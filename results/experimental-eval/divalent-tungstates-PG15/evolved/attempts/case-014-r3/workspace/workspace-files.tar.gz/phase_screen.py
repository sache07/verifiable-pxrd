#!/usr/bin/env python3
"""Plot the measured pattern with candidate COD stick patterns."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import percentile_filter


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    pattern = pd.read_csv("inputs/pattern.csv")
    x = pattern.two_theta_deg.to_numpy()
    y = pattern.intensity.to_numpy()
    baseline = percentile_filter(y, percentile=12, size=251, mode="nearest")
    net = y - baseline

    candidates = [
        ("SrWO4 scheelite", "1546036", "tab:blue"),
        ("WO3 monoclinic", "1528915", "tab:orange"),
        ("SrCO3 Pnma", "9008198", "tab:green"),
        ("Sr3W2O9 C2/c", "2311977", "tab:red"),
    ]
    fig, axes = plt.subplots(
        2, 1, figsize=(16, 9), sharex=True, gridspec_kw={"height_ratios": [3, 1]}
    )
    axes[0].plot(x, y, color="black", lw=0.6)
    axes[0].plot(x, baseline, color="gray", lw=0.8)
    axes[0].set_yscale("symlog", linthresh=600)
    axes[0].set_ylabel("Counts")

    calc = XRDCalculator(wavelength=1.540598)
    offsets = np.arange(len(candidates))[::-1]
    for offset, (label, cod_id, color) in zip(offsets, candidates):
        structure = Structure.from_file(cod_path(cod_id))
        sticks = calc.get_pattern(structure, two_theta_range=(10, 100))
        keep = sticks.y >= 0.7
        axes[1].vlines(
            np.asarray(sticks.x)[keep],
            offset,
            offset + np.asarray(sticks.y)[keep] / 110,
            color=color,
            lw=0.8,
        )
        axes[1].text(10.2, offset + 0.25, label, color=color, va="bottom")
    axes[1].set_ylim(-0.1, len(candidates))
    axes[1].set_yticks([])
    axes[1].set_xlabel(r"$2\theta$ (degrees, Cu K$\alpha_1$)")
    axes[1].set_xlim(10, 100)
    fig.tight_layout()
    fig.savefig("phase_screen.png", dpi=160)


if __name__ == "__main__":
    main()
