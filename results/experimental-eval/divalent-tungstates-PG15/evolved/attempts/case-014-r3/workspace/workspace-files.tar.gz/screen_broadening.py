#!/usr/bin/env python3
"""Screen isotropic phase size and strain from neutral values."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SOURCE = Path("baseline_p1.gpx")
OUTDIR = Path("broadening_trials")


def freeze(project, hist):
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.getHAPvalues(hist.name)
        hap["Scale"][1] = False
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]


def main():
    OUTDIR.mkdir(exist_ok=True)
    results = []
    for phase_index in range(3):
        for kind in ["Size", "Mustrain"]:
            output = OUTDIR / f"p{phase_index}_{kind.lower()}.gpx"
            shutil.copy2(SOURCE, output)
            project = G2sc.G2Project(gpxfile=str(output))
            project.set_Controls("cycles", 6)
            hist = project.histogram(0)
            freeze(project, hist)
            phase = project.phase(phase_index)
            hap = phase.getHAPvalues(hist.name)
            hap[kind][2][0] = True
            variable = f"{phase.data['pId']}:{hist.id}:{kind};i"
            if kind == "Size":
                hap[kind][1][0] = 10.0
                project.set_Controls("parmMin", 0.01, variable=variable)
                project.set_Controls("parmMax", 10.0, variable=variable)
            else:
                hap[kind][1][0] = 0.0
                project.set_Controls("parmMin", 0.0, variable=variable)
                project.set_Controls("parmMax", 10000.0, variable=variable)
            project.refine()
            project.save(str(output))
            covariance = project.data.get("Covariance", {}).get("data", {})
            esd = None
            if variable in covariance.get("varyList", []):
                esd = covariance["sig"][covariance["varyList"].index(variable)]
            item = {
                "phase": phase.name,
                "kind": kind,
                "Rwp": hist.residuals.get("wR"),
                "value": hap[kind][1][0],
                "esd": esd,
            }
            results.append(item)
            print(json.dumps(item, default=float))
    print(json.dumps(results, indent=2, default=float))


if __name__ == "__main__":
    main()
