#!/usr/bin/env python3
"""Build explicitly documented cross-chemistry prototype CIFs."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"
)
OUTPUT = Path("prototypes")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def substitute(cod_id: str, mapping: dict[str, str], output: str) -> None:
    structure = Structure.from_file(cod_path(cod_id))
    structure.replace_species(mapping)
    CifWriter(structure, symprec=0.01, refine_struct=False).write_file(OUTPUT / output)


def gsas_preserving_substitute(cod_id: str, mode: str, output: str) -> None:
    """Keep the COD setting/symmetry loop while changing only atom records."""
    lines = cod_path(cod_id).read_text().splitlines(keepends=True)
    converted: list[str] = []
    for line in lines:
        if line.startswith("_chemical_formula_sum"):
            converted.append("_chemical_formula_sum            'O6 Sr3 W'\n")
        elif line.startswith("_chemical_formula_weight"):
            converted.append("_chemical_formula_weight         542.70\n")
        elif mode == "ca_to_sr" and line.startswith("Ca Ca "):
            converted.append("Sr Sr " + line[len("Ca Ca ") :])
        elif mode == "ca_to_sr" and line.startswith("Ca Ca2 "):
            converted.append("Sr Sr2 " + line[len("Ca Ca2 ") :])
        elif mode == "ca_to_sr" and line.strip() == "Ca 6.0":
            converted.append("Sr 6.0\n")
        elif mode == "u_to_w" and line.startswith("U "):
            converted.append("W " + line[len("U ") :])
        else:
            converted.append(line)
    (OUTPUT / output).write_text("".join(converted))


def replace_tokens(cod_id: str, replacements: dict[str, str], output: str) -> None:
    """Preserve a parent CIF setting while replacing complete chemical tokens."""
    import re

    text = cod_path(cod_id).read_text()
    for source in sorted(replacements, key=len, reverse=True):
        target = replacements[source]
        text = re.sub(rf"(?<![A-Za-z]){re.escape(source)}(?![a-z])", target, text)
    (OUTPUT / output).write_text(text)


def main() -> None:
    OUTPUT.mkdir(exist_ok=True)
    substitute("1563081", {"Ca": "Sr"}, "Sr3WO6_Ca3WO6_parent_1563081.cif")
    substitute("2001752", {"U": "W"}, "Sr3WO6_Sr3UO6_parent_2001752.cif")
    substitute("1534803", {"Ba": "Sr"}, "Sr3WO6_Ba3WO6_parent_1534803.cif")
    gsas_preserving_substitute(
        "1563081", "ca_to_sr", "Sr3WO6_Ca3WO6_parent_1563081_gsas.cif"
    )
    gsas_preserving_substitute(
        "2001752", "u_to_w", "Sr3WO6_Sr3UO6_parent_2001752_gsas.cif"
    )
    # Ba2ReO5 is an exact charge-balanced analogue: Ba2+ -> Sr2+ and
    # Re6+ -> W6+.  The lanthanide parents are coupled substitutions and are
    # retained only as competing structural parents.
    replace_tokens(
        "1529756",
        {"Ba": "Sr", "Re": "W"},
        "Sr2WO5_Ba2ReO5_parent_1529756_gsas.cif",
    )
    replace_tokens(
        "1521237",
        {"Gd+3": "Sr+2", "Re+4": "W+6", "Gd": "Sr", "Re": "W"},
        "Sr2WO5_Gd2ReO5_parent_1521237_gsas.cif",
    )
    replace_tokens(
        "1521235",
        {"Eu+3": "Sr+2", "Re+4": "W+6", "Eu": "Sr", "Re": "W"},
        "Sr2WO5_Eu2ReO5_parent_1521235_gsas.cif",
    )


if __name__ == "__main__":
    main()
