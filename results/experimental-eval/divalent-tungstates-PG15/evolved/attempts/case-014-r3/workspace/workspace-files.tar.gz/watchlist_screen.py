#!/usr/bin/env python3
"""Re-challenge plausible weak phases under the accepted common profile."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize(phase, hist):
    phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=0.5)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=0.5)
    hap = phase.getHAPvalues(hist.name)
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def freeze(project, hist):
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.getHAPvalues(hist.name)
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        for atom in phase.data["Atoms"]:
            atom[2] = ""


def set_cell(phase, cell):
    phase.data["General"]["Cell"][1:7] = cell
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def main():
    trials = [
        (
            "Sr3WO6_P21n",
            Path("prototypes/Sr3WO6_Sr3UO6_parent_2001752_gsas.cif"),
            [6.0530, 6.1658, 8.5630, 90.0, 90.2969, 90.0],
        ),
        ("SrCO3_Pnma", cod("9008198"), None),
        ("Sr3W2O9_C2c", cod("2311977"), None),
        (
            "Sr2WO5_P4n_alt",
            Path("prototypes/Sr2WO5_Gd2ReO5_parent_1521237_gsas.cif"),
            None,
        ),
    ]
    Path("watchlist_trials").mkdir(exist_ok=True)
    results = []
    for label, candidate_file, cell in trials:
        output = Path("watchlist_trials") / f"{label}.gpx"
        shutil.copy2("joint_accepted.gpx", output)
        project = G2sc.G2Project(gpxfile=str(output))
        project.set_Controls("cycles", 6)
        hist = project.histogram(0)
        freeze(project, hist)
        candidate = project.add_phase(
            str(candidate_file), phasename=label, histograms=[hist], fmthint="CIF"
        )
        neutralize(candidate, hist)
        if cell is not None:
            set_cell(candidate, cell)
        hap = candidate.getHAPvalues(hist.name)
        hap["Scale"] = [0.05, True]
        variable = f"{candidate.data['pId']}:{hist.id}:Scale"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.refine()
        project.save(str(output))
        try:
            fraction = hist.ComputeMassFracs()[candidate.name]
        except Exception:
            fraction = None
        item = {
            "phase": candidate.name,
            "scale": hap["Scale"][0],
            "weight_fraction": fraction,
            "Rwp": hist.residuals.get("wR"),
        }
        results.append(item)
        print(json.dumps(item, default=float))
    print(json.dumps(results, indent=2, default=float))


if __name__ == "__main__":
    main()
