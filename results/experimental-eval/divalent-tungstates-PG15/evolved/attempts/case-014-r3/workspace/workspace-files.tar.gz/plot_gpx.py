#!/usr/bin/env python3
"""Create a diagnostic observed/calculated/difference plot from a GSAS-II project."""

from __future__ import annotations

import argparse

import matplotlib.pyplot as plt
import numpy as np
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx")
    parser.add_argument("output")
    parser.add_argument("--xmin", type=float)
    parser.add_argument("--xmax", type=float)
    parser.add_argument("--linear", action="store_true")
    args = parser.parse_args()

    project = G2sc.G2Project(gpxfile=args.gpx)
    hist = project.histogram(0)
    x, yobs, _, ycalc, ybkg, diff = [np.asarray(v) for v in hist.data["data"][1]]
    fig, (top, bottom) = plt.subplots(
        2, 1, figsize=(17, 9), sharex=True, gridspec_kw={"height_ratios": [2.2, 1]}
    )
    top.plot(x, yobs, color="black", lw=0.55, label="observed")
    top.plot(x, ycalc, color="tab:red", lw=0.8, label="calculated")
    top.plot(x, ybkg, color="tab:green", lw=0.7, label="background")
    if not args.linear:
        top.set_yscale("symlog", linthresh=500)
    top.legend(loc="upper right")
    top.set_ylabel("Counts")

    bottom.plot(x, diff, color="tab:blue", lw=0.55)
    bottom.axhline(0, color="gray", lw=0.5)
    colors = plt.cm.tab10.colors
    reflection_lists = hist.reflections()
    base = min(np.nanpercentile(diff, 1), -500)
    spacing = max(150, (np.nanpercentile(diff, 99) - base) * 0.04)
    for i, (name, values) in enumerate(reflection_lists.items()):
        positions = values["RefList"][:, 5]
        y0 = base - i * spacing
        bottom.vlines(positions, y0, y0 + spacing * 0.6, color=colors[i], lw=0.6)
        bottom.text(10.2, y0, name, color=colors[i], va="bottom")
    bottom.set_ylim(base - len(reflection_lists) * spacing, np.nanpercentile(diff, 99.8) * 1.1)
    bottom.set_xlabel(r"$2\theta$ (degrees)")
    bottom.set_ylabel("Observed - calculated")
    bottom.set_xlim(args.xmin or x.min(), args.xmax or x.max())
    fig.tight_layout()
    fig.savefig(args.output, dpi=170)


if __name__ == "__main__":
    main()
