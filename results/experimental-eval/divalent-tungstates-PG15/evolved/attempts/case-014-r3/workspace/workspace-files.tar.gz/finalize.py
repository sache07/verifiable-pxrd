#!/usr/bin/env python3
"""Build, replay, export, and document the final GSAS-II model."""

from __future__ import annotations

import csv
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


SOURCE = Path("joint_accepted.gpx")
FINAL = Path("final.gpx")
CIF_PATHS = [
    Path("phase_1_SrWO4.cif"),
    Path("phase_2_WO3.cif"),
    Path("phase_3_Sr2WO5_Pnma.cif"),
]
FORMULAS = ["SrWO4", "WO3", "Sr2WO5"]
DISPLAY_NAMES = [
    "SrWO4 (scheelite)",
    "WO3 (monoclinic)",
    "Sr2WO5 (Pnma prototype)",
]
SOURCES = [
    "COD 1546036",
    "COD 1528915",
    "Ba2ReO5 parent, COD 1529756; Ba2+/Re6+ -> Sr2+/W6+",
]


def configure(project: G2sc.G2Project) -> None:
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)
    x = np.asarray(hist.data["data"][1][0])
    hist.Limits("lower", float(x[0]))
    hist.Limits("upper", float(x[-1]))

    hist.Background[0][0] = "chebyschev-1"
    hist.Background[0][1] = True
    hist.Background[0][2] = 8
    hist.SampleParameters["Scale"] = [1.0, False]
    for key in ["Absorption", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]:
        if key in hist.SampleParameters and isinstance(hist.SampleParameters[key], list):
            hist.SampleParameters[key][0] = 0.0
            hist.SampleParameters[key][1] = False

    for key, value in [("U", 0.0), ("V", 0.0), ("Y", 0.0), ("Z", 0.0)]:
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = False
    hist.InstrumentParameters["Zero"][2] = True
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["X"][2] = True
    # A free trial ran to the physical endpoint. Use a near-complete fixed
    # correction so no bound-refined polarization term survives in the model.
    hist.InstrumentParameters["Polariz."][1] = 0.99
    hist.InstrumentParameters["Polariz."][2] = False
    hist.InstrumentParameters["SH/L"][1] = 0.002
    hist.InstrumentParameters["SH/L"][2] = False
    hist.InstrumentParameters["I(L2)/I(L1)"][1] = 0.5
    hist.InstrumentParameters["I(L2)/I(L1)"][2] = False

    for index, phase in enumerate(project.phases()):
        phase.data["General"]["Cell"][0] = True
        hap = phase.getHAPvalues(hist.name)
        hap["Scale"][1] = True
        hap["Size"] = [
            "isotropic", [10.0, 1.0, 0.5], [False, False, False],
            [0, 0, 1], hap["Size"][4], [False] * len(hap["Size"][5]),
        ]
        strain = hap["Mustrain"][1][0] if index in [1, 2] else 0.0
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        hap["Mustrain"][2] = [index in [1, 2], False, False]
        hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
        hap["Extinction"] = [0.0, False]
        if "Babinet" in hap:
            hap["Babinet"]["BabA"] = [0.0, False]
            hap["Babinet"]["BabU"] = [0.0, False]
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        for atom in phase.data["Atoms"]:
            atom[2] = "U" if index == 0 else ""

    for phase_index in [1, 2]:
        variable = f"{project.phase(phase_index).data['pId']}:{hist.id}:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 10000.0, variable=variable)
    phase = project.phase(0)
    for atom_index in range(len(phase.data["Atoms"])):
        variable = f"{phase.data['pId']}::AUiso:{atom_index}"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 0.03, variable=variable)


def replay_to_stability() -> tuple[G2sc.G2Project, list[float]]:
    shutil.copy2(SOURCE, FINAL)
    project = G2sc.G2Project(gpxfile=str(FINAL))
    configure(project)
    project.save(str(FINAL))
    rwps = []
    for _ in range(4):
        project = G2sc.G2Project(gpxfile=str(FINAL))
        project.refine()
        project.save(str(FINAL))
        rwps.append(float(project.histogram(0).residuals["wR"]))
        if len(rwps) > 1 and abs(rwps[-1] - rwps[-2]) < 1.0e-5:
            break
    return project, rwps


def main() -> None:
    project, replay_rwps = replay_to_stability()
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]

    for phase, path in zip(project.phases(), CIF_PATHS):
        phase.export_CIF(str(path))

    x, observed, weights, calculated, background, difference = [
        np.asarray(item) for item in hist.data["data"][1]
    ]
    with Path("fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg", "observed_counts", "calculated_counts",
            "difference_counts", "background_counts",
        ])
        writer.writerows(zip(x, observed, calculated, difference, background))

    phases_json = []
    for index, (phase, path, formula, display_name, source) in enumerate(
        zip(project.phases(), CIF_PATHS, FORMULAS, DISPLAY_NAMES, SOURCES)
    ):
        fraction, fraction_esd = fractions[phase.name]
        pfx = f"{phase.data['pId']}:{hist.id}:"
        phases_json.append({
            "name": display_name,
            "formula": formula,
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "cif_path": str(path),
            "weight_fraction": float(fraction),
            "weight_fraction_esd_formal": float(fraction_esd),
            "structure_source": source,
            "cell": {key: float(value) for key, value in phase.get_cell().items()},
            "R_F_percent": hist.residuals.get(f"{phase.data['pId']}:{hist.id}:Rf"),
            "R_F2_percent": hist.residuals.get(f"{phase.data['pId']}:{hist.id}:Rf^2"),
        })

    result = {
        "phases": phases_json,
        "crystalline_weight_fraction_sum": float(sum(p["weight_fraction"] for p in phases_json)),
        "fit_statistics": {
            "Rwp_percent": float(hist.residuals["wR"]),
            "Rp_percent": float(hist.residuals["R"]),
            "Rexp_percent": float(hist.residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "combined_Rbragg_percent": float(hist.residuals["Rb"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
        },
        "profile": {
            "two_theta_range_deg": [float(x[0]), float(x[-1])],
            "wavelengths_angstrom": [1.540598, 1.544426],
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "effective_polarization_fixed": 0.99,
            "replay_Rwp_percent": replay_rwps,
        },
        "scope": "Fractions are normalized over the modeled crystalline phases; amorphous content was not determined.",
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")

    pct = [100.0 * item["weight_fraction"] for item in phases_json]
    esd_pct = [100.0 * item["weight_fraction_esd_formal"] for item in phases_json]
    cells = [item["cell"] for item in phases_json]
    report = f"""# PXRD phase analysis

## Result

The modeled crystalline assemblage is:

| Phase | Space group | Crystalline weight fraction |
|---|---:|---:|
| SrWO4, scheelite | I 41/a | {pct[0]:.2f}% (formal esd {esd_pct[0]:.2f}%) |
| WO3, monoclinic | P 21/n | {pct[1]:.2f}% (formal esd {esd_pct[1]:.2f}%) |
| Sr2WO5, Pnma prototype | P n m a | {pct[2]:.2f}% (formal esd {esd_pct[2]:.2f}%) |

These fractions sum to 100% over the modeled crystalline phases. No internal standard was supplied, so amorphous content cannot be quantified. The final full-range fit has Rwp = {hist.residuals['wR']:.3f}%, Rp = {hist.residuals['R']:.3f}%, Rexp = {hist.residuals['wRmin']:.3f}%, and GOF = {rvals['GOF']:.3f}.

## Evidence and model selection

Scheelite SrWO4 is fixed by its coherent 101, 112, 004, 200, 204, 220, 116, 312, and higher-angle doublet families. Its refined cell is a = {cells[0]['length_a']:.5f} and c = {cells[0]['length_c']:.5f} A. The minor monoclinic WO3 model accounts for the distinctive 23.43/23.91/24.68 degree group and many higher-angle lines; it fit better and retained a physical cell compared with the tested Pnma WO3 polymorph.

Residual families at approximately 15.00, 16.56, 20.6, 22.0, 29.70-29.89, 32.56, 44.62, and 53.39 degrees require the third phase. No exact Sr2WO5 entry was available, so the supplied analogue search was used. The selected model is the Pnma Ba2ReO5 parent (COD 1529756) with the charge-preserving substitutions Ba2+ -> Sr2+ and Re6+ -> W6+. Its refined cell is a = {cells[2]['length_a']:.5f}, b = {cells[2]['length_b']:.5f}, c = {cells[2]['length_c']:.5f} A. The resulting W-O distances (about 1.75-2.01 A) and Sr-O distances (about 2.60-2.91 A) are physically credible. A P4/n Sr2WO5 parent refined to zero scale; Sr3WO6 and Sr3W2O9 watch-list models gave only about 0.46 and 0.35 wt%, respectively, without independent strong unique families. SrCO3 gave about 0.2 wt%. These sub-percent signals were not considered reliable enough to add.

## Refinement checks and uncertainty

The GSAS-II model used the measured Cu Kalpha1/Kalpha2 doublet, an eight-term smooth Chebyshev background, one zero correction, and a nonnegative shared W/X profile. Sizes, roughness, extinction, and preferred orientation were neutral; axial and diagonal March-Dollase trials stayed close to unity and were pruned. Modest replay-stable isotropic microstrain was retained for WO3 and Sr2WO5. SrWO4 displacement parameters refined to physical values. Releasing its oxygen coordinates lowered Rwp but lengthened tetrahedral W-O to about 1.99 A, so that trial was rejected and the source geometry retained.

The cross-phase high-angle intensity trend required a near-complete polarization correction. A free polarization trial reached its physical upper limit, so the final project fixes it at 0.99 rather than retaining a bound parameter. Because effective polarization was not reported and pointwise uncertainties were absent (Poisson weights were used), the formal fraction esds understate model uncertainty. A practical sensitivity is roughly 1-3 absolute wt% for the major/prototype fractions. The Sr2WO5 topology and cell are well supported by the pattern, but its detailed atomic coordinates remain a substituted-parent model and are not uniquely determined by these data.
"""
    Path("report.md").write_text(report)

    print(json.dumps({
        "Rwp": hist.residuals["wR"],
        "replay_Rwp": replay_rwps,
        "fractions": fractions,
        "files": [str(FINAL), "fit.csv", "result.json", "report.md"] + [str(p) for p in CIF_PATHS],
    }, indent=2, default=float))


if __name__ == "__main__":
    main()
