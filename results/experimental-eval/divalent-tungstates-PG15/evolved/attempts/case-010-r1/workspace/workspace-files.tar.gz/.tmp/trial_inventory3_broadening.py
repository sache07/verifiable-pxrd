from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
phase_index = int(sys.argv[1])
mode = sys.argv[2]
target = work / ".tmp" / f"inventory3_broad_p{phase_index}_{mode}.gpx"
p = G2sc.G2Project(str(work / ".tmp" / "inventory3_neutral.gpx"), newgpx=str(target))
h = p.histogram(0)
phase = p.phase(phase_index)
hap = phase.getHAPvalues(h)
if mode == "size":
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2] = [True, False, False]
elif mode == "strain":
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 500.0
    hap["Mustrain"][2] = [True, False, False]
else:
    raise ValueError(mode)

p["Controls"]["data"]["max cyc"] = 10
p["Controls"]["data"]["min dM/M"] = 1e-5
for replay in range(2):
    p.refine()
    p.save()
    p = G2sc.G2Project(str(target))
    h = p.histogram(0)
    phase = p.phase(phase_index)

rv = p["Covariance"]["data"].get("Rvals", {})
print("RESULT " + json.dumps({
    "phase": phase.name,
    "mode": mode,
    "wR": h.get_wR(),
    "fractions": h.ComputeMassFracs(),
    "size": phase.getHAPvalues(h)["Size"],
    "mustrain": phase.getHAPvalues(h)["Mustrain"],
    "profile": {key: h.InstrumentParameters[key][1] for key in ("U", "W", "X")},
    "rvals": rv,
}, sort_keys=True), flush=True)
