from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
phase_index = int(sys.argv[1])
mode = sys.argv[2]
gpx = work / ".tmp" / f"broad_p{phase_index}_{mode}.gpx"
p = G2sc.G2Project(str(work / ".tmp" / "twophase_shift.gpx"), newgpx=str(gpx))
h = p.histogram(0)
phase = p.phase(phase_index)
hap = phase.getHAPvalues(h)

if mode == "size":
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [1.0, 1.0, 0.5]
    hap["Size"][2] = [True, False, False]
elif mode == "strain":
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [500.0, 500.0, 0.5]
    hap["Mustrain"][2] = [True, False, False]
else:
    raise ValueError(mode)

p["Controls"]["data"]["max cyc"] = 7
p["Controls"]["data"]["min dM/M"] = 1e-5
p.refine()
p.save()
p = G2sc.G2Project(str(gpx))
h = p.histogram(0)
phase = p.phase(phase_index)
out = {
    "phase": phase.name,
    "mode": mode,
    "wR": h.get_wR(),
    "fractions": h.ComputeMassFracs(),
    "profile": {key: h.InstrumentParameters[key][1] for key in ["U", "W", "X", "SH/L"]},
    "size": phase.getHAPvalues(h)["Size"],
    "mustrain": phase.getHAPvalues(h)["Mustrain"],
    "rvals": p["Covariance"]["data"].get("Rvals"),
}
print("RESULT " + json.dumps(out, sort_keys=True), flush=True)
