from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
phase_name = sys.argv[1]
target = work / ".tmp" / f"adp_{phase_name}.gpx"
p = G2sc.G2Project(str(work / "final.gpx"), newgpx=str(target))
phase = p.phase(phase_name)

groups = {}
for atom in phase.atoms():
    if atom.adp_flag != "I":
        continue
    groups.setdefault(atom.element, []).append(atom)
    atom.uiso = 0.005 if atom.element in {"W", "O"} else 0.008
    atom.refinement_flags = "U"
p.save()
for atoms in groups.values():
    if len(atoms) > 1:
        variables = [(phase, None, "AUiso", atom) for atom in atoms]
        p.add_EquivConstr(variables)

p["Controls"]["data"]["max cyc"] = 12
p["Controls"]["data"]["min dM/M"] = 1e-5
for _ in range(3):
    p.refine()
    p.save()
    p = G2sc.G2Project(str(target))
    phase = p.phase(phase_name)
    rv = p["Covariance"]["data"].get("Rvals", {})
    if rv.get("converged") and abs(rv.get("DelChi2", 1.0)) < 1e-5:
        break

h = p.histogram(0)
print("RESULT " + json.dumps({
    "phase": phase_name,
    "wR": h.get_wR(),
    "fractions": h.ComputeMassFracs(),
    "uiso": {atom.label: atom.uiso for atom in phase.atoms() if atom.adp_flag == "I"},
    "vary_list": p["Covariance"]["data"].get("varyList", []),
    "rvals": p["Covariance"]["data"].get("Rvals", {}),
}, sort_keys=True), flush=True)
