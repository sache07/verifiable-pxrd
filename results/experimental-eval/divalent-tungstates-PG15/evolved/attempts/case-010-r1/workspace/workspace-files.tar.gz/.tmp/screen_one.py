from pathlib import Path
import json
import sys

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
root = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
label, cod_id = sys.argv[1:3]
cif = root / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"
gpx = work / ".tmp" / f"screen_one_{cod_id}.gpx"

p = G2sc.G2Project(newgpx=str(gpx))
h = p.add_powder_histogram(str(work / "inputs" / "pattern.csv"), str(work / ".tmp" / "instrument.instprm"))
x = np.asarray(h.getdata("X"))
y = np.asarray(h.getdata("Yobs"))
b = percentile_filter(y, 15, size=301, mode="nearest")
t = -1 + 2 * (x - x[0]) / (x[-1] - x[0])
co = np.polynomial.chebyshev.chebfit(t, b, 5)
h.set_refinements({"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 6, "coeffs": co.tolist()}})
h.SampleParameters["Scale"] = [1.0, False]
for key, value in {"U": 156.94, "V": 0.0, "W": 2.08, "X": 12.91, "Y": 0.0, "Z": 0.0, "SH/L": 0.002, "Zero": 0.30}.items():
    h.InstrumentParameters[key][0] = h.InstrumentParameters[key][1] = value
    h.InstrumentParameters[key][2] = False
ph = p.add_phase(str(cif), phasename=label, histograms=[h], fmthint="CIF")
# Some legacy COD files label tungsten with oxidation states that are not in
# the GSAS-II X-ray form-factor table. Keep the sites/occupancies unchanged and
# use neutral-W scattering for a like-for-like phase-screening calculation.
for atom in ph.atoms():
    if atom.element == "W" and atom.type != "W":
        atom.type = "W"
G2sc.SetupGeneral(ph.data, None)
hap = ph.getHAPvalues(h)
hap["Scale"] = [1.0, True]
hap["Pref.Ori."][1:3] = [1.0, False]
hap["Size"][0] = "isotropic"
hap["Size"][1] = [1000.0, 1000.0, 0.5]
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1] = [0.0, 0.0, 0.5]
hap["Mustrain"][2] = [False, False, False]
p["Controls"]["data"]["min dM/M"] = 1e-5
p["Controls"]["data"]["max cyc"] = 4
p.refine()
p.save()
print("SCALE " + json.dumps({"wR": h.get_wR(), "scale": hap["Scale"][0]}), flush=True)

ph.set_refinements({"Cell": True})
h.set_refinements({"Instrument Parameters": ["Zero"]})
p["Controls"]["data"]["max cyc"] = 7
p.refine()
p.save()
p = G2sc.G2Project(str(gpx))
h, ph = p.histogram(0), p.phase(0)
p["Controls"]["data"]["max cyc"] = 5
p.refine()
p.save()
out = {
    "label": label,
    "cod_id": cod_id,
    "wR": h.get_wR(),
    "R": h.residuals.get("R"),
    "scale": ph.getHAPvalues(h)["Scale"][0],
    "zero": h.InstrumentParameters["Zero"][1],
    "cell": ph.get_cell(),
    "converged": p["Covariance"]["data"].get("Rvals", {}).get("converged"),
}
print("RESULT " + json.dumps(out, sort_keys=True), flush=True)
