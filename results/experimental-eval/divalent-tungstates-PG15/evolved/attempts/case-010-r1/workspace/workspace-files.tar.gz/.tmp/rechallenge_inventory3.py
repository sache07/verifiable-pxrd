from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
root = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
label, cod_id = sys.argv[1:3]
cif = root / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"
target = work / ".tmp" / f"inventory3_challenge_{cod_id}.gpx"
p = G2sc.G2Project(str(work / ".tmp" / "inventory3.gpx"), newgpx=str(target))
h = p.histogram(0)
ph = p.add_phase(str(cif), phasename=label, histograms=[h], fmthint="CIF")
for atom in ph.atoms():
    if atom.element in {"Mn", "W", "O"} and atom.type != atom.element:
        atom.type = atom.element
G2sc.SetupGeneral(ph.data, None)
hap = ph.getHAPvalues(h)
hap["Scale"] = [0.005, True]
hap["Pref.Ori."][1:3] = [1.0, False]
hap["Size"][0] = "isotropic"
hap["Size"][1] = [10.0, 10.0, 0.5]
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1] = [0.0, 0.0, 0.5]
hap["Mustrain"][2] = [False, False, False]

for phase in p.phases():
    phase.getHAPvalues(h)["Scale"][1] = True
h.Background[0][1] = True
h.SampleParameters["Shift"][1] = True
for key in ("U", "W", "X"):
    h.InstrumentParameters[key][2] = True
p["Controls"]["data"]["max cyc"] = 10
p["Controls"]["data"]["min dM/M"] = 1e-5
p.refine()
p.save()
scale_only = {
    "wR": h.get_wR(),
    "scale": ph.getHAPvalues(h)["Scale"][0],
    "fractions": h.ComputeMassFracs(),
}

ph.set_refinements({"Cell": True})
p.refine()
p.save()
p = G2sc.G2Project(str(target))
h = p.histogram(0)
p["Controls"]["data"]["max cyc"] = 10
p.refine()
p.save()
p = G2sc.G2Project(str(target))
h = p.histogram(0)
ph = p.phase(label)
print("RESULT " + json.dumps({
    "label": label,
    "cod_id": cod_id,
    "scale_only": scale_only,
    "wR": h.get_wR(),
    "fractions": h.ComputeMassFracs(),
    "candidate_scale": ph.getHAPvalues(h)["Scale"][0],
    "candidate_cell": ph.get_cell(),
    "rvals": p["Covariance"]["data"].get("Rvals", {}),
}, sort_keys=True), flush=True)
