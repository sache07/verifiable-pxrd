from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
target = work / ".tmp" / "inventory3_neutral.gpx"
p = G2sc.G2Project(str(work / ".tmp" / "inventory3.gpx"), newgpx=str(target))

for replay in range(3):
    h = p.histogram(0)
    for phase in p.phases():
        hap = phase.getHAPvalues(h)
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Scale"][1] = True
        phase.set_refinements({"Cell": True})
    h.Background[0][1] = True
    h.SampleParameters["Shift"][1] = True
    for key in ("U", "W", "X"):
        h.InstrumentParameters[key][2] = True
    p["Controls"]["data"]["max cyc"] = 12
    p["Controls"]["data"]["min dM/M"] = 1e-5
    p.refine()
    p.save()
    p = G2sc.G2Project(str(target))
    rv = p["Covariance"]["data"].get("Rvals", {})
    print("REPLAY " + json.dumps({"i": replay, "wR": p.histogram(0).get_wR(), **rv}, default=str), flush=True)
    if replay >= 1 and rv.get("converged") and abs(rv.get("DelChi2", 1)) < 1e-5:
        break

h = p.histogram(0)
print("RESULT " + json.dumps({
    "wR": h.get_wR(),
    "fractions": h.ComputeMassFracs(),
    "profile": {key: h.InstrumentParameters[key][1] for key in ("U", "W", "X")},
    "rvals": p["Covariance"]["data"].get("Rvals", {}),
}, sort_keys=True), flush=True)
