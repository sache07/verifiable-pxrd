from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
base = work / ".tmp" / "broad_p1_size.gpx"
trials = {
    0: [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1), (1, 1, 1)],
    1: [(1, 0, 0), (1, 1, 0), (1, 1, 1)],
}

for phase_index, directions in trials.items():
    for hkl in directions:
        tag = "".join(str(v) for v in hkl)
        output = work / ".tmp" / f"texture_p{phase_index}_{tag}.gpx"
        p = G2sc.G2Project(str(base), newgpx=str(output))
        h = p.histogram(0)
        phase = p.phase(phase_index)
        po = phase.getHAPvalues(h)["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = list(hkl)
        p["Controls"]["data"]["max cyc"] = 4
        p["Controls"]["data"]["min dM/M"] = 1e-5
        p.refine()
        p.save()
        result = {
            "phase": phase.name,
            "phase_index": phase_index,
            "hkl": hkl,
            "MD": phase.getHAPvalues(h)["Pref.Ori."][1],
            "wR": h.get_wR(),
            "fractions": h.ComputeMassFracs(),
            "converged": p["Covariance"]["data"].get("Rvals", {}).get("converged"),
            "delta_chi2": p["Covariance"]["data"].get("Rvals", {}).get("DelChi2"),
        }
        print("RESULT " + json.dumps(result, sort_keys=True), flush=True)
