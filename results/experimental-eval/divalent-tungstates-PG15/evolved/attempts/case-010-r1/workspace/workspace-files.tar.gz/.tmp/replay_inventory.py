from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
source = work / ".tmp" / "rechallenge_1520200.gpx"
target = work / ".tmp" / "inventory3.gpx"
p = G2sc.G2Project(str(source), newgpx=str(target))

for replay in range(4):
    h = p.histogram(0)
    h.Background[0][1] = True
    h.SampleParameters["Shift"][1] = True
    h.InstrumentParameters["Zero"][2] = False
    for key in ("U", "W", "X"):
        h.InstrumentParameters[key][2] = True
    for key in ("V", "Y", "Z", "SH/L"):
        h.InstrumentParameters[key][2] = False

    for phase in p.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.getHAPvalues(h)
        hap["Scale"][1] = True
        hap["Pref.Ori."][1:3] = [1.0, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"] = [0.0, False]
        hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
        if phase.name == "Mn2O3_Ia-3":
            hap["Size"][0] = "isotropic"
            hap["Size"][2] = [True, False, False]
        else:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 10.0
            hap["Size"][2] = [False, False, False]

    h.SampleParameters["SurfRoughA"] = [0.0, False]
    h.SampleParameters["SurfRoughB"] = [0.0, False]
    p["Controls"]["data"]["max cyc"] = 12
    p["Controls"]["data"]["min dM/M"] = 1e-5
    p.refine()
    p.save()
    p = G2sc.G2Project(str(target))
    rvals = p["Covariance"]["data"].get("Rvals", {})
    print("REPLAY " + json.dumps({
        "index": replay,
        "wR": p.histogram(0).get_wR(),
        "converged": rvals.get("converged"),
        "delta_chi2": rvals.get("DelChi2"),
        "max_shift_esd": rvals.get("Max shft/sig"),
    }, sort_keys=True), flush=True)
    if replay >= 1 and rvals.get("converged") and abs(rvals.get("DelChi2", 1)) < 1e-5:
        break

h = p.histogram(0)
print("RESULT " + json.dumps({
    "wR": h.get_wR(),
    "R": h.residuals.get("R"),
    "fractions": h.ComputeMassFracs(),
    "cells": {phase.name: phase.get_cell() for phase in p.phases()},
    "sizes": {phase.name: phase.getHAPvalues(h)["Size"] for phase in p.phases()},
    "profile": {key: h.InstrumentParameters[key][1] for key in ("U", "W", "X", "SH/L")},
    "shift_um": h.SampleParameters["Shift"][0],
    "rvals": p["Covariance"]["data"].get("Rvals", {}),
}, sort_keys=True), flush=True)
