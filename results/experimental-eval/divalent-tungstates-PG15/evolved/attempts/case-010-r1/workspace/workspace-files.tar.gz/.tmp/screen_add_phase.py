from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
root = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
label, cod_id = sys.argv[1:3]
cif = root / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"
gpx = work / ".tmp" / f"add_{cod_id}.gpx"

p = G2sc.G2Project(str(work / ".tmp" / "screen_2106293.gpx"), newgpx=str(gpx))
h = p.histogram(0)
ph = p.add_phase(str(cif), phasename=label, histograms=[h], fmthint="CIF")
for atom in ph.atoms():
    if atom.element == "W" and atom.type != "W":
        atom.type = "W"
G2sc.SetupGeneral(ph.data, None)
hap = ph.getHAPvalues(h)
hap["Scale"] = [0.2, True]
hap["Pref.Ori."][1:3] = [1.0, False]
hap["Size"][0] = "isotropic"
hap["Size"][1] = [1000.0, 1000.0, 0.5]
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1] = [0.0, 0.0, 0.5]
hap["Mustrain"][2] = [False, False, False]

# Re-converge the common nuisance model and all scales before moving the new cell.
for phase in p.phases():
    phase.getHAPvalues(h)["Scale"][1] = True
h.Background[0][1] = True
h.InstrumentParameters["Zero"][2] = True
p["Controls"]["data"]["min dM/M"] = 1e-5
p["Controls"]["data"]["max cyc"] = 5
p.refine()
p.save()
print("SCALE " + json.dumps({"wR": h.get_wR(), "new_scale": hap["Scale"][0]}), flush=True)

ph.set_refinements({"Cell": True})
p["Controls"]["data"]["max cyc"] = 8
p.refine()
p.save()
p = G2sc.G2Project(str(gpx))
h = p.histogram(0)
p["Controls"]["data"]["max cyc"] = 5
p.refine()
p.save()

out = {
    "label": label,
    "cod_id": cod_id,
    "wR": h.get_wR(),
    "R": h.residuals.get("R"),
    "fractions": h.ComputeMassFracs(),
    "zero": h.InstrumentParameters["Zero"][1],
    "phases": {
        phase.name: {
            "scale": phase.getHAPvalues(h)["Scale"][0],
            "cell": phase.get_cell(),
        }
        for phase in p.phases()
    },
    "converged": p["Covariance"]["data"].get("Rvals", {}).get("converged"),
    "delta_chi2": p["Covariance"]["data"].get("Rvals", {}).get("DelChi2"),
}
print("RESULT " + json.dumps(out, sort_keys=True), flush=True)
