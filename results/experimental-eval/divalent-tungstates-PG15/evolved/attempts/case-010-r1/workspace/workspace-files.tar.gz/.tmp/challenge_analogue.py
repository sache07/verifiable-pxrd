from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
label = sys.argv[1]
cif = Path(sys.argv[2]).resolve()
replace_wolframite = len(sys.argv) > 3 and sys.argv[3] == "replace"
suffix = "replace" if replace_wolframite else "add"
target = work / ".tmp" / f"analogue_challenge_{label}_{suffix}.gpx"
p = G2sc.G2Project(str(work / "final.gpx"), newgpx=str(target))
h = p.histogram(0)

if replace_wolframite:
    old = p.phase("MnWO4_monoclinic").getHAPvalues(h)
    old["Use"] = False
    old["Scale"] = [0.0, False]

ph = p.add_phase(str(cif), phasename=label, histograms=[h], fmthint="CIF")
for atom in ph.atoms():
    if atom.element in {"Mn", "W", "O"} and atom.type != atom.element:
        atom.type = atom.element
G2sc.SetupGeneral(ph.data, None)
hap = ph.getHAPvalues(h)
hap["Scale"] = [0.005, True]
hap["Pref.Ori."][1:3] = [1.0, False]
hap["Size"][0] = "isotropic"
hap["Size"][1] = [10.0, 10.0, 0.5]
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1] = [0.0, 0.0, 0.5]
hap["Mustrain"][2] = [False, False, False]

for phase in p.phases():
    other = phase.getHAPvalues(h)
    if other.get("Use", True):
        other["Scale"][1] = True
h.Background[0][1] = True
h.SampleParameters["Shift"][1] = True
for key in ("U", "W", "X"):
    h.InstrumentParameters[key][2] = True
p["Controls"]["data"]["max cyc"] = 10
p["Controls"]["data"]["min dM/M"] = 1e-5

# Candidate scale first, with its parent cell held fixed.
p.refine()
p.save()
scale_only = {
    "wR": h.get_wR(),
    "scale": ph.getHAPvalues(h)["Scale"][0],
    "fractions": h.ComputeMassFracs(),
}

# A physically supported candidate can then move its symmetry-allowed cell.
ph.set_refinements({"Cell": True})
for _ in range(2):
    p.refine()
    p.save()
    p = G2sc.G2Project(str(target))
    h = p.histogram(0)
    ph = p.phase(label)

print("RESULT " + json.dumps({
    "label": label,
    "mode": suffix,
    "scale_only": scale_only,
    "wR": h.get_wR(),
    "candidate_scale": ph.getHAPvalues(h)["Scale"][0],
    "candidate_cell": ph.get_cell(),
    "fractions": h.ComputeMassFracs(),
    "rvals": p["Covariance"]["data"].get("Rvals", {}),
}, sort_keys=True), flush=True)
