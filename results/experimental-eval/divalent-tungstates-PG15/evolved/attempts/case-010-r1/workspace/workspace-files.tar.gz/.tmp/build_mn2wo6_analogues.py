from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


work = Path(__file__).resolve().parents[1]
parents = [
    ("Cr2WO6_trirutile", Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/53/09/1530909.cif"), "Cr"),
    ("Fe2WO6_orthorhombic", Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/04/2310464.cif"), "Fe"),
    ("V2WO6_trirutile", Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/00/89/1008912.cif"), "V"),
]

for label, source, replaced in parents:
    structure = Structure.from_file(source)
    structure.remove_oxidation_states()
    structure.replace_species({replaced: "Mn"})
    output = work / ".tmp" / f"analogue_{label}.cif"
    CifWriter(structure, symprec=0.01).write_file(output)
    pairs = {}
    for i, site_i in enumerate(structure):
        for j in range(i + 1, len(structure)):
            site_j = structure[j]
            key = "-".join(sorted((site_i.specie.symbol, site_j.specie.symbol)))
            distance = structure.get_distance(i, j)
            pairs[key] = min(distance, pairs.get(key, 1e9))
    print(label, structure.composition.reduced_formula, structure.get_space_group_info(), structure.lattice, pairs, output)
