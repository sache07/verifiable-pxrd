from pathlib import Path
import json

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = [
    ("WO3_triclinic_1978", "2106293"),
    ("WO3_monoclinic_1960", "1528915"),
    ("WO3_small_triclinic_1931", "1010618"),
    ("WO3_orthorhombic_1977", "2107312"),
    ("W10O29_magneli", "1538317"),
    ("W18O49_magneli", "1538315"),
]


def neutralize_hap(hap):
    hap["Scale"] = [1.0, True]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [1000.0, 1000.0, 0.5]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 0.5]
    hap["Mustrain"][2] = [False, False, False]


summary = []
for label, cod_id in CANDIDATES:
    print(f"START {label} {cod_id}", flush=True)
    try:
        project_path = WORK / ".tmp" / f"screen_{cod_id}.gpx"
        project = G2sc.G2Project(newgpx=str(project_path))
        hist = project.add_powder_histogram(
            str(WORK / "inputs" / "pattern.csv"),
            str(WORK / ".tmp" / "instrument.instprm"),
        )
        x = np.asarray(hist.getdata("X"))
        y = np.asarray(hist.getdata("Yobs"))
        baseline = percentile_filter(y, 15, size=301, mode="nearest")
        xpos = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
        coeffs = np.polynomial.chebyshev.chebfit(xpos, baseline, 5)
        hist.set_refinements(
            {
                "Background": {
                    "type": "chebyschev-1",
                    "refine": True,
                    "no. coeffs": 6,
                    "coeffs": coeffs.tolist(),
                }
            }
        )
        hist.SampleParameters["Scale"] = [1.0, False]
        instrument = hist.InstrumentParameters
        for key, value in {
            "U": 156.94,
            "V": 0.0,
            "W": 2.08,
            "X": 12.91,
            "Y": 0.0,
            "Z": 0.0,
            "SH/L": 0.002,
            "Zero": 0.30,
        }.items():
            instrument[key][0] = instrument[key][1] = value
            instrument[key][2] = False
        phase = project.add_phase(
            str(cod_path(cod_id)),
            phasename=label,
            histograms=[hist],
            fmthint="CIF",
        )
        neutralize_hap(phase.getHAPvalues(hist))
        phase.set_refinements({"Cell": True})
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        project["Controls"]["data"]["max cyc"] = 7
        project["Controls"]["data"]["min dM/M"] = 1e-5
        project.refine()
        project.save()
        # Reopen and replay once, as a common convergence/replay check.
        project = G2sc.G2Project(str(project_path))
        hist = project.histogram(0)
        phase = project.phase(0)
        project["Controls"]["data"]["max cyc"] = 5
        project.refine()
        project.save()
        row = {
            "label": label,
            "cod_id": cod_id,
            "wR_percent": hist.get_wR(),
            "R_percent": hist.residuals.get("R"),
            "zero_deg": hist.InstrumentParameters["Zero"][1],
            "scale": phase.getHAPvalues(hist)["Scale"][0],
            "cell": phase.get_cell(),
            "converged": project["Covariance"]["data"].get("Rvals", {}).get("converged"),
            "delta_chi2": project["Covariance"]["data"].get("Rvals", {}).get("DelChi2"),
        }
        summary.append(row)
        print("RESULT " + json.dumps(row, sort_keys=True), flush=True)
    except Exception as exc:
        row = {"label": label, "cod_id": cod_id, "error": repr(exc)}
        summary.append(row)
        print("ERROR " + json.dumps(row, sort_keys=True), flush=True)

(WORK / ".tmp" / "source_screen.json").write_text(json.dumps(summary, indent=2) + "\n")
