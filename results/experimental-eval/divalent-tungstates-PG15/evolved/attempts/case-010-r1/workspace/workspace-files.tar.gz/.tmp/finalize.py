from pathlib import Path
import csv
import json
import math

import numpy as np
from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
source = work / ".tmp" / "inventory3_combined_sizes.gpx"
final = work / "final.gpx"
p = G2sc.G2Project(str(source), newgpx=str(final))

# Restate the retained model so the final project is self-documenting and has
# no dormant nuisance refinements left enabled.
h = p.histogram(0)
h.data["Limits"][1] = list(h.data["Limits"][0])
h.Background[0][1] = True
h.SampleParameters["Scale"] = [1.0, False]
h.SampleParameters["Shift"][1] = True
h.SampleParameters["Transparency"] = [0.0, False]
h.SampleParameters["SurfRoughA"] = [0.0, False]
h.SampleParameters["SurfRoughB"] = [0.0, False]
for key in ("U", "W", "X"):
    h.InstrumentParameters[key][2] = True
for key in ("V", "Y", "Z", "SH/L", "Zero"):
    h.InstrumentParameters[key][2] = False
h.InstrumentParameters["SH/L"][1] = 0.002
h.InstrumentParameters["Zero"][1] = 0.0

size_phases = {"Mn2O3_Ia-3", "MnWO4_monoclinic"}
for phase in p.phases():
    phase.set_refinements({"Cell": True})
    hap = phase.getHAPvalues(h)
    hap["Scale"][1] = True
    hap["Pref.Ori."][1:3] = [1.0, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    hap["Size"][0] = "isotropic"
    hap["Size"][2] = [phase.name in size_phases, False, False]
    if phase.name not in size_phases:
        hap["Size"][1][0] = 10.0

p["Controls"]["data"]["max cyc"] = 12
p["Controls"]["data"]["min dM/M"] = 1e-5

# One full-range serialized replay from the accepted state.
p.refine()
p.save()
p = G2sc.G2Project(str(final))
h = p.histogram(0)
rv = p["Covariance"]["data"].get("Rvals", {})
if not rv.get("converged", False) or abs(rv.get("DelChi2", 1.0)) >= 1e-5:
    p.refine()
    p.save()
    p = G2sc.G2Project(str(final))
    h = p.histogram(0)
    rv = p["Covariance"]["data"].get("Rvals", {})

phase_files = {
    "WO3_triclinic_1978": "phase_1_WO3_triclinic.cif",
    "Mn2O3_Ia-3": "phase_2_Mn2O3_bixbyite.cif",
    "MnWO4_monoclinic": "phase_3_MnWO4_wolframite.cif",
}
phase_labels = {
    "WO3_triclinic_1978": ("tungsten trioxide", "WO3", "P -1"),
    "Mn2O3_Ia-3": ("bixbyite manganese(III) oxide", "Mn2O3", "Ia-3"),
    "MnWO4_monoclinic": ("wolframite manganese tungstate", "MnWO4", "P2/c"),
}
for phase in p.phases():
    phase.export_CIF(str(work / phase_files[phase.name]))

x, yobs, weight, ycalc, ybkg, _ = [np.asarray(a, dtype=float) for a in h.data["data"][1]]
with (work / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(["two_theta_deg", "observed", "calculated", "difference", "background"])
    writer.writerows(zip(x, yobs, ycalc, yobs - ycalc, ybkg))

fracs = h.ComputeMassFracs()
phases = []
for phase in p.phases():
    frac, esd = fracs[phase.name]
    label, formula, space_group = phase_labels[phase.name]
    phases.append({
        "name": label,
        "formula": formula,
        "space_group": space_group,
        "cif_path": phase_files[phase.name],
        "weight_fraction": frac,
        "weight_fraction_esd": esd,
        "refined_cell": phase.get_cell(),
    })

result = {
    "phases": phases,
    "weight_fraction_basis": "normalized over modeled crystalline phases",
    "fit_statistics": {
        "Rwp_percent": h.residuals.get("wR"),
        "Rp_percent": h.residuals.get("R"),
        "Rexp_percent": h.residuals.get("wRmin"),
        "goodness_of_fit": rv.get("GOF"),
        "chi_squared": rv.get("chisq"),
        "n_observations": rv.get("Nobs"),
        "n_refined_variables": rv.get("Nvars"),
        "converged": rv.get("converged"),
        "final_delta_chi_squared_fraction": rv.get("DelChi2"),
        "maximum_shift_over_esd": rv.get("Max shft/sig"),
    },
    "project_path": "final.gpx",
    "profile_path": "fit.csv",
}
with (work / "result.json").open("w") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

print("RESULT " + json.dumps({
    "fractions": fracs,
    "fit_statistics": result["fit_statistics"],
    "cells": {phase.name: phase.get_cell() for phase in p.phases()},
    "sizes_um": {phase.name: phase.getHAPvalues(h)["Size"][1][0] for phase in p.phases()},
    "profile": {key: h.InstrumentParameters[key][1] for key in ("U", "V", "W", "X", "Y", "SH/L", "Zero")},
    "shift_um": h.SampleParameters["Shift"][0],
    "background_range": [float(np.min(ybkg)), float(np.max(ybkg))],
    "fraction_sum": sum(value[0] for value in fracs.values()),
}, sort_keys=True), flush=True)
