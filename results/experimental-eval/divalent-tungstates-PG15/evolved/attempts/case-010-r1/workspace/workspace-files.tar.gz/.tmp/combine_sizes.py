from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
target = work / ".tmp" / "inventory3_combined_sizes.gpx"
p = G2sc.G2Project(str(work / ".tmp" / "inventory3_neutral.gpx"), newgpx=str(target))
h = p.histogram(0)
starts = {"Mn2O3_Ia-3": 0.147, "MnWO4_monoclinic": 0.068}
for phase in p.phases():
    hap = phase.getHAPvalues(h)
    if phase.name in starts:
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = starts[phase.name]
        hap["Size"][2] = [True, False, False]
    else:
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]

for replay in range(4):
    p["Controls"]["data"]["max cyc"] = 12
    p["Controls"]["data"]["min dM/M"] = 1e-5
    p.refine()
    p.save()
    p = G2sc.G2Project(str(target))
    rv = p["Covariance"]["data"].get("Rvals", {})
    print("REPLAY " + json.dumps({
        "i": replay,
        "wR": p.histogram(0).get_wR(),
        "converged": rv.get("converged"),
        "delta_chi2": rv.get("DelChi2"),
        "max_shift_esd": rv.get("Max shft/sig"),
    }, sort_keys=True), flush=True)
    if replay >= 1 and rv.get("converged") and abs(rv.get("DelChi2", 1)) < 1e-5:
        break

h = p.histogram(0)
c = p["Covariance"]["data"]
vary = c.get("varyList", [])
cov = np.asarray(c.get("covMatrix", []))
corr = {}
if cov.size:
    den = np.sqrt(np.outer(np.diag(cov), np.diag(cov)))
    cm = np.divide(cov, den, out=np.zeros_like(cov), where=den > 0)
    for par in ("1:0:Size;i", "2:0:Size;i"):
        if par in vary:
            i = vary.index(par)
            ranked = sorted(((abs(cm[i, j]), vary[j], cm[i, j]) for j in range(len(vary)) if j != i), reverse=True)
            corr[par] = ranked[:5]

print("RESULT " + json.dumps({
    "wR": h.get_wR(),
    "fractions": h.ComputeMassFracs(),
    "sizes": {phase.name: phase.getHAPvalues(h)["Size"] for phase in p.phases()},
    "profile": {key: h.InstrumentParameters[key][1] for key in ("U", "W", "X")},
    "correlations": corr,
    "rvals": c.get("Rvals", {}),
}, sort_keys=True), flush=True)
