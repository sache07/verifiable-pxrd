#!/usr/bin/env python3
"""Build and stage a one-phase MnWO4 GSAS-II baseline."""

from __future__ import annotations

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
INST = ROOT / "instrument.instprm"
MNWO4 = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/02/1520200.cif"
)
OUT = ROOT / "trial_single.gpx"


def neutralize_hap(phase, hist_name: str) -> None:
    """Set phase-dependent nuisance broadening and intensity terms neutral."""
    hap = phase.data["Histograms"][hist_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [1.0e6, 1.0e6, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}


def status(tag: str, project, hist, phase) -> None:
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    print(
        "STATUS",
        tag,
        "residuals=", hist.residuals,
        "cell=", phase.get_cell(),
        "sample_scale=", sample["Scale"],
        "shift=", sample["Shift"],
        "profile=", {k: inst[k] for k in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
        "background=", hist.Background[0],
        flush=True,
    )


def run(project, hist, phase, tag: str) -> None:
    project.refine(makeBack=False)
    status(tag, project, hist, phase)
    project.save(ROOT / f"trial_single_{tag}.gpx")


def main() -> None:
    gpx = G2sc.G2Project(newgpx=str(OUT))
    hist = gpx.add_powder_histogram(str(PATTERN), str(INST))
    phase = gpx.add_phase(
        str(MNWO4), phasename="MnWO4", histograms=[hist], fmthint="CIF"
    )
    gpx.set_Controls("cycles", 8)

    # Reflection geometry and source are known from metadata. Keep only one
    # angular correction (specimen shift), and neutralize unused corrections.
    hist.SampleParameters["Scale"] = [1.0, True]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    neutralize_hap(phase, hist.name)

    # Use a low-order smooth background. V is fixed at zero so U/W/X form a
    # compact nonnegative baseline profile; source ratio is fixed to metadata.
    hist.InstrumentParameters["U"] = [2.0, 2.0, False]
    hist.InstrumentParameters["V"] = [0.0, 0.0, False]
    hist.InstrumentParameters["W"] = [5.0, 5.0, False]
    hist.InstrumentParameters["X"] = [0.0, 0.0, False]
    hist.InstrumentParameters["Y"] = [0.0, 0.0, False]
    hist.InstrumentParameters["Z"] = [0.0, 0.0, False]
    hist.InstrumentParameters["SH/L"] = [0.002, 0.002, False]
    hist.InstrumentParameters["I(L2)/I(L1)"] = [0.5, 0.5, False]
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 6}}
    )
    status("initial", gpx, hist, phase)

    run(gpx, hist, phase, "01_scale_background")

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run(gpx, hist, phase, "02_shift")

    phase.set_refinements({"Cell": True})
    run(gpx, hist, phase, "03_cell")

    hist.set_refinements({"Instrument Parameters": ["W"]})
    run(gpx, hist, phase, "04_W")

    hist.set_refinements({"Instrument Parameters": ["U"]})
    run(gpx, hist, phase, "05_UW")

    hist.set_refinements({"Instrument Parameters": ["X"]})
    run(gpx, hist, phase, "06_UWX")

    gpx.save(OUT)


if __name__ == "__main__":
    main()
