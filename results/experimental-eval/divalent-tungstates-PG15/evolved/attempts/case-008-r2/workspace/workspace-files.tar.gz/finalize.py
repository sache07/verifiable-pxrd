#!/usr/bin/env python3
"""Replay the accepted GSAS-II model and export the submitted results."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
START = ROOT / "trial_cation_coords.gpx"
FINAL = ROOT / "final.gpx"
FIT = ROOT / "fit.csv"
RESULT = ROOT / "result.json"
REPORT = ROOT / "report.md"


def neutralize_hap(hap: dict, keep_strain: bool) -> None:
    """Keep only the accepted WO3 isotropic-strain term phase dependent."""
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 1.0e6, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    if not keep_strain:
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
    else:
        hap["Mustrain"][2] = [True, False, False]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}


def enforce_accepted_model(project: G2sc.G2Project) -> None:
    """Remove every trial term that was not retained in the final model."""
    hist = project.histograms()[0]
    hist.data["Limits"][1] = list(hist.data["Limits"][0])

    sample = hist.SampleParameters
    sample["Scale"][1] = True
    sample["Shift"][1] = True
    sample["Transparency"] = [0.0, False]
    sample["DisplaceX"] = [0.0, False]
    sample["DisplaceY"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"][1] = True

    inst = hist.InstrumentParameters
    for key, value in (
        ("Zero", 0.0),
        ("V", 0.0),
        ("Y", 0.0),
        ("Z", 0.0),
        ("SH/L", 0.002),
        ("Polariz.", 0.5),
        ("I(L2)/I(L1)", 0.5),
    ):
        inst[key][1] = value
        inst[key][2] = False
    for key in ("U", "W", "X"):
        inst[key][2] = True

    background = hist.data["Background"]
    background[0][0] = "chebyschev-1"
    background[0][1] = True
    background[0][2] = 6
    background[1]["nDebye"] = 0
    background[1]["debyeTerms"] = []
    background[1]["nPeaks"] = 0
    background[1]["peaksList"] = []

    phases = {phase.name: phase for phase in project.phases()}
    mn = phases["MnWO4"]
    wo3 = phases["WO3_mono_1528915"]
    mn.data["General"]["Cell"][0] = True
    wo3.data["General"]["Cell"][0] = True
    mn.data["Atoms"][0][2] = "X"
    mn.data["Atoms"][1][2] = "X"
    for atom in mn.data["Atoms"][2:]:
        atom[2] = " "
    for atom in wo3.data["Atoms"]:
        atom[2] = ""

    mn_hap = mn.data["Histograms"][hist.name]
    wo3_hap = wo3.data["Histograms"][hist.name]
    mn_hap["Scale"] = [1.0, False]
    wo3_hap["Scale"][1] = True
    neutralize_hap(mn_hap, keep_strain=False)
    neutralize_hap(wo3_hap, keep_strain=True)

    project.set_Controls("cycles", 20)


def replay() -> G2sc.G2Project:
    """Refine, save, reopen, and replay the full pattern."""
    project = G2sc.G2Project(str(START), newgpx=str(FINAL))
    enforce_accepted_model(project)
    for cycle in range(3):
        project.refine(makeBack=False)
        project.save(FINAL)
        rvals = project["Covariance"]["data"]["Rvals"]
        print(
            f"replay {cycle + 1}: Rwp={rvals['Rwp']:.8f}% "
            f"GOF={rvals['GOF']:.6f} converged={rvals['converged']} "
            f"max_shift/esd={rvals['Max shft/sig']:.5g}"
        )
        if cycle < 2:
            project = G2sc.G2Project(str(FINAL))
            enforce_accepted_model(project)
    project.save(FINAL)
    return G2sc.G2Project(str(FINAL))


def get_phase_results(project: G2sc.G2Project) -> tuple[list[dict], dict]:
    hist = project.histograms()[0]
    fractions = hist.ComputeMassFracs()
    cov = project["Covariance"]["data"]
    dep = cov["depSigDict"]
    phase_specs = (
        ("MnWO4", "MnWO4 (wolframite)", "MnWO4", "P 2/c", 13, "MnWO4.cif"),
        (
            "WO3_mono_1528915",
            "WO3 (monoclinic)",
            "WO3",
            "P 21/n",
            14,
            "WO3.cif",
        ),
    )
    rows = []
    for index, (internal, name, formula, spg, number, cif_name) in enumerate(
        phase_specs
    ):
        phase = next(item for item in project.phases() if item.name == internal)
        fraction, fraction_esd = fractions[internal]
        cell = phase.get_cell()
        rows.append(
            {
                "name": name,
                "formula": formula,
                "space_group": spg,
                "space_group_number": number,
                "cif_path": cif_name,
                "weight_fraction": float(fraction),
                "weight_fraction_standard_uncertainty": float(fraction_esd),
                "cell_angstrom_degrees": {
                    "a": float(cell["length_a"]),
                    "b": float(cell["length_b"]),
                    "c": float(cell["length_c"]),
                    "alpha": float(cell["angle_alpha"]),
                    "beta": float(cell["angle_beta"]),
                    "gamma": float(cell["angle_gamma"]),
                    "volume_angstrom_cubed": float(cell["volume"]),
                },
                "bragg_r_f_percent": float(hist.residuals[f"{index}:0:Rf"]),
                "bragg_r_f_squared_percent": float(
                    hist.residuals[f"{index}:0:Rf^2"]
                ),
                "reflections": int(hist.residuals[f"{index}:0:Nref"]),
            }
        )
    rvals = cov["Rvals"]
    fit_stats = {
        "r_wp_percent": float(rvals["Rwp"]),
        "r_p_percent": float(hist.residuals["R"]),
        "r_exp_percent": float(hist.residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_parameters": int(rvals["Nvars"]),
        "background_r_percent": float(hist.residuals["Rb"]),
        "weighted_background_r_percent": float(hist.residuals["wRb"]),
        "converged": bool(rvals["converged"]),
    }
    assert math.isclose(sum(row["weight_fraction"] for row in rows), 1.0, abs_tol=1e-10)
    assert dep["0:0:WgtFrac"][0] == fractions["MnWO4"][0]
    assert dep["1:0:WgtFrac"][0] == fractions["WO3_mono_1528915"][0]
    return rows, fit_stats


def export_outputs(project: G2sc.G2Project) -> tuple[list[dict], dict]:
    phases = {phase.name: phase for phase in project.phases()}
    phases["MnWO4"].export_CIF(str(ROOT / "MnWO4.cif"))
    phases["WO3_mono_1528915"].export_CIF(str(ROOT / "WO3.cif"))

    hist = project.histograms()[0]
    profile = np.ma.filled(hist.data["data"][1], np.nan)
    with FIT.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_observed_minus_calculated_counts",
                "background_counts",
            ]
        )
        for x, obs, calc, diff, background in zip(
            profile[0], profile[1], profile[3], profile[5], profile[4]
        ):
            writer.writerow(
                [
                    format(float(x), ".15g"),
                    format(float(obs), ".15g"),
                    format(float(calc), ".15g"),
                    format(float(diff), ".15g"),
                    format(float(background), ".15g"),
                ]
            )

    phase_rows, fit_stats = get_phase_results(project)
    result = {
        "phases": phase_rows,
        "crystalline_weight_fraction_basis": (
            "normalized over the modeled crystalline phases; no amorphous fraction "
            "or absolute phase content was determined"
        ),
        "profile_path": "fit.csv",
        "project_path": "final.gpx",
        "difference_definition": "observed - calculated",
        "fit_statistics": fit_stats,
    }
    RESULT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return phase_rows, fit_stats


def write_report(project: G2sc.G2Project, phases: list[dict], stats: dict) -> None:
    hist = project.histograms()[0]
    mn, wo3 = phases
    sample = hist.SampleParameters
    inst = hist.InstrumentParameters
    wo3_hap = next(
        phase for phase in project.phases() if phase.name == "WO3_mono_1528915"
    ).data["Histograms"][hist.name]
    mn_atoms = next(phase for phase in project.phases() if phase.name == "MnWO4").atoms()
    text = f"""# Crystalline phase analysis

## Result

The modeled crystalline material is **{100 * mn['weight_fraction']:.2f} wt% MnWO4** (wolframite, P 2/c) and **{100 * wo3['weight_fraction']:.2f} wt% monoclinic WO3** (P 21/n). The covariance standard uncertainty is {100 * wo3['weight_fraction_standard_uncertainty']:.2f} wt% for either fraction, but the trace-phase amount is profile-model sensitive; a more realistic statement is about **{100 * wo3['weight_fraction']:.1f} +/- 1.0 wt% WO3** and the complementary MnWO4 fraction. Fractions are normalized only over these modeled crystalline phases. No amorphous fraction can be obtained without an internal standard.

The final full-range fit has Rwp = {stats['r_wp_percent']:.3f}%, Rp = {stats['r_p_percent']:.3f}%, Rexp = {stats['r_exp_percent']:.3f}%, and GOF = {stats['goodness_of_fit']:.3f} ({stats['n_observations']} points, {stats['n_refined_parameters']} variables). The fit is converged, but GOF above one and correlated residuals show that it is not noise limited.

## Evidence and structural models

MnO + WO3 heated at 900 C gives the expected 1:1 wolframite chemistry, and the dominant peak positions and intensities form a coherent P 2/c MnWO4 pattern across low, middle, and high angle. Both retained models are fully occupied and contain no occupational disorder. COD 1520200 supplied the exact-composition topology; although that record was measured at 2.4 GPa, the cell was fully refined to a = {mn['cell_angstrom_degrees']['a']:.6f}, b = {mn['cell_angstrom_degrees']['b']:.6f}, c = {mn['cell_angstrom_degrees']['c']:.6f} A and beta = {mn['cell_angstrom_degrees']['beta']:.5f} degrees. Ambient wolframite analogues were also screened and support the topology. Refined Mn y = {mn_atoms[0].coordinates[1]:.6f} and W y = {mn_atoms[1].coordinates[1]:.6f}; the resulting Mn-O (2.10-2.27 A) and W-O (1.80-2.13 A) octahedra are physical. Oxygen coordinates and displacement parameters remain at source values because unconstrained oxygen refinement produced implausible bonds.

Residual families near 23.45, 24.68, 33.58, and 34.45 degrees 2theta support residual room-temperature monoclinic WO3. COD 1528915 fit better than alternate monoclinic, triclinic, orthorhombic, and high-pressure WO3 records. Its cell refined to a = {wo3['cell_angstrom_degrees']['a']:.5f}, b = {wo3['cell_angstrom_degrees']['b']:.5f}, c = {wo3['cell_angstrom_degrees']['c']:.5f} A and beta = {wo3['cell_angstrom_degrees']['beta']:.4f} degrees. At only ~3 wt%, its atomic coordinates cannot be determined reliably and remain fixed to the literature model.

## Refinement choices and uncertainty

The Cu Kalpha1/Kalpha2 wavelengths and 0.5 intensity ratio were fixed from metadata. Poisson weights were inferred from the raw counts because pointwise uncertainties were not supplied. The accepted common baseline uses a six-coefficient Chebyshev background, one specimen-shift correction ({sample['Shift'][0]:.1f} micrometres), nonnegative U/W/X ({inst['U'][1]:.3f}/{inst['W'][1]:.3f}/{inst['X'][1]:.3f}), and one low-angle surface/footprint term. Isolated MnWO4 families at low, middle, and high angle show no systematic position drift or persistent hkl-dependent width pattern. Extra SH/L asymmetry, refined polarization, texture, phase size, and MnWO4 strain trials were unsupported or unstable and were pruned; no anisotropic broadening term was justified. WO3 isotropic microstrain was replay-stable at {wo3_hap['Mustrain'][1][0]:.0f} microstrain and was retained. Removing it lowers the inferred WO3 fraction to about 2.3 wt%, so this approximately 1 wt% model spread dominates the formal fraction uncertainty.

MnO, Mn2O3, Mn3O4, Mn3WO6, WO2, and W18O49 were re-challenged after establishing the common profile. Their trial scales were zero or below about 0.6 wt%, but no coherent diagnostic peak family was present; they are therefore omitted rather than claimed as determined phases. A sub-percent contribution from one of these phases cannot be excluded reliably.
"""
    REPORT.write_text(text, encoding="utf-8")


def verify_exports() -> None:
    """Verify the exported profile and fractions against a clean project reopen."""
    project = G2sc.G2Project(str(FINAL))
    hist = project.histograms()[0]
    profile = np.ma.filled(hist.data["data"][1], np.nan)
    exported = np.genfromtxt(FIT, delimiter=",", names=True)
    comparisons = (
        (exported["two_theta_deg"], profile[0]),
        (exported["observed_counts"], profile[1]),
        (exported["calculated_counts"], profile[3]),
        (exported["difference_observed_minus_calculated_counts"], profile[5]),
        (exported["background_counts"], profile[4]),
    )
    for exported_values, project_values in comparisons:
        assert np.allclose(exported_values, project_values, rtol=1e-12, atol=1e-9)

    result = json.loads(RESULT.read_text(encoding="utf-8"))
    fractions = hist.ComputeMassFracs()
    assert math.isclose(
        result["phases"][0]["weight_fraction"], fractions["MnWO4"][0], abs_tol=1e-12
    )
    assert math.isclose(
        result["phases"][1]["weight_fraction"],
        fractions["WO3_mono_1528915"][0],
        abs_tol=1e-12,
    )
    assert result["fit_statistics"]["r_wp_percent"] == hist.residuals["wR"]
    print("verified: final.gpx, CIFs, fit.csv, and result.json agree")


def main() -> None:
    project = replay()
    phases, stats = export_outputs(project)
    write_report(project, phases, stats)
    verify_exports()


if __name__ == "__main__":
    main()
