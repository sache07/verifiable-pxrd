#!/usr/bin/env python3
"""Residual-led candidate phase tests against a common GSAS-II baseline."""

from __future__ import annotations

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = [
    ("WO3_mono_1528915", "1528915", 0.01),
    ("WO3_mono_2311041", "2311041", 0.01),
    ("WO3_tric_2106293", "2106293", 0.01),
    ("WO3_old_1010618", "1010618", 0.01),
    ("WO3_ortho_2107312", "2107312", 0.01),
    ("MnO_1514231", "1514231", 0.02),
    ("Mn2O3_1514230", "1514230", 0.01),
    ("Mn3O4_9001963", "9001963", 0.01),
    ("Mn3WO6_2002703", "2002703", 0.01),
    ("W18O49_1528166", "1528166", 0.005),
]


def neutralize_hap(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [1.0e6, 1.0e6, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}


def direct_mass_fracs(project, hist_name: str) -> dict[str, float]:
    vals = {}
    denom = 0.0
    for phase in project.phases():
        hap = phase.data["Histograms"][hist_name]
        value = phase.data["General"]["Mass"] * hap["Scale"][0]
        vals[phase.name] = value
        denom += value
    return {key: value / denom for key, value in vals.items()}


def main() -> None:
    for name, cod_id, start_scale in CANDIDATES:
        out = ROOT / f"screen_{name}.gpx"
        gpx = G2sc.G2Project(str(ROOT / "trial_single.gpx"), newgpx=str(out))
        gpx.set_Controls("cycles", 12)
        hist = gpx.histogram(0)
        phase = gpx.add_phase(
            str(cif_path(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        neutralize_hap(phase, hist.name)
        phase.data["Histograms"][hist.name]["Scale"] = [start_scale, True]
        try:
            gpx.refine(makeBack=False)
            gpx.save()
            print(
                "CANDIDATE",
                name,
                "COD", cod_id,
                "Rwp", hist.residuals.get("wR"),
                "phase_scale", phase.data["Histograms"][hist.name]["Scale"],
                "mass_fracs", direct_mass_fracs(gpx, hist.name),
                "cell", phase.get_cell(),
                flush=True,
            )
        except Exception as exc:
            print("CANDIDATE", name, "FAILED", repr(exc), flush=True)


if __name__ == "__main__":
    main()
