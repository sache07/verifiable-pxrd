#!/usr/bin/env python3
"""Fit physically plausible ambient WO3 records under one common baseline."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
CANDIDATES = {
    "1528915_monoclinic_legacy": ROOT / "1/52/89/1528915.cif",
    "2311041_monoclinic_neutron": ROOT / "2/31/10/2311041.cif",
    "2106293_triclinic": ROOT / "2/10/62/2106293.cif",
}
CAWO4 = ROOT / "7/21/92/7219229.cif"
CALCITE = ROOT / "1/54/73/1547347.cif"


def neutralize_phase_profile(phase, hist) -> None:
    hap = phase.getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1000.0
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def fit_candidate(label: str, wo3_cif: Path) -> dict:
    out = Path(".tmp") / f"screen_{label}.gpx"
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram("pattern.xye", "instrument.instprm", fmthint="xye")
    project.add_phase(str(CAWO4), phasename="CaWO4_scheelite", histograms=[hist], fmthint="CIF")
    project.add_phase(str(wo3_cif), phasename="WO3", histograms=[hist], fmthint="CIF")
    project.add_phase(str(CALCITE), phasename="CaCO3_calcite", histograms=[hist], fmthint="CIF")
    project["Controls"]["data"]["max cyc"] = 8
    project["Controls"]["data"]["min dM/M"] = 0.001

    hist.SampleParameters["Scale"][1] = False
    for key in ("SurfRoughA", "SurfRoughB", "Transparency", "Absorption", "DisplaceX", "DisplaceY", "Shift"):
        if key in hist.SampleParameters:
            hist.SampleParameters[key][0] = 0.0
            hist.SampleParameters[key][1] = False
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)"):
        hist.InstrumentParameters[key][2] = False
    hist.InstrumentParameters["U"][1] = 1.0
    hist.InstrumentParameters["V"][1] = 0.0
    hist.InstrumentParameters["W"][1] = 25.0
    hist.InstrumentParameters["X"][1] = 10.0
    hist.InstrumentParameters["Y"][1] = 0.0
    hist.InstrumentParameters["Z"][1] = 0.0
    hist.InstrumentParameters["SH/L"][1] = 0.002
    hist.InstrumentParameters["Zero"][1] = 0.29
    hist.InstrumentParameters["Zero"][2] = False
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": [1100.0, -900.0, 700.0, -450.0, 200.0, -50.0],
            }
        }
    )
    for phase in project.phases():
        neutralize_phase_profile(phase, hist)
        phase.set_HAP_refinements({"Scale": True})
    project.save()

    # Re-establish the common nuisance model after each source change.
    project.refine(printFile=str(out.with_suffix(".lst")))
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine(printFile=str(out.with_suffix(".lst")))
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine(printFile=str(out.with_suffix(".lst")))
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    project.refine(printFile=str(out.with_suffix(".lst")))
    project.save()

    # Save, reopen and replay over the original full limits.
    project = G2sc.G2Project(str(out))
    project["Controls"]["data"]["max cyc"] = 8
    project.refine(printFile=str(out.with_suffix(".replay.lst")))
    project.save()
    hist = project.histogram(0)
    rvals = project["Covariance"]["data"].get("Rvals", {})
    return {
        "candidate": label,
        "project": str(out),
        "rwp_percent": hist.get_wR(),
        "gof": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "zero_deg": hist.InstrumentParameters["Zero"][1],
        "U": hist.InstrumentParameters["U"][1],
        "W": hist.InstrumentParameters["W"][1],
        "X": hist.InstrumentParameters["X"][1],
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "mass_fractions": hist.ComputeMassFracs(),
    }


if __name__ == "__main__":
    results = [fit_candidate(label, path) for label, path in CANDIDATES.items()]
    print("SCREEN_RESULTS=" + json.dumps(results, indent=2))
