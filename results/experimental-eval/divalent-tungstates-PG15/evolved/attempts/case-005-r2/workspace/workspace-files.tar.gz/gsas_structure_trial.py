#!/usr/bin/env python3
"""Test limited, physically interpretable atomic-coordinate refinements."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc

from gsas_screen import ROOT, snapshot


def atomic_state(gpx) -> dict:
    state = {}
    for phase in gpx.phases():
        state[phase.name] = [
            {
                "label": atom.label,
                "type": atom.type,
                "coordinates": list(atom.coordinates),
                "occupancy": atom.occupancy,
                "uiso": atom.uiso,
                "refinement_flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ]
    return state


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "trial",
        choices=("thermal", "w_coords", "co_o", "both", "w_coords_orig", "co_o_orig", "both_orig"),
    )
    args = parser.parse_args()

    source = ROOT / "profile_mono_alt_strain.gpx"
    output = ROOT / f"structure_{args.trial}.gpx"
    G2sc.SetPrintLevel("warn")
    gpx = G2sc.G2Project(str(source), newgpx=str(output))
    wo3, co3o4 = gpx.phases()

    use_parent_adp = args.trial.endswith("_orig")
    # In the thermal trials, test conservative fixed room-temperature values
    # because the neutron parent reports zeros. Separate *_orig trials retain
    # the parent values so coordinate support is judged independently.
    for atom in wo3.atoms():
        if not use_parent_adp:
            atom.uiso = 0.005 if atom.element == "W" else 0.010
        atom.refinement_flags = " "
    for atom in co3o4.atoms():
        atom.refinement_flags = " "

    if args.trial in ("w_coords", "both", "w_coords_orig", "both_orig"):
        for atom in wo3.atoms():
            if atom.element == "W":
                atom.refinement_flags = "X"
    if args.trial in ("co_o", "both", "co_o_orig", "both_orig"):
        for atom in co3o4.atoms():
            if atom.element == "O":
                atom.refinement_flags = "X"

    gpx.set_Controls("cycles", 10)
    history = []
    for index in range(3):
        gpx.refine()
        item = snapshot(gpx, f"replay_{index + 1}")
        item["atoms"] = atomic_state(gpx)
        history.append(item)
    gpx.save()
    (ROOT / f"structure_{args.trial}.json").write_text(json.dumps(history, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
