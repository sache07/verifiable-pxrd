#!/usr/bin/env python3
"""Challenge common intensity corrections and simple March-Dollase textures."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc

from gsas_screen import ROOT, snapshot


TEXTURE_TRIALS = {
    "tex_wo3_100": (0, [1, 0, 0]),
    "tex_wo3_010": (0, [0, 1, 0]),
    "tex_wo3_001": (0, [0, 0, 1]),
    "tex_wo3_101": (0, [1, 0, 1]),
    "tex_wo3_10m1": (0, [1, 0, -1]),
    "tex_wo3_110": (0, [1, 1, 0]),
    "tex_wo3_111": (0, [1, 1, 1]),
    "tex_co3o4_100": (1, [1, 0, 0]),
    "tex_co3o4_110": (1, [1, 1, 0]),
    "tex_co3o4_111": (1, [1, 1, 1]),
}


def trial_state(gpx) -> dict:
    hist = gpx.histogram(0)
    cov = gpx.data.get("Covariance", {}).get("data", {})
    variables = {
        str(name): {"value": float(value), "sigma": float(sigma)}
        for name, value, sigma in zip(
            cov.get("varyList", []), cov.get("variables", []), cov.get("sig", [])
        )
    }
    return {
        "polarization": list(hist.InstrumentParameters["Polariz."]),
        "surface_roughness": {
            "A": list(hist.SampleParameters["SurfRoughA"]),
            "B": list(hist.SampleParameters["SurfRoughB"]),
        },
        "preferred_orientation": {
            phase.name: list(phase.data["Histograms"][hist.name]["Pref.Ori."][:4])
            for phase in gpx.phases()
        },
        "variables": variables,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "trial",
        choices=("polariz", "roughness_b", "polariz_roughness_b", "asymmetry", *TEXTURE_TRIALS),
    )
    parser.add_argument("--source", default="structure_co_o_orig.gpx")
    parser.add_argument("--label")
    parser.add_argument(
        "--keep-corrections",
        action="store_true",
        help="retain polarization/roughness settings already present in the source project",
    )
    args = parser.parse_args()

    label = args.label or args.trial
    output = ROOT / f"intensity_{label}.gpx"
    G2sc.SetPrintLevel("warn")
    gpx = G2sc.G2Project(str(ROOT / args.source), newgpx=str(output))
    hist = gpx.histogram(0)

    # Begin every comparison from a neutral intensity model.
    if not args.keep_corrections:
        hist.InstrumentParameters["Polariz."][2] = False
        hist.SampleParameters["SurfRoughA"][:] = [0.0, False]
        hist.SampleParameters["SurfRoughB"][:] = [0.0, False]
    for phase in gpx.phases():
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = False

    if args.trial in ("polariz", "polariz_roughness_b"):
        hist.InstrumentParameters["Polariz."][2] = True
        gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
        gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")
    if args.trial in ("roughness_b", "polariz_roughness_b"):
        # With A fixed at zero, B=0 is the exactly nested neutral model.
        hist.SampleParameters["SurfRoughB"][:] = [1.0e-5, True]
        gpx.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
        gpx.set_Controls("parmMax", 1.0, ":0:SurfRoughB")
    if args.trial == "asymmetry":
        hist.InstrumentParameters["SH/L"][2] = True
        gpx.set_Controls("parmMin", 0.0005, ":0:SH/L")
        gpx.set_Controls("parmMax", 1.0, ":0:SH/L")
    if args.trial in TEXTURE_TRIALS:
        phase_index, axis = TEXTURE_TRIALS[args.trial]
        po = gpx.phases()[phase_index].data["Histograms"][hist.name]["Pref.Ori."]
        po[1] = 1.0
        po[2] = True
        po[3] = axis
        gpx.set_Controls("parmMin", 0.2, f"{phase_index}:0:MD")
        gpx.set_Controls("parmMax", 5.0, f"{phase_index}:0:MD")

    gpx.set_Controls("cycles", 10)
    history = []
    for index in range(3):
        gpx.refine()
        item = snapshot(gpx, f"replay_{index + 1}")
        item["trial_state"] = trial_state(gpx)
        history.append(item)
    gpx.save()
    (ROOT / f"intensity_{label}.json").write_text(
        json.dumps(history, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    main()
