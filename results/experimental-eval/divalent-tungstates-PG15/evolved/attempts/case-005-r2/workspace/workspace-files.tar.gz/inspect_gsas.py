#!/usr/bin/env python3
"""Create a minimal GSAS-II project and print its initialized state."""

from pprint import pprint
from pathlib import Path

import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
WO3 = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif")

G2sc.SetPrintLevel("warn")
gpx = G2sc.G2Project(newgpx=str(ROOT / "scratch.gpx"))
hist = gpx.add_powder_histogram(
    str(ROOT / "pattern.xye"), str(ROOT / "instrument.instprm"), fmthint="xye"
)
phase = gpx.add_phase(str(WO3), phasename="WO3_mP", histograms=[hist], fmthint="CIF")
gpx.save()

print("HIST", hist.name)
print("INSTRUMENT")
pprint(hist.InstrumentParameters)
print("SAMPLE")
pprint(hist.SampleParameters)
print("BACKGROUND")
pprint(hist.Background)
print("LIMITS")
pprint(hist.data["Limits"])
print("HAP")
pprint(phase.data["Histograms"][hist.name])
print("GENERAL")
pprint({k: phase.data["General"][k] for k in ("Name", "Cell", "AtomPtrs", "SGData", "Mass")})
print("ATOMS")
pprint(phase.data["Atoms"])
