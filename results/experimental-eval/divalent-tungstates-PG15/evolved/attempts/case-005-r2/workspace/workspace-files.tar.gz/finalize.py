#!/usr/bin/env python3
"""Freeze, replay, and export the selected GSAS-II refinement."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "intensity_roughness_b.gpx"
FINAL = ROOT / "final.gpx"


def prune_to_selected_model(gpx: G2sc.G2Project) -> None:
    """Remove every tested-but-rejected term and make the final flags explicit."""
    hist = gpx.histogram(0)
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    hist.Background[0][1] = True

    inst = hist.InstrumentParameters
    for key, value in inst.items():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], (bool, np.bool_)):
            value[2] = key in ("U", "W", "X")
    inst["Polariz."][1:] = [0.5, False]
    inst["SH/L"][1:] = [0.002, False]
    inst["Zero"][1:] = [0.0, False]
    for key in ("V", "Y", "Z"):
        inst[key][1:] = [0.0, False]

    sample = hist.SampleParameters
    sample["Scale"][:] = [1.0, False]
    sample["Shift"][1] = True
    sample["Transparency"][:] = [0.0, False]
    sample["SurfRoughA"][:] = [0.0, False]
    sample["SurfRoughB"][1] = True
    for key in ("Absorption", "DisplaceX", "DisplaceY"):
        if key in sample and isinstance(sample[key], list) and len(sample[key]) == 2:
            sample[key][1] = False

    for p_index, phase in enumerate(gpx.phases()):
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True

        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 0.5]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])

        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2][:] = [p_index == 0, False, False]
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        if p_index != 0:
            hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]

        hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Extinction"][:] = [0.0, False]
        hap["Babinet"]["BabA"][:] = [0.0, False]
        hap["Babinet"]["BabU"][:] = [0.0, False]

        for atom in phase.atoms():
            atom.refinement_flags = "X" if p_index == 1 and atom.element == "O" else " "


def compact_state(gpx: G2sc.G2Project) -> dict:
    hist = gpx.histogram(0)
    cov = gpx.data.get("Covariance", {}).get("data", {})
    return {
        "Rwp_percent": float(hist.residuals["wR"]),
        "GOF": float(cov.get("Rvals", {}).get("GOF", np.nan)),
        "max_shift_over_esd": float(cov.get("Rvals", {}).get("Max shft/sig", np.nan)),
        "cells": {p.name: p.get_cell() for p in gpx.phases()},
        "scales": {
            p.name: float(p.data["Histograms"][hist.name]["Scale"][0]) for p in gpx.phases()
        },
        "weight_fractions": {
            key: [float(value), float(esd)] for key, (value, esd) in hist.ComputeMassFracs().items()
        },
    }


def covariance_summary(gpx: G2sc.G2Project) -> dict:
    cov = gpx.data["Covariance"]["data"]
    names = [str(value) for value in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    strong = []
    if matrix.size:
        sigma = np.sqrt(np.diag(matrix))
        corr = matrix / np.outer(sigma, sigma)
        for i in range(len(names)):
            for j in range(i):
                if abs(corr[i, j]) >= 0.95:
                    strong.append(
                        {"parameter_1": names[j], "parameter_2": names[i], "correlation": float(corr[i, j])}
                    )
    return {"refined_parameters": names, "correlations_abs_ge_0.95": strong}


def main() -> None:
    G2sc.SetPrintLevel("warn")

    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    prune_to_selected_model(gpx)
    gpx.set_Controls("cycles", 12)
    gpx.save()

    replay_history = []
    # Reopen before each replay so this checks the serialized project, not only
    # an in-memory model.
    for index in range(2):
        replay = G2sc.G2Project(str(FINAL))
        replay.histogram(0).data["Limits"][1] = list(replay.histogram(0).data["Limits"][0])
        replay.refine()
        replay.save()
        state = compact_state(replay)
        state["replay"] = index + 1
        replay_history.append(state)
        print(json.dumps(state, default=float))

    final = G2sc.G2Project(str(FINAL))
    hist = final.histogram(0)
    state = compact_state(final)
    rvals = final.data["Covariance"]["data"]["Rvals"]
    if not rvals.get("converged", False):
        raise RuntimeError("Final GSAS-II replay did not converge")
    if state["max_shift_over_esd"] >= 0.1:
        raise RuntimeError(f"Final replay is not stable: max shift/esd={state['max_shift_over_esd']}")

    cif_paths = [ROOT / "phase_1_WO3.cif", ROOT / "phase_2_Co3O4.cif"]
    for phase, path in zip(final.phases(), cif_paths):
        phase.export_CIF(str(path))

    profile = hist.data["data"][1]
    x, observed, weights, calculated, background, difference = [
        np.asarray(column, dtype=float) for column in profile
    ]
    if not np.allclose(observed - calculated, difference, rtol=0.0, atol=1.0e-8):
        raise RuntimeError("GSAS-II difference profile is inconsistent with observed-calculated")
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        for row in zip(x, observed, calculated, difference, background):
            writer.writerow([f"{value:.10f}" for value in row])

    mass_fracs = hist.ComputeMassFracs()
    phase_metadata = [
        {
            "name": "tungsten trioxide",
            "formula": "WO3",
            "internal_phase_name": final.phases()[0].name,
            "space_group": final.phases()[0].data["General"]["SGData"]["SpGrp"],
            "cif_path": cif_paths[0].name,
            "source_structure": "COD 2311041",
        },
        {
            "name": "cobalt oxide (spinel)",
            "formula": "Co3O4",
            "internal_phase_name": final.phases()[1].name,
            "space_group": final.phases()[1].data["General"]["SGData"]["SpGrp"],
            "cif_path": cif_paths[1].name,
            "source_structure": "COD 9005896",
        },
    ]
    for phase, metadata in zip(final.phases(), phase_metadata):
        fraction, esd = mass_fracs[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        metadata.update(
            {
                "weight_fraction": float(fraction),
                "weight_fraction_esd": float(esd),
                "cell": {key: float(value) for key, value in cell.items()},
                "cell_esd": {key: float(value) for key, value in cell_esd.items()},
                "phase_fit_statistics": {
                    "R_F_percent": float(hist.residuals[f"{phase.id}:0:Rf"]),
                    "R_F_squared_percent": float(hist.residuals[f"{phase.id}:0:Rf^2"]),
                    "reflection_count": int(hist.residuals[f"{phase.id}:0:Nref"]),
                },
            }
        )

    residuals = hist.residuals
    result = {
        "project_path": FINAL.name,
        "fit_profile_path": "fit.csv",
        "fraction_basis": "normalized over the modeled crystalline phases",
        "phases": phase_metadata,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "reduced_chi_squared": float(rvals["GOF"] ** 2),
            "chi_squared": float(rvals["chisq"]),
            "observations": int(rvals["Nobs"]),
            "refined_variables": int(rvals["Nvars"]),
            "max_shift_over_esd_final_replay": float(rvals["Max shft/sig"]),
            "Durbin_Watson": float(hist.data["data"][0]["Durbin-Watson"]),
        },
        "uncertainty_note": (
            "Weight-fraction esds are covariance-only. Alternate plausible angular-intensity "
            "corrections move the fractions by about 0.02 absolute, which is the more realistic "
            "systematic scale for this single-pattern analysis."
        ),
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    audit = {
        "source_project": SOURCE.name,
        "final_project": FINAL.name,
        "final_project_sha256": hashlib.sha256(FINAL.read_bytes()).hexdigest(),
        "replay_history": replay_history,
        "final_state": state,
        "covariance": covariance_summary(final),
        "files": {
            path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in [FINAL, *cif_paths, ROOT / "fit.csv", ROOT / "result.json"]
        },
    }
    (ROOT / "final_audit.json").write_text(json.dumps(audit, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
