#!/usr/bin/env python3
"""Compare common and phase-specific broadening models on the two-phase fit."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from gsas_screen import ROOT, snapshot


def reset_hap_broadening(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 0.5]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "trial",
        choices=("none", "wo3_size", "wo3_strain", "co3o4_size", "co3o4_strain", "wo3_size_strain"),
    )
    parser.add_argument("--source", default="screen_wo3_co3o4_alt.gpx")
    parser.add_argument("--label")
    args = parser.parse_args()

    source = ROOT / args.source
    label = args.label or args.trial
    output = ROOT / f"profile_{label}.gpx"
    G2sc.SetPrintLevel("warn")
    gpx = G2sc.G2Project(str(source), newgpx=str(output))
    hist = gpx.histogram(0)

    inst = hist.InstrumentParameters
    for key, val in {"U": 5.0, "V": 0.0, "W": 25.0, "X": 5.0, "Y": 0.0, "Z": 0.0}.items():
        inst[key][0] = inst[key][1] = val
        inst[key][2] = key in ("U", "W", "X")
    for key in ("U", "W", "X"):
        gpx.set_Controls("parmMin", 0.0, f":0:{key}")

    phase_list = gpx.phases()
    wo3_phase, co3o4_phase = phase_list[0], phase_list[1]
    for phase in phase_list:
        reset_hap_broadening(phase, hist.name)

    if args.trial in ("wo3_size", "wo3_size_strain"):
        hap = wo3_phase.data["Histograms"][hist.name]
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
    if args.trial in ("wo3_strain", "wo3_size_strain"):
        hap = wo3_phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True
    if args.trial == "co3o4_size":
        hap = co3o4_phase.data["Histograms"][hist.name]
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
    if args.trial == "co3o4_strain":
        hap = co3o4_phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True

    gpx.set_Controls("cycles", 10)
    history = []
    for index in range(3):
        gpx.refine()
        history.append(snapshot(gpx, f"replay_{index + 1}"))
    gpx.save()
    (ROOT / f"profile_{label}.json").write_text(json.dumps(history, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
