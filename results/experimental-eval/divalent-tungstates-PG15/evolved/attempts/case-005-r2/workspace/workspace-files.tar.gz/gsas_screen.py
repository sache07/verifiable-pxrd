#!/usr/bin/env python3
"""Run comparable, restrained GSAS-II screening refinements."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

CANDIDATES = {
    "wo3_mono": ("WO3_mP", COD_ROOT / "1/52/89/1528915.cif"),
    "wo3_mono_alt": ("WO3_mP_alt", COD_ROOT / "2/31/10/2311041.cif"),
    "wo3_tri": ("WO3_aP", COD_ROOT / "2/10/62/2106293.cif"),
    "wo3_ortho": ("WO3_oP", COD_ROOT / "2/10/73/2107312.cif"),
    "wo3_p21m": ("WO3_mP_small", COD_ROOT / "1/01/06/1010618.cif"),
    "co3o4": ("Co3O4_cF", COD_ROOT / "5/91/00/5910031.cif"),
    "co3o4_alt": ("Co3O4_cF", COD_ROOT / "9/00/58/9005896.cif"),
    "coo": ("CoO_cF", COD_ROOT / "1/54/16/1541662.cif"),
    "cowo4_co": ("CoWO4_mP_CoMoO4_parent", ROOT / "candidate_CoWO4_from_CoMoO4.cif"),
    "cowo4_fe": ("CoWO4_mP_FeWO4_parent", ROOT / "candidate_CoWO4_from_FeWO4.cif"),
}


def neutralize_hap(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1.0e6, 1.0e6, 0.5]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]
    hap["Scale"][1] = True


def configure_histogram(hist, correction: str) -> None:
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": [3100.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            }
        }
    )
    inst = hist.InstrumentParameters
    for name, value in {"U": 5.0, "V": 0.0, "W": 25.0, "X": 0.03, "Y": 0.0, "Z": 0.0, "SH/L": 0.002}.items():
        inst[name][0] = value
        inst[name][1] = value
        inst[name][2] = False
    inst["Zero"][0] = inst["Zero"][1] = 0.30 if correction == "zero" else 0.0
    inst["Zero"][2] = correction == "zero"

    sample = hist.SampleParameters
    sample["Scale"][:] = [1.0, False]
    sample["Shift"][:] = [-250.0 if correction == "shift" else 0.0, correction == "shift"]
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][:] = [0.0, False]


def snapshot(gpx, tag: str) -> dict:
    hist = gpx.histogram(0)
    cov = gpx.data.get("Covariance", {}).get("data", {})
    result = {
        "tag": tag,
        "residuals": dict(hist.residuals),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items() if k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "sample": {k: v[0] for k, v in hist.SampleParameters.items() if k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
        "background": list(hist.Background[0][3:]),
        "phases": [],
    }
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": list(hap["Size"][1]),
                "mustrain": list(hap["Mustrain"][1]),
            }
        )
    print(json.dumps(result, default=float))
    return result


def refine_step(gpx, tag: str, history: list[dict]) -> None:
    gpx.refine()
    history.append(snapshot(gpx, tag))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("candidates", nargs="+")
    parser.add_argument("--correction", choices=("shift", "zero"), default="shift")
    parser.add_argument("--profile", action="store_true", help="refine common U/W/X after cells")
    args = parser.parse_args()

    out = ROOT / f"screen_{args.name}.gpx"
    G2sc.SetPrintLevel("warn")
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "instrument.instprm"), fmthint="xye"
    )
    configure_histogram(hist, args.correction)

    for key in args.candidates:
        phase_name, path = CANDIDATES[key]
        phase = gpx.add_phase(str(path), phasename=phase_name, histograms=[hist], fmthint="CIF")
        neutralize_hap(phase, hist.name)

    gpx.set_Controls("cycles", 8)
    history: list[dict] = []
    refine_step(gpx, "background_scale_angle", history)

    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = True
    refine_step(gpx, "cells", history)

    if args.profile:
        hist.set_refinements({"Instrument Parameters": ["W"]})
        refine_step(gpx, "profile_W", history)
        hist.set_refinements({"Instrument Parameters": ["U", "X"]})
        refine_step(gpx, "profile_UWX", history)
        refine_step(gpx, "profile_UWX_replay", history)

    gpx.save()
    (ROOT / f"screen_{args.name}.json").write_text(json.dumps(history, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
