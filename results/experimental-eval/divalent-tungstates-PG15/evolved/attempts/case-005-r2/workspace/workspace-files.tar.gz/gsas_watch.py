#!/usr/bin/env python3
"""Re-challenge a chemically plausible weak phase under the clean profile."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc

from gsas_screen import CANDIDATES, ROOT, neutralize_hap, snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", choices=("cowo4_co", "cowo4_fe", "coo"))
    args = parser.parse_args()

    source = ROOT / "profile_mono_alt_strain.gpx"
    output = ROOT / f"watch_{args.candidate}.gpx"
    G2sc.SetPrintLevel("warn")
    gpx = G2sc.G2Project(str(source), newgpx=str(output))
    hist = gpx.histogram(0)
    phase_name, phase_path = CANDIDATES[args.candidate]
    phase = gpx.add_phase(str(phase_path), phasename=phase_name, histograms=[hist], fmthint="CIF")
    neutralize_hap(phase, hist.name)
    phase.data["Histograms"][hist.name]["Scale"][0] = 0.1
    phase.data["General"]["Cell"][0] = False

    gpx.set_Controls("cycles", 10)
    history = []
    for index in range(2):
        gpx.refine()
        history.append(snapshot(gpx, f"scale_trial_{index + 1}"))

    scale = phase.data["Histograms"][hist.name]["Scale"][0]
    if scale > 1.0e-5:
        phase.data["General"]["Cell"][0] = True
        gpx.refine()
        history.append(snapshot(gpx, "cell_trial"))

    gpx.save()
    (ROOT / f"watch_{args.candidate}.json").write_text(json.dumps(history, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
