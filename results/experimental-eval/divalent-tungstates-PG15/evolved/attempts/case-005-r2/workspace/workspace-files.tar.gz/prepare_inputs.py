#!/usr/bin/env python3
"""Prepare GSAS-II input data and physically screened candidate CIFs."""

from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_powder_data() -> None:
    data = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    # Point uncertainties were not supplied. Counting-statistical uncertainties
    # are the least assumptive choice for the original count data.
    sigma = np.sqrt(np.maximum(data[:, 1], 1.0))
    np.savetxt(
        ROOT / "pattern.xye",
        np.column_stack((data, sigma)),
        fmt=("%.8f", "%.8g", "%.8g"),
        header="2theta_deg intensity_counts sigma_counts",
    )


def write_cowo4_analogues() -> None:
    # No complete, machine-readable exact CoWO4 entry is available in the
    # supplied COD snapshot. Build two independent wolframite prototypes:
    # CoMoO4 -> CoWO4 (preserves the Co sublattice) and FeWO4 -> CoWO4.
    substitutions = [
        ("7205001", {"Mo": "W"}, "candidate_CoWO4_from_CoMoO4.cif"),
        ("1567215", {"Fe": "Co"}, "candidate_CoWO4_from_FeWO4.cif"),
    ]
    for cod_id, mapping, filename in substitutions:
        structure = Structure.from_file(cod_path(cod_id))
        structure.replace_species(mapping)
        CifWriter(structure, symprec=1e-5).write_file(ROOT / filename)


if __name__ == "__main__":
    write_powder_data()
    write_cowo4_analogues()
