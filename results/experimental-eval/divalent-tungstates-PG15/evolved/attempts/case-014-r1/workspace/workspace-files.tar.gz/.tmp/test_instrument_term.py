#!/usr/bin/env python3
"""Challenge one additional common instrumental profile term."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


G2sc.G2fil.G2SetPrintLevel("warn")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("term", choices=["U", "SH/L"])
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
    project.set_Controls("cycles", 15)
    hist = project.histogram(0)
    if args.term == "U":
        hist.InstrumentParameters["U"][1] = 5.0
    else:
        hist.InstrumentParameters["SH/L"][1] = 0.01
    hist.InstrumentParameters[args.term][2] = True

    project.save()
    project.do_refinements([{}])
    project.save()
    project = G2sc.G2Project(str(args.output.resolve()))
    project.set_Controls("cycles", 15)
    project.do_refinements([{}])
    project.save()

    hist = project.histogram(0)
    print(json.dumps({
        "term": args.term,
        "Rwp": hist.residuals["wR"],
        "instrument": {key: hist.InstrumentParameters[key] for key in ["U", "V", "W", "X", "SH/L"]},
        "mass_fractions": hist.ComputeMassFracs(),
    }, indent=2, default=str))


if __name__ == "__main__":
    main()
