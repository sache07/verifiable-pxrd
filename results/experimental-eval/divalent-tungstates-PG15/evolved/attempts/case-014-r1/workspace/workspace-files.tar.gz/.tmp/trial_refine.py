#!/usr/bin/env python3
"""Small GSAS-II trial runner used to compare physically plausible phase records."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

G2sc.G2fil.G2SetPrintLevel("none")


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def run(cod_ids: list[str], output: Path) -> dict:
    if output.exists():
        output.unlink()
    project = G2sc.G2Project(newgpx=str(output))
    histogram = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma/tab/semicolon separated",
    )
    histogram.set_refinements({
        "Limits": [10.02, 99.98],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 6,
        },
    })
    # The histogram scale and phase scales are exactly degenerate. Keep the
    # former fixed at unity so refined HAP scales carry the quantitative result.
    histogram.SampleParameters["Scale"] = [1.0, False]
    phases = []
    for cod_id in cod_ids:
        phase = project.add_phase(
            str(cod_path(cod_id)),
            phasename=f"COD_{cod_id}",
            histograms=[histogram],
            fmthint="CIF",
        )
        phase.set_HAP_refinements({"Scale": True})
        phases.append(phase)

    project.set_Controls("cycles", 8)
    project.save()

    # Common nuisance model: smooth background and all scales, then one
    # angular correction and cells, followed by a low-dimensional profile.
    project.do_refinements([{}])
    histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.do_refinements([{}])
    histogram.set_refinements({"Instrument Parameters": ["W"]})
    project.do_refinements([{}])
    histogram.set_refinements({"Instrument Parameters": ["X"]})
    project.do_refinements([{}])
    project.save()

    result = {
        "cod_ids": cod_ids,
        "residuals": histogram.residuals,
        "mass_fractions": histogram.ComputeMassFracs(),
        "instrument": {
            key: value[1]
            for key, value in histogram.InstrumentParameters.items()
            if isinstance(value, list) and len(value) >= 2
        },
        "background": histogram.Background[0],
        "phases": [],
    }
    for phase in phases:
        hdata = phase.data["Histograms"][histogram.name]
        result["phases"].append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "density": phase.density,
            "composition": phase.composition,
            "scale": hdata["Scale"],
            "size": hdata["Size"],
            "mustrain": hdata["Mustrain"],
        })
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("cod_ids", nargs="+")
    args = parser.parse_args()
    print(json.dumps(run(args.cod_ids, args.output.resolve()), indent=2, default=str))


if __name__ == "__main__":
    main()
