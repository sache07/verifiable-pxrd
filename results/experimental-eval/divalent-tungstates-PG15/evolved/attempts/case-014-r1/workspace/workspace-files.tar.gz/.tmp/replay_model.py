#!/usr/bin/env python3
"""Replay an existing GSAS-II refinement after save/reopen cycles."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


G2sc.G2fil.G2SetPrintLevel("warn")


def summary(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "max_shift_esd": cov.get("Max shft/sig"),
        "phases": [
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "density": phase.density,
                "scale": phase.data["Histograms"][hist.name]["Scale"],
            }
            for phase in project.phases()
        ],
        "instrument": {
            key: hist.InstrumentParameters[key]
            for key in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]
            if key in hist.InstrumentParameters
        },
        "roughness": {
            key: hist.SampleParameters[key]
            for key in ["SurfRoughA", "SurfRoughB"]
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--replays", type=int, default=4)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
    project.set_Controls("cycles", 12)
    project.save()
    for replay in range(args.replays):
        project.do_refinements([{}])
        project.save()
        print(json.dumps({"replay": replay + 1, **summary(project)}, default=str))
        project = G2sc.G2Project(str(args.output.resolve()))
        project.set_Controls("cycles", 12)


if __name__ == "__main__":
    main()
