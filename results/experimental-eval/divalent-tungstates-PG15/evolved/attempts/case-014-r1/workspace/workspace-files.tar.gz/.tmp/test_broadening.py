#!/usr/bin/env python3
"""Challenge one phase with isotropic size or microstrain broadening."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


G2sc.G2fil.G2SetPrintLevel("warn")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", type=int)
    parser.add_argument("mode", choices=["size", "strain"])
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
    project.set_Controls("cycles", 15)
    hist = project.histogram(0)
    phase = project.phases()[args.phase]
    hap = phase.data["Histograms"][hist.name]

    # Start each challenge from a finite, neutral-adjacent trial value.
    if args.mode == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 2.0
        hap["Size"][2] = [True, False, False]
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 300.0
        hap["Mustrain"][2] = [True, False, False]

    project.save()
    project.do_refinements([{}])
    project.save()
    project = G2sc.G2Project(str(args.output.resolve()))
    project.set_Controls("cycles", 15)
    project.do_refinements([{}])
    project.save()

    hist = project.histogram(0)
    phase = project.phases()[args.phase]
    hap = phase.data["Histograms"][hist.name]
    print(json.dumps({
        "phase": phase.name,
        "mode": args.mode,
        "Rwp": hist.residuals["wR"],
        "mass_fractions": hist.ComputeMassFracs(),
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "instrument": {key: hist.InstrumentParameters[key] for key in ["W", "X"]},
    }, indent=2, default=str))


if __name__ == "__main__":
    main()
