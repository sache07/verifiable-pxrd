#!/usr/bin/env python3
"""Challenge selected atomic coordinate or displacement refinements."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


G2sc.G2fil.G2SetPrintLevel("warn")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", type=int)
    parser.add_argument("element")
    parser.add_argument("flag", choices=["X", "U"])
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
    project.set_Controls("cycles", 15)
    phase = project.phases()[args.phase]
    for atom in phase.atoms():
        if atom.element == args.element:
            atom.refinement_flags = args.flag

    project.save()
    project.do_refinements([{}])
    project.save()
    project = G2sc.G2Project(str(args.output.resolve()))
    project.set_Controls("cycles", 15)
    project.do_refinements([{}])
    project.save()

    hist = project.histogram(0)
    phase = project.phases()[args.phase]
    print(json.dumps({
        "phase": phase.name,
        "element": args.element,
        "flag": args.flag,
        "Rwp": hist.residuals["wR"],
        "mass_fractions": hist.ComputeMassFracs(),
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "xyz": atom.coordinates,
                "uiso": atom.uiso,
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ],
    }, indent=2, default=str))


if __name__ == "__main__":
    main()
