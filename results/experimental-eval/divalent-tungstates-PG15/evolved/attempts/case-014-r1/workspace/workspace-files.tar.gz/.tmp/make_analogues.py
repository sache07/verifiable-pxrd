#!/usr/bin/env python3
"""Create explicitly documented isovalent Sr3WO6 analogue models."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


models = {
    "sr3wo6_from_sr3uo6_2001752.cif": ("2001752", {"U": "W"}),
    "sr3wo6_from_sr3uo6_2310471.cif": ("2310471", {"U": "W"}),
    "sr3wo6_from_ca3wo6_1563081.cif": ("1563081", {"Ca": "Sr"}),
    "sr3wo6_from_ba3wo6_1534803.cif": ("1534803", {"Ba": "Sr"}),
}

for filename, (cod_id, substitutions) in models.items():
    structure = Structure.from_file(cod_path(cod_id))
    structure.replace_species(substitutions)
    CifWriter(structure, symprec=0.01, refine_struct=True).write_file(ROOT / ".tmp" / filename)
    print(filename, structure.composition.reduced_formula, structure.get_space_group_info())
