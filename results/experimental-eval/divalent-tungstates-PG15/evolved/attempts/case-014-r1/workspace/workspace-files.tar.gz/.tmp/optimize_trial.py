#!/usr/bin/env python3
"""Apply selected residual-led model changes to an existing GSAS-II trial."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

G2sc.G2fil.G2SetPrintLevel("none")


def summary(project: G2sc.G2Project) -> dict:
    histogram = project.histogram(0)
    return {
        "residuals": histogram.residuals,
        "mass_fractions": histogram.ComputeMassFracs(),
        "instrument": {
            key: val[1]
            for key, val in histogram.InstrumentParameters.items()
            if isinstance(val, list) and len(val) > 1
        },
        "sample": histogram.SampleParameters,
        "phases": [
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": atom.coordinates,
                        "uiso": atom.uiso,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
                "hap": phase.data["Histograms"][histogram.name],
            }
            for phase in project.phases()
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--p-fixed", type=float)
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--srwo4-uiso", action="store_true")
    parser.add_argument("--uiso-fixed", type=float)
    parser.add_argument("--srwo4-oxygen", action="store_true")
    parser.add_argument("--shl", action="store_true")
    args = parser.parse_args()

    if args.output.exists():
        args.output.unlink()
    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
    histogram = project.histogram(0)
    project.set_Controls("cycles", 12)

    # Neutral fixed phase broadening and texture before common-profile tests.
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0e6
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
        if hap["Pref.Ori."][0] == "MD":
            hap["Pref.Ori."][1] = 1.0

    histogram.SampleParameters["SurfRoughA"] = [0.0, False]
    histogram.SampleParameters["SurfRoughB"] = [0.0, False]
    histogram.SampleParameters["Transparency"] = [0.0, False]

    if args.polarization:
        histogram.InstrumentParameters["Polariz."][1] = 0.8
        histogram.InstrumentParameters["Polariz."][2] = True
    elif args.p_fixed is not None:
        histogram.InstrumentParameters["Polariz."][1] = args.p_fixed
        histogram.InstrumentParameters["Polariz."][2] = False
    if args.roughness:
        histogram.SampleParameters["SurfRoughA"] = [0.0, False]
        histogram.SampleParameters["SurfRoughB"] = [0.05, True]
    if args.shl:
        histogram.InstrumentParameters["SH/L"][1] = 0.02
        histogram.InstrumentParameters["SH/L"][2] = True
    if args.srwo4_uiso:
        phase = project.phase(0)
        for atom in phase.atoms():
            atom.uiso = 0.005
            atom.refinement_flags = "U"
    elif args.uiso_fixed is not None:
        phase = project.phase(0)
        for atom in phase.atoms():
            atom.uiso = args.uiso_fixed
            atom.refinement_flags = ""
    if args.srwo4_oxygen:
        phase = project.phase(0)
        phase.atom("O").refinement_flags = "X"

    project.save()
    project.do_refinements([{}])
    project.save()
    print(json.dumps(summary(project), indent=2, default=str))


if __name__ == "__main__":
    main()
