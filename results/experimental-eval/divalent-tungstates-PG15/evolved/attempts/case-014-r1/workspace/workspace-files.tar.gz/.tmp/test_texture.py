#!/usr/bin/env python3
"""Challenge a phase with one March-Dollase texture direction."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


G2sc.G2fil.G2SetPrintLevel("warn")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", type=int)
    parser.add_argument("h", type=int)
    parser.add_argument("k", type=int)
    parser.add_argument("l", type=int)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
    project.set_Controls("cycles", 15)
    hist = project.histogram(0)
    phase = project.phases()[args.phase]
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = [args.h, args.k, args.l]

    project.save()
    project.do_refinements([{}])
    project.save()
    project = G2sc.G2Project(str(args.output.resolve()))
    project.set_Controls("cycles", 15)
    project.do_refinements([{}])
    project.save()

    hist = project.histogram(0)
    phase = project.phases()[args.phase]
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    cov = project.data.get("Covariance", {}).get("data", {})
    sig = None
    for name, value in zip(cov.get("varyList", []), cov.get("sig", [])):
        if name == f"{args.phase}:0:MD":
            sig = value
    print(json.dumps({
        "phase": phase.name,
        "direction": [args.h, args.k, args.l],
        "Rwp": hist.residuals["wR"],
        "MD": po[1],
        "MD_esd": sig,
        "mass_fractions": hist.ComputeMassFracs(),
    }, indent=2, default=str))


if __name__ == "__main__":
    main()
