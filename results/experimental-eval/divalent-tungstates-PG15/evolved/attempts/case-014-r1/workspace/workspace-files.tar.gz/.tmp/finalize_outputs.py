#!/usr/bin/env python3
"""Replay the selected GSAS-II model and export all submitted artifacts."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


G2sc.G2fil.G2SetPrintLevel("warn")
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp" / "atom_srwo4_o_replay.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = [
    {
        "name": "SrWO4 (scheelite)",
        "formula": "SrWO4",
        "cif": "SrWO4.cif",
        "assignment": "exact-composition scheelite model; COD 1546036",
        "confidence": "high",
    },
    {
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif": "WO3.cif",
        "assignment": "exact-composition ambient monoclinic model; COD 2311041",
        "confidence": "high",
    },
    {
        "name": "Sr3W2O9-like (monoclinic)",
        "formula": "Sr3W2O9",
        "cif": "Sr3W2O9.cif",
        "assignment": "exact-composition C2/c model; COD 2311977",
        "confidence": "provisional",
    },
    {
        "name": "Sr3WO6-like (monoclinic prototype)",
        "formula": "Sr3WO6",
        "cif": "Sr3WO6.cif",
        "assignment": "isovalent W(VI)-for-U(VI) analogue of Sr3UO6; COD parent 2001752",
        "confidence": "provisional",
    },
    {
        "name": "SrO",
        "formula": "SrO",
        "cif": "SrO.cif",
        "assignment": "exact-composition rocksalt model; COD 7200689",
        "confidence": "moderate (weak phase)",
    },
]


def main() -> None:
    project = G2sc.G2Project(str(SOURCE.resolve()), newgpx=str(FINAL.resolve()))
    project.set_Controls("cycles", 15)
    project.save()

    # Required disk replay: refine, save, reopen, and replay the full range.
    project.do_refinements([{}])
    project.save()
    project = G2sc.G2Project(str(FINAL.resolve()))
    project.set_Controls("cycles", 15)
    project.do_refinements([{}])
    project.save()

    # Reopen once more so every export is read from the submitted GPX itself.
    project = G2sc.G2Project(str(FINAL.resolve()))
    hist = project.histogram(0)
    phases = project.phases()
    if len(phases) != len(PHASE_INFO):
        raise RuntimeError(f"Expected {len(PHASE_INFO)} phases, found {len(phases)}")

    fractions = hist.ComputeMassFracs()
    phase_results = []
    for index, (phase, info) in enumerate(zip(phases, PHASE_INFO)):
        cif_path = ROOT / info["cif"]
        phase.export_CIF(str(cif_path.resolve()))
        fraction, fraction_esd = fractions[phase.name]
        sg = phase.data["General"]["SGData"]["SpGrp"].strip()
        phase_results.append({
            **info,
            "space_group": sg,
            "cif_path": info["cif"],
            "weight_fraction": float(fraction),
            "weight_fraction_esd": float(fraction_esd),
            "bragg_R_F_percent": float(hist.residuals[f"{index}:0:Rf"]),
            "bragg_R_F2_percent": float(hist.residuals[f"{index}:0:Rf^2"]),
            "cell": {key: float(value) for key, value in phase.get_cell().items()},
        })

    arrays = np.asarray(hist.data["data"][1], dtype=float)
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg",
            "observed_intensity",
            "calculated_intensity",
            "difference_intensity",
            "background_intensity",
        ])
        # GSAS-II marks points outside the active range with zero calc/background;
        # this preserves the exact internal index convention at the upper limit.
        fitted = arrays[4] != 0.0
        for x, obs, calc, diff, bkg in zip(
            arrays[0][fitted], arrays[1][fitted], arrays[3][fitted],
            arrays[5][fitted], arrays[4][fitted]
        ):
            writer.writerow([
                f"{x:.8f}",
                f"{obs:.8f}",
                f"{calc:.8f}",
                f"{diff:.8f}",
                f"{bkg:.8f}",
            ])

    cov = project.data["Covariance"]["data"]
    result = {
        "phases": phase_results,
        "weight_fraction_basis": "normalized over the modeled crystalline phases; amorphous/unmodeled material excluded",
        "fit_statistics": {
            "Rwp_percent": float(hist.residuals["wR"]),
            "Rp_percent": float(hist.residuals["R"]),
            "R_background_percent": float(hist.residuals["Rb"]),
            "weighted_R_background_percent": float(hist.residuals["wRb"]),
            "Rexp_percent": float(hist.residuals["wRmin"]),
            "GOF": float(cov["Rvals"]["GOF"]),
            "chi_square": float(cov["Rvals"]["chisq"]),
            "n_observations": int(cov["Rvals"]["Nobs"]),
            "n_refined_parameters": int(cov["Rvals"]["Nvars"]),
            "max_shift_over_esd": float(cov["Rvals"]["Max shft/sig"]),
        },
        "profile": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelengths_angstrom": [1.540598, 1.544426],
            "Kalpha2_over_Kalpha1": 0.5,
            "zero_shift_deg": float(hist.InstrumentParameters["Zero"][1]),
            "U": float(hist.InstrumentParameters["U"][1]),
            "V": float(hist.InstrumentParameters["V"][1]),
            "W": float(hist.InstrumentParameters["W"][1]),
            "X": float(hist.InstrumentParameters["X"][1]),
            "SH_over_L": float(hist.InstrumentParameters["SH/L"][1]),
            "surface_roughness_B": float(hist.SampleParameters["SurfRoughB"][0]),
        },
        "files": {
            "project": "final.gpx",
            "fit_profile": "fit.csv",
            "report": "report.md",
        },
    }
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
