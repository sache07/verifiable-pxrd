#!/usr/bin/env python3
"""Add one watch-list phase and rebuild the common GSAS-II profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

G2sc.G2fil.G2SetPrintLevel("none")
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phasefile")
    parser.add_argument("name")
    args = parser.parse_args()

    if args.output.exists():
        args.output.unlink()
    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
    histogram = project.histogram(0)
    phasefile = cod_path(args.phasefile) if args.phasefile.isdigit() else Path(args.phasefile)
    added = project.add_phase(
        str(phasefile.resolve()),
        phasename=args.name,
        histograms=[histogram],
        fmthint="CIF",
    )
    added.data["Histograms"][histogram.name]["Scale"] = [0.1, True]

    # Keep all unused phase-specific broadening and texture neutral.
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
        if hap["Pref.Ori."][0] == "MD":
            hap["Pref.Ori."][1] = 1.0
        phase.set_refinements({"Cell": False})

    histogram.Background[0][1] = True
    histogram.SampleParameters["Scale"] = [1.0, False]
    histogram.SampleParameters["SurfRoughA"] = [0.0, False]
    histogram.SampleParameters["SurfRoughB"][1] = False
    for key, val in histogram.InstrumentParameters.items():
        if isinstance(val, list) and len(val) > 2:
            val[2] = False

    project.set_Controls("cycles", 10)
    project.save()
    # First test the candidate scale under the established nuisance model.
    project.do_refinements([{}])

    # Inventory change requires a common zero/cell/background/scale rebuild.
    histogram.InstrumentParameters["Zero"][2] = True
    histogram.SampleParameters["SurfRoughB"][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.do_refinements([{}])

    # Finally rebuild the common low-dimensional nonnegative profile.
    histogram.InstrumentParameters["W"][2] = True
    histogram.InstrumentParameters["X"][2] = True
    project.do_refinements([{}])
    project.save()

    result = {
        "residuals": histogram.residuals,
        "mass_fractions": histogram.ComputeMassFracs(),
        "instrument": {k: v for k, v in histogram.InstrumentParameters.items()},
        "sample": {
            k: histogram.SampleParameters[k]
            for k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]
        },
        "phases": [
            {
                "name": phase.name,
                "composition": phase.composition,
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][histogram.name]["Scale"],
                "density": phase.density,
            }
            for phase in project.phases()
        ],
    }
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
