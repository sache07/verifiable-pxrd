#!/usr/bin/env python3
"""Replay the accepted model and export the final GSAS-II deliverables."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "adp_fix_w.gpx"
FINAL = ROOT / "final.gpx"


def enforce_accepted_model(gpx: G2sc.G2Project) -> None:
    """Set the final range and explicitly neutralize rejected nuisance terms."""
    hist = gpx.histogram(0)
    data = hist.data["data"][1]
    hist.data["Limits"][1] = [float(data[0, 0]), float(data[0, -1])]

    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "X", "Y", "Z", "Zero"):
        inst[key][1] = 0.0
        inst[key][2] = False
    inst["W"][2] = True
    inst["SH/L"][1] = 0.002
    inst["SH/L"][2] = False
    inst["Polariz."][2] = True

    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"][1] = True
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"][1] = True

    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist.name)
        hap["Scale"][1] = True
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]

    # The CuWO4 W ADP was strongly correlated with polarization and was
    # therefore fixed at a small, positive neutral value in the accepted model.
    cuwo4_w = gpx.phase(0).atoms()[1]
    cuwo4_w.uiso = 0.00633
    cuwo4_w.refinement_flags = cuwo4_w.refinement_flags.replace("U", "")

    # The weak WO3 phase supports cell, scale and size refinement, but not
    # independent coordinate or ADP refinement.
    for atom in gpx.phase(1).atoms():
        atom.uiso = 0.00633
        atom.refinement_flags = ""

    gpx.set_Controls("cycles", 30)
    gpx.set_Frozen()


def replay() -> G2sc.G2Project:
    gpx = G2sc.G2Project(str(SOURCE))
    gpx.save(str(FINAL))
    enforce_accepted_model(gpx)
    gpx.save()

    # Reopen and replay repeatedly so project serialization and the full-range
    # result are tested rather than relying on an in-memory state.
    for pass_number in range(1, 4):
        gpx = G2sc.G2Project(str(FINAL))
        enforce_accepted_model(gpx)
        gpx.save()
        gpx.refine(printFile=str(ROOT / f"final_pass{pass_number}.lst"))
        gpx.reload()
        rvals = gpx.data["Covariance"]["data"]["Rvals"]
        print(
            f"pass {pass_number}: Rwp={gpx.histogram(0).get_wR():.8f}, "
            f"GOF={rvals['GOF']:.8f}, max shift/esd={rvals.get('Max shft/sig')}"
        )

    return G2sc.G2Project(str(FINAL))


def export_outputs(gpx: G2sc.G2Project) -> dict:
    hist = gpx.histogram(0)
    cuwo4 = gpx.phase(0)
    wo3 = gpx.phase(1)
    cuwo4.export_CIF(str(ROOT / "CuWO4.cif"))
    wo3.export_CIF(str(ROOT / "WO3.cif"))

    profile = np.ma.filled(hist.data["data"][1], np.nan)
    with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        for x, yo, yc, yd, yb in zip(
            profile[0], profile[1], profile[3], profile[5], profile[4]
        ):
            writer.writerow(
                [
                    f"{x:.8f}",
                    f"{yo:.10g}",
                    f"{yc:.10g}",
                    f"{yd:.10g}",
                    f"{yb:.10g}",
                ]
            )

    fractions = hist.ComputeMassFracs()
    rvals = gpx.data["Covariance"]["data"]["Rvals"]
    powder_stats = hist.data["data"][0]
    phase_specs = [
        (cuwo4, "CuWO4", "CuWO4", "CuWO4.cif", "P -1"),
        (wo3, "WO3", "WO3", "WO3.cif", "P 21/n"),
    ]
    phases = []
    for phase, key, formula, cif_path, space_group in phase_specs:
        fraction, fraction_esd = fractions[phase.name]
        phases.append(
            {
                "name": key,
                "formula": formula,
                "space_group": space_group,
                "cif_path": cif_path,
                "weight_fraction": float(fraction),
                "weight_fraction_esd_statistical": float(fraction_esd),
                "cell": {
                    key: float(value) for key, value in phase.get_cell().items()
                },
            }
        )

    rwp = float(hist.get_wR())
    gof = float(rvals["GOF"])
    result = {
        "phases": phases,
        "weight_fraction_basis": (
            "Normalized over the modeled crystalline phases; no amorphous "
            "fraction or absolute external-standard fraction was determined."
        ),
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": float(powder_stats["R"]),
            "Rexp_percent": rwp / gof,
            "goodness_of_fit": gof,
            "reduced_chi_squared": gof * gof,
            "chi_squared": float(rvals["chisq"]),
            "durbin_watson": float(powder_stats["Durbin-Watson"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
            "two_theta_range_deg": [float(profile[0, 0]), float(profile[0, -1])],
            "weighting": (
                "Poisson counting approximation, sigma=sqrt(observed counts); "
                "pointwise uncertainties were not supplied."
            ),
        },
        "profile_path": "fit.csv",
        "gsasii_project_path": "final.gpx",
    }
    with (ROOT / "result.json").open("w", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")

    assert math.isclose(
        sum(item["weight_fraction"] for item in phases), 1.0, abs_tol=1e-10
    )
    assert int(rvals["Nobs"]) == profile.shape[1]
    assert np.allclose(profile[1] - profile[3], profile[5], rtol=0.0, atol=1e-7)
    assert np.isfinite(profile).all()
    return result


def main() -> None:
    gpx = replay()
    result = export_outputs(gpx)
    print(json.dumps(result, indent=2))
    print("refinement_message", repr(gpx.data["Covariance"]["data"]["Rvals"].get("msg", "")))


if __name__ == "__main__":
    main()
