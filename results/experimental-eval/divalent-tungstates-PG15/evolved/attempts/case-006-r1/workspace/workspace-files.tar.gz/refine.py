#!/usr/bin/env python3
"""Build and refine the CuWO4 GSAS-II model."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
GPX = ROOT / "work.gpx"


def project_summary(gpx: G2sc.G2Project, label: str) -> None:
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    samp = hist.data["Sample Parameters"]
    hap = phase.getHAPvalues(hist.name)
    print(f"SUMMARY {label}")
    print("Rwp", hist.get_wR())
    print("cell", phase.get_cell())
    print("inst", {k: v for k, v in inst.items() if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")})
    print("sample", {k: v for k, v in samp.items() if k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")})
    print("hap", {k: hap[k] for k in ("Scale", "Size", "Mustrain", "Pref.Ori.")})
    print("background", hist.data["Background"][0])


def refine(gpx: G2sc.G2Project, label: str) -> None:
    gpx.refine(printFile=str(ROOT / f"{label}.lst"))
    gpx.reload()
    project_summary(gpx, label)


def main() -> None:
    if GPX.exists():
        GPX.unlink()
    gpx = G2sc.G2Project(newgpx=str(GPX))
    hist = gpx.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "lab_cuka.instprm"), fmthint="xye"
    )
    phase = gpx.add_phase(
        str(ROOT / "cuwo4_start.cif"),
        phasename="CuWO4",
        histograms=[hist],
        fmthint="CIF",
    )

    gpx.set_Controls("cycles", 15)

    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 6,
            "coeffs": [1200.0, -200.0, 100.0, 0.0, 0.0, 0.0],
        },
    })
    # Neutralize sample effects before the baseline refinement.
    phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
    phase.setSampleProfile(hist, "micro", "isotropic", 0.0, LGmix=1.0)
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    phase.HAPvalue("Scale", 1.0)
    phase.set_HAP_refinements({"Scale": True})
    sample = hist.data["Sample Parameters"]
    # The histogram scale and HAP scale are exactly redundant. Keep the
    # histogram scale fixed and use only the HAP scale.
    sample["Scale"] = [1.0, False]
    sample["Shift"][0] = -500.0
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        if key in sample:
            sample[key][1] = False
    gpx.save()

    # Establish scale/background only.
    refine(gpx, "step01_scale_background")

    # Use a single specimen-displacement correction, with instrument zero fixed.
    hist = gpx.histogram(0)
    if "Shift" in hist.data["Sample Parameters"]:
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    else:
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(gpx, "step02_angular")

    # Refine the triclinic metric only after scale and angular correction.
    phase = gpx.phase(0)
    phase.set_refinements({"Cell": True})
    refine(gpx, "step03_cell")

    # Clean common profile. Seed a physical width, then release W, U, and X
    # sequentially. V and Y remain fixed at zero.
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][1] = 5.0
    inst["W"][1] = 30.0
    inst["X"][1] = 5.0
    for name in ("U", "W", "X"):
        gpx.set_Controls("parmMin", 0.0, f":0:{name}")
    hist.set_refinements({"Instrument Parameters": ["W"]})
    refine(gpx, "step04_profile_W")
    hist = gpx.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["U", "W"]})
    refine(gpx, "step05_profile_UW")
    hist = gpx.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(gpx, "step06_profile_UWX")


if __name__ == "__main__":
    main()
