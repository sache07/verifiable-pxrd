#!/usr/bin/env python3
"""Compare restrained ADP variants for the final two-phase refinement."""

from __future__ import annotations

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "wo3_adp_fixed.gpx"


def run_variant(name: str, atom_indices: tuple[int, ...]) -> None:
    path = ROOT / f"adp_{name}.gpx"
    gpx = G2sc.G2Project(str(BASE))
    gpx.save(str(path))
    phase = gpx.phase(0)
    for index in atom_indices:
        atom = phase.atoms()[index]
        atom.uiso = 0.00633
        atom.refinement_flags = atom.refinement_flags.replace("U", "")
    gpx.set_Controls("cycles", 30)
    gpx.save()
    gpx.refine(printFile=str(ROOT / f"adp_{name}.lst"))
    gpx.reload()
    hist = gpx.histogram(0)
    rvals = gpx.data["Covariance"]["data"]["Rvals"]
    print(f"VARIANT {name}")
    print("Rwp", hist.get_wR())
    print("GOF", rvals["GOF"], "Nvars", rvals["Nvars"])
    print("max_shift_sigma", rvals.get("Max shft/sig"))
    print("message", repr(rvals.get("msg", "")))
    print("fractions", hist.ComputeMassFracs())
    print(
        "adps",
        [(atom.label, atom.refinement_flags, atom.uiso) for atom in phase.atoms()],
    )


def main() -> None:
    run_variant("fix_w", (1,))
    run_variant("fix_all", tuple(range(6)))


if __name__ == "__main__":
    main()
