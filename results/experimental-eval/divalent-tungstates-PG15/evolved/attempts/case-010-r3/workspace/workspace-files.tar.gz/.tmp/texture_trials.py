#!/usr/bin/env python3
"""Test symmetry-distinct March-Dollase axes under the accepted nuisance model."""

from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "trial_both_strain.gpx"


def trial(phase_index, direction):
    axis = "_".join(str(i).replace("-", "m") for i in direction)
    output = ROOT / ".tmp" / f"texture_p{phase_index}_{axis}.gpx"
    shutil.copyfile(BASE, output)
    project = G2sc.G2Project(str(output))
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(direction)
    project.set_Controls("parmMin", 0.2, variable=f"{phase_index}:0:MD")
    project.set_Controls("parmMax", 5.0, variable=f"{phase_index}:0:MD")
    project.refine()
    first = project.histogram(0).residuals["wR"]
    project.refine()
    hist = project.histogram(0)
    replay = hist.residuals["wR"]
    po = project.phase(phase_index).data["Histograms"][hist.name]["Pref.Ori."]
    cov = project.data["Covariance"]["data"]
    esd = None
    for name, sig in zip(cov.get("varyList", []), cov.get("sig", [])):
        if name == f"{phase_index}:0:MD":
            esd = sig
            break
    print(
        "TEXTURE",
        project.phase(phase_index).name,
        direction,
        "first", first,
        "replay", replay,
        "MD", po[1],
        "esd", esd,
        "mass", hist.ComputeMassFracs(),
        "frozen", project.get_Frozen(),
    )
    project.save()


def main():
    G2sc.SetPrintLevel("warn")
    for direction in ([1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 0, 1], [1, 0, -1], [1, 1, 0], [0, 1, 1]):
        trial(0, direction)
    for direction in ([1, 0, 0], [1, 1, 0], [1, 1, 1]):
        trial(1, direction)


if __name__ == "__main__":
    main()
