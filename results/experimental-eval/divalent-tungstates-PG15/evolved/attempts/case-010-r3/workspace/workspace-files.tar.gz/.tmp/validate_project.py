#!/usr/bin/env python3
"""Read-only consistency checks for the final GSAS-II deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(ROOT / "final.gpx"))
    hist = project.histogram(0)
    arrays = hist.data["data"][1]

    with (ROOT / "fit.csv").open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    fit = np.array(
        [
            [
                float(row["two_theta_deg"]),
                float(row["observed"]),
                float(row["calculated"]),
                float(row["background"]),
                float(row["difference"]),
            ]
            for row in rows
        ]
    )
    expected = np.column_stack((arrays[0], arrays[1], arrays[3], arrays[4], arrays[5]))
    if fit.shape != expected.shape:
        raise RuntimeError(f"fit.csv shape {fit.shape} != project shape {expected.shape}")
    max_profile_delta = np.max(np.abs(fit - expected), axis=0)

    fractions = hist.ComputeMassFracs()
    fraction_sum = sum(float(value[0]) for value in fractions.values())
    summary = json.loads((ROOT / ".tmp" / "final_summary.json").read_text())
    summary_map = {row["name"]: row["weight_fraction"] for row in summary["phases"]}
    fraction_delta = max(
        abs(float(value[0]) - summary_map[name]) for name, value in fractions.items()
    )

    inst = hist.InstrumentParameters
    fixed_profile = {
        key: {"value": float(inst[key][1]), "refine": bool(inst[key][2])}
        for key in ("V", "W", "Y", "Z", "SH/L", "Zero")
    }
    sample = hist.SampleParameters
    neutral_sample = {
        key: {"value": float(sample[key][0]), "refine": bool(sample[key][1])}
        for key in ("Transparency", "SurfRoughA", "SurfRoughB")
    }
    covariance = project.data["Covariance"]["data"]
    result = {
        "points": len(rows),
        "max_abs_csv_rounding_delta_by_column": max_profile_delta.tolist(),
        "weight_fraction_sum": fraction_sum,
        "max_fraction_delta_from_summary": fraction_delta,
        "max_shift_over_esd": float(covariance["Rvals"]["Max shft/sig"]),
        "fixed_profile": fixed_profile,
        "neutral_sample_terms": neutral_sample,
    }

    if not np.isclose(fraction_sum, 1.0, rtol=0.0, atol=1e-12):
        raise RuntimeError(f"Mass fractions do not sum to unity: {fraction_sum}")
    if fraction_delta > 1e-12:
        raise RuntimeError(f"Summary/project fraction mismatch: {fraction_delta}")
    if np.max(max_profile_delta) > 5e-6:
        raise RuntimeError(f"fit.csv/project mismatch: {max_profile_delta}")
    if any(item["refine"] for item in fixed_profile.values()):
        raise RuntimeError(f"A pruned profile term is active: {fixed_profile}")
    if any(item["refine"] or item["value"] != 0.0 for item in neutral_sample.values()):
        raise RuntimeError(f"An unused sample term is active: {neutral_sample}")

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
