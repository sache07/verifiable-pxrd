#!/usr/bin/env python3
"""Compare physical MnWO4 source models under one common nuisance model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "texture_p0_0_1_0.gpx"
HP_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/02/1520200.cif"
)
LOW_T_CIF = ROOT / ".tmp" / "MnWO4_from_9008131.cif"


def neutralize(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Scale"][:] = [0.2, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][1:3] = [1.0, False]


def summarize(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    scale_sigma = None
    for variable, sigma in zip(cov.get("varyList", []), cov.get("sig", [])):
        if variable == "2:0:Scale":
            scale_sigma = float(sigma)
    return {
        "Rwp": float(hist.residuals["wR"]),
        "GOF": float(cov["Rvals"]["GOF"]),
        "max_shift_over_esd": float(cov["Rvals"]["Max shft/sig"]),
        "cell": project.phase("MnWO4").get_cell_and_esd(),
        "fractions": hist.ComputeMassFracs(),
        "scale": project.phase("MnWO4").data["Histograms"][hist.name]["Scale"][0],
        "scale_sigma": scale_sigma,
    }


def trial(label: str, cif: Path, release_cell: bool) -> dict:
    target = ROOT / ".tmp" / f"trace_source_{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(target))
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cif), phasename="MnWO4", histograms=[hist], fmthint="CIF"
    )
    neutralize(phase, hist.name)
    phase.set_refinements({"Cell": False})
    project.set_Controls("parmMin", 0.0, variable="2:0:Scale")
    project.save()
    project.refine()
    project.refine()
    fixed = summarize(project)

    free_history = []
    if release_cell:
        phase.set_refinements({"Cell": True})
        for iteration in range(1, 5):
            project.refine()
            project.save()
            project = G2sc.G2Project(str(target))
            free_history.append({"iteration": iteration, **summarize(project)})
    project.save()
    return {"label": label, "fixed_cell": fixed, "free_cell": free_history}


def main() -> None:
    G2sc.SetPrintLevel("warn")
    results = [
        trial("COD1520200_2p4GPa_293K", HP_CIF, False),
        trial("COD9008131_Mn_sub_4p2K", LOW_T_CIF, True),
    ]
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
