#!/usr/bin/env python3
"""Replay, save, and export the accepted GSAS-II model."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp" / "accepted_MnWO4.gpx"
FINAL_GPX = ROOT / "final.gpx"

CIF_NAMES = {
    "WO3_monoclinic": "phase_1_WO3.cif",
    "Mn2O3_bixbyite": "phase_2_Mn2O3.cif",
    "MnWO4": "phase_3_MnWO4.cif",
}


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL_GPX))
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)

    # Explicitly retain the pruned physical baseline.
    instrument = hist.InstrumentParameters
    for key, value in (("V", 0.0), ("W", 0.0), ("Y", 0.0), ("Z", 0.0)):
        instrument[key][1] = value
        instrument[key][2] = False
    instrument["SH/L"][1] = 0.002
    instrument["SH/L"][2] = False
    instrument["Zero"][1] = 0.0
    instrument["Zero"][2] = False
    hist.SampleParameters["Scale"][1] = False
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key][0] = 0.0
        hist.SampleParameters[key][1] = False

    # The trace MnWO4 cell is deliberately fixed to the physical 4.2 K
    # hubnerite record (COD 9008131), with its 3% Fe replaced by Mn.
    project.phase("MnWO4").set_refinements({"Cell": False})

    project.save()
    project.refine()
    project.refine()
    project.save()

    # Reopen to ensure exports come from the exact on-disk project.
    project = G2sc.G2Project(str(FINAL_GPX))
    hist = project.histogram(0)
    covariance = project.data["Covariance"]["data"]
    rvals = covariance.get("Rvals", {})
    max_shift = float(rvals.get("Max shft/sig", np.nan))
    if not np.isfinite(max_shift) or max_shift > 0.2:
        raise RuntimeError(f"Final replay did not converge tightly: max shift/esd={max_shift}")

    mass_fractions = hist.ComputeMassFracs()
    phase_rows = []
    for phase in project.phases():
        cif_name = CIF_NAMES[phase.name]
        cif_path = ROOT / cif_name
        phase.export_CIF(str(cif_path))
        value, sigma = mass_fractions[phase.name]
        phase_rows.append(
            {
                "name": phase.name,
                "cif": cif_name,
                "weight_fraction": float(value),
                "weight_fraction_standard_uncertainty": float(sigma),
                "cell": phase.get_cell(),
                "cell_standard_uncertainty": phase.get_cell_and_esd()[1],
            }
        )

    arrays = hist.data["data"][1]
    with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "background", "difference"]
        )
        for row in zip(arrays[0], arrays[1], arrays[3], arrays[4], arrays[5]):
            writer.writerow([f"{float(value):.10g}" for value in row])

    residuals = hist.residuals
    summary = {
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "GOF": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_variables": int(rvals["Nvars"]),
            "max_shift_over_esd": max_shift,
            "background_R_percent": float(residuals["Rb"]),
            "weighted_background_R_percent": float(residuals["wRb"]),
        },
        "instrument": {
            key: float(instrument[key][1])
            for key in ["Lam1", "Lam2", "I(L2)/I(L1)", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L", "Zero"]
        },
        "specimen_displacement_micrometre": float(hist.SampleParameters["Shift"][0]),
        "residuals": {key: value for key, value in residuals.items() if isinstance(value, (int, float))},
    }
    (ROOT / ".tmp" / "final_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
