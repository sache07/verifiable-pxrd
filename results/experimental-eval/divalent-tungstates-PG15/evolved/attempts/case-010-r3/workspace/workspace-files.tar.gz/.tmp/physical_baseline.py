#!/usr/bin/env python3
"""Prune the nonphysical profile term and test axial asymmetry."""

from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp" / "trial_polarization.gpx"
BASE = ROOT / ".tmp" / "physical_baseline.gpx"
ASYM = ROOT / ".tmp" / "trial_asymmetry.gpx"


def summarize(project, label):
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    cov = project.data["Covariance"]["data"]
    print(
        label,
        "wR", hist.residuals["wR"],
        "mass", hist.ComputeMassFracs(),
        "profile", {k: inst[k] for k in ["U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]},
        "shift", hist.SampleParameters["Shift"],
        "frozen", project.get_Frozen(),
    )
    print(
        "PROFILE_ESD",
        [(a, b, s) for a, b, s in zip(cov.get("varyList", []), cov.get("variables", []), cov.get("sig", []))
         if any(key in a for key in [":U", ":W", ":X", "SH/L", "Polariz."])],
    )


def main():
    shutil.copyfile(SOURCE, BASE)
    project = G2sc.G2Project(str(BASE))
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    inst["W"][1] = 0.0
    inst["W"][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.refine()
    summarize(project, "PHYSICAL_BASE_FIRST")
    project.refine()
    summarize(project, "PHYSICAL_BASE_REPLAY")
    project.save()

    shutil.copyfile(BASE, ASYM)
    asym = G2sc.G2Project(str(ASYM))
    asym.set_Controls("cycles", 12)
    ah = asym.histogram(0)
    ah.InstrumentParameters["SH/L"][2] = True
    asym.set_Controls("parmMin", 0.002, variable=":0:SH/L")
    asym.set_Controls("parmMax", 0.2, variable=":0:SH/L")
    asym.refine()
    summarize(asym, "ASYM_FIRST")
    asym.refine()
    summarize(asym, "ASYM_REPLAY")
    asym.save()


if __name__ == "__main__":
    main()
