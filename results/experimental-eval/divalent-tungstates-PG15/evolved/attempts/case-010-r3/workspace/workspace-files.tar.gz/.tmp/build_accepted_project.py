#!/usr/bin/env python3
"""Build the accepted three-phase model with a physical fixed MnWO4 cell."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "texture_p0_0_1_0.gpx"
TRACE_CIF = ROOT / ".tmp" / "MnWO4_from_9008131.cif"
TARGET = ROOT / ".tmp" / "accepted_MnWO4.gpx"


def neutralize(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Scale"][:] = [0.2, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][1:3] = [1.0, False]


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(BASE), newgpx=str(TARGET))
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    phase = project.add_phase(
        str(TRACE_CIF), phasename="MnWO4", histograms=[hist], fmthint="CIF"
    )
    neutralize(phase, hist.name)
    phase.set_refinements({"Cell": False})
    project.set_Controls("parmMin", 0.0, variable="2:0:Scale")
    project.save()

    replay = []
    for iteration in range(1, 5):
        project.refine()
        project.save()
        project = G2sc.G2Project(str(TARGET))
        hist = project.histogram(0)
        rvals = project.data["Covariance"]["data"]["Rvals"]
        replay.append(
            {
                "iteration": iteration,
                "Rwp": hist.residuals["wR"],
                "max_shift_over_esd": rvals["Max shft/sig"],
                "fractions": hist.ComputeMassFracs(),
            }
        )
        if rvals["Max shft/sig"] < 0.05:
            break
    print(json.dumps(replay, indent=2))


if __name__ == "__main__":
    main()
