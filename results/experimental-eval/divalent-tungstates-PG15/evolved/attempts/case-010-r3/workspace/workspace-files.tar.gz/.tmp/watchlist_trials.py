#!/usr/bin/env python3
"""Re-challenge plausible weak phases under the accepted common profile."""

from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "texture_p0_0_1_0.gpx"
PREFIX = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"

CANDIDATES = [
    ("MnWO4", f"{PREFIX}/1/52/02/1520200.cif", 0.20),
    ("Mn3WO6", f"{PREFIX}/2/00/27/2002703.cif", 0.20),
    ("Mn3O4", f"{PREFIX}/9/00/19/9001963.cif", 0.10),
]


def neutralize(phase, histogram_name, scale):
    hap = phase.data["Histograms"][histogram_name]
    hap["Scale"][:] = [scale, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][1:3] = [1.0, False]


def challenge(name, cif, initial_scale):
    target = ROOT / ".tmp" / f"watch_{name}.gpx"
    shutil.copyfile(BASE, target)
    project = G2sc.G2Project(str(target))
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)
    phase = project.add_phase(cif, phasename=name, histograms=[hist], fmthint="CIF")
    neutralize(phase, hist.name, initial_scale)
    phase.set_refinements({"Cell": False})
    project.set_Controls("parmMin", 0.0, variable="2:0:Scale")
    project.refine()
    first = project.histogram(0).residuals["wR"]
    project.refine()
    hist = project.histogram(0)
    replay = hist.residuals["wR"]
    cov = project.data["Covariance"]["data"]
    scale = phase.data["Histograms"][hist.name]["Scale"][0]
    scale_esd = None
    for var, sig in zip(cov.get("varyList", []), cov.get("sig", [])):
        if var == "2:0:Scale":
            scale_esd = sig
            break
    print(
        "WATCH", name,
        "first", first,
        "replay", replay,
        "scale", scale,
        "scale_esd", scale_esd,
        "mass", hist.ComputeMassFracs(),
        "frozen", project.get_Frozen(),
        "residuals", hist.residuals,
    )
    project.save()


def main():
    G2sc.SetPrintLevel("warn")
    for args in CANDIDATES:
        challenge(*args)


if __name__ == "__main__":
    main()
