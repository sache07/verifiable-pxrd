#!/usr/bin/env python3
"""Read-only chemical and geometric checks for exported CIF files."""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path(__file__).resolve().parents[1]
CIFS = ["phase_1_WO3.cif", "phase_2_Mn2O3.cif", "phase_3_MnWO4.cif"]


def main() -> None:
    output = []
    for name in CIFS:
        structure = Structure.from_file(ROOT / name)
        occupancies = [float(sum(site.species.values())) for site in structure]
        cation_shells = []
        for index, site in enumerate(structure):
            element = next(iter(site.species)).symbol
            if element not in {"Mn", "W"}:
                continue
            oxygen_distances = sorted(
                float(neighbor.nn_distance)
                for neighbor in structure.get_neighbors(site, 3.1)
                if next(iter(neighbor.species)).symbol == "O"
            )
            cation_shells.append(
                {
                    "site": index,
                    "element": element,
                    "first_six_O_distances_A": oxygen_distances[:6],
                }
            )
        output.append(
            {
                "cif": name,
                "reduced_formula": structure.composition.reduced_formula,
                "sites": len(structure),
                "space_group_at_symprec_0.01_A": SpacegroupAnalyzer(
                    structure, symprec=0.01
                ).get_space_group_symbol(),
                "occupancy_range": [min(occupancies), max(occupancies)],
                "cation_O_shells": cation_shells,
            }
        )
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
