#!/usr/bin/env python3
"""Replay the provisional free-cell MnWO4 model to test stability."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp" / "trace_source_COD9008131_Mn_sub_4p2K.gpx"
TARGET = ROOT / ".tmp" / "trace_source_COD9008131_Mn_sub_replay.gpx"


def snapshot(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "Rwp": hist.residuals["wR"],
        "GOF": rvals.get("GOF"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "cell": project.phase("MnWO4").get_cell_and_esd(),
        "fractions": hist.ComputeMassFracs(),
    }


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(SOURCE), newgpx=str(TARGET))
    project.set_Controls("cycles", 12)
    project.save()
    history = [{"stage": "source", **snapshot(project)}]
    for iteration in range(1, 7):
        project.refine()
        project.save()
        project = G2sc.G2Project(str(TARGET))
        history.append({"stage": f"replay_{iteration}", **snapshot(project)})
        if history[-1]["max_shift_over_esd"] < 0.05:
            break
    print(json.dumps(history, indent=2))


if __name__ == "__main__":
    main()
