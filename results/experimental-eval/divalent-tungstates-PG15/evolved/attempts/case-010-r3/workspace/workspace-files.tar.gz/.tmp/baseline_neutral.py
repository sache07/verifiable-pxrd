#!/usr/bin/env python3
"""Build a physically neutral common-profile baseline refinement."""

from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp" / "probe.gpx"
TARGET = ROOT / ".tmp" / "baseline_neutral.gpx"


def neutralize_microstructure(phase, histogram_name):
    hap = phase.data["Histograms"][histogram_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1000.0, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def report(project, label):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    print("\nSTAGE", label, hist.residuals, hist.ComputeMassFracs())
    print("profile", {k: inst[k] for k in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]})
    print("shift", hist.data["Sample Parameters"]["Shift"])
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, "scale", hap["Scale"], "cell", phase.get_cell(), "size", hap["Size"], "strain", hap["Mustrain"])


def run():
    shutil.copyfile(SOURCE, TARGET)
    project = G2sc.G2Project(str(TARGET))
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    hist.data["Sample Parameters"]["Scale"][1] = False
    hist.data["Instrument Parameters"][0]["Zero"][2] = False
    hist.set_refinements({
        "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 8},
        "Sample Parameters": ["Shift"],
    })
    for phase in project.phases():
        neutralize_microstructure(phase, hist.name)
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": False})
    project.refine()
    report(project, "background_scales_shift")

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine()
    report(project, "cells")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.refine()
    report(project, "common_profile")
    project.refine()
    report(project, "replay")
    project.save()


if __name__ == "__main__":
    run()
