#!/usr/bin/env python3
"""Re-challenge excluded phases under the rebuilt final common profile."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "final.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
CANDIDATES = [
    ("Mn3WO6", COD / "2/00/27/2002703.cif", 0.05),
    ("Mn3O4", COD / "9/00/19/9001963.cif", 0.05),
]


def neutralize(phase, histogram_name: str, scale: float) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Scale"][:] = [scale, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][1:3] = [1.0, False]


def trial(name: str, cif: Path, initial_scale: float) -> dict:
    target = ROOT / ".tmp" / f"final_watch_{name}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(target))
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cif), phasename=name, histograms=[hist], fmthint="CIF"
    )
    neutralize(phase, hist.name, initial_scale)
    phase.set_refinements({"Cell": False})
    project.set_Controls("parmMin", 0.0, variable="3:0:Scale")
    project.save()
    for _ in range(2):
        project.refine()
        project.save()
        project = G2sc.G2Project(str(target))

    hist = project.histogram(0)
    covariance = project.data["Covariance"]["data"]
    scale_sigma = None
    for variable, sigma in zip(covariance.get("varyList", []), covariance.get("sig", [])):
        if variable == "3:0:Scale":
            scale_sigma = float(sigma)
    scale = float(project.phase(name).data["Histograms"][hist.name]["Scale"][0])
    return {
        "candidate": name,
        "Rwp": float(hist.residuals["wR"]),
        "max_shift_over_esd": float(covariance["Rvals"]["Max shft/sig"]),
        "scale": scale,
        "scale_sigma": scale_sigma,
        "scale_significance_sigma": None if not scale_sigma else scale / scale_sigma,
        "fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
    }


def main() -> None:
    G2sc.SetPrintLevel("warn")
    print(json.dumps([trial(*candidate) for candidate in CANDIDATES], indent=2))


if __name__ == "__main__":
    main()
