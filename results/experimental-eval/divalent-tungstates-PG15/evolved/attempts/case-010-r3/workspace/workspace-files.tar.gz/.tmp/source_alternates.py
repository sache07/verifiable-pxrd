#!/usr/bin/env python3
"""Challenge physically plausible alternate structure records under one profile."""

from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "trial_polarization.gpx"
HIST_NAME = "PWDR pattern.xye"

WO3_ALT = (
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/89/1528915.cif"
)
MN2O3_ALT = (
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/51/41/1514103.cif"
)


def neutralize(phase, histogram_name, scale):
    hap = phase.data["Histograms"][histogram_name]
    hap["Scale"][:] = [scale, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][1:3] = [1.0, False]


def challenge(label, old_index, source, phase_name, scale):
    target = ROOT / ".tmp" / f"alternate_{label}.gpx"
    shutil.copyfile(BASE, target)
    project = G2sc.G2Project(str(target))
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    old = project.phase(old_index)
    old_hap = old.data["Histograms"][hist.name]
    old_hap["Use"] = False
    old_hap["Scale"][1] = False
    old.set_refinements({"Cell": False})
    alternate = project.add_phase(
        source,
        phasename=phase_name,
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize(alternate, hist.name, scale)
    alternate.set_refinements({"Cell": False})
    project.refine()
    fixed = project.histogram(0).residuals["wR"]
    alternate.set_refinements({"Cell": True})
    project.refine()
    cell = project.histogram(0).residuals["wR"]
    project.refine()
    replay = project.histogram(0).residuals["wR"]
    print(
        "ALTERNATE", label,
        "fixed", fixed,
        "cell", cell,
        "replay", replay,
        "mass", project.histogram(0).ComputeMassFracs(),
        "cellpar", project.phase(2).get_cell(),
        "scale", project.phase(2).data["Histograms"][hist.name]["Scale"],
        "frozen", project.get_Frozen(),
    )
    project.save()


def main():
    challenge("wo3_1528915", 0, WO3_ALT, "WO3_Tanisaki_1960", 17.7)
    challenge("mn2o3_pbca", 1, MN2O3_ALT, "Mn2O3_Pbca", 4.86)


if __name__ == "__main__":
    main()
