#!/usr/bin/env python3
"""Prepare the original count pattern for GSAS-II and inspect defaults."""

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
PATTERN = ROOT / "inputs" / "pattern.csv"
XYE = TMP / "pattern.xye"
GPX = TMP / "probe.gpx"
IPRM = TMP / "cu_ka_reflection.instprm"


def prepare_xye() -> None:
    data = np.genfromtxt(PATTERN, delimiter=",", names=True)
    x = np.asarray(data["two_theta_deg"], dtype=float)
    y = np.asarray(data["intensity"], dtype=float)
    # Original values are counts. No point uncertainties were supplied, so
    # use counting-statistical sigma=sqrt(I), which GSAS-II stores as 1/I.
    with XYE.open("w", encoding="ascii") as handle:
        handle.write("# Original pattern.csv; sigma=sqrt(counts)\n")
        for xx, yy in zip(x, y):
            handle.write(f"{xx:.8f} {yy:.8f} {np.sqrt(max(yy, 1.0)):.8f}\n")


def main() -> None:
    prepare_xye()
    project = G2sc.G2Project(newgpx=str(GPX))
    histogram = project.add_powder_histogram(
        str(XYE), str(IPRM), fmthint="Topas xye"
    )
    wo3 = project.add_phase(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/2/31/10/2311041.cif",
        phasename="WO3_monoclinic",
        histograms=[histogram],
        fmthint="CIF",
    )
    mn2o3 = project.add_phase(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/1/51/42/1514230.cif",
        phasename="Mn2O3_bixbyite",
        histograms=[histogram],
        fmthint="CIF",
    )
    project.save()
    print("histogram", histogram.name)
    print("limits", histogram.data["Limits"])
    print("instrument", histogram.data["Instrument Parameters"])
    print("sample", histogram.data["Sample Parameters"])
    print("background", histogram.data["Background"])
    for phase in (wo3, mn2o3):
        print("PHASE", phase.name)
        print("cell", phase.get_cell())
        print("composition", phase.composition)
        print("HAP", phase.data["Histograms"][histogram.name])


if __name__ == "__main__":
    main()
