#!/usr/bin/env python3
"""Staged two-phase trial using specimen displacement instead of zero."""

from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp" / "probe.gpx"
TARGET = ROOT / ".tmp" / "trial_shift.gpx"


def show(project, label):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    print("\nSTAGE", label)
    print("residuals", hist.residuals)
    print("mass", hist.ComputeMassFracs())
    print("inst", {k: inst[k] for k in ["Zero", "U", "W", "X", "SH/L"]})
    print("sample", {k: sample[k] for k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, "scale", hap["Scale"], "cell", phase.get_cell())
    cov = project.data.get("Covariance", {}).get("data", {})
    print("vary", list(zip(cov.get("varyList", []), cov.get("variables", []), cov.get("sig", []))))


def run():
    shutil.copyfile(SOURCE, TARGET)
    project = G2sc.G2Project(str(TARGET))
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)
    hist.data["Sample Parameters"]["Scale"][1] = False
    hist.data["Instrument Parameters"][0]["Zero"][2] = False
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 8,
        },
        "Sample Parameters": ["Shift"],
    })
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": False})
    project.refine()
    show(project, "background_scales_shift")

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine()
    show(project, "cells")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.refine()
    show(project, "common_profile")

    project.refine()
    show(project, "replay")
    project.save()


if __name__ == "__main__":
    run()
