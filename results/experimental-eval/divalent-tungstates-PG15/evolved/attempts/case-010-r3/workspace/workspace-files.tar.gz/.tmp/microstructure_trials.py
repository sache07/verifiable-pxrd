#!/usr/bin/env python3
"""Compare phase-specific isotropic size and strain against the neutral baseline."""

from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "physical_baseline.gpx"


def run_trial(phase_index, kind):
    label = f"{kind}_phase{phase_index}"
    target = ROOT / ".tmp" / f"trial_{label}.gpx"
    shutil.copyfile(BASE, target)
    project = G2sc.G2Project(str(target))
    project.set_Controls("cycles", 12)
    phase = project.phase(phase_index)
    hist = project.histogram(0)
    hap = phase.data["Histograms"][hist.name]
    if kind == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
        project.set_Controls("parmMin", 0.05, variable=f"{phase_index}:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{phase_index}:0:Size;i")
    elif kind == "strain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, variable=f"{phase_index}:0:Mustrain;i")
    else:
        raise ValueError(kind)
    project.refine()
    first = project.histogram(0).residuals["wR"]
    project.refine()
    replay = project.histogram(0).residuals["wR"]
    hap = project.phase(phase_index).data["Histograms"][project.histogram(0).name]
    print(
        "TRIAL", label,
        "phase", project.phase(phase_index).name,
        "wR", first, "replay", replay,
        "size", hap["Size"], "strain", hap["Mustrain"],
        "mass", project.histogram(0).ComputeMassFracs(),
        "frozen", project.get_Frozen(),
    )
    project.save()


def main():
    for phase_index in (0, 1):
        for kind in ("size", "strain"):
            run_trial(phase_index, kind)


if __name__ == "__main__":
    main()
