#!/usr/bin/env python3
"""Build and refine a restrained GSAS-II trial model for phase screening."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)

PHASES = {
    "znwo4": ("ZnWO4", "1520641"),
    "zno": ("ZnO", "9004178"),
    "wo3_mon_old": ("WO3_mon_old", "1528915"),
    "wo3_mon_neutron": ("WO3_mon_neutron", "2311041"),
    "wo3_tric": ("WO3_tric", "2106293"),
    "wo3_old_subcell": ("WO3_old_subcell", "1010618"),
    "wo3_hp_record": ("WO3_hp_record", "1563541"),
    "wo3_tet_130": ("WO3_tet_130", "1521532"),
    "wo3_tet_129": ("WO3_tet_129", "1521533"),
    "wo3_hex": ("WO3_hex", "1004057"),
    "wo3_ortho": ("WO3_ortho", "2107312"),
    "w18o49": ("W18O49", "1528166"),
}


def cif_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize_hap(phase, hist, scale: float) -> None:
    hap = phase.data["Histograms"][hist.name]
    # Large crystallite size and zero microstrain are profile-neutral.
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1.0e6, 1.0e6, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]
    hap["Scale"] = [scale, True]


def run_refinement(project, repeats: int = 2) -> None:
    for _ in range(repeats):
        project.refine(makeBack=False)
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        if rvals.get("converged") and rvals.get("Max shft/sig", 999.0) < 0.2:
            break


def build(args) -> dict:
    out = Path(args.output).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(Path("inputs/pattern.csv").resolve()),
        str(Path("instrument.instprm").resolve()),
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-160.0, False]
    for key in ("DisplaceX", "DisplaceY", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in hist.SampleParameters:
            hist.SampleParameters[key][0] = 0.0
            hist.SampleParameters[key][1] = False

    inst = hist.InstrumentParameters
    common_profile = {
        "U": 0.0,
        "V": 0.0,
        "W": 85.5201584417,
        "X": 4.52475057995,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.08268960385,
    }
    starting_profile = common_profile if args.fixed_profile else {
        "U": 0.0,
        "V": 0.0,
        "W": 100.0,
        "X": 5.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.02,
    }
    for key, value in starting_profile.items():
        inst[key][1] = value
        inst[key][2] = False

    phases = []
    for i, key in enumerate(args.phases):
        name, cod_id = PHASES[key]
        phase = project.add_phase(
            str(cif_path(cod_id)), phasename=name, histograms=[hist]
        )
        neutralize_hap(phase, hist, 10.0 if i == 0 else 1.0)
        phases.append(phase)

    if args.fixed_profile:
        hist.SampleParameters["SurfRoughA"] = [0.1634159085, False]
        hist.SampleParameters["SurfRoughB"] = [0.8253856144, False]
        bkg_coeffs = [
            577.17518965, -684.12765315, 492.73232674, -273.40615945,
            147.84106780, -76.45619333, 47.48038090, -35.10551966,
            22.49351990, -7.65119493,
        ]
    else:
        bkg_coeffs = [700.0, -550.0, 400.0, -200.0, 90.0, -20.0]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": len(bkg_coeffs),
                "coeffs": bkg_coeffs,
            }
        }
    )
    project.set_Controls("cycles", 15)
    project.save()

    # Stage 1: establish background and all phase scales.
    run_refinement(project, 2)

    # Stage 2: one specimen-height correction plus all cells.
    hist.SampleParameters["Shift"][1] = True
    for phase in phases:
        phase.data["General"]["Cell"][0] = True
    run_refinement(project, 3)

    if not args.fixed_profile:
        # Stage 3: common nonnegative candidate profile. U and V stay neutral.
        inst["W"][2] = True
        inst["X"][2] = True
        run_refinement(project, 3)

        # Repeating low-angle asymmetry warrants one common axial-divergence term.
        inst["SH/L"][2] = True
        run_refinement(project, 3)
    project.save()

    # Reopen and replay to ensure serialization does not alter the result.
    project = G2sc.G2Project(str(out))
    project.set_Controls("cycles", 15)
    run_refinement(project, 2)
    project.save()
    hist = project.histogram(0)

    try:
        fractions = hist.ComputeMassFracs()
    except Exception as exc:  # Trial summaries should still be usable.
        fractions = {"error": str(exc)}

    summary = {
        "project": str(out),
        "phases": list(args.phases),
        "residuals": hist.residuals,
        "mass_fractions": fractions,
        "profile": {
            key: hist.InstrumentParameters[key][1]
            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "shift_um": hist.SampleParameters["Shift"][0],
        "background": hist.Background[0],
        "phase_details": {},
        "frozen": project.get_Frozen(),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        summary["phase_details"][phase.name] = {
            "scale": hap["Scale"][0],
            "cell": phase.get_cell(),
        }

    summary_path = out.with_suffix(".json")
    summary_path.write_text(json.dumps(summary, indent=2, default=float) + "\n")
    print("TRIAL_SUMMARY", json.dumps(summary, default=float))
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--fixed-profile",
        action="store_true",
        help="hold the accepted common W/X/SH-L profile fixed for inventory tests",
    )
    parser.add_argument("output")
    parser.add_argument("phases", nargs="+", choices=sorted(PHASES))
    build(parser.parse_args())


if __name__ == "__main__":
    main()
