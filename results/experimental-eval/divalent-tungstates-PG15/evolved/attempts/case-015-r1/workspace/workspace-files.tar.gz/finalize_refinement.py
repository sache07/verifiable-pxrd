#!/usr/bin/env python3
"""Replay the accepted model and export project-consistent deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/trials/wo3_uniax_100.gpx"
FINAL = ROOT / "final.gpx"


def converge(project: G2sc.G2Project, repeats: int = 5) -> None:
    project.set_Controls("cycles", 25)
    for _ in range(repeats):
        project.refine(makeBack=False)
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        if rvals.get("converged") and rvals.get("Max shft/sig", 999.0) < 0.1:
            break


def normalize_model(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Limits"][1][:] = list(hist.data["Limits"][0])
    hist.Excluded([])

    # One angular correction (specimen height); all alternatives remain neutral.
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"][1] = True
    for key in ("DisplaceX", "DisplaceY", "Transparency"):
        hist.SampleParameters[key] = [0.0, False]
    hist.SampleParameters["SurfRoughA"][1] = True
    hist.SampleParameters["SurfRoughB"][1] = True

    inst = hist.InstrumentParameters
    for key in ("U", "V", "Y", "Z", "Zero"):
        inst[key][1] = 0.0
        inst[key][2] = False
    for key in ("W", "X", "SH/L"):
        inst[key][2] = True
    inst["Polariz."][1:] = [0.5, False]
    inst["I(L2)/I(L1)"][1:] = [0.5, False]

    # Ten terms remain smooth over this unusually wide 90-degree range.
    bkg = hist.Background
    bkg[0][0] = "chebyschev-1"
    bkg[0][1] = True
    bkg[0][2] = 10
    bkg[1]["nDebye"] = 0
    bkg[1]["debyeTerms"] = []
    bkg[1]["nPeaks"] = 0
    bkg[1]["peaksList"] = []
    bkg[1].pop("FixedPoints", None)

    for i, phase in enumerate(project.phases()):
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["LeBail"] = False
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        if i == 1:  # Monoclinic WO3: accepted [100] uniaxial strain.
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][2][:] = [True, True, False]
            hap["Mustrain"][3] = [1, 0, 0]
        else:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
            hap["Mustrain"][2][:] = [False, False, False]
        for atom in phase.atoms():
            atom.refinement_flags = ""


def serializable(value):
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    raise TypeError(type(value).__name__)


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    normalize_model(project)
    project.save()
    converge(project)
    project.save()

    # Required serialization replay over the complete measured range.
    project = G2sc.G2Project(str(FINAL))
    normalize_model(project)
    converge(project)
    project.save()

    # Reopen once more so every export is sourced from the submitted file.
    project = G2sc.G2Project(str(FINAL))
    hist = project.histogram(0)
    frozen = project.get_Frozen()
    if frozen:
        raise RuntimeError(f"Final project contains frozen variables: {frozen}")

    cif_names = {
        "ZnWO4": "phase_1_ZnWO4.cif",
        "WO3_mon_neutron": "phase_2_WO3.cif",
        "ZnO": "phase_3_ZnO.cif",
    }
    for phase in project.phases():
        phase.export_CIF(str(ROOT / cif_names[phase.name]))

    x, obs, weight, calc, bkg, diff = [
        np.asarray(v) for v in hist.data["data"][1]
    ]
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_intensity",
                "background_intensity",
                "weight",
            ]
        )
        writer.writerows(zip(x, obs, calc, diff, bkg, weight))

    fractions = hist.ComputeMassFracs()
    cov = project.data["Covariance"]["data"]
    summary = {
        "project": str(FINAL.relative_to(ROOT)),
        "histogram": hist.name,
        "range_deg": [float(x[0]), float(x[-1])],
        "residuals": hist.residuals,
        "Rvals": cov.get("Rvals", {}),
        "profile": {
            key: hist.InstrumentParameters[key][1]
            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample": {
            key: hist.SampleParameters[key][0]
            for key in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "background": hist.Background[0],
        "fractions": fractions,
        "phases": {},
        "cif_names": cif_names,
        "frozen": frozen,
    }
    for phase in project.phases():
        cell, cell_esd = phase.get_cell_and_esd()
        hap = phase.data["Histograms"][hist.name]
        summary["phases"][phase.name] = {
            "composition": phase.composition,
            "density_g_cm3": phase.density,
            "cell": cell,
            "cell_esd": cell_esd,
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    (ROOT / ".tmp/final_summary.json").write_text(
        json.dumps(summary, indent=2, default=serializable) + "\n"
    )
    print("FINAL_SUMMARY", json.dumps(summary, default=serializable))


if __name__ == "__main__":
    main()
