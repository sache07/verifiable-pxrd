#!/usr/bin/env python3
"""Physical and crystallographic checks for the submitted CIFs."""

from __future__ import annotations

from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


for filename in ("MgWO4.cif", "WO3.cif", "MgO.cif"):
    structure = Structure.from_file(filename)
    analyzer = SpacegroupAnalyzer(structure, symprec=1.0e-3, angle_tolerance=1.0)
    print(
        filename,
        "formula=", structure.composition.reduced_formula,
        "sites=", len(structure),
        "SG=", analyzer.get_space_group_symbol(), analyzer.get_space_group_number(),
        "volume=", structure.volume,
    )
    distance_matrix = np.asarray(structure.distance_matrix)
    distance_matrix[distance_matrix < 1.0e-8] = np.inf
    print("  shortest interatomic distance", float(distance_matrix.min()))
    seen = set()
    for site in structure:
        symbol = site.specie.symbol
        if symbol not in {"Mg", "W"} or symbol in seen:
            continue
        seen.add(symbol)
        oxygen_distances = sorted(
            neighbor.nn_distance
            for neighbor in structure.get_neighbors(site, 3.0)
            if neighbor.specie.symbol == "O"
        )
        print(
            f"  {symbol}-O neighbors through 3.0 A:",
            len(oxygen_distances),
            [round(value, 4) for value in oxygen_distances],
        )
