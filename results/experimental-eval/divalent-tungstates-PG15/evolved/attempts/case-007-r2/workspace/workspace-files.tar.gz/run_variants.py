#!/usr/bin/env python3
"""Replay controlled one-at-a-time refinements from a common GSAS-II model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Callable

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("base", type=Path)
parser.add_argument(
    "--suite",
    choices=("baseline", "profile", "polarization", "broadening", "texture"),
    required=True,
)
parser.add_argument("--tag", default="test")
args = parser.parse_args()

G2sc.SetPrintLevel("none")


def shl(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.InstrumentParameters["SH/L"][1] = 0.01
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})


def specimen_shift(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.InstrumentParameters["Zero"] = [0.0, 0.0, False]
    hist.SampleParameters["Shift"] = [-530.0, True]


def background_order(order: int) -> Callable[[G2sc.G2Project], None]:
    def apply(project: G2sc.G2Project) -> None:
        hist = project.histogram(0)
        coeffs = list(hist.Background[0][3:])
        coeffs = (coeffs + [0.0] * order)[:order]
        hist.set_refinements(
            {
                "Background": {
                    "type": "chebyschev-1",
                    "refine": True,
                    "no. coeffs": order,
                    "coeffs": coeffs,
                }
            }
        )

    return apply


def polarization(value: float) -> Callable[[G2sc.G2Project], None]:
    def apply(project: G2sc.G2Project) -> None:
        par = project.histogram(0).InstrumentParameters["Polariz."]
        par[0] = value
        par[1] = value
        par[2] = False

    return apply


def phase_size(phase_name: str | int) -> Callable[[G2sc.G2Project], None]:
    def apply(project: G2sc.G2Project) -> None:
        phase = project.phase(phase_name)
        hist = project.histogram(0)
        size = phase.data["Histograms"][hist.name]["Size"]
        size[0] = "isotropic"
        size[1][0] = 2.0
        size[1][2] = 0.5
        size[2] = [True, False, False]

    return apply


def phase_strain(phase_name: str | int) -> Callable[[G2sc.G2Project], None]:
    def apply(project: G2sc.G2Project) -> None:
        phase = project.phase(phase_name)
        hist = project.histogram(0)
        strain = phase.data["Histograms"][hist.name]["Mustrain"]
        strain[0] = "isotropic"
        strain[1][0] = 100.0
        strain[1][2] = 0.5
        strain[2] = [True, False, False]

    return apply


def texture(phase_name: str, axis: tuple[int, int, int]) -> Callable[[G2sc.G2Project], None]:
    def apply(project: G2sc.G2Project) -> None:
        phase = project.phase(phase_name)
        hist = project.histogram(0)
        pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
        pref[0] = "MD"
        pref[1] = 1.0
        pref[2] = True
        pref[3] = list(axis)

    return apply


baseline_variants = {
    "shl": shl,
    "specimen_shift": specimen_shift,
    "background_4": background_order(4),
    "background_8": background_order(8),
    "polarization_0p3": polarization(0.3),
    "polarization_0p7": polarization(0.7),
    "polarization_0p9": polarization(0.9),
}

broadening_variants = {}
for phase_index, short in ((0, "MgWO4"), (1, "WO3"), (2, "MgO")):
    broadening_variants[f"{short}_size"] = phase_size(phase_index)
    broadening_variants[f"{short}_strain"] = phase_strain(phase_index)

texture_variants = {}
for phase_name, axes in {
    "MgWO4_wolframite": ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1), (1, 1, 1)),
    "WO3_monoclinic": ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1), (1, 1, 1)),
    "MgO_periclase": ((1, 0, 0), (1, 1, 0), (1, 1, 1)),
}.items():
    short = phase_name.split("_")[0]
    for axis in axes:
        key = "".join(str(v) for v in axis)
        texture_variants[f"{short}_MD_{key}"] = texture(phase_name, axis)

variants = {
    "baseline": baseline_variants,
    "profile": {
        "shl": shl,
        "specimen_shift": specimen_shift,
        "background_4": background_order(4),
        "background_7": background_order(7),
        "background_8": background_order(8),
    },
    "polarization": {
        f"polarization_{str(value).replace('.', 'p')}": polarization(value)
        for value in (0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95, 1.00)
    },
    "broadening": broadening_variants,
    "texture": texture_variants,
}[args.suite]


def summarize(project: G2sc.G2Project, name: str, path: Path) -> dict:
    hist = project.histogram(0)
    result = {
        "name": name,
        "gpx": str(path),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Polariz.", "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample_shift_micrometres": hist.SampleParameters["Shift"][0],
        "background": list(hist.Background[0]),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    return result


outdir = ROOT / ".tmp" / "variants" / args.tag
outdir.mkdir(parents=True, exist_ok=True)
results = []
for name, configure in variants.items():
    path = outdir / f"{name}.gpx"
    project = G2sc.G2Project(str(args.base), newgpx=str(path))
    project.data["Controls"]["data"]["max cyc"] = 12
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    configure(project)
    project.save()
    project.refine(makeBack=False)
    project.save()
    project = G2sc.G2Project(str(path))
    project.refine(makeBack=False)
    project.save()
    result = summarize(project, name, path)
    results.append(result)
    print(
        f"{name:24s} Rwp={result['residuals']['wR']:.6f} "
        f"fractions={result['mass_fractions']}"
    )

summary_path = outdir / "summary.json"
summary_path.write_text(json.dumps(results, indent=2, default=float) + "\n")
print(f"summary={summary_path}")
