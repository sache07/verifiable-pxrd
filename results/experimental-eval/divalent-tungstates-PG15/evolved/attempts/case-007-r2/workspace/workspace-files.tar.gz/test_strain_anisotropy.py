#!/usr/bin/env python3
"""Challenge isotropic microstrain with one-extra-parameter uniaxial models."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output_dir", type=Path)
args = parser.parse_args()

G2sc.SetPrintLevel("none")
args.output_dir.mkdir(parents=True, exist_ok=True)

axes = (
    (1, 0, 0),
    (0, 1, 0),
    (0, 0, 1),
    (1, 1, 0),
    (1, 0, 1),
    (0, 1, 1),
    (1, 1, 1),
)
phase_names = ("MgWO4_wolframite", "WO3_monoclinic_equiv_P21c")
results = []

for phase_name in phase_names:
    for axis in axes:
        axis_tag = "".join(str(value) for value in axis)
        path = args.output_dir / f"{phase_name.split('_')[0]}_uniaxial_{axis_tag}.gpx"
        project = G2sc.G2Project(str(args.source), newgpx=str(path))
        project.data["Controls"]["data"]["max cyc"] = 16
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
        hist = project.histogram(0)
        strain = project.phase(phase_name).data["Histograms"][hist.name]["Mustrain"]
        isotropic = float(strain[1][0])
        strain[0] = "uniaxial"
        strain[1][0] = isotropic
        strain[1][1] = isotropic
        strain[2] = [True, True, False]
        strain[3] = list(axis)
        project.save()

        for _ in range(2):
            project = G2sc.G2Project(str(path))
            project.refine(makeBack=False)
            project.save()

        hist = project.histogram(0)
        strain = project.phase(phase_name).data["Histograms"][hist.name]["Mustrain"]
        row = {
            "phase": phase_name,
            "axis": axis,
            "Rwp": hist.residuals["wR"],
            "Rp": hist.residuals["R"],
            "equatorial_microstrain": strain[1][0],
            "axial_microstrain": strain[1][1],
            "fractions": hist.ComputeMassFracs(),
            "gpx": str(path),
        }
        results.append(row)
        print(json.dumps(row, default=float))

(args.output_dir / "summary.json").write_text(
    json.dumps(results, indent=2, default=float) + "\n"
)
