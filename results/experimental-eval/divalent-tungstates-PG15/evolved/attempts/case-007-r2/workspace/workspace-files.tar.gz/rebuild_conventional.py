#!/usr/bin/env python3
"""Rebuild the accepted model with WO3 in an equivalent low-skew basis."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from refine_baseline import cod_path, neutralize_hap


parser = argparse.ArgumentParser()
parser.add_argument("seed", type=Path)
parser.add_argument("wo3_cif", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--cycles", type=int, default=8)
args = parser.parse_args()

root = Path(__file__).resolve().parent
G2sc.SetPrintLevel("none")
seed = G2sc.G2Project(str(args.seed))
seed_hist = seed.histogram(0)

project = G2sc.G2Project(newgpx=str(args.output))
project.data["Controls"]["data"]["max cyc"] = 24
project.data["Controls"]["data"]["min dM/M"] = 1.0e-7
hist = project.add_powder_histogram(
    str(root / "inputs" / "pattern.csv"),
    str(root / "instrument.instprm"),
    fmthint="comma",
)
x = np.asarray(hist.getdata("X"))
hist.Limits("lower", float(x.min()))
hist.Limits("upper", float(x.max()))

# Copy the accepted common instrumental and sample model, with only U, X and
# SH/L active and one specimen-height correction. W is deliberately fixed at
# the nonnegative boundary after unconstrained trials drove it below zero.
for key in (
    "Lam1", "Lam2", "I(L2)/I(L1)", "Polariz.", "Zero",
    "U", "V", "W", "X", "Y", "Z", "SH/L",
):
    hist.InstrumentParameters[key] = copy.deepcopy(seed_hist.InstrumentParameters[key])
for key in ("U", "X", "SH/L"):
    hist.InstrumentParameters[key][2] = True
for key in ("Lam1", "Lam2", "I(L2)/I(L1)", "Polariz.", "Zero", "V", "W", "Y", "Z"):
    hist.InstrumentParameters[key][2] = False

hist.SampleParameters["Scale"] = [1.0, False]
hist.SampleParameters["Shift"] = [float(seed_hist.SampleParameters["Shift"][0]), True]
for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
    hist.SampleParameters[key] = [0.0, False]

background_coeffs = [float(v) for v in seed_hist.Background[0][3:]]
hist.set_refinements({
    "Background": {
        "type": "chebyschev-1",
        "refine": True,
        "no. coeffs": len(background_coeffs),
        "coeffs": background_coeffs,
    }
})

phase_specs = (
    ("MgWO4_wolframite", cod_path("9013902")),
    ("WO3_monoclinic_P21n", args.wo3_cif),
    ("MgO_periclase", cod_path("9000499")),
)
phases = []
for index, (name, cif_path) in enumerate(phase_specs):
    phase = project.add_phase(str(cif_path), phasename=name, histograms=[hist])
    neutralize_hap(phase, hist)
    hap = phase.data["Histograms"][hist.name]
    seed_hap = seed.phase(index).data["Histograms"][seed_hist.name]
    hap["Scale"] = [float(seed_hap["Scale"][0]), True]
    # Keep unused size, hydrostatic strain, extinction and roughness neutral.
    hap["Size"][1][0] = 10.0
    hap["Size"][1][1] = 10.0
    phase.set_refinements({"Cell": True})
    for atom in phase.atoms():
        atom.refinement_flags = " "
    phases.append(phase)

# Retain the replay-stable MgWO4 [110] March-Dollase term and the accepted
# phase broadening model from the seed. The WO3 [011] strain axis in the old
# skew basis maps to [110] in this equivalent basis.
mg_hap = phases[0].data["Histograms"][hist.name]
seed_mg_hap = seed.phase(0).data["Histograms"][seed_hist.name]
mg_hap["Pref.Ori."] = copy.deepcopy(seed_mg_hap["Pref.Ori."])
mg_hap["Mustrain"] = copy.deepcopy(seed_mg_hap["Mustrain"])

wo_hap = phases[1].data["Histograms"][hist.name]
seed_wo_hap = seed.phase(1).data["Histograms"][seed_hist.name]
wo_hap["Mustrain"] = copy.deepcopy(seed_wo_hap["Mustrain"])
wo_hap["Mustrain"][3] = [1, 1, 0]

# The neutron record has two independent W sites and six independent O sites.
# Refine one common W Uiso; keep O at a plausible fixed 0.008 A^2 after its
# common refinement was statistically weak.
w_indices = []
for index, atom in enumerate(phases[1].atoms()):
    if atom.element == "W":
        atom.uiso = 0.0077
        atom.refinement_flags = "U"
        w_indices.append(index)
    elif atom.element == "O":
        atom.uiso = 0.008
        atom.refinement_flags = " "
project.add_EquivConstr(
    [f"1::AUiso:{index}" for index in w_indices], reloadIdx=True
)

project.save()
history = []
for cycle in range(args.cycles):
    project = G2sc.G2Project(str(args.output))
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    covariance = project.data["Covariance"]["data"]
    row = {
        "cycle": cycle + 1,
        "Rwp": hist.residuals["wR"],
        "Rp": hist.residuals["R"],
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "converged": covariance.get("Rvals", {}).get("converged"),
        "message": covariance.get("Rvals", {}).get("msg"),
        "fractions": hist.ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }
    history.append(row)
    print(json.dumps(row, default=float))

Path(str(args.output) + ".replay.json").write_text(
    json.dumps(history, indent=2, default=float) + "\n"
)
