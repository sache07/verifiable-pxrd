#!/usr/bin/env python3
"""Test physically plausible common WO3 displacement parameters."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "wo3_w0" / "monoclinic_equiv_P21c.gpx"
OUT = ROOT / ".tmp" / "wo3_adp"
OUT.mkdir(parents=True, exist_ok=True)
G2sc.SetPrintLevel("none")


def configure(project: G2sc.G2Project, mode: str) -> None:
    phase = project.phase(1)
    w_indices = []
    o_indices = []
    for index, atom in enumerate(phase.atoms()):
        if atom.element == "W":
            atom.uiso = 0.005
            atom.refinement_flags = "U" if mode in ("W_refined", "W_O_refined") else " "
            w_indices.append(index)
        elif atom.element == "O":
            atom.uiso = 0.008
            atom.refinement_flags = "U" if mode == "W_O_refined" else " "
            o_indices.append(index)
    if mode in ("W_refined", "W_O_refined"):
        project.add_EquivConstr(
            [f"1::AUiso:{index}" for index in w_indices], reloadIdx=True
        )
    if mode == "W_O_refined":
        project.add_EquivConstr(
            [f"1::AUiso:{index}" for index in o_indices], reloadIdx=True
        )


results = []
for mode in ("fixed_plausible", "W_refined", "W_O_refined"):
    output = OUT / f"{mode}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
    project.data["Controls"]["data"]["max cyc"] = 16
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    configure(project, mode)
    project.save()
    history = []
    for cycle in range(7):
        project = G2sc.G2Project(str(output))
        project.refine(makeBack=False)
        project.save()
        history.append(project.histogram(0).residuals["wR"])
    hist = project.histogram(0)
    phase = project.phase(1)
    covariance = project.data["Covariance"]["data"]
    adp_vars = {}
    for index, variable in enumerate(covariance.get("varyList", [])):
        if "AUiso" in variable:
            adp_vars[variable] = {
                "value": covariance["variables"][index],
                "sigma": covariance["sig"][index],
            }
    result = {
        "mode": mode,
        "output": str(output),
        "history": history,
        "residuals": hist.residuals,
        "fractions": hist.ComputeMassFracs(),
        "adps": {atom.label: atom.uiso for atom in phase.atoms()},
        "adp_variables": adp_vars,
    }
    results.append(result)
    print(
        f"{mode:18s} Rwp={hist.residuals['wR']:.6f} "
        f"fractions={result['fractions']} ADPs={result['adps']} vars={adp_vars}"
    )

(OUT / "summary.json").write_text(json.dumps(results, indent=2, default=float) + "\n")
