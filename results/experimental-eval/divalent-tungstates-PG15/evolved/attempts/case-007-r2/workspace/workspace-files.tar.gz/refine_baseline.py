#!/usr/bin/env python3
"""Build and refine the three-phase, common-profile GSAS-II baseline."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
CIF_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
PHASES = (
    ("MgWO4_wolframite", "9013902"),
    ("WO3_monoclinic", "1528915"),
    ("MgO_periclase", "9000499"),
)


def cod_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize_hap(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData) -> None:
    """Remove default phase-specific broadening and texture contributions."""
    hap = phase.data["Histograms"][hist.name]
    size = hap["Size"]
    size[0] = "isotropic"
    size[1][0] = 1.0e6
    size[1][1] = 1.0e6
    size[1][2] = 0.5
    size[2] = [False for _ in size[2]]
    mustrain = hap["Mustrain"]
    mustrain[0] = "isotropic"
    mustrain[1][0] = 0.0
    mustrain[1][1] = 0.0
    mustrain[1][2] = 0.5
    mustrain[2] = [False for _ in mustrain[2]]
    mustrain[5] = [False for _ in mustrain[5]]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    out = {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "background": list(hist.Background[0]),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "scale": hap["Scale"][0],
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    try:
        out["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    print(json.dumps(out, indent=2, default=float))
    return out


def refine(project: G2sc.G2Project, label: str) -> dict:
    print(f"\n===== {label} =====")
    project.refine(makeBack=False)
    project.save()
    return snapshot(project, label)


def main() -> None:
    TMP.mkdir(exist_ok=True)
    gpx_path = TMP / "baseline.gpx"
    project = G2sc.G2Project(newgpx=str(gpx_path))
    project.data["Controls"]["data"]["max cyc"] = 12
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    sample = hist.SampleParameters
    sample["Scale"] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key] = [0.0, False]

    inst = hist.InstrumentParameters
    inst["Zero"] = [0.32, 0.32, False]
    inst["U"] = [100.0, 100.0, False]
    inst["V"] = [0.0, 0.0, False]
    inst["W"] = [40.0, 40.0, False]
    inst["X"] = [1.0, 1.0, False]
    inst["Y"] = [0.0, 0.0, False]
    inst["Z"] = [0.0, 0.0, False]
    inst["SH/L"] = [0.002, 0.002, False]

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": [900.0, -650.0, 300.0, -120.0, 40.0, 0.0],
            }
        }
    )
    phases = []
    for name, cod_id in PHASES:
        phase = project.add_phase(
            str(cod_path(cod_id)), phasename=name, histograms=[hist]
        )
        neutralize_hap(phase, hist)
        phase.set_HAP_refinements({"Scale": True})
        phases.append(phase)

    # Approximate starting phase fractions; all are immediately refined.
    phases[0].data["Histograms"][hist.name]["Scale"][0] = 1.0
    phases[1].data["Histograms"][hist.name]["Scale"][0] = 0.2
    phases[2].data["Histograms"][hist.name]["Scale"][0] = 0.1
    project.save()

    history = [refine(project, "background_and_scales")]
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    history.append(refine(project, "add_zero"))
    for phase in phases:
        phase.set_refinements({"Cell": True})
    history.append(refine(project, "add_cells"))
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    history.append(refine(project, "add_common_U_W_X"))
    history.append(refine(project, "common_profile_reconverged"))

    # Save/reopen and replay the same full-range model.
    project.save()
    project = G2sc.G2Project(str(gpx_path))
    history.append(refine(project, "reopened_full_range_replay"))
    (TMP / "baseline_history.json").write_text(
        json.dumps(history, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    main()
