#!/usr/bin/env python3
"""Print selected refined variables and standard uncertainties from a GPX file."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("gpx", type=Path)
args = parser.parse_args()

project = G2sc.G2Project(str(args.gpx))
covariance = project.data["Covariance"]["data"]
rows = []
for name, value, sigma in zip(
    covariance.get("varyList", []),
    covariance.get("variables", []),
    covariance.get("sig", []),
):
    rows.append({"name": name, "value": value, "sigma": sigma})

print(json.dumps({
    "Rvals": covariance.get("Rvals", {}),
    "variables": rows,
}, indent=2, default=float))
