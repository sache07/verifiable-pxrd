#!/usr/bin/env python3
"""Compare low-symmetry WO3 records with the same ADP/profile model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
OUT = ROOT / ".tmp" / "wo3_adp_compare"
SOURCES = (
    ROOT / ".tmp" / "wo3_w0" / "monoclinic_RT_P21n.gpx",
    ROOT / ".tmp" / "wo3_w0" / "monoclinic_equiv_P21c.gpx",
    ROOT / ".tmp" / "wo3_w0" / "triclinic_P-1.gpx",
)

OUT.mkdir(parents=True, exist_ok=True)
G2sc.SetPrintLevel("none")
results = []
for source in SOURCES:
    output = OUT / source.name
    project = G2sc.G2Project(str(source), newgpx=str(output))
    project.data["Controls"]["data"]["max cyc"] = 16
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = project.histogram(0)
    hist.InstrumentParameters["Polariz."] = [0.75, 0.75, False]
    phase = project.phase(1)
    w_indices = []
    o_indices = []
    for index, atom in enumerate(phase.atoms()):
        if atom.element == "W":
            atom.uiso = 0.0135
            atom.refinement_flags = "U"
            w_indices.append(index)
        elif atom.element == "O":
            atom.uiso = 0.016
            atom.refinement_flags = "U"
            o_indices.append(index)
    project.add_EquivConstr(
        [f"1::AUiso:{index}" for index in w_indices], reloadIdx=True
    )
    project.add_EquivConstr(
        [f"1::AUiso:{index}" for index in o_indices], reloadIdx=True
    )
    project.save()
    history = []
    for cycle in range(7):
        project = G2sc.G2Project(str(output))
        project.refine(makeBack=False)
        project.save()
        history.append(project.histogram(0).residuals["wR"])
    hist = project.histogram(0)
    covariance = project.data["Covariance"]["data"]
    adp_vars = {
        variable: {
            "value": covariance["variables"][index],
            "sigma": covariance["sig"][index],
        }
        for index, variable in enumerate(covariance.get("varyList", []))
        if "AUiso" in variable
    }
    result = {
        "source": str(source),
        "output": str(output),
        "history": history,
        "residuals": hist.residuals,
        "fractions": hist.ComputeMassFracs(),
        "adp_variables": adp_vars,
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Polariz.", "Zero", "U", "W", "X", "SH/L")
        },
    }
    results.append(result)
    print(
        f"{source.stem:32s} Rwp={hist.residuals['wR']:.6f} "
        f"fractions={result['fractions']} ADPs={adp_vars}"
    )

(OUT / "summary.json").write_text(json.dumps(results, indent=2, default=float) + "\n")
