#!/usr/bin/env python3
"""Write COD 2311041 in a low-skew equivalent monoclinic basis."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()

source = Structure.from_file(args.source)
old = np.asarray(source.lattice.matrix)
# a' = a + c, b' = b, c' = -a is unimodular and converts the skew
# P21/c representation (beta about 136 degrees) to the usual P21/n-like
# low-skew representation (beta about 91 degrees).
new = np.vstack((old[0] + old[2], old[1], -old[0]))
transformed = Structure(
    Lattice(new),
    source.species,
    source.cart_coords,
    coords_are_cartesian=True,
    to_unit_cell=True,
    site_properties=source.site_properties,
)
args.output.parent.mkdir(parents=True, exist_ok=True)
CifWriter(
    transformed,
    symprec=0.01,
    angle_tolerance=1.0,
    refine_struct=False,
).write_file(args.output)
# pymatgen reports every setting of space-group No. 14 with the standard
# P21/c label. This transformed operator set is the P21/n setting, which must
# be named explicitly for GSAS-II's CIF symmetry validation.
cif_text = args.output.read_text()
cif_text = cif_text.replace(
    "_symmetry_space_group_name_H-M   P2_1/c",
    "_symmetry_space_group_name_H-M   'P 1 21/n 1'",
)
# GSAS-II's CIF reader gives the International Tables number precedence over
# the explicit setting name and would map 14 back to standard P21/c. Omit the
# redundant number so that the setting-specific P21/n symbol is respected.
cif_text = "\n".join(
    line for line in cif_text.splitlines()
    if not line.startswith("_symmetry_Int_Tables_number")
) + "\n"
args.output.write_text(cif_text)

check = Structure.from_file(args.output)
analyzer = SpacegroupAnalyzer(check, symprec=0.01, angle_tolerance=1.0)
print("cell", check.lattice.abc, check.lattice.angles, check.volume)
print("space_group", analyzer.get_space_group_symbol(), analyzer.get_space_group_number())
print("composition", check.composition, "sites", len(check))
