#!/usr/bin/env python3
"""Re-refine saved candidate projects with a fixed nonnegative W profile term."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("sources", nargs="+", type=Path)
parser.add_argument("--outdir", type=Path, required=True)
parser.add_argument("--w", type=float, default=0.0)
parser.add_argument("--cycles", type=int, default=6)
args = parser.parse_args()

G2sc.SetPrintLevel("none")
args.outdir.mkdir(parents=True, exist_ok=True)
results = []
for source in args.sources:
    output = args.outdir / source.name
    project = G2sc.G2Project(str(source), newgpx=str(output))
    project.data["Controls"]["data"]["max cyc"] = 16
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = project.histogram(0)
    hist.InstrumentParameters["W"] = [args.w, args.w, False]
    for key in ("V", "Y", "Z"):
        hist.InstrumentParameters[key] = [0.0, 0.0, False]
    hist.set_refinements({"Instrument Parameters": ["Zero", "U", "X", "SH/L"]})
    project.save()
    history = []
    for cycle in range(args.cycles):
        project = G2sc.G2Project(str(output))
        project.refine(makeBack=False)
        project.save()
        hist = project.histogram(0)
        history.append(
            {
                "cycle": cycle + 1,
                "Rwp": hist.residuals["wR"],
                "instrument": {
                    key: hist.InstrumentParameters[key][1]
                    for key in ("Zero", "U", "W", "X", "SH/L")
                },
            }
        )
    hist = project.histogram(0)
    result = {
        "source": str(source),
        "output": str(output),
        "history": history,
        "residuals": hist.residuals,
        "fractions": hist.ComputeMassFracs(),
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }
    results.append(result)
    print(
        f"{source.stem:32s} W={args.w:g} Rwp={hist.residuals['wR']:.6f} "
        f"U={result['instrument']['U']:.5g} X={result['instrument']['X']:.5g} "
        f"SHL={result['instrument']['SH/L']:.5g}"
    )

(args.outdir / "summary.json").write_text(
    json.dumps(results, indent=2, default=float) + "\n"
)
