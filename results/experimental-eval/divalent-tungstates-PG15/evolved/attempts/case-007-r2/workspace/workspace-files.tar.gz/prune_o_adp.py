#!/usr/bin/env python3
"""Fix the weakly supported WO3 oxygen ADP and replay the model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()

G2sc.SetPrintLevel("none")
project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
project.data["Controls"]["data"]["max cyc"] = 16
project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
phase = project.phase(1)
for atom in phase.atoms():
    if atom.element == "O":
        atom.uiso = 0.008
        atom.refinement_flags = " "

# The W equivalence has two atom terms; the O equivalence has six.
constraints = project.get_Constraints("Phase")
constraints[:] = [constraint for constraint in constraints if len(constraint) <= 5]
project.save()

history = []
for cycle in range(8):
    project = G2sc.G2Project(str(args.output))
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    history.append(
        {
            "cycle": cycle + 1,
            "Rwp": hist.residuals["wR"],
            "fractions": hist.ComputeMassFracs(),
        }
    )
    print(json.dumps(history[-1], default=float))

(Path(str(args.output) + ".replay.json")).write_text(
    json.dumps(history, indent=2, default=float) + "\n"
)
