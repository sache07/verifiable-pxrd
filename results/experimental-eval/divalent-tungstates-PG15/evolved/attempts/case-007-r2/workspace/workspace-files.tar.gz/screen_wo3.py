#!/usr/bin/env python3
"""Rebuild the inventory to compare physical WO3 polymorph records."""

from __future__ import annotations

import json
import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_baseline import neutralize_hap


ROOT = Path(__file__).resolve().parent
OUT = ROOT / ".tmp" / "wo3_screen"
CIF_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
CANDIDATES = (
    ("monoclinic_RT_P21n", "1528915"),
    ("monoclinic_equiv_P21c", "2311041"),
    ("triclinic_P-1", "2106293"),
    ("old_triclinic_model", "1010618"),
    ("orthorhombic_Pnma", "2107312"),
    ("high_pressure_P21c", "1563541"),
    ("tetragonal_P4ncc", "1521532"),
    ("tetragonal_P4nmm", "1521533"),
    ("hexagonal_P6mmm", "1004057"),
)

parser = argparse.ArgumentParser()
parser.add_argument("--only", nargs="*")
args = parser.parse_args()


def cod_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make_project(label: str, cod_id: str) -> tuple[G2sc.G2Project, Path]:
    path = OUT / f"{label}.gpx"
    project = G2sc.G2Project(newgpx=str(path))
    project.data["Controls"]["data"]["max cyc"] = 16
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    hist.SampleParameters["Scale"] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key] = [0.0, False]

    inst = hist.InstrumentParameters
    for key, value in {
        "Polariz.": 0.8,
        "Zero": 0.3414,
        "U": 57.63,
        "V": 0.0,
        "W": 11.62,
        "X": 8.15,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.0318,
    }.items():
        inst[key][0] = value
        inst[key][1] = value
        inst[key][2] = False
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": [705.0, -620.0, 402.0, -220.0, 118.0, -45.0],
            }
        }
    )

    phase_defs = (
        ("MgWO4_wolframite", "9013902", 77.5),
        (f"WO3_{label}", cod_id, 4.1),
        ("MgO_periclase", "9000499", 24.2),
    )
    phases = []
    for name, phase_id, scale in phase_defs:
        phase = project.add_phase(
            str(cod_path(phase_id)), phasename=name, histograms=[hist]
        )
        neutralize_hap(phase, hist)
        phase.data["Histograms"][hist.name]["Scale"] = [scale, True]
        phases.append(phase)
    pref = phases[0].data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.08446
    pref[2] = True
    pref[3] = [1, 1, 0]
    project.save()
    return project, path


def summarize(project: G2sc.G2Project, label: str, cod_id: str, path: Path) -> dict:
    hist = project.histogram(0)
    wo3 = project.phase(1)
    result = {
        "label": label,
        "cod_id": cod_id,
        "gpx": str(path),
        "residuals": hist.residuals,
        "WO3_scale": wo3.data["Histograms"][hist.name]["Scale"][0],
        "WO3_cell": wo3.get_cell(),
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Zero", "U", "W", "X", "SH/L")
        },
    }
    try:
        result["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        result["mass_fraction_error"] = repr(exc)
    return result


G2sc.SetPrintLevel("none")
OUT.mkdir(parents=True, exist_ok=True)
results = []
selected = [row for row in CANDIDATES if not args.only or row[0] in args.only]
for label, cod_id in selected:
    try:
        project, path = make_project(label, cod_id)
        # First fit only the smooth background and all scales under the common profile.
        project.refine(makeBack=False)
        project.save()
        # Then reconverge the single angular correction, cells and common profile.
        hist = project.histogram(0)
        hist.set_refinements(
            {"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L"]}
        )
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
        project.save()
        for _ in range(4):
            project = G2sc.G2Project(str(path))
            project.refine(makeBack=False)
            project.save()
        result = summarize(project, label, cod_id, path)
        print(
            f"{label:28s} COD={cod_id} Rwp={result['residuals']['wR']:.5f} "
            f"WO3_scale={result['WO3_scale']:.6g}"
        )
    except Exception as exc:
        result = {"label": label, "cod_id": cod_id, "error": repr(exc)}
        print(f"{label:28s} COD={cod_id} ERROR={exc!r}")
    results.append(result)
    (OUT / "summary.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )
