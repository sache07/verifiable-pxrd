#!/usr/bin/env python3
"""Create a scratch GSAS-II project and print default refinement state."""

from pathlib import Path

import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


project = G2sc.G2Project(newgpx=str(ROOT / ".tmp" / "inspect.gpx"))
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "instrument.instprm"),
    fmthint="comma",
)
for name, cod_id in (
    ("MgWO4_wolframite", "9013902"),
    ("WO3_monoclinic", "1528915"),
    ("MgO_periclase", "9000499"),
):
    phase = project.add_phase(
        str(cod_path(cod_id)), phasename=name, histograms=[hist]
    )
    hap = phase.data["Histograms"][hist.name]
    print("PHASE", name)
    print(" composition", phase.composition)
    print(" cell", phase.get_cell())
    print(" scale", hap["Scale"])
    print(" size", hap["Size"])
    print(" mustrain", hap["Mustrain"])
    print(" pref ori", hap["Pref.Ori."])
print("HIST", hist.name)
print("sample", hist.data["Sample Parameters"])
print("instrument", hist.data["Instrument Parameters"])
print("background", hist.data["Background"])
print("limits", hist.data["Limits"])
project.save()
