#!/usr/bin/env python3
"""Repeatedly save, reopen, and refine a GSAS-II project to test replay stability."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--cycles", type=int, default=8)
args = parser.parse_args()

G2sc.SetPrintLevel("none")
project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
project.data["Controls"]["data"]["max cyc"] = 16
project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
project.save()

history = []
for index in range(args.cycles):
    project = G2sc.G2Project(str(args.output))
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    row = {
        "cycle": index + 1,
        "Rwp": hist.residuals["wR"],
        "Rp": hist.residuals["R"],
        "fractions": hist.ComputeMassFracs(),
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Polariz.", "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "shift": hist.SampleParameters["Shift"][0],
    }
    history.append(row)
    print(json.dumps(row, default=float))

Path(str(args.output) + ".replay.json").write_text(
    json.dumps(history, indent=2, default=float) + "\n"
)
