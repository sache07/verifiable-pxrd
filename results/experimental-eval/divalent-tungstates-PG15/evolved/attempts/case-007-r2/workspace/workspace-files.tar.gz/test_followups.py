#!/usr/bin/env python3
"""Test complementary anisotropic strain and size terms from the best model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output_dir", type=Path)
args = parser.parse_args()

G2sc.SetPrintLevel("none")
args.output_dir.mkdir(parents=True, exist_ok=True)


def replay(path: Path, cycles: int = 4) -> G2sc.G2Project:
    for _ in range(cycles):
        project = G2sc.G2Project(str(path))
        project.refine(makeBack=False)
        project.save()
    return project


def summary(project: G2sc.G2Project, label: str, path: Path) -> dict:
    hist = project.histogram(0)
    covariance = project.data["Covariance"]["data"]
    selected = {}
    for name, value, sigma in zip(
        covariance.get("varyList", []),
        covariance.get("variables", []),
        covariance.get("sig", []),
    ):
        if "Mustrain" in name or "Size" in name:
            selected[name] = {"value": value, "sigma": sigma}
    return {
        "label": label,
        "gpx": str(path),
        "Rwp": hist.residuals["wR"],
        "Rp": hist.residuals["R"],
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "converged": covariance.get("Rvals", {}).get("converged"),
        "fractions": hist.ComputeMassFracs(),
        "broadening_variables": selected,
    }


# Add the best standalone MgWO4 uniaxial direction to the accepted WO3 [011]
# uniaxial model, then replay before testing any further term.
combined_path = args.output_dir / "combined_uniaxial_strain.gpx"
combined = G2sc.G2Project(str(args.source), newgpx=str(combined_path))
combined.data["Controls"]["data"]["max cyc"] = 16
combined.data["Controls"]["data"]["min dM/M"] = 1.0e-6
hist = combined.histogram(0)
mg_strain = combined.phase("MgWO4_wolframite").data["Histograms"][hist.name]["Mustrain"]
isotropic = float(mg_strain[1][0])
mg_strain[0] = "uniaxial"
mg_strain[1][0] = isotropic
mg_strain[1][1] = isotropic
mg_strain[2] = [True, True, False]
mg_strain[3] = [1, 1, 0]
combined.save()
combined = replay(combined_path)

results = [summary(combined, "combined_uniaxial_strain", combined_path)]
print(json.dumps(results[-1], default=float))


def add_size(label: str, phase_name: str, model: str, axis: tuple[int, int, int]) -> None:
    path = args.output_dir / f"{label}.gpx"
    project = G2sc.G2Project(str(combined_path), newgpx=str(path))
    project.data["Controls"]["data"]["max cyc"] = 16
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = project.histogram(0)
    size = project.phase(phase_name).data["Histograms"][hist.name]["Size"]
    size[0] = model
    size[1][0] = 2.0
    size[1][1] = 2.0
    size[2] = [True, model == "uniaxial", False]
    size[3] = list(axis)
    project.save()
    project = replay(path)
    results.append(summary(project, label, path))
    print(json.dumps(results[-1], default=float))


add_size("MgWO4_isotropic_size", "MgWO4_wolframite", "isotropic", (1, 1, 0))
add_size("MgWO4_uniaxial_size_110", "MgWO4_wolframite", "uniaxial", (1, 1, 0))
add_size("WO3_isotropic_size", "WO3_monoclinic_equiv_P21c", "isotropic", (0, 1, 1))
add_size("WO3_uniaxial_size_011", "WO3_monoclinic_equiv_P21c", "uniaxial", (0, 1, 1))

(args.output_dir / "summary.json").write_text(
    json.dumps(results, indent=2, default=float) + "\n"
)
