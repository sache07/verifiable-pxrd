#!/usr/bin/env python3
"""Plot and summarize a saved GSAS-II powder fit."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from scipy.signal import find_peaks


parser = argparse.ArgumentParser()
parser.add_argument("gpx", type=Path)
parser.add_argument("--csv", type=Path, required=True)
args = parser.parse_args()

project = G2sc.G2Project(str(args.gpx))
hist = project.histogram(0)
x = np.asarray(hist.getdata("X"))
obs = np.asarray(hist.getdata("Yobs"))
calc = np.asarray(hist.getdata("Ycalc"))
bkg = np.asarray(hist.getdata("Background"))
diff = obs - calc

args.csv.parent.mkdir(exist_ok=True)
np.savetxt(
    args.csv,
    np.column_stack((x, obs, calc, bkg, diff)),
    delimiter=",",
    header="two_theta_deg,observed,calculated,background,difference",
    comments="",
)

prom = max(100.0, 0.02 * obs.max())
pp, props = find_peaks(diff, prominence=prom, distance=7)
pn, props_n = find_peaks(-diff, prominence=prom, distance=7)
rows = []
for idx, prominence in zip(pp, props["prominences"]):
    rows.append((abs(diff[idx]), "+", x[idx], diff[idx], prominence))
for idx, prominence in zip(pn, props_n["prominences"]):
    rows.append((abs(diff[idx]), "-", x[idx], diff[idx], prominence))
print("Largest coherent residual extrema")
for _, sign, xpos, value, prominence in sorted(rows, reverse=True)[:80]:
    print(f"{sign} {xpos:9.4f} residual={value:10.2f} prominence={prominence:10.2f}")

print("\nFit summary")
print(hist.residuals)
print("Mass fractions", hist.ComputeMassFracs())
print("Instrument", hist.InstrumentParameters)
for phase in project.phases():
    print(phase.name, phase.get_cell(), phase.data["Histograms"][hist.name])
