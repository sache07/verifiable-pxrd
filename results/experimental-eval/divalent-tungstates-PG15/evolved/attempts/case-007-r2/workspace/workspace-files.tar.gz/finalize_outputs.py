#!/usr/bin/env python3
"""Export all submitted outputs from the unchanged final GSAS-II project."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
gpx_path = root / "final.gpx"
project = G2sc.G2Project(str(gpx_path))
hist = project.histogram(0)
covariance = project.data["Covariance"]["data"]
rvals = covariance.get("Rvals", {})
if not rvals.get("converged"):
    raise RuntimeError("final.gpx does not contain a converged final refinement")

phase_metadata = {
    "MgWO4_wolframite": {
        "display_name": "MgWO4 (wolframite)",
        "formula": "MgWO4",
        "cif": "MgWO4.cif",
        "source_record": "COD 9013902",
        "space_group_number": 13,
    },
    "WO3_monoclinic_P21n": {
        "display_name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif": "WO3.cif",
        "source_record": "COD 2311041, transformed to an equivalent P21/n setting",
        "space_group_number": 14,
    },
    "MgO_periclase": {
        "display_name": "MgO (periclase)",
        "formula": "MgO",
        "cif": "MgO.cif",
        "source_record": "COD 9000499",
        "space_group_number": 225,
    },
}

fractions = hist.ComputeMassFracs()
fraction_sum = sum(float(value[0]) for value in fractions.values())
if not np.isclose(fraction_sum, 1.0, atol=1.0e-12):
    raise RuntimeError(f"phase fractions are not normalized: {fraction_sum}")

phase_rows = []
for index, phase in enumerate(project.phases()):
    metadata = phase_metadata[phase.name]
    phase.export_CIF(str(root / metadata["cif"]))
    fraction, fraction_esd = fractions[phase.name]
    sg_data = phase.data["General"]["SGData"]
    cell = phase.get_cell()
    phase_rows.append({
        "name": metadata["display_name"],
        "project_phase_name": phase.name,
        "formula": metadata["formula"],
        "space_group": sg_data["SpGrp"],
        "space_group_number": metadata["space_group_number"],
        "cif_path": metadata["cif"],
        "source_record": metadata["source_record"],
        "weight_fraction": float(fraction),
        "weight_fraction_esd_formal": float(fraction_esd),
        "weight_percent": 100.0 * float(fraction),
        "unit_cell": {key: float(value) for key, value in cell.items()},
        "Bragg_R_F_percent": float(hist.residuals[f"{index}:0:Rf"]),
        "Bragg_R_F_squared_percent": float(hist.residuals[f"{index}:0:Rf^2"]),
    })

x = np.asarray(hist.getdata("X"), dtype=float)
observed = np.asarray(hist.getdata("Yobs"), dtype=float)
calculated = np.asarray(hist.getdata("Ycalc"), dtype=float)
difference = observed - calculated
if len(x) != int(rvals["Nobs"]):
    raise RuntimeError(f"profile length {len(x)} differs from Nobs {rvals['Nobs']}")
if not np.all(np.isfinite(np.column_stack((x, observed, calculated, difference)))):
    raise RuntimeError("non-finite value found in exported profile")
np.savetxt(
    root / "fit.csv",
    np.column_stack((x, observed, calculated, difference)),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference",
    comments="",
    fmt="%.15g",
)

result = {
    "phase_fraction_basis": "normalized over the modeled crystalline phases",
    "phases": phase_rows,
    "fit_statistics": {
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "Rexp_percent": float(hist.residuals["wRmin"]),
        "GOF": float(rvals["GOF"]),
        "chi_square": float(rvals["chisq"]),
        "Bragg_R_percent": float(hist.residuals["Rb"]),
        "weighted_Bragg_R_percent": float(hist.residuals["wRb"]),
        "observations": int(rvals["Nobs"]),
        "refined_variables": int(rvals["Nvars"]),
        "two_theta_min_deg": float(x.min()),
        "two_theta_max_deg": float(x.max()),
    },
    "profile_path": "fit.csv",
    "project_path": "final.gpx",
}
(root / "result.json").write_text(json.dumps(result, indent=2) + "\n")

print(json.dumps(result, indent=2))
