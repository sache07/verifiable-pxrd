#!/usr/bin/env python3
"""Render a profile CSV exported from a GSAS-II project."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


parser = argparse.ArgumentParser()
parser.add_argument("csv", type=Path)
parser.add_argument("png", type=Path)
args = parser.parse_args()

data = pd.read_csv(args.csv)
x = data["two_theta_deg"]
obs = data["observed"]
calc = data["calculated"]
bkg = data["background"]
diff = data["difference"]

fig, axes = plt.subplots(
    4,
    1,
    figsize=(15, 12),
    gridspec_kw={"height_ratios": [1.5, 1.2, 1.2, 1.2]},
    constrained_layout=True,
)
axes[0].plot(x, obs, color="black", lw=0.65, label="observed")
axes[0].plot(x, calc, color="crimson", lw=0.65, label="calculated")
axes[0].plot(x, bkg, color="royalblue", lw=0.6, label="background")
offset = -0.12 * (obs.max() - obs.min())
axes[0].plot(x, diff + offset, color="darkgreen", lw=0.55, label="difference (offset)")
axes[0].legend(ncol=4, fontsize=8)
axes[0].set_xlim(x.min(), x.max())
axes[0].set_ylabel("counts")
for ax, (lo, hi) in zip(axes[1:], ((10, 38), (38, 68), (68, 100))):
    use = (x >= lo) & (x <= hi)
    ax.plot(x[use], obs[use], color="black", lw=0.8)
    ax.plot(x[use], calc[use], color="crimson", lw=0.8)
    ax.plot(x[use], diff[use] + offset / 3, color="darkgreen", lw=0.65)
    ax.set_xlim(lo, hi)
    ax.set_ylabel("counts")
axes[-1].set_xlabel(r"$2\theta$ (degrees)")
args.png.parent.mkdir(exist_ok=True)
fig.savefig(args.png, dpi=160)
