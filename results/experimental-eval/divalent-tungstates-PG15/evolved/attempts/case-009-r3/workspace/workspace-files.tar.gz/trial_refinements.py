#!/usr/bin/env python3
"""Run reversible GSAS-II model challenges from an existing project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def replay(gpx: G2sc.G2Project, output: Path) -> G2sc.G2Project:
    gpx.save(str(output))
    gpx.do_refinements([{}])
    gpx.save()
    reopened = G2sc.G2Project(str(output))
    reopened.do_refinements([{}])
    reopened.save()
    return reopened


def summary(gpx: G2sc.G2Project) -> dict:
    hist = gpx.histogram(0)
    phase_rows = []
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        phase_rows.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "scale_refined": hap["Scale"][1],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    inst = hist.InstrumentParameters
    return {
        "residuals": hist.residuals,
        "instrument": {key: inst[key] for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L")},
        "shift": hist.SampleParameters["Shift"],
        "background": hist.Background[0],
        "phases": phase_rows,
        "variables": gpx.data["Covariance"]["data"].get("varyList", []),
        "sigmas": gpx.data["Covariance"]["data"].get("sig", []).tolist(),
        "frozen": gpx.get_Frozen(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "--mode",
        required=True,
        choices=(
            "shl",
            "polarization",
            "polarization_fixed_u",
            "polarization_source_u",
            "roughness_b",
            "roughness_ab",
            "texture",
            "texture_sh2",
            "size",
            "strain",
            "size_uniaxial",
            "strain_uniaxial",
            "strain_generalized",
            "coordinates",
            "uiso",
            "coordinates_uiso",
            "source_adp",
            "candidate",
            "candidate_cell",
        ),
    )
    parser.add_argument("--axis", nargs=3, type=int, default=(0, 0, 1))
    parser.add_argument("--cod-id")
    parser.add_argument("--phase-name")
    parser.add_argument("--phase-index", type=int, default=1)
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.input), newgpx=str(args.output))
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    if args.mode == "shl":
        gpx.set_Controls("parmMin", 0.001, variable=":0:SH/L")
        gpx.set_Controls("parmMax", 0.2, variable=":0:SH/L")
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    elif args.mode == "polarization":
        gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif args.mode == "polarization_fixed_u":
        for atom in phase.atoms():
            atom.refinement_flags = atom.refinement_flags.replace("U", "")
        gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif args.mode == "polarization_source_u":
        source_u = {"Mn1": 0.0078, "W1": 0.0070, "O1": 0.0066, "O2": 0.0090}
        for atom in phase.atoms():
            atom.data[10] = source_u[atom.label]
            atom.refinement_flags = atom.refinement_flags.replace("U", "")
        gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif args.mode == "roughness_b":
        hist.SampleParameters["SurfRoughA"] = [0.0, False]
        hist.SampleParameters["SurfRoughB"] = [0.05, True]
        gpx.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        gpx.set_Controls("parmMax", 5.0, variable=":0:SurfRoughB")
    elif args.mode == "roughness_ab":
        hist.SampleParameters["SurfRoughA"] = [0.1, True]
        hist.SampleParameters["SurfRoughB"] = [0.05, True]
        for name in ("SurfRoughA", "SurfRoughB"):
            gpx.set_Controls("parmMin", 0.0, variable=f":0:{name}")
            gpx.set_Controls("parmMax", 5.0 if name.endswith("B") else 1.0, variable=f":0:{name}")
    elif args.mode == "texture":
        po = phase.getHAPvalues(hist)["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = list(args.axis)
        gpx.set_Controls("parmMin", 0.05, variable="0:0:MD")
        gpx.set_Controls("parmMax", 20.0, variable="0:0:MD")
    elif args.mode == "texture_sh2":
        phase.HAPvalue("PO", 2, targethistlist=[hist])
        phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])
    elif args.mode == "size":
        phase.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=1.0)
        gpx.set_Controls("parmMin", 0.01, variable="0:0:Size;i")
        gpx.set_Controls("parmMax", 1.0e5, variable="0:0:Size;i")
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True, "value": 1.0}}
        )
    elif args.mode == "strain":
        phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=1.0)
        gpx.set_Controls("parmMin", 0.0, variable="0:0:Mustrain;i")
        gpx.set_Controls("parmMax", 1.0e5, variable="0:0:Mustrain;i")
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    elif args.mode == "size_uniaxial":
        phase.setSampleProfile(hist, "size", "uniaxial", 2.0, 2.0, args.axis, LGmix=1.0)
        for name in ("i", "a"):
            gpx.set_Controls("parmMin", 0.01, variable=f"0:0:Size;{name}")
            gpx.set_Controls("parmMax", 1.0e5, variable=f"0:0:Size;{name}")
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "uniaxial",
                    "direction": list(args.axis),
                    "refine": True,
                }
            }
        )
    elif args.mode == "strain_uniaxial":
        phase.setSampleProfile(
            hist, "microstrain", "uniaxial", 100.0, 100.0, args.axis, LGmix=1.0
        )
        for name in ("i", "a"):
            gpx.set_Controls("parmMin", 0.0, variable=f"0:0:Mustrain;{name}")
            gpx.set_Controls("parmMax", 1.0e5, variable=f"0:0:Mustrain;{name}")
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "uniaxial",
                    "direction": list(args.axis),
                    "refine": True,
                }
            }
        )
    elif args.mode == "strain_generalized":
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "generalized", "refine": True}}
        )
    elif args.mode == "coordinates":
        phase.set_refinements({"Atoms": {"all": "X"}})
    elif args.mode == "uiso":
        # Replace imported anisotropic ADPs with their listed Ueq values, then
        # refine one Uiso per occupied site as a reversible structural trial.
        cia = phase.data["General"]["AtomPtrs"][3]
        for atom in phase.atoms():
            atom.data[cia] = "I"
            atom.refinement_flags = "U"
    elif args.mode == "coordinates_uiso":
        cia = phase.data["General"]["AtomPtrs"][3]
        for i, atom in enumerate(phase.atoms()):
            atom.data[cia] = "I"
            atom.refinement_flags = "XU"
            gpx.set_Controls("parmMin", 0.0, variable=f"0::AUiso:{i}")
            gpx.set_Controls("parmMax", 0.05, variable=f"0::AUiso:{i}")
    elif args.mode == "source_adp":
        source_adp = {
            "Mn1": ["A", 0.0078, 0.0070, 0.0100, 0.0066, 0.0, 0.0003, 0.0],
            "W1": ["A", 0.0070, 0.00632, 0.0095, 0.00519, 0.0, -0.00012, 0.0],
            "O1": ["I", 0.0066, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            "O2": ["I", 0.0090, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        }
        cia = phase.data["General"]["AtomPtrs"][3]
        for atom in phase.atoms():
            atom.data[cia : cia + 8] = source_adp[atom.label]
            atom.refinement_flags = atom.refinement_flags.replace("U", "")
    elif args.mode == "candidate":
        if not args.cod_id or not args.phase_name:
            parser.error("candidate mode requires --cod-id and --phase-name")
        candidate = gpx.add_phase(
            str(cod_path(args.cod_id)),
            phasename=args.phase_name,
            histograms=[hist],
            fmthint="CIF",
        )
        candidate.setSampleProfile(hist, "size", "isotropic", 1.0e6, LGmix=1.0)
        candidate.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
        candidate.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
        candidate.HAPvalue("Scale", 0.05, targethistlist=[hist])
        candidate.set_HAP_refinements({"Scale": True}, [hist])
        p_id = candidate.id
        gpx.set_Controls("parmMin", 0.0, variable=f"{p_id}:0:Scale")
    elif args.mode == "candidate_cell":
        if len(gpx.phases()) <= args.phase_index:
            parser.error("candidate_cell phase index is not present")
        gpx.phase(args.phase_index).set_refinements({"Cell": True})

    gpx = replay(gpx, args.output)
    print(json.dumps(summary(gpx), indent=2, default=float))


if __name__ == "__main__":
    main()
