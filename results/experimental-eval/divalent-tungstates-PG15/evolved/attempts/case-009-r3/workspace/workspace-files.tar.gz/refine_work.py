#!/usr/bin/env python3
"""Build and interrogate GSAS-II refinements for the submitted PXRD result."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summarize(gpx: G2sc.G2Project, label: str) -> None:
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    print(f"\n--- {label} ---")
    print("residuals", hist.residuals)
    print(
        "instrument",
        {key: inst[key] for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)")},
    )
    print("sample", hist.SampleParameters)
    print("background", hist.Background[0])
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        print(
            "phase",
            phase.name,
            "cell",
            phase.get_cell(),
            "scale",
            hap["Scale"],
            "size",
            hap["Size"],
            "mustrain",
            hap["Mustrain"],
            "PO",
            hap["Pref.Ori."],
        )


def build_initial(output: Path, background_terms: int = 8) -> G2sc.G2Project:
    gpx = G2sc.G2Project(newgpx=str(output))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "cu_ka.instprm"),
        fmthint="comma",
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    phase = gpx.add_phase(
        str(cod_path("1520200")),
        phasename="MnWO4",
        histograms=[hist],
        fmthint="CIF",
    )
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": background_terms,
            }
        }
    )
    # Neutralize phase-specific line broadening and texture before fitting.
    phase.setSampleProfile(hist, "size", "isotropic", 1.0e6, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    phase.set_HAP_refinements({"Scale": True})
    # A single pattern does not require an independently refined global scale;
    # phase scales carry the quantitative information and avoid rank deficiency.
    hist.SampleParameters["Scale"] = [1.0, False]
    gpx.set_Controls("cycles", 12)
    gpx.save()
    return gpx


def run_baseline(output: Path, correction: str, background_terms: int, profile: str) -> G2sc.G2Project:
    gpx = build_initial(output, background_terms)
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    # Establish scale and a smooth low-order background first.
    gpx.do_refinements([{}])
    # Add the monoclinic cell and exactly one angular correction.
    phase.set_refinements({"Cell": True})
    if correction == "shift":
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    elif correction == "zero":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    else:
        raise ValueError(correction)
    gpx.do_refinements([{}])
    # Fit a nonnegative low-dimensional common profile. V and Y remain zero.
    # U is tested either at its neutral boundary or with an explicit lower bound.
    hist.InstrumentParameters["U"][0:2] = [0.0, 0.0]
    terms = ["W", "X"] if profile == "wx" else ["U", "W", "X"]
    if profile == "uwx":
        gpx.set_Controls("parmMin", 0.0, variable=":0:U")
    gpx.set_Controls("parmMin", 0.0, variable=":0:W")
    gpx.set_Controls("parmMin", 0.0, variable=":0:X")
    hist.set_refinements({"Instrument Parameters": terms})
    gpx.do_refinements([{}])
    # Replay once from the converged state.
    gpx.save()
    gpx = G2sc.G2Project(str(output))
    gpx.do_refinements([{}])
    gpx.save()
    return gpx


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--correction", choices=("shift", "zero"), default="shift")
    parser.add_argument("--background-terms", type=int, default=8)
    parser.add_argument("--profile", choices=("wx", "uwx"), default="wx")
    parser.add_argument("--output", type=Path, default=ROOT / ".tmp" / "baseline.gpx")
    args = parser.parse_args()
    gpx = run_baseline(args.output, args.correction, args.background_terms, args.profile)
    summarize(gpx, f"baseline {args.correction} bkg={args.background_terms} {args.profile}")


if __name__ == "__main__":
    main()
