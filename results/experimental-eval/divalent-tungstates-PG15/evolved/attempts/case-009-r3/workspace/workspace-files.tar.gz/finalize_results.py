#!/usr/bin/env python3
"""Replay the selected full-range model and export the submitted results."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE_PROJECT = ROOT / ".tmp" / "full_orderA.gpx"
FINAL_PROJECT = ROOT / "final.gpx"

PHASE_INFO = {
    "MnWO4": {
        "name": "MnWO4 (wolframite)",
        "formula": "MnWO4",
        "cif": "phase_1_MnWO4.cif",
        "cod_id": "1520200",
        "model_note": "cell, atomic coordinates, isotropic displacement parameters, and scale refined",
    },
    "Mn2O3": {
        "name": "Mn2O3 (bixbyite)",
        "formula": "Mn2O3",
        "cif": "phase_2_Mn2O3.cif",
        "cod_id": "1514230",
        "model_note": "cell and scale refined; source coordinates retained",
    },
    "WO3_monoclinic": {
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif": "phase_3_WO3.cif",
        "cod_id": "1528915",
        "model_note": "source structure and cell retained; scale refined",
    },
    "Mn3O4_tetragonal": {
        "name": "Mn3O4 (hausmannite)",
        "formula": "Mn3O4",
        "cif": "phase_4_Mn3O4.cif",
        "cod_id": "9001963",
        "model_note": "source structure and cell retained; scale refined",
    },
}


def replay_full_range() -> G2sc.G2Project:
    """Copy the accepted model, use every measured point, and replay twice."""
    project = G2sc.G2Project(str(SOURCE_PROJECT), newgpx=str(FINAL_PROJECT))
    histogram = project.histogram(0)
    x = np.asarray(histogram.getdata("X"), dtype=float)
    histogram.Limits("lower", float(x[0]))
    histogram.Limits("upper", float(x[-1]))
    project.save()

    # A save/reopen replay catches order- or in-memory-state dependence.
    for _ in range(2):
        project = G2sc.G2Project(str(FINAL_PROJECT))
        project.do_refinements([{}])
        project.save()

    return G2sc.G2Project(str(FINAL_PROJECT))


def cell_string(cell: dict[str, float]) -> str:
    return (
        f"a={cell['length_a']:.5f}, b={cell['length_b']:.5f}, "
        f"c={cell['length_c']:.5f} A; alpha={cell['angle_alpha']:.4f}, "
        f"beta={cell['angle_beta']:.4f}, gamma={cell['angle_gamma']:.4f} deg"
    )


def main() -> None:
    project = replay_full_range()
    histogram = project.histogram(0)
    fractions = histogram.ComputeMassFracs()

    phases_out = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        phase.export_CIF(str(ROOT / info["cif"]))
        fraction, esd = fractions[phase.name]
        phases_out.append(
            {
                "name": info["name"],
                "formula": info["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": info["cif"],
                "weight_fraction": fraction,
                "weight_fraction_esd": esd,
                "structure_source": f"COD {info['cod_id']}",
                "model_note": info["model_note"],
            }
        )

    x = np.asarray(histogram.getdata("X"), dtype=float)
    y_obs = np.asarray(histogram.getdata("Yobs"), dtype=float)
    y_calc = np.asarray(histogram.getdata("Ycalc"), dtype=float)
    background = np.asarray(histogram.getdata("Background"), dtype=float)
    difference = y_obs - y_calc
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_observed_minus_calculated",
                "background_intensity",
            ]
        )
        for row in zip(x, y_obs, y_calc, difference, background):
            writer.writerow([repr(float(value)) for value in row])

    residuals = histogram.residuals
    rvals = project.data["Covariance"]["data"]["Rvals"]
    fit_statistics = {
        "r_wp_percent": float(residuals["wR"]),
        "r_p_percent": float(residuals["R"]),
        "r_exp_percent": float(residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "reduced_chi_squared": float(rvals["GOF"] ** 2),
        "chi_squared": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_parameters": int(rvals["Nvars"]),
        "converged": bool(rvals["converged"]),
        "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
        "two_theta_range_deg": [float(x[0]), float(x[-1])],
    }
    result = {
        "project_path": FINAL_PROJECT.name,
        "profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over the modeled crystalline phases; sum equals 1",
        "phases": phases_out,
        "fit_statistics": fit_statistics,
    }
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")

    phase_by_formula = {item["formula"]: item for item in phases_out}
    p_mw = phase_by_formula["MnWO4"]
    p_m2 = phase_by_formula["Mn2O3"]
    p_wo = phase_by_formula["WO3"]
    p_m3 = phase_by_formula["Mn3O4"]
    phase_objects = {PHASE_INFO[p.name]["formula"]: p for p in project.phases()}

    def wt(item: dict) -> str:
        return f"{100.0 * item['weight_fraction']:.3f} ± {100.0 * item['weight_fraction_esd']:.3f} wt%"

    report = f"""# Quantitative phase analysis

## Result

The pattern is modeled by wolframite MnWO4 with three trace oxide phases. Fractions below are normalized over the modeled crystalline material; they do not measure amorphous content or absolute crystalline yield.

| Phase | Space group | Weight fraction | Structural treatment |
|---|---:|---:|---|
| MnWO4 (wolframite) | {p_mw['space_group']} | {wt(p_mw)} | Cell, coordinates, isotropic displacement parameters, and scale refined |
| Mn2O3 (bixbyite) | {p_m2['space_group']} | {wt(p_m2)} | Cell and scale refined; source coordinates retained |
| WO3 (monoclinic) | {p_wo['space_group']} | {wt(p_wo)} | Source cell/coordinates fixed; scale refined |
| Mn3O4 (hausmannite) | {p_m3['space_group']} | {wt(p_m3)} | Source cell/coordinates fixed; scale refined |

The final full-range refinement ({x[0]:.4f}-{x[-1]:.4f} deg 2theta, Cu Kalpha1/Kalpha2) converged with Rwp={fit_statistics['r_wp_percent']:.3f}%, Rp={fit_statistics['r_p_percent']:.3f}%, Rexp={fit_statistics['r_exp_percent']:.3f}%, and goodness of fit={fit_statistics['goodness_of_fit']:.3f} ({fit_statistics['n_observations']} observations, {fit_statistics['n_refined_parameters']} refined parameters).

## Evidence and model selection

MnWO4 accounts for the strong peak positions, monoclinic splitting, and intensities throughout low, middle, and high angle. Its refined cell is {cell_string(phase_objects['MnWO4'].get_cell())}. The refined Mn-O distances remain approximately 2.10-2.30 A and W-O distances 1.79-2.14 A, supporting a physically intact wolframite structure with full occupied sites.

The trace phases were retained only when a nonnegative scale was supported by coherent families after the common profile was rebuilt. Bixbyite Mn2O3 contributes around 33.2, 55.4, and 66.0 deg; monoclinic WO3 contributes the 23.4-23.9 deg cluster and weaker features near 33.6-33.8 and 56.2 deg; hausmannite Mn3O4 contributes near 32.6, 51.0, and 58.7-60.1 deg. Their scales remain supported when phase-addition order is reversed, and cross-phase scale correlations are below 0.09. MnO was statistically insignificant and Mn3WO6 refined to zero scale. Alternate WO3 and high-pressure Mn3O4 records also refined to zero under the same nuisance model.

Exact occupied-composition records were available, so no cross-chemistry substitution was needed. The selected starting structures are COD 1520200 (MnWO4), 1514230 (Mn2O3), 1528915 (WO3), and 9001963 (Mn3O4). The residual Mn3O4 and WO3 are chemically consistent with the stated reactants; minor Mn2O3 is consistent with oxidation during the 900 C synthesis.

## Refinement controls and uncertainty

The baseline uses a smooth 12-term Chebyshev background, one specimen-displacement correction, a nonnegative common W/X profile with U fixed at zero, and SH/L asymmetry. Low-angle intensity curvature required a nonnegative surface-roughness term before texture was tested. A small order-2 spherical-harmonic texture correction was replay-stable and supported by multiple MnWO4 families. Phase size/strain terms were neutralized: isotropic strain returned to zero, while size and anisotropic trials collapsed onto or strongly correlated with the common profile. Crystallite size and microstrain therefore cannot be determined reliably without an instrumental standard.

The MnWO4 structure is well supported by this pattern. The Mn2O3 fraction is supported, but Ia-3, I213, and Pbca Mn2O3 records fit essentially identically at ~0.7 wt%; the reported canonical bixbyite symmetry is therefore not uniquely established. The WO3 and Mn3O4 identities/fractions are plausible and statistically supported at trace level, but their cells and coordinates cannot be refined reliably from this pattern and were held to physical source structures. Localized low-angle tail residuals remain near the strongest MnWO4 families (notably around 18.4, 23.6, and 29.9 deg); additional size/strain models were rejected because they collapsed onto the common profile, reached bounds, or were not replay-stable. Specimen displacement and axial asymmetry are also strongly covariant, making their individual values non-unique, though the replayed phase fractions are stable.

Pointwise uncertainties were not supplied, so counting-statistic weights (1/count) were used. The quoted covariance errors are conditional on those weights, this phase inventory, and this profile; systematic uncertainty is likely larger, so differences of a few tenths of a weight percent should not be over-interpreted.

The submitted CIFs, `fit.csv`, and fractions were exported from the exact saved state in `final.gpx`.
"""
    (ROOT / "report.md").write_text(report)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
