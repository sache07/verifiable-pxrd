#!/usr/bin/env python3
"""Combine supported texture terms and reconverge the common model."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
src = ROOT / "profile_wo3_iso_strain.gpx"
out = ROOT / "combined_texture.gpx"
gpx = G2sc.G2Project(str(src))
gpx.save(str(out))
gpx = G2sc.G2Project(str(out))
hist = gpx.histogram(0)

for phase in gpx.phases():
    po = phase.getHAPvalues(hist.name)["Pref.Ori."]
    po[0], po[1], po[2] = "MD", 1.0, False

po0 = gpx.phase(0).getHAPvalues(hist.name)["Pref.Ori."]
po0[1], po0[2], po0[3] = 0.9871, True, [0, 0, 1]
po2 = gpx.phase(2).getHAPvalues(hist.name)["Pref.Ori."]
po2[1], po2[2], po2[3] = 1.0311, True, [0, 1, 0]

for key in ("U", "X", "SH/L"):
    hist.InstrumentParameters[key][2] = True
for key in ("V", "W", "Y", "Z"):
    hist.InstrumentParameters[key][1] = 0.0
    hist.InstrumentParameters[key][2] = False

gpx.set_Frozen()
for var, lo, hi in [
    ("0:0:MD", 0.2, 5.0), ("2:0:MD", 0.2, 5.0),
    (":0:U", 0.0, 1000.0), (":0:X", 0.0, 100.0), (":0:SH/L", 0.00001, 2.0),
    ("2:0:Mustrain;i", 0.0, 20000.0),
]:
    gpx.set_Controls("parmMin", lo, variable=var)
    gpx.set_Controls("parmMax", hi, variable=var)

gpx.set_Controls("cycles", 12)
gpx.save()
gpx.refine(makeBack=False)
gpx.save()
gpx = G2sc.G2Project(str(out))
gpx.set_Controls("cycles", 6)
gpx.refine(makeBack=False)
gpx.save()

hist = gpx.histogram(0)
cov = gpx.data["Covariance"]["data"]
sig = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
print("COMBINED " + json.dumps({
    "residuals": hist.residuals,
    "fractions": hist.ComputeMassFracs(),
    "profile": {k: hist.InstrumentParameters[k][1] for k in
                ("U", "V", "W", "X", "Y", "Z", "SH/L")},
    "po": {
        p.name: p.getHAPvalues(hist.name)["Pref.Ori."] for p in gpx.phases()
    },
    "po_sig": {k: v for k, v in sig.items() if k.endswith(":MD")},
    "wo3_mustrain": gpx.phase(2).getHAPvalues(hist.name)["Mustrain"],
    "frozen": gpx.get_Frozen(),
}, default=float, sort_keys=True))
