#!/usr/bin/env python3
"""Nested strain/texture challenges from the stable common-ADP baseline."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "adp_stable_base.gpx"


def run(label, strain=False, mg_texture=False, wo_texture=False):
    out = ROOT / f"adp_nuisance_{label}.gpx"
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(out))
    project = G2sc.G2Project(str(out))
    hist = project.histogram(0)

    wo = project.phase(2).getHAPvalues(hist.name)
    wo["Mustrain"][0] = "isotropic"
    wo["Mustrain"][1][0] = 900.0 if strain else 0.0
    wo["Mustrain"][2] = [bool(strain), False, False]

    for phase in project.phases():
        po = phase.getHAPvalues(hist.name)["Pref.Ori."]
        po[0], po[1], po[2] = "MD", 1.0, False
    if mg_texture:
        po = project.phase(0).getHAPvalues(hist.name)["Pref.Ori."]
        po[1], po[2], po[3] = 0.987, True, [0, 0, 1]
    if wo_texture:
        po = project.phase(2).getHAPvalues(hist.name)["Pref.Ori."]
        po[1], po[2], po[3] = 1.03, True, [0, 1, 0]

    project.set_Frozen()
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.data["Controls"]["data"]["shift factor"] = 0.2
    project.set_Controls("cycles", 30)
    project.save()
    for _ in range(4):
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(out))
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
        project.data["Controls"]["data"]["shift factor"] = 0.2
        project.set_Controls("cycles", 30)

    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    sig = dict(zip((str(v) for v in cov.get("varyList", [])), cov.get("sig", [])))
    print("ADP_NUISANCE " + json.dumps({
        "label": label,
        "Rwp_percent": hist.residuals.get("wR"),
        "Rp_percent": hist.residuals.get("R"),
        "fractions": hist.ComputeMassFracs(),
        "mustrain": project.phase(2).getHAPvalues(hist.name)["Mustrain"],
        "textures": {phase.name: phase.getHAPvalues(hist.name)["Pref.Ori."]
                     for phase in project.phases()},
        "sigmas": {key: value for key, value in sig.items()
                   if key in ("2:0:Mustrain;i", "0:0:MD", "2:0:MD",
                              "2::AUiso:0")},
        "frozen": project.get_Frozen(),
        "path": str(out),
    }, default=float, sort_keys=True), flush=True)


run("strain", strain=True)
run("mg_texture", mg_texture=True)
run("wo_texture", wo_texture=True)
run("both_textures", mg_texture=True, wo_texture=True)
run("strain_mg_texture", strain=True, mg_texture=True)
run("strain_wo_texture", strain=True, wo_texture=True)
run("strain_both_textures", strain=True, mg_texture=True, wo_texture=True)
