#!/usr/bin/env python3
"""Rebuild the common model after accepting a grouped WO3 displacement term."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "final.gpx"
OUT = ROOT / "adp_rebuilt.gpx"


def reopen(project):
    return G2sc.G2Project(str(project.filename))


def refine_stage(project, label):
    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    project.save()
    project.refine(makeBack=False)
    project.save()
    project = reopen(project)
    hist = project.histogram(0)
    print("STAGE " + json.dumps({
        "label": label,
        "Rwp_percent": hist.residuals.get("wR"),
        "Rp_percent": hist.residuals.get("R"),
    }, sort_keys=True))
    return project


project = G2sc.G2Project(str(SOURCE))
project.save(str(OUT))
project = reopen(project)
hist = project.histogram(0)

# Replace zero placeholders by one positive, symmetry-constrained WO3 Uiso.
wo3 = project.phase(2)
adp_variables = []
for index, atom in enumerate(wo3.atoms()):
    atom.uiso = 0.008
    atom.refinement_flags = "U"
    adp_variables.append(f"2::AUiso:{index}")
project.save()
project.add_EquivConstr(adp_variables, reloadIdx=True)
for variable in adp_variables:
    project.set_Controls("parmMin", 0.0, variable=variable)
    project.set_Controls("parmMax", 0.05, variable=variable)

# Stage 1: structural intensity scale against a smooth background.
hist = project.histogram(0)
hist.data["Background"][0][1] = True
for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
    hist.InstrumentParameters[key][2] = False
for key in ("Shift", "SurfRoughB"):
    hist.SampleParameters[key][1] = False
for phase in project.phases():
    phase.getHAPvalues(hist.name)["Scale"][1] = True
    phase.data["General"]["Cell"][0] = False
    phase.getHAPvalues(hist.name)["Pref.Ori."][2] = False
    phase.getHAPvalues(hist.name)["Mustrain"][2] = [False, False, False]
project.set_Frozen()
project = refine_stage(project, "background_scales_common_uiso")

# Stage 2: rebuild positions and the low-dimensional common profile.
hist = project.histogram(0)
for key in ("U", "X", "SH/L"):
    hist.InstrumentParameters[key][2] = True
for key in ("V", "W", "Y", "Z"):
    hist.InstrumentParameters[key][1] = 0.0
    hist.InstrumentParameters[key][2] = False
hist.SampleParameters["Shift"][1] = True
hist.SampleParameters["SurfRoughA"] = [0.0, False]
hist.SampleParameters["SurfRoughB"][1] = True
for phase in project.phases():
    phase.data["General"]["Cell"][0] = True
project = refine_stage(project, "common_profile_shift_cells")

# Stage 3: restore only the supported phase broadening.
hist = project.histogram(0)
wo3 = project.phase(2)
wo3.getHAPvalues(hist.name)["Mustrain"][0] = "isotropic"
wo3.getHAPvalues(hist.name)["Mustrain"][2] = [True, False, False]
project = refine_stage(project, "wo3_isotropic_microstrain")

# Stage 4: re-challenge and restore the supported mild textures.
hist = project.histogram(0)
for phase, axis in ((project.phase(0), [0, 0, 1]),
                    (project.phase(2), [0, 1, 0])):
    po = phase.getHAPvalues(hist.name)["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", 1.0, True, axis
project = refine_stage(project, "supported_textures")

# Full reopen/replay until stringent convergence.
for number in range(3):
    project = refine_stage(project, f"full_replay_{number + 1}")

hist = project.histogram(0)
cov = project.data["Covariance"]["data"]
sig = dict(zip((str(v) for v in cov.get("varyList", [])), cov.get("sig", [])))
print("ADP_REBUILT " + json.dumps({
    "residuals": hist.residuals,
    "fractions": hist.ComputeMassFracs(),
    "wo3_uiso": [atom.uiso for atom in project.phase(2).atoms()],
    "uiso_sigma": sig.get("2::AUiso:0"),
    "wo3_mustrain": project.phase(2).getHAPvalues(hist.name)["Mustrain"],
    "textures": {phase.name: phase.getHAPvalues(hist.name)["Pref.Ori."]
                 for phase in project.phases()},
    "profile": {key: hist.InstrumentParameters[key][1]
                for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
    "sample": {key: hist.SampleParameters[key]
               for key in ("Shift", "SurfRoughA", "SurfRoughB")},
    "frozen": project.get_Frozen(),
    "path": str(OUT),
}, default=float, sort_keys=True))
