#!/usr/bin/env python3
"""Repair and challenge the common GSAS-II profile/intensity baseline."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def report(gpx, label):
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    print(f"\n=== {label} ===")
    print("residuals", json.dumps(hist.residuals, sort_keys=True, default=float))
    print("profile", {k: inst[k] for k in ("U", "V", "W", "X", "Y", "Z", "SH/L")})
    print("sample", {k: sample[k] for k in
                     ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")})
    print("cells", {p.name: p.get_cell() for p in gpx.phases()})
    print("fractions", hist.ComputeMassFracs())
    print("frozen", gpx.get_Frozen())


def refine(gpx, label, cycles=12):
    gpx.set_Controls("cycles", cycles)
    gpx.refine(makeBack=False)
    report(gpx, label)


def set_inst(inst, key, value, refine_flag):
    inst[key][0] = float(value)
    inst[key][1] = float(value)
    inst[key][2] = bool(refine_flag)


gpx = G2sc.G2Project(str(ROOT / "explore_3phase.gpx"))
gpx.save(str(ROOT / "baseline_work.gpx"))
hist = gpx.histogram(0)
inst = hist.InstrumentParameters

# The first U/W/X trial was made before cells had converged and forced U and W
# against trial bounds. Discard it. Rebuild a two-term U/X profile at neutral W.
gpx.set_Frozen()
set_inst(inst, "U", 250.0, True)
set_inst(inst, "W", 0.0, False)
set_inst(inst, "X", 5.0, True)
set_inst(inst, "V", 0.0, False)
set_inst(inst, "Y", 0.0, False)
set_inst(inst, "Z", 0.0, False)
gpx.set_Controls("parmMin", 0.0, variable=":0:U")
gpx.set_Controls("parmMax", 1000.0, variable=":0:U")
gpx.set_Controls("parmMin", 0.0, variable=":0:W")
gpx.set_Controls("parmMax", 300.0, variable=":0:W")
gpx.set_Controls("parmMin", 0.0, variable=":0:X")
gpx.set_Controls("parmMax", 100.0, variable=":0:X")
gpx.save()
refine(gpx, "re-established common U/X profile")
gpx.save(str(ROOT / "baseline_ux.gpx"))

# Low-angle isolated peaks have the same low-angle tail, so test one common
# axial-divergence asymmetry term.
gpx = G2sc.G2Project(str(ROOT / "baseline_ux.gpx"))
hist = gpx.histogram(0)
inst = hist.InstrumentParameters
set_inst(inst, "SH/L", 0.02, True)
gpx.set_Controls("parmMin", 0.00001, variable=":0:SH/L")
gpx.set_Controls("parmMax", 2.0, variable=":0:SH/L")
gpx.save()
refine(gpx, "common SH/L asymmetry challenge")
gpx.save(str(ROOT / "baseline_asym.gpx"))

# Across all three phases, low-angle intensities are too strong relative to
# middle/high angle. Test a single Suortti roughness B parameter while keeping
# A at its neutral zero and polarization fixed at the unpolarized value.
gpx = G2sc.G2Project(str(ROOT / "baseline_asym.gpx"))
hist = gpx.histogram(0)
sample = hist.SampleParameters
sample["SurfRoughA"] = [0.0, False]
sample["SurfRoughB"] = [0.01, True]
gpx.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
gpx.set_Controls("parmMax", 2.0, variable=":0:SurfRoughB")
gpx.save()
refine(gpx, "one-parameter surface-roughness challenge")
gpx.save(str(ROOT / "baseline_rough.gpx"))

# Required reopen/replay across the complete fitted range.
gpx = G2sc.G2Project(str(ROOT / "baseline_rough.gpx"))
refine(gpx, "reopen/replay full range", 8)
gpx.save(str(ROOT / "baseline_replayed.gpx"))
