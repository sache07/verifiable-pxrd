#!/usr/bin/env python3
"""One-phase-at-a-time isotropic size and microstrain challenges."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "trial_wo3_p21c_2311041.gpx"


def run(phase_index, kind):
    base = G2sc.G2Project(str(BASE))
    phase_name = base.phase(phase_index).name
    tag = phase_name.replace("/", "_").replace(" ", "_")
    out = ROOT / f"broad_{phase_index}_{tag}_{kind}.gpx"
    base.save(str(out))
    gpx = G2sc.G2Project(str(out))
    hist = gpx.histogram(0)

    # Hold the accepted common profile while testing one phase contribution.
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        hist.InstrumentParameters[key][2] = False
    for p in gpx.phases():
        p.clear_HAP_refinements({"Size": True, "Mustrain": True})
    phase = gpx.phase(phase_index)
    hap = phase.getHAPvalues(hist.name)

    gpx.set_Frozen()
    if kind == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][1][2] = 1.0
        hap["Size"][2] = [True, False, False]
        var = f"{phase.id}:0:Size;i"
        gpx.set_Controls("parmMin", 0.01, variable=var)
        gpx.set_Controls("parmMax", 100.0, variable=var)
    elif kind == "mustrain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 100.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2] = [True, False, False]
        var = f"{phase.id}:0:Mustrain;i"
        gpx.set_Controls("parmMin", 0.0, variable=var)
        gpx.set_Controls("parmMax", 20000.0, variable=var)
    else:
        raise ValueError(kind)

    gpx.set_Controls("cycles", 10)
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    gpx = G2sc.G2Project(str(out))
    gpx.set_Controls("cycles", 5)
    gpx.refine(makeBack=False)
    gpx.save()
    hist = gpx.histogram(0)
    hap = gpx.phase(phase_index).getHAPvalues(hist.name)
    result = {
        "phase_index": phase_index,
        "phase": phase_name,
        "kind": kind,
        "rwp": hist.residuals.get("wR"),
        "rp": hist.residuals.get("R"),
        "rf2": hist.residuals.get(f"{phase_index}:0:Rf^2"),
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "frozen": gpx.get_Frozen(),
        "path": str(out),
    }
    print("BROAD_RESULT " + json.dumps(result, default=float))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("phase_index", type=int, choices=(0, 1, 2))
    parser.add_argument("kind", choices=("size", "mustrain"))
    args = parser.parse_args()
    run(args.phase_index, args.kind)
