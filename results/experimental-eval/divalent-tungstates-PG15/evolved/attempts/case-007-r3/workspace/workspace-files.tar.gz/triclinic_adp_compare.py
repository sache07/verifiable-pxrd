#!/usr/bin/env python3
"""Compare the P-1 WO3 alternate with the same common-ADP baseline."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trial_wo3_pminus1_2106293.gpx"
OUT = ROOT / "triclinic_adp_base.gpx"

project = G2sc.G2Project(str(SOURCE))
project.save(str(OUT))
project = G2sc.G2Project(str(OUT))
hist = project.histogram(0)
phase = project.phase(2)

# Match the selected model: one common positive Uiso, no strain or texture.
variables = []
for index, atom in enumerate(phase.atoms()):
    atom.uiso = 0.008
    atom.refinement_flags = "U"
    variables.append(f"2::AUiso:{index}")
hap = phase.getHAPvalues(hist.name)
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][0] = 0.0
hap["Mustrain"][2] = [False, False, False]
for item in project.phases():
    po = item.getHAPvalues(hist.name)["Pref.Ori."]
    po[0], po[1], po[2] = "MD", 1.0, False

project.save()
project.add_EquivConstr(variables, reloadIdx=True)
for variable in variables:
    project.set_Controls("parmMin", 0.0, variable=variable)
    project.set_Controls("parmMax", 0.05, variable=variable)
project.set_Frozen()
project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
project.data["Controls"]["data"]["shift factor"] = 0.2
project.set_Controls("cycles", 30)
project.save()

for number in range(6):
    project.refine(makeBack=False)
    project.save()
    project = G2sc.G2Project(str(OUT))
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.data["Controls"]["data"]["shift factor"] = 0.2
    project.set_Controls("cycles", 30)
    hist = project.histogram(0)
    print("TRICLINIC_REPLAY " + json.dumps({
        "number": number + 1,
        "Rwp_percent": hist.residuals.get("wR"),
        "Rp_percent": hist.residuals.get("R"),
    }, sort_keys=True), flush=True)

hist = project.histogram(0)
cov = project.data["Covariance"]["data"]
sig = dict(zip((str(v) for v in cov.get("varyList", [])), cov.get("sig", [])))
print("TRICLINIC_ADP " + json.dumps({
    "residuals": hist.residuals,
    "fractions": hist.ComputeMassFracs(),
    "cell": project.phase(2).get_cell(),
    "uiso": project.phase(2).atoms()[0].uiso,
    "uiso_sigma": sig.get("2::AUiso:0"),
    "n_refined_parameters": len(cov.get("varyList", [])),
    "frozen": project.get_Frozen(),
    "path": str(OUT),
}, default=float, sort_keys=True))
