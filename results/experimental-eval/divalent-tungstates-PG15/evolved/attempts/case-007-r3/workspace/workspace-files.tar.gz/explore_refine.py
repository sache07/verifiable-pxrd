#!/usr/bin/env python3
"""Exploratory GSAS-II Rietveld refinement for the Mg-O-W pattern."""

from pathlib import Path
import json
import math
import sys

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    cod_id = str(cod_id)
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def project_summary(gpx, label):
    hist = gpx.histogram(0)
    print(f"\n=== {label} ===")
    print("residuals", json.dumps(hist.residuals, sort_keys=True, default=float))
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.",
                                  "U", "V", "W", "X", "Y", "Z", "SH/L")})
    print("sample", {k: v for k, v in hist.SampleParameters.items()
                     if k in ("Type", "Gonio. radius", "Scale", "Shift", "Transparency",
                              "SurfRoughA", "SurfRoughB")})
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist.name)
        print("phase", phase.name, "composition", phase.composition,
              "density", phase.density, "cell", phase.get_cell(),
              "scale", hap["Scale"], "size", hap["Size"],
              "mustrain", hap["Mustrain"], "PO", hap["Pref.Ori."])
    try:
        print("mass_fracs", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass_fracs unavailable", repr(exc))
    print("frozen", gpx.get_Frozen())


def refine(gpx, label, cycles=8):
    gpx.set_Controls("cycles", cycles)
    gpx.refine(makeBack=False)
    project_summary(gpx, label)
    return gpx


def make_project(outfile, phase_records):
    outfile = Path(outfile)
    if outfile.exists():
        outfile.unlink()
    gpx = G2sc.G2Project(newgpx=str(outfile))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma/tab/semicolon separated",
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "refine": False,
            "no. coeffs": 8,
            "coeffs": [900.0, -500.0, 300.0, -150.0, 80.0, -40.0, 20.0, -10.0],
        }
    })
    sample = hist.SampleParameters
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [-600.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    inst = hist.InstrumentParameters
    for key, value in {
        "U": 5.0, "V": 0.0, "W": 30.0, "X": 0.0, "Y": 0.0, "Z": 0.0,
        "SH/L": 0.002, "Polariz.": 0.5, "I(L2)/I(L1)": 0.5, "Zero": 0.0,
    }.items():
        inst[key][0] = value
        inst[key][1] = value
        inst[key][2] = False

    for name, cod_id in phase_records:
        phase = gpx.add_phase(
            str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
        )
        hap = phase.getHAPvalues(hist.name)
        hap["Scale"] = [1.0, False]
        # Explicit neutral nuisance model.
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][1][1] = 1.0
        hap["Size"][1][2] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2] = [False, False, False]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]

    gpx.save()
    gpx.index_ids()
    # Keep profile terms physical and scales nonnegative.
    for var, lo, hi in [
        (":0:U", 0.0, 200.0), (":0:W", 0.01, 300.0), (":0:X", 0.0, 100.0),
        (":0:Shift", -2000.0, 2000.0),
    ]:
        gpx.set_Controls("parmMin", lo, variable=var)
        gpx.set_Controls("parmMax", hi, variable=var)
    for phase in gpx.phases():
        var = f"{phase.id}:0:Scale"
        gpx.set_Controls("parmMin", 0.0, variable=var)
        gpx.set_Controls("parmMax", 1.0e8, variable=var)
    gpx.save()
    return gpx


def run(outfile, phase_records):
    gpx = make_project(outfile, phase_records)
    project_summary(gpx, "initial")
    hist = gpx.histogram(0)

    # Start from source/cell values: establish smooth background, scales and one
    # displacement correction under a fixed common profile.
    hist.set_refinements({"Background": {"refine": True}})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in gpx.phases():
        phase.set_HAP_refinements({"Scale": True})
    refine(gpx, "background + scales + specimen shift", 10)

    # Establish a small nonnegative common profile; V/Y/Z remain exactly zero.
    hist.set_refinements({"Instrument Parameters": ["U", "W"]})
    refine(gpx, "common U/W profile", 10)
    hist.set_refinements({"Instrument Parameters": ["X"]})
    refine(gpx, "common U/W/X profile", 10)

    # Only after position/profile convergence, refine symmetry-constrained cells.
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    refine(gpx, "cells + baseline reconvergence", 12)
    gpx.save()


if __name__ == "__main__":
    records = [
        ("MgWO4_P2c", "9013902"),
        ("MgO_Fm-3m", "9000499"),
        ("WO3_P21c", "1528915"),
    ]
    run(ROOT / "explore_3phase.gpx", records)
