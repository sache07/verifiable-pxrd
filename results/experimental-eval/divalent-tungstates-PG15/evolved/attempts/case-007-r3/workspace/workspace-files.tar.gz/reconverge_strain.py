#!/usr/bin/env python3
"""Reconverge the common profile after accepting WO3 isotropic strain."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
src = ROOT / "broad_2_WO3_candidate_mustrain.gpx"
out = ROOT / "profile_wo3_iso_strain.gpx"
gpx = G2sc.G2Project(str(src))
gpx.save(str(out))
gpx = G2sc.G2Project(str(out))
hist = gpx.histogram(0)

# Keep rejected phase terms neutral and release the accepted common profile.
for i, phase in enumerate(gpx.phases()):
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    hap = phase.getHAPvalues(hist.name)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][1][2] = 1.0
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0 if i != 2 else 1221.6
    hap["Mustrain"][1][2] = 1.0
    if i == 2:
        hap["Mustrain"][2][0] = True

for key in ("U", "X", "SH/L"):
    hist.InstrumentParameters[key][2] = True
for key in ("V", "W", "Y", "Z"):
    hist.InstrumentParameters[key][1] = 0.0
    hist.InstrumentParameters[key][2] = False

gpx.set_Frozen()
for var, lo, hi in [
    (":0:U", 0.0, 1000.0), (":0:X", 0.0, 100.0), (":0:SH/L", 0.00001, 2.0),
    ("2:0:Mustrain;i", 0.0, 20000.0),
]:
    gpx.set_Controls("parmMin", lo, variable=var)
    gpx.set_Controls("parmMax", hi, variable=var)

gpx.set_Controls("cycles", 12)
gpx.save()
gpx.refine(makeBack=False)
gpx.save()
gpx = G2sc.G2Project(str(out))
gpx.set_Controls("cycles", 6)
gpx.refine(makeBack=False)
gpx.save()

hist = gpx.histogram(0)
print("RECONVERGED " + json.dumps({
    "residuals": hist.residuals,
    "profile": {k: hist.InstrumentParameters[k][1] for k in
                ("U", "V", "W", "X", "Y", "Z", "SH/L")},
    "wo3_mustrain": gpx.phase(2).getHAPvalues(hist.name)["Mustrain"],
    "fractions": hist.ComputeMassFracs(),
    "frozen": gpx.get_Frozen(),
}, default=float, sort_keys=True))
