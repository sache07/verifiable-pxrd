#!/usr/bin/env python3
"""Nested term deletions from the full triclinic WO3 model."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "triclinic_full.gpx"


def run(label, no_strain=False, no_mg_texture=False,
        no_wo_texture=False, no_adp=False):
    out = ROOT / f"triclinic_nested_{label}.gpx"
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(out))
    project = G2sc.G2Project(str(out))
    hist = project.histogram(0)

    if no_strain:
        strain = project.phase(2).getHAPvalues(hist.name)["Mustrain"]
        strain[1][0] = 0.0
        strain[2] = [False, False, False]
    if no_mg_texture:
        po = project.phase(0).getHAPvalues(hist.name)["Pref.Ori."]
        po[1], po[2] = 1.0, False
    if no_wo_texture:
        po = project.phase(2).getHAPvalues(hist.name)["Pref.Ori."]
        po[1], po[2] = 1.0, False
    if no_adp:
        project.get_Constraints("Phase").clear()
        for atom in project.phase(2).atoms():
            atom.uiso = 0.0
            atom.refinement_flags = ""

    project.set_Frozen()
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.data["Controls"]["data"]["shift factor"] = 0.2
    project.set_Controls("cycles", 30)
    project.save()
    for _ in range(3):
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(out))
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
        project.data["Controls"]["data"]["shift factor"] = 0.2
        project.set_Controls("cycles", 30)

    hist = project.histogram(0)
    print("TRICLINIC_NESTED " + json.dumps({
        "label": label,
        "Rwp_percent": hist.residuals.get("wR"),
        "Rp_percent": hist.residuals.get("R"),
        "fractions": hist.ComputeMassFracs(),
        "uiso": project.phase(2).atoms()[0].uiso,
        "mustrain": project.phase(2).getHAPvalues(hist.name)["Mustrain"],
        "textures": {phase.name: phase.getHAPvalues(hist.name)["Pref.Ori."]
                     for phase in project.phases()},
        "frozen": project.get_Frozen(),
        "path": str(out),
    }, default=float, sort_keys=True), flush=True)


run("no_strain", no_strain=True)
run("no_mg_texture", no_mg_texture=True)
run("no_wo_texture", no_wo_texture=True)
run("no_textures", no_mg_texture=True, no_wo_texture=True)
run("no_adp", no_adp=True)
