#!/usr/bin/env python3
"""Rebuild the accepted model with WO3 in a conventional P21/n setting."""

from copy import deepcopy
from pathlib import Path
import json
import math

from GSASII import GSASIIscriptable as G2sc

from explore_refine import cod_path


ROOT = Path(__file__).resolve().parent
SEED = ROOT / "adp_nuisance_strain_both_textures.gpx"
OUT = ROOT / "conventional_model.gpx"


def transformed_wo3_cell(old_cell):
    a = old_cell["length_a"]
    b = old_cell["length_b"]
    c = old_cell["length_c"]
    beta = math.radians(old_cell["angle_beta"])
    new_a = math.sqrt(a * a + c * c + 2.0 * a * c * math.cos(beta))
    cos_new_beta = -(a + c * math.cos(beta)) / new_a
    new_beta = math.degrees(math.acos(max(-1.0, min(1.0, cos_new_beta))))
    volume = old_cell["volume"]
    return [new_a, b, a, 90.0, new_beta, 90.0, volume]


seed = G2sc.G2Project(str(SEED))
seed_hist = seed.histogram(0)
if OUT.exists():
    OUT.unlink()
project = G2sc.G2Project(newgpx=str(OUT))
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "instrument.instprm"),
    fmthint="comma/tab/semicolon separated",
)
hist.data["Limits"][1] = list(seed_hist.data["Limits"][1])
hist.data["Background"] = deepcopy(seed_hist.data["Background"])
hist.data["Instrument Parameters"] = deepcopy(seed_hist.data["Instrument Parameters"])
hist.data["Sample Parameters"] = deepcopy(seed_hist.data["Sample Parameters"])

phase_files = (
    ("MgWO4_P2c", cod_path("9013902")),
    ("MgO_Fm-3m", cod_path("9000499")),
    ("WO3_P21n", ROOT / "wo3_2311041_conventional.cif"),
)
for name, path in phase_files:
    project.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
project.save()
project = G2sc.G2Project(str(OUT))
hist = project.histogram(0)

# Transfer exact seed cells for unchanged phases and the unimodular transform
# of the refined WO3 cell for the new setting.
for index in (0, 1):
    old = seed.phase(index).get_cell()
    project.phase(index).data["General"]["Cell"][1:8] = [
        old["length_a"], old["length_b"], old["length_c"],
        old["angle_alpha"], old["angle_beta"], old["angle_gamma"], old["volume"],
    ]
old_wo3 = seed.phase(2).get_cell()
project.phase(2).data["General"]["Cell"][1:8] = transformed_wo3_cell(old_wo3)

for index, phase in enumerate(project.phases()):
    old_hap = seed.phase(index).getHAPvalues(seed_hist.name)
    hap = phase.getHAPvalues(hist.name)
    hap["Scale"] = deepcopy(old_hap["Scale"])
    hap["Size"] = deepcopy(old_hap["Size"])
    hap["HStrain"] = deepcopy(old_hap["HStrain"])
    hap["Extinction"] = deepcopy(old_hap["Extinction"])
    hap["Babinet"] = deepcopy(old_hap["Babinet"])
    hap["Mustrain"] = deepcopy(old_hap["Mustrain"])
    hap["Pref.Ori."] = deepcopy(old_hap["Pref.Ori."])
    phase.data["General"]["Cell"][0] = True

# The b axis is unchanged, so the accepted WO3 [010] texture axis transfers
# directly. Keep one common positive Uiso across all WO3 sites.
seed_uiso = seed.phase(2).atoms()[0].uiso
adp_variables = []
for index, atom in enumerate(project.phase(2).atoms()):
    atom.uiso = seed_uiso
    atom.refinement_flags = "U"
    adp_variables.append(f"2::AUiso:{index}")

project.save()
project.add_EquivConstr(adp_variables, reloadIdx=True)
for variable in adp_variables:
    project.set_Controls("parmMin", 0.0, variable=variable)
    project.set_Controls("parmMax", 0.05, variable=variable)
for variable, lower, upper in (
    (":0:U", 0.0, 1000.0), (":0:X", 0.0, 100.0),
    (":0:SH/L", 0.00001, 2.0), (":0:Shift", -2000.0, 2000.0),
    (":0:SurfRoughB", 0.0, 2.0), ("2:0:Mustrain;i", 0.0, 20000.0),
    ("0:0:MD", 0.2, 5.0), ("2:0:MD", 0.2, 5.0),
):
    project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", upper, variable=variable)
for phase in project.phases():
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
    project.set_Controls("parmMax", 1.0e8, variable=f"{phase.id}:0:Scale")

project.set_Frozen()
project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
project.data["Controls"]["data"]["shift factor"] = 0.2
project.set_Controls("cycles", 30)
project.save()

for number in range(6):
    project.refine(makeBack=False)
    project.save()
    project = G2sc.G2Project(str(OUT))
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.data["Controls"]["data"]["shift factor"] = 0.2
    project.set_Controls("cycles", 30)
    hist = project.histogram(0)
    print("CONVENTIONAL_REPLAY " + json.dumps({
        "number": number + 1,
        "Rwp_percent": hist.residuals.get("wR"),
        "Rp_percent": hist.residuals.get("R"),
    }, sort_keys=True), flush=True)

hist = project.histogram(0)
cov = project.data["Covariance"]["data"]
sig = dict(zip((str(v) for v in cov.get("varyList", [])), cov.get("sig", [])))
print("CONVENTIONAL_FINAL " + json.dumps({
    "residuals": hist.residuals,
    "fractions": hist.ComputeMassFracs(),
    "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    "wo3_uiso": project.phase(2).atoms()[0].uiso,
    "uiso_sigma": sig.get("2::AUiso:0"),
    "mustrain": project.phase(2).getHAPvalues(hist.name)["Mustrain"],
    "textures": {phase.name: phase.getHAPvalues(hist.name)["Pref.Ori."]
                 for phase in project.phases()},
    "frozen": project.get_Frozen(),
    "path": str(OUT),
}, default=float, sort_keys=True))
