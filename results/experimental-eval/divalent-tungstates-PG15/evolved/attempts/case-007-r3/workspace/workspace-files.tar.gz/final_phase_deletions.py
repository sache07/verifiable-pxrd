#!/usr/bin/env python3
"""Nested phase-deletion challenges from the final common model."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "triclinic_full.gpx"


def run(label, omitted):
    out = ROOT / f"triclinic_phase_delete_{label}.gpx"
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(out))
    project = G2sc.G2Project(str(out))
    hist = project.histogram(0)

    for index in omitted:
        phase = project.phase(index)
        hap = phase.getHAPvalues(hist.name)
        hap["Use"] = False
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        phase.data["General"]["Cell"][0] = False

    project.set_Frozen()
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.data["Controls"]["data"]["shift factor"] = 0.2
    project.set_Controls("cycles", 12)
    project.save()
    for _ in range(3):
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(out))
        project.set_Controls("cycles", 8)

    hist = project.histogram(0)
    print("PHASE_DELETE " + json.dumps({
        "label": label,
        "omitted": [project.phase(index).name for index in omitted],
        "Rwp_percent": hist.residuals.get("wR"),
        "Rp_percent": hist.residuals.get("R"),
        "Rexp_percent": hist.residuals.get("wRmin"),
        "frozen": project.get_Frozen(),
        "path": str(out),
    }, sort_keys=True))


run("no_mgo", [1])
run("no_wo3", [2])
run("mgwo4_only", [1, 2])
