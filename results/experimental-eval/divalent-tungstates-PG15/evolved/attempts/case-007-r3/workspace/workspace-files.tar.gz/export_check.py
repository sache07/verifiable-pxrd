#!/usr/bin/env python3
"""Export the converged candidate and print structural sanity-check data."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
OUT = ROOT / ".tmp" / "geometry_check"
OUT.mkdir(parents=True, exist_ok=True)

gpx = G2sc.G2Project(str(ROOT / "texture_nested_both.gpx"))
hist = gpx.histogram(0)
records = []
for index, phase in enumerate(gpx.phases()):
    path = OUT / f"phase_{index}.cif"
    phase.export_CIF(str(path))
    cell, cell_esd = phase.get_cell_and_esd()
    records.append({
        "index": index,
        "name": phase.name,
        "formula": phase.data["General"].get("F000X"),
        "space_group": phase.data["General"]["SGData"]["SpGrp"],
        "composition_per_cell": phase.composition,
        "density_g_cm3": phase.density,
        "cell": cell,
        "cell_esd": cell_esd,
        "atoms": [{
            "label": atom.label,
            "element": atom.element,
            "coordinates": atom.coordinates,
            "occupancy": atom.occupancy,
            "multiplicity": atom.mult,
            "refinement_flags": atom.refinement_flags,
        } for atom in phase.atoms()],
        "cif": str(path),
    })

print(json.dumps({
    "residuals": hist.residuals,
    "fractions": hist.ComputeMassFracs(),
    "structures": records,
}, indent=2, default=float, sort_keys=True))
