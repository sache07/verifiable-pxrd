#!/usr/bin/env python3
"""Read-only consistency checks for the submitted result bundle."""

from pathlib import Path
import json
import re

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
project = G2sc.G2Project(str(ROOT / "final.gpx"))
hist = project.histogram(0)
result = json.loads((ROOT / "result.json").read_text())

internal_to_public = {
    "MgWO4_P2c": "MgWO4",
    "MgO_Fm-3m": "MgO",
    "WO3_candidate": "WO3",
}
public = {phase["name"]: phase for phase in result["phases"]}
fractions = hist.ComputeMassFracs()
assert abs(sum(item[0] for item in fractions.values()) - 1.0) < 1e-12

for phase in project.phases():
    item = public[internal_to_public[phase.name]]
    assert (ROOT / item["cif_path"]).is_file()
    assert abs(item["weight_fraction"] - fractions[phase.name][0]) < 1e-12
    assert abs(item["formal_weight_fraction_std"] - fractions[phase.name][1]) < 1e-12
    cell = phase.get_cell()
    for key, value in item["cell"].items():
        assert abs(value - cell[key]) < 1e-10
    assert all(atom.occupancy == 1.0 for atom in phase.atoms())
    if phase.name == "WO3_candidate":
        assert all(atom.refinement_flags.strip() == "U" for atom in phase.atoms())
        uiso = [atom.uiso for atom in phase.atoms()]
        assert min(uiso) > 0.0 and max(uiso) - min(uiso) < 1e-12
    else:
        assert all(atom.refinement_flags.strip() == "" for atom in phase.atoms())

stats = result["fit_statistics"]
assert abs(stats["Rwp_percent"] - hist.residuals["wR"]) < 1e-12
assert abs(stats["Rp_percent"] - hist.residuals["R"]) < 1e-12
assert abs(stats["Rexp_percent"] - hist.residuals["wRmin"]) < 1e-12

profile = np.genfromtxt(ROOT / "fit.csv", delimiter=",", names=True)
x = np.asarray(hist.getdata("X"), dtype=float)
y_obs = np.asarray(hist.getdata("Yobs"), dtype=float)
y_calc = np.asarray(hist.getdata("Ycalc"), dtype=float)
used = np.isfinite(y_calc) & (y_calc != 0.0)
assert len(profile) == int(np.count_nonzero(used)) == stats["number_of_profile_points"]
assert np.max(np.abs(profile["two_theta_deg"] - x[used])) < 5.1e-9
assert np.max(np.abs(profile["observed"] - y_obs[used])) < 5.1e-9
assert np.max(np.abs(profile["calculated"] - y_calc[used])) < 5.1e-9
assert np.max(np.abs(profile["difference"] - (y_obs[used] - y_calc[used]))) < 5.1e-9

instrument = hist.InstrumentParameters
for key in ("U", "W", "X", "Y", "Z", "SH/L"):
    assert instrument[key][1] >= 0.0
controls = project.data["Controls"]["data"]
frozen = controls.get("parmFrozen", {})
assert not frozen.get("FrozenList", [])

for item in result["phases"]:
    text = (ROOT / item["cif_path"]).read_text()
    assert "_atom_site_occupancy" in text
    assert re.search(r"_symmetry_space_group_name_H-M\s+", text)

print(json.dumps({
    "status": "validated",
    "phases": {name: public[name]["weight_percent"] for name in public},
    "fraction_sum": sum(item["weight_fraction"] for item in result["phases"]),
    "Rwp_percent": stats["Rwp_percent"],
    "profile_rows": len(profile),
    "refined_parameters": stats["number_of_refined_parameters"],
}, indent=2, sort_keys=True))
