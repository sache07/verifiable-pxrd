#!/usr/bin/env python3
"""Challenge zero placeholder WO3 ADPs with minimal grouped models."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "final.gpx"


def run(label, grouped):
    out = ROOT / f"wo3_adp_{label}.gpx"
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(out))
    project = G2sc.G2Project(str(out))
    phase = project.phase(2)

    atom_groups = []
    if grouped:
        for element, initial in (("O", 0.006), ("W", 0.003)):
            indices = []
            for index, atom in enumerate(phase.atoms()):
                if atom.element == element:
                    atom.uiso = initial
                    atom.refinement_flags = "U"
                    indices.append(index)
            atom_groups.append(indices)
    else:
        indices = []
        for index, atom in enumerate(phase.atoms()):
            atom.uiso = 0.005
            atom.refinement_flags = "U"
            indices.append(index)
        atom_groups.append(indices)

    project.save()
    for indices in atom_groups:
        variables = [f"2::AUiso:{index}" for index in indices]
        project.add_EquivConstr(variables, reloadIdx=True)
        for variable in variables:
            project.set_Controls("parmMin", 0.0, variable=variable)
            project.set_Controls("parmMax", 0.05, variable=variable)

    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.save()
    for _ in range(3):
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(out))
        project.set_Controls("cycles", 8)

    hist = project.histogram(0)
    phase = project.phase(2)
    cov = project.data["Covariance"]["data"]
    print("ADP_TRIAL " + json.dumps({
        "label": label,
        "Rwp_percent": hist.residuals.get("wR"),
        "Rp_percent": hist.residuals.get("R"),
        "fractions": hist.ComputeMassFracs(),
        "wo3_adps": [{"label": atom.label, "element": atom.element,
                       "uiso": atom.uiso, "flags": atom.refinement_flags}
                      for atom in phase.atoms()],
        "refined_adp_parameters": [str(v) for v in cov.get("varyList", [])
                                    if "AUiso" in str(v)],
        "po": phase.getHAPvalues(hist.name)["Pref.Ori."],
        "profile": {key: hist.InstrumentParameters[key][1]
                    for key in ("U", "X", "SH/L")},
        "frozen": project.get_Frozen(),
        "constraints": [str(c) for c in project.get_Constraints("Phase")],
        "path": str(out),
    }, sort_keys=True))


run("common", False)
run("elements", True)
