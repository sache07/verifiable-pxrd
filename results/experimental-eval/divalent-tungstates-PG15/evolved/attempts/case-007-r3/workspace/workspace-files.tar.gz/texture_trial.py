#!/usr/bin/env python3
"""Challenge symmetry-distinct March-Dollase preferred-orientation axes."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "profile_wo3_iso_strain.gpx"


def run(phase_index, axis):
    axis_label = "".join(str(v).replace("-", "m") for v in axis)
    out = ROOT / f"texture_{phase_index}_{axis_label}.gpx"
    gpx = G2sc.G2Project(str(BASE))
    gpx.save(str(out))
    gpx = G2sc.G2Project(str(out))
    hist = gpx.histogram(0)
    # Hold peak-shape terms during the texture challenge.
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        hist.InstrumentParameters[key][2] = False
    for p in gpx.phases():
        hap = p.getHAPvalues(hist.name)
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    phase = gpx.phase(phase_index)
    hap = phase.getHAPvalues(hist.name)
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    gpx.set_Frozen()
    var = f"{phase.id}:0:MD"
    gpx.set_Controls("parmMin", 0.2, variable=var)
    gpx.set_Controls("parmMax", 5.0, variable=var)
    gpx.set_Controls("cycles", 10)
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    gpx = G2sc.G2Project(str(out))
    gpx.set_Controls("cycles", 5)
    gpx.refine(makeBack=False)
    gpx.save()
    hist = gpx.histogram(0)
    po = gpx.phase(phase_index).getHAPvalues(hist.name)["Pref.Ori."]
    print("TEXTURE_RESULT " + json.dumps({
        "phase_index": phase_index,
        "phase": phase.name,
        "axis": axis,
        "md": po[1],
        "rwp": hist.residuals.get("wR"),
        "rp": hist.residuals.get("R"),
        "rf2": hist.residuals.get(f"{phase_index}:0:Rf^2"),
        "frozen": gpx.get_Frozen(),
        "path": str(out),
    }, default=float))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("phase_index", type=int, choices=(0, 1, 2))
    parser.add_argument("h", type=int)
    parser.add_argument("k", type=int)
    parser.add_argument("l", type=int)
    args = parser.parse_args()
    run(args.phase_index, [args.h, args.k, args.l])
