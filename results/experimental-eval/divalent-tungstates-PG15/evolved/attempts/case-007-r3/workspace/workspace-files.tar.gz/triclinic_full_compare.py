#!/usr/bin/env python3
"""Apply the accepted nuisance model to the P-1 WO3 alternate."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "triclinic_adp_base.gpx"
OUT = ROOT / "triclinic_full.gpx"

project = G2sc.G2Project(str(SOURCE))
project.save(str(OUT))
project = G2sc.G2Project(str(OUT))
hist = project.histogram(0)

wo = project.phase(2).getHAPvalues(hist.name)
wo["Mustrain"][0] = "isotropic"
wo["Mustrain"][1][0] = 850.0
wo["Mustrain"][2] = [True, False, False]
for phase, value, axis in (
    (project.phase(0), 0.988, [0, 0, 1]),
    (project.phase(2), 1.031, [0, 1, 0]),
):
    po = phase.getHAPvalues(hist.name)["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", value, True, axis

project.set_Frozen()
project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
project.data["Controls"]["data"]["shift factor"] = 0.2
project.set_Controls("cycles", 30)
project.save()

for number in range(6):
    project.refine(makeBack=False)
    project.save()
    project = G2sc.G2Project(str(OUT))
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.data["Controls"]["data"]["shift factor"] = 0.2
    project.set_Controls("cycles", 30)
    hist = project.histogram(0)
    print("TRICLINIC_FULL_REPLAY " + json.dumps({
        "number": number + 1,
        "Rwp_percent": hist.residuals.get("wR"),
        "Rp_percent": hist.residuals.get("R"),
    }, sort_keys=True), flush=True)

hist = project.histogram(0)
cov = project.data["Covariance"]["data"]
sig = dict(zip((str(v) for v in cov.get("varyList", [])), cov.get("sig", [])))
print("TRICLINIC_FULL " + json.dumps({
    "residuals": hist.residuals,
    "fractions": hist.ComputeMassFracs(),
    "cell": project.phase(2).get_cell(),
    "uiso": project.phase(2).atoms()[0].uiso,
    "mustrain": project.phase(2).getHAPvalues(hist.name)["Mustrain"],
    "textures": {phase.name: phase.getHAPvalues(hist.name)["Pref.Ori."]
                 for phase in project.phases()},
    "sigmas": {key: value for key, value in sig.items()
               if key in ("2::AUiso:0", "2:0:Mustrain;i", "0:0:MD", "2:0:MD")},
    "n_refined_parameters": len(cov.get("varyList", [])),
    "frozen": project.get_Frozen(),
    "path": str(OUT),
}, default=float, sort_keys=True))
