#!/usr/bin/env python3
"""Compare phase inventories and WO3 polymorphs under one restrained model."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2sc

from explore_refine import make_project


ROOT = Path(__file__).resolve().parent

TRIALS = {
    "no_mgo": [("MgWO4_P2c", "9013902"), ("WO3_candidate", "1528915")],
    "no_wo3": [("MgWO4_P2c", "9013902"), ("MgO_Fm-3m", "9000499")],
    "mgwo4_only": [("MgWO4_P2c", "9013902")],
    "wo3_p21c_1528915": [("MgWO4_P2c", "9013902"), ("MgO_Fm-3m", "9000499"),
                          ("WO3_candidate", "1528915")],
    "wo3_p21c_2311041": [("MgWO4_P2c", "9013902"), ("MgO_Fm-3m", "9000499"),
                          ("WO3_candidate", "2311041")],
    "wo3_pminus1_2106293": [("MgWO4_P2c", "9013902"), ("MgO_Fm-3m", "9000499"),
                             ("WO3_candidate", "2106293")],
    "wo3_p21m_1010618": [("MgWO4_P2c", "9013902"), ("MgO_Fm-3m", "9000499"),
                          ("WO3_candidate", "1010618")],
    "wo3_pnma_2107312": [("MgWO4_P2c", "9013902"), ("MgO_Fm-3m", "9000499"),
                          ("WO3_candidate", "2107312")],
    "wo3_p4ncc_1521532": [("MgWO4_P2c", "9013902"), ("MgO_Fm-3m", "9000499"),
                           ("WO3_candidate", "1521532")],
    "wo3_p21c_1563541": [("MgWO4_P2c", "9013902"), ("MgO_Fm-3m", "9000499"),
                          ("WO3_candidate", "1563541")],
}


def set_inst(inst, key, value, flag):
    inst[key][0] = float(value)
    inst[key][1] = float(value)
    inst[key][2] = bool(flag)


def run_trial(name):
    path = ROOT / f"trial_{name}.gpx"
    gpx = make_project(path, TRIALS[name])
    hist = gpx.histogram(0)
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1", "refine": True, "no. coeffs": 8,
            "coeffs": [672.85, -693.74, 440.73, -228.86, 119.45, -55.14, 29.79, -21.25],
        }
    })
    inst = hist.InstrumentParameters
    set_inst(inst, "U", 68.70, True)
    set_inst(inst, "V", 0.0, False)
    set_inst(inst, "W", 0.0, False)
    set_inst(inst, "X", 9.09, True)
    set_inst(inst, "Y", 0.0, False)
    set_inst(inst, "Z", 0.0, False)
    set_inst(inst, "SH/L", 0.0211, True)
    sample = hist.SampleParameters
    sample["Shift"] = [-539.5, True]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.1097, True]
    hist.set_refinements({"Limits": [10.0, 100.0]})

    for phase in gpx.phases():
        if phase.name.startswith("MgWO4"):
            phase.HAPvalue("Scale", 121.0)
        elif phase.name.startswith("MgO"):
            phase.HAPvalue("Scale", 39.0)
        else:
            phase.HAPvalue("Scale", 6.4)
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})

    gpx.set_Frozen()
    for var, lo, hi in [
        (":0:U", 0.0, 1000.0), (":0:W", 0.0, 300.0), (":0:X", 0.0, 100.0),
        (":0:SH/L", 0.00001, 2.0), (":0:Shift", -2000.0, 2000.0),
        (":0:SurfRoughB", 0.0, 2.0),
    ]:
        gpx.set_Controls("parmMin", lo, variable=var)
        gpx.set_Controls("parmMax", hi, variable=var)
    for phase in gpx.phases():
        var = f"{phase.id}:0:Scale"
        gpx.set_Controls("parmMin", 0.0, variable=var)
        gpx.set_Controls("parmMax", 1.0e8, variable=var)

    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.refine(makeBack=False)
    # Full-range reopen/replay to test stability after the source/inventory change.
    gpx.save()
    gpx = G2sc.G2Project(str(path))
    gpx.set_Controls("cycles", 6)
    gpx.refine(makeBack=False)
    gpx.save()

    hist = gpx.histogram(0)
    result = {
        "trial": name,
        "rwp": hist.residuals.get("wR"),
        "rp": hist.residuals.get("R"),
        "gof": hist.residuals.get("wR", 0.0) / hist.residuals.get("wRmin", 1.0),
        "profile": {k: hist.InstrumentParameters[k][1] for k in ("U", "W", "X", "SH/L")},
        "sample": {k: hist.SampleParameters[k][0] for k in
                   ("Shift", "SurfRoughA", "SurfRoughB")},
        "frozen": gpx.get_Frozen(),
        "phases": [],
    }
    try:
        fracs = hist.ComputeMassFracs()
    except Exception:
        fracs = {}
    for phase in gpx.phases():
        result["phases"].append({
            "name": phase.name,
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "cell": phase.get_cell(),
            "scale": phase.HAPvalue("Scale"),
            "weight_fraction": fracs.get(phase.name, (None, None))[0],
            "rf2": hist.residuals.get(f"{phase.id}:0:Rf^2"),
        })
    print("TRIAL_RESULT " + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("trials", nargs="+", choices=sorted(TRIALS))
    args = parser.parse_args()
    for trial in args.trials:
        run_trial(trial)
