#!/usr/bin/env python3
"""Nested preferred-orientation deletions from the combined model."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "combined_texture.gpx"


def run(label, keep_mgwo4, keep_wo3):
    out = ROOT / f"texture_nested_{label}.gpx"
    gpx = G2sc.G2Project(str(SOURCE))
    gpx.save(str(out))
    gpx = G2sc.G2Project(str(out))
    hist = gpx.histogram(0)

    settings = (
        (gpx.phase(0), keep_mgwo4, [0, 0, 1]),
        (gpx.phase(2), keep_wo3, [0, 1, 0]),
    )
    for phase, keep, axis in settings:
        po = phase.getHAPvalues(hist.name)["Pref.Ori."]
        po[0] = "MD"
        po[1] = po[1] if keep else 1.0
        po[2] = bool(keep)
        po[3] = axis

    gpx.set_Frozen()
    gpx.set_Controls("cycles", 12)
    gpx.save()
    for _ in range(3):
        gpx.refine(makeBack=False)
        gpx.save()
        gpx = G2sc.G2Project(str(out))
        gpx.set_Controls("cycles", 8)

    hist = gpx.histogram(0)
    cov = gpx.data["Covariance"]["data"]
    sig = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    print("NESTED " + json.dumps({
        "label": label,
        "path": str(out),
        "residuals": hist.residuals,
        "fractions": hist.ComputeMassFracs(),
        "po": {
            p.name: p.getHAPvalues(hist.name)["Pref.Ori."]
            for p in gpx.phases()
        },
        "po_sig": {k: v for k, v in sig.items() if k.endswith(":MD")},
        "frozen": gpx.get_Frozen(),
    }, default=float, sort_keys=True))


for args in (
    ("both", True, True),
    ("mgwo4", True, False),
    ("wo3", False, True),
    ("none", False, False),
):
    run(*args)
