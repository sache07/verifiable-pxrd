#!/usr/bin/env python3
"""Stabilize the common-ADP baseline with strain and texture neutralized."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "adp_rebuilt.gpx"
OUT = ROOT / "adp_stable_base.gpx"

project = G2sc.G2Project(str(SOURCE))
project.save(str(OUT))
project = G2sc.G2Project(str(OUT))
hist = project.histogram(0)

for phase in project.phases():
    hap = phase.getHAPvalues(hist.name)
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False

project.set_Frozen()
project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
project.data["Controls"]["data"]["shift factor"] = 0.2
project.set_Controls("cycles", 30)
project.save()

for number in range(6):
    project.refine(makeBack=False)
    project.save()
    project = G2sc.G2Project(str(OUT))
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.data["Controls"]["data"]["shift factor"] = 0.2
    project.set_Controls("cycles", 30)
    hist = project.histogram(0)
    print("BASE_REPLAY " + json.dumps({
        "number": number + 1,
        "Rwp_percent": hist.residuals.get("wR"),
        "Rp_percent": hist.residuals.get("R"),
    }, sort_keys=True))

hist = project.histogram(0)
cov = project.data["Covariance"]["data"]
sig = dict(zip((str(v) for v in cov.get("varyList", [])), cov.get("sig", [])))
print("ADP_BASE " + json.dumps({
    "residuals": hist.residuals,
    "fractions": hist.ComputeMassFracs(),
    "wo3_uiso": project.phase(2).atoms()[0].uiso,
    "uiso_sigma": sig.get("2::AUiso:0"),
    "profile": {key: hist.InstrumentParameters[key][1]
                for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
    "sample": {key: hist.SampleParameters[key]
               for key in ("Shift", "SurfRoughA", "SurfRoughB")},
    "frozen": project.get_Frozen(),
    "path": str(OUT),
}, default=float, sort_keys=True))
