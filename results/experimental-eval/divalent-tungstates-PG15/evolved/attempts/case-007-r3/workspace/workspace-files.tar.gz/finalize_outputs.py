#!/usr/bin/env python3
"""Replay the accepted model and export all user-facing deliverables."""

from pathlib import Path
import csv
import json
import math

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "triclinic_full.gpx"
FINAL = ROOT / "final.gpx"
PHASE_DIR = ROOT / "phases"

PHASE_INFO = {
    "MgWO4_P2c": {
        "name": "MgWO4",
        "formula": "MgWO4",
        "cif": "phases/MgWO4.cif",
        "source": "COD 9013902",
    },
    "MgO_Fm-3m": {
        "name": "MgO",
        "formula": "MgO",
        "cif": "phases/MgO.cif",
        "source": "COD 9000499",
    },
    "WO3_candidate": {
        "name": "WO3",
        "formula": "WO3",
        "cif": "phases/WO3.cif",
        "source": "COD 2106293",
    },
}


def replay(project_path):
    """Refine after reopening so exported values come from a replayed project."""
    project = G2sc.G2Project(str(project_path))
    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    project.save()
    return G2sc.G2Project(str(project_path))


# Copy by GSAS-II save, then reopen/refine/reopen on the submitted filename.
project = G2sc.G2Project(str(SOURCE))
project.save(str(FINAL))
project = replay(FINAL)
project = replay(FINAL)

hist = project.histogram(0)
fractions = hist.ComputeMassFracs()
residuals = hist.residuals
covariance = project.data["Covariance"]["data"]

PHASE_DIR.mkdir(exist_ok=True)
phase_results = []
for phase in project.phases():
    info = PHASE_INFO[phase.name]
    cif_path = ROOT / info["cif"]
    phase.export_CIF(str(cif_path))
    cell, cell_esd = phase.get_cell_and_esd()
    fraction, fraction_esd = fractions[phase.name]
    phase_results.append({
        "name": info["name"],
        "formula": info["formula"],
        "space_group": phase.data["General"]["SGData"]["SpGrp"],
        "cif_path": info["cif"],
        "structure_source": info["source"],
        "weight_fraction": fraction,
        "weight_percent": 100.0 * fraction,
        "formal_weight_fraction_std": fraction_esd,
        "bragg_R_F_squared_percent": residuals.get(f"{phase.id}:0:Rf^2"),
        "cell": cell,
        "cell_formal_std": cell_esd,
    })

# Export the exact profile used in the global fit statistics. Points outside
# the selected 10--100 degree range are intentionally excluded, since GSAS-II
# does not calculate them.
x = np.asarray(hist.getdata("X"), dtype=float)
y_obs = np.asarray(hist.getdata("Yobs"), dtype=float)
y_calc = np.asarray(hist.getdata("Ycalc"), dtype=float)
low, high = map(float, hist.data["Limits"][1])
# GSAS-II selects the first grid point at/above each requested bound and uses
# the upper endpoint inclusively. The nonzero calculated-profile span mirrors
# that exact internal selection (8,284 points here, including 100.00795 deg).
used = np.isfinite(y_calc) & (y_calc != 0.0)
with (ROOT / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(("two_theta_deg", "observed", "calculated", "difference"))
    for row in zip(x[used], y_obs[used], y_calc[used], y_obs[used] - y_calc[used]):
        writer.writerow((f"{row[0]:.8f}", f"{row[1]:.8f}",
                         f"{row[2]:.8f}", f"{row[3]:.8f}"))

rwp = float(residuals["wR"])
rp = float(residuals["R"])
rexp = float(residuals["wRmin"])
gof = rwp / rexp
result = {
    "project_path": "final.gpx",
    "profile_path": "fit.csv",
    "fraction_normalization": "modeled crystalline phases only",
    "phases": phase_results,
    "fit_statistics": {
        "Rwp_percent": rwp,
        "Rp_percent": rp,
        "Rexp_percent": rexp,
        "goodness_of_fit": gof,
        "reduced_chi_squared": gof * gof,
        "number_of_profile_points": int(np.count_nonzero(used)),
        "number_of_refined_parameters": len(covariance.get("varyList", [])),
        "two_theta_range_deg": [low, high],
        "calculated_profile_point_range_deg": [float(x[used][0]), float(x[used][-1])],
    },
}

with (ROOT / "result.json").open("w") as stream:
    json.dump(result, stream, indent=2, sort_keys=False)
    stream.write("\n")

print(json.dumps({
    "fit_statistics": result["fit_statistics"],
    "fractions": {item["name"]: item["weight_fraction"] for item in phase_results},
    "fraction_sum": math.fsum(item["weight_fraction"] for item in phase_results),
    "frozen": project.get_Frozen(),
    "outputs": ["final.gpx", "fit.csv", "result.json"]
               + [item["cif_path"] for item in phase_results],
}, indent=2, sort_keys=True))
