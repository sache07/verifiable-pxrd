#!/usr/bin/env python3
"""Test low-dimensional uniaxial WO3 microstrain directions."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "profile_wo3_iso_strain.gpx"


def run(axis):
    label = "".join(str(v).replace("-", "m") for v in axis)
    out = ROOT / f"anisotropy_wo3_{label}.gpx"
    gpx = G2sc.G2Project(str(BASE))
    gpx.save(str(out))
    gpx = G2sc.G2Project(str(out))
    hist = gpx.histogram(0)
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        hist.InstrumentParameters[key][2] = False
    phase = gpx.phase(2)
    hap = phase.getHAPvalues(hist.name)
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = 1313.0
    hap["Mustrain"][1][1] = 1313.0
    hap["Mustrain"][1][2] = 1.0
    hap["Mustrain"][2] = [True, True, False]
    hap["Mustrain"][3] = list(axis)
    gpx.set_Frozen()
    for suffix in ("i", "a"):
        var = f"2:0:Mustrain;{suffix}"
        gpx.set_Controls("parmMin", 0.0, variable=var)
        gpx.set_Controls("parmMax", 20000.0, variable=var)
    gpx.set_Controls("cycles", 10)
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    gpx = G2sc.G2Project(str(out))
    gpx.set_Controls("cycles", 5)
    gpx.refine(makeBack=False)
    gpx.save()
    hist = gpx.histogram(0)
    print("ANISO_RESULT " + json.dumps({
        "axis": axis,
        "rwp": hist.residuals.get("wR"),
        "rp": hist.residuals.get("R"),
        "rf2": hist.residuals.get("2:0:Rf^2"),
        "mustrain": gpx.phase(2).getHAPvalues(hist.name)["Mustrain"],
        "frozen": gpx.get_Frozen(),
        "path": str(out),
    }, default=float))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("h", type=int)
    parser.add_argument("k", type=int)
    parser.add_argument("l", type=int)
    args = parser.parse_args()
    run([args.h, args.k, args.l])
