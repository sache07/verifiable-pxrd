#!/usr/bin/env python3
"""Export the submitted profiles, structures, and machine-readable summary."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"


def main() -> None:
    gpx = G2sc.G2Project(gpxfile=str(PROJECT))
    hist = gpx.histograms()[0]
    phases = gpx.phases()

    exports = {
        "WO3_cod_2106293": {
            "name": "tungsten trioxide",
            "formula": "WO3",
            "cif": "WO3_triclinic.cif",
            "source": "COD 2106293",
        },
        "BaO2_cod_1010113": {
            "name": "barium peroxide",
            "formula": "BaO2",
            "cif": "BaO2_tetragonal.cif",
            "source": "COD 1010113",
        },
    }

    fractions = hist.ComputeMassFracs()
    phase_results = []
    for phase in phases:
        info = exports[phase.name]
        phase.export_CIF(str(ROOT / info["cif"]))
        value, esd = fractions[phase.name]
        phase_results.append(
            {
                "name": info["name"],
                "formula": info["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "source_structure": info["source"],
                "cif_path": info["cif"],
                "weight_fraction": float(value),
                "weight_fraction_esd": float(esd),
                "weight_percent": float(100.0 * value),
                "cell": {key: float(val) for key, val in phase.get_cell().items()},
            }
        )

    profile = np.asarray(hist.data["data"][1], dtype=float)
    with (ROOT / "fit.csv").open("w", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "background_counts",
                "difference_counts",
                "statistical_weight",
            ]
        )
        for x, obs, weight, calc, background, difference in profile.T:
            writer.writerow(
                [
                    f"{x:.8f}",
                    f"{obs:.8f}",
                    f"{calc:.8f}",
                    f"{background:.8f}",
                    f"{difference:.8f}",
                    f"{weight:.12g}",
                ]
            )

    residuals = hist.residuals
    rvals = gpx.data["Covariance"]["data"]["Rvals"]
    result = {
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over the two modeled crystalline phases",
        "phases": phase_results,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_variables": int(rvals["Nvars"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
            "svd_zero_count": int(rvals["SVD0"]),
            "converged": bool(rvals["converged"]),
        },
    }
    with (ROOT / "result.json").open("w") as fp:
        json.dump(result, fp, indent=2)
        fp.write("\n")


if __name__ == "__main__":
    main()
