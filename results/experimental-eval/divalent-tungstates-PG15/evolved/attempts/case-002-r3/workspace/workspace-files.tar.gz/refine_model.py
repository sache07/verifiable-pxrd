#!/usr/bin/env python3
"""Build and stage a GSAS-II refinement for the Ba-O-W powder pattern."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def refine(gpx: G2sc.G2Project, label: str) -> None:
    print(f"\n===== refinement: {label} =====")
    gpx.refine()
    gpx.reload()
    hist = gpx.histograms()[0]
    print("residuals", json.dumps(hist.residuals, sort_keys=True, default=float))
    print("mass fractions", hist.ComputeMassFracs())
    print("instrument", hist.InstrumentParameters)
    for phase in gpx.phases():
        print(phase.name, "cell", phase.get_cell())
        print(phase.name, "HAP", phase.getHAPvalues(hist.name))


def neutralize_phase_profile(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData) -> None:
    phase.setSampleProfile(hist, "size", "isotropic", 1.0e6, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    phase.clear_HAP_refinements(
        {
            "Size": True,
            "Mustrain": True,
            "HStrain": True,
            "Pref.Ori.": True,
            "Extinction": True,
            "Babinet": ["BabA", "BabU"],
        },
        [hist],
    )
    hap = phase.getHAPvalues(hist.name)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"][0] = 0.0
    hap["Extinction"][1] = False
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def build_project(output: Path, wo3_id: str, bao2_id: str, bkg_terms: int) -> G2sc.G2Project:
    gpx = G2sc.G2Project(newgpx=str(output))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.Limits("lower", 9.91)
    hist.Limits("upper", 100.08)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": bkg_terms,
                "coeffs": [600.0] + [0.0] * (bkg_terms - 1),
            }
        }
    )
    # Reflection geometry: keep transparency/roughness/displacement neutral.
    for key in ("DisplaceX", "DisplaceY", "Absorption", "SurfRoughA", "SurfRoughB"):
        if key in hist.SampleParameters:
            hist.SampleParameters[key][0] = 0.0
            hist.SampleParameters[key][1] = False

    phases = [
        gpx.add_phase(str(cod_path(wo3_id)), phasename=f"WO3_cod_{wo3_id}", histograms=[hist]),
        gpx.add_phase(str(cod_path(bao2_id)), phasename=f"BaO2_cod_{bao2_id}", histograms=[hist]),
    ]
    for phase in phases:
        neutralize_phase_profile(phase, hist)
        phase.set_HAP_refinements({"Scale": True}, [hist])

    gpx.set_Controls("cycles", 12)
    gpx.save()
    return gpx


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / "scratch.gpx")
    parser.add_argument("--wo3", default="1528915")
    parser.add_argument("--bao2", default="1010113")
    parser.add_argument("--background", type=int, default=8)
    parser.add_argument("--common-profile", choices=("fit", "fixed"), default="fit")
    parser.add_argument("--through", choices=("scales", "cells", "profile", "size", "strain"), default="strain")
    args = parser.parse_args()

    gpx = build_project(args.output, args.wo3, args.bao2, args.background)
    hist = gpx.histograms()[0]
    refine(gpx, "background + scales")
    if args.through == "scales":
        return

    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(gpx, "cells + zero + background + scales")
    if args.through == "cells":
        return

    # Common low-dimensional, nonnegative starting profile. V and Y remain fixed at zero.
    inst = hist.InstrumentParameters
    inst["U"][1] = max(2.0, float(inst["U"][1]))
    inst["W"][1] = max(5.0, float(inst["W"][1]))
    inst["X"][1] = max(0.01, float(inst["X"][1]))
    if args.common_profile == "fit":
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
        refine(gpx, "common U/W/X profile")
    else:
        hist.clear_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
        gpx.save()
    if args.through == "profile":
        return

    for phase in gpx.phases():
        phase.setSampleProfile(hist, "size", "isotropic", 0.05, LGmix=1.0)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True, "LGmix": {"value": 1.0, "refine": False}}},
            [hist],
        )
    refine(gpx, "isotropic size by phase")
    if args.through == "size":
        return

    for phase in gpx.phases():
        phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=1.0)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True, "LGmix": {"value": 1.0, "refine": False}}},
            [hist],
        )
    refine(gpx, "isotropic size + microstrain by phase")


if __name__ == "__main__":
    main()
