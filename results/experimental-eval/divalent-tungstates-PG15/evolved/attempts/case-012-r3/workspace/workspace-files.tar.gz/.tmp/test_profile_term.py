import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("phase", type=int)
parser.add_argument("term", choices=("size", "strain"))
parser.add_argument("output")
args = parser.parse_args()

root = Path(__file__).resolve().parents[1]
out = root / args.output
G2sc.SetPrintLevel("warn")
g = G2sc.G2Project(str(root / ".tmp/trial_pol.gpx"), newgpx=str(out))
h = g.histogram(0)
g.set_Frozen()
h.InstrumentParameters["U"][2] = False
for p in g.phases():
    hap = p.getHAPvalues(h.name)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [1.0, 1.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]

p = g.phase(args.phase)
if args.term == "size":
    p.set_HAP_refinements({"Size": {"type": "isotropic", "value": 10.0, "refine": True}})
    variable = f"{args.phase}:0:Size;i"
    g.set_Controls("parmMin", 0.01, variable=variable)
    g.set_Controls("parmMax", 10.0, variable=variable)
else:
    p.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    variable = f"{args.phase}:0:Mustrain;i"
    g.set_Controls("parmMin", 0.0, variable=variable)
    g.set_Controls("parmMax", 10000.0, variable=variable)

g.set_Controls("cycles", 30)
g.save()
for _ in range(2):
    g.refine(makeBack=False)
g.save()
g = G2sc.G2Project(str(out))
g.refine(makeBack=False)
h = g.histogram(0)
print("RWP", h.residuals["wR"], "RP", h.residuals["R"], "MASS", h.ComputeMassFracs())
print("FROZEN", g.get_Frozen())
for q in g.phases():
    hap = q.getHAPvalues(h.name)
    print(q.name, "size", hap["Size"], "strain", hap["Mustrain"])
g.save()
