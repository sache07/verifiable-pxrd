from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
GPX = ROOT / ".tmp" / "trial2.gpx"
HIST_NAME = "PWDR pattern.xye"


def show(gpx, tag):
    h = gpx.histogram(0)
    print(f"\n--- {tag} ---")
    print("residuals", h.residuals)
    print(
        "instrument",
        {k: tuple(v[1:]) for k, v in h.InstrumentParameters.items()
         if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.", "I(L2)/I(L1)")},
    )
    print(
        "sample",
        {k: v for k, v in h.SampleParameters.items()
         if k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
    )
    print("background", h.Background[0])
    for p in gpx.phases():
        hap = p.getHAPvalues(h.name)
        print(p.name, "cell", p.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"], "mustrain", hap["Mustrain"],
              "PO", hap["Pref.Ori."][:4])
    try:
        print("mass fractions", h.ComputeMassFracs())
    except Exception as exc:
        print("mass fraction error", repr(exc))


def reopen(gpx):
    gpx.save()
    return G2sc.G2Project(str(GPX))


G2sc.SetPrintLevel("warn")
g = G2sc.G2Project(newgpx=str(GPX))
h = g.add_powder_histogram(
    str(ROOT / ".tmp" / "pattern.xye"),
    str(ROOT / ".tmp" / "cu_ka.instprm"),
    fmthint="xye",
)
for cif, name in [
    ("candidates/NiWO4_prototype.cif", "NiWO4"),
    ("candidates/WO3_2311041.cif", "WO3"),
]:
    g.add_phase(str(ROOT / cif), phasename=name, histograms=[h], fmthint="CIF")

g.set_Controls("cycles", 12)
h.SampleParameters["Scale"][:] = [1.0, False]
h.SampleParameters["Shift"][:] = [0.0, False]
h.SampleParameters["Transparency"][:] = [0.0, False]
h.SampleParameters["SurfRoughA"][:] = [0.0, False]
h.SampleParameters["SurfRoughB"][:] = [0.0, False]

inst = h.InstrumentParameters
for key, value in {
    "Zero": 0.0,
    "U": 2.0,
    "V": 0.0,
    "W": 5.0,
    "X": 0.0,
    "Y": 0.0,
    "Z": 0.0,
    "SH/L": 0.002,
    "Polariz.": 0.5,
    "I(L2)/I(L1)": 0.5,
}.items():
    inst[key][1] = value
    inst[key][2] = False

h.set_refinements({
    "Background": {
        "type": "chebyschev-1",
        "refine": True,
        "no. coeffs": 8,
    }
})

for p in g.phases():
    hap = p.getHAPvalues(h.name)
    hap["Scale"][:] = [1.0, True]
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1000.0, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [1.0, 1.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["HStrain"][0][:] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1][:] = [False for _ in hap["HStrain"][1]]
    hap["Extinction"][:] = [0.0, False]
    p.set_refinements({"Cell": False, "Atoms": {"all": " "}})

g.save()
show(g, "initial")
g.refine(makeBack=False)
show(g, "background and scales")

h = g.histogram(0)
h.InstrumentParameters["Zero"][2] = True
for p in g.phases():
    p.set_refinements({"Cell": True})
g.refine(makeBack=False)
show(g, "zero and cells")

g = reopen(g)
h = g.histogram(0)
h.InstrumentParameters["W"][2] = True
g.set_Controls("parmMin", 0.0, variable=":0:W")
g.refine(makeBack=False)
show(g, "W")

g.set_Frozen()
h.InstrumentParameters["U"][2] = True
g.set_Controls("parmMin", 0.0, variable=":0:U")
g.refine(makeBack=False)
show(g, "U W")

g.set_Frozen()
h.InstrumentParameters["X"][2] = True
g.set_Controls("parmMin", 0.0, variable=":0:X")
g.refine(makeBack=False)
show(g, "U W X")

g = reopen(g)
g.refine(makeBack=False)
show(g, "reopen replay")
g.save()
