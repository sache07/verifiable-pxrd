import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("phase", type=int)
parser.add_argument("h", type=int)
parser.add_argument("k", type=int)
parser.add_argument("l", type=int)
parser.add_argument("output")
args = parser.parse_args()

root = Path(__file__).resolve().parents[1]
out = root / args.output
G2sc.SetPrintLevel("warn")
g = G2sc.G2Project(str(root / ".tmp/profile_wo_strain.gpx"), newgpx=str(out))
h = g.histogram(0)
g.set_Frozen()
h.InstrumentParameters["U"][2] = False
h.InstrumentParameters["SH/L"][1:] = [0.002, False]
for p in g.phases():
    po = p.getHAPvalues(h.name)["Pref.Ori."]
    po[0:4] = ["MD", 1.0, False, [0, 0, 1]]
p = g.phase(args.phase)
po = p.getHAPvalues(h.name)["Pref.Ori."]
po[0:4] = ["MD", 1.0, True, [args.h, args.k, args.l]]
var = f"{args.phase}:0:MD"
g.set_Controls("parmMin", 0.2, variable=var)
g.set_Controls("parmMax", 5.0, variable=var)
g.set_Controls("cycles", 30)
g.save()
for _ in range(2):
    g.refine(makeBack=False)
g.save()
g = G2sc.G2Project(str(out))
g.refine(makeBack=False)
h = g.histogram(0)
print("RWP", h.residuals["wR"], "RP", h.residuals["R"], "MASS", h.ComputeMassFracs())
print("PO", g.phase(args.phase).getHAPvalues(h.name)["Pref.Ori."][:4], "FROZEN", g.get_Frozen())
print("RESIDUALS", h.residuals)
g.save()
