import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp" / "test_u_final.gpx"
FINAL = ROOT / "final.gpx"

G2sc.SetPrintLevel("warn")
g = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
h = g.histogram(0)
g.set_Frozen()
g.set_Controls("cycles", 40)

# Full submitted range; no exclusions.
h.Limits("lower", float(h.data["data"][1][0][0]))
h.Limits("upper", float(h.data["data"][1][0][-1]))
h.Excluded([])

# One angular correction, no sample-scale redundancy, and neutral unused
# reflection-geometry terms.
h.SampleParameters["Scale"][1] = False
for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
    h.SampleParameters[key][:] = [0.0, False]

# Retained common instrument/profile model. All other terms are pruned.
for key in h.InstrumentParameters:
    if len(h.InstrumentParameters[key]) > 2:
        h.InstrumentParameters[key][2] = key in ("Zero", "Polariz.", "U", "W", "X")
for key in ("V", "Y", "Z"):
    h.InstrumentParameters[key][1] = 0.0
h.InstrumentParameters["SH/L"][1:] = [0.002, False]
h.InstrumentParameters["I(L2)/I(L1)"][1:] = [0.5, False]
h.Background[0][0:3] = ["chebyschev-1", True, 8]

for p in g.phases():
    hap = p.getHAPvalues(h.name)
    hap["Scale"][1] = True
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["HStrain"][0][:] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1][:] = [False for _ in hap["HStrain"][1]]
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]
    p.set_refinements({"Cell": True})

niwo4 = g.phase("NiWO4")
ni_hap = niwo4.getHAPvalues(h.name)
ni_hap["Mustrain"][0] = "isotropic"
ni_hap["Mustrain"][1][:] = [1.0, 1.0, 1.0]
ni_hap["Mustrain"][2][:] = [False, False, False]
niwo4.set_refinements({"Atoms": {"all": "X"}})

wo3 = g.phase("WO3")
wo_hap = wo3.getHAPvalues(h.name)
wo_hap["Mustrain"][0] = "isotropic"
wo_hap["Mustrain"][2][:] = [True, False, False]
wo3.set_refinements({"Atoms": {"all": " "}})

# Preserve nonnegative bounds for retained width/strain terms and physical
# bounds for the refined polarization.
for variable in (":0:U", ":0:W", ":0:X", "1:0:Mustrain;i"):
    g.set_Controls("parmMin", 0.0, variable=variable)
g.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
g.set_Controls("parmMin", 0.0, variable=":0:Polariz.")

g.save()
for _ in range(3):
    g.refine(makeBack=False)
g.save()

# Reopen and replay once over the full range, then save the exact export state.
g = G2sc.G2Project(str(FINAL))
g.set_Controls("cycles", 40)
g.refine(makeBack=False)
g.save()
h = g.histogram(0)

niwo4 = g.phase("NiWO4")
wo3 = g.phase("WO3")
niwo4.export_CIF(str(ROOT / "phase_1_NiWO4.cif"))
wo3.export_CIF(str(ROOT / "phase_2_WO3.cif"))

x, yobs, weights, ycalc, background, difference = h.data["data"][1]
with (ROOT / "fit.csv").open("w", newline="") as fp:
    writer = csv.writer(fp)
    writer.writerow([
        "two_theta_deg",
        "observed_intensity",
        "calculated_intensity",
        "difference_intensity",
        "background_intensity",
    ])
    writer.writerows(zip(x, yobs, ycalc, difference, background))

mass_fracs = h.ComputeMassFracs()
residuals = h.residuals
rvals = g.data["Covariance"]["data"]["Rvals"]
phase_meta = {
    "NiWO4": {
        "name": "nickel tungstate",
        "formula": "NiWO4",
        "space_group": "P 1 2/c 1",
        "cif_path": "phase_1_NiWO4.cif",
    },
    "WO3": {
        "name": "tungsten trioxide (monoclinic gamma-WO3)",
        "formula": "WO3",
        "space_group": "P 1 21/c 1",
        "cif_path": "phase_2_WO3.cif",
    },
}
phases = []
for p in g.phases():
    frac, sigma = mass_fracs[p.name]
    cell, cell_sigma = p.get_cell_and_esd()
    item = dict(phase_meta[p.name])
    item.update({
        "weight_fraction": frac,
        "weight_fraction_esd": sigma,
        "weight_percent": 100.0 * frac,
        "weight_percent_esd": 100.0 * sigma,
        "cell": cell,
        "cell_esd": cell_sigma,
    })
    phases.append(item)

result = {
    "normalization": "modeled crystalline phases sum to 1.0",
    "phases": phases,
    "fit_statistics": {
        "Rwp_percent": residuals["wR"],
        "Rp_percent": residuals["R"],
        "Rexp_percent": residuals["wRmin"],
        "background_Rwp_percent": residuals["wRb"],
        "goodness_of_fit": rvals["GOF"],
        "reduced_chi_square": rvals["GOF"] ** 2,
        "chi_square": rvals["chisq"],
        "n_observations": rvals["Nobs"],
        "n_refined_parameters": rvals["Nvars"],
        "max_shift_over_esd": rvals["Max shft/sig"],
        "two_theta_range_deg": [float(x[0]), float(x[-1])],
    },
    "project_path": "final.gpx",
    "profile_path": "fit.csv",
}
with (ROOT / "result.json").open("w") as fp:
    json.dump(result, fp, indent=2)
    fp.write("\n")

print(json.dumps(result, indent=2))
