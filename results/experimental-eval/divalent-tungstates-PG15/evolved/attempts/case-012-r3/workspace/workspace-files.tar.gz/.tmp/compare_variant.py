import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("nickel_tungstate_cif")
parser.add_argument("tungsten_oxide_cif")
parser.add_argument("output_gpx")
args = parser.parse_args()

root = Path(__file__).resolve().parents[1]
out = root / args.output_gpx
G2sc.SetPrintLevel("warn")
g = G2sc.G2Project(newgpx=str(out))
h = g.add_powder_histogram(
    str(root / ".tmp/pattern.xye"), str(root / ".tmp/cu_ka.instprm"), fmthint="xye"
)
g.add_phase(str(root / args.nickel_tungstate_cif), phasename="NiWO4", histograms=[h], fmthint="CIF")
g.add_phase(str(root / args.tungsten_oxide_cif), phasename="WO3", histograms=[h], fmthint="CIF")

g.set_Controls("cycles", 20)
h.SampleParameters["Scale"][:] = [1.0, False]
for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
    h.SampleParameters[key][:] = [0.0, False]
for key, val in {"Zero": 0.0, "U": 0.0, "V": 0.0, "W": 5.0, "X": 0.0,
                 "Y": 0.0, "Z": 0.0, "SH/L": 0.002, "Polariz.": 0.5}.items():
    h.InstrumentParameters[key][1] = val
    h.InstrumentParameters[key][2] = False
h.set_refinements({"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 8}})
for p in g.phases():
    hap = p.getHAPvalues(h.name)
    hap["Scale"][:] = [1.0, True]
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [1.0, 1.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["HStrain"][0][:] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1][:] = [False for _ in hap["HStrain"][1]]
    hap["Extinction"][:] = [0.0, False]
    p.set_refinements({"Cell": False, "Atoms": {"all": " "}})

g.save()
g.refine(makeBack=False)
h.InstrumentParameters["Zero"][2] = True
for p in g.phases():
    p.set_refinements({"Cell": True})
g.refine(makeBack=False)
h.InstrumentParameters["W"][2] = True
g.set_Controls("parmMin", 0.0, variable=":0:W")
g.refine(makeBack=False)
h.InstrumentParameters["X"][2] = True
g.set_Controls("parmMin", 0.0, variable=":0:X")
g.refine(makeBack=False)
h.InstrumentParameters["Polariz."][2] = True
g.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
g.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
for _ in range(3):
    g.refine(makeBack=False)
g.save()
print("RWP", h.residuals["wR"], "RP", h.residuals["R"], "MASS", h.ComputeMassFracs())
print("INST", {k: v[1] for k, v in h.InstrumentParameters.items()
               if k in ("Zero", "U", "V", "W", "X", "Polariz.")})
for p in g.phases():
    print(p.name, p.get_cell(), p.getHAPvalues(h.name)["Scale"])
