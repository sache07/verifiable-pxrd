#!/usr/bin/env python3
"""One-at-a-time profile, geometry and phase-width trials."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "trials" / "base3_rebuilt.gpx"


def apply_trial(project, label):
    hist = project.histogram(0)
    if label == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif label == "shl":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        project.set_Controls("parmMin", 0.0005, variable=":0:SH/L")
        project.set_Controls("parmMax", 0.2, variable=":0:SH/L")
    elif label == "roughness":
        hist.SampleParameters["SurfRoughA"] = [0.5, True]
        hist.SampleParameters["SurfRoughB"] = [0.01, True]
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughB")
    elif label.startswith("size_"):
        phase = project.phase(label[5:])
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 1.0, "refine": True}},
            histograms=[hist],
        )
    elif label.startswith("strain_"):
        phase = project.phase(label[7:])
        hap = phase.getHAPvalues(hist)
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 100.0
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}},
            histograms=[hist],
        )
    else:
        raise ValueError(label)


def summarize(project):
    hist = project.histogram(0)
    return {
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "wRb": hist.residuals.get("wRb"),
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample": {
            key: value[0]
            for key, value in hist.SampleParameters.items()
            if key in ("SurfRoughA", "SurfRoughB")
        },
        "phase_widths": {
            phase.name: {
                "size": phase.getHAPvalues(hist)["Size"],
                "mustrain": phase.getHAPvalues(hist)["Mustrain"],
            }
            for phase in project.phases()
        },
        "vary": project.get_VaryList(),
    }


def run(label):
    out = ROOT / "trials" / f"{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    project.set_Controls("cycles", 20)
    apply_trial(project, label)
    project.save()
    project.refine()
    project.save()
    # Required replay from the saved project.
    project = G2sc.G2Project(str(out))
    project.set_Controls("cycles", 20)
    project.refine()
    project.save()
    return summarize(project)


def main():
    labels = [
        "polarization",
        "shl",
        "roughness",
        "size_BaCO3_modern",
        "size_WO3_P-1",
        "size_BaWO4_ordered",
        "strain_BaCO3_modern",
        "strain_WO3_P-1",
        "strain_BaWO4_ordered",
    ]
    summary = {}
    for label in labels:
        print(f"\n=== {label} ===", flush=True)
        try:
            summary[label] = run(label)
            print(json.dumps(summary[label], indent=2), flush=True)
        except Exception as exc:
            summary[label] = {"error": repr(exc)}
            print(summary[label], flush=True)
    with (ROOT / "trials" / "nuisance_summary.json").open("w") as handle:
        json.dump(summary, handle, indent=2)


if __name__ == "__main__":
    main()
