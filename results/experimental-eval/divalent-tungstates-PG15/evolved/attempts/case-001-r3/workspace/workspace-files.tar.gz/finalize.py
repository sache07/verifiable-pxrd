#!/usr/bin/env python3
"""Replay the accepted model and export all submission artifacts from it."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials" / "texture_baco3_110.gpx"
FINAL = ROOT / "final.gpx"

PHASES = (
    {
        "project_name": "BaCO3_modern",
        "name": "barium carbonate (witherite)",
        "formula": "BaCO3",
        "space_group": "Pmcn (No. 62)",
        "cif": "BaCO3.cif",
        "structure_source": "COD 9010928",
    },
    {
        "project_name": "WO3_P-1",
        "name": "tungsten trioxide, triclinic",
        "formula": "WO3",
        "space_group": "P-1 (No. 2)",
        "cif": "WO3.cif",
        "structure_source": "COD 2106293",
    },
    {
        "project_name": "BaWO4_ordered",
        "name": "barium tungstate (scheelite)",
        "formula": "BaWO4",
        "space_group": "I41/a (No. 88, setting 2)",
        "cif": "BaWO4.cif",
        "structure_source": "ordered physical representation derived from COD 1527204",
    },
)


def replay() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 20)
    project.save()
    project.refine()
    project.save()

    # Required save/reopen/full-range replay of the submitted project.
    project = G2sc.G2Project(str(FINAL))
    project.set_Controls("cycles", 20)
    project.refine()
    project.save()


def export() -> dict:
    project = G2sc.G2Project(str(FINAL))
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()

    phase_results = []
    for index, spec in enumerate(PHASES):
        phase = project.phase(spec["project_name"])
        phase.export_CIF(str(ROOT / spec["cif"]))
        fraction, fraction_esd = fractions[spec["project_name"]]
        residuals = hist.residuals
        phase_results.append(
            {
                "name": spec["name"],
                "formula": spec["formula"],
                "space_group": spec["space_group"],
                "cif_path": spec["cif"],
                "structure_source": spec["structure_source"],
                "weight_fraction": float(fraction),
                "weight_fraction_standard_uncertainty": float(fraction_esd),
                "weight_percent": 100.0 * float(fraction),
                "weight_percent_standard_uncertainty": 100.0 * float(fraction_esd),
                "cell": {key: float(value) for key, value in phase.get_cell().items()},
                "phase_fit_statistics": {
                    "n_reflections": int(residuals[f"{index}:0:Nref"]),
                    "R_F_percent": float(residuals[f"{index}:0:Rf"]),
                    "R_F_squared_percent": float(residuals[f"{index}:0:Rf^2"]),
                },
            }
        )

    profile = np.asarray(hist.data["data"][1], dtype=float)
    two_theta, observed, weights, calculated, background = profile[:5]
    low, high = hist.data["Limits"][1]
    # Use GSAS-II's exact profile slicing convention. The upper search point
    # is included, even when the sampled value lies just above the nominal
    # limit (100.00795 degrees here).
    first = int(np.searchsorted(two_theta, low))
    last = int(np.searchsorted(two_theta, high)) + 1
    selected = slice(first, last)
    x = two_theta[selected]
    yobs = observed[selected]
    weight = weights[selected]
    ycalc = calculated[selected]
    ybkg = background[selected]
    difference = yobs - ycalc

    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            (
                "two_theta_deg",
                "observed_intensity_counts",
                "calculated_intensity_counts",
                "difference_observed_minus_calculated_counts",
                "background_intensity_counts",
            )
        )
        writer.writerows(zip(x, yobs, ycalc, difference, ybkg))

    covariance = project.data["Covariance"]["data"]
    n_variables = len(covariance.get("varyList", []))
    n_observations = last - first
    chi_square = float(np.sum(weight * difference**2))
    degrees_of_freedom = n_observations - n_variables
    reduced_chi_square = chi_square / degrees_of_freedom
    residuals = hist.residuals
    r_exp = float(residuals["wRmin"])
    r_wp = float(residuals["wR"])

    result = {
        "weight_fraction_basis": "normalized over the modeled crystalline phases; sums to 1",
        "phases": phase_results,
        "fit_statistics": {
            "profile_range_two_theta_deg": [float(low), float(high)],
            "n_observations": n_observations,
            "n_refined_variables": n_variables,
            "degrees_of_freedom": degrees_of_freedom,
            "chi_square": chi_square,
            "reduced_chi_square": reduced_chi_square,
            "goodness_of_fit_sqrt_reduced_chi_square": math.sqrt(reduced_chi_square),
            "R_wp_percent": r_wp,
            "R_p_percent": float(residuals["R"]),
            "R_wp_background_percent": float(residuals["wRb"]),
            "R_p_background_percent": float(residuals["Rb"]),
            "R_exp_percent": r_exp,
            "R_wp_over_R_exp": r_wp / r_exp,
            "weighting": "Poisson proxy w = 1 / observed counts; pointwise uncertainties were not supplied",
        },
        "measurement": {
            "geometry": "reflection, Bragg-Brentano profile model",
            "radiation": "Cu K-alpha doublet",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
        },
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
    }
    with (ROOT / "result.json").open("w") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")
    return result


def validate(result: dict) -> None:
    project = G2sc.G2Project(str(FINAL))
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    submitted = {phase["formula"]: phase["weight_fraction"] for phase in result["phases"]}
    expected = {
        spec["formula"]: float(fractions[spec["project_name"]][0])
        for spec in PHASES
    }
    if submitted != expected:
        raise RuntimeError("Exported fractions do not match final.gpx")
    if abs(sum(submitted.values()) - 1.0) > 1e-12:
        raise RuntimeError("Submitted crystalline fractions are not normalized")
    with (ROOT / "fit.csv").open() as handle:
        if sum(1 for _ in handle) - 1 != result["fit_statistics"]["n_observations"]:
            raise RuntimeError("fit.csv row count does not match final.gpx")
    for spec in PHASES:
        if not (ROOT / spec["cif"]).is_file():
            raise RuntimeError(f"Missing CIF export: {spec['cif']}")


def main():
    replay()
    result = export()
    validate(result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
