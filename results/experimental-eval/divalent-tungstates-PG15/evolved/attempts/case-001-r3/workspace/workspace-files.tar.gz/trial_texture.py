#!/usr/bin/env python3
"""Replay-stable March-Dollase orientation challenges for the major phases."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "trials" / "pol_clean.gpx"
AXES = ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0),
        (1, 0, 1), (0, 1, 1), (1, 1, 1))


def run(phase_name: str, axis: tuple[int, int, int]):
    tag = "".join(str(i) for i in axis)
    short_phase = "baco3" if phase_name.startswith("BaCO3") else "wo3"
    out = ROOT / "trials" / f"texture_{short_phase}_{tag}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 20)
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    pref = phase.getHAPvalues(hist)["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = list(axis)
    project.save()
    project.refine()
    project.save()

    project = G2sc.G2Project(str(out))
    project.set_Controls("cycles", 20)
    project.refine()
    project.save()
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    return {
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "mass_fractions": hist.ComputeMassFracs(),
        "pref_ori": phase.getHAPvalues(hist)["Pref.Ori."],
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "nvar": len(project.get_VaryList()),
    }


def main():
    summary = {}
    for phase in ("BaCO3_modern", "WO3_P-1"):
        for axis in AXES:
            key = f"{phase}:{axis}"
            print(f"\n=== {key} ===", flush=True)
            try:
                summary[key] = run(phase, axis)
                print(json.dumps(summary[key], indent=2), flush=True)
            except Exception as exc:
                summary[key] = {"error": repr(exc)}
                print(summary[key], flush=True)
    with (ROOT / "trials" / "texture_summary.json").open("w") as handle:
        json.dump(summary, handle, indent=2)


if __name__ == "__main__":
    main()
