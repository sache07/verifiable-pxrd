#!/usr/bin/env python3
"""Screen chemically plausible phase records with a matched GSAS-II model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod(cod_id: str) -> str:
    return str(COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif")


PHASES = {
    "BaCO3_modern": cod("9010928"),
    "BaCO3_old": cod("1011149"),
    "WO3_P21c_1960": cod("1528915"),
    "WO3_P21c_2023": cod("2311041"),
    "WO3_P21c_small": cod("1563541"),
    "WO3_P-1": cod("2106293"),
    "WO3_Pnma": cod("2107312"),
    "WO3_P21m_old": cod("1010618"),
    "BaWO4_proto": str(ROOT / "bawo4_proto.cif"),
    "BaWO4_ordered": str(ROOT / "bawo4_ordered.cif"),
    "BaWO4_split": cod("1527204"),
}


MODELS = {
    "baco3_wo3_1960": ["BaCO3_modern", "WO3_P21c_1960"],
    "baco3_wo3_2023": ["BaCO3_modern", "WO3_P21c_2023"],
    "baco3_wo3_small": ["BaCO3_modern", "WO3_P21c_small"],
    "baco3_wo3_triclinic": ["BaCO3_modern", "WO3_P-1"],
    "baco3_wo3_pnma": ["BaCO3_modern", "WO3_Pnma"],
    "baco3_wo3_old": ["BaCO3_modern", "WO3_P21m_old"],
    "baco3old_wo3_1960": ["BaCO3_old", "WO3_P21c_1960"],
    "three_phase": ["BaCO3_modern", "WO3_P21c_1960", "BaWO4_proto"],
    "three_phase_split": ["BaCO3_modern", "WO3_P21c_1960", "BaWO4_split"],
}


def configure_project(label: str, phase_names: list[str]):
    out = ROOT / "screen" / f"{label}.gpx"
    out.parent.mkdir(exist_ok=True)
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "CuKa.instprm"), fmthint="Topas"
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Absorption"] = [0.0, False]
    hist.SampleParameters["DisplaceX"] = [0.0, False]
    hist.SampleParameters["DisplaceY"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    # Six-term smooth baseline estimated from the low-percentile envelope.
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [678.26, -585.35, 352.44, -196.86, 89.62, -32.20],
                "refine": True,
            }
        }
    )

    inst = hist.InstrumentParameters
    for key, value in {
        "Zero": 0.28,
        "U": 20.0,
        "V": 0.0,
        "W": 10.0,
        "X": 5.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }.items():
        inst[key][0] = inst[key][1] = value
        inst[key][2] = False

    phases = []
    for name in phase_names:
        phase = project.add_phase(
            PHASES[name], phasename=name, histograms=[hist], fmthint="CIF"
        )
        hap = phase.getHAPvalues(hist)
        hap["Scale"] = [0.1, True]
        # Explicitly neutralize phase-specific nuisance terms.
        phase.clear_HAP_refinements(
            {
                "Size": True,
                "Mustrain": True,
                "HStrain": True,
                "Pref.Ori.": True,
                "Extinction": True,
                "Babinet": ["BabA", "BabU"],
            }
        )
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0e6
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        phases.append(phase)

    project.set_Controls("cycles", 12)
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMin", 0.0, variable=":0:W")
    project.set_Controls("parmMin", 0.0, variable=":0:X")
    project.save()
    return project, hist, phases


def snapshot(project, hist, phases, stage):
    result = {
        "stage": stage,
        "residuals": hist.residuals,
        "profile": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "background": hist.Background[0][3:],
        "phases": {},
    }
    try:
        mass_fracs = hist.ComputeMassFracs()
    except Exception as exc:
        mass_fracs = {"error": repr(exc)}
    result["mass_fractions"] = mass_fracs
    for phase in phases:
        result["phases"][phase.name] = {
            "scale": phase.getHAPvalues(hist)["Scale"][0],
            "cell": phase.get_cell(),
        }
    return result


def run_model(label: str, names: list[str]):
    project, hist, phases = configure_project(label, names)
    history = []

    # Same restrained nuisance model for every inventory trial.
    project.refine()
    history.append(snapshot(project, hist, phases, "background_scales"))

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.refine()
    history.append(snapshot(project, hist, phases, "zero_cells"))

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.refine()
    history.append(snapshot(project, hist, phases, "common_profile"))

    # One replay after saving/reopening.
    project.save()
    replay = G2sc.G2Project(str(project.filename))
    replay.set_Controls("cycles", 12)
    replay.refine()
    rh = replay.histogram(0)
    rph = replay.phases()
    history.append(snapshot(replay, rh, rph, "reopened_replay"))
    replay.save()
    return history


def main():
    summary = {}
    for label, names in MODELS.items():
        print(f"\n=== {label}: {', '.join(names)} ===", flush=True)
        try:
            summary[label] = run_model(label, names)
            last = summary[label][-1]
            print(
                json.dumps(
                    {
                        "residuals": last["residuals"],
                        "mass_fractions": last["mass_fractions"],
                        "profile": last["profile"],
                    },
                    indent=2,
                ),
                flush=True,
            )
        except Exception as exc:
            summary[label] = {"error": repr(exc)}
            print(f"ERROR: {exc!r}", flush=True)
    with (ROOT / "screen" / "summary.json").open("w") as handle:
        json.dump(summary, handle, indent=2)


if __name__ == "__main__":
    main()
