#!/usr/bin/env python3
"""Replay-stable structural and WO3 line-broadening trials."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "trials" / "pol_clean.gpx"


def configure(project, label):
    hist = project.histogram(0)
    if label == "baco3_ba_xyz":
        project.phase("BaCO3_modern").set_refinements(
            {"Atoms": {"Ba": "X"}}
        )
    elif label == "baco3_all_xyz":
        project.phase("BaCO3_modern").set_refinements(
            {"Atoms": {"all": "X"}}
        )
    elif label == "wo3_w_xyz":
        project.phase("WO3_P-1").set_refinements(
            {"Atoms": {name: "X" for name in ("W1", "W2", "W3", "W4")}}
        )
    elif label == "wo3_size":
        project.phase("WO3_P-1").set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 1.0, "refine": True}},
            histograms=[hist],
        )
    elif label == "wo3_strain":
        phase = project.phase("WO3_P-1")
        phase.getHAPvalues(hist)["Mustrain"][1][0] = 100.0
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}},
            histograms=[hist],
        )
        project.set_Controls("parmMin", 0.0, variable="1:0:Mustrain;i")
    elif label == "wo3_size_strain":
        phase = project.phase("WO3_P-1")
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 1.0, "refine": True}},
            histograms=[hist],
        )
        phase.getHAPvalues(hist)["Mustrain"][1][0] = 100.0
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}},
            histograms=[hist],
        )
        project.set_Controls("parmMin", 0.0, variable="1:0:Mustrain;i")
    else:
        raise ValueError(label)


def summarize(project):
    hist = project.histogram(0)
    return {
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "profile": {
            k: hist.InstrumentParameters[k][1]
            for k in ("Polariz.", "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "atoms": {
            phase.name: {
                atom.label: {
                    "type": atom.type,
                    "xyz": atom.coordinates,
                    "uiso": atom.ADP,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            }
            for phase in project.phases()
        },
        "widths": {
            phase.name: {
                "size": phase.getHAPvalues(hist)["Size"],
                "mustrain": phase.getHAPvalues(hist)["Mustrain"],
            }
            for phase in project.phases()
        },
        "vary": project.get_VaryList(),
    }


def run(label):
    out = ROOT / "trials" / f"{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 20)
    configure(project, label)
    project.save()
    project.refine()
    project.save()
    project = G2sc.G2Project(str(out))
    project.set_Controls("cycles", 20)
    project.refine()
    project.save()
    return summarize(project)


def main():
    labels = [
        "baco3_ba_xyz",
        "baco3_all_xyz",
        "wo3_w_xyz",
        "wo3_size",
        "wo3_strain",
        "wo3_size_strain",
    ]
    summary = {}
    for label in labels:
        print(f"\n=== {label} ===", flush=True)
        try:
            summary[label] = run(label)
            short = {
                "wR": summary[label]["residuals"].get("wR"),
                "mass_fractions": summary[label]["mass_fractions"],
                "profile": summary[label]["profile"],
                "widths": summary[label]["widths"]["WO3_P-1"],
            }
            print(json.dumps(short, indent=2), flush=True)
        except Exception as exc:
            summary[label] = {"error": repr(exc)}
            print(summary[label], flush=True)
    with (ROOT / "trials" / "structure_summary.json").open("w") as handle:
        json.dump(summary, handle, indent=2)


if __name__ == "__main__":
    main()
