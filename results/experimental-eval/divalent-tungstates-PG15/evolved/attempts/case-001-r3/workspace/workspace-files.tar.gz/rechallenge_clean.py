#!/usr/bin/env python3
"""Re-challenge the weak BaWO4 phase after establishing the clean profile."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import screen_models as sm


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "trials" / "pol_clean.gpx"


def neutralize(phase, hist):
    phase.clear_HAP_refinements(
        {
            "Size": True,
            "Mustrain": True,
            "HStrain": True,
            "Pref.Ori.": True,
            "Extinction": True,
            "Babinet": ["BabA", "BabU"],
        },
        histograms=[hist],
    )
    hap = phase.getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0


def summarize(project):
    hist = project.histogram(0)
    return {
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "profile": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Polariz.", "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "phases": {
            phase.name: {
                "scale": phase.HAPvalue("Scale"),
                "cell": phase.get_cell(),
            }
            for phase in project.phases()
        },
    }


def run(label: str, candidate: str | None):
    out = ROOT / "trials" / f"clean_watch_{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 20)
    hist = project.histogram(0)

    old = project.phase("BaWO4_ordered")
    old.HAPvalue("Scale", 0.0, [hist])
    old.clear_HAP_refinements({"Scale": True}, histograms=[hist])
    old.set_refinements({"Cell": False})

    new_phase = None
    if candidate:
        new_phase = project.add_phase(
            sm.PHASES[candidate],
            phasename=candidate,
            histograms=[hist],
            fmthint="CIF",
        )
        neutralize(new_phase, hist)
        new_phase.HAPvalue("Scale", 0.12, [hist])
        new_phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
        new_phase.set_refinements({"Cell": False})

    # First establish scale with the smooth background, major cells, common
    # profile, polarization and one angular correction still active.
    project.save()
    project.refine()
    project.save()

    # Only after a positive scale is established is the candidate cell freed.
    if new_phase is not None and new_phase.HAPvalue("Scale") > 0:
        new_phase.set_refinements({"Cell": True})
        project.save()
    project = G2sc.G2Project(str(out))
    project.set_Controls("cycles", 20)
    project.refine()
    project.save()

    # Reopen/replay over the full range.
    project = G2sc.G2Project(str(out))
    project.set_Controls("cycles", 20)
    project.refine()
    project.save()
    return summarize(project)


def main():
    result = {}
    for label, candidate in (
        ("none", None),
        ("moproto", "BaWO4_proto"),
        ("split", "BaWO4_split"),
    ):
        print(f"\n=== {label} ===", flush=True)
        try:
            result[label] = run(label, candidate)
            print(json.dumps(result[label], indent=2), flush=True)
        except Exception as exc:
            result[label] = {"error": repr(exc)}
            print(result[label], flush=True)
    with (ROOT / "trials" / "clean_watch_summary.json").open("w") as handle:
        json.dump(result, handle, indent=2)


if __name__ == "__main__":
    main()
