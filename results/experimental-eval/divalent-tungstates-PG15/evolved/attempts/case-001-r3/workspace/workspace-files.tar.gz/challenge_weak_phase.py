#!/usr/bin/env python3
"""Re-challenge BaWO4 records under a fixed clean common profile."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import screen_models as sm


ROOT = Path(__file__).resolve().parent


def freeze_common_profile(hist):
    hist.clear_refinements(
        {"Instrument Parameters": ["U", "V", "W", "X", "Y", "Z", "SH/L"]}
    )


def neutralize(phase, hist):
    phase.clear_HAP_refinements(
        {
            "Size": True,
            "Mustrain": True,
            "HStrain": True,
            "Pref.Ori.": True,
            "Extinction": True,
            "Babinet": ["BabA", "BabU"],
        },
        histograms=[hist],
    )
    hap = phase.getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0e6
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0


def summarize(project, hist):
    return {
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "profile": {
            k: hist.InstrumentParameters[k][1]
            for k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "phases": {
            p.name: {
                "scale": p.HAPvalue("Scale"),
                "cell": p.get_cell(),
            }
            for p in project.phases()
        },
    }


def run(base: str, label: str, candidate: str | None):
    out = ROOT / "watch" / f"{label}.gpx"
    out.parent.mkdir(exist_ok=True)
    project = G2sc.G2Project(str(ROOT / base), newgpx=str(out))
    hist = project.histogram(0)
    freeze_common_profile(hist)
    project.set_Controls("cycles", 16)

    if candidate:
        phase = project.add_phase(
            sm.PHASES[candidate],
            phasename=candidate,
            histograms=[hist],
            fmthint="CIF",
        )
        neutralize(phase, hist)
        phase.HAPvalue("Scale", 0.05)
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
        phase.set_refinements({"Cell": False})

    # Existing flags retain smooth background, all scales, zero, and major cells.
    project.save()
    project.refine()
    project.save()
    return summarize(project, hist)


def main():
    trials = {
        "mono_none": ("screen/baco3_wo3_2023.gpx", None),
        "mono_ordered": ("screen/baco3_wo3_2023.gpx", "BaWO4_ordered"),
        "mono_moproto": ("screen/baco3_wo3_2023.gpx", "BaWO4_proto"),
        "mono_split": ("screen/baco3_wo3_2023.gpx", "BaWO4_split"),
        "tri_none": ("screen/baco3_wo3_triclinic.gpx", None),
        "tri_ordered": ("screen/baco3_wo3_triclinic.gpx", "BaWO4_ordered"),
        "tri_moproto": ("screen/baco3_wo3_triclinic.gpx", "BaWO4_proto"),
        "tri_split": ("screen/baco3_wo3_triclinic.gpx", "BaWO4_split"),
    }
    result = {}
    for label, (base, candidate) in trials.items():
        print(f"\n=== {label} ===", flush=True)
        try:
            result[label] = run(base, label, candidate)
            print(json.dumps(result[label], indent=2), flush=True)
        except Exception as exc:
            result[label] = {"error": repr(exc)}
            print(result[label], flush=True)
    with (ROOT / "watch" / "summary.json").open("w") as handle:
        json.dump(result, handle, indent=2)


if __name__ == "__main__":
    main()
