import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

f = sys.argv[1]
out = sys.argv[2]
d = np.genfromtxt(f, delimiter=',', names=True)
x = d['2theta'] if '2theta' in d.dtype.names else d[d.dtype.names[0]]
yo = d[d.dtype.names[1]]; yc = d[d.dtype.names[2]]
n = 4
fig, axes = plt.subplots(n, 1, figsize=(16, 4 * n))
edges = np.linspace(x.min(), x.max(), n + 1)
for i, ax in enumerate(axes):
    m = (x >= edges[i]) & (x <= edges[i + 1])
    ax.plot(x[m], yo[m], 'k.', ms=2, label='obs')
    ax.plot(x[m], yc[m], 'r-', lw=0.8, label='calc')
    ax.plot(x[m], yo[m] - yc[m] - 0.15 * yo[m].max(), 'b-', lw=0.6, label='diff')
    ax.legend(fontsize=7)
    ax.set_xlim(edges[i], edges[i + 1])
plt.tight_layout()
plt.savefig(out, dpi=85)
print('saved', out)
