import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

WS = '<ATTEMPT_WORKSPACE>'
d = np.genfromtxt(WS + '/fit.csv', delimiter=',', names=True)
x, yo, yc, dy = d['two_theta_deg'], d['y_obs'], d['y_calc'], d['y_diff']

fig, axes = plt.subplots(2, 1, figsize=(13, 8), gridspec_kw={'height_ratios': [1, 1]})
for ax, (lo, hi) in zip(axes, [(10, 55), (55, 100.1)]):
    m = (x >= lo) & (x <= hi)
    off = -0.18 * yo[m].max()
    ax.plot(x[m], yo[m], 'k.', ms=2.0, label='observed')
    ax.plot(x[m], yc[m], 'r-', lw=0.9, label='calculated')
    ax.plot(x[m], dy[m] + off, 'b-', lw=0.6, label='difference')
    ax.axhline(off, color='0.6', lw=0.5)
    ax.set_xlim(lo, hi)
    ax.set_xlabel(r'2$\theta$ / deg (Cu K$\alpha$)')
    ax.set_ylabel('counts')
    ax.legend(fontsize=8, loc='upper right')
axes[0].set_title('Rietveld fit: ZnWO$_4$ 73.4 wt% + WO$_3$ 20.2 wt% + ZnO 6.4 wt%  '
                  '(Rwp = 4.73 %, GOF = 1.25)')
plt.tight_layout()
plt.savefig(WS + '/fit.png', dpi=130)
print('saved fit.png')
