import sys
import numpy as np
from scipy.signal import find_peaks
from scipy.ndimage import uniform_filter1d

d = np.genfromtxt(sys.argv[1], delimiter=',', names=True)
c = d.dtype.names
x = d[c[0]]; r = uniform_filter1d(d[c[1]] - d[c[2]], 9)
thr = float(sys.argv[2]) if len(sys.argv) > 2 else 80
pk, pr = find_peaks(r, prominence=thr, distance=10)
lam = 1.540598
print(f"{'2th':>9} {'d':>8} {'resid':>8} {'prom':>8}")
for i, p in zip(pk, pr['prominences']):
    print(f"{x[i]:9.3f} {lam/(2*np.sin(np.radians(x[i]/2))):8.4f} {r[i]:8.1f} {p:8.1f}")
