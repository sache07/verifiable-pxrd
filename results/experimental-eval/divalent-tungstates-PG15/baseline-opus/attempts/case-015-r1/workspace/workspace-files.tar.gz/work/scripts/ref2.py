import os, sys, json
import numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
import GSASIIscriptable as G2sc

OUT = '<ATTEMPT_WORKSPACE>/work/out'
gpx_path = os.path.join(OUT, 'step2.gpx')
for f in (gpx_path, gpx_path.replace('.gpx', '.bak0.gpx')):
    if os.path.exists(f):
        os.remove(f)
gpx = G2sc.G2Project(newgpx=gpx_path)
hist = gpx.add_powder_histogram(os.path.join(OUT, 'pattern.xye'),
                                os.path.join(OUT, 'inst.instprm'), fmthint='Topas')
ph = gpx.add_phase(os.path.join(OUT, '1520641.cif'), phasename='ZnWO4', histograms=[hist])

# modest starting profile: U,V,W small; Y (Lorentzian size) moderate
ip = hist.getHistEntryValue(['Instrument Parameters'])[0]
for k, v in [('U', 2.0), ('V', -0.5), ('W', 0.5), ('X', 0.0), ('Y', 2.0), ('SH/L', 0.002)]:
    ip[k][1] = v

hist.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 10, 'refine': True}})
gpx.refine()
hist.set_refinements({'Sample Parameters': ['Shift', 'Scale']})
ph.set_refinements({'Cell': True})
gpx.refine()
hist.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']})
gpx.refine()
print('Rwp', hist.get_wR())
print({k: ip[k][1] for k in ['U', 'V', 'W', 'X', 'Y']})
print('cell', ph.get_cell())
print('Shift', hist.data['Sample Parameters']['Shift'])

x = hist.getdata('X'); yo = hist.getdata('Yobs'); yc = hist.getdata('Ycalc'); bg = hist.getdata('Background')
np.savetxt(os.path.join(OUT, 'step2_prof.csv'), np.c_[x, yo, yc, bg], delimiter=',',
           header='2theta,yobs,ycalc,bkg', comments='')
