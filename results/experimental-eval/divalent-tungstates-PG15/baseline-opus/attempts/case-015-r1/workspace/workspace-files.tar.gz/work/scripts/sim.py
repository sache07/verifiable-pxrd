import sys
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator

c = XRDCalculator(wavelength=1.540598)
for f in sys.argv[1:]:
    s = Structure.from_file(f)
    print("====", f, s.composition.reduced_formula, s.lattice.abc, s.lattice.angles)
    p = c.get_pattern(s, two_theta_range=(10, 70))
    for tt, i, hkl in zip(p.x, p.y, p.hkls):
        if i > 2:
            h = hkl[0]['hkl']
            print(f"  {tt:8.3f} {i:7.2f} {h}")
