import sys, numpy as np
from scipy.signal import find_peaks

f = sys.argv[1]
d = np.loadtxt(f, delimiter=',', skiprows=1)
x, y = d[:, 0], d[:, 1]
print("range", x.min(), x.max(), "step", np.median(np.diff(x)), "N", len(x))
print("Imax", y.max(), "at", x[np.argmax(y)], "Imin", y.min())

# crude background via rolling min + smoothing
from scipy.ndimage import minimum_filter1d, uniform_filter1d
bg = minimum_filter1d(y, 201)
bg = uniform_filter1d(bg, 301)
yc = y - bg
pk, props = find_peaks(yc, prominence=max(30, 0.01 * yc.max()), distance=5)
lam = 1.540598
print(f"{'2th':>9} {'d':>8} {'Iobs':>9} {'Irel':>6}")
order = np.argsort(-yc[pk])
for i in pk:
    tt = x[i]
    dsp = lam / (2 * np.sin(np.radians(tt / 2)))
    print(f"{tt:9.4f} {dsp:8.4f} {yc[i]:9.1f} {100*yc[i]/yc[pk].max():6.1f}")
print("npeaks", len(pk))
