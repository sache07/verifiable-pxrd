"""Definitive refinement + export of deliverables.

usage: produce.py TAG [name=cif ...]
env: UISO_MODE = refine | fixed
"""
import os, sys, json, re, shutil
import numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
import GSASIIscriptable as G2sc

WS = '<ATTEMPT_WORKSPACE>'
OUT = os.path.join(WS, 'work/out')
TAG = sys.argv[1] if len(sys.argv) > 1 else 'prod'
SPECS = [s.split('=') for s in sys.argv[2:]] or [
    ('ZnWO4', '1520641.cif'), ('WO3', '2311041.cif'), ('ZnO', '9004178.cif')]
UISO_MODE = os.environ.get('UISO_MODE', 'refine')
COORD_PHASES = os.environ.get('COORD_PHASES', 'ZnWO4').split(',')
DEFAULT_U = {'W': 0.005, 'Zn': 0.008, 'O': 0.012}


def hap(ph):
    return ph.data['Histograms'][list(ph.data['Histograms'])[0]]


def setU(ph, a, val):
    a.data[a.cia] = 'I'
    a.data[a.cia + 1] = val


gpx_path = os.path.join(OUT, f'{TAG}.gpx')
for suff in ('.gpx',) + tuple(f'.bak{i}.gpx' for i in range(8)):
    f = os.path.join(OUT, TAG + suff)
    if os.path.exists(f):
        os.remove(f)

gpx = G2sc.G2Project(newgpx=gpx_path)
hist = gpx.add_powder_histogram(os.path.join(OUT, 'pattern.xye'),
                                os.path.join(OUT, 'inst.instprm'), fmthint='Topas')
phases = []
for name, cif in SPECS:
    phases.append(gpx.add_phase(os.path.join(OUT, cif), phasename=name, histograms=[hist]))

ip = hist.getHistEntryValue(['Instrument Parameters'])[0]
for k, v in [('U', 10.0), ('V', -10.0), ('W', 160.0), ('X', 0.0), ('Y', 0.0), ('SH/L', 0.002)]:
    ip[k][1] = v
sp = hist.data['Sample Parameters']
for ph in phases:
    h = hap(ph)
    h['Size'][1][0] = 1.0
    h['Mustrain'][1][0] = 1.0
    h['Scale'][0] = 1.0 / len(phases)
    for a in ph.atoms():
        setU(ph, a, DEFAULT_U.get(a.type, 0.01))

trace = []


def step(label):
    gpx.refine()
    r = hist.get_wR()
    trace.append([label, round(r, 4)])
    print(f'  {label:28s} Rwp={r:.3f}', flush=True)


hist.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True}})
step('bkg')
for ph in phases[1:]:
    ph.set_HAP_refinements({'PhaseFraction': True})
step('+phasefrac')
hist.set_refinements({'Sample Parameters': ['Shift']})
step('+shift')
hist.set_refinements({'Instrument Parameters': ['U', 'V', 'W']})
step('+UVW')
for ph in phases:
    ph.set_refinements({'Cell': True})
step('+cells')
hist.set_refinements({'Instrument Parameters': ['SH/L']})
step('+SH/L')
hist.set_refinements({'Sample Parameters': ['SurfRoughA', 'SurfRoughB']})
step('+surfrough')
print('   SurfRoughA/B =', sp['SurfRoughA'][0], sp['SurfRoughB'][0], flush=True)
if not 0.0 <= sp['SurfRoughA'][0] <= 1.0:
    sp['SurfRoughA'] = [min(max(sp['SurfRoughA'][0], 0.0), 1.0), False]
    step('surfroughA-clamped')
if not 0.0 <= sp['SurfRoughB'][0] <= 5.0:
    sp['SurfRoughB'] = [min(max(sp['SurfRoughB'][0], 0.0), 5.0), False]
    step('surfroughB-clamped')
for ph in phases:
    ph.set_HAP_refinements({'Size': {'refine': True}})
step('+size')
for ph in phases:
    h = hap(ph)
    if not (0.01 < h['Size'][1][0] < 5.0):
        print('   size reset', ph.name, h['Size'][1][0])
        h['Size'][1][0] = 1.0
        h['Size'][2][0] = False
step('size-check')
if UISO_MODE == 'refine':
    # one overall Uiso per phase (all atoms of a phase held equivalent)
    gpx.save()
    for ph in phases:
        n = len(ph.data['Atoms'])
        if n > 1:
            gpx.add_EquivConstr([f'{ph.id}::AUiso:{i}' for i in range(n)])
    for ph in phases:
        ph.set_refinements({'Atoms': {a.label: 'U' for a in ph.atoms()}})
    step('+Uiso(overall/phase)')
    for ph in phases:
        a0 = ph.atoms()[0]; u = a0.data[a0.cia + 1]
        print(f'   Uiso overall {ph.name} = {u:.5f}')
        if not (0.0005 <= u <= 0.06):
            for a in ph.atoms():
                setU(ph, a, 0.005)
            ph.clear_refinements({'Atoms': {a.label: 'U' for a in ph.atoms()}})
            print('   Uiso fixed at 0.005 for', ph.name)
    step('Uiso-clamped')
for ph in phases:
    if ph.name in COORD_PHASES:
        ph.set_refinements({'Atoms': {a.label: 'X' for a in ph.atoms()}})
step('+coords')
for ph in phases:
    a0 = ph.atoms()[0]; u = a0.data[a0.cia + 1]
    if not (0.0005 <= u <= 0.06):
        for a in ph.atoms():
            setU(ph, a, 0.005)
        ph.clear_refinements({'Atoms': {a.label: 'U' for a in ph.atoms()}})
        print('   Uiso fixed at 0.005 (late):', ph.name)
step('final')

# ---------------- results ----------------------------------------------
from GSASII import GSASIImath as G2mth
masses = {ph.name: (ph.data['General'].get('Mass') or G2mth.getMass(ph.data['General']))
          for ph in phases}
tot = sum(masses[ph.name] * hap(ph)['Scale'][0] for ph in phases)
wf = {ph.name: masses[ph.name] * hap(ph)['Scale'][0] / tot for ph in phases}

# weight-fraction esds from the .lst file written by the last refinement
sig = {}
lst = os.path.join(OUT, f'{TAG}.lst')
cur = None
if os.path.exists(lst):
    for line in open(lst):
        m = re.match(r'\s*Phase:\s*(\S+)\s+in histogram', line)
        if m:
            cur = m.group(1)
        m = re.search(r'Weight fraction\s*:\s*([\d.eE+-]+),\s*sig\s*([\d.eE+-]+)', line)
        if m and cur:
            sig[cur] = (float(m.group(1)), float(m.group(2)))

Rvals = gpx.data['Covariance']['data']['Rvals']
res = hist.residuals
out = {
    'tag': TAG, 'Rwp_percent': Rvals['Rwp'], 'GOF': Rvals['GOF'],
    'chi2': Rvals['chisq'], 'Nobs': Rvals['Nobs'], 'Nvars': Rvals['Nvars'],
    'Rp_percent': res.get('R'), 'Rb': res.get('Rb'),
    'weight_fractions': {k: round(v, 5) for k, v in wf.items()},
    'wf_from_lst': sig, 'trace': trace,
    'sample': {'Shift_um': sp['Shift'][0], 'SurfRoughA': sp['SurfRoughA'][0],
               'SurfRoughB': sp['SurfRoughB'][0]},
    'inst': {k: ip[k][1] for k in ('U', 'V', 'W', 'X', 'Y', 'SH/L', 'Zero',
                                   'Lam1', 'Lam2', 'I(L2)/I(L1)', 'Polariz.')},
    'phases': {},
}
for ph in phases:
    h = hap(ph)
    out['phases'][ph.name] = {
        'formula': ph.data['General']['Name'],
        'spacegroup': ph.data['General']['SGData']['SpGrp'],
        'cell': {k: round(v, 6) for k, v in ph.get_cell().items()},
        'phase_scale': h['Scale'][0],
        'size_um': h['Size'][1][0],
        'Rf_percent': res.get(f'{ph.id}:0:Rf'), 'Rf2_percent': res.get(f'{ph.id}:0:Rf^2'),
        'nref': res.get(f'{ph.id}:0:Nref'),
        'atoms': [{'label': a.label, 'type': a.type,
                   'xyz': [round(c, 5) for c in a.coordinates],
                   'Uiso': round(a.data[a.cia + 1], 5), 'occ': a.occupancy}
                  for a in ph.atoms()],
    }
print('RESULT ' + json.dumps(out, indent=1))
with open(os.path.join(OUT, f'{TAG}_result.json'), 'w') as fh:
    json.dump(out, fh, indent=2)

x = hist.getdata('X'); yo = hist.getdata('Yobs'); yc = hist.getdata('Ycalc'); bg = hist.getdata('Background')
w = hist.getdata('yweight')
np.savetxt(os.path.join(OUT, f'{TAG}_prof.csv'), np.c_[x, yo, yc, bg, yo - yc, w], delimiter=',',
           header='2theta,yobs,ycalc,bkg,diff,weight', comments='')
gpx.save()
# export CIFs
for ph in phases:
    try:
        ph.export_CIF(os.path.join(OUT, f'{TAG}_{ph.name}.cif'))
    except Exception as e:
        print('export fail', ph.name, repr(e))
print('DONE')
