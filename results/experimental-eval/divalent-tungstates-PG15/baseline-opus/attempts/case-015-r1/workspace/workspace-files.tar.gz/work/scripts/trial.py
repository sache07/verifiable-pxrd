"""Try a combination of phases; refine scale/cell/profile; report Rwp and weight fractions."""
import os, sys, json
import numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
import GSASIIscriptable as G2sc

OUT = '<ATTEMPT_WORKSPACE>/work/out'

tag = sys.argv[1]
specs = sys.argv[2:]   # name=ciffile

gpx_path = os.path.join(OUT, f'{tag}.gpx')
for suff in ('.gpx', '.bak0.gpx', '.bak1.gpx'):
    f = os.path.join(OUT, tag + suff)
    if os.path.exists(f):
        os.remove(f)

gpx = G2sc.G2Project(newgpx=gpx_path)
hist = gpx.add_powder_histogram(os.path.join(OUT, 'pattern.xye'),
                                os.path.join(OUT, 'inst.instprm'), fmthint='Topas')
phases = []
for s in specs:
    name, cif = s.split('=')
    ph = gpx.add_phase(os.path.join(OUT, cif), phasename=name, histograms=[hist])
    phases.append(ph)

ip = hist.getHistEntryValue(['Instrument Parameters'])[0]
for k, v in [('U', 2.0), ('V', -0.6), ('W', 1.0), ('X', 0.0), ('Y', 0.0), ('SH/L', 0.002)]:
    ip[k][1] = v

for ph in phases:
    hap = ph.data['Histograms'][list(ph.data['Histograms'])[0]]
    hap['Size'][1][0] = 0.05
    hap['Mustrain'][1][0] = 1000.0

hist.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True}})
gpx.refine()
for ph in phases:
    ph.set_HAP_refinements({'Size': {'refine': True}})
gpx.refine()
hist.set_refinements({'Sample Parameters': ['Shift']})
gpx.refine()
for ph in phases:
    ph.set_refinements({'Cell': True})
gpx.refine()
gpx.refine()

print('TAG', tag, 'Rwp', hist.get_wR())
try:
    import GSASIIstrIO
except Exception:
    pass
# weight fractions
from GSASII import GSASIImath as G2mth
hId = hist.id
for ph in phases:
    print(' phase', ph.name, 'cell', {k: round(v, 5) for k, v in ph.get_cell().items()})
    hap = ph.data['Histograms'][list(ph.data['Histograms'])[0]]
    print('   scale', hap['Scale'], 'size', hap['Size'][1][0], 'mustrain', hap['Mustrain'][1][0])

x = hist.getdata('X'); yo = hist.getdata('Yobs'); yc = hist.getdata('Ycalc'); bg = hist.getdata('Background')
np.savetxt(os.path.join(OUT, f'{tag}_prof.csv'), np.c_[x, yo, yc, bg], delimiter=',',
           header='2theta,yobs,ycalc,bkg', comments='')
