"""Assemble final deliverables from a finished GSAS-II run."""
import os, sys, json, shutil
import numpy as np

WS = '<ATTEMPT_WORKSPACE>'
OUT = os.path.join(WS, 'work/out')
TAG = sys.argv[1]

r = json.load(open(os.path.join(OUT, f'{TAG}_result.json')))

# --- fit.csv -------------------------------------------------------------
d = np.genfromtxt(os.path.join(OUT, f'{TAG}_prof.csv'), delimiter=',', names=True)
hdr = 'two_theta_deg,y_obs,y_calc,y_diff,y_background'
np.savetxt(os.path.join(WS, 'fit.csv'),
           np.c_[d['2theta'], d['yobs'], d['ycalc'], d['yobs'] - d['ycalc'], d['bkg']],
           delimiter=',', header=hdr, comments='', fmt='%.6f,%.4f,%.4f,%.4f,%.4f'.split(',')[0:1] * 0 or
           ['%.6f', '%.4f', '%.4f', '%.4f', '%.4f'])

# --- CIFs ----------------------------------------------------------------
cifmap = {}
for name in r['phases']:
    src = os.path.join(OUT, f'{TAG}_{name}.cif')
    dst = os.path.join(WS, f'{name}.cif')
    shutil.copyfile(src, dst)
    cifmap[name] = os.path.basename(dst)

# --- final.gpx -----------------------------------------------------------
shutil.copyfile(os.path.join(OUT, f'{TAG}.gpx'), os.path.join(WS, 'final.gpx'))

print(json.dumps({'cifs': cifmap, 'Rwp': r['Rwp_percent'], 'wf': r['weight_fractions']}, indent=1))
