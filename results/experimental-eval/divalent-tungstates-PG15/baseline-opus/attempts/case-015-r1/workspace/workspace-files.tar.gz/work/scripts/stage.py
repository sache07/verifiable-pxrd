"""Staged multiphase Rietveld refinement with reporting of weight fractions."""
import os, sys, json
import numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
import GSASIIscriptable as G2sc

OUT = '<ATTEMPT_WORKSPACE>/work/out'


def hap(ph):
    return ph.data['Histograms'][list(ph.data['Histograms'])[0]]


def wfrac(gpx, hist, phases):
    """Weight fractions, GSAS-II convention: mass(unit cell) * phase scale."""
    from GSASII import GSASIImath as G2mth
    tot = {}
    for ph in phases:
        gen = ph.data['General']
        mass = gen.get('Mass') or G2mth.getMass(gen)
        tot[ph.name] = hap(ph)['Scale'][0] * mass
    s = sum(tot.values())
    return {k: v / s for k, v in tot.items()}


def run(tag, specs, nbkg=10, refine_coords=False, verbose=True):
    gpx_path = os.path.join(OUT, f'{tag}.gpx')
    for suff in ('.gpx', '.bak0.gpx', '.bak1.gpx', '.bak2.gpx'):
        f = os.path.join(OUT, tag + suff)
        if os.path.exists(f):
            os.remove(f)
    gpx = G2sc.G2Project(newgpx=gpx_path)
    hist = gpx.add_powder_histogram(os.path.join(OUT, 'pattern.xye'),
                                    os.path.join(OUT, 'inst.instprm'), fmthint='Topas')
    phases = []
    for name, cif in specs:
        ph = gpx.add_phase(os.path.join(OUT, cif), phasename=name, histograms=[hist])
        phases.append(ph)

    ip = hist.getHistEntryValue(['Instrument Parameters'])[0]
    for k, v in [('U', 10.0), ('V', -10.0), ('W', 160.0), ('X', 0.0), ('Y', 0.0), ('SH/L', 0.002)]:
        ip[k][1] = v
    for ph in phases:
        h = hap(ph)
        h['Size'][1][0] = 1.0
        h['Mustrain'][1][0] = 1.0
        h['Scale'][0] = 1.0 / len(phases)

    log = []

    def step(label):
        gpx.refine()
        log.append((label, hist.get_wR()))
        if verbose:
            print(f'  {label:32s} Rwp={hist.get_wR():.3f}')

    hist.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': nbkg, 'refine': True}})
    step('bkg')
    if len(phases) > 1:
        for ph in phases[1:]:
            ph.set_HAP_refinements({'PhaseFraction': True})
        step('+phasefrac')
    hist.set_refinements({'Sample Parameters': ['Shift']})
    step('+shift')
    hist.set_refinements({'Instrument Parameters': ['U', 'V', 'W']})
    step('+UVW')
    for ph in phases:
        ph.set_refinements({'Cell': True})
        step(f'+cell {ph.name}')
    for ph in phases:
        ph.set_HAP_refinements({'Size': {'refine': True}})
    step('+size')
    for ph in phases:
        h = hap(ph)
        if not (0.005 < h['Size'][1][0] < 10.0):
            h['Size'][1][0] = 1.0
            h['Size'][2][0] = False
            print('   size reset for', ph.name)
    step('size-check')
    if refine_coords:
        for ph in phases:
            ph.set_refinements({'Atoms': {a.label: 'XU' for a in ph.atoms()}})
        step('+coords')

    wf = wfrac(gpx, hist, phases)
    print(f'TAG {tag}  Rwp={hist.get_wR():.3f}  GOF={gpx.data["Covariance"]["data"]["Rvals"].get("GOF"):.3f}')
    print('  Rvals:', {k: (round(v, 4) if isinstance(v, float) else v)
                       for k, v in gpx.data['Covariance']['data']['Rvals'].items()})
    for ph in phases:
        h = hap(ph)
        print(f'  {ph.name:10s} wf={wf[ph.name]*100:6.2f}%  scale={h["Scale"][0]:.4g} '
              f"size={h['Size'][1][0]:.4f}um "
              f'cell={ {k: round(v,5) for k,v in ph.get_cell().items()} }')
    print('  Shift', round(hist.data['Sample Parameters']['Shift'][0], 2))
    x = hist.getdata('X'); yo = hist.getdata('Yobs'); yc = hist.getdata('Ycalc'); bg = hist.getdata('Background')
    np.savetxt(os.path.join(OUT, f'{tag}_prof.csv'), np.c_[x, yo, yc, bg], delimiter=',',
               header='2theta,yobs,ycalc,bkg', comments='')
    return gpx, hist, phases, wf


if __name__ == '__main__':
    tag = sys.argv[1]
    specs = [s.split('=') for s in sys.argv[2:]]
    run(tag, specs)
