"""Final staged Rietveld refinement: ZnWO4 + WO3 + ZnO (configurable)."""
import os, sys, json
import numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
import GSASIIscriptable as G2sc

OUT = '<ATTEMPT_WORKSPACE>/work/out'
TAG = sys.argv[1] if len(sys.argv) > 1 else 'f_all'
SPECS = [s.split('=') for s in sys.argv[2:]] or [
    ('ZnWO4', '1520641.cif'), ('WO3', '2311041.cif'), ('ZnO', '9004178.cif')]
COORD_PHASES = os.environ.get('COORD_PHASES', 'ZnWO4').split(',')


def hap(ph):
    return ph.data['Histograms'][list(ph.data['Histograms'])[0]]


def force_iso(ph, u=0.01):
    for a in ph.atoms():
        if a.adp_flag != 'I':
            a.data[a.cia] = 'I'
            a.data[a.cia + 1] = u
        elif not (0.0 < a.data[a.cia + 1] < 0.1):
            a.data[a.cia + 1] = u


gpx_path = os.path.join(OUT, f'{TAG}.gpx')
for suff in ('.gpx',) + tuple(f'.bak{i}.gpx' for i in range(6)):
    f = os.path.join(OUT, TAG + suff)
    if os.path.exists(f):
        os.remove(f)

gpx = G2sc.G2Project(newgpx=gpx_path)
hist = gpx.add_powder_histogram(os.path.join(OUT, 'pattern.xye'),
                                os.path.join(OUT, 'inst.instprm'), fmthint='Topas')
phases = []
for name, cif in SPECS:
    phases.append(gpx.add_phase(os.path.join(OUT, cif), phasename=name, histograms=[hist]))

ip = hist.getHistEntryValue(['Instrument Parameters'])[0]
for k, v in [('U', 10.0), ('V', -10.0), ('W', 160.0), ('X', 0.0), ('Y', 0.0), ('SH/L', 0.002)]:
    ip[k][1] = v
sp = hist.data['Sample Parameters']
for ph in phases:
    h = hap(ph)
    h['Size'][1][0] = 1.0
    h['Mustrain'][1][0] = 1.0
    h['Scale'][0] = 1.0 / len(phases)
    force_iso(ph)

trace = []


def step(label):
    gpx.refine()
    r = hist.get_wR()
    trace.append((label, r))
    print(f'  {label:28s} Rwp={r:.3f}', flush=True)


hist.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 10, 'refine': True}})
step('bkg')
if len(phases) > 1:
    for ph in phases[1:]:
        ph.set_HAP_refinements({'PhaseFraction': True})
    step('+phasefrac')
hist.set_refinements({'Sample Parameters': ['Shift']})
step('+shift')
hist.set_refinements({'Instrument Parameters': ['U', 'V', 'W']})
step('+UVW')
for ph in phases:
    ph.set_refinements({'Cell': True})
step('+cells')
hist.set_refinements({'Instrument Parameters': ['SH/L']})
step('+SH/L')
hist.set_refinements({'Sample Parameters': ['SurfRoughA', 'SurfRoughB']})
step('+surfrough')
print('   SurfRoughA/B =', sp['SurfRoughA'][0], sp['SurfRoughB'][0], flush=True)
if not 0.0 <= sp['SurfRoughA'][0] <= 1.0:
    sp['SurfRoughA'] = [min(max(sp['SurfRoughA'][0], 0.0), 1.0), False]
    print('   SurfRoughA clamped+fixed at', sp['SurfRoughA'][0])
    step('surfroughA-clamped')
if not 0.0 <= sp['SurfRoughB'][0] <= 5.0:
    sp['SurfRoughB'] = [min(max(sp['SurfRoughB'][0], 0.0), 5.0), False]
    print('   SurfRoughB clamped+fixed at', sp['SurfRoughB'][0])
    step('surfroughB-clamped')
for ph in phases:
    ph.set_HAP_refinements({'Size': {'refine': True}})
step('+size')
for ph in phases:
    h = hap(ph)
    if not (0.01 < h['Size'][1][0] < 5.0):
        print('   size reset for', ph.name, h['Size'][1][0])
        h['Size'][1][0] = 1.0
        h['Size'][2][0] = False
step('size-check')
for ph in phases:
    ph.set_refinements({'Atoms': {a.label: 'U' for a in ph.atoms()}})
step('+Uiso')
for ph in phases:
    bad = [a.label for a in ph.atoms() if not (0.0 < a.data[a.cia + 1] < 0.08)]
    if bad:
        for a in ph.atoms():
            if a.label in bad:
                a.data[a.cia + 1] = 0.008
        ph.clear_refinements({'Atoms': {lb: 'U' for lb in bad}})
        print('   Uiso reset', ph.name, bad)
step('Uiso-check')
for ph in phases:
    if ph.name in COORD_PHASES:
        ph.set_refinements({'Atoms': {a.label: 'X' for a in ph.atoms()}})
step('+coords')
hist.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 14, 'refine': True}})
step('+bkg14')
step('final')

# ---- report -------------------------------------------------------------
from GSASII import GSASIImath as G2mth
masses = {ph.name: (ph.data['General'].get('Mass') or G2mth.getMass(ph.data['General']))
          for ph in phases}
tot = sum(masses[ph.name] * hap(ph)['Scale'][0] for ph in phases)
wf = {ph.name: masses[ph.name] * hap(ph)['Scale'][0] / tot for ph in phases}

Rvals = gpx.data['Covariance']['data']['Rvals']
print('RESULT ' + json.dumps({
    'tag': TAG, 'Rwp': Rvals['Rwp'], 'GOF': Rvals['GOF'], 'chisq': Rvals['chisq'],
    'Nobs': Rvals['Nobs'], 'Nvars': Rvals['Nvars'],
    'wf': {k: round(v, 5) for k, v in wf.items()}}))
res = hist.residuals
print('  residuals', {k: (round(v, 4) if isinstance(v, float) else v) for k, v in res.items()})
for ph in phases:
    h = hap(ph)
    print(f'  {ph.name:8s} wf={wf[ph.name]*100:6.2f}% scale={h["Scale"][0]:.5g} '
          f'size={h["Size"][1][0]:.4f} cell=' +
          json.dumps({k: round(v, 5) for k, v in ph.get_cell().items()}))
    for a in ph.atoms():
        print(f'      {a.label:4s} {a.type:3s} '
              f'{tuple(round(c,5) for c in a.coordinates)} U={a.data[a.cia+1]:.5f} occ={a.occupancy}')
print('  Shift', sp['Shift'][0], 'SurfRoughA', sp['SurfRoughA'][0], 'SurfRoughB', sp['SurfRoughB'][0])
print('  Inst', {k: round(ip[k][1], 4) for k in ('U', 'V', 'W', 'X', 'Y', 'SH/L', 'Zero')})

x = hist.getdata('X'); yo = hist.getdata('Yobs'); yc = hist.getdata('Ycalc'); bg = hist.getdata('Background')
np.savetxt(os.path.join(OUT, f'{TAG}_prof.csv'), np.c_[x, yo, yc, bg], delimiter=',',
           header='2theta,yobs,ycalc,bkg', comments='')
gpx.save()
