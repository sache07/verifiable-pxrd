"""Write the final deliverables into the workspace root."""
import os, re, json, shutil
import numpy as np

WS = '<ATTEMPT_WORKSPACE>'
OUT = os.path.join(WS, 'work/out')
TAG = 'final_run'

r = json.load(open(os.path.join(OUT, f'{TAG}_result.json')))

# ---- cell esds from the GSAS-II .lst -----------------------------------
cellsig = {}
lines = open(os.path.join(OUT, f'{TAG}.lst')).read().splitlines()
cur = None
for i, ln in enumerate(lines):
    m = re.match(r'\s*Result for phase:\s*(\S+)', ln)
    if m:
        cur = m.group(1)
    if ln.strip().startswith('New unit cell:') and cur:
        vals = [float(v) for v in lines[i + 2].split(':')[1].split()]
        raw = lines[i + 3].split(':')[1]
        # fixed-width esd row aligned with the values row
        esds = []
        valrow = lines[i + 2].split(':')[1]
        for mm in re.finditer(r'\S+', valrow):
            seg = raw[mm.start():mm.end() + 1].strip()
            esds.append(float(seg) if seg else None)
        cellsig[cur] = dict(zip(['a', 'b', 'c', 'alpha', 'beta', 'gamma', 'volume'],
                                zip(vals, esds)))

META = {
    'ZnWO4': dict(mineral='sanmartinite', sg='P2/c (No. 13)',
                  src='COD 1520641 (Dahlborg & Asberg Svensson, Acta Chem. Scand. 53 (1999) 1103)'),
    'WO3': dict(mineral='gamma-WO3 (monoclinic room-temperature WO3)', sg='P2_1/c (No. 14)',
                src='COD 2311041 (Loopstra & Boldrini, Acta Cryst. 21 (1966) 158; neutron)'),
    'ZnO': dict(mineral='zincite', sg='P6_3mc (No. 186)',
                src='COD 9004178 (wurtzite-type ZnO)'),
}


def esd_str(v, s, nd):
    if s is None or s == 0:
        return f'{v:.{nd}f}'
    # express esd in units of the last printed digit
    k = int(round(s * 10 ** nd))
    if k == 0:
        k = 1
    return f'{v:.{nd}f}({k})'


cifs = {}
for name in r['phases']:
    src = os.path.join(OUT, f'{TAG}_{name}.cif')
    txt = open(src).read()
    txt = txt.replace('data_' + TAG, f'data_{name}_Rietveld')
    cs = cellsig.get(name, {})
    for key, tag, nd in [('a', '_cell_length_a', 5), ('b', '_cell_length_b', 5),
                         ('c', '_cell_length_c', 5), ('alpha', '_cell_angle_alpha', 4),
                         ('beta', '_cell_angle_beta', 4), ('gamma', '_cell_angle_gamma', 4),
                         ('volume', '_cell_volume', 3)]:
        if key in cs:
            v, s = cs[key]
            txt = re.sub(rf'^{tag}\s+\S+$', f'{tag}  {esd_str(v, s, nd)}', txt,
                         flags=re.M)
    wfv, wfs = r['wf_from_lst'][name]
    head = f"""#  Rietveld-refined structure for {name} ({META[name]['mineral']})
#  Sample: WO3 + ZnO reacted at 900 C; three-phase Rietveld refinement of
#  Cu K-alpha1/K-alpha2 laboratory powder data (10-100 deg 2-theta).
#  Starting model: {META[name]['src']}
#  Refined in GSAS-II (see final.gpx).  Overall fit: Rwp = {r['Rwp_percent']:.2f} %,
#  Rp = {r['Rp_percent']:.2f} %, GOF = {r['GOF']:.3f}, {r['Nobs']} points, {r['Nvars']} variables.
#  Weight fraction of this phase (normalised over the 3 modelled crystalline
#  phases) = {wfv*100:.2f}({wfs*100*100:.0f}) %   [esd in units of the last digit]
#  Phase Bragg residual R(F) = {r['phases'][name]['Rf_percent']:.2f} % on {r['phases'][name]['nref']} reflections.
#  Isotropic displacement parameters were constrained to a single value per
#  phase; for {name} they are {'refined' if name != 'ZnWO4' else 'fixed at 0.0050 A^2 (see report.md)'}.
"""
    dst = os.path.join(WS, f'{name}.cif')
    open(dst, 'w').write(head + txt)
    cifs[name] = f'{name}.cif'
    print('wrote', dst)

# ---- fit.csv -----------------------------------------------------------
d = np.genfromtxt(os.path.join(OUT, f'{TAG}_prof.csv'), delimiter=',', names=True)
np.savetxt(os.path.join(WS, 'fit.csv'),
           np.c_[d['2theta'], d['yobs'], d['ycalc'], d['yobs'] - d['ycalc'], d['bkg']],
           delimiter=',', fmt=['%.6f', '%.3f', '%.4f', '%.4f', '%.4f'],
           header='two_theta_deg,y_obs,y_calc,y_diff,y_background', comments='')
print('wrote fit.csv', d['2theta'].size, 'points')

# ---- final.gpx ---------------------------------------------------------
shutil.copyfile(os.path.join(OUT, f'{TAG}.gpx'), os.path.join(WS, 'final.gpx'))

# ---- result.json -------------------------------------------------------
cmp_noZnO = json.load(open(os.path.join(OUT, 'cmp_noZnO_result.json')))
order = ['ZnWO4', 'WO3', 'ZnO']
res = {
    'analysis': {
        'input_pattern': 'inputs/pattern.csv',
        'radiation': 'Cu K-alpha1 + K-alpha2 (1.540598 / 1.544426 A, I2/I1 = 0.5)',
        'two_theta_range_deg': [float(d['2theta'].min()), float(d['2theta'].max())],
        'method': 'Rietveld refinement, GSAS-II (scriptable); see final.gpx and report.md',
        'number_of_crystalline_phases': 3,
        'product_composition': 'ZnWO4 (major) with unreacted WO3 and ZnO',
    },
    'phases': [
        {
            'name': n,
            'formula': {'ZnWO4': 'ZnWO4', 'WO3': 'WO3', 'ZnO': 'ZnO'}[n],
            'mineral_name': META[n]['mineral'],
            'space_group': META[n]['sg'],
            'cif': cifs[n],
            'weight_fraction': round(r['wf_from_lst'][n][0], 4),
            'weight_fraction_esd': round(r['wf_from_lst'][n][1], 4),
            'weight_fraction_percent': round(r['wf_from_lst'][n][0] * 100, 2),
            'lattice_parameters': {k: round(v, 5) for k, v in r['phases'][n]['cell'].items()},
            'bragg_R_F_percent': round(r['phases'][n]['Rf_percent'], 3),
            'bragg_R_F2_percent': round(r['phases'][n]['Rf2_percent'], 3),
            'n_reflections': r['phases'][n]['nref'],
            'apparent_crystallite_size_um': round(r['phases'][n]['size_um'], 4),
            'starting_model': META[n]['src'],
        } for n in order
    ],
    'weight_fractions_normalised_over_modelled_crystalline_phases': {
        n: round(r['wf_from_lst'][n][0], 4) for n in order},
    'fit_statistics': {
        'Rwp_percent': round(r['Rwp_percent'], 3),
        'Rp_percent': round(r['Rp_percent'], 3),
        'R_Bragg_percent': round(r['Rb_percent'], 3),
        'goodness_of_fit': round(r['GOF'], 3),
        'reduced_chi_squared': round(r['GOF'] ** 2, 3),
        'chi_squared': round(r['chi2'], 2),
        'n_observations': r['Nobs'],
        'n_refined_parameters': r['Nvars'],
    },
    'model_checks': {
        'Rwp_ZnWO4_only_percent': round(json.load(open(os.path.join(OUT,'cmp_ZnWO4only_result.json')))['Rwp_percent'], 2),
        'Rwp_ZnWO4_plus_WO3_percent': round(cmp_noZnO['Rwp_percent'], 2),
        'Rwp_all_three_phases_percent': round(r['Rwp_percent'], 2),
        'note': ('Rwp values for the 1- and 2-phase models were obtained with the same '
                 'refinement protocol; both WO3 and ZnO are required by the data.'),
    },
    'uncertainty': {
        'weight_fraction_esd_source': 'GSAS-II covariance matrix (statistical only)',
        'estimated_systematic_uncertainty_wt_percent': {'ZnWO4': 1.0, 'WO3': 1.0, 'ZnO': 0.3},
        'systematic_uncertainty_basis': (
            'spread of the refined weight fractions over four alternative treatments of the '
            'isotropic displacement parameters / surface-roughness correction, which are '
            'strongly correlated with the angular intensity distribution'),
        'amorphous_or_unmodelled_content': 'not quantified - no internal standard was available; '
                                           'fractions are normalised over the three modelled crystalline phases',
    },
    'files': {'fit_profile': 'fit.csv', 'gsas2_project': 'final.gpx',
              'report': 'report.md',
              'cifs': {n: cifs[n] for n in order}},
}
json.dump(res, open(os.path.join(WS, 'result.json'), 'w'), indent=2)
print(json.dumps(res['weight_fractions_normalised_over_modelled_crystalline_phases'], indent=1))
print('sum', sum(res['weight_fractions_normalised_over_modelled_crystalline_phases'].values()))
print('DONE')
