import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

f = sys.argv[1]; out = sys.argv[2]
rngs = [(float(a), float(b)) for a, b in (s.split(':') for s in sys.argv[3:])]
d = np.genfromtxt(f, delimiter=',', names=True)
cols = d.dtype.names
x = d[cols[0]]; yo = d[cols[1]]; yc = d[cols[2]]
fig, axes = plt.subplots(len(rngs), 1, figsize=(11, 3.2 * len(rngs)))
if len(rngs) == 1:
    axes = [axes]
for (a, b), ax in zip(rngs, axes):
    m = (x >= a) & (x <= b)
    ax.plot(x[m], yo[m], 'k.-', ms=3, lw=0.4, label='obs')
    ax.plot(x[m], yc[m], 'r-', lw=1.0, label='calc')
    ax.plot(x[m], yo[m] - yc[m], 'b-', lw=0.7, label='diff')
    ax.axhline(0, color='0.7', lw=0.5)
    ax.legend(fontsize=7); ax.set_xlim(a, b); ax.grid(alpha=0.3)
plt.tight_layout(); plt.savefig(out, dpi=100); print('saved', out)
