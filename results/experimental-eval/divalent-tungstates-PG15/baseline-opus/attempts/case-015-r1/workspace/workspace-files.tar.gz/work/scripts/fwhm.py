import numpy as np
from scipy.optimize import curve_fit

d = np.loadtxt('<ATTEMPT_WORKSPACE>/inputs/pattern.csv',
               delimiter=',', skiprows=1)
x, y = d[:, 0], d[:, 1]


def pv(t, a, c, f, eta, b0, b1):
    s = f / 2
    g = np.exp(-4 * np.log(2) * ((t - c) / f) ** 2)
    l = 1 / (1 + 4 * ((t - c) / f) ** 2)
    return a * (eta * l + (1 - eta) * g) + b0 + b1 * (t - c)


# isolated-ish single reflections
for c0, lo, hi in [(18.98, 18.5, 19.5), (36.50, 36.0, 37.0), (38.50, 38.1, 38.9),
                   (41.39, 41.0, 41.8), (48.90, 48.6, 49.3), (51.86, 51.4, 52.3),
                   (68.38, 68.0, 68.8), (81.2, 80.8, 81.7), (99.15, 98.6, 99.7)]:
    m = (x > lo) & (x < hi)
    try:
        p, _ = curve_fit(pv, x[m], y[m], p0=[y[m].max() - y[m].min(), c0, 0.25, 0.5,
                                             y[m].min(), 0], maxfev=20000)
        print(f"2th={p[1]:8.3f} FWHM={abs(p[2]):6.3f} eta={p[3]:5.2f} amp={p[0]:8.0f}")
    except Exception as e:
        print(c0, 'fail', e)
