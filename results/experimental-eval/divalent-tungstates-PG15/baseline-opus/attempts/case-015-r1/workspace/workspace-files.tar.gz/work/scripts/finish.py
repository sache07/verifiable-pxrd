"""Continue from prod6.gpx: re-enable ZnWO4 coordinate refinement (Uiso kept fixed),
polish, and export the final deliverable files."""
import os, sys, json, re, shutil
import numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
import GSASIIscriptable as G2sc

WS = '<ATTEMPT_WORKSPACE>'
OUT = os.path.join(WS, 'work/out')
SRC, TAG = 'prod6', 'final_run'
COORD_PHASES = ['ZnWO4']

for suff in ('.gpx',) + tuple(f'.bak{i}.gpx' for i in range(8)):
    f = os.path.join(OUT, TAG + suff)
    if os.path.exists(f):
        os.remove(f)
shutil.copyfile(os.path.join(OUT, f'{SRC}.gpx'), os.path.join(OUT, f'{TAG}.gpx'))

gpx = G2sc.G2Project(os.path.join(OUT, f'{TAG}.gpx'))
hist = gpx.histograms()[0]
phases = gpx.phases()


def hap(ph):
    return ph.data['Histograms'][list(ph.data['Histograms'])[0]]


ip = hist.data['Instrument Parameters'][0]
sp = hist.data['Sample Parameters']
trace = []


def step(label):
    gpx.refine()
    r = hist.get_wR()
    trace.append([label, round(r, 4)])
    print(f'  {label:28s} Rwp={r:.3f}', flush=True)


for ph in phases:
    if ph.name in COORD_PHASES:
        ph.set_refinements({'Atoms': {a.label: 'X' for a in ph.atoms()}})
step('coords(ZnWO4), Uiso fixed')
step('converge')

from GSASII import GSASIImath as G2mth
masses = {ph.name: (ph.data['General'].get('Mass') or G2mth.getMass(ph.data['General']))
          for ph in phases}
tot = sum(masses[ph.name] * hap(ph)['Scale'][0] for ph in phases)
wf = {ph.name: masses[ph.name] * hap(ph)['Scale'][0] / tot for ph in phases}

sig, cur = {}, None
for line in open(os.path.join(OUT, f'{TAG}.lst')):
    m = re.match(r'\s*Phase:\s*(\S+)\s+in histogram', line)
    if m:
        cur = m.group(1)
    m = re.search(r'Weight fraction\s*:\s*([\d.eE+-]+),\s*sig\s*([\d.eE+-]+)', line)
    if m and cur:
        sig[cur] = (float(m.group(1)), float(m.group(2)))

Rvals = gpx.data['Covariance']['data']['Rvals']
res = hist.residuals
out = {
    'tag': TAG, 'Rwp_percent': Rvals['Rwp'], 'GOF': Rvals['GOF'], 'chi2': Rvals['chisq'],
    'Nobs': Rvals['Nobs'], 'Nvars': Rvals['Nvars'],
    'Rp_percent': res.get('R'), 'Rb_percent': res.get('Rb'), 'wRb_percent': res.get('wRb'),
    'weight_fractions': {k: round(v, 5) for k, v in wf.items()},
    'wf_from_lst': sig, 'trace': trace,
    'sample': {'Shift_um': sp['Shift'][0], 'SurfRoughA': sp['SurfRoughA'][0],
               'SurfRoughB': sp['SurfRoughB'][0], 'hist_scale': sp['Scale'][0]},
    'inst': {k: ip[k][1] for k in ('U', 'V', 'W', 'X', 'Y', 'SH/L', 'Zero',
                                   'Lam1', 'Lam2', 'I(L2)/I(L1)', 'Polariz.')},
    'phases': {},
}
for ph in phases:
    h = hap(ph)
    out['phases'][ph.name] = {
        'spacegroup': ph.data['General']['SGData']['SpGrp'],
        'cell': {k: round(v, 6) for k, v in ph.get_cell().items()},
        'phase_scale': h['Scale'][0], 'size_um': h['Size'][1][0],
        'Rf_percent': res.get(f'{ph.id}:0:Rf'), 'Rf2_percent': res.get(f'{ph.id}:0:Rf^2'),
        'nref': res.get(f'{ph.id}:0:Nref'),
        'atoms': [{'label': a.label, 'type': a.type,
                   'xyz': [round(c, 5) for c in a.coordinates],
                   'Uiso': round(a.data[a.cia + 1], 5), 'occ': a.occupancy}
                  for a in ph.atoms()],
    }
print('RESULT ' + json.dumps(out, indent=1))
json.dump(out, open(os.path.join(OUT, f'{TAG}_result.json'), 'w'), indent=2)

x = hist.getdata('X'); yo = hist.getdata('Yobs'); yc = hist.getdata('Ycalc')
bg = hist.getdata('Background')
np.savetxt(os.path.join(OUT, f'{TAG}_prof.csv'), np.c_[x, yo, yc, bg, yo - yc], delimiter=',',
           header='2theta,yobs,ycalc,bkg,diff', comments='')
gpx.save()
for ph in phases:
    ph.export_CIF(os.path.join(OUT, f'{TAG}_{ph.name}.cif'))
print('DONE')
