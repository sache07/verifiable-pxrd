import os, sys, json
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
import GSASIIscriptable as G2sc

OUT = '<ATTEMPT_WORKSPACE>/work/out'
gpx_path = os.path.join(OUT, 'step1.gpx')
if os.path.exists(gpx_path):
    os.remove(gpx_path)
gpx = G2sc.G2Project(newgpx=gpx_path)
hist = gpx.add_powder_histogram(os.path.join(OUT, 'pattern.xye'),
                                os.path.join(OUT, 'inst.instprm'),
                                fmthint='Topas')
ph = gpx.add_phase(os.path.join(OUT, '1520641.cif'), phasename='ZnWO4', histograms=[hist])

hist.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True}})
gpx.refine()
print('Rwp after bkg', hist.get_wR())

# sample displacement + zero + cell
hist.set_refinements({'Sample Parameters': ['Shift', 'Scale']})
gpx.refine()
print('Rwp after shift', hist.get_wR())
ph.set_refinements({'Cell': True})
gpx.refine()
print('Rwp after cell', hist.get_wR())
hist.set_refinements({'Instrument Parameters': ['U', 'V', 'W']})
gpx.refine()
print('Rwp after UVW', hist.get_wR())
print(hist.getHistEntryValue(['Instrument Parameters'])[0])
print('cell', ph.get_cell())
