"""Main staged refinement: 2 phases, instrumental Gaussian + per-phase broadening."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build import new_project, wt_fractions

ATOMS = sys.argv[1] if len(sys.argv) > 1 else 'niwo4'   # none|niwo4|all
out = sys.argv[2] if len(sys.argv) > 2 else 'r5.gpx'

gpx, h, phs = new_project(out, [('NiWO4', 'start_NiWO4.cif'), ('WO3', 'start_WO3.cif')])
p1, p2 = phs
ip = h.data['Instrument Parameters'][0]
ip['Y'][1] = 0.0

def step(label, *d):
    gpx.do_refinements(list(d) if d else [{}])
    print(f'{label:26s} Rwp={h.get_wR():.4f}', flush=True)

step('bkg+scale')
step('cell', {'set': {'Cell': True}})
step('displacement', {'set': {'Sample Parameters': ['Shift']}})
step('UVW+X', {'set': {'Instrument Parameters': ['U', 'V', 'W', 'X']}})
for p in phs:
    p.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True},
                           'Size': {'type': 'isotropic', 'refine': True}})
step('+size/mustrain')
if ATOMS in ('niwo4', 'all'):
    p1.set_HAP_refinements({})
    step('NiWO4 atoms', {'set': {'Atoms': {'all': 'X'}}, 'phases': [p1]})
if ATOMS == 'all':
    step('WO3 atoms', {'set': {'Atoms': {'all': 'X'}}, 'phases': [p2]})
step('all together')
gpx.save()

print('Shift', round(h.data['Sample Parameters']['Shift'][0], 1))
print('UVWXY', [round(ip[k][1], 3) for k in 'UVWXY'])
for p in phs:
    hp = p.data['Histograms'][h.name]
    print(p.name, 'mu', round(hp['Mustrain'][1][0], 1), 'size', round(hp['Size'][1][0], 3),
          {k: round(v, 5) for k, v in p.get_cell().items()})
    for a in p.atoms():
        print('   ', a.label, a.type, [round(c, 4) for c in a.coordinates], round(a.uiso, 4))
print('wt%', {k: round(100 * v, 2) for k, v in wt_fractions(gpx, h).items()})
