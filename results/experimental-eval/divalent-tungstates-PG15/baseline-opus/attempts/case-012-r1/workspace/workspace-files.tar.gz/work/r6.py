"""Refinement with effective instrumental profile tied to the major phase.

NiWO4 (major) keeps the default isotropic microstrain so that the refined
instrumental U,V,W,X(,Y) describe the NiWO4 peak shape; the minor WO3 phase
gets its own microstrain term on top of that.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build import new_project, wt_fractions

freeY = sys.argv[1] == 'Y'
ATOMS = sys.argv[2]            # none|niwo4|all
out = sys.argv[3]

gpx, h, phs = new_project(out, [('NiWO4', 'start_NiWO4.cif'), ('WO3', 'start_WO3.cif')])
p1, p2 = phs
ip = h.data['Instrument Parameters'][0]
if not freeY:
    ip['Y'][1] = 0.0
ivars = ['U', 'V', 'W', 'X'] + (['Y'] if freeY else [])

def step(label, *d):
    gpx.do_refinements(list(d) if d else [{}])
    print(f'{label:26s} Rwp={h.get_wR():.4f}', flush=True)

step('bkg+scale')
step('cell', {'set': {'Cell': True}})
step('displacement', {'set': {'Sample Parameters': ['Shift']}})
step('inst profile', {'set': {'Instrument Parameters': ivars}})
p2.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}})
step('WO3 mustrain')
if ATOMS in ('niwo4', 'all'):
    step('NiWO4 atom xyz', {'set': {'Atoms': {'all': 'X'}}, 'phases': [p1]})
if ATOMS == 'all':
    step('WO3 atom xyz', {'set': {'Atoms': {'all': 'X'}}, 'phases': [p2]})
step('converge')
gpx.save()

print('Shift', round(h.data['Sample Parameters']['Shift'][0], 1))
print('UVWXY', [round(ip[k][1], 3) for k in 'UVWXY'])
for p in phs:
    hp = p.data['Histograms'][h.name]
    print(p.name, 'mu', round(hp['Mustrain'][1][0], 1),
          {k: round(v, 5) for k, v in p.get_cell().items()})
    for a in p.atoms():
        print('   ', a.label, a.type, [round(c, 4) for c in a.coordinates], round(a.uiso, 4))
print('wt%', {k: round(100 * v, 2) for k, v in wt_fractions(gpx, h).items()})
