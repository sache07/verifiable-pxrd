import os, sys
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc
os.chdir(os.path.dirname(os.path.abspath(__file__)))
gpx = G2sc.G2Project(sys.argv[1])
pre = sys.argv[2]
for p in gpx.phases():
    p.export_CIF(f'{pre}_{p.name}.cif')
    print('wrote', f'{pre}_{p.name}.cif')
