import os, sys
import numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc
W = os.path.dirname(os.path.abspath(__file__)); os.chdir(W)
gpx = G2sc.G2Project(sys.argv[1])
h = gpx.histograms()[0]
x = np.array(h.data['data'][1][0]); yo = np.array(h.data['data'][1][1])
yc = np.array(h.data['data'][1][3]); bg = np.array(h.data['data'][1][4])
msk = (x > 10.5) & (x < 99.9)
x, yo, yc, bg = x[msk], yo[msk], yc[msk], bg[msk]
d = yo - yc
sig = np.sqrt(np.maximum(yo, 1))
from scipy.signal import find_peaks
pk, pr = find_peaks(d / sig, prominence=3, distance=8)
print('Rwp', h.get_wR())
print('unmodelled-ish residual peaks (2th, obs, calc, diff, diff/sig):')
for i in pk:
    print(f'{x[i]:8.3f} {yo[i]:8.0f} {yc[i]:8.0f} {d[i]:8.0f} {d[i]/sig[i]:6.1f}')
