"""Final-candidate refinement with switchable extras (3rd phase, PO, Uiso, WO3 model)."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build import new_project, wt_fractions

opt = json.loads(sys.argv[1])
out = sys.argv[2]

plist = [('NiWO4', 'start_NiWO4.cif'), ('WO3', opt.get('wo3', 'start_WO3.cif'))]
if opt.get('third'):
    plist.append((opt['third'][0], opt['third'][1]))
gpx, h, phs = new_project(out, plist)
p1, p2 = phs[0], phs[1]
ip = h.data['Instrument Parameters'][0]
ivars = ['U', 'V', 'W', 'X', 'Y', 'SH/L']

def step(label, *d):
    gpx.do_refinements(list(d) if d else [{}])
    print(f'{label:26s} Rwp={h.get_wR():.4f}', flush=True)

step('bkg+scale')
step('cell', {'set': {'Cell': True}})
step('displacement', {'set': {'Sample Parameters': ['Shift']}})
step('inst profile', {'set': {'Instrument Parameters': ivars}})
for p in phs[1:]:
    p.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}})
step('mustrain(minor)')
step('NiWO4 atom xyz', {'set': {'Atoms': {'all': 'X'}}, 'phases': [p1]})
if opt.get('wo3atoms'):
    step('WO3 atom xyz', {'set': {'Atoms': {'all': 'X'}}, 'phases': [p2]})
if opt.get('uiso'):
    step('Uiso', {'set': {'Atoms': {'all': 'U'}}, 'phases': [p1]})
if opt.get('po'):
    for p in phs:
        p.set_HAP_refinements({'Pref.Ori.': ['MD', 1.0, True, list(opt['po']), 0, {}]})
    step('pref.ori. MD ' + str(opt['po']))
step('converge')
gpx.save()
print('Shift', round(h.data['Sample Parameters']['Shift'][0], 1), 'SH/L', round(ip['SH/L'][1], 5))
print('UVWXY', [round(ip[k][1], 3) for k in 'UVWXY'])
for p in gpx.phases():
    hp = p.data['Histograms'][h.name]
    print(p.name, 'scale', hp['Scale'][0], 'mu', round(hp['Mustrain'][1][0], 1),
          'PO', hp['Pref.Ori.'][1] if hp['Pref.Ori.'][0] == 'MD' else None,
          {k: round(v, 5) for k, v in p.get_cell().items()})
    for a in p.atoms():
        print('   ', a.label, a.type, [round(c, 4) for c in a.coordinates], round(a.uiso, 4))
print('wt%', {k: round(100 * v, 2) for k, v in wt_fractions(gpx, h).items()})
