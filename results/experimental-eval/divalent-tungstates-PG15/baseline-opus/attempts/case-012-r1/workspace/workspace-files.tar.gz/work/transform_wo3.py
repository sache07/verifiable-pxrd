"""Re-express Loopstra's gamma-WO3 (P2_1/c, beta=136.06) in the usual P2_1/n cell.

a' = a + c, b' = b, c' = -a   (det = +1, volume preserved)
"""
import numpy as np
import itertools

# Loopstra & Boldrini, Acta Cryst 1966 (COD 2311041)
A, B, C, BETA = 7.688, 7.539, 10.515, 136.06
OPS_C = [((1, 0, 0, 0), (0, 1, 0, 0), (0, 0, 1, 0)),
         ((-1, 0, 0, 0), (0, 1, 0, 0.5), (0, 0, -1, 0.5)),
         ((-1, 0, 0, 0), (0, -1, 0, 0), (0, 0, -1, 0)),
         ((1, 0, 0, 0), (0, -1, 0, -0.5), (0, 0, 1, -0.5))]
ATOMS = [('O6', 'O', 0.714, 0.487, 0.721), ('O2', 'O', 0.225, 0.474, 0.007),
         ('W1', 'W', 0.028, 0.037, 0.746), ('O5', 'O', 0.716, 0.043, 0.708),
         ('O3', 'O', 0.998, 0.262, 0.712), ('O1', 'O', 0.206, 0.042, 0.995),
         ('W2', 'W', 0.534, 0.023, 0.750), ('O4', 'O', 0.519, 0.259, 0.789)]


def apply(op, x):
    return np.array([sum(op[i][j] * x[j] for j in range(3)) + op[i][3] for i in range(3)])


# full cell contents
full = []
for lbl, el, *x in ATOMS:
    for op in OPS_C:
        y = apply(op, np.array(x)) % 1.0
        if not any(e == el and np.allclose(np.abs(y - z) % 1.0, 0, atol=1e-3)
                   for e, z in full):
            full.append((el, y))
print('atoms in cell:', len(full))

lat = np.array([[A, 0, 0], [0, B, 0],
                [C * np.cos(np.radians(BETA)), 0, C * np.sin(np.radians(BETA))]])
M = np.array([[1, 0, 1], [0, 1, 0], [-1, 0, 0]], dtype=float)
latn = M @ lat
an, bn, cn = [np.linalg.norm(v) for v in latn]
beta_n = np.degrees(np.arccos(np.dot(latn[0], latn[2]) / (an * cn)))
alpha_n = np.degrees(np.arccos(np.dot(latn[1], latn[2]) / (bn * cn)))
gamma_n = np.degrees(np.arccos(np.dot(latn[0], latn[1]) / (an * bn)))
print(f'new cell a={an:.4f} b={bn:.4f} c={cn:.4f} alpha={alpha_n:.3f} '
      f'beta={beta_n:.4f} gamma={gamma_n:.3f} V={abs(np.linalg.det(latn)):.3f}')

Minv = np.linalg.inv(M)
newpos = [(el, (x @ Minv) % 1.0) for el, x in full]

# P2_1/n operations
OPS_N = [((1, 0, 0, 0), (0, 1, 0, 0), (0, 0, 1, 0)),
         ((-1, 0, 0, 0.5), (0, 1, 0, 0.5), (0, 0, -1, 0.5)),
         ((-1, 0, 0, 0), (0, -1, 0, 0), (0, 0, -1, 0)),
         ((1, 0, 0, 0.5), (0, -1, 0, 0.5), (0, 0, 1, 0.5))]

# verify the transformed structure is invariant under P2_1/n and build orbits
remaining = list(range(len(newpos)))
asym = []
while remaining:
    i = remaining[0]
    el, x = newpos[i]
    orbit = []
    for op in OPS_N:
        y = apply(op, x) % 1.0
        for j in remaining:
            e2, z = newpos[j]
            d = (y - z + 0.5) % 1.0 - 0.5
            if e2 == el and np.linalg.norm(d) < 0.02:
                orbit.append(j)
                break
        else:
            raise SystemExit(f'P2_1/n not satisfied for atom {i} op {op}: {y}')
    orbit = sorted(set(orbit))
    asym.append((el, x, len(orbit)))
    for j in orbit:
        remaining.remove(j)
print('asymmetric unit:')
for el, x, n in asym:
    print(f'  {el} {x[0]:.4f} {x[1]:.4f} {x[2]:.4f}  mult={n}')

uiso = {'W': 0.004, 'O': 0.010}
cnt = {}
lines = ["data_WO3_gamma_P21n",
         "_chemical_formula_sum            'O3 W'",
         "_chemical_name_mineral           'gamma-WO3 (tungstite-type), Loopstra & Boldrini 1966, P2_1/n setting'",
         "_symmetry_space_group_name_H-M   'P 1 21/n 1'",
         "_symmetry_Int_Tables_number      14",
         f"_cell_length_a                   {an:.4f}",
         f"_cell_length_b                   {bn:.4f}",
         f"_cell_length_c                   {cn:.4f}",
         "_cell_angle_alpha                90.0",
         f"_cell_angle_beta                 {beta_n:.4f}",
         "_cell_angle_gamma                90.0",
         "_cell_formula_units_Z            8",
         "loop_", "_symmetry_equiv_pos_as_xyz",
         " 'x,y,z'", " '-x+1/2,y+1/2,-z+1/2'", " '-x,-y,-z'", " 'x+1/2,-y+1/2,z+1/2'",
         "loop_", "_atom_site_label", "_atom_site_type_symbol",
         "_atom_site_fract_x", "_atom_site_fract_y", "_atom_site_fract_z",
         "_atom_site_occupancy", "_atom_site_U_iso_or_equiv"]
for el, x, n in asym:
    cnt[el] = cnt.get(el, 0) + 1
    lines.append(f'{el}{cnt[el]:<3} {el:2s} {x[0]:.5f} {x[1]:.5f} {x[2]:.5f} 1.0 {uiso[el]}')
open('start_WO3n.cif', 'w').write('\n'.join(lines) + '\n')
print('wrote start_WO3n.cif')
