"""Upper-bound test for unreacted NiO on top of the converged 2-phase model."""
import os, sys, shutil
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build import wt_fractions
os.chdir(os.path.dirname(os.path.abspath(__file__)))

src, dst, cif, name = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
shutil.copy(src, dst)
gpx = G2sc.G2Project(dst)
h = gpx.histograms()[0]
p3 = gpx.add_phase(cif, phasename=name, histograms=[h])
p3.data['Histograms'][h.name]['Scale'] = [0.05, True]
print('before Rwp', h.get_wR())
gpx.do_refinements([{}])
print('after  Rwp', h.get_wR())
for p in gpx.phases():
    print(p.name, 'scale', p.data['Histograms'][h.name]['Scale'][0])
print('wt%', {k: round(100 * v, 3) for k, v in wt_fractions(gpx, h).items()})
cov = gpx.data['Covariance']['data']
for v, s in zip(cov['varyList'], cov['sig']):
    if 'Scale' in v:
        print(v, cov['variables'][cov['varyList'].index(v)], '+/-', s)
