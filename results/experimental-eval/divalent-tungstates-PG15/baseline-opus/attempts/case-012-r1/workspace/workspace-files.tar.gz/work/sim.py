import sys
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator
c=XRDCalculator(wavelength=1.540598)
for f in sys.argv[1:]:
    try:
        s=Structure.from_file(f)
    except Exception as e:
        print(f,'ERR',e); continue
    p=c.get_pattern(s,two_theta_range=(10,70))
    print('===',f, s.composition.reduced_formula, s.get_space_group_info())
    top=sorted(zip(p.x,p.y),key=lambda t:-t[1])[:18]
    print(' '.join(f'{x:.2f}({y:.0f})' for x,y in sorted(top)))
