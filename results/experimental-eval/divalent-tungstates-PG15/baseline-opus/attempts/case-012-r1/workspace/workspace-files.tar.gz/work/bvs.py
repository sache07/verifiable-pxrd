"""Bond lengths and bond-valence sums for the cation sites of a CIF."""
import sys
import numpy as np
from pymatgen.core import Structure

R0 = {('Ni', 'O'): (1.654, 0.37), ('W', 'O'): (1.917, 0.37)}

for f in sys.argv[1:]:
    s = Structure.from_file(f)
    print('==', f, s.composition.reduced_formula, s.get_space_group_info())
    done = set()
    for i, site in enumerate(s):
        el = site.specie.symbol
        if el == 'O':
            continue
        key = (el, tuple(np.round(site.frac_coords, 3)))
        nb = sorted(s.get_neighbors(site, 2.7), key=lambda n: n.nn_distance)
        nb = [n for n in nb if n.specie.symbol == 'O']
        ds = [n.nn_distance for n in nb]
        r0, b = R0[(el, 'O')]
        bv = sum(np.exp((r0 - d) / b) for d in ds)
        if el in done:
            continue
        done.add(el)
        print(f'   {el}: d(O) = ' + ', '.join(f'{d:.3f}' for d in ds) +
              f'   <d>={np.mean(ds):.3f}  BVS={bv:.2f}')
