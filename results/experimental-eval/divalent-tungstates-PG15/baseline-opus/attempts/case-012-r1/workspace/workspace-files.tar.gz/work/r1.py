import os, sys, json
import numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc

W = os.path.dirname(os.path.abspath(__file__))
os.chdir(W)

gpx = G2sc.G2Project(newgpx=os.path.join(W, 'r1.gpx'))
h = gpx.add_powder_histogram('pattern.xy', 'cu.instprm', fmthint='Topas xye')
p1 = gpx.add_phase('start_NiWO4.cif', phasename='NiWO4', histograms=[h])
p2 = gpx.add_phase('start_WO3.cif', phasename='WO3', histograms=[h])

h.set_refinements({'Limits': [10.5, 99.9]})
h.data['Background'][0][1] = True
h.data['Background'][0][2] = 8
h.data['Sample Parameters']['Shift'] = [0.0, False]

for p in (p1, p2):
    p.set_HAP_refinements({'Scale': True})

gpx.set_refinement({'set': {'Background': {'no. coeffs': 8, 'refine': True}}})
gpx.do_refinements([{}])
print('Rwp after bkg+scale', h.get_wR())

gpx.set_refinement({'set': {'Cell': True}})
gpx.do_refinements([{}])
print('Rwp after cell', h.get_wR())

gpx.do_refinements([{'set': {'Sample Parameters': ['Shift'],
                            'Instrument Parameters': ['Zero']}}])
print('Rwp after shift/zero', h.get_wR())

gpx.do_refinements([{'set': {'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']}}])
print('Rwp after profile', h.get_wR())

gpx.save()
for ph in gpx.phases():
    print(ph.name, ph.get_cell())
print(json.dumps({p.name: p.data['Histograms'][h.name]['Scale'][0] for p in gpx.phases()}))
