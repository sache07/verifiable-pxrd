"""Variant scan: axial divergence (SH/L), Lorentzian Y, per-phase microstrain."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build import new_project, wt_fractions

opt = json.loads(sys.argv[1])
out = sys.argv[2]

gpx, h, phs = new_project(out, [('NiWO4', 'start_NiWO4.cif'), ('WO3', 'start_WO3.cif')])
p1, p2 = phs
ip = h.data['Instrument Parameters'][0]
if not opt.get('Y'):
    ip['Y'][1] = 0.0
ivars = ['U', 'V', 'W', 'X'] + (['Y'] if opt.get('Y') else []) + (['SH/L'] if opt.get('shl') else [])

def step(label, *d):
    gpx.do_refinements(list(d) if d else [{}])
    print(f'{label:26s} Rwp={h.get_wR():.4f}', flush=True)

step('bkg+scale')
step('cell', {'set': {'Cell': True}})
step('displacement', {'set': {'Sample Parameters': ['Shift']}})
step('inst profile', {'set': {'Instrument Parameters': ivars}})
mu = {'type': 'isotropic', 'refine': True}
p2.set_HAP_refinements({'Mustrain': mu})
if opt.get('mu1'):
    p1.set_HAP_refinements({'Mustrain': mu})
step('mustrain')
if opt.get('atoms'):
    step('NiWO4 atom xyz', {'set': {'Atoms': {'all': 'X'}}, 'phases': [p1]})
if opt.get('uiso'):
    step('NiWO4 Uiso', {'set': {'Atoms': {'all': 'U'}}, 'phases': [p1]})
step('converge')
gpx.save()
print('Shift', round(h.data['Sample Parameters']['Shift'][0], 1),
      'SH/L', round(ip['SH/L'][1], 5))
print('UVWXY', [round(ip[k][1], 3) for k in 'UVWXY'])
for p in phs:
    hp = p.data['Histograms'][h.name]
    print(p.name, 'mu', round(hp['Mustrain'][1][0], 1),
          {k: round(v, 5) for k, v in p.get_cell().items()})
    for a in p.atoms():
        print('   ', a.label, a.type, [round(c, 4) for c in a.coordinates], round(a.uiso, 4))
print('wt%', {k: round(100 * v, 2) for k, v in wt_fractions(gpx, h).items()})
