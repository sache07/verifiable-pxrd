import os, sys, json
import numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc

W = os.path.dirname(os.path.abspath(__file__))
os.chdir(W)
NB = int(sys.argv[1]) if len(sys.argv) > 1 else 12
out = sys.argv[2] if len(sys.argv) > 2 else 'r2.gpx'

gpx = G2sc.G2Project(newgpx=os.path.join(W, out))
h = gpx.add_powder_histogram('pattern.xy', 'cu.instprm', fmthint='Topas xye')
p1 = gpx.add_phase('start_NiWO4.cif', phasename='NiWO4', histograms=[h])
p2 = gpx.add_phase('start_WO3.cif', phasename='WO3', histograms=[h])

h.set_refinements({'Limits': [10.5, 99.9]})
for p in (p1, p2):
    p.set_HAP_refinements({'Scale': True})

gpx.set_refinement({'set': {'Background': {'type': 'chebyschev-1',
                                          'no. coeffs': NB, 'refine': True}}})
gpx.do_refinements([{}])
print('Rwp bkg+scale', h.get_wR())
gpx.do_refinements([{'set': {'Cell': True}},
                    {'set': {'Sample Parameters': ['Shift'],
                             'Instrument Parameters': ['Zero']}},
                    {'set': {'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']}}])
print('Rwp after cell/shift/profile', h.get_wR())
gpx.save()
for ph in gpx.phases():
    print(ph.name, {k: round(v, 5) for k, v in ph.get_cell().items()})
