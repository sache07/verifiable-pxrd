"""Export deliverables from a converged GSAS-II project."""
import os, sys, json, shutil
import numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc

WORK = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.abspath(sys.argv[2])
os.chdir(WORK)
gpx = G2sc.G2Project(sys.argv[1])
h = gpx.histograms()[0]
hname = h.name

# ---------- weight fractions (GSAS-II convention: w_i = scale_i*mass_i / sum) -------
mass = {p.name: p.data['General']['Mass'] for p in gpx.phases()}
scale = {p.name: p.data['Histograms'][hname]['Scale'][0] for p in gpx.phases()}
pId = {p.name: p.data['pId'] for p in gpx.phases()}
wsum = sum(mass[k] * scale[k] for k in mass)
wt = {k: mass[k] * scale[k] / wsum for k in mass}

cov = gpx.data['Covariance']['data']
varyList = list(cov['varyList'])
covM = np.array(cov['covMatrix'])
sig = {}
for name in mass:
    A = np.zeros(len(varyList))
    for i, v in enumerate(varyList):
        if not v.endswith(':Scale') or v.startswith(':'):
            continue
        pi = int(v.split(':')[0])
        src = [k for k in mass if pId[k] == pi]
        if not src:
            continue
        k_i = src[0]
        if k_i == name:
            A[i] = mass[name] / wsum - mass[name] ** 2 * scale[name] / wsum ** 2
        else:
            A[i] = -mass[name] * mass[k_i] * scale[name] / wsum ** 2
    sig[name] = float(np.sqrt(A @ covM @ A))

# ---------------------------- profile -------------------------------------
x, yo, wgt, yc, bg = [np.array(a) for a in h.data['data'][1][:5]]
lo, hi = h.data['Limits'][1]
m = (x >= lo) & (x <= hi)
prof = np.column_stack([x[m], yo[m], yc[m], (yo - yc)[m], bg[m]])
np.savetxt(os.path.join(OUT, 'fit.csv'), prof, delimiter=',',
           header='two_theta_deg,y_obs,y_calc,y_diff,y_background', comments='',
           fmt='%.6f,%.4f,%.4f,%.4f,%.4f')

# --------------------------- fit statistics -------------------------------
res = h.data['data'][0]
yoc, ycc, wc = yo[m], yc[m], wgt[m]
Rwp = 100 * np.sqrt(np.sum(wc * (yoc - ycc) ** 2) / np.sum(wc * yoc ** 2))
Rp = 100 * np.sum(np.abs(yoc - ycc)) / np.sum(yoc)
nobs = int(m.sum())
nvar = len(varyList)
chi2 = np.sum(wc * (yoc - ycc) ** 2) / (nobs - nvar)
Rexp = Rwp / np.sqrt(chi2)
stats = {'Rwp_percent': round(float(Rwp), 3), 'Rp_percent': round(float(Rp), 3),
         'Rexp_percent': round(float(Rexp), 3), 'GOF': round(float(np.sqrt(chi2)), 3),
         'chi_squared_reduced': round(float(chi2), 3),
         'n_observations': nobs, 'n_refined_parameters': nvar,
         'two_theta_min_deg': float(lo), 'two_theta_max_deg': float(hi)}

# ------------------------------- CIFs -------------------------------------
cifs = {}
for p in gpx.phases():
    fn = f'{p.name}.cif'
    p.export_CIF(os.path.join(OUT, fn))
    cifs[p.name] = fn

# -------------------------- cells + misc ----------------------------------
info = {}
for p in gpx.phases():
    hp = p.data['Histograms'][hname]
    cell = p.get_cell()
    esd = p.get_cell_and_esd()[1]
    info[p.name] = {
        'space_group': p.data['General']['SGData']['SpGrp'],
        'cell': {k: round(v, 5) for k, v in cell.items()},
        'cell_esd': {k: round(v, 6) for k, v in esd.items()},
        'atoms': [[a.label, a.type, [round(c, 5) for c in a.coordinates],
                   round(a.uiso, 4), a.occupancy] for a in p.atoms()],
        'phase_scale': scale[p.name],
        'cell_mass_amu': mass[p.name],
        'microstrain_1e6': round(hp['Mustrain'][1][0], 1),
        'domain_size_um': round(hp['Size'][1][0], 4),
    }

ip = h.data['Instrument Parameters'][0]
json.dump({'weight_fractions': wt, 'weight_fraction_esd': sig, 'stats': stats,
           'cifs': cifs, 'phase_info': info,
           'instrument': {k: ip[k][1] for k in
                          ['Lam1', 'Lam2', 'I(L2)/I(L1)', 'Zero', 'Polariz.',
                           'U', 'V', 'W', 'X', 'Y', 'SH/L']},
           'sample': {'Shift_um': h.data['Sample Parameters']['Shift'][0],
                      'Absorption': h.data['Sample Parameters']['Absorption'][0],
                      'hist_scale': h.data['Sample Parameters']['Scale'][0]},
           'background': h.data['Background'][0][:3],
           }, open(os.path.join(WORK, 'export_summary.json'), 'w'), indent=1)
print(json.dumps({'wt': wt, 'sig': sig, 'stats': stats}, indent=1))
