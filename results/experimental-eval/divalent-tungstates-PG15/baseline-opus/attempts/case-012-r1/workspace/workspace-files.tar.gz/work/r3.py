import os, sys, json, copy
import numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc

W = os.path.dirname(os.path.abspath(__file__)); os.chdir(W)
THIRD = sys.argv[1] if len(sys.argv) > 1 else ''
out = sys.argv[2] if len(sys.argv) > 2 else 'r3.gpx'

gpx = G2sc.G2Project(newgpx=os.path.join(W, out))
h = gpx.add_powder_histogram('pattern.xy', 'cu.instprm', fmthint='Topas xye')
phs = [gpx.add_phase('start_NiWO4.cif', phasename='NiWO4', histograms=[h]),
       gpx.add_phase('start_WO3.cif', phasename='WO3', histograms=[h])]
if THIRD:
    phs.append(gpx.add_phase(THIRD, phasename='X3', histograms=[h]))

h.set_refinements({'Limits': [10.5, 99.9]})
for p in phs:
    p.set_HAP_refinements({'Scale': True})
gpx.set_refinement({'set': {'Background': {'type': 'chebyschev-1',
                                          'no. coeffs': 12, 'refine': True}}})
def step(label, *dicts):
    gpx.do_refinements(list(dicts) if dicts else [{}])
    print(f'{label:28s} Rwp={h.get_wR():.4f}')

step('bkg+scale')
step('cell', {'set': {'Cell': True}})
step('shift+zero', {'set': {'Sample Parameters': ['Shift'],
                            'Instrument Parameters': ['Zero']}})
step('profile UVWXY', {'set': {'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']}})
step('atoms XU', {'set': {'Atoms': {'all': 'XU'}}})
gpx.save()
for p in phs:
    print(p.name, {k: round(v, 5) for k, v in p.get_cell().items()},
          'scale=', p.data['Histograms'][h.name]['Scale'][0])
print('wtFrac:', {p.name: p.data['Histograms'][h.name].get('WgtFrac') for p in phs})
