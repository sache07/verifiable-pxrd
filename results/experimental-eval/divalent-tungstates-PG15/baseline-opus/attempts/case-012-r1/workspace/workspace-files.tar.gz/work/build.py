"""Staged Rietveld refinement helper for the NiO + WO3 (900 C) product."""
import os, sys
import numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc

WORK = os.path.dirname(os.path.abspath(__file__))

UISO = {'Ni': 0.006, 'W': 0.004, 'W+6': 0.004, 'O': 0.010, 'O-2': 0.010}


def new_project(name, phase_files, nbkg=12, limits=(10.5, 99.9)):
    gpx = G2sc.G2Project(newgpx=os.path.join(WORK, name))
    h = gpx.add_powder_histogram(os.path.join(WORK, 'pattern.xy'),
                                 os.path.join(WORK, 'cu.instprm'),
                                 fmthint='Topas xye')
    phs = []
    for pname, pfile in phase_files:
        p = gpx.add_phase(os.path.join(WORK, pfile), phasename=pname, histograms=[h])
        for a in p.atoms():
            a.uiso = UISO.get(a.type, 0.01)
        phs.append(p)
    h.set_refinements({'Limits': list(limits)})
    for p in phs:
        p.set_HAP_refinements({'Scale': True})
    gpx.set_refinement({'set': {'Background': {'type': 'chebyschev-1',
                                               'no. coeffs': nbkg, 'refine': True}}})
    return gpx, h, phs


def wt_fractions(gpx, h):
    """Weight fractions, same convention as GSAS-II: w_i ~ scale_i * mass_i(cell)."""
    out = {}
    for p in gpx.phases():
        out[p.name] = (p.data['Histograms'][h.name]['Scale'][0]
                       * p.data['General']['Mass'])
    tot = sum(out.values())
    return {k: v / tot for k, v in out.items()}
