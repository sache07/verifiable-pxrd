"""Test sample-displacement / zero-offset and profile parameterisation choices."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build import new_project, wt_fractions

mode = sys.argv[1]            # 'shift', 'zero', 'both'
prof = sys.argv[2]            # 'inst' (UVWXY) or 'phase' (UVW + phase broadening)
out = sys.argv[3]

gpx, h, phs = new_project(out, [('NiWO4', 'start_NiWO4.cif'), ('WO3', 'start_WO3.cif')])
ip = h.data['Instrument Parameters'][0]

def step(label, *d):
    gpx.do_refinements(list(d) if d else [{}])
    print(f'{label:26s} Rwp={h.get_wR():.4f}')

step('bkg+scale')
step('cell', {'set': {'Cell': True}})
zs = {'shift': {'Sample Parameters': ['Shift']},
      'zero': {'Instrument Parameters': ['Zero']},
      'both': {'Sample Parameters': ['Shift'], 'Instrument Parameters': ['Zero']}}[mode]
step('displacement', {'set': zs})
if prof == 'inst':
    step('UVWXY', {'set': {'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']}})
else:
    ip['X'][1] = ip['Y'][1] = 0.0
    step('UVW', {'set': {'Instrument Parameters': ['U', 'V', 'W']}})
    for p in phs:
        p.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}})
    step('+mustrain', {})
    for p in phs:
        p.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}})
    step('+size', {})
    step('UVW again', {'set': {'Instrument Parameters': ['U', 'V', 'W']}})
gpx.save()
print('Shift', h.data['Sample Parameters']['Shift'][0], 'Zero', ip['Zero'][1])
print('UVWXY', [round(ip[k][1], 3) for k in 'UVWXY'])
for p in phs:
    hp = p.data['Histograms'][h.name]
    print(p.name, 'mustrain', [round(v, 1) for v in hp['Mustrain'][1][:1]],
          'size', [round(v, 4) for v in hp['Size'][1][:1]])
print('wt%', {k: round(100 * v, 2) for k, v in wt_fractions(gpx, h).items()})
