"""Refinement variants with restricted (heavy-atom only) positional refinement."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build import new_project, wt_fractions

opt = json.loads(sys.argv[1])
out = sys.argv[2]

gpx, h, phs = new_project(out, [('NiWO4', 'start_NiWO4.cif'), ('WO3', 'start_WO3n.cif')], nbkg=opt.get('nbkg',12), limits=opt.get('limits',(10.5,99.9)))
p1, p2 = phs
ip = h.data['Instrument Parameters'][0]

if 'pola' in opt:
    ip['Polariz.'][1] = opt['pola']


def step(label, *d):
    gpx.do_refinements(list(d) if d else [{}])
    print(f'{label:26s} Rwp={h.get_wR():.4f}', flush=True)

step('bkg+scale')
step('cell', {'set': {'Cell': True}})
step('displacement', {'set': {'Sample Parameters': ['Shift']}})
ivars = ['U', 'V', 'W', 'X', 'SH/L'] + ([] if opt.get('noY') else ['Y'])
if opt.get('noY'):
    ip['Y'][1] = 0.0
step('inst profile', {'set': {'Instrument Parameters': ivars}})
if opt.get('polaref'):
    step('polarization', {'set': {'Instrument Parameters': ['Polariz.']}})
for p in ([p1, p2] if opt.get('mu1') else [p2]):
    p.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}})
step('mustrain')
if opt.get('heavy'):
    step('heavy-atom xyz',
         {'set': {'Atoms': {'Ni1': 'X', 'W1': 'X'}}, 'phases': [p1]},
         {'set': {'Atoms': {'W1': 'X', 'W2': 'X'}}, 'phases': [p2]})
if opt.get('restr'):
    rd = gpx.data.setdefault('Restraints', {'data': {}})['data']
    rd.setdefault(p1.name, {})['Bond'] = {'wtFactor': 1.0, 'Range': 1.1,
                                          'Bonds': [], 'Use': True}
    p1.clearDistRestraint()
    n1 = p1.addDistRestraint(['Ni1'], ['O1', 'O2'], 2.07, factor=1.08, ESD=0.03)
    n2 = p1.addDistRestraint(['W1'], ['O1', 'O2'], 1.95, factor=1.12, ESD=0.15)
    p1.setDistRestraintWeight(opt['restr'])
    print(f'restraints: {n1} Ni-O, {n2} W-O, weight {opt["restr"]}')
if opt.get('oxy'):
    step('O xyz (NiWO4)', {'set': {'Atoms': {'O1': 'X', 'O2': 'X'}}, 'phases': [p1]})
if opt.get('absorb'):
    step('absorption', {'set': {'Sample Parameters': ['Absorption']}})
if opt.get('uiso'):
    jobs = [{'set': {'Atoms': {'Ni1': 'XU', 'W1': 'XU'}}, 'phases': [p1]}]
    if opt.get('uiso3'):
        jobs.append({'set': {'Atoms': {'W1': 'XU', 'W2': 'XU'}}, 'phases': [p2]})
    step('Uiso heavy', *jobs)
if opt.get('po'):
    targets = phs if opt.get('po_both') else [p1]
    for p in targets:
        po = p.data['Histograms'][h.name]['Pref.Ori.']
        po[0] = 'MD'
        po[1] = 1.0
        po[2] = True
        po[3] = list(opt['po'])
    step('pref.ori ' + str(opt['po']))
step('converge')
gpx.save()
print('Shift', round(h.data['Sample Parameters']['Shift'][0], 1), 'SH/L', round(ip['SH/L'][1], 5))
print('UVWXY', [round(ip[k][1], 3) for k in 'UVWXY'])
for p in gpx.phases():
    hp = p.data['Histograms'][h.name]
    print(p.name, 'mu', round(hp['Mustrain'][1][0], 1),
          'PO', round(hp['Pref.Ori.'][1], 4),
          {k: round(v, 5) for k, v in p.get_cell().items()})
    for a in p.atoms():
        print('   ', a.label, a.type, [round(c, 4) for c in a.coordinates], round(a.uiso, 4))
print('wt%', {k: round(100 * v, 2) for k, v in wt_fractions(gpx, h).items()})
