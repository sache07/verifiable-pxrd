import os
import sys
import numpy as np
import GSASII.GSASIIscriptable as G2sc

W = "<ATTEMPT_WORKSPACE>"
WK = os.path.join(W, "work")
COD = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"

gpx = os.path.join(WK, "step2.gpx")
for f in (gpx,):
    if os.path.exists(f):
        os.remove(f)
prj = G2sc.G2Project(newgpx=gpx)
h = prj.add_powder_histogram(os.path.join(WK, "pattern.xy"),
                             os.path.join(W, "scripts", "inst.instprm"),
                             fmthint="Topas xye")
ph = prj.add_phase(os.path.join(COD, "1/52/02/1520200.cif"), phasename="MnWO4",
                   histograms=[h])
# ambient-pressure starting cell
ph.data["General"]["Cell"][1:7] = [4.8238, 5.7504, 4.9901, 90.0, 91.18, 90.0]

h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 14, "refine": True},
                   "Limits": [10.0, 100.0]})


def go(tag):
    prj.refine()
    print(f"== {tag}: Rwp = {h.get_wR():.4f}")
    sys.stdout.flush()


go("bkg+scale")
ph.set_refinements({"Cell": True})
go("+cell")
h.set_refinements({"Sample Parameters": ["Shift"]})
go("+displacement")
h.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
go("+UVW")
h.set_refinements({"Instrument Parameters": ["X", "Y"]})
go("+XY")
h.set_refinements({"Instrument Parameters": ["SH/L"]})
go("+SH/L")
ph.set_refinements({"Atoms": {"all": "XU"}})
go("+atoms")
print(ph.get_cell())
for a in ph.atoms():
    print(a.label, a.coordinates, a.uiso)
prj.save()
