"""Plot fit difference with tick marks for candidate impurity phases."""
import sys
import warnings
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator

warnings.filterwarnings("ignore")
f = np.genfromtxt(sys.argv[1], delimiter=",", names=True)
x, yo, yc, yb, dif = f["two_theta_deg"], f["y_obs"], f["y_calc"], f["y_bkg"], f["y_diff"]
cands = sys.argv[3:]
calc = XRDCalculator(wavelength=1.540598)
pats = []
for c in cands:
    s = Structure.from_file(c)
    p = calc.get_pattern(s, two_theta_range=(10, 100))
    pats.append((s.composition.reduced_formula + " " + c.split("/")[-1][:7],
                 np.array(p.x), np.array(p.y)))

segs = [(10, 40), (40, 70), (70, 100)]
fig, axes = plt.subplots(len(segs), 1, figsize=(19, 4.2 * len(segs)))
colors = plt.cm.tab10.colors
for ax, (lo, hi) in zip(axes, segs):
    m = (x >= lo) & (x <= hi)
    ax.plot(x[m], dif[m], "b-", lw=0.7)
    ax.axhline(0, color="k", lw=0.4)
    s = np.std(dif[m])
    ax.set_ylim(-4 * s, 7 * s)
    for k, (nm, px, py) in enumerate(pats):
        sel = (px >= lo) & (px <= hi) & (py > 1)
        y0 = 7 * s - (k + 1) * 0.55 * s
        ax.vlines(px[sel], y0, y0 + 0.4 * s * py[sel] / 100.0 * 3,
                  color=colors[k % 10], lw=1.0)
        ax.text(lo + 0.2, y0, nm, fontsize=7, color=colors[k % 10], va="bottom")
plt.tight_layout()
plt.savefig(sys.argv[2], dpi=110)
