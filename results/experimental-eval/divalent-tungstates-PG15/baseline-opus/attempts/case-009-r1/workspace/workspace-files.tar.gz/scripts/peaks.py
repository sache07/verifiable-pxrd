import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.signal import find_peaks

path = sys.argv[1]
out = sys.argv[2]
d = np.loadtxt(path, delimiter=",", skiprows=1)
x, y = d[:, 0], d[:, 1]
print("range", x.min(), x.max(), "step", np.median(np.diff(x)), "npts", len(x))
print("Imax", y.max(), "Imin", y.min())

# rough background via rolling minimum + smoothing
from scipy.ndimage import minimum_filter1d, uniform_filter1d
bg = minimum_filter1d(y, 201)
bg = uniform_filter1d(bg, 301)
ys = y - bg
pk, prop = find_peaks(ys, prominence=max(30, 0.01 * ys.max()), distance=5)
lam = 1.540598
print(f"{'2th':>9} {'d':>8} {'I':>9} {'Irel':>6}")
imax = ys[pk].max()
for i in pk:
    dsp = lam / (2 * np.sin(np.radians(x[i] / 2)))
    print(f"{x[i]:9.4f} {dsp:8.4f} {ys[i]:9.1f} {100*ys[i]/imax:6.1f}")

fig, axes = plt.subplots(2, 1, figsize=(16, 9))
axes[0].plot(x, y, lw=0.6)
axes[0].plot(x, bg, lw=0.6)
axes[0].set_yscale("log")
axes[1].plot(x, ys, lw=0.6)
axes[1].plot(x[pk], ys[pk], "rv", ms=3)
for i in pk:
    axes[1].annotate(f"{x[i]:.2f}", (x[i], ys[i]), fontsize=5, rotation=90)
plt.tight_layout()
plt.savefig(out, dpi=130)
