"""Index the local COD subset: list CIFs whose elements are a subset of a target set."""
import os
import re
import sys
import json

root = sys.argv[1]
allowed = set(sys.argv[2].split(","))
out = sys.argv[3]

sym_re = re.compile(r"^[A-Z][a-z]?")
rows = []
for dirpath, _, files in os.walk(root):
    for f in files:
        if not f.endswith(".cif"):
            continue
        p = os.path.join(dirpath, f)
        try:
            txt = open(p, "r", errors="ignore").read()
        except Exception:
            continue
        m = re.search(r"_chemical_formula_sum\s+'([^']*)'", txt)
        if not m:
            m = re.search(r'_chemical_formula_sum\s+"([^"]*)"', txt)
        if not m:
            m = re.search(r"_chemical_formula_sum\s+(\S+)", txt)
        if not m:
            continue
        formula = m.group(1)
        els = set()
        ok = True
        for tok in formula.split():
            mm = sym_re.match(tok)
            if not mm:
                ok = False
                break
            els.add(mm.group(0))
        if not ok or not els:
            continue
        if els <= allowed and els & (allowed - {"O"}):
            name = ""
            nm = re.search(r"_chemical_name_mineral\s+'([^']*)'", txt)
            if nm:
                name = nm.group(1)
            sg = ""
            sm = re.search(r"_symmetry_space_group_name_H-M\s+'([^']*)'", txt)
            if sm:
                sg = sm.group(1)
            rows.append({"file": p, "formula": formula, "elements": sorted(els),
                         "mineral": name, "sg": sg})
json.dump(rows, open(out, "w"), indent=1)
print(len(rows), "matches")
for r in rows:
    print(os.path.basename(r["file"]), "|", r["formula"], "|", r["sg"], "|", r["mineral"])
