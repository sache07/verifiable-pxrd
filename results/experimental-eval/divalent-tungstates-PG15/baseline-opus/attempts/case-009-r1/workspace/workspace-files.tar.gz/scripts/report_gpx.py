import sys
import numpy as np
import GSASII.GSASIIscriptable as G2sc

prj = G2sc.G2Project(sys.argv[1])
h = prj.histograms()[0]
print("Rwp", h.get_wR())
rv = prj.data["Covariance"]["data"]["Rvals"]
print({k: rv.get(k) for k in ("Rwp", "GOF", "Nobs", "Nvars", "converged", "Max shft/sig")})
h.ComputeMassFracs()
for p in prj.phases():
    print("---", p.name, p.data["General"]["SGData"]["SpGrp"])
    print("  cell", {k: round(v, 5) for k, v in p.get_cell().items()})
    hd = p.data["Histograms"][list(p.data["Histograms"])[0]]
    print("  scale", hd["Scale"], "massFrac", hd.get("massFrac"),
          "PO", hd.get("Pref.Ori.", [None])[0], hd.get("Pref.Ori.")[:5] if hd.get("Pref.Ori.") else None)
    for a in p.data["Atoms"]:
        print("  ", a[0], a[1], [round(v, 5) for v in a[3:7]], "Uiso", round(a[10], 5))
print("inst:", {k: round(h.data["Instrument Parameters"][0][k][1], 5)
                for k in ["U", "V", "W", "X", "Y", "Zero", "SH/L", "Polariz."]})
print("sample Shift:", h.data["Sample Parameters"]["Shift"])
sd = prj.data["Covariance"]["data"].get("sig")
vl = prj.data["Covariance"]["data"].get("varyList")
if vl:
    for n, s in zip(vl, sd):
        if any(t in n for t in ("::A", "Scale", "Shift", "AUiso", "dA")):
            print("   esd", n, s)
