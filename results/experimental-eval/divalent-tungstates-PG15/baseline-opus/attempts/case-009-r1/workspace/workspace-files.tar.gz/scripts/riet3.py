"""Rietveld refinement of MnWO4 with configurable corrections.

usage: riet3.py TAG OPTS   OPTS = comma list from {md,sh,rough,pol,k2,uiso,extinct}
       optional trailing args: Name=cod/path.cif extra phases
"""
import os
import sys
import numpy as np
import GSASII.GSASIIscriptable as G2sc

W = "<ATTEMPT_WORKSPACE>"
WK = os.path.join(W, "work")
COD = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"

PROF = dict(U=74.6487, V=47.3492, W=4.18714, X=21.0983, Y=-43.7906)
SHL = 0.0016829
SHIFT = -419.88
CELL = [4.830191, 5.757172, 4.996631, 90.0, 91.20843, 90.0]
U0 = {"Mn": 0.008, "W": 0.005, "O": 0.010}

tag = sys.argv[1]
opts = set(sys.argv[2].split(",")) - {""}
extras = sys.argv[3:]

gpx = os.path.join(WK, f"r3_{tag}.gpx")
if os.path.exists(gpx):
    os.remove(gpx)
prj = G2sc.G2Project(newgpx=gpx)
h = prj.add_powder_histogram(os.path.join(WK, "pattern.xy"),
                             os.path.join(W, "scripts", "inst.instprm"),
                             fmthint="Topas xye")
ph = prj.add_phase(os.path.join(COD, "1/52/02/1520200.cif"), phasename="MnWO4",
                   histograms=[h])
ph.data["General"]["Cell"][1:7] = CELL
for a in ph.data["Atoms"]:
    a[9] = "I"
    a[10] = U0.get(a[1].rstrip("+-0123456789"), 0.01)
    a[11:17] = [0.0] * 6
ip = h.data["Instrument Parameters"][0]
for k, v in PROF.items():
    ip[k][1] = v
ip["SH/L"][1] = SHL
h.data["Sample Parameters"]["Shift"][0] = SHIFT

phases = [ph]
for e in extras:
    name, path = e.split("=")
    p2 = prj.add_phase(os.path.join(COD, path), phasename=name, histograms=[h])
    phases.append(p2)

h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 14, "refine": True},
                   "Limits": [10.0, 100.0]})
prj.set_Controls("cycles", 12)


def go(t):
    prj.refine()
    print(f"== {t}: Rwp = {h.get_wR():.4f}", flush=True)


go("scale+bkg")
for p in phases:
    p.set_refinements({"Cell": True})
h.set_refinements({"Sample Parameters": ["Shift"]})
go("+cell+shift")
if "rough" in opts:
    h.data["Sample Parameters"]["SurfRoughA"][0] = 0.01
    h.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    go("+roughness")
if "pol" in opts:
    h.set_refinements({"Instrument Parameters": ["Polariz."]})
    go("+polariz")
if "k2" in opts:
    h.set_refinements({"Instrument Parameters": ["I(L2)/I(L1)"]})
    go("+Ka2 ratio")
if "md" in opts:
    ph.set_HAP_refinements({"Pref.Ori.": {"type": "MD", "MDaxis": [0, 1, 0], "refine": True}},
                           histograms=[h])
    go("+MD prefori")
if "sh" in opts:
    ph.set_HAP_refinements({"Pref.Ori.": {"type": "SH", "order": 6, "refine": True}},
                           histograms=[h])
    go("+SH prefori")
if "uiso" in opts:
    ph.set_refinements({"Atoms": {"Mn1": "U", "W1": "U"}})
    go("+MnW Uiso")
ph.set_refinements({"Atoms": {"O1": "X", "O2": "X"}})
go("+O xyz")
h.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
go("+profile")
if len(phases) > 1:
    for p in phases[1:]:
        p.set_HAP_refinements({"Scale": True}, histograms=[h])
    go("+extra scales")
go("final")
prj.save()
rv = prj.data["Covariance"]["data"]["Rvals"]
print("Rvals:", {k: rv.get(k) for k in ("Rwp", "GOF", "Nobs", "Nvars", "converged")})
h.ComputeMassFracs()
for p in phases:
    hd = p.data["Histograms"][list(p.data["Histograms"])[0]]
    print("PH", p.name, {k: round(v, 5) for k, v in p.get_cell().items()},
          "scale", hd["Scale"], "massFrac", hd.get("massFrac"))
for a in ph.data["Atoms"]:
    print("  AT", a[0], a[1], [round(v, 5) for v in a[3:7]], "Uiso", round(a[10], 5))
sp = h.data["Sample Parameters"]
print("SAMP", {k: sp[k] for k in ("Shift", "SurfRoughA", "SurfRoughB")})
print("INST", {k: round(h.data["Instrument Parameters"][0][k][1], 5)
               for k in ["U", "V", "W", "X", "Y", "SH/L", "Polariz.", "I(L2)/I(L1)"]})
