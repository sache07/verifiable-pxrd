import sys
import numpy as np
import GSASII.GSASIIscriptable as G2sc

gpx, out = sys.argv[1], sys.argv[2]
prj = G2sc.G2Project(gpx)
h = prj.histograms()[0]
d = h.data["data"][1]
x, yo, w, yc, yb = [np.asarray(v) for v in d[:5]]
np.savetxt(out, np.column_stack([x, yo, yc, yb, yo - yc]),
           header="two_theta_deg,y_obs,y_calc,y_bkg,y_diff", delimiter=",",
           comments="", fmt="%.6f")
res = h.get_wR()
print("Rwp", res)
try:
    print("GOF", h.data["data"][0].get("wR"), prj.data["Covariance"]["data"]["Rvals"])
except Exception as e:
    print("cov?", e)
for p in prj.phases():
    print(p.name, p.get_cell())
    try:
        print("  wtFrac", h.data["data"][0])
    except Exception:
        pass
