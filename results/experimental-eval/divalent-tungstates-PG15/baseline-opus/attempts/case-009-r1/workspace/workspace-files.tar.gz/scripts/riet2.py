"""Rietveld refinement of MnWO4 (+ optional extra phase) seeded with the Le Bail profile.

usage: riet2.py TAG PO_MODE [EXTRA ...]   EXTRA = Name=relative/cod/path.cif
"""
import os
import sys
import numpy as np
import GSASII.GSASIIscriptable as G2sc

W = "<ATTEMPT_WORKSPACE>"
WK = os.path.join(W, "work")
COD = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"

PROF = dict(U=74.6487, V=47.3492, W=4.18714, X=21.0983, Y=-43.7906)
SHL = 0.0016829
SHIFT = -419.88
CELL = [4.830191, 5.757172, 4.996631, 90.0, 91.20843, 90.0]
U0 = {"Mn": 0.008, "W": 0.005, "O": 0.010}

tag, po_mode = sys.argv[1], sys.argv[2]
extras = sys.argv[3:]

gpx = os.path.join(WK, f"r2_{tag}.gpx")
if os.path.exists(gpx):
    os.remove(gpx)
prj = G2sc.G2Project(newgpx=gpx)
h = prj.add_powder_histogram(os.path.join(WK, "pattern.xy"),
                             os.path.join(W, "scripts", "inst.instprm"),
                             fmthint="Topas xye")
ph = prj.add_phase(os.path.join(COD, "1/52/02/1520200.cif"), phasename="MnWO4",
                   histograms=[h])
ph.data["General"]["Cell"][1:7] = CELL
# force isotropic ADPs with sensible starting values
for a in ph.data["Atoms"]:
    a[9] = "I"
    a[10] = U0.get(a[1].rstrip("+-0123456789"), 0.01)
    a[11:17] = [0.0] * 6
ip = h.data["Instrument Parameters"][0]
for k, v in PROF.items():
    ip[k][1] = v
ip["SH/L"][1] = SHL
h.data["Sample Parameters"]["Shift"][0] = SHIFT

phases = [ph]
for e in extras:
    name, path = e.split("=")
    p2 = prj.add_phase(os.path.join(COD, path), phasename=name, histograms=[h])
    phases.append(p2)

h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 14, "refine": True},
                   "Limits": [10.0, 100.0]})
prj.set_Controls("cycles", 12)


def go(t):
    prj.refine()
    print(f"== {t}: Rwp = {h.get_wR():.4f}", flush=True)


go("scale+bkg")
for p in phases:
    p.set_refinements({"Cell": True})
h.set_refinements({"Sample Parameters": ["Shift"]})
go("+cell+shift")
# Mn/W Uiso + O coordinates (O Uiso held)
ph.set_refinements({"Atoms": {"Mn1": "U", "W1": "U"}})
go("+MnW Uiso")
ph.set_refinements({"Atoms": {"O1": "X", "O2": "X"}})
go("+O xyz")
if po_mode == "sh":
    ph.set_HAP_refinements({"Pref.Ori.": {"type": "SH", "order": 6, "refine": True}},
                           histograms=[h])
    go("+SH prefori")
elif po_mode == "md":
    ph.set_HAP_refinements({"Pref.Ori.": {"type": "MD", "MDaxis": [0, 1, 0], "refine": True}},
                           histograms=[h])
    go("+MD prefori")
h.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
go("+profile")
if len(phases) > 1:
    for p in phases[1:]:
        p.set_HAP_refinements({"Scale": True}, histograms=[h])
    go("+extra scales")
go("final")
prj.save()
rv = prj.data["Covariance"]["data"]["Rvals"]
print("Rvals:", {k: rv.get(k) for k in ("Rwp", "GOF", "Nobs", "Nvars", "converged")})
h.ComputeMassFracs()
for p in phases:
    hd = p.data["Histograms"][list(p.data["Histograms"])[0]]
    print(p.name, "cell", {k: round(v, 5) for k, v in p.get_cell().items()},
          "scale", hd["Scale"], "massFrac", hd.get("massFrac"))
for a in ph.data["Atoms"]:
    print("  ", a[0], a[1], [round(v, 5) for v in a[3:7]], "Uiso", round(a[10], 5))
