"""Add a trial impurity phase to the converged MnWO4 model and refine only its scale.

usage: trial.py BASE.gpx Name=cod/rel/path.cif
"""
import os
import shutil
import sys
import numpy as np
import GSASII.GSASIIscriptable as G2sc

W = "<ATTEMPT_WORKSPACE>"
WK = os.path.join(W, "work")
COD = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"

base = sys.argv[1]
name, path = sys.argv[2].split("=")
gpx = os.path.join(WK, f"tr_{name}.gpx")
shutil.copy(base, gpx)

prj = G2sc.G2Project(gpx)
h = prj.histograms()[0]
host = prj.phases()[0]
print(f"base Rwp = {h.get_wR():.4f}")
p2 = prj.add_phase(os.path.join(COD, path), phasename=name, histograms=[h])
hid = list(p2.data["Histograms"])[0]
p2.data["Histograms"][hid]["Scale"] = [1.0e-6, True]
# trial phase keeps the host's broadening; nothing else refined for it
prj.set_Controls("cycles", 10)
prj.refine()
print(f"with {name}: Rwp = {h.get_wR():.4f}")
h.ComputeMassFracs()
cov = prj.data["Covariance"]["data"]
esd = dict(zip(list(cov.get("varyList", [])), list(cov.get("sig", []))))
for i, p in enumerate(prj.phases()):
    hd = p.data["Histograms"][hid]
    print("PH", p.name, "scale", hd["Scale"], "esd", esd.get(f"{i}:0:Scale"),
          "massFrac", hd.get("massFrac"))
prj.save()
