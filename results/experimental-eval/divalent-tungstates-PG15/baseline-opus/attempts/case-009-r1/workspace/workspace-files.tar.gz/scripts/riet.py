"""Rietveld refinement of MnWO4 (+ optional extra phases) seeded with the
Le Bail profile parameters."""
import os
import sys
import json
import numpy as np
import GSASII.GSASIIscriptable as G2sc

W = "<ATTEMPT_WORKSPACE>"
WK = os.path.join(W, "work")
COD = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"

PROF = dict(U=74.6487, V=47.3492, W=4.18714, X=21.0983, Y=-43.7906)
SHL = 0.0016829
SHIFT = -419.88
CELL = [4.830191, 5.757172, 4.996631, 90.0, 91.20843, 90.0]

tag = sys.argv[1]
extra = sys.argv[2] if len(sys.argv) > 2 and sys.argv[2] != "-" else None
po_mode = sys.argv[3] if len(sys.argv) > 3 else "none"

gpx = os.path.join(WK, f"riet_{tag}.gpx")
if os.path.exists(gpx):
    os.remove(gpx)
prj = G2sc.G2Project(newgpx=gpx)
h = prj.add_powder_histogram(os.path.join(WK, "pattern.xy"),
                             os.path.join(W, "scripts", "inst.instprm"),
                             fmthint="Topas xye")
ph = prj.add_phase(os.path.join(COD, "1/52/02/1520200.cif"), phasename="MnWO4",
                   histograms=[h])
ph.data["General"]["Cell"][1:7] = CELL
ip = h.data["Instrument Parameters"][0]
for k, v in PROF.items():
    ip[k][1] = v
ip["SH/L"][1] = SHL
h.data["Sample Parameters"]["Shift"][0] = SHIFT

phases = [ph]
if extra:
    name, path = extra.split("=")
    p2 = prj.add_phase(os.path.join(COD, path), phasename=name, histograms=[h])
    phases.append(p2)

h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 14, "refine": True},
                   "Limits": [10.0, 100.0]})
prj.set_Controls("cycles", 12)


def go(t):
    prj.refine()
    print(f"== {t}: Rwp = {h.get_wR():.4f}", flush=True)


go("scale+bkg")
for p in phases:
    p.set_refinements({"Cell": True})
h.set_refinements({"Sample Parameters": ["Shift"]})
go("+cell+shift")
ph.set_refinements({"Atoms": {"all": "XU"}})
go("+atoms")
if po_mode == "sh":
    ph.set_HAP_refinements({"Pref.Ori.": {"type": "SH", "order": 6, "refine": True}}, histograms=[h])
    go("+SH prefori")
elif po_mode == "md":
    ph.set_HAP_refinements({"Pref.Ori.": {"type": "MD", "MDaxis": [0, 1, 0], "refine": True}},
                           histograms=[h])
    go("+MD prefori")
h.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
go("+profile")
go("again")

prj.save()
res = prj.data["Covariance"]["data"]["Rvals"]
print("Rvals:", {k: res[k] for k in ("Rwp", "GOF", "Nobs", "Nvars") if k in res})
h.ComputeMassFracs()
for p in phases:
    print(p.name, p.get_cell())
hap = h.data
for p in phases:
    hd = p.data["Histograms"][list(p.data["Histograms"])[0]]
    print(p.name, "scale", hd["Scale"], "massFrac", hd.get("massFrac"))
