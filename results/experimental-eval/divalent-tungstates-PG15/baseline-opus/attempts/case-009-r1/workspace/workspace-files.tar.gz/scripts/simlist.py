import sys
import warnings
import numpy as np
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator

warnings.filterwarnings("ignore")
s = Structure.from_file(sys.argv[1])
if len(sys.argv) > 2 and sys.argv[2] != "-":
    a, b, c, al, be, ga = [float(v) for v in sys.argv[2].split(",")]
    s.lattice = s.lattice.__class__.from_parameters(a, b, c, al, be, ga)
print(s.lattice)
print(s.composition.reduced_formula)
hi = float(sys.argv[3]) if len(sys.argv) > 3 else 70
p = XRDCalculator(wavelength=1.540598).get_pattern(s, two_theta_range=(10, hi))
for t, i, hkl, d in zip(p.x, p.y, p.hkls, p.d_hkls):
    if i < 0.5:
        continue
    lbl = ",".join(str(h["hkl"]) for h in hkl[:3])
    print(f"{t:9.4f} {d:8.4f} {i:7.2f}  {lbl}")
