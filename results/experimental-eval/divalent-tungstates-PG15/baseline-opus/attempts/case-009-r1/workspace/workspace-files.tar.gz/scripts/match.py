"""Rank candidate COD structures against an observed peak list."""
import json
import sys
import warnings

import numpy as np
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator

warnings.filterwarnings("ignore")

cands = json.load(open(sys.argv[1]))
obs = np.loadtxt(sys.argv[2])  # two columns: 2theta, rel intensity
otth, oint = obs[:, 0], obs[:, 1]
tol = float(sys.argv[3]) if len(sys.argv) > 3 else 0.15

calc = XRDCalculator(wavelength=1.540598)
rows = []
for c in cands:
    try:
        s = Structure.from_file(c["file"])
        p = calc.get_pattern(s, two_theta_range=(10, 70))
    except Exception as e:
        continue
    ctth = np.array(p.x)
    cI = np.array(p.y)
    keep = cI > 2.0
    ctth, cI = ctth[keep], cI[keep]
    if len(ctth) == 0:
        continue
    # fraction of calc intensity matched to an observed peak
    matched = 0.0
    for t, i in zip(ctth, cI):
        if np.min(np.abs(otth - t)) < tol:
            matched += i
    fcalc = matched / cI.sum()
    # weighted fraction of observed peaks explained
    expl = 0.0
    for t, i in zip(otth, oint):
        if np.min(np.abs(ctth - t)) < tol:
            expl += i
    fobs = expl / oint.sum()
    rows.append((fcalc, fobs, c["formula"], c["sg"], c["file"]))

rows.sort(key=lambda r: -(r[0] * 0.7 + r[1] * 0.3))
for r in rows[:30]:
    print(f"fcalc={r[0]:.3f} fobs={r[1]:.3f} {r[2]:16s} {r[3]:14s} {r[4].split('/')[-1]}")
