import os
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import GSASII.GSASIIscriptable as G2sc

gpx = sys.argv[1]
png = sys.argv[2]
prj = G2sc.G2Project(gpx)
h = prj.histograms()[0]
d = h.data["data"][1]
x, yo, w, yc, yb = d[0], d[1], d[2], d[3], d[4]
msk = np.asarray(d[0].mask) if hasattr(d[0], "mask") else None
x = np.asarray(x); yo = np.asarray(yo); yc = np.asarray(yc); yb = np.asarray(yb)
diff = yo - yc
print("Rwp", h.get_wR())
for p in prj.phases():
    print(p.name, p.get_cell())

fig, axes = plt.subplots(3, 1, figsize=(18, 12), sharex=False)
ax = axes[0]
ax.plot(x, yo, "k.", ms=1.2, label="obs")
ax.plot(x, yc, "r-", lw=0.7, label="calc")
ax.plot(x, yb, "g-", lw=0.6, label="bkg")
ax.plot(x, diff - 0.15 * yo.max(), "b-", lw=0.6, label="diff")
ax.legend(fontsize=7)
ax = axes[1]
ax.plot(x, yo, "k-", lw=0.5)
ax.plot(x, yc, "r-", lw=0.5)
ax.set_yscale("log")
ax = axes[2]
ax.plot(x, diff, "b-", lw=0.6)
ax.axhline(0, color="k", lw=0.4)
lim = np.percentile(np.abs(diff), 99.7)
ax.set_ylim(-3 * lim, 3 * lim)
plt.tight_layout()
plt.savefig(png, dpi=120)

# list largest positive residual regions
from scipy.signal import find_peaks
sig = np.sqrt(np.maximum(yo, 1))
pk, _ = find_peaks(diff / sig, prominence=4, distance=6)
lam = 1.540598
print("\nResidual peaks (obs-calc):")
for i in pk:
    print(f"{x[i]:9.3f} d={lam/(2*np.sin(np.radians(x[i]/2))):7.4f} "
          f"resid={diff[i]:8.1f} ({diff[i]/sig[i]:5.1f} sigma) yo={yo[i]:8.0f}")
