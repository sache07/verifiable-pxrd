import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.signal import find_peaks

f = np.genfromtxt(sys.argv[1], delimiter=",", names=True)
x, yo, yc, yb, dif = f["two_theta_deg"], f["y_obs"], f["y_calc"], f["y_bkg"], f["y_diff"]
fig, axes = plt.subplots(3, 1, figsize=(19, 12))
axes[0].plot(x, yo, "k.", ms=1.0)
axes[0].plot(x, yc, "r-", lw=0.7)
axes[0].plot(x, yb, "g-", lw=0.6)
axes[0].plot(x, dif - 0.2 * yo.max(), "b-", lw=0.6)
axes[1].plot(x, yo, "k-", lw=0.5)
axes[1].plot(x, yc, "r-", lw=0.5)
axes[1].set_yscale("log")
axes[2].plot(x, dif, "b-", lw=0.6)
axes[2].axhline(0, color="k", lw=0.4)
axes[2].set_ylim(-5 * np.std(dif), 8 * np.std(dif))
plt.tight_layout()
plt.savefig(sys.argv[2], dpi=110)

sig = np.sqrt(np.maximum(yo, 1))
pk, _ = find_peaks(dif / sig, prominence=3.5, distance=6)
lam = 1.540598
print("Residual peaks (obs-calc), sorted by significance:")
rows = sorted(((dif[i] / sig[i], x[i], dif[i], yo[i]) for i in pk), reverse=True)
for s, t, dd, yy in rows[:60]:
    print(f"{t:9.3f} d={lam/(2*np.sin(np.radians(t/2))):7.4f} resid={dd:8.1f} ({s:5.1f} sig) yo={yy:8.0f}")
