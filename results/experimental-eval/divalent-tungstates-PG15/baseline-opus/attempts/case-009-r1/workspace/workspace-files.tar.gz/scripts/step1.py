import os
import sys
import numpy as np
import GSASII.GSASIIscriptable as G2sc

W = "<ATTEMPT_WORKSPACE>"
WK = os.path.join(W, "work")
COD = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"

gpx = os.path.join(WK, "step1.gpx")
if os.path.exists(gpx):
    os.remove(gpx)
prj = G2sc.G2Project(newgpx=gpx)
h = prj.add_powder_histogram(os.path.join(WK, "pattern.xy"),
                             os.path.join(W, "scripts", "inst.instprm"),
                             fmthint="Topas xye")
ph = prj.add_phase(os.path.join(COD, "1/52/02/1520200.cif"), phasename="MnWO4",
                   histograms=[h])

h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 12, "refine": True},
                   "Limits": [10.0, 100.0]})
prj.refine()
print("Rwp", h.get_wR())

# cell + zero
ph.set_refinements({"Cell": True})
h.set_refinements({"Sample Parameters": ["Scale"], "Instrument Parameters": ["Zero"]})
prj.refine()
print("Rwp after cell/zero", h.get_wR())
print(ph.get_cell())

h.set_refinements({"Sample Parameters": ["Shift"]})
prj.refine()
print("Rwp after shift", h.get_wR())

h.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
prj.refine()
print("Rwp after profile", h.get_wR())
print(ph.get_cell())
prj.save()
