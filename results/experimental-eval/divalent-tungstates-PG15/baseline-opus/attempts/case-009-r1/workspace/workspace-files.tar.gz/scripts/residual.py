"""Show which observed peaks are NOT explained by a set of candidate structures."""
import sys
import warnings
import numpy as np
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator

warnings.filterwarnings("ignore")
obs = np.loadtxt(sys.argv[1])
tol = 0.25
calc = XRDCalculator(wavelength=1.540598)
allc = []
for f in sys.argv[2:]:
    s = Structure.from_file(f)
    p = calc.get_pattern(s, two_theta_range=(10, 101))
    t = np.array(p.x)[np.array(p.y) > 0.5]
    allc.append((f.split("/")[-1], t))
    print(f.split("/")[-1], s.composition.reduced_formula, len(t), "refl")

lam = 1.540598
print(f"\n{'2th':>9} {'d':>8} {'Irel':>7}  owner")
for t, i in obs:
    owners = [n for n, tt in allc if len(tt) and np.min(np.abs(tt - t)) < tol]
    tag = ",".join(o.replace(".cif", "") for o in owners) or "*** UNEXPLAINED ***"
    print(f"{t:9.4f} {lam/(2*np.sin(np.radians(t/2))):8.4f} {i:7.2f}  {tag}")
