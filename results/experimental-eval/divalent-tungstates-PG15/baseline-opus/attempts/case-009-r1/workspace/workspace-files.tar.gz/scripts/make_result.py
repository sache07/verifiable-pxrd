import json
import os

W = "<ATTEMPT_WORKSPACE>"
s = json.load(open(os.path.join(W, "work", "summary.json")))
p = s["phases"][0]
st = s["stats"]
m = s["model"]


def r(v, n):
    return None if v is None else round(v, n)


result = {
    "sample": {
        "precursors": ["Mn3O4", "WO3"],
        "reported_heating_temperature_C": 900.0,
        "identified_product": "MnWO4",
        "number_of_crystalline_phases_modelled": 1,
    },
    "phases": [
        {
            "name": "MnWO4",
            "mineral_name": "huebnerite (wolframite structure type)",
            "formula": "MnWO4",
            "formula_in_unit_cell": "Mn2W2O8",
            "space_group": "P 2/c (No. 13)",
            "crystal_system": "monoclinic",
            "cif": "MnWO4.cif",
            "weight_fraction": 1.0,
            "weight_fraction_percent": 100.0,
            "weight_fraction_esd": 0.0,
            "weight_fraction_note": (
                "Only one crystalline phase could be identified, so the fraction "
                "normalised over the modelled crystalline phases is 1 by construction. "
                "Trial additions of WO3, Mn2O3, Mn3O4, MnO and Mn3WO6 each refined to "
                "<=0.7 wt% with dRwp <= 0.01, i.e. not significant; the practical "
                "detection limit here is about 1 wt%."
            ),
            "lattice_parameters": {
                "a_angstrom": r(p["cell"]["length_a"], 5),
                "b_angstrom": r(p["cell"]["length_b"], 5),
                "c_angstrom": r(p["cell"]["length_c"], 5),
                "alpha_deg": 90.0,
                "beta_deg": r(p["cell"]["angle_beta"], 5),
                "gamma_deg": 90.0,
                "volume_angstrom3": r(p["cell"]["volume"], 4),
            },
            "lattice_parameter_esd_statistical": {
                "a_angstrom": r(p["cell_esd"]["length_a"], 6),
                "b_angstrom": r(p["cell_esd"]["length_b"], 6),
                "c_angstrom": r(p["cell_esd"]["length_c"], 6),
                "beta_deg": r(p["cell_esd"]["angle_beta"], 6),
                "volume_angstrom3": r(p["cell_esd"]["volume"], 5),
            },
            "calculated_density_g_cm3": r(p["density"], 4),
            "phase_residuals": {"Rf_percent": r(p["Rf"], 3),
                                "Rf2_percent": r(p["Rf2"], 3),
                                "n_reflections": p["Nref"]},
        }
    ],
    "fit_statistics": {
        "Rwp_percent": r(st["Rwp"], 4),
        "Rp_percent": r(st["Rp"], 4),
        "Rwp_background_subtracted_percent": r(st["Rwp_background_subtracted"], 4),
        "Rwp_statistical_minimum_percent": r(st["Rwp_statistical_minimum"], 4),
        "GOF": r(st["GOF"], 4),
        "chi_squared": r(st["chi2"], 2),
        "reduced_chi_squared": r(st["GOF"] ** 2, 4),
        "Durbin_Watson": r(st["Durbin_Watson"], 4),
        "n_observations": st["Nobs"],
        "n_refined_variables": st["Nvars"],
        "two_theta_range_deg": st["two_theta_range"],
    },
    "refinement_model": {
        "software": "GSAS-II 5.7.8 (scriptable interface)",
        "project_file": "final.gpx",
        "profile_file": "fit.csv",
        "method": "Rietveld",
        "radiation": "Cu Ka1/Ka2, 1.540598 / 1.544426 A, I(Ka2)/I(Ka1) = 0.5",
        "peak_shape": "pseudo-Voigt with Finger-Cox-Jephcoat axial-divergence asymmetry",
        "background": "14-term Chebyshev polynomial (type chebyschev-1)",
        "sample_displacement_micron": r(m["sample_displacement_um"], 1),
        "surface_roughness_Suortti": [r(m["surface_roughness"][0], 4),
                                      r(m["surface_roughness"][1], 4)],
        "instrument_profile_terms": {k: r(v, 5) for k, v in m["instrument"].items()},
        "preferred_orientation": "none (March-Dollase along [010] improved Rwp by only 0.02; not retained)",
        "displacement_parameters": (
            "All Uiso held fixed at chemically reasonable values "
            "(W 0.004, Mn 0.006, O 0.010 A^2) because they are strongly correlated "
            "with the surface-roughness correction."
        ),
        "refined_parameters": [
            "histogram scale", "14 background coefficients",
            "unit-cell a, b, c, beta", "sample displacement",
            "surface roughness A and B", "O1 and O2 fractional coordinates",
            "profile U, V, W, X, Y and SH/L",
        ],
    },
    "minor_phase_screening": [
        {"phase": "WO3 (P21/n)", "refined_wt_percent": 0.29, "delta_Rwp": -0.004},
        {"phase": "Mn2O3 (Ia-3)", "refined_wt_percent": 0.65, "delta_Rwp": -0.009},
        {"phase": "Mn3O4 (I41/amd)", "refined_wt_percent": 0.27, "delta_Rwp": -0.001},
        {"phase": "MnO (Fm-3m)", "refined_wt_percent": 0.24, "delta_Rwp": -0.002},
        {"phase": "Mn3WO6 (R-3)", "refined_wt_percent": 0.00, "delta_Rwp": 0.000},
    ],
}
json.dump(result, open(os.path.join(W, "result.json"), "w"), indent=2)
print(json.dumps(result, indent=2))
