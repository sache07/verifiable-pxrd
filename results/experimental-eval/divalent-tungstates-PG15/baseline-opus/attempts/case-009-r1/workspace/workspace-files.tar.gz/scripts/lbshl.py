import os
import sys
import numpy as np
import GSASII.GSASIIscriptable as G2sc

W = "<ATTEMPT_WORKSPACE>"
WK = os.path.join(W, "work")
COD = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"
shl = float(sys.argv[1])
tag = sys.argv[2]

gpx = os.path.join(WK, f"lbs_{tag}.gpx")
if os.path.exists(gpx):
    os.remove(gpx)
prj = G2sc.G2Project(newgpx=gpx)
h = prj.add_powder_histogram(os.path.join(WK, "pattern.xy"),
                             os.path.join(W, "scripts", "inst.instprm"),
                             fmthint="Topas xye")
ph = prj.add_phase(os.path.join(COD, "1/52/02/1520200.cif"), phasename="MnWO4",
                   histograms=[h])
ph.data["General"]["Cell"][1:7] = [4.8238, 5.7504, 4.9901, 90.0, 91.18, 90.0]
ip = h.data["Instrument Parameters"][0]
for k, v in dict(U=2.0, V=-1.0, W=16.0, X=6.0, Y=2.0).items():
    ip[k][1] = v
ip["SH/L"][1] = shl
h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 14, "refine": True},
                   "Limits": [10.0, 100.0]})
prj.set_Controls("cycles", 12)


def go(t):
    prj.refine()
    print(f"== {t}: Rwp = {h.get_wR():.4f}", flush=True)


go("seed")
ph.data["Histograms"][list(ph.data["Histograms"])[0]]["LeBail"] = True
go("lebail")
ph.set_refinements({"Cell": True})
h.set_refinements({"Sample Parameters": ["Shift"]})
go("+cell+shift")
h.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
go("+profile")
go("again")
print("SHL", shl, ph.get_cell())
print("inst:", {k: round(h.data["Instrument Parameters"][0][k][1], 5) for k in
                ["U", "V", "W", "X", "Y", "Zero", "SH/L"]})
print("shift:", h.data["Sample Parameters"]["Shift"])
prj.save()
