import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

f = np.genfromtxt(sys.argv[1], delimiter=",", names=True)
x, yo, yc, yb = f["two_theta_deg"], f["y_obs"], f["y_calc"], f["y_bkg"]
wins = [tuple(float(v) for v in w.split("-")) for w in sys.argv[3].split(",")]
n = len(wins)
fig, axes = plt.subplots((n + 2) // 3, 3, figsize=(16, 3.2 * ((n + 2) // 3)), squeeze=False)
for k, (lo, hi) in enumerate(wins):
    ax = axes[k // 3][k % 3]
    m = (x >= lo) & (x <= hi)
    ax.plot(x[m], yo[m], "k.-", ms=2, lw=0.4)
    ax.plot(x[m], yc[m], "r-", lw=0.9)
    ax.plot(x[m], yb[m], "g-", lw=0.6)
    ax.plot(x[m], yo[m] - yc[m] + yb[m].min() - 0.1 * yo[m].max(), "b-", lw=0.6)
    ax.set_title(f"{lo}-{hi}", fontsize=8)
plt.tight_layout()
plt.savefig(sys.argv[2], dpi=110)
