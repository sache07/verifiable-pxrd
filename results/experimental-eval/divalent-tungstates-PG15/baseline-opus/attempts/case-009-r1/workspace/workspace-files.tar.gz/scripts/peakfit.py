import os
import sys
import numpy as np
import GSASII.GSASIIscriptable as G2sc

W = "<ATTEMPT_WORKSPACE>"
WK = os.path.join(W, "work")
gpx = os.path.join(WK, "peakfit.gpx")
if os.path.exists(gpx):
    os.remove(gpx)
prj = G2sc.G2Project(newgpx=gpx)
h = prj.add_powder_histogram(os.path.join(WK, "pattern.xy"),
                             os.path.join(W, "scripts", "inst.instprm"),
                             fmthint="Topas xye")
h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 14, "refine": True},
                   "Limits": [10.0, 100.0]})
ip = h.data["Instrument Parameters"][0]
ip["U"][1] = 1.0
ip["V"][1] = -0.2
ip["W"][1] = 0.02
ip["X"][1] = 1.0
ip["Y"][1] = 3.0
ip["SH/L"][1] = 0.002

pos = [15.674, 18.629, 23.845, 24.312, 31.310, 37.450, 40.525, 41.134,
       44.383, 45.111, 48.447, 49.457, 57.781, 67.909, 71.092, 76.373, 79.775]
for p in pos:
    h.add_peak(1, ttheta=p)
h.set_peakFlags(area=True, pos=True)
h.refine_peaks()
h.set_peakFlags(sig=True, gam=True)
r = h.refine_peaks()
print("peak fit Rwp", r)
print(f"{'pos':>9} {'int':>10} {'sig':>9} {'gam':>9} {'fwhm_deg':>9}")
rows = []
for pk in h.data["Peak List"]["peaks"]:
    p, _, inten, _, sig, _, gam, _ = pk[:8]
    fg = 2.35482 * np.sqrt(max(sig, 1e-6)) / 100.0
    fl = gam / 100.0
    fw = (fg**5 + 2.69269 * fg**4 * fl + 2.42843 * fg**3 * fl**2
          + 4.47163 * fg**2 * fl**3 + 0.07842 * fg * fl**4 + fl**5) ** 0.2
    print(f"{p:9.4f} {inten:10.1f} {sig:9.2f} {gam:9.2f} {fw:9.4f}")
    rows.append((p, sig, gam))
np.savetxt(os.path.join(WK, "peakprofiles.txt"), np.array(rows))
prj.save()
