"""Final-style Rietveld of MnWO4 with surface roughness; optional trial impurity phases.

usage: riet4.py TAG [Name=cod/rel/path.cif ...]
Trial phases get only their HAP scale refined (cell/profile held at the host values).
"""
import os
import sys
import numpy as np
import GSASII.GSASIIscriptable as G2sc

W = "<ATTEMPT_WORKSPACE>"
WK = os.path.join(W, "work")
COD = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"

PROF = dict(U=74.6487, V=47.3492, W=4.18714, X=21.0983, Y=-43.7906)
SHL = 0.0016829
SHIFT = -419.88
CELL = [4.830191, 5.757172, 4.996631, 90.0, 91.20843, 90.0]
U0 = {"Mn": 0.008, "W": 0.005, "O": 0.010}

tag = sys.argv[1]
extras = sys.argv[2:]

gpx = os.path.join(WK, f"r4_{tag}.gpx")
if os.path.exists(gpx):
    os.remove(gpx)
prj = G2sc.G2Project(newgpx=gpx)
h = prj.add_powder_histogram(os.path.join(WK, "pattern.xy"),
                             os.path.join(W, "scripts", "inst.instprm"),
                             fmthint="Topas xye")
ph = prj.add_phase(os.path.join(COD, "1/52/02/1520200.cif"), phasename="MnWO4",
                   histograms=[h])
ph.data["General"]["Cell"][1:7] = CELL
for a in ph.data["Atoms"]:
    a[9] = "I"
    a[10] = U0.get(a[1].rstrip("+-0123456789"), 0.01)
    a[11:17] = [0.0] * 6
ip = h.data["Instrument Parameters"][0]
for k, v in PROF.items():
    ip[k][1] = v
ip["SH/L"][1] = SHL
h.data["Sample Parameters"]["Shift"][0] = SHIFT
h.data["Sample Parameters"]["SurfRoughA"][0] = 0.11
h.data["Sample Parameters"]["SurfRoughB"][0] = 0.29

phases = [ph]
for e in extras:
    name, path = e.split("=")
    p2 = prj.add_phase(os.path.join(COD, path), phasename=name, histograms=[h])
    phases.append(p2)

h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 14, "refine": True},
                   "Limits": [10.0, 100.0]})
prj.set_Controls("cycles", 12)


def go(t):
    prj.refine()
    print(f"== {t}: Rwp = {h.get_wR():.4f}", flush=True)


go("scale+bkg")
ph.set_refinements({"Cell": True})
h.set_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
go("+cell+shift+rough")
ph.set_refinements({"Atoms": {"Mn1": "U", "W1": "U", "O1": "X", "O2": "X"}})
go("+atoms")
h.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
go("+profile")
if len(phases) > 1:
    for p in phases[1:]:
        p.set_HAP_refinements({"Scale": True}, histograms=[h])
    go("+trial phase scales")
go("final")
prj.save()
rv = prj.data["Covariance"]["data"]["Rvals"]
print("Rvals:", {k: rv.get(k) for k in ("Rwp", "GOF", "Nobs", "Nvars", "converged")})
h.ComputeMassFracs()
cov = prj.data["Covariance"]["data"]
esd = dict(zip(list(cov.get("varyList", [])), list(cov.get("sig", []))))
for i, p in enumerate(phases):
    hd = p.data["Histograms"][list(p.data["Histograms"])[0]]
    print("PH", p.name, {k: round(v, 5) for k, v in p.get_cell().items()},
          "scale", hd["Scale"], "esd", esd.get(f"{i}:0:Scale"),
          "massFrac", hd.get("massFrac"))
for a in ph.data["Atoms"]:
    print("  AT", a[0], a[1], [round(v, 5) for v in a[3:7]], "Uiso", round(a[10], 6))
sp = h.data["Sample Parameters"]
print("SAMP", {k: sp[k] for k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")})
print("INST", {k: round(h.data["Instrument Parameters"][0][k][1], 5)
               for k in ["U", "V", "W", "X", "Y", "SH/L", "Polariz.", "I(L2)/I(L1)"]})
