"""Write the deliverables (final.gpx, CIF per phase, fit.csv, result.json inputs)."""
import json
import os
import shutil
import sys

import numpy as np
import GSASII.GSASIIscriptable as G2sc

W = "<ATTEMPT_WORKSPACE>"
src = sys.argv[1]

final_gpx = os.path.join(W, "final.gpx")
for f in (final_gpx, final_gpx.replace(".gpx", ".bak0.gpx")):
    if os.path.exists(f):
        os.remove(f)
shutil.copy(src, final_gpx)

prj = G2sc.G2Project(final_gpx)
h = prj.histograms()[0]
prj.save()

# ---- profile ----
d = h.data["data"][1]
x, yo, w, yc, yb = [np.asarray(v, dtype=float) for v in d[:5]]
lim = h.data["Limits"][1]
m = (x >= lim[0] - 1e-9) & (x <= lim[1] + 1e-9)
out = np.column_stack([x[m], yo[m], yc[m], yb[m], (yo - yc)[m]])
np.savetxt(os.path.join(W, "fit.csv"), out, delimiter=",", fmt="%.6f",
           header="two_theta_deg,y_obs,y_calc,y_bkg,y_diff", comments="")
print("fit.csv rows", out.shape)

# ---- per-phase CIF + weight fractions ----
h.ComputeMassFracs()
hid = h.name
cov = prj.data["Covariance"]["data"]
esd = dict(zip(list(cov.get("varyList", [])), list(cov.get("sig", []))))
rv = cov["Rvals"]
hres = h.data["data"][0]

phases = []
for i, p in enumerate(prj.phases()):
    cifname = f"{p.name}.cif"
    p.export_CIF(os.path.join(W, cifname))
    hd = p.data["Histograms"][list(p.data["Histograms"])[0]]
    cell, cesd = p.get_cell_and_esd()
    phases.append(dict(
        name=p.name,
        formula="".join(f"{k}{v:g}" for k, v in p.composition.items()),
        space_group=p.data["General"]["SGData"]["SpGrp"],
        cif=cifname,
        cell=cell, cell_esd=cesd,
        density=p.density,
        scale=hd["Scale"][0],
        massFrac=hd.get("massFrac"),
        Rf=hres.get(f"{i}:0:Rf"), Rf2=hres.get(f"{i}:0:Rf^2"),
        Nref=hres.get(f"{i}:0:Nref"),
    ))
    print(p.name, cell, "massFrac", hd.get("massFrac"))

stats = dict(Rwp=rv["Rwp"], Rp=hres.get("R"), GOF=rv["GOF"], chi2=rv.get("chisq"),
             Nobs=rv["Nobs"], Nvars=rv["Nvars"],
             Rwp_background_subtracted=hres.get("wRb"),
             Rwp_statistical_minimum=hres.get("wRmin"),
             Durbin_Watson=hres.get("Durbin-Watson"),
             two_theta_range=[float(lim[0]), float(lim[1])])
sp = h.data["Sample Parameters"]
ip = h.data["Instrument Parameters"][0]
model = dict(
    histogram_scale=sp["Scale"][0],
    sample_displacement_um=sp["Shift"][0],
    surface_roughness=[sp["SurfRoughA"][0], sp["SurfRoughB"][0]],
    instrument={k: ip[k][1] for k in ("Lam1", "Lam2", "I(L2)/I(L1)", "Polariz.",
                                      "Zero", "U", "V", "W", "X", "Y", "SH/L")},
    background_terms=len(h.data["Background"][0][3:]) if h.data["Background"] else None,
)
json.dump(dict(phases=phases, stats=stats, model=model, esd=esd),
          open(os.path.join(W, "work", "summary.json"), "w"), indent=1, default=float)
print(json.dumps(stats, indent=1, default=float))
print("esd cell-ish:", {k: v for k, v in esd.items() if "::A" in k or "Scale" in k})
