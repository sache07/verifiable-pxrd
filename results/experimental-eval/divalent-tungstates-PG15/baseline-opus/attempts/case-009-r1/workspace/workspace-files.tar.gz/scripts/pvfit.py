"""Fit isolated peaks with a Ka1+Ka2 pseudo-Voigt pair to get FWHM & eta vs 2theta."""
import sys
import numpy as np
from scipy.optimize import curve_fit

lam1, lam2, ratio = 1.540598, 1.544426, 0.5

d = np.loadtxt(sys.argv[1], delimiter=",", skiprows=1)
X, Y = d[:, 0], d[:, 1]


def pv(x, x0, fwhm, eta):
    g = np.exp(-4 * np.log(2) * ((x - x0) / fwhm) ** 2) * (2 / fwhm) * np.sqrt(np.log(2) / np.pi)
    l = (2 / (np.pi * fwhm)) / (1 + 4 * ((x - x0) / fwhm) ** 2)
    return eta * l + (1 - eta) * g


def model(x, area, x0, fwhm, eta, b0, b1):
    th = np.radians(x0 / 2)
    dx = np.degrees(2 * (np.arcsin(np.sin(th) * lam2 / lam1) - th))
    return (area * (pv(x, x0, fwhm, eta) + ratio * pv(x, x0 + dx, fwhm, eta)) / (1 + ratio)
            + b0 + b1 * (x - x0))


pos = [float(v) for v in sys.argv[2].split(",")]
print(f"{'2th':>9} {'fwhm':>8} {'eta':>7} {'area':>10}")
rows = []
for p in pos:
    hw = 0.9 if p < 50 else 1.4
    m = (X > p - hw) & (X < p + hw)
    x, y = X[m], Y[m]
    try:
        popt, _ = curve_fit(model, x, y,
                            p0=[y.max() * 0.3, p, 0.12, 0.6, y.min(), 0],
                            bounds=([0, p - 0.3, 0.02, 0, 0, -1e4],
                                    [1e9, p + 0.3, 1.5, 1, 1e5, 1e4]),
                            maxfev=20000)
    except Exception as e:
        print(p, "fail", e)
        continue
    area, x0, fwhm, eta = popt[:4]
    print(f"{x0:9.4f} {fwhm:8.4f} {eta:7.3f} {area:10.1f}")
    rows.append((x0, fwhm, eta))

rows = np.array(rows)
np.savetxt(sys.argv[3], rows)

# Fit GSAS-II U,V,W (Gaussian, centideg^2) and X,Y (Lorentzian, centideg)
th = np.radians(rows[:, 0] / 2)
fw = rows[:, 1] * 100.0
eta = rows[:, 2]
# split pseudo-Voigt fwhm into G and L parts using Thompson-Cox-Hastings inverse approx
fl = fw * (1.36603 * eta - 0.47719 * eta**2 + 0.11116 * eta**3)
fg = np.sqrt(np.maximum(fw**2 - fl**2 * 1.0, 1e-6))
A = np.column_stack([np.tan(th) ** 2, np.tan(th), np.ones_like(th)])
uvw, *_ = np.linalg.lstsq(A, fg**2 / (8 * np.log(2)) * (2.35482**2) / 2.35482**2 * 0 + (fg / 2.35482) ** 2 * 2.35482**2 / 2.35482**2, rcond=None)
# GSAS-II: Gaussian variance sig^2 = U tan^2 + V tan + W, FWHM_G = 2.35482*sqrt(sig^2)
sig2 = (fg / 2.35482) ** 2
uvw, *_ = np.linalg.lstsq(A, sig2, rcond=None)
B = np.column_stack([1 / np.cos(th), np.tan(th)])
xy, *_ = np.linalg.lstsq(B, fl, rcond=None)
print("\nU,V,W =", uvw)
print("X,Y   =", xy)
