import sys
import numpy as np
from scipy.signal import find_peaks
from scipy.ndimage import minimum_filter1d, uniform_filter1d

d = np.loadtxt(sys.argv[1], delimiter=",", skiprows=1)
x, y = d[:, 0], d[:, 1]
w = int(sys.argv[3]) if len(sys.argv) > 3 else 401
bg = uniform_filter1d(minimum_filter1d(y, w), w)
ys = y - bg
noise = np.sqrt(np.maximum(y, 1))
pk, prop = find_peaks(ys, prominence=8 * noise, distance=4)
I = ys[pk]
rel = 100 * I / I.max()
sel = rel > 0.8
out = np.column_stack([x[pk][sel], rel[sel]])
np.savetxt(sys.argv[2], out, fmt="%10.4f %8.2f")
lam = 1.540598
for t, r in out:
    print(f"{t:9.4f} {lam/(2*np.sin(np.radians(t/2))):8.4f} {r:7.2f}")
print(len(out), "peaks")
