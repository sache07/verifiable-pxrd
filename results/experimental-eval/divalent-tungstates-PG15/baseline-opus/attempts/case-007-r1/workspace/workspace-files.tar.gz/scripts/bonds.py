"""Cation-anion distance check for the refined phases in a GSAS-II project."""
import sys, numpy as np, itertools, math
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc


def cellmat(a, b, c, al, be, ga):
    al, be, ga = (math.radians(v) for v in (al, be, ga))
    v1 = [a, 0, 0]
    v2 = [b*math.cos(ga), b*math.sin(ga), 0]
    cx = c*math.cos(be)
    cy = c*(math.cos(al) - math.cos(be)*math.cos(ga))/math.sin(ga)
    cz = math.sqrt(max(c*c - cx*cx - cy*cy, 0))
    return np.array([v1, v2, [cx, cy, cz]])


gpx = G2sc.G2Project(sys.argv[1])
for ph in gpx.phases():
    gen = ph.data['General']
    M = cellmat(*gen['Cell'][1:7])
    SG = gen['SGData']
    frac = []
    for at in ph.atoms():
        seen = []
        for op, t in SG['SGOps']:
            for cen in SG['SGCen']:
                for inv in ([1, -1] if SG['SGInv'] else [1]):
                    xyz = (inv*(np.inner(op, at.coordinates) + t) + cen) % 1.0
                    if not any(np.allclose(xyz, s, atol=1e-4) for s in seen):
                        seen.append(xyz)
        for s in seen:
            frac.append((at.label, at.element, s))
    print('== %s  (%d atoms in cell)' % (ph.name, len(frac)))
    for at in ph.atoms():
        if at.element == 'O':
            continue
        p0 = np.array(at.coordinates)
        ds = []
        for lbl, el, xyz in frac:
            if el != 'O':
                continue
            for sh in itertools.product((-1, 0, 1), repeat=3):
                d = np.linalg.norm(np.dot(xyz + np.array(sh) - p0, M))
                if 1.2 < d < 2.8:
                    ds.append(round(d, 3))
        print('   %-4s %s' % (at.label, sorted(ds)))
