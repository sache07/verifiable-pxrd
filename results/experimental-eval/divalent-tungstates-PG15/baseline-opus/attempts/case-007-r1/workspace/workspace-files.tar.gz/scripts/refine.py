"""Staged Rietveld refinement of the MgO + WO3 (900 C) product pattern.

Usage: refine.py <tag> <phase-spec> [key=value ...]
  phase-spec: comma separated names from CIF dict below
Options:
  shift=zero|displ|both   2theta-offset model (default zero)
  prof=uwy|uvwxy          profile parameters refined (default uwy)
  strain=1                refine per-phase isotropic microstrain
  size=1                  refine per-phase isotropic size broadening
  atoms=1                 refine atomic coordinates (X) of all phases
  uiso=1                  refine Uiso
  po=<phase>:h,k,l        March-Dollase preferred orientation for one phase
"""
import os, sys
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc
import numpy as np

W = '<ATTEMPT_WORKSPACE>'
work = os.path.join(W, 'work')
CIF = {'MgWO4': '9013902.cif', 'WO3': '1528915.cif', 'MgO': '9000499.cif',
       'WO3t': '2106293.cif', 'WO3m': '2311041.cif', 'WO3n': 'wo3_p21n.cif', 'WO3o': '2107312.cif'}

tag = sys.argv[1]
names = sys.argv[2].split(',')
opt = dict(shift='zero', prof='uwy', strain='0', size='0', atoms='0', uiso='0', po='',
           shl='0', anis='', sizeanis='', rough='0', bkgn='10', trans='0', pol='0', polval='', lo='12.5')
for a in sys.argv[3:]:
    k, v = a.split('=', 1); opt[k] = v

gpxf = os.path.join(work, '%s.gpx' % tag)
for f in (gpxf, gpxf.replace('.gpx', '.bak0.gpx')):
    if os.path.exists(f): os.remove(f)
gpx = G2sc.G2Project(newgpx=gpxf)
hist = gpx.add_powder_histogram(os.path.join(work, 'pattern.xye'),
                                os.path.join(work, 'cu.instprm'), fmthint='Topas')
phases = {}
for n in names:
    phases[n] = gpx.add_phase(os.path.join(work, 'cifsrc', CIF[n]), phasename=n,
                              histograms=[hist], fmthint='CIF')
hid = hist.name

hist.set_refinements({'Limits': [float(opt['lo']), 100.1]})
NB = int(opt['bkgn'])
hist.data['Background'][0] = ['chebyschev-1', True, NB] + [0.0]*NB
hist.data['Background'][0][3] = 700.
ip = hist.data['Instrument Parameters'][0]
if opt['prof'] in ('none', 'w'):
    # instrumental Gaussian only; sample broadening carried by size/mustrain
    ip['U'][1], ip['V'][1], ip['W'][1] = 0., 0., 10.
    ip['X'][1], ip['Y'][1] = 0., 0.
else:
    ip['U'][1], ip['V'][1], ip['W'][1] = 40., 0., 260.
    ip['X'][1], ip['Y'][1] = 0., 8.
ip['Zero'][1] = 0.30
if opt['polval']:
    ip['Polariz.'][1] = float(opt['polval'])
hist.data['Sample Parameters']['Scale'][1] = False   # keep histogram scale fixed

for n in names:
    hap = phases[n].data['Histograms'][hid]
    hap['Size'][1][0] = 0.12
    hap['Mustrain'][1][0] = 2000.
    hap['Scale'][1] = True
    for at in phases[n].atoms():          # sensible Uiso where the CIF gives none
        if at.uiso <= 0.0:
            at.uiso = 0.006 if at.element == 'W' else 0.012

def step(label):
    gpx.refine()
    r = gpx.data['Covariance']['data']['Rvals']
    print('### %-24s Rwp=%7.3f GOF=%6.3f  conv=%s' % (label, r['Rwp'], r['GOF'], r['converged']))
    sys.stdout.flush()

gpx.set_refinement({'set': {'Background': {'no. coeffs': NB, 'refine': True}}})
step('bkg+phase scales')

if opt['shift'] in ('zero', 'both'):
    gpx.set_refinement({'set': {'Instrument Parameters': ['Zero']}})
if opt['shift'] in ('displ', 'both'):
    hist.data['Sample Parameters']['Shift'][1] = True
    if opt['shift'] == 'displ':
        ip['Zero'][1] = 0.0; ip['Zero'][2] = False
step('offset')

for n in names:
    phases[n].set_refinements({'Cell': True})
step('cells')

pset = {'none': [], 'w': ['W'], 'uwy': ['U', 'W', 'Y'],
        'uvwxy': ['U', 'V', 'W', 'X', 'Y']}[opt['prof']]
if pset:
    gpx.set_refinement({'set': {'Instrument Parameters': pset}})
    step('profile ' + opt['prof'])

if opt['strain'] == '1':
    for n in names:
        phases[n].set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}})
    step('mustrain')
if opt['size'] == '1':
    for n in names:
        phases[n].set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}})
    step('size')
if opt['rough'] == '1':
    sp = hist.data['Sample Parameters']
    sp['SurfRoughA'][0] = 0.05; sp['SurfRoughA'][1] = True
    sp['SurfRoughB'][0] = 0.01; sp['SurfRoughB'][1] = True
    step('surface roughness')
if opt['shl'] == '1':
    gpx.set_refinement({'set': {'Instrument Parameters': ['SH/L']}})
    step('SH/L')
if opt['trans'] == '1':
    hist.data['Sample Parameters']['Transparency'][1] = True
    step('transparency')
if opt['pol'] == '1':
    gpx.set_refinement({'set': {'Instrument Parameters': ['Polariz.']}})
    step('polarization')
if opt['anis']:
    for n in opt['anis'].split(','):
        phases[n].set_HAP_refinements({'Mustrain': {'type': 'generalized', 'refine': True}})
    step('aniso mustrain ' + opt['anis'])
if opt['sizeanis']:
    for n in opt['sizeanis'].split(','):
        phases[n].set_HAP_refinements({'Size': {'type': 'uniaxial', 'refine': True,
                                                'direction': [0, 1, 0]}})
    step('aniso size ' + opt['sizeanis'])
if opt['po']:
    pn, hkl = opt['po'].split(':')
    phases[pn].set_HAP_refinements({'Pref.Ori.': {'type': 'MD', 'refine': True,
                                                  'MDaxis': [int(v) for v in hkl.split(',')]}})
    step('pref.ori ' + opt['po'])
if opt['atoms'] not in ('0', ''):
    sel = names if opt['atoms'] == '1' else opt['atoms'].split(',')
    for n in sel:
        phases[n].set_refinements({'Atoms': {'all': 'X'}})
    step('atom xyz ' + ','.join(sel))
if opt['uiso'] not in ('0', ''):
    sel = names if opt['uiso'] == '1' else opt['uiso'].split(',')
    for n in sel:
        phases[n].set_refinements({'Atoms': {'all': 'U'}})
    step('atom Uiso ' + ','.join(sel))

gpx.save()

print('--- Zero %.4f  Shift %.4f  RoughA %.4f RoughB %.4f' % (ip['Zero'][1], hist.data['Sample Parameters']['Shift'][0], hist.data['Sample Parameters']['SurfRoughA'][0], hist.data['Sample Parameters']['SurfRoughB'][0]))
print('--- Polariz %.4f' % ip['Polariz.'][1])
print('--- Profile U,V,W,X,Y,SH/L:', [round(ip[k][1], 4) for k in ('U','V','W','X','Y','SH/L')])
for n in names:
    c = phases[n].get_cell()
    hap = phases[n].data['Histograms'][hid]
    print('--- %-6s a=%.5f b=%.5f c=%.5f beta=%.4f V=%.3f  scale=%.5g mustr=%.0f size=%.3f' %
          (n, c['length_a'], c['length_b'], c['length_c'], c['angle_beta'], c['volume'],
           hap['Scale'][0], hap['Mustrain'][1][0], hap['Size'][1][0]))
try:
    import GSASII.GSASIIstrIO as G2stIO
    wt = gpx.get_Variables if False else None
except Exception:
    pass
r = gpx.data['Covariance']['data']['Rvals']
print('--- Rvals Rwp=%.4f GOF=%.4f Nobs=%d Nvars=%d chi2=%.1f' %
      (r['Rwp'], r['GOF'], r['Nobs'], r['Nvars'], r['chisq']))
print('--- msg', r.get('msg'))

d = hist.data['data'][1]
np.savetxt(os.path.join(work, '%s_prof.csv' % tag),
           np.column_stack([d[0], d[1], d[3], d[4], d[1]-d[3]]), delimiter=',',
           header='2theta,yobs,ycalc,bkg,diff', comments='')
