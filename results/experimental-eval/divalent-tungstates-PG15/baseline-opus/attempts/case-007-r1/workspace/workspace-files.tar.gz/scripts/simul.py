"""Simulate powder patterns of candidate phases separately (GSAS-II single-phase calc)."""
import os, sys
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc
import numpy as np

W = '<ATTEMPT_WORKSPACE>'
work = os.path.join(W, 'work')
cifs = {'MgWO4': '9013902.cif', 'WO3_g': '1528915.cif', 'MgO': '9000499.cif'}

obs = [15.9343,19.2377,23.4322,23.9429,24.2145,24.6818,24.9317,26.9094,29.2240,
       30.8105,31.1147,31.8210,33.5705,33.8965,34.4507,36.7870,37.3086,38.6669,
       40.1556,41.4270,41.8725,43.2091,44.5456,44.9912,45.7844,46.2299,48.3706,
       49.2182,50.2071,50.7504,52.3912,53.8582,54.0755,54.5754,58.7155,59.3349,
       62.0189,62.5405,64.6377,65.3223,65.8656,69.0603,72.2442]

for name, cif in cifs.items():
    gpx = G2sc.G2Project(newgpx=os.path.join(work, 'sim_%s.gpx' % name))
    h = gpx.add_simulated_powder_histogram(name, os.path.join(work, 'cu.instprm'),
                                           12.5, 100.1, Npoints=8000)
    gpx.add_phase(os.path.join(work, 'cifsrc', cif), phasename=name,
                  histograms=[h], fmthint='CIF')
    gpx.data['Controls']['data']['max cyc'] = 0
    gpx.refine()
    refl = h.reflections()[name]['RefList']
    # columns: h,k,l,mul,d,pos,sig,gam,Fo^2,Fc^2,phase,Icorr,Prfo,Trans,ExtP
    out = []
    for r in refl:
        out.append((r[5], r[0], r[1], r[2], r[9]*r[3]*r[11]))
    mx = max(o[4] for o in out) or 1
    print('=== %s' % name)
    for p, hh, kk, ll, I in sorted(out):
        if 100*I/mx < 1.0 or p > 73:
            continue
        # nearest observed assuming +0.35 shift
        pp = p + 0.35
        near = min(obs, key=lambda o: abs(o-pp))
        print(f'  {hh:3.0f}{kk:3.0f}{ll:3.0f}  2th={p:8.3f} (+.35={pp:8.3f})  I={100*I/mx:6.1f}  obs={near:8.3f}  d={near-pp:+.3f}')
