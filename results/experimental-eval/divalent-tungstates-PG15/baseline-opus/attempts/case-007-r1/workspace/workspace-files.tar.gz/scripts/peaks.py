import sys, numpy as np
d = np.genfromtxt(sys.argv[1], delimiter=',', skip_header=1)
x, y = d[:,0], d[:,1]
print("range", x.min(), x.max(), "n", len(x), "step", np.median(np.diff(x)))
print("ymin", y.min(), "ymax", y.max())
# smooth
k = 9
ys = np.convolve(y, np.ones(k)/k, mode='same')
# rough background: rolling min then smooth
from numpy.lib.stride_tricks import sliding_window_view
w = 201
pad = np.pad(ys, w//2, mode='edge')
bg = sliding_window_view(pad, w).min(axis=1)
pad2 = np.pad(bg, w//2, mode='edge')
bg = sliding_window_view(pad2, w).max(axis=1)
pad3 = np.pad(bg, 150, mode='edge')
bg = np.convolve(pad3, np.ones(301)/301, mode='valid')
net = ys - bg
thr = max(30, 0.01*net.max())
peaks = []
for i in range(2, len(net)-2):
    if net[i] > thr and net[i] >= net[i-1] and net[i] >= net[i+1] and net[i] > net[i-2] and net[i] > net[i+2]:
        peaks.append((x[i], net[i], y[i], bg[i]))
# merge close
merged = []
for p in peaks:
    if merged and p[0]-merged[-1][0] < 0.06:
        if p[1] > merged[-1][1]: merged[-1] = p
    else: merged.append(list(p))
print(f"{len(merged)} peaks")
mx = max(p[1] for p in merged)
import math
lam = 1.540598
for p in merged:
    dsp = lam/(2*math.sin(math.radians(p[0]/2)))
    print(f"{p[0]:8.4f}  d={dsp:8.5f}  I={p[1]:9.1f}  rel={100*p[1]/mx:6.2f}  bg={p[3]:7.0f}")
