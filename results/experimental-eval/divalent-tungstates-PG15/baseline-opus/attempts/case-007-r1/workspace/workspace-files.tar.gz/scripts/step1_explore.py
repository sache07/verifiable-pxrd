"""Stage 1: load data, add MgWO4, refine background+scale+zero+cell, inspect residual."""
import os, sys
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc

W = '<ATTEMPT_WORKSPACE>'
work = os.path.join(W, 'work')

gpx = G2sc.G2Project(newgpx=os.path.join(work, 'step1.gpx'))
hist = gpx.add_powder_histogram(os.path.join(work, 'pattern.xye'),
                                os.path.join(work, 'cu.instprm'),
                                fmthint='Topas')
ph = gpx.add_phase(os.path.join(work, 'cifsrc', '9013902.cif'), phasename='MgWO4',
                   histograms=[hist], fmthint='CIF')

hist.set_refinements({'Limits': [12.5, 100.1]})
hist.data['Background'][0] = ['chebyschev-1', True, 8] + [0.0]*8
hist.data['Background'][0][3] = 600.

# 1: background + scale
gpx.set_refinement({'set': {'Background': {'no. coeffs': 8, 'refine': True},
                            'Scale': True}})
gpx.refine()
print('Rwp after bkg/scale', hist.get_wR())

# 2: + zero + cell
gpx.set_refinement({'set': {'Instrument Parameters': ['Zero']}})
ph.set_refinements({'Cell': True})
gpx.refine()
print('Rwp after zero/cell', hist.get_wR())
print('Zero', hist.data['Instrument Parameters'][0]['Zero'])
print('Cell', ph.get_cell())

# 3: + profile
gpx.set_refinement({'set': {'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']}})
gpx.refine()
print('Rwp after profile', hist.get_wR())
print('Zero', hist.data['Instrument Parameters'][0]['Zero'])
print('Cell', ph.get_cell())
gpx.save()

import numpy as np
x = hist.data['data'][1][0]
yo = hist.data['data'][1][1]
yc = hist.data['data'][1][3]
bg = hist.data['data'][1][4]
np.savetxt(os.path.join(work, 'step1_prof.csv'),
           np.column_stack([x, yo, yc, bg, yo-yc]), delimiter=',',
           header='2theta,yobs,ycalc,bkg,diff', comments='')
