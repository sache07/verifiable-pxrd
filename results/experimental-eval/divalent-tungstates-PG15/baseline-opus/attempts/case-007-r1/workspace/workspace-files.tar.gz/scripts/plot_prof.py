import sys, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
f = sys.argv[1]; out = sys.argv[2]
d = np.genfromtxt(f, delimiter=',', skip_header=1)
x, yo, yc, bg, df = d[:,0], d[:,1], d[:,2], d[:,3], d[:,4]
n = 4
seg = np.array_split(np.arange(len(x)), n)
fig, ax = plt.subplots(n, 1, figsize=(16, 4*n))
for i, s in enumerate(seg):
    ax[i].plot(x[s], yo[s], 'k.', ms=1.5, label='obs')
    ax[i].plot(x[s], yc[s], 'g-', lw=0.8, label='calc')
    ax[i].plot(x[s], df[s] - 0.15*yo[s].max(), 'r-', lw=0.6, label='diff')
    ax[i].plot(x[s], bg[s], 'b-', lw=0.5)
    ax[i].axhline(-0.15*yo[s].max(), color='gray', lw=0.4)
    ax[i].legend(fontsize=7)
plt.tight_layout(); plt.savefig(out, dpi=100)
