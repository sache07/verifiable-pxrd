"""Final three-phase Rietveld refinement -> final.gpx, CIFs, fit.csv, result.json.

Model: MgWO4 (wolframite, P2/c) + gamma-WO3 (P2_1/n) + MgO (periclase, Fm-3m)
Data : Cu K-alpha1/2 reflection scan, 12.5-100.1 deg 2theta
"""
import os, sys, json
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc
import numpy as np

W = '<ATTEMPT_WORKSPACE>'
work = os.path.join(W, 'work')
out = W
CIF = [('MgWO4', '9013902.cif'), ('WO3', 'wo3_p21n.cif'), ('MgO', '9000499.cif')]
LO, HI = 12.5, 100.1

gpxf = os.path.join(out, 'final.gpx')
for f in (gpxf, gpxf.replace('.gpx', '.bak0.gpx'), gpxf.replace('.gpx', '.lst')):
    if os.path.exists(f):
        os.remove(f)

gpx = G2sc.G2Project(newgpx=gpxf)
hist = gpx.add_powder_histogram(os.path.join(work, 'pattern.xye'),
                                os.path.join(work, 'cu.instprm'), fmthint='Topas')
phases = {}
for n, c in CIF:
    phases[n] = gpx.add_phase(os.path.join(work, 'cifsrc', c), phasename=n,
                              histograms=[hist], fmthint='CIF')
hid = hist.name

hist.set_refinements({'Limits': [LO, HI]})
NB = 14
hist.data['Background'][0] = ['chebyschev-1', True, NB] + [0.0]*NB
hist.data['Background'][0][3] = 700.
ip = hist.data['Instrument Parameters'][0]
ip['U'][1], ip['V'][1], ip['W'][1] = 0., 0., 10.
ip['X'][1], ip['Y'][1] = 0., 0.
ip['Zero'][1] = 0.0          # peak shift modelled as specimen displacement, see report
hist.data['Sample Parameters']['Shift'][0] = -500.
ip['Polariz.'][1] = 0.5          # Ni-filtered lab source, no monochromator
sp0 = hist.data['Sample Parameters']
sp0['Scale'][1] = False
for n in phases:
    hap = phases[n].data['Histograms'][hid]
    hap['Size'][1][0] = 0.12
    hap['Mustrain'][1][0] = 2000.
    hap['Scale'][1] = True
    for at in phases[n].atoms():
        if at.uiso <= 0.0:
            at.uiso = 0.006 if at.element == 'W' else 0.012

log = []
def step(label):
    gpx.refine()
    r = gpx.data['Covariance']['data']['Rvals']
    log.append({'stage': label, 'Rwp': round(r['Rwp'], 4), 'GOF': round(r['GOF'], 4),
                'Nvars': r['Nvars']})
    print('### %-26s Rwp=%7.3f GOF=%6.3f' % (label, r['Rwp'], r['GOF']))
    sys.stdout.flush()

gpx.set_refinement({'set': {'Background': {'no. coeffs': NB, 'refine': True}}})
step('background + phase scales')
hist.data['Sample Parameters']['Shift'][1] = True
step('+ specimen displacement')
for n in phases:
    phases[n].set_refinements({'Cell': True})
step('+ unit cells')
gpx.set_refinement({'set': {'Instrument Parameters': ['W']}})
step('+ Gaussian W')
for n in phases:
    phases[n].set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}})
step('+ isotropic microstrain')
for n in phases:
    phases[n].set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}})
step('+ isotropic size')
sp = hist.data['Sample Parameters']
sp['SurfRoughA'][0], sp['SurfRoughA'][1] = 0.05, True
sp['SurfRoughB'][0], sp['SurfRoughB'][1] = 0.01, True
step('+ Suortti low-angle intensity corr.')
gpx.set_refinement({'set': {'Instrument Parameters': ['SH/L']}})
step('+ axial-divergence asymmetry')
phases['MgWO4'].set_refinements({'Atoms': {'all': 'X'}})
step('+ MgWO4 atom coordinates')
step('final cycle')
gpx.save()

# ---------------------------------------------------------------- outputs
res = gpx.data['Covariance']['data']['Rvals']
d = hist.data['data'][1]
x, yo, yw, yc, yb = d[0], d[1], d[2], d[3], d[4]
m = (x >= LO) & (x <= HI)
x, yo, yw, yc, yb = x[m], yo[m], yw[m], yc[m], yb[m]
Rp = 100*np.sum(np.abs(yo-yc))/np.sum(yo)
Rwp = 100*np.sqrt(np.sum(yw*(yo-yc)**2)/np.sum(yw*yo**2))
Rexp = Rwp/np.sqrt(res['GOF']**2)

np.savetxt(os.path.join(out, 'fit.csv'),
           np.column_stack([x, yo, yc, yo-yc, yb]), delimiter=',', fmt='%.6f',
           header='two_theta_deg,y_obs,y_calc,y_diff,y_background', comments='')

# weight fractions + esds from the GSAS-II listing
wf = {}
lst = open(os.path.join(out, 'final.lst')).read().splitlines()
cur = None
for i, line in enumerate(lst):
    if line.startswith(' Phase: ') and ' in histogram' in line:
        cur = line.split()[1]
    if 'Weight fraction' in line and cur:
        seg = line.split('Weight fraction  :')[1]
        v, s = seg.split(', sig')
        wf[cur] = (float(v), float(s))
print(wf)

info = {
    'MgWO4': dict(formula='MgWO4', mineral='huanzalaite (wolframite type)', sg='P 2/c',
                  sgnum=13, source='COD 9013902 (Macavei & Schulz, Z. Kristallogr. 207, 193, 1993)'),
    'WO3':   dict(formula='WO3', mineral='gamma-WO3 (monoclinic tungstite type)', sg='P 2_1/n',
                  sgnum=14, source='COD 2311041 (Loopstra & Boldrup, Acta Cryst. 1966), transformed to the P2_1/n setting'),
    'MgO':   dict(formula='MgO', mineral='periclase', sg='F m -3 m', sgnum=225,
                  source='COD 9000499 (Hazen, Am. Mineral. 61, 266, 1976)'),
}
# Combined (statistical + model-choice) uncertainty.  The model-choice part is the
# spread of the weight fractions over the alternative refinements that were tested
# (WO3 structure model, polarization 0.5/0.7/0.9, with/without the low-angle
# intensity correction, with/without preferred orientation and Uiso refinement):
#   MgWO4 0.775-0.784, WO3 0.149-0.156, MgO 0.067-0.076
MODEL_SPREAD = {'MgWO4': 0.005, 'WO3': 0.004, 'MgO': 0.005}
MOLWT = {'MgWO4': 272.15, 'WO3': 231.84, 'MgO': 40.304}

phase_out = []
for n in phases:
    ph = phases[n]
    cifname = 'phase_%s.cif' % n
    ph.export_CIF(os.path.join(out, cifname))
    c = ph.get_cell()
    hap = ph.data['Histograms'][hid]
    rsd = hist.data['Reflection Lists'][n] if False else None
    phase_out.append({
        'phase_name': n,
        'formula': info[n]['formula'],
        'description': info[n]['mineral'],
        'space_group': info[n]['sg'],
        'space_group_number': info[n]['sgnum'],
        'cif': cifname,
        'structure_source': info[n]['source'],
        'weight_fraction': round(wf[n][0], 4),
        'weight_fraction_esd_statistical': round(wf[n][1], 4),
        'weight_fraction_uncertainty_combined': round(
            float(np.hypot(wf[n][1], MODEL_SPREAD[n])), 4),
        'lattice': {k: round(v, 5) for k, v in c.items()},
        'phase_scale': hap['Scale'][0],
        'microstrain_1e-6': round(hap['Mustrain'][1][0], 1),
        'domain_size_um': round(hap['Size'][1][0], 4),
    })

result = {
    'sample': {'precursors': ['MgO', 'WO3'], 'heating_temperature_C': 900.0},
    'n_phases_modelled': len(phase_out),
    'phases': phase_out,
    'weight_fraction_basis': 'normalised over the three modelled crystalline phases (sums to 1)',
    'fit_statistics': {
        'Rwp_percent': round(float(Rwp), 3),
        'Rp_percent': round(float(Rp), 3),
        'Rexp_percent': round(float(Rexp), 3),
        'GOF': round(float(res['GOF']), 3),
        'chi2': round(float(res['chisq']), 1),
        'reduced_chi2': round(float(res['GOF'])**2, 3),
        'n_observations': int(res['Nobs']),
        'n_variables': int(res['Nvars']),
        'two_theta_range_deg': [LO, HI],
        'per_phase_RF2_percent': {},
    },
    'instrument_model': {
        'wavelengths_angstrom': [ip['Lam1'][1], ip['Lam2'][1]],
        'I_Ka2_over_Ka1': ip['I(L2)/I(L1)'][1],
        'polarization_GSASII': ip['Polariz.'][1],
        'zero_offset_deg': round(ip['Zero'][1], 4),
        'specimen_displacement_um': round(sp0['Shift'][0], 1),
        'gaussian_W_centideg2': round(ip['W'][1], 3),
        'SH_over_L': round(ip['SH/L'][1], 5),
        'SuorttiA': round(sp['SurfRoughA'][0], 4),
        'SuorttiB': round(sp['SurfRoughB'][0], 5),
        'background': 'Chebyshev (1st kind), %d terms' % NB,
    },
    'refinement_log': log,
}

mol = {n: wf[n][0]/MOLWT[n] for n in phases}
tot = sum(mol.values())
result['derived_chemistry'] = {
    'mole_fractions_of_phases': {n: round(mol[n]/tot, 4) for n in phases},
    'bulk_Mg_to_W_atomic_ratio': round((mol['MgWO4'] + mol['MgO'])/(mol['MgWO4'] + mol['WO3']), 3),
    'fraction_of_W_present_as_MgWO4': round(mol['MgWO4']/(mol['MgWO4'] + mol['WO3']), 3),
    'fraction_of_Mg_present_as_MgWO4': round(mol['MgWO4']/(mol['MgWO4'] + mol['MgO']), 3),
    'comment': ('Both precursors survive, so the 900 C reaction MgO + WO3 -> MgWO4 is '
                'incomplete.  The leftover MgO greatly exceeds the leftover WO3 on a molar '
                'basis, implying an Mg-rich (Mg:W ~ 1.3) starting mixture and/or '
                'under-correction of the MgO amount (see notes).')
}
result['notes'] = [
    'The 9.90-12.50 deg region was excluded from the refinement: it contains only the '
    'steeply rising direct-beam/air-scatter tail and no Bragg peaks.',
    'All three phases require the same systematic peak shift of about +0.33 deg at 15-30 deg '
    '2theta; without it every refined cell comes out ~1% too small.  It is modelled as a '
    'specimen displacement (-544 um, cos-theta dependence) rather than as a constant zero '
    'error, because that fits better (Rwp 7.99 vs 8.05%) and reproduces a(MgO) = 4.2122 A '
    'against the periclase value 4.2117 A (zero-error model: 4.2160 A).  The unreacted MgO '
    'thus acts as an internal standard.  Weight fractions are unchanged by this choice.',
    'Observed intensities fall off systematically at low 2theta relative to any '
    'structural model.  This was absorbed with the GSAS-II Suortti surface-roughness '
    'function; the refined A lies outside the physical 0-1 range, so it is used as an '
    'empirical low-angle intensity correction (beam overflow / surface roughness) '
    'rather than as a measured roughness.  Weight fractions change by <1 abs% whether '
    'it is included or not.',
    'No Brindley microabsorption correction was applied (particle sizes unknown).  '
    'MgO (mu ~ 100 /cm) is a much weaker absorber than MgWO4/WO3 (mu ~ 830-990 /cm), '
    'so the MgO weight fraction is more likely under- than over-estimated.',
    'Atomic displacement parameters were held at the published single-crystal values; '
    'they cannot be refined meaningfully alongside the empirical low-angle correction.',
    'WO3 oxygen positions were held at the Loopstra & Boldrup values; releasing them '
    'gave no improvement in Rwp (8.513 vs 8.516 in the equivalent test refinement) while '
    'moving some O atoms by >0.1 fractional units, i.e. overfitting.',
    'Alternative WO3 polymorphs were tested with the identical protocol and rejected: '
    'orthorhombic beta-WO3 (Pnma) Rwp = 10.99%, triclinic delta-WO3 (P-1) worse than '
    'monoclinic at the matched stage with alpha, gamma within 0.17 deg of 90 deg.',
    'Removing MgO from the model raises Rwp from 7.99% to 9.36% and leaves the 43.21 deg '
    'peak unfitted; removing WO3 raises it to 19.07%.',
]
cur = None
for line in lst:
    if line.startswith(' Phase: ') and ' in histogram' in line:
        cur = line.split()[1]
    if cur and 'Final refinement RF, RF^2' in line:
        rf, rf2 = line.split('=')[1].split('on')[0].split(',')
        result['fit_statistics']['per_phase_RF2_percent'][cur] = float(rf2.strip().rstrip('%'))
        result['fit_statistics'].setdefault('per_phase_RF_percent', {})[cur] = float(rf.strip().rstrip('%'))

json.dump(result, open(os.path.join(out, 'result.json'), 'w'), indent=2)
print(json.dumps(result['fit_statistics'], indent=2))
print('Rwp %.3f Rp %.3f Rexp %.3f' % (Rwp, Rp, Rexp))
np.savetxt(os.path.join(work, 'final_prof.csv'),
           np.column_stack([x, yo, yc, yb, yo-yc]), delimiter=',',
           header='2theta,yobs,ycalc,bkg,diff', comments='')
