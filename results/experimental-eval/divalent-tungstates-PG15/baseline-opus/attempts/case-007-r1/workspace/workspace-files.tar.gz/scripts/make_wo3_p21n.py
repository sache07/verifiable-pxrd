"""Transform the Loopstra & Boldrup (COD 2311041) gamma-WO3 structure from the
P2_1/c setting (a1=c, b1=b, c1=-(a+c), beta1=136.06) into the standard P2_1/n
setting (a=7.306, b=7.540, c=7.692, beta=90.88).

  r = x1*a1 + y1*b1 + z1*c1 = x1*c + y1*b - z1*(a+c)
    = -z1*a + y1*b + (x1-z1)*c
  =>  x = -z1,  y = y1,  z = x1 - z1
"""
import math, os

src = [('O6', 'O', 0.714, 0.487, 0.721), ('O2', 'O', 0.225, 0.474, 0.007),
       ('W1', 'W', 0.028, 0.037, 0.746), ('O5', 'O', 0.716, 0.043, 0.708),
       ('O3', 'O', 0.998, 0.262, 0.712), ('O1', 'O', 0.206, 0.042, 0.995),
       ('W2', 'W', 0.534, 0.023, 0.750), ('O4', 'O', 0.519, 0.259, 0.789)]
a1, b1, c1, beta1 = 7.688, 7.539, 10.515, 136.06

# derive the P2_1/n cell:  c = a1 ; b = b1 ; a = -(c1 + a1) -> |a|
cb = math.cos(math.radians(beta1))
c = a1
b = b1
a = math.sqrt(a1**2 + c1**2 + 2*a1*c1*cb)      # |a| = |-(c1)-(a1)| with angle beta1
# angle beta between a and c
cosbeta = -(a1 + c1*cb)/a
beta = math.degrees(math.acos(cosbeta))
print('P21/n cell: a=%.4f b=%.4f c=%.4f beta=%.3f  V=%.2f' %
      (a, b, c, beta, a*b*c*math.sin(math.radians(beta))))

atoms = []
for lbl, el, x1, y1, z1 in src:
    x, y, z = -z1, y1, x1 - z1
    atoms.append((lbl, el, x % 1.0, y % 1.0, z % 1.0))

out = ['data_gamma_WO3_P21n',
       "_chemical_formula_sum 'O3 W'",
       "_chemical_name_systematic 'tungsten trioxide (gamma)'",
       '_cell_length_a %.4f' % a,
       '_cell_length_b %.4f' % b,
       '_cell_length_c %.4f' % c,
       '_cell_angle_alpha 90.0',
       '_cell_angle_beta %.3f' % beta,
       '_cell_angle_gamma 90.0',
       '_space_group_IT_number 14',
       "_symmetry_space_group_name_H-M 'P 1 21/n 1'",
       'loop_', '_symmetry_equiv_pos_as_xyz',
       '  x,y,z', '  -x+1/2,y+1/2,-z+1/2', '  -x,-y,-z', '  x+1/2,-y+1/2,z+1/2',
       'loop_', '_atom_site_label', '_atom_site_type_symbol',
       '_atom_site_fract_x', '_atom_site_fract_y', '_atom_site_fract_z',
       '_atom_site_occupancy', '_atom_site_U_iso_or_equiv']
for lbl, el, x, y, z in atoms:
    out.append('%-4s %-2s %.4f %.4f %.4f 1.0 %.4f' %
               (lbl, el, x, y, z, 0.006 if el == 'W' else 0.012))
W = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
open(os.path.join(W, 'work', 'cifsrc', 'wo3_p21n.cif'), 'w').write('\n'.join(out) + '\n')
for aa in atoms:
    print(aa)
