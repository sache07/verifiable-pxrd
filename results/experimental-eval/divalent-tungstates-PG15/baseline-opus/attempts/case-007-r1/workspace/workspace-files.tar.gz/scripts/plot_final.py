import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

W = '<ATTEMPT_WORKSPACE>/'
d = np.genfromtxt(W+'fit.csv', delimiter=',', skip_header=1)
x, yo, yc, df, bg = d[:,0], d[:,1], d[:,2], d[:,3], d[:,4]
fig, ax = plt.subplots(2, 1, figsize=(13, 9), gridspec_kw={'height_ratios': [1, 1]})
for A, (lo, hi) in zip(ax, [(12.5, 56.0), (56.0, 100.1)]):
    s = (x >= lo) & (x <= hi)
    off = 0.12*yo[s].max()
    A.plot(x[s], yo[s], 'k.', ms=2, label='observed')
    A.plot(x[s], yc[s], 'r-', lw=0.9, label='calculated')
    A.plot(x[s], bg[s], 'b-', lw=0.6, label='background')
    A.plot(x[s], df[s]-off, 'g-', lw=0.6, label='difference')
    A.axhline(-off, color='0.6', lw=0.4)
    A.set_xlim(lo, hi); A.set_xlabel(r'2$\theta$ / deg (Cu K$\alpha$)')
    A.set_ylabel('counts'); A.legend(fontsize=8, ncol=4)
ax[0].set_title(r'MgWO$_4$ (77.8 wt%) + $\gamma$-WO$_3$ (15.2 wt%) + MgO (7.1 wt%),  '
                r'R$_{wp}$ = 7.99%, GOF = 2.77', fontsize=11)
plt.tight_layout(); plt.savefig(W+'fit.png', dpi=130)
print('ok')
