import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
d = np.genfromtxt('inputs/pattern.csv', delimiter=',', skip_header=1)
x, y = d[:,0], d[:,1]
fig, ax = plt.subplots(3,1, figsize=(14,11))
ax[0].plot(x,y,lw=0.6); ax[0].set_yscale('log')
ax[1].plot(x[:600],y[:600],lw=0.8)
ax[2].plot(x,y,lw=0.6); ax[2].set_ylim(0,3000)
plt.tight_layout(); plt.savefig('work/raw.png', dpi=110)
