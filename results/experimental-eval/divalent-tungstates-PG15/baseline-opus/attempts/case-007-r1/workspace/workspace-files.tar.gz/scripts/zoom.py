import sys, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
f, out = sys.argv[1], sys.argv[2]
rngs = [tuple(float(v) for v in a.split('-')) for a in sys.argv[3:]]
d = np.genfromtxt(f, delimiter=',', skip_header=1)
x, yo, yc, bg, df = d[:,0], d[:,1], d[:,2], d[:,3], d[:,4]
fig, ax = plt.subplots(len(rngs), 1, figsize=(13, 3.4*len(rngs)), squeeze=False)
for i, (a, b) in enumerate(rngs):
    s = (x >= a) & (x <= b)
    A = ax[i][0]
    A.plot(x[s], yo[s], 'k.', ms=3)
    A.plot(x[s], yc[s], 'g-', lw=1)
    A.plot(x[s], df[s] - 0.2*yo[s].max(), 'r-', lw=0.8)
    A.axhline(-0.2*yo[s].max(), color='gray', lw=0.4)
    A.set_title('%g-%g' % (a, b), fontsize=8)
plt.tight_layout(); plt.savefig(out, dpi=110)
