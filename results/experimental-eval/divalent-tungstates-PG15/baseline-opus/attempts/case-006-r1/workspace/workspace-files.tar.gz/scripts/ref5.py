"""Main Rietveld refinement: CuWO4 (P-1) + gamma-WO3 (P2_1/n).

Usage: ref5.py <outgpx> [--cuo] [--po]
"""
import os, sys, numpy as np
os.chdir('<ATTEMPT_WORKSPACE>')
import GSASIIscriptable as G2sc

out = sys.argv[1]
ADD_CUO = '--cuo' in sys.argv
PO = '--po' in sys.argv

def wfrac(gpx):
    o = {}
    for p in gpx.phases():
        hid = list(p.data['Histograms'])[0]
        o[p.name] = p.data['Histograms'][hid]['Scale'][0] * G2sc.G2mth.getMass(p.data['General'])
    t = sum(o.values())
    return {k: v/t for k, v in o.items()}

def rep(gpx, h, tag):
    print(f'--- {tag}: Rwp={h.get_wR():.4f} ' +
          ' '.join(f'{k}={v*100:.2f}%' for k, v in wfrac(gpx).items()), flush=True)

gpx = G2sc.G2Project(newgpx=out)
h = gpx.add_powder_histogram('work/pattern.xy', 'work/lab.instprm', fmthint='Topas xye')
plist = [('CuWO4', 'cifs/CuWO4_start.cif', 1.0), ('WO3', 'cifs/1528915.cif', 0.02)]
if ADD_CUO:
    plist.append(('CuO', 'cifs/1011194.cif', 0.01))
phs = {}
for name, cif, sc0 in plist:
    p = gpx.add_phase(cif, phasename=name, histograms=[h])
    p.data['Histograms'][list(p.data['Histograms'])[0]]['Scale'] = [sc0, False]
    phs[name] = p
print('atoms CuWO4:', [(i, a.label) for i, a in enumerate(phs['CuWO4'].atoms())])

# A
h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True},
                   'Sample Parameters': ['Scale', 'Shift']})
gpx.do_refinements([{}]); rep(gpx, h, 'A bkg+scale+shift')

# B
for p in phs.values():
    p.set_HAP_refinements({'Scale': True})
h.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']})
phs['CuWO4'].set_refinements({'Cell': True})
gpx.do_refinements([{}]); rep(gpx, h, 'B frac+UVWXY+cell')

# C
phs['WO3'].set_refinements({'Cell': True})
h.set_refinements({'Instrument Parameters': ['SH/L']})
gpx.do_refinements([{}]); rep(gpx, h, 'C WO3 cell+SHL')

# D: per-phase broadening, drop global X/Y
ip = h.data['Instrument Parameters'][0]
ip['X'][1] = 0.0; ip['Y'][1] = 0.0
h.clear_refinements({'Instrument Parameters': ['X', 'Y']})
for p in phs.values():
    p.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True},
                           'Size': {'type': 'isotropic', 'refine': True}})
gpx.do_refinements([{}]); rep(gpx, h, 'D size+mustrain')

# E: atom coordinates + Uiso (O sites constrained equal)
nO = [i for i, a in enumerate(phs['CuWO4'].atoms()) if a.element == 'O']
gpx.add_EquivConstr([f'0::AUiso:{i}' for i in nO])
phs['CuWO4'].set_refinements({'Atoms': {'all': 'XU'}})
gpx.do_refinements([{}]); rep(gpx, h, 'E CuWO4 X+U')

# F: more background
h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True}})
gpx.do_refinements([{}]); rep(gpx, h, 'F bkg12')

if PO:
    for p in phs.values():
        p.set_HAP_refinements({'Pref.Ori.': {'type': 'SH', 'order': 4, 'refine': True}})
    gpx.do_refinements([{}]); rep(gpx, h, 'G pref.ori SH4')

# final cycle: everything together
gpx.do_refinements([{}]); rep(gpx, h, 'final')

print('inst', {k: round(h.data['Instrument Parameters'][0][k][1], 5)
               for k in ['U', 'V', 'W', 'X', 'Y', 'Zero', 'SH/L']})
print('shift', h.data['Sample Parameters']['Shift'])
for name, p in phs.items():
    hid = list(p.data['Histograms'])[0]
    hd = p.data['Histograms'][hid]
    print(name, 'cell', {k: round(v, 5) for k, v in p.get_cell().items()})
    print('   size', hd['Size'][1][0], 'mustrain', hd['Mustrain'][1][0])
    for a in p.atoms():
        print('   ', a.label, a.element, [round(c, 4) for c in a.coordinates], round(a.uiso, 5))
cv = gpx.data['Covariance']['data']
print('GOF', cv.get('Rvals', {}))
gpx.save()
