"""First-pass Rietveld: CuWO4 only."""
import os, sys
os.chdir('<ATTEMPT_WORKSPACE>')
import GSASIIscriptable as G2sc

gpx = G2sc.G2Project(newgpx='work/step1.gpx')
h = gpx.add_powder_histogram('work/pattern.xy', 'work/lab.instprm', fmthint='Topas xye')
ph = gpx.add_phase('cifs/CuWO4_ambient.cif', phasename='CuWO4', histograms=[h])

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True},
                   'Sample Parameters': ['Scale']})
gpx.do_refinements([{}])
print('Rwp after bkg/scale', h.get_wR())

h.set_refinements({'Sample Parameters': ['Shift']})
gpx.do_refinements([{}])
print('Rwp after shift', h.get_wR(), h.data['Sample Parameters']['Shift'])

ph.set_refinements({'Cell': True})
gpx.do_refinements([{}])
print('Rwp after cell', h.get_wR(), ph.get_cell())

h.set_refinements({'Instrument Parameters': ['U', 'V', 'W']})
gpx.do_refinements([{}])
print('Rwp after UVW', h.get_wR())

h.set_refinements({'Instrument Parameters': ['X', 'Y']})
gpx.do_refinements([{}])
print('Rwp after XY', h.get_wR())
print({k: h.data['Instrument Parameters'][0][k][1] for k in ['U','V','W','X','Y','Zero','SH/L']})
gpx.save()
