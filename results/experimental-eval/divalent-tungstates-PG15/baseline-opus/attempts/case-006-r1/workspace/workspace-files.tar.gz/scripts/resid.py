"""Dump profile + list residual peaks from a gpx."""
import os, sys, numpy as np
os.chdir('<ATTEMPT_WORKSPACE>')
import GSASIIscriptable as G2sc
gpx = G2sc.G2Project(sys.argv[1])
h = gpx.histograms()[0]
d = h.data['data'][1]
x, yo, w, yc, yb = d[0], d[1], d[2], d[3], d[4]
print('Rwp', h.get_wR(), 'Shift', h.data['Sample Parameters']['Shift'],
      'DisplaceX' if 'DisplaceX' in h.data['Sample Parameters'] else '')
res = yo - yc
sig = 1/np.sqrt(np.maximum(w, 1e-12))
# smooth residual
k = np.ones(9)/9
rs = np.convolve(np.pad(res, 4, mode='edge'), k, mode='valid')
mx = (yo - yb).max()
print('max net obs', mx)
print(' 2theta   resid   %ofmax')
out = []
for i in range(3, len(x)-3):
    if rs[i] > 0.01*mx and rs[i] == max(rs[i-3:i+4]):
        out.append((x[i], rs[i], 100*rs[i]/mx))
for t, r, p in out:
    print(f"{t:8.3f} {r:9.1f} {p:6.2f}")
np.savetxt('work/prof.csv', np.c_[x, yo, yc, yo-yc, yb], delimiter=',', header='x,yobs,ycalc,diff,ybkg', comments='')
