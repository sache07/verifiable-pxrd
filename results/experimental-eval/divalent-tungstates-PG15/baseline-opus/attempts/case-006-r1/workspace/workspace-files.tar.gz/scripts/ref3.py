"""Third pass: CuWO4 (major) + trial minor phases, proper phase-fraction refinement."""
import os, sys, numpy as np
os.chdir('<ATTEMPT_WORKSPACE>')
import GSASIIscriptable as G2sc

PHASES = [('CuWO4', 'cifs/CuWO4_ambient.cif', 1.0),
          ('WO3', 'cifs/1528915.cif', 0.02),
          ('CuO', 'cifs/1011194.cif', 0.02)]

def wfrac(gpx):
    """weight fractions from HAP scales"""
    out = {}
    for p in gpx.phases():
        hid = list(p.data['Histograms'])[0]
        sc = p.data['Histograms'][hid]['Scale'][0]
        # mass of unit cell
        gen = p.data['General']
        mass = G2sc.G2mth.getMass(gen)
        out[p.name] = sc * mass
    tot = sum(out.values())
    return {k: v/tot for k, v in out.items()}

def rep(gpx, h, tag):
    print(f'--- {tag}: Rwp = {h.get_wR():.4f}  ' +
          '  '.join(f'{k}={v*100:.2f}%' for k, v in wfrac(gpx).items()))
    sys.stdout.flush()

gpx = G2sc.G2Project(newgpx='work/step3.gpx')
h = gpx.add_powder_histogram('work/pattern.xy', 'work/lab.instprm', fmthint='Topas xye')
phs = {}
for name, cif, sc0 in PHASES:
    p = gpx.add_phase(cif, phasename=name, histograms=[h])
    p.data['Histograms'][list(p.data['Histograms'])[0]]['Scale'] = [sc0, False]
    phs[name] = p

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True},
                   'Sample Parameters': ['Scale', 'Shift']})
gpx.do_refinements([{}]); rep(gpx, h, 'bkg+scale+shift')

for p in phs.values():
    p.set_HAP_refinements({'Scale': True})
gpx.do_refinements([{}]); rep(gpx, h, 'phase fractions')

h.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']})
phs['CuWO4'].set_refinements({'Cell': True})
gpx.do_refinements([{}]); rep(gpx, h, 'profile+CuWO4 cell')

for n in ('WO3', 'CuO'):
    phs[n].set_refinements({'Cell': True})
gpx.do_refinements([{}]); rep(gpx, h, 'all cells')

h.set_refinements({'Instrument Parameters': ['SH/L']})
gpx.do_refinements([{}]); rep(gpx, h, 'SH/L')

for name, p in phs.items():
    print(name, {k: round(v, 5) for k, v in p.get_cell().items()})
gpx.save()
