"""Second pass: CuWO4 + WO3 + CuO, stepwise refinement."""
import os, sys
os.chdir('<ATTEMPT_WORKSPACE>')
import GSASIIscriptable as G2sc

def rep(gpx, h, tag):
    print(f'--- {tag}: Rwp = {h.get_wR():.4f}')
    try:
        for p, f in zip(gpx.phases(), [None]*9):
            pass
    except Exception:
        pass
    sys.stdout.flush()

gpx = G2sc.G2Project(newgpx='work/step2.gpx')
h = gpx.add_powder_histogram('work/pattern.xy', 'work/lab.instprm', fmthint='Topas xye')
phs = {}
for name, cif in [('CuWO4', 'cifs/CuWO4_ambient.cif'),
                  ('WO3', 'cifs/1528915.cif'),
                  ('CuO', 'cifs/1011194.cif')]:
    phs[name] = gpx.add_phase(cif, phasename=name, histograms=[h])

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True},
                   'Sample Parameters': ['Scale', 'Shift']})
gpx.do_refinements([{}]); rep(gpx, h, 'bkg+scale+shift')

h.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']})
for p in phs.values():
    p.set_refinements({'Cell': True})
gpx.do_refinements([{}]); rep(gpx, h, 'cells+profile')

h.set_refinements({'Instrument Parameters': ['SH/L']})
gpx.do_refinements([{}]); rep(gpx, h, 'SH/L')

for name, p in phs.items():
    print(name, p.get_cell())
    print('  fraction', p.data['Histograms'][list(p.data['Histograms'])[0]]['Scale'])
gpx.save()
