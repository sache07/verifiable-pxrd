"""Produce deliverables from the final GSAS-II project."""
import os, json, shutil, numpy as np
os.chdir('<ATTEMPT_WORKSPACE>')
import GSASIIscriptable as G2sc

shutil.copy('work/final_b.gpx', 'final.gpx')
gpx = G2sc.G2Project('final.gpx')
h = gpx.histograms()[0]
phs = {p.name: p for p in gpx.phases()}

# ---- profile ----
d = h.data['data'][1]
x, yo, w, yc, yb = np.array(d[0]), np.array(d[1]), np.array(d[2]), np.array(d[3]), np.array(d[4])
np.savetxt('fit.csv', np.c_[x, yo, yc, yo - yc, yb], delimiter=',', fmt='%.6f',
           header='two_theta_deg,y_obs,y_calc,y_diff,y_background', comments='')

Rwp = 100*np.sqrt(np.sum(w*(yo-yc)**2)/np.sum(w*yo**2))
Rp = 100*np.sum(np.abs(yo-yc))/np.sum(yo)
rv = gpx.data['Covariance']['data']['Rvals']
Nobs, Nvar = rv['Nobs'], rv['Nvars']
chi2 = np.sum(w*(yo-yc)**2)
GOF = np.sqrt(chi2/(Nobs-Nvar))
Rexp = Rwp/GOF

# ---- weight fractions (GSAS-II convention: scale * cell mass) ----
mass, scale, sig = {}, {}, {}
for n, p in phs.items():
    hid = list(p.data['Histograms'])[0]
    hd = p.data['Histograms'][hid]
    mass[n] = G2sc.G2mth.getMass(p.data['General'])
    scale[n] = hd['Scale'][0]
cov = gpx.data['Covariance']['data']
vl, sg = cov['varyList'], cov['sig']
for n, p in phs.items():
    key = f'{list(phs).index(n)}:0:Scale'
    sig[n] = sg[vl.index(key)] if key in vl else 0.0
tot = sum(scale[n]*mass[n] for n in phs)
wt = {n: scale[n]*mass[n]/tot for n in phs}
# propagate scale esds (uncorrelated approximation)
wsig = {}
for n in phs:
    s = 0.0
    for m in phs:
        dwdm = (mass[n]*mass[m]*scale[n]/tot**2) if m != n else (mass[n]*(tot-scale[n]*mass[n])/tot**2)
        s += (dwdm*sig[m])**2
    wsig[n] = np.sqrt(s)

# ---- per-phase Bragg residuals ----
rf = {}
for n in phs:
    rl = h.reflections()[n]['RefList']
    Fo = np.sqrt(np.abs(rl[:, 8])); Fc = np.sqrt(np.abs(rl[:, 9]))
    rf[n] = {'n_reflections': int(rl.shape[0]),
             'RF_percent': round(float(100*np.sum(np.abs(Fo-Fc))/np.sum(Fo)), 2)}

# ---- export CIFs ----
cifname = {'CuWO4': 'CuWO4.cif', 'WO3': 'WO3.cif'}
for n, p in phs.items():
    p.export_CIF(cifname[n])

cells = {n: phs[n].get_cell_and_esd() for n in phs}
out = {
    'phases': [],
    'fit_statistics': {
        'Rwp_percent': round(float(Rwp), 3),
        'Rp_percent': round(float(Rp), 3),
        'Rexp_percent': round(float(Rexp), 3),
        'GOF': round(float(GOF), 3),
        'chi2_reduced': round(float(GOF**2), 3),
        'n_observations': int(Nobs),
        'n_refined_variables': int(Nvar),
        'two_theta_range_deg': [float(x[0]), float(x[-1])],
    },
    'software': 'GSAS-II (scriptable) ' + str(gpx.data['Controls']['data'].get('LastSavedUsing', '')),
}
formula = {'CuWO4': 'CuWO4', 'WO3': 'WO3'}
sg = {'CuWO4': 'P-1 (#2)', 'WO3': 'P2_1/n (#14, monoclinic gamma-WO3)'}
for n in ['CuWO4', 'WO3']:
    c, ce = cells[n]
    out['phases'].append({
        'name': n,
        'formula': formula[n],
        'space_group': sg[n],
        'cif': cifname[n],
        'weight_fraction': round(float(wt[n]), 4),
        'weight_fraction_esd_statistical': round(float(wsig[n]), 4),
        'weight_fraction_percent': round(100*float(wt[n]), 2),
        'lattice': {k: round(float(c[k]), 5) for k in c},
        'lattice_esd': {k: round(float(ce[k]), 5) for k in ce},
        'n_reflections': rf[n]['n_reflections'],
        'RF_percent': rf[n]['RF_percent'],
    })
out['notes'] = {
    'weight_fraction_basis': 'normalized over the two modeled crystalline phases; '
                             'no internal standard, so any amorphous content is not included',
    'weight_fraction_uncertainty_realistic': 'WO3 = 2.5 +/- 0.2 wt% (spread over reasonable model '
                                             'variants: WO3 Uiso, Ka2 ratio, polarization, zero/'
                                             'displacement, WO3 microstrain); the quoted esd is '
                                             'the statistical value only',
    'phases_tested_and_rejected': [
        'CuO (tenorite): phase fraction refines to 0.00 wt%, Rwp worsens 3.78 -> 3.87',
        'Cu2O (cuprite): phase fraction refines to 0.00 wt%',
        'Cu3WO6: strongest lines (320 near 33.2 deg, 210 near 20.5 deg) absent from the data',
        'Cu2WO4: strong low-angle lines near 11.6, 13.4, 18.3 deg absent from the data',
        'CuWO4-II (high-pressure P-1 polymorph): refines to 0.2 wt% with no significant '
        'Rwp change (3.7788 -> 3.7731); not distinguishable from the main phase'],
    'estimated_detection_limit': 'about 0.5 wt% for a well-crystallized heavy-metal oxide '
                                 'in this pattern',
    'implied_cation_ratio': 'Cu:W = 0.967:1 (3.4 mol% W excess) from the two modeled phases',
    'single_phase_control': 'CuWO4 alone with the same protocol gives Rwp = 8.58%, GOF = 3.54',
}
json.dump(out, open('result.json', 'w'), indent=2)
print(json.dumps(out, indent=2))
gpx.save()
