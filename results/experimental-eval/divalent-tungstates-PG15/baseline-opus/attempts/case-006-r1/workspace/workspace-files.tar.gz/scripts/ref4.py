"""Fourth pass: CuWO4 + WO3, full stepwise Rietveld."""
import os, sys, numpy as np
os.chdir('<ATTEMPT_WORKSPACE>')
import GSASIIscriptable as G2sc

def wfrac(gpx):
    out = {}
    for p in gpx.phases():
        hid = list(p.data['Histograms'])[0]
        sc = p.data['Histograms'][hid]['Scale'][0]
        out[p.name] = sc * G2sc.G2mth.getMass(p.data['General'])
    tot = sum(out.values())
    return {k: v/tot for k, v in out.items()}

def rep(gpx, h, tag):
    print(f'--- {tag}: Rwp = {h.get_wR():.4f}  ' +
          '  '.join(f'{k}={v*100:.2f}%' for k, v in wfrac(gpx).items()))
    sys.stdout.flush()

gpx = G2sc.G2Project(newgpx='work/step4.gpx')
h = gpx.add_powder_histogram('work/pattern.xy', 'work/lab.instprm', fmthint='Topas xye')
phs = {}
for name, cif, sc0 in [('CuWO4', 'cifs/CuWO4_ambient.cif', 1.0),
                       ('WO3', 'cifs/1528915.cif', 0.02)]:
    p = gpx.add_phase(cif, phasename=name, histograms=[h])
    p.data['Histograms'][list(p.data['Histograms'])[0]]['Scale'] = [sc0, False]
    phs[name] = p

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True},
                   'Sample Parameters': ['Scale', 'Shift']})
gpx.do_refinements([{}]); rep(gpx, h, 'bkg+scale+shift')

for p in phs.values():
    p.set_HAP_refinements({'Scale': True})
h.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']})
phs['CuWO4'].set_refinements({'Cell': True})
gpx.do_refinements([{}]); rep(gpx, h, 'frac+profile+cell')

phs['WO3'].set_refinements({'Cell': True})
gpx.do_refinements([{}]); rep(gpx, h, 'WO3 cell')

h.set_refinements({'Instrument Parameters': ['SH/L']})
gpx.do_refinements([{}]); rep(gpx, h, 'SH/L')

# switch broadening to per-phase microstrain + size, release global X/Y
for p in phs.values():
    p.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True},
                           'Size': {'type': 'isotropic', 'refine': True}})
h.clear_refinements({'Instrument Parameters': ['X', 'Y']})
gpx.do_refinements([{}]); rep(gpx, h, 'size+mustrain')

# atom coordinates of major phase
phs['CuWO4'].set_refinements({'Atoms': {'all': 'XU'}})
gpx.do_refinements([{}]); rep(gpx, h, 'CuWO4 atoms XU')

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True}})
gpx.do_refinements([{}]); rep(gpx, h, 'bkg 12')

for name, p in phs.items():
    print(name, {k: round(v, 5) for k, v in p.get_cell().items()})
    for a in p.atoms():
        print('   ', a.label, a.element, [round(c, 4) for c in a.coordinates], a.uiso)
print('inst', {k: h.data['Instrument Parameters'][0][k][1] for k in ['U','V','W','X','Y','Zero','SH/L']})
print('shift', h.data['Sample Parameters']['Shift'])
gpx.save()
