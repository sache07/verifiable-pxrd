import warnings; warnings.filterwarnings('ignore')
from pymatgen.core import Structure, Lattice
from pymatgen.analysis.diffraction.xrd import XRDCalculator

# ambient-pressure CuWO4 (P-1), Forsyth/Kihlborg-type cell + coordinates
lat = Lattice.from_parameters(4.7026, 5.8389, 4.8784, 91.677, 92.469, 82.805)
species = ['Cu', 'W', 'O', 'O', 'O', 'O']
coords = [[0.4918, 0.6605, 0.2491],
          [0.0211, 0.1770, 0.2559],
          [0.2503, 0.3542, 0.4256],
          [0.2174, 0.8828, 0.4261],
          [0.7399, 0.3809, 0.0929],
          [0.7796, 0.9038, 0.0595]]
s = Structure.from_spacegroup('P-1', lat, species, coords)
s.to(filename='cifs/CuWO4_ambient.cif')
c = XRDCalculator(wavelength=1.540598)
p = c.get_pattern(s, two_theta_range=(10, 70))
for x, y, h in zip(p.x, p.y, p.hkls):
    if y > 3:
        print(f"{x:8.3f} {y:7.1f} {h[0]['hkl']}")
