"""Control refinement: CuWO4 only (same protocol as ref_final.py)."""
import os, sys
os.chdir('<ATTEMPT_WORKSPACE>')
import GSASIIscriptable as G2sc

gpx = G2sc.G2Project(newgpx='work/single.gpx')
h = gpx.add_powder_histogram('work/pattern.xy', 'work/lab.instprm', fmthint='Topas xye')
p = gpx.add_phase('cifs/CuWO4_start.cif', phasename='CuWO4', histograms=[h])

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True},
                   'Sample Parameters': ['Scale', 'Shift']})
gpx.do_refinements([{}])
h.set_refinements({'Instrument Parameters': ['U', 'V', 'W']})
p.set_refinements({'Cell': True})
gpx.do_refinements([{}])
h.set_refinements({'Instrument Parameters': ['SH/L', 'X', 'Y']})
gpx.do_refinements([{}])
nO = [i for i, a in enumerate(p.atoms()) if a.element == 'O']
gpx.add_EquivConstr([f'0::AUiso:{i}' for i in nO])
p.set_refinements({'Atoms': {'all': 'XU'}})
gpx.do_refinements([{}])
h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True}})
gpx.do_refinements([{}])
h.data['Instrument Parameters'][0]['Y'][1] = 0.0
h.clear_refinements({'Instrument Parameters': ['Y']})
p.set_HAP_refinements({'Mustrain': {'type': 'generalized', 'refine': True}})
gpx.do_refinements([{}]); gpx.do_refinements([{}]); gpx.do_refinements([{}])
r = gpx.data['Covariance']['data']['Rvals']
print('SINGLE-PHASE STATS', {k: round(r[k], 4) for k in ['Rwp', 'GOF', 'chisq', 'Nvars'] if k in r})
print('get_wR', h.get_wR())
gpx.save()
