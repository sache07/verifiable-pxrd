import numpy as np, sys
d = np.loadtxt(sys.argv[1], delimiter=',', skiprows=1)
x, y = d[:,0], d[:,1]
print("range", x.min(), x.max(), "step", np.median(np.diff(x)), "npts", len(x))
print("Imax", y.max(), "at", x[y.argmax()], "Imin", y.min())
# crude background via rolling min
from numpy.lib.stride_tricks import sliding_window_view
w = 201
pad = np.pad(y, w//2, mode='edge')
bg = sliding_window_view(pad, w).min(axis=1)
# smooth bg
k = np.ones(301)/301
bg = np.convolve(np.pad(bg, 150, mode='edge'), k, mode='valid')
ys = np.convolve(np.pad(y,5,mode='edge'), np.ones(11)/11, mode='valid')
net = ys - bg
thr = 0.01*net.max()
peaks=[]
for i in range(2, len(x)-2):
    if net[i] > thr and net[i] >= net[i-1] and net[i] >= net[i+1] and net[i]>net[i-2] and net[i]>net[i+2]:
        peaks.append((x[i], net[i]))
# merge close
merged=[]
for p in peaks:
    if merged and p[0]-merged[-1][0] < 0.08:
        if p[1] > merged[-1][1]: merged[-1]=p
    else: merged.append(p)
lam=1.540598
print(f"{'2theta':>9} {'d':>8} {'Inet':>9} {'I%':>6}")
mx=max(p[1] for p in merged)
for t,I in merged:
    dsp = lam/(2*np.sin(np.radians(t/2)))
    print(f"{t:9.4f} {dsp:8.4f} {I:9.1f} {100*I/mx:6.1f}")
print("npeaks", len(merged))
