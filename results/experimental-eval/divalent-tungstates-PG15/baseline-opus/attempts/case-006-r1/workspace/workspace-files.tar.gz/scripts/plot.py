import sys, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
d = np.genfromtxt(sys.argv[1], delimiter=',', names=True)
x, yo, yc, df = d['x'], d['yobs'], d['ycalc'], d['diff']
fig, ax = plt.subplots(3, 1, figsize=(16, 11))
for a, (lo, hi) in zip(ax, [(9.9, 40), (40, 70), (70, 100.1)]):
    m = (x >= lo) & (x <= hi)
    a.plot(x[m], yo[m], 'k.', ms=2, label='obs')
    a.plot(x[m], yc[m], 'r-', lw=0.8, label='calc')
    a.plot(x[m], df[m] - 0.12*yo[m].max(), 'b-', lw=0.6, label='diff')
    a.set_xlim(lo, hi); a.legend(fontsize=7)
plt.tight_layout(); plt.savefig(sys.argv[2], dpi=110)
print('saved', sys.argv[2])
