"""Continue from v_XY.gpx: test extra model terms."""
import os, sys, shutil
os.chdir('<ATTEMPT_WORKSPACE>')
import GSASIIscriptable as G2sc

mode = sys.argv[1]
src, dst = 'work/v_XY.gpx', f'work/try_{mode}.gpx'
shutil.copy(src, dst)
gpx = G2sc.G2Project(dst)
h = gpx.histograms()[0]
phs = {p.name: p for p in gpx.phases()}

def wfrac():
    o = {}
    for p in gpx.phases():
        hid = list(p.data['Histograms'])[0]
        o[p.name] = p.data['Histograms'][hid]['Scale'][0] * G2sc.G2mth.getMass(p.data['General'])
    t = sum(o.values())
    return {k: v/t for k, v in o.items()}

def rep(tag):
    print(f'--- {tag}: Rwp={h.get_wR():.4f} ' +
          ' '.join(f'{k}={v*100:.3f}%' for k, v in wfrac().items()), flush=True)

rep('start')
if mode == 'po':
    phs['CuWO4'].set_HAP_refinements({'Pref.Ori.': {'type': 'SH', 'order': 4, 'refine': True}})
elif mode == 'po6':
    phs['CuWO4'].set_HAP_refinements({'Pref.Ori.': {'type': 'SH', 'order': 6, 'refine': True}})
elif mode == 'mustr':
    phs['CuWO4'].set_HAP_refinements({'Mustrain': {'type': 'generalized', 'refine': True}})
elif mode == 'hstrain':
    phs['CuWO4'].set_HAP_refinements({'HStrain': True})
elif mode == 'wo3u':
    for a in phs['WO3'].atoms():
        a.uiso = 0.01
    phs['WO3'].set_refinements({'Atoms': {'all': 'U'}})
elif mode == 'sizeaniso':
    phs['CuWO4'].set_HAP_refinements({'Size': {'type': 'uniaxial', 'direction': [0, 1, 0], 'refine': True}})
gpx.do_refinements([{}]); rep(mode)
gpx.do_refinements([{}]); rep(mode + ' again')
r = gpx.data['Covariance']['data']['Rvals']
print('STATS', {k: r[k] for k in ['Rwp', 'GOF', 'Nvars'] if k in r})
gpx.save()
