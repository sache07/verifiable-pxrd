"""Rough FWHM of isolated peaks."""
import numpy as np
d = np.loadtxt('inputs/pattern.csv', delimiter=',', skiprows=1)
x, y = d[:, 0], d[:, 1]
for c in [15.60, 19.31, 26.27, 28.97, 37.16, 48.97, 53.47, 64.14, 82.86, 99.67]:
    m = (x > c-1.0) & (x < c+1.0)
    xi, yi = x[m], y[m]
    bg = np.percentile(yi, 10)
    pk = yi.max() - bg
    half = bg + pk/2
    above = xi[yi > half]
    print(f"{c:7.2f}  Imax={pk:8.0f}  FWHM~{above.max()-above.min():6.3f}")
