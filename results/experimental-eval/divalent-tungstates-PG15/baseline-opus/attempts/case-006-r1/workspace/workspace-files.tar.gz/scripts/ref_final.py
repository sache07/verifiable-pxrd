"""Final Rietveld refinement of the CuO + WO3 (800 C) product pattern.

Model: CuWO4 (P-1, cuprotungstite-type) + residual gamma-WO3 (P2_1/n).
Usage: ref_final.py <outgpx> [--po] [--nomustr]
"""
import os, sys
os.chdir('<ATTEMPT_WORKSPACE>')
import GSASIIscriptable as G2sc

out = sys.argv[1]
PO = '--po' in sys.argv
MUSTR = '--nomustr' not in sys.argv

def wfrac(gpx):
    o = {}
    for p in gpx.phases():
        hid = list(p.data['Histograms'])[0]
        o[p.name] = p.data['Histograms'][hid]['Scale'][0] * G2sc.G2mth.getMass(p.data['General'])
    t = sum(o.values())
    return {k: v/t for k, v in o.items()}

def rep(gpx, h, tag):
    print(f'--- {tag}: Rwp={h.get_wR():.4f} ' +
          ' '.join(f'{k}={v*100:.3f}%' for k, v in wfrac(gpx).items()), flush=True)

gpx = G2sc.G2Project(newgpx=out)
h = gpx.add_powder_histogram('work/pattern.xy', 'work/lab.instprm', fmthint='Topas xye')
phs = {}
EXTRA = {'CuO': 'cifs/1011194.cif', 'Cu2O': 'cifs/1010941.cif',
         'Cu3WO6': 'cifs/1527404.cif', 'Cu2WO4': 'cifs/2002403.cif',
         'CuWO4-II': 'cifs/4000806.cif'}
plist = [('CuWO4', 'cifs/CuWO4_start.cif', 1.0), ('WO3', 'cifs/1528915.cif', 0.02)]
for a in sys.argv[2:]:
    if a in EXTRA:
        plist.append((a, EXTRA[a], 0.01))
for name, cif, sc0 in plist:
    p = gpx.add_phase(cif, phasename=name, histograms=[h])
    p.data['Histograms'][list(p.data['Histograms'])[0]]['Scale'] = [sc0, False]
    phs[name] = p
# WO3 displacement parameters are absent in the source CIF; fix at typical RT values
for a in phs['WO3'].atoms():
    a.uiso = 0.006 if a.element == 'W' else 0.012

# A: background, overall scale, sample displacement
h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True},
                   'Sample Parameters': ['Scale', 'Shift']})
gpx.do_refinements([{}]); rep(gpx, h, 'A bkg+scale+shift')

# B: phase fractions (overall scale held), Gaussian widths, major-phase cell
h.clear_refinements({'Sample Parameters': ['Scale']})
for p in phs.values():
    p.set_HAP_refinements({'Scale': True})
h.set_refinements({'Instrument Parameters': ['U', 'V', 'W']})
phs['CuWO4'].set_refinements({'Cell': True})
gpx.do_refinements([{}]); rep(gpx, h, 'B frac+UVW+cell')

# C: minor-phase cell, axial-divergence asymmetry
phs['WO3'].set_refinements({'Cell': True})
h.set_refinements({'Instrument Parameters': ['SH/L']})
gpx.do_refinements([{}]); rep(gpx, h, 'C WO3cell+SHL')

# D: Lorentzian widths
h.set_refinements({'Instrument Parameters': ['X', 'Y']})
gpx.do_refinements([{}]); rep(gpx, h, 'D X+Y')

# E: CuWO4 coordinates and Uiso (all O constrained to a common Uiso)
nO = [i for i, a in enumerate(phs['CuWO4'].atoms()) if a.element == 'O']
gpx.add_EquivConstr([f'0::AUiso:{i}' for i in nO])
phs['CuWO4'].set_refinements({'Atoms': {'all': 'XU'}})
gpx.do_refinements([{}]); rep(gpx, h, 'E CuWO4 X+U')

# F: more background terms
h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True}})
gpx.do_refinements([{}]); rep(gpx, h, 'F bkg12')

# G: anisotropic (generalized) microstrain broadening of the major phase
if MUSTR:
    # generalized microstrain supplies the tan(theta) Lorentzian term; drop the
    # redundant global Y so it cannot go negative
    h.data['Instrument Parameters'][0]['Y'][1] = 0.0
    h.clear_refinements({'Instrument Parameters': ['Y']})
    phs['CuWO4'].set_HAP_refinements({'Mustrain': {'type': 'generalized', 'refine': True}})
    gpx.do_refinements([{}]); rep(gpx, h, 'G mustrain-gen')
    gpx.do_refinements([{}]); rep(gpx, h, 'G mustrain-gen (2)')

if PO:
    phs['CuWO4'].set_HAP_refinements({'Pref.Ori.': {'type': 'SH', 'order': 4, 'refine': True}})
    gpx.do_refinements([{}]); rep(gpx, h, 'H pref.ori')

gpx.do_refinements([{}]); rep(gpx, h, 'final')

print('inst', {k: round(h.data['Instrument Parameters'][0][k][1], 5)
               for k in ['U', 'V', 'W', 'X', 'Y', 'Zero', 'SH/L']})
print('shift', h.data['Sample Parameters']['Shift'][0])
for name, p in phs.items():
    hid = list(p.data['Histograms'])[0]
    hd = p.data['Histograms'][hid]
    print(name, 'cell', {k: round(v, 5) for k, v in p.get_cell().items()})
    print('   scale', hd['Scale'][0], 'size', hd['Size'][1][0], 'mustrain', hd['Mustrain'][0], hd['Mustrain'][1][:1], hd['Mustrain'][4] if len(hd['Mustrain']) > 4 else '')
    for a in p.atoms():
        print('   ', a.label, a.element, [round(c, 4) for c in a.coordinates], round(a.uiso, 5))
r = gpx.data['Covariance']['data']['Rvals']
print('STATS', {k: r[k] for k in ['Rwp', 'GOF', 'chisq', 'Nobs', 'Nvars'] if k in r})
print('MSG', r.get('msg'))
gpx.save()
