"""Rietveld variants: CuWO4 (P-1) + gamma-WO3 (+ optional CuO).

Usage: ref6.py <outgpx> <profile-mode> [extra phases...]
  profile-mode: XY | X | MS | MSZ
"""
import os, sys, numpy as np
os.chdir('<ATTEMPT_WORKSPACE>')
import GSASIIscriptable as G2sc

out, mode = sys.argv[1], sys.argv[2]
extra = sys.argv[3:]

CIFS = {'CuWO4': 'cifs/CuWO4_start.cif', 'WO3': 'cifs/1528915.cif',
        'CuO': 'cifs/1011194.cif', 'Cu2O': 'cifs/1010941.cif',
        'Cu3WO6': 'cifs/1527404.cif'}

def wfrac(gpx):
    o = {}
    for p in gpx.phases():
        hid = list(p.data['Histograms'])[0]
        o[p.name] = p.data['Histograms'][hid]['Scale'][0] * G2sc.G2mth.getMass(p.data['General'])
    t = sum(o.values())
    return {k: v/t for k, v in o.items()}

def rep(gpx, h, tag):
    print(f'--- {tag}: Rwp={h.get_wR():.4f} ' +
          ' '.join(f'{k}={v*100:.3f}%' for k, v in wfrac(gpx).items()), flush=True)

gpx = G2sc.G2Project(newgpx=out)
h = gpx.add_powder_histogram('work/pattern.xy', 'work/lab.instprm', fmthint='Topas xye')
phs = {}
for name in ['CuWO4', 'WO3'] + extra:
    p = gpx.add_phase(CIFS[name], phasename=name, histograms=[h])
    p.data['Histograms'][list(p.data['Histograms'])[0]]['Scale'] = [1.0 if name == 'CuWO4' else 0.02, False]
    phs[name] = p

# A: background, overall scale, sample displacement
h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True},
                   'Sample Parameters': ['Scale', 'Shift']})
gpx.do_refinements([{}]); rep(gpx, h, 'A bkg+scale+shift')

# hold overall scale from here on; phase fractions carry the scaling
h.clear_refinements({'Sample Parameters': ['Scale']})
for p in phs.values():
    p.set_HAP_refinements({'Scale': True})
h.set_refinements({'Instrument Parameters': ['U', 'V', 'W']})
phs['CuWO4'].set_refinements({'Cell': True})
gpx.do_refinements([{}]); rep(gpx, h, 'B frac+UVW+cell')

phs['WO3'].set_refinements({'Cell': True})
h.set_refinements({'Instrument Parameters': ['SH/L']})
gpx.do_refinements([{}]); rep(gpx, h, 'C WO3cell+SHL')

# D: Lorentzian broadening treatment
if mode == 'XY':
    h.set_refinements({'Instrument Parameters': ['X', 'Y']})
elif mode == 'X':
    h.set_refinements({'Instrument Parameters': ['X']})
elif mode in ('MS', 'MSZ'):
    for p in phs.values():
        p.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True},
                               'Size': {'type': 'isotropic', 'refine': True}})
gpx.do_refinements([{}]); rep(gpx, h, f'D broadening({mode})')

# E: atoms of CuWO4 (O Uiso constrained equal)
nO = [i for i, a in enumerate(phs['CuWO4'].atoms()) if a.element == 'O']
gpx.add_EquivConstr([f'0::AUiso:{i}' for i in nO])
phs['CuWO4'].set_refinements({'Atoms': {'all': 'XU'}})
gpx.do_refinements([{}]); rep(gpx, h, 'E CuWO4 X+U')

# F: background terms
h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True}})
gpx.do_refinements([{}]); rep(gpx, h, 'F bkg12')
if mode == 'MSZ':
    h.set_refinements({'Instrument Parameters': ['Zero']})
    gpx.do_refinements([{}]); rep(gpx, h, 'G zero')
gpx.do_refinements([{}]); rep(gpx, h, 'final')

print('inst', {k: round(h.data['Instrument Parameters'][0][k][1], 5)
               for k in ['U', 'V', 'W', 'X', 'Y', 'Zero', 'SH/L']})
print('shift', [round(v, 3) if isinstance(v, float) else v for v in h.data['Sample Parameters']['Shift']])
for name, p in phs.items():
    hid = list(p.data['Histograms'])[0]
    hd = p.data['Histograms'][hid]
    print(name, 'cell', {k: round(v, 5) for k, v in p.get_cell().items()})
    print('   size', round(hd['Size'][1][0], 4), 'mustrain', round(hd['Mustrain'][1][0], 1),
          'scale', hd['Scale'][0])
    for a in p.atoms():
        print('   ', a.label, a.element, [round(c, 4) for c in a.coordinates], round(a.uiso, 5))
r = gpx.data['Covariance']['data']['Rvals']
print('STATS', {k: r[k] for k in ['Rwp', 'GOF', 'chisq', 'Nobs', 'Nvars'] if k in r})
print('MSG', r.get('msg'))
gpx.save()
