import sys, warnings
warnings.filterwarnings('ignore')
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator
c = XRDCalculator(wavelength=1.540598)
for f in sys.argv[1:]:
    s = Structure.from_file(f)
    p = c.get_pattern(s, two_theta_range=(10, 70))
    print('===', f, s.composition.reduced_formula)
    idx = sorted(range(len(p.x)), key=lambda i: -p.y[i])[:25]
    for i in sorted(idx, key=lambda i: p.x[i]):
        hkl = p.hkls[i][0]['hkl']
        print(f"  {p.x[i]:8.3f} {p.y[i]:7.1f} {hkl}")
