"""Robustness tests on the final model (copies final_b.gpx)."""
import os, sys, shutil
os.chdir('<ATTEMPT_WORKSPACE>')
import GSASIIscriptable as G2sc
mode = sys.argv[1]
dst = f'work/rb_{mode}.gpx'
shutil.copy('work/final_b.gpx', dst)
gpx = G2sc.G2Project(dst)
h = gpx.histograms()[0]
phs = {p.name: p for p in gpx.phases()}

def wf():
    o = {}
    for p in gpx.phases():
        hid = list(p.data['Histograms'])[0]
        o[p.name] = p.data['Histograms'][hid]['Scale'][0] * G2sc.G2mth.getMass(p.data['General'])
    t = sum(o.values())
    return {k: round(v*100, 3) for k, v in o.items()}

if mode == 'zero':
    h.set_refinements({'Instrument Parameters': ['Zero']})
elif mode == 'nodisp':   # zero-point instead of sample displacement
    h.data['Sample Parameters']['Shift'] = [0.0, False]
    h.set_refinements({'Instrument Parameters': ['Zero']})
elif mode == 'transparency':
    h.set_refinements({'Sample Parameters': ['Transparency']})
elif mode == 'wo3iso':
    phs['WO3'].set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}})
elif mode == 'wo3u06':
    for a in phs['WO3'].atoms():
        a.uiso = 0.003 if a.element == 'W' else 0.006
elif mode == 'wo3u20':
    for a in phs['WO3'].atoms():
        a.uiso = 0.010 if a.element == 'W' else 0.020
elif mode == 'polariz':
    h.data['Instrument Parameters'][0]['Polariz.'][1] = 0.5
elif mode == 'ka2':
    h.data['Instrument Parameters'][0]['I(L2)/I(L1)'][1] = 0.48
gpx.do_refinements([{}])
gpx.do_refinements([{}])
r = gpx.data['Covariance']['data']['Rvals']
print(f"{mode}: Rwp={r['Rwp']:.4f} GOF={r['GOF']:.3f} frac={wf()} "
      f"zero={h.data['Instrument Parameters'][0]['Zero'][1]:.5f} "
      f"shift={h.data['Sample Parameters']['Shift'][0]:.1f} "
      f"transp={h.data['Sample Parameters'].get('Transparency', [0])[0]:.2f}")
print('   CuWO4 cell', {k: round(v, 5) for k, v in phs['CuWO4'].get_cell().items()})
gpx.save()
