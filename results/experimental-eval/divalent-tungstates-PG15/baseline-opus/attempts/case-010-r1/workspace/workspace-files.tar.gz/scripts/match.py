import numpy as np, json, os, glob
d=np.loadtxt('inputs/pattern.csv',delimiter=',',skiprows=1)
x,y=d[:,0],d[:,1]
import scipy.ndimage as ndi
bg=ndi.uniform_filter1d(ndi.minimum_filter1d(y,401),401)
yo=np.clip(y-bg,0,None)
yo/=yo.max()
meta=json.load(open('out/mnwo.json'))
info={os.path.basename(e['path']).replace('.cif',''):e for e in meta}
rows=[]
for f in sorted(glob.glob('tmpwork/simproj/*_calc.npy')):
    name=os.path.basename(f).replace('_calc.npy','')
    a=np.load(f); xc,yc=a[0],a[1]
    yi=np.interp(x,xc,yc)
    if yi.max()<=0: continue
    yi/=yi.max()
    # cosine similarity
    sim=float(np.dot(yi,yo)/np.sqrt(np.dot(yi,yi)*np.dot(yo,yo)))
    # coverage: fraction of calc intensity that lies where obs has signal
    rows.append((sim,name,info[name]['formula'],info[name]['sg']))
for r in sorted(rows,reverse=True)[:30]:
    print(f"{r[0]:.3f}  {r[1]:<10} {r[2]:<14} {r[3]}")
