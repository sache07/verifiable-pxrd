import sys, numpy as np
import GSASII.GSASIIscriptable as G2sc
p=G2sc.G2Project(sys.argv[1])
for ph in p.phases():
    print('==',ph.name, ph.data['General']['SGData']['SpGrp'])
    for a in ph.atoms():
        print(f"  {a.label:6s} {a.element:3s} {a.coordinates[0]:9.5f} {a.coordinates[1]:9.5f} {a.coordinates[2]:9.5f}  Uiso={a.uiso:.5f} occ={a.occupancy}")
