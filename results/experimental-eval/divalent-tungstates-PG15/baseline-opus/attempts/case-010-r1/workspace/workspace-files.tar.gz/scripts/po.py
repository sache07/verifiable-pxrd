import os, sys, shutil, numpy as np
sys.path.insert(0,'scripts')
import GSASII.GSASIIscriptable as G2sc
base,new = sys.argv[1],sys.argv[2]
mode = sys.argv[3]   # e.g. "WO3:MD:1,0,0" or "WO3:SH:4" ; multiple separated by ';'
for f in [new,new.replace('.gpx','.bak0.gpx')]:
    if os.path.exists(f): os.remove(f)
shutil.copy(base,new)
p=G2sc.G2Project(new); h=p.histogram(0)
print('start',h.get_wR())
for spec in mode.split(';'):
    if not spec: continue
    parts=spec.split(':'); name=parts[0]
    ph=p.phase(name)
    if parts[1]=='MD':
        ax=[int(v) for v in parts[2].split(',')]
        ph.set_HAP_refinements({'Pref.Ori.':{'type':'MD','direction':ax,'refine':True}})
    else:
        ph.set_HAP_refinements({'Pref.Ori.':{'type':'SH','order':int(parts[2]),'refine':True}})
def run(tag,**kw):
    p.do_refinements([kw]); print(f'  [{tag}] Rwp={h.get_wR():.3f}')
run('po'); run('po2'); run('all')
for q in p.phases():
    hd=q.data['Histograms'][list(q.data['Histograms'])[0]]
    print('PO',q.name,hd['Pref.Ori.'][:5])
