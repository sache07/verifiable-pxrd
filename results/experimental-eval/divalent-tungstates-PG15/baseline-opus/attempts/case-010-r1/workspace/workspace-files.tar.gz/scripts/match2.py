import numpy as np, json, os, glob
import scipy.ndimage as ndi
d=np.loadtxt('inputs/pattern.csv',delimiter=',',skiprows=1)
x,y=d[:,0],d[:,1]
bg=ndi.uniform_filter1d(ndi.minimum_filter1d(y,401),401)
yo=np.clip(y-bg,0,None)
meta=json.load(open('out/mnwo.json'))
info={os.path.basename(e['path']).replace('.cif',''):e for e in meta}
shifts=np.arange(-0.6,0.61,0.02)
rows=[]
for f in sorted(glob.glob('tmpwork/simproj/*_calc.npy')):
    name=os.path.basename(f).replace('_calc.npy','')
    a=np.load(f); xc,yc=a[0],a[1]
    if yc.max()<=0: continue
    best=(-1,0)
    for s in shifts:
        yi=np.interp(x,xc+s,yc)
        if yi.max()<=0: continue
        sim=float(np.dot(yi,yo)/np.sqrt(np.dot(yi,yi)*np.dot(yo,yo)))
        if sim>best[0]: best=(sim,s)
    rows.append((best[0],best[1],name,info[name]['formula'],info[name]['sg']))
for r in sorted(rows,reverse=True)[:25]:
    print(f"{r[0]:.3f} shift{r[1]:+.2f}  {r[2]:<10} {r[3]:<14} {r[4]}")
print('---specific---')
for r in rows:
    if r[2] in ('1520200','2002703','1514230','1514103','1010586','9001963','1528915','2106293','1563541'):
        print(f"{r[0]:.3f} shift{r[1]:+.2f}  {r[2]:<10} {r[3]:<14} {r[4]}")
