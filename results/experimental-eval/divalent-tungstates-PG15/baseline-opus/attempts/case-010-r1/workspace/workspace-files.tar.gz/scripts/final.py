import os, sys, numpy as np, json
sys.path.insert(0,'scripts')
import GSASII.GSASIIscriptable as G2sc
from build import mk

gpxf = sys.argv[1]
mode = sys.argv[2] if len(sys.argv)>2 else 'shift'
PH=[('WO3','cifs_src/1528915.cif'),('Mn2O3','cifs_src/1514230.cif'),('MnWO4','cifs_src/MnWO4_ambient.cif')]
p,h=mk(gpxf,PH)
h.set_refinements({'Background':{'type':'chebyschev-1','no. coeffs':16,'refine':True}})
h.data['Sample Parameters']['Scale']=[1.0,False]
for ph in p.phases():
    hid=list(ph.data['Histograms'])[0]
    ph.data['Histograms'][hid]['Scale']=[1.0 if ph.name!='MnWO4' else 0.05, True]
maj=['WO3','Mn2O3']
def run(tag,**kw):
    p.do_refinements([kw]); print(f'  [{tag}] Rwp={h.get_wR():.4f}', flush=True)
run('bg+frac')
if mode=='shift': run('disp', set={'Sample Parameters':['Shift']})
else:             run('disp', set={'Instrument Parameters':['Zero']})
run('cell_maj', set={'Cell':True}, phases=maj)
run('uvw', set={'Instrument Parameters':['U','V','W']})
run('xy', set={'Instrument Parameters':['X','Y']})
run('rep')
run('atoms_maj', set={'Atoms':{'all':'XU'}}, phases=maj)
run('shl', set={'Instrument Parameters':['SH/L']})
run('rep2')
run('cell_all', set={'Cell':True}, phases=['MnWO4'])
run('rep3')
run('rep4')
for q in p.phases():
    print('CELL',q.name,{k:round(v,5) for k,v in q.get_cell().items()})
print('Shift',h.data['Sample Parameters']['Shift'])
print('Zero',h.data['Instrument Parameters'][0]['Zero'])
print('IP',{k:round(h.data['Instrument Parameters'][0][k][1],5) for k in ['U','V','W','X','Y','SH/L','Polariz.']})
