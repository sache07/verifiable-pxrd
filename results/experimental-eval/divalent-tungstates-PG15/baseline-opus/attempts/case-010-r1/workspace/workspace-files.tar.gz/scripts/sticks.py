import sys, os, numpy as np
import GSASII.GSASIIscriptable as G2sc
iprm, out = sys.argv[1], sys.argv[2]
cifs = sys.argv[3:]
tmp='tmpwork/simproj'; os.makedirs(tmp,exist_ok=True)
res={}
for c in cifs:
    name=os.path.basename(c).replace('.cif','')
    gpx=os.path.join(tmp,name+'.gpx')
    for f in [gpx,gpx.replace('.gpx','.bak0.gpx')]:
        if os.path.exists(f): os.remove(f)
    try:
        p=G2sc.G2Project(newgpx=gpx)
        h=p.add_simulated_powder_histogram("sim",iprm,10.,100.,Npoints=4000,phases=[],scale=1.0)
        ph=p.add_phase(c,phasename=name,histograms=[h])
        p.do_refinements([{}])
        refl=p.histogram(0).reflections()[name]['RefList']
        y=np.array(p.histogram(0).getdata('ycalc'))
        x=np.array(p.histogram(0).getdata('x'))
        np.save(os.path.join(tmp,name+'_calc.npy'),np.vstack([x,y]))
        # refl cols: h k l mult d pos sig gam Fosq Fcsq phase Icorr Prfo Trans Ext
        arr=np.array([[r[0],r[1],r[2],r[4],r[5],r[9]*r[3]*r[11]] for r in refl])
        res[name]=arr
    except Exception as e:
        print('FAIL',name,e); continue
np.savez(out, **res)
