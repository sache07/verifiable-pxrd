import os, sys, numpy as np, json
sys.path.insert(0,'scripts')
import GSASII.GSASIIscriptable as G2sc
from build import mk, seq

gpxf=sys.argv[1]; phases=[]
for a in sys.argv[2:]:
    n,c=a.split('=');phases.append((n,c))
p,h=mk(gpxf,phases)
h.set_refinements({'Background':{'type':'chebyschev-1','no. coeffs':12,'refine':True},
                   'Sample Parameters':['Scale']})
for ph in p.phases(): ph.set_HAP_refinements({'Scale':True})
steps=[{},
 {'set':{'Sample Parameters':['Shift']}},
 {'set':{'Cell':True}},
 {'set':{'Instrument Parameters':['U','V','W']}},
 {'set':{'Instrument Parameters':['X','Y']}},
 {'set':{'Mustrain':{'type':'isotropic','refine':True},'Size':{'type':'isotropic','refine':True}}},
 {'set':{'Atoms':{'all':'XU'}}},
 {'set':{'Mustrain':{'type':'uniaxial','refine':True}}},
 {},
 {'set':{'Instrument Parameters':['SH/L']}},
 {},
]
seq(p,h,steps)
for ph in p.phases():
    print('CELL',ph.name,{k:round(v,5) for k,v in ph.get_cell().items()})
print('Shift',h.data['Sample Parameters']['Shift'])
