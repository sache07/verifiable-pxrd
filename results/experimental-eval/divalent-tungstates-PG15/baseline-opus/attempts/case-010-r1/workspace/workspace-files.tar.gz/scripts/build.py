import os, sys, numpy as np, json
import GSASII.GSASIIscriptable as G2sc

def mk(gpx, phases, instprm='out/inst.instprm'):
    for f in [gpx, gpx.replace('.gpx','.bak0.gpx')]:
        if os.path.exists(f): os.remove(f)
    p=G2sc.G2Project(newgpx=gpx)
    h=p.add_powder_histogram('out/pattern.xy',instprm,fmthint='Topas xye')
    for name,cif in phases:
        p.add_phase(cif,phasename=name,histograms=[h])
    return p,h

def seq(p,h,steps,tag=''):
    for i,s in enumerate(steps):
        p.do_refinements([s])
        print(f'  [{tag}{i}] Rwp={h.get_wR():.3f}')
    return h.get_wR()
