import os, sys, shutil, numpy as np
sys.path.insert(0,'scripts')
import GSASII.GSASIIscriptable as G2sc
src, name = sys.argv[1], sys.argv[2]
tmp='tmpwork/_iso.gpx'
for f in [tmp,tmp.replace('.gpx','.bak0.gpx')]:
    if os.path.exists(f): os.remove(f)
shutil.copy(src,tmp)
p=G2sc.G2Project(tmp); h=p.histogram(0)
x=np.array(h.getdata('x')); yo=np.array(h.getdata('yobs')); ytot=np.array(h.getdata('ycalc'))
ph=p.phase(name); hid=list(ph.data['Histograms'])[0]
sc=ph.data['Histograms'][hid]['Scale'][0]
ph.data['Histograms'][hid]['Scale']=[0.0,False]
p.do_refinements([{'skip':True}] if False else [{'set':{},'call':None}]) if False else None
p.save()
p.do_refinements([{'skip':True}])
y0=np.array(p.histogram(0).getdata('ycalc'))
comp=ytot-y0
r=yo-(ytot-comp)   # residual of model without this phase
np.save('tmpwork/comp_%s.npy'%name, np.vstack([x,comp,r]))
w=1.0/np.maximum(yo,1)
s=np.sum(w*r*comp)/np.sum(w*comp*comp)
sig=1/np.sqrt(np.sum(w*comp*comp))
print(f'{name}: fitted scale of isolated component = {s:.4f} +- {sig:.4f}  ({s/sig:.1f} sigma)')
print(f'max component intensity {comp.max():.0f} at 2th {x[comp.argmax()]:.3f}')
top=np.argsort(-comp)[:400]
sel=sorted(set(np.round(x[top],1)))
print('component strongest regions:',sel[:20])
