import os, sys, numpy as np, json
sys.path.insert(0,'scripts')
import GSASII.GSASIIscriptable as G2sc
from build import mk, seq

gpxf=sys.argv[1]
main=sys.argv[2].split(',')   # phases with full refinement  name=cif
test=sys.argv[3].split(',') if len(sys.argv)>3 and sys.argv[3] else []
phases=[tuple(a.split('=')) for a in main+test]
mainN=[a.split('=')[0] for a in main]
p,h=mk(gpxf,phases)
h.set_refinements({'Background':{'type':'chebyschev-1','no. coeffs':12,'refine':True},
                   'Sample Parameters':['Scale']})
for ph in p.phases(): ph.set_HAP_refinements({'Scale':True})
steps=[{},
 {'set':{'Sample Parameters':['Shift']}},
 {'set':{'Cell':True},'phases':mainN},
 {'set':{'Instrument Parameters':['U','V','W']}},
 {'set':{'Instrument Parameters':['X','Y']}},
 {},
 {'set':{'Atoms':{'all':'XU'}},'phases':mainN},
 {},
 {'set':{'Instrument Parameters':['SH/L']}},
 {},
]
seq(p,h,steps)
for ph in p.phases():
    print('CELL',ph.name,{k:round(v,5) for k,v in ph.get_cell().items()})
print('Shift',h.data['Sample Parameters']['Shift'][0])
