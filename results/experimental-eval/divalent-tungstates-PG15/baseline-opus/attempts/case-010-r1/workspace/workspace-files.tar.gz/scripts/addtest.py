import os, sys, shutil, numpy as np
sys.path.insert(0,'scripts')
import GSASII.GSASIIscriptable as G2sc
base, newgpx, name, cif = sys.argv[1:5]
for f in [newgpx, newgpx.replace('.gpx','.bak0.gpx')]:
    if os.path.exists(f): os.remove(f)
shutil.copy(base,newgpx)
p=G2sc.G2Project(newgpx)
h=p.histogram(0)
print('start Rwp',h.get_wR())
ph=p.add_phase(cif,phasename=name,histograms=[h])
ph.set_HAP_refinements({'Scale':0.001})
ph.setHAPvalues({'Scale':[1e-4,True]})
def run(tag,**kw):
    p.do_refinements([kw]); print(f'  [{tag}] Rwp={h.get_wR():.3f}')
run('scale_only')
run('all', set={'Cell':True}, phases=[name])
run('rep')
for q in p.phases(): print('CELL',q.name,{k:round(v,5) for k,v in q.get_cell().items()})
