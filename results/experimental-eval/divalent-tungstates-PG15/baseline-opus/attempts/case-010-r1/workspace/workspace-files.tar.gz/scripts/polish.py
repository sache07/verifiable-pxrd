import os, sys, shutil, numpy as np, json
sys.path.insert(0,'scripts')
import GSASII.GSASIIscriptable as G2sc
base,new = sys.argv[1],sys.argv[2]
for f in [new,new.replace('.gpx','.bak0.gpx')]:
    if os.path.exists(f): os.remove(f)
shutil.copy(base,new)
p=G2sc.G2Project(new); h=p.histogram(0)
print('start Rwp',round(h.get_wR(),4))
ph=p.add_phase('cifs_src/MnWO4_ambient.cif',phasename='MnWO4',histograms=[h])
hid=list(ph.data['Histograms'])[0]
ph.data['Histograms'][hid]['Scale']=[1e-3,True]
def run(tag,**kw):
    p.do_refinements([kw]); print(f'  [{tag}] Rwp={h.get_wR():.4f}',flush=True)
run('scale'); run('scale2')
run('cellMnWO4', set={'Cell':True}, phases=['MnWO4'])
for i in range(4): run('all%d'%i)
for q in p.phases():
    print('CELL',q.name,{k:round(v,5) for k,v in q.get_cell().items()})
print('Shift',h.data['Sample Parameters']['Shift'])
print('IP',{k:h.data['Instrument Parameters'][0][k][1] for k in ['U','V','W','X','Y','SH/L','Zero','Polariz.']})
