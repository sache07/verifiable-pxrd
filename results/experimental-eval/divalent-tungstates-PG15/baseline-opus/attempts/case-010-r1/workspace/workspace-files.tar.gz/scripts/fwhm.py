import numpy as np
from scipy.optimize import curve_fit
d=np.loadtxt('inputs/pattern.csv',delimiter=',',skiprows=1); x,y=d[:,0],d[:,1]
def pv(t,A,c,f,eta,b0,b1):
    s=f/2
    g=np.exp(-4*np.log(2)*((t-c)/f)**2)
    l=1/(1+4*((t-c)/f)**2)
    return A*(eta*l+(1-eta)*g)+b0+b1*(t-c)
# isolated-ish peaks (single, no Ka2 overlap issues at low angle)
for c0,w in [(23.43,0.35),(26.91,0.35),(29.02,0.35),(33.26,0.30),(38.53,0.4),(47.52,0.4),(56.19,0.4),(62.52,0.45),(77.17,0.55)]:
    m=(x>c0-w)&(x<c0+w)
    try:
        popt,_=curve_fit(pv,x[m],y[m],p0=[y[m].max()-y[m].min(),c0,0.1,0.5,y[m].min(),0],maxfev=20000)
        print(f"2th={popt[1]:7.3f}  FWHM={abs(popt[2]):.4f}  eta={popt[3]:.2f}")
    except Exception as e: print(c0,'fail',e)
