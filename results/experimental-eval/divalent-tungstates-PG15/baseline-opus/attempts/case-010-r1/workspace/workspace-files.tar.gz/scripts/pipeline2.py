import os, sys, numpy as np, json
sys.path.insert(0,'scripts')
import GSASII.GSASIIscriptable as G2sc
from build import mk

gpxf  = sys.argv[1]
OFREE = sys.argv[2]=='Ofree'
UFIX  = {'W':0.006,'Mn':0.008,'O':0.010}
PH=[('WO3','cifs_src/WO3_gamma.cif'),('Mn2O3','cifs_src/1514230.cif')]
p,h=mk(gpxf,PH)
h.data['Instrument Parameters'][0]['Polariz.'][1]=0.7
h.set_refinements({'Background':{'type':'chebyschev-1','no. coeffs':16,'refine':True}})
h.data['Sample Parameters']['Scale']=[1.0,False]
for q in p.phases():
    q.data['Histograms'][list(q.data['Histograms'])[0]]['Scale']=[1.0,True]
    for a in q.atoms(): a.uiso=UFIX[a.element]
def run(tag,**kw):
    p.do_refinements([kw]); print(f'  [{tag}] Rwp={h.get_wR():.4f}',flush=True)
run('bg+frac')
run('disp',  set={'Sample Parameters':['Shift']})
run('cell',  set={'Cell':True})
run('uvw',   set={'Instrument Parameters':['U','V','W']})
run('xy',    set={'Instrument Parameters':['X','Y']})
run('shl',   set={'Instrument Parameters':['SH/L']})
run('rep')
p.phase('WO3').set_refinements({'Atoms':{'W1':'X','W2':'X'}})
p.phase('Mn2O3').set_refinements({'Atoms':{'Mn2':'X','O1':'X'}})
run('Mpos'); run('Mpos2')
if OFREE:
    p.phase('WO3').set_refinements({'Atoms':{'O%d'%i:'X' for i in range(1,7)}})
    run('Opos'); run('Opos2')
ph=p.add_phase('cifs_src/MnWO4_ambient.cif',phasename='MnWO4',histograms=[h])
ph.data['Histograms'][list(ph.data['Histograms'])[0]]['Scale']=[1e-3,True]
run('mnwo4'); run('mnwo4b')
run('mnwo4cell', set={'Cell':True}, phases=['MnWO4'])
run('final1'); run('final2')
for q in p.phases():
    print('CELL',q.name,{k:round(v,5) for k,v in q.get_cell().items()})
print('Shift',h.data['Sample Parameters']['Shift'])
print('IP',{k:round(h.data['Instrument Parameters'][0][k][1],5) for k in ['U','V','W','X','Y','SH/L','Polariz.']})
for q in p.phases():
    for a in q.atoms(): print('ATOM',q.name,a.label,a.element,[round(c,5) for c in a.coordinates],round(a.uiso,5))
