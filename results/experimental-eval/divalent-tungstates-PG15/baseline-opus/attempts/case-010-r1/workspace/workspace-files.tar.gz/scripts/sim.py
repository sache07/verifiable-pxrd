import sys, os, numpy as np, json
sys.path.insert(0,'<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
import GSASII.GSASIIscriptable as G2sc

iprm = sys.argv[1]
cifs = sys.argv[2:]
tmp='tmpwork/simproj'
os.makedirs(tmp,exist_ok=True)
for c in cifs:
    name=os.path.basename(c)
    gpx=os.path.join(tmp,name+'.gpx')
    if os.path.exists(gpx): os.remove(gpx)
    p=G2sc.G2Project(newgpx=gpx)
    h=p.add_simulated_powder_histogram("sim",iprm,10.,100.,Npoints=4000,
        phases=[], scale=1.0)
    ph=p.add_phase(c,phasename=name,histograms=[h])
    p.do_refinements([{}])
    print(name)
