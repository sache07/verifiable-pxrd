import os, re, sys, json
root = sys.argv[1]
out = []
pat_form = re.compile(r"_chemical_formula_sum\s+(.*)")
allowed = {'Mn','W','O'}
el_re = re.compile(r"([A-Z][a-z]?)([0-9.]*)")
n=0
for dp,_,fns in os.walk(root):
    for fn in fns:
        if not fn.endswith('.cif'): continue
        p=os.path.join(dp,fn); n+=1
        try:
            txt=open(p,errors='ignore').read()
        except Exception: continue
        m=pat_form.search(txt)
        if not m: continue
        f=m.group(1).strip().strip("'\"")
        if not f: continue
        els=set()
        ok=True
        for tok in f.split():
            mm=el_re.fullmatch(tok)
            if not mm: ok=False;break
            els.add(mm.group(1))
        if not ok or not els or not els.issubset(allowed): continue
        def g(key):
            mm=re.search(key+r"\s+([0-9.]+)",txt)
            return float(mm.group(1)) if mm else None
        sg=re.search(r"_symmetry_space_group_name_H-M\s+(.*)",txt)
        out.append(dict(path=p,formula=f,
            a=g('_cell_length_a'),b=g('_cell_length_b'),c=g('_cell_length_c'),
            al=g('_cell_angle_alpha'),be=g('_cell_angle_beta'),ga=g('_cell_angle_gamma'),
            sg=(sg.group(1).strip().strip("'\"") if sg else '?')))
print(n,'cifs scanned',len(out),'matched',file=sys.stderr)
json.dump(out,open(sys.argv[2],'w'),indent=0)
