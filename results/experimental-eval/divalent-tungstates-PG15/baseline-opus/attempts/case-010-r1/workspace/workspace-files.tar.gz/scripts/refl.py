import sys, numpy as np
import GSASII.GSASIIscriptable as G2sc
p=G2sc.G2Project(sys.argv[1]); h=p.histogram(0); name=sys.argv[2]
R=h.reflections()[name]['RefList']
# cols: h,k,l,mult,d,pos,sig,gam,Fosq,Fcsq,phase,Icorr,...
I=np.array([r[9]*r[3]*r[11] for r in R]); pos=np.array([r[5] for r in R]); d=np.array([r[4] for r in R])
hkl=[tuple(int(v) for v in r[:3]) for r in R]
o=np.argsort(-I)
x=np.array(h.getdata('x')); yo=np.array(h.getdata('yobs')); yc=np.array(h.getdata('ycalc'))
# residual of the full model
import scipy.ndimage as ndi
print(f"{'hkl':>12} {'2th':>8} {'d':>7} {'Irel':>6}")
for i in o[:14]:
    print(f"{str(hkl[i]):>12} {pos[i]:8.3f} {d[i]:7.4f} {100*I[i]/I.max():6.1f}")
