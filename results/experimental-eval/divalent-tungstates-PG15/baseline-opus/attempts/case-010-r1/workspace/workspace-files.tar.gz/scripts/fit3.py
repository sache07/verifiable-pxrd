import os, sys, numpy as np
sys.path.insert(0,'scripts')
import GSASII.GSASIIscriptable as G2sc
from build import mk, seq
gpxf=sys.argv[1]; phases=[]
for a in sys.argv[2:]:
    n,c=a.split('=');phases.append((n,c))
p,h=mk(gpxf,phases)
h.set_refinements({'Background':{'type':'chebyschev-1','no. coeffs':10,'refine':True},
                   'Sample Parameters':['Scale']})
steps=[{},
 {'set':{'Sample Parameters':['Shift']}},
 {'set':{'Cell':True}},
 {'set':{'Instrument Parameters':['U','V','W']}},
 {'set':{'Instrument Parameters':['X','Y']}},
 {'set':{'Atoms':{'all':'XU'}}},
 {},
]
seq(p,h,steps)
for ph in p.phases():
    print(ph.name,'cell',{k:round(v,5) for k,v in ph.get_cell().items()})
print('wtFrac', {ph.name: round(float(ph.data['Histograms'][list(ph.data['Histograms'])[0]]['Scale'][0]),5) for ph in p.phases()})
import GSASII.GSASIIstrIO as G2stIO
print('Shift',h.data['Sample Parameters']['Shift'])
