import sys, numpy as np
import GSASII.GSASIIscriptable as G2sc
p=G2sc.G2Project(sys.argv[1]); h=p.histogram(0)
x=np.array(h.getdata('x')); yo=np.array(h.getdata('yobs')); yc=np.array(h.getdata('ycalc')); bg=np.array(h.getdata('background'))
lo,hi=float(sys.argv[2]),float(sys.argv[3])
m=(x>=lo)&(x<=hi)
import scipy.ndimage as ndi
r=ndi.uniform_filter1d(yo-yc,9)
step=max(1,int(m.sum()//60))
for i in np.where(m)[0][::step]:
    bar='#'*max(0,int(r[i]/20))
    print(f"{x[i]:8.3f} obs{yo[i]-bg[i]:9.0f} calc{yc[i]-bg[i]:9.0f} res{r[i]:8.0f} {bar}")
