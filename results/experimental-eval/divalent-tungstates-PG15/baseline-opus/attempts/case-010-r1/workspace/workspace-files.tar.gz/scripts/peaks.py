import numpy as np, sys
d = np.loadtxt(sys.argv[1], delimiter=',', skiprows=1)
x, y = d[:,0], d[:,1]
print("range", x.min(), x.max(), "step", np.median(np.diff(x)), "npts", len(x))
print("Imax", y.max(), "at", x[y.argmax()], "Imin", y.min())
# simple background via rolling min percentile
from scipy.signal import find_peaks, savgol_filter
ys = savgol_filter(y, 15, 3)
# background estimate
import scipy.ndimage as ndi
bg = ndi.minimum_filter1d(ys, 301)
bg = ndi.uniform_filter1d(bg, 301)
yc = ys - bg
pk, props = find_peaks(yc, height=max(30, 0.01*yc.max()), distance=10, prominence=0.008*yc.max())
lam=1.540598
print(f"{'2th':>9} {'d':>8} {'Inet':>9} {'Irel':>6}")
h = props['peak_heights']
order = np.argsort(-h)
for i in pk:
    dsp = lam/(2*np.sin(np.radians(x[i]/2)))
    print(f"{x[i]:9.4f} {dsp:8.4f} {yc[i]:9.1f} {100*yc[i]/yc[pk].max():6.1f}")
