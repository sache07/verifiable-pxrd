import os, sys, shutil, numpy as np
sys.path.insert(0,'scripts')
import GSASII.GSASIIscriptable as G2sc
base,new,name,cif = sys.argv[1:5]
refcell = len(sys.argv)>5 and sys.argv[5]=='cell'
for f in [new,new.replace('.gpx','.bak0.gpx')]:
    if os.path.exists(f): os.remove(f)
shutil.copy(base,new)
p=G2sc.G2Project(new); h=p.histogram(0)
print('start Rwp',round(h.get_wR(),4))
ph=p.add_phase(cif,phasename=name,histograms=[h])
hid=list(ph.data['Histograms'])[0]
ph.data['Histograms'][hid]['Scale']=[1e-3,True]
def run(tag,**kw):
    p.do_refinements([kw]); print(f'  [{tag}] Rwp={h.get_wR():.4f}')
run('scale')
run('scale2')
if refcell:
    run('cell', set={'Cell':True}, phases=[name])
    run('rep')
print('CELL',name,{k:round(v,5) for k,v in p.phase(name).get_cell().items()})
