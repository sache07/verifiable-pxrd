import sys, numpy as np, itertools
import GSASII.GSASIIscriptable as G2sc
p=G2sc.G2Project(sys.argv[1])
for ph in p.phases():
    G=ph.data['General']; cell=G['Cell'][1:7]
    a,b,c,al,be,ga=cell
    al,be,ga=np.radians([al,be,ga])
    M=np.array([[a,b*np.cos(ga),c*np.cos(be)],
                [0,b*np.sin(ga),c*(np.cos(al)-np.cos(be)*np.cos(ga))/np.sin(ga)],
                [0,0,0]])
    M[2,2]=np.sqrt(max(c**2-M[0,2]**2-M[1,2]**2,1e-9))
    SG=G['SGData']
    import GSASII.GSASIIspc as G2spc
    atoms=ph.data['Atoms']
    cx,ct=G['AtomPtrs'][0],G['AtomPtrs'][1]
    # expand all
    sites=[]
    for at in atoms:
        xyz=np.array(at[cx:cx+3])
        eq=G2spc.GenAtom(xyz,SG,Move=True)
        for e in eq:
            for sh in itertools.product([-1,0,1],repeat=3):
                sites.append((at[ct-1],at[ct],np.array(e[0])+np.array(sh)))
    print('==',ph.name)
    for at in atoms:
        if at[ct] in ('O','O-2'): continue
        x0=np.array(at[cx:cx+3])
        ds=[]
        for lab,el,xyz in sites:
            if el not in ('O','O-2'): continue
            d=np.linalg.norm(M@(xyz-x0))
            if 1.2<d<2.6: ds.append(d)
        ds=sorted(ds)
        print(f"  {at[ct-1]:5s} O-neighbours: {['%.3f'%v for v in ds[:8]]}")
