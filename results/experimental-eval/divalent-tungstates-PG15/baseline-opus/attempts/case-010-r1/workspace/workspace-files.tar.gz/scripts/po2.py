import os, sys, shutil, numpy as np
sys.path.insert(0,'scripts')
import GSASII.GSASIIscriptable as G2sc
base,new,name,ax = sys.argv[1:5]
for f in [new,new.replace('.gpx','.bak0.gpx')]:
    if os.path.exists(f): os.remove(f)
shutil.copy(base,new)
p=G2sc.G2Project(new); h=p.histogram(0)
print('start',h.get_wR())
ph=p.phase(name)
hid=list(ph.data['Histograms'])[0]
ph.data['Histograms'][hid]['Pref.Ori.']=['MD',1.0,True,[int(v) for v in ax.split(',')],0,{},[],0.1]
def run(tag,**kw):
    p.do_refinements([kw]); print(f'  [{tag}] Rwp={h.get_wR():.3f}')
run('po'); run('all')
print('PO',name,ph.data['Histograms'][hid]['Pref.Ori.'][:4])
