import os, sys, numpy as np, json
sys.path.insert(0,'scripts')
import GSASII.GSASIIscriptable as G2sc
from build import mk

gpxf  = sys.argv[1]
UFIX  = {'W':0.006,'Mn':0.008,'O':0.010}
PH=[('WO3','cifs_src/WO3_gamma.cif'),('Mn2O3','cifs_src/1514230.cif')]
p,h=mk(gpxf,PH)
ip=h.data['Instrument Parameters'][0]
for k,v in dict(U=3.0,V=0.0,W=0.3,X=0.5,Y=3.0).items(): ip[k][1]=v
ip['Polariz.'][1]=0.7
h.set_refinements({'Background':{'type':'chebyschev-1','no. coeffs':16,'refine':True}})
h.data['Sample Parameters']['Scale']=[1.0,False]
for q in p.phases():
    q.data['Histograms'][list(q.data['Histograms'])[0]]['Scale']=[1.0,True]
    for a in q.atoms(): a.uiso=UFIX[a.element]
def run(tag,**kw):
    p.do_refinements([kw]); print(f'  [{tag}] Rwp={h.get_wR():.4f}  W={ip["W"][1]:.4f} U={ip["U"][1]:.3f} X={ip["X"][1]:.3f} Y={ip["Y"][1]:.3f}',flush=True)
run('bg+frac')
run('disp',  set={'Sample Parameters':['Shift']})
run('cell',  set={'Cell':True})
run('uw',    set={'Instrument Parameters':['U','W']})
run('xy',    set={'Instrument Parameters':['X','Y']})
run('shl',   set={'Instrument Parameters':['SH/L']})
run('rep')
p.phase('WO3').set_refinements({'Atoms':{'W1':'X','W2':'X'}})
p.phase('Mn2O3').set_refinements({'Atoms':{'Mn2':'X','O1':'X'}})
run('pos'); run('pos2')
ph=p.add_phase('cifs_src/MnWO4_ambient.cif',phasename='MnWO4',histograms=[h])
ph.data['Histograms'][list(ph.data['Histograms'])[0]]['Scale']=[1e-3,True]
run('mnwo4'); run('mnwo4b')
run('mnwo4cell', set={'Cell':True}, phases=['MnWO4'])
run('final1'); run('final2')
for q in p.phases():
    print('CELL',q.name,{k:round(v,5) for k,v in q.get_cell().items()})
print('Shift',h.data['Sample Parameters']['Shift'])
print('IP',{k:round(ip[k][1],5) for k in ['U','V','W','X','Y','SH/L','Zero','Polariz.']})
for q in p.phases():
    for a in q.atoms(): print('ATOM',q.name,a.label,a.element,[round(c,5) for c in a.coordinates],round(a.uiso,5))
