import os, sys, numpy as np, json
sys.path.insert(0,'scripts')
import GSASII.GSASIIscriptable as G2sc
from build import mk

gpxf=sys.argv[1]
main=[a for a in sys.argv[2].split(',') if a]
test=[a for a in (sys.argv[3].split(',') if len(sys.argv)>3 and sys.argv[3] else []) if a]
phases=[tuple(a.split('=')) for a in main+test]
mainN=[a.split('=')[0] for a in main]
p,h=mk(gpxf,phases)
h.set_refinements({'Background':{'type':'chebyschev-1','no. coeffs':12,'refine':True}})
h.data['Sample Parameters']['Scale']=[1.0,False]
for ph in p.phases(): ph.set_HAP_refinements({'Scale':True})
def run(tag,**kw):
    p.do_refinements([kw])
    print(f'  [{tag}] Rwp={h.get_wR():.3f}')
run('bg+frac')
run('shift', set={'Sample Parameters':['Shift']})
run('cell', set={'Cell':True}, phases=mainN)
run('uvw', set={'Instrument Parameters':['U','V','W']})
run('xy', set={'Instrument Parameters':['X','Y']})
run('rep')
run('atoms', set={'Atoms':{'all':'XU'}}, phases=mainN)
run('shl', set={'Instrument Parameters':['SH/L']})
run('rep2')
run('rep3')
for ph in p.phases():
    print('CELL',ph.name,{k:round(v,5) for k,v in ph.get_cell().items()})
print('Shift',h.data['Sample Parameters']['Shift'][0])
