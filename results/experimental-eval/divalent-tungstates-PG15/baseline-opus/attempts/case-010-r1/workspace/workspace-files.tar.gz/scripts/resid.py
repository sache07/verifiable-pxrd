import os, sys, numpy as np
import GSASII.GSASIIscriptable as G2sc
p=G2sc.G2Project(sys.argv[1])
h=p.histogram(0)
x=np.array(h.getdata('x')); yo=np.array(h.getdata('yobs')); yc=np.array(h.getdata('ycalc')); bg=np.array(h.getdata('background'))
r=yo-yc
import scipy.ndimage as ndi
from scipy.signal import find_peaks
rs=ndi.uniform_filter1d(r,7)
pk,pr=find_peaks(rs,prominence=max(60,0.02*rs.max()),distance=8)
lam=1.540598
print(f"Rwp={h.get_wR():.2f}  max resid {rs.max():.0f}  obs max {(yo-bg).max():.0f}")
print(f"{'2th':>9} {'d':>8} {'resid':>8} {'%obsmax':>8}")
for i in pk:
    print(f"{x[i]:9.4f} {lam/(2*np.sin(np.radians(x[i]/2))):8.4f} {rs[i]:8.0f} {100*rs[i]/(yo-bg).max():8.1f}")
