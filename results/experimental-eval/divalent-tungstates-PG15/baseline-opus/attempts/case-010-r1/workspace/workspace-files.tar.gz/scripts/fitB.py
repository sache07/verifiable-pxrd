import os, sys, numpy as np, json
sys.path.insert(0,'scripts')
import GSASII.GSASIIscriptable as G2sc
from build import mk

gpxf=sys.argv[1]
main=[a for a in sys.argv[2].split(',') if a]
NB=int(sys.argv[3]); POorder=int(sys.argv[4]); aniso=sys.argv[5]
phases=[tuple(a.split('=')) for a in main]
mainN=[a.split('=')[0] for a in main]
p,h=mk(gpxf,phases)
h.set_refinements({'Background':{'type':'chebyschev-1','no. coeffs':NB,'refine':True}})
h.data['Sample Parameters']['Scale']=[1.0,False]
for ph in p.phases(): ph.set_HAP_refinements({'Scale':True})
def run(tag,**kw):
    p.do_refinements([kw]); print(f'  [{tag}] Rwp={h.get_wR():.3f}')
run('bg+frac')
run('shift', set={'Sample Parameters':['Shift']})
run('cell', set={'Cell':True})
run('uvw', set={'Instrument Parameters':['U','V','W']})
run('xy', set={'Instrument Parameters':['X','Y']})
run('rep')
run('atoms', set={'Atoms':{'all':'XU'}})
run('shl', set={'Instrument Parameters':['SH/L']})
run('rep2')
if POorder>0:
    for ph in p.phases():
        ph.set_HAP_refinements({'Pref.Ori.':{'type':'SH','order':POorder,'refine':True}})
    run('PO')
    run('PO2')
if aniso=='mustrain':
    for ph in p.phases():
        ph.set_HAP_refinements({'Mustrain':{'type':'generalized','refine':True}})
    run('mu')
    run('mu2')
run('final')
for q in p.phases(): print('CELL',q.name,{k:round(v,5) for k,v in q.get_cell().items()})
print('Shift',h.data['Sample Parameters']['Shift'][0])
print('GOF',h.data['Residuals'] if 'Residuals' in h.data else '')
