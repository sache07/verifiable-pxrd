import os, sys, numpy as np, shutil
import GSASII.GSASIIscriptable as G2sc
gpx='tmpwork/f1.gpx'
for f in [gpx, gpx.replace('.gpx','.bak0.gpx')]:
    if os.path.exists(f): os.remove(f)
p=G2sc.G2Project(newgpx=gpx)
h=p.add_powder_histogram('out/pattern.xy','out/inst.instprm',fmthint='Topas xye')
ph=p.add_phase('cifs_src/1528915.cif',phasename='WO3',histograms=[h])
h.set_refinements({'Background':{'type':'chebyschev-1','no. coeffs':8,'refine':True},
                   'Sample Parameters':['Scale']})
p.do_refinements([{}])
print('Rwp',h.get_wR())
# add zero + cell
p.set_refinement({'set':{'Instrument Parameters':['Zero']}})
ph.set_HAP_refinements({'Scale':True})
p.do_refinements([{}])
print('Rwp after zero',h.get_wR(), 'Zero', h.data['Instrument Parameters'][0]['Zero'])
ph.set_refinements({'Cell':True})
p.do_refinements([{}])
print('Rwp after cell',h.get_wR())
h.set_refinements({'Instrument Parameters':['U','V','W','X','Y']})
p.do_refinements([{}])
print('Rwp after prof',h.get_wR(),'Zero',h.data['Instrument Parameters'][0]['Zero'][1])
print('cell',ph.get_cell())
