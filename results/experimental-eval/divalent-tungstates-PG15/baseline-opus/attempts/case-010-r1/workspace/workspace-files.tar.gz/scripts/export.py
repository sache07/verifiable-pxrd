import os, sys, json, shutil, re, numpy as np
sys.path.insert(0,'scripts')
import GSASII.GSASIIscriptable as G2sc

src    = sys.argv[1]           # converged .gpx
outdir = sys.argv[2]           # destination directory
log    = sys.argv[3]           # refinement stdout log (for the variable count)
os.makedirs(outdir, exist_ok=True)
final = os.path.join(outdir,'final.gpx')
for f in [final, final.replace('.gpx','.bak0.gpx')]:
    if os.path.exists(f): os.remove(f)
shutil.copy(src, final)
p = G2sc.G2Project(final)
h = p.histogram(0)

x   = np.array(h.getdata('x'))
yo  = np.array(h.getdata('yobs'))
yc  = np.array(h.getdata('ycalc'))
bkg = np.array(h.getdata('background'))
w   = np.array(h.getdata('yweight'))

with open(os.path.join(outdir,'fit.csv'),'w') as f:
    f.write('two_theta_deg,y_obs,y_calc,y_diff,y_background\n')
    for i in range(len(x)):
        f.write(f'{x[i]:.6f},{yo[i]:.4f},{yc[i]:.4f},{yo[i]-yc[i]:.4f},{bkg[i]:.4f}\n')

nobs = len(x)
nvar = int(re.findall(r'(\d+) variables', open(log).read())[-1])
Rwp  = 100*np.sqrt(np.sum(w*(yo-yc)**2)/np.sum(w*yo**2))
Rp   = 100*np.sum(np.abs(yo-yc))/np.sum(np.abs(yo))
Rexp = 100*np.sqrt((nobs-nvar)/np.sum(w*yo**2))
GOF  = Rwp/Rexp
chi2 = np.sum(w*(yo-yc)**2)/(nobs-nvar)
Rwpb = 100*np.sqrt(np.sum(w*(yo-yc)**2)/np.sum(w*(yo-bkg)**2))

txt   = open(src.replace('.gpx','.lst')).read()
names = [q.name for q in p.phases()]
wf    = [(float(a),float(b)) for a,b in
         re.findall(r'Weight fraction\s*:\s*([0-9.]+), sig\s*([0-9.]+)', txt)][-len(names):]
rf    = [(float(a),float(b)) for a,b in
         re.findall(r'Final refinement RF, RF\^2 = ([0-9.]+)%, ([0-9.]+)%', txt)][-len(names):]
nrefl = [int(a) for a in re.findall(r'RF\^2 = [0-9.]+%, [0-9.]+% on (\d+) reflections', txt)][-len(names):]

FORMULA = {'WO3':'WO3','Mn2O3':'Mn2O3','MnWO4':'MnWO4'}
MINERAL = {'WO3':'gamma-WO3 (monoclinic tungsten trioxide)',
           'Mn2O3':'alpha-Mn2O3 (bixbyite)',
           'MnWO4':'MnWO4 (wolframite-type, huebnerite)'}
cifs={}
for i,q in enumerate(p.phases()):
    fn = os.path.join(outdir, f'{q.name}.cif')
    q.export_CIF(fn, quickmode=True)
    body = open(fn).read()
    body = body.replace('data_final', 'data_'+q.name, 1)
    hdr = (f"# Rietveld-refined structural model for {MINERAL[q.name]}\n"
           f"# Refined against inputs/pattern.csv with GSAS-II (see final.gpx)\n"
           f"# Weight fraction in the modelled crystalline mixture: "
           f"{100*wf[i][0]:.2f} +- {100*wf[i][1]:.2f} %\n"
           f"# Overall fit: Rwp = {Rwp:.2f} %, GOF = {GOF:.2f}\n")
    open(fn,'w').write(hdr+body)
    cifs[q.name]=os.path.basename(fn)

tot = sum(v[0] for v in wf)
phases=[]
for i,q in enumerate(p.phases()):
    phases.append(dict(
        name=MINERAL[q.name],
        formula=FORMULA[q.name],
        space_group=q.data['General']['SGData']['SpGrp'],
        cif=cifs[q.name],
        weight_fraction=round(wf[i][0]/tot,5),
        weight_fraction_esd=round(wf[i][1],5),
        lattice_parameters={k:round(v,5) for k,v in q.get_cell().items()},
        R_F_percent=rf[i][0], R_F2_percent=rf[i][1], n_reflections=nrefl[i]))

result = dict(
    phases=phases,
    fit_statistics=dict(Rwp_percent=round(Rwp,3), Rp_percent=round(Rp,3),
                        Rexp_percent=round(Rexp,3), goodness_of_fit=round(GOF,3),
                        reduced_chi_squared=round(chi2,3),
                        Rwp_background_subtracted_percent=round(Rwpb,3),
                        n_observations=nobs, n_refined_variables=nvar,
                        two_theta_range_deg=[round(float(x.min()),4), round(float(x.max()),4)]),
    profile=dict(wavelength_Kalpha1_angstrom=h.data['Instrument Parameters'][0]['Lam1'][1],
                 wavelength_Kalpha2_angstrom=h.data['Instrument Parameters'][0]['Lam2'][1],
                 Kalpha2_ratio=h.data['Instrument Parameters'][0]['I(L2)/I(L1)'][1],
                 polarization=h.data['Instrument Parameters'][0]['Polariz.'][1],
                 zero_deg=h.data['Instrument Parameters'][0]['Zero'][1],
                 sample_displacement_micron=round(h.data['Sample Parameters']['Shift'][0],1),
                 GU=0.0, GV=0.0,
                 GW=round(h.data['Instrument Parameters'][0]['W'][1],4),
                 LX=round(h.data['Instrument Parameters'][0]['X'][1],4),
                 LY=round(h.data['Instrument Parameters'][0]['Y'][1],4),
                 SH_L=round(h.data['Instrument Parameters'][0]['SH/L'][1],5),
                 background='Chebyshev polynomial (1st kind), 16 terms'),
    software='GSAS-II (GSASIIscriptable)',
    project_file='final.gpx',
    profile_file='fit.csv')
json.dump(result, open(os.path.join(outdir,'result.json'),'w'), indent=2)
print(json.dumps(result, indent=2))
p.save()
