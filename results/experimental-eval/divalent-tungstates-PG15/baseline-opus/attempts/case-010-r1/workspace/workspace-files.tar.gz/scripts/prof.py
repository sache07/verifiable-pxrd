import sys, numpy as np
import GSASII.GSASIIscriptable as G2sc
p=G2sc.G2Project(sys.argv[1]); h=p.histogram(0)
x=np.array(h.getdata('x')); yo=np.array(h.getdata('yobs')); yc=np.array(h.getdata('ycalc')); bg=np.array(h.getdata('background'))
n=90
idx=np.array_split(np.arange(len(x)),n)
print(f"{'2th':>7} {'obs':>8} {'calc':>8} {'bg':>8} {'minobs':>8} {'<res>':>8}")
for g in idx:
    print(f"{x[g].mean():7.2f} {yo[g].mean():8.0f} {yc[g].mean():8.0f} {bg[g].mean():8.0f} {yo[g].min():8.0f} {(yo[g]-yc[g]).mean():8.1f}")
