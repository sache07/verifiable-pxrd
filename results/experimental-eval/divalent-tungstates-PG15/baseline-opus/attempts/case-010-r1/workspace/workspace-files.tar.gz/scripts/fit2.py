import os, sys, numpy as np
sys.path.insert(0,'scripts')
import GSASII.GSASIIscriptable as G2sc
from build import mk, seq
p,h=mk('tmpwork/f2.gpx',[('WO3','cifs_src/1528915.cif')])
ph=p.phase('WO3')
h.set_refinements({'Background':{'type':'chebyschev-1','no. coeffs':10,'refine':True},
                   'Sample Parameters':['Scale']})
steps=[{},
 {'set':{'Sample Parameters':['DisplaceX','Shift']}},
 {'set':{'Cell':True}},
 {'set':{'Instrument Parameters':['U','V','W']}},
 {'set':{'Instrument Parameters':['X','Y']}},
 {'set':{'Atoms':{'all':'XU'}}},
]
seq(p,h,steps)
print('cell',ph.get_cell())
sp=h.data['Sample Parameters']
print('Shift',sp['Shift'],'DisplaceX',sp.get('DisplaceX'))
print('Zero',h.data['Instrument Parameters'][0]['Zero'])
