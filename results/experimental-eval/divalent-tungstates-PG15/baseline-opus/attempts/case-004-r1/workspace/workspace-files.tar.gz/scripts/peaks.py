import sys, numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

path = sys.argv[1]
d = np.loadtxt(path, delimiter=",", skiprows=1)
x, y = d[:,0], d[:,1]
print("range", x.min(), x.max(), "step", np.median(np.diff(x)), "npts", len(x))
print("Imax", y.max(), "Imin", y.min())

# simple background via rolling minimum + smoothing
from scipy.ndimage import minimum_filter1d, uniform_filter1d
bg = minimum_filter1d(y, 201)
bg = uniform_filter1d(bg, 301)
ys = uniform_filter1d(y, 5)
net = ys - bg

# peak finding
from scipy.signal import find_peaks
pk, props = find_peaks(net, height=0.01*net.max(), prominence=0.008*net.max(), distance=5)
print("n peaks", len(pk))
order = np.argsort(-net[pk])
lam = 1.540598
print(f"{'2th':>9} {'d':>8} {'Inet':>9} {'rel%':>6}")
for i in sorted(pk, key=lambda j: x[j]):
    dsp = lam/(2*np.sin(np.radians(x[i]/2)))
    print(f"{x[i]:9.4f} {dsp:8.4f} {net[i]:9.1f} {100*net[i]/net.max():6.1f}")

fig, ax = plt.subplots(2,1, figsize=(16,9))
ax[0].plot(x,y,lw=0.7); ax[0].plot(x,bg,lw=0.7)
ax[0].set_yscale("log")
ax[1].plot(x,net,lw=0.7)
ax[1].plot(x[pk], net[pk], "r.", ms=4)
for i in pk:
    ax[1].annotate(f"{x[i]:.2f}", (x[i], net[i]), fontsize=5, rotation=90)
plt.tight_layout(); plt.savefig(sys.argv[2], dpi=130)
