import numpy as np
from scipy.optimize import curve_fit
d = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
x, y = d[:, 0], d[:, 1]
l1, l2 = 1.540598, 1.544426

def shape(dx, f, eta):
    g = np.exp(-4*np.log(2)*(dx/f)**2)
    l = 1/(1+4*(dx/f)**2)
    return eta*l + (1-eta)*g

def mk(c0):
    def fn(xx, x0, I, f, eta, b0, b1):
        th = np.radians(x0/2)
        d2 = 2*np.degrees(np.arcsin(min(0.999, (l2/l1)*np.sin(th)))) - x0
        return I*(shape(xx-x0, f, eta) + 0.5*shape(xx-x0-d2, f, eta)) + b0 + b1*(xx-c0)
    return fn

print(f"{'2th':>8} {'FWHM':>7} {'eta':>6}")
for c, w in [(19.06, 0.55), (26.66, 0.45), (30.71, 0.5), (36.45, 0.4), (38.60, 0.45),
             (47.28, 0.55), (48.37, 0.4), (52.13, 0.5), (56.0, 0.55), (65.13, 0.7),
             (71.96, 0.7), (76.94, 0.9), (87.5, 0.8)]:
    m = (x > c-w) & (x < c+w)
    try:
        p, cv = curve_fit(mk(c), x[m], y[m], p0=[c, y[m].max()-y[m].min(), 0.2, 0.3,
                          y[m].min(), 0], maxfev=40000,
                          bounds=([c-0.3, 0, 0.03, 0, 0, -1e4], [c+0.3, 1e6, 1.5, 1, 1e4, 1e4]))
        print(f"{p[0]:8.3f} {p[2]:7.4f} {p[3]:6.2f}")
    except Exception as e:
        print(c, "fail", e)
