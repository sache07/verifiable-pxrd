"""Staged Rietveld refinement of the CoO + WO3 (900 C) product.

Phases: gamma-WO3 (P2_1/n) + CoWO4 (wolframite, P2/c), optional extras via EXTRA.
Profile: global Gaussian U,V,W + Lorentzian X,Y; per-phase isotropic size and
microstrain released only in a later stage (and only if they improve the fit).
"""
import os, sys, json
import numpy as np
sys.path.insert(0, "<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages")
from GSASII import GSASIIscriptable as G2sc

W = "<ATTEMPT_WORKSPACE>/work"
NAME = os.environ.get("NAME", "r3")
NBG = int(os.environ.get("NBG", "12"))
EXTRA = os.environ.get("EXTRA", "")
STAGES = os.environ.get("STAGES", "bg,cell,gau,lor,micro,atomX,atomU,shl")
gpx = os.path.join(W, NAME + ".gpx")
if os.path.exists(gpx):
    os.remove(gpx)

prj = G2sc.G2Project(newgpx=gpx)
hist = prj.add_powder_histogram(os.path.join(W, "pattern.xy"),
                                os.path.join(W, "cu.instprm"), fmthint="Topas xye")
hname = hist.name
ip = hist.data["Instrument Parameters"][0]

specs = [("WO3", "WO3_start.cif"), ("CoWO4", "CoWO4_start.cif")]
if EXTRA:
    specs += [tuple(it.split(":")) for it in EXTRA.split(",")]
phases = [prj.add_phase(os.path.join(W, cif), phasename=nm, histograms=[hist])
          for nm, cif in specs]
for p in phases:
    p.setSampleProfile(hname, "size", "isotropic", 2.0)
    p.setSampleProfile(hname, "mustrain", "isotropic", 500.)
    p.data["Histograms"][hname]["Scale"] = [1.0, True]

def rep(tag):
    rv = prj.data["Covariance"]["data"].get("Rvals", {})
    print(f"--- {tag}: Rwp={hist.get_wR():.4f} GOF={rv.get('GOF',float('nan')):.4f}")
    for p in phases:
        c = p.data["General"]["Cell"]
        h = p.data["Histograms"][hname]
        print(f"    {p.name:8s} sc={h['Scale'][0]:.5f} a={c[1]:.5f} b={c[2]:.5f} c={c[3]:.5f} "
              f"bet={c[5]:.4f} V={c[7]:.3f} size={h['Size'][1][0]:.3f} mu={h['Mustrain'][1][0]:.0f}")
    print("    inst:", {k: round(ip[k][1], 4) for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")},
          "shift=%.1f" % hist.data["Sample Parameters"]["Shift"][0])

STEP = {
 "bg":    [{"set": {"Background": {"type": "chebyschev-1", "no. coeffs": NBG, "refine": True},
                    "Sample Parameters": ["Scale"]}}],
 "cell":  [{"set": {"Cell": True, "Sample Parameters": ["Shift"]}}],
 "gau":   [{"set": {"Instrument Parameters": ["U", "V", "W"]}}],
 "lor":   [{"set": {"Instrument Parameters": ["X", "Y"]}}],
 "micro": [{"set": {"Size": {"type": "isotropic", "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True}}}],
 "atomX": [{"set": {"Atoms": {"all": "X"}}}],
 "atomU": [{"set": {"Atoms": {"all": "U"}}}],
 "shl":   [{"set": {"Instrument Parameters": ["SH/L"]}}],
 "all":   [{}],
}
for tag in STAGES.split(","):
    prj.do_refinements(STEP[tag])
    rep(tag)

prj.save()
x = np.array(hist.data["data"][1][0]); yo = np.array(hist.data["data"][1][1])
yc = np.array(hist.data["data"][1][3]); yb = np.array(hist.data["data"][1][4])
np.savetxt(os.path.join(W, NAME + "_prof.csv"), np.column_stack([x, yo, yc, yo-yc, yb]),
           delimiter=",", header="two_theta_deg,y_obs,y_calc,y_diff,y_bkg", comments="")
print("saved", gpx)
