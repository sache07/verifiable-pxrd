"""Staged Rietveld refinement of the CoO+WO3 900C product: gamma-WO3 + CoWO4."""
import os, sys, json
sys.path.insert(0, "<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages")
from GSASII import GSASIIscriptable as G2sc

W = "<ATTEMPT_WORKSPACE>/work"
NAME = sys.argv[1] if len(sys.argv) > 1 else "r1"
NBG = int(os.environ.get("NBG", "12"))
EXTRA = os.environ.get("EXTRA", "")          # extra phase cifs, comma separated name:cif
gpx = os.path.join(W, NAME + ".gpx")
if os.path.exists(gpx):
    os.remove(gpx)

prj = G2sc.G2Project(newgpx=gpx)
hist = prj.add_powder_histogram(os.path.join(W, "pattern.xy"),
                                os.path.join(W, "cu.instprm"), fmthint="Topas xye")
phases = []
phases.append(prj.add_phase(os.path.join(W, "WO3_start.cif"), phasename="WO3", histograms=[hist]))
phases.append(prj.add_phase(os.path.join(W, "CoWO4_start.cif"), phasename="CoWO4", histograms=[hist]))
if EXTRA:
    for item in EXTRA.split(","):
        nm, cif = item.split(":")
        phases.append(prj.add_phase(os.path.join(W, cif), phasename=nm, histograms=[hist]))

hname = hist.name
for p in phases:
    p.setSampleProfile(hname, "size", "isotropic", 1.0)
    p.data["Histograms"][hname]["Scale"] = [1.0, True]

def rep(tag):
    print(f"--- {tag}: Rwp={hist.get_wR():.4f}  GOF={prj.data['Covariance']['data'].get('Rvals',{}).get('GOF',float('nan')):.4f}")
    for p in phases:
        c = p.data["General"]["Cell"]
        print(f"    {p.name:8s} scale={p.data['Histograms'][hname]['Scale'][0]:.5f} "
              f"a={c[1]:.5f} b={c[2]:.5f} c={c[3]:.5f} beta={c[5]:.4f} V={c[7]:.3f}")
    ip = hist.data["Instrument Parameters"][0]
    print("    inst:", {k: round(ip[k][1], 5) for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")})
    print("    shift:", hist.data["Sample Parameters"]["Shift"][0])

steps = []
# 1 background + scale + phase fractions
steps.append(("bg+scale", [{"set": {"Background": {"type": "chebyschev-1", "no. coeffs": NBG,
                                                   "refine": True},
                                    "Sample Parameters": ["Scale"]}}]))
# 2 unit cells + sample displacement
steps.append(("cell", [{"set": {"Cell": True}},
                       {"set": {"Sample Parameters": ["Shift"]}}]))
# 3 profile
steps.append(("prof", [{"set": {"Instrument Parameters": ["U", "V", "W", "X", "Y"]}}]))
# 4 microstrain / size per phase
steps.append(("micro", [{"set": {"Mustrain": {"type": "isotropic", "refine": True},
                                 "Size": {"type": "isotropic", "refine": True}}}]))
# 5 atoms
steps.append(("atoms", [{"set": {"Atoms": {"all": "XU"}}}]))
# 6 SH/L + zero
steps.append(("shl", [{"set": {"Instrument Parameters": ["SH/L"]}}]))

for tag, dicts in steps:
    prj.do_refinements(dicts)
    rep(tag)

prj.save()
print("saved", gpx)
