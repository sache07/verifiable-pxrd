"""COD 2311041 (gamma-WO3, 1966) -> conventional P2_1/n setting CIF."""
import numpy as np
from pymatgen.core import Structure, Lattice

src = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif"
s = Structure.from_file(src)
M = np.array([[1, 0, 1], [0, 1, 0], [-1, 0, 0]])
newlat = Lattice(M @ s.lattice.matrix)
frac = np.array([newlat.get_fractional_coords(c) for c in s.cart_coords]) % 1.0
species = [sp.symbol for sp in s.species]

ops = [lambda p: p,
       lambda p: -p,
       lambda p: np.array([0.5-p[0], 0.5+p[1], 0.5-p[2]]),
       lambda p: np.array([0.5+p[0], 0.5-p[1], 0.5+p[2]])]

def inset(p, pts, tol=1e-3):
    d = np.abs((pts - p + 0.5) % 1.0 - 0.5)
    return np.any(np.all(d < tol, axis=1))

# group sites into orbits under the assumed P2_1/n operations
used = set()
asym = []
for i, p in enumerate(frac):
    if i in used:
        continue
    orbit = []
    for op in ops:
        q = op(p) % 1.0
        for j, pj in enumerate(frac):
            if species[j] == species[i] and inset(q, pj.reshape(1, 3)):
                orbit.append(j)
    orbit = sorted(set(orbit))
    if len(orbit) != 4:
        print("WARN orbit size", len(orbit), "for site", i, species[i], p)
    used.update(orbit)
    asym.append((species[i], p))
print("asym unit sites:", len(asym))
a, b, c, al, be, ga = newlat.parameters
lines = ["data_gamma_WO3_P21n",
         "_chemical_formula_sum            'W8 O24'",
         "_symmetry_space_group_name_H-M   'P 1 21/n 1'",
         "_symmetry_Int_Tables_number      14",
         f"_cell_length_a                   {a:.5f}",
         f"_cell_length_b                   {b:.5f}",
         f"_cell_length_c                   {c:.5f}",
         f"_cell_angle_alpha                {al:.4f}",
         f"_cell_angle_beta                 {be:.4f}",
         f"_cell_angle_gamma                {ga:.4f}",
         "_cell_formula_units_Z            8",
         "loop_", "_symmetry_equiv_pos_as_xyz",
         "  'x,y,z'", "  '-x,-y,-z'",
         "  '-x+1/2,y+1/2,-z+1/2'", "  'x+1/2,-y+1/2,z+1/2'",
         "loop_", "_atom_site_label", "_atom_site_type_symbol",
         "_atom_site_fract_x", "_atom_site_fract_y", "_atom_site_fract_z",
         "_atom_site_occupancy", "_atom_site_U_iso_or_equiv"]
nw = no = 0
for el, p in asym:
    if el == "W":
        nw += 1; lab = f"W{nw}"; u = 0.005
    else:
        no += 1; lab = f"O{no}"; u = 0.010
    lines.append(f"{lab:4s} {el:2s} {p[0]:9.5f} {p[1]:9.5f} {p[2]:9.5f} 1.0 {u}")
open("work/WO3_pn.cif", "w").write("\n".join(lines) + "\n")
print("\n".join(lines[-9:]))
chk = Structure.from_file("work/WO3_pn.cif")
print("check:", chk.composition, [round(v, 4) for v in chk.lattice.parameters])
md = min(chk.distance_matrix[chk.distance_matrix > 0.01])
print("min interatomic:", round(md, 3))
