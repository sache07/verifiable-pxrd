"""Compare profile/correction model variants for the WO3 + CoWO4 refinement.

Each variant starts from the same literature structures (coordinates and Uiso
fixed) and refines background, scale, phase fractions, cells, sample shift and
the requested set of profile/correction parameters.  Reports Rwp and the
resulting weight fractions so that model dependence can be judged.
"""
import os, sys, json, copy
import numpy as np
sys.path.insert(0, "<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages")
from GSASII import GSASIIscriptable as G2sc

WD = "<ATTEMPT_WORKSPACE>/work"
UISO0 = {"W": 0.005, "Co": 0.008, "O": 0.012}

def build(name, ratio=0.5, extra=()):
    gpx = os.path.join(WD, name + ".gpx")
    for f in (gpx, gpx.replace(".gpx", ".bak0.gpx")):
        if os.path.exists(f):
            os.remove(f)
    prj = G2sc.G2Project(newgpx=gpx)
    hist = prj.add_powder_histogram(os.path.join(WD, "pattern.xy"),
                                    os.path.join(WD, "cu.instprm"), fmthint="Topas xye")
    ip = hist.data["Instrument Parameters"][0]
    for k, v in (("U", 0.0), ("V", 0.0), ("W", 200.0), ("X", 10.0), ("Y", 0.0), ("SH/L", 0.01)):
        ip[k][1] = v
    ip["I(L2)/I(L1)"][1] = ratio
    specs = [("WO3", "WO3_pn.cif"), ("CoWO4", "CoWO4_start.cif")] + list(extra)
    phases = [prj.add_phase(os.path.join(WD, cif), phasename=nm, histograms=[hist])
              for nm, cif in specs]
    for p in phases:
        p.setSampleProfile(hist.name, "size", "isotropic", 10.0)
        p.setSampleProfile(hist.name, "mustrain", "isotropic", 500.)
        p.data["Histograms"][hist.name]["Scale"] = [1.0, True]
        for a in p.data["Atoms"]:
            a[10] = UISO0.get(a[1].split("+")[0].split("-")[0], 0.01)
    ctrl = prj.data["Controls"]["data"]
    ctrl["parmMinDict"] = {":0:W": 1.0, ":0:SH/L": 0.0003, ":0:X": 0.0, ":0:Y": 0.0,
                           ":0:U": 0.0}
    ctrl["parmMaxDict"] = {":0:SH/L": 0.1}
    for i in range(len(phases)):
        ctrl["parmMinDict"]["%d:0:Size;i" % i] = 0.05
        ctrl["parmMinDict"]["%d:0:Mustrain;i" % i] = 10.
        ctrl["parmMaxDict"]["%d:0:Mustrain;i" % i] = 10000.
    prj.save()
    return prj, hist, phases

def report(tag, prj, hist, phases):
    try:
        mf = hist.ComputeMassFracs()
    except Exception:
        mf = {}
    ip = hist.data["Instrument Parameters"][0]
    sp = hist.data["Sample Parameters"]
    out = {"tag": tag, "Rwp": round(hist.get_wR(), 4),
           "GOF": round(prj.data["Covariance"]["data"]["Rvals"].get("GOF", 0), 4),
           "wt": {p.name: round(100*mf.get(p.name, (float('nan'),))[0], 2) for p in phases},
           "su": {p.name: round(100*mf.get(p.name, (0, float('nan')))[1], 2) for p in phases},
           "inst": {k: round(ip[k][1], 4) for k in ("U", "V", "W", "X", "Y", "SH/L",
                                                    "I(L2)/I(L1)", "Polariz.")},
           "shift": round(sp["Shift"][0], 1),
           "rough": [round(sp["SurfRoughA"][0], 4), round(sp["SurfRoughB"][0], 4)],
           "mu": {p.name: round(p.data["Histograms"][hist.name]["Mustrain"][1][0], 1) for p in phases},
           "size": {p.name: round(p.data["Histograms"][hist.name]["Size"][1][0], 3) for p in phases},
           "cell": {p.name: [round(v, 5) for v in p.data["General"]["Cell"][1:8]] for p in phases},
           "PO": {p.name: p.data["Histograms"][hist.name].get("Pref.Ori.", [None, None])[1]
                  for p in phases}}
    print("RESULT " + json.dumps(out))
    return out

def run(tag, instvars, ratio=0.5, po=None, rough=False, nbg=12, mu=True):
    prj, hist, phases = build(tag, ratio=ratio)
    hname = hist.name
    if po:
        nm, ax = po
        for p in phases:
            if p.name == nm:
                p.data["Histograms"][hname]["Pref.Ori."] = ["MD", 1.0, True, list(ax), 0, {}, [], 0.1]
    if rough:
        hist.data["Sample Parameters"]["SurfRoughA"][1] = True
        hist.data["Sample Parameters"]["SurfRoughB"][1] = True
    seq = [{"set": {"Background": {"type": "chebyschev-1", "no. coeffs": nbg, "refine": True},
                    "Sample Parameters": ["Scale"]}},
           {"set": {"Cell": True, "Sample Parameters": ["Shift"]}},
           {"set": {"Instrument Parameters": instvars}}]
    if mu:
        seq.append({"set": {"Mustrain": {"type": "isotropic", "refine": True}}})
    seq.append({})
    prj.do_refinements(seq)
    prj.save()
    r = report(tag, prj, hist, phases)
    x = np.array(hist.data["data"][1][0]); yo = np.array(hist.data["data"][1][1])
    yc = np.array(hist.data["data"][1][3]); yb = np.array(hist.data["data"][1][4])
    np.savetxt(os.path.join(WD, tag + "_prof.csv"), np.column_stack([x, yo, yc, yo-yc, yb]),
               delimiter=",", header="two_theta_deg,y_obs,y_calc,y_diff,y_bkg", comments="")
    return r

if __name__ == "__main__":
    which = sys.argv[1]
    if which == "v1":
        run("v1_WX", ["W", "X", "SH/L"])
    elif which == "v2":
        run("v2_WXnoratio", ["W", "X", "SH/L"], ratio=0.0)
    elif which == "v3":
        run("v3_WXrough", ["W", "X", "SH/L"], rough=True)
    elif which == "v4":
        run("v4_WXratio", ["W", "X", "SH/L", "I(L2)/I(L1)"])
    elif which == "v5":
        run("v5_WXUY", ["U", "W", "X", "Y", "SH/L"])
    elif which.startswith("po"):
        ax = tuple(int(c) for c in which[2:])
        run("vpo_%s" % which[2:], ["W", "X", "SH/L"], po=("WO3", ax))
    elif which == "v6":
        run("v6_bg20", ["W", "X", "SH/L"], nbg=20)
    elif which == "v7":
        run("v7_pola", ["W", "X", "SH/L", "Polariz."])
