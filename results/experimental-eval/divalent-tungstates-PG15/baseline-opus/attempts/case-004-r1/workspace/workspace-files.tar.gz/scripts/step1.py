import os, sys, json
sys.path.insert(0, "<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages")
from GSASII import GSASIIscriptable as G2sc

W = "<ATTEMPT_WORKSPACE>/work"
gpx = os.path.join(W, "s1.gpx")
if os.path.exists(gpx):
    os.remove(gpx)
prj = G2sc.G2Project(newgpx=gpx)
hist = prj.add_powder_histogram(os.path.join(W, "pattern.xy"),
                                os.path.join(W, "cu.instprm"),
                                fmthint="Topas xye")
ph1 = prj.add_phase(os.path.join(W, "WO3_start.cif"), phasename="WO3", histograms=[hist])
ph2 = prj.add_phase(os.path.join(W, "CoWO4_start.cif"), phasename="CoWO4", histograms=[hist])

hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 12, "refine": True},
                      "Sample Parameters": ["Scale"]})
hist.data["Sample Parameters"]["Shift"] = [0.0, False]
for p in (ph1, ph2):
    p.setSampleProfile(hist.name, "size", "isotropic", 1.0)
prj.save()
prj.do_refinements([{}])
print("Rwp", hist.get_wR())
for p in (ph1, ph2):
    print(p.name, p.data["Histograms"][hist.name]["Scale"])
prj.save()
