"""Report fit statistics, mass fractions and structures from a finished .gpx."""
import os, sys, json
import numpy as np
sys.path.insert(0, "<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages")
from GSASII import GSASIIscriptable as G2sc

gpxf = sys.argv[1]
outdir = sys.argv[2] if len(sys.argv) > 2 else None
prj = G2sc.G2Project(gpxf)
hist = prj.histograms()[0]
rv = prj.data["Covariance"]["data"]["Rvals"]
print("Rvals:", {k: (round(v, 4) if isinstance(v, float) else v) for k, v in rv.items()})
try:
    mf = hist.ComputeMassFracs()
except Exception as e:
    mf = {}
    print("massfrac failed", e)
print("MassFracs:", {k: (round(v[0], 5), round(v[1], 5)) for k, v in mf.items()})
sig = prj.data["Covariance"]["data"].get("sigDict", {})
for p in prj.phases():
    c = p.data["General"]["Cell"]
    h = p.data["Histograms"][hist.name]
    print(f"\n== {p.name}  SG={p.data['General']['SGData']['SpGrp']}")
    print(f"   a={c[1]:.5f} b={c[2]:.5f} c={c[3]:.5f} al={c[4]:.4f} be={c[5]:.4f} ga={c[6]:.4f} V={c[7]:.3f}")
    print(f"   phase scale={h['Scale'][0]:.5f}  size={h['Size'][1][0]:.4f} mustrain={h['Mustrain'][1][0]:.1f}"
          f"  PO={h.get('Pref.Ori.',['-'])[1] if 'Pref.Ori.' in h else '-'}")
    for a in p.data["Atoms"]:
        print("   ", a[0], a[1], " ".join(f"{v:9.5f}" for v in a[3:7]), f"Uiso={a[10]:.5f}")
print("\nRefined esds (selected):")
for k in sorted(sig):
    if any(t in k for t in ("A0", "A1", "A2", "A3", "A4", "A5", "Scale", "Size", "Mustrain", ":W", ":U", "SH/L")):
        print(f"   {k:22s} {sig[k]:.5g}")

if outdir:
    os.makedirs(outdir, exist_ok=True)
    for p in prj.phases():
        fn = os.path.join(outdir, p.name + ".cif")
        p.export_CIF(fn)
        print("wrote", fn)
