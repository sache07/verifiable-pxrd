"""Continue refining an existing project, optionally releasing more parameters.

usage: cont.py SRC.gpx DST.gpx [opts...]
opts: atomX uiso rough po=h,k,l mu size nocoords sh bg=N seed=W,X,muA,muB
"""
import os, sys, json, shutil
import numpy as np
sys.path.insert(0, "<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages")
from GSASII import GSASIIscriptable as G2sc

src, dst = sys.argv[1], sys.argv[2]
opts = sys.argv[3:]
if os.path.abspath(src) != os.path.abspath(dst):
    shutil.copy(src, dst)
prj = G2sc.G2Project(dst)
hist = prj.histograms()[0]
hname = hist.name
phases = prj.phases()
ip = hist.data["Instrument Parameters"][0]
sp = hist.data["Sample Parameters"]

sets = {}
for o in opts:
    if o.startswith("seed="):
        w, x, ma, mb = [float(v) for v in o[5:].split(",")]
        ip["W"][1], ip["X"][1] = w, x
        for p, m in zip(phases, (ma, mb)):
            p.data["Histograms"][hname]["Mustrain"][1][0] = m
    elif o.startswith("bg="):
        sets.setdefault("Background", {}).update(
            {"type": "chebyschev-1", "no. coeffs": int(o[3:]), "refine": True})
    elif o.startswith("po="):
        for p in phases:
            if p.name == "WO3":
                p.data["Histograms"][hname]["Pref.Ori."] = [
                    "MD", 1.0, True, [int(v) for v in o[3:].split(",")], 0, {}, [], 0.1]
    elif o == "atomX":
        sets.setdefault("Atoms", {})["all"] = "X"
    elif o == "uiso":
        sets.setdefault("Atoms", {})["all"] = "U"
    elif o == "atomXU":
        sets.setdefault("Atoms", {})["all"] = "XU"
    elif o == "metalX":
        for ph in phases:
            for a in ph.atoms():
                a.refinement_flags = "" if a.element == "O" else "X"
    elif o == "oxyX":
        for ph in phases:
            for a in ph.atoms():
                a.refinement_flags = "X" if a.element == "O" else ""
    elif o == "noX":
        for ph in phases:
            for a in ph.atoms():
                a.refinement_flags = ""
    elif o == "rough":
        sp["SurfRoughA"][1] = True
        sp["SurfRoughB"][1] = True
    elif o == "size":
        sets["Size"] = {"type": "isotropic", "refine": True}
    elif o == "mu":
        sets["Mustrain"] = {"type": "isotropic", "refine": True}

if sets:
    prj.do_refinements([{"set": sets}])
else:
    prj.do_refinements([{}])
prj.do_refinements([{}])

try:
    mf = hist.ComputeMassFracs()
except Exception:
    mf = {}
rv = prj.data["Covariance"]["data"]["Rvals"]
out = {"dst": os.path.basename(dst), "opts": opts, "Rwp": round(hist.get_wR(), 4),
       "GOF": round(rv.get("GOF", 0), 4), "Nvar": rv.get("Nvars"),
       "wt": {p.name: round(100*mf.get(p.name, (float('nan'),))[0], 2) for p in phases},
       "su": {p.name: round(100*mf.get(p.name, (0, float('nan')))[1], 3) for p in phases},
       "inst": {k: round(ip[k][1], 4) for k in ("U", "V", "W", "X", "Y", "SH/L")},
       "shift": round(sp["Shift"][0], 1),
       "rough": [round(sp["SurfRoughA"][0], 4), round(sp["SurfRoughB"][0], 4)],
       "mu": {p.name: round(p.data["Histograms"][hname]["Mustrain"][1][0], 1) for p in phases},
       "size": {p.name: round(p.data["Histograms"][hname]["Size"][1][0], 3) for p in phases},
       "cell": {p.name: [round(v, 5) for v in p.data["General"]["Cell"][1:8]] for p in phases},
       "PO": {p.name: p.data["Histograms"][hname].get("Pref.Ori.", [None, None])[1] for p in phases}}
print("RESULT " + json.dumps(out))
prj.save()
x = np.array(hist.data["data"][1][0]); yo = np.array(hist.data["data"][1][1])
yc = np.array(hist.data["data"][1][3]); yb = np.array(hist.data["data"][1][4])
np.savetxt(dst.replace(".gpx", "_prof.csv"), np.column_stack([x, yo, yc, yo-yc, yb]),
           delimiter=",", header="two_theta_deg,y_obs,y_calc,y_diff,y_bkg", comments="")
