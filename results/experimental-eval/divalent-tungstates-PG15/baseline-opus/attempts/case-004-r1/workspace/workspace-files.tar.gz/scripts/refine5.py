"""Rietveld refinement of the CoO + WO3 (900 C) product: gamma-WO3 + CoWO4.

Profile model:
  instrumental : Gaussian U, W (V=0) + axial divergence SH/L; X=Y=0
  sample       : per-phase isotropic crystallite size and microstrain (bounded)
"""
import os, sys, json
import numpy as np
sys.path.insert(0, "<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages")
from GSASII import GSASIIscriptable as G2sc

WD = "<ATTEMPT_WORKSPACE>/work"
NAME = os.environ.get("NAME", "r5")
NBG = int(os.environ.get("NBG", "12"))
EXTRA = os.environ.get("EXTRA", "")
STAGES = os.environ.get("STAGES", "bg,cell,inst,size,mu,atomX,atomU,final")
gpx = os.path.join(WD, NAME + ".gpx")
for f in (gpx, gpx.replace(".gpx", ".bak0.gpx")):
    if os.path.exists(f):
        os.remove(f)

prj = G2sc.G2Project(newgpx=gpx)
hist = prj.add_powder_histogram(os.path.join(WD, "pattern.xy"),
                                os.path.join(WD, "cu.instprm"), fmthint="Topas xye")
hname = hist.name
ip = hist.data["Instrument Parameters"][0]
for k, v in (("U", 0.0), ("V", 0.0), ("W", 500.0), ("X", 0.0), ("Y", 0.0), ("SH/L", 0.01)):
    ip[k][1] = v

specs = [("WO3", "WO3_start.cif"), ("CoWO4", "CoWO4_start.cif")]
if EXTRA:
    specs += [tuple(it.split(":")) for it in EXTRA.split(",")]
phases = [prj.add_phase(os.path.join(WD, cif), phasename=nm, histograms=[hist])
          for nm, cif in specs]
for p in phases:
    p.setSampleProfile(hname, "size", "isotropic", 5.0)
    p.setSampleProfile(hname, "mustrain", "isotropic", 100.)
    p.data["Histograms"][hname]["Scale"] = [1.0, True]

ctrl = prj.data["Controls"]["data"]
ctrl["parmMinDict"] = {}
ctrl["parmMaxDict"] = {}
for i in range(len(phases)):
    ctrl["parmMinDict"]["%d:0:Size;i" % i] = 0.03
    ctrl["parmMaxDict"]["%d:0:Size;i" % i] = 100.
    ctrl["parmMinDict"]["%d:0:Mustrain;i" % i] = 1.
    ctrl["parmMaxDict"]["%d:0:Mustrain;i" % i] = 8000.
ctrl["parmMinDict"][":0:W"] = 1.
ctrl["parmMinDict"][":0:SH/L"] = 0.0005
ctrl["parmMaxDict"][":0:SH/L"] = 0.1

def rep(tag):
    rv = prj.data["Covariance"]["data"].get("Rvals", {})
    print(f"--- {tag}: Rwp={hist.get_wR():.4f} GOF={rv.get('GOF',float('nan')):.4f}")
    for p in phases:
        c = p.data["General"]["Cell"]
        h = p.data["Histograms"][hname]
        print(f"    {p.name:8s} sc={h['Scale'][0]:.5f} a={c[1]:.5f} b={c[2]:.5f} c={c[3]:.5f} "
              f"bet={c[5]:.4f} V={c[7]:.3f} size={h['Size'][1][0]:.3f} mu={h['Mustrain'][1][0]:.0f}")
    print("    inst:", {k: round(ip[k][1], 4) for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")},
          "shift=%.1f" % hist.data["Sample Parameters"]["Shift"][0])

STEP = {
 "bg":    [{"set": {"Background": {"type": "chebyschev-1", "no. coeffs": NBG, "refine": True},
                    "Sample Parameters": ["Scale"]}}],
 "cell":  [{"set": {"Cell": True, "Sample Parameters": ["Shift"]}}],
 "inst":  [{"set": {"Instrument Parameters": ["W", "SH/L"]}},
           {"set": {"Instrument Parameters": ["U"]}}],
 "size":  [{"set": {"Size": {"type": "isotropic", "refine": True}}}],
 "mu":    [{"set": {"Mustrain": {"type": "isotropic", "refine": True}}}],
 "atomX": [{"set": {"Atoms": {"all": "X"}}}],
 "atomU": [{"set": {"Atoms": {"all": "U"}}}],
 "xy":    [{"set": {"Instrument Parameters": ["X", "Y"]}}],
 "final": [{}],
}
for tag in STAGES.split(","):
    prj.do_refinements(STEP[tag])
    rep(tag)

prj.save()
x = np.array(hist.data["data"][1][0]); yo = np.array(hist.data["data"][1][1])
yc = np.array(hist.data["data"][1][3]); yb = np.array(hist.data["data"][1][4])
np.savetxt(os.path.join(WD, NAME + "_prof.csv"), np.column_stack([x, yo, yc, yo-yc, yb]),
           delimiter=",", header="two_theta_deg,y_obs,y_calc,y_diff,y_bkg", comments="")
print("saved", gpx)
