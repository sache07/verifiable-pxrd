import sys
from pymatgen.core import Structure
for f in sys.argv[1:]:
    s = Structure.from_file(f)
    print("###", f, s.composition.reduced_formula, [round(v, 4) for v in s.lattice.parameters])
    for i, site in enumerate(s):
        if site.specie.symbol == "O":
            continue
        ns = s.get_neighbors(site, 2.6)
        ds = sorted(round(n.nn_distance, 3) for n in ns)
        print(f"   {site.specie.symbol}{i}: n={len(ds)} {ds}")
    # shortest O-O / cation-cation
    mind = min(s.distance_matrix[s.distance_matrix > 0.01])
    print("   min interatomic:", round(mind, 3))
