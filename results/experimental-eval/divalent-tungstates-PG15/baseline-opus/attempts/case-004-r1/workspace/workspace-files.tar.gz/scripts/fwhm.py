import numpy as np, sys
from scipy.optimize import curve_fit
d = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
x, y = d[:, 0], d[:, 1]

def pv(xx, x0, I, f, eta, b0, b1):
    s = f / 2
    g = np.exp(-4*np.log(2)*((xx-x0)/f)**2)
    l = 1/(1+4*((xx-x0)/f)**2)
    return I*(eta*l+(1-eta)*g) + b0 + b1*(xx-x0)

for c, w in [(19.06, 0.5), (26.66, 0.45), (30.71, 0.5), (35.69, 0.4), (38.60, 0.4),
             (47.28, 0.5), (52.13, 0.5), (65.13, 0.7), (76.94, 0.9)]:
    m = (x > c-w) & (x < c+w)
    try:
        p, _ = curve_fit(pv, x[m], y[m], p0=[c, y[m].max()-y[m].min(), 0.12, 0.5,
                                            y[m].min(), 0], maxfev=20000)
        print(f"  center {p[0]:8.3f}  FWHM {abs(p[2]):.4f}  eta {p[3]:.2f}  I {p[1]:.0f}")
    except Exception as e:
        print(c, "fail", e)
