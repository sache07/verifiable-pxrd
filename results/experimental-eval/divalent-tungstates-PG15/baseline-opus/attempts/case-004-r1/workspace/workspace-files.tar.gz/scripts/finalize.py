"""Write the deliverables from final.gpx: CIFs, fit.csv, result.json."""
import os, sys, json
import numpy as np
sys.path.insert(0, "<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages")
from GSASII import GSASIIscriptable as G2sc

ROOT = "<ATTEMPT_WORKSPACE>"
prj = G2sc.G2Project(os.path.join(ROOT, "final.gpx"))
hist = prj.histograms()[0]
hname = hist.name
phases = prj.phases()
cov = prj.data["Covariance"]["data"]
rv = cov["Rvals"]
sig = dict(zip(cov.get("varyList", []), cov.get("sig", [])))

# ---- profile ----
d = hist.data["data"][1]
x, yo, yc, yb = (np.array(d[0]), np.array(d[1]), np.array(d[3]), np.array(d[4]))
np.savetxt(os.path.join(ROOT, "fit.csv"),
           np.column_stack([x, yo, yc, yo - yc, yb]), delimiter=",", fmt="%.6f",
           header="two_theta_deg,y_obs,y_calc,y_diff,y_background", comments="")

# ---- fit statistics ----
sumw = np.sum(yo)                      # Rp denominators use observed intensities
Rp = 100 * np.sum(np.abs(yo - yc)) / sumw
stats = {"Rwp_percent": round(rv["Rwp"], 3),
         "Rp_percent": round(float(Rp), 3),
         "GOF": round(rv["GOF"], 4),
         "chi2_reduced": round(rv["GOF"] ** 2, 4),
         "chi2": round(rv["chisq"], 1),
         "n_observations": rv["Nobs"],
         "n_refined_variables": rv["Nvars"],
         "two_theta_range_deg": [round(float(x.min()), 4), round(float(x.max()), 4)]}

# values that GSAS-II only writes to the .lst listing
lst = open(os.path.join(ROOT, "final.lst")).read().splitlines()
cellsu, braggR = {}, {}
order = [ph.name for ph in phases]
k = 0
for i, ln in enumerate(lst):
    if ln.startswith("  names :           a"):
        v = lst[i + 2].split(":")[1].split()
        cellsu[order[k]] = {"a": float(v[0]), "b": float(v[1]), "c": float(v[2]),
                            "beta": float(v[3]), "volume": float(v[4])}
        k += 1
k = 0
for ln in lst:
    if "Final refinement RF" in ln:
        t = ln.split("=")[1].replace("%", "").replace(",", " ").split()
        braggR[order[k]] = {"RF_percent": float(t[0]), "RF2_percent": float(t[1]),
                            "n_reflections": int(t[3])}
        k += 1
    if "Other residuals:" in ln:
        f = [t for t in ln.replace("%", "").replace("=", " ").replace(",", " ").split()
             if t.replace(".", "").isdigit()]
        (stats["R_percent"], stats["R_background_subtracted_percent"],
         stats["wR_background_subtracted_percent"], stats["wR_expected_percent"]) = \
            [float(v) for v in f[:4]]
stats["bragg_R_factors"] = braggR

mf = hist.ComputeMassFracs()
SG = {"WO3": "P 1 21/n 1", "CoWO4": "P 1 2/c 1"}
FORMULA = {"WO3": "WO3", "CoWO4": "CoWO4"}
MINERAL = {"WO3": "gamma-WO3 (monoclinic tungsten trioxide)",
           "CoWO4": "CoWO4 (wolframite-type cobalt tungstate)"}
out = {"phases": [], "fit_statistics": stats}
for p in phases:
    cif = os.path.join(ROOT, p.name + ".cif")
    p.export_CIF(cif)
    c = p.data["General"]["Cell"]
    h = p.data["Histograms"][hname]
    pid = p.data["pId"]
    out["phases"].append({
        "name": FORMULA[p.name],
        "description": MINERAL[p.name],
        "space_group": p.data["General"]["SGData"]["SpGrp"],
        "cif": os.path.relpath(cif, ROOT),
        "weight_fraction": round(float(mf[p.name][0]), 4),
        "weight_fraction_percent": round(100 * float(mf[p.name][0]), 2),
        "weight_fraction_esd_percent": round(100 * float(mf[p.name][1]), 2),
        "lattice_parameters": {"a": round(c[1], 5), "b": round(c[2], 5), "c": round(c[3], 5),
                               "alpha": round(c[4], 4), "beta": round(c[5], 5),
                               "gamma": round(c[6], 4), "volume": round(c[7], 3)},
        "lattice_parameter_esd": cellsu.get(p.name, {}),
        "phase_scale_factor": round(h["Scale"][0], 5),
        "microstrain_1e-6": round(h["Mustrain"][1][0], 1),
    })
sp = hist.data["Sample Parameters"]
ipar = hist.data["Instrument Parameters"][0]
out["model"] = {
    "radiation": "Cu K-alpha1/K-alpha2, lambda = %.6f / %.6f A, I2/I1 = %.2f (fixed, as reported)"
                 % (ipar["Lam1"][1], ipar["Lam2"][1], ipar["I(L2)/I(L1)"][1]),
    "geometry": "Bragg-Brentano reflection",
    "background": "Chebyshev polynomial (1st kind), 12 terms, refined",
    "peak_shape": "pseudo-Voigt; refined Gaussian W = %.2f, Lorentzian X = %.2f (centideg), "
                  "axial divergence SH/L = %.4f; isotropic microstrain per phase"
                  % (ipar["W"][1], ipar["X"][1], ipar["SH/L"][1]),
    "sample_displacement_um": round(sp["Shift"][0], 1),
    "surface_roughness_Suortti": {"A": round(sp["SurfRoughA"][0], 4),
                                  "B": round(sp["SurfRoughB"][0], 4)},
    "refined_structural_parameters": "lattice parameters and metal-atom coordinates "
        "(W in WO3; Co and W y-coordinates in CoWO4); oxygen coordinates and all Uiso held "
        "at literature values",
    "starting_models": {"WO3": "COD 2311041 (gamma-WO3, P2_1/c beta=136.06) transformed to the "
                               "conventional P2_1/n setting",
                        "CoWO4": "COD 5910316 (CoWO4 wolframite, P2/c)"},
    "phases_tested_and_rejected": {
        "Co3O4": "refines to 0.0 wt% (no Rwp change); not detected",
        "CoO": "refines to 0.0 wt% (no Rwp change); not detected"},
    "estimated_detection_limit_wt_percent": 1.0,
    "weight_fraction_model_uncertainty_percent": 1.5,
}
tot = sum(ph["weight_fraction"] for ph in out["phases"])
out["weight_fraction_normalisation"] = {"sum_over_modelled_crystalline_phases": round(tot, 6),
                                        "amorphous_or_unmodelled_content": "not determined "
                                        "(no internal standard; fractions are normalised to "
                                        "100% of the modelled crystalline phases)"}
json.dump(out, open(os.path.join(ROOT, "result.json"), "w"), indent=2)
print(json.dumps(out, indent=2))
