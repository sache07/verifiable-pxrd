"""Transform the 1966 gamma-WO3 structure (COD 2311041, P2_1/c, beta=136.06)
into the conventional P2_1/n setting (a~7.30, b~7.54, c~7.69, beta~90.9)."""
import numpy as np
from pymatgen.core import Structure, Lattice
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

src = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif"
s = Structure.from_file(src)
print("in :", s.lattice.parameters, s.composition)

M = np.array([[1, 0, 1], [0, 1, 0], [-1, 0, 0]])     # new vectors in terms of old
newmat = M @ s.lattice.matrix
newlat = Lattice(newmat)
print("new lattice:", [round(v, 4) for v in newlat.parameters])
frac = np.array([newlat.get_fractional_coords(c) for c in s.cart_coords]) % 1.0
s2 = Structure(newlat, [sp.symbol for sp in s.species], frac)
sga = SpacegroupAnalyzer(s2, symprec=0.05)
print("sg:", sga.get_space_group_symbol(), sga.get_space_group_number())
sym = sga.get_refined_structure()
print("refined:", [round(v, 4) for v in sym.lattice.parameters], sym.composition)
sga2 = SpacegroupAnalyzer(sym, symprec=0.02)
ds = sga2.get_symmetrized_structure()
print("asym unit:")
for grp, wy in zip(ds.equivalent_sites, ds.wyckoff_symbols):
    st = grp[0]
    print("  ", st.specie.symbol, wy, [round(v, 5) for v in st.frac_coords], len(grp))
ds.to(filename="work/WO3_pn.cif", fmt="cif", symprec=0.02)
print(open("work/WO3_pn.cif").read()[:2000])
