import gzip, json, sys
P="<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz"
info=json.load(gzip.open(P,"rt"))
for key in sys.argv[1:]:
    print("===", key)
    for e in info.get(key, []):
        print("  ", e)
