"""Add a candidate minor phase to a converged project and refine its scale.

usage: addphase.py SRC.gpx DST.gpx NAME CIF
Reports Rwp before/after and the refined weight fraction of the added phase.
"""
import os, sys, json, shutil
import numpy as np
sys.path.insert(0, "<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages")
from GSASII import GSASIIscriptable as G2sc

src, dst, nm, cif = sys.argv[1:5]
shutil.copy(src, dst)
prj = G2sc.G2Project(dst)
hist = prj.histograms()[0]
hname = hist.name
print("Rwp before:", round(hist.get_wR(), 4))
p = prj.add_phase(cif, phasename=nm, histograms=[hist])
p.setSampleProfile(hname, "size", "isotropic", 10.0)
p.setSampleProfile(hname, "mustrain", "isotropic", 1000.)
p.data["Histograms"][hname]["Scale"] = [0.05, True]
for a in p.data["Atoms"]:
    a[10] = 0.01
prj.save()
prj.do_refinements([{}])
prj.do_refinements([{"set": {"Cell": True}}])
try:
    mf = hist.ComputeMassFracs()
except Exception as e:
    mf = {}
rv = prj.data["Covariance"]["data"]["Rvals"]
print("RESULT " + json.dumps({
    "added": nm, "Rwp": round(hist.get_wR(), 4), "GOF": round(rv.get("GOF", 0), 4),
    "wt": {q.name: round(100*mf.get(q.name, (float('nan'),))[0], 3) for q in prj.phases()},
    "su": {q.name: round(100*mf.get(q.name, (0, float('nan')))[1], 3) for q in prj.phases()},
    "scale": {q.name: round(q.data["Histograms"][hname]["Scale"][0], 5) for q in prj.phases()},
    "cell_added": [round(v, 5) for v in p.data["General"]["Cell"][1:8]]}))
prj.save()
