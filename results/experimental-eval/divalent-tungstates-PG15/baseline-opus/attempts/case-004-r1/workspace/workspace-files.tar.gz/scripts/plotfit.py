import sys, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
d = np.loadtxt(sys.argv[1], delimiter=",", skiprows=1)
x, yo, yc, yd = d[:, 0], d[:, 1], d[:, 2], d[:, 3]
n = 3
fig, axs = plt.subplots(n, 1, figsize=(17, 4*n))
edges = np.linspace(x.min(), x.max(), n+1)
for i, ax in enumerate(axs):
    m = (x >= edges[i]) & (x <= edges[i+1])
    ax.plot(x[m], yo[m], "k.", ms=1.5, label="obs")
    ax.plot(x[m], yc[m], "r-", lw=0.8, label="calc")
    off = -0.25*(yo[m].max())
    ax.plot(x[m], yd[m]+off, "b-", lw=0.6, label="diff")
    ax.axhline(off, color="gray", lw=0.4)
    ax.legend(fontsize=7)
plt.tight_layout(); plt.savefig(sys.argv[2], dpi=120)
print("ok", np.abs(yd).max())
