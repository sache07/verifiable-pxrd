import gzip, json, sys, re
P="<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz"
info=json.load(gzip.open(P,"rt"))
print(type(info), len(info))
if isinstance(info, dict):
    k=list(info)[:3]
    for kk in k: print(kk, json.dumps(info[kk])[:400])
else:
    for e in info[:3]: print(json.dumps(e)[:400])
