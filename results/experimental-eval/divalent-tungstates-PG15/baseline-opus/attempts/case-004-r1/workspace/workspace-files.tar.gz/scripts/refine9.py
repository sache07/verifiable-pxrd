"""Production Rietveld refinement: gamma-WO3 (P2_1/n) + CoWO4 (wolframite, P2/c).

Model:
  background   Chebyshev (NBG terms)
  profile      Gaussian W + Lorentzian X + axial divergence SH/L (U=V=Y=0)
               plus per-phase isotropic microstrain
  corrections  sample displacement, Bragg-Brentano surface roughness (A,B)
  structures   literature starting models; Uiso and/or coordinates optionally
               refined (element-wise Uiso equivalences, optional M-O soft
               bond restraints)

Variants are selected with environment variables so that the model dependence
of the phase fractions can be assessed.
"""
import os, sys, json
import numpy as np
sys.path.insert(0, "<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages")
from GSASII import GSASIIscriptable as G2sc

WD = "<ATTEMPT_WORKSPACE>/work"
NAME = os.environ.get("NAME", "m1")
NBG = int(os.environ.get("NBG", "12"))
EXTRA = os.environ.get("EXTRA", "")
ROUGH = os.environ.get("ROUGH", "1") == "1"
STAGES = os.environ.get("STAGES", "bg,cell,inst,mu,rough,all")
RWT = float(os.environ.get("RWT", "0"))
RESD = float(os.environ.get("RESD", "0.15"))
PO = os.environ.get("PO", "")
UISO0 = {"W": 0.005, "Co": 0.008, "O": 0.012}

gpx = os.path.join(WD, NAME + ".gpx")
for f in (gpx, gpx.replace(".gpx", ".bak0.gpx")):
    if os.path.exists(f):
        os.remove(f)
prj = G2sc.G2Project(newgpx=gpx)
hist = prj.add_powder_histogram(os.path.join(WD, "pattern.xy"),
                               os.path.join(WD, "cu.instprm"), fmthint="Topas xye")
hname = hist.name
ip = hist.data["Instrument Parameters"][0]
for k, v in (("U", 0.0), ("V", 0.0), ("W", 200.0), ("X", 10.0), ("Y", 0.0), ("SH/L", 0.01)):
    ip[k][1] = v

specs = [("WO3", os.environ.get("WO3CIF", "WO3_pn.cif")), ("CoWO4", "CoWO4_start.cif")]
if EXTRA:
    specs += [tuple(it.split(":")) for it in EXTRA.split(",")]
phases = [prj.add_phase(os.path.join(WD, cif), phasename=nm, histograms=[hist])
          for nm, cif in specs]
for p in phases:
    p.setSampleProfile(hname, "size", "isotropic", 10.0)
    p.setSampleProfile(hname, "mustrain", "isotropic", 500.)
    p.data["Histograms"][hname]["Scale"] = [1.0, True]
    for a in p.data["Atoms"]:
        a[10] = UISO0.get(a[1].split("+")[0].split("-")[0], 0.01)
prj.save()

for ipx, p in enumerate(phases):          # element-wise Uiso equivalences
    byel = {}
    for ia, a in enumerate(p.data["Atoms"]):
        byel.setdefault(a[1].split("+")[0].split("-")[0], []).append(ia)
    for el, idx in byel.items():
        if len(idx) > 1:
            prj.add_EquivConstr(["%d::AUiso:%d" % (ipx, i) for i in idx], reloadIdx=False)

ctrl = prj.data["Controls"]["data"]
ctrl["parmMinDict"] = {":0:W": 1.0, ":0:SH/L": 0.0003, ":0:X": 0.0,
                       ":0:SurfRoughA": 0.0, ":0:SurfRoughB": 0.01}
ctrl["parmMaxDict"] = {":0:SH/L": 0.1, ":0:SurfRoughA": 1.0, ":0:SurfRoughB": 5.0}
for i, p in enumerate(phases):
    ctrl["parmMinDict"]["%d:0:Size;i" % i] = 0.05
    ctrl["parmMinDict"]["%d:0:Mustrain;i" % i] = 10.
    ctrl["parmMaxDict"]["%d:0:Mustrain;i" % i] = 10000.
    for ia in range(len(p.data["Atoms"])):
        ctrl["parmMinDict"]["%d::AUiso:%d" % (i, ia)] = 0.001
        ctrl["parmMaxDict"]["%d::AUiso:%d" % (i, ia)] = 0.06

if ROUGH:                      # released from the first cycle (best convergence)
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.2, True]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.5, True]

if PO:
    for item in PO.split(";"):
        nm, ax = item.split(":")
        for p in phases:
            if p.name == nm:
                p.data["Histograms"][hname]["Pref.Ori."] = [
                    "MD", 1.0, True, [int(v) for v in ax.split(",")], 0, {}, [], 0.1]

def addrestraints():
    for p in phases:
        prj.data.setdefault("Restraints", {"data": {}})
        prj.data["Restraints"]["data"].setdefault(p.name, {})
        prj.data["Restraints"]["data"][p.name].setdefault(
            "Bond", {"wtFactor": 1.0, "Bonds": [], "Use": True})
        p.clearDistRestraint()
        oxy = [i for i, a in enumerate(p.data["Atoms"]) if a[1].startswith("O")]
        for el, d in (("W", 1.92), ("Co", 2.10)):
            orig = [i for i, a in enumerate(p.data["Atoms"]) if a[1].startswith(el)]
            if orig:
                n = p.addDistRestraint(orig, oxy, d, factor=1.3, ESD=RESD)
                print(f"    restraints {p.name} {el}-O {d}+-{RESD}: {n}")
        p.setDistRestraintWeight(RWT)
    prj.save()

def rep(tag):
    rv = prj.data["Covariance"]["data"].get("Rvals", {})
    try:
        mf = hist.ComputeMassFracs()
    except Exception:
        mf = {}
    sp = hist.data["Sample Parameters"]
    out = {"tag": NAME + ":" + tag, "Rwp": round(hist.get_wR(), 4),
           "GOF": round(rv.get("GOF", float("nan")), 4), "Nvar": rv.get("Nvars"),
           "restr": round(rv.get("RestraintSum", 0) or 0, 1),
           "wt": {p.name: round(100*mf.get(p.name, (float('nan'),))[0], 2) for p in phases},
           "su": {p.name: round(100*mf.get(p.name, (0, float('nan')))[1], 3) for p in phases},
           "inst": {k: round(ip[k][1], 4) for k in ("W", "X", "SH/L")},
           "shift": round(sp["Shift"][0], 1),
           "rough": [round(sp["SurfRoughA"][0], 4), round(sp["SurfRoughB"][0], 4)],
           "mu": {p.name: round(p.data["Histograms"][hname]["Mustrain"][1][0], 1) for p in phases},
           "cell": {p.name: [round(v, 5) for v in p.data["General"]["Cell"][1:8]] for p in phases},
           "Uiso": {p.name: {a[0]: round(a[10], 5) for a in p.data["Atoms"]} for p in phases},
           "PO": {p.name: p.data["Histograms"][hname].get("Pref.Ori.", [None, None])[1]
                  for p in phases}}
    print("RESULT " + json.dumps(out))

STEP = {
 "bg":    [{"set": {"Background": {"type": "chebyschev-1", "no. coeffs": NBG, "refine": True},
                    "Sample Parameters": ["Scale"]}}],
 "cell":  [{"set": {"Cell": True, "Sample Parameters": ["Shift"]}}],
 "inst":  [{"set": {"Instrument Parameters": ["W", "X", "SH/L"]}}],
 "mu":    [{"set": {"Mustrain": {"type": "isotropic", "refine": True}}}],
 "uiso":  [{"set": {"Atoms": {"all": "U"}}}],
 "atomX": [{"set": {"Atoms": {"all": "X"}}}],
 "all":   [{}],
}
for tag in STAGES.split(","):
    if tag == "rough":
        hist.data["Sample Parameters"]["SurfRoughA"][0] = 0.2
        hist.data["Sample Parameters"]["SurfRoughB"][0] = 0.5
        hist.data["Sample Parameters"]["SurfRoughA"][1] = ROUGH
        hist.data["Sample Parameters"]["SurfRoughB"][1] = ROUGH
        prj.do_refinements([{}])
    elif tag == "restr":
        addrestraints()
        continue
    else:
        prj.do_refinements(STEP[tag])
    rep(tag)

prj.save()
x = np.array(hist.data["data"][1][0]); yo = np.array(hist.data["data"][1][1])
yc = np.array(hist.data["data"][1][3]); yb = np.array(hist.data["data"][1][4])
np.savetxt(os.path.join(WD, NAME + "_prof.csv"), np.column_stack([x, yo, yc, yo-yc, yb]),
           delimiter=",", header="two_theta_deg,y_obs,y_calc,y_diff,y_bkg", comments="")
print("saved", gpx)
