"""Rietveld refinement of the CoO + WO3 (900 C) product.

Phases: gamma-WO3 (P2_1/n, COD 2311041 transformed) + CoWO4 (wolframite, P2/c).
Coordinates are refined under M-O bond-distance restraints so that the weakly
scattering oxygen sublattice cannot run away from chemically sensible geometry.
"""
import os, sys, json
import numpy as np
sys.path.insert(0, "<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages")
from GSASII import GSASIIscriptable as G2sc

WD = "<ATTEMPT_WORKSPACE>/work"
NAME = os.environ.get("NAME", "r8")
NBG = int(os.environ.get("NBG", "12"))
EXTRA = os.environ.get("EXTRA", "")
STAGES = os.environ.get("STAGES", "bg,cell,inst,xy,mu,restr,atomX,uiso,final")
RWT = float(os.environ.get("RWT", "300"))
RESD = float(os.environ.get("RESD", "0.05"))
PO = os.environ.get("PO", "")
ROUGH = os.environ.get("ROUGH", "0") == "1"
gpx = os.path.join(WD, NAME + ".gpx")
for f in (gpx, gpx.replace(".gpx", ".bak0.gpx")):
    if os.path.exists(f):
        os.remove(f)

prj = G2sc.G2Project(newgpx=gpx)
hist = prj.add_powder_histogram(os.path.join(WD, "pattern.xy"),
                               os.path.join(WD, "cu.instprm"), fmthint="Topas xye")
hname = hist.name
ip = hist.data["Instrument Parameters"][0]
for k, v in (("U", 0.0), ("V", 0.0), ("W", 300.0), ("X", 0.0), ("Y", 0.0), ("SH/L", 0.02)):
    ip[k][1] = v
if "RATIO" in os.environ:
    ip["I(L2)/I(L1)"][1] = float(os.environ["RATIO"])
if "POLA" in os.environ:
    ip["Polariz."][1] = float(os.environ["POLA"])

specs = [("WO3", os.environ.get("WO3CIF", "WO3_pn.cif")), ("CoWO4", "CoWO4_start.cif")]
if EXTRA:
    specs += [tuple(it.split(":")) for it in EXTRA.split(",")]
phases = [prj.add_phase(os.path.join(WD, cif), phasename=nm, histograms=[hist])
          for nm, cif in specs]
UISO0 = {"W": 0.005, "Co": 0.008, "O": 0.012}
for p in phases:
    p.setSampleProfile(hname, "size", "isotropic", 10.0)
    p.setSampleProfile(hname, "mustrain", "isotropic", 1000.)
    p.data["Histograms"][hname]["Scale"] = [1.0, True]
    for a in p.data["Atoms"]:
        a[10] = UISO0.get(a[1].split("+")[0].split("-")[0], 0.01)
prj.save()

# Uiso equivalences per element within each phase
for ipx, p in enumerate(phases):
    byel = {}
    for ia, a in enumerate(p.data["Atoms"]):
        byel.setdefault(a[1].split("+")[0].split("-")[0], []).append(ia)
    for el, idx in byel.items():
        if len(idx) > 1:
            prj.add_EquivConstr(["%d::AUiso:%d" % (ipx, i) for i in idx], reloadIdx=False)

ctrl = prj.data["Controls"]["data"]
ctrl["parmMinDict"] = {":0:W": 1.0, ":0:SH/L": 0.0005, ":0:X": 0.0, ":0:Y": 0.0}
ctrl["parmMaxDict"] = {":0:SH/L": 0.1}
for i, p in enumerate(phases):
    ctrl["parmMinDict"]["%d:0:Size;i" % i] = 0.05
    ctrl["parmMinDict"]["%d:0:Mustrain;i" % i] = 10.
    ctrl["parmMaxDict"]["%d:0:Mustrain;i" % i] = 10000.
    for ia in range(len(p.data["Atoms"])):
        ctrl["parmMinDict"]["%d::AUiso:%d" % (i, ia)] = 0.0015
        ctrl["parmMaxDict"]["%d::AUiso:%d" % (i, ia)] = 0.06

if PO:
    for item in PO.split(";"):
        nm, ax = item.split(":")
        for p in phases:
            if p.name == nm:
                h = p.data["Histograms"][hname]
                h["Pref.Ori."] = ["MD", 1.0, True, [int(v) for v in ax.split(",")], 0, {}, [], 0.1]
if ROUGH:
    hist.data["Sample Parameters"]["SurfRoughA"][1] = True
    hist.data["Sample Parameters"]["SurfRoughB"][1] = True

def addrestraints():
    tgt = {"W": 1.92, "Co": 2.10}
    for p in phases:
        prj.data.setdefault("Restraints", {"data": {}})
        prj.data["Restraints"]["data"].setdefault(p.name, {})
        prj.data["Restraints"]["data"][p.name].setdefault(
            "Bond", {"wtFactor": 1.0, "Bonds": [], "Use": True})
        p.clearDistRestraint()
        oxy = [i for i, a in enumerate(p.data["Atoms"]) if a[1].startswith("O")]
        for el, d in tgt.items():
            orig = [i for i, a in enumerate(p.data["Atoms"]) if a[1].startswith(el)]
            if orig:
                n = p.addDistRestraint(orig, oxy, d, factor=1.25, ESD=RESD)
                print(f"    restraints {p.name} {el}-O d={d}: {n}")
        p.setDistRestraintWeight(RWT)
    prj.save()

def rep(tag):
    rv = prj.data["Covariance"]["data"].get("Rvals", {})
    print(f"--- {tag}: Rwp={hist.get_wR():.4f} GOF={rv.get('GOF',float('nan')):.4f} "
          f"Nvar={rv.get('Nvars')} restr={rv.get('RestraintSum')}")
    try:
        mf = hist.ComputeMassFracs()
    except Exception:
        mf = {}
    for p in phases:
        c = p.data["General"]["Cell"]
        h = p.data["Histograms"][hname]
        w = mf.get(p.name, (float("nan"), float("nan")))
        po = h.get("Pref.Ori.", [None, None])[1]
        print(f"    {p.name:8s} wt={100*w[0]:6.2f}({100*w[1]:.2f}) sc={h['Scale'][0]:.5f} "
              f"a={c[1]:.5f} b={c[2]:.5f} c={c[3]:.5f} bet={c[5]:.4f} V={c[7]:.3f} "
              f"mu={h['Mustrain'][1][0]:.0f} size={h['Size'][1][0]:.2f} PO={po} "
              f"U={[round(a[10],4) for a in p.data['Atoms']]}")
    sp = hist.data["Sample Parameters"]
    print("    inst:", {k: round(ip[k][1], 4) for k in ("U", "V", "W", "X", "Y", "SH/L",
                                                        "I(L2)/I(L1)", "Polariz.")},
          "shift=%.1f rough=%.4f,%.4f" % (sp["Shift"][0], sp["SurfRoughA"][0], sp["SurfRoughB"][0]))

STEP = {
 "bg":    [{"set": {"Background": {"type": "chebyschev-1", "no. coeffs": NBG, "refine": True},
                    "Sample Parameters": ["Scale"]}}],
 "cell":  [{"set": {"Cell": True, "Sample Parameters": ["Shift"]}}],
 "inst":  [{"set": {"Instrument Parameters": ["W", "SH/L"]}},
           {"set": {"Instrument Parameters": ["U"]}}],
 "xy":    [{"set": {"Instrument Parameters": ["X", "Y"]}}],
 "mu":    [{"set": {"Mustrain": {"type": "isotropic", "refine": True}}}],
 "atomX": [{"set": {"Atoms": {"all": "X"}}}],
 "uiso":  [{"set": {"Atoms": {"all": "U"}}}],
 "ratio": [{"set": {"Instrument Parameters": ["I(L2)/I(L1)"]}}],
 "pola":  [{"set": {"Instrument Parameters": ["Polariz."]}}],
 "final": [{}],
}
for tag in STAGES.split(","):
    if tag == "restr":
        addrestraints()
        continue
    prj.do_refinements(STEP[tag])
    rep(tag)

prj.save()
x = np.array(hist.data["data"][1][0]); yo = np.array(hist.data["data"][1][1])
yc = np.array(hist.data["data"][1][3]); yb = np.array(hist.data["data"][1][4])
np.savetxt(os.path.join(WD, NAME + "_prof.csv"), np.column_stack([x, yo, yc, yo-yc, yb]),
           delimiter=",", header="two_theta_deg,y_obs,y_calc,y_diff,y_bkg", comments="")
print("saved", gpx)
