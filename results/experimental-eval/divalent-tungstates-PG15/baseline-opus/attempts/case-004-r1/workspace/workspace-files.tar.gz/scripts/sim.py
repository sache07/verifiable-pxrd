import sys
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator
c = XRDCalculator(wavelength=1.540598)
for f in sys.argv[1:]:
    s = Structure.from_file(f)
    p = c.get_pattern(s, two_theta_range=(10, 70))
    print("###", f, s.composition.reduced_formula, s.lattice.abc, s.lattice.angles)
    for x, i, hk in zip(p.x, p.y, p.hkls):
        if i > 1.5:
            print(f"  {x:8.3f} {i:7.1f}  {hk[0]['hkl']}")
