"""Staged Rietveld refinement: gamma-WO3 + CoWO4 (+ optional extra phases).

Profile strategy: instrumental Gaussian constant (W) + axial asymmetry (SH/L)
refined globally; all angle-dependent broadening carried by per-phase
isotropic crystallite size (Lorentzian, 1/cos th) and microstrain (tan th).
U, V, X, Y are held at zero to avoid the strong correlations seen when both
instrumental and sample broadening terms are released together.
"""
import os, sys, json
import numpy as np
sys.path.insert(0, "<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages")
from GSASII import GSASIIscriptable as G2sc

W = "<ATTEMPT_WORKSPACE>/work"
NAME = os.environ.get("NAME", "r2")
NBG = int(os.environ.get("NBG", "12"))
EXTRA = os.environ.get("EXTRA", "")
DO_ATOMS = os.environ.get("ATOMS", "1") == "1"
MUSTRAIN = os.environ.get("MUSTRAIN", "iso")   # iso | uniax
PO = os.environ.get("PO", "")                  # e.g. "WO3:0,0,1"
gpx = os.path.join(W, NAME + ".gpx")
if os.path.exists(gpx):
    os.remove(gpx)

prj = G2sc.G2Project(newgpx=gpx)
hist = prj.add_powder_histogram(os.path.join(W, "pattern.xy"),
                                os.path.join(W, "cu.instprm"), fmthint="Topas xye")
hname = hist.name
ip = hist.data["Instrument Parameters"][0]
for k, v in (("U", 0.0), ("V", 0.0), ("W", 8.0), ("X", 0.0), ("Y", 0.0)):
    ip[k][1] = v

specs = [("WO3", "WO3_start.cif"), ("CoWO4", "CoWO4_start.cif")]
if EXTRA:
    specs += [tuple(it.split(":")) for it in EXTRA.split(",")]
phases = [prj.add_phase(os.path.join(W, cif), phasename=nm, histograms=[hist])
          for nm, cif in specs]
for p in phases:
    p.setSampleProfile(hname, "size", "isotropic", 1.0)
    p.setSampleProfile(hname, "mustrain", "isotropic", 1000.)
    p.data["Histograms"][hname]["Scale"] = [1.0, True]

def rep(tag):
    rv = prj.data["Covariance"]["data"].get("Rvals", {})
    print(f"--- {tag}: Rwp={hist.get_wR():.4f} GOF={rv.get('GOF',float('nan')):.4f}")
    for p in phases:
        c = p.data["General"]["Cell"]
        h = p.data["Histograms"][hname]
        print(f"    {p.name:8s} sc={h['Scale'][0]:.5f} a={c[1]:.5f} b={c[2]:.5f} c={c[3]:.5f} "
              f"bet={c[5]:.4f} V={c[7]:.3f} size={h['Size'][1][0]:.3f} mu={h['Mustrain'][1][0]:.0f}")
    print("    inst:", {k: round(ip[k][1], 4) for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")},
          "shift=%.1f" % hist.data["Sample Parameters"]["Shift"][0])

steps = [
    ("bg", [{"set": {"Background": {"type": "chebyschev-1", "no. coeffs": NBG, "refine": True},
                     "Sample Parameters": ["Scale"]}}]),
    ("cell", [{"set": {"Cell": True, "Sample Parameters": ["Shift"]}}]),
    ("width", [{"set": {"Size": {"type": "isotropic", "refine": True},
                        "Mustrain": {"type": "isotropic", "refine": True}}},
               {"set": {"Instrument Parameters": ["W", "SH/L"]}}]),
]
if DO_ATOMS:
    steps.append(("atomsX", [{"set": {"Atoms": {"all": "X"}}}]))
    steps.append(("atomsU", [{"set": {"Atoms": {"all": "U"}}}]))
if MUSTRAIN == "uniax":
    steps.append(("mu-uniax", []))
if PO:
    steps.append(("po", []))

for tag, dicts in steps:
    if tag == "mu-uniax":
        for p in phases:
            ax = [0, 0, 1] if p.name == "WO3" else [0, 1, 0]
            p.setSampleProfile(hname, "mustrain", "uniaxial",
                               [p.data["Histograms"][hname]["Mustrain"][1][0]] * 2, axis=ax)
            p.data["Histograms"][hname]["Mustrain"][2] = [True, True, False]
    if tag == "po":
        for item in PO.split(";"):
            nm, ax = item.split(":")
            for p in phases:
                if p.name == nm:
                    h = p.data["Histograms"][hname]
                    h["Pref.Ori."] = ['MD', 1.0, True, [int(v) for v in ax.split(",")], 0, {}, [], 0.1]
    if dicts:
        prj.do_refinements(dicts)
    else:
        prj.do_refinements([{}])
    rep(tag)

prj.save()
# dump profile + fractions
x = np.array(hist.data["data"][1][0])
yo = np.array(hist.data["data"][1][1])
yc = np.array(hist.data["data"][1][3])
yb = np.array(hist.data["data"][1][4])
np.savetxt(os.path.join(W, NAME + "_prof.csv"),
           np.column_stack([x, yo, yc, yo - yc, yb]), delimiter=",",
           header="two_theta_deg,y_obs,y_calc,y_diff,y_bkg", comments="")
print("WtFrac:", prj.get_Variable if False else "")
for p in phases:
    print("  ", p.name, p.data["Histograms"][hname]["Scale"])
print("saved", gpx)
