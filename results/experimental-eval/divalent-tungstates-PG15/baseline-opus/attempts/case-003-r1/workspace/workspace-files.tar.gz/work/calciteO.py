"""Refine the single free calcite oxygen coordinate as well."""
import sys
from g2lib import *
src, tag = sys.argv[1], sys.argv[2]
dst = os.path.join(GPX, '%s.gpx' % tag)
shutil.copy(os.path.join(GPX, src), dst)
gpx = G2sc.G2Project(dst); h = gpx.histograms()[0]
print('start Rwp %.4f' % h.get_wR())
for p in gpx.phases():
    if p.name == 'CaCO3':
        p.set_refinements({'Atoms': {'O1': 'X'}})
gpx.data['Controls']['data']['parmFrozen'] = {'FrozenList': []}
R = Runner(gpx, h, tag); R.best = 1e9; R.save_ckpt()
for i in range(2):
    gpx, h, ok = R.step('converge %d' % i, 20)
    if not ok: break
summary(gpx, h)
for p in gpx.phases():
    if p.name == 'CaCO3':
        print('  calcite O1 x =', [round(v, 5) for v in p.atom('O1').coordinates])
gpx.save()
