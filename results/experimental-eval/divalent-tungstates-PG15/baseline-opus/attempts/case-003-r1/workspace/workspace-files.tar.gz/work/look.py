"""Detailed inspection of a refined project: parameters, ADPs, bond lengths, wt fractions."""
import sys
from g2lib import *

gpx = G2sc.G2Project(os.path.join(GPX, sys.argv[1]))
h = gpx.histograms()[0]
hn = h.name
cov = gpx.data['Covariance']['data']
print('Rwp %.4f  GOF %.4f  nvar %d' % (h.get_wR(), cov['Rvals']['GOF'], len(cov['varyList'])))
print('frozen:', gpx.data['Controls']['data'].get('parmFrozen', {}).get('FrozenList', []))
sd = cov.get('sigDict', {})
mf = mass_fractions(gpx, h)
for p in gpx.phases():
    hd = p.data['Histograms'][hn]
    print('== %s  (%s)  wt=%.4f' % (p.name, p.data['General']['SGData']['SpGrp'], mf[p.name]))
    c = p.data['General']['Cell']
    print('   cell %.5f %.5f %.5f  %.4f %.4f %.4f  V=%.3f' % tuple(c[1:8]))
    print('   scale %.5g +/- %s' % (hd['Scale'][0], sd.get('%d:0:Scale' % p.id)))
    print('   Size %s %s  LGmix %.3f' % (hd['Size'][0], [round(v, 4) for v in hd['Size'][1][:2]],
                                         hd['Size'][1][2]))
    print('   Mustrain %s %s  LGmix %.3f' % (hd['Mustrain'][0],
                                             [round(v, 1) for v in hd['Mustrain'][1][:2]],
                                             hd['Mustrain'][1][2]))
    print('   PO %s %s axis %s' % (hd['Pref.Ori.'][0], round(hd['Pref.Ori.'][1], 4),
                                   hd['Pref.Ori.'][3]))
    for a in p.data['Atoms']:
        cx, ct, cs, cia = p.data['General']['AtomPtrs']
        adp = a[cia + 1] if a[cia] == 'I' else 'aniso %s' % [round(v, 4) for v in a[cia + 2:cia + 8]]
        print('   %-4s %-2s %9.5f %9.5f %9.5f occ %.2f  %s' %
              (a[ct - 1], a[ct], a[cx], a[cx + 1], a[cx + 2], a[cx + 3], adp))
sp = h.data['Sample Parameters']
ip = h.data['Instrument Parameters'][0]
print('Shift %.1f (+/-%s) SurfRoughA %.4f B %.4f' % (sp['Shift'][0], sd.get(':0:Shift'),
                                                     sp['SurfRoughA'][0], sp['SurfRoughB'][0]))
print('U %.2f V %.2f W %.2f X %.3f Y %.3f SH/L %.4f Pol %.2f Zero %.4f' %
      (ip['U'][1], ip['V'][1], ip['W'][1], ip['X'][1], ip['Y'][1], ip['SH/L'][1],
       ip['Polariz.'][1], ip['Zero'][1]))
