"""Build a GSAS-II project with the candidate phases and do a first look."""
import os, sys, numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc

WORK = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(WORK, 'data', 'pattern.xy')
IPRM = os.path.join(WORK, 'data', 'lab_cuka.instprm')
REFS = os.path.join(WORK, 'refs')

phases = sys.argv[2:]           # cif basenames
out = os.path.join(WORK, 'gpx', sys.argv[1])

gpx = G2sc.G2Project(newgpx=out)
hist = gpx.add_powder_histogram(DATA, IPRM, fmthint='Topas')
for cif in phases:
    gpx.add_phase(os.path.join(REFS, cif), phasename=cif.replace('.cif', ''), histograms=[hist])

hist.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True}})
gpx.set_refinement({'set': {'Scale': True}})
gpx.do_refinements([{}])
print('Rwp =', hist.get_wR())
gpx.save()
