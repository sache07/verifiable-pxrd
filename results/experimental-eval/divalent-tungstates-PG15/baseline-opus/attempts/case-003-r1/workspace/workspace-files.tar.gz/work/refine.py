"""Staged Rietveld refinement of the CaCO3 + WO3 -> CaWO4 product mixture."""
import os, sys, numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc

WORK = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(WORK, 'data', 'pattern.xy')
IPRM = os.path.join(WORK, 'data', 'lab_cuka.instprm')
REFS = os.path.join(WORK, 'refs')

CIFS = {'CaWO4': '7219229.cif', 'WO3': '1528915.cif', 'CaCO3': '1547347.cif'}
if len(sys.argv) > 2:
    CIFS = dict(p.split('=') for p in sys.argv[2:])
out = os.path.join(WORK, 'gpx', sys.argv[1])

gpx = G2sc.G2Project(newgpx=out)
h = gpx.add_powder_histogram(DATA, IPRM, fmthint='Topas')
for name, cif in CIFS.items():
    gpx.add_phase(os.path.join(REFS, cif), phasename=name, histograms=[h])

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True},
                   'Sample Parameters': ['Scale']})
for p in gpx.phases():
    p.set_HAP_refinements({'Scale': True})


def step(label, hist_ref=None, phase_ref=None, hap_ref=None, cycles=5):
    if hist_ref:
        h.set_refinements(hist_ref)
    if phase_ref:
        for p in gpx.phases():
            p.set_refinements(phase_ref)
    if hap_ref:
        for p in gpx.phases():
            p.set_HAP_refinements(hap_ref)
    gpx.data['Controls']['data']['max cyc'] = cycles
    gpx.do_refinements([{}])
    print('### %-28s Rwp = %.3f' % (label, h.get_wR()), flush=True)


step('bkg+scale')
step('+ sample displacement', hist_ref={'Sample Parameters': ['Shift']})
step('+ cell', phase_ref={'Cell': True})
step('+ W,X,Y profile', hist_ref={'Instrument Parameters': ['W', 'X', 'Y']})
step('+ U,V', hist_ref={'Instrument Parameters': ['U', 'V']})
step('+ HAP size/strain', hap_ref={'Size': {'refine': True}, 'Mustrain': {'refine': True}})
step('+ atoms(xu)', phase_ref={'Atoms': {'all': 'XU'}}, cycles=8)

gpx.save()
print('weights:')
for p in gpx.phases():
    print(' ', p.name, p.data['Histograms'][h.name]['Scale'])
print('Rwp', h.get_wR(), 'GOF', gpx.data['Covariance']['data']['Rvals'])
