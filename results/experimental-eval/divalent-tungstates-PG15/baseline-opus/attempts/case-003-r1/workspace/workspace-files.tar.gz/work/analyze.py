"""Dump fit profile, residual peaks and per-phase reflection coverage from a .gpx."""
import os, sys, numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc
from scipy.signal import find_peaks

gpx = G2sc.G2Project(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'gpx', sys.argv[1]))
h = gpx.histograms()[0]
x = np.array(h.data['data'][1][0]); yo = np.array(h.data['data'][1][1])
yc = np.array(h.data['data'][1][3]); bkg = np.array(h.data['data'][1][4])
d = yo - yc
np.savetxt('fitdump.csv', np.c_[x, yo, yc, bkg, d], delimiter=',',
           header='2theta,yobs,ycalc,bkg,diff', comments='')
print('Rwp %.3f' % h.get_wR())
for p in gpx.phases():
    print(p.name, 'cell', ['%.5f' % v for v in p.data['General']['Cell'][1:8]],
          'scale', p.data['Histograms'][h.name]['Scale'][0])
print('wtFrac:', {p.name: round(float(p.data['Histograms'][h.name].get('WgtFrac', np.nan)), 4) for p in gpx.phases()})

# residual peaks
sig = np.sqrt(np.maximum(yo, 1))
pk, pr = find_peaks(d / sig, prominence=3, distance=8)
print('\nresidual peaks (diff/sigma > 3):')
for i, j in enumerate(pk):
    print('  %7.3f  diff=%8.1f  d/sig=%5.1f  yo=%8.1f' % (x[j], d[j], (d/sig)[j], yo[j]))

refl = h.data['Reflection Lists']
print('\nstrongest reflections per phase:')
for name, rd in refl.items():
    r = np.array(rd['RefList'])
    # cols: h k l mul d-sp 2theta sig gam FoSq FcSq phase Icorr Prfo Trans ExtP
    inten = r[:, 8] * r[:, 11]
    order = np.argsort(-inten)[:15]
    print(' ', name, [(int(r[i, 0]), int(r[i, 1]), int(r[i, 2]), round(r[i, 5], 3)) for i in order])
