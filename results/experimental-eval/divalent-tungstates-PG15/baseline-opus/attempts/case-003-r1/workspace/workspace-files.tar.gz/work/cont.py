"""Continue a refinement from an existing project: peak-shape mixing, texture, etc.

usage: cont.py SRC.gpx NEWTAG [steps...]
"""
import sys
from g2lib import *

src, tag = sys.argv[1], sys.argv[2]
steps = sys.argv[3:] or ['lgmix', 'po', 'uniax', 'final']
dst = os.path.join(GPX, '%s.gpx' % tag)
shutil.copy(os.path.join(GPX, src), dst)
gpx = G2sc.G2Project(dst)
h = gpx.histograms()[0]
R = Runner(gpx, h, tag)
R.best = h.get_wR()
print('start Rwp = %.3f' % R.best, flush=True)
R.save_ckpt()


def S(fn, label, cycles=8):
    global gpx, h
    fn(gpx, h)
    gpx, h, ok = R.step(label, cycles)
    return ok


def ph(g, name):
    return [p for p in g.phases() if p.name == name][0]


if 'lgmix' in steps:
    S(lambda g, x: [p.set_HAP_refinements(
        {'Mustrain': {'refine': True, 'LGmix': {'refine': True}}}) for p in g.phases()],
      '+mustrain LGmix')
    S(lambda g, x: [p.set_HAP_refinements(
        {'Size': {'refine': True, 'LGmix': {'refine': True}}}) for p in g.phases()],
      '+size+LGmix')
if 'po' in steps:
    for pn in ['CaCO3', 'WO3', 'CaWO4']:
        S(lambda g, x, pn=pn: ph(g, pn).set_HAP_refinements({'Pref.Ori.': True}), '+PO %s' % pn)
if 'uniax' in steps:
    for pn in ['CaWO4', 'WO3', 'CaCO3']:
        S(lambda g, x, pn=pn: ph(g, pn).set_HAP_refinements(
            {'Mustrain': {'type': 'uniaxial', 'refine': True}}), '+uniax mustrain %s' % pn, 10)
if 'gen' in steps:
    for pn in ['WO3', 'CaWO4', 'CaCO3']:
        S(lambda g, x, pn=pn: ph(g, pn).set_HAP_refinements(
            {'Mustrain': {'type': 'generalized', 'refine': True}}),
          '+generalized mustrain %s' % pn, 12)
if 'hstrain' in steps:
    S(lambda g, x: [p.set_HAP_refinements({'HStrain': True}) for p in g.phases()], '+HStrain', 10)
if 'final' in steps:
    S(lambda g, x: None, 'converge', 12)
summary(gpx, h)
gpx.save()
