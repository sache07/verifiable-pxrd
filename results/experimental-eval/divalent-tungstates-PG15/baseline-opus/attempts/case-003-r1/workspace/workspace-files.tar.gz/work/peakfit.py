"""Single-peak fits of reasonably isolated reflections to characterise the profile."""
from g2lib import *

POS = [18.89, 29.713, 31.723, 36.298, 39.721, 43.470, 50.207, 54.423, 56.205,
       61.932, 64.920, 72.201, 77.145, 86.577, 96.313]

gpx = G2sc.G2Project(newgpx=os.path.join(GPX, 'peaks.gpx'))
h = gpx.add_powder_histogram(DATA, IPRM, fmthint='Topas')
h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 10, 'refine': True}})
for p in POS:
    h.add_peak(1, ttheta=p)
h.set_peakFlags(area=True, pos=True)
h.refine_peaks()
h.set_peakFlags(area=True, pos=True, sig=True)
h.refine_peaks()
h.set_peakFlags(area=True, pos=True, sig=True, gam=True)
r = h.refine_peaks()
print('peak fit Rwp', r['Rvals'] if isinstance(r, dict) else r)
print(' pos      int        sig(cdeg^2)  gam(cdeg)   fwhm_est')
import math
for pk in h.data['Peak List']['peaks']:
    pos, _, intn, _, sig, _, gam, _ = pk[:8]
    fg = math.sqrt(max(sig, 0)) * 2.3548 / 100 * 0.6  # rough
    print('%8.3f %10.1f %10.2f %10.3f   G=%.4f L=%.4f' %
          (pos, intn, sig, gam, math.sqrt(max(sig, 0)) / 100, gam / 100))
gpx.save()
