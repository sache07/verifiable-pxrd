"""Add a constant zero-point correction on top of the displacement term."""
import sys
from g2lib import *
src, tag = sys.argv[1], sys.argv[2]
dst = os.path.join(GPX, '%s.gpx' % tag)
shutil.copy(os.path.join(GPX, src), dst)
gpx = G2sc.G2Project(dst); h = gpx.histograms()[0]
print('start Rwp %.3f' % h.get_wR())
ctrl = gpx.data['Controls']['data']
ctrl['parmMinDict'][':0:Zero'], ctrl['parmMaxDict'][':0:Zero'] = -0.3, 0.3
ctrl['parmFrozen'] = {'FrozenList': []}
h.set_refinements({'Instrument Parameters': ['Zero']})
R = Runner(gpx, h, tag); R.best = 1e9; R.save_ckpt()
for i in range(2):
    gpx, h, ok = R.step('zero %d' % i, 20)
    if not ok: break
summary(gpx, h)
gpx.save()
