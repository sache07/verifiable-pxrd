"""Final model: oxygen ADPs held at chemically sensible values, heavy-atom ADPs refined.

usage: final2.py SRC.gpx TAG
"""
import sys
from g2lib import *

src, tag = sys.argv[1], sys.argv[2]
dst = os.path.join(GPX, '%s.gpx' % tag)
shutil.copy(os.path.join(GPX, src), dst)
gpx = G2sc.G2Project(dst)
h = gpx.histograms()[0]
hn = h.name
print('start Rwp %.3f' % h.get_wR())

FIXED_O = {'CaWO4': 0.0200, 'WO3': 0.0100}
for p in gpx.phases():
    if p.name not in FIXED_O:
        continue
    cx, ct, cs, cia = p.data['General']['AtomPtrs']
    for a in p.data['Atoms']:
        if a[ct] == 'O':
            a[cia + 1] = FIXED_O[p.name]
    # refine coordinates of all atoms on general positions + ADPs of the cations only
    p.set_refinements({'Atoms': {a.label: ('XU' if a.element != 'O' else 'X')
                                 for a in p.atoms()}})
    if p.name == 'CaWO4':   # Ca and W are on special positions (no free coordinates)
        p.set_refinements({'Atoms': {a.label: ('U' if a.element != 'O' else 'X')
                                     for a in p.atoms()}})
gpx.data['Controls']['data']['parmFrozen'] = {'FrozenList': []}
R = Runner(gpx, h, tag)
R.best = 1e9
R.save_ckpt()
gpx, h, ok = R.step('fixed O ADPs, converge', 20)
gpx, h, ok = R.step('converge 2', 20)
summary(gpx, h)
for p in gpx.phases():
    print('  ', p.name, [(a.label, round(a.uiso, 4)) for a in p.atoms()
                         if p.data['General']['AtomPtrs'] and a.adp_flag == 'I'])
gpx.save()
