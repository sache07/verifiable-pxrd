"""Re-converge the final model with the Ka2 component removed."""
import sys
from g2lib import *
src, tag = sys.argv[1], sys.argv[2]
dst = os.path.join(GPX, '%s.gpx' % tag)
shutil.copy(os.path.join(GPX, src), dst)
gpx = G2sc.G2Project(dst); h = gpx.histograms()[0]
h.data['Instrument Parameters'][0]['I(L2)/I(L1)'][1] = float(sys.argv[3])
gpx.data['Controls']['data']['parmFrozen'] = {'FrozenList': []}
print('start Rwp %.3f  I2/I1=%s' % (h.get_wR(), sys.argv[3]))
R = Runner(gpx, h, tag); R.best = 1e9; R.save_ckpt()
for i in range(2):
    gpx, h, ok = R.step('converge %d' % i, 20)
    if not ok: break
summary(gpx, h)
gpx.save()
