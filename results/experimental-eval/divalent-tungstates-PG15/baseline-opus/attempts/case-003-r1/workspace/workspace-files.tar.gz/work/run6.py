"""Staged refinement with rollback; WO3 model selectable.

usage: run6.py TAG WO3CIF [pol=0.7]
"""
import sys
from g2lib import *

tag, wo3 = sys.argv[1], sys.argv[2]
opts = sys.argv[3:]
pol = [float(o.split('=')[1]) for o in opts if o.startswith('pol=')]
pol = pol[0] if pol else 0.7

CIFS = {'CaWO4': '7219229.cif', 'WO3': wo3, 'CaCO3': '1547347.cif'}
gpx, h = new_project('%s.gpx' % tag, CIFS, nback=12,
                     inst={'U': 2.0, 'V': -2.0, 'W': 50.0, 'X': 0.0, 'Y': 0.0,
                           'Polariz.': pol})
for p in gpx.phases():
    hd = p.data['Histograms'][h.name]
    hd['Size'][1][0] = 1.0
    hd['Mustrain'][1][0] = 1000.

R = Runner(gpx, h, tag)
R.save_ckpt()


def S(fn, label, cycles=8):
    global gpx, h
    fn(gpx, h)
    gpx, h, ok = R.step(label, cycles)
    return ok


def atoms_of(g, phase, elem, flag='X'):
    for p in g.phases():
        if p.name != phase:
            continue
        sel = {a.label: flag for a in p.atoms() if a.element == elem}
        p.set_refinements({'Atoms': sel})


S(lambda g, x: None, 'bkg+scale')
S(lambda g, x: x.set_refinements({'Sample Parameters': ['Shift']}), '+shift')
S(lambda g, x: [p.set_refinements({'Cell': True}) for p in g.phases()], '+cell')
S(lambda g, x: [p.set_HAP_refinements({'Mustrain': {'refine': True}}) for p in g.phases()],
  '+mustrain')
S(lambda g, x: x.set_refinements({'Instrument Parameters': ['W']}), '+W')
S(lambda g, x: [p.set_HAP_refinements({'Size': {'refine': True}}) for p in g.phases()], '+size')
S(lambda g, x: x.set_refinements({'Instrument Parameters': ['SH/L']}), '+SH/L')
S(lambda g, x: x.set_refinements({'Sample Parameters': ['SurfRoughA', 'SurfRoughB']}), '+rough')
S(lambda g, x: atoms_of(g, 'WO3', 'W'), '+WO3 W xyz', 12)
S(lambda g, x: atoms_of(g, 'WO3', 'O'), '+WO3 O xyz', 12)
S(lambda g, x: atoms_of(g, 'CaWO4', 'O'), '+CaWO4 O xyz', 12)
S(lambda g, x: [p.set_refinements({'Atoms': {'all': 'U'}}) for p in g.phases()], '+Uiso', 12)
S(lambda g, x: x.set_refinements({'Instrument Parameters': ['X', 'Y']}), '+X,Y', 12)
summary(gpx, h)
gpx.save()
