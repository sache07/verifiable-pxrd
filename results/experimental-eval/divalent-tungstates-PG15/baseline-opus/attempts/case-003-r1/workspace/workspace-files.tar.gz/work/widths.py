"""Fit isolated peaks with a Ka1+Ka2 pseudo-Voigt doublet to map FWHM vs 2theta."""
import numpy as np
from scipy.optimize import curve_fit

L1, L2, RAT = 1.540598, 1.544426, 0.5
d = np.loadtxt('../inputs/pattern.csv', delimiter=',', skiprows=1)
X, Y = d[:, 0], d[:, 1]


def pv(x, pos, fwhm, eta):
    g = np.exp(-4 * np.log(2) * ((x - pos) / fwhm) ** 2) * (2 / fwhm) * np.sqrt(np.log(2) / np.pi)
    l = (2 / (np.pi * fwhm)) / (1 + 4 * ((x - pos) / fwhm) ** 2)
    return eta * l + (1 - eta) * g


def model(x, pos, area, fwhm, eta, b0, b1):
    th = np.radians(pos / 2)
    pos2 = pos + np.degrees(2 * np.tan(th) * (L2 - L1) / L1)
    return area * (pv(x, pos, fwhm, eta) + RAT * pv(x, pos2, fwhm, eta)) / (1 + RAT) + b0 + b1 * (x - pos)


def fit(c, w):
    m = (X > c - w) & (X < c + w)
    x, y = X[m], Y[m]
    b = np.percentile(y, 10)
    p0 = [c, (y.max() - b) * 0.15, 0.12, 0.5, b, 0.0]
    try:
        p, cov = curve_fit(model, x, y, p0=p0, sigma=np.sqrt(np.maximum(y, 1)),
                           bounds=([c - .3, 0, .02, 0, 0, -1e4], [c + .3, 1e9, 1.0, 1, 1e5, 1e4]))
    except Exception as e:
        return None
    return p


print('  2th_obs   fwhm    eta    area')
res = []
for c, w in [(18.89, .35), (26.91, .3), (29.713, .3), (31.723, .3), (36.298, .3), (39.721, .35),
             (43.470, .3), (44.557, .3), (50.207, .3), (54.423, .35), (56.205, .4), (59.672, .3),
             (61.932, .3), (64.920, .35), (72.201, .4), (77.145, .5), (86.577, .6), (96.313, .7)]:
    p = fit(c, w)
    if p is None:
        print(c, 'fail'); continue
    print('%9.4f %7.4f %6.3f %9.1f' % (p[0], p[2], p[3], p[1]))
    res.append((p[0], p[2]))

res = np.array(res)
# fit fwhm^2 = U tan^2 + V tan + W  (degrees^2)
t = np.tan(np.radians(res[:, 0] / 2))
A = np.c_[t ** 2, t, np.ones_like(t)]
sol, *_ = np.linalg.lstsq(A, res[:, 1] ** 2, rcond=None)
print('Caglioti U,V,W (deg^2):', sol, ' -> centideg^2:', sol * 1e4)
