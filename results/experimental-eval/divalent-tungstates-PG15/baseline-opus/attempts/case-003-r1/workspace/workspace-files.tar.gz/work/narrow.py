"""Test a sharp-core profile model: impose measured peak widths, refit background+scales."""
import sys
from g2lib import *

src, tag = sys.argv[1], sys.argv[2]
dst = os.path.join(GPX, '%s.gpx' % tag)
shutil.copy(os.path.join(GPX, src), dst)
gpx = G2sc.G2Project(dst)
h = gpx.histograms()[0]
hn = h.name
print('start Rwp %.3f' % h.get_wR())

TARGET = {'CaWO4': (0.05, 50.), 'WO3': (0.18, 1500.), 'CaCO3': (2.0, 1200.)}
for p in gpx.phases():
    hd = p.data['Histograms'][hn]
    s, m = TARGET[p.name]
    hd['Size'][1][0] = s
    hd['Mustrain'][1][0] = m
    hd['Size'][2] = [False, False, False]
    hd['Mustrain'][2] = [False, False, False]
gpx.data['Controls']['data']['parmFrozen'] = {'FrozenList': []}
R = Runner(gpx, h, tag)
R.best = 1e9
R.save_ckpt()
gpx, h, ok = R.step('fixed widths: bkg+scales', 12)
# now let widths free again, starting from the sharp values
for p in gpx.phases():
    p.set_HAP_refinements({'Size': {'refine': True}, 'Mustrain': {'refine': True}})
gpx, h, ok = R.step('+widths free', 15)
summary(gpx, h)
for name, rd in h.data['Reflection Lists'].items():
    r = np.array(rd['RefList'])
    inten = r[:, 8] * r[:, 11]
    i = np.argmax(inten)
    fg = np.sqrt(max(r[i, 6], 0)) * 2.3548 / 100
    fl = 2 * r[i, 7] / 100
    print('   %-6s strongest 2th=%.3f FWHM_G=%.3f FWHM_L=%.3f' % (name, r[i, 5], fg, fl))
gpx.save()
