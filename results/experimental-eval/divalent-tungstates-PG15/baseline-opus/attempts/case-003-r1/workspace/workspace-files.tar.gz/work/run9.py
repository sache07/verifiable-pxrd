"""Final staged refinement: 3 phases, bounded microstructure/ADPs, texture.

usage: run9.py TAG [wo3cif] [opts]
"""
import sys
from g2lib import *

tag = sys.argv[1]
wo3 = sys.argv[2] if len(sys.argv) > 2 else '2311041.cif'
opts = sys.argv[3:]

CIFS = {'CaWO4': '7219229.cif', 'WO3': wo3, 'CaCO3': '1547347.cif'}
gpx, h = new_project('%s.gpx' % tag, CIFS, nback=12,
                     inst={'U': 2.0, 'V': -2.0, 'W': 50.0, 'X': 0.0, 'Y': 0.0,
                           'Polariz.': 0.5})
hn = h.name
for p in gpx.phases():
    hd = p.data['Histograms'][hn]
    hd['Size'][1][0] = 1.0
    hd['Mustrain'][1][0] = 2000.

# parameter bounds keep the microstructure / ADPs physical
mins, maxs = {}, {}
for pid in range(3):
    mins['%d:0:Size;i' % pid], maxs['%d:0:Size;i' % pid] = 0.02, 10.0
    mins['%d:0:Mustrain;i' % pid], maxs['%d:0:Mustrain;i' % pid] = 50., 25000.
    mins['%d:0:Size;mx' % pid], maxs['%d:0:Size;mx' % pid] = 0.0, 1.0
    mins['%d:0:Mustrain;mx' % pid], maxs['%d:0:Mustrain;mx' % pid] = 0.0, 1.0
    mins['%d:0:MD' % pid], maxs['%d:0:MD' % pid] = 0.5, 2.0
    for i in range(20):
        mins['%d::AUiso:%d' % (pid, i)], maxs['%d::AUiso:%d' % (pid, i)] = 0.0025, 0.06
for v, lo, hi in [(':0:X', 0., 25.), (':0:Y', 0., 25.), (':0:W', 1., 400.),
                  (':0:SH/L', 0.0005, 0.08), (':0:SurfRoughA', -1., 1.),
                  (':0:SurfRoughB', -1., 1.)]:
    mins[v], maxs[v] = lo, hi
gpx.data['Controls']['data']['parmMinDict'] = mins
gpx.data['Controls']['data']['parmMaxDict'] = maxs

R = Runner(gpx, h, tag)
R.save_ckpt()


def S(fn, label, cycles=8):
    global gpx, h
    fn(gpx, h)
    gpx, h, ok = R.step(label, cycles)
    return ok


def ph(g, name):
    return [p for p in g.phases() if p.name == name][0]


def atoms_of(g, phase, elem, flag='X'):
    p = ph(g, phase)
    p.set_refinements({'Atoms': {a.label: flag for a in p.atoms() if a.element == elem}})


S(lambda g, x: None, 'bkg+scale')
S(lambda g, x: x.set_refinements({'Sample Parameters': ['Shift']}), '+shift')
S(lambda g, x: [p.set_refinements({'Cell': True}) for p in g.phases()], '+cell')
S(lambda g, x: [p.set_HAP_refinements({'Mustrain': {'refine': True}}) for p in g.phases()],
  '+mustrain')
S(lambda g, x: x.set_refinements({'Instrument Parameters': ['W']}), '+W')
S(lambda g, x: x.set_refinements({'Sample Parameters': ['SurfRoughA', 'SurfRoughB']}), '+rough')
S(lambda g, x: x.set_refinements({'Instrument Parameters': ['SH/L']}), '+SH/L')
S(lambda g, x: [p.set_HAP_refinements({'Size': {'refine': True}}) for p in g.phases()], '+size')
S(lambda g, x: [p.set_HAP_refinements({'Mustrain': {'refine': True,
                                                    'LGmix': {'refine': True}}})
                for p in g.phases()], '+mustrain LGmix')
S(lambda g, x: ph(g, 'CaCO3').set_HAP_refinements({'Pref.Ori.': True}), '+PO CaCO3')
S(lambda g, x: ph(g, 'WO3').set_HAP_refinements({'Pref.Ori.': True}), '+PO WO3')
S(lambda g, x: atoms_of(g, 'WO3', 'W'), '+WO3 W xyz', 12)
S(lambda g, x: atoms_of(g, 'WO3', 'O'), '+WO3 O xyz', 12)
S(lambda g, x: atoms_of(g, 'CaWO4', 'O'), '+CaWO4 O xyz', 12)
S(lambda g, x: [ph(g, n).set_refinements({'Atoms': {'all': 'U'}}) for n in ['WO3', 'CaWO4']],
  '+Uiso(WO3,CaWO4)', 12)
S(lambda g, x: x.set_refinements({'Instrument Parameters': ['X', 'Y']}), '+X,Y', 12)
S(lambda g, x: None, 'converge', 15)
summary(gpx, h)
gpx.save()
