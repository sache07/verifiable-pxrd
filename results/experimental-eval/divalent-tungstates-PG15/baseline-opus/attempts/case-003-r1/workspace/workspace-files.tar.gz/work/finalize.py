"""Final convergence + export of CIFs, fit profile, result.json.

usage: finalize.py SRC.gpx OUTDIR
"""
import sys, json, datetime
from g2lib import *
from GSASII import GSASIIstrMath as G2stMth

src, outdir = sys.argv[1], os.path.abspath(sys.argv[2])
final = os.path.join(outdir, 'final.gpx')
shutil.copy(os.path.join(GPX, src), final)
gpx = G2sc.G2Project(final)
h = gpx.histograms()[0]
hn = h.name
print('start Rwp %.3f' % h.get_wR())

# calcite shows no measurable size broadening: hold it, refine its microstrain only
for p in gpx.phases():
    if p.name == 'CaCO3':
        hd = p.data['Histograms'][hn]
        hd['Size'][1][0] = 10.0
        hd['Size'][1][2] = 1.0
        hd['Size'][2] = [False, False, False]
gpx.data['Controls']['data']['parmFrozen'] = {'FrozenList': []}
R = Runner(gpx, h, 'final')
R.best = 1e9
R.save_ckpt()
gpx, h, ok = R.step('final convergence', 20)
gpx, h, ok = R.step('final convergence 2', 20)
wf = summary(gpx, h)

# --- mass fractions with esds from the covariance matrix
cov = gpx.data['Covariance']['data']
Phases = {k: v for k, v in gpx.data['Phases'].items() if k != 'data'}
try:
    valD, sigD = G2stMth.calcMassFracs(cov['varyList'], cov['covMatrix'], Phases, hn, 0)
except Exception as e:
    print('calcMassFracs failed:', e)
    valD, sigD = {}, {}
print('mass fracs', valD, sigD)

# --- export CIFs
cifs = {}
for p in gpx.phases():
    fn = os.path.join(outdir, '%s.cif' % p.name)
    p.export_CIF(fn)
    cifs[p.name] = os.path.basename(fn)
    print('wrote', fn)

# --- fit profile
d = h.data['data'][1]
x, yo, w, yc, bk = [np.array(v) for v in (d[0], d[1], d[2], d[3], d[4])]
np.savetxt(os.path.join(outdir, 'fit.csv'),
           np.c_[x, yo, yc, yo - yc, bk],
           delimiter=',', fmt='%.6f',
           header='two_theta_deg,y_obs,y_calc,y_obs_minus_calc,background', comments='')

# --- statistics
Rvals = cov['Rvals']
nobs = len(x)
res = {
    'analysis': 'Rietveld refinement (GSAS-II) of Cu K-alpha1,2 laboratory PXRD data',
    'phases': [],
    'fit_statistics': {
        'Rwp_percent': round(float(Rvals['Rwp']), 4),
        'Rp_percent': round(float(Rvals.get('Rp', float('nan'))), 4),
        'GOF': round(float(Rvals['GOF']), 4),
        'chi_squared_reduced': round(float(Rvals['GOF']) ** 2, 4),
        'n_observations': nobs,
        'n_variables': int(Rvals['Nvars']),
        'two_theta_range_deg': [round(float(x.min()), 4), round(float(x.max()), 4)],
    },
    'generated': datetime.datetime.now().isoformat(timespec='seconds'),
}
for p in gpx.phases():
    hd = p.data['Histograms'][hn]
    c = p.data['General']['Cell']
    sig = sigD.get('%d:0:WgtFrac' % p.id)
    res['phases'].append({
        'name': p.name,
        'formula': p.data['General']['Formula'] if 'Formula' in p.data['General'] else None,
        'space_group': p.data['General']['SGData']['SpGrp'],
        'cif': cifs[p.name],
        'weight_fraction': round(float(wf[p.name]), 4),
        'weight_fraction_esd': (round(float(sig), 4) if sig else None),
        'lattice_parameters': {'a': round(c[1], 5), 'b': round(c[2], 5), 'c': round(c[3], 5),
                               'alpha': round(c[4], 4), 'beta': round(c[5], 4),
                               'gamma': round(c[6], 4), 'volume_A3': round(c[7], 3)},
        'phase_scale': float(hd['Scale'][0]),
        'apparent_size_um': float(hd['Size'][1][0]),
        'microstrain_1e6': float(hd['Mustrain'][1][0]),
        'march_dollase_001': float(hd['Pref.Ori.'][1]),
    })
with open(os.path.join(outdir, 'result.json'), 'w') as f:
    json.dump(res, f, indent=2)
print(json.dumps(res, indent=2))
gpx.save()
