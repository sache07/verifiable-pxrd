"""Export the final project: CIFs, fit.csv, result.json (no further refinement).

usage: export.py SRC.gpx OUTDIR
"""
import sys, json, datetime
from g2lib import *
from GSASII import GSASIIstrMath as G2stMth

src, outdir = sys.argv[1], os.path.abspath(sys.argv[2])
final = os.path.join(outdir, 'final.gpx')
shutil.copy(os.path.join(GPX, src), final)
gpx = G2sc.G2Project(final)
h = gpx.histograms()[0]
hn = h.name
print('Rwp %.4f' % h.get_wR())
wf = mass_fractions(gpx, h)

cov = gpx.data['Covariance']['data']
Phases = {k: v for k, v in gpx.data['Phases'].items() if k != 'data'}
valD, sigD = G2stMth.calcMassFracs(cov['varyList'], cov['covMatrix'], Phases, hn, 0)
print('mass fracs', valD, sigD)

cifs = {}
for p in gpx.phases():
    fn = os.path.join(outdir, '%s.cif' % p.name)
    p.export_CIF(fn)
    cifs[p.name] = os.path.basename(fn)
    print('wrote', fn)

d = h.data['data'][1]
x, yo, wt, yc, bk = [np.array(v) for v in (d[0], d[1], d[2], d[3], d[4])]
np.savetxt(os.path.join(outdir, 'fit.csv'), np.c_[x, yo, yc, yo - yc, bk],
           delimiter=',', fmt='%.6f',
           header='two_theta_deg,y_obs,y_calc,y_obs_minus_calc,background', comments='')

Rvals = cov['Rvals']
FORMULA = {'CaWO4': 'CaWO4', 'WO3': 'WO3', 'CaCO3': 'CaCO3'}
MINERAL = {'CaWO4': 'scheelite', 'WO3': 'gamma-WO3 (monoclinic tungsten trioxide)',
           'CaCO3': 'calcite'}
res = {
    'method': 'Rietveld refinement with GSAS-II (scriptable API), Cu K-alpha1+alpha2 '
              'laboratory data, Bragg-Brentano reflection geometry',
    'data_file': 'inputs/pattern.csv',
    'project_file': 'final.gpx',
    'profile_file': 'fit.csv',
    'n_phases': len(cifs),
    'phases': [],
    'fit_statistics': {
        'Rwp_percent': round(float(Rvals['Rwp']) , 3),
        'Rp_percent': round(float(Rvals['Rp']), 3) if 'Rp' in Rvals else None,
        'GOF_chi': round(float(Rvals['GOF']), 3),
        'reduced_chi_squared': round(float(Rvals['GOF']) ** 2, 3),
        'n_points': int(len(x)),
        'n_refined_variables': int(Rvals['Nvars']),
        'two_theta_range_deg': [round(float(x.min()), 3), round(float(x.max()), 3)],
    },
    'generated_utc': datetime.datetime.utcnow().isoformat(timespec='seconds'),
}
for p in gpx.phases():
    hd = p.data['Histograms'][hn]
    c = p.data['General']['Cell']
    sig = sigD.get('%d:0:WgtFrac' % p.id)
    entry = {
        'name': MINERAL[p.name],
        'formula': FORMULA[p.name],
        'space_group': p.data['General']['SGData']['SpGrp'],
        'cif_path': cifs[p.name],
        'weight_fraction': round(float(wf[p.name]), 4),
        'weight_fraction_esd_statistical': round(float(sig), 4) if sig else None,
        'weight_fraction_uncertainty_estimated': 0.01,
        'weight_percent': round(100 * float(wf[p.name]), 2),
        'lattice_parameters_A_deg': {'a': round(c[1], 5), 'b': round(c[2], 5),
                                     'c': round(c[3], 5), 'alpha': round(c[4], 3),
                                     'beta': round(c[5], 4), 'gamma': round(c[6], 3),
                                     'volume_A3': round(c[7], 3)},
        'rietveld_phase_scale': float(hd['Scale'][0]),
        'apparent_crystallite_size_nm': round(1000 * float(hd['Size'][1][0]), 1),
        'microstrain_x1e6': round(float(hd['Mustrain'][1][0]), 0),
        'march_dollase_preferred_orientation_001': round(float(hd['Pref.Ori.'][1]), 4),
    }
    res['phases'].append(entry)
res['phases'].sort(key=lambda e: -e['weight_fraction'])
with open(os.path.join(outdir, 'result.json'), 'w') as f:
    json.dump(res, f, indent=2)
print(json.dumps(res, indent=2))
