"""Final model: ADPs fixed at reference values, pure-Lorentzian microstructure, clean flags.

usage: final3.py SRC.gpx TAG
"""
import sys
from g2lib import *

src, tag = sys.argv[1], sys.argv[2]
dst = os.path.join(GPX, '%s.gpx' % tag)
shutil.copy(os.path.join(GPX, src), dst)
gpx = G2sc.G2Project(dst)
h = gpx.histograms()[0]
hn = h.name
print('start Rwp %.3f' % h.get_wR())

UISO = {'CaWO4': {'Ca': 0.0123, 'W': 0.0110, 'O': 0.0257},
        'WO3': {'W': 0.0050, 'O': 0.0100}}
for p in gpx.phases():
    cx, ct, cs, cia = p.data['General']['AtomPtrs']
    if p.name in UISO:
        for a in p.data['Atoms']:
            a[cia + 1] = UISO[p.name][a[ct]]
    # coordinates: refine those not fixed by symmetry; no ADP refinement
    if p.name == 'WO3':
        p.set_refinements({'Atoms': {a.label: 'X' for a in p.atoms()}})
    elif p.name == 'CaWO4':
        p.set_refinements({'Atoms': {a.label: ('X' if a.element == 'O' else '')
                                    for a in p.atoms()}})
    else:
        p.set_refinements({'Atoms': {a.label: '' for a in p.atoms()}})
    hd = p.data['Histograms'][hn]
    hd['Size'][1][2] = 1.0          # pure Lorentzian size broadening
    hd['Mustrain'][1][2] = 1.0      # pure Lorentzian strain broadening
    hd['Size'][2] = [True, False, False]
    hd['Mustrain'][2] = [True, False, False]
    if p.name == 'CaCO3':           # no measurable size broadening for calcite
        hd['Size'][1][0] = 10.0
        hd['Size'][2] = [False, False, False]
gpx.data['Controls']['data']['parmFrozen'] = {'FrozenList': []}
R = Runner(gpx, h, tag)
R.best = 1e9
R.save_ckpt()
for i in range(3):
    gpx, h, ok = R.step('converge %d' % (i + 1), 20)
    if not ok:
        break
summary(gpx, h)
print('frozen:', len(gpx.data['Controls']['data'].get('parmFrozen', {}).get('FrozenList', [])))
gpx.save()
