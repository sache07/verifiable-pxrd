"""Look for unmodelled peaks in the difference curve of a finished fit."""
import sys
from g2lib import *
from scipy.signal import find_peaks
from scipy.ndimage import uniform_filter1d

gpx = G2sc.G2Project(os.path.join(GPX, sys.argv[1]))
h = gpx.histograms()[0]
d = h.data['data'][1]
x, yo, yc = np.array(d[0]), np.array(d[1]), np.array(d[3])
diff = uniform_filter1d(yo - yc, 9)
sig = np.sqrt(np.maximum(yo, 1)) / 3.0      # smoothing by 9 reduces noise ~3x
pk, pr = find_peaks(diff / sig, prominence=5, distance=10, height=4)
print('Rwp %.3f ; candidate unmodelled peaks (smoothed diff, >4 sigma):' % h.get_wR())
# positions of all modelled reflections
refl = []
for name, rd in h.data['Reflection Lists'].items():
    r = np.array(rd['RefList'])
    inten = r[:, 8] * r[:, 11]
    for i in range(len(r)):
        refl.append((r[i, 5], name, inten[i] / max(inten.max(), 1e-9)))
refl.sort()
for j in pk:
    near = [(abs(p - x[j]), n, round(w, 3)) for p, n, w in refl if abs(p - x[j]) < 0.25]
    near.sort()
    tag = ','.join('%s(%.2f,%+0.2f)' % (n, w, -dd) for dd, n, w in near[:3]) or 'NONE NEARBY'
    print('  %7.3f  diff=%8.1f (%.1f sig)  yo=%8.0f  | %s' %
          (x[j], (yo - yc)[j], (diff / sig)[j], yo[j], tag))
