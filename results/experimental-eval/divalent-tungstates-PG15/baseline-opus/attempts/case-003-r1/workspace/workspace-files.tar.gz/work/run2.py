"""Test displacement vs zero-offset models for the 3-phase mixture."""
import sys
from g2lib import *

CIFS = {'CaWO4': '7219229.cif', 'WO3': '1528915.cif', 'CaCO3': '1547347.cif'}
mode = sys.argv[1]      # shift | zero | both

gpx, h = new_project('t_%s.gpx' % mode, CIFS)
run(gpx, h, 'bkg+scale')
h.set_refinements({'Instrument Parameters': ['W', 'X', 'Y']})
run(gpx, h, '+WXY')
if mode in ('shift', 'both'):
    h.set_refinements({'Sample Parameters': ['Shift']})
if mode in ('zero', 'both'):
    h.set_refinements({'Instrument Parameters': ['Zero']})
run(gpx, h, '+offset(%s)' % mode)
for p in gpx.phases():
    p.set_refinements({'Cell': True})
run(gpx, h, '+cell')
for p in gpx.phases():
    p.set_HAP_refinements({'Size': {'refine': True}, 'Mustrain': {'refine': True}})
run(gpx, h, '+size/strain')
run(gpx, h, 'again')
summary(gpx, h)
gpx.save()
