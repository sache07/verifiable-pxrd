"""Test whether an extra phase is needed: add to a converged fit and refine.

usage: addphase.py SRC.gpx NAME CIF
"""
import sys
from g2lib import *

src, name, cif = sys.argv[1], sys.argv[2], sys.argv[3]
dst = os.path.join(GPX, 'add_%s.gpx' % name)
shutil.copy(os.path.join(GPX, src), dst)
gpx = G2sc.G2Project(dst)
h = gpx.histograms()[0]
start = h.get_wR()
newp = gpx.add_phase(os.path.join(REFS, cif), phasename=name, histograms=[h])
hd = newp.data['Histograms'][h.name]
hd['Scale'][0] = 0.1
hd['Size'][1][0] = 1.0
hd['Mustrain'][1][0] = 2000.
newp.set_HAP_refinements({'Scale': True, 'Mustrain': {'refine': True}})
R = Runner(gpx, h, 'add_%s' % name)
R.best = start
R.save_ckpt()
gpx, h, ok = R.step('+%s scale/strain' % name, 10, keep_if_worse=True)
newp = [p for p in gpx.phases() if p.name == name][0]
newp.set_refinements({'Cell': True})
gpx, h, ok = R.step('+%s cell' % name, 10, keep_if_worse=True)
print('start Rwp %.3f -> %.3f' % (start, h.get_wR()))
summary(gpx, h)
gpx.save()
