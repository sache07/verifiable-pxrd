"""3-phase refinement with per-phase microstructural broadening; offset-model test."""
import sys
from g2lib import *

CIFS = {'CaWO4': '7219229.cif', 'WO3': '1528915.cif', 'CaCO3': '1547347.cif'}
mode = sys.argv[1]      # shift | zero | both

gpx, h = new_project('u_%s.gpx' % mode, CIFS, nback=12)
ip = h.data['Instrument Parameters'][0]
ip['U'][1], ip['V'][1], ip['W'][1] = 2.0, -2.0, 50.0
for p in gpx.phases():
    p.data['Histograms'][h.name]['Size'][1][0] = 1.0      # um
    p.data['Histograms'][h.name]['Mustrain'][1][0] = 1000.

run(gpx, h, 'bkg+scale')
if mode in ('shift', 'both'):
    h.set_refinements({'Sample Parameters': ['Shift']})
if mode in ('zero', 'both'):
    h.set_refinements({'Instrument Parameters': ['Zero']})
run(gpx, h, '+offset(%s)' % mode)
for p in gpx.phases():
    p.set_refinements({'Cell': True})
run(gpx, h, '+cell')
for p in gpx.phases():
    p.set_HAP_refinements({'Size': {'refine': True}, 'Mustrain': {'refine': True}})
run(gpx, h, '+size/strain')
h.set_refinements({'Instrument Parameters': ['W', 'SH/L']})
run(gpx, h, '+W,SH/L')
run(gpx, h, 'again')
summary(gpx, h)
for p in gpx.phases():
    hd = p.data['Histograms'][h.name]
    print('  %-8s size=%.4f um  mustrain=%.0f' % (p.name, hd['Size'][1][0], hd['Mustrain'][1][0]))
gpx.save()
