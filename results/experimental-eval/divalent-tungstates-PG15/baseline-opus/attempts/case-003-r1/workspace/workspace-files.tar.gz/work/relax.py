"""Relax the artificial microstructure bounds and re-converge; optional extra tweaks."""
import sys
from g2lib import *

src, tag = sys.argv[1], sys.argv[2]
opts = sys.argv[3:]
dst = os.path.join(GPX, '%s.gpx' % tag)
shutil.copy(os.path.join(GPX, src), dst)
gpx = G2sc.G2Project(dst)
h = gpx.histograms()[0]
hn = h.name
print('start Rwp %.3f' % h.get_wR())
ctrl = gpx.data['Controls']['data']
mins, maxs = ctrl.get('parmMinDict', {}), ctrl.get('parmMaxDict', {})
for pid in range(3):
    mins['%d:0:Size;i' % pid], maxs['%d:0:Size;i' % pid] = 0.005, 50.0
    mins['%d:0:Mustrain;i' % pid], maxs['%d:0:Mustrain;i' % pid] = 10., 30000.
ctrl['parmMinDict'], ctrl['parmMaxDict'] = mins, maxs
ctrl['parmFrozen'] = {'FrozenList': []}
for p in gpx.phases():
    p.set_HAP_refinements({'Size': {'refine': True}, 'Mustrain': {'refine': True}})

R = Runner(gpx, h, tag)
R.best = 1e9
R.save_ckpt()


def S(fn, label, cycles=12):
    global gpx, h
    fn(gpx, h)
    gpx, h, ok = R.step(label, cycles)
    return ok


def ph(g, name):
    return [p for p in g.phases() if p.name == name][0]


S(lambda g, x: None, 'relaxed widths')
if 'pocawo4' in opts:
    S(lambda g, x: ph(g, 'CaWO4').set_HAP_refinements({'Pref.Ori.': True}), '+PO CaWO4')
if 'powo3' in opts:
    S(lambda g, x: ph(g, 'WO3').set_HAP_refinements({'Pref.Ori.': True}), '+PO WO3')
if 'lgmix' in opts:
    S(lambda g, x: [p.set_HAP_refinements({'Size': {'refine': True,
                                                    'LGmix': {'refine': True}}})
                    for p in g.phases()], '+size LGmix')
if 'uvw' in opts:
    S(lambda g, x: x.set_refinements({'Instrument Parameters': ['U', 'V']}), '+U,V')
if 'zero' in opts:
    S(lambda g, x: x.set_refinements({'Instrument Parameters': ['Zero']}), '+Zero')
if 'hstrain' in opts:
    S(lambda g, x: [p.set_HAP_refinements({'HStrain': True}) for p in g.phases()], '+HStrain')
S(lambda g, x: None, 'converge', 20)
summary(gpx, h)
gpx.save()
