"""Sensitivity test: hold ADPs at literature-like values and re-converge."""
import sys
from g2lib import *

src, tag = sys.argv[1], sys.argv[2]
dst = os.path.join(GPX, '%s.gpx' % tag)
shutil.copy(os.path.join(GPX, src), dst)
gpx = G2sc.G2Project(dst)
h = gpx.histograms()[0]
print('start Rwp %.3f' % h.get_wR())

UISO = {'CaWO4': {'Ca': 0.0123, 'W': 0.0110, 'O': 0.0257},
        'WO3': {'W': 0.005, 'O': 0.010}}
for p in gpx.phases():
    if p.name not in UISO:
        continue
    cx, ct, cs, cia = p.data['General']['AtomPtrs']
    for a in p.data['Atoms']:
        a[cia + 1] = UISO[p.name][a[ct]]
    p.set_refinements({'Atoms': {a.label: '' for a in p.atoms()}})   # clear flags
gpx.data['Controls']['data']['parmFrozen'] = {'FrozenList': []}
R = Runner(gpx, h, tag)
R.best = 1e9
R.save_ckpt()
gpx, h, ok = R.step('fixed ADPs, converge', 20)
summary(gpx, h)
gpx.save()
