"""Shared helpers for the Rietveld runs."""
import os, sys, shutil, numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc

WORK = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(WORK, 'data', 'pattern.xy')
IPRM = os.path.join(WORK, 'data', 'lab_cuka.instprm')
REFS = os.path.join(WORK, 'refs')
GPX = os.path.join(WORK, 'gpx')


def new_project(name, cifs, nback=12, inst=None):
    """cifs: dict phasename -> cif file name"""
    gpx = G2sc.G2Project(newgpx=os.path.join(GPX, name))
    h = gpx.add_powder_histogram(DATA, IPRM, fmthint='Topas')
    for pn, cif in cifs.items():
        gpx.add_phase(os.path.join(REFS, cif), phasename=pn, histograms=[h])
    h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': nback, 'refine': True},
                       'Sample Parameters': ['Scale']})
    ip = h.data['Instrument Parameters'][0]
    for k, v in (inst or {}).items():
        ip[k][1] = v
    for p in gpx.phases():
        p.set_HAP_refinements({'Scale': True})
    gpx.data['Controls']['data']['max cyc'] = 8
    return gpx, h


class Runner:
    """Runs refinement steps with checkpoint/rollback."""

    def __init__(self, gpx, h, tag):
        self.gpx, self.h, self.tag = gpx, h, tag
        self.ckpt = os.path.join(GPX, 'ckpt_%s.gpx' % tag)
        self.best = 1e9

    def save_ckpt(self):
        self.gpx.save()
        shutil.copy(self.gpx.filename, self.ckpt)

    def rollback(self):
        shutil.copy(self.ckpt, self.gpx.filename)
        self.gpx = G2sc.G2Project(self.gpx.filename)
        self.h = self.gpx.histograms()[0]
        print('   (rolled back to checkpoint)', flush=True)
        return self.gpx, self.h

    def step(self, label, cycles=8, keep_if_worse=False, tol=0.01):
        self.gpx.data['Controls']['data']['max cyc'] = cycles
        try:
            self.gpx.do_refinements([{}])
            rwp = self.h.get_wR()
            bad = not np.isfinite(rwp)
        except Exception as e:
            print('!! step %s failed: %s' % (label, e), flush=True)
            bad = True
            rwp = float('nan')
        if bad or (not keep_if_worse and rwp > self.best + tol):
            print('### %-32s FAILED/worse (Rwp=%.3f)' % (label, rwp), flush=True)
            return self.rollback() + (False,)
        print('### %-32s Rwp = %.3f' % (label, rwp), flush=True)
        self.best = min(self.best, rwp)
        self.save_ckpt()
        return self.gpx, self.h, True


def mass_fractions(gpx, h):
    masses, scales = {}, {}
    for p in gpx.phases():
        masses[p.name] = p.data['General']['Mass']
        scales[p.name] = p.data['Histograms'][h.name]['Scale'][0]
    tot = sum(masses[k] * scales[k] for k in masses)
    return {k: masses[k] * scales[k] / tot for k in masses}


def summary(gpx, h):
    cov = gpx.data['Covariance']['data']
    print('Rwp = %.3f  GOF = %.3f  Rb(hist) = %s' % (h.get_wR(), cov['Rvals']['GOF'],
                                                     cov['Rvals'].get('Rwp')))
    wf = mass_fractions(gpx, h)
    sd = cov.get('sigDict', {})
    print('weight fractions:')
    for i, p in enumerate(gpx.phases()):
        sig = sd.get('%d:0:WgtFrac' % p.id, None)
        print('   %-8s %.4f  +/- %s' % (p.name, wf[p.name], ('%.4f' % sig) if sig else '?'))
    for p in gpx.phases():
        c = p.data['General']['Cell']
        hd = p.data['Histograms'][h.name]
        print('  %-8s a=%.5f b=%.5f c=%.5f beta=%.4f V=%.3f scale=%.5g size=%.4f mustrain=%.0f' %
              (p.name, c[1], c[2], c[3], c[5], c[7], hd['Scale'][0],
               hd['Size'][1][0], hd['Mustrain'][1][0]))
    sp = h.data['Sample Parameters']
    ip = h.data['Instrument Parameters'][0]
    print('  Shift=%.1f um Zero=%.4f U=%.2f V=%.2f W=%.2f X=%.3f Y=%.3f SH/L=%.4f Polariz=%.3f' %
          (sp['Shift'][0], ip['Zero'][1], ip['U'][1], ip['V'][1], ip['W'][1],
           ip['X'][1], ip['Y'][1], ip['SH/L'][1], ip['Polariz.'][1]))
    return wf
