"""Continue refinement from an existing project: add Gaussian profile terms.
Usage: fit12.py in.gpx out_tag"""
import sys, os, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import GSASII.GSASIIscriptable as G2sc
from common import W, report, save_prof

src, tag = sys.argv[1], sys.argv[2]
dst = os.path.join(W, tag + '.gpx')
shutil.copy(src, dst)
p = G2sc.G2Project(dst)
h = p.histograms()[0]
ip = h.data['Instrument Parameters'][0]
sp = h.data['Sample Parameters']
ip['SH/L'][1] = 0.002
h.set_refinements({'Instrument Parameters': []})
C = p.data['Controls']['data']
C['parmMaxDict'] = {'*:*:Mustrain;i': 30000., '*::AUiso:*': 0.05, '*:*:Size;i': 10.,
                    ':*:SurfRoughA': 1.5, ':*:SurfRoughB': 2.0, ':*:SH/L': 0.05,
                    ':*:U': 600., ':*:W': 300., ':*:X': 20., ':*:V': 50.}
C['parmMinDict'] = {'*:*:Mustrain;i': 200., '*::AUiso:*': 0.001, '*:*:Size;i': 0.004,
                    ':*:SurfRoughA': 0.0, ':*:SurfRoughB': 0.0, ':*:SH/L': 0.0,
                    ':*:U': 0., ':*:W': 0., ':*:X': 0., ':*:V': -600.}

def refine(msg):
    C['parmFrozen'] = {}
    p.refine()
    report(p, h, msg)
    print('   rough', [round(sp[k][0], 4) for k in ('SurfRoughA', 'SurfRoughB')])

report(p, h, 'start')
h.set_refinements({'Instrument Parameters': ['U', 'W']})
refine('+U,W')
h.set_refinements({'Instrument Parameters': ['V']})
refine('+V')
h.set_refinements({'Instrument Parameters': ['SH/L']})
refine('+SH/L')
p.phase('Pb2WO5').set_refinements({'Atoms': {'Pb1': 'X', 'Pb2': 'X', 'W1': 'X'}})
p.phase('stolzite').set_refinements({'Atoms': {'O': 'X'}})
refine('+coords')
for ph in p.phases():
    print(' ', ph.name, [(a.label, [round(v, 5) for v in a.coordinates], round(a.ADP, 4))
                         for a in ph.atoms()])
try:
    print('mass fracs:', h.ComputeMassFracs())
except Exception as e:
    print('massfrac err', e)
save_prof(h, tag + '_prof.csv')
p.save()
