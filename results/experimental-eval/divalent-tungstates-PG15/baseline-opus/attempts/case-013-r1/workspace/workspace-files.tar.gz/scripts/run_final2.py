"""Produce the submitted model: reset all atomic coordinates to the reference-structure values,
disable coordinate refinement (X-ray data cannot locate O reliably), re-converge everything else.
Usage: run_final2.py in.gpx tag"""
import sys, os, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import GSASII.GSASIIscriptable as G2sc
from common import W, report, save_prof

src, tag = sys.argv[1], sys.argv[2]
dst = os.path.join(W, tag + '.gpx')
shutil.copy(src, dst)
p = G2sc.G2Project(dst)
h = p.histograms()[0]
sp = h.data['Sample Parameters']
C = p.data['Controls']['data']

REF = {
    'stolzite': {'Pb': (0.0, 0.25, 0.625), 'W': (0.0, 0.25, 0.125),
                 'O': (0.2317, 0.1122, 0.0430)},
    'Pb2WO5': {'Pb1': (0.13713, 0.0, 0.11447), 'Pb2': (0.01350, 0.5, 0.25628),
               'W1': (0.33103, 0.5, 0.34061), 'O1': (0.0859, 0.0, 0.3999),
               'O2': (0.3528, 0.7425, 0.2182), 'O3': (0.2009, 0.5, 0.3069),
               'O4': (0.0, 0.2550, 0.0)},
}
for phn, coords in REF.items():
    ph = p.phase(phn)
    for at in ph.atoms():
        if at.label in coords:
            at.coordinates = coords[at.label]
    ph.clear_refinements({'Atoms': [a.label for a in ph.atoms()]})

C['parmMaxDict'] = {'*:*:Mustrain;i': 30000., '*::AUiso:*': 0.05, '*:*:Size;i': 10.,
                    ':*:SurfRoughA': 1.5, ':*:SurfRoughB': 2.0, ':*:SH/L': 0.05,
                    ':*:U': 600., ':*:W': 300., ':*:X': 20., ':*:V': 50.}
C['parmMinDict'] = {'*:*:Mustrain;i': 200., '*::AUiso:*': 0.001, '*:*:Size;i': 0.004,
                    ':*:SurfRoughA': 0.0, ':*:SurfRoughB': 0.0, ':*:SH/L': 0.0,
                    ':*:U': 0., ':*:W': 0., ':*:X': 0., ':*:V': -600.}
report(p, h, 'after coordinate reset')
for i in range(3):
    C['parmFrozen'] = {}
    p.refine()
    report(p, h, f'converge {i}')
    print('   rough', [round(sp[k][0], 4) for k in ('SurfRoughA', 'SurfRoughB')])
for ph in p.phases():
    print(' ', ph.name, [(a.label, [round(v, 5) for v in a.coordinates], round(a.ADP, 4))
                         for a in ph.atoms()])
print('mass fracs:', h.ComputeMassFracs())
save_prof(h, tag + '_prof.csv')
p.save()
