"""Least-squares monoclinic C-centred cell fit to a residual line list with iterative hkl
assignment. Usage: cellfit.py "2th1,2th2,..." shift a b c beta [--lattice C]"""
import sys, numpy as np
from scipy.optimize import least_squares

pos = np.array([float(v) for v in sys.argv[1].split(',')])
shift = float(sys.argv[2])
p0 = np.array([float(v) for v in sys.argv[3:7]])
latt = sys.argv[7] if len(sys.argv) > 7 else 'C'
lam = 1.540598
const = 9.e-2/(np.pi*200.0)
th = np.radians(pos/2)
pos_corr = pos + const*4*shift*np.cos(th)
dobs = lam/(2*np.sin(np.radians(pos_corr/2)))

hkls = []
for h in range(-14, 15):
    for k in range(0, 10):
        for l in range(-10, 11):
            if (h, k, l) == (0, 0, 0):
                continue
            if latt == 'C' and (h+k) % 2:
                continue
            if latt == 'I' and (h+k+l) % 2:
                continue
            if latt == 'P2c' and ((k == 0 and l % 2) or (h == 0 and k % 2)):
                pass
            # c-glide (h0l: l even) and 21 screw (0k0 k even) for C2/c
            if latt == 'Cc' and k == 0 and l % 2:
                continue
            if latt == 'Cc' and h == 0 and k % 2:
                continue
            hkls.append((h, k, l))
hkls = np.array(hkls)

def dcalc(p, hk):
    a, b, c, beta = p
    br = np.radians(beta); s2 = np.sin(br)**2
    h, k, l = hk[:, 0], hk[:, 1], hk[:, 2]
    q = h*h/(a*a*s2) + k*k/(b*b) + l*l/(c*c*s2) - 2*h*l*np.cos(br)/(a*c*s2)
    return 1/np.sqrt(np.maximum(q, 1e-12))

TOL = 0.006
def assign(p):
    dc = dcalc(p, hkls)
    out, used = [], []
    for dd in dobs:
        j = np.argmin(np.abs(dc/dd - 1))
        if abs(dc[j]/dd - 1) < TOL:
            out.append(hkls[j]); used.append(True)
        else:
            out.append([0, 0, 0]); used.append(False)
    return np.array(out), np.array(used)

def resid(p):
    hk, used = assign(p)
    if used.sum() == 0:
        return np.zeros(len(dobs))
    r = np.zeros(len(dobs))
    r[used] = (dcalc(p, hk[used])/dobs[used] - 1)*1000
    return r

p = p0.copy()
for it in range(20):
    r = least_squares(resid, p, diff_step=1e-4)
    p = r.x
hk, used = assign(p)
dc = np.zeros(len(dobs))
dc[used] = dcalc(p, hk[used])
print('cell a=%.4f b=%.4f c=%.4f beta=%.3f  V=%.2f' % (p[0], p[1], p[2], p[3],
      p[0]*p[1]*p[2]*np.sin(np.radians(p[3]))))
print('indexed %d/%d' % (used.sum(), len(dobs)))
for i in range(len(dobs)):
    s = f'{pos[i]:8.3f} d_obs={dobs[i]:8.4f}'
    if used[i]:
        s += f'  hkl={tuple(hk[i])} d_calc={dc[i]:8.4f} ({100*(dc[i]/dobs[i]-1):+6.3f}%)'
    else:
        s += '   --- not indexed ---'
    print(s)
print('rms(%%) = %.4f' % np.sqrt(np.mean(((dc[used]-dobs[used])/dobs[used]*100)**2)))
