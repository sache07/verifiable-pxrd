"""Final refinement: per-phase broadening model, Suortti roughness, coordinate refinement.
Usage: fit10.py tag [broad-mode]
broad-mode: 'mu' = massicot/litharge use mustrain, 'size' = they use size
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

tag = sys.argv[1]
mode = sys.argv[2] if len(sys.argv) > 2 else 'mu'
names = ['stolzite', 'WO3', 'litharge', 'massicot', 'Pb2WO5']
CIF['Pb2WO5'] = os.path.join(W, 'Pb2WO5_start.cif')
p, h = new_project(tag, names, ncoef=12)
ip = h.data['Instrument Parameters'][0]
for k, v in (('U', 5.), ('V', -5.), ('W', 50.), ('X', 1.), ('Y', 0.), ('SH/L', 0.002),
             ('Polariz.', 0.5)):
    ip[k][1] = v
sp = h.data['Sample Parameters']
sp['Shift'][0] = -460.
for ph in p.phases():
    ph.data['Histograms'][h.name]['Mustrain'][1][0] = 500.
    ph.data['Histograms'][h.name]['Size'][1][0] = 1.0
    for at in ph.atoms():
        at.data[at.cia] = 'I'
        at.ADP = 0.018 if at.element == 'O' else 0.011
for nm in ('litharge', 'massicot'):
    ph = p.phase(nm)
    if mode == 'mu':
        ph.data['Histograms'][h.name]['Mustrain'][1][0] = 20000.
        ph.data['Histograms'][h.name]['Size'][1][0] = 10.0
    else:
        ph.data['Histograms'][h.name]['Size'][1][0] = 0.015

C = p.data['Controls']['data']
C['parmMaxDict'] = {'*:*:Mustrain;i': 60000., '*::AUiso:*': 0.05, '*:*:Size;i': 10.,
                    ':*:SurfRoughA': 1.5, ':*:SurfRoughB': 2.0}
C['parmMinDict'] = {'*:*:Mustrain;i': 300., '*::AUiso:*': 0.001, '*:*:Size;i': 0.004,
                    ':*:SurfRoughA': 0.0, ':*:SurfRoughB': 0.0}

def refine(msg):
    C['parmFrozen'] = {}
    p.refine()
    report(p, h, msg)
    print('   rough', [round(sp[k][0], 4) for k in ('SurfRoughA', 'SurfRoughB')])

refine('bkg+frac')
sp['Shift'][1] = True
refine('+shift')
# broadening: sharp phases -> size; poorly crystalline PbO -> mustrain (or size)
for nm in ('stolzite', 'WO3', 'Pb2WO5'):
    p.phase(nm).set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}},
                                    histograms=[h.name])
for nm in ('litharge', 'massicot'):
    key = 'Mustrain' if mode == 'mu' else 'Size'
    p.phase(nm).set_HAP_refinements({key: {'type': 'isotropic', 'refine': True}},
                                    histograms=[h.name])
refine('+broadening')
for ph in p.phases():
    ph.set_refinements({'Cell': True})
refine('+cell')
sp['SurfRoughA'][0], sp['SurfRoughB'][0] = 0.5, 0.1
sp['SurfRoughA'][1] = sp['SurfRoughB'][1] = True
refine('+roughness')
h.set_refinements({'Instrument Parameters': ['W', 'SH/L']})
refine('+W,SH/L')
# structural refinement: heavy-atom coordinates of Pb2WO5 and O of stolzite
p.phase('Pb2WO5').set_refinements({'Atoms': {'Pb1': 'X', 'Pb2': 'X', 'W1': 'X'}})
refine('+Pb2WO5 xyz')
p.phase('stolzite').set_refinements({'Atoms': {'O': 'X'}})
refine('+stolzite O')
for ph in p.phases():
    print(' ', ph.name, [(a.label, [round(v, 5) for v in a.coordinates], round(a.ADP, 4))
                         for a in ph.atoms()])
try:
    print('mass fracs:', h.ComputeMassFracs())
except Exception as e:
    print('massfrac err', e)
save_prof(h, tag + '_prof.csv')
p.save()
