"""Staged multiphase Rietveld with fixed instrumental profile + per-phase broadening."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

names = sys.argv[1].split(',') if len(sys.argv) > 1 else ['stolzite', 'WO3', 'litharge', 'massicot']
tag = sys.argv[2] if len(sys.argv) > 2 else 'fit4'
p, h = new_project(tag, names, ncoef=12)
ip = h.data['Instrument Parameters'][0]
for k, v in (('U', 5.), ('V', -5.), ('W', 8.), ('X', 1.), ('Y', 0.), ('SH/L', 0.002)):
    ip[k][1] = v
h.data['Sample Parameters']['Shift'][0] = -440.
for ph in p.phases():
    ph.data['Histograms'][h.name]['Mustrain'][1][0] = 2000.
    ph.data['Histograms'][h.name]['Size'][1][0] = 2.0

p.refine()
report(p, h, 'bkg+frac')

h.data['Sample Parameters']['Shift'][1] = True
p.refine()
report(p, h, '+shift')

for ph in p.phases():
    ph.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}}, histograms=[h.name])
p.refine()
report(p, h, '+mustrain')

for ph in p.phases():
    ph.set_refinements({'Cell': True})
p.refine()
report(p, h, '+cell')

for ph in p.phases():
    ph.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}}, histograms=[h.name])
p.refine()
report(p, h, '+size')

h.set_refinements({'Instrument Parameters': ['W', 'SH/L']})
p.refine()
report(p, h, '+W,SH/L')

try:
    print('mass fracs:', h.ComputeMassFracs())
except Exception as e:
    print('massfrac err', e)
save_prof(h, tag + '_prof.csv')
p.save()
