"""Compare observed peak list against simulated patterns of candidate phases (with a 2theta offset)."""
import sys, numpy as np, json
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator

obs = np.array([float(v) for v in open(sys.argv[1]).read().split()])
off = float(sys.argv[2])
tol = float(sys.argv[3])
cands = sys.argv[4:]
c = XRDCalculator(wavelength=1.540598)
allcalc = {}
for f in cands:
    s = Structure.from_file(f)
    p = c.get_pattern(s, two_theta_range=(10, 100))
    name = s.composition.reduced_formula + ':' + f.split('/')[-1][:-4]
    allcalc[name] = (np.array(p.x) + off, np.array(p.y))
explained = {}
for t in obs:
    hits = []
    for n, (px, py) in allcalc.items():
        m = np.abs(px - t) < tol
        if m.any() and py[m].max() > 1.0:
            hits.append(f'{n}({py[m].max():.0f})')
    explained[t] = hits
for t, h in explained.items():
    print(f'{t:8.3f}  ', ', '.join(h) if h else '   *** UNEXPLAINED ***')
