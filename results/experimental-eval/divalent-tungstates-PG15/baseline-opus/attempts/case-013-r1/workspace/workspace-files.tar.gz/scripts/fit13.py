"""Reference fit with only the two certain phases (stolzite, WO3) in Le Bail mode,
to isolate the residual belonging to the remaining phases.
Usage: fit13.py tag phase1,phase2,..."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

tag = sys.argv[1]
names = sys.argv[2].split(',')
CIF['Pb2WO5'] = os.path.join(W, 'Pb2WO5_start.cif')
p, h = new_project(tag, names, ncoef=12)
ip = h.data['Instrument Parameters'][0]
for k, v in (('U', 140.), ('V', -160.), ('W', 60.), ('X', 1.), ('Y', 0.), ('SH/L', 0.008),
             ('Polariz.', 0.5)):
    ip[k][1] = v
sp = h.data['Sample Parameters']
sp['Shift'][0] = -442.
sp['SurfRoughA'][0], sp['SurfRoughB'][0] = 0.30, 0.84
for ph in p.phases():
    ph.data['Histograms'][h.name]['Mustrain'][1][0] = 500.
    ph.data['Histograms'][h.name]['Size'][1][0] = 0.10
    for at in ph.atoms():
        at.data[at.cia] = 'I'
        at.ADP = 0.018 if at.element == 'O' else 0.011
C = p.data['Controls']['data']
C['parmMaxDict'] = {'*:*:Size;i': 10.}
C['parmMinDict'] = {'*:*:Size;i': 0.004}
p.refine()
report(p, h, 'scales')
for ph in p.phases():
    ph.set_refinements({'Cell': True})
    ph.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}}, histograms=[h.name])
C['parmFrozen'] = {}
p.refine()
report(p, h, '+cell+size')
for ph in p.phases():
    ph.set_refinements({'LeBail': True})
C['newLeBail'] = True
for i in range(4):
    C['parmFrozen'] = {}
    p.refine()
    print(f'  LeBail cycle {i}: Rwp = {h.get_wR():.3f}')
    C['newLeBail'] = False
report(p, h, 'after LeBail')
save_prof(h, tag + '_prof.csv')
p.save()
