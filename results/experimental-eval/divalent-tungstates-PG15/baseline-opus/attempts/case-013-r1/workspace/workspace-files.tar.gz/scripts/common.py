import os, numpy as np
import GSASII.GSASIIscriptable as G2sc

W = '<ATTEMPT_WORKSPACE>/work'
D = '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif'

CIF = {
    'stolzite': f'{D}/9/00/98/9009811.cif',      # PbWO4 I41/a
    'raspite':  f'{D}/9/00/76/9007617.cif',      # PbWO4 P21/a
    'WO3':      f'{D}/1/52/89/1528915.cif',      # WO3 P21/n
    'litharge': os.path.join(W, 'litharge_PbO.cif'),   # alpha-PbO P4/nmm (origin 2)
    'massicot': f'{D}/2/31/04/2310433.cif',      # beta-PbO Pbcm
    'Pb3O4':    f'{D}/9/00/30/9003043.cif',
    'Pb2O3':    f'{D}/2/31/10/2311012.cif',
}


def new_project(name, phases, ncoef=10):
    gpx = os.path.join(W, name + '.gpx')
    for f in (gpx, gpx.replace('.gpx', '.bak0.gpx')):
        if os.path.exists(f):
            os.remove(f)
    p = G2sc.G2Project(newgpx=gpx)
    h = p.add_powder_histogram(os.path.join(W, 'pattern.xy'), os.path.join(W, 'cu.instprm'),
                               fmthint='Topas xye')
    for nm in phases:
        p.add_phase(CIF[nm] if nm in CIF else nm, phasename=nm, histograms=[h], fmthint='CIF')
    # sensible starting profile for a broadened lab pattern
    ip = h.data['Instrument Parameters'][0]
    for k, v in (('U', 50.), ('V', -20.), ('W', 15.), ('X', 2.), ('Y', 5.), ('SH/L', 0.002)):
        ip[k][1] = v
    h.data['Sample Parameters']['Scale'] = [1.0, False]
    h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': ncoef, 'refine': True}})
    for ph in p.phases():
        ph.set_HAP_refinements({'Scale': True})
    return p, h


def prof(h):
    d = h.data['data'][1]
    return np.column_stack([d[0], d[1], d[3], d[4]])


def save_prof(h, fn):
    np.savetxt(os.path.join(W, fn), prof(h), delimiter=',',
               header='x,yobs,ycalc,ybkg', comments='')


def report(p, h, tag=''):
    print(f'--- {tag}: Rwp = {h.get_wR():.3f}')
    ip = h.data['Instrument Parameters'][0]
    print('   inst:', {k: round(ip[k][1], 4) for k in ('Zero', 'U', 'V', 'W', 'X', 'Y', 'SH/L', 'Polariz.')},
          'Shift', round(h.data['Sample Parameters']['Shift'][0], 2))
    try:
        wf = {ph.name: round(ph.get_WeightFraction(h.name), 4) for ph in p.phases()}
        print('   wtfrac:', wf)
    except Exception as e:
        print('   wtfrac err', e)
    for ph in p.phases():
        c = ph.get_cell()
        print(f"   {ph.name:10s} a={c['length_a']:.5f} b={c['length_b']:.5f} c={c['length_c']:.5f} "
              f"beta={c['angle_beta']:.4f} V={c['volume']:.3f} "
              f"frac={ph.data['Histograms'][h.name]['Scale'][0]:.5f} "
              f"size={ph.data['Histograms'][h.name]['Size'][1][0]:.3f} "
              f"mustr={ph.data['Histograms'][h.name]['Mustrain'][1][0]:.1f}")
