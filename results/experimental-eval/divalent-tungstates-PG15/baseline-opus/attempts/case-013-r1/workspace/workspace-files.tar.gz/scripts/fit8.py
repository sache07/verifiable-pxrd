"""Final staged Rietveld with parameter limits.
Usage: fit8.py phases tag [ncoef] [bkgpeaks]"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

names = sys.argv[1].split(',')
tag = sys.argv[2]
ncoef = int(sys.argv[3]) if len(sys.argv) > 3 else 12
CIF['Pb2WO5'] = os.path.join(W, 'Pb2WO5_start.cif')
p, h = new_project(tag, names, ncoef=ncoef)
ip = h.data['Instrument Parameters'][0]
for k, v in (('U', 5.), ('V', -5.), ('W', 50.), ('X', 1.), ('Y', 0.), ('SH/L', 0.002)):
    ip[k][1] = v
h.data['Sample Parameters']['Shift'][0] = -460.
for ph in p.phases():
    ph.data['Histograms'][h.name]['Mustrain'][1][0] = 3000.
    for at in ph.atoms():
        at.data[at.cia] = 'I'
        at.ADP = 0.018 if at.element == 'O' else 0.011

C = p.data['Controls']['data']
C['parmMaxDict'] = {'*:*:Mustrain;i': 15000., '*::AUiso:*': 0.05}
C['parmMinDict'] = {'*:*:Mustrain;i': 300., '*::AUiso:*': 0.001}

def refine(msg):
    C['parmFrozen'] = {}
    p.refine()
    report(p, h, msg)

refine('bkg+frac')
h.data['Sample Parameters']['Shift'][1] = True
refine('+shift')
for ph in p.phases():
    ph.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}}, histograms=[h.name])
refine('+mustrain')
for ph in p.phases():
    ph.set_refinements({'Cell': True})
refine('+cell')
p.phase(names[0]).set_refinements({'Atoms': {'all': 'U'}})
refine('+Uiso(major)')
h.set_refinements({'Instrument Parameters': ['W', 'SH/L']})
refine('+W,SH/L')
for ph in p.phases():
    print(' ', ph.name, 'Uiso', [(a.label, round(a.ADP, 4)) for a in ph.atoms()])
try:
    print('mass fracs:', h.ComputeMassFracs())
except Exception as e:
    print('massfrac err', e)
save_prof(h, tag + '_prof.csv')
p.save()
