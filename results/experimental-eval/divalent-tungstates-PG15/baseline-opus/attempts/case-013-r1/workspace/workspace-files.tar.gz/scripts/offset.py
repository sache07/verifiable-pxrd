"""Fit scheelite cell + 2theta offset model to indexed observed peaks of the major phase."""
import numpy as np
from scipy.optimize import least_squares

lam = 1.540598
# (hkl) : observed 2theta  (scheelite PbWO4, I41/a)
obs = {(1,1,2): 27.700, (0,0,4): 29.906, (2,0,0): 33.057, (2,0,4): 45.032,
       (2,2,0): 47.281, (1,1,6): 51.487, (3,1,2): 55.540, (2,2,4): 56.822,
       (3,1,6): 71.666, (4,0,0): 68.906, (3,3,2): 76.751, (2,0,8): 72.274,
       (4,2,4): 78.425, (1,1,10): 81.076, (4,0,8): 85.977, (5,1,2): 90.758,
       (4,4,0): 94.029}

def th(hkl, a, c):
    h, k, l = hkl
    d = 1/np.sqrt((h*h+k*k)/a**2 + l*l/c**2)
    return 2*np.degrees(np.arcsin(lam/(2*d)))

hkls = list(obs)
y = np.array([obs[h] for h in hkls])

def resid(p, model):
    a, c, z = p
    tc = np.array([th(h, a, c) for h in hkls])
    if model == 'zero':
        return tc + z - y
    else:  # specimen displacement: d2th = z*cos(theta)
        return tc + z*np.cos(np.radians(tc/2)) - y

for model in ('zero', 'disp'):
    r = least_squares(resid, [5.46, 12.05, 0.3], args=(model,))
    a, c, z = r.x
    rms = np.sqrt(np.mean(r.fun**2))
    print(f'{model}: a={a:.5f} c={c:.5f} shift={z:.4f} rms={rms*1000:.1f} m-deg')
    for h, dv in zip(hkls, r.fun):
        print(f'   {h} obs={obs[h]:8.3f} resid={dv*1000:7.1f}')
