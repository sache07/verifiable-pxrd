"""Fit Ka1/Ka2 doublets to the residual (obs-calc) curve to get accurate positions of
unmodelled reflections. Usage: fitres.py prof.csv shift_microns out.txt"""
import numpy as np, sys
from scipy.signal import find_peaks
from scipy.optimize import curve_fit

lam1, lam2, rat = 1.540598, 1.544426, 0.5

def ka2(pos):
    return 2*np.degrees(np.arcsin(np.clip(lam2/lam1*np.sin(np.radians(pos/2)), -1, 1)))

def pv(x, pos, fwhm, eta):
    g = np.exp(-4*np.log(2)*((x-pos)/fwhm)**2)*2*np.sqrt(np.log(2)/np.pi)/fwhm
    l = (2/(np.pi*fwhm))/(1+4*((x-pos)/fwhm)**2)
    return eta*l + (1-eta)*g

d = np.genfromtxt(sys.argv[1], delimiter=',', names=True)
x, r = d['x'], d['yobs'] - d['ycalc']
shift = float(sys.argv[2])
sig = np.sqrt(np.maximum(d['yobs'], 1))

# smooth lightly for peak detection
from scipy.ndimage import uniform_filter1d
rs = uniform_filter1d(r, 5)
pk, _ = find_peaks(rs, height=5*np.median(sig), prominence=200, distance=8)
print('# candidate residual peaks:', len(pk))

# cluster peaks that are within 0.5 deg
clusters, cur = [], [pk[0]]
for i in pk[1:]:
    if x[i] - x[cur[-1]] < 0.55:
        cur.append(i)
    else:
        clusters.append(cur); cur = [i]
clusters.append(cur)

const = 9.e-2/(np.pi*200.0)
rows = []
for cl in clusters:
    lo, hi = x[cl[0]] - 0.6, x[cl[-1]] + 0.7
    m = (x >= lo) & (x <= hi)
    xs, ys = x[m], r[m]
    n = len(cl)
    p0, lb, ub = [], [], []
    for i in cl:
        p0 += [max(rs[i], 10)*0.2, x[i]]
        lb += [0, x[i]-0.25]; ub += [np.inf, x[i]+0.25]
    p0 += [0.16, 0.5, 0.0]; lb += [0.03, 0.0, -np.inf]; ub += [0.8, 1.0, np.inf]

    def model(xx, *p):
        fw, eta, bg = p[-3:]
        out = np.full_like(xx, bg)
        for j in range(n):
            A, pos = p[2*j], p[2*j+1]
            out = out + A*(pv(xx, pos, fw, eta) + rat*pv(xx, ka2(pos), fw, eta))
        return out
    try:
        popt, _ = curve_fit(model, xs, ys, p0=p0, bounds=(lb, ub), maxfev=20000)
    except Exception as e:
        print('# fit failed near', x[cl[0]], e); continue
    fw, eta, bg = popt[-3:]
    yfit = model(xs, *popt)
    for j in range(n):
        A, pos = popt[2*j], popt[2*j+1]
        th = np.radians(pos/2)
        pos_corr = pos + const*4*shift*np.cos(th)
        dsp = lam1/(2*np.sin(np.radians(pos_corr/2)))
        hmax = A*pv(pos, pos, fw, eta)
        rows.append((pos, pos_corr, dsp, A, hmax, fw))
print(f'# shift={shift}  columns: pos_obs pos_corr d A height fwhm')
for r_ in sorted(rows):
    print(f'{r_[0]:9.4f} {r_[1]:9.4f} {r_[2]:9.5f} {r_[3]:10.1f} {r_[4]:9.1f} {r_[5]:7.4f}')
