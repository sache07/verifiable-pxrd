"""Refinement with physical peak-shape model: fixed instrumental profile + per-phase size/strain."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

names = sys.argv[1].split(',') if len(sys.argv) > 1 else ['stolzite', 'WO3', 'litharge', 'massicot']
tag = sys.argv[2] if len(sys.argv) > 2 else 'fit3'
p, h = new_project(tag, names, ncoef=12)
ip = h.data['Instrument Parameters'][0]
for k, v in (('U', 5.), ('V', -5.), ('W', 8.), ('X', 1.), ('Y', 0.), ('SH/L', 0.002)):
    ip[k][1] = v
# start with modest sample broadening
for ph in p.phases():
    ph.data['Histograms'][h.name]['Mustrain'][1][0] = 2000.
    ph.data['Histograms'][h.name]['Size'][1][0] = 1.0

p.refine()
report(p, h, 'bkg+frac')

h.data['Sample Parameters']['Shift'][1] = True
for ph in p.phases():
    ph.set_refinements({'Cell': True})
p.refine()
report(p, h, '+shift+cell')

for ph in p.phases():
    ph.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}}, histograms=[h.name])
p.refine()
report(p, h, '+mustrain')

for ph in p.phases():
    ph.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}}, histograms=[h.name])
p.refine()
report(p, h, '+size')

h.set_refinements({'Instrument Parameters': ['SH/L']})
p.refine()
report(p, h, '+SH/L')

save_prof(h, tag + '_prof.csv')
p.save()
