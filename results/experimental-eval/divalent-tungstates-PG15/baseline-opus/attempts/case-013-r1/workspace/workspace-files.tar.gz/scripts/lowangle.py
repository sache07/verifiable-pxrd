import numpy as np, sys
from scipy.ndimage import uniform_filter1d
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
d = np.loadtxt('inputs/pattern.csv', delimiter=',', skiprows=1)
x, y = d[:, 0], d[:, 1]
m = x < 26.5
x, y = x[m], y[m]
ys = uniform_filter1d(y, 21)
# smooth polynomial background over the window
co = np.polyfit(x, np.log(ys), 8)
bg = np.exp(np.polyval(co, x))
fig, ax = plt.subplots(2, 1, figsize=(18, 9))
ax[0].plot(x, y, lw=0.5, alpha=.4); ax[0].plot(x, ys, lw=1); ax[0].plot(x, bg, lw=1)
ax[1].plot(x, ys-bg, lw=1); ax[1].axhline(0, color='k', lw=.5)
ax[1].fill_between(x, -3*np.sqrt(ys/21), 3*np.sqrt(ys/21), color='g', alpha=.3)
for a in ax:
    a.grid(alpha=.3); a.set_xticks(np.arange(10, 27, 0.5)); a.tick_params(labelsize=7)
plt.tight_layout(); plt.savefig('work/lowangle.png', dpi=110)
