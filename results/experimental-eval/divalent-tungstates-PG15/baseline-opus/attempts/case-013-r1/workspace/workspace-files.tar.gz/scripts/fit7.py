"""Staged Rietveld with parameter limits (stable version).
Usage: fit7.py phases tag [ncoef]"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

names = sys.argv[1].split(',')
tag = sys.argv[2]
ncoef = int(sys.argv[3]) if len(sys.argv) > 3 else 12
CIF['Pb2WO5'] = os.path.join(W, 'Pb2WO5_start.cif')
p, h = new_project(tag, names, ncoef=ncoef)
ip = h.data['Instrument Parameters'][0]
for k, v in (('U', 5.), ('V', -5.), ('W', 50.), ('X', 1.), ('Y', 0.), ('SH/L', 0.002)):
    ip[k][1] = v
h.data['Sample Parameters']['Shift'][0] = -460.
for ph in p.phases():
    ph.data['Histograms'][h.name]['Mustrain'][1][0] = 3000.
    ph.data['Histograms'][h.name]['Size'][1][0] = 2.0
    for at in ph.atoms():
        at.data[at.cia] = 'I'
        at.ADP = 0.02 if at.element == 'O' else 0.012

# parameter limits keep the refinement physical
C = p.data['Controls']['data']
C['parmMaxDict'] = {'Mustrain;i': 15000., 'Uiso': 0.06, 'Size;i': 10.}
C['parmMinDict'] = {'Mustrain;i': 100., 'Uiso': 0.0005, 'Size;i': 0.05}

p.refine(); report(p, h, 'bkg+frac')
h.data['Sample Parameters']['Shift'][1] = True
p.refine(); report(p, h, '+shift')
for ph in p.phases():
    ph.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}}, histograms=[h.name])
p.refine(); report(p, h, '+mustrain')
for ph in p.phases():
    ph.set_refinements({'Cell': True})
p.refine(); report(p, h, '+cell')
for ph in p.phases():
    ph.set_refinements({'Atoms': {'all': 'U'}})
p.refine(); report(p, h, '+Uiso')
h.set_refinements({'Instrument Parameters': ['W', 'SH/L']})
p.refine(); report(p, h, '+W,SH/L')
for ph in p.phases():
    print(' ', ph.name, 'Uiso', [(a.label, round(a.ADP, 4)) for a in ph.atoms()])
try:
    print('mass fracs:', h.ComputeMassFracs())
except Exception as e:
    print('massfrac err', e)
save_prof(h, tag + '_prof.csv')
p.save()
