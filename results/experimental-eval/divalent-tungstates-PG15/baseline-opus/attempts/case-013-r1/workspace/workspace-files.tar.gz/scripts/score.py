"""Score candidate CIFs against a target peak list (allowing a global 2theta offset scan)."""
import sys, json, numpy as np
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator

target = np.array([float(v) for v in open(sys.argv[1]).read().split()])
cands = json.load(open(sys.argv[2]))
c = XRDCalculator(wavelength=1.540598)
res = []
for e in cands:
    try:
        s = Structure.from_file(e['file'])
        p = c.get_pattern(s, two_theta_range=(float(target.min())-1, float(target.max())+1))
    except Exception as ex:
        continue
    px, py = np.array(p.x), np.array(p.y)
    keep = py > 5.0
    px, py = px[keep], py[keep]
    if len(px) == 0:
        continue
    best = None
    for off in np.arange(0.0, 0.45, 0.02):
        # fraction of strong calc lines that have an observed peak nearby
        hit_c = np.mean([np.abs(target - (t+off)).min() < 0.18 for t in px])
        hit_o = np.mean([np.abs(px + off - t).min() < 0.18 for t in target])
        sc = hit_c * hit_o
        if best is None or sc > best[0]:
            best = (sc, off, hit_c, hit_o)
    res.append((best[0], best[1], best[2], best[3], e['formula'], e['mineral'], e['sg'], e['file'].split('/')[-1]))
res.sort(reverse=True)
for r in res[:25]:
    print(f'score={r[0]:.3f} off={r[1]:.2f} calc_hit={r[2]:.2f} obs_hit={r[3]:.2f}  {r[4]:12s} {r[5]:12s} {r[6]:14s} {r[7]}')
