import numpy as np, sys
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
d = np.genfromtxt(sys.argv[1], delimiter=',', names=True)
x, yo, yc = d['x'], d['yobs'], d['ycalc']
n = 3
fig, axs = plt.subplots(n, 1, figsize=(19, 4*n))
edges = np.linspace(x.min(), x.max(), n+1)
for i, ax in enumerate(axs):
    m = (x >= edges[i]) & (x <= edges[i+1])
    ax.plot(x[m], yo[m], 'k-', lw=0.7, label='obs')
    ax.plot(x[m], yc[m], 'r-', lw=0.7, label='calc')
    ax.plot(x[m], yo[m]-yc[m] - 0.12*yo[m].max(), 'b-', lw=0.7, label='diff')
    ax.grid(alpha=.3); ax.set_xticks(np.arange(np.round(edges[i]), edges[i+1], 1))
    ax.set_xlim(edges[i], edges[i+1])
    if i == 0: ax.legend()
plt.tight_layout(); plt.savefig(sys.argv[2], dpi=100)
