"""4-phase Rietveld: stolzite + WO3 + litharge + massicot, careful sequence."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

names = sys.argv[1].split(',') if len(sys.argv) > 1 else ['stolzite', 'WO3', 'litharge', 'massicot']
tag = sys.argv[2] if len(sys.argv) > 2 else 'fit2'
p, h = new_project(tag, names)

p.refine()
report(p, h, 'bkg+frac')

h.data['Sample Parameters']['Shift'][1] = True
p.refine()
report(p, h, '+shift')

for ph in p.phases():
    ph.set_refinements({'Cell': True})
p.refine()
report(p, h, '+cell')

h.set_refinements({'Instrument Parameters': ['W', 'Y']})
p.refine()
report(p, h, '+W,Y')

h.set_refinements({'Instrument Parameters': ['U', 'X']})
p.refine()
report(p, h, '+U,X')

for ph in p.phases():
    ph.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True},
                            'Size': {'type': 'isotropic', 'refine': True}}, histograms=[h.name])
p.refine()
report(p, h, '+size/strain')

save_prof(h, tag + '_prof.csv')
p.save()
