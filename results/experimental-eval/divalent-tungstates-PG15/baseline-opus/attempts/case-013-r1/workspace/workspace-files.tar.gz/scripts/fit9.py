"""Staged Rietveld: per-phase size+mustrain, Suortti surface roughness, parameter limits.
Usage: fit9.py phases tag [ncoef] [pola] [rough]"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

names = sys.argv[1].split(',')
tag = sys.argv[2]
ncoef = int(sys.argv[3]) if len(sys.argv) > 3 else 12
pola = float(sys.argv[4]) if len(sys.argv) > 4 else 0.5
rough = bool(int(sys.argv[5])) if len(sys.argv) > 5 else True
CIF['Pb2WO5'] = os.path.join(W, 'Pb2WO5_start.cif')
p, h = new_project(tag, names, ncoef=ncoef)
ip = h.data['Instrument Parameters'][0]
for k, v in (('U', 5.), ('V', -5.), ('W', 50.), ('X', 1.), ('Y', 0.), ('SH/L', 0.002),
             ('Polariz.', pola)):
    ip[k][1] = v
sp = h.data['Sample Parameters']
sp['Shift'][0] = -460.
for ph in p.phases():
    ph.data['Histograms'][h.name]['Mustrain'][1][0] = 2000.
    ph.data['Histograms'][h.name]['Size'][1][0] = 1.0
    for at in ph.atoms():
        at.data[at.cia] = 'I'
        at.ADP = 0.018 if at.element == 'O' else 0.011

C = p.data['Controls']['data']
C['parmMaxDict'] = {'*:*:Mustrain;i': 15000., '*::AUiso:*': 0.05, '*:*:Size;i': 10.,
                    ':*:SurfRoughA': 1.5, ':*:SurfRoughB': 2.0}
C['parmMinDict'] = {'*:*:Mustrain;i': 200., '*::AUiso:*': 0.001, '*:*:Size;i': 0.004,
                    ':*:SurfRoughA': 0.0, ':*:SurfRoughB': 0.0}

def refine(msg):
    C['parmFrozen'] = {}
    p.refine()
    report(p, h, msg)
    print('   rough', [round(sp[k][0], 4) for k in ('SurfRoughA', 'SurfRoughB')])

refine('bkg+frac')
sp['Shift'][1] = True
refine('+shift')
for ph in p.phases():
    ph.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}}, histograms=[h.name])
refine('+mustrain')
for ph in p.phases():
    ph.set_refinements({'Cell': True})
refine('+cell')
for ph in p.phases():
    ph.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}}, histograms=[h.name])
refine('+size')
if rough:
    sp['SurfRoughA'][0], sp['SurfRoughB'][0] = 0.5, 0.1
    sp['SurfRoughA'][1] = sp['SurfRoughB'][1] = True
    refine('+roughness')
h.set_refinements({'Instrument Parameters': ['W', 'SH/L']})
refine('+W,SH/L')
for ph in p.phases():
    print(' ', ph.name, 'Uiso', [(a.label, round(a.ADP, 4)) for a in ph.atoms()])
try:
    print('mass fracs:', h.ComputeMassFracs())
except Exception as e:
    print('massfrac err', e)
save_prof(h, tag + '_prof.csv')
p.save()
