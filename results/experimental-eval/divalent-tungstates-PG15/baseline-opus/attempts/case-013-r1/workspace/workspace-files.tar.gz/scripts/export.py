"""Export deliverables from a finished GSAS-II project:
   one CIF per phase, fit.csv, result.json.
Usage: export.py project.gpx outdir"""
import sys, os, json, shutil
import numpy as np
import GSASII.GSASIIscriptable as G2sc

gpxin, outdir = sys.argv[1], sys.argv[2]
os.makedirs(outdir, exist_ok=True)
final = os.path.join(outdir, 'final.gpx')
if os.path.abspath(gpxin) != os.path.abspath(final):
    shutil.copy(gpxin, final)
p = G2sc.G2Project(final)
h = p.histograms()[0]

IDENT = {
    'stolzite': ('PbWO4', 'stolzite (scheelite-type PbWO4)'),
    'WO3': ('WO3', 'monoclinic gamma-WO3 (unreacted precursor)'),
    'litharge': ('PbO', 'litharge, alpha-PbO (unreacted precursor)'),
    'massicot': ('PbO', 'massicot, beta-PbO (unreacted precursor)'),
    'Pb2WO5': ('Pb2WO5', 'Pb2WO5, modelled in the Pb2MoO5 (C2/m) structure type'),
}

x, yo, w, yc, yb = (h.data['data'][1][i] for i in range(5))
yd = yo - yc
np.savetxt(os.path.join(outdir, 'fit.csv'),
           np.column_stack([x, yo, yc, yd, yb]), delimiter=',',
           header='two_theta_deg,y_obs,y_calc,y_diff,y_background', comments='', fmt='%.6f')

cov = p.data['Covariance']['data']
R = cov['Rvals']
N, P = int(R['Nobs']), int(R['Nvars'])
sw = np.sum(w*yo*yo)
stats = {
    'Rwp_percent': round(float(R['Rwp']), 3),
    'Rp_percent': round(float(100*np.sum(np.abs(yd))/np.sum(yo)), 3),
    'Rexp_percent': round(float(100*np.sqrt((N-P)/sw)), 3),
    'GOF': round(float(R['GOF']), 3),
    'chi_squared_reduced': round(float(R['GOF'])**2, 3),
    'n_points': N, 'n_refined_parameters': P,
    'two_theta_range_deg': [round(float(x.min()), 4), round(float(x.max()), 4)],
}
try:
    mf = h.ComputeMassFracs()
except Exception as e:
    print('massfrac failed', e)
    mf = {}

phases = []
for ph in p.phases():
    name = ph.name
    cifname = f'{name}.cif'
    ph.export_CIF(os.path.join(outdir, cifname))
    cell, esd = ph.get_cell_and_esd()
    hap = ph.data['Histograms'][h.name]
    val, su = mf.get(name, (float('nan'), float('nan')))
    comp = {}
    for at in ph.atoms():
        comp[at.element] = comp.get(at.element, 0) + at.data[ph.data['General']['AtomPtrs'][2]+1]*at.occupancy
    phases.append({
        'phase': name,
        'formula': IDENT.get(name, ('', ''))[0],
        'identification': IDENT.get(name, ('', ''))[1],
        'space_group': ph.data['General']['SGData']['SpGrp'],
        'atoms_per_unit_cell': {k: round(v, 3) for k, v in comp.items()},
        'cif': cifname,
        'weight_fraction': round(float(val), 4),
        'weight_fraction_esd_statistical': round(float(su), 4),
        'lattice': {k: round(float(v), 5) for k, v in cell.items()},
        'lattice_esd': {k: round(float(v), 5) for k, v in esd.items()},
        'crystallite_size_micron': round(float(hap['Size'][1][0]), 4),
        'microstrain_1e6_fixed': round(float(hap['Mustrain'][1][0]), 1),
        'phase_scale': round(float(hap['Scale'][0]), 6),
    })

res = {
    'sample': 'PbO + WO3, heated at 500 C (see inputs/metadata.json)',
    'n_phases_modelled': len(phases),
    'phases': phases,
    'fit_statistics': stats,
    'sum_weight_fractions': round(float(sum(q['weight_fraction'] for q in phases)), 4),
    'notes': 'Weight fractions are normalised over the five modelled crystalline phases; '
             'any amorphous content is not quantified. See report.md for the evidence and '
             'for realistic (systematic) uncertainties, which are larger than the '
             'statistical esds quoted here.',
}
json.dump(res, open(os.path.join(outdir, 'result.json'), 'w'), indent=2)
print(json.dumps(res, indent=2))
