"""Final refinement v11: Gaussian Caglioti instrument/strain + per-phase Lorentzian size,
Suortti surface roughness, sample displacement, coordinate refinement.
Usage: fit11.py tag"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

tag = sys.argv[1]
names = ['stolzite', 'WO3', 'litharge', 'massicot', 'Pb2WO5']
CIF['Pb2WO5'] = os.path.join(W, 'Pb2WO5_start.cif')
p, h = new_project(tag, names, ncoef=12)
ip = h.data['Instrument Parameters'][0]
for k, v in (('U', 210.), ('V', -188.), ('W', 89.), ('X', 0.5), ('Y', 0.), ('SH/L', 0.002),
             ('Polariz.', 0.5)):
    ip[k][1] = v
sp = h.data['Sample Parameters']
sp['Shift'][0] = -445.
for ph in p.phases():
    ph.data['Histograms'][h.name]['Mustrain'][1][0] = 300.
    ph.data['Histograms'][h.name]['Size'][1][0] = 5.0
    for at in ph.atoms():
        at.data[at.cia] = 'I'
        at.ADP = 0.018 if at.element == 'O' else 0.011
for nm in ('litharge', 'massicot'):
    p.phase(nm).data['Histograms'][h.name]['Size'][1][0] = 0.015

C = p.data['Controls']['data']
C['parmMaxDict'] = {'*:*:Mustrain;i': 30000., '*::AUiso:*': 0.05, '*:*:Size;i': 10.,
                    ':*:SurfRoughA': 1.5, ':*:SurfRoughB': 2.0, ':*:SH/L': 0.1,
                    ':*:U': 600., ':*:W': 300., ':*:X': 20.}
C['parmMinDict'] = {'*:*:Mustrain;i': 200., '*::AUiso:*': 0.001, '*:*:Size;i': 0.004,
                    ':*:SurfRoughA': 0.0, ':*:SurfRoughB': 0.0, ':*:SH/L': 0.0,
                    ':*:U': 0., ':*:W': 0., ':*:X': 0.}

def refine(msg):
    C['parmFrozen'] = {}
    p.refine()
    report(p, h, msg)
    print('   rough', [round(sp[k][0], 4) for k in ('SurfRoughA', 'SurfRoughB')])

refine('bkg+frac')
sp['Shift'][1] = True
refine('+shift')
for ph in p.phases():
    ph.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}}, histograms=[h.name])
refine('+size')
for ph in p.phases():
    ph.set_refinements({'Cell': True})
refine('+cell')
sp['SurfRoughA'][0], sp['SurfRoughB'][0] = 0.4, 0.3
sp['SurfRoughA'][1] = sp['SurfRoughB'][1] = True
refine('+roughness')
h.set_refinements({'Instrument Parameters': ['U', 'W']})
refine('+U,W')
h.set_refinements({'Instrument Parameters': ['V', 'X']})
refine('+V,X')
p.phase('Pb2WO5').set_refinements({'Atoms': {'Pb1': 'X', 'Pb2': 'X', 'W1': 'X'}})
refine('+Pb2WO5 xyz')
p.phase('stolzite').set_refinements({'Atoms': {'O': 'X'}})
refine('+stolzite O')
for ph in p.phases():
    print(' ', ph.name, [(a.label, [round(v, 5) for v in a.coordinates], round(a.ADP, 4))
                         for a in ph.atoms()])
try:
    print('mass fracs:', h.ComputeMassFracs())
except Exception as e:
    print('massfrac err', e)
save_prof(h, tag + '_prof.csv')
p.save()
