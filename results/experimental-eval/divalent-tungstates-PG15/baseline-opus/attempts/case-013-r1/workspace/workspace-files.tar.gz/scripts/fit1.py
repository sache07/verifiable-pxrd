"""Initial multi-phase Rietveld: stolzite + WO3 + PbO."""
import os, sys, numpy as np
import GSASII.GSASIIscriptable as G2sc

W = '<ATTEMPT_WORKSPACE>/work'
D = '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif'
gpx = os.path.join(W, 'fit1.gpx')
if os.path.exists(gpx):
    os.remove(gpx)
p = G2sc.G2Project(newgpx=gpx)
h = p.add_powder_histogram(os.path.join(W, 'pattern.xy'), os.path.join(W, 'cu.instprm'),
                           fmthint='Topas xye')
phases = [('stolzite', f'{D}/9/00/98/9009811.cif'),
          ('WO3', f'{D}/1/52/89/1528915.cif'),
          ('PbO', f'{D}/9/01/27/9012700.cif')]
for nm, f in phases:
    p.add_phase(f, phasename=nm, histograms=[h], fmthint='CIF')

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True},
                   'Sample Parameters': ['Scale']})
p.set_refinement({'set': {'Scale': True}})
p.refine()
print('Rwp', h.get_wR())

# zero + cells
h.set_refinements({'Instrument Parameters': ['Zero']})
p.set_refinement({'set': {'Cell': True}})
p.refine()
print('Rwp after zero+cell', h.get_wR())
print('Zero', h.data['Instrument Parameters'][0]['Zero'])
for ph in p.phases():
    print(ph.name, ph.get_cell())

h.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']})
p.refine()
print('Rwp after profile', h.get_wR())
for ph in p.phases():
    print(ph.name, ph.get_cell())
print({k: h.data['Instrument Parameters'][0][k][1] for k in ('U','V','W','X','Y','Zero')})
np.savetxt(os.path.join(W, 'fit1_prof.csv'),
           np.column_stack([h.data['data'][1][0], h.data['data'][1][1], h.data['data'][1][3], h.data['data'][1][4]]),
           delimiter=',', header='x,yobs,ycalc,ybkg', comments='')
p.save()
