"""5-phase Rietveld: stolzite + WO3 + litharge + massicot + Pb2WO5."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

names = sys.argv[1].split(',') if len(sys.argv) > 1 else \
    ['stolzite', 'WO3', 'litharge', 'massicot', 'Pb2WO5']
tag = sys.argv[2] if len(sys.argv) > 2 else 'fit5'
CIF['Pb2WO5'] = os.path.join(W, 'Pb2WO5_start.cif')
p, h = new_project(tag, names, ncoef=12)
ip = h.data['Instrument Parameters'][0]
for k, v in (('U', 5.), ('V', -5.), ('W', 8.), ('X', 1.), ('Y', 0.), ('SH/L', 0.002)):
    ip[k][1] = v
h.data['Sample Parameters']['Shift'][0] = -460.
for ph in p.phases():
    ph.data['Histograms'][h.name]['Mustrain'][1][0] = 3000.
    ph.data['Histograms'][h.name]['Size'][1][0] = 2.0

p.refine(); report(p, h, 'bkg+frac')

h.data['Sample Parameters']['Shift'][1] = True
p.refine(); report(p, h, '+shift')

for ph in p.phases():
    ph.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}}, histograms=[h.name])
p.refine(); report(p, h, '+mustrain')

for ph in p.phases():
    ph.set_refinements({'Cell': True})
p.refine(); report(p, h, '+cell')

h.set_refinements({'Instrument Parameters': ['W', 'SH/L']})
p.refine(); report(p, h, '+W,SH/L')

# isotropic displacement parameters, one per phase (constrained within phase)
for ph in p.phases():
    for a in ph.data['Atoms']:
        a[9] = 0.015
    ph.set_refinements({'Atoms': {a[0]: 'U' for a in ph.data['Atoms']}})
p.refine(); report(p, h, '+Uiso')

try:
    print('mass fracs:', h.ComputeMassFracs())
except Exception as e:
    print('massfrac err', e)
save_prof(h, tag + '_prof.csv')
p.save()
