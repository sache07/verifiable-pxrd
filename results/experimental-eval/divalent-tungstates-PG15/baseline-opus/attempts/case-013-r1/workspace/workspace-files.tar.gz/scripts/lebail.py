"""Le Bail test: free the intensities of one phase to test whether its lattice indexes the
remaining residual. Usage: lebail.py in.gpx tag phasename"""
import sys, os, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import GSASII.GSASIIscriptable as G2sc
from common import W, report, save_prof

src, tag, phname = sys.argv[1], sys.argv[2], sys.argv[3]
dst = os.path.join(W, tag + '.gpx')
shutil.copy(src, dst)
p = G2sc.G2Project(dst)
h = p.histograms()[0]
C = p.data['Controls']['data']
report(p, h, 'start')
ph = p.phase(phname)
ph.set_refinements({'LeBail': True})
C['newLeBail'] = True
for i in range(4):
    C['parmFrozen'] = {}
    p.refine()
    print(f'  LeBail cycle {i}: Rwp = {h.get_wR():.3f}')
    C['newLeBail'] = False
report(p, h, 'after LeBail')
save_prof(h, tag + '_prof.csv')
p.save()
