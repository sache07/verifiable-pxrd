"""Reset the Pb2WO5 cell to the value derived from peak positions and refine its heavy-atom
coordinates. Usage: fit14.py in.gpx tag"""
import sys, os, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import GSASII.GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat
from common import W, report, save_prof

src, tag = sys.argv[1], sys.argv[2]
dst = os.path.join(W, tag + '.gpx')
shutil.copy(src, dst)
p = G2sc.G2Project(dst)
h = p.histograms()[0]
sp = h.data['Sample Parameters']
C = p.data['Controls']['data']
C['parmMaxDict'] = {'*:*:Mustrain;i': 30000., '*::AUiso:*': 0.05, '*:*:Size;i': 10.,
                    ':*:SurfRoughA': 1.5, ':*:SurfRoughB': 2.0, ':*:SH/L': 0.05,
                    ':*:U': 600., ':*:W': 300., ':*:X': 20., ':*:V': 50.}
C['parmMinDict'] = {'*:*:Mustrain;i': 200., '*::AUiso:*': 0.001, '*:*:Size;i': 0.004,
                    ':*:SurfRoughA': 0.0, ':*:SurfRoughB': 0.0, ':*:SH/L': 0.0,
                    ':*:U': 0., ':*:W': 0., ':*:X': 0., ':*:V': -600.}

ph = p.phase('Pb2WO5')
cell = [14.0999, 5.8016, 7.2932, 90.0, 112.91, 90.0]
gen = ph.data['General']
gen['Cell'][1:7] = cell
gen['Cell'][7] = G2lat.calc_V(G2lat.cell2A(cell))
ph.set_refinements({'Cell': False})
ph.set_refinements({'Atoms': {'Pb1': 'X', 'Pb2': 'X', 'W1': 'X'}})

def refine(msg):
    C['parmFrozen'] = {}
    p.refine()
    report(p, h, msg)

report(p, h, 'after cell reset')
refine('+Pb2WO5 coords (cell fixed)')
print('  coords', [(a.label, [round(v, 5) for v in a.coordinates]) for a in ph.atoms()])
ph.set_refinements({'Cell': True})
refine('+cell free')
print('  coords', [(a.label, [round(v, 5) for v in a.coordinates]) for a in ph.atoms()])
ph.set_refinements({'Atoms': {'O1': 'X', 'O2': 'X', 'O3': 'X', 'O4': 'X'}})
refine('+O coords')
print('  coords', [(a.label, [round(v, 5) for v in a.coordinates]) for a in ph.atoms()])
try:
    print('mass fracs:', h.ComputeMassFracs())
except Exception as e:
    print('massfrac err', e)
save_prof(h, tag + '_prof.csv')
p.save()
