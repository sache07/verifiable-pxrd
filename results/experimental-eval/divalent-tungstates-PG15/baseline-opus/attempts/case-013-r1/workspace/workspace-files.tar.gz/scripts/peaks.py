import numpy as np, sys
from scipy.signal import find_peaks
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

d = np.loadtxt(sys.argv[1], delimiter=',', skiprows=1)
x, y = d[:,0], d[:,1]
print('range', x.min(), x.max(), 'step', np.median(np.diff(x)), 'N', len(x))
print('ymax', y.max(), 'ymin', y.min())

# rough background: rolling minimum percentile
from scipy.ndimage import minimum_filter1d, uniform_filter1d
bg = minimum_filter1d(y, 201)
bg = uniform_filter1d(bg, 201)
yc = y - bg
pk, props = find_peaks(yc, height=max(30, 0.01*yc.max()), prominence=0.008*yc.max(), distance=5)
print(len(pk), 'peaks')
lam = 1.540598
print(' 2th      d        I     Irel')
for i in pk:
    dsp = lam/2/np.sin(np.radians(x[i]/2))
    print(f'{x[i]:8.3f} {dsp:8.4f} {yc[i]:9.1f} {100*yc[i]/yc[pk].max():6.1f}')

fig, ax = plt.subplots(2,1, figsize=(16,9))
ax[0].plot(x,y,lw=0.6); ax[0].plot(x,bg,lw=0.6)
ax[1].plot(x,yc,lw=0.6); ax[1].plot(x[pk], yc[pk],'r.')
ax[1].set_yscale('symlog')
plt.savefig(sys.argv[2], dpi=110)
