import numpy as np, sys
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
d = np.loadtxt(sys.argv[1], delimiter=',', skiprows=1)
x, y = d[:,0], d[:,1]
lo, hi = float(sys.argv[3]), float(sys.argv[4])
m = (x >= lo) & (x <= hi)
plt.figure(figsize=(18,6))
plt.plot(x[m], y[m], lw=0.8, marker='.', ms=2)
plt.grid(alpha=.3); plt.xticks(np.arange(np.floor(lo), hi+0.5, max(0.5,(hi-lo)/40)))
plt.xlim(lo,hi)
if len(sys.argv) > 5: plt.yscale('log')
plt.tight_layout(); plt.savefig(sys.argv[2], dpi=110)
