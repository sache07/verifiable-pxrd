"""Overlay candidate phase stick patterns on the smoothed residual of a fit."""
import numpy as np, sys
from scipy.ndimage import uniform_filter1d
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator
import warnings; warnings.filterwarnings('ignore')

prof, out, shift = sys.argv[1], sys.argv[2], float(sys.argv[3])
cifs = sys.argv[4:]
d = np.genfromtxt(prof, delimiter=',', names=True)
x, r = d['x'], d['yobs'] - d['ycalc']
rs = uniform_filter1d(r, 61)
const = 9.e-2/(np.pi*200.0)
calc = XRDCalculator(wavelength=1.540598)
fig, axs = plt.subplots(2, 1, figsize=(19, 9))
for ax, (lo, hi) in zip(axs, [(22, 60), (56, 100)]):
    m = (x >= lo) & (x <= hi)
    ax.plot(x[m], r[m], lw=0.5, color='0.6')
    ax.plot(x[m], rs[m], lw=1.6, color='b')
    ax.axhline(0, color='k', lw=.5)
    cols = 'rgmcy'
    for i, f in enumerate(cifs):
        s = Structure.from_file(f)
        p = calc.get_pattern(s, two_theta_range=(lo, hi))
        px = np.array(p.x) - const*4*shift*np.cos(np.radians(np.array(p.x)/2))
        sc = 0.6*np.nanmax(rs[m])/max(p.y)
        for t, ii in zip(px, p.y):
            ax.plot([t, t], [0, -sc*ii*(1+0.3*i)], color=cols[i % 5], lw=1.5)
        ax.plot([], [], color=cols[i % 5], label=f.split('/')[-1])
    ax.grid(alpha=.3); ax.set_xticks(np.arange(lo, hi, 1)); ax.set_xlim(lo, hi); ax.legend(fontsize=7)
plt.tight_layout(); plt.savefig(out, dpi=100)
