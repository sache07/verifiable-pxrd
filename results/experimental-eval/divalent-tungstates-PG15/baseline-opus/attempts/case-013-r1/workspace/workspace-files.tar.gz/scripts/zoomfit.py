import numpy as np, sys
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
d = np.genfromtxt(sys.argv[1], delimiter=',', names=True)
x, yo, yc = d['x'], d['yobs'], d['ycalc']
lo, hi = float(sys.argv[3]), float(sys.argv[4])
m = (x >= lo) & (x <= hi)
plt.figure(figsize=(18, 7))
plt.plot(x[m], yo[m], 'k.-', lw=0.8, ms=2, label='obs')
plt.plot(x[m], yc[m], 'r-', lw=1.2, label='calc')
plt.plot(x[m], yo[m]-yc[m], 'b-', lw=0.8, label='diff')
plt.axhline(0, color='0.5', lw=.5)
plt.grid(alpha=.3); plt.xticks(np.arange(np.floor(lo*10)/10, hi, max(0.1, (hi-lo)/40)))
plt.xlim(lo, hi); plt.legend()
plt.tight_layout(); plt.savefig(sys.argv[2], dpi=110)
