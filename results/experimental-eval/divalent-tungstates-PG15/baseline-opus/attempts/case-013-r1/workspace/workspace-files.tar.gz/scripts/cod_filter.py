"""Scan COD cif collection, keep entries whose elements are a subset of the allowed set."""
import os, re, sys, json

root = '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif'
allowed = set(sys.argv[1].split(','))
out = []
pat = re.compile(r"_chemical_formula_sum\s+(.*)")
for dp, dn, fn in os.walk(root):
    for f in fn:
        if not f.endswith('.cif'):
            continue
        p = os.path.join(dp, f)
        try:
            txt = open(p, errors='ignore').read()
        except Exception:
            continue
        m = pat.search(txt)
        if not m:
            continue
        s = m.group(1).strip().strip("'\"")
        if s.startswith(';'):
            continue
        els = set(re.findall(r"([A-Z][a-z]?)[0-9. ]*", s))
        els = {e for e in els if e}
        if els and els <= allowed:
            nm = re.search(r"_chemical_name_mineral\s+(.*)", txt)
            sg = re.search(r"_symmetry_space_group_name_H-M\s+(.*)", txt)
            out.append({'file': p, 'formula': s,
                        'mineral': nm.group(1).strip().strip("'\"") if nm else '',
                        'sg': sg.group(1).strip().strip("'\"") if sg else ''})
print(json.dumps(out, indent=1))
