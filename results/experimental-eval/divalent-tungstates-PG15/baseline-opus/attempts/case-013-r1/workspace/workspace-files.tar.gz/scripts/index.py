"""Autoindex a list of d-spacings with GSAS-II's DoIndexPeaks.
Usage: index.py "d1,d2,..." [bravais-set] [volmin]"""
import sys, numpy as np
from GSASII import GSASIIindex as G2indx

ds = [float(v) for v in sys.argv[1].split(',')]
lam = 1.540598
which = sys.argv[2] if len(sys.argv) > 2 else 'all'
vstart = float(sys.argv[3]) if len(sys.argv) > 3 else 25.0

bravaisNames = ['Cubic-F','Cubic-I','Cubic-P','Trigonal-R','Trigonal/Hexagonal-P',
    'Tetragonal-I','Tetragonal-P','Orthorhombic-F','Orthorhombic-I','Orthorhombic-A',
    'Orthorhombic-B','Orthorhombic-C','Orthorhombic-P','Monoclinic-I','Monoclinic-A',
    'Monoclinic-C','Monoclinic-P','Triclinic']
bravais = [0]*18
if which == 'all':
    sel = range(18)
elif which == 'hi':
    sel = range(13)
else:
    sel = [int(v) for v in which.split(',')]
for i in sel:
    bravais[i] = 1

peaks = []
for d in ds:
    pos = 2*np.degrees(np.arcsin(lam/(2*d)))
    peaks.append([pos, 100.0, True, False, 0, 0, 0, d, 0.0])

controls = [0, 0.0, 4, vstart, 0, 'P1', 1., 1., 1., 90., 90., 90., 1., 'P 1']
ok, dmin, cells = G2indx.DoIndexPeaks(peaks, controls, bravais, None, ifX20=True, timeout=240)
print('ok', ok, 'dmin', dmin)
cells.sort(key=lambda c: -c[0])
print(' M20     X20  brav                  a       b       c     alpha    beta   gamma    vol')
for c in cells[:25]:
    print(f'{c[0]:8.2f} {c[1]:4d} {bravaisNames[c[2]]:22s} {c[3]:7.4f} {c[4]:7.4f} {c[5]:7.4f} '
          f'{c[6]:7.3f} {c[7]:7.3f} {c[8]:7.3f} {c[9]:9.2f}')
