"""Final polish: refine all active parameters together to convergence.
Usage: final.py in.gpx tag"""
import sys, os, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import GSASII.GSASIIscriptable as G2sc
from common import W, report, save_prof

src, tag = sys.argv[1], sys.argv[2]
dst = os.path.join(W, tag + '.gpx')
shutil.copy(src, dst)
p = G2sc.G2Project(dst)
h = p.histograms()[0]
sp = h.data['Sample Parameters']
C = p.data['Controls']['data']
C['parmMaxDict'] = {'*:*:Mustrain;i': 30000., '*::AUiso:*': 0.05, '*:*:Size;i': 10.,
                    ':*:SurfRoughA': 1.5, ':*:SurfRoughB': 2.0, ':*:SH/L': 0.05,
                    ':*:U': 600., ':*:W': 300., ':*:X': 20., ':*:V': 50.}
C['parmMinDict'] = {'*:*:Mustrain;i': 200., '*::AUiso:*': 0.001, '*:*:Size;i': 0.004,
                    ':*:SurfRoughA': 0.0, ':*:SurfRoughB': 0.0, ':*:SH/L': 0.0,
                    ':*:U': 0., ':*:W': 0., ':*:X': 0., ':*:V': -600.}
C['max cyc'] = 12
h.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'SH/L'],
                   'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True}})
sp['Shift'][1] = True
sp['SurfRoughA'][1] = sp['SurfRoughB'][1] = True
for ph in p.phases():
    ph.set_refinements({'Cell': True})
    ph.set_HAP_refinements({'Scale': True, 'Size': {'type': 'isotropic', 'refine': True}},
                           histograms=[h.name])
report(p, h, 'start')
for i in range(3):
    C['parmFrozen'] = {}
    p.refine()
    report(p, h, f'cycle {i}')
    print('   rough', [round(sp[k][0], 4) for k in ('SurfRoughA', 'SurfRoughB')])
for ph in p.phases():
    print(' ', ph.name, [(a.label, [round(v, 5) for v in a.coordinates], round(a.ADP, 4))
                         for a in ph.atoms()])
print('mass fracs:', h.ComputeMassFracs())
save_prof(h, tag + '_prof.csv')
p.save()
