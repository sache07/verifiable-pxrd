"""Fit isolated peaks of the raw pattern (Ka1+Ka2 pseudo-Voigt doublet, linear background)
to measure FWHM vs 2theta."""
import numpy as np
from scipy.optimize import curve_fit

lam1, lam2, rat = 1.540598, 1.544426, 0.5
def ka2(pos):
    return 2*np.degrees(np.arcsin(lam2/lam1*np.sin(np.radians(pos/2))))
def pv(x, pos, fwhm, eta):
    g = np.exp(-4*np.log(2)*((x-pos)/fwhm)**2)*2*np.sqrt(np.log(2)/np.pi)/fwhm
    l = (2/(np.pi*fwhm))/(1+4*((x-pos)/fwhm)**2)
    return eta*l + (1-eta)*g

d = np.loadtxt('inputs/pattern.csv', delimiter=',', skiprows=1)
x, y = d[:, 0], d[:, 1]
peaks = [27.70, 29.91, 33.06, 45.03, 47.28, 51.49, 55.54, 56.82, 68.91, 72.27, 75.66, 81.08, 85.98, 94.03]
hw = {27.70: 0.9, 29.91: 0.45}
print(' pos_fit   fwhm    eta    tan(th)   area')
for p0 in peaks:
    w = hw.get(p0, 0.8)
    m = (x > p0-w) & (x < p0+w)
    xs, ys = x[m], y[m]
    def model(xx, A, pos, fw, eta, b0, b1):
        return b0 + b1*(xx-p0) + A*(pv(xx, pos, fw, eta) + rat*pv(xx, ka2(pos), fw, eta))
    try:
        po, _ = curve_fit(model, xs, ys, p0=[ys.max()*0.1, p0, 0.15, 0.5, ys.min(), 0],
                          bounds=([0, p0-0.3, 0.02, 0, 0, -np.inf], [np.inf, p0+0.3, 1.0, 1, np.inf, np.inf]),
                          maxfev=40000)
    except Exception as e:
        print(p0, 'fail', e); continue
    A, pos, fw, eta, b0, b1 = po
    print(f'{pos:8.3f} {fw:7.4f} {eta:6.3f} {np.tan(np.radians(pos/2)):8.4f} {A:9.1f}')
