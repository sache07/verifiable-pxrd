import sys, numpy as np
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator

c = XRDCalculator(wavelength=1.540598)
for f in sys.argv[1:]:
    s = Structure.from_file(f)
    p = c.get_pattern(s, two_theta_range=(10, 60))
    print('===', f, s.composition.reduced_formula, s.lattice.abc, s.lattice.angles)
    idx = np.argsort(p.y)[::-1][:18]
    for i in sorted(idx):
        hkl = p.hkls[i][0]['hkl']
        print(f'  {p.x[i]:7.3f} {p.y[i]:6.1f} {hkl}')
