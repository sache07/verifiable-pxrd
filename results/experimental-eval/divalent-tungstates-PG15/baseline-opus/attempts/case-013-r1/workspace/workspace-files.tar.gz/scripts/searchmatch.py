"""Search-match candidate CIFs against a residual (obs-calc) profile.

score = intensity-weighted fraction of the candidate's calculated peaks that fall on
positive residual intensity, after applying the known sample-displacement shift.
"""
import json, sys, os, warnings
import numpy as np
warnings.filterwarnings('ignore')
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from scipy.ndimage import uniform_filter1d, maximum_filter1d
from multiprocessing import Pool

prof = sys.argv[1]
cands = json.load(open(sys.argv[2]))
SHIFT = float(sys.argv[3]) if len(sys.argv) > 3 else -446.49

d = np.genfromtxt(prof, delimiter=',', names=True)
x, r = d['x'], d['yobs'] - d['ycalc']
r = uniform_filter1d(r, 7)
# normalise residual: positive part, scaled by local noise
noise = np.sqrt(np.maximum(uniform_filter1d(d['yobs'], 31), 1))
f = np.clip(r/(6*noise), 0, None)
f = np.clip(f/np.percentile(f[f > 0], 99.5), 0, 1.2)
fmax = maximum_filter1d(f, 9)   # allow +-0.05 deg tolerance

const = 9.e-2/(np.pi*200.0)

def shift_pos(t):
    return t - const*4*SHIFT*np.cos(np.radians(t/2))

calc = XRDCalculator(wavelength=1.540598)

def work(e):
    try:
        s = Structure.from_file(e['file'])
        if len(s) > 200:
            return None
        p = calc.get_pattern(s, two_theta_range=(24, 70))
    except Exception:
        return None
    px, py = np.array(p.x), np.array(p.y)
    if len(px) == 0 or py.max() <= 0:
        return None
    pz = shift_pos(px)
    k = (pz > x.min()) & (pz < x.max()) & (py > 0.5)
    px, py, pz = px[k], py[k], pz[k]
    if len(px) < 3:
        return None
    val = np.interp(pz, x, fmax)
    sc = float(np.sum(py*val)/np.sum(py))
    # fraction of intensity on essentially-zero residual
    miss = float(np.sum(py[val < 0.03])/np.sum(py))
    return (sc, miss, len(px), e['file'], e['formula'], e['mineral'])

if __name__ == '__main__':
    with Pool(2) as pool:
        res = [v for v in pool.map(work, cands, chunksize=20) if v]
    res.sort(key=lambda v: -v[0])
    for v in res[:40]:
        print(f'score={v[0]:.3f} miss={v[1]:.3f} nl={v[2]:3d} {v[4]:28s} {v[5]:14s} {os.path.basename(v[3])}')
    json.dump(res[:300], open(sys.argv[2].replace('.json', '_scored.json'), 'w'))
