import numpy as np, sys
from scipy.signal import find_peaks
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
d = np.genfromtxt(sys.argv[1], delimiter=',', names=True)
x, yo, yc = d['x'], d['yobs'], d['ycalc']
r = yo - yc
sig = np.sqrt(np.maximum(yo, 1))
pk, pr = find_peaks(r, height=4*np.median(sig), prominence=120, distance=6)
print('resid peaks (2theta, height, height/sigma):')
for i in pk:
    print(f'  {x[i]:8.3f} {r[i]:8.1f} {r[i]/sig[i]:6.1f}')
n = 3
fig, axs = plt.subplots(n, 1, figsize=(19, 3.4*n))
edges = np.linspace(x.min(), x.max(), n+1)
for i, ax in enumerate(axs):
    m = (x >= edges[i]) & (x <= edges[i+1])
    ax.plot(x[m], r[m], 'b-', lw=0.8)
    ax.plot(x[m], 3*sig[m], 'g-', lw=0.5)
    for j in pk:
        if m[np.searchsorted(x, x[j])]:
            ax.annotate(f'{x[j]:.2f}', (x[j], r[j]), fontsize=7, rotation=90)
    ax.grid(alpha=.3); ax.set_xticks(np.arange(np.round(edges[i]), edges[i+1], 1)); ax.set_xlim(edges[i], edges[i+1])
plt.tight_layout(); plt.savefig(sys.argv[2], dpi=100)
