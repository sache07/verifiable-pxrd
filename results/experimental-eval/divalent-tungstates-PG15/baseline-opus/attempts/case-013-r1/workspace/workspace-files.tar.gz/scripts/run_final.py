"""Complete staged Rietveld refinement of the 5-phase model, producing the submitted project.

Model: PbWO4 (stolzite) + WO3 (monoclinic) + alpha-PbO (litharge) + beta-PbO (massicot)
       + Pb2WO5 (Pb2MoO5 structure type).
Peak shape: Gaussian Caglioti (U,V,W, shared instrumental+strain) + per-phase Lorentzian
       crystallite-size broadening; Suortti surface roughness; sample-displacement shift.
Usage: run_final.py tag
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

tag = sys.argv[1]
names = sys.argv[2].split(',') if len(sys.argv) > 2 else \
    ['stolzite', 'WO3', 'litharge', 'massicot', 'Pb2WO5']
CIF['Pb2WO5'] = os.path.join(W, 'Pb2WO5_start.cif')
p, h = new_project(tag, names, ncoef=12)
ip = h.data['Instrument Parameters'][0]
for k, v in (('U', 5.), ('V', -5.), ('W', 50.), ('X', 1.), ('Y', 0.), ('SH/L', 0.002),
             ('Polariz.', 0.5)):
    ip[k][1] = v
sp = h.data['Sample Parameters']
sp['Shift'][0] = -445.
for ph in p.phases():
    ph.data['Histograms'][h.name]['Mustrain'][1][0] = 500.
    ph.data['Histograms'][h.name]['Size'][1][0] = 1.0
    for at in ph.atoms():
        at.data[at.cia] = 'I'
        at.ADP = 0.018 if at.element == 'O' else 0.011
for nm in ('litharge', 'massicot'):
    if nm in names:
        p.phase(nm).data['Histograms'][h.name]['Size'][1][0] = 0.015

C = p.data['Controls']['data']
C['parmMaxDict'] = {'*:*:Mustrain;i': 30000., '*::AUiso:*': 0.05, '*:*:Size;i': 10.,
                    ':*:SurfRoughA': 1.5, ':*:SurfRoughB': 2.0, ':*:SH/L': 0.05,
                    ':*:U': 600., ':*:W': 300., ':*:X': 20., ':*:V': 50.}
C['parmMinDict'] = {'*:*:Mustrain;i': 200., '*::AUiso:*': 0.001, '*:*:Size;i': 0.004,
                    ':*:SurfRoughA': 0.0, ':*:SurfRoughB': 0.0, ':*:SH/L': 0.0,
                    ':*:U': 0., ':*:W': 0., ':*:X': 0., ':*:V': -600.}

def refine(msg):
    C['parmFrozen'] = {}
    p.refine()
    report(p, h, msg)
    print('   rough', [round(sp[k][0], 4) for k in ('SurfRoughA', 'SurfRoughB')])

refine('1 background + phase fractions')
sp['Shift'][1] = True
refine('2 + sample displacement')
for ph in p.phases():
    ph.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}}, histograms=[h.name])
refine('3 + crystallite size')
for ph in p.phases():
    ph.set_refinements({'Cell': True})
refine('4 + lattice parameters')
sp['SurfRoughA'][0], sp['SurfRoughB'][0] = 0.4, 0.3
sp['SurfRoughA'][1] = sp['SurfRoughB'][1] = True
refine('5 + surface roughness')
h.set_refinements({'Instrument Parameters': ['W']})
refine('6 + profile W')
h.set_refinements({'Instrument Parameters': ['U', 'V', 'W']})
refine('7 + profile U,V,W')
if 'Pb2WO5' in names:
    p.phase('Pb2WO5').set_refinements({'Atoms': {'Pb1': 'X', 'Pb2': 'X', 'W1': 'X'}})
p.phase('stolzite').set_refinements({'Atoms': {'O': 'X'}})
refine('8 + coordinates')
for i in range(2):
    refine(f'9 converge {i}')
for ph in p.phases():
    print(' ', ph.name, ph.data['General']['Formula'] if 'Formula' in ph.data['General'] else '',
          [(a.label, [round(v, 5) for v in a.coordinates], round(a.ADP, 4)) for a in ph.atoms()])
print('mass fracs:', h.ComputeMassFracs())
save_prof(h, tag + '_prof.csv')
p.save()
