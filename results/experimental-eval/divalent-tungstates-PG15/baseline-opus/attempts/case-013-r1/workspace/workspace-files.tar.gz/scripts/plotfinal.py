import numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
d = np.genfromtxt('out/fit.csv', delimiter=',', names=True)
x, yo, yc, yd = d['two_theta_deg'], d['y_obs'], d['y_calc'], d['y_diff']
n = 3
fig, axs = plt.subplots(n, 1, figsize=(16, 3.6*n))
edges = np.linspace(x.min(), x.max(), n+1)
for i, ax in enumerate(axs):
    m = (x >= edges[i]) & (x <= edges[i+1])
    off = 0.15*yo[m].max()
    ax.plot(x[m], yo[m], 'k-', lw=0.6, label='observed')
    ax.plot(x[m], yc[m], 'r-', lw=0.9, label='calculated')
    ax.plot(x[m], yd[m]-off, 'b-', lw=0.6, label='difference')
    ax.axhline(-off, color='0.6', lw=0.4)
    ax.set_xlim(edges[i], edges[i+1]); ax.grid(alpha=.25)
    ax.set_xticks(np.arange(np.round(edges[i]), edges[i+1], 2))
    ax.set_ylabel('counts')
    if i == 0:
        ax.legend(fontsize=9)
        ax.set_title('PbO + WO3, 500 C: 5-phase Rietveld fit (Cu Ka1+Ka2), Rwp = 10.60%')
axs[-1].set_xlabel('2theta (deg)')
plt.tight_layout(); plt.savefig('out/fit_plot.png', dpi=120)
print('saved out/fit_plot.png')
