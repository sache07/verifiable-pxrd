import sys, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
f = sys.argv[1]; out = sys.argv[2]
rngs = [tuple(float(v) for v in s.split('-')) for s in sys.argv[3:]]
d = np.genfromtxt(f, delimiter=',', names=True)
x = d[d.dtype.names[0]]
n = len(rngs)
fig, axs = plt.subplots(1, n, figsize=(5*n, 4))
if n == 1: axs = [axs]
for (lo, hi), ax in zip(rngs, axs):
    m = (x >= lo) & (x <= hi)
    ax.plot(x[m], d['obs'][m], 'b.', ms=3)
    ax.plot(x[m], d['calc'][m], 'g-', lw=1)
    ax.plot(x[m], d['diff'][m] - 0.2*d['obs'][m].max(), 'r-', lw=0.7)
    ax.set_title(f'{lo}-{hi}')
plt.tight_layout(); plt.savefig(out, dpi=110); print(out)
