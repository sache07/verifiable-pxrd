import sys, numpy as np
d = np.genfromtxt(sys.argv[1], delimiter=',', names=True)
x = d[d.dtype.names[0]]; yo = d['obs']; yc = d['calc']; r = yo-yc
k = np.ones(7)/7
rs = np.convolve(r, k, mode='same')
sig = np.sqrt(np.maximum(yo,1))
lam = 1.540598
pk=[]
for i in range(3,len(rs)-3):
    if rs[i]>=rs[i-1] and rs[i]>rs[i+1] and rs[i] > 4*sig[i] and rs[i] > 0.02*rs.max():
        pk.append((x[i], rs[i]))
# merge close
merged=[]
for t,I in pk:
    if merged and t-merged[-1][0] < 0.12:
        if I>merged[-1][1]: merged[-1]=[t,I]
    else: merged.append([t,I])
print("resid peaks", len(merged), " max", rs.max())
for t,I in merged:
    print(f"{t:8.3f} {lam/2/np.sin(np.radians(t/2)):8.4f} {100*I/rs.max():7.1f}")
