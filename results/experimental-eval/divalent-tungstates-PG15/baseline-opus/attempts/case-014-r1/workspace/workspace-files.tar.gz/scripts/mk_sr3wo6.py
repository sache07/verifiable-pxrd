import sys, warnings
warnings.filterwarnings('ignore')
from pymatgen.core import Structure
COD = '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif'
sc = float(sys.argv[1])
out = sys.argv[2]
s = Structure.from_file(COD + '/1/56/30/1563081.cif')
s.replace_species({'Ca': 'Sr'})
s.scale_lattice(s.volume*sc**3)
s.to(filename=out, fmt='cif')
print(s.lattice)
