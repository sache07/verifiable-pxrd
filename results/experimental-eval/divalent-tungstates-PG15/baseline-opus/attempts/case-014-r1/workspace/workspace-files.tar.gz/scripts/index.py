import os, sys, numpy as np
os.environ.setdefault('MPLBACKEND','Agg')
from GSASII import GSASIIindex as G2indx

lam = 1.540598
rows = [
    (5.44541, 148), (4.08499, 335), (3.03757, 1503), (2.92447, 519),
    (2.77458, 713), (2.65689, 161), (2.56629, 190), (2.32504, 183),
    (2.04373, 527), (1.72411, 249), (1.51942, 279), (1.40064, 232),
    (1.22113, 145)]
drop = set(int(a) for a in sys.argv[1:])
peaks = []
for i, (d, I) in enumerate(rows):
    if i in drop:
        continue
    tt = 2*np.degrees(np.arcsin(lam/(2*d)))
    peaks.append([tt, I, True, False, 0, 0, 0, d, 0.0])
controls = [0, 0.0, 4, 25.0, 0, 0, 0, 0, 0]
bravais = [1]*18
ok, dmin, cells, symm, aglme = G2indx.DoIndexPeaks(peaks, controls, bravais, None, ifX20=True, timeout=240)
print('ok', ok)
cells.sort(key=lambda c: -c[0])
print(' M20    X20 Nc  ibrav      a        b        c      alpha    beta    gamma     vol')
for c in cells[:25]:
    print(f"{c[0]:7.2f} {c[1]:5d} {c[2]:3d} {c[3]:3d}  " + ' '.join(f"{v:8.4f}" for v in c[4:11]))
