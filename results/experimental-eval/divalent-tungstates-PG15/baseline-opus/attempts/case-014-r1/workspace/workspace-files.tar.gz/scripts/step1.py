import os, sys
os.environ.setdefault('MPLBACKEND','Agg')
from GSASII import GSASIIscriptable as G2sc

WD = '<ATTEMPT_WORKSPACE>'
COD = '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif'

gpx = G2sc.G2Project(newgpx=os.path.join(WD,'work','s1.gpx'))
h = gpx.add_powder_histogram(os.path.join(WD,'work','pattern.xye'),
                             os.path.join(WD,'work','cu.instprm'),
                             fmthint='Topas xye')
ph = gpx.add_phase(os.path.join(COD,'1/54/60/1546036.cif'), phasename='SrWO4', histograms=[h])
h.set_refinements({'Background': {'type':'chebyschev-1','no. coeffs':8,'refine':True},
                   'Limits':[10.0,100.0]})
gpx.do_refinements([{}])
print('wR after bkg', h.residuals['wR'])
gpx.set_refinement({'set':{'Cell':True}})
gpx.do_refinements([{}])
print('wR cell', h.residuals['wR'])
h.set_refinements({'Instrument Parameters':['Zero']})
h.set_refinements({'Sample Parameters':['Shift','Scale']})
gpx.do_refinements([{}])
print('wR zero/shift', h.residuals['wR'])
h.set_refinements({'Instrument Parameters':['U','V','W','X','Y']})
gpx.do_refinements([{}])
print('wR prof', h.residuals['wR'])
print(ph.get_cell())
print('Zero', h.data['Instrument Parameters'][0]['Zero'], 'Shift', h.data['Sample Parameters']['Shift'])
gpx.save()
