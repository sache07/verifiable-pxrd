import os, sys, numpy as np
os.environ.setdefault('MPLBACKEND','Agg')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from GSASII import GSASIIscriptable as G2sc
from common import WD, COD, dump, report

cif3 = sys.argv[1]
name3 = sys.argv[2]
tag = sys.argv[3]

gpx = G2sc.G2Project(newgpx=os.path.join(WD, 'work', f't3_{tag}.gpx'))
h = gpx.add_powder_histogram(os.path.join(WD,'work','pattern.xye'),
                             os.path.join(WD,'work','cu2.instprm'), fmthint='Topas xye')
ip = h.data['Instrument Parameters'][0]
for k, v in [('U',0.0),('V',0.0),('W',72.0),('X',4.0),('Y',0.0),('SH/L',0.002)]:
    ip[k][1] = v
p1 = gpx.add_phase(os.path.join(COD,'1/54/60/1546036.cif'), phasename='SrWO4', histograms=[h])
p2 = gpx.add_phase(os.path.join(COD,'1/52/89/1528915.cif'), phasename='WO3', histograms=[h])
p3 = gpx.add_phase(cif3, phasename=name3, histograms=[h])
phases = [p1, p2, p3]
p1.data['General']['Cell'][1:4] = [5.41939, 5.41939, 11.96194]
h.data['Sample Parameters']['Shift'] = [-605.0, False]
h.set_refinements({'Background': {'type':'chebyschev-1','no. coeffs':14,'refine':True},
                   'Limits':[10.0,100.0]})
h.set_refinements({'Sample Parameters':['Scale']})
for ph in phases:
    ph.set_HAP_refinements({'Scale':True}, histograms=[h])
gpx.do_refinements([{}]); report(gpx,h,phases)
gpx.set_refinement({'set':{'Cell':True}})
gpx.do_refinements([{}]); report(gpx,h,phases)
gpx.do_refinements([{}]); report(gpx,h,phases)
gpx.save()
dump(h, os.path.join(WD,'work',f'diff_t3_{tag}.csv'))
