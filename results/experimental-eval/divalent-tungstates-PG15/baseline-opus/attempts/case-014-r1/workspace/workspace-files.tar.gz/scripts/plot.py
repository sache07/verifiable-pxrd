import sys, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
f = sys.argv[1]; out = sys.argv[2]
d = np.genfromtxt(f, delimiter=',', names=True)
x = d['2th'] if '2th' in d.dtype.names else d[d.dtype.names[0]]
yo, yc, diff = d['obs'], d['calc'], d['diff']
n = 4
fig, axs = plt.subplots(n, 1, figsize=(16, 3.0*n))
edges = np.linspace(x.min(), x.max(), n+1)
for i, ax in enumerate(axs):
    m = (x >= edges[i]) & (x <= edges[i+1])
    ax.plot(x[m], yo[m], 'b.', ms=2, label='obs')
    ax.plot(x[m], yc[m], 'g-', lw=0.8, label='calc')
    off = -0.15*yo[m].max()
    ax.plot(x[m], diff[m]+off, 'r-', lw=0.6, label='diff')
    ax.axhline(off, color='k', lw=0.3)
    ax.set_xlim(edges[i], edges[i+1])
    if i == 0: ax.legend(fontsize=7)
plt.tight_layout(); plt.savefig(out, dpi=110)
print(out)
