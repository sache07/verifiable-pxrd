import sys, json
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator
c = XRDCalculator(wavelength=1.540598)
for p in sys.argv[1:]:
    try:
        s = Structure.from_file(p)
    except Exception as e:
        print(p, "FAIL", e); continue
    ps = c.get_pattern(s, two_theta_range=(10, 80))
    print("===", p, s.composition.reduced_formula, s.get_space_group_info())
    idx = sorted(range(len(ps.x)), key=lambda i: -ps.y[i])[:18]
    for i in sorted(idx):
        print(f"  {ps.x[i]:8.3f} {ps.y[i]:7.1f} {ps.hkls[i][0]['hkl']}")
