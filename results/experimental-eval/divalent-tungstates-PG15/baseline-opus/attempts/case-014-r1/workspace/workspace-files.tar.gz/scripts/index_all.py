import os, re, sys, json
root = sys.argv[1]
pat = re.compile(r"([A-Z][a-z]?)([0-9.]*)")
out = []
for dp, dn, fn in os.walk(root):
    for f in fn:
        if not f.endswith('.cif'): continue
        p = os.path.join(dp, f)
        txt = open(p, errors='ignore').read()
        m = re.search(r"_chemical_formula_sum\s*\n?\s*'([^']*)'", txt) or \
            re.search(r'_chemical_formula_sum\s*\n?\s*"([^"]*)"', txt)
        if not m: continue
        formula = m.group(1)
        els = set(e for e, n in pat.findall(formula) if e)
        out.append([p, formula, sorted(els)])
json.dump(out, open(sys.argv[2], 'w'))
print(len(out))
sel = [o for o in out if ('W' in o[2] or 'Sr' in o[2])]
print('W/Sr containing:', len(sel))
