import os, sys, numpy as np
os.environ.setdefault('MPLBACKEND','Agg')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from GSASII import GSASIIscriptable as G2sc
from common import WD, COD, dump, report

gpx = G2sc.G2Project(newgpx=os.path.join(WD,'work','s4.gpx'))
h = gpx.add_powder_histogram(os.path.join(WD,'work','pattern.xye'),
                             os.path.join(WD,'work','cu.instprm'),
                             fmthint='Topas xye')
p1 = gpx.add_phase(os.path.join(COD,'1/54/60/1546036.cif'), phasename='SrWO4', histograms=[h])
p2 = gpx.add_phase(os.path.join(COD,'1/52/89/1528915.cif'), phasename='WO3', histograms=[h])
phases = [p1,p2]
hid = list(p1.data['Histograms'])[0]
h.data['Sample Parameters']['Shift'] = [-330.0, True]
h.set_refinements({'Background': {'type':'chebyschev-1','no. coeffs':12,'refine':True},
                   'Limits':[10.0,100.0]})
h.set_refinements({'Sample Parameters':['Scale']})
for ph in phases:
    ph.set_HAP_refinements({'Scale':True}, histograms=[h])
gpx.do_refinements([{}]); report(gpx,h,phases)
gpx.set_refinement({'set':{'Cell':True}})
gpx.do_refinements([{}]); report(gpx,h,phases)
# sample broadening (isotropic size + microstrain) in place of unphysical inst terms
for ph in phases:
    hap = ph.data['Histograms'][hid]
    hap['Size'][1][0] = 0.6
    hap['Mustrain'][1][0] = 800.
    ph.set_HAP_refinements({'Size':{'type':'isotropic','refine':True},
                            'Mustrain':{'type':'isotropic','refine':True}}, histograms=[h])
gpx.do_refinements([{}]); report(gpx,h,phases)
h.set_refinements({'Instrument Parameters':['SH/L','Zero']})
gpx.do_refinements([{}]); report(gpx,h,phases)
gpx.save()
dump(h, os.path.join(WD,'work','diff_s4.csv'))
