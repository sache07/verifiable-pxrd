"""Definitive refinement + all deliverables."""
import os, sys, json, shutil, numpy as np
os.environ.setdefault('MPLBACKEND', 'Agg')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from GSASII import GSASIIscriptable as G2sc
from common import WD, COD, dump, report

OUT = WD
gpxf = os.path.join(OUT, 'final.gpx')
for f in (gpxf, os.path.join(OUT, 'final.bak0.gpx'), os.path.join(OUT, 'final.lst')):
    if os.path.exists(f):
        os.remove(f)

UNK = [16.61, 22.08, 29.73, 30.88, 32.57, 39.01, 44.61, 53.40,
       56.93, 61.19, 67.00, 78.51]

gpx = G2sc.G2Project(newgpx=gpxf)
h = gpx.add_powder_histogram(os.path.join(WD, 'work', 'pattern.xye'),
                             os.path.join(WD, 'work', 'cu2.instprm'),
                             fmthint='Topas xye')
ip = h.data['Instrument Parameters'][0]
for k, v in [('U', 0.0), ('V', 0.0), ('W', 72.0), ('X', 4.0), ('Y', 0.0), ('SH/L', 0.002)]:
    ip[k][1] = v
p1 = gpx.add_phase(os.path.join(COD, '1/54/60/1546036.cif'), phasename='SrWO4', histograms=[h])
p2 = gpx.add_phase(os.path.join(COD, '1/52/89/1528915.cif'), phasename='WO3', histograms=[h])
phases = [p1, p2]
p1.data['General']['Cell'][1:4] = [5.41939, 5.41939, 11.96194]
U0 = {'Sr': 0.009, 'W': 0.006, 'O': 0.012}
for ph in phases:
    for a in ph.atoms():
        a.uiso = U0[a.element]
h.data['Sample Parameters']['Shift'] = [-605.0, False]
h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 14, 'refine': True},
                   'Limits': [10.0, 100.0]})
h.set_refinements({'Sample Parameters': ['Scale']})
for ph in phases:
    ph.set_HAP_refinements({'Scale': True}, histograms=[h])

log = []


def step(name):
    gpx.do_refinements([{}])
    ws, tot = report(gpx, h, phases)
    log.append((name, h.residuals['wR'], {k: 100*v/tot for k, v in ws.items()}))


step('background + scale + phase fractions')
gpx.set_refinement({'set': {'Cell': True}})
step('lattice parameters')
h.set_refinements({'Instrument Parameters': ['W', 'X']})
step('peak widths (W, X)')
for pos in UNK:
    h.add_back_peak(pos, 2000., 70., 5., [0, 1, 1, 0])
step('independent peaks of unidentified phase')
h.set_refinements({'Sample Parameters': ['Shift']})
step('sample displacement')
h.data['Sample Parameters']['SurfRoughA'] = [0.0, True]
h.data['Sample Parameters']['SurfRoughB'] = [0.0, True]
step('surface roughness')
p1.set_refinements({'Atoms': {'O': 'X'}})
step('SrWO4 O coordinates')
p1.set_refinements({'Atoms': {'Sr': 'U', 'W': 'U', 'O': 'U'}})
step('SrWO4 Uiso')
p2.set_refinements({'Atoms': {'W1': 'X', 'W2': 'X'}})
step('WO3 W coordinates')
step('converge')

gpx.save()

# ---------------- outputs -----------------
hid = list(p1.data['Histograms'])[0]
mass = {ph.name: ph.data['General']['Mass'] for ph in phases}
sc = {ph.name: ph.data['Histograms'][hid]['Scale'][0] for ph in phases}
cov = gpx.data['Covariance']['data']
varyList = list(cov['varyList'])
sigv = list(cov['sig'])
sig = {}
for ph, i in zip(phases, range(len(phases))):
    key = f'{i}:0:Scale'
    sig[ph.name] = sigv[varyList.index(key)] if key in varyList else float('nan')
tot = sum(sc[n]*mass[n] for n in sc)
wf = {n: sc[n]*mass[n]/tot for n in sc}
# propagate scale esds (ignoring correlation) to the normalised fractions
wsig = {}
for n in sc:
    dn = (mass[n]/tot)*(1-wf[n])
    wsig[n] = abs(dn*sig[n]) if sig[n] == sig[n] else float('nan')

d = h.data['data'][1]
x, yo, yc, yb = d[0], d[1], d[3], d[4]
np.savetxt(os.path.join(OUT, 'fit.csv'),
           np.c_[x, yo, yc, yo-yc, yb], delimiter=',', fmt='%.6f',
           header='two_theta_deg,y_obs,y_calc,y_diff,y_background', comments='')

cifs = {}
for ph in phases:
    fn = f'{ph.name}.cif'
    ph.export_CIF(os.path.join(OUT, fn), quickmode=True)
    cifs[ph.name] = fn

res = h.residuals
gof = res['wR']/res['wRmin']
info = {
    'Rwp_percent': round(res['wR'], 3),
    'Rp_percent': round(res['R'], 3),
    'Rexp_percent': round(res['wRmin'], 3),
    'GOF': round(gof, 3),
    'chi_squared': round(gof**2, 3),
    'R_Bragg_percent': {ph.name: round(res[f'{i}:0:Rf'], 3) for i, ph in enumerate(phases)},
    'n_points': int(len(x)),
}
out = {
    'phases': [
        {'name': 'SrWO4',
         'formula': 'SrWO4',
         'mineral_structure_type': 'scheelite',
         'space_group': p1.data['General']['SGData']['SpGrp'].strip(),
         'cif': cifs['SrWO4'],
         'lattice': {k: round(v, 5) for k, v in p1.get_cell().items()},
         'weight_fraction': round(wf['SrWO4'], 4),
         'weight_fraction_esd': round(wsig['SrWO4'], 4),
         'weight_percent': round(100*wf['SrWO4'], 2)},
        {'name': 'WO3',
         'formula': 'WO3',
         'mineral_structure_type': 'gamma-WO3 (monoclinic tungsten trioxide)',
         'space_group': p2.data['General']['SGData']['SpGrp'].strip(),
         'cif': cifs['WO3'],
         'lattice': {k: round(v, 5) for k, v in p2.get_cell().items()},
         'weight_fraction': round(wf['WO3'], 4),
         'weight_fraction_esd': round(wsig['WO3'], 4),
         'weight_percent': round(100*wf['WO3'], 2)},
    ],
    'fit_statistics': info,
    'gpx': 'final.gpx',
    'profile': 'fit.csv',
}
json.dump(out, open(os.path.join(OUT, 'result_draft.json'), 'w'), indent=2)

print('\n--- refinement path')
for n, w, f in log:
    print(f'  {n:38s} wR={w:6.3f}  ' + ' '.join(f'{k}={v:.2f}%' for k, v in f.items()))
print('RESID', {k: (round(v, 4) if isinstance(v, float) else v) for k, v in res.items()})
print('WF', wf, 'ESD', wsig, 'scale sig', sig)
print('SAMPLE', {k: h.data['Sample Parameters'][k] for k in ['Scale','Shift','SurfRoughA','SurfRoughB']})
print('INST', {k: round(ip[k][1], 5) for k in ['U','V','W','X','Y','SH/L','Zero']})
for ph in phases:
    print(ph.name, {k: round(v, 5) for k, v in ph.get_cell().items()})
    for a in ph.atoms():
        print('   ', a.label, a.element, [round(v, 5) for v in a.coordinates], round(a.uiso, 5))
bpsum = sum(bp[2] for bp in h.Background[1]['peaksList'])
print('unknown-phase integrated intensity (sum of independent peaks):', round(bpsum))
print('SrWO4 sumInt', round(res['0:0:sumInt']), ' WO3 sumInt', round(res['1:0:sumInt']))

if 'extra' in sys.argv:
    h.set_refinements({'Instrument Parameters': ['Zero']})
    step('zero')
    ip['I(L2)/I(L1)'][2] = True
    step('Ka2 ratio')
    print('I(L2)/I(L1)', ip['I(L2)/I(L1)'])
    print('Zero', ip['Zero'])
    gpx.save()
