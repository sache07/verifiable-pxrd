import os, sys, numpy as np
os.environ.setdefault('MPLBACKEND','Agg')
from GSASII import GSASIIscriptable as G2sc

WD = '<ATTEMPT_WORKSPACE>'
COD = '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif'

gpx = G2sc.G2Project(newgpx=os.path.join(WD,'work','s2.gpx'))
h = gpx.add_powder_histogram(os.path.join(WD,'work','pattern.xye'),
                             os.path.join(WD,'work','cu.instprm'),
                             fmthint='Topas xye')
ph = gpx.add_phase(os.path.join(COD,'1/54/60/1546036.cif'), phasename='SrWO4', histograms=[h])
h.set_refinements({'Background': {'type':'chebyschev-1','no. coeffs':10,'refine':True},
                   'Limits':[10.0,100.0]})
gpx.do_refinements([{}])
gpx.set_refinement({'set':{'Cell':True}})
h.set_refinements({'Sample Parameters':['Shift','Scale']})
gpx.do_refinements([{}])
h.set_refinements({'Instrument Parameters':['U','V','W','X','Y']})
gpx.do_refinements([{}])
print('wR', h.residuals['wR'])
print(ph.get_cell())
print('Shift', h.data['Sample Parameters']['Shift'])
print('inst', {k:h.data['Instrument Parameters'][0][k] for k in ['U','V','W','X','Y','SH/L','Zero']})
gpx.save()

d = h.data['data'][1]
x, yo, yc, yb = d[0], d[1], d[3], d[4]
np.savetxt(os.path.join(WD,'work','diff_s2.csv'), np.c_[x,yo,yc,yb,yo-yc], delimiter=',',
           header='2th,obs,calc,bkg,diff', comments='')
