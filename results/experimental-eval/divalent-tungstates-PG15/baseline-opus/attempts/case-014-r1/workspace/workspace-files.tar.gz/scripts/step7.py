import os, sys, numpy as np
os.environ.setdefault('MPLBACKEND','Agg')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from GSASII import GSASIIscriptable as G2sc
from common import WD, COD, dump, report

gpx = G2sc.G2Project(newgpx=os.path.join(WD,'work','s7.gpx'))
h = gpx.add_powder_histogram(os.path.join(WD,'work','pattern.xye'),
                             os.path.join(WD,'work','cu2.instprm'),
                             fmthint='Topas xye')
ip = h.data['Instrument Parameters'][0]
for k, v in [('U',0.0),('V',0.0),('W',72.0),('X',0.0),('Y',0.0),('SH/L',0.002)]:
    ip[k][1] = v
p1 = gpx.add_phase(os.path.join(COD,'1/54/60/1546036.cif'), phasename='SrWO4', histograms=[h])
p2 = gpx.add_phase(os.path.join(COD,'1/52/89/1528915.cif'), phasename='WO3', histograms=[h])
phases = [p1,p2]
p1.data['General']['Cell'][1:4] = [5.41939, 5.41939, 11.96194]
h.data['Sample Parameters']['Shift'] = [-605.0, False]
h.set_refinements({'Background': {'type':'chebyschev-1','no. coeffs':14,'refine':True},
                   'Limits':[10.0,100.0]})
h.set_refinements({'Sample Parameters':['Scale']})
for ph in phases:
    ph.set_HAP_refinements({'Scale':True}, histograms=[h])
gpx.do_refinements([{}]); report(gpx,h,phases)
gpx.set_refinement({'set':{'Cell':True}})
gpx.do_refinements([{}]); report(gpx,h,phases)
h.set_refinements({'Instrument Parameters':['W','X','Y']})
gpx.do_refinements([{}]); report(gpx,h,phases)
h.set_refinements({'Instrument Parameters':['U','SH/L']})
h.set_refinements({'Sample Parameters':['Shift']})
gpx.do_refinements([{}]); report(gpx,h,phases)
gpx.save()
dump(h, os.path.join(WD,'work','diff_s7.csv'))
# FWHM check
ipd = {k: h.data['Instrument Parameters'][0][k][1] for k in ['U','V','W','X','Y','Z']}
tt = np.arange(12, 100, 8.)
th = np.radians(tt/2)
sig2 = ipd['U']*np.tan(th)**2 + ipd['V']*np.tan(th) + ipd['W']
gam = ipd['X']/np.cos(th) + ipd['Y']*np.tan(th)
print('2th  sig^2   FWHM_G   FWHM_L')
for t, s2, g in zip(tt, sig2, gam):
    print(f'{t:6.1f} {s2:9.2f} {2.3548*np.sqrt(abs(s2))/100:8.4f} {g/100:8.4f}')
