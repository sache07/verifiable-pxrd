import os, sys, time, numpy as np
os.environ.setdefault('MPLBACKEND','Agg')
from GSASII import GSASIIscriptable as G2sc

WD = '<ATTEMPT_WORKSPACE>'
COD = '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif'

gpx = G2sc.G2Project(newgpx=os.path.join(WD,'work','s3.gpx'))
h = gpx.add_powder_histogram(os.path.join(WD,'work','pattern.xye'),
                             os.path.join(WD,'work','cu.instprm'),
                             fmthint='Topas xye')
p1 = gpx.add_phase(os.path.join(COD,'1/54/60/1546036.cif'), phasename='SrWO4', histograms=[h])
p2 = gpx.add_phase(os.path.join(COD,'1/52/89/1528915.cif'), phasename='WO3', histograms=[h])
h.set_refinements({'Background': {'type':'chebyschev-1','no. coeffs':12,'refine':True},
                   'Limits':[10.0,100.0]})
gpx.do_refinements([{}])
for ph in (p1,p2):
    ph.set_HAP_refinements({'Scale':True}, histograms=[h])
h.set_refinements({'Sample Parameters':['Shift']})
gpx.set_refinement({'set':{'Cell':True}})
gpx.do_refinements([{}])
h.set_refinements({'Instrument Parameters':['U','W','X','Y','SH/L']})
gpx.do_refinements([{}])
print('wR', h.residuals['wR'])
for ph in (p1,p2):
    print(ph.name, ph.get_cell())
print('Shift', h.data['Sample Parameters']['Shift'])
print('inst', {k:h.data['Instrument Parameters'][0][k] for k in ['U','V','W','X','Y','SH/L','Zero']})
print('wtFrac', gpx.get_phase_fractions() if hasattr(gpx,'get_phase_fractions') else '')
for ph in (p1,p2):
    print(ph.name, 'HAPscale', ph.data['Histograms'][list(ph.data['Histograms'])[0]]['Scale'])
gpx.save()
d = h.data['data'][1]
np.savetxt(os.path.join(WD,'work','diff_s3.csv'), np.c_[d[0],d[1],d[3],d[4],d[1]-d[3]], delimiter=',',
           header='2th,obs,calc,bkg,diff', comments='')
# reflection positions
for ph in (p1,p2):
    rl = h.reflections()[ph.name]['RefList']
    print('===', ph.name)
    for r in rl[:40]:
        print(f"  {int(r[0])} {int(r[1])} {int(r[2])}  d={r[4]:.4f} pos={r[5]:.3f} Fc2={r[10]:.1f}")
