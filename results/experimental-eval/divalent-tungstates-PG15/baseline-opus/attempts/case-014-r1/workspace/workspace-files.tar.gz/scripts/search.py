"""Score candidate CIFs against a residual profile.

Usage: search.py diff.csv all_cod.json out.txt [shiftA]
Shift model applied to simulated 2theta: 2th_sim_obs = 2th + A*cos(theta)
"""
import sys, json, warnings, numpy as np
warnings.filterwarnings('ignore')
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator

diff_f, idx_f, out_f = sys.argv[1], sys.argv[2], sys.argv[3]
A = float(sys.argv[4]) if len(sys.argv) > 4 else 0.40
els_allowed = set(sys.argv[5].split(',')) if len(sys.argv) > 5 else None

d = np.genfromtxt(diff_f, delimiter=',', names=True)
x = d[d.dtype.names[0]]
res = d['obs'] - d['calc']
sig = np.sqrt(np.maximum(d['obs'], 1))
# positive residual only, in sigma units
rp = np.clip(res, 0, None)

lo, hi = 10.0, 80.0
msk = (x >= lo) & (x <= hi)
xg, rg, sg = x[msk], rp[msk], sig[msk]
step = np.median(np.diff(xg))

cands = json.load(open(idx_f))
cal = XRDCalculator(wavelength=1.540598)
rows = []
for i, (p, formula, els) in enumerate(cands):
    if els_allowed is not None and not set(els) <= els_allowed:
        continue
    try:
        s = Structure.from_file(p)
        ps = cal.get_pattern(s, two_theta_range=(lo, hi - 0.5))
    except Exception:
        continue
    if len(ps.x) == 0:
        continue
    tt = np.array(ps.x) + A*np.cos(np.radians(np.array(ps.x)/2))
    I = np.array(ps.y)
    keep = (tt >= lo) & (tt <= hi)
    tt, I = tt[keep], I[keep]
    if len(I) == 0 or I.max() <= 0:
        continue
    I = I/I.max()
    # for each predicted reflection, measure residual support in a +-0.25 deg window
    sup = []
    for t, inten in zip(tt, I):
        j0 = int((t-0.3-lo)/step); j1 = int((t+0.3-lo)/step)
        j0 = max(j0, 0); j1 = min(j1, len(xg)-1)
        if j1 <= j0: continue
        w = rg[j0:j1+1]
        sup.append((inten, w.max()/max(sg[j0:j1+1].mean(), 1)))
    if not sup: continue
    sup = np.array(sup)
    # weighted mean support, intensity weighted, saturating
    sat = np.clip(sup[:,1]/4.0, 0, 1)
    score = float((sup[:,0]*sat).sum()/sup[:,0].sum())
    nstrong = int((sup[:,0] > 0.2).sum())
    hit = float((sup[sup[:,0] > 0.2][:,1] > 4).mean()) if nstrong else 0.0
    rows.append((score, hit, nstrong, formula, p))

rows.sort(reverse=True)
with open(out_f, 'w') as f:
    for r in rows[:120]:
        f.write(f"{r[0]:.3f} {r[1]:.2f} {r[2]:3d}  {r[3]:40s} {r[4]}\n")
print(len(rows))
for r in rows[:40]:
    print(f"{r[0]:.3f} {r[1]:.2f} {r[2]:3d}  {r[3]:40s} {r[4].split('/')[-1]}")
