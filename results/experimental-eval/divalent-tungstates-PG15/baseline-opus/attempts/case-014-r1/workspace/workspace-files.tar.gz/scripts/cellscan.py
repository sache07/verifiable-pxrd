"""Grid search over simple cells: reward covering the residual peaks, punish
predicted reflections where the residual shows nothing."""
import sys, numpy as np

obs_d = np.array([5.0238, 4.0849, 3.4403, 3.0362, 2.9246, 2.7746, 2.6525, 2.5661,
                  2.3258, 2.1581, 2.0436, 1.8837, 1.8639, 1.8162, 1.7238, 1.6241,
                  1.5201, 1.4009, 1.2603, 1.2208])
obs_w = np.array([138, 111, 48, 801, 176, 216, 114, 62, 149, 39, 165, 109, 52, 50,
                  94, 100, 75, 128, 61, 84], float)
obs_Q = 1/obs_d**2
dmin, dmax = 1.20, 5.10
Qlo, Qhi = 1/dmax**2, 1/dmin**2
tol = 0.004          # relative tolerance in d

sysname = sys.argv[1]
step = float(sys.argv[2]) if len(sys.argv) > 2 else 0.01

HKL = [(h, k, l) for h in range(0, 8) for k in range(0, 8) for l in range(0, 11)
       if (h, k, l) != (0, 0, 0)]


def mk(system):
    if system == 'cubic':
        n = np.array(sorted({h*h+k*k+l*l for h, k, l in HKL}), float)
        return [('a', np.arange(3.0, 13.0, step))], lambda p: np.outer(1/p[0]**2, n)
    if system == 'tet':
        n1 = np.array([h*h+k*k for h, k, l in HKL], float)
        n2 = np.array([l*l for h, k, l in HKL], float)
        return [('a', None), ('c', None)], (n1, n2)
    if system == 'hex':
        n1 = np.array([h*h+h*k+k*k for h in range(-7, 8) for k in range(0, 8)
                       for l in range(0, 11) if (h, k, l) != (0, 0, 0)], float)
        n2 = np.array([l*l for h in range(-7, 8) for k in range(0, 8)
                       for l in range(0, 11) if (h, k, l) != (0, 0, 0)], float)
        return [('a', None), ('c', None)], (n1, n2)
    raise SystemExit('bad system')


def evaluate(Qs):
    """Qs: 1-D array of predicted Q values"""
    Qs = Qs[(Qs >= Qlo) & (Qs <= Qhi)]
    if len(Qs) == 0:
        return -1, 0, 0
    d = 1/np.sqrt(Qs)
    d = np.unique(np.round(d, 5))
    # coverage
    diff = np.abs(obs_d[:, None]/d[None, :] - 1)
    hit = (diff < tol).any(axis=1)
    cover = obs_w[hit].sum()/obs_w.sum()
    # extra predicted lines with nothing observed
    diff2 = np.abs(d[:, None]/obs_d[None, :] - 1)
    extra = (~(diff2 < tol).any(axis=1)).mean()
    return cover - extra, cover, extra


res = []
if sysname == 'cubic':
    n = np.array(sorted({h*h+k*k+l*l for h, k, l in HKL}), float)
    for a in np.arange(3.0, 13.0, step):
        s, c, e = evaluate(n/a**2)
        res.append((s, c, e, (a,)))
else:
    if sysname == 'tet':
        n1 = np.array([h*h+k*k for h, k, l in HKL], float)
        n2 = np.array([l*l for h, k, l in HKL], float)
    else:
        trip = [(h, k, l) for h in range(-7, 8) for k in range(0, 8) for l in range(0, 11)
                if (h, k, l) != (0, 0, 0)]
        n1 = np.array([(h*h+h*k+k*k)*4/3. for h, k, l in trip], float)
        n2 = np.array([l*l for h, k, l in trip], float)
    for a in np.arange(3.0, 13.0, step):
        A = 1/a**2
        for c in np.arange(3.0, 26.0, step*2):
            s, cv, e = evaluate(A*n1 + n2/c**2)
            if s > 0.3:
                res.append((s, cv, e, (a, c)))

res.sort(reverse=True)
print(sysname, 'top solutions')
for r in res[:25]:
    print(f"score={r[0]:6.3f} cover={r[1]:.3f} extra={r[2]:.3f}  " +
          ' '.join(f'{v:7.3f}' for v in r[3]))
