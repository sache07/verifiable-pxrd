import os, sys, numpy as np
os.environ.setdefault('MPLBACKEND','Agg')
from GSASII import GSASIIscriptable as G2sc
gpx = G2sc.G2Project(sys.argv[1])
h = gpx.histograms()[0]
lo = float(sys.argv[2]) if len(sys.argv) > 2 else 10.
hi = float(sys.argv[3]) if len(sys.argv) > 3 else 100.
refs = h.data['Reflection Lists']
for name, blk in refs.items():
    rl = blk['RefList'] if isinstance(blk, dict) else blk
    print('===', name, 'nref', len(rl))
    out = []
    for r in rl:
        if lo <= r[5] <= hi:
            out.append((r[5], int(r[0]), int(r[1]), int(r[2]), r[4], r[9]))
    mx = max([o[5] for o in out]) if out else 1
    for o in sorted(out):
        print(f"  {o[0]:8.3f}  {o[1]:3d}{o[2]:3d}{o[3]:3d}  d={o[4]:.4f}  Irel={100*o[5]/mx:6.1f}")
