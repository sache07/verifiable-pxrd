import os, json, numpy as np
os.environ.setdefault('MPLBACKEND', 'Agg')
from GSASII import GSASIIscriptable as G2sc
from common import WD

gpx = G2sc.G2Project(os.path.join(WD, 'final.gpx'))
h = gpx.histograms()[0]
phases = gpx.phases()
p = {ph.name: ph for ph in phases}
hid = list(phases[0].data['Histograms'])[0]
res = h.residuals
cov = gpx.data['Covariance']['data']
vl, sg = list(cov['varyList']), list(cov['sig'])


def s(key):
    return sg[vl.index(key)] if key in vl else float('nan')


mass = {n: ph.data['General']['Mass'] for n, ph in p.items()}
sc = {n: ph.data['Histograms'][hid]['Scale'][0] for n, ph in p.items()}
tot = sum(sc[n]*mass[n] for n in sc)
wf = {n: sc[n]*mass[n]/tot for n in sc}
scsig = {'SrWO4': s('0:0:Scale'), 'WO3': s('1:0:Scale')}
wsig = {n: abs((mass[n]/tot)*(1-wf[n])*scsig[n]) for n in sc}

cells = {n: ph.get_cell() for n, ph in p.items()}
# lattice esds from the A-matrix sigmas
asig = {'SrWO4': {'a': 0.5*cells['SrWO4']['length_a']**3*s('0::A0'),
                  'c': 0.5*cells['SrWO4']['length_c']**3*s('0::A2')},
        'WO3': {'a': 0.5*cells['WO3']['length_a']**3*s('1::A0'),
                'b': 0.5*cells['WO3']['length_b']**3*s('1::A1'),
                'c': 0.5*cells['WO3']['length_c']**3*s('1::A2')}}

gof = res['wR']/res['wRmin']
out = {
    "sample": {
        "precursors": ["SrCO3", "WO3"],
        "reported_heating_temperature_C": 900.0,
        "modelled_crystalline_phases": 2,
        "additional_crystalline_phases_detected": 1,
        "comment": ("A third crystalline phase is clearly present (strongest line "
                    "d = 3.035 A) but could not be identified; it is modelled with "
                    "independent peaks and is therefore NOT included in the weight "
                    "fractions below. See report.md.")
    },
    "phases": [
        {
            "name": "SrWO4",
            "formula": "SrWO4",
            "structure_type": "scheelite",
            "space_group": "I4_1/a (No. 88)",
            "cif": "SrWO4.cif",
            "lattice_parameters_angstrom_deg": {
                "a": round(cells['SrWO4']['length_a'], 5),
                "a_esd": round(asig['SrWO4']['a'], 5),
                "c": round(cells['SrWO4']['length_c'], 5),
                "c_esd": round(asig['SrWO4']['c'], 5),
                "alpha": 90.0, "beta": 90.0, "gamma": 90.0,
                "volume": round(cells['SrWO4']['volume'], 3)
            },
            "weight_fraction": round(wf['SrWO4'], 4),
            "weight_percent": round(100*wf['SrWO4'], 2),
            "weight_percent_esd_statistical": round(100*wsig['SrWO4'], 2),
            "weight_percent_uncertainty_realistic": 1.5,
            "R_Bragg_F_percent": round(res['0:0:Rf'], 2),
            "n_reflections": int(res['0:0:Nref'])
        },
        {
            "name": "WO3",
            "formula": "WO3",
            "structure_type": "gamma-WO3 (monoclinic tungsten trioxide, unreacted precursor)",
            "space_group": "P2_1/n (No. 14)",
            "cif": "WO3.cif",
            "lattice_parameters_angstrom_deg": {
                "a": round(cells['WO3']['length_a'], 5),
                "a_esd": round(asig['WO3']['a'], 5),
                "b": round(cells['WO3']['length_b'], 5),
                "b_esd": round(asig['WO3']['b'], 5),
                "c": round(cells['WO3']['length_c'], 5),
                "c_esd": round(asig['WO3']['c'], 5),
                "alpha": 90.0,
                "beta": round(cells['WO3']['angle_beta'], 4),
                "gamma": 90.0,
                "volume": round(cells['WO3']['volume'], 3)
            },
            "weight_fraction": round(wf['WO3'], 4),
            "weight_percent": round(100*wf['WO3'], 2),
            "weight_percent_esd_statistical": round(100*wsig['WO3'], 2),
            "weight_percent_uncertainty_realistic": 1.5,
            "R_Bragg_F_percent": round(res['1:0:Rf'], 2),
            "n_reflections": int(res['1:0:Nref'])
        }
    ],
    "unidentified_phase": {
        "status": "detected, not identified - structure and weight fraction not determinable",
        "share_of_total_bragg_intensity_percent": 11.1,
        "strongest_reflections_d_angstrom": [5.440, 4.082, 3.035, 2.923, 2.773,
                                             2.325, 2.043, 1.723, 1.624, 1.520,
                                             1.401, 1.221],
        "relative_intensities_percent": [5, 15, 100, 21, 28, 8, 30, 11, 19, 8, 28, 7],
        "treatment": "modelled as 12 independent pseudo-Voigt peaks on the background"
    },
    "fit_statistics": {
        "Rwp_percent": round(res['wR'], 3),
        "Rp_percent": round(res['R'], 3),
        "Rwp_expected_percent": round(res['wRmin'], 3),
        "goodness_of_fit_S": round(gof, 3),
        "reduced_chi_squared": round(gof**2, 3),
        "R_Bragg_weighted_percent": round(res['wRb'], 3),
        "two_theta_range_deg": [10.0, 100.0],
        "n_data_points": 8282,
        "weighting": "1/sigma^2 with sigma = sqrt(counts) (uncertainties not supplied, Poisson assumed)"
    },
    "files": {
        "gsas2_project": "final.gpx",
        "profile": "fit.csv",
        "report": "report.md"
    }
}
json.dump(out, open(os.path.join(WD, 'result.json'), 'w'), indent=2)
print(json.dumps(out, indent=2))
