"""Rank candidate CIFs by how well they explain the unindexed lines.

Requires: the strongest unindexed line (d=3.0376) must coincide with a
reflection of relative intensity > IMIN, and the candidate's own strong
reflections must all fall on observed peaks.

Usage: dmatch2.py all_cod.json out.txt [tol] [imin]
"""
import sys, json, warnings, numpy as np
warnings.filterwarnings('ignore')
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator

idx_f, out_f = sys.argv[1], sys.argv[2]
tol = float(sys.argv[3]) if len(sys.argv) > 3 else 0.006
imin = float(sys.argv[4]) if len(sys.argv) > 4 else 0.40

unk = np.array([
    [5.4454, 211], [4.0850, 503], [3.0376, 2651], [2.9245, 678],
    [2.7746, 894], [2.6569, 367], [2.5663, 218], [2.3250, 188],
    [2.0437, 770], [1.86858, 127], [1.7241, 319], [1.62299, 352],
    [1.4006, 507], [1.2211, 130], [1.13821, 156], [1.12004, 232],
    [1.05377, 236]])
lam = 1.540598
obs_all = np.array([5.4454, 4.9962, 4.9254, 4.0850, 3.8455, 3.7721, 3.6529, 3.3944,
                    3.2252, 3.2104, 3.11, 3.0854, 3.0376, 2.98954, 2.9245, 2.7746,
                    2.7083, 2.6889, 2.6594, 2.6569, 2.6291, 2.6197, 2.5663, 2.5294,
                    2.5162, 2.3758, 2.3250, 2.3575, 2.1885, 2.1757, 2.1529, 2.0711,
                    2.0437, 2.0080, 1.9236, 1.9154, 1.8826, 1.86858, 1.8250, 1.8006,
                    1.7685, 1.7241, 1.7134, 1.7026, 1.6928, 1.62299, 1.6455, 1.6296,
                    1.6133, 1.6058, 1.5442, 1.5274, 1.51942, 1.4951, 1.4920, 1.4869,
                    1.4730, 1.4708, 1.4416, 1.4006, 1.4065, 1.3965, 1.3928, 1.3814,
                    1.3080, 1.2988, 1.2486, 1.2211, 1.2334, 1.2112, 1.1778, 1.1223,
                    1.13821, 1.12004, 1.0749, 1.05377, 1.0459, 1.0444])

cands = json.load(open(idx_f))
cal = XRDCalculator(wavelength=lam)
rows = []
for n, (p, formula, els) in enumerate(cands):
    try:
        s = Structure.from_file(p)
        ps = cal.get_pattern(s, two_theta_range=(10, 80))
    except Exception:
        continue
    if len(ps.x) == 0:
        continue
    dd = lam/2/np.sin(np.radians(np.array(ps.x)/2))
    I = np.array(ps.y)/max(ps.y)
    m = np.abs(dd/3.0376 - 1) < tol
    if not m.any() or I[m].max() < imin:
        continue
    expl = 0.0
    for d, a in unk:
        mm = np.abs(dd/d - 1) < tol
        if mm.any() and I[mm].max() > 0.05:
            expl += a
    expl /= unk[:, 1].sum()
    bad = tot = 0.0
    for d, i in zip(dd, I):
        if i < 0.15:
            continue
        tot += i
        if not (np.abs(obs_all/d - 1) < tol).any():
            bad += i
    bad = bad/tot if tot else 1.0
    rows.append((expl - bad, expl, bad, formula, p))

rows.sort(reverse=True)
with open(out_f, 'w') as f:
    for r in rows:
        f.write(f"{r[0]:.3f} {r[1]:.3f} {r[2]:.3f}  {r[3]:40s} {r[4]}\n")
print('candidates passing filter:', len(rows))
for r in rows[:40]:
    print(f"{r[0]:6.3f} expl={r[1]:.3f} bad={r[2]:.3f}  {r[3]:36s} {r[4].split('/')[-1]}")
