"""Match candidate CIFs (allowing an isotropic cell scale) to the unindexed lines.

This finds Sr analogues of Ca/Ba/Pb compounds, whose cells differ mainly by an
overall scale factor.
Usage: dmatch3.py all_cod.json out.txt 'A|B|C' 'W|Mo'
"""
import sys, json, warnings, numpy as np
warnings.filterwarnings('ignore')
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator

idx_f, out_f = sys.argv[1], sys.argv[2]
g1 = set(sys.argv[3].split('|')) if len(sys.argv) > 3 else set()
g2 = set(sys.argv[4].split('|')) if len(sys.argv) > 4 else set()

unk_d = np.array([5.0238, 4.0849, 3.4403, 3.0362, 2.9246, 2.7746, 2.6525, 2.5661,
                  2.3258, 2.1581, 2.0436, 1.8837, 1.8639, 1.8162, 1.7238, 1.6241,
                  1.5201, 1.4009])
unk_w = np.array([138, 111, 48, 801, 176, 216, 114, 62, 149, 39, 165, 109, 52, 50,
                  94, 100, 75, 128], float)
lam = 1.540598
tol = 0.005
scales = np.arange(0.88, 1.18, 0.0015)

cands = json.load(open(idx_f))
cal = XRDCalculator(wavelength=lam)
rows = []
for p, formula, els in cands:
    s = set(els)
    if g1 and not (g1 & s):
        continue
    if g2 and not (g2 & s):
        continue
    try:
        st = Structure.from_file(p)
        ps = cal.get_pattern(st, two_theta_range=(10, 85))
    except Exception:
        continue
    if len(ps.x) == 0:
        continue
    d0 = lam/2/np.sin(np.radians(np.array(ps.x)/2))
    I = np.array(ps.y)/max(ps.y)
    keep = I > 0.04
    d0, I = d0[keep], I[keep]
    best = None
    for sc in scales:
        d = d0*sc
        # coverage of unknown lines
        diff = np.abs(unk_d[:, None]/d[None, :] - 1)
        hit = (diff < tol).any(axis=1)
        cover = unk_w[hit].sum()/unk_w.sum()
        # strong predicted lines with nothing observed
        strong = I > 0.25
        if strong.sum() == 0:
            continue
        ds = d[strong]
        miss = (~(np.abs(ds[:, None]/unk_d[None, :] - 1) < tol).any(axis=1))
        bad = (I[strong]*miss).sum()/I[strong].sum()
        sco = cover - bad
        if best is None or sco > best[0]:
            best = (sco, cover, bad, sc)
    if best:
        rows.append(best + (formula, p))

rows.sort(reverse=True)
with open(out_f, 'w') as f:
    for r in rows:
        f.write(f"{r[0]:.3f} {r[1]:.3f} {r[2]:.3f} {r[3]:.4f} {r[4]:40s} {r[5]}\n")
print('n =', len(rows))
for r in rows[:30]:
    print(f"{r[0]:6.3f} cov={r[1]:.3f} bad={r[2]:.3f} scale={r[3]:.3f}  {r[4]:34s} {r[5].split('/')[-1]}")
