"""Final Rietveld refinement: SrWO4 (scheelite) + gamma-WO3.

The unassigned reflections of a third, unidentified minor phase are described
with independent (background) peaks so that they do not bias the two-phase
quantification.  Pass 'nobp' as argv[1] to omit them.
"""
import os, sys, json, numpy as np
os.environ.setdefault('MPLBACKEND', 'Agg')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from GSASII import GSASIIscriptable as G2sc
from common import WD, COD, dump, report

USE_BP = 'nobp' not in sys.argv
tag = 'final' if USE_BP else 'nobp'
gpxf = os.path.join(WD, 'work', tag + '.gpx')
for ext in ('.gpx', '.bak0.gpx', '.lst'):
    f = os.path.join(WD, 'work', tag + ext)
    if os.path.exists(f):
        os.remove(f)

# 2-theta positions (as measured) of reflections that belong to neither
# SrWO4 nor WO3 and are well separated from their reflections
UNKNOWN_PEAKS = [16.61, 22.08, 29.73, 30.88, 32.57, 39.01, 44.61, 53.40,
                 56.93, 61.19, 67.00, 78.51]

gpx = G2sc.G2Project(newgpx=gpxf)
h = gpx.add_powder_histogram(os.path.join(WD, 'work', 'pattern.xye'),
                             os.path.join(WD, 'work', 'cu2.instprm'),
                             fmthint='Topas xye')
ip = h.data['Instrument Parameters'][0]
for k, v in [('U', 0.0), ('V', 0.0), ('W', 72.0), ('X', 4.0), ('Y', 0.0), ('SH/L', 0.002)]:
    ip[k][1] = v
p1 = gpx.add_phase(os.path.join(COD, '1/54/60/1546036.cif'), phasename='SrWO4', histograms=[h])
p2 = gpx.add_phase(os.path.join(COD, '1/52/89/1528915.cif'), phasename='WO3', histograms=[h])
phases = [p1, p2]
p1.data['General']['Cell'][1:4] = [5.41939, 5.41939, 11.96194]
for a in p2.atoms():
    a.uiso = 0.010
h.data['Sample Parameters']['Shift'] = [-605.0, False]
h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 14, 'refine': True},
                   'Limits': [10.0, 100.0]})
h.set_refinements({'Sample Parameters': ['Scale']})
for ph in phases:
    ph.set_HAP_refinements({'Scale': True}, histograms=[h])

steps = []
gpx.do_refinements([{}]); steps.append(('scales+bkg', report(gpx, h, phases)))
gpx.set_refinement({'set': {'Cell': True}})
gpx.do_refinements([{}]); steps.append(('cells', report(gpx, h, phases)))
h.set_refinements({'Instrument Parameters': ['W', 'X']})
gpx.do_refinements([{}]); steps.append(('profile W,X', report(gpx, h, phases)))

if USE_BP:
    for pos in UNKNOWN_PEAKS:
        h.add_back_peak(pos, 2000., 80., 5., [0, 1, 1, 0])
    gpx.do_refinements([{}]); steps.append(('unknown peaks', report(gpx, h, phases)))

h.set_refinements({'Sample Parameters': ['Shift']})
gpx.do_refinements([{}]); steps.append(('shift', report(gpx, h, phases)))
gpx.set_refinement({'set': {'Atoms': {'all': 'U'}}})
gpx.do_refinements([{}]); steps.append(('Uiso', report(gpx, h, phases)))
p1.set_refinements({'Atoms': {'O': 'XU'}})
gpx.do_refinements([{}]); steps.append(('SrWO4 O xyz', report(gpx, h, phases)))
h.set_refinements({'Instrument Parameters': ['SH/L']})
gpx.do_refinements([{}]); steps.append(('SH/L', report(gpx, h, phases)))
gpx.do_refinements([{}]); steps.append(('final', report(gpx, h, phases)))

gpx.save()
dump(h, os.path.join(WD, 'work', f'diff_{tag}.csv'))

ipd = {k: h.data['Instrument Parameters'][0][k][1] for k in ['U', 'V', 'W', 'X', 'Y', 'SH/L', 'Zero']}
print('INST', ipd)
print('RESID', h.residuals)
for ph in phases:
    print(ph.name, ph.get_cell())
    for a in ph.atoms():
        print('   ', a.label, a.element, [round(v, 5) for v in a.coordinates], a.uiso)
if USE_BP:
    print('BKG PEAKS', h.Background[1].get('peaksList'))
