"""Final Rietveld refinement: SrWO4 (scheelite) + gamma-WO3.

Reflections of a third, unidentified minor phase are modelled with independent
peaks ("background peaks") so that they do not bias the two-phase
quantification.  argv: tag  [nobp|few]
"""
import os, sys, json, numpy as np
os.environ.setdefault('MPLBACKEND', 'Agg')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from GSASII import GSASIIscriptable as G2sc
from common import WD, COD, dump, report

tag = sys.argv[1]
mode = sys.argv[2] if len(sys.argv) > 2 else 'all'

ALL_UNK = [16.61, 22.08, 29.73, 30.88, 32.57, 39.01, 44.61, 53.40,
           56.93, 61.19, 67.00, 78.51]
FEW_UNK = [22.08, 29.73, 30.88, 32.57, 39.01, 53.40, 56.93, 61.19]
UNK = {'all': ALL_UNK, 'few': FEW_UNK, 'nobp': []}[mode]

gpxf = os.path.join(WD, 'work', tag + '.gpx')
for ext in ('.gpx', '.bak0.gpx', '.lst'):
    f = os.path.join(WD, 'work', tag + ext)
    if os.path.exists(f):
        os.remove(f)

gpx = G2sc.G2Project(newgpx=gpxf)
h = gpx.add_powder_histogram(os.path.join(WD, 'work', 'pattern.xye'),
                             os.path.join(WD, 'work', 'cu2.instprm'),
                             fmthint='Topas xye')
ip = h.data['Instrument Parameters'][0]
for k, v in [('U', 0.0), ('V', 0.0), ('W', 72.0), ('X', 4.0), ('Y', 0.0), ('SH/L', 0.002)]:
    ip[k][1] = v
p1 = gpx.add_phase(os.path.join(COD, '1/54/60/1546036.cif'), phasename='SrWO4', histograms=[h])
p2 = gpx.add_phase(os.path.join(COD, '1/52/89/1528915.cif'), phasename='WO3', histograms=[h])
phases = [p1, p2]
p1.data['General']['Cell'][1:4] = [5.41939, 5.41939, 11.96194]
U0 = {'Sr': 0.009, 'W': 0.006, 'O': 0.012}
for ph in phases:
    for a in ph.atoms():
        a.uiso = U0[a.element]
h.data['Sample Parameters']['Shift'] = [-605.0, False]
h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 14, 'refine': True},
                   'Limits': [10.0, 100.0]})
h.set_refinements({'Sample Parameters': ['Scale']})
for ph in phases:
    ph.set_HAP_refinements({'Scale': True}, histograms=[h])

log = []


def step(name):
    gpx.do_refinements([{}])
    ws, tot = report(gpx, h, phases)
    log.append((name, h.residuals['wR'], {k: 100*v/tot for k, v in ws.items()}))


step('scales+bkg')
gpx.set_refinement({'set': {'Cell': True}})
step('cells')
h.set_refinements({'Instrument Parameters': ['W', 'X']})
step('profile')
for pos in UNK:
    h.add_back_peak(pos, 2000., 70., 5., [0, 1, 0, 0])
if UNK:
    step('unknown peaks (int)')
    for i in range(len(UNK)):
        h.ref_back_peak(i, [0, 1, 1, 0])
    step('unknown peaks (int+sig)')
h.set_refinements({'Sample Parameters': ['Shift']})
step('shift')
h.data['Sample Parameters']['SurfRoughA'] = [0.0, True]
h.data['Sample Parameters']['SurfRoughB'] = [0.0, True]
step('surface roughness')
p1.set_refinements({'Atoms': {'O': 'X'}})
step('SrWO4 O xyz')
p1.set_refinements({'Atoms': {'Sr': 'U', 'W': 'U', 'O': 'U'}})
step('SrWO4 Uiso')
if 'wo3xyz' in sys.argv:
    p2.set_refinements({'Atoms': {'W1': 'X', 'W2': 'X'}})
    step('WO3 W xyz')
    p2.set_refinements({'Atoms': {'W1': 'U', 'W2': 'U'}})
    step('WO3 W Uiso')
if 'po' in sys.argv:
    p1.set_HAP_refinements({'Pref.Ori.': True}, histograms=[h])
    step('SrWO4 pref. orient.')
step('final')
print('PO', p1.data['Histograms'][list(p1.data['Histograms'])[0]]['Pref.Ori.'])

gpx.save()
dump(h, os.path.join(WD, 'work', f'diff_{tag}.csv'))

print('\n--- refinement path')
for n, w, f in log:
    print(f'  {n:24s} wR={w:6.3f}  ' + ' '.join(f'{k}={v:.2f}%' for k, v in f.items()))
ipd = {k: round(h.data['Instrument Parameters'][0][k][1], 5)
       for k in ['U', 'V', 'W', 'X', 'Y', 'SH/L', 'Zero']}
print('INST', ipd)
print('SAMPLE', {k: h.data['Sample Parameters'][k] for k in
                ['Scale', 'Shift', 'SurfRoughA', 'SurfRoughB']})
print('RESID', {k: (round(v, 4) if isinstance(v, float) else v) for k, v in h.residuals.items()})
for ph in phases:
    print(ph.name, {k: round(v, 5) for k, v in ph.get_cell().items()})
    for a in ph.atoms():
        print('   ', a.label, a.element, [round(v, 5) for v in a.coordinates], round(a.uiso, 5))
if UNK:
    print('BKG PEAKS')
    for bp in h.Background[1]['peaksList']:
        print(f'   pos={bp[0]:7.2f} int={bp[2]:10.0f} sig={bp[4]:8.1f} '
              f'fwhm={2.3548*np.sqrt(abs(bp[4]))/100:.3f}')
