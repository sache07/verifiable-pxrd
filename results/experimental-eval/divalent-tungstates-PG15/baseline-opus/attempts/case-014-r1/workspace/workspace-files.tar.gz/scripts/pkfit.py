import os, sys, numpy as np
os.environ.setdefault('MPLBACKEND','Agg')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from GSASII import GSASIIscriptable as G2sc
from common import WD

gpx = G2sc.G2Project(newgpx=os.path.join(WD,'work','pk.gpx'))
h = gpx.add_powder_histogram(os.path.join(WD,'work','pattern.xye'),
                             os.path.join(WD,'work','cu.instprm'),
                             fmthint='Topas xye')
h.set_refinements({'Background': {'type':'chebyschev-1','no. coeffs':12,'refine':True},
                   'Limits':[10.0,100.0]})
#
pks = [18.33, 22.12, 23.48, 23.97, 24.74, 28.00, 29.75, 30.21, 30.91, 32.60,
       33.39, 34.11, 34.50, 38.22, 41.75, 42.16, 44.65, 45.47, 47.74, 48.60,
       51.98, 53.44, 56.08, 57.36, 61.26, 67.02, 72.99, 76.43, 81.88, 86.87, 95.05]
for p in pks:
    h.add_peak(1, ttheta=p)
h.set_peakFlags(area=True, pos=True)
h.refine_peaks()
h.set_peakFlags(area=True, pos=True, sig=True, gam=True)
r = h.refine_peaks()
print('peak fit Rwp', r[3])
print(' 2th      int      sig      gam   fwhm_est')
rows = []
for pk in h.PeakList:
    pos, intn, sig, gam = pk[0], pk[1], pk[2], pk[3]
    fwg = 2.3548*np.sqrt(max(sig, 0))/100.
    fwl = gam/100.
    fw = (fwg**5 + 2.69269*fwg**4*fwl + 2.42843*fwg**3*fwl**2 + 4.47163*fwg**2*fwl**3
          + 0.07842*fwg*fwl**4 + fwl**5)**0.2
    print(f'{pos:8.3f} {intn:9.1f} {sig:8.2f} {gam:8.2f} {fw:8.4f}')
    rows.append((pos, sig, gam))
np.savetxt(os.path.join(WD,'work','pkwid.csv'), np.array(rows), delimiter=',', header='pos,sig,gam', comments='')
gpx.save()
