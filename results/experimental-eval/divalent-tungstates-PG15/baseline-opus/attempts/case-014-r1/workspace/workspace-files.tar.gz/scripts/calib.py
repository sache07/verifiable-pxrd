import numpy as np
from scipy.optimize import curve_fit, least_squares
lam1, lam2, R = 1.540598, 1.544426, 0.5
d = np.loadtxt('inputs/pattern.csv', delimiter=',', skiprows=1)
X, Y = d[:, 0], d[:, 1]


def k2(x0):
    th = np.radians(x0/2)
    s = np.sin(th)*lam2/lam1
    return np.degrees(2*np.arcsin(min(s, 1.0)))


def pv(x, x0, f, eta):
    g = np.exp(-4*np.log(2)*((x-x0)/f)**2)
    l = 1/(1+4*((x-x0)/f)**2)
    return eta*l + (1-eta)*g


def fit1(p, half=0.45, f0=0.21):
    m = (X > p-half) & (X < p+half)
    x, y = X[m], Y[m]

    def mod(x, x0, f, eta, A, b0, b1):
        return A*(pv(x, x0, f, eta) + R*pv(x, k2(x0), f, eta)) + b0 + b1*(x-x0)
    po, pc = curve_fit(mod, x, y, p0=[p, f0, 0.3, y.max()-y.min(), y.min(), 0],
                       bounds=([p-0.25, 0.05, 0, 0, 0, -1e4], [p+0.25, 0.8, 1, 1e7, 1e5, 1e4]))
    return po[0], po[1], po[3], np.sqrt(np.diag(pc))[0]


# ---- SrWO4 reference peaks (2theta approx, hkl)
ref = [(18.33, (1, 0, 1)), (28.00, (1, 1, 2)), (33.39, (2, 0, 0)), (45.47, (2, 0, 4)),
       (47.74, (2, 2, 0)), (51.98, (1, 1, 6)), (57.36, (2, 2, 4)), (69.60, (4, 0, 0)),
       (72.99, (3, 1, 6)), (79.21, (4, 2, 0))]
obs = []
for p, hkl in ref:
    try:
        x0, f, A, e = fit1(p)
        obs.append((x0, hkl, e))
        print(f"ref {hkl} fit {x0:8.4f} +-{e:.4f} fwhm {f:.4f}")
    except Exception as ex:
        print('fail', p, ex)


def resid(par):
    a, c, D = par
    Z = 0.0
    out = []
    for x0, (h, k, l), e in obs:
        dd = 1/np.sqrt((h*h+k*k)/a**2 + l*l/c**2)
        tt = 2*np.degrees(np.arcsin(lam1/(2*dd)))
        out.append((tt + Z + D*np.cos(np.radians(tt/2)) - x0)/max(e, 1e-3))
    return out


s = least_squares(resid, [5.4168, 11.951, 0.3])
a, c, D = s.x; Z = 0.0
print(f"\nSrWO4 cell a={a:.5f} c={c:.5f}  Zero={Z:.4f} Disp={D:.4f} deg; rms={np.sqrt(np.mean(np.array(resid(s.x))**2)):.2f}")
for x0, (h, k, l), e in obs:
    dd = 1/np.sqrt((h*h+k*k)/a**2 + l*l/c**2)
    tt = 2*np.degrees(np.arcsin(lam1/(2*dd)))
    print(f"  {h}{k}{l} calc {tt:8.4f} +corr {tt+Z+D*np.cos(np.radians(tt/2)):8.4f} obs {x0:8.4f}")


def correct(x0):
    """observed 2theta -> true 2theta (remove Z + D cos(theta))"""
    t = x0
    for _ in range(20):
        t = x0 - Z - D*np.cos(np.radians(t/2))
    return t


print("\n--- unknown peaks")
unk = [16.61, 22.11, 29.75, 30.91, 32.60, 34.14, 35.31, 39.03, 44.65, 53.45,
       61.25, 67.03, 78.53]
print(f"{'fit2th':>9} {'true2th':>9} {'d':>9} {'amp':>9}")
rows = []
for p in unk:
    try:
        x0, f, A, e = fit1(p, half=0.35)
    except Exception as ex:
        print('fail', p, ex); continue
    t = correct(x0)
    dd = lam1/2/np.sin(np.radians(t/2))
    print(f"{x0:9.4f} {t:9.4f} {dd:9.5f} {A:9.0f}")
    rows.append((t, dd, A))
np.savetxt('work/unknown_d.csv', np.array(rows), delimiter=',', header='two_theta,d,amp', comments='')
