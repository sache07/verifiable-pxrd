import os, numpy as np
WD = '<ATTEMPT_WORKSPACE>'
COD = '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif'


def dump(h, path):
    d = h.data['data'][1]
    np.savetxt(path, np.c_[d[0], d[1], d[3], d[4], d[1]-d[3]], delimiter=',',
               header='2th,obs,calc,bkg,diff', comments='')


def report(gpx, h, phases):
    print('wR %.3f  GOF %.3f' % (h.residuals['wR'], h.residuals.get('GOF', float('nan'))))
    hid = list(phases[0].data['Histograms'])[0]
    # weight fractions
    tot = 0.0
    ws = {}
    for ph in phases:
        sc = ph.data['Histograms'][hid]['Scale'][0]
        mass = ph.data['General']['Mass']
        ws[ph.name] = sc*mass
        tot += sc*mass
    for ph in phases:
        c = ph.get_cell()
        print(f"  {ph.name:14s} wt%={100*ws[ph.name]/tot:6.2f}  a={c['length_a']:.5f} b={c['length_b']:.5f} "
              f"c={c['length_c']:.5f} beta={c['angle_beta']:.3f} V={c['volume']:.2f} "
              f"scale={ph.data['Histograms'][hid]['Scale'][0]:.5g}")
    ip = h.data['Instrument Parameters'][0]
    print('  inst', {k: round(ip[k][1], 4) for k in ['U','V','W','X','Y','Z','SH/L','Zero']})
    print('  Shift', round(h.data['Sample Parameters']['Shift'][0], 2),
          ' Scale', h.data['Sample Parameters']['Scale'][0])
    return ws, tot
