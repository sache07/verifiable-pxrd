"""Fit Ka1/Ka2 doublets to the positive residual of a Rietveld fit."""
import sys, numpy as np
from scipy.optimize import curve_fit
lam1, lam2, R = 1.540598, 1.544426, 0.5
f = sys.argv[1]
D = 0.3466      # 2theta = 2theta_true + D*cos(theta)
d = np.genfromtxt(f, delimiter=',', names=True)
X = d[d.dtype.names[0]]
res = d['obs'] - d['calc']
sig = np.sqrt(np.maximum(d['obs'], 1))
sm = np.convolve(res, np.ones(7)/7, mode='same')


def k2(x0):
    s = np.sin(np.radians(x0/2))*lam2/lam1
    return np.degrees(2*np.arcsin(min(s, 1.0)))


def pv(x, x0, fw, eta):
    g = np.exp(-4*np.log(2)*((x-x0)/fw)**2)
    l = 1/(1+4*((x-x0)/fw)**2)
    return eta*l + (1-eta)*g


def mod(x, x0, fw, A, b0, b1):
    return A*(pv(x, x0, fw, 0.3) + R*pv(x, k2(x0), fw, 0.3)) + b0 + b1*(x-x0)


cands = []
for i in range(6, len(sm)-6):
    if sm[i] >= sm[i-1] and sm[i] > sm[i+1] and sm[i] > 4*sig[i]:
        cands.append(i)
merged = []
for i in cands:
    if merged and X[i]-X[merged[-1]] < 0.18:
        if sm[i] > sm[merged[-1]]:
            merged[-1] = i
    else:
        merged.append(i)


def correct(x0):
    t = x0
    for _ in range(20):
        t = x0 - D*np.cos(np.radians(t/2))
    return t


print(f"{'2th_fit':>9} {'d_corr':>9} {'area':>9} {'fwhm':>7} {'hgt':>8}")
rows = []
for i in merged:
    p = X[i]
    m = (X > p-0.35) & (X < p+0.35)
    x, y = X[m], res[m]
    try:
        po, _ = curve_fit(mod, x, y, p0=[p, 0.20, max(y.max(), 1), 0, 0],
                          bounds=([p-0.15, 0.08, 0, -1e4, -1e5], [p+0.15, 0.45, 1e6, 1e4, 1e5]))
    except Exception:
        continue
    if po[2] < 50:
        continue
    t = correct(po[0])
    dd = lam1/2/np.sin(np.radians(t/2))
    area = po[2]*po[1]*1.5
    print(f"{po[0]:9.4f} {dd:9.5f} {area:9.0f} {po[1]:7.3f} {po[2]:8.0f}")
    rows.append((dd, area))
np.savetxt('work/resid_peaks.csv', np.array(rows), delimiter=',', header='d,area', comments='')
