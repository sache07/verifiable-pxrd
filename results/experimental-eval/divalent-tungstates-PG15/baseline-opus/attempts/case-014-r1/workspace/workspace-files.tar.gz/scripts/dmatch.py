"""Match candidate CIFs against a list of unindexed d-spacings.

Usage: dmatch.py all_cod.json out.txt [element_filter]
"""
import sys, json, warnings, numpy as np
warnings.filterwarnings('ignore')
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator

idx_f, out_f = sys.argv[1], sys.argv[2]
flt = set(sys.argv[3].split(',')) if len(sys.argv) > 3 and sys.argv[3] != 'ANY' else None
req = set(sys.argv[4].split('|')) if len(sys.argv) > 4 else set()

# unindexed peaks: corrected d, relative amplitude
unk = np.array([
    [5.44541, 148], [4.08499, 335], [3.03757, 1503], [2.92447, 519],
    [2.77458, 713], [2.65689, 161], [2.56629, 190], [2.32504, 183],
    [2.04373, 527], [1.72411, 249], [1.51942, 279], [1.40064, 232],
    [1.22113, 145]])
# all observed peaks (corrected d) incl. those of SrWO4/WO3 - used to penalise
# predicted strong reflections that have no observed peak at all
lam = 1.540598
obs_all = np.array([5.44541, 4.9254, 4.08499, 3.8455, 3.7721, 3.6529, 3.2252, 3.2104,
                    3.11, 3.0854, 3.03757, 2.98954, 2.92447, 2.77458, 2.7083, 2.6889,
                    2.6594, 2.65689, 2.6291, 2.6197, 2.56629, 2.5294, 2.5162, 2.3758,
                    2.32504, 2.3575, 2.1885, 2.1757, 2.1529, 2.0711, 2.04373, 2.0080,
                    1.9236, 1.9154, 1.8826, 1.8250, 1.8006, 1.7685, 1.72411, 1.7134,
                    1.7026, 1.6928, 1.6455, 1.6296, 1.6133, 1.6058, 1.5442, 1.5274,
                    1.51942, 1.4951, 1.4920, 1.4869, 1.4730, 1.4708, 1.4416, 1.40064,
                    1.4065, 1.3965, 1.3928, 1.3814, 1.3080, 1.2988, 1.2486, 1.22113,
                    1.2334, 1.2112, 1.1778, 1.1223, 1.0749, 1.0459, 1.0444])

cands = json.load(open(idx_f))
cal = XRDCalculator(wavelength=lam)
rows = []
for p, formula, els in cands:
    if flt is not None and not set(els) <= flt:
        continue
    if req and not (req & set(els)):
        continue
    try:
        s = Structure.from_file(p)
        ps = cal.get_pattern(s, two_theta_range=(10, 80))
    except Exception:
        continue
    if len(ps.x) == 0:
        continue
    dd = lam/2/np.sin(np.radians(np.array(ps.x)/2))
    I = np.array(ps.y)/max(ps.y)
    # fraction of unknown-peak weight explained
    expl = 0.0
    for d, a in unk:
        m = np.abs(dd/d - 1) < 0.004
        if m.any() and I[m].max() > 0.05:
            expl += a
    expl /= unk[:, 1].sum()
    # fraction of predicted strong intensity with NO observed peak
    bad = 0.0
    tot = 0.0
    for d, i in zip(dd, I):
        if i < 0.15:
            continue
        tot += i
        if not (np.abs(obs_all/d - 1) < 0.005).any():
            bad += i
    bad = bad/tot if tot else 1.0
    rows.append((expl - bad, expl, bad, formula, p))

rows.sort(reverse=True)
with open(out_f, 'w') as f:
    for r in rows:
        f.write(f"{r[0]:.3f} {r[1]:.3f} {r[2]:.3f}  {r[3]:40s} {r[4]}\n")
print(len(rows))
for r in rows[:30]:
    print(f"{r[0]:6.3f} expl={r[1]:.3f} bad={r[2]:.3f}  {r[3]:36s} {r[4].split('/')[-1]}")
