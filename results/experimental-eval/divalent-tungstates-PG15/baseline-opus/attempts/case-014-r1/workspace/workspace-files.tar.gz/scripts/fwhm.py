import numpy as np
from scipy.optimize import curve_fit
d = np.loadtxt('inputs/pattern.csv', delimiter=',', skiprows=1)
X, Y = d[:, 0], d[:, 1]
lam1, lam2 = 1.540598, 1.544426
R = 0.5

def pv(x, x0, f, eta):
    g = np.exp(-4*np.log(2)*((x-x0)/f)**2)
    l = 1/(1+4*((x-x0)/f)**2)
    return eta*l + (1-eta)*g

def model(x, x0, f, eta, A, b0, b1):
    th = np.radians(x0/2)
    d0 = np.degrees(2*(np.arcsin(min(np.sin(th)*lam2/lam1, 1.0)) - th)) + x0
    return A*(pv(x, x0, f, eta) + R*pv(x, d0, f, eta)) + b0 + b1*(x-x0)

peaks = [(18.33, 0.55), (28.00, 0.6), (30.21, 0.4), (33.39, 0.5), (45.47, 0.6),
         (47.74, 0.6), (51.98, 0.6), (57.36, 0.5), (69.6, 0.7), (72.99, 0.6),
         (79.2, 0.7), (86.87, 0.8), (95.05, 0.9)]
print('  2th_fit    FWHM     eta   tan(th)')
rows = []
for p, w in peaks:
    m = (X > p-w) & (X < p+w)
    x, y = X[m], Y[m]
    try:
        po, _ = curve_fit(model, x, y, p0=[p, 0.2, 0.5, y.max()-y.min(), y.min(), 0],
                          bounds=([p-0.3, 0.03, 0, 0, 0, -1e4], [p+0.3, 1.0, 1, 1e7, 1e5, 1e4]))
    except Exception as e:
        print(p, 'fail', e); continue
    print(f'{po[0]:9.4f} {po[1]:8.4f} {po[2]:7.3f} {np.tan(np.radians(po[0]/2)):8.4f}')
    rows.append((po[0], po[1], po[2]))
rows = np.array(rows)
# fit FWHM^2 = U tan^2 + V tan + W
t = np.tan(np.radians(rows[:, 0]/2))
A = np.c_[t**2, t, np.ones_like(t)]
cf, *_ = np.linalg.lstsq(A, rows[:, 1]**2, rcond=None)
print('Caglioti (deg^2): U=%.5f V=%.5f W=%.5f -> centideg^2: %.2f %.2f %.2f' %
      (cf[0], cf[1], cf[2], cf[0]*1e4, cf[1]*1e4, cf[2]*1e4))
