import numpy as np
from scipy.optimize import least_squares

# observed d, assigned hkl for cell a~5.549 b~7.255 c~10.886
obs = [
    (5.4465, (0, 0, 2)), (4.0849, (1, 1, 1)), (3.4403, (0, 2, 1)),
    (3.0362, (1, 2, 0)), (2.9246, (1, 2, 1)), (2.7746, (2, 0, 0)),
    (2.6525, (1, 2, 2)), (2.5661, (0, 2, 3)), (2.3258, (1, 2, 3)),
    (2.1581, (2, 2, 1)), (1.8837, (2, 2, 3)), (1.8639, (0, 2, 5)),
    (1.8162, (0, 0, 6)), (1.7238, (0, 4, 2)), (1.6241, (0, 4, 3)),
    (1.5201, (2, 4, 0)), (1.4009, (2, 4, 3)), (1.2603, (3, 4, 2)),
    (1.2208, (2, 0, 8)),
]


def res(p):
    a, b, c = p
    out = []
    for d, (h, k, l) in obs:
        dc = 1/np.sqrt(h*h/a**2 + k*k/b**2 + l*l/c**2)
        out.append((dc-d)/d*1000)
    return out


s = least_squares(res, [5.5492, 7.2554, 10.886])
a, b, c = s.x
r = np.array(res(s.x))
print(f'a={a:.4f} b={b:.4f} c={c:.4f}  V={a*b*c:.2f}')
print(f'rms(delta d/d) = {np.sqrt((r**2).mean())/1000*100:.3f} %  max={np.abs(r).max()/1000*100:.3f} %')
print(f"{'d_obs':>8} {'d_calc':>8} {'hkl':>10} {'d/d %':>8}")
for (d, (h, k, l)), e in zip(obs, r):
    dc = 1/np.sqrt(h*h/a**2 + k*k/b**2 + l*l/c**2)
    print(f'{d:8.4f} {dc:8.4f} {h}{k}{l:>7} {e/10:8.3f}')

# full predicted list
print('\nall reflections 1.20-5.6 A for this cell (P lattice):')
lst = []
for h in range(0, 6):
    for k in range(0, 8):
        for l in range(0, 12):
            if h == k == l == 0:
                continue
            dd = 1/np.sqrt(h*h/a**2 + k*k/b**2 + l*l/c**2)
            if 1.20 <= dd <= 5.6:
                lst.append((dd, h, k, l))
lst.sort(reverse=True)
od = np.array([d for d, _ in obs])
for dd, h, k, l in lst:
    m = np.abs(od/dd - 1) < 0.004
    print(f'  {dd:7.4f}  {h}{k}{l}   {"OBS" if m.any() else ""}')
