import os, sys, numpy as np
os.environ.setdefault('MPLBACKEND','Agg')
from GSASII import GSASIIindex as G2indx

lam = 1.540598
rows = [
    (5.0238, 138), (4.0849, 111), (3.4403, 48), (3.0362, 801), (2.9246, 176),
    (2.7746, 216), (2.6525, 114), (2.5661, 62), (2.3258, 149), (2.1581, 39),
    (2.0436, 165), (1.8837, 109), (1.8639, 52), (1.8162, 50), (1.7238, 94),
    (1.6241, 100), (1.5201, 75), (1.4009, 128), (1.2603, 61), (1.2208, 84)]
drop = set(int(a) for a in sys.argv[2:])
peaks = []
for i, (d, I) in enumerate(rows):
    if i in drop:
        continue
    tt = 2*np.degrees(np.arcsin(lam/(2*d)))
    peaks.append([tt, I, True, False, 0, 0, 0, d, 0.0])
controls = [0, 0.0, 4, 25.0, 0, 0, 0, 0, 0]
nb = int(sys.argv[1]) if len(sys.argv) > 1 else 13
bravais = [1]*nb + [0]*(18-nb)
ok, dmin, cells, symm, aglme = G2indx.DoIndexPeaks(peaks, controls, bravais, None,
                                                   ifX20=True, timeout=400)
print('ok', ok)
cells.sort(key=lambda c: -c[0])
print(' M20    X20 Nc  ibrav      a        b        c      alpha    beta    gamma     vol')
for c in cells[:25]:
    print(f"{c[0]:7.2f} {c[1]:5d} {c[2]:3d} {c[3]:3d}  " + ' '.join(f"{v:8.4f}" for v in c[4:11]))
