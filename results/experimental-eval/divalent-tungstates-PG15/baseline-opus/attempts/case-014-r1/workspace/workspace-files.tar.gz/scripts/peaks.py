import numpy as np, sys
d = np.loadtxt(sys.argv[1], delimiter=',', skiprows=1)
x, y = d[:,0], d[:,1]
print("range", x.min(), x.max(), "step", np.median(np.diff(x)), "npts", len(x))
print("Imax", y.max(), "at", x[y.argmax()], "Imin", y.min())
# crude background: rolling min then smooth
from numpy.lib.stride_tricks import sliding_window_view
w = 201
pad = np.pad(y, w//2, mode='edge')
bg = sliding_window_view(pad, w).min(axis=1)
padb = np.pad(bg, w//2, mode='edge')
bg = sliding_window_view(padb, w).mean(axis=1)
yc = y - bg
# smooth
k = np.ones(5)/5
ys = np.convolve(yc, k, mode='same')
thr = 0.01*ys.max()
pk = []
for i in range(2, len(ys)-2):
    if ys[i] >= ys[i-1] and ys[i] > ys[i+1] and ys[i] > thr and ys[i] > 3*np.sqrt(max(bg[i],1)):
        pk.append((x[i], ys[i]))
pk.sort(key=lambda t: -t[1])
print("n peaks", len(pk))
lam = 1.540598
print("  2th      d        Irel")
for t, I in sorted(pk):
    print(f"{t:8.3f} {lam/2/np.sin(np.radians(t/2)):8.4f} {100*I/ys.max():7.1f}")
