import os, re, sys, json
root = sys.argv[1]
allowed = set(['Sr','W','O','C'])
out = []
pat = re.compile(r"([A-Z][a-z]?)([0-9.]*)")
for dp, dn, fn in os.walk(root):
    for f in fn:
        if not f.endswith('.cif'): continue
        p = os.path.join(dp, f)
        try:
            txt = open(p, errors='ignore').read()
        except Exception:
            continue
        m = re.search(r"_chemical_formula_sum\s*\n?\s*'([^']*)'", txt)
        if not m:
            m = re.search(r'_chemical_formula_sum\s*\n?\s*"([^"]*)"', txt)
        if not m: continue
        formula = m.group(1)
        els = set(e for e, n in pat.findall(formula) if e)
        if not els: continue
        if els <= allowed and ("W" in els):
            sg = re.search(r"_symmetry_space_group_name_H-M\s+'?([^'\n]*)'?", txt)
            cell = {}
            for k in ['length_a','length_b','length_c','angle_alpha','angle_beta','angle_gamma']:
                mm = re.search(r"_cell_"+k+r"\s+([0-9.]+)", txt)
                if mm: cell[k] = float(mm.group(1))
            name = re.search(r"_chemical_name_mineral\s+'?([^'\n]*)'?", txt)
            out.append(dict(path=p, formula=formula, sg=(sg.group(1).strip() if sg else ''),
                            cell=cell, mineral=(name.group(1).strip() if name else '')))
json.dump(out, open(sys.argv[2],'w'), indent=1)
print(len(out))
for o in out:
    print(o['formula'], '|', o['sg'], '|', o['cell'].get('length_a'), o['cell'].get('length_b'), o['cell'].get('length_c'), '|', os.path.basename(o['path']))
