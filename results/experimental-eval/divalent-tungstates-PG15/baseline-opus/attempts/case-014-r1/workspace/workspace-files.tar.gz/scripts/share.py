import os, numpy as np
os.environ.setdefault('MPLBACKEND', 'Agg')
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIpwd as G2pwd
from common import WD

gpx = G2sc.G2Project(os.path.join(WD, 'final.gpx'))
h = gpx.histograms()[0]
d = h.data['data'][1]
x, yo, yc, yb = np.array(d[0]), np.array(d[1]), np.array(d[3]), np.array(d[4])
bkg = h.data['Background']
coeffs = bkg[0][3:]
n = len(coeffs)
xmin, xmax = x.min(), x.max()
t = 2.*(x-xmin)/(xmax-xmin) - 1.
poly = np.polynomial.chebyshev.chebval(t, coeffs)
unk = yb - poly
bragg = yc - yb
print('background polynomial terms:', n)
print('check poly range', poly.min(), poly.max(), ' yb range', yb.min(), yb.max())
step = np.median(np.diff(x))
A_bragg = bragg.sum()*step
A_unk = unk.sum()*step
A_tot = (yc - poly).sum()*step
print(f'integrated SrWO4+WO3 Bragg intensity : {A_bragg:12.0f} counts.deg')
print(f'integrated unidentified-phase peaks  : {A_unk:12.0f} counts.deg')
print(f'unidentified share of Bragg intensity: {100*A_unk/A_tot:6.2f} %')
np.savetxt(os.path.join(WD, 'work', 'decomp.csv'),
           np.c_[x, yo, yc, poly, unk, bragg], delimiter=',',
           header='2th,obs,calc,bkg_poly,unknown_peaks,bragg_2phase', comments='')
