import os, sys, numpy as np
os.environ.setdefault('MPLBACKEND','Agg')
from GSASII import GSASIIscriptable as G2sc

gpx = G2sc.G2Project(sys.argv[1])
h = gpx.histograms()[0]
pos = {}
for name, blk in h.data['Reflection Lists'].items():
    rl = blk['RefList'] if isinstance(blk, dict) else blk
    I = np.array([r[9]*r[3] for r in rl])
    mx = I.max() if len(I) else 1
    pos[name] = [(r[5], 100*r[9]*r[3]/mx) for r in rl]

d = np.genfromtxt(sys.argv[2], delimiter=',', names=True)
x = d[d.dtype.names[0]]; r = d['obs']-d['calc']
sig = np.sqrt(np.maximum(d['obs'], 1))
rs = np.convolve(r, np.ones(9)/9, mode='same')
pk = []
for i in range(5, len(rs)-5):
    if rs[i] >= rs[i-1] and rs[i] > rs[i+1] and rs[i] > 5*sig[i]:
        pk.append((x[i], rs[i]))
merged = []
for t, I in pk:
    if merged and t-merged[-1][0] < 0.15:
        if I > merged[-1][1]: merged[-1] = [t, I]
    else:
        merged.append([t, I])
lam = 1.540598
print(f"{'2th':>8} {'d':>8} {'resid':>8}   nearby reflections (<0.12 deg, Irel>1)")
for t, I in merged:
    tags = []
    for name, lst in pos.items():
        for p, ir in lst:
            if abs(p-t) < 0.12 and ir > 1:
                tags.append(f"{name}:{ir:.0f}%@{p:.2f}")
    print(f"{t:8.3f} {lam/2/np.sin(np.radians(t/2)):8.4f} {I:8.0f}   {' '.join(tags[:4])}")
