"""Exhaustive trial-and-error indexing that tolerates missing reflections.

For each crystal system a small number of base lines are assigned trial indices;
the resulting cell is tested against the whole observed Q list.  All observed
lines must be indexed (within tol); a de Wolff-like FoM ranks the solutions.
"""
import sys, itertools, numpy as np

D = np.array([5.4454, 4.0850, 3.0376, 2.9245, 2.7746, 2.6569, 2.5663, 2.3250,
              2.0437, 1.86858, 1.7241, 1.62299, 1.5194])
drop = set(int(a) for a in sys.argv[1:] if a.lstrip('-').isdigit())
D = np.array([d for i, d in enumerate(D) if i not in drop])
Q = 1.0/D**2
tol = 0.0025          # relative tolerance on Q
Qmax = Q.max()
HK = sorted({h*h+k*k for h in range(9) for k in range(9)})
HKhex = sorted({h*h+h*k+k*k for h in range(9) for k in range(-8, 9)})


def score(Qcalc_fun, nposs_fun, name, params):
    """all lines indexed?  -> FoM"""
    errs = []
    for q in Q:
        e = Qcalc_fun(q)
        if e is None:
            return None
        errs.append(e)
    eps = np.mean(np.abs(errs))
    Nposs = nposs_fun()
    if Nposs <= 0:
        return None
    fom = Qmax/(2*eps*Nposs) if eps > 0 else 1e9
    return (fom, name, params, eps, Nposs)


def test_tet(A, C):
    if A <= 0 or C <= 0:
        return None
    vals = np.array(sorted({A*n + C*l*l for n in HK for l in range(0, 13)
                            if 0 < A*n + C*l*l <= Qmax*1.001}))
    if len(vals) == 0:
        return None

    def f(q):
        i = np.argmin(np.abs(vals-q))
        return abs(vals[i]-q) if abs(vals[i]-q)/q < tol else None
    return score(f, lambda: len(vals), 'tet', (1/np.sqrt(A), 1/np.sqrt(C)))


def test_hex(A, C):
    if A <= 0 or C <= 0:
        return None
    vals = np.array(sorted({A*n + C*l*l for n in HKhex for l in range(0, 13)
                            if 0 < A*n + C*l*l <= Qmax*1.001}))
    if len(vals) == 0:
        return None

    def f(q):
        i = np.argmin(np.abs(vals-q))
        return abs(vals[i]-q) if abs(vals[i]-q)/q < tol else None
    return score(f, lambda: len(vals), 'hex', (1/np.sqrt(A*0.75), 1/np.sqrt(C)))


def test_ortho(A, B, C):
    if min(A, B, C) <= 0:
        return None
    vals = np.array(sorted({A*h*h + B*k*k + C*l*l
                            for h in range(0, 9) for k in range(0, 9) for l in range(0, 13)
                            if 0 < A*h*h+B*k*k+C*l*l <= Qmax*1.001}))
    if len(vals) == 0 or len(vals) > 4000:
        return None

    def f(q):
        i = np.argmin(np.abs(vals-q))
        return abs(vals[i]-q) if abs(vals[i]-q)/q < tol else None
    return score(f, lambda: len(vals), 'ortho',
                 (1/np.sqrt(A), 1/np.sqrt(B), 1/np.sqrt(C)))


res = []
# --- cubic
for n1 in HK:
    if n1 == 0:
        continue
    A = Q[0]/n1
    a = 1/np.sqrt(A)
    if not 2.5 < a < 20:
        continue
    vals = np.array(sorted({A*n for n in
                            {h*h+k*k+l*l for h in range(13) for k in range(13) for l in range(13)}
                            if 0 < A*n <= Qmax*1.001}))
    ok = True
    errs = []
    for q in Q:
        i = np.argmin(np.abs(vals-q))
        if abs(vals[i]-q)/q > tol:
            ok = False
            break
        errs.append(abs(vals[i]-q))
    if ok:
        eps = np.mean(errs)
        res.append((Qmax/(2*eps*len(vals)), 'cubic', (a,), eps, len(vals)))

# --- tetragonal / hexagonal: assign indices to two base lines
base = [0, 1, 2, 3, 4]
for i, j in itertools.combinations(base, 2):
    for n1 in HK:
        for l1 in range(0, 7):
            for n2 in HK:
                for l2 in range(0, 7):
                    det = n1*l2*l2 - n2*l1*l1
                    if det == 0:
                        continue
                    A = (Q[i]*l2*l2 - Q[j]*l1*l1)/det
                    C = (n1*Q[j] - n2*Q[i])/det
                    if A <= 1e-6 or C <= 1e-6:
                        continue
                    a, c = 1/np.sqrt(A), 1/np.sqrt(C)
                    if not (2.4 < a < 18 and 2.4 < c < 28):
                        continue
                    r = test_tet(A, C)
                    if r:
                        res.append(r)
    for n1 in HKhex:
        for l1 in range(0, 7):
            for n2 in HKhex:
                for l2 in range(0, 7):
                    det = n1*l2*l2 - n2*l1*l1
                    if det == 0:
                        continue
                    A = (Q[i]*l2*l2 - Q[j]*l1*l1)/det
                    C = (n1*Q[j] - n2*Q[i])/det
                    if A <= 1e-6 or C <= 1e-6:
                        continue
                    a, c = 1/np.sqrt(A*0.75), 1/np.sqrt(C)
                    if not (2.4 < a < 18 and 2.4 < c < 28):
                        continue
                    r = test_hex(A, C)
                    if r:
                        res.append(r)

seen = {}
for r in res:
    key = tuple(round(v, 2) for v in r[2]) + (r[1],)
    if key not in seen or r[0] > seen[key][0]:
        seen[key] = r
out = sorted(seen.values(), key=lambda r: -r[0])
print(f'{len(out)} distinct solutions (all {len(Q)} lines indexed)')
for r in out[:30]:
    pars = ' '.join(f'{v:8.4f}' for v in r[2])
    print(f'FoM={r[0]:8.2f} {r[1]:6s} {pars}  eps={r[3]:.2e} Nposs={r[4]}')
