"""Final Rietveld refinement of the Co3O4 + WO3 (500 C) product pattern.

Phases:  gamma-WO3 (P21/n; Loopstra & Boldrini 1966 coordinates, conventional
         setting) + Co3O4 spinel (Fd-3m, Will et al. 1990).
Profile: instrument Gaussian W (U,V held small), Lorentzian X, axial-divergence
         asymmetry SH/L; per-phase Lorentzian microstrain (isotropic, or
         generalized for a selected phase).  Crystallite size held at 1 um
         (no resolvable size broadening; strongly correlated with X).
Geometry: Bragg-Brentano sample displacement (Shift); Cu Ka1/Ka2, I2/I1 = 0.5.

Options: --anisoP=WO3   generalized (anisotropic) microstrain for that phase
         --size         also refine isotropic size
         --uisogrp      one Uiso per element per phase (equivalence constrained)
         --holdel=W,Co  hold the Uiso of these elements
         --po=WO3:1,0,0 March-Dollase preferred-orientation test
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from refine import build, report

GPX = sys.argv[1] if len(sys.argv) > 1 else 'final.gpx'
ANISOP = sum([a.split('=')[1].split(',') for a in sys.argv if a.startswith('--anisoP=')], [])
SIZE = '--size' in sys.argv
UGRP = '--uisogrp' in sys.argv
PO = [a.split('=')[1] for a in sys.argv if a.startswith('--po=')]
HOLDEL = sum([a.split('=')[1].split(',') for a in sys.argv if a.startswith('--holdel=')], [])
UFIX = {'W': 0.005, 'O': 0.010, 'Co': 0.005}

prj, h, phases = build(GPX, [('WO3', 'wo3_p21n_b.cif'), ('Co3O4', '9005896.cif')])
names = list(phases)
ip = h.data['Instrument Parameters'][0]


def show(tag):
    report(prj, h, phases, tag)
    print('   inst:', {k: round(ip[k][1], 5) for k in ['U', 'V', 'W', 'X', 'Y', 'SH/L']})
    for n, p in phases.items():
        hp = p.data['Histograms'][h.name]
        mu = ([round(v, 1) for v in hp['Mustrain'][4]] if hp['Mustrain'][0] == 'generalized'
              else round(hp['Mustrain'][1][0], 1))
        print(f'    {n:10s} size {hp["Size"][1][0]:8.4f}  mustrain {hp["Mustrain"][0]:12s} {mu}')


for p in phases.values():
    for at in p.atoms():
        if at.adp_flag == 'I':
            at.uiso = UFIX.get(at.element, 0.01)

# --- 1. scale, background, sample displacement, cells -----------------------
h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True},
                   'Sample Parameters': ['Scale']})
for n in names[1:]:
    phases[n].set_HAP_refinements({'Scale': True})
prj.refine()
h.set_refinements({'Sample Parameters': ['Scale', 'Shift']})
prj.refine()
for p in phases.values():
    p.set_refinements({'Cell': True})
prj.refine()
report(prj, h, phases, '1. scale/bkg/shift/cell')

# --- 2. profile ------------------------------------------------------------
ip['U'][1] = 2.0
ip['V'][1] = -2.0
ip['W'][1] = 5.0
ip['X'][1] = 5.0
ip['Y'][1] = 0.0
for p in phases.values():
    hp = p.data['Histograms'][h.name]
    hp['Mustrain'][1][0] = 3000.
    hp['Size'][1][0] = 1.0
    p.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}})
h.set_refinements({'Instrument Parameters': ['W', 'X', 'SH/L']})
prj.refine()
show('2. +inst W,X,SH/L + isotropic microstrain')

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True}})
prj.refine()
prj.refine()
show('3. +bkg(12 terms)')

if SIZE:
    for p in phases.values():
        p.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}})
    prj.refine()
    show('4. +isotropic size')

# --- 5. anisotropic microstrain for selected phases ------------------------
for pname in ANISOP:
    phases[pname].set_HAP_refinements({'Mustrain': {'type': 'generalized', 'refine': True}})
    for k in range(int(os.environ.get('NCYC', '1'))):
        prj.refine()
        show(f'5.{k} +generalized microstrain ({pname})')

# --- 5c. preferred-orientation test ----------------------------------------
for spec in PO:
    pname, hkl = spec.split(':')
    hkl = [int(v) for v in hkl.split(',')]
    hp = phases[pname].data['Histograms'][h.name]
    hp['Pref.Ori.'] = ['MD', 1.0, False, hkl, 0, {}, [], 0.1]
    phases[pname].set_HAP_refinements({'Pref.Ori.': True})
    prj.refine()
    show(f'5c. +March-Dollase {pname} {hkl} = {hp["Pref.Ori."][1]:.4f}')

# --- 6. displacement parameters (one per element per phase) -----------------
if UGRP:
    for pname, p in phases.items():
        groups = {}
        for at in p.atoms():
            groups.setdefault(at.element, []).append(at.label)
        for el, labels in groups.items():
            if len(labels) > 1:
                prj.add_EquivConstr([prj.make_var_obj(phase=pname, varname='AUiso', atomId=lab)
                                     for lab in labels])
        p.set_refinements({'Atoms': {'all': 'U'}})
        for at in p.atoms():
            if at.element in HOLDEL:
                at.refinement_flags = at.refinement_flags.replace('U', '')
    prj.refine()
    show('6. +grouped Uiso')
    for pname, p in phases.items():
        seen = set()
        for at in p.atoms():
            if at.element not in seen:
                seen.add(at.element)
                print(f'    Uiso {pname}/{at.element} = {at.uiso:.5f}')

prj.save()
print('saved', prj.filename)
