"""Export deliverables from the final GSAS-II project:
   <phase>.cif, fit.csv, result.json"""
import json
import os
import re
import sys
import numpy as np
import GSASII.GSASIIscriptable as G2s

W = '<ATTEMPT_WORKSPACE>'
prj = G2s.G2Project(os.path.join(W, 'final.gpx'))
h = prj.histograms()[0]
lst = os.path.join(W, 'final.lst')

# ---- fit statistics --------------------------------------------------------
res = {}
cov = prj.data['Covariance']['data']['Rvals']
print('Rvals:', cov)

# per-phase R factors and weight fractions from the .lst report
wt, rf, name = {}, {}, None
for line in open(lst):
    m = re.match(r' Phase: (.*) in histogram:', line)
    if m:
        name = m.group(1).strip()
    m = re.search(r'Final refinement RF, RF\^2 = ([\d.]+)%, ([\d.]+)% on (\d+) reflections', line)
    if m and name:
        rf[name] = dict(RF_percent=float(m.group(1)), RF2_percent=float(m.group(2)),
                        n_reflections=int(m.group(3)))
    m = re.search(r'Weight fraction  :\s*([\d.]+), sig\s*([\d.]+)', line)
    if m and name:
        wt[name] = (float(m.group(1)), float(m.group(2)))
print('weight fractions:', wt)
print('phase R factors:', rf)

# ---- profile ---------------------------------------------------------------
d = h.data['data'][1]
x, yo, yc, yb = np.array(d[0]), np.array(d[1]), np.array(d[3]), np.array(d[4])
with open(os.path.join(W, 'fit.csv'), 'w') as fp:
    fp.write('two_theta_deg,y_obs,y_calc,y_diff,y_background\n')
    for i in range(len(x)):
        fp.write(f'{x[i]:.6f},{yo[i]:.3f},{yc[i]:.4f},{yo[i]-yc[i]:.4f},{yb[i]:.4f}\n')
print('wrote fit.csv with', len(x), 'points')

# R factors computed directly from the profile (check)
w = 1.0 / np.maximum(yo, 1.0)
Rwp = 100 * np.sqrt(np.sum(w * (yo - yc) ** 2) / np.sum(w * yo ** 2))
Rp = 100 * np.sum(np.abs(yo - yc)) / np.sum(yo)
print(f'check Rwp = {Rwp:.3f}%  Rp = {Rp:.3f}%')

# ---- CIFs ------------------------------------------------------------------
cifnames = {}
for p in prj.phases():
    out = os.path.join(W, f'{p.name}.cif')
    p.export_CIF(out)
    cifnames[p.name] = os.path.basename(out)
    print('wrote', out)

# ---- result.json -----------------------------------------------------------
sp = h.data['Sample Parameters']
ip = h.data['Instrument Parameters'][0]
tot = sum(v[0] for v in wt.values())
phases_out = []
formula = {'WO3': 'WO3', 'Co3O4': 'Co3O4'}
sgname = {}
for p in prj.phases():
    c = p.get_cell()
    hp = p.data['Histograms'][h.name]
    mus = hp['Mustrain']
    phases_out.append({
        'name': p.name,
        'formula': formula.get(p.name, p.name),
        'space_group': p.data['General']['SGData']['SpGrp'],
        'cif': cifnames[p.name],
        'weight_fraction': round(wt[p.name][0] / tot, 4),
        'weight_fraction_esd': round(wt[p.name][1], 4),
        'weight_percent': round(100 * wt[p.name][0] / tot, 2),
        'lattice_parameters': {k: round(v, 5) for k, v in c.items()},
        'phase_scale_factor': hp['Scale'][0],
        'microstrain_model': mus[0],
        'microstrain': ([round(v, 1) for v in mus[4]] if mus[0] == 'generalized'
                        else round(mus[1][0], 1)),
        'R_factors': rf.get(p.name, {}),
    })

out = {
    'sample': {
        'precursors': ['Co3O4', 'WO3'],
        'reported_heating_temperature_C': 500.0,
        'identified_product': 'unreacted precursor mixture: gamma-WO3 + Co3O4',
        'number_of_crystalline_phases_modelled': len(phases_out),
    },
    'phases': phases_out,
    'fit_statistics': {
        'Rwp_percent': round(float(cov.get('Rwp', Rwp)), 4),
        'Rp_percent': round(float(Rp), 4),
        'GOF': round(float(cov.get('GOF', float('nan'))), 4),
        'chi_squared_reduced': round(float(cov.get('GOF', float('nan'))) ** 2, 4),
        'n_observations': int(len(x)),
        'n_varied_parameters': len(prj.data['Covariance']['data'].get('varyList', [])),
        'two_theta_range_deg': [round(float(x[0]), 4), round(float(x[-1]), 4)],
    },
    'experimental_model': {
        'radiation': 'Cu Ka1/Ka2',
        'wavelengths_angstrom': [ip['Lam1'][1], ip['Lam2'][1]],
        'Ka2_to_Ka1_intensity_ratio': ip['I(L2)/I(L1)'][1],
        'geometry': 'Bragg-Brentano (reflection)',
        'sample_displacement_um': round(sp['Shift'][0], 1),
        'goniometer_radius_mm': sp['Gonio. radius'],
        'background': f"{h.data['Background'][0][0]}, {h.data['Background'][0][2]} terms",
        'profile_instrument': {k: round(ip[k][1], 5) for k in ['U', 'V', 'W', 'X', 'Y', 'SH/L']},
        'polarization': ip['Polariz.'][1],
        'Uiso_fixed': {'W': 0.005, 'O': 0.010, 'Co': 0.005},
    },
    'derived': {
        'molar_ratio_WO3_to_Co3O4': round((wt['WO3'][0] / 231.84) / (wt['Co3O4'][0] / 240.80), 3),
        'atomic_ratio_Co_to_W': round(3 * (wt['Co3O4'][0] / 240.80) / (wt['WO3'][0] / 231.84), 3),
        'comment': ('close to the 3 WO3 : 1 Co3O4 (Co:W = 1:1) batch expected for an '
                    'intended CoWO4 synthesis, i.e. the precursors are essentially unreacted'),
    },
    'phases_tested_and_rejected': [
        {'phase': 'CoWO4 (wolframite, P2/c, COD 5910316)',
         'result': 'phase fraction refines to zero; no intensity at its strongest line '
                   '(-111, 2theta ~ 30.9 deg after the displacement correction)',
         'upper_bound_wt_percent': 1.5},
        {'phase': 'triclinic epsilon/delta-WO3 (P-1, COD 2106293)',
         'result': 'markedly worse fit than monoclinic gamma-WO3 (Rwp 8.3% vs 3.2% in the '
                   'same protocol); not used'},
        {'phase': 'CoO (rocksalt), WO2, W metal',
         'result': 'no distinct unmodelled peaks at their principal lines '
                   '(CoO 36.8/42.7, W 40.6/53.1, WO2 26.2/37.3 deg in the displaced frame)'},
        {'phase': 'preferred orientation (March-Dollase on WO3 [100], [010], [001])',
         'result': 'all refine to 1.00; no texture, term dropped'},
    ],
    'caveats': [
        'Weight fractions are normalised over the two modelled crystalline phases; any '
        'amorphous or X-ray-poorly-diffracting fraction is not quantified (no internal standard).',
        'Quoted esds are refinement statistics only; realistic QPA accuracy for this '
        'strongly absorbing, heavily overlapped two-phase mixture is +/- 1-2 wt% '
        '(the spread over the physically acceptable model variants tried was 74.4-75.4 wt% WO3; '
        'a rejected variant with negative surface roughness gave 76.5 wt%). Microabsorption '
        '(Brindley) was not corrected: particle sizes are unknown.',
        'Atom coordinates were not refined: with laboratory Cu data, a ~2900-count background '
        'and extensive WO3/Co3O4 overlap they are not reliably determinable here.',
    ],
    'files': {'project': 'final.gpx', 'profile': 'fit.csv', 'report': 'report.md',
              'figure': 'fit.png'},
}
with open(os.path.join(W, 'result.json'), 'w') as fp:
    json.dump(out, fp, indent=2)
print(json.dumps(out, indent=2))
