import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

f = sys.argv[1]
out = sys.argv[2]
d = np.genfromtxt(f, delimiter=',', names=True)
x = d['2th'] if '2th' in d.dtype.names else d[d.dtype.names[0]]
ranges = [(10, 30), (30, 45), (45, 65), (65, 100)]
fig, axs = plt.subplots(len(ranges), 1, figsize=(14, 4 * len(ranges)))
for ax, (lo, hi) in zip(axs, ranges):
    m = (x >= lo) & (x <= hi)
    ax.plot(x[m], d['obs'][m], 'k.', ms=2, label='obs')
    ax.plot(x[m], d['calc'][m], 'r-', lw=0.8, label='calc')
    ax.plot(x[m], d['diff'][m] + d['obs'][m].min() - 0.15 * (d['obs'][m].max() - d['obs'][m].min()),
            'b-', lw=0.6, label='diff')
    ax.set_xlim(lo, hi)
    ax.legend(fontsize=7)
fig.tight_layout()
fig.savefig(out, dpi=110)
print('wrote', out)
