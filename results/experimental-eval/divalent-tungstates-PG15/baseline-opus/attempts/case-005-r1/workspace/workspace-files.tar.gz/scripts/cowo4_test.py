"""Detection test: add CoWO4 (wolframite) to the converged 2-phase model and
refine only its phase fraction (cell and profile held)."""
import os
import shutil
import sys
import GSASII.GSASIIscriptable as G2s
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from refine import wtfracs

W = '<ATTEMPT_WORKSPACE>'
src, dst = f'{W}/work/testK.gpx', f'{W}/work/cowo4test.gpx'
shutil.copy(src, dst)
prj = G2s.G2Project(dst)
h = prj.histograms()[0]
print('start Rwp', h.get_wR())
ph = prj.add_phase(f'{W}/work/5910316.cif', phasename='CoWO4', histograms=[h])
hp = ph.data['Histograms'][h.name]
hp['Scale'] = [0.02, True]
hp['Mustrain'][1][0] = 2000.
ph.set_refinements({'Cell': False})
prj.refine()
print('Rwp with CoWO4', h.get_wR())
print('CoWO4 scale', hp['Scale'])
for n, v in wtfracs(prj, h).items():
    print(f'  {n:8s} wt% = {100*v[0]:.3f} +/- {100*v[1]:.3f}')
prj.save()
