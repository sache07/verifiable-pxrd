"""Fifth pass: physically-bounded instrument Gaussian, sample Lorentzian broadening."""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from refine import build, report

gpxname = sys.argv[1] if len(sys.argv) > 1 else 'two5.gpx'
plist = [tuple(a.split(':')) for a in sys.argv[2:]] or [('WO3', '1528915.cif'), ('Co3O4', '9005896.cif')]

prj, h, phases = build(gpxname, plist)
names = list(phases)
ip = h.data['Instrument Parameters'][0]


def show(tag):
    report(prj, h, phases, tag)
    print('   inst:', {k: round(ip[k][1], 5) for k in ['U', 'V', 'W', 'X', 'Y', 'SH/L']})
    for n, p in phases.items():
        hp = p.data['Histograms'][h.name]
        print(f'    {n:10s} size {hp["Size"][1][0]:8.4f}  mustrain {hp["Mustrain"][1][0]:8.1f}')


h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True},
                   'Sample Parameters': ['Scale']})
for n in names[1:]:
    phases[n].set_HAP_refinements({'Scale': True})
prj.refine()
h.set_refinements({'Sample Parameters': ['Scale', 'Shift']})
prj.refine()
for p in phases.values():
    p.set_refinements({'Cell': True})
prj.refine()
report(prj, h, phases, 'base')

# modest fixed instrumental Gaussian; sample broadening carries the rest
ip['U'][1] = 2.0
ip['V'][1] = -2.0
ip['W'][1] = 3.0
ip['X'][1] = 0.0
ip['Y'][1] = 0.0
h.set_refinements({'Instrument Parameters': ['W', 'SH/L']})
for p in phases.values():
    p.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True},
                           'Size': {'type': 'isotropic', 'refine': True}})
prj.refine()
show('W,SH/L + per-phase size&mustrain (U,V,X,Y fixed)')

h.set_refinements({'Instrument Parameters': ['W', 'SH/L', 'X']})
prj.refine()
show('+X')

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True}})
prj.refine()
show('+bkg12')

for p in phases.values():
    p.set_HAP_refinements({'Mustrain': {'type': 'uniaxial', 'refine': True, 'direction': [0, 0, 1]}})
prj.refine()
show('+uniaxial mustrain (001)')
prj.save()
