"""First pass: WO3 + Co3O4 two-phase Rietveld, progressive refinement."""
import os
import sys
import numpy as np
import GSASII.GSASIIscriptable as G2s

W = '<ATTEMPT_WORKSPACE>'
work = os.path.join(W, 'work')
gpx = os.path.join(work, 'step1.gpx')
if os.path.exists(gpx):
    os.remove(gpx)

prj = G2s.G2Project(filename=gpx)
h = prj.add_powder_histogram(os.path.join(work, 'pattern.xye'),
                             os.path.join(work, 'cu.instprm'),
                             fmthint='Topas xye')
phases = {}
for name, cif in [('WO3', '1528915.cif'), ('Co3O4', '9005896.cif')]:
    phases[name] = prj.add_phase(os.path.join(work, cif), phasename=name, histograms=[h])

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 6, 'refine': True},
                   'Sample Parameters': ['Scale']})
prj.refine()


def rep(tag):
    print(f'--- {tag}: Rwp = {h.get_wR():.3f}')
    for n, p in phases.items():
        print('   ', n, 'cell', [round(v, 5) for v in p.get_cell_list()[1][:6]] if False else p.get_cell())
    sys.stdout.flush()


rep('scale+bkg')

# sample displacement + zero
h.set_refinements({'Sample Parameters': ['Scale', 'Shift']})
prj.refine()
rep('+shift')

for p in phases.values():
    p.set_refinements({'Cell': True})
prj.refine()
rep('+cell')

h.set_refinements({'Instrument Parameters': ['U', 'V', 'W']})
prj.refine()
rep('+UVW')

h.set_refinements({'Instrument Parameters': ['X', 'Y']})
prj.refine()
rep('+XY')

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 10, 'refine': True}})
prj.refine()
rep('+bkg10')

prj.save()
print('phase fractions:')
for n, p in phases.items():
    print(n, p.data['Histograms'][h.name]['Scale'])
