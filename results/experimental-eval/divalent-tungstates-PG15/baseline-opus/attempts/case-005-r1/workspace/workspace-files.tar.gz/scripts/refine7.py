"""Seventh pass: final profile model candidate.

Instrument: Gaussian W (+U,V fixed small), Lorentzian X (1/cos th), Y = 0, SH/L asymmetry.
Sample:     per-phase isotropic Lorentzian microstrain; size fixed at 1 um (negligible).
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from refine import build, report

gpxname = sys.argv[1] if len(sys.argv) > 1 else 'two7.gpx'
plist = [tuple(a.split(':')) for a in sys.argv[2:]] or [('WO3', '1528915.cif'), ('Co3O4', '9005896.cif')]

prj, h, phases = build(gpxname, plist)
names = list(phases)
ip = h.data['Instrument Parameters'][0]


def show(tag):
    report(prj, h, phases, tag)
    print('   inst:', {k: round(ip[k][1], 5) for k in ['U', 'V', 'W', 'X', 'Y', 'SH/L']})
    for n, p in phases.items():
        hp = p.data['Histograms'][h.name]
        print(f'    {n:10s} size {hp["Size"][1][0]:8.4f}  mustrain {hp["Mustrain"][1][0]:8.1f}')


h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True},
                   'Sample Parameters': ['Scale']})
for n in names[1:]:
    phases[n].set_HAP_refinements({'Scale': True})
prj.refine()
h.set_refinements({'Sample Parameters': ['Scale', 'Shift']})
prj.refine()
for p in phases.values():
    p.set_refinements({'Cell': True})
prj.refine()
report(prj, h, phases, 'base')

ip['U'][1] = 2.0
ip['V'][1] = -2.0
ip['W'][1] = 5.0
ip['X'][1] = 5.0
ip['Y'][1] = 0.0
for p in phases.values():
    hp = p.data['Histograms'][h.name]
    hp['Mustrain'][1][0] = 3000.
    hp['Size'][1][0] = 1.0
    p.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}})
h.set_refinements({'Instrument Parameters': ['W', 'X', 'SH/L']})
prj.refine()
show('inst W,X,SH/L + per-phase mustrain')

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True}})
prj.refine()
show('+bkg12')

# allow a size term only where it helps
for n, p in phases.items():
    p.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}})
prj.refine()
show('+size both')
prj.save()
