import sys
import numpy as np
from scipy.signal import find_peaks

path = sys.argv[1]
d = np.loadtxt(path, delimiter=',', skiprows=1)
x, y = d[:, 0], d[:, 1]
print("range", x[0], x[-1], "step", np.median(np.diff(x)), "n", len(x))
print("ymin", y.min(), "ymax", y.max())

# crude background: rolling minimum then smooth
from scipy.ndimage import minimum_filter1d, uniform_filter1d
bg = minimum_filter1d(y, 301)
bg = uniform_filter1d(bg, 301)
yc = y - bg
sm = uniform_filter1d(yc, 5)
noise = np.std(yc[:200])
pk, props = find_peaks(sm, height=max(30, 4 * noise), prominence=max(25, 3 * noise), distance=8)
lam = 1.540598
print(f"{'2th':>9} {'d':>8} {'I':>9} {'I/Imax':>7}")
hmax = props['peak_heights'].max()
for i, h in zip(pk, props['peak_heights']):
    dsp = lam / (2 * np.sin(np.radians(x[i] / 2)))
    print(f"{x[i]:9.4f} {dsp:8.4f} {h:9.1f} {100*h/hmax:7.1f}")
