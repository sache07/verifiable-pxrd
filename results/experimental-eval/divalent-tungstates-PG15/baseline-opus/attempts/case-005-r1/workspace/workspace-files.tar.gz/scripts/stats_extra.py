"""Extra diagnostics for the report: background-subtracted R factors, peak widths."""
import os
import numpy as np
import GSASII.GSASIIscriptable as G2s

W = '<ATTEMPT_WORKSPACE>'
prj = G2s.G2Project(os.path.join(W, 'final.gpx'))
h = prj.histograms()[0]
d = h.data['data'][1]
x, yo, yc, yb = np.array(d[0]), np.array(d[1]), np.array(d[3]), np.array(d[4])
w = 1 / np.maximum(yo, 1)
print(f'Rwp  = {100*np.sqrt(np.sum(w*(yo-yc)**2)/np.sum(w*yo**2)):.3f} %')
print(f'Rp   = {100*np.sum(np.abs(yo-yc))/np.sum(yo):.3f} %')
pb = yo - yb
print(f"Rwp' (background subtracted) = {100*np.sqrt(np.sum(w*(yo-yc)**2)/np.sum(w*pb**2)):.2f} %")
print(f"Rp'  (background subtracted) = {100*np.sum(np.abs(yo-yc))/np.sum(np.abs(pb)):.2f} %")
print('mean background counts', round(yb.mean()), ' max obs', yo.max())
print('peak/background ratio (max)', round(yo.max() / yb.mean(), 2))

for ph, rl in h.reflections().items():
    R = np.array(rl['RefList'])
    pos, sig, gam = R[:, 5], R[:, 6], R[:, 7]
    fwG = 2.3548 * np.sqrt(np.abs(sig)) / 100.      # sig is in centideg^2
    fwL = gam / 100.                                 # gam is a FWHM in centideg
    fw = (fwG ** 5 + 2.69269 * fwG ** 4 * fwL + 2.42843 * fwG ** 3 * fwL ** 2
          + 4.47163 * fwG ** 2 * fwL ** 3 + 0.07842 * fwG * fwL ** 4 + fwL ** 5) ** 0.2
    m = pos < 60
    print(f'\n{ph}: {len(R)} reflections, 2th {pos.min():.2f}-{pos.max():.2f}')
    print('  FWHM (deg) estimates below 60 deg 2theta: '
          f'min {fw[m].min():.3f}  median {np.median(fw[m]):.3f}  max {fw[m].max():.3f}')
    idx = np.argsort(fw[m])
    for j in list(idx[:3]) + list(idx[-3:]):
        hkl = R[m][j][:3].astype(int)
        print(f'   hkl {hkl}  2th {pos[m][j]:7.3f}  FWHM {fw[m][j]:.3f}')
