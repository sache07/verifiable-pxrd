"""Same refinement sequence as the final 2-phase model, but with CoWO4
(wolframite) added as a third phase: cell fixed, only its fraction refined.
Used to put an upper bound on any CoWO4 in the sample."""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from refine import build, report

prj, h, phases = build('final3.gpx', [('WO3', 'wo3_p21n_b.cif'), ('Co3O4', '9005896.cif'),
                                      ('CoWO4', '5910316.cif')])
ip = h.data['Instrument Parameters'][0]
UFIX = {'W': 0.005, 'O': 0.010, 'Co': 0.005}
for p in phases.values():
    for at in p.atoms():
        if at.adp_flag == 'I':
            at.uiso = UFIX.get(at.element, 0.01)

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True},
                   'Sample Parameters': ['Scale']})
for n in ['Co3O4', 'CoWO4']:
    phases[n].data['Histograms'][h.name]['Scale'] = [0.05, True]
prj.refine()
h.set_refinements({'Sample Parameters': ['Scale', 'Shift']})
prj.refine()
for n in ['WO3', 'Co3O4']:
    phases[n].set_refinements({'Cell': True})
prj.refine()
report(prj, h, phases, '1. scale/bkg/shift/cell')

ip['U'][1] = 2.0
ip['V'][1] = -2.0
ip['W'][1] = 5.0
ip['X'][1] = 5.0
ip['Y'][1] = 0.0
for n in ['WO3', 'Co3O4']:
    hp = phases[n].data['Histograms'][h.name]
    hp['Mustrain'][1][0] = 3000.
    hp['Size'][1][0] = 1.0
    phases[n].set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}})
phases['CoWO4'].data['Histograms'][h.name]['Mustrain'][1][0] = 2000.
h.set_refinements({'Instrument Parameters': ['W', 'X', 'SH/L']})
prj.refine()
report(prj, h, phases, '2. +profile')

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True}})
prj.refine()
prj.refine()
report(prj, h, phases, '3. +bkg12')

phases['WO3'].set_HAP_refinements({'Mustrain': {'type': 'generalized', 'refine': True}})
for k in range(4):
    prj.refine()
report(prj, h, phases, '4. +generalized microstrain WO3')
for n, p in phases.items():
    print(f'   {n}: scale {p.data["Histograms"][h.name]["Scale"]}')
prj.save()
