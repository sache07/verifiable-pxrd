"""Fourth pass: constrained Caglioti (V=0), per-phase broadening both phases."""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from refine import build, report

gpxname = sys.argv[1] if len(sys.argv) > 1 else 'two4.gpx'
plist = [('WO3', '1528915.cif'), ('Co3O4', '9005896.cif')]
if len(sys.argv) > 2:
    plist = [tuple(a.split(':')) for a in sys.argv[2:]]

prj, h, phases = build(gpxname, plist)
names = list(phases)
ip = h.data['Instrument Parameters'][0]


def show(tag):
    report(prj, h, phases, tag)
    print('   inst:', {k: round(ip[k][1], 5) for k in ['U', 'V', 'W', 'X', 'Y', 'SH/L']})
    for n, p in phases.items():
        hp = p.data['Histograms'][h.name]
        print(f'    {n:10s} size {hp["Size"][1][0]:8.4f}  mustrain {hp["Mustrain"][1][0]:8.1f}')


h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True},
                   'Sample Parameters': ['Scale']})
for n in names[1:]:
    phases[n].set_HAP_refinements({'Scale': True})
prj.refine()
h.set_refinements({'Sample Parameters': ['Scale', 'Shift']})
prj.refine()
for p in phases.values():
    p.set_refinements({'Cell': True})
prj.refine()
report(prj, h, phases, 'base')

# constrained instrument: U, W, X, Y, SH/L  (V held at 0)
ip['V'][1] = 0.0
h.set_refinements({'Instrument Parameters': ['U', 'W', 'X', 'Y', 'SH/L']})
prj.refine()
show('+inst U,W,X,Y,SH/L (V=0)')

for p in phases.values():
    p.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}})
prj.refine()
show('+mustrain both')

for p in phases.values():
    p.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}})
prj.refine()
show('+size both')

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True}})
prj.refine()
show('+bkg12')
prj.save()
