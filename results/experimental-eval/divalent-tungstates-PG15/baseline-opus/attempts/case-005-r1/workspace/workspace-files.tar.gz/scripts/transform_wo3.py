"""Transform the Loopstra gamma-WO3 P21/c (beta=136) description into the
conventional P21/n setting (a~7.31, b~7.54, c~7.69, beta~90.9)."""
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
from pymatgen.io.cif import CifWriter
import numpy as np

s = Structure.from_file('work/2311041.cif')
print('input:', s.lattice.abc, s.lattice.angles, len(s))
print('input sg:', SpacegroupAnalyzer(s, symprec=0.05).get_space_group_symbol())

M = np.array([[1, 0, 1], [0, 1, 0], [-1, 0, 0]])
s2 = s.copy()
s2.make_supercell(M)
print('new:', s2.lattice.abc, s2.lattice.angles, len(s2))
sga = SpacegroupAnalyzer(s2, symprec=0.05)
print('new sg:', sga.get_space_group_symbol(), sga.get_space_group_number())
CifWriter(s2, symprec=0.05).write_file('work/wo3_p21n.cif')
s3 = Structure.from_file('work/wo3_p21n.cif')
print('written:', s3.lattice.abc, s3.lattice.angles, len(s3),
      SpacegroupAnalyzer(s3, symprec=0.05).get_space_group_symbol())
print(open('work/wo3_p21n.cif').read())
