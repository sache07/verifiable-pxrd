"""Write gamma-WO3 in the conventional P21/n setting, keeping the transformed basis."""
import numpy as np
import spglib
from pymatgen.core import Structure

s = Structure.from_file('work/2311041.cif')
M = np.array([[1, 0, 1], [0, 1, 0], [-1, 0, 0]])
s.make_supercell(M)
lat = s.lattice.matrix
pos = s.frac_coords % 1.0
nums = [site.specie.Z for site in s]
cell = (lat, pos, nums)
ds = spglib.get_symmetry_dataset(cell, symprec=0.05)
print('sg:', ds.international, ds.number, 'hall:', ds.hall)
print('n ops:', len(ds.rotations))
for R, t in zip(ds.rotations, ds.translations):
    print(R.tolist(), np.round(t, 4).tolist())
print('equiv:', ds.equivalent_atoms)
