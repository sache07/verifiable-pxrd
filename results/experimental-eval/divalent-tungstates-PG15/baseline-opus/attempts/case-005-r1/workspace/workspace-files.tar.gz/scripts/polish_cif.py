"""Give the exported CIFs unique data-block names, cell esds and provenance notes."""
import json
import os
import re

W = '<ATTEMPT_WORKSPACE>'
res = json.load(open(os.path.join(W, 'result.json')))
fit = res['fit_statistics']

# cell esds parsed from the GSAS-II .lst report, in the order phases appear
blocks = []
lines = open(os.path.join(W, 'final.lst')).read().splitlines()
for i, l in enumerate(lines):
    if l.startswith(' Result for phase:'):
        name = l.split(':', 1)[1].strip()
    if l.strip().startswith('New unit cell'):
        vals = lines[i + 2].split(':')[1].split()
        esds = lines[i + 3].split(':')[1]
        esd = {'a': esds[0:12].strip(), 'b': esds[12:24].strip(), 'c': esds[24:36].strip(),
               'alpha': esds[36:48].strip(), 'beta': esds[48:60].strip(),
               'gamma': esds[60:72].strip(), 'V': esds[72:].strip()}
        blocks.append((name, vals, esd))
esdmap = {n: e for n, v, e in blocks}
print(esdmap)

NOTES = {
    'WO3': ["# gamma-WO3 (monoclinic tungsten trioxide), conventional P 21/n setting.",
            "# Starting coordinates: neutron refinement of Loopstra & Boldrini,",
            "# Acta Cryst. 21 (1966) 158 (COD 2311041), transformed from the P 21/c",
            "# (beta = 136.06 deg) description to the standard P 21/n cell.",
            "# Only the lattice parameters were refined against the present data;",
            "# atom coordinates and Uiso were held fixed (see report.md)."],
    'Co3O4': ["# Co3O4 normal spinel, Fd-3m (origin choice 2).",
              "# Starting coordinates: Liu & Prewitt, Phys. Chem. Minerals 17 (1990) 168",
              "# (296 K data set; AMCSD 0007478 / COD 9005896).",
              "# Only the lattice parameter was refined against the present data;",
              "# atom coordinates and Uiso were held fixed (see report.md)."],
}


def fmt(val, esd):
    """7.304722 + 0.000146 -> 7.30472(15)"""
    if not esd:
        return val
    e = float(esd)
    if e <= 0:
        return val
    import math
    nd = max(0, -int(math.floor(math.log10(e))) + 1)
    digits = int(round(e * 10 ** nd))
    if digits >= 100:
        nd -= 1
        digits = int(round(e * 10 ** nd))
    return f'{float(val):.{nd}f}({digits})'


for ph in res['phases']:
    name = ph['name']
    path = os.path.join(W, ph['cif'])
    txt = open(path).read()
    txt = txt.replace('data_final', f'data_{name}', 1)
    esd = esdmap.get(name, {})
    vals = {k: ph['lattice_parameters'][v] for k, v in
            [('a', 'length_a'), ('b', 'length_b'), ('c', 'length_c'),
             ('alpha', 'angle_alpha'), ('beta', 'angle_beta'), ('gamma', 'angle_gamma')]}
    for key, tag in [('a', '_cell_length_a'), ('b', '_cell_length_b'), ('c', '_cell_length_c'),
                     ('beta', '_cell_angle_beta')]:
        if esd.get(key):
            txt = re.sub(rf'{tag}\s+\S+', f'{tag}  {fmt(vals[key], esd[key])}', txt)
    header = ['######################################################################',
              f'# {name} - Rietveld refinement of laboratory Cu K-alpha powder data',
              f'# (Co3O4 + WO3 heated to 500 C; two-phase refinement, GSAS-II 5.7.8)']
    header += NOTES.get(name, [])
    header += [f"# Refined weight fraction in the crystalline mixture: "
               f"{100*ph['weight_fraction']:.1f} +/- {100*ph['weight_fraction_esd']:.1f} wt% "
               f"(estimated-standard-deviation from the refinement only)",
               f"# Overall fit: Rwp = {fit['Rwp_percent']:.2f}%, Rp = {fit['Rp_percent']:.2f}%, "
               f"GOF = {fit['GOF']:.2f}",
               f"# Phase residuals: RF = {ph['R_factors'].get('RF_percent')}%, "
               f"RF^2 = {ph['R_factors'].get('RF2_percent')}% "
               f"on {ph['R_factors'].get('n_reflections')} reflections",
               '######################################################################']
    txt = '\n'.join(header) + '\n' + txt.split('\n', 1)[1] if txt.startswith(' \n') else \
        '\n'.join(header) + '\n' + txt
    open(path, 'w').write(txt)
    print('polished', path)
