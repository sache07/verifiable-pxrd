"""Dump obs/calc/diff from a gpx and look for unmodeled residual peaks."""
import os
import sys
import numpy as np
from scipy.signal import find_peaks
from scipy.ndimage import uniform_filter1d
import GSASII.GSASIIscriptable as G2s

gpx = sys.argv[1]
prj = G2s.G2Project(gpx)
h = prj.histograms()[0]
d = h.data['data'][1]
x, yo, w, yc, yb = d[0], d[1], d[2], d[3], d[4]
res = yo - yc
np.savetxt(sys.argv[2], np.c_[x, yo, yc, yb, res], header='2th,obs,calc,bkg,diff',
           delimiter=',', comments='', fmt='%.6f')
sm = uniform_filter1d(res, 7)
sig = np.sqrt(np.maximum(yo, 1))
pk, props = find_peaks(sm / sig, height=3.0, prominence=2.0, distance=10)
lam = 1.540598
print('residual peaks (height in sigma units, and counts):')
for i, hh in zip(pk, props['peak_heights']):
    dsp = lam / (2 * np.sin(np.radians(x[i] / 2)))
    print(f'  2th={x[i]:8.3f}  d={dsp:7.4f}  res={sm[i]:8.1f}  ({hh:5.1f} sigma)  obs={yo[i]:8.0f} calc={yc[i]:8.0f}')
print('n residual peaks:', len(pk))
print('Rwp', h.get_wR())
