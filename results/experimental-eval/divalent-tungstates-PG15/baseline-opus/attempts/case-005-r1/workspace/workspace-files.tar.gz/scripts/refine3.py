"""Third pass: instrument profile global, extra broadening only where needed."""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from refine import build, report

prj, h, phases = build('two3.gpx', [('WO3', '1528915.cif'), ('Co3O4', '9005896.cif')])
names = list(phases)
ip = h.data['Instrument Parameters'][0]

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True},
                   'Sample Parameters': ['Scale']})
for n in names[1:]:
    phases[n].set_HAP_refinements({'Scale': True})
prj.refine()
h.set_refinements({'Sample Parameters': ['Scale', 'Shift']})
prj.refine()
for p in phases.values():
    p.set_refinements({'Cell': True})
prj.refine()
report(prj, h, phases, 'base (scale,bkg,shift,cell)')

h.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y', 'SH/L']})
prj.refine()
report(prj, h, phases, '+inst UVWXY SH/L')
print('   inst:', {k: round(ip[k][1], 5) for k in ['U', 'V', 'W', 'X', 'Y', 'SH/L']})

phases['WO3'].set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}})
prj.refine()
report(prj, h, phases, '+WO3 mustrain')
print('   inst:', {k: round(ip[k][1], 5) for k in ['U', 'V', 'W', 'X', 'Y', 'SH/L']})
for n, p in phases.items():
    hp = p.data['Histograms'][h.name]
    print('   ', n, 'size', round(hp['Size'][1][0], 4), 'mustrain', round(hp['Mustrain'][1][0], 1))

phases['WO3'].set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}})
prj.refine()
report(prj, h, phases, '+WO3 size')
for n, p in phases.items():
    hp = p.data['Histograms'][h.name]
    print('   ', n, 'size', round(hp['Size'][1][0], 4), 'mustrain', round(hp['Mustrain'][1][0], 1))

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True}})
prj.refine()
report(prj, h, phases, '+bkg12')
prj.save()
