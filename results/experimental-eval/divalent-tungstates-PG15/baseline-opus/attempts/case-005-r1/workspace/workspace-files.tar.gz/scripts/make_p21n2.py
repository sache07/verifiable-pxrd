"""Write gamma-WO3 (Loopstra & Boldrini 1966 coordinates) in the P21/n setting."""
import numpy as np
import spglib
from pymatgen.core import Structure

s = Structure.from_file('work/2311041.cif')
M = np.array([[1, 0, 1], [0, 1, 0], [-1, 0, 0]])
s.make_supercell(M)
pos = s.frac_coords % 1.0
nums = [site.specie.Z for site in s]
ds = spglib.get_symmetry_dataset((s.lattice.matrix, pos, nums), symprec=0.05)
reps = sorted(set(ds.equivalent_atoms))
a, b, c = s.lattice.abc
al, be, ga = s.lattice.angles

lines = ["data_gamma_WO3_P21n",
         "_chemical_name_mineral 'tungsten trioxide (gamma)'",
         "_chemical_formula_sum 'W O3'",
         "_symmetry_space_group_name_H-M 'P 1 21/n 1'",
         "_symmetry_Int_Tables_number 14",
         f"_cell_length_a {a:.5f}",
         f"_cell_length_b {b:.5f}",
         f"_cell_length_c {c:.5f}",
         f"_cell_angle_alpha {al:.4f}",
         f"_cell_angle_beta {be:.4f}",
         f"_cell_angle_gamma {ga:.4f}",
         "_cell_formula_units_Z 8",
         "loop_",
         "_symmetry_equiv_pos_as_xyz",
         "  'x, y, z'",
         "  '-x, -y, -z'",
         "  '-x+1/2, y+1/2, -z+1/2'",
         "  'x+1/2, -y+1/2, z+1/2'",
         "loop_",
         "_atom_site_label",
         "_atom_site_type_symbol",
         "_atom_site_fract_x",
         "_atom_site_fract_y",
         "_atom_site_fract_z",
         "_atom_site_occupancy",
         "_atom_site_U_iso_or_equiv"]
nw = no = 0
for i in reps:
    el = s[i].specie.symbol
    if el == 'W':
        nw += 1
        lab = f'W{nw}'
    else:
        no += 1
        lab = f'O{no}'
    x, y, z = pos[i]
    lines.append(f'  {lab} {el} {x:.5f} {y:.5f} {z:.5f} 1.0 0.01')
open('work/wo3_p21n.cif', 'w').write('\n'.join(lines) + '\n')
print('\n'.join(lines))

chk = Structure.from_file('work/wo3_p21n.cif')
print('check:', chk.lattice.abc, chk.lattice.angles, len(chk), chk.composition.reduced_formula)
