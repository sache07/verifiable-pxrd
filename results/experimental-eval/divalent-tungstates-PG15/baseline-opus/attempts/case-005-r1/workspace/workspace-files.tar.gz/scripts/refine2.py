"""Second pass: careful profile refinement, two-phase model."""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from refine import build, report

prj, h, phases = build('two2.gpx', [('WO3', '1528915.cif'), ('Co3O4', '9005896.cif')])
names = list(phases)

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True},
                   'Sample Parameters': ['Scale']})
for n in names[1:]:
    phases[n].set_HAP_refinements({'Scale': True})
prj.refine()
report(prj, h, phases, 'scale+bkg, shift fixed')

h.set_refinements({'Sample Parameters': ['Scale', 'Shift']})
prj.refine()
report(prj, h, phases, '+shift')

for p in phases.values():
    p.set_refinements({'Cell': True})
prj.refine()
report(prj, h, phases, '+cell')

h.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y', 'SH/L']})
prj.refine()
report(prj, h, phases, '+UVWXY+SHL')
ip = h.data['Instrument Parameters'][0]
print('   inst:', {k: round(ip[k][1], 5) for k in ['U', 'V', 'W', 'X', 'Y', 'Z', 'SH/L', 'Polariz.']})

h.clear_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']})
for p in phases.values():
    p.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True},
                           'Mustrain': {'type': 'isotropic', 'refine': True}})
prj.refine()
report(prj, h, phases, '+per-phase size/mustrain (SH/L still on)')
print('   inst:', {k: round(ip[k][1], 5) for k in ['U', 'V', 'W', 'X', 'Y', 'SH/L']})
for n, p in phases.items():
    hp = p.data['Histograms'][h.name]
    print('   ', n, 'size', round(hp['Size'][1][0], 4), 'mustrain', round(hp['Mustrain'][1][0], 1))

for p in phases.values():
    p.set_refinements({'Atoms': {'all': 'XU'}})
prj.refine()
report(prj, h, phases, '+atoms XU')
prj.save()
