"""Progressive Rietveld refinement driver for the Co-W-O product pattern.

Usage: refine.py <gpxname> <phase1:cif1> [<phase2:cif2> ...]
"""
import os
import re
import sys
import numpy as np
import GSASII.GSASIIscriptable as G2s

W = '<ATTEMPT_WORKSPACE>'
work = os.path.join(W, 'work')


def wtfracs(prj, h):
    """Weight fractions from the .lst file of the last refinement."""
    lst = prj.filename.replace('.gpx', '.lst')
    out = {}
    name = None
    for line in open(lst):
        m = re.match(r' Phase: (.*) in histogram: (.*)', line)
        if m:
            name = m.group(1).strip()
        m = re.search(r'Weight fraction  :\s*([\d.]+), sig\s*([\d.]+)', line)
        if m and name:
            out[name] = (float(m.group(1)), float(m.group(2)))
    return out


def report(prj, h, phases, tag):
    print(f'=== {tag}:  Rwp = {h.get_wR():.4f}  GOF = {prj.data["Covariance"]["data"]["Rvals"].get("GOF", float("nan")):.3f}')
    wf = wtfracs(prj, h)
    sp = h.data['Sample Parameters']
    print(f'    Shift = {sp["Shift"][0]:.1f} um   Zero = {h.data["Instrument Parameters"][0]["Zero"][1]:.4f}')
    for n, p in phases.items():
        c = p.get_cell()
        print(f'    {n:10s} frac={p.data["Histograms"][h.name]["Scale"][0]:9.5f}  wt%={100*wf.get(n,(float("nan"),0))[0]:6.2f}'
              f'  a={c["length_a"]:.5f} b={c["length_b"]:.5f} c={c["length_c"]:.5f} beta={c["angle_beta"]:.4f} V={c["volume"]:.2f}')
    sys.stdout.flush()
    return wf


def build(gpxname, phaselist):
    gpx = gpxname if os.path.isabs(gpxname) else os.path.join(work, gpxname)
    for f in (gpx, gpx.replace('.gpx', '.bak0.gpx')):
        if os.path.exists(f):
            os.remove(f)
    prj = G2s.G2Project(filename=gpx)
    h = prj.add_powder_histogram(os.path.join(work, 'pattern.xye'),
                                 os.path.join(work, 'cu.instprm'),
                                 fmthint='Topas xye')
    phases = {}
    for name, cif in phaselist:
        phases[name] = prj.add_phase(os.path.join(work, cif), phasename=name, histograms=[h])
    sp = h.data['Sample Parameters']
    sp['Shift'] = [-600.0, False]
    print('Gonio radius', sp['Gonio. radius'])
    return prj, h, phases


def sequence(prj, h, phases, aniso=True):
    names = list(phases)
    h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True},
                       'Sample Parameters': ['Scale']})
    for n in names[1:]:
        phases[n].set_HAP_refinements({'Scale': True})
    prj.refine()
    report(prj, h, phases, 'scale+bkg (Shift fixed -600um)')

    h.set_refinements({'Sample Parameters': ['Scale', 'Shift']})
    prj.refine()
    report(prj, h, phases, '+shift')

    for p in phases.values():
        p.set_refinements({'Cell': True})
    prj.refine()
    report(prj, h, phases, '+cell')

    h.set_refinements({'Instrument Parameters': ['U', 'V', 'W']})
    prj.refine()
    report(prj, h, phases, '+UVW')

    h.clear_refinements({'Instrument Parameters': ['U', 'V', 'W']})
    for p in phases.values():
        p.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True},
                               'Mustrain': {'type': 'isotropic', 'refine': True}})
    prj.refine()
    report(prj, h, phases, 'size+mustrain(iso) per phase, UVW fixed')
    return prj


if __name__ == '__main__':
    gpxname = sys.argv[1]
    phaselist = [tuple(a.split(':')) for a in sys.argv[2:]]
    prj, h, phases = build(gpxname, phaselist)
    sequence(prj, h, phases)
    prj.save()
