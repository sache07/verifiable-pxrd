"""Single-peak pseudo-Voigt fits for isolated peaks to gauge the profile."""
import numpy as np
from scipy.optimize import curve_fit

d = np.loadtxt('inputs/pattern.csv', delimiter=',', skiprows=1)
x, y = d[:, 0], d[:, 1]


def pv(t, amp, pos, fw, eta, b0, b1):
    g = np.exp(-4 * np.log(2) * ((t - pos) / fw) ** 2)
    l = 1 / (1 + 4 * ((t - pos) / fw) ** 2)
    return amp * (eta * l + (1 - eta) * g) + b0 + b1 * (t - pos)


# isolated-ish single peaks (2th center, half-window)
targets = [(19.37, 0.8, 'Co3O4 111'), (31.63, 0.8, 'Co3O4 220'), (37.20, 0.9, 'Co3O4 311'),
           (45.14, 1.0, 'Co3O4 400'), (56.24, 1.2, 'Co3O4 422'), (65.54, 1.2, 'Co3O4 440'),
           (26.95, 0.7, 'WO3 120'), (29.03, 0.7, 'WO3 112'), (42.20, 0.9, 'WO3 13x'),
           (47.56, 0.9, 'WO3 222'), (62.55, 1.0, 'WO3'), (77.22, 1.3, 'mix')]
print(f"{'label':12s} {'pos':>9} {'fwhm':>7} {'eta':>5} {'amp':>8}")
for c, hw, lab in targets:
    m = (x > c - hw) & (x < c + hw)
    t, yy = x[m], y[m]
    try:
        p, _ = curve_fit(pv, t, yy, p0=[yy.max() - np.median(yy), c, 0.2, 0.5, np.median(yy), 0],
                         bounds=([0, c - 0.4, 0.02, 0, 0, -1e4], [1e6, c + 0.4, 2.0, 1, 1e5, 1e4]))
        print(f'{lab:12s} {p[1]:9.4f} {p[2]:7.4f} {p[3]:5.2f} {p[0]:8.0f}')
    except Exception as e:
        print(lab, 'fail', e)
