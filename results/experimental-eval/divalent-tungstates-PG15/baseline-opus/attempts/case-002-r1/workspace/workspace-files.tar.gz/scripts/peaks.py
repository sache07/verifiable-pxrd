import sys
import numpy as np
import pandas as pd
from scipy.signal import find_peaks, savgol_filter

df = pd.read_csv(sys.argv[1])
x = df.iloc[:, 0].to_numpy(float)
y = df.iloc[:, 1].to_numpy(float)
print("range", x.min(), x.max(), "step", np.median(np.diff(x)), "npts", len(x))
print("Imax", y.max(), "at", x[y.argmax()], "Imin", y.min())

ys = savgol_filter(y, 11, 3)
# crude background: rolling minimum percentile
from scipy.ndimage import minimum_filter1d, maximum_filter1d
w = 301
bg = minimum_filter1d(ys, w)
bg = maximum_filter1d(bg, w)
bg = savgol_filter(bg, 201, 2)
yb = ys - bg
noise = np.std(yb[yb < np.percentile(yb, 40)])
print("bg level approx", bg.mean(), "noise", noise)

pk, props = find_peaks(yb, height=max(5 * noise, 0.01 * yb.max()), distance=8, prominence=3 * noise)
lam = 1.540598
print(f"{'2th':>9} {'d':>8} {'I':>10} {'I%':>7}")
hmax = props["peak_heights"].max()
for i, h in zip(pk, props["peak_heights"]):
    d = lam / (2 * np.sin(np.radians(x[i] / 2)))
    print(f"{x[i]:9.4f} {d:8.4f} {h:10.1f} {100*h/hmax:7.1f}")
print("n peaks", len(pk))
