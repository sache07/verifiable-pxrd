import sys, os
import numpy as np
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator

ROOT = '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif'


def cifpath(cid):
    return os.path.join(ROOT, cid[0], cid[1:3], cid[3:5], cid + '.cif')


cid = sys.argv[1]
tmax = float(sys.argv[2]) if len(sys.argv) > 2 else 60.0
p = cid if cid.endswith('.cif') else cifpath(cid)
st = Structure.from_file(p)
print(st.composition.reduced_formula, st.lattice)
calc = XRDCalculator(wavelength=1.540598)
ps = calc.get_pattern(st, two_theta_range=(9.0, tmax))
for tt, ii, h in zip(ps.x, ps.y, ps.hkls):
    hk = h[0]['hkl'] if isinstance(h, list) else h
    print(f'{tt:8.3f} {ii:7.2f} {hk}')
