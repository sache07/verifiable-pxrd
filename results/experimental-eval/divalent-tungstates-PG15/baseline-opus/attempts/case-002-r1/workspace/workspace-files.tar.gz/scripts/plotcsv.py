import sys, json
import numpy as np, pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

stem = sys.argv[1]
df = pd.read_csv(stem + '_fit.csv')
info = json.load(open(stem + '_info.json'))
x = df.two_theta_deg.values
n = 4
edges = np.linspace(x.min(), x.max(), n + 1)
fig, axes = plt.subplots(n, 1, figsize=(17, 4 * n))
cols = ['b', 'm', 'c', 'orange', 'purple']
for ax, a, b in zip(axes, edges[:-1], edges[1:]):
    m = (x >= a) & (x <= b)
    ymax = df.y_obs[m].max()
    ax.plot(x[m], df.y_obs[m], 'k.', ms=1.5)
    ax.plot(x[m], df.y_calc[m], 'r-', lw=0.8)
    ax.plot(x[m], df.y_diff[m] - 0.22 * ymax, 'g-', lw=0.6)
    for i, (nm, pd_) in enumerate(info['phases'].items()):
        p = np.array(pd_['refl2theta'])
        p = p[(p >= a) & (p <= b)]
        ax.plot(p, np.full_like(p, -0.04 * ymax - i * 0.035 * ymax), '|', color=cols[i % 5], ms=11,
                label=nm if ax is axes[0] else None)
    ax.set_xlim(a, b); ax.grid(alpha=.3)
axes[0].legend(fontsize=9, title=f"wR={info['wR']:.2f}%")
plt.tight_layout(); plt.savefig(sys.argv[2], dpi=100)
