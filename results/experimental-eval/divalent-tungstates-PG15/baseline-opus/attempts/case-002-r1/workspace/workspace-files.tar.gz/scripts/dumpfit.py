"""Dump obs/calc/bkg/diff and reflection positions from a .gpx to csv/json."""
import os, sys, json
import numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
import GSASIIscriptable as G2sc

gpx = G2sc.G2Project(sys.argv[1])
stem = sys.argv[2]
h = gpx.histogram(0)
d = h.data['data'][1]
x, yo, yc, yb = np.array(d[0]), np.array(d[1]), np.array(d[3]), np.array(d[4])
lo, hi = h.data['Limits'][1]
m = (x >= lo) & (x <= hi)
np.savetxt(stem + '_fit.csv', np.c_[x[m], yo[m], yc[m], yb[m], yo[m] - yc[m]], delimiter=',',
           header='two_theta_deg,y_obs,y_calc,y_bkg,y_diff', comments='')
out = {'wR': h.residuals['wR'], 'residuals': {k: (v if not isinstance(v, np.ndarray) else None)
                                             for k, v in h.residuals.items() if k != 'Nobs'},
       'phases': {}}
for ph in gpx.phases():
    try:
        rl = h.reflections()[ph.name]['RefList']
        pos = list(np.round(rl[:, 5], 4))
        inten = list(np.round(rl[:, 8] * rl[:, 11], 3)) if rl.shape[1] > 11 else []
    except Exception:
        pos, inten = [], []
    out['phases'][ph.name] = {'cell': list(np.round(ph.data['General']['Cell'][1:8], 5)),
                              'refl2theta': pos, 'intensity': inten}
try:
    wf = {}
    for ph in gpx.phases():
        wf[ph.name] = ph.data['Histograms'][h.name]['Scale'][0]
    out['scales'] = wf
except Exception as e:
    print(e)
json.dump(out, open(stem + '_info.json', 'w'), indent=1, default=str)
print('wR', h.residuals['wR'])
