"""Generic multi-phase Rietveld driver for the BaO2/WO3 pattern.

usage: rietveld.py OUT.gpx cif1[:name] cif2[:name] ...
"""
import os, sys, json
import numpy as np

WS = '<ATTEMPT_WORKSPACE>'
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
import GSASIIscriptable as G2sc

DATA = os.path.join(WS, 'work/pattern.xye')
INST = os.path.join(WS, 'work/cuka.instprm')


def build(gpxfile, cifs, nbkg=8):
    if os.path.exists(gpxfile):
        os.remove(gpxfile)
    gpx = G2sc.G2Project(newgpx=gpxfile)
    hist = gpx.add_powder_histogram(DATA, INST, fmthint='Topas xye')
    for spec in cifs:
        path, _, nm = spec.partition(':')
        ph = gpx.add_phase(path, phasename=nm or os.path.basename(path).split('.')[0],
                           histograms=[hist], fmthint='CIF')
    hist.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': nbkg, 'refine': True},
                          'Limits': [9.95, 100.0]})
    for ph in gpx.phases():
        ph.set_HAP_refinements({'Scale': True, 'Size': {'type': 'isotropic', 'refine': False}})
    gpx.data['Controls']['data']['max cyc'] = 12
    return gpx, hist


def rw(gpx):
    return gpx.histogram(0).residuals['wR']


def report(gpx, tag=''):
    h = gpx.histogram(0)
    print(f'--- {tag}: wR = {h.residuals["wR"]:.3f}%  GOF = {h.residuals.get("GOF", float("nan")):.3f}')
    for ph in gpx.phases():
        c = ph.data['General']['Cell'][1:8]
        print(f'    {ph.name:16s} a={c[0]:.5f} b={c[1]:.5f} c={c[2]:.5f} '
              f'al={c[3]:.3f} be={c[4]:.3f} ga={c[5]:.3f} V={c[6]:.2f} '
              f'frac={ph.data["Histograms"][h.name]["Scale"][0]:.5g}')
    try:
        print('    wtFrac', {k: round(v, 4) for k, v in gpx.get_phase_fractions().items()} if hasattr(gpx, 'get_phase_fractions') else '')
    except Exception:
        pass


if __name__ == '__main__':
    out = sys.argv[1]
    gpx, hist = build(out, sys.argv[2:])
    gpx.refine()
    report(gpx, 'scale+bkg')
    # sample displacement + zero
    hist.set_refinements({'Sample Parameters': ['Shift']})
    gpx.refine(); report(gpx, '+shift')
    for ph in gpx.phases():
        ph.set_refinements({'Cell': True})
    gpx.refine(); report(gpx, '+cell')
    hist.set_refinements({'Instrument Parameters': ['U', 'V', 'W']})
    gpx.refine(); report(gpx, '+UVW')
    for ph in gpx.phases():
        ph.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True},
                                'Mustrain': {'type': 'isotropic', 'refine': True}})
    gpx.refine(); report(gpx, '+size/strain')
