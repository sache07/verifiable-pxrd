"""Clean, staged Rietveld refinement of the BaO2 + gamma-WO3 mixture.

usage: final.py OUT.gpx cif:name [cif:name ...] [--coords] [--extra=cif:name]
"""
import os, sys, json
import numpy as np

WS = '<ATTEMPT_WORKSPACE>'
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
import GSASIIscriptable as G2sc

DATA = os.path.join(WS, 'work/pattern.xye')
INST = os.path.join(WS, 'work/cuka.instprm')
UISO = {'Ba': 0.010, 'W': 0.005, 'O': 0.012, 'C': 0.012}


def report(gpx, tag=''):
    h = gpx.histogram(0)
    print(f'=== {tag}: wR = {h.residuals["wR"]:.3f}%')
    for ph in gpx.phases():
        c = ph.data['General']['Cell'][1:8]
        hap = ph.data['Histograms'][h.name]
        print(f'    {ph.name:14s} {c[0]:.5f} {c[1]:.5f} {c[2]:.5f} {c[3]:.3f} {c[4]:.3f} {c[5]:.3f} '
              f'V={c[6]:.2f} sc={hap["Scale"][0]:.5g} sz={hap["Size"][1][0]:.4f} '
              f'ms={hap["Mustrain"][1][0]:.1f} MD={hap["Pref.Ori."][1]:.4f}')
    ip = h.data['Instrument Parameters'][0]
    sp = h.data['Sample Parameters']
    print('    Zero=%.4f Shift=%.1f U,V,W=%.1f,%.1f,%.1f' %
          (ip['Zero'][1], sp['Shift'][0], ip['U'][1], ip['V'][1], ip['W'][1]), flush=True)


def wtfrac(gpx):
    h = gpx.histogram(0)
    out = {}
    for ph in gpx.phases():
        out[ph.name] = ph.data['Histograms'][h.name]['Scale'][0] * ph.data['General']['Mass']
    s = sum(out.values())
    return {k: v / s for k, v in out.items()}


def main():
    args = sys.argv[1:]
    out = args.pop(0)
    coords = '--coords' in args
    cifs = [a for a in args if not a.startswith('--')]
    if os.path.exists(out):
        os.remove(out)
    gpx = G2sc.G2Project(newgpx=out)
    hist = gpx.add_powder_histogram(DATA, INST, fmthint='Topas xye')
    for spec in cifs:
        path, _, nm = spec.partition(':')
        gpx.add_phase(path, phasename=nm, histograms=[hist], fmthint='CIF')
    hist.set_refinements({'Limits': [9.95, 100.0],
                          'Background': {'type': 'chebyschev-1', 'no. coeffs': 10, 'refine': True}})
    gpx.data['Controls']['data']['max cyc'] = 20
    hname = hist.name
    for ph in gpx.phases():
        # sensible, fixed isotropic displacement parameters
        # atom record: [name, type, refine, x,y,z, frac, sym, mult, I/A, Uiso, U11..U23, id]
        for at in ph.data['Atoms']:
            el = at[1].rstrip('0123456789+-')
            at[9] = 'I'
            at[10] = UISO.get(el, 0.012)
            at[11:17] = [0.0] * 6
        ph.data['Histograms'][hname]['Size'][1][0] = 0.6
        ph.data['Histograms'][hname]['Mustrain'][1][0] = 1000.
        ph.set_HAP_refinements({'Scale': True})
    gpx.refine(); report(gpx, 'scale+bkg')

    for ph in gpx.phases():
        ph.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}})
    gpx.refine(); report(gpx, '+size')

    if '--zero' in args:
        hist.set_refinements({'Instrument Parameters': ['Zero']})
    else:
        hist.set_refinements({'Sample Parameters': ['Shift']})
    gpx.refine(); report(gpx, '+shift')

    for ph in gpx.phases():
        ph.set_refinements({'Cell': True})
    gpx.refine(); report(gpx, '+cell')

    for ph in gpx.phases():
        ph.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}})
    gpx.refine(); report(gpx, '+mustrain')

    for ph in gpx.phases():
        ph.set_HAP_refinements({'Pref.Ori.': {'type': 'MD', 'refine': True}})
    gpx.refine(); report(gpx, '+PO')

    hist.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 14, 'refine': True}})
    gpx.refine(); report(gpx, '+bkg14')

    if '--uiso' in args:
        # displacement parameters: only the heavy cations, O/C stay fixed
        for ph in gpx.phases():
            for at in ph.data['Atoms']:
                if not at[1].startswith('O'):
                    ph.set_refinements({'Atoms': {at[0]: 'U'}})
        gpx.refine(); report(gpx, '+Uiso(cation)')

    if coords:
        # free positional parameters of the heavy scatterers only
        for ph in gpx.phases():
            for at in ph.data['Atoms']:
                if at[1].startswith('W') or (ph.name == 'BaO2' and at[1].startswith('O')):
                    ph.set_refinements({'Atoms': {at[0]: 'X'}})
        gpx.refine(); report(gpx, '+coords')

    wf = wtfrac(gpx)
    print('weight fractions:', {k: round(v, 4) for k, v in wf.items()})
    h = gpx.histogram(0)
    print('residuals:', {k: v for k, v in h.residuals.items() if not hasattr(v, '__len__')})


if __name__ == '__main__':
    main()
