"""Apply one profile/texture tweak to a converged project and re-refine.

usage: tweak.py in.gpx out.gpx mode
modes: unims<hkl>  uniaxial mustrain for all phases along hkl (e.g. unims010)
       unisz<hkl>  uniaxial size
       sh4 / sh6   spherical-harmonic preferred orientation
"""
import os, sys, shutil
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
import GSASIIscriptable as G2sc
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from final import report, wtfrac

src, dst, mode = sys.argv[1], sys.argv[2], sys.argv[3]
shutil.copy(src, dst)
gpx = G2sc.G2Project(dst)
h = gpx.histogram(0)
report(gpx, 'start')
if mode.startswith('unims'):
    hkl = [int(c) for c in mode[5:]]
    for ph in gpx.phases():
        ph.set_HAP_refinements({'Mustrain': {'type': 'uniaxial', 'refine': True, 'direction': hkl}})
elif mode.startswith('unisz'):
    hkl = [int(c) for c in mode[5:]]
    for ph in gpx.phases():
        ph.set_HAP_refinements({'Size': {'type': 'uniaxial', 'refine': True, 'direction': hkl}})
elif mode in ('sh4', 'sh6'):
    order = int(mode[2])
    for ph in gpx.phases():
        ph.HAPvalue('PO', order)
        ph.set_HAP_refinements({'Pref.Ori.': {'type': 'SH', 'order': order, 'refine': True}})
else:
    raise SystemExit('bad mode')
gpx.refine(); report(gpx, mode)
print('weight fractions:', {k: round(v, 4) for k, v in wtfrac(gpx).items()})
print('residuals:', {k: v for k, v in h.residuals.items() if not hasattr(v, '__len__')})
