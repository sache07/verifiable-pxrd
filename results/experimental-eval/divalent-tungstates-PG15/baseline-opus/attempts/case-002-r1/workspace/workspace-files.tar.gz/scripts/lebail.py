"""Le Bail check: free intensities, same cells/profile. usage: lebail.py in.gpx out.gpx [niter]"""
import os, sys, shutil
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
import GSASIIscriptable as G2sc

src, dst = sys.argv[1], sys.argv[2]
n = int(sys.argv[3]) if len(sys.argv) > 3 else 6
shutil.copy(src, dst)
gpx = G2sc.G2Project(dst)
h = gpx.histogram(0)
for ph in gpx.phases():
    ph.set_HAP_refinements({'Scale': False})
    ph.data['Histograms'][h.name]['LeBail'] = True
    ph.data['Histograms'][h.name]['newLeBail'] = True
for i in range(n):
    gpx.refine()
    print(f'LeBail iter {i}: wR = {h.residuals["wR"]:.3f}%', flush=True)
