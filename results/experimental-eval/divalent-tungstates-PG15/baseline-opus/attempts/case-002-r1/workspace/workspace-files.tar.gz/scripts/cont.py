"""Continue refinement of an existing project with extra stages.

usage: cont.py in.gpx out.gpx stage1,stage2,...
"""
import os, sys, shutil
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
import GSASIIscriptable as G2sc
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from driver import report, wtfrac

src, dst = sys.argv[1], sys.argv[2]
stages = sys.argv[3].split(',') if len(sys.argv) > 3 else []
if os.path.abspath(src) != os.path.abspath(dst):
    shutil.copy(src, dst)
gpx = G2sc.G2Project(dst)
hist = gpx.histogram(0)
report(gpx, 'start')
for st in stages:
    if st == 'cell':
        for ph in gpx.phases():
            ph.set_refinements({'Cell': True})
    elif st == 'xy':
        hist.set_refinements({'Instrument Parameters': ['X', 'Y']})
    elif st == 'w':
        hist.set_refinements({'Instrument Parameters': ['W']})
    elif st == 'uvw':
        hist.set_refinements({'Instrument Parameters': ['U', 'V', 'W']})
    elif st == 'sh':
        hist.set_refinements({'Instrument Parameters': ['SH/L']})
    elif st == 'uiso':
        for ph in gpx.phases():
            ph.set_refinements({'Atoms': {'all': 'U'}})
    elif st == 'xyz':
        for ph in gpx.phases():
            ph.set_refinements({'Atoms': {'all': 'X'}})
    elif st.startswith('xyzW'):
        for ph in gpx.phases():
            for i, at in enumerate(ph.data['Atoms']):
                if at[1].startswith('W'):
                    ph.set_refinements({'Atoms': {i: 'X'}})
    elif st == 'po':
        for ph in gpx.phases():
            ph.set_HAP_refinements({'Pref.Ori.': {'type': 'MD', 'refine': True}})
    elif st == 'unistrain':
        for ph in gpx.phases():
            ph.set_HAP_refinements({'Mustrain': {'type': 'uniaxial', 'refine': True,
                                                 'direction': [0, 0, 1]}})
    elif st == 'unisize':
        for ph in gpx.phases():
            ph.set_HAP_refinements({'Size': {'type': 'uniaxial', 'refine': True,
                                             'direction': [0, 0, 1]}})
    elif st == 'bkg14':
        hist.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 14, 'refine': True}})
    elif st == 'bkg18':
        hist.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 18, 'refine': True}})
    elif st == 'hstrain':
        for ph in gpx.phases():
            ph.set_HAP_refinements({'HStrain': True})
    elif st == 'lgmix':
        for ph in gpx.phases():
            ph.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True,
                                             'LGmix': {'refine': True}},
                                    'Mustrain': {'type': 'isotropic', 'refine': True,
                                                 'LGmix': {'refine': True}}})
    elif st == 'noop':
        pass
    else:
        raise SystemExit('unknown stage ' + st)
    gpx.refine(); report(gpx, '+' + st)
print('weight fractions:', {k: round(v, 4) for k, v in wtfrac(gpx).items()})
