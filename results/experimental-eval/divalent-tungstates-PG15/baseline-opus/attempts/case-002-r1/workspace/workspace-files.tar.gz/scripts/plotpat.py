import sys
import numpy as np, pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

df = pd.read_csv(sys.argv[1])
x = df.iloc[:, 0].to_numpy(float); y = df.iloc[:, 1].to_numpy(float)
fig, axes = plt.subplots(4, 1, figsize=(16, 14))
edges = [(9.9, 32), (32, 55), (55, 78), (78, 100.1)]
for ax, (a, b) in zip(axes, edges):
    m = (x >= a) & (x <= b)
    ax.plot(x[m], y[m], lw=0.7)
    ax.set_xlim(a, b); ax.grid(alpha=.3)
    ax.set_xticks(np.arange(np.ceil(a), b, 1 if b - a < 25 else 2), minor=True)
plt.tight_layout(); plt.savefig(sys.argv[2], dpi=110)
