"""Add a candidate phase to a converged project and refine its scale (+size) only.

usage: addphase.py in.gpx out.gpx cif:name
"""
import os, sys, shutil
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
import GSASIIscriptable as G2sc
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from driver import report, wtfrac

src, dst, spec = sys.argv[1], sys.argv[2], sys.argv[3]
shutil.copy(src, dst)
gpx = G2sc.G2Project(dst)
hist = gpx.histogram(0)
path, _, nm = spec.partition(':')
ph = gpx.add_phase(path, phasename=nm, histograms=[hist], fmthint='CIF')
ph.set_HAP_refinements({'Scale': True,
                        'Size': {'type': 'isotropic', 'refine': True, 'value': 0.5}})
report(gpx, 'before')
gpx.refine(); report(gpx, 'scale(new)')
ph.set_refinements({'Cell': True})
gpx.refine(); report(gpx, '+cell(new)')
print('weight fractions:', {k: round(v, 4) for k, v in wtfrac(gpx).items()})
