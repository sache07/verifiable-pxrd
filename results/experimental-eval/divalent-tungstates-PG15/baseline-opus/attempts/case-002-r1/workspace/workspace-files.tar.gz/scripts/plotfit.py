import os, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
import GSASIIscriptable as G2sc

gpx = G2sc.G2Project(sys.argv[1])
h = gpx.histogram(0)
d = h.data['data'][1]
x, yo, w, yc, yb = d[0], d[1], d[2], d[3], d[4]
msk = (x >= h.data['Limits'][1][0]) & (x <= h.data['Limits'][1][1])
x, yo, yc, yb = x[msk], yo[msk], yc[msk], yb[msk]
print('wR', h.residuals['wR'])
refl = {}
for ph in gpx.phases():
    try:
        rd = h.reflections()[ph.name]['RefList']
        refl[ph.name] = rd[:, 5] if rd.shape[1] > 5 else None
    except Exception as e:
        print('norefl', ph.name, e)

n = 4
edges = np.linspace(x.min(), x.max(), n + 1)
fig, axes = plt.subplots(n, 1, figsize=(16, 4 * n))
for ax, a, b in zip(axes, edges[:-1], edges[1:]):
    m = (x >= a) & (x <= b)
    ax.plot(x[m], yo[m], 'k.', ms=1.5, label='obs')
    ax.plot(x[m], yc[m], 'r-', lw=0.8, label='calc')
    ax.plot(x[m], yo[m] - yc[m] - 0.15 * yo[m].max(), 'g-', lw=0.6, label='diff')
    cols = 'bmcy'
    for i, (nm, pos) in enumerate(refl.items()):
        if pos is None:
            continue
        p = pos[(pos >= a) & (pos <= b)]
        ax.plot(p, np.full_like(p, -0.05 * yo[m].max() - i * 0.03 * yo[m].max()), '|',
                color=cols[i % 4], ms=10, label=nm if ax is axes[0] else None)
    ax.set_xlim(a, b); ax.grid(alpha=.3)
    if ax is axes[0]:
        ax.legend(fontsize=8)
plt.tight_layout(); plt.savefig(sys.argv[2], dpi=100)
