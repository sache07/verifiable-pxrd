"""Refine selected atom parameters: refatoms.py in.gpx out.gpx Phase:Label:flags ..."""
import os, sys, shutil
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
import GSASIIscriptable as G2sc
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from final import report, wtfrac

src, dst = sys.argv[1], sys.argv[2]
shutil.copy(src, dst)
gpx = G2sc.G2Project(dst)
h = gpx.histogram(0)
report(gpx, 'start')
for spec in sys.argv[3:]:
    pn, lab, flags = spec.split(':')
    ph = gpx.phase(pn)
    ph.set_refinements({'Atoms': {lab: flags}})
    print('refining', spec)
gpx.refine(); report(gpx, 'atoms')
for ph in gpx.phases():
    print('--', ph.name)
    for at in ph.data['Atoms']:
        print('   ', at[0], at[1], at[2], [round(v, 5) for v in at[3:7]], at[9], round(at[10], 5))
print('weight fractions:', {k: round(v, 4) for k, v in wtfrac(gpx).items()})
print('residuals:', {k: v for k, v in h.residuals.items() if not hasattr(v, '__len__')})
