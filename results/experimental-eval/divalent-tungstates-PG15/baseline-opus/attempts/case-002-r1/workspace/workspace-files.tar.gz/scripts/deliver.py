"""Produce the deliverables: final.gpx, one CIF per phase, fit.csv, result.json.

usage: deliver.py source.gpx outdir
"""
import os, sys, json, shutil
import numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
import GSASIIscriptable as G2sc

src, outdir = sys.argv[1], sys.argv[2]
os.makedirs(outdir, exist_ok=True)
gpxpath = os.path.join(outdir, 'final.gpx')
shutil.copy(src, gpxpath)
gpx = G2sc.G2Project(gpxpath)
gpx.save(gpxpath)
h = gpx.histogram(0)
hname = h.name

# ---- profile ----
d = h.data['data'][1]
x, yo, yc, yb = np.array(d[0]), np.array(d[1]), np.array(d[3]), np.array(d[4])
lo, hi = h.data['Limits'][1]
m = (x >= lo) & (x <= hi)
arr = np.c_[x[m], yo[m], yc[m], yo[m] - yc[m], yb[m]]
np.savetxt(os.path.join(outdir, 'fit.csv'), arr, delimiter=',',
           fmt=['%.6f', '%.3f', '%.3f', '%.3f', '%.3f'],
           header='two_theta_deg,y_obs,y_calc,y_diff,y_background', comments='')

# ---- weight fractions and cell parameters ----
cov = gpx['Covariance']['data']
sig = dict(zip(cov.get('varyList', []), cov.get('sig', [])))
masses, scales, sscale = {}, {}, {}
for ph in gpx.phases():
    hap = ph.data['Histograms'][hname]
    masses[ph.name] = ph.data['General']['Mass']
    scales[ph.name] = hap['Scale'][0]
    key = f'{ph.id}:{h.id}:Scale'
    sscale[ph.name] = sig.get(key, 0.0)
tot = sum(scales[k] * masses[k] for k in scales)
wf = {k: scales[k] * masses[k] / tot for k in scales}
# propagate scale esds (ignoring correlations)
wfsig = {}
for k in scales:
    dwf = 0.0
    for j in scales:
        if j == k:
            dwf += ((masses[k] * tot - scales[k] * masses[k] * masses[k]) / tot**2 * sscale[k])**2
        else:
            dwf += ((-scales[k] * masses[k] * masses[j]) / tot**2 * sscale[j])**2
    wfsig[k] = dwf ** 0.5

res = h.residuals
out = {
    'analysis': 'Rietveld refinement (GSAS-II) of Cu Ka1/Ka2 powder pattern',
    'project': os.path.basename(gpxpath),
    'profile_file': 'fit.csv',
    'n_crystalline_phases': len(wf),
    'phases': [],
    'fit_statistics': {
        'Rwp_percent': round(res['wR'], 4),
        'Rp_percent': round(res['R'], 4),
        'Rwp_expected_percent': round(res['wRmin'], 4),
        'goodness_of_fit_chi': round(res['wR'] / res['wRmin'], 4),
        'reduced_chi_squared': round((res['wR'] / res['wRmin'])**2, 4),
        'R_Bragg_percent_all': round(res['Rb'], 4),
        'n_observations': int(len(arr)),
        'two_theta_range_deg': [round(float(arr[0, 0]), 4), round(float(arr[-1, 0]), 4)],
    },
}
for ph in gpx.phases():
    cell = ph.data['General']['Cell'][1:8]
    cifname = ph.name + '.cif'
    ph.export_CIF(os.path.join(outdir, cifname))
    out['phases'].append({
        'name': ph.name,
        'formula_in_cell': ''.join(
            f'{e.rstrip("+-0123456789")}{int(round(ph.data["General"]["NoAtoms"][e]))}'
            for e in ph.data['General']['AtomTypes']),
        'space_group': ph.data['General']['SGData']['SpGrp'],
        'cif': cifname,
        'weight_fraction': round(wf[ph.name], 5),
        'weight_fraction_esd_statistical': round(wfsig[ph.name], 5),
        'lattice': {'a': round(cell[0], 5), 'b': round(cell[1], 5), 'c': round(cell[2], 5),
                    'alpha': round(cell[3], 4), 'beta': round(cell[4], 4), 'gamma': round(cell[5], 4),
                    'volume_A3': round(cell[6], 3)},
        'R_F_percent': round(res.get(f'{ph.id}:{h.id}:Rf', float('nan')), 4),
        'R_F2_percent': round(res.get(f'{ph.id}:{h.id}:Rf^2', float('nan')), 4),
        'n_reflections': int(res.get(f'{ph.id}:{h.id}:Nref', 0)),
        'domain_size_um': round(ph.data['Histograms'][hname]['Size'][1][0], 4),
        'microstrain_1e6': round(ph.data['Histograms'][hname]['Mustrain'][1][0], 1),
        'march_dollase_001': round(ph.data['Histograms'][hname]['Pref.Ori.'][1], 4),
    })
json.dump(out, open(os.path.join(outdir, 'result.json'), 'w'), indent=2)
print(json.dumps(out, indent=2))
