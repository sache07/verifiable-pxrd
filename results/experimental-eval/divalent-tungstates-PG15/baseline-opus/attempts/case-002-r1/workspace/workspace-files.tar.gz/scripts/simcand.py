"""Simulate XRD for candidate COD entries and score against observed peak list."""
import gzip, json, sys, os
import numpy as np
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator

ROOT = '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif'
INFO = '<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz'


def cifpath(cid):
    return os.path.join(ROOT, cid[0], cid[1:3], cid[3:5], cid + '.cif')


OBS = np.array([float(v) for v in sys.argv[2].split(',')]) if len(sys.argv) > 2 else None

systems = sys.argv[1].split('+')
info = json.load(gzip.open(INFO))
calc = XRDCalculator(wavelength=1.540598)

rows = []
for s in systems:
    for formula, cid, sg, dev in info.get(s, []):
        p = cifpath(cid)
        try:
            st = Structure.from_file(p)
            ps = calc.get_pattern(st, two_theta_range=(9.9, 60))
        except Exception as e:
            print('FAIL', cid, formula, e)
            continue
        peaks = np.array(ps.x)
        ints = np.array(ps.y)
        strong = peaks[ints > 5]
        score = None
        if OBS is not None and len(strong):
            # fraction of strong calc peaks matched by an observed peak
            m = [np.min(np.abs(OBS - pp)) < 0.25 for pp in strong]
            score = np.mean(m)
        rows.append((score if score is not None else -1, formula, cid, sg, s,
                     ' '.join(f'{pp:.2f}' for pp in peaks[np.argsort(-ints)][:8])))

rows.sort(reverse=True)
for r in rows:
    print(f'{r[0]:5.2f} {r[1]:22s} {r[2]:>8s} sg={r[3]:<4} {r[4]:8s} {r[5]}')
