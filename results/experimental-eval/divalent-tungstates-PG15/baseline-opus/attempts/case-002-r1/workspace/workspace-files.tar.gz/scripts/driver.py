"""Staged Rietveld driver.

usage: driver.py OUT.gpx [--stages=a,b,c] cif1[:name] ...
Stages: scale, zero, size, cell, uvw, shift, strain, aniso, xyz, uiso
"""
import os, sys
import numpy as np

WS = '<ATTEMPT_WORKSPACE>'
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
import GSASIIscriptable as G2sc

DATA = os.path.join(WS, 'work/pattern.xye')
INST = os.path.join(WS, 'work/cuka.instprm')


def report(gpx, tag=''):
    h = gpx.histogram(0)
    msg = [f'=== {tag}: wR = {h.residuals["wR"]:.3f}%']
    for ph in gpx.phases():
        c = ph.data['General']['Cell'][1:8]
        msg.append(f'    {ph.name:14s} {c[0]:.5f} {c[1]:.5f} {c[2]:.5f} '
                   f'{c[3]:.3f} {c[4]:.3f} {c[5]:.3f} V={c[6]:.2f} '
                   f'sc={ph.data["Histograms"][h.name]["Scale"][0]:.5g}')
    ip = h.data['Instrument Parameters'][0]
    sp = h.data['Sample Parameters']
    msg.append('    inst U,V,W=%.2f,%.2f,%.2f X,Y=%.2f,%.2f Zero=%.4f Shift=%.1f' %
               (ip['U'][1], ip['V'][1], ip['W'][1], ip['X'][1], ip['Y'][1], ip['Zero'][1], sp['Shift'][0]))
    print('\n'.join(msg), flush=True)


def wtfrac(gpx):
    """Weight fractions over phases present in histogram 0."""
    h = gpx.histogram(0)
    out = {}
    for ph in gpx.phases():
        hap = ph.data['Histograms'][h.name]
        gen = ph.data['General']
        mass = gen.get('Mass') or G2sc.G2lat.getMass(gen)
        out[ph.name] = hap['Scale'][0] * mass
    s = sum(out.values())
    return {k: v / s for k, v in out.items()}


def run(gpxfile, cifs, stages, nbkg=10, lim=(9.95, 100.0), maxcyc=20):
    if os.path.exists(gpxfile):
        os.remove(gpxfile)
    gpx = G2sc.G2Project(newgpx=gpxfile)
    hist = gpx.add_powder_histogram(DATA, INST, fmthint='Topas xye')
    for spec in cifs:
        path, _, nm = spec.partition(':')
        gpx.add_phase(path, phasename=nm or os.path.basename(path).split('.')[0],
                      histograms=[hist], fmthint='CIF')
    hist.set_refinements({'Limits': list(lim),
                          'Background': {'type': 'chebyschev-1', 'no. coeffs': nbkg, 'refine': True}})
    gpx.data['Controls']['data']['max cyc'] = maxcyc
    for ph in gpx.phases():
        ph.set_HAP_refinements({'Scale': True})
    gpx.refine(); report(gpx, 'scale+bkg')

    for st in stages:
        if st == 'size':
            for ph in gpx.phases():
                ph.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}})
        elif st == 'strain':
            for ph in gpx.phases():
                ph.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}})
        elif st == 'anisosize':
            for ph in gpx.phases():
                ph.set_HAP_refinements({'Size': {'type': 'uniaxial', 'refine': True, 'direction': [0, 0, 1]}})
        elif st == 'anisostrain':
            for ph in gpx.phases():
                ph.set_HAP_refinements({'Mustrain': {'type': 'generalized', 'refine': True}})
        elif st == 'cell':
            for ph in gpx.phases():
                ph.set_refinements({'Cell': True})
        elif st == 'zero':
            hist.set_refinements({'Instrument Parameters': ['Zero']})
        elif st == 'shift':
            hist.set_refinements({'Sample Parameters': ['Shift']})
        elif st == 'trans':
            hist.set_refinements({'Sample Parameters': ['Transparency']})
        elif st == 'nozero':
            hist.data['Instrument Parameters'][0]['Zero'][1] = 0.0
            hist.data['Instrument Parameters'][0]['Zero'][2] = False
        elif st == 'uvw':
            hist.set_refinements({'Instrument Parameters': ['U', 'V', 'W']})
        elif st == 'w':
            hist.set_refinements({'Instrument Parameters': ['W']})
        elif st == 'xy':
            hist.set_refinements({'Instrument Parameters': ['X', 'Y']})
        elif st == 'xyz':
            for ph in gpx.phases():
                ph.set_refinements({'Atoms': {'all': 'XU'}})
        elif st == 'uiso':
            for ph in gpx.phases():
                ph.set_refinements({'Atoms': {'all': 'U'}})
        elif st == 'po':
            for ph in gpx.phases():
                ph.set_HAP_refinements({'Pref.Ori.': {'type': 'MD', 'refine': True}})
        elif st == 'sh':
            hist.set_refinements({'Instrument Parameters': ['SH/L']})
        else:
            raise SystemExit('unknown stage ' + st)
        gpx.refine(); report(gpx, '+' + st)
    print('weight fractions:', {k: round(v, 4) for k, v in wtfrac(gpx).items()})
    return gpx


if __name__ == '__main__':
    args = [a for a in sys.argv[1:]]
    out = args.pop(0)
    stages = ['zero', 'size', 'cell', 'strain', 'w']
    cifs = []
    for a in args:
        if a.startswith('--stages='):
            stages = a.split('=')[1].split(',')
        else:
            cifs.append(a)
    run(out, cifs, stages)
