"""Staged Rietveld refinement of the MnO + WO3 (900 C) product.

Phases: MnWO4 (wolframite/huebnerite, P2/c) + residual gamma-WO3 (P21/n).
Instrumental Lorentzian X,Y are held at 0 and the Lorentzian broadening is
carried by per-phase isotropic size/microstrain to avoid over-parameterisation.

Usage: refine_v2.py OUT.gpx [--wo3cell] [--wo3atoms] [--zero] [--rough] [--po] [--anisostrain]
"""
import os, sys
import GSASII.GSASIIscriptable as G2sc

W = os.path.abspath(os.path.dirname(__file__) + "/../work")
out, opts = sys.argv[1], sys.argv[2:]
for f in (out, out.replace('.gpx', '.bak0.gpx')):
    if os.path.exists(f):
        os.remove(f)
prj = G2sc.G2Project(newgpx=out)
h = prj.add_powder_histogram(os.path.join(W, "pattern.xye"),
                             os.path.join(W, "cuka.instprm"), fmthint="Topas xye")
ph1 = prj.add_phase(os.path.join(W, "MnWO4_start.cif"), phasename="MnWO4", histograms=[h])
ph2 = prj.add_phase(os.path.join(W, "WO3_start.cif"), phasename="WO3", histograms=[h])
prj.set_Controls("cycles", 20)

def step(label):
    prj.do_refinements([{}])
    print(f"=== {label}: Rwp = {h.get_wR():.4f}", flush=True)

h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 8, "refine": True},
                   "Sample Parameters": ["Scale"]})
step("bkg+scale")
for p in (ph1, ph2):
    p.set_HAP_refinements({"Scale": True})
step("fracs")
h.set_refinements({"Sample Parameters": ["Shift"]})
ph1.set_refinements({"Cell": True})
step("shift+cell(MnWO4)")
h.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
step("UVW")
for p in (ph1, ph2):
    p.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True},
                           "Mustrain": {"type": "isotropic", "refine": True}})
step("size+strain")
h.set_refinements({"Instrument Parameters": ["SH/L"]})
step("SH/L")
ph1.set_refinements({"Atoms": {"Mn1": "X", "W1": "X", "O1": "X", "O2": "X"}})
step("MnWO4 xyz")
ph1.set_refinements({"Atoms": {"Mn1": "U", "W1": "U", "O1": "U", "O2": "U"}})
step("MnWO4 Uiso")
h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 12, "refine": True}})
step("bkg12")

if "--wo3cell" in opts:          # a,b,c only; beta (A4) held
    ph2.set_refinements({"Cell": True})
    prj.add_HoldConstr(['1::A4'])
    step("cell(WO3) a,b,c")
if "--anisostrain" in opts:
    ph1.set_HAP_refinements({"Mustrain": {"type": "uniaxial", "refine": True, "direction": [0, 1, 0]}})
    step("uniaxial mustrain MnWO4")
if "--rough" in opts:
    h.data['Sample Parameters']['SurfRoughA'][1] = True
    h.data['Sample Parameters']['SurfRoughB'][1] = True
    step("SurfRough")
if "--zero" in opts:
    h.set_refinements({"Instrument Parameters": ["Zero"]})
    step("Zero")
if "--po" in opts:
    ph1.set_HAP_refinements({"Pref.Ori.": ["MD", True, [0, 1, 0]]})
    step("PO 010")
if "--wo3atoms" in opts:
    ph2.set_refinements({"Atoms": {a.label: "X" for a in ph2.atoms()}})
    step("WO3 xyz")

prj.save()
print("\n--- final state ---")
print("Rwp", h.get_wR())
print("shift(um)", h.data["Sample Parameters"]["Shift"][0],
      "roughness", [h.data['Sample Parameters'].get(k) for k in ('SurfRoughA', 'SurfRoughB')])
print("inst", {k: round(v[1], 5) for k, v in h.data["Instrument Parameters"][0].items()
               if k in ('U', 'V', 'W', 'X', 'Y', 'Z', 'SH/L', 'Zero')})
for p in prj.phases():
    c = p.get_cell()
    print(f"{p.name}: a={c['length_a']:.5f} b={c['length_b']:.5f} c={c['length_c']:.5f} "
          f"beta={c['angle_beta']:.4f} V={c['volume']:.3f}  scale={p.data['Histograms'][h.name]['Scale'][0]:.5f}")
    for a in p.atoms():
        print("   ", a.label, [round(v, 5) for v in a.coordinates], "Uiso", round(a.uiso, 5))
    hap = p.data['Histograms'][h.name]
    print("    size", hap['Size'][1][0], "mustrain", hap['Mustrain'][1][:2], "PO", hap['Pref.Ori.'][:4])
