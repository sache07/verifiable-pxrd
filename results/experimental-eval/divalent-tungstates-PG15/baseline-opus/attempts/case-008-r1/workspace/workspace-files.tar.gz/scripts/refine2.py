"""Staged Rietveld refinement: MnWO4 + WO3."""
import os, sys
import GSASII.GSASIIscriptable as G2sc

W = os.path.abspath(os.path.dirname(__file__) + "/../work")
gpx = os.path.join(W, "stage2.gpx")
for f in (gpx, gpx.replace('.gpx', '.bak0.gpx')):
    if os.path.exists(f):
        os.remove(f)
prj = G2sc.G2Project(newgpx=gpx)
h = prj.add_powder_histogram(os.path.join(W, "pattern.xye"),
                             os.path.join(W, "cuka.instprm"), fmthint="Topas xye")
ph1 = prj.add_phase(os.path.join(W, "MnWO4_start.cif"), phasename="MnWO4", histograms=[h])
ph2 = prj.add_phase(os.path.join(W, "WO3_start.cif"), phasename="WO3", histograms=[h])
h.set_refinements({"Limits": [9.95, 100.05]})
prj.set_Controls("cycles", 15)

def step(label):
    prj.do_refinements([{}])
    print(f"=== {label}: Rwp = {h.get_wR():.3f}", flush=True)

# 1 background + overall scale
h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 8, "refine": True},
                   "Sample Parameters": ["Scale"]})
step("bkg+scale")

# 2 phase fractions
for p in (ph1, ph2):
    p.set_HAP_refinements({"Scale": True})
step("phase fractions")

# 3 zero/shift + cells
h.set_refinements({"Sample Parameters": ["Shift"]})
for p in (ph1, ph2):
    p.set_refinements({"Cell": True})
step("cell+shift")

# 4 profile
h.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
step("UVW")
for p in (ph1, ph2):
    p.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True},
                           "Mustrain": {"type": "isotropic", "refine": True}})
step("size+strain")

print("shift", h.data["Sample Parameters"]["Shift"])
for p in (ph1, ph2):
    print(p.name, p.get_cell())
print(prj.get_LastFitResults() if hasattr(prj, 'get_LastFitResults') else '')
prj.save()
