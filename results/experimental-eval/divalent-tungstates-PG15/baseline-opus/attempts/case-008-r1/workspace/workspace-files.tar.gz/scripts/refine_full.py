"""Full staged Rietveld refinement of the MnO + WO3 (900 C) product.

Phases: MnWO4 (wolframite/huebnerite, P2/c) + residual gamma-WO3 (P21/n).
Usage: refine_full.py OUT.gpx [--po] [--zero] [--rough]
"""
import os, shutil, sys
import GSASII.GSASIIscriptable as G2sc

W = os.path.abspath(os.path.dirname(__file__) + "/../work")
out = sys.argv[1]
opts = sys.argv[2:]
for f in (out, out.replace('.gpx', '.bak0.gpx')):
    if os.path.exists(f):
        os.remove(f)
prj = G2sc.G2Project(newgpx=out)
h = prj.add_powder_histogram(os.path.join(W, "pattern.xye"),
                             os.path.join(W, "cuka.instprm"), fmthint="Topas xye")
ph1 = prj.add_phase(os.path.join(W, "MnWO4_start.cif"), phasename="MnWO4", histograms=[h])
ph2 = prj.add_phase(os.path.join(W, "WO3_start.cif"), phasename="WO3", histograms=[h])
prj.set_Controls("cycles", 20)

def step(label):
    prj.do_refinements([{}])
    print(f"=== {label}: Rwp = {h.get_wR():.4f}", flush=True)

# 1 background + histogram scale
h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 8, "refine": True},
                   "Sample Parameters": ["Scale"]})
step("bkg+scale")

# 2 phase fractions
for p in (ph1, ph2):
    p.set_HAP_refinements({"Scale": True})
step("fracs")

# 3 specimen displacement + main-phase cell (WO3 cell held at literature for now)
h.set_refinements({"Sample Parameters": ["Shift"]})
ph1.set_refinements({"Cell": True})
step("shift+cell(MnWO4)")

# 4 peak shape
h.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
step("UVW")
h.set_refinements({"Instrument Parameters": ["X", "Y"]})
step("XY")
for p in (ph1, ph2):
    p.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True},
                           "Mustrain": {"type": "isotropic", "refine": True}})
step("size+strain")

# 5 release WO3 cell
ph2.set_refinements({"Cell": True})
step("cell(WO3)")

# 6 structure of the major phase
ph1.set_refinements({"Atoms": {"Mn1": "X", "W1": "X", "O1": "X", "O2": "X"}})
step("MnWO4 xyz")
ph1.set_refinements({"Atoms": {"Mn1": "U", "W1": "U", "O1": "U", "O2": "U"}})
step("MnWO4 Uiso")

if "--shl" in opts:
    h.set_refinements({"Instrument Parameters": ["SH/L"]})
    step("SH/L")
if "--zero" in opts:
    h.set_refinements({"Instrument Parameters": ["Zero"]})
    step("Zero")
if "--rough" in opts:
    h.data['Sample Parameters']['SurfRoughA'][1] = True
    h.data['Sample Parameters']['SurfRoughB'][1] = True
    step("SurfRough")
if "--po" in opts:
    ph1.set_HAP_refinements({"Pref.Ori.": ["MD", True, [0, 1, 0]]})
    step("PO 010")

prj.save()
print("\n--- final state ---")
print("Rwp", h.get_wR())
print("shift(um)", h.data["Sample Parameters"]["Shift"][0],
      " roughness", [h.data['Sample Parameters'].get(k) for k in ('SurfRoughA', 'SurfRoughB')])
print("inst", {k: round(v[1], 5) for k, v in h.data["Instrument Parameters"][0].items()
               if k in ('U', 'V', 'W', 'X', 'Y', 'Z', 'SH/L', 'Zero')})
for p in prj.phases():
    c = p.get_cell()
    print(f"{p.name}: a={c['length_a']:.5f} b={c['length_b']:.5f} c={c['length_c']:.5f} "
          f"beta={c['angle_beta']:.4f} V={c['volume']:.3f}  scale={p.data['Histograms'][h.name]['Scale'][0]:.5f}")
    for a in p.atoms():
        print("   ", a.label, [round(v, 5) for v in a.coordinates], "Uiso", round(a.uiso, 5))
    hap = p.data['Histograms'][h.name]
    print("    size", hap['Size'][1][0], "mustrain", hap['Mustrain'][1][0])
