import sys, numpy as np
from scipy.signal import find_peaks

f = sys.argv[1]
d = np.loadtxt(f, delimiter=',', skiprows=1)
x, y = d[:, 0], d[:, 1]
print("range", x.min(), x.max(), "step", np.median(np.diff(x)), "npts", len(x))
print("Imax", y.max(), "Imin", y.min())

# crude background via rolling minimum + smoothing
from scipy.ndimage import minimum_filter1d, uniform_filter1d
w = 301
bg = minimum_filter1d(y, w)
bg = uniform_filter1d(bg, w)
ys = uniform_filter1d(y, 5)
net = ys - bg
pk, props = find_peaks(net, height=max(30, 0.01 * net.max()), prominence=0.008 * net.max(), distance=8)
lam = 1.540598
print(f"{'2th':>9} {'d':>8} {'Inet':>9} {'Irel':>6}")
hi = props['peak_heights']
order = np.argsort(-hi)
for i in pk:
    tt = x[i]
    dsp = lam / (2 * np.sin(np.radians(tt / 2)))
    print(f"{tt:9.4f} {dsp:8.4f} {net[i]:9.1f} {100*net[i]/net[pk].max():6.1f}")
