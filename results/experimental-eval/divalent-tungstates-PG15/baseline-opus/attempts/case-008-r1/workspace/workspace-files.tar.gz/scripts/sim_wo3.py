from pymatgen.core import Structure, Lattice
from pymatgen.analysis.diffraction.xrd import XRDCalculator

# gamma-WO3, P2_1/n (#14), origin choice standard; generators:
# (x,y,z) (-x,-y,-z) (1/2-x,1/2+y,1/2-z) (1/2+x,1/2-y,1/2+z)
def orbit(x, y, z):
    return [(x, y, z), (-x, -y, -z), (0.5 - x, 0.5 + y, 0.5 - z), (0.5 + x, 0.5 - y, 0.5 + z)]

asym = [("W", (0.2522, 0.0286, 0.2847)), ("W", (0.2468, 0.0307, 0.7806)),
        ("O", (0.0017, 0.0343, 0.2099)), ("O", (0.9959, 0.4654, 0.2192)),
        ("O", (0.2847, 0.2590, 0.2836)), ("O", (0.2122, 0.2566, 0.7333)),
        ("O", (0.2850, 0.0383, 0.0063)), ("O", (0.2881, 0.4885, 0.9930))]
sp, co = [], []
for el, p in asym:
    for q in orbit(*p):
        sp.append(el); co.append(q)
s = Structure(Lattice.monoclinic(7.3008, 7.5389, 7.6896, 90.892), sp, co, to_unit_cell=True)
s = s.merge_sites(tol=0.01, mode="delete")
print(s.composition)
c = XRDCalculator(wavelength=1.540598)
p = c.get_pattern(s, two_theta_range=(10, 55))
for x, i, hkl in zip(p.x, p.y, p.hkls):
    if i > 2:
        print(f"{x:8.3f} (+0.26 -> {x+0.26:7.3f}) {i:7.1f}  {[h['hkl'] for h in hkl][:3]}")
