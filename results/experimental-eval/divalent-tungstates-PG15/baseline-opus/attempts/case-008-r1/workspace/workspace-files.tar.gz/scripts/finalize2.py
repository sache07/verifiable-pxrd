"""Produce the deliverables (final.gpx, CIFs, fit.csv, result.json) from a refined project."""
import json, os, re, shutil, sys
import numpy as np
import GSASII.GSASIIscriptable as G2sc

ROOT = os.path.abspath(os.path.dirname(__file__) + "/..")
src = sys.argv[1]
gpx = os.path.join(ROOT, "final.gpx")
shutil.copy(src, gpx)
prj = G2sc.G2Project(gpx)
h = prj.histograms()[0]
phs = prj.phases()
lam1 = h.data['Instrument Parameters'][0]['Lam1'][1]

# ---------- profile ----------
d = h.data['data'][1]
x, yo, wt, yc, yb = [np.asarray(v) for v in (d[0], d[1], d[2], d[3], d[4])]
lo, hi = h.data['Limits'][1]
m = (x >= lo) & (x <= hi)
np.savetxt(os.path.join(ROOT, "fit.csv"), np.c_[x[m], yo[m], yc[m], (yo - yc)[m], yb[m]],
           fmt='%.6f,%.4f,%.4f,%.4f,%.4f',
           header='two_theta_deg,y_obs,y_calc,y_diff,y_background', comments='')

# ---------- statistics ----------
N = int(m.sum())
P = 0
for line in open(src.replace('.gpx', '.lst')):
    mm = re.search(r'No. of parameters:\s*(\d+)', line)
    if mm:
        P = int(mm.group(1))
dy = (yo - yc)[m]
Rwp = float(np.sqrt(np.sum(wt[m] * dy ** 2) / np.sum(wt[m] * yo[m] ** 2)))
Rp = float(np.sum(np.abs(dy)) / np.sum(yo[m]))
chi2red = float(np.sum(wt[m] * dy ** 2) / (N - P))
# background-subtracted (Bragg-only) R factors
num, den = np.abs(dy).sum(), np.abs(yo[m] - yb[m]).sum()
Rp_bkgsub = float(num / den)
Rwp_bkgsub = float(np.sqrt(np.sum(wt[m] * dy ** 2) / np.sum(wt[m] * (yo[m] - yb[m]) ** 2)))

# per-phase RF / cell esds from the .lst
rf = {}
cur = None
lines = open(src.replace('.gpx', '.lst')).read().split('\n')
pcur = None
for i, line in enumerate(lines):
    if line.startswith(' Result for phase:'):
        pcur = line.split(':')[1].strip()
    if pcur and line.strip().startswith('names :') and 'Volume' in line:
        esds = lines[i + 2].split(':')[1].split()
        rf.setdefault(pcur, {})['cell_esd'] = dict(zip(
            ['a', 'b', 'c', 'beta', 'volume'],
            [float(esds[0]), float(esds[1]), float(esds[2]), float(esds[3]), float(esds[4])]
            if len(esds) >= 5 else [None] * 5))
for line in open(src.replace('.gpx', '.lst')):
    mm = re.match(r' Phase: (.+) in histogram:', line)
    if mm:
        cur = mm.group(1).strip()
    if 'Final refinement RF' in line and cur:
        v = re.findall(r'([\d.]+)%', line)
        rf.setdefault(cur, {}).update({"RF_percent": float(v[0]), "RF2_percent": float(v[1])})
    if 'Weight fraction' in line and cur:
        rf.setdefault(cur, {})["weight_fraction_esd"] = float(line.split('sig')[-1])

# ---------- weight fractions ----------
wmass = {p.name: p.data['Histograms'][h.name]['Scale'][0] * p.data['General']['Mass'] for p in phs}
tot = sum(wmass.values())
wf = {k: v / tot for k, v in wmass.items()}

# ---------- CIFs ----------
cifs = {}
for p in phs:
    f = os.path.join(ROOT, f"{p.name}.cif")
    p.export_CIF(f)
    txt = open(f).read().replace("data_final", f"data_{p.name}")
    c = p.get_cell()
    sg = p.data['General']['SGData']['SpGrp']
    extra = f"""
# --- Rietveld refinement information (GSAS-II) ---
_diffrn_radiation_type                  'Cu K-alpha'
_diffrn_radiation_wavelength            {lam1:.6f}
_pd_proc_ls_prof_wR_factor              {Rwp*100:.3f}
_pd_proc_ls_prof_R_factor               {Rp*100:.3f}
_refine_ls_goodness_of_fit_all          {np.sqrt(chi2red):.3f}
_pd_proc_ls_background_function         'Chebyschev polynomial, 14 terms'
_refine_ls_number_parameters            {P}
_pd_phase_mass_percent                  {wf[p.name]*100:.2f}
_pd_proc_info_data_reduction
;
  Weight fraction normalised over the two modelled crystalline phases
  (MnWO4 + gamma-WO3); RF = {rf.get(p.name,{}).get('RF_percent','?')}%,
  RF^2 = {rf.get(p.name,{}).get('RF2_percent','?')}% for this phase.
;
"""
    open(f, 'w').write(txt.rstrip() + "\n" + extra)
    cifs[p.name] = os.path.basename(f)
    print("wrote", f, sg)

result = {
    "sample": "product of MnO + WO3 heated at 900 C",
    "method": "Rietveld refinement with GSAS-II (scriptable interface)",
    "radiation": {"source": "Cu K-alpha", "lambda_Kalpha1_A": lam1,
                  "lambda_Kalpha2_A": h.data['Instrument Parameters'][0]['Lam2'][1],
                  "I_Kalpha2/I_Kalpha1": h.data['Instrument Parameters'][0]['I(L2)/I(L1)'][1]},
    "two_theta_range_deg": [float(x[m].min()), float(x[m].max())],
    "n_phases": len(phs),
    "phases": [],
    "fit_statistics": {
        "Rwp_percent": round(Rwp * 100, 3),
        "Rp_percent": round(Rp * 100, 3),
        "Rwp_background_subtracted_percent": round(Rwp_bkgsub * 100, 3),
        "Rp_background_subtracted_percent": round(Rp_bkgsub * 100, 3),
        "chi2_reduced": round(chi2red, 3),
        "goodness_of_fit": round(float(np.sqrt(chi2red)), 3),
        "n_observations": N,
        "n_parameters": P,
    },
    "weight_fraction_basis": ("normalised over the two modelled crystalline phases; no internal "
                             "standard was available, so any amorphous content is not quantified"),
    "model_tests": {
        "two_phase_model": {"Rwp_percent": 3.975, "chi2": 17234.5, "GOF": 1.44},
        "MnWO4_only_control": {"Rwp_percent": 4.603, "chi2": 23107.1, "GOF": 1.67,
                               "comment": "removing WO3 degrades the fit strongly"},
        "MnO_trial_phase": {"refined_weight_fraction": 0.00067, "esd": 0.00052,
                            "comment": "consistent with zero; residual MnO below ~0.2 wt% (3 sigma)"},
        "Mn3O4_trial_phase": {"refined_weight_fraction": 0.0,
                              "comment": "scale refines to zero; no hausmannite detected"},
    },
    "files": {"profile": "fit.csv", "gsas2_project": "final.gpx", "report": "report.md",
              "figure": "fit.png"},
}
label = {"MnWO4": ("MnWO4", "wolframite-type MnWO4 (huebnerite)"),
         "WO3": ("WO3", "monoclinic gamma-WO3 (unreacted precursor)")}
for p in phs:
    c = p.get_cell()
    ce = p.get_cell_and_esd()[1] if hasattr(p, 'get_cell_and_esd') else {}
    result["phases"].append({
        "name": p.name,
        "formula": label.get(p.name, (p.name, ""))[0],
        "description": label.get(p.name, ("", ""))[1],
        "space_group": p.data['General']['SGData']['SpGrp'],
        "cif": cifs[p.name],
        "weight_fraction": round(wf[p.name], 4),
        "weight_fraction_esd_statistical": rf.get(p.name, {}).get("weight_fraction_esd"),
        "lattice_parameters": {k: round(c[k], 5) for k in
                               ('length_a', 'length_b', 'length_c', 'angle_alpha', 'angle_beta',
                                'angle_gamma', 'volume')},
        "lattice_parameter_esd_statistical": rf.get(p.name, {}).get("cell_esd"),
        "RF_percent": rf.get(p.name, {}).get("RF_percent"),
        "RF2_percent": rf.get(p.name, {}).get("RF2_percent"),
        "atoms": [{"label": a.label, "element": a.element, "xyz": [round(v, 5) for v in a.coordinates],
                   "occupancy": a.occupancy, "Uiso": round(a.uiso, 5)} for a in p.atoms()],
        "refined": ("cell, atomic coordinates, Uiso, phase scale, isotropic size, "
                    "March-Dollase [010] preferred orientation"
                    if p.name == "MnWO4" else
                    "cell (a,b,c; beta fixed) and phase scale only; atomic coordinates and Uiso "
                    "held at the literature gamma-WO3 values"),
    })
json.dump(result, open(os.path.join(ROOT, "result.json"), "w"), indent=2)
print(json.dumps(result, indent=2))
prj.save()
