"""Continue refinement from stage2: profile detail, atoms, Uiso."""
import os, shutil, sys
import GSASII.GSASIIscriptable as G2sc

W = os.path.abspath(os.path.dirname(__file__) + "/../work")
src, gpx = os.path.join(W, "stage2.gpx"), os.path.join(W, "stage3.gpx")
shutil.copy(src, gpx)
prj = G2sc.G2Project(gpx)
h = prj.histograms()[0]
ph1, ph2 = prj.phases()
prj.set_Controls("cycles", 15)

def step(label):
    prj.do_refinements([{}])
    print(f"=== {label}: Rwp = {h.get_wR():.3f}", flush=True)

h.set_refinements({"Instrument Parameters": ["X", "Y", "SH/L"]})
step("XY+SHL")
ph1.set_refinements({"Atoms": {"all": "XU"}})
step("MnWO4 atoms")
h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 12, "refine": True}})
step("bkg12")
ph2.set_refinements({"Atoms": {"all": "X"}})
step("WO3 atoms")
for p in (ph1, ph2):
    print(p.name, p.get_cell())
    for a in p.atoms():
        print("  ", a.label, [round(v, 4) for v in a.coordinates], round(a.uiso, 4))
print("shift", h.data["Sample Parameters"]["Shift"])
print("inst", {k: v[1] for k, v in h.data["Instrument Parameters"][0].items() if k in ('U','V','W','X','Y','SH/L','Zero','Polariz.')})
print("frac", [(p.name, p.data['Histograms'][h.name]['Scale']) for p in prj.phases()])
prj.save()
