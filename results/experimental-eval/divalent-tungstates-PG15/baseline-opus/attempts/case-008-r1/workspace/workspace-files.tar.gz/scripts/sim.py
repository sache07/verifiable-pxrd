"""Simulate powder patterns for candidate structures and compare with observed peaks."""
import sys
from pymatgen.core import Structure, Lattice
from pymatgen.analysis.diffraction.xrd import XRDCalculator

def mnwo4(a=4.8238, b=5.7504, c=4.9903, beta=91.18):
    lat = Lattice.monoclinic(a, b, c, beta)
    sp, co = [], []
    # P2/c (#13) generators: (x,y,z) (-x,y,1/2-z) (-x,-y,-z) (x,-y,1/2+z)
    def orbit(x, y, z):
        return [(x, y, z), (-x, y, 0.5 - z), (-x, -y, -z), (x, -y, 0.5 + z)]
    for el, pos in [("Mn", (0.5, 0.6853, 0.25)), ("W", (0.0, 0.1807, 0.25)),
                    ("O", (0.2103, 0.1024, 0.9401)), ("O", (0.2588, 0.3754, 0.3927))]:
        for p in orbit(*pos):
            sp.append(el); co.append(p)
    return Structure(lat, sp, co, to_unit_cell=True).get_reduced_structure() if False else Structure(lat, sp, co, to_unit_cell=True)

if __name__ == "__main__":
    s = mnwo4()
    s = s.merge_sites(tol=0.01, mode="delete")
    print(s.composition, s.lattice)
    c = XRDCalculator(wavelength=1.540598)
    p = c.get_pattern(s, two_theta_range=(10, 60))
    for x, i, hkl in zip(p.x, p.y, p.hkls):
        if i > 1:
            print(f"{x:8.3f} {i:7.1f}  {[h['hkl'] for h in hkl]}")
