import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

d = np.genfromtxt('fit.csv', delimiter=',', names=True)
x, yo, yc, dy = d['two_theta_deg'], d['y_obs'], d['y_calc'], d['y_diff']
dn = np.genfromtxt('work/fit_nowo3.csv', delimiter=',', names=True)

fig = plt.figure(figsize=(11, 8))
gs = fig.add_gridspec(2, 2, height_ratios=[1.6, 1])
ax0 = fig.add_subplot(gs[0, :])
m = np.ones(len(x), bool)
off = -0.11 * yo.max()
ax0.plot(x, yo, 'k.', ms=1.4, label='observed')
ax0.plot(x, yc, 'r-', lw=0.7, label='calculated')
ax0.plot(x, dy + off, 'b-', lw=0.6, label='difference')
ax0.axhline(off, color='0.7', lw=0.5)
ax0.set_xlim(9.9, 100.1)
ax0.set_xlabel(r'2$\theta$ (deg, Cu K$\alpha_{1,2}$)')
ax0.set_ylabel('counts')
ax0.legend(fontsize=8)
ax0.set_title(r'MnO + WO$_3$, 900 $^\circ$C: two-phase Rietveld fit  '
              r'(MnWO$_4$ 97.8 wt% + $\gamma$-WO$_3$ 2.2 wt%), R$_{wp}$ = 3.98%')

for k, (lo, hi) in enumerate([(22.5, 25.6), (32.6, 35.4)]):
    a = fig.add_subplot(gs[1, k])
    m = (x >= lo) & (x <= hi)
    a.plot(x[m], yo[m], 'k.', ms=2.5, label='observed')
    a.plot(x[m], yc[m], 'r-', lw=0.9, label='calculated (MnWO$_4$+WO$_3$)')
    a.plot(dn['two_theta_deg'][m], dn['y_calc'][m], '-', color='green', lw=0.9,
           label='calculated (MnWO$_4$ only)')
    a.set_xlim(lo, hi)
    a.set_yscale('log')
    a.set_xlabel(r'2$\theta$ (deg)')
    a.set_ylabel('counts (log)')
    if k == 0:
        a.legend(fontsize=7, loc='upper left')
    a.set_title('WO$_3$ lines: ' + ('(002), (200)' if k == 0 else '(022), (20-2), (202)/(220)'), fontsize=9)
plt.tight_layout()
plt.savefig('fit.png', dpi=130)
print('ok')
