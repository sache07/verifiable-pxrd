"""Produce the deliverables from the final GSAS-II project."""
import json, os, shutil, sys
import numpy as np
import GSASII.GSASIIscriptable as G2sc

ROOT = os.path.abspath(os.path.dirname(__file__) + "/..")
src = sys.argv[1]
gpx = os.path.join(ROOT, "final.gpx")
if os.path.abspath(src) != gpx:
    shutil.copy(src, gpx)
prj = G2sc.G2Project(gpx)
h = prj.histograms()[0]
phs = prj.phases()

# ---- profile ----
d = h.data['data'][1]
x, yo, yc, yb = [np.asarray(v) for v in (d[0], d[1], d[3], d[4])]
lo, hi = h.data['Limits'][1]
m = (x >= lo) & (x <= hi)
np.savetxt(os.path.join(ROOT, "fit.csv"), np.c_[x[m], yo[m], yc[m], (yo - yc)[m], yb[m]],
           fmt='%.6f,%.3f,%.3f,%.3f,%.3f',
           header='two_theta_deg,y_obs,y_calc,y_diff,y_background', comments='')

# ---- CIFs ----
names = {}
for p in phs:
    f = os.path.join(ROOT, f"{p.name}.cif")
    p.export_CIF(f)
    names[p.name] = os.path.basename(f)
    print("wrote", f)

# ---- weight fractions (GSAS-II convention: scale * unit-cell mass) ----
w = {p.name: p.data['Histograms'][h.name]['Scale'][0] * p.data['General']['Mass'] for p in phs}
tot = sum(w.values())
wf = {k: v / tot for k, v in w.items()}
print(wf)

# esds from the .lst produced by the last refinement
lst = src.replace('.gpx', '.lst')
esd = {}
if os.path.exists(lst):
    cur = None
    for line in open(lst):
        if line.startswith(' Result for phase:'):
            cur = line.split(':')[1].strip()
        if 'Weight fraction' in line and cur:
            esd[cur] = float(line.split('sig')[-1])
print("esd", esd)

res = {
    "phases": [
        {"name": p.name,
         "formula": p.data['General']['Formula'] if 'Formula' in p.data['General'] else None,
         "cif": names[p.name],
         "weight_fraction": round(wf[p.name], 5),
         "weight_fraction_esd": esd.get(p.name)}
        for p in phs],
    "fit_statistics": {"Rwp_percent": round(h.get_wR(), 3)},
}
print(json.dumps(res, indent=2))
json.dump(res, open(os.path.join(ROOT, "work", "result_core.json"), "w"), indent=2)
prj.save()
