"""Fit isolated peaks with a Ka1/Ka2 pseudo-Voigt doublet to get FWHM & eta vs 2theta."""
import numpy as np
from scipy.optimize import curve_fit

d = np.loadtxt('inputs/pattern.csv', delimiter=',', skiprows=1)
X, Y = d[:, 0], d[:, 1]
lam1, lam2, R = 1.540598, 1.544426, 0.5

def pv(x, x0, fwhm, eta):
    g = np.exp(-4 * np.log(2) * ((x - x0) / fwhm) ** 2) * (2 / fwhm) * np.sqrt(np.log(2) / np.pi)
    l = (2 / (np.pi * fwhm)) / (1 + 4 * ((x - x0) / fwhm) ** 2)
    return eta * l + (1 - eta) * g

def model(x, x0, fwhm, eta, amp, b0, b1):
    th = np.radians(x0 / 2)
    x02 = 2 * np.degrees(np.arcsin(np.sin(th) * lam2 / lam1))
    return amp * (pv(x, x0, fwhm, eta) + R * pv(x, x02, fwhm, eta)) + b0 + b1 * (x - x0)

print(f"{'2th':>8} {'fwhm':>7} {'eta':>6} {'tanth':>7}")
for c in [18.68, 41.18, 48.50, 57.86, 61.65, 67.95, 76.44, 84.72, 97.43]:
    m = (X > c - 1.0) & (X < c + 1.0)
    x, y = X[m], Y[m]
    p0 = [c, 0.15, 0.5, max(y) * 0.2, np.percentile(y, 10), 0]
    try:
        p, _ = curve_fit(model, x, y, p0=p0, sigma=np.sqrt(np.maximum(y, 1)),
                         bounds=([c - .4, .02, 0, 0, 0, -1e3], [c + .4, 1.0, 1, 1e8, 1e5, 1e3]))
        print(f"{p[0]:8.3f} {p[1]:7.4f} {p[2]:6.3f} {np.tan(np.radians(p[0]/2)):7.4f}")
    except Exception as e:
        print(c, "fail", e)
