import sys, numpy as np
from scipy.signal import find_peaks
from scipy.ndimage import minimum_filter1d, uniform_filter1d

d = np.loadtxt(sys.argv[1], delimiter=',', skiprows=1)
x, y = d[:, 0], d[:, 1]
w = 301
bg = uniform_filter1d(minimum_filter1d(y, w), w)
ys = uniform_filter1d(y, 5)
net = ys - bg
pk, props = find_peaks(net, height=max(30, 0.008 * net.max()), prominence=0.006 * net.max(), distance=6)
tt = x[pk]; h = net[pk]
lam1, lam2 = 1.540598, 1.544426
# predicted alpha2 position for each peak
th = np.radians(tt / 2)
tt2 = 2 * np.degrees(np.arcsin(np.clip(np.sin(th) * lam2 / lam1, -1, 1)))
is_a2 = np.zeros(len(tt), bool)
for i in range(len(tt)):
    for j in range(len(tt)):
        if i == j: continue
        if abs(tt[i] - tt2[j]) < 0.06 and h[i] < 0.75 * h[j]:
            is_a2[i] = True
print(f"{'2th':>9} {'d(a1)':>8} {'Inet':>9} {'Irel':>6}  flag")
for i in range(len(tt)):
    dsp = lam1 / (2 * np.sin(np.radians(tt[i] / 2)))
    print(f"{tt[i]:9.4f} {dsp:8.4f} {h[i]:9.1f} {100*h[i]/h.max():6.1f}  {'a2' if is_a2[i] else ''}")
np.savetxt(sys.argv[2], np.c_[tt[~is_a2], h[~is_a2]], fmt='%.5f %.1f')
