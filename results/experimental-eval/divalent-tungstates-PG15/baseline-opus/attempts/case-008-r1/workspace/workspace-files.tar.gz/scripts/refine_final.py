"""Final staged Rietveld refinement of the MnO + WO3 (900 C) product.

Phases: MnWO4 (wolframite/huebnerite, P2/c) + residual gamma-WO3 (P21/n).

Model choices (documented in report.md):
  * Specimen displacement ("Shift") accounts for the ~+0.3 deg cos(theta)
    offset of the observed peaks; Zero is held at 0 (the two are degenerate
    and refining Zero gave no improvement).
  * Gaussian U,V,W + FCJ axial-divergence asymmetry SH/L are refined;
    instrumental Lorentzian X,Y are held at 0 and the Lorentzian part is
    carried by an isotropic crystallite size that is constrained to be the
    same for both phases (WO3 is too weak to support its own broadening);
    microstrain is held at ~0 (it refines negative otherwise).
  * Suortti surface-roughness A,B model the low-angle intensity deficit of
    this strongly absorbing specimen (without it Uiso refines negative).
  * Only the major phase's coordinates/Uiso are refined; the WO3 structure is
    held at the literature gamma-WO3 model, with only its cell (a,b,c) free.

Usage: refine_final.py OUT.gpx
"""
import os, sys
import GSASII.GSASIIscriptable as G2sc

W = os.path.abspath(os.path.dirname(__file__) + "/../work")
out = sys.argv[1]
for f in (out, out.replace('.gpx', '.bak0.gpx')):
    if os.path.exists(f):
        os.remove(f)
prj = G2sc.G2Project(newgpx=out)
h = prj.add_powder_histogram(os.path.join(W, "pattern.xye"),
                             os.path.join(W, "cuka.instprm"), fmthint="Topas xye")
ph1 = prj.add_phase(os.path.join(W, "MnWO4_start.cif"), phasename="MnWO4", histograms=[h])
ph2 = prj.add_phase(os.path.join(W, "WO3_p21n.cif"), phasename="WO3", histograms=[h])
for p, sg in ((ph1, 'P 2/c'), (ph2, 'P 21/n')):
    assert p.data['General']['SGData']['SpGrp'] == sg, (p.name, p.data['General']['SGData']['SpGrp'])
prj.set_Controls("cycles", 12)
h.data['Sample Parameters']['Scale'] = [1.0, False]      # redundant with phase scales
h.data['Instrument Parameters'][0]['SH/L'][1] = 0.07     # realistic axial-divergence start

def step(label):
    prj.do_refinements([{}])
    print(f"=== {label}: Rwp = {h.get_wR():.4f}", flush=True)

h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 8, "refine": True}})
for p in (ph1, ph2):
    p.set_HAP_refinements({"Scale": True})
step("bkg+fracs")

h.set_refinements({"Sample Parameters": ["Shift"]})
ph1.set_refinements({"Cell": True})
step("shift+cell(MnWO4)")

h.set_refinements({"Instrument Parameters": ["U", "V", "W", "SH/L"]})
step("UVW+SH/L")

for p in (ph1, ph2):
    p.data['Histograms'][h.name]['Mustrain'][1][0] = 1.0
    p.data['Histograms'][h.name]['Size'][1][0] = 0.2
    p.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
prj.add_EquivConstr(['0:0:Size;i', '1:0:Size;i'])
step("size")

h.data['Sample Parameters']['SurfRoughA'] = [0.05, True]
h.data['Sample Parameters']['SurfRoughB'] = [0.10, True]
step("surface roughness")

# Re-seed the Gaussian width terms: refining U,V,W together from a cold start
# can fall into a pathological (negative-width) minimum; these values come from
# the best minimum found when U,V,W were released after the asymmetry.
for k, v in (("U", 62.0), ("V", -1.3), ("W", 0.3)):
    ip = h.data['Instrument Parameters'][0]
    ip[k][1] = v
step("re-seed UVW")

ph1.set_refinements({"Atoms": {a.label: "XU" for a in ph1.atoms()}})
step("MnWO4 xyz+Uiso")

ph1.set_HAP_refinements({"Pref.Ori.": ["MD", True, [0, 1, 0]]})
step("PO [010]")

ph2.set_refinements({"Cell": True})
prj.add_HoldConstr(['1::A4'])          # hold WO3 beta
step("cell(WO3) a,b,c")

h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 14, "refine": True}})
step("bkg14")
step("converge")

prj.save()
print("\n--- final state ---")
sp, ip = h.data['Sample Parameters'], h.data['Instrument Parameters'][0]
print("Rwp", h.get_wR())
print("shift(um)", round(sp['Shift'][0], 1), "rough", [round(sp[k][0], 4) for k in ('SurfRoughA', 'SurfRoughB')])
print("inst", {k: round(ip[k][1], 5) for k in ('Zero', 'U', 'V', 'W', 'X', 'Y', 'SH/L', 'Polariz.')})
wt = {}
for p in prj.phases():
    c, hp = p.get_cell(), p.data['Histograms'][h.name]
    wt[p.name] = hp['Scale'][0] * p.data['General']['Mass']
    print(f"{p.name} [{p.data['General']['SGData']['SpGrp']}]: a={c['length_a']:.5f} b={c['length_b']:.5f} "
          f"c={c['length_c']:.5f} beta={c['angle_beta']:.4f} V={c['volume']:.3f} scale={hp['Scale'][0]:.5f} "
          f"size={hp['Size'][1][0]:.4f} mustr={hp['Mustrain'][1][0]:.1f} PO={hp['Pref.Ori.'][1]:.4f}")
    for a in p.atoms():
        print("   ", a.label, [round(v, 5) for v in a.coordinates], "Uiso", round(a.uiso, 5))
tot = sum(wt.values())
print("weight fractions", {k: round(v / tot, 5) for k, v in wt.items()})
