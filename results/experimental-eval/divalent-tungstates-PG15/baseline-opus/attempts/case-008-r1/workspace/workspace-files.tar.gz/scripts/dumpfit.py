"""Dump obs/calc/diff from a .gpx and report the largest residual features."""
import os, sys, numpy as np
import GSASII.GSASIIscriptable as G2sc

prj = G2sc.G2Project(sys.argv[1])
h = prj.histograms()[0]
d = h.data['data'][1]
x, yo, w, yc, yb = d[0], d[1], d[2], d[3], d[4]
m = ~x.mask if hasattr(x, 'mask') else np.ones(len(x), bool)
x, yo, yc, yb = [np.asarray(v)[m] for v in (x, yo, yc, yb)]
diff = yo - yc
if len(sys.argv) > 2:
    np.savetxt(sys.argv[2], np.c_[x, yo, yc, diff, yb],
               fmt='%.5f,%.4f,%.4f,%.4f,%.4f',
               header='two_theta_deg,y_obs,y_calc,y_diff,y_background', comments='')
print("Rwp", h.get_wR(), "nobs", len(x))
print("phase fracs", [(p.name, p.data['Histograms'][h.name]['Scale'][0]) for p in prj.phases()])
# residual humps: smooth diff and find positives
from scipy.ndimage import uniform_filter1d
ds = uniform_filter1d(diff, 9)
sig = np.sqrt(np.maximum(yo, 1))
print("worst positive residual regions (smoothed diff / sqrt(yo)):")
idx = np.argsort(-ds)[:400]
seen = []
for i in idx:
    if any(abs(x[i] - s) < 0.4 for s in seen):
        continue
    seen.append(x[i])
    print(f"  2th={x[i]:8.3f}  diff={ds[i]:8.1f}  obs={yo[i]:9.1f}  n_sigma={ds[i]/sig[i]:6.1f}")
    if len(seen) >= 18:
        break
