"""Staged Rietveld refinement of the MnO + WO3 (900 C) product.

Phases: MnWO4 (wolframite/huebnerite, P2/c) + residual gamma-WO3 (P21/n).

Profile strategy (lab Cu data, no calibrated instrument profile supplied):
  * Gaussian U,V,W + axial asymmetry SH/L are refined as "instrumental".
  * Instrumental Lorentzian X,Y held at zero; Lorentzian broadening is carried
    by per-phase isotropic crystallite size + microstrain, with the minor WO3
    phase constrained to the same size/strain as MnWO4 (it is too weak to
    support independent broadening parameters).

Usage: refine_v3.py OUT.gpx [--wo3cell] [--zero] [--rough] [--po] [--freewo3broad]
"""
import os, sys
import GSASII.GSASIIscriptable as G2sc

W = os.path.abspath(os.path.dirname(__file__) + "/../work")
out, opts = sys.argv[1], sys.argv[2:]
for f in (out, out.replace('.gpx', '.bak0.gpx')):
    if os.path.exists(f):
        os.remove(f)
prj = G2sc.G2Project(newgpx=out)
h = prj.add_powder_histogram(os.path.join(W, "pattern.xye"),
                             os.path.join(W, "cuka.instprm"), fmthint="Topas xye")
ph1 = prj.add_phase(os.path.join(W, "MnWO4_start.cif"), phasename="MnWO4", histograms=[h])
ph2 = prj.add_phase(os.path.join(W, "WO3_start.cif"), phasename="WO3", histograms=[h])
prj.set_Controls("cycles", 12)

def step(label):
    prj.do_refinements([{}])
    print(f"=== {label}: Rwp = {h.get_wR():.4f}", flush=True)

h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 8, "refine": True},
                   "Sample Parameters": ["Scale"]})
step("bkg+scale")
for p in (ph1, ph2):
    p.set_HAP_refinements({"Scale": True})
step("fracs")
h.set_refinements({"Sample Parameters": ["Shift"]})
ph1.set_refinements({"Cell": True})
step("shift+cell(MnWO4)")
h.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
step("UVW")

# Lorentzian broadening via phase size/mustrain, WO3 tied to MnWO4
for p in (ph1, ph2):
    p.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True},
                           "Mustrain": {"type": "isotropic", "refine": True}})
if "--freewo3broad" not in opts:
    prj.add_EquivConstr(['0:0:Size;i', '1:0:Size;i'])
    prj.add_EquivConstr(['0:0:Mustrain;i', '1:0:Mustrain;i'])
step("size+strain")
h.set_refinements({"Instrument Parameters": ["SH/L"]})
step("SH/L")
ph1.set_refinements({"Atoms": {"Mn1": "X", "W1": "X", "O1": "X", "O2": "X"}})
step("MnWO4 xyz")
ph1.set_refinements({"Atoms": {"Mn1": "U", "W1": "U", "O1": "U", "O2": "U"}})
step("MnWO4 Uiso")
h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 12, "refine": True}})
step("bkg12")

if "--wo3cell" in opts:
    ph2.set_refinements({"Cell": True})
    prj.add_HoldConstr(['1::A4'])
    step("cell(WO3) a,b,c")
if "--rough" in opts:
    h.data['Sample Parameters']['SurfRoughA'][1] = True
    h.data['Sample Parameters']['SurfRoughB'][1] = True
    step("SurfRough")
if "--zero" in opts:
    h.set_refinements({"Instrument Parameters": ["Zero"]})
    step("Zero")
if "--po" in opts:
    ph1.set_HAP_refinements({"Pref.Ori.": ["MD", True, [0, 1, 0]]})
    step("PO 010")

prj.save()
print("\n--- final state ---")
print("Rwp", h.get_wR())
print("shift(um)", h.data["Sample Parameters"]["Shift"][0],
      "roughness", [h.data['Sample Parameters'].get(k) for k in ('SurfRoughA', 'SurfRoughB')])
print("inst", {k: round(v[1], 5) for k, v in h.data["Instrument Parameters"][0].items()
               if k in ('U', 'V', 'W', 'X', 'Y', 'Z', 'SH/L', 'Zero')})
for p in prj.phases():
    c = p.get_cell()
    print(f"{p.name}: a={c['length_a']:.5f} b={c['length_b']:.5f} c={c['length_c']:.5f} "
          f"beta={c['angle_beta']:.4f} V={c['volume']:.3f}  scale={p.data['Histograms'][h.name]['Scale'][0]:.5f}")
    for a in p.atoms():
        print("   ", a.label, [round(v, 5) for v in a.coordinates], "Uiso", round(a.uiso, 5))
    hap = p.data['Histograms'][h.name]
    print("    size", hap['Size'][1][0], "mustrain", hap['Mustrain'][1][0], "PO", hap['Pref.Ori.'][:4])
