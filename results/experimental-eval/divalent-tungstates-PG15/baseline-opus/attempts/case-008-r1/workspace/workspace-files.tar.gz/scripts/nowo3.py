"""Control test: same model with the WO3 phase removed (scale -> 0, held)."""
import shutil, sys
import GSASII.GSASIIscriptable as G2sc
shutil.copy(sys.argv[1], sys.argv[2])
prj = G2sc.G2Project(sys.argv[2])
h = prj.histograms()[0]
ph2 = prj.phases()[1]
hap = ph2.data['Histograms'][h.name]
hap['Scale'] = [0.0, False]
ph2.clear_refinements({"Cell": False, "Atoms": {a.label: "XU" for a in ph2.atoms()}})
ph2.clear_HAP_refinements({"Scale": False, "Size": {"refine": False},
                           "Mustrain": {"refine": False}, "Pref.Ori.": {"refine": False}})
prj.data['Constraints']['data'] = []
prj.set_Controls("cycles", 8)
prj.do_refinements([{}])
print("=== MnWO4 only: Rwp =", round(h.get_wR(), 4))
prj.save()
