"""Stage-1 Rietveld: MnWO4 + WO3 against the measured Cu-Kalpha pattern."""
import os, sys, numpy as np
import GSASII.GSASIIscriptable as G2sc

W = os.path.abspath(os.path.dirname(__file__) + "/../work")
gpx = os.path.join(W, "stage1.gpx")
if os.path.exists(gpx):
    os.remove(gpx)
prj = G2sc.G2Project(newgpx=gpx)
hist = prj.add_powder_histogram(os.path.join(W, "pattern.xye"),
                                os.path.join(W, "cuka.instprm"), fmthint="Topas xye")
ph1 = prj.add_phase(os.path.join(W, "MnWO4_start.cif"), phasename="MnWO4", histograms=[hist])
ph2 = prj.add_phase(os.path.join(W, "WO3_start.cif"), phasename="WO3", histograms=[hist])

hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 6, "refine": True},
                      "Limits": [9.95, 100.05]})
prj.set_Controls("cycles", 12)
prj.do_refinements([{}])
print("Rwp after bkg", hist.get_wR())

# cell + sample displacement
hist.set_refinements({"Sample Parameters": ["Shift"]})
for p in (ph1, ph2):
    p.set_refinements({"Cell": True})
prj.do_refinements([{}])
print("Rwp after cell", hist.get_wR())
print("shift", hist.data["Sample Parameters"]["Shift"])
for p in (ph1, ph2):
    print(p.name, p.get_cell())
prj.save()
