import sys, numpy as np
from scipy.ndimage import minimum_filter1d, uniform_filter1d
d = np.loadtxt(sys.argv[1], delimiter=',', skiprows=1)
x, y = d[:, 0], d[:, 1]
bg = uniform_filter1d(minimum_filter1d(y, 301), 301)
net = uniform_filter1d(y, 7) - bg
for rng in sys.argv[2:]:
    lo, hi = [float(v) for v in rng.split('-')]
    m = (x >= lo) & (x <= hi)
    xs, ns = x[m], net[m]
    # print binned maxima every 0.1 deg
    out = []
    for i in range(0, len(xs), 9):
        out.append(f"{xs[i]:.2f}:{ns[i:i+9].max():.0f}")
    print(f"--- {lo}-{hi}  bgmax={bg[m].mean():.0f}")
    print(" ".join(out))
