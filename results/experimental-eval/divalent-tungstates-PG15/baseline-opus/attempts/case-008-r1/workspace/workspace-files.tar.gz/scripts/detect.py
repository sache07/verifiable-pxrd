"""Detection-limit test: add a trial phase to the converged model and refine only its scale.

detect.py SRC.gpx OUT.gpx trial.cif name
"""
import shutil, sys, os
import GSASII.GSASIIscriptable as G2sc

src, out, cif, name = sys.argv[1:5]
for f in (out, out.replace('.gpx', '.bak0.gpx')):
    if os.path.exists(f):
        os.remove(f)
shutil.copy(src, out)
prj = G2sc.G2Project(out)
h = prj.histograms()[0]
base = {p.name: p.data['Histograms'][h.name]['Scale'][0] * p.data['General']['Mass'] for p in prj.phases()}
p3 = prj.add_phase(cif, phasename=name, histograms=[h])
hp = p3.data['Histograms'][h.name]
hp['Scale'] = [0.01, True]
hp['Size'][1][0] = prj.phases()[0].data['Histograms'][h.name]['Size'][1][0]
hp['Mustrain'][1][0] = 1.0
prj.set_Controls("cycles", 8)
prj.do_refinements([{}])
print("=== with", name, ": Rwp =", round(h.get_wR(), 4))
w = {p.name: p.data['Histograms'][h.name]['Scale'][0] * p.data['General']['Mass'] for p in prj.phases()}
tot = sum(w.values())
print({k: round(v / tot, 5) for k, v in w.items()})
print("scale", hp['Scale'])
prj.save()
for line in open(out.replace('.gpx', '.lst')):
    if 'Weight fraction' in line:
        print(line.rstrip())
