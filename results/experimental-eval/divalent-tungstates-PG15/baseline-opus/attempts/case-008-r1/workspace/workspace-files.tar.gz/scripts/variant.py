"""Explore model variants starting from an existing .gpx.

variant.py SRC.gpx OUT.gpx opt1 opt2 ...
options: zero, rough, pola, fixU, freeY, wo3cell, po, shl, cycles=N
"""
import os, shutil, sys
import GSASII.GSASIIscriptable as G2sc

src, out = sys.argv[1], sys.argv[2]
opts = sys.argv[3:]
shutil.copy(src, out)
prj = G2sc.G2Project(out)
h = prj.histograms()[0]
phs = prj.phases()
ph1, ph2 = phs[0], phs[1]
ncyc = 8
for o in opts:
    if o.startswith("cycles="):
        ncyc = int(o.split("=")[1])
prj.set_Controls("cycles", ncyc)

def wtfrac():
    tot, ws = 0.0, []
    for p in phs:
        m = sum(a.element_mass if hasattr(a, 'element_mass') else 0 for a in p.atoms())
        ws.append(p.data['Histograms'][h.name]['Scale'][0] * p.data['General']['Mass'])
    s = sum(ws)
    return [(p.name, round(w / s, 5)) for p, w in zip(phs, ws)]

def step(label):
    prj.do_refinements([{}])
    print(f"=== {label}: Rwp = {h.get_wR():.4f}  wt% {wtfrac()}", flush=True)

if "fixU" in opts:
    lit = {"Mn1": 0.006, "W1": 0.004, "O1": 0.008, "O2": 0.008}
    for a in ph1.atoms():
        if a.label in lit:
            a.uiso = lit[a.label]
    ph1.clear_refinements({"Atoms": {a.label: "U" for a in ph1.atoms()}})
if "freeY" in opts:
    for p in phs:
        p.clear_HAP_refinements({"Size": {"refine": False}, "Mustrain": {"refine": False}})
        p.data['Histograms'][h.name]['Size'][1][0] = 1.0
        p.data['Histograms'][h.name]['Mustrain'][1][0] = 1000.0
    h.set_refinements({"Instrument Parameters": ["X", "Y"]})
if "lorsize" in opts:
    # keep the Lorentzian broadening physical: microstrain -> ~0, size free
    for p in phs:
        p.clear_HAP_refinements({"Mustrain": {"refine": False}})
        p.data['Histograms'][h.name]['Mustrain'][1][0] = 1.0
        p.data['Histograms'][h.name]['Size'][1][0] = 0.3
        p.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    h.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
if "mustr" in opts:
    for p in phs:
        p.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        if p.data['Histograms'][h.name]['Mustrain'][1][0] < 1.1:
            p.data['Histograms'][h.name]['Mustrain'][1][0] = 500.
if "atoms" in opts:
    ph1.set_refinements({"Atoms": {a.label: "XU" for a in ph1.atoms()}})
if "bkg" in opts:
    h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 14, "refine": True}})
if "zero" in opts:
    h.set_refinements({"Instrument Parameters": ["Zero"]})
if "shl" in opts:
    h.set_refinements({"Instrument Parameters": ["SH/L"]})
if "bigshl" in opts:
    h.data["Instrument Parameters"][0]["SH/L"][1] = 0.15
    h.set_refinements({"Instrument Parameters": ["SH/L"]})
if "pola" in opts:
    h.data["Instrument Parameters"][0]["Polariz."][2] = True
if "rough" in opts:
    h.data['Sample Parameters']['SurfRoughA'][1] = True
    h.data['Sample Parameters']['SurfRoughB'][1] = True
    if h.data['Sample Parameters']['SurfRoughA'][0] == 0:
        h.data['Sample Parameters']['SurfRoughA'][0] = 0.01
        h.data['Sample Parameters']['SurfRoughB'][0] = 0.01
if "wo3cell" in opts:
    ph2.set_refinements({"Cell": True})
    prj.add_HoldConstr(['1::A4'])
if "po" in opts:
    ph1.set_HAP_refinements({"Pref.Ori.": ["MD", True, [0, 1, 0]]})

step("+".join(opts) or "none")
prj.save()
sp = h.data['Sample Parameters']
ip = h.data['Instrument Parameters'][0]
print("shift(um)", round(sp['Shift'][0], 1), "rough", [round(sp[k][0], 4) for k in ('SurfRoughA', 'SurfRoughB')])
print("inst", {k: round(ip[k][1], 5) for k in ('Zero', 'U', 'V', 'W', 'X', 'Y', 'SH/L', 'Polariz.')})
for p in phs:
    c = p.get_cell()
    hp = p.data['Histograms'][h.name]
    print(f"{p.name}: a={c['length_a']:.5f} b={c['length_b']:.5f} c={c['length_c']:.5f} beta={c['angle_beta']:.4f} "
          f"scale={hp['Scale'][0]:.5f} size={hp['Size'][1][0]:.4f} mustr={hp['Mustrain'][1][0]:.1f} PO={hp['Pref.Ori.'][1]:.4f}")
    for a in p.atoms():
        print("   ", a.label, [round(v, 5) for v in a.coordinates], "Uiso", round(a.uiso, 5))
