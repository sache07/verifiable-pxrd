"""Refined staged workflow with anisotropic broadening + asymmetry.

usage: refine3.py <gpxname> <cif:label> ...
"""
import os, sys, re
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc

WORK = '<ATTEMPT_WORKSPACE>/work'
os.chdir(WORK)


def wtfrac_from_lst(lstfile):
    out, cur = {}, None
    for line in open(lstfile):
        m = re.match(r'\s*Phase:\s+(\S+)\s+in histogram', line)
        if m:
            cur = m.group(1)
        m = re.search(r'Weight fraction\s*:\s*([-\d.eE+]+), sig\s*([-\d.eE+]+)', line)
        if m and cur:
            out[cur] = (float(m.group(1)), float(m.group(2)))
    return out


def report(gpx, h, name, log):
    print()
    for t, r in log:
        print(f'{t:24s} {r:8.3f}')
    print()
    for k, v in wtfrac_from_lst(name + '.lst').items():
        print(f'wt% {k:12s} {100*v[0]:7.2f} +/- {100*v[1]:.2f}')
    for p in gpx.phases():
        print(p.name, {k: round(v, 5) for k, v in p.get_cell().items()})
    rv = gpx.data['Covariance']['data']['Rvals']
    print({k: rv[k] for k in ('Rwp', 'GOF', 'Nobs', 'Nvars') if k in rv})
    ip = h.data['Instrument Parameters'][0]
    print({k: round(ip[k][1], 4) for k in ('Zero', 'U', 'V', 'W', 'X', 'Y', 'SH/L', 'Polariz.', 'I(L2)/I(L1)')})
    print('MSG:', rv.get('msg'))


def main():
    name = sys.argv[1]
    specs = sys.argv[2:]
    gpx = G2sc.G2Project(newgpx=name + '.gpx')
    h = gpx.add_powder_histogram('pattern.xy', 'cu.instprm', fmthint='Topas xye')
    for spec in specs:
        cif, label = spec.split(':')
        gpx.add_phase(cif, phasename=label, histograms=[h], fmthint='CIF')
    ip = h.data['Instrument Parameters'][0]
    ip['Zero'][1] = 0.31
    ip['U'][1], ip['V'][1], ip['W'][1] = 2.0, -1.0, 1.0
    ip['X'][1], ip['Y'][1] = 0.0, 3.0
    h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True}})
    gpx.save()

    log = []

    def step(tag):
        gpx.refine()
        r = h.get_wR()
        log.append((tag, r))
        print(f'=== {tag}: Rwp = {r:.3f}', flush=True)

    h.set_refinements({'Sample Parameters': ['Scale'], 'Instrument Parameters': ['Zero']})
    step('bg+scale+zero')
    for p in gpx.phases():
        p.set_refinements({'Cell': True})
    step('+cell')
    h.set_refinements({'Instrument Parameters': ['W', 'Y']})
    step('+W,Y')
    for p in gpx.phases():
        p.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True},
                               'Mustrain': {'type': 'isotropic', 'refine': True}})
    step('+size/strain')
    for p in gpx.phases():
        p.set_refinements({'Atoms': {a.label: 'XU' for a in p.atoms()}})
    step('+atoms')
    for p in gpx.phases():
        p.set_HAP_refinements({'Mustrain': {'type': 'generalized', 'refine': True}})
    step('+generalized strain')
    h.set_refinements({'Instrument Parameters': ['SH/L']})
    step('+SH/L')
    step('+SH/L(2)')
    report(gpx, h, name, log)
    gpx.save()


main()
