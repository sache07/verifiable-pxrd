"""Single-peak pseudo-Voigt (Ka1+Ka2) fits to estimate observed FWHM vs 2theta."""
import numpy as np, sys
from scipy.optimize import curve_fit

lam1, lam2, ratio = 1.540598, 1.544426, 0.5
d = np.loadtxt('<ATTEMPT_WORKSPACE>/inputs/pattern.csv',
               delimiter=',', skiprows=1)
X, Y = d[:, 0], d[:, 1]


def pv(x, x0, fwhm, eta):
    g = np.exp(-4 * np.log(2) * ((x - x0) / fwhm) ** 2) * (2 / fwhm) * np.sqrt(np.log(2) / np.pi)
    l = (2 / (np.pi * fwhm)) / (1 + 4 * ((x - x0) / fwhm) ** 2)
    return eta * l + (1 - eta) * g


def model(x, x0, fwhm, eta, amp, b0, b1):
    th = np.radians(x0 / 2)
    x02 = 2 * np.degrees(np.arcsin(np.clip(np.sin(th) * lam2 / lam1, -1, 1)))
    return amp * (pv(x, x0, fwhm, eta) + ratio * pv(x, x02, fwhm, eta)) + b0 + b1 * (x - x0)


peaks = [float(v) for v in sys.argv[1:]]
print(' 2theta   FWHM    eta    amp')
for p0 in peaks:
    w = 1.6 + 0.012 * p0
    m = (X > p0 - w) & (X < p0 + w)
    x, y = X[m], Y[m]
    try:
        popt, _ = curve_fit(model, x, y, p0=[p0, 0.15, 0.5, y.max() * 0.3, np.median(y), 0],
                            sigma=np.sqrt(np.maximum(y, 1)), maxfev=20000,
                            bounds=([p0 - 0.3, 0.02, 0, 0, 0, -1e3], [p0 + 0.3, 2.0, 1, 1e8, 1e5, 1e3]))
        print(f'{popt[0]:8.3f} {popt[1]:7.4f} {popt[2]:6.3f} {popt[3]:9.1f}')
    except Exception as e:
        print(p0, 'fail', e)
