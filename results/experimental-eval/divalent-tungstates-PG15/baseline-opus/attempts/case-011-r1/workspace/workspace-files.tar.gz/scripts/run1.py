import os, sys, numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc

WORK = os.path.dirname(os.path.abspath(__file__)).replace('/scripts', '/work')
os.chdir(WORK)

gpx = G2sc.G2Project(newgpx='t1.gpx')
h = gpx.add_powder_histogram('pattern.xy', 'cu.instprm', fmthint='Topas xye')
print('hist', h.name, len(h.data['data'][1][0]))
p = gpx.add_phase('cifs/WO3_m.cif', phasename='WO3', histograms=[h], fmthint='CIF')
print('phase', p.name, p.get_cell())
h.data['Instrument Parameters'][0]['Zero'][1] = 0.30
h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 8, 'refine': True}})
gpx.save()
gpx.do_refinements([{}])
print('Rwp', h.get_wR())
