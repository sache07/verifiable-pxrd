"""addtest.py <base.gpx> <newname> <cif:label>
Clone a converged project, add a candidate phase, refine only its scale (then cell),
and report how much it takes up and how much Rwp improves.
"""
import os, sys, re, shutil
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc

WORK = '<ATTEMPT_WORKSPACE>/work'
os.chdir(WORK)
base, newname, spec = sys.argv[1], sys.argv[2], sys.argv[3]
shutil.copy(base, newname + '.gpx')
gpx = G2sc.G2Project(newname + '.gpx')
h = gpx.histograms()[0]
cif, label = spec.split(':')
p = gpx.add_phase(cif, phasename=label, histograms=[h], fmthint='CIF')
hd = p.data['Histograms'][h.name]
hd['Scale'] = [0.05, True]
hd['Size'][1][0] = 0.3
hd['Mustrain'][1][0] = 1000.0
gpx.set_Frozen()
gpx.refine()
r1 = h.get_wR()
p.set_refinements({'Cell': True})
p.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}})
gpx.set_Frozen()
gpx.refine()
r2 = h.get_wR()
gpx.save()


def wtfrac(lstfile):
    out, cur = {}, None
    for line in open(lstfile):
        m = re.match(r'\s*Phase:\s+(\S+)\s+in histogram', line)
        if m:
            cur = m.group(1)
        m = re.search(r'Weight fraction\s*:\s*([-\d.eE+]+), sig\s*([-\d.eE+]+)', line)
        if m and cur:
            out[cur] = (float(m.group(1)), float(m.group(2)))
    return out


print(f'RESULT {label}: Rwp(scale only)={r1:.3f}  Rwp(+cell,size)={r2:.3f}')
for k, v in wtfrac(newname + '.lst').items():
    print(f'   wt% {k:12s} {100*v[0]:7.2f} +/- {100*v[1]:.2f}')
print('   cell', {k: round(v, 5) for k, v in p.get_cell().items()})
