"""zoom.py <prefix> <out.png> lo1,hi1 lo2,hi2 ..."""
import sys, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

pre, out = sys.argv[1], sys.argv[2]
rng = [tuple(float(v) for v in a.split(',')) for a in sys.argv[3:]]
d = np.genfromtxt(pre + '_fit.csv', delimiter=',', names=True)
x, yo, yc, diff = d['two_theta_deg'], d['y_obs'], d['y_calc'], d['y_diff']
n = len(rng)
fig, ax = plt.subplots(n, 1, figsize=(11, 3.2 * n), squeeze=False)
for a, (lo, hi) in zip(ax[:, 0], rng):
    m = (x >= lo) & (x <= hi)
    a.plot(x[m], yo[m], 'k.', ms=3)
    a.plot(x[m], yc[m], 'g-', lw=1.0)
    off = -0.2 * yo[m].max()
    a.plot(x[m], diff[m] + off, 'b-', lw=0.8)
    a.axhline(off, color='gray', lw=0.4)
    a.set_xlim(lo, hi)
plt.tight_layout(); plt.savefig(out, dpi=110)
