"""Shared helpers for GSAS-II scriptable refinements in this task."""
import os, sys, numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc

WORK = '<ATTEMPT_WORKSPACE>/work'
DATA = os.path.join(WORK, 'pattern.xy')
INST = os.path.join(WORK, 'cu.instprm')


def new_project(name, phases, bgterms=8, zero=0.30):
    """phases: list of (label, cif path, phasename-in-cif or None)"""
    gpx = G2sc.G2Project(newgpx=os.path.join(WORK, name))
    h = gpx.add_powder_histogram(DATA, INST, fmthint='Topas xye')
    for label, cif, pname in phases:
        p = gpx.add_phase(cif, phasename=label, histograms=[h], fmthint='CIF')
    h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': bgterms, 'refine': True}})
    h.data['Instrument Parameters'][0]['Zero'][1] = zero
    return gpx, h


def summary(gpx):
    h = gpx.histograms()[0]
    out = {'Rwp': h.get_wR()}
    try:
        out['GOF'] = gpx.data['Covariance']['data']['Rvals'].get('GOF')
        out['Rwp_all'] = gpx.data['Covariance']['data']['Rvals'].get('Rwp')
    except Exception:
        pass
    return out


def wtfracs(gpx):
    h = gpx.histograms()[0]
    res = {}
    for p in gpx.phases():
        res[p.name] = p.data['Histograms'][h.name]['Scale'][0]
    return res
