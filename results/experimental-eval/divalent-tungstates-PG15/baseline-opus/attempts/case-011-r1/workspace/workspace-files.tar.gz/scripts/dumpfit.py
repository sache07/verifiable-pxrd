"""dumpfit.py <project.gpx> <out_prefix>  -> <prefix>_fit.csv and <prefix>_refl.csv"""
import os, sys, numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc

WORK = '<ATTEMPT_WORKSPACE>/work'
os.chdir(WORK)
gpx = G2sc.G2Project(sys.argv[1])
h = gpx.histograms()[0]
d = h.data['data'][1]
x, yo, w, yc, yb = [np.asarray(v) for v in d[:5]]
pre = sys.argv[2]
with open(pre + '_fit.csv', 'w') as f:
    f.write('two_theta_deg,y_obs,y_calc,y_diff,y_bkg,weight\n')
    for i in range(len(x)):
        f.write(f'{x[i]:.6f},{yo[i]:.4f},{yc[i]:.4f},{yo[i]-yc[i]:.4f},{yb[i]:.4f},{w[i]:.6g}\n')
with open(pre + '_refl.csv', 'w') as f:
    f.write('phase,h,k,l,two_theta,Icalc\n')
    for p in gpx.phases():
        rl = h.data['Reflection Lists'].get(p.name)
        if rl is None:
            continue
        for r in rl['RefList']:
            f.write(f'{p.name},{int(r[0])},{int(r[1])},{int(r[2])},{r[5]:.4f},{r[8]*r[11]:.4f}\n')
print('Rwp', h.get_wR())
