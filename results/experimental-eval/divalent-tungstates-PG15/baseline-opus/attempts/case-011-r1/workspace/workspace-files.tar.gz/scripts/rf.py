"""Configurable staged Rietveld refinement.

usage: rf.py <gpxname> <phasespec,...> <plan>
  phasespec = cif:label
  plan = comma separated stage tokens, each a ';'-separated list of actions:
     bg, scale, zero, shift, cell, U,V,W,X,Y, SHL, pol, ka2,
     size, strain, strainU, strainG, lgmix, atoms, uiso, po
"""
import os, sys, re, json
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc

WORK = '<ATTEMPT_WORKSPACE>/work'
os.chdir(WORK)
INSTKEYS = {'U', 'V', 'W', 'X', 'Y', 'Z', 'SHL', 'pol', 'ka2', 'zero'}
IMAP = {'SHL': 'SH/L', 'pol': 'Polariz.', 'ka2': 'I(L2)/I(L1)', 'zero': 'Zero'}


def wtfrac_from_lst(lstfile):
    out, cur = {}, None
    for line in open(lstfile):
        m = re.match(r'\s*Phase:\s+(\S+)\s+in histogram', line)
        if m:
            cur = m.group(1)
        m = re.search(r'Weight fraction\s*:\s*([-\d.eE+]+), sig\s*([-\d.eE+]+)', line)
        if m and cur:
            out[cur] = (float(m.group(1)), float(m.group(2)))
    return out


def apply(gpx, h, acts):
    inst = []
    for a in acts:
        a = a.strip()
        if not a:
            continue
        if a == 'bg':
            h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True}})
        elif a == 'nobg':
            h.set_refinements({'Background': {'refine': False}})
        elif a == 'scale':
            h.set_refinements({'Sample Parameters': ['Scale']})
        elif a == 'shift':
            h.set_refinements({'Sample Parameters': ['Shift']})
        elif a == 'noshift':
            h.clear_refinements({'Sample Parameters': ['Shift']})
        elif a in INSTKEYS:
            inst.append(IMAP.get(a, a))
        elif a.startswith('no') and a[2:] in INSTKEYS:
            h.clear_refinements({'Instrument Parameters': [IMAP.get(a[2:], a[2:])]})
        elif a == 'limits':
            C = gpx.data['Controls']['data']
            for k in ('parmMinDict', 'parmMaxDict', 'parmFrozen'):
                C.setdefault(k, {})
            mn, mx = C['parmMinDict'], C['parmMaxDict']
            mn[':0:U'] = 0.0
            mn[':0:W'] = 1.0
            mn[':0:X'] = 0.0
            mn[':0:Y'] = 0.0
            mn[':0:SH/L'] = 0.001
            mx[':0:SH/L'] = 0.1
            for i, p in enumerate(gpx.phases()):
                mn[f'{i}:0:Size;i'] = 0.05
                mx[f'{i}:0:Size;i'] = 20.0
                mn[f'{i}:0:Mustrain;i'] = 50.0
                mx[f'{i}:0:Mustrain;i'] = 8000.0
                mn[f'{i}:0:Mustrain;a'] = 50.0
                mx[f'{i}:0:Mustrain;a'] = 8000.0
        elif a.startswith('uniax:'):
            # uniax:<phase index>:h,k,l   -> uniaxial mustrain along given axis
            _, idx, axis = a.split(':')
            p = gpx.phases()[int(idx)]
            hd = p.data['Histograms'][h.name]['Mustrain']
            v = hd[1][0]
            hd[0] = 'uniaxial'
            hd[1][0] = hd[1][1] = v
            hd[2][0] = hd[2][1] = True
            hd[3] = [int(t) for t in axis.split(',')]
        elif a.startswith('gen:'):
            from GSASII import GSASIIspc as G2spc
            p = gpx.phases()[int(a.split(':')[1])]
            hd = p.data['Histograms'][h.name]['Mustrain']
            gd = p.data['General']
            vals = G2spc.Muiso2Shkl(hd[1][0], gd['SGData'], gd['Cell'][1:7])
            hd[0] = 'generalized'
            hd[4] = list(vals)
            hd[2] = [False] * len(hd[2])
            hd[5] = [True] * len(hd[4])
        elif a.startswith('setuiso:'):
            # setuiso:<heavy>:<oxygen>
            _, hv, ox = a.split(':')
            for p in gpx.phases():
                for at in p.atoms():
                    at.uiso = float(ox) if at.element == 'O' else float(hv)
        elif a.startswith('po:'):
            # po:<phase idx>:h,k,l  -> March-Dollase preferred orientation
            _, idx, axis = a.split(':')
            p = gpx.phases()[int(idx)]
            po = p.data['Histograms'][h.name]['Pref.Ori.']
            po[0] = 'MD'
            po[1] = 1.0
            po[2] = True
            po[3] = [int(t) for t in axis.split(',')]
        elif a == 'sph':
            # spherical harmonics texture, order 4
            for p in gpx.phases():
                po = p.data['Histograms'][h.name]['Pref.Ori.']
                po[0] = 'SH'
                po[4] = 4
                po[2] = True
        elif a == 'uisoheavy':
            # refine Uiso only for the heavy (non-oxygen) atoms
            C = gpx.data['Controls']['data']
            for k in ('parmMinDict', 'parmMaxDict', 'parmFrozen'):
                C.setdefault(k, {})
            for i, p in enumerate(gpx.phases()):
                sel = {}
                for j, at in enumerate(p.atoms()):
                    if at.element != 'O':
                        sel[at.label] = 'U'
                        C['parmMinDict'][f'{i}::AUiso:{j}'] = 0.002
                        C['parmMaxDict'][f'{i}::AUiso:{j}'] = 0.025
                p.set_refinements({'Atoms': sel})
        elif a == 'uisoeq':
            # one Uiso per element per phase
            for i, p in enumerate(gpx.phases()):
                byel = {}
                for j, at in enumerate(p.atoms()):
                    byel.setdefault(at.element, []).append(j)
                for el, idx in byel.items():
                    if len(idx) > 1:
                        gpx.add_EquivConstr([f'{i}::AUiso:{j}' for j in idx])
        elif a == 'uisolim':
            C = gpx.data['Controls']['data']
            for k in ('parmMinDict', 'parmMaxDict', 'parmFrozen'):
                C.setdefault(k, {})
            for i, p in enumerate(gpx.phases()):
                for j, at in enumerate(p.atoms()):
                    C['parmMinDict'][f'{i}::AUiso:{j}'] = 0.002
                    C['parmMaxDict'][f'{i}::AUiso:{j}'] = 0.04
        elif a.startswith('restrain:'):
            # restrain:<phase idx>:<central element>:<target dist>:<esd>:<weight>
            _, idx, el, dist, esd, wt = a.split(':')
            p = gpx.phases()[int(idx)]
            rd = gpx.data['Restraints']['data']
            rd.setdefault(p.name, {})
            rd[p.name]['Bond'] = {'wtFactor': 1.0, 'Range': 1.1, 'Bonds': [], 'Use': True}
            org = [at.label for at in p.atoms() if at.element == el]
            tgt = [at.label for at in p.atoms() if at.element == 'O']
            n = p.addDistRestraint(org, tgt, float(dist), factor=1.25, ESD=float(esd))
            p.setDistRestraintWeight(float(wt))
            print(f'   {n} distance restraints added for {p.name}')
        elif a == 'unfreeze':
            gpx.set_Frozen()
        elif a.startswith('set:'):
            _, key, val = a.split(':')
            h.data['Instrument Parameters'][0][IMAP.get(key, key)][1] = float(val)
        elif a == 'frac':
            # refine phase fractions of all but the first phase (hist Scale covers the rest)
            for p in gpx.phases()[1:]:
                p.set_HAP_refinements({'Scale': True})
        elif a == 'cell':
            for p in gpx.phases():
                p.set_refinements({'Cell': True})
        elif a == 'size':
            for p in gpx.phases():
                p.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}})
        elif a == 'nosize':
            for p in gpx.phases():
                p.set_HAP_refinements({'Size': {'refine': False}})
        elif a == 'strain':
            for p in gpx.phases():
                p.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}})
        elif a == 'strainU':
            for p in gpx.phases():
                p.set_HAP_refinements({'Mustrain': {'type': 'uniaxial', 'refine': True}})
        elif a == 'nostrain':
            for p in gpx.phases():
                p.set_HAP_refinements({'Mustrain': {'refine': False}})
        elif a == 'atoms':
            for p in gpx.phases():
                p.set_refinements({'Atoms': {at.label: 'XU' for at in p.atoms()}})
        elif a == 'atomsx':
            for p in gpx.phases():
                p.set_refinements({'Atoms': {at.label: 'X' for at in p.atoms()}})
        elif a == 'atomsheavy':
            for p in gpx.phases():
                sel = {at.label: 'X' for at in p.atoms() if at.element != 'O'}
                if sel:
                    p.set_refinements({'Atoms': sel})
        elif a == 'uiso':
            for p in gpx.phases():
                p.set_refinements({'Atoms': {at.label: 'U' for at in p.atoms()}})
        elif a == 'hstrain':
            for p in gpx.phases():
                p.set_HAP_refinements({'HStrain': True})
        elif a.startswith('setsize:'):
            v = float(a.split(':')[1])
            for p in gpx.phases():
                p.data['Histograms'][h.name]['Size'][1][0] = v
        elif a.startswith('setstrain:'):
            v = float(a.split(':')[1])
            for p in gpx.phases():
                p.data['Histograms'][h.name]['Mustrain'][1][0] = v
        elif a.startswith('lgmixS'):
            for p in gpx.phases():
                hd = p.data['Histograms'][h.name]['Size']
                hd[1][2] = min(hd[1][2], 0.7)
                hd[2][2] = True
        elif a.startswith('lgmixM'):
            for p in gpx.phases():
                hd = p.data['Histograms'][h.name]['Mustrain']
                hd[1][2] = min(hd[1][2], 0.7)
                hd[2][2] = True
        else:
            raise ValueError('unknown action ' + a)
    if inst:
        h.set_refinements({'Instrument Parameters': inst})


def main():
    name = sys.argv[1]
    specs = sys.argv[2].split(',')
    plan = sys.argv[3].split('|')
    gpx = G2sc.G2Project(newgpx=name + '.gpx')
    h = gpx.add_powder_histogram('pattern.xy', os.environ.get('INSTPRM', 'cu.instprm'),
                                 fmthint='Topas xye')
    for spec in specs:
        cif, label = spec.split(':')
        gpx.add_phase(cif, phasename=label, histograms=[h], fmthint='CIF')
    ip = h.data['Instrument Parameters'][0]
    ip['Zero'][1] = 0.31
    ip['U'][1], ip['V'][1], ip['W'][1] = 2.0, -2.0, 5.0
    ip['X'][1], ip['Y'][1] = 0.0, 0.0
    for p in gpx.phases():
        hd = p.data['Histograms'][h.name]
        hd['Size'][1][0] = 1.0
        hd['Mustrain'][1][0] = 1000.0
    gpx.save()
    log = []
    for stage in plan:
        apply(gpx, h, stage.split(';'))
        gpx.refine()
        log.append((stage, h.get_wR()))
        print(f'=== {stage}: Rwp = {h.get_wR():.3f}', flush=True)
    gpx.save()
    print()
    for t, r in log:
        print(f'{t:40s} {r:8.3f}')
    print()
    for k, v in wtfrac_from_lst(name + '.lst').items():
        print(f'wt% {k:12s} {100*v[0]:7.2f} +/- {100*v[1]:.2f}')
    for p in gpx.phases():
        print(p.name, {k: round(v, 5) for k, v in p.get_cell().items()})
        hd = p.data['Histograms'][h.name]
        print('   Scale', hd['Scale'], ' Size', hd['Size'][0], [round(v, 4) for v in hd['Size'][1]],
              'Mustrain', hd['Mustrain'][0], [round(v, 2) for v in hd['Mustrain'][1]])
    rv = gpx.data['Covariance']['data']['Rvals']
    print({k: rv[k] for k in ('Rwp', 'GOF', 'Nobs', 'Nvars') if k in rv})
    ip = h.data['Instrument Parameters'][0]
    print({k: round(ip[k][1], 4) for k in ('Zero', 'U', 'V', 'W', 'X', 'Y', 'SH/L', 'Polariz.', 'I(L2)/I(L1)')})
    print('Shift', h.data['Sample Parameters']['Shift'])
    print('MSG:', rv.get('msg'))


main()
