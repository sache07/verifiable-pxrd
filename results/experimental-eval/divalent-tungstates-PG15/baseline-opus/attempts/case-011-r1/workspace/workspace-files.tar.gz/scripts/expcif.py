"""expcif.py <project.gpx> <outdir>  -> export each phase as CIF"""
import os, sys
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc

WORK = '<ATTEMPT_WORKSPACE>/work'
os.chdir(WORK)
gpx = G2sc.G2Project(sys.argv[1])
out = sys.argv[2]
os.makedirs(out, exist_ok=True)
for p in gpx.phases():
    fn = os.path.join(out, p.name + '.cif')
    p.export_CIF(fn)
    print('wrote', fn)
    for a in p.atoms():
        print('   ', a.label, a.type, [round(v, 5) for v in a.coordinates], a.occupancy, a.uiso)
