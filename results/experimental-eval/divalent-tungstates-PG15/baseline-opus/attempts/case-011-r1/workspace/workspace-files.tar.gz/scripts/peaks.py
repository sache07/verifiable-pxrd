import numpy as np, sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.signal import find_peaks

d = np.loadtxt(sys.argv[1], delimiter=',', skiprows=1)
x, y = d[:,0], d[:,1]
print("range", x.min(), x.max(), "step", np.median(np.diff(x)), "npts", len(x))
print("Imax", y.max(), "at", x[np.argmax(y)], "Imin", y.min())

# rough background via rolling minimum + smoothing
from scipy.ndimage import minimum_filter1d, uniform_filter1d
bg = minimum_filter1d(y, 201)
bg = uniform_filter1d(bg, 301)
ys = uniform_filter1d(y, 5)
net = ys - bg
pk, props = find_peaks(net, height=max(30, 0.01*net.max()), prominence=0.008*net.max(), distance=8)
print(f"{len(pk)} peaks")
lam = 1.540598
print(" 2theta      d       Inet    Irel")
for i in pk:
    dsp = lam/2/np.sin(np.radians(x[i]/2))
    print(f"{x[i]:8.3f} {dsp:8.4f} {net[i]:9.1f} {100*net[i]/net[pk].max():6.1f}")

fig, ax = plt.subplots(2,1, figsize=(16,9))
ax[0].plot(x,y,lw=0.6); ax[0].plot(x,bg,lw=0.8)
ax[0].plot(x[pk], y[pk], 'rv', ms=3)
ax[1].plot(x,net,lw=0.6); ax[1].set_yscale('symlog')
for a in ax: a.set_xlim(x.min(), x.max())
plt.tight_layout(); plt.savefig(sys.argv[2], dpi=110)
