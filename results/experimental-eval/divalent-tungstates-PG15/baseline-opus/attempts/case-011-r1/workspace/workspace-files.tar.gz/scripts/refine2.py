"""Staged 2+ phase Rietveld refinement with controlled profile parameterisation.

usage: refine2.py <gpxname> <cif:label> ...
env knobs: ATOMS=1 UNIAX=1 UVW=WXY
"""
import os, sys, re, json
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc

WORK = '<ATTEMPT_WORKSPACE>/work'
os.chdir(WORK)


def wtfrac_from_lst(lstfile):
    out, cur = {}, None
    for line in open(lstfile):
        m = re.match(r'\s*Phase:\s+(\S+)\s+in histogram', line)
        if m:
            cur = m.group(1)
        m = re.search(r'Weight fraction\s*:\s*([-\d.eE+]+), sig\s*([-\d.eE+]+)', line)
        if m and cur:
            out[cur] = (float(m.group(1)), float(m.group(2)))
    return out


def main():
    name = sys.argv[1]
    specs = sys.argv[2:]
    gpx = G2sc.G2Project(newgpx=name + '.gpx')
    h = gpx.add_powder_histogram('pattern.xy', 'cu.instprm', fmthint='Topas xye')
    for spec in specs:
        cif, label = spec.split(':')
        gpx.add_phase(cif, phasename=label, histograms=[h], fmthint='CIF')
    ip = h.data['Instrument Parameters'][0]
    ip['Zero'][1] = 0.31
    ip['U'][1], ip['V'][1], ip['W'][1] = 0.0, 0.0, 1.0
    ip['X'][1], ip['Y'][1] = 0.0, 3.0
    h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True}})
    gpx.save()

    log = []

    def step(tag):
        gpx.refine()
        r = h.get_wR()
        log.append((tag, r))
        print(f'=== {tag}: Rwp = {r:.3f}', flush=True)

    h.set_refinements({'Sample Parameters': ['Scale'], 'Instrument Parameters': ['Zero']})
    step('bg+scale+zero')
    for p in gpx.phases():
        p.set_refinements({'Cell': True})
    step('+cell')
    h.set_refinements({'Instrument Parameters': ['W', 'Y']})
    step('+W,Y')
    for p in gpx.phases():
        p.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True},
                               'Mustrain': {'type': 'isotropic', 'refine': True}})
    step('+size/strain')
    if os.environ.get('ATOMS', '1') == '1':
        for p in gpx.phases():
            p.set_refinements({'Atoms': {a.label: 'XU' for a in p.atoms()}})
        step('+atoms')
    if os.environ.get('UNIAX', '1') == '1':
        for p in gpx.phases():
            p.set_HAP_refinements({'Mustrain': {'type': 'uniaxial', 'refine': True}})
        step('+uniaxial')

    gpx.save()
    print()
    for t, r in log:
        print(f'{t:22s} {r:8.3f}')
    wf = wtfrac_from_lst(name + '.lst')
    print()
    for k, v in wf.items():
        print(f'wt% {k:12s} {100*v[0]:7.2f} +/- {100*v[1]:.2f}')
    for p in gpx.phases():
        c = p.get_cell()
        print(p.name, {k: round(v, 5) for k, v in c.items()})
    rv = gpx.data['Covariance']['data']['Rvals']
    print({k: rv[k] for k in ('Rwp', 'GOF', 'Nobs', 'Nvars') if k in rv})
    print('MSG:', rv.get('msg'))


main()
