"""Fit isolated peaks with Ka1+Ka2 pseudo-Voigt; optionally free Ka2 ratio."""
import numpy as np, sys
from scipy.optimize import curve_fit

lam1, lam2 = 1.540598, 1.544426
d = np.loadtxt('<ATTEMPT_WORKSPACE>/inputs/pattern.csv',
               delimiter=',', skiprows=1)
X, Y = d[:, 0], d[:, 1]


def pv(x, x0, fwhm, eta):
    g = np.exp(-4 * np.log(2) * ((x - x0) / fwhm) ** 2) * (2 / fwhm) * np.sqrt(np.log(2) / np.pi)
    l = (2 / (np.pi * fwhm)) / (1 + 4 * ((x - x0) / fwhm) ** 2)
    return eta * l + (1 - eta) * g


def make(ratio_free):
    def model(x, x0, fwhm, eta, amp, b0, b1, ratio=0.5):
        th = np.radians(x0 / 2)
        x02 = 2 * np.degrees(np.arcsin(np.clip(np.sin(th) * lam2 / lam1, -1, 1)))
        return amp * (pv(x, x0, fwhm, eta) + ratio * pv(x, x02, fwhm, eta)) + b0 + b1 * (x - x0)
    if ratio_free:
        return model
    return lambda x, x0, fwhm, eta, amp, b0, b1: model(x, x0, fwhm, eta, amp, b0, b1, 0.5)


peaks = [float(v) for v in sys.argv[1:]]
print(' 2theta   FWHM    eta     ratio    chi2/n(r=0.5)  chi2/n(free)  chi2/n(r=0)')
for p0 in peaks:
    w = 1.3 + 0.014 * p0
    m = (X > p0 - w) & (X < p0 + w)
    x, y = X[m], Y[m]
    sig = np.sqrt(np.maximum(y, 1))
    res = {}
    for tag, rf, fixr in (('0.5', False, None), ('free', True, None), ('0', False, 0.0)):
        if fixr == 0.0:
            def mdl(x, x0, fwhm, eta, amp, b0, b1):
                return amp * pv(x, x0, fwhm, eta) + b0 + b1 * (x - x0)
        else:
            mdl = make(rf)
        p = [p0, 0.18, 0.3, y.max() * 0.3, np.median(y), 0] + ([0.5] if rf else [])
        lo = [p0 - 0.4, 0.03, 0, 0, 0, -1e3] + ([0.0] if rf else [])
        hi = [p0 + 0.4, 2.0, 1, 1e8, 1e5, 1e3] + ([1.5] if rf else [])
        try:
            popt, _ = curve_fit(mdl, x, y, p0=p, sigma=sig, maxfev=40000, bounds=(lo, hi))
            chi2 = np.sum(((y - mdl(x, *popt)) / sig) ** 2) / (len(x) - len(popt))
            res[tag] = (popt, chi2)
        except Exception as e:
            res[tag] = (None, float('nan'))
    pf = res['free'][0]
    print(f"{res['0.5'][0][0]:8.3f} {res['0.5'][0][1]:7.4f} {res['0.5'][0][2]:6.3f} "
          f"{(pf[6] if pf is not None else float('nan')):7.3f}   "
          f"{res['0.5'][1]:10.3f}   {res['free'][1]:10.3f}   {res['0'][1]:10.3f}")
