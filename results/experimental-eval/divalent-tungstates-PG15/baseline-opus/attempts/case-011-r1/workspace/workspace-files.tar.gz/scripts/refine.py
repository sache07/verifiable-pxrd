"""Staged Rietveld refinement driver.

usage: refine.py <gpxname> <cif:label> [<cif:label> ...]
"""
import os, sys, re, numpy as np
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc

WORK = '<ATTEMPT_WORKSPACE>/work'
os.chdir(WORK)


def wtfrac_from_lst(lstfile):
    out = {}
    cur = None
    for line in open(lstfile):
        m = re.match(r'\s*Phase:\s+(\S+)\s+in histogram', line)
        if m:
            cur = m.group(1)
        m = re.search(r'Weight fraction\s*:\s*([\d.eE+-]+), sig\s*([\d.eE+-]+)', line)
        if m and cur:
            out[cur] = (float(m.group(1)), float(m.group(2)))
    return out


def build(name, specs, zero=0.30, bg=10):
    gpx = G2sc.G2Project(newgpx=name + '.gpx')
    h = gpx.add_powder_histogram('pattern.xy', 'cu.instprm', fmthint='Topas xye')
    for spec in specs:
        cif, label = spec.split(':')
        gpx.add_phase(cif, phasename=label, histograms=[h], fmthint='CIF')
    h.data['Instrument Parameters'][0]['Zero'][1] = zero
    h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': bg, 'refine': True}})
    gpx.save()
    return gpx, h


def stages(gpx, h, do_atoms=True, aniso_strain=True):
    log = []

    def step(tag):
        gpx.refine()
        r = h.get_wR()
        log.append((tag, r))
        print(f'--- {tag}: Rwp = {r:.3f}', flush=True)

    # 1: background + scale + zero
    h.set_refinements({'Sample Parameters': ['Scale'], 'Instrument Parameters': ['Zero']})
    step('bg+scale+zero')

    # 2: + unit cells
    for p in gpx.phases():
        p.set_refinements({'Cell': True})
    step('+cell')

    # 3: + profile U,V,W,X,Y  (instrumental-ish, shared)
    h.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']})
    step('+UVWXY')

    # 4: + per-phase isotropic size & microstrain
    for p in gpx.phases():
        p.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True},
                               'Mustrain': {'type': 'isotropic', 'refine': True}})
    step('+size/strain')

    # 5: + sample displacement instead of zero
    h.set_refinements({'Sample Parameters': ['Shift']})
    step('+shift')

    if do_atoms:
        for p in gpx.phases():
            p.set_refinements({'Atoms': {a.label: 'XU' for a in p.atoms()}})
        step('+atoms')

    if aniso_strain:
        for p in gpx.phases():
            p.set_HAP_refinements({'Mustrain': {'type': 'uniaxial', 'refine': True}})
        step('+uniaxial strain')

    return log


if __name__ == '__main__':
    name = sys.argv[1]
    gpx, h = build(name, sys.argv[2:])
    log = stages(gpx, h)
    gpx.save()
    print()
    for t, r in log:
        print(f'{t:22s} {r:8.3f}')
    print()
    wf = wtfrac_from_lst(name + '.lst')
    for k, v in wf.items():
        print(f'wt% {k:12s} {100*v[0]:7.2f} +/- {100*v[1]:.2f}')
    for p in gpx.phases():
        print(p.name, p.get_cell())
    print('Rvals', gpx.data['Covariance']['data']['Rvals'])
