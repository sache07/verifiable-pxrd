"""Final two-phase Rietveld refinement of inputs/pattern.csv (gamma-WO3 + beta-MnO2).

Produces  final.gpx, fit.csv, result.json and one CIF per phase in the workspace root.
Run with the GSAS-II venv interpreter.
"""
import os, sys, re, json, shutil
sys.path.insert(0, '<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages')
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIspc as G2spc

ROOT = '<ATTEMPT_WORKSPACE>'
WORK = os.path.join(ROOT, 'work')
os.chdir(WORK)

GPX = os.path.join(WORK, 'final.gpx')
for f in (GPX, GPX.replace('.gpx', '.lst')):
    if os.path.exists(f):
        os.remove(f)

PHASES = [('WO3', 'cifs/WO3_m.cif'), ('MnO2', 'cifs/MnO2_pyr.cif')]

gpx = G2sc.G2Project(newgpx=GPX)
h = gpx.add_powder_histogram('pattern.xy', 'cu.instprm', fmthint='Topas xye')
for label, cif in PHASES:
    gpx.add_phase(cif, phasename=label, histograms=[h], fmthint='CIF')
hname = h.name
wo3, mno2 = gpx.phases()

# ---- starting values -------------------------------------------------------
ip = h.data['Instrument Parameters'][0]
ip['Zero'][1] = 0.31
ip['U'][1] = ip['V'][1] = ip['X'][1] = ip['Y'][1] = 0.0   # held: see report.md
ip['W'][1] = 10.0
ip['SH/L'][1] = 0.01
for p in gpx.phases():
    for at in p.atoms():
        at.uiso = 0.012 if at.element == 'O' else 0.006
    hd = p.data['Histograms'][hname]
    hd['Size'][1][0] = 1.0
    hd['Mustrain'][1][0] = 1000.0

# physical bounds on the displacement parameters that are refined
C = gpx.data['Controls']['data']
for k in ('parmMinDict', 'parmMaxDict', 'parmFrozen'):
    C.setdefault(k, {})
for i, p in enumerate(gpx.phases()):
    for j, at in enumerate(p.atoms()):
        if at.element != 'O':
            C['parmMinDict'][f'{i}::AUiso:{j}'] = 0.002
            C['parmMaxDict'][f'{i}::AUiso:{j}'] = 0.025
gpx.save()

log = []


def step(tag):
    gpx.set_Frozen()
    gpx.refine()
    r = h.get_wR()
    log.append((tag, r))
    print(f'=== {tag:38s} Rwp = {r:.3f}', flush=True)


def heavy_xyz():
    for p in gpx.phases():
        sel = {at.label: 'X' for at in p.atoms() if at.element != 'O'}
        if sel:
            p.set_refinements({'Atoms': sel})


def heavy_uiso():
    for p in gpx.phases():
        sel = {at.label: 'U' for at in p.atoms() if at.element != 'O'}
        if sel:
            p.set_refinements({'Atoms': sel})


# ---- staged refinement -----------------------------------------------------
h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True},
                   'Sample Parameters': ['Scale'],
                   'Instrument Parameters': ['Zero']})
mno2.set_HAP_refinements({'Scale': True})          # WO3 fraction stays 1, hist scale carries it
step('background + scale + fraction + zero')

for p in gpx.phases():
    p.set_refinements({'Cell': True})
step('+ unit cells')

for p in gpx.phases():
    p.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True},
                           'Mustrain': {'type': 'isotropic', 'refine': True}})
step('+ crystallite size & microstrain')

h.set_refinements({'Instrument Parameters': ['W']})
step('+ Gaussian W')

h.set_refinements({'Instrument Parameters': ['SH/L']})
step('+ axial-divergence asymmetry')

hd = wo3.data['Histograms'][hname]['Mustrain']
hd[0] = 'uniaxial'
hd[1][0] = hd[1][1] = hd[1][0]
hd[2][0] = hd[2][1] = True
hd[3] = [0, 1, 0]
step('+ WO3 uniaxial microstrain [010]')

heavy_uiso()
step('+ Uiso(W, Mn)')

heavy_xyz()
step('+ W positions')

gd = wo3.data['General']
hd = wo3.data['Histograms'][hname]['Mustrain']
hd[4] = list(G2spc.Muiso2Shkl(hd[1][0], gd['SGData'], gd['Cell'][1:7]))
hd[0] = 'generalized'
hd[2] = [False] * len(hd[2])
hd[5] = [True] * len(hd[4])
step('+ WO3 generalized (Stephens) strain')

heavy_xyz()
step('+ W positions (2)')

# MnO2 microstrain refined to ~0 (slightly negative); hold it at a small positive value
hdm = mno2.data['Histograms'][hname]['Mustrain']
hdm[1][0] = 100.0
hdm[2][0] = False
step('final cycle (MnO2 strain held)')

gpx.save()

# ---- results ---------------------------------------------------------------
lst = GPX.replace('.gpx', '.lst')
wf, cur = {}, None
for line in open(lst):
    m = re.match(r'\s*Phase:\s+(\S+)\s+in histogram', line)
    if m:
        cur = m.group(1)
    m = re.search(r'Weight fraction\s*:\s*([-\d.eE+]+), sig\s*([-\d.eE+]+)', line)
    if m and cur:
        wf[cur] = (float(m.group(1)), float(m.group(2)))

rv = gpx.data['Covariance']['data']['Rvals']
res = h.data['data'][0].get('Residuals', {}) if isinstance(h.data['data'][0], dict) else {}
resid = h.data['Residuals'] if 'Residuals' in h.data else {}

print()
for t, r in log:
    print(f'{t:42s} {r:8.3f}')
print()
for k, v in wf.items():
    print(f'wt% {k:6s} {100*v[0]:7.2f} +/- {100*v[1]:.2f}')
for p in gpx.phases():
    print(p.name, {k: round(v, 5) for k, v in p.get_cell().items()})
    hd = p.data['Histograms'][hname]
    print('    Scale', hd['Scale'], 'Size', hd['Size'][0], [round(v, 4) for v in hd['Size'][1]],
          'Mustrain', hd['Mustrain'][0], [round(v, 1) for v in hd['Mustrain'][1]])
    for at in p.atoms():
        print('      ', at.label, at.type, [round(c, 5) for c in at.coordinates], round(at.uiso, 5))
print({k: rv[k] for k in ('Rwp', 'GOF', 'Nobs', 'Nvars') if k in rv})
print({k: round(ip[k][1], 5) for k in ('Zero', 'U', 'V', 'W', 'X', 'Y', 'SH/L', 'Polariz.', 'I(L2)/I(L1)')})
print('MSG:', rv.get('msg'))

json.dump({'log': log, 'wtfrac': wf,
           'Rvals': {k: rv[k] for k in ('Rwp', 'GOF', 'Nobs', 'Nvars') if k in rv},
           'inst': {k: ip[k][1] for k in ('Zero', 'U', 'V', 'W', 'X', 'Y', 'SH/L')},
           'cells': {p.name: p.get_cell() for p in gpx.phases()},
           'resid': {k: v for k, v in h.data['Residuals'].items() if isinstance(v, (int, float))},
           }, open(os.path.join(WORK, 'final_summary.json'), 'w'), indent=1)
