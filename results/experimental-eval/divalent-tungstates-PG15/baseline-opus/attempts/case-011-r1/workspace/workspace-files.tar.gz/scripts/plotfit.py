"""plotfit.py <prefix> <out.png>  (reads <prefix>_fit.csv, <prefix>_refl.csv)"""
import sys, numpy as np, csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

pre, out = sys.argv[1], sys.argv[2]
d = np.genfromtxt(pre + '_fit.csv', delimiter=',', names=True)
x, yo, yc, diff, yb = d['two_theta_deg'], d['y_obs'], d['y_calc'], d['y_diff'], d['y_bkg']
refl = {}
try:
    for row in csv.DictReader(open(pre + '_refl.csv')):
        refl.setdefault(row['phase'], []).append(float(row['two_theta']))
except FileNotFoundError:
    pass
cols = ['r', 'm', 'orange', 'purple', 'brown']
fig, ax = plt.subplots(3, 1, figsize=(19, 13))
for a, (lo, hi) in zip(ax, [(9.9, 40), (40, 70), (70, 100.1)]):
    m = (x >= lo) & (x <= hi)
    a.plot(x[m], yo[m], 'k.', ms=1.6, label='obs')
    a.plot(x[m], yc[m], 'g-', lw=0.8, label='calc')
    a.plot(x[m], yb[m], 'c-', lw=0.5)
    off = -0.28 * yo[m].max()
    a.plot(x[m], diff[m] + off, 'b-', lw=0.6, label='diff')
    a.axhline(off, color='gray', lw=0.4)
    a.set_xlim(lo, hi)
    for k, (pn, tts) in enumerate(refl.items()):
        tt = np.array([t for t in tts if lo <= t <= hi])
        a.plot(tt, np.full(len(tt), off * (0.35 + 0.22 * k)), '|', ms=9, color=cols[k % 5],
               label=pn if lo == 9.9 else None)
    a.legend(fontsize=8, ncol=5)
plt.tight_layout()
plt.savefig(out, dpi=100)
