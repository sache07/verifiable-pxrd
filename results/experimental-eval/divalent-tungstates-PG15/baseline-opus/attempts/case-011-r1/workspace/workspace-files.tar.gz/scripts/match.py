"""Compare observed peak list against simulated patterns of candidate CIFs."""
import sys, glob, numpy as np, warnings
warnings.filterwarnings('ignore')
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator

obs = np.array([float(v) for v in open(sys.argv[1]).read().split()])
cifs = sys.argv[2:]
calc = XRDCalculator(wavelength=1.540598)
for c in cifs:
    try:
        s = Structure.from_file(c)
        p = calc.get_pattern(s, two_theta_range=(9.9, 100.1))
    except Exception as e:
        print(c, 'FAIL', e); continue
    x = np.array(p.x); i = np.array(p.y)
    strong = x[i > 3]
    # fraction of observed peaks matched within tol
    tol = 0.35
    matched = sum(1 for o in obs if np.any(np.abs(x - o) < tol))
    # fraction of strong simulated peaks present in obs
    present = sum(1 for sx in strong if np.any(np.abs(obs - sx) < tol))
    print(f"{c.split('/')[-1]:14s} {s.composition.reduced_formula:8s} {str(s.get_space_group_info()):28s} obs_match {matched:3d}/{len(obs)}  sim_present {present:3d}/{len(strong)}")
