"""Assemble the deliverables from work/final.gpx into the workspace root."""
import os, re, json, shutil, math

ROOT = '<ATTEMPT_WORKSPACE>'
WORK = os.path.join(ROOT, 'work')

CIFS = {'WO3': 'WO3_gamma_monoclinic.cif', 'MnO2': 'MnO2_pyrolusite.cif'}
BLOCK = {'WO3': 'WO3_gamma_P21n', 'MnO2': 'MnO2_pyrolusite_P42mnm'}

# ---- CIFs ------------------------------------------------------------------
for ph, out in CIFS.items():
    txt = open(os.path.join(WORK, 'cif_final', ph + '.cif')).read()
    txt = txt.replace('data_final', 'data_' + BLOCK[ph], 1)
    open(os.path.join(ROOT, out), 'w').write(txt)
    print('wrote', out)

# ---- fit.csv ---------------------------------------------------------------
src = os.path.join(WORK, 'final_fit.csv')
rows = open(src).read().strip().split('\n')
hdr = rows[0].split(',')
keep = [hdr.index(c) for c in ('two_theta_deg', 'y_obs', 'y_calc', 'y_diff', 'y_bkg')]
with open(os.path.join(ROOT, 'fit.csv'), 'w') as f:
    f.write('two_theta_deg,y_obs,y_calc,y_diff,y_background\n')
    for r in rows[1:]:
        v = r.split(',')
        f.write(','.join(v[i] for i in keep) + '\n')
print('wrote fit.csv', len(rows) - 1, 'points')

# ---- statistics from the .lst ---------------------------------------------
lst = open(os.path.join(WORK, 'final.lst')).read()
wf, cur, perphase = {}, None, {}
for line in lst.split('\n'):
    m = re.match(r'\s*Phase:\s+(\S+)\s+in histogram', line)
    if m:
        cur = m.group(1)
    m = re.search(r'Final refinement RF, RF\^2 = ([\d.]+)%, ([\d.]+)% on (\d+) reflections', line)
    if m and cur:
        perphase.setdefault(cur, {}).update(R_F_percent=float(m.group(1)),
                                            R_F2_percent=float(m.group(2)),
                                            n_reflections=int(m.group(3)))
    m = re.search(r'Weight fraction\s*:\s*([-\d.eE+]+), sig\s*([-\d.eE+]+)', line)
    if m and cur:
        wf[cur] = (float(m.group(1)), float(m.group(2)))
m = re.search(r'Final refinement wR = ([\d.]+)% on (\d+) observations', lst)
Rwp, Nobs = float(m.group(1)), int(m.group(2))
m = re.search(r'Other residuals: R = ([\d.]+)%, R-bkg = ([\d.]+)%, wR-bkg = ([\d.]+)% wRmin = ([\d.]+)%', lst)
Rp, Rp_bkg, Rwp_bkg, Rexp = [float(m.group(i)) for i in (1, 2, 3, 4)]
m = re.search(r'Durbin-Watson statistic = ([\d.]+)', lst)
DW = float(m.group(1))
rvals = json.load(open(os.path.join(WORK, 'final_rvals.json')))
nvar = rvals['Nvars']

summ = json.load(open(os.path.join(WORK, 'final_summary.json'))) if \
    os.path.exists(os.path.join(WORK, 'final_summary.json')) else {}

GOF = Rwp / Rexp
stats = {
    'R_wp_percent': Rwp,
    'R_p_percent': Rp,
    'R_exp_percent': Rexp,
    'goodness_of_fit_S': round(GOF, 3),
    'reduced_chi_squared': round(GOF ** 2, 3),
    'R_wp_background_subtracted_percent': Rwp_bkg,
    'R_p_background_subtracted_percent': Rp_bkg,
    'Durbin_Watson': DW,
    'n_observations': Nobs,
    'n_refined_variables': nvar,
    'two_theta_range_deg': [9.903, 100.095],
}

# ---- cells -----------------------------------------------------------------
cells = {}
for blk in lst.split(' Phase name: ')[1:]:
    name = blk.split('\n')[0].strip()
    mm = re.search(r'Unit cell: a = ([\d.]+) b = ([\d.]+) c = ([\d.]+) '
                   r'alpha = ([\d.]+) beta = ([\d.]+) gamma = ([\d.]+) volume = ([\d.]+)', blk)
    if mm:
        cells[name] = dict(zip(('a', 'b', 'c', 'alpha', 'beta', 'gamma', 'volume'),
                               [float(mm.group(i)) for i in range(1, 8)]))

INFO = {
    'WO3': dict(formula='WO3', name='tungsten(VI) oxide, monoclinic gamma-WO3',
                space_group='P 1 21/n 1', space_group_number=14, Z=8,
                cif='WO3_gamma_monoclinic.cif',
                source_model='COD 1528915 (Tanisaki 1960), monoclinic gamma-WO3'),
    'MnO2': dict(formula='MnO2', name='manganese(IV) oxide, pyrolusite (beta-MnO2, rutile type)',
                 space_group='P 42/m n m', space_group_number=136, Z=2,
                 cif='MnO2_pyrolusite.cif',
                 source_model='COD 1514232 (pyrolusite, rutile type)'),
}

phases = []
for ph in ('WO3', 'MnO2'):
    f, s = wf[ph]
    d = dict(INFO[ph])
    d['weight_fraction'] = round(f, 4)
    d['weight_fraction_percent'] = round(100 * f, 2)
    d['weight_fraction_esd_percent'] = round(100 * s, 2)
    d['weight_fraction_total_uncertainty_percent'] = 3.0
    d['refined_cell'] = {k: round(v, 5) for k, v in cells.get(ph, {}).items()}
    d.update(perphase.get(ph, {}))
    phases.append(d)

result = {
    'sample_context': {
        'precursors': ['MnO2', 'WO3'],
        'reported_heating_temperature_C': 300.0,
        'radiation': 'Cu K-alpha1 + K-alpha2 (1.540598 / 1.544426 A, I2/I1 = 0.5)',
        'method': 'Rietveld refinement, GSAS-II scriptable',
    },
    'n_crystalline_phases': 2,
    'phases': phases,
    'weight_fractions_normalised_over': 'the two modelled crystalline phases (sum = 1)',
    'derived_molar_ratio_MnO2_to_WO3': round(
        (wf['MnO2'][0] / 86.9368) / (wf['WO3'][0] / 231.837), 3),
    'fit_statistics': stats,
    'files': {
        'profile': 'fit.csv',
        'gsas2_project': 'final.gpx',
        'report': 'report.md',
    },
    'notes': [
        'No third crystalline phase was required; candidate MnWO4, Mn2O3, Mn3O4, MnO, '
        'ramsdellite-MnO2 and other WO3 polymorphs each refined to <=1.2 wt% with no '
        'significant improvement of the fit.',
        'Quoted weight_fraction_esd_percent is the GSAS-II least-squares estimate '
        '(statistical only). weight_fraction_total_uncertainty_percent is the spread '
        'observed over physically defensible alternative profile/displacement models.',
    ],
}
json.dump(result, open(os.path.join(ROOT, 'result.json'), 'w'), indent=2)
print('wrote result.json')

shutil.copy(os.path.join(WORK, 'final.gpx'), os.path.join(ROOT, 'final.gpx'))
print('wrote final.gpx')
print(json.dumps({'Rwp': Rwp, 'GOF': round(GOF, 3), 'wt%': {k: round(100 * v[0], 2) for k, v in wf.items()},
                  'molar MnO2:WO3': result['derived_molar_ratio_MnO2_to_WO3']}, indent=1))
