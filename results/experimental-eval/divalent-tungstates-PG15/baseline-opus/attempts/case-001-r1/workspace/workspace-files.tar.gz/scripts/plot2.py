import sys
import numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
d=np.loadtxt(sys.argv[1],delimiter=',',skiprows=1)
x,yo,yc,yb,yd=d.T
rngs=[(10,30),(30,50),(50,70),(70,100)]
fig,axs=plt.subplots(len(rngs),1,figsize=(16,16))
for ax,(lo,hi) in zip(axs,rngs):
    m=(x>=lo)&(x<=hi)
    ax.plot(x[m],yo[m],'k.',ms=2); ax.plot(x[m],yc[m],'r-',lw=0.8)
    off=-0.25*yo[m].max()
    ax.plot(x[m],yd[m]+off,'b-',lw=0.6); ax.axhline(off,color='gray',lw=0.4)
    ax.set_xlim(lo,hi)
plt.tight_layout(); plt.savefig(sys.argv[2],dpi=100)
