"""Transform the Loopstra & Boldrini gamma-WO3 structure (COD 2311041, P21/c,
beta=136) into the conventional P21/n setting (a~7.30, b~7.54, c~7.69).

This derives and checks the transformation and writes work/ref_WO3n_check.cif.
The model actually fed to GSAS-II, work/ref_WO3n.cif, carries the same cell,
symmetry operations and asymmetric unit but is written in the COD-style layout
that the GSAS-II CIF reader accepts.
"""
import numpy as np
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

s = Structure.from_file('work/ref_WO3b.cif')
P = np.array([[1, 0, 1], [0, 1, 0], [-1, 0, 0]])
s2 = Structure(np.dot(P, s.lattice.matrix), s.species, s.cart_coords,
               coords_are_cartesian=True)
sa = SpacegroupAnalyzer(s2, symprec=0.02)
ops = sa.get_symmetry_operations()
print("spacegroup", sa.get_space_group_symbol(), "nops", len(ops))
for o in ops:
    print("   ", o.as_xyz_str())

# group atoms into orbits
frac = np.mod(s2.frac_coords, 1.0)
assigned = [-1]*len(frac)
reps = []
for i in range(len(frac)):
    if assigned[i] >= 0:
        continue
    k = len(reps); reps.append(i)
    for o in ops:
        y = np.mod(o.operate(frac[i]), 1.0)
        d = np.mod(frac - y + 0.5, 1.0) - 0.5
        for j in np.where(np.all(np.abs(d) < 0.02, axis=1))[0]:
            assigned[j] = k
print("orbits", len(reps), "sizes", [assigned.count(k) for k in range(len(reps))])

lat = s2.lattice
lines = ["data_WO3_gamma_P21n",
         "_chemical_formula_sum 'W8 O24'",
         "_symmetry_space_group_name_H-M 'P 1 21/n 1'",
         "_symmetry_Int_Tables_number 14",
         "_cell_length_a %.5f" % lat.a,
         "_cell_length_b %.5f" % lat.b,
         "_cell_length_c %.5f" % lat.c,
         "_cell_angle_alpha %.4f" % lat.alpha,
         "_cell_angle_beta  %.4f" % lat.beta,
         "_cell_angle_gamma %.4f" % lat.gamma,
         "_cell_formula_units_Z 8",
         "loop_", "_symmetry_equiv_pos_as_xyz"]
for o in ops:
    lines.append("  '%s'" % o.as_xyz_str().replace(" ", ""))
lines += ["loop_", "_atom_site_label", "_atom_site_type_symbol",
          "_atom_site_fract_x", "_atom_site_fract_y", "_atom_site_fract_z",
          "_atom_site_occupancy", "_atom_site_U_iso_or_equiv"]
nw = no = 0
for i in reps:
    el = str(s2[i].specie)
    if el == 'W':
        nw += 1; lab = 'W%d' % nw
    else:
        no += 1; lab = 'O%d' % no
    f = frac[i]
    lines.append("  %-4s %-2s %.5f %.5f %.5f 1.0 0.01" % (lab, el, f[0], f[1], f[2]))
open('work/ref_WO3n_check.cif', 'w').write("\n".join(lines) + "\n")
print("written")
