"""Staged Rietveld refinement driver.

usage: run.py <out.gpx> <phase,phase,...> [options]
options (comma list as 3rd arg): shift|zero , sh , tex=MD|SH , xyz , pol , k2
"""
import os, sys
import GSASII.GSASIIscriptable as G2sc

WORK = "<ATTEMPT_WORKSPACE>/work"
os.chdir(WORK)

gpx_name = sys.argv[1]
phase_list = sys.argv[2].split(",")
opts = sys.argv[3].split(",") if len(sys.argv) > 3 else []
opt = {}
for o in opts:
    if "=" in o:
        k, v = o.split("="); opt[k] = v
    else:
        opt[o] = True

CIF = {"BaCO3": "ref_BaCO3.cif", "WO3": "ref_WO3.cif", "BaWO4": "ref_BaWO4.cif",
       "WO3t": "ref_WO3t.cif", "WO3b": "ref_WO3b.cif"}

if os.path.exists(gpx_name):
    os.remove(gpx_name)
gpx = G2sc.G2Project(newgpx=gpx_name)
hist = gpx.add_powder_histogram("pattern.xy", "cuka.instprm", fmthint="Topas xye")

ip = hist.data['Instrument Parameters'][0]
for k, v in dict(U=40.0, V=-15.0, W=120.0, X=4.0, Y=4.0, SH=0.002).items():
    if k in ip:
        ip[k][0] = ip[k][1] = v
if opt.get("zero"):
    hist.data['Instrument Parameters'][0]['Zero'][1] = 0.30
else:
    hist.data['Sample Parameters']['Shift'][0] = -580.0

for p in phase_list:
    gpx.add_phase(CIF[p], phasename=p, histograms=[hist])

# crystallite-size broadening is not refined (correlated with microstrain);
# 1 um corresponds to negligible broadening
for p in gpx.phases():
    p.data['Histograms'][hist.name]['Size'][1][0] = 1.0

log = []
def ref(label):
    gpx.do_refinements([{}])
    w = hist.get_wR()
    log.append((label, w))
    print(f"  {label:34s} wR = {w:.3f}", flush=True)

hist.set_refinements({"Background": {"no. coeffs": 8, "type": "chebyschev-1",
                                     "refine": True}})
ref("background")

for p in gpx.phases():
    p.set_HAP_refinements({"Scale": True})
ref("+ phase scales")

if opt.get("zero"):
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    ref("+ zero offset")
else:
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    ref("+ sample displacement")

for p in gpx.phases():
    p.set_refinements({"Cell": True})
ref("+ unit cells")

hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
ref("+ instrument profile UVWXY")

for p in gpx.phases():
    p.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
ref("+ microstrain")

if opt.get("sh"):
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    ref("+ axial asymmetry")

if opt.get("pol"):
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    ref("+ polarization")

if opt.get("k2"):
    ip['I(L2)/I(L1)'][2] = True
    ref("+ Ka2/Ka1 ratio")

if opt.get("tex") == "MD":
    for p in gpx.phases():
        p.set_HAP_refinements({"Pref.Ori.": {"type": "MD", "refine": True}})
    ref("+ March-Dollase (001)")
elif opt.get("tex") == "SH":
    for p in gpx.phases():
        p.set_HAP_refinements({"Pref.Ori.": {"type": "SH", "order": 4,
                                             "refine": True}})
    ref("+ spherical harmonics L=4")

if opt.get("uiso"):
    for p in gpx.phases():
        p.set_refinements({"Atoms": {"all": "U"}})
    ref("+ Uiso")

if opt.get("xyz"):
    for p in gpx.phases():
        p.set_refinements({"Atoms": {"all": "XU"}})
    ref("+ coordinates")

if opt.get("mu2"):
    for p in gpx.phases():
        p.set_HAP_refinements({"Mustrain": {"type": "uniaxial", "refine": True}})
    ref("+ uniaxial microstrain")

gpx.save()
print("FINAL wR %.4f" % hist.get_wR())
cov = gpx.data['Covariance']['data']['Rvals']
print("GOF %.3f  Nvars %d  converged %s  maxshift/sig %.2f" %
      (cov['GOF'], cov['Nvars'], cov['converged'], cov.get('Max shft/sig', -1)))
for p in gpx.phases():
    print(p.name, {k: round(v, 5) for k, v in p.get_cell().items()})
