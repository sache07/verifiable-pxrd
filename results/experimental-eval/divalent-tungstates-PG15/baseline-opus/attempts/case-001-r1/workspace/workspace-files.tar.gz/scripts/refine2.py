"""Rietveld refinement with physically-sensible profile parameterisation.

Instrumental U,V,W are held at values typical for a PIXcel1D Bragg-Brentano
diffractometer; sample broadening is carried by per-phase isotropic
crystallite size and microstrain.
"""
import os, sys, json
import GSASII.GSASIIscriptable as G2sc

WORK = "<ATTEMPT_WORKSPACE>/work"
os.chdir(WORK)

gpx_name = sys.argv[1]
phase_list = sys.argv[2].split(",")

CIF = {"BaCO3": "ref_BaCO3.cif", "WO3": "ref_WO3.cif", "BaWO4": "ref_BaWO4.cif"}

if os.path.exists(gpx_name):
    os.remove(gpx_name)
gpx = G2sc.G2Project(newgpx=gpx_name)
hist = gpx.add_powder_histogram("pattern.xy", "cuka.instprm", fmthint="Topas xye")

ip = hist.data['Instrument Parameters'][0]
# U,V,W,X,Y are in centidegrees**2 / centidegrees; observed FWHM ~0.15-0.20 deg
for k, v in dict(U=40.0, V=-15.0, W=120.0, X=4.0, Y=4.0).items():
    ip[k][0] = ip[k][1] = v
# peak positions are offset by ~+0.3 deg at 24 deg (sample displacement)
hist.data['Sample Parameters']['Shift'][0] = -580.0

for p in phase_list:
    gpx.add_phase(CIF[p], phasename=p, histograms=[hist])

def ref(label, **kw):
    gpx.do_refinements([{}])
    print(f"  {label:28s} wR = {hist.get_wR():.3f}", flush=True)

hist.set_refinements({"Background": {"no. coeffs": 10, "type": "chebyschev-1",
                                     "refine": True}})
ref("background")

for p in gpx.phases():
    p.set_HAP_refinements({"Scale": True})
ref("+ phase scales")

hist.set_refinements({"Sample Parameters": ["Shift"]})
ref("+ sample displacement")

for p in gpx.phases():
    p.set_refinements({"Cell": True})
ref("+ unit cells")

for p in gpx.phases():
    p.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True},
                           "Size": {"type": "isotropic", "refine": True}})
ref("+ size/microstrain")

# preferred orientation (March-Dollase) is tried separately in later stages
gpx.save()
print("FINAL wR", hist.get_wR())
for p in gpx.phases():
    c = p.get_cell()
    print(p.name, {k: round(v, 5) for k, v in c.items()})
