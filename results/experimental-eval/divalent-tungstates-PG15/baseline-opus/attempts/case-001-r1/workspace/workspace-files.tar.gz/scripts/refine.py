"""Two/three-phase Rietveld refinement of BaCO3 + WO3 (+ optional BaWO4)."""
import os, sys, json, shutil
import numpy as np
import GSASII.GSASIIscriptable as G2sc

WORK = "<ATTEMPT_WORKSPACE>/work"
os.chdir(WORK)

gpx_name = sys.argv[1] if len(sys.argv) > 1 else "trial.gpx"
phases = sys.argv[2].split(",") if len(sys.argv) > 2 else ["BaCO3", "WO3"]

CIF = {"BaCO3": ("ref_BaCO3.cif", "BaCO3"),
       "WO3":   ("ref_WO3.cif", "WO3"),
       "BaWO4": ("ref_BaWO4.cif", "BaWO4")}

if os.path.exists(gpx_name):
    os.remove(gpx_name)
gpx = G2sc.G2Project(newgpx=gpx_name)
hist = gpx.add_powder_histogram("pattern.xy", "cuka.instprm", fmthint="Topas xye")

for p in phases:
    f, name = CIF[p]
    gpx.add_phase(f, phasename=p, histograms=[hist])

# background: shifted Chebyschev, several terms, plus refine sample displacement
hist.set_refinements({"Background": {"no. coeffs": 8, "type": "chebyschev-1",
                                     "refine": True}})
gpx.do_refinements([{}])
print("step1 bkg", hist.get_wR())

# scale factors + phase fractions
for p in gpx.phases():
    p.set_HAP_refinements({"Scale": True})
gpx.do_refinements([{}])
print("step2 scale", hist.get_wR())

# sample displacement
hist.set_refinements({"Sample Parameters": ["Shift"]})
gpx.do_refinements([{}])
print("step3 shift", hist.get_wR())

# unit cells
for p in gpx.phases():
    p.set_refinements({"Cell": True})
gpx.do_refinements([{}])
print("step4 cell", hist.get_wR())

# profile: U,V,W then X,Y + size/strain
hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
gpx.do_refinements([{}])
print("step5 UVW", hist.get_wR())

hist.set_refinements({"Instrument Parameters": ["X", "Y"]})
gpx.do_refinements([{}])
print("step6 XY", hist.get_wR())

gpx.save()
print("final wR", hist.get_wR())
for p in gpx.phases():
    print(p.name, p.get_cell())
