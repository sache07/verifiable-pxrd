import numpy as np,sys
d=np.loadtxt('inputs/pattern.csv',delimiter=',',skiprows=1)
x,y=d[:,0],d[:,1]
lo,hi=float(sys.argv[1]),float(sys.argv[2])
m=(x>=lo)&(x<=hi)
xs,ys=x[m],y[m]
n=int(sys.argv[3]) if len(sys.argv)>3 else 60
idx=np.linspace(0,len(xs)-1,n).astype(int)
for i in idx: print(f"{xs[i]:8.3f} {ys[i]:8.0f}")
