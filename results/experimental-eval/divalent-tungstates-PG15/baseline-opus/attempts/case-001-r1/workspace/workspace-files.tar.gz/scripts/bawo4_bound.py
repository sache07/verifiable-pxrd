"""Upper bound on scheelite BaWO4: add it to the converged two-phase model with
its published cell held fixed and refine only its scale factor."""
import os, shutil, re
import GSASII.GSASIIscriptable as G2sc

WORK = "<ATTEMPT_WORKSPACE>/work"
os.chdir(WORK)
shutil.copy("f3.gpx", "bound.gpx")
gpx = G2sc.G2Project("bound.gpx")
hist = gpx.histogram(0)
print("start wR %.4f" % hist.get_wR())

ph = gpx.add_phase("ref_BaWO4.cif", phasename="BaWO4", histograms=[hist])
ph.data['Histograms'][hist.name]['Size'][1][0] = 1.0
ph.data['Histograms'][hist.name]['Mustrain'][1][0] = 2000.0
ph.set_HAP_refinements({"Scale": True})
gpx.do_refinements([{}])
gpx.do_refinements([{}])
gpx.save()
print("with BaWO4 (cell held) wR %.4f" % hist.get_wR())
for line in open("bound.lst"):
    if "Weight fraction" in line or re.match(r"\s*Phase:", line):
        print("   ", line.strip())
