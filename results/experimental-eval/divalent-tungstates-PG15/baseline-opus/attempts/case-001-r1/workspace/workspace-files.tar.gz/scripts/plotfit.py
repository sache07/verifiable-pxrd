import os,sys
import numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import GSASII.GSASIIscriptable as G2sc
os.chdir("<ATTEMPT_WORKSPACE>/work")
gpx=G2sc.G2Project(sys.argv[1]); h=gpx.histogram(0)
d=h.data['data'][1]; x,yo,yc,yb=d[0],d[1],d[3],d[4]
fig,axs=plt.subplots(4,1,figsize=(16,14))
rngs=[(10,35),(35,60),(60,80),(80,100)]
for ax,(lo,hi) in zip(axs,rngs):
    m=(x>=lo)&(x<=hi)
    ax.plot(x[m],yo[m],'k.',ms=2,label='obs')
    ax.plot(x[m],yc[m],'r-',lw=0.8,label='calc')
    off=-0.15*max(yo[m].max(),1)
    ax.plot(x[m],(yo-yc)[m]+off,'b-',lw=0.6,label='diff')
    ax.axhline(off,color='gray',lw=0.4)
    ax.set_xlim(lo,hi); ax.legend(fontsize=7)
plt.tight_layout(); plt.savefig(sys.argv[2],dpi=110)
print("saved",sys.argv[2])
