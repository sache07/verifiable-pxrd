import os,sys
import numpy as np
import GSASII.GSASIIscriptable as G2sc
os.chdir("<ATTEMPT_WORKSPACE>/work")
gpx=G2sc.G2Project(sys.argv[1]); h=gpx.histogram(0)
d=h.data['data'][1]; x,yo,w,yc,yb=d[0],d[1],d[2],d[3],d[4]
np.savetxt(sys.argv[2], np.c_[x,yo,yc,yb,yo-yc], header="two_theta_deg,yobs,ycalc,ybkg,ydiff", delimiter=",", comments="", fmt="%.6f")
print("wR",h.get_wR())
