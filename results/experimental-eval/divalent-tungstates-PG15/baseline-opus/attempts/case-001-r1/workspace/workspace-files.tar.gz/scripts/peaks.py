import numpy as np, sys
d=np.loadtxt(sys.argv[1],delimiter=',',skiprows=1)
x,y=d[:,0],d[:,1]
print("range",x.min(),x.max(),"step",np.median(np.diff(x)),"n",len(x))
print("Imax",y.max(),"Imin",y.min())
# smooth
k=np.ones(5)/5
ys=np.convolve(y,k,mode='same')
# crude background: rolling min
from numpy.lib.stride_tricks import sliding_window_view
w=201
pad=np.pad(ys,w//2,mode='edge')
bg=sliding_window_view(pad,w).min(axis=1)
pad2=np.pad(bg,w//2,mode='edge')
bg=sliding_window_view(pad2,w).max(axis=1)
z=ys-bg
thr=0.02*z.max()
pk=[]
for i in range(2,len(z)-2):
    if z[i]>thr and z[i]>=z[i-1] and z[i]>=z[i+1] and z[i]>z[i-2] and z[i]>z[i+2]:
        pk.append((x[i],z[i]))
pk.sort(key=lambda t:-t[1])
print("npeaks",len(pk))
for t,h in sorted(pk):
    print(f"{t:8.3f} {h:9.1f} {100*h/max(p[1] for p in pk):6.1f}  d={1.540598/(2*np.sin(np.radians(t/2))):7.4f}")
