import os,sys,numpy as np, GSASII.GSASIIscriptable as G2sc
os.chdir("<ATTEMPT_WORKSPACE>/work")
gpx=G2sc.G2Project(sys.argv[1]); h=gpx.histogram(0)
print("wR",h.get_wR())
print("Sample",{k:v for k,v in h.data['Sample Parameters'].items() if k in ('Shift','Transparency','DisplaceX','DisplaceY','Scale')})
ip=h.data['Instrument Parameters'][0]
for k in ['Lam1','Lam2','I(L2)/I(L1)','Zero','Polariz.','U','V','W','X','Y','Z','SH/L']:
    if k in ip: print(" ip",k,ip[k])
for p in gpx.phases():
    print(p.name, p.get_cell(), "frac", h.data['Reflection Lists'][p.name].get('wtFrac') if 'Reflection Lists' in h.data else None)
import GSASII.GSASIIstrIO as G2stIO
