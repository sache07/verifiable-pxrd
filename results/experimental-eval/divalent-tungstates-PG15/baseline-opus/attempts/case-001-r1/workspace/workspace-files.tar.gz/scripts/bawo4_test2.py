"""Is the ~2.7 wt% BaWO4 found by the 3-phase fit real, or is it soaking up the
WO3 peak-shape misfit near 26.9 deg?

Test A: exclude 26.4-27.4 deg (the only region where BaWO4's strongest line
        overlaps a strong WO3 line) and see whether BaWO4 survives.
Test B: use the triclinic (delta) WO3 model, which splits the 26.6/26.9 doublet,
        and see whether BaWO4 is still needed.
"""
import os, shutil, sys, re
import GSASII.GSASIIscriptable as G2sc

WORK = "<ATTEMPT_WORKSPACE>/work"
os.chdir(WORK)
test = sys.argv[1]

if test == "A":
    shutil.copy("f3.gpx", "testA.gpx")
    gpx = G2sc.G2Project("testA.gpx")
    hist = gpx.histogram(0)
    hist.data['Limits'].append([26.40, 27.40])
    gpx.do_refinements([{}])
    print("2-phase, 26.4-27.4 excluded: wR %.4f" % hist.get_wR())
    ph = gpx.add_phase("ref_BaWO4.cif", phasename="BaWO4", histograms=[hist])
    ph.data['Histograms'][hist.name]['Size'][1][0] = 1.0
    ph.data['Histograms'][hist.name]['Mustrain'][1][0] = 2000.0
    ph.set_HAP_refinements({"Scale": True})
    gpx.do_refinements([{}])
    gpx.do_refinements([{}])
    gpx.save()
    print("3-phase, 26.4-27.4 excluded: wR %.4f" % hist.get_wR())
    out = "testA.lst"
else:
    shutil.copy("e_tri.gpx", "testB.gpx")
    gpx = G2sc.G2Project("testB.gpx")
    hist = gpx.histogram(0)
    ph = gpx.add_phase("ref_BaWO4.cif", phasename="BaWO4", histograms=[hist])
    ph.data['Histograms'][hist.name]['Size'][1][0] = 1.0
    ph.data['Histograms'][hist.name]['Mustrain'][1][0] = 2000.0
    ph.set_HAP_refinements({"Scale": True})
    gpx.do_refinements([{}])
    gpx.do_refinements([{}])
    gpx.save()
    print("triclinic WO3 + BaCO3 + BaWO4: wR %.4f" % hist.get_wR())
    out = "testB.lst"

cur = None
for line in open(out):
    m = re.match(r"\s*Phase:\s+(\S+)\s+in histogram", line)
    if m:
        cur = m.group(1)
    if "Weight fraction" in line:
        print("   %-8s %s" % (cur, line.split("Weight fraction  :")[1].strip()))
