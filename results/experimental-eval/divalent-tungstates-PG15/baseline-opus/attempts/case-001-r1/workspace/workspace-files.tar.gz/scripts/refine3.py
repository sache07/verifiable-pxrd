"""Continue a refinement: profile asymmetry, anisotropic strain, preferred
orientation, displacement parameters and atomic coordinates."""
import os, sys, shutil
import GSASII.GSASIIscriptable as G2sc

WORK = "<ATTEMPT_WORKSPACE>/work"
os.chdir(WORK)
src, dst = sys.argv[1], sys.argv[2]
if src != dst:
    shutil.copy(src, dst)
gpx = G2sc.G2Project(dst)
hist = gpx.histogram(0)

def ref(label):
    gpx.do_refinements([{}])
    print(f"  {label:34s} wR = {hist.get_wR():.3f}", flush=True)

print("start wR", hist.get_wR())

hist.set_refinements({"Instrument Parameters": ["SH/L"]})
ref("+ axial asymmetry SH/L")

hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
ref("+ instrument UVWXY")

for p in gpx.phases():
    p.set_HAP_refinements({"Mustrain": {"type": "uniaxial", "refine": True}})
ref("+ uniaxial microstrain")

for p in gpx.phases():
    p.set_HAP_refinements({"Pref.Ori.": {"type": "SH", "order": 4,
                                         "refine": True}})
ref("+ spherical-harmonic texture (L=4)")

for p in gpx.phases():
    p.set_refinements({"Atoms": {"all": "U"}})
ref("+ Uiso")

for p in gpx.phases():
    p.set_refinements({"Atoms": {"all": "XU"}})
ref("+ atomic coordinates")

gpx.save()
print("FINAL wR", hist.get_wR())
