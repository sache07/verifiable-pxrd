"""Final two-phase Rietveld refinement: witherite BaCO3 + monoclinic gamma-WO3.

Parameterisation (see report.md for the reasoning):
  * peak positions  : sample displacement ("Shift"); instrument Zero held at 0
  * profile         : global U,V,W,X,Y,SH/L + one isotropic microstrain per
                      phase.  Crystallite-size broadening is held (completely
                      correlated with microstrain for these peak widths).
  * Uiso            : grouped by species (Ba | C,O of the carbonate;
                      W | O of the oxide); W held at 0.005 A^2 if it refines
                      negative.
  * coordinates     : only the heavy-cation positions, Ba(y,z) and W1,W2(x,y,z),
                      are refined.  C and O positions are held at the published
                      values: releasing them gives chemically impossible
                      carbonate/tungstate geometries, i.e. they are not
                      determinable from this pattern.
"""
import os, sys
import GSASII.GSASIIscriptable as G2sc

WORK = "<ATTEMPT_WORKSPACE>/work"
os.chdir(WORK)
gpx_name = sys.argv[1] if len(sys.argv) > 1 else "final.gpx"
extra = sys.argv[2] if len(sys.argv) > 2 else ""

if os.path.exists(gpx_name):
    os.remove(gpx_name)
gpx = G2sc.G2Project(newgpx=gpx_name)
hist = gpx.add_powder_histogram("pattern.xy", "cuka.instprm", fmthint="Topas xye")

ip = hist.data['Instrument Parameters'][0]
for k, v in dict(U=40.0, V=-15.0, W=120.0, X=4.0, Y=4.0).items():
    ip[k][0] = ip[k][1] = v
hist.data['Sample Parameters']['Shift'][0] = -580.0

gpx.add_phase("ref_BaCO3.cif", phasename="BaCO3", histograms=[hist])
gpx.add_phase("ref_WO3.cif", phasename="WO3", histograms=[hist])
if "bawo4" in extra:
    gpx.add_phase("ref_BaWO4.cif", phasename="BaWO4", histograms=[hist])
for p in gpx.phases():
    p.data['Histograms'][hist.name]['Size'][1][0] = 1.0

def ref(label):
    gpx.do_refinements([{}])
    print(f"  {label:34s} wR = {hist.get_wR():.4f}", flush=True)

hist.set_refinements({"Background": {"no. coeffs": 8, "type": "chebyschev-1",
                                     "refine": True}})
ref("background")
for p in gpx.phases():
    p.set_HAP_refinements({"Scale": True})
ref("+ phase scales")
hist.set_refinements({"Sample Parameters": ["Shift"]})
ref("+ sample displacement")
for p in gpx.phases():
    if p.name != "BaWO4":
        p.set_refinements({"Cell": True})
ref("+ unit cells")
hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
ref("+ instrument profile")
for p in gpx.phases():
    p.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
ref("+ microstrain")
hist.set_refinements({"Instrument Parameters": ["SH/L"]})
ref("+ axial asymmetry")

# ---- grouped displacement parameters -------------------------------------
gpx.save()
idx = {ph.name: {a.label: i for i, a in enumerate(ph.atoms())} for ph in gpx.phases()}
pid = {ph.name: ph.id for ph in gpx.phases()}
uvar = lambda ph, lbl: f"{pid[ph]}::AUiso:{idx[ph][lbl]}"

gpx.add_EquivConstr([uvar("BaCO3", l) for l in ("C", "O1", "O2")])
gpx.add_EquivConstr([uvar("WO3", l) for l in idx["WO3"] if l.startswith("O")])
gpx.add_EquivConstr([uvar("WO3", "W1"), uvar("WO3", "W2")])
for p in gpx.phases():
    if p.name != "BaWO4":
        p.set_refinements({"Atoms": {"all": "U"}})
ref("+ Uiso (species-grouped)")

# W Uiso tends to run slightly negative (micro-absorption); hold it if so
wph = gpx.phase("WO3")
if wph.atom("W1").uiso < 0.001:
    for lbl in ("W1", "W2"):
        wph.atom(lbl).uiso = 0.005
    gpx.add_HoldConstr([uvar("WO3", "W1"), uvar("WO3", "W2")])
    ref("  (W Uiso held at 0.005)")

# ---- heavy-cation coordinates -------------------------------------------
gpx.phase("BaCO3").set_refinements({"Atoms": {"Ba": "X"}})
for lbl in ("W1", "W2"):
    wph.set_refinements({"Atoms": {lbl: "X"}})
ref("+ Ba and W coordinates")
ref("  (second cycle)")

gpx.save()
print("FINAL wR %.4f" % hist.get_wR())
rv = gpx.data['Covariance']['data']['Rvals']
print("GOF %.3f Rwp %.4f Nobs %d Nvars %d converged %s maxshft/sig %.2f" %
      (rv['GOF'], rv['Rwp'], rv['Nobs'], rv['Nvars'], rv['converged'],
       rv.get('Max shft/sig', -1)))
for p in gpx.phases():
    print(p.name, {k: round(v, 5) for k, v in p.get_cell().items()})
    for a in p.atoms():
        print("   ", a.label, a.element, [round(c, 4) for c in a.coordinates],
              "Uiso %.4f" % a.uiso)
