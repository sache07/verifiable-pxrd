import os, sys
import numpy as np
import GSASII.GSASIIscriptable as G2sc
WORK = "<ATTEMPT_WORKSPACE>/work"
os.chdir(WORK)
gpx = G2sc.G2Project(sys.argv[1])
h = gpx.histogram(0)
d = h.data['data'][1]
x, yo, w, yc, yb = d[0], d[1], d[2], d[3], d[4]
sig = 1/np.sqrt(np.maximum(w, 1e-30))
r = (yo - yc)/sig
print("wR %.3f  GOF-ish %.3f" % (h.get_wR(), np.sqrt(np.mean(r**2))))
print("Residuals: largest contiguous misfit regions")
# bin residual chi contributions in 0.5 deg bins
bins = np.arange(x.min(), x.max()+0.5, 0.5)
idx = np.digitize(x, bins)-1
rows = []
for b in range(len(bins)-1):
    m = idx == b
    if m.sum() < 3: continue
    rows.append((np.mean(r[m]**2), bins[b], np.max(np.abs(yo-yc)[m]), np.mean(yo[m])))
rows.sort(reverse=True)
for v, b, mx, mo in rows[:25]:
    print(f"  2th {b:6.2f}-{b+0.5:6.2f}  <chi2>={v:8.1f}  maxdiff={mx:8.0f}  <Iobs>={mo:8.0f}")
