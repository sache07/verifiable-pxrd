import os,sys
import GSASII.GSASIIscriptable as G2sc
os.chdir("<ATTEMPT_WORKSPACE>/work")
gpx=G2sc.G2Project(sys.argv[1]); h=gpx.histogram(0)
print("wR",h.get_wR())
for p in gpx.phases():
    hd=p.data['Histograms'][h.name]
    print("==",p.name,"Scale",hd['Scale'])
    print("   Size",hd['Size'])
    print("   Mustrain",hd['Mustrain'])
    print("   HStrain",hd['HStrain'])
    print("   Pref.Ori.",hd['Pref.Ori.'])
    print("   SGSys", p.data['General']['SGData']['SGSys'], p.data['General']['SGData']['SpGrp'])
    print("   Cell", p.data['General']['Cell'])
print("Back", h.data['Background'][0][:3], h.data['Background'][0][3:])
cov=gpx.data.get('Covariance',{}).get('data',{})
print("Rvals", cov.get('Rvals'))
vn=cov.get('varyList',[]); vv=cov.get('variables',[]); sig=cov.get('sig',[])
for a,b,c in zip(vn,vv,sig):
    print(f"   {a:22s} {b: .6g} +- {c if c is None else round(c,6)}")
