import gzip, json, sys
p="<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz"
d=json.load(gzip.open(p,'rt'))
for k in sys.argv[1:]:
    print("###",k, d.get(k) is not None)
    for e in d.get(k,[]): print("  ",e)
