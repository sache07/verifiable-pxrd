import os,sys,shutil
import GSASII.GSASIIscriptable as G2sc
os.chdir("<ATTEMPT_WORKSPACE>/work")
shutil.copy(sys.argv[1],'dbg.gpx')
gpx=G2sc.G2Project('dbg.gpx'); h=gpx.histogram(0)
what=sys.argv[2]
for p in gpx.phases():
    print(p.name, p.data['Histograms'][h.name]['Mustrain'], p.data['Histograms'][h.name]['Size'])
if what=='mu':
    for p in gpx.phases():
        p.set_HAP_refinements({"Mustrain":{"type":"uniaxial","refine":True}})
elif what=='po':
    for p in gpx.phases():
        p.set_HAP_refinements({"Pref.Ori.":{"type":"SH","order":4,"refine":True}})
elif what=='u':
    for p in gpx.phases():
        p.set_refinements({"Atoms":{"all":"U"}})
gpx.do_refinements([{}])
print("wR",h.get_wR())
