import os,sys
import GSASII.GSASIIscriptable as G2sc
os.chdir("<ATTEMPT_WORKSPACE>/work")
gpx=G2sc.G2Project(sys.argv[1])
out=sys.argv[2] if len(sys.argv)>2 else None
for p in gpx.phases():
    print("=====",p.name)
    for a in p.atoms():
        print(f"  {a.label:6s} {a.element:2s} {a.coordinates[0]: .4f} {a.coordinates[1]: .4f} {a.coordinates[2]: .4f}  Uiso {a.uiso: .4f} occ {a.occupancy}")
    if out:
        p.export_CIF(f"{out}_{p.name}.cif")
