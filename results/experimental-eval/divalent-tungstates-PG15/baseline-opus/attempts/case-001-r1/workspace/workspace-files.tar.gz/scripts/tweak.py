"""Add one extra model feature to an existing refinement and report the gain."""
import os, sys, shutil
import GSASII.GSASIIscriptable as G2sc

WORK = "<ATTEMPT_WORKSPACE>/work"
os.chdir(WORK)
src, dst, what = sys.argv[1], sys.argv[2], sys.argv[3]
shutil.copy(src, dst)
gpx = G2sc.G2Project(dst)
hist = gpx.histogram(0)
start = hist.get_wR()

if what.startswith("md:"):          # md:PHASE:h,k,l
    _, phn, hkl = what.split(":")
    ph = gpx.phase(phn)
    ph.set_HAP_refinements({"Pref.Ori.": {"type": "MD", "refine": True}})
    po = ph.data['Histograms'][hist.name]['Pref.Ori.']
    po[3] = [int(v) for v in hkl.split(",")]
elif what.startswith("sh:"):        # sh:PHASE:order
    _, phn, order = what.split(":")
    gpx.phase(phn).set_HAP_refinements(
        {"Pref.Ori.": {"type": "SH", "order": int(order), "refine": True}})
elif what.startswith("gmu:"):       # gmu:PHASE  generalized microstrain
    phn = what.split(":")[1]
    gpx.phase(phn).set_HAP_refinements({"Mustrain": {"type": "generalized",
                                                     "refine": True}})
elif what.startswith("hstrain:"):   # hstrain:PHASE  anisotropic cell strain
    phn = what.split(":")[1]
    gpx.phase(phn).set_HAP_refinements({"HStrain": True})
elif what.startswith("size:"):      # size:PHASE
    phn = what.split(":")[1]
    gpx.phase(phn).set_HAP_refinements({"Size": {"type": "isotropic",
                                                 "refine": True}})
elif what == "k2":
    hist.data['Instrument Parameters'][0]['I(L2)/I(L1)'][2] = True
elif what == "zero":
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
elif what == "nothing":
    pass
else:
    raise SystemExit("unknown: " + what)

gpx.do_refinements([{}])
gpx.do_refinements([{}])
gpx.save()
wf = [l.strip() for l in open(dst.replace(".gpx", ".lst"))
      if "Weight fraction" in l]
print("%-24s %.4f -> %.4f   %s" % (what, start, hist.get_wR(),
      " | ".join(w.split("Weight fraction  :")[1].strip() for w in wf)))
for p in gpx.phases():
    hd = p.data['Histograms'][hist.name]
    print("   ", p.name, "MD", hd['Pref.Ori.'][:4], "mustr", hd['Mustrain'][0],
          [round(v, 1) for v in hd['Mustrain'][1][:3]], "size", round(hd['Size'][1][0], 3))
