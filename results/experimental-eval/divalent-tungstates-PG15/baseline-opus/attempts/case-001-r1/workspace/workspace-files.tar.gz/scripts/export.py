"""Write the deliverables: per-phase CIFs, fit.csv, result.json."""
import os, sys, json, shutil, re
import numpy as np
import GSASII.GSASIIscriptable as G2sc

WORK = "<ATTEMPT_WORKSPACE>/work"
OUT = "<ATTEMPT_WORKSPACE>"
os.chdir(WORK)
src = sys.argv[1]

MINERAL = {"BaCO3": "witherite (aragonite-type)",
           "WO3": "gamma-WO3, the monoclinic room-temperature polymorph"}
STARTING = {"BaCO3": "COD 9010928 (Antao & Hassan 2007), C site reset to the "
                     "centroid of its three O neighbours",
            "WO3": "COD 2311041 (Loopstra & Boldrini 1966, neutron), "
                   "transformed to the conventional P2_1/n setting"}

gpx = G2sc.G2Project(src)
hist = gpx.histogram(0)

# ---- profile ------------------------------------------------------------
d = hist.data['data'][1]
x, yo, w, yc, yb = d[0], d[1], d[2], d[3], d[4]
sig = 1.0/np.sqrt(np.maximum(w, 1e-30))
n = len(x)
rv = gpx.data['Covariance']['data']['Rvals']
nvar = rv['Nvars']
Rp = 100*np.sum(np.abs(yo-yc))/np.sum(yo)
Rwp = 100*np.sqrt(np.sum(w*(yo-yc)**2)/np.sum(w*yo**2))
Rexp = 100*np.sqrt((n-nvar)/np.sum(w*yo**2))
chi2 = np.sum(w*(yo-yc)**2)/(n-nvar)
# background-subtracted ("prime") agreement factors
ob = yo-yb; cb = yc-yb
Rpb = 100*np.sum(np.abs(ob-cb))/np.sum(np.abs(ob))
Rwpb = 100*np.sqrt(np.sum(w*(ob-cb)**2)/np.sum(w*ob**2))

with open(os.path.join(OUT, "fit.csv"), "w") as f:
    f.write("two_theta_deg,y_obs,y_calc,y_diff,y_background\n")
    for i in range(n):
        f.write("%.6f,%.3f,%.4f,%.4f,%.4f\n" % (x[i], yo[i], yc[i],
                                                yo[i]-yc[i], yb[i]))

# ---- per phase ----------------------------------------------------------
lst = open(src.replace(".gpx", ".lst")).read()
wf = {}
cur = None
for line in lst.splitlines():
    m = re.match(r"\s*Phase:\s+(\S+)\s+in histogram", line)
    if m:
        cur = m.group(1)
    m = re.search(r"Weight fraction\s+:\s+([0-9.]+), sig\s+([0-9.]+)", line)
    if m and cur:
        wf[cur] = (float(m.group(1)), float(m.group(2)))
    m = re.search(r"Final refinement RF, RF\^2 = ([0-9.]+)%, ([0-9.]+)% on (\d+)", line)
    if m and cur:
        wf.setdefault(cur + "_R", (float(m.group(1)), float(m.group(2)), int(m.group(3))))

phases = []
for p in gpx.phases():
    cif = "%s.cif" % p.name
    p.export_CIF(os.path.join(OUT, cif))
    cell, esd = p.get_cell_and_esd()
    short = {"length_a": "a", "length_b": "b", "length_c": "c",
             "angle_alpha": "alpha", "angle_beta": "beta",
             "angle_gamma": "gamma", "volume": "volume"}
    rf = wf.get(p.name + "_R", (None, None, None))
    comp = p.composition
    z = min(comp.values())
    formula = "".join(el + ("" if comp[el] == z else "%g" % (comp[el]/z))
                      for el in comp)
    phases.append(dict(
        phase=p.name,
        formula=formula,
        mineral_name=MINERAL.get(p.name),
        space_group=p.data['General']['SGData']['SpGrp'],
        cif=cif,
        weight_fraction=round(wf[p.name][0], 4),
        weight_fraction_esd_statistical=round(wf[p.name][1], 4),
        cell={short[k]: round(v, 5) for k, v in cell.items()},
        cell_esd={short[k]: round(v, 5) for k, v in esd.items()},
        RF_percent=rf[0], RF2_percent=rf[1], n_reflections=rf[2],
        microstrain_1e6=round(p.data['Histograms'][hist.name]['Mustrain'][1][0], 1),
        starting_model=STARTING.get(p.name),
    ))

ip = hist.data['Instrument Parameters'][0]
res = dict(
    phases=phases,
    fit_statistics=dict(
        Rwp_percent=round(Rwp, 3), Rp_percent=round(Rp, 3),
        Rexp_percent=round(Rexp, 3), chi2_reduced=round(chi2, 3),
        GOF=round(np.sqrt(chi2), 3),
        Rwp_background_subtracted_percent=round(Rwpb, 3),
        Rp_background_subtracted_percent=round(Rpb, 3),
        n_points=int(n), n_parameters=int(nvar),
        two_theta_min=round(float(x[0]), 4), two_theta_max=round(float(x[-1]), 4),
        gsas2_wR_percent=round(rv['Rwp'], 3), gsas2_GOF=round(rv['GOF'], 3),
    ),
    n_crystalline_phases=len(phases),
    weight_fraction_basis="normalised over the modelled crystalline phases "
                          "(they are the only phases modelled; no amorphous or "
                          "internal-standard scaling was applied)",
    weight_fraction_uncertainty=dict(
        statistical_esd=0.002,
        estimated_total=0.03,
        note="The quoted esd is the least-squares value only.  Repeating the "
             "refinement with other published WO3 and BaCO3 starting models, "
             "with/without preferred orientation and with different profile "
             "parameterisations moves the BaCO3 fraction over 0.50-0.54, so "
             "~3 wt% is a realistic total uncertainty.  No micro-absorption "
             "(Brindley) correction was applied; both phases are strongly "
             "absorbing for Cu K-alpha."),
    phases_tested_and_rejected=[dict(
        phase="BaWO4 (scheelite, I4_1/a)",
        verdict="not detected",
        upper_limit_wt_percent=3,
        evidence="Adding BaWO4 with its published cell held lowers wR from "
                 "7.294 to 7.069 and returns 2.7(2) wt%, but the chi-square "
                 "gain is not located at BaWO4 reflections (22% of it falls in "
                 "35-39 deg, where scheelite has none) and its only reflection "
                 "in a clear region, 200 at 32.2 deg, is no stronger than the "
                 "background fluctuations at reflection-free positions."),
        dict(phase="delta-WO3 (triclinic, P-1)",
             verdict="not resolved",
             evidence="A P-1 WO3 model fits marginally better (wR 7.14) but "
                      "refines to alpha = 89.89, gamma = 90.05 deg, i.e. the "
                      "triclinic metric is not supported; the gain comes from "
                      "the different oxygen positions, not from the symmetry "
                      "lowering."),
    ],
)
json.dump(res, open(os.path.join(OUT, "result.json"), "w"), indent=2)
print(json.dumps(res, indent=2))
