import numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
d = np.loadtxt('fit.csv', delimiter=',', skiprows=1)
x, yo, yc, yd, yb = d.T
fig, axs = plt.subplots(2, 1, figsize=(13, 9),
                        gridspec_kw=dict(height_ratios=[1, 1]))
for ax, (lo, hi) in zip(axs, [(9.9, 55), (55, 100.1)]):
    m = (x >= lo) & (x <= hi)
    ax.plot(x[m], yo[m], 'k.', ms=2.2, label='observed')
    ax.plot(x[m], yc[m], 'r-', lw=0.9, label='calculated')
    off = -0.22*yo[m].max()
    ax.plot(x[m], yd[m]+off, 'b-', lw=0.6, label='difference')
    ax.axhline(off, color='0.6', lw=0.4)
    ax.set_xlim(lo, hi); ax.set_xlabel(r'2$\theta$ / deg (Cu K$\alpha$)')
    ax.set_ylabel('counts'); ax.legend(fontsize=8, loc='upper right')
axs[0].set_title('BaCO$_3$ (witherite) + $\\gamma$-WO$_3$ two-phase Rietveld fit, '
                 '$R_{wp}$ = 7.29 %, GOF = 2.10')
plt.tight_layout(); plt.savefig('fit_overview.png', dpi=120)
print('ok')
