#!/usr/bin/env python3
"""Challenge isotropic PbWO4 microstrain with symmetry-compatible models."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np

from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIIpwd as G2pwd
from GSASII import GSASIIspc as G2spc
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", choices=("uniaxial", "generalized"))
    parser.add_argument("output", type=Path)
    parser.add_argument("--source", type=Path, default=Path("final.gpx"))
    args = parser.parse_args()

    source = args.source.resolve()
    output = args.output.resolve()
    project = G2sc.G2Project(gpxfile=str(source))
    project.save(str(output))
    hist = project.histogram(0)
    profile = hist.data["data"][1]
    hist.set_refinements(
        {"Limits": [float(profile[0][0]), float(profile[0][-1])]}
    )
    phase = project.phase("PbWO4")
    hap = phase.data["Histograms"][hist.name]
    mu = hap["Mustrain"]
    mu_iso = float(mu[1][0])

    if args.model == "uniaxial":
        mu[0] = "uniaxial"
        mu[1][0] = mu_iso
        mu[1][1] = mu_iso
        mu[1][2] = 1.0
        mu[2] = [True, True, False]
        mu[3] = [0, 0, 1]
        mu[5] = [False for _ in mu[5]]
    else:
        sg = phase.data["General"]["SGData"]
        cell = list(phase.get_cell().values())[:6]
        mu[0] = "generalized"
        mu[2] = [False for _ in mu[2]]
        mu[4] = list(G2spc.Muiso2Shkl(mu_iso, sg, cell))
        mu[5] = [True for _ in mu[5]]

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 10
    controls["min dM/M"] = 5.0e-6
    before = hist.get_wR()
    project.refine(printFile=str(output.with_suffix(".lst")))
    first = project.histogram(0).get_wR()
    project.save()

    replay = G2sc.G2Project(gpxfile=str(output))
    replay.data["Controls"]["data"]["max cyc"] = 10
    replay.refine(printFile=str(output.with_name(output.stem + "_replay.lst")))
    replay.save()
    hist = replay.histogram(0)
    phase = replay.phase("PbWO4")
    mu = phase.data["Histograms"][hist.name]["Mustrain"]
    refl = hist.data["Reflection Lists"]["PbWO4"]["RefList"]
    hkl = np.asarray(refl[:, :3]).T
    cell = list(phase.get_cell().values())[:6]
    gmat = G2lat.cell2Gmat(cell)[0]
    effective = np.asarray(
        G2pwd.getMustrain(hkl, gmat, phase.data["General"]["SGData"], mu)
    )
    rvals = replay.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    values = {
        "type": mu[0],
        "isotropic_uniaxial_values": [float(v) for v in mu[1]],
        "generalized_values": [float(v) for v in mu[4]],
        "effective_min": float(np.nanmin(effective)),
        "effective_max": float(np.nanmax(effective)),
    }
    physical = bool(
        np.all(np.isfinite(effective))
        and np.all(effective >= 0)
        and all(
            phase.data["Histograms"][hist.name]["Scale"][0] > 0
            for phase in replay.phases()
        )
    )
    summary = {
        "model": args.model,
        "project": str(output),
        "Rwp_before": before,
        "Rwp_first": first,
        "Rwp_replay": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "maximum_shift_over_esd": rvals.get("Max shft/sig"),
        "physical": physical,
        "values": values,
        "fractions": hist.ComputeMassFracs(),
    }
    output.with_suffix(".json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
