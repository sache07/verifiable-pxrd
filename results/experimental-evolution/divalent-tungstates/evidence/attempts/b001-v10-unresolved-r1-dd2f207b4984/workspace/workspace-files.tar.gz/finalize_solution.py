#!/usr/bin/env python3
"""Freeze, replay, export, and cross-check the final GSAS-II solution."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials" / "pbwo4_generalized.gpx"
OUTPUT = ROOT / "final.gpx"

CIF_NAMES = {
    "PbWO4": "PbWO4.cif",
    "WO3": "WO3.cif",
    "Pb3O4": "Pb3O4.cif",
    "PbO": "PbO.cif",
}

FORMULAS = {
    "PbWO4": "PbWO4",
    "WO3": "WO3",
    "Pb3O4": "Pb3O4",
    "PbO": "PbO",
}


def prune_to_supported_model(project: G2sc.G2Project) -> None:
    """Set inactive terms to neutral values and keep only supported flags."""
    hist = project.histogram(0)
    data = hist.data["data"][1]
    hist.set_refinements({"Limits": [float(data[0][0]), float(data[0][-1])]})

    inst = hist.data["Instrument Parameters"][0]
    for value in inst.values():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
            value[2] = False
    inst["Zero"][2] = True
    inst["W"][2] = True
    # Keep the measured Cu K-alpha doublet and the neutral low-dimensional
    # profile terms fixed at their supplied values.
    inst["Lam1"][1] = 1.540598
    inst["Lam2"][1] = 1.544426
    inst["I(L2)/I(L1)"][1] = 0.5
    inst["Polariz."][1] = 0.5
    inst["U"][1] = 5.0
    inst["V"][1] = 0.0
    inst["X"][1] = 8.0
    inst["Y"][1] = 0.0
    inst["Z"][1] = 0.0
    inst["SH/L"][1] = 0.002

    sample = hist.data["Sample Parameters"]
    sample["Type"] = "Bragg-Brentano"
    sample["Scale"] = [1.0, False]
    for key in ("Absorption", "DisplaceX", "DisplaceY", "Shift", "Transparency"):
        if key in sample and isinstance(sample[key], list):
            sample[key][0] = 0.0
            sample[key][1] = False
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"][1] = True

    supported_isotropic_strain = {"Pb3O4", "PbO"}
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True

        size = hap["Size"]
        size[0] = "isotropic"
        size[1] = [10.0, 10.0, 1.0]
        size[2] = [False for _ in size[2]]
        size[4] = [10.0 for _ in size[4]]
        size[5] = [False for _ in size[5]]

        strain = hap["Mustrain"]
        strain[1][1:] = [0.0, 1.0]
        if phase.name == "PbWO4":
            # The four tetragonal Stephens coefficients are independently
            # supported by multiple hkl families and remain positive in the
            # effective-strain domain over the measured reflection set.
            strain[0] = "generalized"
            strain[2] = [False for _ in strain[2]]
            strain[5] = [True for _ in strain[5]]
        else:
            strain[0] = "isotropic"
            strain[2] = [
                phase.name in supported_isotropic_strain,
                False,
                False,
            ]
            strain[4] = [0.0 for _ in strain[4]]
            strain[5] = [False for _ in strain[5]]
            if phase.name not in supported_isotropic_strain:
                strain[1][0] = 0.0

        pref = hap["Pref.Ori."]
        pref[0] = "MD"
        pref[1] = 1.0
        pref[2] = False
        pref[3] = [0, 0, 1]
        if len(pref) > 4:
            pref[4] = 0
        if len(pref) > 5 and isinstance(pref[5], dict):
            pref[5] = {}
        if len(pref) > 6 and isinstance(pref[6], list):
            pref[6] = []

        hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        hap["Extinction"] = [0.0, False]
        for key in ("BabA", "BabU"):
            hap["Babinet"][key] = [0.0, False]


def refine_and_replay() -> G2sc.G2Project:
    if not SOURCE.is_file():
        raise FileNotFoundError(SOURCE)
    project = G2sc.G2Project(gpxfile=str(SOURCE))
    project.save(str(OUTPUT))
    prune_to_supported_model(project)
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 10
    controls["min dM/M"] = 5.0e-6
    controls["shift factor"] = 1.0
    project.refine(printFile=str(ROOT / "final_full_range.lst"))
    project.save()

    # The submitted values must come from a fresh reopen/replay of the file.
    replay = G2sc.G2Project(gpxfile=str(OUTPUT))
    prune_to_supported_model(replay)
    replay.refine(printFile=str(ROOT / "final_replay.lst"))
    replay.save()
    return G2sc.G2Project(gpxfile=str(OUTPUT))


def export_outputs(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    raw_fracs = hist.ComputeMassFracs()
    total = sum(float(value[0]) for value in raw_fracs.values())
    if not math.isfinite(total) or total <= 0:
        raise RuntimeError(f"invalid phase-fraction sum: {total}")

    phases = []
    for phase in project.phases():
        cif_name = CIF_NAMES[phase.name]
        phase.export_CIF(str(ROOT / cif_name))
        value, esd = raw_fracs[phase.name]
        sg = phase.data["General"]["SGData"].get("SpGrp", "")
        phases.append(
            {
                "name": phase.name,
                "formula": FORMULAS[phase.name],
                "space_group": sg,
                "cif_path": cif_name,
                "weight_fraction": float(value) / total,
                "weight_fraction_esd": float(esd),
            }
        )

    profile = hist.data["data"][1]
    x, yobs, _, ycalc, ybkg, ydiff = [np.asarray(v) for v in profile[:6]]
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_observed_minus_calculated",
                "background_intensity",
            ]
        )
        writer.writerows(zip(x, yobs, ycalc, ydiff, ybkg))

    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    hist_stats = hist.data["data"][0]
    result = {
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": float(hist.get_wR()),
            "Rp_percent": float(hist_stats.get("R", float("nan"))),
            "Rexp_percent": float(hist_stats.get("wRmin", float("nan"))),
            "goodness_of_fit": float(rvals.get("GOF", float("nan"))),
            "chi_squared": float(rvals.get("chisq", float("nan"))),
            "n_observations": int(rvals.get("Nobs", len(x))),
            "n_variables": int(rvals.get("Nvars", 0)),
            "converged": bool(rvals.get("converged", False)),
            "maximum_shift_over_esd": float(rvals.get("Max shft/sig", float("nan"))),
        },
        "measurement_range_two_theta_deg": [float(x[0]), float(x[-1])],
        "wavelength_angstrom": {
            "Kalpha1": 1.540598,
            "Kalpha2": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def validate(project: G2sc.G2Project, result: dict) -> None:
    fractions = [row["weight_fraction"] for row in result["phases"]]
    if abs(sum(fractions) - 1.0) > 1.0e-9:
        raise RuntimeError("exported phase fractions do not sum to one")
    if result["project_path"] != "final.gpx":
        raise RuntimeError("result project path is not final.gpx")
    for row in result["phases"]:
        if not (ROOT / row["cif_path"]).is_file():
            raise FileNotFoundError(row["cif_path"])
        if not isinstance(row["weight_fraction"], float):
            raise TypeError("weight fraction is not numeric")
    x = np.asarray(project.histogram(0).data["data"][1][0])
    csv_rows = sum(1 for _ in (ROOT / "fit.csv").open()) - 1
    if csv_rows != len(x):
        raise RuntimeError(f"fit.csv has {csv_rows} rows, expected {len(x)}")


def main() -> None:
    project = refine_and_replay()
    result = export_outputs(project)
    validate(project, result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
