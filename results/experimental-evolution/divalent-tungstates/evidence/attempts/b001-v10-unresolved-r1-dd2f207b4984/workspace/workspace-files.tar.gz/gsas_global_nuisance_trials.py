#!/usr/bin/env python3
"""Test polarization and surface roughness before phase texture."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def run_trial(baseline: Path, output: Path, term: str, cycles: int) -> dict:
    project = G2sc.G2Project(gpxfile=str(baseline))
    project.save(str(output))
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = cycles
    controls["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    before = hist.get_wR()

    if term == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif term == "polarization_boundary":
        inst = hist.data["Instrument Parameters"][0]
        inst["Polariz."][1] = 1.0
        inst["Polariz."][2] = False
    elif term == "roughness_a":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"][1] = True
    elif term == "roughness_b":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.0, True]
    else:
        raise ValueError(term)

    project.refine()
    first = project.histogram(0).get_wR()
    project.refine()
    replay = project.histogram(0).get_wR()
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    values = {
        "polarization": float(inst["Polariz."][1]),
        "roughness_a": float(sample["SurfRoughA"][0]),
        "roughness_b": float(sample["SurfRoughB"][0]),
    }
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    stable = (
        abs(float(first) - float(replay)) < 0.02
        and not rvals.get("Aborted", False)
    )
    if term in ("polarization", "polarization_boundary"):
        physical = math.isfinite(values["polarization"]) and 0 <= values["polarization"] <= 1
    elif term == "roughness_a":
        physical = (
            math.isfinite(values["roughness_a"])
            and 0 <= values["roughness_a"] <= 1
            and math.isfinite(values["roughness_b"])
            and values["roughness_b"] >= 0
        )
    else:
        physical = math.isfinite(values["roughness_b"]) and values["roughness_b"] >= 0
    summary = {
        "term": term,
        "project": str(output),
        "Rwp_before": before,
        "Rwp_first": first,
        "Rwp_replay": replay,
        "values": values,
        "physical": physical,
        "stable": stable,
        "accepted_by_value_and_replay": bool(physical and stable),
        "Rvals": rvals,
        "fractions": hist.ComputeMassFracs(),
    }
    project.save()
    output.with_suffix(".json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument(
        "--terms",
        nargs="+",
        choices=("polarization", "polarization_boundary", "roughness_a", "roughness_b"),
        default=("polarization", "roughness_b"),
    )
    args = parser.parse_args()
    baseline = args.baseline.resolve()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for term in args.terms:
        output = (args.output_dir / f"{term}.gpx").resolve()
        row = run_trial(baseline, output, term, args.cycles)
        rows.append(row)
        print(json.dumps(row, indent=2))
    (args.output_dir / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
