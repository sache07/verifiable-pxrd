#!/usr/bin/env python3
"""Compare no texture with symmetry-distinct March-Dollase axes."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


AXES = {
    "PbWO4": ((0, 0, 1), (1, 1, 0)),
    "WO3": ((0, 1, 0), (1, 1, 1)),
    "Pb3O4": ((0, 0, 1), (1, 1, 0)),
    "PbO": ((0, 0, 1), (1, 1, 1)),
}


def trial(
    baseline: Path, output: Path, phase_name: str, axis: tuple[int, int, int], cycles: int
) -> dict:
    project = G2sc.G2Project(gpxfile=str(baseline))
    project.save(str(output))
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = cycles
    controls["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    before = hist.get_wR()
    phase = project.phase(phase_name)
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = list(axis)
    if len(pref) > 4:
        pref[4] = 0
    if len(pref) > 5:
        pref[5] = {}
    if len(pref) > 6:
        pref[6] = []

    project.refine()
    first = project.histogram(0).get_wR()
    project.refine()
    replay = project.histogram(0).get_wR()
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    ratio = float(pref[1])
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    physical = math.isfinite(ratio) and 0.2 < ratio < 5.0
    stable = (
        abs(float(first) - float(replay)) < 0.02
        and not rvals.get("Aborted", False)
        and bool(rvals.get("converged", False))
    )
    row = {
        "phase": phase_name,
        "axis": list(axis),
        "ratio": ratio,
        "project": str(output),
        "Rwp_before": before,
        "Rwp_first": first,
        "Rwp_replay": replay,
        "physical": physical,
        "stable": stable,
        "accepted_by_value_and_replay": bool(physical and stable),
        "Rvals": rvals,
        "fractions": hist.ComputeMassFracs(),
    }
    project.save()
    output.with_suffix(".json").write_text(json.dumps(row, indent=2) + "\n")
    return row


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()
    baseline = args.baseline.resolve()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    probe = G2sc.G2Project(gpxfile=str(baseline))
    phase_names = {phase.name for phase in probe.phases()}
    for phase_name, axes in AXES.items():
        if phase_name not in phase_names:
            continue
        for axis in axes:
            tag = "".join(str(v) for v in axis)
            output = (args.output_dir / f"{phase_name}_{tag}.gpx").resolve()
            row = trial(baseline, output, phase_name, axis, args.cycles)
            rows.append(row)
            print(json.dumps(row, indent=2))
    (args.output_dir / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
