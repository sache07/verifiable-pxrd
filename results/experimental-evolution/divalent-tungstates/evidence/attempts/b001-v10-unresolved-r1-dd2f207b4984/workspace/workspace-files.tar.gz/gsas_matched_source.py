#!/usr/bin/env python3
"""Compare structural sources under the accepted matched nuisance model."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from gsas_trial import instrument_parameters, set_neutral_hap, set_neutral_sample


SUPPORTED_STRAIN = {
    "PbWO4": 4813.96,
    "Pb3O4": 13486.30,
    "PbO": 8406.17,
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--phase", action="append", required=True, metavar="NAME=CIF")
    parser.add_argument("--cycles", type=int, default=6)
    parser.add_argument("--surface-roughness-b", type=float)
    args = parser.parse_args()

    specs = []
    for item in args.phase:
        name, sep, filename = item.partition("=")
        if not sep:
            parser.error(f"invalid phase specification: {item}")
        path = Path(filename).resolve()
        if not path.is_file():
            parser.error(f"missing CIF: {path}")
        specs.append((name, path))

    output = args.output.resolve()
    project = G2sc.G2Project(newgpx=str(output))
    iparms = instrument_parameters()
    iparms[0]["W"][1] = 34.5
    hist = project.add_powder_histogram(
        str(Path("inputs/pattern.csv").resolve()), iparms, fmthint="comma"
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 10,
                "coeffs": [1000.0] + [0.0] * 9,
            }
        }
    )
    set_neutral_sample(hist)
    if args.surface_roughness_b is not None:
        hist.data["Sample Parameters"]["SurfRoughB"] = [
            float(args.surface_roughness_b),
            True,
        ]

    phases = []
    for name, path in specs:
        phase = project.add_phase(
            str(path), phasename=name, histograms=[hist], fmthint="CIF"
        )
        set_neutral_hap(phase, hist.name)
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][0] = 1.0
        hap["Scale"][1] = True
        if name in SUPPORTED_STRAIN:
            hap["Mustrain"][1][0] = SUPPORTED_STRAIN[name]
            hap["Mustrain"][2][0] = True
        phases.append(phase)

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = args.cycles
    controls["min dM/M"] = 1.0e-5
    project.save()

    # Identical sequence for each source candidate.
    project.refine()
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.refine()
    hist.set_refinements({"Instrument Parameters": ["W"]})
    project.refine()
    project.refine()
    project.save()

    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    values = {key: float(inst[key][1]) for key in ("U", "W", "X")}
    scales = {}
    strains = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        scales[phase.name] = float(hap["Scale"][0])
        strains[phase.name] = float(hap["Mustrain"][1][0])
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    physical = all(math.isfinite(v) and v >= 0 for v in values.values())
    physical = physical and all(v > 0 for v in scales.values())
    physical = physical and all(
        strains[name] > 0 for name in SUPPORTED_STRAIN if name in strains
    )
    physical = physical and abs(strains.get("WO3", 0.0)) < 1.0e-9
    summary = {
        "project": str(output),
        "Rwp": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "aborted": rvals.get("Aborted", False),
        "physical": physical,
        "instrument": values,
        "scales": scales,
        "strains": strains,
        "fractions": hist.ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "sources": {name: str(path) for name, path in specs},
        "Rvals": rvals,
    }
    output.with_suffix(".json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
