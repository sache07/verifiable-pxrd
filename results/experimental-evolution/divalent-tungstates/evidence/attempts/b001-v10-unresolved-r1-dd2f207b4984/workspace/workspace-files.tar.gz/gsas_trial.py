#!/usr/bin/env python3
"""Build and refine a neutral-profile GSAS-II trial for phase comparison.

This script intentionally keeps all phase-specific profile and texture terms
neutral. It is used to compare candidate structures under one common nuisance
model before any phase broadening is considered.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np

from GSASII import GSASIIfiles as G2fil
from GSASII import GSASIIscriptable as G2sc


def instrument_parameters() -> list[dict]:
    names = [
        "Type",
        "Lam1",
        "Lam2",
        "Zero",
        "I(L2)/I(L1)",
        "Polariz.",
        "U",
        "V",
        "W",
        "X",
        "Y",
        "Z",
        "SH/L",
        "Azimuth",
    ]
    values = [
        "PXC",
        1.540598,
        1.544426,
        0.42,
        0.5,
        0.5,
        5.0,
        0.0,
        35.0,
        8.0,
        0.0,
        0.0,
        0.002,
        0.0,
    ]
    return [G2fil.makeInstDict(names, values, [False] * len(names)), {}]


def set_neutral_hap(phase: G2sc.G2Phase, hist_name: str) -> None:
    """Make inactive phase terms physically neutral, including their values."""
    hap = phase.data["Histograms"][hist_name]

    size = hap["Size"]
    size[0] = "isotropic"
    size[1][0] = 10.0
    size[1][1] = 10.0
    size[1][2] = 1.0
    size[2] = [False for _ in size[2]]
    size[4] = [10.0 for _ in size[4]]
    size[5] = [False for _ in size[5]]

    strain = hap["Mustrain"]
    strain[0] = "isotropic"
    strain[1][0] = 0.0
    strain[1][1] = 0.0
    strain[1][2] = 1.0
    strain[2] = [False for _ in strain[2]]
    strain[4] = [0.0 for _ in strain[4]]
    strain[5] = [False for _ in strain[5]]

    pref = hap["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = False
    pref[3] = [0, 0, 1]
    if len(pref) > 4:
        pref[4] = 0
    if len(pref) > 5 and isinstance(pref[5], list):
        pref[5] = []

    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Extinction"][0] = 0.0
    hap["Extinction"][1] = False
    for key in ("BabA", "BabU"):
        hap["Babinet"][key][0] = 0.0
        hap["Babinet"][key][1] = False


def set_neutral_sample(hist: G2sc.G2PwdrData) -> None:
    sample = hist.data["Sample Parameters"]
    sample["Type"] = "Bragg-Brentano"
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample.setdefault(key, [0.0, False])
    if "Scale" in sample:
        sample["Scale"][0] = 1.0
        sample["Scale"][1] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in sample:
            sample[key][0] = 0.0
            sample[key][1] = False


def run_refinement(project: G2sc.G2Project, label: str) -> None:
    try:
        project.refine(printFile=f"{Path(project.filename).with_suffix('')}_{label}.lst")
    except Exception as exc:
        raise RuntimeError(f"refinement stage {label!r} failed") from exc


def finite_nonnegative(inst: dict, keys: tuple[str, ...]) -> bool:
    return all(math.isfinite(float(inst[k][1])) and float(inst[k][1]) >= 0 for k in keys)


def extract_summary(
    project: G2sc.G2Project, labels: list[str], profile_trials: list[dict]
) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    cov = project.data.get("Covariance", {}).get("data", {})
    data = hist.data["data"][1]
    phases = []
    fractions = {}
    try:
        fractions = hist.ComputeMassFracs()
    except Exception as exc:
        fractions = {"error": str(exc)}
    for phase, label in zip(project.phases(), labels):
        hap = phase.data["Histograms"][hist.name]
        row = {
            "label": label,
            "name": phase.name,
            "cell": phase.get_cell(),
            "composition": phase.composition,
            "density": phase.density,
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
        if label in fractions:
            row["mass_fraction"] = fractions[label]
        phases.append(row)
    return {
        "project": str(Path(project.filename).resolve()),
        "histogram": hist.name,
        "wR_percent": hist.get_wR(),
        "Rvals": hist.data["data"][0].get("Rvals", hist.data["data"][0]),
        "instrument": {key: inst[key] for key in inst},
        "profile_trials": profile_trials,
        "background": hist.data["Background"],
        "phases": phases,
        "mass_fractions": fractions,
        "covariance": {
            "Rvals": cov.get("Rvals"),
            "varyList": cov.get("varyList"),
            "sig": np.asarray(cov.get("sig", [])).tolist(),
        },
        "profile_points": len(data[0]),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument(
        "--phase",
        action="append",
        required=True,
        metavar="NAME=CIF",
        help="repeat for each candidate phase",
    )
    parser.add_argument("--background-terms", type=int, default=10)
    parser.add_argument("--cycles", type=int, default=3)
    args = parser.parse_args()

    phase_specs: list[tuple[str, Path]] = []
    for spec in args.phase:
        name, sep, value = spec.partition("=")
        if not sep:
            parser.error(f"invalid --phase {spec!r}; expected NAME=CIF")
        path = Path(value).resolve()
        if not path.is_file():
            parser.error(f"candidate CIF does not exist: {path}")
        phase_specs.append((name, path))

    output = args.output.resolve()
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(Path("inputs/pattern.csv").resolve()),
        instrument_parameters(),
        fmthint="comma",
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": args.background_terms,
                "coeffs": [1000.0] + [0.0] * (args.background_terms - 1),
            }
        }
    )
    set_neutral_sample(hist)

    phases = []
    labels = []
    for label, cif in phase_specs:
        phase = project.add_phase(
            str(cif),
            phasename=label,
            histograms=[hist],
            fmthint="CIF",
        )
        set_neutral_hap(phase, hist.name)
        phase.data["Histograms"][hist.name]["Scale"][0] = 1.0
        phase.set_HAP_refinements({"Scale": True})
        phases.append(phase)
        labels.append(label)

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = args.cycles
    controls["min dM/M"] = 1.0e-5
    controls["shift factor"] = 1.0
    project.save()

    # Source-comparison baseline: scales/background, one angular correction,
    # cells, and the common low-dimensional profile. Phase terms stay neutral.
    run_refinement(project, "scale_background")
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(project, "zero")
    for phase in phases:
        phase.set_refinements({"Cell": True})
    run_refinement(project, "cells")

    inst = hist.data["Instrument Parameters"][0]
    profile_trials = []
    for key in ("W", "X", "U"):
        prior = {name: list(inst[name]) for name in ("U", "W", "X")}
        hist.set_refinements({"Instrument Parameters": [key]})
        run_refinement(project, f"profile_{key.lower()}")
        accepted = finite_nonnegative(inst, ("U", "W", "X"))
        profile_trials.append(
            {
                "term": key,
                "trial_value": float(inst[key][1]),
                "all_values": {
                    name: float(inst[name][1]) for name in ("U", "W", "X")
                },
                "accepted": accepted,
                "wR_percent": hist.get_wR(),
            }
        )
        if not accepted:
            # A collapsed branch is invalid. Reload the pre-trial values (not
            # just the flags) and reconverge the simpler physical baseline.
            hist.clear_refinements({"Instrument Parameters": [key]})
            for name, value in prior.items():
                inst[name][:] = value
            run_refinement(project, f"profile_{key.lower()}_restored")

    # Replay all active baseline terms once to test reproducibility.
    run_refinement(project, "replay")
    project.save()
    summary = extract_summary(project, labels, profile_trials)
    summary_path = output.with_suffix(".json")
    summary_path.write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps(summary, indent=2, default=str))


if __name__ == "__main__":
    main()
