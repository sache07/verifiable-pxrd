#!/usr/bin/env python3
"""Challenge phase size/strain terms from a saved neutral GSAS-II baseline."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def refine(project: G2sc.G2Project) -> None:
    project.refine()


def hap_state(project: G2sc.G2Project, phase_name: str) -> dict:
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][hist.name]
    return {
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "scale": hap["Scale"],
    }


def test_term(
    baseline: Path,
    output: Path,
    phase_name: str,
    term: str,
    cycles: int,
) -> dict:
    project = G2sc.G2Project(gpxfile=str(baseline))
    project.save(str(output))
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = cycles
    controls["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][hist.name]

    if term == "size":
        size = hap["Size"]
        size[0] = "isotropic"
        size[1][0] = 10.0
        size[2] = [False for _ in size[2]]
        size[2][0] = True
    elif term == "strain":
        strain = hap["Mustrain"]
        strain[0] = "isotropic"
        strain[1][0] = 0.0
        strain[2] = [False for _ in strain[2]]
        strain[2][0] = True
    else:
        raise ValueError(term)

    before = hist.get_wR()
    refine(project)
    first = project.histogram(0).get_wR()
    state_first = hap_state(project, phase_name)
    refine(project)
    replay = project.histogram(0).get_wR()
    state_replay = hap_state(project, phase_name)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})

    if term == "size":
        value = float(state_replay["size"][1][0])
        physical = math.isfinite(value) and 0.0 < value < 10.0
    else:
        value = float(state_replay["mustrain"][1][0])
        physical = math.isfinite(value) and value > 0.0
    stable = (
        first is not None
        and replay is not None
        and abs(float(first) - float(replay)) < 0.02
        and not rvals.get("Aborted", False)
    )
    project.save()
    return {
        "phase": phase_name,
        "term": term,
        "project": str(output.resolve()),
        "Rwp_before": before,
        "Rwp_first": first,
        "Rwp_replay": replay,
        "value": value,
        "physical": physical,
        "stable": stable,
        "accepted_by_value_and_replay": bool(physical and stable),
        "state": state_replay,
        "Rvals": rvals,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--cycles", type=int, default=6)
    args = parser.parse_args()
    baseline = args.baseline.resolve()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    probe = G2sc.G2Project(gpxfile=str(baseline))
    phase_names = [phase.name for phase in probe.phases()]
    rows = []
    for phase_name in phase_names:
        for term in ("size", "strain"):
            safe_name = phase_name.replace(" ", "_")
            output = (args.output_dir / f"{safe_name}_{term}.gpx").resolve()
            row = test_term(baseline, output, phase_name, term, args.cycles)
            rows.append(row)
            print(json.dumps(row, indent=2, default=str))

    summary = args.output_dir / "summary.json"
    summary.write_text(json.dumps(rows, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
