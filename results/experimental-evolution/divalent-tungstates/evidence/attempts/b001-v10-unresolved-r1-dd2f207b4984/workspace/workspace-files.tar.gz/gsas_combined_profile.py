#!/usr/bin/env python3
"""Combine independently supported phase strain terms and re-audit profile."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SUPPORTED_STRAIN = {
    "PbWO4": 2495.255,
    "Pb3O4": 11880.01,
    "PbO": 6930.112,
}


def physical(project: G2sc.G2Project) -> tuple[bool, dict]:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    values = {key: float(inst[key][1]) for key in ("U", "W", "X")}
    for name, phase in ((p.name, p) for p in project.phases()):
        hap = phase.data["Histograms"][hist.name]
        values[f"strain_{name}"] = float(hap["Mustrain"][1][0])
    ok = all(math.isfinite(v) for v in values.values())
    ok = ok and all(values[key] >= 0.0 for key in ("U", "W", "X"))
    ok = ok and all(values[f"strain_{name}"] > 0.0 for name in SUPPORTED_STRAIN)
    ok = ok and abs(values.get("strain_WO3", 0.0)) < 1.0e-9
    return ok, values


def covariance_summary(project: G2sc.G2Project) -> dict:
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "varyList": cov.get("varyList", []),
        "sig": list(cov.get("sig", [])),
        "Rvals": cov.get("Rvals", {}),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()
    output = args.output.resolve()
    project = G2sc.G2Project(gpxfile=str(args.baseline.resolve()))
    project.save(str(output))
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = args.cycles
    controls["min dM/M"] = 1.0e-5
    hist = project.histogram(0)

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        strain = hap["Mustrain"]
        strain[0] = "isotropic"
        strain[1][0] = 0.0
        strain[2] = [False for _ in strain[2]]
        if phase.name in SUPPORTED_STRAIN:
            strain[1][0] = SUPPORTED_STRAIN[phase.name]
            strain[2][0] = True

    project.refine()
    combined_first = project.histogram(0).get_wR()
    project.refine()
    combined_replay = project.histogram(0).get_wR()
    combined_ok, combined_values = physical(project)
    combined_state = output.with_name(output.stem + "_strains.gpx")
    project.save(str(combined_state))

    trials = []
    for key in ("X", "U"):
        pretrial = output.with_name(output.stem + f"_pre_{key.lower()}.gpx")
        project.save(str(pretrial))
        # Keep the snapshot immutable during the trial. GSAS-II saves before
        # every refinement, so change the working filename back to output.
        project.save(str(output))
        hist = project.histogram(0)
        hist.set_refinements({"Instrument Parameters": [key]})
        project.refine()
        first = project.histogram(0).get_wR()
        project.refine()
        replay = project.histogram(0).get_wR()
        ok, values = physical(project)
        rvals = covariance_summary(project)["Rvals"]
        stable = (
            first is not None
            and replay is not None
            and abs(float(first) - float(replay)) < 0.02
            and not rvals.get("Aborted", False)
        )
        accepted = bool(ok and stable)
        trials.append(
            {
                "term": key,
                "Rwp_first": first,
                "Rwp_replay": replay,
                "values": values,
                "physical": ok,
                "stable": stable,
                "accepted": accepted,
                "Rvals": rvals,
            }
        )
        if not accepted:
            project = G2sc.G2Project(gpxfile=str(pretrial))
            project.save(str(output))
            project.refine()
        else:
            project.save(str(output))

    # Fresh replay of every retained term over the full range.
    project.refine()
    project.save(str(output))
    ok, values = physical(project)
    summary = {
        "project": str(output),
        "combined_Rwp_first": combined_first,
        "combined_Rwp_replay": combined_replay,
        "combined_physical": combined_ok,
        "combined_values": combined_values,
        "profile_trials": trials,
        "final_Rwp": project.histogram(0).get_wR(),
        "final_physical": ok,
        "final_values": values,
        "mass_fractions": project.histogram(0).ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "covariance": covariance_summary(project),
    }
    output.with_suffix(".json").write_text(
        json.dumps(summary, indent=2, default=str) + "\n"
    )
    print(json.dumps(summary, indent=2, default=str))


if __name__ == "__main__":
    main()
