from __future__ import annotations

import json
from pathlib import Path

from refine_utils import ROOT, make_project, phase_summary, refine_repeated


CIF_ROOT = Path(
    "<RUN>/resources/"
    "b001-c04/cif"
)


def cod(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = {
    "wolframite_ferberite_parent": ROOT / "_work/candidates/mnwo4_ferberite_parent.cif",
    "wolframite_zn_parent": ROOT / "_work/candidates/mnwo4_zn_parent.cif",
    "scheelite_parent": ROOT / "_work/candidates/mnwo4_scheelite_parent.cif",
    "fergusonite_parent": ROOT / "_work/candidates/mnwo4_fergusonite_parent.cif",
    "mnmoo4_parent": ROOT / "_work/candidates/mnwo4_mnmoo4_parent.cif",
    "mn3wo6": cod("2002703"),
}


def main():
    outdir = ROOT / "_work/provisional/candidate_screens"
    outdir.mkdir(parents=True, exist_ok=True)
    results = []
    for label, cif in CANDIDATES.items():
        gpx = outdir / f"{label}.gpx"
        status = "completed"
        error = None
        project, hist, phases = make_project(
            gpx, [(label, cif)], shift=580.0, background_terms=8,
            profile=(0.0, 10.0, 2.0)
        )
        try:
            # Same modest nuisance schedule for every structural candidate.
            refine_repeated(project, 1)  # background + scale
            scale = phases[0].data["Histograms"][hist.name]["Scale"][0]
            if scale <= 1.0e-8 or any("Scale" in item for item in project.get_Frozen()):
                status = "scale_rejected"
            else:
                hist.SampleParameters["Shift"][1] = True
                phases[0].set_refinements({"Cell": True})
                refine_repeated(project, 3)
        except Exception as exc:
            status = "refinement_failed"
            error = f"{type(exc).__name__}: {exc}"
        project.save()
        results.append(
            {
                "candidate": label,
                "cif": str(cif),
                "status": status,
                "error": error,
                "wR_percent": float(hist.residuals["wR"]),
                "R_percent": float(hist.residuals["R"]),
                "shift_micrometres": float(hist.SampleParameters["Shift"][0]),
                "frozen": project.get_Frozen(),
                "phase": phase_summary(project, phases[0], hist),
            }
        )
    (outdir / "summary.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
