from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc

from final_profile_screen import refine_to_stability
from refine_utils import ROOT


RDIR = ROOT / "_work" / "restart"
SOURCE = RDIR / "final_candidate_bg7.gpx"


def branch(label, w_uiso, o_uiso):
    project = G2sc.G2Project(
        str(SOURCE), newgpx=str(RDIR / f"adp_{label}.gpx")
    )
    project.set_Frozen()
    for atom in project.phase(1).atoms():
        atom.uiso = w_uiso if atom.element == "W" else o_uiso
        atom.refinement_flags = ""
    project.save()
    refine_to_stability(project, maximum=5)
    hist = project.histogram(0)
    return {
        "label": label,
        "W_Uiso_A2": w_uiso,
        "O_Uiso_A2": o_uiso,
        "Rwp_percent": float(hist.residuals["wR"]),
        "polarization": float(hist.InstrumentParameters["Polariz."][1]),
        "mass_fractions": {
            name: [float(value), float(esd)]
            for name, (value, esd) in hist.ComputeMassFracs().items()
        },
        "frozen": list(project.get_Frozen()),
    }


def main():
    results = [
        branch("zero_reported", 0.0, 0.0),
        branch("low", 0.0030, 0.0050),
        branch("selected", 0.0046, 0.0074),
        branch("high", 0.0060, 0.0100),
    ]
    (RDIR / "adp_sensitivity.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
