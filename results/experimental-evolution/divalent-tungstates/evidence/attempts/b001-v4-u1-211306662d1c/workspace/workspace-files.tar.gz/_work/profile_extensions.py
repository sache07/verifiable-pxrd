from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from final_profile_screen import (
    OUTDIR,
    ROOT,
    covariance_summary,
    project_summary,
    refine_to_stability,
)


COMMON = OUTDIR / "profile_W_X.gpx"


def reset_phase_broadening(project):
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def extension_summary(project, label, history):
    result = project_summary(project, label, history)
    hist = project.histogram(0)
    result["hap_profiles"] = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["hap_profiles"][phase.name] = {
            "size_type": hap["Size"][0],
            "size_micrometres": float(hap["Size"][1][0]),
            "size_refine": bool(hap["Size"][2][0]),
            "mustrain_microstrain": float(hap["Mustrain"][1][0]),
            "mustrain_refine": bool(hap["Mustrain"][2][0]),
        }
    return result


def make_asymmetry_branch():
    project = G2sc.G2Project(
        str(COMMON), newgpx=str(OUTDIR / "profile_W_X_SHL.gpx")
    )
    project.set_Frozen()
    inst = project.histogram(0).InstrumentParameters
    inst["SH/L"][1] = 0.02
    inst["SH/L"][2] = True
    project.set_Controls("parmMin", 0.0005, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.20, variable=":0:SH/L")
    project.save()
    history = refine_to_stability(project, maximum=6)
    return project, extension_summary(project, "profile_W_X_SHL", history)


def valid_asymmetry(summary, baseline_wr):
    value = summary["profile"]["SH/L"]["value"]
    return (
        not summary["frozen"]
        and 0.0006 < value < 0.195
        and baseline_wr - summary["wR_percent"] > 0.02
    )


def make_broadening_branch(base, phase_index, kind):
    label = f"{Path(base).stem}_phase{phase_index}_{kind}"
    project = G2sc.G2Project(
        str(base), newgpx=str(OUTDIR / f"{label}.gpx")
    )
    project.set_Frozen()
    reset_phase_broadening(project)
    phase = project.phase(phase_index)
    hist = project.histogram(0)
    hap = phase.data["Histograms"][hist.name]
    if kind == "size":
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
        variable = f"{phase_index}:0:Size;i"
        project.set_Controls("parmMin", 0.005, variable=variable)
        project.set_Controls("parmMax", 10.0, variable=variable)
    elif kind == "strain":
        hap["Mustrain"][1][0] = 100.0
        hap["Mustrain"][2][0] = True
        variable = f"{phase_index}:0:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 10000.0, variable=variable)
    else:
        raise ValueError(kind)
    project.save()
    history = refine_to_stability(project, maximum=7)
    return extension_summary(project, label, history)


def main():
    baseline = G2sc.G2Project(str(COMMON))
    baseline_wr = float(baseline.histogram(0).residuals["wR"])
    asymmetry, asymmetry_result = make_asymmetry_branch()
    if valid_asymmetry(asymmetry_result, baseline_wr):
        broadening_base = OUTDIR / "profile_W_X_SHL.gpx"
        selected_asymmetry = True
    else:
        broadening_base = COMMON
        selected_asymmetry = False

    results = [asymmetry_result]
    for phase_index in range(2):
        for kind in ("size", "strain"):
            results.append(
                make_broadening_branch(broadening_base, phase_index, kind)
            )

    output = {
        "common_profile": str(COMMON.relative_to(ROOT)),
        "common_wR_percent": baseline_wr,
        "asymmetry_selected_for_subsequent_tests": selected_asymmetry,
        "broadening_base": str(broadening_base.relative_to(ROOT)),
        "results": results,
    }
    (OUTDIR / "profile_extensions_summary.json").write_text(
        json.dumps(output, indent=2) + "\n"
    )
    concise = {
        "common_wR_percent": baseline_wr,
        "asymmetry_selected": selected_asymmetry,
        "results": [
            {
                "label": item["label"],
                "wR_percent": item["wR_percent"],
                "SH/L": item["profile"]["SH/L"],
                "hap_profiles": item["hap_profiles"],
                "frozen": item["frozen"],
                "max_shift_over_sigma": item["covariance"]["max_shift_over_sigma"],
                "correlations": item["covariance"]["correlations_abs_ge_0.90"],
            }
            for item in results
        ],
    }
    print(json.dumps(concise, indent=2))


if __name__ == "__main__":
    main()
