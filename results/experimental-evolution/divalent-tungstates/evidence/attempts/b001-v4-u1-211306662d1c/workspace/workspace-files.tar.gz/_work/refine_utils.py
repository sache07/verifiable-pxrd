from __future__ import annotations

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
PATTERN = ROOT / "inputs" / "pattern.csv"
INSTRUMENT = ROOT / "_work" / "instrument.instprm"


def neutralize_hap(phase, hist, scale: float = 1.0, refine_scale: bool = True):
    """Remove default phase-profile and intensity effects from one HAP entry."""
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [float(scale), bool(refine_scale)]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0e6
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    return hap


def make_project(gpx: Path, phases: list[tuple[str, Path]], shift: float = 580.0,
                 background_terms: int = 10,
                 profile: tuple[float, float, float] = (0.0, 10.0, 2.0)):
    """Create a neutral provisional Bragg-Brentano project."""
    project = G2sc.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(
        str(PATTERN), str(INSTRUMENT), fmthint="comma"
    )
    phase_objects = []
    for name, cif in phases:
        phase_objects.append(
            project.add_phase(
                str(cif), phasename=name, histograms=[hist], fmthint="CIF"
            )
        )

    # Keep one angular correction only and turn off unused intensity effects.
    sample = hist.SampleParameters
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [float(shift), False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    inst = hist.InstrumentParameters
    for key in inst:
        if isinstance(inst[key], list) and len(inst[key]) > 2:
            inst[key][2] = False
    inst["Zero"][1] = 0.0
    inst["U"][1], inst["W"][1], inst["X"][1] = profile
    inst["V"][1] = inst["Y"][1] = inst["Z"][1] = 0.0
    inst["SH/L"][1] = 0.002

    hist.Background[0] = (
        ["chebyschev-1", True, background_terms, 1000.0]
        + [0.0] * (background_terms - 1)
    )

    for phase in phase_objects:
        neutralize_hap(phase, hist)

    project.save()
    project.set_Controls("cycles", 12)
    for index, _phase in enumerate(phase_objects):
        project.set_Controls("parmMin", 0.0, variable=f"{index}:0:Scale")
    project.set_Controls("parmMin", -2000.0, variable=":0:Shift")
    project.set_Controls("parmMax", 2000.0, variable=":0:Shift")
    project.save()
    return project, hist, phase_objects


def refine_repeated(project, repeats: int = 2):
    """Run repeated native refinements and return the last histogram wR."""
    result = None
    for _ in range(repeats):
        project.do_refinements([{}])
        result = project.histogram(0).residuals.get("wR")
    return result


def phase_summary(project, phase, hist):
    hap = phase.data["Histograms"][hist.name]
    return {
        "name": phase.name,
        "scale": float(hap["Scale"][0]),
        "cell": {key: float(value) for key, value in phase.get_cell().items()},
        "composition": {key: float(value) for key, value in phase.composition.items()},
        "density": float(phase.density),
    }
