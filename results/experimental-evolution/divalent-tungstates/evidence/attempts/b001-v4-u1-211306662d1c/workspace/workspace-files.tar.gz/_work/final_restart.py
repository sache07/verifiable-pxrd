from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat

from final_profile_screen import (
    CIF_ROOT,
    MNWO4,
    covariance_summary,
    project_summary,
    refine_to_stability,
    set_common_profile,
)
from refine_utils import ROOT, make_project


RDIR = ROOT / "_work" / "restart"
WO3 = CIF_ROOT / "2" / "31" / "10" / "2311041.cif"


def add_room_temperature_adps(project):
    wo3 = project.phase(1)
    for atom in wo3.atoms():
        atom.uiso = 0.0046 if atom.element == "W" else 0.0074
        atom.refinement_flags = ""


def set_inventory_cells(phases):
    cells = [
        [4.7991, 5.7071, 4.9759, 90.0, 91.1262, 90.0],
        [7.6898, 7.5520, 10.5167, 90.0, 136.0325, 90.0],
    ]
    for phase, cell in zip(phases, cells):
        phase.data["General"]["Cell"][1:7] = cell
        phase.data["General"]["Cell"][7] = float(
            G2lat.calc_V(G2lat.cell2A(cell))
        )


def build_clean_base():
    project, hist, phases = make_project(
        RDIR / "clean_base.gpx",
        [("MnWO4_wolframite", MNWO4), ("WO3_monoclinic", WO3)],
        shift=959.0,
        background_terms=8,
        profile=(0.0, 10.0, 2.0),
    )
    add_room_temperature_adps(project)
    set_inventory_cells(phases)
    project.set_Controls("cycles", 16)
    project.set_Controls("parmMin", 0.0, variable=":0:Shift")
    project.set_Controls("parmMax", 1500.0, variable=":0:Shift")
    hist.Background[0][1] = True
    for phase in phases:
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        phase.set_refinements({"Cell": False})
    hist.SampleParameters["Shift"][1] = False
    project.save()
    first = refine_to_stability(project, maximum=4)
    hist.SampleParameters["Shift"][1] = True
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.save()
    second = refine_to_stability(project, maximum=6)
    return project_summary(project, "clean_base", first + second)


def clone(source, label):
    return G2sc.G2Project(
        str(source), newgpx=str(RDIR / f"{label}.gpx")
    )


def profile_branch(label, values, refine):
    project = clone(RDIR / "clean_base.gpx", label)
    set_common_profile(project, values, set(refine))
    history = refine_to_stability(project, maximum=7)
    return project_summary(project, label, history)


def shl_branch():
    project = clone(RDIR / "common_W_X.gpx", "common_W_X_SHL")
    project.set_Frozen()
    shl = project.histogram(0).InstrumentParameters["SH/L"]
    shl[1], shl[2] = 0.02, True
    project.set_Controls("parmMin", 0.0005, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.20, variable=":0:SH/L")
    project.save()
    history = refine_to_stability(project, maximum=6)
    return project_summary(project, "common_W_X_SHL", history)


def reset_phase_profiles(project):
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def phase_profile_branch(phase_index, kind):
    label = f"phase{phase_index}_{kind}"
    project = clone(RDIR / "common_W_X.gpx", label)
    project.set_Frozen()
    reset_phase_profiles(project)
    hist = project.histogram(0)
    hap = project.phase(phase_index).data["Histograms"][hist.name]
    if kind == "size":
        hap["Size"][1][0], hap["Size"][2][0] = 1.0, True
        variable = f"{phase_index}:0:Size;i"
        project.set_Controls("parmMin", 0.005, variable=variable)
        project.set_Controls("parmMax", 10.0, variable=variable)
    else:
        hap["Mustrain"][1][0], hap["Mustrain"][2][0] = 100.0, True
        variable = f"{phase_index}:0:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 10000.0, variable=variable)
    project.save()
    history = refine_to_stability(project, maximum=7)
    result = project_summary(project, label, history)
    result["phase_profile"] = {
        phase.name: {
            "size_micrometres": float(
                phase.data["Histograms"][hist.name]["Size"][1][0]
            ),
            "size_refine": bool(
                phase.data["Histograms"][hist.name]["Size"][2][0]
            ),
            "mustrain_microstrain": float(
                phase.data["Histograms"][hist.name]["Mustrain"][1][0]
            ),
            "mustrain_refine": bool(
                phase.data["Histograms"][hist.name]["Mustrain"][2][0]
            ),
        }
        for phase in project.phases()
    }
    return result


def polarization_branch():
    project = clone(RDIR / "phase1_size.gpx", "polarization")
    project.set_Frozen()
    polar = project.histogram(0).InstrumentParameters["Polariz."]
    polar[1], polar[2] = 0.5, True
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.save()
    history = refine_to_stability(project, maximum=6)
    result = project_summary(project, "polarization", history)
    result["polarization"] = float(
        project.histogram(0).InstrumentParameters["Polariz."][1]
    )
    return result


def reset_texture(project):
    hist = project.histogram(0)
    for phase in project.phases():
        preferred = phase.data["Histograms"][hist.name]["Pref.Ori."]
        preferred[0] = "MD"
        preferred[1] = 1.0
        preferred[2] = False
        preferred[3] = [0, 0, 1]


def texture_branch(phase_index, axis):
    axis_text = "".join(str(item) for item in axis)
    label = f"texture_phase{phase_index}_{axis_text}"
    project = clone(RDIR / "polarization.gpx", label)
    project.set_Frozen()
    reset_texture(project)
    hist = project.histogram(0)
    preferred = project.phase(phase_index).data["Histograms"][hist.name]["Pref.Ori."]
    preferred[1], preferred[2], preferred[3] = 1.05, True, list(axis)
    project.set_Controls("parmMin", 0.20, variable=f"{phase_index}:0:MD")
    project.set_Controls("parmMax", 5.0, variable=f"{phase_index}:0:MD")
    project.save()
    history = refine_to_stability(project, maximum=6)
    result = project_summary(project, label, history)
    result["texture"] = {
        "phase": project.phase(phase_index).name,
        "axis": list(axis),
        "coefficient": float(preferred[1]),
    }
    return result


def make_final_candidate():
    project = clone(RDIR / "texture_phase0_001.gpx", "final_candidate")
    project.set_Frozen()
    project.save()
    project = G2sc.G2Project(str(RDIR / "final_candidate.gpx"))
    history = refine_to_stability(project, maximum=6)
    result = project_summary(project, "final_candidate_replay", history)
    hist = project.histogram(0)
    result["polarization"] = float(hist.InstrumentParameters["Polariz."][1])
    result["texture"] = {
        phase.name: {
            "coefficient": float(
                phase.data["Histograms"][hist.name]["Pref.Ori."][1]
            ),
            "refine": bool(
                phase.data["Histograms"][hist.name]["Pref.Ori."][2]
            ),
            "axis": phase.data["Histograms"][hist.name]["Pref.Ori."][3],
        }
        for phase in project.phases()
    }
    result["wo3_adps"] = {
        atom.label: float(atom.uiso) for atom in project.phase(1).atoms()
    }
    return result


def concise(result):
    data = {
        "label": result["label"],
        "wR_percent": result["wR_percent"],
        "frozen": result["frozen"],
        "profile": result["profile"],
        "correlations": result["covariance"]["correlations_abs_ge_0.90"],
    }
    for key in ("phase_profile", "polarization", "texture", "mass_fractions", "wo3_adps"):
        if key in result:
            data[key] = result[key]
    return data


def main():
    RDIR.mkdir(parents=True, exist_ok=True)
    results = [build_clean_base()]
    profile_specs = [
        ("common_W", {"W": 10.0}, {"W"}),
        ("common_X", {"W": 0.05, "X": 2.0}, {"X"}),
        ("common_W_X", {"W": 10.0, "X": 2.0}, {"W", "X"}),
        (
            "common_U_W_X",
            {"U": 1.0, "W": 10.0, "X": 2.0},
            {"U", "W", "X"},
        ),
    ]
    for label, values, refine in profile_specs:
        results.append(profile_branch(label, values, refine))
    results.append(shl_branch())
    for phase_index in range(2):
        for kind in ("size", "strain"):
            results.append(phase_profile_branch(phase_index, kind))
    results.append(polarization_branch())
    for phase_index in range(2):
        for axis in ([1, 0, 0], [0, 1, 0], [0, 0, 1]):
            results.append(texture_branch(phase_index, axis))
    results.append(make_final_candidate())

    (RDIR / "restart_summary.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )
    print(json.dumps([concise(result) for result in results], indent=2))


if __name__ == "__main__":
    main()
