from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from final_profile_screen import OUTDIR, ROOT, project_summary, refine_to_stability


SOURCE = OUTDIR / "profile_W_X_phase1_size.gpx"
ACCEPTED_PROFILE = OUTDIR / "accepted_profile.gpx"


def full_summary(project, label, history):
    result = project_summary(project, label, history)
    hist = project.histogram(0)
    result["texture"] = {}
    result["phase_profiles"] = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["texture"][phase.name] = {
            "model": hap["Pref.Ori."][0],
            "coefficient": float(hap["Pref.Ori."][1]),
            "refine": bool(hap["Pref.Ori."][2]),
            "axis": [int(value) for value in hap["Pref.Ori."][3]],
        }
        result["phase_profiles"][phase.name] = {
            "size_micrometres": float(hap["Size"][1][0]),
            "size_refine": bool(hap["Size"][2][0]),
            "mustrain_microstrain": float(hap["Mustrain"][1][0]),
            "mustrain_refine": bool(hap["Mustrain"][2][0]),
        }
    result["polarization"] = {
        "value": float(hist.InstrumentParameters["Polariz."][1]),
        "refine": bool(hist.InstrumentParameters["Polariz."][2]),
    }
    return result


def replay_accepted_profile():
    project = G2sc.G2Project(str(SOURCE), newgpx=str(ACCEPTED_PROFILE))
    project.set_Frozen()
    project.save()
    project = G2sc.G2Project(str(ACCEPTED_PROFILE))
    history = refine_to_stability(project, maximum=5)
    return project, full_summary(project, "accepted_profile_replay", history)


def polarization_branch():
    target = OUTDIR / "accepted_profile_polarization.gpx"
    project = G2sc.G2Project(str(ACCEPTED_PROFILE), newgpx=str(target))
    project.set_Frozen()
    polar = project.histogram(0).InstrumentParameters["Polariz."]
    polar[1] = 0.5
    polar[2] = True
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.save()
    history = refine_to_stability(project, maximum=6)
    return project, full_summary(project, "polarization", history)


def valid_polarization(result, baseline_wr):
    value = result["polarization"]["value"]
    correlations = result["covariance"]["correlations_abs_ge_0.90"]
    severe = any(
        "Polariz." in pair[0] or "Polariz." in pair[1]
        for pair in correlations
        if abs(pair[2]) >= 0.95
    )
    return (
        not result["frozen"]
        and 0.02 < value < 0.98
        and baseline_wr - result["wR_percent"] > 0.03
        and not severe
    )


def reset_texture(project):
    hist = project.histogram(0)
    for phase in project.phases():
        preferred = phase.data["Histograms"][hist.name]["Pref.Ori."]
        preferred[0] = "MD"
        preferred[1] = 1.0
        preferred[2] = False
        preferred[3] = [0, 0, 1]


def texture_branch(base, phase_index, axis):
    axis_text = "".join(str(value) for value in axis)
    label = f"texture_phase{phase_index}_{axis_text}"
    target = OUTDIR / f"{label}.gpx"
    project = G2sc.G2Project(str(base), newgpx=str(target))
    project.set_Frozen()
    reset_texture(project)
    hist = project.histogram(0)
    preferred = project.phase(phase_index).data["Histograms"][hist.name]["Pref.Ori."]
    preferred[1] = 1.05
    preferred[2] = True
    preferred[3] = list(axis)
    variable = f"{phase_index}:0:MD"
    project.set_Controls("parmMin", 0.20, variable=variable)
    project.set_Controls("parmMax", 5.0, variable=variable)
    project.save()
    history = refine_to_stability(project, maximum=6)
    return full_summary(project, label, history)


def main():
    replay, replay_result = replay_accepted_profile()
    baseline_wr = replay_result["wR_percent"]
    polarization, polarization_result = polarization_branch()
    if valid_polarization(polarization_result, baseline_wr):
        texture_base = OUTDIR / "accepted_profile_polarization.gpx"
        selected_polarization = True
    else:
        texture_base = ACCEPTED_PROFILE
        selected_polarization = False

    textures = []
    for phase_index in range(2):
        for axis in ([1, 0, 0], [0, 1, 0], [0, 0, 1]):
            textures.append(texture_branch(texture_base, phase_index, axis))

    output = {
        "accepted_profile_source": str(SOURCE.relative_to(ROOT)),
        "replay": replay_result,
        "polarization": polarization_result,
        "polarization_selected_for_texture_tests": selected_polarization,
        "texture_base": str(texture_base.relative_to(ROOT)),
        "texture_branches": textures,
    }
    (OUTDIR / "intensity_texture_summary.json").write_text(
        json.dumps(output, indent=2) + "\n"
    )
    print(json.dumps({
        "replay_wR_percent": baseline_wr,
        "polarization": {
            "selected": selected_polarization,
            "wR_percent": polarization_result["wR_percent"],
            "value": polarization_result["polarization"],
            "frozen": polarization_result["frozen"],
            "correlations": polarization_result["covariance"]["correlations_abs_ge_0.90"],
        },
        "textures": [
            {
                "label": result["label"],
                "wR_percent": result["wR_percent"],
                "texture": result["texture"],
                "frozen": result["frozen"],
                "correlations": result["covariance"]["correlations_abs_ge_0.90"],
            }
            for result in textures
        ],
    }, indent=2))


if __name__ == "__main__":
    main()
