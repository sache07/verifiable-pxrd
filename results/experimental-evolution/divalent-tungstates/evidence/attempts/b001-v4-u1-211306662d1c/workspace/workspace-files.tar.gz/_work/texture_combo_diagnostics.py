from __future__ import annotations

import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from final_profile_screen import OUTDIR, ROOT, project_summary, refine_to_stability


BASE = OUTDIR / "accepted_profile_polarization.gpx"
COMBINED = OUTDIR / "accepted_profile_polarization_texture.gpx"


def configure_combined_texture(project):
    hist = project.histogram(0)
    starting = (0.964, 1.083)
    for index, (phase, coefficient) in enumerate(zip(project.phases(), starting)):
        preferred = phase.data["Histograms"][hist.name]["Pref.Ori."]
        preferred[0] = "MD"
        preferred[1] = coefficient
        preferred[2] = True
        preferred[3] = [0, 0, 1]
        project.set_Controls("parmMin", 0.20, variable=f"{index}:0:MD")
        project.set_Controls("parmMax", 5.0, variable=f"{index}:0:MD")


def window_statistics(project, centers, half_width=0.18):
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("x"))
    observed = np.asarray(hist.getdata("yobs"))
    calculated = np.asarray(hist.getdata("ycalc"))
    weight = np.asarray(hist.getdata("yweight"))
    results = []
    for item in centers:
        mask = np.abs(x - item["two_theta_deg"]) <= half_width
        residual = observed[mask] - calculated[mask]
        results.append({
            **item,
            "weighted_sse": float(np.sum(weight[mask] * residual**2)),
            "absolute_residual": float(np.sum(np.abs(residual))),
            "integrated_signed_residual": float(np.sum(residual)),
            "points": int(np.sum(mask)),
        })
    return results


def diagnostic_centers(project, minimum_separation=0.28, per_phase=12):
    hist = project.histogram(0)
    all_rows = []
    by_phase = {}
    for phase in project.phases():
        rows = hist.reflections()[phase.name]["RefList"]
        score = rows[:, 3] * rows[:, 9] * rows[:, 11]
        phase_rows = []
        for row, intensity in zip(rows, score):
            record = {
                "phase": phase.name,
                "hkl": [int(value) for value in row[:3]],
                "two_theta_deg": float(row[5]),
                "intensity_score": float(intensity),
            }
            phase_rows.append(record)
            all_rows.append(record)
        by_phase[phase.name] = phase_rows

    selected = []
    for phase in project.phases():
        candidates = sorted(
            by_phase[phase.name], key=lambda item: item["intensity_score"], reverse=True
        )
        for item in candidates:
            nearest = min(
                abs(item["two_theta_deg"] - other["two_theta_deg"])
                for other in all_rows
                if other is not item
            )
            if nearest < minimum_separation:
                continue
            if any(
                abs(item["two_theta_deg"] - prior["two_theta_deg"]) < 0.6
                for prior in selected
                if prior["phase"] == phase.name
            ):
                continue
            selected.append({**item, "nearest_reflection_deg": float(nearest)})
            if sum(entry["phase"] == phase.name for entry in selected) >= per_phase:
                break
    return selected


def main():
    project = G2sc.G2Project(str(BASE), newgpx=str(COMBINED))
    project.set_Frozen()
    configure_combined_texture(project)
    project.save()
    history = refine_to_stability(project, maximum=6)
    project.save()

    # Required fresh replay after accepting a profile/intensity candidate.
    project = G2sc.G2Project(str(COMBINED))
    replay_history = refine_to_stability(project, maximum=5)
    combined_summary = project_summary(
        project, "combined_texture_001_replay", history + replay_history
    )
    hist = project.histogram(0)
    combined_summary["texture"] = {
        phase.name: {
            "coefficient": float(
                phase.data["Histograms"][hist.name]["Pref.Ori."][1]
            ),
            "refine": bool(
                phase.data["Histograms"][hist.name]["Pref.Ori."][2]
            ),
            "axis": phase.data["Histograms"][hist.name]["Pref.Ori."][3],
        }
        for phase in project.phases()
    }

    baseline = G2sc.G2Project(str(BASE))
    centers = diagnostic_centers(baseline)
    before = window_statistics(baseline, centers)
    after = window_statistics(project, centers)
    diagnostics = []
    for old, new in zip(before, after):
        diagnostics.append({
            **{key: old[key] for key in (
                "phase", "hkl", "two_theta_deg", "intensity_score",
                "nearest_reflection_deg", "points"
            )},
            "weighted_sse_no_texture": old["weighted_sse"],
            "weighted_sse_combined_texture": new["weighted_sse"],
            "weighted_sse_change": new["weighted_sse"] - old["weighted_sse"],
            "absolute_residual_no_texture": old["absolute_residual"],
            "absolute_residual_combined_texture": new["absolute_residual"],
            "signed_residual_no_texture": old["integrated_signed_residual"],
            "signed_residual_combined_texture": new["integrated_signed_residual"],
        })

    output = {
        "baseline_gpx": str(BASE.relative_to(ROOT)),
        "baseline_wR_percent": float(baseline.histogram(0).residuals["wR"]),
        "combined": combined_summary,
        "isolated_reflection_windows": diagnostics,
    }
    (OUTDIR / "texture_combo_diagnostics.json").write_text(
        json.dumps(output, indent=2) + "\n"
    )
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
