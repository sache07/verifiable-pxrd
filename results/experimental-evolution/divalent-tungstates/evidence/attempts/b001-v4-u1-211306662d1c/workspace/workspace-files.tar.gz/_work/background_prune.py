from __future__ import annotations

import json
import math

from GSASII import GSASIIscriptable as G2sc

from final_profile_screen import project_summary, refine_to_stability
from refine_utils import ROOT


RDIR = ROOT / "_work" / "restart"
SOURCE = RDIR / "final_candidate.gpx"


def branch(terms):
    label = f"final_candidate_bg{terms}"
    project = G2sc.G2Project(
        str(SOURCE), newgpx=str(RDIR / f"{label}.gpx")
    )
    project.set_Frozen()
    background = project.histogram(0).Background[0]
    background[2] = terms
    del background[3 + terms:]
    project.save()
    history = refine_to_stability(project, maximum=6)
    result = project_summary(project, label, history)
    rvals = project["Covariance"]["data"]["Rvals"]
    chisq = float(rvals["chisq"])
    nobs = int(rvals["Nobs"])
    nvars = int(rvals["Nvars"])
    result["chisq"] = chisq
    result["aic"] = chisq + 2 * nvars
    result["bic"] = chisq + nvars * math.log(nobs)
    result["background"] = [float(value) for value in background[3:]]
    return result


def main():
    source = G2sc.G2Project(str(SOURCE))
    rvals = source["Covariance"]["data"]["Rvals"]
    base = project_summary(source, "final_candidate_bg8", [])
    base["chisq"] = float(rvals["chisq"])
    base["aic"] = base["chisq"] + 2 * int(rvals["Nvars"])
    base["bic"] = base["chisq"] + int(rvals["Nvars"]) * math.log(int(rvals["Nobs"]))
    base["background"] = [
        float(value) for value in source.histogram(0).Background[0][3:]
    ]
    results = [base, branch(7), branch(6)]
    (RDIR / "background_prune_summary.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )
    print(json.dumps([
        {
            key: result[key]
            for key in ("label", "wR_percent", "chisq", "aic", "bic", "background", "frozen")
        }
        for result in results
    ], indent=2))


if __name__ == "__main__":
    main()
