from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_utils import ROOT, neutralize_hap, phase_summary, refine_repeated


CIF_ROOT = Path(
    "<RUN>/resources/"
    "b001-c04/cif"
)
BASE = ROOT / "_work/provisional/candidate_screens/wolframite_zn_parent.gpx"


def cod(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = {
    "WO3_monoclinic_RT": cod("1528915"),
    "WO3_monoclinic_neutron": cod("2311041"),
    "WO3_monoclinic_HP_derived": cod("1563541"),
    "WO3_orthorhombic": cod("2107312"),
    "WO3_triclinic": cod("2106293"),
    "WO3_tetragonal": cod("1521532"),
    "Mn3O4_tetragonal": cod("9001963"),
    "Mn3O4_tetragonal_alt": cod("1011262"),
    "Mn3O4_orthorhombic_HP": cod("1514104"),
    "Mn2O3_bixbyite": cod("1514230"),
    "MnO_manganosite": cod("1514108"),
    "Mn3WO6": cod("2002703"),
}


def main():
    outdir = ROOT / "_work/provisional/secondary_screens"
    outdir.mkdir(parents=True, exist_ok=True)
    baseline = G2sc.G2Project(str(BASE))
    baseline_wr = float(baseline.histogram(0).residuals["wR"])
    results = []
    for label, cif in CANDIDATES.items():
        gpx = outdir / f"{label}.gpx"
        project = G2sc.G2Project(str(BASE), newgpx=str(gpx))
        project.set_Frozen()
        hist = project.histogram(0)
        candidate = project.add_phase(
            str(cif), phasename=label, histograms=[hist], fmthint="CIF"
        )
        neutralize_hap(candidate, hist, scale=0.1, refine_scale=True)
        candidate.set_refinements({"Cell": True})
        for index, phase in enumerate(project.phases()):
            phase.data["Histograms"][hist.name]["Scale"][1] = True
            phase.set_refinements({"Cell": True})
            project.set_Controls("parmMin", 0.0, variable=f"{index}:0:Scale")
        hist.Background[0][1] = True
        hist.SampleParameters["Shift"][1] = True
        project.set_Controls("cycles", 12)
        project.save()
        status = "completed"
        error = None
        try:
            refine_repeated(project, 3)
        except Exception as exc:
            status = "refinement_failed"
            error = f"{type(exc).__name__}: {exc}"
        project.save()
        candidate_scale = candidate.data["Histograms"][hist.name]["Scale"][0]
        frozen = project.get_Frozen()
        if candidate_scale <= 1.0e-8 or any(
            item.startswith("1:0:Scale") for item in frozen
        ):
            status = "scale_rejected"
        try:
            fractions = {
                name: [float(value), float(su)]
                for name, (value, su) in hist.ComputeMassFracs().items()
            }
        except Exception as exc:
            fractions = {"error": f"{type(exc).__name__}: {exc}"}
        results.append(
            {
                "candidate": label,
                "cif": str(cif),
                "status": status,
                "error": error,
                "baseline_wR_percent": baseline_wr,
                "wR_percent": float(hist.residuals["wR"]),
                "delta_wR_percent": float(hist.residuals["wR"] - baseline_wr),
                "R_percent": float(hist.residuals["R"]),
                "shift_micrometres": float(hist.SampleParameters["Shift"][0]),
                "frozen": frozen,
                "mass_fractions": fractions,
                "phases": [phase_summary(project, phase, hist) for phase in project.phases()],
            }
        )
    (outdir / "summary.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
