from __future__ import annotations

import csv
import json
from itertools import product
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIIspc as G2spc

from final_profile_screen import covariance_summary, refine_to_stability
from refine_utils import ROOT


SOURCE = ROOT / "_work" / "restart" / "final_candidate_bg7.gpx"
FINAL_GPX = ROOT / "final.gpx"
CIF_NAMES = ["MnWO4_wolframite.cif", "WO3_monoclinic.cif"]
FORMULAS = ["MnWO4", "WO3"]


def geometry_summary(phase, formula, center_elements):
    cell_dict = phase.get_cell()
    cell = [
        cell_dict[key]
        for key in (
            "length_a", "length_b", "length_c", "angle_alpha",
            "angle_beta", "angle_gamma"
        )
    ]
    orthogonalization, _ = G2lat.cell2AB(cell)
    sgdata = phase.data["General"]["SGData"]
    sites = []
    for atom in phase.atoms():
        equivalents = [
            generated[0] for generated in G2spc.GenAtom(atom.coordinates, sgdata)
        ]
        for coordinate in equivalents:
            sites.append((atom.element, atom.label, np.asarray(coordinate, dtype=float)))

    distances = {element: [] for element in center_elements}
    coordinations = {element: [] for element in center_elements}
    translations = [np.asarray(item, dtype=float) for item in product((-1, 0, 1), repeat=3)]
    for element, _label, center in sites:
        if element not in center_elements:
            continue
        oxygen = sorted(
            distance
            for other_element, _other_label, other in sites
            if other_element == "O"
            for translation in translations
            for distance in [
                float(np.linalg.norm(np.inner(orthogonalization, other + translation - center)))
            ]
            if 1.0e-6 < distance <= 3.0
        )
        first_shell = oxygen[:6]
        distances[element].extend(first_shell)
        coordinations[element].append(len(first_shell))
    result = {
        "parsed_reduced_formula": formula,
        "sites_in_unit_cell": len(sites),
        "full_occupancy": all(abs(atom.occupancy - 1.0) < 1.0e-8 for atom in phase.atoms()),
        "first_six_oxygen_distances_A": {},
    }
    for element, values in distances.items():
        result["first_six_oxygen_distances_A"][element] = {
            "minimum": float(min(values)),
            "maximum": float(max(values)),
            "mean": float(np.mean(values)),
            "coordination_counts": sorted(set(coordinations[element])),
        }
    return result


def project_parameter(project, variable):
    covariance = project["Covariance"]["data"]
    values = dict(zip(covariance.get("varyList", []), covariance.get("variables", [])))
    sigmas = dict(zip(covariance.get("varyList", []), covariance.get("sig", [])))
    return float(values[variable]), float(sigmas[variable])


def main():
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL_GPX))
    project.set_Frozen()
    project.save()

    # Native full-range replay from the saved final path.
    project = G2sc.G2Project(str(FINAL_GPX))
    replay_history = refine_to_stability(project, maximum=6)
    project.save()
    project = G2sc.G2Project(str(FINAL_GPX))
    hist = project.histogram(0)

    for phase, cif_name in zip(project.phases(), CIF_NAMES):
        phase.export_CIF(str(ROOT / cif_name))

    x = np.asarray(hist.getdata("x"), dtype=float)
    observed = np.asarray(hist.getdata("yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("ycalc"), dtype=float)
    background = np.asarray(hist.getdata("background"), dtype=float)
    difference = observed - calculated
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg",
            "observed_counts",
            "calculated_counts",
            "difference_counts",
            "background_counts",
        ])
        writer.writerows(
            zip(x, observed, calculated, difference, background)
        )

    fractions = hist.ComputeMassFracs()
    covariance = project["Covariance"]["data"]
    rvals = covariance["Rvals"]
    residuals = hist.residuals
    nobs = int(rvals["Nobs"])
    nvars = int(rvals["Nvars"])
    chisq = float(rvals["chisq"])
    gof = float(rvals["GOF"])
    profile = {
        key: float(hist.InstrumentParameters[key][1])
        for key in ("U", "W", "X", "SH/L", "Polariz.")
    }
    shift = float(hist.SampleParameters["Shift"][0])
    geometry = [
        geometry_summary(project.phase(0), FORMULAS[0], ["Mn", "W"]),
        geometry_summary(project.phase(1), FORMULAS[1], ["W"]),
    ]

    phases_json = []
    for index, (phase, cif_name, formula, geom) in enumerate(
        zip(project.phases(), CIF_NAMES, FORMULAS, geometry)
    ):
        fraction, fraction_esd = fractions[phase.name]
        cell = phase.get_cell_and_esd()
        hap = phase.data["Histograms"][hist.name]
        phases_json.append({
            "name": phase.name,
            "formula": formula,
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "cif_path": cif_name,
            "weight_fraction": float(fraction),
            "weight_percent": 100.0 * float(fraction),
            "formal_weight_fraction_esd": float(fraction_esd),
            "cell": cell,
            "density_g_cm3": float(phase.density),
            "phase_R_F_percent": float(residuals[f"{index}:0:Rf"]),
            "phase_R_F2_percent": float(residuals[f"{index}:0:Rf^2"]),
            "isotropic_size_micrometres": (
                float(hap["Size"][1][0]) if hap["Size"][2][0] else None
            ),
            "march_dollase": (
                {
                    "axis": [int(value) for value in hap["Pref.Ori."][3]],
                    "coefficient": float(hap["Pref.Ori."][1]),
                }
                if hap["Pref.Ori."][2]
                else None
            ),
            "geometry_check": geom,
        })

    result = {
        "phases": phases_json,
        "fraction_basis": (
            "Normalized over the modeled crystalline phases; amorphous or "
            "unmodeled material is not quantified."
        ),
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": gof,
            "chi_square": chisq,
            "reduced_chi_square": chisq / (nobs - nvars),
            "n_observations": nobs,
            "n_refined_variables": nvars,
            "two_theta_range_deg": [float(x[0]), float(x[-1])],
        },
        "refinement_model": {
            "software": "GSAS-II",
            "project_path": "final.gpx",
            "profile_path": "fit.csv",
            "background": "7-term Chebyshev-1",
            "instrument_profile": profile,
            "specimen_displacement_micrometres": shift,
            "angular_corrections_refined": ["specimen displacement"],
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "replay_history_Rwp_percent": [
                float(item["wR"]) for item in replay_history
            ],
        },
        "formal_uncertainty_note": (
            "Pointwise uncertainties were not supplied. GSAS-II counting-statistical "
            "weights were used; formal ESDs do not include model/source systematic error."
        ),
        "validation": {
            "frozen_variables": list(project.get_Frozen()),
            "correlations_abs_ge_0.90": covariance_summary(project)[
                "correlations_abs_ge_0.90"
            ],
            "profile_difference_is_observed_minus_calculated": bool(
                np.allclose(difference, hist.getdata("residual"))
            ),
            "weight_fraction_sum": float(
                sum(item["weight_fraction"] for item in phases_json)
            ),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    mn = phases_json[0]
    wo = phases_json[1]
    mn_geom = mn["geometry_check"]["first_six_oxygen_distances_A"]
    wo_geom = wo["geometry_check"]["first_six_oxygen_distances_A"]
    report = f"""# PXRD phase analysis

## Result

The crystalline model contains **wolframite MnWO4 (P2/c)** at **{mn['weight_percent']:.2f} wt%** and **monoclinic WO3 (P21/c)** at **{wo['weight_percent']:.2f} wt%**. Fractions are normalized to these modeled crystalline phases only. The final full-range GSAS-II replay gives Rwp = {result['fit_statistics']['Rwp_percent']:.3f}%, Rp = {result['fit_statistics']['Rp_percent']:.3f}%, and GOF = {gof:.3f}.

This is chemically consistent with reaction of the reported WO3 and Mn3O4 precursors at 700 C to MnWO4 with residual WO3. The refinement used the reported reflection-mode Cu Kalpha1/Kalpha2 wavelengths and 0.5 doublet ratio on the original counts.

## Evidence and model selection

The dominant peak sequence at approximately 15.10, 18.06, 23.29/23.80, and 29.58/30.03 degrees 2theta matches the 010, 100, 011/110, and 11-1/111 families of wolframite MnWO4 after the single refined specimen-displacement correction. No exact MnWO4 entry was present in the supplied database, so same-stoichiometry analogues were screened. A fully occupied ZnWO4 P2/c parent with Zn->Mn substitution fit better than the physically plausible FeWO4 parent; another FeWO4 record was rejected before fitting because it generated 1.54 A W-O and 1.64 A Mn-O contacts. Scheelite, fergusonite, MnMoO4-type, and Mn3WO6 alternatives failed by zero/poor scale, diagnostic reflections, or geometry.

Residual families near 22.7-24.0, 32.8-33.7, and 41 degrees require monoclinic WO3. It outperformed orthorhombic, triclinic, and tetragonal WO3 records under the same provisional schedule. Tetragonal Mn3O4 alternatives gave only a 0.07-0.11 percentage-point provisional Rwp gain, while their strong nominally unique peaks missed by about 0.12-0.17 degrees and their refined cells expanded; Mn3O4 was therefore rejected as an overlap surrogate. A Mn3O4 fraction cannot be determined reliably from this pattern and is not reported.

Both retained phases are ordered and fully occupied. The submitted MnWO4 model has six-neighbour Mn-O and W-O ranges of {mn_geom['Mn']['minimum']:.3f}-{mn_geom['Mn']['maximum']:.3f} A and {mn_geom['W']['minimum']:.3f}-{mn_geom['W']['maximum']:.3f} A. WO3 has six-neighbour W-O distances of {wo_geom['W']['minimum']:.3f}-{wo_geom['W']['maximum']:.3f} A. These are chemically plausible. MnWO4 coordinates remain those of the screened substituted prototype; WO3 coordinates remain those of the selected room-temperature neutron record. They were not independently refined because the powder data do not constrain the many oxygen coordinates reliably.

## Final profile and uncertainty

The clean restart retained a common nonnegative W+X profile (W = {profile['W']:.3f}, X = {profile['X']:.3f}); every branch containing U drove U to its bound. SH/L was rejected because it changed Rwp by only about 0.002 percentage points and correlated 0.963 with displacement. MnWO4 size- and strain-only branches returned to neutral bounds. WO3 supports a size-only term of {wo['isotropic_size_micrometres']:.3f} micrometres; its strain-only alternative was poorer and required about 7100 microstrain. An effective polarization of {profile['Polariz.']:.3f} and weak MnWO4 [001] March-Dollase term ({mn['march_dollase']['coefficient']:.4f}) improve coherent intensity residuals without bounds or high correlations. WO3 texture was rejected because the apparent gain did not repeat consistently across isolated reflection families.

The formal GSAS-II fraction ESD is about {100.0 * mn['formal_weight_fraction_esd']:.2f} wt%, but this is optimistic: pointwise uncertainties and a calibrated instrument profile were not supplied, and the MnWO4 coordinates are prototype-derived. A plausible WO3 displacement-parameter sensitivity test moved the MnWO4 fraction from 78.3 to 78.7 wt% (the source's unphysical reported zeros gave 79.1 wt%). Allowing for structure, profile, and absorption/polarization systematics, the defensible precision is about **+/-2 wt% absolute**, not the formal ESD. Minor phases below roughly 1-2 wt%, amorphous material, and phases whose peaks are completely overlapped cannot be excluded reliably.
"""
    (ROOT / "report.md").write_text(report)

    print(json.dumps({
        "fit_statistics": result["fit_statistics"],
        "phases": [
            {
                "name": item["name"],
                "weight_fraction": item["weight_fraction"],
                "cif_path": item["cif_path"],
                "cell": item["cell"],
            }
            for item in phases_json
        ],
        "validation": result["validation"],
    }, indent=2))


if __name__ == "__main__":
    main()
