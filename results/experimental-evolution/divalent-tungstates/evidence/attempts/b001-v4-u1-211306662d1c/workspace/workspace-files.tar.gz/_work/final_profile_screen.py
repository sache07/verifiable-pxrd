from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat

from refine_utils import ROOT, make_project, phase_summary


CIF_ROOT = Path(
    "<RUN>/resources/"
    "b001-c04/cif"
)
OUTDIR = ROOT / "_work" / "final_branches"
MNWO4 = ROOT / "_work" / "candidates" / "mnwo4_zn_parent.cif"
WO3 = CIF_ROOT / "2" / "31" / "10" / "2311041.cif"


def covariance_summary(project):
    cov = project["Covariance"].get("data", {})
    rvals = cov.get("Rvals", {})
    vary = list(cov.get("varyList", []))
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    largest = []
    if matrix.ndim == 2 and matrix.shape == (len(vary), len(vary)):
        sd = np.sqrt(np.clip(np.diag(matrix), 0.0, None))
        denom = np.outer(sd, sd)
        corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
        for i in range(len(vary)):
            for j in range(i + 1, len(vary)):
                if abs(corr[i, j]) >= 0.90:
                    largest.append([vary[i], vary[j], float(corr[i, j])])
        largest.sort(key=lambda item: abs(item[2]), reverse=True)
    return {
        "vary_list": vary,
        "converged": bool(rvals.get("converged", False)),
        "delta_chi2": float(rvals.get("DelChi2", float("nan"))),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", float("nan"))),
        "gof": float(rvals.get("GOF", float("nan"))),
        "nvars": int(rvals.get("Nvars", len(vary))),
        "correlations_abs_ge_0.90": largest[:30],
    }


def refine_to_stability(project, maximum: int = 8):
    history = []
    previous = None
    for _ in range(maximum):
        project.do_refinements([{}])
        wr = float(project.histogram(0).residuals["wR"])
        cov = covariance_summary(project)
        history.append({"wR": wr, **{k: cov[k] for k in (
            "converged", "delta_chi2", "max_shift_over_sigma"
        )}})
        if (
            previous is not None
            and abs(wr - previous) < 2.0e-5
            and cov["converged"]
            and abs(cov["max_shift_over_sigma"]) < 0.25
        ):
            break
        previous = wr
    project.save()
    return history


def project_summary(project, label, history):
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    try:
        fractions = {
            key: [float(value), float(su)]
            for key, (value, su) in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": f"{type(exc).__name__}: {exc}"}
    return {
        "label": label,
        "gpx": str(Path(project.filename).relative_to(ROOT)),
        "wR_percent": float(hist.residuals["wR"]),
        "R_percent": float(hist.residuals["R"]),
        "profile": {
            key: {"value": float(inst[key][1]), "refine": bool(inst[key][2])}
            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "shift_micrometres": float(sample["Shift"][0]),
        "frozen": list(project.get_Frozen()),
        "mass_fractions": fractions,
        "phases": [phase_summary(project, phase, hist) for phase in project.phases()],
        "covariance": covariance_summary(project),
        "refinement_history": history,
    }


def set_common_profile(project, values, refine):
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        inst[key][2] = False
    for key in ("U", "W", "X"):
        inst[key][1] = float(values.get(key, 0.0))
        inst[key][2] = key in refine
        if key in refine:
            project.set_Controls("parmMin", 0.0, variable=f":0:{key}")
            project.set_Controls("parmMax", 100.0, variable=f":0:{key}")
    project.set_Frozen()
    project.save()


def build_base():
    gpx = OUTDIR / "clean_base.gpx"
    project, hist, phases = make_project(
        gpx,
        [
            ("MnWO4_wolframite", MNWO4),
            ("WO3_monoclinic", WO3),
        ],
        shift=933.0,
        background_terms=10,
        profile=(0.0, 10.0, 2.0),
    )
    inventory_cells = [
        [4.79956, 5.70769, 4.97653, 90.0, 91.12768, 90.0],
        [7.69123, 7.55219, 10.52015, 90.0, 136.06629, 90.0],
    ]
    for phase, cell in zip(phases, inventory_cells):
        phase.data["General"]["Cell"][1:7] = cell
        phase.data["General"]["Cell"][7] = float(
            G2lat.calc_V(G2lat.cell2A(cell))
        )
    project.set_Controls("cycles", 16)
    project.set_Controls("parmMin", 0.0, variable=":0:Shift")
    project.set_Controls("parmMax", 1500.0, variable=":0:Shift")

    # Establish only background and scales before allowing the one angular
    # correction and phase cells to move.
    hist.Background[0][1] = True
    for phase in phases:
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        phase.set_refinements({"Cell": False})
    hist.SampleParameters["Shift"][1] = False
    project.save()
    first = refine_to_stability(project, maximum=4)

    hist.SampleParameters["Shift"][1] = True
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.save()
    second = refine_to_stability(project, maximum=6)
    return project, first + second


def main():
    OUTDIR.mkdir(parents=True, exist_ok=True)
    base, base_history = build_base()
    results = [project_summary(base, "clean_base_fixed_profile", base_history)]

    branches = {
        "profile_W": ({"W": 10.0}, {"W"}),
        "profile_X": ({"W": 0.05, "X": 2.0}, {"X"}),
        "profile_U": ({"U": 1.0, "W": 0.05}, {"U"}),
        "profile_W_X": ({"W": 10.0, "X": 2.0}, {"W", "X"}),
        "profile_U_W": ({"U": 1.0, "W": 10.0}, {"U", "W"}),
        "profile_U_X": ({"U": 1.0, "W": 0.05, "X": 2.0}, {"U", "X"}),
        "profile_U_W_X": (
            {"U": 1.0, "W": 10.0, "X": 2.0},
            {"U", "W", "X"},
        ),
    }
    for label, (values, refine) in branches.items():
        project = G2sc.G2Project(
            str(OUTDIR / "clean_base.gpx"),
            newgpx=str(OUTDIR / f"{label}.gpx"),
        )
        set_common_profile(project, values, refine)
        history = refine_to_stability(project, maximum=6)
        results.append(project_summary(project, label, history))

    summary_path = OUTDIR / "profile_summary.json"
    summary_path.write_text(json.dumps(results, indent=2) + "\n")
    concise = [
        {
            "label": item["label"],
            "wR_percent": item["wR_percent"],
            "profile": item["profile"],
            "shift_micrometres": item["shift_micrometres"],
            "frozen": item["frozen"],
            "max_shift_over_sigma": item["covariance"]["max_shift_over_sigma"],
            "correlations": item["covariance"]["correlations_abs_ge_0.90"],
        }
        for item in results
    ]
    print(json.dumps(concise, indent=2))


if __name__ == "__main__":
    main()
