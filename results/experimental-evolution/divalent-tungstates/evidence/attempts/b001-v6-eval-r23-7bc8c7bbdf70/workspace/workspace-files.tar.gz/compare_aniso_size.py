#!/usr/bin/env python3
"""Challenge isotropic size with a one-axis uniaxial model."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent


def serializable(value):
    if hasattr(value, "tolist"):
        return value.tolist()
    raise TypeError(type(value).__name__)


def main(phase_index: int, axis: tuple[int, int, int]) -> None:
    axis_tag = "".join(str(value).replace("-", "m") for value in axis)
    tag = f"aniso_size_p{phase_index}_{axis_tag}"
    project = G2sc.G2Project(
        str(WORK / "working.gpx"), newgpx=str(WORK / ".tmp" / f"{tag}.gpx")
    )
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    isotropic_size = phase.getHAPvalues(hist)["Size"][1][0]
    phase.setSampleProfile(
        hist,
        "size",
        "uniaxial",
        isotropic_size,
        isotropic_size,
        list(axis),
        LGmix=1.0,
    )
    phase.set_HAP_refinements(
        {"Size": {"type": "uniaxial", "refine": True}}, [hist]
    )
    project.set_Controls("cycles", 18)
    project.do_refinements([{}])
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    summary = {
        "phase_index": phase_index,
        "phase": phase.name,
        "axis": axis,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "size": phase.getHAPvalues(hist)["Size"],
        "frozen": project.get_Frozen(),
    }
    project.save()
    (WORK / ".tmp" / f"{tag}.json").write_text(
        json.dumps(summary, indent=2, default=serializable) + "\n"
    )


if __name__ == "__main__":
    main(int(sys.argv[1]), tuple(map(int, sys.argv[2:5])))
