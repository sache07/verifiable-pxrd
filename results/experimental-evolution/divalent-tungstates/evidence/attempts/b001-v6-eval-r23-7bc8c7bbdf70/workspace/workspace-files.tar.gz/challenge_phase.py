#!/usr/bin/env python3
"""Add one watch-list phase at fixed source cell and refine its scale."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
CIF_ROOT = Path(
    "<RUN>/"
    "resources/b001-c05/cif"
)


def cod_cif(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def serializable(value):
    if hasattr(value, "tolist"):
        return value.tolist()
    raise TypeError(type(value).__name__)


def main(cod_id: str, name: str) -> None:
    tag = f"challenge_{cod_id}"
    project = G2sc.G2Project(
        str(WORK / "working.gpx"), newgpx=str(WORK / ".tmp" / f"{tag}.gpx")
    )
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cod_cif(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
    )
    phase.HAPvalue("Scale", 0.02, targethistlist=[hist])
    phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=0.5)
    phase.clear_HAP_refinements(
        {
            "Size": False,
            "Mustrain": False,
            "HStrain": False,
            "Pref.Ori.": False,
            "Extinction": False,
        },
        [hist],
    )
    for value in phase.getHAPvalues(hist)["Babinet"].values():
        value[1] = False
    phase.set_refinements({"Cell": False})
    phase.set_HAP_refinements({"Scale": True}, [hist])
    project.set_Controls("cycles", 18)
    project.do_refinements([{}])
    hist = project.histogram(0)
    phase = project.phase(name)
    cov = project.data["Covariance"]["data"]
    scale_name = f"{phase.id}:0:Scale"
    scale_su = None
    if scale_name in cov.get("varyList", []):
        scale_su = cov["sig"][cov["varyList"].index(scale_name)]
    summary = {
        "cod_id": cod_id,
        "phase": phase.name,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "scale": phase.HAPvalue("Scale", targethistlist=[hist]),
        "scale_su": scale_su,
        "cell": phase.get_cell(),
        "frozen": project.get_Frozen(),
    }
    project.save()
    (WORK / ".tmp" / f"{tag}.json").write_text(
        json.dumps(summary, indent=2, default=serializable) + "\n"
    )


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
