#!/usr/bin/env python3
"""Compare candidate WO3 records under one fixed refinement protocol."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
CIF_ROOT = Path(
    "<RUN>/"
    "resources/b001-c05/cif"
)


def cod_cif(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize(phase, hist) -> None:
    phase.setSampleProfile(hist, "size", "isotropic", 1e6, LGmix=0.5)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=0.5)
    phase.clear_HAP_refinements(
        {
            "Size": False,
            "Mustrain": False,
            "HStrain": False,
            "Pref.Ori.": False,
            "Extinction": False,
        },
        [hist],
    )
    for value in phase.getHAPvalues(hist)["Babinet"].values():
        value[1] = False


def main(cod_id: str) -> None:
    project_path = WORK / ".tmp" / f"wo3_{cod_id}.gpx"
    result_path = WORK / ".tmp" / f"wo3_{cod_id}.json"
    project = G2sc.G2Project(newgpx=str(project_path))
    hist = project.add_powder_histogram(
        str(WORK / "inputs" / "pattern.csv"),
        str(WORK / "instrument.instprm"),
        fmthint="comma",
    )
    hist.SampleParameters["Scale"][1] = False
    for key in (
        "DisplaceX",
        "DisplaceY",
        "Shift",
        "Transparency",
        "SurfRoughA",
        "SurfRoughB",
        "Absorption",
    ):
        if key in hist.SampleParameters and isinstance(hist.SampleParameters[key], list):
            hist.SampleParameters[key][1] = False
    for key, value in {
        "Zero": -0.20,
        "U": 0.0,
        "V": 0.0,
        "W": 30.0,
        "X": 11.5,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }.items():
        hist.InstrumentParameters[key][1] = value

    specifications = [
        (cod_cif("7219229"), "CaWO4_scheelite", 47.5),
        (cod_cif(cod_id), f"WO3_{cod_id}", 5.0),
        (WORK / "Ca3WO6_prototype.cif", "Ca3WO6_double_perovskite", 11.0),
    ]
    for path, name, scale in specifications:
        phase = project.add_phase(
            str(path), phasename=name, histograms=[hist], fmthint="CIF"
        )
        phase.HAPvalue("Scale", scale, targethistlist=[hist])
        neutralize(phase, hist)

    project.set_Controls("cycles", 15)
    recipes = [
        {
            "set": {
                "Background": {
                    "type": "chebyschev-1",
                    "no. coeffs": 6,
                    "refine": True,
                },
                "Scale": True,
            }
        },
        {"set": {"Cell": True, "Instrument Parameters": ["Zero"]}},
        {"set": {"Instrument Parameters": ["W", "X"]}},
    ]
    project.do_refinements(recipes)
    hist = project.histogram(0)
    summary = {
        "cod_id": cod_id,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "zero": hist.InstrumentParameters["Zero"][1],
        "W": hist.InstrumentParameters["W"][1],
        "X": hist.InstrumentParameters["X"][1],
        "phases": {
            phase.name: {
                "scale": phase.HAPvalue("Scale", targethistlist=[hist]),
                "cell": phase.get_cell(),
            }
            for phase in project.phases()
        },
    }
    project.save()
    result_path.write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main(sys.argv[1])
