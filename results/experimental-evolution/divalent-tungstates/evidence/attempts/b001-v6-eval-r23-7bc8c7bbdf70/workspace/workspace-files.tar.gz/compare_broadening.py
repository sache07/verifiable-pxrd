#!/usr/bin/env python3
"""One-at-a-time isotropic size/strain trials from a common GSAS-II project."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent


def serializable(value):
    if hasattr(value, "tolist"):
        return value.tolist()
    raise TypeError(type(value).__name__)


def main(phase_index: int, term: str) -> None:
    tag = f"broad_p{phase_index}_{term}"
    project = G2sc.G2Project(
        str(WORK / "working.gpx"), newgpx=str(WORK / ".tmp" / f"{tag}.gpx")
    )
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    for candidate in project.phases():
        candidate.clear_HAP_refinements({"Size": False, "Mustrain": False}, [hist])
    if term == "size":
        phase.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=1.0)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
    elif term == "strain":
        phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=0.0)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
    else:
        raise ValueError(term)
    project.set_Controls("cycles", 18)
    project.do_refinements([{}])
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    summary = {
        "phase_index": phase_index,
        "phase": phase.name,
        "term": term,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "size": phase.getHAPvalues(hist)["Size"],
        "mustrain": phase.getHAPvalues(hist)["Mustrain"],
        "last_shift": project.data["Covariance"]["data"].get("Lastshft"),
    }
    project.save()
    (WORK / ".tmp" / f"{tag}.json").write_text(
        json.dumps(summary, indent=2, default=serializable) + "\n"
    )


if __name__ == "__main__":
    main(int(sys.argv[1]), sys.argv[2])
