#!/usr/bin/env python3
"""Small one-at-a-time profile refinements from working.gpx."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent


def serializable(value):
    if hasattr(value, "tolist"):
        return value.tolist()
    raise TypeError(type(value).__name__)


def main(term: str) -> None:
    project = G2sc.G2Project(
        str(WORK / "working.gpx"),
        newgpx=str(WORK / ".tmp" / f"term_{term}.gpx"),
    )
    hist = project.histogram(0)
    phase = project.phase(0)
    if term == "shl":
        hist.InstrumentParameters["SH/L"][1] = 0.01
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    elif term == "u":
        hist.InstrumentParameters["U"][1] = 1.0
        hist.set_refinements({"Instrument Parameters": ["U"]})
    elif term == "ca_strain":
        phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=0.0)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
    elif term == "size_mix":
        size = phase.getHAPvalues(hist)["Size"]
        size[1][2] = 0.8
        size[2][2] = True
    else:
        raise ValueError(term)
    project.set_Controls("cycles", 18)
    project.do_refinements([{}])
    hist = project.histogram(0)
    phase = project.phase(0)
    summary = {
        "term": term,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {
            key: hist.InstrumentParameters[key]
            for key in ("Zero", "Polariz.", "U", "W", "X", "SH/L")
        },
        "size": phase.getHAPvalues(hist)["Size"],
        "mustrain": phase.getHAPvalues(hist)["Mustrain"],
        "frozen": project.get_Frozen(),
    }
    project.save()
    (WORK / ".tmp" / f"term_{term}.json").write_text(
        json.dumps(summary, indent=2, default=serializable) + "\n"
    )


if __name__ == "__main__":
    main(sys.argv[1])
