#!/usr/bin/env python3
"""Replay ordered scheelite prototype coordinates in the accepted model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


COORDS = {
    # Coordinates after GSAS-II import into the common I 41/a setting.
    "bamo": (0.22831, 0.13536, 0.04996),  # COD 2300459
    "cawo": (0.15202, 0.01135, 0.20864),  # COD 7219229
    "srwo": (0.24970, 0.09250, 0.04210),  # COD 1546036
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("prototype", choices=sorted(COORDS))
    parser.add_argument("--out", required=True)
    parser.add_argument("--cif", required=True)
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.project)
    gpx.save(args.out)
    phase = gpx.phase("BaWO4")
    oxygen = [atom for atom in phase.atoms() if atom.element == "O"]
    if len(oxygen) != 1:
        raise RuntimeError(f"Expected one ordered oxygen site, found {len(oxygen)}")
    oxygen[0].coordinates = COORDS[args.prototype]
    oxygen[0].refinement_flags = ""
    gpx.set_Controls("cycles", 16)
    gpx.save()

    # The accepted model already has background, all scales, one angular
    # correction, cells, common profile and supported broadening active.
    # Reopen/replay the complete range after changing the prototype.
    for _ in range(3):
        gpx.refine(printFile=str(Path(args.out).with_suffix(".lst")))
        gpx.reload()
    gpx.save()

    phase = gpx.phase("BaWO4")
    phase.export_CIF(args.cif)
    hist = gpx.histogram(0)
    rvals = gpx.data["Covariance"]["data"]["Rvals"]
    print(json.dumps({
        "prototype": args.prototype,
        "Rwp": hist.get_wR(),
        "GOF": rvals["GOF"],
        "oxygen": [atom.coordinates for atom in phase.atoms() if atom.element == "O"],
        "cell": phase.get_cell(),
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": gpx.get_Frozen(),
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
