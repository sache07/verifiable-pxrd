#!/usr/bin/env python3
"""Replay the accepted full-range model and export the requested deliverables."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "baco3_old_source.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "BaWO4": {
        "formula": "BaWO4",
        "cif_path": "phase_BaWO4.cif",
        "source_model": "ordered scheelite prototype from COD 2300459 (BaMoO4), Ba/Mo -> Ba/W; restrained oxygen refinement",
    },
    "Ba3W2O9": {
        "formula": "Ba3W2O9",
        "cif_path": "phase_Ba3W2O9.cif",
        "source_model": "COD 1533878",
    },
    "WO3": {
        "formula": "WO3",
        "cif_path": "phase_WO3.cif",
        "source_model": "COD 2311041",
    },
    "BaCO3": {
        "formula": "BaCO3",
        "cif_path": "phase_BaCO3.cif",
        "source_model": "COD 1011149 coordinates (origin transformed into the refined Pmcn setting); room-temperature isotropic U values retained from COD 9010928",
    },
}


def assert_final_model(gpx: G2sc.G2Project) -> None:
    """Guard against exporting a trial or an unsupported nuisance model."""
    if len(gpx.histograms()) != 1:
        raise RuntimeError("Expected exactly one powder histogram")
    if [phase.name for phase in gpx.phases()] != list(PHASE_INFO):
        raise RuntimeError("Unexpected phase inventory or phase order")
    if gpx.get_Frozen():
        raise RuntimeError(f"Frozen parameters remain: {gpx.get_Frozen()}")

    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for name in ("U", "V", "Y"):
        if inst[name][1] != 0.0 or inst[name][2]:
            raise RuntimeError(f"Unsupported profile term {name} is active")
    if inst["SH/L"][2] or not math.isclose(inst["SH/L"][1], 0.002):
        raise RuntimeError("SH/L should remain at its neutral lower value")
    for name in ("Zero", "Polariz.", "W", "X"):
        if not inst[name][2]:
            raise RuntimeError(f"Required common term {name} is inactive")
    background = hist.data["Background"][0]
    if background[2] != 6 or not background[1]:
        raise RuntimeError("Expected active six-coefficient smooth background")

    sample = hist.data["Sample Parameters"]
    for name in ("SurfRoughA", "SurfRoughB"):
        if sample[name] != [0.0, False]:
            raise RuntimeError(f"Unsupported roughness term {name} remains")

    expected_broadening = {
        "BaWO4": (False, False),
        "Ba3W2O9": (True, False),
        "WO3": (True, False),
        "BaCO3": (False, True),
    }
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        if hap["Pref.Ori."][1:3] != [1.0, False]:
            raise RuntimeError(f"Texture remains in {phase.name}")
        if hap["Extinction"] != [0.0, False]:
            raise RuntimeError(f"Extinction remains in {phase.name}")
        if hap["Babinet"]["BabA"] != [0.0, False] or hap["Babinet"]["BabU"] != [0.0, False]:
            raise RuntimeError(f"Babinet correction remains in {phase.name}")
        got = (bool(hap["Size"][2][0]), bool(hap["Mustrain"][2][0]))
        if got != expected_broadening[phase.name]:
            raise RuntimeError(f"Unexpected broadening flags for {phase.name}: {got}")

    restraints = gpx.data["Restraints"]["data"]["BaWO4"]["Bond"]
    if not restraints["Use"] or restraints["wtFactor"] != 100.0 or len(restraints["Bonds"]) != 4:
        raise RuntimeError("The accepted BaWO4 W-O restraint is absent or changed")


def main() -> None:
    gpx = G2sc.G2Project(str(SOURCE))
    gpx.save(str(FINAL))
    hist = gpx.histogram(0)
    # Use every measured point, including the narrow end slivers omitted while
    # prototyping the model.
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    gpx.set_Controls("cycles", 16)
    gpx.save()

    # Save, reopen and replay the complete range to establish export/project
    # identity. Continue until shifts are small, with a finite replay cap.
    for replay in range(5):
        gpx.refine(printFile=str(ROOT / "final.lst"))
        gpx.reload()
        shift = gpx.data["Covariance"]["data"]["Rvals"].get("Max shft/sig", float("inf"))
        if replay >= 1 and shift < 0.01:
            break
    gpx.save()
    gpx = G2sc.G2Project(str(FINAL))
    assert_final_model(gpx)

    hist = gpx.histogram(0)
    arrays = np.asarray(hist.data["data"][1], dtype=float)
    x, observed, weights, calculated, background, stored_difference = arrays
    if len(x) != 8301:
        raise RuntimeError(f"Expected 8301 profile points, found {len(x)}")
    if np.any(calculated <= 0.0):
        raise RuntimeError("Calculated profile does not cover the complete measurement range")
    difference = observed - calculated
    if not np.allclose(difference, stored_difference, rtol=0.0, atol=1e-8):
        raise RuntimeError("Stored GSAS-II difference profile is inconsistent")

    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
        writer.writerows(zip(x, observed, calculated, difference))

    fractions = hist.ComputeMassFracs()
    if not math.isclose(sum(value[0] for value in fractions.values()), 1.0, abs_tol=1e-10):
        raise RuntimeError("Crystalline phase fractions do not sum to one")

    phases = []
    for phase in gpx.phases():
        info = PHASE_INFO[phase.name]
        phase.export_CIF(str(ROOT / info["cif_path"]))
        value, esd = fractions[phase.name]
        phases.append({
            "name": phase.name,
            "formula": info["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": info["cif_path"],
            "weight_fraction": value,
            "weight_fraction_esd": esd,
            "cell": phase.get_cell(),
            "source_model": info["source_model"],
        })

    rvals = gpx.data["Covariance"]["data"]["Rvals"]
    profile_stats = hist.data["data"][0]
    result = {
        "input_pattern": "inputs/pattern.csv",
        "project_path": "final.gpx",
        "fraction_basis": "normalized over the modeled crystalline phases; amorphous content not measured",
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": hist.get_wR(),
            "Rp_percent": profile_stats["R"],
            "Rexp_percent": profile_stats["wRmin"],
            "goodness_of_fit": rvals["GOF"],
            "chi_squared": rvals["chisq"],
            "durbin_watson": profile_stats["Durbin-Watson"],
            "observations": rvals["Nobs"],
            "variables": rvals["Nvars"],
            "fit_range_two_theta_deg": list(hist.data["Limits"][1]),
            "restraint_sum": rvals.get("RestraintSum", 0.0),
            "restraint_terms": rvals.get("RestraintTerms", 0),
        },
    }
    with (ROOT / "result.json").open("w") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")

    # Reopen one last time and verify the project values recorded above.
    check = G2sc.G2Project(str(FINAL))
    check_fracs = check.histogram(0).ComputeMassFracs()
    for row in phases:
        if not math.isclose(row["weight_fraction"], check_fracs[row["name"]][0], abs_tol=1e-12):
            raise RuntimeError(f"Export/project fraction mismatch for {row['name']}")

    print(json.dumps({
        "replays": replay + 1,
        "max_shift_over_sigma": rvals.get("Max shft/sig"),
        "fit_statistics": result["fit_statistics"],
        "fractions": {row["name"]: row["weight_fraction"] for row in phases},
    }, indent=2))


if __name__ == "__main__":
    main()
