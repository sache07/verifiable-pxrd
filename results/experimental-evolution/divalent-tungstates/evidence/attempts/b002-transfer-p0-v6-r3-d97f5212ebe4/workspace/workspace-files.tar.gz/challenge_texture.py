#!/usr/bin/env python3
"""Test one March-Dollase texture axis against the accepted correction model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


PHASES = {
    "bawo4": "BaWO4",
    "ba3w2o9": "Ba3W2O9",
    "wo3": "WO3",
    "baco3": "BaCO3",
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=sorted(PHASES))
    parser.add_argument("axis", help="three Miller indices without separators, e.g. 101")
    parser.add_argument("--base", default="correction_polarization.gpx")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    if len(args.axis) != 3 or not args.axis.isdigit():
        raise ValueError("axis must contain three nonnegative single-digit indices")
    axis = [int(v) for v in args.axis]

    gpx = G2sc.G2Project(args.base)
    gpx.save(args.out)
    hist = gpx.histogram(0)
    phase = gpx.phase(PHASES[args.phase])
    hap = phase.getHAPvalues(hist)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][3] = axis
    phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])
    gpx.set_Controls("parmMin", 0.5, f"{phase.id}:0:MD")
    gpx.set_Controls("parmMax", 2.0, f"{phase.id}:0:MD")
    gpx.set_Controls("cycles", 12)
    gpx.save()
    listing = Path(args.out).with_suffix(".lst")
    for _ in range(3):
        gpx.refine(printFile=str(listing))
        gpx.reload()
    gpx.save()

    hist = gpx.histogram(0)
    phase = gpx.phase(PHASES[args.phase])
    cov = gpx.data["Covariance"]["data"]
    matching = {
        str(v): [float(value), float(esd)]
        for v, value, esd in zip(cov["varyList"], cov["variables"], cov["sig"])
        if "MD" in str(v)
    }
    print(json.dumps({
        "phase": phase.name,
        "axis": axis,
        "Rwp": hist.get_wR(),
        "GOF": cov["Rvals"]["GOF"],
        "preferred_orientation": phase.getHAPvalues(hist)["Pref.Ori."],
        "variables": matching,
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": gpx.get_Frozen(),
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
