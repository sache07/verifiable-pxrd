#!/usr/bin/env python3
"""Combine the supported phase-specific broadening terms and replay."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASE = "watch_baco3.gpx"
OUT = "combined_broadening.gpx"

gpx = G2sc.G2Project(BASE)
gpx.save(OUT)
hist = gpx.histogram(0)

for phase_name, value in [("Ba3W2O9", 0.33), ("WO3", 0.145)]:
    phase = gpx.phase(phase_name)
    phase.setSampleProfile(hist, "size", "isotropic", value, LGmix=1.0)
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True, "value": value,
                 "LGmix": {"value": 1.0, "refine": False}}
    }, [hist])
    gpx.set_Controls("parmMin", 0.01, f"{phase.id}:0:Size;i")
    gpx.set_Controls("parmMax", 10.0, f"{phase.id}:0:Size;i")

phase = gpx.phase("BaCO3")
phase.setSampleProfile(hist, "microstrain", "isotropic", 8000.0, LGmix=1.0)
phase.set_HAP_refinements({
    "Mustrain": {"type": "isotropic", "refine": True,
                 "LGmix": {"value": 1.0, "refine": False}}
}, [hist])
gpx.set_Controls("parmMin", 0.0, f"{phase.id}:0:Mustrain;i")
gpx.set_Controls("parmMax", 50000.0, f"{phase.id}:0:Mustrain;i")

hist.set_refinements({"Instrument Parameters": ["W", "X"]})
gpx.set_Controls("cycles", 16)
gpx.save()
for _ in range(4):
    gpx.refine(printFile=str(Path(OUT).with_suffix(".lst")))
    gpx.reload()
gpx.save()

hist = gpx.histogram(0)
cov = gpx.data["Covariance"]["data"]
matching = {
    str(v): [float(value), float(esd)]
    for v, value, esd in zip(cov["varyList"], cov["variables"], cov["sig"])
    if "Size" in str(v) or "Mustrain" in str(v)
}
print(json.dumps({
    "Rwp": hist.get_wR(),
    "GOF": cov["Rvals"]["GOF"],
    "broadening_variables": matching,
    "instrument": {
        key: hist.data["Instrument Parameters"][0][key][1]
        for key in ["U", "V", "W", "X", "Y", "SH/L"]
    },
    "mass_fractions": hist.ComputeMassFracs(),
    "frozen": gpx.get_Frozen(),
}, indent=2, sort_keys=True))
