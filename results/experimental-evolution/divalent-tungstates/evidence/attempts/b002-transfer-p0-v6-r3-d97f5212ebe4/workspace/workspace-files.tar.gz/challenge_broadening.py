#!/usr/bin/env python3
"""Test one phase-specific size or microstrain term against a fixed common profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


PHASES = {
    "bawo4": "BaWO4",
    "ba3w2o9": "Ba3W2O9",
    "wo3": "WO3",
    "baco3": "BaCO3",
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=sorted(PHASES))
    parser.add_argument("term", choices=["size", "micro"])
    parser.add_argument("--base", default="watch_baco3.gpx")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.base)
    gpx.save(args.out)
    hist = gpx.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]})
    phase = gpx.phase(PHASES[args.phase])
    if args.term == "size":
        phase.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=1.0)
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True, "value": 1.0,
                     "LGmix": {"value": 1.0, "refine": False}}
        }, [hist])
    else:
        phase.setSampleProfile(hist, "microstrain", "isotropic", 100.0, LGmix=1.0)
        phase.set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "refine": True,
                         "LGmix": {"value": 1.0, "refine": False}}
        }, [hist])
    gpx.set_Controls("cycles", 12)
    gpx.save()
    listing = Path(args.out).with_suffix(".lst")
    for _ in range(3):
        gpx.refine(printFile=str(listing))
        gpx.reload()
    gpx.save()

    hist = gpx.histogram(0)
    phase = gpx.phase(PHASES[args.phase])
    cov = gpx.data["Covariance"]["data"]
    matching = {
        str(v): [float(value), float(esd)]
        for v, value, esd in zip(cov["varyList"], cov["variables"], cov["sig"])
        if ("Size" in str(v) or "Mustrain" in str(v))
    }
    print(json.dumps({
        "phase": phase.name,
        "term": args.term,
        "Rwp": hist.get_wR(),
        "GOF": cov["Rvals"]["GOF"],
        "size": phase.getHAPvalues(hist)["Size"],
        "mustrain": phase.getHAPvalues(hist)["Mustrain"],
        "matching_variables": matching,
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": gpx.get_Frozen(),
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
