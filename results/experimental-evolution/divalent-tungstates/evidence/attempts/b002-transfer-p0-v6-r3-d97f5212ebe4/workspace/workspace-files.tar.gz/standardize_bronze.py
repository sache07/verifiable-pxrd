#!/usr/bin/env python3
"""Write the Ba-W bronze COD record in a GSAS-II-compatible standard setting."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


SOURCE = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/00/12/1001273.cif")
structure = Structure.from_file(SOURCE)
standard = SpacegroupAnalyzer(structure, symprec=1e-3).get_conventional_standard_structure()
CifWriter(standard, symprec=1e-3).write_file("bronze_standard_symmetry.cif")
