#!/usr/bin/env python3
"""Refine ordered BaWO4 oxygen coordinates with a tetrahedral W--O restraint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def init_phase_restraints(gpx: G2sc.G2Project, name: str) -> None:
    gpx.data["Restraints"]["data"][name] = {
        "Bond": {"wtFactor": 1.0, "Range": 1.2, "Bonds": [], "Use": True},
        "Angle": {"wtFactor": 1.0, "Range": 0.85, "Angles": [], "Use": True},
        "Plane": {"wtFactor": 1.0, "Planes": [], "Use": True},
        "Chiral": {"wtFactor": 1.0, "Volumes": [], "Use": True},
        "Torsion": {"wtFactor": 1.0, "Coeff": {}, "Torsions": [], "Use": True},
        "Rama": {"wtFactor": 1.0, "Coeff": {}, "Ramas": [], "Use": True},
        "Texture": {"wtFactor": 1.0, "HKLs": [], "Use": True},
        "ChemComp": {"wtFactor": 1.0, "Sites": [], "Use": True},
        "General": {"wtFactor": 1.0, "General": [], "Use": True},
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("--out", required=True)
    parser.add_argument("--cif", required=True)
    parser.add_argument("--weight", type=float, required=True)
    parser.add_argument("--target", type=float, default=1.82)
    parser.add_argument("--esd", type=float, default=0.02)
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.project)
    gpx.save(args.out)
    phase = gpx.phase("BaWO4")
    init_phase_restraints(gpx, phase.name)
    tungsten = [atom for atom in phase.atoms() if atom.element == "W"]
    oxygen = [atom for atom in phase.atoms() if atom.element == "O"]
    count = phase.addDistRestraint(
        tungsten, oxygen, args.target, factor=1.2, ESD=args.esd
    )
    phase.setDistRestraintWeight(args.weight)
    oxygen[0].refinement_flags = "X"
    gpx.set_Controls("cycles", 16)
    gpx.save()

    for _ in range(3):
        gpx.refine(printFile=str(Path(args.out).with_suffix(".lst")))
        gpx.reload()
    gpx.save()
    phase = gpx.phase("BaWO4")
    phase.export_CIF(args.cif)
    hist = gpx.histogram(0)
    rvals = gpx.data["Covariance"]["data"]["Rvals"]
    print(json.dumps({
        "restraints_added": count,
        "restraint_weight": args.weight,
        "Rwp": hist.get_wR(),
        "GOF": rvals["GOF"],
        "restraint_sum": rvals.get("RestraintSum"),
        "restraint_terms": rvals.get("RestraintTerms"),
        "oxygen": [atom.coordinates for atom in phase.atoms() if atom.element == "O"],
        "cell": phase.get_cell(),
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": gpx.get_Frozen(),
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
