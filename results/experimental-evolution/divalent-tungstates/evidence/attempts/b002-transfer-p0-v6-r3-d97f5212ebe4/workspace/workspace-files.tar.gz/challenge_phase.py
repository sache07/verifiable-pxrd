#!/usr/bin/env python3
"""Add one watch-list phase to a converged common-profile project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import cod_path, neutralize_hap


CANDIDATES = {
    "baco3": ("9010928", "BaCO3"),
    "ba3wo6": ("1534803", "Ba3WO6"),
    "bronze": ("1001273", "Ba0.15WO3"),
}


def refine_replay(gpx: G2sc.G2Project, listing: Path) -> None:
    gpx.refine(printFile=str(listing))
    gpx.reload()
    gpx.refine(printFile=str(listing))
    gpx.reload()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", choices=sorted(CANDIDATES))
    parser.add_argument("--base", default="compare_cawo_2311041.gpx")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    cod_id, name = CANDIDATES[args.candidate]
    gpx = G2sc.G2Project(args.base)
    gpx.save(args.out)
    hist = gpx.histogram(0)
    source = Path(__file__).resolve().parent / "bronze_standard_symmetry.cif" \
        if args.candidate == "bronze" else cod_path(cod_id)
    phase = gpx.add_phase(
        str(source), phasename=name, histograms=[hist], fmthint="CIF"
    )
    neutralize_hap(phase, hist)
    phase.HAPvalue("Scale", 0.01)
    phase.set_HAP_refinements({"Scale": True}, [hist])
    gpx.set_Controls("parmMin", 0.0, f"{phase.id}:0:Scale")
    gpx.set_Controls("cycles", 12)
    gpx.save()

    listing = Path(args.out).with_suffix(".lst")
    refine_replay(gpx, listing)
    phase = gpx.phase(name)
    scale_stage = phase.HAPvalue("Scale", targethistlist=[gpx.histogram(0)])
    frozen_stage = gpx.get_Frozen()

    # A positive candidate is allowed to adjust its cell before final judgment.
    if scale_stage > 1e-8 and f"{phase.id}:0:Scale" not in frozen_stage:
        phase.set_refinements({"Cell": True})
        refine_replay(gpx, listing)

    gpx.save()
    hist = gpx.histogram(0)
    phase = gpx.phase(name)
    rvals = gpx.data["Covariance"]["data"]["Rvals"]
    mass = hist.ComputeMassFracs()
    print(json.dumps({
        "candidate": name,
        "Rwp": hist.get_wR(),
        "GOF": rvals["GOF"],
        "scale_after_fixed_cell": scale_stage,
        "scale_final": phase.HAPvalue("Scale", targethistlist=[hist]),
        "cell_final": phase.get_cell(),
        "mass_fractions": mass,
        "candidate_mass_fraction": mass.get(name),
        "frozen_after_fixed_cell": frozen_stage,
        "frozen_final": gpx.get_Frozen(),
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
