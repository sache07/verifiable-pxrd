#!/usr/bin/env python3
"""Challenge ordered BaWO4 prototype starts by refining the unique O position."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("--out", required=True)
    parser.add_argument("--cif", required=True)
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.project)
    gpx.save(args.out)
    phase = gpx.phase("BaWO4")
    oxygen = [atom for atom in phase.atoms() if atom.element == "O"]
    if len(oxygen) != 1:
        raise RuntimeError(f"Expected one ordered oxygen site, found {len(oxygen)}")
    oxygen[0].refinement_flags = "X"
    gpx.set_Controls("cycles", 16)

    for replay in range(3):
        gpx.refine(printFile=str(Path(args.out).with_suffix(".lst")))
        gpx.reload()
    gpx.save()
    phase = gpx.phase("BaWO4")
    phase.export_CIF(args.cif)
    hist = gpx.histogram(0)
    print(json.dumps({
        "Rwp": hist.get_wR(),
        "GOF": gpx.data["Covariance"]["data"]["Rvals"]["GOF"],
        "oxygen": [atom.coordinates for atom in phase.atoms() if atom.element == "O"],
        "cell": phase.get_cell(),
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": gpx.get_Frozen(),
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
