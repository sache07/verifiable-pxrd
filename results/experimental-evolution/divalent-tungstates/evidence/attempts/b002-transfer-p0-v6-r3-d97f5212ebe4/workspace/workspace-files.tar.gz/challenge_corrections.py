#!/usr/bin/env python3
"""Challenge polarization or low-angle roughness against the combined baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["polarization", "roughness"])
    parser.add_argument("--base", default="combined_broadening.gpx")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.base)
    gpx.save(args.out)
    hist = gpx.histogram(0)
    if args.mode == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
        gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")
    else:
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"][0] = 0.01
        sample["SurfRoughB"][0] = 0.10
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        for name in ["SurfRoughA", "SurfRoughB"]:
            gpx.set_Controls("parmMin", 0.0, f":0:{name}")
            gpx.set_Controls("parmMax", 2.0, f":0:{name}")
    gpx.set_Controls("cycles", 16)
    gpx.save()
    listing = Path(args.out).with_suffix(".lst")
    for _ in range(4):
        gpx.refine(printFile=str(listing))
        gpx.reload()
    gpx.save()

    hist = gpx.histogram(0)
    cov = gpx.data["Covariance"]["data"]
    matching = {
        str(v): [float(value), float(esd)]
        for v, value, esd in zip(cov["varyList"], cov["variables"], cov["sig"])
        if any(key in str(v) for key in ["Polariz", "SurfRough"])
    }
    print(json.dumps({
        "mode": args.mode,
        "Rwp": hist.get_wR(),
        "GOF": cov["Rvals"]["GOF"],
        "variables": matching,
        "polarization": hist.data["Instrument Parameters"][0]["Polariz."],
        "surface_roughness": {
            key: hist.data["Sample Parameters"][key]
            for key in ["SurfRoughA", "SurfRoughB"]
        },
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": gpx.get_Frozen(),
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
