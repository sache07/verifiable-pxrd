#!/usr/bin/env python3
"""Build comparable baseline GSAS-II refinements for structural-record trials."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize_hap(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData) -> None:
    """Set all unused sample broadening and intensity corrections to neutral values."""
    phase.setSampleProfile(hist, "size", "isotropic", 1.0e6, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap = phase.getHAPvalues(hist)
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"][0] = 0.0
    hap["Extinction"][1] = False
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]
    phase.clear_HAP_refinements(
        {"Size": False, "Mustrain": False, "HStrain": False,
         "Pref.Ori.": False, "Extinction": False,
         "Babinet": ["BabA", "BabU"]},
        [hist],
    )


def set_cell(phase: G2sc.G2Phase, cell: list[float]) -> None:
    from GSASII import GSASIIlattice as G2lat

    phase.data["General"]["Cell"][1:7] = cell
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def add_bawo4(gpx: G2sc.G2Project, hist: G2sc.G2PwdrData, model: str) -> G2sc.G2Phase:
    if model == "exact":
        phase = gpx.add_phase(
            str(cod_path("1527204")), phasename="BaWO4", histograms=[hist], fmthint="CIF"
        )
    else:
        parents = {
            "bamo": ("2300459", "Mo"),
            "srwo": ("1546036", "Sr"),
            "cawo": ("7219229", "Ca"),
        }
        cod_id, replace_element = parents[model]
        phase = gpx.add_phase(
            str(cod_path(cod_id)), phasename="BaWO4", histograms=[hist], fmthint="CIF"
        )
        for atom in phase.atoms():
            if atom.element == replace_element:
                atom.type = "Ba" if replace_element in {"Sr", "Ca"} else "W"
                atom.label = "Ba1" if replace_element in {"Sr", "Ca"} else "W1"
        # SrWO4 and CaWO4 parents already contain W; BaMoO4 needs only Mo -> W.
        G2sc.SetupGeneral(phase.data, None)
        set_cell(phase, [5.614, 5.614, 12.719, 90.0, 90.0, 90.0])
        G2sc.SetupGeneral(phase.data, None)
    # Use the same physically modest room-temperature starting ADPs for every
    # structural-record trial so record selection is not driven by source ADPs.
    for atom in phase.atoms():
        atom.uiso = 0.010 if atom.element == "O" else 0.005
    return phase


def stage(gpx: G2sc.G2Project, label: str, replay: bool = True) -> dict:
    """Refine, reopen, and optionally replay the active full-range model."""
    gpx.refine(printFile=str(ROOT / f"{Path(gpx.filename).stem}.lst"))
    gpx.reload()
    if replay:
        gpx.refine(printFile=str(ROOT / f"{Path(gpx.filename).stem}.lst"))
        gpx.reload()
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    result = {
        "stage": label,
        "Rwp": hist.get_wR(),
        "GOF": gpx.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "zero": inst["Zero"][1],
        "U": inst["U"][1],
        "V": inst["V"][1],
        "W": inst["W"][1],
        "X": inst["X"][1],
        "Y": inst["Y"][1],
        "SH/L": inst["SH/L"][1],
        "cells": {p.name: p.get_cell() for p in gpx.phases()},
        "scales": {p.name: p.HAPvalue("Scale", targethistlist=[hist]) for p in gpx.phases()},
        "frozen": gpx.get_Frozen(),
    }
    print("STAGE", json.dumps(result, sort_keys=True))
    return result


def build(model: str, wo3_id: str, out: Path) -> tuple[G2sc.G2Project, list[dict]]:
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"), str(ROOT / "instrument.instprm"),
        fmthint="comma/tab/semicolon",
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    # Peak matching gives a common initial offset near +0.23 deg. Starting here
    # prevents weak-phase scales from being rejected before the zero correction
    # and cells are released together.
    hist.data["Instrument Parameters"][0]["Zero"][1] = 0.23
    hist.data["Sample Parameters"]["Scale"][1] = False

    phases = [
        add_bawo4(gpx, hist, model),
        gpx.add_phase(str(cod_path("1533878")), phasename="Ba3W2O9", histograms=[hist], fmthint="CIF"),
        gpx.add_phase(str(cod_path(wo3_id)), phasename="WO3", histograms=[hist], fmthint="CIF"),
    ]
    for i, phase in enumerate(phases):
        neutralize_hap(phase, hist)
        phase.HAPvalue("Scale", [1.0, 0.20, 0.08][i])
        gpx.set_Controls("parmMin", 0.0, f"{i}:0:Scale")

    # Nonnegative, low-dimensional common profile. V and Y remain fixed at zero.
    for name, upper in [("U", 500.0), ("W", 500.0), ("X", 100.0), ("SH/L", 1.0)]:
        gpx.set_Controls("parmMin", 0.0 if name != "SH/L" else 0.002, f":0:{name}")
        gpx.set_Controls("parmMax", upper, f":0:{name}")
    gpx.set_Controls("parmMin", -1.0, ":0:Zero")
    gpx.set_Controls("parmMax", 1.0, ":0:Zero")
    gpx.set_Controls("cycles", 12)
    gpx.save()

    results: list[dict] = []
    hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 6, "refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    results.append(stage(gpx, "background_scales"))

    hist = gpx.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    results.append(stage(gpx, "zero_cells"))

    hist = gpx.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["W"]})
    results.append(stage(gpx, "profile_W"))

    hist = gpx.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["X"]})
    results.append(stage(gpx, "profile_WX"))
    gpx.save()
    return gpx, results


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bawo4", choices=["exact", "bamo", "srwo", "cawo"], default="bamo")
    parser.add_argument("--wo3", choices=["1528915", "2311041", "2106293"], default="2311041")
    parser.add_argument("--out")
    args = parser.parse_args()
    out = ROOT / (args.out or f"trial_{args.bawo4}_{args.wo3}.gpx")
    _, results = build(args.bawo4, args.wo3, out)
    print("SUMMARY", json.dumps(results, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
