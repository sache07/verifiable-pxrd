#!/usr/bin/env python3
"""Replay a physically credible ordered witherite coordinate record."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


# COD 1011149 is in the same #62 axis setting but a different origin from the
# accepted P m c n phase. The transform into the current GSAS-II setting is
# (x, y, z) -> (x + 1/4, y, z + 3/4), modulo one.
OLD_WITHERITE = {
    "Ba": (0.250, 0.417, 0.752),
    "C": (0.250, 0.750, -0.095),
    "O1": (0.250, 0.889, -0.095),
    "O2": (0.452, 0.680, -0.095),
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("--out", required=True)
    parser.add_argument("--cif", required=True)
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.project)
    gpx.save(args.out)
    phase = gpx.phase("BaCO3")
    atoms = {atom.label: atom for atom in phase.atoms()}
    if set(atoms) != set(OLD_WITHERITE):
        raise RuntimeError(f"Unexpected BaCO3 labels: {sorted(atoms)}")
    for label, xyz in OLD_WITHERITE.items():
        atoms[label].coordinates = xyz
        atoms[label].refinement_flags = ""
    gpx.set_Controls("cycles", 16)
    gpx.save()
    for _ in range(3):
        gpx.refine(printFile=str(Path(args.out).with_suffix(".lst")))
        gpx.reload()
    gpx.save()

    phase = gpx.phase("BaCO3")
    phase.export_CIF(args.cif)
    hist = gpx.histogram(0)
    rvals = gpx.data["Covariance"]["data"]["Rvals"]
    print(json.dumps({
        "Rwp": hist.get_wR(),
        "GOF": rvals["GOF"],
        "cell": phase.get_cell(),
        "coordinates": {atom.label: atom.coordinates for atom in phase.atoms()},
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": gpx.get_Frozen(),
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
