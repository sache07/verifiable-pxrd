#!/usr/bin/env python3
"""Screen March-Dollase axes for the dominant MgWO4 phase."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
BASE = TMP / "profile_WY.gpx"


def refine(project, times=3):
    for _ in range(times):
        project.do_refinements([{}])


def run(axis):
    tag = "".join(str(i).replace("-", "m") for i in axis)
    out = TMP / f"texture_mgwo4_{tag}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    project.set_Controls("cycles", 20)
    phase = project.phase("MgWO4_wolframite")
    hist = project.histogram(0)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(axis)
    project.set_Controls("parmMin", 0.2, variable="0:0:MD")
    project.set_Controls("parmMax", 5.0, variable="0:0:MD")
    refine(project)
    project.save()
    cov = project.data["Covariance"]["data"]["Rvals"]
    return {
        "axis": axis,
        "MD": po[1],
        "Rwp_percent": hist.get_wR(),
        "GOF": cov.get("GOF"),
        "converged": cov.get("converged"),
        "svd_zeros": cov.get("SVD0"),
        "message": cov.get("msg", ""),
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
    }


def main():
    axes = [[1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 0], [1, 0, 1], [0, 1, 1]]
    results = [run(axis) for axis in axes]
    with (TMP / "texture_results.json").open("w") as handle:
        json.dump(results, handle, indent=2)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
