#!/usr/bin/env python3
"""Build and refine a three-phase GSAS-II model for the supplied PXRD data."""

from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
GPX = TMP / "trial.gpx"
XYE = TMP / "pattern.xye"
IPRM = TMP / "cu_ka.instprm"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def show_state(project, label):
    hist = project.histogram(0)
    print(f"\n=== {label} ===")
    print("wR", hist.get_wR())
    print("GOF", project.data["Covariance"]["data"].get("Rvals", {}).get("GOF"))
    print("inst", hist.data["Instrument Parameters"][0])
    print("sample", hist.data["Sample Parameters"])
    print("background", hist.data["Background"][0])
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, "cell", phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"], "mustrain", hap["Mustrain"])
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass fractions unavailable", repr(exc))


def main():
    if GPX.exists():
        GPX.unlink()
    project = G2sc.G2Project(newgpx=str(GPX))
    hist = project.add_powder_histogram(str(XYE), str(IPRM), fmthint="xye")
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 10,
            "coeffs": [3450.0] + [0.0] * 9,
        },
    })

    specs = [
        ("MgWO4_wolframite", "9013902"),
        ("WO3_monoclinic", "1528915"),
        ("MgO_periclase", "9000499"),
    ]
    phases = []
    for name, cod_id in specs:
        phase = project.add_phase(
            str(cod_cif(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
        )
        phases.append(phase)

    # Put all phase scales in a sensible range before the first fit.
    initial_scales = [1.0, 0.15, 0.05]
    for phase, scale in zip(phases, initial_scales):
        phase.data["Histograms"][hist.name]["Scale"][0] = scale
        phase.set_HAP_refinements({"Scale": True})

    project.data["Controls"]["data"]["max cyc"] = 12
    project.save()
    project.do_refinements([{}])
    show_state(project, "scales + background")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.do_refinements([{}])
    show_state(project, "add cells")

    hist.set_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y"]})
    project.do_refinements([{}])
    show_state(project, "add instrument profile")

    # A final pass with independent isotropic size and microstrain terms tests
    # whether phase-dependent broadening is needed.
    for phase in phases:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 1.0, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    project.do_refinements([{}])
    show_state(project, "add phase broadening")
    project.save()

    cov = project.data["Covariance"]["data"]
    summary = {
        "Rvals": cov.get("Rvals", {}),
        "varyList": [str(v) for v in cov.get("varyList", [])],
        "variables": [float(v) for v in cov.get("variables", [])],
        "sig": [float(v) for v in cov.get("sig", [])],
    }
    print(json.dumps(summary, indent=2, default=str))


if __name__ == "__main__":
    main()
