#!/usr/bin/env python3
"""Screen March-Dollase axes for monoclinic WO3 after MgWO4 texture fit."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
BASE = TMP / "texture_mgwo4_010.gpx"


def run(axis):
    tag = "".join(str(i).replace("-", "m") for i in axis)
    out = TMP / f"texture_wo3_{tag}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    project.set_Controls("cycles", 20)
    phase = project.phase("WO3_monoclinic")
    hist = project.histogram(0)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", 1.0, True, list(axis)
    project.set_Controls("parmMin", 0.2, variable="1:0:MD")
    project.set_Controls("parmMax", 5.0, variable="1:0:MD")
    for _ in range(3):
        project.do_refinements([{}])
    project.save()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    return {
        "axis": axis,
        "MD": po[1],
        "Rwp_percent": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "svd_zeros": rvals.get("SVD0"),
        "message": rvals.get("msg", ""),
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
    }


def main():
    axes = [[1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 0], [1, 0, 1], [0, 1, 1]]
    results = [run(axis) for axis in axes]
    with (TMP / "wo3_texture_results.json").open("w") as handle:
        json.dump(results, handle, indent=2)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
