#!/usr/bin/env python3
"""Compare stable GSAS-II profile models after a common base refinement."""

from pathlib import Path
import json
import math
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
XYE = TMP / "pattern.xye"
IPRM = TMP / "cu_ka.instprm"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def refine(project, times=1):
    for _ in range(times):
        project.do_refinements([{}])


def build_base():
    path = TMP / "profile_base.gpx"
    if path.exists():
        path.unlink()
    project = G2sc.G2Project(newgpx=str(path))
    hist = project.add_powder_histogram(str(XYE), str(IPRM), fmthint="xye")
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 10,
            "coeffs": [3450.0] + [0.0] * 9,
        },
    })
    # Fix the histogram-wide multiplier; only phase scales are varied. This
    # removes the exact scale degeneracy while preserving quantitative ratios.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]

    specs = [
        ("MgWO4_wolframite", "9013902", 80.0),
        ("WO3_monoclinic", "1528915", 15.0),
        ("MgO_periclase", "9000499", 4.0),
    ]
    for name, cod_id, scale in specs:
        phase = project.add_phase(
            str(cod_cif(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
        )
        phase.data["Histograms"][hist.name]["Scale"][0] = scale
        phase.set_HAP_refinements({"Scale": True})

    project.set_Controls("cycles", 16)
    project.save()
    refine(project, 2)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, 3)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, 2)
    project.save()
    return path


def profile_validity(inst):
    pos = np.linspace(10.0, 100.0, 901)
    theta = np.deg2rad(pos / 2.0)
    t = np.tan(theta)
    sig = inst["U"][1] * t**2 + inst["V"][1] * t + inst["W"][1]
    gam = inst["X"][1] / np.cos(theta) + inst["Y"][1] * t + inst["Z"][1]
    return {
        "sigma2_min": float(sig.min()),
        "sigma2_max": float(sig.max()),
        "gamma_min": float(gam.min()),
        "gamma_max": float(gam.max()),
        "valid": bool(np.all(sig > 0) and np.all(gam >= 0)),
    }


def collect(project, tag):
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    inst = hist.data["Instrument Parameters"][0]
    fractions = hist.ComputeMassFracs()
    return {
        "tag": tag,
        "Rwp_percent": float(hist.get_wR()),
        "GOF": float(cov["Rvals"]["GOF"]),
        "converged": bool(cov["Rvals"].get("converged", False)),
        "svd_zeros": int(cov["Rvals"].get("SVD0", 0)),
        "message": cov["Rvals"].get("msg", ""),
        "profile": {k: float(v[1]) for k, v in inst.items() if k in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]},
        "profile_validity": profile_validity(inst),
        "fractions": {k: [float(v[0]), float(v[1])] for k, v in fractions.items()},
        "cells": {p.name: p.get_cell() for p in project.phases()},
    }


def run_variant(base, tag, params, limits=None, extras=None):
    out = TMP / f"profile_{tag}.gpx"
    project = G2sc.G2Project(str(base), newgpx=str(out))
    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": params})
    if limits:
        for variable, (lo, hi) in limits.items():
            if lo is not None:
                project.set_Controls("parmMin", lo, variable=variable)
            if hi is not None:
                project.set_Controls("parmMax", hi, variable=variable)
    project.set_Controls("cycles", 20)
    refine(project, 3)
    if extras:
        extras(project)
        refine(project, 3)
    project.save()
    return collect(project, tag)


def add_polarization(project):
    project.histogram(0).set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")


def add_shl(project):
    project.histogram(0).set_refinements({"Instrument Parameters": ["SH/L"]})
    project.set_Controls("parmMin", 0.002, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.2, variable=":0:SH/L")


def main():
    base = build_base()
    common_positive = {
        ":0:U": (0.0, 1000.0),
        ":0:W": (0.001, 1000.0),
        ":0:X": (0.0, 1000.0),
        ":0:Y": (0.0, 1000.0),
    }
    variants = [
        ("WY", ["W", "Y"], {k: common_positive[k] for k in [":0:W", ":0:Y"]}, None),
        ("UWY", ["U", "W", "Y"], {k: common_positive[k] for k in [":0:U", ":0:W", ":0:Y"]}, None),
        ("UWX", ["U", "W", "X"], {k: common_positive[k] for k in [":0:U", ":0:W", ":0:X"]}, None),
        ("UWXY", ["U", "W", "X", "Y"], common_positive, None),
        ("UWY_pol", ["U", "W", "Y"], {k: common_positive[k] for k in [":0:U", ":0:W", ":0:Y"]}, add_polarization),
        ("UWY_shl", ["U", "W", "Y"], {k: common_positive[k] for k in [":0:U", ":0:W", ":0:Y"]}, add_shl),
    ]
    results = [run_variant(base, *variant) for variant in variants]
    with (TMP / "profile_results.json").open("w") as handle:
        json.dump(results, handle, indent=2)
    print("PROFILE_RESULTS")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
