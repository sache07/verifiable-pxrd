#!/usr/bin/env python3
"""Create the final GSAS-II project and all machine-readable deliverables."""

from pathlib import Path
import csv
import json
import math

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
XYE = TMP / "pattern.xye"
IPRM = TMP / "cu_ka.instprm"
WORK_GPX = TMP / "final_work.gpx"
FINAL_GPX = ROOT / "final.gpx"
FIT_CSV = ROOT / "fit.csv"
RESULT_JSON = ROOT / "result.json"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


PHASE_SPECS = [
    {
        "name": "MgWO4_wolframite",
        "display_name": "MgWO4 (wolframite-type)",
        "formula": "MgWO4",
        "cod_id": "9013902",
        "initial_scale": 80.0,
        "cif": ROOT / "MgWO4.cif",
    },
    {
        "name": "WO3_monoclinic",
        "display_name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cod_id": "2311041",
        "initial_scale": 19.0,
        "cif": ROOT / "WO3.cif",
    },
    {
        "name": "MgO_periclase",
        "display_name": "MgO (periclase)",
        "formula": "MgO",
        "cod_id": "9000499",
        "initial_scale": 39.0,
        "cif": ROOT / "MgO.cif",
    },
]


def cod_cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def refine(project, times):
    for _ in range(times):
        project.do_refinements([{}])


def build_project():
    if WORK_GPX.exists():
        WORK_GPX.unlink()
    project = G2sc.G2Project(newgpx=str(WORK_GPX))
    hist = project.add_powder_histogram(str(XYE), str(IPRM), fmthint="xye")
    x = np.asarray(hist.getdata("X"), dtype=float)
    hist.set_refinements({
        "Limits": [float(x[0]), float(x[-1])],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 10,
            "coeffs": [3450.0] + [0.0] * 9,
        },
    })

    # Fix the histogram-wide scale to remove the exact gauge freedom between
    # it and the three phase scales.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]

    for spec in PHASE_SPECS:
        phase = project.add_phase(
            str(cod_cif(spec["cod_id"])),
            phasename=spec["name"],
            histograms=[hist],
            fmthint="CIF",
        )
        phase.data["Histograms"][hist.name]["Scale"][0] = spec["initial_scale"]
        phase.set_HAP_refinements({"Scale": True})

    project.set_Controls("cycles", 20)
    project.save()

    # Stable staged refinement: scales/background, unit cells, zero/profile,
    # MgWO4 texture + WO3 broadening, then effective polarization.
    refine(project, 2)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, 3)

    hist.set_refinements({"Instrument Parameters": ["Zero", "W"]})
    project.set_Controls("parmMin", 0.001, variable=":0:W")
    project.set_Controls("parmMax", 1000.0, variable=":0:W")
    refine(project, 2)

    mgwo4 = project.phase("MgWO4_wolframite")
    po = mgwo4.data["Histograms"][hist.name]["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", 1.0, True, [0, 1, 0]
    project.set_Controls("parmMin", 0.2, variable="0:0:MD")
    project.set_Controls("parmMax", 5.0, variable="0:0:MD")

    wo3 = project.phase("WO3_monoclinic")
    wo3.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    project.set_Controls("parmMin", 0.1, variable="1:0:Mustrain;i")
    project.set_Controls("parmMax", 20000.0, variable="1:0:Mustrain;i")
    refine(project, 3)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    refine(project, 3)

    # Save the exact state used below for CIF, profile, and fraction export.
    project.save(str(FINAL_GPX))
    return project


def export_outputs(project):
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"]["Rvals"]
    if not rvals.get("converged", False):
        raise RuntimeError("Final refinement did not converge")
    if rvals.get("SVD0", 0):
        raise RuntimeError(f"Final refinement has {rvals['SVD0']} SVD singularities")
    if project.get_Frozen():
        raise RuntimeError(f"Final refinement has frozen variables: {project.get_Frozen()}")

    fractions = hist.ComputeMassFracs()
    x = np.asarray(hist.getdata("X"), dtype=float)
    yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    bkg = np.asarray(hist.getdata("Background"), dtype=float)
    diff = yobs - ycalc
    weight = np.asarray(hist.getdata("Yweight"), dtype=float)

    with FIT_CSV.open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "two_theta_deg",
            "observed_intensity",
            "calculated_intensity",
            "difference_intensity",
            "background_intensity",
        ])
        for row in zip(x, yobs, ycalc, diff, bkg):
            writer.writerow([f"{row[0]:.8f}"] + [f"{value:.8f}" for value in row[1:]])

    phase_records = []
    for spec in PHASE_SPECS:
        phase = project.phase(spec["name"])
        phase.export_CIF(str(spec["cif"]))
        frac, frac_esd = fractions[spec["name"]]
        phase_records.append({
            "name": spec["display_name"],
            "formula": spec["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "cif_path": spec["cif"].name,
            "weight_fraction": float(frac),
            "weight_fraction_esd": float(frac_esd),
            "weight_percent": float(100.0 * frac),
            "weight_percent_esd": float(100.0 * frac_esd),
            "reference_cod_id": spec["cod_id"],
        })

    rp = 100.0 * float(np.sum(np.abs(diff)) / np.sum(np.abs(yobs)))
    rwp = float(rvals["Rwp"])
    gof = float(rvals["GOF"])
    rexp = rwp / gof
    reduced_chi_square = gof * gof
    result = {
        "phases": phase_records,
        "weight_fraction_normalization": "modeled crystalline phases only; sum = 1",
        "fit_statistics": {
            "Rp_percent": rp,
            "Rwp_percent": rwp,
            "Rexp_percent": rexp,
            "goodness_of_fit": gof,
            "reduced_chi_square": reduced_chi_square,
            "chi_square": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
            "converged": bool(rvals["converged"]),
            "svd_singularities": int(rvals.get("SVD0", 0)),
            "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
            "weighting": "Poisson counting approximation, w = 1/I, because pointwise uncertainties were not supplied",
        },
        "files": {
            "gsasii_project": FINAL_GPX.name,
            "fit_profile": FIT_CSV.name,
        },
    }
    with RESULT_JSON.open("w") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")

    print(json.dumps(result, indent=2))


def main():
    project = build_project()
    export_outputs(project)


if __name__ == "__main__":
    main()
