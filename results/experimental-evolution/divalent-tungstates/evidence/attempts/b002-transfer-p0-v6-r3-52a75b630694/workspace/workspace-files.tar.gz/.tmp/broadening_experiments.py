#!/usr/bin/env python3
"""Test limited phase broadening and polarization additions."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
BASE = TMP / "texture_mgwo4_010.gpx"


def configure(project, kind):
    hist = project.histogram(0)
    wo3 = project.phase("WO3_monoclinic")
    if "pol" in kind:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    if "size" in kind:
        wo3.set_HAP_refinements({"Size": {"type": "isotropic", "value": 1.0, "refine": True}})
        project.set_Controls("parmMin", 0.01, variable="1:0:Size;i")
        project.set_Controls("parmMax", 100.0, variable="1:0:Size;i")
    if "strain" in kind:
        wo3.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        project.set_Controls("parmMin", 0.1, variable="1:0:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, variable="1:0:Mustrain;i")


def run(kind):
    out = TMP / f"broadening_{kind}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    project.set_Controls("cycles", 20)
    configure(project, kind)
    for _ in range(3):
        project.do_refinements([{}])
    project.save()
    hist = project.histogram(0)
    wo3_hap = project.phase("WO3_monoclinic").data["Histograms"][hist.name]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    return {
        "kind": kind,
        "Rwp_percent": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "svd_zeros": rvals.get("SVD0"),
        "message": rvals.get("msg", ""),
        "frozen": project.get_Frozen(),
        "polarization": hist.data["Instrument Parameters"][0]["Polariz."][1],
        "wo3_size": wo3_hap["Size"],
        "wo3_mustrain": wo3_hap["Mustrain"],
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
    }


def main():
    kinds = ["pol", "size", "strain", "size_strain", "pol_size", "pol_strain", "pol_size_strain"]
    results = [run(kind) for kind in kinds]
    with (TMP / "broadening_results.json").open("w") as handle:
        json.dump(results, handle, indent=2)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
