#!/usr/bin/env python3
"""Rietveld comparison of locally available WO3 structure models."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
XYE = TMP / "pattern.xye"
IPRM = TMP / "cu_ka.instprm"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def refine(project, times=2):
    for _ in range(times):
        project.do_refinements([{}])


def run(cod_id):
    out = TMP / f"wo3_model_{cod_id}.gpx"
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(str(XYE), str(IPRM), fmthint="xye")
    xmin = float(hist.getdata("X")[0])
    xmax = float(hist.getdata("X")[-1])
    hist.set_refinements({
        "Limits": [xmin, xmax],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 10,
            "coeffs": [3450.0] + [0.0] * 9,
        },
    })
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    specs = [
        ("MgWO4_wolframite", "9013902", 80.0),
        ("WO3_candidate", cod_id, 15.0),
        ("MgO_periclase", "9000499", 4.0),
    ]
    for name, phase_id, scale in specs:
        phase = project.add_phase(
            str(cod_cif(phase_id)), phasename=name, histograms=[hist], fmthint="CIF"
        )
        phase.data["Histograms"][hist.name]["Scale"][0] = scale
        phase.set_HAP_refinements({"Scale": True})
    project.set_Controls("cycles", 20)
    project.save()
    refine(project, 2)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, 3)
    hist.set_refinements({"Instrument Parameters": ["Zero", "W"]})
    project.set_Controls("parmMin", 0.001, variable=":0:W")
    project.set_Controls("parmMax", 1000.0, variable=":0:W")
    refine(project, 2)

    mgwo4 = project.phase("MgWO4_wolframite")
    po = mgwo4.data["Histograms"][hist.name]["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", 1.0, True, [0, 1, 0]
    project.set_Controls("parmMin", 0.2, variable="0:0:MD")
    project.set_Controls("parmMax", 5.0, variable="0:0:MD")

    wo3 = project.phase("WO3_candidate")
    wo3.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    project.set_Controls("parmMin", 0.1, variable="1:0:Mustrain;i")
    project.set_Controls("parmMax", 20000.0, variable="1:0:Mustrain;i")
    refine(project, 3)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    refine(project, 3)
    project.save()

    rvals = project.data["Covariance"]["data"]["Rvals"]
    wo3_hap = wo3.data["Histograms"][hist.name]
    return {
        "cod_id": cod_id,
        "space_group": wo3.data["General"]["SGData"]["SpGrp"],
        "Rwp_percent": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "svd_zeros": rvals.get("SVD0"),
        "message": rvals.get("msg", ""),
        "frozen": project.get_Frozen(),
        "wo3_mustrain": wo3_hap["Mustrain"][1][0],
        "polarization": hist.data["Instrument Parameters"][0]["Polariz."][1],
        "mgwo4_MD": po[1],
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "wo3_cell": wo3.get_cell(),
    }


def main():
    ids = ["1528915", "2311041", "2106293", "1010618", "2107312", "1563541"]
    results = []
    for cod_id in ids:
        try:
            results.append(run(cod_id))
        except Exception as exc:
            results.append({"cod_id": cod_id, "error": repr(exc)})
    with (TMP / "wo3_structure_results.json").open("w") as handle:
        json.dump(results, handle, indent=2)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
