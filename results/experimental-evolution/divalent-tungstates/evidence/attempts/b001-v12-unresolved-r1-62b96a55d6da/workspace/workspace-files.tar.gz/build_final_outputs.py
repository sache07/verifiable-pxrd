#!/usr/bin/env python3
"""Prune, replay, and export the final GSAS-II quantitative phase model."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from context_texture_challenges import md_diagnostics
from term_challenges import global_terms, metric, phase_terms


SOURCE = Path("trials/checkpoints/11_common_U_W_X_replay.gpx")
PROJECT = Path("final.gpx")
PHASE_OUTPUTS = {
    "SrWO4_scheelite": ("SrWO4", "phase_1_SrWO4.cif"),
    "WO3_monoclinic": ("WO3", "phase_2_WO3.cif"),
    "SrCO3_orthorhombic": ("SrCO3", "phase_3_SrCO3.cif"),
}


def neutral_size(hap) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 0.5]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])


def neutral_other_hap(hap) -> None:
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Extinction"][:] = [0.0, False]
    for key in ("BabA", "BabU"):
        hap["Babinet"][key][:] = [0.0, False]


def prune(project) -> None:
    hist = project.histogram(0)
    hist.data["Limits"][1][:] = [9.90343322, 100.09455322]
    sample = hist.data["Sample Parameters"]
    sample["Scale"][:] = [1.0, False]
    sample["Shift"][1] = True
    sample["Transparency"][:] = [0.0, False]
    sample["SurfRoughA"][:] = [0.0, False]
    sample["SurfRoughB"][:] = [0.0, False]

    instrument = hist.data["Instrument Parameters"][0]
    for key in ("U", "W", "X", "Polariz."):
        instrument[key][2] = True
    for key, value in (("V", 0.0), ("Y", 0.0), ("SH/L", 0.002)):
        instrument[key][1] = value
        instrument[key][2] = False

    # Keep the accepted smooth background and remove any auxiliary terms.
    hist.data["Background"][0][0] = "chebyschev-1"
    hist.data["Background"][0][1] = True
    hist.data["Background"][0][2] = 8
    hist.data["Background"][1]["nDebye"] = 0
    hist.data["Background"][1]["debyeTerms"] = []
    hist.data["Background"][1]["nPeaks"] = 0
    hist.data["Background"][1]["peaksList"] = []

    md = {
        "SrWO4_scheelite": [1, 1, 0],
        "WO3_monoclinic": [0, 0, 1],
        "SrCO3_orthorhombic": [0, 0, 1],
    }
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        hap["Scale"][1] = True
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = md[phase.name]
        neutral_size(hap)
        neutral_other_hap(hap)
        if phase.name == "WO3_monoclinic":
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][2][:] = [True, True, False]
            hap["Mustrain"][3] = [0, 1, 0]
            hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        else:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
            hap["Mustrain"][2][:] = [False, False, False]
            hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
            hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])


def write_fit(hist) -> None:
    profile = hist.data["data"][1]
    with Path("fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
        for angle, observed, calculated, difference in zip(
                profile[0], profile[1], profile[3], profile[5]):
            writer.writerow([
                f"{float(angle):.10f}", f"{float(observed):.10f}",
                f"{float(calculated):.10f}", f"{float(difference):.10f}",
            ])


def main() -> None:
    G2sc.SetPrintLevel("none")
    project = G2sc.G2Project(str(SOURCE.resolve()), newgpx=str(PROJECT.resolve()))
    project.set_Controls("cycles", 12)
    prune(project)

    rows = []
    previous = None
    for replay in range(1, 7):
        project.refine()
        row = {
            "replay": replay,
            "metric": metric(project),
            "global_terms": global_terms(project),
            "phase_terms": phase_terms(project),
            "md": md_diagnostics(project),
        }
        rows.append(row)
        project.save()
        current = row["metric"]["rwp_percent"]
        if (previous is not None and abs(current - previous) < 1.0e-5
                and row["metric"]["max_shift_over_sigma"] < 0.2
                and row["metric"]["converged"]):
            break
        previous = current
    Path("trials/final_replay_log.json").write_text(json.dumps(rows, indent=2) + "\n")

    # Reopen the exact saved project before all exports.
    project = G2sc.G2Project(str(PROJECT.resolve()))
    hist = project.histogram(0)
    final_metric = metric(project)
    fractions = hist.ComputeMassFracs()
    write_fit(hist)

    phase_rows = []
    for phase in project.phases():
        formula, cif_path = PHASE_OUTPUTS[phase.name]
        phase.export_CIF(cif_path)
        fraction, sigma = fractions[phase.name]
        phase_id = phase.id
        data_summary = hist.data["data"][0]
        phase_rows.append({
            "name": phase.name,
            "formula": formula,
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": cif_path,
            "project_path": "final.gpx",
            "weight_fraction": float(fraction),
            "weight_fraction_esd": float(sigma),
            "bragg_R_percent": float(data_summary.get(f"{phase_id}:0:Rf", 0.0)),
            "bragg_R_squared_percent": float(data_summary.get(f"{phase_id}:0:Rf^2", 0.0)),
        })

    covariance = project.data["Covariance"]["data"]
    residuals = hist.residuals
    gof = float(covariance["Rvals"]["GOF"])
    result = {
        "project_path": "final.gpx",
        "fit_path": "fit.csv",
        "weight_fraction_basis": "normalized over modeled crystalline phases",
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "GOF": gof,
            "reduced_chi_squared": gof * gof,
            "number_of_observations": int(hist.data["data"][0]["Nobs"]),
            "number_of_refined_parameters": len(covariance.get("varyList", [])),
            "durbin_watson": float(hist.data["data"][0]["Durbin-Watson"]),
            "converged": bool(covariance["Rvals"].get("converged")),
            "max_shift_over_sigma": float(covariance["Rvals"].get("Max shft/sig", 0.0)),
        },
        "measurement_range_two_theta_deg": [
            float(hist.data["Limits"][1][0]), float(hist.data["Limits"][1][1])
        ],
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"final_metric": final_metric, "result": result}, indent=2))


if __name__ == "__main__":
    main()
