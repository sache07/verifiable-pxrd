#!/usr/bin/env python3
"""Build chemically adapted CIF candidates used in the source challenge."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)
OUT = Path("candidates")


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def adapt(cod_id: str, replacements: dict[str, str], output: str) -> None:
    structure = Structure.from_file(cod_path(cod_id))
    structure.replace_species(replacements)
    CifWriter(structure, symprec=0.01).write_file(OUT / output)


def copy_normalized(cod_id: str, output: str) -> None:
    structure = Structure.from_file(cod_path(cod_id))
    CifWriter(structure, symprec=0.01).write_file(OUT / output)


OUT.mkdir(exist_ok=True)

# SrMoO4 is the closest ordered same-A-site scheelite parent. Mo6+ -> W6+
# is isovalent and preserves tetrahedral coordination.
adapt("2300460", {"Mo": "W"}, "srwo4_scheelite_from_srmoo4.cif")

# Independent scheelite parent; retained as a source-ranking check only because
# its oxygen disorder is flagged by cif_health.py.
adapt("1527204", {"Ba": "Sr"}, "srwo4_scheelite_from_bawo4.cif")

# Structurally distinct high-pressure/monoclinic and wolframite competitors.
adapt("1546035", {"Ca": "Sr"}, "srwo4_monoclinic_from_cawo4.cif")
adapt("9013902", {"Mg": "Sr"}, "srwo4_wolframite_from_mgwo4.cif")

# Exact-composition records normalized to compact CIFs for GSAS-II import.
for cod_id, output in [
    ("1004057", "wo3_hex_1004057.cif"),
    ("1521532", "wo3_tetragonal_1521532.cif"),
    ("1521533", "wo3_tetragonal_1521533.cif"),
    ("1528915", "wo3_monoclinic_1528915.cif"),
    ("1563541", "wo3_monoclinic_1563541.cif"),
    ("2311041", "wo3_monoclinic_2311041.cif"),
    ("2106293", "wo3_triclinic_2106293.cif"),
    ("2107312", "wo3_orthorhombic_2107312.cif"),
    ("1539128", "srco3_rhombohedral_1539128.cif"),
    ("9008198", "srco3_pnma_9008198.cif"),
    ("2311977", "sr3w2o9_c2c_2311977.cif"),
]:
    copy_normalized(cod_id, output)
