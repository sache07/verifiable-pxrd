#!/usr/bin/env python3
"""Remove or reseed accepted terms and phases from one common checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from term_challenges import configure_background, global_terms, metric, phase_terms


BASE = Path("trials/checkpoints/11_common_U_W_X_replay.gpx")
OUTDIR = Path("trials/ablation_challenge")


def neutral_md(project, phase_name: str) -> None:
    hist = project.histogram(0)
    po = project.phase(phase_name).data["Histograms"][hist.name]["Pref.Ori."]
    po[1] = 1.0
    po[2] = False


def remove_phase(project, phase_name: str) -> None:
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][hist.name]
    hap["Use"] = False
    hap["Scale"][:] = [0.0, False]
    hap["Pref.Ori."][2] = False
    hap["Size"][2][:] = [False] * len(hap["Size"][2])
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][2][:] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    phase.data["General"]["Cell"][0] = False


def apply_trial(project, label: str) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    if label == "polarization_fixed_0p5":
        inst["Polariz."][:] = [0.5, 0.5, False]
    elif label == "polarization_seed_0p6":
        inst["Polariz."][:] = [0.5, 0.6, True]
    elif label == "polarization_seed_0p9":
        inst["Polariz."][:] = [0.5, 0.9, True]
    elif label == "U_fixed_10":
        inst["U"][:] = [10.0, 10.0, False]
    elif label == "U_seed_0":
        inst["U"][:] = [10.0, 0.0, True]
    elif label == "U_seed_30":
        inst["U"][:] = [10.0, 30.0, True]
    elif label == "background_6":
        configure_background(hist, 6)
    elif label.startswith("remove_MD_"):
        neutral_md(project, label.removeprefix("remove_MD_"))
    elif label == "WO3_isotropic_strain":
        hap = project.phase("WO3_monoclinic").data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [7500.0, 0.0, 0.5]
        hap["Mustrain"][2][:] = [True, False, False]
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    elif label == "WO3_neutral_width":
        hap = project.phase("WO3_monoclinic").data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    elif label.startswith("remove_phase_"):
        remove_phase(project, label.removeprefix("remove_phase_"))
    else:
        raise ValueError(label)


def main() -> None:
    G2sc.SetPrintLevel("none")
    OUTDIR.mkdir(parents=True, exist_ok=True)
    reference = G2sc.G2Project(str(BASE.resolve()))
    reference_metric = metric(reference)
    labels = [
        "polarization_fixed_0p5", "polarization_seed_0p6", "polarization_seed_0p9",
        "U_fixed_10", "U_seed_0", "U_seed_30", "background_6",
        "remove_MD_SrWO4_scheelite", "remove_MD_WO3_monoclinic",
        "remove_MD_SrCO3_orthorhombic", "WO3_isotropic_strain",
        "WO3_neutral_width", "remove_phase_SrWO4_scheelite",
        "remove_phase_WO3_monoclinic", "remove_phase_SrCO3_orthorhombic",
    ]
    rows = []
    for label in labels:
        outfile = (OUTDIR / f"{label}.gpx").resolve()
        project = G2sc.G2Project(str(BASE.resolve()), newgpx=str(outfile))
        project.set_Controls("cycles", 12)
        try:
            apply_trial(project, label)
            project.refine()
            first = metric(project)
            project.refine()
            replay = metric(project)
            project.save()
            terms = phase_terms(project)
            row = {
                "trial": label,
                "reference": reference_metric,
                "first": first,
                "replay": replay,
                "delta_aic_vs_reference": replay["aic"] - reference_metric["aic"],
                "global_terms": global_terms(project),
                "phase_terms": terms,
                "invalid": (not replay["converged"] or
                            any(v["scale"] < 0 for v in terms.values())),
                "project": str(outfile.relative_to(Path.cwd())),
            }
        except Exception as exc:
            row = {"trial": label, "invalid": True, "error": repr(exc),
                   "project": str(outfile.relative_to(Path.cwd()))}
        rows.append(row)
        print(json.dumps(row, indent=2), flush=True)
    (OUTDIR / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
