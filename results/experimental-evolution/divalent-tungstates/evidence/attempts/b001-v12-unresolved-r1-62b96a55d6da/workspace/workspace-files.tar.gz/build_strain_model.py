#!/usr/bin/env python3
"""Add the accepted isotropic WO3 microstrain term and replay to stability."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from context_texture_challenges import md_diagnostics
from term_challenges import global_terms, metric, phase_terms


SOURCE = Path("trials/checkpoints/08_accepted_texture_replay.gpx")
WORK = Path("trials/accepted_wo3_strain.gpx")
CHECKPOINT = Path("trials/checkpoints/09_wo3_isotropic_strain_replay.gpx")


def parameter_sigma(project, variable: str) -> float | None:
    cov = project.data["Covariance"]["data"]
    vary = cov.get("varyList", [])
    if variable not in vary:
        return None
    return float(cov["sig"][vary.index(variable)])


def main() -> None:
    G2sc.SetPrintLevel("none")
    project = G2sc.G2Project(str(SOURCE.resolve()), newgpx=str(WORK.resolve()))
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    phase = project.phase("WO3_monoclinic")
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 0.5]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [7495.0, 0.0, 0.5]
    hap["Mustrain"][2][:] = [True, False, False]

    rows = []
    previous_rwp = None
    for replay in range(1, 9):
        project.refine()
        variable = f"{phase.id}:{hist.id}:Mustrain;i"
        row = {
            "replay": replay,
            "metric": metric(project),
            "wo3_strain_sigma": parameter_sigma(project, variable),
            "md": md_diagnostics(project),
            "global_terms": global_terms(project),
            "phase_terms": phase_terms(project),
        }
        rows.append(row)
        project.save()
        rwp = row["metric"]["rwp_percent"]
        if (previous_rwp is not None and abs(rwp - previous_rwp) < 1.0e-5
                and row["metric"]["max_shift_over_sigma"] < 0.2
                and row["metric"]["converged"]):
            break
        previous_rwp = rwp

    Path("trials/accepted_wo3_strain_log.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )
    CHECKPOINT.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(WORK, CHECKPOINT)
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
