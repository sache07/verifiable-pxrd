#!/usr/bin/env python3
"""Build and replay the accepted three-phase preferred-orientation model."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from context_texture_challenges import md_diagnostics, set_md
from term_challenges import global_terms, metric, phase_terms


SOURCE = Path("trials/checkpoints/07_background8_polarization.gpx")
WORK = Path("trials/accepted_texture.gpx")
CHECKPOINT = Path("trials/checkpoints/08_accepted_texture_replay.gpx")
TERMS = {
    "SrWO4_scheelite": ((1, 1, 0), 0.7347),
    "WO3_monoclinic": ((0, 0, 1), 1.2568),
    "SrCO3_orthorhombic": ((0, 0, 1), 0.8448),
}


def main() -> None:
    G2sc.SetPrintLevel("none")
    project = G2sc.G2Project(str(SOURCE.resolve()), newgpx=str(WORK.resolve()))
    project.set_Controls("cycles", 12)
    for phase_name, (axis, ratio) in TERMS.items():
        set_md(project, phase_name, axis, ratio)

    rows = []
    previous_rwp = None
    for replay in range(1, 9):
        project.refine()
        row = {
            "replay": replay,
            "metric": metric(project),
            "md": md_diagnostics(project),
            "global_terms": global_terms(project),
            "phase_terms": phase_terms(project),
        }
        rows.append(row)
        project.save()
        rwp = row["metric"]["rwp_percent"]
        if (previous_rwp is not None and abs(rwp - previous_rwp) < 1.0e-5
                and row["metric"]["max_shift_over_sigma"] < 0.2
                and row["metric"]["converged"]):
            break
        previous_rwp = rwp

    Path("trials/accepted_texture_log.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )
    CHECKPOINT.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(WORK, CHECKPOINT)
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
