#!/usr/bin/env python3
"""Scale-first challenge for the charge-balanced Sr3W2O9 watch-list phase."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from term_challenges import global_terms, metric, phase_terms


BASE = Path("trials/checkpoints/11_common_U_W_X_replay.gpx")
OUTDIR = Path("trials/watchlist_challenge")
CIF = "candidates/sr3w2o9_c2c_2311977.cif"


def neutralize(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Pref.Ori."][:3] = ["MD", 1.0, False]
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 0.5]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Extinction"][:] = [0.0, False]
    for key in ("BabA", "BabU"):
        hap["Babinet"][key][:] = [0.0, False]


def scale_sigma(project, phase) -> float | None:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    vary = cov.get("varyList", [])
    variable = f"{phase.id}:{hist.id}:Scale"
    return float(cov["sig"][vary.index(variable)]) if variable in vary else None


def main() -> None:
    G2sc.SetPrintLevel("none")
    OUTDIR.mkdir(parents=True, exist_ok=True)
    rows = []
    for seed in (0.02, 0.2, 1.0):
        label = f"Sr3W2O9_scale_seed_{str(seed).replace('.', 'p')}"
        outfile = (OUTDIR / f"{label}.gpx").resolve()
        project = G2sc.G2Project(str(BASE.resolve()), newgpx=str(outfile))
        project.set_Controls("cycles", 12)
        hist = project.histogram(0)
        phase = project.add_phase(CIF, phasename="Sr3W2O9_watch",
                                  histograms=[hist], fmthint="CIF")
        neutralize(phase, hist.name)
        phase.data["General"]["Cell"][0] = False
        phase.data["Histograms"][hist.name]["Scale"][:] = [seed, True]
        try:
            project.refine()
            first = metric(project)
            first_scale = float(phase.data["Histograms"][hist.name]["Scale"][0])
            first_sigma = scale_sigma(project, phase)
            project.refine()
            replay = metric(project)
            scale = float(phase.data["Histograms"][hist.name]["Scale"][0])
            sigma = scale_sigma(project, phase)
            project.save()
            terms = phase_terms(project)
            significant = bool(sigma and scale > 3.0 * sigma)
            row = {
                "trial": label,
                "seed": seed,
                "first": first,
                "first_scale": first_scale,
                "first_scale_sigma": first_sigma,
                "replay": replay,
                "scale": scale,
                "scale_sigma": sigma,
                "scale_significant_gt_3sigma": significant,
                "global_terms": global_terms(project),
                "phase_terms": terms,
                "invalid": (not replay["converged"] or scale <= 0.0 or
                            not significant),
                "project": str(outfile.relative_to(Path.cwd())),
            }
        except Exception as exc:
            row = {"trial": label, "seed": seed, "invalid": True,
                   "error": repr(exc),
                   "project": str(outfile.relative_to(Path.cwd()))}
        rows.append(row)
        print(json.dumps(row, indent=2), flush=True)
    (OUTDIR / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
