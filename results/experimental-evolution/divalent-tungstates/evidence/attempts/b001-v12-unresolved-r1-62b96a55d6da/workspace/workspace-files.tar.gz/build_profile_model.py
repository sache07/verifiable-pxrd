#!/usr/bin/env python3
"""Release the accepted nonnegative common U/W/X profile model and replay."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from context_texture_challenges import md_diagnostics
from term_challenges import global_terms, metric, phase_terms


SOURCE = Path("trials/checkpoints/10_wo3_uniaxial_010_replay.gpx")
WORK = Path("trials/accepted_profile_UWX.gpx")
CHECKPOINT = Path("trials/checkpoints/11_common_U_W_X_replay.gpx")


def sigma(project, variable: str) -> float | None:
    cov = project.data["Covariance"]["data"]
    vary = cov.get("varyList", [])
    return float(cov["sig"][vary.index(variable)]) if variable in vary else None


def main() -> None:
    G2sc.SetPrintLevel("none")
    project = G2sc.G2Project(str(SOURCE.resolve()), newgpx=str(WORK.resolve()))
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    hist.data["Instrument Parameters"][0]["U"][2] = True

    rows = []
    previous_rwp = None
    for replay in range(1, 9):
        project.refine()
        row = {
            "replay": replay,
            "metric": metric(project),
            "profile_sigmas": {
                key: sigma(project, f":{hist.id}:{key}")
                for key in ("U", "W", "X")
            },
            "md": md_diagnostics(project),
            "global_terms": global_terms(project),
            "phase_terms": phase_terms(project),
        }
        rows.append(row)
        project.save()
        rwp = row["metric"]["rwp_percent"]
        if (previous_rwp is not None and abs(rwp - previous_rwp) < 1.0e-5
                and row["metric"]["max_shift_over_sigma"] < 0.2
                and row["metric"]["converged"]):
            break
        previous_rwp = rwp

    Path("trials/accepted_profile_UWX_log.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )
    CHECKPOINT.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(WORK, CHECKPOINT)
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
