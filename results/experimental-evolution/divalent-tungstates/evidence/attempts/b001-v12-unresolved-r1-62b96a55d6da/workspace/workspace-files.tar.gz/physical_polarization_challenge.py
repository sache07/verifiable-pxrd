#!/usr/bin/env python3
"""Complement the bound polarization ablation with nonnegative fixed U."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from term_challenges import global_terms, metric, phase_terms


BASE = Path("trials/checkpoints/11_common_U_W_X_replay.gpx")
OUTDIR = Path("trials/physical_polarization_challenge")


def main() -> None:
    G2sc.SetPrintLevel("none")
    OUTDIR.mkdir(parents=True, exist_ok=True)
    rows = []
    for label, u_value in (("P0p5_U16p93_fixed", 16.93),
                           ("P0p5_U10_fixed", 10.0),
                           ("P0p5_U0_fixed", 0.0)):
        outfile = (OUTDIR / f"{label}.gpx").resolve()
        project = G2sc.G2Project(str(BASE.resolve()), newgpx=str(outfile))
        project.set_Controls("cycles", 12)
        hist = project.histogram(0)
        inst = hist.data["Instrument Parameters"][0]
        inst["Polariz."][:] = [0.5, 0.5, False]
        inst["U"][:] = [10.0, u_value, False]
        project.refine()
        first = metric(project)
        project.refine()
        replay = metric(project)
        project.save()
        terms = global_terms(project)
        row = {
            "trial": label, "fixed_U": u_value, "first": first,
            "replay": replay, "global_terms": terms,
            "phase_terms": phase_terms(project),
            "invalid": (not replay["converged"] or
                        any(terms["instrument"][key]["value"] < 0
                            for key in ("U", "W", "X"))),
            "project": str(outfile.relative_to(Path.cwd())),
        }
        rows.append(row)
        print(json.dumps(row, indent=2), flush=True)
    (OUTDIR / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
