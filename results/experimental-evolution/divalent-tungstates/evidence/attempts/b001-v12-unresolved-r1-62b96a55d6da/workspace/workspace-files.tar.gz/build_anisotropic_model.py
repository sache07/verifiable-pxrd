#!/usr/bin/env python3
"""Build and replay the accepted [010] uniaxial WO3 microstrain model."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from build_strain_model import parameter_sigma
from context_texture_challenges import md_diagnostics
from term_challenges import global_terms, metric, phase_terms


SOURCE = Path("trials/checkpoints/09_wo3_isotropic_strain_replay.gpx")
WORK = Path("trials/accepted_wo3_uniaxial_strain.gpx")
CHECKPOINT = Path("trials/checkpoints/10_wo3_uniaxial_010_replay.gpx")


def main() -> None:
    G2sc.SetPrintLevel("none")
    project = G2sc.G2Project(str(SOURCE.resolve()), newgpx=str(WORK.resolve()))
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    phase = project.phase("WO3_monoclinic")
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][:] = [4273.0, 17174.0, 0.5]
    hap["Mustrain"][2][:] = [True, True, False]
    hap["Mustrain"][3] = [0, 1, 0]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])

    rows = []
    previous_rwp = None
    for replay in range(1, 9):
        project.refine()
        pfx = f"{phase.id}:{hist.id}:"
        row = {
            "replay": replay,
            "metric": metric(project),
            "wo3_strain_sigmas": {
                "equatorial": parameter_sigma(project, pfx + "Mustrain;i"),
                "axial": parameter_sigma(project, pfx + "Mustrain;a"),
            },
            "md": md_diagnostics(project),
            "global_terms": global_terms(project),
            "phase_terms": phase_terms(project),
            "wo3_mustrain_raw": phase.data["Histograms"][hist.name]["Mustrain"],
        }
        rows.append(row)
        project.save()
        rwp = row["metric"]["rwp_percent"]
        if (previous_rwp is not None and abs(rwp - previous_rwp) < 1.0e-5
                and row["metric"]["max_shift_over_sigma"] < 0.2
                and row["metric"]["converged"]):
            break
        previous_rwp = rwp

    Path("trials/accepted_wo3_uniaxial_log.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )
    CHECKPOINT.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(WORK, CHECKPOINT)
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
