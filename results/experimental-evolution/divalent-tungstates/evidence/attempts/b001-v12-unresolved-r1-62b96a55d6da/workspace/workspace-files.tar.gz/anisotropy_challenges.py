#!/usr/bin/env python3
"""Compare isotropic and symmetry-compatible WO3 microstrain models."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIspc as G2spc

from context_texture_challenges import md_diagnostics
from term_challenges import global_terms, metric, phase_terms


BASE = Path("trials/checkpoints/09_wo3_isotropic_strain_replay.gpx")
OUTDIR = Path("trials/anisotropy_challenge")
AXES = [(1, 0, 0), (0, 1, 0), (0, 0, 1),
        (1, 1, 0), (1, 0, 1), (0, 1, 1)]


def covariance_values(project, phase_name: str) -> dict:
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    cov = project.data["Covariance"]["data"]
    vary = cov.get("varyList", [])
    return {
        name: float(cov["sig"][i])
        for i, name in enumerate(vary)
        if name.startswith(f"{phase.id}:{hist.id}:Mustrain")
    }


def generalized_diagnostics(project) -> dict:
    hist = project.histogram(0)
    phase = project.phase("WO3_monoclinic")
    hap = phase.data["Histograms"][hist.name]
    coeffs = np.asarray(hap["Mustrain"][4], dtype=float)
    reflections = hist.data["Reflection Lists"][phase.name]["RefList"]
    sums = []
    effective = []
    for reflection in reflections:
        hkl = reflection[:3]
        terms = np.asarray(G2spc.MustrainCoeff(hkl, phase.data["General"]["SGData"]))
        value = float(np.dot(coeffs, terms))
        sums.append(value)
        # GSAS-II's generalized model uses sqrt(sum(S_hkl * term)).
        effective.append(float(np.sqrt(max(value, 0.0))))
    return {
        "names": G2spc.MustrainNames(phase.data["General"]["SGData"]),
        "coefficients": coeffs.tolist(),
        "minimum_observed_hkl_quartic_sum": min(sums),
        "maximum_observed_hkl_quartic_sum": max(sums),
        "minimum_effective_observed_hkl": min(effective),
        "maximum_effective_observed_hkl": max(effective),
        "negative_observed_hkl_count": sum(value <= 0.0 for value in sums),
    }


def run(label: str, model: str, axis=None) -> dict:
    outfile = (OUTDIR / f"{label}.gpx").resolve()
    project = G2sc.G2Project(str(BASE.resolve()), newgpx=str(outfile))
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    phase = project.phase("WO3_monoclinic")
    hap = phase.data["Histograms"][hist.name]
    iso = float(hap["Mustrain"][1][0])

    if model == "uniaxial":
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][:] = [iso, iso, 0.5]
        hap["Mustrain"][2][:] = [True, True, False]
        hap["Mustrain"][3] = list(axis)
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    elif model == "generalized":
        cell = phase.data["General"]["Cell"][1:7]
        values = G2spc.Muiso2Shkl(iso, phase.data["General"]["SGData"], cell)
        hap["Mustrain"][0] = "generalized"
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][4][:] = [float(v) for v in values]
        hap["Mustrain"][5][:] = [True] * len(hap["Mustrain"][5])
    else:
        raise ValueError(model)

    project.refine()
    first = metric(project)
    project.refine()
    replay = metric(project)
    project.save()
    current = phase_terms(project)["WO3_monoclinic"]
    diag = generalized_diagnostics(project) if model == "generalized" else None
    if model == "uniaxial":
        values = phase.data["Histograms"][hist.name]["Mustrain"][1][:2]
        boundary = any(value <= 0.0 or value >= 1.0e5 for value in values)
    else:
        boundary = diag["negative_observed_hkl_count"] > 0
    expected_count = 2 if model == "uniaxial" else len(hap["Mustrain"][5])
    sigmas = covariance_values(project, phase.name)
    missing = len(sigmas) != expected_count
    invalid = (not replay["converged"] or boundary or missing or
               any(v["scale"] <= 0 for v in phase_terms(project).values()))
    return {
        "trial": label,
        "model": model,
        "axis": list(axis) if axis else None,
        "first": first,
        "replay": replay,
        "wo3_terms": current,
        "mustrain_raw": phase.data["Histograms"][hist.name]["Mustrain"],
        "mustrain_sigmas": sigmas,
        "generalized_diagnostics": diag,
        "md": md_diagnostics(project),
        "global_terms": global_terms(project),
        "phase_terms": phase_terms(project),
        "boundary": boundary,
        "missing_variables": missing,
        "invalid": invalid,
        "project": str(outfile.relative_to(Path.cwd())),
    }


def main() -> None:
    G2sc.SetPrintLevel("none")
    OUTDIR.mkdir(parents=True, exist_ok=True)
    rows = []
    for axis in AXES:
        label = "WO3_uniaxial_" + "".join(str(v) for v in axis)
        try:
            row = run(label, "uniaxial", axis)
        except Exception as exc:
            row = {"trial": label, "model": "uniaxial", "axis": list(axis),
                   "invalid": True, "error": repr(exc)}
        rows.append(row)
        print(json.dumps(row, indent=2), flush=True)
    try:
        row = run("WO3_generalized", "generalized")
    except Exception as exc:
        row = {"trial": "WO3_generalized", "model": "generalized",
               "invalid": True, "error": repr(exc)}
    rows.append(row)
    print(json.dumps(row, indent=2), flush=True)
    (OUTDIR / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
