#!/usr/bin/env python3
"""Replay serious alternative structural sources in the mature model."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from term_challenges import global_terms, metric, phase_terms


BASE = Path("trials/checkpoints/11_common_U_W_X_replay.gpx")
OUTDIR = Path("trials/elaborated_source_challenge")
CANDIDATES = [
    {
        "name": "WO3_mono_1528915", "role": "WO3_monoclinic",
        "cif": "candidates/wo3_monoclinic_1528915.cif",
        "md_axis": (0, 0, 1), "md_ratio": 1.26,
        "strain_axis": (0, 1, 0), "strain": (4300.0, 17200.0),
    },
    {
        "name": "WO3_tri_2106293", "role": "WO3_monoclinic",
        "cif": "candidates/wo3_triclinic_2106293.cif",
        "md_axis": (0, 0, 1), "md_ratio": 1.26,
        "strain_axis": (0, 1, 0), "strain": (4300.0, 17200.0),
    },
    {
        "name": "SrCO3_R3m_1539128", "role": "SrCO3_orthorhombic",
        "cif": "candidates/srco3_rhombohedral_1539128.cif",
        "md_axis": (0, 0, 1), "md_ratio": 0.84,
    },
    {
        "name": "SrWO4_scheelite_BaW", "role": "SrWO4_scheelite",
        "cif": "candidates/srwo4_scheelite_from_bawo4.cif",
        "md_axis": (1, 1, 0), "md_ratio": 0.74,
    },
    {
        "name": "SrWO4_monoclinic_CaW", "role": "SrWO4_scheelite",
        "cif": "candidates/srwo4_monoclinic_from_cawo4.cif",
        "md_axis": (1, 1, 0), "md_ratio": 0.74,
    },
]


def json_default(value):
    """Convert numpy scalar values returned by GSAS-II for audit logs."""
    if hasattr(value, "item"):
        return value.item()
    raise TypeError(f"Cannot JSON-encode {type(value)!r}")


def disable_phase(project, phase_name: str) -> float:
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][hist.name]
    scale = float(hap["Scale"][0])
    hap["Use"] = False
    hap["Scale"][:] = [0.0, False]
    hap["Pref.Ori."][2] = False
    hap["Size"][2][:] = [False] * len(hap["Size"][2])
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][2][:] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    phase.data["General"]["Cell"][0] = False
    return scale


def neutralize(phase, hist_name: str, scale: float) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"][:] = [max(scale, 0.1), True]
    hap["Pref.Ori."][:3] = ["MD", 1.0, False]
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 0.5]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Extinction"][:] = [0.0, False]
    for key in ("BabA", "BabU"):
        hap["Babinet"][key][:] = [0.0, False]


def scale_sigma(project, phase) -> float | None:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    vary = cov.get("varyList", [])
    variable = f"{phase.id}:{hist.id}:Scale"
    return float(cov["sig"][vary.index(variable)]) if variable in vary else None


def snapshot(project, phase, initial_volume: float) -> dict:
    hist = project.histogram(0)
    hap = phase.data["Histograms"][hist.name]
    cell = {key: float(value) for key, value in phase.get_cell().items()}
    return {
        "metric": metric(project),
        "candidate_scale": float(hap["Scale"][0]),
        "candidate_scale_sigma": scale_sigma(project, phase),
        "candidate_cell": cell,
        "volume_ratio": cell["volume"] / initial_volume,
        "global_terms": global_terms(project),
        "phase_terms": phase_terms(project),
    }


def run(spec: dict) -> dict:
    path = (OUTDIR / f"{spec['name']}.gpx").resolve()
    project = G2sc.G2Project(str(BASE.resolve()), newgpx=str(path))
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    scale_seed = disable_phase(project, spec["role"])
    candidate = project.add_phase(spec["cif"], phasename=spec["name"],
                                  histograms=[hist], fmthint="CIF")
    neutralize(candidate, hist.name, scale_seed)
    candidate.data["General"]["Cell"][0] = False
    initial_volume = candidate.get_cell()["volume"]

    project.refine()
    project.refine()
    fixed = snapshot(project, candidate, initial_volume)
    fixed_path = path.with_name(path.stem + "_fixed.gpx")
    project.save()
    shutil.copy2(path, fixed_path)
    fixed_valid = (fixed["metric"]["converged"] and
                   fixed["candidate_scale"] > 0.0 and
                   fixed["candidate_scale_sigma"] is not None and
                   fixed["candidate_scale"] > 3 * fixed["candidate_scale_sigma"])

    if not fixed_valid:
        return {
            "candidate": spec["name"], "role": spec["role"], "cif": spec["cif"],
            "fixed_cell": fixed, "fixed_cell_valid": False,
            "cell_refined": None, "elaborated": None,
            "retained_project": str(path.relative_to(Path.cwd())),
        }

    candidate.data["General"]["Cell"][0] = True
    project.refine()
    project.refine()
    cell = snapshot(project, candidate, initial_volume)
    cell_valid = (cell["metric"]["converged"] and cell["candidate_scale"] > 0.0
                  and 0.8 <= cell["volume_ratio"] <= 1.2)
    if not cell_valid:
        # Restore every value and flag from the fixed-cell checkpoint.
        project = G2sc.G2Project(str(fixed_path), newgpx=str(path))
        hist = project.histogram(0)
        candidate = project.phase(spec["name"])

    hap = candidate.data["Histograms"][hist.name]
    hap["Pref.Ori."][:3] = ["MD", spec["md_ratio"], True]
    hap["Pref.Ori."][3] = list(spec["md_axis"])
    if "strain" in spec:
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][:] = [spec["strain"][0], spec["strain"][1], 0.5]
        hap["Mustrain"][2][:] = [True, True, False]
        hap["Mustrain"][3] = list(spec["strain_axis"])
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    project.refine()
    project.refine()
    project.save()
    elaborated = snapshot(project, candidate, initial_volume)
    return {
        "candidate": spec["name"], "role": spec["role"], "cif": spec["cif"],
        "fixed_cell": fixed, "fixed_cell_valid": fixed_valid,
        "cell_refined": cell, "cell_refined_valid": cell_valid,
        "elaborated": elaborated,
        "retained_project": str(path.relative_to(Path.cwd())),
    }


def main() -> None:
    G2sc.SetPrintLevel("none")
    OUTDIR.mkdir(parents=True, exist_ok=True)
    rows = []
    for spec in CANDIDATES:
        try:
            row = run(spec)
        except Exception as exc:
            row = {"candidate": spec["name"], "role": spec["role"],
                   "cif": spec["cif"], "error": repr(exc), "invalid": True}
        rows.append(row)
        print(json.dumps(row, indent=2, default=json_default), flush=True)
    (OUTDIR / "summary.json").write_text(
        json.dumps(rows, indent=2, default=json_default) + "\n"
    )


if __name__ == "__main__":
    main()
