#!/usr/bin/env python3
"""Replay source/polymorph challenges from one common neutral profile."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


COMMON = {
    "SrWO4": "candidates/srwo4_scheelite_seed.cif",
    "WO3": "candidates/wo3_triclinic_2106293.cif",
    "SrCO3": "candidates/srco3_pnma_9008198.cif",
}

SUITES = {
    "wo3": [
        ("WO3_hex_1004057", "candidates/wo3_hex_1004057.cif"),
        ("WO3_tet_1521532", "candidates/wo3_tetragonal_1521532.cif"),
        ("WO3_tet_1521533", "candidates/wo3_tetragonal_1521533.cif"),
        ("WO3_mono_1528915", "candidates/wo3_monoclinic_1528915.cif"),
        ("WO3_mono_1563541", "candidates/wo3_monoclinic_1563541.cif"),
        ("WO3_mono_2311041", "candidates/wo3_monoclinic_2311041.cif"),
        ("WO3_tri_2106293", "candidates/wo3_triclinic_2106293.cif"),
        ("WO3_ortho_2107312", "candidates/wo3_orthorhombic_2107312.cif"),
    ],
    "srco3": [
        ("SrCO3_R3m_1539128", "candidates/srco3_rhombohedral_1539128.cif"),
        ("SrCO3_Pnma_9008198", "candidates/srco3_pnma_9008198.cif"),
    ],
    "srwo4": [
        ("SrWO4_scheelite_SrMo", "candidates/srwo4_scheelite_seed.cif"),
        ("SrWO4_scheelite_BaW", "candidates/srwo4_scheelite_from_bawo4.cif"),
        ("SrWO4_monoclinic_CaW", "candidates/srwo4_monoclinic_from_cawo4.cif"),
        ("SrWO4_wolframite_MgW", "candidates/srwo4_wolframite_from_mgwo4.cif"),
    ],
}


def neutralize(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Pref.Ori."][:3] = ["MD", 1.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 0.5]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Extinction"][:] = [0.0, False]
    for key in ("BabA", "BabU"):
        hap["Babinet"][key][:] = [0.0, False]


def snapshot(project, candidate, initial_volume: float) -> dict:
    hist = project.histogram(0)
    hap = candidate.data["Histograms"][hist.name]
    cov = project.data["Covariance"]["data"]
    cell = candidate.get_cell()
    scale_name = f"{candidate.id}:0:Scale"
    scale_sigma = None
    if scale_name in cov.get("varyList", []):
        scale_sigma = float(cov["sig"][cov["varyList"].index(scale_name)])
    return {
        "rwp_percent": float(hist.residuals["wR"]),
        "gof": float(cov["Rvals"]["GOF"]),
        "converged": bool(cov["Rvals"].get("converged")),
        "max_shift_over_sigma": float(cov["Rvals"].get("Max shft/sig", 0.0)),
        "candidate_scale": float(hap["Scale"][0]),
        "candidate_scale_sigma": scale_sigma,
        "cell": cell,
        "volume_ratio": float(cell["volume"] / initial_volume),
    }


def run_trial(suite: str, name: str, cif: str, outdir: Path) -> dict:
    path = outdir / f"{name}.gpx"
    project = G2sc.G2Project(newgpx=str(path.resolve()))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    hist.data["Sample Parameters"]["Scale"][:] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"][:] = [1059.5650515651625, False]
    hist.data["Sample Parameters"]["Transparency"][:] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"][:] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"][:] = [0.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 10.0, "V": 0.0, "W": 45.921420703174434,
                       "X": 2.3297867733303876, "Y": 0.0, "SH/L": 0.002}.items():
        inst[key][1] = value
        inst[key][2] = False
    hist.set_refinements({
        "Limits": [9.90343322, 100.09455322],
        "Background": {"type": "chebyschev-1", "refine": True,
                       "no. coeffs": 6,
                       "coeffs": [1050.0, 0.0, 0.0, 0.0, 0.0, 0.0]},
    })

    if suite == "wo3":
        phase_specs = [("SrWO4_support", COMMON["SrWO4"]),
                       (name, cif), ("SrCO3_support", COMMON["SrCO3"])]
        candidate_index = 1
    elif suite == "srco3":
        phase_specs = [("SrWO4_support", COMMON["SrWO4"]),
                       ("WO3_support", COMMON["WO3"]), (name, cif)]
        candidate_index = 2
    else:
        phase_specs = [(name, cif), ("WO3_support", COMMON["WO3"]),
                       ("SrCO3_support", COMMON["SrCO3"])]
        candidate_index = 0

    phases = []
    for phase_name, phase_cif in phase_specs:
        phase = project.add_phase(
            phase_cif, phasename=phase_name, histograms=[hist], fmthint="CIF"
        )
        neutralize(phase, hist.name)
        phase.data["Histograms"][hist.name]["Scale"][:] = [1.0, True]
        phases.append(phase)
    candidate = phases[candidate_index]
    initial_volume = candidate.get_cell()["volume"]

    project.set_Controls("cycles", 5)
    project.save()
    project.refine()
    project.save()
    fixed = snapshot(project, candidate, initial_volume)
    checkpoint = path.with_name(path.stem + "_fixed.gpx")
    shutil.copy2(path, checkpoint)

    candidate.set_refinements({"Cell": True})
    project.refine()
    project.save()
    cell = snapshot(project, candidate, initial_volume)
    invalid = (
        cell["candidate_scale"] <= 0.0
        or not 0.80 <= cell["volume_ratio"] <= 1.20
        or not cell["converged"]
    )
    if invalid:
        # Restore every value and flag from the common fixed-cell checkpoint.
        project = G2sc.G2Project(str(checkpoint), newgpx=str(path.resolve()))
        project.save()

    return {
        "suite": suite,
        "candidate": name,
        "cif": cif,
        "fixed_cell": fixed,
        "refined_cell": cell,
        "refined_cell_invalid": invalid,
        "retained_project": str(path),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("suite", choices=sorted(SUITES))
    args = parser.parse_args()
    outdir = Path("trials/source_challenge") / args.suite
    outdir.mkdir(parents=True, exist_ok=True)
    rows = []
    for name, cif in SUITES[args.suite]:
        print(f"\nSOURCE_CHALLENGE {args.suite} {name}", flush=True)
        rows.append(run_trial(args.suite, name, cif, outdir))
        print(json.dumps(rows[-1], indent=2), flush=True)
    with (outdir / "summary.json").open("w") as handle:
        json.dump(rows, handle, indent=2)


if __name__ == "__main__":
    main()
