#!/usr/bin/env python3
"""Run a conservative GSAS-II source challenge for one or more phases."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def parse_phase(token: str) -> tuple[str, str]:
    name, path = token.split("=", 1)
    return name, path


def neutralize_hap(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [100.0, 100.0, 0.5]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0 for _ in hap["Mustrain"][4]]
    hap["Mustrain"][5][:] = [False for _ in hap["Mustrain"][5]]
    hap["HStrain"][0][:] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1][:] = [False for _ in hap["HStrain"][1]]
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def summarize(project, label: str) -> None:
    hist = project.histogram(0)
    print(f"\nSUMMARY {label}")
    print("residuals", hist.residuals)
    print("sample", {k: hist.data["Sample Parameters"].get(k) for k in
                     ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    print("instrument", {k: hist.data["Instrument Parameters"][0][k]
                          for k in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"]})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("phase", phase.name, "cell", phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"], "mustrain", hap["Mustrain"],
              "prefori", hap["Pref.Ori."][:4])
    try:
        print("mass_fracs", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass_fracs_error", repr(exc))
    cov = project.data.get("Covariance", {}).get("data", {})
    print("covariance", {k: cov.get(k) for k in ["Rvals", "varyList", "variables", "sig"]})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", action="append", required=True, type=parse_phase)
    parser.add_argument("--shift", type=float, default=600.0)
    args = parser.parse_args()

    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    hist.data["Sample Parameters"]["Scale"][:] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"][:] = [args.shift, False]
    hist.data["Sample Parameters"]["Transparency"][:] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"][:] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"][:] = [0.0, False]
    hist.set_refinements({
        "Limits": [9.90343322, 100.09455322],
        "Background": {
            "type": "chebyschev-1", "refine": True, "no. coeffs": 6,
            "coeffs": [1050.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        },
    })

    phases = []
    for name, cif in args.phase:
        phase = project.add_phase(
            cif, phasename=name, histograms=[hist], fmthint="CIF"
        )
        neutralize_hap(phase, hist.name)
        phase.data["Histograms"][hist.name]["Scale"][:] = [1.0, True]
        phases.append(phase)

    project.set_Controls("cycles", 8)
    project.save()

    # Common neutral checkpoint: smooth background and nonnegative phase scales.
    project.refine()
    project.save(output.with_name(output.stem + "_scale.gpx"))
    summarize(project, "scale")

    # Reopen cell and one reflection-geometry correction from the checkpoint.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.refine()
    project.save(output.with_name(output.stem + "_cell_shift.gpx"))
    summarize(project, "cell_shift")

    # Low-dimensional, nonnegative common profile: W and X, with U held.
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    project.refine()
    project.save(str(output))
    summarize(project, "profile")


if __name__ == "__main__":
    main()
