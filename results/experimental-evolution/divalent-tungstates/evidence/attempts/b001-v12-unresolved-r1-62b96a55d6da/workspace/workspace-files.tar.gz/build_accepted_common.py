#!/usr/bin/env python3
"""Build and replay the accepted common profile/intensity checkpoint."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from term_challenges import configure_background, global_terms, metric, phase_terms


SOURCE = Path("trials/checkpoints/06_common_W_X_replay.gpx")
WORK = Path("trials/accepted_common.gpx")
CHECKPOINT = Path("trials/checkpoints/07_background8_polarization.gpx")


def main() -> None:
    G2sc.SetPrintLevel("none")
    project = G2sc.G2Project(str(SOURCE.resolve()), newgpx=str(WORK.resolve()))
    hist = project.histogram(0)
    configure_background(hist, 8)
    hist.data["Instrument Parameters"][0]["Polariz."][:] = [0.5, 0.5, True]
    project.set_Controls("cycles", 12)

    log = []
    previous_rwp = None
    for replay in range(1, 7):
        project.refine()
        row = {
            "replay": replay,
            "metric": metric(project),
            "global_terms": global_terms(project),
            "phase_terms": phase_terms(project),
        }
        log.append(row)
        project.save()
        rwp = row["metric"]["rwp_percent"]
        shift = row["metric"]["max_shift_over_sigma"]
        if (previous_rwp is not None and abs(rwp - previous_rwp) < 1.0e-4
                and shift < 0.5 and row["metric"]["converged"]):
            break
        previous_rwp = rwp

    Path("trials/accepted_common_log.json").write_text(
        json.dumps(log, indent=2) + "\n"
    )
    CHECKPOINT.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(WORK, CHECKPOINT)
    print(json.dumps(log, indent=2))


if __name__ == "__main__":
    main()
