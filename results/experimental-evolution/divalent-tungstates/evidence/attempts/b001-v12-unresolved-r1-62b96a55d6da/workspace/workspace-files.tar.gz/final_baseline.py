#!/usr/bin/env python3
"""Build the common, reversible three-phase GSAS-II baseline."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


PHASES = [
    ("SrWO4_scheelite", "candidates/srwo4_scheelite_seed.cif"),
    ("WO3_monoclinic", "candidates/wo3_monoclinic_seed.cif"),
    ("SrCO3_orthorhombic", "candidates/srco3_pnma_seed.cif"),
]


def neutralize(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Pref.Ori."][:3] = ["MD", 1.0, False]
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 0.5]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Extinction"][:] = [0.0, False]
    for key in ("BabA", "BabU"):
        hap["Babinet"][key][:] = [0.0, False]


def state(project, label: str) -> dict:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    row = {
        "label": label,
        "residuals": {k: float(v) for k, v in hist.residuals.items()
                      if k in ("R", "Rb", "wR", "wRb", "wRmin")},
        "gof": float(cov["Rvals"]["GOF"]),
        "converged": bool(cov["Rvals"].get("converged")),
        "max_shift_over_sigma": float(cov["Rvals"].get("Max shft/sig", 0.0)),
        "sample_shift_micrometre": float(hist.data["Sample Parameters"]["Shift"][0]),
        "instrument": {key: float(hist.data["Instrument Parameters"][0][key][1])
                       for key in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.")},
        "phases": [],
    }
    try:
        row["mass_fractions"] = {
            key: [float(value), float(sigma)]
            for key, (value, sigma) in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        row["mass_fraction_error"] = repr(exc)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        row["phases"].append({
            "name": phase.name,
            "cell": {key: float(value) for key, value in phase.get_cell().items()},
            "scale": float(hap["Scale"][0]),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."][:4],
        })
    print(json.dumps(row, indent=2), flush=True)
    return row


def checkpoint(project, number: int, label: str) -> None:
    project.save()
    target = Path("trials/checkpoints") / f"{number:02d}_{label}.gpx"
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(project.filename, target)


def refine_stage(project, logs: list[dict], number: int, label: str) -> None:
    project.refine()
    logs.append(state(project, label))
    checkpoint(project, number, label)


def main() -> None:
    output = Path("trials/final_baseline.gpx").resolve()
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    hist.data["Sample Parameters"]["Scale"][:] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"][:] = [1059.5650515651625, False]
    hist.data["Sample Parameters"]["Transparency"][:] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"][:] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"][:] = [0.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 10.0, "V": 0.0, "W": 45.921420703174434,
                       "X": 2.3297867733303876, "Y": 0.0,
                       "SH/L": 0.002, "Polariz.": 0.5}.items():
        inst[key][1] = value
        inst[key][2] = False
    hist.set_refinements({
        "Limits": [9.90343322, 100.09455322],
        "Background": {"type": "chebyschev-1", "refine": True,
                       "no. coeffs": 6,
                       "coeffs": [1050.0, 0.0, 0.0, 0.0, 0.0, 0.0]},
    })

    phases = []
    for name, cif in PHASES:
        phase = project.add_phase(
            cif, phasename=name, histograms=[hist], fmthint="CIF"
        )
        neutralize(phase, hist.name)
        phase.data["Histograms"][hist.name]["Scale"][:] = [1.0, True]
        phases.append(phase)

    project.set_Controls("cycles", 8)
    project.save()
    logs: list[dict] = []

    # Common neutral checkpoint: scales/background only.
    refine_stage(project, logs, 0, "neutral_scales_background")

    # Each cell receives its own source-anchored loop with the common shift fixed.
    for index, phase in enumerate(phases, start=1):
        for other in phases:
            other.clear_refinements({"Cell": True})
        phase.set_refinements({"Cell": True})
        refine_stage(project, logs, index, f"cell_{phase.name}")

    # Reopen all accepted cells and the single angular correction.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine_stage(project, logs, 4, "all_cells_shift")

    # Reopen the low-dimensional common width model; U and V remain fixed.
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine_stage(project, logs, 5, "common_W_X")
    refine_stage(project, logs, 6, "common_W_X_replay")

    with Path("trials/final_baseline_log.json").open("w") as handle:
        json.dump(logs, handle, indent=2)
    project.save()


if __name__ == "__main__":
    main()
