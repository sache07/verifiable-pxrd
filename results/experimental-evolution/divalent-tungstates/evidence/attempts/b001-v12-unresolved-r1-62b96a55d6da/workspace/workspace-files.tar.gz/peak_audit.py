#!/usr/bin/env python3
"""Audit representative low/middle/high-angle peak-family shapes."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


PROJECT = Path("final.gpx")
FAMILIES = [
    ("low", "WO3_monoclinic", "002", 22.509, 0.20, True),
    ("low", "WO3_monoclinic", "020", 22.939, 0.20, True),
    ("low", "WO3_monoclinic", "20-2", 23.814, 0.24, True),
    ("low", "SrCO3_orthorhombic", "111", 24.615, 0.24, True),
    ("low", "SrWO4_scheelite", "004", 29.427, 0.24, True),
    ("middle", "SrWO4_scheelite", "121", 37.464, 0.24, True),
    ("middle", "WO3_monoclinic", "22-4", 41.305, 0.24, True),
    ("middle", "SrCO3_orthorhombic", "122/203", 43.600, 0.24, False),
    ("middle", "WO3_monoclinic", "24-2", 54.154, 0.24, True),
    ("high", "WO3_monoclinic", "44-4", 71.458, 0.25, False),
    ("high", "SrCO3_orthorhombic", "324", 74.836, 0.20, False),
    ("high", "SrWO4_scheelite", "332", 76.107, 0.20, False),
    ("high", "WO3_monoclinic", "62-6", 83.085, 0.20, False),
    ("high", "SrWO4_scheelite", "336", 91.649, 0.24, False),
]


def crossing(x, y, peak_index: int, half: float, direction: int) -> float | None:
    index = peak_index
    while 0 <= index + direction < len(y):
        nxt = index + direction
        if y[nxt] <= half < y[index]:
            x1, y1 = x[index], y[index]
            x2, y2 = x[nxt], y[nxt]
            if y2 == y1:
                return float(x2)
            return float(x1 + (half - y1) * (x2 - x1) / (y2 - y1))
        index = nxt
    return None


def characterize(x, signal) -> dict:
    peak_index = int(np.argmax(signal))
    peak = float(signal[peak_index])
    position = float(x[peak_index])
    half = peak / 2.0
    left = crossing(x, signal, peak_index, half, -1)
    right = crossing(x, signal, peak_index, half, 1)
    if left is None or right is None:
        return {"position_deg": position, "height": peak,
                "fwhm_deg": None, "left_half_width_deg": None,
                "right_half_width_deg": None}
    return {
        "position_deg": position,
        "height": peak,
        "fwhm_deg": right - left,
        "left_half_width_deg": position - left,
        "right_half_width_deg": right - position,
    }


def main() -> None:
    G2sc.SetPrintLevel("none")
    project = G2sc.G2Project(str(PROJECT.resolve()))
    hist = project.histogram(0)
    profile = hist.data["data"][1]
    x = np.asarray(profile[0], dtype=float)
    observed = np.asarray(profile[1], dtype=float)
    calculated = np.asarray(profile[3], dtype=float)
    background = np.asarray(profile[4], dtype=float)
    rows = []
    for region, phase, hkl, center, radius, isolated in FAMILIES:
        select = (x >= center - radius) & (x <= center + radius)
        xpart = x[select]
        obs = characterize(xpart, observed[select] - background[select])
        calc = characterize(xpart, calculated[select] - background[select])
        row = {
            "angle_region": region,
            "dominant_phase": phase,
            "family": hkl,
            "reference_position_deg": center,
            "window_radius_deg": radius,
            "nominally_isolated": isolated,
            "observed": obs,
            "calculated": calc,
            "position_offset_observed_minus_calculated_deg":
                obs["position_deg"] - calc["position_deg"],
        }
        if obs["fwhm_deg"] is not None and calc["fwhm_deg"] is not None:
            row["fwhm_observed_minus_calculated_deg"] = (
                obs["fwhm_deg"] - calc["fwhm_deg"]
            )
            row["observed_half_width_asymmetry_deg"] = (
                obs["right_half_width_deg"] - obs["left_half_width_deg"]
            )
            row["calculated_half_width_asymmetry_deg"] = (
                calc["right_half_width_deg"] - calc["left_half_width_deg"]
            )
        rows.append(row)
    Path("trials/peak_audit.json").write_text(json.dumps(rows, indent=2) + "\n")
    with Path("trials/peak_audit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "angle_region", "dominant_phase", "family", "isolated",
            "reference_position_deg", "observed_position_deg",
            "calculated_position_deg", "position_offset_deg",
            "observed_fwhm_deg", "calculated_fwhm_deg",
            "observed_left_half_width_deg", "observed_right_half_width_deg",
            "calculated_left_half_width_deg", "calculated_right_half_width_deg",
        ])
        for row in rows:
            writer.writerow([
                row["angle_region"], row["dominant_phase"], row["family"],
                row["nominally_isolated"], row["reference_position_deg"],
                row["observed"]["position_deg"], row["calculated"]["position_deg"],
                row["position_offset_observed_minus_calculated_deg"],
                row["observed"]["fwhm_deg"], row["calculated"]["fwhm_deg"],
                row["observed"]["left_half_width_deg"],
                row["observed"]["right_half_width_deg"],
                row["calculated"]["left_half_width_deg"],
                row["calculated"]["right_half_width_deg"],
            ])
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
