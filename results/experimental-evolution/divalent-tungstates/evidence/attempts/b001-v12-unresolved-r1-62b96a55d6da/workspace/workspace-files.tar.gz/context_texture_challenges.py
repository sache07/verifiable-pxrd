#!/usr/bin/env python3
"""Replay texture-axis choices in the context of the other accepted axes."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from term_challenges import global_terms, metric, phase_terms


BASE = Path("trials/checkpoints/07_background8_polarization.gpx")
OUTDIR = Path("trials/context_texture_challenge")
AXES = {
    "SrWO4_scheelite": [(0, 0, 1), (1, 0, 0), (1, 1, 0),
                         (1, 0, 1), (1, 1, 2)],
    "WO3_monoclinic": [(1, 0, 0), (0, 1, 0), (0, 0, 1),
                        (1, 1, 0), (1, 0, 1), (0, 1, 1)],
    "SrCO3_orthorhombic": [(1, 0, 0), (0, 1, 0), (0, 0, 1),
                            (1, 1, 0), (1, 0, 1), (0, 1, 1)],
}
SEED = {
    "SrWO4_scheelite": ((1, 1, 0), 0.7335),
    "WO3_monoclinic": ((0, 0, 1), 1.2439),
}


def set_md(project, phase_name: str, axis, ratio: float) -> None:
    hist = project.histogram(0)
    po = project.phase(phase_name).data["Histograms"][hist.name]["Pref.Ori."]
    po[:3] = ["MD", float(ratio), True]
    po[3] = list(axis)


def md_diagnostics(project) -> dict:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    vary = cov.get("varyList", [])
    out = {}
    for phase in project.phases():
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        var = f"{phase.id}:{hist.id}:MD"
        sigma = float(cov["sig"][vary.index(var)]) if var in vary else None
        out[phase.name] = {
            "axis": [int(x) for x in po[3]],
            "ratio": float(po[1]),
            "sigma": sigma,
            "variable_present": var in vary,
            "refined": bool(po[2]),
        }
    return out


def run_trial(target: str, axis) -> dict:
    label = f"{target}_MD_{''.join(str(x) for x in axis)}_context"
    outfile = (OUTDIR / f"{label}.gpx").resolve()
    project = G2sc.G2Project(str(BASE.resolve()), newgpx=str(outfile))
    project.set_Controls("cycles", 12)

    # Keep the competitor phase's winning axis active, then challenge every
    # low-index axis of the target from this same nuisance/profile checkpoint.
    for phase_name, (seed_axis, seed_ratio) in SEED.items():
        if phase_name != target:
            set_md(project, phase_name, seed_axis, seed_ratio)
    set_md(project, target, axis, 1.0)

    project.refine()
    first_metric = metric(project)
    first_md = md_diagnostics(project)
    project.refine()
    replay_metric = metric(project)
    replay_md = md_diagnostics(project)
    project.save()
    active = [value for value in replay_md.values() if value["refined"]]
    boundary = any(not 0.2 < value["ratio"] < 5.0 for value in active)
    missing = any(not value["variable_present"] for value in active)
    invalid = (not replay_metric["converged"] or boundary or missing or
               any(v["scale"] <= 0 for v in phase_terms(project).values()))
    return {
        "trial": label,
        "target_phase": target,
        "target_axis": list(axis),
        "first": first_metric,
        "first_md": first_md,
        "replay": replay_metric,
        "replay_md": replay_md,
        "global_terms": global_terms(project),
        "phase_terms": phase_terms(project),
        "boundary": boundary,
        "missing_variable": missing,
        "invalid": invalid,
        "project": str(outfile.relative_to(Path.cwd())),
    }


def main() -> None:
    G2sc.SetPrintLevel("none")
    OUTDIR.mkdir(parents=True, exist_ok=True)
    rows = []
    for target, axes in AXES.items():
        for axis in axes:
            try:
                row = run_trial(target, axis)
            except Exception as exc:
                row = {
                    "target_phase": target, "target_axis": list(axis),
                    "invalid": True, "error": repr(exc),
                }
            rows.append(row)
            print(json.dumps(row, indent=2), flush=True)
    (OUTDIR / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
