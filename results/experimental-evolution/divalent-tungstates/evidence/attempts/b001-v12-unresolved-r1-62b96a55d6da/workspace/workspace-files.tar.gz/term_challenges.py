#!/usr/bin/env python3
"""Reversible profile/intensity challenges from a common GSAS-II checkpoint."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASE = Path("trials/checkpoints/06_common_W_X_replay.gpx")
OUTDIR = Path("trials/term_challenge")


def metric(project) -> dict:
    """Return compact fit and parameter diagnostics after a refinement."""
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    nobs = int(hist.data["data"][0].get("Nobs", len(hist.data["data"][1][0])))
    k = len(cov.get("varyList", []))
    sumwyo = float(hist.data["data"][0]["sumwYo"])
    rwp = float(hist.residuals["wR"])
    wrss = (rwp / 100.0) ** 2 * sumwyo
    aic = nobs * math.log(wrss / nobs) + 2.0 * k
    try:
        fractions = {
            key: {"value": float(value), "sigma": float(sigma)}
            for key, (value, sigma) in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": repr(exc)}
    return {
        "rwp_percent": rwp,
        "rp_percent": float(hist.residuals["R"]),
        "gof": float(rvals["GOF"]),
        "converged": bool(rvals.get("converged")),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", 0.0)),
        "n_variables": k,
        "weighted_rss": wrss,
        "aic": aic,
        "fractions": fractions,
    }


def phase_terms(project) -> dict:
    hist = project.histogram(0)
    rows = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        rows[phase.name] = {
            "scale": float(hap["Scale"][0]),
            "size_micrometre": float(hap["Size"][1][0]),
            "size_refined": bool(hap["Size"][2][0]),
            "microstrain": float(hap["Mustrain"][1][0]),
            "microstrain_refined": bool(hap["Mustrain"][2][0]),
            "march_ratio": float(hap["Pref.Ori."][1]),
            "march_axis": [int(x) for x in hap["Pref.Ori."][3]],
            "march_refined": bool(hap["Pref.Ori."][2]),
        }
    return rows


def global_terms(project) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    return {
        "background_order": int(hist.data["Background"][0][2]),
        "background_coefficients": [float(x) for x in hist.data["Background"][0][3:]],
        "instrument": {
            key: {"value": float(inst[key][1]), "refined": bool(inst[key][2])}
            for key in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.")
        },
        "sample": {
            key: {"value": float(sample[key][0]), "refined": bool(sample[key][1])}
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
    }


def fresh_project(label: str):
    OUTDIR.mkdir(parents=True, exist_ok=True)
    outfile = (OUTDIR / f"{label}.gpx").resolve()
    project = G2sc.G2Project(str(BASE.resolve()), newgpx=str(outfile))
    project.set_Controls("cycles", 12)
    return project, outfile


def refine_twice(project) -> tuple[dict, dict]:
    project.refine()
    first = metric(project)
    project.refine()
    replay = metric(project)
    project.save()
    return first, replay


def run_broadening() -> list[dict]:
    rows = []
    phase_names = ["SrWO4_scheelite", "WO3_monoclinic", "SrCO3_orthorhombic"]
    for phase_name in phase_names:
        for mode in ("neutral", "size", "strain", "size_strain"):
            label = f"broadening_{phase_name}_{mode}"
            project, outfile = fresh_project(label)
            phase = project.phase(phase_name)
            hist = project.histogram(0)
            hap = phase.data["Histograms"][hist.name]
            # Explicitly reload the neutral values and flags for every comparison.
            hap["Size"][0] = "isotropic"
            hap["Size"][1][:] = [10.0, 10.0, 0.5]
            hap["Size"][2][:] = [False, False, False]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
            hap["Mustrain"][2][:] = [False, False, False]
            if mode in ("size", "size_strain"):
                hap["Size"][1][0] = 1.0
                hap["Size"][2][0] = True
            if mode in ("strain", "size_strain"):
                hap["Mustrain"][1][0] = 100.0
                hap["Mustrain"][2][0] = True
            try:
                first, replay = refine_twice(project)
                terms = phase_terms(project)
                value = terms[phase_name]
                cov_vary = project.data["Covariance"]["data"].get("varyList", [])
                phase_id = project.phase(phase_name).id
                hist_id = project.histogram(0).id
                expected = []
                if mode in ("size", "size_strain"):
                    expected.append(f"{phase_id}:{hist_id}:Size;i")
                if mode in ("strain", "size_strain"):
                    expected.append(f"{phase_id}:{hist_id}:Mustrain;i")
                missing = [name for name in expected if name not in cov_vary]
                boundary = (
                    (mode in ("size", "size_strain") and
                     (value["size_micrometre"] >= 9.99 or
                      value["size_micrometre"] <= 0.001))
                    or
                    (mode in ("strain", "size_strain") and
                     value["microstrain"] <= 1.0e-6)
                )
                invalid = (not replay["converged"] or boundary or bool(missing) or
                           any(v["scale"] <= 0.0 for v in terms.values()))
                row = {
                    "trial": label,
                    "phase": phase_name,
                    "mode": mode,
                    "first": first,
                    "replay": replay,
                    "terms": terms,
                    "expected_variables": expected,
                    "missing_variables": missing,
                    "boundary": bool(boundary),
                    "invalid": bool(invalid),
                    "project": str(outfile.relative_to(Path.cwd())),
                }
            except Exception as exc:
                row = {
                    "trial": label, "phase": phase_name, "mode": mode,
                    "invalid": True, "error": repr(exc),
                    "project": str(outfile.relative_to(Path.cwd())),
                }
            rows.append(row)
            print(json.dumps(row, indent=2), flush=True)
    (OUTDIR / "broadening_summary.json").write_text(json.dumps(rows, indent=2) + "\n")
    return rows


def configure_background(hist, order: int) -> None:
    old = [float(x) for x in hist.data["Background"][0][3:]]
    coeffs = (old + [0.0] * order)[:order]
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1", "refine": True,
            "no. coeffs": order, "coeffs": coeffs,
        }
    })


def run_global() -> list[dict]:
    trials = [
        ("background_4", {"background": 4}),
        ("background_6", {"background": 6}),
        ("background_8", {"background": 8}),
        ("profile_U_W_X", {"U": True}),
        ("polarization", {"polarization": True}),
        ("roughness", {"roughness": True}),
    ]
    rows = []
    for label, settings in trials:
        project, outfile = fresh_project(label)
        hist = project.histogram(0)
        if "background" in settings:
            configure_background(hist, settings["background"])
        if settings.get("U"):
            hist.data["Instrument Parameters"][0]["U"][2] = True
        if settings.get("polarization"):
            hist.data["Instrument Parameters"][0]["Polariz."][:] = [0.5, 0.5, True]
        if settings.get("roughness"):
            hist.data["Sample Parameters"]["SurfRoughA"][:] = [0.5, True]
            hist.data["Sample Parameters"]["SurfRoughB"][:] = [0.01, True]
        try:
            first, replay = refine_twice(project)
            terms = global_terms(project)
            inst = terms["instrument"]
            sample = terms["sample"]
            boundary = False
            if settings.get("U"):
                boundary = inst["U"]["value"] < 0.0
            if settings.get("polarization"):
                boundary = not 0.0 <= inst["Polariz."]["value"] <= 1.0
            if settings.get("roughness"):
                boundary = not (
                    0.0 <= sample["SurfRoughA"]["value"] <= 1.0 and
                    sample["SurfRoughB"]["value"] >= 0.0
                )
            phases = phase_terms(project)
            invalid = (not replay["converged"] or boundary or
                       any(v["scale"] <= 0.0 for v in phases.values()))
            row = {
                "trial": label,
                "settings": settings,
                "first": first,
                "replay": replay,
                "global_terms": terms,
                "phase_terms": phases,
                "boundary": bool(boundary),
                "invalid": bool(invalid),
                "project": str(outfile.relative_to(Path.cwd())),
            }
        except Exception as exc:
            row = {
                "trial": label, "settings": settings, "invalid": True,
                "error": repr(exc),
                "project": str(outfile.relative_to(Path.cwd())),
            }
        rows.append(row)
        print(json.dumps(row, indent=2), flush=True)
    (OUTDIR / "global_summary.json").write_text(json.dumps(rows, indent=2) + "\n")
    return rows


def main() -> None:
    global BASE, OUTDIR
    parser = argparse.ArgumentParser()
    parser.add_argument("suite", choices=("broadening", "global", "all"))
    parser.add_argument("--base", type=Path, default=BASE)
    parser.add_argument("--outdir", type=Path, default=OUTDIR)
    args = parser.parse_args()
    BASE = args.base
    OUTDIR = args.outdir
    G2sc.SetPrintLevel("none")
    if args.suite in ("broadening", "all"):
        run_broadening()
    if args.suite in ("global", "all"):
        run_global()


if __name__ == "__main__":
    main()
