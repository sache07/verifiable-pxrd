#!/usr/bin/env python3
"""Give close WO3 source competitors their own low-index elaboration loops."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from term_challenges import global_terms, metric, phase_terms


OUTDIR = Path("trials/source_axis_challenge")
SOURCES = [
    ("WO3_tri_2106293", Path("trials/elaborated_source_challenge/WO3_tri_2106293.gpx"), True),
    ("WO3_mono_1528915", Path("trials/elaborated_source_challenge/WO3_mono_1528915.gpx"), False),
]
AXES = [(1, 0, 0), (0, 1, 0), (0, 0, 1),
        (1, 1, 0), (1, 0, 1), (0, 1, 1)]


def phase_snapshot(project, phase_name: str) -> dict:
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][hist.name]
    cov = project.data["Covariance"]["data"]
    vary = cov.get("varyList", [])
    sigmas = {
        name: float(cov["sig"][i]) for i, name in enumerate(vary)
        if name.startswith(f"{phase.id}:{hist.id}:") and
        any(tag in name for tag in ("MD", "Mustrain"))
    }
    return {
        "cell": {key: float(value) for key, value in phase.get_cell().items()},
        "scale": float(hap["Scale"][0]),
        "preferred_orientation": hap["Pref.Ori."][:4],
        "mustrain": hap["Mustrain"],
        "sigmas": sigmas,
    }


def run(source_name: str, base: Path, kind: str, axis) -> dict:
    label = f"{source_name}_{kind}_{''.join(str(v) for v in axis)}"
    outfile = (OUTDIR / f"{label}.gpx").resolve()
    project = G2sc.G2Project(str(base.resolve()), newgpx=str(outfile))
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    phase = project.phase(source_name)
    hap = phase.data["Histograms"][hist.name]
    if kind == "MD":
        hap["Pref.Ori."][:3] = ["MD", 1.0, True]
        hap["Pref.Ori."][3] = list(axis)
    elif kind == "strain":
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][:] = [4300.0, 17200.0, 0.5]
        hap["Mustrain"][2][:] = [True, True, False]
        hap["Mustrain"][3] = list(axis)
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    else:
        raise ValueError(kind)
    project.refine()
    first = metric(project)
    project.refine()
    replay = metric(project)
    project.save()
    snap = phase_snapshot(project, source_name)
    ratio = float(snap["preferred_orientation"][1])
    strain = [float(v) for v in snap["mustrain"][1][:2]]
    boundary = (not 0.2 < ratio < 5.0 or
                any(value <= 0.0 or value >= 1.0e5 for value in strain))
    return {
        "trial": label, "source": source_name, "kind": kind,
        "axis": list(axis), "first": first, "replay": replay,
        "candidate": snap, "global_terms": global_terms(project),
        "phase_terms": phase_terms(project), "boundary": boundary,
        "invalid": (not replay["converged"] or boundary or snap["scale"] <= 0),
        "project": str(outfile.relative_to(Path.cwd())),
    }


def main() -> None:
    G2sc.SetPrintLevel("none")
    OUTDIR.mkdir(parents=True, exist_ok=True)
    rows = []
    for source, base, strain_loop in SOURCES:
        kinds = ["MD", "strain"] if strain_loop else ["MD"]
        for kind in kinds:
            for axis in AXES:
                try:
                    row = run(source, base, kind, axis)
                except Exception as exc:
                    row = {"source": source, "kind": kind, "axis": list(axis),
                           "invalid": True, "error": repr(exc)}
                rows.append(row)
                print(json.dumps(row, indent=2), flush=True)
    (OUTDIR / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
