#!/usr/bin/env python3
"""Cross-seed the coupled SrWO4 size and common-X broadening terms."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from term_challenges import global_terms, metric, phase_terms


BASE = Path("trials/checkpoints/11_common_U_W_X_replay.gpx")
OUTDIR = Path("trials/size_X_coupling")
TRIALS = [
    ("active_low", 0.20, 3.00, True),
    ("active_center", 0.56, 4.35, True),
    ("active_high", 2.00, 5.50, True),
    ("active_size5", 5.00, 4.35, True),
    ("X_fixed_baseline", 0.56, 4.35, False),
    ("X_fixed_lower", 0.56, 3.62, False),
]


def covariance_diagnostics(project) -> dict:
    cov = project.data["Covariance"]["data"]
    vary = cov.get("varyList", [])
    matrix = np.asarray(cov["covMatrix"], dtype=float)
    diagonal = np.sqrt(np.diag(matrix))
    corr = matrix / np.outer(diagonal, diagonal)
    selected = [name for name in vary if any(tag in name for tag in
                ("Size;i", "Mustrain;i", "Mustrain;a", ":U", ":W", ":X"))]
    correlations = {}
    for i, first in enumerate(selected):
        for second in selected[i + 1:]:
            value = float(corr[vary.index(first), vary.index(second)])
            if abs(value) >= 0.5:
                correlations[f"{first}|{second}"] = value
    return {
        "sigmas": {name: float(cov["sig"][vary.index(name)]) for name in selected},
        "correlations_abs_ge_0.5": correlations,
    }


def main() -> None:
    G2sc.SetPrintLevel("none")
    OUTDIR.mkdir(parents=True, exist_ok=True)
    rows = []
    for label, size_seed, x_seed, x_refine in TRIALS:
        outfile = (OUTDIR / f"{label}.gpx").resolve()
        project = G2sc.G2Project(str(BASE.resolve()), newgpx=str(outfile))
        project.set_Controls("cycles", 12)
        hist = project.histogram(0)
        hap = project.phase("SrWO4_scheelite").data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [size_seed, 10.0, 0.5]
        hap["Size"][2][:] = [True, False, False]
        inst = hist.data["Instrument Parameters"][0]
        inst["X"][1] = x_seed
        inst["X"][2] = x_refine
        try:
            project.refine()
            first = metric(project)
            project.refine()
            replay = metric(project)
            project.save()
            terms = phase_terms(project)
            size = terms["SrWO4_scheelite"]["size_micrometre"]
            row = {
                "trial": label,
                "seeds": {"size_micrometre": size_seed, "X": x_seed,
                          "X_refined": x_refine},
                "first": first,
                "replay": replay,
                "global_terms": global_terms(project),
                "phase_terms": terms,
                "covariance": covariance_diagnostics(project),
                "boundary": not 0.001 < size < 9.99,
                "invalid": (not replay["converged"] or not 0.001 < size < 9.99 or
                            any(value["scale"] <= 0 for value in terms.values())),
                "project": str(outfile.relative_to(Path.cwd())),
            }
        except Exception as exc:
            row = {"trial": label, "invalid": True, "error": repr(exc),
                   "project": str(outfile.relative_to(Path.cwd()))}
        rows.append(row)
        print(json.dumps(row, indent=2), flush=True)
    (OUTDIR / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
