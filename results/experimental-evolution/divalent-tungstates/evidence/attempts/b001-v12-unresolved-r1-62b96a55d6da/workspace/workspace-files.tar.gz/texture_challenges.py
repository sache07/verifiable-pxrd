#!/usr/bin/env python3
"""Challenge simple March-Dollase axes from the accepted common checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from term_challenges import global_terms, metric, phase_terms


BASE = Path("trials/checkpoints/07_background8_polarization.gpx")
OUTDIR = Path("trials/texture_challenge")
AXES = {
    "SrWO4_scheelite": [(0, 0, 1), (1, 0, 0), (1, 1, 0),
                         (1, 0, 1), (1, 1, 2)],
    "WO3_monoclinic": [(1, 0, 0), (0, 1, 0), (0, 0, 1),
                        (1, 1, 0), (1, 0, 1), (0, 1, 1)],
    "SrCO3_orthorhombic": [(1, 0, 0), (0, 1, 0), (0, 0, 1),
                            (1, 1, 0), (1, 0, 1), (0, 1, 1)],
}


def ratio_and_sigma(project, phase_name: str) -> tuple[float, float | None, bool]:
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    ratio = float(phase.data["Histograms"][hist.name]["Pref.Ori."][1])
    cov = project.data["Covariance"]["data"]
    variable = f"{phase.id}:{hist.id}:MD"
    vary = cov.get("varyList", [])
    if variable in vary:
        return ratio, float(cov["sig"][vary.index(variable)]), True
    return ratio, None, False


def main() -> None:
    G2sc.SetPrintLevel("none")
    OUTDIR.mkdir(parents=True, exist_ok=True)
    reference = G2sc.G2Project(str(BASE.resolve()))
    reference_metric = metric(reference)
    rows = []
    for phase_name, axes in AXES.items():
        for axis in axes:
            axis_label = "".join(str(x) for x in axis)
            label = f"{phase_name}_MD_{axis_label}"
            outfile = (OUTDIR / f"{label}.gpx").resolve()
            project = G2sc.G2Project(str(BASE.resolve()), newgpx=str(outfile))
            project.set_Controls("cycles", 12)
            hist = project.histogram(0)
            phase = project.phase(phase_name)
            po = phase.data["Histograms"][hist.name]["Pref.Ori."]
            po[:3] = ["MD", 1.0, True]
            po[3] = list(axis)
            try:
                project.refine()
                first_metric = metric(project)
                first_ratio, first_sigma, first_present = ratio_and_sigma(project, phase_name)
                project.refine()
                replay_metric = metric(project)
                ratio, sigma, present = ratio_and_sigma(project, phase_name)
                project.save()
                boundary = not 0.2 < ratio < 5.0
                invalid = (
                    not replay_metric["converged"] or boundary or not present or
                    any(v["scale"] <= 0 for v in phase_terms(project).values())
                )
                row = {
                    "trial": label,
                    "phase": phase_name,
                    "axis": list(axis),
                    "reference": reference_metric,
                    "first": first_metric,
                    "first_ratio": first_ratio,
                    "first_ratio_sigma": first_sigma,
                    "first_variable_present": first_present,
                    "replay": replay_metric,
                    "ratio": ratio,
                    "ratio_sigma": sigma,
                    "variable_present": present,
                    "delta_aic_vs_common": replay_metric["aic"] - reference_metric["aic"],
                    "global_terms": global_terms(project),
                    "phase_terms": phase_terms(project),
                    "boundary": boundary,
                    "invalid": invalid,
                    "project": str(outfile.relative_to(Path.cwd())),
                }
            except Exception as exc:
                row = {
                    "trial": label, "phase": phase_name, "axis": list(axis),
                    "invalid": True, "error": repr(exc),
                    "project": str(outfile.relative_to(Path.cwd())),
                }
            rows.append(row)
            print(json.dumps(row, indent=2), flush=True)
    (OUTDIR / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
