#!/usr/bin/env python3
"""Build and refine trial GSAS-II Rietveld models for the Pb-W-O pattern."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize_hap(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData) -> None:
    """Make all inactive phase profile/texture terms physically neutral."""
    hap = phase.data["Histograms"][hist.name]

    size = hap["Size"]
    size[0] = "isotropic"
    size[1][0] = 10.0
    if len(size[1]) > 1:
        size[1][1] = 10.0
    size[2] = [False for _ in size[2]]
    if len(size) > 4:
        size[4] = [10.0 for _ in size[4]]
    if len(size) > 5:
        size[5] = [False for _ in size[5]]

    strain = hap["Mustrain"]
    strain[0] = "isotropic"
    # First two entries are the isotropic/equatorial and axial microstrain.
    strain[1][0] = 0.0
    if len(strain[1]) > 1:
        strain[1][1] = 0.0
    strain[2] = [False for _ in strain[2]]
    if len(strain) > 4:
        strain[4] = [0.0 for _ in strain[4]]
    if len(strain) > 5:
        strain[5] = [False for _ in strain[5]]

    pref = hap["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = False

    for key in ("BabA", "BabU"):
        hap["Babinet"][key] = [0.0, False]
    hap["Extinction"] = [0.0, False]


def initialize_histogram(hist: G2sc.G2PwdrData, n_background: int) -> None:
    hist.set_refinements(
        {
            "Limits": [float(hist.getdata("X")[0]), float(hist.getdata("X")[-1])],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": n_background,
            },
        }
    )
    inst = hist.InstrumentParameters
    for key, value in {
        "Zero": 0.42,
        "U": 20.0,
        "V": 0.0,
        "W": 100.0,
        "X": 0.10,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "I(L2)/I(L1)": 0.5,
        "Polariz.": 0.5,
    }.items():
        if key in inst:
            inst[key][1] = value
            inst[key][2] = False

    sample = hist.SampleParameters
    if "Scale" in sample:
        sample["Scale"][0] = 1.0
        sample["Scale"][1] = False
    for key in ("SurfRoughA", "SurfRoughB"):
        if key in sample:
            sample[key][0] = 0.0
            sample[key][1] = False
    for key in ("Shift", "Transparency"):
        if key in sample:
            sample[key][0] = 0.0
            sample[key][1] = False


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": list(hap["Scale"]),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    result = {
        "label": label,
        "residuals": hist.residuals,
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "Nobs": cov.get("Rvals", {}).get("Nobs"),
        "Nvars": cov.get("Rvals", {}).get("Nvars"),
        "instrument": {
            key: list(value) if isinstance(value, list) else value
            for key, value in hist.InstrumentParameters.items()
        },
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": phases,
        "frozen": project.get_Frozen(),
    }
    try:
        result["mass_fractions"] = {
            key: list(value) for key, value in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        result["mass_fraction_error"] = str(exc)
    print(json.dumps(result, indent=2, default=str))
    return result


def refine_once(project: G2sc.G2Project, label: str, records: list[dict]) -> None:
    project.set_Frozen()
    project.refine(makeBack=False)
    records.append(snapshot(project, label))


def build_and_refine(
    output: Path,
    phase_specs: list[tuple[str, str]],
    n_background: int,
    profile_mode: str,
) -> list[dict]:
    if output.exists():
        output.unlink()
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "cu_ka.instprm", fmthint="comma"
    )
    initialize_histogram(hist, n_background)

    for phase_name, cod_id in phase_specs:
        phase = project.add_phase(
            str(cod_path(cod_id)),
            phasename=phase_name,
            histograms=[hist],
            fmthint="CIF",
        )
        neutralize_hap(phase, hist)
        phase.data["Histograms"][hist.name]["Scale"] = [1.0, False]

    project.save()
    project.set_Controls("cycles", 12)
    # Enforce physically meaningful common profile and nonnegative phase scales.
    for name in (":0:U", ":0:W", ":0:X"):
        project.set_Controls("parmMin", 0.0, variable=name)
    for phase in project.phases():
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")

    records: list[dict] = []
    # Stage 1: background and scales from a close angular starting correction.
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, [hist])
    refine_once(project, "background_scales", records)

    # Stage 2: cells plus the single angular correction (zero).
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_once(project, "cells_zero", records)

    # Stage 3: low-dimensional common profile, with V/Y/Z fixed at zero.
    profile_terms = ["U", "W", "X"]
    if profile_mode == "uw":
        profile_terms = ["U", "W"]
    hist.set_refinements({"Instrument Parameters": profile_terms})
    refine_once(project, f"common_profile_{profile_mode}", records)

    # Replay the coupled baseline until convergence.
    refine_once(project, "baseline_replay_1", records)
    refine_once(project, "baseline_replay_2", records)
    project.save()
    return records


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("trial.gpx"))
    parser.add_argument("--background", type=int, default=8)
    parser.add_argument("--profile", choices=["uw", "uwx"], default="uwx")
    parser.add_argument(
        "--phase",
        action="append",
        nargs=2,
        metavar=("NAME", "COD_ID"),
        help="Repeat for each phase; defaults to the three-phase Pb-W-O model.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    phase_specs = args.phase or [
        ("PbWO4_scheelite", "9009811"),
        ("WO3_monoclinic", "2311041"),
        ("Pb3O4_tetragonal", "9012124"),
    ]
    records = build_and_refine(
        args.output.resolve(), phase_specs, args.background, args.profile
    )
    args.output.with_suffix(".json").write_text(
        json.dumps(records, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
