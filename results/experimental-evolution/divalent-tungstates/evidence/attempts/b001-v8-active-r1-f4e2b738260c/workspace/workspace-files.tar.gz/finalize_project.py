#!/usr/bin/env python3
"""Prune the accepted model, replay it, reopen it and save final.gpx."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from run_refinement import neutralize_hap, snapshot


SOURCE = Path("weak_u010.gpx")
OUTPUT = Path("final.gpx")
OLD_WEAK_NAME = "Pb3WO6_watch_final"
NEW_WEAK_NAME = "Pb3WO6_like_Pnma"


def normalize_model(project: G2sc.G2Project) -> None:
    hist = project.histograms()[0]
    project.set_Controls("cycles", 15)
    project.set_Frozen()

    # Full measured range, a 12-term smooth background, and the accepted
    # low-dimensional common angular/profile model.
    hist.set_refinements(
        {
            "Limits": [float(hist.getdata("X")[0]), float(hist.getdata("X")[-1])],
            "Background": {"refine": True},
        }
    )
    inst = hist.InstrumentParameters
    for key in ("U", "V", "Y", "Z"):
        inst[key][1] = 0.0
        inst[key][2] = False
    for key in ("W", "X", "Zero"):
        inst[key][2] = True
    inst["SH/L"][1] = 0.002
    inst["SH/L"][2] = False
    inst["Polariz."][1] = 1.0
    inst["Polariz."][2] = False
    inst["I(L2)/I(L1)"][1] = 0.5
    inst["I(L2)/I(L1)"][2] = False
    project.set_Controls("parmMin", 0.0, variable=":0:W")
    project.set_Controls("parmMin", 0.0, variable=":0:X")

    sample = hist.SampleParameters
    sample["Scale"] = [1.0, False]
    for key in ("SurfRoughA", "SurfRoughB", "Shift", "Transparency"):
        if key in sample:
            sample[key][0] = 0.0
            sample[key][1] = False

    broadened = {"PbWO4_scheelite", "Pb3O4_tetragonal"}
    for phase in project.phases():
        if phase.name not in broadened:
            neutralize_hap(phase, hist)
        else:
            hap = phase.data["Histograms"][hist.name]
            hap["Size"][0] = "isotropic"
            hap["Size"][2] = [True, False, False]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][1][1] = 0.0
            hap["Mustrain"][2] = [False, False, False]
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
            project.set_Controls("parmMin", 0.005, variable=f"{phase.id}:0:Size;i")
            project.set_Controls("parmMax", 10.0, variable=f"{phase.id}:0:Size;i")
        phase.set_HAP_refinements({"Scale": True}, [hist])
        phase.set_refinements({"Cell": True})
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")

        if phase.name == NEW_WEAK_NAME:
            for atom in phase.atoms():
                atom.uiso = 0.010
                atom.refinement_flags = ""


def replay(project: G2sc.G2Project, label: str) -> dict:
    project.set_Frozen()
    project.refine(makeBack=False)
    row = snapshot(project, label)
    row["uiso"] = {
        phase.name: {atom.label: atom.uiso for atom in phase.atoms()}
        for phase in project.phases()
    }
    return row


def main() -> None:
    project = G2sc.G2Project(str(SOURCE.resolve()))
    phases = project.data["Phases"]
    if OLD_WEAK_NAME in phases:
        weak = phases.pop(OLD_WEAK_NAME)
        weak["General"]["Name"] = NEW_WEAK_NAME
        phases[NEW_WEAK_NAME] = weak
        for tree_item in project.names:
            for index, name in enumerate(tree_item):
                if name == OLD_WEAK_NAME:
                    tree_item[index] = NEW_WEAK_NAME
    project.save(str(OUTPUT.resolve()))

    # Reload after renaming so all wrappers and IDs reflect the final names.
    project = G2sc.G2Project(str(OUTPUT.resolve()))
    normalize_model(project)
    project.save()
    records = [replay(project, f"final_replay_{index}") for index in range(1, 4)]
    project.save()

    # Required final saved-project audit: reopen and replay over the full range.
    reopened = G2sc.G2Project(str(OUTPUT.resolve()))
    normalize_model(reopened)
    records.append(replay(reopened, "reopened_full_range_replay"))
    reopened.save()
    OUTPUT.with_suffix(".json").write_text(
        json.dumps(records, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
