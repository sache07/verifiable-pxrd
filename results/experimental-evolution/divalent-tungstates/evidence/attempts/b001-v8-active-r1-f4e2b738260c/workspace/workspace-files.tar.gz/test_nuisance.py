#!/usr/bin/env python3
"""Replay background, polarization and roughness alternatives from one baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from run_refinement import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument(
        "mode",
        choices=[
            "background12",
            "background16",
            "polarization",
            "roughness",
            "background12_pol",
            "background16_pol",
            "pol_roughness",
            "background12_pol_roughness",
        ],
    )
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.baseline.resolve()))
    project.save(str(args.output.resolve()))
    project.set_Controls("cycles", 15)
    project.set_Frozen()
    hist = project.histograms()[0]
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters

    # Start every comparison from the same neutral optional terms.
    inst["Polariz."][1] = 0.5
    inst["Polariz."][2] = False
    for key in ("SurfRoughA", "SurfRoughB"):
        sample[key][0] = 0.0
        sample[key][1] = False

    if args.mode in ("background12", "background12_pol", "background12_pol_roughness"):
        hist.set_refinements({"Background": {"refine": True, "no. coeffs": 12}})
    elif args.mode in ("background16", "background16_pol"):
        hist.set_refinements({"Background": {"refine": True, "no. coeffs": 16}})

    if args.mode in (
        "polarization",
        "background12_pol",
        "background16_pol",
        "pol_roughness",
        "background12_pol_roughness",
    ):
        inst["Polariz."][2] = True
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")

    if args.mode in ("roughness", "pol_roughness", "background12_pol_roughness"):
        sample["SurfRoughA"] = [0.5, True]
        sample["SurfRoughB"] = [0.01, True]
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 5.0, variable=":0:SurfRoughB")

    records = []
    for index in range(1, 5):
        project.set_Frozen()
        project.refine(makeBack=False)
        records.append(snapshot(project, f"{args.mode}_replay_{index}"))
    project.save()
    args.output.with_suffix(".json").write_text(
        json.dumps(records, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
