#!/usr/bin/env python3
"""Generate charge-balanced Pb-W-O watch-list structures from exact analogues."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = Path("candidates")


def source(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def convert(cod_id: str, substitutions: dict[str, str], output: str) -> None:
    structure = Structure.from_file(source(cod_id))
    structure.replace_species(substitutions)
    CifWriter(structure, symprec=0.01).write_file(OUT / output)


def normalize(cod_id: str, output: str) -> None:
    structure = Structure.from_file(source(cod_id))
    CifWriter(structure, symprec=0.01).write_file(OUT / output)


def main() -> None:
    OUT.mkdir(exist_ok=True)
    convert("7220560", {"Mo": "W"}, "Pb2WO5_from_Pb2MoO5_7220560.cif")
    convert("2310493", {"U": "W"}, "Pb3WO6_from_UPb3O6_2310493.cif")
    convert("1527404", {"Cu": "Pb"}, "Pb3WO6_from_Cu3WO6_1527404.cif")
    normalize("1527935", "PbWO4_scheelite_1527935_normalized.cif")
    normalize("9007617", "PbWO4_monoclinic_9007617_normalized.cif")
    normalize("1563541", "WO3_1563541_normalized.cif")
    normalize("9013442", "Pb3O4_orthorhombic_9013442_normalized.cif")


if __name__ == "__main__":
    main()
