#!/usr/bin/env python3
"""Replace one phase with a competitor and replay the accepted nuisance model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from run_refinement import neutralize_hap, snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("old_name")
    parser.add_argument("candidate", type=Path)
    parser.add_argument("new_name")
    parser.add_argument("output", type=Path)
    parser.add_argument("--broaden", action="store_true")
    parser.add_argument("--uiso", type=float, default=0.02)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.baseline.resolve()))
    project.save(str(args.output.resolve()))
    project.set_Frozen()
    project.set_Controls("cycles", 15)
    hist = project.histograms()[0]
    old = project.phase(args.old_name)
    old_hap = old.data["Histograms"][hist.name]
    old_scale = float(old_hap["Scale"][0])
    old_size = float(old_hap["Size"][1][0])
    old_hap["Use"] = False
    old_hap["Scale"][1] = False
    old.data["General"]["Cell"][0] = False
    for atom in old.atoms():
        atom.refinement_flags = " "

    new = project.add_phase(
        str(args.candidate.resolve()),
        phasename=args.new_name,
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize_hap(new, hist)
    new_hap = new.data["Histograms"][hist.name]
    new_hap["Scale"] = [old_scale, True]
    new.data["General"]["Cell"][0] = False
    project.set_Controls("parmMin", 0.0, variable=f"{new.id}:0:Scale")
    if args.broaden:
        new.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": old_size, "refine": True}}, [hist]
        )
        project.set_Controls("parmMin", 0.005, variable=f"{new.id}:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{new.id}:0:Size;i")

    project.index_ids()
    atoms = new.atoms()
    if all(atom.adp_flag == "I" for atom in atoms):
        for atom in atoms:
            atom.uiso = args.uiso
            atom.refinement_flags = "U"
        variables = [f"{new.id}::AUiso:{index}" for index in range(len(atoms))]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
        project.set_Controls("parmMin", 0.0, variable=variables[0])
        project.set_Controls("parmMax", 0.05, variable=variables[0])
    else:
        for atom in atoms:
            atom.refinement_flags = " "
    project.save()

    records = []
    for index in range(1, 5):
        project.set_Frozen()
        project.refine(makeBack=False)
        row = snapshot(project, f"replacement_replay_{index}")
        row["replacement_adp"] = {atom.label: atom.ADP for atom in new.atoms()}
        records.append(row)
        if index == 1:
            scale = float(new.data["Histograms"][hist.name]["Scale"][0])
            if scale > 0.01 * old_scale:
                new.data["General"]["Cell"][0] = True
    project.save()
    args.output.with_suffix(".json").write_text(
        json.dumps(records, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
