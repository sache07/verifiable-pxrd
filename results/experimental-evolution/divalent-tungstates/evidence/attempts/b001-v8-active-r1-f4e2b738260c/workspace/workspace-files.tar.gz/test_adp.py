#!/usr/bin/env python3
"""Test restrained phase-wide isotropic displacement parameters."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from run_refinement import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("mode", choices=["zero_sources", "all_phases"])
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.baseline.resolve()))
    project.save(str(args.output.resolve()))
    project.set_Controls("cycles", 15)
    project.set_Frozen()
    selected = project.phases()
    if args.mode == "zero_sources":
        selected = [phase for phase in selected if phase.name in ("WO3_monoclinic", "PbO_massicot_simple")]

    project.index_ids()
    for phase in selected:
        atoms = phase.atoms()
        start = max(0.003, sum(max(0.0, atom.uiso) for atom in atoms) / len(atoms))
        for atom in atoms:
            atom.uiso = start
            atom.refinement_flags = "U"
        variables = [f"{phase.id}::AUiso:{index}" for index in range(len(atoms))]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
        project.set_Controls("parmMin", 0.0, variable=variables[0])
        project.set_Controls("parmMax", 0.05, variable=variables[0])

    project.save()
    records = []
    for index in range(1, 5):
        project.set_Frozen()
        project.refine(makeBack=False)
        row = snapshot(project, f"{args.mode}_replay_{index}")
        row["uiso"] = {
            phase.name: {atom.label: atom.uiso for atom in phase.atoms()}
            for phase in project.phases()
        }
        records.append(row)
    project.save()
    args.output.with_suffix(".json").write_text(
        json.dumps(records, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
