#!/usr/bin/env python3
"""Export final CIFs, profile data and the machine-readable result summary."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


PROJECT = Path("final.gpx")
PROFILE = Path("fit.csv")
RESULT = Path("result.json")

PHASE_INFO = {
    "PbWO4_scheelite": {
        "display_name": "PbWO4 (scheelite)",
        "formula": "PbWO4",
        "cif_path": "PbWO4_scheelite.cif",
        "structure_status": "identified",
    },
    "WO3_monoclinic": {
        "display_name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif_path": "WO3_monoclinic.cif",
        "structure_status": "identified",
    },
    "Pb3O4_tetragonal": {
        "display_name": "Pb3O4 (tetragonal minium)",
        "formula": "Pb3O4",
        "cif_path": "Pb3O4_tetragonal.cif",
        "structure_status": "identified",
    },
    "PbO_massicot_simple": {
        "display_name": "PbO (orthorhombic massicot)",
        "formula": "PbO",
        "cif_path": "PbO_massicot.cif",
        "structure_status": "identified",
    },
    "Pb3WO6_like_Pnma": {
        "display_name": "Pb3WO6-like (Pnma analogue)",
        "formula": "Pb3WO6",
        "cif_path": "Pb3WO6_like_Pnma.cif",
        "structure_status": "tentative analogue; exact structure not reliable",
    },
}


def main() -> None:
    project = G2sc.G2Project(str(PROJECT.resolve()))
    hist = project.histograms()[0]

    mass = hist.ComputeMassFracs()
    total = sum(float(value[0]) for value in mass.values())
    phases = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        phase.export_CIF(info["cif_path"])
        fraction, esd = mass[phase.name]
        phases.append(
            {
                "name": info["display_name"],
                "formula": info["formula"],
                "cif_path": info["cif_path"],
                "weight_fraction": float(fraction) / total,
                "weight_fraction_esd_formal": float(esd) / total,
                "structure_status": info["structure_status"],
            }
        )

    x = np.asarray(hist.getdata("X"), dtype=float)
    observed = np.asarray(hist.getdata("Yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("Ycalc"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)
    with PROFILE.open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "difference", "background"]
        )
        writer.writerows(zip(x, observed, calculated, observed - calculated, background))

    rvals = project.data["Covariance"]["data"]["Rvals"]
    fit_statistics = {
        "r_wp_percent": float(hist.residuals["wR"]),
        "r_p_percent": float(hist.residuals["R"]),
        "r_exp_percent": float(hist.residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_square": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_parameters": int(rvals["Nvars"]),
        "max_shift_over_esd": float(rvals["Max shft/sig"]),
        "converged": bool(rvals["converged"]),
        "two_theta_range_deg": [float(x[0]), float(x[-1])],
        "weighting": "Poisson counting approximation, w = 1 / observed counts",
    }
    result = {
        "project_path": PROJECT.name,
        "fit_path": PROFILE.name,
        "weight_fraction_basis": "normalized over modeled crystalline phases",
        "phases": phases,
        "fit_statistics": fit_statistics,
    }
    RESULT.write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
