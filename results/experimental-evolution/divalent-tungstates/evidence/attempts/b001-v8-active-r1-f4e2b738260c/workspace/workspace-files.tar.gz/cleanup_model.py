#!/usr/bin/env python3
"""Prune unsupported terms and replay a saved GSAS-II model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from run_refinement import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--replays", type=int, default=4)
    parser.add_argument("--fix-polarization", action="store_true")
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()))
    project.save(str(args.output.resolve()))
    project.set_Controls("cycles", 15)
    project.set_Frozen()
    hist = project.histograms()[0]

    inst = hist.InstrumentParameters
    # U repeatedly reached its physical zero bound; V/Y/Z and asymmetry are neutral.
    for key in ("U", "V", "Y", "Z"):
        inst[key][1] = 0.0
        inst[key][2] = False
    for key in ("W", "X", "Zero"):
        inst[key][2] = True
    if "SH/L" in inst:
        inst["SH/L"][1] = 0.002
        inst["SH/L"][2] = False
    if args.fix_polarization and "Polariz." in inst:
        inst["Polariz."][1] = 1.0
        inst["Polariz."][2] = False

    sample = hist.SampleParameters
    if "Scale" in sample:
        sample["Scale"] = [1.0, False]
    for key in ("SurfRoughA", "SurfRoughB", "Shift", "Transparency"):
        if key in sample:
            sample[key][0] = 0.0
            sample[key][1] = False

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        strain = hap["Mustrain"]
        strain[0] = "isotropic"
        strain[1][0] = 0.0
        if len(strain[1]) > 1:
            strain[1][1] = 0.0
        strain[2] = [False for _ in strain[2]]
        if len(strain) > 4:
            strain[4] = [0.0 for _ in strain[4]]
        if len(strain) > 5:
            strain[5] = [False for _ in strain[5]]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    records = []
    for index in range(1, args.replays + 1):
        project.set_Frozen()
        project.refine(makeBack=False)
        records.append(snapshot(project, f"clean_replay_{index}"))
    project.save()
    args.output.with_suffix(".json").write_text(
        json.dumps(records, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
