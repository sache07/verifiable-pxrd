#!/usr/bin/env python3
"""Replay the common-profile baseline with targeted phase broadening models."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from run_refinement import neutralize_hap, snapshot


def prepare(project: G2sc.G2Project, output: Path) -> tuple[G2sc.G2PwdrData, list[G2sc.G2Phase]]:
    project.save(str(output.resolve()))
    hist = project.histograms()[0]
    phases = project.phases()
    project.set_Frozen()
    project.set_Controls("cycles", 15)

    sample = hist.SampleParameters
    if "Scale" in sample:
        sample["Scale"] = [1.0, False]
    for key in ("SurfRoughA", "SurfRoughB", "Shift", "Transparency"):
        if key in sample:
            sample[key][0] = 0.0
            sample[key][1] = False

    for phase in phases:
        neutralize_hap(phase, hist)
        phase.set_HAP_refinements({"Scale": True}, [hist])
        phase.set_refinements({"Cell": True})

    inst = hist.InstrumentParameters
    for key, value in {"U": 0.0, "V": 0.0, "W": 50.0, "X": 5.0, "Y": 0.0, "Z": 0.0}.items():
        inst[key][1] = value
        inst[key][2] = False
    for key in ("W", "X", "Zero"):
        inst[key][2] = True
    for name in (":0:W", ":0:X"):
        project.set_Controls("parmMin", 0.0, variable=name)
    return hist, phases


def configure_model(
    project: G2sc.G2Project,
    hist: G2sc.G2PwdrData,
    phases: list[G2sc.G2Phase],
    model: str,
) -> None:
    broadened = [phases[0], phases[2]]  # anchor sharp WO3 as common-profile reference
    if model in ("size", "size_strain"):
        for phase in broadened:
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 0.10, "refine": True}},
                [hist],
            )
            project.set_Controls(
                "parmMin", 0.005, variable=f"{phase.id}:0:Size;i"
            )
            project.set_Controls(
                "parmMax", 10.0, variable=f"{phase.id}:0:Size;i"
            )
    if model in ("strain", "size_strain"):
        for phase in broadened:
            hap = phase.data["Histograms"][hist.name]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 500.0
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
            )
            project.set_Controls(
                "parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i"
            )
    if model == "common_only":
        pass


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("model", choices=["common_only", "size", "strain", "size_strain"])
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.baseline.resolve()))
    hist, phases = prepare(project, args.output)
    configure_model(project, hist, phases, args.model)
    records = []
    for index in range(1, 5):
        project.set_Frozen()
        project.refine(makeBack=False)
        records.append(snapshot(project, f"{args.model}_replay_{index}"))
    project.save()
    args.output.with_suffix(".json").write_text(
        json.dumps(records, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
