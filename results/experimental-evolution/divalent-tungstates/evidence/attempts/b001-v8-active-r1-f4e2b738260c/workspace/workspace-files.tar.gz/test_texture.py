#!/usr/bin/env python3
"""Test one restrained March-Dollase term against the final baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from run_refinement import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("phase")
    parser.add_argument("hkl", nargs=3, type=int)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.baseline.resolve()))
    project.save(str(args.output.resolve()))
    project.set_Controls("cycles", 15)
    project.set_Frozen()
    hist = project.histograms()[0]
    phase = project.phase(args.phase)
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 0.95
    pref[2] = True
    pref[3] = list(args.hkl)
    project.set_Controls("parmMin", 0.2, variable=f"{phase.id}:0:MD")
    project.set_Controls("parmMax", 5.0, variable=f"{phase.id}:0:MD")
    project.save()

    records = []
    for index in range(1, 5):
        project.set_Frozen()
        project.refine(makeBack=False)
        row = snapshot(project, f"texture_replay_{index}")
        row["texture_phase"] = phase.name
        row["texture_hkl"] = list(args.hkl)
        row["march_ratio"] = float(pref[1])
        records.append(row)
    project.save()
    args.output.with_suffix(".json").write_text(
        json.dumps(records, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
