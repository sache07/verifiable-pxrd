#!/usr/bin/env python3
"""Export and numerically inspect a GSAS-II powder-profile fit."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from GSASII import GSASIIscriptable as G2sc
from scipy.signal import savgol_filter


CHECKS = [
    ("WO3 low", 23.53, 0.22),
    ("WO3 low-2", 24.02, 0.22),
    ("PbWO4 low", 27.81, 0.38),
    ("Pb3O4 low", 31.22, 0.30),
    ("PbWO4 middle", 45.13, 0.45),
    ("Pb3O4 middle", 52.52, 0.35),
    ("Pb3O4 high", 66.40, 0.42),
    ("PbWO4 high", 86.00, 0.55),
]


def half_widths(x: np.ndarray, y: np.ndarray, target: float, window: float) -> dict:
    use = (x >= target - window) & (x <= target + window)
    xx = x[use]
    yy = np.asarray(y[use], dtype=float)
    if len(xx) < 7:
        return {"error": "insufficient points"}
    # Mild smoothing suppresses point noise without materially changing broad peaks.
    if len(yy) >= 9:
        yy = savgol_filter(yy, 7, 2)
    peak_index = int(np.argmax(yy))
    peak_x = float(xx[peak_index])
    peak_y = float(yy[peak_index])
    half = peak_y / 2.0

    left_cross = None
    for i in range(peak_index - 1, -1, -1):
        if yy[i] <= half <= yy[i + 1]:
            left_cross = float(np.interp(half, [yy[i], yy[i + 1]], [xx[i], xx[i + 1]]))
            break
    right_cross = None
    for i in range(peak_index, len(xx) - 1):
        if yy[i] >= half >= yy[i + 1]:
            right_cross = float(np.interp(half, [yy[i + 1], yy[i]], [xx[i + 1], xx[i]]))
            break
    return {
        "position": peak_x,
        "height_above_background": peak_y,
        "left_hwhm": None if left_cross is None else peak_x - left_cross,
        "right_hwhm": None if right_cross is None else right_cross - peak_x,
        "fwhm": None if left_cross is None or right_cross is None else right_cross - left_cross,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx", type=Path)
    parser.add_argument("--prefix", type=Path)
    args = parser.parse_args()
    prefix = args.prefix or args.gpx.with_suffix("")

    project = G2sc.G2Project(str(args.gpx))
    hist = project.histograms()[0]
    x = np.asarray(hist.getdata("X"), float)
    obs = np.asarray(hist.getdata("Yobs"), float)
    calc = np.asarray(hist.getdata("Ycalc"), float)
    background = np.asarray(hist.getdata("Background"), float)
    difference = obs - calc

    csv_path = prefix.with_name(prefix.name + "_fit.csv")
    with csv_path.open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference", "background"])
        writer.writerows(zip(x, obs, calc, difference, background))

    checks = []
    for label, target, window in CHECKS:
        checks.append(
            {
                "label": label,
                "target": target,
                "observed": half_widths(x, obs - background, target, window),
                "calculated": half_widths(x, calc - background, target, window),
            }
        )
    json_path = prefix.with_name(prefix.name + "_peak_checks.json")
    json_path.write_text(json.dumps(checks, indent=2) + "\n")

    offset = -0.18 * np.max(obs)
    fig, axes = plt.subplots(2, 1, figsize=(16, 9), constrained_layout=True)
    axes[0].plot(x, obs, color="black", lw=0.55, label="observed")
    axes[0].plot(x, calc, color="tab:red", lw=0.65, label="calculated")
    axes[0].plot(x, difference + offset, color="tab:blue", lw=0.5, label="difference (offset)")
    axes[0].set(xlim=(x.min(), x.max()), ylabel="counts")
    axes[0].legend(loc="upper right")
    axes[1].plot(x, difference / np.sqrt(np.maximum(obs, 1.0)), color="black", lw=0.5)
    axes[1].axhline(0, color="tab:red", lw=0.6)
    axes[1].set(xlim=(x.min(), x.max()), xlabel=r"$2\theta$ (deg)", ylabel=r"$(I_o-I_c)/\sqrt{I_o}$")
    fig.savefig(prefix.with_name(prefix.name + "_fit.png"), dpi=170)

    print(json.dumps({"fit_csv": str(csv_path), "peak_checks": checks}, indent=2))


if __name__ == "__main__":
    main()
