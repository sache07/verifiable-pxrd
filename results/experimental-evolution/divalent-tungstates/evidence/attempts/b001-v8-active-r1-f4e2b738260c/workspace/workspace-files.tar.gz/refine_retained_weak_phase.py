#!/usr/bin/env python3
"""Apply the same restrained ADP model to a retained weak phase and replay."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from run_refinement import neutralize_hap, snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("phase_name")
    parser.add_argument("output", type=Path)
    parser.add_argument("--size", action="store_true")
    parser.add_argument("--fixed-uiso", type=float)
    parser.add_argument("--replays", type=int, default=5)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()))
    project.save(str(args.output.resolve()))
    project.set_Controls("cycles", 15)
    project.set_Frozen()
    project.index_ids()
    hist = project.histograms()[0]
    phase = project.phase(args.phase_name)

    # Reassert all inactive nuisance terms at physical neutral values. Keep the
    # accepted PbWO4/Pb3O4 size terms, which are already active in the source.
    neutralize_hap(phase, hist)
    phase.set_HAP_refinements({"Scale": True}, [hist])
    phase.set_refinements({"Cell": True})

    atoms = phase.atoms()
    if args.fixed_uiso is None:
        start = max(0.003, sum(max(0.0, atom.uiso) for atom in atoms) / len(atoms))
        for atom in atoms:
            atom.uiso = start
            atom.refinement_flags = "U"
        variables = [f"{phase.id}::AUiso:{index}" for index in range(len(atoms))]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
        project.set_Controls("parmMin", 0.0, variable=variables[0])
        project.set_Controls("parmMax", 0.05, variable=variables[0])
    else:
        for atom in atoms:
            atom.uiso = args.fixed_uiso
            atom.refinement_flags = ""

    if args.size:
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 0.20, "refine": True}},
            [hist],
        )
        project.set_Controls("parmMin", 0.005, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{phase.id}:0:Size;i")

    project.save()
    records = []
    for index in range(1, args.replays + 1):
        project.set_Frozen()
        project.refine(makeBack=False)
        row = snapshot(project, f"retained_replay_{index}")
        row["uiso"] = {
            item.name: {atom.label: atom.uiso for atom in item.atoms()}
            for item in project.phases()
        }
        records.append(row)
    project.save()
    args.output.with_suffix(".json").write_text(
        json.dumps(records, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
