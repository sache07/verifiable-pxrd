#!/usr/bin/env python3
"""Extract conservative peak candidates and make a diagnostic PXRD plot."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import sparse
from scipy.signal import find_peaks, peak_widths
from scipy.sparse.linalg import spsolve


def arpls(y: np.ndarray, lam: float = 2e7, ratio: float = 1e-5) -> np.ndarray:
    """Asymmetrically reweighted penalized least-squares baseline."""
    n = y.size
    d = sparse.diags([1.0, -2.0, 1.0], [0, 1, 2], shape=(n - 2, n))
    h = lam * (d.T @ d)
    w = np.ones(n)
    for _ in range(80):
        z = spsolve(h + sparse.spdiags(w, 0, n, n), w * y)
        residual = y - z
        negative = residual[residual < 0]
        mean = negative.mean()
        std = negative.std()
        new_w = 1.0 / (1.0 + np.exp(np.clip(2.0 * (residual - (2 * std - mean)) / std, -50, 50)))
        if np.linalg.norm(new_w - w) / np.linalg.norm(w) < ratio:
            return z
        w = new_w
    return z


def main() -> None:
    frame = pd.read_csv("inputs/pattern.csv")
    x = frame.iloc[:, 0].to_numpy(float)
    y = frame.iloc[:, 1].to_numpy(float)
    baseline = arpls(y)
    signal = y - baseline
    step = np.median(np.diff(x))
    # Require at least ~0.065 degree separation and a conservative prominence.
    peaks, props = find_peaks(signal, prominence=175, distance=max(1, round(0.065 / step)))
    widths, _, left, right = peak_widths(signal, peaks, rel_height=0.5)
    order = np.argsort(props["prominences"])[::-1]
    print("rank,two_theta,intensity,baseline,prominence,FWHM_deg,d_A")
    wavelength = 1.540598
    for rank, idx in enumerate(order[:120], 1):
        p = peaks[idx]
        theta = np.deg2rad(x[p] / 2)
        dspace = wavelength / (2 * np.sin(theta))
        print(
            f"{rank},{x[p]:.5f},{y[p]:.1f},{baseline[p]:.1f},"
            f"{props['prominences'][idx]:.1f},{widths[idx] * step:.5f},{dspace:.5f}"
        )

    fig, axes = plt.subplots(2, 1, figsize=(15, 8), constrained_layout=True)
    axes[0].plot(x, y, lw=0.55, color="black")
    axes[0].plot(x, baseline, lw=0.8, color="tab:red")
    axes[0].set(xlim=(x.min(), x.max()), ylabel="counts")
    axes[1].plot(x, signal, lw=0.55, color="black")
    axes[1].scatter(x[peaks], signal[peaks], s=8, color="tab:blue")
    axes[1].set(xlim=(x.min(), x.max()), xlabel=r"$2\theta$ (deg)", ylabel="baseline-subtracted")
    fig.savefig("pattern_diagnostic.png", dpi=170)


if __name__ == "__main__":
    main()
