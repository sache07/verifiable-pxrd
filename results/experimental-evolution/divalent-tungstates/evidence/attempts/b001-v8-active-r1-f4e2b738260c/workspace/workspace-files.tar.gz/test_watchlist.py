#!/usr/bin/env python3
"""Add one watch-list phase to a converged model and replay all nuisance terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from run_refinement import neutralize_hap, snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("name")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.baseline.resolve()))
    project.save(str(args.output.resolve()))
    project.set_Frozen()
    project.set_Controls("cycles", 15)
    hist = project.histograms()[0]
    if "Scale" in hist.SampleParameters:
        hist.SampleParameters["Scale"] = [1.0, False]

    phase = project.add_phase(
        str(args.candidate.resolve()),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize_hap(phase, hist)
    phase.data["Histograms"][hist.name]["Scale"] = [0.01, True]
    phase.data["General"]["Cell"][0] = False
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
    project.save()

    records = []
    for index in range(1, 4):
        project.set_Frozen()
        project.refine(makeBack=False)
        records.append(snapshot(project, f"watch_replay_{index}"))
        scale = phase.data["Histograms"][hist.name]["Scale"][0]
        if index == 1 and scale > 1e-8:
            phase.set_refinements({"Cell": True})
    project.save()
    args.output.with_suffix(".json").write_text(
        json.dumps(records, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
