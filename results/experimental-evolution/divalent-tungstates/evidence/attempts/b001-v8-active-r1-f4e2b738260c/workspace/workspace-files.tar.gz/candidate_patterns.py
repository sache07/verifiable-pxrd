#!/usr/bin/env python3
"""Print and plot calculated Cu K-alpha1 stick patterns for candidate phases."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy import sparse
from scipy.optimize import least_squares
from scipy.signal import find_peaks
from scipy.sparse.linalg import spsolve


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
IDS = [
    "1527935", "9009811", "9007617",  # PbWO4
    "1528915", "1563541", "2311041", "1010618", "1004057",  # WO3
    "1533609", "9012700",  # PbO
    "1537983", "9003043",  # Pb3O4
]


def source(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def baseline(y: np.ndarray, lam: float = 2e7) -> np.ndarray:
    n = len(y)
    d = sparse.diags([1.0, -2.0, 1.0], [0, 1, 2], shape=(n - 2, n))
    h = lam * (d.T @ d)
    w = np.ones(n)
    for _ in range(60):
        z = spsolve((h + sparse.spdiags(w, 0, n, n)).tocsc(), w * y)
        r = y - z
        neg = r[r < 0]
        mu, sigma = neg.mean(), neg.std()
        new = 1 / (1 + np.exp(np.clip(2 * (r - (2 * sigma - mu)) / sigma, -50, 50)))
        if np.linalg.norm(new - w) / np.linalg.norm(w) < 1e-5:
            break
        w = new
    return z


def main() -> None:
    data = pd.read_csv("inputs/pattern.csv")
    x = data.iloc[:, 0].to_numpy(float)
    y = data.iloc[:, 1].to_numpy(float)
    corrected = y - baseline(y)
    obs_idx, obs_props = find_peaks(corrected, prominence=275, distance=7)
    obs_x = x[obs_idx]
    obs_prom = obs_props["prominences"]
    order = np.argsort(obs_prom)[::-1]
    obs_x, obs_prom = obs_x[order], obs_prom[order]

    calc = XRDCalculator(wavelength=1.540598, symprec=0.05)
    patterns = {}
    print("Candidate calculated sticks (intensity >= 2%):")
    for cod_id in IDS:
        structure = Structure.from_file(source(cod_id))
        pattern = calc.get_pattern(structure, two_theta_range=(9.8, 100.2), scaled=True)
        px = np.array(pattern.x)
        py = np.array(pattern.y)
        keep = py >= 2.0
        px, py = px[keep], py[keep]
        patterns[cod_id] = (structure, px, py)
        sticks = " ".join(f"{a:.3f}({b:.0f})" for a, b in zip(px, py))
        print(f"{cod_id} {structure.composition.reduced_formula} {structure.get_space_group_info()}: {sticks}")

    fig, axes = plt.subplots(len(IDS) + 1, 1, figsize=(15, 15), sharex=True, constrained_layout=True)
    axes[0].plot(x, corrected / corrected.max(), color="black", lw=0.6)
    axes[0].set_ylabel("obs")
    for ax, cod_id in zip(axes[1:], IDS):
        structure, px, py = patterns[cod_id]
        ax.vlines(px, 0, py / 100, color="tab:blue", lw=0.8)
        ax.set_ylim(0, 1.05)
        ax.set_ylabel(cod_id, rotation=0, ha="right", va="center")
    axes[-1].set_xlim(x.min(), x.max())
    axes[-1].set_xlabel(r"$2\theta$ (deg)")
    fig.savefig("candidate_sticks.png", dpi=170)


if __name__ == "__main__":
    main()
