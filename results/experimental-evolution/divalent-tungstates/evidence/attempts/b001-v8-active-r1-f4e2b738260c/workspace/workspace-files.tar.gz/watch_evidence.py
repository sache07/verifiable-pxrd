#!/usr/bin/env python3
"""Check whether candidate stick families align with positive baseline residuals."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from GSASII import GSASIIscriptable as G2sc
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.baseline))
    hist = project.histograms()[0]
    x = np.asarray(hist.getdata("X"), float)
    obs = np.asarray(hist.getdata("Yobs"), float)
    residual = np.asarray(hist.getdata("Residual"), float)
    zero = float(hist.InstrumentParameters["Zero"][1])

    structure = Structure.from_file(args.candidate)
    pattern = XRDCalculator(wavelength=1.540598, symprec=0.05).get_pattern(
        structure, two_theta_range=(x.min() - zero, x.max() - zero), scaled=True
    )
    positions = np.asarray(pattern.x) + zero
    intensities = np.asarray(pattern.y)
    keep = intensities >= 2.0
    positions, intensities = positions[keep], intensities[keep]

    rows = []
    for position, intensity in zip(positions, intensities):
        use = np.abs(x - position) <= 0.12
        z = residual[use] / np.sqrt(np.maximum(obs[use], 1.0))
        rows.append(
            {
                "two_theta": float(position),
                "relative_intensity": float(intensity),
                "mean_standardized_residual": float(np.mean(z)),
                "max_standardized_residual": float(np.max(z)),
                "integrated_residual_counts": float(np.trapz(residual[use], x[use])),
            }
        )
    rows.sort(key=lambda row: row["relative_intensity"], reverse=True)
    args.output.with_suffix(".json").write_text(json.dumps(rows, indent=2) + "\n")

    fig, ax = plt.subplots(figsize=(16, 5), constrained_layout=True)
    zall = residual / np.sqrt(np.maximum(obs, 1.0))
    ax.plot(x, zall, color="black", lw=0.5)
    ax.axhline(0, color="tab:red", lw=0.6)
    height = max(5.0, float(np.percentile(np.abs(zall), 99)))
    ax.vlines(positions, -height, -height + 2 * height * intensities / 100, color="tab:blue", lw=0.8)
    ax.set(
        xlim=(x.min(), x.max()),
        xlabel=r"$2\theta$ (deg)",
        ylabel=r"baseline $(I_o-I_c)/\sqrt{I_o}$ and candidate sticks",
    )
    fig.savefig(args.output.with_suffix(".png"), dpi=170)

    print(json.dumps(rows[:30], indent=2))


if __name__ == "__main__":
    main()
