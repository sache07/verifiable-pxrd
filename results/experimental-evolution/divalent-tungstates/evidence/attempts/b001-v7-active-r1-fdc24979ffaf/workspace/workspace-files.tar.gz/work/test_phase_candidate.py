#!/usr/bin/env python3
"""Add one watch-list phase to the accepted MnWO4+SH/L baseline."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def refine_n(project, n):
    for _ in range(n):
        project.refine()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("name")
    ap.add_argument("cif")
    ap.add_argument("output")
    args = ap.parse_args()
    project = G2sc.G2Project(
        "work/branch_shl.gpx", newgpx=str(Path(args.output).resolve())
    )
    project.set_Controls("cycles", 20)
    hist = project.histogram(0)
    main = project.phase(0)
    candidate = project.add_phase(
        args.cif, phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    hap = candidate.data["Histograms"][hist.name]
    hap["Scale"][0] = 0.01
    candidate.set_HAP_refinements({"Scale": True})
    refine_n(project, 3)
    scale_only = float(hap["Scale"][0])

    if scale_only > 0:
        candidate.set_refinements({"Cell": True})
        main.set_refinements({"Cell": True})
        refine_n(project, 2)
        candidate.clear_refinements({"Cell": True})
        main.clear_refinements({"Cell": True})
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        refine_n(project, 1)
        hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    project.save()

    try:
        fractions = hist.ComputeMassFracs()
    except Exception as exc:
        fractions = {"error": repr(exc)}
    print("CANDIDATE", args.name)
    print("SCALE_ONLY", scale_only)
    print("FINAL_SCALE", hap["Scale"])
    print("RESIDUALS", hist.residuals)
    print("FRACTIONS", fractions)
    print("MAIN_CELL", main.get_cell())
    print("CANDIDATE_CELL", candidate.get_cell())
    print("ZERO_SHL", hist.InstrumentParameters["Zero"], hist.InstrumentParameters["SH/L"])


if __name__ == "__main__":
    main()
