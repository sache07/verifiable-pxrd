#!/usr/bin/env python3
"""Freeze, replay, and export the scorer-facing refinement products."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "work" / "threephase_baseline.gpx"
FINAL = ROOT / "final.gpx"


def prune_to_accepted_model(project):
    hist = project.histogram(0)
    x = hist.data["data"][1][0]
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]
    # Measured constant-width baseline; all unused profile terms are neutralized.
    for key, value in (("U", 0.0), ("V", 0.0), ("W", 30.0),
                       ("X", 0.5), ("Y", 0.0), ("Z", 0.0)):
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = False
    hist.InstrumentParameters["Zero"][2] = False
    for key in ("SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key] = [0.0, False]

    for idx, phase in enumerate(project.phases()):
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["LeBail"] = False
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [1.0, 1.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [1000.0, 1000.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        for atom in phase.atoms():
            atom.refinement_flags = " "
        if idx == 0:
            hap["Pref.Ori."][0:4] = ["MD", hap["Pref.Ori."][1], True,
                                      [0, 0, 1]]
        elif idx == 1:
            hap["Pref.Ori."][0:4] = ["MD", hap["Pref.Ori."][1], True,
                                      [0, 1, 0]]
        else:
            hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]


def export_products(project):
    hist = project.histogram(0)
    phases = project.phases()
    filenames = [
        "phase_mnwo4.cif",
        "phase_wo3.cif",
        "phase_mn2wo6_pbcn.cif",
    ]
    labels = ["MnWO4", "WO3", "Mn2WO6 (Pbcn model)"]
    formulas = ["MnWO4", "WO3", "Mn2WO6"]
    confidence = ["high", "high", "tentative"]
    for phase, filename in zip(phases, filenames):
        phase.export_CIF(str(ROOT / filename))

    profile = hist.data["data"][1]
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg", "observed", "calculated", "difference", "background"
        ])
        for row in zip(profile[0], profile[1], profile[3], profile[5], profile[4]):
            writer.writerow([float(value) for value in row])

    raw_fracs = hist.ComputeMassFracs()
    values = [float(raw_fracs[phase.name][0]) for phase in phases]
    total = sum(values)
    values = [value / total for value in values]
    errors = [float(raw_fracs[phase.name][1]) for phase in phases]
    residuals = hist.residuals
    rwp = float(residuals["wR"])
    rexp = float(residuals["wRmin"])
    result = {
        "project_path": "final.gpx",
        "fit_path": "fit.csv",
        "phases": [
            {
                "name": label,
                "formula": formula,
                "cif_path": filename,
                "weight_fraction": value,
                "weight_fraction_esd": error,
                "identification_confidence": conf,
            }
            for label, formula, filename, value, error, conf in zip(
                labels, formulas, filenames, values, errors, confidence
            )
        ],
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": rexp,
            "goodness_of_fit": rwp / rexp,
            "reduced_chi_squared": (rwp / rexp) ** 2,
            "points_used": int(len(profile[0])),
        },
    }
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    return result


def main():
    project = G2sc.G2Project(str(BASE), newgpx=str(FINAL))
    project.set_Controls("cycles", 32)
    prune_to_accepted_model(project)
    project.save()

    # Required replay: reopen the frozen file and reconverge the complete measured range.
    project = G2sc.G2Project(str(FINAL))
    project.set_Controls("cycles", 32)
    for _ in range(3):
        project.refine()
    project.save()

    # Export only from a second clean reopen of the replayed project.
    project = G2sc.G2Project(str(FINAL))
    result = export_products(project)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
