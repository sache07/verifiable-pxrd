#!/usr/bin/env python3
"""Rechallenge a weak/alternate phase after the accepted two-phase model."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def refine_n(project, n):
    for _ in range(n):
        project.refine()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("name")
    ap.add_argument("cif")
    ap.add_argument("output")
    ap.add_argument("--base", default="work/texture_both_from_wo3.gpx")
    ap.add_argument("--scale-cycles", type=int, default=3)
    ap.add_argument("--cell-cycles", type=int, default=2)
    args = ap.parse_args()
    project = G2sc.G2Project(
        args.base, newgpx=str(Path(args.output).resolve())
    )
    project.set_Controls("cycles", 24)
    hist = project.histogram(0)
    phases = project.phases()
    candidate = project.add_phase(
        args.cif, phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    hap = candidate.data["Histograms"][hist.name]
    hap["Scale"][0] = 0.005
    candidate.set_HAP_refinements({"Scale": True})
    refine_n(project, args.scale_cycles)
    scale_only = float(hap["Scale"][0])
    if scale_only > 1e-10:
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
        refine_n(project, args.cell_cycles)
        for phase in project.phases():
            phase.clear_refinements({"Cell": True})
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        refine_n(project, 1)
        hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    project.save()
    try:
        fractions = hist.ComputeMassFracs()
    except Exception as exc:
        fractions = {"error": repr(exc)}
    print("CANDIDATE", args.name)
    print("SCALE_ONLY", scale_only)
    print("FINAL_SCALE", hap["Scale"])
    print("RESIDUALS", hist.residuals)
    print("FRACTIONS", fractions)
    for phase in project.phases():
        print("CELL", phase.name, phase.get_cell())
    print("NUISANCE", hist.InstrumentParameters["Zero"],
          hist.InstrumentParameters["SH/L"], hist.InstrumentParameters["Polariz."])


if __name__ == "__main__":
    main()
