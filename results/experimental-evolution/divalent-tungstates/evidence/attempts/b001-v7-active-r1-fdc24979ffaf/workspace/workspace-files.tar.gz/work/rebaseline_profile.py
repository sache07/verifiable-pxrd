#!/usr/bin/env python3
"""Replay a saved model with a measured, fixed U/W/X instrument baseline."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def refine_n(project, count):
    for _ in range(count):
        project.refine()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base")
    ap.add_argument("output")
    ap.add_argument("--u", type=float, default=0.0)
    ap.add_argument("--w", type=float, default=30.0)
    ap.add_argument("--x", type=float, default=0.5)
    args = ap.parse_args()

    project = G2sc.G2Project(
        args.base, newgpx=str(Path(args.output).resolve())
    )
    project.set_Controls("cycles", 32)
    hist = project.histogram(0)
    for key, value in (("U", args.u), ("W", args.w), ("X", args.x)):
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = False
    for key in ("V", "Y", "Z"):
        hist.InstrumentParameters[key][1] = 0.0
        hist.InstrumentParameters[key][2] = False

    refine_n(project, 4)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine_n(project, 2)
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_n(project, 1)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    project.save()

    print("RESIDUALS", hist.residuals)
    print("FRACTIONS", hist.ComputeMassFracs())
    print("INSTRUMENT", {key: hist.InstrumentParameters[key]
                         for key in ("Zero", "U", "V", "W", "X", "Y", "Z",
                                     "SH/L", "Polariz.")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("PHASE", phase.name, phase.get_cell(), hap["Pref.Ori."],
              hap["Mustrain"], hap["Size"])


if __name__ == "__main__":
    main()
