#!/usr/bin/env python3
"""Compare March-Dollase texture axes after nuisance challenges."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def refine_n(project, n):
    for _ in range(n):
        project.refine()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("phase", type=int, choices=(0, 1))
    ap.add_argument("h", type=int)
    ap.add_argument("k", type=int)
    ap.add_argument("l", type=int)
    ap.add_argument("output")
    args = ap.parse_args()
    axis = [args.h, args.k, args.l]
    project = G2sc.G2Project(
        "work/nuis_polar.gpx", newgpx=str(Path(args.output).resolve())
    )
    project.set_Controls("cycles", 24)
    hist = project.histogram(0)
    phases = project.phases()
    target = phases[args.phase]
    po = target.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = axis
    refine_n(project, 3)
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine_n(project, 2)
    for phase in phases:
        phase.clear_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_n(project, 1)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    project.save()
    print("TARGET", target.name, "AXIS", axis)
    print("RESIDUALS", hist.residuals)
    print("FRACTIONS", hist.ComputeMassFracs())
    for phase in phases:
        print("PO", phase.name, phase.data["Histograms"][hist.name]["Pref.Ori."])
    print("POLAR", hist.InstrumentParameters["Polariz."])


if __name__ == "__main__":
    main()
