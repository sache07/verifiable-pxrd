#!/usr/bin/env python3
"""Replay one profile term from the saved physical MnWO4 baseline."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def refine_n(project, n):
    for _ in range(n):
        project.refine()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=("shl", "size", "strain"))
    ap.add_argument("output")
    args = ap.parse_args()
    project = G2sc.G2Project(
        "work/huebnerite_physical2.gpx", newgpx=str(Path(args.output).resolve())
    )
    project.set_Controls("cycles", 20)
    hist = project.histogram(0)
    phase = project.phase(0)

    if args.mode == "shl":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    elif args.mode == "size":
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 1.0, "refine": True,
                     "LGmix": {"value": 0.5, "refine": False}}
        })
    elif args.mode == "strain":
        phase.set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "refine": True,
                         "LGmix": {"value": 0.5, "refine": False}}
        })

    refine_n(project, 3)
    # Rechallenge lattice and the single angular correction sequentially.
    phase.set_refinements({"Cell": True})
    refine_n(project, 2)
    phase.clear_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_n(project, 1)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    project.save()

    print("MODE", args.mode)
    print("RESIDUALS", hist.residuals)
    print("CELL", phase.get_cell())
    print("INSTRUMENT", {k: hist.InstrumentParameters[k] for k in
                         ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")})
    hap = phase.data["Histograms"][hist.name]
    print("SIZE", hap["Size"])
    print("MUSTRAIN", hap["Mustrain"])


if __name__ == "__main__":
    main()
