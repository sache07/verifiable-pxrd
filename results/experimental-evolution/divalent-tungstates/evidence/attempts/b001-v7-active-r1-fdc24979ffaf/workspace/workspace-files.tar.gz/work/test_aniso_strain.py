#!/usr/bin/env python3
"""Test a phase-specific anisotropic microstrain model from one saved baseline."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIspc as G2spc


def refine_n(project, n):
    for _ in range(n):
        project.refine()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("phase", type=int)
    ap.add_argument("mode", choices=("uniaxial", "generalized"))
    ap.add_argument("output")
    ap.add_argument("axis", nargs=3, type=int, default=(0, 0, 1))
    ap.add_argument("--base", default="work/texture_both_from_wo3.gpx")
    ap.add_argument("--profile-cycles", type=int, default=4)
    ap.add_argument("--cell-cycles", type=int, default=2)
    ap.add_argument("--skip-zero", action="store_true")
    args = ap.parse_args()

    project = G2sc.G2Project(
        args.base, newgpx=str(Path(args.output).resolve())
    )
    project.set_Controls("cycles", 32)
    hist = project.histogram(0)
    phases = project.phases()
    target = phases[args.phase]
    hap = target.data["Histograms"][hist.name]

    if args.mode == "uniaxial":
        hap["Mustrain"][1][0:2] = [1000.0, 1000.0]
        target.set_HAP_refinements({
            "Mustrain": {
                "type": "uniaxial",
                "direction": args.axis,
                "refine": True,
                "LGmix": {"value": 0.5, "refine": False},
            }
        })
    else:
        general = target.data["General"]
        hap["Mustrain"][4] = list(G2spc.Muiso2Shkl(
            1000.0, general["SGData"], general["Cell"][1:7]
        ))
        target.set_HAP_refinements({
            "Mustrain": {
                "type": "generalized",
                "refine": True,
                "LGmix": {"value": 0.5, "refine": False},
            }
        })

    refine_n(project, args.profile_cycles)
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine_n(project, args.cell_cycles)
    for phase in phases:
        phase.clear_refinements({"Cell": True})
    if not args.skip_zero:
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        refine_n(project, 1)
        hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    project.save()

    print("TARGET", target.name, args.mode, list(args.axis))
    print("RESIDUALS", hist.residuals)
    print("FRACTIONS", hist.ComputeMassFracs())
    for phase in phases:
        phap = phase.data["Histograms"][hist.name]
        print("PROFILE", phase.name, "MUSTRAIN", phap["Mustrain"])
        print("CELL", phase.name, phase.get_cell())
    print("NUISANCE", {
        key: hist.InstrumentParameters[key]
        for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
    })


if __name__ == "__main__":
    main()
