#!/usr/bin/env python3
"""Fail-fast consistency checks for scorer-facing PXRD outputs."""

from __future__ import annotations

import csv
import json
import math
import re
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def cif_number(text, tag):
    match = re.search(rf"^{re.escape(tag)}\s+([-+0-9.eE]+)", text, re.MULTILINE)
    require(match is not None, f"missing {tag}")
    return float(match.group(1))


def main():
    result = json.loads((ROOT / "result.json").read_text())
    require(result["project_path"] == "final.gpx", "project_path is not final.gpx")
    require((ROOT / result["project_path"]).is_file(), "missing final.gpx")
    require((ROOT / result["fit_path"]).is_file(), "missing fit.csv")
    require(all(isinstance(item["weight_fraction"], (int, float))
                and math.isfinite(item["weight_fraction"])
                for item in result["phases"]), "nonnumeric fraction")
    require(abs(sum(item["weight_fraction"] for item in result["phases"]) - 1.0)
            < 1e-12, "fractions do not sum to one")

    project = G2sc.G2Project(str(ROOT / "final.gpx"))
    hist = project.histogram(0)
    phases = project.phases()
    require(len(phases) == len(result["phases"]) == 3, "phase count mismatch")
    x = np.asarray(hist.data["data"][1][0], dtype=float)
    require(np.allclose(hist.data["Limits"][1], [x[0], x[-1]]),
            "project does not use the full measured range")

    fractions = hist.ComputeMassFracs()
    gpx_values = np.asarray([fractions[phase.name][0] for phase in phases], dtype=float)
    gpx_values /= gpx_values.sum()
    json_values = np.asarray([item["weight_fraction"] for item in result["phases"]])
    require(np.allclose(gpx_values, json_values, rtol=0, atol=1e-12),
            "JSON fractions differ from final.gpx")

    for phase, item in zip(phases, result["phases"]):
        cif_path = ROOT / item["cif_path"]
        require(cif_path.is_file(), f"missing {item['cif_path']}")
        text = cif_path.read_text()
        cell = phase.get_cell()
        for short, key in (("a", "length_a"), ("b", "length_b"),
                           ("c", "length_c"), ("alpha", "angle_alpha"),
                           ("beta", "angle_beta"), ("gamma", "angle_gamma")):
            value = cif_number(text, f"_cell_{key}")
            tolerance = 6e-4 if key.startswith("angle_") else 6e-5
            require(math.isclose(value, cell[key], rel_tol=0, abs_tol=tolerance),
                    f"CIF/project cell mismatch for {phase.name} {short}")
        hap = phase.data["Histograms"][hist.name]
        require(not any(hap["Size"][2]) and not any(hap["Size"][5]),
                f"active size term in {phase.name}")
        require(not any(hap["Mustrain"][2]) and not any(hap["Mustrain"][5]),
                f"active strain term in {phase.name}")
        require(all(not atom.refinement_flags.strip() for atom in phase.atoms()),
                f"active atom term in {phase.name}")

    with (ROOT / "fit.csv").open(newline="") as stream:
        reader = csv.DictReader(stream)
        fit = list(reader)
    require(len(fit) == len(x) == result["fit_statistics"]["points_used"],
            "fit row/point count mismatch")
    exported = np.asarray([[float(row[key]) for row in fit] for key in
                           ("two_theta_deg", "observed", "calculated",
                            "difference", "background")])
    profile = np.asarray(hist.data["data"][1], dtype=float)
    expected = np.vstack((profile[0], profile[1], profile[3], profile[5], profile[4]))
    require(np.allclose(exported, expected, rtol=0, atol=1e-10),
            "fit.csv differs from final.gpx")
    require(np.count_nonzero(exported[2, [0, -1]]) == 2,
            "edge profile was not calculated")

    residuals = hist.residuals
    require(math.isclose(result["fit_statistics"]["Rwp_percent"], residuals["wR"],
                         rel_tol=0, abs_tol=1e-12), "Rwp mismatch")
    require(hist.SampleParameters["Type"] == "Bragg-Brentano", "wrong geometry")
    for key in ("SurfRoughA", "SurfRoughB"):
        require(hist.SampleParameters[key] == [0.0, False],
                f"active/bound roughness term {key}")
    print("VALIDATED")
    print("fractions", json_values.tolist(), "sum", float(json_values.sum()))
    print("rows", len(fit), "range", float(x[0]), float(x[-1]))
    print("Rwp", residuals["wR"], "GOF",
          result["fit_statistics"]["goodness_of_fit"])


if __name__ == "__main__":
    main()
