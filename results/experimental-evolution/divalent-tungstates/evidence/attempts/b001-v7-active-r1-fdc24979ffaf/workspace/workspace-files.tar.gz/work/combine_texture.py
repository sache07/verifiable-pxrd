#!/usr/bin/env python3
"""Combine the best phase texture axes from either accepted starting branch."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def refine_n(project, n):
    for _ in range(n):
        project.refine()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base")
    ap.add_argument("add_phase", type=int, choices=(0, 1))
    ap.add_argument("output")
    args = ap.parse_args()
    project = G2sc.G2Project(args.base, newgpx=str(Path(args.output).resolve()))
    project.set_Controls("cycles", 24)
    hist = project.histogram(0)
    phases = project.phases()
    axis = [0, 0, 1] if args.add_phase == 0 else [0, 1, 0]
    po = phases[args.add_phase].data["Histograms"][hist.name]["Pref.Ori."]
    po[0:4] = ["MD", 1.0, True, axis]
    refine_n(project, 3)
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine_n(project, 2)
    for phase in phases:
        phase.clear_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_n(project, 1)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    project.save()
    print("RESIDUALS", hist.residuals)
    print("FRACTIONS", hist.ComputeMassFracs())
    for phase in phases:
        print("PO", phase.name, phase.data["Histograms"][hist.name]["Pref.Ori."])
        print("CELL", phase.name, phase.get_cell())
    print("POLAR", hist.InstrumentParameters["Polariz."])
    print("ZERO_SHL", hist.InstrumentParameters["Zero"], hist.InstrumentParameters["SH/L"])


if __name__ == "__main__":
    main()
