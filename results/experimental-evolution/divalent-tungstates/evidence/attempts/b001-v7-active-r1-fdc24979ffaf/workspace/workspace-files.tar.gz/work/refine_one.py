#!/usr/bin/env python3
"""Build and refine a one-phase GSAS-II baseline for source-model comparison."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def snapshot(tag, project, hist, phase):
    inst = hist.InstrumentParameters
    vals = {k: round(float(inst[k][1]), 7) for k in
            ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")}
    print(tag, "residuals", hist.residuals)
    print(tag, "cell", phase.get_cell())
    print(tag, "instrument", vals)
    print(tag, "sample", {k: hist.SampleParameters[k] for k in
                           ("Scale", "Shift", "DisplaceX", "DisplaceY",
                            "Transparency", "SurfRoughA", "SurfRoughB")})
    print(tag, "background", hist.Background[0])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("cif")
    parser.add_argument("gpx")
    args = parser.parse_args()

    output = Path(args.gpx).resolve()
    project = G2sc.G2Project(newgpx=str(output))
    project.set_Controls("cycles", 12)
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "work/cu_ka1ka2.instprm", fmthint="comma"
    )
    phase = project.add_phase(
        args.cif, phasename="MnWO4", histograms=[hist], fmthint="CIF"
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    # Low-dimensional smooth background; coefficients are deliberately broad
    # starting estimates and are reconverged at each accepted stage.
    hist.set_refinements({"Background": {
        "type": "chebyschev-1", "refine": True, "no. coeffs": 8,
        "coeffs": [1500.0, -700.0, 250.0, -100.0, 50.0, -20.0, 5.0, 0.0],
    }})
    # Imported sample scale is the sole scale variable for this one-phase run.
    project.save()
    project.refine()
    snapshot("scale_background", project, hist, phase)

    phase.set_refinements({"Cell": True})
    project.refine()
    snapshot("cell", project, hist, phase)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    snapshot("zero", project, hist, phase)

    # U/W/X only. V/Y/Z and asymmetry remain neutralized.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.refine()
    snapshot("uwx", project, hist, phase)
    project.save()


if __name__ == "__main__":
    main()
