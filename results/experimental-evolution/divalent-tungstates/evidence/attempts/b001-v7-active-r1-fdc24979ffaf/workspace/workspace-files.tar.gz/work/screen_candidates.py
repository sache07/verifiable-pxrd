#!/usr/bin/env python3
"""Fast whole-pattern screen of chemically allowed COD candidates.

This is deliberately a screening model (fixed atoms, simple Gaussian profile),
not the final Rietveld refinement.  It ranks records for physical follow-up.
"""

from __future__ import annotations

import gzip
import json
import math
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import gaussian_filter1d, percentile_filter


ROOT = Path("<RUN>/resources/b001-c04")
INDEX = ROOT / "index.json.gz"
PATTERN = Path("inputs/pattern.csv")


def cif_path(cod_id: str) -> Path:
    return ROOT / "cif" / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def diffraction_sticks(structure: Structure, x: np.ndarray):
    sticks = []
    for wavelength, ratio in ((1.540598, 1.0), (1.544426, 0.5)):
        patt = XRDCalculator(wavelength=wavelength).get_pattern(
            structure, two_theta_range=(max(0.5, x[0] - 2), x[-1] + 2), scaled=False
        )
        sticks.append((wavelength, ratio, np.asarray(patt.x), np.asarray(patt.y)))
    return sticks


def calc_profile(sticks, x: np.ndarray, cell_scale: float, shift: float,
                 fwhm: float) -> np.ndarray:
    """Return Kalpha1+Kalpha2 profile on x, with a uniform cell multiplier."""
    out = np.zeros_like(x)
    step = float(np.median(np.diff(x)))
    sigma_pts = fwhm / 2.354820045 / step
    for wavelength, ratio, positions, intensities in sticks:
        for pos, inten in zip(positions, intensities):
            theta = math.radians(pos / 2)
            arg = min(0.999999, max(0.0, math.sin(theta) / cell_scale))
            moved = math.degrees(2 * math.asin(arg)) + shift
            idx = int(round((moved - x[0]) / step))
            if 0 <= idx < len(out):
                out[idx] += ratio * float(inten)
    return gaussian_filter1d(out, sigma_pts, mode="constant")


def main() -> None:
    data = np.genfromtxt(PATTERN, delimiter=",", names=True)
    x = data["two_theta_deg"]
    y = data["intensity"]
    bg = percentile_filter(y, percentile=12, size=401, mode="nearest")
    target = np.maximum(0, gaussian_filter1d(y - bg, 1.0))
    # Weight peaks approximately equally in relative rather than squared-count space.
    target = np.sqrt(target)
    target /= np.linalg.norm(target)

    with gzip.open(INDEX, "rt") as handle:
        db = json.load(handle)
    records = []
    for system in ("Mn-O", "O-W", "Mn-O-W"):
        records.extend((system, *row) for row in db.get(system, []))

    # Include physical wolframite parents to be substituted with Mn in a later model.
    for system in ("Fe-O-W", "O-W-Zn", "Mg-O-W", "Cd-O-W", "Cu-O-W", "Mn-Mo-O"):
        for row in db.get(system, []):
            if row[2] in (2, 13, 14):
                records.append((system, *row))

    rows = []
    for system, formula, cod_id, sg, quality in records:
        path = cif_path(str(cod_id))
        if not path.is_file():
            continue
        try:
            structure = Structure.from_file(path)
        except Exception as exc:
            rows.append((float("nan"), formula, cod_id, sg, system, "read_error", str(exc)))
            continue
        sticks = diffraction_sticks(structure, x)
        best = (-np.inf, None, None, None)
        # Wide enough to accommodate physical isostructural substitutions.
        for scale in np.linspace(0.975, 1.035, 13):
            for shift in np.linspace(-0.12, 0.12, 7):
                for fwhm in (0.12, 0.16, 0.22, 0.30):
                    prof = calc_profile(sticks, x, scale, shift, fwhm)
                    prof = np.sqrt(np.maximum(0, prof))
                    norm = np.linalg.norm(prof)
                    if norm == 0:
                        continue
                    score = float(np.dot(target, prof / norm))
                    if score > best[0]:
                        best = (score, scale, shift, fwhm)
        rows.append((*best, formula, cod_id, sg, system, str(path)))

    rows.sort(key=lambda row: -row[0] if np.isfinite(row[0]) else np.inf)
    print("score cell_scale shift fwhm formula cod_id sg system path")
    for row in rows[:80]:
        print("{:.5f} {:8.5f} {:+7.3f} {:5.2f} {:16s} {:8s} {:3s} {:10s} {}".format(
            row[0], row[1], row[2], row[3], str(row[4]), str(row[5]), str(row[6]),
            str(row[7]), row[8]
        ))


if __name__ == "__main__":
    main()
