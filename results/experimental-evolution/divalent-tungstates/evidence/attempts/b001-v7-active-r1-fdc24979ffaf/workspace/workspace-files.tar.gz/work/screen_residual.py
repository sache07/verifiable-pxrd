#!/usr/bin/env python3
"""Rank chemically plausible structures against the positive final residual."""

from __future__ import annotations

import gzip
import json
import math
from pathlib import Path
import warnings

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import gaussian_filter1d

warnings.filterwarnings("ignore")
ROOT = Path("<RUN>/resources/b001-c04")


def cif_path(cod_id: str) -> Path:
    return ROOT / "cif" / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def sticks(structure, x):
    out = []
    for wave, ratio in ((1.540598, 1.0), (1.544426, 0.5)):
        p = XRDCalculator(wavelength=wave).get_pattern(
            structure, two_theta_range=(x[0] - 2, x[-1] + 2), scaled=False
        )
        out.append((wave, ratio, np.asarray(p.x), np.asarray(p.y)))
    return out


def profile(stick_data, x, scale, shift, fwhm):
    step = float(np.median(np.diff(x)))
    out = np.zeros_like(x)
    for wave, ratio, positions, intensities in stick_data:
        moved = np.degrees(2 * np.arcsin(np.clip(
            np.sin(np.radians(positions / 2)) / scale, 0, .999999
        ))) + shift
        idx = np.rint((moved - x[0]) / step).astype(int)
        good = (idx >= 0) & (idx < len(x))
        np.add.at(out, idx[good], ratio * intensities[good])
    return gaussian_filter1d(out, fwhm / 2.35482 / step, mode="constant")


def main():
    data = np.genfromtxt("work/texture_both_profile.csv", delimiter=",", names=True)
    x = data["two_theta"]
    target = np.sqrt(np.maximum(data["difference"], 0))
    target /= np.linalg.norm(target)
    with gzip.open(ROOT / "index.json.gz", "rt") as f:
        db = json.load(f)
    candidates = []
    for system in ("Mn-O", "O-W", "Mn-O-W"):
        for formula, cod_id, sg, quality in db.get(system, []):
            candidates.append((formula, str(cod_id), sg, system, None))
    candidates.append(("MnWO4", "9008131", 13, "derived exact", None))
    candidates.extend([
        ("Mn2WO6_from_Fe2WO6", "2310464", 60, "analogue", {"Fe": "Mn"}),
        ("Mn2WO6_from_Cr2WO6", "1530909", 136, "analogue", {"Cr": "Mn"}),
        ("Mn2WO5_from_PrMn2O5", "1526276", 55, "analogue", {"Pr": "W"}),
        ("Mn2W2O7_from_Ag2W2O7", "4027815", 2, "analogue", {"Ag": "Mn"}),
    ])
    rows = []
    for formula, cod_id, sg, system, repl in candidates:
        path = cif_path(cod_id)
        if not path.is_file():
            continue
        try:
            structure = Structure.from_file(path)
            if repl:
                structure.replace_species(repl)
            sd = sticks(structure, x)
        except Exception:
            continue
        best = (-1.0, None, None, None)
        for scale in np.linspace(.97, 1.03, 13):
            for shift in (-.10, -.05, 0, .05, .10):
                for fwhm in (.12, .20, .35):
                    p = np.sqrt(np.maximum(profile(sd, x, scale, shift, fwhm), 0))
                    n = np.linalg.norm(p)
                    if n:
                        score = float(np.dot(target, p / n))
                        if score > best[0]:
                            best = (score, scale, shift, fwhm)
        rows.append((*best, formula, cod_id, sg, system, str(path)))
    rows.sort(reverse=True, key=lambda row: row[0])
    print("score scale shift fwhm formula cod_id sg system path")
    for row in rows[:60]:
        print("{:.5f} {:7.4f} {:+6.2f} {:4.2f} {:26s} {:8s} {:3d} {:12s} {}".format(*row))


if __name__ == "__main__":
    main()
