#!/usr/bin/env python3
"""Refine a physical U/W/X-only one-phase baseline in guarded stages."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


START_CELL = [4.87, 5.80, 5.00, 90.0, 89.4, 90.0]


def snapshot(tag, project, hist, phase):
    inst = hist.InstrumentParameters
    vals = {k: round(float(inst[k][1]), 7) for k in
            ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")}
    print("SNAPSHOT", tag, "residuals", hist.residuals)
    print("SNAPSHOT", tag, "cell", phase.get_cell())
    print("SNAPSHOT", tag, "instrument", vals)
    print("SNAPSHOT", tag, "scale", hist.SampleParameters["Scale"])
    print("SNAPSHOT", tag, "background", hist.Background[0])


def refine_n(project, n=2):
    for _ in range(n):
        project.refine()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("cif")
    parser.add_argument("gpx")
    args = parser.parse_args()

    project = G2sc.G2Project(newgpx=str(Path(args.gpx).resolve()))
    project.set_Controls("cycles", 16)
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "work/cu_ka1ka2.instprm", fmthint="comma"
    )
    phase = project.add_phase(
        args.cif, phasename="MnWO4", histograms=[hist], fmthint="CIF"
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    cell = phase.data["General"]["Cell"]
    cell[1:7] = START_CELL
    cell[7] = G2lat.calc_V(G2lat.cell2A(START_CELL))

    inst = hist.InstrumentParameters
    for key, value in {"Zero": 0.0, "U": 20.0, "V": 0.0, "W": 80.0,
                       "X": 1.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.002}.items():
        inst[key][1] = value
        inst[key][2] = False
    hist.set_refinements({"Background": {
        "type": "chebyschev-1", "refine": True, "no. coeffs": 8,
        "coeffs": [1500.0, -700.0, 250.0, -100.0, 50.0, -20.0, 5.0, 0.0],
    }})
    project.save()
    refine_n(project, 2)
    snapshot("scale_background", project, hist, phase)

    phase.set_refinements({"Cell": True})
    refine_n(project, 3)
    phase.clear_refinements({"Cell": True})
    snapshot("cell", project, hist, phase)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_n(project, 2)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    snapshot("zero", project, hist, phase)

    # Release only one width degree of freedom at a time.
    for key in ("W", "U", "X"):
        hist.set_refinements({"Instrument Parameters": [key]})
        refine_n(project, 2)
        hist.clear_refinements({"Instrument Parameters": [key]})
        value = float(inst[key][1])
        if value < 0:
            raise RuntimeError(f"Rejected nonphysical {key}={value}")
        snapshot(key.lower(), project, hist, phase)

    # Reconcile the lattice and angular correction against the accepted fixed
    # profile. Do not release correlated profile terms together.
    phase.set_refinements({"Cell": True})
    refine_n(project, 3)
    phase.clear_refinements({"Cell": True})
    snapshot("reconciled_cell", project, hist, phase)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_n(project, 2)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    snapshot("reconciled_zero", project, hist, phase)
    if any(float(inst[k][1]) < 0 for k in ("U", "W", "X")):
        raise RuntimeError("Reconciled U/W/X baseline became nonphysical")
    project.save()


if __name__ == "__main__":
    main()
