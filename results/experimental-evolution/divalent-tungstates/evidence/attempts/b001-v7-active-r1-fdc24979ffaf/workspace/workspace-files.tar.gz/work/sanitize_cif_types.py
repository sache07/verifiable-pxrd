#!/usr/bin/env python3
"""Normalize charged CIF atom type labels for GSAS-II x-ray form factors."""

from pathlib import Path
import sys


source = Path(sys.argv[1])
target = Path(sys.argv[2])
text = source.read_text()
for charged, neutral in (("W+6", "W"), ("W+5", "W"), ("O-2", "O"),
                         ("Mn2+", "Mn"), ("Mn3+", "Mn")):
    text = text.replace(charged, neutral)
target.write_text(text)
