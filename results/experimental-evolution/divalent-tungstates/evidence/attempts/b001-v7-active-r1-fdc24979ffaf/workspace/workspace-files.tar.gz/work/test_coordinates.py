#!/usr/bin/env python3
"""Challenge source coordinates for one phase from a common saved baseline."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("phase", type=int)
    ap.add_argument("output")
    ap.add_argument("labels", nargs="+")
    ap.add_argument("--base", default="work/threephase_baseline.gpx")
    ap.add_argument("--cycles", type=int, default=1)
    args = ap.parse_args()

    project = G2sc.G2Project(
        args.base, newgpx=str(Path(args.output).resolve())
    )
    project.set_Controls("cycles", 32)
    hist = project.histogram(0)
    target = project.phases()[args.phase]
    refs = {label: "X" for label in args.labels}
    target.set_refinements({"Atoms": refs})
    for _ in range(args.cycles):
        project.refine()
    project.save()
    print("TARGET", target.name, args.labels)
    print("RESIDUALS", hist.residuals)
    print("FRACTIONS", hist.ComputeMassFracs())
    for atom in target.atoms():
        print("ATOM", atom.label, atom.element, atom.coordinates,
              atom.refinement_flags)


if __name__ == "__main__":
    main()
