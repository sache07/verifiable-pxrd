#!/usr/bin/env python3
"""Numerical position/half-width audit for selected isolated reflections."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.signal import find_peaks, peak_widths, savgol_filter
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SELECTIONS = [
    ("MnWO4", "low", (1, 1, -1), 30.032, 0.18),
    ("MnWO4", "middle", (1, 0, 2), 40.107, 0.10),
    ("MnWO4", "high", (4, 0, 2), 87.825, 0.10),
    ("WO3", "low", (0, 2, 0), 23.264, 0.14),
    ("WO3", "middle", (2, 2, -4), 41.477, 0.10),
    ("WO3", "high", (4, 5, -2), 84.653, 0.10),
    ("Mn2WO6", "low", (1, 3, 0), 25.007, 0.24),
    ("Mn2WO6", "middle", (2, 0, 0), 38.867, 0.10),
    ("Mn2WO6", "high", (0, 12, 1), 70.390, 0.10),
]


def measure(x, y, center, radius):
    indices = np.where((x >= center - radius) & (x <= center + radius))[0]
    local = y[indices]
    peaks, props = find_peaks(local, prominence=max(5.0, 0.01 * np.ptp(local)))
    if not len(peaks):
        peaks = np.array([int(np.argmax(local))])
        prominences = np.array([float(np.ptp(local))])
    else:
        prominences = props["prominences"]
    positions = x[indices[peaks]]
    scores = prominences / (1.0 + (np.abs(positions - center) /
                                  max(radius / 3.0, 0.02)) ** 2)
    selected = int(np.argmax(scores))
    peak = int(peaks[selected])
    width = peak_widths(local, [peak], rel_height=0.5)
    left_crossing = np.interp(width[2][0], np.arange(len(indices)), x[indices])
    right_crossing = np.interp(width[3][0], np.arange(len(indices)), x[indices])
    position = float(x[indices[peak]])
    return {
        "position_deg": position,
        "left_half_width_deg": position - float(left_crossing),
        "right_half_width_deg": float(right_crossing) - position,
        "FWHM_deg": float(right_crossing - left_crossing),
        "prominence_counts": float(prominences[selected]),
    }


def main():
    project = G2sc.G2Project(str(ROOT / "final.gpx"))
    hist = project.histogram(0)
    profile = hist.data["data"][1]
    x = np.asarray(profile[0], dtype=float)
    background = np.asarray(profile[4], dtype=float)
    observed = savgol_filter(np.asarray(profile[1], dtype=float) - background, 7, 2)
    calculated = savgol_filter(np.asarray(profile[3], dtype=float) - background, 7, 2)
    rows = []
    for phase, region, hkl, center, radius in SELECTIONS:
        rows.append({
            "phase": phase,
            "region": region,
            "hkl": list(hkl),
            "nominal_reflection_position_deg": center,
            "observed": measure(x, observed, center, radius),
            "calculated": measure(x, calculated, center, radius),
        })
    payload = {
        "method": (
            "Background-subtracted observed and calculated profiles were smoothed "
            "with a 7-point quadratic Savitzky-Golay filter. Half-height crossings "
            "use scipy peak prominence within a manually isolated local window."
        ),
        "rows": rows,
    }
    with (ROOT / "work" / "peak_audit.json").open("w") as stream:
        json.dump(payload, stream, indent=2)
        stream.write("\n")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
