#!/usr/bin/env python3
"""Re-establish the accepted MnWO4+WO3 model with a measured sharp baseline."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def refine_n(project, n):
    for _ in range(n):
        project.refine()


def main():
    project = G2sc.G2Project(
        "work/cand_wo3_mono.gpx", newgpx=str(Path("work/twophase_narrow.gpx").resolve())
    )
    project.set_Controls("cycles", 20)
    hist = project.histogram(0)
    phases = project.phases()
    inst = hist.InstrumentParameters
    # Isolated sharp peaks give FWHM ~0.14 deg at low/mid angle and
    # ~0.16 deg near 80 deg 2theta. These nonnegative U/W/X values provide
    # that low-dimensional common instrument baseline.
    for key, value in {"U": 15.0, "W": 30.0, "X": 0.5,
                       "V": 0.0, "Y": 0.0, "Z": 0.0}.items():
        inst[key][1] = value
        inst[key][2] = False
    # Preserve supported asymmetry, smooth background and scales.
    inst["SH/L"][2] = True
    hist.Background[0][1] = True
    hist.SampleParameters["Scale"][1] = True
    phases[1].data["Histograms"][hist.name]["Scale"][1] = True
    project.save()
    refine_n(project, 3)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine_n(project, 3)
    for phase in phases:
        phase.clear_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_n(project, 2)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    project.save()
    print("RESIDUALS", hist.residuals)
    print("FRACTIONS", hist.ComputeMassFracs())
    print("INSTRUMENT", {k: inst[k] for k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")})
    for phase in phases:
        print("PHASE", phase.name, phase.get_cell(), phase.data["Histograms"][hist.name]["Scale"])


if __name__ == "__main__":
    main()
