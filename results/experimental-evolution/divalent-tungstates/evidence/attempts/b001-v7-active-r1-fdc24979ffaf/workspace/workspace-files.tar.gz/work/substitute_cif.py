#!/usr/bin/env python3
"""Create a neutral-species substituted analogue CIF for physical screening."""

from pathlib import Path
import sys

from pymatgen.core import Element, Structure
from pymatgen.io.cif import CifWriter


source = Path(sys.argv[1])
target = Path(sys.argv[2])
mapping = dict(item.split(":", 1) for item in sys.argv[3:])
structure = Structure.from_file(source)
for index, site in enumerate(list(structure)):
    symbol = next(iter(site.species)).symbol
    structure.replace(index, Element(mapping.get(symbol, symbol)))
CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(target)
