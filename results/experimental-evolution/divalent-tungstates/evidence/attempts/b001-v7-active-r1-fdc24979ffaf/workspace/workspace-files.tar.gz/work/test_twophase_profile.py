#!/usr/bin/env python3
"""Test one phase-specific broadening term from the narrow two-phase baseline."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def refine_n(project, n):
    for _ in range(n):
        project.refine()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("phase", type=int)
    ap.add_argument("mode", choices=("size", "strain"))
    ap.add_argument("output")
    ap.add_argument("--base", default="work/twophase_narrow.gpx")
    ap.add_argument("--profile-cycles", type=int, default=3)
    ap.add_argument("--cell-cycles", type=int, default=2)
    args = ap.parse_args()
    project = G2sc.G2Project(
        args.base, newgpx=str(Path(args.output).resolve())
    )
    project.set_Controls("cycles", 24)
    hist = project.histogram(0)
    phases = project.phases()
    target = phases[args.phase]
    if args.mode == "size":
        target.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 0.2, "refine": True,
                     "LGmix": {"value": 0.5, "refine": False}}
        })
    else:
        target.set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "refine": True,
                         "LGmix": {"value": 0.5, "refine": False}}
        })
    refine_n(project, args.profile_cycles)
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine_n(project, args.cell_cycles)
    for phase in phases:
        phase.clear_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_n(project, 1)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    project.save()
    print("TARGET", target.name, args.mode)
    print("RESIDUALS", hist.residuals)
    print("FRACTIONS", hist.ComputeMassFracs())
    print("INSTRUMENT", {k: hist.InstrumentParameters[k] for k in
                         ("Zero", "U", "W", "X", "SH/L")})
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        print("PROFILE", phase.name, "SIZE", hap["Size"], "MUSTRAIN", hap["Mustrain"])
        print("CELL", phase.name, phase.get_cell())


if __name__ == "__main__":
    main()
