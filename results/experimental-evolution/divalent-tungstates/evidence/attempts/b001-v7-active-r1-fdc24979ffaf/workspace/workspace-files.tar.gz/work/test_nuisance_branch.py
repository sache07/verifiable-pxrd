#!/usr/bin/env python3
"""Challenge background, polarization and roughness before texture."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def refine_n(project, n):
    for _ in range(n):
        project.refine()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=("polar", "rough", "bg6", "bg10"))
    ap.add_argument("output")
    args = ap.parse_args()
    project = G2sc.G2Project(
        "work/twophase_narrow.gpx", newgpx=str(Path(args.output).resolve())
    )
    project.set_Controls("cycles", 24)
    hist = project.histogram(0)
    phases = project.phases()
    if args.mode == "polar":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        refine_n(project, 3)
    elif args.mode == "rough":
        sample = hist.SampleParameters
        sample["SurfRoughA"][:] = [0.5, False]
        sample["SurfRoughB"][:] = [0.01, True]
        refine_n(project, 2)
        sample["SurfRoughA"][1] = True
        refine_n(project, 2)
    else:
        n = 6 if args.mode == "bg6" else 10
        coeffs = list(hist.Background[0][3:])
        coeffs = (coeffs + [0.0] * n)[:n]
        hist.set_refinements({"Background": {
            "type": "chebyschev-1", "refine": True,
            "no. coeffs": n, "coeffs": coeffs,
        }})
        refine_n(project, 3)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine_n(project, 2)
    for phase in phases:
        phase.clear_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_n(project, 1)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    project.save()
    print("MODE", args.mode)
    print("RESIDUALS", hist.residuals)
    print("FRACTIONS", hist.ComputeMassFracs())
    print("BACKGROUND", hist.Background[0])
    print("POLAR", hist.InstrumentParameters["Polariz."])
    print("ROUGH", hist.SampleParameters["SurfRoughA"], hist.SampleParameters["SurfRoughB"])
    print("ZERO_SHL", hist.InstrumentParameters["Zero"], hist.InstrumentParameters["SH/L"])


if __name__ == "__main__":
    main()
