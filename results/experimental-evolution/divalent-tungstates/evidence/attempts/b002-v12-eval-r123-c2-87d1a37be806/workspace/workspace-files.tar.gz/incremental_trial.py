#!/usr/bin/env python3
"""Replay one nuisance/profile challenge while preserving accepted HAP terms."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import traceback

from GSASII import GSASIIscriptable as G2sc

from gsas_workflow import refine_step, set_flags


def hap_flags(project, histogram):
    """Snapshot every active HAP flag so set_flags can be used safely."""
    out = {}
    for phase in project.phases():
        hap = phase.getHAPvalues(histogram.name)
        out[phase.name] = {
            "size": list(hap["Size"][2]),
            "size_g": list(hap["Size"][5]),
            "strain": list(hap["Mustrain"][2]),
            "strain_g": list(hap["Mustrain"][5]),
            "texture": bool(hap["Pref.Ori."][2]),
        }
    return out


def restore_hap_flags(project, histogram, flags) -> None:
    for phase in project.phases():
        hap = phase.getHAPvalues(histogram.name)
        old = flags[phase.name]
        hap["Size"][2][:] = old["size"]
        hap["Size"][5][:] = old["size_g"]
        hap["Mustrain"][2][:] = old["strain"]
        hap["Mustrain"][5][:] = old["strain_g"]
        hap["Pref.Ori."][2] = old["texture"]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--summary", type=Path, required=True)
    ap.add_argument(
        "--mode",
        required=True,
        choices=(
            "replay",
            "remove_strain",
            "uniaxial_strain",
            "background",
            "polarization",
            "roughness_a",
            "roughness_ab",
            "texture",
            "shl",
            "atom_xyz",
        ),
    )
    ap.add_argument("--phase")
    ap.add_argument("--axis", nargs=3, type=int)
    ap.add_argument("--background-order", type=int)
    ap.add_argument("--atom-label")
    ap.add_argument(
        "--refine-polarization",
        action="store_true",
        help="also reopen the already-seeded common polarization term",
    )
    args = ap.parse_args()

    result = {
        "mode": args.mode,
        "phase": args.phase,
        "axis": args.axis,
        "base": str(args.base.resolve()),
        "project": str(args.output.resolve()),
        "status": "error",
        "rows": [],
    }
    try:
        project = G2sc.G2Project(str(args.base), newgpx=str(args.output))
        hist = project.histogram(0)
        target = project.phase(args.phase) if args.phase else None
        if args.mode in ("remove_strain", "uniaxial_strain", "texture", "atom_xyz") and target is None:
            raise ValueError("--phase is required for this trial")
        if args.mode == "atom_xyz" and not args.atom_label:
            raise ValueError("--atom-label is required for atom_xyz")

        if args.mode == "remove_strain":
            hap = target.getHAPvalues(hist.name)
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
            hap["Mustrain"][2][:] = [False] * len(hap["Mustrain"][2])
            hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        elif args.mode == "uniaxial_strain":
            if args.axis is None:
                raise ValueError("--axis is required for uniaxial broadening")
            hap = target.getHAPvalues(hist.name)
            seed = max(100.0, float(hap["Mustrain"][1][0]))
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][3] = list(args.axis)
            hap["Mustrain"][1][0:2] = [seed, seed]
            hap["Mustrain"][2][:] = [False] * len(hap["Mustrain"][2])
            hap["Mustrain"][2][0:2] = [True, True]
            hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        elif args.mode == "texture":
            if args.axis is None:
                raise ValueError("--axis is required for texture")
            hap = target.getHAPvalues(hist.name)
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(args.axis)

        if args.mode == "background":
            if args.background_order is None:
                raise ValueError("--background-order is required")
            coeffs = list(hist.Background[0][3:])
            if len(coeffs) < args.background_order:
                coeffs += [0.0] * (args.background_order - len(coeffs))
            hist.set_refinements(
                {
                    "Background": {
                        "type": "chebyschev-1",
                        "no. coeffs": args.background_order,
                        "coeffs": coeffs[: args.background_order],
                        "refine": False,
                    }
                }
            )

        extra_instrument_list: list[str] = []
        extra_sample: tuple[str, ...] = ()
        if args.mode == "polarization" or args.refine_polarization:
            extra_instrument_list.append("Polariz.")
        if args.mode == "shl":
            extra_instrument_list.append("SH/L")
        if args.mode == "roughness_a":
            hist.SampleParameters["SurfRoughA"][0] = 0.01
            extra_sample = ("SurfRoughA",)
        elif args.mode == "roughness_ab":
            hist.SampleParameters["SurfRoughA"][0] = 0.01
            hist.SampleParameters["SurfRoughB"][0] = 0.01
            extra_sample = ("SurfRoughA", "SurfRoughB")

        flags = hap_flags(project, hist)
        set_flags(
            project,
            background=True,
            scales=True,
            cells=True,
            instrument=("Zero", "W", "X") + tuple(extra_instrument_list),
            sample=extra_sample,
        )
        restore_hap_flags(project, hist, flags)
        if args.mode == "atom_xyz":
            matches = [atom for atom in target.atoms() if atom.label == args.atom_label]
            if len(matches) != 1:
                raise ValueError(
                    f"expected one atom named {args.atom_label!r}; found {len(matches)}"
                )
            matches[0].refinement_flags = "X"
        project.save()

        for label in ("trial", "replay"):
            row = refine_step(project, label)
            row["mass_fractions"] = {
                key: list(value) for key, value in hist.ComputeMassFracs().items()
            }
            row["sample"] = {
                key: float(hist.SampleParameters[key][0])
                for key in ("SurfRoughA", "SurfRoughB")
            }
            row["hap"] = {
                phase.name: {
                    "scale": float(phase.getHAPvalues(hist.name)["Scale"][0]),
                    "size": list(phase.getHAPvalues(hist.name)["Size"][1]),
                    "size_type": phase.getHAPvalues(hist.name)["Size"][0],
                    "strain": list(phase.getHAPvalues(hist.name)["Mustrain"][1]),
                    "strain_type": phase.getHAPvalues(hist.name)["Mustrain"][0],
                    "md_ratio": float(phase.getHAPvalues(hist.name)["Pref.Ori."][1]),
                    "md_axis": list(phase.getHAPvalues(hist.name)["Pref.Ori."][3]),
                }
                for phase in project.phases()
            }
            row["covariance"] = {
                key: project.data["Covariance"]["data"].get("Rvals", {}).get(key)
                for key in ("converged", "chisq", "Nobs", "Nvars", "GOF", "Max shft/sig")
            }
            row["atoms"] = {
                phase.name: {
                    atom.label: {
                        "element": atom.element,
                        "coordinates": list(atom.coordinates),
                        "occupancy": float(atom.occupancy),
                        "uiso": float(atom.uiso),
                    }
                    for atom in phase.atoms()
                }
                for phase in project.phases()
            }
            result["rows"].append(row)

        last = result["rows"][-1]
        vals = [last["instrument"]["W"], last["instrument"]["X"]]
        scales = list(last["scales"].values())
        if not all(math.isfinite(v) and v >= 0 for v in vals + scales):
            result["status"] = "invalid_bound"
        elif not bool(last["covariance"]["converged"]):
            result["status"] = "not_converged"
        else:
            result["status"] = "complete"
        project.save()
    except Exception as exc:
        result["error"] = str(exc)
        result["traceback"] = traceback.format_exc()
    args.summary.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print("SUMMARY", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
