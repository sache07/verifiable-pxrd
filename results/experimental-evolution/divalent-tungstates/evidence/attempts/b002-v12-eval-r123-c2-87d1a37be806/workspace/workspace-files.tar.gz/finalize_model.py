#!/usr/bin/env python3
"""Prune, replay, and export the accepted GSAS-II model."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from gsas_workflow import refine_step, set_flags


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "gsas" / "convergence_loop" / "loop2_replay.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "BaWO4_ordered": {
        "name": "barium tungstate (scheelite)",
        "formula": "BaWO4",
        "cif_path": "phase_BaWO4.cif",
        "source": "ordered Ba-for-Sr scheelite analogue from COD 1546036; cell anchored/challenged against COD 1527204",
    },
    "Ba3W2O9_1533878": {
        "name": "tribarium ditungstate",
        "formula": "Ba3W2O9",
        "cif_path": "phase_Ba3W2O9.cif",
        "source": "COD 1533878",
    },
    "WO3_2311041": {
        "name": "tungsten trioxide",
        "formula": "WO3",
        "cif_path": "phase_WO3.cif",
        "source": "COD 2311041",
    },
    "BaCO3_9010928": {
        "name": "barium carbonate (witherite)",
        "formula": "BaCO3",
        "cif_path": "phase_BaCO3.cif",
        "source": "COD 9010928",
    },
}

STRAIN_PHASES = {"Ba3W2O9_1533878", "WO3_2311041", "BaCO3_9010928"}


def prune_and_flag(project) -> None:
    hist = project.histogram(0)
    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    x = np.asarray(hist.data["data"][1][0], dtype=float)
    hist.data["Limits"][1][:] = [float(x[0]), float(x[-1])]

    if len(hist.Background[0][3:]) != 9:
        raise RuntimeError("accepted checkpoint does not contain the 9-term background")
    hist.SampleParameters["Scale"][:] = [1.0, False]
    for key in ("Absorption", "DisplaceX", "DisplaceY", "Shift", "Transparency"):
        if isinstance(hist.SampleParameters.get(key), list):
            hist.SampleParameters[key][1] = False
    hist.SampleParameters["SurfRoughA"][:] = [0.0, False]
    hist.SampleParameters["SurfRoughB"][:] = [0.0, False]

    inst = hist.InstrumentParameters
    for key in ("U", "V", "Y", "Z"):
        inst[key][1] = 0.0
        inst[key][2] = False
    inst["I(L2)/I(L1)"][1:] = [0.5, False]
    inst["SH/L"][1:] = [0.002, False]

    strain_values = {}
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.getHAPvalues(hist.name)
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [100.0, 100.0, 1.0]
        hap["Size"][2][:] = [False] * len(hap["Size"][2])
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        strain_values[phase.name] = max(0.0, float(hap["Mustrain"][1][0]))
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"][:] = [0.0, False]
        hap["Babinet"]["BabA"][:] = [0.0, False]
        hap["Babinet"]["BabU"][:] = [0.0, False]

    set_flags(
        project,
        background=True,
        scales=True,
        cells=True,
        instrument=("Zero", "W", "X", "Polariz."),
    )
    for phase in project.phases():
        if phase.name in STRAIN_PHASES:
            hap = phase.getHAPvalues(hist.name)
            hap["Mustrain"][1][0] = strain_values[phase.name]
            hap["Mustrain"][2][0] = True


def export_outputs(project) -> dict:
    hist = project.histogram(0)
    fractions_raw = hist.ComputeMassFracs()
    total = sum(float(value[0]) for value in fractions_raw.values())
    if not np.isfinite(total) or total <= 0:
        raise RuntimeError("invalid modeled crystalline mass-fraction total")

    phases = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        cif_path = ROOT / info["cif_path"]
        phase.export_CIF(str(cif_path))
        cell, cell_esd = phase.get_cell_and_esd()
        raw_fraction, raw_esd = fractions_raw[phase.name]
        phases.append(
            {
                "name": info["name"],
                "formula": info["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": info["cif_path"],
                "project_path": "final.gpx",
                "weight_fraction": float(raw_fraction) / total,
                "weight_fraction_esd": float(raw_esd) / total,
                "source_model": info["source"],
                "cell": {key: float(value) for key, value in cell.items()},
                "cell_esd": {key: float(value) for key, value in cell_esd.items()},
            }
        )

    profile = np.asarray(hist.data["data"][1], dtype=float)
    two_theta, observed, _, calculated = profile[:4]
    difference = observed - calculated
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("two_theta_deg", "observed", "calculated", "difference"))
        writer.writerows(zip(two_theta, observed, calculated, difference))

    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    durbin_watson = float(hist.residuals.get("Durbin-Watson", float("nan")))
    fit_statistics = {
        "r_wp_percent": float(hist.residuals["wR"]),
        "r_p_percent": float(hist.residuals["R"]),
        "r_exp_percent": float(hist.residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_variables": int(rvals["Nvars"]),
        "durbin_watson": durbin_watson if np.isfinite(durbin_watson) else None,
    }
    result = {
        "project_path": "final.gpx",
        "fit_path": "fit.csv",
        "fraction_basis": "normalized over the modeled crystalline phases; amorphous content not quantified",
        "phases": phases,
        "fit_statistics": fit_statistics,
        "measurement": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelengths_angstrom": [1.540598, 1.544426],
            "kalpha2_to_kalpha1_ratio": 0.5,
            "two_theta_range_deg": [float(two_theta[0]), float(two_theta[-1])],
            "points": int(len(two_theta)),
        },
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    return result


def main() -> None:
    project = G2sc.G2Project(str(BASE), newgpx=str(FINAL))
    prune_and_flag(project)
    project.save()
    rows = [refine_step(project, "final_pruned"), refine_step(project, "final_pruned_replay")]
    project.save()

    # Required cold reopen and full-range replay. Outputs below are all read
    # from this saved/reopened project state.
    replayed = G2sc.G2Project(str(FINAL))
    rows.append(refine_step(replayed, "final_reopen_replay"))
    replayed.save()
    result = export_outputs(replayed)
    summary = {
        "base": str(BASE),
        "project": str(FINAL),
        "rows": rows,
        "result": result,
    }
    (ROOT / ".tmp" / "finalization_summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
