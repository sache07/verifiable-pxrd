#!/usr/bin/env python3
"""Replay one profile/background/geometry trial from a saved GSAS-II checkpoint."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import traceback

from GSASII import GSASIIscriptable as G2sc

from gsas_workflow import neutralize_phase, refine_step, set_flags


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--summary", type=Path, required=True)
    ap.add_argument(
        "--mode",
        required=True,
        choices=(
            "neutral",
            "size",
            "strain",
            "size_strain",
            "uniaxial_size",
            "uniaxial_strain",
            "background",
            "polarization",
            "roughness_a",
            "roughness_ab",
            "texture",
            "shl",
        ),
    )
    ap.add_argument("--phase")
    ap.add_argument("--axis", nargs=3, type=int)
    ap.add_argument("--background-order", type=int)
    args = ap.parse_args()

    result = {
        "mode": args.mode,
        "phase": args.phase,
        "axis": args.axis,
        "base": str(args.base.resolve()),
        "project": str(args.output.resolve()),
        "status": "error",
        "rows": [],
    }
    try:
        project = G2sc.G2Project(str(args.base), newgpx=str(args.output))
        hist = project.histogram(0)
        # Every trial starts from the same neutral HAP checkpoint.
        for phase in project.phases():
            neutralize_phase(phase, hist)

        target = project.phase(args.phase) if args.phase else None
        if args.mode in {
            "size",
            "strain",
            "size_strain",
            "uniaxial_size",
            "uniaxial_strain",
            "texture",
        } and target is None:
            raise ValueError("--phase is required for this trial")

        if target is not None:
            hap = target.getHAPvalues(hist.name)
        if args.mode in ("size", "size_strain"):
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 10.0
            hap["Size"][2][0] = True
        if args.mode in ("strain", "size_strain"):
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 100.0
            hap["Mustrain"][2][0] = True
        if args.mode == "uniaxial_size":
            if args.axis is None:
                raise ValueError("--axis is required for uniaxial broadening")
            hap["Size"][0] = "uniaxial"
            hap["Size"][3] = list(args.axis)
            hap["Size"][1][0:2] = [10.0, 10.0]
            hap["Size"][2][0:2] = [True, True]
        if args.mode == "uniaxial_strain":
            if args.axis is None:
                raise ValueError("--axis is required for uniaxial broadening")
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][3] = list(args.axis)
            hap["Mustrain"][1][0:2] = [100.0, 100.0]
            hap["Mustrain"][2][0:2] = [True, True]
        if args.mode == "texture":
            if args.axis is None:
                raise ValueError("--axis is required for texture")
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(args.axis)

        if args.mode == "background":
            if args.background_order is None:
                raise ValueError("--background-order is required")
            coeffs = list(hist.Background[0][3:])
            if len(coeffs) < args.background_order:
                coeffs += [0.0] * (args.background_order - len(coeffs))
            hist.set_refinements(
                {
                    "Background": {
                        "type": "chebyschev-1",
                        "no. coeffs": args.background_order,
                        "coeffs": coeffs[: args.background_order],
                        "refine": False,
                    }
                }
            )

        extra_instrument: tuple[str, ...] = ()
        extra_sample: tuple[str, ...] = ()
        if args.mode == "polarization":
            extra_instrument = ("Polariz.",)
        elif args.mode == "shl":
            extra_instrument = ("SH/L",)
        elif args.mode == "roughness_a":
            hist.SampleParameters["SurfRoughA"][0] = 0.01
            extra_sample = ("SurfRoughA",)
        elif args.mode == "roughness_ab":
            hist.SampleParameters["SurfRoughA"][0] = 0.01
            hist.SampleParameters["SurfRoughB"][0] = 0.01
            extra_sample = ("SurfRoughA", "SurfRoughB")

        set_flags(
            project,
            background=True,
            scales=True,
            cells=True,
            instrument=("Zero", "W", "X") + extra_instrument,
            sample=extra_sample,
        )
        # set_flags clears HAP flags, so restore the selected trial flags.
        if target is not None:
            hap = target.getHAPvalues(hist.name)
            if args.mode in ("size", "size_strain"):
                hap["Size"][2][0] = True
            if args.mode in ("strain", "size_strain"):
                hap["Mustrain"][2][0] = True
            if args.mode == "uniaxial_size":
                hap["Size"][2][0:2] = [True, True]
            if args.mode == "uniaxial_strain":
                hap["Mustrain"][2][0:2] = [True, True]
            if args.mode == "texture":
                hap["Pref.Ori."][2] = True

        project.save()
        for label in ("trial", "replay"):
            row = refine_step(project, label)
            row["mass_fractions"] = {
                key: list(value) for key, value in hist.ComputeMassFracs().items()
            }
            row["sample"] = {
                key: float(hist.SampleParameters[key][0])
                for key in ("SurfRoughA", "SurfRoughB")
            }
            row["hap"] = {
                phase.name: {
                    "scale": float(phase.getHAPvalues(hist.name)["Scale"][0]),
                    "size": list(phase.getHAPvalues(hist.name)["Size"][1]),
                    "size_type": phase.getHAPvalues(hist.name)["Size"][0],
                    "strain": list(phase.getHAPvalues(hist.name)["Mustrain"][1]),
                    "strain_type": phase.getHAPvalues(hist.name)["Mustrain"][0],
                    "md_ratio": float(phase.getHAPvalues(hist.name)["Pref.Ori."][1]),
                    "md_axis": list(phase.getHAPvalues(hist.name)["Pref.Ori."][3]),
                }
                for phase in project.phases()
            }
            result["rows"].append(row)

        last = result["rows"][-1]
        vals = [last["instrument"]["W"], last["instrument"]["X"]]
        if not all(math.isfinite(v) and v >= 0 for v in vals):
            result["status"] = "invalid_profile"
        else:
            result["status"] = "complete"
        project.save()
    except Exception as exc:
        result["error"] = str(exc)
        result["traceback"] = traceback.format_exc()
    args.summary.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print("SUMMARY", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
