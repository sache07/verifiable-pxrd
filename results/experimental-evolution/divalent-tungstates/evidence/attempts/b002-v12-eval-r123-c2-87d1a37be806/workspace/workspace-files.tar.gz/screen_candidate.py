#!/usr/bin/env python3
"""Add one phase source to a common checkpoint and replay a neutral fit loop."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import traceback

from GSASII import GSASIIscriptable as G2sc

from gsas_workflow import neutralize_phase, refine_step, set_flags


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", type=Path, required=True)
    ap.add_argument("--name", required=True)
    ap.add_argument("--cif", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--summary", type=Path, required=True)
    args = ap.parse_args()

    result = {
        "name": args.name,
        "cif": str(args.cif.resolve()),
        "project": str(args.output.resolve()),
        "status": "error",
        "rows": [],
    }
    try:
        project = G2sc.G2Project(str(args.base), newgpx=str(args.output))
        hist = project.histogram(0)
        phase = project.add_phase(
            str(args.cif), phasename=args.name, histograms=[hist], fmthint="CIF"
        )
        neutralize_phase(phase, hist)
        phase.getHAPvalues(hist.name)["Scale"][0] = 0.1
        hist.InstrumentParameters["U"][1] = 0.0
        project.save()

        # Scale is challenged before this candidate's cell. Existing-phase
        # cells and all common nuisance terms are reopened from the same base.
        set_flags(
            project,
            background=True,
            scales=True,
            cells=True,
            instrument=("Zero", "W", "X"),
        )
        phase.data["General"]["Cell"][0] = False
        first = refine_step(project, "candidate_scale_neutral_cell")
        result["rows"].append(first)
        scale = first["scales"][phase.name]
        if not math.isfinite(scale) or scale <= 1e-8:
            result["status"] = "collapsed"
            project.save()
        else:
            set_flags(
                project,
                background=True,
                scales=True,
                cells=True,
                instrument=("Zero", "W", "X"),
            )
            second = refine_step(project, "candidate_cell_profile")
            result["rows"].append(second)
            third = refine_step(project, "candidate_replay")
            result["rows"].append(third)
            if min(third["instrument"]["W"], third["instrument"]["X"]) < 0:
                result["status"] = "invalid_negative_profile"
            elif third["scales"][phase.name] <= 1e-8:
                result["status"] = "collapsed_after_cell"
            else:
                result["status"] = "positive"
            project.save()
    except Exception as exc:
        result["error"] = str(exc)
        result["traceback"] = traceback.format_exc()
    args.summary.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print("SUMMARY", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
