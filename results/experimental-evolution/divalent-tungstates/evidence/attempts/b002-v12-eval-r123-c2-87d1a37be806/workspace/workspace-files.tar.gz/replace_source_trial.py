#!/usr/bin/env python3
"""Replace one phase source in a converged inventory and replay it fairly."""

from __future__ import annotations

import argparse
from copy import deepcopy
import json
import math
from pathlib import Path
import traceback

from GSASII import GSASIIscriptable as G2sc

from gsas_workflow import neutralize_phase, refine_step, set_flags


def remove_phase(project, histogram, name: str) -> None:
    """Remove a phase and its histogram link from a copied project."""
    histogram.data["Reflection Lists"].pop(name, None)
    project.data["Phases"].pop(name)
    for item in project.names:
        if item and item[0] == "Phases":
            while name in item:
                item.remove(name)
            break
    project.update_ids()


def active_hap_flags(project, histogram):
    out = {}
    for phase in project.phases():
        hap = phase.getHAPvalues(histogram.name)
        out[phase.name] = {
            "size": list(hap["Size"][2]),
            "size_g": list(hap["Size"][5]),
            "strain": list(hap["Mustrain"][2]),
            "strain_g": list(hap["Mustrain"][5]),
            "texture": bool(hap["Pref.Ori."][2]),
        }
    return out


def restore_hap_flags(project, histogram, flags) -> None:
    for phase in project.phases():
        hap = phase.getHAPvalues(histogram.name)
        old = flags[phase.name]
        hap["Size"][2][:] = old["size"]
        hap["Size"][5][:] = old["size_g"]
        hap["Mustrain"][2][:] = old["strain"]
        hap["Mustrain"][5][:] = old["strain_g"]
        hap["Pref.Ori."][2] = old["texture"]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", type=Path, required=True)
    ap.add_argument("--phase", required=True)
    ap.add_argument("--cif", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--summary", type=Path, required=True)
    args = ap.parse_args()

    result = {
        "base": str(args.base.resolve()),
        "phase": args.phase,
        "cif": str(args.cif.resolve()),
        "project": str(args.output.resolve()),
        "status": "error",
        "rows": [],
    }
    try:
        project = G2sc.G2Project(str(args.base), newgpx=str(args.output))
        hist = project.histogram(0)
        old_phase = project.phase(args.phase)
        old_hap = deepcopy(old_phase.getHAPvalues(hist.name))
        old_scale = float(old_hap["Scale"][0])
        old_strain = max(0.0, float(old_hap["Mustrain"][1][0]))

        remove_phase(project, hist, args.phase)
        new_phase = project.add_phase(
            str(args.cif),
            phasename=args.phase,
            histograms=[hist],
            fmthint="CIF",
        )
        neutralize_phase(new_phase, hist)
        new_hap = new_phase.getHAPvalues(hist.name)
        new_hap["Scale"][0] = old_scale
        new_hap["Size"][1][:] = list(old_hap["Size"][1])
        if old_strain > 0:
            new_hap["Mustrain"][0] = "isotropic"
            new_hap["Mustrain"][1][0] = old_strain
            new_hap["Mustrain"][2][0] = True
        project.save()

        # The replacement first earns scale at its source cell. All shared
        # nuisance values and accepted broadening are cross-seeded from base.
        for label, refine_target_cell in (
            ("source_cell_fixed", False),
            ("source_cell_released", True),
            ("source_replay", True),
        ):
            flags = active_hap_flags(project, hist)
            set_flags(
                project,
                background=True,
                scales=True,
                cells=True,
                instrument=("Zero", "W", "X", "Polariz."),
            )
            restore_hap_flags(project, hist, flags)
            if not refine_target_cell:
                new_phase.data["General"]["Cell"][0] = False
            row = refine_step(project, label)
            row["mass_fractions"] = {
                key: list(value) for key, value in hist.ComputeMassFracs().items()
            }
            row["hap"] = {
                phase.name: {
                    "scale": float(phase.getHAPvalues(hist.name)["Scale"][0]),
                    "strain": list(phase.getHAPvalues(hist.name)["Mustrain"][1]),
                    "strain_type": phase.getHAPvalues(hist.name)["Mustrain"][0],
                }
                for phase in project.phases()
            }
            row["covariance"] = {
                key: project.data["Covariance"]["data"].get("Rvals", {}).get(key)
                for key in ("converged", "chisq", "Nobs", "Nvars", "GOF", "Max shft/sig")
            }
            result["rows"].append(row)
            if row["scales"][args.phase] <= 1e-8:
                result["status"] = "collapsed"
                break
        else:
            last = result["rows"][-1]
            bounded = [
                last["instrument"]["W"],
                last["instrument"]["X"],
                *last["scales"].values(),
            ]
            if not all(math.isfinite(value) and value >= 0 for value in bounded):
                result["status"] = "invalid_bound"
            elif not bool(last["covariance"]["converged"]):
                result["status"] = "not_converged"
            else:
                result["status"] = "complete"
        project.save()
    except Exception as exc:
        result["error"] = str(exc)
        result["traceback"] = traceback.format_exc()
    args.summary.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print("SUMMARY", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
