#!/usr/bin/env python3
"""Small, reproducible GSAS-II helpers for this powder-pattern analysis."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
INSTRUMENT = ROOT / "instrument.instprm"


def neutralize_phase(phase, histogram) -> None:
    """Put inactive HAP terms at genuinely neutral physical values."""
    hap = phase.getHAPvalues(histogram.name)
    hap["Scale"][1] = False
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [100.0, 100.0, 1.0]
    hap["Size"][2][:] = [False] * len(hap["Size"][2])
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def configure_common(project, background_order: int = 6) -> None:
    hist = project.histogram(0)
    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5

    # The histogram scale is fixed so independently refined HAP scales define
    # quantitative phase fractions without a redundant overall-scale variable.
    hist.SampleParameters["Scale"][:] = [1.0, False]
    for key in ("Absorption", "DisplaceX", "DisplaceY", "Shift", "Transparency"):
        if isinstance(hist.SampleParameters.get(key), list):
            hist.SampleParameters[key][1] = False
    for key in ("SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key][:] = [0.0, False]

    inst = hist.InstrumentParameters
    starts = {
        "Zero": 0.0,
        "Polariz.": 0.7,
        "I(L2)/I(L1)": 0.5,
        "U": 2.0,
        "V": 0.0,
        # Deliberately broad only for source screening: COD cells can be
        # displaced by a few tenths of a degree from this specimen. Once the
        # cells/zero align, W is released and contracts to the observed width.
        "W": 100.0,
        "X": 0.1,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }
    for key, value in starts.items():
        inst[key][1] = value
        inst[key][2] = False

    # Coefficients are a stable starting approximation obtained from a
    # phase-scale/background-only pass over the full measured range.
    seed = [1154.18, -873.15, 372.23, -209.77, 69.69, -22.59, 0.0, 0.0]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": background_order,
                "coeffs": seed[:background_order],
                "refine": False,
            }
        }
    )
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        neutralize_phase(phase, hist)


def clear_flags(project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.getHAPvalues(hist.name)
        hap["Scale"][1] = False
        hap["Size"][2][:] = [False] * len(hap["Size"][2])
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2][:] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False
        hap["Babinet"]["BabA"][1] = False
        hap["Babinet"]["BabU"][1] = False


def set_flags(
    project,
    *,
    background: bool = False,
    scales: bool = False,
    cells: bool = False,
    instrument: tuple[str, ...] = (),
    sample: tuple[str, ...] = (),
    phase_names: tuple[str, ...] | None = None,
) -> None:
    clear_flags(project)
    hist = project.histogram(0)
    hist.Background[0][1] = bool(background)
    for key in instrument:
        hist.InstrumentParameters[key][2] = True
    for key in sample:
        hist.SampleParameters[key][1] = True
    selected = project.phases() if phase_names is None else [project.phase(n) for n in phase_names]
    for phase in selected:
        if scales:
            phase.getHAPvalues(hist.name)["Scale"][1] = True
        if cells:
            phase.data["General"]["Cell"][0] = True


def refine_step(project, label: str) -> dict:
    project.refine(makeBack=False)
    hist = project.histogram(0)
    row = {
        "label": label,
        "residuals": {k: float(v) if isinstance(v, (int, float)) else v for k, v in hist.residuals.items()},
        "scales": {
            p.name: float(p.getHAPvalues(hist.name)["Scale"][0]) for p in project.phases()
        },
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "instrument": {
            k: float(hist.InstrumentParameters[k][1])
            for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "background": [float(v) for v in hist.Background[0][3:]],
        "vary_list": list(project.data["Covariance"]["data"].get("varyList", [])),
        "frozen": dict(project.data["Controls"]["data"].get("parmFrozen", {})),
    }
    print("STEP", json.dumps(row, sort_keys=True))
    return row


def create_project(output: Path, phases: list[tuple[str, Path]], background_order: int = 6):
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(PATTERN), str(INSTRUMENT), fmthint="comma"
    )
    for name, cif in phases:
        project.add_phase(
            str(cif), phasename=name, histograms=[hist], fmthint="CIF"
        )
    configure_common(project, background_order)
    # Similar positive starts let scale-only screening reveal collapse cleanly.
    for phase in project.phases():
        phase.getHAPvalues(hist.name)["Scale"][0] = 0.03
    project.save()
    return project


def add_competitor(base: Path, output: Path, name: str, cif: Path):
    project = G2sc.G2Project(str(base), newgpx=str(output))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cif), phasename=name, histograms=[hist], fmthint="CIF"
    )
    phase.getHAPvalues(hist.name)["Scale"][0] = 0.01
    phase.data["General"]["Cell"][0] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "
    neutralize_phase(phase, hist)
    project.save()
    return project


def baseline_loop(project) -> list[dict]:
    """Converge smooth background, scales, cells, zero and common U/W/X."""
    rows = []
    set_flags(project, background=True, scales=True)
    rows.append(refine_step(project, "background_scales"))
    set_flags(project, background=True, scales=True, cells=True, instrument=("Zero",))
    rows.append(refine_step(project, "cells_zero"))
    set_flags(
        project,
        background=True,
        scales=True,
        cells=True,
        instrument=("Zero", "U", "W", "X"),
    )
    rows.append(refine_step(project, "profile"))
    # Replay once from the converged nuisance state.
    rows.append(refine_step(project, "profile_replay"))
    project.save()
    return rows
