#!/usr/bin/env python3
"""One-at-a-time nuisance and phase-broadening trials from the accepted inventory."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "trial_2311041_monoclinic_neutron.gpx"


def run_trial(label: str) -> dict:
    out = ROOT / f"model_{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = project.histogram(0)
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    project["Controls"]["data"]["min dM/M"] = 1e-7

    if label == "polarization":
        hist.InstrumentParameters["Polariz."][2] = True
        project.set_Controls("parmMin", 0.0, ":0:Polariz.")
        project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    elif label == "roughness_B":
        hist.SampleParameters["SurfRoughA"] = [0.0, False]
        hist.SampleParameters["SurfRoughB"] = [0.01, True]
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
        project.set_Controls("parmMax", 1.0, ":0:SurfRoughB")
    elif label == "SH_L":
        hist.InstrumentParameters["SH/L"][1] = 0.002
        hist.InstrumentParameters["SH/L"][2] = True
        project.set_Controls("parmMin", 0.002, ":0:SH/L")
        project.set_Controls("parmMax", 1.0, ":0:SH/L")
    elif label.startswith("strain_"):
        name = label.removeprefix("strain_")
        phase = project.phase(name)
        hap = phase.getHAPvalues(hist.name)
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [100.0, 100.0, 1.0]
        hap["Mustrain"][2] = [True, False, False]
        variable = f"{phase.id}:0:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable)
        project.set_Controls("parmMax", 10000.0, variable)
    else:
        raise ValueError(label)

    project.save()
    project.refine()
    result = {
        "label": label,
        "Rwp_percent": hist.residuals["wR"],
        "Rp_percent": hist.residuals["R"],
        "GOF": hist.residuals["wR"] / hist.residuals["wRmin"],
        "weight_fractions": {
            name: value[0] for name, value in hist.ComputeMassFracs().items()
        },
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "roughness_A": hist.SampleParameters["SurfRoughA"][0],
        "roughness_B": hist.SampleParameters["SurfRoughB"][0],
        "SH_L": hist.InstrumentParameters["SH/L"][1],
        "microstrain": {
            phase.name: phase.getHAPvalues(hist.name)["Mustrain"][1][0]
            for phase in project.phases()
        },
        "sizes_micrometre": {
            phase.name: phase.getHAPvalues(hist.name)["Size"][1][0]
            for phase in project.phases()
        },
        "frozen": project.get_Frozen(),
    }
    return result


def main() -> None:
    labels = [
        "polarization",
        "roughness_B",
        "SH_L",
        "strain_ZnWO4",
        "strain_ZnO",
        "strain_WO3",
    ]
    results = []
    for label in labels:
        print(f"\n===== {label} =====", flush=True)
        try:
            results.append(run_trial(label))
        except Exception as exc:
            results.append({"label": label, "error": f"{type(exc).__name__}: {exc}"})
    (ROOT / "model_trials.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
