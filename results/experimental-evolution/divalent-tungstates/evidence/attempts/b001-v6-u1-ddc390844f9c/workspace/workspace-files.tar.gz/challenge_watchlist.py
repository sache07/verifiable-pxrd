#!/usr/bin/env python3
"""Re-challenge weak polymorph candidates under the accepted common profile."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
BASE = ROOT / "trial_2311041_monoclinic_neutron.gpx"
CANDIDATES = {
    "WO3_orthorhombic_2107312": (CIF_ROOT / "2/10/73/2107312.cif", 0.24),
    "WO3_tetragonal_1521532": (CIF_ROOT / "1/52/15/1521532.cif", 0.24),
    "WO3_high_pressure_1563541": (CIF_ROOT / "1/56/35/1563541.cif", 0.24),
    "ZnO_zincblende_1537875": (CIF_ROOT / "1/53/78/1537875.cif", 10.0),
    "ZnO_rocksalt_1534836": (CIF_ROOT / "1/53/48/1534836.cif", 10.0),
}


def challenge(label: str, cif: Path, size: float) -> dict:
    out = ROOT / f"watch_{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = project.histogram(0)
    phase = project.add_phase(str(cif), phasename="Watch", histograms=[hist])
    phase.set_refinements({"Cell": False})
    hap = phase.getHAPvalues(hist.name)
    hap["Scale"] = [0.05, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [size, size, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.1, 0.1, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    project.set_Controls("cycles", 20)
    project["Controls"]["data"]["min dM/M"] = 1e-7
    project.set_Controls("parmMin", 0.0, "3:0:Scale")
    project.set_Controls("parmMax", 100.0, "3:0:Scale")
    project.save()
    project.refine()
    fractions = hist.ComputeMassFracs()
    return {
        "label": label,
        "cif": str(cif),
        "Rwp_percent": hist.residuals["wR"],
        "GOF": hist.residuals["wR"] / hist.residuals["wRmin"],
        "watch_scale": phase.HAPvalue("Scale"),
        "watch_weight_fraction": fractions.get("Watch", [0.0])[0],
        "all_weight_fractions": {name: value[0] for name, value in fractions.items()},
        "frozen": project.get_Frozen(),
    }


def main() -> None:
    results = []
    for label, (cif, size) in CANDIDATES.items():
        print(f"\n===== {label} =====", flush=True)
        try:
            results.append(challenge(label, cif, size))
        except Exception as exc:
            results.append({"label": label, "error": f"{type(exc).__name__}: {exc}"})
    (ROOT / "watchlist_trials.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
