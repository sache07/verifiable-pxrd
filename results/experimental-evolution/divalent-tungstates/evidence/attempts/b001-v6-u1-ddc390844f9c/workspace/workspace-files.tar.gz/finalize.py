#!/usr/bin/env python3
"""Replay the selected GSAS-II model and export the exact submitted results."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "model_selected.gpx"
FINAL = ROOT / "final.gpx"

PHASE_METADATA = {
    "ZnWO4": {
        "formula": "ZnWO4",
        "structure_type": "wolframite",
        "source_database": "Crystallography Open Database",
        "source_record": "1520641",
    },
    "ZnO": {
        "formula": "ZnO",
        "structure_type": "wurtzite (zincite)",
        "source_database": "Crystallography Open Database",
        "source_record": "9004178",
    },
    "WO3": {
        "formula": "WO3",
        "structure_type": "room-temperature monoclinic tungsten trioxide",
        "source_database": "Crystallography Open Database",
        "source_record": "2311041",
    },
}


def set_final_model(project: G2sc.G2Project) -> None:
    """Remove stale bounds and explicitly neutralize every unused profile term."""
    hist = project.histogram(0)

    # Use the complete observed range and no excluded regions.
    hist.data["Limits"][1] = list(hist.data["Limits"][0])

    # One correction for peak positions and a nonnegative common U/W/X profile.
    instr = hist.InstrumentParameters
    instr["U"][1:] = [0.0, False]
    instr["V"][1:] = [0.0, False]
    instr["X"][1:] = [3.8, False]
    instr["Y"][1:] = [0.0, False]
    instr["Z"][1:] = [0.0, False]
    instr["SH/L"][1:] = [0.002, False]
    instr["Polariz."][1:] = [0.7, False]

    sample = hist.SampleParameters
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"][1] = True

    # ZnWO4 retains isotropic coherent-domain broadening. All other size
    # terms are at the neutral 10 micrometre upper value. Only WO3 retains
    # microstrain, in the selected uniaxial [0 1 1] model.
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

        if phase.name == "ZnWO4":
            hap["Size"][0] = "isotropic"
            hap["Size"][2] = [True, False, False]
        else:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 10.0
            hap["Size"][2] = [False, False, False]

        if phase.name == "WO3":
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][2] = [True, True, False]
            hap["Mustrain"][3] = [0, 1, 1]
        else:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][1][1] = 0.0
            hap["Mustrain"][2] = [False, False, False]

    # Rebuild bounds so no rejected or inactive trial remains in the project.
    controls = project["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 40)
    controls["min dM/M"] = 1.0e-8
    bounds = {
        ":0:W": (0.0, 100.0),
        ":0:SurfRoughB": (0.0, 1.0),
        "0:0:Size;i": (0.005, 10.0),
        "2:0:Mustrain;i": (0.0, 10000.0),
        "2:0:Mustrain;a": (0.0, 10000.0),
    }
    for variable, (lower, upper) in bounds.items():
        project.set_Controls("parmMin", lower, variable)
        project.set_Controls("parmMax", upper, variable)


def profile_parameter(hist, key: str) -> float:
    return float(hist.InstrumentParameters[key][1])


def export_results(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()

    phases = []
    for phase in project.phases():
        cif_name = f"{phase.name}.cif"
        phase.export_CIF(str(ROOT / cif_name))
        cell, cell_esd = phase.get_cell_and_esd()
        fraction, fraction_esd = fractions[phase.name]
        metadata = PHASE_METADATA[phase.name]
        phases.append(
            {
                "name": phase.name,
                **metadata,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif": cif_name,
                "weight_fraction": float(fraction),
                "formal_weight_fraction_esd": float(fraction_esd),
                "weight_percent": 100.0 * float(fraction),
                "formal_weight_percent_esd": 100.0 * float(fraction_esd),
                "cell": {key: float(value) for key, value in cell.items()},
                "formal_cell_esd": {
                    key: float(value) for key, value in cell_esd.items()
                },
            }
        )

    # Export exactly the profile arrays stored in this final project.
    x = np.asarray(hist.getdata("x"), dtype=float)
    observed = np.asarray(hist.getdata("yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("ycalc"), dtype=float)
    background = np.asarray(hist.getdata("background"), dtype=float)
    difference = observed - calculated
    stored_difference = np.asarray(hist.getdata("residual"), dtype=float)
    if not np.allclose(difference, stored_difference, rtol=0.0, atol=1.0e-8):
        raise RuntimeError("GSAS-II stored residual does not equal observed-calculated")

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_intensity",
                "background_intensity",
            ]
        )
        for row in zip(x, observed, calculated, difference, background):
            writer.writerow([format(float(value), ".15g") for value in row])

    residuals = hist.residuals
    rvals = project["Covariance"]["data"]["Rvals"]
    nobs = int(rvals["Nobs"])
    nvars = int(rvals["Nvars"])
    gof = float(rvals["GOF"])
    result = {
        "analysis": "GSAS-II Rietveld refinement",
        "project": "final.gpx",
        "profile": "fit.csv",
        "weight_fraction_basis": (
            "Normalized over the modeled crystalline phases; no amorphous "
            "fraction or absolute crystalline content was determined."
        ),
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": float(rvals["Rwp"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "GOF": gof,
            "chi_square": float(rvals["chisq"]),
            "reduced_chi_square": gof * gof,
            "N_observations": nobs,
            "N_variables": nvars,
            "degrees_of_freedom": nobs - nvars,
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
            "background_Rwp_percent": float(residuals["wRb"]),
            "weighting": (
                "Poisson estimate, weight=1/observed intensity, because "
                "pointwise standard uncertainties were not supplied"
            ),
        },
        "measurement": {
            "geometry": "reflection, Bragg-Brentano model",
            "radiation": "Cu K-alpha doublet",
            "wavelength_Kalpha1_angstrom": profile_parameter(hist, "Lam1"),
            "wavelength_Kalpha2_angstrom": profile_parameter(hist, "Lam2"),
            "Kalpha2_to_Kalpha1_ratio": profile_parameter(hist, "I(L2)/I(L1)"),
            "two_theta_min_deg": float(x[0]),
            "two_theta_max_deg": float(x[-1]),
            "number_of_points": int(x.size),
        },
        "refinement_model": {
            "background": "6-term Chebyshev-1 polynomial",
            "angular_correction": {
                "type": "zero shift",
                "value_deg": profile_parameter(hist, "Zero"),
            },
            "common_profile": {
                key: profile_parameter(hist, key)
                for key in ("U", "V", "W", "X", "Y", "SH/L")
            },
            "surface_roughness_B": float(hist.SampleParameters["SurfRoughB"][0]),
            "preferred_orientation": "none",
            "phase_broadening": {
                "ZnWO4_isotropic_size_micrometre": float(
                    project.phase("ZnWO4").getHAPvalues(hist.name)["Size"][1][0]
                ),
                "WO3_uniaxial_microstrain_axis": [0, 1, 1],
                "WO3_microstrain_coefficients": [
                    float(value)
                    for value in project.phase("WO3").getHAPvalues(hist.name)[
                        "Mustrain"
                    ][1][:2]
                ],
            },
        },
        "uncertainty_note": (
            "Reported esds are formal covariance estimates. Model/source/profile "
            "systematics dominate the practical phase-fraction uncertainty."
        ),
    }

    fraction_sum = sum(item["weight_fraction"] for item in phases)
    if not math.isclose(fraction_sum, 1.0, rel_tol=0.0, abs_tol=1.0e-10):
        raise RuntimeError(f"Weight fractions do not sum to one: {fraction_sum}")
    if x.size != nobs or not all(np.isfinite(a).all() for a in (x, observed, calculated)):
        raise RuntimeError("Profile export failed an observation-count or finite-value check")

    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def main() -> None:
    project = G2sc.G2Project(str(BASE), newgpx=str(FINAL))
    set_final_model(project)
    project.save()
    project.refine()

    # Reopen the persisted project before every submitted export so the CIFs,
    # fractions and profile are guaranteed to come from final.gpx.
    final_project = G2sc.G2Project(str(FINAL))
    result = export_results(final_project)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
