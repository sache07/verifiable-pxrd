#!/usr/bin/env python3
"""Compare no texture with low-index March-Dollase axes."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "anisotropy_WO3_011.gpx"
AXES = {
    "100": [1, 0, 0],
    "010": [0, 1, 0],
    "001": [0, 0, 1],
    "110": [1, 1, 0],
    "101": [1, 0, 1],
    "011": [0, 1, 1],
}


def trial(phase_name: str, label: str, axis: list[int]) -> dict:
    out = ROOT / f"texture_{phase_name}_{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = project.histogram(0)
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    project["Controls"]["data"]["min dM/M"] = 1e-7
    phase = project.phase(phase_name)
    po = phase.getHAPvalues(hist.name)["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = axis
    variable = f"{phase.id}:0:MD"
    project.set_Controls("parmMin", 0.2, variable)
    project.set_Controls("parmMax", 5.0, variable)
    project.save()
    project.refine()
    return {
        "phase": phase_name,
        "axis": axis,
        "Rwp_percent": hist.residuals["wR"],
        "GOF": hist.residuals["wR"] / hist.residuals["wRmin"],
        "MD": phase.getHAPvalues(hist.name)["Pref.Ori."][1],
        "weight_fractions": {
            name: value[0] for name, value in hist.ComputeMassFracs().items()
        },
        "frozen": project.get_Frozen(),
    }


def main() -> None:
    results = []
    for phase_name in ("ZnWO4", "WO3"):
        for label, axis in AXES.items():
            print(f"\n===== {phase_name} {label} =====", flush=True)
            try:
                results.append(trial(phase_name, label, axis))
            except Exception as exc:
                results.append(
                    {
                        "phase": phase_name,
                        "axis": axis,
                        "error": f"{type(exc).__name__}: {exc}",
                    }
                )
    (ROOT / "texture_trials.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
