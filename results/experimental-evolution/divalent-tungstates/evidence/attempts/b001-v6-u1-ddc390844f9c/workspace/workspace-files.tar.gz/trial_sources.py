#!/usr/bin/env python3
"""Compare physically plausible WO3 source records under one nuisance model."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
ZNWO4 = CIF_ROOT / "1/52/06/1520641.cif"
ZNO = CIF_ROOT / "9/00/41/9004178.cif"
WO3_RECORDS = {
    "2311041_monoclinic_neutron": CIF_ROOT / "2/31/10/2311041.cif",
    "1528915_monoclinic_room_temperature": CIF_ROOT / "1/52/89/1528915.cif",
    "2106293_triclinic": CIF_ROOT / "2/10/62/2106293.cif",
    "2107312_orthorhombic": CIF_ROOT / "2/10/73/2107312.cif",
    "1521532_tetragonal": CIF_ROOT / "1/52/15/1521532.cif",
}

BACKGROUND = [
    1276.2016559205892,
    -717.7005255453265,
    469.7827287689842,
    -247.8727703843173,
    105.9599468561256,
    -34.729521454075766,
]


def build_and_refine(label: str, wo3_cif: Path) -> dict:
    out = ROOT / f"trial_{label}.gpx"
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(ROOT / "measured.xye"), str(ROOT / "instrument.instprm")
    )
    phases = [
        project.add_phase(str(ZNWO4), phasename="ZnWO4", histograms=[hist]),
        project.add_phase(str(ZNO), phasename="ZnO", histograms=[hist]),
        project.add_phase(str(wo3_cif), phasename="WO3", histograms=[hist]),
    ]
    project.set_Controls("cycles", 25)
    project["Controls"]["data"]["min dM/M"] = 1e-6
    hist.SampleParameters["Scale"] = [1.0, False]
    for item in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if item in hist.SampleParameters:
            hist.SampleParameters[item] = [0.0, False]

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": BACKGROUND,
            }
        }
    )
    for key in hist.InstrumentParameters:
        hist.InstrumentParameters[key][2] = False
    for key, value in {
        "Zero": 0.02849,
        "U": 0.0,
        "V": 0.0,
        "W": 9.54,
        "X": 3.8,
        "Y": 0.0,
        "SH/L": 0.002,
    }.items():
        hist.InstrumentParameters[key][1] = value
    hist.InstrumentParameters["Zero"][2] = True

    scale_starts = {"ZnWO4": 19.39, "ZnO": 9.15, "WO3": 1.59}
    size_starts = {"ZnWO4": 0.089, "ZnO": 10.0, "WO3": 0.24}
    for phase in phases:
        phase.set_refinements({"Cell": True})
        hap = phase.getHAPvalues(hist.name)
        hap["Scale"] = [scale_starts[phase.name], True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [size_starts[phase.name], 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.1, 0.1, 1.0]
        hap["Mustrain"][2] = [False, False, False]

    # Reconverge the shared baseline after the source change.
    project.save()
    project.refine()

    # Compare size under the same clean profile; ZnO remains instrument-limited.
    hist.InstrumentParameters["W"][2] = True
    for index, phase in enumerate(phases):
        if phase.name in ("ZnWO4", "WO3"):
            phase.getHAPvalues(hist.name)["Size"][2][0] = True
            project.set_Controls("parmMin", 0.005, f"{index}:0:Size;i")
            project.set_Controls("parmMax", 10.0, f"{index}:0:Size;i")
    project.set_Controls("parmMin", 0.0, ":0:W")
    project.set_Controls("parmMax", 100.0, ":0:W")
    project.save()
    project.refine()

    result = {
        "label": label,
        "wo3_cif": str(wo3_cif),
        "Rwp_percent": hist.residuals["wR"],
        "Rp_percent": hist.residuals["R"],
        "GOF": hist.residuals["wR"] / hist.residuals["wRmin"],
        "weight_fractions": {
            name: values[0] for name, values in hist.ComputeMassFracs().items()
        },
        "scales": {phase.name: phase.HAPvalue("Scale") for phase in phases},
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "sizes_micrometre": {
            phase.name: phase.getHAPvalues(hist.name)["Size"][1][0]
            for phase in phases
        },
        "W": hist.InstrumentParameters["W"][1],
        "zero_deg": hist.InstrumentParameters["Zero"][1],
        "frozen": project.get_Frozen(),
    }
    return result


def main() -> None:
    results = []
    for label, path in WO3_RECORDS.items():
        print(f"\n===== {label} =====", flush=True)
        try:
            results.append(build_and_refine(label, path))
        except Exception as exc:
            results.append({"label": label, "error": f"{type(exc).__name__}: {exc}"})
    target = ROOT / "source_trials.json"
    target.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
