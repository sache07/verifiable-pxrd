#!/usr/bin/env python3
"""Challenge monoclinic WO3 with symmetry-distinct uniaxial strain axes."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "rough_strainWO3.gpx"
AXES = {
    "100": [1, 0, 0],
    "010": [0, 1, 0],
    "001": [0, 0, 1],
    "110": [1, 1, 0],
    "101": [1, 0, 1],
    "011": [0, 1, 1],
}


def trial(label: str, axis: list[int]) -> dict:
    out = ROOT / f"anisotropy_WO3_{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = project.histogram(0)
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    project["Controls"]["data"]["min dM/M"] = 1e-7
    phase = project.phase("WO3")
    hap = phase.getHAPvalues(hist.name)
    strain = hap["Mustrain"]
    strain[0] = "uniaxial"
    strain[1] = [2803.0, 2803.0, 1.0]
    strain[2] = [True, True, False]
    strain[3] = axis
    for variable in ("2:0:Mustrain;i", "2:0:Mustrain;a"):
        project.set_Controls("parmMin", 0.0, variable)
        project.set_Controls("parmMax", 10000.0, variable)
    project.save()
    project.refine()
    return {
        "axis": axis,
        "Rwp_percent": hist.residuals["wR"],
        "GOF": hist.residuals["wR"] / hist.residuals["wRmin"],
        "strain_values": phase.getHAPvalues(hist.name)["Mustrain"][1],
        "weight_fractions": {
            name: value[0] for name, value in hist.ComputeMassFracs().items()
        },
        "frozen": project.get_Frozen(),
    }


def main() -> None:
    results = []
    for label, axis in AXES.items():
        print(f"\n===== {label} =====", flush=True)
        try:
            results.append(trial(label, axis))
        except Exception as exc:
            results.append({"axis": axis, "error": f"{type(exc).__name__}: {exc}"})
    (ROOT / "anisotropy_trials.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
