#!/usr/bin/env python3
"""Create final.gpx and export the final profiles and phase CIFs."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIpwd as G2pwd
from GSASII import GSASIIscriptable as G2sc

from gsas_branch import project_summary


BASE = Path(".tmp/branches/Orestr_replay.gpx")
FINAL = Path("final.gpx")


def refine_full_range(project: G2sc.G2Project) -> None:
    histogram = project.histogram(0)
    measured_limits = histogram.data["Limits"][0]
    histogram.set_refinements(
        {"Limits": [float(measured_limits[0]), float(measured_limits[1])]}
    )
    project.set_Controls("cycles", 15)
    project.refine(makeBack=False)
    project.save()


project = G2sc.G2Project(str(BASE), newgpx=str(FINAL))
refine_full_range(project)

# Required fresh native replay from the saved project.
project = G2sc.G2Project(str(FINAL))
refine_full_range(project)

histogram = project.histogram(0)
phase_files = {
    "SrWO4_scheelite": Path("phase_SrWO4.cif"),
    "WO3": Path("phase_WO3.cif"),
    "SrCO3": Path("phase_SrCO3.cif"),
}
for name, path in phase_files.items():
    project.phase(name).export_CIF(str(path), quickmode=True)

x, observed, weights, calculated, background, difference = histogram.data["data"][1]
with Path("fit.csv").open("w", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(
        ["two_theta_deg", "observed", "calculated", "difference", "background"]
    )
    writer.writerows(
        zip(
            np.asarray(x, dtype=float),
            np.asarray(observed, dtype=float),
            np.asarray(calculated, dtype=float),
            np.asarray(difference, dtype=float),
            np.asarray(background, dtype=float),
        )
    )

summary = project_summary(project, "final_full_range_fresh_replay")
summary["phase_files"] = {name: str(path) for name, path in phase_files.items()}
summary["point_count"] = int(len(x))
summary["refinement_limits_two_theta_deg"] = [
    float(histogram.data["Limits"][1][0]),
    float(histogram.data["Limits"][1][1]),
]
inst = histogram.data["Instrument Parameters"][0]
summary["common_profile_fwhm_deg"] = {
    str(angle): float(G2pwd.getFWHM(float(angle), inst))
    for angle in (17.5, 45.0, 72.5, 86.5, 95.0)
}
summary["covariance_Rvals"] = {
    str(key): (
        float(value)
        if isinstance(value, (int, float, np.integer, np.floating))
        else str(value)
    )
    for key, value in project.data["Covariance"]["data"].get("Rvals", {}).items()
}
Path(".tmp/final_summary.json").write_text(
    json.dumps(summary, indent=2, sort_keys=True) + "\n"
)
