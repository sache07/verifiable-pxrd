#!/usr/bin/env python3
"""Continue a GSAS-II project with one controlled model challenge."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def covariance_summary(project) -> dict:
    data = project.data["Covariance"]["data"]
    names = [str(value) for value in data.get("varyList", [])]
    values = np.asarray(data.get("variables", []), dtype=float)
    sigmas = np.asarray(data.get("sig", []), dtype=float)
    covariance = np.asarray(data.get("covMatrix", []), dtype=float)
    parameters = {
        name: {"value": float(value), "sigma": float(sigma)}
        for name, value, sigma in zip(names, values, sigmas)
    }
    correlations = []
    if covariance.ndim == 2 and covariance.shape[0] == len(names):
        denom = np.sqrt(np.outer(np.diag(covariance), np.diag(covariance)))
        corr = np.divide(covariance, denom, out=np.zeros_like(covariance), where=denom > 0)
        for i in range(len(names)):
            for j in range(i):
                correlations.append((abs(float(corr[i, j])), names[i], names[j], float(corr[i, j])))
        correlations.sort(reverse=True)
    return {
        "parameters": parameters,
        "largest_correlations": [
            {"absolute": value, "left": left, "right": right, "signed": signed}
            for value, left, right, signed in correlations[:15]
        ],
        "frozen": project.get_Frozen(),
        "last_shifts": [float(value) for value in data.get("Lastshft", [])],
    }


def project_summary(project, mode: str) -> dict:
    histogram = project.histogram(0)
    inst = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": phase.HAPvalue("Scale", targethistlist=[histogram]),
            "preferred_orientation": hap["Pref.Ori."],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    return {
        "mode": mode,
        "residuals": histogram.residuals,
        "instrument": {
            key: inst[key][1]
            for key in (
                "Zero",
                "Polariz.",
                "U",
                "V",
                "W",
                "X",
                "Y",
                "Z",
                "SH/L",
            )
        },
        "sample": {
            key: sample[key][0]
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "phases": phases,
        "mass_fractions": {
            key: [value, sigma]
            for key, (value, sigma) in histogram.ComputeMassFracs().items()
        },
        "covariance": covariance_summary(project),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("tag")
    parser.add_argument(
        "--mode",
        required=True,
        choices=("replay", "neutralize", "asymmetry", "polarization", "roughness", "texture", "size", "strain", "atomxyz", "scheelite_oxygen"),
    )
    parser.add_argument("--phase")
    parser.add_argument("--axis", type=int, nargs=3)
    parser.add_argument("--atom")
    args = parser.parse_args()

    out_dir = Path(".tmp/branches")
    out_dir.mkdir(parents=True, exist_ok=True)
    out_gpx = out_dir / f"{args.tag}.gpx"
    project = G2sc.G2Project(args.base, newgpx=str(out_gpx))
    project.set_Controls("cycles", 12)
    histogram = project.histogram(0)
    project.index_ids()

    if args.mode == "neutralize":
        project.set_Frozen()
        for phase in project.phases():
            hap = phase.data["Histograms"][histogram.name]
            hap["Size"][0] = "isotropic"
            hap["Size"][1][:] = [10000.0, 10000.0, 1.0]
            hap["Size"][2][:] = [False, False, False]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
            hap["Mustrain"][2][:] = [False, False, False]
    elif args.mode == "asymmetry":
        histogram.set_refinements({"Instrument Parameters": ["SH/L"]})
        project.set_Controls("parmMin", 0.0005, variable=":0:SH/L")
        project.set_Controls("parmMax", 0.2, variable=":0:SH/L")
    elif args.mode == "polarization":
        histogram.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif args.mode == "roughness":
        sample = histogram.data["Sample Parameters"]
        sample["SurfRoughA"][:] = [0.1, True]
        sample["SurfRoughB"][:] = [0.1, True]
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 2.0, variable=":0:SurfRoughB")
    elif args.mode == "texture":
        if not args.phase or not args.axis:
            raise ValueError("texture mode requires --phase and --axis")
        phase = project.phase(args.phase)
        po = phase.data["Histograms"][histogram.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = list(args.axis)
        project.set_Controls("parmMin", 0.2, variable=f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 5.0, variable=f"{phase.id}:0:MD")
    elif args.mode == "size":
        if not args.phase:
            raise ValueError("size mode requires --phase")
        phase = project.phase(args.phase)
        size = phase.data["Histograms"][histogram.name]["Size"]
        size[0] = "isotropic"
        size[1][0] = 1000.0
        size[2][0] = True
        project.set_Controls("parmMin", 10.0, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 10000.0, variable=f"{phase.id}:0:Size;i")
    elif args.mode == "strain":
        if not args.phase:
            raise ValueError("strain mode requires --phase")
        phase = project.phase(args.phase)
        strain = phase.data["Histograms"][histogram.name]["Mustrain"]
        strain[0] = "isotropic"
        strain[1][0] = 300.0
        strain[2][0] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, variable=f"{phase.id}:0:Mustrain;i")
    elif args.mode == "atomxyz":
        if not args.phase or not args.atom:
            raise ValueError("atomxyz mode requires --phase and --atom")
        atom = project.phase(args.phase).atom(args.atom)
        if atom is None:
            raise ValueError(f"atom {args.atom!r} not present in phase {args.phase!r}")
        atom.refinement_flags = "X"
    elif args.mode == "scheelite_oxygen":
        phase = project.phase("SrWO4_scheelite")
        atom = phase.atom("O2")
        if atom is None:
            raise ValueError("O2 not present in the scheelite phase")
        restraints = project.data["Restraints"]["data"]
        restraints.setdefault(
            phase.name,
            {"Bond": {"wtFactor": 1.0, "Range": 1.1, "Bonds": [], "Use": True}},
        )
        phase.clearDistRestraint()
        count = phase.addDistRestraint(["W1"], ["O2"], 1.79, factor=1.25, ESD=0.02)
        if count < 1:
            raise ValueError("failed to construct the scheelite W-O restraint")
        phase.setDistRestraintWeight(100.0)
        atom.refinement_flags = "X"

    project.refine(makeBack=False)
    project.save()
    summary = project_summary(project, args.mode)
    (out_dir / f"{args.tag}.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"tag": args.tag, "wR": summary["residuals"]["wR"], "frozen": summary["covariance"]["frozen"]}))


if __name__ == "__main__":
    main()
