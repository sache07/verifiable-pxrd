#!/usr/bin/env python3
"""Prepare chemically screened candidate CIFs for GSAS-II trials."""

from pathlib import Path

from pymatgen.core import Element, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)
OUT = Path(".tmp/candidates")


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_structure(structure: Structure, filename: str, provenance: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    text = str(CifWriter(structure, symprec=0.01, refine_struct=False))
    header = (
        "# Candidate model prepared for this refinement.\n"
        f"# {provenance}\n"
        "# Coordinates were not fitted or transferred from this diffraction pattern.\n"
    )
    (OUT / filename).write_text(header + text)


scheelite = Structure.from_file(cod_path("2300460"))
scheelite.replace_species({Element("Mo"): Element("W")})
write_structure(
    scheelite,
    "SrWO4_scheelite_from_SrMoO4_2300460.cif",
    "COD 2300460 SrMoO4 parent; chemically justified isovalent Mo6+ -> W6+ substitution.",
)

scheelite_eu = Structure.from_file(cod_path("1561850"))
scheelite_eu.replace_species({Element("Eu"): Element("Sr")})
write_structure(
    scheelite_eu,
    "SrWO4_scheelite_from_EuWO4_1561850.cif",
    "COD 1561850 EuWO4 parent; chemically justified isovalent Eu2+ -> Sr2+ substitution.",
)

scheelite_ca = Structure.from_file(cod_path("7219229"))
scheelite_ca.replace_species({Element("Ca"): Element("Sr")})
scheelite_ca = Structure(
    scheelite.lattice,
    scheelite_ca.species,
    scheelite_ca.frac_coords,
    site_properties=scheelite_ca.site_properties,
)
write_structure(
    scheelite_ca,
    "SrWO4_scheelite_from_CaWO4_7219229.cif",
    "COD 7219229 CaWO4 coordinate parent; isovalent Ca2+ -> Sr2+ substitution and SrMoO4-parent starting cell.",
)

original_1528915 = cod_path("1528915").read_text()
(OUT / "WO3_monoclinic_1528915.cif").write_text(
    "# Direct COD 1528915 model retained in its importable P21/n setting.\n"
    + original_1528915
)

for cod_id, filename in (
    ("2311041", "WO3_monoclinic_2311041.cif"),
    ("2106293", "WO3_triclinic_2106293.cif"),
    ("2107312", "WO3_orthorhombic_2107312.cif"),
    ("9008198", "SrCO3_orthorhombic_9008198.cif"),
    ("1539128", "SrCO3_rhombohedral_1539128.cif"),
):
    structure = Structure.from_file(cod_path(cod_id))
    write_structure(structure, filename, f"Direct copy of occupied structure from COD {cod_id}.")
