#!/usr/bin/env python3
"""Run a controlled three-phase GSAS-II candidate trial.

The phase nuisance schedule is intentionally identical across source-record
comparisons. Atomic coordinates and displacement factors remain fixed.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def neutralize_hap(phase, histogram) -> None:
    """Remove default phase broadening before fitting the common profile."""
    hap = phase.data["Histograms"][histogram.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10000.0, 10000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["HStrain"][0][:] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1][:] = [False for _ in hap["HStrain"][1]]
    hap["Pref.Ori."][2] = False
    hap["Scale"][:] = [0.01, False]


def snapshot(project, label: str) -> dict:
    histogram = project.histogram(0)
    inst = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]
    result = {
        "stage": label,
        "residuals": histogram.residuals,
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample_shift_micrometre": sample["Shift"][0],
        "phases": {},
    }
    for phase in project.phases():
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": phase.HAPvalue("Scale", targethistlist=[histogram]),
        }
    try:
        result["mass_fractions"] = {
            key: [value, sigma]
            for key, (value, sigma) in histogram.ComputeMassFracs().items()
        }
    except Exception as error:
        result["mass_fraction_error"] = repr(error)
    print("SNAPSHOT " + json.dumps(result, sort_keys=True))
    return result


def refine_stage(project, label: str, records: list[dict]) -> None:
    project.refine(makeBack=False)
    records.append(snapshot(project, label))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scheelite", default="SrWO4_scheelite_from_SrMoO4_2300460.cif")
    parser.add_argument("--wo3", default="WO3_monoclinic_2311041.cif")
    parser.add_argument("--carbonate", default="SrCO3_orthorhombic_9008198.cif")
    parser.add_argument("--correction", choices=("zero", "shift"), default="zero")
    parser.add_argument("--tag", required=True)
    args = parser.parse_args()

    trial_dir = Path(".tmp/trials")
    trial_dir.mkdir(parents=True, exist_ok=True)
    project_path = trial_dir / f"{args.tag}.gpx"
    log_path = trial_dir / f"{args.tag}.json"
    candidate_dir = Path(".tmp/candidates")

    project = G2sc.G2Project(newgpx=str(project_path))
    project.set_Controls("cycles", 8)
    histogram = project.add_powder_histogram(
        "inputs/pattern.csv",
        "instrument.instprm",
        fmthint="comma",
    )
    histogram.set_refinements({"Limits": [10.0, 100.0]})
    histogram.data["Sample Parameters"]["Scale"][:] = [1.0, False]
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
                "coeffs": [1050.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            }
        }
    )

    phase_specs = (
        ("SrWO4_scheelite", args.scheelite),
        ("WO3", args.wo3),
        ("SrCO3", args.carbonate),
    )
    phases = []
    for name, filename in phase_specs:
        phase = project.add_phase(
            str(candidate_dir / filename),
            phasename=name,
            histograms=[histogram],
            fmthint="CIF",
        )
        neutralize_hap(phase, histogram)
        phase.set_HAP_refinements({"Scale": True}, [histogram])
        phases.append(phase)

    inst = histogram.data["Instrument Parameters"][0]
    if args.correction == "zero":
        inst["Zero"][:] = [-0.60, -0.60, False]
        histogram.data["Sample Parameters"]["Shift"][:] = [0.0, False]
    else:
        inst["Zero"][:] = [0.0, 0.0, False]
        histogram.data["Sample Parameters"]["Shift"][:] = [1050.0, False]

    project.index_ids()
    for phase in phases:
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
    for variable, lower, upper in (
        (":0:W", 0.0, 500.0),
        (":0:U", 0.0, 500.0),
        (":0:X", 0.0, 100.0),
        (":0:SH/L", 0.0001, 0.2),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)

    records: list[dict] = []
    refine_stage(project, "background_scales", records)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine_stage(project, "cells", records)

    if args.correction == "zero":
        histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    else:
        histogram.set_refinements({"Sample Parameters": ["Shift"]})
    refine_stage(project, args.correction, records)

    histogram.set_refinements({"Instrument Parameters": ["W"]})
    refine_stage(project, "profile_W", records)

    histogram.set_refinements({"Instrument Parameters": ["U", "X"]})
    refine_stage(project, "profile_UWX", records)

    project.save()
    log_path.write_text(json.dumps(records, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
