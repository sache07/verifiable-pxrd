#!/usr/bin/env python3
"""Compare stable GSAS-II profile/microstructure variants."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "final.bak0.gpx"


def summarize(gpx, name):
    hist = gpx.histogram(0)
    cov = gpx.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    result = {
        "name": name,
        "Rwp": rvals.get("Rwp", hist.get_wR()),
        "GOF": rvals.get("GOF"),
        "message": rvals.get("msg", ""),
        "fractions": hist.ComputeMassFracs(),
        "instrument": {
            key: hist.data["Instrument Parameters"][0][key][1]
            for key in ("U", "V", "W", "X", "Y", "Zero")
        },
        "microstructure": {},
    }
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        result["microstructure"][phase.name] = {
            "size": hap["Size"][:3],
            "mustrain": hap["Mustrain"][:3],
        }
    print("\nVARIANT", result)
    return result


def stable_common_profile():
    out = ROOT / "variant_common.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = gpx.histogram(0)

    # The imported sample scale is a redundant multiplier for the three HAP
    # phase scales. Keep it fixed to remove the exact Hessian singularity.
    hist.data["Sample Parameters"]["Scale"][1] = False

    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "X", "Y"):
        inst[key][2] = False
    inst["U"][1], inst["U"][2] = 50.0, True
    inst["V"][1] = 0.0
    inst["W"][1], inst["W"][2] = 10.0, True
    inst["X"][1], inst["X"][2] = 5.0, True
    inst["Y"][1] = 0.0

    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Size"][1][0] = 1.0
        hap["Mustrain"][1][0] = 1000.0

    gpx.data["Controls"]["data"]["max cyc"] = 20
    gpx.save()
    gpx.do_refinements([{}])
    summarize(gpx, "common_UWX")
    return gpx


def make_variant(base, filename, mode):
    out = ROOT / filename
    base.save(str(out))
    gpx = G2sc.G2Project(str(out))
    hist = gpx.histogram(0)
    phase = gpx.phase("ZnWO4_wolframite")
    hap = phase.data["Histograms"][hist.name]

    if "size" in mode:
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.2
        hap["Size"][1][2] = 1.0
        hap["Size"][2][0] = True
    if "strain" in mode:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2][0] = True

    gpx.save()
    gpx.do_refinements([{}])
    summarize(gpx, mode)
    return gpx


def main():
    G2sc.SetPrintLevel("warn")
    common = stable_common_profile()
    make_variant(common, "variant_size.gpx", "size")
    make_variant(common, "variant_strain.gpx", "strain")
    make_variant(common, "variant_size_strain.gpx", "size+strain")


if __name__ == "__main__":
    main()
