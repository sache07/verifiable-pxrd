#!/usr/bin/env python3
"""Build and refine a three-phase GSAS-II model for pattern.csv.

Run with the Python interpreter bundled with the local GSAS-II installation.
The script intentionally keeps atomic coordinates at their literature values;
the powder pattern is used to refine phase scales, cells and profile terms.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
INPUT_CSV = ROOT / "inputs" / "pattern.csv"
XYE = ROOT / "pattern.xye"
INSTRUMENT = ROOT / "instrument.instprm"
PROJECT = ROOT / "final.gpx"

COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_cif(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PHASES = [
    ("ZnWO4_wolframite", "1520641"),
    ("WO3_gamma", "1528915"),
    ("ZnO_wurtzite", "9004178"),
]


def write_powder_input() -> None:
    """Convert the supplied CSV to a GSAS-II-readable xye file."""
    with INPUT_CSV.open(newline="") as src, XYE.open("w") as dst:
        reader = csv.DictReader(src)
        dst.write("# two_theta_deg intensity sigma_Poisson\n")
        for row in reader:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")


def write_instrument_parameters() -> None:
    """Write the known Cu K-alpha doublet and conservative profile defaults."""
    INSTRUMENT.write_text(
        "#GSAS-II instrument parameter file for supplied Cu Ka reflection data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;"
        "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:2.0;V:-2.0;W:16.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )


def print_state(gpx: G2sc.G2Project, label: str) -> None:
    hist = gpx.histogram(0)
    print(f"\n--- {label} ---")
    print("residuals", hist.residuals)
    inst = hist.data["Instrument Parameters"][0]
    print(
        "instrument",
        {key: inst[key][1] for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L")},
    )
    for phase in gpx.phases():
        print(phase.name, phase.get_cell(), "scale", phase.HAPvalue("Scale"))
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass fractions unavailable", repr(exc))


def refine(gpx: G2sc.G2Project, refs: dict, label: str) -> None:
    gpx.do_refinements([refs])
    print_state(gpx, label)


def main() -> None:
    write_powder_input()
    write_instrument_parameters()

    G2sc.SetPrintLevel("all")
    gpx = G2sc.G2Project(newgpx=str(PROJECT), author="OpenAI Codex")
    hist = gpx.add_powder_histogram(
        str(XYE), str(INSTRUMENT), fmthint="Topas xye"
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)

    phases = []
    for name, cod_id in PHASES:
        phase = gpx.add_phase(
            str(cod_cif(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phases.append(phase)

    # A flexible smooth background is warranted by the strong monotonic
    # low-angle falloff. Atomic coordinates and ADPs remain fixed.
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 18,
                "coeffs": [1400.0] + [0.0] * 17,
            }
        }
    )

    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-5
    gpx.save()

    # Stage parameters to avoid strong initial correlations.
    refine(
        gpx,
        {"set": {"Background": True, "PhaseFraction": True}},
        "background and phase scales",
    )
    refine(gpx, {"set": {"Cell": True}}, "unit cells")
    refine(
        gpx,
        {"set": {"Instrument Parameters": ["Zero"]}},
        "zero offset",
    )
    refine(
        gpx,
        {"set": {"Instrument Parameters": ["U", "V", "W", "X", "Y"]}},
        "common instrumental profile",
    )

    # Allow each phase an isotropic crystallite-size broadening term. This
    # captures visibly different widths without overparameterizing anisotropy.
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "refine": True,
                    "value": 1.0,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            },
            [hist],
        )
    refine(gpx, {}, "isotropic phase-size terms")

    gpx.save(str(PROJECT))
    print_state(gpx, "final")


if __name__ == "__main__":
    main()
