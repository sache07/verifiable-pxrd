#!/usr/bin/env python3
"""Create the requested deliverables from the selected stable refinement."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE_PROJECT = ROOT / "variant_size.gpx"
FINAL_PROJECT = ROOT / "final.gpx"

PHASE_METADATA = {
    "ZnWO4_wolframite": {
        "display_name": "zinc tungstate (wolframite)",
        "formula": "ZnWO4",
        "cif_path": "ZnWO4_wolframite.cif",
        "reference": "COD 1520641",
    },
    "WO3_gamma": {
        "display_name": "gamma tungsten trioxide",
        "formula": "WO3",
        "cif_path": "WO3_gamma.cif",
        "reference": "COD 1528915",
    },
    "ZnO_wurtzite": {
        "display_name": "zinc oxide (wurtzite)",
        "formula": "ZnO",
        "cif_path": "ZnO_wurtzite.cif",
        "reference": "COD 9004178",
    },
}


def plain(value):
    """Convert NumPy scalar/container values into JSON-native values."""
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    return value


def main() -> None:
    G2sc.SetPrintLevel("warn")
    selected = G2sc.G2Project(str(SOURCE_PROJECT), newgpx=str(FINAL_PROJECT))
    selected.save()

    # Reopen under the submitted filename and include every supplied point.
    gpx = G2sc.G2Project(str(FINAL_PROJECT))
    hist = gpx.histogram(0)
    x_all = np.asarray(hist.getdata("X"))
    hist.Limits("lower", float(x_all[0]))
    hist.Limits("upper", float(x_all[-1]))
    gpx.data["Controls"]["data"]["max cyc"] = 30
    # A limit change perturbs the orthogonal-polynomial background mapping.
    # Repeat until the full-range model has genuinely settled.
    for _ in range(5):
        gpx.do_refinements([{}])
        max_shift = gpx.data["Covariance"]["data"]["Rvals"].get(
            "Max shft/sig", float("inf")
        )
        if abs(max_shift) < 0.1:
            break
    gpx.save()

    # Export one phase-only CIF from the final refined project.
    for phase in gpx.phases():
        meta = PHASE_METADATA[phase.name]
        phase.export_CIF(str(ROOT / meta["cif_path"]))

    x = np.asarray(hist.getdata("X"), dtype=float)
    y_obs = np.asarray(hist.getdata("Yobs"), dtype=float)
    y_calc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)
    difference = np.asarray(hist.getdata("Residual"), dtype=float)

    with (ROOT / "fit.csv").open("w", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_observed_minus_calculated",
                "calculated_background",
            ]
        )
        writer.writerows(zip(x, y_obs, y_calc, difference, background))

    fractions = hist.ComputeMassFracs()
    residuals = hist.residuals
    covariance = gpx.data["Covariance"]["data"]
    rvals = covariance["Rvals"]

    phase_results = []
    for phase in gpx.phases():
        meta = PHASE_METADATA[phase.name]
        frac, frac_esd = fractions[phase.name]
        pid = phase.id
        hid = hist.id
        prefix = f"{pid}:{hid}:"
        hap = phase.data["Histograms"][hist.name]
        cell, cell_esd = phase.get_cell_and_esd()
        phase_results.append(
            {
                "name": meta["display_name"],
                "phase_id": phase.name,
                "formula": meta["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": meta["cif_path"],
                "starting_structure_reference": meta["reference"],
                "weight_fraction": float(frac),
                "weight_percent": float(100.0 * frac),
                "weight_fraction_formal_esd": float(frac_esd),
                "cell": plain(cell),
                "cell_formal_esd": plain(cell_esd),
                "profile_R_F_percent": plain(residuals.get(prefix + "Rf")),
                "profile_R_F_squared_percent": plain(residuals.get(prefix + "Rf^2")),
                "isotropic_crystallite_size_micrometre": (
                    float(hap["Size"][1][0])
                    if hap["Size"][2][0]
                    else None
                ),
            }
        )

    result = {
        "phases": phase_results,
        "weight_fraction_basis": "normalized over all modeled crystalline phases",
        "fit_statistics": {
            "R_wp_percent": float(rvals["Rwp"]),
            "R_p_percent": float(residuals["R"]),
            "R_exp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "reduced_chi_square": float(rvals["GOF"] ** 2),
            "weighted_residual_sum_squares": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
            "two_theta_range_deg": [float(x[0]), float(x[-1])],
        },
        "measurement_model": {
            "radiation": "Cu K-alpha doublet",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "intensity_weights": "Poisson, w = 1 / observed intensity",
            "software": "GSAS-II",
            "project_path": "final.gpx",
            "profile_path": "fit.csv",
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
