#!/usr/bin/env python3
"""Run one reversible GSAS-II model challenge from a saved checkpoint."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<RUN>/resources/b001-c05/cif")


def cif_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize(phase: G2sc.G2Phase, histogram: G2sc.G2PwdrData) -> None:
    hap = phase.data["Histograms"][histogram.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [1000.0, 1000.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [1.0, 1.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}


def replay(project: G2sc.G2Project, count: int = 4) -> G2sc.G2Project:
    project.set_Controls("cycles", 16)
    for _ in range(count):
        project.save()
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(project.filename)
        shift = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("Max shft/sig")
        if shift is not None and abs(float(shift)) < 0.05:
            break
    return project


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("challenge")
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    histogram = project.histogram(0)
    challenge = args.challenge

    if challenge == "polarization":
        inst = histogram.data["Instrument Parameters"][0]
        inst["Polariz."][2] = True
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif challenge == "commonU":
        inst = histogram.data["Instrument Parameters"][0]
        inst["U"][0] = inst["U"][1] = 100.0
        inst["U"][2] = True
        project.set_Controls("parmMin", 0.0, variable=":0:U")
    elif challenge == "commonW":
        inst = histogram.data["Instrument Parameters"][0]
        inst["W"][0] = inst["W"][1] = 10.0
        inst["W"][2] = True
        project.set_Controls("parmMin", 0.0, variable=":0:W")
    elif challenge == "commonUWX":
        inst = histogram.data["Instrument Parameters"][0]
        inst["U"][0] = inst["U"][1] = 100.0
        inst["W"][0] = inst["W"][1] = 10.0
        inst["U"][2] = inst["W"][2] = inst["X"][2] = True
        project.set_Controls("parmMin", 0.0, variable=":0:U")
        project.set_Controls("parmMin", 0.0, variable=":0:W")
    elif challenge == "shl":
        inst = histogram.data["Instrument Parameters"][0]
        inst["SH/L"][0] = inst["SH/L"][1] = 0.01
        inst["SH/L"][2] = True
        project.set_Controls("parmMin", 0.002, variable=":0:SH/L")
    elif challenge == "roughness":
        sample = histogram.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.5, True]
        sample["SurfRoughB"] = [0.02, True]
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    elif challenge == "roughB":
        sample = histogram.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.05, True]
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    elif challenge == "roughBonly":
        inst = histogram.data["Instrument Parameters"][0]
        inst["Polariz."][0] = inst["Polariz."][1] = 0.5
        inst["Polariz."][2] = False
        sample = histogram.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.1, True]
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    elif challenge == "nopolar":
        inst = histogram.data["Instrument Parameters"][0]
        inst["Polariz."][0] = inst["Polariz."][1] = 0.5
        inst["Polariz."][2] = False
    elif challenge == "shift":
        inst = histogram.data["Instrument Parameters"][0]
        inst["Zero"][0] = inst["Zero"][1] = 0.0
        inst["Zero"][2] = False
        sample = histogram.data["Sample Parameters"]
        sample["Shift"] = [500.0, True]
    elif challenge.startswith("texture-"):
        _, phase_index, axis_text = challenge.split("-", 2)
        axis = [int(v) for v in axis_text]
        phase = project.phase(int(phase_index))
        pref = phase.data["Histograms"][histogram.name]["Pref.Ori."]
        pref[0:4] = ["MD", 1.0, True, axis]
    elif challenge.startswith("notexture-"):
        phase_index = int(challenge.split("-", 1)[1])
        phase = project.phase(phase_index)
        pref = phase.data["Histograms"][histogram.name]["Pref.Ori."]
        pref[0:4] = ["MD", 1.0, False, [0, 0, 1]]
    elif challenge.startswith("size-"):
        phase_index = int(challenge.split("-", 1)[1])
        phase = project.phase(phase_index)
        size = phase.data["Histograms"][histogram.name]["Size"]
        size[0] = "isotropic"
        size[1] = [0.2, 0.2, 1.0]
        size[2] = [True, False, False]
        project.set_Controls("parmMin", 0.01, variable=f"{phase_index}:0:Size;i")
    elif challenge.startswith("strain-"):
        phase_index = int(challenge.split("-", 1)[1])
        phase = project.phase(phase_index)
        strain = phase.data["Histograms"][histogram.name]["Mustrain"]
        strain[0] = "isotropic"
        strain[1] = [500.0, 500.0, 1.0]
        strain[2] = [True, False, False]
        project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;i")
    elif challenge.startswith("sizestrain-"):
        phase_index = int(challenge.split("-", 1)[1])
        phase = project.phase(phase_index)
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [0.2, 0.2, 1.0]
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [500.0, 500.0, 1.0]
        hap["Mustrain"][2] = [True, False, False]
        project.set_Controls("parmMin", 0.01, variable=f"{phase_index}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;i")
    elif challenge.startswith("usize-"):
        _, phase_text, axis_text = challenge.split("-", 2)
        phase_index = int(phase_text)
        axis = [int(v) for v in axis_text]
        phase = project.phase(phase_index)
        size = phase.data["Histograms"][histogram.name]["Size"]
        start = float(size[1][0])
        size[0] = "uniaxial"
        size[1] = [start, start, 1.0]
        size[2] = [True, True, False]
        size[3] = axis
        project.set_Controls("parmMin", 0.01, variable=f"{phase_index}:0:Size;i")
        project.set_Controls("parmMin", 0.01, variable=f"{phase_index}:0:Size;a")
    elif challenge.startswith("ustrain-"):
        _, phase_text, axis_text = challenge.split("-", 2)
        phase_index = int(phase_text)
        axis = [int(v) for v in axis_text]
        phase = project.phase(phase_index)
        strain = phase.data["Histograms"][histogram.name]["Mustrain"]
        start = float(strain[1][0])
        strain[0] = "uniaxial"
        strain[1] = [start, start, 1.0]
        strain[2] = [True, True, False]
        strain[3] = axis
        project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;i")
        project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;a")
    elif challenge.startswith("addfixed-"):
        _, cod_id, phase_name = challenge.split("-", 2)
        phase = project.add_phase(
            str(cif_path(cod_id)), phasename=phase_name, histograms=[histogram]
        )
        neutralize(phase, histogram)
        phase.data["Histograms"][histogram.name]["Scale"] = [0.1, True]
    elif challenge.startswith("analoguefixed-"):
        analogue_key = challenge.split("-", 1)[1]
        choices = {
            "ca3os": ("analogues/Ca3WO6_from_Ca3OsO6_1562666.cif", "Ca3WO6_Os_parent"),
            "ca3u": ("analogues/Ca3WO6_from_Ca3UO6_2310470.cif", "Ca3WO6_U_parent"),
            "ca2re": ("analogues/Ca2WO5_from_Ba2ReO5_1529756_scaled094.cif", "Ca2WO5_Re_parent"),
        }
        phase_file, phase_name = choices[analogue_key]
        phase = project.add_phase(phase_file, phasename=phase_name, histograms=[histogram])
        neutralize(phase, histogram)
        phase.data["Histograms"][histogram.name]["Scale"] = [0.1, True]
    elif challenge.startswith("analogue-"):
        analogue_key = challenge.split("-", 1)[1]
        choices = {
            "ca3os": ("analogues/Ca3WO6_from_Ca3OsO6_1562666.cif", "Ca3WO6_Os_parent"),
            "ca3u": ("analogues/Ca3WO6_from_Ca3UO6_2310470.cif", "Ca3WO6_U_parent"),
            "ca2re": ("analogues/Ca2WO5_from_Ba2ReO5_1529756_scaled094.cif", "Ca2WO5_Re_parent"),
        }
        phase_file, phase_name = choices[analogue_key]
        phase = project.add_phase(phase_file, phasename=phase_name, histograms=[histogram])
        neutralize(phase, histogram)
        phase.data["Histograms"][histogram.name]["Scale"] = [0.1, True]
        project = replay(project, 3)
        phase = project.phase(phase_name)
        scale = phase.data["Histograms"][project.histogram(0).name]["Scale"][0]
        if math.isfinite(scale) and scale > 0.0:
            phase.set_refinements({"Cell": True})
    elif challenge.startswith("add-"):
        _, cod_id, phase_name = challenge.split("-", 2)
        phase = project.add_phase(
            str(cif_path(cod_id)), phasename=phase_name, histograms=[histogram]
        )
        neutralize(phase, histogram)
        phase.data["Histograms"][histogram.name]["Scale"] = [0.1, True]
        # Scale first. Only if scale survives is the candidate cell released.
        project = replay(project, 2)
        phase = project.phase(phase_name)
        scale = phase.data["Histograms"][project.histogram(0).name]["Scale"][0]
        if math.isfinite(scale) and scale > 0.0:
            phase.set_refinements({"Cell": True})
    else:
        raise ValueError(f"unknown challenge {challenge}")

    project = replay(project)
    histogram = project.histogram(0)
    inst = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]
    result = {
        "challenge": challenge,
        "Rwp": histogram.residuals.get("wR"),
        "Rp": histogram.residuals.get("R"),
        "max_shift_over_sigma": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("Max shft/sig"),
        "frozen": project.get_Frozen(),
        "instrument": {key: value[1:] for key, value in inst.items() if key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")},
        "sample": {key: sample.get(key) for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
        "phases": {
            phase.name: {
                "scale": phase.data["Histograms"][histogram.name]["Scale"],
                "cell": phase.get_cell(),
                "preferred_orientation": phase.data["Histograms"][histogram.name]["Pref.Ori."],
            }
            for phase in project.phases()
        },
    }
    try:
        result["mass_fractions"] = histogram.ComputeMassFracs()
    except Exception as exc:
        result["mass_fraction_error"] = repr(exc)
    print("TRIAL_RESULT " + json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
