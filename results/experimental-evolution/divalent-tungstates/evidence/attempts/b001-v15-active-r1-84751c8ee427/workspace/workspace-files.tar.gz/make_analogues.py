#!/usr/bin/env python3
"""Create explicitly documented Ca-W-O analogue models from indexed parents."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path("<RUN>/resources/b001-c05/cif")
OUT = Path("analogues")


def source(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_substituted(cod_id: str, substitutions: dict[str, str], output: str,
                      lattice_scale: float = 1.0) -> None:
    structure = Structure.from_file(source(cod_id))
    structure.replace_species(substitutions)
    if lattice_scale != 1.0:
        lattice = Lattice(
            matrix=structure.lattice.matrix * lattice_scale,
        )
        structure = Structure(
            lattice,
            structure.species,
            structure.frac_coords,
            site_properties=structure.site_properties,
        )
    CifWriter(structure, symprec=0.01).write_file(OUT / output)


def main() -> None:
    OUT.mkdir(exist_ok=True)
    # Os6+ -> W6+ is isovalent and the octahedral Shannon radii are close;
    # retain the 293 K Ca3OsO6 P21/n cell for the scale-first challenge.
    write_substituted(
        "1562666", {"Os": "W"}, "Ca3WO6_from_Ca3OsO6_1562666.cif"
    )
    # U6+ -> W6+ tests the lower-symmetry Ca3UO6 parent independently.
    write_substituted(
        "2310470", {"U": "W"}, "Ca3WO6_from_Ca3UO6_2310470.cif"
    )
    # Ba2+ -> Ca2+ and Re6+ -> W6+ are isovalent substitutions. A modest
    # uniform 6% contraction gives ordinary W-O/Ca-O contacts while allowing
    # the subsequent scale-first test to decide whether the prototype exists.
    write_substituted(
        "1529756", {"Ba": "Ca", "Re": "W"},
        "Ca2WO5_from_Ba2ReO5_1529756_scaled094.cif", lattice_scale=0.94,
    )


if __name__ == "__main__":
    main()
