#!/usr/bin/env python3
"""Build and refine a two-phase source-record comparison project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<RUN>/resources/b001-c05/cif")


def cif_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize(phase: G2sc.G2Phase, histogram: G2sc.G2PwdrData) -> None:
    hap = phase.data["Histograms"][histogram.name]
    hap["Size"] = [
        "isotropic", [1000.0, 1000.0, 1.0], [False, False, False],
        [0, 0, 1], [1.0, 1.0, 1.0, 0.0, 0.0, 0.0],
        [False, False, False, False, False, False],
    ]
    n_general = len(hap["Mustrain"][4])
    hap["Mustrain"] = [
        "isotropic", [1.0, 1.0, 1.0], [False, False, False],
        [0, 0, 1], [0.01] * n_general, [False] * n_general,
    ]
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}


def replay(project: G2sc.G2Project, maximum: int = 5) -> G2sc.G2Project:
    project.set_Controls("cycles", 16)
    for _ in range(maximum):
        project.save()
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(project.filename)
        shift = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("Max shft/sig")
        if shift is not None and abs(float(shift)) < 0.05:
            break
    return project


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output")
    parser.add_argument("calcium_record")
    parser.add_argument("tungsten_record")
    args = parser.parse_args()

    project = G2sc.G2Project(newgpx=args.output)
    histogram = project.add_powder_histogram("inputs/pattern.csv", "instrument.instprm")
    calcium = project.add_phase(
        str(cif_path(args.calcium_record)),
        phasename=f"CaWO4_{args.calcium_record}", histograms=[histogram],
    )
    tungsten = project.add_phase(
        str(cif_path(args.tungsten_record)),
        phasename=f"WO3_{args.tungsten_record}", histograms=[histogram],
    )
    histogram.data["Sample Parameters"]["Scale"] = [1.0, False]
    inst = histogram.data["Instrument Parameters"][0]
    for key, value in {
        "Zero": -0.197, "U": 0.0, "V": 0.0, "W": 0.0,
        "X": 16.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.002,
    }.items():
        inst[key][0] = inst[key][1] = value
        inst[key][2] = False
    for phase, scale in ((calcium, 50.0), (tungsten, 5.0)):
        neutralize(phase, histogram)
        phase.data["Histograms"][histogram.name]["Scale"] = [scale, True]

    histogram.set_refinements({
        "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 6},
        "Instrument Parameters": ["Zero"],
    })
    project = replay(project, 3)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project = replay(project, 4)
    histogram = project.histogram(0)
    histogram.data["Instrument Parameters"][0]["X"][2] = True
    project.set_Controls("parmMin", 0.0, variable=":0:X")
    project = replay(project, 5)

    histogram = project.histogram(0)
    result = {
        "calcium_record": args.calcium_record,
        "tungsten_record": args.tungsten_record,
        "Rwp": histogram.residuals.get("wR"),
        "Rp": histogram.residuals.get("R"),
        "max_shift_over_sigma": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("Max shft/sig"),
        "frozen": project.get_Frozen(),
        "mass_fractions": histogram.ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "scales": {phase.name: phase.data["Histograms"][histogram.name]["Scale"] for phase in project.phases()},
        "instrument": {key: value[1:] for key, value in histogram.data["Instrument Parameters"][0].items() if key in ("Zero", "U", "V", "W", "X", "Y", "SH/L")},
    }
    print("SOURCE_RESULT " + json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
