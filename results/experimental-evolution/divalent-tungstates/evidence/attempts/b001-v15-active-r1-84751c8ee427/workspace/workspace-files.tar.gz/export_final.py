#!/usr/bin/env python3
"""Export the submitted artifacts from the exact saved final GSAS-II project."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"
PATTERN = ROOT / "inputs" / "pattern.csv"

PHASE_EXPORTS = {
    "CaWO4_7219229": {
        "name": "CaWO4",
        "description": "scheelite CaWO4",
        "formula": "CaWO4",
        "cif_path": "phase_CaWO4.cif",
        "structure_source": "COD 7219229",
    },
    "WO3_2311041": {
        "name": "WO3",
        "description": "room-temperature monoclinic WO3",
        "formula": "WO3",
        "cif_path": "phase_WO3.cif",
        "structure_source": "COD 2311041",
    },
    "Ca3WO6_Os_parent": {
        "name": "Ca3WO6",
        "description": "monoclinic Ca3WO6 prototype model",
        "formula": "Ca3WO6",
        "cif_path": "phase_Ca3WO6.cif",
        "structure_source": "isovalent W-for-Os model derived from Ca3OsO6, COD 1562666",
    },
}


def read_original_pattern() -> tuple[list[str], list[str], np.ndarray, np.ndarray]:
    x_text: list[str] = []
    y_text: list[str] = []
    with PATTERN.open(newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != ["two_theta_deg", "intensity"]:
            raise RuntimeError(f"unexpected pattern columns: {reader.fieldnames}")
        for row in reader:
            x_text.append(row["two_theta_deg"])
            y_text.append(row["intensity"])
    return x_text, y_text, np.asarray(x_text, float), np.asarray(y_text, float)


def main() -> None:
    project = G2sc.G2Project(str(PROJECT))
    if len(project.histograms()) != 1:
        raise RuntimeError("submission exporter requires exactly one histogram")
    histogram = project.histogram(0)
    if set(phase.name for phase in project.phases()) != set(PHASE_EXPORTS):
        raise RuntimeError("final project phase inventory differs from the submitted inventory")

    x, observed, weights, calculated, background, difference = (
        np.asarray(array, dtype=float) for array in histogram.data["data"][1]
    )
    x_text, observed_text, source_x, source_observed = read_original_pattern()
    if not np.array_equal(x, source_x) or not np.array_equal(observed, source_observed):
        raise RuntimeError("final project does not preserve the original observation grid and counts")
    if not np.array_equal(difference, observed - calculated):
        raise RuntimeError("stored GSAS-II difference profile is inconsistent")
    if np.ma.getmaskarray(histogram.data["data"][1][0]).any():
        raise RuntimeError("final profile contains masked observations")

    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
        for x_raw, y_raw, y_calc, y_diff in zip(
            x_text, observed_text, calculated, difference, strict=True
        ):
            writer.writerow([x_raw, y_raw, repr(float(y_calc)), repr(float(y_diff))])

    fractions_raw = histogram.ComputeMassFracs()
    total_fraction = sum(float(value[0]) for value in fractions_raw.values())
    if not np.isfinite(total_fraction) or total_fraction <= 0:
        raise RuntimeError("invalid crystalline phase-fraction sum")

    phases = []
    for phase in project.phases():
        metadata = PHASE_EXPORTS[phase.name]
        phase.export_CIF(str(ROOT / metadata["cif_path"]))
        value, esd = fractions_raw[phase.name]
        phases.append(
            {
                **metadata,
                "project_phase_name": phase.name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": metadata["cif_path"],
                "weight_fraction": float(value) / total_fraction,
                "weight_fraction_esd": float(esd) / total_fraction,
            }
        )

    covariance = project.data["Covariance"]["data"]
    r_values = covariance["Rvals"]
    residuals = histogram.residuals
    result = {
        "refinement_project": "final.gpx",
        "refinement_histogram": histogram.name,
        "phase_fraction_basis": "normalized over the modeled crystalline phases; no amorphous fraction determined",
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(r_values["GOF"]),
            "chi_squared": float(r_values["chisq"]),
            "n_observations": int(r_values["Nobs"]),
            "n_refined_variables": int(r_values["Nvars"]),
            "max_shift_over_sigma": float(r_values["Max shft/sig"]),
            "converged": bool(r_values["converged"]),
        },
        "weighting": "Poisson count weights (1/I); pointwise standard uncertainties were not supplied",
    }
    if abs(sum(item["weight_fraction"] for item in phases) - 1.0) > 1e-12:
        raise RuntimeError("exported weight fractions do not sum to unity")
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    print(
        json.dumps(
            {
                "project": PROJECT.name,
                "histogram": histogram.name,
                "points": len(x),
                "Rwp_percent": residuals["wR"],
                "fractions": {
                    item["name"]: item["weight_fraction"] for item in phases
                },
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
