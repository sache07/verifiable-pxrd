#!/usr/bin/env python3
"""Replay one physically motivated common-profile/intensity correction trial."""

from __future__ import annotations

import argparse
import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "mode", choices=("polarization", "roughness", "pol_rough", "shl")
    )
    parser.add_argument("--replays", type=int, default=3)
    args = parser.parse_args()

    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
        histogram = project.histogram(0)
        instrument = histogram.data["Instrument Parameters"][0]
        sample = histogram.data["Sample Parameters"]

        instrument["Polariz."][1:] = [0.5, False]
        instrument["SH/L"][1:] = [0.002, False]
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.0, False]

        if args.mode in ("polarization", "pol_rough"):
            instrument["Polariz."][2] = True
        if args.mode in ("roughness", "pol_rough"):
            sample["SurfRoughB"] = [0.01, True]
        if args.mode == "shl":
            instrument["SH/L"][1:] = [0.02, True]

        project.set_Controls("cycles", 16)
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
        project.save()
        for _ in range(args.replays):
            project.refine(makeBack=False)
            project.save()
            project = G2sc.G2Project(str(args.output))

    histogram = project.histogram(0)
    covariance = project.data.get("Covariance", {}).get("data", {})
    summary = {
        "mode": args.mode,
        "Rwp": histogram.residuals.get("wR"),
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "max_shift_over_esd": covariance.get("Rvals", {}).get("Max shft/sig"),
        "polarization": histogram.data["Instrument Parameters"][0]["Polariz."][1],
        "roughness_A": histogram.data["Sample Parameters"]["SurfRoughA"][0],
        "roughness_B": histogram.data["Sample Parameters"]["SurfRoughB"][0],
        "SH_over_L": histogram.data["Instrument Parameters"][0]["SH/L"][1],
        "fractions": {
            key: value[0] for key, value in histogram.ComputeMassFracs().items()
        },
        "frozen": list(map(str, project.get_Frozen() or [])),
        "output": str(args.output),
    }
    with contextlib.redirect_stdout(captured):
        project.save()
    print("NUISANCE_RESULT " + json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
