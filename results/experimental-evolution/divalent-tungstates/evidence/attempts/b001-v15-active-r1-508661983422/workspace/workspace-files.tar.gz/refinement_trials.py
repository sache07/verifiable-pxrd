#!/usr/bin/env python3
"""Replay one GSAS-II phase-broadening trial from a common checkpoint."""

from __future__ import annotations

import argparse
import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def neutralize(hap: dict) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][1][2] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][2] = 1.0
    hap["Mustrain"][2] = [False, False, False]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("mode", choices=("neutral", "size", "strain", "combined"))
    parser.add_argument("--replays", type=int, default=3)
    parser.add_argument("--preserve-existing", action="store_true")
    args = parser.parse_args()

    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
        histogram = project.histogram(0)
        if not args.preserve_existing:
            for phase in project.phases():
                neutralize(phase.data["Histograms"][histogram.name])

        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][histogram.name]
        neutralize(hap)
        if args.mode in ("size", "combined"):
            hap["Size"][1][0] = 1.0
            hap["Size"][2][0] = True
        if args.mode in ("strain", "combined"):
            hap["Mustrain"][1][0] = 500.0
            hap["Mustrain"][2][0] = True

        project.set_Controls("cycles", 16)
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
        project.save()
        for _ in range(args.replays):
            project.refine(makeBack=False)
            project.save()
            project = G2sc.G2Project(str(args.output))

    histogram = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][histogram.name]
    covariance = project.data.get("Covariance", {}).get("data", {})
    summary = {
        "phase": args.phase,
        "mode": args.mode,
        "Rwp": histogram.residuals.get("wR"),
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "max_shift_over_esd": covariance.get("Rvals", {}).get("Max shft/sig"),
        "common_X": histogram.data["Instrument Parameters"][0]["X"][1],
        "size_micrometre": hap["Size"][1][0],
        "size_refined": hap["Size"][2][0],
        "microstrain": hap["Mustrain"][1][0],
        "microstrain_refined": hap["Mustrain"][2][0],
        "fractions": {
            key: value[0] for key, value in histogram.ComputeMassFracs().items()
        },
        "frozen": list(map(str, project.get_Frozen() or [])),
        "output": str(args.output),
    }
    with contextlib.redirect_stdout(captured):
        project.save()
    print("TRIAL_RESULT " + json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
