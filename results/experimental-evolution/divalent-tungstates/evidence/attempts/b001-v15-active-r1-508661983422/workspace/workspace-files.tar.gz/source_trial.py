#!/usr/bin/env python3
"""Challenge a phase record (or omission) under a saved GSAS-II profile."""

from __future__ import annotations

import argparse
import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def neutralize(hap: dict) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][1][2] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][2] = 1.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("cif", nargs="?", type=Path)
    parser.add_argument("--omit", action="store_true")
    parser.add_argument("--mode", choices=("neutral", "size", "strain"), default="neutral")
    parser.add_argument("--value", type=float)
    parser.add_argument("--replays", type=int, default=4)
    args = parser.parse_args()
    if not args.omit and args.cif is None:
        parser.error("cif is required unless --omit is selected")

    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
        histogram = project.histogram(0)
        old_phase = project.phase(args.phase)
        old_hap = old_phase.data["Histograms"][histogram.name]
        old_scale = old_hap["Scale"][0]
        old_hap["Use"] = False
        old_hap["Scale"] = [0.0, False]

        alternate_name = None
        if not args.omit:
            alternate_name = args.phase + "_alternate"
            alternate = project.add_phase(
                str(args.cif),
                phasename=alternate_name,
                histograms=[histogram],
                fmthint="CIF",
            )
            alternate.set_refinements({"Cell": False})
            hap = alternate.data["Histograms"][histogram.name]
            neutralize(hap)
            hap["Scale"] = [old_scale, True]
            hap["Use"] = True
            if args.mode == "size":
                hap["Size"][1][0] = args.value if args.value is not None else 0.1
                hap["Size"][2][0] = True
            elif args.mode == "strain":
                hap["Mustrain"][1][0] = (
                    args.value if args.value is not None else 5000.0
                )
                hap["Mustrain"][2][0] = True

        project.set_Controls("cycles", 16)
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
        project.save()
        fixed_cell_replays = min(2, args.replays) if alternate_name else args.replays
        for _ in range(fixed_cell_replays):
            project.refine(makeBack=False)
            project.save()
            project = G2sc.G2Project(str(args.output))
        if alternate_name and args.replays > fixed_cell_replays:
            project.phase(alternate_name).set_refinements({"Cell": True})
            project.save()
            for _ in range(args.replays - fixed_cell_replays):
                project.refine(makeBack=False)
                project.save()
                project = G2sc.G2Project(str(args.output))

    histogram = project.histogram(0)
    covariance = project.data.get("Covariance", {}).get("data", {})
    fractions = histogram.ComputeMassFracs()
    summary = {
        "replaced_phase": args.phase,
        "alternate_phase": alternate_name,
        "omitted": args.omit,
        "Rwp": histogram.residuals.get("wR"),
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "max_shift_over_esd": covariance.get("Rvals", {}).get("Max shft/sig"),
        "fractions": {key: value[0] for key, value in fractions.items()},
        "frozen": list(map(str, project.get_Frozen() or [])),
        "output": str(args.output),
    }
    if alternate_name is not None:
        alternate = project.phase(alternate_name)
        hap = alternate.data["Histograms"][histogram.name]
        summary.update(
            {
                "cell": alternate.get_cell(),
                "scale": hap["Scale"][0],
                "size_micrometre": hap["Size"][1][0],
                "microstrain": hap["Mustrain"][1][0],
            }
        )
    with contextlib.redirect_stdout(captured):
        project.save()
    print("SOURCE_RESULT " + json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
