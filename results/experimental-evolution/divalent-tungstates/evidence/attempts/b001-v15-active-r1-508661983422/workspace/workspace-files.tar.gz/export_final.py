#!/usr/bin/env python3
"""Export all requested deliverables from the exact final GSAS-II project."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


PHASE_METADATA = {
    "PbWO4_scheelite": {
        "display_name": "PbWO4 (scheelite)",
        "formula": "PbWO4",
        "cif_path": "PbWO4_scheelite.cif",
    },
    "WO3_monoclinic": {
        "display_name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif_path": "WO3_monoclinic.cif",
    },
    "Pb3O4_tetragonal": {
        "display_name": "Pb3O4 (tetragonal minium)",
        "formula": "Pb3O4",
        "cif_path": "Pb3O4_tetragonal.cif",
    },
    "PbO_massicot": {
        "display_name": "PbO (orthorhombic massicot)",
        "formula": "PbO",
        "cif_path": "PbO_massicot.cif",
    },
}


def main() -> None:
    root = Path(__file__).resolve().parent
    project_path = root / "final.gpx"
    project = G2sc.G2Project(str(project_path))
    histograms = project.histograms()
    if len(histograms) != 1:
        raise RuntimeError(f"expected one final histogram, found {len(histograms)}")
    histogram = histograms[0]

    x = histogram.getdata("x")
    observed = histogram.getdata("yobs")
    calculated = histogram.getdata("ycalc")
    background = histogram.getdata("background")
    weights = histogram.getdata("yweight")
    with (root / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity_counts",
                "calculated_intensity_counts",
                "difference_observed_minus_calculated_counts",
                "calculated_background_counts",
                "weight",
            ]
        )
        for values in zip(x, observed, calculated, background, weights):
            angle, obs, calc, back, weight = map(float, values)
            writer.writerow([angle, obs, calc, obs - calc, back, weight])

    fractions = histogram.ComputeMassFracs()
    phase_rows = []
    for phase in project.phases():
        metadata = PHASE_METADATA[phase.name]
        cif_path = root / metadata["cif_path"]
        phase.export_CIF(str(cif_path))
        cell, cell_esd = phase.get_cell_and_esd()
        fraction, fraction_esd = fractions[phase.name]
        phase_rows.append(
            {
                "name": metadata["display_name"],
                "project_phase_name": phase.name,
                "formula": metadata["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": metadata["cif_path"],
                "weight_fraction": float(fraction),
                "weight_fraction_esd": float(fraction_esd),
                "weight_percent": 100.0 * float(fraction),
                "cell": {key: float(value) for key, value in cell.items()},
                "cell_esd": {key: float(value) for key, value in cell_esd.items()},
            }
        )

    residuals = histogram.residuals
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    result = {
        "final_project": "final.gpx",
        "refinement_histogram": histogram.name,
        "modeled_crystalline_fraction_sum": sum(
            row["weight_fraction"] for row in phase_rows
        ),
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "RBragg_percent": float(residuals["Rb"]),
            "weighted_RBragg_percent": float(residuals["wRb"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "number_of_observations": int(rvals["Nobs"]),
            "number_of_refined_variables": int(rvals["Nvars"]),
            "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
        },
        "measurement_grid": {
            "points": len(x),
            "two_theta_min_deg": float(x[0]),
            "two_theta_max_deg": float(x[-1]),
            "resampled": False,
        },
        "weighting": "Poisson weights 1/I assigned by GSAS-II because pointwise standard uncertainties were not supplied.",
    }
    with (root / "result.json").open("w") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")


if __name__ == "__main__":
    main()
