#!/usr/bin/env python3
"""Replay a one-axis March-Dollase texture challenge."""

from __future__ import annotations

import argparse
import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("axis", nargs=3, type=int)
    parser.add_argument("--replays", type=int, default=3)
    args = parser.parse_args()

    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
        histogram = project.histogram(0)
        for phase in project.phases():
            pref = phase.data["Histograms"][histogram.name]["Pref.Ori."]
            pref[0] = "MD"
            pref[1] = 1.0
            pref[2] = False
        phase = project.phase(args.phase)
        pref = phase.data["Histograms"][histogram.name]["Pref.Ori."]
        pref[1] = 1.0
        pref[2] = True
        pref[3] = list(args.axis)

        project.set_Controls("cycles", 16)
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
        project.save()
        for _ in range(args.replays):
            project.refine(makeBack=False)
            project.save()
            project = G2sc.G2Project(str(args.output))

    histogram = project.histogram(0)
    phase = project.phase(args.phase)
    pref = phase.data["Histograms"][histogram.name]["Pref.Ori."]
    covariance = project.data.get("Covariance", {}).get("data", {})
    summary = {
        "phase": args.phase,
        "axis": args.axis,
        "MD_ratio": pref[1],
        "Rwp": histogram.residuals.get("wR"),
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "max_shift_over_esd": covariance.get("Rvals", {}).get("Max shft/sig"),
        "fractions": {
            key: value[0] for key, value in histogram.ComputeMassFracs().items()
        },
        "frozen": list(map(str, project.get_Frozen() or [])),
        "output": str(args.output),
    }
    with contextlib.redirect_stdout(captured):
        project.save()
    print("TEXTURE_RESULT " + json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
