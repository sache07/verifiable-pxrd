#!/usr/bin/env python3
"""Replay source-record challenges from one neutral profile checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


HERE = Path(__file__).resolve().parent
ROOT = Path(
    "<RUN>/"
    "resources/b001-c05/cif"
)
OUT = HERE / "source_screen"

COMMON_BACKGROUND = [
    1399.050199227885,
    -734.8260250961225,
    480.04741937513893,
    -390.946820914924,
    212.20296341411654,
    -105.90809061194443,
]
COMMON_CA_CELL = [5.2432526, 5.2432526, 11.3758902, 90.0, 90.0, 90.0]
COMMON_INST = {
    "Zero": -0.1976700,
    "U": 36.7887,
    "V": 0.0,
    "W": 25.8664,
    "X": 11.9861,
    "Y": 0.0,
    "Z": 0.0,
    "SH/L": 0.002,
    "Polariz.": 0.7,
}


def cif_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def set_cell(phase, cell: list[float]) -> None:
    phase.data["General"]["Cell"][1:7] = cell
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def neutral_hap(phase, hist_name: str, scale: float) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"] = [scale, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][:3] = ["MD", 1.0, False]


def snapshot(project, hist, stage: str) -> dict:
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    phases = []
    for phase in project.phases():
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
                "mass": phase.data["General"]["Mass"],
            }
        )
    try:
        mass_fractions = {
            key: {"value": value[0], "esd": value[1]}
            for key, value in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        mass_fractions = {"error": str(exc)}
    inst = hist.data["Instrument Parameters"][0]
    return {
        "stage": stage,
        "Rwp": rvals.get("Rwp", hist.get_wR()),
        "GOF": rvals.get("GOF"),
        "chi2": rvals.get("chisq"),
        "Nvars": rvals.get("Nvars"),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "instrument": {key: inst[key][1] for key in COMMON_INST},
        "phases": phases,
        "mass_fractions": mass_fractions,
    }


def refine_replays(project, count: int) -> None:
    for _ in range(count):
        project.do_refinements([{}])


def challenge(ca_id: str, wo_id: str, tag: str) -> dict:
    path = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(newgpx=str(path))
    hist = project.add_powder_histogram(
        str(HERE / "inputs" / "pattern.csv"), str(HERE / "instrument.instprm")
    )
    ca = project.add_phase(
        str(cif_path(ca_id)), f"CaWO4_{ca_id}", [hist], fmthint="CIF"
    )
    wo = project.add_phase(
        str(cif_path(wo_id)), f"WO3_{wo_id}", [hist], fmthint="CIF"
    )
    project.set_Controls("cycles", 12)

    if ca_id == "7219229":
        set_cell(ca, COMMON_CA_CELL)

    # Cross-seed every record with the same scale products and all shared nuisances.
    ca_scale = 44.4 * 1151.67 / ca.data["General"]["Mass"]
    wo_scale = 4.40 * 1854.72 / wo.data["General"]["Mass"]
    neutral_hap(ca, hist.name, ca_scale)
    neutral_hap(wo, hist.name, wo_scale)

    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for key, value in COMMON_INST.items():
        inst[key][0] = value
        inst[key][1] = value
        inst[key][2] = False
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(COMMON_BACKGROUND),
                "coeffs": COMMON_BACKGROUND,
                "refine": True,
            }
        }
    )
    ca.data["General"]["Cell"][0] = False
    wo.data["General"]["Cell"][0] = False
    project.save()
    for variable in ["0:0:Scale", "1:0:Scale", ":0:U", ":0:W", ":0:X"]:
        project.set_Controls("parmMin", 0.0, variable)
    refine_replays(project, 2)
    fixed = snapshot(project, hist, "fixed_source_cells_common_profile")

    ca.data["General"]["Cell"][0] = True
    wo.data["General"]["Cell"][0] = True
    for key in ["Zero", "U", "W", "X"]:
        inst[key][2] = True
    refine_replays(project, 4)
    elaborated = snapshot(project, hist, "refined_cells_profile")
    project.save()
    return {
        "tag": tag,
        "ca_source": ca_id,
        "wo3_source": wo_id,
        "project": str(path.relative_to(HERE)),
        "fixed": fixed,
        "elaborated": elaborated,
    }


def main() -> None:
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("none")
    cases = [
        ("7219229", "2311041", "wo3_2311041_monoclinic"),
        ("7219229", "1528915", "wo3_1528915_monoclinic"),
        ("7219229", "2106293", "wo3_2106293_triclinic"),
        ("7219229", "2107312", "wo3_2107312_orthorhombic"),
        ("7219229", "1563541", "wo3_1563541_monoclinic"),
        ("7219229", "1521532", "wo3_1521532_tetragonal"),
        ("7219229", "1521533", "wo3_1521533_tetragonal"),
        ("7219229", "1004057", "wo3_1004057_hexagonal"),
        ("1546035", "2311041", "cawo4_1546035_monoclinic"),
    ]
    results = []
    for ca_id, wo_id, tag in cases:
        print(f"screening {tag}", flush=True)
        try:
            results.append(challenge(ca_id, wo_id, tag))
        except Exception as exc:
            results.append(
                {
                    "tag": tag,
                    "ca_source": ca_id,
                    "wo3_source": wo_id,
                    "error": repr(exc),
                }
            )
    with (OUT / "summary.json").open("w") as stream:
        json.dump(results, stream, indent=2)
    for row in results:
        if "error" in row:
            print(row["tag"], "ERROR", row["error"])
            continue
        print(
            row["tag"],
            f"fixed={row['fixed']['Rwp']:.4f}",
            f"elaborated={row['elaborated']['Rwp']:.4f}",
            row["elaborated"]["mass_fractions"],
        )


if __name__ == "__main__":
    main()
