#!/usr/bin/env python3
"""Compare smooth background, polarization, and roughness from one checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
BASE = HERE / "model_stage_profile.gpx"
OUT = HERE / "global_trials"


def configure(project, tag: str) -> list[tuple[str, float, float]]:
    hist = project.histogram(0)
    bounds: list[tuple[str, float, float]] = []
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    inst["Polariz."][2] = False
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    if tag.startswith("background_"):
        order = int(tag.split("_")[1])
        old = list(hist.data["Background"][0][3:])
        coeffs = (old + [0.0] * order)[:order]
        hist.set_refinements(
            {
                "Background": {
                    "type": "chebyschev-1",
                    "no. coeffs": order,
                    "coeffs": coeffs,
                    "refine": True,
                }
            }
        )
    elif tag == "polarization_0p5":
        inst["Polariz."][0] = inst["Polariz."][1] = 0.5
    elif tag == "polarization_0p9":
        inst["Polariz."][0] = inst["Polariz."][1] = 0.9
    elif tag == "polarization_refine":
        inst["Polariz."][1] = 0.7
        inst["Polariz."][2] = True
        bounds.append((":0:Polariz.", 0.0, 1.0))
    elif tag == "roughness_refine":
        sample["SurfRoughA"] = [0.5, True]
        sample["SurfRoughB"] = [0.01, True]
        bounds.extend(
            [
                (":0:SurfRoughA", 0.0, 1.0),
                (":0:SurfRoughB", 0.0, 1.0),
            ]
        )
    return bounds


def snapshot(project, tag: str) -> dict:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    return {
        "tag": tag,
        "Rwp": rvals.get("Rwp", hist.get_wR()),
        "GOF": rvals.get("GOF"),
        "chi2": rvals.get("chisq"),
        "Nvars": rvals.get("Nvars"),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "frozen": project.get_Frozen(),
        "background": hist.data["Background"][0],
        "polarization": inst["Polariz."],
        "roughness_A": sample["SurfRoughA"],
        "roughness_B": sample["SurfRoughB"],
        "fractions": {
            key: {"value": value[0], "esd": value[1]}
            for key, value in hist.ComputeMassFracs().items()
        },
    }


def run(tag: str) -> dict:
    output = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output))
    project.set_Controls("cycles", 12)
    bounds = configure(project, tag)
    project.save()
    for variable, low, high in bounds:
        project.set_Controls("parmMin", low, variable)
        project.set_Controls("parmMax", high, variable)
    for _ in range(4):
        project.do_refinements([{}])
    project.save()
    result = snapshot(project, tag)
    result["project"] = str(output.relative_to(HERE))
    return result


def main() -> None:
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("none")
    cases = [
        "baseline",
        "background_4",
        "background_8",
        "polarization_0p5",
        "polarization_0p9",
        "polarization_refine",
        "roughness_refine",
    ]
    results = []
    for tag in cases:
        print(f"running {tag}", flush=True)
        try:
            results.append(run(tag))
        except Exception as exc:
            results.append({"tag": tag, "error": repr(exc)})
    with (OUT / "summary.json").open("w") as stream:
        json.dump(results, stream, indent=2)
    for row in results:
        if "error" in row:
            print(row["tag"], "ERROR", row["error"])
        else:
            print(
                row["tag"],
                f"Rwp={row['Rwp']:.5f}",
                f"GOF={row['GOF']:.4f}",
                "pol=",
                row["polarization"],
                "rough=",
                row["roughness_A"],
                row["roughness_B"],
                "frozen=",
                row["frozen"],
            )


if __name__ == "__main__":
    main()
