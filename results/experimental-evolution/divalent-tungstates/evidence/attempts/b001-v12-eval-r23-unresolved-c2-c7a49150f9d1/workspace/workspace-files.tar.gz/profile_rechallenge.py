#!/usr/bin/env python3
"""Re-challenge phase widths after accepting isotropic CaWO4 size broadening."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
BASE = HERE / "profile_trials" / "cawo4_size.gpx"
OUT = HERE / "profile_rechallenge"


def set_neutral(hap) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def configure(project, target: int | None, mode: str) -> list[str]:
    hist = project.histogram(0)
    bounded = []
    if target is None:
        return bounded
    phase = project.phases()[target]
    hap = phase.data["Histograms"][hist.name]

    # Preserve the accepted CaWO4 isotropic-size term unless explicitly replacing it.
    if target != 0:
        set_neutral(hap)
    if mode == "cawo4_combined":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 300.0
        hap["Mustrain"][2][0] = True
        bounded.append("0:0:Mustrain;i")
    elif mode == "cawo4_uniaxial_size_001":
        hap["Size"][0] = "uniaxial"
        hap["Size"][1] = [0.12, 0.05, 1.0]
        hap["Size"][2] = [True, True, False]
        hap["Size"][3] = [0, 0, 1]
        bounded.extend(["0:0:Size;i", "0:0:Size;a"])
    elif mode in ("size", "combined"):
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
        bounded.append(f"{target}:0:Size;i")
    if mode in ("strain", "combined"):
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 300.0
        hap["Mustrain"][2][0] = True
        bounded.append(f"{target}:0:Mustrain;i")
    return bounded


def snapshot(project, tag: str) -> dict:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    terms = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        terms.append(
            {
                "name": phase.name,
                "size_type": hap["Size"][0],
                "size_values": hap["Size"][1],
                "size_flags": hap["Size"][2],
                "size_axis": hap["Size"][3],
                "strain_type": hap["Mustrain"][0],
                "strain_values": hap["Mustrain"][1],
                "strain_flags": hap["Mustrain"][2],
            }
        )
    inst = hist.data["Instrument Parameters"][0]
    return {
        "tag": tag,
        "Rwp": rvals.get("Rwp", hist.get_wR()),
        "GOF": rvals.get("GOF"),
        "chi2": rvals.get("chisq"),
        "Nvars": rvals.get("Nvars"),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "frozen": project.get_Frozen(),
        "instrument": {key: inst[key][1] for key in ["Zero", "U", "W", "X"]},
        "fractions": {
            key: {"value": value[0], "esd": value[1]}
            for key, value in hist.ComputeMassFracs().items()
        },
        "terms": terms,
    }


def run(tag: str, target: int | None, mode: str) -> dict:
    output = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output))
    project.set_Controls("cycles", 12)
    bounded = configure(project, target, mode)
    project.save()
    for variable in bounded:
        if "Size" in variable:
            project.set_Controls("parmMin", 0.005, variable)
            project.set_Controls("parmMax", 10.0, variable)
        else:
            project.set_Controls("parmMin", 0.0, variable)
            project.set_Controls("parmMax", 20000.0, variable)
    for _ in range(4):
        project.do_refinements([{}])
    project.save()
    result = snapshot(project, tag)
    result["bounded_variables"] = bounded
    result["project"] = str(output.relative_to(HERE))
    return result


def main() -> None:
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("none")
    cases = [
        ("accepted_replay", None, "replay"),
        ("cawo4_combined_bounded", 0, "cawo4_combined"),
        ("cawo4_uniaxial_size_001", 0, "cawo4_uniaxial_size_001"),
    ]
    for target, name in [(1, "wo3"), (2, "ca3wo6")]:
        for mode in ["size", "strain", "combined"]:
            cases.append((f"{name}_{mode}_bounded", target, mode))
    results = []
    for tag, target, mode in cases:
        print(f"running {tag}", flush=True)
        try:
            results.append(run(tag, target, mode))
        except Exception as exc:
            results.append({"tag": tag, "error": repr(exc)})
    with (OUT / "summary.json").open("w") as stream:
        json.dump(results, stream, indent=2)
    for row in results:
        if "error" in row:
            print(row["tag"], "ERROR", row["error"])
        else:
            print(
                row["tag"],
                f"Rwp={row['Rwp']:.5f}",
                f"GOF={row['GOF']:.4f}",
                "frozen=",
                row["frozen"],
                "terms=",
                row["terms"],
            )


if __name__ == "__main__":
    main()
