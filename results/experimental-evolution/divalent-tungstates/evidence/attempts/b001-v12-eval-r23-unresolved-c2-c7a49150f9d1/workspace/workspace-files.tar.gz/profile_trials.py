#!/usr/bin/env python3
"""Run reversible per-phase size/strain trials from a common checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
BASE = HERE / "inventory_screen" / "ca3wo6_p21c_os_parent.gpx"
OUT = HERE / "profile_trials"


def neutralize(project) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Size"][4] = [1.0, 1.0, 1.0, 0.0, 0.0, 0.0]
        hap["Size"][5] = [False] * 6
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][:3] = ["MD", 1.0, False]
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]


def apply_trial(project, phase_index: int | None, mode: str) -> None:
    if phase_index is None:
        return
    hist = project.histogram(0)
    phase = project.phases()[phase_index]
    hap = phase.data["Histograms"][hist.name]
    if mode in ("size", "combined"):
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][1][2] = 1.0
        hap["Size"][2][0] = True
    if mode in ("strain", "combined"):
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2][0] = True


def snapshot(project, mode: str, phase_index: int | None) -> dict:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    fractions = {
        key: {"value": value[0], "esd": value[1]}
        for key, value in hist.ComputeMassFracs().items()
    }
    phase_terms = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phase_terms.append(
            {
                "name": phase.name,
                "size_type": hap["Size"][0],
                "size_values": hap["Size"][1],
                "size_flags": hap["Size"][2],
                "strain_type": hap["Mustrain"][0],
                "strain_values": hap["Mustrain"][1],
                "strain_flags": hap["Mustrain"][2],
            }
        )
    inst = hist.data["Instrument Parameters"][0]
    return {
        "mode": mode,
        "target_phase": None if phase_index is None else project.phases()[phase_index].name,
        "Rwp": rvals.get("Rwp", hist.get_wR()),
        "GOF": rvals.get("GOF"),
        "chi2": rvals.get("chisq"),
        "Nvars": rvals.get("Nvars"),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "instrument": {key: inst[key][1] for key in ["Zero", "U", "W", "X"]},
        "fractions": fractions,
        "phase_terms": phase_terms,
    }


def run(tag: str, phase_index: int | None, mode: str) -> dict:
    output = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output))
    project.set_Controls("cycles", 12)
    neutralize(project)
    apply_trial(project, phase_index, mode)
    project.save()
    for _ in range(4):
        project.do_refinements([{}])
    project.save()
    result = snapshot(project, mode, phase_index)
    result["tag"] = tag
    result["project"] = str(output.relative_to(HERE))
    return result


def main() -> None:
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("none")
    cases = [("neutral", None, "neutral")]
    phase_names = ["cawo4", "wo3", "ca3wo6"]
    for index, name in enumerate(phase_names):
        for mode in ["size", "strain", "combined"]:
            cases.append((f"{name}_{mode}", index, mode))
    results = []
    for tag, index, mode in cases:
        print(f"running {tag}", flush=True)
        try:
            results.append(run(tag, index, mode))
        except Exception as exc:
            results.append({"tag": tag, "error": repr(exc)})
    with (OUT / "summary.json").open("w") as stream:
        json.dump(results, stream, indent=2)
    for row in results:
        if "error" in row:
            print(row["tag"], "ERROR", row["error"])
            continue
        terms = row["phase_terms"]
        target = next(
            (item for item in terms if item["name"] == row["target_phase"]), None
        )
        print(
            row["tag"],
            f"Rwp={row['Rwp']:.5f}",
            f"GOF={row['GOF']:.4f}",
            "terms=",
            target,
            "inst=",
            row["instrument"],
        )


if __name__ == "__main__":
    main()
