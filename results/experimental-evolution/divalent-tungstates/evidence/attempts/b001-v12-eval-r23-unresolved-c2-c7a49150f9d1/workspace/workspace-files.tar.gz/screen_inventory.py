#!/usr/bin/env python3
"""Challenge coherent residuals by adding one candidate to a common checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
BASE = HERE / "source_screen" / "wo3_2311041_monoclinic.gpx"
ROOT = Path(
    "<RUN>/"
    "resources/b001-c05/cif"
)
OUT = HERE / "inventory_screen"


def cod(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutral_hap(phase, hist_name: str, scale: float) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"] = [scale, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][:3] = ["MD", 1.0, False]


def snapshot(project, hist, stage: str) -> dict:
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    try:
        fractions = {
            key: {"value": value[0], "esd": value[1]}
            for key, value in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": str(exc)}
    return {
        "stage": stage,
        "Rwp": rvals.get("Rwp", hist.get_wR()),
        "GOF": rvals.get("GOF"),
        "chi2": rvals.get("chisq"),
        "Nvars": rvals.get("Nvars"),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "fractions": fractions,
        "phases": [
            {
                "name": phase.name,
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
                "cell": phase.get_cell(),
            }
            for phase in project.phases()
        ],
        "instrument": {
            key: hist.data["Instrument Parameters"][0][key][1]
            for key in ["Zero", "U", "W", "X"]
        },
    }


def replays(project, count: int) -> None:
    for _ in range(count):
        project.do_refinements([{}])


def challenge(tag: str, path: Path, phase_name: str) -> dict:
    output = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output))
    hist = project.histogram(0)
    candidate = project.add_phase(
        str(path), phase_name, [hist], fmthint="CIF"
    )
    project.set_Controls("cycles", 12)

    # Seed at 6 wt% while preserving the two-phase checkpoint scale products.
    old_product = sum(
        phase.data["General"]["Mass"]
        * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()[:-1]
    )
    candidate_scale = old_product * (0.06 / 0.94) / candidate.data["General"]["Mass"]
    neutral_hap(candidate, hist.name, candidate_scale)
    for phase in project.phases()[:-1]:
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.data["Background"][0][1] = True

    # Fixed-cell/common-profile replay.
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
    inst = hist.data["Instrument Parameters"][0]
    for key in ["Zero", "U", "W", "X"]:
        inst[key][2] = False
    project.save()
    for phase in project.phases():
        project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Scale")
    for key in ["U", "W", "X"]:
        project.set_Controls("parmMin", 0.0, f":0:{key}")
    replays(project, 2)
    fixed = snapshot(project, hist, "fixed_candidate_cell_common_profile")

    # Reopen complete cells and the shared angular/profile nuisance set.
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    for key in ["Zero", "U", "W", "X"]:
        inst[key][2] = True
    replays(project, 4)
    elaborated = snapshot(project, hist, "refined_cells_profile")
    project.save()
    return {
        "tag": tag,
        "candidate_path": str(path),
        "project": str(output.relative_to(HERE)),
        "fixed": fixed,
        "elaborated": elaborated,
    }


def main() -> None:
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("none")
    cases = [
        (
            "ca3wo6_p21c_os_parent",
            HERE / "candidates" / "Ca3WO6_from_Ca3OsO6_1562666.cif",
            "Ca3WO6_P21c_analogue",
        ),
        (
            "ca3wo6_p21_u_parent",
            HERE / "candidates" / "Ca3WO6_from_Ca3UO6_2310470.cif",
            "Ca3WO6_P21_analogue",
        ),
        ("cao_1563196", cod("1563196"), "CaO_1563196"),
        (
            "second_cawo4_1546035",
            cod("1546035"),
            "CaWO4_monoclinic_1546035",
        ),
        (
            "second_wo3_2107312",
            cod("2107312"),
            "WO3_orthorhombic_2107312",
        ),
    ]
    results = []
    for tag, path, name in cases:
        print(f"screening {tag}", flush=True)
        try:
            results.append(challenge(tag, path, name))
        except Exception as exc:
            results.append({"tag": tag, "candidate_path": str(path), "error": repr(exc)})
    with (OUT / "summary.json").open("w") as stream:
        json.dump(results, stream, indent=2)
    for row in results:
        if "error" in row:
            print(row["tag"], "ERROR", row["error"])
        else:
            print(
                row["tag"],
                f"fixed={row['fixed']['Rwp']:.4f}",
                f"elaborated={row['elaborated']['Rwp']:.4f}",
                row["elaborated"]["fractions"],
            )


if __name__ == "__main__":
    main()
