#!/usr/bin/env python3
"""Final add/remove inventory controls around the selected three-phase model."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
BASE = HERE / "final_model_loop" / "baseline_replay.gpx"
OUT = HERE / "final_inventory_challenge"
ROOT = Path(
    "<RUN>/"
    "resources/b001-c05/cif"
)


def cod(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = {
    "CaO_1563196": (cod("1563196"), "CaO_1563196"),
    "CaWO4_1546035": (cod("1546035"), "CaWO4_monoclinic_1546035"),
    "WO3_1528915": (cod("1528915"), "WO3_monoclinic_1528915"),
    "Ca3WO6_P21": (
        HERE / "source_screen" / "ca3wo6_p21_crossseed.cif",
        "Ca3WO6_P21_competitor",
    ),
}


def neutral_hap(hap) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][:3] = ["MD", 1.0, False]


def set_bounds(project) -> None:
    for phase in project.phases():
        project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Scale")
    for variable in [":0:U", ":0:W", ":0:X", ":0:SurfRoughB"]:
        project.set_Controls("parmMin", 0.0, variable)
    project.set_Controls("parmMin", 0.0, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    for phase in project.phases():
        for suffix in ["Size;i", "Size;a"]:
            variable = f"{phase.id}:0:{suffix}"
            project.set_Controls("parmMin", 0.005, variable)
            project.set_Controls("parmMax", 10.0, variable)
        variable = f"{phase.id}:0:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable)
        project.set_Controls("parmMax", 20000.0, variable)
        variable = f"{phase.id}:0:MD"
        project.set_Controls("parmMin", 0.2, variable)
        project.set_Controls("parmMax", 5.0, variable)


def snapshot(project, hist, stage: str) -> dict:
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    phase_rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phase_rows.append(
            {"phase": phase.name, "space_group": phase.data["General"]["SGData"]["SpGrp"],
             "cell": phase.get_cell(), "scale": hap["Scale"],
             "size": [hap["Size"][0], hap["Size"][1], hap["Size"][2]],
             "strain": [hap["Mustrain"][0], hap["Mustrain"][1],
                        hap["Mustrain"][2]],
             "preferred_orientation": hap["Pref.Ori."]}
        )
    return {
        "stage": stage,
        "Rwp": rvals.get("Rwp", hist.get_wR()),
        "GOF": rvals.get("GOF"),
        "chi2": rvals.get("chisq"),
        "Nvars": rvals.get("Nvars"),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "frozen": project.get_Frozen(),
        "phases": phase_rows,
        "fractions": {key: {"value": value[0], "esd": value[1]}
                      for key, value in hist.ComputeMassFracs().items()},
    }


def add_candidate(candidate: str, mode: str) -> dict:
    tag = f"add_{candidate}_{mode}"
    output = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output))
    hist = project.histogram(0)
    cif, name = CANDIDATES[candidate]
    phase = project.add_phase(str(cif), name, [hist], fmthint="CIF")
    project.set_Controls("cycles", 12)
    hap = phase.data["Histograms"][hist.name]
    neutral_hap(hap)
    # Start at 2 wt%; this is large enough to test a positive scale without
    # prejudicing a collapse to the nonnegative boundary.
    retained_product = sum(
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()[:-1]
    )
    hap["Scale"] = [retained_product * (0.02 / 0.98) / phase.data["General"]["Mass"], True]
    if mode in ("size", "combined"):
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
    if mode in ("strain", "combined"):
        hap["Mustrain"][1][0] = 300.0
        hap["Mustrain"][2][0] = True
    if mode == "texture001":
        hap["Pref.Ori."][1] = 0.9
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = [0, 0, 1]
    if mode == "texture100":
        hap["Pref.Ori."][1] = 0.9
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = [1, 0, 0]
    phase.data["General"]["Cell"][0] = False
    project.save()
    set_bounds(project)
    replay = []
    for _ in range(2):
        project.do_refinements([{}])
        replay.append(project.data["Covariance"]["data"].get("Rvals", {}).copy())
    fixed = snapshot(project, hist, "candidate_cell_fixed")
    phase.data["General"]["Cell"][0] = True
    for _ in range(4):
        project.do_refinements([{}])
        replay.append(project.data["Covariance"]["data"].get("Rvals", {}).copy())
    project.save()
    refined = snapshot(project, hist, "candidate_cell_refined")
    return {"tag": tag, "candidate": candidate, "mode": mode,
            "project": str(output.relative_to(HERE)), "fixed": fixed,
            "refined": refined, "replay": replay}


def remove_phase(index: int) -> dict:
    tag = f"remove_phase_{index}"
    output = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output))
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    phase = project.phases()[index]
    hap = phase.data["Histograms"][hist.name]
    # Disable the HAP explicitly. A zero fixed scale leaves a stale calculated
    # profile in GSAS-II when no active parameter forces profile regeneration.
    hap["Use"] = False
    hap["Scale"][1] = False
    neutral_hap(hap)
    phase.data["General"]["Cell"][0] = False
    project.save()
    set_bounds(project)
    replay = []
    for _ in range(4):
        project.do_refinements([{}])
        replay.append(project.data["Covariance"]["data"].get("Rvals", {}).copy())
    project.save()
    return {"tag": tag, "removed": phase.name,
            "project": str(output.relative_to(HERE)),
            "refined": snapshot(project, hist, "removed_phase_replay"),
            "replay": replay}


def main() -> None:
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("none")
    if len(sys.argv) > 1 and sys.argv[1] == "removals":
        results = []
        for index in [1, 2]:
            print(f"running remove phase {index}", flush=True)
            try:
                results.append(remove_phase(index))
            except Exception as exc:
                results.append({"tag": f"remove_phase_{index}", "error": repr(exc)})
        with (OUT / "removal_summary.json").open("w") as stream:
            json.dump(results, stream, indent=2)
        for row in results:
            if "error" in row:
                print(row["tag"], "ERROR", row["error"])
            else:
                r = row["refined"]
                print(row["tag"], f"Rwp={r['Rwp']:.6f}",
                      f"max={r['max_shift_over_esd']}", "frozen=", r["frozen"],
                      "fractions=", r["fractions"])
        return
    cases = []
    cases += [("CaO_1563196", mode) for mode in ["neutral", "size"]]
    cases += [("CaWO4_1546035", mode) for mode in
              ["neutral", "size", "texture001", "texture100"]]
    cases += [("WO3_1528915", mode) for mode in
              ["neutral", "size", "strain", "combined"]]
    cases += [("Ca3WO6_P21", mode) for mode in
              ["neutral", "size", "strain", "combined"]]
    results = []
    for candidate, mode in cases:
        print(f"running add {candidate} {mode}", flush=True)
        try:
            results.append(add_candidate(candidate, mode))
        except Exception as exc:
            results.append({"tag": f"add_{candidate}_{mode}", "error": repr(exc)})
    for index in [1, 2]:
        print(f"running remove phase {index}", flush=True)
        try:
            results.append(remove_phase(index))
        except Exception as exc:
            results.append({"tag": f"remove_phase_{index}", "error": repr(exc)})
    with (OUT / "summary.json").open("w") as stream:
        json.dump(results, stream, indent=2)
    for row in results:
        if "error" in row:
            print(row["tag"], "ERROR", row["error"])
        else:
            r = row["refined"]
            print(row["tag"], f"Rwp={r['Rwp']:.6f}",
                  f"max={r['max_shift_over_esd']}", "frozen=", r["frozen"],
                  "fractions=", r["fractions"])


if __name__ == "__main__":
    main()
