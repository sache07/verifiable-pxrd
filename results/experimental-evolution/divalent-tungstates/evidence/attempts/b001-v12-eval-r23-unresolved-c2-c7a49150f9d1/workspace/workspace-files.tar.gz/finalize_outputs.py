#!/usr/bin/env python3
"""Replay the selected model and export the submission artifacts from final.gpx."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
SOURCE = HERE / "final_model_loop" / "baseline_replay.gpx"
FINAL = HERE / "final.gpx"

PHASE_INFO = [
    {
        "name": "Calcium tungstate (scheelite)",
        "formula": "CaWO4",
        "cif_path": "CaWO4.cif",
        "source": "COD 7219229",
        "model_note": "Exact-formula source record; unit cell refined.",
    },
    {
        "name": "Monoclinic tungsten trioxide (gamma-WO3)",
        "formula": "WO3",
        "cif_path": "WO3.cif",
        "source": "COD 2311041",
        "model_note": "Exact-formula source record in a nonconventional P21/c setting; unit cell refined.",
    },
    {
        "name": "Tricalcium tungstate",
        "formula": "Ca3WO6",
        "cif_path": "Ca3WO6.cif",
        "source": "Isovalent W6+ analogue constructed from Ca3OsO6, COD 1562666",
        "model_note": "P21/n analogue model; Os6+ was replaced by W6+ and the unit cell was refined. Atomic coordinates were not independently refined.",
    },
]


def replay(project: G2sc.G2Project, count: int) -> list[dict]:
    project.set_Controls("cycles", 12)
    rows = []
    for _ in range(count):
        project.do_refinements([{}])
        rows.append(project.data["Covariance"]["data"].get("Rvals", {}).copy())
    return rows


def main() -> None:
    G2sc.SetPrintLevel("none")
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    hist = project.histogram(0)
    limits = hist.data["Limits"][1]
    x = np.asarray(hist.data["data"][1][0], dtype=float)
    if limits[0] > x.min() + 1e-6 or limits[1] < x.max() - 1e-6:
        raise RuntimeError(f"Final project does not use the full measured range: {limits}")
    if any(not phase.data["Histograms"][hist.name].get("Use", True)
           for phase in project.phases()):
        raise RuntimeError("A submitted phase is disabled in the selected project")
    replay(project, 4)
    project.save()

    # Required save/reopen/full-range replay before freezing exports.
    project = G2sc.G2Project(str(FINAL))
    hist = project.histogram(0)
    final_replay = replay(project, 2)
    project.save()
    frozen = project.get_Frozen()
    if frozen:
        raise RuntimeError(f"Final replay contains bound/frozen variables: {frozen}")

    phases = project.phases()
    if len(phases) != len(PHASE_INFO):
        raise RuntimeError(f"Expected three phases, found {len(phases)}")
    fractions_raw = hist.ComputeMassFracs()
    values = np.asarray([fractions_raw[p.name][0] for p in phases], dtype=float)
    if np.any(~np.isfinite(values)) or np.any(values <= 0):
        raise RuntimeError(f"Invalid final mass fractions: {values}")
    values /= values.sum()

    for phase, info in zip(phases, PHASE_INFO):
        phase.export_CIF(str(HERE / info["cif_path"]))

    profile = np.asarray(hist.data["data"][1], dtype=float)
    with (HERE / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta_deg", "observed_intensity", "calculated_intensity",
             "difference_intensity", "background_intensity"]
        )
        for row in zip(profile[0], profile[1], profile[3], profile[5], profile[4]):
            writer.writerow([f"{value:.10g}" for value in row])

    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    hist_stats = hist.data["data"][0]
    result_phases = []
    for idx, (phase, info, fraction) in enumerate(zip(phases, PHASE_INFO, values)):
        raw_esd = fractions_raw[phase.name][1]
        result_phases.append(
            {
                **info,
                "project_path": "final.gpx",
                "weight_fraction": float(fraction),
                "weight_percent": float(100.0 * fraction),
                "weight_fraction_esd_conditional": (
                    float(raw_esd) if np.isfinite(raw_esd) else None
                ),
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "unit_cell": {key: float(value)
                              for key, value in phase.get_cell().items()},
            }
        )

    result = {
        "project_path": "final.gpx",
        "fit_path": "fit.csv",
        "fraction_basis": "Normalized over the three modeled crystalline phases; no amorphous fraction was determined.",
        "phases": result_phases,
        "fit_statistics": {
            "Rwp_percent": float(rvals.get("Rwp", hist.get_wR())),
            "Rp_percent": float(hist_stats.get("R")),
            "Rexp_percent": float(hist_stats.get("wRmin")),
            "GOF": float(rvals.get("GOF")),
            "chi_squared": float(rvals.get("chisq")),
            "N_observations": int(rvals.get("Nobs")),
            "N_variables": int(rvals.get("Nvars")),
            "max_shift_over_esd": float(rvals.get("Max shft/sig")),
            "Durbin_Watson": float(hist_stats.get("Durbin-Watson")),
            "full_range_two_theta_deg": [float(profile[0].min()), float(profile[0].max())],
            "weighting": "Poisson 1/I weights assigned by the GSAS-II reader because pointwise uncertainties were not supplied.",
        },
        "final_replay": {
            "passes": len(final_replay),
            "last_Rwp_percent": float(final_replay[-1]["Rwp"]),
            "last_max_shift_over_esd": float(final_replay[-1]["Max shft/sig"]),
            "frozen_variables": frozen,
        },
    }
    with (HERE / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
