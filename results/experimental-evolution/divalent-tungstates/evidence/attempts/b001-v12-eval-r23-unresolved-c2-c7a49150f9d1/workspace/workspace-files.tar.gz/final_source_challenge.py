#!/usr/bin/env python3
"""Replay close WO3 source records with the complete accepted nuisance model."""

from __future__ import annotations

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
BASE = HERE / "roughness_challenge" / "baseline_replay.gpx"
OUT = HERE / "final_source_challenge"
CA3_CIF = HERE / "candidates" / "Ca3WO6_from_Ca3OsO6_1562666.cif"

SOURCES = {
    "2311041_monoclinic": HERE / "source_screen" / "wo3_2311041_monoclinic.gpx",
    "1528915_monoclinic": HERE / "source_screen" / "wo3_1528915_monoclinic.gpx",
    "2106293_triclinic": HERE / "source_screen" / "wo3_2106293_triclinic.gpx",
    "2107312_orthorhombic": HERE / "source_screen" / "wo3_2107312_orthorhombic.gpx",
}


def neutral_size(hap) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])


def neutral_strain(hap) -> None:
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def copy_hap_shape(source_hap, target_hap) -> None:
    for key in ["Size", "Mustrain", "Pref.Ori."]:
        target_hap[key] = copy.deepcopy(source_hap[key])


def configure(source: str, mode: str, output: Path):
    accepted = G2sc.G2Project(str(BASE))
    accepted_hist = accepted.histogram(0)
    accepted_phases = accepted.phases()

    project = G2sc.G2Project(str(SOURCES[source]), newgpx=str(output))
    hist = project.histogram(0)
    phases = project.phases()
    ca3 = project.add_phase(
        str(CA3_CIF), "Ca3WO6_P21c_analogue", [hist], fmthint="CIF"
    )
    phases = project.phases()
    project.set_Controls("cycles", 12)

    # Cross-seed the full shared model from the selected three-phase checkpoint.
    hist.data["Background"] = copy.deepcopy(accepted_hist.data["Background"])
    hist.data["Instrument Parameters"] = copy.deepcopy(
        accepted_hist.data["Instrument Parameters"]
    )
    for key in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]:
        hist.data["Sample Parameters"][key] = copy.deepcopy(
            accepted_hist.data["Sample Parameters"][key]
        )
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]

    # Keep the source-specific WO3 cell reached in its neutral source challenge.
    phases[0].data["General"]["Cell"] = copy.deepcopy(
        accepted_phases[0].data["General"]["Cell"]
    )
    phases[2].data["General"]["Cell"] = copy.deepcopy(
        accepted_phases[2].data["General"]["Cell"]
    )
    for idx in [0, 2]:
        copy_hap_shape(
            accepted_phases[idx].data["Histograms"][accepted_hist.name],
            phases[idx].data["Histograms"][hist.name],
        )
    wo_hap = phases[1].data["Histograms"][hist.name]
    neutral_size(wo_hap)
    neutral_strain(wo_hap)
    wo_hap["Pref.Ori."][:3] = ["MD", 1.0, False]

    # Preserve accepted scale products so all records start at identical fractions.
    for idx, phase in enumerate(phases):
        accepted_product = (
            accepted_phases[idx].data["General"]["Mass"]
            * accepted_phases[idx].data["Histograms"][accepted_hist.name]["Scale"][0]
        )
        phase.data["Histograms"][hist.name]["Scale"] = [
            accepted_product / phase.data["General"]["Mass"],
            True,
        ]

    bounds = []
    if mode in ("size", "combined"):
        wo_hap["Size"][1][0] = 1.0
        wo_hap["Size"][2][0] = True
        bounds.append(("1:0:Size;i", 0.005, 10.0))
    if mode in ("strain", "combined"):
        wo_hap["Mustrain"][1][0] = 300.0
        wo_hap["Mustrain"][2][0] = True
        bounds.append(("1:0:Mustrain;i", 0.0, 20000.0))

    for phase in phases:
        phase.data["General"]["Cell"][0] = False
    project.save()
    for phase in phases:
        project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Scale")
    for variable, low, high in bounds:
        project.set_Controls("parmMin", low, variable)
        project.set_Controls("parmMax", high, variable)
    for variable in [":0:U", ":0:W", ":0:X", ":0:SurfRoughB"]:
        project.set_Controls("parmMin", 0.0, variable)
    project.set_Controls("parmMin", 0.0, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    project.set_Controls("parmMin", 0.2, "0:0:MD")
    project.set_Controls("parmMax", 5.0, "0:0:MD")
    for variable in ["0:0:Size;i", "0:0:Size;a", "2:0:Size;i"]:
        project.set_Controls("parmMin", 0.005, variable)
        project.set_Controls("parmMax", 10.0, variable)
    return project, hist


def snapshot(project, hist, stage: str) -> dict:
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    inst = hist.data["Instrument Parameters"][0]
    terms = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        terms.append(
            {
                "phase": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": [hap["Size"][0], hap["Size"][1], hap["Size"][2]],
                "strain": [
                    hap["Mustrain"][0], hap["Mustrain"][1], hap["Mustrain"][2]
                ],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    return {
        "stage": stage,
        "Rwp": rvals.get("Rwp", hist.get_wR()),
        "GOF": rvals.get("GOF"),
        "chi2": rvals.get("chisq"),
        "Nvars": rvals.get("Nvars"),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "frozen": project.get_Frozen(),
        "polarization": inst["Polariz."],
        "roughness_B": hist.data["Sample Parameters"]["SurfRoughB"],
        "instrument": {key: inst[key] for key in ["Zero", "U", "V", "W", "X"]},
        "terms": terms,
        "fractions": {
            key: {"value": value[0], "esd": value[1]}
            for key, value in hist.ComputeMassFracs().items()
        },
    }


def run(source: str, mode: str) -> dict:
    tag = f"{source}_{mode}"
    output = OUT / f"{tag}.gpx"
    project, hist = configure(source, mode, output)
    replay = []
    for _ in range(2):
        project.do_refinements([{}])
        replay.append(project.data["Covariance"]["data"].get("Rvals", {}).copy())
    fixed = snapshot(project, hist, "fixed_cells_complete_profile")
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    for _ in range(4):
        project.do_refinements([{}])
        replay.append(project.data["Covariance"]["data"].get("Rvals", {}).copy())
    project.save()
    refined = snapshot(project, hist, "refined_cells_complete_profile")
    return {
        "tag": tag,
        "source": source,
        "mode": mode,
        "project": str(output.relative_to(HERE)),
        "fixed": fixed,
        "refined": refined,
        "replay": replay,
    }


def main() -> None:
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("none")
    cases = []
    for source in ["2311041_monoclinic", "1528915_monoclinic", "2106293_triclinic"]:
        for mode in ["neutral", "size", "strain", "combined"]:
            cases.append((source, mode))
    cases.append(("2107312_orthorhombic", "neutral"))
    results = []
    for source, mode in cases:
        print(f"running {source} {mode}", flush=True)
        try:
            results.append(run(source, mode))
        except Exception as exc:
            results.append(
                {"tag": f"{source}_{mode}", "source": source, "mode": mode,
                 "error": repr(exc)}
            )
    with (OUT / "summary.json").open("w") as stream:
        json.dump(results, stream, indent=2)
    for row in results:
        if "error" in row:
            print(row["tag"], "ERROR", row["error"])
        else:
            print(
                row["tag"], f"fixed={row['fixed']['Rwp']:.6f}",
                f"refined={row['refined']['Rwp']:.6f}",
                f"max={row['refined']['max_shift_over_esd']}",
                "frozen=", row["refined"]["frozen"],
                "fractions=", row["refined"]["fractions"],
            )


if __name__ == "__main__":
    main()
