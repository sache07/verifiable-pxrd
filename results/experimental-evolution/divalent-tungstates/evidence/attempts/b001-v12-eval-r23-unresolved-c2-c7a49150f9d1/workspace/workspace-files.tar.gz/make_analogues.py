#!/usr/bin/env python3
"""Construct charge-balanced Ca3WO6 competitors from close isovalent parents."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(
    "<RUN>/"
    "resources/b001-c05/cif"
)
OUT = Path(__file__).resolve().parent / "candidates"


def source(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def substitute(cod_id: str, old: str, output: str) -> None:
    structure = Structure.from_file(source(cod_id))
    structure.replace_species({old: "W"})
    if structure.composition.reduced_formula != "Ca3WO6":
        raise ValueError(f"unexpected product {structure.composition.reduced_formula}")
    CifWriter(structure, symprec=0.02, refine_struct=False).write_file(OUT / output)


def main() -> None:
    OUT.mkdir(exist_ok=True)
    # Ca and O sublattices are retained; Os6+ and U6+ are replaced isovalently by W6+.
    substitute("1562666", "Os", "Ca3WO6_from_Ca3OsO6_1562666.cif")
    substitute("2310470", "U", "Ca3WO6_from_Ca3UO6_2310470.cif")


if __name__ == "__main__":
    main()
