#!/usr/bin/env python3
"""Screen simple low-index March-Dollase axes from a roughness-free checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
BASE = HERE / "model_stage_global.gpx"
OUT = HERE / "texture_trials"


def run(phase_index: int, axis: tuple[int, int, int]) -> dict:
    tag = f"phase{phase_index}_{axis[0]}{axis[1]}{axis[2]}"
    output = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output))
    hist = project.histogram(0)
    project.set_Controls("cycles", 12)
    for phase in project.phases():
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = False
    phase = project.phases()[phase_index]
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[1] = 0.9
    po[2] = True
    po[3] = list(axis)
    project.save()
    variable = f"{phase_index}:0:MD"
    project.set_Controls("parmMin", 0.2, variable)
    project.set_Controls("parmMax", 5.0, variable)
    for _ in range(4):
        project.do_refinements([{}])
    project.save()
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    return {
        "tag": tag,
        "project": str(output.relative_to(HERE)),
        "phase": phase.name,
        "axis": list(axis),
        "ratio": po[1],
        "Rwp": rvals.get("Rwp", hist.get_wR()),
        "GOF": rvals.get("GOF"),
        "chi2": rvals.get("chisq"),
        "Nvars": rvals.get("Nvars"),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "frozen": project.get_Frozen(),
        "fractions": {
            key: {"value": value[0], "esd": value[1]}
            for key, value in hist.ComputeMassFracs().items()
        },
    }


def main() -> None:
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("none")
    axes = {
        0: [(0, 0, 1), (1, 0, 0), (1, 1, 0), (1, 0, 1), (1, 1, 2)],
        1: [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0)],
        2: [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0)],
    }
    results = []
    for phase_index, phase_axes in axes.items():
        for axis in phase_axes:
            print(f"running phase {phase_index} axis {axis}", flush=True)
            try:
                results.append(run(phase_index, axis))
            except Exception as exc:
                results.append(
                    {
                        "tag": f"phase{phase_index}_{axis[0]}{axis[1]}{axis[2]}",
                        "error": repr(exc),
                    }
                )
    with (OUT / "summary.json").open("w") as stream:
        json.dump(results, stream, indent=2)
    for row in results:
        if "error" in row:
            print(row["tag"], "ERROR", row["error"])
        else:
            print(
                row["tag"],
                f"Rwp={row['Rwp']:.5f}",
                f"ratio={row['ratio']:.5f}",
                "fractions=",
                row["fractions"],
                "frozen=",
                row["frozen"],
            )


if __name__ == "__main__":
    main()
