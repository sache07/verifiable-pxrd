#!/usr/bin/env python3
"""Re-open profile and global terms around the accepted CaWO4 [110] MD checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
BASE = HERE / "texture_trials" / "phase0_110.gpx"
OUT = HERE / "post_texture_loop"


def neutral_size(hap) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])


def neutral_strain(hap) -> None:
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def configure(project, tag: str) -> list[tuple[str, float, float]]:
    hist = project.histogram(0)
    phases = project.phases()
    bounds: list[tuple[str, float, float]] = []
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    if tag.startswith("background_"):
        order = int(tag.split("_")[1])
        old = list(hist.data["Background"][0][3:])
        coeffs = (old + [0.0] * order)[:order]
        hist.set_refinements(
            {
                "Background": {
                    "type": "chebyschev-1",
                    "no. coeffs": order,
                    "coeffs": coeffs,
                    "refine": True,
                }
            }
        )
    elif tag.startswith("polarization_fixed_"):
        value = float(tag.rsplit("_", 1)[1].replace("p", "."))
        inst["Polariz."][0] = inst["Polariz."][1] = value
        inst["Polariz."][2] = False
    elif tag == "roughness_B_only":
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.05, True]
        bounds.append((":0:SurfRoughB", 0.0, 1.0))
    elif tag == "roughness_AB":
        sample["SurfRoughA"] = [0.1, True]
        sample["SurfRoughB"] = [0.05, True]
        bounds.extend(
            [(":0:SurfRoughA", 0.0, 1.0), (":0:SurfRoughB", 0.0, 1.0)]
        )
    elif tag == "texture_neutral":
        po = phases[0].data["Histograms"][hist.name]["Pref.Ori."]
        po[1] = 1.0
        po[2] = False
    elif tag == "cawo4_size_neutral":
        hap = phases[0].data["Histograms"][hist.name]
        neutral_size(hap)
    elif tag == "cawo4_size_isotropic":
        hap = phases[0].data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [0.10, 10.0, 1.0]
        hap["Size"][2] = [True, False, False]
        bounds.append(("0:0:Size;i", 0.005, 10.0))
    elif tag == "cawo4_size_plus_strain":
        hap = phases[0].data["Histograms"][hist.name]
        neutral_strain(hap)
        hap["Mustrain"][1][0] = 300.0
        hap["Mustrain"][2][0] = True
        bounds.append(("0:0:Mustrain;i", 0.0, 20000.0))
    elif tag == "wo3_size":
        hap = phases[1].data["Histograms"][hist.name]
        neutral_size(hap)
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
        bounds.append(("1:0:Size;i", 0.005, 10.0))
    elif tag == "wo3_strain":
        hap = phases[1].data["Histograms"][hist.name]
        neutral_strain(hap)
        hap["Mustrain"][1][0] = 300.0
        hap["Mustrain"][2][0] = True
        bounds.append(("1:0:Mustrain;i", 0.0, 20000.0))
    elif tag == "ca3wo6_size_neutral":
        hap = phases[2].data["Histograms"][hist.name]
        neutral_size(hap)
    elif tag == "ca3wo6_strain":
        hap = phases[2].data["Histograms"][hist.name]
        neutral_size(hap)
        neutral_strain(hap)
        hap["Mustrain"][1][0] = 300.0
        hap["Mustrain"][2][0] = True
        bounds.append(("2:0:Mustrain;i", 0.0, 20000.0))
    elif tag == "ca3wo6_size_plus_strain":
        hap = phases[2].data["Histograms"][hist.name]
        neutral_strain(hap)
        hap["Mustrain"][1][0] = 300.0
        hap["Mustrain"][2][0] = True
        bounds.append(("2:0:Mustrain;i", 0.0, 20000.0))
    return bounds


def snapshot(project, tag: str) -> dict:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phase_terms = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phase_terms.append(
            {
                "phase": phase.name,
                "size_type": hap["Size"][0],
                "size_values": hap["Size"][1],
                "size_flags": hap["Size"][2],
                "strain_type": hap["Mustrain"][0],
                "strain_values": hap["Mustrain"][1],
                "strain_flags": hap["Mustrain"][2],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    return {
        "tag": tag,
        "Rwp": rvals.get("Rwp", hist.get_wR()),
        "GOF": rvals.get("GOF"),
        "chi2": rvals.get("chisq"),
        "Nvars": rvals.get("Nvars"),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "frozen": project.get_Frozen(),
        "background": hist.data["Background"][0],
        "polarization": inst["Polariz."],
        "roughness_A": sample["SurfRoughA"],
        "roughness_B": sample["SurfRoughB"],
        "instrument": {
            key: inst[key] for key in ["Zero", "U", "V", "W", "X", "SH/L"]
        },
        "phase_terms": phase_terms,
        "fractions": {
            key: {"value": value[0], "esd": value[1]}
            for key, value in hist.ComputeMassFracs().items()
        },
    }


def run(tag: str) -> dict:
    output = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output))
    project.set_Controls("cycles", 12)
    bounds = configure(project, tag)
    project.save()
    for variable, low, high in bounds:
        project.set_Controls("parmMin", low, variable)
        project.set_Controls("parmMax", high, variable)
    replay = []
    for _ in range(4):
        project.do_refinements([{}])
        replay.append(project.data["Covariance"]["data"].get("Rvals", {}).copy())
    project.save()
    result = snapshot(project, tag)
    result["replay"] = replay
    result["project"] = str(output.relative_to(HERE))
    return result


def main() -> None:
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("none")
    cases = [
        "baseline_replay",
        "background_6",
        "background_8",
        "background_10",
        "polarization_fixed_0p7",
        "polarization_fixed_0p9",
        "roughness_B_only",
        "roughness_AB",
        "texture_neutral",
        "cawo4_size_neutral",
        "cawo4_size_isotropic",
        "cawo4_size_plus_strain",
        "wo3_size",
        "wo3_strain",
        "ca3wo6_size_neutral",
        "ca3wo6_strain",
        "ca3wo6_size_plus_strain",
    ]
    results = []
    for tag in cases:
        print(f"running {tag}", flush=True)
        try:
            results.append(run(tag))
        except Exception as exc:
            results.append({"tag": tag, "error": repr(exc)})
    with (OUT / "summary.json").open("w") as stream:
        json.dump(results, stream, indent=2)
    for row in results:
        if "error" in row:
            print(row["tag"], "ERROR", row["error"])
        else:
            print(
                row["tag"],
                f"Rwp={row['Rwp']:.6f}",
                f"GOF={row['GOF']:.5f}",
                f"max={row['max_shift_over_esd']}",
                "frozen=", row["frozen"],
                "fractions=", row["fractions"],
            )


if __name__ == "__main__":
    main()
