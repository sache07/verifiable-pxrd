#!/usr/bin/env python3
"""Compare P21 and P21/n Ca3WO6 analogue models with the final shared profile."""

from __future__ import annotations

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
BASE = HERE / "roughness_challenge" / "baseline_replay.gpx"
OUT = HERE / "final_ca3_symmetry_challenge"
SOURCES = {
    "P21": HERE / "source_screen" / "ca3wo6_p21_crossseed.gpx",
    "P21n": HERE / "source_screen" / "ca3wo6_p21c_backcross.gpx",
}


def neutral_size(hap) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])


def neutral_strain(hap) -> None:
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def configure(source: str, mode: str, output: Path):
    accepted = G2sc.G2Project(str(BASE))
    ah = accepted.histogram(0)
    ap = accepted.phases()
    project = G2sc.G2Project(str(SOURCES[source]), newgpx=str(output))
    hist = project.histogram(0)
    phases = project.phases()
    project.set_Controls("cycles", 12)

    hist.data["Background"] = copy.deepcopy(ah.data["Background"])
    hist.data["Instrument Parameters"] = copy.deepcopy(ah.data["Instrument Parameters"])
    for key in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]:
        hist.data["Sample Parameters"][key] = copy.deepcopy(
            ah.data["Sample Parameters"][key]
        )
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]

    # Cross-seed shared cells and all HAP terms; preserve only the Ca3 source model.
    for idx in [0, 1]:
        phases[idx].data["General"]["Cell"] = copy.deepcopy(
            ap[idx].data["General"]["Cell"]
        )
    for idx in range(3):
        sh = ap[idx].data["Histograms"][ah.name]
        th = phases[idx].data["Histograms"][hist.name]
        for key in ["Size", "Mustrain", "Pref.Ori."]:
            th[key] = copy.deepcopy(sh[key])
        product = ap[idx].data["General"]["Mass"] * sh["Scale"][0]
        th["Scale"] = [product / phases[idx].data["General"]["Mass"], True]

    hap = phases[2].data["Histograms"][hist.name]
    neutral_strain(hap)
    if mode == "neutral":
        neutral_size(hap)
    elif mode == "size":
        neutral_size(hap)
        hap["Size"][1][0] = 0.28
        hap["Size"][2][0] = True
    elif mode == "strain":
        neutral_size(hap)
        hap["Mustrain"][1][0] = 300.0
        hap["Mustrain"][2][0] = True
    elif mode == "combined":
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [0.28, 10.0, 1.0]
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][1][0] = 300.0
        hap["Mustrain"][2][0] = True

    for phase in phases:
        phase.data["General"]["Cell"][0] = False
    project.save()
    for phase in phases:
        project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Scale")
    for variable in [":0:U", ":0:W", ":0:X", ":0:SurfRoughB"]:
        project.set_Controls("parmMin", 0.0, variable)
    project.set_Controls("parmMin", 0.0, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    project.set_Controls("parmMin", 0.2, "0:0:MD")
    project.set_Controls("parmMax", 5.0, "0:0:MD")
    for variable in ["0:0:Size;i", "0:0:Size;a", "2:0:Size;i"]:
        project.set_Controls("parmMin", 0.005, variable)
        project.set_Controls("parmMax", 10.0, variable)
    project.set_Controls("parmMin", 0.0, "2:0:Mustrain;i")
    project.set_Controls("parmMax", 20000.0, "2:0:Mustrain;i")
    return project, hist


def snapshot(project, hist, stage: str) -> dict:
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    terms = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        terms.append(
            {
                "phase": phase.name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": [hap["Size"][0], hap["Size"][1], hap["Size"][2]],
                "strain": [hap["Mustrain"][1], hap["Mustrain"][2]],
            }
        )
    return {
        "stage": stage,
        "Rwp": rvals.get("Rwp", hist.get_wR()),
        "GOF": rvals.get("GOF"),
        "chi2": rvals.get("chisq"),
        "Nvars": rvals.get("Nvars"),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "frozen": project.get_Frozen(),
        "terms": terms,
        "fractions": {
            key: {"value": value[0], "esd": value[1]}
            for key, value in hist.ComputeMassFracs().items()
        },
    }


def run(source: str, mode: str) -> dict:
    tag = f"{source}_{mode}"
    output = OUT / f"{tag}.gpx"
    project, hist = configure(source, mode, output)
    replay = []
    for _ in range(2):
        project.do_refinements([{}])
        replay.append(project.data["Covariance"]["data"].get("Rvals", {}).copy())
    fixed = snapshot(project, hist, "fixed_cells_complete_profile")
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    for _ in range(4):
        project.do_refinements([{}])
        replay.append(project.data["Covariance"]["data"].get("Rvals", {}).copy())
    project.save()
    refined = snapshot(project, hist, "refined_cells_complete_profile")
    return {
        "tag": tag,
        "source": source,
        "mode": mode,
        "project": str(output.relative_to(HERE)),
        "fixed": fixed,
        "refined": refined,
        "replay": replay,
    }


def main() -> None:
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("none")
    results = []
    for source in ["P21n", "P21"]:
        for mode in ["neutral", "size", "strain", "combined"]:
            print(f"running {source} {mode}", flush=True)
            try:
                results.append(run(source, mode))
            except Exception as exc:
                results.append({"tag": f"{source}_{mode}", "error": repr(exc)})
    with (OUT / "summary.json").open("w") as stream:
        json.dump(results, stream, indent=2)
    for row in results:
        if "error" in row:
            print(row["tag"], "ERROR", row["error"])
        else:
            print(
                row["tag"], f"fixed={row['fixed']['Rwp']:.6f}",
                f"refined={row['refined']['Rwp']:.6f}",
                f"max={row['refined']['max_shift_over_esd']}",
                "frozen=", row["refined"]["frozen"],
                "fractions=", row["refined"]["fractions"],
            )


if __name__ == "__main__":
    main()
