#!/usr/bin/env python3
"""Final replay loop after accepting the P21/n Ca3WO6 combined width model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
BASE = HERE / "final_ca3_symmetry_challenge" / "P21n_combined.gpx"
OUT = HERE / "final_model_loop"


def neutral_size(hap) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])


def neutral_strain(hap) -> None:
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def configure(project, tag: str) -> None:
    hist = project.histogram(0)
    phases = project.phases()
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    if tag.startswith("background_"):
        order = int(tag.split("_")[1])
        old = list(hist.data["Background"][0][3:])
        coeffs = (old + [0.0] * order)[:order]
        hist.set_refinements(
            {"Background": {"type": "chebyschev-1", "no. coeffs": order,
                            "coeffs": coeffs, "refine": True}}
        )
    elif tag == "roughness_neutral":
        sample["SurfRoughB"] = [0.0, False]
    elif tag.startswith("polarization_fixed_"):
        value = float(tag.rsplit("_", 1)[1].replace("p", "."))
        inst["Polariz."] = [value, value, False]
    elif tag == "texture_neutral":
        po = phases[0].data["Histograms"][hist.name]["Pref.Ori."]
        po[1] = 1.0
        po[2] = False
    elif tag == "cawo4_size_neutral":
        neutral_size(phases[0].data["Histograms"][hist.name])
    elif tag == "cawo4_size_isotropic":
        hap = phases[0].data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [0.10, 10.0, 1.0]
        hap["Size"][2] = [True, False, False]
    elif tag == "wo3_size":
        hap = phases[1].data["Histograms"][hist.name]
        neutral_size(hap)
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
    elif tag == "wo3_strain":
        hap = phases[1].data["Histograms"][hist.name]
        neutral_strain(hap)
        hap["Mustrain"][1][0] = 300.0
        hap["Mustrain"][2][0] = True


def snapshot(project, tag: str) -> dict:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    terms = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        terms.append(
            {"phase": phase.name, "cell": phase.get_cell(),
             "size": [hap["Size"][0], hap["Size"][1], hap["Size"][2]],
             "strain": [hap["Mustrain"][0], hap["Mustrain"][1],
                        hap["Mustrain"][2]],
             "preferred_orientation": hap["Pref.Ori."]}
        )
    return {
        "tag": tag,
        "Rwp": rvals.get("Rwp", hist.get_wR()),
        "GOF": rvals.get("GOF"),
        "chi2": rvals.get("chisq"),
        "Nvars": rvals.get("Nvars"),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "frozen": project.get_Frozen(),
        "background": hist.data["Background"][0],
        "polarization": inst["Polariz."],
        "roughness_B": sample["SurfRoughB"],
        "instrument": {key: inst[key] for key in ["Zero", "U", "V", "W", "X", "SH/L"]},
        "terms": terms,
        "fractions": {key: {"value": value[0], "esd": value[1]}
                      for key, value in hist.ComputeMassFracs().items()},
    }


def run(tag: str) -> dict:
    output = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output))
    project.set_Controls("cycles", 12)
    configure(project, tag)
    project.save()
    for variable in [":0:U", ":0:W", ":0:X", ":0:SurfRoughB",
                     "0:0:Scale", "1:0:Scale", "2:0:Scale"]:
        project.set_Controls("parmMin", 0.0, variable)
    for variable in ["0:0:Size;i", "0:0:Size;a", "1:0:Size;i", "2:0:Size;i"]:
        project.set_Controls("parmMin", 0.005, variable)
        project.set_Controls("parmMax", 10.0, variable)
    for variable in ["1:0:Mustrain;i", "2:0:Mustrain;i"]:
        project.set_Controls("parmMin", 0.0, variable)
        project.set_Controls("parmMax", 20000.0, variable)
    project.set_Controls("parmMin", 0.0, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    project.set_Controls("parmMin", 0.2, "0:0:MD")
    project.set_Controls("parmMax", 5.0, "0:0:MD")
    replay = []
    for _ in range(4):
        project.do_refinements([{}])
        replay.append(project.data["Covariance"]["data"].get("Rvals", {}).copy())
    project.save()
    result = snapshot(project, tag)
    result["project"] = str(output.relative_to(HERE))
    result["replay"] = replay
    return result


def main() -> None:
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("none")
    cases = ["baseline_replay", "background_6", "background_10",
             "roughness_neutral", "polarization_fixed_0p7",
             "polarization_fixed_0p9", "texture_neutral",
             "cawo4_size_neutral", "cawo4_size_isotropic",
             "wo3_size", "wo3_strain"]
    results = []
    for tag in cases:
        print(f"running {tag}", flush=True)
        try:
            results.append(run(tag))
        except Exception as exc:
            results.append({"tag": tag, "error": repr(exc)})
    with (OUT / "summary.json").open("w") as stream:
        json.dump(results, stream, indent=2)
    for row in results:
        if "error" in row:
            print(row["tag"], "ERROR", row["error"])
        else:
            print(row["tag"], f"Rwp={row['Rwp']:.6f}",
                  f"GOF={row['GOF']:.5f}", f"max={row['max_shift_over_esd']}",
                  "frozen=", row["frozen"], "fractions=", row["fractions"])


if __name__ == "__main__":
    main()
