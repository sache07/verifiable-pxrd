#!/usr/bin/env python3
"""Replay an additional instrument parameter from an established baseline."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("parameters", nargs="+")
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.data["Controls"]["data"]["max cyc"] = 10
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": args.parameters})
    project.save()
    for _ in range(3):
        project.refine()
    project.save()
    inst = hist.data["Instrument Parameters"][0]
    print(
        "INSTRUMENT_RESULT",
        json.dumps(
            {
                "wR_percent": hist.get_wR(),
                "parameters": {
                    key: {"value": val[1], "refined": val[2]}
                    for key, val in inst.items()
                    if isinstance(val, list) and len(val) > 2
                },
                "fractions": hist.ComputeMassFracs(),
            },
            indent=2,
        ),
    )


if __name__ == "__main__":
    main()
