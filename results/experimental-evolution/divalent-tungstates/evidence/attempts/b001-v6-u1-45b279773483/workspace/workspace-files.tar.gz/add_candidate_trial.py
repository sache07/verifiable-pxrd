#!/usr/bin/env python3
"""Challenge a plausible weak phase under the accepted common profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/"
    "dara/cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def candidate_path(identifier: str) -> Path:
    """Accept either a COD identifier or a local prototype CIF path."""
    local = Path(identifier)
    return local if local.is_file() else cod_path(identifier)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("name")
    parser.add_argument("cod_id")
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.data["Controls"]["data"]["max cyc"] = 10
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    phase = project.add_phase(
        str(candidate_path(args.cod_id)), phasename=args.name, histograms=[hist]
    )
    phase.HAPvalue("Scale", 0.05)
    # Start from essentially no phase-specific broadening so a broad fixed
    # profile cannot manufacture support for an otherwise mismatched phase.
    phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
    phase.set_HAP_refinements({"Scale": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    phase.clear_refinements({"Cell": False})
    project.save()

    # Scale-first challenge under the current common nuisance model.
    for _ in range(2):
        project.refine()
    scale_only = float(phase.HAPvalue("Scale"))
    if scale_only > 1.0e-4:
        phase.set_refinements({"Cell": True})
        for _ in range(2):
            project.refine()
    project.save()

    try:
        fraction = hist.ComputeMassFracs().get(args.name)
    except Exception as exc:
        fraction = repr(exc)
    print(
        "CANDIDATE_RESULT",
        json.dumps(
            {
                "phase": args.name,
                "cod_id": args.cod_id,
                "wR_percent": hist.get_wR(),
                "scale_after_scale_only": scale_only,
                "scale_final": phase.HAPvalue("Scale"),
                "fraction": fraction,
                "cell": phase.get_cell(),
            },
            indent=2,
        ),
    )


if __name__ == "__main__":
    main()
