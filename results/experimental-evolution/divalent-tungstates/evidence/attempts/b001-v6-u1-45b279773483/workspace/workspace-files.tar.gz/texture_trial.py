#!/usr/bin/env python3
"""Challenge one March-Dollase axis on the accepted common baseline."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("phase")
    parser.add_argument("axis", nargs=3, type=int)
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.data["Controls"]["data"]["max cyc"] = 10
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    po = phase.getHAPvalues(hist)["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(args.axis)
    project.save()
    for _ in range(3):
        project.refine()
    project.save()
    print(
        "TEXTURE_RESULT",
        json.dumps(
            {
                "phase": args.phase,
                "axis": args.axis,
                "wR_percent": hist.get_wR(),
                "fraction": hist.ComputeMassFracs()[args.phase],
                "preferred_orientation": phase.getHAPvalues(hist)["Pref.Ori."],
            },
            indent=2,
        ),
    )


if __name__ == "__main__":
    main()
