#!/usr/bin/env python3
"""Replace one phase record and replay the same restrained nuisance model."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/"
    "dara/cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("phase_name")
    parser.add_argument("cod_id")
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.data["Controls"]["data"]["max cyc"] = 10
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    old = project.phase(args.phase_name)
    old_hap = copy.deepcopy(old.getHAPvalues(hist))
    old_scale = float(old_hap["Scale"][0])
    old_size = float(old_hap["Size"][1][0])

    del project.data["Phases"][args.phase_name]
    for row in project.names:
        if row and row[0] == "Phases":
            row.remove(args.phase_name)
            break
    hist.data["Reflection Lists"].pop(args.phase_name, None)

    phase = project.add_phase(
        str(cod_path(args.cod_id)),
        phasename=args.phase_name,
        histograms=[hist],
    )
    phase.HAPvalue("Scale", old_scale)
    phase.setSampleProfile(hist, "size", "isotropic", old_size, LGmix=1.0)
    phase.set_HAP_refinements(
        {
            "Scale": True,
            "Size": {"type": "isotropic", "refine": True},
        }
    )
    phase.set_refinements({"Cell": True})
    project.update_ids()
    project.save()
    for _ in range(4):
        project.refine()
    project.save()

    print(
        "REPLACEMENT_RESULT",
        json.dumps(
            {
                "phase": args.phase_name,
                "cod_id": args.cod_id,
                "wR_percent": hist.get_wR(),
                "fraction": hist.ComputeMassFracs().get(args.phase_name),
                "scale": phase.HAPvalue("Scale"),
                "cell": phase.get_cell(),
                "size": phase.getHAPvalues(hist)["Size"],
            },
            indent=2,
        ),
    )


if __name__ == "__main__":
    main()
