#!/usr/bin/env python3
"""Add massicot to the established inventory and rebuild common terms."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc


SOURCE = ".tmp/trial_plus_polariz.gpx"
OUTPUT = ".tmp/four_inventory.gpx"
CIF = (
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/2/31/04/2310433.cif"
)


def main() -> None:
    project = G2sc.G2Project(SOURCE, newgpx=OUTPUT)
    project.data["Controls"]["data"]["max cyc"] = 10
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)

    # Freeze the accepted profile while source/background/scale/zero/cells replay.
    hist.clear_refinements(
        {"Instrument Parameters": ["W", "SH/L", "Polariz."]}
    )
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})

    massicot = project.add_phase(CIF, phasename="PbO_massicot", histograms=[hist])
    massicot.HAPvalue("Scale", 0.5)
    massicot.set_HAP_refinements({"Scale": True})
    massicot.set_refinements({"Cell": True})
    massicot.setSampleProfile(hist, "size", "isotropic", 0.05, LGmix=1.0)
    massicot.clear_HAP_refinements({"Size": True, "Mustrain": True})

    project.save()
    for _ in range(4):
        project.refine()
    project.save()

    print(
        "INVENTORY_RESULT",
        json.dumps(
            {
                "wR_percent": hist.get_wR(),
                "fractions": hist.ComputeMassFracs(),
                "phases": {
                    phase.name: {
                        "scale": phase.HAPvalue("Scale"),
                        "cell": phase.get_cell(),
                        "size": phase.getHAPvalues(hist)["Size"][1][0],
                    }
                    for phase in project.phases()
                },
            },
            indent=2,
        ),
    )


if __name__ == "__main__":
    main()
