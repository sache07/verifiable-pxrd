#!/usr/bin/env python3
"""Replay Bragg-Brentano sample corrections from an established baseline."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("parameters", nargs="+")
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.data["Controls"]["data"]["max cyc"] = 10
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    sample = hist.data["Sample Parameters"]
    if "SurfRoughA" in args.parameters:
        sample["SurfRoughA"][0] = 0.1
    if "SurfRoughB" in args.parameters:
        sample["SurfRoughB"][0] = 0.1
    hist.set_refinements({"Sample Parameters": args.parameters})
    project.save()
    for _ in range(3):
        project.refine()
    project.save()
    print(
        "SAMPLE_RESULT",
        json.dumps(
            {
                "wR_percent": hist.get_wR(),
                "sample": {
                    key: value
                    for key, value in sample.items()
                    if key in args.parameters
                },
                "fractions": hist.ComputeMassFracs(),
            },
            indent=2,
        ),
    )


if __name__ == "__main__":
    main()
