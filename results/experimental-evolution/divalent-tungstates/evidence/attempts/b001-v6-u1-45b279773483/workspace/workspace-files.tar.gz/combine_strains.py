#!/usr/bin/env python3
"""Assemble the individually supported phase-width terms and replay them."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc


SOURCE = ".tmp/repl_wo3_2311041.gpx"
OUTPUT = ".tmp/combined_widths.gpx"


def refine_replay(project: G2sc.G2Project, count: int = 2) -> None:
    for _ in range(count):
        project.refine()


def main() -> None:
    project = G2sc.G2Project(SOURCE, newgpx=OUTPUT)
    project.data["Controls"]["data"]["max cyc"] = 10
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)

    # The polarization replay refined to 0.9967; use the physical endpoint.
    inst = hist.data["Instrument Parameters"][0]
    inst["Polariz."][1] = 1.0
    inst["Polariz."][2] = False

    wo3 = project.phase("WO3")
    wo3.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
    wo3.clear_HAP_refinements({"Size": True})
    wo3.setSampleProfile(hist, "microstrain", "isotropic", 3865.0, LGmix=1.0)
    wo3.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}
    )
    project.save()
    refine_replay(project)

    minium = project.phase("Pb3O4")
    minium.setSampleProfile(hist, "microstrain", "isotropic", 7600.0, LGmix=1.0)
    minium.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}
    )
    refine_replay(project)

    massicot = project.phase("PbO_massicot")
    massicot.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
    massicot.clear_HAP_refinements({"Size": True})
    massicot.setSampleProfile(hist, "microstrain", "isotropic", 13525.0, LGmix=1.0)
    massicot.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}
    )
    refine_replay(project, 3)
    project.save()

    print(
        "COMBINED_RESULT",
        json.dumps(
            {
                "wR_percent": hist.get_wR(),
                "fractions": hist.ComputeMassFracs(),
                "instrument": {
                    key: inst[key]
                    for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
                },
                "profiles": {
                    phase.name: {
                        "size": phase.getHAPvalues(hist)["Size"],
                        "mustrain": phase.getHAPvalues(hist)["Mustrain"],
                    }
                    for phase in project.phases()
                },
            },
            indent=2,
        ),
    )


if __name__ == "__main__":
    main()
