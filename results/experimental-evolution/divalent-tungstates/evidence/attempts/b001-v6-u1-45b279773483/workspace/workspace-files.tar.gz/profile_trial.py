#!/usr/bin/env python3
"""Replay profile/phase-width hypotheses from the common three-phase model."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--sizes", nargs="*", default=[])
    parser.add_argument("--strains", nargs="*", default=[])
    parser.add_argument("--profile", nargs="*", default=["W", "X"])
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.data["Controls"]["data"]["max cyc"] = 10
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]

    # Return to a nonnegative, low-dimensional common profile.
    starts = {"U": 0.0, "V": 0.0, "W": 10.0, "X": 0.0, "Y": 0.0, "Z": 0.0}
    for key, value in starts.items():
        inst[key][1] = value
        inst[key][2] = False
    for key in args.profile:
        inst[key][2] = True

    for phase in project.phases():
        phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})

    for name in args.sizes:
        phase = project.phase(name)
        phase.setSampleProfile(hist, "size", "isotropic", 0.05, LGmix=1.0)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}
        )

    for name in args.strains:
        phase = project.phase(name)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=1.0)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )

    project.save()
    for _ in range(4):
        project.refine()
    project.save()

    result = {
        "wR_percent": hist.get_wR(),
        "instrument": {key: inst[key][1] for key in starts},
        "fractions": hist.ComputeMassFracs(),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        result["phases"][phase.name] = {
            "scale": phase.HAPvalue("Scale"),
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    print("PROFILE_RESULT")
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
