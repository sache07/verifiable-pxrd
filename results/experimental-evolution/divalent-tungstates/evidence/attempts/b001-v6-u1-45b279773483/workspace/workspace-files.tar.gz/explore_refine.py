#!/usr/bin/env python3
"""Create and refine a compact GSAS-II trial model for candidate screening."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/"
    "dara/cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "phase",
        nargs="+",
        help="phase specification NAME=COD_ID",
    )
    parser.add_argument("--profile", action="store_true")
    args = parser.parse_args()

    specs: list[tuple[str, str]] = []
    for item in args.phase:
        name, cod_id = item.split("=", 1)
        specs.append((name, cod_id))

    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(args.output))
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5

    hist = project.add_powder_histogram("inputs/pattern.csv", "instrument.instprm")
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
            },
        }
    )
    hist.clear_refinements({"Sample Parameters": ["Scale"]})
    inst = hist.data["Instrument Parameters"][0]
    inst["Zero"][1] = 0.40
    # Keep the unused profile terms neutral during the inventory challenge.
    for key in ("V", "Y", "Z"):
        inst[key][1] = 0.0
        inst[key][2] = False
    inst["SH/L"][1] = 0.002
    inst["SH/L"][2] = False
    sample = hist.data["Sample Parameters"]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in sample:
            sample[key][0] = 0.0
            sample[key][1] = False

    phases = []
    for name, cod_id in specs:
        path = cod_path(cod_id)
        phase = project.add_phase(str(path), phasename=name, histograms=[hist])
        phase.HAPvalue("Scale", 0.1)
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})
        # Explicitly neutralize phase-specific broadening and texture.
        hap = phase.getHAPvalues(hist)
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0e6
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False
        phases.append(phase)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.save()

    # Repeated common-baseline passes make a candidate's scale comparable.
    for _ in range(3):
        project.refine()

    if args.profile:
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
        for _ in range(3):
            project.refine()

    project.save()
    result = {
        "gpx": str(args.output),
        "wR_percent": hist.get_wR(),
        "residuals": hist.data["data"][0],
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "phases": {},
    }
    try:
        result["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        result["mass_fraction_error"] = repr(exc)
    for phase in phases:
        result["phases"][phase.name] = {
            "scale": phase.HAPvalue("Scale"),
            "cell": phase.get_cell(),
            "size": phase.getHAPvalues(hist)["Size"],
            "mustrain": phase.getHAPvalues(hist)["Mustrain"],
        }
    print("TRIAL_RESULT")
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
