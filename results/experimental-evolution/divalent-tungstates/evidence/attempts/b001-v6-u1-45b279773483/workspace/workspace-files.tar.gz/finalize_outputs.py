#!/usr/bin/env python3
"""Replay the accepted GSAS-II model and export all final deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "combined_widths.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "PbWO4": {
        "name": "PbWO4 (scheelite-type/stolzite)",
        "formula": "PbWO4",
        "cif": "phase_PbWO4_scheelite.cif",
        "source": "COD 9009811",
    },
    "WO3": {
        "name": "WO3 (room-temperature monoclinic)",
        "formula": "WO3",
        "cif": "phase_WO3_monoclinic.cif",
        "source": "COD 2311041",
    },
    "Pb3O4": {
        "name": "Pb3O4 (minium)",
        "formula": "Pb3O4",
        "cif": "phase_Pb3O4_minium.cif",
        "source": "COD 9012124",
    },
    "PbO_massicot": {
        "name": "PbO (massicot)",
        "formula": "PbO",
        "cif": "phase_PbO_massicot.cif",
        "source": "COD 2310433",
    },
}
OUTPUT_ORDER = ["PbWO4", "WO3", "Pb3O4", "PbO_massicot"]


def load_and_replay(source: Path, destination: Path | None = None) -> G2sc.G2Project:
    if destination is None:
        project = G2sc.G2Project(str(source))
    else:
        project = G2sc.G2Project(str(source), newgpx=str(destination))
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 10
    controls["min dM/M"] = 1.0e-5
    project.save()
    project.refine()
    project.save()
    return project


def native(value):
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    return value


def main() -> None:
    # First replay writes a clean deliverable project; the second explicitly
    # checks replay stability after closing and reopening that exact file.
    load_and_replay(SOURCE, FINAL)
    load_and_replay(FINAL)
    project = G2sc.G2Project(str(FINAL))
    histogram = project.histogram(0)

    residuals = histogram.data["data"][0]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    fractions = histogram.ComputeMassFracs()
    by_name = {phase.name: phase for phase in project.phases()}

    phases = []
    for project_name in OUTPUT_ORDER:
        phase = by_name[project_name]
        info = PHASE_INFO[project_name]
        cif_path = ROOT / info["cif"]
        phase.export_CIF(str(cif_path))
        cell, cell_esd = phase.get_cell_and_esd()
        phase_id = phase.data["pId"]
        fraction, fraction_esd = fractions[project_name]
        phases.append(
            {
                "name": info["name"],
                "formula": info["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": info["cif"],
                "structure_source": info["source"],
                "weight_fraction": float(fraction),
                "weight_fraction_formal_esd": float(fraction_esd),
                "weight_percent": 100.0 * float(fraction),
                "cell": {key: float(native(value)) for key, value in cell.items()},
                "cell_formal_esd": {
                    key: float(native(value)) for key, value in cell_esd.items()
                },
                "bragg_R_F_percent": float(residuals[f"{phase_id}:0:Rf"]),
                "bragg_R_F2_percent": float(residuals[f"{phase_id}:0:Rf^2"]),
            }
        )

    arrays = np.asarray(histogram.data["data"][1], dtype=float)
    calculated = arrays[3]
    modeled = np.flatnonzero(calculated != 0.0)
    first, last = int(modeled[0]), int(modeled[-1]) + 1
    fit_path = ROOT / "fit.csv"
    with fit_path.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "background_counts",
                "difference_counts",
            ]
        )
        for x, obs, calc, background, difference in zip(
            arrays[0, first:last],
            arrays[1, first:last],
            arrays[3, first:last],
            arrays[4, first:last],
            arrays[5, first:last],
        ):
            writer.writerow(
                [
                    f"{x:.8f}",
                    f"{obs:.6f}",
                    f"{calc:.6f}",
                    f"{background:.6f}",
                    f"{difference:.6f}",
                ]
            )

    result = {
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over modeled crystalline phases",
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "R_expected_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "N_observations": int(rvals["Nobs"]),
            "N_variables": int(rvals["Nvars"]),
            "Durbin_Watson": float(residuals["Durbin-Watson"]),
            "converged": bool(rvals["converged"]),
            "SVD_zero_count": int(rvals["SVD0"]),
            "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
            "profile_start_two_theta_deg": float(arrays[0, first]),
            "profile_end_two_theta_deg": float(arrays[0, last - 1]),
            "profile_point_count": int(last - first),
        },
    }
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
