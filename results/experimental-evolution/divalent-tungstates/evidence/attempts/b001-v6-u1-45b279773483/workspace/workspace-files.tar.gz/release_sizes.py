#!/usr/bin/env python3
"""Release selected existing phase-size terms without resetting their values."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("phases", nargs="+")
    parser.add_argument("--profile-w", action="store_true")
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.data["Controls"]["data"]["max cyc"] = 10
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    for name in args.phases:
        project.phase(name).set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}
        )
    if args.profile_w:
        hist.set_refinements({"Instrument Parameters": ["W"]})
    project.save()
    for _ in range(3):
        project.refine()
    project.save()
    print(
        "WIDTH_RESULT",
        json.dumps(
            {
                "wR_percent": hist.get_wR(),
                "W": hist.data["Instrument Parameters"][0]["W"],
                "fractions": hist.ComputeMassFracs(),
                "sizes": {
                    phase.name: phase.getHAPvalues(hist)["Size"]
                    for phase in project.phases()
                },
            },
            indent=2,
        ),
    )


if __name__ == "__main__":
    main()
