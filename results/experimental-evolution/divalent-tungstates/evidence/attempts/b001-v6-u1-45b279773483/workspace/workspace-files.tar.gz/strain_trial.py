#!/usr/bin/env python3
"""Challenge one phase with isotropic microstrain on the accepted baseline."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("phase")
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.data["Controls"]["data"]["max cyc"] = 10
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 500.0, LGmix=1.0)
    phase.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}
    )
    project.save()
    for _ in range(3):
        project.refine()
    project.save()
    print(
        "STRAIN_RESULT",
        json.dumps(
            {
                "phase": args.phase,
                "wR_percent": hist.get_wR(),
                "fraction": hist.ComputeMassFracs()[args.phase],
                "size": phase.getHAPvalues(hist)["Size"],
                "mustrain": phase.getHAPvalues(hist)["Mustrain"],
            },
            indent=2,
        ),
    )


if __name__ == "__main__":
    main()
