#!/usr/bin/env python3
"""Residual-led profile trials from the neutral three-phase baseline."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "three_phase.gpx"


def result(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    row = {
        "label": label,
        "gpx": project.filename,
        "Rwp": hist.residuals["wR"],
        "Rexp": hist.residuals["wRmin"],
        "fractions": hist.ComputeMassFracs(),
        "profile": {
            key: hist.data["Instrument Parameters"][0][key][1:]
            for key in ("U", "W", "X", "SH/L")
        },
        "HAP": {
            phase.name: {
                "Size": phase.data["Histograms"][hist.name]["Size"],
                "Mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in project.phases()
        },
        "vary": [str(item) for item in (project.get_VaryList() or [])],
    }
    print("RESULT " + json.dumps(row, default=float))
    return row


def trial_hap(phase_index: int, term: str) -> dict:
    label = f"{term.lower()}_{phase_index}_{['NiWO4','WO3','NiO'][phase_index]}"
    out = ROOT / ".tmp" / f"trial_{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    phase = project.phase(phase_index)
    hist = project.histogram(0)
    if term == "Size":
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": 1.0,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            },
            [hist],
        )
        variable = f"{phase_index}:0:Size;i"
        project.set_Controls("parmMin", 0.01, variable)
        project.set_Controls("parmMax", 1000.0, variable)
    else:
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 500.0
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            },
            [hist],
        )
        variable = f"{phase_index}:0:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable)
        project.set_Controls("parmMax", 10000.0, variable)
    project.refine()
    project.save()
    replay = G2sc.G2Project(str(out))
    replay.refine()
    replay.save()
    return result(replay, label)


def trial_shl() -> dict:
    label = "shl"
    out = ROOT / ".tmp" / "trial_shl.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["SH/L"][1] = 0.01
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    project.set_Controls("parmMin", 0.0005, ":0:SH/L")
    project.set_Controls("parmMax", 0.2, ":0:SH/L")
    project.refine()
    project.save()
    replay = G2sc.G2Project(str(out))
    replay.refine()
    replay.save()
    return result(replay, label)


def main() -> None:
    G2sc.SetPrintLevel("none")
    base = G2sc.G2Project(str(BASE))
    rows = [result(base, "baseline")]
    rows.append(trial_shl())
    for phase_index in range(3):
        rows.append(trial_hap(phase_index, "Size"))
        rows.append(trial_hap(phase_index, "Mustrain"))
    print("SUMMARY")
    for row in sorted(rows, key=lambda item: item["Rwp"]):
        print(row["label"], f"Rwp={row['Rwp']:.6f}")


if __name__ == "__main__":
    main()
