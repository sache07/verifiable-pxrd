#!/usr/bin/env python3
"""Structural and asymmetry challenges from the accepted common profile."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "trial_polarization.gpx"


def summarize(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    sig = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    wo3 = project.phase(1)
    row = {
        "label": label,
        "Rwp": hist.residuals["wR"],
        "Rexp": hist.residuals["wRmin"],
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "fractions": hist.ComputeMassFracs(),
        "SH/L": hist.data["Instrument Parameters"][0]["SH/L"][1],
        "WO3_atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "xyz": atom.coordinates,
                "uiso": atom.uiso,
                "flags": atom.refinement_flags,
                "uiso_esd": sig.get(f"1::AUiso:{index}"),
            }
            for index, atom in enumerate(wo3.atoms())
        ],
        "vary": [str(item) for item in (project.get_VaryList() or [])],
        "message": cov.get("Rvals", {}).get("msg", ""),
    }
    print("RESULT " + json.dumps(row, default=float))
    return row


def finish(project: G2sc.G2Project, out: Path, label: str) -> dict:
    project.refine()
    project.save()
    replay = G2sc.G2Project(str(out))
    replay.refine()
    replay.save()
    return summarize(replay, label)


def no_shl() -> dict:
    label = "no_shl"
    out = ROOT / ".tmp" / f"trial_{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["SH/L"]})
    hist.data["Instrument Parameters"][0]["SH/L"][1] = 0.002
    return finish(project, out, label)


def wo3_trial(
    label: str,
    w_uiso: float | None = None,
    o_uiso: float | None = None,
    flags: str = "",
) -> dict:
    out = ROOT / ".tmp" / f"trial_{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    wo3 = project.phase(1)
    for atom in wo3.atoms():
        if atom.element == "W" and w_uiso is not None:
            atom.uiso = w_uiso
        elif atom.element == "O" and o_uiso is not None:
            atom.uiso = o_uiso
    if flags:
        wo3.set_refinements({"Atoms": {"W1": flags, "W2": flags}})
    if "U" in flags:
        for index, atom in enumerate(wo3.atoms()):
            if atom.element != "W":
                continue
            variable = f"1::AUiso:{index}"
            project.set_Controls("parmMin", 0.0001, variable)
            project.set_Controls("parmMax", 0.05, variable)
    return finish(project, out, label)


def wo3_selective_coordinates(label: str, coordinate_atom: str) -> dict:
    out = ROOT / ".tmp" / f"trial_{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    wo3 = project.phase(1)
    for atom in wo3.atoms():
        atom.uiso = 0.003 if atom.element == "W" else 0.008
    wo3.set_refinements(
        {
            "Atoms": {
                "W1": "XU" if coordinate_atom == "W1" else "U",
                "W2": "XU" if coordinate_atom == "W2" else "U",
            }
        }
    )
    for index, atom in enumerate(wo3.atoms()):
        if atom.element != "W":
            continue
        variable = f"1::AUiso:{index}"
        project.set_Controls("parmMin", 0.0001, variable)
        project.set_Controls("parmMax", 0.05, variable)
    return finish(project, out, label)


def main() -> None:
    G2sc.SetPrintLevel("none")
    rows = [summarize(G2sc.G2Project(str(BASE)), "baseline")]
    rows.extend(
        [
            no_shl(),
            wo3_trial("wo3_w_coordinates", flags="X"),
            wo3_trial("wo3_fixed_small_adp", 0.002, 0.005),
            wo3_trial("wo3_w_adp", 0.003, 0.008, "U"),
            wo3_trial("wo3_w_coordinates_adp", 0.003, 0.008, "XU"),
            wo3_selective_coordinates("wo3_w1_coordinates_adp", "W1"),
            wo3_selective_coordinates("wo3_w2_coordinates_adp", "W2"),
        ]
    )
    print("SUMMARY")
    for row in sorted(rows, key=lambda item: item["Rwp"]):
        print(row["label"], f"Rwp={row['Rwp']:.6f}")


if __name__ == "__main__":
    main()
