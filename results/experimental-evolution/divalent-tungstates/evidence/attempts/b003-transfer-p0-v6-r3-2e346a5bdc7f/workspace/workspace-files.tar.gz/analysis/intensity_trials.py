#!/usr/bin/env python3
"""Challenge global intensity corrections before testing preferred orientation."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "trial_shl.gpx"


def summarize(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    sig = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    sample = hist.data["Sample Parameters"]
    inst = hist.data["Instrument Parameters"][0]
    row = {
        "label": label,
        "gpx": project.filename,
        "Rwp": hist.residuals["wR"],
        "Rexp": hist.residuals["wRmin"],
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "fractions": hist.ComputeMassFracs(),
        "background": hist.data["Background"][0],
        "polarization": [inst["Polariz."][1], sig.get(":0:Polariz.")],
        "roughness": {
            "A": [sample["SurfRoughA"][0], sig.get(":0:SurfRoughA")],
            "B": [sample["SurfRoughB"][0], sig.get(":0:SurfRoughB")],
        },
        "vary": [str(item) for item in (project.get_VaryList() or [])],
        "message": cov.get("Rvals", {}).get("msg", ""),
    }
    print("RESULT " + json.dumps(row, default=float))
    return row


def replay(out: Path, label: str) -> dict:
    project = G2sc.G2Project(str(out))
    project.refine()
    project.save()
    return summarize(project, label)


def background_trial(ncoeff: int, base: Path = BASE, suffix: str = "") -> dict:
    label = f"background_{ncoeff}{suffix}"
    out = ROOT / ".tmp" / f"trial_{label}.gpx"
    project = G2sc.G2Project(str(base), newgpx=str(out))
    project.histogram(0).set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": ncoeff}}
    )
    project.refine()
    project.save()
    return replay(out, label)


def polarization_trial() -> dict:
    label = "polarization"
    out = ROOT / ".tmp" / f"trial_{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Controls("parmMin", 0.0, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    project.refine()
    project.save()
    return replay(out, label)


def roughness_trial(base: Path = BASE, suffix: str = "") -> dict:
    label = f"roughness{suffix}"
    out = ROOT / ".tmp" / f"trial_{label}.gpx"
    project = G2sc.G2Project(str(base), newgpx=str(out))
    hist = project.histogram(0)
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"][0] = 0.5
    sample["SurfRoughB"][0] = 0.05
    hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    for term in ("SurfRoughA", "SurfRoughB"):
        project.set_Controls("parmMin", 0.0, f":0:{term}")
        project.set_Controls("parmMax", 1.0, f":0:{term}")
    project.refine()
    project.save()
    return replay(out, label)


def main() -> None:
    G2sc.SetPrintLevel("none")
    rows = [summarize(G2sc.G2Project(str(BASE)), "baseline")]
    rows.extend(
        [
            background_trial(4),
            background_trial(8),
            polarization_trial(),
            roughness_trial(),
            background_trial(
                8, ROOT / ".tmp" / "trial_polarization.gpx", "_after_polarization"
            ),
            roughness_trial(
                ROOT / ".tmp" / "trial_polarization.gpx", "_after_polarization"
            ),
        ]
    )
    print("SUMMARY")
    for row in sorted(rows, key=lambda item: item["Rwp"]):
        print(
            row["label"],
            f"Rwp={row['Rwp']:.6f}",
            f"polarization={row['polarization'][0]:.6f}",
            f"roughness=({row['roughness']['A'][0]:.6f}, {row['roughness']['B'][0]:.6f})",
        )


if __name__ == "__main__":
    main()
