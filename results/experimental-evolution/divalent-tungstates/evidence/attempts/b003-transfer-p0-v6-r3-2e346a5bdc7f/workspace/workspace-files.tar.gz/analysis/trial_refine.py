#!/usr/bin/env python3
"""Build and stage a minimal NiWO4 GSAS-II refinement."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def show(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    hap = phase.data["Histograms"][hist.name]
    payload = {
        "label": label,
        "residuals": hist.residuals,
        "cell": phase.get_cell(),
        "profile": {key: inst[key][1:] for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L")},
        "background": hist.data["Background"][0],
        "sample_scale": hist.data["Sample Parameters"]["Scale"],
        "phase_scale": hap["Scale"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "vary": [str(item) for item in (project.get_VaryList() or [])],
    }
    print("STAGE " + json.dumps(payload, default=float))


def main() -> None:
    out = ROOT / ".tmp" / "trial.gpx"
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(ROOT / ".tmp" / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
        fmthint="xye",
    )
    phase = project.add_phase(
        str(ROOT / "candidates" / "NiWO4_start.cif"),
        phasename="NiWO4",
        histograms=[hist],
        fmthint="CIF",
    )

    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
    # Keep one overall scale: phase scale varies; sample scale stays at unity.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [3300.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": True,
            },
        }
    )
    phase.set_HAP_refinements({"Scale": True}, [hist])
    project.save()
    project.refine()
    show(project, "background_scale")

    # One angular correction plus cell.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    phase.set_refinements({"Cell": True})
    project.refine()
    show(project, "zero_cell")

    # Common nonnegative low-dimensional profile. V and Y remain neutral/fixed.
    for variable, lower, upper in (
        (":0:U", 0.0, 1000.0),
        (":0:W", 0.0, 1000.0),
        (":0:X", 0.0, 100.0),
    ):
        project.set_Controls("parmMin", lower, variable)
        project.set_Controls("parmMax", upper, variable)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.refine()
    show(project, "common_profile")

    # Replay from disk as a reproducibility check.
    project.save()
    replay = G2sc.G2Project(str(out))
    replay.refine()
    replay.save()
    show(replay, "replay")


if __name__ == "__main__":
    main()
