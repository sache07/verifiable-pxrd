#!/usr/bin/env python3
"""Create the exact final project and all machine-readable deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "common_final_pruned.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = (
    {
        "name": "NiWO4",
        "formula": "NiWO4",
        "cif_path": "phase_NiWO4.cif",
        "space_group_number": 13,
        "structure_type": "wolframite",
    },
    {
        "name": "WO3",
        "formula": "WO3",
        "cif_path": "phase_WO3.cif",
        "space_group_number": 14,
        "structure_type": "monoclinic gamma-WO3",
    },
    {
        "name": "NiO",
        "formula": "NiO",
        "cif_path": "phase_NiO.cif",
        "space_group_number": 225,
        "structure_type": "rocksalt",
    },
)


def neutralize_rejected_terms(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    sample = hist.data["Sample Parameters"]
    for key in ("SurfRoughA", "SurfRoughB", "Shift", "Transparency"):
        sample[key] = [0.0, False]
    for index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 1000.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]
        if index < 2:
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
        else:
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [1, 1, 1]


def make_final_project() -> list[dict]:
    G2sc.SetPrintLevel("none")
    project = G2sc.G2Project(str(BASE), newgpx=str(FINAL))
    hist = project.histogram(0)
    x = hist.data["data"][1][0]
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]
    neutralize_rejected_terms(project)
    project.set_Controls("cycles", 24)
    history = []
    for iteration in range(3):
        project.refine()
        project.save()
        rvals = project.data["Covariance"]["data"]["Rvals"]
        history.append(
            {
                "iteration": iteration + 1,
                "Rwp": project.histogram(0).residuals["wR"],
                "max_shift_over_esd": rvals.get("Max shft/sig"),
                "converged": rvals.get("converged"),
            }
        )
        project = G2sc.G2Project(str(FINAL))
    # One final full-range replay is the project used for every export below.
    project.refine()
    project.save()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    history.append(
        {
            "iteration": 4,
            "Rwp": project.histogram(0).residuals["wR"],
            "max_shift_over_esd": rvals.get("Max shft/sig"),
            "converged": rvals.get("converged"),
        }
    )
    return history


def export_outputs(replay_history: list[dict]) -> None:
    # Reopen after the final save so CIF, fractions and profile all originate
    # from the serialized project submitted as final.gpx.
    project = G2sc.G2Project(str(FINAL))
    hist = project.histogram(0)
    for phase, info in zip(project.phases(), PHASE_INFO):
        phase.export_CIF(str(ROOT / info["cif_path"]))

    x, observed, weights, calculated, background = hist.data["data"][1][:5]
    difference = observed - calculated
    if not np.allclose(difference, hist.data["data"][1][5], rtol=0.0, atol=1e-7):
        raise RuntimeError("Stored GSAS-II residual is inconsistent with observed-calculated")
    with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_intensity",
                "background_intensity",
            ]
        )
        writer.writerows(zip(x, observed, calculated, difference, background))

    mass = hist.ComputeMassFracs()
    total = sum(value for value, _ in mass.values())
    phases = []
    for phase, info in zip(project.phases(), PHASE_INFO):
        value, esd = mass[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        phases.append(
            {
                **info,
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": info["cif_path"],
                "weight_fraction": value / total,
                "weight_fraction_esd_statistical": esd,
                "weight_percent": 100.0 * value / total,
                "unit_cell": cell,
                "unit_cell_esd": cell_esd,
            }
        )

    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    result = {
        "input_pattern": "inputs/pattern.csv",
        "metadata": "inputs/metadata.json",
        "final_project_path": "final.gpx",
        "weight_fraction_basis": (
            "Normalized over the three modeled crystalline phases; amorphous or "
            "unidentified material is not quantified."
        ),
        "uncertainty_note": (
            "Listed esds are counting-statistical values from Poisson weights. "
            "Model/source/profile systematics are larger; see report.md."
        ),
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": hist.residuals["wR"],
            "Rp_percent": hist.residuals["R"],
            "Rexp_percent": hist.residuals["wRmin"],
            "GOF": rvals["GOF"],
            "reduced_chi_squared": rvals["GOF"] ** 2,
            "Bragg_R_percent": hist.residuals["Rb"],
            "weighted_Bragg_R_percent": hist.residuals["wRb"],
            "n_observations": rvals["Nobs"],
            "n_refined_parameters": rvals["Nvars"],
            "weighting": "sigma(I)=sqrt(max(I,1)) because pointwise uncertainties were not supplied",
            "two_theta_range_deg": [float(x[0]), float(x[-1])],
        },
        "replay_history": replay_history,
    }
    with (ROOT / "result.json").open("w", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")


def main() -> None:
    history = make_final_project()
    export_outputs(history)
    print(json.dumps(history, indent=2))


if __name__ == "__main__":
    main()
