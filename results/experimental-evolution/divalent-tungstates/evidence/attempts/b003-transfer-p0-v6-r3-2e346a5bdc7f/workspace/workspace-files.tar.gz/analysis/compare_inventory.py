#!/usr/bin/env python3
"""Compare reversible WO3 inventory candidates under one nuisance model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
WO3_CANDIDATES = {
    "1528915": ROOT / "candidates" / "WO3_1528915.cif",
    "2311041": ROOT / "candidates" / "WO3_2311041.cif",
    "2106293": ROOT / "candidates" / "WO3_2106293.cif",
}


def build(cod_id: str, cif: Path) -> dict:
    out = ROOT / ".tmp" / f"inventory_{cod_id}.gpx"
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(ROOT / ".tmp" / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
        fmthint="xye",
    )
    niwo4 = project.add_phase(
        str(ROOT / "candidates" / "NiWO4_start.cif"),
        phasename="NiWO4",
        histograms=[hist],
        fmthint="CIF",
    )
    wo3 = project.add_phase(
        str(cif),
        phasename=f"WO3_{cod_id}",
        histograms=[hist],
        fmthint="CIF",
    )

    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][0] = inst["U"][1] = 0.0
    inst["W"][0] = inst["W"][1] = 31.0
    inst["X"][0] = inst["X"][1] = 3.0
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [3300.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": True,
            },
        }
    )
    for phase in (niwo4, wo3):
        phase.set_HAP_refinements({"Scale": True}, [hist])
    project.save()
    project.refine()

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in (niwo4, wo3):
        phase.set_refinements({"Cell": True})
    project.refine()

    for variable, upper in ((":0:W", 1000.0), (":0:X", 100.0)):
        project.set_Controls("parmMin", 0.0, variable)
        project.set_Controls("parmMax", upper, variable)
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    project.refine()
    project.save()

    replay = G2sc.G2Project(str(out))
    replay.refine()
    replay.save()
    hist = replay.histogram(0)
    phases = replay.phases()
    result = {
        "cod_id": cod_id,
        "gpx": str(out),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "phase_scales": {
            phase.name: phase.data["Histograms"][hist.name]["Scale"] for phase in phases
        },
        "profile": {
            key: hist.data["Instrument Parameters"][0][key][1:]
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L")
        },
        "background": hist.data["Background"][0],
    }
    print("RESULT " + json.dumps(result, default=float))
    return result


def main() -> None:
    results = [build(cod_id, cif) for cod_id, cif in WO3_CANDIDATES.items()]
    print("SUMMARY")
    for result in sorted(results, key=lambda row: row["residuals"]["wR"]):
        print(
            result["cod_id"],
            f"Rwp={result['residuals']['wR']:.5f}",
            f"GOF={result['residuals']['wR'] / result['residuals']['wRmin']:.5f}",
            result["mass_fractions"],
        )


if __name__ == "__main__":
    main()
