#!/usr/bin/env python3
"""Replay-stable one-phase-at-a-time size and strain challenges."""

from __future__ import annotations

import concurrent.futures
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "common_final_pruned.gpx"


def run_one(spec: tuple[int, str]) -> dict:
    from GSASII import GSASIIscriptable as G2sc

    G2sc.SetPrintLevel("none")
    phase_index, term = spec
    phase_name = ("NiWO4", "WO3", "NiO")[phase_index]
    label = f"final_{term.lower()}_{phase_name}"
    out = ROOT / ".tmp" / f"trial_{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    phase = project.phase(phase_index)
    hist = project.histogram(0)
    if term == "Size":
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": 1.0,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            },
            [hist],
        )
        variable = f"{phase_index}:0:Size;i"
        project.set_Controls("parmMin", 0.01, variable)
        project.set_Controls("parmMax", 10.0, variable)
    else:
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 500.0
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            },
            [hist],
        )
        variable = f"{phase_index}:0:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable)
        project.set_Controls("parmMax", 10000.0, variable)
    project.refine()
    project.save()
    replay = G2sc.G2Project(str(out))
    replay.refine()
    replay.save()
    hist = replay.histogram(0)
    hap = replay.phase(phase_index).data["Histograms"][hist.name]
    cov = replay.data.get("Covariance", {}).get("data", {})
    sig = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    return {
        "label": label,
        "Rwp": hist.residuals["wR"],
        "value": hap[term][1][0],
        "esd": sig.get(variable),
        "flags": hap[term][2],
        "message": cov.get("Rvals", {}).get("msg", ""),
    }


def main() -> None:
    specs = [(phase_index, term) for phase_index in range(3) for term in ("Size", "Mustrain")]
    with concurrent.futures.ProcessPoolExecutor(max_workers=3) as executor:
        rows = list(executor.map(run_one, specs))
    for row in sorted(rows, key=lambda item: item["Rwp"]):
        print(
            row["label"],
            f"Rwp={row['Rwp']:.6f}",
            f"value={row['value']:.6f}",
            f"esd={row['esd']}",
            f"flags={row['flags']}",
        )


if __name__ == "__main__":
    main()
