#!/usr/bin/env python3
"""Build the coherent three-phase inventory with a common baseline profile."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    out = ROOT / ".tmp" / "three_phase.gpx"
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(ROOT / ".tmp" / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
        fmthint="xye",
    )
    phases = [
        project.add_phase(
            str(ROOT / "candidates" / "NiWO4_start.cif"),
            phasename="NiWO4",
            histograms=[hist],
            fmthint="CIF",
        ),
        project.add_phase(
            str(ROOT / "candidates" / "WO3_2311041.cif"),
            phasename="WO3",
            histograms=[hist],
            fmthint="CIF",
        ),
        project.add_phase(
            str(ROOT / "candidates" / "NiO_1010093.cif"),
            phasename="NiO",
            histograms=[hist],
            fmthint="CIF",
        ),
    ]

    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for key, value in (("U", 10.0), ("W", 40.0), ("X", 2.0)):
        inst[key][0] = inst[key][1] = value
        inst[key][2] = False
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [3100.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": True,
            },
        }
    )
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        # GSAS-II defaults are not neutral even when flags are off.
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [1000.0, 1000.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        phase.set_HAP_refinements({"Scale": True}, [hist])
    project.save()
    project.refine()

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.refine()

    for variable, upper in ((":0:U", 1000.0), (":0:W", 1000.0), (":0:X", 100.0)):
        project.set_Controls("parmMin", 0.0, variable)
        project.set_Controls("parmMax", upper, variable)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.refine()
    project.save()

    replay = G2sc.G2Project(str(out))
    replay.refine()
    replay.save()
    hist = replay.histogram(0)
    payload = {
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell() for phase in replay.phases()},
        "scales": {
            phase.name: phase.data["Histograms"][hist.name]["Scale"]
            for phase in replay.phases()
        },
        "profile": {
            key: hist.data["Instrument Parameters"][0][key][1:]
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L")
        },
        "background": hist.data["Background"][0],
    }
    print("RESULT " + json.dumps(payload, default=float))


if __name__ == "__main__":
    main()
