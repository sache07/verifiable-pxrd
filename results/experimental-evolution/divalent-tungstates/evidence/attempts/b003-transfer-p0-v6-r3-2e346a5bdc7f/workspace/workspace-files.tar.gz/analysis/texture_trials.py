#!/usr/bin/env python3
"""Compare symmetry-distinct March-Dollase axes one phase at a time."""

from __future__ import annotations

import concurrent.futures
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "trial_wo3_w_coordinates_adp.gpx"
TRIALS = {
    0: ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 0, 1), (1, 1, 0), (1, 1, 1)),
    1: ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 0, 1), (1, 1, 0), (1, 1, 1)),
    2: ((1, 0, 0), (1, 1, 0), (1, 1, 1)),
}


def run_one(spec: tuple[int, tuple[int, int, int]]) -> dict:
    from GSASII import GSASIIscriptable as G2sc

    G2sc.SetPrintLevel("none")
    phase_index, axis = spec
    phase_name = ("NiWO4", "WO3", "NiO")[phase_index]
    axis_text = "".join(str(item) for item in axis)
    label = f"texture_{phase_name}_{axis_text}"
    out = ROOT / ".tmp" / f"trial_{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    # Cubic symmetry can give a zero MD derivative exactly at random
    # orientation, so use a tiny reversible offset for that challenge.
    pref[1] = 0.98 if phase_index == 2 else 1.0
    pref[2] = True
    pref[3] = list(axis)
    variable = f"{phase_index}:0:MD"
    project.set_Controls("parmMin", 0.2, variable)
    project.set_Controls("parmMax", 5.0, variable)
    project.refine()
    project.save()
    replay = G2sc.G2Project(str(out))
    replay.refine()
    replay.save()
    hist = replay.histogram(0)
    pref = replay.phase(phase_index).data["Histograms"][hist.name]["Pref.Ori."]
    cov = replay.data.get("Covariance", {}).get("data", {})
    sig = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    return {
        "label": label,
        "phase": phase_name,
        "phase_index": phase_index,
        "axis": axis,
        "Rwp": hist.residuals["wR"],
        "MD": pref[1],
        "MD_esd": sig.get(variable),
        "fractions": hist.ComputeMassFracs(),
        "message": cov.get("Rvals", {}).get("msg", ""),
    }


def main() -> None:
    specs = [(phase_index, axis) for phase_index, axes in TRIALS.items() for axis in axes]
    with concurrent.futures.ProcessPoolExecutor(max_workers=3) as executor:
        rows = list(executor.map(run_one, specs))
    out = ROOT / ".tmp" / "texture_trials.json"
    out.write_text(json.dumps(rows, indent=2), encoding="utf-8")
    for row in sorted(rows, key=lambda item: item["Rwp"]):
        print(
            row["label"],
            f"Rwp={row['Rwp']:.6f}",
            f"MD={row['MD']:.6f}",
            f"esd={row['MD_esd']}",
        )


if __name__ == "__main__":
    main()
