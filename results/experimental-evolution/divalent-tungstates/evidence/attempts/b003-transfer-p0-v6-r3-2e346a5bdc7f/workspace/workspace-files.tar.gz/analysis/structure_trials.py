#!/usr/bin/env python3
"""Test structural degrees of freedom without changing the phase inventory."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "three_phase.gpx"


def run(label: str, atom_flags: dict[int, dict[str, str]], nominal_adps: bool = False) -> dict:
    out = ROOT / ".tmp" / f"struct_{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    if nominal_adps:
        wo3 = project.phase(1)
        for atom in wo3.atoms():
            atom.uiso = 0.005 if atom.element == "W" else 0.008
    for phase_index, flags in atom_flags.items():
        project.phase(phase_index).set_refinements({"Atoms": flags})
    project.refine()
    project.save()
    replay = G2sc.G2Project(str(out))
    replay.refine()
    replay.save()
    hist = replay.histogram(0)
    row = {
        "label": label,
        "gpx": str(out),
        "Rwp": hist.residuals["wR"],
        "Rexp": hist.residuals["wRmin"],
        "Rf": {
            phase.name: hist.residuals[f"{phase.id}:0:Rf"] for phase in replay.phases()
        },
        "fractions": hist.ComputeMassFracs(),
        "atoms": {
            phase.name: [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": atom.coordinates,
                    "uiso": atom.uiso,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ]
            for phase in replay.phases()
        },
        "vary": [str(item) for item in (replay.get_VaryList() or [])],
    }
    print("RESULT " + json.dumps(row, default=float))
    return row


def main() -> None:
    G2sc.SetPrintLevel("none")
    rows = []
    rows.append(run("niwo4_metals", {0: {"Ni1": "X", "W1": "X"}}))
    rows.append(run("niwo4_all", {0: {"all": "X"}}))
    rows.append(run("wo3_metals", {1: {"W1": "X", "W2": "X"}}, nominal_adps=True))
    rows.append(run("wo3_all", {1: {"all": "X"}}, nominal_adps=True))
    rows.append(
        run(
            "niwo4_all_wo3_metals",
            {0: {"all": "X"}, 1: {"W1": "X", "W2": "X"}},
            nominal_adps=True,
        )
    )
    print("SUMMARY")
    for row in sorted(rows, key=lambda item: item["Rwp"]):
        print(row["label"], f"Rwp={row['Rwp']:.6f}", row["Rf"])


if __name__ == "__main__":
    main()
