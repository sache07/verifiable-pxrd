#!/usr/bin/env python3
"""Test one isotropic phase-broadening term on a converged project."""

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", default="trial_texture_wo3_srwo4_110.gpx")
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--kind", choices=("size", "strain"), required=True)
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(args.base, newgpx=args.output)
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    if args.kind == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2][0] = True
        variable = f"{phase.id}:0:Size;i"
        project.set_Controls("parmMin", 0.05, variable=variable)
        project.set_Controls("parmMax", 10.0, variable=variable)
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 100.0
        hap["Mustrain"][2][0] = True
        variable = f"{phase.id}:0:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 5000.0, variable=variable)
    project.set_Frozen(mode="remove")
    project.set_Controls("cycles", 12)
    project.refine()
    project.refine()
    project.save()
    print(
        json.dumps(
            {
                "output": args.output,
                "phase": phase.name,
                "kind": args.kind,
                "Rwp": project.data["Covariance"]["data"]["Rvals"]["Rwp"],
                "GOF": project.data["Covariance"]["data"]["Rvals"]["GOF"],
                "max_shift_over_sigma": project.data["Covariance"]["data"]["Rvals"].get(
                    "Max shft/sig"
                ),
                "Size": hap["Size"],
                "Mustrain": hap["Mustrain"],
                "mass_fractions": hist.ComputeMassFracs(),
                "frozen": project.get_Frozen(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
