#!/usr/bin/env python3
"""Prepare GSAS-II input and chemically adapted SrWO4 trial structures."""

from pathlib import Path

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path("<RUN>/resources/b001-c03/cif")


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_adapted_scheelite(parent_id: str, substitution: dict[str, str], output: Path,
                            target_lattice: Lattice | None = None) -> None:
    parent = Structure.from_file(cod_path(parent_id), primitive=False)
    parent.replace_species(substitution)
    if target_lattice is not None:
        parent = Structure(
            target_lattice,
            parent.species,
            parent.frac_coords,
            site_properties=parent.site_properties,
        )
    CifWriter(parent, symprec=0.01, refine_struct=False).write_file(output)


def main() -> None:
    data = np.genfromtxt("inputs/pattern.csv", delimiter=",", names=True)
    x = data["two_theta_deg"]
    y = data["intensity"]
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(
        "pattern.xye",
        np.column_stack([x, y, sigma]),
        fmt=("%.8f", "%.8f", "%.8f"),
        header="two_theta_deg intensity sigma_poisson",
    )

    Path("instrument.instprm").write_text(
        "#GSAS-II instrument parameter file for supplied Cu Ka reflection data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:20.0;V:0.0;W:45.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )

    srmoo4 = Structure.from_file(cod_path("2300460"), primitive=False)
    write_adapted_scheelite(
        "2300460", {"Mo": "W"}, Path("candidate_srwo4_from_srmoo4.cif")
    )
    write_adapted_scheelite(
        "7219229",
        {"Ca": "Sr"},
        Path("candidate_srwo4_from_cawo4.cif"),
        target_lattice=srmoo4.lattice,
    )
    write_adapted_scheelite(
        "1561850", {"Eu": "Sr"}, Path("candidate_srwo4_from_euwo4.cif")
    )


if __name__ == "__main__":
    main()
