#!/usr/bin/env python3
"""Run a conservative, common-profile GSAS-II trial refinement."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<RUN>/resources/b001-c03/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def reset_hap(phase, hist_name: str, initial_scale: float) -> None:
    """Remove the non-neutral GSAS-II sample-broadening defaults."""
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"] = [float(initial_scale), True]
    hap["Size"] = [
        "isotropic",
        [1000.0, 1000.0, 1.0],
        [False, False, False],
        [0, 0, 1],
        [1000.0, 1000.0, 1000.0, 0.0, 0.0, 0.0],
        [False, False, False, False, False, False],
    ]
    hap["Mustrain"] = [
        "isotropic",
        [0.0, 0.0, 1.0],
        [False, False, False],
        [0, 0, 1],
        [0.0, 0.0, 0.0, 0.0],
        [False, False, False, False],
    ]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def compact_hap(phase, hist_name: str) -> dict:
    hap = phase.data["Histograms"][hist_name]
    return {
        "Scale": hap["Scale"],
        "Size": hap["Size"],
        "Mustrain": hap["Mustrain"],
        "HStrain": hap["HStrain"],
        "Pref.Ori.": hap["Pref.Ori."],
    }


def covariance_diagnostics(project) -> dict:
    cov = project.data.get("Covariance", {}).get("data", {})
    matrix = cov.get("covMatrix")
    names = [str(v) for v in cov.get("varyList", [])]
    if matrix is None or len(names) < 2:
        return {"largest_abs_correlations": []}
    matrix = np.asarray(matrix, dtype=float)
    sd = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    denom = np.outer(sd, sd)
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
    pairs = []
    for i in range(len(names)):
        for j in range(i):
            pairs.append((abs(float(corr[i, j])), float(corr[i, j]), names[i], names[j]))
    pairs.sort(reverse=True)
    return {
        "largest_abs_correlations": [
            {"abs": a, "value": c, "left": left, "right": right}
            for a, c, left, right in pairs[:12]
        ]
    }


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    cov = project.data.get("Covariance", {}).get("data", {})
    out = {
        "stage": label,
        "histogram_residuals": hist.residuals,
        "overall_Rvals": cov.get("Rvals", {}),
        "shift_um": sample["Shift"],
        "zero_deg": inst["Zero"],
        "profile": {k: inst[k] for k in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
        "background": hist.data["Background"][0],
        "phases": {},
        "frozen": project.get_Frozen(),
    }
    for phase in project.phases():
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "hap": compact_hap(phase, hist.name),
        }
    try:
        out["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    out.update(covariance_diagnostics(project))
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    parser.add_argument(
        "--scheelite",
        default="candidate_srwo4_from_srmoo4.cif",
        help="adapted SrWO4 CIF",
    )
    parser.add_argument("--wo3", help="COD id for a WO3 candidate")
    parser.add_argument("--carbonate", action="store_true")
    parser.add_argument("--sr3w2o9", action="store_true")
    parser.add_argument("--refine-x", action="store_true")
    parser.add_argument("--history-json")
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(newgpx=args.output)
    hist = project.add_powder_histogram(
        "pattern.xye", "instrument.instprm", fmthint="xye"
    )
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [850.0, True]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": [1000.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            }
        }
    )

    phase_specs: list[tuple[str, Path, float]] = [
        ("SrWO4", Path(args.scheelite), 1.0),
    ]
    if args.wo3:
        phase_specs.append((f"WO3_{args.wo3}", cod_path(args.wo3), 0.25))
    if args.carbonate:
        phase_specs.append(("SrCO3_9008198", cod_path("9008198"), 0.12))
    if args.sr3w2o9:
        phase_specs.append(("Sr3W2O9_2311977", cod_path("2311977"), 0.12))

    phases = []
    for name, cif, scale in phase_specs:
        phase = project.add_phase(
            str(cif), phasename=name, histograms=[hist], fmthint="CIF"
        )
        reset_hap(phase, hist.name, scale)
        phase.set_refinements({"Cell": False})
        phases.append(phase)

    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    project.save()

    # Enforce physically valid global Gaussian width and displacement ranges.
    for control, value, variable in [
        ("parmMin", 0.01, ":0:W"),
        ("parmMax", 500.0, ":0:W"),
        ("parmMin", 0.0, ":0:U"),
        ("parmMax", 500.0, ":0:U"),
        ("parmMin", 0.0, ":0:X"),
        ("parmMax", 100.0, ":0:X"),
        ("parmMin", 0.0, ":0:Shift"),
        ("parmMax", 2000.0, ":0:Shift"),
        ("parmMin", 1e-12, "*:0:Scale"),
    ]:
        project.set_Controls(control, value, variable=variable)

    history = []
    project.refine()
    history.append(snapshot(project, "background_scales_shift"))

    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.refine()
    history.append(snapshot(project, "all_cells"))

    inst = hist.data["Instrument Parameters"][0]
    inst["W"][2] = True
    project.refine()
    history.append(snapshot(project, "global_W"))

    inst["U"][2] = True
    project.refine()
    history.append(snapshot(project, "global_UW"))

    if args.refine_x:
        inst["X"][2] = True
        project.refine()
        history.append(snapshot(project, "global_UWX"))

    # One final coupled pass verifies that the persistent flags replay cleanly.
    project.refine()
    history.append(snapshot(project, "reconverged"))
    project.save()

    if args.history_json:
        Path(args.history_json).write_text(json.dumps(history, indent=2, default=float) + "\n")
    final = history[-1]
    print(
        json.dumps(
            {
                "output": args.output,
                "Rwp": final["overall_Rvals"].get("Rwp"),
                "GOF": final["overall_Rvals"].get("GOF"),
                "converged": final["overall_Rvals"].get("converged"),
                "max_shift_over_sigma": final["overall_Rvals"].get("Max shft/sig"),
                "mass_fractions": final.get("mass_fractions"),
                "shift_um": final["shift_um"],
                "profile": final["profile"],
                "cells": {
                    name: values["cell"] for name, values in final["phases"].items()
                },
                "frozen": final["frozen"],
            },
            indent=2,
            default=float,
        )
    )


if __name__ == "__main__":
    main()
