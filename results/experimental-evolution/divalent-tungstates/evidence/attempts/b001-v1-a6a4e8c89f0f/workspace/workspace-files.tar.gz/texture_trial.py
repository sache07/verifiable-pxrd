#!/usr/bin/env python3
"""Test one March-Dollase direction on a converged project."""

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", default="trial_eu_profile_x.gpx")
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--axis", nargs=3, type=int, required=True)
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(args.base, newgpx=args.output)
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(args.axis)
    project.set_Controls("cycles", 12)
    project.set_Frozen(mode="remove")
    project.refine()
    project.refine()
    project.save()
    print(
        json.dumps(
            {
                "output": args.output,
                "phase": args.phase,
                "axis": args.axis,
                "Rwp": project.data["Covariance"]["data"]["Rvals"]["Rwp"],
                "GOF": project.data["Covariance"]["data"]["Rvals"]["GOF"],
                "max_shift_over_sigma": project.data["Covariance"]["data"]["Rvals"].get(
                    "Max shft/sig"
                ),
                "preferred_orientation": hap["Pref.Ori."],
                "mass_fractions": hist.ComputeMassFracs(),
                "frozen": project.get_Frozen(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
