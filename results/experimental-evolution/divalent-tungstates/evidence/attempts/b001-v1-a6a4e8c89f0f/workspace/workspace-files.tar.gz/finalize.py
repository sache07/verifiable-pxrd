#!/usr/bin/env python3
"""Replay the selected GSAS-II model and export all submitted artifacts."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


BASE = "trial_broad_WO3_2311041_strain.gpx"
FINAL = "final.gpx"

PHASE_OUTPUTS = {
    "SrWO4": ("SrWO4", "SrWO4.cif"),
    "WO3_2311041": ("WO3", "WO3.cif"),
    "SrCO3_9008198": ("SrCO3", "SrCO3.cif"),
}


def to_builtin(value):
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    raise TypeError(f"Cannot serialize {type(value)}")


def assert_final_model(project) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    assert inst["Zero"][2] is False
    assert sample["Shift"][1] is True
    assert inst["V"][2] is False and inst["Y"][2] is False and inst["Z"][2] is False
    assert all(inst[key][1] >= 0 for key in ("U", "W", "X"))
    assert not project.get_Frozen()
    assert set(p.name for p in project.phases()) == set(PHASE_OUTPUTS)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        assert hap["Scale"][1]
        assert not any(hap["Size"][2]) and not any(hap["Size"][5])
        assert not any(hap["HStrain"][1])
        if phase.name == "WO3_2311041":
            assert hap["Mustrain"][2][0]
        else:
            assert not any(hap["Mustrain"][2]) and not any(hap["Mustrain"][5])


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(BASE, newgpx=FINAL)
    project.set_Frozen(mode="remove")
    project.set_Controls("cycles", 12)
    assert_final_model(project)

    # Coupled replay: all persistent flags are already set in BASE.
    project.refine()
    project.refine()
    project.save()
    assert_final_model(project)

    # Reload and perform one final replay pass to verify project consistency.
    project = G2sc.G2Project(FINAL)
    before = project.data["Covariance"]["data"]["Rvals"]["Rwp"]
    project.refine()
    project.save()
    after = project.data["Covariance"]["data"]["Rvals"]["Rwp"]
    assert abs(after - before) < 1e-4, (before, after)
    assert_final_model(project)

    hist = project.histogram(0)
    residuals = hist.residuals
    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    fractions = hist.ComputeMassFracs()

    phase_rows = []
    for phase in project.phases():
        formula, cif_path = PHASE_OUTPUTS[phase.name]
        phase.export_CIF(cif_path)
        fraction, formal_esd = fractions[phase.name]
        phase_rows.append(
            {
                "name": formula,
                "project_phase_name": phase.name,
                "cif_path": cif_path,
                "weight_fraction": fraction,
                "weight_percent": 100.0 * fraction,
                "formal_weight_fraction_esd": formal_esd,
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cell": phase.get_cell(),
                "phase_fit_Rf_percent": residuals.get(f"{phase.id}:0:Rf"),
                "phase_fit_Rf2_percent": residuals.get(f"{phase.id}:0:Rf^2"),
            }
        )

    x, observed, weights, calculated, background, stored_difference = hist.data["data"][1]
    difference = np.asarray(observed) - np.asarray(calculated)
    with Path("fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "background_counts",
                "difference_counts",
            ]
        )
        writer.writerows(zip(x, observed, calculated, background, difference))

    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "phases": phase_rows,
        "modeled_crystalline_weight_fraction_sum": sum(
            row["weight_fraction"] for row in phase_rows
        ),
        "fit_statistics": {
            "Rwp_percent": residuals["wR"],
            "Rp_percent": residuals["R"],
            "R_background_percent": residuals["Rb"],
            "weighted_R_background_percent": residuals["wRb"],
            "Rwp_expected_percent": residuals["wRmin"],
            "goodness_of_fit": rvals["GOF"],
            "reduced_chi_square": rvals["GOF"] ** 2,
            "chi_square": rvals["chisq"],
            "n_observations": rvals["Nobs"],
            "n_refined_variables": rvals["Nvars"],
            "converged": bool(rvals["converged"]),
            "max_shift_over_sigma": rvals.get("Max shft/sig"),
        },
        "measurement_model": {
            "radiation": "Cu K-alpha1/K-alpha2",
            "wavelength_Kalpha1_angstrom": inst["Lam1"][1],
            "wavelength_Kalpha2_angstrom": inst["Lam2"][1],
            "Kalpha2_to_Kalpha1_ratio": inst["I(L2)/I(L1)"][1],
            "point_weights": "1 / observed_counts (Poisson counting approximation)",
            "angular_correction": {
                "type": "Bragg-Brentano specimen displacement",
                "shift_micrometres": sample["Shift"][0],
                "zero_offset_deg": inst["Zero"][1],
                "zero_offset_refined": bool(inst["Zero"][2]),
            },
            "global_profile": {
                key: {"value": inst[key][1], "refined": bool(inst[key][2])}
                for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")
            },
        },
        "project_path": FINAL,
        "fit_csv_path": "fit.csv",
        "replay_Rwp_change_percent": after - before,
    }
    Path("result.json").write_text(
        json.dumps(result, indent=2, default=to_builtin) + "\n"
    )
    print(json.dumps(result, indent=2, default=to_builtin))


if __name__ == "__main__":
    main()
