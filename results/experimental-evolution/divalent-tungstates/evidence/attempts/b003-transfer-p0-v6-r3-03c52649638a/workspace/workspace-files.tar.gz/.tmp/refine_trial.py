from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parents[1]
source = root / ".tmp" / "explore.gpx"
target = root / ".tmp" / "trial.gpx"
shutil.copy2(source, target)
project = G2sc.G2Project(str(target))
G2sc.SetPrintLevel("all")
project.set_Controls("cycles", 12)
hist = project.histogram(0)


def summary(stage):
    print("\nSUMMARY", stage)
    print("residuals", hist.residuals)
    try:
        print("mass_fracs", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass_fracs_error", repr(exc))
    print("instrument", {k: v for k, v in hist.data["Instrument Parameters"][0].items() if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")})
    print("background", hist.data["Background"][0])
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, "cell", phase.get_cell(), "scale", hap["Scale"], "size", hap["Size"], "mustrain", hap["Mustrain"])


hist.clear_refinements({"Sample Parameters": ["Scale"]})
hist.set_refinements({
    "Limits": [10.0, 100.0],
    "Background": {
        "type": "chebyschev-1",
        "refine": True,
        "no. coeffs": 12,
        "coeffs": [3300.0] + [0.0] * 11,
    },
})
for phase in project.phases():
    phase.set_HAP_refinements({"Scale": True})
project.refine(printFile=str(root / ".tmp" / "stage1.lst"))
summary("scale_background")

for phase in project.phases():
    phase.set_refinements({"Cell": True})
project.refine(printFile=str(root / ".tmp" / "stage2.lst"))
summary("cells")

hist.set_refinements({"Instrument Parameters": ["Zero"]})
project.refine(printFile=str(root / ".tmp" / "stage3.lst"))
summary("zero")

hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
project.refine(printFile=str(root / ".tmp" / "stage4.lst"))
summary("uvw")

hist.set_refinements({"Instrument Parameters": ["X", "Y"]})
project.refine(printFile=str(root / ".tmp" / "stage5.lst"))
summary("xy")

for phase in project.phases():
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": 1.0, "refine": True},
    })
project.refine(printFile=str(root / ".tmp" / "stage6.lst"))
summary("size")

project.save()
