from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parents[1]
gpx_path = root / ".tmp" / "explore.gpx"
G2sc.SetPrintLevel("all")
project = G2sc.G2Project(newgpx=str(gpx_path))
hist = project.add_powder_histogram(
    str(root / ".tmp" / "pattern.xye"),
    str(root / ".tmp" / "cu_ka.instprm"),
    fmthint="xye",
)

for name, filename in (
    ("NiWO4", "niwo4_start.cif"),
    ("WO3", "wo3_start.cif"),
    ("NiO", "nio_start.cif"),
):
    project.add_phase(
        str(root / ".tmp" / filename),
        phasename=name,
        histograms=[hist],
        fmthint="CIF",
    )

project.save()
print("hist", hist.name, hist.residuals)
print("limits", hist.data["Limits"])
print("instrument", hist.data["Instrument Parameters"])
print("background", hist.data["Background"])
print("sample", hist.data["Sample Parameters"])
for phase in project.phases():
    print("PHASE", phase.name)
    print("cell", phase.get_cell())
    print("general", {k: phase.data["General"].get(k) for k in ("Name", "Type", "SGData", "Cell", "AtomTypes", "NoAtoms", "Mass")})
    print("atoms")
    for atom in phase.atoms():
        print(atom.label, atom.element, atom.coordinates, atom.occupancy, atom.uiso)
    print("HAP", phase.data["Histograms"][hist.name])
