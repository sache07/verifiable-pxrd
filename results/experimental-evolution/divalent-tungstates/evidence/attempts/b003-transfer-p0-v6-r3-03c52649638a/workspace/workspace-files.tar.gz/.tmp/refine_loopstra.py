from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parents[1]
project_path = root / ".tmp" / "loopstra.gpx"
wo3_source = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/2/31/10/2311041.cif"
)

G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(newgpx=str(project_path))
project.set_Controls("cycles", 10)
hist = project.add_powder_histogram(
    str(root / ".tmp" / "pattern.xye"),
    str(root / ".tmp" / "cu_ka.instprm"),
    fmthint="xye",
)
for name, source in (
    ("NiWO4", root / ".tmp" / "niwo4_start.cif"),
    ("WO3", wo3_source),
    ("NiO", root / ".tmp" / "nio_start.cif"),
):
    project.add_phase(
        str(source), phasename=name, histograms=[hist], fmthint="CIF"
    )

# The source structures do not provide a consistent ADP model. Keep all
# isotropic displacement factors at zero, as in the WO3 neutron reference.
for phase in project.phases():
    for atom in phase.atoms():
        atom.uiso = 0.0
        atom.refinement_flags = ""

instrument = hist.data["Instrument Parameters"][0]
for key, value in {
    "U": 34.93,
    "V": -53.17,
    "W": 48.29,
    "X": 2.98,
    "Y": 0.0,
}.items():
    instrument[key][1] = value
    instrument[key][2] = False

hist.clear_refinements({"Sample Parameters": ["Scale"]})
hist.set_refinements(
    {
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 12,
            "coeffs": [3300.0] + [0.0] * 11,
        },
    }
)
for phase in project.phases():
    phase.set_HAP_refinements({"Scale": True})
project.refine()

for phase in project.phases():
    phase.set_refinements({"Cell": True})
project.refine()

hist.set_refinements({"Instrument Parameters": ["Zero"]})
project.refine()

hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X"]})
project.refine()

for atom in project.phase("NiWO4").atoms():
    atom.refinement_flags = "X"
for atom in project.phase("WO3").atoms():
    if atom.element == "W":
        atom.refinement_flags = "X"
project.refine()
project.refine()
project.save()

print("residuals", hist.residuals)
print("Rvals", project.data["Covariance"]["data"]["Rvals"])
print("mass_fractions", hist.ComputeMassFracs())
for phase in project.phases():
    print(phase.name, phase.get_cell())
    print([(a.label, a.element, a.coordinates) for a in phase.atoms()])
