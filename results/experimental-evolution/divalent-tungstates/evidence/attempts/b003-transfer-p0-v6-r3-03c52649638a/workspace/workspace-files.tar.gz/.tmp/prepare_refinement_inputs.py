from pathlib import Path

import numpy as np
import pandas as pd


root = Path(__file__).resolve().parents[1]
pattern = pd.read_csv(root / "inputs" / "pattern.csv")
x = pattern.iloc[:, 0].to_numpy(float)
y = pattern.iloc[:, 1].to_numpy(float)
sigma = np.sqrt(np.maximum(y, 1.0))

with (root / ".tmp" / "pattern.xye").open("w") as stream:
    stream.write("# 2theta_deg intensity_counts sigma_counts\n")
    np.savetxt(stream, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")

(root / ".tmp" / "cu_ka.instprm").write_text(
    "#GSAS-II instrument parameter file for lab Cu K-alpha reflection data\n"
    "Type:PXC;Bank:1\n"
    "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.70;Azimuth:0.0;I(L2)/I(L1):0.5\n"
    "U:20.0;V:-5.0;W:40.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
)
