from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parents[1]
source = root / ".tmp" / "loopstra.gpx"
final_project = root / "final.gpx"

project = G2sc.G2Project(str(source), newgpx=str(final_project))
project.save()
hist = project.histogram(0)

for phase_name, output_name in (
    ("NiWO4", "NiWO4.cif"),
    ("WO3", "WO3.cif"),
    ("NiO", "NiO.cif"),
):
    project.phase(phase_name).export_CIF(str(root / output_name))

x, observed, _, calculated, background, difference = hist.data["data"][1]
# GSAS-II uses the nearest data-bin edges for the configured 10--100 degree
# limits. Select the points actually calculated so fit.csv exactly matches
# the observations included in the saved refinement statistics.
selected = (calculated != 0.0) | (background != 0.0)
np.savetxt(
    root / "fit.csv",
    np.column_stack(
        (
            x[selected],
            observed[selected],
            calculated[selected],
            background[selected],
            difference[selected],
        )
    ),
    fmt="%.8f",
    delimiter=",",
    header=(
        "two_theta_deg,observed_counts,calculated_counts,"
        "background_counts,difference_counts"
    ),
    comments="",
)

print(hist.residuals)
print(project.data["Covariance"]["data"]["Rvals"])
print(hist.ComputeMassFracs())
