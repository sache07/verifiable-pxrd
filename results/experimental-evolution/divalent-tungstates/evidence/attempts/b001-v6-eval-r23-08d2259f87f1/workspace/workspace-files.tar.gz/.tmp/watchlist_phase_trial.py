#!/usr/bin/env python3
"""Re-challenge an omitted candidate phase under the accepted profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def neutralize_hap(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][:3] = ["MD", 1.0, False]
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("cif", type=Path)
    parser.add_argument("name")
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(args.source), newgpx=str(args.out.resolve()))
    project.data["Controls"]["data"]["max cyc"] = 10
    hist = project.histogram(0)
    phase = project.add_phase(
        str(args.cif), phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    neutralize_hap(phase, hist.name)
    phase.data["Histograms"][hist.name]["Scale"][:] = [0.1, True]
    phase.data["General"]["Cell"][0] = False
    project.save()
    project.do_refinements([{}, {}])
    project.save()

    cov = project.data["Covariance"]["data"]
    print(
        json.dumps(
            {
                "candidate": args.name,
                "rwp": hist.residuals["wR"],
                "gof": cov["Rvals"]["GOF"],
                "converged": cov["Rvals"].get("converged"),
                "scale": phase.data["Histograms"][hist.name]["Scale"],
                "fractions": hist.ComputeMassFracs(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
