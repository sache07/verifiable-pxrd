#!/usr/bin/env python3
"""Replay a restricted SrWO4 coordinate/ADP trial."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("mode", choices=("oxygen_xyz", "uiso", "oxygen_xyz_uiso"))
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(args.source), newgpx=str(args.out.resolve()))
    project.data["Controls"]["data"]["max cyc"] = 10
    phase = project.phase("SrWO4")
    for atom in phase.atoms():
        if args.mode == "oxygen_xyz":
            atom.refinement_flags = "X" if atom.element == "O" else " "
        elif args.mode == "uiso":
            atom.refinement_flags = "U"
        else:
            atom.refinement_flags = "XU" if atom.element == "O" else "U"
    project.save()
    project.do_refinements([{}, {}])
    project.save()
    hist = project.histogram(0)
    print(
        json.dumps(
            {
                "mode": args.mode,
                "rwp": hist.residuals["wR"],
                "gof": project.data["Covariance"]["data"]["Rvals"]["GOF"],
                "converged": project.data["Covariance"]["data"]["Rvals"].get(
                    "converged"
                ),
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": atom.coordinates,
                        "uiso": atom.uiso,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
                "mass_fractions": hist.ComputeMassFracs(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
