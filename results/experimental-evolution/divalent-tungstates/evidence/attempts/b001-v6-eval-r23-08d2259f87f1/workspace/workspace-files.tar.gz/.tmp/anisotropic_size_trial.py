#!/usr/bin/env python3
"""Challenge an isotropic phase-size term with one uniaxial alternative."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("phase")
    parser.add_argument("axis", nargs=3, type=int)
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(args.source), newgpx=str(args.out.resolve()))
    project.data["Controls"]["data"]["max cyc"] = 10
    hist = project.histogram(0)
    size = project.phase(args.phase).data["Histograms"][hist.name]["Size"]
    initial = float(size[1][0])
    size[0] = "uniaxial"
    size[1][:] = [initial, initial, 1.0]
    size[2][:] = [True, True, False]
    size[3][:] = list(args.axis)
    project.save()
    project.do_refinements([{}, {}])
    project.save()

    cov = project.data["Covariance"]["data"]
    print(
        json.dumps(
            {
                "phase": args.phase,
                "axis": args.axis,
                "rwp": hist.residuals["wR"],
                "gof": cov["Rvals"]["GOF"],
                "converged": cov["Rvals"].get("converged"),
                "size": size,
                "vary_list": [str(x) for x in cov.get("varyList", [])],
                "sigmas": cov.get("sig", []).tolist(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
