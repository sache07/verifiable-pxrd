#!/usr/bin/env python3
"""Run a restrained GSAS-II inventory/profile trial and print a JSON summary."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
CIF_ROOT = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)


def cod_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize_hap(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1.0e6, 1.0e6, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][:3] = ["MD", 1.0, False]
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--wo3", default="1528915")
    parser.add_argument("--carbonate", default="9008198")
    parser.add_argument("--product", choices=("scheelite", "sr3w2o9", "none"), default="scheelite")
    parser.add_argument("--profile", action="store_true")
    parser.add_argument("--fit-u", action="store_true")
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(args.out.resolve()))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / ".tmp/lab_cu.instprm"),
        fmthint="comma",
    )
    hist.data["Limits"][1][:] = [10.0, 100.0]
    hist.data["Sample Parameters"]["Scale"][:] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"][:] = [800.0, False]
    hist.data["Background"][0][:] = [
        "chebyschev-1", True, 6, 1050.0, 0.0, 0.0, 0.0, 0.0, 0.0
    ]

    phase_specs: list[tuple[str, Path]] = []
    if args.product == "scheelite":
        phase_specs.append(("SrWO4", ROOT / ".tmp/SrWO4_scheelite_start.cif"))
    elif args.product == "sr3w2o9":
        phase_specs.append(("Sr3W2O9", cod_path("2311977")))
    if args.wo3 != "none":
        phase_specs.append(("WO3", cod_path(args.wo3)))
    if args.carbonate != "none":
        phase_specs.append(("SrCO3", cod_path(args.carbonate)))

    phases = []
    for name, path in phase_specs:
        phase = project.add_phase(
            str(path), phasename=name, histograms=[hist], fmthint="CIF"
        )
        neutralize_hap(phase, hist.name)
        initial_scales = {"SrWO4": 3.4, "WO3": 0.6, "SrCO3": 0.5, "Sr3W2O9": 1.0}
        phase.data["Histograms"][hist.name]["Scale"][:] = [
            initial_scales[name], True
        ]
        if name == "SrCO3" and args.carbonate == "9008198":
            # The coherent 111/102/211/013/122 families all require a
            # slightly larger metric than this ambient database record.
            cell = phase.data["General"]["Cell"]
            cell[1:4] = [value * 1.0045 for value in cell[1:4]]
            cell[7] = cell[1] * cell[2] * cell[3]
        phases.append(phase)

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = args.cycles
    controls["min dM/M"] = 1.0e-4
    project.save()

    # Fit smooth background and all scales with the displacement near its
    # position-family estimate, then release displacement and cells.
    project.do_refinements([{}])
    hist.data["Sample Parameters"]["Shift"][1] = True
    project.do_refinements([{}])
    for phase in phases:
        phase.data["General"]["Cell"][0] = True
        project.do_refinements([{}])
    project.do_refinements([{}])

    if args.profile:
        inst = hist.data["Instrument Parameters"][0]
        inst["U"][1] = 0.0
        inst["U"][2] = False
        inst["W"][2] = True
        inst["X"][2] = True
        project.do_refinements([{}])
        if args.fit_u:
            inst["U"][2] = True
            project.do_refinements([{}])
        project.do_refinements([{}])

    project.save()
    summary = {
        "project": str(args.out),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "sample": {
            key: value
            for key, value in hist.data["Sample Parameters"].items()
            if key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "instrument": {
            key: value
            for key, value in hist.data["Instrument Parameters"][0].items()
            if key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Zero")
        },
        "background": hist.data["Background"][0],
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][hist.name]["Scale"],
            }
            for phase in phases
        },
        "covariance": {
            key: project.data["Covariance"]["data"].get(key)
            for key in ("Rvals", "varyList", "sig")
        },
    }
    print(json.dumps(summary, indent=2, default=str))


if __name__ == "__main__":
    main()
