#!/usr/bin/env python3
"""Compare mutually exclusive specimen-shift and zero corrections."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("mode", choices=("shift", "zero", "none"))
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(args.source), newgpx=str(args.out.resolve()))
    project.data["Controls"]["data"]["max cyc"] = 10
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    shift = hist.data["Sample Parameters"]["Shift"]
    shift[:] = [0.0, args.mode == "shift"]
    # A +1.06 mm displacement on the 200 mm goniometer corresponds to
    # roughly -0.5 degrees over this angular range; seed the competing zero
    # model nearby so the first cycle does not lose every reflection.
    inst["Zero"][1] = -0.5 if args.mode == "zero" else 0.0
    inst["Zero"][2] = args.mode == "zero"
    if args.mode == "zero":
        # Move between angular-correction parameterizations reversibly. Start
        # with zero alone, then restore intensity, cell, profile, texture and
        # width variables in restrained blocks.
        hist.data["Background"][0][1] = False
        inst["W"][2] = False
        inst["X"][2] = False
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            phase.data["General"]["Cell"][0] = False
            hap["Scale"][1] = False
            hap["Pref.Ori."][2] = False
            hap["Size"][2][:] = [False, False, False]
        project.save()
        project.do_refinements([{}])

        hist.data["Background"][0][1] = True
        for phase in project.phases():
            phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.do_refinements([{}])
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = True
        project.do_refinements([{}])
        inst["W"][2] = True
        inst["X"][2] = True
        for phase in project.phases():
            phase.data["Histograms"][hist.name]["Pref.Ori."][2] = True
        project.phase("WO3").data["Histograms"][hist.name]["Size"][2][:] = [
            True,
            True,
            False,
        ]
        project.do_refinements([{}, {}])
    else:
        project.save()
        project.do_refinements([{}, {}])
    project.save()

    cov = project.data["Covariance"]["data"]
    print(
        json.dumps(
            {
                "mode": args.mode,
                "rwp": hist.residuals["wR"],
                "gof": cov["Rvals"]["GOF"],
                "converged": cov["Rvals"].get("converged"),
                "shift": shift,
                "zero": inst["Zero"],
                "cells": {phase.name: phase.get_cell() for phase in project.phases()},
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
