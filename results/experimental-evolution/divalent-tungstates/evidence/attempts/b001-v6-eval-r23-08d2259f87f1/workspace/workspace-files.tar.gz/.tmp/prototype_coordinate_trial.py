#!/usr/bin/env python3
"""Compare fixed, physically screened scheelite oxygen-coordinate parents."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--oxygen", nargs=3, type=float, required=True)
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(args.source), newgpx=str(args.out.resolve()))
    project.data["Controls"]["data"]["max cyc"] = 10
    phase = project.phase("SrWO4")
    for atom in phase.atoms():
        atom.refinement_flags = " "
        if atom.element == "O":
            atom.coordinates = list(args.oxygen)
    project.save()
    project.do_refinements([{}, {}])
    project.save()

    hist = project.histogram(0)
    print(
        json.dumps(
            {
                "oxygen": list(args.oxygen),
                "rwp": hist.residuals["wR"],
                "gof": project.data["Covariance"]["data"]["Rvals"]["GOF"],
                "converged": project.data["Covariance"]["data"]["Rvals"].get(
                    "converged"
                ),
                "mass_fractions": hist.ComputeMassFracs(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
