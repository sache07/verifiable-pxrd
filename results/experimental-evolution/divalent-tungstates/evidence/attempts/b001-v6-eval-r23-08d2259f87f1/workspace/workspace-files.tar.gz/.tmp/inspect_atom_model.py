#!/usr/bin/env python3
"""Inspect the refined scheelite atom model and its covariance."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
GPX = ROOT / ".tmp" / "atom_oxygen_xyz.gpx"
CIF = ROOT / ".tmp" / "atom_oxygen_xyz.cif"


project = G2sc.G2Project(str(GPX))
phase = project.phase("SrWO4")
phase.export_CIF(str(CIF))

cov_data = project.data["Covariance"]["data"]
vary = [str(item) for item in cov_data.get("varyList", [])]
sig = np.asarray(cov_data.get("sig", []), dtype=float)
cov = np.asarray(cov_data.get("covMatrix", []), dtype=float)
selected = [
    index
    for index, name in enumerate(vary)
    if any(key in name for key in ("dA", "MD", "Scale", "Shift", "W", "X"))
]

correlations = []
if cov.shape == (len(vary), len(vary)):
    denom = np.sqrt(np.outer(np.diag(cov), np.diag(cov)))
    with np.errstate(divide="ignore", invalid="ignore"):
        corr = np.divide(cov, denom, out=np.zeros_like(cov), where=denom > 0)
    for i in selected:
        for j in range(i + 1, len(vary)):
            if abs(corr[i, j]) >= 0.5:
                correlations.append(
                    {
                        "a": vary[i],
                        "b": vary[j],
                        "correlation": float(corr[i, j]),
                    }
                )

print(
    json.dumps(
        {
            "cif": str(CIF),
            "selected_variables": [
                {
                    "name": vary[i],
                    "value": float(cov_data.get("variables", [])[i]),
                    "sigma": float(sig[i]),
                }
                for i in selected
            ],
            "correlations_abs_ge_0.5": correlations,
        },
        indent=2,
    )
)
