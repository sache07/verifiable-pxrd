#!/usr/bin/env python3
"""Make a compact diagnostic view of the submitted full-range profile."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
data = np.genfromtxt(ROOT / "fit.csv", delimiter=",", names=True)
x = data["two_theta_deg"]
yo = data["observed"]
yc = data["calculated"]
diff = data["difference"]

fig, axes = plt.subplots(4, 1, figsize=(14, 11), constrained_layout=True)
ranges = [(x.min(), x.max()), (18, 34), (38, 58), (68, 94)]
for axis, (lo, hi) in zip(axes, ranges):
    mask = (x >= lo) & (x <= hi)
    offset = max(0.0, float(np.min(yo[mask])) - 2.5 * float(np.std(diff[mask])))
    axis.plot(x[mask], yo[mask], color="black", lw=0.65, label="observed")
    axis.plot(x[mask], yc[mask], color="#d62728", lw=0.8, label="calculated")
    axis.plot(x[mask], diff[mask] + offset, color="#1f77b4", lw=0.65, label="difference + offset")
    axis.axhline(offset, color="#1f77b4", lw=0.4, alpha=0.6)
    axis.set_xlim(lo, hi)
    axis.set_ylabel("counts")
axes[0].legend(ncol=3, loc="upper right", frameon=False)
axes[-1].set_xlabel(r"$2\theta$ (degrees)")
fig.savefig(ROOT / ".tmp" / "final_fit_diagnostic.png", dpi=170)
