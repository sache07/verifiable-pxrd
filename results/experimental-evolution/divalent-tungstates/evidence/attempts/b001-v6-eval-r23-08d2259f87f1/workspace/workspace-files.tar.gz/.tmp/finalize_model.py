#!/usr/bin/env python3
"""Replay the accepted model over the full range and make exact exports."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp" / "aniso_010.gpx"
FINAL = ROOT / "final.gpx"
CIFS = {
    "SrWO4": ROOT / "phase_1_SrWO4.cif",
    "WO3": ROOT / "phase_2_WO3.cif",
    "SrCO3": ROOT / "phase_3_SrCO3.cif",
}


def configure(project: G2sc.G2Project) -> None:
    project.data["Controls"]["data"]["max cyc"] = 10
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-4
    hist = project.histogram(0)
    x = np.asarray(hist.data["data"][1][0], dtype=float)
    hist.data["Limits"][1][:] = [float(x[0]), float(x[-1])]


def replay(project: G2sc.G2Project, repeats: int = 1) -> None:
    for _ in range(repeats):
        project.do_refinements([{}])
        project.save()


G2sc.SetPrintLevel("warn")

# First convert the accepted common-profile project to the full measured range.
project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL.resolve()))
configure(project)
project.save()
replay(project, repeats=2)

# Reopen and replay twice so the submitted project is independently reusable.
for _ in range(2):
    project = G2sc.G2Project(str(FINAL))
    configure(project)
    replay(project)

# Reopen once more for exports; every exported value now comes from final.gpx.
project = G2sc.G2Project(str(FINAL))
hist = project.histogram(0)
for phase in project.phases():
    phase.export_CIF(str(CIFS[phase.name]))

arrays = np.asarray(hist.data["data"][1], dtype=float)
x, observed, _weights, calculated = arrays[:4]
difference = observed - calculated
with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as stream:
    writer = csv.writer(stream)
    writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
    for row in zip(x, observed, calculated, difference):
        writer.writerow(
            [
                f"{row[0]:.8f}",
                f"{row[1]:.10g}",
                f"{row[2]:.10g}",
                f"{row[3]:.10g}",
            ]
        )

cov = project.data["Covariance"]["data"]
rvals = cov["Rvals"]
fractions = hist.ComputeMassFracs()
summary = {
    "project": str(FINAL),
    "limits": list(hist.data["Limits"][1]),
    "residuals": hist.residuals,
    "rvals": rvals,
    "fractions": fractions,
    "instrument": {
        key: hist.data["Instrument Parameters"][0][key]
        for key in (
            "Lam1",
            "Lam2",
            "I(L2)/I(L1)",
            "Polariz.",
            "Zero",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "SH/L",
        )
    },
    "sample_shift": hist.data["Sample Parameters"]["Shift"],
    "background": hist.data["Background"][0],
    "phases": {},
    "fit_rows": len(x),
    "difference_consistent": bool(
        np.allclose(difference, np.asarray(hist.data["data"][1][5], dtype=float))
    ),
}
for index, phase in enumerate(project.phases()):
    hap = phase.data["Histograms"][hist.name]
    summary["phases"][phase.name] = {
        "cif": str(CIFS[phase.name]),
        "space_group": phase.data["General"]["SGData"]["SpGrp"],
        "cell": phase.get_cell(),
        "fraction": fractions[phase.name],
        "scale": hap["Scale"],
        "preferred_orientation": hap["Pref.Ori."],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "R_F_percent": hist.residuals.get(f"{index}:0:Rf"),
        "R_F2_percent": hist.residuals.get(f"{index}:0:Rf^2"),
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": atom.coordinates,
                "uiso": atom.uiso,
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ],
    }

print(json.dumps(summary, indent=2, default=lambda value: value.tolist()))
