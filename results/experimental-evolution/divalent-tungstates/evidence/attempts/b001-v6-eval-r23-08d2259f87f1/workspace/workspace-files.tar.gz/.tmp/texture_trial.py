#!/usr/bin/env python3
"""Replay a project with one SrWO4 March-Dollase texture axis."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("axis", nargs=3, type=int)
    parser.add_argument("--phase", default="SrWO4")
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(args.source), newgpx=str(args.out.resolve()))
    project.data["Controls"]["data"]["max cyc"] = 8
    phase = project.phase(args.phase)
    hist = project.histogram(0)
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = list(args.axis)
    project.save()
    project.do_refinements([{}, {}])
    project.save()
    print(
        json.dumps(
            {
                "axis": args.axis,
                "phase": args.phase,
                "rwp": hist.residuals["wR"],
                "gof": project.data["Covariance"]["data"]["Rvals"]["GOF"],
                "converged": project.data["Covariance"]["data"]["Rvals"].get(
                    "converged"
                ),
                "md": pref[1],
                "mass_fractions": hist.ComputeMassFracs(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
