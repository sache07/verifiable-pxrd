#!/usr/bin/env python3
"""Remove one accepted texture term and replay all remaining variables."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("phase")
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(args.source), newgpx=str(args.out.resolve()))
    project.data["Controls"]["data"]["max cyc"] = 10
    hist = project.histogram(0)
    pref = project.phase(args.phase).data["Histograms"][hist.name]["Pref.Ori."]
    pref[1] = 1.0
    pref[2] = False
    project.save()
    project.do_refinements([{}, {}])
    project.save()

    cov = project.data["Covariance"]["data"]
    print(
        json.dumps(
            {
                "removed": args.phase,
                "rwp": hist.residuals["wR"],
                "gof": cov["Rvals"]["GOF"],
                "converged": cov["Rvals"].get("converged"),
                "fractions": hist.ComputeMassFracs(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
