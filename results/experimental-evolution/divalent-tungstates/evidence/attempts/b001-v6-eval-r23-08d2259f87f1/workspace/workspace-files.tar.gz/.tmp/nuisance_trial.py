#!/usr/bin/env python3
"""Replay one bounded-physical profile nuisance trial from a common project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("kind", choices=("shl", "size", "strain"))
    parser.add_argument("--phase")
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(args.source), newgpx=str(args.out.resolve()))
    project.data["Controls"]["data"]["max cyc"] = 10
    hist = project.histogram(0)
    value = None
    if args.kind == "shl":
        item = hist.data["Instrument Parameters"][0]["SH/L"]
        item[1] = 0.002
        item[2] = True
    else:
        if not args.phase:
            parser.error("--phase is required for size/strain trials")
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][hist.name]
        if args.kind == "size":
            hap["Size"][0] = "isotropic"
            hap["Size"][1][:] = [2.0, 2.0, 1.0]
            hap["Size"][2][:] = [True, False, False]
        else:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][:] = [100.0, 100.0, 1.0]
            hap["Mustrain"][2][:] = [True, False, False]
    project.save()
    project.do_refinements([{}, {}])
    project.save()
    if args.kind == "shl":
        value = hist.data["Instrument Parameters"][0]["SH/L"]
    elif args.kind == "size":
        value = project.phase(args.phase).data["Histograms"][hist.name]["Size"]
    else:
        value = project.phase(args.phase).data["Histograms"][hist.name]["Mustrain"]
    print(
        json.dumps(
            {
                "kind": args.kind,
                "phase": args.phase,
                "rwp": hist.residuals["wR"],
                "gof": project.data["Covariance"]["data"]["Rvals"]["GOF"],
                "converged": project.data["Covariance"]["data"]["Rvals"].get(
                    "converged"
                ),
                "value": value,
                "mass_fractions": hist.ComputeMassFracs(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
