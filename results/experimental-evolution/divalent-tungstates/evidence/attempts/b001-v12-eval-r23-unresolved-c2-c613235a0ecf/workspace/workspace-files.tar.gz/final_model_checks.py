#!/usr/bin/env python3
"""Ablate final-model terms and replay the selected model over the full range."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "gsas_trials" / "prune_pbo_size_aniso.gpx"
CHECKS = ROOT / ".tmp" / "final_checks"


def refine_replay(project, count: int = 2) -> list[dict]:
    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    records = []
    for replay in range(count):
        project.set_Frozen()
        project.save()
        project.do_refinements([{}])
        project.save()
        hist = project.histogram(0)
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        records.append(
            {
                "replay": replay + 1,
                "Rwp": hist.residuals.get("wR"),
                "Rp": hist.residuals.get("R"),
                "chi_square": rvals.get("chisq"),
                "GOF": rvals.get("GOF"),
                "Nobs": rvals.get("Nobs"),
                "Nvars": rvals.get("Nvars"),
                "converged": rvals.get("converged"),
                "frozen": [str(item) for item in project.get_Frozen()],
                "mass_fractions": hist.ComputeMassFracs(),
            }
        )
    return records


def make_ablation(name: str) -> dict:
    CHECKS.mkdir(parents=True, exist_ok=True)
    output = CHECKS / f"ablate_{name}.gpx"
    shutil.copy2(BASE, output)
    project = G2sc.G2Project(gpxfile=str(output))
    hist = project.histogram(0)

    if name == "wo3_texture":
        po = project.phase("wo3_monoclinic_1528915").data["Histograms"][hist.name]["Pref.Ori."]
        po[1:3] = [1.0, False]
    elif name == "pb3o4_texture":
        po = project.phase("pb3o4_tetragonal_1537983").data["Histograms"][hist.name]["Pref.Ori."]
        po[1:3] = [1.0, False]
    elif name == "pbo_anisotropy":
        hap = project.phase("pbo_orthorhombic_2310433").data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [14000.0, 0.0, 1.0]
        hap["Mustrain"][2] = [True, False, False]
        hap["Mustrain"][3] = [0, 0, 1]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    elif name == "pbo_phase":
        phase = project.phase("pbo_orthorhombic_2310433")
        phase.set_refinements({"Cell": False})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [0.0, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Size"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
    elif name == "roughness":
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    elif name == "shl":
        hist.data["Instrument Parameters"][0]["SH/L"] = [0.002, 0.002, False]
    else:
        raise ValueError(f"unknown ablation: {name}")

    project.save()
    records = refine_replay(project)
    return {"name": name, "project": str(output.relative_to(ROOT)), "records": records}


def make_final() -> dict:
    output = ROOT / "final.gpx"
    shutil.copy2(BASE, output)
    project = G2sc.G2Project(gpxfile=str(output))
    hist = project.histogram(0)
    hist.set_refinements({"Limits": list(hist.data["Limits"][0])})
    project.save()
    records = refine_replay(project, count=3)
    return {"project": "final.gpx", "records": records}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "mode",
        choices=[
            "wo3_texture",
            "pb3o4_texture",
            "pbo_anisotropy",
            "pbo_phase",
            "roughness",
            "shl",
            "final",
        ],
    )
    args = parser.parse_args()
    result = make_final() if args.mode == "final" else make_ablation(args.mode)
    print(json.dumps(result, indent=2, default=lambda value: value.tolist()))


if __name__ == "__main__":
    main()
