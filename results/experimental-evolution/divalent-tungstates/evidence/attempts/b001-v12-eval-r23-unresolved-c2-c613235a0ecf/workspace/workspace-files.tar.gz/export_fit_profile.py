#!/usr/bin/env python3
"""Export the final GSAS-II powder profile in a portable CSV table."""

from __future__ import annotations

import csv
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
project = G2sc.G2Project(gpxfile=str(root / "final.gpx"))
profile = np.asarray(project.histogram(0).data["data"][1], dtype=float)
two_theta, observed, weight, calculated, background, difference = profile
sigma = np.where(weight > 0.0, 1.0 / np.sqrt(weight), np.nan)

with (root / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(
        [
            "two_theta_deg",
            "observed_counts",
            "calculated_counts",
            "difference_counts",
            "background_counts",
            "sigma_counts",
        ]
    )
    writer.writerows(
        zip(two_theta, observed, calculated, difference, background, sigma)
    )

print(f"wrote {len(two_theta)} rows to fit.csv")
