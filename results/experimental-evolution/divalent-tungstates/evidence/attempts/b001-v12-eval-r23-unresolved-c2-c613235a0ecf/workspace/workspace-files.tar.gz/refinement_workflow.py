#!/usr/bin/env python3
"""Reproducible GSAS-II trial refinements for the Pb-W-O powder pattern.

This script is intentionally explicit about neutral HAP terms so every source
and line-broadening comparison starts from the same physical baseline.
"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TRIALS = ROOT / ".tmp" / "gsas_trials"
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)

CANDIDATES = {
    "pbwo4_scheelite_9009811": "9009811",
    "pbwo4_scheelite_1527935": "1527935",
    "pbwo4_monoclinic_9007617": "9007617",
    "pb7w8o28_8_9016035": "9016035",
    "wo3_monoclinic_1528915": "1528915",
    "wo3_monoclinic_1563541": "1563541",
    "wo3_triclinic_2106293": "2106293",
    "wo3_orthorhombic_2107312": "2107312",
    "pb3o4_tetragonal_1537983": "1537983",
    "pb3o4_orthorhombic_9003043": "9003043",
    "pbo_tetragonal_9012700": "9012700",
    "pbo_orthorhombic_2310433": "2310433",
}


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def phase_path(key: str) -> Path:
    return cod_path(CANDIDATES[key])


def set_neutral_hap(phase, hist, scale: float) -> None:
    """Set genuinely neutral phase-specific profile/intensity terms."""
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [float(scale), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [100.0, 100.0, 1.0]  # micrometres
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]  # zero microstrain
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def configure_common(project, hist, background_order: int = 8) -> None:
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": background_order,
            "coeffs": [1600.0, -1000.0, 400.0, -150.0]
            + [0.0] * max(0, background_order - 4),
        },
    })
    # Keep the histogram scale fixed; phase scales carry the quantitative fit.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    sample = hist.data["Sample Parameters"]
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    inst = hist.data["Instrument Parameters"][0]
    starts = {
        "Zero": 0.42,
        "Polariz.": 0.5,
        "U": 5.0,
        "V": 0.0,
        "W": 10.0,
        "X": 3.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "I(L2)/I(L1)": 0.5,
    }
    for key, value in starts.items():
        if key in inst:
            inst[key][1] = value
            inst[key][2] = False

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-5


def set_bounds(project) -> None:
    # Bounds are deliberately broad. A hit invalidates a trial and is reported.
    for name in ("U", "W", "X"):
        project.set_Controls("parmMin", 0.0, variable=f":0:{name}")
        project.set_Controls("parmMax", 200.0, variable=f":0:{name}")
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.set_Controls("parmMin", 0.0, variable=":0:Zero")
    project.set_Controls("parmMax", 1.0, variable=":0:Zero")
    for phase in project.phases():
        project.set_Controls(
            "parmMin", 1.0e-8, variable=f"{phase.id}:0:Scale"
        )
        project.set_Controls(
            "parmMin", 0.005, variable=f"{phase.id}:0:Size;i"
        )
        project.set_Controls(
            "parmMax", 10.0, variable=f"{phase.id}:0:Size;i"
        )
        project.set_Controls(
            "parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i"
        )
        project.set_Controls(
            "parmMax", 20000.0, variable=f"{phase.id}:0:Mustrain;i"
        )


def create_project(
    output: Path,
    phase_keys: list[str],
    scales: list[float] | None = None,
    background_order: int = 8,
):
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
        fmthint="xye",
    )
    configure_common(project, hist, background_order)
    if scales is None:
        scales = [1.0] * len(phase_keys)
    for key, scale in zip(phase_keys, scales):
        phase = project.add_phase(
            str(phase_path(key)), phasename=key, histograms=[hist]
        )
        set_neutral_hap(phase, hist, scale)
    project.update_ids()
    set_bounds(project)
    project.save()
    return project, hist


def refine(project, label: str) -> dict:
    project.set_Frozen()
    project.save()
    project.do_refinements([{}])
    project.save()
    hist = project.histogram(0)
    result = {
        "step": label,
        "residuals": dict(hist.residuals),
        "frozen": project.get_Frozen(),
        "vary_list": [str(v) for v in project.data["Covariance"]["data"].get("varyList", [])],
        "refinement": dict(project.data["Covariance"]["data"].get("Rvals", {})),
    }
    return result


def state(project) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    out = {
        "residuals": dict(hist.residuals),
        "instrument": {
            key: {"value": value[1], "refine": bool(value[2])}
            for key, value in inst.items()
            if isinstance(value, list) and len(value) >= 3
        },
        "background": list(hist.data["Background"][0]),
        "sample": dict(hist.data["Sample Parameters"]),
        "phases": {},
        "frozen": project.get_Frozen(),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "mass": phase.data["General"]["Mass"],
            "scale": list(hap["Scale"]),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    try:
        out["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        out["mass_fractions_error"] = str(exc)
    return out


def initial_pair(
    output: Path, pb_key: str, wo_key: str, anchor_only: bool = False
) -> dict:
    project, hist = create_project(output, [pb_key, wo_key], [1.2, 0.25])
    log: list[dict] = []
    # Step 1: smooth background and positive scales from source cells.
    log.append(refine(project, "background_and_scales"))
    # Step 2: source-specific cells plus one common angular correction.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    log.append(refine(project, "cells_and_zero"))
    log.append(refine(project, "cells_and_zero_replay"))
    checkpoint = output.with_name(output.stem + "_cells_zero.gpx")
    project.save()
    shutil.copy2(output, checkpoint)
    if not anchor_only:
        # Step 3: diagnostic full common-profile trial. A bound result is not
        # advanced; phase-width trials always reopen the checkpoint above.
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
        log.append(refine(project, "common_profile"))
    return {
        "log": log,
        "state": state(project),
        "neutral_checkpoint": str(checkpoint),
    }


def width_trial(
    checkpoint: Path,
    output: Path,
    modes: dict[str, str],
    profile_terms: list[str],
) -> dict:
    """Replay a saved neutral checkpoint with requested per-phase widths.

    modes maps a phase name to neutral, size, strain, or combined.
    """
    shutil.copy2(checkpoint, output)
    project = G2sc.G2Project(str(output))
    hist = project.histogram(0)
    project.set_Frozen()
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
    inst = hist.data["Instrument Parameters"][0]
    profile_starts = {"U": 5.0, "W": 10.0, "X": 3.0}
    for key in profile_starts:
        inst[key][1] = profile_starts[key] if key in profile_terms else 0.0
    if profile_terms:
        hist.set_refinements({"Instrument Parameters": profile_terms})
    for phase in project.phases():
        # Reloaded complete values are neutral at the supplied checkpoint.
        set_neutral_hap(
            phase,
            hist,
            phase.data["Histograms"][hist.name]["Scale"][0],
        )
        mode = modes.get(phase.name, "neutral")
        if mode in ("size", "combined"):
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 0.10, "refine": True}}
            )
        if mode in ("strain", "combined"):
            hap = phase.data["Histograms"][hist.name]
            hap["Mustrain"][1][0] = 1000.0
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )
    set_bounds(project)
    project.save()
    label = "width_" + "_".join(f"{k}={v}" for k, v in modes.items())
    label += "_profile=" + ("".join(profile_terms) if profile_terms else "fixed")
    log = [refine(project, label)]
    if not project.get_Frozen():
        log.append(refine(project, label + "_replay"))
    return {"log": log, "state": state(project)}


def add_phase_anchor(
    base_project: Path, output: Path, phase_key: str, scale: float = 0.2
) -> dict:
    """Add one inventory candidate, refining scale before cell/profile terms."""
    shutil.copy2(base_project, output)
    project = G2sc.G2Project(str(output))
    hist = project.histogram(0)
    project.set_Frozen()
    # Hold all established structural/profile values while the candidate scale
    # is tested. Background and all phase scales remain open.
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]}
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
        phase.set_HAP_refinements({"Scale": True})
    added = project.add_phase(
        str(phase_path(phase_key)), phasename=phase_key, histograms=[hist]
    )
    set_neutral_hap(added, hist, scale)
    project.update_ids()
    set_bounds(project)
    project.save()
    log = [refine(project, "candidate_scale")]

    # Reopen complete cells and the one common angular correction before
    # deciding whether the candidate survives.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    log.append(refine(project, "candidate_cells_and_zero"))
    log.append(refine(project, "candidate_cells_and_zero_replay"))
    checkpoint = output.with_name(output.stem + "_cells_zero.gpx")
    project.save()
    shutil.copy2(output, checkpoint)
    return {
        "log": log,
        "state": state(project),
        "neutral_checkpoint": str(checkpoint),
    }


def nuisance_trial(base_project: Path, output: Path, mode: str) -> dict:
    """Replay the complete accepted model with one simple nuisance change."""
    shutil.copy2(base_project, output)
    project = G2sc.G2Project(str(output))
    hist = project.histogram(0)
    project.set_Frozen()
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    if mode.startswith("background"):
        order = int(mode.removeprefix("background"))
        old = list(hist.data["Background"][0][3:])
        coeffs = old[:order] + [0.0] * max(0, order - len(old))
        hist.set_refinements(
            {
                "Background": {
                    "type": "chebyschev-1",
                    "refine": True,
                    "no. coeffs": order,
                    "coeffs": coeffs,
                }
            }
        )
    if "polarization" in mode:
        inst["Polariz."][1] = 0.5
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    if "rough_b" in mode:
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.01, True]
    if "rough_ab" in mode:
        sample["SurfRoughA"] = [0.5, True]
        sample["SurfRoughB"] = [0.01, True]
    if "shl" in mode:
        inst["SH/L"][1] = 0.002
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})

    set_bounds(project)
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 5.0, variable=":0:SurfRoughB")
    project.set_Controls("parmMin", 0.0, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.05, variable=":0:SH/L")
    project.save()
    log = [refine(project, "nuisance_" + mode)]
    if not project.get_Frozen():
        log.append(refine(project, "nuisance_" + mode + "_replay"))
    return {"log": log, "state": state(project)}


def texture_trial(
    base_project: Path,
    output: Path,
    phase_name: str,
    axis: list[int],
) -> dict:
    """Test one low-index March-Dollase axis from a full saved model."""
    shutil.copy2(base_project, output)
    project = G2sc.G2Project(str(output))
    hist = project.histogram(0)
    project.set_Frozen()
    phase = project.phase(phase_name)
    if phase is None:
        raise ValueError(f"phase not found: {phase_name}")
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][3] = [int(v) for v in axis]
    phase.set_HAP_refinements({"Pref.Ori.": True})
    set_bounds(project)
    project.set_Controls(
        "parmMin", 0.2, variable=f"{phase.id}:0:MD"
    )
    project.set_Controls(
        "parmMax", 5.0, variable=f"{phase.id}:0:MD"
    )
    project.save()
    axis_label = "".join(str(v) for v in axis)
    log = [refine(project, f"texture_{phase_name}_{axis_label}")]
    if not project.get_Frozen():
        log.append(refine(project, f"texture_{phase_name}_{axis_label}_replay"))
    return {"log": log, "state": state(project)}


def anisotropy_trial(
    base_project: Path,
    output: Path,
    phase_name: str,
    kind: str,
    axis: list[int],
) -> dict:
    """Test symmetry-compatible uniaxial size or microstrain."""
    shutil.copy2(base_project, output)
    project = G2sc.G2Project(str(output))
    hist = project.histogram(0)
    project.set_Frozen()
    phase = project.phase(phase_name)
    if phase is None:
        raise ValueError(f"phase not found: {phase_name}")
    hap = phase.data["Histograms"][hist.name]
    axis = [int(v) for v in axis]
    if kind == "size":
        current = float(hap["Size"][1][0])
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "uniaxial",
                    "direction": axis,
                    "value": current,
                    "refine": True,
                }
            }
        )
    else:
        current = float(hap["Mustrain"][1][0])
        hap["Mustrain"][1][0] = current
        hap["Mustrain"][1][1] = current
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "uniaxial",
                    "direction": axis,
                    "refine": True,
                }
            }
        )
    set_bounds(project)
    for suffix in ("i", "a"):
        if kind == "size":
            project.set_Controls(
                "parmMin", 0.005, variable=f"{phase.id}:0:Size;{suffix}"
            )
            project.set_Controls(
                "parmMax", 10.0, variable=f"{phase.id}:0:Size;{suffix}"
            )
        else:
            project.set_Controls(
                "parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;{suffix}"
            )
            project.set_Controls(
                "parmMax", 20000.0, variable=f"{phase.id}:0:Mustrain;{suffix}"
            )
    project.save()
    axis_label = "".join(str(v) for v in axis)
    label = f"anisotropy_{kind}_{phase_name}_{axis_label}"
    log = [refine(project, label)]
    if not project.get_Frozen():
        log.append(refine(project, label + "_replay"))
    return {"log": log, "state": state(project)}


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    pair = sub.add_parser("pair")
    pair.add_argument("name")
    pair.add_argument("pb_key", choices=CANDIDATES)
    pair.add_argument("wo_key", choices=CANDIDATES)
    pair.add_argument("--anchor-only", action="store_true")
    width = sub.add_parser("width")
    width.add_argument("checkpoint", type=Path)
    width.add_argument("name")
    width.add_argument("modes", nargs="+", help="phase=neutral|size|strain|combined")
    width.add_argument(
        "--profile-terms",
        nargs="*",
        default=["U", "W", "X"],
        choices=["U", "W", "X"],
    )
    add = sub.add_parser("add")
    add.add_argument("base_project", type=Path)
    add.add_argument("name")
    add.add_argument("phase_key", choices=CANDIDATES)
    add.add_argument("--scale", type=float, default=0.2)
    nuisance = sub.add_parser("nuisance")
    nuisance.add_argument("base_project", type=Path)
    nuisance.add_argument("name")
    nuisance.add_argument(
        "mode",
        choices=[
            "background6",
            "background8",
            "background10",
            "background12",
            "polarization",
            "rough_b",
            "rough_ab",
            "polarization_rough_b",
            "polarization_rough_ab",
            "shl",
        ],
    )
    texture = sub.add_parser("texture")
    texture.add_argument("base_project", type=Path)
    texture.add_argument("name")
    texture.add_argument("phase_name")
    texture.add_argument("axis", type=int, nargs=3)
    anisotropy = sub.add_parser("anisotropy")
    anisotropy.add_argument("base_project", type=Path)
    anisotropy.add_argument("name")
    anisotropy.add_argument("phase_name")
    anisotropy.add_argument("kind", choices=["size", "strain"])
    anisotropy.add_argument("axis", type=int, nargs=3)
    args = parser.parse_args()

    TRIALS.mkdir(parents=True, exist_ok=True)
    if args.command == "pair":
        output = TRIALS / f"{args.name}.gpx"
        result = initial_pair(
            output, args.pb_key, args.wo_key, anchor_only=args.anchor_only
        )
    elif args.command == "width":
        output = TRIALS / f"{args.name}.gpx"
        modes = dict(item.split("=", 1) for item in args.modes)
        result = width_trial(
            args.checkpoint.resolve(), output, modes, args.profile_terms
        )
    elif args.command == "add":
        output = TRIALS / f"{args.name}.gpx"
        result = add_phase_anchor(
            args.base_project.resolve(), output, args.phase_key, args.scale
        )
    elif args.command == "nuisance":
        output = TRIALS / f"{args.name}.gpx"
        result = nuisance_trial(
            args.base_project.resolve(), output, args.mode
        )
    elif args.command == "texture":
        output = TRIALS / f"{args.name}.gpx"
        result = texture_trial(
            args.base_project.resolve(), output, args.phase_name, args.axis
        )
    else:
        output = TRIALS / f"{args.name}.gpx"
        result = anisotropy_trial(
            args.base_project.resolve(),
            output,
            args.phase_name,
            args.kind,
            args.axis,
        )
    result["project"] = str(output)
    print("TRIAL_RESULT=" + json.dumps(result, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
