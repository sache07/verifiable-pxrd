#!/usr/bin/env python3
"""Replay the accepted model and export the exact submitted GSAS-II state."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "scratch" / "branches" / "three_strain_ca3.gpx"
FINAL = ROOT / "final.gpx"

PHASE_METADATA = {
    "CaWO4_scheelite": {
        "display_name": "CaWO4 (scheelite)",
        "formula": "CaWO4",
        "space_group": "I 41/a",
        "space_group_number": 88,
        "cif_path": "CaWO4.cif",
        "structure_source": "COD 7219229",
    },
    "WO3_mono_2311041": {
        "display_name": "WO3 (monoclinic)",
        "formula": "WO3",
        "space_group": "P 1 21/c 1",
        "space_group_number": 14,
        "cif_path": "WO3.cif",
        "structure_source": "COD 2311041",
    },
    "Ca3WO6_double_perovskite": {
        "display_name": "Ca3WO6 (ordered double-perovskite type)",
        "formula": "Ca3WO6",
        "space_group": "P 1 21/n 1",
        "space_group_number": 14,
        "cif_path": "Ca3WO6.cif",
        "structure_source": "Ca3OsO6 prototype, COD 1562666; isovalent Os6+ to W6+ substitution",
    },
}


def scalar(value):
    if isinstance(value, np.generic):
        return value.item()
    return value


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    project.data["Controls"]["data"]["max cyc"] = 15
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    project.save()

    # Required fresh native replay from the saved accepted state.
    replay = G2sc.G2Project(str(FINAL))
    replay.refine(printFile=str(ROOT / "scratch" / "final_replay.lst"))
    replay.save()

    # Reopen once more; all exports below are read from exactly final.gpx.
    final = G2sc.G2Project(str(FINAL))
    phases = final.phases()
    if [phase.name for phase in phases] != list(PHASE_METADATA):
        raise RuntimeError(f"Unexpected final phase inventory: {[phase.name for phase in phases]}")

    hist = final.histogram(0)
    fractions = hist.ComputeMassFracs()
    if not np.isclose(sum(value[0] for value in fractions.values()), 1.0, atol=1.0e-10):
        raise RuntimeError(f"Mass fractions are not normalized: {fractions}")

    phase_results = []
    for phase in phases:
        metadata = PHASE_METADATA[phase.name]
        output_path = ROOT / metadata["cif_path"]
        phase.export_CIF(str(output_path))
        cell, cell_esd = phase.get_cell_and_esd()
        fraction, fraction_esd = fractions[phase.name]
        phase_results.append(
            {
                "name": metadata["display_name"],
                "formula": metadata["formula"],
                "space_group": metadata["space_group"],
                "space_group_number": metadata["space_group_number"],
                "cif_path": metadata["cif_path"],
                "weight_fraction": float(fraction),
                "weight_fraction_formal_esd": float(fraction_esd),
                "cell": {key: float(value) for key, value in cell.items()},
                "cell_formal_esd": {key: float(value) for key, value in cell_esd.items()},
                "structure_source": metadata["structure_source"],
            }
        )

    arrays = np.asarray(hist.data["data"][1], dtype=float)
    x, observed, weight, calculated, background, difference = arrays
    if not np.allclose(difference, observed - calculated, atol=1.0e-8):
        raise RuntimeError("Stored difference profile does not equal observed minus calculated")
    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity_counts",
                "calculated_intensity_counts",
                "difference_observed_minus_calculated_counts",
                "background_intensity_counts",
            ]
        )
        writer.writerows(zip(x, observed, calculated, difference, background))

    residuals = hist.data["data"][0]
    covariance = final.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    fit_statistics = {
        "Rwp_percent": float(residuals["wR"]),
        "Rp_percent": float(residuals["R"]),
        "Rwp_expected_percent": float(residuals["wRmin"]),
        "GOF": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "N_observations": int(rvals["Nobs"]),
        "N_variables": int(rvals["Nvars"]),
        "max_shift_over_esd": float(rvals["Max shft/sig"]),
        "converged": bool(rvals["converged"]),
        "Durbin_Watson": float(residuals["Durbin-Watson"]),
        "phase_R_F_percent": {
            phase.name: float(residuals[f"{phase.id}:0:Rf"])
            for phase in phases
        },
        "phase_R_F_squared_percent": {
            phase.name: float(residuals[f"{phase.id}:0:Rf^2"])
            for phase in phases
        },
    }
    result = {
        "phases": phase_results,
        "weight_fraction_basis": "Normalized over the three modeled crystalline phases; amorphous content was not determined.",
        "fit_statistics": fit_statistics,
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "measurement_range_two_theta_deg": [float(x[0]), float(x[-1])],
        "weighting": "Poisson approximation sigma=sqrt(observed counts), because pointwise uncertainties were not supplied.",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    verification = {
        "project": str(FINAL),
        "phase_names": [phase.name for phase in phases],
        "fraction_sum": sum(item["weight_fraction"] for item in phase_results),
        "fit_rows": int(len(x)),
        "fit_statistics": fit_statistics,
        "instrument": {
            key: scalar(hist.data["Instrument Parameters"][0][key][1])
            for key in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
        },
        "sample": {
            key: scalar(hist.data["Sample Parameters"][key][0])
            for key in ("Shift", "SurfRoughA", "SurfRoughB")
        },
    }
    (ROOT / "scratch" / "final_verification.json").write_text(json.dumps(verification, indent=2) + "\n")
    print(json.dumps(verification, indent=2))


if __name__ == "__main__":
    main()
