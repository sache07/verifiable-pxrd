#!/usr/bin/env python3
"""Challenge individual nuisance/profile/texture terms from the same base fit."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "scratch" / "trials" / "mono_2311041_shift.gpx"
OUTDIR = ROOT / "scratch" / "branches"


def summary(project: G2sc.G2Project, branch: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    covariance = project.data.get("Covariance", {}).get("data", {})
    result = {
        "branch": branch,
        "gpx": project.filename,
        "Rwp": hist.get_wR(),
        "Rvals": covariance.get("Rvals", {}),
        "instrument": {key: inst[key] for key in ("Polariz.", "SH/L", "U", "W", "X")},
        "sample": {key: sample[key] for key in ("Shift", "SurfRoughA", "SurfRoughB")},
        "mass_fractions": hist.ComputeMassFracs(),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "preferred_orientation": hap["Pref.Ori."],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    return result


def apply_branch(project: G2sc.G2Project, branch: str) -> None:
    hist = project.histogram(0)
    phases = project.phases()
    ca, wo = phases[:2]
    if branch == "polarization":
        hist.data["Instrument Parameters"][0]["Polariz."][1] = 0.5
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif branch == "roughness":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"][0] = 0.2
        sample["SurfRoughB"][0] = 0.05
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    elif branch == "shl":
        hist.data["Instrument Parameters"][0]["SH/L"][1] = 0.002
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    elif branch == "prune_x":
        xterm = hist.data["Instrument Parameters"][0]["X"]
        xterm[1] = 0.0
        xterm[2] = False
    elif branch == "add_ca3wo6":
        phase = project.add_phase(
            str(ROOT / "scratch" / "Ca3WO6_from_COD_1562666.cif"),
            phasename="Ca3WO6_double_perovskite",
            histograms=project.histograms(),
            fmthint="CIF",
        )
        hap = phase.getHAPvalues(hist.name)
        hap["Scale"][:] = [0.5, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})
    elif branch == "add_cao":
        phase = project.add_phase(
            "<RUN>/"
            "resources/b001-c05/cif/1/56/31/1563196.cif",
            phasename="CaO_rocksalt",
            histograms=project.histograms(),
            fmthint="CIF",
        )
        hap = phase.getHAPvalues(hist.name)
        hap["Scale"][:] = [0.05, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})
    elif branch.startswith("po_"):
        axes = {
            "po_001": [0, 0, 1],
            "po_100": [1, 0, 0],
            "po_110": [1, 1, 0],
            "po_101": [1, 0, 1],
            "po_112": [1, 1, 2],
        }
        po = ca.getHAPvalues(hist.name)["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = False
        po[3] = axes[branch]
        ca.set_HAP_refinements({"Pref.Ori.": True})
    elif branch == "size_ca":
        ca.set_HAP_refinements({"Size": {"type": "isotropic", "value": 10.0, "refine": True}})
    elif branch == "size_wo":
        wo.set_HAP_refinements({"Size": {"type": "isotropic", "value": 10.0, "refine": True}})
    elif branch == "strain_ca":
        strain = ca.getHAPvalues(hist.name)["Mustrain"]
        strain[0] = "isotropic"
        strain[1][0] = 0.0
        ca.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    elif branch == "strain_wo":
        strain = wo.getHAPvalues(hist.name)["Mustrain"]
        strain[0] = "isotropic"
        strain[1][0] = 0.0
        wo.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    elif branch == "size_ca3":
        ca3 = phases[2]
        ca3.set_HAP_refinements({"Size": {"type": "isotropic", "value": 10.0, "refine": True}})
    elif branch == "strain_ca3":
        ca3 = phases[2]
        strain = ca3.getHAPvalues(hist.name)["Mustrain"]
        strain[0] = "isotropic"
        strain[1][0] = 0.0
        ca3.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    else:
        raise ValueError(branch)


def main() -> None:
    choices = [
        "polarization", "roughness", "shl", "prune_x", "add_ca3wo6", "add_cao",
        "po_001", "po_100", "po_110", "po_101", "po_112",
        "size_ca", "size_wo", "strain_ca", "strain_wo",
        "size_ca3", "strain_ca3",
    ]
    parser = argparse.ArgumentParser()
    parser.add_argument("branch", choices=choices)
    parser.add_argument("--base", type=Path, default=BASE)
    parser.add_argument("--tag")
    args = parser.parse_args()
    OUTDIR.mkdir(parents=True, exist_ok=True)
    tag = args.tag or args.branch
    out = OUTDIR / f"{tag}.gpx"
    project = G2sc.G2Project(str(args.base), newgpx=str(out))
    project.data["Controls"]["data"]["max cyc"] = 15
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    apply_branch(project, args.branch)
    project.save()
    project.refine(printFile=str(OUTDIR / f"{tag}.lst"))
    project.save()
    replay = G2sc.G2Project(str(out))
    replay.refine(printFile=str(OUTDIR / f"{tag}_replay.lst"))
    replay.save()
    result = summary(replay, tag)
    (OUTDIR / f"{tag}.json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    print(json.dumps(result, default=float))


if __name__ == "__main__":
    main()
