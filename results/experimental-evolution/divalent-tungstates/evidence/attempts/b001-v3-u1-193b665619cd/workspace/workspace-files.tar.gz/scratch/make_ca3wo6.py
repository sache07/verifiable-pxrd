#!/usr/bin/env python3
"""Adapt COD 1562666 (Ca3OsO6) to the isovalent Ca3WO6 prototype."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parents[1]
PARENT = Path(
    "<RUN>/"
    "resources/b001-c05/cif/1/56/26/1562666.cif"
)
OUTPUT = ROOT / "scratch" / "Ca3WO6_from_COD_1562666.cif"


def main() -> None:
    structure = Structure.from_file(PARENT)
    structure.replace_species({"Os": "W"})
    CifWriter(structure, symprec=0.01, refine_struct=False).write_file(OUTPUT)
    distances = structure.distance_matrix.copy()
    distances[distances < 1.0e-8] = 999.0
    print("parent", PARENT)
    print("output", OUTPUT)
    print("composition", structure.composition)
    print("space_group", structure.get_space_group_info(symprec=0.01))
    print("ordered", structure.is_ordered)
    print("minimum_distance_A", float(distances.min()))
    for index, site in enumerate(structure):
        if site.specie.symbol != "W":
            continue
        neighbors = sorted(
            (neighbor.nn_distance, neighbor.species_string)
            for neighbor in structure.get_neighbors(site, 2.5)
        )
        print("W_site", index, "neighbors", neighbors)


if __name__ == "__main__":
    main()
