#!/usr/bin/env python3
"""Quantitative residual and peak-width checks for the final model choice."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIpwd as G2pwd


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "scratch" / "branches" / "three_phase.gpx"
STRAIN = ROOT / "final.gpx"


def arrays(path: Path) -> tuple[G2sc.G2Project, np.ndarray]:
    project = G2sc.G2Project(str(path))
    return project, np.asarray(project.histogram(0).data["data"][1], dtype=float)


def weighted_rwp(data: np.ndarray, lo: float, hi: float) -> float:
    x, yo, w, yc = data[:4]
    use = (x >= lo) & (x < hi)
    return 100.0 * np.sqrt(np.sum(w[use] * (yo[use] - yc[use]) ** 2) / np.sum(w[use] * yo[use] ** 2))


def window_sse(data: np.ndarray, center: float, half_width: float = 0.25) -> float:
    x, yo, w, yc = data[:4]
    use = np.abs(x - center) <= half_width
    return float(np.sum(w[use] * (yo[use] - yc[use]) ** 2))


def reflection_fwhm(project: G2sc.G2Project, targets: list[float]) -> list[dict]:
    refs = project.histogram(0).data["Reflection Lists"]["Ca3WO6_double_perovskite"]["RefList"]
    output = []
    for target in targets:
        ref = min(refs, key=lambda item: abs(float(item[5]) - target))
        h, k, l, _, d, pos, sig, gam = ref[:8]
        gaussian_sigma_deg = np.sqrt(max(sig, 0.0001)) / 100.0
        lorentzian_fwhm_deg = gam / 100.0
        output.append(
            {
                "hkl": [int(h), int(k), int(l)],
                "two_theta_deg": float(pos),
                "d_angstrom": float(d),
                "gaussian_sigma_deg": float(gaussian_sigma_deg),
                "lorentzian_fwhm_deg": float(lorentzian_fwhm_deg),
                "total_fwhm_deg": float(G2pwd.getgamFW(lorentzian_fwhm_deg, gaussian_sigma_deg)),
            }
        )
    return output


def gaussian_smooth(values: np.ndarray, sigma: float) -> np.ndarray:
    radius = int(np.ceil(4.0 * sigma))
    grid = np.arange(-radius, radius + 1, dtype=float)
    kernel = np.exp(-0.5 * (grid / sigma) ** 2)
    kernel /= kernel.sum()
    return np.convolve(values, kernel, mode="same")


def spaced_extrema(values: np.ndarray, minimum_distance: int, count: int) -> list[int]:
    candidates = np.flatnonzero(
        (np.abs(values[1:-1]) >= np.abs(values[:-2]))
        & (np.abs(values[1:-1]) > np.abs(values[2:]))
    ) + 1
    accepted: list[int] = []
    for idx in sorted(candidates, key=lambda item: abs(values[item]), reverse=True):
        if all(abs(idx - other) >= minimum_distance for other in accepted):
            accepted.append(int(idx))
        if len(accepted) == count:
            break
    return accepted


def main() -> None:
    base_project, base = arrays(BASE)
    strain_project, strain = arrays(STRAIN)
    assert np.allclose(base[0], strain[0])

    bins = [(9.90, 30.0), (30.0, 50.0), (50.0, 70.0), (70.0, 100.095)]
    regional = [
        {
            "range_deg": [lo, hi],
            "Rwp_no_Ca3_strain_percent": weighted_rwp(base, lo, hi),
            "Rwp_with_Ca3_strain_percent": weighted_rwp(strain, lo, hi),
        }
        for lo, hi in bins
    ]

    targets = [18.712, 22.018, 31.39, 45.13, 55.20, 65.77, 74.72, 92.66]
    local = []
    for target in targets:
        sse0 = window_sse(base, target)
        sse1 = window_sse(strain, target)
        local.append(
            {
                "center_deg": target,
                "half_width_deg": 0.25,
                "weighted_sse_no_Ca3_strain": sse0,
                "weighted_sse_with_Ca3_strain": sse1,
                "sse_ratio_with_over_without": sse1 / sse0,
            }
        )

    x, yo, w, yc, yb, diff = strain
    z = diff * np.sqrt(w)
    smooth = gaussian_smooth(z, sigma=4.0)
    ranked = spaced_extrema(smooth, minimum_distance=18, count=30)
    residual_extrema = [
        {
            "two_theta_deg": float(x[idx]),
            "smoothed_standardized_residual": float(smooth[idx]),
            "raw_difference_counts": float(diff[idx]),
        }
        for idx in ranked
    ]

    result = {
        "regional_Rwp": regional,
        "Ca3WO6_diagnostic_windows": local,
        "Ca3WO6_calculated_widths": reflection_fwhm(strain_project, [18.712, 45.13, 74.72, 92.66]),
        "largest_smoothed_standardized_residual_extrema": residual_extrema,
        "standardized_residual_mean": float(np.mean(z)),
        "standardized_residual_rms": float(np.sqrt(np.mean(z**2))),
    }
    (ROOT / "scratch" / "final_diagnostics.json").write_text(json.dumps(result, indent=2) + "\n")

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
