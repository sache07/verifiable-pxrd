#!/usr/bin/env python3
"""Run controlled GSAS-II candidate and angular-correction trials."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SCRATCH = ROOT / "scratch"
TRIALS = SCRATCH / "trials"
CIF_ROOT = Path(
    "<RUN>/"
    "resources/b001-c05/cif"
)
CAWO4_ID = "7219229"
WO3_CANDIDATES = {
    "mono_2311041": "2311041",
    "mono_1528915": "1528915",
    "triclinic_2106293": "2106293",
    "orthorhombic_2107312": "2107312",
}


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_xye() -> Path:
    source = ROOT / "inputs" / "pattern.csv"
    target = SCRATCH / "pattern.xye"
    with source.open(newline="") as src, target.open("w", newline="") as dst:
        reader = csv.DictReader(src)
        writer = csv.writer(dst, delimiter=" ")
        for row in reader:
            y = float(row["intensity"])
            writer.writerow(
                (
                    row["two_theta_deg"],
                    row["intensity"],
                    f"{math.sqrt(max(y, 1.0)):.8f}",
                )
            )
    return target


def set_neutral_hap(phase, hist_name: str, initial_scale: float) -> None:
    hap = phase.getHAPvalues(hist_name)
    hap["Scale"][:] = [initial_scale, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    size = hap["Size"]
    size[0] = "isotropic"
    size[1][0] = 1000.0
    size[1][1] = 1000.0
    size[2] = [False for _ in size[2]]
    size[5] = [False for _ in size[5]]
    strain = hap["Mustrain"]
    strain[0] = "isotropic"
    strain[1][0] = 0.0
    strain[1][1] = 0.0
    strain[2] = [False for _ in strain[2]]
    strain[5] = [False for _ in strain[5]]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]


def project_summary(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    residuals = dict(hist.data["data"][0])
    covariance = project.data.get("Covariance", {}).get("data", {})
    result = {
        "label": label,
        "gpx": project.filename,
        "wR_percent": hist.get_wR(),
        "residuals": {
            key: value
            for key, value in residuals.items()
            if key in {"R", "wR", "Rb", "wRb", "wRmin", "Nobs"}
        },
        "Rvals": covariance.get("Rvals", {}),
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
        },
        "sample": {
            key: sample[key][0]
            for key in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "phases": {},
    }
    try:
        fractions = hist.ComputeMassFracs()
    except Exception as exc:
        fractions = {"error": repr(exc)}
    result["mass_fractions"] = fractions
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "short_distances": phase.ShortDistances(),
        }
    print("SUMMARY", json.dumps(result, default=float, sort_keys=True))
    return result


def refine(project: G2sc.G2Project, label: str) -> dict:
    project.save()
    project.refine(printFile=str(Path(project.filename).with_suffix(f".{label}.lst")))
    return project_summary(project, label)


def build_project(candidate_name: str, branch: str) -> G2sc.G2Project:
    cod_id = WO3_CANDIDATES[candidate_name]
    gpx_path = TRIALS / f"{candidate_name}_{branch}.gpx"
    project = G2sc.G2Project(newgpx=str(gpx_path))
    project.add_phase(
        str(cif_path(CAWO4_ID)),
        phasename="CaWO4_scheelite",
        fmthint="CIF",
    )
    project.add_phase(
        str(cif_path(cod_id)),
        phasename=f"WO3_{candidate_name}",
        fmthint="CIF",
    )
    hist = project.add_powder_histogram(
        str(write_xye()),
        str(SCRATCH / "instrument.instprm"),
        phases="all",
        fmthint="xye",
    )
    hist.Limits("lower", 9.90343322)
    hist.Limits("upper", 100.09455322)
    hist.data["Sample Parameters"]["Scale"][:] = [1.0, False]
    background = hist.data["Background"][0]
    background[:] = ["chebyschev-1", True, 10, 1500.0] + [0.0] * 9

    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 80.0, "V": 0.0, "W": 60.0, "X": 5.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.002}.items():
        inst[key][1] = value
        inst[key][2] = False
    sample = hist.data["Sample Parameters"]
    sample["Shift"][:] = [0.0, False]
    if branch == "zero":
        inst["Zero"][:] = [inst["Zero"][0], -0.16, False]
    elif branch == "shift":
        inst["Zero"][:] = [inst["Zero"][0], 0.0, False]
        sample["Shift"][:] = [280.0, False]
    else:
        raise ValueError(branch)

    for i, phase in enumerate(project.phases()):
        phase.set_refinements({"Cell": False})
        phase.set_refinements({"Atoms": {"all": " "}})
        set_neutral_hap(phase, hist.name, 1.0 if i == 0 else 0.2)

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-5
    project.save()
    return project


def run_trial(candidate_name: str, branch: str) -> dict:
    project = build_project(candidate_name, branch)
    hist = project.histogram(0)
    phases = project.phases()

    # Linear/background terms first; keep the histogram scale fixed.
    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    refine(project, "01_bg_scales")

    # Use one common angular correction only.
    if branch == "zero":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    else:
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "02_angular")

    # Refit both cells together with background, phase scales and correction.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "03_cells")

    # Establish a low-dimensional nonnegative common profile in stages.
    for sequence, parameter in enumerate(("W", "U", "X"), start=4):
        hist.set_refinements({"Instrument Parameters": [parameter]})
        refine(project, f"{sequence:02d}_{parameter}")

    # Fresh replay from disk with the same native parameter flags.
    project.save()
    replay = G2sc.G2Project(project.filename)
    refine(replay, "07_replay")
    summary = project_summary(replay, "final")
    summary_path = TRIALS / f"{candidate_name}_{branch}.json"
    summary_path.write_text(json.dumps(summary, indent=2, default=float) + "\n")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", choices=WO3_CANDIDATES)
    parser.add_argument("branch", choices=("zero", "shift"))
    args = parser.parse_args()
    TRIALS.mkdir(parents=True, exist_ok=True)
    run_trial(args.candidate, args.branch)


if __name__ == "__main__":
    main()
