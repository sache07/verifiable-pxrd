#!/usr/bin/env python3
"""Create a minimal two-phase GSAS-II project and print its defaults."""

from __future__ import annotations

import csv
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
CIF_ROOT = Path(
    "<RUN>/"
    "resources/b001-c05/cif"
)


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_xye() -> Path:
    source = ROOT / "inputs" / "pattern.csv"
    target = ROOT / "scratch" / "pattern.xye"
    with source.open(newline="") as src, target.open("w", newline="") as dst:
        reader = csv.DictReader(src)
        writer = csv.writer(dst, delimiter=" ")
        for row in reader:
            y = float(row["intensity"])
            writer.writerow((row["two_theta_deg"], row["intensity"], math.sqrt(max(y, 1.0))))
    return target


def main() -> None:
    xye = write_xye()
    gpx_path = ROOT / "scratch" / "probe.gpx"
    project = G2sc.G2Project(newgpx=str(gpx_path))
    project.add_phase(
        str(cif_path("7219229")),
        phasename="CaWO4_scheelite",
        fmthint="CIF",
    )
    project.add_phase(
        str(cif_path("2311041")),
        phasename="WO3_monoclinic",
        fmthint="CIF",
    )
    hist = project.add_powder_histogram(
        str(xye),
        str(ROOT / "scratch" / "instrument.instprm"),
        phases="all",
        fmthint="xye",
    )
    hist.Limits("lower", 9.90343322)
    hist.Limits("upper", 100.09455322)
    print("Histogram", hist.name)
    print("Background", hist.data["Background"])
    print("Instrument", hist.data["Instrument Parameters"])
    print("Sample", hist.data["Sample Parameters"])
    for phase in project.phases():
        print("Phase", phase.name)
        print("Cell", phase.get_cell())
        print("HAP", phase.getHAPvalues(hist.name))
        print("Short distances", phase.ShortDistances())
    project.save()


if __name__ == "__main__":
    main()
