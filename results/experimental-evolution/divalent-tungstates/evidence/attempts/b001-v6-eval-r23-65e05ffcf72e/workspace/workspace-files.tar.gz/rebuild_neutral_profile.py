#!/usr/bin/env python3
"""Rebuild the selected inventory with truly neutral phase broadening."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    work = Path(__file__).resolve().parent
    out = work / "neutral_common.gpx"
    project = G2sc.G2Project(
        str(work / "final_texture_SrCO3_pnma_001.gpx"), newgpx=str(out)
    )
    histogram = project.histogram(0)

    for phase in project.phases():
        hap = phase.getHAPvalues(histogram.name)
        size = hap["Size"]
        size[0] = "isotropic"
        size[1] = [1.0e6, 1.0e6, 1.0]
        size[2] = [False, False, False]
        size[5] = [False] * len(size[5])

        strain = hap["Mustrain"]
        strain[0] = "isotropic"
        strain[1] = [0.0, 0.0, 1.0]
        strain[2] = [False, False, False]
        strain[5] = [False] * len(strain[5])

    histogram.InstrumentParameters["SH/L"][1] = 0.002
    histogram.InstrumentParameters["SH/L"][2] = False
    project.set_Controls("parmMin", 0.0, ":0:W")
    project.set_Controls("parmMin", 0.0, ":0:X")
    project.set_Controls("cycles", 12)
    for _ in range(4):
        project.refine()
    project.save()

    cov = project.data["Covariance"]["data"]
    result = {
        "wR": histogram.residuals["wR"],
        "R": histogram.residuals["R"],
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "max_shift_over_sigma": cov.get("Rvals", {}).get("Max shft/sig"),
        "mass_fractions": histogram.ComputeMassFracs(),
        "instrument": {
            key: histogram.InstrumentParameters[key][1]
            for key in ["Polariz.", "U", "W", "X", "SH/L"]
        },
        "phase_broadening": {
            phase.name: {
                "Size": phase.getHAPvalues(histogram.name)["Size"][1][0],
                "Mustrain": phase.getHAPvalues(histogram.name)["Mustrain"][1][0],
            }
            for phase in project.phases()
        },
        "project": str(out),
    }
    print("NEUTRAL_RESULT", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
