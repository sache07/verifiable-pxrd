#!/usr/bin/env python3
"""Challenge one phase-broadening term from the clean common-profile model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("phase", choices=["SrWO4", "WO3_triclinic", "SrCO3_pnma"])
    parser.add_argument("term", choices=["size", "strain"])
    args = parser.parse_args()

    work = Path(__file__).resolve().parent
    out = work / f"broadening_{args.name}.gpx"
    project = G2sc.G2Project(str(work / "final_work.gpx"), newgpx=str(out))
    phase = project.phase(args.phase)
    if args.term == "size":
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": 10.0,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )
    else:
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )
    project.set_Controls("cycles", 10)
    project.refine()
    project.save()
    histogram = project.histogram(0)
    result = {
        "trial": args.name,
        "phase": args.phase,
        "term": args.term,
        "wR": histogram.residuals["wR"],
        "max_shift_over_sigma": project.data["Covariance"]["data"]
        .get("Rvals", {})
        .get("Max shft/sig"),
        "W": histogram.InstrumentParameters["W"][1],
        "X": histogram.InstrumentParameters["X"][1],
        "hap": phase.getHAPvalues(histogram.name),
        "project": str(out),
    }
    print("BROADENING_RESULT", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
