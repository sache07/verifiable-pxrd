#!/usr/bin/env python3
"""Compare a single WO3 source with identical neutral nuisance controls."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


CANDIDATES = {
    "gamma": ("variant_gamma_final.gpx", "WO3_gamma"),
    "triclinic": ("variant_triclinic_final.gpx", "WO3_triclinic"),
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", choices=CANDIDATES)
    parser.add_argument("axis", nargs=3, type=int)
    args = parser.parse_args()

    work = Path(__file__).resolve().parent
    source, wo3_name = CANDIDATES[args.candidate]
    axis_name = "".join("m" + str(-v) if v < 0 else str(v) for v in args.axis)
    out = work / f"candidate_{args.candidate}_{axis_name}.gpx"
    project = G2sc.G2Project(str(work / source), newgpx=str(out))
    histogram = project.histogram(0)

    for phase in project.phases():
        hap = phase.getHAPvalues(histogram.name)
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    srwo4_pref = project.phase("SrWO4").getHAPvalues(histogram.name)["Pref.Ori."]
    srwo4_pref[0:4] = ["MD", 0.69, True, [1, 1, 1]]
    carbonate_pref = project.phase("SrCO3_pnma").getHAPvalues(histogram.name)["Pref.Ori."]
    carbonate_pref[0:4] = ["MD", 0.83, True, [0, 0, 1]]

    wo3 = project.phase(wo3_name)
    wo3_hap = wo3.getHAPvalues(histogram.name)
    wo3_hap["Mustrain"][1] = [4000.0, 0.0, 1.0]
    wo3_hap["Mustrain"][2] = [True, False, False]
    wo3_pref = wo3_hap["Pref.Ori."]
    wo3_pref[0:4] = ["MD", 1.0, True, list(args.axis)]

    histogram.InstrumentParameters["SH/L"][1] = 0.002
    histogram.InstrumentParameters["SH/L"][2] = False
    project.set_Controls("parmMin", 0.0, ":0:W")
    project.set_Controls("parmMin", 0.0, ":0:X")
    project.set_Controls("parmMin", 0.0, f"{wo3.id}:0:Mustrain;i")
    project.set_Controls("parmMin", 0.2, f"{wo3.id}:0:MD")
    project.set_Controls("parmMax", 5.0, f"{wo3.id}:0:MD")
    project.set_Controls("cycles", 12)
    for _ in range(4):
        project.refine()
    project.save()

    cov = project.data["Covariance"]["data"]
    result = {
        "candidate": args.candidate,
        "axis": args.axis,
        "wR": histogram.residuals["wR"],
        "R": histogram.residuals["R"],
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "max_shift_over_sigma": cov.get("Rvals", {}).get("Max shft/sig"),
        "mass_fractions": histogram.ComputeMassFracs(),
        "wo3_strain": wo3_hap["Mustrain"][1][0],
        "wo3_pref": wo3_pref,
        "wo3_cell": wo3.get_cell(),
        "instrument": {
            key: histogram.InstrumentParameters[key][1]
            for key in ["Polariz.", "U", "W", "X", "SH/L"]
        },
        "project": str(out),
    }
    print("CANDIDATE_RESULT", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
