#!/usr/bin/env python3
"""Re-challenge a WO3 record under the accepted width/texture model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("source_gpx")
    parser.add_argument("wo3_phase")
    args = parser.parse_args()

    work = Path(__file__).resolve().parent
    output = work / f"variant_{args.name}.gpx"
    project = G2sc.G2Project(str(work / args.source_gpx), newgpx=str(output))
    histogram = project.histogram(0)
    srwo4 = project.phase("SrWO4")
    wo3 = project.phase(args.wo3_phase)

    pref = srwo4.getHAPvalues(histogram.name)["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 0.70
    pref[2] = True
    pref[3] = [1, 1, 1]
    strain = wo3.getHAPvalues(histogram.name)["Mustrain"]
    strain[0] = "isotropic"
    strain[1][0] = 5500.0
    strain[1][2] = 1.0
    strain[2] = [True, False, False]
    strain[5] = [False] * len(strain[5])

    project.set_Controls("parmMin", 0.2, "0:0:MD")
    project.set_Controls("parmMax", 5.0, "0:0:MD")
    project.set_Controls("cycles", 10)
    for _ in range(3):
        project.refine()
    project.save()

    result = {
        "name": args.name,
        "wR": histogram.residuals["wR"],
        "R": histogram.residuals["R"],
        "GOF": project.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "max_shift_over_sigma": project.data["Covariance"]["data"]
        .get("Rvals", {})
        .get("Max shft/sig"),
        "mass_fractions": histogram.ComputeMassFracs(),
        "wo3_cell": wo3.get_cell(),
        "wo3_strain": strain[1][0],
        "srwo4_md": pref[1],
        "instrument": {
            key: histogram.InstrumentParameters[key][1]
            for key in ["Polariz.", "U", "W", "X", "SH/L"]
        },
        "project": str(output),
    }
    print("VARIANT_RESULT", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
