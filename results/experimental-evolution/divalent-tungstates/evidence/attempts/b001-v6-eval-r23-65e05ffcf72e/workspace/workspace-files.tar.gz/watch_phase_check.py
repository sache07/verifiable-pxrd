#!/usr/bin/env python3
"""Re-challenge plausible weak phases under the clean accepted profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


CIF_ROOT = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)
WATCH = {
    "sr3w2o9": ("2311977", "Sr3W2O9_watch"),
    "srco3_rhombohedral": ("1539128", "SrCO3_rhombohedral_watch"),
    "wo3_triclinic": ("2106293", "WO3_triclinic_watch"),
    "wo3_gamma": ("1528915", "WO3_gamma_watch"),
}


def cod(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", choices=WATCH)
    args = parser.parse_args()

    work = Path(__file__).resolve().parent
    cod_id, phase_name = WATCH[args.candidate]
    out = work / f"watch_{args.candidate}.gpx"
    project = G2sc.G2Project(
        str(work / "neutral_WO3_alt_monoclinic_strain.gpx"), newgpx=str(out)
    )
    histogram = project.histogram(0)
    phase = project.add_phase(
        str(cod(cod_id)), phasename=phase_name, histograms=[histogram], fmthint="CIF"
    )
    hap = phase.getHAPvalues(histogram.name)
    hap["Scale"] = [0.03, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    phase.data["General"]["Cell"][0] = False

    project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Scale")
    project.set_Controls("cycles", 12)
    for _ in range(4):
        project.refine()
    project.save()

    cov = project.data["Covariance"]["data"]
    scale_name = f"{phase.id}:0:Scale"
    scale_result = None
    for name, value, sigma in zip(
        cov.get("varyList", []), cov.get("variables", []), cov.get("sig", [])
    ):
        if str(name) == scale_name:
            scale_result = {"value": float(value), "sigma": float(sigma)}
    result = {
        "candidate": args.candidate,
        "phase": phase_name,
        "wR": histogram.residuals["wR"],
        "R": histogram.residuals["R"],
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "max_shift_over_sigma": cov.get("Rvals", {}).get("Max shft/sig"),
        "scale": phase.getHAPvalues(histogram.name)["Scale"],
        "scale_covariance": scale_result,
        "mass_fractions": histogram.ComputeMassFracs(),
        "project": str(out),
    }
    print("WATCH_RESULT", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
