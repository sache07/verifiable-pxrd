#!/usr/bin/env python3
"""Replay one final nuisance-model challenge from the selected inventory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def covariance_matches(project: G2sc.G2Project, needle: str) -> dict[str, dict[str, float]]:
    cov = project.data["Covariance"]["data"]
    names = cov.get("varyList", [])
    values = cov.get("variables", [])
    sigmas = cov.get("sig", [])
    return {
        str(name): {"value": float(value), "sigma": float(sigma)}
        for name, value, sigma in zip(names, values, sigmas)
        if needle in str(name)
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("trial", choices=["shl", "carbonate_strain"])
    parser.add_argument("--source", default="variant_altmono_final.gpx")
    parser.add_argument("--tag", default="")
    args = parser.parse_args()

    work = Path(__file__).resolve().parent
    suffix = f"_{args.tag}" if args.tag else ""
    out = work / f"final_check_{args.trial}{suffix}.gpx"
    project = G2sc.G2Project(
        str(work / args.source), newgpx=str(out)
    )
    histogram = project.histogram(0)

    if args.trial == "shl":
        histogram.InstrumentParameters["SH/L"][1] = 0.01
        histogram.InstrumentParameters["SH/L"][2] = True
        project.set_Controls("parmMin", 0.002, ":0:SH/L")
        project.set_Controls("parmMax", 0.10, ":0:SH/L")
        needle = "SH/L"
    else:
        carbonate = project.phase("SrCO3_pnma")
        strain = carbonate.getHAPvalues(histogram.name)["Mustrain"]
        strain[0] = "isotropic"
        strain[1][0] = 1000.0
        strain[1][2] = 1.0
        strain[2] = [True, False, False]
        strain[5] = [False] * len(strain[5])
        project.set_Controls("parmMin", 0.0, "2:0:Mustrain;i")
        needle = "Mustrain"

    project.set_Controls("cycles", 10)
    for _ in range(3):
        project.refine()
    project.save()

    result = {
        "trial": args.trial,
        "wR": histogram.residuals["wR"],
        "R": histogram.residuals["R"],
        "GOF": project.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "max_shift_over_sigma": project.data["Covariance"]["data"]
        .get("Rvals", {})
        .get("Max shft/sig"),
        "SH/L": histogram.InstrumentParameters["SH/L"][1],
        "carbonate_mustrain": project.phase("SrCO3_pnma")
        .getHAPvalues(histogram.name)["Mustrain"][1][0],
        "parameters": covariance_matches(project, needle),
        "mass_fractions": histogram.ComputeMassFracs(),
        "project": str(out),
        "source": args.source,
    }
    print("FINAL_CHECK_RESULT", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
