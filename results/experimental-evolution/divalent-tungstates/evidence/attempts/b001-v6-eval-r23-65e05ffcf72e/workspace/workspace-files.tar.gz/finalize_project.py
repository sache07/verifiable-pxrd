#!/usr/bin/env python3
"""Freeze, replay, and export the selected GSAS-II refinement."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
PHASE_INFO = {
    "SrWO4": {
        "display_name": "SrWO4 (scheelite)",
        "formula": "SrWO4",
        "space_group": "I 41/a",
        "space_group_number": 88,
        "cif": "phase_1_SrWO4.cif",
        "structure_source": "SrMoO4 COD 2300460; isovalent Mo6+ -> W6+ prototype",
    },
    "WO3_alt_monoclinic": {
        "display_name": "WO3 (monoclinic)",
        "formula": "WO3",
        "space_group": "P 1 21/c 1",
        "space_group_number": 14,
        "cif": "phase_2_WO3.cif",
        "structure_source": "COD 2311041",
    },
    "SrCO3_pnma": {
        "display_name": "SrCO3 (strontianite)",
        "formula": "SrCO3",
        "space_group": "P n m a",
        "space_group_number": 62,
        "cif": "phase_3_SrCO3.cif",
        "structure_source": "COD 9008198",
    },
}


def enforce_model(project: G2sc.G2Project) -> None:
    histogram = project.histogram(0)
    instrument = histogram.InstrumentParameters
    for key, value, refine in [
        ("Lam1", 1.540598, False),
        ("Lam2", 1.544426, False),
        ("I(L2)/I(L1)", 0.5, False),
        ("Zero", 0.0, False),
        ("U", 0.0, False),
        ("V", 0.0, False),
        ("Y", 0.0, False),
        ("Z", 0.0, False),
        ("SH/L", 0.002, False),
    ]:
        instrument[key][1] = value
        instrument[key][2] = refine
    for key in ["W", "X", "Polariz."]:
        instrument[key][2] = True

    sample = histogram.SampleParameters
    sample["Scale"] = [1.0, False]
    sample["Shift"][1] = True
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    histogram.data["Background"][0][1] = True

    texture = {
        "SrWO4": (0.69, [1, 1, 1]),
        "WO3_alt_monoclinic": (1.25, [1, 0, -1]),
        "SrCO3_pnma": (0.83, [0, 0, 1]),
    }
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        hap = phase.getHAPvalues(histogram.name)
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        if phase.name == "WO3_alt_monoclinic":
            hap["Mustrain"][1][0] = 4400.0
            hap["Mustrain"][2] = [True, False, False]
        else:
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2] = [False, False, False]
        md, axis = texture[phase.name]
        hap["Pref.Ori."][0:4] = ["MD", md, True, axis]
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]

    project.set_Controls("parmMin", 0.0, ":0:W")
    project.set_Controls("parmMin", 0.0, ":0:X")
    project.set_Controls("parmMin", 0.0, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    project.set_Controls("parmMin", 0.0, "1:0:Mustrain;i")
    for phase in project.phases():
        project.set_Controls("parmMin", 0.2, f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 5.0, f"{phase.id}:0:MD")
    project.set_Controls("cycles", 12)


def replay(project: G2sc.G2Project, count: int) -> None:
    for _ in range(count):
        project.refine()
    project.save()


def main() -> None:
    final_path = WORK / "final.gpx"
    project = G2sc.G2Project(
        str(WORK / "neutral_WO3_alt_monoclinic_strain.gpx"),
        newgpx=str(final_path),
    )
    enforce_model(project)
    replay(project, 4)

    # Required save/reopen/full-range replay before the submitted exports.
    project = G2sc.G2Project(str(final_path))
    enforce_model(project)
    replay(project, 2)

    histogram = project.histogram(0)
    mass = histogram.ComputeMassFracs()
    mass_total = sum(value for value, _ in mass.values())
    residuals = histogram.residuals
    covariance = project.data["Covariance"]["data"]
    rvals = covariance.get("Rvals", {})

    phase_results = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        cif_path = WORK / info["cif"]
        phase.export_CIF(str(cif_path))
        fraction, sigma = mass[phase.name]
        cell = phase.get_cell()
        phase_results.append(
            {
                "name": info["display_name"],
                "formula": info["formula"],
                "space_group": info["space_group"],
                "space_group_number": info["space_group_number"],
                "cif_path": info["cif"],
                "structure_source": info["structure_source"],
                "weight_fraction": fraction / mass_total,
                "weight_fraction_esd": sigma / mass_total,
                "cell": {
                    "a_angstrom": cell["length_a"],
                    "b_angstrom": cell["length_b"],
                    "c_angstrom": cell["length_c"],
                    "alpha_deg": cell["angle_alpha"],
                    "beta_deg": cell["angle_beta"],
                    "gamma_deg": cell["angle_gamma"],
                    "volume_angstrom3": cell["volume"],
                },
                "phase_fit_statistics": {
                    "Rf_percent": residuals.get(f"{phase.id}:0:Rf"),
                    "Rf2_percent": residuals.get(f"{phase.id}:0:Rf^2"),
                    "reflection_count": residuals.get(f"{phase.id}:0:Nref"),
                },
            }
        )

    x, observed, weights, calculated, background, _ = histogram.data["data"][1]
    with (WORK / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        for xx, yo, yc, yb in zip(x, observed, calculated, background):
            writer.writerow(
                [
                    f"{xx:.8f}",
                    f"{yo:.8f}",
                    f"{yc:.8f}",
                    f"{yo - yc:.8f}",
                    f"{yb:.8f}",
                ]
            )

    result = {
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "phases": phase_results,
        "fit_statistics": {
            "Rwp_percent": residuals["wR"],
            "Rp_percent": residuals["R"],
            "Rexp_percent": residuals["wRmin"],
            "goodness_of_fit": rvals.get("GOF"),
            "background_corrected_Rwp_percent": residuals.get("wRb"),
            "background_corrected_Rp_percent": residuals.get("Rb"),
            "chi_square": rvals.get("chisq"),
            "number_of_observations": rvals.get("Nobs"),
            "number_of_refined_variables": rvals.get("Nvars"),
            "max_shift_over_sigma": rvals.get("Max shft/sig"),
            "two_theta_range_deg": [float(x[0]), float(x[-1])],
        },
        "refinement_model": {
            "specimen_shift_micrometers": histogram.SampleParameters["Shift"][0],
            "polarization": histogram.InstrumentParameters["Polariz."][1],
            "profile_U": histogram.InstrumentParameters["U"][1],
            "profile_W": histogram.InstrumentParameters["W"][1],
            "profile_X": histogram.InstrumentParameters["X"][1],
            "SH_over_L": histogram.InstrumentParameters["SH/L"][1],
            "WO3_isotropic_microstrain": project.phase("WO3_alt_monoclinic")
            .getHAPvalues(histogram.name)["Mustrain"][1][0],
            "march_dollase": {
                phase.name: {
                    "coefficient": phase.getHAPvalues(histogram.name)["Pref.Ori."][1],
                    "axis": phase.getHAPvalues(histogram.name)["Pref.Ori."][3],
                }
                for phase in project.phases()
            },
        },
    }
    with (WORK / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")

    print("FINAL_RESULT", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
