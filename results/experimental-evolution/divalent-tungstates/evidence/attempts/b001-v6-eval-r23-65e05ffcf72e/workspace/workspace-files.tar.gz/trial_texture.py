#!/usr/bin/env python3
"""Compare one March-Dollase axis against the no-texture baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("phase", choices=["SrWO4", "WO3_triclinic", "SrCO3_pnma"])
    parser.add_argument("axis", nargs=3, type=int)
    args = parser.parse_args()

    work = Path(__file__).resolve().parent
    out = work / f"texture_{args.name}.gpx"
    project = G2sc.G2Project(str(work / "width_work.gpx"), newgpx=str(out))
    histogram = project.histogram(0)
    phase = project.phase(args.phase)
    pref = phase.getHAPvalues(histogram.name)["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = list(args.axis)
    project.set_Controls("cycles", 12)
    project.refine()
    project.save()

    result = {
        "trial": args.name,
        "phase": args.phase,
        "axis": args.axis,
        "wR": histogram.residuals["wR"],
        "max_shift_over_sigma": project.data["Covariance"]["data"]
        .get("Rvals", {})
        .get("Max shft/sig"),
        "pref_ori": phase.getHAPvalues(histogram.name)["Pref.Ori."],
        "mass_fractions": histogram.ComputeMassFracs(),
        "project": str(out),
    }
    print("TEXTURE_RESULT", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
