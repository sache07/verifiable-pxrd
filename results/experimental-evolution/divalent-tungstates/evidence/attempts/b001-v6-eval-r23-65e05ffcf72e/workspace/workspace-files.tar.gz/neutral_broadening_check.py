#!/usr/bin/env python3
"""Test one phase-broadening term from the truly neutral common profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=["SrWO4", "WO3_alt_monoclinic", "SrCO3_pnma"])
    parser.add_argument("term", choices=["size", "strain"])
    parser.add_argument("--source", default="neutral_common.gpx")
    parser.add_argument("--tag", default="")
    args = parser.parse_args()

    work = Path(__file__).resolve().parent
    suffix = f"_{args.tag}" if args.tag else ""
    out = work / f"neutral_{args.phase}_{args.term}{suffix}.gpx"
    project = G2sc.G2Project(str(work / args.source), newgpx=str(out))
    histogram = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.getHAPvalues(histogram.name)

    if args.term == "size":
        size = hap["Size"]
        size[0] = "isotropic"
        size[1] = [1.0, 1.0, 1.0]
        size[2] = [True, False, False]
        size[5] = [False] * len(size[5])
        project.set_Controls("parmMin", 0.001, f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 10.0, f"{phase.id}:0:Size;i")
        needle = "Size;i"
    else:
        strain = hap["Mustrain"]
        strain[0] = "isotropic"
        strain[1] = [1000.0, 1000.0, 1.0]
        strain[2] = [True, False, False]
        strain[5] = [False] * len(strain[5])
        project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Mustrain;i")
        needle = "Mustrain;i"

    project.set_Controls("cycles", 12)
    for _ in range(3):
        project.refine()
    project.save()

    cov = project.data["Covariance"]["data"]
    params = {
        str(name): {"value": float(value), "sigma": float(sigma)}
        for name, value, sigma in zip(
            cov.get("varyList", []), cov.get("variables", []), cov.get("sig", [])
        )
        if needle in str(name)
    }
    result = {
        "phase": args.phase,
        "term": args.term,
        "wR": histogram.residuals["wR"],
        "R": histogram.residuals["R"],
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "max_shift_over_sigma": cov.get("Rvals", {}).get("Max shft/sig"),
        "value": (
            phase.getHAPvalues(histogram.name)["Size"][1][0]
            if args.term == "size"
            else phase.getHAPvalues(histogram.name)["Mustrain"][1][0]
        ),
        "parameters": params,
        "mass_fractions": histogram.ComputeMassFracs(),
        "project": str(out),
        "source": args.source,
    }
    print("NEUTRAL_BROADENING_RESULT", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
