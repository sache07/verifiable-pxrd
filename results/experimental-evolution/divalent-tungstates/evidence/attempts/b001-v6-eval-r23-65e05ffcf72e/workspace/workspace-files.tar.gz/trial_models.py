#!/usr/bin/env python3
"""Run restrained common-profile GSAS-II inventory challenges."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
CIF_ROOT = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)


def cod(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


WO3 = {
    "gamma": "1528915",       # room-temperature monoclinic P21/n
    "triclinic": "2106293",   # room-temperature P-1
    "alt_monoclinic": "2311041",  # alternate P21/c setting
    "high_pressure": "1563541",
    "orthorhombic": "2107312",
}

SRCO3 = {
    "pnma": "9008198",        # room-temperature strontianite
    "rhombohedral": "1539128",
}


def neutralize_hap(phase, histogram_name: str) -> None:
    hap = phase.getHAPvalues(histogram_name)
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [1.0, 1.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [1000.0, 1000.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]


def add_phase(project, histogram, name: str, source: Path, scale: float):
    phase = project.add_phase(
        str(source), phasename=name, histograms=[histogram], fmthint="CIF"
    )
    phase.HAPvalue("Scale", scale)
    phase.set_HAP_refinements({"Scale": True})
    neutralize_hap(phase, histogram.name)
    return phase


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("--wo3", choices=WO3, default="gamma")
    parser.add_argument("--srco3", choices=SRCO3, default="pnma")
    parser.add_argument("--omit-wo3", action="store_true")
    parser.add_argument("--omit-srco3", action="store_true")
    parser.add_argument("--add-sr3w2o9", action="store_true")
    args = parser.parse_args()

    project_path = WORK / f"trial_{args.name}.gpx"
    project = G2sc.G2Project(newgpx=str(project_path))
    histogram = project.add_powder_histogram(
        str(WORK / "inputs/pattern.csv"),
        str(WORK / "instrument.instprm"),
        fmthint="comma",
    )

    phases = [
        add_phase(project, histogram, "SrWO4", WORK / "srwo4_prototype.cif", 7.0)
    ]
    if not args.omit_wo3:
        phases.append(
            add_phase(
                project,
                histogram,
                f"WO3_{args.wo3}",
                cod(WO3[args.wo3]),
                2.0,
            )
        )
    if not args.omit_srco3:
        phases.append(
            add_phase(
                project,
                histogram,
                f"SrCO3_{args.srco3}",
                cod(SRCO3[args.srco3]),
                3.0,
            )
        )
    if args.add_sr3w2o9:
        phases.append(
            add_phase(project, histogram, "Sr3W2O9_watch", cod("2311977"), 0.05)
        )

    sample = histogram.SampleParameters
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [1060.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    instrument = histogram.InstrumentParameters
    for key, value in {
        "Polariz.": 0.761,
        "U": 0.0,
        "V": 0.0,
        "W": 40.27,
        "X": 2.315,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }.items():
        instrument[key][1] = value
        instrument[key][2] = False

    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 5,
                "coeffs": [1021.59, -4.24, -2.51, 9.62, -4.54],
            }
        }
    )
    project.set_Controls("cycles", 5)

    # Re-establish scale/background before any positional or cell freedom.
    project.refine()

    histogram.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.refine()

    histogram.set_refinements(
        {"Instrument Parameters": ["W", "X", "Polariz."]}
    )
    project.set_Controls("parmMin", 0.0, ":0:W")
    project.set_Controls("parmMin", 0.0, ":0:X")
    project.set_Controls("parmMin", 0.0, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    project.refine()
    project.refine()
    project.save()

    try:
        mass_fractions = {
            key: {"value": value[0], "sigma": value[1]}
            for key, value in histogram.ComputeMassFracs().items()
        }
    except Exception as exc:
        mass_fractions = {"error": repr(exc)}

    result = {
        "trial": args.name,
        "wo3": None if args.omit_wo3 else args.wo3,
        "srco3": None if args.omit_srco3 else args.srco3,
        "add_sr3w2o9": args.add_sr3w2o9,
        "residuals": histogram.residuals,
        "mass_fractions": mass_fractions,
        "shift_micrometres": histogram.SampleParameters["Shift"][0],
        "instrument": {
            key: histogram.InstrumentParameters[key][1]
            for key in ["Polariz.", "U", "W", "X", "SH/L"]
        },
        "phases": {
            phase.name: {
                "scale": phase.HAPvalue("Scale"),
                "cell": phase.get_cell(),
            }
            for phase in project.phases()
        },
        "project": str(project_path),
    }
    out = WORK / f"trial_{args.name}.json"
    with out.open("w", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print("TRIAL_RESULT", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
