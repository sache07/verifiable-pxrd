#!/usr/bin/env python3
"""Challenge one March-Dollase axis in the selected final inventory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "phase", choices=["SrWO4", "WO3_alt_monoclinic", "SrCO3_pnma"]
    )
    parser.add_argument("axis", nargs=3, type=int)
    parser.add_argument(
        "--source", default="variant_altmono_final.gpx", help="source project"
    )
    args = parser.parse_args()

    work = Path(__file__).resolve().parent
    axis_name = "".join("m" + str(-v) if v < 0 else str(v) for v in args.axis)
    out = work / f"final_texture_{args.phase}_{axis_name}.gpx"
    project = G2sc.G2Project(
        str(work / args.source), newgpx=str(out)
    )
    histogram = project.histogram(0)
    phase = project.phase(args.phase)
    pref = phase.getHAPvalues(histogram.name)["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    if args.axis == [0, 0, 0]:
        pref[2] = False
        pref[3] = [0, 0, 1]
    else:
        pref[2] = True
        pref[3] = list(args.axis)

    project.set_Controls("parmMin", 0.2, f"{phase.id}:0:MD")
    project.set_Controls("parmMax", 5.0, f"{phase.id}:0:MD")
    project.set_Controls("cycles", 12)
    for _ in range(3):
        project.refine()
    project.save()

    cov = project.data["Covariance"]["data"]
    result = {
        "phase": args.phase,
        "axis": args.axis,
        "wR": histogram.residuals["wR"],
        "R": histogram.residuals["R"],
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "max_shift_over_sigma": cov.get("Rvals", {}).get("Max shft/sig"),
        "pref_ori": phase.getHAPvalues(histogram.name)["Pref.Ori."],
        "mass_fractions": histogram.ComputeMassFracs(),
        "project": str(out),
        "source": args.source,
    }
    print("FINAL_TEXTURE_RESULT", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
