from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT=Path.cwd();BASE=ROOT/'.tmp/shared_terms_trials/o10_pol_roughB.gpx';OUT=ROOT/'.tmp/profile_trials2';OUT.mkdir(parents=True,exist_ok=True)


def rv(p):
    x=p.data['Covariance']['data']['Rvals'];return {k:x[k] for k in ('chisq','Nobs','Nvars','Rwp','GOF','Max shft/sig','converged') if k in x}


def settle(p,n=3):
    hist=[]
    for _ in range(n):
        p.refine();hist.append(rv(p))
        if hist[-1].get('converged') and abs(hist[-1].get('Max shft/sig',999))<.25:break
    return hist


rows=[]
for idx in range(3):
    for mode in ('size','strain','combined'):
        label=f'p{idx}_{mode}';p=G2sc.G2Project(gpxfile=str(BASE),newgpx=str(OUT/f'{label}.gpx'));h=p.histogram(0);ph=p.phase(idx);hap=ph.getHAPvalues(h.name)
        p.set_Frozen();p.set_Controls('cycles',12)
        if mode in ('size','combined'):
            hap['Size'][1][0]=1.0;ph.set_HAP_refinements({'Size':{'type':'isotropic','value':1.0,'refine':True}})
            p.set_Controls('parmMin',0.01,variable=f'{idx}:0:Size;i');p.set_Controls('parmMax',10.0,variable=f'{idx}:0:Size;i')
        if mode in ('strain','combined'):
            hap['Mustrain'][1][0]=500.0;ph.set_HAP_refinements({'Mustrain':{'type':'isotropic','refine':True}})
            p.set_Controls('parmMin',0.0,variable=f'{idx}:0:Mustrain;i');p.set_Controls('parmMax',10000.0,variable=f'{idx}:0:Mustrain;i')
        history=settle(p);p.save();hap=ph.getHAPvalues(h.name)
        rows.append({'label':label,'phase':ph.name,'mode':mode,'rvals':rv(p),'history':history,'size':hap['Size'],'strain':hap['Mustrain'],'mass':{k:{'value':v[0],'esd':v[1]} for k,v in h.ComputeMassFracs().items()},'instrument':{k:list(v) for k,v in h.InstrumentParameters.items() if k in ('U','W','X')},'frozen':p.get_Frozen(),'vary':p.get_VaryList(),'gpx':str(Path(p.filename).relative_to(ROOT))})

(OUT/'trials.json').write_text(json.dumps(rows,indent=2,default=float))
for r in rows:print(r['label'],r['rvals'],'size',r['size'][:3],'strain',r['strain'][:3],'UWX',r['instrument'],'mass',r['mass'],'frozen',r['frozen'])
