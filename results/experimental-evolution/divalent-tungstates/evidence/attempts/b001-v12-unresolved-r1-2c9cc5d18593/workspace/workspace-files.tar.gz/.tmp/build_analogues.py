from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path.cwd()
CIF_ROOT = Path('<RUN>/resources/b001-c05/cif')
OUT = ROOT / '.tmp' / 'models'
OUT.mkdir(parents=True, exist_ok=True)


def source(cod_id):
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


models = [
    ('1562666', {'Os': 'W'}, 'Ca3WO6_from_Ca3OsO6_P21c_1562666.cif'),
    ('2310470', {'U': 'W'}, 'Ca3WO6_from_Ca3UO6_P21_2310470.cif'),
    ('2002703', {'Mn': 'Ca'}, 'Ca3WO6_from_Mn3WO6_R3_2002703.cif'),
]

for cod_id, substitutions, filename in models:
    structure = Structure.from_file(source(cod_id))
    structure.remove_oxidation_states()
    structure.replace_species(substitutions)
    CifWriter(structure, symprec=0.01, refine_struct=False).write_file(OUT / filename)
    print(OUT / filename, structure.composition.reduced_formula)
