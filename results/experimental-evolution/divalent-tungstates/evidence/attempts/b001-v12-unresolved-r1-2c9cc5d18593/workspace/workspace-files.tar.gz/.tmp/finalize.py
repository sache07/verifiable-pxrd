from pathlib import Path
import csv
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
BASE = ROOT / '.tmp/final_profile_loop/full_replay.gpx'
FINAL = ROOT / 'final.gpx'


def rvals(project):
    raw = project.data['Covariance']['data']['Rvals']
    return {key: raw[key] for key in
            ('chisq', 'Nobs', 'Nvars', 'Rwp', 'GOF', 'Max shft/sig', 'converged')
            if key in raw}


def settle(project, maximum=5, tolerance=0.01):
    history = []
    for _ in range(maximum):
        project.refine()
        history.append(rvals(project))
        if (history[-1].get('converged') and
                abs(history[-1].get('Max shft/sig', 999)) < tolerance):
            break
    return history


def enforce_pruned_model(project):
    hist = project.histogram(0)
    hist.data['Limits'][1] = list(hist.data['Limits'][0])
    hist.Background[0][0] = 'chebyschev-1'
    hist.Background[0][1] = True
    hist.Background[0][2] = 10
    hist.InstrumentParameters['Zero'][2] = True
    hist.InstrumentParameters['Polariz.'][2] = True
    for key in ('U', 'W', 'X'):
        hist.InstrumentParameters[key][2] = True
    for key in ('V', 'Y', 'Z', 'SH/L'):
        hist.InstrumentParameters[key][2] = False
    hist.InstrumentParameters['V'][1] = 0.0
    hist.InstrumentParameters['Y'][1] = 0.0
    hist.InstrumentParameters['Z'][1] = 0.0
    hist.InstrumentParameters['SH/L'][1] = 0.002
    hist.SampleParameters['Scale'][:] = [1.0, False]
    hist.SampleParameters['SurfRoughA'][:] = [0.0, False]
    hist.SampleParameters['SurfRoughB'][1] = True

    for phase in project.phases():
        phase.set_refinements({'Cell': True})
        phase.getHAPvalues(hist.name)['Scale'][1] = True

    # CaWO4: supported [001] size anisotropy, isotropic strain and [110] MD.
    hap0 = project.phase(0).getHAPvalues(hist.name)
    hap0['Size'][0] = 'uniaxial'
    hap0['Size'][2][:] = [True, True, False]
    hap0['Size'][3] = [0, 0, 1]
    hap0['Size'][5][:] = [False] * len(hap0['Size'][5])
    hap0['Mustrain'][0] = 'isotropic'
    hap0['Mustrain'][2][:] = [True, False, False]
    hap0['Mustrain'][5][:] = [False] * len(hap0['Mustrain'][5])
    hap0['Pref.Ori.'][0] = 'MD'
    hap0['Pref.Ori.'][2] = True
    hap0['Pref.Ori.'][3] = [1, 1, 0]

    # WO3 inactive phase-specific profile terms are genuinely neutral.
    hap1 = project.phase(1).getHAPvalues(hist.name)
    hap1['Size'][0] = 'isotropic'
    hap1['Size'][1][:] = [10.0, 10.0, 1.0]
    hap1['Size'][2][:] = [False] * len(hap1['Size'][2])
    hap1['Size'][5][:] = [False] * len(hap1['Size'][5])
    hap1['Mustrain'][0] = 'isotropic'
    hap1['Mustrain'][1][0] = hap1['Mustrain'][1][1] = 0.0
    hap1['Mustrain'][2][:] = [False] * len(hap1['Mustrain'][2])
    hap1['Mustrain'][5][:] = [False] * len(hap1['Mustrain'][5])
    hap1['Pref.Ori.'][1] = 1.0
    hap1['Pref.Ori.'][2] = False

    # Ca3WO6: supported isotropic size plus isotropic strain only.
    hap2 = project.phase(2).getHAPvalues(hist.name)
    hap2['Size'][0] = 'isotropic'
    hap2['Size'][2][:] = [True, False, False]
    hap2['Size'][5][:] = [False] * len(hap2['Size'][5])
    hap2['Mustrain'][0] = 'isotropic'
    hap2['Mustrain'][2][:] = [True, False, False]
    hap2['Mustrain'][5][:] = [False] * len(hap2['Mustrain'][5])
    hap2['Pref.Ori.'][1] = 1.0
    hap2['Pref.Ori.'][2] = False

    project.set_Frozen()
    project.set_Controls('cycles', 12)
    return hist


# Save once, reopen from disk and replay the complete measured range.
project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(FINAL))
enforce_pruned_model(project)
first_history = settle(project)
project.save()

project = G2sc.G2Project(gpxfile=str(FINAL))
hist = enforce_pruned_model(project)
replay_history = settle(project)
project.save()

if project.get_Frozen():
    raise RuntimeError(f'Final refinement has frozen variables: {project.get_Frozen()}')
final_r = rvals(project)
if not final_r.get('converged'):
    raise RuntimeError('Final refinement did not converge')

# Export one structural CIF per retained phase from this exact covariance state.
phase_info = (
    ('Calcium tungstate (scheelite)', 'CaWO4', 'phase_CaWO4.cif',
     'COD 7219229'),
    ('Tungsten(VI) oxide, monoclinic', 'WO3', 'phase_WO3.cif',
     'COD 2311041'),
    ('Tricalcium tungstate, monoclinic analogue', 'Ca3WO6',
     'phase_Ca3WO6.cif', 'Ca3OsO6 COD 1562666 with isovalent Os6+ -> W6+'),
)
for phase, (_, _, filename, _) in zip(project.phases(), phase_info):
    phase.export_CIF(str(ROOT / filename))

# Export the observed/calculated/background/difference profile.
arr = hist.data['data'][1]
with (ROOT / 'fit.csv').open('w', newline='') as stream:
    writer = csv.writer(stream)
    writer.writerow(('two_theta_deg', 'observed_counts', 'calculated_counts',
                     'background_counts', 'difference_observed_minus_calculated'))
    for x, yobs, ycalc, ybkg, ydiff in zip(arr[0], arr[1], arr[3], arr[4], arr[5]):
        writer.writerow((f'{x:.8f}', f'{yobs:.8f}', f'{ycalc:.8f}',
                         f'{ybkg:.8f}', f'{ydiff:.8f}'))

# Normalize fractions explicitly over the retained crystalline phases.
mass = hist.ComputeMassFracs()
raw_mass = [float(mass[phase.name][0]) for phase in project.phases()]
mass_total = sum(raw_mass)
fractions = [value / mass_total for value in raw_mass]
fractions[-1] = 1.0 - sum(fractions[:-1])

phases_json = []
for idx, (phase, info, fraction) in enumerate(
        zip(project.phases(), phase_info, fractions)):
    display_name, formula, filename, source = info
    cell, cell_esd = phase.get_cell_and_esd()
    phases_json.append({
        'name': display_name,
        'formula': formula,
        'space_group': phase.data['General']['SGData']['SpGrp'],
        'source_model': source,
        'cif_path': filename,
        'project_path': 'final.gpx',
        'weight_fraction': float(fraction),
        'weight_fraction_esd_formal': float(mass[phase.name][1] / mass_total),
        'cell': {key: float(value) for key, value in cell.items()},
        'cell_esd': {key: float(value) for key, value in cell_esd.items()},
        'phase_Rf_percent': float(hist.residuals[f'{idx}:0:Rf']),
    })

rwp_percent = float(final_r['Rwp'])
rp_percent = float(hist.residuals['R'])
gof = float(final_r['GOF'])
rexp_percent = rwp_percent / gof
result = {
    'project_path': 'final.gpx',
    'fit_profile_path': 'fit.csv',
    'crystalline_phase_count': len(phases_json),
    'fraction_basis': 'normalized over the modeled crystalline phases',
    'phases': phases_json,
    'fit_statistics': {
        'Rwp': rwp_percent / 100.0,
        'Rwp_percent': rwp_percent,
        'Rp': rp_percent / 100.0,
        'Rp_percent': rp_percent,
        'Rexp': rexp_percent / 100.0,
        'Rexp_percent': rexp_percent,
        'goodness_of_fit': gof,
        'reduced_chi_square': gof ** 2,
        'weighted_sum_of_squares': float(final_r['chisq']),
        'observations': int(final_r['Nobs']),
        'refined_variables': int(final_r['Nvars']),
        'maximum_shift_over_esd': float(final_r['Max shft/sig']),
    },
    'measurement_model': {
        'radiation': 'Cu K-alpha1/K-alpha2',
        'wavelength_Kalpha1_angstrom': 1.540598,
        'wavelength_Kalpha2_angstrom': 1.544426,
        'Kalpha2_to_Kalpha1_ratio': 0.5,
        'range_two_theta_deg': [float(arr[0][0]), float(arr[0][-1])],
        'point_count': int(len(arr[0])),
        'weighting': 'count-statistical weights generated by GSAS-II; supplied pointwise uncertainties were absent',
    },
    'final_replay_history': replay_history,
}
(ROOT / 'result.json').write_text(json.dumps(result, indent=2))

f0, f1, f2 = (100.0 * value for value in fractions)
e0, e1, e2 = (100.0 * mass[phase.name][1] / mass_total
              for phase in project.phases())
report = f'''# PXRD phase analysis

The pattern is modeled by three crystalline phases. Fractions are normalized over those phases only.

| Phase | Structural model | Weight fraction |
|---|---|---:|
| CaWO4 (scheelite, I 41/a) | COD 7219229 | {f0:.2f}% (formal e.s.d. {e0:.2f}%) |
| WO3 (monoclinic, P 21/c) | COD 2311041 | {f1:.2f}% (formal e.s.d. {e1:.2f}%) |
| Ca3WO6 (monoclinic, P 21/n) | Ca3OsO6 COD 1562666, isovalent Os6+ -> W6+ analogue | {f2:.2f}% (formal e.s.d. {e2:.2f}%) |

## Evidence

Scheelite CaWO4 accounts for the dominant 18.43, 28.54, 34.01, 46.94, 54.12 and 57.72 degree families. Monoclinic WO3 accounts for the diagnostic 22.95/23.42/24.23 degree group and many higher-angle lines. The remaining coherent families, including peaks near 18.77, 19.29, 22.02, 30.73, 31.4, 32.15, 37.54 and 45.25 degrees, are jointly indexed by the adapted Ca3WO6 model. Removing WO3 or Ca3WO6 raises Rwp from {rwp_percent:.3f}% to 12.59% or 8.20%, respectively.

Source challenges favored WO3 COD 2311041 at Rwp 2.634%; the triclinic record reached 2.780%, another monoclinic record 3.413%, and orthorhombic/tetragonal records were much poorer or boundary-unstable. Alternate Ca3WO6 parents and fergusonite CaWO4 collapsed to zero scale. A CaO trial replayed near 0.12 wt%, but its useful intensity was confined to reflections coincident with retained phases; it lacked two independent non-coincident families and is therefore not retained or reliably quantified.

The final full-range replay gives Rwp = {rwp_percent:.3f}%, Rp = {rp_percent:.3f}%, Rexp = {rexp_percent:.3f}% and GOF = {gof:.3f}. Supported profile terms are CaWO4 [110] March-Dollase texture, slight [001] size anisotropy and small strain, plus isotropic Ca3WO6 size/strain. WO3 phase widths are neutral. Polarization and surface roughness survive deletion tests; SH/L remains fixed because isolated low-, middle- and high-angle left/right half-widths show no repeated unmodeled asymmetry.

## Remaining uncertainty

The Ca3WO6 lattice/topology and fraction are supported, but its atomic coordinates come from an isovalently substituted Ca3OsO6 parent; oxygen positions are not uniquely refinable from this powder pattern. Atomic coordinates in all three phases were held to their source models while cells were refined. Formal covariance errors understate source, texture and background uncertainty, so the extra fraction decimals should not be interpreted as accuracy. No precursor amounts were supplied, so reagent-balance closure could not be imposed. The fractions exclude amorphous material, and trace CaO cannot be ruled out even though no reliable CaO fraction can be reported.
'''
(ROOT / 'report.md').write_text(report)

summary = {
    'first_history': first_history,
    'replay_history': replay_history,
    'fit': result['fit_statistics'],
    'fractions': {phase['formula']: phase['weight_fraction']
                  for phase in phases_json},
    'fraction_sum': sum(phase['weight_fraction'] for phase in phases_json),
}
print(json.dumps(summary, indent=2))
