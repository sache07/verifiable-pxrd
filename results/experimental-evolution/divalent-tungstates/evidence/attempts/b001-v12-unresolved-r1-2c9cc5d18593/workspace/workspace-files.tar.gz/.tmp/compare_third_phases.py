from pathlib import Path
import json
import traceback

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
BASE = ROOT / '.tmp/source_comparison/wo3_2311041.gpx'
OUT = ROOT / '.tmp/third_phase_comparison'
OUT.mkdir(parents=True, exist_ok=True)
CIF_ROOT = Path('<RUN>/resources/b001-c05/cif')


def cod_path(cod_id):
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


CANDIDATES = [
    ('Ca3WO6_P21n_1562666', ROOT/'.tmp/models/Ca3WO6_from_Ca3OsO6_P21n_1562666.cif'),
    ('Ca3WO6_P21_2310470', ROOT/'.tmp/models/Ca3WO6_from_Ca3UO6_P21_2310470.cif'),
    ('Ca3WO6_R3_2002703', ROOT/'.tmp/models/Ca3WO6_from_Mn3WO6_R3_2002703.cif'),
    ('CaO_1563196', cod_path('1563196')),
]


def neutralize(phase, hist):
    hap = phase.getHAPvalues(hist.name)
    hap['Size'][0] = 'isotropic'
    hap['Size'][1][0] = 10.0
    hap['Size'][1][1] = 10.0
    hap['Size'][2][:] = [False] * len(hap['Size'][2])
    hap['Size'][5][:] = [False] * len(hap['Size'][5])
    hap['Mustrain'][0] = 'isotropic'
    hap['Mustrain'][1][0] = 0.0
    hap['Mustrain'][1][1] = 0.0
    hap['Mustrain'][2][:] = [False] * len(hap['Mustrain'][2])
    hap['Mustrain'][5][:] = [False] * len(hap['Mustrain'][5])
    hap['Pref.Ori.'][0] = 'MD'
    hap['Pref.Ori.'][1] = 1.0
    hap['Pref.Ori.'][2] = False
    hap['HStrain'][0][:] = [0.0] * len(hap['HStrain'][0])
    hap['HStrain'][1][:] = [False] * len(hap['HStrain'][1])


def values(proj):
    raw = proj.data['Covariance']['data']['Rvals']
    return {k: raw[k] for k in ('chisq','Nobs','Nvars','Rwp','GOF','Max shft/sig','converged') if k in raw}


def settle(proj, maximum=5):
    history=[]
    for _ in range(maximum):
        proj.refine()
        row=values(proj); history.append(row)
        if row.get('converged') and abs(row.get('Max shft/sig',999)) < 0.25:
            break
    return history


rows=[]
for label, model in CANDIDATES:
    print('\n'+'='*20,label,'='*20,flush=True)
    try:
        gpx=OUT/f'{label}.gpx'
        proj=G2sc.G2Project(gpxfile=str(BASE),newgpx=str(gpx))
        hist=proj.histogram(0)
        third=proj.add_phase(str(model),phasename=label,histograms=[hist],fmthint='CIF')
        neutralize(third,hist)
        hap=third.getHAPvalues(hist.name)
        hap['Scale'][0]=0.1
        third.set_HAP_refinements({'Scale':True})
        proj.set_Controls('parmMin',0.0,variable='2:0:Scale')
        proj.set_Controls('cycles',12)

        # Required scale-before-cell challenge from the saved two-phase checkpoint.
        scale_history=settle(proj,5)
        scale_value=third.getHAPvalues(hist.name)['Scale'][0]
        frozen=proj.get_Frozen()
        row={
            'label':label,'model':str(model.relative_to(ROOT)) if model.is_relative_to(ROOT) else str(model),
            'scale_only':values(proj),'scale_history':scale_history,
            'scale':scale_value,'frozen_after_scale':frozen,
        }
        if scale_value > 1e-6 and '2:0:Scale' not in frozen:
            third.set_refinements({'Cell':True})
            cell_history=settle(proj,6)
            row['cell_refined']=values(proj)
            row['cell_history']=cell_history
            row['cell']=third.get_cell()
            row['scale']=third.getHAPvalues(hist.name)['Scale'][0]
            row['mass_fractions']={k:{'value':v[0],'esd':v[1]} for k,v in hist.ComputeMassFracs().items()}
            row['frozen_final']=proj.get_Frozen()
        else:
            row['rejected_before_cell']='scale collapsed or reached lower bound'
        proj.save()
        row['gpx']=str(gpx.relative_to(ROOT))
        rows.append(row)
    except Exception as exc:
        traceback.print_exc()
        rows.append({'label':label,'error':str(exc)})
    (OUT/'comparison.json').write_text(json.dumps(rows,indent=2,default=float))

print('\nSUMMARY')
for row in rows:
    if 'error' in row: print(row['label'],'ERROR',row['error']); continue
    print(row['label'],'scale stage',row['scale_only'],'scale',row['scale'],'frozen',row['frozen_after_scale'])
    if 'cell_refined' in row:
        print('  cell stage',row['cell_refined'],'cell',row['cell'],'mass',row['mass_fractions'],'frozen',row['frozen_final'])
    else:
        print(' ',row['rejected_before_cell'])
