from pathlib import Path
from copy import deepcopy
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
BASE = ROOT / '.tmp/final_profile_loop/full_replay.gpx'
OUT = ROOT / '.tmp/final_source_challenge'
OUT.mkdir(parents=True, exist_ok=True)
CIF_ROOT = Path('<RUN>/resources/b001-c05/cif')
CA3_MODEL = ROOT / '.tmp/models/Ca3WO6_from_Ca3OsO6_P21n_1562666.cif'
WO3_IDS = ('2311041', '1528915', '2106293', '2107312', '1521532')


def cif(cod_id):
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


def rvals(project):
    raw = project.data['Covariance']['data']['Rvals']
    return {key: raw[key] for key in
            ('chisq', 'Nobs', 'Nvars', 'Rwp', 'GOF', 'Max shft/sig', 'converged')
            if key in raw}


def settle(project, maximum=6):
    history = []
    for _ in range(maximum):
        project.refine()
        history.append(rvals(project))
        if (history[-1].get('converged') and
                abs(history[-1].get('Max shft/sig', 999)) < 0.25):
            break
    return history


def neutralize(hap):
    hap['Size'][0] = 'isotropic'
    hap['Size'][1][:] = [10.0, 10.0, 1.0]
    hap['Size'][2][:] = [False] * len(hap['Size'][2])
    hap['Size'][5][:] = [False] * len(hap['Size'][5])
    hap['Mustrain'][0] = 'isotropic'
    hap['Mustrain'][1][0] = hap['Mustrain'][1][1] = 0.0
    hap['Mustrain'][2][:] = [False] * len(hap['Mustrain'][2])
    hap['Mustrain'][5][:] = [False] * len(hap['Mustrain'][5])
    hap['Pref.Ori.'][0] = 'MD'
    hap['Pref.Ori.'][1] = 1.0
    hap['Pref.Ori.'][2] = False
    hap['HStrain'][0][:] = [0.0] * len(hap['HStrain'][0])
    hap['HStrain'][1][:] = [False] * len(hap['HStrain'][1])


def freeze_profile(hist, phases):
    hist.Background[0][1] = False
    for key in ('Zero', 'Polariz.', 'U', 'W', 'X'):
        hist.InstrumentParameters[key][2] = False
    hist.SampleParameters['SurfRoughA'][1] = False
    hist.SampleParameters['SurfRoughB'][1] = False
    for phase in phases:
        hap = phase.getHAPvalues(hist.name)
        hap['Size'][2][:] = [False] * len(hap['Size'][2])
        hap['Size'][5][:] = [False] * len(hap['Size'][5])
        hap['Mustrain'][2][:] = [False] * len(hap['Mustrain'][2])
        hap['Mustrain'][5][:] = [False] * len(hap['Mustrain'][5])
        hap['Pref.Ori.'][2] = False


def reopen_profile(hist, ca, ca3):
    hist.Background[0][1] = True
    for key in ('Zero', 'Polariz.', 'U', 'W', 'X'):
        hist.InstrumentParameters[key][2] = True
    hist.SampleParameters['SurfRoughA'][:] = [0.0, False]
    hist.SampleParameters['SurfRoughB'][1] = True
    hap0 = ca.getHAPvalues(hist.name)
    hap0['Size'][2][:] = [True, True, False]
    hap0['Mustrain'][2][:] = [True, False, False]
    hap0['Pref.Ori.'][2] = True
    hap2 = ca3.getHAPvalues(hist.name)
    hap2['Size'][2][:] = [True, False, False]
    hap2['Mustrain'][2][:] = [True, False, False]


def snapshot(project):
    hist = project.histogram(0)
    return {
        'rvals': rvals(project),
        'mass': {k: {'value': v[0], 'esd': v[1]}
                 for k, v in hist.ComputeMassFracs().items()},
        'frozen': project.get_Frozen(),
        'instrument': {k: list(v) for k, v in hist.InstrumentParameters.items()
                       if k in ('Zero', 'Polariz.', 'U', 'W', 'X')},
        'sample': {k: list(v) for k, v in hist.SampleParameters.items()
                   if k in ('SurfRoughA', 'SurfRoughB')},
        'phases': [{
            'name': phase.name, 'cell': phase.get_cell(),
            'scale': phase.getHAPvalues(hist.name)['Scale'],
            'size': phase.getHAPvalues(hist.name)['Size'],
            'strain': phase.getHAPvalues(hist.name)['Mustrain'],
            'MD': phase.getHAPvalues(hist.name)['Pref.Ori.']}
            for phase in project.phases()],
    }


reference = G2sc.G2Project(gpxfile=str(BASE))
ref_hist = reference.histogram(0)
ref_phases = reference.phases()
rows = []

for cod_id in WO3_IDS:
    gpx = OUT / f'wo3_{cod_id}.gpx'
    project = G2sc.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(
        str(ROOT / 'inputs/pattern.csv'), str(ROOT / '.tmp/cu_ka.instprm'),
        fmthint='comma')
    hist.data['Background'] = deepcopy(ref_hist.data['Background'])
    hist.data['Instrument Parameters'] = deepcopy(
        ref_hist.data['Instrument Parameters'])
    hist.data['Sample Parameters'] = deepcopy(ref_hist.data['Sample Parameters'])
    hist.data['Limits'] = deepcopy(ref_hist.data['Limits'])

    ca = project.add_phase(str(cif('7219229')), phasename='CaWO4_7219229',
                           histograms=[hist], fmthint='CIF')
    wo = project.add_phase(str(cif(cod_id)), phasename=f'WO3_{cod_id}',
                           histograms=[hist], fmthint='CIF')
    ca3 = project.add_phase(str(CA3_MODEL),
                            phasename='Ca3WO6_P21n_1562666',
                            histograms=[hist], fmthint='CIF')

    # Exact common CaWO4 and Ca3WO6 geometry/profile values are copied from
    # the accepted checkpoint. Each WO3 record retains its own source setting.
    for target, source in ((ca, ref_phases[0]), (ca3, ref_phases[2])):
        target.data['General']['Cell'] = deepcopy(source.data['General']['Cell'])
        target_hap = target.getHAPvalues(hist.name)
        source_hap = source.getHAPvalues(ref_hist.name)
        for key in ('Size', 'Mustrain', 'Pref.Ori.', 'HStrain'):
            target_hap[key] = deepcopy(source_hap[key])
        target_hap['Scale'][0] = source_hap['Scale'][0]
    if cod_id == '2311041':
        wo.data['General']['Cell'] = deepcopy(ref_phases[1].data['General']['Cell'])
    wo_hap = wo.getHAPvalues(hist.name)
    neutralize(wo_hap)
    wo_hap['Scale'][0] = ref_phases[1].getHAPvalues(ref_hist.name)['Scale'][0]

    for phase in (ca, wo, ca3):
        phase.getHAPvalues(hist.name)['Scale'][1] = True
        phase.set_refinements({'Cell': True})

    project.set_Frozen()
    project.set_Controls('cycles', 12)
    for idx in range(3):
        project.set_Controls('parmMin', 0.0, variable=f'{idx}:0:Scale')
    for var in (':0:U', ':0:W', ':0:X'):
        project.set_Controls('parmMin', 0.0, variable=var)
    project.set_Controls('parmMin', -0.5, variable=':0:Zero')
    project.set_Controls('parmMax', 0.5, variable=':0:Zero')
    project.set_Controls('parmMin', 0.0, variable=':0:Polariz.')
    project.set_Controls('parmMax', 1.0, variable=':0:Polariz.')
    project.set_Controls('parmMin', 0.0, variable=':0:SurfRoughB')
    project.set_Controls('parmMax', 1.0, variable=':0:SurfRoughB')
    for var in ('0:0:Size;i', '0:0:Size;a', '2:0:Size;i'):
        project.set_Controls('parmMin', 0.01, variable=var)
        project.set_Controls('parmMax', 10.0, variable=var)
    for var in ('0:0:Mustrain;i', '2:0:Mustrain;i'):
        project.set_Controls('parmMin', 0.0, variable=var)
        project.set_Controls('parmMax', 10000.0, variable=var)
    project.set_Controls('parmMin', 0.2, variable='0:0:MD')
    project.set_Controls('parmMax', 5.0, variable='0:0:MD')

    freeze_profile(hist, (ca, wo, ca3))
    common_history = settle(project)
    common = snapshot(project)

    # A collapsed common-profile scale invalidates elaboration for that source.
    if (wo.getHAPvalues(hist.name)['Scale'][0] > 1e-8 and
            '1:0:Scale' not in project.get_Frozen()):
        project.set_Frozen()
        reopen_profile(hist, ca, ca3)
        elaborated_history = settle(project)
        elaborated = snapshot(project)
    else:
        elaborated_history = []
        elaborated = {'rejected': 'WO3 scale collapsed at common-profile stage'}
    project.save()
    rows.append({
        'cod_id': cod_id, 'source': str(cif(cod_id)),
        'common_history': common_history, 'common': common,
        'elaborated_history': elaborated_history, 'elaborated': elaborated,
        'gpx': str(gpx.relative_to(ROOT)),
    })
    (OUT / 'comparison.json').write_text(json.dumps(rows, indent=2, default=float))

for row in rows:
    print(row['cod_id'], 'common', row['common']['rvals'],
          row['common']['mass'], row['common']['frozen'])
    if 'rvals' in row['elaborated']:
        print('  elaborated', row['elaborated']['rvals'],
              row['elaborated']['mass'], row['elaborated']['frozen'])
    else:
        print(' ', row['elaborated'])
