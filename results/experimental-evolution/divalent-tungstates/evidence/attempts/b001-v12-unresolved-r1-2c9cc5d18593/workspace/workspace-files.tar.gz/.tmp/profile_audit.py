from pathlib import Path
import json

import numpy as np
from scipy.signal import savgol_filter, find_peaks
from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
GPX = ROOT / '.tmp/final_profile_loop/full_replay.gpx'
OUT = ROOT / '.tmp/profile_audit.json'

project = G2sc.G2Project(gpxfile=str(GPX))
hist = project.histogram(0)
arr = np.asarray(hist.data['data'][1], dtype=float)
x, obs, wt, calc, bkg, diff = arr
obs_net = obs - bkg
calc_net = calc - bkg
obs_smooth = savgol_filter(obs_net, 7, 2)


def crossing(axis, signal, peak_index, direction, level):
    i = peak_index
    while 0 <= i + direction < len(signal):
        j = i + direction
        if signal[j] <= level < signal[i]:
            x0, x1 = axis[i], axis[j]
            y0, y1 = signal[i], signal[j]
            return float(x0 + (level - y0) * (x1 - x0) / (y1 - y0))
        i = j
    return None


def halfwidth(signal, center):
    search = 0.11 if center < 60 else 0.16
    sel = np.where(np.abs(x - center) <= search)[0]
    peak = int(sel[np.argmax(signal[sel])])
    height = float(signal[peak])
    level = height / 2.0
    left = crossing(x, signal, peak, -1, level)
    right = crossing(x, signal, peak, 1, level)
    return {
        'peak_position': float(x[peak]), 'height': height,
        'left_half_width': None if left is None else float(x[peak] - left),
        'right_half_width': None if right is None else float(right - x[peak]),
        'fwhm': None if left is None or right is None else float(right - left),
    }


centers = (18.4336, 28.5393, 34.0051, 46.9361, 57.7156, 76.0363, 90.3800)
peak_audit = []
for center in centers:
    observed = halfwidth(obs_smooth, center)
    calculated = halfwidth(calc_net, center)
    peak_audit.append({
        'nominal_position': center, 'observed': observed,
        'calculated': calculated,
        'left_width_residual': observed['left_half_width'] - calculated['left_half_width'],
        'right_width_residual': observed['right_half_width'] - calculated['right_half_width'],
    })


windows = []
for lo, hi in ((9.90343322, 30), (30, 55), (55, 75), (75, 100.09455322)):
    mask = (x >= lo) & (x < hi)
    rwp = 100.0 * np.sqrt(np.sum(wt[mask] * diff[mask] ** 2) /
                          np.sum(wt[mask] * obs[mask] ** 2))
    windows.append({'minimum_2theta': lo, 'maximum_2theta': hi,
                    'points': int(mask.sum()), 'Rwp_percent': float(rwp)})

# Positive residual maxima are listed to check for a coherent omitted family.
smooth_diff = savgol_filter(diff, 9, 2)
peaks, properties = find_peaks(smooth_diff, prominence=20.0, distance=8)
order = np.argsort(properties['prominences'])[::-1]
positive_residuals = [{
    'two_theta': float(x[peaks[i]]),
    'smoothed_difference': float(smooth_diff[peaks[i]]),
    'prominence': float(properties['prominences'][i]),
} for i in order[:25]]

result = {
    'project': str(GPX.relative_to(ROOT)),
    'range_2theta': [float(x[0]), float(x[-1])],
    'local_fit': windows,
    'isolated_peak_halfwidths': peak_audit,
    'largest_positive_residuals': positive_residuals,
}
OUT.write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
