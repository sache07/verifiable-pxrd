from pathlib import Path
import json
import math
import traceback

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
OUT = ROOT / '.tmp' / 'source_comparison'
OUT.mkdir(parents=True, exist_ok=True)
CIF_ROOT = Path('<RUN>/resources/b001-c05/cif')

WO3_IDS = [
    '1004057',  # hexagonal P6/mmm
    '1521532',  # tetragonal P4/ncc
    '1521533',  # tetragonal P4/nmm
    '2107312',  # orthorhombic Pnma
    '1563541',  # monoclinic P21/c, small cell
    '1528915',  # monoclinic P21/c, review geometry
    '2311041',  # monoclinic P21/c, pass geometry
    '2106293',  # triclinic P-1
]


def cif(cod_id):
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


def neutralize(phase, hist):
    hap = phase.getHAPvalues(hist.name)
    hap['Size'][0] = 'isotropic'
    hap['Size'][1][0] = 10.0
    hap['Size'][1][1] = 10.0
    hap['Size'][2][:] = [False] * len(hap['Size'][2])
    hap['Size'][5][:] = [False] * len(hap['Size'][5])
    hap['Mustrain'][0] = 'isotropic'
    hap['Mustrain'][1][0] = 0.0
    hap['Mustrain'][1][1] = 0.0
    hap['Mustrain'][2][:] = [False] * len(hap['Mustrain'][2])
    hap['Mustrain'][5][:] = [False] * len(hap['Mustrain'][5])
    hap['Pref.Ori.'][0] = 'MD'
    hap['Pref.Ori.'][1] = 1.0
    hap['Pref.Ori.'][2] = False
    hap['HStrain'][0][:] = [0.0] * len(hap['HStrain'][0])
    hap['HStrain'][1][:] = [False] * len(hap['HStrain'][1])


def rvals(proj):
    raw = proj.data['Covariance']['data']['Rvals']
    return {k: raw[k] for k in ('chisq','Nobs','Nvars','Rwp','GOF','Max shft/sig','converged') if k in raw}


def settle(proj, maximum=4):
    history = []
    for _ in range(maximum):
        proj.refine()
        row = rvals(proj)
        history.append(row)
        if row.get('converged') and abs(row.get('Max shft/sig', 999)) < 0.25:
            break
    return history


def summarize(proj, cod_id, stage, history):
    hist = proj.histogram(0)
    phases = []
    for ph in proj.phases():
        hap = ph.getHAPvalues(hist.name)
        phases.append({
            'name': ph.name,
            'cell': ph.get_cell(),
            'scale': hap['Scale'][0],
            'size': hap['Size'],
            'mustrain': hap['Mustrain'],
            'preferred_orientation': hap['Pref.Ori.'],
        })
    mass = {}
    try:
        mass = {k: {'value': v[0], 'esd': v[1]} for k,v in hist.ComputeMassFracs().items()}
    except Exception as exc:
        mass = {'error': str(exc)}
    return {
        'cod_id': cod_id,
        'stage': stage,
        'rvals': rvals(proj),
        'history': history,
        'residuals': hist.residuals,
        'mass_fractions': mass,
        'instrument': {k: list(v) for k,v in hist.InstrumentParameters.items() if k in ('Zero','U','V','W','X','Y','Z','SH/L','Polariz.','I(L2)/I(L1)')},
        'background': hist.Background,
        'phases': phases,
        'vary_list': proj.get_VaryList(),
        'frozen': proj.get_Frozen(),
        'gpx': str(Path(proj.filename).relative_to(ROOT)),
    }


def setup(cod_id):
    gpx = OUT / f'wo3_{cod_id}.gpx'
    proj = G2sc.G2Project(newgpx=str(gpx))
    hist = proj.add_powder_histogram(str(ROOT/'inputs/pattern.csv'), str(ROOT/'.tmp/cu_ka.instprm'), fmthint='comma')
    hist.SampleParameters['Scale'][:] = [1.0, False]
    hist.SampleParameters['Shift'][:] = [0.0, False]
    hist.SampleParameters['Transparency'][:] = [0.0, False]
    hist.SampleParameters['SurfRoughA'][:] = [0.0, False]
    hist.SampleParameters['SurfRoughB'][:] = [0.0, False]
    inst = hist.InstrumentParameters
    starts = {'Zero':-0.19694,'U':2.0,'V':0.0,'W':30.88,'X':11.67,'Y':0.0,'Z':0.0,'SH/L':0.002,'Polariz.':0.5}
    for key, value in starts.items():
        inst[key][0] = inst[key][1] = value
        inst[key][2] = False
    ca = proj.add_phase(str(cif('7219229')), phasename='CaWO4_7219229', histograms=[hist], fmthint='CIF')
    wo = proj.add_phase(str(cif(cod_id)), phasename=f'WO3_{cod_id}', histograms=[hist], fmthint='CIF')
    for ph in (ca, wo):
        neutralize(ph, hist)
        ph.set_HAP_refinements({'Scale':True})
    hist.set_refinements({'Background': {'type':'chebyschev-1','refine':True,'no. coeffs':6}})
    proj.set_Controls('cycles', 12)
    for var in ('0:0:Scale','1:0:Scale',':0:U',':0:W',':0:X'):
        proj.set_Controls('parmMin', 0.0, variable=var)
    proj.set_Controls('parmMin', -0.5, variable=':0:Zero')
    proj.set_Controls('parmMax', 0.5, variable=':0:Zero')
    return proj


results = []
for cod_id in WO3_IDS:
    print('\n' + '='*20, cod_id, '='*20, flush=True)
    try:
        proj = setup(cod_id)
        hist = proj.histogram(0)

        # Neutral source checkpoint: common profile fixed; only scales/background,
        # one angular correction, then all symmetry-allowed cell metrics.
        settle(proj, 2)
        hist.set_refinements({'Instrument Parameters':['Zero']})
        settle(proj, 2)
        for ph in proj.phases():
            ph.set_refinements({'Cell':True})
        pre_history = settle(proj, 4)
        results.append(summarize(proj, cod_id, 'common_profile', pre_history))

        # Reopen the same low-dimensional common profile for each source.
        hist.set_refinements({'Instrument Parameters':['U','W','X']})
        post_history = settle(proj, 4)
        results.append(summarize(proj, cod_id, 'refined_common_profile', post_history))
        proj.save()
    except Exception as exc:
        traceback.print_exc()
        results.append({'cod_id':cod_id,'stage':'error','error':str(exc)})
    (OUT/'comparison.json').write_text(json.dumps(results, indent=2, default=float))

print('\nSUMMARY')
for row in results:
    if row['stage'] == 'error':
        print(row['cod_id'], row['stage'], row['error'])
    else:
        rv = row['rvals']
        wo = row['phases'][1]
        print(row['cod_id'], row['stage'], 'Rwp',rv.get('Rwp'),'chi2',rv.get('chisq'),'k',rv.get('Nvars'),'maxshift',rv.get('Max shft/sig'),'scale',wo['scale'],'frozen',row['frozen'])
