from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT=Path.cwd();BASE=ROOT/'.tmp/profile_trials2/p0_size.gpx';OUT=ROOT/'.tmp/post_size_trials';OUT.mkdir(parents=True,exist_ok=True)


def rv(p):
    x=p.data['Covariance']['data']['Rvals'];return {k:x[k] for k in ('chisq','Nobs','Nvars','Rwp','GOF','Max shft/sig','converged') if k in x}


def settle(p,n=3):
    hist=[]
    for _ in range(n):
        p.refine();hist.append(rv(p))
        if hist[-1].get('converged') and abs(hist[-1].get('Max shft/sig',999))<.3:break
    return hist


def summarize(p,label,history,focus=None):
    h=p.histogram(0);row={'label':label,'rvals':rv(p),'history':history,'mass':{k:{'value':v[0],'esd':v[1]} for k,v in h.ComputeMassFracs().items()},'frozen':p.get_Frozen(),'instrument':{k:list(v) for k,v in h.InstrumentParameters.items() if k in ('Polariz.','U','W','X')},'sample':{k:list(v) for k,v in h.SampleParameters.items() if k in ('SurfRoughA','SurfRoughB')},'background':h.Background,'phases':[],'gpx':str(Path(p.filename).relative_to(ROOT))}
    for ph in p.phases():
        hap=ph.getHAPvalues(h.name);row['phases'].append({'name':ph.name,'scale':hap['Scale'],'size':hap['Size'],'strain':hap['Mustrain'],'MD':hap['Pref.Ori.'],'cell':ph.get_cell()})
    if focus is not None:row['focus']=focus
    return row


rows=[]

# Full-model replay and term/order ablations.
for label,order,pol,rough in [
    ('full_replay',10,True,True),('order8',8,True,True),
    ('no_polarization',10,False,True),('no_roughness',10,True,False),
    ('no_pol_no_rough',10,False,False),
]:
    p=G2sc.G2Project(gpxfile=str(BASE),newgpx=str(OUT/f'{label}.gpx'));h=p.histogram(0);p.set_Frozen();p.set_Controls('cycles',10)
    h.set_refinements({'Background':{'type':'chebyschev-1','refine':True,'no. coeffs':order}})
    h.InstrumentParameters['Polariz.'][2]=pol
    if not pol:h.InstrumentParameters['Polariz.'][1]=0.5
    h.SampleParameters['SurfRoughA'][:]=[0.0,False]
    h.SampleParameters['SurfRoughB'][1]=rough
    if not rough:h.SampleParameters['SurfRoughB'][0]=0.0
    hist=settle(p);p.save();rows.append(summarize(p,label,hist))

# Symmetry-compatible [001] uniaxial size for tetragonal CaWO4.
label='ca_uniaxial_size_001';p=G2sc.G2Project(gpxfile=str(BASE),newgpx=str(OUT/f'{label}.gpx'));h=p.histogram(0);p.set_Frozen();p.set_Controls('cycles',10);ph=p.phase(0);size=ph.getHAPvalues(h.name)['Size']
v=size[1][0];size[0]='uniaxial';size[1][:]=[v,v,1.0];size[2][:]=[True,True,False];size[3]=[0,0,1]
for par in ('Size;i','Size;a'):
    p.set_Controls('parmMin',0.01,variable=f'0:0:{par}');p.set_Controls('parmMax',10.0,variable=f'0:0:{par}')
hist=settle(p);p.save();rows.append(summarize(p,label,hist,{'phase':0,'axis':[0,0,1]}))

# Simple low-index March-Dollase challenges, one phase/axis per checkpoint.
axes={0:[[0,0,1],[1,0,0],[1,1,0],[1,0,1],[1,1,2]],1:[[1,0,0],[0,1,0],[0,0,1],[1,0,1],[1,0,-1],[2,0,-2]],2:[[1,0,0],[0,1,0],[0,0,1],[1,1,0],[0,1,1],[1,0,1]]}
for idx,axislist in axes.items():
    for axis in axislist:
        ax='_'.join('m'+str(abs(v)) if v<0 else str(v) for v in axis);label=f'MD_p{idx}_{ax}'
        p=G2sc.G2Project(gpxfile=str(BASE),newgpx=str(OUT/f'{label}.gpx'));h=p.histogram(0);p.set_Frozen();p.set_Controls('cycles',8);ph=p.phase(idx);po=ph.getHAPvalues(h.name)['Pref.Ori.'];po[0]='MD';po[1]=1.0;po[2]=True;po[3]=list(axis)
        p.set_Controls('parmMin',0.2,variable=f'{idx}:0:MD');p.set_Controls('parmMax',5.0,variable=f'{idx}:0:MD')
        hist=settle(p,2);p.save();rows.append(summarize(p,label,hist,{'phase':idx,'axis':axis}))

(OUT/'trials.json').write_text(json.dumps(rows,indent=2,default=float))
for r in rows:
    extra=''
    if 'focus' in r:
        i=r['focus']['phase'];extra=f" focus={r['focus']} size={r['phases'][i]['size'][1]} MD={r['phases'][i]['MD'][1]}"
    print(r['label'],r['rvals'],'mass',r['mass'],'frozen',r['frozen'],extra)
