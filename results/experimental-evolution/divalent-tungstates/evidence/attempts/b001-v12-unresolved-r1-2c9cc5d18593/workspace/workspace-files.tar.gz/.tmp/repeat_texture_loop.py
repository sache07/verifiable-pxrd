from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
BASE = ROOT / '.tmp/post_size_trials/MD_p0_1_1_0.gpx'
OUT = ROOT / '.tmp/repeat_texture_loop'
OUT.mkdir(parents=True, exist_ok=True)


def rvals(project):
    raw = project.data['Covariance']['data']['Rvals']
    keys = ('chisq', 'Nobs', 'Nvars', 'Rwp', 'Rp', 'GOF',
            'Max shft/sig', 'converged')
    return {key: raw[key] for key in keys if key in raw}


def settle(project, maximum=4):
    history = []
    for _ in range(maximum):
        project.refine()
        history.append(rvals(project))
        if (history[-1].get('converged') and
                abs(history[-1].get('Max shft/sig', 999)) < 0.25):
            break
    return history


def neutral_size(hap):
    size = hap['Size']
    size[0] = 'isotropic'
    size[1][:] = [10.0, 10.0, 1.0]
    size[2][:] = [False] * len(size[2])
    size[3] = [0, 0, 1]
    size[5][:] = [False] * len(size[5])


def neutral_strain(hap):
    strain = hap['Mustrain']
    strain[0] = 'isotropic'
    strain[1][0] = 0.0
    strain[1][1] = 0.0
    strain[2][:] = [False] * len(strain[2])
    strain[5][:] = [False] * len(strain[5])


def summarize(project, label, history, focus=None):
    hist = project.histogram(0)
    row = {
        'label': label,
        'rvals': rvals(project),
        'history': history,
        'mass': {k: {'value': v[0], 'esd': v[1]}
                 for k, v in hist.ComputeMassFracs().items()},
        'frozen': project.get_Frozen(),
        'instrument': {k: list(v) for k, v in hist.InstrumentParameters.items()
                       if k in ('Zero', 'Polariz.', 'U', 'W', 'X', 'SH/L')},
        'sample': {k: list(v) for k, v in hist.SampleParameters.items()
                   if k in ('SurfRoughA', 'SurfRoughB')},
        'background': hist.Background,
        'phases': [],
        'gpx': str(Path(project.filename).relative_to(ROOT)),
    }
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        row['phases'].append({
            'name': phase.name,
            'cell': phase.get_cell(),
            'scale': hap['Scale'],
            'size': hap['Size'],
            'strain': hap['Mustrain'],
            'MD': hap['Pref.Ori.'],
        })
    if focus is not None:
        row['focus'] = focus
    return row


def open_trial(label):
    project = G2sc.G2Project(
        gpxfile=str(BASE), newgpx=str(OUT / f'{label}.gpx'))
    project.set_Frozen()
    project.set_Controls('cycles', 12)
    return project, project.histogram(0)


rows = []

# Replay the accepted checkpoint and repeat shared-term/background challenges.
for label, order, polarization, roughness in (
        ('full_replay', 10, True, True),
        ('order8', 8, True, True),
        ('no_polarization', 10, False, True),
        ('no_roughness', 10, True, False),
        ('no_pol_no_rough', 10, False, False)):
    project, hist = open_trial(label)
    hist.set_refinements({'Background': {
        'type': 'chebyschev-1', 'refine': True, 'no. coeffs': order}})
    hist.InstrumentParameters['Polariz.'][2] = polarization
    if not polarization:
        hist.InstrumentParameters['Polariz.'][1] = 0.5
    hist.SampleParameters['SurfRoughA'][:] = [0.0, False]
    hist.SampleParameters['SurfRoughB'][1] = roughness
    if not roughness:
        hist.SampleParameters['SurfRoughB'][0] = 0.0
    history = settle(project)
    project.save()
    rows.append(summarize(project, label, history))

# Re-run neutral/size/strain/combined width comparisons from the texture checkpoint.
for idx in range(3):
    for mode in ('neutral', 'size', 'strain', 'combined'):
        label = f'p{idx}_{mode}'
        project, hist = open_trial(label)
        phase = project.phase(idx)
        hap = phase.getHAPvalues(hist.name)
        neutral_strain(hap)
        if mode in ('neutral', 'strain'):
            neutral_size(hap)
        if mode in ('size', 'combined'):
            if idx == 0:
                value = 0.09
            else:
                value = 1.0
            phase.set_HAP_refinements({'Size': {
                'type': 'isotropic', 'value': value, 'refine': True}})
            project.set_Controls('parmMin', 0.01,
                                 variable=f'{idx}:0:Size;i')
            project.set_Controls('parmMax', 10.0,
                                 variable=f'{idx}:0:Size;i')
        if mode in ('strain', 'combined'):
            hap['Mustrain'][1][0] = 500.0
            phase.set_HAP_refinements({'Mustrain': {
                'type': 'isotropic', 'refine': True}})
            project.set_Controls('parmMin', 0.0,
                                 variable=f'{idx}:0:Mustrain;i')
            project.set_Controls('parmMax', 10000.0,
                                 variable=f'{idx}:0:Mustrain;i')
        history = settle(project)
        project.save()
        rows.append(summarize(project, label, history,
                              {'phase': idx, 'mode': mode}))

# Symmetry-compatible uniaxial CaWO4 size, while retaining [110] texture.
label = 'p0_uniaxial_size_001'
project, hist = open_trial(label)
phase = project.phase(0)
size = phase.getHAPvalues(hist.name)['Size']
value = size[1][0]
size[0] = 'uniaxial'
size[1][:] = [value, value, 1.0]
size[2][:] = [True, True, False]
size[3] = [0, 0, 1]
for par in ('Size;i', 'Size;a'):
    project.set_Controls('parmMin', 0.01, variable=f'0:0:{par}')
    project.set_Controls('parmMax', 10.0, variable=f'0:0:{par}')
history = settle(project)
project.save()
rows.append(summarize(project, label, history,
                      {'phase': 0, 'axis': [0, 0, 1]}))

# Re-challenge the strongest texture directions seen for the minor phases.
for idx, axis in ((1, [1, 0, -1]), (2, [0, 0, 1])):
    label = f'p{idx}_MD_' + '_'.join('m' + str(abs(x)) if x < 0 else str(x)
                                     for x in axis)
    project, hist = open_trial(label)
    po = project.phase(idx).getHAPvalues(hist.name)['Pref.Ori.']
    po[0], po[1], po[2], po[3] = 'MD', 1.0, True, list(axis)
    project.set_Controls('parmMin', 0.2, variable=f'{idx}:0:MD')
    project.set_Controls('parmMax', 5.0, variable=f'{idx}:0:MD')
    history = settle(project)
    project.save()
    rows.append(summarize(project, label, history,
                          {'phase': idx, 'axis': axis}))

(OUT / 'trials.json').write_text(json.dumps(rows, indent=2, default=float))
for row in rows:
    focus = row.get('focus')
    extra = ''
    if focus:
        phase = row['phases'][focus['phase']]
        extra = f" size={phase['size'][1]} strain={phase['strain'][1]} MD={phase['MD'][1]}"
    masses = {k: round(v['value'], 7) for k, v in row['mass'].items()}
    print(row['label'], row['rvals'], masses, row['frozen'], extra)
