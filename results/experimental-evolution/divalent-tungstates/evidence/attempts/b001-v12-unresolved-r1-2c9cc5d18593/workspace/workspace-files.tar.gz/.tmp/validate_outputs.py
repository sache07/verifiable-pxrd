from pathlib import Path
import csv
import json
import math

from GSASII import GSASIIscriptable as G2sc


root = Path.cwd()
result = json.loads((root / 'result.json').read_text())
assert result['project_path'] == 'final.gpx'
assert (root / result['project_path']).is_file()
assert (root / result['fit_profile_path']).is_file()
assert len(result['phases']) == 3
assert math.isclose(sum(p['weight_fraction'] for p in result['phases']),
                    1.0, rel_tol=0.0, abs_tol=1e-12)
for phase in result['phases']:
    assert isinstance(phase['weight_fraction'], (int, float))
    assert 0.0 < phase['weight_fraction'] < 1.0
    assert phase['project_path'] == 'final.gpx'
    assert (root / phase['cif_path']).is_file()

project = G2sc.G2Project(gpxfile=str(root / 'final.gpx'))
assert not project.get_Frozen()
hist = project.histogram(0)
assert list(hist.data['Limits'][1]) == list(hist.data['Limits'][0])
mass = hist.ComputeMassFracs()
total = sum(v[0] for v in mass.values())
for model, submitted in zip(project.phases(), result['phases']):
    expected = mass[model.name][0] / total
    assert math.isclose(expected, submitted['weight_fraction'],
                        rel_tol=0.0, abs_tol=1e-12)

arr = hist.data['data'][1]
with (root / 'fit.csv').open(newline='') as stream:
    reader = csv.DictReader(stream)
    rows = list(reader)
assert len(rows) == len(arr[0]) == 8301
for i, row in enumerate(rows):
    values = (
        float(row['two_theta_deg']), float(row['observed_counts']),
        float(row['calculated_counts']), float(row['background_counts']),
        float(row['difference_observed_minus_calculated']))
    expected = (arr[0][i], arr[1][i], arr[3][i], arr[4][i], arr[5][i])
    for found, target in zip(values, expected):
        assert math.isclose(found, target, rel_tol=0.0, abs_tol=5e-8)
    assert math.isclose(values[4], values[1] - values[2],
                        rel_tol=0.0, abs_tol=2e-8)

rvals = project.data['Covariance']['data']['Rvals']
assert math.isclose(result['fit_statistics']['Rwp_percent'], rvals['Rwp'],
                    rel_tol=0.0, abs_tol=1e-12)
assert rvals['converged']
print(json.dumps({
    'status': 'pass',
    'phase_count': len(project.phases()),
    'fraction_sum': sum(p['weight_fraction'] for p in result['phases']),
    'fit_rows': len(rows),
    'Rwp_percent': rvals['Rwp'],
    'GOF': rvals['GOF'],
    'frozen': project.get_Frozen(),
}, indent=2))
