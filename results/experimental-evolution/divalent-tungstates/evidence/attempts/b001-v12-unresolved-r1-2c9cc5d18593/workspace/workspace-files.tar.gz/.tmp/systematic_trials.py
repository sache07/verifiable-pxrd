from pathlib import Path
import json
import math
import traceback

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
START = ROOT/'.tmp/third_phase_comparison/Ca3WO6_P21n_1562666.gpx'
OUT = ROOT/'.tmp/systematic_trials'
OUT.mkdir(parents=True,exist_ok=True)


def rvals(proj):
    raw=proj.data['Covariance']['data']['Rvals']
    return {k:raw[k] for k in ('chisq','Nobs','Nvars','Rwp','GOF','Max shft/sig','DelChi2','converged') if k in raw}


def settle(proj,maximum=5):
    hist=[]
    for _ in range(maximum):
        proj.refine(); row=rvals(proj); hist.append(row)
        if row.get('converged') and abs(row.get('Max shft/sig',999))<0.25:
            break
    return hist


def mass(proj):
    try:return {k:{'value':v[0],'esd':v[1]} for k,v in proj.histogram(0).ComputeMassFracs().items()}
    except Exception as exc:return {'error':str(exc)}


def snapshot(proj,label,history=None):
    h=proj.histogram(0)
    return {
        'label':label,'rvals':rvals(proj),'history':history or [],
        'mass_fractions':mass(proj),'frozen':proj.get_Frozen(),
        'instrument':{k:list(v) for k,v in h.InstrumentParameters.items() if k in ('Zero','Polariz.','U','V','W','X','Y','Z','SH/L')},
        'sample':{k:list(v) for k,v in h.SampleParameters.items() if k in ('Shift','DisplaceX','Transparency','SurfRoughA','SurfRoughB')},
        'background':h.Background,
        'phases':[
            {'name':p.name,'cell':p.get_cell(),'hap':p.getHAPvalues(h.name)}
            for p in proj.phases()
        ],
        'vary_list':proj.get_VaryList(),
        'gpx':str(Path(proj.filename).relative_to(ROOT)),
    }


def clone(label):
    return G2sc.G2Project(gpxfile=str(COMMON),newgpx=str(OUT/f'{label}.gpx'))


# Reconverge and save a common neutral checkpoint.
COMMON=OUT/'common_neutral.gpx'
base=G2sc.G2Project(gpxfile=str(START),newgpx=str(COMMON))
base.set_Frozen()
base.set_Controls('cycles',12)
base_history=settle(base,5)
base.save()
results=[snapshot(base,'common_neutral',base_history)]


# Smooth background orders from the identical common checkpoint.
for order in (3,4,5,6,8,10):
    label=f'background_{order}'
    try:
        p=clone(label); h=p.histogram(0)
        h.set_refinements({'Background':{'type':'chebyschev-1','refine':True,'no. coeffs':order}})
        history=settle(p,5); p.save(); results.append(snapshot(p,label,history))
    except Exception as exc:results.append({'label':label,'error':str(exc)})


# Shared-intensity and specimen-geometry challenges before texture.
for label,kind in [('polarization','polarization'),('roughness_A','roughA'),('roughness_AB','roughAB')]:
    try:
        p=clone(label); h=p.histogram(0)
        if kind=='polarization':
            h.set_refinements({'Instrument Parameters':['Polariz.']})
            p.set_Controls('parmMin',0.0,variable=':0:Polariz.')
            p.set_Controls('parmMax',1.0,variable=':0:Polariz.')
        elif kind=='roughA':
            h.SampleParameters['SurfRoughA'][0]=0.01
            h.set_refinements({'Sample Parameters':['SurfRoughA']})
            p.set_Controls('parmMin',0.0,variable=':0:SurfRoughA')
        else:
            h.SampleParameters['SurfRoughA'][0]=0.01
            h.SampleParameters['SurfRoughB'][0]=0.01
            h.set_refinements({'Sample Parameters':['SurfRoughA','SurfRoughB']})
            p.set_Controls('parmMin',0.0,variable=':0:SurfRoughA')
            p.set_Controls('parmMin',0.0,variable=':0:SurfRoughB')
        history=settle(p,6);p.save();results.append(snapshot(p,label,history))
    except Exception as exc:
        traceback.print_exc();results.append({'label':label,'error':str(exc)})


# Per-phase neutral/size/strain/combined profile challenges.
phase_names=[p.name for p in base.phases()]
for pidx,pname in enumerate(phase_names):
    for mode in ('size','strain','size_strain'):
        label=f'profile_p{pidx}_{mode}'
        try:
            p=clone(label);ph=p.phase(pidx);hap=ph.getHAPvalues(p.histogram(0).name)
            if mode in ('size','size_strain'):
                hap['Size'][1][0]=2.0
                ph.set_HAP_refinements({'Size':{'type':'isotropic','value':2.0,'refine':True}})
            if mode in ('strain','size_strain'):
                hap['Mustrain'][1][0]=500.0
                ph.set_HAP_refinements({'Mustrain':{'type':'isotropic','refine':True}})
            history=settle(p,7);p.save();results.append(snapshot(p,label,history))
        except Exception as exc:
            traceback.print_exc();results.append({'label':label,'error':str(exc)})


# Low-index March-Dollase axes, one axis and one phase per replay.
axes={
    0:[[0,0,1],[1,0,0],[1,1,0],[1,0,1],[1,1,2]],
    1:[[1,0,0],[0,1,0],[0,0,1],[1,0,1],[1,0,-1],[2,0,-2]],
    2:[[1,0,0],[0,1,0],[0,0,1],[1,1,0],[0,1,1],[1,0,1]],
}
for pidx,axislist in axes.items():
    for axis in axislist:
        ax='m'.join(str(v) for v in axis)
        label=f'texture_p{pidx}_{ax}'
        try:
            p=clone(label);ph=p.phase(pidx);hap=ph.getHAPvalues(p.histogram(0).name)
            hap['Pref.Ori.'][0]='MD';hap['Pref.Ori.'][1]=1.0;hap['Pref.Ori.'][2]=True;hap['Pref.Ori.'][3]=list(axis)
            history=settle(p,6);p.save();results.append(snapshot(p,label,history))
        except Exception as exc:
            traceback.print_exc();results.append({'label':label,'error':str(exc)})


(OUT/'trials.json').write_text(json.dumps(results,indent=2,default=float))
print('SUMMARY')
for row in results:
    if 'error' in row:print(row['label'],'ERROR',row['error']);continue
    rv=row['rvals'];extra=''
    if row['label'].startswith('profile_'):
        idx=int(row['label'].split('_')[1][1:]);hap=row['phases'][idx]['hap'];extra=f" size={hap['Size'][1]} strain={hap['Mustrain'][1]}"
    elif row['label'].startswith('texture_'):
        idx=int(row['label'].split('_')[1][1:]);extra=f" MD={row['phases'][idx]['hap']['Pref.Ori.']}"
    elif row['label']=='polarization':extra=f" pol={row['instrument']['Polariz.']}"
    elif row['label'].startswith('roughness'):extra=f" rough={row['sample']['SurfRoughA']},{row['sample']['SurfRoughB']}"
    print(row['label'],'Rwp',rv.get('Rwp'),'chi',rv.get('chisq'),'k',rv.get('Nvars'),'shift',rv.get('Max shft/sig'),'frozen',row['frozen'],extra)
