from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT=Path.cwd()
BASE=ROOT/'.tmp/systematic_trials/common_neutral.gpx'
OUT=ROOT/'.tmp/shared_terms_trials'
OUT.mkdir(parents=True,exist_ok=True)


def rv(p):
    x=p.data['Covariance']['data']['Rvals']
    return {k:x[k] for k in ('chisq','Nobs','Nvars','Rwp','GOF','Max shft/sig','converged') if k in x}


def settle(p,n=4):
    hist=[]
    for _ in range(n):
        p.refine();hist.append(rv(p))
        if hist[-1].get('converged') and abs(hist[-1].get('Max shft/sig',999))<.25:break
    return hist


rows=[]
for order in (6,8,10):
    for pol,rough in ((False,False),(True,False),(False,True),(True,True)):
        label=f'o{order}'+('_pol' if pol else '')+('_roughB' if rough else '')
        p=G2sc.G2Project(gpxfile=str(BASE),newgpx=str(OUT/f'{label}.gpx'));h=p.histogram(0)
        h.set_refinements({'Background':{'type':'chebyschev-1','refine':True,'no. coeffs':order}})
        if pol:
            h.InstrumentParameters['Polariz.'][1]=0.93
            h.set_refinements({'Instrument Parameters':['Polariz.']})
            p.set_Controls('parmMin',0.0,variable=':0:Polariz.')
            p.set_Controls('parmMax',1.0,variable=':0:Polariz.')
        else:
            h.InstrumentParameters['Polariz.'][1]=0.5;h.InstrumentParameters['Polariz.'][2]=False
        h.SampleParameters['SurfRoughA'][:]=[0.0,False]
        if rough:
            h.SampleParameters['SurfRoughB'][:]=[0.12,True]
            p.set_Controls('parmMin',0.0,variable=':0:SurfRoughB')
            p.set_Controls('parmMax',1.0,variable=':0:SurfRoughB')
        else:h.SampleParameters['SurfRoughB'][:]=[0.0,False]
        p.set_Controls('cycles',12);p.set_Frozen();history=settle(p);p.save()
        mass={k:{'value':v[0],'esd':v[1]} for k,v in h.ComputeMassFracs().items()}
        rows.append({'label':label,'order':order,'polarization':h.InstrumentParameters['Polariz.'],'roughA':h.SampleParameters['SurfRoughA'],'roughB':h.SampleParameters['SurfRoughB'],'rvals':rv(p),'history':history,'mass':mass,'background':h.Background,'instrument':{k:list(v) for k,v in h.InstrumentParameters.items() if k in ('Zero','U','W','X')},'frozen':p.get_Frozen(),'vary':p.get_VaryList(),'gpx':str(Path(p.filename).relative_to(ROOT))})

(OUT/'trials.json').write_text(json.dumps(rows,indent=2,default=float))
for r in rows:print(r['label'],r['rvals'],'pol',r['polarization'],'B',r['roughB'],'mass',r['mass'],'frozen',r['frozen'])
