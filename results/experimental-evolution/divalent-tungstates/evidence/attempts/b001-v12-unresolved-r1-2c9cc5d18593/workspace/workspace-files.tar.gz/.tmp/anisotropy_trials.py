from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
BASE = ROOT / '.tmp/post_size_trials/MD_p0_1_1_0.gpx'
OUT = ROOT / '.tmp/anisotropy_trials'
OUT.mkdir(parents=True, exist_ok=True)


def rv(project):
    raw = project.data['Covariance']['data']['Rvals']
    return {key: raw[key] for key in
            ('chisq', 'Nobs', 'Nvars', 'Rwp', 'GOF', 'Max shft/sig', 'converged')
            if key in raw}


def settle(project, maximum=5):
    history = []
    for _ in range(maximum):
        project.refine()
        history.append(rv(project))
        if (history[-1].get('converged') and
                abs(history[-1].get('Max shft/sig', 999)) < 0.20):
            break
    return history


def configure_size(project, hap, phase_id, mode, values=(10.0, 10.0),
                   direction=(0, 0, 1)):
    size = hap['Size']
    size[5][:] = [False] * len(size[5])
    if mode == 'neutral':
        size[0] = 'isotropic'
        size[1][:] = [10.0, 10.0, 1.0]
        size[2][:] = [False] * len(size[2])
        return
    if mode == 'isotropic':
        size[0] = 'isotropic'
        size[1][:] = [values[0], 10.0, 1.0]
        size[2][:] = [True, False, False]
        names = ('Size;i',)
    elif mode == 'uniaxial':
        size[0] = 'uniaxial'
        size[1][:] = [values[0], values[1], 1.0]
        size[2][:] = [True, True, False]
        size[3] = list(direction)
        names = ('Size;i', 'Size;a')
    else:
        raise ValueError(mode)
    for name in names:
        project.set_Controls('parmMin', 0.01, variable=f'{phase_id}:0:{name}')
        project.set_Controls('parmMax', 10.0, variable=f'{phase_id}:0:{name}')


def configure_strain(project, hap, phase_id, mode, values=(0.0, 0.0),
                     direction=(0, 0, 1)):
    strain = hap['Mustrain']
    strain[5][:] = [False] * len(strain[5])
    if mode == 'neutral':
        strain[0] = 'isotropic'
        strain[1][0] = strain[1][1] = 0.0
        strain[2][:] = [False] * len(strain[2])
        return
    if mode == 'isotropic':
        strain[0] = 'isotropic'
        strain[1][0], strain[1][1] = values[0], 0.0
        strain[2][:] = [True, False, False]
        names = ('Mustrain;i',)
    elif mode == 'uniaxial':
        strain[0] = 'uniaxial'
        strain[1][0], strain[1][1] = values
        strain[2][:] = [True, True, False]
        strain[3] = list(direction)
        names = ('Mustrain;i', 'Mustrain;a')
    else:
        raise ValueError(mode)
    for name in names:
        project.set_Controls('parmMin', 0.0, variable=f'{phase_id}:0:{name}')
        project.set_Controls('parmMax', 10000.0, variable=f'{phase_id}:0:{name}')


TRIALS = [
    # label, p0 size mode, p0 strain mode, p2 size mode, p2 strain mode
    ('p0uniax_p2neutral', 'uniaxial', 'neutral', 'neutral', 'neutral'),
    ('p0iso_p2size', 'isotropic', 'neutral', 'isotropic', 'neutral'),
    ('p0uniax_p2size', 'uniaxial', 'neutral', 'isotropic', 'neutral'),
    ('p0uniax_p2combined', 'uniaxial', 'neutral', 'isotropic', 'isotropic'),
    ('p0uniax_p2usize010', 'uniaxial', 'neutral', 'uniaxial', 'neutral'),
    ('p0uniax_p2usize010_strain', 'uniaxial', 'neutral', 'uniaxial', 'isotropic'),
    ('p0uniax_p2size_ustrain010', 'uniaxial', 'neutral', 'isotropic', 'uniaxial'),
    ('p0uniax_strain_p2combined', 'uniaxial', 'isotropic', 'isotropic', 'isotropic'),
]

rows = []
for label, p0_size, p0_strain, p2_size, p2_strain in TRIALS:
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(OUT / f'{label}.gpx'))
    project.set_Frozen()
    project.set_Controls('cycles', 12)
    hist = project.histogram(0)
    hap0 = project.phase(0).getHAPvalues(hist.name)
    hap2 = project.phase(2).getHAPvalues(hist.name)
    configure_size(project, hap0, 0, p0_size, (.0939, .0887), (0, 0, 1))
    configure_strain(project, hap0, 0, p0_strain, (175.0, 175.0), (0, 0, 1))
    configure_size(project, hap2, 2, p2_size, (.30, .30), (0, 1, 0))
    configure_strain(project, hap2, 2, p2_strain, (600.0, 600.0), (0, 1, 0))
    history = settle(project)
    project.save()
    phases = []
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        phases.append({'name': phase.name, 'size': hap['Size'],
                       'strain': hap['Mustrain'], 'MD': hap['Pref.Ori.'],
                       'cell': phase.get_cell()})
    rows.append({
        'label': label,
        'rvals': rv(project),
        'history': history,
        'mass': {k: {'value': v[0], 'esd': v[1]}
                 for k, v in hist.ComputeMassFracs().items()},
        'frozen': project.get_Frozen(),
        'instrument': {k: list(v) for k, v in hist.InstrumentParameters.items()
                       if k in ('U', 'W', 'X')},
        'phases': phases,
        'gpx': str(Path(project.filename).relative_to(ROOT)),
    })

(OUT / 'trials.json').write_text(json.dumps(rows, indent=2, default=float))
for row in rows:
    p0, p2 = row['phases'][0], row['phases'][2]
    mass = {k: round(v['value'], 7) for k, v in row['mass'].items()}
    print(row['label'], row['rvals'], mass, 'frozen', row['frozen'],
          'p0', p0['size'][0:3], p0['strain'][0:3],
          'p2', p2['size'][0:3], p2['strain'][0:3])
