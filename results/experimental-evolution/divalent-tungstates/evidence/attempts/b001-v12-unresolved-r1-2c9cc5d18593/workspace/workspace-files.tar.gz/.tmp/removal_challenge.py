from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
BASE = ROOT / '.tmp/final_profile_loop/full_replay.gpx'
OUT = ROOT / '.tmp/removal_challenge'
OUT.mkdir(parents=True, exist_ok=True)


def rv(project):
    raw = project.data['Covariance']['data']['Rvals']
    return {key: raw[key] for key in
            ('chisq', 'Nobs', 'Nvars', 'Rwp', 'GOF', 'Max shft/sig', 'converged')
            if key in raw}


def settle(project, maximum=5):
    out = []
    for _ in range(maximum):
        project.refine()
        out.append(rv(project))
        if out[-1].get('converged') and abs(out[-1].get('Max shft/sig', 999)) < .25:
            break
    return out


rows = []
for idx, label in ((1, 'remove_WO3'), (2, 'remove_Ca3WO6')):
    project = G2sc.G2Project(gpxfile=str(BASE),
                             newgpx=str(OUT / f'{label}.gpx'))
    project.set_Frozen()
    project.set_Controls('cycles', 12)
    hist = project.histogram(0)
    removed = project.phase(idx)
    removed.clear_refinements({'Cell': True})
    hap = removed.getHAPvalues(hist.name)
    hap['Scale'][:] = [0.0, False]
    hap['Size'][2][:] = [False] * len(hap['Size'][2])
    hap['Size'][5][:] = [False] * len(hap['Size'][5])
    hap['Mustrain'][2][:] = [False] * len(hap['Mustrain'][2])
    hap['Mustrain'][5][:] = [False] * len(hap['Mustrain'][5])
    hap['Pref.Ori.'][2] = False
    # In deletion models, a surviving width term can otherwise run to a
    # compensating boundary. Fix only that challenged nuisance at its saved
    # value so the phase-removal comparison itself remains interior.
    if idx == 1:
        survivor = project.phase(2).getHAPvalues(hist.name)
        survivor['Size'][2][:] = [False] * len(survivor['Size'][2])
        survivor['Mustrain'][2][:] = [False] * len(survivor['Mustrain'][2])
        hist.InstrumentParameters['X'][2] = False
    elif idx == 2:
        survivor = project.phase(0).getHAPvalues(hist.name)
        survivor['Mustrain'][2][:] = [False] * len(survivor['Mustrain'][2])
    history = settle(project)
    project.save()
    rows.append({
        'label': label, 'history': history, 'rvals': rv(project),
        'mass': {k: {'value': v[0], 'esd': v[1]}
                 for k, v in hist.ComputeMassFracs().items()},
        'frozen': project.get_Frozen(),
        'gpx': str(Path(project.filename).relative_to(ROOT)),
    })

(OUT / 'trials.json').write_text(json.dumps(rows, indent=2, default=float))
for row in rows:
    print(row)
