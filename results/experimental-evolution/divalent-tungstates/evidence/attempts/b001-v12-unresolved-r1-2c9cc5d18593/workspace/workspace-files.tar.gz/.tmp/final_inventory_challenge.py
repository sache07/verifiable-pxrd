from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
BASE = ROOT / '.tmp/final_profile_loop/full_replay.gpx'
OUT = ROOT / '.tmp/final_inventory_challenge'
OUT.mkdir(parents=True, exist_ok=True)
CIF_ROOT = Path('<RUN>/resources/b001-c05/cif')


def cif(cod_id):
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


CANDIDATES = (
    ('CaO_1563196', cif('1563196')),
    ('CaWO4_fergusonite_1546035', cif('1546035')),
    ('Ca3WO6_P21_2310470', ROOT / '.tmp/models/Ca3WO6_from_Ca3UO6_P21_2310470.cif'),
    ('Ca3WO6_R3_2002703', ROOT / '.tmp/models/Ca3WO6_from_Mn3WO6_R3_2002703.cif'),
)


def rvals(project):
    raw = project.data['Covariance']['data']['Rvals']
    return {key: raw[key] for key in
            ('chisq', 'Nobs', 'Nvars', 'Rwp', 'GOF', 'Max shft/sig', 'converged')
            if key in raw}


def settle(project, maximum=6):
    history = []
    for _ in range(maximum):
        project.refine()
        history.append(rvals(project))
        if (history[-1].get('converged') and
                abs(history[-1].get('Max shft/sig', 999)) < 0.25):
            break
    return history


def neutralize(phase, hist):
    hap = phase.getHAPvalues(hist.name)
    hap['Size'][0] = 'isotropic'
    hap['Size'][1][:] = [10.0, 10.0, 1.0]
    hap['Size'][2][:] = [False] * len(hap['Size'][2])
    hap['Size'][5][:] = [False] * len(hap['Size'][5])
    hap['Mustrain'][0] = 'isotropic'
    hap['Mustrain'][1][0] = hap['Mustrain'][1][1] = 0.0
    hap['Mustrain'][2][:] = [False] * len(hap['Mustrain'][2])
    hap['Mustrain'][5][:] = [False] * len(hap['Mustrain'][5])
    hap['Pref.Ori.'][0] = 'MD'
    hap['Pref.Ori.'][1] = 1.0
    hap['Pref.Ori.'][2] = False
    hap['HStrain'][0][:] = [0.0] * len(hap['HStrain'][0])
    hap['HStrain'][1][:] = [False] * len(hap['HStrain'][1])


def snapshot(project):
    hist = project.histogram(0)
    return {
        'rvals': rvals(project),
        'mass': {k: {'value': v[0], 'esd': v[1]}
                 for k, v in hist.ComputeMassFracs().items()},
        'frozen': project.get_Frozen(),
        'phases': [{
            'name': phase.name, 'cell': phase.get_cell(),
            'scale': phase.getHAPvalues(hist.name)['Scale'],
            'size': phase.getHAPvalues(hist.name)['Size'],
            'strain': phase.getHAPvalues(hist.name)['Mustrain']}
            for phase in project.phases()],
    }


rows = []
for label, model in CANDIDATES:
    gpx = OUT / f'add_{label}.gpx'
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(gpx))
    project.set_Frozen()
    project.set_Controls('cycles', 12)
    hist = project.histogram(0)
    candidate = project.add_phase(str(model), phasename=label,
                                  histograms=[hist], fmthint='CIF')
    neutralize(candidate, hist)
    candidate.getHAPvalues(hist.name)['Scale'][:] = [0.05, True]
    project.set_Controls('parmMin', 0.0, variable='3:0:Scale')

    # Required scale-before-cell challenge from the same accepted checkpoint.
    scale_history = settle(project)
    scale_stage = snapshot(project)
    scale = candidate.getHAPvalues(hist.name)['Scale'][0]
    if scale > 1e-8 and '3:0:Scale' not in project.get_Frozen():
        project.set_Frozen()
        candidate.set_refinements({'Cell': True})
        cell_history = settle(project)
        cell_stage = snapshot(project)
    else:
        cell_history = []
        cell_stage = {'rejected': 'candidate scale collapsed or reached lower bound'}
    project.save()
    rows.append({
        'label': label, 'model': str(model),
        'scale_history': scale_history, 'scale_stage': scale_stage,
        'cell_history': cell_history, 'cell_stage': cell_stage,
        'gpx': str(gpx.relative_to(ROOT)),
    })

# Removal challenges: all saved values are reloaded before reconvergence.
for idx, label in ((1, 'remove_WO3'), (2, 'remove_Ca3WO6')):
    gpx = OUT / f'{label}.gpx'
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(gpx))
    project.set_Frozen()
    project.set_Controls('cycles', 12)
    hist = project.histogram(0)
    hap = project.phase(idx).getHAPvalues(hist.name)
    hap['Scale'][:] = [0.0, False]
    history = settle(project)
    project.save()
    rows.append({
        'label': label, 'history': history, 'stage': snapshot(project),
        'gpx': str(gpx.relative_to(ROOT)),
    })

(OUT / 'comparison.json').write_text(json.dumps(rows, indent=2, default=float))
for row in rows:
    if 'scale_stage' in row:
        print(row['label'], 'scale', row['scale_stage']['rvals'],
              row['scale_stage']['mass'], row['scale_stage']['frozen'])
        print('  cell', row['cell_stage'])
    else:
        print(row['label'], row['stage']['rvals'], row['stage']['mass'],
              row['stage']['frozen'])
