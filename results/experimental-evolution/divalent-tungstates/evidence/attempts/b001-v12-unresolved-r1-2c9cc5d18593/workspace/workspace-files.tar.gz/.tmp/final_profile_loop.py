from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
BASE = ROOT / '.tmp/anisotropy_trials/p0uniax_strain_p2combined.gpx'
OUT = ROOT / '.tmp/final_profile_loop'
OUT.mkdir(parents=True, exist_ok=True)


def rvals(project):
    raw = project.data['Covariance']['data']['Rvals']
    return {key: raw[key] for key in
            ('chisq', 'Nobs', 'Nvars', 'Rwp', 'GOF', 'Max shft/sig', 'converged')
            if key in raw}


def settle(project, maximum=5):
    history = []
    for _ in range(maximum):
        project.refine()
        history.append(rvals(project))
        if (history[-1].get('converged') and
                abs(history[-1].get('Max shft/sig', 999)) < 0.20):
            break
    return history


def open_trial(label):
    project = G2sc.G2Project(
        gpxfile=str(BASE), newgpx=str(OUT / f'{label}.gpx'))
    project.set_Frozen()
    project.set_Controls('cycles', 12)
    return project, project.histogram(0)


def summarize(project, label, history):
    hist = project.histogram(0)
    phases = []
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        phases.append({
            'name': phase.name, 'cell': phase.get_cell(), 'scale': hap['Scale'],
            'size': hap['Size'], 'strain': hap['Mustrain'],
            'MD': hap['Pref.Ori.']})
    return {
        'label': label, 'rvals': rvals(project), 'history': history,
        'mass': {k: {'value': v[0], 'esd': v[1]}
                 for k, v in hist.ComputeMassFracs().items()},
        'frozen': project.get_Frozen(), 'vary': project.get_VaryList(),
        'instrument': {k: list(v) for k, v in hist.InstrumentParameters.items()
                       if k in ('Zero', 'Polariz.', 'U', 'W', 'X', 'SH/L')},
        'sample': {k: list(v) for k, v in hist.SampleParameters.items()
                   if k in ('SurfRoughA', 'SurfRoughB')},
        'background': hist.Background, 'phases': phases,
        'gpx': str(Path(project.filename).relative_to(ROOT)),
    }


rows = []
labels = (
    'full_replay', 'order8', 'no_polarization', 'no_roughness',
    'p0_no_strain', 'p0_isotropic_size', 'p2_no_strain',
    'p2_no_size', 'p2_neutral', 'no_texture',
    'reseed_broad_low', 'reseed_broad_high')

for label in labels:
    project, hist = open_trial(label)
    hap0 = project.phase(0).getHAPvalues(hist.name)
    hap2 = project.phase(2).getHAPvalues(hist.name)

    if label == 'order8':
        hist.set_refinements({'Background': {
            'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 8}})
    elif label == 'no_polarization':
        hist.InstrumentParameters['Polariz.'][1:] = [0.5, False]
    elif label == 'no_roughness':
        hist.SampleParameters['SurfRoughA'][:] = [0.0, False]
        hist.SampleParameters['SurfRoughB'][:] = [0.0, False]
    elif label == 'p0_no_strain':
        hap0['Mustrain'][1][0] = 0.0
        hap0['Mustrain'][2][:] = [False] * len(hap0['Mustrain'][2])
    elif label == 'p0_isotropic_size':
        mean_size = sum(hap0['Size'][1][:2]) / 2.0
        hap0['Size'][0] = 'isotropic'
        hap0['Size'][1][:] = [mean_size, 10.0, 1.0]
        hap0['Size'][2][:] = [True, False, False]
    elif label == 'p2_no_strain':
        hap2['Mustrain'][1][0] = 0.0
        hap2['Mustrain'][2][:] = [False] * len(hap2['Mustrain'][2])
    elif label == 'p2_no_size':
        hap2['Size'][0] = 'isotropic'
        hap2['Size'][1][:] = [10.0, 10.0, 1.0]
        hap2['Size'][2][:] = [False] * len(hap2['Size'][2])
    elif label == 'p2_neutral':
        hap2['Size'][0] = 'isotropic'
        hap2['Size'][1][:] = [10.0, 10.0, 1.0]
        hap2['Size'][2][:] = [False] * len(hap2['Size'][2])
        hap2['Mustrain'][1][0] = 0.0
        hap2['Mustrain'][2][:] = [False] * len(hap2['Mustrain'][2])
    elif label == 'no_texture':
        hap0['Pref.Ori.'][1] = 1.0
        hap0['Pref.Ori.'][2] = False
    elif label == 'reseed_broad_low':
        hap0['Mustrain'][1][0] = 50.0
        hap2['Size'][1][0] = 0.15
        hap2['Mustrain'][1][0] = 200.0
    elif label == 'reseed_broad_high':
        hap0['Mustrain'][1][0] = 1000.0
        hap2['Size'][1][0] = 1.0
        hap2['Mustrain'][1][0] = 3000.0

    history = settle(project)
    project.save()
    rows.append(summarize(project, label, history))

(OUT / 'trials.json').write_text(json.dumps(rows, indent=2, default=float))
for row in rows:
    p0, p2 = row['phases'][0], row['phases'][2]
    mass = {k: round(v['value'], 7) for k, v in row['mass'].items()}
    print(row['label'], row['rvals'], mass, 'frozen', row['frozen'],
          'p0size', p0['size'][1], 'p0strain', p0['strain'][1],
          'MD', p0['MD'][1], 'p2size', p2['size'][1],
          'p2strain', p2['strain'][1])
