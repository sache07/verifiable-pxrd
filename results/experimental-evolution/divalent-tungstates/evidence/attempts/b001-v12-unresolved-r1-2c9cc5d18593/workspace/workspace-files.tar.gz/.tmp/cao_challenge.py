from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
BASE = ROOT / '.tmp/final_profile_loop/full_replay.gpx'
OUT = ROOT / '.tmp/cao_challenge'
OUT.mkdir(parents=True, exist_ok=True)
CIF_ROOT = Path('<RUN>/resources/b001-c05/cif')
CAO = CIF_ROOT / '1/56/31/1563196.cif'


def rvals(project):
    raw = project.data['Covariance']['data']['Rvals']
    return {key: raw[key] for key in
            ('chisq', 'Nobs', 'Nvars', 'Rwp', 'GOF', 'Max shft/sig', 'converged')
            if key in raw}


def settle(project, maximum=5):
    history = []
    for _ in range(maximum):
        project.refine()
        history.append(rvals(project))
        if (history[-1].get('converged') and
                abs(history[-1].get('Max shft/sig', 999)) < 0.20):
            break
    return history


def neutralize(phase, hist):
    hap = phase.getHAPvalues(hist.name)
    hap['Size'][0] = 'isotropic'
    hap['Size'][1][:] = [10.0, 10.0, 1.0]
    hap['Size'][2][:] = [False] * len(hap['Size'][2])
    hap['Size'][5][:] = [False] * len(hap['Size'][5])
    hap['Mustrain'][0] = 'isotropic'
    hap['Mustrain'][1][0] = hap['Mustrain'][1][1] = 0.0
    hap['Mustrain'][2][:] = [False] * len(hap['Mustrain'][2])
    hap['Mustrain'][5][:] = [False] * len(hap['Mustrain'][5])
    hap['Pref.Ori.'][0] = 'MD'
    hap['Pref.Ori.'][1] = 1.0
    hap['Pref.Ori.'][2] = False


def snapshot(project):
    hist = project.histogram(0)
    candidate = project.phase(3).getHAPvalues(hist.name)
    return {
        'rvals': rvals(project),
        'mass': {k: {'value': v[0], 'esd': v[1]}
                 for k, v in hist.ComputeMassFracs().items()},
        'frozen': project.get_Frozen(),
        'candidate': {
            'cell': project.phase(3).get_cell(), 'scale': candidate['Scale'],
            'size': candidate['Size'], 'strain': candidate['Mustrain'],
            'MD': candidate['Pref.Ori.']},
        'gpx': str(Path(project.filename).relative_to(ROOT)),
    }


# Build a replayable scale-only checkpoint with all other accepted terms open.
checkpoint = OUT / 'scale_checkpoint.gpx'
project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(checkpoint))
project.set_Frozen()
project.set_Controls('cycles', 12)
hist = project.histogram(0)
cao = project.add_phase(str(CAO), phasename='CaO_1563196',
                        histograms=[hist], fmthint='CIF')
neutralize(cao, hist)
cao.getHAPvalues(hist.name)['Scale'][:] = [0.4, True]
project.set_Controls('parmMin', 0.0, variable='3:0:Scale')
scale_history = settle(project)
project.save()

rows = [{'label': 'scale_checkpoint', 'history': scale_history,
         **snapshot(project)}]

trials = (
    ('full_replay', 'replay', None),
    ('cell', 'cell', None),
    ('size', 'size', None),
    ('strain', 'strain', None),
    ('combined', 'combined', None),
    ('MD_100', 'MD', [1, 0, 0]),
    ('MD_110', 'MD', [1, 1, 0]),
    ('MD_111', 'MD', [1, 1, 1]),
    ('order8', 'order8', None),
)

for label, mode, axis in trials:
    p = G2sc.G2Project(gpxfile=str(checkpoint),
                       newgpx=str(OUT / f'{label}.gpx'))
    p.set_Frozen()
    p.set_Controls('cycles', 12)
    h = p.histogram(0)
    phase = p.phase(3)
    hap = phase.getHAPvalues(h.name)
    if mode == 'cell':
        phase.set_refinements({'Cell': True})
    if mode in ('size', 'combined'):
        hap['Size'][1][0] = 1.0
        phase.set_HAP_refinements({'Size': {
            'type': 'isotropic', 'value': 1.0, 'refine': True}})
        p.set_Controls('parmMin', 0.01, variable='3:0:Size;i')
        p.set_Controls('parmMax', 10.0, variable='3:0:Size;i')
    if mode in ('strain', 'combined'):
        hap['Mustrain'][1][0] = 500.0
        phase.set_HAP_refinements({'Mustrain': {
            'type': 'isotropic', 'refine': True}})
        p.set_Controls('parmMin', 0.0, variable='3:0:Mustrain;i')
        p.set_Controls('parmMax', 10000.0, variable='3:0:Mustrain;i')
    if mode == 'MD':
        hap['Pref.Ori.'][0] = 'MD'
        hap['Pref.Ori.'][1] = 1.0
        hap['Pref.Ori.'][2] = True
        hap['Pref.Ori.'][3] = axis
        p.set_Controls('parmMin', 0.2, variable='3:0:MD')
        p.set_Controls('parmMax', 5.0, variable='3:0:MD')
    if mode == 'order8':
        h.set_refinements({'Background': {
            'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 8}})
    history = settle(p)
    p.save()
    rows.append({'label': label, 'history': history, **snapshot(p)})

(OUT / 'trials.json').write_text(json.dumps(rows, indent=2, default=float))
for row in rows:
    print(row['label'], row['rvals'], row['mass'], row['frozen'],
          'scale', row['candidate']['scale'], 'size', row['candidate']['size'][1],
          'strain', row['candidate']['strain'][1], 'MD', row['candidate']['MD'][1])
