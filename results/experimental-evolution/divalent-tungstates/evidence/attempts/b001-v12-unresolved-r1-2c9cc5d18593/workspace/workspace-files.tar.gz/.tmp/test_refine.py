from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
CIF_ROOT = Path('<RUN>/resources/b001-c05/cif')


def cif(cod_id):
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


def neutralize(phase, hist):
    hap = phase.getHAPvalues(hist.name)
    hap['Size'][0] = 'isotropic'
    hap['Size'][1][:] = [100.0, 100.0, 1.0]
    hap['Size'][2][:] = [False, False, False]
    hap['Size'][5][:] = [False] * len(hap['Size'][5])
    hap['Mustrain'][0] = 'isotropic'
    hap['Mustrain'][1][:] = [0.0, 0.0, 1.0]
    hap['Mustrain'][2][:] = [False, False, False]
    hap['Mustrain'][5][:] = [False] * len(hap['Mustrain'][5])
    hap['Pref.Ori.'][0] = 'MD'
    hap['Pref.Ori.'][1] = 1.0
    hap['Pref.Ori.'][2] = False
    hap['HStrain'][0][:] = [0.0] * len(hap['HStrain'][0])
    hap['HStrain'][1][:] = [False] * len(hap['HStrain'][1])


def snapshot(proj, label):
    h = proj.histogram(0)
    print('\nSNAPSHOT', label)
    print('residuals', json.dumps(h.residuals, default=float, sort_keys=True))
    print('inst', {k: v for k, v in h.InstrumentParameters.items() if k in ('Zero','U','V','W','X','Y','Z','SH/L','Polariz.','I(L2)/I(L1)')})
    print('background', h.Background[0])
    print('sample', {k:v for k,v in h.SampleParameters.items() if k in ('Scale','DisplaceX','Shift','SurfRoughA','SurfRoughB')})
    for ph in proj.phases():
        hap = ph.getHAPvalues(h.name)
        print('phase', ph.name, 'cell', ph.get_cell(), 'scale', hap['Scale'], 'size', hap['Size'], 'strain', hap['Mustrain'], 'MD', hap['Pref.Ori.'])
    print('vary', proj.get_VaryList())
    print('frozen', proj.get_Frozen())


gpx = ROOT / '.tmp' / 'two_phase_test.gpx'
proj = G2sc.G2Project(newgpx=str(gpx))
hist = proj.add_powder_histogram(str(ROOT/'inputs/pattern.csv'), str(ROOT/'.tmp/cu_ka.instprm'), fmthint='comma')
hist.SampleParameters['Scale'][:] = [1.0, False]
hist.SampleParameters['Shift'][:] = [0.0, False]
hist.SampleParameters['SurfRoughA'][:] = [0.0, False]
hist.SampleParameters['SurfRoughB'][:] = [0.0, False]
inst = hist.InstrumentParameters
for key, val in {'U':2.0,'V':0.0,'W':5.0,'X':0.1,'Y':0.0,'Z':0.0,'SH/L':0.002,'Zero':0.0,'Polariz.':0.5}.items():
    inst[key][0] = inst[key][1] = val
    inst[key][2] = False

p1 = proj.add_phase(str(cif('7219229')), phasename='CaWO4_7219229', histograms=[hist], fmthint='CIF')
p2 = proj.add_phase(str(cif('2311041')), phasename='WO3_2311041', histograms=[hist], fmthint='CIF')
for ph in (p1,p2):
    neutralize(ph,hist)
    ph.set_HAP_refinements({'Scale': True})

hist.set_refinements({'Background': {'type':'chebyschev-1','refine':True,'no. coeffs':6}})
proj.set_Controls('cycles', 12)

proj.refine()
snapshot(proj, 'scale_background')

hist.set_refinements({'Instrument Parameters':['Zero']})
proj.refine()
snapshot(proj, 'zero')

for ph in proj.phases(): ph.set_refinements({'Cell':True})
proj.refine()
snapshot(proj, 'cell')

hist.set_refinements({'Instrument Parameters':['U','W']})
proj.set_Controls('parmMin', 0.0, variable=':0:U')
proj.set_Controls('parmMin', 0.0, variable=':0:W')
proj.refine()
snapshot(proj, 'UW')

hist.set_refinements({'Instrument Parameters':['X']})
proj.set_Controls('parmMin', 0.0, variable=':0:X')
proj.refine()
snapshot(proj, 'UWX')

proj.save()
