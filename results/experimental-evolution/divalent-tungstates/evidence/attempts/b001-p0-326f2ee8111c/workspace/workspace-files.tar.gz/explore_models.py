from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(root / "trial.gpx"), newgpx=str(root / "model_pol.gpx"))
gpx.set_Controls("cycles", 12)
hist = gpx.histogram(0)
phase = gpx.phase(0)

# Reset to literature displacement parameters and remove their refinement flags.
for label, uiso, flags in [
    ("Ca1", 0.01225, " "),
    ("W1", 0.01098, " "),
    ("O1", 0.02571, "X"),
]:
    atom = phase.atom(label)
    atom.uiso = uiso
    atom.refinement_flags = flags

gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")
hist.set_refinements({"Instrument Parameters": ["Polariz."]})
gpx.refine(printFile=str(root / "model_pol.lst"), makeBack=False)
print("fixed literature Uiso, refined polarization")
print(hist.data["data"][0])
print(hist.data["Instrument Parameters"][0])
print(phase.get_cell())
for atom in phase.atoms():
    print(atom.label, atom.coordinates, atom.uiso, atom.refinement_flags)

# Check whether the data support positive individual Uiso values after allowing
# for the unknown effective polarization.
phase.set_refinements({"Atoms": {"Ca1": "U", "W1": "U", "O1": "XU"}})
gpx.refine(printFile=str(root / "model_pol_u.lst"), makeBack=False)
print("refined polarization and Uiso")
print(hist.data["data"][0])
print(hist.data["Instrument Parameters"][0])
print(phase.get_cell())
for atom in phase.atoms():
    print(atom.label, atom.coordinates, atom.uiso, atom.refinement_flags)
gpx.save()
