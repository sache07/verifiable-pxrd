from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(root / "model_pol.gpx"), newgpx=str(root / "secondary_test.gpx"))
gpx.set_Controls("cycles", 12)
hist = gpx.histogram(0)

# Ensure the principal phase's ADPs are fixed during the phase-presence test.
main = gpx.phase(0)
for label, flags in [("Ca1", " "), ("W1", " "), ("O1", "X")]:
    main.atom(label).refinement_flags = flags

candidates = [
    ("CaO_lime", "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/56/31/1563196.cif"),
    ("WO3_monoclinic", "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/01/06/1010618.cif"),
    ("Ca3WO6", "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/56/30/1563081.cif"),
]
for i, (name, cif) in enumerate(candidates, start=1):
    phase = gpx.add_phase(cif, phasename=name, histograms=[hist], fmthint="CIF")
    phase.data["Histograms"][hist.name]["Scale"][0] = 0.01
    phase.set_HAP_refinements({"Scale": True})
    gpx.set_Controls("parmMin", 0.0, f"{i}:0:Scale")

gpx.refine(printFile=str(root / "secondary_test.lst"), makeBack=False)
print(hist.data["data"][0])
for phase in gpx.phases():
    print(phase.id, phase.name, phase.data["Histograms"][hist.name]["Scale"])
print("variables", gpx.get_VaryList())
gpx.save()
