from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
candidates = [
    ("CaO_lime", "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/56/31/1563196.cif", 0.25),
    ("WO3_monoclinic", "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/01/06/1010618.cif", 0.05),
    ("WO3_P21c", "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif", 0.05),
    ("WO3_triclinic", "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/10/62/2106293.cif", 0.05),
    ("Ca3WO6", "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/56/30/1563081.cif", 1e-8),
]

for name, cif, initial_scale in candidates:
    stem = f"candidate_{name}"
    gpx = G2sc.G2Project(str(root / "model_pol.gpx"), newgpx=str(root / f"{stem}.gpx"))
    gpx.set_Controls("cycles", 8)
    hist = gpx.histogram(0)
    main = gpx.phase(0)
    for label, flags in [("Ca1", " "), ("W1", " "), ("O1", "X")]:
        main.atom(label).refinement_flags = flags
    phase = gpx.add_phase(cif, phasename=name, histograms=[hist], fmthint="CIF")
    phase.data["Histograms"][hist.name]["Scale"][0] = initial_scale
    phase.set_HAP_refinements({"Scale": True})
    gpx.set_Controls("parmMin", 0.0, "1:0:Scale")
    try:
        gpx.refine(printFile=str(root / f"{stem}.lst"), makeBack=False)
    except Exception as exc:
        print(name, "ERROR", repr(exc))
        continue
    print("\n", name)
    print(hist.data["data"][0])
    for p in gpx.phases():
        print(p.name, p.data["Histograms"][hist.name]["Scale"])
    gpx.save()
