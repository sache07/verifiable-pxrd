from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
INSTRUMENT = ROOT / "instrument.instprm"
START_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/7/21/92/7219229.cif"
)


def status(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    print(f"\n--- {label} ---")
    print("residuals", hist.data["data"][0])
    print("cell", phase.get_cell())
    print("instrument", hist.data["Instrument Parameters"][0])
    print("sample", hist.data["Sample Parameters"])
    print("HAP", phase.data["Histograms"][hist.name])
    print("atoms")
    for atom in phase.atoms():
        print(atom.label, atom.element, atom.coordinates, atom.occupancy,
              atom.uiso, atom.refinement_flags)
    print("vary", project.get_VaryList())


def refine(project, label):
    project.refine(printFile=str(ROOT / "trial.lst"), makeBack=False)
    status(project, label)


gpx_path = ROOT / "trial.gpx"
if gpx_path.exists():
    gpx_path.unlink()

gpx = G2sc.G2Project(newgpx=str(gpx_path))
gpx.set_Controls("cycles", 8)
hist = gpx.add_powder_histogram(
    str(PATTERN), str(INSTRUMENT), fmthint="comma"
)
phase = gpx.add_phase(
    str(START_CIF), phasename="CaWO4_scheelite", histograms=[hist],
    fmthint="CIF"
)

# Keep width parameters in their physically meaningful ranges. These bounds
# also prevent a trial step from generating pathologically broad profiles.
for variable, lower, upper in [
    (":0:U", 0.0, 200.0),
    (":0:W", 0.01, 200.0),
    (":0:X", 0.0, 20.0),
    (":0:Y", 0.0, 20.0),
    (":0:SH/L", 0.002, 0.20),
    # GSAS-II stores Bragg-Brentano specimen displacement in micrometres.
    (":0:Shift", -1000.0, 1000.0),
    ("0::AUiso:0", 0.0, 0.10),
    ("0::AUiso:1", 0.0, 0.10),
    ("0::AUiso:2", 0.0, 0.10),
]:
    gpx.set_Controls("parmMin", lower, variable)
    gpx.set_Controls("parmMax", upper, variable)

# Use a single phase scale; do not also vary the redundant overall sample scale.
hist.data["Sample Parameters"]["Scale"][1] = False
hist.set_refinements({
    "Limits": [10.0, 100.05],
    "Background": {
        "type": "chebyschev-1",
        "no. coeffs": 10,
        "coeffs": [1800.0] + [0.0] * 9,
        "refine": True,
    },
})
phase.set_HAP_refinements({"Scale": True})
refine(gpx, "background + scale")
phase.set_refinements({"Cell": True})
refine(gpx, "cell")

# Introduce the profile terms in stable groups.
hist.set_refinements({"Instrument Parameters": ["W"]})
refine(gpx, "W")
hist.set_refinements({"Instrument Parameters": ["U", "V"]})
refine(gpx, "Gaussian profile")

# Reflection geometry: allow one physically meaningful specimen-height shift.
hist.set_refinements({"Sample Parameters": ["Shift"]})
refine(gpx, "specimen shift")

# Refine the only free positional site (oxygen), then isotropic displacement
# factors. Occupancies remain fixed at the stoichiometric values.
phase.set_refinements({"Atoms": {"O1": "X"}})
refine(gpx, "oxygen coordinates")
phase.set_refinements({"Atoms": {"Ca1": "U", "W1": "U", "O1": "XU"}})
refine(gpx, "isotropic displacement factors")

gpx.save()
