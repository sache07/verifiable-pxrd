import csv
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(root / "model_pol.gpx"), newgpx=str(root / "final.gpx"))
gpx.set_Controls("cycles", 12)
hist = gpx.histogram(0)
phase = gpx.phase(0)

# Atomic displacement factors are not independently determined by this data
# because they correlate with the uncalibrated effective polarization. Keep the
# literature starting values fixed and retain only the oxygen positional flags.
for label, uiso, flags in [
    ("Ca1", 0.01225, " "),
    ("W1", 0.01098, " "),
    ("O1", 0.02571, "X"),
]:
    atom = phase.atom(label)
    atom.uiso = uiso
    atom.refinement_flags = flags

# Remove the trial-model boundary freezes and use the complete measured range.
gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
x_all = hist.data["data"][1][0]
hist.Limits("lower", float(x_all[0]))
hist.Limits("upper", float(x_all[-1]))

for _ in range(3):
    gpx.refine(printFile=str(root / "final.lst"), makeBack=False)
gpx.save()

# This CIF is exported from the same final in-memory project as final.gpx.
cif_path = root / "CaWO4_scheelite.cif"
phase.export_CIF(str(cif_path))

x, y_obs, weights, y_calc, y_bkg, y_diff_gsas = hist.data["data"][1]
y_diff = y_obs - y_calc
with open(root / "fit.csv", "w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow([
        "two_theta_deg",
        "observed_intensity",
        "calculated_intensity",
        "difference_intensity",
    ])
    writer.writerows(zip(x, y_obs, y_calc, y_diff))

residuals = hist.data["data"][0]
vary = gpx.get_VaryList()
chi2 = float(np.sum(weights * y_diff**2))
nobs = int(residuals["Nobs"])
nvars = len(vary)
print("residuals", residuals)
print("cell/esd", phase.get_cell_and_esd())
print("instrument", hist.data["Instrument Parameters"][0])
print("sample", hist.data["Sample Parameters"])
print("vary", vary)
print("chi2", chi2, "nobs", nobs, "nvars", nvars,
      "reduced", chi2 / (nobs - nvars))
for atom in phase.atoms():
    print(atom.label, atom.element, atom.coordinates, atom.uiso,
          atom.refinement_flags)
