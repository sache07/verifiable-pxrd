#!/usr/bin/env python3
"""Replay a saved GSAS-II baseline with one targeted nuisance model."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2sc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("mode", choices=["size", "strain"])
    parser.add_argument("phase", help="phase name or zero-based index")
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    histogram = project.histogram(0)
    try:
        phase_ref = int(args.phase)
    except ValueError:
        phase_ref = args.phase
    phase = project.phase(phase_ref)
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 16
    controls["min dM/M"] = 1.0e-6
    controls["parmFrozen"] = {"FrozenList": []}
    controls.setdefault("parmMinDict", {})
    controls.setdefault("parmMaxDict", {})

    if args.mode == "size":
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": 0.25,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            },
            [histogram],
        )
        variable = G2obj.G2VarObj(f"{phase.id}:{histogram.id}:Size;i")
        controls["parmMinDict"][variable] = 0.01
        controls["parmMaxDict"][variable] = 100.0
    else:
        hap = phase.data["Histograms"][histogram.name]
        hap["Mustrain"][1][0] = 600.0
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            },
            [histogram],
        )
        variable = G2obj.G2VarObj(f"{phase.id}:{histogram.id}:Mustrain;i")
        controls["parmMinDict"][variable] = 0.0
        controls["parmMaxDict"][variable] = 10000.0

    project.save()
    project.refine()
    project.refine()
    project.save()

    residuals = histogram.residuals
    payload = {
        "project": project.filename,
        "mode": args.mode,
        "phase": phase.name,
        "wR": residuals["wR"],
        "R": residuals["R"],
        "wRmin": residuals["wRmin"],
        "GoF": residuals["wR"] / residuals["wRmin"],
        "mass_fractions": histogram.ComputeMassFracs(),
        "X": histogram.InstrumentParameters["X"],
        "HAP": phase.getHAPvalues(histogram.name),
        "frozen": controls.get("parmFrozen"),
    }
    print(json.dumps(payload, indent=2, default=str))


if __name__ == "__main__":
    main()
