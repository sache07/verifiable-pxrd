#!/usr/bin/env python3
"""Replay a saved GSAS-II project with one global nuisance-model challenge."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2sc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument(
        "mode",
        choices=[
            "background6",
            "background10",
            "polarization",
            "roughness",
            "roughness_a",
            "roughness_b",
            "roughness_off",
            "polarization_off",
        ],
    )
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    histogram = project.histogram(0)
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 16
    controls["min dM/M"] = 1.0e-6
    controls["parmFrozen"] = {"FrozenList": []}
    controls.setdefault("parmMinDict", {})
    controls.setdefault("parmMaxDict", {})

    if args.mode.startswith("background"):
        terms = int(args.mode.removeprefix("background"))
        histogram.set_refinements(
            {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": terms}}
        )
    elif args.mode == "polarization":
        histogram.InstrumentParameters["Polariz."][1] = 0.5
        histogram.set_refinements({"Instrument Parameters": ["Polariz."]})
        variable = G2obj.G2VarObj(f":{histogram.id}:Polariz.")
        controls["parmMinDict"][variable] = 0.0
        controls["parmMaxDict"][variable] = 1.0
    elif args.mode == "polarization_off":
        histogram.InstrumentParameters["Polariz."][1] = 0.5
        histogram.InstrumentParameters["Polariz."][2] = False
    elif args.mode == "roughness_off":
        histogram.SampleParameters["SurfRoughA"] = [0.0, False]
        histogram.SampleParameters["SurfRoughB"] = [0.0, False]
    elif args.mode == "roughness":
        histogram.SampleParameters["SurfRoughA"] = [0.5, True]
        histogram.SampleParameters["SurfRoughB"] = [0.01, True]
        a_var = G2obj.G2VarObj(f":{histogram.id}:SurfRoughA")
        b_var = G2obj.G2VarObj(f":{histogram.id}:SurfRoughB")
        controls["parmMinDict"][a_var] = 0.0
        controls["parmMaxDict"][a_var] = 1.0
        controls["parmMinDict"][b_var] = 0.0
        controls["parmMaxDict"][b_var] = 1.0
    elif args.mode == "roughness_a":
        histogram.SampleParameters["SurfRoughA"] = [0.2, True]
        histogram.SampleParameters["SurfRoughB"] = [0.1, False]
        a_var = G2obj.G2VarObj(f":{histogram.id}:SurfRoughA")
        controls["parmMinDict"][a_var] = 0.0
        controls["parmMaxDict"][a_var] = 1.0
    else:
        histogram.SampleParameters["SurfRoughA"] = [0.0, False]
        histogram.SampleParameters["SurfRoughB"] = [0.05, True]
        b_var = G2obj.G2VarObj(f":{histogram.id}:SurfRoughB")
        controls["parmMinDict"][b_var] = 0.0
        controls["parmMaxDict"][b_var] = 1.0

    project.save()
    project.refine()
    project.refine()
    project.save()

    residuals = histogram.residuals
    payload = {
        "project": project.filename,
        "mode": args.mode,
        "wR": residuals["wR"],
        "R": residuals["R"],
        "wRmin": residuals["wRmin"],
        "GoF": residuals["wR"] / residuals["wRmin"],
        "mass_fractions": histogram.ComputeMassFracs(),
        "background": histogram.Background[0],
        "polarization": histogram.InstrumentParameters["Polariz."],
        "roughness": {
            "A": histogram.SampleParameters["SurfRoughA"],
            "B": histogram.SampleParameters["SurfRoughB"],
        },
        "frozen": controls.get("parmFrozen"),
    }
    print(json.dumps(payload, indent=2, default=str))


if __name__ == "__main__":
    main()
