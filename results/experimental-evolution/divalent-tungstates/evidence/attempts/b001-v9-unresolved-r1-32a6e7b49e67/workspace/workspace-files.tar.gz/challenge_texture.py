#!/usr/bin/env python3
"""Replay a no-texture GSAS-II baseline with one March-Dollase direction."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2sc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("phase")
    parser.add_argument("h", type=int)
    parser.add_argument("k", type=int)
    parser.add_argument("l", type=int)
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    histogram = project.histogram(0)
    try:
        phase_ref = int(args.phase)
    except ValueError:
        phase_ref = args.phase
    phase = project.phase(phase_ref)
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 16
    controls["min dM/M"] = 1.0e-6
    controls["parmFrozen"] = {"FrozenList": []}
    controls.setdefault("parmMinDict", {})
    controls.setdefault("parmMaxDict", {})

    hap = phase.data["Histograms"][histogram.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = [args.h, args.k, args.l]
    variable = G2obj.G2VarObj(f"{phase.id}:{histogram.id}:MD")
    controls["parmMinDict"][variable] = 0.2
    controls["parmMaxDict"][variable] = 5.0

    project.save()
    project.refine()
    project.refine()
    project.save()

    residuals = histogram.residuals
    covariance = project.data["Covariance"]["data"]
    payload = {
        "project": project.filename,
        "phase": phase.name,
        "direction": [args.h, args.k, args.l],
        "wR": residuals["wR"],
        "R": residuals["R"],
        "wRmin": residuals["wRmin"],
        "GoF": residuals["wR"] / residuals["wRmin"],
        "mass_fractions": histogram.ComputeMassFracs(),
        "preferred_orientation": phase.getHAPvalues(histogram.name)["Pref.Ori."],
        "vary_list": covariance.get("varyList", []),
        "frozen": controls.get("parmFrozen"),
    }
    print(json.dumps(payload, indent=2, default=str))


if __name__ == "__main__":
    main()
