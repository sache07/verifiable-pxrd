#!/usr/bin/env python3
"""Compare specimen displacement with the selected single zero correction."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    histogram = project.histogram(0)
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1.0e-6
    controls["parmFrozen"] = {"FrozenList": []}
    controls.setdefault("parmMinDict", {})
    controls.setdefault("parmMaxDict", {})

    # Use exactly one angular correction. The approximate displacement that
    # corresponds to the fitted -0.2 degree zero is +350 micrometres in the
    # GSAS-II Bragg-Brentano sign convention.
    histogram.InstrumentParameters["Zero"][1] = 0.0
    histogram.InstrumentParameters["Zero"][2] = False
    histogram.SampleParameters["Shift"] = [350.0, True]
    variable = G2obj.G2VarObj(f":{histogram.id}:Shift")
    controls["parmMinDict"][variable] = -1000.0
    controls["parmMaxDict"][variable] = 1000.0

    project.save()
    project.refine()
    project.refine()
    project.save()
    print(
        json.dumps(
            {
                "project": project.filename,
                "residuals": histogram.residuals,
                "zero": histogram.InstrumentParameters["Zero"],
                "shift": histogram.SampleParameters["Shift"],
                "mass_fractions": histogram.ComputeMassFracs(),
                "frozen": controls.get("parmFrozen"),
            },
            indent=2,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
