#!/usr/bin/env python3
"""Test nonnegative low-dimensional common Gaussian profile terms."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("mode", choices=["U", "W", "UW"])
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    histogram = project.histogram(0)
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1.0e-6
    controls["parmFrozen"] = {"FrozenList": []}
    controls.setdefault("parmMinDict", {})
    controls.setdefault("parmMaxDict", {})

    names = list(args.mode)
    for name in ("U", "W"):
        histogram.InstrumentParameters[name][1] = 0.0
        histogram.InstrumentParameters[name][2] = False
    for name in names:
        histogram.InstrumentParameters[name][1] = 1.0
        variable = G2obj.G2VarObj(f":{histogram.id}:{name}")
        controls["parmMinDict"][variable] = 0.0
        controls["parmMaxDict"][variable] = 100.0
    histogram.set_refinements({"Instrument Parameters": names + ["X"]})

    project.save()
    project.refine()
    project.refine()
    project.save()
    print(
        json.dumps(
            {
                "project": project.filename,
                "mode": args.mode,
                "residuals": histogram.residuals,
                "profile": {
                    key: histogram.InstrumentParameters[key]
                    for key in ("U", "V", "W", "X", "Y", "Z")
                },
                "mass_fractions": histogram.ComputeMassFracs(),
                "frozen": controls.get("parmFrozen"),
            },
            indent=2,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
