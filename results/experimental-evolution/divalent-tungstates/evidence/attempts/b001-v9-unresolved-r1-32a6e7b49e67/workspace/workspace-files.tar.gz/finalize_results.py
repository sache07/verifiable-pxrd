#!/usr/bin/env python3
"""Create, replay, and export the accepted GSAS-II model and result files."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc

from gsas_trials import neutralize_phase_terms


ROOT = Path(__file__).resolve().parent
PHASE_EXPORTS = {
    "CaWO4_scheelite": ("CaWO4 (scheelite)", "CaWO4", "CaWO4.cif"),
    "WO3_monoclinic": ("WO3 (monoclinic)", "WO3", "WO3.cif"),
    "Ca3WO6_from_Ca3OsO6": ("Ca3WO6 (monoclinic analogue)", "Ca3WO6", "Ca3WO6.cif"),
}


def neutralize_hstrain(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hstrain = hap["HStrain"]
    hstrain[0] = [0.0 for _ in hstrain[0]]
    hstrain[1] = [False for _ in hstrain[1]]


def clean_model(project: G2sc.G2Project) -> None:
    histogram = project.histogram(0)
    inst = histogram.InstrumentParameters
    sample = histogram.SampleParameters

    # Full measured range and a fixed global histogram scale.
    histogram.data["Limits"][1] = list(histogram.data["Limits"][0])
    sample["Scale"] = [1.0, False]

    # One angular correction only: Bragg-Brentano specimen displacement.
    inst["Zero"][1:] = [0.0, False]
    sample["Shift"][1] = True
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key] = [0.0, False]

    # Supported common profile and intensity terms. All other profile terms
    # are explicitly neutral both by value and refinement flag.
    for key in ("U", "W", "X", "Polariz."):
        inst[key][2] = True
    for key in ("V", "Y", "Z"):
        inst[key][1:] = [0.0, False]
    inst["SH/L"][1:] = [0.0005, False]

    # Keep only the supported CaWO4 size and [110] March-Dollase term.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][1] = True
        if phase.name == "CaWO4_scheelite":
            size = hap["Size"]
            size[0] = "isotropic"
            size[2] = [True, False, False]
            if len(size) > 5:
                size[5] = [False for _ in size[5]]
            pref = hap["Pref.Ori."]
            pref[0] = "MD"
            pref[2] = True
            pref[3] = [1, 1, 0]
            mustrain = hap["Mustrain"]
            mustrain[0] = "isotropic"
            mustrain[1] = [0.0, 0.0, 1.0]
            mustrain[2] = [False, False, False]
            if len(mustrain) > 4:
                mustrain[4] = [0.0 for _ in mustrain[4]]
            if len(mustrain) > 5:
                mustrain[5] = [False for _ in mustrain[5]]
            hap["Extinction"] = [0.0, False]
            hap["Babinet"]["BabA"] = [0.0, False]
            hap["Babinet"]["BabU"] = [0.0, False]
        else:
            neutralize_phase_terms(phase, histogram.name)
        neutralize_hstrain(phase, histogram.name)

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1.0e-6
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}

    # Rebuild only bounds belonging to retained variables.
    bounds = {
        "U": (0.0, 500.0),
        "W": (0.0, 500.0),
        "X": (0.0, 100.0),
        "Polariz.": (0.0, 1.0),
        "Shift": (-1000.0, 1000.0),
    }
    for name, (lower, upper) in bounds.items():
        variable = project.make_var_obj(hist=histogram, varname=name, reloadIdx=True)
        controls["parmMinDict"][variable] = lower
        controls["parmMaxDict"][variable] = upper
    for phase in project.phases():
        variable = project.make_var_obj(
            phase=phase, hist=histogram, varname="Scale", reloadIdx=True
        )
        controls["parmMinDict"][variable] = 0.0
    cawo4 = project.phase("CaWO4_scheelite")
    for name, lower, upper in (("Size;i", 0.01, 100.0), ("MD", 0.2, 5.0)):
        variable = project.make_var_obj(
            phase=cawo4, hist=histogram, varname=name, reloadIdx=True
        )
        controls["parmMinDict"][variable] = lower
        controls["parmMaxDict"][variable] = upper


def replay(project: G2sc.G2Project, cycles: int) -> None:
    for _ in range(cycles):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.refine()
    project.save()


def export_outputs(project: G2sc.G2Project) -> dict:
    histogram = project.histogram(0)
    mass = histogram.ComputeMassFracs()
    total = sum(float(value[0]) for value in mass.values())

    phases = []
    for internal_name, (name, formula, filename) in PHASE_EXPORTS.items():
        phase = project.phase(internal_name)
        phase.export_CIF(str(ROOT / filename))
        fraction, esd = mass[internal_name]
        phases.append(
            {
                "name": name,
                "formula": formula,
                "cif_path": filename,
                "weight_fraction": float(fraction) / total,
                "weight_fraction_esd": float(esd) / total,
            }
        )

    x = np.asarray(histogram.getdata("X"), dtype=float)
    observed = np.asarray(histogram.getdata("Yobs"), dtype=float)
    calculated = np.asarray(histogram.getdata("Ycalc"), dtype=float)
    background = np.asarray(histogram.getdata("Background"), dtype=float)
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, observed, calculated, difference, background]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )

    residuals = histogram.residuals
    rwp = float(residuals["wR"])
    rexp = float(residuals["wRmin"])
    covariance = project.data["Covariance"]["data"]
    result = {
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": rexp,
            "goodness_of_fit": rwp / rexp,
            "reduced_chi_squared": (rwp / rexp) ** 2,
            "n_profile_points": int(x.size),
            "n_refined_variables": len(covariance.get("varyList", [])),
            "difference_rms_counts": float(np.sqrt(np.mean(difference**2))),
        },
    }
    with (ROOT / "result.json").open("w", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", nargs="?", default="trial_three_shift_tex_110.gpx")
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=str(ROOT / "final.gpx"))
    clean_model(project)
    project.save()
    replay(project, 2)

    # Required saved-project replay: reopen the exact final path and run the
    # complete measured range once more before producing any submitted file.
    project = G2sc.G2Project(str(ROOT / "final.gpx"))
    clean_model(project)
    replay(project, 1)

    # Reopen once more so every exported value/profile is read from final.gpx.
    project = G2sc.G2Project(str(ROOT / "final.gpx"))
    result = export_outputs(project)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
