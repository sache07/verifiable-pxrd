#!/usr/bin/env python3
"""Inspect a GSAS-II profile numerically and optionally make a diagnostic plot."""

from __future__ import annotations

import argparse
import json

import numpy as np
from scipy.signal import find_peaks

from GSASII import GSASIIscriptable as G2sc


def crossing(x0, y0, x1, y1, level):
    if y1 == y0:
        return 0.5 * (x0 + x1)
    return x0 + (level - y0) * (x1 - x0) / (y1 - y0)


def peak_metrics(x, profile, target, radius=0.32):
    indices = np.flatnonzero((x >= target - radius) & (x <= target + radius))
    peak_index = indices[np.argmax(profile[indices])]
    level = 0.5 * profile[peak_index]

    left = peak_index
    while left > indices[0] and profile[left] > level:
        left -= 1
    right = peak_index
    while right < indices[-1] and profile[right] > level:
        right += 1

    if left == indices[0] or right == indices[-1]:
        return {
            "position": float(x[peak_index]),
            "height": float(profile[peak_index]),
            "left_half_width": None,
            "right_half_width": None,
            "fwhm": None,
        }

    left_x = crossing(x[left], profile[left], x[left + 1], profile[left + 1], level)
    right_x = crossing(
        x[right - 1], profile[right - 1], x[right], profile[right], level
    )
    return {
        "position": float(x[peak_index]),
        "height": float(profile[peak_index]),
        "left_half_width": float(x[peak_index] - left_x),
        "right_half_width": float(right_x - x[peak_index]),
        "fwhm": float(right_x - left_x),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("--plot")
    parser.add_argument("--profile-csv")
    parser.add_argument("--targets", nargs="*", type=float, default=[18.43356, 45.27357, 85.92477])
    args = parser.parse_args()

    project = G2sc.G2Project(args.project)
    histogram = project.histogram(0)
    x = np.asarray(histogram.getdata("X"))
    observed = np.asarray(histogram.getdata("Yobs"))
    calculated = np.asarray(histogram.getdata("Ycalc"))
    background = np.asarray(histogram.getdata("Background"))
    difference = observed - calculated
    observed_net = observed - background
    calculated_net = calculated - background

    peaks, props = find_peaks(
        difference,
        prominence=100.0,
        distance=8,
    )
    ranked = sorted(
        (
            {
                "two_theta": float(x[index]),
                "difference": float(difference[index]),
                "prominence": float(props["prominences"][i]),
            }
            for i, index in enumerate(peaks)
        ),
        key=lambda row: row["prominence"],
        reverse=True,
    )

    payload = {
        "residuals": histogram.residuals,
        "spot_checks": {
            str(target): {
                "observed": peak_metrics(x, observed_net, target),
                "calculated": peak_metrics(x, calculated_net, target),
            }
            for target in args.targets
        },
        "largest_positive_residual_peaks": ranked[:30],
        "difference_rms_counts": float(np.sqrt(np.mean(difference**2))),
        "difference_mean_counts": float(np.mean(difference)),
    }
    print(json.dumps(payload, indent=2))

    if args.profile_csv:
        np.savetxt(
            args.profile_csv,
            np.column_stack([x, observed, calculated, difference, background]),
            delimiter=",",
            header="two_theta_deg,observed,calculated,difference,background",
            comments="",
        )

    if args.plot:
        import matplotlib.pyplot as plt
        fig, axes = plt.subplots(
            2, 1, figsize=(13, 8), sharex=True,
            gridspec_kw={"height_ratios": [3, 1]},
        )
        axes[0].plot(x, observed, color="black", lw=0.65, label="observed")
        axes[0].plot(x, calculated, color="#d62728", lw=0.75, label="calculated")
        axes[0].plot(x, background, color="#1f77b4", lw=0.6, label="background")
        axes[0].set_ylabel("counts")
        axes[0].legend(loc="upper right", frameon=False)
        axes[1].axhline(0, color="0.55", lw=0.5)
        axes[1].plot(x, difference, color="#2ca02c", lw=0.6)
        axes[1].set_xlabel(r"$2\theta$ (degrees)")
        axes[1].set_ylabel("obs − calc")
        axes[1].set_xlim(x[0], x[-1])
        fig.tight_layout()
        fig.savefig(args.plot, dpi=180)


if __name__ == "__main__":
    main()
