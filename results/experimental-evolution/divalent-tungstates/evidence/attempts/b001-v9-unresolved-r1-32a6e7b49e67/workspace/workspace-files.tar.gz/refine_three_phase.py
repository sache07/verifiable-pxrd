#!/usr/bin/env python3
"""Reconcile the accepted three-phase inventory after scale-first testing."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc

from gsas_trials import summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--phase", default="Ca3WO6_from_Ca3OsO6")
    parser.add_argument("--cycles", type=int, default=3)
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1.0e-6
    controls["parmFrozen"] = {"FrozenList": []}

    # The candidate's cell was intentionally held fixed for its scale test.
    # It is released only after the scale has survived reopening and replay.
    project.phase(args.phase).set_refinements({"Cell": True})
    project.save()

    # Existing flags jointly reconverge background, all scales/cells, one
    # zero correction, the common X profile, polarization, CaWO4 size and MD.
    for _ in range(args.cycles):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.refine()
    project.save()

    print(json.dumps(summary(project), indent=2, default=str))


if __name__ == "__main__":
    main()
