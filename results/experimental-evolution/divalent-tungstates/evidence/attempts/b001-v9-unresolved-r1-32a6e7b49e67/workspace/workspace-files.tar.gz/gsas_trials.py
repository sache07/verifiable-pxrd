#!/usr/bin/env python3
"""Create and refine controlled GSAS-II trial projects for this dataset."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
RESOURCE_CIF = Path(
    "<RUN>/"
    "resources/b001-c05/cif"
)

CANDIDATES = {
    "CaWO4_scheelite": RESOURCE_CIF / "7/21/92/7219229.cif",
    "CaWO4_monoclinic": RESOURCE_CIF / "1/54/60/1546035.cif",
    "WO3_monoclinic": RESOURCE_CIF / "2/31/10/2311041.cif",
    "WO3_monoclinic_short_OO": RESOURCE_CIF / "1/52/89/1528915.cif",
    "WO3_triclinic": RESOURCE_CIF / "2/10/62/2106293.cif",
    "WO3_monoclinic_small_cell": RESOURCE_CIF / "1/56/35/1563541.cif",
    "WO3_orthorhombic": RESOURCE_CIF / "2/10/73/2107312.cif",
    "WO3_tetragonal": RESOURCE_CIF / "1/52/15/1521533.cif",
    "WO3_hexagonal": RESOURCE_CIF / "1/00/40/1004057.cif",
    "CaO": RESOURCE_CIF / "1/56/31/1563196.cif",
    "Ca3WO6_from_Ca3OsO6": ROOT / "candidates/Ca3WO6_from_Ca3OsO6.cif",
    "Ca3WO6_from_Ca3UO6": ROOT / "candidates/Ca3WO6_from_Ca3UO6.cif",
    "Ca3W2O9_from_Sr3W2O9": ROOT / "candidates/Ca3W2O9_from_Sr3W2O9.cif",
    "Ca2WO5_from_Ba2ReO5": ROOT / "candidates/Ca2WO5_from_Ba2ReO5.cif",
}


def neutralize_phase_terms(phase, histogram_name: str) -> None:
    """Remove default phase-specific profile/texture effects by value and flag."""
    hap = phase.data["Histograms"][histogram_name]

    # GSAS-II sizes are in micrometres. Ten micrometres is effectively
    # unbroadened over this pattern and meets the neutral-term gate.
    size = hap["Size"]
    size[0] = "isotropic"
    size[1][0] = 10.0
    size[1][1] = 10.0
    size[1][2] = 1.0
    size[2] = [False for _ in size[2]]
    if len(size) > 4:
        size[4] = [10.0 for _ in size[4]]
    if len(size) > 5:
        size[5] = [False for _ in size[5]]

    mustrain = hap["Mustrain"]
    mustrain[0] = "isotropic"
    mustrain[1][0] = 0.0
    mustrain[1][1] = 0.0
    mustrain[1][2] = 1.0
    mustrain[2] = [False for _ in mustrain[2]]
    if len(mustrain) > 4:
        mustrain[4] = [0.0 for _ in mustrain[4]]
    if len(mustrain) > 5:
        mustrain[5] = [False for _ in mustrain[5]]

    pref = hap["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = False
    pref[3] = [0, 0, 1]
    if len(pref) > 4:
        pref[4] = 0
    if len(pref) > 5 and isinstance(pref[5], dict):
        pref[5].clear()

    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def setup_project(output: Path, phase_names: list[str], background_terms: int) -> G2sc.G2Project:
    project = G2sc.G2Project(newgpx=str(output))
    histogram = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    histogram.set_refinements(
        {
            "Limits": [9.90343322, 100.09455322],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": background_terms,
            },
        }
    )

    # The data importer defaults this flag on. Keep the histogram scale fixed
    # so that only independent phase scales determine the mass fractions.
    histogram.SampleParameters["Scale"] = [1.0, False]

    # Explicitly neutralize Bragg-Brentano specimen terms.
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in histogram.SampleParameters:
            histogram.SampleParameters[key][0] = 0.0
            histogram.SampleParameters[key][1] = False

    for name in phase_names:
        phase = project.add_phase(
            str(CANDIDATES[name]),
            phasename=name,
            histograms=[histogram],
            fmthint="CIF",
        )
        neutralize_phase_terms(phase, histogram.name)
        phase.data["Histograms"][histogram.name]["Scale"] = [1.0, True]

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-5
    controls.setdefault("parmMinDict", {})
    controls["parmMinDict"][G2obj.G2VarObj(":0:X")] = 0.0
    for phase in project.phases():
        controls["parmMinDict"][
            G2obj.G2VarObj(f"{phase.id}:0:Scale")
        ] = 0.0
    project.save()
    return project


def refine_baseline(project: G2sc.G2Project, refine_cells: bool = True) -> None:
    hist = project.histogram(0)

    # First establish background and positive scales with fixed cells/profile.
    project.refine()
    project.refine()

    # The full nonnegative U/W/X challenge drove both Gaussian terms to their
    # zero bounds. Replay the supported simpler common profile explicitly.
    for parameter in ("U", "W"):
        hist.InstrumentParameters[parameter][1] = 0.0
        hist.InstrumentParameters[parameter][2] = False
    hist.InstrumentParameters["X"][1] = 16.0
    hist.set_refinements({"Instrument Parameters": ["Zero", "X"]})
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.refine()

    if refine_cells:
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
        project.refine()

    # Re-establish background, scales, cells and profile together.
    project.refine()
    project.save()


def summary(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    return {
        "project": project.filename,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {
            key: value
            for key, value in hist.InstrumentParameters.items()
            if key in [
                "Lam1",
                "Lam2",
                "I(L2)/I(L1)",
                "Zero",
                "Polariz.",
                "U",
                "V",
                "W",
                "X",
                "Y",
                "Z",
                "SH/L",
            ]
        },
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "cell_esd": phase.get_cell_and_esd()[1],
                "hap": phase.getHAPvalues(hist.name),
            }
            for phase in project.phases()
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phases", nargs="+", choices=sorted(CANDIDATES))
    parser.add_argument("--background-terms", type=int, default=8)
    parser.add_argument("--no-cell", action="store_true")
    args = parser.parse_args()

    project = setup_project(args.output, args.phases, args.background_terms)
    refine_baseline(project, refine_cells=not args.no_cell)
    print(json.dumps(summary(project), indent=2, default=str))


if __name__ == "__main__":
    main()
