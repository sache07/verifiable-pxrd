#!/usr/bin/env python3
"""Add one health-screened watch-list phase and test its scale before its cell."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc

from gsas_trials import CANDIDATES, neutralize_phase_terms


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("candidate", choices=sorted(CANDIDATES))
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    histogram = project.histogram(0)
    phase = project.add_phase(
        str(CANDIDATES[args.candidate]),
        phasename=args.candidate,
        histograms=[histogram],
        fmthint="CIF",
    )
    neutralize_phase_terms(phase, histogram.name)
    phase.data["Histograms"][histogram.name]["Scale"] = [0.1, True]
    phase.data["General"]["Cell"][0] = False

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 16
    controls["min dM/M"] = 1.0e-6
    controls["parmFrozen"] = {"FrozenList": []}
    controls.setdefault("parmMinDict", {})
    project.save()
    scale_var = project.make_var_obj(
        phase=phase, hist=histogram, varname="Scale", reloadIdx=True
    )
    controls["parmMinDict"][scale_var] = 0.0
    project.save()

    # Matched-nuisance scale test with the candidate cell fixed.
    project.refine()
    first_scale = phase.getHAPvalues(histogram.name)["Scale"][0]
    first_wR = histogram.residuals["wR"]
    project.save()

    # Reopen and replay once to test scale stability.
    project = G2sc.G2Project(args.output)
    histogram = project.histogram(0)
    phase = project.phase(args.candidate)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.refine()
    project.save()
    second_scale = phase.getHAPvalues(histogram.name)["Scale"][0]
    second_wR = histogram.residuals["wR"]

    payload = {
        "project": project.filename,
        "candidate": args.candidate,
        "cell_refined": phase.data["General"]["Cell"][0],
        "first_scale": first_scale,
        "second_scale": second_scale,
        "first_wR": first_wR,
        "second_wR": second_wR,
        "mass_fractions": histogram.ComputeMassFracs(),
        "frozen": project.data["Controls"]["data"].get("parmFrozen"),
    }
    print(json.dumps(payload, indent=2, default=str))


if __name__ == "__main__":
    main()
