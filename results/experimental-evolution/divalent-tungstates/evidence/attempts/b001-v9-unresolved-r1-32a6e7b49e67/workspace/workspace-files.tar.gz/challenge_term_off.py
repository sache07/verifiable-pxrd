#!/usr/bin/env python3
"""Replay a refined model after neutralizing one supported nuisance term."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("mode", choices=["size_off", "texture_off"])
    parser.add_argument("phase")
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    histogram = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][histogram.name]
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1.0e-6
    controls["parmFrozen"] = {"FrozenList": []}

    if args.mode == "size_off":
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        if len(hap["Size"]) > 4:
            hap["Size"][4] = [10.0 for _ in hap["Size"][4]]
        if len(hap["Size"]) > 5:
            hap["Size"][5] = [False for _ in hap["Size"][5]]
    else:
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    project.save()
    project.refine()
    project.refine()
    project.save()
    print(
        json.dumps(
            {
                "project": project.filename,
                "mode": args.mode,
                "phase": phase.name,
                "residuals": histogram.residuals,
                "mass_fractions": histogram.ComputeMassFracs(),
                "hap": phase.getHAPvalues(histogram.name),
                "profile": {
                    key: histogram.InstrumentParameters[key]
                    for key in ("U", "W", "X", "Polariz.")
                },
                "frozen": controls.get("parmFrozen"),
            },
            indent=2,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
