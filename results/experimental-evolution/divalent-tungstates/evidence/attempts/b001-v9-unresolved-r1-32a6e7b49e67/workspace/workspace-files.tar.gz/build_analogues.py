#!/usr/bin/env python3
"""Construct charge-balanced Ca-W-O analogue models from screened parents."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(
    "<RUN>/"
    "resources/b001-c05/cif"
)
OUT = Path(__file__).resolve().parent / "candidates"

MODELS = {
    # Exact Ca sublattice and an isovalent, similarly sized octahedral cation.
    "Ca3WO6_from_Ca3OsO6.cif": (ROOT / "1/56/26/1562666.cif", {"Os": "W"}, 1.0),
    # Exact Ca sublattice, but U(VI) is appreciably larger; modest cell shrink.
    "Ca3WO6_from_Ca3UO6.cif": (ROOT / "2/31/04/2310470.cif", {"U": "W"}, 0.98),
    # Isovalent alkaline-earth substitution; Ca analogue should be smaller.
    "Ca3W2O9_from_Sr3W2O9.cif": (ROOT / "2/31/19/2311977.cif", {"Sr": "Ca"}, 0.955),
    # Two isovalent substitutions with a larger parent lattice; lower-priority model.
    "Ca2WO5_from_Ba2ReO5.cif": (
        ROOT / "1/52/97/1529756.cif",
        {"Ba": "Ca", "Re": "W"},
        0.93,
    ),
}


def main():
    OUT.mkdir(exist_ok=True)
    for name, (source, substitutions, linear_scale) in MODELS.items():
        structure = Structure.from_file(source)
        structure.replace_species(substitutions)
        if linear_scale != 1.0:
            structure.scale_lattice(structure.volume * linear_scale**3)
        CifWriter(structure, symprec=0.02).write_file(OUT / name)
        print(OUT / name)


if __name__ == "__main__":
    main()
