#!/usr/bin/env python3
"""Replay the accepted GSAS-II model and create scorer-ready outputs."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
SOURCE = TMP / "wo3w_cawo4ocoords.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "CaWO4_scheelite": {
        "formula": "CaWO4",
        "display_name": "CaWO4 (scheelite)",
        "cif_path": "phase_CaWO4_scheelite.cif",
        "source": "COD 7219229",
    },
    "WO3_monoclinic": {
        "formula": "WO3",
        "display_name": "WO3 (monoclinic)",
        "cif_path": "phase_WO3_monoclinic.cif",
        "source": "COD 1528915",
    },
    "Ca3WO6_analogue": {
        "formula": "Ca3WO6",
        "display_name": "Ca3WO6 (P21/n analogue)",
        "cif_path": "phase_Ca3WO6_analogue.cif",
        "source": "Ca3OsO6 COD 1562666 with Os -> W",
    },
}

# Targets are strong, phase-dominant peaks or the least-overlapped cluster in
# each angular third. Windows are used only to measure the local half-height.
AUDIT_TARGETS = {
    "CaWO4_scheelite": [
        ("low", 18.434, 0.40),
        ("middle", 46.925, 0.40),
        ("high", 79.133, 0.50),
    ],
    "WO3_monoclinic": [
        ("low", 22.954, 0.30),
        ("middle", 41.764, 0.28),
        ("high", 83.643, 0.22),
    ],
    "Ca3WO6_analogue": [
        ("low", 19.292, 0.30),
        ("middle", 50.805, 0.30),
        ("high", 74.852, 0.40),
    ],
}


def clear_frozen(gpx: G2sc.G2Project) -> None:
    frozen = gpx.data["Controls"]["data"].setdefault("parmFrozen", {})
    frozen["FrozenList"] = []


def replay_final() -> G2sc.G2Project:
    """Copy, refine over every supplied point, save, reopen, and replay."""
    gpx = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    hist = gpx.histogram(0)
    profile = np.asarray(hist.data["data"][1])
    hist.data["Limits"][1] = [float(profile[0, 0]), float(profile[0, -1])]
    clear_frozen(gpx)
    gpx.set_Controls("cycles", 10)
    gpx.save()
    gpx.refine()
    gpx.save()

    reopened = G2sc.G2Project(gpxfile=str(FINAL))
    clear_frozen(reopened)
    reopened.refine()
    reopened.save()
    return G2sc.G2Project(gpxfile=str(FINAL))


def freeze_project(gpx: G2sc.G2Project) -> None:
    """Turn off every refinement flag without changing parameter values."""
    hist = gpx.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1:
            value[1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        hap["Extinction"][1] = False


def phase_contributions(gpx: G2sc.G2Project) -> dict[str, np.ndarray]:
    """Calculate each phase profile with all other phase scales set to zero."""
    contributions: dict[str, np.ndarray] = {}
    for target in PHASE_INFO:
        out = TMP / f"final_only_{target}.gpx"
        trial = G2sc.G2Project(gpxfile=str(FINAL), newgpx=str(out))
        freeze_project(trial)
        hist = trial.histogram(0)
        for phase in trial.phases():
            if phase.name != target:
                phase.data["Histograms"][hist.name]["Scale"][0] = 0.0
        clear_frozen(trial)
        trial.set_Controls("cycles", 0)
        trial.save()
        trial.refine()
        trial.save()
        arr = np.asarray(trial.histogram(0).data["data"][1], dtype=float)
        contributions[target] = arr[3] - arr[4]
    return contributions


def smooth7(values: np.ndarray) -> np.ndarray:
    """Seven-point quadratic Savitzky-Golay smoothing without SciPy."""
    if len(values) < 7:
        return values.copy()
    kernel = np.array([-2, 3, 6, 7, 6, 3, -2], dtype=float) / 21.0
    result = values.copy()
    result[3:-3] = np.convolve(values, kernel, mode="valid")
    return result


def crossing(x1: float, y1: float, x2: float, y2: float, height: float) -> float:
    if y2 == y1:
        return (x1 + x2) / 2.0
    return x1 + (height - y1) * (x2 - x1) / (y2 - y1)


def peak_metrics(
    x: np.ndarray,
    intensity: np.ndarray,
    target: float,
    half_window: float,
) -> dict[str, float]:
    use = (x >= target - half_window) & (x <= target + half_window)
    xx = x[use]
    yy = smooth7(intensity[use])
    edge = max(3, len(xx) // 10)
    left_floor = float(np.median(yy[:edge]))
    right_floor = float(np.median(yy[-edge:]))
    floor = left_floor + (right_floor - left_floor) * (xx - xx[0]) / (xx[-1] - xx[0])
    yy = yy - floor
    search = np.abs(xx - target) <= min(0.15, half_window / 2.0)
    candidates = np.flatnonzero(search)
    peak_index = int(candidates[np.argmax(yy[search])])
    half_height = yy[peak_index] / 2.0

    left = peak_index
    while left > 0 and yy[left] >= half_height:
        left -= 1
    right = peak_index
    while right < len(yy) - 1 and yy[right] >= half_height:
        right += 1
    if left == 0 or right == len(yy) - 1:
        raise RuntimeError(f"half-height crossing not found near {target}")

    left_x = crossing(xx[left], yy[left], xx[left + 1], yy[left + 1], half_height)
    right_x = crossing(xx[right - 1], yy[right - 1], xx[right], yy[right], half_height)
    position = float(xx[peak_index])
    return {
        "position_deg": position,
        "fwhm_deg": float(right_x - left_x),
        "left_half_width_deg": float(position - left_x),
        "right_half_width_deg": float(right_x - position),
        "height_counts": float(yy[peak_index]),
    }


def make_audit(gpx: G2sc.G2Project, contributions: dict[str, np.ndarray]) -> list[dict]:
    arr = np.asarray(gpx.histogram(0).data["data"][1], dtype=float)
    x, observed, _, _, background, _ = arr
    total = np.sum(np.vstack(list(contributions.values())), axis=0)
    rows: list[dict] = []
    for phase_name, targets in AUDIT_TARGETS.items():
        phase_calc = contributions[phase_name]
        # Remove the modeled background and all other phase contributions from
        # measured counts. This keeps observed residuals in the audited peak.
        phase_observed = observed - background - (total - phase_calc)
        for region, target, half_window in targets:
            obs = peak_metrics(x, phase_observed, target, half_window)
            calc = peak_metrics(x, phase_calc, target, half_window)
            at_peak = int(np.argmin(np.abs(x - calc["position_deg"])))
            dominance = phase_calc[at_peak] / max(total[at_peak], 1e-12)
            rows.append({
                "phase": phase_name,
                "region": region,
                "target_deg": target,
                "phase_dominance": float(dominance),
                "observed": obs,
                "calculated": calc,
            })
    return rows


def export_outputs(gpx: G2sc.G2Project) -> dict:
    hist = gpx.histogram(0)
    arr = np.asarray(hist.data["data"][1], dtype=float)
    x, observed, weights, calculated, background, _ = arr
    difference = observed - calculated

    with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "two_theta_deg", "observed_intensity", "calculated_intensity",
            "difference", "background_intensity",
        ])
        writer.writerows(zip(x, observed, calculated, difference, background))

    mass = hist.ComputeMassFracs()
    normalized = {name: float(value[0]) for name, value in mass.items()}
    total_mass = sum(normalized.values())
    normalized = {name: value / total_mass for name, value in normalized.items()}

    phases = []
    for phase in gpx.phases():
        info = PHASE_INFO[phase.name]
        cif = ROOT / info["cif_path"]
        phase.export_CIF(str(cif))
        cell = phase.get_cell()
        phases.append({
            "name": info["display_name"],
            "phase_id": phase.name,
            "formula": info["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": info["cif_path"],
            "weight_fraction": normalized[phase.name],
            "weight_fraction_esd": float(mass[phase.name][1]),
            "cell": {
                "a_angstrom": float(cell["length_a"]),
                "b_angstrom": float(cell["length_b"]),
                "c_angstrom": float(cell["length_c"]),
                "alpha_deg": float(cell["angle_alpha"]),
                "beta_deg": float(cell["angle_beta"]),
                "gamma_deg": float(cell["angle_gamma"]),
                "volume_angstrom3": float(cell["volume"]),
            },
            "structure_source": info["source"],
        })

    covariance = gpx.data.get("Covariance", {}).get("data", {})
    n_parameters = len(covariance.get("varyList", []))
    chi_squared = float(np.sum(weights * difference * difference))
    n_points = int(len(x))
    rwp = float(hist.residuals["wR"])
    rexp = float(hist.residuals["wRmin"])
    audit = make_audit(gpx, phase_contributions(gpx))

    result = {
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": float(hist.residuals["R"]),
            "Rexp_percent": rexp,
            "goodness_of_fit": rwp / rexp,
            "reduced_chi_squared": (rwp / rexp) ** 2,
            "chi_squared": chi_squared,
            "n_points": n_points,
            "n_refined_parameters": n_parameters,
            "degrees_of_freedom": n_points - n_parameters,
        },
        "profile_audit": audit,
        "notes": {
            "fractions_normalization": "modeled crystalline phases only",
            "uncertainties": "weight_fraction_esd values are formal GSAS-II covariance estimates",
        },
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8"
    )
    return result


def validate(result: dict) -> None:
    parsed = json.loads((ROOT / "result.json").read_text(encoding="utf-8"))
    if parsed["project_path"] != "final.gpx" or not FINAL.exists():
        raise RuntimeError("final project path is invalid")
    fractions = [phase["weight_fraction"] for phase in parsed["phases"]]
    if not all(isinstance(value, (int, float)) and math.isfinite(value) for value in fractions):
        raise RuntimeError("a phase weight fraction is not finite")
    if abs(sum(fractions) - 1.0) > 1e-10:
        raise RuntimeError("phase weight fractions do not sum to one")
    for phase in parsed["phases"]:
        if not (ROOT / phase["cif_path"]).is_file():
            raise RuntimeError(f"missing CIF: {phase['cif_path']}")

    reopened = G2sc.G2Project(gpxfile=str(FINAL))
    arr = np.asarray(reopened.histogram(0).data["data"][1], dtype=float)
    saved = np.genfromtxt(ROOT / "fit.csv", delimiter=",", names=True)
    if len(saved) != arr.shape[1]:
        raise RuntimeError("fit.csv length differs from final.gpx")
    comparisons = (
        (saved["two_theta_deg"], arr[0]),
        (saved["observed_intensity"], arr[1]),
        (saved["calculated_intensity"], arr[3]),
        (saved["difference"], arr[1] - arr[3]),
        (saved["background_intensity"], arr[4]),
    )
    if any(not np.allclose(left, right, rtol=0.0, atol=1e-8) for left, right in comparisons):
        raise RuntimeError("fit.csv does not match reopened final.gpx")
    reopened_mass = reopened.histogram(0).ComputeMassFracs()
    for phase in parsed["phases"]:
        if abs(phase["weight_fraction"] - reopened_mass[phase["phase_id"]][0]) > 1e-10:
            raise RuntimeError("result.json fraction differs from reopened final.gpx")
    print(json.dumps({
        "validated": True,
        "fractions_sum": sum(fractions),
        "Rwp_percent": result["fit_statistics"]["Rwp_percent"],
        "n_profile_points": len(saved),
    }, indent=2))


def main() -> None:
    if not SOURCE.is_file():
        raise FileNotFoundError(SOURCE)
    project = replay_final()
    result = export_outputs(project)
    validate(result)


if __name__ == "__main__":
    main()
