#!/usr/bin/env python3
"""Build and inspect GSAS-II baselines for the Ca-W-O powder pattern."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
DATA_CSV = ROOT / "inputs" / "pattern.csv"
CIF_ROOT = Path(
    "<RUN>/"
    "resources/b001-c05/cif"
)


def cod_cif(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PHASE_SOURCES = {
    "CaWO4_scheelite": cod_cif("7219229"),
    "WO3_orthorhombic": cod_cif("2107312"),
    "WO3_monoclinic": cod_cif("1528915"),
    "CaO": cod_cif("1563196"),
    "CaOH2": cod_cif("7020138"),
    "CaCO3": cod_cif("1547347"),
    "CaWO4_monoclinic": cod_cif("1546035"),
    "CaW_bronze": cod_cif("4030741"),
    "Ca3WO6_analogue": ROOT / "candidates" / "Ca3WO6_P21n_analogue.cif",
}


def write_inputs() -> tuple[Path, Path]:
    """Create GSAS-II text input files from the supplied CSV and metadata."""
    TMP.mkdir(exist_ok=True)
    frame = np.genfromtxt(DATA_CSV, delimiter=",", names=True)
    x = np.asarray(frame["two_theta_deg"], dtype=float)
    y = np.asarray(frame["intensity"], dtype=float)
    # Original counts with no supplied uncertainty: use the Poisson counting
    # estimate. This is explicit in the XYE file and gives a meaningful chi^2.
    sigma = np.sqrt(np.maximum(y, 1.0))
    xye = TMP / "pattern_poisson.xye"
    np.savetxt(xye, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")

    inst = TMP / "cu_ka_reflection.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for supplied Cu K-alpha reflection data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;"
        "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        # A deliberately low-dimensional, nonnegative U/W/X starting profile.
        "U:20.0;V:0.0;W:35.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.002\n",
        encoding="utf-8",
    )
    return xye, inst


def project_summary(gpx: G2sc.G2Project) -> dict:
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = {}
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "composition": phase.composition,
            "density": phase.density,
            "scale": hap["Scale"][0],
            "scale_refine": hap["Scale"][1],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    return {
        "filename": gpx.filename,
        "residuals": hist.residuals,
        "instrument": {
            key: value
            for key, value in inst.items()
            if key in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.",
                       "U", "V", "W", "X", "Y", "Z", "SH/L", "Type"}
        },
        "sample": {
            key: sample[key]
            for key in ("Type", "Gonio. radius", "Scale", "Shift", "Transparency",
                        "SurfRoughA", "SurfRoughB")
            if key in sample
        },
        "background": hist.data["Background"],
        "phases": phases,
        "mass_fractions": hist.ComputeMassFracs(),
        "covariance": {
            key: gpx.data.get("Covariance", {}).get("data", {}).get(key)
            for key in ("Rvals", "varyList", "variables", "sig")
        },
    }


def emit_summary(gpx: G2sc.G2Project, label: str) -> None:
    summary = project_summary(gpx)
    path = TMP / f"{label}_summary.json"
    path.write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")
    hist = gpx.histogram(0)
    print(f"{label}: {hist.residuals}")
    inst = hist.data["Instrument Parameters"][0]
    print(
        "  profile",
        {k: round(float(inst[k][1]), 7) for k in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
    )
    print(
        "  correction",
        "Zero", inst["Zero"],
        "Shift", hist.data["Sample Parameters"].get("Shift"),
    )
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        cell = phase.get_cell()
        print(
            f"  {phase.name}: scale={hap['Scale'][0]:.8g}",
            "cell=",
            tuple(round(cell[k], 6) for k in (
                "length_a", "length_b", "length_c", "angle_alpha",
                "angle_beta", "angle_gamma", "volume"
            )),
        )
    print("  mass fractions", hist.ComputeMassFracs())


def set_profile_bounds(gpx: G2sc.G2Project) -> None:
    # Keep the baseline Caglioti/profile terms physical. V, Y and Z remain zero.
    for name in ("U", "W", "X"):
        gpx.set_Controls("parmMin", 0.0, variable=f":0:{name}")
    gpx.set_Controls("parmMax", 10000.0, variable=":0:U")
    gpx.set_Controls("parmMax", 10000.0, variable=":0:W")
    gpx.set_Controls("parmMax", 1000.0, variable=":0:X")
    gpx.set_Controls("parmMin", -2000.0, variable=":0:Shift")
    gpx.set_Controls("parmMax", 2000.0, variable=":0:Shift")


def build_baseline(output: Path, phase_names: list[str]) -> G2sc.G2Project:
    xye, inst = write_inputs()
    gpx = G2sc.G2Project(newgpx=str(output))
    hist = gpx.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.set_refinements({"Limits": [10.0, 100.0]})
    # Reflection geometry is set by the dual-wavelength lab parameter file.
    sample = hist.data["Sample Parameters"]
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    # Approximate observed -0.16 degree displacement at low angle.
    sample["Shift"] = [280.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    sample["Scale"] = [1.0, False]

    # Eight smooth Chebyshev terms over 90 degrees; no background peaks/Debye terms.
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "refine": False,
            "no. coeffs": 8,
            "coeffs": [1600.0, -900.0, 550.0, -300.0, 160.0, -80.0, 30.0, -10.0],
        }
    })

    for name in phase_names:
        gpx.add_phase(
            str(PHASE_SOURCES[name]),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )

    # Neutralize all optional HAP terms; only phase scales are activated initially.
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        hap["Extinction"] = [0.0, False]
        hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]

    gpx.set_Controls("cycles", 8)
    gpx.save()
    set_profile_bounds(gpx)
    gpx.save()
    return gpx


def refine_baseline(output: Path, phase_names: list[str]) -> G2sc.G2Project:
    gpx = build_baseline(output, phase_names)
    hist = gpx.histogram(0)

    # Stage 1: smooth background and phase scales only.
    hist.set_refinements({"Background": {"refine": True}})
    for phase in gpx.phases():
        phase.set_HAP_refinements({"Scale": True})
    gpx.refine()
    emit_summary(gpx, output.stem + "_stage1")

    # Stage 2: phase cells, still with the physical displacement held at start value.
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    gpx.refine()
    emit_summary(gpx, output.stem + "_stage2")

    # Stage 3: one angular correction (sample height/displacement) and common U/W/X.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    gpx.refine()
    emit_summary(gpx, output.stem + "_stage3")

    # Re-converge the accepted baseline and save/reopen it.
    gpx.refine()
    gpx.save()
    reopened = G2sc.G2Project(gpxfile=str(output))
    reopened.refine()
    reopened.save()
    emit_summary(reopened, output.stem + "_replayed")
    return reopened


def inspect(path: Path) -> None:
    gpx = G2sc.G2Project(gpxfile=str(path))
    emit_summary(gpx, path.stem + "_inspect")


def refine_variant(
    source: Path,
    output: Path,
    kind: str,
    phase_name: str | None = None,
    axis: list[int] | None = None,
) -> G2sc.G2Project:
    """Replay a single nuisance-model challenge from a saved baseline."""
    gpx = G2sc.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = gpx.histogram(0)

    if kind in {"roughness", "roughness1"}:
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.0 if kind == "roughness1" else 0.1,
                                kind == "roughness"]
        sample["SurfRoughB"] = [0.07, True]
        gpx.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
        gpx.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
        gpx.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        gpx.set_Controls("parmMax", 2.0, variable=":0:SurfRoughB")
    elif kind == "polarization":
        inst = hist.data["Instrument Parameters"][0]
        inst["Polariz."][2] = True
        gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif kind == "no_roughness":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.0, False]
    elif kind.startswith("background"):
        count = int(kind.removeprefix("background"))
        hist.set_refinements({"Background": {"refine": True, "no. coeffs": count}})
    elif kind == "shl":
        hist.data["Instrument Parameters"][0]["SH/L"][2] = True
        gpx.set_Controls("parmMin", 0.0005, variable=":0:SH/L")
        gpx.set_Controls("parmMax", 0.2, variable=":0:SH/L")
    elif kind in {"fix_x0", "fix_u0"}:
        key = "X" if kind == "fix_x0" else "U"
        inst = hist.data["Instrument Parameters"][0]
        inst[key][1] = 0.0
        inst[key][2] = False
        gpx.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    elif kind in {"texture", "size", "strain", "w_positions", "o_positions"}:
        if phase_name is None:
            raise ValueError(f"{kind} requires a phase name")
        phase = gpx.phase(phase_name)
        if phase is None:
            raise ValueError(f"phase not found: {phase_name}")
        hap = phase.data["Histograms"][hist.name]
        if kind in {"w_positions", "o_positions"}:
            # The legacy WO3 record reports coordinates to only 2--3 decimal
            # places. Refine only the two strongly scattering W sites; oxygen
            # coordinates are underdetermined in this multiphase lab pattern.
            selected = 0
            wanted = "W" if kind == "w_positions" else "O"
            for atom in phase.atoms():
                if atom.element == wanted:
                    atom.refinement_flags = "X"
                    selected += 1
            if selected == 0:
                raise ValueError(f"no {wanted} atoms found in {phase_name}")
        elif kind == "texture":
            if axis is None or len(axis) != 3:
                raise ValueError("texture requires three hkl values")
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [int(v) for v in axis]
            gpx.set_Controls("parmMin", 0.1, variable=f"{phase.id}:0:MD")
            gpx.set_Controls("parmMax", 10.0, variable=f"{phase.id}:0:MD")
        elif kind == "size":
            phase.set_HAP_refinements({
                "Size": {"type": "isotropic", "value": 1.0, "refine": True}
            }, [hist])
            gpx.set_Controls("parmMin", 0.002, variable=f"{phase.id}:0:Size;i")
            gpx.set_Controls("parmMax", 100.0, variable=f"{phase.id}:0:Size;i")
        else:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 1000.0
            hap["Mustrain"][2][0] = True
            gpx.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
            gpx.set_Controls("parmMax", 100000.0, variable=f"{phase.id}:0:Mustrain;i")
    else:
        raise ValueError(f"unknown variant {kind}")

    gpx.set_Controls("cycles", 10)
    gpx.save()
    for _ in range(2):
        gpx.refine()
    gpx.save()
    reopened = G2sc.G2Project(gpxfile=str(output))
    reopened.refine()
    reopened.save()
    emit_summary(reopened, output.stem + "_replayed")
    return reopened


def add_phase_and_reconverge(
    source: Path,
    output: Path,
    phase_name: str,
) -> G2sc.G2Project:
    """Add a watch-list phase to a saved baseline and replay all shared terms."""
    gpx = G2sc.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = gpx.histogram(0)
    phase = gpx.add_phase(
        str(PHASE_SOURCES[phase_name]), phasename=phase_name,
        histograms=[hist], fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    # A watch-list phase is tested at trace abundance with its literature cell
    # fixed.  Refining a nearly absent phase cell lets the metric run away and
    # tests an unphysical pattern rather than the candidate record itself.
    hap["Scale"] = [0.01, True]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    phase.set_refinements({"Cell": False})

    gpx.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
    gpx.set_Controls("cycles", 12)
    gpx.save()
    for _ in range(3):
        gpx.refine()
    gpx.save()
    reopened = G2sc.G2Project(gpxfile=str(output))
    reopened.refine()
    reopened.save()
    emit_summary(reopened, output.stem + "_replayed")
    return reopened


def probe_phase_scale(source: Path, output: Path, phase_name: str) -> G2sc.G2Project:
    """Test a trace phase with every baseline term frozen except its scale."""
    gpx = G2sc.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = gpx.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
            value[2] = False

    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]

    phase = gpx.add_phase(
        str(PHASE_SOURCES[phase_name]), phasename=phase_name,
        histograms=[hist], fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.01, True]
    phase.data["General"]["Cell"][0] = False
    gpx.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
    gpx.set_Controls("cycles", 8)
    gpx.save()
    gpx.refine()
    gpx.save()
    reopened = G2sc.G2Project(gpxfile=str(output))
    reopened.refine()
    reopened.save()
    emit_summary(reopened, output.stem + "_replayed")
    return reopened


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    build = sub.add_parser("baseline")
    build.add_argument("output", type=Path)
    build.add_argument("phases", nargs="+", choices=sorted(PHASE_SOURCES))
    show = sub.add_parser("inspect")
    show.add_argument("project", type=Path)
    variant = sub.add_parser("variant")
    variant.add_argument("source", type=Path)
    variant.add_argument("output", type=Path)
    variant.add_argument(
        "kind",
        choices=["roughness", "roughness1", "polarization", "no_roughness", "background6", "background10",
                 "background12", "shl", "fix_x0", "fix_u0", "texture", "size", "strain",
                 "w_positions", "o_positions"],
    )
    variant.add_argument("--phase", choices=sorted(PHASE_SOURCES))
    variant.add_argument("--axis", type=int, nargs=3)
    addphase = sub.add_parser("addphase")
    addphase.add_argument("source", type=Path)
    addphase.add_argument("output", type=Path)
    addphase.add_argument("phase", choices=sorted(PHASE_SOURCES))
    probe = sub.add_parser("probephase")
    probe.add_argument("source", type=Path)
    probe.add_argument("output", type=Path)
    probe.add_argument("phase", choices=sorted(PHASE_SOURCES))
    args = parser.parse_args()

    if args.command == "baseline":
        refine_baseline(args.output.resolve(), args.phases)
    elif args.command == "variant":
        refine_variant(
            args.source.resolve(), args.output.resolve(), args.kind,
            args.phase, args.axis,
        )
    elif args.command == "addphase":
        add_phase_and_reconverge(
            args.source.resolve(), args.output.resolve(), args.phase,
        )
    elif args.command == "probephase":
        probe_phase_scale(
            args.source.resolve(), args.output.resolve(), args.phase,
        )
    else:
        inspect(args.project.resolve())


if __name__ == "__main__":
    main()
