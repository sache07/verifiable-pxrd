#!/usr/bin/env python3
"""Final physical trials, replay, and deliverable export for the PXRD model."""

from __future__ import annotations

import argparse
import copy
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TRIALS = ROOT / "trials"
GSAS_SOURCE = TRIALS / "triclinic_reconverged.gpx"
WATCH_CIF = Path(
    "<RUN>/"
    "resources/b001-c03/cif/2/31/19/2311977.cif"
)
RESOURCE_CIF = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)
PHASE_FILES = {
    "SrWO4_scheelite": ROOT / "candidates" / "SrWO4_scheelite_from_CaWO4_7219229.cif",
    "WO3_monoclinic": RESOURCE_CIF / "2/10/62/2106293.cif",
    "SrCO3_strontianite": RESOURCE_CIF / "9/00/81/9008198.cif",
}


def controls(project: G2sc.G2Project) -> None:
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5


def covariance_status(project: G2sc.G2Project) -> dict:
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    return {
        "Rwp_percent": float(rvals.get("Rwp", project.histogram(0).residuals["wR"])),
        "GOF": float(rvals.get("GOF", float("nan"))),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_esd": float(rvals.get("Max shft/sig", float("inf"))),
        "SVD0": int(rvals.get("SVD0", 0)),
        "Nvars": int(rvals.get("Nvars", 0)),
        "vary_list": [str(value) for value in cov.get("varyList", [])],
    }


def project_record(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    record = covariance_status(project)
    record["label"] = label
    record["fractions"] = {
        name: [float(value[0]), float(value[1])]
        for name, value in hist.ComputeMassFracs().items()
    }
    record["scales"] = {
        phase.name: copy.deepcopy(phase.data["Histograms"][hist.name]["Scale"])
        for phase in project.phases()
    }
    return record


def replay_until_converged(
    project: G2sc.G2Project,
    output: Path,
    label: str,
    max_replays: int = 6,
    threshold: float = 0.05,
) -> list[dict]:
    records = []
    for replay in range(1, max_replays + 1):
        project.save(str(output))
        project.refine()
        project.save()
        record = project_record(project, f"{label}_replay_{replay}")
        records.append(record)
        print(json.dumps(record, indent=2))
        if record["converged"] and record["max_shift_over_esd"] < threshold:
            break
    return records


def freeze_non_wo3_broadening(project: G2sc.G2Project) -> None:
    """Hold already-supported other-phase broadening fixed during WO3 tests."""
    hist = project.histogram(0)
    for phase in project.phases():
        if phase.name == "WO3_monoclinic":
            continue
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def set_wo3_neutral(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hap = project.phase("WO3_monoclinic").data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:3] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][4] = [10.0, 10.0, 10.0, 0.0, 0.0, 0.0]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:3] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][4] = [0.0 for _ in hap["Mustrain"][4]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def profile_trials() -> None:
    all_records: dict[str, list[dict]] = {}

    no_strain_path = TRIALS / "triclinic_clean_wo3_no_strain.gpx"
    no_strain = G2sc.G2Project(str(GSAS_SOURCE), newgpx=str(no_strain_path))
    controls(no_strain)
    freeze_non_wo3_broadening(no_strain)
    set_wo3_neutral(no_strain)
    all_records["no_strain"] = replay_until_converged(
        no_strain, no_strain_path, "clean_wo3_no_strain"
    )

    size_path = TRIALS / "triclinic_clean_wo3_size.gpx"
    size = G2sc.G2Project(str(no_strain_path), newgpx=str(size_path))
    controls(size)
    size_hap = size.phase("WO3_monoclinic").data["Histograms"][size.histogram(0).name]
    size_hap["Size"][1][0] = 10.0
    size_hap["Size"][2][0] = True
    all_records["size"] = replay_until_converged(
        size, size_path, "clean_wo3_size", max_replays=3
    )
    all_records["size"][-1]["size_term"] = copy.deepcopy(size_hap["Size"][:4])

    for axis in ([0, 0, 1], [1, 0, 1]):
        axis_slug = "".join(str(value) for value in axis)
        output = TRIALS / f"triclinic_clean_wo3_strain_{axis_slug}.gpx"
        project = G2sc.G2Project(str(no_strain_path), newgpx=str(output))
        controls(project)
        hap = project.phase("WO3_monoclinic").data["Histograms"][project.histogram(0).name]
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = 1.0
        hap["Mustrain"][1][1] = 1.0
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        hap["Mustrain"][3] = list(axis)
        key = f"strain_{axis_slug}"
        all_records[key] = replay_until_converged(
            project, output, f"clean_wo3_strain_{axis_slug}"
        )
        all_records[key][-1]["strain_term"] = copy.deepcopy(hap["Mustrain"][:4])

    combined_path = TRIALS / "triclinic_profile_clean_combined.gpx"
    combined = G2sc.G2Project(
        str(TRIALS / "triclinic_clean_wo3_strain_001.gpx"),
        newgpx=str(combined_path),
    )
    controls(combined)
    hist = combined.histogram(0)
    sr_hap = combined.phase("SrWO4_scheelite").data["Histograms"][hist.name]
    sr_hap["Mustrain"][2][0] = True
    sr_hap["Mustrain"][2][1] = True
    all_records["combined"] = replay_until_converged(
        combined, combined_path, "clean_combined_profile"
    )
    print(json.dumps({"profile_trial_records": all_records}, indent=2))


def set_uniaxial_strain(project: G2sc.G2Project, phase_name: str, axis: list[int]) -> None:
    hist = project.histogram(0)
    hap = project.phase(phase_name).data["Histograms"][hist.name]
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = 1.0
    hap["Mustrain"][1][1] = 1.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    hap["Mustrain"][3] = list(axis)


def followup_trials() -> None:
    """Challenge the newly favored WO3 [101] strain and rebuild the combination."""
    no_strain = TRIALS / "triclinic_clean_wo3_no_strain.gpx"
    axes = ([1, 0, 0], [0, 1, 0], [0, 1, 1], [1, 1, 0])
    all_records: dict[str, list[dict]] = {}
    for axis in axes:
        slug = "".join(str(value) for value in axis)
        output = TRIALS / f"triclinic_followup_wo3_strain_{slug}.gpx"
        project = G2sc.G2Project(str(no_strain), newgpx=str(output))
        controls(project)
        set_uniaxial_strain(project, "WO3_monoclinic", list(axis))
        rows = replay_until_converged(
            project, output, f"followup_wo3_strain_{slug}", max_replays=6
        )
        hap = project.phase("WO3_monoclinic").data["Histograms"][project.histogram(0).name]
        rows[-1]["strain_term"] = copy.deepcopy(hap["Mustrain"][:4])
        all_records[slug] = rows

    candidate_paths = {
        "001": TRIALS / "triclinic_clean_wo3_strain_001.gpx",
        "101": TRIALS / "triclinic_clean_wo3_strain_101.gpx",
        **{
            "".join(str(value) for value in axis):
                TRIALS / f"triclinic_followup_wo3_strain_{''.join(str(value) for value in axis)}.gpx"
            for axis in axes
        },
    }
    viable = {}
    for slug, path in candidate_paths.items():
        project = G2sc.G2Project(str(path))
        status = covariance_status(project)
        hap = project.phase("WO3_monoclinic").data["Histograms"][project.histogram(0).name]
        values = [float(hap["Mustrain"][1][0]), float(hap["Mustrain"][1][1])]
        if (
            status["converged"]
            and status["max_shift_over_esd"] < 0.1
            and status["SVD0"] == 0
            and min(values) > 0.0
        ):
            viable[slug] = (status["Rwp_percent"], path, values)
    selected_slug, (_, selected_path, _) = min(viable.items(), key=lambda item: item[1][0])

    combined_path = TRIALS / "triclinic_selected_combined.gpx"
    combined = G2sc.G2Project(str(selected_path), newgpx=str(combined_path))
    controls(combined)
    sr_hap = combined.phase("SrWO4_scheelite").data["Histograms"][combined.histogram(0).name]
    sr_hap["Mustrain"][2][0] = True
    sr_hap["Mustrain"][2][1] = True
    all_records["selected_combined"] = replay_until_converged(
        combined, combined_path, f"selected_{selected_slug}_combined"
    )

    no_sr_path = TRIALS / "triclinic_selected_no_srwo4_strain.gpx"
    no_sr = G2sc.G2Project(str(combined_path), newgpx=str(no_sr_path))
    controls(no_sr)
    sr_hap = no_sr.phase("SrWO4_scheelite").data["Histograms"][no_sr.histogram(0).name]
    sr_hap["Mustrain"][0] = "isotropic"
    sr_hap["Mustrain"][1][:3] = [0.0, 0.0, 1.0]
    sr_hap["Mustrain"][2] = [False for _ in sr_hap["Mustrain"][2]]
    all_records["no_srwo4_strain"] = replay_until_converged(
        no_sr, no_sr_path, "selected_no_srwo4_strain"
    )

    final_profile_path = TRIALS / "triclinic_profile_selected.gpx"
    final_profile = G2sc.G2Project(str(no_sr_path), newgpx=str(final_profile_path))
    controls(final_profile)
    set_uniaxial_strain(final_profile, "SrWO4_scheelite", [1, 1, 2])
    all_records["srwo4_strain_reintroduced"] = replay_until_converged(
        final_profile, final_profile_path, "selected_srwo4_strain_112"
    )

    no_texture_path = TRIALS / "triclinic_selected_wo3_no_texture.gpx"
    no_texture = G2sc.G2Project(str(final_profile_path), newgpx=str(no_texture_path))
    controls(no_texture)
    wo_hap = no_texture.phase("WO3_monoclinic").data["Histograms"][no_texture.histogram(0).name]
    wo_hap["Pref.Ori."][0] = "MD"
    wo_hap["Pref.Ori."][1] = 1.0
    wo_hap["Pref.Ori."][2] = False
    wo_hap["Pref.Ori."][3] = [0, 0, 1]
    all_records["wo3_no_texture"] = replay_until_converged(
        no_texture, no_texture_path, "selected_wo3_no_texture"
    )

    for seed in (0.9, 1.1):
        seed_slug = str(seed).replace(".", "p")
        output = TRIALS / f"triclinic_selected_wo3_texture_101_seed_{seed_slug}.gpx"
        project = G2sc.G2Project(str(no_texture_path), newgpx=str(output))
        controls(project)
        hap = project.phase("WO3_monoclinic").data["Histograms"][project.histogram(0).name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = seed
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = [1, 0, 1]
        key = f"wo3_texture_101_seed_{seed_slug}"
        all_records[key] = replay_until_converged(
            project, output, key, max_replays=5
        )
        all_records[key][-1]["texture_term"] = copy.deepcopy(hap["Pref.Ori."][:4])

    print(
        json.dumps(
            {
                "selected_axis": selected_slug,
                "viable_axes": {
                    slug: {"Rwp_percent": values[0], "strain": values[2]}
                    for slug, values in viable.items()
                },
                "followup_records": all_records,
            },
            indent=2,
        )
    )


def copy_matched_model(
    baseline: G2sc.G2Project,
    output: Path,
    replacement_phase: str,
    replacement_file: Path,
    same_setting: bool,
) -> G2sc.G2Project:
    base_hist = baseline.histogram(0)
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "candidates" / "lab_cuka1ka2.instprm"),
        fmthint="comma",
    )
    files = dict(PHASE_FILES)
    files[replacement_phase] = replacement_file
    for name, path in files.items():
        project.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
    controls(project)
    hist.Background[:] = copy.deepcopy(base_hist.Background)
    hist.SampleParameters.update(copy.deepcopy(base_hist.SampleParameters))
    hist.InstrumentParameters.update(copy.deepcopy(base_hist.InstrumentParameters))
    hist.data["Limits"] = copy.deepcopy(base_hist.data["Limits"])

    for phase in project.phases():
        base_phase = baseline.phase(phase.name)
        base_hap = base_phase.data["Histograms"][base_hist.name]
        hap = phase.data["Histograms"][hist.name]
        for key in (
            "Scale", "Size", "Mustrain", "Pref.Ori.", "Extinction",
            "Babinet", "HStrain", "Use",
        ):
            hap[key] = copy.deepcopy(base_hap[key])
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.data["General"]["Cell"][0] = True
        if phase.name != replacement_phase or same_setting:
            phase.data["General"]["Cell"][1:8] = copy.deepcopy(
                base_phase.data["General"]["Cell"][1:8]
            )

    if replacement_phase == "WO3_monoclinic":
        # Give the monoclinic source its independently supported [001]
        # directional broadening rather than forcing the triclinic [101] axis.
        old = G2sc.G2Project(str(TRIALS / "srwo4_uniaxial_strain_112.gpx"))
        old_hap = old.phase("WO3_monoclinic").data["Histograms"][old.histogram(0).name]
        hap = project.phase(replacement_phase).data["Histograms"][hist.name]
        hap["Mustrain"] = copy.deepcopy(old_hap["Mustrain"])
        hap["Pref.Ori."] = copy.deepcopy(old_hap["Pref.Ori."])
    return project


def source_followup_trials() -> None:
    baseline_path = TRIALS / "triclinic_profile_selected.gpx"
    baseline = G2sc.G2Project(str(baseline_path))
    specifications = (
        (
            "srwo4_srmoo4_parent_selected",
            "SrWO4_scheelite",
            ROOT / "candidates" / "SrWO4_scheelite_from_SrMoO4_2300460.cif",
            True,
        ),
        (
            "wo3_monoclinic_2311041_selected",
            "WO3_monoclinic",
            RESOURCE_CIF / "2/31/10/2311041.cif",
            False,
        ),
    )
    records = {}
    for label, phase_name, path, same_setting in specifications:
        output = TRIALS / f"source_followup_{label}.gpx"
        project = copy_matched_model(
            baseline, output, phase_name, path, same_setting
        )
        if not same_setting:
            project.phase(phase_name).data["General"]["Cell"][0] = False
        rows = replay_until_converged(
            project, output, f"{label}_scale_first", max_replays=3
        )
        project.phase(phase_name).data["General"]["Cell"][0] = True
        rows.extend(
            replay_until_converged(
                project, output, f"{label}_cell_released", max_replays=6
            )
        )
        records[label] = rows

    # Restore and replay the selected source after every source change.
    restored_path = TRIALS / "triclinic_profile_selected.gpx"
    restored = G2sc.G2Project(str(restored_path))
    controls(restored)
    records["selected_source_restored"] = replay_until_converged(
        restored, restored_path, "selected_source_restored", max_replays=3
    )
    print(json.dumps({"source_followup_records": records}, indent=2))


def neutralize_watch_phase(phase: G2sc.G2Phase, hist_name: str, seed: float) -> None:
    phase.data["General"]["Cell"][0] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"] = [seed, True]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:3] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][4] = [10.0, 10.0, 10.0, 0.0, 0.0, 0.0]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:3] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][4] = [0.0 for _ in hap["Mustrain"][4]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]


def watchlist_trials() -> None:
    source = TRIALS / "triclinic_profile_selected.gpx"
    if not source.exists():
        source = TRIALS / "triclinic_profile_clean_combined.gpx"
    if not source.exists():
        source = GSAS_SOURCE
    all_records = {}
    for seed in (0.02, 0.2):
        seed_slug = str(seed).replace(".", "p")
        output = TRIALS / f"watch_Sr3W2O9_seed_{seed_slug}.gpx"
        project = G2sc.G2Project(str(source), newgpx=str(output))
        controls(project)
        hist = project.histogram(0)
        phase = project.add_phase(
            str(WATCH_CIF),
            phasename="Sr3W2O9_watch",
            histograms=[hist],
            fmthint="CIF",
        )
        neutralize_watch_phase(phase, hist.name, seed)
        rows = replay_until_converged(
            project, output, f"Sr3W2O9_seed_{seed}", max_replays=5
        )
        hap = phase.data["Histograms"][hist.name]
        cov = project.data.get("Covariance", {}).get("data", {})
        scale_name = f"{phase.id}:{hist.id}:Scale"
        scale_esd = None
        for name, esd in zip(cov.get("varyList", []), cov.get("sig", [])):
            if str(name) == scale_name:
                scale_esd = float(esd)
                break
        rows[-1]["watch_phase"] = {
            "seed": seed,
            "scale": float(hap["Scale"][0]),
            "scale_refine_flag": bool(hap["Scale"][1]),
            "scale_esd": scale_esd,
            "cell_refined": bool(phase.data["General"]["Cell"][0]),
            "size": copy.deepcopy(hap["Size"][:4]),
            "mustrain": copy.deepcopy(hap["Mustrain"][:4]),
            "preferred_orientation": copy.deepcopy(hap["Pref.Ori."][:4]),
        }
        all_records[seed_slug] = rows
    print(json.dumps({"watchlist_records": all_records}, indent=2))


def rename_phase(project: G2sc.G2Project, old: str, new: str) -> None:
    if old not in project.data["Phases"]:
        return
    phase_data = project.data["Phases"].pop(old)
    phase_data["General"]["Name"] = new
    project.data["Phases"][new] = phase_data
    for names in project.names:
        if names and names[0] == "Phases":
            names[names.index(old)] = new
    for hist in project.histograms():
        reflections = hist.data.get("Reflection Lists", {})
        if old in reflections:
            reflections[new] = reflections.pop(old)
    project.update_ids()


def neutralize_size(hap: dict) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:3] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][4] = [10.0, 10.0, 10.0, 0.0, 0.0, 0.0]
    hap["Size"][5] = [False for _ in hap["Size"][5]]


def prune_final(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    sample = hist.SampleParameters
    sample["Scale"] = [1.0, False]
    sample["Shift"][1] = True
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key] = [0.0, False]
    inst = hist.InstrumentParameters
    for key in ("Zero", "V", "Y", "Z"):
        inst[key][0] = 0.0
        inst[key][1] = 0.0
        inst[key][2] = False
    inst["U"] = [0.0, 0.0, False]
    inst["W"][2] = True
    inst["X"][2] = True
    inst["SH/L"] = [0.002, 0.002, False]
    inst["I(L2)/I(L1)"] = [0.5, 0.5, False]
    inst["Polariz."][2] = True
    hist.Background[0][1] = True

    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Use"] = True
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]
        hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        neutralize_size(hap)
        hap["Mustrain"][4] = [0.0 for _ in hap["Mustrain"][4]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        if phase.name == "SrCO3_strontianite":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][:3] = [0.0, 0.0, 1.0]
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]


def crossing(x: np.ndarray, y: np.ndarray, start: int, direction: int, level: float) -> float:
    index = start
    while 0 <= index + direction < len(y):
        next_index = index + direction
        if (y[index] - level) * (y[next_index] - level) <= 0.0:
            if y[next_index] == y[index]:
                return float((x[index] + x[next_index]) / 2.0)
            fraction = (level - y[index]) / (y[next_index] - y[index])
            return float(x[index] + fraction * (x[next_index] - x[index]))
        index = next_index
    return float("nan")


def peak_metrics(x: np.ndarray, y: np.ndarray, background: np.ndarray, target: float) -> dict:
    mask = (x >= target - 0.45) & (x <= target + 0.45)
    xx = x[mask]
    signal = (y - background)[mask]
    peak_window = np.abs(xx - target) <= 0.22
    local_indices = np.flatnonzero(peak_window)
    peak_index = int(local_indices[np.argmax(signal[peak_window])])
    peak_x = float(xx[peak_index])
    peak_height = float(signal[peak_index])
    level = peak_height / 2.0
    left = crossing(xx, signal, peak_index, -1, level)
    right = crossing(xx, signal, peak_index, 1, level)
    return {
        "position_deg": peak_x,
        "left_half_width_deg": peak_x - left,
        "right_half_width_deg": right - peak_x,
        "FWHM_deg": right - left,
    }


def peak_audit(hist: G2sc.G2PwdrData) -> dict[str, list[dict]]:
    arrays = hist.data["data"][1]
    x = np.asarray(arrays[0], dtype=float)
    observed = np.asarray(arrays[1], dtype=float)
    calculated = np.asarray(arrays[3], dtype=float)
    background = np.asarray(arrays[4], dtype=float)
    targets = {
        "SrWO4_scheelite": (17.456, 27.203, 44.82, 72.65, 86.71, 95.01),
        "WO3_triclinic": (22.52, 33.56, 76.10),
        "SrCO3_strontianite": (24.65, 43.63, 77.38),
    }
    audit = {}
    for phase_name, phase_targets in targets.items():
        audit[phase_name] = []
        for target in phase_targets:
            audit[phase_name].append(
                {
                    "target_deg": target,
                    "observed": peak_metrics(x, observed, background, target),
                    "calculated": peak_metrics(x, calculated, background, target),
                }
            )
    return audit


def write_fit(hist: G2sc.G2PwdrData, output: Path) -> None:
    arrays = hist.data["data"][1]
    with output.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        for values in zip(arrays[0], arrays[1], arrays[3], arrays[5], arrays[4]):
            writer.writerow([f"{float(value):.10g}" for value in values])


def final_outputs() -> None:
    source = TRIALS / "triclinic_profile_selected.gpx"
    if not source.exists():
        source = TRIALS / "triclinic_profile_clean_combined.gpx"
    if not source.exists():
        source = GSAS_SOURCE
    final_path = ROOT / "final.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(final_path))
    controls(project)
    rename_phase(project, "WO3_monoclinic", "WO3_triclinic")
    prune_final(project)
    pre_reopen = replay_until_converged(project, final_path, "final_pre_reopen")

    # The submitted arrays and CIFs are generated only after a fresh load and
    # full-range replay of the exact project that is left on disk.
    project = G2sc.G2Project(str(final_path))
    controls(project)
    post_reopen = replay_until_converged(
        project, final_path, "final_post_reopen", max_replays=3
    )
    hist = project.histogram(0)

    cif_paths = {
        "SrWO4_scheelite": ROOT / "phase_1_SrWO4_scheelite.cif",
        "WO3_triclinic": ROOT / "phase_2_WO3_triclinic.cif",
        "SrCO3_strontianite": ROOT / "phase_3_SrCO3_strontianite.cif",
    }
    for phase in project.phases():
        phase.export_CIF(str(cif_paths[phase.name]))
    write_fit(hist, ROOT / "fit.csv")

    fractions = hist.ComputeMassFracs()
    fraction_sum = sum(float(value[0]) for value in fractions.values())
    residuals = hist.residuals
    rvals = project.data["Covariance"]["data"]["Rvals"]
    phase_labels = {
        "SrWO4_scheelite": ("SrWO4 (scheelite)", "SrWO4"),
        "WO3_triclinic": ("WO3 (triclinic)", "WO3"),
        "SrCO3_strontianite": ("SrCO3 (strontianite)", "SrCO3"),
    }
    result = {
        "project_path": "final.gpx",
        "weight_fraction_basis": "normalized over modeled crystalline phases",
        "phases": [],
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_variables": int(rvals["Nvars"]),
        },
    }
    for phase in project.phases():
        label, formula = phase_labels[phase.name]
        fraction, esd = fractions[phase.name]
        result["phases"].append(
            {
                "name": label,
                "formula": formula,
                "cif_path": cif_paths[phase.name].name,
                "weight_fraction": float(fraction) / fraction_sum,
                "weight_fraction_formal_esd": float(esd),
            }
        )
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")

    audit = peak_audit(hist)
    with (TRIALS / "final_peak_audit.json").open("w") as stream:
        json.dump(audit, stream, indent=2)
        stream.write("\n")
    summary = {
        "pre_reopen": pre_reopen,
        "post_reopen": post_reopen,
        "result": result,
        "cells": {phase.name: phase.get_cell_and_esd() for phase in project.phases()},
        "peak_audit": audit,
    }
    print(json.dumps(summary, indent=2, default=str))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "action",
        choices=("profile", "followup", "sources", "watchlist", "final"),
    )
    args = parser.parse_args()
    if args.action == "profile":
        profile_trials()
    elif args.action == "followup":
        followup_trials()
    elif args.action == "sources":
        source_followup_trials()
    elif args.action == "watchlist":
        watchlist_trials()
    else:
        final_outputs()


if __name__ == "__main__":
    main()
