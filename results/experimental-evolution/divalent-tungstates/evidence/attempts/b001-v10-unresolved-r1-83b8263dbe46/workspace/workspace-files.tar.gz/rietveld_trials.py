#!/usr/bin/env python3
"""Staged GSAS-II refinements and matched-nuisance phase/profile trials."""

from __future__ import annotations

import argparse
import copy
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TRIALS = ROOT / "trials"
RESOURCE = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)
BASE_PHASE_FILES = {
    "SrWO4_scheelite": ROOT / "candidates" / "SrWO4_scheelite_from_SrMoO4_2300460.cif",
    "WO3_monoclinic": RESOURCE / "2/31/10/2311041.cif",
    "SrCO3_strontianite": RESOURCE / "9/00/81/9008198.cif",
}


def neutralize(project: G2sc.G2Project) -> None:
    """Set all inactive specimen/phase terms to physically neutral values."""
    hist = project.histogram(0)
    sample = hist.SampleParameters
    sample["Scale"] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key] = [0.0, False]

    inst = hist.InstrumentParameters
    starts = {
        "Zero": 0.0,
        "Polariz.": 0.5,
        "U": 10.0,
        "V": 0.0,
        "W": 50.0,
        "X": 10.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "I(L2)/I(L1)": 0.5,
    }
    for key, value in starts.items():
        inst[key][0] = value
        inst[key][1] = value
        if len(inst[key]) > 2:
            inst[key][2] = False

    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]
        hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][1][1] = 10.0
        hap["Size"][1][2] = 1.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][4] = [10.0, 10.0, 10.0, 0.0, 0.0, 0.0]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][4] = [0.0 for _ in hap["Mustrain"][4]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Use"] = True


def summary(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    row = {
        "label": label,
        "residuals": hist.residuals,
        "Rvals": cov.get("Rvals", {}),
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.", "I(L2)/I(L1)")
        },
        "sample": {
            key: hist.SampleParameters[key][0]
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "phases": {},
        "varyList": [str(value) for value in cov.get("varyList", [])],
        "sig": [float(value) for value in cov.get("sig", [])],
    }
    try:
        row["mass_fractions"] = {
            key: [float(v[0]), float(v[1])]
            for key, v in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        row["mass_fraction_error"] = str(exc)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        row["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    print(json.dumps(row, indent=2, default=str))
    return row


def refine_and_save(project: G2sc.G2Project, output: Path, label: str) -> dict:
    project.save(str(output))
    project.refine()
    project.save()
    return summary(project, label)


def cell_volume(cell: list[float]) -> float:
    a, b, c, alpha, beta, gamma = cell
    ca, cb, cg = (math.cos(math.radians(value)) for value in (alpha, beta, gamma))
    return a * b * c * math.sqrt(1.0 + 2.0 * ca * cb * cg - ca * ca - cb * cb - cg * cg)


def set_cell(phase: G2sc.G2Phase, cell: list[float]) -> None:
    phase.data["General"]["Cell"][1:7] = cell
    phase.data["General"]["Cell"][7] = cell_volume(cell)


def compact_summary(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    return {
        "label": label,
        "Rwp_percent": float(hist.residuals["wR"]),
        "GOF": float(cov["Rvals"]["GOF"]),
        "converged": bool(cov["Rvals"]["converged"]),
        "max_shift_over_esd": float(cov["Rvals"]["Max shft/sig"]),
        "shift_micrometres": float(hist.SampleParameters["Shift"][0]),
        "profile": {
            key: float(hist.InstrumentParameters[key][1])
            for key in ("U", "W", "X")
        },
        "phases": {
            phase.name: {
                "scale": float(phase.data["Histograms"][hist.name]["Scale"][0]),
                "cell": phase.get_cell(),
            }
            for phase in project.phases()
        },
        "mass_fractions": {
            key: [float(value[0]), float(value[1])]
            for key, value in hist.ComputeMassFracs().items()
        },
    }


def build_matched_competitor(label: str, replacement_name: str, replacement_file: Path) -> list[dict]:
    baseline = G2sc.G2Project(str(TRIALS / "baseline_valid.gpx"))
    base_hist = baseline.histogram(0)
    output = TRIALS / f"competitor_{label}.gpx"
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "candidates" / "lab_cuka1ka2.instprm"),
        fmthint="comma",
    )
    files = dict(BASE_PHASE_FILES)
    files[replacement_name] = replacement_file
    for name, path in files.items():
        project.add_phase(str(path), phasename=name, histograms=[hist])
    neutralize(project)
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5

    hist.Background[:] = copy.deepcopy(base_hist.Background)
    hist.SampleParameters.update(copy.deepcopy(base_hist.SampleParameters))
    hist.InstrumentParameters.update(copy.deepcopy(base_hist.InstrumentParameters))

    for phase in project.phases():
        base_phase = baseline.phase(phase.name)
        base_hap = base_phase.data["Histograms"][base_hist.name]
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [float(base_hap["Scale"][0]), True]
        phase.data["General"]["Cell"][0] = False
        # Same-setting structural competitors start at the identical observed
        # cell. Different-setting WO3 competitors retain their source cell.
        if phase.name != replacement_name or replacement_name == "SrWO4_scheelite":
            bcell = base_phase.get_cell()
            set_cell(
                phase,
                [
                    bcell["length_a"], bcell["length_b"], bcell["length_c"],
                    bcell["angle_alpha"], bcell["angle_beta"], bcell["angle_gamma"],
                ],
            )

    records = []
    project.save(str(TRIALS / f"competitor_{label}_01_scale.gpx"))
    project.refine()
    project.save()
    records.append(compact_summary(project, f"{label}_scale_first"))
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    project.save(str(TRIALS / f"competitor_{label}_02_cells.gpx"))
    project.refine()
    project.save()
    records.append(compact_summary(project, f"{label}_cells"))
    project.save(str(output))
    project.refine()
    project.save()
    records.append(compact_summary(project, f"{label}_replay"))
    return records


def run_baseline() -> None:
    setup = TRIALS / "setup.gpx"
    output = TRIALS / "baseline.gpx"
    project = G2sc.G2Project(str(setup), newgpx=str(output))
    neutralize(project)
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    hist.Background[0] = ["chebyschev-1", True, 6, 1050.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    # The line-family offsets imply about 1 mm specimen-height error. Seed it
    # fixed so that scale derivatives begin with overlapping peaks.
    hist.SampleParameters["Shift"] = [1000.0, False]
    scale_starts = {
        "SrWO4_scheelite": 10.0,
        "WO3_monoclinic": 2.0,
        "SrCO3_strontianite": 3.0,
    }
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"] = [scale_starts[phase.name], True]

    records = []
    records.append(refine_and_save(project, TRIALS / "baseline_01_scale.gpx", "scale_background_shift_fixed"))

    hist.SampleParameters["Shift"][1] = True
    records.append(refine_and_save(project, TRIALS / "baseline_02_shift.gpx", "release_shift"))

    for index, phase_name in enumerate(("SrWO4_scheelite", "WO3_monoclinic", "SrCO3_strontianite"), start=3):
        project.phase(phase_name).data["General"]["Cell"][0] = True
        records.append(refine_and_save(project, TRIALS / f"baseline_0{index}_{phase_name}_cell.gpx", f"cell_{phase_name}"))
    records.append(refine_and_save(project, TRIALS / "baseline_06_cells_replay.gpx", "cells_replay"))

    hist.InstrumentParameters["W"][2] = True
    records.append(refine_and_save(project, TRIALS / "baseline_07_W.gpx", "profile_W"))

    hist.InstrumentParameters["U"][2] = True
    hist.InstrumentParameters["X"][2] = True
    records.append(refine_and_save(project, TRIALS / "baseline_08_UWX.gpx", "profile_UWX"))
    records.append(refine_and_save(project, output, "profile_UWX_replay"))

    print(json.dumps({"baseline_records": records}, indent=2, default=str))


def run_profile_u0wx() -> None:
    source = TRIALS / "baseline_07_W.gpx"
    output = TRIALS / "baseline_valid.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(output))
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    inst = project.histogram(0).InstrumentParameters
    # Restore the pre-UWX trial, test U at the physical zero boundary, and
    # refine the complementary Gaussian/Lorentzian W/X baseline.
    inst["U"] = [0.0, 0.0, False]
    inst["W"][2] = True
    inst["X"][2] = True
    first = refine_and_save(project, TRIALS / "baseline_09_U0_WX.gpx", "U0_WX")
    second = refine_and_save(project, output, "U0_WX_replay")
    print(json.dumps({"profile_boundary_records": [first, second]}, indent=2, default=str))


def run_competitors() -> None:
    trials = [
        (
            "srwo4_cawo4_parent",
            "SrWO4_scheelite",
            ROOT / "candidates" / "SrWO4_scheelite_from_CaWO4_7219229.cif",
        ),
        (
            "wo3_1528915_review",
            "WO3_monoclinic",
            RESOURCE / "1/52/89/1528915.cif",
        ),
        (
            "wo3_2106293_triclinic",
            "WO3_monoclinic",
            RESOURCE / "2/10/62/2106293.cif",
        ),
    ]
    rows = {}
    for label, phase_name, path in trials:
        rows[label] = build_matched_competitor(label, phase_name, path)
        print(json.dumps({label: rows[label]}, indent=2, default=str))
    print(json.dumps({"competitor_records": rows}, indent=2, default=str))


def term_esd(project: G2sc.G2Project, suffix: str) -> float | None:
    cov = project.data.get("Covariance", {}).get("data", {})
    for name, esd in zip(cov.get("varyList", []), cov.get("sig", [])):
        if str(name).endswith(suffix):
            return float(esd)
    return None


def run_one_broadening_trial(phase_name: str, term: str) -> list[dict]:
    source = TRIALS / "competitor_srwo4_cawo4_parent.gpx"
    slug = phase_name.lower().replace("_", "-")
    output = TRIALS / f"broadening_{slug}_{term}.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(output))
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    hap = project.phase(phase_name).data["Histograms"][hist.name]
    if term == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2][0] = True
        suffix = "Size;i"
    elif term == "strain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2][0] = True
        suffix = "Mustrain;i"
    else:
        raise ValueError(term)

    rows = []
    for replay in (1, 2):
        project.save(str(output))
        project.refine()
        project.save()
        row = compact_summary(project, f"{phase_name}_{term}_replay_{replay}")
        hap = project.phase(phase_name).data["Histograms"][hist.name]
        row["trial_term"] = {
            "phase": phase_name,
            "kind": term,
            "value": float(
                hap["Size"][1][0] if term == "size" else hap["Mustrain"][1][0]
            ),
            "esd": term_esd(project, suffix),
            "refine_flag": bool(
                hap["Size"][2][0] if term == "size" else hap["Mustrain"][2][0]
            ),
        }
        rows.append(row)
    return rows


def run_broadening_trials() -> None:
    rows = {}
    for phase_name in ("SrWO4_scheelite", "WO3_monoclinic", "SrCO3_strontianite"):
        for term in ("size", "strain"):
            label = f"{phase_name}_{term}"
            rows[label] = run_one_broadening_trial(phase_name, term)
            print(json.dumps({label: rows[label]}, indent=2, default=str))
    print(json.dumps({"broadening_records": rows}, indent=2, default=str))


def run_one_anisotropy_trial(axis: list[int]) -> list[dict]:
    source = TRIALS / "broadening_wo3-monoclinic_strain.gpx"
    axis_slug = "".join(str(value) for value in axis)
    output = TRIALS / f"anisotropy_wo3_uniaxial_{axis_slug}.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(output))
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    hap = project.phase("WO3_monoclinic").data["Histograms"][hist.name]
    isotropic = float(hap["Mustrain"][1][0])
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = isotropic
    hap["Mustrain"][1][1] = isotropic
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    hap["Mustrain"][3] = list(axis)

    rows = []
    for replay in (1, 2):
        project.save(str(output))
        project.refine()
        project.save()
        row = compact_summary(project, f"WO3_uniaxial_{axis_slug}_replay_{replay}")
        hap = project.phase("WO3_monoclinic").data["Histograms"][hist.name]
        row["trial_term"] = {
            "phase": "WO3_monoclinic",
            "kind": "uniaxial_strain",
            "axis": list(axis),
            "isotropic_component": float(hap["Mustrain"][1][0]),
            "axial_component": float(hap["Mustrain"][1][1]),
            "isotropic_esd": term_esd(project, "Mustrain;i"),
            "axial_esd": term_esd(project, "Mustrain;a"),
        }
        rows.append(row)
    return rows


def run_anisotropy_trials() -> None:
    rows = {}
    for axis in ([0, 1, 0], [0, 0, 1]):
        label = "WO3_uniaxial_" + "".join(str(value) for value in axis)
        rows[label] = run_one_anisotropy_trial(list(axis))
        print(json.dumps({label: rows[label]}, indent=2, default=str))
    print(json.dumps({"anisotropy_records": rows}, indent=2, default=str))


def run_one_intensity_nuisance(term: str) -> list[dict]:
    source = TRIALS / "anisotropy_wo3_uniaxial_001.gpx"
    output = TRIALS / f"intensity_nuisance_{term}.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(output))
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    if term == "polarization":
        hist.InstrumentParameters["Polariz."] = [0.5, 0.5, True]
    elif term == "roughness_b":
        hist.SampleParameters["SurfRoughA"] = [0.0, False]
        hist.SampleParameters["SurfRoughB"] = [0.0, True]
    else:
        raise ValueError(term)

    rows = []
    for replay in (1, 2):
        project.save(str(output))
        project.refine()
        project.save()
        row = compact_summary(project, f"{term}_replay_{replay}")
        row["trial_term"] = {
            "kind": term,
            "polarization": float(hist.InstrumentParameters["Polariz."][1]),
            "roughness_a": float(hist.SampleParameters["SurfRoughA"][0]),
            "roughness_b": float(hist.SampleParameters["SurfRoughB"][0]),
            "esd": term_esd(
                project,
                "Polariz." if term == "polarization" else "SurfRoughB",
            ),
        }
        rows.append(row)
    return rows


def run_intensity_nuisance_trials() -> None:
    rows = {}
    for term in ("polarization", "roughness_b"):
        rows[term] = run_one_intensity_nuisance(term)
        print(json.dumps({term: rows[term]}, indent=2, default=str))
    print(json.dumps({"intensity_nuisance_records": rows}, indent=2, default=str))


def parameter_correlation(
    project: G2sc.G2Project,
    suffix_a: str,
    suffix_b: str,
) -> float | None:
    cov = project.data.get("Covariance", {}).get("data", {})
    names = [str(value) for value in cov.get("varyList", [])]
    matrix = cov.get("covMatrix")
    if matrix is None:
        return None
    ia = next((i for i, name in enumerate(names) if name.endswith(suffix_a)), None)
    ib = next((i for i, name in enumerate(names) if name.endswith(suffix_b)), None)
    if ia is None or ib is None:
        return None
    denom = math.sqrt(float(matrix[ia][ia]) * float(matrix[ib][ib]))
    return float(matrix[ia][ib]) / denom if denom else None


def run_combined_intensity_trials() -> None:
    specifications = {
        "polarization_roughness_b": (
            TRIALS / "intensity_nuisance_polarization.gpx",
            True,
            False,
            True,
        ),
        "roughness_ab": (
            TRIALS / "intensity_nuisance_roughness_b.gpx",
            False,
            True,
            True,
        ),
    }
    all_rows = {}
    for label, (source, refine_pol, refine_a, refine_b) in specifications.items():
        output = TRIALS / f"intensity_combined_{label}.gpx"
        project = G2sc.G2Project(str(source), newgpx=str(output))
        project.set_Controls("cycles", 12)
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
        hist = project.histogram(0)
        hist.InstrumentParameters["Polariz."][2] = refine_pol
        hist.SampleParameters["SurfRoughA"][1] = refine_a
        hist.SampleParameters["SurfRoughB"][1] = refine_b
        rows = []
        for replay in (1, 2):
            project.save(str(output))
            project.refine()
            project.save()
            row = compact_summary(project, f"{label}_replay_{replay}")
            row["trial_term"] = {
                "polarization": float(hist.InstrumentParameters["Polariz."][1]),
                "roughness_a": float(hist.SampleParameters["SurfRoughA"][0]),
                "roughness_b": float(hist.SampleParameters["SurfRoughB"][0]),
                "polarization_esd": term_esd(project, "Polariz."),
                "roughness_a_esd": term_esd(project, "SurfRoughA"),
                "roughness_b_esd": term_esd(project, "SurfRoughB"),
                "polarization_roughness_b_correlation": parameter_correlation(
                    project, "Polariz.", "SurfRoughB"
                ),
                "roughness_a_b_correlation": parameter_correlation(
                    project, "SurfRoughA", "SurfRoughB"
                ),
            }
            rows.append(row)
        all_rows[label] = rows
        print(json.dumps({label: rows}, indent=2, default=str))
    print(json.dumps({"combined_intensity_records": all_rows}, indent=2, default=str))


def run_one_texture_trial(phase_name: str, axis: list[int]) -> list[dict]:
    source = TRIALS / "intensity_nuisance_polarization.gpx"
    axis_slug = "".join(str(value) for value in axis)
    phase_slug = phase_name.lower().replace("_", "-")
    output = TRIALS / f"texture_{phase_slug}_{axis_slug}.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(output))
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    hap = project.phase(phase_name).data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)

    rows = []
    for replay in (1, 2):
        project.save(str(output))
        project.refine()
        project.save()
        row = compact_summary(project, f"{phase_name}_MD_{axis_slug}_replay_{replay}")
        hap = project.phase(phase_name).data["Histograms"][hist.name]
        row["trial_term"] = {
            "phase": phase_name,
            "kind": "March-Dollase",
            "axis": list(axis),
            "ratio": float(hap["Pref.Ori."][1]),
            "esd": term_esd(project, "MD"),
        }
        rows.append(row)
    return rows


def run_texture_trials() -> None:
    specifications = {
        "SrWO4_scheelite": ([0, 0, 1], [1, 1, 2]),
        "WO3_monoclinic": ([0, 0, 1], [1, 0, 1]),
        "SrCO3_strontianite": ([0, 0, 1], [1, 1, 1]),
    }
    all_rows = {}
    for phase_name, axes in specifications.items():
        for axis in axes:
            axis_list = list(axis)
            label = f"{phase_name}_MD_" + "".join(str(value) for value in axis_list)
            all_rows[label] = run_one_texture_trial(phase_name, axis_list)
            print(json.dumps({label: all_rows[label]}, indent=2, default=str))
    print(json.dumps({"texture_records": all_rows}, indent=2, default=str))


def run_texture_retry() -> None:
    source = TRIALS / "intensity_nuisance_polarization.gpx"
    all_rows = {}
    for seed in (0.9, 1.1):
        seed_slug = str(seed).replace(".", "p")
        output = TRIALS / f"texture_retry_srwo4_112_seed_{seed_slug}.gpx"
        project = G2sc.G2Project(str(source), newgpx=str(output))
        project.set_Controls("cycles", 12)
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
        hist = project.histogram(0)
        hap = project.phase("SrWO4_scheelite").data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = seed
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = [1, 1, 2]
        rows = []
        for replay in (1, 2):
            project.save(str(output))
            project.refine()
            project.save()
            row = compact_summary(project, f"SrWO4_MD_112_seed_{seed}_replay_{replay}")
            row["trial_term"] = {
                "phase": "SrWO4_scheelite",
                "kind": "March-Dollase",
                "axis": [1, 1, 2],
                "seed": seed,
                "ratio": float(hap["Pref.Ori."][1]),
                "esd": term_esd(project, "MD"),
            }
            rows.append(row)
        all_rows[seed_slug] = rows
        print(json.dumps({seed_slug: rows}, indent=2, default=str))
    print(json.dumps({"texture_retry_records": all_rows}, indent=2, default=str))


def texture_values(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    values = {}
    for phase in project.phases():
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        values[phase.name] = {
            "axis": list(po[3]),
            "ratio": float(po[1]),
            "refine_flag": bool(po[2]),
        }
    return values


def run_combined_texture() -> None:
    stages = [
        (
            "srwo4_wo3",
            TRIALS / "intensity_nuisance_polarization.gpx",
            {
                "SrWO4_scheelite": ([1, 1, 2], 0.7158),
                "WO3_monoclinic": ([0, 0, 1], 0.8822),
            },
        ),
        (
            "all_three",
            TRIALS / "texture_combined_srwo4_wo3.gpx",
            {
                "SrCO3_strontianite": ([0, 0, 1], 0.8424),
            },
        ),
    ]
    all_rows = {}
    for label, source, additions in stages:
        output = TRIALS / f"texture_combined_{label}.gpx"
        project = G2sc.G2Project(str(source), newgpx=str(output))
        project.set_Controls("cycles", 12)
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
        hist = project.histogram(0)
        for phase_name, (axis, ratio) in additions.items():
            po = project.phase(phase_name).data["Histograms"][hist.name]["Pref.Ori."]
            po[0] = "MD"
            po[1] = ratio
            po[2] = True
            po[3] = list(axis)
        rows = []
        for replay in (1, 2):
            project.save(str(output))
            project.refine()
            project.save()
            row = compact_summary(project, f"combined_texture_{label}_replay_{replay}")
            row["texture"] = texture_values(project)
            rows.append(row)
        all_rows[label] = rows
        print(json.dumps({label: rows}, indent=2, default=str))
    print(json.dumps({"combined_texture_records": all_rows}, indent=2, default=str))


def run_srwo4_anisotropic_strain() -> None:
    source = TRIALS / "texture_combined_all_three.gpx"
    all_rows = {}
    for axis in ([0, 0, 1], [1, 1, 2]):
        axis_slug = "".join(str(value) for value in axis)
        output = TRIALS / f"srwo4_uniaxial_strain_{axis_slug}.gpx"
        project = G2sc.G2Project(str(source), newgpx=str(output))
        project.set_Controls("cycles", 12)
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
        hist = project.histogram(0)
        hap = project.phase("SrWO4_scheelite").data["Histograms"][hist.name]
        # A mathematically exact zero gives 0/0 in GSAS-II's uniaxial formula;
        # 1 microstrain is an effectively neutral numerical seed.
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = 1.0
        hap["Mustrain"][1][1] = 1.0
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        hap["Mustrain"][3] = list(axis)
        rows = []
        for replay in (1, 2):
            project.save(str(output))
            project.refine()
            project.save()
            row = compact_summary(project, f"SrWO4_uniaxial_strain_{axis_slug}_{replay}")
            row["trial_term"] = {
                "axis": list(axis),
                "isotropic_component": float(hap["Mustrain"][1][0]),
                "axial_component": float(hap["Mustrain"][1][1]),
                "isotropic_esd": term_esd(project, "Mustrain;i"),
                "axial_esd": term_esd(project, "Mustrain;a"),
            }
            rows.append(row)
        all_rows[axis_slug] = rows
        print(json.dumps({axis_slug: rows}, indent=2, default=str))
    print(json.dumps({"srwo4_anisotropic_strain_records": all_rows}, indent=2, default=str))


def build_postprofile_source_competitor(
    label: str,
    replacement_phase: str,
    replacement_file: Path,
    same_setting: bool,
) -> list[dict]:
    source = TRIALS / "srwo4_uniaxial_strain_112.gpx"
    baseline = G2sc.G2Project(str(source))
    base_hist = baseline.histogram(0)
    output = TRIALS / f"postprofile_source_{label}.gpx"
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "candidates" / "lab_cuka1ka2.instprm"),
        fmthint="comma",
    )
    files = {
        "SrWO4_scheelite": ROOT / "candidates" / "SrWO4_scheelite_from_CaWO4_7219229.cif",
        "WO3_monoclinic": RESOURCE / "2/31/10/2311041.cif",
        "SrCO3_strontianite": RESOURCE / "9/00/81/9008198.cif",
    }
    files[replacement_phase] = replacement_file
    for name, path in files.items():
        project.add_phase(str(path), phasename=name, histograms=[hist])
    neutralize(project)
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist.Background[:] = copy.deepcopy(base_hist.Background)
    hist.SampleParameters.update(copy.deepcopy(base_hist.SampleParameters))
    hist.InstrumentParameters.update(copy.deepcopy(base_hist.InstrumentParameters))

    for phase in project.phases():
        base_phase = baseline.phase(phase.name)
        base_hap = base_phase.data["Histograms"][base_hist.name]
        hap = phase.data["Histograms"][hist.name]
        for key in ("Scale", "Size", "Mustrain", "Pref.Ori.", "Extinction", "Babinet"):
            hap[key] = copy.deepcopy(base_hap[key])
        hap["Use"] = True
        phase.data["General"]["Cell"][0] = True
        if phase.name != replacement_phase or same_setting:
            bcell = base_phase.get_cell()
            set_cell(
                phase,
                [
                    bcell["length_a"], bcell["length_b"], bcell["length_c"],
                    bcell["angle_alpha"], bcell["angle_beta"], bcell["angle_gamma"],
                ],
            )

    rows = []
    if not same_setting:
        project.phase(replacement_phase).data["General"]["Cell"][0] = False
    project.save(str(output))
    project.refine()
    project.save()
    rows.append(compact_summary(project, f"{label}_scale_nuisance"))
    project.phase(replacement_phase).data["General"]["Cell"][0] = True
    for replay in (1, 2):
        project.save(str(output))
        project.refine()
        project.save()
        rows.append(compact_summary(project, f"{label}_cell_replay_{replay}"))
    return rows


def run_postprofile_sources() -> None:
    specifications = [
        (
            "srwo4_srmoo4_parent",
            "SrWO4_scheelite",
            ROOT / "candidates" / "SrWO4_scheelite_from_SrMoO4_2300460.cif",
            True,
        ),
        (
            "wo3_triclinic_2106293",
            "WO3_monoclinic",
            RESOURCE / "2/10/62/2106293.cif",
            False,
        ),
    ]
    rows = {}
    for label, phase_name, path, same_setting in specifications:
        rows[label] = build_postprofile_source_competitor(
            label, phase_name, path, same_setting
        )
        print(json.dumps({label: rows[label]}, indent=2, default=str))
    print(json.dumps({"postprofile_source_records": rows}, indent=2, default=str))


def run_triclinic_replay() -> None:
    source = TRIALS / "postprofile_source_wo3_triclinic_2106293.gpx"
    output = TRIALS / "triclinic_reconverged.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(output))
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    rows = []
    for replay in (1, 2, 3):
        project.save(str(output))
        project.refine()
        project.save()
        rows.append(compact_summary(project, f"triclinic_replay_{replay}"))
        if rows[-1]["max_shift_over_esd"] < 0.05:
            break
    print(json.dumps({"triclinic_replay_records": rows}, indent=2, default=str))


def run_triclinic_nuisance() -> None:
    source = TRIALS / "triclinic_reconverged.gpx"
    specifications = ("polarization_fixed", "roughness_substitute", "roughness_added")
    all_rows = {}
    for label in specifications:
        output = TRIALS / f"triclinic_nuisance_{label}.gpx"
        project = G2sc.G2Project(str(source), newgpx=str(output))
        project.set_Controls("cycles", 12)
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
        hist = project.histogram(0)
        if label == "polarization_fixed":
            hist.InstrumentParameters["Polariz."] = [0.5, 0.5, False]
        elif label == "roughness_substitute":
            hist.InstrumentParameters["Polariz."] = [0.5, 0.5, False]
            hist.SampleParameters["SurfRoughA"] = [0.0, False]
            hist.SampleParameters["SurfRoughB"] = [0.0, True]
        else:
            hist.SampleParameters["SurfRoughA"] = [0.0, False]
            hist.SampleParameters["SurfRoughB"] = [0.0, True]
        rows = []
        for replay in (1, 2):
            project.save(str(output))
            project.refine()
            project.save()
            row = compact_summary(project, f"{label}_replay_{replay}")
            row["trial_term"] = {
                "polarization": float(hist.InstrumentParameters["Polariz."][1]),
                "polarization_flag": bool(hist.InstrumentParameters["Polariz."][2]),
                "roughness_a": float(hist.SampleParameters["SurfRoughA"][0]),
                "roughness_b": float(hist.SampleParameters["SurfRoughB"][0]),
                "roughness_b_esd": term_esd(project, "SurfRoughB"),
                "polarization_roughness_b_correlation": parameter_correlation(
                    project, "Polariz.", "SurfRoughB"
                ),
            }
            rows.append(row)
        all_rows[label] = rows
        print(json.dumps({label: rows}, indent=2, default=str))
    print(json.dumps({"triclinic_nuisance_records": all_rows}, indent=2, default=str))


def replay_with_wo3_term(
    source: Path,
    output: Path,
    label: str,
    configure,
) -> list[dict]:
    project = G2sc.G2Project(str(source), newgpx=str(output))
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    hap = project.phase("WO3_monoclinic").data["Histograms"][hist.name]
    configure(hap)
    rows = []
    for replay in (1, 2):
        project.save(str(output))
        project.refine()
        project.save()
        row = compact_summary(project, f"{label}_replay_{replay}")
        row["wo3_terms"] = {
            "size": copy.deepcopy(hap["Size"][:4]),
            "mustrain": copy.deepcopy(hap["Mustrain"][:4]),
            "preferred_orientation": copy.deepcopy(hap["Pref.Ori."][:4]),
        }
        rows.append(row)
    return rows


def run_triclinic_wo3_terms() -> None:
    baseline = TRIALS / "triclinic_reconverged.gpx"
    no_texture = TRIALS / "triclinic_wo3_no_texture.gpx"
    no_strain = TRIALS / "triclinic_wo3_no_strain.gpx"
    all_rows = {}

    def configure_no_texture(hap):
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]

    all_rows["no_texture"] = replay_with_wo3_term(
        baseline, no_texture, "triclinic_wo3_no_texture", configure_no_texture
    )
    print(json.dumps({"no_texture": all_rows["no_texture"]}, indent=2, default=str))

    for seed in (0.9, 1.1):
        label = f"texture_101_seed_{str(seed).replace('.', 'p')}"
        def configure_texture(hap, seed=seed):
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = seed
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [1, 0, 1]
        all_rows[label] = replay_with_wo3_term(
            no_texture,
            TRIALS / f"triclinic_wo3_{label}.gpx",
            f"triclinic_wo3_{label}",
            configure_texture,
        )
        print(json.dumps({label: all_rows[label]}, indent=2, default=str))

    def configure_no_strain(hap):
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]

    all_rows["no_strain"] = replay_with_wo3_term(
        baseline, no_strain, "triclinic_wo3_no_strain", configure_no_strain
    )
    print(json.dumps({"no_strain": all_rows["no_strain"]}, indent=2, default=str))

    def configure_size(hap):
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][2][0] = True

    all_rows["size"] = replay_with_wo3_term(
        no_strain,
        TRIALS / "triclinic_wo3_size.gpx",
        "triclinic_wo3_size",
        configure_size,
    )
    print(json.dumps({"size": all_rows["size"]}, indent=2, default=str))

    for axis in ([0, 0, 1], [1, 0, 1]):
        axis_slug = "".join(str(value) for value in axis)
        label = f"strain_{axis_slug}"
        def configure_strain(hap, axis=axis):
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1][0] = 1.0
            hap["Mustrain"][1][1] = 1.0
            hap["Mustrain"][2][0] = True
            hap["Mustrain"][2][1] = True
            hap["Mustrain"][3] = list(axis)
        all_rows[label] = replay_with_wo3_term(
            no_strain,
            TRIALS / f"triclinic_wo3_{label}.gpx",
            f"triclinic_wo3_{label}",
            configure_strain,
        )
        print(json.dumps({label: all_rows[label]}, indent=2, default=str))
    print(json.dumps({"triclinic_wo3_term_records": all_rows}, indent=2, default=str))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "action",
        choices=[
            "baseline", "profile_u0wx", "competitors", "broadening",
            "anisotropy", "intensity_nuisance", "combined_intensity",
            "texture", "texture_retry", "combined_texture",
            "srwo4_anisotropic_strain",
            "postprofile_sources",
            "triclinic_replay",
            "triclinic_nuisance",
            "triclinic_wo3_terms",
        ],
    )
    args = parser.parse_args()
    if args.action == "baseline":
        run_baseline()
    elif args.action == "profile_u0wx":
        run_profile_u0wx()
    elif args.action == "competitors":
        run_competitors()
    elif args.action == "broadening":
        run_broadening_trials()
    elif args.action == "anisotropy":
        run_anisotropy_trials()
    elif args.action == "intensity_nuisance":
        run_intensity_nuisance_trials()
    elif args.action == "combined_intensity":
        run_combined_intensity_trials()
    elif args.action == "texture":
        run_texture_trials()
    elif args.action == "texture_retry":
        run_texture_retry()
    elif args.action == "combined_texture":
        run_combined_texture()
    elif args.action == "srwo4_anisotropic_strain":
        run_srwo4_anisotropic_strain()
    elif args.action == "postprofile_sources":
        run_postprofile_sources()
    elif args.action == "triclinic_replay":
        run_triclinic_replay()
    elif args.action == "triclinic_nuisance":
        run_triclinic_nuisance()
    elif args.action == "triclinic_wo3_terms":
        run_triclinic_wo3_terms()


if __name__ == "__main__":
    main()
