#!/usr/bin/env python3
"""Create and inspect the initial three-phase GSAS-II project."""

from pathlib import Path
from pprint import pprint

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
RESOURCE = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)

project = G2sc.G2Project(newgpx=str(ROOT / "trials" / "setup.gpx"))
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "candidates" / "lab_cuka1ka2.instprm"),
    fmthint="comma",
)
phase_files = [
    ("SrWO4_scheelite", ROOT / "candidates" / "SrWO4_scheelite_from_SrMoO4_2300460.cif"),
    ("WO3_monoclinic", RESOURCE / "2/31/10/2311041.cif"),
    ("SrCO3_strontianite", RESOURCE / "9/00/81/9008198.cif"),
]
for name, path in phase_files:
    project.add_phase(str(path), phasename=name, histograms=[hist])

print("HISTOGRAM", hist.name)
print("LIMITS")
pprint(hist.data["Limits"])
print("INSTRUMENT")
pprint(hist.InstrumentParameters)
print("SAMPLE")
pprint(hist.SampleParameters)
print("BACKGROUND")
pprint(hist.Background)
print("CONTROLS")
pprint(project.data["Controls"]["data"])
for phase in project.phases():
    print("PHASE", phase.name)
    print("CELL", phase.get_cell())
    print("GENERAL")
    pprint({key: phase.data["General"].get(key) for key in ("Name", "Type", "Mass", "Cell", "SGData")})
    print("HAP")
    pprint(phase.data["Histograms"][hist.name])

project.save()
