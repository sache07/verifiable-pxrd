#!/usr/bin/env python3
"""Build the final four-phase GSAS-II project and export requested results."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE_GPX = ROOT / "compare_WO3_2311041.gpx"
FINAL_GPX = ROOT / "final.gpx"

PHASE_ORDER = ["BaWO4", "Ba3W2O9", "WO3", "BaCO3"]
PHASE_INFO = {
    "BaWO4": {
        "formula": "BaWO4",
        "cif_path": "BaWO4.cif",
        "identification": "scheelite BaWO4",
    },
    "Ba3W2O9": {
        "formula": "Ba3W2O9",
        "cif_path": "Ba3W2O9.cif",
        "identification": "rhombohedral Ba3W2O9",
    },
    "WO3": {
        "formula": "WO3",
        "cif_path": "WO3.cif",
        "identification": "monoclinic gamma-WO3",
    },
    "BaCO3": {
        "formula": "BaCO3",
        "cif_path": "BaCO3.cif",
        "identification": "witherite BaCO3",
    },
}


def prune_comparison_project() -> G2sc.G2Project:
    """Keep the selected WO3 model and remove the inactive comparison model."""
    gpx = G2sc.G2Project(str(SOURCE_GPX), newgpx=str(FINAL_GPX))
    hist = gpx.histogram(0)

    phases = gpx.data["Phases"]
    selected_wo3 = phases.pop("WO3_2311041")
    phases.pop("WO3")
    selected_wo3["General"]["Name"] = "WO3"
    phases["WO3"] = selected_wo3

    for item in gpx.names:
        if item and item[0] == "Phases":
            item[:] = ["Phases", *PHASE_ORDER]
            break

    reflection_lists = hist.data["Reflection Lists"]
    reflection_lists.pop("WO3", None)
    reflection_lists["WO3"] = reflection_lists.pop("WO3_2311041")

    # Include the full measured angular range in the final calculated profile.
    x = hist.data["data"][1][0]
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]

    gpx.update_ids()
    gpx.save(str(FINAL_GPX))
    return gpx


def refine_and_export(gpx: G2sc.G2Project) -> tuple[dict, dict, dict]:
    """Run the final refinement, export CIF/profile files, and return results."""
    # A second call starts from the first converged result and makes the
    # shift/esd convergence check stringent after the phase-ID remapping.
    gpx.refine()
    gpx.refine()
    gpx.save(str(FINAL_GPX))

    hist = gpx.histogram(0)
    mass_fractions = hist.ComputeMassFracs()
    if isinstance(mass_fractions, dict):
        fraction_by_name = {
            name: {"value": float(value), "esd": float(esd)}
            for name, (value, esd) in mass_fractions.items()
        }
    else:
        fraction_by_name = {
            name: {"value": float(value), "esd": float(esd)}
            for name, value, esd in mass_fractions
        }

    for name in PHASE_ORDER:
        gpx.phase(name).export_CIF(str(ROOT / PHASE_INFO[name]["cif_path"]))

    x, observed, _weights, calculated, background, difference = hist.data["data"][1]
    with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_intensity",
                "background_intensity",
            ]
        )
        writer.writerows(zip(x, observed, calculated, difference, background))

    residuals = hist.data["data"][0]
    rvals = gpx.data["Covariance"]["data"]["Rvals"]
    fit_stats = {
        "Rp_percent": float(residuals["R"]),
        "Rwp_percent": float(residuals["wR"]),
        "Rexp_percent": float(residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_square": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_variables": int(rvals["Nvars"]),
    }

    phase_results = []
    for name in PHASE_ORDER:
        phase = gpx.phase(name)
        sg = phase.data["General"]["SGData"]["SpGrp"]
        entry = {
            "name": name,
            "identification": PHASE_INFO[name]["identification"],
            "formula": PHASE_INFO[name]["formula"],
            "space_group": sg,
            "cif_path": PHASE_INFO[name]["cif_path"],
            "weight_fraction": fraction_by_name[name]["value"],
            "weight_fraction_percent": 100.0 * fraction_by_name[name]["value"],
            "weight_fraction_formal_esd": fraction_by_name[name]["esd"],
        }
        phase_results.append(entry)

    result = {
        "phases": phase_results,
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "fit_statistics": fit_stats,
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
    }
    with (ROOT / "result.json").open("w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")

    return result, fraction_by_name, fit_stats


def write_report(result: dict, fractions: dict, stats: dict) -> None:
    rows = []
    for phase in result["phases"]:
        name = phase["name"]
        rows.append(
            f"| {name} | {phase['space_group']} | "
            f"{100.0 * fractions[name]['value']:.2f} | "
            f"{100.0 * fractions[name]['esd']:.2f} |"
        )

    report = f"""# Quantitative phase analysis

## Result

Four crystalline phases are required by the pattern. Weight fractions below are normalized over those modeled crystalline phases; they do not measure any amorphous content.

| Phase | Space group | Weight fraction (wt%) | Formal esd (wt%) |
|---|---:|---:|---:|
{chr(10).join(rows)}

The final fit gives Rp = {stats['Rp_percent']:.3f}%, Rwp = {stats['Rwp_percent']:.3f}%, Rexp = {stats['Rexp_percent']:.3f}%, and goodness of fit = {stats['goodness_of_fit']:.3f}.

## Evidence

Scheelite BaWO4 accounts for the dominant reflections, including those near 26.69, 32.04, 43.19, 48.98, 53.68, 69.16, and 82.62 degrees 2theta. Ba3W2O9 is required for peaks near 26.28, 30.82, 37.66, 40.80, and 51.84 degrees. The characteristic split WO3 groups at approximately 23.40/23.88/24.65 and 33.56/33.83/34.45 degrees identify distorted tungsten trioxide. Residual peaks near 24.17, 34.84, 42.26, and 45.18 degrees require witherite BaCO3. This assemblage is chemically consistent with partial reaction of the stated WO3 and BaCO3 precursors at 750 degrees C, leaving both precursors alongside Ba-W-O products.

The four reference structures were refined together in GSAS-II using the supplied Cu Kalpha1/Kalpha2 wavelengths and intensity ratio. Starting models were COD 1527204 (BaWO4), 1533878 (Ba3W2O9), 2311041 (WO3), and 9010928 (BaCO3); the reported Pmcn carbonate setting is equivalent to standard Pnma (No. 62). Because pointwise uncertainties were not supplied, Poisson counting weights (1/count) were used. Phase scales and unit cells, a 12-term Chebyshev background, the pattern zero offset, selected crystallite-size terms, and a [112] March-Dollase correction for the dominant BaWO4 phase were refined. Atomic coordinates were retained from the reference structures because this powder pattern does not support reliable coordinate refinement for four overlapping phases. The profile started from a fixed, physically plausible instrumental-width floor because no instrumental standard or resolution function was supplied.

## Uncertainty and limitations

The tabulated esds are least-squares values only. Profile-width and texture sensitivity tests indicate a more realistic systematic uncertainty of roughly 1–2 wt% absolute for each phase, with the carbonate fraction especially correlated with peak width. The phase fractions are therefore best reported as about {100.0 * fractions['BaWO4']['value']:.1f}% BaWO4, {100.0 * fractions['Ba3W2O9']['value']:.1f}% Ba3W2O9, {100.0 * fractions['WO3']['value']:.1f}% WO3, and {100.0 * fractions['BaCO3']['value']:.1f}% BaCO3.

The exact low-symmetry description of WO3 is not uniquely determined. A triclinic literature model gives an essentially indistinguishable fit (Rwp lower by only about 0.005 percentage point). The submitted monoclinic gamma-WO3 model is preferred because it is the expected ambient polymorph and avoids unsupported symmetry lowering, but its symmetry should be regarded as provisional. No reliable amorphous fraction can be obtained without an internal standard.
"""
    (ROOT / "report.md").write_text(report, encoding="utf-8")


def main() -> None:
    gpx = prune_comparison_project()
    result, fractions, stats = refine_and_export(gpx)
    write_report(result, fractions, stats)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
