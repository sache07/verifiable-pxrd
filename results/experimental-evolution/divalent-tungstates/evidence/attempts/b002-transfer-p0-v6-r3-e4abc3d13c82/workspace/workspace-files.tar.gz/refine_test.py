#!/usr/bin/env python3
"""Exploratory GSAS-II Rietveld refinement for the supplied PXRD pattern."""

from __future__ import annotations

import csv
import json
import math
import os
import sys
from pathlib import Path

import numpy as np

from GSASII import GSASIIfiles as G2fil
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make_xye() -> Path:
    out = ROOT / "pattern.xye"
    with (ROOT / "inputs/pattern.csv").open(newline="") as src, out.open("w") as dst:
        rows = csv.reader(src)
        next(rows)
        dst.write("# two_theta_deg intensity\n")
        for x, y in rows:
            dst.write(f"{x} {y}\n")
    return out


def instrument_parameters():
    names = [
        "Type", "Lam1", "Lam2", "Zero", "I(L2)/I(L1)", "Polariz.",
        "U", "V", "W", "X", "Y", "Z", "SH/L", "Azimuth",
    ]
    values = [
        "PXC", 1.540598, 1.544426, 0.22, 0.5, 0.5,
        10.0, -5.0, 20.0, 0.0, 2.0, 0.0, 0.002, 0.0,
    ]
    inst = G2fil.makeInstDict(names, values, [False] * len(values))
    inst["Source"] = ["CuKa", "CuKa"]
    inst["Bank"] = [1, 1, 0]
    return [inst, {}]


def metrics(gpx, label):
    hist = gpx.histogram(0)
    print("\nMETRICS", label, json.dumps(hist.residuals, default=float, sort_keys=True))
    inst = hist.data["Instrument Parameters"][0]
    print("INST", {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1})
    for phase in gpx.phases():
        print("PHASE", phase.name, phase.get_cell(), "scale", phase.HAPvalue("Scale", targethistlist=[hist]))


def run(wo3_id="1528915", include_baco3=False, output="trial.gpx"):
    xye = make_xye()
    gpx = G2sc.G2Project(newgpx=str(ROOT / output))
    hist = gpx.add_powder_histogram(
        str(xye), instrument_parameters(), fmthint="Topas xye"
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.05)
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Type"] = "Bragg-Brentano"
    sample.setdefault("Shift", [0.0, False])
    sample.setdefault("Transparency", [0.0, False])
    sample.setdefault("SurfRoughA", [0.0, False])
    sample.setdefault("SurfRoughB", [0.0, False])

    phase_defs = [
        ("BaWO4", "1527204", 0.55),
        ("Ba3W2O9", "1533878", 0.20),
        ("WO3", wo3_id, 0.25),
    ]
    if include_baco3:
        phase_defs.append(("BaCO3", "9010928", 0.03))
    phases = []
    for name, cid, scale in phase_defs:
        phase = gpx.add_phase(str(cod_path(cid)), phasename=name, histograms=[hist])
        phase.HAPvalue("Scale", scale, targethistlist=[hist])
        phases.append(phase)

    # Keep iterations generous; step refinements avoid parameter correlations.
    gpx.data["Controls"]["data"]["max cyc"] = 12
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1", "refine": True, "no. coeffs": 12,
        }
    })
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    gpx.refine()
    metrics(gpx, "background+scales")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    gpx.refine()
    metrics(gpx, "cells")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    gpx.refine()
    metrics(gpx, "zero")

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
    gpx.refine()
    metrics(gpx, "profile")

    # Isotropic phase broadening is often needed for reaction mixtures.
    for phase in phases:
        phase.setSampleProfile(hist, "microstrain", "isotropic", 500.0, LGmix=0.5)
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    gpx.refine()
    metrics(gpx, "mustrain")

    gpx.save()
    return gpx


if __name__ == "__main__":
    wo3 = sys.argv[1] if len(sys.argv) > 1 else "1528915"
    baco3 = bool(int(sys.argv[2])) if len(sys.argv) > 2 else False
    out = sys.argv[3] if len(sys.argv) > 3 else f"trial_{wo3}_{int(baco3)}.gpx"
    run(wo3, baco3, out)
