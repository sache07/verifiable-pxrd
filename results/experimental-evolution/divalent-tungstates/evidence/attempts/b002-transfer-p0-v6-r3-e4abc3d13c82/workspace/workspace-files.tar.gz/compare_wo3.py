#!/usr/bin/env python3
"""Compare alternative WO3 structures against the same refined host model."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def compare(cod_id: str):
    out = ROOT / f"compare_WO3_{cod_id}.gpx"
    gpx = G2sc.G2Project(str(ROOT / "stable_final_candidate.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    old = gpx.phase("WO3")
    old.HAPvalue("Use", False, targethistlist=[hist])

    phase = gpx.add_phase(
        str(cod_path(cod_id)), phasename=f"WO3_{cod_id}", histograms=[hist]
    )
    target_mass_scale = 1854.776 * 0.8862
    phase.HAPvalue(
        "Scale", target_mass_scale / phase.data["General"]["Mass"],
        targethistlist=[hist],
    )
    phase.setSampleProfile(hist, "size", "isotropic", 0.09, LGmix=0.5)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=0.5)
    phase.set_refinements({"Cell": True})
    phase.set_HAP_refinements({"Scale": True}, [hist])
    gpx.data["Controls"]["data"]["max cyc"] = 12
    gpx.refine()
    phase.set_HAP_refinements(
        {"Size": {"type": "isotropic", "refine": True}}, [hist]
    )
    gpx.refine()
    gpx.save()
    print("WO3_COMPARISON " + json.dumps({
        "cod_id": cod_id,
        "space_group": phase.data["General"]["SGData"]["SpGrp"],
        "wR_percent": hist.residuals["wR"],
        "R_percent": hist.residuals["R"],
        "cell": phase.get_cell(),
        "size_micrometre": phase.getHAPvalues(hist)["Size"][1][0],
        "mass_fractions": hist.ComputeMassFracs(),
    }, sort_keys=True))


if __name__ == "__main__":
    compare(sys.argv[1])
