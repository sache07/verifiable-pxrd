#!/usr/bin/env python3
"""Build a reproducible four-phase GSAS-II refinement for pattern.csv."""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

from GSASII import GSASIIfiles as G2fil
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make_xye() -> Path:
    out = ROOT / "pattern.xye"
    with (ROOT / "inputs/pattern.csv").open(newline="") as src, out.open("w") as dst:
        rows = csv.reader(src)
        next(rows)
        dst.write("# two_theta_deg intensity_counts\n")
        for x, y in rows:
            dst.write(f"{x} {y}\n")
    return out


def instrument_parameters():
    # With no calibration standard supplied, use a conservative Gaussian
    # resolution floor matched to the narrowest resolved peaks. Phase-specific
    # broadening is then modeled as isotropic crystallite-size broadening.
    names = [
        "Type", "Lam1", "Lam2", "Zero", "I(L2)/I(L1)", "Polariz.",
        "U", "V", "W", "X", "Y", "Z", "SH/L", "Azimuth",
    ]
    values = [
        "PXC", 1.540598, 1.544426, 0.25, 0.5, 0.5,
        5.0, 0.0, 28.0, 0.0, 0.0, 0.0, 0.002, 0.0,
    ]
    inst = G2fil.makeInstDict(names, values, [False] * len(values))
    inst["Source"] = ["CuKa", "CuKa"]
    inst["Bank"] = [1, 1, 0]
    return [inst, {}]


def summarize(gpx: G2sc.G2Project) -> dict:
    hist = gpx.histogram(0)
    return {
        "wR_percent": float(hist.residuals["wR"]),
        "R_percent": float(hist.residuals["R"]),
        "wRmin_percent": float(hist.residuals["wRmin"]),
        "mass_fractions": {
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        },
        "cells": {phase.name: phase.get_cell() for phase in gpx.phases()},
        "sizes_micrometre": {
            phase.name: phase.getHAPvalues(hist)["Size"][1][0]
            for phase in gpx.phases()
        },
        "preferred_orientation": {
            phase.name: phase.getHAPvalues(hist)["Pref.Ori."][:4]
            for phase in gpx.phases()
        },
        "zero_deg": hist.data["Instrument Parameters"][0]["Zero"][1],
    }


def build_project(wo3_id: str, output: Path) -> G2sc.G2Project:
    gpx = G2sc.G2Project(newgpx=str(output))
    hist = gpx.add_powder_histogram(
        str(make_xye()), instrument_parameters(), fmthint="Topas xye"
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.05)
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Type"] = "Bragg-Brentano"
    sample.setdefault("Shift", [0.0, False])
    sample.setdefault("Transparency", [0.0, False])
    sample.setdefault("SurfRoughA", [0.0, False])
    sample.setdefault("SurfRoughB", [0.0, False])

    phase_defs = [
        ("BaWO4", "1527204", 4.5, 10.0),
        ("Ba3W2O9", "1533878", 0.35, 10.0),
        ("WO3", wo3_id, 0.75, 10.0),
        ("BaCO3", "9010928", 0.90, 10.0),
    ]
    phases = []
    for name, cid, scale, size in phase_defs:
        phase = gpx.add_phase(
            str(cod_path(cid)), phasename=name, histograms=[hist]
        )
        phase.HAPvalue("Scale", scale, targethistlist=[hist])
        phase.setSampleProfile(hist, "size", "isotropic", size, LGmix=0.5)
        # GSAS-II initializes a nonzero sample microstrain; explicitly remove
        # it so an unrefined default cannot broaden the calculated peaks.
        phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=0.5)
        phases.append(phase)

    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1e-5

    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1", "refine": True, "no. coeffs": 12,
        }
    })
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    gpx.refine()

    for phase in phases:
        phase.set_refinements({"Cell": True})
    gpx.refine()

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    gpx.refine()

    # The dominant scheelite phase shows a reproducible 112 cleavage texture.
    bawo4 = gpx.phase("BaWO4")
    po = bawo4.getHAPvalues(hist)["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", 1.0, True, [1, 1, 2]
    gpx.refine()

    # Introduce phase-specific broadening only after scales, cells, zero and
    # the dominant texture term have stabilized.
    size_start = {"BaWO4": 0.65, "Ba3W2O9": 0.125, "WO3": 0.09, "BaCO3": 0.05}
    for phase in phases:
        phase.getHAPvalues(hist)["Size"][1][0] = size_start[phase.name]
        # The weak, strongly overlapped carbonate profile does not constrain
        # width independently of scale; retain its observed-width estimate.
        refine_size = phase.name != "BaCO3"
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": refine_size}}, [hist]
        )
    gpx.refine()

    # One final cycle from the jointly refined state.
    gpx.refine()
    gpx.save()
    return gpx


if __name__ == "__main__":
    wo3_id = sys.argv[1] if len(sys.argv) > 1 else "1528915"
    output = Path(sys.argv[2]) if len(sys.argv) > 2 else ROOT / f"model_{wo3_id}.gpx"
    project = build_project(wo3_id, output)
    print("FINAL_SUMMARY " + json.dumps(summarize(project), sort_keys=True))
