#!/usr/bin/env python3
"""Build and refine the Mg-W-O powder model with GSAS-II."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

PHASE_FILES = {
    "MgWO4": COD / "9/01/39/9013902.cif",
    "WO3": COD / "2/31/10/2311041.cif",
    "MgO": COD / "9/00/04/9000499.cif",
}


def show_state(project, label):
    hist = project.histogram(0)
    print(f"\n--- {label} ---")
    print("residuals", hist.data["data"][0])
    print("instrument")
    for key, val in hist.data["Instrument Parameters"][0].items():
        if key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"):
            print(" ", key, val)
    print("sample scale", hist.data["Sample Parameters"]["Scale"])
    for phase in project.phases():
        print(phase.name, "cell", phase.get_cell(), "scale", phase.HAPvalue("Scale"))
        hap = phase.data["Histograms"][hist.name]
        print("  size", hap["Size"])
        print("  mustrain", hap["Mustrain"])


def run_refinement(project, label):
    project.refine(makeBack=False)
    show_state(project, label)


def main():
    project = G2sc.G2Project(newgpx=str(ROOT / "explore.gpx"))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 12,
                "coeffs": [3500.0] + [0.0] * 11,
            },
        }
    )

    phases = {}
    for name, filename in PHASE_FILES.items():
        phases[name] = project.add_phase(
            str(filename), phasename=name, histograms=[hist], fmthint="CIF"
        )

    # Use MgWO4 as the fixed internal scale reference and refine a common
    # histogram scale. The two minor-phase scales then determine their ratios.
    phases["MgWO4"].HAPvalue("Scale", 1.0)
    phases["WO3"].HAPvalue("Scale", 0.25)
    phases["MgO"].HAPvalue("Scale", 0.05)
    phases["MgWO4"].set_HAP_refinements({"Scale": False})
    phases["WO3"].set_HAP_refinements({"Scale": False})
    phases["MgO"].set_HAP_refinements({"Scale": False})

    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    project.save()
    show_state(project, "initial")

    run_refinement(project, "background and common scale")

    phases["WO3"].set_HAP_refinements({"Scale": True})
    phases["MgO"].set_HAP_refinements({"Scale": True})
    run_refinement(project, "phase scales")

    for phase in phases.values():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(project, "cells and zero")

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
    run_refinement(project, "shared profile")

    project.save(ROOT / "explore.gpx")
    print("mass fractions", hist.ComputeMassFracs())


if __name__ == "__main__":
    main()
