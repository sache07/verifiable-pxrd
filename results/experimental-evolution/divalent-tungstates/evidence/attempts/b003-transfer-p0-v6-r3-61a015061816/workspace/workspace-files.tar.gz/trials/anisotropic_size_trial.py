#!/usr/bin/env python3
"""Challenge symmetry-distinct uniaxial size axes for cubic Cu3WO6."""

from __future__ import annotations

import json
import sys

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    direction = [int(v) for v in sys.argv[1].split(",")]
    output = sys.argv[2]
    project = G2sc.G2Project("trials/broad_Cu3_size_reprofile.gpx", newgpx=output)
    hist = project.histogram(0)
    project.set_Frozen()
    phase = project.phase("Cu3WO6")
    hap = phase.getHAPvalues(hist.name)
    size = hap["Size"]
    size[0] = "uniaxial"
    size[1][0] = 0.17
    size[1][1] = 0.17
    size[2][0] = True
    size[2][1] = True
    size[2][2] = False
    size[3] = direction
    project.set_Controls("cycles", 12)
    project.save()
    project.refine()
    project.save()
    print("TRIAL_RESULT=" + json.dumps({
        "direction": direction,
        "wR_percent": hist.get_wR(),
        "equatorial_size_um": size[1][0],
        "axial_size_um": size[1][1],
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
