#!/usr/bin/env python3
"""Replace the provisional WO3 record and replay the common model."""

from __future__ import annotations

import json
import sys

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    cif, name, axis_text, output = sys.argv[1:5]
    axis = [int(v) for v in axis_text.split(",")]
    project = G2sc.G2Project("trials/add_CuO.gpx", newgpx=output)
    hist = project.histogram(0)
    project.set_Frozen()

    old = project.phase("WO3_monoclinic")
    old.set_refinements({"Cell": False})
    old_hap = old.getHAPvalues(hist.name)
    old_hap["Use"] = False
    old_hap["Scale"][1] = False
    old_hap["Pref.Ori."][2] = False

    phase = project.add_phase(cif, phasename=name, histograms=[hist], fmthint="CIF")
    for atom in phase.atoms():
        atom.uiso = 0.005 if atom.element == "W" else 0.010
        atom.refinement_flags = " "
    hap = phase.getHAPvalues(hist.name)
    hap["Scale"] = [19.0, True]
    hap["Pref.Ori."] = ["MD", 0.724, True, axis, 0, {}, [], 0.1]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])

    phase.set_refinements({"Cell": False})
    project.set_Controls("cycles", 12)
    project.save()
    project.refine()
    scale_result = {
        "wR_percent": hist.get_wR(),
        "scale": hap["Scale"][0],
        "texture_ratio": hap["Pref.Ori."][1],
        "cell": phase.get_cell(),
    }

    phase.set_refinements({"Cell": True})
    project.refine()
    project.save()
    result = {
        "phase": name,
        "axis": axis,
        "scale_stage": scale_result,
        "cell_stage": {
            "wR_percent": hist.get_wR(),
            "scale": hap["Scale"][0],
            "texture_ratio": hap["Pref.Ori."][1],
            "cell": phase.get_cell(),
            "mass_fractions": hist.ComputeMassFracs(),
            "profile_X": hist.data["Instrument Parameters"][0]["X"][1],
        },
    }
    print("TRIAL_RESULT=" + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
