#!/usr/bin/env python3
"""Replay profile, polarization, roughness and background nuisance trials."""

from __future__ import annotations

import json
import sys

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    mode, output = sys.argv[1:3]
    project = G2sc.G2Project("trials/replace_WO3_mono_alt.gpx", newgpx=output)
    hist = project.histogram(0)
    project.set_Frozen()
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    # Explicitly retain only one angular correction (Zero). All roughness
    # and profile terms not selected below start neutral and fixed.
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = False
    for key in ("U", "V", "W", "Y", "Z", "SH/L", "Polariz."):
        inst[key][2] = False
    inst["X"][2] = True

    if mode == "shl":
        inst["SH/L"][1] = 0.002
        inst["SH/L"][2] = True
        project.set_Controls("parmMin", 0.0005, variable=":0:SH/L")
    elif mode == "polar_refine":
        inst["Polariz."][1] = 0.5
        inst["Polariz."][2] = True
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif mode.startswith("polar_"):
        inst["Polariz."][1] = float(mode.split("_", 1)[1])
    elif mode == "rough_b" or mode.startswith("rougha_"):
        rough_a = 0.5 if mode == "rough_b" else float(mode.split("_", 1)[1])
        sample["SurfRoughA"] = [rough_a, False]
        sample["SurfRoughB"] = [0.01, True]
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    elif mode.startswith("roughboth_"):
        rough_a = float(mode.split("_", 1)[1])
        sample["SurfRoughA"] = [rough_a, True]
        sample["SurfRoughB"] = [0.05, True]
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    elif mode.startswith("bkg_"):
        ncoeff = int(mode.split("_", 1)[1])
        hist.set_refinements({"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": ncoeff}})
    else:
        raise ValueError(mode)

    project.set_Controls("cycles", 12)
    project.save()
    project.refine()
    project.save()
    result = {
        "mode": mode,
        "wR_percent": hist.get_wR(),
        "profile": {key: inst[key][1] for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
        "polarization": inst["Polariz."][1],
        "roughness": {key: sample[key][0] for key in ("SurfRoughA", "SurfRoughB")},
        "background": hist.data["Background"][0],
        "mass_fractions": hist.ComputeMassFracs(),
        "texture_ratio": project.phase("WO3_mono_alt").getHAPvalues(hist.name)["Pref.Ori."][1],
        "frozen": project.get_Frozen(),
    }
    print("TRIAL_RESULT=" + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
