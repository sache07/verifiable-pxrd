#!/usr/bin/env python3
"""Add a watch-list phase to the clean two-phase model and replay it."""

from __future__ import annotations

import json
import sys

from GSASII import GSASIIscriptable as G2sc


def neutralize_phase(phase, hist) -> None:
    for atom in phase.atoms():
        atom.uiso = {"W": 0.005, "Cu": 0.008, "O": 0.010}.get(atom.element, 0.010)
        atom.refinement_flags = " "
    hap = phase.getHAPvalues(hist.name)
    hap["Scale"] = [0.10, True]
    hap["Pref.Ori."] = ["MD", 1.0, False, [0, 0, 1], 0, {}, [], 0.1]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])


def snapshot(project, hist, candidate, stage):
    return {
        "stage": stage,
        "wR_percent": hist.get_wR(),
        "candidate_scale": candidate.getHAPvalues(hist.name)["Scale"][0],
        "candidate_cell": candidate.get_cell(),
        "mass_fractions": hist.ComputeMassFracs(),
        "profile_X": hist.data["Instrument Parameters"][0]["X"][1],
    }


def main() -> None:
    base, cif, name, output = sys.argv[1:5]
    project = G2sc.G2Project(base, newgpx=output)
    hist = project.histogram(0)
    project.set_Frozen()
    candidate = project.add_phase(
        cif,
        phasename=name,
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize_phase(candidate, hist)
    candidate.set_refinements({"Cell": False})
    project.set_Controls("cycles", 12)
    project.save()
    project.refine()
    results = [snapshot(project, hist, candidate, "scale")]

    if candidate.getHAPvalues(hist.name)["Scale"][0] > 1e-6:
        candidate.set_refinements({"Cell": True})
        project.refine()
        results.append(snapshot(project, hist, candidate, "cell"))
    project.save()
    print("TRIAL_RESULT=" + json.dumps({"phase": name, "results": results}, sort_keys=True))


if __name__ == "__main__":
    main()
