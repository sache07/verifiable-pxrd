#!/usr/bin/env python3
"""Challenge an additional phase texture axis after the baseline is rebuilt."""

from __future__ import annotations

import json
import sys

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    base, phase_name, direction_text, output = sys.argv[1:5]
    direction = [int(v) for v in direction_text.split(",")]
    project = G2sc.G2Project(base, newgpx=output)
    hist = project.histogram(0)
    project.set_Frozen()
    phase = project.phase(phase_name)
    hap = phase.getHAPvalues(hist.name)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = direction
    project.set_Controls("cycles", 12)
    project.save()
    project.refine()
    project.save()
    result = {
        "phase": phase_name,
        "direction": direction,
        "ratio": hap["Pref.Ori."][1],
        "wR_percent": hist.get_wR(),
        "mass_fractions": hist.ComputeMassFracs(),
    }
    print("TRIAL_RESULT=" + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
