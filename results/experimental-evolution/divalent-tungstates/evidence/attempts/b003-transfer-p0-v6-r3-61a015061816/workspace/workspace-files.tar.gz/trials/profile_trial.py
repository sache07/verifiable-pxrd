#!/usr/bin/env python3
"""Replay a common-profile trial from the converged two-phase project."""

from __future__ import annotations

import json
import sys

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    mode = sys.argv[1]
    output = sys.argv[2]
    project = G2sc.G2Project(
        "trials/two_phase_mono.gpx",
        newgpx=output,
    )
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]

    # Rebuild a nonnegative common profile. V, Y and Z remain neutral/fixed.
    starts = {
        "ux": {"U": 130.0, "W": 0.0, "X": 15.5},
        "wx": {"U": 0.0, "W": 30.0, "X": 15.5},
        "uw": {"U": 130.0, "W": 30.0, "X": 0.0},
        "uwx": {"U": 130.0, "W": 10.0, "X": 15.5},
    }
    varied = {
        "ux": {"U", "X"},
        "wx": {"W", "X"},
        "uw": {"U", "W"},
        "uwx": {"U", "W", "X"},
    }
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        inst[key][2] = False
    for key, val in starts[mode].items():
        inst[key][1] = val
        inst[key][2] = key in varied[mode]
    for key in varied[mode]:
        project.set_Controls("parmMin", 0.0, variable=f":0:{key}")

    project.set_Controls("cycles", 12)
    project.save()
    project.refine()
    project.save()

    result = {
        "mode": mode,
        "wR_percent": hist.get_wR(),
        "profile": {key: inst[key][1] for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
        "zero_deg": inst["Zero"][1],
        "mass_fractions": hist.ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "frozen": project.get_Frozen(),
    }
    print("TRIAL_RESULT=" + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
