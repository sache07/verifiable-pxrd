#!/usr/bin/env python3
"""Test one phase-specific isotropic size or strain term at a time."""

from __future__ import annotations

import json
import sys

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    phase_name, term, output = sys.argv[1:4]
    start = float(sys.argv[4]) if len(sys.argv) > 4 else (1.0 if term == "size" else 1000.0)
    project = G2sc.G2Project("trials/nuisance_polar_refine.gpx", newgpx=output)
    hist = project.histogram(0)
    project.set_Frozen()

    # Hold the accepted common profile fixed while phase broadening is tested.
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        inst[key][2] = False

    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])

    phase = project.phase(phase_name)
    hap = phase.getHAPvalues(hist.name)
    if term == "size":
        hap["Size"][1][0] = start
        hap["Size"][2][0] = True
    elif term == "strain":
        hap["Mustrain"][1][0] = start
        hap["Mustrain"][2][0] = True
    else:
        raise ValueError(term)

    project.set_Controls("cycles", 12)
    project.save()
    project.refine()
    project.save()
    result = {
        "phase": phase_name,
        "term": term,
        "wR_percent": hist.get_wR(),
        "size_um": hap["Size"][1][0],
        "microstrain_ppm": hap["Mustrain"][1][0],
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
    }
    print("TRIAL_RESULT=" + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
