#!/usr/bin/env python3
"""Build, replay, export and summarize the clean final GSAS-II model."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
GPX = ROOT / "final.gpx"


PHASES = [
    {
        "name": "Cu3WO6",
        "formula": "Cu3WO6",
        "source_cif": ROOT / "candidates" / "Cu3WO6_COD_1527404.cif",
        "source": "COD 1527404",
        "cell": [9.7775415984, 9.7775415984, 9.7775415984, 90.0, 90.0, 90.0],
        "scale": 5.8053728593,
        "cif": ROOT / "phase_Cu3WO6.cif",
    },
    {
        "name": "WO3_monoclinic",
        "formula": "WO3",
        "source_cif": ROOT / "candidates" / "WO3_monoclinic_alt_COD_2311041.cif",
        "source": "COD 2311041",
        "cell": [7.6829361463, 7.5377128821, 10.5095880880, 90.0, 136.0520838309, 90.0],
        "scale": 17.7377856353,
        "cif": ROOT / "phase_WO3_monoclinic.cif",
    },
    {
        "name": "CuO",
        "formula": "CuO",
        "source_cif": ROOT / "candidates" / "CuO_COD_1011194.cif",
        "source": "COD 1011194",
        "cell": [4.6667157725, 3.4283710291, 5.1200739267, 90.0, 99.4937624640, 90.0],
        "scale": 14.9961525306,
        "cif": ROOT / "phase_CuO.cif",
    },
]


def set_cell(phase, cell: list[float]) -> None:
    phase.data["General"]["Cell"][1:7] = cell
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))
    phase.set_refinements({"Cell": True})


def neutralize_hap(phase, hist) -> dict:
    hap = phase.getHAPvalues(hist.name)
    hap["Pref.Ori."] = ["MD", 1.0, False, [0, 0, 1], 0, {}, [], 0.1]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    return hap


def build_project() -> G2sc.G2Project:
    project = G2sc.G2Project(newgpx=str(GPX))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.set_refinements({"Limits": [9.90343322, 100.09455322]})
    hist.data["Background"][0] = [
        "chebyschev-1",
        True,
        6,
        1173.1907385,
        -604.7588221,
        427.5857957,
        -192.5722431,
        73.0894747,
        -22.6219038,
    ]

    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key] = [0.0, False]

    inst = hist.data["Instrument Parameters"][0]
    for key, value in {
        "Zero": 0.0574756733,
        "Polariz.": 0.6185903162,
        "U": 0.0,
        "V": 0.0,
        "W": 0.0,
        "X": 13.7894034631,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }.items():
        inst[key][1] = value
        inst[key][2] = key in {"Zero", "Polariz.", "X"}
    inst["I(L2)/I(L1)"][1] = 0.5
    inst["I(L2)/I(L1)"][2] = False

    for spec in PHASES:
        phase = project.add_phase(
            str(spec["source_cif"]),
            phasename=spec["name"],
            histograms=[hist],
            fmthint="CIF",
        )
        for atom in phase.atoms():
            atom.uiso = {"W": 0.005, "Cu": 0.008, "O": 0.010}.get(atom.element, 0.010)
            atom.refinement_flags = " "
        set_cell(phase, spec["cell"])
        hap = neutralize_hap(phase, hist)
        hap["Scale"] = [spec["scale"], True]
        if spec["name"] == "Cu3WO6":
            hap["Size"][1][0] = 0.1681841974
            hap["Size"][2][0] = True
        elif spec["name"] == "WO3_monoclinic":
            hap["Pref.Ori."] = ["MD", 0.7169712688, True, [1, 0, -1], 0, {}, [], 0.1]
        elif spec["name"] == "CuO":
            hap["Mustrain"][1][0] = 5876.7458282
            hap["Mustrain"][2][0] = True

    project.set_Controls("cycles", 12)
    project.set_Controls("parmMin", 0.0, variable=":0:X")
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.set_Controls("parmMin", 0.001, variable="0:0:Size;i")
    project.set_Controls("parmMax", 10.0, variable="0:0:Size;i")
    project.set_Controls("parmMin", 0.0, variable="2:0:Mustrain;i")
    project.save()
    return project


def replay(project: G2sc.G2Project, count: int = 3) -> G2sc.G2Project:
    for cycle in range(count):
        project.refine()
        project.save()
        rvals = project.data["Covariance"]["data"]["Rvals"]
        print(
            f"replay {cycle + 1}: Rwp={rvals['Rwp']:.6f}% "
            f"GOF={rvals['GOF']:.6f} converged={rvals['converged']}"
        )
        project = G2sc.G2Project(str(GPX))
    return project


def export(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    if abs(sum(v[0] for v in fractions.values()) - 1.0) > 1e-10:
        raise RuntimeError("mass fractions are not normalized")

    for spec in PHASES:
        project.phase(spec["name"]).export_CIF(str(spec["cif"]))

    arrays = {
        "two_theta_deg": np.asarray(hist.getdata("X")),
        "observed_intensity": np.asarray(hist.getdata("Yobs")),
        "calculated_intensity": np.asarray(hist.getdata("Ycalc")),
        "difference_obs_minus_calc": np.asarray(hist.getdata("Residual")),
        "background_intensity": np.asarray(hist.getdata("Background")),
    }
    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(arrays)
        writer.writerows(zip(*(arrays[key] for key in arrays)))

    residuals = hist.data["data"][0]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    phase_rows = []
    for spec in PHASES:
        phase = project.phase(spec["name"])
        cell, cell_esd = phase.get_cell_and_esd()
        wt, wt_esd = fractions[spec["name"]]
        pid = phase.id
        phase_rows.append(
            {
                "name": spec["name"],
                "formula": spec["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": spec["cif"].name,
                "source_structure": spec["source"],
                "weight_fraction": wt,
                "weight_fraction_esd_statistical": wt_esd,
                "cell": cell,
                "cell_esd": cell_esd,
                "R_F_percent": residuals.get(f"{pid}:0:Rf"),
                "R_F2_percent": residuals.get(f"{pid}:0:Rf^2"),
            }
        )

    result = {
        "project_path": GPX.name,
        "profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over modeled crystalline phases; amorphous content not determined",
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": rvals["Rwp"],
            "Rp_percent": residuals["R"],
            "R_background_percent": residuals["Rb"],
            "weighted_R_background_percent": residuals["wRb"],
            "R_expected_percent": residuals["wRmin"],
            "goodness_of_fit": rvals["GOF"],
            "chi_square": rvals["chisq"],
            "durbin_watson": residuals["Durbin-Watson"],
            "n_observations": rvals["Nobs"],
            "n_refined_variables": rvals["Nvars"],
        },
        "measurement": {
            "radiation": "Cu K-alpha1/K-alpha2",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "two_theta_range_deg": [float(arrays["two_theta_deg"][0]), float(arrays["two_theta_deg"][-1])],
        },
    }
    with (ROOT / "result.json").open("w") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")


def main() -> None:
    project = build_project()
    project = replay(project)
    export(project)


if __name__ == "__main__":
    main()
