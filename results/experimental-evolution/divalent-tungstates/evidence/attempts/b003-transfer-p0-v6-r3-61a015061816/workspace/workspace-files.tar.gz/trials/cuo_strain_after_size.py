#!/usr/bin/env python3
"""Replay CuO isotropic microstrain after accepting Cu3WO6 size."""

from __future__ import annotations

import json
import sys

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    start = float(sys.argv[1])
    output = sys.argv[2]
    project = G2sc.G2Project("trials/broad_Cu3_size_reprofile.gpx", newgpx=output)
    hist = project.histogram(0)
    project.set_Frozen()
    phase = project.phase("CuO")
    hap = phase.getHAPvalues(hist.name)
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [start, 0.0, 1.0]
    hap["Mustrain"][2] = [True, False, False]
    project.set_Controls("parmMin", 0.0, variable="2:0:Mustrain;i")
    project.set_Controls("cycles", 12)
    project.save()
    project.refine()
    project.save()
    print("TRIAL_RESULT=" + json.dumps({
        "start": start,
        "wR_percent": hist.get_wR(),
        "microstrain_ppm": hap["Mustrain"][1][0],
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
