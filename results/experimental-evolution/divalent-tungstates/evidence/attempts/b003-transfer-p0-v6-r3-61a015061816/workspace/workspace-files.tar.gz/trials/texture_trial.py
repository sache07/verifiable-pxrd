#!/usr/bin/env python3
"""Compare March-Dollase texture axes under a shared nuisance model."""

from __future__ import annotations

import json
import sys

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    phase_name = sys.argv[1]
    direction = [int(v) for v in sys.argv[2].split(",")]
    output = sys.argv[3]
    project = G2sc.G2Project("trials/profile_ux.gpx", newgpx=output)
    hist = project.histogram(0)

    # Retain the accepted, nonnegative common profile. U and W are zero;
    # allow only X to reconverge with scales, background, zero and cells.
    project.set_Frozen()
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        inst[key][2] = key == "X"
    inst["U"][1] = 0.0
    inst["W"][1] = 0.0

    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = phase.name == phase_name
        hap["Pref.Ori."][3] = direction if phase.name == phase_name else [0, 0, 1]

    project.set_Controls("cycles", 12)
    project.save()
    project.refine()
    project.save()

    result = {
        "phase": phase_name,
        "direction": direction,
        "wR_percent": hist.get_wR(),
        "texture": {
            phase.name: {
                "ratio": phase.getHAPvalues(hist.name)["Pref.Ori."][1],
                "axis": phase.getHAPvalues(hist.name)["Pref.Ori."][3],
                "refined": phase.getHAPvalues(hist.name)["Pref.Ori."][2],
            }
            for phase in project.phases()
        },
        "profile_X": inst["X"][1],
        "mass_fractions": hist.ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }
    print("TRIAL_RESULT=" + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
