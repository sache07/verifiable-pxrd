#!/usr/bin/env python3
"""Assess physically plausible isotropic displacement-parameter treatments."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def set_uiso(project: G2sc.G2Project, variant: str) -> None:
    for phase in project.phases():
        element_groups: dict[str, list[str]] = {}
        for atom_index, atom in enumerate(phase.atoms()):
            if variant in ("all_001", "all_refined"):
                atom.uiso = 0.01
            elif variant in ("element_fixed", "element_refined", "group_refined"):
                if atom.element == "O":
                    atom.uiso = 0.012 if "WO3" in phase.name else 0.015
                elif atom.element == "W":
                    atom.uiso = 0.005
                elif atom.element == "Pb":
                    atom.uiso = 0.010
            if variant in ("all_refined", "element_refined", "group_refined"):
                atom.refinement_flags = "U"
                project.set_Controls(
                    "parmMin", 0.0, f"{phase.id}::AUiso:{atom_index}"
                )
                project.set_Controls(
                    "parmMax", 0.05, f"{phase.id}::AUiso:{atom_index}"
                )
                element_groups.setdefault(atom.element, []).append(
                    f"{phase.id}::AUiso:{atom_index}"
                )
            else:
                atom.refinement_flags = " "
        if variant == "group_refined":
            for variables in element_groups.values():
                if len(variables) > 1:
                    project.add_EquivConstr(variables)


def run(variant: str) -> None:
    source = Path(".tmp/instrument_variants/pol_wprof.gpx")
    target = Path(".tmp/adp_variants") / f"{variant}.gpx"
    target.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(source), newgpx=str(target))
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    set_uiso(project, variant)
    project.save(str(target))
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    project.save(str(target))
    hist = project.histogram(0)
    summary = {
        "variant": variant,
        "residuals": {
            key: hist.data["data"][0].get(key)
            for key in ("R", "wR", "Rb", "wRb", "wRmin", "Durbin-Watson")
        },
        "fractions": hist.ComputeMassFracs(),
        "polarization": hist.data["Instrument Parameters"][0]["Polariz."],
        "atoms": {
            phase.name: [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "uiso": atom.uiso,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ]
            for phase in project.phases()
        },
        "frozen": project.get_Frozen(),
    }
    Path(".tmp/adp_variants", f"{variant}.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps(summary, sort_keys=True))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "variant",
        choices=(
            "all_001",
            "element_fixed",
            "all_refined",
            "element_refined",
            "group_refined",
        ),
    )
    run(parser.parse_args().variant)


if __name__ == "__main__":
    main()
