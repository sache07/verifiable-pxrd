#!/usr/bin/env python3
"""Test limited, physically bounded instrument/background refinements."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def run(variant: str) -> None:
    source = Path(".tmp/profile_variants/lorentzian.gpx")
    target = Path(".tmp/instrument_variants") / f"{variant}.gpx"
    target.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(source), newgpx=str(target))
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]

    params: list[str] = []
    if "pol" in variant:
        params.append("Polariz.")
        project.set_Controls("parmMin", 0.0, ":0:Polariz.")
        project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    if "wprof" in variant:
        params.append("W")
        project.set_Controls("parmMin", 0.0, ":0:W")
        project.set_Controls("parmMax", 100.0, ":0:W")
    if params:
        hist.set_refinements({"Instrument Parameters": params})
    if "bg16" in variant:
        hist.set_refinements({"Background": {"no. coeffs": 16, "refine": True}})
    elif "bg8" in variant:
        hist.set_refinements({"Background": {"no. coeffs": 8, "refine": True}})

    project.save(str(target))
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    project.save(str(target))
    summary = {
        "variant": variant,
        "residuals": {
            key: hist.data["data"][0].get(key)
            for key in ("R", "wR", "Rb", "wRb", "wRmin", "Durbin-Watson")
        },
        "fractions": hist.ComputeMassFracs(),
        "instrument": {
            key: inst[key]
            for key in ("Polariz.", "U", "V", "W", "X", "Y", "SH/L")
        },
        "background_terms": hist.data["Background"][0][2],
        "frozen": project.get_Frozen(),
    }
    Path(".tmp/instrument_variants", f"{variant}.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps(summary, sort_keys=True))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("variant", choices=("pol", "pol_wprof", "pol_bg16", "bg16", "bg8"))
    run(parser.parse_args().variant)


if __name__ == "__main__":
    main()
