#!/usr/bin/env python3
"""Run staged GSAS-II refinements for candidate phase assemblages."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)

MODELS = {
    "two": [
        ("PbWO4_scheelite", "9009811"),
        ("WO3_monoclinic", "1528915"),
    ],
    "three_minium": [
        ("PbWO4_scheelite", "9009811"),
        ("WO3_monoclinic", "1528915"),
        ("Pb3O4_minium", "1537983"),
    ],
    "three_litharge": [
        ("PbWO4_scheelite", "9009811"),
        ("WO3_monoclinic", "1528915"),
        ("PbO_litharge", "9012700"),
    ],
    "four_minium_litharge": [
        ("PbWO4_scheelite", "9009811"),
        ("WO3_monoclinic", "1528915"),
        ("Pb3O4_minium", "1537983"),
        ("PbO_litharge", "9012700"),
    ],
}


def cod_cif(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def stage_summary(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    resid = dict(hist.data["data"][0])
    summary = {
        "stage": label,
        "residuals": {
            key: float(resid[key])
            for key in ("R", "wR", "Rb", "wRb", "GOF")
            if key in resid
        },
        "sample": {
            key: hist.data["Sample Parameters"][key]
            for key in ("Scale", "Shift", "Transparency")
        },
        "instrument": {
            key: hist.data["Instrument Parameters"][0][key]
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L")
        },
        "phases": {},
    }
    try:
        mass_fracs = hist.ComputeMassFracs()
    except Exception as exc:  # early stages may not yet have a covariance matrix
        mass_fracs = {"error": str(exc)}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        summary["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "mass_fraction": mass_fracs.get(phase.name),
        }
    return summary


def refine(project: G2sc.G2Project, label: str, log: list[dict]) -> None:
    project.refine(makeBack=False)
    item = stage_summary(project, label)
    log.append(item)
    print("STAGE", label, json.dumps(item, sort_keys=True))


def run(model: str, outdir: Path, background_terms: int) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    gpx_path = outdir / f"{model}.gpx"
    project = G2sc.G2Project(newgpx=str(gpx_path))
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5

    hist = project.add_powder_histogram(
        "inputs/pattern.csv", ".tmp/cu_ka.instprm", fmthint="comma"
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [-700.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": background_terms,
                "coeffs": [1200.0] + [0.0] * (background_terms - 1),
            }
        }
    )

    phases = []
    for name, cod_id in MODELS[model]:
        phase = project.add_phase(
            str(cod_cif(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase.data["Histograms"][hist.name]["Scale"][0] = 0.1
        phase.data["Histograms"][hist.name]["Size"][1][0] = 0.05
        phase.set_HAP_refinements({"Scale": True})
        phases.append(phase)

    log: list[dict] = []
    refine(project, "scale_background", log)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "shift_cells", log)

    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": 0.05,
                    "refine": True,
                    "LGmix": {"value": 0.5, "refine": False},
                }
            }
        )
    refine(project, "sizes", log)

    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 0.5, "refine": False},
                }
            }
        )
    refine(project, "sizes_strain", log)

    # A final common instrumental Gaussian profile adjustment captures the
    # resolution component while phase-specific broadening remains in HAP terms.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
    refine(project, "profile", log)

    project.save(str(gpx_path))
    (outdir / f"{model}_summary.json").write_text(
        json.dumps(log, indent=2, sort_keys=True) + "\n"
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", choices=sorted(MODELS))
    parser.add_argument("--outdir", type=Path, default=Path(".tmp/models"))
    parser.add_argument("--background-terms", type=int, default=12)
    args = parser.parse_args()
    run(args.model, args.outdir, args.background_terms)


if __name__ == "__main__":
    main()
