#!/usr/bin/env python3
"""Test low-order preferred-orientation models for sensitivity."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def run(variant: str) -> None:
    source = Path(".tmp/adp_variants/element_fixed.gpx")
    target = Path(".tmp/texture_variants") / f"{variant}.gpx"
    target.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(source), newgpx=str(target))
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.histogram(0)
    selected = []
    for phase in project.phases():
        use = variant == "all_sh2" or (
            variant == "pbwo4_sh2" and phase.name.startswith("PbWO4")
        ) or (variant == "wo3_sh2" and phase.name.startswith("WO3")) or (
            variant == "minium_sh2" and phase.name.startswith("Pb3O4")
        )
        if use:
            phase.HAPvalue("PO", 2)
            phase.set_HAP_refinements({"Pref.Ori.": True})
            selected.append(phase.name)
    project.save(str(target))
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    project.save(str(target))
    summary = {
        "variant": variant,
        "selected": selected,
        "residuals": {
            key: hist.data["data"][0].get(key)
            for key in ("R", "wR", "Rb", "wRb", "wRmin", "Durbin-Watson")
        },
        "fractions": hist.ComputeMassFracs(),
        "po": {
            phase.name: phase.data["Histograms"][hist.name]["Pref.Ori."]
            for phase in project.phases()
        },
        "frozen": project.get_Frozen(),
    }
    Path(".tmp/texture_variants", f"{variant}.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps(summary, sort_keys=True))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "variant", choices=("all_sh2", "pbwo4_sh2", "wo3_sh2", "minium_sh2")
    )
    run(parser.parse_args().variant)


if __name__ == "__main__":
    main()
