#!/usr/bin/env python3
"""Compare alternative crystallographic models under one refinement recipe."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
VARIANTS = {
    "mono_old": ("1528915", "1537983"),
    "mono_new": ("1528915", "9012124"),
    "triclinic_old": ("2106293", "1537983"),
    "triclinic_new": ("2106293", "9012124"),
    "p21m_old": ("1010618", "1537983"),
}
BACKGROUND = [
    1459.1,
    -1210.56,
    645.53,
    -225.08,
    71.11,
    -16.41,
    11.38,
    -0.05,
    1.88,
    14.60,
    -21.37,
    16.89,
]


def cod_cif(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def do_refine(project: G2sc.G2Project) -> None:
    project.refine(makeBack=False)


def run(variant: str) -> None:
    wo3_id, minium_id = VARIANTS[variant]
    outdir = Path(".tmp/structural_variants")
    outdir.mkdir(parents=True, exist_ok=True)
    target = outdir / f"{variant}.gpx"
    project = G2sc.G2Project(newgpx=str(target))
    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", ".tmp/cu_ka.instprm", fmthint="comma"
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [-728.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": len(BACKGROUND),
                "coeffs": BACKGROUND,
            }
        }
    )
    inst = hist.data["Instrument Parameters"][0]
    inst["Polariz."][1] = 0.94
    inst["W"][1] = 12.0

    specs = [
        ("PbWO4_scheelite", "9009811", 7.0, 0.046),
        ("WO3", wo3_id, 2.5, 0.17),
        ("Pb3O4_minium", minium_id, 1.3, 0.030),
    ]
    phases = []
    for name, cod_id, scale, size in specs:
        phase = project.add_phase(
            str(cod_cif(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [size, 1.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2][0] = False
        for atom in phase.atoms():
            if name == "PbWO4_scheelite":
                atom.uiso = 0.01
            elif atom.element == "O":
                atom.uiso = 0.012 if name == "WO3" else 0.015
            elif atom.element == "W":
                atom.uiso = 0.005
            elif atom.element == "Pb":
                atom.uiso = 0.010
            atom.refinement_flags = " "
        phases.append(phase)

    # Establish scales and background before positional/profile parameters.
    do_refine(project)
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    do_refine(project)
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )
        project.set_Controls("parmMin", 0.003, f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 10.0, f"{phase.id}:0:Size;i")
    do_refine(project)
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Controls("parmMin", 0.0, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    do_refine(project)
    hist.set_refinements({"Instrument Parameters": ["W"]})
    project.set_Controls("parmMin", 0.0, ":0:W")
    project.set_Controls("parmMax", 100.0, ":0:W")
    do_refine(project)
    do_refine(project)
    project.save(str(target))

    summary = {
        "variant": variant,
        "source_ids": {"WO3": wo3_id, "Pb3O4": minium_id},
        "residuals": {
            key: hist.data["data"][0].get(key)
            for key in ("R", "wR", "Rb", "wRb", "wRmin", "Durbin-Watson")
        },
        "fractions": hist.ComputeMassFracs(),
        "polarization": inst["Polariz."],
        "W": inst["W"],
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "frozen": project.get_Frozen(),
    }
    (outdir / f"{variant}.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps(summary, sort_keys=True))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("variant", choices=sorted(VARIANTS))
    run(parser.parse_args().variant)


if __name__ == "__main__":
    main()
