#!/usr/bin/env python3
"""Continue the three-phase fit with physically constrained profile variants."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def run(variant: str) -> None:
    source = Path(".tmp/models/three_minium.gpx")
    target = Path(".tmp/profile_variants") / f"{variant}.gpx"
    target.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(source), newgpx=str(target))
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)

    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 2.0, "V": -2.0, "W": 5.0}.items():
        inst[key][1] = value
        inst[key][2] = False

    mix = {"lorentzian": 1.0, "gaussian": 0.0, "fixed_half": 0.5}.get(
        variant, 0.5
    )
    refine_mix = variant == "refined_mix"
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2][0] = False
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2][2] = False
        hap["Size"][1][2] = mix
        hap["Size"][2][2] = refine_mix
        project.set_Controls("parmMin", 0.003, f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 10.0, f"{phase.id}:0:Size;i")
        if refine_mix:
            project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Size;mx")
            project.set_Controls("parmMax", 1.0, f"{phase.id}:0:Size;mx")

    project.save(str(target))
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    project.save(str(target))

    fractions = hist.ComputeMassFracs()
    summary = {
        "variant": variant,
        "residuals": {
            key: hist.data["data"][0].get(key)
            for key in ("R", "wR", "Rb", "wRb", "wRmin", "Durbin-Watson")
        },
        "fractions": fractions,
        "instrument": {
            key: inst[key] for key in ("U", "V", "W", "X", "Y", "SH/L")
        },
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][hist.name]["Scale"],
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in project.phases()
        },
        "frozen": project.get_Frozen(),
    }
    Path(".tmp/profile_variants", f"{variant}.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps(summary, sort_keys=True))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "variant",
        choices=("lorentzian", "gaussian", "fixed_half", "refined_mix"),
    )
    run(parser.parse_args().variant)


if __name__ == "__main__":
    main()
