#!/usr/bin/env python3
"""Build, refine, and export the submitted three-phase GSAS-II model."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent.parent
COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)

BACKGROUND = [
    1459.100071861947,
    -1210.564349188578,
    645.52712252385,
    -225.07595334984248,
    71.10848540505333,
    -16.41163836087016,
    11.382069222609514,
    -0.048045827063413406,
    1.8813960488692574,
    14.598281952837876,
    -21.373347922933018,
    16.890945554593007,
]

PHASE_SPECS = [
    {
        "name": "PbWO4_stolzite",
        "display_name": "stolzite (scheelite-type lead tungstate)",
        "formula": "PbWO4",
        "space_group": "I 41/a",
        "space_group_number": 88,
        "cod_id": "9009811",
        "cif": "PbWO4_stolzite.cif",
        "scale": 7.0487,
        "size": 0.04563,
    },
    {
        "name": "WO3_monoclinic",
        "display_name": "monoclinic tungsten trioxide",
        "formula": "WO3",
        "space_group": "P 21/n",
        "space_group_number": 14,
        "cod_id": "1528915",
        "cif": "WO3_monoclinic.cif",
        "scale": 2.5025,
        "size": 0.1732,
    },
    {
        "name": "Pb3O4_minium",
        "display_name": "minium (red lead)",
        "formula": "Pb3O4",
        "space_group": "P 42/mbc",
        "space_group_number": 135,
        "cod_id": "1537983",
        "cif": "Pb3O4_minium.cif",
        "scale": 1.2848,
        "size": 0.02934,
    },
]


def cod_cif(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def set_fixed_uiso(phase: G2sc.G2Phase) -> None:
    """Apply plausible, fixed room-temperature isotropic displacement values."""
    for atom in phase.atoms():
        if atom.element == "O":
            atom.uiso = 0.012 if phase.name == "WO3_monoclinic" else 0.015
        elif atom.element == "W":
            atom.uiso = 0.005
        elif atom.element == "Pb":
            atom.uiso = 0.010
        atom.refinement_flags = " "


def refine(project: G2sc.G2Project, label: str, log: list[dict]) -> None:
    project.refine(makeBack=False)
    hist = project.histogram(0)
    residuals = hist.data["data"][0]
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    log.append(
        {
            "stage": label,
            "Rp_percent": float(residuals.get("R", math.nan)),
            "Rwp_percent": float(residuals.get("wR", math.nan)),
            "GOF": float(rvals.get("GOF", math.nan)),
            "converged": bool(rvals.get("converged", False)),
            "frozen": list(project.get_Frozen()),
        }
    )


def build_project() -> tuple[G2sc.G2Project, list[G2sc.G2Phase], list[dict]]:
    final_gpx = ROOT / "final.gpx"
    project = G2sc.G2Project(newgpx=str(final_gpx))
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5

    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / ".tmp/cu_ka.instprm"),
        fmthint="comma",
    )
    x = hist.data["data"][1][0]
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [-728.49, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": len(BACKGROUND),
                "coeffs": BACKGROUND,
            }
        }
    )

    inst = hist.data["Instrument Parameters"][0]
    # Keep the uncalibrated instrumental U and V terms fixed; W is refined below.
    for key, value in {"U": 2.0, "V": -2.0, "W": 12.29}.items():
        inst[key][1] = value
        inst[key][2] = False
    inst["Polariz."][1] = 0.9453
    inst["Polariz."][2] = False

    phases: list[G2sc.G2Phase] = []
    for spec in PHASE_SPECS:
        phase = project.add_phase(
            str(cod_cif(spec["cod_id"])),
            phasename=spec["name"],
            histograms=[hist],
            fmthint="CIF",
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [spec["scale"], True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [spec["size"], 1.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2][0] = False
        set_fixed_uiso(phase)
        phases.append(phase)

    stages: list[dict] = []
    refine(project, "scales_and_background", stages)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "cells_and_sample_shift", stages)

    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )
        project.set_Controls("parmMin", 0.003, f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 10.0, f"{phase.id}:0:Size;i")
    refine(project, "phase_broadening", stages)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Controls("parmMin", 0.0, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    refine(project, "effective_polarization", stages)

    hist.set_refinements({"Instrument Parameters": ["W"]})
    project.set_Controls("parmMin", 0.0, ":0:W")
    project.set_Controls("parmMax", 100.0, ":0:W")
    refine(project, "instrument_W", stages)
    refine(project, "final_joint_1", stages)
    refine(project, "final_joint_2", stages)
    project.save(str(final_gpx))
    return project, phases, stages


def export_outputs(
    project: G2sc.G2Project, phases: list[G2sc.G2Phase], stages: list[dict]
) -> dict:
    hist = project.histogram(0)
    for phase, spec in zip(phases, PHASE_SPECS, strict=True):
        phase.export_CIF(str(ROOT / spec["cif"]))

    arrays = hist.data["data"][1]
    x, observed, weights, calculated, background, difference = arrays
    if not np.allclose(
        np.asarray(difference),
        np.asarray(observed) - np.asarray(calculated),
        atol=1.0e-7,
        rtol=1.0e-10,
    ):
        raise RuntimeError("GSAS-II difference profile is not observed minus calculated")
    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "background_intensity",
                "difference_intensity",
            ]
        )
        for row in zip(x, observed, calculated, background, difference, strict=True):
            writer.writerow([f"{float(value):.10g}" for value in row])

    fractions = hist.ComputeMassFracs()
    fraction_sum = sum(value[0] for value in fractions.values())
    if not math.isclose(fraction_sum, 1.0, abs_tol=1.0e-8):
        raise RuntimeError(f"Mass fractions do not sum to unity: {fraction_sum}")

    residuals = hist.data["data"][0]
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    phase_results = []
    for phase, spec in zip(phases, PHASE_SPECS, strict=True):
        fraction, formal_esd = fractions[phase.name]
        phase_results.append(
            {
                "name": spec["display_name"],
                "formula": spec["formula"],
                "space_group": spec["space_group"],
                "space_group_number": spec["space_group_number"],
                "cif_path": spec["cif"],
                "reference_structure": f"COD {spec['cod_id']}",
                "weight_fraction": float(fraction),
                "weight_percent": float(100.0 * fraction),
                "formal_weight_fraction_esd": float(formal_esd),
                "estimated_absolute_weight_fraction_uncertainty": 0.02,
                "cell": {key: float(value) for key, value in phase.get_cell().items()},
            }
        )

    result = {
        "method": "three-phase Rietveld refinement with GSAS-II",
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "fractions_normalized_over": "modeled crystalline phases",
        "phases": phase_results,
        "fit_statistics": {
            "Rp_percent": float(residuals["R"]),
            "Rwp_percent": float(residuals["wR"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_variables": int(rvals["Nvars"]),
            "converged": bool(rvals["converged"]),
            "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
        },
        "weighting": {
            "scheme": "w = 1/I",
            "interpretation": "Poisson counting proxy because no uncertainties were supplied",
        },
        "uncertainty_note": (
            "Formal covariance errors are conditional on the selected models and weighting. "
            "An estimated +/-0.02 absolute systematic uncertainty is assigned to each "
            "normalized crystalline weight fraction."
        ),
    }
    with (ROOT / "result.json").open("w") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")

    summary = {
        "stages": stages,
        "result": result,
        "instrument": {
            key: hist.data["Instrument Parameters"][0][key]
            for key in ("Lam1", "Lam2", "I(L2)/I(L1)", "Polariz.", "U", "V", "W")
        },
        "sample": {
            key: hist.data["Sample Parameters"][key] for key in ("Scale", "Shift")
        },
        "sizes_micrometers": {
            phase.name: float(phase.data["Histograms"][hist.name]["Size"][1][0])
            for phase in phases
        },
        "frozen_parameters": list(project.get_Frozen()),
        "profile_points": len(x),
        "weight_check": {
            "minimum": float(np.min(weights)),
            "maximum": float(np.max(weights)),
        },
    }
    with (ROOT / ".tmp/final_summary.json").open("w") as handle:
        json.dump(summary, handle, indent=2)
        handle.write("\n")
    return summary


def main() -> None:
    project, phases, stages = build_project()
    summary = export_outputs(project, phases, stages)
    if summary["frozen_parameters"]:
        raise RuntimeError(f"Final refinement has frozen parameters: {summary['frozen_parameters']}")
    if not summary["result"]["fit_statistics"]["converged"]:
        raise RuntimeError("Final refinement did not converge")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
