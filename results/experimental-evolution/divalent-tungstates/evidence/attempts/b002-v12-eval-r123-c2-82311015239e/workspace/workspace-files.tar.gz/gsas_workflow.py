#!/usr/bin/env python3
"""Reproducible GSAS-II helpers for the Ba--W--O powder refinement."""

from __future__ import annotations

import argparse
import copy
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
INPUT_CSV = ROOT / "inputs" / "pattern.csv"
DATA_XYE = WORK / "pattern.xye"
INSTPRM = WORK / "cu_kalpha.instprm"
CIF_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


COD_IDS = {
    "BaWO4": "1527204",
    "WO3_hex": "1004057",
    "WO3_tet_P4ncc": "1521532",
    "WO3_tet_P4nmm": "1521533",
    "WO3_monoclinic_1528915": "1528915",
    "WO3_monoclinic_1563541": "1563541",
    "WO3_monoclinic_2311041": "2311041",
    "WO3_triclinic": "2106293",
    "WO3_orthorhombic": "2107312",
    "BaCO3_9010928": "9010928",
    "BaCO3_1011149": "1011149",
    "Ba3W2O9": "1533878",
    "Ba3WO6": "1534803",
    "Ba0.9W6O18": "1001273",
}

CUSTOM_SOURCES = {
    "BaCO3_1011149_std": WORK / "BaCO3_1011149_standardized.cif",
}


def cod_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def candidate_path(candidate: str) -> Path:
    if candidate in CUSTOM_SOURCES:
        return CUSTOM_SOURCES[candidate]
    return cod_path(COD_IDS[candidate])


def prepare_support_files() -> None:
    WORK.mkdir(exist_ok=True)
    arr = np.loadtxt(INPUT_CSV, delimiter=",", skiprows=1)
    # The measurement has no supplied uncertainties. Poisson counting
    # uncertainties are the least-assumptive working weights for raw counts.
    sigma = np.sqrt(np.maximum(arr[:, 1], 1.0))
    np.savetxt(DATA_XYE, np.column_stack((arr, sigma)), fmt="%.8g")
    INSTPRM.write_text(
        "#GSAS-II instrument parameter file for measured Cu K-alpha data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.5;"
        "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:0.0;V:0.0;W:30.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )


def set_neutral_hap(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData) -> None:
    """Make all optional phase profile/intensity terms physically neutral."""
    hap = phase.getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 100.0  # micrometres; effectively neutral, and >= 10 um
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"][1] = False
    for term in hap["Babinet"].values():
        term[0] = 0.0
        term[1] = False


def set_neutral_histogram(hist: G2sc.G2PwdrData) -> None:
    sample = hist.data["Sample Parameters"]
    # Keep the redundant histogram-wide scale fixed. Quantitative phase scales
    # are the only active intensity multipliers.
    sample["Scale"] = [1.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    # One angular correction only: reflection-geometry specimen shift.
    sample["Shift"] = [-450.0, False]
    inst = hist.InstrumentParameters
    for key in ("Zero", "V", "Y", "Z", "SH/L", "Polariz.", "I(L2)/I(L1)"):
        inst[key][2] = False


def make_project(path: Path, phases: list[tuple[str, Path]]) -> G2sc.G2Project:
    prepare_support_files()
    path.parent.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(newgpx=str(path))
    hist = gpx.add_powder_histogram(
        str(DATA_XYE), str(INSTPRM), fmthint="xye"
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    set_neutral_histogram(hist)
    for name, cif in phases:
        phase = gpx.add_phase(
            str(cif), phasename=name, histograms=[hist], fmthint="CIF"
        )
        set_neutral_hap(phase, hist)
    gpx.set_Controls("cycles", 12)
    gpx.save()
    return gpx


def refinement_value(gpx: G2sc.G2Project, variable: str) -> tuple[float, float | None]:
    cov = gpx.data.get("Covariance", {}).get("data", {})
    vary = cov.get("varyList", [])
    vals = cov.get("variables", [])
    sig = cov.get("sig", [])
    if variable not in vary:
        return math.nan, None
    i = vary.index(variable)
    return float(vals[i]), (float(sig[i]) if i < len(sig) else None)


def summary(gpx: G2sc.G2Project) -> dict:
    hist = gpx.histogram(0)
    out: dict = {
        "project": str(Path(gpx.filename).resolve()),
        "residuals": hist.residuals,
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if isinstance(value, list) and len(value) >= 2
        },
        "sample": {
            key: (value[0] if isinstance(value, list) else value)
            for key, value in hist.data["Sample Parameters"].items()
        },
        "phases": {},
        "vary_list": [str(v) for v in (gpx.get_VaryList() or [])],
    }
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "density": phase.density,
            "composition": phase.composition,
            "scale": hap["Scale"][0],
            "scale_refined": hap["Scale"][1],
            "size": hap["Size"],
            "microstrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    try:
        out["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        out["mass_fractions_error"] = str(exc)
    return out


def print_summary(gpx: G2sc.G2Project) -> None:
    print(json.dumps(summary(gpx), indent=2, default=float))


def refine_once(gpx: G2sc.G2Project, label: str) -> None:
    print(f"\n===== refinement: {label} =====")
    gpx.refine()
    gpx.save()
    print_summary(gpx)


def baseline(output: Path) -> None:
    gpx = make_project(output, [("BaWO4", cod_path(COD_IDS["BaWO4"]))])
    hist = gpx.histogram(0)
    phase = gpx.phase("BaWO4")

    # Smooth baseline, phase scale and sensible starting specimen height.
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 8}}
    )
    phase.HAPvalue("Scale", 1.0e-4)
    phase.set_HAP_refinements({"Scale": True}, [hist])
    refine_once(gpx, "background + scale")

    # Open the full symmetry-constrained cell together with the one angular term.
    phase.set_refinements({"Cell": True})
    hist.data["Sample Parameters"]["Shift"][1] = True
    refine_once(gpx, "cell + specimen shift")

    # Build the common, nonnegative low-dimensional instrument profile.
    gpx.set_Controls("parmMin", 0.0, ":0:W")
    hist.set_refinements({"Instrument Parameters": ["W"]})
    refine_once(gpx, "W")

    # A separate U trial from this checkpoint refined below its nonnegative
    # physical bound. That comparison is invalid, so U is retained at its
    # neutral value and all values from that trial are discarded.
    gpx.set_Controls("parmMin", 0.0, ":0:X")
    hist.set_refinements({"Instrument Parameters": ["X"]})
    refine_once(gpx, "W + X (U trial rejected at bound)")

    # Replay the complete common baseline once more.
    refine_once(gpx, "common-baseline replay")
    gpx.save(output)


def show(project: Path) -> None:
    print_summary(G2sc.G2Project(str(project)))


def replay(base: Path, output: Path, label: str = "full-model replay") -> None:
    """Reopen a complete saved model and reconverge without changing flags."""
    gpx = G2sc.G2Project(str(base), newgpx=str(output))
    refine_once(gpx, label)
    refine_once(gpx, f"{label} repeat")
    gpx.save(output)


def candidate_trial(base: Path, candidate: str, output: Path) -> None:
    """Add one source to the same saved neutral checkpoint and reconverge."""
    if candidate not in COD_IDS and candidate not in CUSTOM_SOURCES:
        raise KeyError(f"Unknown candidate {candidate!r}")
    output.parent.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(str(base), newgpx=str(output))
    hist = gpx.histogram(0)
    phase = gpx.add_phase(
        str(candidate_path(candidate)),
        phasename=candidate,
        histograms=[hist],
        fmthint="CIF",
    )
    set_neutral_hap(phase, hist)
    phase.HAPvalue("Scale", 0.25)
    phase.set_HAP_refinements({"Scale": True}, [hist])
    phase.set_refinements({"Cell": False})
    gpx.set_Controls("cycles", 12)
    refine_once(gpx, f"{candidate}: neutral source, scale before cell")
    scale = phase.HAPvalue("Scale", targethistlist=[hist])
    if scale > 1.0e-6:
        phase.set_refinements({"Cell": True})
        refine_once(gpx, f"{candidate}: symmetry-compatible cell")
        refine_once(gpx, f"{candidate}: source replay")
    else:
        print(f"{candidate}: scale collapsed ({scale:g}); cell not opened")
    gpx.save(output)


def watch_trial(base: Path, candidate: str, output: Path) -> None:
    """Rollback-safe final watch-list challenge, with scale before cell."""
    if candidate not in COD_IDS and candidate not in CUSTOM_SOURCES:
        raise KeyError(f"Unknown candidate {candidate!r}")

    def add_candidate(project: G2sc.G2Project, start_scale: float) -> G2sc.G2Phase:
        trial_hist = project.histogram(0)
        trial_phase = project.add_phase(
            str(candidate_path(candidate)), phasename=candidate,
            histograms=[trial_hist], fmthint="CIF"
        )
        set_neutral_hap(trial_phase, trial_hist)
        trial_phase.HAPvalue("Scale", start_scale)
        trial_phase.set_HAP_refinements({"Scale": True}, [trial_hist])
        trial_phase.set_refinements({"Cell": False})
        project.set_Controls("parmMin", 0.0, f"{trial_phase.id}:0:Scale")
        return trial_phase

    def freeze_existing(project: G2sc.G2Project, active: G2sc.G2Phase) -> None:
        trial_hist = project.histogram(0)
        trial_hist.data["Background"][0][1] = False
        for value in trial_hist.InstrumentParameters.values():
            if isinstance(value, list) and len(value) >= 3:
                value[2] = False
        for value in trial_hist.data["Sample Parameters"].values():
            if (isinstance(value, list) and len(value) == 2
                    and isinstance(value[1], bool)):
                value[1] = False
        for phase in project.phases():
            phase.set_refinements({"Cell": False})
            hap = phase.getHAPvalues(trial_hist)
            hap["Scale"][1] = phase.name == active.name
            hap["Pref.Ori."][2] = False
            hap["Size"][2] = [False for _ in hap["Size"][2]]
            hap["Size"][5] = [False for _ in hap["Size"][5]]
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
            hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]

    def trial_collapsed(project: G2sc.G2Project, phase: G2sc.G2Phase) -> bool:
        scale = float(phase.HAPvalue("Scale", targethistlist=[project.histogram(0)]))
        frozen = project.data["Controls"]["data"].get(
            "parmFrozen", {"FrozenList": []}
        ).get("FrozenList", [])
        print(f"{candidate}: staged scale={scale:.8g}; frozen={list(map(str, frozen))}")
        return scale <= 1.0e-8 or any("Scale" in str(item) for item in frozen)

    # First stage: candidate scale alone, all accepted model values fixed.
    gpx = G2sc.G2Project(str(base), newgpx=str(output))
    phase = add_candidate(gpx, 0.05)
    freeze_existing(gpx, phase)
    refine_once(gpx, f"{candidate}: final watch scale-only")
    if trial_collapsed(gpx, phase):
        print(f"{candidate}: collapsed/bound scale; discard trial and reload checkpoint")
        clean = G2sc.G2Project(str(base), newgpx=str(output))
        clean.save(output)
        return
    staged_scale = float(phase.HAPvalue("Scale", targethistlist=[gpx.histogram(0)]))

    # Reload every saved value and flag, then carry only the positive scale.
    gpx = G2sc.G2Project(str(base), newgpx=str(output))
    phase = add_candidate(gpx, staged_scale)
    refine_once(gpx, f"{candidate}: reopen complete model at fixed candidate cell")
    refine_once(gpx, f"{candidate}: positive-scale replay")
    if trial_collapsed(gpx, phase):
        print(f"{candidate}: scale unstable after reopen; discard and reload checkpoint")
        clean = G2sc.G2Project(str(base), newgpx=str(output))
        clean.save(output)
        return
    phase.set_refinements({"Cell": True})
    refine_once(gpx, f"{candidate}: cell after stable scale")
    refine_once(gpx, f"{candidate}: final watch replay")
    if trial_collapsed(gpx, phase):
        print(f"{candidate}: unstable after cell; discard and reload checkpoint")
        clean = G2sc.G2Project(str(base), newgpx=str(output))
        clean.save(output)
        return
    gpx.save(output)


def profile_trial(base: Path, phase_name: str, mode: str, output: Path) -> None:
    """Compare isotropic size/strain terms from one complete checkpoint."""
    gpx = G2sc.G2Project(str(base), newgpx=str(output))
    hist = gpx.histogram(0)
    phase = gpx.phase(phase_name)
    if mode in ("size", "combined"):
        phase.setSampleProfile(hist, "size", "isotropic", 5.0, LGmix=1.0)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
    if mode in ("strain", "combined"):
        phase.setSampleProfile(hist, "microstrain", "isotropic", 500.0, LGmix=1.0)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
    refine_once(gpx, f"{phase_name}: isotropic {mode}")
    refine_once(gpx, f"{phase_name}: isotropic {mode} replay")
    gpx.save(output)


def neutral_width_checkpoint(base: Path, phase_name: str, output: Path) -> None:
    """Reset one phase's size/strain terms and replay the common model."""
    gpx = G2sc.G2Project(str(base), newgpx=str(output))
    hist = gpx.histogram(0)
    phase = gpx.phase(phase_name)
    phase.setSampleProfile(hist, "size", "isotropic", 100.0, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap = phase.getHAPvalues(hist)
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    refine_once(gpx, f"{phase_name}: neutral width checkpoint")
    refine_once(gpx, f"{phase_name}: neutral width replay")
    gpx.save(output)


def adopt_strains(base: Path, output: Path) -> None:
    """Combine the replay-stable positive isotropic strain terms."""
    gpx = G2sc.G2Project(str(base), newgpx=str(output))
    hist = gpx.histogram(0)
    starts = {"Ba3W2O9": 780.0, "WO3_monoclinic_2311041": 5500.0}
    for name, value in starts.items():
        phase = gpx.phase(name)
        phase.setSampleProfile(hist, "microstrain", "isotropic", value, LGmix=1.0)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
        gpx.set_Controls("parmMin", 0.0, f"{phase.id}:0:Mustrain;i")
    refine_once(gpx, "combined positive isotropic strains")
    refine_once(gpx, "combined positive isotropic strains replay")
    gpx.save(output)


def anisotropy_trial(
    base: Path, phase_name: str, axis_text: str, output: Path
) -> None:
    """Test low-dimensional symmetry-compatible uniaxial microstrain."""
    gpx = G2sc.G2Project(str(base), newgpx=str(output))
    hist = gpx.histogram(0)
    phase = gpx.phase(phase_name)
    if len(axis_text) != 3 or not axis_text.isdigit():
        raise ValueError("axis must be three digits, e.g. 001")
    axis = [int(v) for v in axis_text]
    hap = phase.getHAPvalues(hist)
    start = float(hap["Mustrain"][1][0])
    if start <= 0.0:
        start = 300.0
    phase.setSampleProfile(
        hist, "microstrain", "uniaxial", start, start, axis=axis, LGmix=1.0
    )
    phase.set_HAP_refinements(
        {"Mustrain": {"type": "uniaxial", "refine": True, "direction": axis}},
        [hist],
    )
    for suffix in ("i", "a"):
        gpx.set_Controls(
            "parmMin", 0.0, f"{phase.id}:0:Mustrain;{suffix}"
        )
    refine_once(gpx, f"{phase_name}: uniaxial strain {axis_text}")
    refine_once(gpx, f"{phase_name}: uniaxial strain {axis_text} replay")
    gpx.save(output)


def nuisance_trial(base: Path, kind: str, output: Path) -> None:
    """Challenge smooth background and shared reflection-geometry terms."""
    gpx = G2sc.G2Project(str(base), newgpx=str(output))
    hist = gpx.histogram(0)
    if kind.startswith("bkg"):
        order = int(kind[3:])
        hist.set_refinements(
            {"Background": {"type": "chebyschev-1", "refine": True,
                            "no. coeffs": order}}
        )
    elif kind == "polarization":
        hist.InstrumentParameters["Polariz."][1] = 0.5
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
        gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")
    elif kind == "roughness":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.5, True]
        sample["SurfRoughB"] = [0.01, True]
        gpx.set_Controls("parmMin", 0.0, ":0:SurfRoughA")
        gpx.set_Controls("parmMax", 1.0, ":0:SurfRoughA")
        gpx.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
    else:
        raise ValueError(f"unknown nuisance trial {kind!r}")
    refine_once(gpx, kind)
    refine_once(gpx, f"{kind} replay")
    gpx.save(output)


def instrument_trial(base: Path, parameter: str, output: Path) -> None:
    """Challenge one additional nonnegative common profile coefficient."""
    gpx = G2sc.G2Project(str(base), newgpx=str(output))
    hist = gpx.histogram(0)
    if parameter not in ("U", "W", "X"):
        raise ValueError(parameter)
    if float(hist.InstrumentParameters[parameter][1]) <= 0.0:
        hist.InstrumentParameters[parameter][1] = 1.0
    hist.set_refinements({"Instrument Parameters": [parameter]})
    gpx.set_Controls("parmMin", 0.0, f":0:{parameter}")
    refine_once(gpx, f"common profile {parameter}")
    refine_once(gpx, f"common profile {parameter} replay")
    gpx.save(output)


def texture_trial(base: Path, phase_name: str, axis_text: str, output: Path) -> None:
    """Test one low-index March-Dollase axis from a neutral texture state."""
    gpx = G2sc.G2Project(str(base), newgpx=str(output))
    hist = gpx.histogram(0)
    phase = gpx.phase(phase_name)
    if len(axis_text) != 3 or not axis_text.isdigit():
        raise ValueError("axis must be three digits, e.g. 001")
    axis = [int(v) for v in axis_text]
    po = phase.getHAPvalues(hist)["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = axis
    gpx.set_Controls("parmMin", 0.1, f"{phase.id}:0:MD")
    gpx.set_Controls("parmMax", 10.0, f"{phase.id}:0:MD")
    refine_once(gpx, f"{phase_name}: MD {axis_text}")
    refine_once(gpx, f"{phase_name}: MD {axis_text} replay")
    gpx.save(output)


def source_checkpoint(base: Path, output: Path) -> None:
    """Create a source-comparison checkpoint with shared intensity terms neutral."""
    gpx = G2sc.G2Project(str(base), newgpx=str(output))
    hist = gpx.histogram(0)
    # Source ranking must not be decided by a polarization or texture term that
    # was optimized for a different structure-factor model.
    polar = hist.InstrumentParameters["Polariz."]
    polar[1] = 0.5
    polar[2] = False
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    for phase in gpx.phases():
        po = phase.getHAPvalues(hist)["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = False
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    refine_once(gpx, "source checkpoint: neutral polarization and texture")
    refine_once(gpx, "source checkpoint replay")
    gpx.save(output)


def atom_trial(
    base: Path, phase_name: str, atom_label: str, output: Path
) -> None:
    """Test symmetry-constrained coordinate refinement for one unique atom."""
    gpx = G2sc.G2Project(str(base), newgpx=str(output))
    phase = gpx.phase(phase_name)
    phase.set_refinements({"Atoms": {atom_label: "X"}})
    refine_once(gpx, f"{phase_name}: coordinates for {atom_label}")
    refine_once(gpx, f"{phase_name}: coordinates for {atom_label} replay")
    gpx.save(output)


def cross_seed(target: Path, donor: Path, output: Path) -> None:
    """Cross-seed source-independent nuisance values, then reconverge."""
    gpx = G2sc.G2Project(str(target), newgpx=str(output))
    seed = G2sc.G2Project(str(donor))
    hist = gpx.histogram(0)
    seed_hist = seed.histogram(0)
    hist.data["Background"] = copy.deepcopy(seed_hist.data["Background"])
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        hist.InstrumentParameters[key] = copy.deepcopy(
            seed_hist.InstrumentParameters[key]
        )
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        hist.data["Sample Parameters"][key] = copy.deepcopy(
            seed_hist.data["Sample Parameters"][key]
        )
    # Transfer broadening for phases common to both source models. The BaWO4
    # HAP stays with the target so texture is challenged independently.
    for name in ("Ba3W2O9", "WO3_monoclinic_2311041"):
        target_hap = gpx.phase(name).getHAPvalues(hist)
        donor_hap = seed.phase(name).getHAPvalues(seed_hist)
        for key in ("Size", "Mustrain", "Pref.Ori."):
            target_hap[key] = copy.deepcopy(donor_hap[key])
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    refine_once(gpx, "cross-seeded shared nuisance values")
    refine_once(gpx, "cross-seeded source replay")
    gpx.save(output)


def replace_bawo4(base: Path, model: str, output: Path) -> None:
    """Replace, never coexist, one phase source with a competing record."""
    models = {
        "bamo": ("BaWO4", WORK / "BaWO4_from_BaMoO4_2300459.cif", True),
        "srwo": ("BaWO4", WORK / "BaWO4_from_SrWO4_1546036.cif", True),
        "euwo": ("BaWO4", WORK / "BaWO4_from_EuWO4_1561850.cif", True),
        "wo3alt": (
            "WO3_monoclinic_2311041",
            cod_path(COD_IDS["WO3_monoclinic_1528915"]),
            False,
        ),
    }
    target_name, source_model, neutral_hap = models[model]
    gpx = G2sc.G2Project(str(base), newgpx=str(output))
    hist = gpx.histogram(0)
    old = gpx.phase(target_name)
    old_scale = old.HAPvalue("Scale", targethistlist=[hist])
    # Import into a temporary, unlinked phase and transplant only structural
    # data. This preserves the original phase ID, all other phase IDs, and the
    # saved common-profile parameter bounds.
    temp = gpx.add_phase(
        str(source_model), phasename=f"{target_name}_adapted",
        histograms=[], fmthint="CIF"
    )
    keep_hist = old.data["Histograms"]
    keep_pid = old.data["pId"]
    keep_ranid = old.data["ranId"]
    replacement = copy.deepcopy(temp.data)
    replacement["Histograms"] = keep_hist
    replacement["pId"] = keep_pid
    replacement["ranId"] = keep_ranid
    replacement["General"]["Name"] = target_name
    gpx.data["Phases"][target_name] = replacement
    del gpx.data["Phases"][temp.name]
    for names in gpx.names:
        if names and names[0] == "Phases" and temp.name in names:
            names.remove(temp.name)
    hist.data["Reflection Lists"].pop(target_name, None)
    gpx.update_ids()
    phase = gpx.phase(target_name)
    if neutral_hap:
        set_neutral_hap(phase, hist)
    phase.HAPvalue("Scale", old_scale)
    phase.set_HAP_refinements({"Scale": True}, [hist])
    phase.set_refinements({"Cell": False})

    # Preserve a complete checkpoint with all accepted values and flags. The
    # first fit is deliberately scale-only; afterwards the whole checkpoint
    # is restored and only that fitted scale is carried into the cell loop.
    full_data = copy.deepcopy(gpx.data)
    full_names = copy.deepcopy(gpx.names)

    def freeze_all(project: G2sc.G2Project) -> None:
        frozen_hist = project.histogram(0)
        frozen_hist.data["Background"][0][1] = False
        for value in frozen_hist.InstrumentParameters.values():
            if isinstance(value, list) and len(value) >= 3:
                value[2] = False
        for value in frozen_hist.data["Sample Parameters"].values():
            if (isinstance(value, list) and len(value) == 2
                    and isinstance(value[1], bool)):
                value[1] = False
        for other in project.phases():
            other.set_refinements({"Cell": False})
            hap = other.getHAPvalues(frozen_hist)
            hap["Scale"][1] = False
            hap["Pref.Ori."][2] = False
            hap["Size"][2] = [False for _ in hap["Size"][2]]
            hap["Size"][5] = [False for _ in hap["Size"][5]]
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
            hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
            hap["Extinction"][1] = False
            for term in hap["Babinet"].values():
                term[1] = False

    def restore_checkpoint(project: G2sc.G2Project) -> None:
        project.data = copy.deepcopy(full_data)
        project.names = copy.deepcopy(full_names)
        project.filename = str(output.resolve())
        project.data["Controls"]["data"]["LastSavedAs"] = project.filename
        project.update_ids()

    freeze_all(gpx)
    phase = gpx.phase(target_name)
    phase.set_HAP_refinements({"Scale": True}, [gpx.histogram(0)])
    refine_once(gpx, f"source {model}: scale before cell")

    scale_only = phase.HAPvalue("Scale", targethistlist=[hist])
    restore_checkpoint(gpx)
    hist = gpx.histogram(0)
    phase = gpx.phase(target_name)
    phase.HAPvalue("Scale", scale_only)
    freeze_all(gpx)
    phase.set_HAP_refinements({"Scale": True}, [hist])
    phase.set_refinements({"Cell": True})
    refine_once(gpx, f"source {model}: scale + cell, nuisances fixed")

    scale_cell = phase.HAPvalue("Scale", targethistlist=[hist])
    refined_cell = copy.deepcopy(phase.data["General"]["Cell"])
    restore_checkpoint(gpx)
    hist = gpx.histogram(0)
    phase = gpx.phase(target_name)
    phase.HAPvalue("Scale", scale_cell)
    phase.data["General"]["Cell"] = refined_cell
    phase.set_refinements({"Cell": True})
    refine_once(gpx, f"source {model}: reopen common loop")
    refine_once(gpx, f"source {model}: source replay")
    gpx.save(output)


def finalize_project(base: Path, output: Path) -> None:
    """Prune unsupported terms, replay the complete measured range, and save."""
    gpx = G2sc.G2Project(str(base), newgpx=str(output))
    hist = gpx.histogram(0)
    x = np.asarray(hist.getdata("x"), dtype=float)
    hist.Limits("lower", float(np.min(x)))
    hist.Limits("upper", float(np.max(x)))

    # Freeze a single, explicit common profile and geometry model.
    inst = hist.InstrumentParameters
    for key in inst:
        if isinstance(inst[key], list) and len(inst[key]) >= 3:
            inst[key][2] = key in ("W", "X")
    for key in ("U", "V", "Y", "Z"):
        inst[key][1] = 0.0
        inst[key][2] = False
    inst["Polariz."][1] = 0.5
    inst["Polariz."][2] = False
    inst["SH/L"][1] = 0.002
    inst["SH/L"][2] = False
    inst["Zero"][1] = 0.0
    inst["Zero"][2] = False
    inst["I(L2)/I(L1)"][1] = 0.5
    inst["I(L2)/I(L1)"][2] = False
    gpx.set_Controls("parmMin", 0.0, ":0:W")
    gpx.set_Controls("parmMin", 0.0, ":0:X")

    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"][1] = True
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key] = [0.0, False]
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True,
                        "no. coeffs": 10}}
    )

    for phase in gpx.phases():
        phase.set_refinements({"Cell": True, "Atoms": {"all": " "}})
        phase.set_HAP_refinements({"Scale": True}, [hist])
        hap = phase.getHAPvalues(hist)
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False
        for term in hap["Babinet"].values():
            term[0] = 0.0
            term[1] = False
        # Retained widths were established from independent neutral trials.
        if phase.name == "BaWO4":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        elif phase.name == "Ba3W2O9":
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][3] = [0, 0, 1]
            hap["Mustrain"][2] = [True, True, False]
            for suffix in ("i", "a"):
                gpx.set_Controls(
                    "parmMin", 0.0, f"{phase.id}:0:Mustrain;{suffix}"
                )
        else:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][2] = [True, False, False]
            gpx.set_Controls(
                "parmMin", 0.0, f"{phase.id}:0:Mustrain;i"
            )

    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 12)
    refine_once(gpx, "full measured range, pruned model")
    refine_once(gpx, "full measured range replay")
    gpx.save(output)

    # Reopen the serialized project and replay it, so the submitted GPX itself
    # is the object that generated all final values and profiles.
    gpx = G2sc.G2Project(str(output))
    refine_once(gpx, "reopened final project")
    refine_once(gpx, "reopened final project replay")
    gpx.save(output)


def export_outputs(project: Path) -> None:
    """Export CIFs, profile CSV and machine-readable phase/fit summary."""
    gpx = G2sc.G2Project(str(project))
    hist = gpx.histogram(0)
    names = {
        "BaWO4": ("BaWO4", "BaWO4.cif", "BaWO4"),
        "Ba3W2O9": ("Ba3W2O9", "Ba3W2O9.cif", "Ba3W2O9"),
        "WO3_monoclinic_2311041": ("WO3", "WO3.cif", "WO3"),
        "BaCO3_9010928": ("BaCO3", "BaCO3.cif", "BaCO3"),
    }
    raw_fracs = hist.ComputeMassFracs()
    total = sum(float(value[0]) for value in raw_fracs.values())
    phases_out = []
    for phase in gpx.phases():
        display, cif_name, formula = names[phase.name]
        phase.export_CIF(str(ROOT / cif_name))
        value, esd = raw_fracs[phase.name]
        phases_out.append({
            "name": display,
            "formula": formula,
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "cif_path": cif_name,
            "weight_fraction": float(value) / total,
            "weight_fraction_esd": float(esd) / total,
        })

    x = np.asarray(hist.getdata("x"), dtype=float)
    yobs = np.asarray(hist.getdata("yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("ycalc"), dtype=float)
    diff = yobs - ycalc
    np.savetxt(
        ROOT / "fit.csv", np.column_stack((x, yobs, ycalc, diff)),
        delimiter=",", comments="",
        header="two_theta_deg,observed_counts,calculated_counts,difference_counts",
        fmt="%.15g",
    )

    residuals = hist.residuals
    rwp = float(residuals["wR"])
    rexp = float(residuals["wRmin"])
    result = {
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "phases": phases_out,
        "fit_statistics": {
            "r_wp_percent": rwp,
            "r_p_percent": float(residuals["R"]),
            "r_exp_percent": rexp,
            "goodness_of_fit": rwp / rexp,
            "reduced_chi_squared": (rwp / rexp) ** 2,
            "n_profile_points": int(len(x)),
            "n_refined_parameters": int(len(gpx.get_VaryList() or [])),
            "two_theta_min_deg": float(np.min(x)),
            "two_theta_max_deg": float(np.max(x)),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("baseline")
    p.add_argument("output", type=Path)
    p = sub.add_parser("show")
    p.add_argument("project", type=Path)
    p = sub.add_parser("replay")
    p.add_argument("base", type=Path)
    p.add_argument("output", type=Path)
    p = sub.add_parser("finalize")
    p.add_argument("base", type=Path)
    p.add_argument("output", type=Path)
    p = sub.add_parser("export")
    p.add_argument("project", type=Path)
    p = sub.add_parser("candidate")
    p.add_argument("base", type=Path)
    p.add_argument("candidate", choices=sorted(set(COD_IDS) | set(CUSTOM_SOURCES)))
    p.add_argument("output", type=Path)
    p = sub.add_parser("watch")
    p.add_argument("base", type=Path)
    p.add_argument("candidate", choices=sorted(set(COD_IDS) | set(CUSTOM_SOURCES)))
    p.add_argument("output", type=Path)
    p = sub.add_parser("profile")
    p.add_argument("base", type=Path)
    p.add_argument("phase")
    p.add_argument("mode", choices=["size", "strain", "combined"])
    p.add_argument("output", type=Path)
    p = sub.add_parser("neutral-width")
    p.add_argument("base", type=Path)
    p.add_argument("phase")
    p.add_argument("output", type=Path)
    p = sub.add_parser("adopt-strains")
    p.add_argument("base", type=Path)
    p.add_argument("output", type=Path)
    p = sub.add_parser("anisotropy")
    p.add_argument("base", type=Path)
    p.add_argument("phase")
    p.add_argument("axis")
    p.add_argument("output", type=Path)
    p = sub.add_parser("nuisance")
    p.add_argument("base", type=Path)
    p.add_argument("kind", choices=["bkg4", "bkg6", "bkg8", "bkg10", "bkg12",
                                    "polarization", "roughness"])
    p.add_argument("output", type=Path)
    p = sub.add_parser("instrument")
    p.add_argument("base", type=Path)
    p.add_argument("parameter", choices=["U", "W", "X"])
    p.add_argument("output", type=Path)
    p = sub.add_parser("texture")
    p.add_argument("base", type=Path)
    p.add_argument("phase")
    p.add_argument("axis")
    p.add_argument("output", type=Path)
    p = sub.add_parser("source-checkpoint")
    p.add_argument("base", type=Path)
    p.add_argument("output", type=Path)
    p = sub.add_parser("atom")
    p.add_argument("base", type=Path)
    p.add_argument("phase")
    p.add_argument("atom_label")
    p.add_argument("output", type=Path)
    p = sub.add_parser("cross-seed")
    p.add_argument("target", type=Path)
    p.add_argument("donor", type=Path)
    p.add_argument("output", type=Path)
    p = sub.add_parser("replace-bawo4")
    p.add_argument("base", type=Path)
    p.add_argument("model", choices=["bamo", "srwo", "euwo", "wo3alt"])
    p.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.command == "baseline":
        baseline(args.output)
    elif args.command == "show":
        show(args.project)
    elif args.command == "replay":
        replay(args.base, args.output)
    elif args.command == "finalize":
        finalize_project(args.base, args.output)
    elif args.command == "export":
        export_outputs(args.project)
    elif args.command == "candidate":
        candidate_trial(args.base, args.candidate, args.output)
    elif args.command == "watch":
        watch_trial(args.base, args.candidate, args.output)
    elif args.command == "profile":
        profile_trial(args.base, args.phase, args.mode, args.output)
    elif args.command == "neutral-width":
        neutral_width_checkpoint(args.base, args.phase, args.output)
    elif args.command == "adopt-strains":
        adopt_strains(args.base, args.output)
    elif args.command == "anisotropy":
        anisotropy_trial(args.base, args.phase, args.axis, args.output)
    elif args.command == "nuisance":
        nuisance_trial(args.base, args.kind, args.output)
    elif args.command == "instrument":
        instrument_trial(args.base, args.parameter, args.output)
    elif args.command == "texture":
        texture_trial(args.base, args.phase, args.axis, args.output)
    elif args.command == "source-checkpoint":
        source_checkpoint(args.base, args.output)
    elif args.command == "atom":
        atom_trial(args.base, args.phase, args.atom_label, args.output)
    elif args.command == "cross-seed":
        cross_seed(args.target, args.donor, args.output)
    elif args.command == "replace-bawo4":
        replace_bawo4(args.base, args.model, args.output)


if __name__ == "__main__":
    main()
