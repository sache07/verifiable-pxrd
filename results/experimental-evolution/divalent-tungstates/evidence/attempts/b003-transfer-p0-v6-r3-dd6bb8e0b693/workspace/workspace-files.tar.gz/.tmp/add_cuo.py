from GSASII import GSASIIscriptable as G2sc

GPX = '.tmp/trial.gpx'
CUO = '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/01/11/1011194.cif'

proj = G2sc.G2Project(GPX)
proj.data['Controls']['data']['max cyc'] = 12
hist = proj.histogram(0)
if not any(p.name == 'tenorite-CuO' for p in proj.phases()):
    cuo = proj.add_phase(CUO, phasename='tenorite-CuO', histograms=[hist], fmthint='CIF')
else:
    cuo = proj.phase('tenorite-CuO')
cuo.HAPvalue('Scale', 0.15)
cuo.set_HAP_refinements({'Scale': True})
hist.data['Sample Parameters']['Scale'] = [1.0, False]
proj.do_refinements([{}])
cuo.set_refinements({'Cell': True})
proj.do_refinements([{}])
proj.save()

print('residuals', hist.data['data'][0])
print('fractions', hist.ComputeMassFracs())
print('sample', hist.data['Sample Parameters']['Scale'])
print('vary', proj.data['Covariance']['data']['varyList'])
for phase in proj.phases():
    print(phase.name, phase.get_cell(), phase.getHAPvalues(hist.name)['Scale'], phase.getHAPvalues(hist.name)['Pref.Ori.'])
print('instrument', hist.data['Instrument Parameters'][0])
