import csv
import json
import math
import os

import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
BASE = os.path.join(ROOT, '.tmp', 'atoms_cations.gpx')
FINAL = os.path.join(ROOT, 'final.gpx')
FIT = os.path.join(ROOT, 'fit.csv')
CIFS = {
    'gamma-WO3': os.path.join(ROOT, 'phase_1_gamma_WO3.cif'),
    'Cu3WO6': os.path.join(ROOT, 'phase_2_Cu3WO6.cif'),
    'tenorite-CuO': os.path.join(ROOT, 'phase_3_tenorite_CuO.cif'),
}


proj = G2sc.G2Project(BASE, newgpx=FINAL)
proj.data['Controls']['data']['max cyc'] = 20
hist = proj.histogram(0)
x = np.asarray(hist.data['data'][1][0], dtype=float)
hist.data['Limits'][1] = [float(x[0]), float(x[-1])]
hist.data['Sample Parameters']['Scale'] = [1.0, False]

# Re-refine once under the final filename and over every measured point.
proj.do_refinements([{}])
proj.save()

for phase in proj.phases():
    phase.export_CIF(CIFS[phase.name])

x, yobs, weight, ycalc, ybkg, stored_diff = [
    np.asarray(a, dtype=float) for a in hist.data['data'][1]
]
with open(FIT, 'w', newline='') as fp:
    writer = csv.writer(fp)
    writer.writerow([
        'two_theta_deg',
        'observed_intensity_counts',
        'calculated_intensity_counts',
        'difference_observed_minus_calculated_counts',
        'background_intensity_counts',
    ])
    for vals in zip(x, yobs, ycalc, yobs - ycalc, ybkg):
        writer.writerow([f'{v:.8f}' for v in vals])

resid = hist.data['data'][0]
cov = proj.data['Covariance']['data']
fractions = hist.ComputeMassFracs()
summary = {
    'residuals': resid,
    'covariance_Rvals': cov.get('Rvals', {}),
    'mass_fractions': fractions,
    'instrument_parameters': hist.data['Instrument Parameters'][0],
    'sample_parameters': hist.data['Sample Parameters'],
    'limits': hist.data['Limits'],
    'phases': {},
}
for phase in proj.phases():
    hap = phase.getHAPvalues(hist.name)
    phase_info = {
        'space_group': phase.data['General']['SGData']['SpGrp'],
        'cell': phase.get_cell(),
        'scale': hap['Scale'],
        'preferred_orientation': hap['Pref.Ori.'],
        'size': hap['Size'],
        'atoms': [],
    }
    for atom in phase.atoms():
        phase_info['atoms'].append({
            'label': atom.label,
            'element': atom.element,
            'coordinates': atom.coordinates,
            'occupancy': atom.occupancy,
            'uiso': atom.uiso,
            'refinement_flags': atom.refinement_flags,
        })
    refl = np.asarray(hist.data['Reflection Lists'][phase.name]['RefList'])
    if phase.name == 'gamma-WO3':
        phase_info['texture_correction_range'] = [
            float(np.min(refl[:, 12])), float(np.max(refl[:, 12]))
        ]
    summary['phases'][phase.name] = phase_info

print(json.dumps(summary, indent=2, default=lambda o: float(o)))
