from GSASII import GSASIIscriptable as G2sc

proj = G2sc.G2Project('.tmp/trial.gpx')
proj.data['Controls']['data']['max cyc'] = 12
hist = proj.histogram(0)
old_scale = hist.data['Sample Parameters']['Scale'][0]
for phase in proj.phases():
    hap = phase.getHAPvalues(hist.name)
    hap['Scale'][0] *= old_scale
hist.data['Sample Parameters']['Scale'] = [1.0, False]
proj.do_refinements([{}])
proj.save()
print('residuals', hist.data['data'][0])
print('fractions', hist.ComputeMassFracs())
print('sample', hist.data['Sample Parameters'])
print('vary', proj.data['Covariance']['data']['varyList'])
for phase in proj.phases():
    print(phase.name, phase.get_cell(), phase.getHAPvalues(hist.name)['Scale'], phase.getHAPvalues(hist.name)['Pref.Ori.'])
print('instrument', hist.data['Instrument Parameters'][0])
