from GSASII import GSASIIscriptable as G2sc

BASE = '.tmp/atoms_cations.gpx'
CANDS = {
    'triclinic-CuWO4': '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/4/00/08/4000806.cif',
    'cuprite-Cu2O': '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/01/09/1010941.cif',
    'tetragonal-WO3': '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/15/1521532.cif',
}

for name, cif in CANDS.items():
    proj = G2sc.G2Project(BASE, newgpx=f'.tmp/extra_{name}.gpx')
    proj.data['Controls']['data']['max cyc'] = 16
    hist = proj.histogram(0)
    ph = proj.add_phase(cif, phasename=name, histograms=[hist], fmthint='CIF')
    hist.data['Sample Parameters']['Scale'] = [1.0, False]
    ph.HAPvalue('Scale', 0.1)
    ph.set_HAP_refinements({'Scale': True})
    proj.do_refinements([{}])
    proj.save()
    print('\n', name)
    print('R', hist.data['data'][0])
    try: print('fractions', hist.ComputeMassFracs())
    except Exception as e: print('fraction error', e)
    print('new scale', ph.getHAPvalues(hist.name)['Scale'])
