from GSASII import GSASIIscriptable as G2sc

BASE = '.tmp/atoms_cations.gpx'

def run(tag, zero_refine, shift_refine, zero_value, shift_value):
    proj = G2sc.G2Project(BASE, newgpx=f'.tmp/{tag}.gpx')
    proj.data['Controls']['data']['max cyc'] = 16
    hist = proj.histogram(0)
    inst = hist.data['Instrument Parameters'][0]
    inst['Zero'][1] = zero_value
    inst['Zero'][2] = zero_refine
    hist.data['Sample Parameters']['Shift'] = [shift_value, shift_refine]
    proj.do_refinements([{}])
    proj.save()
    print('\n', tag)
    print('R', hist.data['data'][0])
    print('fractions', hist.ComputeMassFracs())
    print('zero', inst['Zero'], 'shift', hist.data['Sample Parameters']['Shift'])
    print('vary', proj.data['Covariance']['data']['varyList'])
    for ph in proj.phases(): print(ph.name, ph.get_cell())

run('shift_only', False, True, 0.0, -150.0)
run('zero_and_shift', True, True, 0.0855, 0.0)
