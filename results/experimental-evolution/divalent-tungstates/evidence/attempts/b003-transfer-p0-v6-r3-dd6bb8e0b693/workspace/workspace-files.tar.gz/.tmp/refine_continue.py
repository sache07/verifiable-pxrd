import os
from GSASII import GSASIIscriptable as G2sc

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
GPX = os.path.join(ROOT, ".tmp", "trial.gpx")


def dump(proj, label):
    hist = proj.histogram(0)
    print("\n=====", label, "=====")
    print("residuals", hist.data["data"][0])
    print("fractions", hist.ComputeMassFracs())
    for phase in proj.phases():
        print(phase.name, phase.get_cell())
        print("pref", phase.getHAPvalues(hist.name)["Pref.Ori."])
        print("scale", phase.getHAPvalues(hist.name)["Scale"])
    print("inst", hist.data["Instrument Parameters"][0])


proj = G2sc.G2Project(GPX)
proj.data["Controls"]["data"]["max cyc"] = 12
hist = proj.histogram(0)
wo3 = proj.phase("gamma-WO3")
pref = wo3.getHAPvalues(hist.name)["Pref.Ori."]
pref[0] = "MD"
pref[1] = 0.5
pref[2] = True
pref[3] = [0, 0, 1]
hist.clear_refinements({"Instrument Parameters": ["SH/L"]})
proj.do_refinements([{}])
proj.save()
dump(proj, "WO3 [001] March-Dollase")
