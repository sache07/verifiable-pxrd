import csv
import math
import os
import sys

from GSASII import GSASIIscriptable as G2sc

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
CSV = os.path.join(ROOT, "inputs", "pattern.csv")
XYE = os.path.join(ROOT, ".tmp", "pattern.xye")
IPRM = os.path.join(ROOT, ".tmp", "panalytical_cuka.instprm")
GPX = os.path.join(ROOT, ".tmp", "trial.gpx")
COD = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"
WO3_CIF = os.path.join(COD, "1", "52", "89", "1528915.cif")
CU3WO6_CIF = os.path.join(COD, "1", "52", "74", "1527404.cif")


def make_inputs():
    with open(CSV, newline="") as src, open(XYE, "w") as dst:
        rows = csv.DictReader(src)
        dst.write("# two_theta_deg intensity sigma_Poisson\n")
        for row in rows:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    with open(IPRM, "w") as dst:
        dst.write("#GSAS-II instrument parameter file for reflection Cu Kalpha data\n")
        dst.write("Type:PXC;Bank:1\n")
        dst.write(
            "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.5;"
            "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        )
        dst.write("U:10.0;V:-5.0;W:20.0;X:0.5;Y:2.0;Z:0.0;SH/L:0.02\n")


def summary(proj, label):
    hist = proj.histogram(0)
    print(f"\n===== {label} =====")
    print("residuals", hist.data["data"][0])
    print("mass fractions", hist.ComputeMassFracs())
    print("instrument")
    for key, val in hist.data["Instrument Parameters"][0].items():
        print(" ", key, val)
    print("background", hist.data["Background"][0])
    for ph in proj.phases():
        print("phase", ph.name, ph.get_cell())
        print(" HAP", ph.getHAPvalues(hist.name))


def refine_once(proj, label):
    proj.do_refinements([{}])
    summary(proj, label)


def main():
    make_inputs()
    if os.path.exists(GPX):
        os.remove(GPX)
    proj = G2sc.G2Project(newgpx=GPX)
    proj.data["Controls"]["data"]["max cyc"] = 12
    hist = proj.add_powder_histogram(XYE, IPRM, fmthint="xye")
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {"type": "chebyschev-1", "no. coeffs": 15, "refine": True},
    })
    wo3 = proj.add_phase(WO3_CIF, phasename="gamma-WO3", histograms=[hist], fmthint="CIF")
    cuw = proj.add_phase(CU3WO6_CIF, phasename="Cu3WO6", histograms=[hist], fmthint="CIF")
    wo3.HAPvalue("Scale", 1.0)
    cuw.HAPvalue("Scale", 0.5)
    wo3.set_HAP_refinements({"Scale": True})
    cuw.set_HAP_refinements({"Scale": True})
    refine_once(proj, "background + scales")

    wo3.set_refinements({"Cell": True})
    cuw.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_once(proj, "cells + zero")

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]})
    refine_once(proj, "instrument profile")

    proj.save()
    summary(proj, "final trial")


if __name__ == "__main__":
    main()
