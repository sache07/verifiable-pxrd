from GSASII import GSASIIscriptable as G2sc

BASE = '.tmp/trial_sh8.gpx'

for refsize in (0.10, 0.17, 0.25, 0.50, 1.00):
    tag = str(refsize).replace('.', 'p')
    proj = G2sc.G2Project(BASE, newgpx=f'.tmp/rel_size_{tag}.gpx')
    proj.data['Controls']['data']['max cyc'] = 20
    hist = proj.histogram(0)
    wo3 = proj.phase('gamma-WO3')
    cuw = proj.phase('Cu3WO6')
    cuo = proj.phase('tenorite-CuO')
    cuw.setSampleProfile(hist.name, 'size', 'isotropic', refsize)
    cuw.clear_HAP_refinements({'Size': True})
    wo3.setSampleProfile(hist.name, 'size', 'isotropic', 1.5)
    cuo.setSampleProfile(hist.name, 'size', 'isotropic', 0.07)
    wo3.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}})
    cuo.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}})
    proj.do_refinements([{}])
    proj.save()
    print('\nREFSIZE', refsize)
    print('residuals', hist.data['data'][0])
    print('fractions', hist.ComputeMassFracs())
    print('X', hist.data['Instrument Parameters'][0]['X'])
    for ph in proj.phases():
        print(ph.name, ph.getHAPvalues(hist.name)['Size'])
