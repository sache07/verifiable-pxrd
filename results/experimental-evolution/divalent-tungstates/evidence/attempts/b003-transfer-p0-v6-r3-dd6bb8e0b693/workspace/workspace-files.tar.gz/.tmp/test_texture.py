from GSASII import GSASIIscriptable as G2sc

BASE = '.tmp/trial.gpx'

for order in (2, 4, 6, 8):
    out = f'.tmp/trial_sh{order}.gpx'
    proj = G2sc.G2Project(BASE, newgpx=out)
    proj.data['Controls']['data']['max cyc'] = 16
    hist = proj.histogram(0)
    wo3 = proj.phase('gamma-WO3')
    wo3.HAPvalue('PO', order)
    wo3.set_HAP_refinements({'Pref.Ori.': True})
    proj.do_refinements([{}])
    proj.save()
    print('\nSH order', order)
    print('residuals', hist.data['data'][0])
    print('fractions', hist.ComputeMassFracs())
    print('PO', wo3.getHAPvalues(hist.name)['Pref.Ori.'])
    print('vary count', len(proj.data['Covariance']['data']['varyList']))
