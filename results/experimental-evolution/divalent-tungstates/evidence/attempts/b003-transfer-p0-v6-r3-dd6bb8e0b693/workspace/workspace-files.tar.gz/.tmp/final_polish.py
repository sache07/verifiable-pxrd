import csv
import os
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
GPX = os.path.join(ROOT, 'final.gpx')
FIT = os.path.join(ROOT, 'fit.csv')
CIFS = {
    'gamma-WO3': os.path.join(ROOT, 'phase_1_gamma_WO3.cif'),
    'Cu3WO6': os.path.join(ROOT, 'phase_2_Cu3WO6.cif'),
    'tenorite-CuO': os.path.join(ROOT, 'phase_3_tenorite_CuO.cif'),
}

proj = G2sc.G2Project(GPX)
proj.data['Controls']['data']['max cyc'] = 20
for cycle in range(4):
    proj.do_refinements([{}])
    rvals = proj.data['Covariance']['data']['Rvals']
    print('polish', cycle + 1, 'Rwp', rvals.get('Rwp'),
          'GOF', rvals.get('GOF'), 'max_shift_esd', rvals.get('Max shft/sig'))
    if abs(rvals.get('Max shft/sig', 999.0)) < 0.2:
        break
proj.save()

hist = proj.histogram(0)
for phase in proj.phases():
    phase.export_CIF(CIFS[phase.name])
x, yobs, weight, ycalc, ybkg, stored_diff = [
    np.asarray(a, dtype=float) for a in hist.data['data'][1]
]
with open(FIT, 'w', newline='') as fp:
    writer = csv.writer(fp)
    writer.writerow([
        'two_theta_deg', 'observed_intensity_counts',
        'calculated_intensity_counts',
        'difference_observed_minus_calculated_counts',
        'background_intensity_counts',
    ])
    for vals in zip(x, yobs, ycalc, yobs - ycalc, ybkg):
        writer.writerow([f'{v:.8f}' for v in vals])

print('fractions', hist.ComputeMassFracs())
print('residuals', hist.data['data'][0])
print('Rvals', proj.data['Covariance']['data']['Rvals'])
for phase in proj.phases():
    print(phase.name, phase.get_cell())
