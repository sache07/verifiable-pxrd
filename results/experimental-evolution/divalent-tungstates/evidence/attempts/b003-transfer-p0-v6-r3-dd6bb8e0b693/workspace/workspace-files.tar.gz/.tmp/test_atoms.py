from GSASII import GSASIIscriptable as G2sc

BASE = '.tmp/rel_size_0p17.gpx'

def run(tag, atom_sets):
    proj = G2sc.G2Project(BASE, newgpx=f'.tmp/{tag}.gpx')
    proj.data['Controls']['data']['max cyc'] = 20
    hist = proj.histogram(0)
    for phase_name, atom_names in atom_sets.items():
        ph = proj.phase(phase_name)
        ph.set_refinements({'Atoms': {name: 'X' for name in atom_names}})
    proj.do_refinements([{}])
    proj.save()
    print('\n', tag, hist.data['data'][0])
    print('fractions', hist.ComputeMassFracs())
    print('vary count', len(proj.data['Covariance']['data']['varyList']))
    for ph in proj.phases():
        print(ph.name, ph.get_cell())
        for atom in ph.atoms():
            print(atom.label, atom.element, atom.coordinates, atom.uiso, atom.refinement_flags)

run('atoms_cations', {
    'gamma-WO3': ('W1', 'W2'),
    'Cu3WO6': ('Cu1', 'W1'),
})

run('atoms_all', {
    'gamma-WO3': ('O1', 'O2', 'O3', 'O4', 'O5', 'O6', 'W1', 'W2'),
    'Cu3WO6': ('Cu1', 'W1', 'O1', 'O2'),
    'tenorite-CuO': ('O1',),
})
