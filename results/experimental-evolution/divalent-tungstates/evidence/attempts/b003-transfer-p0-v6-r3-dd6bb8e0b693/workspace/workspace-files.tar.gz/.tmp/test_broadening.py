from GSASII import GSASIIscriptable as G2sc

BASE = '.tmp/trial_sh8.gpx'

def run(label, size_names=(), strain_names=()):
    out = f'.tmp/{label}.gpx'
    proj = G2sc.G2Project(BASE, newgpx=out)
    proj.data['Controls']['data']['max cyc'] = 16
    hist = proj.histogram(0)
    for name in size_names:
        ph = proj.phase(name)
        ph.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True, 'value': 1.0}})
    for name in strain_names:
        ph = proj.phase(name)
        ph.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}})
    proj.do_refinements([{}])
    proj.save()
    print('\n', label, hist.data['data'][0])
    print('fractions', hist.ComputeMassFracs())
    print('inst', hist.data['Instrument Parameters'][0])
    for ph in proj.phases():
        hap = ph.getHAPvalues(hist.name)
        print(ph.name, 'size', hap['Size'], 'strain', hap['Mustrain'])

run('sh8_size_wo3_cuo', ('gamma-WO3', 'tenorite-CuO'))
run('sh8_size_all', ('gamma-WO3', 'Cu3WO6', 'tenorite-CuO'))
run('sh8_strain_wo3_cuo', (), ('gamma-WO3', 'tenorite-CuO'))
run('sh8_broad_wo3_cuo', ('gamma-WO3', 'tenorite-CuO'), ('gamma-WO3', 'tenorite-CuO'))
