from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
DB = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PHASES = [
    ("PbWO4_scheelite", DB / "9/00/98/9009811.cif", 0.08, 2200.0, 2.0),
    ("WO3_monoclinic", DB / "1/52/89/1528915.cif", 3.0, 100.0, 0.8),
    ("Pb3O4_tetragonal", DB / "1/53/79/1537983.cif", 0.15, 1200.0, 0.25),
]


def set_flag(item, value=False):
    if isinstance(item, list) and len(item) > 1:
        item[-1] = value


def summarize(gpx, tag):
    hist = gpx.histogram(0)
    residuals = hist.data["data"][0]
    inst = hist.data["Instrument Parameters"][0]
    phases = []
    denominator = 0.0
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        denominator += hap["Scale"][0] * phase.data["General"]["Mass"]
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        frac = hap["Scale"][0] * phase.data["General"]["Mass"] / denominator
        phases.append({
            "name": phase.name,
            "fraction": frac,
            "scale": hap["Scale"][0],
            "cell": phase.get_cell(),
            "size_um": hap["Size"][1][0],
            "microstrain": hap["Mustrain"][1][0],
        })
    state = {
        "tag": tag,
        "Rwp": residuals.get("wR"),
        "Rp": residuals.get("R"),
        "GOF": gpx.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "converged": gpx.data["Covariance"]["data"].get("Rvals", {}).get("converged"),
        "zero": inst["Zero"][1],
        "profile": {k: inst[k][1] for k in ["U", "V", "W", "X", "Y", "Z", "SH/L"]},
        "frozen": gpx.get_Frozen(),
        "phases": phases,
    }
    print("SUMMARY", json.dumps(state, sort_keys=True))
    return state


def refine(gpx, tag):
    print("\n===", tag, "===")
    gpx.refine(makeBack=False)
    summarize(gpx, tag)
    gpx.save(TMP / f"trial3_{tag}.gpx")


def main():
    out = TMP / "trial3.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"), str(TMP / "instrument.instprm"),
        fmthint="comma",
    )
    phase_objects = []
    for name, path, size, strain, scale in PHASES:
        phase = gpx.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][:] = [scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][2][0] = False
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        hap["Mustrain"][2][0] = False
        phase_objects.append(phase)

    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 18},
    })
    sample = hist.data["Sample Parameters"]
    sample["Scale"][:] = [1.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for key, val in {"Zero": 0.42, "U": 8.0, "V": 0.0, "W": 12.0,
                     "X": 0.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.002}.items():
        inst[key][1] = val
        inst[key][2] = False

    gpx.set_Controls("cycles", 7)
    gpx.data["Controls"]["data"]["SVDtol"] = 1e-7
    # Physical parameter bounds. GSAS-II freezes a parameter only if it crosses a bound.
    bounds = {
        ":0:Zero": (0.0, 1.0),
        ":0:U": (0.0, 100.0),
        ":0:W": (1.0, 100.0),
        "0:0:Size;i": (0.01, 10.0),
        "1:0:Size;i": (0.01, 10.0),
        "2:0:Size;i": (0.01, 10.0),
        "0:0:Mustrain;i": (0.0, 10000.0),
        "1:0:Mustrain;i": (0.0, 10000.0),
        "2:0:Mustrain;i": (0.0, 10000.0),
        "0:0:Scale": (1e-5, 100.0),
        "1:0:Scale": (1e-5, 100.0),
        "2:0:Scale": (1e-5, 100.0),
    }
    for var, (lo, hi) in bounds.items():
        gpx.set_Controls("parmMin", lo, var)
        gpx.set_Controls("parmMax", hi, var)
    gpx.save()

    refine(gpx, "scales")
    inst["Zero"][2] = True
    refine(gpx, "zero")
    for phase in phase_objects:
        phase.data["General"]["Cell"][0] = True
    refine(gpx, "cells")

    # Refine broad Pb-containing phases first; WO3 provides the sharp instrument baseline.
    for phase in (phase_objects[0], phase_objects[2]):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
        hap["Mustrain"][2][0] = True
    refine(gpx, "broadening_pb")

    # Fit only physically nonnegative Gaussian instrument terms.
    inst["U"][2] = True
    inst["W"][2] = True
    refine(gpx, "instrument")

    # Allow a small WO3 sample broadening after the instrument baseline is established.
    hap = phase_objects[1].data["Histograms"][hist.name]
    hap["Size"][2][0] = True
    hap["Mustrain"][2][0] = True
    refine(gpx, "all_profiles")

    # One final cycle after any bound-triggered freezes.
    refine(gpx, "final")
    gpx.save(out)


if __name__ == "__main__":
    main()
