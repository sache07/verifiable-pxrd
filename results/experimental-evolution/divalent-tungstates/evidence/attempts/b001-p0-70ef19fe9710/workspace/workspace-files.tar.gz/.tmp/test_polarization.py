from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
for pol in (0.7, 1.0):
    dst = ROOT / f".tmp/model_pol_{str(pol).replace('.', 'p')}.gpx"
    gpx = G2sc.G2Project(str(ROOT / ".tmp/trial3_mix.gpx"), newgpx=str(dst))
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    gpx.set_Frozen()
    inst["Polariz."][1] = pol
    inst["Polariz."][2] = False
    inst["U"][1] = 0.0
    inst["U"][2] = False

    p0, p1, p2 = gpx.phases()
    h0 = p0.data["Histograms"][hist.name]
    h1 = p1.data["Histograms"][hist.name]
    h2 = p2.data["Histograms"][hist.name]
    h0["Mustrain"][1][0] = 0.0
    h0["Mustrain"][2][0] = False
    h1["Size"][1][0] = 10.0
    h1["Size"][2][0] = False
    # Pb3O4 broadening is angular (strain-like); remove the highly-correlated size term.
    h2["Size"][1][0] = 10.0
    h2["Size"][1][2] = 1.0
    h2["Size"][2][0] = False
    h2["Size"][2][2] = False
    h2["Mustrain"][1][2] = 1.0
    h2["Mustrain"][2][0] = True
    h2["Mustrain"][2][2] = False

    gpx.set_Controls("cycles", 9)
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    if not gpx.data["Covariance"]["data"].get("Rvals", {}).get("converged", False):
        gpx.refine(makeBack=False)
        gpx.save()

    r = hist.data["data"][0]
    den = sum(p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"] for p in gpx.phases())
    state = {
        "pol": pol, "Rwp": r.get("wR"), "Rp": r.get("R"),
        "GOF": gpx.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "converged": gpx.data["Covariance"]["data"].get("Rvals", {}).get("converged"),
        "frozen": gpx.get_Frozen(), "W": inst["W"][1], "fractions": {},
    }
    for p in gpx.phases():
        h = p.data["Histograms"][hist.name]
        state["fractions"][p.name] = h["Scale"][0] * p.data["General"]["Mass"] / den
    print("POLSUMMARY", json.dumps(state, sort_keys=True))
