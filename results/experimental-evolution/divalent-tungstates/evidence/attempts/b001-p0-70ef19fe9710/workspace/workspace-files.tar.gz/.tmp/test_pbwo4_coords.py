from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
gpx = G2sc.G2Project(str(ROOT / ".tmp/model_pol_uiso.gpx"), newgpx=str(ROOT / ".tmp/model_pbwo4_coords.gpx"))
hist = gpx.histogram(0)
p = gpx.phase(0)
oxygen = p.atom("O")
oxygen.refinement_flags = "X"
gpx.set_Controls("cycles", 10)
gpx.save()
gpx.refine(makeBack=False)
gpx.save()
r = hist.data["data"][0]
print("COORDSUMMARY", json.dumps({
    "Rwp": r.get("wR"), "Rp": r.get("R"), "Rf": r.get("0:0:Rf"),
    "coords": oxygen.coordinates,
    "GOF": gpx.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
    "converged": gpx.data["Covariance"]["data"].get("Rvals", {}).get("converged"),
}, sort_keys=True))
