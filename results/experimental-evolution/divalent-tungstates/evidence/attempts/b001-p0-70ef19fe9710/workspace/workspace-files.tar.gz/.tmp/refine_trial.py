from pathlib import Path
import json
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
DB = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PBWO4 = DB / "9/00/98/9009811.cif"
WO3 = DB / "1/52/89/1528915.cif"


def print_state(gpx, tag):
    hist = gpx.histogram(0)
    print(f"\nSTATE {tag}")
    print("residuals", hist.data["data"][0])
    print("instrument")
    for key, value in hist.data["Instrument Parameters"][0].items():
        if isinstance(value, list) and len(value) >= 2:
            print(f"  {key:14s} {value[1]!r} refine={value[2] if len(value) > 2 else None}")
    print("background", hist.data["Background"][0])
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        print("phase", phase.name)
        print("  cell", phase.get_cell())
        print("  scale", hap["Scale"])
        print("  size", hap["Size"])
        print("  mustrain", hap["Mustrain"])


def main():
    out = TMP / "trial.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(TMP / "instrument.instprm"),
        fmthint="comma",
    )
    p1 = gpx.add_phase(str(PBWO4), phasename="PbWO4_scheelite", histograms=[hist], fmthint="CIF")
    p2 = gpx.add_phase(str(WO3), phasename="WO3_monoclinic", histograms=[hist], fmthint="CIF")
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 15,
        },
    })
    gpx.data["Controls"]["data"]["max cyc"] = 8
    gpx.data["Controls"]["data"]["SVDtol"] = 1e-6
    gpx.save()
    print_state(gpx, "initial")

    steps = [
        {"set": {"PhaseFraction": True}},
        {"set": {"Instrument Parameters": ["Zero"]}},
        {"set": {"Cell": True}},
        {"set": {"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]}},
        {"set": {"Size": {"type": "isotropic", "refine": True, "value": 1000.0},
                  "Mustrain": {"type": "isotropic", "refine": True}}},
    ]
    for i, step in enumerate(steps, 1):
        print("\nREFINEMENT STEP", i, step)
        gpx.do_refinements([step])
        print_state(gpx, f"step-{i}")
    gpx.save()


if __name__ == "__main__":
    main()
