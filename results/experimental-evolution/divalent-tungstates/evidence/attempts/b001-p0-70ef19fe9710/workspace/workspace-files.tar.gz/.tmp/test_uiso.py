from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
src = ROOT / ".tmp/model_pol_0p7.gpx"
dst = ROOT / ".tmp/model_uiso.gpx"
gpx = G2sc.G2Project(str(src), newgpx=str(dst))
hist = gpx.histogram(0)
gpx.set_Frozen()
p0, p1, p2 = gpx.phases()
h0 = p0.data["Histograms"][hist.name]
h1 = p1.data["Histograms"][hist.name]
h2 = p2.data["Histograms"][hist.name]

# Remove weakly identifiable profile mixtures from the vary list.
h0["Size"][1][2] = 0.90
h0["Size"][2][2] = False
h1["Mustrain"][1][2] = 1.0
h1["Mustrain"][2][2] = False
h2["Size"][1][0] = 10.0
h2["Size"][2][0] = False
h2["Mustrain"][1][2] = 1.0
h2["Mustrain"][2][2] = False
gpx.set_Controls("parmMax", 30000.0, "2:0:Mustrain;i")

# Test whether the assumed PbWO4 displacement factors caused high-angle mismatch.
for i, atom in enumerate(p0.atoms()):
    atom.refinement_flags = "U"
    gpx.set_Controls("parmMin", 0.0, f"0::AUiso:{i}")
    gpx.set_Controls("parmMax", 0.05, f"0::AUiso:{i}")

gpx.set_Controls("cycles", 10)
gpx.save()
gpx.refine(makeBack=False)
gpx.save()
if not gpx.data["Covariance"]["data"].get("Rvals", {}).get("converged", False):
    gpx.refine(makeBack=False)
    gpx.save()

r = hist.data["data"][0]
den = sum(p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"] for p in gpx.phases())
state = {
    "Rwp": r.get("wR"), "Rp": r.get("R"),
    "GOF": gpx.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
    "frozen": gpx.get_Frozen(),
    "uiso": {a.label: a.uiso for a in p0.atoms()},
    "fractions": {p.name: p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"] / den for p in gpx.phases()},
}
print("UISOSUMMARY", json.dumps(state, sort_keys=True))
