from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
gpx = G2sc.G2Project(str(ROOT / ".tmp/model_uiso.gpx"), newgpx=str(ROOT / ".tmp/model_pol_uiso.gpx"))
hist = gpx.histogram(0)
gpx.set_Frozen()
for atom in gpx.phase(0).atoms():
    atom.uiso = 0.0
    atom.refinement_flags = " "
inst = hist.data["Instrument Parameters"][0]
inst["Polariz."][1] = 0.7
inst["Polariz."][2] = True
gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")
gpx.set_Controls("cycles", 10)
gpx.save()
gpx.refine(makeBack=False)
gpx.save()
r = hist.data["data"][0]
den = sum(p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"] for p in gpx.phases())
print("POLUISOSUMMARY", json.dumps({
    "Rwp": r.get("wR"), "Rp": r.get("R"),
    "GOF": gpx.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
    "polarization": inst["Polariz."][1], "frozen": gpx.get_Frozen(),
    "fractions": {p.name: p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"] / den for p in gpx.phases()},
}, sort_keys=True))
