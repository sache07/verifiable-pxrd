from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIstrMath as G2stMth


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/model_pbwo4_coords.gpx"
FINAL = ROOT / "final.gpx"

phase_meta = {
    "PbWO4_scheelite": {
        "display_name": "lead tungstate (scheelite)",
        "formula": "PbWO4",
        "space_group_number": 88,
        "cif": "PbWO4_scheelite.cif",
    },
    "WO3_monoclinic": {
        "display_name": "tungsten(VI) oxide (monoclinic gamma-WO3)",
        "formula": "WO3",
        "space_group_number": 14,
        "cif": "WO3_monoclinic.cif",
    },
    "Pb3O4_tetragonal": {
        "display_name": "lead tetroxide (minium)",
        "formula": "Pb3O4",
        "space_group_number": 135,
        "cif": "Pb3O4_tetragonal.cif",
    },
}

# Save under the required final name before exporting, so all products derive from final.gpx.
gpx = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
gpx.save()
gpx = G2sc.G2Project(str(FINAL))
hist = gpx.histogram(0)
cov = gpx.data["Covariance"]["data"]
res = hist.data["data"][0]

if gpx.get_Frozen():
    raise RuntimeError(f"Final project unexpectedly has frozen variables: {gpx.get_Frozen()}")
if not cov.get("Rvals", {}).get("converged", False):
    raise RuntimeError("Final refinement is not marked converged")

# Export one structural model per phase from the saved final project.
for phase in gpx.phases():
    phase.export_CIF(str(ROOT / phase_meta[phase.name]["cif"]))

# Export the fitted interval with the residual convention made explicit in the header.
x = np.asarray(hist.getdata("X"), dtype=float)
yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
background = np.asarray(hist.getdata("Background"), dtype=float)
difference = np.asarray(hist.getdata("Residual"), dtype=float)
low, high = hist.data["Limits"][1]
# Match GSAS-II's exact refinement slice (the first grid point above the upper
# numerical limit is included by its searchsorted(...)+1 convention).
x_begin = int(np.searchsorted(x, low))
x_end = int(np.searchsorted(x, high)) + 1
profile = np.column_stack((
    x[x_begin:x_end], yobs[x_begin:x_end], ycalc[x_begin:x_end],
    difference[x_begin:x_end], background[x_begin:x_end],
))
np.savetxt(
    ROOT / "fit.csv",
    profile,
    delimiter=",",
    header="two_theta_deg,observed_intensity,calculated_intensity,difference_observed_minus_calculated,background_intensity",
    comments="",
    fmt=["%.8f", "%.8g", "%.8g", "%.8g", "%.8g"],
)

# GSAS-II's Hill-Howard crystalline weight fractions and covariance-only uncertainties.
phases_dict = {k: v for k, v in gpx.data["Phases"].items() if k != "data"}
wf, wf_sig = G2stMth.calcMassFracs(
    cov["varyList"], cov["covMatrix"], phases_dict, hist.name, hist.id
)

phase_results = []
for phase in gpx.phases():
    pid = phase.id
    key = f"{pid}:{hist.id}:WgtFrac"
    sg = phase.data["General"]["SGData"]
    cell, cell_sig = phase.get_cell_and_esd()
    meta = phase_meta[phase.name]
    phase_results.append({
        "name": meta["display_name"],
        "formula": meta["formula"],
        "space_group": sg["SpGrp"].strip(),
        "space_group_number": meta["space_group_number"],
        "cif_path": meta["cif"],
        "weight_fraction": float(wf[key]),
        "weight_fraction_formal_esd": float(wf_sig[key]),
        "weight_percent": float(100.0 * wf[key]),
        "phase_Rf_percent": float(res[f"{pid}:{hist.id}:Rf"]),
        "phase_Rf2_percent": float(res[f"{pid}:{hist.id}:Rf^2"]),
        "cell": {k: float(v) for k, v in cell.items()},
        "cell_formal_esd": {k: float(v) for k, v in cell_sig.items()},
    })

fit_stats = {
    "Rwp_percent": float(res["wR"]),
    "Rp_percent": float(res["R"]),
    "Rexp_percent": float(res["wRmin"]),
    "goodness_of_fit": float(cov["Rvals"]["GOF"]),
    "chi_square": float(cov["Rvals"]["chisq"]),
    "durbin_watson": float(res["Durbin-Watson"]),
    "n_observations": int(cov["Rvals"]["Nobs"]),
    "n_refined_variables": int(cov["Rvals"]["Nvars"]),
    "fit_range_two_theta_deg": [float(low), float(high)],
    "difference_profile": "observed - calculated",
    "converged": bool(cov["Rvals"]["converged"]),
}

result = {
    "project_path": "final.gpx",
    "profile_path": "fit.csv",
    "radiation": "Cu K-alpha1/K-alpha2",
    "wavelengths_angstrom": [1.540598, 1.544426],
    "modeled_crystalline_phase_count": len(phase_results),
    "fractions_normalized_over_modeled_crystalline_phases": True,
    "phases": phase_results,
    "fit_statistics": fit_stats,
}
with open(ROOT / "result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, sort_keys=False)
    stream.write("\n")

print(json.dumps(result, indent=2))
