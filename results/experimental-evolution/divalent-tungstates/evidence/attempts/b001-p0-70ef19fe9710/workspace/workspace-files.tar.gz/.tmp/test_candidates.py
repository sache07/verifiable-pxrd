from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
DB = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
BASE = ROOT / ".tmp/model_pol_uiso.gpx"
CANDIDATES = [
    ("PbO_litharge", DB / "9/01/27/9012700.cif"),
    ("PbO_massicot", DB / "1/53/36/1533609.cif"),
    ("PbWO4_raspite", DB / "9/00/76/9007617.cif"),
    ("PbO2_orthorhombic", DB / "1/53/10/1531016.cif"),
]


for name, cif in CANDIDATES:
    out = ROOT / f".tmp/candidate_{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = gpx.histogram(0)
    phase = gpx.add_phase(str(cif), phasename=name, histograms=[hist], fmthint="CIF")
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][:] = [0.05, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.1
    hap["Size"][2][0] = False
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2][0] = False
    gpx.set_Controls("parmMin", 0.0, "3:0:Scale")
    gpx.set_Controls("parmMax", 100.0, "3:0:Scale")
    gpx.set_Controls("cycles", 8)
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    r = hist.data["data"][0]
    den = sum(p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"] for p in gpx.phases())
    frac = hap["Scale"][0] * phase.data["General"]["Mass"] / den
    cov = gpx.data["Covariance"]["data"]
    vname = "3:0:Scale"
    scale_sig = None
    if vname in cov.get("varyList", []):
        scale_sig = cov["sig"][cov["varyList"].index(vname)]
    print("CANDIDATE", json.dumps({
        "name": name, "Rwp": r.get("wR"), "Rp": r.get("R"),
        "chisq": cov.get("Rvals", {}).get("chisq"),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "scale": hap["Scale"][0], "scale_sigma": scale_sig,
        "weight_fraction": frac, "frozen": gpx.get_Frozen(),
        "Rf": r.get("3:0:Rf"), "Rf2": r.get("3:0:Rf^2"),
    }, sort_keys=True))
