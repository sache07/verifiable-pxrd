from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
src = ROOT / ".tmp/trial3.gpx"
dst = ROOT / ".tmp/trial3_mix.gpx"
gpx = G2sc.G2Project(str(src), newgpx=str(dst))
hist = gpx.histogram(0)
inst = hist.data["Instrument Parameters"][0]

# Turn bound-hit terms into explicit, fixed physical limits rather than leaving them frozen.
gpx.set_Frozen()
inst["U"][1] = 0.0
inst["U"][2] = False
for idx, phase in enumerate(gpx.phases()):
    hap = phase.data["Histograms"][hist.name]
    if idx == 0:
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2][0] = False
    if idx == 1:
        hap["Size"][1][0] = 10.0
        hap["Size"][2][0] = False

# Refine the Gaussian/Lorentzian sample-profile mixing rather than forcing Lorentzian tails.
mix_vars = []
for idx, which in [(0, "Size"), (1, "Mustrain"), (2, "Size"), (2, "Mustrain")]:
    hap = gpx.phases()[idx].data["Histograms"][hist.name]
    hap[which][1][2] = 0.5
    hap[which][2][2] = True
    mix_vars.append(f"{idx}:0:{which};mx")
for var in mix_vars:
    gpx.set_Controls("parmMin", 0.0, var)
    gpx.set_Controls("parmMax", 1.0, var)

inst["Polariz."][2] = True
gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")
gpx.set_Controls("cycles", 8)
gpx.save()
gpx.refine(makeBack=False)
gpx.save()

r = hist.data["data"][0]
den = sum(p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"] for p in gpx.phases())
state = {
    "Rwp": r.get("wR"), "Rp": r.get("R"),
    "GOF": gpx.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
    "polarization": inst["Polariz."][1], "W": inst["W"][1],
    "frozen": gpx.get_Frozen(),
    "phases": [],
}
for p in gpx.phases():
    h = p.data["Histograms"][hist.name]
    state["phases"].append({
        "name": p.name,
        "fraction": h["Scale"][0] * p.data["General"]["Mass"] / den,
        "size": h["Size"], "mustrain": h["Mustrain"],
    })
print("MIXSUMMARY", json.dumps(state, sort_keys=True))
