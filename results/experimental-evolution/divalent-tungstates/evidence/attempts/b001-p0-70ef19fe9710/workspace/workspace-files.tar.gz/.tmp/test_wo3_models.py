from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
DB = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
BASE = ROOT / ".tmp/model_pol_uiso.gpx"
MODELS = [
    ("WO3_P-1", DB / "2/10/62/2106293.cif"),
    ("WO3_P21m", DB / "1/01/06/1010618.cif"),
    ("WO3_Pnma", DB / "2/10/73/2107312.cif"),
    ("WO3_P21n_alt", DB / "2/31/10/2311041.cif"),
]


for name, cif in MODELS:
    out = ROOT / f".tmp/wo3model_{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = gpx.histogram(0)
    old = gpx.phase(1)
    old_hap = old.data["Histograms"][hist.name]
    old_hap["Use"] = False
    old_hap["Scale"][1] = False
    phase = gpx.add_phase(str(cif), phasename=name, histograms=[hist], fmthint="CIF")
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][:] = [2.72, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2][0] = False
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 3100.0
    hap["Mustrain"][1][2] = 1.0
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][2] = False
    phase.data["General"]["Cell"][0] = True
    gpx.set_Controls("parmMin", 0.0, "3:0:Mustrain;i")
    gpx.set_Controls("parmMax", 30000.0, "3:0:Mustrain;i")
    gpx.set_Controls("parmMin", 0.0, "3:0:Scale")
    gpx.set_Controls("cycles", 10)
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    if not gpx.data["Covariance"]["data"].get("Rvals", {}).get("converged", False):
        gpx.refine(makeBack=False)
        gpx.save()
    r = hist.data["data"][0]
    cov = gpx.data["Covariance"]["data"]
    print("WO3MODEL", json.dumps({
        "name": name, "Rwp": r.get("wR"), "Rp": r.get("R"),
        "chisq": cov.get("Rvals", {}).get("chisq"),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "Rf": r.get("3:0:Rf"), "Rf2": r.get("3:0:Rf^2"),
        "cell": phase.get_cell(), "scale": hap["Scale"][0],
        "microstrain": hap["Mustrain"][1][0], "frozen": gpx.get_Frozen(),
    }, sort_keys=True))
