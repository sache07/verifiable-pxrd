#!/usr/bin/env python3
"""Replay one phase-broadening model from a common GSAS-II checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIspc as G2spc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--phase", required=True)
    ap.add_argument(
        "--model",
        choices=("neutral", "size", "strain", "combined", "uniaxial_strain", "generalized_strain"),
        required=True,
    )
    ap.add_argument("--axis", default="001", help="three digits, used for uniaxial strain")
    ap.add_argument("--cycles", type=int, default=8)
    args = ap.parse_args()

    out = str(Path(args.out).resolve())
    gpx = G2sc.G2Project(args.base, newgpx=out)
    gpx.data["Controls"]["data"]["max cyc"] = args.cycles
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = gpx.histogram(0)

    # Fully reset every phase's microstructure values and flags. This makes the
    # trial genuinely reversible and avoids inheriting merely-cleared flags.
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [1000.0, 1000.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])

    phase = gpx.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    if args.model in ("size", "combined"):
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
    if args.model in ("strain", "combined"):
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True
    elif args.model == "uniaxial_strain":
        axis = [int(v) for v in args.axis]
        if len(axis) != 3 or not any(axis):
            raise ValueError("--axis must contain three digits and be nonzero")
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][:] = [6966.0, 6966.0, 1.0]
        hap["Mustrain"][2][:] = [True, True, False]
        hap["Mustrain"][3] = axis
    elif args.model == "generalized_strain":
        cell = phase.get_cell()
        cell6 = [
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ]
        values = G2spc.Muiso2Shkl(6966.0, phase.data["General"]["SGData"], cell6)
        hap["Mustrain"][0] = "generalized"
        hap["Mustrain"][4][:] = [float(v) for v in values]
        hap["Mustrain"][5][:] = [True] * len(values)

    gpx.save()
    gpx.do_refinements([{}])
    gpx.save()
    gpx.do_refinements([{}])
    gpx.save()

    mass = hist.ComputeMassFracs()
    inst = hist.data["Instrument Parameters"][0]
    summary = {
        "base": str(Path(args.base).resolve()),
        "project": out,
        "trial_phase": args.phase,
        "model": args.model,
        "Rwp": float(hist.residuals["wR"]),
        "Rp": float(hist.residuals["R"]),
        "GOF": float(np.sqrt(gpx.data["Covariance"]["data"]["Rvals"]["GOF"] ** 2)),
        "instrument": {k: float(inst[k][1]) for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")},
        "phases": {},
        "vary_list": list(gpx.data["Covariance"]["data"].get("varyList", [])),
        "sigmas": [float(v) for v in gpx.data["Covariance"]["data"].get("sig", [])],
    }
    for p in gpx.phases():
        h = p.data["Histograms"][hist.name]
        summary["phases"][p.name] = {
            "weight_fraction": float(mass[p.name][0]),
            "weight_fraction_esd": float(mass[p.name][1]),
            "scale": float(h["Scale"][0]),
            "size_type": h["Size"][0],
            "size_values": [float(v) for v in h["Size"][1]],
            "size_flags": [bool(v) for v in h["Size"][2]],
            "strain_type": h["Mustrain"][0],
            "strain_values": [float(v) for v in h["Mustrain"][1]],
            "strain_flags": [bool(v) for v in h["Mustrain"][2]],
            "strain_axis": [int(v) for v in h["Mustrain"][3]],
            "generalized_strain_values": [float(v) for v in h["Mustrain"][4]],
            "generalized_strain_flags": [bool(v) for v in h["Mustrain"][5]],
        }
    Path(out + ".json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
