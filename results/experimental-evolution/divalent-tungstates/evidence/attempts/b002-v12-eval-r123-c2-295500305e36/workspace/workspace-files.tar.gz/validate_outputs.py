#!/usr/bin/env python3
"""Check that submitted JSON, CIFs, profile and GPX describe one model."""

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


result = json.loads(Path("result.json").read_text())
assert result["project_path"] == "final.gpx"
assert Path(result["project_path"]).is_file()
assert Path(result["profile_path"]).is_file()
assert all(isinstance(p["weight_fraction"], (int, float)) for p in result["phases"])
assert all(Path(p["cif_path"]).is_file() for p in result["phases"])
assert abs(sum(p["weight_fraction"] for p in result["phases"]) - 1.0) < 1e-12

gpx = G2sc.G2Project(result["project_path"])
hist = gpx.histogram(0)
mass = hist.ComputeMassFracs()
for phase in result["phases"]:
    assert abs(phase["weight_fraction"] - mass[phase["name"]][0]) < 1e-12

with Path(result["profile_path"]).open(newline="") as fp:
    rows = list(csv.DictReader(fp))
x, y, _, yc, yb, _ = hist.data["data"][1]
assert len(rows) == len(x) == 8301
columns = {
    "two_theta_deg": x,
    "observed_counts": y,
    "calculated_counts": yc,
    "background_counts": yb,
    "difference_counts": y - yc,
}
max_error = {}
for name, expected in columns.items():
    submitted = np.array([float(row[name]) for row in rows])
    max_error[name] = float(np.max(np.abs(submitted - expected)))
    assert np.allclose(submitted, expected, rtol=2e-9, atol=5e-6)

print(
    json.dumps(
        {
            "status": "pass",
            "weight_fraction_sum": sum(p["weight_fraction"] for p in result["phases"]),
            "profile_rows": len(rows),
            "max_profile_rounding_error": max_error,
        },
        indent=2,
    )
)
