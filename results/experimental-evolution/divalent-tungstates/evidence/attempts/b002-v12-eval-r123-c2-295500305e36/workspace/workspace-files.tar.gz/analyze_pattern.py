#!/usr/bin/env python3
"""Small local aid for peak finding and CIF-pattern screening."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import gaussian_filter1d, minimum_filter1d, percentile_filter
from scipy.signal import find_peaks, peak_widths


def observed(path: str):
    frame = pd.read_csv(path)
    x = frame.iloc[:, 0].to_numpy(float)
    y = frame.iloc[:, 1].to_numpy(float)
    # Wide low-percentile envelope, subsequently smoothed. This is used only for
    # screening and peak finding, never as the submitted Rietveld background.
    bg = percentile_filter(y, percentile=15, size=401, mode="nearest")
    bg = gaussian_filter1d(bg, 80)
    signal = np.maximum(y - bg, 0.0)
    return x, y, bg, signal


def simulated(pat, x: np.ndarray, fwhm: float, shift: float):
    out = np.zeros_like(x)
    sigma = fwhm / 2.354820045
    for pos, inten in zip(pat.x, pat.y):
        if inten < 0.02:
            continue
        out += inten * np.exp(-0.5 * ((x - (pos + shift)) / sigma) ** 2)
    return out


def screen(cif: str, x: np.ndarray, signal: np.ndarray):
    structure = Structure.from_file(cif)
    calc = XRDCalculator(wavelength=1.540598, symprec=0)
    pat = calc.get_pattern(structure, two_theta_range=(x[0] - 1, x[-1] + 1))
    best = None
    for fwhm in (0.08, 0.12, 0.18, 0.25, 0.35):
        for shift in np.linspace(-0.35, 0.35, 71):
            sim = simulated(pat, x, fwhm, shift)
            norm = np.linalg.norm(sim) * np.linalg.norm(signal)
            score = float(sim @ signal / norm) if norm else 0.0
            if best is None or score > best[0]:
                best = (score, shift, fwhm, structure, pat)
    assert best is not None
    score, shift, fwhm, structure, pat = best
    formula = structure.composition.reduced_formula
    lattice = tuple(round(v, 5) for v in structure.lattice.abc + structure.lattice.angles)
    strong = [(round(float(a + shift), 3), round(float(b), 1)) for a, b in zip(pat.x, pat.y) if b >= 5]
    return score, shift, fwhm, formula, lattice, strong


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("pattern")
    parser.add_argument("cifs", nargs="*")
    parser.add_argument("--prominence", type=float, default=250.0)
    args = parser.parse_args()
    x, y, bg, signal = observed(args.pattern)
    peaks, props = find_peaks(signal, prominence=args.prominence, distance=4)
    widths = peak_widths(signal, peaks, rel_height=0.5)[0] * np.median(np.diff(x))
    order = np.argsort(props["prominences"])[::-1]
    print("Observed peaks (2theta, net height, prominence, approximate FWHM):")
    for i in order[:120]:
        p = peaks[i]
        print(f"{x[p]:9.4f} {signal[p]:10.1f} {props['prominences'][i]:10.1f} {widths[i]:8.4f}")
    print("\nCandidate single-pattern cosine screens:")
    for cif in args.cifs:
        try:
            score, shift, fwhm, formula, lattice, strong = screen(cif, x, signal)
            print(f"{score:8.5f} shift={shift:+.3f} FWHM={fwhm:.3f} {formula:12s} {Path(cif).name} cell={lattice}")
            print("  strong:", strong[:40])
        except Exception as exc:
            print(f"ERROR {cif}: {exc}")


if __name__ == "__main__":
    main()
