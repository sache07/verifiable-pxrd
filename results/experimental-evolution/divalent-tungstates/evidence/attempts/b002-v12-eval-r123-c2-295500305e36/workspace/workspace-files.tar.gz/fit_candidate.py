#!/usr/bin/env python3
"""Build and refine a common-baseline GSAS-II project for source ranking."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


MGWO4 = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/01/39/9013902.cif"
MGO = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/00/04/9000499.cif"


def neutralize(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1000.0, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def report(gpx, label: str) -> None:
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    scales = {
        p.name: p.data["Histograms"][hist.name]["Scale"][0]
        for p in gpx.phases()
    }
    try:
        mass = hist.ComputeMassFracs()
    except Exception as exc:
        mass = {"error": str(exc)}
    print(
        "STEP",
        label,
        "residuals=", hist.residuals,
        "profile=", {k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")},
        "scales=", scales,
        "mass=", mass,
        flush=True,
    )


def refine(gpx, label: str) -> None:
    gpx.do_refinements([{}])
    report(gpx, label)
    gpx.save()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--wo3", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--without-mgo", action="store_true")
    ap.add_argument("--cycles", type=int, default=8)
    args = ap.parse_args()

    out = str(Path(args.out).resolve())
    gpx = G2sc.G2Project(newgpx=out)
    gpx.data["Controls"]["data"]["max cyc"] = args.cycles
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = gpx.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    # Keep the overall histogram multiplier fixed; refine independent phase scales.
    hist.data["Sample Parameters"]["Scale"][:] = [1.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"][:] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"][:] = [0.0, False]
    # Common nonnegative, low-dimensional starting profile.
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 5.0, "V": 0.0, "W": 25.0, "X": 0.5, "Y": 0.0, "SH/L": 0.002}.items():
        inst[key][1] = value
        inst[key][2] = False

    sources = [("MgWO4", MGWO4), ("WO3", args.wo3)]
    if not args.without_mgo:
        sources.append(("MgO", MGO))
    for name, source in sources:
        phase = gpx.add_phase(
            source, phasename=name, histograms=[hist], fmthint="CIF"
        )
        neutralize(phase, hist.name)
        phase.data["Histograms"][hist.name]["Scale"][:] = [1.0, True]

    # Smooth background, common scales, then lattice and one angular correction.
    y = hist.data["data"][1][1]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": [float(np.median(y)), 0.0, 0.0, 0.0, 0.0, 0.0],
            },
        }
    )
    gpx.save()
    refine(gpx, "background_scales")
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    refine(gpx, "cells")
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(gpx, "zero")
    hist.set_refinements({"Instrument Parameters": ["W"]})
    refine(gpx, "W")
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(gpx, "UWX")
    refine(gpx, "replay")

    mass = hist.ComputeMassFracs()
    summary = {
        "project": out,
        "wo3_source": str(Path(args.wo3).resolve()),
        "residuals": {
            k: float(v)
            for k, v in hist.residuals.items()
            if isinstance(v, (int, float, np.integer, np.floating))
        },
        "instrument": {k: float(inst[k][1]) for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")},
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        summary["phases"][phase.name] = {
            "source": next(v for k, v in sources if k == phase.name),
            "scale": float(hap["Scale"][0]),
            "weight_fraction": float(mass[phase.name][0]),
            "weight_fraction_esd": float(mass[phase.name][1]),
            "cell": {k: float(v) for k, v in phase.get_cell().items()},
        }
    Path(out + ".json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
