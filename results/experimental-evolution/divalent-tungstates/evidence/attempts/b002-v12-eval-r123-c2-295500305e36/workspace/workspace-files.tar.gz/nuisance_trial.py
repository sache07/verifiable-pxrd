#!/usr/bin/env python3
"""Replay background/geometry/intensity nuisance trials from one checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument(
        "--trial",
        choices=("background", "polarization", "roughness", "texture", "shl"),
        required=True,
    )
    ap.add_argument("--value", default="")
    ap.add_argument("--phase")
    ap.add_argument("--axis", default="001")
    ap.add_argument("--preserve-existing-texture", action="store_true")
    ap.add_argument("--preserve-polarization", action="store_true")
    ap.add_argument("--cycles", type=int, default=8)
    args = ap.parse_args()

    out = str(Path(args.out).resolve())
    gpx = G2sc.G2Project(args.base, newgpx=out)
    gpx.data["Controls"]["data"]["max cyc"] = args.cycles
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    # Reset all terms under test, including values, before applying one trial.
    if not args.preserve_polarization:
        inst["Polariz."][1:] = [0.5, False]
    inst["SH/L"][1:] = [0.002, False]
    sample["SurfRoughA"][:] = [0.0, False]
    sample["SurfRoughB"][:] = [0.0, False]
    if not args.preserve_existing_texture:
        for phase in gpx.phases():
            po = phase.data["Histograms"][hist.name]["Pref.Ori."]
            po[0] = "MD"
            po[1] = 1.0
            po[2] = False
            po[3] = [0, 0, 1]

    if args.trial == "background":
        hist.set_refinements(
            {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": int(args.value)}}
        )
    elif args.trial == "polarization":
        inst["Polariz."][2] = True
    elif args.trial == "roughness":
        sample["SurfRoughA"][:] = [0.5, True]
        sample["SurfRoughB"][:] = [0.1, True]
    elif args.trial == "shl":
        inst["SH/L"][2] = True
    elif args.trial == "texture":
        if args.phase is None:
            raise ValueError("--phase is required for texture")
        axis = [int(v) for v in args.axis]
        if len(axis) != 3 or not any(axis):
            raise ValueError("--axis must contain three digits and be nonzero")
        po = gpx.phase(args.phase).data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = axis

    gpx.save()
    gpx.do_refinements([{}])
    gpx.save()
    gpx.do_refinements([{}])
    gpx.save()

    mass = hist.ComputeMassFracs()
    cov = gpx.data["Covariance"]["data"]
    summary = {
        "base": str(Path(args.base).resolve()),
        "project": out,
        "trial": args.trial,
        "value": args.value,
        "trial_phase": args.phase,
        "axis": args.axis,
        "Rwp": float(hist.residuals["wR"]),
        "Rp": float(hist.residuals["R"]),
        "GOF": float(cov["Rvals"]["GOF"]),
        "background": {
            "type": hist.data["Background"][0][0],
            "ncoeff": int(hist.data["Background"][0][2]),
            "coeffs": [float(v) for v in hist.data["Background"][0][3:]],
        },
        "instrument": {k: float(inst[k][1]) for k in ("Polariz.", "SH/L", "Zero", "U", "V", "W", "X", "Y")},
        "roughness": {k: float(sample[k][0]) for k in ("SurfRoughA", "SurfRoughB")},
        "phases": {},
        "vary_list": list(cov.get("varyList", [])),
        "sigmas": [float(v) for v in cov.get("sig", [])],
    }
    for phase in gpx.phases():
        h = phase.data["Histograms"][hist.name]
        summary["phases"][phase.name] = {
            "weight_fraction": float(mass[phase.name][0]),
            "weight_fraction_esd": float(mass[phase.name][1]),
            "scale": float(h["Scale"][0]),
            "march_ratio": float(h["Pref.Ori."][1]),
            "march_axis": [int(v) for v in h["Pref.Ori."][3]],
            "march_refine": bool(h["Pref.Ori."][2]),
        }
    Path(out + ".json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
