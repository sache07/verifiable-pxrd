#!/usr/bin/env python3
from pprint import pprint
from GSASII import GSASIIscriptable as G2sc

gpx = G2sc.G2Project(newgpx="probe.gpx")
hist = gpx.add_powder_histogram("inputs/pattern.csv", "instrument.instprm", fmthint="comma")
phase = gpx.add_phase(
    "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/01/39/9013902.cif",
    phasename="MgWO4",
    histograms=[hist],
    fmthint="CIF",
)
print("hist", hist.name)
print("limits")
pprint(hist.data["Limits"])
print("background")
pprint(hist.data["Background"])
print("instrument")
pprint(hist.data["Instrument Parameters"])
print("sample")
pprint(hist.data["Sample Parameters"])
print("phase hist")
pprint(phase.data["Histograms"])
print("cell")
pprint(phase.get_cell())
print("controls")
pprint(gpx.data["Controls"]["data"])
gpx.save()
