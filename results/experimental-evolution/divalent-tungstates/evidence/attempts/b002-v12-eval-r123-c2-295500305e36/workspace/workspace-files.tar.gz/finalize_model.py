#!/usr/bin/env python3
"""Freeze, replay, export and summarize the selected full-range GSAS-II model."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


BASE = Path("trials/loop2_bg9.gpx")
PROJECT = Path("final.gpx")
PHASE_CIFS = {
    "MgWO4": Path("MgWO4.cif"),
    "WO3": Path("WO3.cif"),
    "MgO": Path("MgO.cif"),
}


def neutral_microstructure(hap: dict) -> None:
    """Set all inactive phase-profile terms to physically neutral values."""
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def main() -> None:
    gpx = G2sc.G2Project(str(BASE), newgpx=str(PROJECT.resolve()))
    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = 10
    controls["min dM/M"] = 1e-6

    hist = gpx.histogram(0)
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    hist.data["Background"][0][0] = "chebyschev-1"
    hist.data["Background"][0][1] = True
    hist.data["Background"][0][2] = 9

    inst = hist.data["Instrument Parameters"][0]
    for key, value, refine in (
        ("Lam1", 1.540598, False),
        ("Lam2", 1.544426, False),
        ("I(L2)/I(L1)", 0.5, False),
        ("Zero", inst["Zero"][1], True),
        ("Polariz.", inst["Polariz."][1], True),
        ("U", inst["U"][1], True),
        ("V", 0.0, False),
        ("W", inst["W"][1], True),
        ("X", inst["X"][1], True),
        ("Y", 0.0, False),
        ("Z", 0.0, False),
        ("SH/L", 0.002, False),
    ):
        inst[key][1] = value
        inst[key][2] = refine

    sample = hist.data["Sample Parameters"]
    sample["Scale"][:] = [1.0, False]
    sample["SurfRoughA"][:] = [0.0, False]
    sample["SurfRoughB"][:] = [0.0, False]

    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        neutral_microstructure(hap)
        hap["Scale"][1] = True
        if phase.name == "WO3":
            hap["Mustrain"][0] = "generalized"
            hap["Mustrain"][5][:] = [True] * len(hap["Mustrain"][5])
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [0, 0, 1]
        elif phase.name == "MgWO4":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][4][:] = [0.01] * len(hap["Mustrain"][4])
            hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [0, 1, 0]
        else:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][4][:] = [0.01] * len(hap["Mustrain"][4])
            hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
            hap["Pref.Ori."][3] = [0, 0, 1]

    # Save first so the full-range limits and all pruned values are the actual
    # starting checkpoint. Reopen/replay is done by the second refinement.
    gpx.save()
    gpx.do_refinements([{}])
    gpx.save()
    gpx = G2sc.G2Project(str(PROJECT))
    gpx.data["Controls"]["data"]["max cyc"] = 10
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6
    gpx.do_refinements([{}])
    gpx.save()

    hist = gpx.histogram(0)
    mass = hist.ComputeMassFracs()
    cov = gpx.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    inst = hist.data["Instrument Parameters"][0]

    phases = {}
    for phase in gpx.phases():
        phase.export_CIF(str(PHASE_CIFS[phase.name].resolve()), quickmode=True)
        cell, cell_esd = phase.get_cell_and_esd()
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cif_path": str(PHASE_CIFS[phase.name]),
            "weight_fraction": float(mass[phase.name][0]),
            "weight_fraction_esd": float(mass[phase.name][1]),
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "cell": {k: float(v) for k, v in cell.items()},
            "cell_esd": {k: float(v) for k, v in cell_esd.items()},
            "scale": float(hap["Scale"][0]),
            "march_dollase": {
                "ratio": float(hap["Pref.Ori."][1]),
                "axis": [int(v) for v in hap["Pref.Ori."][3]],
                "refined": bool(hap["Pref.Ori."][2]),
            },
            "size_micrometre": float(hap["Size"][1][0]),
            "mustrain_type": hap["Mustrain"][0],
            "generalized_mustrain": [float(v) for v in hap["Mustrain"][4]],
        }

    x, yobs, weight, ycalc, ybkg, _ = hist.data["data"][1]
    with Path("fit.csv").open("w", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(
            ["two_theta_deg", "observed_counts", "calculated_counts", "background_counts", "difference_counts"]
        )
        for vals in zip(x, yobs, ycalc, ybkg, yobs - ycalc):
            writer.writerow([f"{float(v):.10g}" for v in vals])

    summary = {
        "project_path": str(PROJECT),
        "profile_path": "fit.csv",
        "range_two_theta_deg": [float(hist.data["Limits"][1][0]), float(hist.data["Limits"][1][1])],
        "n_profile_points": int(len(x)),
        "n_observations_refined": int(rvals["Nobs"]),
        "n_variables": int(rvals["Nvars"]),
        "fit_statistics": {
            "Rwp_percent": float(hist.residuals["wR"]),
            "Rp_percent": float(hist.residuals["R"]),
            "Rexp_percent": float(hist.residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "converged": bool(rvals["converged"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
        },
        "instrument": {
            key: float(inst[key][1])
            for key in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")
        },
        "background": {
            "type": hist.data["Background"][0][0],
            "ncoeff": int(hist.data["Background"][0][2]),
            "coefficients": [float(v) for v in hist.data["Background"][0][3:]],
        },
        "phases": phases,
        "weight_fraction_sum": float(sum(v["weight_fraction"] for v in phases.values())),
        "vary_list": list(cov.get("varyList", [])),
        "sigmas": [float(v) for v in cov.get("sig", [])],
    }
    Path("final_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
