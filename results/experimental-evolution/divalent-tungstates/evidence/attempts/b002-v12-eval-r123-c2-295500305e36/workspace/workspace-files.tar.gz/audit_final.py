#!/usr/bin/env python3
"""Numerical audit of the frozen full-range profile and retained weak phase."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.signal import peak_prominences, peak_widths
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIspc as G2spc


def segment_rwp(hist, lo: float, hi: float) -> float:
    x, y, w, yc, _, _ = hist.data["data"][1]
    use = (x >= lo) & (x <= hi)
    return float(100.0 * np.sqrt(np.sum(w[use] * (y[use] - yc[use]) ** 2) / np.sum(w[use] * y[use] ** 2)))


def peak_metric(x: np.ndarray, signal: np.ndarray, target: float, radius: float = 0.12) -> dict:
    use = np.flatnonzero((x >= target - radius) & (x <= target + radius))
    idx = int(use[np.argmax(signal[use])])
    # Move to the nearest strict local maximum if the finite sampling puts the
    # requested point one channel away from it.
    for _ in range(4):
        if idx > 0 and signal[idx - 1] > signal[idx]:
            idx -= 1
        elif idx + 1 < len(signal) and signal[idx + 1] > signal[idx]:
            idx += 1
        else:
            break
    prominence = float(peak_prominences(signal, [idx])[0][0])
    width, _, left, right = peak_widths(signal, [idx], rel_height=0.5)
    left_x = float(np.interp(left[0], np.arange(len(x)), x))
    right_x = float(np.interp(right[0], np.arange(len(x)), x))
    pos = float(x[idx])
    return {
        "position_deg": pos,
        "prominence_counts": prominence,
        "left_half_width_deg": pos - left_x,
        "right_half_width_deg": right_x - pos,
        "FWHM_deg": right_x - left_x,
    }


def local_residual(hist, target: float, radius: float = 0.18) -> dict:
    x, y, w, yc, _, _ = hist.data["data"][1]
    use = (x >= target - radius) & (x <= target + radius)
    diff = y[use] - yc[use]
    return {
        "local_Rwp_percent": float(100.0 * np.sqrt(np.sum(w[use] * diff**2) / np.sum(w[use] * y[use] ** 2))),
        "max_abs_difference_counts": float(np.max(np.abs(diff))),
        "mean_difference_counts": float(np.mean(diff)),
    }


def main() -> None:
    final = G2sc.G2Project("final.gpx")
    hist = final.histogram(0)
    no_mgo = G2sc.G2Project("trials/no_mgo_texture.gpx").histogram(0)

    x, y, _, yc, yb, _ = hist.data["data"][1]
    targets = {
        "low_MgWO4_100": 18.8791,
        "low_WO3_20m2": 23.1170,
        "middle_MgO_200": 42.9373,
        "middle_high_MgO_220": 62.2577,
        "high_MgWO4_400": 82.0020,
    }
    peaks = {
        name: {
            "observed": peak_metric(x, y - yb, target),
            "calculated": peak_metric(x, yc - yb, target),
        }
        for name, target in targets.items()
    }

    mgo_targets = [42.9373, 62.2577, 78.6117, 94.1615]
    mgo_challenge = {
        f"{target:.4f}": {
            "with_MgO": local_residual(hist, target),
            "without_MgO": local_residual(no_mgo, target),
        }
        for target in mgo_targets
    }

    wo3 = final.phase("WO3")
    hap = wo3.data["Histograms"][hist.name]
    shkl = hap["Mustrain"][4]
    sums = []
    for ref in hist.data["Reflection Lists"]["WO3"]["RefList"]:
        coeff = G2spc.MustrainCoeff(ref[:3], wo3.data["General"]["SGData"])
        sums.append(float(np.dot(shkl, coeff)))

    fractions = hist.ComputeMassFracs()
    mgwo4 = float(fractions["MgWO4"][0])
    wo3f = float(fractions["WO3"][0])
    mgof = float(fractions["MgO"][0])
    n_mg = mgwo4 / 272.141 + mgof / 40.304
    n_w = mgwo4 / 272.141 + wo3f / 231.837

    audit = {
        "segment_Rwp_percent": {
            "low_9.903_35": segment_rwp(hist, 9.90343322, 35.0),
            "middle_35_65": segment_rwp(hist, 35.0, 65.0),
            "high_65_100.095": segment_rwp(hist, 65.0, 100.09455322),
        },
        "peak_shape_audit": peaks,
        "MgO_removal_challenge": mgo_challenge,
        "WO3_generalized_mustrain_polynomial": {
            "n_reflections_checked": len(sums),
            "minimum": min(sums),
            "maximum": max(sums),
            "all_positive": all(v > 0 for v in sums),
        },
        "phase_balance": {
            "Mg_to_W_molar_ratio_from_crystalline_phases": n_mg / n_w,
            "residual_MgO_to_WO3_molar_ratio": (mgof / 40.304) / (wo3f / 231.837),
        },
    }
    Path("audit_final.json").write_text(json.dumps(audit, indent=2) + "\n")
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
