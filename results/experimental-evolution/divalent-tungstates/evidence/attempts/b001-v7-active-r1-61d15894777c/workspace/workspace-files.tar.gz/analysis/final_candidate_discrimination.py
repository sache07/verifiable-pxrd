#!/usr/bin/env python3
"""Texture and compatible anisotropy challenges of the selected four-phase candidate."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis/candidates/massicot_size_w_bg12.gpx"
OUT = ROOT / "analysis/final_discrimination"

TEXTURE = {
    "texture_p0_001": (0, [0, 0, 1]),
    "texture_p0_112": (0, [1, 1, 2]),
    "texture_p1_010": (1, [0, 1, 0]),
    "texture_p1_111": (1, [1, 1, 1]),
    "texture_p2_001": (2, [0, 0, 1]),
    "texture_p2_110": (2, [1, 1, 0]),
    "texture_p3_100": (3, [1, 0, 0]),
    "texture_p3_010": (3, [0, 1, 0]),
    "texture_p3_001": (3, [0, 0, 1]),
    "texture_p3_110": (3, [1, 1, 0]),
    "texture_p3_111": (3, [1, 1, 1]),
}

ANISOTROPY = {
    "usize_p2_001": (2, [0, 0, 1]),
    "usize_p2_110": (2, [1, 1, 0]),
    "usize_p3_100": (3, [1, 0, 0]),
    "usize_p3_001": (3, [0, 0, 1]),
    "usize_p3_111": (3, [1, 1, 1]),
}

TRIALS = sorted([*TEXTURE, *ANISOTROPY, "wo3_isotropic_strain"])


def apply_trial(gpx: G2sc.G2Project, trial: str) -> None:
    hist = gpx.histograms("PWDR")[0]
    if trial in TEXTURE:
        pidx, axis = TEXTURE[trial]
        po = gpx.phases()[pidx].getHAPvalues(hist.name)["Pref.Ori."]
        po[0:4] = ["MD", 1.0, True, axis]
        gpx.set_Controls("parmMin", 0.2, variable=f"{pidx}:0:MD")
        gpx.set_Controls("parmMax", 5.0, variable=f"{pidx}:0:MD")
        return
    if trial in ANISOTROPY:
        pidx, axis = ANISOTROPY[trial]
        size = gpx.phases()[pidx].getHAPvalues(hist.name)["Size"]
        seed = float(size[1][0])
        size[0] = "uniaxial"
        size[1] = [seed, seed, 1.0]
        size[2] = [True, True, False]
        size[3] = axis
        for term in ("i", "a"):
            gpx.set_Controls("parmMin", 0.001, variable=f"{pidx}:0:Size;{term}")
            gpx.set_Controls("parmMax", 10.0, variable=f"{pidx}:0:Size;{term}")
        return
    if trial == "wo3_isotropic_strain":
        strain = gpx.phases()[1].getHAPvalues(hist.name)["Mustrain"]
        strain[0] = "isotropic"
        strain[1][0] = 300.0
        strain[2][0] = True
        gpx.set_Controls("parmMin", 0.0, variable="1:0:Mustrain;i")
        gpx.set_Controls("parmMax", 50000.0, variable="1:0:Mustrain;i")
        return
    raise ValueError(trial)


def correlations(gpx: G2sc.G2Project) -> list[dict]:
    cov = gpx.data["Covariance"]["data"]
    names = [str(v) for v in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if not matrix.size:
        return []
    sig = np.sqrt(np.clip(np.diag(matrix), 0.0, None))
    den = np.outer(sig, sig)
    corr = np.divide(matrix, den, out=np.zeros_like(matrix), where=den != 0)
    pairs = []
    for i in range(len(names)):
        for j in range(i):
            pairs.append((abs(corr[i, j]), float(corr[i, j]), names[i], names[j]))
    return [
        {"correlation": c, "variables": [vi, vj]}
        for _, c, vi, vj in sorted(pairs, reverse=True)[:12]
    ]


def run(trial: str) -> dict:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"{trial}.gpx"
    gpx = G2sc.G2Project(str(BASE))
    gpx.save(str(target))
    gpx.set_Frozen()
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["shift factor"] = 0.2
    apply_trial(gpx, trial)
    for _ in range(2):
        gpx.refine()
        gpx.save()
    replay = G2sc.G2Project(str(target))
    replay.set_Controls("cycles", 12)
    replay.data["Controls"]["data"]["shift factor"] = 0.2
    replay.refine()
    replay.save()

    hist = replay.histograms("PWDR")[0]
    cov = replay.data["Covariance"]["data"]
    dep = cov.get("depSigDict", {})
    phases = []
    for i, phase in enumerate(replay.phases()):
        hap = phase.getHAPvalues(hist.name)
        phases.append(
            {
                "name": phase.name,
                "weight_fraction": dep.get(f"{i}:0:WgtFrac", [None, None])[0],
                "preferred_orientation": hap["Pref.Ori."],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    result = {
        "trial": trial,
        "project": str(target),
        "r_wp_percent": hist.get_wR(),
        "r_exp_percent": hist.residuals.get("wRmin"),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "phases": phases,
        "frozen": replay.get_Frozen(),
        "rvals": cov.get("Rvals", {}),
        "top_correlations": correlations(replay),
    }
    (OUT / f"{trial}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "trial": trial,
                "Rwp": result["r_wp_percent"],
                "GOF": result["gof"],
                "fractions": [p["weight_fraction"] for p in phases],
                "PO": [p["preferred_orientation"][:4] for p in phases],
                "sizes": [p["size"][:4] for p in phases],
                "WO3_strain": phases[1]["mustrain"][:3],
                "frozen": result["frozen"],
                "top_corr": result["top_correlations"][:4],
            },
            indent=2,
        ),
        flush=True,
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("trials", nargs="+", choices=TRIALS)
    args = parser.parse_args()
    for trial in args.trials:
        run(trial)


if __name__ == "__main__":
    main()
