#!/usr/bin/env python3
"""Refine candidate phase inventories with one restrained nuisance model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

SOURCES = {
    "pbwo4_290k": COD / "9/00/98/9009811.cif",
    "pbwo4_old": COD / "1/52/79/1527935.cif",
    "pbwo4_monoclinic": COD / "9/00/76/9007617.cif",
    "wo3_tanisaki": COD / "1/52/89/1528915.cif",
    "wo3_loopstra": COD / "2/31/10/2311041.cif",
    "wo3_triclinic": COD / "2/10/62/2106293.cif",
    "wo3_orthorhombic": COD / "2/10/73/2107312.cif",
    "pb3o4_293k": COD / "9/01/21/9012124.cif",
    "pb3o4_240k": COD / "9/01/34/9013442.cif",
}

MODELS = {
    "two_tanisaki": ["pbwo4_290k", "wo3_tanisaki"],
    "two_loopstra": ["pbwo4_290k", "wo3_loopstra"],
    "two_triclinic": ["pbwo4_290k", "wo3_triclinic"],
    "two_orthorhombic": ["pbwo4_290k", "wo3_orthorhombic"],
    "three_293k": ["pbwo4_290k", "wo3_tanisaki", "pb3o4_293k"],
    "three_loopstra": ["pbwo4_290k", "wo3_loopstra", "pb3o4_293k"],
    "three_triclinic": ["pbwo4_290k", "wo3_triclinic", "pb3o4_293k"],
    "three_ortho_wo3": ["pbwo4_290k", "wo3_orthorhombic", "pb3o4_293k"],
    "three_240k": ["pbwo4_290k", "wo3_tanisaki", "pb3o4_240k"],
    "three_old_pbwo4": ["pbwo4_old", "wo3_tanisaki", "pb3o4_293k"],
    "three_mono_pbwo4": ["pbwo4_monoclinic", "wo3_tanisaki", "pb3o4_293k"],
}


def neutralize_hap(phase: G2sc.G2Phase) -> None:
    phase.clear_HAP_refinements(
        {
            "Scale": True,
            "HStrain": True,
            "Mustrain": True,
            "Size": True,
            "Pref.Ori.": True,
            "Extinction": True,
            "Babinet": ["BabA", "BabU"],
        }
    )
    for hap in phase.data["Histograms"].values():
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:2] = [10.0, 10.0]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:2] = [0.0, 0.0]
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Pref.Ori."][1:3] = [1.0, False]
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]
    phase.set_HAP_refinements({"Scale": True})


def configure_histogram(hist: G2sc.G2PwdrData) -> None:
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [1400.0, -900.0, 350.0, -150.0, 60.0, -20.0, 0.0, 0.0, 0.0, 0.0],
                "refine": True,
            }
        }
    )
    sample = hist.SampleParameters
    sample["Gonio. radius"] = 240.0
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [-850.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    inst = hist.InstrumentParameters
    fixed = {
        "Zero": 0.0,
        "U": 0.0,
        "V": 0.0,
        "W": 0.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "Polariz.": 0.5,
        "I(L2)/I(L1)": 0.5,
    }
    for key, value in fixed.items():
        inst[key][1:] = [value, False]
    inst["X"][1:] = [12.0, False]


def extract(gpx: G2sc.G2Project, model: str, sources: list[str]) -> dict:
    hist = gpx.histograms("PWDR")[0]
    dep = gpx.data["Covariance"]["data"].get("depSigDict", {})
    phases = []
    for i, (phase, source) in enumerate(zip(gpx.phases(), sources)):
        wf, wf_sig = dep.get(f"{i}:0:WgtFrac", (None, None))
        scale, scale_sig = dep.get(f"{i}:0:Scale", (None, None))
        phases.append(
            {
                "name": phase.name,
                "source": source,
                "cell": phase.get_cell(),
                "scale": scale,
                "scale_esd": scale_sig,
                "weight_fraction": wf,
                "weight_fraction_esd": wf_sig,
            }
        )
    result = {
        "model": model,
        "project": str(ROOT / f"analysis/screens/{model}.gpx"),
        "wR": hist.get_wR(),
        "residuals": hist.residuals,
        "gof": hist.residuals.get("wR", 0.0) / hist.residuals.get("wRmin", 1.0),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": phases,
    }
    return result


def run(model: str) -> dict:
    sources = MODELS[model]
    screen_dir = ROOT / "analysis/screens"
    screen_dir.mkdir(parents=True, exist_ok=True)
    path = screen_dir / f"{model}.gpx"
    gpx = G2sc.G2Project(newgpx=str(path))
    gpx.set_Controls("cycles", 8)
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "analysis/instrument.instprm"),
        fmthint="comma",
    )
    configure_histogram(hist)
    phases = []
    for source in sources:
        phase = gpx.add_phase(
            str(SOURCES[source]), phasename=source, histograms=[hist], fmthint="CIF"
        )
        neutralize_hap(phase)
        phases.append(phase)
    gpx.save()

    print(f"{model}: background + scales", flush=True)
    gpx.refine()
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    print(f"{model}: cells + displacement", flush=True)
    gpx.refine()
    hist.set_refinements({"Instrument Parameters": ["X"]})
    print(f"{model}: common X profile", flush=True)
    gpx.refine()
    gpx.save()

    # A save/reopen/replay catches state that was not serialized consistently.
    replay = G2sc.G2Project(str(path))
    print(f"{model}: reopened replay", flush=True)
    replay.refine()
    replay.save()
    result = extract(replay, model, sources)
    (screen_dir / f"{model}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "model": model,
                "wR": result["wR"],
                "gof": result["gof"],
                "fractions": {
                    p["name"]: p["weight_fraction"] for p in result["phases"]
                },
                "X": result["instrument"]["X"][1],
                "shift": result["sample"]["Shift"][0],
            },
            indent=2,
        ),
        flush=True,
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("models", nargs="+", choices=MODELS)
    args = parser.parse_args()
    results = [run(model) for model in args.models]
    print(json.dumps(results, indent=2), flush=True)


if __name__ == "__main__":
    main()
