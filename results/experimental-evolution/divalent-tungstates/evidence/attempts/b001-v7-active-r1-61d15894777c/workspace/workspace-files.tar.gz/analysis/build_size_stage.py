#!/usr/bin/env python3
"""Combine replay-supported isotropic size terms for PbWO4 and Pb3O4."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis/trials/pol_bg8/size_p0.gpx"
TARGET = ROOT / "analysis/stages/pol_bg8_size02.gpx"


def report(gpx: G2sc.G2Project, label: str) -> None:
    hist = gpx.histograms("PWDR")[0]
    sizes = [p.getHAPvalues(hist.name)["Size"][1][0] for p in gpx.phases()]
    shifts = gpx.data["Covariance"]["data"].get("Lastshft")
    print(label, "Rwp", hist.get_wR(), "size_um", sizes, "last_shift", shifts, flush=True)


def main() -> None:
    gpx = G2sc.G2Project(str(SOURCE))
    gpx.save(str(TARGET))
    gpx.set_Frozen()
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["shift factor"] = 0.2
    hist = gpx.histograms("PWDR")[0]
    phases = gpx.phases()
    # Retain PbWO4 isotropic size from the accepted one-phase test and add
    # the independently supported Pb3O4 size term; leave WO3 neutral.
    phases[0].set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 0.11, "refine": True}}
    )
    phases[2].set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 0.06, "refine": True}}
    )
    for i in range(4):
        gpx.refine()
        gpx.save()
        report(gpx, f"pass{i + 1}")
    replay = G2sc.G2Project(str(TARGET))
    replay.set_Controls("cycles", 12)
    replay.data["Controls"]["data"]["shift factor"] = 0.2
    replay.refine()
    replay.save()
    report(replay, "reopened")


if __name__ == "__main__":
    main()
