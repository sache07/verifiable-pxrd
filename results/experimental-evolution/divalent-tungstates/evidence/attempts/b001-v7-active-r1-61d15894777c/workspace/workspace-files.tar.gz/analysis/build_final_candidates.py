#!/usr/bin/env python3
"""Build size- and strain-broadened massicot candidates with shared W/U/X and bg12."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCES = {
    "massicot_size": ROOT / "analysis/post_combo/massicot_size.gpx",
    "massicot_strain": ROOT / "analysis/post_combo/massicot_strain.gpx",
}
OUT = ROOT / "analysis/candidates"


def top_correlations(gpx: G2sc.G2Project) -> list[dict]:
    cov = gpx.data["Covariance"]["data"]
    names = [str(v) for v in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if not matrix.size:
        return []
    sig = np.sqrt(np.clip(np.diag(matrix), 0.0, None))
    den = np.outer(sig, sig)
    corr = np.divide(matrix, den, out=np.zeros_like(matrix), where=den != 0)
    pairs = []
    for i in range(len(names)):
        for j in range(i):
            pairs.append((abs(corr[i, j]), float(corr[i, j]), names[i], names[j]))
    return [
        {"correlation": c, "variables": [vi, vj]}
        for _, c, vi, vj in sorted(pairs, reverse=True)[:12]
    ]


def run(candidate: str) -> dict:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"{candidate}_w_bg12.gpx"
    gpx = G2sc.G2Project(str(SOURCES[candidate]))
    gpx.save(str(target))
    gpx.set_Frozen()
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["shift factor"] = 0.2
    hist = gpx.histograms("PWDR")[0]
    hist.set_refinements({"Background": {"no. coeffs": 12, "refine": True}})
    hist.InstrumentParameters["W"][1:] = [3.0, True]
    gpx.set_Controls("parmMin", 0.0, variable=":0:W")
    for _ in range(4):
        gpx.refine()
        gpx.save()
    replay = G2sc.G2Project(str(target))
    replay.set_Controls("cycles", 12)
    replay.data["Controls"]["data"]["shift factor"] = 0.2
    replay.refine()
    replay.save()

    hist = replay.histograms("PWDR")[0]
    cov = replay.data["Covariance"]["data"]
    dep = cov.get("depSigDict", {})
    phases = []
    for i, phase in enumerate(replay.phases()):
        hap = phase.getHAPvalues(hist.name)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "weight_fraction": dep.get(f"{i}:0:WgtFrac", [None, None])[0],
                "weight_fraction_sigma": dep.get(f"{i}:0:WgtFrac", [None, None])[1],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    result = {
        "candidate": candidate,
        "project": str(target),
        "r_wp_percent": hist.get_wR(),
        "r_exp_percent": hist.residuals.get("wRmin"),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": phases,
        "frozen": replay.get_Frozen(),
        "rvals": cov.get("Rvals", {}),
        "top_correlations": top_correlations(replay),
    }
    (OUT / f"{candidate}_w_bg12.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    print(
        json.dumps(
            {
                "candidate": candidate,
                "Rwp": result["r_wp_percent"],
                "GOF": result["gof"],
                "U_W_X": [hist.InstrumentParameters[k][1] for k in ("U", "W", "X")],
                "sizes": [p["size"][1][0] for p in phases],
                "strains": [p["mustrain"][1][0] for p in phases],
                "fractions": [p["weight_fraction"] for p in phases],
                "frozen": result["frozen"],
                "last": result["rvals"].get("Max shft/sig"),
                "top_corr": result["top_correlations"][:4],
            },
            indent=2,
        ),
        flush=True,
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidates", nargs="+", choices=sorted(SOURCES))
    args = parser.parse_args()
    for candidate in args.candidates:
        run(candidate)


if __name__ == "__main__":
    main()
