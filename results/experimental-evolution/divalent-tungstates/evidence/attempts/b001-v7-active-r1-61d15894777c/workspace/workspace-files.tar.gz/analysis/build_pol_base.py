#!/usr/bin/env python3
"""Create the accepted polarization/background baseline for profile tests."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis/screens/three_loopstra.gpx"
TARGET = ROOT / "analysis/stages/pol_bg8.gpx"


def main() -> None:
    TARGET.parent.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(str(SOURCE))
    gpx.save(str(TARGET))
    gpx.set_Controls("cycles", 8)
    gpx.set_Frozen()
    hist = gpx.histograms("PWDR")[0]
    hist.set_refinements({"Background": {"no. coeffs": 8, "refine": True}})
    hist.InstrumentParameters["Polariz."][1:] = [1.0, False]
    hist.InstrumentParameters["U"][1:] = [0.0, False]
    hist.InstrumentParameters["W"][1:] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    gpx.refine()
    gpx.save()
    replay = G2sc.G2Project(str(TARGET))
    replay.refine()
    replay.save()
    h = replay.histograms("PWDR")[0]
    print(
        {
            "wR": h.get_wR(),
            "gof": h.residuals["wR"] / h.residuals["wRmin"],
            "polarization": h.InstrumentParameters["Polariz."],
            "background_terms": h.Background[0][2],
            "frozen": replay.get_Frozen(),
        }
    )


if __name__ == "__main__":
    main()
