#!/usr/bin/env python3
"""Final compatible anisotropy challenge for the dominant scheelite phase."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from final_candidate_discrimination import correlations


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "final.gpx"
OUT = ROOT / "analysis/pbwo4_anisotropy"
TRIALS = {
    "size_001": ("size", [0, 0, 1]),
    "size_110": ("size", [1, 1, 0]),
    "size_112": ("size", [1, 1, 2]),
    "strain_001": ("strain", [0, 0, 1]),
    "strain_110": ("strain", [1, 1, 0]),
}


def run(name: str, kind: str, axis: list[int]) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"{name}.gpx"
    gpx = G2sc.G2Project(str(BASE))
    gpx.save(str(target))
    gpx.set_Frozen()
    gpx.set_Controls("cycles", 16)
    gpx.data["Controls"]["data"]["shift factor"] = 0.1
    hist = gpx.histograms("PWDR")[0]
    hap = gpx.phases()[0].getHAPvalues(hist.name)
    if kind == "size":
        size = hap["Size"]
        seed = float(size[1][0])
        size[0] = "uniaxial"
        size[1] = [seed, seed, 1.0]
        size[2] = [True, True, False]
        size[3] = axis
        for suffix in ("i", "a"):
            gpx.set_Controls("parmMin", 0.001, variable=f"0:0:Size;{suffix}")
            gpx.set_Controls("parmMax", 10.0, variable=f"0:0:Size;{suffix}")
    else:
        strain = hap["Mustrain"]
        strain[0] = "uniaxial"
        strain[1] = [100.0, 100.0, 1.0]
        strain[2] = [True, True, False]
        strain[3] = axis
        for suffix in ("i", "a"):
            gpx.set_Controls("parmMin", 0.0, variable=f"0:0:Mustrain;{suffix}")
            gpx.set_Controls("parmMax", 50000.0, variable=f"0:0:Mustrain;{suffix}")
    for _ in range(2):
        gpx.refine()
        gpx.save()
    replay = G2sc.G2Project(str(target))
    replay.set_Controls("cycles", 16)
    replay.data["Controls"]["data"]["shift factor"] = 0.1
    replay.refine()
    replay.save()

    hist = replay.histograms("PWDR")[0]
    cov = replay.data["Covariance"]["data"]
    dep = cov.get("depSigDict", {})
    result = {
        "trial": name,
        "project": str(target),
        "r_wp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "fractions": [dep[f"{i}:0:WgtFrac"][0] for i in range(5)],
        "size": replay.phases()[0].getHAPvalues(hist.name)["Size"],
        "mustrain": replay.phases()[0].getHAPvalues(hist.name)["Mustrain"],
        "frozen": replay.get_Frozen(),
        "top_correlations": correlations(replay),
    }
    (OUT / f"{name}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    for trial_name, (trial_kind, trial_axis) in TRIALS.items():
        run(trial_name, trial_kind, trial_axis)
