#!/usr/bin/env python3
"""Build a clean four-phase nuisance/profile baseline after finding massicot."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis/watchlist/massicot_PbO.gpx"
TARGET = ROOT / "analysis/stages/four_baseline.gpx"


def neutralize_hap(phase: G2sc.G2Phase, hist_name: str) -> None:
    hap = phase.getHAPvalues(hist_name)
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def report(gpx: G2sc.G2Project, label: str) -> None:
    hist = gpx.histograms("PWDR")[0]
    cov = gpx.data["Covariance"]["data"]
    dep = cov.get("depSigDict", {})
    print(
        label,
        "Rwp",
        hist.get_wR(),
        "GOF",
        cov.get("Rvals", {}).get("GOF"),
        "fractions",
        [dep.get(f"{i}:0:WgtFrac", [None])[0] for i in range(len(gpx.phases()))],
        "X",
        hist.InstrumentParameters["X"][1],
        "shift",
        hist.SampleParameters["Shift"][0],
        "last",
        cov.get("Rvals", {}).get("Max shft/sig"),
        flush=True,
    )


def main() -> None:
    gpx = G2sc.G2Project(str(SOURCE))
    gpx.save(str(TARGET))
    gpx.set_Frozen()
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["shift factor"] = 0.2
    hist = gpx.histograms("PWDR")[0]

    # Reassert the accepted low-dimensional geometry/nuisance model.
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.set_refinements({"Background": {"no. coeffs": 8, "refine": True}})
    for key, value in {
        "U": 0.0,
        "V": 0.0,
        "W": 0.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "Polariz.": 1.0,
        "Zero": 0.0,
    }.items():
        hist.InstrumentParameters[key][1:] = [value, False]
    hist.InstrumentParameters["X"][2] = True
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"][1] = True
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    gpx.set_Controls("parmMin", 0.0, variable=":0:X")

    for i, phase in enumerate(gpx.phases()):
        neutralize_hap(phase, hist.name)
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})
        gpx.set_Controls("parmMin", 0.0, variable=f"{i}:0:Scale")

    for i in range(4):
        gpx.refine()
        gpx.save()
        report(gpx, f"pass{i + 1}")

    replay = G2sc.G2Project(str(TARGET))
    replay.set_Controls("cycles", 12)
    replay.data["Controls"]["data"]["shift factor"] = 0.2
    replay.refine()
    replay.save()
    report(replay, "reopened")


if __name__ == "__main__":
    main()
