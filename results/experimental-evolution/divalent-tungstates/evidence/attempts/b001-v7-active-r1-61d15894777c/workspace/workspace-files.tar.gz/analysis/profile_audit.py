#!/usr/bin/env python3
"""Numerically audit isolated low/mid/high peaks for each candidate phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from scipy.signal import savgol_filter


ROOT = Path(__file__).resolve().parents[1]
CANDIDATES = {
    "massicot_size": ROOT / "analysis/candidates/massicot_size_w_bg12.gpx",
    "massicot_strain": ROOT / "analysis/candidates/massicot_strain_w_bg12.gpx",
    "final_five_phase": ROOT / "final.gpx",
}
OUT = ROOT / "analysis/audit"

# The reflections were chosen for high intensity and the best available
# separation from other appreciable-phase families in each angular third.
PEAKS = {
    "pbwo4_290k": [
        ("low", (1, 1, 2), 0.35),
        ("middle", (0, 2, 4), 0.45),
        ("high", (4, 2, 4), 0.70),
    ],
    "wo3_loopstra": [
        ("low", (2, 0, -2), 0.35),
        ("middle", (2, 2, -4), 0.40),
        ("high", (6, 1, -9), 0.75),
    ],
    "pb3o4_293k": [
        ("low", (2, 1, 1), 0.45),
        ("middle", (3, 3, 2), 0.55),
        ("high", (6, 1, 1), 0.65),
    ],
    "massicot_PbO": [
        ("low", (1, 1, 1), 0.55),
        ("middle", (3, 1, 1), 0.65),
        ("high", (3, 1, 3), 0.80),
    ],
    # No fully isolated high-angle line exists for this weak, closely related
    # WO3 polymorph. These are the least-contaminated usable local maxima in
    # each angular third and their overlap/SNR is reported explicitly.
    "triclinic_WO3": [
        ("low", (2, 2, 0), 0.45),
        ("middle", (0, 4, 0), 0.55),
        ("high", (1, 6, 0), 0.75),
    ],
}


def reflection_position(hist: G2sc.G2PwdrData, phase: str, hkl: tuple[int, int, int]) -> float:
    rows = np.asarray(hist.reflections()[phase]["RefList"])
    match = rows[np.all(rows[:, :3].astype(int) == np.asarray(hkl), axis=1)]
    if not len(match):
        raise KeyError(f"Reflection {phase} {hkl} not found")
    return float(match[0, 5])


def phase_only_profile(project: Path, pidx: int, label: str) -> np.ndarray:
    target = OUT / f"{label}_phase{pidx}.gpx"
    gpx = G2sc.G2Project(str(project))
    gpx.save(str(target))
    hist = gpx.histograms("PWDR")[0]
    for i, phase in enumerate(gpx.phases()):
        hap = phase.getHAPvalues(hist.name)
        hap["Scale"] = [float(hap["Scale"][0]) if i == pidx else 0.0, False]
    hist.Background[0][1] = False
    for i in range(3, len(hist.Background[0])):
        hist.Background[0][i] = 0.0
    gpx.set_Controls("cycles", 0)
    gpx.refine()
    gpx.save()
    return np.asarray(hist.getdata("ycalc"), dtype=float)


def quadratic_apex(x: np.ndarray, y: np.ndarray, i: int) -> tuple[float, float]:
    if i <= 0 or i >= len(x) - 1:
        return float(x[i]), float(y[i])
    xp = x[i - 1 : i + 2]
    yp = y[i - 1 : i + 2]
    coeff = np.polyfit(xp, yp, 2)
    if coeff[0] >= 0:
        return float(x[i]), float(y[i])
    xv = -coeff[1] / (2.0 * coeff[0])
    if xv < xp[0] or xv > xp[-1]:
        return float(x[i]), float(y[i])
    return float(xv), float(np.polyval(coeff, xv))


def crossing(x1: float, y1: float, x2: float, y2: float, level: float) -> float:
    if y2 == y1:
        return 0.5 * (x1 + x2)
    return float(x1 + (level - y1) * (x2 - x1) / (y2 - y1))


def measure_peak(
    x: np.ndarray,
    y: np.ndarray,
    expected: float,
    half_window: float,
    smooth: bool,
) -> dict:
    mask = (x >= expected - half_window) & (x <= expected + half_window)
    xx = x[mask]
    yy = y[mask].astype(float)
    if len(xx) < 15:
        raise ValueError("Peak window too small")

    # Remove any slowly varying carry-through from imperfect subtraction using
    # the two outer 12% portions of the local window.
    nedge = max(3, int(0.12 * len(xx)))
    edge_x = np.r_[xx[:nedge], xx[-nedge:]]
    edge_y = np.r_[yy[:nedge], yy[-nedge:]]
    baseline = np.polyval(np.polyfit(edge_x, edge_y, 1), xx)
    net = yy - baseline
    if smooth:
        win = min(11, len(net) - (1 - len(net) % 2))
        if win % 2 == 0:
            win -= 1
        if win >= 5:
            net = savgol_filter(net, win, 3, mode="interp")

    # Keep the apex tied to the selected reflection rather than a stronger
    # neighbour that may enter the wider half-height window.
    search_half = min(0.16, 0.35 * half_window)
    search = (xx >= expected - search_half) & (xx <= expected + search_half)
    indices = np.flatnonzero(search)
    apex_i = int(indices[np.argmax(net[search])])
    center, height = quadratic_apex(xx, net, apex_i)
    level = 0.5 * height

    left_i = apex_i
    while left_i > 0 and net[left_i] > level:
        left_i -= 1
    right_i = apex_i
    while right_i < len(net) - 1 and net[right_i] > level:
        right_i += 1
    if left_i == 0 or right_i == len(net) - 1:
        return {
            "position_deg": center,
            "height_counts": height,
            "fwhm_deg": None,
            "left_half_width_deg": None,
            "right_half_width_deg": None,
            "status": "half-height crossing outside window",
        }

    left = crossing(xx[left_i], net[left_i], xx[left_i + 1], net[left_i + 1], level)
    right = crossing(
        xx[right_i - 1], net[right_i - 1], xx[right_i], net[right_i], level
    )
    return {
        "position_deg": center,
        "height_counts": height,
        "fwhm_deg": right - left,
        "left_half_width_deg": center - left,
        "right_half_width_deg": right - center,
        "status": "ok",
    }


def audit(candidate: str) -> dict:
    OUT.mkdir(parents=True, exist_ok=True)
    project = CANDIDATES[candidate]
    gpx = G2sc.G2Project(str(project))
    hist = gpx.histograms("PWDR")[0]
    x = np.asarray(hist.getdata("x"), dtype=float)
    yobs = np.asarray(hist.getdata("yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("ycalc"), dtype=float)
    background = np.asarray(hist.getdata("background"), dtype=float)
    residual = yobs - ycalc

    rows = []
    for pidx, phase in enumerate(gpx.phases()):
        phase_calc = phase_only_profile(project, pidx, candidate)
        phase_observed_estimate = phase_calc + residual
        for region, hkl, half_window in PEAKS[phase.name]:
            expected = reflection_position(hist, phase.name, hkl)
            calc = measure_peak(x, phase_calc, expected, half_window, smooth=False)
            obs = measure_peak(
                x, phase_observed_estimate, expected, half_window, smooth=True
            )
            apex_idx = int(np.argmin(np.abs(x - calc["position_deg"])))
            total_net = max(float(ycalc[apex_idx] - background[apex_idx]), 1e-12)
            contamination = max(0.0, 1.0 - float(phase_calc[apex_idx]) / total_net)
            counting_snr = float(calc["height_counts"] / np.sqrt(max(yobs[apex_idx], 1.0)))
            rows.append(
                {
                    "phase": phase.name,
                    "region": region,
                    "hkl": list(hkl),
                    "reflection_position_deg": expected,
                    "observed": obs,
                    "calculated": calc,
                    "estimated_other_phase_fraction_at_calc_apex": contamination,
                    "calculated_height_over_counting_sigma": counting_snr,
                }
            )
    result = {"candidate": candidate, "project": str(project), "peaks": rows}
    (OUT / f"{candidate}_peak_audit.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    for row in rows:
        o, c = row["observed"], row["calculated"]
        print(
            row["phase"],
            row["region"],
            row["hkl"],
            "obs",
            [o[k] for k in ("position_deg", "fwhm_deg", "left_half_width_deg", "right_half_width_deg")],
            "calc",
            [c[k] for k in ("position_deg", "fwhm_deg", "left_half_width_deg", "right_half_width_deg")],
            "other",
            row["estimated_other_phase_fraction_at_calc_apex"],
            "snr",
            row["calculated_height_over_counting_sigma"],
            flush=True,
        )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidates", nargs="+", choices=sorted(CANDIDATES))
    args = parser.parse_args()
    for candidate in args.candidates:
        audit(candidate)


if __name__ == "__main__":
    main()
