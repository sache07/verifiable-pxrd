#!/usr/bin/env python3
"""Controlled texture and directional-strain challenges of the final baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis/trials/pol_bg8_size02/strain_p1.gpx"
OUT = ROOT / "analysis/discrimination"

TEXTURE_TRIALS = {
    # Axial and diagonal directions for each phase. These are deliberately
    # low-dimensional March-Dollase challenges, not an SH texture expansion.
    "texture_p0_001": (0, [0, 0, 1]),
    "texture_p0_112": (0, [1, 1, 2]),
    "texture_p1_010": (1, [0, 1, 0]),
    "texture_p1_111": (1, [1, 1, 1]),
    "texture_p2_001": (2, [0, 0, 1]),
    "texture_p2_110": (2, [1, 1, 0]),
}

STRAIN_TRIALS = {
    # Monoclinic WO3 is the only phase for which an isotropic strain term was
    # replay-supported. Challenge it with physically simple uniaxial models.
    "uniaxial_p1_100": [1, 0, 0],
    "uniaxial_p1_010": [0, 1, 0],
    "uniaxial_p1_001": [0, 0, 1],
    "uniaxial_p1_111": [1, 1, 1],
}


def covariance_summary(gpx: G2sc.G2Project) -> dict:
    cov = gpx.data["Covariance"]["data"]
    vary = [str(v) for v in cov.get("varyList", [])]
    vals = list(cov.get("variables", []))
    sig = list(cov.get("sig", []))
    corr_out = []
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.size and len(vary) == matrix.shape[0]:
        d = np.sqrt(np.clip(np.diag(matrix), 0.0, None))
        denom = np.outer(d, d)
        corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom != 0)
        pairs = []
        for i in range(len(vary)):
            for j in range(i):
                pairs.append((abs(corr[i, j]), corr[i, j], vary[i], vary[j]))
        for _, c, vi, vj in sorted(pairs, reverse=True)[:10]:
            corr_out.append({"correlation": float(c), "variables": [vi, vj]})
    return {
        "vary_list": vary,
        "values": vals,
        "sigmas": sig,
        "top_correlations": corr_out,
        "rvals": cov.get("Rvals", {}),
    }


def summarize(gpx: G2sc.G2Project, trial: str, project: Path) -> dict:
    hist = gpx.histograms("PWDR")[0]
    dep = gpx.data["Covariance"]["data"].get("depSigDict", {})
    phases = []
    for i, phase in enumerate(gpx.phases()):
        hap = phase.getHAPvalues(hist.name)
        phases.append(
            {
                "name": phase.name,
                "weight_fraction": dep.get(f"{i}:0:WgtFrac", [None, None])[0],
                "weight_fraction_sigma": dep.get(f"{i}:0:WgtFrac", [None, None])[1],
                "preferred_orientation": hap["Pref.Ori."],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    return {
        "trial": trial,
        "project": str(project),
        "r_wp_percent": hist.get_wR(),
        "r_exp_percent": hist.residuals.get("wRmin"),
        "gof": hist.residuals.get("wR", 0.0) / hist.residuals.get("wRmin", 1.0),
        "residuals": hist.residuals,
        "frozen": gpx.get_Frozen(),
        "phases": phases,
        "covariance": covariance_summary(gpx),
    }


def apply_trial(gpx: G2sc.G2Project, trial: str) -> None:
    hist = gpx.histograms("PWDR")[0]
    if trial in TEXTURE_TRIALS:
        pidx, axis = TEXTURE_TRIALS[trial]
        hap = gpx.phases()[pidx].getHAPvalues(hist.name)
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
        gpx.set_Controls("parmMin", 0.2, variable=f"{pidx}:0:MD")
        gpx.set_Controls("parmMax", 5.0, variable=f"{pidx}:0:MD")
        return
    if trial in STRAIN_TRIALS:
        axis = STRAIN_TRIALS[trial]
        hap = gpx.phases()[1].getHAPvalues(hist.name)
        seed = max(float(hap["Mustrain"][1][0]), 10.0)
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0:2] = [seed, seed]
        hap["Mustrain"][2][0:2] = [True, True]
        hap["Mustrain"][3] = axis
        gpx.set_Controls("parmMin", 0.0, variable="1:0:Mustrain;i")
        gpx.set_Controls("parmMin", 0.0, variable="1:0:Mustrain;a")
        return
    raise ValueError(trial)


def run(trial: str) -> dict:
    OUT.mkdir(parents=True, exist_ok=True)
    project = OUT / f"{trial}.gpx"
    gpx = G2sc.G2Project(str(BASE))
    gpx.save(str(project))
    gpx.set_Frozen()
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["shift factor"] = 0.2
    apply_trial(gpx, trial)
    for _ in range(2):
        gpx.refine()
        gpx.save()

    # The reported result is always from a newly opened project and a full
    # replay, so an in-memory-only optimum cannot be selected accidentally.
    replay = G2sc.G2Project(str(project))
    replay.set_Controls("cycles", 12)
    replay.data["Controls"]["data"]["shift factor"] = 0.2
    replay.refine()
    replay.save()
    result = summarize(replay, trial, project)
    (OUT / f"{trial}.json").write_text(json.dumps(result, indent=2) + "\n")
    compact = {
        "trial": trial,
        "Rwp": result["r_wp_percent"],
        "GOF": result["gof"],
        "fractions": [p["weight_fraction"] for p in result["phases"]],
        "PO": [p["preferred_orientation"][:4] for p in result["phases"]],
        "WO3_mustrain": result["phases"][1]["mustrain"][:4],
        "frozen": result["frozen"],
        "top_corr": result["covariance"]["top_correlations"][:3],
    }
    print(json.dumps(compact, indent=2), flush=True)
    return result


def main() -> None:
    trials = {**TEXTURE_TRIALS, **STRAIN_TRIALS}
    parser = argparse.ArgumentParser()
    parser.add_argument("trials", nargs="+", choices=sorted(trials))
    args = parser.parse_args()
    for trial in args.trials:
        run(trial)


if __name__ == "__main__":
    main()
