#!/usr/bin/env python3
"""Build and refine a minimal PbWO4 + WO3 GSAS-II baseline."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PBWO4 = COD / "9/00/98/9009811.cif"
WO3 = COD / "1/52/89/1528915.cif"


def snapshot(gpx: G2sc.G2Project, label: str) -> None:
    hist = gpx.histograms("PWDR")[0]
    print(f"\n=== {label}: wR={hist.get_wR()} ===")
    print("residuals", hist.residuals)
    print("instrument", hist.InstrumentParameters)
    print("sample", hist.SampleParameters)
    print("background", hist.Background)
    for phase in gpx.phases():
        print(
            "phase",
            phase.name,
            "cell",
            phase.get_cell(),
            "HAP",
            phase.getHAPvalues(hist.name),
        )


def neutralize_hap(phase: G2sc.G2Phase) -> None:
    phase.clear_HAP_refinements(
        {
            "Scale": True,
            "HStrain": True,
            "Mustrain": True,
            "Size": True,
            "Pref.Ori.": True,
            "Extinction": True,
            "Babinet": ["BabA", "BabU"],
        }
    )
    # Disabled flags alone are not neutral: GSAS-II still applies the stored
    # values. Use effectively infinite crystallite size and zero microstrain.
    for hap in phase.data["Histograms"].values():
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0e6
        hap["Size"][1][1] = 1.0e6
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Pref.Ori."][1] = 1.0
        hap["Extinction"][0] = 0.0
        hap["Babinet"]["BabA"][0] = 0.0
        hap["Babinet"]["BabU"][0] = 0.0
    phase.set_HAP_refinements({"Scale": True})


def main() -> None:
    out = ROOT / "analysis/baseline.gpx"
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "analysis/instrument.instprm"),
        fmthint="comma",
    )
    p1 = gpx.add_phase(str(PBWO4), phasename="PbWO4_scheelite", histograms=[hist])
    p2 = gpx.add_phase(str(WO3), phasename="WO3_monoclinic", histograms=[hist])

    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [1400.0, -900.0, 350.0, -150.0, 60.0, -20.0, 0.0, 0.0, 0.0, 0.0],
                "refine": True,
            }
        }
    )
    # Dual-wavelength import selects Bragg-Brentano geometry. Use only specimen
    # displacement as the angular correction; keep instrument zero fixed.
    hist.SampleParameters["Gonio. radius"] = 240.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"][0] = -850.0
    hist.SampleParameters["Shift"][1] = False
    hist.SampleParameters["Transparency"][0] = 0.0
    hist.SampleParameters["Transparency"][1] = False
    hist.SampleParameters["SurfRoughA"][1] = False
    hist.SampleParameters["SurfRoughB"][1] = False
    hist.InstrumentParameters["Zero"][1:] = [0.0, False]
    hist.InstrumentParameters["V"][1:] = [0.0, False]
    hist.InstrumentParameters["Y"][1:] = [0.0, False]
    hist.InstrumentParameters["Z"][1:] = [0.0, False]
    hist.InstrumentParameters["SH/L"][1:] = [0.002, False]
    for phase in (p1, p2):
        neutralize_hap(phase)

    gpx.save()
    snapshot(gpx, "initial")

    # First establish smooth background and phase scales.
    gpx.refine()
    gpx.save()
    snapshot(gpx, "background_scales")

    # Refine cells with one physical angular correction.
    p1.set_refinements({"Cell": True})
    p2.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    gpx.refine()
    gpx.save()
    snapshot(gpx, "cells_shift")

    # Common nonnegative low-dimensional U/W/X profile.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    gpx.refine()
    gpx.save()
    snapshot(gpx, "common_profile")

    # Replay once from disk and write a compact machine-readable diagnostic.
    reopened = G2sc.G2Project(str(out))
    reopened.refine()
    reopened.save()
    snapshot(reopened, "reopened_replay")
    h = reopened.histograms("PWDR")[0]
    diag = {
        "wR": h.get_wR(),
        "residuals": h.residuals,
        "instrument": h.InstrumentParameters,
        "sample": h.SampleParameters,
        "phases": {
            p.name: {"cell": p.get_cell(), "hap": p.getHAPvalues(h.name)}
            for p in reopened.phases()
        },
    }
    (ROOT / "analysis/baseline_diagnostic.json").write_text(
        json.dumps(diag, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
