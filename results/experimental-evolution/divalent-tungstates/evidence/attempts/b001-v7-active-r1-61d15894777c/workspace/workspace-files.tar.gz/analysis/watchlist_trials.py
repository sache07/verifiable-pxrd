#!/usr/bin/env python3
"""Re-challenge chemically plausible weak phases from the final nuisance model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "final.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = ROOT / "analysis/final_watchlist_after_anisotropy"

CANDIDATES = {
    "litharge_PbO": COD / "9/01/27/9012700.cif",
    "massicot_PbO": COD / "2/31/04/2310433.cif",
    "plattnerite_PbO2": COD / "9/00/75/9007543.cif",
    "WO2": COD / "1/54/86/1548686.cif",
    "W18O49": ROOT / "analysis/candidate_cifs/W18O49_neutral_W.cif",
    "triclinic_WO3": COD / "2/10/62/2106293.cif",
    "orthorhombic_WO3": COD / "2/10/73/2107312.cif",
    "tetragonal_WO3_130": COD / "1/52/15/1521532.cif",
    "tetragonal_WO3_129": COD / "1/52/15/1521533.cif",
    "hexagonal_WO3": COD / "1/00/40/1004057.cif",
    "Pb7W8O28p8": COD / "9/01/60/9016035.cif",
}


def neutralize_candidate(phase: G2sc.G2Phase, hist_name: str) -> None:
    hap = phase.getHAPvalues(hist_name)
    hap["Scale"] = [0.01, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:2] = [10.0, 10.0]
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:2] = [0.0, 0.0]
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def summarize(gpx: G2sc.G2Project, candidate: str, project: Path) -> dict:
    hist = gpx.histograms("PWDR")[0]
    cov = gpx.data["Covariance"]["data"]
    dep = cov.get("depSigDict", {})
    phases = []
    for i, phase in enumerate(gpx.phases()):
        hap = phase.getHAPvalues(hist.name)
        phases.append(
            {
                "name": phase.name,
                "scale": hap["Scale"][0],
                "scale_refined": hap["Scale"][1],
                "weight_fraction": dep.get(f"{i}:0:WgtFrac", [None, None])[0],
                "weight_fraction_sigma": dep.get(f"{i}:0:WgtFrac", [None, None])[1],
            }
        )
    vary = [str(v) for v in cov.get("varyList", [])]
    values = list(cov.get("variables", []))
    sigmas = list(cov.get("sig", []))
    candidate_scale = None
    candidate_idx = len(phases) - 1
    candidate_var = f"{candidate_idx}:0:Scale"
    if candidate_var in vary:
        i = vary.index(candidate_var)
        candidate_scale = {"value": values[i], "sigma": sigmas[i]}
    return {
        "candidate": candidate,
        "source": str(CANDIDATES[candidate]),
        "project": str(project),
        "r_wp_percent": hist.get_wR(),
        "r_exp_percent": hist.residuals.get("wRmin"),
        "gof": hist.residuals.get("wR", 0.0) / hist.residuals.get("wRmin", 1.0),
        "candidate_scale": candidate_scale,
        "phases": phases,
        "frozen": gpx.get_Frozen(),
        "rvals": cov.get("Rvals", {}),
    }


def run(candidate: str) -> dict:
    OUT.mkdir(parents=True, exist_ok=True)
    project = OUT / f"{candidate}.gpx"
    gpx = G2sc.G2Project(str(BASE))
    gpx.save(str(project))
    gpx.set_Frozen()
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["shift factor"] = 0.2
    hist = gpx.histograms("PWDR")[0]
    phase = gpx.add_phase(
        str(CANDIDATES[candidate]),
        phasename=candidate,
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize_candidate(phase, hist.name)
    candidate_idx = len(gpx.phases()) - 1
    gpx.set_Controls("parmMin", 0.0, variable=f"{candidate_idx}:0:Scale")
    for _ in range(2):
        gpx.refine()
        gpx.save()

    replay = G2sc.G2Project(str(project))
    replay.set_Controls("cycles", 12)
    replay.data["Controls"]["data"]["shift factor"] = 0.2
    replay.refine()
    replay.save()
    result = summarize(replay, candidate, project)
    (OUT / f"{candidate}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "candidate": candidate,
                "Rwp": result["r_wp_percent"],
                "candidate_scale": result["candidate_scale"],
                "fractions": [p["weight_fraction"] for p in result["phases"]],
                "frozen": result["frozen"],
            },
            indent=2,
        ),
        flush=True,
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidates", nargs="+", choices=sorted(CANDIDATES))
    args = parser.parse_args()
    for candidate in args.candidates:
        run(candidate)


if __name__ == "__main__":
    main()
