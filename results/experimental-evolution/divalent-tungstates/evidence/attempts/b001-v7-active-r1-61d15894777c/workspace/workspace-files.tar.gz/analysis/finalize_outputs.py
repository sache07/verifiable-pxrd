#!/usr/bin/env python3
"""Freeze, replay, export and validate the submitted five-phase model."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from final_candidate_discrimination import correlations


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis/pbwo4_anisotropy/size_001.gpx"
FINAL = ROOT / "final.gpx"
PROFILE = ROOT / "fit.csv"
RESULT = ROOT / "result.json"
PHASE_DIR = ROOT / "phases"

PHASE_META = [
    {
        "name": "scheelite lead tungstate",
        "formula": "PbWO4",
        "cif_name": "PbWO4_scheelite.cif",
        "cod_id": "9009811",
        "confidence": "high",
    },
    {
        "name": "monoclinic tungsten trioxide",
        "formula": "WO3",
        "cif_name": "WO3_monoclinic.cif",
        "cod_id": "2311041",
        "confidence": "high",
    },
    {
        "name": "red lead",
        "formula": "Pb3O4",
        "cif_name": "Pb3O4_red_lead.cif",
        "cod_id": "9012124",
        "confidence": "high",
    },
    {
        "name": "massicot",
        "formula": "PbO",
        "cif_name": "PbO_massicot.cif",
        "cod_id": "2310433",
        "confidence": "moderate",
    },
    {
        "name": "triclinic tungsten trioxide",
        "formula": "WO3",
        "cif_name": "WO3_triclinic.cif",
        "cod_id": "2106293",
        "confidence": "tentative",
    },
]


def enforce_supported_model(gpx: G2sc.G2Project) -> None:
    """Remove unsupported/bound terms without changing accepted values."""
    hist = gpx.histograms("PWDR")[0]
    x = np.asarray(hist.getdata("x"), dtype=float)
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    hist.set_refinements({"Background": {"no. coeffs": 12, "refine": True}})

    inst = hist.data["Instrument Parameters"][0]
    for term in ("Zero", "V", "Y", "Z"):
        inst[term][1] = 0.0
        inst[term][2] = False
    for term in ("U", "W", "X"):
        inst[term][2] = True
        gpx.set_Controls("parmMin", 0.0, variable=f":0:{term}")
    inst["Polariz."][1:] = [1.0, False]
    inst["SH/L"][1:] = [0.002, False]
    inst["I(L2)/I(L1)"][1:] = [0.5, False]
    inst["Lam1"][1:] = [1.540598, False]
    inst["Lam2"][1:] = [1.544426, False]

    sample = hist.SampleParameters
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 240.0
    sample["Scale"] = [1.0, False]
    sample["Shift"][1] = True
    for key in ("Absorption", "DisplaceX", "DisplaceY", "Transparency"):
        sample[key] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    phases = gpx.phases()
    if len(phases) != 5:
        raise RuntimeError(f"Expected five phases, found {len(phases)}")
    for i, phase in enumerate(phases):
        phase.set_refinements({"Cell": True})
        hap = phase.getHAPvalues(hist.name)
        hap["Scale"][1] = True
        gpx.set_Controls("parmMin", 0.0, variable=f"{i}:0:Scale")

        strain = hap["Mustrain"]
        strain[0] = "isotropic"
        strain[1][:2] = [0.0, 0.0]
        strain[2] = [False] * len(strain[2])
        hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]

        po = hap["Pref.Ori."]
        if i == 3:
            po[0] = "MD"
            po[2] = True
            po[3] = [1, 1, 1]
            gpx.set_Controls("parmMin", 0.2, variable="3:0:MD")
            gpx.set_Controls("parmMax", 5.0, variable="3:0:MD")
        else:
            po[0:4] = ["MD", 1.0, False, [0, 0, 1]]

        size = hap["Size"]
        if i == 0:
            size[0] = "uniaxial"
            size[2] = [True, True, False]
            size[3] = [0, 0, 1]
            for suffix in ("i", "a"):
                gpx.set_Controls("parmMin", 0.001, variable=f"0:0:Size;{suffix}")
                gpx.set_Controls("parmMax", 10.0, variable=f"0:0:Size;{suffix}")
        elif i == 3:
            size[0] = "isotropic"
            size[2] = [True, False, False]
            gpx.set_Controls("parmMin", 0.001, variable=f"{i}:0:Size;i")
            gpx.set_Controls("parmMax", 10.0, variable=f"{i}:0:Size;i")
        elif i == 2:
            size[0] = "uniaxial"
            size[2] = [True, True, False]
            size[3] = [1, 1, 0]
            for suffix in ("i", "a"):
                gpx.set_Controls("parmMin", 0.001, variable=f"2:0:Size;{suffix}")
                gpx.set_Controls("parmMax", 10.0, variable=f"2:0:Size;{suffix}")
        else:
            size[0] = "isotropic"
            size[1][:2] = [10.0, 10.0]
            size[2] = [False] * len(size[2])

    gpx.set_Frozen()
    gpx.set_Controls("cycles", 20)
    gpx.data["Controls"]["data"]["shift factor"] = 0.1


def replay_to_convergence() -> G2sc.G2Project:
    gpx = G2sc.G2Project(str(SOURCE))
    gpx.save(str(FINAL))
    enforce_supported_model(gpx)
    gpx.save()

    history = []
    for replay_number in range(1, 8):
        replay = G2sc.G2Project(str(FINAL))
        enforce_supported_model(replay)
        replay.refine()
        replay.save()
        rvals = replay.data["Covariance"]["data"].get("Rvals", {})
        entry = {
            "replay": replay_number,
            "r_wp_percent": replay.histograms("PWDR")[0].get_wR(),
            "max_shift_over_esd": rvals.get("Max shft/sig"),
            "converged": rvals.get("converged"),
            "frozen": replay.get_Frozen(),
        }
        history.append(entry)
        print(json.dumps(entry), flush=True)
        max_shift = entry["max_shift_over_esd"]
        if (
            entry["converged"]
            and not entry["frozen"]
            and max_shift is not None
            and max_shift < 0.1
            and replay_number >= 2
        ):
            break
    else:
        raise RuntimeError("Final replay did not reach max shift/esd < 0.1")

    final = G2sc.G2Project(str(FINAL))
    (ROOT / "analysis/final_replay_history.json").write_text(
        json.dumps(history, indent=2) + "\n"
    )
    return final


def export(final: G2sc.G2Project) -> dict:
    PHASE_DIR.mkdir(parents=True, exist_ok=True)
    hist = final.histograms("PWDR")[0]
    phases = final.phases()
    cov = final.data["Covariance"]["data"]
    dep = cov.get("depSigDict", {})

    raw_fractions = np.asarray(
        [dep[f"{i}:0:WgtFrac"][0] for i in range(len(phases))], dtype=float
    )
    raw_esds = np.asarray(
        [dep[f"{i}:0:WgtFrac"][1] for i in range(len(phases))], dtype=float
    )
    fractions = raw_fractions / raw_fractions.sum()
    fraction_esds = raw_esds / raw_fractions.sum()

    phase_rows = []
    for i, (phase, meta) in enumerate(zip(phases, PHASE_META, strict=True)):
        cif_path = PHASE_DIR / meta["cif_name"]
        phase.export_CIF(str(cif_path), quickmode=True)
        phase_rows.append(
            {
                "name": meta["name"],
                "formula": meta["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": str(cif_path.relative_to(ROOT)),
                "weight_fraction": float(fractions[i]),
                "weight_fraction_esd": float(fraction_esds[i]),
                "source_cod_id": meta["cod_id"],
                "identification_confidence": meta["confidence"],
            }
        )

    x = np.asarray(hist.getdata("x"), dtype=float)
    yobs = np.asarray(hist.getdata("yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("ycalc"), dtype=float)
    background = np.asarray(hist.getdata("background"), dtype=float)
    difference = yobs - ycalc
    with PROFILE.open("w", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        writer.writerows(
            zip(x, yobs, ycalc, difference, background, strict=True)
        )

    rvals = cov.get("Rvals", {})
    result = {
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "normalization": "weight fractions normalized over modeled crystalline phases; amorphous content not quantified",
        "phases": phase_rows,
        "fit_statistics": {
            "r_wp_percent": float(hist.get_wR()),
            "r_p_percent": float(hist.residuals["R"]),
            "r_exp_percent": float(hist.residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_variables": int(rvals["Nvars"]),
            "max_shift_over_esd_final_replay": float(rvals["Max shft/sig"]),
        },
        "measurement_range_two_theta_deg": [float(x[0]), float(x[-1])],
        "structural_refinement_scope": "phase scales and cells refined; literature atom coordinates/occupancies retained",
    }
    RESULT.write_text(json.dumps(result, indent=2) + "\n")

    inst = hist.data["Instrument Parameters"][0]
    summary = {
        "result": result,
        "phase_project_names": [p.name for p in phases],
        "cells": [p.get_cell() for p in phases],
        "instrument_profile": {
            k: {"value": v[1], "refined": v[2]}
            for k, v in inst.items()
            if isinstance(v, list) and len(v) >= 3
        },
        "sample_parameters": hist.SampleParameters,
        "phase_hap": [p.getHAPvalues(hist.name) for p in phases],
        "frozen": final.get_Frozen(),
        "top_correlations": correlations(final),
    }
    (ROOT / "analysis/final_model_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    return result


def validate(result: dict) -> None:
    parsed = json.loads(RESULT.read_text())
    if parsed["project_path"] != "final.gpx":
        raise AssertionError("project_path must be final.gpx")
    fractions = [p["weight_fraction"] for p in parsed["phases"]]
    if not all(isinstance(v, (int, float)) and math.isfinite(v) for v in fractions):
        raise AssertionError("Every phase must have a finite numeric fraction")
    if not math.isclose(sum(fractions), 1.0, rel_tol=0.0, abs_tol=1e-12):
        raise AssertionError(f"Fractions sum to {sum(fractions)!r}, not one")
    for phase in parsed["phases"]:
        if not (ROOT / phase["cif_path"]).is_file():
            raise AssertionError(f"Missing CIF {phase['cif_path']}")
    if not FINAL.is_file() or not PROFILE.is_file():
        raise AssertionError("Missing final project or profile")

    reopened = G2sc.G2Project(str(FINAL))
    if reopened.get_Frozen():
        raise AssertionError(f"Final project has frozen variables: {reopened.get_Frozen()}")
    hist = reopened.histograms("PWDR")[0]
    cov = reopened.data["Covariance"]["data"]
    dep = cov.get("depSigDict", {})
    project_fractions = np.asarray(
        [dep[f"{i}:0:WgtFrac"][0] for i in range(len(reopened.phases()))]
    )
    project_fractions /= project_fractions.sum()
    if not np.allclose(project_fractions, fractions, rtol=0.0, atol=1e-12):
        raise AssertionError("result.json fractions differ from final.gpx")

    fit = np.genfromtxt(PROFILE, delimiter=",", names=True)
    if len(fit) != len(hist.getdata("x")):
        raise AssertionError("fit.csv length differs from final.gpx")
    comparisons = [
        (fit["two_theta_deg"], hist.getdata("x")),
        (fit["observed_counts"], hist.getdata("yobs")),
        (fit["calculated_counts"], hist.getdata("ycalc")),
        (fit["background_counts"], hist.getdata("background")),
    ]
    if not all(np.allclose(a, b, rtol=1e-12, atol=1e-9) for a, b in comparisons):
        raise AssertionError("fit.csv arrays differ from final.gpx")
    if not np.allclose(
        fit["difference_counts"],
        fit["observed_counts"] - fit["calculated_counts"],
        rtol=1e-12,
        atol=1e-9,
    ):
        raise AssertionError("fit.csv difference column is inconsistent")
    if result["fit_statistics"]["n_observations"] != len(fit):
        raise AssertionError("Not all measured points were replayed")

    validation = {
        "status": "passed",
        "project_reopened": True,
        "project_path": parsed["project_path"],
        "phase_count": len(parsed["phases"]),
        "weight_fraction_sum": sum(fractions),
        "all_cifs_exist": True,
        "fit_rows": len(fit),
        "fit_matches_project": True,
        "frozen_variables": reopened.get_Frozen(),
    }
    (ROOT / "analysis/final_validation.json").write_text(
        json.dumps(validation, indent=2) + "\n"
    )
    print(json.dumps(validation, indent=2), flush=True)


if __name__ == "__main__":
    final_project = replay_to_convergence()
    final_result = export(final_project)
    validate(final_result)
