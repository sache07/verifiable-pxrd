#!/usr/bin/env python3
"""Replay-stable one-phase size/strain comparisons from the four-phase U+X baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis/trials/four_baseline/profile_UX.gpx"
OUT = ROOT / "analysis/profile_four"
TRIALS = [f"{kind}_p{i}" for i in range(4) for kind in ("size", "strain")]
SIZE_SEEDS = {0: 0.13, 1: 2.0, 2: 0.06, 3: 2.0}


def top_correlations(gpx: G2sc.G2Project) -> list[dict]:
    cov = gpx.data["Covariance"]["data"]
    names = [str(v) for v in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if not matrix.size:
        return []
    sig = np.sqrt(np.clip(np.diag(matrix), 0.0, None))
    den = np.outer(sig, sig)
    corr = np.divide(matrix, den, out=np.zeros_like(matrix), where=den != 0)
    pairs = []
    for i in range(len(names)):
        for j in range(i):
            pairs.append((abs(corr[i, j]), float(corr[i, j]), names[i], names[j]))
    return [
        {"correlation": c, "variables": [vi, vj]}
        for _, c, vi, vj in sorted(pairs, reverse=True)[:10]
    ]


def run(trial: str) -> dict:
    kind, ptext = trial.split("_p")
    pidx = int(ptext)
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"{trial}.gpx"
    gpx = G2sc.G2Project(str(BASE))
    gpx.save(str(target))
    gpx.set_Frozen()
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["shift factor"] = 0.2
    phase = gpx.phases()[pidx]
    hist = gpx.histograms("PWDR")[0]
    hap = phase.getHAPvalues(hist.name)
    if kind == "size":
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": SIZE_SEEDS[pidx],
                    "refine": True,
                }
            }
        )
        gpx.set_Controls("parmMin", 0.001, variable=f"{pidx}:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, variable=f"{pidx}:0:Size;i")
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
        gpx.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Mustrain;i")
        gpx.set_Controls("parmMax", 50000.0, variable=f"{pidx}:0:Mustrain;i")

    for _ in range(3):
        gpx.refine()
        gpx.save()

    replay = G2sc.G2Project(str(target))
    replay.set_Controls("cycles", 12)
    replay.data["Controls"]["data"]["shift factor"] = 0.2
    replay.refine()
    replay.save()
    hist = replay.histograms("PWDR")[0]
    cov = replay.data["Covariance"]["data"]
    dep = cov.get("depSigDict", {})
    phases = []
    for i, p in enumerate(replay.phases()):
        phap = p.getHAPvalues(hist.name)
        phases.append(
            {
                "name": p.name,
                "weight_fraction": dep.get(f"{i}:0:WgtFrac", [None, None])[0],
                "weight_fraction_sigma": dep.get(f"{i}:0:WgtFrac", [None, None])[1],
                "size": phap["Size"],
                "mustrain": phap["Mustrain"],
            }
        )
    result = {
        "trial": trial,
        "project": str(target),
        "r_wp_percent": hist.get_wR(),
        "r_exp_percent": hist.residuals.get("wRmin"),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "instrument": hist.InstrumentParameters,
        "phases": phases,
        "frozen": replay.get_Frozen(),
        "rvals": cov.get("Rvals", {}),
        "top_correlations": top_correlations(replay),
    }
    (OUT / f"{trial}.json").write_text(json.dumps(result, indent=2) + "\n")
    selected = phases[pidx]["size" if kind == "size" else "mustrain"]
    print(
        json.dumps(
            {
                "trial": trial,
                "Rwp": result["r_wp_percent"],
                "GOF": result["gof"],
                "selected_term": selected[:3],
                "U_W_X": [
                    hist.InstrumentParameters[k][1] for k in ("U", "W", "X")
                ],
                "fractions": [p["weight_fraction"] for p in phases],
                "frozen": result["frozen"],
                "top_corr": result["top_correlations"][:3],
            },
            indent=2,
        ),
        flush=True,
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("trials", nargs="+", choices=TRIALS)
    args = parser.parse_args()
    for trial in args.trials:
        run(trial)


if __name__ == "__main__":
    main()
