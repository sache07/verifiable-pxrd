#!/usr/bin/env python3
"""Replay-stable combinations of the independently supported final terms."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from final_candidate_discrimination import correlations


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis/final_discrimination/texture_p3_111.gpx"
OUT = ROOT / "analysis/combined_discrimination"

TRIALS = {
    "p3tex_p2usize110": [("size", 2, [1, 1, 0])],
    "p3tex_p2usize001": [("size", 2, [0, 0, 1])],
    "p3tex_p2tex110": [("texture", 2, [1, 1, 0])],
    "p3tex_p3usize111": [("size", 3, [1, 1, 1])],
    "p3tex_p2usize110_p2tex110": [
        ("size", 2, [1, 1, 0]),
        ("texture", 2, [1, 1, 0]),
    ],
    "p3tex_p2usize110_p3usize111": [
        ("size", 2, [1, 1, 0]),
        ("size", 3, [1, 1, 1]),
    ],
    "p3tex_p2usize110_p2tex110_p3usize111": [
        ("size", 2, [1, 1, 0]),
        ("texture", 2, [1, 1, 0]),
        ("size", 3, [1, 1, 1]),
    ],
}


def add_term(gpx: G2sc.G2Project, term: tuple[str, int, list[int]]) -> None:
    kind, pidx, axis = term
    hist = gpx.histograms("PWDR")[0]
    hap = gpx.phases()[pidx].getHAPvalues(hist.name)
    if kind == "texture":
        hap["Pref.Ori."][0:4] = ["MD", 1.0, True, axis]
        gpx.set_Controls("parmMin", 0.2, variable=f"{pidx}:0:MD")
        gpx.set_Controls("parmMax", 5.0, variable=f"{pidx}:0:MD")
    elif kind == "size":
        size = hap["Size"]
        seed = float(size[1][0])
        size[0] = "uniaxial"
        size[1] = [seed, seed, 1.0]
        size[2] = [True, True, False]
        size[3] = axis
        for suffix in ("i", "a"):
            gpx.set_Controls("parmMin", 0.001, variable=f"{pidx}:0:Size;{suffix}")
            gpx.set_Controls("parmMax", 10.0, variable=f"{pidx}:0:Size;{suffix}")
    else:
        raise ValueError(kind)


def run(name: str, terms: list[tuple[str, int, list[int]]]) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"{name}.gpx"
    gpx = G2sc.G2Project(str(BASE))
    gpx.save(str(target))
    gpx.set_Frozen()
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["shift factor"] = 0.2
    for term in terms:
        add_term(gpx, term)
    for _ in range(2):
        gpx.refine()
        gpx.save()
    replay = G2sc.G2Project(str(target))
    replay.set_Controls("cycles", 12)
    replay.data["Controls"]["data"]["shift factor"] = 0.2
    replay.refine()
    replay.save()

    hist = replay.histograms("PWDR")[0]
    cov = replay.data["Covariance"]["data"]
    dep = cov.get("depSigDict", {})
    phases = []
    for i, phase in enumerate(replay.phases()):
        hap = phase.getHAPvalues(hist.name)
        phases.append({
            "name": phase.name,
            "weight_fraction": dep.get(f"{i}:0:WgtFrac", [None, None])[0],
            "preferred_orientation": hap["Pref.Ori."],
            "size": hap["Size"],
        })
    result = {
        "trial": name,
        "project": str(target),
        "r_wp_percent": hist.get_wR(),
        "r_exp_percent": hist.residuals.get("wRmin"),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "phases": phases,
        "frozen": replay.get_Frozen(),
        "top_correlations": correlations(replay),
    }
    (OUT / f"{name}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({
        "trial": name,
        "Rwp": result["r_wp_percent"],
        "GOF": result["gof"],
        "fractions": [p["weight_fraction"] for p in phases],
        "PO": [p["preferred_orientation"][:4] for p in phases],
        "sizes": [p["size"][:4] for p in phases],
        "frozen": result["frozen"],
        "top_corr": result["top_correlations"][:5],
    }, indent=2), flush=True)


if __name__ == "__main__":
    for trial_name, trial_terms in TRIALS.items():
        run(trial_name, trial_terms)
