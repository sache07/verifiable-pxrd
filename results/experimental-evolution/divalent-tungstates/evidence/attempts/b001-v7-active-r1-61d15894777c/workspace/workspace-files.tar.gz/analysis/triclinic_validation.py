#!/usr/bin/env python3
"""Validate the weak triclinic-WO3 watch-list hit with cell/profile trials."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from final_candidate_discrimination import correlations


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis/final_watchlist/triclinic_WO3.gpx"
OUT = ROOT / "analysis/triclinic_validation"


def configure(gpx: G2sc.G2Project, trial: str) -> None:
    hist = gpx.histograms("PWDR")[0]
    phase = gpx.phases()[4]
    phase.set_refinements({"Cell": True})
    hap = phase.getHAPvalues(hist.name)
    if trial == "cell":
        return
    if trial == "cell_size":
        size = hap["Size"]
        size[0] = "isotropic"
        size[1][0] = 0.2
        size[2][0] = True
        gpx.set_Controls("parmMin", 0.001, variable="4:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, variable="4:0:Size;i")
        return
    if trial == "cell_strain":
        strain = hap["Mustrain"]
        strain[0] = "isotropic"
        strain[1][0] = 300.0
        strain[2][0] = True
        gpx.set_Controls("parmMin", 0.0, variable="4:0:Mustrain;i")
        gpx.set_Controls("parmMax", 50000.0, variable="4:0:Mustrain;i")
        return
    raise ValueError(trial)


def run(trial: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"{trial}.gpx"
    gpx = G2sc.G2Project(str(BASE))
    gpx.save(str(target))
    gpx.set_Frozen()
    gpx.set_Controls("cycles", 16)
    gpx.data["Controls"]["data"]["shift factor"] = 0.15
    configure(gpx, trial)
    for _ in range(3):
        gpx.refine()
        gpx.save()
    replay = G2sc.G2Project(str(target))
    replay.set_Controls("cycles", 16)
    replay.data["Controls"]["data"]["shift factor"] = 0.15
    replay.refine()
    replay.save()

    hist = replay.histograms("PWDR")[0]
    cov = replay.data["Covariance"]["data"]
    dep = cov.get("depSigDict", {})
    phases = []
    for i, phase in enumerate(replay.phases()):
        hap = phase.getHAPvalues(hist.name)
        phases.append({
            "name": phase.name,
            "weight_fraction": dep.get(f"{i}:0:WgtFrac", [None, None])[0],
            "weight_fraction_sigma": dep.get(f"{i}:0:WgtFrac", [None, None])[1],
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        })
    result = {
        "trial": trial,
        "project": str(target),
        "r_wp_percent": hist.get_wR(),
        "r_exp_percent": hist.residuals.get("wRmin"),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "phases": phases,
        "frozen": replay.get_Frozen(),
        "top_correlations": correlations(replay),
    }
    (OUT / f"{trial}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({
        "trial": trial,
        "Rwp": result["r_wp_percent"],
        "GOF": result["gof"],
        "fractions": [p["weight_fraction"] for p in phases],
        "triclinic_cell": phases[4]["cell"],
        "triclinic_size": phases[4]["size"][:4],
        "triclinic_strain": phases[4]["mustrain"][:3],
        "frozen": result["frozen"],
        "top_corr": result["top_correlations"][:8],
    }, indent=2), flush=True)


if __name__ == "__main__":
    for trial_name in ("cell", "cell_size", "cell_strain"):
        run(trial_name)
