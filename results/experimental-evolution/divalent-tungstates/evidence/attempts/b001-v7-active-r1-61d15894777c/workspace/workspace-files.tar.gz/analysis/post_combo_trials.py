#!/usr/bin/env python3
"""Challenge extra/bound terms after combining supported four-phase widths."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis/stages/four_size02.gpx"
OUT = ROOT / "analysis/post_combo"
TRIALS = [
    "wo3_strain",
    "massicot_strain",
    "massicot_size",
    "pb3o4_size_plus_strain",
    "pb3o4_strain_only",
    "pbwo4_size_plus_strain",
    "pbwo4_strain_only",
    "no_U",
    "profile_WUX",
    "background12",
    "roughness",
]


def set_strain(gpx: G2sc.G2Project, pidx: int, value: float) -> None:
    hist = gpx.histograms("PWDR")[0]
    phase = gpx.phases()[pidx]
    hap = phase.getHAPvalues(hist.name)
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = value
    phase.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}
    )
    gpx.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Mustrain;i")
    gpx.set_Controls("parmMax", 50000.0, variable=f"{pidx}:0:Mustrain;i")


def set_size(gpx: G2sc.G2Project, pidx: int, value: float) -> None:
    gpx.phases()[pidx].set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": value, "refine": True}}
    )
    gpx.set_Controls("parmMin", 0.001, variable=f"{pidx}:0:Size;i")
    gpx.set_Controls("parmMax", 10.0, variable=f"{pidx}:0:Size;i")


def disable_size(gpx: G2sc.G2Project, pidx: int) -> None:
    hist = gpx.histograms("PWDR")[0]
    size = gpx.phases()[pidx].getHAPvalues(hist.name)["Size"]
    size[0] = "isotropic"
    size[1][0] = 10.0
    size[2][0] = False


def apply_trial(gpx: G2sc.G2Project, trial: str) -> None:
    hist = gpx.histograms("PWDR")[0]
    if trial == "wo3_strain":
        set_strain(gpx, 1, 500.0)
    elif trial == "massicot_strain":
        set_strain(gpx, 3, 1000.0)
    elif trial == "massicot_size":
        set_size(gpx, 3, 0.10)
    elif trial == "pb3o4_size_plus_strain":
        set_strain(gpx, 2, 1000.0)
    elif trial == "pb3o4_strain_only":
        disable_size(gpx, 2)
        set_strain(gpx, 2, 8000.0)
    elif trial == "pbwo4_size_plus_strain":
        set_strain(gpx, 0, 500.0)
    elif trial == "pbwo4_strain_only":
        disable_size(gpx, 0)
        set_strain(gpx, 0, 1500.0)
    elif trial == "no_U":
        hist.InstrumentParameters["U"][1:] = [0.0, False]
    elif trial == "profile_WUX":
        hist.InstrumentParameters["W"][1:] = [10.0, True]
        gpx.set_Controls("parmMin", 0.0, variable=":0:W")
    elif trial == "background12":
        hist.set_refinements({"Background": {"no. coeffs": 12, "refine": True}})
    elif trial == "roughness":
        hist.SampleParameters["SurfRoughA"] = [0.5, True]
        hist.SampleParameters["SurfRoughB"] = [0.01, True]
        gpx.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
        gpx.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
        gpx.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    else:
        raise ValueError(trial)


def correlation_summary(gpx: G2sc.G2Project) -> list[dict]:
    cov = gpx.data["Covariance"]["data"]
    names = [str(v) for v in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if not matrix.size:
        return []
    sig = np.sqrt(np.clip(np.diag(matrix), 0.0, None))
    den = np.outer(sig, sig)
    corr = np.divide(matrix, den, out=np.zeros_like(matrix), where=den != 0)
    pairs = []
    for i in range(len(names)):
        for j in range(i):
            pairs.append((abs(corr[i, j]), float(corr[i, j]), names[i], names[j]))
    return [
        {"correlation": c, "variables": [vi, vj]}
        for _, c, vi, vj in sorted(pairs, reverse=True)[:10]
    ]


def run(trial: str) -> dict:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"{trial}.gpx"
    gpx = G2sc.G2Project(str(BASE))
    gpx.save(str(target))
    gpx.set_Frozen()
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["shift factor"] = 0.2
    apply_trial(gpx, trial)
    for _ in range(3):
        gpx.refine()
        gpx.save()
    replay = G2sc.G2Project(str(target))
    replay.set_Controls("cycles", 12)
    replay.data["Controls"]["data"]["shift factor"] = 0.2
    replay.refine()
    replay.save()

    hist = replay.histograms("PWDR")[0]
    cov = replay.data["Covariance"]["data"]
    dep = cov.get("depSigDict", {})
    phases = []
    for i, phase in enumerate(replay.phases()):
        hap = phase.getHAPvalues(hist.name)
        phases.append(
            {
                "name": phase.name,
                "weight_fraction": dep.get(f"{i}:0:WgtFrac", [None, None])[0],
                "weight_fraction_sigma": dep.get(f"{i}:0:WgtFrac", [None, None])[1],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    result = {
        "trial": trial,
        "project": str(target),
        "r_wp_percent": hist.get_wR(),
        "r_exp_percent": hist.residuals.get("wRmin"),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": phases,
        "frozen": replay.get_Frozen(),
        "rvals": cov.get("Rvals", {}),
        "top_correlations": correlation_summary(replay),
    }
    (OUT / f"{trial}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "trial": trial,
                "Rwp": result["r_wp_percent"],
                "GOF": result["gof"],
                "U_W_X": [hist.InstrumentParameters[k][1] for k in ("U", "W", "X")],
                "sizes": [p["size"][1][0] for p in phases],
                "strains": [p["mustrain"][1][0] for p in phases],
                "fractions": [p["weight_fraction"] for p in phases],
                "frozen": result["frozen"],
                "top_corr": result["top_correlations"][:3],
            },
            indent=2,
        ),
        flush=True,
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("trials", nargs="+", choices=TRIALS)
    args = parser.parse_args()
    for trial in args.trials:
        run(trial)


if __name__ == "__main__":
    main()
