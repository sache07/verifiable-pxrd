#!/usr/bin/env python3
"""Compare the average and modulated orthorhombic PbO source models."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis/stages/four_size02.gpx"
ALT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/53/36/1533609.cif"
)
OUT = ROOT / "analysis/massicot_sources"
TRIALS = ["alt_neutral", "alt_size", "alt_strain"]


def add_alternative(gpx: G2sc.G2Project, trial: str) -> None:
    hist = gpx.histograms("PWDR")[0]
    old = gpx.phases()[3]
    old_hap = old.getHAPvalues(hist.name)
    old_hap["Scale"] = [0.0, False]
    old.data["General"]["Cell"][0] = False

    phase = gpx.add_phase(
        str(ALT),
        phasename="massicot_modulated_1533609",
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.getHAPvalues(hist.name)
    hap["Scale"] = [0.5, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]
    phase.set_refinements({"Cell": True})
    gpx.set_Controls("parmMin", 0.0, variable="4:0:Scale")

    if trial == "alt_size":
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 0.055, "refine": True}}
        )
        gpx.set_Controls("parmMin", 0.001, variable="4:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, variable="4:0:Size;i")
    elif trial == "alt_strain":
        hap["Mustrain"][1][0] = 8000.0
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
        gpx.set_Controls("parmMin", 0.0, variable="4:0:Mustrain;i")
        gpx.set_Controls("parmMax", 50000.0, variable="4:0:Mustrain;i")


def run(trial: str) -> dict:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"{trial}.gpx"
    gpx = G2sc.G2Project(str(BASE))
    gpx.save(str(target))
    gpx.set_Frozen()
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["shift factor"] = 0.2
    add_alternative(gpx, trial)
    for _ in range(4):
        gpx.refine()
        gpx.save()
    replay = G2sc.G2Project(str(target))
    replay.set_Controls("cycles", 12)
    replay.data["Controls"]["data"]["shift factor"] = 0.2
    replay.refine()
    replay.save()

    hist = replay.histograms("PWDR")[0]
    cov = replay.data["Covariance"]["data"]
    dep = cov.get("depSigDict", {})
    phases = []
    for i, phase in enumerate(replay.phases()):
        hap = phase.getHAPvalues(hist.name)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "weight_fraction": dep.get(f"{i}:0:WgtFrac", [None, None])[0],
                "weight_fraction_sigma": dep.get(f"{i}:0:WgtFrac", [None, None])[1],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    result = {
        "trial": trial,
        "project": str(target),
        "source": str(ALT),
        "r_wp_percent": hist.get_wR(),
        "r_exp_percent": hist.residuals.get("wRmin"),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "phases": phases,
        "frozen": replay.get_Frozen(),
        "rvals": cov.get("Rvals", {}),
    }
    (OUT / f"{trial}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "trial": trial,
                "Rwp": result["r_wp_percent"],
                "GOF": result["gof"],
                "alt_fraction": phases[4]["weight_fraction"],
                "alt_cell": phases[4]["cell"],
                "alt_size": phases[4]["size"][:3],
                "alt_strain": phases[4]["mustrain"][:3],
                "frozen": result["frozen"],
            },
            indent=2,
        ),
        flush=True,
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("trials", nargs="+", choices=TRIALS)
    args = parser.parse_args()
    for trial in args.trials:
        run(trial)


if __name__ == "__main__":
    main()
