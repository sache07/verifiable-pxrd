#!/usr/bin/env python3
"""Replay controlled nuisance/profile tests from one saved phase baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis/screens/three_loopstra.gpx"
OUT = ROOT / "analysis/trials"

TRIALS = [
    "background6",
    "background8",
    "background12",
    "polarization",
    "roughness",
    "size_p0",
    "strain_p0",
    "size_p1",
    "strain_p1",
    "size_p2",
    "strain_p2",
    "size_p3",
    "strain_p3",
    "profile_WX",
    "profile_UX",
]


def apply_trial(gpx: G2sc.G2Project, trial: str) -> None:
    hist = gpx.histograms("PWDR")[0]
    phases = gpx.phases()
    if trial.startswith("background"):
        n = int(trial.removeprefix("background"))
        hist.set_refinements({"Background": {"no. coeffs": n, "refine": True}})
    elif trial == "polarization":
        hist.InstrumentParameters["Polariz."][2] = True
        gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif trial == "roughness":
        hist.SampleParameters["SurfRoughA"] = [0.5, True]
        hist.SampleParameters["SurfRoughB"] = [0.01, True]
        gpx.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
        gpx.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
        gpx.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    elif trial.startswith("size_p"):
        idx = int(trial[-1])
        phases[idx].set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}
        )
    elif trial.startswith("strain_p"):
        idx = int(trial[-1])
        hap = phases[idx].getHAPvalues(hist.name)
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        phases[idx].set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    elif trial == "profile_WX":
        hist.InstrumentParameters["W"][1:] = [50.0, True]
        hist.InstrumentParameters["X"][1:] = [10.0, True]
        gpx.set_Controls("parmMin", 0.0, variable=":0:W")
        gpx.set_Controls("parmMin", 0.0, variable=":0:X")
    elif trial == "profile_UX":
        hist.InstrumentParameters["U"][1:] = [50.0, True]
        hist.InstrumentParameters["X"][1:] = [10.0, True]
        gpx.set_Controls("parmMin", 0.0, variable=":0:U")
        gpx.set_Controls("parmMin", 0.0, variable=":0:X")
    else:
        raise ValueError(trial)


def summarize(gpx: G2sc.G2Project, trial: str, project: Path) -> dict:
    hist = gpx.histograms("PWDR")[0]
    dep = gpx.data["Covariance"]["data"].get("depSigDict", {})
    phases = []
    for i, phase in enumerate(gpx.phases()):
        phases.append(
            {
                "name": phase.name,
                "weight_fraction": dep.get(f"{i}:0:WgtFrac", [None, None])[0],
                "hap": phase.getHAPvalues(hist.name),
            }
        )
    return {
        "trial": trial,
        "project": str(project),
        "wR": hist.get_wR(),
        "gof": hist.residuals.get("wR", 0.0) / hist.residuals.get("wRmin", 1.0),
        "residuals": hist.residuals,
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "frozen": gpx.get_Frozen(),
        "phases": phases,
    }


def run(trial: str, base: Path = BASE) -> dict:
    outdir = OUT / base.stem
    outdir.mkdir(parents=True, exist_ok=True)
    project = outdir / f"{trial}.gpx"
    gpx = G2sc.G2Project(str(base))
    gpx.save(str(project))
    gpx.set_Controls("cycles", 8)
    apply_trial(gpx, trial)
    print(f"{trial}: refine", flush=True)
    gpx.refine()
    gpx.save()
    replay = G2sc.G2Project(str(project))
    print(f"{trial}: reopen/replay", flush=True)
    replay.refine()
    replay.save()
    result = summarize(replay, trial, project)
    (outdir / f"{trial}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "trial": trial,
                "wR": result["wR"],
                "gof": result["gof"],
                "polarization": result["instrument"]["Polariz."][1],
                "U_W_X": [result["instrument"][k][1] for k in ("U", "W", "X")],
                "roughness": [
                    result["sample"]["SurfRoughA"][0],
                    result["sample"]["SurfRoughB"][0],
                ],
                "frozen": result["frozen"],
            },
            indent=2,
        ),
        flush=True,
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, default=BASE)
    parser.add_argument("trials", nargs="+", choices=TRIALS)
    args = parser.parse_args()
    for trial in args.trials:
        run(trial, args.base)


if __name__ == "__main__":
    main()
