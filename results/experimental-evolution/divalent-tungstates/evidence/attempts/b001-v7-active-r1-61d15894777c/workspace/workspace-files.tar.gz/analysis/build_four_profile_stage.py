#!/usr/bin/env python3
"""Combine the replay-supported PbWO4 and Pb3O4 isotropic size terms."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis/profile_four/size_p0.gpx"
TARGET = ROOT / "analysis/stages/four_size02.gpx"


def report(gpx: G2sc.G2Project, label: str) -> None:
    hist = gpx.histograms("PWDR")[0]
    cov = gpx.data["Covariance"]["data"]
    dep = cov.get("depSigDict", {})
    print(
        label,
        "Rwp",
        hist.get_wR(),
        "GOF",
        cov.get("Rvals", {}).get("GOF"),
        "fractions",
        [dep.get(f"{i}:0:WgtFrac", [None])[0] for i in range(4)],
        "sizes",
        [p.getHAPvalues(hist.name)["Size"][1][0] for p in gpx.phases()],
        "U_X",
        [hist.InstrumentParameters[k][1] for k in ("U", "X")],
        "last",
        cov.get("Rvals", {}).get("Max shft/sig"),
        flush=True,
    )


def main() -> None:
    gpx = G2sc.G2Project(str(SOURCE))
    gpx.save(str(TARGET))
    gpx.set_Frozen()
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["shift factor"] = 0.2
    gpx.phases()[2].set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 0.06, "refine": True}}
    )
    gpx.set_Controls("parmMin", 0.001, variable="2:0:Size;i")
    gpx.set_Controls("parmMax", 10.0, variable="2:0:Size;i")
    for i in range(4):
        gpx.refine()
        gpx.save()
        report(gpx, f"pass{i + 1}")
    replay = G2sc.G2Project(str(TARGET))
    replay.set_Controls("cycles", 12)
    replay.data["Controls"]["data"]["shift factor"] = 0.2
    replay.refine()
    replay.save()
    report(replay, "reopened")


if __name__ == "__main__":
    main()
