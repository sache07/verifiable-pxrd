#!/usr/bin/env python3
"""Test complementary replay-stable March-Dollase term pairs."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
BASE = WORK / "nuisance_trials/background_12.gpx"
OUT = WORK / "texture_trials"
COMBINATIONS = {
    "C2c_ab110_plus_WO3_a100": ([1, 1, 0], [1, 0, 0]),
    "C2c_a100_plus_WO3_a100": ([1, 0, 0], [1, 0, 0]),
    "C2c_bc011_plus_WO3_a100": ([0, 1, 1], [1, 0, 0]),
}


def fit(tag, axes):
    project = G2sc.G2Project(gpxfile=str(BASE))
    project.save(str(OUT / f"{tag}.gpx"))
    project.data["Controls"]["data"]["max cyc"] = 25
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.histogram(0)
    for phase, axis in zip(project.phases(), axes):
        po = phase.getHAPvalues(hist)["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = axis
        project.set_Controls("parmMin", 0.2, variable=f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 5.0, variable=f"{phase.id}:0:MD")
    project.refine()
    project.refine()
    project.save()
    r = project.data["Covariance"]["data"].get("Rvals", {})
    row = {
        "tag": tag,
        "project": str(Path(project.filename).relative_to(WORK)),
        "Rwp_percent": hist.get_wR(),
        "GOF": r.get("GOF"),
        "max_shift_over_esd": r.get("Max shft/sig"),
        "converged": r.get("converged"),
        "texture": {
            phase.name: {
                "axis": phase.getHAPvalues(hist)["Pref.Ori."][3],
                "ratio": phase.getHAPvalues(hist)["Pref.Ori."][1],
            }
            for phase in project.phases()
        },
        "frozen": [str(v) for v in project.data["Controls"]["data"].get(
            "parmFrozen", {}
        ).get("FrozenList", [])],
    }
    print(tag, row["Rwp_percent"], row["texture"], row["max_shift_over_esd"])
    return row


def main():
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("warn")
    rows = [fit(tag, axes) for tag, axes in COMBINATIONS.items()]
    (OUT / "combined_summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
