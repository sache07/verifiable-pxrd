#!/usr/bin/env python3
"""Staged, correlation-controlled test of C2/c and scheelite SrWO4 coexistence."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
BASE = WORK / "correct_model_trials/profile_WX.gpx"
OUT = WORK / "coexistence_screening/staged_C2c_scheelite_orthoWO3.gpx"


def snapshot(project, label):
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "converged": rvals.get("converged"),
        "scales": {
            phase.name: phase.HAPvalue("Scale", targethistlist=[hist])
            for phase in project.phases()
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }


def refine_and_record(project, rows, label):
    project.refine()
    project.save()
    row = snapshot(project, label)
    rows.append(row)
    print(label, row["Rwp_percent"], row["scales"], row["max_shift_over_esd"])


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(gpxfile=str(BASE))
    project.save(str(OUT))
    project.data["Controls"]["data"]["max cyc"] = 25
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.histogram(0)
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})

    scheelite = project.add_phase(
        str(WORK / "candidates/SrWO4_from_SrMoO4.cif"),
        phasename="SrWO4_scheelite", histograms=[hist],
    )
    scheelite.setSampleProfile(hist, "size", "isotropic", 100.0, LGmix=1.0)
    scheelite.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap = scheelite.getHAPvalues(hist)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Scale"] = [0.1, True]

    rows = []
    refine_and_record(project, rows, "fixed_cell_scale_test")

    # Refine one metric at a time to prevent the nearly related cells from
    # trading reflections and becoming singular.
    phase_order = [
        "SrWO4_scheelite", "SrWO4_C2c", "WO3_ortho_2107312",
        "SrWO4_scheelite", "SrWO4_C2c", "WO3_ortho_2107312",
    ]
    for cycle, name in enumerate(phase_order, start=1):
        for phase in project.phases():
            phase.clear_refinements({"Cell": True})
        project.phase(name).set_refinements({"Cell": True})
        refine_and_record(project, rows, f"cell_stage_{cycle}_{name}")

    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    refine_and_record(project, rows, "fixed_cell_replay")
    (OUT.parent / "staged_summary.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
