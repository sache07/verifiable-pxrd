#!/usr/bin/env python3
"""Re-converge the accepted four-phase inventory with neutral nuisance terms."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
SOURCE = WORK / "four_phase_coordinate_trials/SrW.gpx"
OUTPUT = WORK / "four_phase_reconverged.gpx"


def snapshot(project, label):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "Rp_percent": hist.data["data"][0].get("R"),
        "GOF": rvals.get("GOF"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "converged": rvals.get("converged"),
        "profile": {key: inst[key][1] for key in ("U", "W", "X", "SH/L")},
        "scales": {
            phase.name: phase.HAPvalue("Scale", targethistlist=[hist])
            for phase in project.phases()
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "weight_fractions": {
            name: value[0] for name, value in hist.ComputeMassFracs().items()
        },
        "frozen": [
            str(value)
            for value in project.data["Controls"]["data"].get(
                "parmFrozen", {}
            ).get("FrozenList", [])
        ],
    }


def refine(project, rows, label):
    project.refine()
    project.save()
    row = snapshot(project, label)
    rows.append(row)
    print(label, row["Rwp_percent"], row["max_shift_over_esd"], row["weight_fractions"])


def main():
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(gpxfile=str(SOURCE))
    project.save(str(OUTPUT))
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 25
    controls["min dM/M"] = 1e-5
    controls.setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.histogram(0)
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for name, value, flag in [
        ("U", 100.0, False), ("V", 0.0, False),
        ("W", max(1.0, inst["W"][1]), True),
        ("X", 0.0, False), ("Y", 0.0, False),
        ("SH/L", 0.002, False), ("Zero", 0.0, False),
        ("Polariz.", 0.5, False),
    ]:
        inst[name][1] = value
        inst[name][2] = flag
    project.set_Controls("parmMin", 0.0, variable=":0:W")
    project.set_Controls("parmMax", 1000.0, variable=":0:W")
    hist.set_refinements({"Background": {"refine": True, "no. coeffs": 12}})

    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.setSampleProfile(hist, "size", "isotropic", 100.0, LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        hap["Pref.Ori."][0] = "MD"
        if phase.name == "SrWO4_C2c":
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [1, 1, 0]
            project.set_Controls("parmMin", 0.2, variable=f"{phase.id}:0:MD")
            project.set_Controls("parmMax", 5.0, variable=f"{phase.id}:0:MD")
        else:
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
            hap["Pref.Ori."][3] = [0, 0, 1]

    rows = []
    refine(project, rows, "fixed_cells_nuisance")
    phase_order = [phase.name for phase in project.phases()] * 2
    for index, phase_name in enumerate(phase_order, start=1):
        for phase in project.phases():
            phase.clear_refinements({"Cell": True})
        project.phase(phase_name).set_refinements({"Cell": True})
        refine(project, rows, f"cell_stage_{index}_{phase_name}")
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    refine(project, rows, "full_range_fixed_cell_replay")
    (WORK / "four_phase_reconvergence.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
