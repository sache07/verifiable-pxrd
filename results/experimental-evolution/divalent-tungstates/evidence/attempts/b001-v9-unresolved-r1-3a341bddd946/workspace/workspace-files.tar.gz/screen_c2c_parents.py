#!/usr/bin/env python3
"""Compare independent C2/c SrWO4 coordinate parents with matched nuisance terms."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
OUT = WORK / "c2c_parent_screening"
PARENTS = {
    "CaWO4": WORK / "candidates/SrWO4_fergusonite_indexed_from_CaWO4.cif",
    "CaMoO4": WORK / "candidates/SrWO4_fergusonite_from_CaMoO4.cif",
    "YNbO4": WORK / "candidates/SrWO4_fergusonite_from_YNbO4.cif",
    "NdTaO4": WORK / "candidates/SrWO4_fergusonite_from_NdTaO4.cif",
}
WO3 = Path(
    "<RUN>/"
    "resources/b001-c03/cif/2/10/73/2107312.cif"
)


def neutralize(phase, hist, scale):
    phase.setSampleProfile(hist, "size", "isotropic", 100.0, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap = phase.getHAPvalues(hist)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Scale"] = [scale, True]


def fit(tag, source):
    project = G2sc.G2Project(newgpx=str(OUT / f"{tag}.gpx"))
    project.data["Controls"]["data"]["max cyc"] = 25
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.add_powder_histogram(
        str(WORK / "inputs/pattern.csv"), str(WORK / "instrument.instprm"),
        fmthint="comma",
    )
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for name, value in {
        "U": 100.0, "V": 0.0, "W": 50.0, "X": 0.5,
        "Y": 0.0, "SH/L": 0.002,
    }.items():
        inst[name][1] = value
        inst[name][2] = False
    main = project.add_phase(str(source), phasename=f"SrWO4_C2c_{tag}", histograms=[hist])
    residue = project.add_phase(str(WO3), phasename="WO3_ortho", histograms=[hist])
    neutralize(main, hist, 1.0)
    neutralize(residue, hist, 0.15)
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1", "refine": True, "no. coeffs": 8,
            "coeffs": [1050.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        }
    })
    project.refine()
    scale_test = {p.name: p.HAPvalue("Scale", targethistlist=[hist]) for p in (main, residue)}
    rwp_scale = hist.get_wR()
    main.set_refinements({"Cell": True})
    residue.set_refinements({"Cell": True})
    project.refine()
    project.refine()
    project.save()
    r = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "tag": tag,
        "source": str(source.relative_to(WORK)),
        "project": str(Path(project.filename).relative_to(WORK)),
        "scale_test": scale_test,
        "Rwp_scale_test_percent": rwp_scale,
        "final_scales": {p.name: p.HAPvalue("Scale", targethistlist=[hist]) for p in (main, residue)},
        "cells": {p.name: p.get_cell() for p in (main, residue)},
        "Rwp_percent": hist.get_wR(),
        "GOF": r.get("GOF"),
        "max_shift_over_esd": r.get("Max shft/sig"),
        "converged": r.get("converged"),
    }


def main():
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("warn")
    rows = []
    for tag, source in PARENTS.items():
        row = fit(tag, source)
        rows.append(row)
        print(tag, row["Rwp_percent"], row["final_scales"], row["max_shift_over_esd"])
    (OUT / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
