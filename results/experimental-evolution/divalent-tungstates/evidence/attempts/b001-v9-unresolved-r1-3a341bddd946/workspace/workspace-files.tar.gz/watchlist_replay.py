#!/usr/bin/env python3
"""Matched-nuisance scale-before-cell replay for residual-ranked weak phases."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
BASE = WORK / "texture_trials/SrWO4_C2c_ab110.gpx"
OUT = WORK / "watchlist_replay"
CANDIDATES = {
    "SrW2O7_BaV": WORK / "candidates/SrW2O7_from_BaV2O7_scaled.cif",
    "Sr3W2O9_LaRe": WORK / "candidates/Sr3W2O9_from_La3Re2O9_scaled.cif",
    "Sr3W2O9_SmRe": WORK / "candidates/Sr3W2O9_from_Sm3Re2O9_scaled.cif",
    "Sr2WO5_EuTi": WORK / "candidates/Sr2WO5_from_Eu2TiO5_scaled.cif",
    "Sr2WO5_NdTi": WORK / "candidates/Sr2WO5_from_Nd2TiO5_scaled.cif",
    "SrWO4_LiRe": WORK / "candidates/SrWO4_from_LiReO4_scaled.cif",
    "SrWO4_CuW": WORK / "candidates/SrWO4_from_CuWO4_scaled.cif",
    "SrWO4_BaMn": WORK / "candidates/SrWO4_from_BaMnO4_scaled.cif",
    "SrWO4_LaTa": WORK / "candidates/SrWO4_from_LaTaO4_scaled.cif",
    "Sr3WO6_EuTa": WORK / "candidates/Sr3WO6_from_Eu3TaO6_scaled.cif",
}


def state(project, candidate, label):
    hist = project.histogram(0)
    r = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": r.get("GOF"),
        "max_shift_over_esd": r.get("Max shft/sig"),
        "converged": r.get("converged"),
        "candidate_scale": candidate.HAPvalue("Scale", targethistlist=[hist]),
        "candidate_cell": candidate.get_cell(),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get(
            "parmFrozen", {}
        ).get("FrozenList", [])],
    }


def fit(tag, path):
    project = G2sc.G2Project(gpxfile=str(BASE))
    project.save(str(OUT / f"{tag}.gpx"))
    project.data["Controls"]["data"]["max cyc"] = 25
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.histogram(0)
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    candidate = project.add_phase(str(path), phasename=tag, histograms=[hist])
    candidate.setSampleProfile(hist, "size", "isotropic", 100.0, LGmix=1.0)
    candidate.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap = candidate.getHAPvalues(hist)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Scale"] = [0.05, True]

    stages = []
    project.refine()
    project.save()
    stages.append(state(project, candidate, "scale_test"))
    if stages[-1]["candidate_scale"] > 1e-5:
        candidate.set_refinements({"Cell": True})
        try:
            project.refine()
            project.refine()
        except Exception as error:
            stages.append({"label": "cell_test_error", "error": str(error)})
        else:
            project.save()
            stages.append(state(project, candidate, "cell_test"))
            candidate.clear_refinements({"Cell": True})
            project.refine()
            project.save()
            stages.append(state(project, candidate, "fixed_cell_replay"))
    row = {
        "tag": tag,
        "cif": str(path.relative_to(WORK)),
        "project": str(Path(project.filename).relative_to(WORK)),
        "stages": stages,
    }
    last = stages[-1]
    print(tag, last)
    return row


def main():
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("warn")
    rows = []
    for tag, path in CANDIDATES.items():
        try:
            rows.append(fit(tag, path))
        except Exception as error:
            rows.append({"tag": tag, "cif": str(path), "error": str(error)})
            print(tag, "ERROR", error)
    (OUT / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
