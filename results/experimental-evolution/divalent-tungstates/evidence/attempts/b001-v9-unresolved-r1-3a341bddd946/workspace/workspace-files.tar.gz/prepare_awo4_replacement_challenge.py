#!/usr/bin/env python3
"""Build health-screenable SrWO4 analogues for a main-phase challenge."""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


WORK = Path(__file__).resolve().parent
OUT = WORK / "awo4_replacement_challenge" / "candidates"
SEARCH = WORK / "awo4_topology_search.json"

# Distinct ABO4 topology/coordinate competitors selected from the local
# pattern ranking. Substitutions preserve an A-site Sr and tetrahedral or
# higher-coordinate W site; each metric uses the search's physical-volume
# optimum before the scale-only test.
SELECTION = {
    "LiRe_P1": ("1535227", {"Li": "Sr", "Re": "W"}),
    "BaSi_P1": ("1531303", {"Ba": "Sr", "Si": "W"}),
    "ZnMo_P1": ("1528282", {"Zn": "Sr", "Mo": "W"}),
    "SrP_P1": ("9015018", {"P": "W"}),
    "BaGe_P1": ("1530605", {"Ba": "Sr", "Ge": "W"}),
    "CuMo_P1": ("1535336", {"Cu": "Sr", "Mo": "W"}),
    "KMo_P1": ("1529971", {"K": "Sr", "Mo": "W"}),
    "AgMn_Pnma": ("1010440", {"Ag": "Sr", "Mn": "W"}),
    "BaMn_Pnma": ("5910329", {"Ba": "Sr", "Mn": "W"}),
    "SrCr_P21c": ("9014695", {"Cr": "W"}),
    "PbW_P21c": ("9007617", {"Pb": "Sr"}),
}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    ranked = json.loads(SEARCH.read_text())["candidates"]
    by_id = {str(row["cod_id"]): row for row in ranked}
    manifest = []
    for tag, (cod_id, substitutions) in SELECTION.items():
        row = by_id[cod_id]
        source = Path(row["cif"])
        structure = Structure.from_file(source)
        structure.remove_oxidation_states()
        structure.replace_species(substitutions)
        structure = SpacegroupAnalyzer(
            structure, symprec=0.01
        ).get_conventional_standard_structure()
        scale = float(row["lattice_scale"])
        structure.scale_lattice(structure.volume * scale**3)
        output = OUT / f"SrWO4_{tag}.cif"
        # Write the expanded cell as P1 for robust GSAS-II import. The exact
        # higher-symmetry coordinates retain the same systematic extinctions;
        # symmetry is reassigned only if a topology survives this screen.
        CifWriter(structure, symprec=None).write_file(output)
        manifest.append(
            {
                "tag": tag,
                "source_cod_id": cod_id,
                "source_formula": row["source_formula"],
                "source_cif": str(source),
                "substitutions": substitutions,
                "lattice_scale": scale,
                "adapted_volume_per_formula_A3": row[
                    "adapted_volume_per_formula"
                ],
                "cif": str(output.relative_to(WORK)),
            }
        )
    (OUT.parent / "manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
