#!/usr/bin/env python3
"""Phase-specific isotropic size-versus-strain tests from one saved baseline."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
BASE = WORK / "texture_trials/SrWO4_C2c_ab110.gpx"
OUT = WORK / "broadening_trials"


def fit(tag, phase_name, mode):
    project = G2sc.G2Project(gpxfile=str(BASE))
    project.save(str(OUT / f"{tag}.gpx"))
    project.data["Controls"]["data"]["max cyc"] = 25
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2][0] = False
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2][0] = False
    phase = project.phase(phase_name)
    hap = phase.getHAPvalues(hist)
    if mode == "size":
        hap["Size"][2][0] = True
        project.set_Controls("parmMin", 0.001, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{phase.id}:0:Size;i")
    elif mode == "strain":
        hap["Mustrain"][1][0] = 100.0
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 5000.0, variable=f"{phase.id}:0:Mustrain;i")
    else:
        raise ValueError(mode)
    project.refine()
    project.refine()
    project.save()
    r = project.data["Covariance"]["data"].get("Rvals", {})
    row = {
        "tag": tag,
        "project": str(Path(project.filename).relative_to(WORK)),
        "phase": phase_name,
        "mode": mode,
        "size_micrometre": phase.getHAPvalues(hist)["Size"][1][0],
        "microstrain_ppm": phase.getHAPvalues(hist)["Mustrain"][1][0],
        "Rwp_percent": hist.get_wR(),
        "GOF": r.get("GOF"),
        "max_shift_over_esd": r.get("Max shft/sig"),
        "converged": r.get("converged"),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get(
            "parmFrozen", {}
        ).get("FrozenList", [])],
    }
    print(tag, row)
    return row


def main():
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("warn")
    rows = []
    for phase_name in ("SrWO4_C2c", "WO3_ortho_2107312"):
        short = "SrWO4" if phase_name.startswith("Sr") else "WO3"
        rows.append(fit(f"{short}_size", phase_name, "size"))
        rows.append(fit(f"{short}_strain", phase_name, "strain"))
    (OUT / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
