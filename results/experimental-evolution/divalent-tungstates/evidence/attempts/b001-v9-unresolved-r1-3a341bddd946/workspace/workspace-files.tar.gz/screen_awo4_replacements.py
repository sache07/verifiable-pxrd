#!/usr/bin/env python3
"""Challenge the dominant SrWO4 model with distinct ABO4 topologies."""

from __future__ import annotations

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
OUT = WORK / "awo4_replacement_challenge"
FINAL = WORK / "final.gpx"
PHASE_FILES = {
    "WO3_ortho_2107312": WORK / "phase_WO3_orthorhombic.cif",
    "SrCO3_Pnma": WORK / "phase_SrCO3_orthorhombic.cif",
    "SrWO4_scheelite": WORK / "phase_SrWO4_scheelite.cif",
}


def neutralize(phase, hist, scale):
    phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap = phase.getHAPvalues(hist)
    hap["Scale"] = [scale, True]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]
    phase.clear_refinements({"Cell": True})
    for atom in phase.atoms():
        atom.refinement_flags = " "


def snapshot(project, main, label):
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "converged": rvals.get("converged"),
        "main_scale": main.HAPvalue("Scale", targethistlist=[hist]),
        "main_cell": main.get_cell(),
        "weight_fractions": {
            name: value[0] for name, value in hist.ComputeMassFracs().items()
        },
        "frozen": [
            str(item)
            for item in project.data["Controls"]["data"]
            .get("parmFrozen", {})
            .get("FrozenList", [])
        ],
    }


def refine(project, main, rows, label):
    project.refine()
    project.save()
    rows.append(snapshot(project, main, label))


def fit(tag, main_file):
    reference = G2sc.G2Project(gpxfile=str(FINAL))
    ref_hist = reference.histogram(0)
    ref_inst = ref_hist.data["Instrument Parameters"][0]
    ref_sample = ref_hist.data["Sample Parameters"]
    ref_mass_scales = {
        phase.name: phase.HAPvalue("Scale", targethistlist=[ref_hist])
        for phase in reference.phases()
    }

    project = G2sc.G2Project(newgpx=str(OUT / f"{tag}.gpx"))
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 25
    controls["min dM/M"] = 1e-5
    controls.setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.add_powder_histogram(
        str(WORK / "inputs/pattern.csv"),
        str(WORK / "instrument.instprm"),
        fmthint="comma",
    )
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    hist.data["Background"] = copy.deepcopy(ref_hist.data["Background"])
    hist.data["Background"][0][1] = True
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [float(ref_sample["Shift"][0]), True]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for name in ("U", "V", "W", "X", "Y", "SH/L", "Zero", "Polariz."):
        inst[name][1] = float(ref_inst[name][1])
        inst[name][2] = name == "W"
    main = project.add_phase(
        str(main_file), phasename=f"SrWO4_main_{tag}", histograms=[hist]
    )
    neutralize(main, hist, ref_mass_scales["SrWO4_C2c"])
    project.set_Controls("parmMin", 1e-12, variable=f"{main.id}:0:Scale")
    project.set_Controls("parmMax", 1e6, variable=f"{main.id}:0:Scale")

    for name, path in PHASE_FILES.items():
        phase = project.add_phase(str(path), phasename=name, histograms=[hist])
        neutralize(phase, hist, ref_mass_scales[name])
        project.set_Controls("parmMin", 1e-12, variable=f"{phase.id}:0:Scale")
        project.set_Controls("parmMax", 1e6, variable=f"{phase.id}:0:Scale")

    project.set_Controls("parmMin", 0.0, variable=":0:W")
    project.set_Controls("parmMax", 1000.0, variable=":0:W")
    project.set_Controls("parmMin", -500.0, variable=":0:Shift")
    project.set_Controls("parmMax", 500.0, variable=":0:Shift")

    rows = []
    refine(project, main, rows, "matched_scale_test")
    refine(project, main, rows, "matched_scale_replay")
    if (
        rows[-1]["main_scale"] > 1e-8
        and not rows[-1]["frozen"]
        and rows[-1]["Rwp_percent"] < 20.0
    ):
        main.set_refinements({"Cell": True})
        refine(project, main, rows, "main_cell_test")
        refine(project, main, rows, "main_cell_replay")
        main.clear_refinements({"Cell": True})
        refine(project, main, rows, "fixed_cell_replay")
    print(tag, rows[-1]["Rwp_percent"], rows[-1]["main_scale"], rows[-1]["frozen"])
    return {
        "tag": tag,
        "cif": str(main_file.relative_to(WORK)),
        "project": str(Path(project.filename).relative_to(WORK)),
        "stages": rows,
    }


def main() -> None:
    G2sc.SetPrintLevel("warn")
    manifest = json.loads((OUT / "manifest.json").read_text())
    candidates = [("C2c_control", WORK / "phase_SrWO4_fergusonite.cif")]
    candidates.extend((row["tag"], WORK / row["cif"]) for row in manifest)
    rows = []
    for tag, path in candidates:
        try:
            rows.append(fit(tag, path))
        except Exception as error:
            rows.append({"tag": tag, "cif": str(path), "error": str(error)})
            print(tag, "ERROR", error)
    (OUT / "replacement_summary.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
