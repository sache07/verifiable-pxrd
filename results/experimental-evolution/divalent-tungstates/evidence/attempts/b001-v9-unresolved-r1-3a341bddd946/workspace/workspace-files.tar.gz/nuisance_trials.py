#!/usr/bin/env python3
"""Compare background, angular, polarization and roughness before texture."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
BASE = WORK / "correct_model_trials/profile_WX.gpx"
OUT = WORK / "nuisance_trials"


def summary(project, tag):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    r = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "tag": tag,
        "project": str(Path(project.filename).relative_to(WORK)),
        "Rwp_percent": hist.get_wR(),
        "GOF": r.get("GOF"),
        "max_shift_over_esd": r.get("Max shft/sig"),
        "converged": r.get("converged"),
        "background_coefficients": hist.data["Background"][0][2],
        "instrument": {
            key: {"value": inst[key][1], "refine": inst[key][2]}
            for key in ("Polariz.", "Zero", "U", "W", "X", "SH/L")
        },
        "sample": {
            key: {"value": sample[key][0], "refine": sample[key][1]}
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "frozen": [str(v) for v in project.data["Controls"]["data"].get(
            "parmFrozen", {}
        ).get("FrozenList", [])],
    }


def run(tag, configure):
    project = G2sc.G2Project(gpxfile=str(BASE))
    project.save(str(OUT / f"{tag}.gpx"))
    project.data["Controls"]["data"]["max cyc"] = 25
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    configure(project)
    project.refine()
    project.refine()
    project.save()
    row = summary(project, tag)
    print(tag, row["Rwp_percent"], row["instrument"], row["sample"], row["frozen"])
    return row


def background(n):
    def configure(project):
        project.histogram(0).set_refinements({
            "Background": {"refine": True, "no. coeffs": n}
        })
    return configure


def zero(project):
    inst = project.histogram(0).data["Instrument Parameters"][0]
    inst["Zero"] = [inst["Zero"][0], 0.0, True]
    project.set_Controls("parmMin", -0.2, variable=":0:Zero")
    project.set_Controls("parmMax", 0.2, variable=":0:Zero")


def shift(project):
    sample = project.histogram(0).data["Sample Parameters"]
    sample["Shift"] = [0.0, True]
    project.set_Controls("parmMin", -500.0, variable=":0:Shift")
    project.set_Controls("parmMax", 500.0, variable=":0:Shift")


def polarization(project):
    inst = project.histogram(0).data["Instrument Parameters"][0]
    inst["Polariz."][1] = 0.5
    inst["Polariz."][2] = True
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")


def roughness(project):
    sample = project.histogram(0).data["Sample Parameters"]
    sample["SurfRoughA"] = [0.5, True]
    sample["SurfRoughB"] = [0.01, True]
    for name in ("SurfRoughA", "SurfRoughB"):
        project.set_Controls("parmMin", 0.0, variable=f":0:{name}")
        project.set_Controls("parmMax", 1.0, variable=f":0:{name}")


def main():
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("warn")
    rows = [
        run("background_6", background(6)),
        run("background_10", background(10)),
        run("background_12", background(12)),
        run("angular_zero", zero),
        run("angular_shift", shift),
        run("polarization", polarization),
        run("roughness", roughness),
    ]
    (OUT / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
