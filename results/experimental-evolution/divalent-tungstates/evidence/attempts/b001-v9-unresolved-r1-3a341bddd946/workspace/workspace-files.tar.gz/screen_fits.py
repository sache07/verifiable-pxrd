#!/usr/bin/env python3
"""Matched-nuisance GSAS-II scale/cell screening of phase hypotheses."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
ROOT = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)
OUT = WORK / "screening"

MAIN = WORK / "candidates/SrWO4_from_SrMoO4.cif"
CANDIDATES = {
    "WO3_mono_1528915": WORK / "candidates/WO3_mono_1528915.cif",
    "WO3_mono_1563541": WORK / "candidates/WO3_mono_1563541.cif",
    "WO3_mono_2311041": WORK / "candidates/WO3_mono_2311041.cif",
    "WO3_tric_2106293": WORK / "candidates/WO3_tric_2106293.cif",
    "WO3_ortho_2107312": ROOT / "2/10/73/2107312.cif",
    "WO3_tetra_1521532": WORK / "candidates/WO3_tetra_1521532.cif",
    "WO3_tetra_1521533": WORK / "candidates/WO3_tetra_1521533.cif",
    "SrCO3_ortho_9008198": ROOT / "9/00/81/9008198.cif",
    "SrCO3_rhom_1539128": WORK / "candidates/SrCO3_rhom_1539128.cif",
    "Sr3W2O9_2311977": WORK / "candidates/Sr3W2O9_2311977.cif",
    "SrW2O7_MgMo_parent": WORK / "candidates/SrW2O7_from_MgMo2O7.cif",
    "SrW2O7_SrCr_parent": WORK / "candidates/SrW2O7_from_SrCr2O7.cif",
    "Sr3WO6_SrU_parent": WORK / "candidates/Sr3WO6_from_Sr3UO6.cif",
    "Sr2WO5_BaRe_parent": WORK / "candidates/Sr2WO5_from_Ba2ReO5.cif",
    "Sr3W2O9_Ba_parent": WORK / "candidates/Sr3W2O9_from_Ba3W2O9.cif",
}


def neutralize(phase, hist) -> None:
    phase.setSampleProfile(hist, "size", "isotropic", 100.0, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap = phase.getHAPvalues(hist)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Scale"] = [0.15, True]


def make_project(tag: str, extras: list[tuple[str, Path]]) -> tuple:
    project = G2sc.G2Project(newgpx=str(OUT / f"{tag}.gpx"))
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 15
    controls["min dM/M"] = 1e-5
    hist = project.add_powder_histogram(
        str(WORK / "inputs/pattern.csv"),
        str(WORK / "instrument.instprm"),
        fmthint="comma",
    )
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for name, value in {"U": 100.0, "V": 0.0, "W": 50.0,
                        "X": 0.5, "Y": 0.0, "SH/L": 0.002}.items():
        inst[name][1] = value
        inst[name][2] = False
    main = project.add_phase(
        str(MAIN), phasename="SrWO4", histograms=[hist]
    )
    cell = main.data["General"]["Cell"]
    cell[1] = cell[2] = 5.50
    cell[3] = 12.12
    cell[4:7] = [90.0, 90.0, 90.0]
    cell[7] = cell[1] * cell[2] * cell[3]
    neutralize(main, hist)
    main.getHAPvalues(hist)["Scale"] = [1.0, True]
    phases = [main]
    for name, path in extras:
        phase = project.add_phase(str(path), phasename=name, histograms=[hist])
        neutralize(phase, hist)
        phases.append(phase)
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True,
                         "no. coeffs": 8,
                         "coeffs": [1050.0, 0.0, 0.0, 0.0,
                                    0.0, 0.0, 0.0, 0.0]}}
    )
    return project, hist, phases


def fit(tag: str, extras: list[tuple[str, Path]]) -> dict:
    project, hist, phases = make_project(tag, extras)
    project.refine()
    scale_only = {
        phase.name: phase.HAPvalue("Scale", targethistlist=[hist])
        for phase in phases
    }
    # Cell refinement is challenged only after a positive matched-model scale.
    for phase in phases:
        if scale_only[phase.name] > 1e-5:
            phase.set_refinements({"Cell": True})
    project.refine()
    project.refine()
    project.save()
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "tag": tag,
        "project": str(Path(project.filename).relative_to(WORK)),
        "scale_only": scale_only,
        "final_scales": {
            phase.name: phase.HAPvalue("Scale", targethistlist=[hist])
            for phase in phases
        },
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "Rwp_percent": hist.get_wR(),
        "Rp_percent": hist.data["data"][0].get("R"),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "aborted": rvals.get("Aborted"),
        "message": rvals.get("msg", ""),
    }


def main() -> None:
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("warn")
    rows = [fit("main_only", [])]
    for name, path in CANDIDATES.items():
        rows.append(fit(f"main_plus_{name}", [(name, path)]))
    (OUT / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")
    for row in rows:
        print(
            row["tag"],
            f"Rwp={row['Rwp_percent']:.4f}" if row["Rwp_percent"] is not None else "Rwp=failed",
            "scales=" + json.dumps(row["final_scales"], sort_keys=True),
        )


if __name__ == "__main__":
    main()
