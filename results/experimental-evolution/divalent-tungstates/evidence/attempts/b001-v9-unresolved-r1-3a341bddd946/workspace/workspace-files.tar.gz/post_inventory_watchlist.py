#!/usr/bin/env python3
"""Post-inventory matched-nuisance scale replay for balance-motivated phases."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
BASE = WORK / "four_phase_nuisance/shift.gpx"
OUT = WORK / "post_inventory_watchlist"
CANDIDATES = {
    "Sr3W2O9_exact": WORK / "candidates/Sr3W2O9_2311977.cif",
    "Sr3W2O9_SmRe": WORK / "candidates/Sr3W2O9_from_Sm3Re2O9_scaled.cif",
    "SrW2O7_BaV": WORK / "candidates/SrW2O7_from_BaV2O7_scaled.cif",
    "Sr3WO6_EuTa": WORK / "candidates/Sr3WO6_from_Eu3TaO6_scaled.cif",
    "Sr2WO5_BaRe": WORK / "candidates/Sr2WO5_from_Ba2ReO5.cif",
    "SrWO4_LiRe": WORK / "candidates/SrWO4_from_LiReO4_scaled.cif",
}


def snapshot(project, candidate, label):
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "converged": rvals.get("converged"),
        "candidate_scale": candidate.HAPvalue("Scale", targethistlist=[hist]),
        "candidate_cell": candidate.get_cell(),
        "weight_fractions": {
            name: value[0] for name, value in hist.ComputeMassFracs().items()
        },
        "frozen": [
            str(value)
            for value in project.data["Controls"]["data"].get(
                "parmFrozen", {}
            ).get("FrozenList", [])
        ],
    }


def fit(tag, path):
    project = G2sc.G2Project(gpxfile=str(BASE))
    project.save(str(OUT / f"{tag}.gpx"))
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 25
    controls["min dM/M"] = 1e-5
    controls.setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.histogram(0)
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    candidate = project.add_phase(str(path), phasename=tag, histograms=[hist])
    candidate.setSampleProfile(hist, "size", "isotropic", 100.0, LGmix=1.0)
    candidate.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap = candidate.getHAPvalues(hist)
    hap["Scale"] = [0.03, True]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    project.set_Controls("parmMin", 1e-12, variable=f"{candidate.id}:0:Scale")
    project.set_Controls("parmMax", 1e6, variable=f"{candidate.id}:0:Scale")
    rows = []
    for label in ("scale_test", "scale_replay"):
        project.refine()
        project.save()
        rows.append(snapshot(project, candidate, label))
    print(tag, rows[-1]["Rwp_percent"], rows[-1]["candidate_scale"], rows[-1]["frozen"])
    return {
        "tag": tag,
        "cif": str(path.relative_to(WORK)),
        "project": str(Path(project.filename).relative_to(WORK)),
        "stages": rows,
    }


def main():
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("warn")
    rows = []
    for tag, path in CANDIDATES.items():
        try:
            rows.append(fit(tag, path))
        except Exception as error:
            rows.append({"tag": tag, "cif": str(path), "error": str(error)})
            print(tag, "ERROR", error)
    (OUT / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
