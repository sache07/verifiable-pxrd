#!/usr/bin/env python3
"""Matched-nuisance primary-phase tests for charge-balanced structure models."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
OUT = WORK / "primary_screening"
MODELS = {
    "SrWO4_SrMo_parent": WORK / "candidates/SrWO4_from_SrMoO4.cif",
    "SrWO4_CaW_parent": WORK / "candidates/SrWO4_from_CaWO4.cif",
    "SrWO4_fergusonite_indexed": WORK / "candidates/SrWO4_fergusonite_indexed_from_CaWO4.cif",
    "SrWO4_monoclinic_SrCr_parent": WORK / "candidates/SrWO4_monoclinic_from_SrCrO4.cif",
    "SrWO4_wolframite_MgW_parent": WORK / "candidates/SrWO4_wolframite_from_MgWO4.cif",
    "SrW2O7_MgMo_parent": WORK / "candidates/SrW2O7_from_MgMo2O7.cif",
    "SrW2O7_SrCr_parent": WORK / "candidates/SrW2O7_from_SrCr2O7.cif",
    "Sr3WO6_SrU_parent": WORK / "candidates/Sr3WO6_from_Sr3UO6.cif",
    "Sr3WO6_CaW_parent": WORK / "candidates/Sr3WO6_from_Ca3WO6.cif",
    "Sr2WO5_BaRe_parent": WORK / "candidates/Sr2WO5_from_Ba2ReO5.cif",
    "Sr3W2O9_exact": WORK / "candidates/Sr3W2O9_2311977.cif",
    "Sr3W2O9_Ba_parent": WORK / "candidates/Sr3W2O9_from_Ba3W2O9.cif",
}


def neutralize(phase, hist) -> None:
    phase.setSampleProfile(hist, "size", "isotropic", 100.0, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap = phase.getHAPvalues(hist)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Scale"] = [1.0, True]


def fit(tag: str, cif: Path) -> dict:
    project = G2sc.G2Project(newgpx=str(OUT / f"{tag}.gpx"))
    project.data["Controls"]["data"]["max cyc"] = 15
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.add_powder_histogram(
        str(WORK / "inputs/pattern.csv"),
        str(WORK / "instrument.instprm"),
        fmthint="comma",
    )
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for name, value in {"U": 100.0, "V": 0.0, "W": 50.0,
                        "X": 0.5, "Y": 0.0, "SH/L": 0.002}.items():
        inst[name][1] = value
        inst[name][2] = False
    phase = project.add_phase(str(cif), phasename=tag, histograms=[hist])
    neutralize(phase, hist)
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True,
                         "no. coeffs": 8,
                         "coeffs": [1050.0, 0.0, 0.0, 0.0,
                                    0.0, 0.0, 0.0, 0.0]}}
    )
    project.refine()
    scale_only = phase.HAPvalue("Scale", targethistlist=[hist])
    rwp_scale = hist.get_wR()
    cell_start = phase.get_cell()
    if scale_only > 1e-5:
        phase.set_refinements({"Cell": True})
        project.refine()
        project.refine()
    project.save()
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "tag": tag,
        "cif": str(cif.relative_to(WORK)),
        "project": str(Path(project.filename).relative_to(WORK)),
        "scale_only": scale_only,
        "Rwp_scale_only_percent": rwp_scale,
        "final_scale": phase.HAPvalue("Scale", targethistlist=[hist]),
        "cell_start": cell_start,
        "cell_final": phase.get_cell(),
        "Rwp_percent": hist.get_wR(),
        "Rp_percent": hist.data["data"][0].get("R"),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "aborted": rvals.get("Aborted"),
        "message": rvals.get("msg", ""),
    }


def main() -> None:
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("warn")
    rows = [fit(tag, cif) for tag, cif in MODELS.items()]
    (OUT / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")
    for row in rows:
        print(
            row["tag"],
            f"scale-test={row['scale_only']:.6g}",
            f"Rwp-scale={row['Rwp_scale_only_percent']:.4f}",
            f"Rwp-final={row['Rwp_percent']:.4f}",
        )


if __name__ == "__main__":
    main()
