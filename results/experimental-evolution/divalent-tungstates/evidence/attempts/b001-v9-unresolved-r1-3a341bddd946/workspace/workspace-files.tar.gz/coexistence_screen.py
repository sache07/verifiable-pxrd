#!/usr/bin/env python3
"""Test replay-stable coexistence of the two SrWO4 reflection families."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
OUT = WORK / "coexistence_screening"
FILES = {
    "SrWO4_C2c": WORK / "candidates/SrWO4_fergusonite_indexed_from_CaWO4.cif",
    "SrWO4_scheelite": WORK / "candidates/SrWO4_from_SrMoO4.cif",
    "WO3_ortho": Path(
        "<RUN>/"
        "resources/b001-c03/cif/2/10/73/2107312.cif"
    ),
    "WO3_mono": WORK / "candidates/WO3_mono_2311041.cif",
    "WO3_tetra": WORK / "candidates/WO3_tetra_1521533.cif",
}
COMBINATIONS = [
    ("C2c_scheelite", ["SrWO4_C2c", "SrWO4_scheelite"]),
    ("C2c_scheelite_orthoWO3", ["SrWO4_C2c", "SrWO4_scheelite", "WO3_ortho"]),
    ("C2c_scheelite_monoWO3", ["SrWO4_C2c", "SrWO4_scheelite", "WO3_mono"]),
    ("C2c_scheelite_tetraWO3", ["SrWO4_C2c", "SrWO4_scheelite", "WO3_tetra"]),
]


def neutralize(phase, hist, scale: float) -> None:
    # GSAS-II caps this isotropic value at 10 micrometres; that is the user's
    # required neutral lower limit and removes the active 1 micrometre default.
    phase.setSampleProfile(hist, "size", "isotropic", 100.0, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap = phase.getHAPvalues(hist)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Scale"] = [scale, True]


def fit(tag: str, names: list[str]) -> dict:
    project = G2sc.G2Project(newgpx=str(OUT / f"{tag}.gpx"))
    project.data["Controls"]["data"]["max cyc"] = 25
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.add_powder_histogram(
        str(WORK / "inputs/pattern.csv"),
        str(WORK / "instrument.instprm"),
        fmthint="comma",
    )
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for name, value in {
        "U": 100.0, "V": 0.0, "W": 50.0, "X": 0.5,
        "Y": 0.0, "SH/L": 0.002,
    }.items():
        inst[name][1] = value
        inst[name][2] = False

    phases = []
    for index, name in enumerate(names):
        phase = project.add_phase(
            str(FILES[name]), phasename=name, histograms=[hist]
        )
        neutralize(phase, hist, 1.0 if index == 0 else 0.15)
        phases.append(phase)

    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1", "refine": True, "no. coeffs": 8,
            "coeffs": [1050.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        }
    })
    project.refine()
    scale_test = {
        phase.name: phase.HAPvalue("Scale", targethistlist=[hist])
        for phase in phases
    }
    rwp_scale = hist.get_wR()
    for phase in phases:
        if scale_test[phase.name] > 1e-5:
            phase.set_refinements({"Cell": True})
    project.refine()
    project.refine()
    project.save()
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "tag": tag,
        "project": str(Path(project.filename).relative_to(WORK)),
        "scale_test": scale_test,
        "Rwp_scale_test_percent": rwp_scale,
        "final_scales": {
            phase.name: phase.HAPvalue("Scale", targethistlist=[hist])
            for phase in phases
        },
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "Rwp_percent": hist.get_wR(),
        "Rp_percent": hist.data["data"][0].get("R"),
        "GOF": rvals.get("GOF"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "converged": rvals.get("converged"),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get(
            "parmFrozen", {}
        ).get("FrozenList", [])],
    }


def main() -> None:
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("warn")
    rows = []
    for tag, names in COMBINATIONS:
        row = fit(tag, names)
        rows.append(row)
        print(tag, row["Rwp_percent"], row["scale_test"], row["final_scales"])
    (OUT / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
