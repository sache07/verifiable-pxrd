#!/usr/bin/env python3
"""Low-dimensional heavy-atom coordinate tests for C2/c SrWO4."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
BASE = WORK / "texture_trials/SrWO4_C2c_ab110.gpx"
OUT = WORK / "coordinate_trials"


def fit(tag, labels):
    project = G2sc.G2Project(gpxfile=str(BASE))
    project.save(str(OUT / f"{tag}.gpx"))
    project.data["Controls"]["data"]["max cyc"] = 25
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    phase = project.phase("SrWO4_C2c")
    for atom in phase.atoms():
        atom.refinement_flags = "X" if atom.label in labels else " "
    project.refine()
    project.refine()
    project.save()
    hist = project.histogram(0)
    r = project.data["Covariance"]["data"].get("Rvals", {})
    row = {
        "tag": tag,
        "project": str(Path(project.filename).relative_to(WORK)),
        "labels": labels,
        "Rwp_percent": hist.get_wR(),
        "GOF": r.get("GOF"),
        "max_shift_over_esd": r.get("Max shft/sig"),
        "converged": r.get("converged"),
        "coordinates": {
            atom.label: list(atom.coordinates) for atom in phase.atoms()
        },
        "frozen": [str(v) for v in project.data["Controls"]["data"].get(
            "parmFrozen", {}
        ).get("FrozenList", [])],
    }
    print(tag, row)
    return row


def main():
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("warn")
    rows = [
        fit("Sr_position", ["Sr0"]),
        fit("W_position", ["W1"]),
        fit("Sr_W_positions", ["Sr0", "W1"]),
    ]
    (OUT / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
