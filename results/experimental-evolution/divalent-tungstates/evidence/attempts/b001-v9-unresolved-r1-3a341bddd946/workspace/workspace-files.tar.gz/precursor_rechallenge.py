#!/usr/bin/env python3
"""Re-challenge exact precursor and WO3-polymorph watch-list phases."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
ROOT = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)
BASE = WORK / "texture_trials/SrWO4_C2c_ab110.gpx"
OUT = WORK / "precursor_rechallenge"
CANDIDATES = {
    "SrCO3_Pnma": ROOT / "9/00/81/9008198.cif",
    "WO3_mono": WORK / "candidates/WO3_mono_2311041.cif",
    "WO3_tric": WORK / "candidates/WO3_tric_2106293.cif",
    "WO3_tetra": WORK / "candidates/WO3_tetra_1521533.cif",
}


def snapshot(project, candidate, label):
    hist = project.histogram(0)
    r = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": r.get("GOF"),
        "max_shift_over_esd": r.get("Max shft/sig"),
        "candidate_scale": candidate.HAPvalue("Scale", targethistlist=[hist]),
        "candidate_cell": candidate.get_cell(),
        "converged": r.get("converged"),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get(
            "parmFrozen", {}
        ).get("FrozenList", [])],
    }


def fit(tag, path):
    project = G2sc.G2Project(gpxfile=str(BASE))
    project.save(str(OUT / f"{tag}.gpx"))
    project.data["Controls"]["data"]["max cyc"] = 25
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.histogram(0)
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    candidate = project.add_phase(str(path), phasename=tag, histograms=[hist])
    candidate.setSampleProfile(hist, "size", "isotropic", 100.0, LGmix=1.0)
    candidate.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap = candidate.getHAPvalues(hist)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Scale"] = [0.05, True]
    project.refine()
    project.save()
    stages = [snapshot(project, candidate, "scale_test")]
    if stages[-1]["candidate_scale"] > 1e-5:
        candidate.set_refinements({"Cell": True})
        project.refine()
        project.refine()
        project.save()
        stages.append(snapshot(project, candidate, "cell_test"))
        candidate.clear_refinements({"Cell": True})
        project.refine()
        project.save()
        stages.append(snapshot(project, candidate, "fixed_cell_replay"))
    print(tag, stages[-1])
    return {
        "tag": tag, "source": str(path),
        "project": str(Path(project.filename).relative_to(WORK)),
        "stages": stages,
    }


def main():
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("warn")
    rows = []
    for tag, path in CANDIDATES.items():
        try:
            rows.append(fit(tag, path))
        except Exception as error:
            rows.append({"tag": tag, "source": str(path), "error": str(error)})
            print(tag, "ERROR", error)
    (OUT / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
