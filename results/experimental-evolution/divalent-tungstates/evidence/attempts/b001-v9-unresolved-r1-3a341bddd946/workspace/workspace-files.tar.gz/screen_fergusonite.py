#!/usr/bin/env python3
"""Matched-nuisance inventory tests around the indexed C2/c SrWO4 model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
OUT = WORK / "fergusonite_screening"
FILES = {
    "SrWO4_C2c": WORK / "candidates/SrWO4_fergusonite_indexed_from_CaWO4.cif",
    "WO3_mono_1528915": WORK / "candidates/WO3_mono_1528915.cif",
    "WO3_mono_1563541": WORK / "candidates/WO3_mono_1563541.cif",
    "WO3_mono_2311041": WORK / "candidates/WO3_mono_2311041.cif",
    "WO3_tric_2106293": WORK / "candidates/WO3_tric_2106293.cif",
    "WO3_ortho_2107312": Path(
        "<RUN>/"
        "resources/b001-c03/cif/2/10/73/2107312.cif"
    ),
    "WO3_tetra_1521532": WORK / "candidates/WO3_tetra_1521532.cif",
    "WO3_tetra_1521533": WORK / "candidates/WO3_tetra_1521533.cif",
    "SrW2O7_MgMo": WORK / "candidates/SrW2O7_from_MgMo2O7.cif",
    "SrW2O7_SrCr": WORK / "candidates/SrW2O7_from_SrCr2O7.cif",
    "SrCO3_ortho": WORK / "candidates/SrCO3_ortho_9008198.cif",
    "SrCO3_rhom": WORK / "candidates/SrCO3_rhom_1539128.cif",
    "Sr3W2O9_exact": WORK / "candidates/Sr3W2O9_2311977.cif",
    "Sr3W2O9_Ba": WORK / "candidates/Sr3W2O9_from_Ba3W2O9.cif",
    "Sr3WO6_SrU": WORK / "candidates/Sr3WO6_from_Sr3UO6.cif",
}

PAIR_TESTS = [
    "WO3_ortho_2107312", "WO3_tetra_1521532",
    "WO3_tetra_1521533", "SrW2O7_MgMo", "SrW2O7_SrCr",
    "SrCO3_ortho", "SrCO3_rhom", "Sr3W2O9_exact", "Sr3W2O9_Ba",
    "Sr3WO6_SrU",
]
COMBINATIONS = [("C2c_only", ["SrWO4_C2c"])] + [
    (f"C2c_plus_{name}", ["SrWO4_C2c", name]) for name in PAIR_TESTS
] + [
    (
        "C2c_mono2311041_SrW2O7_MgMo",
        ["SrWO4_C2c", "WO3_mono_2311041", "SrW2O7_MgMo"],
    ),
]


def neutralize(phase, hist, scale: float) -> None:
    phase.setSampleProfile(hist, "size", "isotropic", 100.0, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap = phase.getHAPvalues(hist)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Scale"] = [scale, True]


def fit(tag: str, names: list[str]) -> dict:
    project = G2sc.G2Project(newgpx=str(OUT / f"{tag}.gpx"))
    project.data["Controls"]["data"]["max cyc"] = 20
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.add_powder_histogram(
        str(WORK / "inputs/pattern.csv"),
        str(WORK / "instrument.instprm"),
        fmthint="comma",
    )
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for name, value in {
        "U": 100.0, "V": 0.0, "W": 50.0, "X": 0.5,
        "Y": 0.0, "SH/L": 0.002,
    }.items():
        inst[name][1] = value
        inst[name][2] = False

    phases = []
    for index, name in enumerate(names):
        phase = project.add_phase(
            str(FILES[name]), phasename=name, histograms=[hist]
        )
        neutralize(phase, hist, 1.0 if index == 0 else 0.15)
        phases.append(phase)

    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1", "refine": True, "no. coeffs": 8,
            "coeffs": [1050.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        }
    })
    project.refine()
    scale_test = {
        phase.name: phase.HAPvalue("Scale", targethistlist=[hist])
        for phase in phases
    }
    rwp_scale = hist.get_wR()

    for phase in phases:
        if scale_test[phase.name] > 1e-5:
            phase.set_refinements({"Cell": True})
    project.refine()
    project.refine()
    project.save()
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "tag": tag,
        "phases": names,
        "project": str(Path(project.filename).relative_to(WORK)),
        "scale_test": scale_test,
        "Rwp_scale_test_percent": rwp_scale,
        "final_scales": {
            phase.name: phase.HAPvalue("Scale", targethistlist=[hist])
            for phase in phases
        },
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "Rwp_percent": hist.get_wR(),
        "Rp_percent": hist.data["data"][0].get("R"),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "message": rvals.get("msg", ""),
    }


def main() -> None:
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("warn")
    rows = []
    for tag, names in COMBINATIONS:
        try:
            row = fit(tag, names)
        except Exception as error:
            row = {"tag": tag, "phases": names, "error": str(error)}
            print(tag, "ERROR", error)
        else:
            print(tag, f"Rwp={row['Rwp_percent']:.4f}", row["final_scales"])
        rows.append(row)
    (OUT / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
