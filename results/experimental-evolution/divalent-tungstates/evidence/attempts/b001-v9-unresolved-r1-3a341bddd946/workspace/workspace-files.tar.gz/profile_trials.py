#!/usr/bin/env python3
"""Profile and angular-correction trials from the accepted two-phase baseline."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
BASE = WORK / "fergusonite_screening/C2c_plus_WO3_ortho_2107312.gpx"
OUT = WORK / "correct_model_trials"


def summarize(project: G2sc.G2Project, tag: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "tag": tag,
        "project": str(Path(project.filename).relative_to(WORK)),
        "Rwp_percent": hist.get_wR(),
        "Rp_percent": hist.data["data"][0].get("R"),
        "GOF": rvals.get("GOF"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "converged": rvals.get("converged"),
        "profile": {
            key: {"value": inst[key][1], "refine": inst[key][2]}
            for key in ("U", "V", "W", "X", "Y", "SH/L", "Zero")
        },
        "sample": {
            key: {"value": sample[key][0], "refine": sample[key][1]}
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "frozen": [str(v) for v in project.data["Controls"]["data"].get(
            "parmFrozen", {}
        ).get("FrozenList", [])],
    }


def profile_trial(tag: str, terms: list[str]) -> dict:
    project = G2sc.G2Project(gpxfile=str(BASE))
    project.save(str(OUT / f"{tag}.gpx"))
    project.data["Controls"]["data"]["max cyc"] = 25
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for name, value in {
        "U": 100.0, "V": 0.0, "W": 50.0, "X": 0.5,
        "Y": 0.0, "SH/L": 0.002, "Zero": 0.0,
    }.items():
        inst[name][1] = value
        inst[name][2] = name in terms
    for name, maximum in (("U", 1000.0), ("W", 1000.0), ("X", 100.0)):
        project.set_Controls("parmMin", 0.0, variable=f":0:{name}")
        project.set_Controls("parmMax", maximum, variable=f":0:{name}")
    project.refine()
    project.refine()
    project.save()
    return summarize(project, tag)


def correction_trial(tag: str, source: Path, instrument_zero=False, shift=False) -> dict:
    project = G2sc.G2Project(gpxfile=str(source))
    project.save(str(OUT / f"{tag}.gpx"))
    project.data["Controls"]["data"]["max cyc"] = 25
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    inst["Zero"][1:] = [0.0, bool(instrument_zero)]
    sample["Shift"] = [0.0, bool(shift)]
    if instrument_zero:
        project.set_Controls("parmMin", -0.2, variable=":0:Zero")
        project.set_Controls("parmMax", 0.2, variable=":0:Zero")
    if shift:
        project.set_Controls("parmMin", -2.0, variable=":0:Shift")
        project.set_Controls("parmMax", 2.0, variable=":0:Shift")
    project.refine()
    project.refine()
    project.save()
    return summarize(project, tag)


def main() -> None:
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("warn")
    rows = []
    for tag, terms in [
        ("profile_W", ["W"]),
        ("profile_X", ["X"]),
        ("profile_WX", ["W", "X"]),
        ("profile_UW", ["U", "W"]),
        ("profile_UX", ["U", "X"]),
        ("profile_UWX", ["U", "W", "X"]),
    ]:
        row = profile_trial(tag, terms)
        rows.append(row)
        print(tag, row["Rwp_percent"], row["profile"], row["frozen"])

    valid = [
        row for row in rows
        if row["converged"] and not row["frozen"]
        and all(
            row["profile"][term]["value"] > 1e-6
            for term in ("U", "W", "X")
            if row["profile"][term]["refine"]
        )
    ]
    best = min(valid, key=lambda row: row["Rwp_percent"])
    best_path = WORK / best["project"]
    rows.append(correction_trial("best_plus_zero", best_path, instrument_zero=True))
    rows.append(correction_trial("best_plus_shift", best_path, shift=True))
    (OUT / "profile_summary.json").write_text(json.dumps(rows, indent=2) + "\n")
    print("best_unbounded", best["tag"])
    for row in rows[-2:]:
        print(row["tag"], row["Rwp_percent"], row["profile"], row["sample"])


if __name__ == "__main__":
    main()
