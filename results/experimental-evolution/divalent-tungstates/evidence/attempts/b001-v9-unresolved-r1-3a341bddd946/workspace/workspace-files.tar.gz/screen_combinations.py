#!/usr/bin/env python3
"""Replay-stable multiphase inventory tests under one neutral nuisance model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
OUT = WORK / "combination_screening"
FILES = {
    "SrWO4": WORK / "candidates/SrWO4_from_SrMoO4.cif",
    "WO3_mono": WORK / "candidates/WO3_mono_2311041.cif",
    "WO3_tric": WORK / "candidates/WO3_tric_2106293.cif",
    "WO3_tetra": WORK / "candidates/WO3_tetra_1521532.cif",
    "SrW2O7_MgMo": WORK / "candidates/SrW2O7_from_MgMo2O7.cif",
    "SrW2O7_SrCr": WORK / "candidates/SrW2O7_from_SrCr2O7.cif",
}
COMBINATIONS = [
    ("scheelite_monoWO3", ["SrWO4", "WO3_mono"]),
    ("scheelite_tricWO3", ["SrWO4", "WO3_tric"]),
    ("scheelite_tetraWO3", ["SrWO4", "WO3_tetra"]),
    ("scheelite_SrW2O7_MgMo", ["SrWO4", "SrW2O7_MgMo"]),
    ("scheelite_monoWO3_SrW2O7_MgMo", ["SrWO4", "WO3_mono", "SrW2O7_MgMo"]),
    ("scheelite_monoWO3_SrW2O7_SrCr", ["SrWO4", "WO3_mono", "SrW2O7_SrCr"]),
]


def neutralize(phase, hist, scale: float) -> None:
    phase.setSampleProfile(hist, "size", "isotropic", 100.0, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap = phase.getHAPvalues(hist)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Scale"] = [scale, True]


def fit(tag: str, names: list[str]) -> dict:
    project = G2sc.G2Project(newgpx=str(OUT / f"{tag}.gpx"))
    project.data["Controls"]["data"]["max cyc"] = 20
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.add_powder_histogram(
        str(WORK / "inputs/pattern.csv"),
        str(WORK / "instrument.instprm"),
        fmthint="comma",
    )
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for name, value in {"U": 100.0, "V": 0.0, "W": 50.0,
                        "X": 0.5, "Y": 0.0, "SH/L": 0.002}.items():
        inst[name][1] = value
        inst[name][2] = False
    phases = []
    for index, name in enumerate(names):
        phase = project.add_phase(
            str(FILES[name]), phasename=name, histograms=[hist]
        )
        if name == "SrWO4":
            cell = phase.data["General"]["Cell"]
            cell[1] = cell[2] = 5.50
            cell[3] = 12.12
            cell[4:7] = [90.0, 90.0, 90.0]
            cell[7] = cell[1] * cell[2] * cell[3]
        neutralize(phase, hist, 1.0 if index == 0 else 0.15)
        phases.append(phase)
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True,
                         "no. coeffs": 8,
                         "coeffs": [1050.0, 0.0, 0.0, 0.0,
                                    0.0, 0.0, 0.0, 0.0]}}
    )
    project.refine()
    scale_test = {
        phase.name: phase.HAPvalue("Scale", targethistlist=[hist])
        for phase in phases
    }
    rwp_scale = hist.get_wR()
    for phase in phases:
        if scale_test[phase.name] > 1e-5:
            phase.set_refinements({"Cell": True})
    project.refine()
    project.refine()
    project.save()
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "tag": tag,
        "project": str(Path(project.filename).relative_to(WORK)),
        "scale_test": scale_test,
        "Rwp_scale_test_percent": rwp_scale,
        "final_scales": {
            phase.name: phase.HAPvalue("Scale", targethistlist=[hist])
            for phase in phases
        },
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "Rwp_percent": hist.get_wR(),
        "Rp_percent": hist.data["data"][0].get("R"),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "message": rvals.get("msg", ""),
    }


def main() -> None:
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("warn")
    rows = [fit(tag, names) for tag, names in COMBINATIONS]
    (OUT / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")
    for row in rows:
        print(row["tag"], f"Rwp={row['Rwp_percent']:.4f}", row["final_scales"])


if __name__ == "__main__":
    main()
