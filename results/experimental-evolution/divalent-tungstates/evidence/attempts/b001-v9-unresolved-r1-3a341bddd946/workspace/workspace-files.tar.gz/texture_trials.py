#!/usr/bin/env python3
"""Symmetry-distinct low-index March-Dollase trials after nuisance controls."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
BASE = WORK / "nuisance_trials/background_12.gpx"
OUT = WORK / "texture_trials"
AXES = {
    "SrWO4_C2c": [
        ("a100", [1, 0, 0]), ("b010", [0, 1, 0]),
        ("c001", [0, 0, 1]), ("ac101", [1, 0, 1]),
        ("ab110", [1, 1, 0]), ("bc011", [0, 1, 1]),
    ],
    "WO3_ortho_2107312": [
        ("a100", [1, 0, 0]), ("b010", [0, 1, 0]),
        ("c001", [0, 0, 1]), ("ab110", [1, 1, 0]),
        ("ac101", [1, 0, 1]), ("bc011", [0, 1, 1]),
    ],
}


def fit(phase_name, axis_name, axis):
    tag = f"{phase_name}_{axis_name}"
    project = G2sc.G2Project(gpxfile=str(BASE))
    project.save(str(OUT / f"{tag}.gpx"))
    project.data["Controls"]["data"]["max cyc"] = 25
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.histogram(0)
    for phase in project.phases():
        po = phase.getHAPvalues(hist)["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = False
        po[3] = [0, 0, 1]
    phase = project.phase(phase_name)
    po = phase.getHAPvalues(hist)["Pref.Ori."]
    po[1] = 1.0
    po[2] = True
    po[3] = axis
    project.set_Controls("parmMin", 0.2, variable=f"{phase.id}:0:MD")
    project.set_Controls("parmMax", 5.0, variable=f"{phase.id}:0:MD")
    project.refine()
    project.refine()
    project.save()
    r = project.data["Covariance"]["data"].get("Rvals", {})
    row = {
        "tag": tag,
        "project": str(Path(project.filename).relative_to(WORK)),
        "phase": phase_name,
        "axis": axis,
        "ratio": phase.getHAPvalues(hist)["Pref.Ori."][1],
        "Rwp_percent": hist.get_wR(),
        "GOF": r.get("GOF"),
        "max_shift_over_esd": r.get("Max shft/sig"),
        "converged": r.get("converged"),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get(
            "parmFrozen", {}
        ).get("FrozenList", [])],
    }
    print(tag, row["Rwp_percent"], row["ratio"], row["max_shift_over_esd"], row["frozen"])
    return row


def main():
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("warn")
    rows = []
    for phase_name, axes in AXES.items():
        for axis_name, axis in axes:
            rows.append(fit(phase_name, axis_name, axis))
    (OUT / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
