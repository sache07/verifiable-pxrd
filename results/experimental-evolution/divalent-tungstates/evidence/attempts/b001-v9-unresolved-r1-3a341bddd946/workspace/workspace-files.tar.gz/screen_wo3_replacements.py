#!/usr/bin/env python3
"""Compare WO3 polymorphs as mutually exclusive three-phase replacements."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
ROOT = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)
OUT = WORK / "wo3_replacement_screen"
MAIN = WORK / "candidates/SrWO4_fergusonite_indexed_from_CaWO4.cif"
CARBONATE = ROOT / "9/00/81/9008198.cif"
WO3 = {
    "ortho_2107312": ROOT / "2/10/73/2107312.cif",
    "mono_2311041": ROOT / "2/31/10/2311041.cif",
    "mono_1563541": ROOT / "1/56/35/1563541.cif",
    "tric_2106293": ROOT / "2/10/62/2106293.cif",
    "tetra_1521533": ROOT / "1/52/15/1521533.cif",
}


MAIN_CELL = [
    7.783263586682184,
    12.136579648839628,
    5.598853702532103,
    90.0,
    135.83123606051848,
    90.0,
]


def assign_cell(phase, values):
    """Assign direct-cell values while preserving GSAS-II's list layout."""
    from GSASII import GSASIIlattice as G2lat

    cell = phase.data["General"]["Cell"]
    cell[1:7] = list(values)
    cell[7] = G2lat.calc_V(G2lat.cell2A(values))


def neutralize(phase, hist, scale):
    phase.setSampleProfile(hist, "size", "isotropic", 100.0, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap = phase.getHAPvalues(hist)
    hap["Scale"] = [scale, True]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]


def snapshot(project, label):
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "converged": rvals.get("converged"),
        "scales": {
            phase.name: phase.HAPvalue("Scale", targethistlist=[hist])
            for phase in project.phases()
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "frozen": [
            str(value)
            for value in project.data["Controls"]["data"].get(
                "parmFrozen", {}
            ).get("FrozenList", [])
        ],
    }


def refine(project, rows, label):
    project.refine()
    project.save()
    rows.append(snapshot(project, label))


def fit(tag, wo3_path):
    project = G2sc.G2Project(newgpx=str(OUT / f"{tag}.gpx"))
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 25
    controls["min dM/M"] = 1e-5
    controls.setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.add_powder_histogram(
        str(WORK / "inputs/pattern.csv"),
        str(WORK / "instrument.instprm"),
        fmthint="comma",
    )
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for name, value, flag in [
        ("U", 100.0, False), ("V", 0.0, False),
        ("W", 57.6, True), ("X", 2.37, True), ("Y", 0.0, False),
        ("SH/L", 0.002, False), ("Zero", 0.0, False),
        ("Polariz.", 0.5, False),
    ]:
        inst[name][1] = value
        inst[name][2] = flag
    hist.set_refinements({
        "Background": {"refine": True, "no. coeffs": 12}
    })

    main = project.add_phase(str(MAIN), phasename="SrWO4_C2c", histograms=[hist])
    assign_cell(main, MAIN_CELL)
    tungsten = project.add_phase(str(wo3_path), phasename=f"WO3_{tag}", histograms=[hist])
    carbonate = project.add_phase(str(CARBONATE), phasename="SrCO3_Pnma", histograms=[hist])
    project.set_Controls("parmMin", 0.0, variable=":0:W")
    project.set_Controls("parmMax", 1000.0, variable=":0:W")
    project.set_Controls("parmMin", 0.0, variable=":0:X")
    project.set_Controls("parmMax", 100.0, variable=":0:X")
    neutralize(main, hist, 5.8)
    neutralize(tungsten, hist, 1.1)
    neutralize(carbonate, hist, 3.4)
    mhap = main.getHAPvalues(hist)
    mhap["Pref.Ori."][1] = 0.765
    mhap["Pref.Ori."][2] = True
    mhap["Pref.Ori."][3] = [1, 1, 0]
    project.set_Controls("parmMin", 0.2, variable=f"{main.id}:0:MD")
    project.set_Controls("parmMax", 5.0, variable=f"{main.id}:0:MD")
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "

    rows = []
    refine(project, rows, "matched_scale_test")
    # Cell stages are separated to prevent dense low-symmetry reflection lists
    # from trading metrics between phases.
    for phase_name in [tungsten.name, main.name, carbonate.name] * 2:
        for phase in project.phases():
            phase.clear_refinements({"Cell": True})
        project.phase(phase_name).set_refinements({"Cell": True})
        refine(project, rows, f"cell_{phase_name}")
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    refine(project, rows, "fixed_cell_replay")
    print(tag, rows[-1]["Rwp_percent"], rows[-1]["scales"], rows[-1]["frozen"])
    return {
        "tag": tag,
        "source": str(wo3_path),
        "project": str(Path(project.filename).relative_to(WORK)),
        "stages": rows,
    }


def main():
    OUT.mkdir(exist_ok=True)
    G2sc.SetPrintLevel("warn")
    rows = []
    for tag, path in WO3.items():
        try:
            rows.append(fit(tag, path))
        except Exception as error:
            rows.append({"tag": tag, "source": str(path), "error": str(error)})
            print(tag, "ERROR", error)
    (OUT / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
