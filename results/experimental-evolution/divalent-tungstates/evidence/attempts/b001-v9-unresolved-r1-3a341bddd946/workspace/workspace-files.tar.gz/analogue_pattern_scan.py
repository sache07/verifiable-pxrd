#!/usr/bin/env python3
"""Rank local stoichiometric analogues against the positive residual profile."""

from __future__ import annotations

import gzip
import json
import math
import sys
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks

sys.path.insert(0, str(Path(__file__).resolve().parent / "learned"))
from stoichiometric_analogues import (  # noqa: E402
    reduced_amounts, signature, substitution_cost,
)

WORK = Path(__file__).resolve().parent
INDEX = Path(
    "<RUN>/"
    "resources/b001-c03/index.json.gz"
)
CIF_ROOT = INDEX.parent / "cif"
RESIDUAL_CSV = WORK / "residual_scan_input.csv"
TARGETS = ["SrWO4", "Sr2WO5", "Sr3WO6", "Sr3W2O9", "SrW2O7", "Sr2W3O11"]
WAVELENGTH = 1.540598

warnings.filterwarnings("ignore")


def cif_path(cod_id):
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def residual_data():
    arr = np.loadtxt(RESIDUAL_CSV, delimiter=",", skiprows=1)
    x = np.asarray(arr[:, 0], dtype=float)
    residual = np.clip(np.asarray(arr[:, 1], dtype=float), 0.0, None)
    step = float(np.median(np.diff(x)))
    smooth = gaussian_filter1d(residual, 0.10 / step)
    smooth /= max(float(smooth.max()), 1.0)
    peaks, props = find_peaks(residual, prominence=180.0, distance=5, width=2)
    keep = residual[peaks] > 150.0
    peaks = peaks[keep]
    weights = np.sqrt(residual[peaks])
    weights /= weights.sum()
    return x, smooth, x[peaks], weights


def scaled_positions(two_theta, lattice_scale):
    sine = np.sin(np.radians(two_theta / 2.0)) / lattice_scale
    valid = (sine > 0.0) & (sine < 1.0)
    out = np.full_like(two_theta, np.nan, dtype=float)
    out[valid] = np.degrees(2.0 * np.arcsin(sine[valid]))
    return out


def score_pattern(x, smooth, residual_peaks, residual_weights, positions, intensities):
    best = (-math.inf, None, None, None)
    theory_weights = np.sqrt(np.clip(intensities, 0.0, None))
    theory_weights /= max(float(theory_weights.sum()), 1e-12)
    for scale in np.linspace(0.80, 1.35, 111):
        pos = scaled_positions(positions, scale)
        keep = np.isfinite(pos) & (pos >= x[0]) & (pos <= x[-1])
        if not np.any(keep):
            continue
        p = pos[keep]
        w = theory_weights[keep]
        w /= w.sum()
        precision = float(np.sum(w * np.interp(p, x, smooth)))
        nearest = np.min(np.abs(residual_peaks[:, None] - p[None, :]), axis=1)
        coverage = float(np.sum(residual_weights * np.exp(-0.5 * (nearest / 0.14) ** 2)))
        combined = 0.72 * precision + 0.28 * coverage
        if combined > best[0]:
            best = (combined, scale, precision, coverage)
    return best


def main():
    x, smooth, residual_peaks, residual_weights = residual_data()
    target_data = {
        formula: (reduced_amounts(formula), signature(reduced_amounts(formula)))
        for formula in TARGETS
    }
    with gzip.open(INDEX, "rt") as handle:
        database = json.load(handle)

    candidates = []
    seen = set()
    for system, records in database.items():
        for formula, cod_id_raw, space_group, quality in records:
            cod_id = str(cod_id_raw)
            if cod_id in seen:
                continue
            try:
                amounts = reduced_amounts(formula)
            except Exception:
                continue
            target_formula = None
            cost = None
            for trial, (target_amounts, target_signature) in target_data.items():
                if signature(amounts) != target_signature:
                    continue
                trial_cost = substitution_cost(dict(target_amounts), amounts)
                if trial_cost <= 2.0 and (cost is None or trial_cost < cost):
                    target_formula, cost = trial, trial_cost
            if target_formula is None:
                continue
            path = cif_path(cod_id)
            if not path.is_file():
                continue
            candidates.append((target_formula, cost, formula, cod_id, space_group, quality, path))
            seen.add(cod_id)

    calculator = XRDCalculator(wavelength=WAVELENGTH, symprec=0)
    rows = []
    for index, (target, cost, formula, cod_id, sg, quality, path) in enumerate(candidates, start=1):
        try:
            structure = Structure.from_file(path)
            if len(structure) > 160:
                continue
            pattern = calculator.get_pattern(
                structure, two_theta_range=(8.0, 120.0), scaled=True
            )
            positions = np.asarray(pattern.x, dtype=float)
            intensities = np.asarray(pattern.y, dtype=float)
            keep = intensities >= 1.0
            if np.count_nonzero(keep) < 3:
                continue
            score, scale, precision, coverage = score_pattern(
                x, smooth, residual_peaks, residual_weights,
                positions[keep], intensities[keep],
            )
        except Exception as error:
            continue
        rows.append({
            "score": score,
            "precision": precision,
            "coverage": coverage,
            "lattice_scale": scale,
            "target_formula": target,
            "source_formula": formula,
            "cod_id": cod_id,
            "space_group": sg,
            "substitution_cost": cost,
            "quality": quality,
            "cif": str(path),
            "sites": len(structure),
        })
        if index % 50 == 0:
            print("scanned", index, "of", len(candidates))

    rows.sort(key=lambda row: row["score"], reverse=True)
    (WORK / "analogue_pattern_scan.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )
    print("candidate_count", len(candidates), "scored", len(rows))
    for row in rows[:40]:
        print(
            f"{row['score']:.4f} p={row['precision']:.4f} c={row['coverage']:.4f}",
            f"s={row['lattice_scale']:.3f}", row["target_formula"],
            row["source_formula"], row["cod_id"], "SG", row["space_group"],
        )


if __name__ == "__main__":
    main()
