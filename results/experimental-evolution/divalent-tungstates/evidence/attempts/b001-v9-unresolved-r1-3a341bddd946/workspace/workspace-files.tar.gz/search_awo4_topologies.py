#!/usr/bin/env python3
"""Rank local AB(O4) structure records against the dominant measured peaks."""

from __future__ import annotations

import gzip
import json
import math
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Structure
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks


WORK = Path(__file__).resolve().parent
INDEX = Path(
    "<RUN>/"
    "resources/b001-c03/index.json.gz"
)
CIF_ROOT = INDEX.parent / "cif"
WAVELENGTH = 1.540598

warnings.filterwarnings("ignore")


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def is_abo4(formula: str) -> bool:
    try:
        amounts = Composition(formula).reduced_composition.get_el_amt_dict()
    except Exception:
        return False
    if len(amounts) != 3 or "O" not in amounts:
        return False
    non_oxygen = sorted(amount / amounts["O"] for element, amount in amounts.items() if element != "O")
    return np.allclose(non_oxygen, [0.25, 0.25], atol=1e-5)


def observed_peaks():
    data = np.loadtxt(WORK / "inputs/pattern.csv", delimiter=",", skiprows=1)
    x, y = data[:, 0], data[:, 1]
    step = float(np.median(np.diff(x)))
    # A broad lower envelope is sufficient for peak ranking and does not enter
    # any quantitative refinement.
    broad = gaussian_filter1d(y, 2.5 / step)
    signal = np.clip(y - broad, 0.0, None)
    peaks, props = find_peaks(signal, prominence=100.0, distance=3, width=1)
    keep = (x[peaks] >= 10.0) & (props["prominences"] >= 100.0)
    peaks = peaks[keep]
    prominence = props["prominences"][keep]
    weights = np.sqrt(prominence)
    weights /= weights.sum()
    return x[peaks], weights, prominence


def scale_positions(two_theta: np.ndarray, lattice_scale: float) -> np.ndarray:
    sine = np.sin(np.radians(two_theta / 2.0)) / lattice_scale
    valid = (sine > 0.0) & (sine < 1.0)
    out = np.full_like(two_theta, np.nan, dtype=float)
    out[valid] = np.degrees(2.0 * np.arcsin(sine[valid]))
    return out


def score_pattern(obs_pos, obs_weight, calc_pos, calc_int, volume_per_formula):
    theory_weight = np.sqrt(np.clip(calc_int, 0.0, None))
    theory_weight /= theory_weight.sum()
    best = (-math.inf, None, None, None)
    # SrWO4 polymorphs cluster near 85--95 A^3 per formula unit. Keep a
    # deliberately wider physical interval but exclude scale aliases that
    # imply implausibly dilute/dense SrWO4 cells.
    scale_low = max(0.78, (72.0 / volume_per_formula) ** (1.0 / 3.0))
    scale_high = min(1.38, (108.0 / volume_per_formula) ** (1.0 / 3.0))
    if scale_low > scale_high:
        return best
    for scale in np.linspace(scale_low, scale_high, 161):
        positions = scale_positions(calc_pos, scale)
        keep = np.isfinite(positions) & (positions >= 9.9) & (positions <= 100.1)
        if np.count_nonzero(keep) < 3:
            continue
        positions = positions[keep]
        tw = theory_weight[keep]
        tw /= tw.sum()
        distance = np.abs(obs_pos[:, None] - positions[None, :])
        obs_nearest = np.min(distance, axis=1)
        calc_nearest = np.min(distance, axis=0)
        # A 0.12 degree tolerance is wider than an isolated low-angle peak but
        # narrow enough to discriminate the high-angle fingerprints.
        obs_match = np.exp(-0.5 * (obs_nearest / 0.12) ** 2)
        calc_match = np.exp(-0.5 * (calc_nearest / 0.12) ** 2)
        coverage = float(np.sum(obs_weight * obs_match))
        precision = float(np.sum(tw * calc_match))
        score = 0.55 * precision + 0.45 * coverage
        if score > best[0]:
            best = (score, scale, precision, coverage)
    return best


def main():
    obs_pos, obs_weight, obs_prominence = observed_peaks()
    with gzip.open(INDEX, "rt") as handle:
        database = json.load(handle)
    records = []
    seen = set()
    for entries in database.values():
        for formula, cod_id_raw, space_group, quality in entries:
            cod_id = str(cod_id_raw)
            if cod_id in seen or not is_abo4(formula):
                continue
            path = cif_path(cod_id)
            if path.is_file():
                records.append((formula, cod_id, space_group, quality, path))
                seen.add(cod_id)

    calculator = XRDCalculator(wavelength=WAVELENGTH, symprec=0)
    rows = []
    for index, (formula, cod_id, sg, quality, path) in enumerate(records, start=1):
        try:
            structure = Structure.from_file(path)
            if len(structure) > 160:
                continue
            pattern = calculator.get_pattern(structure, two_theta_range=(7.0, 125.0), scaled=True)
            positions = np.asarray(pattern.x, dtype=float)
            intensities = np.asarray(pattern.y, dtype=float)
            keep = intensities >= 1.0
            if np.count_nonzero(keep) < 3:
                continue
            reduced = structure.composition.reduced_composition
            formula_units = structure.composition.num_atoms / reduced.num_atoms
            volume_per_formula = structure.volume / formula_units
            score, scale, precision, coverage = score_pattern(
                obs_pos, obs_weight, positions[keep], intensities[keep],
                volume_per_formula,
            )
            if scale is None:
                continue
        except Exception:
            continue
        rows.append({
            "score": score,
            "precision": precision,
            "coverage": coverage,
            "lattice_scale": scale,
            "source_formula": formula,
            "cod_id": cod_id,
            "space_group": sg,
            "quality": quality,
            "cif": str(path),
            "sites": len(structure),
            "source_volume_per_formula": volume_per_formula,
            "adapted_volume_per_formula": volume_per_formula * scale**3,
        })
        if index % 100 == 0:
            print("scanned", index, "of", len(records))

    rows.sort(key=lambda row: row["score"], reverse=True)
    output = {
        "observed_peaks": [
            {"two_theta": float(p), "prominence": float(v), "weight": float(w)}
            for p, v, w in zip(obs_pos, obs_prominence, obs_weight)
        ],
        "candidates": rows,
    }
    (WORK / "awo4_topology_search.json").write_text(json.dumps(output, indent=2) + "\n")
    for row in rows[:50]:
        print(
            f"{row['score']:.4f}", f"p={row['precision']:.4f}",
            f"c={row['coverage']:.4f}", f"s={row['lattice_scale']:.4f}",
            row["source_formula"], row["cod_id"], "SG", row["space_group"],
        )


if __name__ == "__main__":
    main()
