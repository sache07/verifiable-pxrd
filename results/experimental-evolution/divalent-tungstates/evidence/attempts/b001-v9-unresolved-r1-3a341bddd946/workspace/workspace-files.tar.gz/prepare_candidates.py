#!/usr/bin/env python3
"""Prepare chemically adapted CIF candidates from health-screened COD parents."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)
OUT = Path("candidates")


def adapt(
    source: Path,
    substitutions: dict[str, str],
    output: Path,
    conventional: bool = False,
    lattice: Lattice | None = None,
    lattice_scale: float | None = None,
) -> None:
    structure = Structure.from_file(source)
    structure.remove_oxidation_states()
    structure.replace_species(substitutions)
    if lattice is not None:
        structure = Structure(
            lattice,
            [site.species for site in structure],
            [site.frac_coords for site in structure],
            site_properties=structure.site_properties,
        )
    elif lattice_scale is not None:
        structure = Structure(
            structure.lattice.scale(structure.volume * lattice_scale**3),
            [site.species for site in structure],
            [site.frac_coords for site in structure],
            site_properties=structure.site_properties,
        )
    if conventional:
        structure = SpacegroupAnalyzer(
            structure, symprec=0.01
        ).get_conventional_standard_structure()
    CifWriter(structure, symprec=0.01, refine_struct=False).write_file(output)


def standardize(source: Path, output: Path) -> None:
    """Remove CIF-import quirks while preserving sites, occupancy and symmetry."""
    structure = Structure.from_file(source)
    structure.remove_oxidation_states()
    structure = SpacegroupAnalyzer(structure, symprec=0.01).get_conventional_standard_structure()
    CifWriter(structure, symprec=0.01, refine_struct=False).write_file(output)


def main() -> None:
    OUT.mkdir(exist_ok=True)
    # Same A-site and tetrahedral framework; isovalent Mo6+ -> W6+.
    adapt(
        ROOT / "2/30/04/2300460.cif",
        {"Mo": "W"},
        OUT / "SrWO4_from_SrMoO4.cif",
    )
    # Pseudotetragonal metric exposed by the independent 004/200 residual
    # family after the distorted I2/a phase is fitted. The SrMoO4 parent
    # supplies the chemically direct scheelite coordinates.
    adapt(
        ROOT / "2/30/04/2300460.cif",
        {"Mo": "W"},
        OUT / "SrWO4_scheelite_indexed.cif",
        lattice=Lattice.tetragonal(5.475, 12.299),
    )
    # Independent scheelite parent with W already present; Ca2+ -> Sr2+.
    adapt(
        ROOT / "7/21/92/7219229.cif",
        {"Ca": "Sr"},
        OUT / "SrWO4_from_CaWO4.cif",
    )
    # Lower-symmetry AWO4 competitors.  The C2/c CaWO4 record is the
    # fergusonite-related distortion of scheelite; SrCrO4 and MgWO4 provide
    # independent monoclinic topologies while preserving A2+/B6+ on
    # substitution.  They are competitors, not phases to co-add.
    adapt(
        ROOT / "1/54/60/1546035.cif",
        {"Ca": "Sr"},
        OUT / "SrWO4_fergusonite_from_CaWO4.cif",
    )
    # Indexed from the independent 040, 002/200 and 121 families.  The 33.59
    # degree line is assigned to the WO3 competitor rather than forcing an
    # unsupported large a/c split.  The expanded metric is appropriate for
    # Sr2+ in the passing CaWO4 topology; coordinates and C2/c connectivity
    # remain those of the parent.
    adapt(
        ROOT / "1/54/60/1546035.cif",
        {"Ca": "Sr"},
        OUT / "SrWO4_fergusonite_indexed_from_CaWO4.cif",
        conventional=True,
        lattice=Lattice.monoclinic(5.483, 12.126, 5.483, 90.1),
    )
    # The same indexed metric in the source's direct C2/c basis. This avoids
    # the strongly correlated a-c/beta representation introduced by a
    # conventional-cell transformation (a ~ 7.75 A, beta ~ 135 degrees).
    direct_fergusonite = OUT / "SrWO4_fergusonite_direct_indexed_from_CaWO4.cif"
    adapt(
        ROOT / "1/54/60/1546035.cif",
        {"Ca": "Sr"},
        direct_fergusonite,
        conventional=False,
        lattice=Lattice.monoclinic(5.483, 12.126, 5.483, 90.1),
    )
    direct_fergusonite.write_text(
        direct_fergusonite.read_text().replace(
            "_symmetry_space_group_name_H-M   C2/c",
            "_symmetry_space_group_name_H-M   'I 1 2/a 1'",
        ).replace("_symmetry_Int_Tables_number   15\n", "")
    )
    # Independent C2/c coordinate sets used to challenge the CaWO4 parent.
    # CaMoO4 preserves the desired +2/+6 chemistry; YNbO4 and NdTaO4 preserve
    # charge balance (+3/+5) and the fergusonite topology but are less direct.
    for relative, substitutions, name in [
        ("8/10/02/8100225.cif", {"Ca": "Sr", "Mo": "W"},
         "SrWO4_fergusonite_from_CaMoO4.cif"),
        ("9/01/14/9011435.cif", {"Y": "Sr", "Nb": "W"},
         "SrWO4_fergusonite_from_YNbO4.cif"),
        ("9/00/97/9009753.cif", {"Nd": "Sr", "Ta": "W"},
         "SrWO4_fergusonite_from_NdTaO4.cif"),
    ]:
        adapt(
            ROOT / relative, substitutions, OUT / name,
            conventional=True,
            lattice=Lattice.monoclinic(5.483, 12.126, 5.483, 90.1),
        )
    adapt(
        ROOT / "1/54/78/1547817.cif",
        {"Cr": "W"},
        OUT / "SrWO4_monoclinic_from_SrCrO4.cif",
        conventional=True,
    )
    adapt(
        ROOT / "9/01/39/9013902.cif",
        {"Mg": "Sr"},
        OUT / "SrWO4_wolframite_from_MgWO4.cif",
        conventional=True,
    )
    # Balance-motivated non-1:1 tungstates. Each substitution preserves the
    # formal +2 A-site / +6 B-site charge pattern of the parent where known.
    adapt(
        ROOT / "2/00/17/2001752.cif",
        {"U": "W"},
        OUT / "Sr3WO6_from_Sr3UO6.cif",
        conventional=True,
    )
    adapt(
        ROOT / "1/56/30/1563081.cif",
        {"Ca": "Sr"},
        OUT / "Sr3WO6_from_Ca3WO6.cif",
        conventional=True,
    )
    adapt(
        ROOT / "1/52/97/1529756.cif",
        {"Ba": "Sr", "Re": "W"},
        OUT / "Sr2WO5_from_Ba2ReO5.cif",
    )
    adapt(
        ROOT / "1/53/38/1533878.cif",
        {"Ba": "Sr"},
        OUT / "Sr3W2O9_from_Ba3W2O9.cif",
    )
    adapt(
        ROOT / "1/54/20/1542062.cif",
        {"Cr": "W"},
        OUT / "SrW2O7_from_SrCr2O7.cif",
    )
    adapt(
        ROOT / "2/10/64/2106441.cif",
        {"Mg": "Sr", "Mo": "W"},
        OUT / "SrW2O7_from_MgMo2O7.cif",
    )
    # Residual-profile-ranked charge-balanced/topological competitors.  Each
    # metric is isotropically pre-scaled by the residual fingerprint match so
    # the required scale-before-cell test is meaningful rather than defeated
    # by the parent cation size.
    for relative, substitutions, name, scale in [
        ("1/53/77/1537702.cif", {"Ba": "Sr", "V": "W"},
         "SrW2O7_from_BaV2O7_scaled.cif", 1.110),
        ("1/00/12/1001202.cif", {"La": "Sr", "Re": "W"},
         "Sr3W2O9_from_La3Re2O9_scaled.cif", 1.240),
        ("1/52/12/1521238.cif", {"Sm": "Sr", "Re": "W"},
         "Sr3W2O9_from_Sm3Re2O9_scaled.cif", 1.135),
        ("2/00/27/2002715.cif", {"Eu": "Sr", "Ti": "W"},
         "Sr2WO5_from_Eu2TiO5_scaled.cif", 1.070),
        ("2/00/21/2002193.cif", {"Nd": "Sr", "Ti": "W"},
         "Sr2WO5_from_Nd2TiO5_scaled.cif", 1.050),
        ("1/53/52/1535227.cif", {"Li": "Sr", "Re": "W"},
         "SrWO4_from_LiReO4_scaled.cif", 1.160),
        ("4/00/08/4000807.cif", {"Cu": "Sr"},
         "SrWO4_from_CuWO4_scaled.cif", 1.165),
        ("5/91/03/5910329.cif", {"Ba": "Sr", "Mn": "W"},
         "SrWO4_from_BaMnO4_scaled.cif", 1.140),
        ("1/53/02/1530230.cif", {"La": "Sr", "Ta": "W"},
         "SrWO4_from_LaTaO4_scaled.cif", 1.035),
        ("1/53/45/1534530.cif", {"Eu": "Sr", "Ta": "W"},
         "Sr3WO6_from_Eu3TaO6_scaled.cif", 1.115),
    ]:
        adapt(
            ROOT / relative, substitutions, OUT / name,
            conventional=True, lattice_scale=scale,
        )
    for relative, name in [
        ("1/52/89/1528915.cif", "WO3_mono_1528915.cif"),
        ("1/56/35/1563541.cif", "WO3_mono_1563541.cif"),
        ("2/31/10/2311041.cif", "WO3_mono_2311041.cif"),
        ("2/10/62/2106293.cif", "WO3_tric_2106293.cif"),
        ("2/10/73/2107312.cif", "WO3_ortho_2107312.cif"),
        ("1/52/15/1521532.cif", "WO3_tetra_1521532.cif"),
        ("1/52/15/1521533.cif", "WO3_tetra_1521533.cif"),
        ("9/00/81/9008198.cif", "SrCO3_ortho_9008198.cif"),
        ("1/53/91/1539128.cif", "SrCO3_rhom_1539128.cif"),
        ("2/31/19/2311977.cif", "Sr3W2O9_2311977.cif"),
    ]:
        standardize(ROOT / relative, OUT / name)


if __name__ == "__main__":
    main()
