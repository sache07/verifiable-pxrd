#!/usr/bin/env python3
"""Freeze, replay, and export the accepted GSAS-II model."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
SOURCE = WORK / "final_no_scheelite_texture.gpx"
FINAL = WORK / "final.gpx"
FIT = WORK / "fit.csv"
RESULT = WORK / "result.json"

CIF_NAMES = {
    "SrWO4_C2c": "phase_SrWO4_fergusonite.cif",
    "SrWO4_scheelite": "phase_SrWO4_scheelite.cif",
    "WO3_ortho_2107312": "phase_WO3_orthorhombic.cif",
    "SrCO3_Pnma": "phase_SrCO3_orthorhombic.cif",
}

PHASE_METADATA = {
    "SrWO4_C2c": {
        "name": "fergusonite-related SrWO4",
        "formula": "SrWO4",
        "space_group": "C2/c",
    },
    "SrWO4_scheelite": {
        "name": "scheelite SrWO4",
        "formula": "SrWO4",
        "space_group": "I41/a",
    },
    "WO3_ortho_2107312": {
        "name": "orthorhombic WO3",
        "formula": "WO3",
        "space_group": "Pnma",
    },
    "SrCO3_Pnma": {
        "name": "orthorhombic SrCO3",
        "formula": "SrCO3",
        "space_group": "Pnma",
    },
}


def configure(project: G2sc.G2Project):
    """Apply the deliberately small accepted nuisance model."""
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 25
    controls["min dM/M"] = 1e-5
    controls.setdefault("parmFrozen", {})["FrozenList"] = []

    hist = project.histogram(0)
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    hist.set_refinements({"Background": {"refine": True, "no. coeffs": 12}})

    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [float(sample["Shift"][0]), True]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    inst = hist.data["Instrument Parameters"][0]
    accepted_profile = (
        ("U", 100.0, False),
        ("V", 0.0, False),
        ("W", max(1.0, float(inst["W"][1])), True),
        ("X", 0.0, False),
        ("Y", 0.0, False),
        ("SH/L", 0.002, False),
        ("Zero", 0.0, False),
        ("Polariz.", 0.5, False),
    )
    for name, value, refine in accepted_profile:
        inst[name][1] = value
        inst[name][2] = refine

    project.set_Controls("parmMin", 0.0, variable=":0:W")
    project.set_Controls("parmMax", 1000.0, variable=":0:W")
    project.set_Controls("parmMin", -500.0, variable=":0:Shift")
    project.set_Controls("parmMax", 500.0, variable=":0:Shift")

    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "

        # Inactive phase-profile terms are genuinely neutral.
        phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]
        hap["Pref.Ori."][0] = "MD"

        if phase.name == "SrWO4_C2c":
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [1, 1, 0]
            project.set_Controls("parmMin", 0.2, variable=f"{phase.id}:0:MD")
            project.set_Controls("parmMax", 5.0, variable=f"{phase.id}:0:MD")
        else:
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
            hap["Pref.Ori."][3] = [0, 0, 1]
    return hist


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    mass = hist.ComputeMassFracs()
    return {
        "label": label,
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": float(hist.data["data"][0].get("R")),
        "GOF": float(rvals["GOF"]),
        "max_shift_over_esd": float(rvals["Max shft/sig"]),
        "converged": bool(rvals["converged"]),
        "weight_fractions": {
            phase.name: float(mass[phase.name][0]) for phase in project.phases()
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "frozen": [
            str(item)
            for item in project.data["Controls"]["data"]
            .get("parmFrozen", {})
            .get("FrozenList", [])
        ],
    }


def refine_and_save(project: G2sc.G2Project, label: str) -> dict:
    project.refine()
    project.save()
    row = snapshot(project, label)
    print(label, row["Rwp_percent"], row["max_shift_over_esd"])
    return row


def export_outputs(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    profile = np.asarray(hist.data["data"][1], dtype=float)
    x, observed, calculated, difference = (
        profile[0], profile[1], profile[3], profile[5]
    )
    with FIT.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "difference"]
        )
        writer.writerows(zip(x, observed, calculated, difference))

    mass = hist.ComputeMassFracs()
    phases = []
    for phase in project.phases():
        cif_name = CIF_NAMES[phase.name]
        phase.export_CIF(str(WORK / cif_name))
        value, esd = mass[phase.name]
        phases.append(
            {
                **PHASE_METADATA[phase.name],
                "project_phase_name": phase.name,
                "cif_path": cif_name,
                "weight_fraction": float(value),
                "weight_fraction_esd_formal": float(esd),
            }
        )

    rvals = project.data["Covariance"]["data"]["Rvals"]
    rwp = float(hist.get_wR())
    gof = float(rvals["GOF"])
    result = {
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "fraction_basis": "normalized over the modeled crystalline phases",
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": float(hist.data["data"][0]["R"]),
            "R_expected_percent": rwp / gof,
            "GOF": gof,
            "chi_squared": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_variables": int(rvals["Nvars"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
            "converged": bool(rvals["converged"]),
        },
    }
    RESULT.write_text(json.dumps(result, indent=2) + "\n")
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    rows = []

    project = G2sc.G2Project(gpxfile=str(SOURCE))
    project.save(str(FINAL))
    configure(project)
    rows.append(refine_and_save(project, "pre_reopen_full_range_replay"))

    # Submitted values are always extracted after reopening and replaying.
    reopened = G2sc.G2Project(gpxfile=str(FINAL))
    configure(reopened)
    rows.append(refine_and_save(reopened, "reopened_full_range_replay"))
    reopened.save(str(FINAL))
    result = export_outputs(reopened)

    (WORK / "final_replay.json").write_text(
        json.dumps({"replays": rows, "result": result}, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
