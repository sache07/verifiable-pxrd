#!/usr/bin/env python3
"""Run GSAS-II unit-cell searches on selected observed peak families."""

from __future__ import annotations

import json
import math
from pathlib import Path

from GSASII import GSASIIindex as G2indx


WAVELENGTH = 1.540598

# These are deliberately separate hypotheses.  Peaks below 27 degrees are
# especially crowded by the WO3/Sr-W-O candidate patterns and are omitted
# from the first pass unless they form an internally plausible family.
FAMILIES = {
    "dominant_a": [
        (17.4556, 2309),
        (27.2027, 15126),
        (32.6359, 3267),
        (44.8280, 3179),
        (47.1426, 2313),
        (51.3913, 1516),
        (55.5314, 4106),
        (56.8354, 1592),
        (72.6569, 1290),
        (76.1015, 1072),
        (78.9159, 696),
        (86.7071, 1012),
        (95.0091, 795),
    ],
    "dominant_no17": [
        (27.2027, 15126),
        (32.6359, 3267),
        (44.8280, 3179),
        (47.1426, 2313),
        (51.3913, 1516),
        (55.5314, 4106),
        (56.8354, 1592),
        (72.6569, 1290),
        (76.1015, 1072),
        (78.9159, 696),
        (86.7071, 1012),
        (95.0091, 795),
    ],
    "middle_family": [
        (22.5085, 760),
        (22.9431, 1972),
        (23.8342, 3073),
        (24.6491, 867),
        (25.3011, 643),
        (25.9640, 566),
        (29.4412, 1440),
        (33.5922, 1427),
        (36.0806, 506),
        (37.4932, 867),
        (40.9053, 465),
        (49.4571, 725),
        (53.5429, 432),
        (61.9100, 483),
        (66.2892, 417),
        (72.0158, 540),
        (77.2208, 568),
        (81.6760, 519),
        (84.9251, 452),
        (91.6188, 510),
    ],
}

BRAVAIS_NAMES = [
    "Cubic-F", "Cubic-I", "Cubic-P", "Trigonal-R", "Hexagonal-P",
    "Tetragonal-I", "Tetragonal-P", "Orthorhombic-F", "Orthorhombic-I",
    "Orthorhombic-A", "Orthorhombic-B", "Orthorhombic-C",
    "Orthorhombic-P", "Monoclinic-I", "Monoclinic-A", "Monoclinic-C",
    "Monoclinic-P", "Triclinic",
]


def peak_rows(items):
    rows = []
    for position, intensity in sorted(items):
        d_obs = WAVELENGTH / (2.0 * math.sin(math.radians(position / 2.0)))
        rows.append([position, intensity, True, False, 0, 0, 0, d_obs, 0.0])
    return rows


def run_one(name, items, indices, start_volume, timeout):
    bravais = [i in indices for i in range(18)]
    controls = [0, 0.0, 5, start_volume]
    ok, dmin, cells = G2indx.DoIndexPeaks(
        peak_rows(items), controls, bravais, None,
        timeout=timeout, M20_min=3.0, return_Nc=True,
    )
    return {
        "family": name,
        "bravais_tested": [BRAVAIS_NAMES[i] for i in indices],
        "start_volume": start_volume,
        "ok": bool(ok),
        "dmin": dmin,
        "cells": [
            {
                "M20": c[0], "X20": c[1], "bravais": BRAVAIS_NAMES[c[2]],
                "a": c[3], "b": c[4], "c": c[5], "alpha": c[6],
                "beta": c[7], "gamma": c[8], "volume": c[9],
                "Nc": c[-1],
            }
            for c in sorted(cells, key=lambda x: x[0], reverse=True)
        ],
    }


def main():
    # High-to-intermediate symmetry first.  Lower symmetry is run separately
    # once the phase-family assignment has been tightened.
    jobs = [
        ("dominant_a", list(range(0, 13)), 100.0, 20),
        ("dominant_no17", list(range(0, 13)), 100.0, 20),
    ]
    results = []
    for family, indices, volume, timeout in jobs:
        results.append(run_one(family, FAMILIES[family], indices, volume, timeout))
    Path("indexing_results.json").write_text(json.dumps(results, indent=2) + "\n")
    for result in results:
        print("\n", result["family"], "top cells")
        for cell in result["cells"][:10]:
            print(cell)


if __name__ == "__main__":
    main()
