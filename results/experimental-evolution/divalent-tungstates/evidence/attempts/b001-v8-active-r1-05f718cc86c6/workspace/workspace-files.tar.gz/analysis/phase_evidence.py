#!/usr/bin/env python3
"""Report where a trial phase improves a powder-profile residual."""

import argparse

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline")
    parser.add_argument("trial")
    parser.add_argument("phase")
    parser.add_argument("--window", type=float, default=0.16)
    parser.add_argument("--count", type=int, default=15)
    args = parser.parse_args()

    base = G2sc.G2Project(args.baseline).histogram(0)
    trial = G2sc.G2Project(args.trial).histogram(0)
    xb, yb, wb, cb = (np.asarray(base.data["data"][1][i]) for i in (0, 1, 2, 3))
    xt, yt, wt, ct = (np.asarray(trial.data["data"][1][i]) for i in (0, 1, 2, 3))
    if not (np.allclose(xb, xt) and np.allclose(yb, yt)):
        raise RuntimeError("baseline and trial grids differ")

    refs_by_phase = trial.data["Reflection Lists"]
    refs = np.asarray(refs_by_phase[args.phase]["RefList"])
    competing = np.concatenate([
        np.asarray(value["RefList"])[:, 5]
        for name, value in refs_by_phase.items() if name != args.phase
    ])
    # Approximate reflection importance: multiplicity times calculated |F|^2.
    order = np.argsort(refs[:, 3] * refs[:, 9])[::-1]
    print("h k l  2theta  nearest_other  local_dchi2  residual_before  residual_after")
    for row in refs[order[:args.count]]:
        pos = row[5]
        mask = np.abs(xb - pos) <= args.window
        before = np.sum(wb[mask] * (yb[mask] - cb[mask]) ** 2)
        after = np.sum(wt[mask] * (yt[mask] - ct[mask]) ** 2)
        idx = int(np.argmin(np.abs(xb - pos)))
        nearest = float(np.min(np.abs(competing - pos)))
        print(
            f"{int(row[0]):2d} {int(row[1]):2d} {int(row[2]):2d} "
            f"{pos:8.4f} {nearest:13.4f} {before-after:12.3f} "
            f"{yb[idx]-cb[idx]:15.3f} {yt[idx]-ct[idx]:14.3f}"
        )


if __name__ == "__main__":
    main()
