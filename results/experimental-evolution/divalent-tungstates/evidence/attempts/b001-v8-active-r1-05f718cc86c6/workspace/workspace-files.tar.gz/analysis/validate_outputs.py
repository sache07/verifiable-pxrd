#!/usr/bin/env python3
"""Cross-check submitted JSON, CIF paths, profile and reopened GSAS project."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    result = json.loads((ROOT / "result.json").read_text())
    assert result["project_path"] == "final.gpx"
    project_path = ROOT / result["project_path"]
    assert project_path.is_file()
    assert result["profile_path"] == "fit.csv"

    fractions = []
    for phase in result["phases"]:
        assert isinstance(phase["weight_fraction"], (int, float))
        assert math.isfinite(phase["weight_fraction"])
        assert (ROOT / phase["cif_path"]).is_file()
        fractions.append(float(phase["weight_fraction"]))
    assert abs(sum(fractions) - 1.0) < 1.0e-12

    project = G2sc.G2Project(str(project_path))
    hist = project.histogram(0)
    mass = hist.ComputeMassFracs()
    public_to_project = {"MnWO4": "MnWO4", "WO3": "wo3_2106293", "Mn3O4": "Mn3O4"}
    for phase in result["phases"]:
        expected = mass[public_to_project[phase["name"]]][0]
        assert abs(phase["weight_fraction"] - expected) < 1.0e-10

    with (ROOT / "fit.csv").open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    profile = hist.data["data"][1]
    assert len(rows) == len(profile[0]) == 8301
    for index in range(len(rows)):
        values = [float(rows[index][key]) for key in ("two_theta_deg", "observed", "calculated", "difference", "background")]
        expected = [profile[0][index], profile[1][index], profile[3][index], profile[1][index]-profile[3][index], profile[4][index]]
        assert np.allclose(values, expected, rtol=0.0, atol=1.0e-10)

    stats = result["fit_statistics"]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    assert abs(stats["Rwp_percent"] - hist.get_wR()) < 1.0e-10
    assert abs(stats["goodness_of_fit"] - rvals["GOF"]) < 1.0e-10
    assert stats["converged"] is True and rvals["converged"] is True
    print(json.dumps({
        "fractions_sum": sum(fractions),
        "project_mass_fractions": mass,
        "profile_rows": len(rows),
        "Rwp_percent": hist.get_wR(),
        "GOF": rvals["GOF"],
        "converged": rvals["converged"],
    }, default=str, indent=2))


if __name__ == "__main__":
    main()
