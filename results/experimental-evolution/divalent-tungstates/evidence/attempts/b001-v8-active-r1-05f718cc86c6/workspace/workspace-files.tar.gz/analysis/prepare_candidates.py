#!/usr/bin/env python3
"""Prepare reproducible MnWO4 analogue models for profile comparison."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(
    "<RUN>/"
    "resources/b001-c04/cif"
)
OUT = Path(__file__).resolve().parent / "candidates"

# Approximate ambient MnWO4 wolframite metric, close enough for a cell/zero
# refinement while keeping every analogue comparison on identical peak positions.
MNWO4_LATTICE = Lattice.monoclinic(4.829, 5.758, 4.996, 91.15)

PARENTS = {
    "mnwo4_from_fe9008124": ROOT / "9/00/81/9008124.cif",
    "mnwo4_from_zn1520641": ROOT / "1/52/06/1520641.cif",
    "mnwo4_from_mg9013902": ROOT / "9/01/39/9013902.cif",
    "mnwo4_from_cd1520645": ROOT / "1/52/06/1520645.cif",
    "mnwo4_from_fe1567215": ROOT / "1/56/72/1567215.cif",
    "mnwo4_from_fe1568792": ROOT / "1/56/87/1568792.cif",
}

EXACT_SOURCES = {
    "wo3_1563541_clean": ROOT / "1/56/35/1563541.cif",
    "wo3_2106293_clean": ROOT / "2/10/62/2106293.cif",
    "wo3_1528915_clean": ROOT / "1/52/89/1528915.cif",
    "mn3o4_1011262_clean": ROOT / "1/01/12/1011262.cif",
    "mn3o4_9001963_clean": ROOT / "9/00/19/9001963.cif",
    "mn3wo6_2002703_clean": ROOT / "2/00/27/2002703.cif",
}


def adapt(parent: Path, destination: Path) -> None:
    source = Structure.from_file(parent)
    species = []
    for site in source:
        symbol = next(iter(site.species.elements)).symbol
        species.append(symbol if symbol in {"W", "O"} else "Mn")
    adapted = Structure(
        MNWO4_LATTICE,
        species,
        [site.frac_coords for site in source],
        coords_are_cartesian=False,
        to_unit_cell=True,
    )
    CifWriter(adapted, symprec=0.02, refine_struct=False).write_file(destination)
    with destination.open("a") as handle:
        handle.write(f"\n# Adapted isostructurally from COD {parent.stem}.\n")


def sanitize(parent: Path, destination: Path) -> None:
    """Strip oxidation-state spellings that GSAS-II can misread as H."""
    source = Structure.from_file(parent)
    clean = Structure(
        source.lattice,
        [next(iter(site.species.elements)).symbol for site in source],
        [site.frac_coords for site in source],
        coords_are_cartesian=False,
        to_unit_cell=True,
    )
    CifWriter(clean, symprec=0.02, refine_struct=False).write_file(destination)
    with destination.open("a") as handle:
        handle.write(f"\n# Element-symbol-clean copy of COD {parent.stem}.\n")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    for name, parent in PARENTS.items():
        adapt(parent, OUT / f"{name}.cif")
    for name, parent in EXACT_SOURCES.items():
        sanitize(parent, OUT / f"{name}.cif")


if __name__ == "__main__":
    main()
