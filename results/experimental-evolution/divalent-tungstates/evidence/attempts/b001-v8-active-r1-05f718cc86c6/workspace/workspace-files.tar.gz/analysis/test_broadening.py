#!/usr/bin/env python3
"""Challenge a saved baseline with one phase-specific broadening model."""

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("out")
    parser.add_argument("phase", type=int)
    parser.add_argument("mode", choices=("size", "strain"))
    args = parser.parse_args()

    project = G2sc.G2Project(args.base, newgpx=args.out)
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    # Restore neutral opposing mechanism before activating the requested one.
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    if args.mode == "size":
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
    else:
        hap["Mustrain"][1][0] = 300.0
        hap["Mustrain"][2][0] = True

    rows = []
    for cycle in range(2):
        project.refine(makeBack=False)
        rvals = project.data["Covariance"]["data"]["Rvals"]
        rows.append(
            {
                "cycle": cycle,
                "Rwp": hist.get_wR(),
                "GOF": rvals.get("GOF"),
                "converged": rvals.get("converged"),
                "max_shift_over_sigma": rvals.get("Max shft/sig"),
                "size_um": hap["Size"][1][0],
                "strain_micro": hap["Mustrain"][1][0],
                "mass_fractions": hist.ComputeMassFracs(),
            }
        )
    project.save()
    print(json.dumps({"file": args.out, "phase": phase.name, "mode": args.mode, "history": rows}, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
