#!/usr/bin/env python3
"""Numerically compare observed and calculated widths for selected peaks."""

from __future__ import annotations

import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def interpolate_crossing(x1, y1, x2, y2, level):
    if y2 == y1:
        return 0.5 * (x1 + x2)
    return x1 + (level - y1) * (x2 - x1) / (y2 - y1)


def width_at_half_height(x, y, target, search=0.14, window=0.45):
    region = np.where(np.abs(x - target) <= window)[0]
    candidates = np.where(np.abs(x - target) <= search)[0]
    peak = int(candidates[np.argmax(y[candidates])])
    lo, hi = int(region[0]), int(region[-1])
    # Local baseline from the lower of the two edge medians. This is robust to
    # a weak neighboring line entering one edge of the inspection window.
    edge = max(3, min(10, len(region) // 8))
    baseline = min(float(np.median(y[lo:lo+edge])), float(np.median(y[hi-edge+1:hi+1])))
    level = baseline + 0.5 * (float(y[peak]) - baseline)

    left = peak
    while left > lo and y[left] > level:
        left -= 1
    right = peak
    while right < hi and y[right] > level:
        right += 1
    if left == lo or right == hi:
        raise RuntimeError(f"half-height crossing not found near {target}")
    xleft = interpolate_crossing(x[left], y[left], x[left+1], y[left+1], level)
    xright = interpolate_crossing(x[right-1], y[right-1], x[right], y[right], level)
    xpos = float(x[peak])
    return {
        "position_deg": xpos,
        "fwhm_deg": xright - xleft,
        "left_half_width_deg": xpos - xleft,
        "right_half_width_deg": xright - xpos,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("targets", nargs="*", type=float, default=[15.108, 40.079, 70.994, 88.044])
    args = parser.parse_args()

    project = G2sc.G2Project(args.project)
    data = project.histogram(0).data["data"][1]
    x, yobs, ycalc, background = (np.asarray(data[i], dtype=float) for i in (0, 1, 3, 4))
    observed_net = yobs - background
    calculated_net = ycalc - background
    rows = []
    for target in args.targets:
        rows.append({
            "target_deg": target,
            "observed": width_at_half_height(x, observed_net, target),
            "calculated": width_at_half_height(x, calculated_net, target),
        })
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
