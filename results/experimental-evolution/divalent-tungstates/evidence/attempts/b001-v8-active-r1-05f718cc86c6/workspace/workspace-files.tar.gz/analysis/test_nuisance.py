#!/usr/bin/env python3
"""Replay controlled common-profile and intensity nuisance alternatives."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("out")
    parser.add_argument(
        "mode",
        choices=("background6", "background8", "background10", "background12", "background14", "background16", "polarization", "roughness", "roughness_b", "shl", "x_refine", "x_zero"),
    )
    args = parser.parse_args()

    project = G2sc.G2Project(args.base, newgpx=args.out)
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    if args.mode.startswith("background"):
        count = int(args.mode.removeprefix("background"))
        background = hist.data["Background"][0]
        coeffs = list(background[3:])
        background[2] = count
        background[3:] = (coeffs + [0.0] * count)[:count]
        background[1] = True
    elif args.mode == "polarization":
        inst["Polariz."][2] = True
    elif args.mode == "roughness":
        sample["SurfRoughA"] = [0.5, True]
        sample["SurfRoughB"] = [0.05, True]
    elif args.mode == "roughness_b":
        sample["SurfRoughA"] = [0.5, False]
        sample["SurfRoughB"] = [0.05, True]
    elif args.mode == "shl":
        inst["SH/L"][2] = True
    elif args.mode == "x_refine":
        inst["X"][2] = True
    elif args.mode == "x_zero":
        inst["X"][1] = 0.0
        inst["X"][2] = False

    rows = []
    for cycle in range(2):
        project.refine(makeBack=False)
        rvals = project.data["Covariance"]["data"]["Rvals"]
        rows.append({
            "cycle": cycle,
            "Rwp": hist.get_wR(),
            "GOF": rvals.get("GOF"),
            "converged": rvals.get("converged"),
            "max_shift_over_sigma": rvals.get("Max shft/sig"),
            "mass_fractions": hist.ComputeMassFracs(),
            "background_coefficients": hist.data["Background"][0][3:],
            "polarization": inst["Polariz."][1],
            "surface_roughness": [sample["SurfRoughA"][0], sample["SurfRoughB"][0]],
            "U_W_X": [inst[key][1] for key in ("U", "W", "X")],
        })
    project.save()
    print(json.dumps({"file": args.out, "mode": args.mode, "history": rows}, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
