#!/usr/bin/env python3
"""Add one watch-list phase to a converged baseline and replay GSAS-II."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def neutralize_hap(phase, histogram, scale: float) -> None:
    hap = phase.data["Histograms"][histogram.name]
    hap["Size"] = [
        "isotropic",
        [1000.0, 1000.0, 1.0],
        [False, False, False],
        [0, 0, 1],
        [1000.0, 1000.0, 1000.0, 0.0, 0.0, 0.0],
        [False] * 6,
    ]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][4] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    hap["Scale"] = [scale, True]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("cif")
    parser.add_argument("out")
    parser.add_argument("name")
    parser.add_argument("--scale", type=float, default=0.05)
    args = parser.parse_args()

    project = G2sc.G2Project(args.base, newgpx=args.out)
    project.data["Controls"]["data"]["max cyc"] = 6
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    phase = project.add_phase(
        args.cif,
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize_hap(phase, hist, args.scale)
    phase.set_refinements({"Cell": False})

    rows = []
    for cycle in range(3):
        # Establish a positive scale before allowing the new cell metric to
        # move. This prevents an absent/weak candidate from destroying its
        # metric tensor on the first least-squares step.
        if cycle == 1 and phase.data["Histograms"][hist.name]["Scale"][0] > 0:
            phase.set_refinements({"Cell": True})
        try:
            project.refine(makeBack=False)
        except Exception as exc:
            rows.append({"cycle": cycle, "error": str(exc)})
            break
        rvals = project.data["Covariance"]["data"]["Rvals"]
        rows.append(
            {
                "cycle": cycle,
                "Rwp": hist.get_wR(),
                "GOF": rvals.get("GOF"),
                "converged": rvals.get("converged"),
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
                "cell": phase.get_cell(),
            }
        )
        if rvals.get("converged") and cycle > 0:
            break
    project.save()
    try:
        mass_fractions = hist.ComputeMassFracs()
    except Exception as exc:
        mass_fractions = {"error": str(exc)}
    print(
        json.dumps(
            {
                "file": args.out,
                "phase": args.name,
                "history": rows,
                "mass_fractions": mass_fractions,
                "HAP": phase.data["Histograms"][hist.name],
            },
            default=str,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
