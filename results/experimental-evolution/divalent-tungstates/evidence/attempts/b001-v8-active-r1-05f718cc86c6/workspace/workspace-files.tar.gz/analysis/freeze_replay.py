#!/usr/bin/env python3
"""Freeze atomic coordinates and replay all already-active GSAS-II terms."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("out")
    args = parser.parse_args()

    project = G2sc.G2Project(args.base, newgpx=args.out)
    project.data["Controls"]["data"]["max cyc"] = 12
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})

    hist = project.histogram(0)
    rows = []
    for cycle in range(3):
        project.refine(makeBack=False)
        rvals = project.data["Covariance"]["data"]["Rvals"]
        rows.append({
            "cycle": cycle,
            "Rwp": hist.get_wR(),
            "GOF": rvals.get("GOF"),
            "converged": rvals.get("converged"),
            "max_shift_over_sigma": rvals.get("Max shft/sig"),
            "mass_fractions": hist.ComputeMassFracs(),
        })
        if rvals.get("converged") and cycle > 0:
            break
    project.save()
    print(json.dumps({"file": args.out, "history": rows}, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
