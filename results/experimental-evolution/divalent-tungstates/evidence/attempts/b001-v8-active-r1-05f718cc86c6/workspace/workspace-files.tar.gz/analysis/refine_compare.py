#!/usr/bin/env python3
"""Run a controlled one-phase GSAS-II comparison refinement."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


DATA = Path("analysis/data/pattern.xye").resolve()
IPRM = Path("analysis/cukka.instprm").resolve()


def neutralize(phase, hist) -> None:
    """Make every inactive phase-profile contribution explicitly neutral."""
    hap = phase.data["Histograms"][hist.name]
    hap["Size"] = [
        "isotropic",
        [1000.0, 1000.0, 1.0],
        [False, False, False],
        [0, 0, 1],
        [1000.0, 1000.0, 1000.0, 0.0, 0.0, 0.0],
        [False] * 6,
    ]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][4] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    hap["Scale"] = [1.0, False]

    sample = hist.data["Sample Parameters"]
    for key in (
        "Absorption",
        "DisplaceX",
        "DisplaceY",
        "Shift",
        "Transparency",
        "SurfRoughA",
        "SurfRoughB",
    ):
        sample[key][0] = 0.0
        sample[key][1] = False
    sample["Scale"][1] = True


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    residuals = hist.data["data"][0]
    return {
        "label": label,
        "wR_percent": residuals.get("wR"),
        "Rp_percent": residuals.get("R"),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "cell": phase.get_cell(),
        "instrument": {key: inst[key][1] for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "sample": {
            key: sample[key][0]
            for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "background": list(hist.data["Background"][0]),
        "varyList": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }


def refine(project, log: list[dict], label: str) -> None:
    project.refine(makeBack=False)
    row = snapshot(project, label)
    log.append(row)
    print(json.dumps(row, sort_keys=True))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("cif", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--phase-name", default="MnWO4")
    parser.add_argument("--angular", choices=("shift", "zero"), default="shift")
    parser.add_argument("--background", type=int, default=8)
    args = parser.parse_args()

    args.out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(args.out.resolve()))
    hist = project.add_powder_histogram(str(DATA), str(IPRM), fmthint="xye")
    phase = project.add_phase(
        str(args.cif.resolve()),
        phasename=args.phase_name,
        histograms=[hist],
        fmthint="CIF",
    )
    project.data["Controls"]["data"]["max cyc"] = 12
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    neutralize(phase, hist)

    # Low-order smooth background; coefficients are solved with scale first.
    hist.set_refinements(
        {
            "Limits": [9.90343322, 100.09455322],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": args.background,
                "coeffs": [1200.0] + [0.0] * (args.background - 1),
            },
        }
    )
    inst = hist.data["Instrument Parameters"][0]
    inst["Zero"] = [0.0, 0.0, False]
    inst["Polariz."] = [0.5, 0.5, False]
    # U was challenged in a preliminary replay and moved negative. Keep it at
    # its physical boundary while W and X describe the common width baseline.
    inst["U"] = [0.0, 0.0, False]
    inst["V"] = [0.0, 0.0, False]
    inst["W"] = [1.0, 1.0, False]
    inst["X"] = [0.1, 0.1, False]
    inst["Y"] = [0.0, 0.0, False]
    inst["Z"] = [0.0, 0.0, False]
    inst["SH/L"] = [0.002, 0.002, False]

    sample = hist.data["Sample Parameters"]
    if args.angular == "shift":
        sample["Shift"] = [500.0, False]
    else:
        inst["Zero"] = [-0.28, -0.28, False]

    log: list[dict] = []
    refine(project, log, "scale_background")

    phase.set_refinements({"Cell": True})
    if args.angular == "shift":
        sample["Shift"][1] = True
    else:
        inst["Zero"][2] = True
    refine(project, log, "cell_angular")

    inst["W"][2] = True
    inst["X"][2] = True
    refine(project, log, "profile_WX")

    refine(project, log, "profile_WX_replay_1")
    refine(project, log, "profile_WX_replay_2")

    project.save()
    with args.out.with_suffix(".json").open("w") as handle:
        json.dump(log, handle, indent=2)


if __name__ == "__main__":
    main()
