#!/usr/bin/env python3
"""Prune, replay, reopen and export the accepted GSAS-II model."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis/compare/final_shl.gpx"
FINAL = ROOT / "final.gpx"


def prune(project: G2sc.G2Project) -> None:
    """Keep accepted terms and make every inactive nuisance term neutral."""
    project.data["Controls"]["data"]["max cyc"] = 12
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    x = np.asarray(hist.data["data"][1][0], dtype=float)
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]

    background = hist.data["Background"][0]
    background[1] = True
    background[2] = 8
    background[3:] = background[3:11]

    inst = hist.data["Instrument Parameters"][0]
    for key in ("Zero", "V", "Y", "Z"):
        inst[key][1] = 0.0
        inst[key][2] = False
    inst["I(L2)/I(L1)"][1] = 0.5
    inst["I(L2)/I(L1)"][2] = False
    inst["X"][2] = False
    for key in ("Polariz.", "U", "W", "SH/L"):
        inst[key][2] = True
    if inst["U"][1] < 0 or inst["W"][1] < 0 or inst["X"][1] < 0:
        raise RuntimeError("accepted common-profile terms must be nonnegative")

    sample = hist.data["Sample Parameters"]
    sample["Scale"][1] = True
    sample["Shift"][1] = True
    for key in ("Absorption", "DisplaceX", "DisplaceY", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][0] = 0.0
        sample[key][1] = False

    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][4] = [0.0] * len(hap["Mustrain"][4])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"] = [0.0, False]
        hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
        hap["Size"][0] = "isotropic"
        if phase.name == "wo3_2106293":
            hap["Size"][2] = [True, False, False]
        else:
            hap["Size"][1] = [10.0, 10.0, 1.0]
            hap["Size"][2] = [False, False, False]


def replay(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    project.refine(makeBack=False)
    project.save()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    return {
        "Rwp": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_over_sigma": rvals.get("Max shft/sig"),
    }


def main() -> None:
    project = G2sc.G2Project(str(BASE), newgpx=str(FINAL))
    prune(project)
    project.save()
    history = [replay(project)]

    # Required freeze check: reopen the exact saved project and replay the full
    # measured range before generating any submitted derivative.
    project = G2sc.G2Project(str(FINAL))
    history.append(replay(project))
    project = G2sc.G2Project(str(FINAL))
    hist = project.histogram(0)

    output_names = {
        "MnWO4": ("MnWO4", "MnWO4.cif"),
        "wo3_2106293": ("WO3", "WO3.cif"),
        "Mn3O4": ("Mn3O4", "Mn3O4.cif"),
    }
    for phase in project.phases():
        phase.export_CIF(str(ROOT / output_names[phase.name][1]))

    data = hist.data["data"][1]
    x, yobs, ycalc, background = (np.asarray(data[i], dtype=float) for i in (0, 1, 3, 4))
    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference", "background"])
        writer.writerows(zip(x, yobs, ycalc, yobs - ycalc, background))

    mass = hist.ComputeMassFracs()
    total = sum(value[0] for value in mass.values())
    phase_rows = []
    for phase in project.phases():
        public_name, cif_name = output_names[phase.name]
        value, esd = mass[phase.name]
        phase_rows.append({
            "name": public_name,
            "formula": public_name,
            "cif_path": cif_name,
            "weight_fraction": float(value / total),
            "weight_fraction_formal_esd": float(esd / total),
            "cell": {key: float(val) for key, val in phase.get_cell().items()},
        })
    # Make the normalized sum exactly one in serialized arithmetic.
    phase_rows[-1]["weight_fraction"] = 1.0 - sum(row["weight_fraction"] for row in phase_rows[:-1])

    rvals = project.data["Covariance"]["data"]["Rvals"]
    powder_stats = hist.data["data"][0]
    result = {
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "phases": phase_rows,
        "fit_statistics": {
            "Rp_percent": float(powder_stats["R"]),
            "Rwp_percent": float(powder_stats["wR"]),
            "Rexp_percent": float(powder_stats["wR"] / rvals["GOF"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
            "durbin_watson": float(powder_stats["Durbin-Watson"]),
            "converged": bool(rvals["converged"]),
            "max_shift_over_sigma": float(rvals["Max shft/sig"]),
        },
        "fraction_basis": "normalized over modeled crystalline phases",
    }
    with (ROOT / "result.json").open("w") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")
    with (ROOT / "analysis/final_replay.json").open("w") as handle:
        json.dump(history, handle, indent=2)
        handle.write("\n")
    print(json.dumps({"replay": history, "result": result}, indent=2))


if __name__ == "__main__":
    main()
