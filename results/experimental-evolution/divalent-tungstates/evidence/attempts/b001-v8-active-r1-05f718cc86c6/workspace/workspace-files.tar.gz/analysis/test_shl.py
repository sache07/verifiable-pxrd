#!/usr/bin/env python3
"""Replay a fixed axial-divergence value from a common GSAS-II baseline."""

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("out")
    parser.add_argument("value", type=float)
    parser.add_argument("--fix-x", type=float)
    args = parser.parse_args()

    project = G2sc.G2Project(args.base, newgpx=args.out)
    project.data["Controls"]["data"]["max cyc"] = 8
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["SH/L"][1] = args.value
    inst["SH/L"][2] = False
    if args.fix_x is not None:
        inst["X"][1] = args.fix_x
        inst["X"][2] = False
    for _ in range(2):
        project.refine(makeBack=False)
        if project.data["Covariance"]["data"]["Rvals"].get("converged"):
            break
    project.save()
    print(
        json.dumps(
            {
                "file": args.out,
                "SH/L": inst["SH/L"][1],
                "Rwp": hist.get_wR(),
                "GOF": project.data["Covariance"]["data"]["Rvals"].get("GOF"),
                "converged": project.data["Covariance"]["data"]["Rvals"].get("converged"),
                "W": inst["W"][1],
                "X": inst["X"][1],
                "shift": hist.data["Sample Parameters"]["Shift"][0],
                "cell": project.phase(0).get_cell(),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
