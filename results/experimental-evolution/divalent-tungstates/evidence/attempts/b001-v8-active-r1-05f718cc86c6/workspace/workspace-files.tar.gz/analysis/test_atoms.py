#!/usr/bin/env python3
"""Test positional refinement for a selected phase from a saved baseline."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("out")
    parser.add_argument("phase", type=int)
    args = parser.parse_args()

    project = G2sc.G2Project(args.base, newgpx=args.out)
    project.data["Controls"]["data"]["max cyc"] = 12
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    phase.set_refinements({"Atoms": {"all": "X"}})

    rows = []
    for cycle in range(3):
        project.refine(makeBack=False)
        rvals = project.data["Covariance"]["data"]["Rvals"]
        cx, ct, _, _ = phase.data["General"]["AtomPtrs"]
        rows.append({
            "cycle": cycle,
            "Rwp": hist.get_wR(),
            "GOF": rvals.get("GOF"),
            "converged": rvals.get("converged"),
            "max_shift_over_sigma": rvals.get("Max shft/sig"),
            "mass_fractions": hist.ComputeMassFracs(),
            "atoms": [
                {"label": atom[ct-1], "type": atom[ct], "xyz": atom[cx:cx+3], "refine": atom[cx+5]}
                for atom in phase.data["Atoms"]
            ],
        })
        if rvals.get("converged") and cycle > 0:
            break
    project.save()
    print(json.dumps({"file": args.out, "phase": phase.name, "history": rows}, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
