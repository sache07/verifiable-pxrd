#!/usr/bin/env python3
"""Scale-only watch-list challenge from a converged GSAS-II baseline."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def neutralize_hap(phase, histogram, scale: float) -> None:
    hap = phase.data["Histograms"][histogram.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    hap["Scale"] = [scale, True]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("cif")
    parser.add_argument("out")
    parser.add_argument("name")
    parser.add_argument("--scale", type=float, default=0.005)
    args = parser.parse_args()

    project = G2sc.G2Project(args.base, newgpx=args.out)
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    phase = project.add_phase(args.cif, phasename=args.name, histograms=[hist], fmthint="CIF")
    neutralize_hap(phase, hist, args.scale)
    phase.set_refinements({"Cell": False})

    rows = []
    for cycle in range(2):
        project.refine(makeBack=False)
        rvals = project.data["Covariance"]["data"]["Rvals"]
        rows.append({
            "cycle": cycle,
            "Rwp": hist.get_wR(),
            "GOF": rvals.get("GOF"),
            "converged": rvals.get("converged"),
            "max_shift_over_sigma": rvals.get("Max shft/sig"),
            "scale": phase.data["Histograms"][hist.name]["Scale"][0],
            "mass_fractions": hist.ComputeMassFracs(),
        })
        if rvals.get("converged") and cycle > 0:
            break
    project.save()
    print(json.dumps({"file": args.out, "phase": args.name, "history": rows}, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
