from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIobj as G2obj

from final_profile import HERE, replay, summarize


BASE = HERE / "intensity_base.gpx"
AXES = {
    0: [(0, 0, 1), (1, 0, 0), (1, 1, 0)],  # tetragonal
    1: [(1, 0, 0), (0, 1, 0), (0, 0, 1)],  # monoclinic
    2: [(1, 0, 0), (0, 1, 0), (0, 0, 1)],  # orthorhombic
}


def branch(phase_id: int, axis: tuple[int, int, int]):
    tag = "".join(str(i) for i in axis)
    project = G2sc.G2Project(
        str(BASE), newgpx=str(HERE / f"texture_{phase_id}_{tag}.gpx")
    )
    hist = project.histogram(0)
    phase = project.phase(phase_id)
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = list(axis)
    controls = project.data["Controls"]["data"]
    controls.setdefault("parmMinDict", {})[
        G2obj.G2VarObj(f"{phase_id}:0:MD")
    ] = 0.2
    controls.setdefault("parmMaxDict", {})[
        G2obj.G2VarObj(f"{phase_id}:0:MD")
    ] = 5.0
    project = replay(project, 2)
    summary = summarize(project, f"{phase.name}_MD_{axis}")
    summary["preferred_orientation"] = phase.data["Histograms"][hist.name][
        "Pref.Ori."
    ][:4]
    return summary


results = []
for phase_id, axes in AXES.items():
    for axis in axes:
        results.append(branch(phase_id, axis))
(HERE / "texture_summary.json").write_text(json.dumps(results, indent=2))
