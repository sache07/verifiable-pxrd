import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from inventory_screen import CARBONATE, SCHEELITE, WO3, cod, run_model


def main() -> None:
    cases = [
        (
            "valid_scheelite_ca",
            [("SrWO4", SCHEELITE["CaWO4-7219229->SrWO4"]), ("WO3", WO3["2311041"]), ("SrCO3", CARBONATE["9008198"])],
        ),
        (
            "valid_scheelite_eu",
            [("SrWO4", SCHEELITE["EuWO4-1561850->SrWO4"]), ("WO3", WO3["2311041"]), ("SrCO3", CARBONATE["9008198"])],
        ),
        (
            "valid_wo3_1528915",
            [("SrWO4", SCHEELITE["CaWO4-7219229->SrWO4"]), ("WO3", WO3["1528915"]), ("SrCO3", CARBONATE["9008198"])],
        ),
        (
            "valid_wo3_2311041",
            [("SrWO4", SCHEELITE["CaWO4-7219229->SrWO4"]), ("WO3", WO3["2311041"]), ("SrCO3", CARBONATE["9008198"])],
        ),
        (
            "valid_wo3_2106293",
            [("SrWO4", SCHEELITE["CaWO4-7219229->SrWO4"]), ("WO3", WO3["2106293"]), ("SrCO3", CARBONATE["9008198"])],
        ),
        (
            "valid_carbonate_pnma",
            [("SrWO4", SCHEELITE["CaWO4-7219229->SrWO4"]), ("WO3", WO3["2311041"]), ("SrCO3", CARBONATE["9008198"])],
        ),
        (
            "valid_carbonate_r3m",
            [("SrWO4", SCHEELITE["CaWO4-7219229->SrWO4"]), ("WO3", WO3["2311041"]), ("SrCO3", CARBONATE["1539128"])],
        ),
        (
            "valid_sr3w2o9_replacement",
            [("Sr3W2O9", cod("2311977")), ("WO3", WO3["2311041"]), ("SrCO3", CARBONATE["9008198"])],
        ),
        (
            "valid_sr3w2o9_added",
            [("SrWO4", SCHEELITE["CaWO4-7219229->SrWO4"]), ("WO3", WO3["2311041"]), ("SrCO3", CARBONATE["9008198"]), ("Sr3W2O9", cod("2311977"))],
        ),
    ]
    results = []
    for label, specs in cases:
        results.append(run_model(label, specs))
    (Path(__file__).resolve().parent / "selected_inventory.json").write_text(
        json.dumps(results, indent=2)
    )


if __name__ == "__main__":
    main()
