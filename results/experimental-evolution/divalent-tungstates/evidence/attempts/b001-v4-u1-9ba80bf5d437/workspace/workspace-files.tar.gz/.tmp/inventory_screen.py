from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIobj as G2obj


HERE = Path(__file__).resolve().parent
ROOT = Path(
    "<RUN>/resources/"
    "b001-c03/cif"
)
RUNS = HERE / "inventory_runs"
RUNS.mkdir(exist_ok=True)
G2sc.SetPrintLevel("warn")


def cod(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


SCHEELITE = {
    "EuWO4-1561850->SrWO4": HERE
    / "candidates"
    / "srwo4_from_euwo4_1561850.cif",
    "CaWO4-7219229->SrWO4": HERE
    / "candidates"
    / "srwo4_from_cawo4_7219229.cif",
    "SrMoO4-2300460->SrWO4": HERE
    / "candidates"
    / "srwo4_from_srmoo4_2300460.cif",
    "fergusonite-CaWO4-1546035->SrWO4": HERE
    / "candidates"
    / "srwo4_fergusonite_from_cawo4_1546035.cif",
}
WO3 = {
    cid: cod(cid)
    for cid in [
        "1528915",
        "1563541",
        "2311041",
        "2106293",
        "1521532",
        "1521533",
        "1010618",
        "1004057",
        "2107312",
    ]
}
CARBONATE = {cid: cod(cid) for cid in ["9008198", "1539128"]}


def set_value(inst: dict, key: str, value: float) -> None:
    inst[key][0] = value
    inst[key][1] = value
    inst[key][2] = False


def add_limits(project: G2sc.G2Project, nphases: int) -> None:
    controls = project.data["Controls"]["data"]
    mins = controls.setdefault("parmMinDict", {})
    maxs = controls.setdefault("parmMaxDict", {})
    for pid in range(nphases):
        mins[G2obj.G2VarObj(f"{pid}:0:Scale")] = 1e-10
    for key, lo, hi in [
        (":0:Zero", -1.0, 0.0),
        (":0:U", 0.0, 200.0),
        (":0:W", 0.1, 200.0),
        (":0:X", 0.0, 20.0),
    ]:
        mins[G2obj.G2VarObj(key)] = lo
        maxs[G2obj.G2VarObj(key)] = hi


def refine_and_reopen(project: G2sc.G2Project) -> G2sc.G2Project:
    project.save()
    project.refine()
    project.save()
    return G2sc.G2Project(project.filename)


def run_model(label: str, specs: Iterable[tuple[str, Path]]) -> dict:
    np.seterr(all="warn", under="ignore")
    safe = "".join(c if c.isalnum() else "_" for c in label)[:100]
    gpx = RUNS / f"{safe}.gpx"
    project = G2sc.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(
        str(HERE / "pattern.xye"),
        str(HERE / "cu_kalpha.instprm"),
        fmthint="xye",
    )
    # Neutralize the redundant overall histogram scale and all sample effects.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    for name in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]:
        if name in hist.data["Sample Parameters"]:
            hist.data["Sample Parameters"][name] = [0.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"Zero": -0.610, "U": 0.0, "V": 0.0, "W": 35.0,
                       "X": 1.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.002}.items():
        set_value(inst, key, value)
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 10,
                "coeffs": [1100.0] + [0.0] * 9,
            },
        }
    )
    phases = []
    for phase_name, path in specs:
        phase = project.add_phase(
            str(path),
            phasename=phase_name,
            histograms=[hist],
            fmthint="CIF",
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [0.3, True]
        # Inventory profile: no phase-specific broadening or intensity effects.
        hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Extinction"] = [0.0, False]
        hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
        phases.append(phase)
    project.data["Controls"]["data"]["max cyc"] = 7
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    add_limits(project, len(phases))
    project.save()

    # Equal modest nuisance schedule for every candidate.
    project = refine_and_reopen(project)  # background + all scales
    hist = project.histogram(0)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project = refine_and_reopen(project)  # zero + cells + background + scales
    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    project = refine_and_reopen(project)  # provisional common profile
    project = refine_and_reopen(project)  # fresh full-range replay

    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    covariance = project.data.get("Covariance", {}).get("data", {})
    frozen = [str(x) for x in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])]
    try:
        fractions = {
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": repr(exc)}
    summary = {
        "label": label,
        "gpx": str(gpx),
        "Rwp_percent": hist.get_wR(),
        "Rp_percent": hist.data["data"][0].get("R"),
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "zero_deg": inst["Zero"][1],
        "profile": {k: inst[k][1] for k in ["U", "V", "W", "X", "Y", "SH/L"]},
        "phases": [],
        "mass_fractions": fractions,
        "frozen": frozen,
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        prefix = f"{phase.id}:0:"
        summary["phases"].append(
            {
                "name": phase.name,
                "scale": hap["Scale"][0],
                "cell": phase.get_cell(),
                "Rf_percent": hist.data["data"][0].get(prefix + "Rf"),
                "Rf2_percent": hist.data["data"][0].get(prefix + "Rf^2"),
            }
        )
    print(json.dumps(summary, sort_keys=True))
    return summary


def main() -> None:
    accepted_scheelite = SCHEELITE["EuWO4-1561850->SrWO4"]
    accepted_wo3 = WO3["2311041"]
    accepted_carbonate = CARBONATE["9008198"]
    results = []

    for key, path in SCHEELITE.items():
        results.append(
            run_model(
                f"scheelite_{key}",
                [("SrWO4", path), ("WO3", accepted_wo3), ("SrCO3", accepted_carbonate)],
            )
        )
    for key, path in WO3.items():
        results.append(
            run_model(
                f"wo3_{key}",
                [("SrWO4", accepted_scheelite), ("WO3", path), ("SrCO3", accepted_carbonate)],
            )
        )
    for key, path in CARBONATE.items():
        results.append(
            run_model(
                f"carbonate_{key}",
                [("SrWO4", accepted_scheelite), ("WO3", accepted_wo3), ("SrCO3", path)],
            )
        )

    # The only exact higher strontium tungstate is pressure-synthesized. Test it
    # both as a replacement product and as a fourth phase, under the same profile.
    results.append(
        run_model(
            "sr3w2o9_replaces_srwo4",
            [("Sr3W2O9", cod("2311977")), ("WO3", accepted_wo3), ("SrCO3", accepted_carbonate)],
        )
    )
    results.append(
        run_model(
            "sr3w2o9_added",
            [
                ("SrWO4", accepted_scheelite),
                ("WO3", accepted_wo3),
                ("SrCO3", accepted_carbonate),
                ("Sr3W2O9", cod("2311977")),
            ],
        )
    )
    (HERE / "inventory_screen.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
