import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIobj as G2obj

from final_profile import HERE, replay, summarize


project = G2sc.G2Project(
    str(HERE / "broadening_1_size.gpx"),
    newgpx=str(HERE / "broadening_wo3_size_strain.gpx"),
)
phase = project.phase(1)
hist = project.histogram(0)
hap = phase.data["Histograms"][hist.name]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][0] = 100.0
hap["Mustrain"][1][2] = 1.0
hap["Mustrain"][2] = [True, False, False]
controls = project.data["Controls"]["data"]
controls.setdefault("parmMinDict", {})[G2obj.G2VarObj("1:0:Mustrain;i")] = 0.0
controls.setdefault("parmMaxDict", {})[G2obj.G2VarObj("1:0:Mustrain;i")] = 10000.0
project = replay(project, 2)
summary = summarize(project, "WO3_size_plus_strain")
summary["size"] = phase.data["Histograms"][hist.name]["Size"]
summary["mustrain"] = phase.data["Histograms"][hist.name]["Mustrain"]
cov = project.data["Covariance"]["data"]
summary["broadening_variables"] = {
    key: {"value": float(value), "sigma": float(sigma)}
    for key, value, sigma in zip(cov["varyList"], cov["variables"], cov["sig"])
    if key.startswith("1:0:Size") or key.startswith("1:0:Mustrain")
}
(HERE / "wo3_combined_summary.json").write_text(json.dumps(summary, indent=2))
