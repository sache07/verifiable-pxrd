from pathlib import Path
import pprint

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
G2sc.SetPrintLevel("all")
project = G2sc.G2Project(newgpx=str(HERE / "test.gpx"))
hist = project.add_powder_histogram(
    str(HERE / "pattern.xye"),
    str(HERE / "cu_kalpha.instprm"),
    fmthint="xye",
)
phase = project.add_phase(
    str(HERE / "candidates" / "srwo4_from_euwo4_1561850.cif"),
    phasename="SrWO4 scheelite",
    histograms=[hist],
    fmthint="CIF",
)
hist.set_refinements(
    {
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 10,
            "coeffs": [1100.0] + [0.0] * 9,
        },
    }
)
phase.set_HAP_refinements({"Scale": True}, [hist])
project.data["Controls"]["data"]["max cyc"] = 8
project.save()

print("HIST", hist.name)
print("INST")
pprint.pp(hist.data["Instrument Parameters"])
print("SAMPLE")
pprint.pp(hist.data["Sample Parameters"])
print("HAP")
pprint.pp(phase.data["Histograms"][hist.name])
print("CELL", phase.get_cell())

project.refine()
project.save()
print("AFTER", hist.get_wR(), hist.data["data"][0])
print("HAP scale", phase.data["Histograms"][hist.name]["Scale"])
