import json

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIobj as G2obj

from final_profile import HERE, replay, summarize


def set_md(project, phase_id, axis):
    hist = project.histogram(0)
    phase = project.phase(phase_id)
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0:4] = ["MD", 1.0, True, list(axis)]
    controls = project.data["Controls"]["data"]
    controls.setdefault("parmMinDict", {})[
        G2obj.G2VarObj(f"{phase_id}:0:MD")
    ] = 0.2
    controls.setdefault("parmMaxDict", {})[
        G2obj.G2VarObj(f"{phase_id}:0:MD")
    ] = 5.0


project = G2sc.G2Project(
    str(HERE / "intensity_base.gpx"),
    newgpx=str(HERE / "texture_combined.gpx"),
)
set_md(project, 0, (1, 1, 0))
set_md(project, 1, (0, 0, 1))
project = replay(project, 2)
project.save(HERE / "texture_combined.gpx")
results = [summarize(project, "SrWO4_110_plus_WO3_001")]
results[0]["texture"] = {
    phase.name: phase.data["Histograms"][project.histogram(0).name]["Pref.Ori."][:4]
    for phase in project.phases()
}

for axis in [(1, 0, 0), (0, 1, 0), (0, 0, 1)]:
    tag = "".join(str(i) for i in axis)
    branch = G2sc.G2Project(
        str(HERE / "texture_combined.gpx"),
        newgpx=str(HERE / f"texture_combined_carbonate_{tag}.gpx"),
    )
    set_md(branch, 2, axis)
    branch = replay(branch, 2)
    summary = summarize(branch, f"combined_plus_SrCO3_{axis}")
    summary["texture"] = {
        phase.name: phase.data["Histograms"][branch.histogram(0).name]["Pref.Ori."][:4]
        for phase in branch.phases()
    }
    results.append(summary)

(HERE / "combined_texture_summary.json").write_text(json.dumps(results, indent=2))
