from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from final_profile import correlations


HERE = Path(__file__).resolve().parent
WORK = HERE.parent
SOURCE = HERE / "texture_combined_carbonate_001.gpx"
FINAL = WORK / "final.gpx"

G2sc.SetPrintLevel("warn")


def native_replay(project: G2sc.G2Project, count: int = 2) -> G2sc.G2Project:
    for _ in range(count):
        project.save()
        project = G2sc.G2Project(project.filename)
        project.refine()
        project.save()
        project = G2sc.G2Project(project.filename)
    return project


project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
hist = project.histogram(0)
x = hist.data["data"][1][0]
hist.data["Limits"][1] = [float(x[0]), float(x[-1])]

# Make every rejected nuisance term explicitly neutral and fixed in the final
# project. The accepted WO3 isotropic size and three MD terms are untouched.
sample = hist.data["Sample Parameters"]
sample["Scale"] = [1.0, False]
for key in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]:
    sample[key] = [0.0, False]

inst = hist.data["Instrument Parameters"][0]
for key in ["U", "V", "Y"]:
    inst[key][0:3] = [0.0, 0.0, False]
inst["SH/L"][0:3] = [0.002, 0.002, False]

for phase_id, phase in enumerate(project.phases()):
    hap = phase.data["Histograms"][hist.name]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Mustrain"] = [
        "isotropic",
        [0.0, 0.0, 1.0],
        [False, False, False],
        [0, 0, 1],
        [0.01, 0.01, 0.01, 0.01],
        [False, False, False, False],
    ]
    if phase_id != 1:
        hap["Size"] = [
            "isotropic",
            [10.0, 10.0, 1.0],
            [False, False, False],
            [0, 0, 1],
            [1.0, 1.0, 1.0, 0.0, 0.0, 0.0],
            [False, False, False, False, False, False],
        ]
    for atom in phase.atoms():
        atom.refinement_flags = " "

controls = project.data["Controls"]["data"]
controls["parmFrozen"] = {"FrozenList": []}
controls["max cyc"] = 10
controls["min dM/M"] = 1.0e-5

project.save()
project = native_replay(project, 2)
project.save(FINAL)
project = G2sc.G2Project(str(FINAL))
hist = project.histogram(0)
inst = hist.data["Instrument Parameters"][0]

# Export the exact structures held by final.gpx after its final replay.
cif_names = {"SrWO4": "SrWO4.cif", "WO3": "WO3.cif", "SrCO3": "SrCO3.cif"}
for phase in project.phases():
    phase.export_CIF(str(WORK / cif_names[phase.name]))

x, yobs, weight, ycalc, background, difference = hist.data["data"][1]
np.savetxt(
    WORK / "fit.csv",
    np.column_stack([x, yobs, ycalc, difference]),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference",
    comments="",
    fmt=["%.8f", "%.8g", "%.8g", "%.8g"],
)

cov = project.data["Covariance"]["data"]
vary = cov.get("varyList", [])
values = dict(zip(vary, cov.get("variables", [])))
sigmas = dict(zip(vary, cov.get("sig", [])))
mass = hist.ComputeMassFracs()
mass_total = sum(value for value, sigma in mass.values())

formulas = {"SrWO4": "SrWO4", "WO3": "WO3", "SrCO3": "SrCO3"}
phase_results = []
for phase in project.phases():
    value, sigma = mass[phase.name]
    cell, cell_sigma = phase.get_cell_and_esd()
    phase_results.append(
        {
            "name": phase.name,
            "formula": formulas[phase.name],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": cif_names[phase.name],
            "weight_fraction": value / mass_total,
            "weight_fraction_formal_esd": sigma / mass_total,
            "unit_cell": cell,
            "unit_cell_formal_esd": cell_sigma,
        }
    )

rdata = hist.data["data"][0]
rvals = cov.get("Rvals", {})
result = {
    "phases": phase_results,
    "fit_statistics": {
        "Rwp_percent": float(rdata["wR"]),
        "Rp_percent": float(rdata["R"]),
        "Rexp_percent": float(rdata["wRmin"]),
        "GOF": float(rvals["GOF"]),
        "chi_square": float(rvals["chisq"]),
        "number_observations": int(rvals["Nobs"]),
        "number_refined_parameters": int(rvals["Nvars"]),
        "durbin_watson": float(rdata["Durbin-Watson"]),
        "weighting": "Poisson working weights, sigma=sqrt(observed counts); no sigmas supplied",
    },
    "project_path": "final.gpx",
    "profile_path": "fit.csv",
    "weight_fraction_basis": "normalized over the modeled crystalline phases",
}
(WORK / "result.json").write_text(json.dumps(result, indent=2) + "\n")

# Machine-readable final audit used for the report and consistency checks.
frozen = controls = project.data["Controls"]["data"].get("parmFrozen", {})
audit = {
    "project": str(FINAL),
    "full_range_deg": [float(x[0]), float(x[-1])],
    "number_profile_points": int(len(x)),
    "fraction_sum": float(sum(p["weight_fraction"] for p in phase_results)),
    "frozen": {key: [str(item) for item in val] for key, val in frozen.items()},
    "correlations_abs_ge_0.8": correlations(project),
    "converged": bool(rvals.get("converged", False)),
    "max_shift_over_esd": float(rvals.get("Max shft/sig", np.nan)),
    "instrument": {
        key: {"value": float(inst[key][1]), "refine": bool(inst[key][2])}
        for key in ["Zero", "U", "V", "W", "X", "Y", "SH/L"]
    },
    "phase_terms": {},
}
for phase_id, phase in enumerate(project.phases()):
    hap = phase.data["Histograms"][hist.name]
    audit["phase_terms"][phase.name] = {
        "scale": hap["Scale"],
        "preferred_orientation": hap["Pref.Ori."][:4],
        "size": hap["Size"][:3],
        "mustrain": hap["Mustrain"][:3],
        "extinction": hap["Extinction"],
        "atom_refinement_flags": [atom.refinement_flags for atom in phase.atoms()],
    }
    for suffix in ["MD", "Size;i"]:
        key = f"{phase_id}:0:{suffix}"
        if key in values:
            audit["phase_terms"][phase.name][suffix] = {
                "value": float(values[key]),
                "formal_esd": float(sigmas[key]),
            }
(HERE / "final_audit.json").write_text(json.dumps(audit, indent=2) + "\n")

print(json.dumps({"result": result, "audit": audit}, sort_keys=True))
