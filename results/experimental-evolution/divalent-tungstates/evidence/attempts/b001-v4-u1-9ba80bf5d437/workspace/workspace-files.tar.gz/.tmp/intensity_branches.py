from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIobj as G2obj

from final_profile import HERE, replay, summarize


BASE = HERE / "intensity_base.gpx"


def add_bound(project, name, lo, hi):
    controls = project.data["Controls"]["data"]
    controls.setdefault("parmMinDict", {})[G2obj.G2VarObj(name)] = lo
    controls.setdefault("parmMaxDict", {})[G2obj.G2VarObj(name)] = hi


def atom_branch():
    project = G2sc.G2Project(str(BASE), newgpx=str(HERE / "intensity_srwo4_oxygen.gpx"))
    phase = project.phase(0)
    phase.set_refinements({"Atoms": {"O2": "X"}})
    project = replay(project, 2)
    summary = summarize(project, "SrWO4_oxygen_coordinates")
    atom = project.phase(0).atom("O2")
    summary["oxygen"] = {
        "coordinates": list(atom.coordinates),
        "flags": atom.refinement_flags,
    }
    return summary


def extinction_branch(phase_id):
    project = G2sc.G2Project(
        str(BASE), newgpx=str(HERE / f"intensity_extinction_{phase_id}.gpx")
    )
    phase = project.phase(phase_id)
    hist = project.histogram(0)
    phase.data["Histograms"][hist.name]["Extinction"] = [0.001, True]
    add_bound(project, f"{phase_id}:0:Extinction", 0.0, 1.0e6)
    project = replay(project, 2)
    summary = summarize(project, f"{phase.name}_extinction")
    summary["extinction"] = phase.data["Histograms"][hist.name]["Extinction"]
    return summary


results = [atom_branch()]
results.extend(extinction_branch(i) for i in range(3))
(HERE / "intensity_summary.json").write_text(json.dumps(results, indent=2))
