from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIobj as G2obj


HERE = Path(__file__).resolve().parent
ROOT = Path(
    "<RUN>/resources/"
    "b001-c03/cif"
)
G2sc.SetPrintLevel("warn")
np.seterr(all="warn", under="ignore")


def cod(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def set_inst(inst: dict, key: str, value: float, refine: bool = False) -> None:
    inst[key][0] = value
    inst[key][1] = value
    inst[key][2] = refine


def bounds(project: G2sc.G2Project) -> None:
    controls = project.data["Controls"]["data"]
    mins = controls.setdefault("parmMinDict", {})
    maxs = controls.setdefault("parmMaxDict", {})
    for pid in range(3):
        mins[G2obj.G2VarObj(f"{pid}:0:Scale")] = 1e-10
    for key, lo, hi in [
        (":0:Zero", -1.0, 0.0),
        (":0:U", 0.0, 200.0),
        (":0:W", 0.1, 200.0),
        (":0:X", 0.0, 20.0),
        (":0:SH/L", 0.002, 0.2),
    ]:
        mins[G2obj.G2VarObj(key)] = lo
        maxs[G2obj.G2VarObj(key)] = hi


def reopen(project: G2sc.G2Project) -> G2sc.G2Project:
    project.save()
    return G2sc.G2Project(project.filename)


def replay(project: G2sc.G2Project, count: int = 1) -> G2sc.G2Project:
    for _ in range(count):
        project.save()
        project.refine()
        project.save()
        project = G2sc.G2Project(project.filename)
    return project


def correlations(project: G2sc.G2Project, cutoff: float = 0.8) -> list[dict]:
    cov = project.data.get("Covariance", {}).get("data", {})
    matrix = cov.get("covMatrix")
    vary = cov.get("varyList", [])
    if matrix is None:
        return []
    matrix = np.asarray(matrix)
    diag = np.sqrt(np.maximum(np.diag(matrix), 0))
    found = []
    for i in range(len(vary)):
        for j in range(i):
            den = diag[i] * diag[j]
            if not den:
                continue
            value = float(matrix[i, j] / den)
            if abs(value) >= cutoff:
                found.append({"left": vary[j], "right": vary[i], "correlation": value})
    return sorted(found, key=lambda item: abs(item["correlation"]), reverse=True)


def summarize(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    cov = project.data.get("Covariance", {}).get("data", {})
    frozen = project.data["Controls"]["data"].get("parmFrozen", {})
    summary = {
        "label": label,
        "gpx": project.filename,
        "Rwp_percent": hist.get_wR(),
        "Rp_percent": hist.data["data"][0].get("R"),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "profile": {key: inst[key][1] for key in ["Zero", "U", "V", "W", "X", "Y", "SH/L"]},
        "frozen": {key: [str(v) for v in value] for key, value in frozen.items()},
        "correlations_abs_ge_0.8": correlations(project),
        "phases": [],
    }
    try:
        summary["mass_fractions"] = {
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        summary["mass_fractions"] = {"error": repr(exc)}
    for phase in project.phases():
        summary["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
            }
        )
    print(json.dumps(summary, sort_keys=True))
    return summary


def clean_project(
    path: Path | None = None,
    wo3_source: Path | None = None,
) -> G2sc.G2Project:
    path = path or HERE / "clean_final_base.gpx"
    wo3_source = wo3_source or HERE / "candidates" / "wo3_2311041_conventional.cif"
    project = G2sc.G2Project(newgpx=str(path))
    hist = project.add_powder_histogram(
        str(HERE / "pattern.xye"), str(HERE / "cu_kalpha.instprm"), fmthint="xye"
    )
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    for key in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]:
        if key in sample:
            sample[key] = [0.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {
        "Zero": -0.610,
        "U": 0.0,
        "V": 0.0,
        "W": 35.0,
        "X": 0.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }.items():
        set_inst(inst, key, value)
    x = hist.data["data"][1][0]
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 10,
                "coeffs": [1100.0] + [0.0] * 9,
            },
        }
    )
    specs = [
        ("SrWO4", HERE / "candidates" / "srwo4_from_cawo4_7219229.cif"),
        ("WO3", wo3_source),
        ("SrCO3", cod("9008198")),
    ]
    for name, source in specs:
        phase = project.add_phase(
            str(source), phasename=name, histograms=[hist], fmthint="CIF"
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [0.3, True]
        hap["Pref.Ori."] = ["MD", 1.0, False, [0, 0, 1], 0, {}, [], 0.1]
        hap["Size"] = [
            "isotropic",
            [10.0, 10.0, 1.0],
            [False, False, False],
            [0, 0, 1],
            [1.0, 1.0, 1.0, 0.0, 0.0, 0.0],
            [False] * 6,
        ]
        hap["Mustrain"] = [
            "isotropic",
            [0.0, 0.0, 1.0],
            [False, False, False],
            [0, 0, 1],
            [0.01, 0.01, 0.01, 0.01],
            [False] * 4,
        ]
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"] = [0.0, False]
        hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 10
    controls["min dM/M"] = 1e-5
    bounds(project)
    project.save()
    return project


def clone(source: Path, target: Path) -> G2sc.G2Project:
    return G2sc.G2Project(str(source), newgpx=str(target))


def main() -> None:
    results = []
    project = clean_project()
    project = replay(project, 2)  # background + all scales
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.histogram(0).set_refinements({"Instrument Parameters": ["Zero"]})
    project = replay(project, 2)  # cell + the sole angular correction
    results.append(summarize(project, "clean_cells"))

    # W-only common profile from a neutral instrument profile.
    project.histogram(0).set_refinements({"Instrument Parameters": ["W"]})
    project = replay(project, 2)
    project.save(HERE / "profile_w_only.gpx")
    results.append(summarize(project, "W_only"))

    # Add nonnegative Lorentzian X; this is the accepted low-dimensional branch
    # only if it remains interior and survives a fresh replay.
    hist = project.histogram(0)
    set_inst(hist.data["Instrument Parameters"][0], "X", 1.0)
    hist.set_refinements({"Instrument Parameters": ["X"]})
    project = replay(project, 2)
    project.save(HERE / "profile_wx.gpx")
    results.append(summarize(project, "W_plus_X"))

    # Explicitly challenge U from a small positive value. A bound hit rejects it.
    branch = clone(HERE / "profile_wx.gpx", HERE / "profile_wxu_test.gpx")
    set_inst(branch.histogram(0).data["Instrument Parameters"][0], "U", 1.0)
    branch.histogram(0).set_refinements({"Instrument Parameters": ["U"]})
    branch = replay(branch, 2)
    results.append(summarize(branch, "W_plus_X_plus_U_test"))

    # Test bounded axial-divergence asymmetry early.
    branch = clone(HERE / "profile_wx.gpx", HERE / "profile_wx_shl_test.gpx")
    set_inst(branch.histogram(0).data["Instrument Parameters"][0], "SH/L", 0.02)
    branch.histogram(0).set_refinements({"Instrument Parameters": ["SH/L"]})
    branch = replay(branch, 2)
    results.append(summarize(branch, "W_plus_X_plus_SHL_test"))

    (HERE / "final_profile_summary.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
