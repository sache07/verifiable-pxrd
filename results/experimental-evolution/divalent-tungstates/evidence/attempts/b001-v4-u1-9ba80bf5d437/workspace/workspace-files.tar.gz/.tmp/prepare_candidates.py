from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path(
    "<RUN>/resources/"
    "b001-c03/cif"
)
OUT = Path(__file__).resolve().parent / "candidates"
OUT.mkdir(parents=True, exist_ok=True)


def source_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def read(cod_id: str) -> Structure:
    return CifParser(str(source_path(cod_id)), occupancy_tolerance=10).parse_structures(
        primitive=False
    )[0]


def adapted(
    cod_id: str,
    substitutions: dict[str, str],
    output_name: str,
    cell: tuple[float, float] | None = None,
) -> None:
    structure = read(cod_id)
    structure.replace_species(substitutions)
    if cell:
        structure = Structure(
            Lattice.tetragonal(*cell),
            structure.species,
            structure.frac_coords,
            site_properties=structure.site_properties,
        )
    CifWriter(structure, symprec=1e-3).write_file(OUT / output_name)


# All three ambient-pressure scheelite parents are screened with the same
# initial SrWO4 cell. EuWO4 is the closest cell/geometry parent, CaWO4 retains
# the exact W chemistry, and SrMoO4 retains the exact Sr sublattice.
initial_scheelite_cell = (5.4145, 11.9494)
adapted(
    "1561850",
    {"Eu": "Sr"},
    "srwo4_from_euwo4_1561850.cif",
    initial_scheelite_cell,
)
adapted(
    "7219229",
    {"Ca": "Sr"},
    "srwo4_from_cawo4_7219229.cif",
    initial_scheelite_cell,
)
adapted(
    "2300460",
    {"Mo": "W"},
    "srwo4_from_srmoo4_2300460.cif",
    initial_scheelite_cell,
)

# Pressure-stabilized fergusonite is an intentionally adverse polymorph test.
adapted(
    "1546035",
    {"Ca": "Sr"},
    "srwo4_fergusonite_from_cawo4_1546035.cif",
)

print("\n".join(str(path) for path in sorted(OUT.glob("*.cif"))))
