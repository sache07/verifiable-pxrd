from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIobj as G2obj

from final_profile import HERE, replay, summarize


BASE = HERE / "profile_wx.gpx"


def add_bound(project, name: str, lo: float, hi: float) -> None:
    controls = project.data["Controls"]["data"]
    controls.setdefault("parmMinDict", {})[G2obj.G2VarObj(name)] = lo
    controls.setdefault("parmMaxDict", {})[G2obj.G2VarObj(name)] = hi


def detail(project, phase_id: int) -> dict:
    hist = project.histogram(0)
    phase = project.phase(phase_id)
    cov = project.data.get("Covariance", {}).get("data", {})
    values = dict(zip(cov.get("varyList", []), cov.get("variables", [])))
    sigmas = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    hap = phase.data["Histograms"][hist.name]
    return {
        "phase": phase.name,
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "refined_values": {
            key: {"value": float(value), "sigma": float(sigmas.get(key, 0.0))}
            for key, value in values.items()
            if key.startswith(f"{phase_id}:0:Size")
            or key.startswith(f"{phase_id}:0:Mustrain")
        },
    }


def branch(phase_id: int, kind: str):
    target = HERE / f"broadening_{phase_id}_{kind}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(target))
    phase = project.phase(phase_id)
    hist = project.histogram(0)
    if kind == "size":
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": 1.0,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            },
            [hist],
        )
        add_bound(project, f"{phase_id}:0:Size;i", 0.01, 100.0)
    elif kind == "strain":
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 100.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2] = [True, False, False]
        add_bound(project, f"{phase_id}:0:Mustrain;i", 0.0, 10000.0)
    else:
        raise ValueError(kind)
    project = replay(project, 2)
    summary = summarize(project, f"{phase.name}_{kind}_only")
    summary["broadening_detail"] = detail(project, phase_id)
    return summary


def main() -> None:
    results = []
    for phase_id in range(3):
        for kind in ["size", "strain"]:
            results.append(branch(phase_id, kind))
    (HERE / "broadening_summary.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
