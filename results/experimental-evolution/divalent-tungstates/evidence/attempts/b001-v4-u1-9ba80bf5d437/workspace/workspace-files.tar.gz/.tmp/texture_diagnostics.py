from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
base = G2sc.G2Project(str(HERE / "texture_combined.gpx"))
textured = G2sc.G2Project(str(HERE / "texture_combined_carbonate_001.gpx"))


def arrays(project):
    return project.histogram(0).data["data"][1]


x0, y0, w0, yc0, bg0, r0 = arrays(base)
x1, y1, w1, yc1, bg1, r1 = arrays(textured)
assert np.allclose(x0, x1) and np.allclose(y0, y1) and np.allclose(w0, w1)

refs = textured.histogram(0).data["Reflection Lists"]["SrCO3"]["RefList"]
# Group nearby carbonate reflections into non-overlapping 0.36-degree windows.
groups = []
for ref in refs:
    pos = float(ref[5])
    if pos < x0[0] or pos > x0[-1]:
        continue
    if groups and pos - groups[-1][-1][5] < 0.36:
        groups[-1].append(ref)
    else:
        groups.append([ref])

rows = []
for group in groups:
    lo = float(group[0][5]) - 0.18
    hi = float(group[-1][5]) + 0.18
    sel = (x0 >= lo) & (x0 <= hi)
    chi0 = float(np.sum(w0[sel] * r0[sel] ** 2))
    chi1 = float(np.sum(w1[sel] * r1[sel] ** 2))
    max_fcalc = max(float(ref[9]) for ref in group)
    max_po_delta = max(abs(float(ref[12]) - 1.0) for ref in group)
    hkls = "+".join("%d%d%d" % tuple(int(v) for v in ref[:3]) for ref in group)
    rows.append((chi0 - chi1, lo, hi, hkls, max_fcalc, max_po_delta, chi0, chi1))

print("total_chi2_base", float(np.sum(w0 * r0**2)))
print("total_chi2_texture", float(np.sum(w1 * r1**2)))
print("delta_chi2", float(np.sum(w0 * r0**2) - np.sum(w1 * r1**2)))
print("best carbonate reflection-family windows")
print("delta_chi2 range_deg hkls max_Fcalc max_abs_PO_minus_1 chi2_before chi2_after")
for row in sorted(rows, reverse=True)[:15]:
    print(
        f"{row[0]:10.3f} {row[1]:7.3f}-{row[2]:7.3f} {row[3]:18s} "
        f"{row[4]:10.1f} {row[5]:9.3f} {row[6]:10.3f} {row[7]:10.3f}"
    )
