import json

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIobj as G2obj

from final_profile import HERE, clean_project, replay, set_inst, summarize


project = clean_project(
    HERE / "clean_conventional.gpx",
    HERE / "candidates" / "wo3_2311041_conventional.cif",
)
project = replay(project, 2)
for phase in project.phases():
    phase.set_refinements({"Cell": True})
hist = project.histogram(0)
hist.set_refinements({"Instrument Parameters": ["Zero"]})
project = replay(project, 2)

hist = project.histogram(0)
hist.set_refinements({"Instrument Parameters": ["W"]})
project = replay(project, 2)
hist = project.histogram(0)
set_inst(hist.data["Instrument Parameters"][0], "X", 1.0)
hist.set_refinements({"Instrument Parameters": ["X"]})
project = replay(project, 2)

# The only supported phase broadening branch: isotropic WO3 size.
phase = project.phase(1)
phase.set_HAP_refinements(
    {
        "Size": {
            "type": "isotropic",
            "value": 1.0,
            "refine": True,
            "LGmix": {"value": 1.0, "refine": False},
        }
    },
    [project.histogram(0)],
)
controls = project.data["Controls"]["data"]
controls.setdefault("parmMinDict", {})[G2obj.G2VarObj("1:0:Size;i")] = 0.01
controls.setdefault("parmMaxDict", {})[G2obj.G2VarObj("1:0:Size;i")] = 100.0
project = replay(project, 2)
project.save(HERE / "intensity_base.gpx")
summary = summarize(project, "conventional_WO3_with_size")
(HERE / "intensity_base_summary.json").write_text(json.dumps(summary, indent=2))
