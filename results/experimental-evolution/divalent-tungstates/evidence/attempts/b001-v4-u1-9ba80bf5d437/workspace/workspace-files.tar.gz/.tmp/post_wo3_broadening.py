import json

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIobj as G2obj

from final_profile import HERE, replay, summarize


def add_bound(project, name, lo, hi):
    controls = project.data["Controls"]["data"]
    controls.setdefault("parmMinDict", {})[G2obj.G2VarObj(name)] = lo
    controls.setdefault("parmMaxDict", {})[G2obj.G2VarObj(name)] = hi


def run(kind):
    project = G2sc.G2Project(
        str(HERE / "intensity_base.gpx"),
        newgpx=str(HERE / f"post_wo3_srco3_{kind}.gpx"),
    )
    phase = project.phase(2)
    hist = project.histogram(0)
    hap = phase.data["Histograms"][hist.name]
    if kind == "size":
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": 1.0,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            },
            [hist],
        )
        add_bound(project, "2:0:Size;i", 0.01, 100.0)
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 100.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2] = [True, False, False]
        add_bound(project, "2:0:Mustrain;i", 0.0, 10000.0)
    project = replay(project, 2)
    result = summarize(project, f"post_WO3_SrCO3_{kind}")
    result["size"] = hap["Size"]
    result["mustrain"] = hap["Mustrain"]
    cov = project.data["Covariance"]["data"]
    result["broadening_variables"] = {
        key: {"value": float(value), "sigma": float(sigma)}
        for key, value, sigma in zip(cov["varyList"], cov["variables"], cov["sig"])
        if key.startswith("2:0:Size") or key.startswith("2:0:Mustrain")
    }
    return result


results = [run("size"), run("strain")]
(HERE / "post_wo3_broadening_summary.json").write_text(json.dumps(results, indent=2))
