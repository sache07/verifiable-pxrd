from pathlib import Path
import sys

import numpy as np
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2sc


gpx = Path(sys.argv[1])
out = Path(sys.argv[2])
project = G2sc.G2Project(str(gpx))
hist = project.histogram(0)
x, yobs, weight, ycalc, bkg, resid = hist.data["data"][1]
np.savetxt(
    out,
    np.column_stack([x, yobs, ycalc, bkg, resid, weight]),
    delimiter=",",
    header="two_theta_deg,observed,calculated,background,difference,weight",
    comments="",
)

score = np.abs(resid) * np.sqrt(weight)
peaks, props = find_peaks(score, prominence=0.5, distance=4)
order = np.argsort(score[peaks])[::-1]
print("Rwp", hist.get_wR())
print("rank 2theta yobs ycalc residual weighted")
for rank, j in enumerate(order[:100], 1):
    i = peaks[j]
    print(rank, f"{x[i]:.5f}", f"{yobs[i]:.1f}", f"{ycalc[i]:.1f}", f"{resid[i]:+.1f}", f"{resid[i]*np.sqrt(weight[i]):+.3f}")
