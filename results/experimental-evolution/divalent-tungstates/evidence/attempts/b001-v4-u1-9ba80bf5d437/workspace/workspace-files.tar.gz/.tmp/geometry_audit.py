import json
from pathlib import Path

from pymatgen.core import Structure


WORK = Path(__file__).resolve().parent.parent


def element(site):
    return next(iter(site.species)).symbol


def bond_summary(structure, center, neighbor, cutoff):
    per_site = []
    for index, site in enumerate(structure):
        if element(site) != center:
            continue
        distances = sorted(
            float(item.nn_distance)
            for item in structure.get_neighbors(site, cutoff)
            if element(item) == neighbor
        )
        per_site.append({"site_index": index, "count": len(distances), "distances_A": distances})
    flat = [distance for item in per_site for distance in item["distances_A"]]
    return {
        "center": center,
        "neighbor": neighbor,
        "cutoff_A": cutoff,
        "coordination_counts": sorted({item["count"] for item in per_site}),
        "minimum_A": min(flat),
        "maximum_A": max(flat),
        "per_site": per_site,
    }


specs = {
    "SrWO4": (WORK / "SrWO4.cif", [("W", "O", 2.3), ("Sr", "O", 3.0)]),
    "WO3": (WORK / "WO3.cif", [("W", "O", 2.4)]),
    "SrCO3": (WORK / "SrCO3.cif", [("C", "O", 1.6), ("Sr", "O", 3.2)]),
    "SrWO4_unrestrained_O_test": (
        WORK / ".tmp" / "SrWO4_oxygen_unrestrained.cif",
        [("W", "O", 2.5), ("Sr", "O", 3.0)],
    ),
}

audit = {}
for name, (path, pairs) in specs.items():
    structure = Structure.from_file(path)
    audit[name] = {
        "path": str(path),
        "reduced_formula": structure.composition.reduced_formula,
        "composition": {str(key): float(value) for key, value in structure.composition.items()},
        "all_sites_fully_occupied": all(abs(site.species.num_atoms - 1.0) < 1e-8 for site in structure),
        "lattice": {
            "a": structure.lattice.a,
            "b": structure.lattice.b,
            "c": structure.lattice.c,
            "alpha": structure.lattice.alpha,
            "beta": structure.lattice.beta,
            "gamma": structure.lattice.gamma,
            "volume": structure.volume,
        },
        "bonds": [bond_summary(structure, *pair) for pair in pairs],
    }

out = WORK / ".tmp" / "geometry_audit.json"
out.write_text(json.dumps(audit, indent=2) + "\n")
print(json.dumps(audit, sort_keys=True))
