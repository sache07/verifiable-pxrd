import json

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIobj as G2obj

from final_profile import HERE, replay, summarize


project = G2sc.G2Project(
    str(HERE / "post_wo3_srco3_size.gpx"),
    newgpx=str(HERE / "broadening_srco3_size_strain.gpx"),
)
hist = project.histogram(0)
hap = project.phase(2).data["Histograms"][hist.name]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][0] = 100.0
hap["Mustrain"][1][2] = 1.0
hap["Mustrain"][2] = [True, False, False]
controls = project.data["Controls"]["data"]
controls.setdefault("parmMinDict", {})[G2obj.G2VarObj("2:0:Mustrain;i")] = 0.0
controls.setdefault("parmMaxDict", {})[G2obj.G2VarObj("2:0:Mustrain;i")] = 10000.0
project = replay(project, 2)
result = summarize(project, "SrCO3_size_plus_strain")
cov = project.data["Covariance"]["data"]
result["broadening_variables"] = {
    key: {"value": float(value), "sigma": float(sigma)}
    for key, value, sigma in zip(cov["varyList"], cov["variables"], cov["sig"])
    if key.startswith("2:0:Size") or key.startswith("2:0:Mustrain")
}
(HERE / "srco3_combined_summary.json").write_text(json.dumps(result, indent=2))
