import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "positions_final.gpx"))
gpx.save(str(ROOT / ".tmp" / "cells_shift_joint.gpx"))
gpx.set_Controls("cycles", 60)

hist = gpx.histogram(0)
hist.SampleParameters["Shift"][1] = True
for phase in gpx.phases():
    phase.data["General"]["Cell"][0] = True

gpx.refine()
gpx.save()

print(json.dumps({
    "residuals": hist.residuals,
    "shift_um": hist.SampleParameters["Shift"],
    "cells": {phase.name: phase.get_cell() for phase in gpx.phases()},
    "fractions": hist.ComputeMassFracs(),
}, indent=2, default=str))
