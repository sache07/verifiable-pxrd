import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
MODE = sys.argv[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "textures_refined.gpx"))
gpx.save(str(ROOT / ".tmp" / f"atoms_{MODE}.gpx"))
gpx.set_Controls("cycles", 40)
h = gpx.histogram(0)
sr = gpx.phase("SrWO4")
wo = gpx.phase("WO3_Pnma")
if MODE == "srO":
    sr.set_refinements({"Atoms": {"O1": "X"}})
elif MODE == "woW":
    wo.set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
elif MODE == "woO":
    wo.set_refinements({"Atoms": {a.label: "X" for a in wo.atoms() if a.element == "O"}})
elif MODE == "woWU":
    wo.set_refinements({"Atoms": {a.label: "U" for a in wo.atoms() if a.element == "W"}})
elif MODE == "woOU":
    for a in wo.atoms():
        if a.element == "O":
            a.uiso = 0.01
    wo.set_refinements({"Atoms": {a.label: "U" for a in wo.atoms() if a.element == "O"}})
elif MODE == "srU":
    sr.set_refinements({"Atoms": {a.label: "U" for a in sr.atoms()}})
elif MODE == "allpos":
    sr.set_refinements({"Atoms": {"O1": "X"}})
    wo.set_refinements({"Atoms": {a.label: "X" for a in wo.atoms()}})
else:
    raise ValueError(MODE)
gpx.refine()
print(json.dumps({
    "mode": MODE, "residuals": h.residuals,
    "mass_fractions": h.ComputeMassFracs(),
    "atoms": {
        p.name: {a.label: {"element": a.element, "xyz": a.coordinates, "uiso": a.uiso}
                 for a in p.atoms()}
        for p in (sr, wo)
    },
}), flush=True)
