import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "pnma_profile.gpx"))
gpx.save(str(ROOT / ".tmp" / "pnma_sr_po.gpx"))
gpx.set_Controls("cycles", 10)
h = gpx.histogram(0)
sr = gpx.phase("SrWO4")
sr.set_HAP_refinements({"Pref.Ori.": True})
gpx.set_Controls("parmMin", 0.2, "0:0:MD")
gpx.set_Controls("parmMax", 5.0, "0:0:MD")
gpx.refine()
print(json.dumps({
    "residuals": h.residuals,
    "sr_preferred_orientation": sr.getHAPvalues(h)["Pref.Ori."],
    "mass_fractions": h.ComputeMassFracs(),
    "instrument": {k: h.InstrumentParameters[k][1] for k in ("U", "V", "W", "X", "Y", "SH/L")},
}), flush=True)
