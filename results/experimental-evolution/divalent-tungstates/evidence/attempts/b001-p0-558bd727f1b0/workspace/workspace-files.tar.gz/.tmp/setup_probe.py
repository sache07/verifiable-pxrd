from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
gpx = G2sc.G2Project(newgpx=str(ROOT / ".tmp" / "probe.gpx"))
h = gpx.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / ".tmp" / "pixcel_cuka.instprm"),
    fmthint="comma/tab/semicolon separated",
)
p1 = gpx.add_phase(
    str(ROOT / ".tmp" / "srwo4_start.cif"),
    phasename="SrWO4",
    histograms=[h],
    fmthint="CIF",
)
p2 = gpx.add_phase(
    "<RUN>/resources/b001-c03/cif/2/10/73/2107312.cif",
    phasename="WO3_orthorhombic",
    histograms=[h],
    fmthint="CIF",
)
print("hist", h.name)
print("sample", h.SampleParameters)
print("instrument", h.InstrumentParameters)
print("background", h.Background)
for p in (p1, p2):
    print("phase", p.name, p.get_cell())
    print("HAP", p.data["Histograms"][h.name])
    print("general", p.data["General"])
gpx.save()
