import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
with (ROOT / "result.json").open() as stream:
    result = json.load(stream)

gpx = G2sc.G2Project(str(ROOT / "final.gpx"))
hist = gpx.histogram(0)
fractions = hist.ComputeMassFracs()
assert [phase.name for phase in gpx.phases()] == [
    "SrWO4", "WO3_Pnma", "SrCO3_Pnma"
]
assert abs(sum(value[0] for value in fractions.values()) - 1.0) < 1e-12
for record in result["phases"]:
    assert (ROOT / record["cif"]).is_file()
    assert abs(record["weight_fraction"] - fractions[record["name"]][0]) < 1e-12

with (ROOT / "fit.csv").open() as stream:
    rows = list(csv.DictReader(stream))
assert len(rows) == gpx.data["Covariance"]["data"]["Rvals"]["Nobs"]
x = hist.getdata("X")
observed_project = hist.getdata("Yobs")
calculated_project = hist.getdata("Ycalc")
difference_project = hist.getdata("Residual")
indices = [index for index, value in enumerate(calculated_project) if value != 0]
assert len(rows) == len(indices)
for row, index in zip(rows, indices):
    observed = float(row["observed_counts"])
    calculated = float(row["calculated_counts"])
    difference = float(row["difference_counts"])
    assert abs((observed - calculated) - difference) < 2e-5
    assert abs(float(row["two_theta_deg"]) - x[index]) < 1e-7
    assert abs(observed - observed_project[index]) < 1e-7
    assert abs(calculated - calculated_project[index]) < 2e-5
    assert abs(difference - difference_project[index]) < 2e-5

# Round-trip each exported structure through the GSAS-II CIF importer.
check = G2sc.G2Project(newgpx=str(ROOT / ".tmp" / "cif_roundtrip.gpx"))
for record in result["phases"]:
    check.add_phase(
        str(ROOT / record["cif"]),
        phasename=record["name"],
        fmthint="CIF",
    )
assert len(check.phases()) == 3

print(json.dumps({
    "project_opens": True,
    "phases": list(fractions),
    "fraction_sum": sum(value[0] for value in fractions.values()),
    "profile_rows": len(rows),
    "Rwp_percent": hist.residuals["wR"],
    "cif_roundtrip": True,
}, indent=2))
