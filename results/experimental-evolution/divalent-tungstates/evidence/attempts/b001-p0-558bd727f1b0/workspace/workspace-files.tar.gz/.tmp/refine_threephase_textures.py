import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "carbonate_po_001.gpx"))
gpx.save(str(ROOT / ".tmp" / "threephase_textures.gpx"))
gpx.set_Controls("cycles", 50)
hist = gpx.histogram(0)

axes = {
    "SrWO4": [1, 1, 0],
    "WO3_Pnma": [0, 0, 1],
    "SrCO3_Pnma": [0, 0, 1],
}
for index, (name, axis) in enumerate(axes.items()):
    phase = gpx.phase(name)
    phase.data["General"]["Cell"][0] = False
    phase.getHAPvalues(hist)["Pref.Ori."][3] = axis
    phase.set_HAP_refinements({"Pref.Ori.": True})
    gpx.set_Controls("parmMin", 0.2, f"{index}:0:MD")
    gpx.set_Controls("parmMax", 5.0, f"{index}:0:MD")

for cycle in range(1, 4):
    gpx.refine()
    gpx.save()
    print(json.dumps({
        "cycle": cycle,
        "Rwp": hist.residuals.get("wR"),
        "textures": {
            name: gpx.phase(name).getHAPvalues(hist)["Pref.Ori."][1]
            for name in axes
        },
        "fractions": hist.ComputeMassFracs(),
    }), flush=True)
