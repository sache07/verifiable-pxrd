import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "wo_po_001.gpx"))
gpx.save(str(ROOT / ".tmp" / "texture_final.gpx"))
gpx.set_Controls("cycles", 40)
h = gpx.histogram(0)
wo = gpx.phase("WO3_Pnma")
for cycle in range(1, 5):
    gpx.refine()
    print(json.dumps({
        "cycle": cycle, "residuals": h.residuals,
        "preferred_orientation": wo.getHAPvalues(h)["Pref.Ori."],
        "mass_fractions": h.ComputeMassFracs(),
    }), flush=True)
