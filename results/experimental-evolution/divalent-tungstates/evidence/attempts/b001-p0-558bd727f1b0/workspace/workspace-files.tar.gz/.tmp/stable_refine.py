import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / ".tmp" / "stable_base.gpx"
WO3 = Path("<RUN>/resources/b001-c03/cif/2/10/73/2107312.cif")

G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(newgpx=str(OUT), author="OpenAI Codex")
h = gpx.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / ".tmp" / "pixcel_cuka.instprm"),
    fmthint="comma/tab/semicolon separated",
)
sr = gpx.add_phase(
    str(ROOT / ".tmp" / "srwo4_start.cif"), phasename="SrWO4",
    histograms=[h], fmthint="CIF",
)
wo = gpx.add_phase(
    str(WO3), phasename="WO3_Pnma", histograms=[h], fmthint="CIF",
)
gpx.set_Controls("cycles", 10)
gpx.data["Controls"]["data"]["min dM/M"] = 1e-5
for variable in (":0:U", ":0:W", ":0:X", ":0:Y", ":0:SH/L"):
    gpx.set_Controls("parmMin", 0.0, variable)

h.set_refinements({
    "Limits": [10.0, 100.0],
    "Background": {
        "type": "chebyschev-1", "refine": False, "no. coeffs": 8,
        "coeffs": [1100.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
    },
})
h.SampleParameters["Shift"] = [800.0, False]
for key, value in {"U": 10.0, "V": 0.0, "W": 50.0, "X": 2.0, "Y": 0.0, "SH/L": 0.01}.items():
    h.InstrumentParameters[key][1] = value

sr.HAPvalue("Scale", 1.0)
wo.HAPvalue("Scale", 0.15)

def all_off():
    h.Background[0][1] = False
    for key, value in h.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for phase in (sr, wo):
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.getHAPvalues(h)
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]

def run(label, background=False, hist_scale=False, wo_scale=False,
        shift=False, sr_cell=False, wo_cell=False, inst=()):
    all_off()
    h.Background[0][1] = background
    h.SampleParameters["Scale"][1] = hist_scale
    h.SampleParameters["Shift"][1] = shift
    wo.getHAPvalues(h)["Scale"][1] = wo_scale
    sr.data["General"]["Cell"][0] = sr_cell
    wo.data["General"]["Cell"][0] = wo_cell
    for key in inst:
        h.InstrumentParameters[key][2] = True
    gpx.refine()
    print(json.dumps({
        "stage": label,
        "Rwp": h.residuals.get("wR"),
        "GOF": h.residuals.get("wR", 0.0) / h.residuals.get("wRmin", 1.0),
        "shift": h.SampleParameters["Shift"][0],
        "cells": {p.name: p.get_cell() for p in (sr, wo)},
        "scales": {"hist": h.SampleParameters["Scale"][0], "wo": wo.HAPvalue("Scale")},
        "profile": {k: h.InstrumentParameters[k][1] for k in ("U", "V", "W", "X", "Y", "SH/L")},
    }), flush=True)

run("background_scales_1", background=True, hist_scale=True, wo_scale=True)
run("shift_1", hist_scale=True, wo_scale=True, shift=True)
run("cells_1", sr_cell=True, wo_cell=True)
run("shift_2", shift=True)
run("cells_2", sr_cell=True, wo_cell=True)
run("background_scales_2", background=True, hist_scale=True, wo_scale=True)
run("profile_W", hist_scale=True, wo_scale=True, inst=("W",))
run("profile_U", hist_scale=True, wo_scale=True, inst=("U",))
run("profile_X", hist_scale=True, wo_scale=True, inst=("X",))
run("profile_SHL", hist_scale=True, wo_scale=True, inst=("SH/L",))
run("shift_3", shift=True)
run("cells_3", sr_cell=True, wo_cell=True)
run("background_scales_3", background=True, hist_scale=True, wo_scale=True)
run("profile_W_final", inst=("W",))
run("profile_U_final", inst=("U",))

all_off()
gpx.save()
print(json.dumps({
    "final": True,
    "residuals": h.residuals,
    "mass_fractions": h.ComputeMassFracs(),
    "sample": {k: h.SampleParameters[k] for k in ("Scale", "Shift")},
    "instrument": {k: h.InstrumentParameters[k] for k in ("U", "V", "W", "X", "Y", "SH/L")},
    "cells": {p.name: p.get_cell() for p in (sr, wo)},
}), flush=True)
