import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "simultaneous_converged.gpx"))
gpx.save(str(ROOT / ".tmp" / "positions_final.gpx"))
gpx.set_Controls("cycles", 40)
h = gpx.histogram(0)
sr = gpx.phase("SrWO4")
wo = gpx.phase("WO3_Pnma")

h.Background[0][1] = False
for val in h.InstrumentParameters.values():
    if isinstance(val, list) and len(val) > 2:
        val[2] = False
for phase in (sr, wo):
    phase.getHAPvalues(h)["Pref.Ori."][2] = False
    phase.getHAPvalues(h)["Mustrain"][2] = [False, False, False]
h.SampleParameters["Scale"][1] = True
wo.getHAPvalues(h)["Scale"][1] = True

def report(label):
    print(json.dumps({
        "stage": label, "Rwp": h.residuals.get("wR"),
        "shift": h.SampleParameters["Shift"][0],
        "cells": {p.name: p.get_cell() for p in (sr, wo)},
        "mass_fractions": h.ComputeMassFracs(),
    }), flush=True)

for cycle in range(1, 4):
    h.SampleParameters["Shift"][1] = False
    sr.data["General"]["Cell"][0] = True
    wo.data["General"]["Cell"][0] = True
    gpx.refine()
    report(f"cells_{cycle}")
    sr.data["General"]["Cell"][0] = False
    wo.data["General"]["Cell"][0] = False
    h.SampleParameters["Shift"][1] = True
    gpx.refine()
    report(f"shift_{cycle}")
h.SampleParameters["Shift"][1] = False
gpx.save()
