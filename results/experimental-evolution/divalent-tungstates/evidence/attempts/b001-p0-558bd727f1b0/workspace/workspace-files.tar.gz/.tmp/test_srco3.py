import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
CIF = Path(
    "<RUN>/resources/"
    "b001-c03/cif/9/00/81/9008198.cif"
)

G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "positions_final.gpx"))
gpx.save(str(ROOT / ".tmp" / "srco3_test.gpx"))
hist = gpx.histogram(0)
phase = gpx.add_phase(
    str(CIF), phasename="SrCO3_Pnma", histograms=[hist], fmthint="CIF"
)
phase.HAPvalue("Scale", 0.02)
phase.set_HAP_refinements({"Scale": True})
gpx.set_Controls("cycles", 30)
gpx.refine()
gpx.save()

print(json.dumps({
    "residuals": hist.residuals,
    "phase_scale": phase.HAPvalue("Scale"),
    "fractions": hist.ComputeMassFracs(),
}, indent=2, default=str))
