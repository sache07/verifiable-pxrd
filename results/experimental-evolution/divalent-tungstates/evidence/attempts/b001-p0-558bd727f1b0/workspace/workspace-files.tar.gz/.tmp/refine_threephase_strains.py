import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "threephase_textures.gpx"))
gpx.save(str(ROOT / ".tmp" / "threephase_strains.gpx"))
gpx.set_Controls("cycles", 50)
hist = gpx.histogram(0)
for name in ("SrWO4", "WO3_Pnma"):
    gpx.phase(name).set_HAP_refinements({
        "Mustrain": {"type": "isotropic", "refine": True}
    })

for cycle in range(1, 4):
    gpx.refine()
    gpx.save()
    print(json.dumps({
        "cycle": cycle,
        "Rwp": hist.residuals.get("wR"),
        "strain": {
            name: gpx.phase(name).getHAPvalues(hist)["Mustrain"][1][0]
            for name in ("SrWO4", "WO3_Pnma")
        },
        "fractions": hist.ComputeMassFracs(),
    }), flush=True)
