import sys
from pathlib import Path

import matplotlib.pyplot as plt
from GSASII import GSASIIscriptable as G2sc


gpx = G2sc.G2Project(sys.argv[1])
hist = gpx.histogram(0)
x = hist.getdata("X")
obs = hist.getdata("Yobs")
calc = hist.getdata("Ycalc")
diff = hist.getdata("Residual")
limits = hist.data["Limits"][1]
use = (x >= limits[0]) & (x <= limits[1])

fig, axes = plt.subplots(3, 1, figsize=(15, 10), constrained_layout=True)
for ax, lo, hi in zip(axes, (10, 40, 70), (40, 70, 100)):
    sel = use & (x >= lo) & (x <= hi)
    ax.plot(x[sel], obs[sel], color="black", lw=0.75, label="observed")
    ax.plot(x[sel], calc[sel], color="red", lw=0.8, label="calculated")
    ax.plot(x[sel], diff[sel], color="blue", lw=0.65, label="difference")
    ax.axhline(0, color="0.6", lw=0.5)
    ax.set_xlim(lo, hi)
    ax.set_ylabel("counts")
axes[0].legend(loc="upper right", ncol=3)
axes[-1].set_xlabel(r"$2\theta$ (degrees)")
fig.savefig(sys.argv[2], dpi=160)
