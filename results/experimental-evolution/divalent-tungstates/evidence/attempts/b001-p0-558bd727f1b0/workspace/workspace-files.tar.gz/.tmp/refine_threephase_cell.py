import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "srco3_test.gpx"))
gpx.save(str(ROOT / ".tmp" / "threephase_cell.gpx"))
gpx.set_Controls("cycles", 40)
hist = gpx.histogram(0)
carbonate = gpx.phase("SrCO3_Pnma")
carbonate.data["General"]["Cell"][0] = True

for cycle in range(1, 4):
    gpx.refine()
    gpx.save()
    print(json.dumps({
        "cycle": cycle,
        "Rwp": hist.residuals.get("wR"),
        "cell": carbonate.get_cell(),
        "fractions": hist.ComputeMassFracs(),
    }), flush=True)
