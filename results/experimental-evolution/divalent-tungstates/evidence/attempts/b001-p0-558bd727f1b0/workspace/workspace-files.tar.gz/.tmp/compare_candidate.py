import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
CID = sys.argv[1]
LABEL = sys.argv[2] if len(sys.argv) > 2 else CID
if CID.lower() != "none":
    CIF_ROOT = Path("<RUN>/resources/b001-c03/cif")
    CANDIDATE = CIF_ROOT / CID[0] / CID[1:3] / CID[3:5] / f"{CID}.cif"

G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(newgpx=str(ROOT / ".tmp" / f"cmp_{CID}.gpx"), author="OpenAI Codex")
h = gpx.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / ".tmp" / "pixcel_cuka.instprm"),
    fmthint="comma/tab/semicolon separated",
)
sr = gpx.add_phase(
    str(ROOT / ".tmp" / "srwo4_start.cif"), phasename="SrWO4",
    histograms=[h], fmthint="CIF"
)
candidate = None
if CID.lower() != "none":
    candidate = gpx.add_phase(
        str(CANDIDATE), phasename=LABEL, histograms=[h], fmthint="CIF"
    )

gpx.set_Controls("cycles", 12)
h.set_refinements({
    "Limits": [10.0, 100.0],
    "Background": {
        "type": "chebyschev-1", "refine": True, "no. coeffs": 8,
        "coeffs": [1100.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
    },
    "Instrument Parameters": ["U", "V", "W"],
})
h.SampleParameters["Shift"] = [800.0, True]
for key, value in {"U": 20.0, "V": -10.0, "W": 50.0, "X": 2.0, "Y": 0.0}.items():
    h.InstrumentParameters[key][1] = value

sr.HAPvalue("Scale", 1.0)
sr.set_refinements({"Cell": True})
if candidate:
    candidate.HAPvalue("Scale", 0.15)
    candidate.set_HAP_refinements({"Scale": True})
    candidate.set_refinements({"Cell": True})

gpx.refine()
out = {
    "candidate_id": CID,
    "candidate_label": LABEL,
    "residuals": h.residuals,
    "shift": h.SampleParameters["Shift"][0],
    "instrument": {k: h.InstrumentParameters[k][1] for k in ("U", "V", "W")},
    "cells": {p.name: p.get_cell() for p in gpx.phases()},
    "phase_scales": {p.name: p.HAPvalue("Scale") for p in gpx.phases()},
}
try:
    out["mass_fractions"] = h.ComputeMassFracs()
except Exception as exc:
    out["mass_fraction_error"] = repr(exc)
print(json.dumps(out), flush=True)
