import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
INFILE = ROOT / ".tmp" / "cmp_2107312.gpx"
OUTFILE = ROOT / ".tmp" / "pnma_profile.gpx"

G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(INFILE))
gpx.save(str(OUTFILE))
gpx.set_Controls("cycles", 10)
for variable in (":0:U", ":0:W", ":0:X", ":0:Y", ":0:SH/L"):
    gpx.set_Controls("parmMin", 0.0, variable)
h = gpx.histogram(0)
h.set_refinements({"Instrument Parameters": ["X", "Y", "SH/L"]})
gpx.refine()

out = {
    "residuals": h.residuals,
    "instrument": {k: h.InstrumentParameters[k][1] for k in ("U", "V", "W", "X", "Y", "SH/L")},
    "mass_fractions": h.ComputeMassFracs(),
    "cells": {p.name: p.get_cell() for p in gpx.phases()},
}
print(json.dumps(out), flush=True)
