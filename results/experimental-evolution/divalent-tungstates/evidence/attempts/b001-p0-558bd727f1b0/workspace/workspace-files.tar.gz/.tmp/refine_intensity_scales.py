import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "strain_textures.gpx"))
gpx.save(str(ROOT / ".tmp" / "prefinal_background.gpx"))
gpx.set_Controls("cycles", 30)
h = gpx.histogram(0)
wo = gpx.phase("WO3_Pnma")
h.Background[0][1] = True
h.SampleParameters["Scale"][1] = True
wo.getHAPvalues(h)["Scale"][1] = True
gpx.refine()
print(json.dumps({
    "residuals": h.residuals,
    "mass_fractions": h.ComputeMassFracs(),
    "scales": {"hist": h.SampleParameters["Scale"], "wo": wo.getHAPvalues(h)["Scale"]},
    "background": h.Background[0],
}), flush=True)
