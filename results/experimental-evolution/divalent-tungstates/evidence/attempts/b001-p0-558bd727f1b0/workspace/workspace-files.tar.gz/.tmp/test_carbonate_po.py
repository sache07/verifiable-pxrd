import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
AXIS = [int(value) for value in sys.argv[1:4]]
TAG = "".join(str(value) for value in AXIS)

G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "threephase_cell.gpx"))
gpx.save(str(ROOT / ".tmp" / f"carbonate_po_{TAG}.gpx"))
gpx.set_Controls("cycles", 40)
hist = gpx.histogram(0)
phase = gpx.phase("SrCO3_Pnma")
phase.data["General"]["Cell"][0] = False
phase.getHAPvalues(hist)["Pref.Ori."][3] = AXIS
phase.set_HAP_refinements({"Pref.Ori.": True})
gpx.set_Controls("parmMin", 0.2, "2:0:MD")
gpx.set_Controls("parmMax", 5.0, "2:0:MD")
gpx.refine()
gpx.save()

print(json.dumps({
    "axis": AXIS,
    "Rwp": hist.residuals.get("wR"),
    "MD": phase.getHAPvalues(hist)["Pref.Ori."][1],
    "fractions": hist.ComputeMassFracs(),
}), flush=True)
