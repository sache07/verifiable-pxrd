import csv
from pathlib import Path

import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parents[1]
columns = {name: [] for name in (
    "two_theta_deg", "observed_counts", "calculated_counts", "difference_counts"
)}
with (ROOT / "fit.csv").open() as stream:
    for row in csv.DictReader(stream):
        for name in columns:
            columns[name].append(float(row[name]))

x = columns["two_theta_deg"]
fig, axes = plt.subplots(3, 1, figsize=(15, 10), constrained_layout=True)
for ax, low, high in zip(axes, (10, 40, 70), (40, 70, 100.01)):
    use = [index for index, value in enumerate(x) if low <= value <= high]
    xx = [x[index] for index in use]
    ax.plot(xx, [columns["observed_counts"][i] for i in use], "k-", lw=0.7,
            label="observed")
    ax.plot(xx, [columns["calculated_counts"][i] for i in use], "r-", lw=0.8,
            label="calculated")
    ax.plot(xx, [columns["difference_counts"][i] for i in use], "b-", lw=0.6,
            label="difference")
    ax.axhline(0, color="0.6", lw=0.5)
    ax.set_xlim(low, high)
    ax.set_ylabel("counts")
axes[0].legend(loc="upper right", ncol=3)
axes[-1].set_xlabel(r"$2\theta$ (degrees)")
fig.savefig(ROOT / ".tmp" / "final_fit.png", dpi=160)
