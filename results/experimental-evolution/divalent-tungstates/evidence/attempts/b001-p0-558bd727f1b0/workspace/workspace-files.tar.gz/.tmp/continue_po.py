import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "po_110.gpx"))
gpx.save(str(ROOT / ".tmp" / "po_final.gpx"))
gpx.set_Controls("cycles", 40)
h = gpx.histogram(0)
sr = gpx.phase("SrWO4")
for cycle in range(1, 4):
    gpx.refine()
    print(json.dumps({
        "cycle": cycle, "residuals": h.residuals,
        "preferred_orientation": sr.getHAPvalues(h)["Pref.Ori."],
        "mass_fractions": h.ComputeMassFracs(),
    }), flush=True)
