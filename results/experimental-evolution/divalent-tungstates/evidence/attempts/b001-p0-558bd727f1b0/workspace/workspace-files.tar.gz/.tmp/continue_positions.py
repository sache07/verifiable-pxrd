import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "position_converged.gpx"))
gpx.save(str(ROOT / ".tmp" / "position_converged2.gpx"))
gpx.set_Controls("cycles", 20)
h = gpx.histogram(0)
sr = gpx.phase("SrWO4")
wo = gpx.phase("WO3_Pnma")

def report(label):
    print(json.dumps({
        "stage": label, "Rwp": h.residuals.get("wR"),
        "shift": h.SampleParameters["Shift"][0],
        "sr_cell": sr.get_cell(), "wo_cell": wo.get_cell(),
    }), flush=True)

for cycle in range(1, 9):
    sr.data["General"]["Cell"][0] = True
    wo.data["General"]["Cell"][0] = True
    gpx.refine()
    sr.data["General"]["Cell"][0] = False
    wo.data["General"]["Cell"][0] = False
    report(f"cells_{cycle}")

    h.SampleParameters["Shift"][1] = True
    gpx.refine()
    h.SampleParameters["Shift"][1] = False
    report(f"shift_{cycle}")

gpx.save()
