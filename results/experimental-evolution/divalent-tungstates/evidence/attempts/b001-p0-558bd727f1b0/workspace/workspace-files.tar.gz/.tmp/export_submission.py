import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp" / "threephase_final_clean.gpx"

PHASE_INFO = {
    "SrWO4": {
        "formula": "SrWO4",
        "cif": "SrWO4.cif",
        "space_group": "I 41/a",
        "space_group_number": 88,
        "structure_source": "scheelite prototype model",
    },
    "WO3_Pnma": {
        "formula": "WO3",
        "cif": "WO3_Pnma.cif",
        "space_group": "P n m a",
        "space_group_number": 62,
        "structure_source": "COD 2107312",
    },
    "SrCO3_Pnma": {
        "formula": "SrCO3",
        "cif": "SrCO3_Pnma.cif",
        "space_group": "P n m a",
        "space_group_number": 62,
        "structure_source": "COD 9008198",
    },
}

G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(SOURCE))
gpx.save(str(ROOT / "final.gpx"))
hist = gpx.histogram(0)
fractions = hist.ComputeMassFracs()
residuals = hist.residuals
rvals = gpx.data["Covariance"]["data"]["Rvals"]

phase_records = []
for index, phase in enumerate(gpx.phases()):
    info = PHASE_INFO[phase.name]
    phase.export_CIF(str(ROOT / info["cif"]))
    fraction, formal_su = fractions[phase.name]
    phase_records.append({
        "name": phase.name,
        "formula": info["formula"],
        "space_group": info["space_group"],
        "space_group_number": info["space_group_number"],
        "cif": info["cif"],
        "weight_fraction": fraction,
        "weight_percent": 100.0 * fraction,
        "weight_fraction_formal_standard_uncertainty": formal_su,
        "R_F_percent": residuals.get(f"{index}:0:Rf"),
        "cell_angstrom_degrees": phase.get_cell(),
        "structure_source": info["structure_source"],
    })

x = hist.getdata("X")
observed = hist.getdata("Yobs")
calculated = hist.getdata("Ycalc")
difference = hist.getdata("Residual")
fit_limits = hist.data["Limits"][1]
# GSAS-II computes through the first grid point above the upper nominal
# limit. Select the points actually calculated so fit.csv has exactly Nobs
# rows rather than imposing a second, slightly different range convention.
use = calculated != 0
with (ROOT / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow([
        "two_theta_deg",
        "observed_counts",
        "calculated_counts",
        "difference_counts",
    ])
    for values in zip(x[use], observed[use], calculated[use], difference[use]):
        writer.writerow([f"{float(value):.10g}" for value in values])

result = {
    "phases": phase_records,
    "fraction_basis": (
        "Normalized over the three modeled crystalline phases; amorphous or "
        "unidentified content is not quantified."
    ),
    "fraction_uncertainty_note": (
        "Formal covariance standard uncertainties are listed per phase, but "
        "model-variant spread is about 1-3 absolute wt%; uncorrected "
        "microabsorption may increase the systematic uncertainty."
    ),
    "fit_statistics": {
        "Rwp_percent": residuals["wR"],
        "Rp_percent": residuals["R"],
        "Rexp_percent": residuals["wRmin"],
        "GOF": rvals["GOF"],
        "reduced_chi_squared": rvals["GOF"] ** 2,
        "chi_squared": rvals["chisq"],
        "observations": rvals["Nobs"],
        "refined_variables": rvals["Nvars"],
        "converged": bool(rvals["converged"]),
        "maximum_shift_over_esd": rvals["Max shft/sig"],
        "two_theta_range_deg": [float(fit_limits[0]), float(fit_limits[1])],
        "difference_definition": "observed - calculated",
        "weighting": "Poisson estimate from counts (w = 1 / observed_counts)",
    },
    "measurement_model": {
        "geometry": "Bragg-Brentano reflection",
        "radiation": "Cu K-alpha1/K-alpha2",
        "wavelength_Kalpha1_angstrom": 1.540598,
        "wavelength_Kalpha2_angstrom": 1.544426,
        "Kalpha2_to_Kalpha1_ratio": 0.5,
    },
    "project": "final.gpx",
    "profile": "fit.csv",
}

with (ROOT / "result.json").open("w") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

print(json.dumps({
    "phases": phase_records,
    "fit_statistics": result["fit_statistics"],
    "profile_rows": int(use.sum()),
}, indent=2))
