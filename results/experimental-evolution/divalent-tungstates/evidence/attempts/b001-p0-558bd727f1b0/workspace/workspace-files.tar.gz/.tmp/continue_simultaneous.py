import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "simultaneous.gpx"))
gpx.save(str(ROOT / ".tmp" / "simultaneous_converged.gpx"))
gpx.set_Controls("cycles", 50)
h = gpx.histogram(0)
sr = gpx.phase("SrWO4")
wo = gpx.phase("WO3_Pnma")
for cycle in range(1, 6):
    gpx.refine()
    print(json.dumps({
        "cycle": cycle, "Rwp": h.residuals.get("wR"),
        "mass_fractions": h.ComputeMassFracs(),
        "polarization": h.InstrumentParameters["Polariz."][1],
        "profile": {k: h.InstrumentParameters[k][1] for k in ("W", "X", "SH/L")},
        "MD": [sr.getHAPvalues(h)["Pref.Ori."][1], wo.getHAPvalues(h)["Pref.Ori."][1]],
        "strain": [sr.getHAPvalues(h)["Mustrain"][1][0], wo.getHAPvalues(h)["Mustrain"][1][0]],
    }), flush=True)
