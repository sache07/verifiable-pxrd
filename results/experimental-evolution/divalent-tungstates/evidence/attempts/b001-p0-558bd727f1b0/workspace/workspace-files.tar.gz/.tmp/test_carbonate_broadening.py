import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
MODE = sys.argv[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "threephase_textures.gpx"))
gpx.save(str(ROOT / ".tmp" / f"carbonate_{MODE}.gpx"))
gpx.set_Controls("cycles", 50)
hist = gpx.histogram(0)
phase = gpx.phase("SrCO3_Pnma")

if MODE == "size":
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
elif MODE == "strain":
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
else:
    raise ValueError(MODE)

for cycle in range(1, 3):
    gpx.refine()
    gpx.save()
    print(json.dumps({
        "mode": MODE,
        "cycle": cycle,
        "Rwp": hist.residuals.get("wR"),
        "size": phase.getHAPvalues(hist)["Size"],
        "strain": phase.getHAPvalues(hist)["Mustrain"],
        "fractions": hist.ComputeMassFracs(),
    }), flush=True)
