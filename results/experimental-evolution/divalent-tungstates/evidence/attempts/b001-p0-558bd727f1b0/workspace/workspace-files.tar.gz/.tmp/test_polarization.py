import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "prefinal_background.gpx"))
gpx.save(str(ROOT / ".tmp" / "polarization_test.gpx"))
gpx.set_Controls("cycles", 40)
h = gpx.histogram(0)
h.Background[0][1] = False
h.InstrumentParameters["Polariz."][2] = True
gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")
gpx.refine()
print(json.dumps({
    "residuals": h.residuals,
    "polarization": h.InstrumentParameters["Polariz."],
    "mass_fractions": h.ComputeMassFracs(),
}), flush=True)
