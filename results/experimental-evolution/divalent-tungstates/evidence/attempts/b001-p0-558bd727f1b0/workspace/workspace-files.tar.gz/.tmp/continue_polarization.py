import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "polarization_test.gpx"))
gpx.save(str(ROOT / ".tmp" / "polarization_converged.gpx"))
gpx.set_Controls("cycles", 40)
h = gpx.histogram(0)
for cycle in range(1, 4):
    gpx.refine()
    print(json.dumps({
        "cycle": cycle, "residuals": h.residuals,
        "polarization": h.InstrumentParameters["Polariz."],
        "mass_fractions": h.ComputeMassFracs(),
    }), flush=True)
