import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
AXIS = [int(v) for v in sys.argv[1:4]]
TAG = "".join(str(v) for v in AXIS)
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "po_final.gpx"))
gpx.save(str(ROOT / ".tmp" / f"wo_po_{TAG}.gpx"))
gpx.set_Controls("cycles", 30)
h = gpx.histogram(0)
sr = gpx.phase("SrWO4")
wo = gpx.phase("WO3_Pnma")
sr.getHAPvalues(h)["Pref.Ori."][2] = False
wo.getHAPvalues(h)["Pref.Ori."][3] = AXIS
wo.set_HAP_refinements({"Pref.Ori.": True})
gpx.refine()
print(json.dumps({
    "axis": AXIS, "residuals": h.residuals,
    "preferred_orientation": wo.getHAPvalues(h)["Pref.Ori."],
    "mass_fractions": h.ComputeMassFracs(),
}), flush=True)
