import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "srco3_test.gpx"))
hist = gpx.histogram(0)
gpx.set_Controls("cycles", 40)

for cycle in range(1, 5):
    gpx.refine()
    gpx.save()
    print(json.dumps({
        "cycle": cycle,
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "fractions": hist.ComputeMassFracs(),
    }), flush=True)
