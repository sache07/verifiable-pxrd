import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
AXIS = [int(v) for v in sys.argv[1:4]] if len(sys.argv) >= 4 else [0, 0, 1]
TAG = "".join(str(v) for v in AXIS)
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "intensity_refined.gpx"))
gpx.save(str(ROOT / ".tmp" / f"po_{TAG}.gpx"))
gpx.set_Controls("cycles", 30)
h = gpx.histogram(0)
sr = gpx.phase("SrWO4")
h.Background[0][1] = False
sr.getHAPvalues(h)["Pref.Ori."][3] = AXIS
sr.set_HAP_refinements({"Pref.Ori.": True})
gpx.set_Controls("parmMin", 0.2, "0:0:MD")
gpx.set_Controls("parmMax", 5.0, "0:0:MD")
gpx.refine()
print(json.dumps({
    "axis": AXIS,
    "residuals": h.residuals,
    "preferred_orientation": sr.getHAPvalues(h)["Pref.Ori."],
    "mass_fractions": h.ComputeMassFracs(),
}), flush=True)
