import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "threephase_final_refinement.gpx"))
gpx.save(str(ROOT / ".tmp" / "threephase_final_clean.gpx"))
gpx.data["Controls"]["data"]["parmFrozen"]["FrozenList"] = []
gpx.set_Controls("cycles", 60)
gpx.refine()
gpx.save()

hist = gpx.histogram(0)
rvals = gpx.data["Covariance"]["data"]["Rvals"]
print(json.dumps({
    "residuals": hist.residuals,
    "fractions": hist.ComputeMassFracs(),
    "Rvals": rvals,
}, default=str, indent=2))
