import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "polarization_converged.gpx"))
gpx.save(str(ROOT / ".tmp" / "polished.gpx"))
gpx.set_Controls("cycles", 30)
h = gpx.histogram(0)
sr = gpx.phase("SrWO4")
wo = gpx.phase("WO3_Pnma")

def all_off():
    h.Background[0][1] = False
    for key, val in h.SampleParameters.items():
        if isinstance(val, list) and len(val) > 1 and isinstance(val[1], bool):
            val[1] = False
    for val in h.InstrumentParameters.values():
        if isinstance(val, list) and len(val) > 2:
            val[2] = False
    for phase in (sr, wo):
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.getHAPvalues(h)
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
    h.SampleParameters["Scale"][1] = True
    wo.getHAPvalues(h)["Scale"][1] = True

def run(label, kind):
    all_off()
    if kind == "sr_po":
        sr.getHAPvalues(h)["Pref.Ori."][2] = True
    elif kind == "wo_po":
        wo.getHAPvalues(h)["Pref.Ori."][2] = True
    elif kind == "sr_strain":
        sr.getHAPvalues(h)["Mustrain"][2][0] = True
    elif kind == "wo_strain":
        wo.getHAPvalues(h)["Mustrain"][2][0] = True
    elif kind == "background":
        h.Background[0][1] = True
    elif kind == "polarization":
        h.InstrumentParameters["Polariz."][2] = True
    elif kind in ("W", "X", "SH/L"):
        h.InstrumentParameters[kind][2] = True
    else:
        raise ValueError(kind)
    gpx.refine()
    print(json.dumps({
        "stage": label, "Rwp": h.residuals.get("wR"),
        "mass_fractions": h.ComputeMassFracs(),
        "polarization": h.InstrumentParameters["Polariz."][1],
        "profile": {k: h.InstrumentParameters[k][1] for k in ("U", "V", "W", "X", "Y", "SH/L")},
        "sr_MD": sr.getHAPvalues(h)["Pref.Ori."][1],
        "wo_MD": wo.getHAPvalues(h)["Pref.Ori."][1],
        "sr_strain": sr.getHAPvalues(h)["Mustrain"][1][0],
        "wo_strain": wo.getHAPvalues(h)["Mustrain"][1][0],
    }), flush=True)

for cycle in range(1, 3):
    for kind in ("sr_po", "wo_po", "sr_strain", "wo_strain", "background", "polarization", "W", "X", "SH/L"):
        run(f"{kind}_{cycle}", kind)
all_off()
gpx.save()
