import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "polished.gpx"))
gpx.save(str(ROOT / ".tmp" / "simultaneous.gpx"))
gpx.set_Controls("cycles", 50)
gpx.data["Controls"]["data"]["min dM/M"] = 1e-6
h = gpx.histogram(0)
sr = gpx.phase("SrWO4")
wo = gpx.phase("WO3_Pnma")
h.Background[0][1] = True
h.SampleParameters["Scale"][1] = True
wo.getHAPvalues(h)["Scale"][1] = True
h.InstrumentParameters["Polariz."][2] = True
for key in ("W", "X", "SH/L"):
    h.InstrumentParameters[key][2] = True
sr.getHAPvalues(h)["Pref.Ori."][2] = True
wo.getHAPvalues(h)["Pref.Ori."][2] = True
sr.getHAPvalues(h)["Mustrain"][2][0] = True
wo.getHAPvalues(h)["Mustrain"][2][0] = True
gpx.refine()
print(json.dumps({
    "residuals": h.residuals,
    "mass_fractions": h.ComputeMassFracs(),
    "polarization": h.InstrumentParameters["Polariz."],
    "profile": {k: h.InstrumentParameters[k] for k in ("U", "V", "W", "X", "Y", "SH/L")},
    "sr_MD": sr.getHAPvalues(h)["Pref.Ori."],
    "wo_MD": wo.getHAPvalues(h)["Pref.Ori."],
    "sr_strain": sr.getHAPvalues(h)["Mustrain"],
    "wo_strain": wo.getHAPvalues(h)["Mustrain"],
}), flush=True)
