import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "pnma_profile.gpx"))
gpx.save(str(ROOT / ".tmp" / "test_sr_po_damped.gpx"))
gpx.set_Controls("cycles", 30)
gpx.data["Controls"]["data"]["shift factor"] = 0.2
h = gpx.histogram(0)
sr = gpx.phase("SrWO4")
wo = gpx.phase("WO3_Pnma")
h.clear_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]})
h.clear_refinements({"Background": True})
h.clear_refinements({"Sample Parameters": ["Shift"]})
sr.clear_refinements({"Cell": True})
wo.clear_refinements({"Cell": True})
sr.set_HAP_refinements({"Pref.Ori.": True})
gpx.refine()
print(json.dumps({
    "residuals": h.residuals,
    "sr_preferred_orientation": sr.getHAPvalues(h)["Pref.Ori."],
    "mass_fractions": h.ComputeMassFracs(),
}), flush=True)
