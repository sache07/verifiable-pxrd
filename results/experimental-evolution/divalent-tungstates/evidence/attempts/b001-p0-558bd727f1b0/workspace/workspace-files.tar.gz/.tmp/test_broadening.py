import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
MODE = sys.argv[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "textures_refined.gpx"))
gpx.save(str(ROOT / ".tmp" / f"broad_{MODE}.gpx"))
gpx.set_Controls("cycles", 30)
h = gpx.histogram(0)
sr = gpx.phase("SrWO4")
wo = gpx.phase("WO3_Pnma")
if MODE == "sr_size":
    sr.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
elif MODE == "wo_size":
    wo.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
elif MODE == "both_size":
    sr.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    wo.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
elif MODE == "sr_strain":
    sr.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
elif MODE == "wo_strain":
    wo.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
elif MODE == "both_strain":
    sr.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    wo.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
else:
    raise ValueError(MODE)
gpx.refine()
print(json.dumps({
    "mode": MODE, "residuals": h.residuals,
    "mass_fractions": h.ComputeMassFracs(),
    "Sr_size": sr.getHAPvalues(h)["Size"],
    "WO_size": wo.getHAPvalues(h)["Size"],
    "Sr_strain": sr.getHAPvalues(h)["Mustrain"],
    "WO_strain": wo.getHAPvalues(h)["Mustrain"],
}), flush=True)
