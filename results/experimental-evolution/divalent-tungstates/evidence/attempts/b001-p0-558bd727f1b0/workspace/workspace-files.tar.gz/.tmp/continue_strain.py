import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "broad_both_strain.gpx"))
gpx.save(str(ROOT / ".tmp" / "strain_converged.gpx"))
gpx.set_Controls("cycles", 40)
h = gpx.histogram(0)
sr = gpx.phase("SrWO4")
wo = gpx.phase("WO3_Pnma")
for cycle in range(1, 5):
    gpx.refine()
    print(json.dumps({
        "cycle": cycle, "Rwp": h.residuals.get("wR"),
        "Sr_strain": sr.getHAPvalues(h)["Mustrain"],
        "WO_strain": wo.getHAPvalues(h)["Mustrain"],
        "mass_fractions": h.ComputeMassFracs(),
    }), flush=True)
