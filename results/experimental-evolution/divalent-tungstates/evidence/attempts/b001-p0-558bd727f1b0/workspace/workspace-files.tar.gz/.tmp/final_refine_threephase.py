import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "threephase_positions.gpx"))
gpx.save(str(ROOT / ".tmp" / "threephase_final_refinement.gpx"))
gpx.set_Controls("cycles", 60)
hist = gpx.histogram(0)

hist.Background[0][1] = True
for name in ("Polariz.", "W", "X", "SH/L"):
    hist.InstrumentParameters[name][2] = True
for phase in gpx.phases():
    phase.set_HAP_refinements({"Pref.Ori.": True})
for phase in gpx.phases()[:2]:
    phase.set_HAP_refinements({
        "Mustrain": {"type": "isotropic", "refine": True}
    })

for cycle in range(1, 4):
    gpx.refine()
    gpx.save()
    print(json.dumps({
        "cycle": cycle,
        "residuals": hist.residuals,
        "fractions": hist.ComputeMassFracs(),
        "instrument": {
            name: hist.InstrumentParameters[name][1]
            for name in ("Polariz.", "W", "X", "SH/L")
        },
        "textures": {
            phase.name: phase.getHAPvalues(hist)["Pref.Ori."][1]
            for phase in gpx.phases()
        },
        "strain": {
            phase.name: phase.getHAPvalues(hist)["Mustrain"][1][0]
            for phase in gpx.phases()[:2]
        },
    }), flush=True)
