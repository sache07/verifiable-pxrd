import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "texture_final.gpx"))
gpx.save(str(ROOT / ".tmp" / "profile_final.gpx"))
gpx.set_Controls("cycles", 30)
h = gpx.histogram(0)
sr = gpx.phase("SrWO4")
wo = gpx.phase("WO3_Pnma")
sr.getHAPvalues(h)["Pref.Ori."][2] = False
wo.getHAPvalues(h)["Pref.Ori."][2] = False
h.Background[0][1] = False

def run(label, parameter):
    for key in ("U", "V", "W", "X", "Y", "SH/L"):
        h.InstrumentParameters[key][2] = key == parameter
    gpx.refine()
    print(json.dumps({
        "stage": label, "Rwp": h.residuals.get("wR"),
        "profile": {k: h.InstrumentParameters[k][1] for k in ("U", "V", "W", "X", "Y", "SH/L")},
        "mass_fractions": h.ComputeMassFracs(),
    }), flush=True)

for cycle in range(1, 3):
    run(f"U_{cycle}", "U")
    run(f"W_{cycle}", "W")
    run(f"X_{cycle}", "X")
    run(f"SHL_{cycle}", "SH/L")
for key in ("U", "V", "W", "X", "Y", "SH/L"):
    h.InstrumentParameters[key][2] = False
gpx.save()
