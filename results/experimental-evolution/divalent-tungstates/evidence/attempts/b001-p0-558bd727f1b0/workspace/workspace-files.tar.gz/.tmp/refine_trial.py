from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
GPX = ROOT / ".tmp" / "trial.gpx"
WO3 = Path("<RUN>/resources/b001-c03/cif/2/10/73/2107312.cif")

G2sc.SetPrintLevel("warn")
gpx = G2sc.G2Project(newgpx=str(GPX), author="OpenAI Codex")
h = gpx.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / ".tmp" / "pixcel_cuka.instprm"),
    fmthint="comma/tab/semicolon separated",
)
sr = gpx.add_phase(
    str(ROOT / ".tmp" / "srwo4_start.cif"), phasename="SrWO4",
    histograms=[h], fmthint="CIF"
)
wo = gpx.add_phase(
    str(WO3), phasename="WO3_orthorhombic",
    histograms=[h], fmthint="CIF"
)
gpx.set_Controls("cycles", 8)
h.set_refinements({
    "Limits": [10.0, 100.0],
    "Background": {
        "type": "chebyschev-1", "refine": True, "no. coeffs": 8,
        "coeffs": [1100.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
    },
})
h.SampleParameters["Shift"] = [800.0, True]
for key, value in {"U": 20.0, "V": -10.0, "W": 50.0, "X": 2.0, "Y": 0.0}.items():
    h.InstrumentParameters[key][1] = value

sr.HAPvalue("Scale", 1.0)
wo.HAPvalue("Scale", 0.15)
wo.set_HAP_refinements({"Scale": True})
sr.set_refinements({"Cell": True})
wo.set_refinements({"Cell": True})

def summary(label):
    print("\nSUMMARY", label)
    print("residuals", h.residuals)
    print("sample", {k: v for k, v in h.SampleParameters.items() if k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")})
    print("instrument", {k: v for k, v in h.InstrumentParameters.items() if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)")})
    for p in (sr, wo):
        print(p.name, "cell", p.get_cell(), "scale", p.HAPvalue("Scale"), "density", p.density)
    try:
        print("massfracs", h.ComputeMassFracs())
    except Exception as exc:
        print("massfracs error", repr(exc))

gpx.refine(printFile=str(ROOT / ".tmp" / "trial_stage1.lst"))
summary("stage1 global/cell")

h.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
gpx.refine(printFile=str(ROOT / ".tmp" / "trial_stage2.lst"))
summary("stage2 gaussian profile")

h.set_refinements({"Instrument Parameters": ["X", "Y", "SH/L"]})
gpx.refine(printFile=str(ROOT / ".tmp" / "trial_stage3.lst"))
summary("stage3 full profile")

gpx.save()
