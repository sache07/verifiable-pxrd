import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "threephase_strains.gpx"))
gpx.save(str(ROOT / ".tmp" / "threephase_profile.gpx"))
gpx.set_Controls("cycles", 60)
hist = gpx.histogram(0)
hist.Background[0][1] = True
for name in ("Polariz.", "W", "X", "SH/L"):
    hist.InstrumentParameters[name][2] = True
gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")
for name in ("W", "X", "SH/L"):
    gpx.set_Controls("parmMin", 0.0, f":0:{name}")

for cycle in range(1, 4):
    gpx.refine()
    gpx.save()
    print(json.dumps({
        "cycle": cycle,
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "instrument": {
            name: hist.InstrumentParameters[name][1]
            for name in ("Polariz.", "W", "X", "SH/L")
        },
        "fractions": hist.ComputeMassFracs(),
    }), flush=True)
