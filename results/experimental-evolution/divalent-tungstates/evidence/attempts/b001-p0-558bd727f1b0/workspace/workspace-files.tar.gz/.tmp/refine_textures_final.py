import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "strain_converged.gpx"))
gpx.save(str(ROOT / ".tmp" / "strain_textures.gpx"))
gpx.set_Controls("cycles", 30)
h = gpx.histogram(0)
sr = gpx.phase("SrWO4")
wo = gpx.phase("WO3_Pnma")
h.Background[0][1] = False
sr.getHAPvalues(h)["Mustrain"][2] = [False, False, False]
wo.getHAPvalues(h)["Mustrain"][2] = [False, False, False]

def report(label):
    print(json.dumps({
        "stage": label, "Rwp": h.residuals.get("wR"),
        "sr_MD": sr.getHAPvalues(h)["Pref.Ori."],
        "wo_MD": wo.getHAPvalues(h)["Pref.Ori."],
        "mass_fractions": h.ComputeMassFracs(),
    }), flush=True)

for cycle in range(1, 4):
    sr.getHAPvalues(h)["Pref.Ori."][2] = True
    wo.getHAPvalues(h)["Pref.Ori."][2] = False
    gpx.refine()
    report(f"Sr_{cycle}")
    sr.getHAPvalues(h)["Pref.Ori."][2] = False
    wo.getHAPvalues(h)["Pref.Ori."][2] = True
    gpx.refine()
    report(f"WO3_{cycle}")
sr.getHAPvalues(h)["Pref.Ori."][2] = False
wo.getHAPvalues(h)["Pref.Ori."][2] = False
gpx.save()
