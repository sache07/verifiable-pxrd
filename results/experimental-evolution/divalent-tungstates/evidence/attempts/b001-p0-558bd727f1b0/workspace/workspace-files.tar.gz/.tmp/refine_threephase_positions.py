import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "threephase_profile.gpx"))
gpx.save(str(ROOT / ".tmp" / "threephase_positions.gpx"))
gpx.set_Controls("cycles", 50)
hist = gpx.histogram(0)
phases = gpx.phases()

hist.Background[0][1] = False
for value in hist.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for phase in phases:
    phase.getHAPvalues(hist)["Pref.Ori."][2] = False
    phase.getHAPvalues(hist)["Mustrain"][2] = [False, False, False]
hist.SampleParameters["Scale"][1] = True
for phase in phases[1:]:
    phase.getHAPvalues(hist)["Scale"][1] = True

def report(stage):
    print(json.dumps({
        "stage": stage,
        "Rwp": hist.residuals.get("wR"),
        "shift_um": hist.SampleParameters["Shift"][0],
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "fractions": hist.ComputeMassFracs(),
    }), flush=True)

for cycle in range(1, 4):
    hist.SampleParameters["Shift"][1] = False
    for phase in phases:
        phase.data["General"]["Cell"][0] = True
    gpx.refine()
    report(f"cells_{cycle}")

    for phase in phases:
        phase.data["General"]["Cell"][0] = False
    hist.SampleParameters["Shift"][1] = True
    gpx.refine()
    report(f"shift_{cycle}")

hist.SampleParameters["Shift"][1] = False
gpx.save()
