#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIfiles as G2fil
from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
TMP = ROOT / ".tmp"
CIFROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id: str) -> Path:
    return CIFROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make_xye() -> Path:
    rows = []
    with (ROOT / "inputs/pattern.csv").open() as handle:
        for row in csv.DictReader(handle):
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            rows.append((x, y, np.sqrt(max(y, 1.0))))
    output = TMP / "pattern.xye"
    np.savetxt(output, np.asarray(rows), fmt=("%.8f", "%.8f", "%.8f"))
    return output


names = ["Type", "Lam1", "Lam2", "Zero", "I(L2)/I(L1)", "Polariz.",
         "U", "V", "W", "X", "Y", "Z", "SH/L", "Azimuth"]
values = ["PXC", 1.540598, 1.544426, 0.0, 0.5, 0.7,
          0.0, 0.0, 12.0, 1.0, 0.0, 0.0, 0.002, 0.0]
inst = G2fil.makeInstDict(names, values, [0] * len(values))
inst["Source"] = ["CuKa", "CuKa"]

gpx_path = TMP / "setup.gpx"
gpx = G2sc.G2Project(newgpx=str(gpx_path))
hist = gpx.add_powder_histogram(str(make_xye()), (inst, {}), fmthint="Topas")
for name, cod_id in (("ZnWO4", "1520641"), ("ZnO", "9004178"), ("WO3", "2311041")):
    gpx.add_phase(str(cif_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF")
gpx.save()

print("HIST", hist.name)
print("INST", json.dumps(hist.data["Instrument Parameters"], default=str))
print("SAMPLE", json.dumps(hist.data["Sample Parameters"], default=str))
print("BACKGROUND", json.dumps(hist.data["Background"], default=str))
for phase in gpx.phases():
    print("PHASE", phase.name, "COMP", phase.composition)
    print("CELL", phase.get_cell())
    print("HAP", json.dumps(phase.getHAPvalues(hist), default=str))
