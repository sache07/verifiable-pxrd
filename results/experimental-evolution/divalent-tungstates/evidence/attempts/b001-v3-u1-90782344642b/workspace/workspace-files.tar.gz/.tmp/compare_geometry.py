#!/usr/bin/env python3
from __future__ import annotations

import numpy as np
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


FILES = {
    "source": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/06/1520641.cif",
    "refined": ".tmp/ZnWO4_atoms_trial.cif",
}

for label, filename in FILES.items():
    structure = Structure.from_file(filename)
    dmat = structure.distance_matrix
    np.fill_diagonal(dmat, np.inf)
    print(label)
    print("  composition", structure.composition.formula)
    print("  space_group", SpacegroupAnalyzer(structure, symprec=1e-3).get_space_group_symbol())
    print("  cell", *(f"{v:.6f}" for v in (*structure.lattice.abc, *structure.lattice.angles)))
    print("  minimum_pair_distance", f"{np.min(dmat):.5f}")
    for element in ("W", "Zn"):
        shells = []
        for i, site in enumerate(structure):
            if site.specie.symbol != element:
                continue
            distances = sorted(float(dmat[i, j]) for j, other in enumerate(structure)
                               if other.specie.symbol == "O")[:6]
            shells.append(distances)
        shell = np.asarray(shells)
        print(f"  {element}-O", " ".join(f"{v:.5f}" for v in np.mean(shell, axis=0)),
              f"range={np.min(shell):.5f}-{np.max(shell):.5f}")
    oo = [dmat[i, j] for i, site in enumerate(structure)
          for j, other in enumerate(structure) if j > i
          and site.specie.symbol == other.specie.symbol == "O"]
    print("  minimum_O-O", f"{min(oo):.5f}")
