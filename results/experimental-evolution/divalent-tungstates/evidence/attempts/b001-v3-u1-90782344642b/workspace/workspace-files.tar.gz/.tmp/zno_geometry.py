#!/usr/bin/env python3
from pymatgen.core import Structure

for label, filename in {
    "source": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/00/41/9004178.cif",
    "trial": ".tmp/ZnO_Oz_trial.cif",
}.items():
    structure = Structure.from_file(filename)
    distances = []
    for site in structure:
        if site.specie.symbol != "Zn":
            continue
        distances.extend(sorted(neighbor.nn_distance for neighbor in structure.get_neighbors(site, 2.3)
                                if neighbor.specie.symbol == "O")[:4])
    print(label, structure.composition.formula,
          "cell", *(f"{value:.6f}" for value in (*structure.lattice.abc, *structure.lattice.angles)),
          "Zn-O", *(f"{value:.5f}" for value in sorted(distances)[:4]))
