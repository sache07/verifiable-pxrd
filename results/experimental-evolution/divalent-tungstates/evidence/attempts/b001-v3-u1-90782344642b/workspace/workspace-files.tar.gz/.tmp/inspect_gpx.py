#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("gpx")
parser.add_argument("--npz")
args = parser.parse_args()

gpx = G2sc.G2Project(args.gpx)
hist = gpx.histogram(0)
cov = gpx.data.get("Covariance", {}).get("data", {})
data = hist.data["data"][1]

out = {
    "wR_percent": hist.get_wR(),
    "Rvals": cov.get("Rvals", {}),
    "varyList": cov.get("varyList", []),
    "variables": cov.get("variables", []),
    "sig": cov.get("sig", []),
    "frozen": gpx.get_Frozen(),
    "instrument": hist.data["Instrument Parameters"][0],
    "sample": hist.data["Sample Parameters"],
    "background": hist.data["Background"],
    "mass_fractions": hist.ComputeMassFracs(),
    "phases": {},
}
for phase in gpx.phases():
    hap = phase.getHAPvalues(hist)
    out["phases"][phase.name] = {
        "composition": phase.composition,
        "cell": phase.get_cell(),
        "cell_esd": phase.get_cell_and_esd()[1],
        "scale": hap["Scale"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "pref_ori": hap["Pref.Ori."],
    }
print(json.dumps(out, default=lambda obj: obj.tolist() if hasattr(obj, "tolist") else str(obj), indent=2))

if args.npz:
    np.savez(args.npz, x=np.asarray(data[0]), observed=np.asarray(data[1]),
             weight=np.asarray(data[2]), calculated=np.asarray(data[3]),
             background=np.asarray(data[4]), difference=np.asarray(data[1]) - np.asarray(data[3]))
