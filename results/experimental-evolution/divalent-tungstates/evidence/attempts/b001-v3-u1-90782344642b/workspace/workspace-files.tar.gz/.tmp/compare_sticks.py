#!/usr/bin/env python3
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import percentile_filter


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
IDS = {
    "ZnWO4 1520641 P2/c": "1520641",
    "ZnO 9004178 P63mc": "9004178",
    "WO3 2311041 P21/c": "2311041",
    "WO3 2106293 P-1": "2106293",
    "WO3 2107312 Pnma": "2107312",
    "WO3 1521532 P4/ncc": "1521532",
    "WO3 1004057 P6/mmm": "1004057",
}


def cif_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


calc = XRDCalculator(wavelength=1.540598, symprec=0.0)
patterns = {}
for name, cod_id in IDS.items():
    s = Structure.from_file(cif_path(cod_id))
    p = calc.get_pattern(s, two_theta_range=(9.9, 100.1), scaled=True)
    patterns[name] = p
    order = np.argsort(p.y)[::-1]
    print(f"\n{name}")
    print("two_theta rel_intensity hkls")
    for j in order[:30]:
        hkls = ";".join(str(h["hkl"]) for h in p.hkls[j])
        print(f"{p.x[j]:8.4f} {p.y[j]:8.2f} {hkls}")

df = pd.read_csv("inputs/pattern.csv")
x = df.two_theta_deg.to_numpy()
y = df.intensity.to_numpy(float)
base = percentile_filter(y, 20, size=301, mode="nearest")
sig = np.maximum(0, y - base)
sig = sig / sig.max()

fig, axes = plt.subplots(len(patterns) + 1, 1, figsize=(16, 14), sharex=True,
                         gridspec_kw={"height_ratios": [3] + [1] * len(patterns)})
axes[0].plot(x, sig, color="black", lw=0.65)
axes[0].set_ylabel("observed\nresidual")
for ax, (name, p) in zip(axes[1:], patterns.items()):
    ax.vlines(p.x, 0, np.asarray(p.y) / 100, color="tab:blue", lw=0.65)
    ax.set_ylim(0, 1.05)
    ax.set_ylabel(name, rotation=0, ha="right", va="center", fontsize=8)
axes[-1].set(xlabel=r"$2\theta$ (deg)", xlim=(9.9, 100.1))
fig.tight_layout()
fig.savefig(".tmp/candidate_sticks.png", dpi=180)
