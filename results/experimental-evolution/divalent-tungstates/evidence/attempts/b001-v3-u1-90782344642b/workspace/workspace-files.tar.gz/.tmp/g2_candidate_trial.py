#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
TMP = ROOT / ".tmp"
CIFROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id: str) -> Path:
    return CIFROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make_xye() -> Path:
    output = TMP / "pattern.xye"
    if output.exists():
        return output
    rows = []
    with (ROOT / "inputs/pattern.csv").open() as handle:
        for row in csv.DictReader(handle):
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            rows.append((x, y, np.sqrt(max(y, 1.0))))
    np.savetxt(output, np.asarray(rows), fmt=("%.8f", "%.8f", "%.8f"))
    return output


def neutralize_hap(phase, hist) -> None:
    hap = phase.getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10000.0, 10000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"][:] = [0.0, False]
    hap["Scale"][0] = 0.3
    hap["Scale"][1] = True


def snapshot(gpx, hist, label: str) -> dict:
    cov = gpx.data.get("Covariance", {}).get("data", {})
    out = {
        "stage": label,
        "wR_percent": hist.get_wR(),
        "Rvals": cov.get("Rvals", {}),
        "instrument": {k: v[1] for k, v in hist.data["Instrument Parameters"][0].items()
                       if isinstance(v, list) and len(v) >= 2},
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"][0],
        "frozen": gpx.get_Frozen(),
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    try:
        out["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    print("SNAPSHOT", json.dumps(out, default=str))
    return out


def refine(gpx, hist, label: str, log: list[dict]) -> None:
    print(f"\n===== REFINE {label} =====")
    gpx.refine(makeBack=False)
    log.append(snapshot(gpx, hist, label))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_id")
    parser.add_argument("output")
    parser.add_argument("--stop-common", action="store_true")
    args = parser.parse_args()
    outpath = Path(args.output).resolve()
    outpath.parent.mkdir(parents=True, exist_ok=True)

    gpx = G2sc.G2Project(newgpx=str(outpath))
    hist = gpx.add_powder_histogram(str(make_xye()), str(TMP / "cu_kalpha.instprm"), fmthint="Topas")
    hist.data["Sample Parameters"]["Scale"][1] = False
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 12,
                                          "coeffs": [1200.0] + [0.0] * 11,
                                          "refine": True}})

    phase_specs = (("ZnWO4", "1520641"), ("ZnO", "9004178"), ("WO3", args.wo3_id))
    for name, cod_id in phase_specs:
        phase = gpx.add_phase(str(cif_path(cod_id)), phasename=name,
                              histograms=[hist], fmthint="CIF")
        neutralize_hap(phase, hist)

    gpx.set_Controls("cycles", 12)
    gpx.save()
    log: list[dict] = []
    snapshot(gpx, hist, "initial")

    # Refit the common background and every phase scale before any model judgment.
    refine(gpx, hist, "background_scales", log)

    # Use one common angular correction (zero), and refine all symmetry-allowed cells.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    refine(gpx, hist, "zero_cells", log)

    # Establish a low-dimensional common profile before phase broadening.
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine(gpx, hist, "common_WX", log)

    if args.stop_common:
        gpx.save()
        (outpath.with_suffix(".json")).write_text(json.dumps(log, indent=2, default=str) + "\n")
        return

    # Challenge an isotropic size-only branch for each phase with shared scheduling.
    for phase, value in zip(gpx.phases(), (0.035, 0.25, 0.10)):
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": value,
                                                    "refine": True}})
    refine(gpx, hist, "size_only", log)
    refine(gpx, hist, "size_only_replay", log)

    gpx.save()
    (outpath.with_suffix(".json")).write_text(json.dumps(log, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
