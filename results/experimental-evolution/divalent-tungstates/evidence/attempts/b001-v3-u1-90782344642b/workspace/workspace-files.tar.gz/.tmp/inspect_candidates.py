#!/usr/bin/env python3
from __future__ import annotations

import gzip
import json
from collections import Counter
from pathlib import Path

import numpy as np
from pymatgen.io.cif import CifParser
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


INDEX = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")
ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def path_for(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


with gzip.open(INDEX, "rt") as handle:
    database = json.load(handle)

records = []
for system in ("O-W-Zn", "O-Zn", "O-W"):
    records.extend((system, *row) for row in database[system])

for system, formula, cod_id, index_sg, quality in records:
    if not (formula in {"ZnWO4", "ZnO", "WO3"}):
        continue
    path = path_for(str(cod_id))
    parser = CifParser(path, occupancy_tolerance=2.0)
    raw = next(iter(parser.as_dict().values()))
    structures = parser.parse_structures(primitive=False)
    if not structures:
        print(f"{cod_id} PARSE_FAILED {path}")
        continue
    s = structures[0]
    sg = SpacegroupAnalyzer(s, symprec=0.05, angle_tolerance=3).get_space_group_symbol()
    sgnum = SpacegroupAnalyzer(s, symprec=0.05, angle_tolerance=3).get_space_group_number()
    occ = [sum(site.species.values()) for site in s]
    partial = sum(abs(v - 1) > 1e-5 or len(site.species) > 1 for v, site in zip(occ, s))
    distances = s.distance_matrix.copy()
    distances[distances < 1e-8] = np.inf
    dmin = float(distances.min())
    cation_o = {}
    for el in sorted({str(e) for e in s.composition.elements} - {"O"}):
        ds = []
        for i, site in enumerate(s):
            if el not in {str(e) for e in site.species.elements}:
                continue
            for neigh in s.get_neighbors(site, 3.0):
                if "O" in {str(e) for e in neigh.species.elements}:
                    ds.append(float(neigh.nn_distance))
        if ds:
            cation_o[el] = (round(min(ds), 3), round(max(ds), 3), len(ds))
    flags = {k: raw.get(k) for k in raw if any(t in k.lower() for t in ("error_flag", "duplicate", "warning"))}
    source = {
        "title": raw.get("_publ_section_title"),
        "journal": raw.get("_journal_name_full"),
        "year": raw.get("_journal_year"),
        "temp_K": raw.get("_diffrn_ambient_temperature"),
        "pressure": raw.get("_diffrn_ambient_pressure"),
        "method": raw.get("_exptl_crystal_description"),
    }
    print(json.dumps({
        "id": str(cod_id), "index_formula": formula, "occupied_composition": str(s.composition),
        "reduced_formula": s.composition.reduced_formula, "index_sg": index_sg,
        "detected_sg": f"{sg} ({sgnum})", "reported_sg": raw.get("_space_group_name_H-M_alt", raw.get("_symmetry_space_group_name_H-M")),
        "cell": [round(v, 5) for v in (*s.lattice.abc, *s.lattice.angles)],
        "volume": round(s.volume, 4), "sites": len(s), "partial_or_disordered_sites": partial,
        "min_distance_A": round(dmin, 3), "cation_O_ranges_A": cation_o,
        "quality": quality, "flags": flags, "source": source, "path": str(path),
    }, default=str))
