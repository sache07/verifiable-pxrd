#!/usr/bin/env python3
from __future__ import annotations

import json
import numpy as np
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


audit = json.load(open(".tmp/final_audit.json"))
expected = {
    "ZnWO4": ("ZnWO4.cif", "ZnWO4", "P2/c"),
    "ZnO": ("ZnO.cif", "ZnO", "P6_3mc"),
    "WO3": ("WO3.cif", "WO3", "P2_1/c"),
}

for name, (filename, formula, space_group) in expected.items():
    structure = Structure.from_file(filename)
    analyzer = SpacegroupAnalyzer(structure, symprec=1e-3)
    found_formula = structure.composition.reduced_formula
    found_group = analyzer.get_space_group_symbol()
    assert found_formula == formula, (name, found_formula)
    assert found_group == space_group, (name, found_group)
    project_cell = audit["cells"][name]["cell"]
    cif_cell = (*structure.lattice.abc, *structure.lattice.angles)
    target_cell = tuple(project_cell[key] for key in
                        ("length_a", "length_b", "length_c", "angle_alpha", "angle_beta", "angle_gamma"))
    max_cell_delta = max(abs(a - b) for a, b in zip(cif_cell, target_cell))
    assert max_cell_delta < 2e-4

    dmat = structure.distance_matrix.copy()
    np.fill_diagonal(dmat, np.inf)
    minimum = float(np.min(dmat))
    cation = "Zn" if name == "ZnO" else "W"
    coordination = 4 if name == "ZnO" else 6
    shells = []
    for i, site in enumerate(structure):
        if site.specie.symbol == cation:
            shells.extend(sorted(float(dmat[i, j]) for j, other in enumerate(structure)
                                 if other.specie.symbol == "O")[:coordination])
    print(name, "formula", found_formula, "space_group", found_group,
          "max_project_CIF_cell_delta", f"{max_cell_delta:.8f}",
          "minimum_pair", f"{minimum:.5f}",
          f"{cation}-O_range", f"{min(shells):.5f}-{max(shells):.5f}")
