#!/usr/bin/env python3
import argparse

import matplotlib.pyplot as plt
import numpy as np


parser = argparse.ArgumentParser()
parser.add_argument("npz")
parser.add_argument("output")
args = parser.parse_args()

d = np.load(args.npz)
x, yo, yc, bkg, diff = (d[k] for k in ("x", "observed", "calculated", "background", "difference"))
fig, (ax, ar) = plt.subplots(2, 1, figsize=(16, 8), sharex=True,
                             gridspec_kw={"height_ratios": [4, 1]})
ax.plot(x, yo, color="black", lw=0.6, label="observed")
ax.plot(x, yc, color="tab:red", lw=0.65, label="calculated")
ax.plot(x, bkg, color="tab:blue", lw=0.6, label="background")
ax.legend(frameon=False, ncol=3)
ax.set_ylabel("counts")
ar.axhline(0, color="0.5", lw=0.5)
ar.plot(x, diff, color="tab:green", lw=0.55)
ar.set(xlabel=r"$2\theta$ (deg)", ylabel="obs-calc", xlim=(x.min(), x.max()))
fig.tight_layout()
fig.savefig(args.output, dpi=180)

regions = [(14.5, 19.5), (22.5, 25.0), (29.8, 31.0), (31.0, 37.0),
           (40.5, 42.5), (47.0, 54.5), (55.0, 65.5), (67.0, 82.0)]
fig, axes = plt.subplots(4, 2, figsize=(16, 13))
for ax, (lo, hi) in zip(axes.flat, regions):
    s = (x >= lo) & (x <= hi)
    ax.plot(x[s], yo[s], color="black", lw=0.75)
    ax.plot(x[s], yc[s], color="tab:red", lw=0.75)
    ax.plot(x[s], bkg[s], color="tab:blue", lw=0.5)
    ax2 = ax.twinx()
    ax2.plot(x[s], diff[s], color="tab:green", lw=0.45, alpha=0.65)
    ax2.axhline(0, color="0.5", lw=0.35)
    ax2.tick_params(labelright=False, right=False)
    ax.set_title(f"{lo:g}–{hi:g}°")
fig.tight_layout()
fig.savefig(args.output.replace(".png", "_zooms.png"), dpi=180)
