#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


FILES = {
    "P21/c 2311041": Path(".tmp/trial_2311041.gpx"),
    "P-1 2106293": Path(".tmp/trial_2106293.gpx"),
    "Pnma 2107312": Path(".tmp/trial_2107312.gpx"),
}

# Windows emphasize WO3 diagnostic families rather than the dominant ZnWO4 peaks.
WINDOWS = {
    "primary_triplet": (22.85, 24.70),
    "26deg": (26.30, 27.05),
    "28deg": (28.25, 29.25),
    "33deg_multiplet": (32.75, 34.75),
    "41deg": (41.65, 42.20),
    "47_48deg": (46.95, 48.50),
    "50deg": (49.65, 51.15),
    "54_56deg": (53.20, 56.35),
}


payload = {}
arrays = {}
for label, path in FILES.items():
    gpx = G2sc.G2Project(str(path))
    hist = gpx.histogram(0)
    x, yo, wt, yc, bkg, diff = [np.asarray(v, dtype=float) for v in hist.data["data"][1]]
    row = {"global_Rwp_percent": hist.get_wR(), "windows": {}}
    for name, (lo, hi) in WINDOWS.items():
        sel = (x >= lo) & (x <= hi)
        num = np.sum(wt[sel] * (yo[sel] - yc[sel]) ** 2)
        den = np.sum(wt[sel] * yo[sel] ** 2)
        row["windows"][name] = {
            "weighted_R_percent": float(100 * np.sqrt(num / den)),
            "weighted_SSE": float(num),
            "points": int(sel.sum()),
        }
    all_sel = np.zeros_like(x, dtype=bool)
    for lo, hi in WINDOWS.values():
        all_sel |= (x >= lo) & (x <= hi)
    num = np.sum(wt[all_sel] * (yo[all_sel] - yc[all_sel]) ** 2)
    den = np.sum(wt[all_sel] * yo[all_sel] ** 2)
    row["diagnostic_combined_R_percent"] = float(100 * np.sqrt(num / den))
    payload[label] = row
    arrays[label.replace(" ", "_").replace("/", "_")] = yc
    arrays[label.replace(" ", "_").replace("/", "_") + "_diff"] = yo - yc
    arrays["x"] = x
    arrays["observed"] = yo

np.savez(".tmp/candidate_profiles.npz", **arrays)
print(json.dumps(payload, indent=2))
