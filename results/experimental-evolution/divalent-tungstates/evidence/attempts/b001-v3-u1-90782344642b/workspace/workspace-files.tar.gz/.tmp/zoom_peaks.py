#!/usr/bin/env python3
import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_csv("inputs/pattern.csv")
regions = [(30.1, 32.1), (34.0, 34.8), (36.0, 36.7), (47.3, 47.9),
           (56.3, 57.0), (62.6, 63.3), (66.1, 66.7), (67.7, 68.5),
           (68.8, 69.5), (76.7, 77.5), (89.3, 90.2), (94.9, 95.8)]
fig, axes = plt.subplots(3, 4, figsize=(16, 10))
for ax, (lo, hi) in zip(axes.flat, regions):
    q = df[(df.two_theta_deg >= lo) & (df.two_theta_deg <= hi)]
    ax.plot(q.two_theta_deg, q.intensity, "k.-", lw=0.8, ms=2)
    ax.set_title(f"{lo:.1f}–{hi:.1f}°")
fig.tight_layout()
fig.savefig(".tmp/peak_zooms.png", dpi=180)
