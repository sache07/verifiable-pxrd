#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
INPUT = ROOT / ".tmp" / "atoms_ZnWO4_profile2.gpx"
FINAL = ROOT / "final.gpx"


def clean_model(gpx):
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for name in ("V", "Y", "Z"):
        inst[name][1] = 0.0
        inst[name][2] = False
    inst["SH/L"][1] = 0.002
    inst["SH/L"][2] = False

    sample = hist.data["Sample Parameters"]
    for name in ("DisplaceX", "DisplaceY", "Shift", "Transparency", "Absorption"):
        if isinstance(sample.get(name), list):
            sample[name][0] = 0.0
            sample[name][1] = False
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        if phase.name == "ZnWO4":
            hap["Size"][0] = "isotropic"
            hap["Size"][2] = [True, False, False]
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2] = [False, False, False]
            for atom in phase.atoms():
                atom.refinement_flags = "X"
        elif phase.name == "WO3":
            hap["Size"][1][0] = 10.0
            hap["Size"][2] = [False, False, False]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][2] = [True, False, False]
            for atom in phase.atoms():
                atom.refinement_flags = ""
        else:
            hap["Size"][1][0] = 10.0
            hap["Size"][2] = [False, False, False]
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2] = [False, False, False]
            for atom in phase.atoms():
                atom.refinement_flags = ""
    gpx.set_Controls("cycles", 12)
    gpx.set_Frozen()


gpx = G2sc.G2Project(str(INPUT), newgpx=str(FINAL))
clean_model(gpx)
gpx.save()

# Native full-range replay, with a fresh project load before every pass.
for replay in range(3):
    gpx = G2sc.G2Project(str(FINAL))
    clean_model(gpx)
    print(f"===== final fresh replay {replay + 1} =====")
    gpx.refine(makeBack=False)
    gpx.save()

gpx = G2sc.G2Project(str(FINAL))
hist = gpx.histogram(0)
cov = gpx.data["Covariance"]["data"]
rvals = cov["Rvals"]

cif_names = {"ZnWO4": "ZnWO4.cif", "ZnO": "ZnO.cif", "WO3": "WO3.cif"}
for phase in gpx.phases():
    phase.export_CIF(str(ROOT / cif_names[phase.name]))

data = hist.data["data"][1]
x, observed, weight, calculated, background = map(np.asarray, data[:5])
low, high = map(float, hist.data["Limits"][1])
first = max(0, int(np.searchsorted(x, low)) - 1)
last = int(np.searchsorted(x, high))
use = slice(first, last)
with (ROOT / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(["two_theta_deg", "observed", "calculated", "difference", "background"])
    for values in zip(x[use], observed[use], calculated[use],
                      observed[use] - calculated[use], background[use]):
        writer.writerow([f"{values[0]:.7f}", *(f"{value:.10g}" for value in values[1:])])

mass_fractions = hist.ComputeMassFracs()
phase_labels = {
    "ZnWO4": ("ZnWO4 (wolframite)", "ZnWO4", "P 2/c", 1520641),
    "ZnO": ("ZnO (wurtzite)", "ZnO", "P 63 m c", 9004178),
    "WO3": ("WO3 (room-temperature monoclinic)", "WO3", "P 21/c", 2311041),
}
phases = []
for phase in gpx.phases():
    label, formula, space_group, cod_id = phase_labels[phase.name]
    fraction, esd = mass_fractions[phase.name]
    phases.append({
        "name": label,
        "formula": formula,
        "space_group": space_group,
        "source_record": f"COD {cod_id}",
        "cif": cif_names[phase.name],
        "weight_fraction": float(fraction),
        "weight_fraction_esd_least_squares": float(esd),
    })

profile_stats = hist.data["data"][0]
result = {
    "phases": phases,
    "weight_fraction_basis": "normalized over the modeled crystalline phases; amorphous or unidentified material is not quantified",
    "fit_statistics": {
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": float(profile_stats["R"]),
        "background_subtracted_Rwp_percent": float(profile_stats["wRb"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "reduced_chi_squared": float(rvals["GOF"] ** 2),
        "durbin_watson": float(profile_stats["Durbin-Watson"]),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_variables": int(rvals["Nvars"]),
        "max_shift_over_esd_final_replay": float(rvals["Max shft/sig"]),
        "two_theta_range_deg": [low, high],
        "weighting": "Poisson; sigma = sqrt(observed counts)",
    },
    "profile": "fit.csv",
    "project": "final.gpx",
}
with (ROOT / "result.json").open("w") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

vary = [str(value) for value in cov.get("varyList", [])]
sig = np.asarray(cov.get("sig", []), dtype=float)
matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
correlations = []
if matrix.ndim == 2 and matrix.shape == (len(sig), len(sig)):
    denominator = np.outer(sig, sig)
    corr = np.divide(matrix, denominator, out=np.zeros_like(matrix), where=denominator != 0)
    for i in range(len(vary)):
        for j in range(i + 1, len(vary)):
            correlations.append([abs(float(corr[i, j])), float(corr[i, j]), vary[i], vary[j]])
    correlations.sort(reverse=True)

audit = {
    "Rvals": rvals,
    "frozen": gpx.get_Frozen(),
    "mass_fractions": mass_fractions,
    "instrument": hist.data["Instrument Parameters"][0],
    "sample": hist.data["Sample Parameters"],
    "top_correlations": correlations[:25],
    "cells": {phase.name: {"cell": phase.get_cell(), "esd": phase.get_cell_and_esd()[1]}
              for phase in gpx.phases()},
    "phase_profile": {phase.name: {
        "size": phase.getHAPvalues(hist)["Size"],
        "mustrain": phase.getHAPvalues(hist)["Mustrain"],
        "preferred_orientation": phase.getHAPvalues(hist)["Pref.Ori."],
    } for phase in gpx.phases()},
    "atoms": {phase.name: [{"label": atom.label, "xyz": list(atom.coordinates),
                              "flags": atom.refinement_flags}
                             for atom in phase.atoms()] for phase in gpx.phases()},
}
with (ROOT / ".tmp" / "final_audit.json").open("w") as stream:
    json.dump(audit, stream, indent=2,
              default=lambda value: value.tolist() if hasattr(value, "tolist") else str(value))
    stream.write("\n")

print("FINAL_RESULT", json.dumps(result))
