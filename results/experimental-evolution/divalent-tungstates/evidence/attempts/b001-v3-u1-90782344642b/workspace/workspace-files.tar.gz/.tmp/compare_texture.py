#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


CASES = {
    "none": ".tmp/sZnWO4_strain_WO3.gpx",
    "ZnWO4_100": ".tmp/texture_ZnWO4_100.gpx",
    "ZnWO4_010": ".tmp/texture_ZnWO4_010.gpx",
    "ZnWO4_001": ".tmp/texture_ZnWO4_001.gpx",
    "ZnO_100": ".tmp/texture_ZnO_100.gpx",
    "ZnO_001": ".tmp/texture_ZnO_001.gpx",
    "WO3_100": ".tmp/texture_WO3_100.gpx",
    "WO3_010": ".tmp/texture_WO3_010.gpx",
    "WO3_001": ".tmp/texture_WO3_001.gpx",
}

WINDOWS = {
    "ZnWO4": [(15.25, 15.80), (18.60, 19.20), (30.10, 30.90),
               (38.05, 38.55), (41.00, 41.55), (48.45, 48.90),
               (51.40, 52.00), (53.30, 53.80), (61.30, 61.90),
               (64.40, 64.90), (67.90, 68.40)],
    "ZnO": [(31.55, 32.00), (34.20, 34.70), (47.35, 47.85),
            (56.30, 56.85), (62.65, 63.15), (66.10, 66.55),
            (67.75, 68.20), (68.85, 69.35)],
    "WO3": [(22.85, 24.70), (26.30, 27.05), (28.25, 29.25),
            (32.75, 34.75), (41.65, 42.20), (46.95, 48.50),
            (49.65, 51.15), (53.20, 56.35)],
}


def wr(x, y, w, yc, windows):
    mask = np.zeros(x.shape, dtype=bool)
    for lo, hi in windows:
        mask |= (x >= lo) & (x <= hi)
    return 100.0 * np.sqrt(np.sum(w[mask] * (y[mask] - yc[mask]) ** 2)
                           / np.sum(w[mask] * y[mask] ** 2))


print("case,Rwp,ZnWO4_windows,ZnO_windows,WO3_windows,MD")
for case, filename in CASES.items():
    gpx = G2sc.G2Project(filename)
    hist = gpx.histogram(0)
    d = hist.data["data"][1]
    x, y, w, yc = map(np.asarray, d[:4])
    md = "-"
    if case != "none":
        phase_name = case.rsplit("_", 1)[0]
        po = gpx.phase(phase_name).getHAPvalues(hist)["Pref.Ori."]
        md = f"{po[1]:.7f}@{''.join(map(str, po[3]))}"
    vals = [wr(x, y, w, yc, WINDOWS[name]) for name in ("ZnWO4", "ZnO", "WO3")]
    print(f"{case},{hist.get_wR():.7f},{vals[0]:.7f},{vals[1]:.7f},{vals[2]:.7f},{md}")

print("\nindividual diagnostic windows")
for phase_name, selected in {
    "ZnWO4": ("none", "ZnWO4_100", "ZnWO4_010", "ZnWO4_001"),
    "ZnO": ("none", "ZnO_100", "ZnO_001"),
    "WO3": ("none", "WO3_100", "WO3_010", "WO3_001"),
}.items():
    print(phase_name)
    print("case," + ",".join(f"{lo:.2f}-{hi:.2f}" for lo, hi in WINDOWS[phase_name]))
    for case in selected:
        gpx = G2sc.G2Project(CASES[case])
        d = gpx.histogram(0).data["data"][1]
        x, y, w, yc = map(np.asarray, d[:4])
        vals = [wr(x, y, w, yc, [window]) for window in WINDOWS[phase_name]]
        print(case + "," + ",".join(f"{value:.5f}" for value in vals))
