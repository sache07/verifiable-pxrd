#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("branch", choices=[
    "replay", "shift", "U", "SHL", "polarization", "roughness", "background15",
    "size_ZnWO4", "size_ZnO", "size_WO3",
    "strain_ZnWO4", "strain_ZnO", "strain_WO3",
    "atoms_ZnWO4", "atoms_ZnO", "atom_ZnO_Oz",
    "texture_ZnWO4_100", "texture_ZnWO4_010", "texture_ZnWO4_001",
    "texture_ZnO_100", "texture_ZnO_001",
    "texture_WO3_100", "texture_WO3_010", "texture_WO3_001",
    "no_U", "no_polarization", "no_size_ZnWO4", "no_strain_WO3",
])
parser.add_argument("--cycles", type=int, default=12)
args = parser.parse_args()

gpx = G2sc.G2Project(args.input, newgpx=args.output)
hist = gpx.histogram(0)
gpx.set_Controls("cycles", args.cycles)
gpx.set_Frozen()

if args.branch == "shift":
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.data["Instrument Parameters"][0]["Zero"][1] = 0.0
    hist.data["Sample Parameters"]["Shift"] = [0.0, True]
elif args.branch == "U":
    hist.data["Instrument Parameters"][0]["U"][1] = 0.0
    hist.set_refinements({"Instrument Parameters": ["U"]})
elif args.branch == "SHL":
    hist.data["Instrument Parameters"][0]["SH/L"][1] = 0.002
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
elif args.branch == "polarization":
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
elif args.branch == "roughness":
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.9, True]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.01, True]
elif args.branch == "background15":
    hist.set_refinements({"Background": {"no. coeffs": 15, "refine": True}})
elif args.branch.startswith("size_"):
    name = args.branch.split("_", 1)[1]
    phase = gpx.phase(name)
    hap = phase.getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = {"ZnWO4": 0.08, "ZnO": 0.5, "WO3": 0.2}[name]
    hap["Size"][2] = [True, False, False]
elif args.branch.startswith("strain_"):
    name = args.branch.split("_", 1)[1]
    phase = gpx.phase(name)
    hap = phase.getHAPvalues(hist)
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 500.0
    hap["Mustrain"][2] = [True, False, False]
elif args.branch == "atoms_ZnWO4":
    gpx.phase("ZnWO4").set_refinements({"Atoms": {"all": "X"}})
elif args.branch == "atoms_ZnO":
    gpx.phase("ZnO").set_refinements({"Atoms": {"all": "X"}})
elif args.branch == "atom_ZnO_Oz":
    for atom in gpx.phase("ZnO").atoms():
        atom.refinement_flags = "X" if atom.element == "O" else ""
elif args.branch.startswith("texture_"):
    _, name, axis_text = args.branch.split("_")
    axis = [int(v) for v in axis_text]
    hap = gpx.phase(name).getHAPvalues(hist)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = axis
elif args.branch == "no_U":
    hist.data["Instrument Parameters"][0]["U"][1:] = [0.0, False]
elif args.branch == "no_polarization":
    hist.data["Instrument Parameters"][0]["Polariz."][1:] = [0.7, False]
elif args.branch == "no_size_ZnWO4":
    hap = gpx.phase("ZnWO4").getHAPvalues(hist)
    hap["Size"][1][0] = 10.0
    hap["Size"][2][0] = False
elif args.branch == "no_strain_WO3":
    hap = gpx.phase("WO3").getHAPvalues(hist)
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2][0] = False

gpx.save()
for i in range(2):
    print(f"===== {args.branch} replay {i + 1} =====")
    gpx.refine(makeBack=False)

cov = gpx.data.get("Covariance", {}).get("data", {})
vary = [str(v) for v in cov.get("varyList", [])]
sig = np.asarray(cov.get("sig", []), dtype=float)
matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
correlations = []
if matrix.ndim == 2 and len(sig) == len(vary):
    denom = np.outer(sig, sig)
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom != 0)
    for i in range(len(vary)):
        for j in range(i + 1, len(vary)):
            correlations.append((abs(float(corr[i, j])), float(corr[i, j]), vary[i], vary[j]))
    correlations.sort(reverse=True)

out = {
    "branch": args.branch,
    "wR_percent": hist.get_wR(),
    "Rvals": cov.get("Rvals", {}),
    "frozen": gpx.get_Frozen(),
    "mass_fractions": hist.ComputeMassFracs(),
    "instrument": hist.data["Instrument Parameters"][0],
    "sample": hist.data["Sample Parameters"],
    "background_coeff_count": hist.data["Background"][0][2],
    "top_correlations": correlations[:15],
    "phases": {},
}
for phase in gpx.phases():
    hap = phase.getHAPvalues(hist)
    out["phases"][phase.name] = {
        "cell": phase.get_cell(), "size": hap["Size"], "mustrain": hap["Mustrain"],
        "pref_ori": hap["Pref.Ori."],
        "atoms": [{"label": a.label, "xyz": list(a.coordinates),
                   "refine": a.refinement_flags} for a in phase.atoms()],
    }
gpx.save()
print("BRANCH_RESULT", json.dumps(out, default=lambda obj: obj.tolist() if hasattr(obj, "tolist") else str(obj)))
