#!/usr/bin/env python3
from GSASII import GSASIIscriptable as G2sc

for label, filename in {
    "full": ".tmp/atoms_ZnWO4_profile2.gpx",
    "no_U": ".tmp/prune_no_U.gpx",
    "no_polarization": ".tmp/prune_no_polarization.gpx",
    "no_ZnWO4_size": ".tmp/prune_no_size_ZnWO4.gpx",
    "no_WO3_strain": ".tmp/prune_no_strain_WO3.gpx",
}.items():
    gpx = G2sc.G2Project(filename)
    hist = gpx.histogram(0)
    rv = gpx.data["Covariance"]["data"]["Rvals"]
    print(label, f"Rwp={hist.get_wR():.7f}", f"GOF={rv['GOF']:.7f}",
          f"max_shift_esd={rv['Max shft/sig']:.4f}")
