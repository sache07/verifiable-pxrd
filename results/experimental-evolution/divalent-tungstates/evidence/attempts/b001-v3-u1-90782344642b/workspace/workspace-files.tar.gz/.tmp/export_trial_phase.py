#!/usr/bin/env python3
from GSASII import GSASIIscriptable as G2sc

gpx = G2sc.G2Project(".tmp/atoms_ZnWO4_profile2.gpx")
gpx.phase("ZnWO4").export_CIF(".tmp/ZnWO4_atoms_trial.cif")

gpx = G2sc.G2Project(".tmp/final_candidate_ZnO_Oz.gpx")
gpx.phase("ZnO").export_CIF(".tmp/ZnO_Oz_trial.cif")
