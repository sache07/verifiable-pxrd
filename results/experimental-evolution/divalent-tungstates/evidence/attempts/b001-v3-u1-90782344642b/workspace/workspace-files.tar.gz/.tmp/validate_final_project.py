#!/usr/bin/env python3
from __future__ import annotations

import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc


gpx = G2sc.G2Project("final.gpx")
hist = gpx.histogram(0)
result = json.load(open("result.json"))
fractions = hist.ComputeMassFracs()
assert abs(sum(value[0] for value in fractions.values()) - 1.0) < 1e-12
for item in result["phases"]:
    key = item["formula"]
    assert abs(item["weight_fraction"] - fractions[key][0]) < 1e-12

profile = np.genfromtxt("fit.csv", delimiter=",", names=True)
d = hist.data["data"][1]
x, observed, _, calculated, background = map(np.asarray, d[:5])
lo, hi = hist.data["Limits"][1]
first = max(0, int(np.searchsorted(x, lo)) - 1)
last = int(np.searchsorted(x, hi))
use = slice(first, last)
checks = {
    "two_theta": np.max(np.abs(profile["two_theta_deg"] - x[use])),
    "observed": np.max(np.abs(profile["observed"] - observed[use])),
    "calculated": np.max(np.abs(profile["calculated"] - calculated[use])),
    "difference": np.max(np.abs(profile["difference"] - (observed[use] - calculated[use]))),
    "background": np.max(np.abs(profile["background"] - background[use])),
}
assert len(profile) == int(result["fit_statistics"]["n_observations"])
assert checks["two_theta"] < 5e-8 and max(checks.values()) < 1e-5

cov = gpx.data["Covariance"]["data"]
rv = cov["Rvals"]
assert rv["SVD0"] == 0 and not gpx.get_Frozen()
assert abs(hist.get_wR() - result["fit_statistics"]["Rwp_percent"]) < 1e-12

inst = hist.data["Instrument Parameters"][0]
print("profile_max_absolute_export_differences", checks)
print("fractions", fractions)
print("Rwp GOF max_shift SVD0 frozen", hist.get_wR(), rv["GOF"],
      rv["Max shft/sig"], rv["SVD0"], gpx.get_Frozen())
print("instrument", {name: inst[name][1] for name in
                     ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")})
for phase in gpx.phases():
    hap = phase.getHAPvalues(hist)
    print(phase.name, "cell", phase.get_cell(), "cell_esd", phase.get_cell_and_esd()[1],
          "size", hap["Size"][1][0], hap["Size"][2][0],
          "mustrain", hap["Mustrain"][1][0], hap["Mustrain"][2][0],
          "texture", hap["Pref.Ori."][:4])

vary = [str(value) for value in cov["varyList"]]
sig = np.asarray(cov["sig"], dtype=float)
matrix = np.asarray(cov["covMatrix"], dtype=float)
corr = matrix / np.outer(sig, sig)
pairs = []
for i in range(len(vary)):
    for j in range(i + 1, len(vary)):
        pairs.append((abs(corr[i, j]), corr[i, j], vary[i], vary[j]))
for pair in sorted(pairs, reverse=True)[:10]:
    print("correlation", *(float(value) if index < 2 else value for index, value in enumerate(pair)))
