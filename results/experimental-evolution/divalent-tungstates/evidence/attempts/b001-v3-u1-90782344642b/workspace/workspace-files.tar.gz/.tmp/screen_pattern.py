#!/usr/bin/env python3
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter1d, percentile_filter
from scipy.signal import find_peaks, peak_widths


data = pd.read_csv("inputs/pattern.csv")
x = data["two_theta_deg"].to_numpy()
y = data["intensity"].to_numpy(dtype=float)
dx = float(np.median(np.diff(x)))

# A broad low-percentile envelope is used only for peak finding, not refinement.
baseline = percentile_filter(y, percentile=20, size=301, mode="nearest")
signal = gaussian_filter1d(y - baseline, 1.0)
peaks, props = find_peaks(signal, prominence=45, distance=max(2, round(0.05 / dx)))
widths = peak_widths(signal, peaks, rel_height=0.5)[0] * dx

order = np.argsort(props["prominences"])[::-1]
print(f"step={dx:.8f} deg; peaks={len(peaks)}")
print("two_theta,intensity,prominence,fwhm_deg")
for j in order[:120]:
    i = peaks[j]
    print(f"{x[i]:.5f},{y[i]:.1f},{props['prominences'][j]:.1f},{widths[j]:.4f}")

fig, ax = plt.subplots(figsize=(15, 6))
ax.plot(x, y, color="black", lw=0.55)
ax.plot(x, baseline, color="tab:orange", lw=0.8)
ax.set(xlabel=r"$2\theta$ (deg)", ylabel="counts", xlim=(x[0], x[-1]))
fig.tight_layout()
fig.savefig(".tmp/pattern_overview.png", dpi=180)
