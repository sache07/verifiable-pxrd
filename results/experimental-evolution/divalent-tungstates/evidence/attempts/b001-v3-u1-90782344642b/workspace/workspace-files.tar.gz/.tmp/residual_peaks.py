#!/usr/bin/env python3
from __future__ import annotations

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks, peak_widths
from GSASII import GSASIIscriptable as G2sc


gpx = G2sc.G2Project("final.gpx")
hist = gpx.histogram(0)
d = hist.data["data"][1]
x, observed, weight, calculated = map(np.asarray, d[:4])
use = (x >= 10.15) & (x <= 99.85)
z = (observed - calculated) * np.sqrt(weight)
smooth = gaussian_filter1d(z, 3.0)
peaks, props = find_peaks(smooth, height=1.0, prominence=0.7, distance=5)
peaks = peaks[use[peaks]]
order = peaks[np.argsort(smooth[peaks])[::-1]]

reflections = []
for name, phase_data in hist.data["Reflection Lists"].items():
    for row in phase_data["RefList"]:
        if row[9] >= 5.0:
            reflections.append((float(row[5]), name, tuple(int(v) for v in row[:3]), float(row[9])))

print("two_theta,smoothed_standardized_residual,raw_difference,nearest_significant_reflection,delta")
for index in order[:30]:
    nearest = min(reflections, key=lambda item: abs(item[0] - x[index]))
    print(f"{x[index]:.5f},{smooth[index]:.3f},{observed[index]-calculated[index]:.1f},"
          f"{nearest[1]}{nearest[2]}@{nearest[0]:.5f},{x[index]-nearest[0]:+.5f}")

unmatched = []
for index in order:
    nearest = min(reflections, key=lambda item: abs(item[0] - x[index]))
    if abs(x[index] - nearest[0]) > 0.15 and smooth[index] > 1.5:
        unmatched.append((float(x[index]), float(smooth[index]), float(x[index] - nearest[0])))
print("unmatched_gt_0.15deg_and_height_gt_1.5", unmatched)
