#!/usr/bin/env python3
"""Challenge the final inventory with source-cell CaO and scale only for CaO."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc

from model_trials import CIF_ROOT, covariance_summary, neutralize_hap, profile_summary


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/polarization.gpx"
OUTPUT = ROOT / ".tmp/cao_fixed_challenge.gpx"


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    hist = project.histogram(0)
    cao = project.add_phase(
        str(CIF_ROOT / "1/56/31/1563196.cif"),
        phasename="CaO_fixed_source_cell_COD1563196",
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize_hap(cao, hist, 0.1)
    cao.set_refinements({"Cell": False})
    project.set_Controls("parmMin", 0.0, variable=f"{cao.id}:0:Scale")
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.save()
    project.refine(printFile=str(OUTPUT.with_suffix(".lst")), makeBack=False)
    project.refine(printFile=str(OUTPUT.with_suffix(".lst")), makeBack=False)
    project.save()
    print(json.dumps({
        "residuals": hist.residuals,
        "profile": profile_summary(hist),
        "mass_fractions": hist.ComputeMassFracs(),
        "scales": {p.name: p.getHAPvalues(hist)["Scale"] for p in project.phases()},
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "frozen": project.get_Frozen(),
        "covariance": covariance_summary(project),
    }, indent=2, default=str))


if __name__ == "__main__":
    main()
