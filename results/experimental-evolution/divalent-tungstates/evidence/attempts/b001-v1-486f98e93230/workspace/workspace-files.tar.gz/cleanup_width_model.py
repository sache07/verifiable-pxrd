#!/usr/bin/env python3
"""Remove the unsupported global Y term and reconverge the selected width model."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc

from model_trials import covariance_summary, profile_summary


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/broad_p0size_p2_strain.gpx"
OUTPUT = ROOT / ".tmp/width_clean.gpx"


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Y"]})
    hist.InstrumentParameters["Y"][0:2] = [0.0, 0.0]
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.save()
    project.refine(printFile=str(OUTPUT.with_suffix(".lst")), makeBack=False)
    project.save()
    result = {
        "residuals": hist.residuals,
        "profile": profile_summary(hist),
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "hap": {p.name: p.getHAPvalues(hist) for p in project.phases()},
        "covariance": covariance_summary(project),
    }
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
