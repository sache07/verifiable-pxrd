#!/usr/bin/env python3
"""Run chemically screened GSAS-II candidate comparisons with one nuisance model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path(
    "<RUN>/"
    "resources/b001-c05/cif"
)


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def initialize_background(hist, ncoeff: int = 10) -> None:
    x = np.asarray(hist.getdata("X"), dtype=float)
    y = np.asarray(hist.getdata("Yobs"), dtype=float)
    step = float(np.median(np.diff(x)))
    # A robust local lower envelope is used only to seed the polynomial.
    window = max(51, int(round(2.2 / step)) | 1)
    baseline = percentile_filter(y, percentile=15, size=window, mode="nearest")
    baseline = gaussian_filter1d(baseline, sigma=max(3.0, 0.35 / step))
    xpos = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    coeff = np.polynomial.chebyshev.chebfit(xpos, baseline, ncoeff - 1)
    hist.data["Background"][0] = [
        "chebyschev-1",
        True,
        ncoeff,
        *[float(v) for v in coeff],
    ]


def neutralize_hap(phase, hist, scale: float) -> None:
    hap = phase.getHAPvalues(hist)
    hap["Scale"] = [float(scale), True]
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1.0e6, 1.0e6, 0.5]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][4][:] = [1.0e6, 1.0e6, 1.0e6, 0.0, 0.0, 0.0]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def covariance_summary(project) -> dict:
    cov = project.data.get("Covariance", {}).get("data", {})
    names = [str(v) for v in cov.get("varyList", [])]
    matrix = cov.get("covMatrix")
    result = {"n_variables": len(names), "largest_correlations": []}
    if matrix is None or len(names) < 2:
        return result
    matrix = np.asarray(matrix, dtype=float)
    sigma = np.sqrt(np.clip(np.diag(matrix), 0.0, None))
    denom = np.outer(sigma, sigma)
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
    rows = []
    for i in range(len(names)):
        for j in range(i):
            rows.append((abs(float(corr[i, j])), float(corr[i, j]), names[j], names[i]))
    rows.sort(reverse=True)
    result["largest_correlations"] = [
        {"abs": a, "value": v, "left": left, "right": right}
        for a, v, left, right in rows[:12]
    ]
    return result


def profile_summary(hist) -> dict:
    inst = hist.InstrumentParameters
    vals = {key: float(inst[key][1]) for key in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]}
    theta = np.linspace(5.0, 50.0, 901)
    tan = np.tan(np.deg2rad(theta))
    gaussian_var = vals["U"] * tan**2 + vals["V"] * tan + vals["W"]
    lorentz = vals["Z"] + vals["X"] / np.cos(np.deg2rad(theta)) + vals["Y"] * tan
    vals["gaussian_variance_min"] = float(gaussian_var.min())
    vals["lorentz_width_min"] = float(lorentz.min())
    return vals


def stage(project, label: str, log_path: Path) -> dict:
    project.save()
    project.refine(printFile=str(log_path), makeBack=False)
    hist = project.histogram(0)
    residuals = {}
    for key, value in hist.residuals.items():
        try:
            residuals[key] = float(value)
        except (TypeError, ValueError):
            residuals[key] = str(value)
    record = {
        "stage": label,
        "residuals": residuals,
        "profile": profile_summary(hist),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "scales": {
            phase.name: float(phase.getHAPvalues(hist)["Scale"][0])
            for phase in project.phases()
        },
        "covariance": covariance_summary(project),
    }
    try:
        record["mass_fractions"] = {
            key: [float(v[0]), float(v[1])] for key, v in hist.ComputeMassFracs().items()
        }
    except Exception as exc:  # diagnostic only during early stages
        record["mass_fraction_error"] = repr(exc)
    print(json.dumps(record, indent=2))
    return record


def build_trial(wo3_id: str, output: Path) -> list[dict]:
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "cu_ka.instprm"),
        fmthint="comma",
    )
    hist.data["Limits"][1][:] = [10.0, 100.0]
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    initialize_background(hist, ncoeff=10)

    inst = hist.InstrumentParameters
    initial_profile = {
        "Zero": -0.160,
        "U": 20.0,
        "V": 0.0,
        "W": 180.0,
        "X": 0.0,
        "Y": 3.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }
    for key, value in initial_profile.items():
        inst[key][0] = float(value)
        inst[key][1] = float(value)
        inst[key][2] = False

    ca = project.add_phase(
        str(cif_path("7219229")),
        phasename="CaWO4_scheelite",
        histograms=[hist],
        fmthint="CIF",
    )
    wo = project.add_phase(
        str(cif_path(wo3_id)),
        phasename=f"WO3_{wo3_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize_hap(ca, hist, 1.0)
    neutralize_hap(wo, hist, 0.2)
    ca.data["General"]["Cell"][0] = False
    wo.data["General"]["Cell"][0] = False

    project.set_Controls("cycles", 8)
    for var in [":0:U", ":0:W", ":0:X", ":0:Y", ":0:Z"]:
        project.set_Controls("parmMin", 0.0, variable=var)
    project.set_Controls("parmMin", -0.5, variable=":0:Zero")
    project.set_Controls("parmMax", 0.2, variable=":0:Zero")
    for phase in project.phases():
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")

    records = []
    log = output.with_suffix(".lst")
    records.append(stage(project, "background_scales", log))

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    records.append(stage(project, "plus_zero", log))

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    records.append(stage(project, "plus_cells", log))

    hist.set_refinements({"Instrument Parameters": ["W"]})
    records.append(stage(project, "plus_W", log))

    hist.set_refinements({"Instrument Parameters": ["U"]})
    records.append(stage(project, "plus_U", log))

    hist.set_refinements({"Instrument Parameters": ["Y"]})
    records.append(stage(project, "plus_Y", log))

    # U is retained only if supported away from its physical zero bound.
    if hist.InstrumentParameters["U"][1] <= 1.0e-6:
        hist.clear_refinements({"Instrument Parameters": ["U"]})
        hist.InstrumentParameters["U"][0:2] = [0.0, 0.0]
        project.set_Frozen()
        records.append(stage(project, "fixed_unsupported_U", log))

    project.save()
    return records


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_id")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    records = build_trial(args.wo3_id, args.output.resolve())
    args.output.with_suffix(".json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
