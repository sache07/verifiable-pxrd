#!/usr/bin/env python3
"""Independent pymatgen geometry audit for the final exported CIF files."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path(__file__).resolve().parent


def coordination_summary(structure: Structure, element: str, oxygen_count: int) -> dict:
    records = []
    for site in structure:
        if site.specie.symbol != element:
            continue
        distances = sorted(
            float(neighbor.nn_distance)
            for neighbor in structure.get_neighbors(site, 3.2)
            if neighbor.specie.symbol == "O"
        )[:oxygen_count]
        records.append(distances)
    flat = [distance for distances in records for distance in distances]
    return {
        "sites": len(records),
        "neighbors_per_site_requested": oxygen_count,
        "minimum_angstrom": min(flat),
        "maximum_angstrom": max(flat),
        "mean_angstrom": float(np.mean(flat)),
    }


def main() -> None:
    result = json.loads((ROOT / "result.json").read_text())
    audits = []
    for phase in result["phases"]:
        structure = Structure.from_file(ROOT / phase["cif_path"])
        distances = np.asarray(structure.distance_matrix, dtype=float)
        np.fill_diagonal(distances, np.inf)
        expected = phase["formula"]
        audit = {
            "file": phase["cif_path"],
            "composition": structure.composition.reduced_formula,
            "expected_formula": expected,
            "space_group": SpacegroupAnalyzer(structure, symprec=1.0e-3).get_space_group_symbol(),
            "n_sites": len(structure),
            "minimum_interatomic_distance_angstrom": float(distances.min()),
            "all_sites_fully_occupied": all(abs(site.species.num_atoms - 1.0) < 1.0e-8 for site in structure),
        }
        if expected == "CaWO4":
            audit["W_O"] = coordination_summary(structure, "W", 4)
            audit["Ca_O"] = coordination_summary(structure, "Ca", 8)
        elif expected == "WO3":
            audit["W_O"] = coordination_summary(structure, "W", 6)
        elif expected == "Ca3WO6":
            audit["W_O"] = coordination_summary(structure, "W", 6)
            audit["Ca_O"] = coordination_summary(structure, "Ca", 8)
        audits.append(audit)
    print(json.dumps(audits, indent=2))


if __name__ == "__main__":
    main()
