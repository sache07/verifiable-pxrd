#!/usr/bin/env python3
"""Test the global Finger-Cox-Jephcoat axial-divergence term."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc

from model_trials import covariance_summary, profile_summary


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/polarization.gpx"
OUTPUT = ROOT / ".tmp/asymmetry.gpx"


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    project.set_Controls("parmMin", 0.002, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.1, variable=":0:SH/L")
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.save()
    project.refine(printFile=str(OUTPUT.with_suffix(".lst")), makeBack=False)
    project.refine(printFile=str(OUTPUT.with_suffix(".lst")), makeBack=False)
    project.save()
    result = {
        "residuals": hist.residuals,
        "instrument": hist.InstrumentParameters,
        "profile": profile_summary(hist),
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "covariance": covariance_summary(project),
    }
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
