#!/usr/bin/env python3
"""Compare one-parameter March-Dollase models for the scheelite phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from model_trials import covariance_summary, profile_summary


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp/width_clean2.gpx"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("axis", nargs=3, type=int)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    project = G2sc.G2Project(str(BASE), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    phase = project.phase(0)
    po = phase.getHAPvalues(hist)["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(args.axis)
    project.set_Controls("parmMin", 0.4, variable=f"{phase.id}:0:MD")
    project.set_Controls("parmMax", 2.5, variable=f"{phase.id}:0:MD")
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.save()
    project.refine(printFile=str(args.output.with_suffix(".lst").resolve()), makeBack=False)
    project.refine(printFile=str(args.output.with_suffix(".lst").resolve()), makeBack=False)
    project.save()
    result = {
        "axis": args.axis,
        "residuals": hist.residuals,
        "profile": profile_summary(hist),
        "mass_fractions": hist.ComputeMassFracs(),
        "po": {p.name: p.getHAPvalues(hist)["Pref.Ori."] for p in project.phases()},
        "frozen": project.get_Frozen(),
        "covariance": covariance_summary(project),
    }
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
