#!/usr/bin/env python3
"""Challenge the converged inventory with a chemically plausible CaO phase."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc

from model_trials import CIF_ROOT, covariance_summary, neutralize_hap, profile_summary


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/polarization.gpx"
OUTPUT = ROOT / ".tmp/cao_challenge.gpx"


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    hist = project.histogram(0)
    cao = project.add_phase(
        str(CIF_ROOT / "1/56/31/1563196.cif"),
        phasename="CaO_challenge_COD1563196",
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize_hap(cao, hist, 0.1)
    cao.set_refinements({"Cell": True})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
        phase.set_refinements({"Cell": True})
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.save()
    project.refine(printFile=str(OUTPUT.with_suffix(".lst")), makeBack=False)
    project.refine(printFile=str(OUTPUT.with_suffix(".lst")), makeBack=False)
    project.save()
    result = {
        "residuals": hist.residuals,
        "profile": profile_summary(hist),
        "mass_fractions": hist.ComputeMassFracs(),
        "scales": {p.name: p.getHAPvalues(hist)["Scale"] for p in project.phases()},
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "frozen": project.get_Frozen(),
        "covariance": covariance_summary(project),
    }
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
