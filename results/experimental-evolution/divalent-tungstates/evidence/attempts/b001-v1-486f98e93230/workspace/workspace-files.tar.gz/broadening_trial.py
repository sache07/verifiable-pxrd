#!/usr/bin/env python3
"""Test one phase-specific isotropic broadening term from a common base fit."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from model_trials import covariance_summary, profile_summary


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp/trial_three.gpx"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", type=int)
    parser.add_argument("mode", choices=["size", "strain"])
    parser.add_argument("output", type=Path)
    parser.add_argument("--base", type=Path, default=BASE)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.base.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.getHAPvalues(hist)
    if args.mode == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
        var = f"{phase.id}:0:Size;i"
        project.set_Controls("parmMin", 0.01, variable=var)
        project.set_Controls("parmMax", 10.0, variable=var)
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 300.0
        hap["Mustrain"][2][0] = True
        var = f"{phase.id}:0:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable=var)
        project.set_Controls("parmMax", 10000.0, variable=var)

    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.save()
    project.refine(printFile=str(args.output.with_suffix(".lst").resolve()), makeBack=False)
    project.save()
    result = {
        "phase": phase.name,
        "mode": args.mode,
        "residuals": hist.residuals,
        "profile": profile_summary(hist),
        "mass_fractions": hist.ComputeMassFracs(),
        "hap": {p.name: p.getHAPvalues(hist) for p in project.phases()},
        "frozen": project.get_Frozen(),
        "covariance": covariance_summary(project),
    }
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
