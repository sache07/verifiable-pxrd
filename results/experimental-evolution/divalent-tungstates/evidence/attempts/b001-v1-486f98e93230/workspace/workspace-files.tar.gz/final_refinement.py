#!/usr/bin/env python3
"""Create and audit the final three-phase GSAS-II refinement deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from model_trials import covariance_summary, profile_summary


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/polarization.gpx"
FINAL = ROOT / "final.gpx"
LOG = ROOT / "final.lst"

PHASE_INFO = {
    "CaWO4_scheelite": {
        "display_name": "CaWO4 (scheelite)",
        "formula": "CaWO4",
        "cif": "CaWO4.cif",
        "source": "COD 7219229",
        "model_basis": "exact-composition ambient scheelite record",
    },
    "WO3_2311041": {
        "display_name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif": "WO3.cif",
        "source": "COD 2311041",
        "model_basis": "exact-composition ambient monoclinic record",
    },
    "Ca3WO6_P21n_adapted_from_Ca3OsO6_COD1562666": {
        "display_name": "Ca3WO6 (double perovskite)",
        "formula": "Ca3WO6",
        "cif": "Ca3WO6.cif",
        "source": "Ca3OsO6 prototype, COD 1562666",
        "model_basis": "isovalent Os6+ to W6+ prototype substitution; parent coordinates retained",
    },
}


def configure_final_model(project: G2sc.G2Project) -> None:
    """Make the selected low-dimensional model and all flags explicit."""
    hist = project.histogram(0)
    original_limits = hist.data["Limits"][0]
    hist.data["Limits"][1][:] = [float(original_limits[0]), float(original_limits[1])]

    hist.data["Background"][0][1] = True
    instrument = hist.InstrumentParameters
    active_instrument = {"Zero", "W", "Polariz."}
    for key, values in instrument.items():
        if isinstance(values, list) and len(values) >= 3 and isinstance(values[2], bool):
            values[2] = key in active_instrument
    for key in ("U", "V", "X", "Y", "Z"):
        instrument[key][0:2] = [0.0, 0.0]
        instrument[key][2] = False
    instrument["SH/L"][0:2] = [0.002, 0.002]
    instrument["SH/L"][2] = False

    for key, values in hist.SampleParameters.items():
        if isinstance(values, list) and len(values) == 2 and isinstance(values[1], bool):
            values[1] = False
    hist.SampleParameters["Shift"][0] = 0.0
    hist.SampleParameters["Transparency"][0] = 0.0
    hist.SampleParameters["Scale"][0] = 1.0

    phases = project.phases()
    if [p.name for p in phases] != list(PHASE_INFO):
        raise RuntimeError("Unexpected phase inventory in source project")

    for phase in phases:
        phase.set_refinements({"Cell": True, "Atoms": {"all": " "}, "LeBail": False})
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = False
        hap["Size"][2][:] = [False] * len(hap["Size"][2])
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2][:] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][1] = False
        hap["Babinet"]["BabA"][1] = False
        hap["Babinet"]["BabU"][1] = False

    ca_hap = phases[0].getHAPvalues(hist)
    ca_hap["Pref.Ori."][0:4] = ["MD", ca_hap["Pref.Ori."][1], True, [0, 0, 1]]
    ca_hap["Size"][0] = "isotropic"
    ca_hap["Size"][2][0] = True

    ca3_hap = phases[2].getHAPvalues(hist)
    ca3_hap["Mustrain"][0] = "isotropic"
    ca3_hap["Mustrain"][2][0] = True

    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.set_Controls("parmMin", -0.5, variable=":0:Zero")
    project.set_Controls("parmMax", 0.2, variable=":0:Zero")
    project.set_Controls("parmMin", 0.0, variable=":0:W")
    project.set_Controls("parmMin", 0.4, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    for phase in phases:
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
    project.set_Controls("parmMin", 0.001, variable="0:0:Size;i")
    project.set_Controls("parmMax", 1000.0, variable="0:0:Size;i")
    project.set_Controls("parmMin", 0.4, variable="0:0:MD")
    project.set_Controls("parmMax", 2.5, variable="0:0:MD")
    project.set_Controls("parmMin", 0.0, variable="2:0:Mustrain;i")
    project.set_Controls("parmMax", 100000.0, variable="2:0:Mustrain;i")


def refine_to_replayable(project: G2sc.G2Project) -> list[dict]:
    history = []
    for cycle in range(1, 7):
        project.save()
        project.refine(printFile=str(LOG), makeBack=False)
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        record = {
            "pass": cycle,
            "r_wp_percent": float(rvals.get("Rwp", np.nan)),
            "goodness_of_fit": float(rvals.get("GOF", np.nan)),
            "max_shift_over_esd": float(rvals.get("Max shft/sig", np.nan)),
            "relative_delta_chi_squared": float(rvals.get("DelChi2", np.nan)),
        }
        history.append(record)
        if (
            cycle >= 2
            and abs(record["max_shift_over_esd"]) < 0.05
            and abs(record["relative_delta_chi_squared"]) < 1.0e-5
        ):
            break
    project.save()
    return history


def phase_flag_audit(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    result = {}
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        result[phase.name] = {
            "scale": hap["Scale"],
            "preferred_orientation": hap["Pref.Ori."],
            "size": hap["Size"],
            "microstrain": hap["Mustrain"],
            "hydrostatic_strain": hap["HStrain"],
            "extinction": hap["Extinction"],
            "babinet": hap["Babinet"],
        }
    return result


def export_from_reopened_project(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    if project.get_Frozen():
        raise RuntimeError(f"Final project contains frozen variables: {project.get_Frozen()}")

    profile = profile_summary(hist)
    if profile["gaussian_variance_min"] < 0 or profile["lorentz_width_min"] < 0:
        raise RuntimeError(f"Nonphysical global profile: {profile}")

    x = np.asarray(np.ma.filled(hist.getdata("X"), np.nan), dtype=float)
    yobs = np.asarray(np.ma.filled(hist.getdata("Yobs"), np.nan), dtype=float)
    ycalc = np.asarray(np.ma.filled(hist.getdata("Ycalc"), np.nan), dtype=float)
    diff = np.asarray(np.ma.filled(hist.getdata("Residual"), np.nan), dtype=float)
    if not (np.all(np.isfinite(x)) and np.all(np.isfinite(yobs)) and np.all(np.isfinite(ycalc))):
        raise RuntimeError("Non-finite values in final profile")
    if not np.allclose(diff, yobs - ycalc, rtol=0.0, atol=1.0e-8):
        raise RuntimeError("Stored final difference is inconsistent with observed-calculated")

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
        writer.writerows(zip(x, yobs, ycalc, diff))

    mass_fractions = hist.ComputeMassFracs()
    total = sum(value[0] for value in mass_fractions.values())
    if total <= 0:
        raise RuntimeError("Final mass-fraction sum is not positive")

    residuals = hist.residuals
    phases_json = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        phase.export_CIF(str(ROOT / info["cif"]), quickmode=True)
        fraction, fraction_esd = mass_fractions[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        phases_json.append({
            "name": info["display_name"],
            "formula": info["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": info["cif"],
            "weight_fraction": float(fraction / total),
            "weight_fraction_esd": float(fraction_esd / total),
            "source": info["source"],
            "model_basis": info["model_basis"],
            "cell": {key: float(value) for key, value in cell.items()},
            "cell_esd": {key: float(value) for key, value in cell_esd.items()},
            "phase_fit_statistics": {
                "r_f_percent": float(residuals[f"{phase.id}:0:Rf"]),
                "r_f_squared_percent": float(residuals[f"{phase.id}:0:Rf^2"]),
                "n_reflections": int(residuals[f"{phase.id}:0:Nref"]),
            },
        })

    rvals = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "phases": phases_json,
        "weight_fraction_basis": "normalized over the three modeled crystalline phases",
        "weight_fraction_sum": float(sum(p["weight_fraction"] for p in phases_json)),
        "fit_statistics": {
            "r_wp_percent": float(residuals["wR"]),
            "r_p_percent": float(residuals["R"]),
            "weighted_bragg_r_percent": float(residuals["wRb"]),
            "bragg_r_percent": float(residuals["Rb"]),
            "expected_r_wp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_variables": int(rvals["Nvars"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
        },
        "profile_csv": "fit.csv",
        "gsas_project": "final.gpx",
        "difference_convention": "observed - calculated",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    return {
        "result": result,
        "profile": profile,
        "instrument": hist.InstrumentParameters,
        "hap_audit": phase_flag_audit(project),
        "frozen": project.get_Frozen(),
        "covariance": covariance_summary(project),
        "profile_rows": len(x),
    }


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    configure_final_model(project)
    convergence = refine_to_replayable(project)

    # All requested numerical products are generated from a fresh read of final.gpx.
    final_project = G2sc.G2Project(str(FINAL))
    audit = export_from_reopened_project(final_project)
    audit["convergence"] = convergence
    print(json.dumps(audit, indent=2, default=str))


if __name__ == "__main__":
    main()
