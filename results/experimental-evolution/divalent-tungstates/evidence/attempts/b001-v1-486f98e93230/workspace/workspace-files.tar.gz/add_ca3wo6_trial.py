#!/usr/bin/env python3
"""Add an isovalently adapted Ca3WO6 prototype to the converged two-phase fit."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc

from model_trials import CIF_ROOT, covariance_summary, neutralize_hap, profile_summary


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/trial_2311041_v2.gpx"
OUTPUT = ROOT / ".tmp/trial_three.gpx"


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    hist = project.histogram(0)
    parent = CIF_ROOT / "1/56/26/1562666.cif"
    phase = project.add_phase(
        str(parent),
        phasename="Ca3WO6_P21n_adapted_from_Ca3OsO6_COD1562666",
        histograms=[hist],
        fmthint="CIF",
    )
    for atom in phase.atoms():
        if atom.element == "Os":
            atom.type = "W"
            atom.label = atom.label.replace("Os", "W")
    G2sc.SetupGeneral(phase.data, None)
    neutralize_hap(phase, hist, 0.5)
    phase.data["General"]["Cell"][0] = True

    for item in project.phases():
        item.set_HAP_refinements({"Scale": True}, histograms=[hist])
        item.set_refinements({"Cell": True})
        project.set_Controls("parmMin", 0.0, variable=f"{item.id}:0:Scale")
    hist.set_refinements({"Background": True})
    hist.set_refinements({"Instrument Parameters": ["Zero", "W", "Y"]})
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.save()
    project.refine(printFile=str(OUTPUT.with_suffix(".lst")), makeBack=False)
    project.save()

    result = {
        "residuals": hist.residuals,
        "profile": profile_summary(hist),
        "frozen": project.get_Frozen(),
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "composition": {p.name: p.composition for p in project.phases()},
        "hap": {p.name: p.getHAPvalues(hist) for p in project.phases()},
        "mass_fractions": hist.ComputeMassFracs(),
        "covariance": covariance_summary(project),
    }
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
