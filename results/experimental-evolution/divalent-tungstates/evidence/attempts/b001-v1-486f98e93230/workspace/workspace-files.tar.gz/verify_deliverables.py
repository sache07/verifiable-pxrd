#!/usr/bin/env python3
"""Verify that all numerical deliverables exactly originate from final.gpx."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def read_csv(path: Path) -> tuple[list[str], np.ndarray]:
    with path.open(newline="") as stream:
        reader = csv.reader(stream)
        header = next(reader)
        values = np.asarray([[float(value) for value in row] for row in reader], dtype=float)
    return header, values


def main() -> None:
    project = G2sc.G2Project(str(ROOT / "final.gpx"))
    hist = project.histogram(0)
    result = json.loads((ROOT / "result.json").read_text())
    header, fit = read_csv(ROOT / "fit.csv")
    input_header, measured = read_csv(ROOT / "inputs/pattern.csv")

    project_profile = np.column_stack([
        np.asarray(hist.getdata("X"), dtype=float),
        np.asarray(hist.getdata("Yobs"), dtype=float),
        np.asarray(hist.getdata("Ycalc"), dtype=float),
        np.asarray(hist.getdata("Residual"), dtype=float),
    ])
    assert header == ["two_theta_deg", "observed", "calculated", "difference"]
    assert input_header == ["two_theta_deg", "intensity"]
    assert fit.shape == (8301, 4)
    assert np.allclose(fit, project_profile, rtol=0.0, atol=1.0e-12)
    assert np.allclose(fit[:, :2], measured, rtol=0.0, atol=1.0e-12)
    assert np.allclose(fit[:, 3], fit[:, 1] - fit[:, 2], rtol=0.0, atol=1.0e-10)

    mass = hist.ComputeMassFracs()
    total = sum(value[0] for value in mass.values())
    for phase, exported in zip(project.phases(), result["phases"], strict=True):
        assert (ROOT / exported["cif_path"]).is_file()
        assert abs(exported["weight_fraction"] - mass[phase.name][0] / total) < 1.0e-14
    assert abs(sum(item["weight_fraction"] for item in result["phases"]) - 1.0) < 1.0e-14
    assert abs(result["fit_statistics"]["r_wp_percent"] - hist.residuals["wR"]) < 1.0e-14
    assert project.get_Frozen() == []

    replay_path = ROOT / ".tmp/replay_check.gpx"
    replay = G2sc.G2Project(str(ROOT / "final.gpx"), newgpx=str(replay_path))
    replay.set_Controls("cycles", 12)
    replay.save()
    replay.refine(printFile=str(replay_path.with_suffix(".lst")), makeBack=False)
    replay_hist = replay.histogram(0)
    replay_mass = replay_hist.ComputeMassFracs()
    replay_rvals = replay.data["Covariance"]["data"]["Rvals"]
    replay_delta = {
        "r_wp_percentage_point": float(replay_hist.residuals["wR"] - hist.residuals["wR"]),
        "maximum_fraction_change": float(max(
            abs(replay_mass[name][0] - mass[name][0]) for name in mass
        )),
        "max_shift_over_esd": float(replay_rvals["Max shft/sig"]),
        "relative_delta_chi_squared": float(replay_rvals["DelChi2"]),
    }

    summary = {
        "final_project": str(project.filename),
        "profile_rows": int(fit.shape[0]),
        "profile_exactly_matches_project": True,
        "observations_exactly_match_input": True,
        "fractions_exactly_match_project": True,
        "fraction_sum": float(sum(item["weight_fraction"] for item in result["phases"])),
        "frozen_variables": project.get_Frozen(),
        "replay_delta": replay_delta,
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
