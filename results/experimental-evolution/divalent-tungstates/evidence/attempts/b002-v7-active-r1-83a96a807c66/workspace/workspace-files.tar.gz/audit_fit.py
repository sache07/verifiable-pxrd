#!/usr/bin/env python3
"""Numerical and graphical audit of a saved GSAS-II powder fit."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks

from GSASII import GSASIIscriptable as G2sc


AUDIT_PEAKS = {
    "BaWO4": [(28.375, "004", "low"), (48.980, "116", "middle"), (82.609, "424", "high")],
    "Ba3W2O9": [(30.810, "300", "low"), (40.788, "223", "middle"), (71.517, "229", "high")],
    "WO3_P21n": [(23.399, "002", "low"), (50.205, "140/400/223", "middle"), (72.266, "440 family", "high")],
    "BaCO3": [(24.172, "111", "low"), (45.123, "132", "middle"), (87.080, "225", "high")],
}


def crossing(x: np.ndarray, y: np.ndarray, start: int, direction: int, level: float) -> float | None:
    i = start
    while 0 <= i + direction < len(y):
        j = i + direction
        if (y[i] - level) * (y[j] - level) <= 0 and y[i] != y[j]:
            return float(x[i] + (level - y[i]) * (x[j] - x[i]) / (y[j] - y[i]))
        i = j
    return None


def peak_metrics(x: np.ndarray, signal: np.ndarray, expected: float) -> dict:
    # A 0.18-degree search catches the refined K-alpha1 maximum but not the
    # K-alpha2 maximum at high angle. A wider extraction region is retained
    # for finding both half-height crossings.
    region = (x >= expected - 0.34) & (x <= expected + 0.34)
    xx = x[region]
    yy = signal[region]
    search = (xx >= expected - 0.18) & (xx <= expected + 0.18)
    candidates = np.flatnonzero(search)
    if not len(candidates):
        return {"expected": expected, "error": "outside range"}
    imax = int(candidates[np.argmax(yy[candidates])])

    left_side = yy[xx <= expected - 0.20]
    right_side = yy[xx >= expected + 0.20]
    side = np.r_[left_side, right_side]
    baseline = float(np.percentile(side, 20)) if len(side) else float(np.min(yy))
    height = float(yy[imax] - baseline)
    half = baseline + 0.5 * height
    left = crossing(xx, yy, imax, -1, half)
    right = crossing(xx, yy, imax, 1, half)
    result = {
        "expected": float(expected),
        "position": float(xx[imax]),
        "height_above_local_baseline": height,
        "local_baseline": baseline,
        "left_half_width": None if left is None else float(xx[imax] - left),
        "right_half_width": None if right is None else float(right - xx[imax]),
        "FWHM": None if left is None or right is None else float(right - left),
    }
    return result


def main() -> None:
    project = Path(sys.argv[1] if len(sys.argv) > 1 else "model_screen/three_plus_baco3.gpx")
    outstem = Path(sys.argv[2] if len(sys.argv) > 2 else "model_screen/four_phase_audit")
    gpx = G2sc.G2Project(str(project))
    hist = gpx.histogram(0)
    x = np.asarray(hist.getdata("X"), dtype=float)
    yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    bkg = np.asarray(hist.getdata("Background"), dtype=float)
    resid = yobs - ycalc
    # Suppress point-to-point counting noise for the numerical half-height
    # audit only. sigma=1.2 points is about 0.013 degrees, far below the
    # observed peak widths; plotted and exported profiles remain unsmoothed.
    metric_yobs = gaussian_filter1d(yobs - bkg, 1.2)
    metric_ycalc = gaussian_filter1d(ycalc - bkg, 1.2)

    smooth = gaussian_filter1d(resid, 1.2)
    positive, pprop = find_peaks(smooth, prominence=35, distance=5)
    negative, nprop = find_peaks(-smooth, prominence=35, distance=5)
    pos_order = np.argsort(pprop["prominences"])[::-1]
    neg_order = np.argsort(nprop["prominences"])[::-1]

    audit = {
        "project": str(project),
        "Rwp_percent": hist.data["data"][0].get("wR"),
        "GOF": gpx.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "metric_method": "background-subtracted profile; Gaussian sigma=1.2 points (about 0.013 degrees) for counting-noise suppression",
        "largest_positive_residual_peaks": [
            {
                "two_theta": float(x[positive[i]]),
                "residual_counts": float(resid[positive[i]]),
                "prominence_counts": float(pprop["prominences"][i]),
            }
            for i in pos_order[:30]
        ],
        "largest_negative_residual_peaks": [
            {
                "two_theta": float(x[negative[i]]),
                "residual_counts": float(resid[negative[i]]),
                "prominence_counts": float(nprop["prominences"][i]),
            }
            for i in neg_order[:30]
        ],
        "isolated_peak_metrics": {},
    }
    for phase, peaks in AUDIT_PEAKS.items():
        if gpx.phase(phase) is None:
            continue
        rows = []
        for expected, hkl, angle_class in peaks:
            rows.append(
                {
                    "hkl": hkl,
                    "angle_class": angle_class,
                    "observed": peak_metrics(x, metric_yobs, expected),
                    "calculated": peak_metrics(x, metric_ycalc, expected),
                }
            )
        audit["isolated_peak_metrics"][phase] = rows

    outstem.parent.mkdir(exist_ok=True)
    with outstem.with_suffix(".json").open("w") as stream:
        json.dump(audit, stream, indent=2)

    fig, axes = plt.subplots(2, 1, figsize=(14, 8), sharex=True, gridspec_kw={"height_ratios": [3, 1]})
    axes[0].plot(x, yobs, color="black", lw=0.65, label="observed")
    axes[0].plot(x, ycalc, color="#d62728", lw=0.75, label="calculated")
    axes[0].plot(x, bkg, color="#777777", lw=0.6, label="background")
    axes[0].set_ylabel("Counts")
    axes[0].legend(frameon=False, ncol=3)
    axes[1].axhline(0, color="#777777", lw=0.5)
    axes[1].plot(x, resid, color="#1f77b4", lw=0.6)
    axes[1].set_ylabel("Obs − calc")
    axes[1].set_xlabel(r"2$\theta$ (degrees)")
    fig.tight_layout()
    fig.savefig(outstem.with_suffix(".png"), dpi=180)
    plt.close(fig)

    fig, axes = plt.subplots(5, 1, figsize=(14, 12))
    ranges = [(10, 35), (35, 50), (50, 65), (65, 82), (82, 100)]
    for ax, (lo, hi) in zip(axes, ranges):
        sel = (x >= lo) & (x <= hi)
        ax.plot(x[sel], yobs[sel], color="black", lw=0.7)
        ax.plot(x[sel], ycalc[sel], color="#d62728", lw=0.75)
        ax.plot(x[sel], resid[sel] + np.min(yobs[sel]) - 250, color="#1f77b4", lw=0.55)
        ax.set_xlim(lo, hi)
        ax.set_ylabel("Counts")
    axes[-1].set_xlabel(r"2$\theta$ (degrees)")
    fig.tight_layout()
    fig.savefig(outstem.with_name(outstem.name + "_segments").with_suffix(".png"), dpi=180)
    plt.close(fig)

    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
