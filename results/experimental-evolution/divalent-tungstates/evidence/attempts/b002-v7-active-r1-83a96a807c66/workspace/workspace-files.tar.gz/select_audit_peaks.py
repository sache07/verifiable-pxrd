#!/usr/bin/env python3
"""Rank phase-specific reflection groups for the measured-profile audit."""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from audit_fit import peak_metrics


def main() -> None:
    project = Path(sys.argv[1] if len(sys.argv) > 1 else "challenges/combined_all_minor_strain.gpx")
    gpx = G2sc.G2Project(str(project))
    hist = gpx.histogram(0)
    x = np.asarray(hist.getdata("X"), dtype=float)
    yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    bkg = np.asarray(hist.getdata("Background"), dtype=float)
    refs = hist.data["Reflection Lists"]

    prepared = {}
    for phase, values in refs.items():
        rows = np.asarray(values["RefList"], dtype=float)
        score = rows[:, 3] * rows[:, 9] * rows[:, 11]
        prepared[phase] = (rows, score)

    bins = ((10.0, 35.0, "low"), (35.0, 65.0, "middle"), (65.0, 99.0, "high"))
    for phase, (rows, score) in prepared.items():
        print(f"\n===== {phase} =====")
        for lo, hi, angle_class in bins:
            candidates = []
            for row in rows[(rows[:, 5] >= lo) & (rows[:, 5] < hi)]:
                pos = float(row[5])
                own = float(score[np.abs(rows[:, 5] - pos) <= 0.16].sum())
                other = 0.0
                nearest = 99.0
                for other_phase, (other_rows, other_score) in prepared.items():
                    if other_phase == phase:
                        continue
                    delta = np.abs(other_rows[:, 5] - pos)
                    significant = other_score >= 0.03 * np.max(other_score)
                    if np.any(significant):
                        nearest = min(nearest, float(np.min(delta[significant])))
                    other += float(other_score[delta <= 0.16].sum())
                purity = own / (own + other + 1e-12)
                metric = peak_metrics(x, yobs - bkg, pos)
                calc_metric = peak_metrics(x, ycalc - bkg, pos)
                height = metric.get("height_above_local_baseline", -1.0)
                candidates.append((purity * own, purity, own, other, nearest, row, height, metric, calc_metric))
            candidates.sort(key=lambda item: item[0], reverse=True)
            print(f"-- {angle_class} --")
            for _, purity, own, other, nearest, row, height, metric, calc_metric in candidates[:12]:
                h, k, l = (int(value) for value in row[:3])
                print(
                    f"{h:3d} {k:3d} {l:3d} pos={row[5]:8.4f} "
                    f"purity={purity:5.3f} own={own:9.1f} other={other:9.1f} "
                    f"nearest={nearest:6.3f} obsheight={height:7.1f} "
                    f"obsFWHM={metric.get('FWHM')} calcFWHM={calc_metric.get('FWHM')}"
                )


if __name__ == "__main__":
    main()
