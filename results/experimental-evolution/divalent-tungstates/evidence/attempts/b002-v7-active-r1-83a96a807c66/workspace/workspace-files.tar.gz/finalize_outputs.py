#!/usr/bin/env python3
"""Replay the selected GSAS-II model and freeze scorer-ready outputs."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "challenges" / "combined_ba3_wo3_uniaxial_001.gpx"
PROJECT = ROOT / "final.gpx"

PHASE_INFO = {
    "BaWO4": {"display_name": "BaWO4", "formula": "BaWO4", "cod_id": "1527204", "cif": "BaWO4.cif"},
    "Ba3W2O9": {"display_name": "Ba3W2O9", "formula": "Ba3W2O9", "cod_id": "1533878", "cif": "Ba3W2O9.cif"},
    "WO3_P21n": {"display_name": "WO3", "formula": "WO3", "cod_id": "1528915", "cif": "WO3.cif"},
    "BaCO3": {"display_name": "BaCO3", "formula": "BaCO3", "cod_id": "9010928", "cif": "BaCO3.cif"},
}


def replay(gpx: G2sc.G2Project, repeats: int) -> None:
    gpx.set_Controls("cycles", 12)
    for _ in range(repeats):
        gpx.refine(makeBack=False)
    gpx.save()


def as_float(value):
    return None if value is None else float(value)


def main() -> None:
    if not SOURCE.exists():
        raise SystemExit(f"Selected source project is missing: {SOURCE}")

    # First replay after extending the refinement limits to every measured point.
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(PROJECT))
    hist = gpx.histogram(0)
    full_limits = hist.data["Limits"][0]
    hist.Limits("lower", float(full_limits[0]))
    hist.Limits("upper", float(full_limits[1]))
    replay(gpx, repeats=4)

    # Required save/reopen/replay check. All exported values below come from
    # this reopened project, not from an in-memory precursor.
    gpx = G2sc.G2Project(str(PROJECT))
    hist = gpx.histogram(0)
    hist.Limits("lower", float(hist.data["Limits"][0][0]))
    hist.Limits("upper", float(hist.data["Limits"][0][1]))
    replay(gpx, repeats=4)

    # Reopen once more to make the on-disk project the single source of truth.
    gpx = G2sc.G2Project(str(PROJECT))
    hist = gpx.histogram(0)
    used_limits = [float(value) for value in hist.data["Limits"][1]]
    full_limits = [float(value) for value in hist.data["Limits"][0]]
    if not np.allclose(used_limits, full_limits, atol=1e-10, rtol=0.0):
        raise RuntimeError(f"Final project does not use the full range: {used_limits} vs {full_limits}")

    rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
    if not rvals.get("converged", False):
        raise RuntimeError("Final replay did not converge")
    frozen = gpx.get_Frozen()
    if frozen:
        raise RuntimeError(f"Final project contains bound/frozen refined terms: {frozen}")

    raw_fractions = hist.ComputeMassFracs()
    names = [phase.name for phase in gpx.phases()]
    if set(names) != set(PHASE_INFO):
        raise RuntimeError(f"Unexpected final phases: {names}")
    total = sum(float(raw_fractions[name][0]) for name in names)
    fractions = {name: float(raw_fractions[name][0]) / total for name in names}
    # Force exact floating-point closure while retaining project agreement.
    fractions[names[-1]] = 1.0 - sum(fractions[name] for name in names[:-1])
    if any(value <= 0.0 for value in fractions.values()):
        raise RuntimeError(f"Nonpositive final phase fraction: {fractions}")
    if abs(sum(fractions.values()) - 1.0) > 1e-12:
        raise RuntimeError(f"Normalized fractions do not sum to one: {fractions}")

    result_phases = []
    phase_details = {}
    for phase in gpx.phases():
        info = PHASE_INFO[phase.name]
        cif_path = ROOT / info["cif"]
        phase.export_CIF(str(cif_path))
        if not cif_path.is_file() or cif_path.stat().st_size == 0:
            raise RuntimeError(f"CIF export failed for {phase.name}")
        general = phase.data["General"]
        hap = phase.data["Histograms"][hist.name]
        cell, cell_esd = phase.get_cell_and_esd()
        result_phases.append(
            {
                "name": info["display_name"],
                "formula": info["formula"],
                "space_group": general["SGData"]["SpGrp"].strip(),
                "cif_path": info["cif"],
                "weight_fraction": fractions[phase.name],
                "weight_fraction_esd": float(raw_fractions[phase.name][1]),
            }
        )
        phase_details[phase.name] = {
            "cod_id": info["cod_id"],
            "space_group": general["SGData"]["SpGrp"].strip(),
            "cell": {key: float(value) for key, value in cell.items()},
            "cell_esd": {key: float(value) for key, value in cell_esd.items()},
            "scale": [float(hap["Scale"][0]), bool(hap["Scale"][1])],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }

    x = np.asarray(hist.getdata("X"), dtype=float)
    yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)
    if not (len(x) == len(yobs) == len(ycalc) == len(background)):
        raise RuntimeError("Profile arrays differ in length")
    fit_path = ROOT / "fit.csv"
    with fit_path.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed_counts", "calculated_counts", "difference_counts", "background_counts"])
        for values in zip(x, yobs, ycalc, yobs - ycalc, background):
            writer.writerow([f"{values[0]:.8f}", *(f"{value:.8f}" for value in values[1:])])

    fit_stats = {
        "Rwp_percent": as_float(hist.data["data"][0].get("wR")),
        "Rp_percent": as_float(hist.data["data"][0].get("R")),
        "goodness_of_fit": as_float(rvals.get("GOF")),
        "chi_squared": as_float(rvals.get("chisq")),
        "n_observations": int(rvals.get("Nobs", len(x))),
        "n_refined_parameters": int(rvals.get("Nvars", 0)),
        "max_shift_over_esd": as_float(rvals.get("Max shft/sig")),
        "converged": bool(rvals.get("converged", False)),
    }
    result = {
        "project_path": "final.gpx",
        "fit_path": "fit.csv",
        "phases": result_phases,
        "fit_statistics": fit_stats,
    }
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")

    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    summary = {
        "source_project": str(SOURCE.relative_to(ROOT)),
        "project": "final.gpx",
        "full_limits": full_limits,
        "used_limits": used_limits,
        "profile_points": len(x),
        "fit_statistics": fit_stats,
        "fractions": fractions,
        "fraction_esds": {name: float(raw_fractions[name][1]) for name in names},
        "phase_details": phase_details,
        "instrument": {key: inst[key][1:] for key in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "sample": {key: sample[key] for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
        "background": hist.data["Background"][0],
        "frozen_parameters": frozen,
    }
    with (ROOT / "final_summary.json").open("w") as stream:
        json.dump(summary, stream, indent=2)
        stream.write("\n")

    # Parse the scorer-facing JSON and verify every referenced artifact.
    parsed = json.loads((ROOT / "result.json").read_text())
    assert parsed["project_path"] == "final.gpx" and (ROOT / parsed["project_path"]).is_file()
    assert (ROOT / parsed["fit_path"]).is_file()
    assert abs(sum(float(row["weight_fraction"]) for row in parsed["phases"]) - 1.0) <= 1e-12
    for row in parsed["phases"]:
        assert isinstance(row["weight_fraction"], (int, float))
        assert (ROOT / row["cif_path"]).is_file()

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
