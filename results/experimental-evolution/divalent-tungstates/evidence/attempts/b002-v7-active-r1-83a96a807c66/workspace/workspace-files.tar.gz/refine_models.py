#!/usr/bin/env python3
"""Build comparable GSAS-II baseline refinements for phase inventory screening."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cif(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PHASES = {
    "BaWO4": cif("1527204"),
    "Ba3W2O9": cif("1533878"),
    "WO3_P21n": cif("1528915"),
    "WO3_P1": cif("2106293"),
    "WO3_Pnma": cif("2107312"),
    "BaCO3": cif("9010928"),
}


MODELS = {
    "bwo4": ["BaWO4"],
    "bwo4_b3w2o9": ["BaWO4", "Ba3W2O9"],
    "bwo4_wo3": ["BaWO4", "WO3_P21n"],
    "three_phase": ["BaWO4", "Ba3W2O9", "WO3_P21n"],
    "three_phase_p1wo3": ["BaWO4", "Ba3W2O9", "WO3_P1"],
    "three_phase_pnmawo3": ["BaWO4", "Ba3W2O9", "WO3_Pnma"],
    "three_plus_baco3": ["BaWO4", "Ba3W2O9", "WO3_P21n", "BaCO3"],
}


def snapshot(gpx: G2sc.G2Project, label: str) -> dict:
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    out = {
        "label": label,
        "Rwp": hist.data["data"][0].get("wR"),
        "Rp": hist.data["data"][0].get("R"),
        "GOF": gpx.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
            if key in inst
        },
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "composition_per_cell": phase.composition,
            "scale": hap["Scale"][0],
            "scale_refine": hap["Scale"][1],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    try:
        out["mass_fractions"] = {
            key: [float(val), float(esd)]
            for key, (val, esd) in hist.ComputeMassFracs().items()
        }
    except Exception as err:
        out["mass_fraction_error"] = repr(err)
    return out


def refine_step(gpx: G2sc.G2Project, label: str, report: list[dict]) -> None:
    gpx.refine(makeBack=False)
    state = snapshot(gpx, label)
    report.append(state)
    print(
        label,
        "Rwp=", state["Rwp"],
        "GOF=", state["GOF"],
        "inst=", state["instrument"],
        "scales=", {k: v["scale"] for k, v in state["phases"].items()},
        flush=True,
    )


def run_model(model_name: str, phase_names: list[str]) -> dict:
    work = ROOT / "model_screen"
    work.mkdir(exist_ok=True)
    project_path = work / f"{model_name}.gpx"
    gpx = G2sc.G2Project(newgpx=str(project_path))
    hist = gpx.add_powder_histogram(
        str(ROOT / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
        fmthint="xye",
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    # There is an otherwise exact degeneracy between the overall histogram
    # scale and all phase scales. Keep the former fixed at unity.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "refine": True,
            }
        }
    )
    for phase_name in phase_names:
        phase = gpx.add_phase(
            str(PHASES[phase_name]),
            phasename=phase_name,
            histograms=[hist],
            fmthint="CIF",
        )
        # GSAS-II defaults contribute 1-micron size and 1000-microstrain
        # broadening even when their refinement flags are off. Neutralize all
        # unused phase broadening before establishing the common profile.
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        # 10 micrometres is GSAS-II's allowed upper bound and contributes
        # negligible broadening at this resolution.
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        phase.set_HAP_refinements({"Scale": True}, [hist])
    for variable in (":0:U", ":0:W", ":0:X"):
        gpx.set_Controls("parmMin", 0.0, variable)
    gpx.set_Controls("cycles", 8)
    gpx.save()

    report: list[dict] = [snapshot(gpx, "initial")]
    refine_step(gpx, "background_scales", report)

    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    refine_step(gpx, "cells", report)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_step(gpx, "zero", report)

    # An unconstrained trial drives U negative. Keep U=V=Y=Z=0 and use the
    # minimal nonnegative Gaussian W + Lorentzian X common profile baseline.
    for key in ("W", "X"):
        hist.set_refinements({"Instrument Parameters": [key]})
        refine_step(gpx, f"profile_{key}", report)

    gpx.save()
    final = snapshot(gpx, "final")
    result = {
        "model": model_name,
        "project": str(project_path),
        "source_cifs": {name: str(PHASES[name]) for name in phase_names},
        "steps": report,
        "final": final,
    }
    with (work / f"{model_name}.json").open("w") as stream:
        json.dump(result, stream, indent=2)
    return result


def main() -> None:
    selected = sys.argv[1:] or list(MODELS)
    summary = {}
    for name in selected:
        if name not in MODELS:
            raise SystemExit(f"Unknown model {name!r}; choose from {sorted(MODELS)}")
        print(f"\n===== {name} =====", flush=True)
        try:
            result = run_model(name, MODELS[name])
            summary[name] = result["final"]
        except Exception as err:
            summary[name] = {"error": repr(err)}
            print("MODEL FAILED", name, repr(err), flush=True)
    with (ROOT / "model_screen" / "summary.json").open("w") as stream:
        json.dump(summary, stream, indent=2)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
