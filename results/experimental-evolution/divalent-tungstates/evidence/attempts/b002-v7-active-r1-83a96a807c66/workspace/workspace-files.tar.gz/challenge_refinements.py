#!/usr/bin/env python3
"""Replay-stable nuisance, broadening and texture challenges from one baseline."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "model_screen" / "three_plus_baco3.gpx"
OUTDIR = ROOT / "challenges"
BEST_NUISANCE_BASELINE = OUTDIR / "roughness_background13.gpx"
BEST_TEXTURE_BASELINE = OUTDIR / "texture_112.gpx"
BEST_COMBINED_BASELINE = OUTDIR / "combined_all_minor_strain.gpx"


def replay(gpx: G2sc.G2Project, repeats: int = 2) -> None:
    gpx.set_Controls("cycles", 12)
    for _ in range(repeats):
        gpx.refine(makeBack=False)
    gpx.save()


def summarize(gpx: G2sc.G2Project) -> dict:
    hist = gpx.histogram(0)
    rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    out = {
        "project": gpx.filename,
        "Rwp": hist.data["data"][0].get("wR"),
        "Rp": hist.data["data"][0].get("R"),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "delta_chi2": rvals.get("DelChi2"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "instrument": {k: inst[k][1:] for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "sample": {k: sample[k] for k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
        "background": hist.data["Background"][0],
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    try:
        out["mass_fractions"] = {
            name: [float(value), float(esd)]
            for name, (value, esd) in hist.ComputeMassFracs().items()
        }
    except Exception as err:
        out["mass_fraction_error"] = repr(err)
    cov = gpx.data["Covariance"]["data"]
    out["refined_parameters"] = {
        name: {"value": float(value), "esd": float(esd)}
        for name, value, esd in zip(cov.get("varyList", []), cov.get("variables", []), cov.get("sig", []))
    }
    out["frozen_parameters"] = gpx.get_Frozen()
    return out


def clone(name: str, source: Path = SOURCE) -> G2sc.G2Project:
    OUTDIR.mkdir(exist_ok=True)
    return G2sc.G2Project(str(source), newgpx=str(OUTDIR / f"{name}.gpx"))


def run(name: str, setup, source: Path = SOURCE, repeats: int = 2) -> dict:
    print(f"===== {name} =====", flush=True)
    gpx = clone(name, source)
    setup(gpx)
    replay(gpx, repeats=repeats)
    result = summarize(gpx)
    with (OUTDIR / f"{name}.json").open("w") as stream:
        json.dump(result, stream, indent=2)
    print(
        name,
        "Rwp", result["Rwp"],
        "GOF", result["GOF"],
        "maxshift", result["max_shift_over_esd"],
        flush=True,
    )
    return result


def noop(gpx: G2sc.G2Project) -> None:
    pass


def background(ncoeff: int):
    def setup(gpx: G2sc.G2Project) -> None:
        gpx.histogram(0).set_refinements(
            {"Background": {"type": "chebyschev-1", "no. coeffs": ncoeff, "refine": True}}
        )

    return setup


def polarization(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
    gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")


def roughness(gpx: G2sc.G2Project) -> None:
    sample = gpx.histogram(0).data["Sample Parameters"]
    # At B=0 the correction is exactly unity. A=0 gives a one-parameter
    # Suortti challenge with a nonzero derivative for B.
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.01, True]
    gpx.set_Controls("parmMin", 0.0, ":0:SurfRoughB")


def polarization_roughness(gpx: G2sc.G2Project) -> None:
    polarization(gpx)
    roughness(gpx)


def roughness_background13(gpx: G2sc.G2Project) -> None:
    background(13)(gpx)
    roughness(gpx)


def sample_shift(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    hist.data["Instrument Parameters"][0]["Zero"][1:] = [0.0, False]
    hist.data["Sample Parameters"]["Shift"] = [-490.0, True]


def texture(axis: list[int]):
    def setup(gpx: G2sc.G2Project) -> None:
        hist = gpx.histogram(0)
        po = gpx.phase("BaWO4").data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = axis

    return setup


def broadening(phase_name: str, kind: str):
    def setup(gpx: G2sc.G2Project) -> None:
        hist = gpx.histogram(0)
        phase = gpx.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        if kind == "size":
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 1.0
            hap["Size"][1][2] = 1.0
            hap["Size"][2][0] = True
            hap["Size"][2][2] = False
            gpx.set_Controls("parmMin", 0.01, f"{phase.id}:{hist.id}:Size;i")
            gpx.set_Controls("parmMax", 10.0, f"{phase.id}:{hist.id}:Size;i")
        elif kind == "strain":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 100.0
            hap["Mustrain"][1][2] = 1.0
            hap["Mustrain"][2][0] = True
            hap["Mustrain"][2][2] = False
            gpx.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Mustrain;i")
        else:
            raise ValueError(kind)

    return setup


def combined_strain(*phase_names: str):
    def setup(gpx: G2sc.G2Project) -> None:
        for phase_name in phase_names:
            broadening(phase_name, "strain")(gpx)

    return setup


def uniaxial_strain(phase_name: str, axis: list[int]):
    """Split an accepted isotropic strain into equatorial/axial components."""
    def setup(gpx: G2sc.G2Project) -> None:
        hist = gpx.histogram(0)
        phase = gpx.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        strain = hap["Mustrain"]
        start = float(strain[1][0])
        strain[0] = "uniaxial"
        strain[1][0] = start
        strain[1][1] = start
        strain[2][0] = True
        strain[2][1] = True
        strain[2][2] = False
        strain[3] = list(axis)
        gpx.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Mustrain;i")
        gpx.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Mustrain;a")

    return setup


SCENARIOS = {
    "baseline_replay": noop,
    "background_8": background(8),
    "background_13": background(13),
    "background_16": background(16),
    "polarization": polarization,
    "roughness": roughness,
    "polarization_roughness": polarization_roughness,
    "roughness_background13": roughness_background13,
    "sample_shift": sample_shift,
    "texture_001": texture([0, 0, 1]),
    "texture_100": texture([1, 0, 0]),
    "texture_112": texture([1, 1, 2]),
}
for phase_name in ("BaWO4", "Ba3W2O9", "WO3_P21n", "BaCO3"):
    for kind in ("size", "strain"):
        SCENARIOS[f"{phase_name}_{kind}"] = broadening(phase_name, kind)
SCENARIOS.update(
    {
        "combined_ba3_strain": combined_strain("Ba3W2O9"),
        "combined_wo3_strain": combined_strain("WO3_P21n"),
        "combined_baco3_strain": combined_strain("BaCO3"),
        "combined_all_minor_strain": combined_strain("Ba3W2O9", "WO3_P21n", "BaCO3"),
    }
)
for phase_name, axes in {
    "Ba3W2O9": ([0, 0, 1], [1, 0, 0]),
    "WO3_P21n": ([0, 0, 1], [1, 0, 0], [0, 1, 0]),
    "BaCO3": ([0, 0, 1], [1, 0, 0], [0, 1, 0]),
}.items():
    for axis in axes:
        tag = "".join(str(value) for value in axis)
        SCENARIOS[f"anisotropy_{phase_name}_{tag}"] = uniaxial_strain(phase_name, list(axis))


def main() -> None:
    selected = sys.argv[1:] or list(SCENARIOS)
    summary = {}
    for name in selected:
        if name not in SCENARIOS:
            raise SystemExit(f"Unknown scenario {name!r}; choose from {sorted(SCENARIOS)}")
        try:
            if name.startswith("anisotropy_"):
                source = BEST_COMBINED_BASELINE
            elif name.startswith("combined_"):
                source = BEST_TEXTURE_BASELINE
            elif name.startswith("texture_") or name.endswith(("_size", "_strain")):
                source = BEST_NUISANCE_BASELINE
            else:
                source = SOURCE
            summary[name] = run(name, SCENARIOS[name], source=source)
        except Exception as err:
            summary[name] = {"error": repr(err)}
            print("FAILED", name, repr(err), flush=True)
    with (OUTDIR / "summary.json").open("w") as stream:
        json.dump(summary, stream, indent=2)
    print(json.dumps({k: {x: v.get(x) for x in ("Rwp", "GOF", "error")} for k, v in summary.items()}, indent=2))


if __name__ == "__main__":
    main()
