#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent


for tag, selected in (("wo", (1,)), ("haus", (2,)), ("both", (1, 2))):
    out = ROOT / f"strain_mix_{tag}.gpx"
    gpx = G2.G2Project(str(ROOT / "haus_strain.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    hist.clear_refinements({"Instrument Parameters":
                            ["Zero", "Polariz.", "U", "W", "X", "SH/L"]})
    for phase in gpx.phases():
        phase.clear_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    for idx in (1, 2):
        phase = gpx.phase(idx)
        m = phase.data["Histograms"][hist.name]["Mustrain"]
        m[1][2] = 1.0
        m[2][2] = False
        if idx in selected:
            phase.set_HAP_refinements({
                "Mustrain": {"type": "isotropic",
                              "LGmix": {"value": 0.5, "refine": True}}
            })
            gpx.set_Controls("parmMin", 0.0, f"{idx}:0:Mustrain;mx")
            gpx.set_Controls("parmMax", 1.0, f"{idx}:0:Mustrain;mx")
    gpx.set_Controls("cycles", 12)
    gpx.do_refinements([{}])
    gpx.do_refinements([{}])
    gpx.save()
    vals = []
    for idx in (1, 2):
        m = gpx.phase(idx).data["Histograms"][hist.name]["Mustrain"]
        vals.append((round(m[1][0], 5), round(m[1][2], 7), m[2][2]))
    print(tag, "wR", round(hist.residuals.get("wR"), 6),
          "strain_mix", vals, "mass", hist.ComputeMassFracs(),
          "frozen", gpx.get_Frozen())
