#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path("<RUN>/resources/b001-c04/cif")


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def run(cod_id: str, label: str) -> None:
    out = ROOT / f"watch_{cod_id}.gpx"
    gpx = G2.G2Project(str(ROOT / "coords_all.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    # Preserve the clean common line shape and refined structures for screening.
    hist.clear_refinements({"Instrument Parameters":
                            ["Zero", "Polariz.", "U", "W", "X", "SH/L"]})
    for phase in gpx.phases():
        phase.clear_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    phase = gpx.add_phase(str(cif_path(cod_id)), phasename=f"{label}_{cod_id}",
                          histograms=[hist], fmthint="CIF")
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][1][0] = hap["Size"][1][1] = 1.0e6
    hap["Mustrain"][1][0] = hap["Mustrain"][1][1] = 0.0
    hap["Pref.Ori."][1] = 1.0
    phase.set_HAP_refinements({"Scale": True})
    gpx.set_Controls("parmMin", 0.0, "2:0:Scale")
    gpx.set_Controls("cycles", 12)
    gpx.do_refinements([{}])
    gpx.do_refinements([{}])
    gpx.save()
    print(cod_id, label, "wR", round(hist.residuals.get("wR"), 6),
          "scale", round(hap["Scale"][0], 9),
          "mass", hist.ComputeMassFracs(), "frozen", gpx.get_Frozen())


for args in [
    ("9001963", "Mn3O4_tetragonal"),
    ("9001302", "Mn3O4_orthorhombic"),
    ("2002703", "Mn3WO6_trigonal"),
    ("1514230", "Mn2O3_cubic"),
    ("1514108", "MnO_cubic"),
]:
    run(*args)
