#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
FINAL_GPX = ROOT / "final.gpx"

gpx = G2.G2Project(str(ROOT / "haus_strain.gpx"), newgpx=str(FINAL_GPX))
hist = gpx.histogram(0)
mn, wo, haus = gpx.phases()

# Use the complete supplied range and no exclusions.
x_all = np.asarray(hist.getdata("X"), dtype=float)
hist.set_refinements({"Limits": [float(x_all[0]), float(x_all[-1])]})
hist.Excluded([])

# Physically restrained shared instrument/background model.
inst = hist.InstrumentParameters
for key in ("U", "V", "W", "Y", "Z"):
    inst[key][1] = 0.0
    inst[key][2] = False
hist.set_refinements({
    "Background": {"type": "chebyschev-1", "no. coeffs": 6, "refine": True},
    "Instrument Parameters": ["Zero", "Polariz.", "X", "SH/L"],
})
hist.SampleParameters["Scale"][1] = False
for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
    hist.SampleParameters[key][0] = 0.0
    hist.SampleParameters[key][1] = False

# Neutralize all unused phase nuisance terms. Retain only the supported
# isotropic microstrain for residual WO3 and Mn3O4.
for phase in (mn, wo, haus):
    phase.set_refinements({"Cell": True})
    phase.set_HAP_refinements({"Scale": True})
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = hap["Size"][1][1] = 1.0e6
    hap["Size"][1][2] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][1][2] = 1.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Extinction"][1] = False
    for item in hap["Babinet"].values():
        item[1] = False

mn_hap = mn.data["Histograms"][hist.name]
mn_hap["Mustrain"][1][0] = 0.0
wo_hap = wo.data["Histograms"][hist.name]
wo_hap["Mustrain"][1][0] = max(100.0, wo_hap["Mustrain"][1][0])
wo_hap["Mustrain"][2][0] = True
haus_hap = haus.data["Histograms"][hist.name]
haus_hap["Mustrain"][1][0] = max(100.0, haus_hap["Mustrain"][1][0])
haus_hap["Mustrain"][2][0] = True

# Bounds are used only for parameters with physical domains.
for phase_id in range(3):
    gpx.set_Controls("parmMin", 0.0, f"{phase_id}:0:Scale")
for phase_id in (1, 2):
    gpx.set_Controls("parmMin", 0.0, f"{phase_id}:0:Mustrain;i")
    gpx.set_Controls("parmMax", 100000.0, f"{phase_id}:0:Mustrain;i")
gpx.set_Controls("parmMin", -0.75, ":0:Zero")
gpx.set_Controls("parmMax", 0.75, ":0:Zero")
gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")
gpx.set_Controls("parmMin", 0.0, ":0:X")
gpx.set_Controls("parmMin", 0.002, ":0:SH/L")
gpx.set_Controls("parmMax", 0.2, ":0:SH/L")
gpx.set_Controls("cycles", 16)
gpx.set_Frozen()

# Rebuild common nuisance terms and phase cells/scales before coordinates.
for phase in (mn, wo, haus):
    for atom in phase.atoms():
        atom.refinement_flags = " "
gpx.do_refinements([{}])
gpx.do_refinements([{}])

# Only the major MnWO4 phase supports coordinate refinement. The minor-phase
# coordinates remain at their physically screened source values.
for atom in mn.atoms():
    atom.refinement_flags = "X"
gpx.do_refinements([{}])
gpx.do_refinements([{}])
gpx.save()

# Full-range save/reopen/replay verification.
gpx = G2.G2Project(str(FINAL_GPX))
gpx.set_Frozen()
gpx.do_refinements([{}])
gpx.do_refinements([{}])
gpx.save()

hist = gpx.histogram(0)
mn, wo, haus = gpx.phases()
rvals = gpx.data["Covariance"]["data"]["Rvals"]
if not rvals.get("converged", False):
    raise RuntimeError("Final GSAS-II refinement did not converge")
if abs(float(rvals.get("Max shft/sig", 999.0))) > 0.1:
    raise RuntimeError(f"Final maximum shift/esd is too large: {rvals.get('Max shft/sig')}")
if gpx.get_Frozen():
    raise RuntimeError(f"Final model retains bound-frozen terms: {gpx.get_Frozen()}")

# CIFs are exported from this exact, reloaded final project.
cif_names = ["phase_MnWO4.cif", "phase_WO3.cif", "phase_Mn3O4.cif"]
for phase, name in zip((mn, wo, haus), cif_names):
    if phase.ShortDistances():
        raise RuntimeError(f"Unphysical short contact in {phase.name}: {phase.ShortDistances()}")
    phase.export_CIF(str(ROOT / name))

# Profile is exported directly from the same final project arrays.
x = np.asarray(hist.getdata("X"), dtype=float)
y_obs = np.asarray(hist.getdata("Yobs"), dtype=float)
y_calc = np.asarray(hist.getdata("Ycalc"), dtype=float)
difference = y_obs - y_calc
with (ROOT / "fit.csv").open("w", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
    writer.writerows(zip(x, y_obs, y_calc, difference))

mass = hist.ComputeMassFracs()
mass_sum = sum(value for value, sigma in mass.values())
phase_specs = [
    (mn, "MnWO4", "manganese tungstate (wolframite)", cif_names[0]),
    (wo, "WO3", "tungsten trioxide", cif_names[1]),
    (haus, "Mn3O4", "hausmannite", cif_names[2]),
]
phase_rows = []
for phase, formula, label, cif_name in phase_specs:
    value, sigma = mass[phase.name]
    phase_rows.append({
        "name": label,
        "formula": formula,
        "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
        "cif_path": cif_name,
        "weight_fraction": value / mass_sum,
        "weight_fraction_esd": sigma / mass_sum,
    })

res = hist.residuals
fit_stats = {
    "Rwp_percent": float(res["wR"]),
    "Rp_percent": float(res["R"]),
    "Rexp_percent": float(res["wRmin"]),
    "goodness_of_fit": float(rvals["GOF"]),
    "reduced_chi_squared": float(rvals["GOF"]) ** 2,
    "background_subtracted_Rwp_percent": float(res["wRb"]),
    "background_subtracted_Rp_percent": float(res["Rb"]),
    "durbin_watson": float(hist.data["data"][0]["Durbin-Watson"]),
    "n_observations": int(rvals["Nobs"]),
    "n_variables": int(rvals["Nvars"]),
}
result = {
    "phases": phase_rows,
    "fit_statistics": fit_stats,
    "weight_fraction_basis": "normalized over the modeled crystalline phases",
    "project_path": "final.gpx",
    "profile_path": "fit.csv",
}
with (ROOT / "result.json").open("w") as handle:
    json.dump(result, handle, indent=2)
    handle.write("\n")

cells = [phase.get_cell() for phase in (mn, wo, haus)]
inst_final = hist.InstrumentParameters
wo_strain = wo.data["Histograms"][hist.name]["Mustrain"][1][0]
haus_strain = haus.data["Histograms"][hist.name]["Mustrain"][1][0]
fractions = {row["formula"]: (100 * row["weight_fraction"],
                               100 * row["weight_fraction_esd"])
             for row in phase_rows}

report = f"""# PXRD phase analysis

## Result

The crystalline model contains three phases (fractions normalized over these modeled crystalline phases):

- MnWO4, wolframite type, P2/c: **{fractions['MnWO4'][0]:.2f} ± {fractions['MnWO4'][1]:.2f} wt%**.
- WO3, monoclinic, P2_1/c: **{fractions['WO3'][0]:.2f} ± {fractions['WO3'][1]:.2f} wt%**.
- Mn3O4, tetragonal hausmannite, I4_1/amd: **{fractions['Mn3O4'][0]:.2f} ± {fractions['Mn3O4'][1]:.2f} wt%**.

The final full-range GSAS-II refinement gives Rwp = {fit_stats['Rwp_percent']:.3f}%, Rp = {fit_stats['Rp_percent']:.3f}%, Rexp = {fit_stats['Rexp_percent']:.3f}%, and goodness of fit = {fit_stats['goodness_of_fit']:.3f}. The quoted fraction uncertainties are covariance-derived one-sigma values and do not include model-selection or microabsorption systematics.

## Evidence and model selection

The precursor chemistry (WO3 + Mn3O4, 700 °C) and the observed 15.1°, 18.1°, and split 29.6/30.0° families identify the major product as P2/c MnWO4. No exact MnWO4 record was present in the supplied structure corpus, so same-stoichiometry analogues were screened. A P2/c CuWO4 wolframite parent with the chemically conservative Cu2+→Mn2+ substitution gave the best physically adequate model; its Mn-cell geometry remained octahedral and the refined model has Mn–O distances of approximately 2.10–2.21 Å and W–O distances of approximately 1.76–2.12 Å. Alternate FeWO4 coordinate records fit worse or produced poorer geometry.

The coherent residual families at 22.7–23.8°, 32.8–33.7°, and about 41.5° require monoclinic WO3. Two equivalent monoclinic records fitted substantially better than triclinic, orthorhombic, or tetragonal alternatives. The weak tetragonal Mn3O4 phase is supported by partly independent families near 31.84°, 37.47°, 58.12°, and 59.38°, plus the overlapped 35.68° family. Orthorhombic Mn3O4 refined below its uncertainty. MnO went to zero scale; Mn3WO6 and Mn2O3 only borrowed trace scale from overlapped lines and lacked their strongest unique families, so they were excluded.

The shared Cu K-alpha1/alpha2 wavelengths and 0.5 intensity ratio were fixed to the metadata. The accepted baseline uses one zero correction ({inst_final['Zero'][1]:.4f}°), a six-term smooth Chebyshev background, nonnegative X-only common width (X = {inst_final['X'][1]:.3f}; U = V = W = Y = 0), and FCJ asymmetry (SH/L = {inst_final['SH/L'][1]:.4f}). The effective polarization refined to {inst_final['Polariz.'][1]:.3f}. Unused size, roughness, H-strain, extinction, and texture terms were neutralized. Isotropic microstrain was retained only for WO3 ({wo_strain:.0f}) and Mn3O4 ({haus_strain:.0f}); anisotropic strain, size broadening, and axial/diagonal texture trials were not replay-stable or did not improve multiple families.

Refined cells are MnWO4 a = {cells[0]['length_a']:.5f} Å, b = {cells[0]['length_b']:.5f} Å, c = {cells[0]['length_c']:.5f} Å, beta = {cells[0]['angle_beta']:.4f}°; WO3 a = {cells[1]['length_a']:.5f} Å, b = {cells[1]['length_b']:.5f} Å, c = {cells[1]['length_c']:.5f} Å, beta = {cells[1]['angle_beta']:.4f}° (the source P2_1/c setting has a non-reduced beta near 136°); and Mn3O4 a = {cells[2]['length_a']:.5f} Å, c = {cells[2]['length_c']:.5f} Å.

## Remaining uncertainty

Mn3O4 is weak, broadened, and partly overlapped, so its approximately {fractions['Mn3O4'][0]:.1f} wt% fraction has appreciably larger systematic uncertainty than its formal one-sigma value; the strain model changes its integrated scale more than the covariance error suggests. WO3 and Mn3O4 atomic coordinates were therefore not refined. Fractions are crystalline-only: an amorphous contribution, if present, cannot be quantified without an internal standard. No additional crystalline phase is supported reliably by the remaining residual.
"""
(ROOT / "report.md").write_text(report)

print(json.dumps(result, indent=2))
print("converged", rvals["converged"], "max_shift_esd", rvals["Max shft/sig"])
print("cells", json.dumps(cells, indent=2))
print("profile", {k: inst_final[k][1] for k in
                  ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")})
