#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent


def run(tag: str, polar: bool, rough: bool) -> None:
    out = ROOT / f"intensity_{tag}.gpx"
    gpx = G2.G2Project(str(ROOT / "mn_parent_4000807.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    if polar:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
        gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")
    else:
        hist.clear_refinements({"Instrument Parameters": ["Polariz."]})
        hist.InstrumentParameters["Polariz."][1] = 0.5
    if rough:
        hist.SampleParameters["SurfRoughA"][0] = 0.5
        hist.SampleParameters["SurfRoughB"][0] = 0.01
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        gpx.set_Controls("parmMin", 0.0, ":0:SurfRoughA")
        gpx.set_Controls("parmMax", 1.0, ":0:SurfRoughA")
        gpx.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
        gpx.set_Controls("parmMax", 5.0, ":0:SurfRoughB")
    else:
        hist.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        hist.SampleParameters["SurfRoughA"][0] = 0.0
        hist.SampleParameters["SurfRoughB"][0] = 0.0
    gpx.set_Controls("cycles", 12)
    gpx.do_refinements([{}])
    gpx.do_refinements([{}])
    gpx.save()
    print(tag, "wR", round(hist.residuals.get("wR"), 6),
          "polar", round(hist.InstrumentParameters["Polariz."][1], 7),
          "rough", [round(hist.SampleParameters[k][0], 7)
                    for k in ("SurfRoughA", "SurfRoughB")],
          "mass", hist.ComputeMassFracs(), "frozen", gpx.get_Frozen())


run("polar", True, False)
run("rough", False, True)
run("polar_rough", True, True)
