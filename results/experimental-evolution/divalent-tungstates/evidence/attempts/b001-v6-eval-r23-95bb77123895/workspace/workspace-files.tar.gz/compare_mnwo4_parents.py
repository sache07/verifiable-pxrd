#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent

PARENTS = {
    # Classic single-crystal ferberite record used for the baseline.
    "9008124": [
        (0.50000, 0.67440, 0.25000),
        (0.00000, 0.17990, 0.25000),
        (0.21590, 0.10500, 0.56600),
        (0.25380, 0.37440, 0.10960),
    ],
    # Alternate P2/c FeWO4 thin-film records from the analogue search.
    "1567215": [
        (0.50000, 0.32319, 0.75000),
        (0.00000, 0.16416, 0.25000),
        (0.21670, 0.39683, 0.58330),
        (0.25830, 0.22504, 0.09000),
    ],
    "1568792": [
        (0.50000, 0.32171, 0.75000),
        (0.00000, 0.17719, 0.25000),
        (0.15180, 0.19740, 0.88820),
        (0.22834, 0.28754, 0.29937),
    ],
    # High-pressure P2/c CuWO4 is included as a source-condition challenge.
    "4000807": [
        (0.50000, 0.67010, 0.25000),
        (0.00000, 0.18670, 0.25000),
        (0.25300, 0.39700, 0.38520),
        (0.22600, 0.89700, 0.42630),
    ],
}


for cod_id, coords in PARENTS.items():
    out = ROOT / f"mn_parent_{cod_id}.gpx"
    gpx = G2.G2Project(str(ROOT / "two_phase_baseline.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    mn = gpx.phase(0)
    for atom, xyz in zip(mn.atoms(), coords):
        atom.coordinates = xyz
        atom.refinement_flags = " "
    # Rebuild the restrained nuisance model after the source-record change.
    hist.set_refinements({"Instrument Parameters": ["Zero", "X", "SH/L"]})
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
    gpx.set_Controls("cycles", 12)
    gpx.do_refinements([{}])
    gpx.do_refinements([{}])
    gpx.save()
    print(cod_id, "wR", round(hist.residuals.get("wR"), 6),
          "Rf", round(hist.residuals.get("0:0:Rf", -1), 6),
          "cell", {k: round(v, 6) for k, v in mn.get_cell().items()},
          "short", mn.ShortDistances())
