#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import pprint

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
GPX = ROOT / "trial_refined.gpx"


def status(tag: str, project: G2.G2Project) -> None:
    hist = project.histogram(0)
    phase = project.phase(0)
    print(f"\n--- {tag} ---")
    print("residuals", hist.residuals)
    print("cell", phase.get_cell())
    print("sample", {k: v for k, v in hist.SampleParameters.items()
                     if k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")})
    print("instrument", {k: hist.InstrumentParameters[k]
                         for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")})
    print("background", hist.Background[0])
    print("HAP scale", phase.data["Histograms"][hist.name]["Scale"])


project = G2.G2Project(newgpx=str(GPX))
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "lab_cuka.instprm"),
)
phase = project.add_phase(
    str(ROOT / "mnwo4_start.cif"),
    phasename="MnWO4_wolframite",
    histograms=[hist],
    fmthint="CIF",
)

project.set_Controls("cycles", 12)
hist.set_refinements({
    "Limits": [10.0, 100.0],
    "Background": {
        "type": "chebyschev-1",
        "no. coeffs": 6,
        "refine": True,
    },
})
hist.SampleParameters["Scale"][1] = False
phase.set_HAP_refinements({"Scale": True})
project.save()

project.do_refinements([{}])
status("background + phase scale", project)

hist.set_refinements({"Sample Parameters": ["Shift"]})
phase.set_refinements({"Cell": True})
project.do_refinements([{}])
status("+ specimen shift + cell", project)

# Use the requested low-dimensional, nonnegative Gaussian/Lorentzian profile.
inst = hist.InstrumentParameters
inst["U"][1] = max(0.0, inst["U"][1])
inst["V"][1] = 0.0
inst["W"][1] = max(0.2, inst["W"][1])
inst["X"][1] = max(0.01, inst["X"][1])
inst["Y"][1] = 0.0
inst["Z"][1] = 0.0
hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
project.do_refinements([{}])
status("+ U/W/X profile", project)

project.save()
print("\nVary list")
for item in project.get_VaryList():
    print(item)
print("\nAtoms")
for atom in phase.atoms():
    print(atom.label, atom.element, atom.coordinates, atom.occupancy, atom.uiso, atom.refinement_flags)
print("\nLast fit")
pprint.pp(project.get_LastFitResults())
