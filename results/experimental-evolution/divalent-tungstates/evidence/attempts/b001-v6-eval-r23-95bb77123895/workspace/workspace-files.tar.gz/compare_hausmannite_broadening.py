#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent


for kind in ("size", "strain"):
    out = ROOT / f"haus_{kind}.gpx"
    gpx = G2.G2Project(str(ROOT / "three_phase_baseline.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    hist.clear_refinements({"Instrument Parameters":
                            ["Zero", "Polariz.", "U", "W", "X", "SH/L"]})
    for phase in gpx.phases():
        phase.clear_refinements({"Cell": False})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    haus = gpx.phase(2)
    hap = haus.data["Histograms"][hist.name]
    if kind == "size":
        hap["Size"][1][0] = 2.0
        haus.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        gpx.set_Controls("parmMin", 0.01, "2:0:Size;i")
        gpx.set_Controls("parmMax", 1.0e6, "2:0:Size;i")
    else:
        hap["Mustrain"][1][0] = 100.0
        haus.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        gpx.set_Controls("parmMin", 0.0, "2:0:Mustrain;i")
        gpx.set_Controls("parmMax", 100000.0, "2:0:Mustrain;i")
    gpx.set_Controls("cycles", 12)
    gpx.do_refinements([{}])
    gpx.do_refinements([{}])
    gpx.save()
    value = hap["Size"][1][0] if kind == "size" else hap["Mustrain"][1][0]
    print(kind, "wR", round(hist.residuals.get("wR"), 6),
          "value", round(value, 7), "mass", hist.ComputeMassFracs(),
          "frozen", gpx.get_Frozen())
