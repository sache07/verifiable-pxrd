#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "two_phase_baseline.gpx"

gpx = G2.G2Project(str(ROOT / "broad_p1_strain.gpx"), newgpx=str(OUT))
hist = gpx.histogram(0)
mn, wo = gpx.phases()

# Rebuild the common profile after accepting WO3 and its isotropic strain.
inst = hist.InstrumentParameters
for key in ("U", "V", "W", "Y", "Z"):
    inst[key][1] = 0.0
    inst[key][2] = False
hist.set_refinements({"Instrument Parameters": ["Zero", "X", "SH/L"]})
gpx.set_Controls("parmMin", 0.0, ":0:X")
gpx.set_Controls("parmMin", 0.002, ":0:SH/L")
gpx.set_Controls("parmMax", 0.2, ":0:SH/L")
gpx.set_Controls("parmMin", -0.75, ":0:Zero")
gpx.set_Controls("parmMax", 0.75, ":0:Zero")

hist.set_refinements({
    "Background": {"type": "chebyschev-1", "no. coeffs": 6, "refine": True}
})
mn.set_HAP_refinements({"Scale": True})
wo.set_HAP_refinements({"Scale": True})
mn.set_refinements({"Cell": True})
wo.set_refinements({"Cell": True})

# Keep accepted WO3 isotropic microstrain; all other phase broadening is neutral.
mn_hap = mn.data["Histograms"][hist.name]
wo_hap = wo.data["Histograms"][hist.name]
mn_hap["Size"][1][0] = mn_hap["Size"][1][1] = 1.0e6
mn_hap["Mustrain"][1][0] = mn_hap["Mustrain"][1][1] = 0.0
wo_hap["Size"][1][0] = wo_hap["Size"][1][1] = 1.0e6
wo_hap["Mustrain"][0] = "isotropic"
wo_hap["Mustrain"][2] = [True, False, False]

gpx.set_Controls("cycles", 12)
gpx.do_refinements([{}])
gpx.do_refinements([{}])
gpx.save()

# Required replay check after save/reopen.
gpx = G2.G2Project(str(OUT))
gpx.do_refinements([{}])
gpx.save()
hist = gpx.histogram(0)
mn, wo = gpx.phases()
print("wR", hist.residuals.get("wR"), "R", hist.residuals.get("R"),
      "mass", hist.ComputeMassFracs())
print("profile", {k: hist.InstrumentParameters[k] for k in
                  ("Zero", "U", "V", "W", "X", "Y", "SH/L")})
print("Mn cell", mn.get_cell())
print("WO cell", wo.get_cell())
print("WO strain", wo.data["Histograms"][hist.name]["Mustrain"])
