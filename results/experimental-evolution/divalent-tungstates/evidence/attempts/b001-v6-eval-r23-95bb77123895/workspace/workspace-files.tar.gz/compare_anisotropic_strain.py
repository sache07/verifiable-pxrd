#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIspc as G2spc

ROOT = Path(__file__).resolve().parent


def prepare(tag: str):
    gpx = G2.G2Project(str(ROOT / "broad_p1_strain.gpx"),
                       newgpx=str(ROOT / f"anis_{tag}.gpx"))
    hist = gpx.histogram(0)
    for phase in gpx.phases():
        phase.clear_refinements({"Cell": False})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L"]})
    return gpx, hist, gpx.phase(1)


def finish(tag, gpx, hist, phase):
    gpx.set_Controls("cycles", 12)
    gpx.do_refinements([{}])
    gpx.do_refinements([{}])
    gpx.save()
    # Explicit reopen/replay check.
    replay = G2.G2Project(str(ROOT / f"anis_{tag}.gpx"))
    replay.do_refinements([{}])
    replay.save()
    rh = replay.histogram(0)
    rp = replay.phase(1)
    m = rp.data["Histograms"][rh.name]["Mustrain"]
    values = m[4] if m[0] == "generalized" else m[1][:2]
    print(tag, "wR", round(rh.residuals.get("wR"), 6),
          "model", m[0], "values", [round(v, 6) for v in values],
          "flags", m[5] if m[0] == "generalized" else m[2],
          "frozen", replay.get_Frozen())


for axis in ([1, 0, 0], [0, 1, 0], [0, 0, 1]):
    tag = "uni_" + "".join(map(str, axis))
    gpx, hist, phase = prepare(tag)
    m = phase.data["Histograms"][hist.name]["Mustrain"]
    m[1][0] = m[1][1] = 3631.6
    m[1][2] = 1.0
    phase.set_HAP_refinements({
        "Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}
    })
    gpx.set_Controls("parmMin", 0.0, "1:0:Mustrain;i")
    gpx.set_Controls("parmMax", 100000.0, "1:0:Mustrain;i")
    gpx.set_Controls("parmMin", 0.0, "1:0:Mustrain;a")
    gpx.set_Controls("parmMax", 100000.0, "1:0:Mustrain;a")
    finish(tag, gpx, hist, phase)

tag = "generalized"
gpx, hist, phase = prepare(tag)
m = phase.data["Histograms"][hist.name]["Mustrain"]
cell = phase.data["General"]["Cell"][1:7]
m[4] = list(G2spc.Muiso2Shkl(3631.6, phase.data["General"]["SGData"], cell))
phase.set_HAP_refinements({"Mustrain": {"type": "generalized", "refine": True}})
finish(tag, gpx, hist, phase)
