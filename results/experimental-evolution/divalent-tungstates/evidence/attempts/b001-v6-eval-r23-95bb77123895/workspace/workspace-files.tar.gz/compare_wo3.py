#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path("<RUN>/resources/b001-c04/cif")


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize(phase, hist) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][1][0] = 1.0e6
    hap["Size"][1][1] = 1.0e6
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def run(cod_id: str, label: str) -> None:
    gpx = G2.G2Project(
        str(ROOT / "baseline_zero_wx_shl.gpx"),
        newgpx=str(ROOT / f"wo3_{cod_id}.gpx"),
    )
    hist = gpx.histogram(0)
    mn = gpx.phase(0)
    # Phase screening begins with the established common profile held fixed.
    hist.clear_refinements({"Instrument Parameters": ["Zero", "W", "X", "SH/L"]})
    mn.clear_refinements({"Cell": False})
    wo = gpx.add_phase(
        str(cif_path(cod_id)), phasename=f"WO3_{cod_id}",
        histograms=[hist], fmthint="CIF")
    neutralize(wo, hist)
    wo.set_HAP_refinements({"Scale": True})
    gpx.set_Controls("parmMin", 0.0, "1:0:Scale")
    gpx.set_Controls("cycles", 10)
    gpx.do_refinements([{}])
    fixed = (hist.residuals.get("wR"), wo.data["Histograms"][hist.name]["Scale"][0])

    # Rebuild shared nuisance terms after the inventory change, then allow cells.
    hist.set_refinements({"Instrument Parameters": ["Zero", "X", "SH/L"]})
    mn.set_refinements({"Cell": True})
    wo.set_refinements({"Cell": True})
    gpx.do_refinements([{}])
    gpx.do_refinements([{}])
    gpx.save()
    print(cod_id, label,
          "fixed_wR", round(fixed[0], 5), "fixed_scale", round(fixed[1], 7),
          "refined_wR", round(hist.residuals.get("wR"), 5),
          "scale", round(wo.data["Histograms"][hist.name]["Scale"][0], 7),
          "cell", {k: round(v, 6) for k, v in wo.get_cell().items()},
          "Mn_cell", {k: round(v, 6) for k, v in mn.get_cell().items()},
          "profile", {k: round(hist.InstrumentParameters[k][1], 6)
                      for k in ("Zero", "X", "SH/L")})


for args in [
    ("1528915", "monoclinic_P21n"),
    ("2311041", "monoclinic_P21c_alt"),
    ("2106293", "triclinic_P-1"),
    ("2107312", "orthorhombic_Pnma"),
    ("1521532", "tetragonal_P4ncc"),
]:
    run(*args)
