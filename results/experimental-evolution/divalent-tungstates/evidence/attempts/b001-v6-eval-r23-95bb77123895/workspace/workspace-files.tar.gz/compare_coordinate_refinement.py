#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent


def run(tag: str, selected: set[str]) -> None:
    out = ROOT / f"coords_{tag}.gpx"
    gpx = G2.G2Project(str(ROOT / "intensity_polar.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    mn = gpx.phase(0)
    for atom in mn.atoms():
        atom.refinement_flags = "X" if atom.label in selected else " "
    # WO3 is minor; retain its source coordinates rather than overfitting them.
    for atom in gpx.phase(1).atoms():
        atom.refinement_flags = " "
    gpx.set_Controls("cycles", 12)
    gpx.do_refinements([{}])
    gpx.do_refinements([{}])
    gpx.save()
    # Save/reopen/replay to expose unstable coordinate solutions.
    gpx = G2.G2Project(str(out))
    gpx.do_refinements([{}])
    gpx.save()
    hist = gpx.histogram(0)
    mn = gpx.phase(0)
    print(tag, "wR", round(hist.residuals.get("wR"), 6),
          "Rf", round(hist.residuals.get("0:0:Rf", -1), 6),
          "mass", hist.ComputeMassFracs(),
          "coords", {a.label: tuple(round(v, 7) for v in a.coordinates)
                     for a in mn.atoms()},
          "short", mn.ShortDistances())


run("fixed", set())
run("metals", {"Mn1", "W1"})
run("oxygen", {"O1", "O2"})
run("all", {"Mn1", "W1", "O1", "O2"})
