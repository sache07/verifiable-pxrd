#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
AXES = ([1, 0, 0], [0, 1, 0], [0, 0, 1],
        [1, 0, 1], [1, 0, -1], [1, 1, 0], [0, 1, 1], [1, 1, 1])


for axis in AXES:
    tag = "".join("m" if v < 0 else str(v) for v in axis)
    out = ROOT / f"texture_{tag}.gpx"
    gpx = G2.G2Project(str(ROOT / "coords_all.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    mn, wo = gpx.phases()
    # Hold coordinates and line-shape nuisance terms while testing one MD axis.
    for phase in (mn, wo):
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_refinements({"Cell": False})
        phase.clear_HAP_refinements({"Pref.Ori.": True})
    hist.clear_refinements({"Instrument Parameters":
                            ["Zero", "Polariz.", "U", "W", "X", "SH/L"]})
    hap = mn.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][3] = list(axis)
    mn.set_HAP_refinements({"Pref.Ori.": True})
    gpx.set_Controls("parmMin", 0.2, "0:0:MD")
    gpx.set_Controls("parmMax", 5.0, "0:0:MD")
    gpx.set_Controls("cycles", 12)
    gpx.do_refinements([{}])
    gpx.do_refinements([{}])
    gpx.save()
    # Reopen/replay check.
    replay = G2.G2Project(str(out))
    replay.do_refinements([{}])
    replay.save()
    rh = replay.histogram(0)
    rmn = replay.phase(0)
    md = rmn.data["Histograms"][rh.name]["Pref.Ori."][1]
    print(tuple(axis), "wR", round(rh.residuals.get("wR"), 6),
          "MD", round(md, 7), "mass", rh.ComputeMassFracs())
