#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent


def run(phase_index: int, kind: str) -> None:
    tag = f"p{phase_index}_{kind}"
    gpx = G2.G2Project(str(ROOT / "wo3_2311041.gpx"),
                       newgpx=str(ROOT / f"broad_{tag}.gpx"))
    hist = gpx.histogram(0)
    phases = gpx.phases()
    # Hold the common profile, angular correction and cells while challenging
    # one phase broadening mechanism at a time.
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L"]})
    for phase in phases:
        phase.clear_refinements({"Cell": False})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    phase = phases[phase_index]
    hap = phase.data["Histograms"][hist.name]
    if kind == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 2.0
        hap["Size"][1][2] = 1.0
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        var = f"{phase_index}:0:Size;i"
        gpx.set_Controls("parmMin", 0.01, var)
        gpx.set_Controls("parmMax", 1.0e6, var)
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 100.0
        hap["Mustrain"][1][2] = 1.0
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        var = f"{phase_index}:0:Mustrain;i"
        gpx.set_Controls("parmMin", 0.0, var)
        gpx.set_Controls("parmMax", 100000.0, var)
    gpx.set_Controls("cycles", 12)
    gpx.do_refinements([{}])
    gpx.do_refinements([{}])
    gpx.save()
    value = (hap["Size"][1][0] if kind == "size"
             else hap["Mustrain"][1][0])
    print(tag, phase.name, "wR", round(hist.residuals.get("wR"), 6),
          "value", round(value, 7), "frozen", gpx.get_Frozen())


for p in (0, 1):
    for k in ("size", "strain"):
        run(p, k)
