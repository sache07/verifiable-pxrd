#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent


def run(name: str, angular: str, profile: tuple[str, ...], shl: bool = False):
    out = ROOT / f"baseline_{name}.gpx"
    project = G2.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"), str(ROOT / "lab_cuka.instprm"))
    phase = project.add_phase(
        str(ROOT / "mnwo4_start.cif"), phasename="MnWO4_wolframite",
        histograms=[hist], fmthint="CIF")
    # Remove the nonzero GSAS-II HAP defaults so the common profile is tested
    # without a hidden 1-micron size or 1000-microstrain contribution.
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][1][0] = 1.0e6
    hap["Size"][1][1] = 1.0e6
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    project.set_Controls("cycles", 10)
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {"type": "chebyschev-1", "no. coeffs": 6, "refine": True},
    })
    hist.SampleParameters["Scale"][1] = False
    phase.set_HAP_refinements({"Scale": True})
    project.do_refinements([{}])

    if angular == "Zero":
        hist.InstrumentParameters["Zero"][1] = -0.2
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        project.set_Controls("parmMin", -0.75, ":0:Zero")
        project.set_Controls("parmMax", 0.75, ":0:Zero")
    else:
        hist.SampleParameters["Shift"][0] = 500.0
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        project.set_Controls("parmMin", -1200.0, ":0:Shift")
        project.set_Controls("parmMax", 1200.0, ":0:Shift")
    phase.set_refinements({"Cell": True})
    project.do_refinements([{}])
    project.do_refinements([{}])

    inst = hist.InstrumentParameters
    for key, value in (("U", 1.0), ("V", 0.0), ("W", 10.0),
                       ("X", 1.0), ("Y", 0.0), ("Z", 0.0), ("SH/L", 0.002)):
        inst[key][1] = value
        inst[key][2] = False
    hist.set_refinements({"Instrument Parameters": list(profile)})
    for key in profile:
        project.set_Controls("parmMin", 0.0, f":0:{key}")
    if shl:
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        project.set_Controls("parmMin", 0.002, ":0:SH/L")
        project.set_Controls("parmMax", 0.2, ":0:SH/L")
    project.do_refinements([{}])
    project.do_refinements([{}])
    project.save()
    vals = {k: round(hist.InstrumentParameters[k][1], 7)
            for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")}
    print(name, "wR", round(hist.residuals.get("wR", -1), 5),
          "R", round(hist.residuals.get("R", -1), 5),
          "cell", {k: round(v, 7) for k, v in phase.get_cell().items()},
          "angular", hist.SampleParameters["Shift"], "inst", vals,
          "scale", phase.data["Histograms"][hist.name]["Scale"],
          "frozen", project.get_Frozen())
    return project


run("zero_wx", "Zero", ("W", "X"))
run("shift_wx", "Shift", ("W", "X"))
run("zero_uwx", "Zero", ("U", "W", "X"))
run("zero_wx_shl", "Zero", ("W", "X"), shl=True)
