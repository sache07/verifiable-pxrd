#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent

for axis in ([0, 0, 1], [1, 0, 0], [1, 0, 1], [1, 1, 0], [1, 1, 1]):
    tag = "".join(map(str, axis))
    out = ROOT / f"haus_texture_{tag}.gpx"
    gpx = G2.G2Project(str(ROOT / "haus_strain.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    hist.clear_refinements({"Instrument Parameters":
                            ["Zero", "Polariz.", "U", "W", "X", "SH/L"]})
    for phase in gpx.phases():
        phase.clear_refinements({"Cell": False})
        phase.clear_HAP_refinements({"Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    haus = gpx.phase(2)
    po = haus.data["Histograms"][hist.name]["Pref.Ori."]
    po[0], po[1], po[3] = "MD", 1.0, list(axis)
    haus.set_HAP_refinements({"Pref.Ori.": True})
    gpx.set_Controls("parmMin", 0.2, "2:0:MD")
    gpx.set_Controls("parmMax", 5.0, "2:0:MD")
    gpx.set_Controls("cycles", 12)
    gpx.do_refinements([{}])
    gpx.do_refinements([{}])
    gpx.save()
    print(tuple(axis), "wR", round(hist.residuals.get("wR"), 6),
          "MD", round(po[1], 7), "mass", hist.ComputeMassFracs())
