#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "three_phase_baseline.gpx"

gpx = G2.G2Project(str(ROOT / "watch_9001963.gpx"), newgpx=str(OUT))
hist = gpx.histogram(0)
mn, wo, haus = gpx.phases()

# Inventory changed: rebuild the smooth background, all scales, one angular
# correction, cells, polarization and the accepted common profile.
inst = hist.InstrumentParameters
for key in ("U", "V", "W", "Y", "Z"):
    inst[key][1] = 0.0
    inst[key][2] = False
hist.set_refinements({
    "Background": {"type": "chebyschev-1", "no. coeffs": 6, "refine": True},
    "Instrument Parameters": ["Zero", "Polariz.", "X", "SH/L"],
})
for phase in (mn, wo, haus):
    phase.set_refinements({"Cell": True})
    phase.set_HAP_refinements({"Scale": True})
    for atom in phase.atoms():
        atom.refinement_flags = " "

gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")
gpx.set_Controls("parmMin", 0.0, ":0:X")
gpx.set_Controls("parmMin", 0.002, ":0:SH/L")
gpx.set_Controls("parmMax", 0.2, ":0:SH/L")
gpx.set_Controls("parmMin", -0.75, ":0:Zero")
gpx.set_Controls("parmMax", 0.75, ":0:Zero")
gpx.set_Controls("parmMin", 0.0, "2:0:Scale")
gpx.set_Controls("cycles", 12)

gpx.do_refinements([{}])
gpx.do_refinements([{}])
gpx.save()

gpx = G2.G2Project(str(OUT))
gpx.do_refinements([{}])
gpx.save()
hist = gpx.histogram(0)
print("residuals", hist.residuals)
print("mass", hist.ComputeMassFracs())
print("profile", {k: hist.InstrumentParameters[k] for k in
                  ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")})
for phase in gpx.phases():
    print(phase.name, phase.get_cell(),
          phase.data["Histograms"][hist.name]["Scale"])
