#!/usr/bin/env python3
"""Build, refine and export the final GSAS-II CaWO4 model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
INSTRUMENT = ROOT / "instrument.instprm"
SOURCE_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/7/21/92/7219229.cif"
)
PROJECT = ROOT / "final.gpx"
OUTPUT_CIF = ROOT / "phase_1_CaWO4_scheelite.cif"


def last_shift(rvals: dict) -> float:
    shifts = rvals.get("lastShifts", {})
    return max((abs(float(value)) for value in shifts.values()), default=0.0)


def refine_to_stable(project: G2sc.G2Project, label: str) -> None:
    """Repeat a GSAS-II step so the last-cycle shifts, not only chi-square, settle."""
    for attempt in range(1, 7):
        project.do_refinements([{}])
        rvals = project.data["Covariance"]["data"]["Rvals"]
        shift = last_shift(rvals)
        print(
            f"STAGE {label} pass {attempt}: "
            f"Rwp={rvals['Rwp']:.8f}% GOF={rvals['GOF']:.8f} "
            f"last_shift/esd={shift:.5g}"
        )
        if attempt >= 2 and shift < 0.05 and abs(rvals.get("DelChi2", 1.0)) < 1e-5:
            break
    else:
        raise RuntimeError(f"Refinement stage {label!r} did not settle")


def main() -> None:
    project = G2sc.G2Project(newgpx=str(PROJECT))
    histogram = project.add_powder_histogram(
        str(PATTERN), str(INSTRUMENT), fmthint="comma"
    )
    phase = project.add_phase(
        str(SOURCE_CIF),
        phasename="CaWO4_scheelite",
        histograms=[histogram],
        fmthint="CIF",
    )
    project.update_ids()
    project.set_Controls("cycles", 12)

    # Use the phase scale, not the redundant histogram scale.
    histogram.data["Sample Parameters"]["Scale"][1] = False
    phase.set_HAP_refinements({"Scale": True})

    # Neutralize the active GSAS-II HAP defaults before any profile work.
    hap = phase.data["Histograms"][histogram.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]  # largest useful GSAS-II value (micrometres)
    hap["Size"][2][:] = [False, False, False]

    # A smooth, low-dimensional background is active throughout all later stages.
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
            }
        }
    )

    # Physical parameter bounds. V, X and Y stay fixed at zero, making the
    # Gaussian width U*tan(theta)^2 + W positive across the measured range.
    for variable, lower, upper in (
        ("0:0:Scale", 0.0, 1.0e6),
        (":0:Zero", -0.1, 0.1),
        (":0:U", 0.0, 1000.0),
        (":0:W", 0.0, 1000.0),
        (":0:Z", 0.0, 100.0),
        (":0:Polariz.", 0.0, 1.0),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)

    project.save()
    refine_to_stable(project, "background and scale")

    # Zero was selected over specimen displacement by a matched trial.
    phase.set_refinements({"Cell": True})
    histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_to_stable(project, "cell and zero")

    # Add identifiable global profile terms one at a time.
    histogram.set_refinements({"Instrument Parameters": ["W"]})
    refine_to_stable(project, "global W")
    histogram.set_refinements({"Instrument Parameters": ["U"]})
    refine_to_stable(project, "global U and W")
    histogram.data["Instrument Parameters"][0]["Z"][1] = 1.0
    histogram.set_refinements({"Instrument Parameters": ["Z"]})
    refine_to_stable(project, "global U, W and Z")

    # Effective polarization was not supplied in metadata and is identifiable.
    histogram.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine_to_stable(project, "effective polarization")

    # Atomic work follows inventory, position and profile stabilization.
    phase.set_refinements({"Atoms": {"O1": "X"}})
    refine_to_stable(project, "oxygen coordinates")
    project.set_Controls("parmMin", 0.0, variable="0::AUiso:2")
    project.set_Controls("parmMax", 0.1, variable="0::AUiso:2")
    phase.set_refinements({"Atoms": {"O1": "XU"}})
    refine_to_stable(project, "oxygen coordinates and Uiso")

    # One final replay with all selected flags active.
    refine_to_stable(project, "final replay")
    project.save()

    frozen = project.get_Frozen()
    if frozen:
        raise RuntimeError(f"Final project contains frozen variables: {frozen}")

    # Print the complete final HAP state, including fixed active values and flags.
    print("FINAL HAP")
    print(json.dumps(hap, indent=2, default=str))

    instrument = histogram.data["Instrument Parameters"][0]
    low, high = histogram.data["Limits"][1]
    grid = np.linspace(low, high, 10001)
    tan_theta = np.tan(np.radians(grid / 2.0))
    gaussian_variance = (
        instrument["U"][1] * tan_theta**2
        + instrument["V"][1] * tan_theta
        + instrument["W"][1]
    )
    lorentzian_width = (
        instrument["X"][1] / np.cos(np.radians(grid / 2.0))
        + instrument["Y"][1] * tan_theta
        + instrument["Z"][1]
    )
    if gaussian_variance.min() <= 0 or lorentzian_width.min() <= 0:
        raise RuntimeError("Final analytic profile becomes non-positive")

    phase.export_CIF(str(OUTPUT_CIF))

    x = np.asarray(histogram.getdata("X"), dtype=float)
    observed = np.asarray(histogram.getdata("Yobs"), dtype=float)
    calculated = np.asarray(histogram.getdata("Ycalc"), dtype=float)
    background = np.asarray(histogram.getdata("Background"), dtype=float)
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference, background)),
        delimiter=",",
        header=(
            "two_theta_deg,observed_intensity,calculated_intensity,"
            "difference_observed_minus_calculated,background_intensity"
        ),
        comments="",
        fmt="%.17g",
    )

    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    weights = np.asarray(histogram.getdata("Yweight"), dtype=float)
    rp = 100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed))
    rwp_check = 100.0 * np.sqrt(
        np.sum(weights * difference**2) / np.sum(weights * observed**2)
    )
    dof = int(rvals["Nobs"] - rvals["Nvars"])
    rexp = 100.0 * np.sqrt(dof / np.sum(weights * observed**2))
    cell = phase.get_cell()

    result = {
        "phases": [
            {
                "name": "CaWO4 (scheelite)",
                "formula": "CaWO4",
                "space_group": "I 41/a (No. 88)",
                "cif_path": OUTPUT_CIF.name,
                "weight_fraction": 1.0,
                "cell_angstrom_degrees": {
                    "a": cell["length_a"],
                    "b": cell["length_b"],
                    "c": cell["length_c"],
                    "alpha": cell["angle_alpha"],
                    "beta": cell["angle_beta"],
                    "gamma": cell["angle_gamma"],
                    "volume_angstrom3": cell["volume"],
                },
            }
        ],
        "weight_fraction_basis": "normalized over modeled crystalline phases",
        "fit_statistics": {
            "Rwp_percent": float(rvals["Rwp"]),
            "Rwp_recalculated_percent": float(rwp_check),
            "Rp_percent": float(rp),
            "Rexp_percent": float(rexp),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "degrees_of_freedom": dof,
            "n_observations": int(rvals["Nobs"]),
            "n_variables": int(rvals["Nvars"]),
        },
        "project_path": PROJECT.name,
        "profile_path": "fit.csv",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    print("FINAL RESULT")
    print(json.dumps(result, indent=2))
    print(
        "PROFILE POSITIVITY: "
        f"Gaussian variance {gaussian_variance.min():.6g}..{gaussian_variance.max():.6g} "
        f"centideg^2; Lorentzian width {lorentzian_width.min():.6g}.."
        f"{lorentzian_width.max():.6g} centideg"
    )


if __name__ == "__main__":
    main()
