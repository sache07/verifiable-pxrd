#!/usr/bin/env python3
"""Re-challenge a watched crystalline phase under the retained nuisance model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from rietveld_utils import cod_path, neutralize_phase, reopen, refine_replay, summary


parser = argparse.ArgumentParser()
parser.add_argument("cod_id")
parser.add_argument("name")
parser.add_argument("--base", default=".tmp/intensity_roughness_high_replay.gpx")
args = parser.parse_args()

root = Path(__file__).resolve().parent
out = root / ".tmp" / f"candidate_{args.name}.gpx"
gpx, hist = reopen(root / args.base, out)
gpx.set_Frozen()
phase = gpx.add_phase(
    str(cod_path(args.cod_id)),
    phasename=args.name,
    histograms=[hist],
    fmthint="CIF",
)
neutralize_phase(phase, hist)
phase.getHAPvalues(hist.name)["Scale"][0] = 0.05
phase.set_refinements({"Cell": True})
index = len(gpx.phases()) - 1
gpx.set_Controls("parmMin", 0.0, variable=f"{index}:0:Scale")
gpx.set_Controls("parmMax", 100.0, variable=f"{index}:0:Scale")
gpx.save()
gpx, hist = refine_replay(gpx, repeats=3)
result = summary(gpx, hist)
sample = hist.data["Sample Parameters"]
result["roughness"] = {"A": sample["SurfRoughA"], "B": sample["SurfRoughB"]}
print(json.dumps(result, indent=2, default=float))
