#!/usr/bin/env python3
"""Create the final project and replay the accepted model over every measured point."""

import argparse
import json
from pathlib import Path

from rietveld_utils import reopen, refine_replay, summary


parser = argparse.ArgumentParser()
parser.add_argument("source")
parser.add_argument("output")
parser.add_argument("--repeats", type=int, default=3)
args = parser.parse_args()

root = Path(__file__).resolve().parent
gpx, hist = reopen(root / args.source, root / args.output)
x = hist.data["data"][1][0]
hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
gpx.save()
gpx, hist = refine_replay(gpx, repeats=args.repeats)
state = summary(gpx, hist)
state["limits"] = hist.data["Limits"]
state["roughness"] = {
    "A": hist.data["Sample Parameters"]["SurfRoughA"],
    "B": hist.data["Sample Parameters"]["SurfRoughB"],
}
print(json.dumps(state, indent=2, default=float))
