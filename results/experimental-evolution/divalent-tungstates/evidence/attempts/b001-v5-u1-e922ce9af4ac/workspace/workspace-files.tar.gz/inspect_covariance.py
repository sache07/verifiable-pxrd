#!/usr/bin/env python3
"""Report refined values, standard uncertainties and strongest correlations."""

import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("project")
parser.add_argument("--minimum-correlation", type=float, default=0.90)
args = parser.parse_args()

gpx = G2sc.G2Project(gpxfile=args.project)
cov = gpx.data.get("Covariance", {}).get("data", {})
names = list(cov.get("varyList", []))
values = list(cov.get("variables", []))
sigmas = list(cov.get("sig", []))
matrix = np.asarray(cov.get("covMatrix", []), dtype=float)

parameters = [
    {"name": name, "value": float(value), "sigma": float(sigma)}
    for name, value, sigma in zip(names, values, sigmas)
]
correlations = []
if matrix.shape == (len(names), len(names)):
    sigma = np.sqrt(np.clip(np.diag(matrix), 0.0, None))
    denom = np.outer(sigma, sigma)
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            if abs(corr[i, j]) >= args.minimum_correlation:
                correlations.append(
                    {"first": names[i], "second": names[j], "correlation": float(corr[i, j])}
                )
correlations.sort(key=lambda item: abs(item["correlation"]), reverse=True)
print(json.dumps({"parameters": parameters, "correlations": correlations}, indent=2))
