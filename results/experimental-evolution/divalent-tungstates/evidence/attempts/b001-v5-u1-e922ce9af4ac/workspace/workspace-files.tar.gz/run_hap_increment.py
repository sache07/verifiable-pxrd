#!/usr/bin/env python3
"""Test one phase broadening model while preserving accepted terms on others."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from rietveld_utils import reopen, refine_replay, summary


parser = argparse.ArgumentParser()
parser.add_argument("base")
parser.add_argument("output")
parser.add_argument("phase", type=int, choices=(0, 1, 2, 3))
parser.add_argument("mode", choices=("size", "strain", "combo"))
args = parser.parse_args()

root = Path(__file__).resolve().parent
gpx, hist = reopen(root / args.base, root / args.output)
gpx.set_Frozen()
phase = gpx.phase(args.phase)
hap = phase.getHAPvalues(hist.name)
hap["Size"][0] = "isotropic"
hap["Size"][1] = [10.0, 10.0, 1.0]
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1] = [0.0, 0.0, 1.0]
hap["Mustrain"][2] = [False, False, False]

if args.mode in ("size", "combo"):
    starts = (0.060, 1.0, 0.035, 0.050)
    phase.setSampleProfile(hist, "size", "isotropic", starts[args.phase], LGmix=1.0)
    phase.set_HAP_refinements(
        {"Size": {"type": "isotropic", "refine": True,
                  "LGmix": {"value": 1.0, "refine": False}}}, [hist]
    )
    gpx.set_Controls("parmMin", 0.002, variable=f"{args.phase}:0:Size;i")
    gpx.set_Controls("parmMax", 10.0, variable=f"{args.phase}:0:Size;i")
if args.mode in ("strain", "combo"):
    starts = (5000.0, 800.0, 25000.0, 10000.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", starts[args.phase], LGmix=1.0)
    phase.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True,
                      "LGmix": {"value": 1.0, "refine": False}}}, [hist]
    )
    gpx.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;i")
    gpx.set_Controls("parmMax", 100000.0, variable=f"{args.phase}:0:Mustrain;i")

gpx, hist = refine_replay(gpx, repeats=3)
print(json.dumps(summary(gpx, hist), indent=2, default=float))
