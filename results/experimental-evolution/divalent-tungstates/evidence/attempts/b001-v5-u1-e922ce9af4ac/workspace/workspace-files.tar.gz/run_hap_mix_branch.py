#!/usr/bin/env python3
"""Refine a sample broadening term and its Gaussian/Lorentzian mixing."""

import argparse
import json
from pathlib import Path

from rietveld_utils import reopen, refine_replay, summary


parser = argparse.ArgumentParser()
parser.add_argument("phase", type=int, choices=(0, 1, 2))
parser.add_argument("mode", choices=("size", "strain"))
parser.add_argument("mix", type=float)
args = parser.parse_args()

root = Path(__file__).resolve().parent
tag = str(args.mix).replace(".", "p")
out = root / ".tmp" / f"hapmix_p{args.phase}_{args.mode}_{tag}.gpx"
gpx, hist = reopen(root / ".tmp" / "base_zero.gpx", out)
phase = gpx.phase(args.phase)

if args.mode == "size":
    start = 0.06 if args.phase == 0 else 0.04
    phase.setSampleProfile(hist, "size", "isotropic", start, LGmix=args.mix)
    phase.set_HAP_refinements(
        {"Size": {"type": "isotropic", "refine": True,
                  "LGmix": {"value": args.mix, "refine": True}}}, [hist]
    )
    gpx.set_Controls("parmMin", 0.002, variable=f"{args.phase}:0:Size;i")
    gpx.set_Controls("parmMax", 10.0, variable=f"{args.phase}:0:Size;i")
    gpx.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Size;mx")
    gpx.set_Controls("parmMax", 1.0, variable=f"{args.phase}:0:Size;mx")
else:
    start = 6000.0 if args.phase == 0 else 15000.0
    phase.setSampleProfile(hist, "microstrain", "isotropic", start, LGmix=args.mix)
    phase.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True,
                      "LGmix": {"value": args.mix, "refine": True}}}, [hist]
    )
    gpx.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;i")
    gpx.set_Controls("parmMax", 100000.0, variable=f"{args.phase}:0:Mustrain;i")
    gpx.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;mx")
    gpx.set_Controls("parmMax", 1.0, variable=f"{args.phase}:0:Mustrain;mx")

gpx, hist = refine_replay(gpx, repeats=2)
print(json.dumps(summary(gpx, hist), indent=2, default=float))
