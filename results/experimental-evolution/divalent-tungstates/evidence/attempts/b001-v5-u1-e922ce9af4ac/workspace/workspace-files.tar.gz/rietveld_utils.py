#!/usr/bin/env python3
"""Shared helpers for the reversible GSAS-II branch refinements."""

from __future__ import annotations

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize_phase(phase, hist) -> None:
    """Remove profile/texture HAP defaults while retaining a refinable scale."""
    hap = phase.getHAPvalues(hist.name)
    hap["Scale"][:] = [0.1, True]
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    # GSAS-II caps isotropic size at 10 micrometres when preparing a refinement.
    # That cap is effectively neutral at this pattern's resolution.
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][4] = [10.0, 10.0, 10.0, 0.0, 0.0, 0.0]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][4] = [0.0 for _ in hap["Mustrain"][4]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]


def set_common_profile(hist, values: dict[str, float], refine=()) -> None:
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        value = float(values.get(key, 0.0))
        inst[key][0] = inst[key][1] = value
        inst[key][2] = key in refine


def set_geometry(hist, geometry: str) -> None:
    sample = hist.data["Sample Parameters"]
    inst = hist.data["Instrument Parameters"][0]
    inst["Zero"][0] = inst["Zero"][1] = 0.0
    inst["Zero"][2] = False
    sample["Shift"][:] = [0.0, False]
    if geometry == "zero":
        inst["Zero"][0] = inst["Zero"][1] = 0.40
        inst["Zero"][2] = True
    elif geometry == "displacement":
        sample["Shift"][:] = [-700.0, True]
    else:
        raise ValueError(f"unknown geometry {geometry!r}")


def build_project(
    output: Path,
    phase_specs: list[tuple[str, str]],
    geometry: str,
    common_profile: dict[str, float] | None = None,
    background_terms: int = 8,
):
    output.parent.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(newgpx=str(output))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    for cod_id, name in phase_specs:
        phase = gpx.add_phase(
            str(cod_path(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        neutralize_phase(phase, hist)

    coeffs = [1200.0, -800.0, 500.0, -250.0, 100.0, -40.0, 10.0, 0.0]
    if background_terms > len(coeffs):
        coeffs += [0.0] * (background_terms - len(coeffs))
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": background_terms,
                "coeffs": coeffs[:background_terms],
            },
        }
    )

    sample = hist.data["Sample Parameters"]
    sample["Scale"][:] = [1.0, False]
    sample["Transparency"][:] = [0.0, False]
    sample["SurfRoughA"][:] = [0.0, False]
    sample["SurfRoughB"][:] = [0.0, False]
    sample["Absorption"][:] = [0.0, False]
    sample["DisplaceX"][:] = [0.0, False]
    sample["DisplaceY"][:] = [0.0, False]
    set_geometry(hist, geometry)

    if common_profile is None:
        common_profile = {"U": 45.0, "V": 0.0, "W": 4.0, "X": 5.0, "Y": 0.0,
                          "Z": 0.0, "SH/L": 0.01}
    set_common_profile(hist, common_profile)

    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    gpx.save()
    return gpx, hist


def reopen(source: Path, output: Path | None = None):
    if output is None:
        gpx = G2sc.G2Project(gpxfile=str(source))
    else:
        gpx = G2sc.G2Project(gpxfile=str(source), newgpx=str(output))
    return gpx, gpx.histogram(0)


def refine_replay(gpx, repeats: int = 2):
    """Refine, save/reopen between runs, and return the reopened project."""
    path = Path(gpx.filename)
    for _ in range(repeats):
        gpx.do_refinements([{}])
        gpx.save()
        gpx = G2sc.G2Project(gpxfile=str(path))
    return gpx, gpx.histogram(0)


def summary(gpx, hist) -> dict:
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = {}
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist.name)
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "microstrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    return {
        "file": gpx.filename,
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "GOF": _gof(gpx),
        "zero": inst["Zero"][1],
        "shift_micrometre": sample["Shift"][0],
        "profile": {k: inst[k][1] for k in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": gpx.get_Frozen(),
        "phases": phases,
    }


def _gof(gpx) -> float | None:
    cov = gpx.data.get("Covariance", {}).get("data", {})
    if "GOF" in cov:
        return float(cov["GOF"])
    if "Rvals" in cov and "GOF" in cov["Rvals"]:
        return float(cov["Rvals"]["GOF"])
    return None
