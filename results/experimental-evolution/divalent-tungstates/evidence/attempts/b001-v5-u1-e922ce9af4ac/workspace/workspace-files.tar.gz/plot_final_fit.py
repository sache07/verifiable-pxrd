#!/usr/bin/env python3
"""Create a diagnostic view of the submitted fitted profile."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


root = Path(__file__).resolve().parent
data = np.genfromtxt(root / "fit.csv", delimiter=",", names=True)
x = data["two_theta_deg"]
yobs = data["observed_counts"]
ycalc = data["calculated_counts"]
diff = data["difference_counts"]

figure, axes = plt.subplots(
    2,
    1,
    figsize=(14, 7),
    sharex=True,
    gridspec_kw={"height_ratios": [3, 1], "hspace": 0.04},
)
axes[0].plot(x, yobs, color="black", linewidth=0.65, label="observed")
axes[0].plot(x, ycalc, color="#d62728", linewidth=0.7, label="calculated")
axes[0].set_ylabel("counts")
axes[0].legend(frameon=False, loc="upper right")
axes[0].set_title("Final four-phase Rietveld fit")
axes[1].axhline(0.0, color="0.65", linewidth=0.7)
axes[1].plot(x, diff, color="#1f77b4", linewidth=0.6)
axes[1].set_ylabel("obs − calc")
axes[1].set_xlabel(r"2$\theta$ (degrees, Cu K$\alpha$)")
axes[1].set_xlim(x[0], x[-1])
figure.savefig(root / ".tmp" / "final_fit.png", dpi=150, bbox_inches="tight")
