#!/usr/bin/env python3
"""Print only the decision variables for texture branches."""

import argparse
import json
from pathlib import Path

from rietveld_utils import reopen, summary


parser = argparse.ArgumentParser()
parser.add_argument("projects", nargs="+")
args = parser.parse_args()

for item in args.projects:
    gpx, hist = reopen(Path(item))
    state = summary(gpx, hist)
    active = []
    for phase in gpx.phases():
        pref = phase.getHAPvalues(hist.name)["Pref.Ori."]
        if pref[2]:
            active.append({"phase": phase.name, "ratio": pref[1], "axis": pref[3]})
    print(json.dumps({"file": item, "Rwp": state["Rwp"], "Rp": state["Rp"], "texture": active}))
