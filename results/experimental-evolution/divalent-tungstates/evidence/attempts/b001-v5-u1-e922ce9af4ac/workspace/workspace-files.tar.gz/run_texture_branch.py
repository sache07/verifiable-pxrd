#!/usr/bin/env python3
"""Test one March-Dollase axis while preserving the common physical model."""

import argparse
import json
from pathlib import Path

from rietveld_utils import reopen, refine_replay, summary


parser = argparse.ArgumentParser()
parser.add_argument("phase", type=int, choices=(0, 1, 2, 3))
parser.add_argument("h", type=int)
parser.add_argument("k", type=int)
parser.add_argument("l", type=int)
parser.add_argument("--source", default=".tmp/intensity_four_roughness_high.gpx")
parser.add_argument("--tag", default="")
parser.add_argument("--repeats", type=int, default=3)
parser.add_argument("--start", type=float, default=0.85)
args = parser.parse_args()

root = Path(__file__).resolve().parent
axis = [args.h, args.k, args.l]
axis_tag = "".join(str(value).replace("-", "m") for value in axis)
tag = f"_{args.tag}" if args.tag else ""
out = root / ".tmp" / f"texture_p{args.phase}_{axis_tag}{tag}.gpx"
gpx, hist = reopen(root / args.source, out)
gpx.set_Frozen()
phase = gpx.phase(args.phase)
hap = phase.getHAPvalues(hist.name)
hap["Pref.Ori."][0] = "MD"
hap["Pref.Ori."][1] = args.start
hap["Pref.Ori."][2] = True
hap["Pref.Ori."][3] = axis
gpx.set_Controls("parmMin", 0.2, variable=f"{args.phase}:0:MD")
gpx.set_Controls("parmMax", 5.0, variable=f"{args.phase}:0:MD")
gpx.save()
gpx, hist = refine_replay(gpx, repeats=args.repeats)
print(json.dumps(summary(gpx, hist), indent=2, default=float))
