#!/usr/bin/env python3
"""Combine the accepted single-phase isotropic size terms."""

import json
from pathlib import Path

from rietveld_utils import reopen, refine_replay, summary


root = Path(__file__).resolve().parent
gpx, hist = reopen(root / ".tmp" / "hap_p0_size.gpx", root / ".tmp" / "combined_sizes.gpx")
phase = gpx.phase(2)
phase.setSampleProfile(hist, "size", "isotropic", 0.02, LGmix=1.0)
phase.set_HAP_refinements(
    {"Size": {"type": "isotropic", "refine": True,
              "LGmix": {"value": 1.0, "refine": False}}}, [hist]
)
gpx.set_Controls("parmMin", 0.002, variable="2:0:Size;i")
gpx.set_Controls("parmMax", 10.0, variable="2:0:Size;i")
gpx, hist = refine_replay(gpx, repeats=3)
print(json.dumps(summary(gpx, hist), indent=2, default=float))
