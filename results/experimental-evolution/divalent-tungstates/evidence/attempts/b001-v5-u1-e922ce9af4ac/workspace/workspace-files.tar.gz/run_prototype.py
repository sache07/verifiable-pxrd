#!/usr/bin/env python3
"""Prototype three-phase GSAS-II refinement."""

from pathlib import Path
from pprint import pprint

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize_phase(phase, hist):
    hap = phase.getHAPvalues(hist.name)
    hap["Scale"][:] = [0.1, True]
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [1.0e6, 1.0e6, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][4] = [1.0e6, 1.0e6, 1.0e6, 0.0, 0.0, 0.0]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][4] = [0.0 for _ in hap["Mustrain"][4]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


gpx = G2sc.G2Project(newgpx=str(ROOT / ".tmp" / "prototype.gpx"))
hist = gpx.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "instrument.instprm"),
    fmthint="comma",
)
phase_specs = [
    ("9009811", "PbWO4_scheelite"),
    ("1528915", "WO3_monoclinic"),
    ("9012124", "Pb3O4_minium"),
]
for cod_id, name in phase_specs:
    phase = gpx.add_phase(
        str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
    )
    neutralize_phase(phase, hist)

hist.set_refinements({
    "Limits": [10.0, 100.0],
    "Background": {
        "type": "chebyschev-1",
        "refine": True,
        "no. coeffs": 8,
        "coeffs": [1200.0, -800.0, 500.0, -250.0, 100.0, -40.0, 10.0, 0.0],
    },
})
sample = hist.data["Sample Parameters"]
sample["Scale"][:] = [1.0, False]
sample["Shift"][:] = [-700.0, True]
sample["Transparency"][:] = [0.0, False]
sample["SurfRoughA"][:] = [0.0, False]
sample["SurfRoughB"][:] = [0.0, False]
sample["Absorption"][:] = [0.0, False]
sample["DisplaceX"][:] = [0.0, False]
sample["DisplaceY"][:] = [0.0, False]

inst = hist.data["Instrument Parameters"][0]
for key, value in {"U": 10.0, "V": 0.0, "W": 15.0, "X": 1.0, "Y": 0.0,
                   "Z": 0.0, "SH/L": 0.01}.items():
    inst[key][0] = inst[key][1] = value
    inst[key][2] = False

gpx.set_Controls("cycles", 10)
gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5

def show(label):
    print("\n###", label)
    print("residuals", hist.residuals)
    print("sample Shift", sample["Shift"])
    print("instrument", {k: inst[k] for k in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    for p in gpx.phases():
        h = p.getHAPvalues(hist.name)
        print(p.name, "cell", p.get_cell(), "scale", h["Scale"], "size", h["Size"], "micro", h["Mustrain"])
    cov = gpx.data.get("Covariance", {}).get("data", {})
    print("vary", list(zip(cov.get("varyList", []), cov.get("variables", []), cov.get("sig", []))))


gpx.save()
gpx.do_refinements([{}])
show("background scales displacement")

for phase in gpx.phases():
    phase.set_refinements({"Cell": True})
gpx.do_refinements([{}])
show("plus cells")

hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
for variable, minimum, maximum in [
    (":0:U", 0.0, 200.0),
    (":0:W", 0.0, 200.0),
    (":0:X", 0.0, 100.0),
    (":0:SH/L", 0.001, 0.1),
]:
    gpx.set_Controls("parmMin", minimum, variable=variable)
    gpx.set_Controls("parmMax", maximum, variable=variable)
gpx.do_refinements([{}])
show("plus common profile")
gpx.save()
