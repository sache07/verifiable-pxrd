#!/usr/bin/env python3
"""Calibrate the common profile on sharp WO3 families across the scan."""

import argparse
import json
from pathlib import Path

from rietveld_utils import reopen, refine_replay, set_common_profile, summary


starts = {
    "low": {"U": 15.0, "V": 0.0, "W": 2.0, "X": 2.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.005},
    "mid": {"U": 45.0, "V": 0.0, "W": 5.0, "X": 5.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.015},
    "high": {"U": 100.0, "V": 0.0, "W": 15.0, "X": 10.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.040},
}
parser = argparse.ArgumentParser()
parser.add_argument("start", choices=starts)
parser.add_argument("--base", default=".tmp/combined_sizes.gpx")
parser.add_argument("--tag", default="")
args = parser.parse_args()

root = Path(__file__).resolve().parent
tag = f"_{args.tag}" if args.tag else ""
out = root / ".tmp" / f"sharp_profile{tag}_{args.start}.gpx"
gpx, hist = reopen(root / args.base, out)
gpx.set_Frozen()

# Retain windows around strong or resolved monoclinic-WO3 families. The other
# modeled phases remain present, but their parameters are held fixed here.
windows = [
    (23.30, 25.12),
    (33.45, 34.25),
    (41.70, 42.50),
    (47.45, 48.85),
    (54.35, 54.75),
    (60.20, 63.00),
    (70.70, 72.25),
    (76.20, 77.55),
    (82.90, 85.10),
    (86.20, 89.20),
]
# Zero weights outside the diagnostic windows in this throwaway calibration
# branch. This avoids a GSAS-II masked-array issue when many disjoint excluded
# regions are scripted. The submitted project retains all original weights.
import numpy as np

xyw = hist.data["data"][1]
keep = np.zeros(len(xyw[0]), dtype=bool)
for low, high in windows:
    keep |= (xyw[0] >= low) & (xyw[0] <= high)
xyw[2][~keep] = 0.0
hist.Excluded([])

hist.clear_refinements({"Background": True, "Sample Parameters": ["Shift"]})
hist.data["Instrument Parameters"][0]["Zero"][2] = False
for phase in gpx.phases():
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True}, [hist])

set_common_profile(hist, starts[args.start], refine=("U", "W", "X", "SH/L"))
for variable, minimum, maximum in [
    (":0:U", 0.0, 200.0),
    (":0:W", 0.0, 200.0),
    (":0:X", 0.0, 100.0),
    (":0:SH/L", 0.001, 0.10),
]:
    gpx.set_Controls("parmMin", minimum, variable=variable)
    gpx.set_Controls("parmMax", maximum, variable=variable)

gpx, hist = refine_replay(gpx, repeats=3)
print(json.dumps(summary(gpx, hist), indent=2, default=float))
