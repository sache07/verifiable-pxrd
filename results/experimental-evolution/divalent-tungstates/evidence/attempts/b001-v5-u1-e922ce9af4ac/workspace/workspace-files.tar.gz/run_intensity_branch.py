#!/usr/bin/env python3
"""Compare shared background, polarization and surface-roughness branches."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from rietveld_utils import reopen, refine_replay, summary


parser = argparse.ArgumentParser()
parser.add_argument("mode", choices=("bg6", "bg10", "polarization", "roughness"))
parser.add_argument("--start", default="mid", choices=("low", "mid", "high"))
parser.add_argument("--base", default=".tmp/hap_neutron_combined_p1_strain.gpx")
parser.add_argument("--tag", default="")
args = parser.parse_args()

root = Path(__file__).resolve().parent
suffix = f"_{args.start}" if args.mode in ("polarization", "roughness") else ""
tag = f"_{args.tag}" if args.tag else ""
out = root / ".tmp" / f"intensity{tag}_{args.mode}{suffix}.gpx"
gpx, hist = reopen(root / args.base, out)
gpx.set_Frozen()

if args.mode.startswith("bg"):
    nterms = int(args.mode[2:])
    old = list(hist.data["Background"][0][3:])
    coeffs = old[:nterms] + [0.0] * max(0, nterms - len(old))
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True,
                        "no. coeffs": nterms, "coeffs": coeffs}}
    )
elif args.mode == "polarization":
    starts = {"low": 0.2, "mid": 0.5, "high": 0.8}
    value = starts[args.start]
    hist.data["Instrument Parameters"][0]["Polariz."][:] = [value, value, True]
    gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
elif args.mode == "roughness":
    starts = {
        "low": (0.3, 0.02),
        "mid": (0.6, 0.08),
        "high": (0.85, 0.20),
    }
    a, b = starts[args.start]
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"][:] = [a, True]
    sample["SurfRoughB"][:] = [b, True]
    gpx.set_Controls("parmMin", 0.001, variable=":0:SurfRoughA")
    gpx.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
    gpx.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    gpx.set_Controls("parmMax", 2.0, variable=":0:SurfRoughB")

gpx, hist = refine_replay(gpx, repeats=3)
result = summary(gpx, hist)
inst = hist.data["Instrument Parameters"][0]
sample = hist.data["Sample Parameters"]
result["background"] = hist.data["Background"][0]
result["polarization"] = inst["Polariz."]
result["roughness"] = {
    "A": sample["SurfRoughA"],
    "B": sample["SurfRoughB"],
}
print(json.dumps(result, indent=2, default=float))
