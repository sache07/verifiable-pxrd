#!/usr/bin/env python3
"""Run one reversible isotropic size-only or strain-only branch."""

import argparse
import json
from pathlib import Path

from rietveld_utils import reopen, refine_replay, summary


parser = argparse.ArgumentParser()
parser.add_argument("phase", type=int, choices=(0, 1, 2))
parser.add_argument("mode", choices=("size", "strain", "combo"))
parser.add_argument("--base", default=".tmp/base_zero.gpx")
parser.add_argument("--tag", default="")
args = parser.parse_args()

root = Path(__file__).resolve().parent
tag = f"_{args.tag}" if args.tag else ""
out = root / ".tmp" / f"hap{tag}_p{args.phase}_{args.mode}.gpx"
gpx, hist = reopen(root / args.base, out)
gpx.set_Frozen()
for item in gpx.phases():
    hap = item.getHAPvalues(hist.name)
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
phase = gpx.phase(args.phase)
if args.mode in ("size", "combo"):
    size_starts = (0.06, 0.5, 0.035)
    phase.setSampleProfile(hist, "size", "isotropic", size_starts[args.phase], LGmix=1.0)
    phase.set_HAP_refinements(
        {"Size": {"type": "isotropic", "refine": True, "LGmix": {"value": 1.0, "refine": False}}},
        [hist],
    )
    gpx.set_Controls("parmMin", 0.002, variable=f"{args.phase}:0:Size;i")
    gpx.set_Controls("parmMax", 10.0, variable=f"{args.phase}:0:Size;i")
if args.mode in ("strain", "combo"):
    phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=1.0)
    phase.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True, "LGmix": {"value": 1.0, "refine": False}}},
        [hist],
    )
    gpx.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;i")
    gpx.set_Controls("parmMax", 100000.0, variable=f"{args.phase}:0:Mustrain;i")

gpx, hist = refine_replay(gpx, repeats=3)
print(json.dumps(summary(gpx, hist), indent=2, default=float))
