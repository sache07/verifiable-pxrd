#!/usr/bin/env python3
"""Replay zero/displacement branches under the calibrated common profile."""

import argparse
import json
from pathlib import Path

from rietveld_utils import reopen, refine_replay, set_common_profile, set_geometry, summary


parser = argparse.ArgumentParser()
parser.add_argument("geometry", choices=("zero", "displacement"))
parser.add_argument("--base", default=".tmp/combined_sizes.gpx")
parser.add_argument("--tag", default="final")
args = parser.parse_args()

root = Path(__file__).resolve().parent
out = root / ".tmp" / f"geometry_{args.tag}_{args.geometry}.gpx"
gpx, hist = reopen(root / args.base, out)
gpx.set_Frozen()
set_common_profile(
    hist,
    {"U": 14.88544, "V": 0.0, "W": 9.17492, "X": 4.42735,
     "Y": 0.0, "Z": 0.0, "SH/L": 0.0142312},
    refine=(),
)
set_geometry(hist, args.geometry)
gpx, hist = refine_replay(gpx, repeats=3)
print(json.dumps(summary(gpx, hist), indent=2, default=float))
