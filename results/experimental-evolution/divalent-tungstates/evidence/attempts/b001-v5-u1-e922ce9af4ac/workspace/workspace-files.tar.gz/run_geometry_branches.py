#!/usr/bin/env python3
"""Compare zero-only and specimen-displacement-only clean branches."""

import json
from pathlib import Path

from rietveld_utils import build_project, refine_replay, summary


ROOT = Path(__file__).resolve().parent
PHASES = [
    ("9009811", "PbWO4_scheelite"),
    ("1528915", "WO3_monoclinic"),
    ("9012124", "Pb3O4_minium"),
]

results = {}
for geometry in ("zero", "displacement"):
    path = ROOT / ".tmp" / f"base_{geometry}.gpx"
    gpx, hist = build_project(path, PHASES, geometry)
    gpx, hist = refine_replay(gpx, repeats=3)
    results[geometry] = summary(gpx, hist)
print(json.dumps(results, indent=2, default=float))
