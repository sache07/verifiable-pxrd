#!/usr/bin/env python3
"""Export CIFs and the fitted profile from the submitted GSAS-II project."""

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
gpx = G2sc.G2Project(gpxfile=str(root / "final.gpx"))
hist = gpx.histogram(0)

cif_names = {
    "PbWO4": "PbWO4.cif",
    "WO3": "WO3.cif",
    "Pb3O4": "Pb3O4.cif",
    "PbO_massicot": "PbO_massicot.cif",
}
for phase in gpx.phases():
    phase.export_CIF(str(root / cif_names[phase.name]))

x, yobs, weight, ycalc, background, difference = hist.data["data"][1][:6]
with (root / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(
        [
            "two_theta_deg",
            "observed_counts",
            "calculated_counts",
            "difference_counts",
            "background_counts",
        ]
    )
    writer.writerows(zip(x, yobs, ycalc, difference, background))

cov = gpx.data.get("Covariance", {}).get("data", {})
vary_names = list(cov.get("varyList", []))
vary_values = list(cov.get("variables", []))
vary_sigmas = list(cov.get("sig", []))
parameter_sigma = dict(zip(vary_names, vary_sigmas))
parameter_value = dict(zip(vary_names, vary_values))

summary = {
    "residuals": hist.residuals,
    "limits": hist.data["Limits"],
    "n_profile_points": int(len(x)),
    "n_refined_parameters": len(vary_names),
    "mass_fractions": hist.ComputeMassFracs(),
    "phases": {},
    "max_abs_difference_identity_error": float(np.max(np.abs((yobs - ycalc) - difference))),
}
for index, phase in enumerate(gpx.phases()):
    hap = phase.getHAPvalues(hist.name)
    summary["phases"][phase.name] = {
        "cif": cif_names[phase.name],
        "space_group": phase.data["General"]["SGData"]["SpGrp"],
        "cell": phase.get_cell(),
        "scale": hap["Scale"][0],
        "scale_sigma": parameter_sigma.get(f"{index}:0:Scale"),
        "size_micrometre": hap["Size"][1][0],
        "microstrain": hap["Mustrain"][1][0],
        "march_dollase": hap["Pref.Ori."][1],
        "march_axis": hap["Pref.Ori."][3],
        "march_sigma": parameter_sigma.get(f"{index}:0:MD"),
    }
print(json.dumps(summary, indent=2, default=float))
