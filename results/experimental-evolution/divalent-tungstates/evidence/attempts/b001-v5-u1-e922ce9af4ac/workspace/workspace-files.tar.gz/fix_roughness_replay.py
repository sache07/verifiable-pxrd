#!/usr/bin/env python3
"""Condition on the accepted roughness correction and replay all other terms."""

import argparse
import json
from pathlib import Path

from rietveld_utils import reopen, refine_replay, summary


parser = argparse.ArgumentParser()
parser.add_argument("source")
parser.add_argument("output")
parser.add_argument("--repeats", type=int, default=3)
args = parser.parse_args()

root = Path(__file__).resolve().parent
gpx, hist = reopen(root / args.source, root / args.output)
sample = hist.data["Sample Parameters"]
sample["SurfRoughA"][1] = False
sample["SurfRoughB"][1] = False
gpx.save()
gpx, hist = refine_replay(gpx, repeats=args.repeats)
state = summary(gpx, hist)
state["roughness"] = {
    "A": hist.data["Sample Parameters"]["SurfRoughA"],
    "B": hist.data["Sample Parameters"]["SurfRoughB"],
}
print(json.dumps(state, indent=2, default=float))
