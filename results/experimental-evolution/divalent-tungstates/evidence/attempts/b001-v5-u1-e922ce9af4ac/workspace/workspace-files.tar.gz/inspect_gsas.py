#!/usr/bin/env python3
"""Create a small GSAS-II project and report its initial data structures."""

from pathlib import Path
from pprint import pprint

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


gpx = G2sc.G2Project(newgpx=str(ROOT / ".tmp" / "initial.gpx"))
hist = gpx.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "instrument.instprm"),
    fmthint="comma",
)
for cod_id, name in [("9009811", "PbWO4_scheelite"), ("1528915", "WO3_monoclinic")]:
    gpx.add_phase(
        str(cod_path(cod_id)),
        phasename=name,
        histograms=[hist],
        fmthint="CIF",
    )

hist.set_refinements({"Limits": [10.0, 100.0]})
gpx.save()

print("histogram", hist.name)
print("residuals", hist.residuals)
print("instrument")
pprint(hist.data["Instrument Parameters"])
print("sample")
pprint(hist.data["Sample Parameters"])
print("background")
pprint(hist.data["Background"])
print("controls")
pprint(gpx.data["Controls"]["data"])
for phase in gpx.phases():
    print("phase", phase.name, phase.composition, phase.get_cell())
    pprint(phase.getHAPvalues(hist.name))
