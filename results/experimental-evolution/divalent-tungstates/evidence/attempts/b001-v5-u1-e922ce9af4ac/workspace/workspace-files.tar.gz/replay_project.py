#!/usr/bin/env python3
"""Save/reopen and replay a GSAS-II project over its native full range."""

import argparse
import json
from pathlib import Path

from rietveld_utils import reopen, refine_replay, summary


parser = argparse.ArgumentParser()
parser.add_argument("source")
parser.add_argument("output")
parser.add_argument("--repeats", type=int, default=3)
args = parser.parse_args()

root = Path(__file__).resolve().parent
gpx, hist = reopen(root / args.source, root / args.output)
gpx, hist = refine_replay(gpx, repeats=args.repeats)
result = summary(gpx, hist)
sample = hist.data["Sample Parameters"]
result["roughness"] = {
    "A": sample["SurfRoughA"],
    "B": sample["SurfRoughB"],
}
result["polarization"] = hist.data["Instrument Parameters"][0]["Polariz."]
result["background"] = hist.data["Background"][0]
print(json.dumps(result, indent=2, default=float))
