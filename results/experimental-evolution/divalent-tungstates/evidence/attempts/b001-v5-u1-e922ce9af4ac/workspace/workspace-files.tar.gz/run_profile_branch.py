#!/usr/bin/env python3
"""Refine bounded common U/W/X and SH/L from an interior start."""

import argparse
import json
from pathlib import Path

from rietveld_utils import reopen, refine_replay, set_common_profile, summary


starts = {
    "low": {"U": 20.0, "V": 0.0, "W": 2.0, "X": 2.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.005},
    "mid": {"U": 45.0, "V": 0.0, "W": 4.0, "X": 5.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.010},
    "high": {"U": 80.0, "V": 0.0, "W": 10.0, "X": 8.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.030},
    "vlow": {"U": 20.0, "V": -5.0, "W": 4.0, "X": 3.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.006},
    "vmid": {"U": 60.0, "V": -15.0, "W": 8.0, "X": 5.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.015},
    "vhigh": {"U": 120.0, "V": -30.0, "W": 15.0, "X": 8.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.035},
}
parser = argparse.ArgumentParser()
parser.add_argument("start", choices=starts)
args = parser.parse_args()

root = Path(__file__).resolve().parent
out = root / ".tmp" / f"profile_{args.start}.gpx"
gpx, hist = reopen(root / ".tmp" / "combined_sizes.gpx", out)
gpx.set_Frozen()
refine = ("U", "W", "X", "SH/L")
if args.start.startswith("v"):
    refine = ("U", "V", "W", "X", "SH/L")
set_common_profile(hist, starts[args.start], refine=refine)
for variable, minimum, maximum in [
    (":0:U", 0.0, 200.0),
    (":0:V", -200.0, 200.0),
    (":0:W", 0.0, 200.0),
    (":0:X", 0.0, 100.0),
    (":0:SH/L", 0.001, 0.10),
]:
    gpx.set_Controls("parmMin", minimum, variable=variable)
    gpx.set_Controls("parmMax", maximum, variable=variable)
gpx, hist = refine_replay(gpx, repeats=3)
print(json.dumps(summary(gpx, hist), indent=2, default=float))
