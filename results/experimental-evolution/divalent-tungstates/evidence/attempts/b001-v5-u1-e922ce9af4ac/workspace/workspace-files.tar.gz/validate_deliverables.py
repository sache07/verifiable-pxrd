#!/usr/bin/env python3
"""Independent chemistry and numeric checks for the exported deliverables."""

import csv
import json
from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


root = Path(__file__).resolve().parent
checks = {"cifs": {}}
for filename in ("PbWO4.cif", "WO3.cif", "Pb3O4.cif", "PbO_massicot.cif"):
    structure = Structure.from_file(root / filename)
    distances = structure.distance_matrix
    nonzero = distances[distances > 1.0e-8]
    symmetry = SpacegroupAnalyzer(structure, symprec=1.0e-3)
    checks["cifs"][filename] = {
        "reduced_formula": structure.composition.reduced_formula,
        "n_sites": len(structure),
        "space_group_number": symmetry.get_space_group_number(),
        "space_group_symbol": symmetry.get_space_group_symbol(),
        "minimum_interatomic_distance_A": float(nonzero.min()),
        "volume_A3": float(structure.volume),
    }

with (root / "fit.csv").open(newline="") as stream:
    rows = list(csv.DictReader(stream))
profile = {
    key: np.asarray([float(row[key]) for row in rows])
    for key in rows[0]
}
checks["fit"] = {
    "n_points": len(rows),
    "two_theta_min": float(profile["two_theta_deg"][0]),
    "two_theta_max": float(profile["two_theta_deg"][-1]),
    "strictly_increasing_two_theta": bool(np.all(np.diff(profile["two_theta_deg"]) > 0)),
    "all_finite": bool(all(np.all(np.isfinite(values)) for values in profile.values())),
    "max_difference_identity_error": float(
        np.max(
            np.abs(
                profile["observed_counts"]
                - profile["calculated_counts"]
                - profile["difference_counts"]
            )
        )
    ),
}

raw = np.genfromtxt(root / "inputs" / "pattern.csv", delimiter=",", names=True)
raw_names = raw.dtype.names
checks["fit"]["matches_input_two_theta"] = bool(
    np.array_equal(profile["two_theta_deg"], raw[raw_names[0]])
)
checks["fit"]["matches_input_observed_counts"] = bool(
    np.array_equal(profile["observed_counts"], raw[raw_names[1]])
)

with (root / "result.json").open() as stream:
    result = json.load(stream)
checks["result"] = {
    "phase_count": len(result["phases"]),
    "weight_fraction_sum": float(sum(item["weight_fraction"] for item in result["phases"])),
    "all_referenced_files_exist": bool(
        (root / result["project"]).is_file()
        and (root / result["profile"]).is_file()
        and all((root / item["cif"]).is_file() for item in result["phases"])
    ),
}
print(json.dumps(checks, indent=2))
