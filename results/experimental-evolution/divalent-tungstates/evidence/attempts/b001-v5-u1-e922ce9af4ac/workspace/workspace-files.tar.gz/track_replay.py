#!/usr/bin/env python3
"""Track save/reopen Rietveld convergence without changing the model."""

import argparse
import json
from pathlib import Path

from rietveld_utils import reopen, summary


parser = argparse.ArgumentParser()
parser.add_argument("source")
parser.add_argument("output")
parser.add_argument("--repeats", type=int, default=10)
args = parser.parse_args()

root = Path(__file__).resolve().parent
path = root / args.output
gpx, hist = reopen(root / args.source, path)
for replay in range(1, args.repeats + 1):
    gpx.do_refinements([{}])
    gpx.save()
    gpx, hist = reopen(path)
    state = summary(gpx, hist)
    sample = hist.data["Sample Parameters"]
    print(
        json.dumps(
            {
                "replay": replay,
                "Rwp": state["Rwp"],
                "Rp": state["Rp"],
                "GOF": state["GOF"],
                "roughness_A": sample["SurfRoughA"][0],
                "roughness_B": sample["SurfRoughB"][0],
                "fractions": state["mass_fractions"],
            },
            default=float,
        ),
        flush=True,
    )
