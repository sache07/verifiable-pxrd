#!/usr/bin/env python3
"""Report chemistry, symmetry, occupancies and short contacts for COD records."""

from __future__ import annotations

import argparse
from collections import Counter
from pathlib import Path

import numpy as np
from pymatgen.io.cif import CifParser
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


parser = argparse.ArgumentParser()
parser.add_argument("cod_ids", nargs="+")
args = parser.parse_args()

for cod_id in args.cod_ids:
    path = cod_path(cod_id)
    cif = CifParser(str(path), occupancy_tolerance=2.0)
    structure = cif.parse_structures(primitive=False)[0]
    symm = SpacegroupAnalyzer(structure, symprec=0.05)
    dmat = np.asarray(structure.distance_matrix, dtype=float)
    dmat[dmat < 1.0e-8] = np.inf
    nearest = []
    for i, site in enumerate(structure):
        j = int(np.argmin(dmat[i]))
        nearest.append((site.species_string, structure[j].species_string, dmat[i, j]))
    contacts = Counter((a, b) for a, b, _ in nearest)
    contact_text = ", ".join(
        f"{a}-{b} {min(d for x, y, d in nearest if (x, y) == (a, b)):.3f} A"
        for a, b in sorted(contacts)
    )
    block = next(iter(cif.as_dict().values()))
    metadata = []
    for key in (
        "_publ_section_title",
        "_diffrn_ambient_temperature",
        "_cell_measurement_temperature",
        "_diffrn_ambient_pressure",
        "_exptl_crystal_pressure_history",
    ):
        if key in block:
            value = str(block[key]).replace("\n", " ").strip()
            metadata.append(f"{key}={value[:180]}")
    disordered = [str(site.species) for site in structure if not site.is_ordered]
    print(f"COD {cod_id}: {path}")
    print(
        f"  composition={structure.composition.formula}; reduced={structure.composition.reduced_formula}; "
        f"SG={symm.get_space_group_symbol()} ({symm.get_space_group_number()}); "
        f"cell={tuple(round(v, 5) for v in (*structure.lattice.abc, *structure.lattice.angles))}"
    )
    print(
        f"  ordered={structure.is_ordered}; disordered_sites={disordered or 'none'}; "
        f"minimum_contact={np.min(dmat):.3f} A; nearest={contact_text}"
    )
    print("  " + ("; ".join(metadata) if metadata else "conditions not tagged"))
