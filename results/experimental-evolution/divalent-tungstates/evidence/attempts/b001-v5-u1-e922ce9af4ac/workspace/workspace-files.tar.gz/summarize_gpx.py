#!/usr/bin/env python3
"""Print compact JSON summaries for one or more GSAS-II projects."""

import argparse
import json
from pathlib import Path

from rietveld_utils import reopen, summary


parser = argparse.ArgumentParser()
parser.add_argument("projects", nargs="+")
args = parser.parse_args()

for item in args.projects:
    path = Path(item)
    gpx, hist = reopen(path)
    data = summary(gpx, hist)
    compact = {
        "file": str(path),
        "Rwp": data["Rwp"],
        "Rp": data["Rp"],
        "GOF": data["GOF"],
        "zero": data["zero"],
        "profile": data["profile"],
        "roughness": {
            "A": hist.data["Sample Parameters"]["SurfRoughA"],
            "B": hist.data["Sample Parameters"]["SurfRoughB"],
        },
        "polarization": hist.data["Instrument Parameters"][0]["Polariz."],
        "mass_fractions": data["mass_fractions"],
        "frozen": data["frozen"],
        "cells": {name: values["cell"] for name, values in data["phases"].items()},
        "sizes": {name: values["size"][1][0] for name, values in data["phases"].items()},
        "microstrains": {
            name: values["microstrain"][1][0] for name, values in data["phases"].items()
        },
        "texture": {
            name: {
                "model": values["preferred_orientation"][0],
                "ratio": values["preferred_orientation"][1],
                "refine": values["preferred_orientation"][2],
                "axis": values["preferred_orientation"][3],
            }
            for name, values in data["phases"].items()
        },
    }
    print(json.dumps(compact, default=float))
