#!/usr/bin/env python3
"""Replace one retained phase by an alternate COD record under one model."""

import argparse
import json
from pathlib import Path

from rietveld_utils import cod_path, neutralize_phase, reopen, refine_replay, summary


parser = argparse.ArgumentParser()
parser.add_argument("phase", type=int, choices=(0, 1, 2))
parser.add_argument("cod_id")
parser.add_argument("tag")
args = parser.parse_args()

root = Path(__file__).resolve().parent
out = root / ".tmp" / f"source_four_{args.tag}.gpx"
gpx, hist = reopen(root / ".tmp" / "intensity_four_roughness_high.gpx", out)
gpx.set_Frozen()
old_phase = gpx.phase(args.phase)
old_hap = old_phase.getHAPvalues(hist.name)
old_scale = old_hap["Scale"][0]
old_size = old_hap["Size"][1][0]
old_size_refine = old_hap["Size"][2][0]
old_strain = old_hap["Mustrain"][1][0]
old_strain_refine = old_hap["Mustrain"][2][0]
old_hap["Use"] = False
old_hap["Scale"][:] = [0.0, False]

phase = gpx.add_phase(
    str(cod_path(args.cod_id)),
    phasename=f"{old_phase.name}_alt_{args.cod_id}",
    histograms=[hist],
    fmthint="CIF",
)
neutralize_phase(phase, hist)
hap = phase.getHAPvalues(hist.name)
hap["Scale"][0] = old_scale
phase.set_refinements({"Cell": True})
index = len(gpx.phases()) - 1
if old_size_refine:
    phase.setSampleProfile(hist, "size", "isotropic", old_size, LGmix=1.0)
    phase.set_HAP_refinements(
        {"Size": {"type": "isotropic", "refine": True,
                  "LGmix": {"value": 1.0, "refine": False}}}, [hist]
    )
    gpx.set_Controls("parmMin", 0.002, variable=f"{index}:0:Size;i")
    gpx.set_Controls("parmMax", 10.0, variable=f"{index}:0:Size;i")
if old_strain_refine:
    phase.setSampleProfile(hist, "microstrain", "isotropic", old_strain, LGmix=1.0)
    phase.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True,
                      "LGmix": {"value": 1.0, "refine": False}}}, [hist]
    )
    gpx.set_Controls("parmMin", 0.0, variable=f"{index}:0:Mustrain;i")
    gpx.set_Controls("parmMax", 100000.0, variable=f"{index}:0:Mustrain;i")
gpx.set_Controls("parmMin", 0.0, variable=f"{index}:0:Scale")
gpx.set_Controls("parmMax", 100.0, variable=f"{index}:0:Scale")
gpx.save()
gpx, hist = refine_replay(gpx, repeats=3)
print(json.dumps(summary(gpx, hist), indent=2, default=float))
