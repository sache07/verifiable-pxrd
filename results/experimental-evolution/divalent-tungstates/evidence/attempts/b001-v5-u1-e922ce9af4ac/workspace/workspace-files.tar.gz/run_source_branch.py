#!/usr/bin/env python3
"""Compare exact-composition source records with an identical nuisance model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from rietveld_utils import build_project, refine_replay, summary


parser = argparse.ArgumentParser()
parser.add_argument("tag")
parser.add_argument("--pbwo4", default="9009811")
parser.add_argument("--wo3", default="1528915")
parser.add_argument("--pb3o4", default="9012124")
args = parser.parse_args()

root = Path(__file__).resolve().parent
out = root / ".tmp" / f"source_{args.tag}.gpx"
profile = {
    "U": 39.89507,
    "V": 0.0,
    "W": 10.14626,
    "X": 4.34001,
    "Y": 0.0,
    "Z": 0.0,
    "SH/L": 0.011668,
}
specs = [
    (args.pbwo4, "PbWO4"),
    (args.wo3, "WO3"),
    (args.pb3o4, "Pb3O4"),
]
gpx, hist = build_project(out, specs, "zero", common_profile=profile)
hist.data["Background"][0][3:] = [
    1477.7010, -1166.0565, 644.4370, -261.1521,
    79.7866, -12.9549, 1.6844, 19.8099,
]
hist.data["Instrument Parameters"][0]["Zero"][:2] = [0.44409, 0.44409]
for phase, raw_scale, start in zip(
    gpx.phases(), (9.0113, 3.0185, 1.7265), (0.060, None, 0.033)
):
    phase.getHAPvalues(hist.name)["Scale"][0] = raw_scale
    if start is None:
        continue
    hap = phase.getHAPvalues(hist.name)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = start
    hap["Size"][2][:] = [True, False, False]
gpx.set_Controls("cycles", 8)
gpx.save()
gpx, hist = refine_replay(gpx, repeats=2)
result = summary(gpx, hist)
result["records"] = {
    "PbWO4": args.pbwo4,
    "WO3": args.wo3,
    "Pb3O4": args.pb3o4,
}
print(json.dumps(result, indent=2, default=float))
