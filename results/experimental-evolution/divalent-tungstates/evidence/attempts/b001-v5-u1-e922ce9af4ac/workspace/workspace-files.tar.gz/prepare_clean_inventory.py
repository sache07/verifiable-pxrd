#!/usr/bin/env python3
"""Neutralize shared intensity effects after an inventory change and replay."""

import json
from pathlib import Path

from rietveld_utils import reopen, refine_replay, summary


root = Path(__file__).resolve().parent
gpx, hist = reopen(
    root / ".tmp" / "candidate_PbO_massicot.gpx",
    root / ".tmp" / "four_phase_clean.gpx",
)
gpx.set_Frozen()
sample = hist.data["Sample Parameters"]
sample["SurfRoughA"][:] = [0.0, False]
sample["SurfRoughB"][:] = [0.0, False]
inst = hist.data["Instrument Parameters"][0]
inst["Polariz."][:] = [0.5, 0.5, False]
for phase in gpx.phases():
    hap = phase.getHAPvalues(hist.name)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
gpx.save()
gpx, hist = refine_replay(gpx, repeats=3)
print(json.dumps(summary(gpx, hist), indent=2, default=float))
