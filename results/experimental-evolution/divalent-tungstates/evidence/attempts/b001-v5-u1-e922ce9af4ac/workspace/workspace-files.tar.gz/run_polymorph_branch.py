#!/usr/bin/env python3
"""Replace retained massicot with a screened PbO polymorph under one model."""

import json
from pathlib import Path

from rietveld_utils import neutralize_phase, reopen, refine_replay, summary


root = Path(__file__).resolve().parent
gpx, hist = reopen(
    root / ".tmp" / "intensity_four_roughness_high.gpx",
    root / ".tmp" / "polymorph_PbO_litharge.gpx",
)
gpx.set_Frozen()
old = gpx.phase(3).getHAPvalues(hist.name)
old["Use"] = False
old["Scale"][:] = [0.0, False]
phase = gpx.add_phase(
    str(root / ".tmp" / "PbO_litharge_gsas2.cif"),
    phasename="PbO_litharge",
    histograms=[hist],
    fmthint="CIF",
)
neutralize_phase(phase, hist)
hap = phase.getHAPvalues(hist.name)
hap["Scale"][0] = 3.2
phase.set_refinements({"Cell": True})
phase.setSampleProfile(hist, "microstrain", "isotropic", 10000.0, LGmix=1.0)
phase.set_HAP_refinements(
    {"Mustrain": {"type": "isotropic", "refine": True,
                  "LGmix": {"value": 1.0, "refine": False}}}, [hist]
)
index = len(gpx.phases()) - 1
gpx.set_Controls("parmMin", 0.0, variable=f"{index}:0:Scale")
gpx.set_Controls("parmMax", 100.0, variable=f"{index}:0:Scale")
gpx.set_Controls("parmMin", 0.0, variable=f"{index}:0:Mustrain;i")
gpx.set_Controls("parmMax", 100000.0, variable=f"{index}:0:Mustrain;i")
gpx.save()
gpx, hist = refine_replay(gpx, repeats=3)
print(json.dumps(summary(gpx, hist), indent=2, default=float))
