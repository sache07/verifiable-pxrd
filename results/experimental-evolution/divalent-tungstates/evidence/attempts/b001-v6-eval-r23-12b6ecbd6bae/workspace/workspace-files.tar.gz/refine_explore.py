#!/usr/bin/env python3
"""Build and stage a physically restrained GSAS-II refinement."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "inputs" / "pattern.csv"
XYE = ROOT / "pattern.xye"
INST = ROOT / "ca_cuka.instprm"
SOURCE_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/7/21/92/7219229.cif"
)


def make_xye() -> None:
    with DATA.open(newline="") as src, XYE.open("w") as dst:
        dst.write("# two_theta_deg intensity; Poisson weights inferred by GSAS-II\n")
        for row in csv.DictReader(src):
            dst.write(f"{float(row['two_theta_deg']):.8f} {float(row['intensity']):.8f}\n")


def snapshot(gpx: G2sc.G2Project, label: str) -> dict:
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    hap = phase.data["Histograms"][hist.name]
    out = {
        "label": label,
        "residuals": hist.residuals,
        "cell": phase.get_cell(),
        "instrument": {
            k: inst[k][1]
            for k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)")
            if k in inst
        },
        "background": hist.data["Background"][0],
        "hap": {
            "Scale": hap["Scale"],
            "Size": hap["Size"],
            "Mustrain": hap["Mustrain"],
            "Pref.Ori.": hap["Pref.Ori."],
        },
    }
    print("SNAPSHOT", json.dumps(out, default=float))
    return out


def run_step(gpx: G2sc.G2Project, label: str) -> None:
    print(f"\n===== {label} =====")
    gpx.refine(makeBack=False)
    snapshot(gpx, label)


def main() -> None:
    G2sc.SetPrintLevel("all")
    make_xye()
    gpx = G2sc.G2Project(newgpx=str(ROOT / "explore.gpx"), author="Codex")
    hist = gpx.add_powder_histogram(
        str(XYE), str(INST), fmthint="Topas xye"
    )
    phase = gpx.add_phase(
        str(SOURCE_CIF), phasename="CaWO4_scheelite", histograms=[hist], fmthint="CIF"
    )

    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": [1600.0, -350.0, 180.0, -80.0, 30.0, -10.0],
            }
        }
    )
    # Neutralize all phase-specific nuisance terms before the common baseline.
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1.0, 1.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    # Only the HAP scale carries phase abundance. The specimen scale is
    # otherwise exactly redundant for a single histogram.
    hist.data["Sample Parameters"]["Scale"][1] = False

    phase.set_HAP_refinements({"Scale": True}, [hist])
    gpx.set_Controls("cycles", 8)
    gpx.save()
    run_step(gpx, "background + scale")

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_step(gpx, "cell + zero")

    hist.set_refinements({"Instrument Parameters": ["W"]})
    run_step(gpx, "add W")

    hist.set_refinements({"Instrument Parameters": ["U"]})
    run_step(gpx, "add U")

    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    run_step(gpx, "add asymmetry")

    gpx.save()


if __name__ == "__main__":
    main()
