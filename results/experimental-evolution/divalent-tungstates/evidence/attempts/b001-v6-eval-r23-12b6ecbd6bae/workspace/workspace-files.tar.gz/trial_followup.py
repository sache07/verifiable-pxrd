#!/usr/bin/env python3
"""Follow-up trials for X broadening and the oxygen model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TDIR = ROOT / ".tmp" / "trials"
BASE = TDIR / "common_replay.gpx"


def summary(name, gpx):
    h = gpx.histogram(0)
    p = gpx.phase(0)
    hap = p.data["Histograms"][h.name]
    inst = h.data["Instrument Parameters"][0]
    cov = gpx.data["Covariance"]["data"]
    vary = cov.get("varyList", [])
    vals = dict(zip(vary, map(float, cov.get("variables", []))))
    sigs = dict(zip(vary, map(float, cov.get("sig", []))))
    corr = []
    cm = cov.get("covMatrix")
    if cm is not None and len(vary):
        cm = np.asarray(cm, dtype=float)
        sd = np.sqrt(np.maximum(np.diag(cm), 0))
        cc = cm / np.outer(sd, sd)
        for i in range(len(vary)):
            for j in range(i):
                if np.isfinite(cc[i, j]) and abs(cc[i, j]) >= 0.9:
                    corr.append([vary[j], vary[i], float(cc[i, j])])
        corr.sort(key=lambda row: abs(row[2]), reverse=True)
    out = {
        "trial": name,
        "residuals": h.residuals,
        "cell": p.get_cell(),
        "instrument": {k: inst[k][1:] for k in ("Polariz.", "Zero", "U", "W", "X", "SH/L")},
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "atoms": {
            a.label: {"xyz": list(map(float, a.coordinates)), "Uiso": float(a.uiso), "flags": a.refinement_flags}
            for a in p.atoms()
        },
        "selected": {
            k: [v, sigs.get(k)] for k, v in vals.items()
            if any(tag in k for tag in (":X", "Size", "Mustrain", "dA", "AUiso", "Polariz"))
        },
        "correlations_ge_0.9": corr[:20],
    }
    print("FOLLOWUP", json.dumps(out, default=float))
    return out


def run(name, source=BASE, configure=None, repeats=2):
    target = TDIR / f"{name}.gpx"
    g = G2sc.G2Project(str(source), newgpx=str(target))
    h = g.histogram(0)
    p = g.phase(0)
    if configure:
        configure(g, h, p)
    g.set_Controls("cycles", 12)
    g.save()
    for _ in range(repeats):
        g.refine(makeBack=False)
        g.save()
    return summary(name, g)


def set_x(g, h, p):
    h.data["Instrument Parameters"][0]["X"][1] = 0.1
    h.set_refinements({"Instrument Parameters": ["X"]})


def main():
    G2sc.SetPrintLevel("warn")
    results = [run("common_replay2", repeats=2)]
    results.append(run("profile_X", configure=set_x, repeats=2))
    xsource = TDIR / "profile_X.gpx"

    def oxygen(g, h, p):
        p.set_refinements({"Atoms": {"O1": "X"}})
    results.append(run("profile_X_oxygen", source=xsource, configure=oxygen, repeats=2))

    def oxygen_u(g, h, p):
        p.set_refinements({"Atoms": {"O1": "XU"}})
    results.append(run("profile_X_oxygen_U", source=xsource, configure=oxygen_u, repeats=2))

    def x_size(g, h, p):
        p.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True, "value": 1.0,
                      "LGmix": {"value": 1.0, "refine": False}}}, [h]
        )
    results.append(run("profile_X_size", source=xsource, configure=x_size, repeats=2))

    def x_strain(g, h, p):
        hap = p.data["Histograms"][h.name]["Mustrain"]
        hap[0] = "isotropic"
        hap[1][:] = [100.0, 100.0, 1.0]
        p.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True,
                           "LGmix": {"value": 1.0, "refine": False}}}, [h]
        )
    results.append(run("profile_X_strain", source=xsource, configure=x_strain, repeats=2))

    (TDIR / "followup_summary.json").write_text(json.dumps(results, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
