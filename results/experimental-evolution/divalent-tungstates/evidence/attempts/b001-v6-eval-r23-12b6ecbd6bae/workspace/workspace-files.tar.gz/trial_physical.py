#!/usr/bin/env python3
"""Replay-stable structural and profile trials under the accepted polarization."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TRIAL_DIR = ROOT / ".tmp" / "trials"
START = TRIAL_DIR / "polar_refined.gpx"
COMMON = TRIAL_DIR / "common_neutral.gpx"


def reset_nuisance(gpx):
    h = gpx.histogram(0)
    ph = gpx.phase(0)
    inst = h.data["Instrument Parameters"][0]
    inst["SH/L"][1:] = [0.002, False]
    inst["X"][1:] = [0.0, False]
    h.data["Sample Parameters"]["Scale"][1] = False
    h.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    h.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hap = ph.data["Histograms"][h.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1000.0, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    for atom in ph.atoms():
        atom.refinement_flags = " "
    gpx.set_Controls("cycles", 12)
    return h, ph


def describe(name, gpx, h, ph):
    inst = h.data["Instrument Parameters"][0]
    hap = ph.data["Histograms"][h.name]
    cov = gpx.data["Covariance"]["data"]
    vals = dict(zip(cov.get("varyList", []), map(float, cov.get("variables", []))))
    sig = dict(zip(cov.get("varyList", []), map(float, cov.get("sig", []))))
    out = {
        "trial": name,
        "residuals": h.residuals,
        "cell": ph.get_cell(),
        "instrument": {k: inst[k][1:] for k in ("Polariz.", "Zero", "U", "W", "X", "SH/L")},
        "roughness": {k: h.data["Sample Parameters"][k] for k in ("SurfRoughA", "SurfRoughB")},
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "atoms": {
            a.label: {
                "xyz": list(map(float, a.coordinates)),
                "Uiso": float(a.uiso),
                "flags": a.refinement_flags,
            }
            for a in ph.atoms()
        },
        "selected_parameters": {
            k: [v, sig.get(k)]
            for k, v in vals.items()
            if any(s in k for s in ("AUiso", "Ax:", "Ay:", "Az:", "Size", "Mustrain", "MD", "SurfRough", "SH/L"))
        },
    }
    print("PHYSICAL", json.dumps(out, default=float))
    return out


def refine(name, source=COMMON, configure=None):
    target = TRIAL_DIR / f"{name}.gpx"
    gpx = G2sc.G2Project(str(source), newgpx=str(target))
    h = gpx.histogram(0)
    ph = gpx.phase(0)
    if configure:
        configure(gpx, h, ph)
    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    return describe(name, gpx, h, ph)


def main():
    G2sc.SetPrintLevel("warn")
    TRIAL_DIR.mkdir(parents=True, exist_ok=True)

    # Build the accepted common profile with unused phase broadening truly neutral.
    gpx = G2sc.G2Project(str(START), newgpx=str(COMMON))
    h, ph = reset_nuisance(gpx)
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    results = [describe("common_neutral", gpx, h, ph)]

    results.append(refine("common_replay"))

    def oxygen_xyz(g, h, p):
        p.set_refinements({"Atoms": {"O1": "X"}})
    results.append(refine("oxygen_xyz", configure=oxygen_xyz))

    for label in ("Ca1", "W1", "O1"):
        def one_uiso(g, h, p, label=label):
            p.set_refinements({"Atoms": {label: "U"}})
        results.append(refine(f"common_uiso_{label}", configure=one_uiso))

    def all_uiso(g, h, p):
        p.set_refinements({"Atoms": {"all": "U"}})
    results.append(refine("common_uiso_all", configure=all_uiso))

    def rough(g, h, p):
        h.data["Sample Parameters"]["SurfRoughA"] = [0.1, True]
        h.data["Sample Parameters"]["SurfRoughB"] = [0.1, True]
    results.append(refine("common_roughness", configure=rough))

    def asym(g, h, p):
        h.set_refinements({"Instrument Parameters": ["SH/L"]})
    results.append(refine("common_asymmetry", configure=asym))

    for axis in ((0, 0, 1), (1, 0, 0), (1, 1, 0), (1, 0, 1), (1, 1, 2)):
        def texture(g, h, p, axis=axis):
            po = p.data["Histograms"][h.name]["Pref.Ori."]
            po[3] = list(axis)
            po[2] = True
        results.append(refine("common_texture_" + "".join(map(str, axis)), configure=texture))

    def size(g, h, p):
        p.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True, "value": 10.0,
                      "LGmix": {"value": 1.0, "refine": False}}}, [h]
        )
    results.append(refine("common_size", configure=size))

    def strain(g, h, p):
        hap = p.data["Histograms"][h.name]["Mustrain"]
        hap[0] = "isotropic"
        hap[1][:] = [100.0, 100.0, 1.0]
        p.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True,
                           "LGmix": {"value": 1.0, "refine": False}}}, [h]
        )
    results.append(refine("common_strain", configure=strain))

    (TRIAL_DIR / "physical_summary.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    main()
