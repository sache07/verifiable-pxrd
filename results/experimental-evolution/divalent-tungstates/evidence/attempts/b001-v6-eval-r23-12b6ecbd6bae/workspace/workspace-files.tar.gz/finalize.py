#!/usr/bin/env python3
"""Create, replay, and export the final GSAS-II result."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "trials" / "profile_X_oxygen_U.gpx"
FINAL = ROOT / "final.gpx"
CIF = ROOT / "CaWO4_scheelite.cif"


def enforce_final_model(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hap = phase.data["Histograms"][hist.name]

    # Replay the complete measured range.
    x = np.asarray(hist.getdata("X"), dtype=float)
    hist.Limits("lower", float(x[0]))
    hist.Limits("upper", float(x[-1]))

    # One positional correction (zero) and a nonnegative U/W/X profile.
    for key in inst:
        if len(inst[key]) > 2:
            inst[key][2] = key in {"Zero", "Polariz.", "U", "W", "X"}
    inst["V"][1] = 0.0
    inst["Y"][1] = 0.0
    inst["Z"][1] = 0.0
    inst["SH/L"][1] = 0.002

    # Remove redundant or unsupported specimen terms.
    sample["Scale"][1] = False
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    phase.set_refinements({"Cell": True, "Atoms": {"Ca1": " ", "W1": " ", "O1": "XU"}})
    hap["Scale"][1] = True
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    for key in ("BabA", "BabU"):
        hap["Babinet"][key] = [0.0, False]

    hist.data["Background"][0][1] = True
    gpx.set_Controls("cycles", 12)
    for variable, lower in (
        (":0:U", 0.0),
        (":0:W", 0.0),
        (":0:X", 0.0),
        (":0:Polariz.", 0.0),
        ("0::AUiso:2", 0.0),
    ):
        gpx.set_Controls("parmMin", lower, variable=variable)
    gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")


def export_result(gpx: G2sc.G2Project) -> dict:
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    phase.export_CIF(str(CIF))

    x = np.asarray(hist.getdata("X"), dtype=float)
    yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)
    difference = yobs - ycalc
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta_deg", "observed_intensity", "calculated_intensity", "difference_obs_minus_calc", "background"]
        )
        writer.writerows(zip(x, yobs, ycalc, difference, background))

    residuals = hist.residuals
    cov = gpx.data["Covariance"]["data"]
    vary = list(cov.get("varyList", []))
    variables = dict(zip(vary, map(float, cov.get("variables", []))))
    sigmas = dict(zip(vary, map(float, cov.get("sig", []))))
    rwp = float(residuals["wR"])
    rexp = float(residuals["wRmin"])
    result = {
        "phases": [
            {
                "name": "CaWO4_scheelite",
                "formula": "CaWO4",
                "space_group": "I 41/a",
                "cif_path": CIF.name,
                "weight_fraction": 1.0,
            }
        ],
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": rexp,
            "goodness_of_fit": rwp / rexp,
            "reduced_chi_squared": (rwp / rexp) ** 2,
            "weighted_background_R_percent": float(residuals["wRb"]),
            "background_R_percent": float(residuals["Rb"]),
            "Bragg_R_F_percent": float(residuals["0:0:Rf"]),
            "Bragg_R_F_squared_percent": float(residuals["0:0:Rf^2"]),
            "n_observations": int(len(x)),
            "n_refined_parameters": int(len(vary)),
        },
        "refined_model": {
            "cell_angstrom_degrees": phase.get_cell(),
            "cell_standard_uncertainties": phase.get_cell_and_esd()[1],
            "oxygen_fractional_coordinates": list(map(float, phase.atom("O1").coordinates)),
            "oxygen_Uiso_angstrom_squared": float(phase.atom("O1").uiso),
            "profile": {
                key: {
                    "value": variables.get(f":0:{key}", hist.data["Instrument Parameters"][0][key][1]),
                    "standard_uncertainty": sigmas.get(f":0:{key}"),
                }
                for key in ("Polariz.", "Zero", "U", "W", "X")
            },
            "phase_scale": {
                "value": variables.get("0:0:Scale", phase.data["Histograms"][hist.name]["Scale"][0]),
                "standard_uncertainty": sigmas.get("0:0:Scale"),
            },
        },
        "project_path": FINAL.name,
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, sort_keys=False) + "\n")
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    enforce_final_model(gpx)
    gpx.save()

    # Reopen before every full-range replay to test persistence of the model.
    for _ in range(3):
        gpx = G2sc.G2Project(str(FINAL))
        enforce_final_model(gpx)
        gpx.save()
        gpx.refine(makeBack=False)
        gpx.save()

    # Export only from the reopened, persisted project.
    gpx = G2sc.G2Project(str(FINAL))
    result = export_result(gpx)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
