#!/usr/bin/env python3
"""Reversible nuisance/structure trials from the common CaWO4 baseline."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "explore.gpx"
TRIAL_DIR = ROOT / ".tmp" / "trials"


def fresh(name: str):
    TRIAL_DIR.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(TRIAL_DIR / f"{name}.gpx"))
    h = gpx.histogram(0)
    ph = gpx.phase(0)
    inst = h.data["Instrument Parameters"][0]
    inst["SH/L"][1:] = [0.002, False]
    inst["X"][1:] = [0.0, False]
    h.data["Sample Parameters"]["Scale"][1] = False
    for atom in ph.atoms():
        atom.refinement_flags = " "
    ph.data["Histograms"][h.name]["Pref.Ori."][1] = 1.0
    ph.data["Histograms"][h.name]["Pref.Ori."][2] = False
    h.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    h.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    gpx.set_Controls("cycles", 10)
    return gpx, h, ph


def finish(name: str, gpx, h, ph):
    gpx.save()
    gpx.refine(makeBack=False)
    inst = h.data["Instrument Parameters"][0]
    sample = h.data["Sample Parameters"]
    cov = gpx.data["Covariance"]["data"]
    values = dict(zip(cov.get("varyList", []), map(float, cov.get("variables", []))))
    sigmas = dict(zip(cov.get("varyList", []), map(float, cov.get("sig", []))))
    out = {
        "trial": name,
        "residuals": h.residuals,
        "instrument": {k: inst[k][1:] for k in ("Polariz.", "Zero", "U", "W", "X", "SH/L")},
        "sample": {k: sample[k] for k in ("SurfRoughA", "SurfRoughB")},
        "atoms": {
            a.label: {"Uiso": a.uiso, "flags": a.refinement_flags}
            for a in ph.atoms()
        },
        "preferred_orientation": ph.data["Histograms"][h.name]["Pref.Ori."],
        "selected_parameters": {
            k: [v, sigmas.get(k)]
            for k, v in values.items()
            if any(s in k for s in ("Polariz", "AUiso", "SurfRough", "MD"))
        },
    }
    print("TRIAL", json.dumps(out, default=float))
    return out


def main():
    G2sc.SetPrintLevel("warn")
    results = []

    g, h, p = fresh("base_pruned")
    results.append(finish("base_pruned", g, h, p))

    for pol in (0.0, 0.25, 0.5, 0.75, 1.0):
        name = f"polar_fixed_{pol:.2f}".replace(".", "p")
        g, h, p = fresh(name)
        h.data["Instrument Parameters"][0]["Polariz."][1] = pol
        results.append(finish(name, g, h, p))

    g, h, p = fresh("polar_refined")
    h.set_refinements({"Instrument Parameters": ["Polariz."]})
    results.append(finish("polar_refined", g, h, p))

    for label in ("Ca1", "W1", "O1"):
        name = f"uiso_{label}"
        g, h, p = fresh(name)
        p.set_refinements({"Atoms": {label: "U"}})
        results.append(finish(name, g, h, p))

    g, h, p = fresh("uiso_all")
    p.set_refinements({"Atoms": {"all": "U"}})
    results.append(finish("uiso_all", g, h, p))

    g, h, p = fresh("roughness")
    h.data["Sample Parameters"]["SurfRoughA"] = [0.1, True]
    h.data["Sample Parameters"]["SurfRoughB"] = [0.1, True]
    results.append(finish("roughness", g, h, p))

    for axis in ((0, 0, 1), (1, 0, 0), (1, 1, 0), (1, 0, 1), (1, 1, 2)):
        name = "texture_" + "".join(map(str, axis))
        g, h, p = fresh(name)
        po = p.data["Histograms"][h.name]["Pref.Ori."]
        po[3] = list(axis)
        po[2] = True
        results.append(finish(name, g, h, p))

    (TRIAL_DIR / "summary.json").write_text(json.dumps(results, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
