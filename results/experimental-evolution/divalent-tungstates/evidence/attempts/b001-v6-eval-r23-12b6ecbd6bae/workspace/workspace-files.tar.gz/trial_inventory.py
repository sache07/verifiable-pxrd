#!/usr/bin/env python3
"""Re-challenge plausible phase candidates under the accepted common profile."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TDIR = ROOT / ".tmp" / "inventory"
BASE = ROOT / ".tmp" / "trials" / "profile_X_oxygen_U.gpx"
CIFROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif(cod_id: str) -> Path:
    return CIFROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = [
    ("CaO_1563196", "1563196", "unreacted CaO, rocksalt, 293 K"),
    ("Ca3WO6_1563081", "1563081", "Ca-rich ordered perovskite"),
    ("CaWO4_fergusonite_1546035", "1546035", "high-pressure CaWO4 polymorph, 11.3 GPa"),
    ("WO3_mono_1528915", "1528915", "ambient monoclinic WO3 record A"),
    ("WO3_mono_1563541", "1563541", "ambient monoclinic WO3 record B"),
    ("WO3_mono_2311041", "2311041", "ambient monoclinic WO3 alternate setting"),
    ("WO3_tri_2106293", "2106293", "triclinic WO3 polymorph"),
    ("WO3_tri_1010618", "1010618", "triclinic WO3 alternate record"),
]


def main():
    G2sc.SetPrintLevel("warn")
    TDIR.mkdir(parents=True, exist_ok=True)
    results = []
    for name, cod_id, context in CANDIDATES:
        target = TDIR / f"{name}.gpx"
        g = G2sc.G2Project(str(BASE), newgpx=str(target))
        h = g.histogram(0)
        p = g.add_phase(str(cif(cod_id)), phasename=name, histograms=[h], fmthint="CIF")
        p.set_refinements({"Cell": False})
        for atom in p.atoms():
            atom.refinement_flags = " "
        hap = p.data["Histograms"][h.name]
        hap["Scale"] = [0.1, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        g.set_Controls("cycles", 12)
        g.save()
        g.refine(makeBack=False)
        g.save()
        g.refine(makeBack=False)
        g.save()

        cov = g.data["Covariance"]["data"]
        vals = dict(zip(cov.get("varyList", []), map(float, cov.get("variables", []))))
        sigs = dict(zip(cov.get("varyList", []), map(float, cov.get("sig", []))))
        scale_var = f"{p.id}:{h.id}:Scale"
        scales = []
        for ph in g.phases():
            s = float(ph.data["Histograms"][h.name]["Scale"][0])
            m = float(ph.data["General"]["Mass"])
            scales.append((ph.name, s, m, s * m))
        denom = sum(row[3] for row in scales)
        signed_fracs = {row[0]: row[3] / denom for row in scales} if denom else {}
        out = {
            "candidate": name,
            "cod_id": cod_id,
            "context": context,
            "space_group": p.data["General"]["SGData"]["SpGrp"],
            "cell": p.get_cell(),
            "scale": float(hap["Scale"][0]),
            "scale_su": sigs.get(scale_var),
            "scale_z": (float(hap["Scale"][0]) / sigs[scale_var]) if sigs.get(scale_var) else None,
            "signed_weight_fractions": signed_fracs,
            "residuals": h.residuals,
        }
        print("INVENTORY", json.dumps(out, default=float))
        results.append(out)
    (TDIR / "summary.json").write_text(json.dumps(results, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
