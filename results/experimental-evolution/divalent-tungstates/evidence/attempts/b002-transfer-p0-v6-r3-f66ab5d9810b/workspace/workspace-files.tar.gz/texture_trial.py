#!/usr/bin/env python3
"""Replay a single March-Dollase preferred-orientation trial."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc

from explore_refine import summarize


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--axis", nargs=3, type=int, required=True)
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.input, newgpx=args.output)
    hist = gpx.histogram(0)
    phase = gpx.phase(args.phase)
    if phase is None:
        raise ValueError(f"unknown phase {args.phase}")
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = list(args.axis)
    variable = f"{phase.id}:{hist.id}:MD"
    gpx.set_Controls("parmMin", 0.2, variable=variable)
    gpx.set_Controls("parmMax", 5.0, variable=variable)
    gpx.set_Controls("cycles", 6)
    gpx.save()
    for _ in range(2):
        gpx.refine()
    gpx.save()

    result = summarize(gpx)
    result["trial"] = {
        "phase": phase.name,
        "axis": list(args.axis),
        "preferred_orientation": pref,
        "frozen": gpx.get_Frozen(),
    }
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
