#!/usr/bin/env python3
"""Make a compact diagnostic plot and rank the largest local residuals."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("--plot")
    parser.add_argument("--extract")
    args = parser.parse_args()

    if args.extract:
        from GSASII import GSASIIscriptable as G2sc

        project = G2sc.G2Project(args.project)
        hist = project.histogram(0)
        x = np.asarray(hist.getdata("X"), dtype=float)
        yo = np.asarray(hist.getdata("Yobs"), dtype=float)
        yc = np.asarray(hist.getdata("Ycalc"), dtype=float)
        bkg = np.asarray(hist.getdata("Background"), dtype=float)
        lo, hi = hist.Limits("lower"), hist.Limits("upper")
        Path(args.extract).parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(args.extract, x=x, yo=yo, yc=yc, bkg=bkg, lo=lo, hi=hi)
        return

    if not args.plot:
        parser.error("--plot is required when plotting an extracted npz file")
    import matplotlib.pyplot as plt
    from scipy.signal import find_peaks

    data = np.load(args.project)
    x, yo, yc, bkg = (np.asarray(data[key], dtype=float) for key in ("x", "yo", "yc", "bkg"))
    lo, hi = float(data["lo"]), float(data["hi"])
    diff = yo - yc
    use = (x >= lo) & (x <= hi)

    fig, axes = plt.subplots(4, 1, figsize=(15, 12), constrained_layout=True)
    windows = [(lo, hi), (10, 40), (40, 70), (70, 100)]
    for ax, (left, right) in zip(axes, windows):
        sel = use & (x >= left) & (x <= right)
        ax.plot(x[sel], yo[sel], color="black", lw=0.55, label="observed")
        ax.plot(x[sel], yc[sel], color="#d62728", lw=0.65, label="calculated")
        offset = float(np.min(bkg[sel]) - 0.08 * np.ptp(yo[sel]))
        ax.plot(x[sel], diff[sel] + offset, color="#1f77b4", lw=0.5, label="difference (offset)")
        ax.plot(x[sel], bkg[sel], color="#2ca02c", lw=0.45, alpha=0.7, label="background")
        ax.set_xlim(left, right)
        ax.set_ylabel("counts")
    axes[0].legend(ncol=4, frameon=False, loc="upper right")
    axes[-1].set_xlabel(r"$2\theta$ (degrees)")
    Path(args.plot).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.plot, dpi=180)

    sigma = np.sqrt(np.maximum(yo, 1.0))
    score = np.abs(diff) / sigma
    idx, _ = find_peaks(score, distance=max(1, int(round(0.08 / np.median(np.diff(x))))), prominence=0.5)
    idx = idx[use[idx]]
    idx = idx[np.argsort(score[idx])[::-1]][:30]
    print("largest standardized local residuals")
    for i in idx:
        print(f"{x[i]:9.4f}  obs={yo[i]:10.2f} calc={yc[i]:10.2f} diff={diff[i]:9.2f} score={score[i]:7.2f}")


if __name__ == "__main__":
    main()
