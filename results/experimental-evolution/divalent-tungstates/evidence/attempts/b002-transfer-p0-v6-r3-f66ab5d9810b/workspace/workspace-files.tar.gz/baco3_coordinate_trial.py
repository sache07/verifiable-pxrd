#!/usr/bin/env python3
"""Apply the physically screened Pnma carbonate coordinates in-place."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc

from explore_refine import summarize


def main() -> None:
    gpx = G2sc.G2Project("final.gpx", newgpx="trial_baco3_hybrid_direct.gpx")
    phase = gpx.phase("BaCO3")
    coordinates = {
        "C": (0.25, 0.750, -0.095),
        "O1": (0.25, 0.889, -0.095),
        "O2": (0.452, 0.680, -0.095),
    }
    for label, xyz in coordinates.items():
        phase.atom(label).coordinates = xyz
    gpx.set_Controls("cycles", 6)
    gpx.save()
    for _ in range(2):
        gpx.refine()
    gpx.save()
    result = summarize(gpx)
    result["trial"] = {
        "atoms": [
            {"label": atom.label, "coordinates": atom.coordinates}
            for atom in phase.atoms()
        ],
        "frozen": gpx.get_Frozen(),
    }
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
