#!/usr/bin/env python3
"""Challenge the BaCO3 record with a canonicalized physical exact record."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc

from explore_refine import neutralize_hap, summarize


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cif", default="baco3_physical.cif")
    parser.add_argument("--output", default="trial_baco3_physical.gpx")
    args = parser.parse_args()
    gpx = G2sc.G2Project("final.gpx", newgpx=args.output)
    hist = gpx.histogram(0)
    old = gpx.phase("BaCO3")
    old_hap = old.data["Histograms"][hist.name]
    old_scale = float(old_hap["Scale"][0])
    old_strain = float(old_hap["Mustrain"][1][0])
    old_hap["Scale"] = [1e-12, False]
    old_hap["Mustrain"][2][:] = [False] * len(old_hap["Mustrain"][2])
    old.set_refinements({"Cell": False})

    new = gpx.add_phase(
        args.cif,
        phasename="BaCO3_physical",
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize_hap(new, hist.name, old_scale)
    new.set_refinements({"Cell": False})
    hap = new.data["Histograms"][hist.name]
    hap["Mustrain"][1][0] = old_strain
    hap["Mustrain"][2][0] = False
    gpx.set_Controls("parmMin", 1e-12, variable=f"{new.id}:{hist.id}:Scale")
    variable = f"{new.id}:{hist.id}:Mustrain;i"
    gpx.set_Controls("parmMin", 0.0, variable=variable)
    gpx.set_Controls("parmMax", 10000.0, variable=variable)
    gpx.set_Controls("cycles", 6)
    gpx.save()
    for _ in range(2):
        gpx.refine()
    new.set_refinements({"Cell": True})
    for _ in range(2):
        gpx.refine()
    hap["Mustrain"][2][0] = True
    for _ in range(2):
        gpx.refine()
    gpx.save()
    result = summarize(gpx)
    result["trial"] = {"old_scale": old_hap["Scale"], "new_hap": hap, "frozen": gpx.get_Frozen()}
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
