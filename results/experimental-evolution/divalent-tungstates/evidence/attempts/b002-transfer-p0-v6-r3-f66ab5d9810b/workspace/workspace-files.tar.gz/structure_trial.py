#!/usr/bin/env python3
"""Replay a small atom-coordinate trial from a converged GSAS-II project."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc

from explore_refine import summarize


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--atoms", nargs="+", required=True)
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.input, newgpx=args.output)
    phase = gpx.phase(args.phase)
    if phase is None:
        raise ValueError(f"unknown phase {args.phase}")
    phase.set_refinements({"Atoms": {label: "X" for label in args.atoms}})
    gpx.set_Controls("cycles", 6)
    gpx.save()
    for _ in range(2):
        gpx.refine()
    gpx.save()

    result = summarize(gpx)
    result["trial"] = {
        "phase": phase.name,
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": atom.coordinates,
                "occupancy": atom.occupancy,
                "uiso": atom.uiso,
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ],
        "frozen": gpx.get_Frozen(),
    }
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
