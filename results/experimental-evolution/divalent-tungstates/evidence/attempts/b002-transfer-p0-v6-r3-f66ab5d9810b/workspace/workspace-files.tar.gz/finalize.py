#!/usr/bin/env python3
"""Replay the accepted model and export all requested final artifacts."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE_PROJECT = ROOT / "trial_baco3_hybrid_direct.gpx"
FINAL_PROJECT = ROOT / "final.gpx"
MINOR_STRAIN_PHASES = {"WO3", "BaCO3", "Ba3W2O9"}


def neutralize_rejected_terms(gpx: G2sc.G2Project) -> None:
    """Retain the accepted baseline and explicitly clear rejected nuisance terms."""
    hist = gpx.histogram(0)
    x = np.asarray(hist.getdata("X"), dtype=float)
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})

    inst = hist.InstrumentParameters
    accepted_instrument = {"Zero", "Polariz.", "U", "W", "X"}
    for key, value in inst.items():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], (bool, np.bool_)):
            value[2] = key in accepted_instrument
    inst["I(L2)/I(L1)"][1] = 0.5
    inst["I(L2)/I(L1)"][2] = False
    inst["V"][1], inst["V"][2] = 0.0, False
    inst["Y"][1], inst["Y"][2] = 0.0, False
    inst["Z"][1], inst["Z"][2] = 0.0, False
    inst["SH/L"][1], inst["SH/L"][2] = 0.002, False

    sample = hist.SampleParameters
    if "Scale" in sample:
        sample["Scale"] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in sample and isinstance(sample[key], list):
            sample[key][0] = 0.0
            sample[key][1] = False

    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Extinction"] = [0.0, False]
        hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
        hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][1:] = [0.0, 1.0]
        hap["Mustrain"][2][:] = [False] * len(hap["Mustrain"][2])
        if phase.name in MINOR_STRAIN_PHASES:
            hap["Mustrain"][2][0] = True
        else:
            hap["Mustrain"][1][0] = 0.0

    gpx.set_Controls("cycles", 6)
    for parameter, lower, upper in (
        (":0:U", 0.0, 500.0),
        (":0:W", 0.0, 500.0),
        (":0:X", 0.0, 100.0),
        (":0:Polariz.", 0.0, 1.0),
    ):
        gpx.set_Controls("parmMin", lower, variable=parameter)
        gpx.set_Controls("parmMax", upper, variable=parameter)
    for phase in gpx.phases():
        gpx.set_Controls("parmMin", 1e-12, variable=f"{phase.id}:{hist.id}:Scale")
        if phase.name in MINOR_STRAIN_PHASES:
            variable = f"{phase.id}:{hist.id}:Mustrain;i"
            gpx.set_Controls("parmMin", 0.0, variable=variable)
            gpx.set_Controls("parmMax", 10000.0, variable=variable)


def replay() -> G2sc.G2Project:
    gpx = G2sc.G2Project(str(SOURCE_PROJECT), newgpx=str(FINAL_PROJECT))
    neutralize_rejected_terms(gpx)
    gpx.save()
    # Reopen before each full-range replay so the submitted project is tested
    # through the same serialization path used by a downstream reader.
    for _ in range(2):
        gpx = G2sc.G2Project(str(FINAL_PROJECT))
        gpx.refine()
        gpx.save()
    gpx = G2sc.G2Project(str(FINAL_PROJECT))
    frozen = list(gpx.get_Frozen())
    if frozen:
        raise RuntimeError(f"final refinement has frozen parameters: {frozen}")
    return gpx


def correlation_summary(gpx: G2sc.G2Project) -> dict:
    cov = gpx["Covariance"]["data"]
    matrix = np.asarray(cov.get("covMatrix"), dtype=float)
    labels = list(cov.get("varyList", []))
    if matrix.ndim != 2 or not labels:
        return {"maximum_absolute_correlation": None, "parameter_pair": []}
    standard = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    denom = np.outer(standard, standard)
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
    np.fill_diagonal(corr, 0.0)
    i, j = np.unravel_index(np.argmax(np.abs(corr)), corr.shape)
    return {
        "maximum_absolute_correlation": float(abs(corr[i, j])),
        "parameter_pair": [labels[i], labels[j]],
    }


def finite_float(value):
    """Return a JSON-safe float or None for an unavailable statistic."""
    converted = float(value)
    return converted if np.isfinite(converted) else None


def export(gpx: G2sc.G2Project) -> tuple[dict, dict]:
    hist = gpx.histogram(0)
    x = np.asarray(hist.getdata("X"), dtype=float)
    observed = np.asarray(hist.getdata("Yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("Ycalc"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)
    difference = observed - calculated

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        for row in zip(x, observed, calculated, difference, background):
            writer.writerow(
                [f"{row[0]:.8f}"] + [f"{value:.6f}" for value in row[1:]]
            )

    mass_fractions = hist.ComputeMassFracs()
    total = sum(float(value[0]) for value in mass_fractions.values())
    phase_records = []
    phase_details = {}
    for phase in gpx.phases():
        cif_name = f"phase_{phase.name}.cif"
        phase.export_CIF(str(ROOT / cif_name))
        fraction, esd = mass_fractions[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        hap = phase.data["Histograms"][hist.name]
        space_group = phase.data["General"]["SGData"]["SpGrp"].strip()
        record = {
            "name": phase.name,
            "formula": phase.name,
            "space_group": space_group,
            "cif_path": cif_name,
            "weight_fraction": float(fraction) / total,
            "weight_percent": 100.0 * float(fraction) / total,
            "weight_fraction_formal_esd": float(esd) / total,
            "weight_percent_formal_esd": 100.0 * float(esd) / total,
            "cell": {key: float(value) for key, value in cell.items()},
            "cell_formal_esd": {key: float(value) for key, value in cell_esd.items()},
            "phase_r_f_percent": float(hist.residuals[f"{phase.id}:{hist.id}:Rf"]),
            "isotropic_microstrain": float(hap["Mustrain"][1][0]),
        }
        phase_records.append(record)
        phase_details[phase.name] = record

    cov_rvals = gpx["Covariance"]["data"].get("Rvals", {})
    fit_statistics = {
        "r_wp_percent": float(hist.residuals["wR"]),
        "r_p_percent": float(hist.residuals["R"]),
        "r_exp_percent": float(hist.residuals["wRmin"]),
        "r_bragg_percent": float(hist.residuals["Rb"]),
        "weighted_r_bragg_percent": float(hist.residuals["wRb"]),
        "goodness_of_fit": finite_float(cov_rvals.get("GOF", np.nan)),
        "chi_square": finite_float(cov_rvals.get("chisq", np.nan)),
        "n_observations": int(cov_rvals.get("Nobs", len(x))),
        "n_refined_parameters": int(cov_rvals.get("Nvars", 0)),
        "durbin_watson": finite_float(hist.residuals.get("Durbin-Watson", np.nan)),
        "maximum_shift_over_esd": finite_float(cov_rvals.get("Max shft/sig", np.nan)),
        "converged": bool(cov_rvals.get("converged", False)),
        **correlation_summary(gpx),
    }
    result = {
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "measurement_range_two_theta_deg": [float(x[0]), float(x[-1])],
        "radiation": {
            "type": "Cu K-alpha doublet",
            "kalpha1_wavelength_angstrom": 1.540598,
            "kalpha2_wavelength_angstrom": 1.544426,
            "kalpha2_to_kalpha1_ratio": 0.5,
        },
        "phase_fraction_normalization": "modeled crystalline phases only",
        "modeled_crystalline_weight_fraction_sum": float(
            sum(record["weight_fraction"] for record in phase_records)
        ),
        "phases": phase_records,
        "fit_statistics": fit_statistics,
        "weighting_note": (
            "Pointwise standard uncertainties were not supplied; GSAS-II used "
            "counting-statistics weights, so fit and fraction esds are formal."
        ),
    }
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")
    return result, phase_details


def make_report(gpx: G2sc.G2Project, result: dict, phases: dict) -> None:
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    fractions = {name: record["weight_fraction"] for name, record in phases.items()}
    molar_mass = {
        "BaWO4": 137.327 + 183.84 + 4 * 15.999,
        "WO3": 183.84 + 3 * 15.999,
        "BaCO3": 137.327 + 12.011 + 3 * 15.999,
        "Ba3W2O9": 3 * 137.327 + 2 * 183.84 + 9 * 15.999,
    }
    stoich = {
        "BaWO4": (1, 1),
        "WO3": (0, 1),
        "BaCO3": (1, 0),
        "Ba3W2O9": (3, 2),
    }
    ba_moles = sum(fractions[name] * stoich[name][0] / molar_mass[name] for name in fractions)
    w_moles = sum(fractions[name] * stoich[name][1] / molar_mass[name] for name in fractions)
    ba_to_w = ba_moles / w_moles
    stats = result["fit_statistics"]

    rows = []
    for name in ("BaWO4", "WO3", "BaCO3", "Ba3W2O9"):
        phase = phases[name]
        cell = phase["cell"]
        if name in {"BaWO4", "Ba3W2O9"}:
            cell_text = f"a={cell['length_a']:.5f}, c={cell['length_c']:.5f} Å"
        elif name == "WO3":
            cell_text = (
                f"a={cell['length_a']:.5f}, b={cell['length_b']:.5f}, "
                f"c={cell['length_c']:.5f} Å, β={cell['angle_beta']:.4f}°"
            )
        else:
            cell_text = (
                f"a={cell['length_a']:.5f}, b={cell['length_b']:.5f}, "
                f"c={cell['length_c']:.5f} Å"
            )
        rows.append(
            f"| {name} | {phase['space_group']} | "
            f"{phase['weight_percent']:.2f} ± {phase['weight_percent_formal_esd']:.2f} | "
            f"{cell_text} |"
        )

    report = f"""# Quantitative phase analysis

The pattern is modeled by four crystalline phases. Fractions below are normalized to the modeled crystalline material; they do not measure amorphous content.

| Phase | Space group | Weight % (formal esd) | Refined cell |
|---|---:|---:|---|
{chr(10).join(rows)}

The refined fractions imply an overall Ba:W atomic ratio of {ba_to_w:.3f}, chemically consistent with a near-equimolar Ba/W precursor inventory. The final full-range fit ({result['measurement_range_two_theta_deg'][0]:.4f}–{result['measurement_range_two_theta_deg'][1]:.4f}° 2θ) has Rwp={stats['r_wp_percent']:.3f}%, Rp={stats['r_p_percent']:.3f}%, Rexp={stats['r_exp_percent']:.3f}%, and GOF={stats['goodness_of_fit']:.3f}. The last maximum shift/esd was {stats['maximum_shift_over_esd']:.3f}; no parameters were frozen at bounds.

## Phase evidence and model selection

- **BaWO4:** The dominant scheelite I41/a peak set and its low-, middle-, and high-angle doublets are reproduced by a fully occupied scheelite model. The sole exact COD record (1527204) uses split half-occupied oxygen sites and gives short 1.47/1.80 Å W–O contacts; it fit worse than a physical fully occupied model. I41/a BaMoO4, SrWO4, and CaWO4 parents were screened because the A-site and tetrahedral-site substitutions preserve the scheelite topology. The retained oxygen site gives a tetrahedral W–O distance near 1.83 Å. An unconstrained oxygen refinement lowered Rwp but lengthened W–O to about 1.97 Å, so it was rejected as nonphysical.
- **WO3:** Monoclinic gamma-WO3 (COD 2311041, P21/c setting) accounts for the residual precursor families. A second monoclinic record (1528915) was close but worse; triclinic 2106293 and orthorhombic 2107312 were clearly poorer under the same nuisance model. The powder data support the monoclinic topology and cell, but not subtle oxygen-displacement distinctions between closely related gamma-WO3 descriptions.
- **BaCO3:** Ambient witherite gives nonzero scale and coherent partly isolated families. COD 9010928 supplied the supported Ba sublattice and Pmcn setting, but its carbonate geometry contained a 1.41 Å C–O contact. Carbonate coordinates from the physical alternate exact Pnma record 1011149 were transformed into the same setting, giving three approximately 1.24 Å C–O bonds and a slightly better fit. The complete 1011149 intensity model and a substituted SrCO3 prototype were both poorer under the same nuisance model; the high-temperature trigonal record 1539129 was also worse.
- **Ba3W2O9:** COD 1533878 (R-3c) was identified from a residual family at approximately 26.28, 30.82, 37.67, 40.80, 43.02, 51.85, 53.71, and 63.07° 2θ. Their common scale and cell persist after the common profile is rebuilt, supporting a genuine secondary reaction product rather than a single-peak assignment.

## Refinement adequacy

The Cu Kα1/Kα2 wavelengths and 0.5 intensity ratio were fixed from the metadata. A smooth six-term Chebyshev background, one zero correction ({inst['Zero'][1]:.5f}°), effective polarization ({inst['Polariz.'][1]:.5f}), and a common nonnegative U/W/X profile ({inst['U'][1]:.3f}/{inst['W'][1]:.3f}/{inst['X'][1]:.3f}) reproduce isolated low-, middle-, and high-angle peak positions and widths. SH/L asymmetry, surface roughness, phase size, and preferred orientation were replayed and rejected: symmetry-distinct axial and diagonal March-Dollase trials changed Rwp by at most 0.004 percentage points without coherent multi-family support. Isotropic microstrain was retained only for the three broader minor phases (WO3 {phases['WO3']['isotropic_microstrain']:.0f}, BaCO3 {phases['BaCO3']['isotropic_microstrain']:.0f}, Ba3W2O9 {phases['Ba3W2O9']['isotropic_microstrain']:.0f} in GSAS-II microstrain units); BaWO4 strain and all size trials were unsupported or reached bounds. The background remains positive and smooth.

## Remaining uncertainty

No pointwise standard uncertainties or calibrated instrumental profile were supplied. GSAS-II counting-statistics weights make the tabulated esds formal and smaller than realistic model uncertainty; minor-phase fractions are likely uncertain at roughly the 1–3 wt% level because scale, broadening, overlap, and source-coordinate choices are coupled. The relatively large fitted zero correction also makes absolute cell errors more systematic than their formal esds. Atomic coordinates for the minor phases and the BaWO4 oxygen site cannot be determined reliably from this pattern and were therefore retained from physically screened source/prototype structures. Absolute amorphous content cannot be determined without an internal standard, so all reported fractions are crystalline-normalized.

The submitted [final.gpx](final.gpx) was reopened and replayed over the complete measured range before [fit.csv](fit.csv), [result.json](result.json), and the four phase CIFs were exported from that exact project state.
"""
    (ROOT / "report.md").write_text(report)


def main() -> None:
    gpx = replay()
    result, phases = export(gpx)
    make_report(gpx, result, phases)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
