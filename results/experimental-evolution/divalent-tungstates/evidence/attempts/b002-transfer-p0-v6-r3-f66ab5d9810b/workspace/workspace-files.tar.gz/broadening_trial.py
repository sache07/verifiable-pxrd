#!/usr/bin/env python3
"""Replay one phase-specific size or strain trial from a converged project."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc

from explore_refine import summarize


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--mode", choices=["size", "strain"], required=True)
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.input, newgpx=args.output)
    hist = gpx.histogram(0)
    phase = gpx.phase(args.phase)
    if phase is None:
        raise ValueError(f"unknown phase {args.phase}")
    hap = phase.data["Histograms"][hist.name]
    p_id = phase.id
    h_id = hist.id

    if args.mode == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [True, False, False]
        gpx.set_Controls("parmMin", 0.02, variable=f"{p_id}:{h_id}:Size;i")
        gpx.set_Controls("parmMax", 10.0, variable=f"{p_id}:{h_id}:Size;i")
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [True, False, False]
        gpx.set_Controls("parmMin", 0.0, variable=f"{p_id}:{h_id}:Mustrain;i")
        gpx.set_Controls("parmMax", 10000.0, variable=f"{p_id}:{h_id}:Mustrain;i")

    gpx.set_Controls("cycles", 6)
    gpx.save()
    for _ in range(2):
        gpx.refine()
    gpx.save()
    result = summarize(gpx)
    result["trial"] = {
        "phase": phase.name,
        "mode": args.mode,
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "frozen": gpx.get_Frozen(),
    }
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
