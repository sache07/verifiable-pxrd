#!/usr/bin/env python3
"""Rewrite a CIF in a conventional, symmetry-consistent setting."""

from __future__ import annotations

import argparse

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--replace", nargs=2, metavar=("OLD", "NEW"))
    args = parser.parse_args()
    structure = Structure.from_file(args.input)
    structure.remove_oxidation_states()
    if args.replace:
        structure.replace_species({args.replace[0]: args.replace[1]})
    CifWriter(structure, symprec=0.01, refine_struct=True).write_file(args.output)


if __name__ == "__main__":
    main()
