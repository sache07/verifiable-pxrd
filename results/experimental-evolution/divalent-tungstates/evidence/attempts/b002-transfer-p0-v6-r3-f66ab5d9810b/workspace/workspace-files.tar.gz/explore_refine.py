#!/usr/bin/env python3
"""Build comparable GSAS-II trial refinements for phase-inventory screening."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def initial_background(hist, ncoef: int = 6) -> list[float]:
    """Estimate a smooth lower-envelope background and Chebyshev coefficients."""
    from scipy.ndimage import gaussian_filter1d, percentile_filter

    x = np.asarray(hist.getdata("X"), dtype=float)
    y = np.asarray(hist.getdata("Yobs"), dtype=float)
    envelope = percentile_filter(y, percentile=18, size=301, mode="nearest")
    envelope = gaussian_filter1d(envelope, 80)
    xn = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    return np.polynomial.chebyshev.chebfit(xn, envelope, ncoef - 1).tolist()


def neutralize_hap(phase, hist_name: str, scale: float) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"] = [float(scale), True]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])


def summarize(gpx: G2sc.G2Project) -> dict:
    hist = gpx.histogram(0)
    x = np.asarray(hist.getdata("X"), dtype=float)
    in_range = (x >= hist.Limits("lower")) & (x <= hist.Limits("upper"))
    background = np.asarray(hist.getdata("Background"), dtype=float)
    result = {
        "residuals": hist.residuals,
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if isinstance(value, list) and len(value) > 1
        },
        "background": hist.Background[0],
        "background_min": float(np.min(background[in_range])),
        "background_max": float(np.max(background[in_range])),
        "phases": {},
    }
    try:
        mass_fracs = hist.ComputeMassFracs()
    except Exception as exc:  # trial projects can lack a usable covariance matrix
        mass_fracs = {"error": str(exc)}
    result["mass_fractions"] = mass_fracs
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "composition": phase.composition,
            "cell": phase.get_cell(),
            "density": phase.density,
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    return result


def build_and_refine(args: argparse.Namespace) -> dict:
    out = Path(args.out).resolve()
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(newgpx=str(out), author="OpenAI Codex")
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    coeffs = initial_background(hist, args.background_order)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": args.background_order,
                "coeffs": coeffs,
            }
        }
    )

    inst = hist.InstrumentParameters
    for key, value in {
        "Zero": 0.20,
        "U": 0.0,
        "V": 0.0,
        "W": 50.0,
        "X": 0.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "I(L2)/I(L1)": 0.5,
        "Polariz.": 0.5,
    }.items():
        inst[key][1] = value
        if len(inst[key]) > 2:
            inst[key][2] = False

    sample = hist.SampleParameters
    if "Scale" in sample:
        sample["Scale"] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in sample and isinstance(sample[key], list):
            sample[key][0] = 0.0
            sample[key][1] = False

    ba_file = ROOT / "ba_wo4_prototype.cif"
    if args.bawo4 == "exact":
        ba_file = cod_path("1527204")
    phase_specs = [("BaWO4", ba_file, 1.0)]
    if args.wo3.lower() != "none":
        phase_specs.append(("WO3", cod_path(args.wo3), 0.20))
    if args.baco3.lower() != "none":
        phase_specs.append(("BaCO3", cod_path(args.baco3), 0.12))
    if args.include_ba3w2o9:
        phase_specs.append(("Ba3W2O9", cod_path("1533878"), 0.25))
    phases = []
    for name, path, scale in phase_specs:
        phase = gpx.add_phase(
            str(path), phasename=name, histograms=[hist], fmthint="CIF"
        )
        neutralize_hap(phase, hist.name, scale)
        phase.set_refinements({"Cell": False})
        phases.append(phase)

    gpx.set_Controls("cycles", args.cycles)
    gpx.set_Controls("parmMin", 0.0, variable=":0:U")
    gpx.set_Controls("parmMin", 0.0, variable=":0:W")
    gpx.set_Controls("parmMin", 0.0, variable=":0:X")
    gpx.set_Controls("parmMax", 500.0, variable=":0:U")
    gpx.set_Controls("parmMax", 500.0, variable=":0:W")
    gpx.set_Controls("parmMax", 100.0, variable=":0:X")
    for i in range(len(phases)):
        gpx.set_Controls("parmMin", 1e-12, variable=f"{i}:0:Scale")

    # Re-establish background, scales, one angular correction and all cells.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    gpx.save()
    for _ in range(2):
        gpx.refine(printFile=None)

    # Release cells from the dominant phase down to the weakest phase so a
    # minor cell cannot run onto an unrelated family during early cycles.
    for phase in phases:
        phase.set_refinements({"Cell": True})
        gpx.refine(printFile=None)
    gpx.refine(printFile=None)

    if args.profile:
        # Common, low-dimensional and nonnegative profile baseline.
        hist.set_refinements({"Instrument Parameters": ["W", "X"]})
        for _ in range(2):
            gpx.refine(printFile=None)

    gpx.save()
    return summarize(gpx)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    parser.add_argument("--wo3", default="1528915")
    parser.add_argument("--baco3", default="9010928")
    parser.add_argument("--bawo4", choices=["prototype", "exact"], default="prototype")
    parser.add_argument("--background-order", type=int, default=6)
    parser.add_argument("--cycles", type=int, default=6)
    parser.add_argument("--include-ba3w2o9", action="store_true")
    parser.add_argument("--no-profile", dest="profile", action="store_false")
    parser.set_defaults(profile=True)
    args = parser.parse_args()
    print(json.dumps(build_and_refine(args), indent=2, default=str))


if __name__ == "__main__":
    main()
