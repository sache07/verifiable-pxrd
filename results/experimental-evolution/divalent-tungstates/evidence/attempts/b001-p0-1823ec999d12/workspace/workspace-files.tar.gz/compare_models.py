#!/usr/bin/env python3
"""Compare restrained profile/structure variants without touching final.gpx."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
IPARAMS = ROOT / "instrument.instprm"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif(cod: str) -> Path:
    return COD / cod[0] / cod[1:3] / cod[3:5] / f"{cod}.cif"


def set_triplet(item, value):
    item[0] = item[1] = float(value)
    item[2] = False


def build(tag: str, wo3_cod: str = "1528915"):
    filename = ROOT / f"test_{tag}.gpx"
    if filename.exists():
        filename.unlink()
    p = G2sc.G2Project(newgpx=str(filename))
    h = p.add_powder_histogram(str(PATTERN), str(IPARAMS),
                               fmthint="comma/tab/semicolon separated")
    h.Limits("lower", 10.0)
    h.Limits("upper", 100.0)
    # Prevent the otherwise exact linear dependency between histogram scale
    # and both phase scales.
    h.SampleParameters["Scale"][:] = [1.0, False]
    inst = h.InstrumentParameters
    for key, value in {
        "Lam1": 1.540598, "Lam2": 1.544426, "I(L2)/I(L1)": 0.5,
        "Zero": 0.42, "U": 2.0, "V": -2.0, "W": 5.0,
        "X": 0.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.002,
    }.items():
        set_triplet(inst[key], value)
    p0 = p.add_phase(str(cif("9009811")), phasename="PbWO4_scheelite",
                     histograms=[h], fmthint="CIF")
    p1 = p.add_phase(str(cif(wo3_cod)), phasename=f"WO3_{wo3_cod}",
                     histograms=[h], fmthint="CIF")
    for phase, size in [(p0, 0.07), (p1, 0.25)]:
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][:] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][1][2] = 0.5
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][2] = 0.5
        hap["Mustrain"][2] = [False, False, False]
    p.set_Controls("cycles", 8)
    p.save()
    for pid in (0, 1):
        p.set_Controls("parmMin", 0.005, f"{pid}:0:Size;i")
        p.set_Controls("parmMax", 5.0, f"{pid}:0:Size;i")
        p.set_Controls("parmMin", 0.0, f"{pid}:0:Mustrain;i")
        p.set_Controls("parmMax", 50000.0, f"{pid}:0:Mustrain;i")
        p.set_Controls("parmMin", 0.0, f"{pid}:0:Size;mx")
        p.set_Controls("parmMax", 1.0, f"{pid}:0:Size;mx")
    for name in ("W", "X"):
        p.set_Controls("parmMin", 0.0, f":0:{name}")
        p.set_Controls("parmMax", 100.0, f":0:{name}")
    return p


def run(tag: str, wo3_cod="1528915", refine_w=False, refine_x=False,
        strain=False, refine_mix=False):
    print(f"\n===== MODEL {tag} =====")
    p = build(tag, wo3_cod)
    h = p.histogram(0)
    # First fit only linear intensity terms and the smooth baseline.
    p.do_refinements([{"set": {
        "Background": {"type": "chebyschev-1", "refine": True,
                       "no. coeffs": 14},
        "PhaseFraction": True,
    }}])
    p.do_refinements([{"set": {"Instrument Parameters": ["Zero"]}}])
    p.do_refinements([{"set": {"Cell": True}}])

    for phase in p.phases():
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True,
                     "LGmix": {"value": 0.5, "refine": refine_mix}}
        })
        if strain:
            # Start from a small positive value so constrained refinement does
            # not step directly across the physical boundary.
            phase.data["Histograms"][h.name]["Mustrain"][1][0] = 500.0
            phase.set_HAP_refinements({
                "Mustrain": {"type": "isotropic", "refine": True,
                              "LGmix": {"value": 0.5, "refine": False}}
            })
    p.refine()
    ip = []
    if refine_w:
        ip.append("W")
    if refine_x:
        ip.append("X")
    if ip:
        h.set_refinements({"Instrument Parameters": ip})
        p.refine()
    # One final pass after all selected parameters have settled.
    p.refine()
    p.save()

    h = p.histogram(0)
    frac = h.ComputeMassFracs()
    out = {
        "tag": tag,
        "wo3_cod": wo3_cod,
        "residuals": h.residuals,
        "fractions": frac,
        "instrument": {key: h.InstrumentParameters[key][1]
                       for key in ("Zero", "U", "V", "W", "X", "Y")},
        "phases": {},
    }
    for phase in p.phases():
        hap = phase.data["Histograms"][h.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(), "scale": hap["Scale"],
            "size": hap["Size"], "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    print(json.dumps(out, indent=2, default=float))
    return out


def main():
    configs = [
        ("size_fixed", {}),
        ("size_W", {"refine_w": True}),
        ("size_WX", {"refine_w": True, "refine_x": True}),
        ("size_WX_mix", {"refine_w": True, "refine_x": True,
                         "refine_mix": True}),
        ("size_strain_WX", {"refine_w": True, "refine_x": True,
                            "strain": True}),
        ("triclinic_size_WX", {"wo3_cod": "2106293", "refine_w": True,
                               "refine_x": True}),
    ]
    results = [run(tag, **opts) for tag, opts in configs]
    (ROOT / "model_comparison.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    main()
