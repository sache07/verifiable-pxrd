#!/usr/bin/env python3
"""Test PbO polymorphs against the residual of the three-phase model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "test_three_wo3_2311041.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif(cod: str) -> Path:
    return COD / cod[0] / cod[1:3] / cod[3:5] / f"{cod}.cif"


def run(cod: str):
    target = ROOT / f"test_four_{cod}.gpx"
    p = G2sc.G2Project(str(BASE))
    p.save(str(target))
    p = G2sc.G2Project(str(target))
    h = p.histogram(0)
    phase = p.add_phase(str(cif(cod)), phasename=f"PbO_{cod}",
                        histograms=[h], fmthint="CIF")
    hap = phase.data["Histograms"][h.name]
    hap["Scale"][:] = [0.3, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.05
    hap["Size"][1][2] = 0.5
    hap["Mustrain"][1][0] = 0.0
    phase.set_refinements({"Cell": True})
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True,
                 "LGmix": {"value": 0.5, "refine": False}}
    })
    p.save()
    p.set_Controls("parmMin", 0.005, "3:0:Size;i")
    p.set_Controls("parmMax", 5.0, "3:0:Size;i")
    p.set_Controls("cycles", 12)
    p.refine()
    p.refine()
    p.save()
    h = p.histogram(0)
    result = {
        "cod": cod,
        "residuals": h.residuals,
        "fractions": h.ComputeMassFracs(),
        "instrument": {k: h.InstrumentParameters[k][1]
                       for k in ("Zero", "U", "V", "W", "X", "Y")},
        "phases": {},
    }
    for ph in p.phases():
        phap = ph.data["Histograms"][h.name]
        result["phases"][ph.name] = {
            "cell": ph.get_cell(), "scale": phap["Scale"],
            "size": phap["Size"],
        }
    print(json.dumps(result, indent=2, default=float))
    return result


def main():
    # 2310433 is orthorhombic massicot, 9012700 tetragonal litharge;
    # 1533609 is a long-axis orthorhombic PbO model included as a check.
    results = [run(cod) for cod in ("2310433", "9012700", "1533609")]
    (ROOT / "four_phase_comparison.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    main()
