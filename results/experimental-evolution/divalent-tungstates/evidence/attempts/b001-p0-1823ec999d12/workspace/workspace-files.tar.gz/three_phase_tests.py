#!/usr/bin/env python3
"""Test residual Pb3O4 structures by extending the stable two-phase fit."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif(cod: str) -> Path:
    return COD / cod[0] / cod[1:3] / cod[3:5] / f"{cod}.cif"


def run(cod: str, base: str = "test_size_fixed.gpx", tag: str | None = None):
    suffix = tag or cod
    target = ROOT / f"test_three_{suffix}.gpx"
    p = G2sc.G2Project(str(ROOT / base))
    p.save(str(target))
    p = G2sc.G2Project(str(target))
    h = p.histogram(0)
    phase = p.add_phase(str(cif(cod)), phasename=f"Pb3O4_{cod}",
                        histograms=[h], fmthint="CIF")
    hap = phase.data["Histograms"][h.name]
    hap["Scale"][:] = [0.5, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.08
    hap["Size"][1][2] = 0.5
    hap["Mustrain"][1][0] = 0.0
    phase.set_refinements({"Cell": True})
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True,
                 "LGmix": {"value": 0.5, "refine": False}}
    })
    p.save()
    p.set_Controls("parmMin", 0.005, "2:0:Size;i")
    p.set_Controls("parmMax", 5.0, "2:0:Size;i")
    p.set_Controls("cycles", 12)
    # Existing phases remain varied exactly as in the stable two-phase model.
    p.refine()
    p.refine()
    p.save()
    h = p.histogram(0)
    result = {
        "cod": cod,
        "residuals": h.residuals,
        "fractions": h.ComputeMassFracs(),
        "instrument": {k: h.InstrumentParameters[k][1]
                       for k in ("Zero", "U", "V", "W", "X", "Y")},
        "phases": {},
    }
    for ph in p.phases():
        phap = ph.data["Histograms"][h.name]
        result["phases"][ph.name] = {
            "cell": ph.get_cell(), "scale": phap["Scale"],
            "size": phap["Size"],
        }
    print(json.dumps(result, indent=2, default=float))
    return result


def main():
    # 9012124 and 1537983 are independent tetragonal P42/mbc entries;
    # 9013442 is its near-tetragonal orthorhombic representation, while
    # 9003043 is a genuinely different orthorhombic model.
    ids = ["9012124", "1537983", "9013442", "9003043"]
    results = [run(cod) for cod in ids]
    (ROOT / "three_phase_comparison.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    main()
