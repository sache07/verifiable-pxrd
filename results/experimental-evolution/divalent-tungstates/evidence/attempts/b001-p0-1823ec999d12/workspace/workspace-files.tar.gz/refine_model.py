#!/usr/bin/env python3
"""Build and refine the four-phase GSAS-II model for pattern.csv.

This script is kept alongside the submitted project to make the refinement
sequence and all exported values reproducible.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
IPARAMS = ROOT / "instrument.instprm"
GPX = ROOT / "final.gpx"

COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_cif(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PHASES = [
    ("PbWO4_scheelite", "PbWO4", cod_cif("9009811"), ROOT / "PbWO4.cif", 0.030),
    ("WO3_monoclinic", "WO3", cod_cif("2311041"), ROOT / "WO3.cif", 0.080),
    ("Pb3O4_minium", "Pb3O4", cod_cif("9012124"), ROOT / "Pb3O4.cif", 0.020),
    ("PbO_massicot", "PbO", cod_cif("2310433"), ROOT / "PbO.cif", 0.040),
]


def set_current(item, value: float) -> None:
    """Set both original and current values in a GSAS-II parameter triplet."""
    item[0] = float(value)
    item[1] = float(value)


def build_project() -> tuple[G2sc.G2Project, G2sc.G2PwdrData]:
    if GPX.exists():
        GPX.unlink()
    project = G2sc.G2Project(newgpx=str(GPX))
    hist = project.add_powder_histogram(
        str(PATTERN), str(IPARAMS), fmthint="comma/tab/semicolon separated"
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)

    # Only relative phase scales are needed for quantitative phase analysis.
    # Fixing the histogram scale removes an exact linear dependency with all
    # phase scales and gives a full-rank covariance matrix.
    hist.SampleParameters["Scale"][:] = [1.0, False]

    # Wavelength values are specified by metadata. With no calibrated profile,
    # generic laboratory instrument-width terms remain fixed; only one
    # effective sample-broadening term per phase is refined below.
    inst = hist.InstrumentParameters
    set_current(inst["Zero"], 0.42)
    set_current(inst["Lam1"], 1.540598)
    set_current(inst["Lam2"], 1.544426)
    set_current(inst["I(L2)/I(L1)"], 0.5)

    for name, _, source, _, initial_size in PHASES:
        phase = project.add_phase(
            str(source), phasename=name, histograms=[hist], fmthint="CIF"
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][:] = [1.0, False]
        # The phases have visibly different line widths. Start with physically
        # plausible effective coherent-domain sizes, with a fixed 50:50
        # Gaussian/Lorentzian sample broadening mix. Instrument-profile
        # calibration was not supplied, so only these effective phase widths
        # are varied, not a correlated set of U,V,W,X,Y terms.
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = initial_size
        hap["Size"][1][2] = 0.5
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][2] = 0.5
        hap["Mustrain"][2] = [False, False, False]

    project.set_Controls("cycles", 12)
    project.save()
    for pid in range(len(PHASES)):
        project.set_Controls("parmMin", 0.005, f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 5.0, f"{pid}:0:Size;i")
    return project, hist


def show_state(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(f"\nSTATE {label}: {hist.residuals}")
    print("instrument", {
        k: v[1] for k, v in hist.InstrumentParameters.items()
        if isinstance(v, list) and len(v) >= 2 and k in
        {"Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)"}
    })
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"], "mustrain", hap["Mustrain"])
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass fractions unavailable", repr(exc))


def refine_project(project: G2sc.G2Project) -> G2sc.G2Project:
    hist = project.histogram(0)

    # The measured baseline is smooth but strongly curved. Fourteen terms are
    # enough to follow it over 90 degrees without fitting individual peaks.
    # Release scale, position, lattice, and sample-broadening terms in order.
    steps = [
        {"set": {
            "Background": {"type": "chebyschev-1", "refine": True,
                           "no. coeffs": 14},
            "PhaseFraction": True,
        }},
        {"set": {"Instrument Parameters": ["Zero"]}},
        {"set": {"Cell": True}},
    ]
    for i, step in enumerate(steps, start=1):
        project.do_refinements([step], makeBack=False)
        show_state(project, f"step {i}")

    # Release one effective isotropic coherent-domain size per phase after the
    # scale and lattice parameters have stabilized.
    for phase in project.phases():
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True,
                     "LGmix": {"value": 0.5, "refine": False}}
        })
    project.refine(makeBack=False)
    show_state(project, "phase broadening")
    project.refine(makeBack=False)
    show_state(project, "final convergence")

    project.save(str(GPX))
    return project


def export_outputs(project: G2sc.G2Project) -> None:
    # Reloading guarantees every export is taken from the serialized final GPX.
    project.save(str(GPX))
    project = G2sc.G2Project(str(GPX))
    hist = project.histogram(0)

    for phase, (_, _, _, outfile, _) in zip(project.phases(), PHASES):
        phase.export_CIF(str(outfile))

    arrays = [np.asarray(hist.getdata(key), dtype=float) for key in
              ("X", "Yobs", "Ycalc", "Residual", "Background")]
    # GSAS-II stores the input range outside the selected refinement limits
    # with zeroed calculated arrays. Export only the points for which the
    # profile was evaluated, including the endpoint selected internally by
    # GSAS-II's grid indexing.
    evaluated = arrays[4] != 0.0
    arrays = [values[evaluated] for values in arrays]
    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta_deg", "observed", "calculated",
                         "difference", "background"])
        writer.writerows(zip(*arrays))

    fractions = hist.ComputeMassFracs()
    total = sum(value[0] for value in fractions.values())
    phase_results = []
    for phase, (_, formula, source, outfile, _) in zip(project.phases(), PHASES):
        value, sigma = fractions[phase.name]
        cell = {key: float(number) for key, number in phase.get_cell().items()}
        phase_results.append({
            "name": phase.name,
            "formula": formula,
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "source_cod_id": source.stem,
            "cif_path": outfile.name,
            "weight_fraction": value / total,
            "weight_fraction_esd": sigma / total,
            "refined_cell": cell,
        })

    gof = float(hist.residuals["wR"] / hist.residuals["wRmin"])
    result = {
        "phases": phase_results,
        "fraction_normalization": "modeled crystalline phases only",
        "fit_statistics": {
            "Rwp_percent": float(hist.residuals["wR"]),
            "Rp_percent": float(hist.residuals["R"]),
            "Rwp_background_subtracted_percent": float(hist.residuals["wRb"]),
            "Rp_background_subtracted_percent": float(hist.residuals["Rb"]),
            "Rexp_percent": float(hist.residuals["wRmin"]),
            "goodness_of_fit_Rwp_over_Rexp": gof,
            "chi_square": gof ** 2,
        },
        "profile_range_two_theta_deg": [float(arrays[0][0]),
                                         float(arrays[0][-1])],
        "profile_point_count": int(len(arrays[0])),
        "project_path": GPX.name,
        "profile_path": "fit.csv",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")


def main() -> None:
    project, _ = build_project()
    project = refine_project(project)
    export_outputs(project)


if __name__ == "__main__":
    main()
