#!/usr/bin/env python3
"""Replay the selected model and export the exact submitted artifacts."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "pol_strain_shl.gpx"
FINAL = ROOT / "final.gpx"


def main() -> None:
    gpx = G2sc.G2Project(str(SOURCE), filename=str(FINAL))
    hist = gpx.histogram(0)
    # Include every supplied point in the final replay and exported profile.
    observed_limits = hist.data["Limits"][0]
    hist.data["Limits"][1][:] = observed_limits[:]
    hist.Excluded([])
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    gpx.save()
    gpx.refine()
    gpx.save()

    # Required reopen/replay check, with the same full-range model.
    gpx = G2sc.G2Project(str(FINAL))
    gpx.set_Controls("cycles", 12)
    gpx.refine()
    gpx.save()

    # Reopen once more so exports are guaranteed to come from final.gpx on disk.
    gpx = G2sc.G2Project(str(FINAL))
    hist = gpx.histogram(0)
    cif_names = {
        "ZnWO4_wolframite": "ZnWO4_wolframite.cif",
        "WO3_monoclinic": "WO3_monoclinic.cif",
        "ZnO_wurtzite": "ZnO_wurtzite.cif",
    }
    for phase in gpx.phases():
        phase.export_CIF(str(ROOT / cif_names[phase.name]))

    columns = (
        np.asarray(hist.getdata("X"), dtype=float),
        np.asarray(hist.getdata("Yobs"), dtype=float),
        np.asarray(hist.getdata("Ycalc"), dtype=float),
        np.asarray(hist.getdata("Residual"), dtype=float),
        np.asarray(hist.getdata("Background"), dtype=float),
    )
    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            ["two_theta_deg", "observed_intensity", "calculated_intensity",
             "difference_observed_minus_calculated", "background_intensity"]
        )
        for row in zip(*columns):
            writer.writerow([f"{row[0]:.8f}"] + [f"{value:.8f}" for value in row[1:]])

    cov = gpx.data["Covariance"]["data"]
    cells = {}
    for phase in gpx.phases():
        value, esd = phase.get_cell_and_esd()
        cells[phase.name] = {"value": value, "esd": esd}
    result = {
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "cells": cells,
        "instrument": hist.InstrumentParameters,
        "limits": hist.data["Limits"][1],
        "covariance_Rvals": cov.get("Rvals", {}),
        "varying_parameters": {
            str(name): {"value": float(value), "esd": float(esd)}
            for name, value, esd in zip(
                cov.get("varyList", []), cov.get("variables", []), cov.get("sig", [])
            )
        },
        "cifs": cif_names,
    }
    print("FINAL_SUMMARY " + json.dumps(result, default=str))


if __name__ == "__main__":
    main()
