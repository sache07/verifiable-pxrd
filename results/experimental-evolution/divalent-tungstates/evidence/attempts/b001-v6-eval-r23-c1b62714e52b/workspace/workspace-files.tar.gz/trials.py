#!/usr/bin/env python3
"""Controlled one-change refinement trials for a converged GSAS-II project."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine import summary


def replay(gpx, label: str) -> None:
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    gpx.refine()
    gpx.save()
    # A second pass catches non-replay-stable minima without changing the model.
    check = G2sc.G2Project(gpx.filename)
    check.set_Controls("cycles", 12)
    check.refine()
    check.save()
    summary(check, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "trial",
        choices=("replace_strain", "add_strain", "size_lgmix",
                 "inst_u", "inst_x", "shl", "polariz", "texture"),
    )
    parser.add_argument("--phase")
    parser.add_argument("--axis", nargs=3, type=int)
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.source.resolve()), filename=str(args.output.resolve()))
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    if args.trial in ("replace_strain", "add_strain", "size_lgmix", "texture"):
        if not args.phase:
            parser.error("this trial requires --phase")
        phase = gpx.phase(args.phase)
        hap = phase.getHAPvalues(hist)
        if args.trial == "texture":
            if args.axis is None:
                parser.error("texture requires --axis h k l")
            po = hap["Pref.Ori."]
            po[0] = "MD"
            po[1] = 1.02
            po[2] = True
            po[3] = list(args.axis)
        elif args.trial == "replace_strain":
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 10.0
            hap["Size"][2] = [False for _ in hap["Size"][2]]
            hap["Size"][5] = [False for _ in hap["Size"][5]]
        if args.trial in ("replace_strain", "add_strain"):
            phase.setSampleProfile(hist, "microstrain", "isotropic", 500.0, LGmix=1.0)
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True,
                               "LGmix": {"value": 1.0, "refine": False}}}, [hist]
            )
        elif args.trial == "size_lgmix":
            hap["Size"][1][2] = 0.8
            hap["Size"][2][2] = True
    elif args.trial == "inst_u":
        inst["U"][1] = 2.0
        inst["U"][2] = True
    elif args.trial == "inst_x":
        inst["X"][1] = 0.5
        inst["X"][2] = True
    elif args.trial == "shl":
        inst["SH/L"][1] = 0.02
        inst["SH/L"][2] = True
    elif args.trial == "polariz":
        inst["Polariz."][1] = 0.5
        inst["Polariz."][2] = True

    gpx.save()
    axis_label = "" if args.axis is None else "_" + "".join(str(v) for v in args.axis)
    replay(gpx, args.trial + ("_" + args.phase if args.phase else "") + axis_label)


if __name__ == "__main__":
    main()
