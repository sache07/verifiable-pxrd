#!/usr/bin/env python3
"""Build, refine, audit, and export the final GSAS-II phase model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def set_neutral_hap(phase, hist) -> None:
    """Remove phase-specific broadening, texture, roughness surrogates, etc."""
    hap = phase.getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 100.0  # micrometres: effectively no size broadening
    hap["Size"][1][1] = 100.0
    hap["Size"][1][2] = 1.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][1][2] = 1.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Scale"][0] = 1.0
    hap["Scale"][1] = False


def summary(gpx, label: str) -> dict:
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    phases = {}
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    out = {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {k: v for k, v in inst.items()},
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": phases,
    }
    try:
        out["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    print("SUMMARY " + json.dumps(out, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x)))
    return out


def build(output: Path, wo3_id: str) -> G2sc.G2Project:
    gpx = G2sc.G2Project(newgpx=str(output))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.08)
    hist.Excluded([])
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": False,
                "no. coeffs": 6,
                "coeffs": [1200.0, -500.0, 300.0, -150.0, 70.0, -30.0],
            }
        }
    )

    phase_specs = [
        ("ZnWO4_wolframite", "1520641"),
        ("WO3_monoclinic", wo3_id),
        ("ZnO_wurtzite", "9004178"),
    ]
    for name, cod_id in phase_specs:
        phase = gpx.add_phase(
            str(cod_path(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase.data["General"]["Name"] = name
        set_neutral_hap(phase, hist)

    # Reflection geometry. Keep all unused corrections fixed at neutral values.
    sample = hist.SampleParameters
    sample["Type"] = "Bragg-Brentano"
    sample["Scale"][0] = 1.0
    sample["Scale"][1] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in sample and isinstance(sample[key], list):
            sample[key][0] = 0.0
            sample[key][1] = False

    gpx.set_Controls("cycles", 8)
    controls = gpx.data["Controls"]["data"]
    controls["min dM/M"] = 1.0e-5
    gpx.save()
    return gpx


def refine_step(gpx, label: str, set_dict=None, clear_dict=None) -> dict:
    if clear_dict:
        gpx.set_refinement({"clear": clear_dict})
    if set_dict:
        gpx.set_refinement({"set": set_dict})
    gpx.refine()
    gpx.save()
    return summary(gpx, label)


def baseline(output: Path, wo3_id: str) -> None:
    gpx = build(output, wo3_id)
    summary(gpx, "built")
    refine_step(gpx, "background_scales", {"Background": True, "Scale": True})
    refine_step(gpx, "cells", {"Cell": True})
    refine_step(gpx, "zero", {"Instrument Parameters": ["Zero"]})
    refine_step(gpx, "profile_W", {"Instrument Parameters": ["W"]})
    refine_step(gpx, "profile_UW", {"Instrument Parameters": ["U", "W"]})
    refine_step(gpx, "profile_UWX", {"Instrument Parameters": ["U", "W", "X"]})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / ".tmp" / "baseline.gpx")
    parser.add_argument("--wo3", default="1528915")
    args = parser.parse_args()
    baseline(args.output.resolve(), args.wo3)


if __name__ == "__main__":
    main()
