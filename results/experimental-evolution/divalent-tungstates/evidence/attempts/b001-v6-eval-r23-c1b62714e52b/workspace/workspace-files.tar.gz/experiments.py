#!/usr/bin/env python3
"""Run controlled GSAS-II profile/model trials from an existing project."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine import build, summary


def load_copy(source: Path, output: Path):
    gpx = G2sc.G2Project(str(source.resolve()), filename=str(output.resolve()))
    gpx.save()
    return gpx


def clean_common_profile(gpx, w: float = 10.0) -> None:
    hist = gpx.histogram(0)
    hist.SampleParameters["Scale"] = [1.0, False]
    inst = hist.InstrumentParameters
    for key, value in (("U", 0.0), ("V", 0.0), ("W", w), ("X", 0.0), ("Y", 0.0), ("Z", 0.0)):
        inst[key][1] = value
        inst[key][2] = False
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][1][2] = 1.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def refine(gpx, label: str) -> None:
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    gpx.refine()
    gpx.save()
    summary(gpx, label)


def size_sequence(gpx) -> None:
    clean_common_profile(gpx)
    hist = gpx.histogram(0)
    for name, start in (
        ("ZnWO4_wolframite", 0.04),
        ("WO3_monoclinic", 0.06),
        ("ZnO_wurtzite", 0.08),
    ):
        phase = gpx.phase(name)
        phase.setSampleProfile(hist, "size", "isotropic", start, LGmix=1.0)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True,
                      "LGmix": {"value": 1.0, "refine": False}}}, [hist]
        )
        refine(gpx, "add_size_" + name)

    hist.InstrumentParameters["W"][2] = True
    refine(gpx, "sizes_plus_W")
    # Save/reopen and replay, as a stability check.
    filename = gpx.filename
    gpx.save()
    replay = G2sc.G2Project(filename)
    replay.set_Controls("cycles", 12)
    replay.refine()
    replay.save()
    summary(replay, "sizes_plus_W_replay")


def full_model(output: Path, wo3_id: str) -> None:
    gpx = build(output.resolve(), wo3_id)
    hist = gpx.histogram(0)
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    gpx.set_refinement({"set": {"Background": True, "Scale": True}})
    refine(gpx, "background_scales")
    gpx.set_refinement({"set": {"Cell": True}})
    refine(gpx, "cells")
    gpx.set_refinement({"set": {"Instrument Parameters": ["Zero"]}})
    refine(gpx, "zero")
    size_sequence(gpx)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path, nargs="?")
    parser.add_argument("output", type=Path)
    parser.add_argument("trial", choices=("sizes", "full"))
    parser.add_argument("--wo3", default="1528915")
    args = parser.parse_args()
    if args.trial == "sizes":
        if args.source is None:
            parser.error("the sizes trial requires a source project")
        gpx = load_copy(args.source, args.output)
        size_sequence(gpx)
    elif args.trial == "full":
        full_model(args.output, args.wo3)


if __name__ == "__main__":
    main()
