#!/usr/bin/env python3
"""Create and inspect a minimal GSAS-II project for this pattern."""

import csv
import math
from pathlib import Path
from pprint import pprint

from GSASII import GSASIIscriptable as G2sc


def write_inputs() -> tuple[Path, Path]:
    out = Path(".tmp/gsas")
    out.mkdir(parents=True, exist_ok=True)
    xye = out / "pattern.xye"
    with Path("inputs/pattern.csv").open(newline="") as source, xye.open("w") as target:
        for row in csv.DictReader(source):
            intensity = float(row["intensity"])
            target.write(
                f'{float(row["two_theta_deg"]):.8f} {intensity:.8f} '
                f'{math.sqrt(max(intensity, 1.0)):.8f}\n'
            )
    inst = out / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for reflection Cu Ka data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.5;"
        "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:2.0;V:-2.0;W:5.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )
    return xye, inst


def main() -> None:
    xye, inst = write_inputs()
    project = G2sc.G2Project(newgpx=".tmp/gsas/probe.gpx")
    histogram = project.add_powder_histogram(
        str(xye), str(inst), fmthint="xye"
    )
    phase = project.add_phase(
        ".tmp/candidates/mnwo4_from_9008124.cif",
        phasename="MnWO4_P2c_9008124",
        histograms=[histogram],
        fmthint="CIF",
    )
    project.set_Controls("cycles", 4)
    project.save()
    print("HIST", histogram.name)
    print("INSTRUMENT")
    pprint(histogram.data["Instrument Parameters"])
    print("SAMPLE")
    pprint(histogram.data["Sample Parameters"])
    print("BACKGROUND")
    pprint(histogram.data["Background"])
    print("LIMITS")
    pprint(histogram.data["Limits"])
    print("CELL", phase.get_cell())
    print("HAP")
    pprint(phase.data["Histograms"])
    print("ATOMS")
    pprint(phase.data["Atoms"])


if __name__ == "__main__":
    main()
