#!/usr/bin/env python3
"""Build and challenge two-phase GSAS-II models for MnWO4 + WO3."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from gsas_trials import START_CELL, ensure_inputs, set_cell


def neutralize_hap(phase, histogram) -> None:
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"] = [1.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][3] = [0, 0, 1]
    hap["Size"][4] = [10.0, 10.0, 10.0, 0.0, 0.0, 0.0]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][3] = [0, 0, 1]
    hap["Mustrain"][4] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def configure_histogram(histogram, background_order: int, geometry: str) -> None:
    sample = histogram.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [800.0 if geometry == "shift" else 0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    instrument = histogram.data["Instrument Parameters"][0]
    values = {
        "Zero": -0.40 if geometry == "zero" else 0.0,
        "U": 0.0,
        "V": 0.0,
        "W": 5.0,
        "X": 0.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "Polariz.": 0.5,
    }
    for key, value in values.items():
        instrument[key][1] = value
        instrument[key][2] = False
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": False,
                "no. coeffs": background_order,
                "coeffs": [1500.0] + [0.0] * (background_order - 1),
            }
        }
    )


def add_bounds(project) -> None:
    project.save()
    for variable, minimum in [
        (":0:U", 0.0),
        (":0:W", 0.0),
        (":0:X", 0.0),
        (":0:SH/L", 0.0),
        (":0:Polariz.", 0.0),
        ("0:0:Scale", 1e-8),
        ("1:0:Scale", 1e-8),
        ("0:0:Size;i", 0.001),
        ("1:0:Size;i", 0.001),
        ("0:0:Size;a", 0.001),
        ("1:0:Size;a", 0.001),
        ("0:0:Mustrain;i", 0.0),
        ("1:0:Mustrain;i", 0.0),
    ]:
        project.set_Controls("parmMin", minimum, variable=variable)
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")


def compact_summary(project, label: str) -> dict:
    histogram = project.histogram(0)
    covariance = project.data.get("Covariance", {}).get("data", {})
    inst = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    try:
        mass_fractions = histogram.ComputeMassFracs()
    except Exception as error:
        mass_fractions = {"error": str(error)}
    rvals = covariance.get("Rvals", {})
    return {
        "label": label,
        "project": project.filename,
        "Rwp": rvals.get("Rwp", histogram.get_wR()),
        "GOF": rvals.get("GOF"),
        "chisq": rvals.get("chisq"),
        "Nvars": rvals.get("Nvars"),
        "converged": rvals.get("converged"),
        "message": rvals.get("msg", ""),
        "residuals": histogram.residuals,
        "instrument": {
            key: inst[key][1]
            for key in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]
        },
        "sample": {
            key: sample[key][0]
            for key in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]
        },
        "background": histogram.data["Background"][0],
        "phases": phases,
        "mass_fractions": mass_fractions,
        "varyList": covariance.get("varyList", []),
        "variables": list(covariance.get("variables", [])),
        "sig": list(covariance.get("sig", [])),
    }


def build_baseline(
    main_source: Path,
    secondary_source: Path,
    output: Path,
    background_order: int,
    geometry: str,
) -> tuple[G2sc.G2Project, list[dict]]:
    xye, inst = ensure_inputs()
    project = G2sc.G2Project(newgpx=str(output))
    histogram = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    main = project.add_phase(
        str(main_source), phasename="MnWO4", histograms=[histogram], fmthint="CIF"
    )
    secondary = project.add_phase(
        str(secondary_source), phasename="WO3", histograms=[histogram], fmthint="CIF"
    )
    set_cell(main, START_CELL)
    for phase in [main, secondary]:
        neutralize_hap(phase, histogram)
    configure_histogram(histogram, background_order, geometry)
    project.set_Controls("cycles", 14)
    add_bounds(project)
    log = [compact_summary(project, "neutral")]

    histogram.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    project.refine()
    log.append(compact_summary(project, "background_scales"))

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    if geometry == "zero":
        histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    else:
        histogram.set_refinements({"Sample Parameters": ["Shift"]})
    project.refine()
    log.append(compact_summary(project, f"cells_{geometry}"))

    project.save()
    return project, log


def profile_trial(
    source_project: Path,
    output: Path,
    model: str,
) -> tuple[G2sc.G2Project, dict]:
    project = G2sc.G2Project(str(source_project), newgpx=str(output))
    histogram = project.histogram(0)
    instrument = histogram.data["Instrument Parameters"][0]
    # Restore the complete neutral profile before each comparison.
    for key, value in {"U": 0.0, "V": 0.0, "W": 5.0, "X": 0.0, "Y": 0.0, "Z": 0.0}.items():
        instrument[key][1] = value
        instrument[key][2] = False
    active = {"W": ["W"], "X": ["X"], "WX": ["W", "X"]}[model]
    histogram.set_refinements({"Instrument Parameters": active})
    add_bounds(project)
    project.refine()
    project.refine()
    project.save()
    return project, compact_summary(project, f"common_{model}")


def apply_broadening(phase, histogram, model: str) -> None:
    old_hap = phase.data["Histograms"][histogram.name]
    old_scale = list(old_hap["Scale"])
    old_preferred_orientation = [
        value.copy() if isinstance(value, (list, dict)) else value
        for value in old_hap["Pref.Ori."]
    ]
    neutralize_hap(phase, histogram)
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"] = old_scale
    hap["Pref.Ori."] = old_preferred_orientation
    if model in {"size", "combined"}:
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.15
        hap["Size"][2][0] = True
    if model in {"strain", "combined"}:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True


def broadening_trial(
    source_project: Path,
    output: Path,
    phase_index: int,
    model: str,
) -> tuple[G2sc.G2Project, dict]:
    project = G2sc.G2Project(str(source_project), newgpx=str(output))
    histogram = project.histogram(0)
    phase = project.phase(phase_index)
    apply_broadening(phase, histogram, model)
    add_bounds(project)
    project.refine()
    project.refine()
    project.save()
    return project, compact_summary(project, f"phase{phase_index}_{model}")


def write_log(path: Path | None, rows: list[dict]) -> None:
    text = json.dumps(rows, indent=2, default=str)
    if path:
        path.write_text(text + "\n")
    print(text)


def full_model(
    main_source: Path,
    secondary_source: Path,
    output: Path,
    background_order: int,
    geometry: str,
) -> tuple[G2sc.G2Project, list[dict]]:
    stem = output.with_suffix("")
    cells_path = Path(f"{stem}_cells.gpx")
    profile_path = Path(f"{stem}_profile.gpx")
    broad_path = Path(f"{stem}_broad.gpx")
    _, initial = build_baseline(
        main_source,
        secondary_source,
        cells_path,
        background_order,
        geometry,
    )
    _, profile = profile_trial(cells_path, profile_path, "X")
    _, broad = broadening_trial(profile_path, broad_path, 1, "size")
    final_project, replay = profile_trial(broad_path, output, "X")
    return final_project, initial + [profile, broad, replay]


def nuisance_trial(
    source_project: Path,
    output: Path,
    model: str,
    background_order: int | None = None,
) -> tuple[G2sc.G2Project, dict]:
    project = G2sc.G2Project(str(source_project), newgpx=str(output))
    histogram = project.histogram(0)
    if model == "background":
        if background_order is None:
            raise ValueError("background order is required")
        histogram.set_refinements(
            {
                "Background": {
                    "type": "chebyschev-1",
                    "refine": True,
                    "no. coeffs": background_order,
                }
            }
        )
        label = f"background_{background_order}"
    elif model == "polarization":
        inst = histogram.data["Instrument Parameters"][0]
        inst["Polariz."][1:] = [0.5, True]
        histogram.set_refinements({"Instrument Parameters": ["Polariz."]})
        label = "polarization"
    elif model == "roughness":
        sample = histogram.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.1, True]
        sample["SurfRoughB"] = [0.1, True]
        histogram.set_refinements(
            {"Sample Parameters": ["SurfRoughA", "SurfRoughB"]}
        )
        project.save()
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 5.0, variable=":0:SurfRoughB")
        label = "roughness"
    elif model == "roughness-neutral":
        sample = histogram.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.0, False]
        label = "roughness_neutral"
    elif model == "shift-neutral":
        sample = histogram.data["Sample Parameters"]
        sample["Shift"] = [0.0, False]
        label = "shift_neutral"
    else:
        raise ValueError(model)
    add_bounds(project)
    project.refine()
    project.refine()
    project.save()
    return project, compact_summary(project, label)


def texture_trial(
    source_project: Path,
    output: Path,
    phase_index: int,
    axis: list[int],
) -> tuple[G2sc.G2Project, dict]:
    project = G2sc.G2Project(str(source_project), newgpx=str(output))
    histogram = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.data["Histograms"][histogram.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    neutral = axis == [0, 0, 0]
    hap["Pref.Ori."][2] = not neutral
    hap["Pref.Ori."][3] = [0, 0, 1] if neutral else [int(value) for value in axis]
    project.save()
    if not neutral:
        variable = f"{phase_index}:0:MD"
        project.set_Controls("parmMin", 0.2, variable=variable)
        project.set_Controls("parmMax", 5.0, variable=variable)
    add_bounds(project)
    project.refine()
    project.refine()
    project.save()
    axis_name = "neutral" if neutral else "".join(str(value) for value in axis)
    return project, compact_summary(project, f"texture_p{phase_index}_{axis_name}")


def anisotropy_trial(
    source_project: Path,
    output: Path,
    phase_index: int,
    axis: list[int],
) -> tuple[G2sc.G2Project, dict]:
    project = G2sc.G2Project(str(source_project), newgpx=str(output))
    histogram = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.data["Histograms"][histogram.name]
    initial = max(0.01, float(hap["Size"][1][0]))
    hap["Size"][0] = "uniaxial"
    hap["Size"][1] = [initial, initial, hap["Size"][1][2]]
    hap["Size"][2] = [True, True, False]
    hap["Size"][3] = [int(value) for value in axis]
    add_bounds(project)
    project.refine()
    project.refine()
    project.save()
    axis_name = "".join(str(value) for value in axis)
    return project, compact_summary(project, f"anisotropy_p{phase_index}_{axis_name}")


def atom_trial(
    source_project: Path,
    output: Path,
    phase_index: int,
    labels: list[str],
    flags: str,
) -> tuple[G2sc.G2Project, dict]:
    """Refine selected atom parameters while preserving the complete checkpoint."""
    project = G2sc.G2Project(str(source_project), newgpx=str(output))
    phase = project.phase(phase_index)
    phase.set_refinements(
        {"Atoms": {label: flags for label in labels}}
    )
    add_bounds(project)
    project.refine()
    project.refine()
    project.save()
    return project, compact_summary(
        project, f"atoms_p{phase_index}_{'-'.join(labels)}_{flags}"
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    base = sub.add_parser("baseline")
    base.add_argument("--main", type=Path, required=True)
    base.add_argument("--secondary", type=Path, required=True)
    base.add_argument("--output", type=Path, required=True)
    base.add_argument("--background-order", type=int, default=6)
    base.add_argument("--geometry", choices=["zero", "shift"], default="zero")
    base.add_argument("--log", type=Path)

    broad = sub.add_parser("broadening")
    broad.add_argument("--input", type=Path, required=True)
    broad.add_argument("--output", type=Path, required=True)
    broad.add_argument("--phase", type=int, choices=[0, 1], required=True)
    broad.add_argument(
        "--model", choices=["neutral", "size", "strain", "combined"], required=True
    )
    broad.add_argument("--log", type=Path)

    profile = sub.add_parser("profile")
    profile.add_argument("--input", type=Path, required=True)
    profile.add_argument("--output", type=Path, required=True)
    profile.add_argument("--model", choices=["W", "X", "WX"], required=True)
    profile.add_argument("--log", type=Path)

    show = sub.add_parser("summary")
    show.add_argument("project", type=Path)

    full = sub.add_parser("full")
    full.add_argument("--main", type=Path, required=True)
    full.add_argument("--secondary", type=Path, required=True)
    full.add_argument("--output", type=Path, required=True)
    full.add_argument("--background-order", type=int, default=6)
    full.add_argument("--geometry", choices=["zero", "shift"], default="shift")
    full.add_argument("--log", type=Path)

    nuisance = sub.add_parser("nuisance")
    nuisance.add_argument("--input", type=Path, required=True)
    nuisance.add_argument("--output", type=Path, required=True)
    nuisance.add_argument(
        "--model",
        choices=[
            "background",
            "polarization",
            "roughness",
            "roughness-neutral",
            "shift-neutral",
        ],
        required=True,
    )
    nuisance.add_argument("--background-order", type=int)
    nuisance.add_argument("--log", type=Path)

    replay = sub.add_parser("replay")
    replay.add_argument("--input", type=Path, required=True)
    replay.add_argument("--output", type=Path, required=True)
    replay.add_argument("--log", type=Path)

    texture = sub.add_parser("texture")
    texture.add_argument("--input", type=Path, required=True)
    texture.add_argument("--output", type=Path, required=True)
    texture.add_argument("--phase", type=int, choices=[0, 1], required=True)
    texture.add_argument("--axis", type=int, nargs=3, required=True)
    texture.add_argument("--log", type=Path)

    anisotropy = sub.add_parser("anisotropy")
    anisotropy.add_argument("--input", type=Path, required=True)
    anisotropy.add_argument("--output", type=Path, required=True)
    anisotropy.add_argument("--phase", type=int, choices=[0, 1], required=True)
    anisotropy.add_argument("--axis", type=int, nargs=3, required=True)
    anisotropy.add_argument("--log", type=Path)

    atoms = sub.add_parser("atoms")
    atoms.add_argument("--input", type=Path, required=True)
    atoms.add_argument("--output", type=Path, required=True)
    atoms.add_argument("--phase", type=int, choices=[0, 1], required=True)
    atoms.add_argument("--labels", nargs="+", required=True)
    atoms.add_argument("--flags", choices=["X", "U", "XU"], default="X")
    atoms.add_argument("--log", type=Path)

    args = parser.parse_args()
    if args.command == "atoms":
        args.output.parent.mkdir(parents=True, exist_ok=True)
        _, row = atom_trial(
            args.input,
            args.output,
            args.phase,
            args.labels,
            args.flags,
        )
        write_log(args.log, [row])
    elif args.command == "anisotropy":
        args.output.parent.mkdir(parents=True, exist_ok=True)
        _, row = anisotropy_trial(
            args.input,
            args.output,
            args.phase,
            args.axis,
        )
        write_log(args.log, [row])
    elif args.command == "texture":
        args.output.parent.mkdir(parents=True, exist_ok=True)
        _, row = texture_trial(
            args.input,
            args.output,
            args.phase,
            args.axis,
        )
        write_log(args.log, [row])
    elif args.command == "replay":
        args.output.parent.mkdir(parents=True, exist_ok=True)
        project = G2sc.G2Project(str(args.input), newgpx=str(args.output))
        add_bounds(project)
        project.refine()
        project.refine()
        project.save()
        write_log(args.log, [compact_summary(project, "replay")])
    elif args.command == "nuisance":
        args.output.parent.mkdir(parents=True, exist_ok=True)
        _, row = nuisance_trial(
            args.input,
            args.output,
            args.model,
            args.background_order,
        )
        write_log(args.log, [row])
    elif args.command == "full":
        args.output.parent.mkdir(parents=True, exist_ok=True)
        _, rows = full_model(
            args.main,
            args.secondary,
            args.output,
            args.background_order,
            args.geometry,
        )
        write_log(args.log, rows)
    elif args.command == "baseline":
        args.output.parent.mkdir(parents=True, exist_ok=True)
        _, rows = build_baseline(
            args.main,
            args.secondary,
            args.output,
            args.background_order,
            args.geometry,
        )
        write_log(args.log, rows)
    elif args.command == "profile":
        args.output.parent.mkdir(parents=True, exist_ok=True)
        _, row = profile_trial(args.input, args.output, args.model)
        write_log(args.log, [row])
    elif args.command == "broadening":
        args.output.parent.mkdir(parents=True, exist_ok=True)
        _, row = broadening_trial(args.input, args.output, args.phase, args.model)
        write_log(args.log, [row])
    else:
        project = G2sc.G2Project(str(args.project))
        write_log(None, [compact_summary(project, args.project.name)])


if __name__ == "__main__":
    main()
