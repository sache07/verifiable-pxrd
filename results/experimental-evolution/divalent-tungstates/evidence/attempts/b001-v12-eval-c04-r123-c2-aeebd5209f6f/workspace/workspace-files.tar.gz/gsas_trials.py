#!/usr/bin/env python3
"""Run reproducible GSAS-II source/profile trials from neutral checkpoints."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


START_CELL = [4.8004, 5.70825, 4.97833, 90.0, 91.12825, 90.0]


def ensure_inputs() -> tuple[Path, Path]:
    out = Path(".tmp/gsas")
    out.mkdir(parents=True, exist_ok=True)
    xye = out / "pattern.xye"
    if not xye.exists():
        with Path("inputs/pattern.csv").open(newline="") as source, xye.open("w") as target:
            for row in csv.DictReader(source):
                intensity = float(row["intensity"])
                target.write(
                    f'{float(row["two_theta_deg"]):.8f} {intensity:.8f} '
                    f'{math.sqrt(max(intensity, 1.0)):.8f}\n'
                )
    inst = out / "instrument.instprm"
    if not inst.exists():
        inst.write_text(
            "#GSAS-II instrument parameter file for reflection Cu Ka data\n"
            "Type:PXC;Bank:1\n"
            "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.5;"
            "Azimuth:0.0;I(L2)/I(L1):0.5\n"
            "U:2.0;V:0.0;W:5.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
        )
    return xye, inst


def set_cell(phase, cell: list[float]) -> None:
    phase.data["General"]["Cell"][1:7] = cell
    a, b, c, alpha, beta, gamma = cell
    volume = (
        a
        * b
        * c
        * math.sqrt(
            1
            + 2
            * math.cos(math.radians(alpha))
            * math.cos(math.radians(beta))
            * math.cos(math.radians(gamma))
            - math.cos(math.radians(alpha)) ** 2
            - math.cos(math.radians(beta)) ** 2
            - math.cos(math.radians(gamma)) ** 2
        )
    )
    phase.data["General"]["Cell"][7] = volume


def make_neutral_project(source: Path, output: Path, background_order: int = 6):
    xye, inst = ensure_inputs()
    project = G2sc.G2Project(newgpx=str(output))
    histogram = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    phase = project.add_phase(
        str(source),
        phasename="MnWO4",
        histograms=[histogram],
        fmthint="CIF",
    )
    set_cell(phase, START_CELL)

    # Make all inactive HAP terms genuinely neutral.
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"] = [1.0, False]
    hap["Size"] = [
        "isotropic",
        [100.0, 100.0, 1.0],
        [False, False, False],
        [0, 0, 1],
        [100.0, 100.0, 100.0, 0.0, 0.0, 0.0],
        [False] * 6,
    ]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][4] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]

    sample = histogram.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    instrument = histogram.data["Instrument Parameters"][0]
    initial = {
        "Zero": -0.40,
        "U": 2.0,
        "V": 0.0,
        "W": 5.0,
        "X": 0.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "Polariz.": 0.5,
    }
    for key, value in initial.items():
        instrument[key][1] = value
        instrument[key][2] = False

    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": False,
                "no. coeffs": background_order,
                "coeffs": [1500.0] + [0.0] * (background_order - 1),
            }
        }
    )
    project.set_Controls("cycles", 12)
    project.save()
    return project


def summary(project, label: str) -> dict:
    histogram = project.histogram(0)
    phase = project.phase(0)
    covariance = project.data.get("Covariance", {}).get("data", {})
    return {
        "label": label,
        "file": project.filename,
        "residuals": histogram.residuals,
        "Rvals": covariance.get("Rvals", {}),
        "cell": phase.get_cell(),
        "instrument": {
            key: value[1]
            for key, value in histogram.data["Instrument Parameters"][0].items()
            if key in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."}
        },
        "sample": {
            key: value[0]
            for key, value in histogram.data["Sample Parameters"].items()
            if isinstance(value, list) and key in {"Shift", "Transparency", "SurfRoughA", "SurfRoughB"}
        },
        "hap": phase.data["Histograms"][histogram.name],
        "varyList": covariance.get("varyList", []),
        "variables": covariance.get("variables", []),
        "sig": covariance.get("sig", []),
    }


def refine_source(source: Path, output: Path, background_order: int = 6) -> list[dict]:
    project = make_neutral_project(source, output, background_order)
    histogram = project.histogram(0)
    phase = project.phase(0)
    log = [summary(project, "neutral")]

    histogram.set_refinements({"Background": {"refine": True}})
    phase.set_HAP_refinements({"Scale": True})
    project.refine()
    log.append(summary(project, "background_scale"))

    phase.set_refinements({"Cell": True})
    histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    log.append(summary(project, "cell_zero"))

    histogram.set_refinements({"Instrument Parameters": ["U", "W"]})
    project.refine()
    log.append(summary(project, "profile_UW"))

    histogram.set_refinements({"Instrument Parameters": ["X"]})
    project.refine()
    log.append(summary(project, "profile_UWX"))

    histogram.set_refinements({"Instrument Parameters": ["SH/L"]})
    project.refine()
    log.append(summary(project, "asymmetry_SHL"))

    project.save()
    return log


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--background-order", type=int, default=6)
    parser.add_argument("--log", type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    log = refine_source(args.source, args.output, args.background_order)
    text = json.dumps(log, indent=2, default=str)
    if args.log:
        args.log.write_text(text + "\n")
    print(text)


if __name__ == "__main__":
    main()
