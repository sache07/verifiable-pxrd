#!/usr/bin/env python3
"""Construct chemistry-adapted candidate CIFs from screened COD parents."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(
    "<RUN>/"
    "resources/b001-c04/cif"
)
OUT = Path(".tmp/candidates")


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def adapt(cod_id: str, substitutions: dict[str, str], name: str) -> None:
    structure = Structure.from_file(cod_path(cod_id))
    structure.replace_species(substitutions)
    CifWriter(structure, symprec=0.01, refine_struct=False).write_file(OUT / name)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    adapt("9008124", {"Fe": "Mn"}, "mnwo4_from_9008124.cif")
    adapt("1567215", {"Fe": "Mn"}, "mnwo4_from_1567215.cif")
    adapt("1568792", {"Fe": "Mn"}, "mnwo4_from_1568792.cif")
    adapt("1527061", {"Mo": "W"}, "mnwo4_c2m_from_1527061.cif")


if __name__ == "__main__":
    main()
