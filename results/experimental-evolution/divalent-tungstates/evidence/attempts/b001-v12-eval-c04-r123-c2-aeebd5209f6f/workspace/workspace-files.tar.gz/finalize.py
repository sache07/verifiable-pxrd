#!/usr/bin/env python3
"""Export the final GSAS-II refinement into the requested submission files."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"
PROFILE = ROOT / "fit.csv"
RESULT = ROOT / "result.json"
CIF_NAMES = {"MnWO4": "MnWO4.cif", "WO3": "WO3.cif"}


project = G2sc.G2Project(str(PROJECT))
histogram = project.histogram(0)
covariance = project.data["Covariance"]["data"]
rvals = covariance["Rvals"]
residuals = histogram.residuals

# GSAS-II powder arrays: x, observed, weight, calculated, background, difference.
arrays = np.asarray(histogram.data["data"][1], dtype=float)
x, observed, _weight, calculated, background, difference = arrays
with PROFILE.open("w", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(
        [
            "two_theta_deg",
            "observed_intensity",
            "calculated_intensity",
            "difference_intensity",
            "background_intensity",
        ]
    )
    writer.writerows(zip(x, observed, calculated, difference, background))

mass_fractions = histogram.ComputeMassFracs()
total = sum(float(value[0]) for value in mass_fractions.values())
phases = []
for index, phase in enumerate(project.phases()):
    cif_name = CIF_NAMES[phase.name]
    phase.export_CIF(str(ROOT / cif_name))
    value, esd = mass_fractions[phase.name]
    phases.append(
        {
            "name": phase.name,
            "formula": "MnWO4" if phase.name == "MnWO4" else "WO3",
            "cif_path": cif_name,
            "project_path": "final.gpx",
            "weight_fraction": float(value) / total,
            "weight_fraction_esd": float(esd) / total,
            "phase_Rf_percent": float(residuals[f"{index}:0:Rf"]),
        }
    )

result = {
    "project_path": "final.gpx",
    "fit_profile_path": "fit.csv",
    "fraction_basis": "normalized over the modeled crystalline phases",
    "phases": phases,
    "fit_statistics": {
        "Rwp_percent": float(rvals["Rwp"]),
        "Rp_percent": float(residuals["R"]),
        "Rexp_percent": float(residuals["wRmin"]),
        "GOF": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "number_observations": int(rvals["Nobs"]),
        "number_refined_variables": int(rvals["Nvars"]),
        "converged": bool(rvals["converged"]),
    },
    "weighting": "Poisson proxy sigma=sqrt(counts); no point uncertainties were supplied",
}
RESULT.write_text(json.dumps(result, indent=2) + "\n")
