#!/usr/bin/env python3
"""Refine and replay one common polarization correction."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--fixed", type=float)
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.base.resolve()), newgpx=str(args.output.resolve()))
    hist = gpx.histogram(0)
    if args.fixed is None:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    else:
        polar = hist.data["Instrument Parameters"][0]["Polariz."]
        polar[1] = args.fixed
        polar[2] = False
    gpx.set_Controls("cycles", 12)
    gpx.save()
    if args.fixed is None:
        gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
        gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()

    gpx = G2sc.G2Project(str(args.output.resolve()))
    gpx.refine(makeBack=False)
    gpx.save()
    hist = gpx.histogram(0)
    result = {
        "rwp": hist.get_wR(),
        "rp": hist.data["data"][0].get("R"),
        "durbin_watson": hist.data["data"][0].get("Durbin-Watson"),
        "polarization": hist.data["Instrument Parameters"][0]["Polariz."][1],
        "mass_fractions": hist.ComputeMassFracs(),
    }
    args.output.with_suffix(".polarization.json").write_text(
        json.dumps(result, indent=2, default=float)
    )
    print("POLARIZATION_RESULT", json.dumps(result, default=float, sort_keys=True))


if __name__ == "__main__":
    main()
