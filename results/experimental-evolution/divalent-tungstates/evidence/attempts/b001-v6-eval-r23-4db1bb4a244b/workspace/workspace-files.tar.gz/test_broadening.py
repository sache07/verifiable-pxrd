#!/usr/bin/env python3
"""Replay one isotropic phase-broadening alternative from a common project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("phase")
    parser.add_argument("output", type=Path)
    parser.add_argument("mode", choices=("strain_only", "size_plus_strain"))
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.base.resolve()), newgpx=str(args.output.resolve()))
    hist = gpx.histogram(0)
    phase = gpx.phase(args.phase)
    if phase is None:
        raise ValueError(f"Phase not found: {args.phase}")

    hap = phase.data["Histograms"][hist.name]
    if args.mode == "strain_only":
        phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
        phase.clear_HAP_refinements({"Size": True}, [hist])

    # Seed from a physically neutral (zero) strain through a small positive
    # value so that the least-squares derivative is defined. Keep the same
    # Lorentzian broadening character used in the size trial.
    phase.setSampleProfile(hist, "microstrain", "isotropic", 500.0, LGmix=1.0)
    phase.set_HAP_refinements({
        "Mustrain": {
            "type": "isotropic",
            "refine": True,
            "LGmix": {"value": 1.0, "refine": False},
        }
    }, [hist])

    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.set_Controls("parmMin", 0.0, f"{phase.id}:0:Mustrain;i")
    gpx.set_Controls("parmMax", 10000.0, f"{phase.id}:0:Mustrain;i")
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()

    # Reopen and replay the same full-range model.
    gpx = G2sc.G2Project(str(args.output.resolve()))
    gpx.refine(makeBack=False)
    gpx.save()
    hist = gpx.histogram(0)
    phase = gpx.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    result = {
        "phase": phase.name,
        "mode": args.mode,
        "rwp": hist.get_wR(),
        "rp": hist.data["data"][0].get("R"),
        "durbin_watson": hist.data["data"][0].get("Durbin-Watson"),
        "size_um": hap["Size"][1][0],
        "size_refined": hap["Size"][2][0],
        "microstrain_ppm": hap["Mustrain"][1][0],
        "microstrain_refined": hap["Mustrain"][2][0],
        "mass_fractions": hist.ComputeMassFracs(),
    }
    args.output.with_suffix(".broadening.json").write_text(
        json.dumps(result, indent=2, default=float)
    )
    print("BROADENING_RESULT", json.dumps(result, default=float, sort_keys=True))


if __name__ == "__main__":
    main()
