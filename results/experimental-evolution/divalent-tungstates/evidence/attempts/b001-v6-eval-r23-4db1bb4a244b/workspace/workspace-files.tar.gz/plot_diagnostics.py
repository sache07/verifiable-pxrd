#!/usr/bin/env python3
"""Plot full-range and selected isolated-family residuals from a GSAS-II project."""

from __future__ import annotations

import argparse

import matplotlib.pyplot as plt
import numpy as np

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("output")
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.project)
    hist = gpx.histogram(0)
    x, yo, _w, yc, yb, yd = hist.data["data"][1]

    centers = [
        (24.01, "WO3 020"), (34.04, "WO3 200"), (55.87, "WO3 202"),
        (27.79, "PbWO4 112"), (47.36, "PbWO4 220"), (68.97, "PbWO4 040"),
        (32.53, "Pb3O4 310"), (47.92, "Pb3O4 213"), (63.70, "Pb3O4 600"),
        (30.79, "PbO 200"), (45.55, "PbO 220"), (68.62, "PbO 040"),
    ]
    fig, axes = plt.subplots(5, 3, figsize=(13, 15), constrained_layout=True)
    for ax, (lo, hi) in zip(axes[0], [(9.9, 40), (40, 70), (70, 100.1)]):
        take = (x >= lo) & (x <= hi)
        ax.plot(x[take], yo[take], color="black", lw=0.7, label="observed")
        ax.plot(x[take], yc[take], color="tab:red", lw=0.7, label="calculated")
        ax.plot(x[take], yd[take] + np.min(yb[take]), color="tab:blue", lw=0.55, label="difference")
        ax.set_xlim(lo, hi)
        ax.set_title(f"{lo:.0f}–{hi:.0f} deg")
    for ax, (center, label) in zip(axes[1:].flat, centers):
        take = (x >= center - 0.8) & (x <= center + 0.8)
        ax.plot(x[take], yo[take], color="black", marker=".", ms=1.5, lw=0.7)
        ax.plot(x[take], yc[take], color="tab:red", lw=0.8)
        ax.plot(x[take], yb[take], color="tab:orange", lw=0.55)
        ax.set_xlim(center - 0.8, center + 0.8)
        ax.set_title(label)
    for ax in axes.flat:
        ax.tick_params(labelsize=7)
        ax.set_xlabel(r"$2\theta$ (deg)", fontsize=8)
    axes[0, 0].legend(fontsize=7)
    fig.savefig(args.output, dpi=180)


if __name__ == "__main__":
    main()
