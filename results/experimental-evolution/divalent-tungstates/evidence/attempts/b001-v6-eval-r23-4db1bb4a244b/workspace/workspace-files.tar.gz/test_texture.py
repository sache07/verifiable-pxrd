#!/usr/bin/env python3
"""Test one March-Dollase texture axis from a common converged project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("phase")
    parser.add_argument("output", type=Path)
    parser.add_argument("axis", nargs=3, type=int)
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.base.resolve()), newgpx=str(args.output.resolve()))
    hist = gpx.histogram(0)
    phase = gpx.phase(args.phase)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(args.axis)
    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.set_Controls("parmMin", 0.2, f"{phase.id}:0:MD")
    gpx.set_Controls("parmMax", 5.0, f"{phase.id}:0:MD")
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()

    # Replay once from disk.
    gpx = G2sc.G2Project(str(args.output.resolve()))
    gpx.refine(makeBack=False)
    gpx.save()
    hist = gpx.histogram(0)
    phase = gpx.phase(args.phase)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    result = {
        "axis": list(args.axis),
        "rwp": hist.get_wR(),
        "rp": hist.data["data"][0].get("R"),
        "durbin_watson": hist.data["data"][0].get("Durbin-Watson"),
        "md_ratio": po[1],
        "mass_fractions": hist.ComputeMassFracs(),
    }
    args.output.with_suffix(".texture.json").write_text(
        json.dumps(result, indent=2, default=float)
    )
    print("TEXTURE_RESULT", json.dumps(result, default=float, sort_keys=True))


if __name__ == "__main__":
    main()
