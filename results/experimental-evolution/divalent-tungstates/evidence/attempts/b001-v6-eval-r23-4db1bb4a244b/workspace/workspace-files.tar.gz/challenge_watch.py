#!/usr/bin/env python3
"""Challenge a weak candidate under a fixed, replayed common profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_explore import CANDIDATES, cod_path, neutralize_hap, state


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("candidate", choices=sorted(CANDIDATES))
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.base.resolve()), newgpx=str(args.output.resolve()))
    hist = gpx.histogram(0)

    # Keep the established U/W/X profile and accepted phase-size terms fixed
    # for the initial scale challenge. Refit only the smooth background, all
    # phase scales, established cells, and the one specimen-height correction.
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        if key in inst:
            inst[key][2] = False
    hist.data["Background"][0][1] = True
    hist.data["Sample Parameters"]["Shift"][1] = True
    hist.data["Sample Parameters"]["Scale"][1] = False
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True}, [hist])
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])

    candidate = gpx.add_phase(
        str(cod_path(CANDIDATES[args.candidate])),
        phasename=args.candidate,
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize_hap(candidate, hist.name)
    candidate.HAPvalue("Scale", 0.1, [hist])
    candidate.set_HAP_refinements({"Scale": True}, [hist])
    candidate.set_refinements({"Cell": False})
    gpx.save()
    gpx.set_Controls("parmMin", 0.0, f"{candidate.id}:0:Scale")
    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.refine(makeBack=False)
    first = state(gpx, "watch_scale_challenge")
    gpx.save()

    # Reopen/replay with the same settings to detect unstable scales.
    gpx = G2sc.G2Project(str(args.output.resolve()))
    gpx.refine(makeBack=False)
    second = state(gpx, "watch_reopened_replay")
    gpx.save()
    args.output.with_suffix(".states.json").write_text(
        json.dumps([first, second], indent=2, default=float)
    )


if __name__ == "__main__":
    main()
