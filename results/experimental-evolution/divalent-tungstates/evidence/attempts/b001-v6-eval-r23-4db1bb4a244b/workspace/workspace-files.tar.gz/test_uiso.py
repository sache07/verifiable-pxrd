#!/usr/bin/env python3
"""Test one shared isotropic displacement parameter for a phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("phase")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.base.resolve()), newgpx=str(args.output.resolve()))
    phase = gpx.phase(args.phase)
    if phase is None:
        raise ValueError(f"Phase not found: {args.phase}")
    atoms = phase.atoms()
    for atom in atoms:
        atom.uiso = 0.005
        atom.refinement_flags = "U"
    gpx.save()

    names = tuple(f"{phase.id}::AUiso:{i}" for i in range(len(atoms)))
    if len(names) > 1:
        gpx.add_EquivConstr(names)
    gpx.set_Controls("parmMin", 0.0, names[0])
    gpx.set_Controls("parmMax", 0.05, names[0])
    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()

    # Reopen/replay with exactly the saved constraint and flags.
    gpx = G2sc.G2Project(str(args.output.resolve()))
    gpx.refine(makeBack=False)
    gpx.save()
    hist = gpx.histogram(0)
    phase = gpx.phase(args.phase)
    result = {
        "phase": phase.name,
        "rwp": hist.get_wR(),
        "rp": hist.data["data"][0].get("R"),
        "durbin_watson": hist.data["data"][0].get("Durbin-Watson"),
        "uiso_A2": {atom.label: atom.uiso for atom in phase.atoms()},
        "mass_fractions": hist.ComputeMassFracs(),
    }
    args.output.with_suffix(".uiso.json").write_text(
        json.dumps(result, indent=2, default=float)
    )
    print("UISO_RESULT", json.dumps(result, default=float, sort_keys=True))


if __name__ == "__main__":
    main()
