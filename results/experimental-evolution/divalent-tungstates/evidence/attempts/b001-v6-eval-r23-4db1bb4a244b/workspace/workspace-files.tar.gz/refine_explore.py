#!/usr/bin/env python3
"""Build and iteratively refine trial GSAS-II phase inventories."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

CANDIDATES = {
    "PbWO4_scheelite": "9009811",
    "PbWO4_raspite": "9007617",
    "WO3_monoclinic": "1528915",
    "WO3_monoclinic_alt": "2311041",
    "WO3_triclinic": "2106293",
    "WO3_orthorhombic": "2107312",
    "WO3_high_pressure": "1563541",
    "Pb3O4_tetragonal": "1537983",
    "Pb3O4_tetragonal_alt": "9012124",
    "PbO_litharge": "9012700",
    "PbO_massicot": "2310433",
}

# Width seeds inferred from isolated peak families (micrometres in GSAS-II).
# They are held fixed while the common profile is established, then challenged
# one phase at a time below.
SIZE_SEEDS = {
    "PbWO4_scheelite": 0.06,
    "Pb3O4_tetragonal": 0.04,
    "Pb3O4_tetragonal_alt": 0.04,
    "PbO_massicot": 0.04,
    "PbO_litharge": 0.04,
}


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make_xye() -> Path:
    source = ROOT / "inputs" / "pattern.csv"
    target = ROOT / "pattern.xye"
    with source.open(newline="") as src, target.open("w") as dst:
        reader = csv.DictReader(src)
        dst.write("# Original counts; weights assigned as Poisson 1/I by GSAS-II\n")
        for row in reader:
            dst.write(f"{float(row['two_theta_deg']):.8f} {float(row['intensity']):.8f}\n")
    return target


def phase_state(phase, hist_name: str) -> dict:
    hap = phase.data["Histograms"][hist_name]
    return {
        "name": phase.name,
        "cell": phase.get_cell(),
        "scale": hap["Scale"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
    }


def state(gpx, label: str) -> dict:
    hist = gpx.histogram(0)
    vals = hist.data["data"][0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    try:
        fracs = hist.ComputeMassFracs()
    except Exception as err:
        fracs = {"error": repr(err)}
    out = {
        "label": label,
        "residuals": {k: v for k, v in vals.items() if np.isscalar(v)},
        "instrument": {k: v for k, v in inst.items() if k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)")},
        "sample": {k: v for k, v in sample.items() if k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Scale", "Gonio. radius")},
        "mass_fractions": fracs,
        "background": hist.data["Background"][0],
        "phases": [phase_state(p, hist.name) for p in gpx.phases()],
    }
    print("STATE", json.dumps(out, default=float, sort_keys=True))
    return out


def refine(gpx, label: str) -> dict:
    gpx.refine(makeBack=False)
    return state(gpx, label)


def neutralize_hap(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    # Neutral, non-refined sample effects. Large sizes suppress size broadening.
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][1][1] = 10.0
    hap["Size"][1][2] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][1][2] = 1.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}


def build_project(model_names: list[str], output: Path) -> tuple:
    xye = make_xye()
    gpx = G2sc.G2Project(newgpx=str(output))
    hist = gpx.add_powder_histogram(
        str(xye), str(ROOT / "instrument.instprm"), fmthint="Topas"
    )
    for name in model_names:
        cif = cod_path(CANDIDATES[name])
        if not cif.is_file():
            raise FileNotFoundError(cif)
        gpx.add_phase(
            str(cif), phasename=name, histograms=[hist], fmthint="CIF"
        )

    # Whole measured range; smooth low-order background.
    hist.set_refinements({
        "Limits": [9.90343322, 100.09455322],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 6,
        },
    })
    for phase in gpx.phases():
        neutralize_hap(phase, hist.name)
        phase.set_HAP_refinements({"Scale": True}, [hist])

    # Reflection geometry defaults are already selected by the dual wavelength.
    # Start near the specimen-height correction inferred from peak-position drift.
    sample = hist.data["Sample Parameters"]
    # GSAS-II stores this Bragg-Brentano sample-height term in micrometres.
    sample["Shift"] = [-750.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    # Keep the overall scale fixed; otherwise it is exactly redundant with
    # refining every HAP phase scale.
    sample["Scale"] = [1.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 10.0, "V": 0.0, "W": 5.0, "X": 1.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.002}.items():
        inst[key][1] = value
        inst[key][2] = False
    gpx.set_Controls("cycles", 12)
    gpx.save()
    # Explicit physical bounds for scale and low-dimensional profile terms.
    for key in (":0:U", ":0:W", ":0:X"):
        gpx.set_Controls("parmMin", 0.0, key)
    for phase in gpx.phases():
        gpx.set_Controls("parmMin", 0.0, f"{phase.id}:0:Scale")
        gpx.set_Controls("parmMin", 0.005, f"{phase.id}:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, f"{phase.id}:0:Size;i")
    gpx.set_Controls("parmMin", -2000.0, ":0:Shift")
    gpx.set_Controls("parmMax", 2000.0, ":0:Shift")
    gpx.save()
    return gpx, hist


def run(model_names: list[str], output: Path, phase_sizes: bool) -> None:
    gpx, hist = build_project(model_names, output)
    if phase_sizes:
        # Seed the visibly broadened phases before determining the common
        # instrumental profile from sharp WO3 families.
        for phase_name, size in SIZE_SEEDS.items():
            if phase_name in model_names:
                gpx.phase(phase_name).setSampleProfile(
                    hist, "size", "isotropic", size, LGmix=1.0
                )
    states = [state(gpx, "initial")]

    # Scales and smooth background only.
    states.append(refine(gpx, "background_scales"))

    # One angular correction and phase cells, with nuisance model unchanged.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    states.append(refine(gpx, "shift_cells"))

    # Common nonnegative low-dimensional profile, one term at a time.
    hist.set_refinements({"Instrument Parameters": ["W"]})
    states.append(refine(gpx, "profile_W"))
    hist.set_refinements({"Instrument Parameters": ["U"]})
    states.append(refine(gpx, "profile_UW"))
    hist.set_refinements({"Instrument Parameters": ["X"]})
    states.append(refine(gpx, "profile_UWX"))

    if phase_sizes:
        # Compare isotropic size one phase at a time. Accepted terms remain
        # active while the next phase is challenged.
        for phase_name in SIZE_SEEDS:
            if phase_name not in model_names:
                continue
            phase = gpx.phase(phase_name)
            phase.set_HAP_refinements({
                "Size": {"type": "isotropic", "refine": True,
                         "LGmix": {"value": 1.0, "refine": False}}
            }, [hist])
            states.append(refine(gpx, f"{phase_name}_isotropic_size"))

    # Replay from disk using exactly the stored flags and full range.
    gpx.save()
    gpx = G2sc.G2Project(str(output))
    states.append(refine(gpx, "reopened_replay"))
    gpx.save()
    (output.with_suffix(".states.json")).write_text(json.dumps(states, indent=2, default=float))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", nargs="+", default=["PbWO4_scheelite", "WO3_monoclinic"])
    parser.add_argument("--output", type=Path, default=ROOT / "trial.gpx")
    parser.add_argument("--no-scheelite-size", action="store_true")
    args = parser.parse_args()
    run(args.model, args.output.resolve(), not args.no_scheelite_size)


if __name__ == "__main__":
    main()
