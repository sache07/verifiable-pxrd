#!/usr/bin/env python3
"""Replay the accepted project and export all required final artifacts."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "candidate_uiso_pol.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "PbWO4_scheelite": {
        "display_name": "PbWO4 (scheelite)",
        "formula": "PbWO4",
        "space_group": "I 41/a",
        "space_group_number": 88,
        "source_cod_id": "9009811",
        "cif": "phase_1_PbWO4_scheelite.cif",
    },
    "WO3_monoclinic_alt": {
        "display_name": "WO3 (ambient monoclinic)",
        "formula": "WO3",
        "space_group": "P 1 21/c 1",
        "space_group_number": 14,
        "source_cod_id": "2311041",
        "cif": "phase_2_WO3_monoclinic.cif",
    },
    "Pb3O4_tetragonal_alt": {
        "display_name": "Pb3O4 (minium)",
        "formula": "Pb3O4",
        "space_group": "P 42/m b c",
        "space_group_number": 135,
        "source_cod_id": "9012124",
        "cif": "phase_3_Pb3O4_minium.cif",
    },
    "PbO_massicot": {
        "display_name": "PbO (massicot)",
        "formula": "PbO",
        "space_group": "P b c m",
        "space_group_number": 57,
        "source_cod_id": "2310433",
        "cif": "phase_4_PbO_massicot.cif",
    },
}


def replay() -> G2sc.G2Project:
    gpx = G2sc.G2Project(str(BASE), newgpx=str(FINAL))
    frozen = gpx.data.get("Controls", {}).get("data", {}).get("parmFrozen")
    if isinstance(frozen, dict):
        frozen["FrozenList"] = []
    gpx.set_Controls("cycles", 12)
    gpx.save()

    # Reopen between passes, matching the required replay check.
    for _ in range(5):
        gpx.refine(makeBack=False)
        gpx.save()
        rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
        max_shift = abs(float(rvals.get("Max shft/sig", 1.0)))
        delta = abs(float(rvals.get("DelChi2", 1.0)))
        gpx = G2sc.G2Project(str(FINAL))
        if max_shift < 0.1 and delta < 1e-4:
            break
    return gpx


def export_fit(hist) -> None:
    arrays = [hist.getdata(name) for name in
              ("X", "Yobs", "Ycalc", "Residual", "Background")]
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg", "observed_counts", "calculated_counts",
            "difference_obs_minus_calc_counts", "background_counts",
        ])
        for values in zip(*arrays):
            writer.writerow([
                f"{float(values[0]):.8f}",
                f"{float(values[1]):.10g}",
                f"{float(values[2]):.10g}",
                f"{float(values[3]):.10g}",
                f"{float(values[4]):.10g}",
            ])


def main() -> None:
    gpx = replay()
    hist = gpx.histogram(0)
    residuals = hist.data["data"][0]
    covariance = gpx.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    masses = hist.ComputeMassFracs()
    total = sum(value[0] for value in masses.values())

    phases_json = []
    for phase in gpx.phases():
        info = PHASE_INFO[phase.name]
        cif_path = ROOT / info["cif"]
        phase.export_CIF(str(cif_path))
        fraction, esd = masses[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        phase_number = phase.id
        phases_json.append({
            "name": info["display_name"],
            "formula": info["formula"],
            "space_group": info["space_group"],
            "space_group_number": info["space_group_number"],
            "source_cod_id": info["source_cod_id"],
            "cif_path": info["cif"],
            "weight_fraction": fraction / total,
            "weight_fraction_esd_formal": esd / total,
            "weight_percent": 100.0 * fraction / total,
            "weight_percent_esd_formal": 100.0 * esd / total,
            "cell": cell,
            "cell_esd": cell_esd,
            "rf_percent": residuals.get(f"{phase_number}:0:Rf"),
            "rf_squared_percent": residuals.get(f"{phase_number}:0:Rf^2"),
        })

    export_fit(hist)
    fit_stats = {
        "rwp_percent": hist.get_wR(),
        "rp_percent": residuals.get("R"),
        "r_expected_percent": residuals.get("wRmin"),
        "goodness_of_fit_sqrt_reduced_chi_squared": rvals.get("GOF"),
        "reduced_chi_squared": float(rvals.get("GOF")) ** 2,
        "weighted_chi_squared": rvals.get("chisq"),
        "durbin_watson": residuals.get("Durbin-Watson"),
        "n_observations": rvals.get("Nobs"),
        "n_refined_parameters": rvals.get("Nvars"),
        "max_shift_over_esd_last_replay": rvals.get("Max shft/sig"),
    }
    result = {
        "phases": phases_json,
        "weight_fraction_basis": (
            "Normalized over the four modeled crystalline phases; amorphous or "
            "unidentified material is not quantified."
        ),
        "fit_statistics": fit_stats,
        "files": {
            "project": "final.gpx",
            "profile": "fit.csv",
            "report": "report.md",
        },
        "weighting": (
            "Poisson weights (1/I) assigned by GSAS-II because pointwise "
            "standard uncertainties were not supplied."
        ),
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    by_formula = {p["formula"]: p for p in phases_json}
    inst = hist.data["Instrument Parameters"][0]
    shift = hist.data["Sample Parameters"]["Shift"][0]
    wo3_u = gpx.phase("WO3_monoclinic_alt").atoms()[0].uiso
    pbo_u = gpx.phase("PbO_massicot").atoms()[0].uiso
    pbwo4_hap = gpx.phase("PbWO4_scheelite").data["Histograms"][hist.name]
    pb3o4_hap = gpx.phase("Pb3O4_tetragonal_alt").data["Histograms"][hist.name]
    pbo_hap = gpx.phase("PbO_massicot").data["Histograms"][hist.name]

    rows = []
    for formula in ("PbWO4", "WO3", "Pb3O4", "PbO"):
        p = by_formula[formula]
        rows.append(
            f"| {p['name']} | {p['space_group']} | "
            f"{p['weight_percent']:.3f} ± {p['weight_percent_esd_formal']:.3f} | "
            f"{p['source_cod_id']} | `{p['cif_path']}` |"
        )

    report = f"""# Quantitative phase analysis

## Result

Four crystalline phases are required. Weight fractions are normalized over those four phases only.

| Phase | Space group | wt% (formal 1σ) | Starting record | Refined CIF |
|---|---:|---:|---:|---|
{chr(10).join(rows)}

The final full-range replay gives Rwp = {fit_stats['rwp_percent']:.4f}%, Rp = {fit_stats['rp_percent']:.4f}%, Rexp = {fit_stats['r_expected_percent']:.4f}%, GOF = {fit_stats['goodness_of_fit_sqrt_reduced_chi_squared']:.4f}, and Durbin–Watson = {fit_stats['durbin_watson']:.3f}.

## Evidence and model

- Scheelite PbWO4 accounts for the broad families at about 27.8, 30.0, 33.1, 47.4, 55.6, and 69.0° 2θ. The 290 K synthetic scheelite record COD 9009811 was physically consistent; monoclinic raspite refined to only 0.011(54) wt% on the final common profile and is not detected.
- Ambient monoclinic WO3 is required by the sharp 23.52/24.01/24.83° triplet and many sharp mid/high-angle lines. COD 2311041 is the neutron structure in the alternative P21/c cell and fit better than the older exact record.
- Tetragonal Pb3O4 (minium) is supported by broad families including those near 31.2, 32.5, 52.5, and 63.7°. The selected record is the 293 K synthetic structure COD 9012124.
- Orthorhombic PbO (massicot) is supported by coherent families near 30.8, 33.0, 45.5, and higher angles. Tetragonal litharge collapsed to the scale lower bound and is not detected.

The metadata Cu Kα1/Kα2 wavelengths and 0.5 intensity ratio were fixed. The baseline uses a six-term smooth Chebyshev background, one specimen-displacement correction ({shift:.1f} µm in the GSAS-II convention), a shared interior polarization coefficient ({inst['Polariz.'][1]:.4f}), and positive U/W/X = {inst['U'][1]:.3f}/{inst['W'][1]:.3f}/{inst['X'][1]:.3f}; V/Y/Z, roughness, transparency, and texture remain neutral. SH/L stayed at its minimal fixed value because repeated low-angle asymmetry was absent.

Isolated low-, middle-, and high-angle families support size-dominated broadening for PbWO4 ({pbwo4_hap['Size'][1][0]:.4f} µm), size plus strain for Pb3O4 ({pb3o4_hap['Size'][1][0]:.4f} µm and {pb3o4_hap['Mustrain'][1][0]:.0f} ppm), and strain-dominated broadening for PbO ({pbo_hap['Mustrain'][1][0]:.0f} ppm). WO3 needed no phase-width term. Shared isotropic displacement terms were supported for WO3 ({wo3_u:.5f} Å²) and PbO ({pbo_u:.5f} Å²); PbWO4 and Pb3O4 displacement trials went to zero and were pruned. Five symmetry-distinct PbWO4 texture tests returned March–Dollase ratios 0.992–1.002 and were rejected.

The exported structures also pass a nearest-neighbour geometry screen: shortest W–O contacts are 1.71–1.77 Å and shortest Pb–O contacts are 2.13–2.61 Å, with no unphysical short contacts.

## Remaining uncertainty

The phase identities are well constrained by multiple coherent reflection families. The tabulated fraction uncertainties are covariance-only values and are smaller than the true accuracy: no pointwise uncertainties or calibrated instrument profile were supplied, so Poisson weights and a jointly refined common profile were used. Accepted/pruned intensity-model variants moved the major-phase fractions by roughly 1–2 wt% absolute; that is a more realistic systematic scale than the formal errors. The minor PbO amount is less secure than the three major fractions, though its orthorhombic identity is supported.

Atomic coordinates were retained from the cited records; cells, scales, common profile, selected broadening terms, polarization, and the two supported shared Uiso terms were refined. No amorphous fraction can be inferred from this normalization. Additional phases below roughly 0.15 wt% (about the 3σ raspite challenge level) cannot be excluded reliably.
"""
    (ROOT / "report.md").write_text(report)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
