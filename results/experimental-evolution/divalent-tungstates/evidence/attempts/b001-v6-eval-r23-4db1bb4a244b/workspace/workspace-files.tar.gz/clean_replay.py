#!/usr/bin/env python3
"""Remove importer ADP defaults and replay the physically screened model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.base.resolve()), newgpx=str(args.output.resolve()))
    hist = gpx.histogram(0)

    # The selected COD files contain no measured ADPs (some omit the CIF field
    # and are imported by GSAS-II with Uiso=0.01). Use the same neutral value,
    # Uiso=0, for all phases before deciding whether any ADP is supported.
    for phase in gpx.phases():
        for atom in phase.atoms():
            atom.uiso = 0.0
            atom.refinement_flags = atom.refinement_flags.replace("U", "")

    # No variable in the screened project should remain frozen from a prior
    # challenge. Keep broad but finite, nonnegative microstrain limits.
    frozen = gpx.data.get("Controls", {}).get("data", {}).get("parmFrozen")
    if isinstance(frozen, dict):
        frozen["FrozenList"] = []
    for phase in gpx.phases():
        gpx.set_Controls("parmMin", 0.0, f"{phase.id}:0:Mustrain;i")
        gpx.set_Controls("parmMax", 50000.0, f"{phase.id}:0:Mustrain;i")
    gpx.set_Controls("cycles", 12)
    gpx.save()

    history = []
    for cycle in range(3):
        gpx.refine(makeBack=False)
        gpx.save()
        history.append(gpx.histogram(0).get_wR())
        gpx = G2sc.G2Project(str(args.output.resolve()))

    hist = gpx.histogram(0)
    result = {
        "replay_rwp": history,
        "rwp": hist.get_wR(),
        "rp": hist.data["data"][0].get("R"),
        "durbin_watson": hist.data["data"][0].get("Durbin-Watson"),
        "mass_fractions": hist.ComputeMassFracs(),
        "uiso_A2": {
            phase.name: {atom.label: atom.uiso for atom in phase.atoms()}
            for phase in gpx.phases()
        },
    }
    args.output.with_suffix(".clean.json").write_text(
        json.dumps(result, indent=2, default=float)
    )
    print("CLEAN_RESULT", json.dumps(result, default=float, sort_keys=True))


if __name__ == "__main__":
    main()
