#!/usr/bin/env python3
"""Replay SrCO3 texture from opposite seeds, then delete each texture term."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
BASE = ROOT / ".tmp/leader_combo_aa_replay.gpx"
G2sc.SetPrintLevel("none")


def clear_frozen(project):
    frozen = project.data["Controls"]["data"].setdefault(
        "parmFrozen", {"FrozenList": []}
    )
    for key in list(frozen):
        frozen[key] = []


def reopen(project):
    hist = project.histogram(0)
    clear_frozen(project)
    hist.Background[0][1] = True
    hist.InstrumentParameters["Zero"][1:3] = [0.0, False]
    hist.InstrumentParameters["U"][1:3] = [0.0, False]
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["X"][2] = True
    hist.SampleParameters["Shift"][1] = True
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key][0:2] = [0.0, False]
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
    return hist


def summarize(project, label, replayed):
    hist = project.histogram(0)
    textures = {}
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        textures[phase.name] = {
            "axis": list(hap["Pref.Ori."][3]),
            "ratio": hap["Pref.Ori."][1],
            "refine": bool(hap["Pref.Ori."][2]),
        }
    frozen = project.get_Frozen()
    return {
        "label": label,
        "project": project.filename,
        "replayed": replayed,
        "frozen": frozen,
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "textures": textures,
        "profile": {k: hist.InstrumentParameters[k][1] for k in ("W", "X")},
        "shift_um": hist.SampleParameters["Shift"][0],
        "fractions": ({key: value[0] for key, value
                       in hist.ComputeMassFracs().items()} if not frozen else None),
    }


def refine(source, output, label, configure, cycles=25, replay_cycles=15):
    project = G2sc.G2Project(str(source), newgpx=str(output))
    hist = reopen(project)
    configure(project, hist)
    project.set_Controls("cycles", cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.save()
    project.do_refinements([{}])
    row = summarize(project, label, False)
    if not row["frozen"]:
        replay_path = output.with_name(output.stem + "_replay.gpx")
        replay = G2sc.G2Project(str(output), newgpx=str(replay_path))
        replay.set_Controls("cycles", replay_cycles)
        replay.do_refinements([{}])
        project = replay
        row = summarize(project, label, True)
    return project, row


rows = []
seed_projects = []
for tag, seed in (("lo", 0.75), ("hi", 1.25)):
    def add_p2(project, hist, seed=seed):
        phase = project.phase(2)
        hap = phase.getHAPvalues(hist)
        hap["Pref.Ori."][0:4] = ["MD", seed, True, [0, 0, 1]]
        project.set_Controls("parmMin", 0.2, f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 5.0, f"{phase.id}:0:MD")
    project, row = refine(
        BASE, ROOT / f".tmp/texture_p2_{tag}.gpx", f"p2_{tag}", add_p2
    )
    seed_projects.append(project)
    rows.append(row)
    print("TEXTURE_RESULT", json.dumps(row, sort_keys=True))

winner = Path(seed_projects[0].filename)
for index in range(3):
    def delete_one(project, hist, index=index):
        hap = project.phase(index).getHAPvalues(hist)
        hap["Pref.Ori."][1:3] = [1.0, False]
    project, row = refine(
        winner,
        ROOT / f".tmp/texture_delete_p{index}.gpx",
        f"delete_p{index}",
        delete_one,
        cycles=20,
        replay_cycles=12,
    )
    rows.append(row)
    print("TEXTURE_RESULT", json.dumps(row, sort_keys=True))

(ROOT / ".tmp/texture_deletions.json").write_text(
    json.dumps(rows, indent=2, sort_keys=True) + "\n"
)
