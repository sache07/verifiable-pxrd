#!/usr/bin/env python3
"""Repeat background and angular-intensity challenges after polarization."""

import importlib.util
from pathlib import Path


ROOT = Path.cwd()
spec = importlib.util.spec_from_file_location(
    "nuisance_helpers", ROOT / ".tmp/nuisance_challenges.py"
)
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
helpers.SOURCE = ROOT / ".tmp/nuisance_polarization_high_replay.gpx"

branches = {
    f"background_{count}": {
        "background": count, "preserve_polarization": True
    } for count in (6, 8, 10, 12, 14, 16)
}
branches.update({
    "rough_b_low": {
        "background": 8, "preserve_polarization": True,
        "rough_b": 0.005,
    },
    "rough_b_high": {
        "background": 8, "preserve_polarization": True,
        "rough_b": 0.2,
    },
    "rough_ab_low": {
        "background": 8, "preserve_polarization": True,
        "rough_ab": (0.2, 0.02),
    },
    "rough_ab_high": {
        "background": 8, "preserve_polarization": True,
        "rough_ab": (0.8, 0.4),
    },
    "shl_low": {
        "background": 8, "preserve_polarization": True,
        "shl": 0.0005,
    },
    "shl_high": {
        "background": 8, "preserve_polarization": True,
        "shl": 0.02,
    },
})

helpers.run_branches(
    branches, output_prefix="intensity",
    summary_name="intensity_loop.json",
)
