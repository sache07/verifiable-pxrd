#!/usr/bin/env python3
"""Collective width release and independent-seed replay checks."""

import json
import os
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = Path(os.environ.get(
    "COLLECTIVE_SOURCE", str(ROOT / ".tmp/angular_shift_replay.gpx")
))
PREFIX = os.environ.get("COLLECTIVE_PREFIX", "collective_width")
PRESERVE_TEXTURE = os.environ.get("COLLECTIVE_PRESERVE_TEXTURE", "0") == "1"
G2sc.SetPrintLevel("none")


def clear_frozen(project):
    frozen = project.data["Controls"]["data"].setdefault(
        "parmFrozen", {"FrozenList": []}
    )
    for key in list(frozen):
        frozen[key] = []


def configure(project, seed):
    hist = project.histogram(0)
    clear_frozen(project)
    hist.Background[0][1] = True
    hist.InstrumentParameters["Zero"][1:3] = [0.0, False]
    for key in ("U", "W", "X"):
        hist.InstrumentParameters[key][2] = True
    hist.InstrumentParameters["U"][1] = seed["u"]
    project.set_Controls("parmMin", 0.0, "0:0:U")
    project.set_Controls("parmMin", 0.0, "0:0:W")
    project.set_Controls("parmMin", 0.0, "0:0:X")
    hist.SampleParameters["Shift"][1] = True
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key][0:2] = [0.0, False]
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        if not PRESERVE_TEXTURE:
            hap["Pref.Ori."][0:3] = ["MD", 1.0, False]

    # Terms with family-level support or a marked trade against common width.
    terms = {
        (0, "strain"): seed["strain"],
        (1, "size"): seed["size"],
        (1, "strain"): seed["strain"],
        (2, "size"): seed["size"],
    }
    for (idx, kind), value in terms.items():
        phase = project.phase(idx)
        hap = phase.getHAPvalues(hist)
        if kind == "size":
            hap["Size"][1][0] = value
            hap["Size"][2][0] = True
            name = f"{phase.id}:0:Size;i"
            project.set_Controls("parmMin", 0.02, name)
            project.set_Controls("parmMax", 100.0, name)
        else:
            hap["Mustrain"][1][0] = value
            hap["Mustrain"][2][0] = True
            name = f"{phase.id}:0:Mustrain;i"
            project.set_Controls("parmMin", 0.0, name)
            project.set_Controls("parmMax", 10000.0, name)
    return hist


def summarize(project, label, replayed):
    hist = project.histogram(0)
    phases = []
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        phases.append({
            "name": phase.name,
            "size_um": hap["Size"][1][0],
            "size_refine": bool(hap["Size"][2][0]),
            "strain_micro": hap["Mustrain"][1][0],
            "strain_refine": bool(hap["Mustrain"][2][0]),
        })
    frozen = project.get_Frozen()
    return {
        "label": label,
        "project": project.filename,
        "replayed": replayed,
        "frozen": frozen,
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "profile": {key: hist.InstrumentParameters[key][1]
                    for key in ("U", "W", "X")},
        "shift_um": hist.SampleParameters["Shift"][0],
        "phases": phases,
        "fractions": ({key: value[0] for key, value
                       in hist.ComputeMassFracs().items()} if not frozen else None),
    }


seeds = [
    {"name": "low_a", "u": 0.2, "size": 0.10, "strain": 100.0},
    {"name": "low_b", "u": 1.0, "size": 0.35, "strain": 400.0},
    {"name": "low_c", "u": 3.0, "size": 1.00, "strain": 1000.0},
]
rows = []
for seed in seeds:
    label = seed["name"]
    output = ROOT / f".tmp/{PREFIX}_{label}.gpx"
    try:
        project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
        configure(project, seed)
        project.set_Controls("cycles", 30)
        project.data["Controls"]["data"]["min dM/M"] = 1e-7
        project.save()
        project.do_refinements([{}])
        row = summarize(project, label, False)
        if not row["frozen"]:
            replay_path = output.with_name(output.stem + "_replay.gpx")
            replay = G2sc.G2Project(str(output), newgpx=str(replay_path))
            replay.set_Controls("cycles", 20)
            replay.do_refinements([{}])
            row = summarize(replay, label, True)
    except Exception as exc:
        row = {"label": label, "error": repr(exc)}
    rows.append(row)
    print("COLLECTIVE_RESULT", json.dumps(row, sort_keys=True))
    (ROOT / f".tmp/{PREFIX}.json").write_text(
        json.dumps(rows, indent=2, sort_keys=True) + "\n"
    )
