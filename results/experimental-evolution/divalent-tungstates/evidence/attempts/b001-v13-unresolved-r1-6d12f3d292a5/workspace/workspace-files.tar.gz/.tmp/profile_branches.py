#!/usr/bin/env python3
"""Challenge low-dimensional nonnegative common profile models."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SOURCE = Path(".tmp/neutral_tet129_zero.bak0.gpx")
BRANCHES = {
    "x": {"X": 5.0},
    "u": {"U": 100.0},
    "ux": {"U": 100.0, "X": 5.0},
    "wx": {"W": 20.0, "X": 5.0},
    "uw": {"U": 100.0, "W": 20.0},
    "uwx": {"U": 50.0, "W": 20.0, "X": 5.0},
}


def clear_frozen(project):
    frozen = project.data["Controls"]["data"].setdefault(
        "parmFrozen", {"FrozenList": []}
    )
    for key in list(frozen):
        frozen[key] = []


rows = []
for label, active in BRANCHES.items():
    output = Path(f".tmp/profile_{label}.gpx")
    project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
    hist = project.histogram(0)
    clear_frozen(project)
    for name in ("U", "W", "X"):
        hist.InstrumentParameters[name][1] = active.get(name, 0.0)
        hist.InstrumentParameters[name][2] = name in active
        project.set_Controls("parmMin", 0.0, f":0:{name}")
        project.set_Controls("parmMax", 5000.0 if name != "X" else 500.0,
                             f":0:{name}")
    for name in ("V", "Y", "Z", "SH/L", "Polariz.", "I(L2)/I(L1)"):
        hist.InstrumentParameters[name][2] = False
    hist.InstrumentParameters["Zero"][2] = True
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.getHAPvalues(hist)["Scale"][1] = True
    project.set_Controls("cycles", 25)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.save()
    project.do_refinements([{}])
    frozen = project.get_Frozen()
    valid = not frozen
    if valid:
        # Reopen and replay all flags/values once to test stability.
        project.save()
        replay = G2sc.G2Project(str(output), newgpx=str(output.with_name(output.stem + "_replay.gpx")))
        replay.set_Controls("cycles", 15)
        replay.do_refinements([{}])
        project = replay
        hist = project.histogram(0)
        frozen = project.get_Frozen()
        valid = not frozen
        output = Path(project.filename)
    row = {
        "branch": label,
        "active": list(active),
        "valid": valid,
        "frozen": frozen,
        "project": str(output),
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "profile": {name: hist.InstrumentParameters[name][1]
                    for name in ("Zero", "U", "W", "X")},
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "scales": {phase.name: phase.getHAPvalues(hist)["Scale"][0]
                   for phase in project.phases()},
    }
    if valid:
        row["mass_fractions"] = {
            key: value[0] for key, value in hist.ComputeMassFracs().items()
        }
    rows.append(row)
    print("BRANCH", json.dumps(row, sort_keys=True))

print("SUMMARY")
print(json.dumps(rows, indent=2, sort_keys=True))
