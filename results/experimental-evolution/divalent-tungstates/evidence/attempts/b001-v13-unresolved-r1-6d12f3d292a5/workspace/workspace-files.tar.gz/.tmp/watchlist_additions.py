#!/usr/bin/env python3
"""Re-challenge plausible fourth phases after the final inventory rebuild."""

import json
import os
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = Path(os.environ.get(
    "WATCH_SOURCE", str(ROOT / ".tmp/texture_p2_lo_replay.gpx")
))
COD = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)
G2sc.SetPrintLevel("none")

JOBS = {
    # Same-formula coexistence challenge against the accepted monoclinic WO3.
    "wo3_p4nmm": COD / "1/52/15/1521533.cif",
    # Charge-balanced non-1:1 product enumerated from the Sr-W-O context.
    "sr3w2o9": COD / "2/31/19/2311977.cif",
}


def clear_frozen(project):
    frozen = project.data["Controls"]["data"].setdefault(
        "parmFrozen", {"FrozenList": []}
    )
    for key in list(frozen):
        frozen[key] = []


def inactive_physics(phase, hist):
    hap = phase.getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def configure_common(project):
    hist = project.histogram(0)
    clear_frozen(project)
    hist.Background[0][1] = True
    hist.InstrumentParameters["Zero"][1:3] = [0.0, False]
    hist.InstrumentParameters["U"][1:3] = [0.0, False]
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["X"][2] = True
    hist.SampleParameters["Shift"][1] = True
    hist.SampleParameters["Transparency"][0:2] = [0.0, False]
    hist.SampleParameters["SurfRoughA"][0:2] = [0.0, False]
    hist.SampleParameters["SurfRoughB"][0:2] = [0.0, False]
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.getHAPvalues(hist)["Scale"][1] = True
    return hist


def summary(project, label, seed, replayed):
    hist = project.histogram(0)
    added = project.phases()[-1]
    hap = added.getHAPvalues(hist)
    frozen = project.get_Frozen()
    try:
        fractions = {key: value[0]
                     for key, value in hist.ComputeMassFracs().items()}
    except Exception as exc:
        fractions = {"error": repr(exc)}
    return {
        "label": label,
        "seed": seed,
        "replayed": replayed,
        "project": project.filename,
        "frozen": frozen,
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "added_phase": added.name,
        "added_scale": hap["Scale"][0],
        "added_scale_refine": bool(hap["Scale"][1]),
        "added_cell": added.get_cell(),
        "fractions": fractions,
    }


rows = []
for label, cif in JOBS.items():
    for seed_tag, seed in (("low", 0.02), ("high", 0.5)):
        output = ROOT / f".tmp/watch_{label}_{seed_tag}.gpx"
        try:
            project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
            hist = configure_common(project)
            added = project.add_phase(
                str(cif), phasename=f"watch_{label}",
                histograms=[hist], fmthint="CIF"
            )
            inactive_physics(added, hist)
            added.set_refinements({"Cell": False})
            hap = added.getHAPvalues(hist)
            hap["Scale"][:] = [seed, True]
            project.set_Controls("parmMin", 1e-10, f"{added.id}:0:Scale")
            project.set_Controls("parmMax", 100.0, f"{added.id}:0:Scale")
            project.set_Controls("cycles", 30)
            project.data["Controls"]["data"]["min dM/M"] = 1e-7
            project.save()
            project.do_refinements([{}])
            row = summary(project, label, seed_tag, False)
            if not row["frozen"]:
                replay_path = output.with_name(output.stem + "_replay.gpx")
                replay = G2sc.G2Project(str(output), newgpx=str(replay_path))
                replay.set_Controls("cycles", 20)
                replay.do_refinements([{}])
                row = summary(replay, label, seed_tag, True)
        except Exception as exc:
            row = {"label": label, "seed": seed_tag, "error": repr(exc)}
        rows.append(row)
        print("WATCH_RESULT", json.dumps(row, sort_keys=True))
        (ROOT / ".tmp/watchlist_additions.json").write_text(
            json.dumps(rows, indent=2, sort_keys=True) + "\n"
        )
