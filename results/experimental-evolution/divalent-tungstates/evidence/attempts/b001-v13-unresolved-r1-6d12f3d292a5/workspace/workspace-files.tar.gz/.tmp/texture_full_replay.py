#!/usr/bin/env python3
"""Opposite-seed replay and term deletion for a complete texture basis."""

import json
import os
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = Path(os.environ.get(
    "TEXTURE_SOURCE", str(ROOT / ".tmp/intensity_background_16_replay.gpx")
))
PREFIX = os.environ.get("TEXTURE_PREFIX", "texture_full")
AXES = json.loads(os.environ.get(
    "TEXTURE_AXES", "[[1,-1,-1],[2,-1,-2],[0,0,1]]"
))
SEED_LOW = json.loads(os.environ.get(
    "TEXTURE_SEEDS_LOW", "[0.45,0.55,0.60]"
))
SEED_HIGH = json.loads(os.environ.get(
    "TEXTURE_SEEDS_HIGH", "[1.55,1.75,1.45]"
))
if len(SEED_LOW) != len(AXES) or len(SEED_HIGH) != len(AXES):
    raise ValueError("texture seed arrays must match TEXTURE_AXES")
G2sc.SetPrintLevel("none")


def clear_frozen(project):
    frozen = project.data["Controls"]["data"].setdefault(
        "parmFrozen", {"FrozenList": []}
    )
    for key in list(frozen):
        frozen[key] = []


def common(project):
    hist = project.histogram(0)
    clear_frozen(project)
    hist.Background[0][1] = True
    inst = hist.InstrumentParameters
    inst["Zero"][1:3] = [0.0, False]
    inst["U"][1:3] = [0.0, False]
    inst["W"][2] = True
    inst["X"][2] = True
    inst["Polariz."][2] = True
    inst["SH/L"][2] = False
    hist.SampleParameters["Shift"][1] = True
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key][0:2] = [0.0, False]
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    for name in (":0:W", ":0:X", ":0:Polariz."):
        project.set_Controls("parmMin", 0.0, name)
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    return hist


def summarize(project, label, replayed):
    hist = project.histogram(0)
    frozen = project.get_Frozen()
    covariance = project.data.get("Covariance", {}).get("data", {})
    return {
        "label": label,
        "replayed": replayed,
        "project": project.filename,
        "frozen": frozen,
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "gof": covariance.get("Rvals", {}).get("GOF"),
        "textures": {
            phase.name: {
                "axis": list(phase.getHAPvalues(hist)["Pref.Ori."][3]),
                "ratio": phase.getHAPvalues(hist)["Pref.Ori."][1],
                "refine": bool(phase.getHAPvalues(hist)["Pref.Ori."][2]),
            } for phase in project.phases()
        },
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "profile": {key: hist.InstrumentParameters[key][1]
                    for key in ("U", "W", "X")},
        "shift_um": hist.SampleParameters["Shift"][0],
        "fractions": ({key: value[0] for key, value
                       in hist.ComputeMassFracs().items()} if not frozen else None),
    }


def refine(source, output, label, configure, cycles=40, replay_cycles=25):
    project = G2sc.G2Project(str(source), newgpx=str(output))
    hist = common(project)
    configure(project, hist)
    project.set_Controls("cycles", cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.save()
    project.do_refinements([{}])
    row = summarize(project, label, False)
    if not row["frozen"]:
        replay_path = output.with_name(output.stem + "_replay.gpx")
        replay = G2sc.G2Project(str(output), newgpx=str(replay_path))
        replay.set_Controls("cycles", replay_cycles)
        replay.data["Controls"]["data"]["min dM/M"] = 1e-5
        replay.do_refinements([{}])
        project = replay
        row = summarize(project, label, True)
    return project, row


rows = []
seed_projects = []
for tag, seeds in (("low", SEED_LOW), ("high", SEED_HIGH)):
    def set_all(project, hist, seeds=seeds):
        for index, (axis, seed) in enumerate(zip(AXES, seeds)):
            phase = project.phase(index)
            hap = phase.getHAPvalues(hist)
            hap["Pref.Ori."][0:4] = ["MD", seed, True, list(axis)]
            project.set_Controls("parmMin", 0.2, f"{phase.id}:0:MD")
            project.set_Controls("parmMax", 5.0, f"{phase.id}:0:MD")
    project, row = refine(
        SOURCE, ROOT / f".tmp/{PREFIX}_{tag}.gpx", tag, set_all
    )
    seed_projects.append(project)
    rows.append(row)
    print("TEXTURE_FULL", json.dumps(row, sort_keys=True))

winner = Path(seed_projects[0].filename)
if not rows[0]["frozen"]:
    for index in range(len(AXES)):
        def delete_one(project, hist, index=index):
            hap = project.phase(index).getHAPvalues(hist)
            hap["Pref.Ori."][1:3] = [1.0, False]
        project, row = refine(
            winner, ROOT / f".tmp/{PREFIX}_delete_p{index}.gpx",
            f"delete_p{index}", delete_one, cycles=30, replay_cycles=20,
        )
        rows.append(row)
        print("TEXTURE_FULL", json.dumps(row, sort_keys=True))

(ROOT / f".tmp/{PREFIX}.json").write_text(
    json.dumps(rows, indent=2, sort_keys=True) + "\n"
)
