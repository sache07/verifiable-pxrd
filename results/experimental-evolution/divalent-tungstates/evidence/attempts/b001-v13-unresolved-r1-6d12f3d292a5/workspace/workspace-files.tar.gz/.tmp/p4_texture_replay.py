#!/usr/bin/env python3
"""Stable opposite-seed and deletion replay for the weak P4/nmm texture."""

import json
import os
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = Path(os.environ.get(
    "SINGLE_TEXTURE_SOURCE", str(ROOT / ".tmp/watch_p4_cell_replay.gpx")
))
PREFIX = os.environ.get("SINGLE_TEXTURE_PREFIX", "p4_texture_replay")
P4_INDEX = int(os.environ.get("SINGLE_TEXTURE_PHASE", "3"))
P4_AXIS = json.loads(os.environ.get("SINGLE_TEXTURE_AXIS", "[0,0,1]"))
SEEDS = json.loads(os.environ.get("SINGLE_TEXTURE_SEEDS", "[0.35,4.50]"))
G2sc.SetPrintLevel("none")


def clear_frozen(project):
    frozen = project.data["Controls"]["data"].setdefault(
        "parmFrozen", {"FrozenList": []}
    )
    for key in list(frozen):
        frozen[key] = []


def configure_common(project):
    hist = project.histogram(0)
    clear_frozen(project)
    hist.Background[0][1] = True
    inst = hist.InstrumentParameters
    inst["Zero"][1:3] = [0.0, False]
    inst["U"][1:3] = [0.0, False]
    inst["W"][2] = True
    inst["X"][2] = True
    inst["Polariz."][2] = True
    inst["SH/L"][2] = False
    hist.SampleParameters["Shift"][1] = True
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key][0:2] = [0.0, False]
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Scale")
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        if hap["Pref.Ori."][2]:
            project.set_Controls("parmMin", 0.2, f"{phase.id}:0:MD")
            project.set_Controls("parmMax", 5.0, f"{phase.id}:0:MD")
    for name in (":0:W", ":0:X", ":0:Polariz."):
        project.set_Controls("parmMin", 0.0, name)
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    return hist


def summarize(project, label):
    hist = project.histogram(0)
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    return {
        "label": label,
        "project": project.filename,
        "frozen": project.get_Frozen(),
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "gof": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "aborted": rvals.get("Aborted"),
        "profile": {key: hist.InstrumentParameters[key][1]
                    for key in ("U", "W", "X")},
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "shift_um": hist.SampleParameters["Shift"][0],
        "fractions": ({key: value[0] for key, value
                       in hist.ComputeMassFracs().items()}
                      if not project.get_Frozen() else None),
        "scales": {
            phase.name: phase.getHAPvalues(hist)["Scale"][0]
            for phase in project.phases()
        },
        "textures": {
            phase.name: {
                "axis": list(phase.getHAPvalues(hist)["Pref.Ori."][3]),
                "ratio": phase.getHAPvalues(hist)["Pref.Ori."][1],
                "refine": bool(phase.getHAPvalues(hist)["Pref.Ori."][2]),
            } for phase in project.phases()
        },
    }


def opposite_seed(tag, seed):
    output = ROOT / f".tmp/{PREFIX}_{tag}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
    hist = configure_common(project)
    p4 = project.phase(P4_INDEX)
    hap = p4.getHAPvalues(hist)
    hap["Pref.Ori."][0:4] = ["MD", seed, True, P4_AXIS]
    project.set_Controls("parmMin", 0.2, f"{p4.id}:0:MD")
    project.set_Controls("parmMax", 5.0, f"{p4.id}:0:MD")

    # First settle the new intensity term without allowing a weak phase cell
    # to run into a non-positive metric, then reopen every cell.
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
    project.set_Controls("cycles", 25)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.save()
    project.do_refinements([{}])
    if project.get_Frozen():
        return project, summarize(project, tag)

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.set_Controls("cycles", 40)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.save()
    project.do_refinements([{}])
    if project.get_Frozen():
        return project, summarize(project, tag)

    replay_path = output.with_name(output.stem + "_replay.gpx")
    replay = G2sc.G2Project(str(output), newgpx=str(replay_path))
    replay.set_Controls("cycles", 25)
    replay.data["Controls"]["data"]["min dM/M"] = 1e-5
    replay.do_refinements([{}])
    return replay, summarize(replay, tag)


def delete_term(source, index):
    label = f"delete_p{index}"
    output = ROOT / f".tmp/{PREFIX}_{label}.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(output))
    hist = configure_common(project)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hap = project.phase(index).getHAPvalues(hist)
    hap["Pref.Ori."][1:3] = [1.0, False]
    project.set_Controls("cycles", 40)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.save()
    project.do_refinements([{}])
    if not project.get_Frozen():
        replay_path = output.with_name(output.stem + "_replay.gpx")
        replay = G2sc.G2Project(str(output), newgpx=str(replay_path))
        replay.set_Controls("cycles", 25)
        replay.data["Controls"]["data"]["min dM/M"] = 1e-5
        replay.do_refinements([{}])
        project = replay
    return project, summarize(project, label)


rows = []
projects = []
for tag, seed in zip(("low", "high"), SEEDS):
    project, row = opposite_seed(tag, seed)
    projects.append(project)
    rows.append(row)
    print("P4_TEXTURE", json.dumps(row, sort_keys=True), flush=True)

if rows and all(not row["frozen"] for row in rows):
    winner = Path(projects[0].filename)
    for index in range(len(projects[0].phases())):
        _, row = delete_term(winner, index)
        rows.append(row)
        print("P4_TEXTURE", json.dumps(row, sort_keys=True), flush=True)

(ROOT / f".tmp/{PREFIX}.json").write_text(
    json.dumps(rows, indent=2, sort_keys=True) + "\n"
)
