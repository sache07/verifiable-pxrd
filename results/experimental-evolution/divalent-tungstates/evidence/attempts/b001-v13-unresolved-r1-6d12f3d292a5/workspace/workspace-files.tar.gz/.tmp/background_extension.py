#!/usr/bin/env python3
"""Locate the smooth-background elbow beyond 18 coefficients."""

import importlib.util
from pathlib import Path


ROOT = Path.cwd()
spec = importlib.util.spec_from_file_location(
    "nuisance_helpers", ROOT / ".tmp/nuisance_challenges.py"
)
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
helpers.SOURCE = ROOT / ".tmp/texture_pol16_p0new_low_replay.gpx"

branches = {
    f"background_{count}": {
        "background": count, "preserve_polarization": True
    } for count in (18, 20, 22, 24)
}
helpers.run_branches(
    branches, output_prefix="background_ext",
    summary_name="background_extension.json",
)
