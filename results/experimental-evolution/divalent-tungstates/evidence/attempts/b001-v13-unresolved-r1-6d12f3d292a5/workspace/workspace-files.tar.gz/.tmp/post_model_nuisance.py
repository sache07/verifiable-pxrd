#!/usr/bin/env python3
"""Final nuisance loop after accepted texture/width topology."""

import importlib.util
import os
from pathlib import Path


ROOT = Path.cwd()
spec = importlib.util.spec_from_file_location(
    "nuisance_helpers", ROOT / ".tmp/nuisance_challenges.py"
)
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
helpers.SOURCE = Path(os.environ.get(
    "POST_SOURCE", str(ROOT / ".tmp/texture_pol16_p0new_low_replay.gpx")
))
prefix = os.environ.get("POST_PREFIX", "post_model")

branches = {
    f"background_{count}": {
        "background": count, "preserve_polarization": True
    } for count in (12, 14, 16, 18)
}
branches.update({
    "polarization_low": {"background": 16, "polarization": 0.5},
    "polarization_high": {"background": 16, "polarization": 0.9},
    "rough_b_low": {
        "background": 16, "preserve_polarization": True,
        "rough_b": 0.005,
    },
    "rough_b_high": {
        "background": 16, "preserve_polarization": True,
        "rough_b": 0.2,
    },
    "shl_low": {
        "background": 16, "preserve_polarization": True,
        "shl": 0.0005,
    },
    "shl_high": {
        "background": 16, "preserve_polarization": True,
        "shl": 0.02,
    },
})

helpers.run_branches(
    branches, output_prefix=prefix,
    summary_name=f"{prefix}.json",
)
