#!/usr/bin/env python3
"""Fit serious structure-source alternatives against one common nuisance basis."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
COD = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)
COMMON = G2sc.G2Project(str(ROOT / ".tmp/common_wx_replay.gpx"))
COMMON_HIST = COMMON.histogram(0)
COMMON_BACKGROUND = list(COMMON_HIST.Background[0][3:])
COMMON_PROFILE = {
    key: COMMON_HIST.InstrumentParameters[key][1]
    for key in ("Zero", "W", "X")
}
G2sc.SetPrintLevel("warn")

SCHEELITE = ROOT / "candidates/SrWO4_scheelite_start.cif"
MONO_TUNGSTATE = ROOT / "candidates/SrWO4_monoclinic_I2a_start.cif"
SR3W2O9 = COD / "2/31/19/2311977.cif"
SRCO3_PNMA = COD / "9/00/81/9008198.cif"
SRCO3_R3M = COD / "1/53/91/1539128.cif"
WO3 = {
    "P4nmm_1521533": COD / "1/52/15/1521533.cif",
    "P4ncc_1521532": COD / "1/52/15/1521532.cif",
    "P21c_1563541": COD / "1/56/35/1563541.cif",
    "P21c_2311041": COD / "2/31/10/2311041.cif",
    "P-1_2106293": COD / "2/10/62/2106293.cif",
    "Pnma_2107312": COD / "2/10/73/2107312.cif",
    "P6mmm_1004057": COD / "1/00/40/1004057.cif",
}


def inactive_physics(phase, hist):
    hap = phase.getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def run(label, phase_defs, target_fracs):
    output = ROOT / f".tmp/source_{label}.gpx"
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / ".tmp/lab_cuka.instprm"),
        fmthint="comma",
    )
    hist.SampleParameters["Scale"][:] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key][:] = [0.0, False]
    hist.set_refinements({"Background": {
        "type": "chebyschev-1", "refine": True, "no. coeffs": 8,
        "coeffs": COMMON_BACKGROUND,
    }})
    phases = []
    source_cells = {}
    for name, path in phase_defs:
        phase = project.add_phase(
            str(path), phasename=name, histograms=[hist], fmthint="CIF"
        )
        inactive_physics(phase, hist)
        source_cells[name] = phase.get_cell()
        phases.append(phase)
    # Seed scales from target mass fractions because cells/Z differ among records.
    normalizer = 16000.0
    for phase, fraction in zip(phases, target_fracs):
        hap = phase.getHAPvalues(hist)
        hap["Scale"][:] = [fraction * normalizer / phase.data["General"]["Mass"], True]
        phase.set_refinements({"Cell": True})
    inst = hist.InstrumentParameters
    for name in ("U", "V", "Y", "Z", "SH/L", "Polariz.", "I(L2)/I(L1)"):
        inst[name][2] = False
    inst["U"][1] = 0.0
    for name in ("Zero", "W", "X"):
        inst[name][1] = COMMON_PROFILE[name]
        inst[name][2] = True
    project.set_Controls("parmMin", 0.0, ":0:W")
    project.set_Controls("parmMin", 0.0, ":0:X")
    project.set_Controls("parmMax", 5000.0, ":0:W")
    project.set_Controls("parmMax", 500.0, ":0:X")
    project.set_Controls("cycles", 35)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.save()
    project.do_refinements([{}])
    frozen = project.get_Frozen()
    # One replay is required before a source result is compared.
    replayed = False
    if not frozen:
        replay = G2sc.G2Project(
            str(output), newgpx=str(output.with_name(output.stem + "_replay.gpx"))
        )
        replay.set_Controls("cycles", 20)
        replay.do_refinements([{}])
        project = replay
        hist = project.histogram(0)
        frozen = project.get_Frozen()
        replayed = True
    cells = {phase.name: phase.get_cell() for phase in project.phases()}
    cell_volume_ratios = {
        name: cells[name]["volume"] / source_cells[name]["volume"]
        for name in cells
    }
    result = {
        "label": label,
        "project": project.filename,
        "replayed": replayed,
        "frozen": frozen,
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "profile": {name: hist.InstrumentParameters[name][1]
                    for name in ("Zero", "U", "W", "X")},
        "cells": cells,
        "cell_volume_ratios": cell_volume_ratios,
        "scales": {phase.name: phase.getHAPvalues(hist)["Scale"][0]
                   for phase in project.phases()},
    }
    if not frozen:
        result["fractions"] = {
            key: value[0] for key, value in hist.ComputeMassFracs().items()
        }
    return result


jobs = []
for name, path in WO3.items():
    if name == "P4nmm_1521533":
        continue
    jobs.append((
        f"wo3_{name}",
        [("SrWO4_scheelite", SCHEELITE), (f"WO3_{name}", path),
         ("SrCO3_Pnma", SRCO3_PNMA)],
        [0.717, 0.108, 0.175],
    ))
jobs.extend([
    ("srco3_R3m", [("SrWO4_scheelite", SCHEELITE),
                    ("WO3_P4nmm", WO3["P4nmm_1521533"]),
                    ("SrCO3_R3m", SRCO3_R3M)], [0.717, 0.108, 0.175]),
    ("srwo4_C2c", [("SrWO4_C2c", MONO_TUNGSTATE),
                    ("WO3_P4nmm", WO3["P4nmm_1521533"]),
                    ("SrCO3_Pnma", SRCO3_PNMA)], [0.717, 0.108, 0.175]),
    ("sr3w2o9_replace", [("Sr3W2O9_C2c", SR3W2O9),
                          ("WO3_P4nmm", WO3["P4nmm_1521533"]),
                          ("SrCO3_Pnma", SRCO3_PNMA)], [0.717, 0.108, 0.175]),
])

if __name__ == "__main__":
    results = []
    for label, defs, fractions in jobs:
        try:
            result = run(label, defs, fractions)
        except Exception as exc:
            result = {"label": label, "error": repr(exc)}
        results.append(result)
        print("SOURCE_RESULT", json.dumps(result, sort_keys=True))
        (ROOT / ".tmp/source_branches.json").write_text(
            json.dumps(results, indent=2, sort_keys=True) + "\n"
        )
