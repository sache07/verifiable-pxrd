#!/usr/bin/env python3
"""Build a neutral three-phase GSAS-II checkpoint and refine in safe stages."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
COD = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)


def report(gpx, label):
    hist = gpx.histogram(0)
    print(f"\n### {label}")
    print("residuals", hist.residuals)
    print("instrument", {k: v[1:] for k, v in hist.InstrumentParameters.items()
                         if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")})
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        print(phase.name, "scale", hap["Scale"], "cell", phase.get_cell(),
              "size", hap["Size"], "strain", hap["Mustrain"],
              "PO", hap["Pref.Ori."][:4])


def inactive_physics(phase, hist):
    hap = phase.getHAPvalues(hist)
    hap["Scale"][:] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


out = ROOT / ".tmp/neutral_tet129.gpx"
gpx = G2sc.G2Project(newgpx=str(out))
hist = gpx.add_powder_histogram(
    str(ROOT / "inputs/pattern.csv"),
    str(ROOT / ".tmp/lab_cuka.instprm"),
    fmthint="comma",
)
hist.SampleParameters["Scale"][:] = [1.0, False]
hist.SampleParameters["Shift"][:] = [0.0, False]
hist.SampleParameters["Transparency"][:] = [0.0, False]
hist.SampleParameters["SurfRoughA"][:] = [0.0, False]
hist.SampleParameters["SurfRoughB"][:] = [0.0, False]
hist.set_refinements({"Background": {
    "type": "chebyschev-1", "refine": True, "no. coeffs": 8,
    "coeffs": [1050.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
}})

phase_files = [
    ("SrWO4_scheelite", ROOT / "candidates/SrWO4_scheelite_start.cif"),
    ("WO3_P4nmm", COD / "1/52/15/1521533.cif"),
    ("SrCO3_Pnma", COD / "9/00/81/9008198.cif"),
]
for name, path in phase_files:
    phase = gpx.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
    inactive_physics(phase, hist)

gpx.set_Controls("cycles", 12)
gpx.data["Controls"]["data"]["min dM/M"] = 1e-5
gpx.save()

# Keep profile branches physical.
for variable, value in [
    (":0:U", 0.0), (":0:W", 0.0), (":0:X", 0.0),
    (":0:U", 100.0), (":0:W", 100.0), (":0:X", 20.0),
]:
    pass
gpx.set_Controls("parmMin", 0.0, ":0:U")
gpx.set_Controls("parmMin", 0.0, ":0:W")
gpx.set_Controls("parmMin", 0.0, ":0:X")
gpx.set_Controls("parmMax", 100.0, ":0:U")
gpx.set_Controls("parmMax", 100.0, ":0:W")
gpx.set_Controls("parmMax", 20.0, ":0:X")
for phase in gpx.phases():
    gpx.set_Controls("parmMin", 1e-10, f"{phase.id}:0:Scale")

gpx.do_refinements([{}])
report(gpx, "background + scales")
gpx.save(ROOT / ".tmp/neutral_tet129_scales.gpx")

for phase in gpx.phases():
    phase.set_refinements({"Cell": True})
gpx.do_refinements([{}])
report(gpx, "+ cells")
gpx.save(ROOT / ".tmp/neutral_tet129_cells.gpx")

hist.set_refinements({"Instrument Parameters": ["Zero"]})
gpx.do_refinements([{}])
report(gpx, "+ zero")
gpx.save(ROOT / ".tmp/neutral_tet129_zero.gpx")

hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
gpx.do_refinements([{}])
report(gpx, "+ U/W/X")
gpx.save(ROOT / ".tmp/neutral_tet129_profile.gpx")
print("mass fractions", hist.ComputeMassFracs())
