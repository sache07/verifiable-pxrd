#!/usr/bin/env python3
"""Construct chemistry-preserving analogue CIFs used for source challenges."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)
OUT = Path("candidates")
OUT.mkdir(exist_ok=True)


def write_substituted(source: Path, substitutions: dict[str, str], lattice: Lattice,
                      output: Path) -> None:
    structure = Structure.from_file(source)
    structure.replace_species(substitutions)
    structure = Structure(
        lattice,
        structure.species,
        structure.frac_coords,
        site_properties=structure.site_properties,
    )
    CifWriter(structure, symprec=0.02, refine_struct=False).write_file(output)


# Ordered I41/a SrMoO4 is the closest clean parent. The starting lattice is
# estimated only from unambiguous observed 200 and 004 lines; GSAS-II refines it.
write_substituted(
    ROOT / "2/30/04/2300460.cif",
    {"Mo": "W"},
    Lattice.tetragonal(5.4820, 12.1260),
    OUT / "SrWO4_scheelite_start.cif",
)

# Structurally distinct C2/c CaWO4 parent. Expansion follows the approximate
# CaWO4 -> SrWO4 length change in the scheelite analogues and is only a seed.
mono = Structure.from_file(ROOT / "1/54/60/1546035.cif")
a, b, c = mono.lattice.abc
write_substituted(
    ROOT / "1/54/60/1546035.cif",
    {"Ca": "Sr"},
    Lattice.monoclinic(1.04 * a, 1.05 * b, 1.04 * c, mono.lattice.beta),
    OUT / "SrWO4_monoclinic_start.cif",
)
