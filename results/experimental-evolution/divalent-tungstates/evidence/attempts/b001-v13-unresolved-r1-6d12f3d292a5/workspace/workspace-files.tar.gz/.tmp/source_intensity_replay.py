#!/usr/bin/env python3
"""Cross-check serious source ranking with accepted polarization/background."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
REFERENCE = G2sc.G2Project(str(ROOT / ".tmp/intensity_background_16_replay.gpx"))
REFERENCE_BACKGROUND = list(REFERENCE.histogram(0).Background[0][3:])
G2sc.SetPrintLevel("none")

JOBS = {
    "monoclinic_neutral": ROOT / ".tmp/angular_shift_replay.gpx",
    "monoclinic_elaborated": ROOT / ".tmp/intensity_background_16_replay.gpx",
    "tetragonal_neutral": ROOT / ".tmp/tetragonal_shift_replay.gpx",
    "tetragonal_elaborated": ROOT / ".tmp/tetragonal_elaborated_replay.gpx",
}


def clear_frozen(project):
    frozen = project.data["Controls"]["data"].setdefault(
        "parmFrozen", {"FrozenList": []}
    )
    for key in list(frozen):
        frozen[key] = []


def summarize(project, label, replayed):
    hist = project.histogram(0)
    frozen = project.get_Frozen()
    return {
        "label": label,
        "replayed": replayed,
        "project": project.filename,
        "frozen": frozen,
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "profile": {key: hist.InstrumentParameters[key][1]
                    for key in ("U", "W", "X")},
        "shift_um": hist.SampleParameters["Shift"][0],
        "textures": {
            phase.name: {
                "axis": list(phase.getHAPvalues(hist)["Pref.Ori."][3]),
                "ratio": phase.getHAPvalues(hist)["Pref.Ori."][1],
                "refine": bool(phase.getHAPvalues(hist)["Pref.Ori."][2]),
            } for phase in project.phases()
        },
        "fractions": ({key: value[0] for key, value
                       in hist.ComputeMassFracs().items()} if not frozen else None),
    }


rows = []
for label, source in JOBS.items():
    output = ROOT / f".tmp/source_intensity_{label}.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(output))
    hist = project.histogram(0)
    clear_frozen(project)
    hist.Background[0][:] = [
        "chebyschev-1", True, len(REFERENCE_BACKGROUND),
        *REFERENCE_BACKGROUND,
    ]
    inst = hist.InstrumentParameters
    inst["Zero"][1:3] = [0.0, False]
    inst["U"][1:3] = [0.0, False]
    inst["W"][2] = True
    inst["X"][2] = True
    inst["Polariz."][1:3] = [0.75, True]
    for key in ("V", "Y", "Z"):
        inst[key][2] = False
    hist.SampleParameters["Shift"][1] = True
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key][0:2] = [0.0, False]
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    project.set_Controls("parmMin", 0.0, ":0:W")
    project.set_Controls("parmMin", 0.0, ":0:X")
    project.set_Controls("parmMin", 0.0, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    project.set_Controls("cycles", 40)
    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.save()
    project.do_refinements([{}])
    row = summarize(project, label, False)
    if not row["frozen"]:
        replay_path = output.with_name(output.stem + "_replay.gpx")
        replay = G2sc.G2Project(str(output), newgpx=str(replay_path))
        replay.set_Controls("cycles", 20)
        replay.do_refinements([{}])
        row = summarize(replay, label, True)
    rows.append(row)
    print("SOURCE_INTENSITY", json.dumps(row, sort_keys=True))
    (ROOT / ".tmp/source_intensity_replay.json").write_text(
        json.dumps(rows, indent=2, sort_keys=True) + "\n"
    )
