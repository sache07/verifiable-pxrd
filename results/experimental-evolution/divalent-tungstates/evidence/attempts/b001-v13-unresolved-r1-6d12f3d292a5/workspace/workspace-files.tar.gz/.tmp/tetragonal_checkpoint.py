#!/usr/bin/env python3
"""Build a replay-stable P4/nmm WO3 checkpoint with sample shift."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = ROOT / ".tmp/common_wx_replay.gpx"
OUTPUT = ROOT / ".tmp/tetragonal_shift.gpx"
G2sc.SetPrintLevel("none")

project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
hist = project.histogram(0)
frozen = project.data["Controls"]["data"].setdefault(
    "parmFrozen", {"FrozenList": []}
)
for key in list(frozen):
    frozen[key] = []
hist.Background[0][1] = True
hist.InstrumentParameters["Zero"][1:3] = [0.0, False]
hist.InstrumentParameters["U"][1:3] = [0.0, False]
hist.InstrumentParameters["W"][2] = True
hist.InstrumentParameters["X"][2] = True
hist.SampleParameters["Shift"][:] = [1060.0, True]
for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
    hist.SampleParameters[key][0:2] = [0.0, False]
for phase in project.phases():
    phase.set_refinements({"Cell": True})
    hap = phase.getHAPvalues(hist)
    hap["Scale"][1] = True
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
project.set_Controls("parmMin", 0.0, ":0:W")
project.set_Controls("parmMin", 0.0, ":0:X")
project.set_Controls("cycles", 30)
project.data["Controls"]["data"]["min dM/M"] = 1e-7
project.save()
project.do_refinements([{}])

replay_path = ROOT / ".tmp/tetragonal_shift_replay.gpx"
replay = G2sc.G2Project(str(OUTPUT), newgpx=str(replay_path))
replay.set_Controls("cycles", 20)
replay.do_refinements([{}])
hist = replay.histogram(0)
row = {
    "project": replay.filename,
    "frozen": replay.get_Frozen(),
    "wR": hist.residuals.get("wR"),
    "R": hist.residuals.get("R"),
    "profile": {key: hist.InstrumentParameters[key][1]
                for key in ("U", "W", "X")},
    "shift_um": hist.SampleParameters["Shift"][0],
    "cells": {phase.name: phase.get_cell() for phase in replay.phases()},
    "fractions": ({key: value[0] for key, value
                   in hist.ComputeMassFracs().items()} if not replay.get_Frozen()
                  else None),
}
(ROOT / ".tmp/tetragonal_checkpoint.json").write_text(
    json.dumps(row, indent=2, sort_keys=True) + "\n"
)
print("TETRAGONAL_CHECKPOINT", json.dumps(row, sort_keys=True))
