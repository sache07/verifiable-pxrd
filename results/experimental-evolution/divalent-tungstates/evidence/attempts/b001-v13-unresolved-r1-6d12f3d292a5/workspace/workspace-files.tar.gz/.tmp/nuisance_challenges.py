#!/usr/bin/env python3
"""Replay-stable background, polarization, roughness and asymmetry challenges."""

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = ROOT / ".tmp/texture_p2_lo_replay.gpx"
G2sc.SetPrintLevel("none")


def clear_frozen(project):
    frozen = project.data["Controls"]["data"].setdefault(
        "parmFrozen", {"FrozenList": []}
    )
    for key in list(frozen):
        frozen[key] = []


def common(project):
    """Restore the accepted common basis and literal inactive physics."""
    hist = project.histogram(0)
    clear_frozen(project)
    hist.Background[0][1] = True
    inst = hist.InstrumentParameters
    inst["Zero"][1:3] = [0.0, False]
    inst["U"][1:3] = [0.0, False]
    inst["W"][2] = True
    inst["X"][2] = True
    for key in ("V", "Y", "Z", "Polariz."):
        inst[key][2] = False
    hist.SampleParameters["Shift"][1] = True
    hist.SampleParameters["Transparency"][0:2] = [0.0, False]
    hist.SampleParameters["SurfRoughA"][0:2] = [0.0, False]
    hist.SampleParameters["SurfRoughB"][0:2] = [0.0, False]
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    for name in (":0:W", ":0:X"):
        project.set_Controls("parmMin", 0.0, name)
    return hist


def set_background(hist, count):
    old = list(hist.Background[0][3:])
    coeffs = old[:count] + [0.0] * max(0, count - len(old))
    hist.Background[0][:] = ["chebyschev-1", True, count] + coeffs


def configure(project, branch):
    hist = common(project)
    inst = hist.InstrumentParameters
    set_background(hist, branch.get("background", 8))
    if "polarization" in branch:
        inst["Polariz."][1:3] = [branch["polarization"], True]
        project.set_Controls("parmMin", 0.0, ":0:Polariz.")
        project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    elif branch.get("preserve_polarization"):
        inst["Polariz."][2] = True
        project.set_Controls("parmMin", 0.0, ":0:Polariz.")
        project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    else:
        inst["Polariz."][1:3] = [0.5, False]
    if "rough_b" in branch:
        hist.SampleParameters["SurfRoughB"][0:2] = [branch["rough_b"], True]
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
        project.set_Controls("parmMax", 5.0, ":0:SurfRoughB")
    if "rough_ab" in branch:
        a, b = branch["rough_ab"]
        hist.SampleParameters["SurfRoughA"][0:2] = [a, True]
        hist.SampleParameters["SurfRoughB"][0:2] = [b, True]
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughA")
        project.set_Controls("parmMax", 1.0, ":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
        project.set_Controls("parmMax", 5.0, ":0:SurfRoughB")
    if "shl" in branch:
        inst["SH/L"][1:3] = [branch["shl"], True]
        project.set_Controls("parmMin", 0.0, ":0:SH/L")
        project.set_Controls("parmMax", 0.1, ":0:SH/L")
    else:
        inst["SH/L"][1:3] = [0.002, False]
    return hist


def angular_metrics(hist):
    x = np.asarray(hist.getdata("x"), dtype=float)
    obs = np.asarray(hist.getdata("yobs"), dtype=float)
    calc = np.asarray(hist.getdata("ycalc"), dtype=float)
    weight = np.asarray(hist.getdata("yweight"), dtype=float)
    resid = obs - calc
    result = {}
    for name, lo, hi in (("low", 10.0, 35.0),
                         ("mid", 35.0, 65.0),
                         ("high", 65.0, 100.1)):
        use = (x >= lo) & (x < hi)
        den = np.sum(weight[use] * obs[use] ** 2)
        wr = 100.0 * np.sqrt(np.sum(weight[use] * resid[use] ** 2) / den)
        result[name] = {
            "mean_residual": float(np.mean(resid[use])),
            "rms_residual": float(np.sqrt(np.mean(resid[use] ** 2))),
            "weighted_r_percent": float(wr),
        }
    return result


def summarize(project, label, replayed):
    hist = project.histogram(0)
    frozen = project.get_Frozen()
    return {
        "label": label,
        "project": project.filename,
        "replayed": replayed,
        "frozen": frozen,
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "background_count": hist.Background[0][2],
        "background_coefficients": list(hist.Background[0][3:]),
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "polarization_refine": bool(hist.InstrumentParameters["Polariz."][2]),
        "roughness_a": hist.SampleParameters["SurfRoughA"][0],
        "roughness_b": hist.SampleParameters["SurfRoughB"][0],
        "roughness_refine": [
            bool(hist.SampleParameters["SurfRoughA"][1]),
            bool(hist.SampleParameters["SurfRoughB"][1]),
        ],
        "shl": hist.InstrumentParameters["SH/L"][1],
        "shl_refine": bool(hist.InstrumentParameters["SH/L"][2]),
        "profile": {key: hist.InstrumentParameters[key][1]
                    for key in ("U", "W", "X")},
        "shift_um": hist.SampleParameters["Shift"][0],
        "angular_metrics": angular_metrics(hist),
        "fractions": ({key: value[0] for key, value
                       in hist.ComputeMassFracs().items()} if not frozen else None),
    }


BRANCHES = {
    "background_4": {"background": 4},
    "background_6": {"background": 6},
    "background_8": {"background": 8},
    "background_10": {"background": 10},
    "background_12": {"background": 12},
    "polarization_low": {"background": 8, "polarization": 0.2},
    "polarization_high": {"background": 8, "polarization": 0.8},
    "rough_b_low": {"background": 8, "rough_b": 0.005},
    "rough_b_high": {"background": 8, "rough_b": 0.2},
    "rough_ab": {"background": 8, "rough_ab": (0.5, 0.02)},
    "shl_low": {"background": 8, "shl": 0.0005},
    "shl_high": {"background": 8, "shl": 0.02},
}


def run_branches(branches=BRANCHES, output_prefix="nuisance",
                 summary_name="nuisance_challenges.json"):
    rows = []
    for label, branch in branches.items():
        output = ROOT / f".tmp/{output_prefix}_{label}.gpx"
        try:
            project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
            configure(project, branch)
            project.set_Controls("cycles", 30)
            project.data["Controls"]["data"]["min dM/M"] = 1e-7
            project.save()
            project.do_refinements([{}])
            row = summarize(project, label, False)
            if not row["frozen"]:
                replay_path = output.with_name(output.stem + "_replay.gpx")
                replay = G2sc.G2Project(str(output), newgpx=str(replay_path))
                replay.set_Controls("cycles", 20)
                replay.do_refinements([{}])
                row = summarize(replay, label, True)
        except Exception as exc:
            row = {"label": label, "error": repr(exc)}
        rows.append(row)
        print("NUISANCE_RESULT", json.dumps(row, sort_keys=True))
        (ROOT / ".tmp" / summary_name).write_text(
            json.dumps(rows, indent=2, sort_keys=True) + "\n"
        )
    return rows


if __name__ == "__main__":
    run_branches()
