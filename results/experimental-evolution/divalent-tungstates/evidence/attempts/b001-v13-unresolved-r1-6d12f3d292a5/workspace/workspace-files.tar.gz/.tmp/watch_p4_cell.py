#!/usr/bin/env python3
"""Release the cell only after the weak P4/nmm WO3 scale survives."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = ROOT / ".tmp/watch_wo3_p4nmm_low_replay.gpx"
OUTPUT = ROOT / ".tmp/watch_p4_cell.gpx"
G2sc.SetPrintLevel("none")

project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
hist = project.histogram(0)
frozen = project.data["Controls"]["data"].setdefault(
    "parmFrozen", {"FrozenList": []}
)
for key in list(frozen):
    frozen[key] = []
hist.Background[0][1] = True
inst = hist.InstrumentParameters
inst["Zero"][1:3] = [0.0, False]
inst["U"][1:3] = [0.0, False]
inst["W"][2] = True
inst["X"][2] = True
inst["Polariz."][2] = True
hist.SampleParameters["Shift"][1] = True
for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
    hist.SampleParameters[key][0:2] = [0.0, False]
for index, phase in enumerate(project.phases()):
    phase.set_refinements({"Cell": True})
    hap = phase.getHAPvalues(hist)
    hap["Scale"][1] = True
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    if index == 3:
        hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
for key in (":0:W", ":0:X", ":0:Polariz."):
    project.set_Controls("parmMin", 0.0, key)
project.set_Controls("parmMax", 1.0, ":0:Polariz.")
project.set_Controls("parmMin", 1e-10, "3:0:Scale")
project.set_Controls("cycles", 40)
project.data["Controls"]["data"]["min dM/M"] = 1e-6
project.save()
project.do_refinements([{}])

replay_path = ROOT / ".tmp/watch_p4_cell_replay.gpx"
replay = G2sc.G2Project(str(OUTPUT), newgpx=str(replay_path))
replay.set_Controls("cycles", 25)
replay.data["Controls"]["data"]["min dM/M"] = 1e-5
replay.do_refinements([{}])
hist = replay.histogram(0)
row = {
    "project": replay.filename,
    "frozen": replay.get_Frozen(),
    "wR": hist.residuals.get("wR"),
    "R": hist.residuals.get("R"),
    "cells": {phase.name: phase.get_cell() for phase in replay.phases()},
    "fractions": {key: value[0]
                  for key, value in hist.ComputeMassFracs().items()},
    "fraction_esds": {key: value[1]
                      for key, value in hist.ComputeMassFracs().items()},
    "polarization": hist.InstrumentParameters["Polariz."][1],
}
(ROOT / ".tmp/watch_p4_cell.json").write_text(
    json.dumps(row, indent=2, sort_keys=True) + "\n"
)
print("WATCH_P4_CELL", json.dumps(row, sort_keys=True))
