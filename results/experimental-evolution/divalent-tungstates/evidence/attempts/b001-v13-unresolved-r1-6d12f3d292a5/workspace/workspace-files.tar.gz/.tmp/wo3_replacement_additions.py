#!/usr/bin/env python3
"""Add structurally distinct WO3 records to the accepted three-phase basis."""

import json
import os
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = Path(os.environ.get(
    "WO3_REPLACE_SOURCE",
    str(ROOT / ".tmp/background_ext_background_22_replay.gpx"),
))
COD = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)
ALL_JOBS = {
    "P4nmm_1521533": COD / "1/52/15/1521533.cif",
    "P4ncc_1521532": COD / "1/52/15/1521532.cif",
    "Pminus1_2106293": COD / "2/10/62/2106293.cif",
    "Pnma_2107312": COD / "2/10/73/2107312.cif",
}
selected_jobs = {
    value for value in os.environ.get("WO3_REPLACE_JOBS", "").split(",")
    if value.strip()
}
JOBS = {key: value for key, value in ALL_JOBS.items()
        if not selected_jobs or key in selected_jobs}
G2sc.SetPrintLevel("none")
OUTPUT_PREFIX = os.environ.get("WO3_REPLACE_PREFIX", "replace")


def clear_frozen(project):
    frozen = project.data["Controls"]["data"].setdefault(
        "parmFrozen", {"FrozenList": []}
    )
    for key in list(frozen):
        frozen[key] = []


def inactive(phase, hist):
    hap = phase.getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def common(project):
    hist = project.histogram(0)
    clear_frozen(project)
    hist.Background[0][1] = True
    inst = hist.InstrumentParameters
    inst["Zero"][1:3] = [0.0, False]
    inst["U"][1:3] = [0.0, False]
    inst["W"][2] = True
    inst["X"][2] = True
    inst["Polariz."][2] = True
    inst["SH/L"][2] = False
    hist.SampleParameters["Shift"][1] = True
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key][0:2] = [0.0, False]
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.getHAPvalues(hist)["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Scale")
    return hist


def summary(project, label, seed, stage):
    hist = project.histogram(0)
    phase = project.phases()[-1]
    hap = phase.getHAPvalues(hist)
    frozen = project.get_Frozen()
    fractions = None
    if not frozen:
        try:
            fractions = {key: value[0]
                         for key, value in hist.ComputeMassFracs().items()}
        except Exception:
            pass
    return {
        "label": label,
        "seed": seed,
        "stage": stage,
        "project": project.filename,
        "frozen": frozen,
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "added_phase": phase.name,
        "added_scale": hap["Scale"][0],
        "added_cell": phase.get_cell(),
        "fractions": fractions,
    }


rows = []
for label, cif in JOBS.items():
    for seed_tag, seed in (("low", 0.02), ("high", 0.50)):
        output = ROOT / f".tmp/{OUTPUT_PREFIX}_{label}_{seed_tag}.gpx"
        try:
            project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
            hist = common(project)
            added = project.add_phase(
                str(cif), phasename=f"replace_WO3_{label}",
                histograms=[hist], fmthint="CIF"
            )
            inactive(added, hist)
            added.set_refinements({"Cell": False})
            hap = added.getHAPvalues(hist)
            hap["Scale"][:] = [seed, True]
            project.set_Controls("parmMin", 1e-10, f"{added.id}:0:Scale")
            project.set_Controls("parmMax", 100.0, f"{added.id}:0:Scale")
            project.set_Controls("cycles", 30)
            project.data["Controls"]["data"]["min dM/M"] = 1e-6
            project.save()
            project.do_refinements([{}])
            row = summary(project, label, seed_tag, "scale")
            if not row["frozen"]:
                added.set_refinements({"Cell": True})
                project.set_Controls("cycles", 30)
                project.save()
                project.do_refinements([{}])
                row = summary(project, label, seed_tag, "cell")
            if not row["frozen"]:
                replay_path = output.with_name(output.stem + "_replay.gpx")
                replay = G2sc.G2Project(str(output), newgpx=str(replay_path))
                replay.set_Controls("cycles", 20)
                replay.data["Controls"]["data"]["min dM/M"] = 1e-5
                replay.do_refinements([{}])
                project = replay
                row = summary(project, label, seed_tag, "replay")
        except Exception as exc:
            row = {"label": label, "seed": seed_tag, "error": repr(exc)}
        rows.append(row)
        print("WO3_REPLACEMENT", json.dumps(row, sort_keys=True), flush=True)
        result_name = os.environ.get(
            "WO3_REPLACE_RESULT", "wo3_replacement_additions.json"
        )
        (ROOT / ".tmp" / result_name).write_text(
            json.dumps(rows, indent=2, sort_keys=True) + "\n"
        )
