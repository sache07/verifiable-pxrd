#!/usr/bin/env python3
"""Complete low-index MD texture and uniaxial width-axis scan."""

import concurrent.futures
import itertools
import json
import math
import os
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = Path(os.environ.get(
    "AXIS_SOURCE", str(ROOT / ".tmp/angular_shift_replay.gpx")
))
PREFIX = os.environ.get("AXIS_PREFIX", "axis")
PRESERVE_TEXTURE = os.environ.get("AXIS_PRESERVE_TEXTURE", "0") == "1"
MODELS = tuple(os.environ.get(
    "AXIS_MODELS", "texture,size,strain"
).split(","))
PHASE_FILTER = {
    int(value) for value in os.environ.get("AXIS_PHASES", "").split(",")
    if value.strip()
}
G2sc.SetPrintLevel("none")


def canonical_axis(v):
    v = tuple(int(round(x)) for x in v)
    for value in v:
        if value:
            return tuple(-x for x in v) if value < 0 else v
    raise ValueError("zero axis")


def enumerate_axes(phase):
    """Primitive reciprocal axes through max |index|=2, modulo phase symmetry."""
    matrices = []
    for operation in phase.data["General"]["SGData"]["SGOps"]:
        rotation = np.asarray(operation[0], dtype=int)
        reciprocal = np.rint(np.linalg.inv(rotation).T).astype(int)
        matrices.extend((reciprocal, -reciprocal))
    vectors = set()
    for vector in itertools.product(range(-2, 3), repeat=3):
        if vector == (0, 0, 0) or math.gcd(*map(abs, vector)) != 1:
            continue
        vectors.add(canonical_axis(vector))
    remaining = set(vectors)
    representatives = []
    while remaining:
        representative = min(
            remaining,
            key=lambda x: (max(map(abs, x)), sum(map(abs, x)), x),
        )
        orbit = {
            canonical_axis(matrix @ np.asarray(representative))
            for matrix in matrices
        }
        remaining -= orbit
        representatives.append(representative)
    return representatives


def clear_frozen(project):
    frozen = project.data["Controls"]["data"].setdefault(
        "parmFrozen", {"FrozenList": []}
    )
    for key in list(frozen):
        frozen[key] = []


def reset_neutral(project):
    hist = project.histogram(0)
    clear_frozen(project)
    hist.Background[0][1] = True
    hist.InstrumentParameters["Zero"][1:3] = [0.0, False]
    hist.InstrumentParameters["U"][1:3] = [0.0, False]
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["X"][2] = True
    hist.SampleParameters["Shift"][1] = True
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key][0:2] = [0.0, False]
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        if not PRESERVE_TEXTURE:
            hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    return hist


def axis_tag(axis):
    return "_".join((f"m{abs(v)}" if v < 0 else f"p{v}") for v in axis)


def scan_one(task):
    phase_index, phase_name, model, axis = task
    tag = axis_tag(axis)
    output = ROOT / f".tmp/{PREFIX}_{model}_p{phase_index}_{tag}.gpx"
    label = f"{model}_p{phase_index}_{axis}"
    try:
        project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
        hist = reset_neutral(project)
        phase = project.phase(phase_index)
        hap = phase.getHAPvalues(hist)
        if model == "texture":
            hap["Pref.Ori."][0:4] = ["MD", 0.92, True, list(axis)]
            project.set_Controls("parmMin", 0.2, f"{phase.id}:0:MD")
            project.set_Controls("parmMax", 5.0, f"{phase.id}:0:MD")
        elif model == "size":
            hap["Size"][0] = "uniaxial"
            hap["Size"][1][:] = [0.30, 0.60, 1.0]
            hap["Size"][2][:] = [True, True, False]
            hap["Size"][3] = list(axis)
            for suffix in ("i", "a"):
                name = f"{phase.id}:0:Size;{suffix}"
                project.set_Controls("parmMin", 0.02, name)
                project.set_Controls("parmMax", 100.0, name)
        elif model == "strain":
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1][:] = [200.0, 500.0, 1.0]
            hap["Mustrain"][2][:] = [True, True, False]
            hap["Mustrain"][3] = list(axis)
            for suffix in ("i", "a"):
                name = f"{phase.id}:0:Mustrain;{suffix}"
                project.set_Controls("parmMin", 0.0, name)
                project.set_Controls("parmMax", 10000.0, name)
        else:
            raise ValueError(model)
        # Screening starts from a fully converged checkpoint. Six cycles are
        # enough to rank all axes; leading branches are fully replayed later.
        project.set_Controls("cycles", 6)
        project.data["Controls"]["data"]["min dM/M"] = 1e-7
        project.save()
        project.do_refinements([{}])
        hist = project.histogram(0)
        phase = project.phase(phase_index)
        hap = phase.getHAPvalues(hist)
        result = {
            "label": label,
            "phase_index": phase_index,
            "phase": phase_name,
            "model": model,
            "axis": list(axis),
            "project": str(output),
            "frozen": project.get_Frozen(),
            "wR": hist.residuals.get("wR"),
            "R": hist.residuals.get("R"),
            "W": hist.InstrumentParameters["W"][1],
            "X": hist.InstrumentParameters["X"][1],
            "shift_um": hist.SampleParameters["Shift"][0],
        }
        if model == "texture":
            result["ratio"] = hap["Pref.Ori."][1]
        elif model == "size":
            result["values"] = list(hap["Size"][1][:2])
        else:
            result["values"] = list(hap["Mustrain"][1][:2])
        return result
    except Exception as exc:
        return {
            "label": label,
            "phase_index": phase_index,
            "phase": phase_name,
            "model": model,
            "axis": list(axis),
            "project": str(output),
            "error": repr(exc),
        }


def main():
    probe = G2sc.G2Project(str(SOURCE))
    inventory = []
    tasks = []
    for phase_index, phase in enumerate(probe.phases()):
        axes = enumerate_axes(phase)
        inventory.append({
            "phase_index": phase_index,
            "phase": phase.name,
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "axes": [list(axis) for axis in axes],
        })
        if PHASE_FILTER and phase_index not in PHASE_FILTER:
            continue
        for model in MODELS:
            tasks.extend(
                (phase_index, phase.name, model, axis) for axis in axes
            )
    (ROOT / f".tmp/{PREFIX}_inventory.json").write_text(
        json.dumps(inventory, indent=2) + "\n"
    )
    rows = []
    workers = min(6, os.cpu_count() or 1)
    with concurrent.futures.ProcessPoolExecutor(max_workers=workers) as pool:
        for row in pool.map(scan_one, tasks, chunksize=1):
            rows.append(row)
            print("AXIS_RESULT", json.dumps(row, sort_keys=True), flush=True)
            (ROOT / f".tmp/{PREFIX}_scan.json").write_text(
                json.dumps(rows, indent=2, sort_keys=True) + "\n"
            )


if __name__ == "__main__":
    main()
