#!/usr/bin/env python3
"""Staged source challenges: scales before cells, then shared profile replay."""

import importlib.util
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SPEC = importlib.util.spec_from_file_location("source_helpers", ROOT / ".tmp/source_branches.py")
HELP = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(HELP)
SEED_PROJECT = G2sc.G2Project(str(ROOT / ".tmp/source_wo3_P21c_2311041_replay.gpx"))
SEED_HIST = SEED_PROJECT.histogram(0)
SEED_BACKGROUND = list(SEED_HIST.Background[0][3:])
SEED_PROFILE = {key: SEED_HIST.InstrumentParameters[key][1]
                for key in ("Zero", "W", "X")}
G2sc.SetPrintLevel("warn")


def stage_summary(project, label):
    hist = project.histogram(0)
    return {
        "stage": label,
        "wR": hist.residuals.get("wR"),
        "frozen": project.get_Frozen(),
        "profile": {key: hist.InstrumentParameters[key][1]
                    for key in ("Zero", "U", "W", "X")},
        "scales": {phase.name: phase.getHAPvalues(hist)["Scale"][0]
                   for phase in project.phases()},
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }


def run_staged(label, phase_defs, target_fracs):
    project = G2sc.G2Project(newgpx=str(ROOT / f".tmp/staged_{label}_scales.gpx"))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"), str(ROOT / ".tmp/lab_cuka.instprm"),
        fmthint="comma",
    )
    hist.SampleParameters["Scale"][:] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key][:] = [0.0, False]
    hist.set_refinements({"Background": {
        "type": "chebyschev-1", "refine": True, "no. coeffs": 8,
        "coeffs": SEED_BACKGROUND,
    }})
    phases = []
    source_volumes = {}
    for name, path in phase_defs:
        phase = project.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
        HELP.inactive_physics(phase, hist)
        source_volumes[name] = phase.get_cell()["volume"]
        phases.append(phase)
    normalizer = 16000.0
    for phase, fraction in zip(phases, target_fracs):
        hap = phase.getHAPvalues(hist)
        hap["Scale"][:] = [fraction * normalizer / phase.data["General"]["Mass"], True]
        project.set_Controls("parmMin", 1e-8, f"{phase.id}:0:Scale")
        phase.set_refinements({"Cell": False})
    inst = hist.InstrumentParameters
    for key in ("U", "V", "Y", "Z", "SH/L", "Polariz.", "I(L2)/I(L1)"):
        inst[key][2] = False
    inst["U"][1] = 0.0
    # Cell seeds were prepared on the measured angular scale. Keep the angular
    # correction literal zero while scales and cells establish themselves;
    # release it only in the coupled profile stage.
    inst["Zero"][1] = 0.0
    inst["Zero"][2] = False
    for key in ("W", "X"):
        inst[key][1] = SEED_PROFILE[key]
        inst[key][2] = False
    project.set_Controls("parmMin", 0.0, ":0:W")
    project.set_Controls("parmMin", 0.0, ":0:X")
    project.set_Controls("parmMax", 5000.0, ":0:W")
    project.set_Controls("parmMax", 500.0, ":0:X")
    project.set_Controls("cycles", 25)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.save()
    project.do_refinements([{}])
    stages = [stage_summary(project, "scales")]
    if project.get_Frozen():
        return {"label": label, "valid": False, "stages": stages,
                "project": project.filename}

    project.save(ROOT / f".tmp/staged_{label}_cells.gpx")
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.set_Controls("cycles", 30)
    project.do_refinements([{}])
    stages.append(stage_summary(project, "cells"))
    if project.get_Frozen():
        return {"label": label, "valid": False, "stages": stages,
                "project": project.filename}

    project.save(ROOT / f".tmp/staged_{label}_profile.gpx")
    for key in ("Zero", "W", "X"):
        hist.InstrumentParameters[key][2] = True
    project.set_Controls("cycles", 30)
    project.do_refinements([{}])
    stages.append(stage_summary(project, "profile"))
    if project.get_Frozen():
        return {"label": label, "valid": False, "stages": stages,
                "project": project.filename}

    project.save(ROOT / f".tmp/staged_{label}_replay.gpx")
    project.set_Controls("cycles", 20)
    project.do_refinements([{}])
    stages.append(stage_summary(project, "replay"))
    cells = {phase.name: phase.get_cell() for phase in project.phases()}
    return {
        "label": label,
        "valid": not project.get_Frozen(),
        "project": project.filename,
        "stages": stages,
        "volume_ratios": {name: cells[name]["volume"] / source_volumes[name]
                          for name in cells},
        "fractions": {key: value[0] for key, value in hist.ComputeMassFracs().items()},
        "fraction_esds": {key: value[1] for key, value in hist.ComputeMassFracs().items()},
        "residuals": hist.residuals,
    }


P21C = HELP.WO3["P21c_2311041"]
jobs = [
    ("baseline", [("SrWO4_scheelite", HELP.SCHEELITE),
                   ("WO3_P21c", P21C), ("SrCO3_Pnma", HELP.SRCO3_PNMA)],
     [0.61, 0.22, 0.17]),
    ("srwo4_C2c", [("SrWO4_C2c", HELP.MONO_TUNGSTATE),
                    ("WO3_P21c", P21C), ("SrCO3_Pnma", HELP.SRCO3_PNMA)],
     [0.61, 0.22, 0.17]),
    ("sr3w2o9", [("Sr3W2O9_C2c", HELP.SR3W2O9),
                  ("WO3_P21c", P21C), ("SrCO3_Pnma", HELP.SRCO3_PNMA)],
     [0.61, 0.22, 0.17]),
    ("srco3_R3m", [("SrWO4_scheelite", HELP.SCHEELITE),
                    ("WO3_P21c", P21C), ("SrCO3_R3m", HELP.SRCO3_R3M)],
     [0.61, 0.22, 0.17]),
]

results = []
for label, defs, fractions in jobs:
    try:
        row = run_staged(label, defs, fractions)
    except Exception as exc:
        row = {"label": label, "valid": False, "error": repr(exc)}
    results.append(row)
    print("STAGED_RESULT", json.dumps(row, sort_keys=True))
    (ROOT / ".tmp/staged_source_challenges.json").write_text(
        json.dumps(results, indent=2, sort_keys=True) + "\n"
    )
