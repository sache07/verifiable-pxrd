#!/usr/bin/env python3
"""Fully replay the near-bound P4/nmm texture leader from opposite seeds."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = ROOT / ".tmp/tetragonal_shift_replay.gpx"
G2sc.SetPrintLevel("none")


def clear_frozen(project):
    frozen = project.data["Controls"]["data"].setdefault(
        "parmFrozen", {"FrozenList": []}
    )
    for key in list(frozen):
        frozen[key] = []


def summarize(project, seed, replayed):
    hist = project.histogram(0)
    return {
        "seed": seed,
        "replayed": replayed,
        "project": project.filename,
        "frozen": project.get_Frozen(),
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "textures": {
            phase.name: {
                "axis": list(phase.getHAPvalues(hist)["Pref.Ori."][3]),
                "ratio": phase.getHAPvalues(hist)["Pref.Ori."][1],
            } for phase in project.phases()
        },
    }


rows = []
for tag, seed in (("low", 0.4), ("high", 2.0)):
    output = ROOT / f".tmp/tetragonal_extreme_{tag}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
    hist = project.histogram(0)
    clear_frozen(project)
    hist.Background[0][1] = True
    hist.InstrumentParameters["Zero"][1:3] = [0.0, False]
    hist.InstrumentParameters["U"][1:3] = [0.0, False]
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["X"][2] = True
    hist.SampleParameters["Shift"][1] = True
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key][0:2] = [0.0, False]
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    for index, ratio in ((0, 0.707), (1, seed)):
        phase = project.phase(index)
        hap = phase.getHAPvalues(hist)
        hap["Pref.Ori."][0:4] = ["MD", ratio, True, [1, -1, 0]]
        project.set_Controls("parmMin", 0.2, f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 5.0, f"{phase.id}:0:MD")
    project.set_Controls("cycles", 35)
    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.save()
    project.do_refinements([{}])
    row = summarize(project, tag, False)
    if not row["frozen"]:
        replay_path = output.with_name(output.stem + "_replay.gpx")
        replay = G2sc.G2Project(str(output), newgpx=str(replay_path))
        replay.set_Controls("cycles", 20)
        replay.do_refinements([{}])
        row = summarize(replay, tag, True)
    rows.append(row)
    print("EXTREME_TEXTURE", json.dumps(row, sort_keys=True))

(ROOT / ".tmp/tetragonal_extreme_texture.json").write_text(
    json.dumps(rows, indent=2, sort_keys=True) + "\n"
)
