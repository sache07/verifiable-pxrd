#!/usr/bin/env python3
"""Polarization, roughness and asymmetry replay on the chosen background."""

import importlib.util
from pathlib import Path


ROOT = Path.cwd()
spec = importlib.util.spec_from_file_location(
    "nuisance_helpers", ROOT / ".tmp/nuisance_challenges.py"
)
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
helpers.SOURCE = ROOT / ".tmp/background_ext_background_22_replay.gpx"

branches = {
    "polarization_low": {"background": 22, "polarization": 0.5},
    "polarization_high": {"background": 22, "polarization": 0.9},
    "rough_b_low": {
        "background": 22, "preserve_polarization": True,
        "rough_b": 0.005,
    },
    "rough_b_high": {
        "background": 22, "preserve_polarization": True,
        "rough_b": 0.2,
    },
    "shl_low": {
        "background": 22, "preserve_polarization": True,
        "shl": 0.0005,
    },
    "shl_high": {
        "background": 22, "preserve_polarization": True,
        "shl": 0.02,
    },
}
helpers.run_branches(
    branches, output_prefix="final_nuisance",
    summary_name="final_nuisance.json",
)
