#!/usr/bin/env python3
"""Full cross-seeded replays for leading neutral-checkpoint terms."""

import concurrent.futures
import json
import os
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = ROOT / ".tmp/angular_shift_replay.gpx"
G2sc.SetPrintLevel("none")


def clear_frozen(project):
    frozen = project.data["Controls"]["data"].setdefault(
        "parmFrozen", {"FrozenList": []}
    )
    for key in list(frozen):
        frozen[key] = []


def reset(project):
    hist = project.histogram(0)
    clear_frozen(project)
    hist.Background[0][1] = True
    hist.InstrumentParameters["Zero"][1:3] = [0.0, False]
    hist.InstrumentParameters["U"][1:3] = [0.0, False]
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["X"][2] = True
    hist.SampleParameters["Shift"][1] = True
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key][0:2] = [0.0, False]
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    return hist


def summarize(project, task, replayed):
    hist = project.histogram(0)
    textures = {}
    sizes = {}
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        if hap["Pref.Ori."][2]:
            textures[phase.name] = {
                "axis": list(hap["Pref.Ori."][3]),
                "ratio": hap["Pref.Ori."][1],
            }
        if hap["Size"][0] == "uniaxial":
            sizes[phase.name] = {
                "axis": list(hap["Size"][3]),
                "values_um": list(hap["Size"][1][:2]),
            }
    frozen = project.get_Frozen()
    return {
        "label": task["label"],
        "project": project.filename,
        "replayed": replayed,
        "frozen": frozen,
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "profile": {k: hist.InstrumentParameters[k][1] for k in ("W", "X")},
        "shift_um": hist.SampleParameters["Shift"][0],
        "textures": textures,
        "sizes": sizes,
        "fractions": ({key: value[0] for key, value
                       in hist.ComputeMassFracs().items()} if not frozen else None),
    }


def run(task):
    output = ROOT / f".tmp/leader_{task['label']}.gpx"
    try:
        project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
        hist = reset(project)
        for phase_index, axis, ratio in task.get("textures", []):
            phase = project.phase(phase_index)
            hap = phase.getHAPvalues(hist)
            hap["Pref.Ori."][0:4] = ["MD", ratio, True, list(axis)]
            name = f"{phase.id}:0:MD"
            project.set_Controls("parmMin", 0.2, name)
            project.set_Controls("parmMax", 5.0, name)
        if "size" in task:
            phase_index, axis, values = task["size"]
            phase = project.phase(phase_index)
            hap = phase.getHAPvalues(hist)
            hap["Size"][0] = "uniaxial"
            hap["Size"][1][:] = [values[0], values[1], 1.0]
            hap["Size"][2][:] = [True, True, False]
            hap["Size"][3] = list(axis)
            for suffix in ("i", "a"):
                name = f"{phase.id}:0:Size;{suffix}"
                project.set_Controls("parmMin", 0.02, name)
                project.set_Controls("parmMax", 100.0, name)
        project.set_Controls("cycles", 25)
        project.data["Controls"]["data"]["min dM/M"] = 1e-7
        project.save()
        project.do_refinements([{}])
        row = summarize(project, task, False)
        if not row["frozen"]:
            replay_path = output.with_name(output.stem + "_replay.gpx")
            replay = G2sc.G2Project(str(output), newgpx=str(replay_path))
            replay.set_Controls("cycles", 15)
            replay.do_refinements([{}])
            row = summarize(replay, task, True)
        return row
    except Exception as exc:
        return {"label": task["label"], "error": repr(exc)}


P0A = (2, -2, -1)
P0B = (1, -1, 0)
P1A = (2, -1, -2)
P1B = (1, 0, -1)

tasks = []
for tag, axis in (("p0a", P0A), ("p0b", P0B)):
    for seed_tag, seed in (("lo", 0.75), ("hi", 1.25)):
        tasks.append({"label": f"{tag}_{seed_tag}",
                      "textures": [(0, axis, seed)]})
for tag, axis in (("p1a", P1A), ("p1b", P1B)):
    for seed_tag, seed in (("lo", 0.75), ("hi", 1.30)):
        tasks.append({"label": f"{tag}_{seed_tag}",
                      "textures": [(1, axis, seed)]})
for seed_tag, values in (("low", (0.08, 0.03)),
                         ("mid", (0.50, 0.05)),
                         ("high", (2.00, 0.20))):
    tasks.append({"label": f"p1size_{seed_tag}",
                  "size": (1, P1B, values)})
for p0tag, p0axis in (("a", P0A), ("b", P0B)):
    for p1tag, p1axis in (("a", P1A), ("b", P1B)):
        tasks.append({
            "label": f"combo_{p0tag}{p1tag}",
            "textures": [(0, p0axis, 0.70), (1, p1axis, 1.30)],
        })


def main():
    rows = []
    with concurrent.futures.ProcessPoolExecutor(
        max_workers=min(5, os.cpu_count() or 1)
    ) as pool:
        for row in pool.map(run, tasks, chunksize=1):
            rows.append(row)
            print("LEADER_RESULT", json.dumps(row, sort_keys=True), flush=True)
            (ROOT / ".tmp/leader_replay.json").write_text(
                json.dumps(rows, indent=2, sort_keys=True) + "\n"
            )


if __name__ == "__main__":
    main()
