#!/usr/bin/env python3
"""Phasewise isotropic size/strain challenges from one common checkpoint."""

import json
import os
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = Path(os.environ.get(
    "WIDTH_SOURCE", str(ROOT / ".tmp/angular_shift_replay.gpx")
))
PREFIX = os.environ.get("WIDTH_PREFIX", "width")
PRESERVE_TEXTURE = os.environ.get("WIDTH_PRESERVE_TEXTURE", "0") == "1"
PHASE_FILTER = {
    int(value) for value in os.environ.get("WIDTH_PHASES", "").split(",")
    if value.strip()
}
G2sc.SetPrintLevel("none")


def clear_frozen(project):
    frozen = project.data["Controls"]["data"].setdefault(
        "parmFrozen", {"FrozenList": []}
    )
    for key in list(frozen):
        frozen[key] = []


def reset_common(project):
    hist = project.histogram(0)
    clear_frozen(project)
    hist.Background[0][1] = True
    hist.InstrumentParameters["Zero"][1:3] = [0.0, False]
    hist.InstrumentParameters["U"][1:3] = [0.0, False]
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["X"][2] = True
    hist.SampleParameters["Shift"][1] = True
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key][0:2] = [0.0, False]
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        if not PRESERVE_TEXTURE:
            hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    return hist


def run(phase_index, model):
    label = f"p{phase_index}_{model}"
    output = ROOT / f".tmp/{PREFIX}_{label}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
    hist = reset_common(project)
    phase = project.phase(phase_index)
    hap = phase.getHAPvalues(hist)
    if model in ("size", "combined"):
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
        project.set_Controls("parmMin", 0.02, f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 100.0, f"{phase.id}:0:Size;i")
    if model in ("strain", "combined"):
        hap["Mustrain"][1][0] = 100.0
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, f"{phase.id}:0:Mustrain;i")
    project.set_Controls("cycles", 25)
    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.save()
    project.do_refinements([{}])
    frozen = project.get_Frozen()
    replayed = False
    if not frozen:
        replay = G2sc.G2Project(
            str(output), newgpx=str(output.with_name(output.stem + "_replay.gpx"))
        )
        replay.set_Controls("cycles", 15)
        replay.do_refinements([{}])
        project = replay
        hist = project.histogram(0)
        phase = project.phase(phase_index)
        hap = phase.getHAPvalues(hist)
        frozen = project.get_Frozen()
        replayed = True
    return {
        "label": label,
        "phase": phase.name,
        "model": model,
        "project": project.filename,
        "replayed": replayed,
        "frozen": frozen,
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "size_um": hap["Size"][1][0],
        "strain_micro": hap["Mustrain"][1][0],
        "profile": {key: hist.InstrumentParameters[key][1]
                    for key in ("W", "X")},
        "shift_um": hist.SampleParameters["Shift"][0],
        "fractions": {key: value[0] for key, value in hist.ComputeMassFracs().items()}
                     if not frozen else None,
    }


rows = []
probe = G2sc.G2Project(str(SOURCE))
for phase_index in range(len(probe.phases())):
    if PHASE_FILTER and phase_index not in PHASE_FILTER:
        continue
    for model in ("size", "strain", "combined"):
        try:
            row = run(phase_index, model)
        except Exception as exc:
            row = {"label": f"p{phase_index}_{model}", "error": repr(exc)}
        rows.append(row)
        print("WIDTH_RESULT", json.dumps(row, sort_keys=True))
        (ROOT / f".tmp/{PREFIX}_branches.json").write_text(
            json.dumps(rows, indent=2, sort_keys=True) + "\n"
        )
