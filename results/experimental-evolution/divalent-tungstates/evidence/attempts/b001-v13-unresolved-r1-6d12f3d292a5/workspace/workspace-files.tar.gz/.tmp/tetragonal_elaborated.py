#!/usr/bin/env python3
"""Construct and replay the best neutral-screen P4/nmm texture pair."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = ROOT / ".tmp/tetragonal_shift_replay.gpx"
OUTPUT = ROOT / ".tmp/tetragonal_elaborated.gpx"
G2sc.SetPrintLevel("none")

project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
hist = project.histogram(0)
frozen = project.data["Controls"]["data"].setdefault(
    "parmFrozen", {"FrozenList": []}
)
for key in list(frozen):
    frozen[key] = []
hist.Background[0][1] = True
hist.InstrumentParameters["Zero"][1:3] = [0.0, False]
hist.InstrumentParameters["U"][1:3] = [0.0, False]
hist.InstrumentParameters["W"][2] = True
hist.InstrumentParameters["X"][2] = True
hist.SampleParameters["Shift"][1] = True
for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
    hist.SampleParameters[key][0:2] = [0.0, False]
for phase in project.phases():
    phase.set_refinements({"Cell": True})
    hap = phase.getHAPvalues(hist)
    hap["Scale"][1] = True
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
for index, ratio in ((0, 0.707), (1, 1.57)):
    phase = project.phase(index)
    hap = phase.getHAPvalues(hist)
    axis = [1, -1, 0] if index == 0 else [2, -2, -1]
    hap["Pref.Ori."][0:4] = ["MD", ratio, True, axis]
    project.set_Controls("parmMin", 0.2, f"{phase.id}:0:MD")
    project.set_Controls("parmMax", 5.0, f"{phase.id}:0:MD")
project.set_Controls("cycles", 30)
project.data["Controls"]["data"]["min dM/M"] = 1e-7
project.save()
project.do_refinements([{}])
row = {"first_frozen": project.get_Frozen()}
if not row["first_frozen"]:
    replay_path = ROOT / ".tmp/tetragonal_elaborated_replay.gpx"
    replay = G2sc.G2Project(str(OUTPUT), newgpx=str(replay_path))
    replay.set_Controls("cycles", 20)
    replay.do_refinements([{}])
    project = replay
hist = project.histogram(0)
row.update({
    "project": project.filename,
    "frozen": project.get_Frozen(),
    "wR": hist.residuals.get("wR"),
    "R": hist.residuals.get("R"),
    "profile": {key: hist.InstrumentParameters[key][1]
                for key in ("W", "X")},
    "shift_um": hist.SampleParameters["Shift"][0],
    "textures": {
        phase.name: {
            "axis": list(phase.getHAPvalues(hist)["Pref.Ori."][3]),
            "ratio": phase.getHAPvalues(hist)["Pref.Ori."][1],
            "refine": bool(phase.getHAPvalues(hist)["Pref.Ori."][2]),
        } for phase in project.phases()
    },
    "fractions": ({key: value[0] for key, value
                   in hist.ComputeMassFracs().items()} if not project.get_Frozen()
                  else None),
})
(ROOT / ".tmp/tetragonal_elaborated.json").write_text(
    json.dumps(row, indent=2, sort_keys=True) + "\n"
)
print("TETRAGONAL_ELABORATED", json.dumps(row, sort_keys=True))
