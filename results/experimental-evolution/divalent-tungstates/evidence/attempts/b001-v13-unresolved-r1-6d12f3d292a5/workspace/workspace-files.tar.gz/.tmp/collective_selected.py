#!/usr/bin/env python3
"""Collectively release selected isotropic widths, then delete each term."""

import json
import os
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = Path(os.environ.get(
    "COLLECTIVE_SOURCE", str(ROOT / ".tmp/texture_pol16_p0new_low_replay.gpx")
))
PREFIX = os.environ.get("COLLECTIVE_PREFIX", "collective_selected")
TERMS = json.loads(os.environ.get(
    "COLLECTIVE_TERMS",
    '[{"phase":1,"kind":"size"},{"phase":1,"kind":"strain"}]',
))
G2sc.SetPrintLevel("none")


def clear_frozen(project):
    frozen = project.data["Controls"]["data"].setdefault(
        "parmFrozen", {"FrozenList": []}
    )
    for key in list(frozen):
        frozen[key] = []


def common(project):
    hist = project.histogram(0)
    clear_frozen(project)
    hist.Background[0][1] = True
    inst = hist.InstrumentParameters
    inst["Zero"][1:3] = [0.0, False]
    for key in ("U", "W", "X"):
        inst[key][2] = True
        project.set_Controls("parmMin", 0.0, f":0:{key}")
    inst["Polariz."][2] = True
    hist.SampleParameters["Shift"][1] = True
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key][0:2] = [0.0, False]
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    return hist


def activate(project, hist, seed, omitted=None):
    hist.InstrumentParameters["U"][1] = seed["u"]
    for term_index, term in enumerate(TERMS):
        if term_index == omitted:
            continue
        phase = project.phase(term["phase"])
        hap = phase.getHAPvalues(hist)
        if term["kind"] == "size":
            hap["Size"][1][0] = seed["size"]
            hap["Size"][2][0] = True
            name = f"{phase.id}:0:Size;i"
            project.set_Controls("parmMin", 0.02, name)
            project.set_Controls("parmMax", 100.0, name)
        elif term["kind"] == "strain":
            hap["Mustrain"][1][0] = seed["strain"]
            hap["Mustrain"][2][0] = True
            name = f"{phase.id}:0:Mustrain;i"
            project.set_Controls("parmMin", 0.0, name)
            project.set_Controls("parmMax", 10000.0, name)
        else:
            raise ValueError(term)


def summarize(project, label, replayed):
    hist = project.histogram(0)
    frozen = project.get_Frozen()
    return {
        "label": label,
        "replayed": replayed,
        "project": project.filename,
        "frozen": frozen,
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "profile": {key: hist.InstrumentParameters[key][1]
                    for key in ("U", "W", "X")},
        "widths": {
            phase.name: {
                "size_um": phase.getHAPvalues(hist)["Size"][1][0],
                "size_refine": bool(phase.getHAPvalues(hist)["Size"][2][0]),
                "strain_micro": phase.getHAPvalues(hist)["Mustrain"][1][0],
                "strain_refine": bool(phase.getHAPvalues(hist)["Mustrain"][2][0]),
            } for phase in project.phases()
        },
        "fractions": ({key: value[0] for key, value
                       in hist.ComputeMassFracs().items()} if not frozen else None),
    }


def run(source, output, label, seed, omitted=None):
    project = G2sc.G2Project(str(source), newgpx=str(output))
    hist = common(project)
    activate(project, hist, seed, omitted)
    project.set_Controls("cycles", 40)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.save()
    project.do_refinements([{}])
    row = summarize(project, label, False)
    if not row["frozen"]:
        replay_path = output.with_name(output.stem + "_replay.gpx")
        replay = G2sc.G2Project(str(output), newgpx=str(replay_path))
        replay.set_Controls("cycles", 25)
        replay.data["Controls"]["data"]["min dM/M"] = 1e-5
        replay.do_refinements([{}])
        project = replay
        row = summarize(project, label, True)
    return project, row


seeds = [
    ("low_a", {"u": 0.2, "size": 0.10, "strain": 100.0}),
    ("low_b", {"u": 1.0, "size": 0.35, "strain": 400.0}),
    ("low_c", {"u": 3.0, "size": 1.00, "strain": 1000.0}),
]
rows = []
projects = []
for label, seed in seeds:
    project, row = run(
        SOURCE, ROOT / f".tmp/{PREFIX}_{label}.gpx", label, seed
    )
    rows.append(row)
    projects.append(project)
    print("COLLECTIVE_SELECTED", json.dumps(row, sort_keys=True))

if rows and all(not row["frozen"] for row in rows):
    winner = Path(projects[0].filename)
    for term_index, term in enumerate(TERMS):
        label = f"delete_{term_index}_{term['kind']}_p{term['phase']}"
        project, row = run(
            winner, ROOT / f".tmp/{PREFIX}_{label}.gpx", label,
            seeds[0][1], omitted=term_index,
        )
        rows.append(row)
        print("COLLECTIVE_SELECTED", json.dumps(row, sort_keys=True))

(ROOT / f".tmp/{PREFIX}.json").write_text(
    json.dumps(rows, indent=2, sort_keys=True) + "\n"
)
