#!/usr/bin/env python3
"""Restore neutral broadening/texture terms for one phase and replay."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from three_phase_trials import refine, snapshot


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("destination", type=Path)
parser.add_argument("phase")
args = parser.parse_args()

destination = args.destination.resolve()
project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(destination))
hist = project.histogram(0)
phase = project.phase(args.phase)
phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
hap = phase.getHAPvalues(hist.name)
hap["Size"][2] = [False for _ in hap["Size"][2]]
hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
hap["Pref.Ori."][0] = "MD"
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = False
refine(project, destination.with_suffix(""), cycles=25, repeats=3)
project.save(str(destination))
print(json.dumps(snapshot(project, "pruned"), indent=2, sort_keys=True))
