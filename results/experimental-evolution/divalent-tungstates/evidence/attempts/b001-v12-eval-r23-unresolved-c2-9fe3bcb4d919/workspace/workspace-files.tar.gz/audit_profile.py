#!/usr/bin/env python3
"""Audit peak positions and asymmetric half-widths in a GSAS-II profile."""

from __future__ import annotations

import json
import sys

import numpy as np
from scipy.signal import find_peaks, peak_prominences, peak_widths
from GSASII import GSASIIscriptable as G2sc


project = G2sc.G2Project(sys.argv[1])
hist = project.histogram(0)
x = np.asarray(hist.getdata("X"), dtype=float)
yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
bkg = np.asarray(hist.getdata("Background"), dtype=float)


def peak_table(signal, prominence=80.0):
    net = signal - bkg
    inds, props = find_peaks(net, prominence=prominence, distance=5)
    widths, heights, left, right = peak_widths(net, inds, rel_height=0.5)
    step = float(np.median(np.diff(x)))
    rows = []
    for i, ind in enumerate(inds):
        rows.append(
            {
                "position": float(x[ind]),
                "height": float(net[ind]),
                "prominence": float(props["prominences"][i]),
                "fwhm": float(widths[i] * step),
                "left_half_width": float((ind - left[i]) * step),
                "right_half_width": float((right[i] - ind) * step),
            }
        )
    return rows


obs = peak_table(yobs)
calc = peak_table(ycalc)

# Isolated, high-prominence representatives distributed over the full range.
selected = []
for low, high in ((10, 30), (30, 55), (55, 80), (80, 101)):
    candidates = [row for row in obs if low <= row["position"] < high]
    candidates.sort(key=lambda row: row["prominence"], reverse=True)
    for row in candidates[:5]:
        nearest = min(calc, key=lambda c: abs(c["position"] - row["position"]))
        selected.append({"observed": row, "calculated": nearest})

refl = {}
for phase, block in hist.data.get("Reflection Lists", {}).items():
    arr = np.asarray(block.get("RefList", []))
    refl[phase] = {
        "shape": list(arr.shape),
        "first_rows": arr[:5, : min(arr.shape[1], 12)].tolist() if arr.ndim == 2 else [],
    }

residual = yobs - ycalc
top = []
for ind in np.argsort(np.abs(residual))[-30:][::-1]:
    top.append({"position": float(x[ind]), "residual": float(residual[ind])})

print(json.dumps({"selected_peaks": selected, "reflection_layout": refl, "top_residual_points": top}, indent=2))
