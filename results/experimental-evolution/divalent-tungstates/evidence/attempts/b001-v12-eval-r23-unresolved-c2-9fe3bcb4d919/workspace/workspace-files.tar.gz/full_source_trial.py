#!/usr/bin/env python3
"""Full-inventory source challenge with matched profile/intensity elaboration."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from three_phase_trials import neutralize, refine, snapshot


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("prefix", type=Path)
    parser.add_argument("calcium_tungstate", type=Path)
    parser.add_argument("tungsten_oxide", type=Path)
    parser.add_argument("calcium_rich", type=Path)
    parser.add_argument("--texture-axis", nargs=3, type=int, default=(1, 1, 0))
    args = parser.parse_args()

    prefix = args.prefix.resolve()
    project = G2sc.G2Project(newgpx=str(prefix.with_suffix(".gpx")))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    project.add_phase(str(args.calcium_tungstate.resolve()), phasename="CaWO4", histograms=[hist])
    project.add_phase(str(args.tungsten_oxide.resolve()), phasename="WO3", histograms=[hist])
    project.add_phase(str(args.calcium_rich.resolve()), phasename="Ca3WO6", histograms=[hist])
    neutralize(project)

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
            }
        }
    )
    refine(project, prefix.with_name(prefix.name + "_scale"), cycles=12, repeats=1)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, prefix.with_name(prefix.name + "_cell"), cycles=20, repeats=1)

    # Cross-seed the common positive profile found in the selected inventory.
    for key, value in (("U", 74.2), ("W", 29.3), ("X", 2.30)):
        hist.InstrumentParameters[key][1] = value
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(project, prefix.with_name(prefix.name + "_profile"), cycles=20, repeats=2)

    project.phase("CaWO4").set_HAP_refinements(
        {
            "Size": {
                "type": "isotropic",
                "value": 0.1,
                "refine": True,
                "LGmix": {"value": 1.0, "refine": False},
            }
        }
    )
    refine(project, prefix.with_name(prefix.name + "_size"), cycles=20, repeats=2)
    common = snapshot(project, "common_profile")

    hap = project.phase("CaWO4").getHAPvalues(hist.name)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.25
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(args.texture_axis)
    hist.SampleParameters["SurfRoughA"] = [0.34, True]
    hist.SampleParameters["SurfRoughB"] = [0.69, True]
    refine(project, prefix.with_name(prefix.name + "_elaborated"), cycles=25, repeats=3)
    project.save(str(prefix.with_suffix(".gpx")))
    elaborated = snapshot(project, "elaborated")
    print(json.dumps([common, elaborated], indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
