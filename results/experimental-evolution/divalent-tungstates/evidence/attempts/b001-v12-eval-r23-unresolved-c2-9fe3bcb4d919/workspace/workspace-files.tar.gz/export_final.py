#!/usr/bin/env python3
"""Export all submitted artifacts from the replayed final GSAS-II project."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"
PHASES = {
    "CaWO4": ("scheelite CaWO4", "CaWO4", "phase_CaWO4.cif"),
    "WO3": ("monoclinic WO3", "WO3", "phase_WO3.cif"),
    "Ca3WO6": ("monoclinic Ca3WO6 analogue", "Ca3WO6", "phase_Ca3WO6.cif"),
    "CaO": ("rocksalt CaO", "CaO", "phase_CaO.cif"),
}


project = G2sc.G2Project(str(PROJECT))
hist = project.histogram(0)
mass = hist.ComputeMassFracs()

phase_rows = []
for phase_name, (label, formula, filename) in PHASES.items():
    phase = project.phase(phase_name)
    phase.export_CIF(str(ROOT / filename))
    cell, cell_esd = phase.get_cell_and_esd()
    fraction, fraction_esd = mass[phase_name]
    phase_rows.append(
        {
            "name": label,
            "formula": formula,
            "cif_path": filename,
            "project_path": "final.gpx",
            "weight_fraction": float(fraction),
            "weight_fraction_esd": float(fraction_esd),
            "weight_percent": float(100.0 * fraction),
            "unit_cell": {key: float(value) for key, value in cell.items()},
            "unit_cell_esd": {key: float(value) for key, value in cell_esd.items()},
        }
    )

columns = {
    "two_theta_deg": hist.getdata("X"),
    "observed_counts": hist.getdata("Yobs"),
    "calculated_counts": hist.getdata("Ycalc"),
    "difference_counts": hist.getdata("Residual"),
    "background_counts": hist.getdata("Background"),
}
with (ROOT / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(columns)
    writer.writerows(zip(*(columns[key] for key in columns)))

rvals = project.data["Covariance"]["data"]["Rvals"]
residuals = hist.residuals
result = {
    "project_path": "final.gpx",
    "profile_path": "fit.csv",
    "phases": phase_rows,
    "fit_statistics": {
        "Rwp_percent": float(residuals["wR"]),
        "Rp_percent": float(residuals["R"]),
        "R_background_percent": float(residuals["Rb"]),
        "weighted_R_background_percent": float(residuals["wRb"]),
        "Rwp_min_percent": float(residuals["wRmin"]),
        "GOF": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_variables": int(rvals["Nvars"]),
        "converged": bool(rvals["converged"]),
        "max_shift_over_esd": float(rvals["Max shft/sig"]),
        "two_theta_min_deg": float(columns["two_theta_deg"][0]),
        "two_theta_max_deg": float(columns["two_theta_deg"][-1]),
    },
}
with (ROOT / "result.json").open("w") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

print(json.dumps(result, indent=2))
