#!/usr/bin/env python3
"""Challenge one weak/watch-list phase against a converged full model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from three_phase_trials import refine, snapshot


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("cif", type=Path)
    parser.add_argument("phase_name")
    parser.add_argument("--size", action="store_true")
    parser.add_argument("--scale-only", action="store_true")
    args = parser.parse_args()

    destination = args.destination.resolve()
    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(destination))
    hist = project.histogram(0)
    phase = project.add_phase(str(args.cif.resolve()), phasename=args.phase_name, histograms=[hist])
    phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap = phase.getHAPvalues(hist.name)
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    phase.set_HAP_refinements({"Scale": True})
    refine(project, destination.with_name(destination.stem + "_scale"), cycles=20, repeats=3)
    records = [snapshot(project, "scale")]

    if args.scale_only:
        project.save(str(destination))
        print(json.dumps(records, indent=2, sort_keys=True))
        return

    phase.set_refinements({"Cell": True})
    refine(project, destination.with_name(destination.stem + "_cell"), cycles=20, repeats=3)
    records.append(snapshot(project, "cell"))

    if args.size:
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": 1.0,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )
        refine(project, destination.with_name(destination.stem + "_size"), cycles=20, repeats=3)
        records.append(snapshot(project, "size"))
    project.save(str(destination))
    print(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
