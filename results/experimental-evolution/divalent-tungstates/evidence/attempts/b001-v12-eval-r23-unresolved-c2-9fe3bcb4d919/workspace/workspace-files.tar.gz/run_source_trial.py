#!/usr/bin/env python3
"""Run a reproducible, neutral-first GSAS-II source comparison."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def snapshot(project, stage):
    hist = project.histogram(0)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    try:
        mass = {
            key: {"value": val[0], "esd": val[1]}
            for key, val in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        mass = {"error": str(exc)}
    phases = {}
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": list(hap["Size"][1]),
            "mustrain": list(hap["Mustrain"][1]),
        }
    return {
        "stage": stage,
        "Rwp": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "mass_fractions": mass,
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")
        },
        "phases": phases,
    }


def refine(project, listing, cycles=12):
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = cycles
    controls["min dM/M"] = 1e-4
    project.save()
    project.refine(printFile=str(listing))


def neutralize(project):
    hist = project.histogram(0)
    hist.data["Sample Parameters"]["Scale"][1] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in hist.data["Sample Parameters"]:
            hist.data["Sample Parameters"][key] = [0.0, False]
    for phase in project.phases():
        phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
        hap = phase.getHAPvalues(hist.name)
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        phase.set_HAP_refinements({"Scale": True})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("prefix")
    parser.add_argument("calcium_tungstate_cif", type=Path)
    parser.add_argument("tungsten_oxide_cif", type=Path)
    parser.add_argument("--ca-size", action="store_true")
    args = parser.parse_args()

    prefix = Path(args.prefix).resolve()
    project = G2sc.G2Project(newgpx=str(prefix.with_name(prefix.name + "_work.gpx")))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    project.add_phase(
        str(args.calcium_tungstate_cif.resolve()),
        phasename="CaWO4",
        histograms=[hist],
    )
    project.add_phase(
        str(args.tungsten_oxide_cif.resolve()),
        phasename="WO3",
        histograms=[hist],
    )
    neutralize(project)

    # Smooth background and positive phase scales, with all profile terms neutral.
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
            }
        }
    )
    refine(project, prefix.with_name(prefix.name + "_scale.lst"), 8)

    # One angular correction and symmetry-constrained cells.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, prefix.with_name(prefix.name + "_cell.lst"), 15)

    # Nonnegative low-dimensional common profile at its positive starting point.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(project, prefix.with_name(prefix.name + "_profile.lst"), 15)
    neutral_file = prefix.with_name(prefix.name + "_neutral.gpx")
    project.save(str(neutral_file))
    records = [snapshot(project, "neutral")]

    if args.ca_size:
        # Complementary phase broadening trial; WO3 remains neutral.
        size_file = prefix.with_name(prefix.name + "_size.gpx")
        project = G2sc.G2Project(str(neutral_file), newgpx=str(size_file))
        phase = project.phase("CaWO4")
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": 1.0,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )
        refine(project, prefix.with_name(prefix.name + "_size.lst"), 15)
        project.save(str(size_file))
        records.append(snapshot(project, "ca_size"))

    print(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
