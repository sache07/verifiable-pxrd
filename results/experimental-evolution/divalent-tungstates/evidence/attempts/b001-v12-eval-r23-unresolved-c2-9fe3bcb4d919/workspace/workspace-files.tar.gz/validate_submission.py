#!/usr/bin/env python3
"""Cross-check that submitted JSON, CIFs, profile, and GPX are identical in scope."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
result = json.loads((root / "result.json").read_text())
assert result["project_path"] == "final.gpx"
assert (root / result["project_path"]).is_file()
assert (root / result["profile_path"]).is_file()
assert (root / "report.md").is_file()

project = G2sc.G2Project(str(root / "final.gpx"))
hist = project.histogram(0)
mass = hist.ComputeMassFracs()

fractions = []
for row in result["phases"]:
    assert isinstance(row["weight_fraction"], (int, float))
    assert row["project_path"] == "final.gpx"
    assert (root / row["cif_path"]).is_file()
    assert row["formula"] in mass
    assert np.isclose(row["weight_fraction"], mass[row["formula"]][0], atol=1e-12)
    fractions.append(row["weight_fraction"])
assert np.isclose(sum(fractions), 1.0, atol=1e-12)

fit = np.loadtxt(root / "fit.csv", delimiter=",", skiprows=1)
expected = np.column_stack(
    [
        hist.getdata("X"),
        hist.getdata("Yobs"),
        hist.getdata("Ycalc"),
        hist.getdata("Residual"),
        hist.getdata("Background"),
    ]
)
assert fit.shape == expected.shape == (8301, 5)
assert np.allclose(fit, expected, rtol=0.0, atol=1e-9)
assert np.allclose(fit[:, 1] - fit[:, 2], fit[:, 3], rtol=0.0, atol=1e-9)

stats = result["fit_statistics"]
rvals = project.data["Covariance"]["data"]["Rvals"]
assert np.isclose(stats["Rwp_percent"], hist.residuals["wR"], atol=1e-12)
assert np.isclose(stats["Rp_percent"], hist.residuals["R"], atol=1e-12)
assert np.isclose(stats["GOF"], rvals["GOF"], atol=1e-12)
assert stats["converged"] is True and rvals["converged"] is True

print(
    json.dumps(
        {
            "status": "pass",
            "phase_count": len(result["phases"]),
            "fraction_sum": sum(fractions),
            "fit_rows": int(fit.shape[0]),
            "Rwp_percent": stats["Rwp_percent"],
            "project": result["project_path"],
        },
        indent=2,
    )
)
