#!/usr/bin/env python3
"""Add the Ca3WO6 analogue to a converged two-phase source checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from three_phase_trials import refine, snapshot


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("ca3wo6", type=Path)
    parser.add_argument("--texture-axis", nargs=3, type=int, default=(1, 1, 0))
    args = parser.parse_args()

    destination = args.destination.resolve()
    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(destination))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(args.ca3wo6.resolve()), phasename="Ca3WO6", histograms=[hist]
    )
    phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap = phase.getHAPvalues(hist.name)
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    phase.set_HAP_refinements({"Scale": True})

    refine(project, destination.with_name(destination.stem + "_scale"), cycles=20, repeats=2)
    phase.set_refinements({"Cell": True})
    refine(project, destination.with_name(destination.stem + "_cell"), cycles=20, repeats=3)

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
            }
        }
    )
    refine(project, destination.with_name(destination.stem + "_bg8"), cycles=20, repeats=2)
    common = snapshot(project, "full_common")

    hap = project.phase("CaWO4").getHAPvalues(hist.name)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.25
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(args.texture_axis)
    hist.SampleParameters["SurfRoughA"] = [0.34, True]
    hist.SampleParameters["SurfRoughB"] = [0.69, True]
    refine(project, destination.with_name(destination.stem + "_elaborated"), cycles=25, repeats=3)
    project.save(str(destination))
    elaborated = snapshot(project, "full_elaborated")
    print(json.dumps([common, elaborated], indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
