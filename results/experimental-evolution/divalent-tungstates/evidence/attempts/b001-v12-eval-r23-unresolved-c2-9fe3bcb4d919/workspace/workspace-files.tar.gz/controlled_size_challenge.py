#!/usr/bin/env python3
"""Re-converge a phase-size removal in stages without letting weak cells run away."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from three_phase_trials import refine, snapshot


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("destination", type=Path)
parser.add_argument("phase")
args = parser.parse_args()

destination = args.destination.resolve()
project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(destination))
hist = project.histogram(0)
phase = project.phase(args.phase)

# Make the challenged term genuinely neutral while retaining all saved nuisance
# values. Staging prevents the very weak CaO cell from compensating for the
# deliberately large CaWO4 profile mismatch.
phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
hap = phase.getHAPvalues(hist.name)
hap["Size"][2] = [False for _ in hap["Size"][2]]
hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]

for item in project.phases():
    item.clear_refinements({"Cell": True})
hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X"]})
refine(project, destination.with_name(destination.stem + "_stable"), cycles=25, repeats=2)

hist.set_refinements({"Instrument Parameters": ["Zero", "U", "W", "X"]})
refine(project, destination.with_name(destination.stem + "_profile"), cycles=25, repeats=2)

for item in project.phases():
    if item.name != "CaO":
        item.set_refinements({"Cell": True})
refine(project, destination.with_name(destination.stem + "_cells"), cycles=25, repeats=2)

project.save(str(destination))
print(json.dumps(snapshot(project, "controlled_size_off"), indent=2, sort_keys=True))
