#!/usr/bin/env python3
"""Create an isovalent structural analogue from a CIF parent."""

from __future__ import annotations

import argparse

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("parent")
    parser.add_argument("output")
    parser.add_argument("--replace", action="append", required=True)
    args = parser.parse_args()

    mapping = {}
    for item in args.replace:
        old, new = item.split("=", 1)
        mapping[old] = new

    structure = Structure.from_file(args.parent)
    structure.replace_species(mapping)
    CifWriter(structure, symprec=0.01, refine_struct=False).write_file(args.output)


if __name__ == "__main__":
    main()
