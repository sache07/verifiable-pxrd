#!/usr/bin/env python3
"""Reproducible replay and phase-broadening trials for the three-phase model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def snapshot(project: G2sc.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    mass = {}
    for key, value in hist.ComputeMassFracs().items():
        mass[key] = {"value": value[0], "esd": value[1]}
    phases = {}
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": list(hap["Scale"]),
            "size": list(hap["Size"][1]),
            "size_flags": list(hap["Size"][2]),
            "mustrain": list(hap["Mustrain"][1]),
            "mustrain_flags": list(hap["Mustrain"][2]),
            "preferred_orientation": list(hap["Pref.Ori."][:4]),
        }
    return {
        "stage": stage,
        "Rwp": hist.get_wR(),
        "Rp": rvals.get("Rwp"),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "mass_fractions": mass,
        "instrument": {
            key: list(hist.InstrumentParameters[key])
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")
        },
        "sample": {
            key: hist.data["Sample Parameters"].get(key)
            for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "phases": phases,
    }


def refine(project: G2sc.G2Project, listing: Path, cycles: int = 25, repeats: int = 2):
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = cycles
    controls["min dM/M"] = 1e-5
    for repeat in range(repeats):
        project.save()
        project.refine(printFile=str(listing.with_name(f"{listing.stem}_{repeat + 1}.lst")))


def neutralize(project: G2sc.G2Project):
    hist = project.histogram(0)
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in hist.data["Sample Parameters"]:
            hist.data["Sample Parameters"][key] = [0.0, False]
    for phase in project.phases():
        phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
        hap = phase.getHAPvalues(hist.name)
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False


def set_trial(project: G2sc.G2Project, phase_name: str, mode: str):
    phase = project.phase(phase_name)
    if mode in ("size", "combined"):
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": 1.0,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )
    if mode in ("strain", "combined"):
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "isotropic",
                    "value": 1000.0,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--stage", default="replay")
    parser.add_argument("--neutral", action="store_true")
    parser.add_argument("--phase")
    parser.add_argument("--mode", choices=("size", "strain", "combined"))
    parser.add_argument("--repeats", type=int, default=2)
    args = parser.parse_args()

    source = args.source.resolve()
    destination = args.destination.resolve()
    project = G2sc.G2Project(str(source), newgpx=str(destination))
    if args.neutral:
        neutralize(project)
    if args.phase or args.mode:
        if not args.phase or not args.mode:
            parser.error("--phase and --mode must be supplied together")
        set_trial(project, args.phase, args.mode)
    refine(project, destination.with_suffix(""), repeats=args.repeats)
    project.save(str(destination))
    print(json.dumps(snapshot(project, args.stage), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
