#!/usr/bin/env python3
"""Inspect whether a weak trial phase has multiple non-coincident families."""

from __future__ import annotations

import json
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2sc


base = G2sc.G2Project(sys.argv[1])
trial = G2sc.G2Project(sys.argv[2])
phase_name = sys.argv[3]
hb = base.histogram(0)
ht = trial.histogram(0)
x = np.asarray(hb.getdata("X"), dtype=float)
rb = np.asarray(hb.getdata("Residual"), dtype=float)
rt = np.asarray(ht.getdata("Residual"), dtype=float)

target = np.asarray(ht.data["Reflection Lists"][phase_name]["RefList"], dtype=float)
other_reflections = []
for name, block in ht.data["Reflection Lists"].items():
    if name == phase_name:
        continue
    arr = np.asarray(block["RefList"], dtype=float)
    for other in arr:
        other_reflections.append((name, other))
other_positions = np.asarray([other[1][5] for other in other_reflections])

rows = []
for refl in target:
    pos = float(refl[5])
    if pos < x[0] or pos > x[-1]:
        continue
    use = np.abs(x - pos) <= 0.18
    nearest_index = int(np.argmin(np.abs(other_positions - pos))) if len(other_positions) else None
    nearest = float(abs(other_positions[nearest_index] - pos)) if nearest_index is not None else None
    nearest_phase = other_reflections[nearest_index][0] if nearest_index is not None else None
    nearest_refl = other_reflections[nearest_index][1] if nearest_index is not None else None
    rows.append(
        {
            "hkl": [int(round(v)) for v in refl[:3]],
            "multiplicity": float(refl[3]),
            "position": pos,
            "nearest_other_reflection_deg": nearest,
            "nearest_other_phase": nearest_phase,
            "nearest_other_hkl": [int(round(v)) for v in nearest_refl[:3]] if nearest_refl is not None else None,
            "nearest_other_intensity_proxy": float(nearest_refl[9]) if nearest_refl is not None else None,
            "trial_calc_intensity_proxy": float(refl[9]),
            "base_integrated_residual": float(np.trapz(rb[use], x[use])),
            "trial_integrated_residual": float(np.trapz(rt[use], x[use])),
            "base_peak_residual": float(np.max(rb[use])),
            "trial_peak_residual": float(np.max(rt[use])),
        }
    )

rows.sort(key=lambda row: row["trial_calc_intensity_proxy"], reverse=True)
print(json.dumps(rows[:20], indent=2))
