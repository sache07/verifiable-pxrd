#!/usr/bin/env python3
"""Print compact JSON snapshots for one or more GSAS-II projects."""

from __future__ import annotations

import json
import sys

from GSASII import GSASIIscriptable as G2sc

from three_phase_trials import snapshot


for filename in sys.argv[1:]:
    project = G2sc.G2Project(filename)
    print(json.dumps(snapshot(project, filename), sort_keys=True))
