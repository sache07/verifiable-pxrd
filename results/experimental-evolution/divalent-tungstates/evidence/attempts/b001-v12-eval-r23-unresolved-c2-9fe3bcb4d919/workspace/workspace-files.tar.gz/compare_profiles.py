#!/usr/bin/env python3
"""Compare regional weighted residuals for converged GSAS-II projects."""

from __future__ import annotations

import json
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2sc


out = []
for filename in sys.argv[1:]:
    project = G2sc.G2Project(filename)
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("X"), dtype=float)
    yo = np.asarray(hist.getdata("Yobs"), dtype=float)
    yc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    w = np.asarray(hist.getdata("Yweight"), dtype=float)
    row = {"project": filename, "Rwp": hist.get_wR(), "regions": {}}
    for label, low, high in (
        ("low", 9.9, 30.0),
        ("middle", 30.0, 60.0),
        ("high", 60.0, 100.1),
    ):
        use = (x >= low) & (x < high)
        rwp = 100.0 * np.sqrt(np.sum(w[use] * (yo[use] - yc[use]) ** 2) / np.sum(w[use] * yo[use] ** 2))
        row["regions"][label] = {
            "Rwp": float(rwp),
            "mean_residual": float(np.mean(yo[use] - yc[use])),
            "mean_abs_residual": float(np.mean(np.abs(yo[use] - yc[use]))),
        }
    row["fractions"] = {
        key: value[0] for key, value in hist.ComputeMassFracs().items()
    }
    out.append(row)

print(json.dumps(out, indent=2))
