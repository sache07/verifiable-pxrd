#!/usr/bin/env python3
"""Run a reversible GSAS-II nuisance/profile trial from a saved checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from three_phase_trials import refine, snapshot


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--background", type=int)
    group.add_argument("--polarization", action="store_true")
    group.add_argument("--roughness", action="store_true")
    group.add_argument("--roughness-off", action="store_true")
    group.add_argument("--roughness-a0", action="store_true")
    group.add_argument("--roughness-b-fixed", type=float)
    group.add_argument("--shl", action="store_true")
    group.add_argument("--texture", nargs=4, metavar=("PHASE", "H", "K", "L"))
    group.add_argument("--texture-off", metavar="PHASE")
    group.add_argument("--uniaxial-size", nargs=4, metavar=("PHASE", "H", "K", "L"))
    group.add_argument("--size-off", metavar="PHASE")
    parser.add_argument("--repeats", type=int, default=2)
    args = parser.parse_args()

    destination = args.destination.resolve()
    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(destination))
    hist = project.histogram(0)
    label = "trial"

    if args.background is not None:
        hist.set_refinements(
            {
                "Background": {
                    "type": "chebyschev-1",
                    "refine": True,
                    "no. coeffs": args.background,
                }
            }
        )
        label = f"background_{args.background}"
    elif args.polarization:
        hist.InstrumentParameters["Polariz."][1] = 0.5
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        label = "polarization"
    elif args.roughness:
        hist.SampleParameters["SurfRoughA"] = [0.5, True]
        hist.SampleParameters["SurfRoughB"] = [0.02, True]
        label = "roughness"
    elif args.roughness_off:
        hist.SampleParameters["SurfRoughA"] = [0.0, False]
        hist.SampleParameters["SurfRoughB"] = [0.0, False]
        label = "roughness_off"
    elif args.roughness_a0:
        hist.SampleParameters["SurfRoughA"] = [0.0, False]
        hist.SampleParameters["SurfRoughB"] = [0.2, True]
        label = "roughness_a0"
    elif args.roughness_b_fixed is not None:
        hist.SampleParameters["SurfRoughA"] = [0.3, True]
        hist.SampleParameters["SurfRoughB"] = [args.roughness_b_fixed, False]
        label = f"roughness_b_fixed_{args.roughness_b_fixed}"
    elif args.shl:
        hist.InstrumentParameters["SH/L"][1] = 0.002
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        label = "shl"
    elif args.texture:
        phase_name, h, k, l = args.texture
        hap = project.phase(phase_name).getHAPvalues(hist.name)
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = [int(h), int(k), int(l)]
        label = f"texture_{phase_name}_{h}{k}{l}"
    elif args.texture_off:
        hap = project.phase(args.texture_off).getHAPvalues(hist.name)
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        label = f"texture_off_{args.texture_off}"
    elif args.uniaxial_size:
        phase_name, h, k, l = args.uniaxial_size
        phase = project.phase(phase_name)
        old = phase.getHAPvalues(hist.name)["Size"][1][0]
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "uniaxial",
                    "direction": [int(h), int(k), int(l)],
                    "value": old,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )
        label = f"uniaxial_size_{phase_name}_{h}{k}{l}"
    elif args.size_off:
        phase = project.phase(args.size_off)
        phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
        hap = phase.getHAPvalues(hist.name)
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        label = f"size_off_{args.size_off}"

    refine(project, destination.with_suffix(""), cycles=25, repeats=args.repeats)
    project.save(str(destination))
    result = snapshot(project, label)
    result["background"] = hist.Background
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
