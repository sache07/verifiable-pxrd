#!/usr/bin/env python3
"""Rechallenge plausible weak Mn-W-O and precursor phases under the clean profile."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_workflow import ROOT
from two_phase_develop import summarize
from two_phase_trials import correlations


CIF_ROOT = Path(
    "<RUN>/"
    "resources/b001-c04/cif"
)
CANDIDATES = {
    "Mn3WO6_R3bar": "2002703",
    "Mn3O4_I41amd": "9001963",
    "Mn3O4_Pbcm": "1541183",
    "Mn2O3_Ia3bar": "1514230",
    "Mn2O3_Pbca": "1514103",
    "MnO_Fm3m": "1514108",
}


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][:] = [0.1, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def run_trial(name: str, cod_id: str) -> dict:
    filename = ROOT / f"watch_{name}.gpx"
    project = G2sc.G2Project(
        gpxfile=str(ROOT / "accepted_intensity.gpx"), newgpx=str(filename)
    )
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cif_path(cod_id)),
        phasename=name,
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize(phase, hist)
    phase.set_refinements({"Cell": False})
    project.set_Controls("parmMin", 0.0, variable="2:0:Scale")
    project.set_Controls("cycles", 10)
    project.save()
    project.refine()
    scale_stage = summarize(project, f"{name} scale first")
    candidate_scale = project.phase(2).data["Histograms"][hist.name]["Scale"][0]

    # Refine the candidate cell only when its positive scale survives scale-first.
    if candidate_scale > 0.001 and project.histogram(0).get_wR() < 2.9167:
        project.phase(2).set_refinements({"Cell": True})
    project.refine()
    project.save()
    project = G2sc.G2Project(str(filename))
    project.refine()
    project.save()
    final = summarize(project, f"{name} replay")
    final["high_correlations"] = correlations(project)
    final["candidate_scale"] = project.phase(2).data["Histograms"][
        project.histogram(0).name
    ]["Scale"]
    final["candidate_cell_refined"] = project.phase(2).data["General"]["Cell"][0]
    return {
        "candidate": name,
        "cod_id": cod_id,
        "source_cif": str(cif_path(cod_id)),
        "scale_stage": scale_stage,
        "final": final,
    }


def run() -> None:
    G2sc.SetPrintLevel("warn")
    results = []
    for name, cod_id in CANDIDATES.items():
        row = run_trial(name, cod_id)
        results.append(row)
        final = row["final"]
        print(
            name,
            "scale-stage Rwp=",
            row["scale_stage"]["Rwp_percent"],
            "replay Rwp=",
            final["Rwp_percent"],
            "scale=",
            final["candidate_scale"],
            "fractions=",
            final["mass_fractions"],
            "cell refined=",
            final["candidate_cell_refined"],
            flush=True,
        )
    (ROOT / "watchlist_trials.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    run()
