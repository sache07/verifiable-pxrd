#!/usr/bin/env python3
"""Read-only CIF parse and nearest-neighbour geometry check."""

from pathlib import Path

from pymatgen.core import Structure


FILES = [
    Path("phase_1_MnWO4.cif"),
    Path("phase_2_WO3.cif"),
    Path("phase_3_Mn3O4.cif"),
]


for filename in FILES:
    structure = Structure.from_file(filename)
    print(filename, structure.composition.reduced_formula, structure.get_space_group_info())
    for element in sorted({site.specie.symbol for site in structure if site.specie.symbol != "O"}):
        first_shells = []
        for site in structure:
            if site.specie.symbol != element:
                continue
            distances = sorted(
                neighbor.nn_distance
                for neighbor in structure.get_neighbors(site, 2.6)
                if neighbor.specie.symbol == "O"
            )
            if distances:
                first_shells.append(distances[:6])
        flattened = [distance for shell in first_shells for distance in shell]
        print(
            f"  {element}-O first-shell range: "
            f"{min(flattened):.4f}-{max(flattened):.4f} A"
        )
