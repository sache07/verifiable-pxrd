#!/usr/bin/env python3
"""Test coherent intensity corrections and structural coordinates."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc

from refine_workflow import ROOT
from two_phase_develop import summarize
from two_phase_trials import correlations


BASE = ROOT / "post_u_w_x.gpx"


def branch(name: str) -> G2sc.G2Project:
    p = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(ROOT / f"int_{name}.gpx"))
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    p.set_Controls("cycles", 12)
    p.save()
    return p


def atom_summary(p: G2sc.G2Project) -> list[dict]:
    result = []
    for ph in p.phases():
        result.append(
            {
                "phase": ph.name,
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": atom.coordinates,
                        "occupancy": atom.occupancy,
                        "uiso": atom.uiso,
                        "flags": atom.refinement_flags,
                    }
                    for atom in ph.atoms()
                ],
            }
        )
    return result


def converge(p: G2sc.G2Project, label: str) -> dict:
    p.refine()
    p.save()
    p = G2sc.G2Project(str(p.filename))
    p.refine()
    p.save()
    result = summarize(p, label)
    result["high_correlations"] = correlations(p)
    result["atoms"] = atom_summary(p)
    result["sample_parameters"] = p.histogram(0).data["Sample Parameters"]
    result["polarization"] = p.histogram(0).data["Instrument Parameters"][0][
        "Polariz."
    ]
    return result


def run() -> None:
    G2sc.SetPrintLevel("warn")
    results = []

    p = branch("polarization")
    p.histogram(0).data["Instrument Parameters"][0]["Polariz."][2] = True
    p.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    p.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    results.append(converge(p, "effective polarization refined"))

    p = branch("roughness")
    sample = p.histogram(0).data["Sample Parameters"]
    sample["SurfRoughA"][:] = [0.1, True]
    sample["SurfRoughB"][:] = [0.1, True]
    p.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
    p.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
    p.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    p.set_Controls("parmMax", 10.0, variable=":0:SurfRoughB")
    results.append(converge(p, "Suortti roughness A/B refined"))

    p = branch("background6")
    bkg = p.histogram(0).data["Background"][0]
    bkg[:] = [bkg[0], True, 6] + bkg[3:9]
    results.append(converge(p, "six-term Chebyshev background"))

    p = branch("background10")
    bkg = p.histogram(0).data["Background"][0]
    bkg[:] = [bkg[0], True, 10] + bkg[3:] + [0.0, 0.0]
    results.append(converge(p, "ten-term Chebyshev background"))

    p = branch("mn_coordinates")
    p.phase(0).set_refinements({"Atoms": {"all": "X"}})
    results.append(converge(p, "MnWO4 fractional coordinates refined"))

    p = branch("wo3_coordinates")
    p.phase(1).set_refinements({"Atoms": {"all": "X"}})
    results.append(converge(p, "WO3 fractional coordinates refined"))

    (ROOT / "intensity_trials.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )
    for row in results:
        sample = row["sample_parameters"]
        print(
            row["label"],
            "Rwp=",
            row["Rwp_percent"],
            "fraction=",
            row["mass_fractions"],
            "polarization=",
            row["polarization"],
            "rough=",
            sample.get("SurfRoughA"),
            sample.get("SurfRoughB"),
            "corr=",
            row["high_correlations"][:5],
        )


if __name__ == "__main__":
    run()
