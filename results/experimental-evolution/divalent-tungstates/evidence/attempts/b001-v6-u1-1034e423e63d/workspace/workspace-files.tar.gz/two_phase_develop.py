#!/usr/bin/env python3
"""Build the coherent two-phase baseline with the transformed WO3 parent."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc

from refine_workflow import ROOT


def summarize(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    covariance = project.data.get("Covariance", {}).get("data", {})
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "composition": phase.composition,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    try:
        fractions = hist.ComputeMassFracs()
    except Exception as error:
        fractions = {"error": str(error)}
    return {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "residuals": hist.data["data"][0],
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "converged": covariance.get("Rvals", {}).get("converged"),
        "message": covariance.get("Rvals", {}).get("msg"),
        "zero": inst["Zero"],
        "profile": {
            key: inst[key] for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "background": hist.data["Background"][0],
        "phases": phases,
        "mass_fractions": fractions,
        "vary_list": covariance.get("varyList", []),
    }


def neutral_wo3(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][:] = [5.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [0.02, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def run() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(
        gpxfile=str(ROOT / "inventory_base.gpx"),
        newgpx=str(ROOT / "two_phase_base.gpx"),
    )
    hist = project.histogram(0)
    wo3 = project.add_phase(
        str(ROOT / "initial_WO3.cif"),
        phasename="WO3_monoclinic",
        histograms=[hist],
        fmthint="CIF",
    )
    neutral_wo3(wo3, hist)
    wo3.set_refinements({"Cell": False})
    project.set_Controls("parmMin", 0.0, variable="1:0:Scale")
    project.set_Controls("cycles", 10)
    project.save()
    audit = []

    project.refine()
    audit.append(summarize(project, "WO3 scale first"))

    project.phase(1).set_refinements({"Cell": True})
    project.refine()
    audit.append(summarize(project, "all scales, zero, cells, common profile"))
    project.save()
    project = G2sc.G2Project(str(ROOT / "two_phase_base.gpx"))
    project.refine()
    audit.append(summarize(project, "full-range replay"))
    project.save()

    (ROOT / "two_phase_develop.json").write_text(
        json.dumps(audit, indent=2, default=float) + "\n"
    )
    for row in audit:
        print(
            row["label"],
            "Rwp=",
            row["Rwp_percent"],
            "fractions=",
            row["mass_fractions"],
            "zero=",
            row["zero"],
            "profile=",
            row["profile"],
        )


if __name__ == "__main__":
    run()
