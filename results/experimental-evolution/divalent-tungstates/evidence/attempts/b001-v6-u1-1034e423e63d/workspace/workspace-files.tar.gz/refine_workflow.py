#!/usr/bin/env python3
"""Develop and audit a residual-led GSAS-II refinement for MnWO4."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "working.gpx"


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hap = phase.data["Histograms"][hist.name]
    covariance = project.data.get("Covariance", {}).get("data", {})
    return {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "histogram_residuals": {
            key: value
            for key, value in hist.data["data"][0].items()
            if key in {"R", "wR", "Rb", "wRb", "Durbin-Watson", "Nobs"}
        },
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "cell": phase.get_cell(),
        "sample_shift_micrometre": sample.get("Shift", [None])[0],
        "instrument": {
            key: inst[key][1]
            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
        },
        "hap_scale": hap["Scale"][0],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "vary_list": covariance.get("varyList", []),
        "sigmas": covariance.get("sig", []).tolist()
        if hasattr(covariance.get("sig", []), "tolist")
        else covariance.get("sig", []),
    }


def neutralize_hap(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1000.0, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"][:] = [0.0, False]
    for term in hap["Babinet"].values():
        term[:] = [0.0, False]


def build_project() -> tuple[G2sc.G2Project, G2sc.G2PwdrData, G2sc.G2Phase]:
    project = G2sc.G2Project(newgpx=str(PROJECT))
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
        fmthint="Topas",
    )
    phase = project.add_phase(
        str(ROOT / "initial_MnWO4.cif"),
        phasename="MnWO4_wolframite",
        histograms=[hist],
        fmthint="CIF",
    )
    hist.Limits("lower", 9.90343322)
    hist.Limits("upper", 100.09455322)

    # Smooth low-order baseline. Coefficients are only starting values.
    hist.data["Background"][0][:] = [
        "chebyschev-1",
        True,
        8,
        1750.0,
        -850.0,
        250.0,
        -120.0,
        60.0,
        -30.0,
        15.0,
        -5.0,
    ]
    sample = hist.data["Sample Parameters"]
    sample["Scale"][1] = False
    sample["Shift"][:] = [0.0, False]
    sample["Transparency"][:] = [0.0, False]
    sample["SurfRoughA"][:] = [0.0, False]
    sample["SurfRoughB"][:] = [0.0, False]

    neutralize_hap(phase, hist)
    phase.data["Histograms"][hist.name]["Scale"][:] = [1.0, True]
    project.set_Controls("cycles", 8)
    project.set_Controls("parmMin", 0.0, variable=":0:W")
    project.set_Controls("parmMin", 0.0, variable=":0:X")
    project.set_Controls("parmMin", 0.0001, variable=":0:SH/L")
    project.set_Controls("parmMin", -1000.0, variable=":0:Shift")
    project.set_Controls("parmMax", 1000.0, variable=":0:Shift")
    project.save()
    return project, hist, phase


def run() -> None:
    G2sc.SetPrintLevel("warn")
    project, hist, phase = build_project()
    audit: list[dict] = []

    # Establish scale and a smooth background with all structural/profile terms fixed.
    project.refine()
    audit.append(snapshot(project, "scale_background"))

    # Reconcile all peak positions with one specimen-displacement correction and cell.
    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.refine()
    audit.append(snapshot(project, "cell_shift"))

    # Establish a nonnegative common Gaussian/Lorentzian profile (W and X only).
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    project.refine()
    audit.append(snapshot(project, "common_W_X"))

    # Replay once from disk over the full range.
    project.save()
    project = G2sc.G2Project(str(PROJECT))
    project.refine()
    audit.append(snapshot(project, "full_range_replay"))
    project.save()

    (ROOT / "refinement_audit.json").write_text(
        json.dumps(audit, indent=2, default=float) + "\n"
    )

    hist = project.histogram(0)
    phase = project.phase(0)
    print(json.dumps(audit[-1], indent=2, default=float))
    print("background", hist.data["Background"][0])
    print("sample", hist.data["Sample Parameters"])
    print("atoms")
    for atom in phase.atoms():
        print(
            atom.label,
            atom.element,
            atom.coordinates,
            atom.occupancy,
            atom.uiso,
            atom.refinement_flags,
        )


if __name__ == "__main__":
    run()
