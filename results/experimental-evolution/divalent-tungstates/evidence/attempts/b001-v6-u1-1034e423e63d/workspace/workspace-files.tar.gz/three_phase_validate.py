#!/usr/bin/env python3
"""Validate the three-phase model and re-challenge the residual inventory."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_workflow import ROOT
from two_phase_develop import summarize
from two_phase_trials import correlations


BASE = ROOT / "watch_Mn3O4_I41amd.gpx"
CIF_ROOT = Path(
    "<RUN>/"
    "resources/b001-c04/cif"
)
CANDIDATES = {
    "Mn3WO6_R3bar": "2002703",
    "Mn3O4_Pbcm": "1541183",
    "Mn2O3_Ia3bar": "1514230",
    "Mn2O3_Pbca": "1514103",
    "MnO_Fm3m": "1514108",
}
TEXTURE_AXES = {
    "001": [0, 0, 1],
    "100": [1, 0, 0],
    "110": [1, 1, 0],
    "101": [1, 0, 1],
}


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def branch(tag: str, base: Path = BASE) -> G2sc.G2Project:
    filename = ROOT / f"three_{tag}.gpx"
    project = G2sc.G2Project(gpxfile=str(base), newgpx=str(filename))
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 12)
    project.save()
    return project


def converge(project: G2sc.G2Project, label: str) -> tuple[G2sc.G2Project, dict]:
    # Reopen/replay until parameter shifts are small, with a finite ceiling so
    # deliberately poor ablation models cannot hold up the audit indefinitely.
    for _ in range(5):
        project.refine()
        project.save()
        shift = project.data.get("Covariance", {}).get("data", {}).get(
            "Rvals", {}
        ).get("Max shft/sig", float("inf"))
        if shift is not None and shift < 0.1:
            break
        project = G2sc.G2Project(str(project.filename))
    result = summarize(project, label)
    result["high_correlations"] = correlations(project)
    result["max_shift_esd"] = project.data["Covariance"]["data"]["Rvals"].get(
        "Max shft/sig"
    )
    return project, result


def neutralize(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][:] = [0.1, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def candidate_fraction(project: G2sc.G2Project, phase_index: int) -> float:
    fractions = project.histogram(0).ComputeMassFracs()
    if isinstance(fractions, dict):
        phase = project.phase(phase_index)
        for key in (phase.name, phase_index, str(phase_index)):
            if key in fractions:
                value = fractions[key]
                if isinstance(value, (list, tuple)):
                    value = value[0]
                return float(value)
    if isinstance(fractions, (list, tuple)):
        return float(fractions[phase_index])
    return 0.0


def run() -> None:
    G2sc.SetPrintLevel("warn")
    results: dict[str, object] = {}

    baseline = branch("baseline")
    baseline, base_row = converge(baseline, "three-phase full-range replay")
    results["baseline"] = base_row
    base_rwp = base_row["Rwp_percent"]
    print("baseline", base_rwp, base_row["mass_fractions"], flush=True)

    broadening = []
    project = branch("mn3o4_size", Path(baseline.filename))
    hist = project.histogram(0)
    hap = project.phase(2).data["Histograms"][hist.name]
    hap["Size"][1][0] = 1.0
    hap["Size"][2][0] = True
    project.set_Controls("parmMin", 0.001, variable="2:0:Size;i")
    project.set_Controls("parmMax", 10.0, variable="2:0:Size;i")
    project, row = converge(project, "Mn3O4 isotropic size challenge")
    broadening.append(row)
    accepted_base = Path(project.filename)
    accepted_rwp = row["Rwp_percent"]
    print("Mn3O4 size", row["Rwp_percent"], row["phases"][2]["size"], flush=True)

    project = branch("mn3o4_strain", Path(baseline.filename))
    hist = project.histogram(0)
    hap = project.phase(2).data["Histograms"][hist.name]
    hap["Mustrain"][1][0] = 100.0
    hap["Mustrain"][2][0] = True
    project.set_Controls("parmMin", 0.0, variable="2:0:Mustrain;i")
    project.set_Controls("parmMax", 10000.0, variable="2:0:Mustrain;i")
    project, row = converge(project, "Mn3O4 isotropic strain challenge")
    broadening.append(row)
    print(
        "Mn3O4 strain", row["Rwp_percent"], row["phases"][2]["mustrain"], flush=True
    )

    project = branch("mn3o4_size_strain", accepted_base)
    hist = project.histogram(0)
    hap = project.phase(2).data["Histograms"][hist.name]
    hap["Mustrain"][1][0] = 100.0
    hap["Mustrain"][2][0] = True
    project.set_Controls("parmMin", 0.0, variable="2:0:Mustrain;i")
    project.set_Controls("parmMax", 10000.0, variable="2:0:Mustrain;i")
    project, row = converge(project, "Mn3O4 isotropic size + strain challenge")
    broadening.append(row)
    print(
        "Mn3O4 size+strain",
        row["Rwp_percent"],
        row["phases"][2]["size"],
        row["phases"][2]["mustrain"],
        flush=True,
    )
    results["broadening"] = broadening

    # Isotropic size gives the best one-term model. All subsequent challenges
    # therefore start from that rebuilt common profile; the combined branch is
    # retained only as a diagnostic for covariance/over-parameterization.
    accepted = branch("accepted_size", accepted_base)
    accepted, accepted_row = converge(accepted, "accepted three-phase size replay")
    results["accepted_baseline"] = accepted_row
    accepted_base = Path(accepted.filename)
    accepted_rwp = accepted_row["Rwp_percent"]

    ablations = []
    for term in ("U", "W", "X"):
        project = branch(f"no_{term.lower()}", accepted_base)
        inst = project.histogram(0).data["Instrument Parameters"][0]
        inst[term][:] = [0.0, 0.0, False]
        project, row = converge(project, f"common profile without {term}")
        ablations.append(row)
        print("without", term, row["Rwp_percent"], flush=True)
    results["common_profile_ablations"] = ablations

    texture = []
    for tag, axis in TEXTURE_AXES.items():
        project = branch(f"mn3o4_texture_{tag}", accepted_base)
        hist = project.histogram(0)
        hap = project.phase(2).data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
        project, row = converge(project, f"Mn3O4 MD {tag}")
        row["MD"] = project.phase(2).data["Histograms"][hist.name]["Pref.Ori."]
        texture.append(row)
        print("texture", tag, row["Rwp_percent"], row["MD"][1], flush=True)
    results["texture"] = texture

    watchlist = []
    for name, cod_id in CANDIDATES.items():
        project = branch(f"watch_{name}", accepted_base)
        hist = project.histogram(0)
        phase = project.add_phase(
            str(cif_path(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        neutralize(phase, hist)
        phase.set_refinements({"Cell": False})
        project.set_Controls("parmMin", 0.0, variable="3:0:Scale")
        project.refine()
        project.save()
        scale_stage = summarize(project, f"{name} scale-first rechallenge")
        fraction = candidate_fraction(project, 3)

        # A small but coherent positive phase may merit a cell challenge. A phase
        # that does not improve Rwp by 0.005 percentage point stays source-fixed.
        if fraction > 0.001 and scale_stage["Rwp_percent"] < accepted_rwp - 0.005:
            phase.set_refinements({"Cell": True})
        project, final = converge(project, f"{name} replay rechallenge")
        final["candidate_fraction"] = candidate_fraction(project, 3)
        final["candidate_scale"] = project.phase(3).data["Histograms"][
            project.histogram(0).name
        ]["Scale"]
        final["candidate_cell_refined"] = project.phase(3).data["General"]["Cell"][0]
        watchlist.append(
            {
                "candidate": name,
                "cod_id": cod_id,
                "source_cif": str(cif_path(cod_id)),
                "scale_stage": scale_stage,
                "final": final,
            }
        )
        print(
            "watch",
            name,
            final["Rwp_percent"],
            final["candidate_fraction"],
            final["candidate_scale"],
            flush=True,
        )
    results["watchlist"] = watchlist

    (ROOT / "three_phase_validate.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    run()
