#!/usr/bin/env python3
"""Branch profile and angular-correction trials from the common baseline."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_workflow import ROOT, snapshot


BASE = ROOT / "working.gpx"


def branch(name: str) -> G2sc.G2Project:
    path = ROOT / f"trial_{name}.gpx"
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(path))
    project.save()
    return project


def converge(project: G2sc.G2Project, label: str) -> dict:
    project.set_Controls("cycles", 8)
    project.refine()
    project.save()
    path = Path(project.filename)
    project = G2sc.G2Project(str(path))
    project.refine()
    project.save()
    return snapshot(project, label)


def run() -> None:
    G2sc.SetPrintLevel("warn")
    results: list[dict] = []

    p = branch("shift_shl")
    h = p.histogram(0)
    h.data["Instrument Parameters"][0]["SH/L"][2] = True
    results.append(converge(p, "shift + W/X + SH/L"))

    p = branch("zero_shl")
    h = p.histogram(0)
    h.data["Sample Parameters"]["Shift"][:] = [0.0, False]
    h.data["Instrument Parameters"][0]["Zero"][:] = [0.0, 0.0, True]
    h.data["Instrument Parameters"][0]["SH/L"][2] = True
    results.append(converge(p, "zero + W/X + SH/L"))

    p = branch("shift_shl_u")
    h = p.histogram(0)
    h.data["Instrument Parameters"][0]["SH/L"][2] = True
    h.data["Instrument Parameters"][0]["U"][:] = [1.0, 1.0, True]
    p.set_Controls("parmMin", 0.0, variable=":0:U")
    results.append(converge(p, "shift + U/W/X + SH/L"))

    p = branch("shift_shl_size")
    h = p.histogram(0)
    ph = p.phase(0)
    h.data["Instrument Parameters"][0]["SH/L"][2] = True
    hap = ph.data["Histograms"][h.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2][0] = True
    results.append(converge(p, "shift + W/X + SH/L + isotropic size"))

    p = branch("shift_shl_strain")
    h = p.histogram(0)
    ph = p.phase(0)
    h.data["Instrument Parameters"][0]["SH/L"][2] = True
    hap = ph.data["Histograms"][h.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2][0] = True
    results.append(converge(p, "shift + W/X + SH/L + isotropic strain"))

    (ROOT / "profile_trials.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )
    for result in results:
        print(
            result["label"],
            "Rwp=",
            result["Rwp_percent"],
            "shift=",
            result["sample_shift_micrometre"],
            "instrument=",
            result["instrument"],
            "size=",
            result["size"][1],
            "strain=",
            result["mustrain"][1],
            "vary=",
            result["vary_list"],
        )


if __name__ == "__main__":
    run()
