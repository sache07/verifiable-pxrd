#!/usr/bin/env python3
"""Combine accepted MnWO4 coordinates with effective polarization."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc

from refine_workflow import ROOT
from two_phase_develop import summarize
from two_phase_trials import correlations


def run() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(
        gpxfile=str(ROOT / "int_mn_coordinates.gpx"),
        newgpx=str(ROOT / "accepted_intensity.gpx"),
    )
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    inst = project.histogram(0).data["Instrument Parameters"][0]
    inst["Polariz."][2] = True
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.set_Controls("cycles", 12)
    project.save()
    project.refine()
    project.save()
    project = G2sc.G2Project(str(ROOT / "accepted_intensity.gpx"))
    project.refine()
    project.save()
    result = summarize(project, "accepted coordinates + polarization")
    result["high_correlations"] = correlations(project)
    result["polarization"] = project.histogram(0).data["Instrument Parameters"][0][
        "Polariz."
    ]
    result["atoms"] = [
        {
            "phase": phase.name,
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": atom.coordinates,
                    "uiso": atom.uiso,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
        for phase in project.phases()
    ]
    (ROOT / "combined_intensity.json").write_text(
        json.dumps(result, indent=2, default=float) + "\n"
    )
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    run()
