#!/usr/bin/env python3
"""Compare common and WO3-specific profile terms from the two-phase baseline."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from refine_workflow import ROOT
from two_phase_develop import summarize


BASE = ROOT / "two_phase_base.gpx"


def new_branch(name: str) -> G2sc.G2Project:
    project = G2sc.G2Project(
        gpxfile=str(BASE), newgpx=str(ROOT / f"twotrial_{name}.gpx")
    )
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 10)
    project.save()
    return project


def correlations(project: G2sc.G2Project, cutoff: float = 0.8) -> list[dict]:
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = covariance.get("varyList", [])
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if not matrix.size:
        return []
    sd = np.sqrt(np.diag(matrix))
    corr = matrix / np.outer(sd, sd)
    result = []
    for i in range(len(names)):
        for j in range(i):
            if abs(corr[i, j]) >= cutoff:
                result.append(
                    {
                        "left": names[i],
                        "right": names[j],
                        "correlation": corr[i, j],
                    }
                )
    return sorted(result, key=lambda row: abs(row["correlation"]), reverse=True)


def converge(project: G2sc.G2Project, label: str) -> dict:
    project.refine()
    project.save()
    project = G2sc.G2Project(str(project.filename))
    project.refine()
    project.save()
    result = summarize(project, label)
    result["high_correlations"] = correlations(project)
    return result


def run() -> None:
    G2sc.SetPrintLevel("warn")
    results = []

    p = new_branch("no_shl")
    inst = p.histogram(0).data["Instrument Parameters"][0]
    inst["SH/L"][:] = [0.002, 0.002, False]
    results.append(converge(p, "X only; SH/L fixed near zero"))

    p = new_branch("w_x_shl")
    inst = p.histogram(0).data["Instrument Parameters"][0]
    inst["W"][:] = [1.0, 1.0, True]
    p.set_Controls("parmMin", 0.0, variable=":0:W")
    results.append(converge(p, "W/X + SH/L"))

    p = new_branch("u_x_shl")
    inst = p.histogram(0).data["Instrument Parameters"][0]
    inst["U"][:] = [1.0, 1.0, True]
    p.set_Controls("parmMin", 0.0, variable=":0:U")
    results.append(converge(p, "U/X + SH/L"))

    p = new_branch("wo3_size")
    h = p.histogram(0)
    hap = p.phase(1).data["Histograms"][h.name]
    hap["Size"][1][0] = 0.02
    hap["Size"][2][0] = True
    p.set_Controls("parmMin", 0.001, variable="1:0:Size;i")
    p.set_Controls("parmMax", 10.0, variable="1:0:Size;i")
    results.append(converge(p, "WO3 isotropic size refined"))

    p = new_branch("wo3_strain")
    h = p.histogram(0)
    hap = p.phase(1).data["Histograms"][h.name]
    hap["Size"][1][0] = 10.0
    hap["Size"][2][0] = False
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2][0] = True
    p.set_Controls("parmMin", 0.0, variable="1:0:Mustrain;i")
    p.set_Controls("parmMax", 10000.0, variable="1:0:Mustrain;i")
    results.append(converge(p, "WO3 isotropic strain refined; size neutral"))

    p = G2sc.G2Project(
        gpxfile=str(ROOT / "twotrial_wo3_size.gpx"),
        newgpx=str(ROOT / "twotrial_wo3_size_strain.gpx"),
    )
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    h = p.histogram(0)
    hap = p.phase(1).data["Histograms"][h.name]
    hap["Mustrain"][1][0] = 100.0
    hap["Mustrain"][2][0] = True
    p.set_Controls("parmMin", 0.0, variable="1:0:Mustrain;i")
    p.set_Controls("parmMax", 10000.0, variable="1:0:Mustrain;i")
    p.save()
    results.append(converge(p, "WO3 isotropic size + strain"))

    (ROOT / "two_phase_trials.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )
    for row in results:
        wo3 = row["phases"][1]
        print(
            row["label"],
            "Rwp=",
            row["Rwp_percent"],
            "GOF=",
            row["GOF"],
            "profile=",
            {key: val[1] for key, val in row["profile"].items()},
            "WO3 size=",
            wo3["size"][1],
            "strain=",
            wo3["mustrain"][1],
            "fraction=",
            row["mass_fractions"],
            "corr=",
            row["high_correlations"][:3],
        )


if __name__ == "__main__":
    run()
