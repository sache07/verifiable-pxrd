#!/usr/bin/env python3
"""Read-only consistency checks for the submitted GSAS-II artifacts."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main() -> None:
    result = json.loads((ROOT / "result.json").read_text())
    project = G2sc.G2Project(str(ROOT / "final.gpx"))
    hist = project.histogram(0)
    assert len(project.phases()) == len(result["phases"]) == 3

    weights = [row["weight_fraction"] for row in result["phases"]]
    assert abs(sum(weights) - 1.0) < 1e-14
    computed = hist.ComputeMassFracs()
    for phase, row in zip(project.phases(), result["phases"]):
        assert (ROOT / row["cif_path"]).is_file()
        assert abs(computed[phase.name][0] - row["weight_fraction"]) < 1e-12
        cell = phase.get_cell()
        for key, value in row["cell"].items():
            assert abs(cell[key] - value) < 1e-10

    with (ROOT / "fit.csv").open(newline="") as stream:
        reader = csv.DictReader(stream)
        fit = np.asarray(
            [
                [
                    float(row["two_theta_deg"]),
                    float(row["observed_counts"]),
                    float(row["calculated_counts"]),
                    float(row["background_counts"]),
                    float(row["difference_obs_minus_calc_counts"]),
                ]
                for row in reader
            ]
        )
    reference = np.column_stack(
        [
            hist.getdata("X"),
            hist.getdata("Yobs"),
            hist.getdata("Ycalc"),
            hist.getdata("Background"),
            hist.getdata("Residual"),
        ]
    )
    assert fit.shape == reference.shape == (8301, 5)
    max_profile_delta = float(np.max(np.abs(fit - reference)))
    assert max_profile_delta < 1e-5
    assert np.max(np.abs(fit[:, 1] - fit[:, 2] - fit[:, 4])) < 1e-5

    residuals = hist.data["data"][0]
    stats = result["fit_statistics"]
    assert abs(hist.get_wR() - stats["Rwp_percent"]) < 1e-12
    assert abs(residuals["R"] - stats["Rp_percent"]) < 1e-12
    assert result["profile"]["point_count"] == len(reference)
    print(
        json.dumps(
            {
                "status": "passed",
                "phase_count": 3,
                "weight_sum": sum(weights),
                "profile_rows": len(reference),
                "max_profile_rounding_delta": max_profile_delta,
                "Rwp_percent": hist.get_wR(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
