#!/usr/bin/env python3
"""Rebuild the angular/profile baseline around a single zero correction."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc

from refine_workflow import ROOT, snapshot


def run() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(
        gpxfile=str(ROOT / "working.gpx"),
        newgpx=str(ROOT / "zero_baseline.gpx"),
    )
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    sample["Shift"][:] = [0.0, False]
    inst["Zero"][:] = [0.0, 0.0, True]
    inst["SH/L"][:] = [0.002, 0.002, False]
    inst["U"][:] = [0.0, 0.0, False]
    inst["V"][:] = [0.0, 0.0, False]
    inst["W"][2] = True
    inst["X"][2] = True
    project.data["Controls"]["data"].get("parmFrozen", {}).clear()
    project.set_Controls("cycles", 12)
    project.save()

    audit = []
    project.refine()
    audit.append(snapshot(project, "zero, W/X, SH/L fixed"))
    project.refine()
    audit.append(snapshot(project, "zero, W/X replay"))

    # Release axial-divergence asymmetry only after the symmetric profile is stable.
    hist = project.histogram(0)
    hist.data["Instrument Parameters"][0]["SH/L"][2] = True
    project.refine()
    audit.append(snapshot(project, "zero, W/X + SH/L"))
    project.refine()
    audit.append(snapshot(project, "zero, W/X + SH/L replay"))
    project.save()

    (ROOT / "zero_baseline.json").write_text(
        json.dumps(audit, indent=2, default=float) + "\n"
    )
    for row in audit:
        current = G2sc.G2Project(str(ROOT / "zero_baseline.gpx")) if False else None
        print(
            row["label"],
            "Rwp=",
            row["Rwp_percent"],
            "cell=",
            row["cell"],
            "inst=",
            row["instrument"],
            "vary=",
            row["vary_list"],
        )
    h = project.histogram(0)
    print("zero", h.data["Instrument Parameters"][0]["Zero"])
    print("frozen", project.data["Controls"]["data"].get("parmFrozen"))


if __name__ == "__main__":
    run()
