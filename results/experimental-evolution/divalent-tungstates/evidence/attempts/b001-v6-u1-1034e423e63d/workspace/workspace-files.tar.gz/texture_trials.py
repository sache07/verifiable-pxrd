#!/usr/bin/env python3
"""Challenge no-texture model with distinct March-Dollase axes."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc

from refine_workflow import ROOT
from two_phase_develop import summarize
from two_phase_trials import correlations


BASE = ROOT / "accepted_intensity.gpx"
AXES = {
    "100": [1, 0, 0],
    "010": [0, 1, 0],
    "001": [0, 0, 1],
    "110": [1, 1, 0],
    "101": [1, 0, 1],
    "011": [0, 1, 1],
}


def trial(phase_index: int, phase_tag: str, axis_tag: str, axis: list[int]) -> dict:
    filename = ROOT / f"texture_{phase_tag}_{axis_tag}.gpx"
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(filename))
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    hap = project.phase(phase_index).data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = axis
    project.set_Controls("cycles", 10)
    project.save()
    project.refine()
    project.save()
    project = G2sc.G2Project(str(filename))
    project.refine()
    project.save()
    result = summarize(project, f"{phase_tag} MD {axis_tag}")
    result["high_correlations"] = correlations(project)
    result["texture_phase"] = phase_index
    result["texture_axis"] = axis
    result["MD"] = project.phase(phase_index).data["Histograms"][
        project.histogram(0).name
    ]["Pref.Ori."]
    return result


def run() -> None:
    G2sc.SetPrintLevel("warn")
    results = []
    for phase_index, tag in [(0, "MnWO4"), (1, "WO3")]:
        for axis_tag, axis in AXES.items():
            row = trial(phase_index, tag, axis_tag, axis)
            results.append(row)
            print(
                row["label"],
                "Rwp=",
                row["Rwp_percent"],
                "MD=",
                row["MD"][1],
                "fractions=",
                row["mass_fractions"],
                "corr=",
                row["high_correlations"][:2],
                flush=True,
            )
    (ROOT / "texture_trials.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    run()
