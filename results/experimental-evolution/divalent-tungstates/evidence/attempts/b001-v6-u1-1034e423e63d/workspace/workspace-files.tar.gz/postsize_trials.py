#!/usr/bin/env python3
"""Rechallenge common and anisotropic broadening after accepting WO3 size."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc

from refine_workflow import ROOT
from two_phase_develop import summarize
from two_phase_trials import correlations


BASE = ROOT / "twotrial_wo3_size.gpx"


def branch(name: str) -> G2sc.G2Project:
    p = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(ROOT / f"post_{name}.gpx"))
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    p.set_Controls("cycles", 10)
    p.save()
    return p


def converge(p: G2sc.G2Project, label: str) -> dict:
    p.refine()
    p.save()
    p = G2sc.G2Project(str(p.filename))
    p.refine()
    p.save()
    result = summarize(p, label)
    result["high_correlations"] = correlations(p)
    return result


def run() -> None:
    G2sc.SetPrintLevel("warn")
    results = []

    p = branch("w_x")
    inst = p.histogram(0).data["Instrument Parameters"][0]
    inst["W"][:] = [1.0, 1.0, True]
    p.set_Controls("parmMin", 0.0, variable=":0:W")
    results.append(converge(p, "accepted WO3 size + common W/X"))

    p = branch("u_x")
    inst = p.histogram(0).data["Instrument Parameters"][0]
    inst["U"][:] = [1.0, 1.0, True]
    p.set_Controls("parmMin", 0.0, variable=":0:U")
    results.append(converge(p, "accepted WO3 size + common U/X"))

    p = branch("u_w_x")
    inst = p.histogram(0).data["Instrument Parameters"][0]
    inst["U"][:] = [1.0, 1.0, True]
    inst["W"][:] = [1.0, 1.0, True]
    p.set_Controls("parmMin", 0.0, variable=":0:U")
    p.set_Controls("parmMin", 0.0, variable=":0:W")
    results.append(converge(p, "accepted WO3 size + common U/W/X"))

    p = branch("mn_size")
    h = p.histogram(0)
    hap = p.phase(0).data["Histograms"][h.name]
    hap["Size"][1][0] = 1.0
    hap["Size"][2][0] = True
    p.set_Controls("parmMin", 0.001, variable="0:0:Size;i")
    p.set_Controls("parmMax", 10.0, variable="0:0:Size;i")
    results.append(converge(p, "MnWO4 isotropic size challenge"))

    p = branch("mn_strain")
    h = p.histogram(0)
    hap = p.phase(0).data["Histograms"][h.name]
    hap["Mustrain"][1][0] = 100.0
    hap["Mustrain"][2][0] = True
    p.set_Controls("parmMin", 0.0, variable="0:0:Mustrain;i")
    p.set_Controls("parmMax", 10000.0, variable="0:0:Mustrain;i")
    results.append(converge(p, "MnWO4 isotropic strain challenge"))

    for direction, tag in [([1, 0, 0], "100"), ([0, 1, 0], "010"), ([0, 0, 1], "001")]:
        p = branch(f"wo3_uniax_{tag}")
        h = p.histogram(0)
        hap = p.phase(1).data["Histograms"][h.name]
        current = hap["Size"][1][0]
        hap["Size"][0] = "uniaxial"
        hap["Size"][1][1] = current
        hap["Size"][1][2] = current
        hap["Size"][2][0] = True
        hap["Size"][2][1] = True
        hap["Size"][3] = direction
        results.append(converge(p, f"WO3 uniaxial size {tag}"))

    (ROOT / "postsize_trials.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )
    for row in results:
        print(
            row["label"],
            "Rwp=",
            row["Rwp_percent"],
            "profile=",
            {key: val[1] for key, val in row["profile"].items()},
            "Mn size/strain=",
            row["phases"][0]["size"][1],
            row["phases"][0]["mustrain"][1],
            "WO3 size=",
            row["phases"][1]["size"],
            "fraction=",
            row["mass_fractions"],
            "corr=",
            row["high_correlations"][:3],
        )


if __name__ == "__main__":
    run()
