#!/usr/bin/env python3
"""Screen physical WO3 records against the coherent broad residual families."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_workflow import ROOT


CIF_ROOT = Path(
    "<RUN>/"
    "resources/b001-c04/cif"
)
CANDIDATES = {
    "WO3_P21c_1528915": "1528915",
    "WO3_P21c_2311041": "2311041",
    "WO3_P1bar_2106293": "2106293",
    "WO3_Pnma_2107312": "2107312",
    "WO3_P21c_1563541": "1563541",
    "WO3_P4ncc_1521532": "1521532",
}


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def clean_base() -> Path:
    path = ROOT / "inventory_base.gpx"
    project = G2sc.G2Project(
        gpxfile=str(ROOT / "trial_zero_shl.gpx"), newgpx=str(path)
    )
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["W"][:] = [0.0, 0.0, False]
    inst["X"][2] = True
    inst["SH/L"][2] = True
    inst["Zero"][2] = True
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 8)
    project.save()
    project.refine()
    project.save()
    return path


def phase_summary(project: G2sc.G2Project, phase_index: int) -> dict:
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.data["Histograms"][hist.name]
    return {
        "name": phase.name,
        "composition": phase.composition,
        "cell": phase.get_cell(),
        "scale": hap["Scale"][0],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
    }


def screen(name: str, cod_id: str, base: Path) -> dict:
    out = ROOT / f"screen_{name}.gpx"
    project = G2sc.G2Project(gpxfile=str(base), newgpx=str(out))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cif_path(cod_id)),
        phasename=name,
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][:] = [5.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [0.02, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    phase.set_refinements({"Cell": False})
    project.set_Controls("parmMin", 0.0, variable="1:0:Scale")
    project.set_Controls("cycles", 8)
    project.save()

    # Scale first under the same fixed 20 nm isotropic broadening.
    project.refine()
    scale_only = {
        "Rwp_percent": project.histogram(0).get_wR(),
        "phase": phase_summary(project, 1),
    }

    # A positive scale licenses cell refinement; all background/scales/angular
    # correction and the established common profile remain active.
    phase = project.phase(1)
    phase.set_refinements({"Cell": True})
    project.refine()
    project.save()
    project = G2sc.G2Project(str(out))
    project.refine()
    project.save()
    hist = project.histogram(0)
    try:
        mass_fractions = hist.ComputeMassFracs()
    except Exception as error:
        mass_fractions = {"error": str(error)}
    covariance = project.data.get("Covariance", {}).get("data", {})
    return {
        "candidate": name,
        "cod_id": cod_id,
        "source_cif": str(cif_path(cod_id)),
        "scale_only": scale_only,
        "cell_refined": {
            "Rwp_percent": hist.get_wR(),
            "phases": [phase_summary(project, i) for i in range(2)],
            "mass_fractions": mass_fractions,
            "GOF": covariance.get("Rvals", {}).get("GOF"),
            "converged": covariance.get("Rvals", {}).get("converged"),
            "message": covariance.get("Rvals", {}).get("msg"),
            "vary_list": covariance.get("varyList", []),
        },
    }


def run() -> None:
    G2sc.SetPrintLevel("warn")
    base = clean_base()
    results = []
    for name, cod_id in CANDIDATES.items():
        result = screen(name, cod_id, base)
        results.append(result)
        print(
            name,
            "scale Rwp",
            result["scale_only"]["Rwp_percent"],
            "cell Rwp",
            result["cell_refined"]["Rwp_percent"],
            "scale",
            result["cell_refined"]["phases"][1]["scale"],
            "fractions",
            result["cell_refined"]["mass_fractions"],
        )
    (ROOT / "inventory_screen.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    run()
