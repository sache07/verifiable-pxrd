#!/usr/bin/env python3
"""Prepare GSAS-II inputs and a physically plausible MnWO4 prototype."""

from __future__ import annotations

import csv
import math
from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
SOURCE_CIF = Path(
    "<RUN>/"
    "resources/b001-c04/cif/1/52/06/1520641.cif"
)
WO3_SOURCE_CIF = Path(
    "<RUN>/"
    "resources/b001-c04/cif/2/31/10/2311041.cif"
)


def prepare_pattern() -> None:
    with (ROOT / "inputs/pattern.csv").open(newline="") as source, (
        ROOT / "pattern.xye"
    ).open("w") as target:
        rows = csv.DictReader(source)
        target.write("# Original counts; sigma approximated as sqrt(counts)\n")
        for row in rows:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            target.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")


def prepare_prototype() -> None:
    structure = Structure.from_file(SOURCE_CIF, primitive=False)
    structure.replace_species({"Zn": "Mn"})

    # A near-MnWO4 starting metric keeps all indexed wolframite families within
    # a few peak widths. The metric is refined in GSAS-II; fractional coordinates
    # come unchanged from the ordered, ambient-temperature ZnWO4 P2/c parent.
    lattice = Lattice.monoclinic(4.829, 5.758, 4.996, 91.08)
    structure = Structure(
        lattice,
        structure.species,
        structure.frac_coords,
        site_properties=structure.site_properties,
    )
    CifWriter(structure, symprec=1e-5, refine_struct=False).write_file(
        ROOT / "initial_MnWO4.cif"
    )


def prepare_wo3() -> None:
    structure = Structure.from_file(WO3_SOURCE_CIF, primitive=False)
    # Unimodular setting change from the source's beta~136 degree cell to the
    # conventional near-orthogonal P21/c metric. This preserves all geometry.
    structure.make_supercell([[1, 0, 1], [0, 1, 0], [-1, 0, 0]])
    output = ROOT / "initial_WO3.cif"
    CifWriter(structure, symprec=1e-4, refine_struct=False).write_file(output)
    # The transformed operations are the conventional P21/n setting of #14.
    output.write_text(
        output.read_text().replace(
            "_symmetry_space_group_name_H-M   P2_1/c",
            "_symmetry_space_group_name_H-M   'P 1 21/n 1'",
        ).replace("_symmetry_Int_Tables_number   14\n", "")
    )


if __name__ == "__main__":
    prepare_pattern()
    prepare_prototype()
    prepare_wo3()
