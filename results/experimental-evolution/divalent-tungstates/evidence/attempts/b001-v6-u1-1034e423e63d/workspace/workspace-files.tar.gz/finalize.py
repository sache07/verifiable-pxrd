#!/usr/bin/env python3
"""Create and export the exact final GSAS-II model and submission files."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "three_accepted_size.gpx"
FINAL = ROOT / "final.gpx"
CIF_NAMES = [
    "phase_1_MnWO4.cif",
    "phase_2_WO3.cif",
    "phase_3_Mn3O4.cif",
]
FORMULAS = ["MnWO4", "WO3", "Mn3O4"]
DISPLAY_NAMES = [
    "MnWO4 (wolframite)",
    "WO3 (monoclinic)",
    "Mn3O4 (hausmannite)",
]


def clean_hap(
    phase: G2sc.G2Phase,
    hist: G2sc.G2PwdrData,
    phase_index: int,
) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = True
    hap["Size"][0] = "isotropic"
    hap["Size"][2][:] = [phase_index in (1, 2), False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    if phase_index == 0:
        hap["Size"][1][:] = [10.0, 1000.0, 1.0]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"][:] = [0.0, False]
    for term in hap["Babinet"].values():
        term[:] = [0.0, False]
    phase.data["General"]["Cell"][0] = True


def prepare_project() -> G2sc.G2Project:
    project = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    hist.Limits("lower", 9.90343322)
    hist.Limits("upper", 100.09455322)

    # Eight smooth Chebyshev terms, no sample correction or roughness surrogate.
    hist.data["Background"][0][1] = True
    hist.data["Background"][0][2] = 8
    sample = hist.data["Sample Parameters"]
    sample["Scale"][1] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][:] = [0.0, False]

    inst = hist.data["Instrument Parameters"][0]
    inst["Zero"][2] = True
    inst["Polariz."][2] = True
    for key in ("U", "W", "X", "SH/L"):
        inst[key][2] = True
    for key in ("V", "Y", "Z"):
        inst[key][:] = [0.0, 0.0, False]
    for key in ("Lam1", "Lam2", "I(L2)/I(L1)"):
        inst[key][2] = False

    for index, phase in enumerate(project.phases()):
        clean_hap(phase, hist, index)
        project.set_Controls("parmMin", 0.0, variable=f"{index}:0:Scale")
    for term in ("U", "W", "X"):
        project.set_Controls("parmMin", 0.0, variable=f":0:{term}")
    project.set_Controls("parmMin", 0.0001, variable=":0:SH/L")
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    for index in (1, 2):
        project.set_Controls("parmMin", 0.001, variable=f"{index}:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{index}:0:Size;i")
    project.save()
    return project


def replay(project: G2sc.G2Project) -> G2sc.G2Project:
    # Require at least one save/reopen replay and continue until shifts are small.
    for cycle in range(8):
        project.refine()
        project.save()
        shift = project.data["Covariance"]["data"]["Rvals"].get(
            "Max shft/sig", float("inf")
        )
        project = G2sc.G2Project(str(FINAL))
        if cycle >= 1 and shift < 0.05:
            break
    project.save()
    return project


def fraction_rows(project: G2sc.G2Project) -> list[tuple[float, float]]:
    raw = project.histogram(0).ComputeMassFracs()
    rows = []
    for phase in project.phases():
        value = raw[phase.name]
        if isinstance(value, (list, tuple)):
            rows.append((float(value[0]), float(value[1])))
        else:
            rows.append((float(value), float("nan")))
    total = sum(value for value, _ in rows)
    return [(value / total, esd / total) for value, esd in rows]


def export_fit(hist: G2sc.G2PwdrData) -> None:
    columns = [
        np.asarray(hist.getdata("X"), dtype=float),
        np.asarray(hist.getdata("Yobs"), dtype=float),
        np.asarray(hist.getdata("Ycalc"), dtype=float),
        np.asarray(hist.getdata("Background"), dtype=float),
        np.asarray(hist.getdata("Residual"), dtype=float),
    ]
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "background_counts",
                "difference_obs_minus_calc_counts",
            ]
        )
        for row in zip(*columns):
            writer.writerow([f"{row[0]:.8f}", *[f"{value:.10g}" for value in row[1:]]])


def export_result(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    residuals = hist.data["data"][0]
    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    fractions = fraction_rows(project)
    phase_rows = []
    for index, (phase, cif_name, formula, display_name, fraction) in enumerate(
        zip(project.phases(), CIF_NAMES, FORMULAS, DISPLAY_NAMES, fractions), start=1
    ):
        phase.export_CIF(str(ROOT / cif_name))
        hap = phase.data["Histograms"][hist.name]
        phase_rows.append(
            {
                "name": display_name,
                "formula": formula,
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": cif_name,
                "weight_fraction": fraction[0],
                "weight_fraction_formal_esd": fraction[1],
                "weight_percent": 100.0 * fraction[0],
                "weight_percent_formal_esd": 100.0 * fraction[1],
                "cell": phase.get_cell(),
                "isotropic_size_micrometre": float(hap["Size"][1][0]),
                "isotropic_size_refined": bool(hap["Size"][2][0]),
            }
        )

    result = {
        "phases": phase_rows,
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "fit_statistics": {
            "Rwp_percent": float(hist.get_wR()),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "GOF": float(rvals["GOF"]),
            "reduced_chi_squared": float(rvals["GOF"] ** 2),
            "Durbin_Watson": float(residuals["Durbin-Watson"]),
            "Nobs": int(residuals["Nobs"]),
            "Nvars": int(rvals["Nvars"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
            "converged": bool(rvals["converged"]),
        },
        "profile": {
            "range_two_theta_deg": [
                float(np.min(hist.getdata("X"))),
                float(np.max(hist.getdata("X"))),
            ],
            "point_count": int(len(hist.getdata("X"))),
            "difference_definition": "observed minus calculated",
            "fit_csv_path": "fit.csv",
            "gsas_project_path": "final.gpx",
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def export_report(project: G2sc.G2Project, result: dict) -> None:
    phases = result["phases"]
    fit = result["fit_statistics"]
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    rows = "\n".join(
        f"| {row['name']} | {row['space_group']} | "
        f"{row['weight_percent']:.2f} ± {row['weight_percent_formal_esd']:.2f} |"
        for row in phases
    )
    report = f"""# Phase analysis and quantitative refinement

The pattern is modeled by three crystalline phases. Fractions are normalized over those phases; no amorphous fraction can be obtained without an internal standard.

| Phase | Space group | Weight % (formal GSAS-II e.s.d.) |
|---|---:|---:|
{rows}

## Evidence and model selection

MnWO4 is the dominant wolframite phase. Its low-angle 15.1, 18.1, 23.3/23.8 and 29.6/30.0° families, followed by its dense middle- and high-angle pattern, require the monoclinic P2/c model. No exact local MnWO4 entry was available, so the ordered ambient ZnWO4 wolframite parent (COD 1520641) was found by the supplied stoichiometric-analogue search and Zn was replaced isovalently by Mn. Refining the cell and symmetry-allowed coordinates gives physically sensible octahedra (Mn–O 2.11–2.22 Å and W–O 1.76–2.14 Å in the exported CIF).

Broad residual families at about 26.1, 28.3, 33.6, 41.4, 49.6, 55.5 and 76.4° require WO3. Several physical records/polymorphs were screened. The submitted P21/n average structure derives from COD 2311041 and is preferred as the lower-parameter physical model. A triclinic P-1 record reduced Rwp by only about 0.05 percentage point in the provisional two-phase screen while adding lattice freedom; the breadth of the WO3 peaks does not reliably distinguish those closely related descriptions. WO3 has a refined isotropic coherent-size term of {phases[1]['isotropic_size_micrometre'] * 1000:.1f} nm.

The remaining coherent peaks at about 18.0, 28.9, 31.0, 32.3, 36.1, 44.4, 50.7, 58.5 and 59.8° identify tetragonal hausmannite Mn3O4 (I41/amd; COD 9001963), consistent with residual precursor. Adding this phase reduced Rwp from 2.917% to 2.596%; its physically supported isotropic broadening reduced it further to 2.547%. Its refined size is {phases[2]['isotropic_size_micrometre'] * 1000:.1f} nm. Strain added to that size is 0.92 correlated with size and does not improve the replay, so it was pruned. Four symmetry-distinct March–Dollase axes gave parameters within about two standard uncertainties of 1 and changed Rwp by less than 0.001 percentage point; no texture is retained.

After rebuilding the common profile, Mn3WO6, orthorhombic Mn3O4 and MnO all refined to zero. Two Mn2O3 records remained below 0.08 wt% and did not produce a meaningful replay improvement. They are not reliably detected and are excluded rather than reported as phases.

## Refinement and uncertainty

The full {result['profile']['range_two_theta_deg'][0]:.3f}–{result['profile']['range_two_theta_deg'][1]:.3f}° range was replayed from disk. Cu Kα1/Kα2 wavelengths and the 0.5 intensity ratio were fixed to the metadata. The accepted baseline uses one zero correction ({inst['Zero'][1]:.5f}°), an eight-term smooth Chebyshev background, positive common U/W/X terms, SH/L asymmetry, and refined effective polarization ({inst['Polariz.'][1]:.4f}). Removing U, W or X increased Rwp to 3.81, 2.81 or 2.80%, respectively. Inspection of isolated low-, middle- and high-angle families shows no systematic position drift or repeated FWHM/asymmetry mismatch, and the background remains smooth. Sample displacement, roughness, extra strain, anisotropic size and preferred orientation were rejected or neutralized.

Final statistics are Rwp = {fit['Rwp_percent']:.4f}%, Rp = {fit['Rp_percent']:.4f}%, Rexp = {fit['Rexp_percent']:.4f}%, GOF = {fit['GOF']:.4f}, and Durbin–Watson = {fit['Durbin_Watson']:.3f} ({fit['Nobs']} points, {fit['Nvars']} variables). Pointwise uncertainties were not supplied, so sigma = sqrt(counts) was used; GOF and the quoted formal e.s.d. values are conditional on that Poisson approximation and the selected models.

Systematic uncertainty exceeds the formal covariance errors. In particular, WO3 symmetry is not uniquely resolved, and the weak, broadened Mn3O4 fraction is sensitive to its size model (the neutral-width trial gave about 4.2 wt%, while the statistically supported size model gives {phases[2]['weight_percent']:.2f} wt%). A practical interpretation is roughly MnWO4 {phases[0]['weight_percent']:.1f} ± 1.5 wt%, WO3 {phases[1]['weight_percent']:.1f} ± 1 wt%, and Mn3O4 {phases[2]['weight_percent']:.1f} ± 1.5 wt%; these wider ranges are model/systematic estimates, not covariance e.s.d. values.
"""
    (ROOT / "report.md").write_text(report)


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = replay(prepare_project())
    export_fit(project.histogram(0))
    result = export_result(project)
    export_report(project, result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
