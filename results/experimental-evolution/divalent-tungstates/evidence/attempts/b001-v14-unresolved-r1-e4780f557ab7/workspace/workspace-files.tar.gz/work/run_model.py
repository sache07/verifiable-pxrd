#!/usr/bin/env python3
"""Build and converge a restrained GSAS-II powder model.

Usage:
  run_model.py OUTPUT.gpx NAME=CIF [NAME=CIF ...]
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
PATTERN = ROOT / "inputs" / "pattern.csv"
INSTRUMENT = ROOT / "work" / "cu_dual.instprm"


def phase_state(phase, hist):
    hap = phase.getHAPvalues(hist)
    return {
        "name": phase.name,
        "cell": phase.get_cell(),
        "scale": float(hap["Scale"][0]),
        "scale_refine": bool(hap["Scale"][1]),
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
    }


def project_state(project):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "residuals": hist.residuals,
        "Rvals": cov.get("Rvals", {}),
        "instrument": {
            key: [float(inst[key][1]), bool(inst[key][2])]
            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Zero",
                        "Polariz.", "I(L2)/I(L1)")
        },
        "sample": {
            key: sample[key]
            for key in ("Type", "Scale", "Shift", "Transparency",
                        "SurfRoughA", "SurfRoughB")
        },
        "background": hist.data["Background"][0],
        "phases": [phase_state(p, hist) for p in project.phases()],
        "varyList": [str(v) for v in cov.get("varyList", [])],
        "variables": [float(v) for v in cov.get("variables", [])],
        "sig": [float(v) for v in cov.get("sig", [])],
        "parmFrozen": {
            str(k): [str(v) for v in vals]
            for k, vals in project.data["Controls"]["data"].get(
                "parmFrozen", {}
            ).items()
        },
    }


def show(project, label):
    state = project_state(project)
    compact = {
        "label": label,
        "wR": state["residuals"].get("wR"),
        "Rvals": state["Rvals"],
        "instrument": state["instrument"],
        "sample": state["sample"],
        "phases": [
            {
                "name": p["name"],
                "cell": p["cell"],
                "scale": p["scale"],
            }
            for p in state["phases"]
        ],
        "parmFrozen": state["parmFrozen"],
    }
    print("\nSTATE", json.dumps(compact, default=str))


def set_inactive_terms(project):
    hist = project.histogram(0)
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    sample["Shift"] = [0.0, False]

    inst = hist.data["Instrument Parameters"][0]
    for key, value in {
        "V": 0.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "Zero": 0.0,
    }.items():
        inst[key][1] = value
        inst[key][2] = False

    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [100.0, 100.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]


def set_bounds(project):
    controls = project.data["Controls"]["data"]
    mins = controls.setdefault("parmMinDict", {})
    maxs = controls.setdefault("parmMaxDict", {})
    for name in (":0:U", ":0:W", ":0:X"):
        mins[G2obj.G2VarObj(name)] = 0.0
        maxs[G2obj.G2VarObj(name)] = 2000.0
    mins[G2obj.G2VarObj(":0:Shift")] = -2000.0
    maxs[G2obj.G2VarObj(":0:Shift")] = 2000.0
    for phase in project.phases():
        name = f"{phase.id}:0:Scale"
        mins[G2obj.G2VarObj(name)] = 1.0e-10
        maxs[G2obj.G2VarObj(name)] = 1.0e4


def build(output, phase_specs):
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(PATTERN), str(INSTRUMENT), fmthint="comma"
    )
    for index, (name, cif) in enumerate(phase_specs):
        phase = project.add_phase(
            str(cif), phasename=name, histograms=[hist], fmthint="CIF"
        )
        hap = phase.getHAPvalues(hist)
        hap["Scale"] = [1.0 if index == 0 else 0.10, False]

    set_inactive_terms(project)
    set_bounds(project)
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 8
    controls["deriv type"] = "analytic Hessian"

    hist.data["Limits"][1] = [10.0, 100.0]
    hist.data["Background"][0] = [
        "chebyschev-1", False, 8, 1100.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
    ]
    project.save()
    return project


def refine_stage(project, label):
    project.do_refinements([{}], makeBack=False)
    project.save()
    show(project, label)


def converge(project):
    hist = project.histogram(0)
    # Background and positive phase scales first.
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.getHAPvalues(hist)["Scale"][1] = True
    refine_stage(project, "background_scales")

    # Refine all phase metrics with one Bragg-Brentano angular correction.
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    hist.data["Sample Parameters"]["Shift"][1] = True
    refine_stage(project, "cells_shift")

    # Common nonnegative low-dimensional profile terms.
    inst = hist.data["Instrument Parameters"][0]
    inst["W"][2] = True
    inst["X"][2] = True
    refine_stage(project, "common_WX")
    # U was tested on the first mature checkpoint and replayed to its
    # nonnegative bound. Keep that unsupported term literally zero.
    inst["U"][1] = 0.0
    inst["U"][2] = False
    refine_stage(project, "converged_WX_repeat")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phases", nargs="+")
    args = parser.parse_args()
    phase_specs = []
    for spec in args.phases:
        name, path = spec.split("=", 1)
        phase_specs.append((name, Path(path).resolve()))
    project = build(args.output.resolve(), phase_specs)
    converge(project)


if __name__ == "__main__":
    main()
