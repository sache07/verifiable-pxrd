#!/usr/bin/env python3
"""Run matched one-axis March-Dollase challenges from a mature GPX."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("phase", type=int)
    parser.add_argument("tag")
    parser.add_argument("--preserve-others", action="store_true",
                        help="retain texture terms on non-target phases")
    parser.add_argument("axes", nargs="+", help="h,k,l")
    args = parser.parse_args()

    source = Path(args.source).resolve()
    rows = []
    for token in args.axes:
        axis = [int(v) for v in token.split(",")]
        axis_tag = "".join("m" + str(-v) if v < 0 else str(v) for v in axis)
        output = source.parent.parent / "challenges" / (
            f"{args.tag}_p{args.phase}_{axis_tag}.gpx"
        )
        project = G2sc.G2Project(str(source), newgpx=str(output))
        hist = project.histogram(0)
        if not args.preserve_others:
            for phase in project.phases():
                po = phase.getHAPvalues(hist)["Pref.Ori."]
                po[1] = 1.0
                po[2] = False
        phase = project.phase(args.phase)
        po = phase.getHAPvalues(hist)["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = axis
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.save()
        for replay in range(3):
            project = G2sc.G2Project(str(output))
            project.do_refinements([{}])
            project.save()
            rvals = project.data["Covariance"]["data"]["Rvals"]
            if (
                rvals.get("converged")
                and abs(rvals.get("Max shft/sig", 99.0)) < 1.0
            ):
                break
        hist = project.histogram(0)
        po = project.phase(args.phase).getHAPvalues(hist)["Pref.Ori."]
        rows.append(
            {
                "output": str(output),
                "phase": project.phase(args.phase).name,
                "axis": axis,
                "ratio": float(po[1]),
                "wR": float(hist.get_wR()),
                "Rvals": project.data["Covariance"]["data"]["Rvals"],
                "fractions": {
                    k: list(v) for k, v in hist.ComputeMassFracs().items()
                },
                "frozen": {
                    str(k): [str(v) for v in vals]
                    for k, vals in project.data["Controls"]["data"].get(
                        "parmFrozen", {}
                    ).items()
                },
            }
        )
    print("TEXTURE_RESULTS " + json.dumps(rows, default=str))


if __name__ == "__main__":
    main()
