#!/usr/bin/env python3
"""Matched phase-specific size/strain challenges from a mature GPX."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("phase", type=int)
    parser.add_argument("tag")
    args = parser.parse_args()
    source = Path(args.source).resolve()
    rows = []
    for mode in ("size", "strain", "size_strain"):
        output = source.parent.parent / "challenges" / (
            f"{args.tag}_p{args.phase}_{mode}.gpx"
        )
        project = G2sc.G2Project(str(source), newgpx=str(output))
        hist = project.histogram(0)
        phase = project.phase(args.phase)
        hap = phase.getHAPvalues(hist)
        size = hap["Size"]
        strain = hap["Mustrain"]
        size[0] = "isotropic"
        # Literal neutral values matter even when the refinement flag is off.
        # GSAS-II's isotropic size ceiling is 10 micrometres.
        size[1][0] = 10.0
        size[2] = [False, False, False]
        strain[0] = "isotropic"
        strain[1][0] = 0.0
        strain[2] = [False, False, False]
        if mode in ("size", "size_strain"):
            size[1][0] = 5.0
            size[2][0] = True
        if mode in ("strain", "size_strain"):
            strain[1][0] = 100.0
            strain[2][0] = True
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.save()
        for replay in range(4):
            project = G2sc.G2Project(str(output))
            project.do_refinements([{}])
            project.save()
            rvals = project.data["Covariance"]["data"]["Rvals"]
            if (
                rvals.get("converged")
                and abs(rvals.get("Max shft/sig", 99.0)) < 1.0
            ):
                break
        hist = project.histogram(0)
        phase = project.phase(args.phase)
        hap = phase.getHAPvalues(hist)
        inst = hist.data["Instrument Parameters"][0]
        rows.append(
            {
                "output": str(output),
                "phase": phase.name,
                "mode": mode,
                "wR": float(hist.get_wR()),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "common_WX": [float(inst["W"][1]), float(inst["X"][1])],
                "Rvals": project.data["Covariance"]["data"]["Rvals"],
                "fractions": {
                    k: list(v) for k, v in hist.ComputeMassFracs().items()
                },
                "frozen": {
                    str(k): [str(v) for v in vals]
                    for k, vals in project.data["Controls"]["data"].get(
                        "parmFrozen", {}
                    ).items()
                },
            }
        )
    print("PROFILE_RESULTS " + json.dumps(rows, default=str))


if __name__ == "__main__":
    main()
