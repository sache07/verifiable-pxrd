#!/usr/bin/env python3
"""Add one candidate phase to a mature GPX and test its scale then cell."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2sc


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    return {
        "label": label,
        "wR": float(hist.get_wR()),
        "Rvals": project.data.get("Covariance", {}).get("data", {}).get(
            "Rvals", {}
        ),
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "phases": [
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": phase.getHAPvalues(hist)["Scale"],
                "texture": phase.getHAPvalues(hist)["Pref.Ori."],
                "size": phase.getHAPvalues(hist)["Size"],
                "strain": phase.getHAPvalues(hist)["Mustrain"],
            }
            for phase in project.phases()
        ],
        "frozen": {
            str(k): [str(v) for v in vals]
            for k, vals in project.data["Controls"]["data"].get(
                "parmFrozen", {}
            ).items()
        },
    }


def replay(output: Path, count: int) -> G2sc.G2Project:
    for _ in range(count):
        project = G2sc.G2Project(str(output))
        project.do_refinements([{}])
        project.save()
        rvals = project.data["Covariance"]["data"]["Rvals"]
        if rvals.get("converged") and abs(rvals.get("Max shft/sig", 99)) < 1:
            return project
    return project


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("name")
    parser.add_argument("cif")
    parser.add_argument("--scale", type=float, default=0.05)
    parser.add_argument("--replays", type=int, default=5)
    args = parser.parse_args()

    source = Path(args.source).resolve()
    output = Path(args.output).resolve()
    project = G2sc.G2Project(str(source), newgpx=str(output))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(Path(args.cif).resolve()), phasename=args.name,
        histograms=[hist], fmthint="CIF"
    )
    hap = phase.getHAPvalues(hist)
    hap["Scale"] = [args.scale, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    phase.data["General"]["Cell"][0] = False

    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    mins = controls.setdefault("parmMinDict", {})
    maxs = controls.setdefault("parmMaxDict", {})
    mins[G2obj.G2VarObj(f"{phase.id}:0:Scale")] = 1.0e-10
    maxs[G2obj.G2VarObj(f"{phase.id}:0:Scale")] = 1.0e4
    project.save()

    rows = []
    project = replay(output, args.replays)
    rows.append(snapshot(project, "scale_only"))

    # A candidate cell is only meaningful after its scale has found a
    # positive interior solution.
    scale = project.phase(phase.id).getHAPvalues(project.histogram(0))["Scale"][0]
    if scale > 1.0e-8:
        project.phase(phase.id).data["General"]["Cell"][0] = True
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.save()
        project = replay(output, args.replays)
        rows.append(snapshot(project, "scale_cell"))

    print("ADD_PHASE_RESULTS " + json.dumps(rows, default=str))


if __name__ == "__main__":
    main()
