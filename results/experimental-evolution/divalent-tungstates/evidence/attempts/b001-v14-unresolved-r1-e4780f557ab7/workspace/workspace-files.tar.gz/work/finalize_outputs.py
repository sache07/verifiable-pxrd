#!/usr/bin/env python3
"""Prune, replay and export the selected full-range GSAS-II model."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "challenges" / "rough_fixed_bg6.gpx"
PROJECT = ROOT / "final.gpx"

PHASE_META = [
    {
        "name": "SrWO4",
        "formula": "SrWO4",
        "model": "scheelite",
        "cif_path": "phase_1_SrWO4_scheelite.cif",
        "source": "SrMoO4 COD 2300460, isovalently adapted to SrWO4",
    },
    {
        "name": "WO3",
        "formula": "WO3",
        "model": "orthorhombic",
        "cif_path": "phase_2_WO3_orthorhombic.cif",
        "source": "WO3 COD 2107312",
    },
    {
        "name": "SrCO3",
        "formula": "SrCO3",
        "model": "orthorhombic strontianite",
        "cif_path": "phase_3_SrCO3.cif",
        "source": "SrCO3 COD 9008198",
    },
    {
        "name": "WO3_mono",
        "formula": "WO3",
        "model": "monoclinic",
        "cif_path": "phase_4_WO3_monoclinic.cif",
        "source": "WO3 COD 2311041",
    },
]


def finite(value):
    """Convert finite numeric scalars for strict JSON output."""
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def configure_project() -> G2sc.G2Project:
    """Clone the selected checkpoint and make every retained term explicit."""
    project = G2sc.G2Project(str(SOURCE), newgpx=str(PROJECT))
    hist = project.histogram(0)
    x = hist.data["data"][1][0]
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]

    # Keep the simplest background that was statistically indistinguishable
    # from the 8- and 10-term challenges.
    background = hist.data["Background"][0]
    coefficients = list(background[3:])
    if len(coefficients) < 6:
        coefficients.extend([0.0] * (6 - len(coefficients)))
    background[0] = "chebyschev-1"
    background[1] = True
    background[2] = 6
    background[3:] = coefficients[:6]

    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    # This value was refined in the focused roughness branch, then fixed for
    # the background comparison to avoid its scale correlation.
    sample["SurfRoughB"] = [0.0714401, False]
    sample["Shift"][1] = True

    inst = hist.data["Instrument Parameters"][0]
    fixed_instrument = {
        "U": 0.0,
        "V": 0.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "Zero": 0.0,
        "Polariz.": 0.5,
        "I(L2)/I(L1)": 0.5,
    }
    for key, value in fixed_instrument.items():
        inst[key][1] = value
        inst[key][2] = False
    for key in ("W", "X"):
        inst[key][2] = True

    # Preserve only the two family-supported isotropic strain terms. All
    # inactive size/strain values are literal and all high-dimensional flags
    # are disabled.
    retained_strain = {1, 3}
    for index, phase in enumerate(project.phases()):
        phase.data["General"]["Cell"][0] = True
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True

        size = hap["Size"]
        size[0] = "isotropic"
        size[1][:] = [10.0, 10.0, 1.0]
        size[2][:] = [False, False, False]
        size[5][:] = [False] * len(size[5])

        strain = hap["Mustrain"]
        previous = max(float(strain[1][0]), 0.0)
        strain[0] = "isotropic"
        strain[1][:] = [previous if index in retained_strain else 0.0, 0.0, 1.0]
        strain[2][:] = [index in retained_strain, False, False]
        strain[4][:] = [0.0] * len(strain[4])
        strain[5][:] = [False] * len(strain[5])

        # Each retained March-Dollase axis won its compact, symmetry-aware
        # comparison. Preserve the ratio, axis and refinement flag.
        orientation = hap["Pref.Ori."]
        orientation[0] = "MD"
        orientation[2] = True

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["deriv type"] = "analytic Hessian"
    controls["parmFrozen"] = {"FrozenList": []}
    mins = controls.setdefault("parmMinDict", {})
    maxs = controls.setdefault("parmMaxDict", {})
    for key in (":0:W", ":0:X"):
        mins[G2obj.G2VarObj(key)] = 0.0
        maxs[G2obj.G2VarObj(key)] = 2000.0
    mins[G2obj.G2VarObj(":0:Shift")] = -2000.0
    maxs[G2obj.G2VarObj(":0:Shift")] = 2000.0
    for phase in project.phases():
        scale = G2obj.G2VarObj(f"{phase.id}:0:Scale")
        mins[scale] = 1.0e-10
        maxs[scale] = 1.0e4

    project.save()
    return project


def replay_full_range() -> tuple[G2sc.G2Project, list[dict]]:
    """Reopen and replay until two consecutive independent convergences."""
    configure_project()
    history = []
    stable = 0
    for replay in range(1, 13):
        project = G2sc.G2Project(str(PROJECT))
        project.do_refinements([{}])
        project.save()
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        entry = {
            "replay": replay,
            "Rwp_percent": finite(project.histogram(0).get_wR()),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_over_sigma": finite(rvals.get("Max shft/sig")),
        }
        history.append(entry)
        max_shift = entry["max_shift_over_sigma"]
        if entry["converged"] and max_shift is not None and abs(max_shift) < 1.0:
            stable += 1
        else:
            stable = 0
        if stable >= 2:
            break
    else:
        raise RuntimeError("Full-range model did not achieve two stable replays")
    return G2sc.G2Project(str(PROJECT)), history


def profile_statistics(hist, n_parameters: int) -> dict:
    x, observed, weights, calculated = hist.data["data"][1][:4]
    limits = hist.data["Limits"][1]
    selected = (x >= limits[0]) & (x <= limits[1])
    obs = np.asarray(observed)[selected]
    calc = np.asarray(calculated)[selected]
    wgt = np.asarray(weights)[selected]
    diff = obs - calc
    weighted_ss = float(np.sum(wgt * diff * diff))
    weighted_obs = float(np.sum(wgt * obs * obs))
    rwp = 100.0 * math.sqrt(weighted_ss / weighted_obs)
    rp = 100.0 * float(np.sum(np.abs(diff))) / float(np.sum(np.abs(obs)))
    dof = int(obs.size - n_parameters)
    reduced_chi2 = weighted_ss / dof
    rexp = rwp / math.sqrt(reduced_chi2)
    return {
        "Rwp_percent": rwp,
        "Rp_percent": rp,
        "Rexp_percent": rexp,
        "goodness_of_fit": math.sqrt(reduced_chi2),
        "reduced_chi_square": reduced_chi2,
        "chi_square": weighted_ss,
        "n_observations": int(obs.size),
        "n_parameters": int(n_parameters),
        "degrees_of_freedom": dof,
        "two_theta_min_deg": float(x[selected][0]),
        "two_theta_max_deg": float(x[selected][-1]),
    }


def export_outputs(project: G2sc.G2Project, replay_history: list[dict]) -> dict:
    hist = project.histogram(0)
    covariance = project.data["Covariance"]["data"]
    phases = project.phases()
    if len(phases) != len(PHASE_META):
        raise RuntimeError(f"Expected four phases, found {len(phases)}")

    for phase, metadata in zip(phases, PHASE_META):
        phase.export_CIF(str(ROOT / metadata["cif_path"]))

    raw_fractions = hist.ComputeMassFracs()
    fraction_rows = []
    for phase, metadata in zip(phases, PHASE_META):
        value = raw_fractions[phase.name]
        fraction_rows.append([float(value[0]), float(value[1])])
    normalizer = math.fsum(row[0] for row in fraction_rows)
    fractions = [row[0] / normalizer for row in fraction_rows]
    fractions[-1] = 1.0 - math.fsum(fractions[:-1])

    result_phases = []
    for phase, metadata, fraction, raw in zip(
            phases, PHASE_META, fractions, fraction_rows):
        cell, cell_esd = phase.get_cell_and_esd()
        general = phase.data["General"]
        result_phases.append({
            "name": metadata["name"],
            "formula": metadata["formula"],
            "structural_model": metadata["model"],
            "space_group": general["SGData"]["SpGrp"].strip(),
            "weight_fraction": float(fraction),
            "weight_fraction_esd": float(raw[1] / normalizer),
            "cif_path": metadata["cif_path"],
            "project_path": "final.gpx",
            "source_model": metadata["source"],
            "cell": {key: float(value) for key, value in cell.items()},
            "cell_esd": {key: float(value) for key, value in cell_esd.items()},
        })

    data = hist.data["data"][1]
    x = np.asarray(data[0])
    observed = np.asarray(data[1])
    calculated = np.asarray(data[3])
    background = np.asarray(data[4])
    difference = observed - calculated
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg", "observed", "calculated", "difference",
            "background",
        ])
        writer.writerows(zip(x, observed, calculated, difference, background))

    fit = profile_statistics(hist, len(covariance.get("varyList", [])))
    result = {
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over modeled crystalline phases",
        "phases": result_phases,
        "fit_statistics": fit,
        "replay": {
            "full_measured_range": True,
            "history": replay_history,
            "converged": True,
        },
        "measurement": {
            "radiation": "Cu K-alpha1/K-alpha2",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "pointwise_standard_uncertainties_supplied": False,
        },
    }
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")

    names = [
        f"{row['formula']} ({row['structural_model']})"
        for row in result_phases
    ]
    fractions_percent = [100.0 * row["weight_fraction"] for row in result_phases]
    esd_percent = [100.0 * row["weight_fraction_esd"] for row in result_phases]
    report = f"""# Powder diffraction phase analysis

The replay-stable crystalline model contains four phases. Fractions are normalized only over the modeled crystalline phases:

| Phase model | Weight fraction |
|---|---:|
| {names[0]} | {fractions_percent[0]:.2f}% (formal s.u. {esd_percent[0]:.2f}%) |
| {names[1]} | {fractions_percent[1]:.2f}% (formal s.u. {esd_percent[1]:.2f}%) |
| {names[2]} | {fractions_percent[2]:.2f}% (formal s.u. {esd_percent[2]:.2f}%) |
| {names[3]} | {fractions_percent[3]:.2f}% (formal s.u. {esd_percent[3]:.2f}%) |

The full-range final replay gives Rwp = {fit['Rwp_percent']:.3f}%, Rp = {fit['Rp_percent']:.3f}% and goodness of fit = {fit['goodness_of_fit']:.3f} over {fit['n_observations']} points. The model uses the measured Cu Kalpha doublet, six smooth Chebyshev background coefficients, one specimen-shift correction, nonnegative common W/X profile terms, and a fixed roughness correction established by the focused angular-trend comparison. Unsupported size, extra strain, asymmetry and polarization terms were pruned or fixed at their physical neutral values.

## Evidence for the inventory

The dominant pattern is scheelite-type SrWO4. Since the supplied structure index contained no exact SrWO4 record, an isovalent SrMoO4 scheelite parent (COD 2300460) was converted to SrWO4 and health-screened; only its cell and whole-pattern nuisance terms were refined. A lower-symmetry fergusonite analogue improved the neutral fit slightly but lost the matched compact texture/profile comparison, so it was rejected. Structurally distinct WO3 records were compared; the orthorhombic COD 2107312 record was the strongest neutral competitor. All four submitted final CIFs pass the required geometry, occupancy and contact health screen.

Residual families required both an orthorhombic and a monoclinic WO3 model. The monoclinic model carries independent lines near 22.51 and 41.33 degrees 2theta, while the orthorhombic model carries independent lines near 47.48 and 54.07 degrees. From the same mature checkpoint, deleting orthorhombic WO3 raised Rwp from 4.049% to 4.766%, and deleting monoclinic WO3 raised it to 5.104%; both retained scales were positive and replay-stable. SrCO3 is also independently supported by families near 24.62/25.26, 35.65/36.03 and 43.61 degrees, consistent with unreacted precursor.

## Remaining uncertainty

No pointwise standard uncertainties were supplied, so the listed fraction s.u. values are conditional GSAS-II least-squares values and are smaller than realistic uncertainty. Preferred orientation, the empirical roughness correction, severe peak overlap and partitioning between the two related WO3 polymorphs make the individual WO3 fractions model-dependent; their combined abundance is more reliable than either individual value. A conservative interpretation is that the minor orthorhombic WO3 fraction is only semiquantitative and both WO3 fractions may shift by several weight-percent under alternative texture/profile assumptions. The scheelite topology is well supported, but its detailed atomic coordinates were inherited from the isovalent analogue and cannot be determined reliably from this powder pattern alone. No amorphous fraction or external-standard absolute crystallinity was determined.
"""
    (ROOT / "report.md").write_text(report)
    return result


def validate(project: G2sc.G2Project, result: dict) -> None:
    fractions = [phase["weight_fraction"] for phase in result["phases"]]
    if not math.isclose(math.fsum(fractions), 1.0, rel_tol=0.0, abs_tol=1e-12):
        raise RuntimeError("Normalized phase fractions do not sum to one")
    for phase in result["phases"]:
        if phase["weight_fraction"] <= 0:
            raise RuntimeError(f"Nonpositive phase fraction for {phase['name']}")
        if not (ROOT / phase["cif_path"]).is_file():
            raise RuntimeError(f"Missing CIF {phase['cif_path']}")
        if phase["project_path"] != "final.gpx":
            raise RuntimeError("Inconsistent project path")
    hist = project.histogram(0)
    if len(hist.data["data"][1][0]) != 8301:
        raise RuntimeError("Unexpected profile length")
    limits = hist.data["Limits"][1]
    x = hist.data["data"][1][0]
    if not (math.isclose(limits[0], x[0]) and math.isclose(limits[1], x[-1])):
        raise RuntimeError("Final project is not set to the complete measured range")


def main() -> None:
    project, replay_history = replay_full_range()
    result = export_outputs(project, replay_history)
    validate(project, result)
    print(json.dumps({
        "project": str(PROJECT),
        "replay": replay_history,
        "fit_statistics": result["fit_statistics"],
        "fractions": {
            phase["name"]: phase["weight_fraction"]
            for phase in result["phases"]
        },
    }, indent=2))


if __name__ == "__main__":
    main()
