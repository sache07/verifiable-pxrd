#!/usr/bin/env python3
"""Clone a GPX, make a small focused change, and replay refinement."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2sc


def phase_index(token: str) -> int:
    return int(token.split(":", 1)[0])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--texture", action="append", default=[],
                        help="phase:h,k,l[:initial_ratio]")
    parser.add_argument("--neutral-texture", action="append", default=[],
                        help="phase")
    parser.add_argument("--strain", action="append", default=[],
                        help="phase:initial_value")
    parser.add_argument("--neutral-strain", action="append", default=[],
                        help="phase")
    parser.add_argument("--disable-phase", action="append", default=[],
                        help="phase index; fix its scale at a negligible value")
    parser.add_argument("--background-terms", type=int)
    parser.add_argument("--polarization", type=float,
                        help="initial polarization and enable refinement")
    parser.add_argument("--roughness-b", type=float,
                        help="initial Suortti B with A fixed at zero")
    parser.add_argument("--fixed-roughness-b", type=float,
                        help="fixed Suortti B with A fixed at zero")
    parser.add_argument("--replays", type=int, default=5)
    args = parser.parse_args()

    source = Path(args.source).resolve()
    output = Path(args.output).resolve()
    project = G2sc.G2Project(str(source), newgpx=str(output))
    hist = project.histogram(0)

    if args.background_terms is not None:
        background = hist.data["Background"][0]
        coefficients = list(background[3:])
        if len(coefficients) < args.background_terms:
            coefficients.extend([0.0] * (args.background_terms - len(coefficients)))
        background[2] = args.background_terms
        background[3:] = coefficients[:args.background_terms]

    controls = project.data["Controls"]["data"]
    mins = controls.setdefault("parmMinDict", {})
    maxs = controls.setdefault("parmMaxDict", {})
    if args.polarization is not None:
        polar = hist.data["Instrument Parameters"][0]["Polariz."]
        polar[1] = args.polarization
        polar[2] = True
        mins[G2obj.G2VarObj(":0:Polariz.")] = 0.0
        maxs[G2obj.G2VarObj(":0:Polariz.")] = 1.0
    if args.roughness_b is not None:
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [args.roughness_b, True]
        mins[G2obj.G2VarObj(":0:SurfRoughB")] = 0.0
        maxs[G2obj.G2VarObj(":0:SurfRoughB")] = 10.0
    if args.fixed_roughness_b is not None:
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [args.fixed_roughness_b, False]

    for token in args.neutral_texture:
        po = project.phase(int(token)).getHAPvalues(hist)["Pref.Ori."]
        po[1] = 1.0
        po[2] = False

    for token in args.texture:
        fields = token.split(":")
        index = int(fields[0])
        axis = [int(v) for v in fields[1].split(",")]
        ratio = float(fields[2]) if len(fields) > 2 else 1.0
        po = project.phase(index).getHAPvalues(hist)["Pref.Ori."]
        po[0] = "MD"
        po[1] = ratio
        po[2] = True
        po[3] = axis

    for token in args.neutral_strain:
        strain = project.phase(int(token)).getHAPvalues(hist)["Mustrain"]
        strain[0] = "isotropic"
        strain[1][0] = 0.0
        strain[2][0] = False

    for token in args.strain:
        index_text, value_text = token.split(":", 1)
        strain = project.phase(int(index_text)).getHAPvalues(hist)["Mustrain"]
        strain[0] = "isotropic"
        strain[1][0] = float(value_text)
        strain[2][0] = True

    for token in args.disable_phase:
        phase = project.phase(int(token))
        hap = phase.getHAPvalues(hist)
        hap["Scale"] = [1.0e-10, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Size"][1][0] = 10.0
        hap["Size"][2][0] = False
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2][0] = False
        phase.data["General"]["Cell"][0] = False

    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.save()

    for replay in range(args.replays):
        project = G2sc.G2Project(str(output))
        project.do_refinements([{}])
        project.save()
        rvals = project.data["Covariance"]["data"]["Rvals"]
        if rvals.get("converged") and abs(rvals.get("Max shft/sig", 99)) < 1:
            break

    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "output": str(output),
        "wR": float(hist.get_wR()),
        "Rvals": project.data["Covariance"]["data"]["Rvals"],
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "phases": [],
        "instrument": {key: inst[key] for key in
                       ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")},
        "sample": {key: sample[key] for key in
                   ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
        "frozen": {str(k): [str(v) for v in vals] for k, vals in
                   project.data["Controls"]["data"].get("parmFrozen", {}).items()},
    }
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        result["phases"].append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "texture": hap["Pref.Ori."],
            "size": hap["Size"],
            "strain": hap["Mustrain"],
        })
    print("REFINE_CLONE " + json.dumps(result, default=str))


if __name__ == "__main__":
    main()
