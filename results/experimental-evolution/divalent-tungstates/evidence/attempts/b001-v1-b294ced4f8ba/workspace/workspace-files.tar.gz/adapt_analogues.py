#!/usr/bin/env python3
"""Create explicitly documented Pb-W-O models from isovalent COD parents."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def adapt(cod_id: str, old: str, output: str) -> None:
    structure = Structure.from_file(cod_path(cod_id))
    structure.replace_species({old: "W"})
    CifWriter(structure, symprec=0.01).write_file(output)
    print(
        output,
        "parent COD", cod_id,
        f"substitution {old}->W",
        "composition", structure.composition,
        "space group", structure.get_space_group_info(),
        "ordered", structure.is_ordered,
    )


adapt("7220560", "Mo", "trials/Pb2WO5_from_Pb2MoO5_7220560.cif")
adapt("2310493", "U", "trials/Pb3WO6_from_Pb3UO6_2310493.cif")
