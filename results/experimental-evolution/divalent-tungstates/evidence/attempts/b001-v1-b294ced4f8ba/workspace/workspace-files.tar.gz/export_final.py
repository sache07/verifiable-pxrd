#!/usr/bin/env python3
"""Create and verify all requested deliverables from one final GSAS-II project."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


SOURCE = Path("trials/final_profile_clean.gpx")
FINAL = Path("final.gpx")

PHASE_INFO = {
    "PbWO4_scheelite": {
        "reported_name": "PbWO4 (scheelite)",
        "formula": "PbWO4",
        "cif": "phase_PbWO4_scheelite.cif",
        "source_record": "COD 9009811",
        "space_group_number": 88,
    },
    "WO3_monoclinic": {
        "reported_name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif": "phase_WO3_monoclinic.cif",
        "source_record": "COD 2311041",
        "space_group_number": 14,
    },
    "Pb3O4": {
        "reported_name": "Pb3O4 (minium)",
        "formula": "Pb3O4",
        "cif": "phase_Pb3O4.cif",
        "source_record": "COD 9012124",
        "space_group_number": 135,
    },
    "PbO_massicot": {
        "reported_name": "PbO (massicot)",
        "formula": "PbO",
        "cif": "phase_PbO_massicot.cif",
        "source_record": "COD 2310433",
        "space_group_number": 57,
    },
}


def make_final_project() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    hist = project.histogram(0)
    instrument = hist.data["Instrument Parameters"][0]

    # Explicit final instrument/profile state.
    instrument["Polariz."][1:] = [1.0, False]
    instrument["Zero"][1:] = [0.0, False]
    instrument["V"][1:] = [0.0, False]
    instrument["Y"][1:] = [0.0, False]
    instrument["Z"][1:] = [0.0, False]
    instrument["U"][2] = True
    instrument["W"][2] = True
    instrument["X"][2] = True
    hist.data["Sample Parameters"]["Shift"][1] = True
    hist.data["Sample Parameters"]["Transparency"][1] = False
    project.set_Frozen()

    # Reassert a neutral state for every unused phase profile contribution.
    broadened = {"PbWO4_scheelite", "Pb3O4", "PbO_massicot"}
    for phase in project.phases():
        phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "isotropic",
                    "refine": False,
                    "LGmix": {"value": 1.0, "refine": False},
                },
                "Pref.Ori.": False,
            },
            [hist],
        )
        if phase.name not in broadened:
            phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
            phase.set_HAP_refinements(
                {
                    "Size": {
                        "type": "isotropic",
                        "refine": False,
                        "LGmix": {"value": 1.0, "refine": False},
                    }
                },
                [hist],
            )

    project.set_Controls("cycles", 12)
    project.save()
    for index in range(2):
        project.refine(printFile=f"final.stage{index + 1}.lst")
    project.save()


def export() -> dict:
    # Reload so every export demonstrably comes from the saved final project.
    project = G2sc.G2Project(str(FINAL))
    hist = project.histogram(0)
    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    fractions = hist.ComputeMassFracs()

    phase_results = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        phase.export_CIF(info["cif"])
        sgdata = phase.data["General"]["SGData"]
        value, esd = fractions[phase.name]
        phase_results.append(
            {
                "name": info["reported_name"],
                "project_phase_name": phase.name,
                "formula": info["formula"],
                "space_group": sgdata["SpGrp"].strip(),
                "space_group_number": info["space_group_number"],
                "source_record": info["source_record"],
                "cif_path": info["cif"],
                "weight_fraction": float(value),
                "weight_fraction_formal_esd": float(esd),
            }
        )

    profile = np.asarray(hist.data["data"][1], dtype=float)
    two_theta, observed, weight, calculated, background, difference = profile
    # GSAS-II leaves zero calculated/background values outside the refinement
    # limits. Export exactly the points that contributed to the final fit.
    used = (calculated != 0.0) | (background != 0.0)
    with Path("fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed",
                "calculated",
                "difference_observed_minus_calculated",
                "background",
            ]
        )
        for row in zip(
            two_theta[used],
            observed[used],
            calculated[used],
            difference[used],
            background[used],
        ):
            # 17 significant digits guarantee round-trip recovery of the
            # binary64 arrays stored in the final project.
            writer.writerow([f"{value:.17g}" for value in row])

    fit_statistics = {
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "Rexp_percent": float(hist.residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_square": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_variables": int(rvals["Nvars"]),
        "fit_range_two_theta_deg": [
            float(two_theta[used][0]),
            float(two_theta[used][-1]),
        ],
        "phase_Bragg_R_percent": {
            phase.name: float(hist.residuals[f"{phase.id}:{hist.id}:Rf"])
            for phase in project.phases()
        },
    }
    result = {
        "project_path": str(FINAL),
        "profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over modeled crystalline phases",
        "phases": phase_results,
        "fit_statistics": fit_statistics,
        "uncertainty_note": (
            "Weight-fraction ESDs are formal least-squares values only; "
            "profile, polarization, microabsorption and structural-model "
            "systematics are larger."
        ),
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def validate(result: dict) -> dict:
    project = G2sc.G2Project(str(FINAL))
    hist = project.histogram(0)
    instrument = hist.data["Instrument Parameters"][0]
    fractions = hist.ComputeMassFracs()
    profile = np.asarray(hist.data["data"][1], dtype=float)
    used = (profile[3] != 0.0) | (profile[4] != 0.0)

    csv_data = np.genfromtxt("fit.csv", delimiter=",", names=True)
    result_by_project_name = {
        item["project_phase_name"]: item for item in result["phases"]
    }
    fraction_error = max(
        abs(
            result_by_project_name[name]["weight_fraction"]
            - float(value[0])
        )
        for name, value in fractions.items()
    )
    csv_error = max(
        float(np.max(np.abs(csv_data["observed"] - profile[1][used]))),
        float(np.max(np.abs(csv_data["calculated"] - profile[3][used]))),
        float(
            np.max(
                np.abs(
                    csv_data["difference_observed_minus_calculated"]
                    - profile[5][used]
                )
            )
        ),
    )

    theta = np.radians(np.linspace(5.0, 50.0, 1000))
    gaussian_variance = (
        instrument["U"][1] * np.tan(theta) ** 2
        + instrument["V"][1] * np.tan(theta)
        + instrument["W"][1]
    )

    haps = {}
    for phase in project.phases():
        values = phase.getHAPvalues(hist)
        haps[phase.name] = {
            "Scale": values["Scale"],
            "Size": values["Size"],
            "Mustrain": values["Mustrain"],
            "HStrain": values["HStrain"],
            "Pref.Ori.": values["Pref.Ori."],
        }

    checks = {
        "project_reloaded": True,
        "no_frozen_variables": len(project.get_Frozen()) == 0,
        "fractions_sum": float(sum(value[0] for value in fractions.values())),
        "max_fraction_export_error": fraction_error,
        "fit_csv_row_count": int(len(csv_data)),
        "fit_csv_max_export_error": csv_error,
        "minimum_global_gaussian_variance": float(gaussian_variance.min()),
        "background_minimum_in_fit": float(profile[4][used].min()),
        "all_scales_positive": all(
            phase.getHAPvalues(hist)["Scale"][0] > 0
            for phase in project.phases()
        ),
        "frozen_variables": [str(value) for value in project.get_Frozen()],
        "instrument": instrument,
        "sample": hist.data["Sample Parameters"],
        "HAP_values_and_flags": haps,
    }
    assert checks["no_frozen_variables"]
    assert math.isclose(checks["fractions_sum"], 1.0, abs_tol=1e-12)
    assert fraction_error < 1e-12
    assert csv_error == 0.0
    assert checks["fit_csv_row_count"] == result["fit_statistics"]["n_observations"]
    assert checks["minimum_global_gaussian_variance"] > 0
    assert checks["background_minimum_in_fit"] > 0
    assert checks["all_scales_positive"]
    Path("final_validation.json").write_text(
        json.dumps(checks, indent=2, default=str) + "\n"
    )
    return checks


def main() -> None:
    make_final_project()
    result = export()
    checks = validate(result)
    print("FINAL_RESULT " + json.dumps(result, sort_keys=True))
    print("FINAL_CHECKS " + json.dumps(checks, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
