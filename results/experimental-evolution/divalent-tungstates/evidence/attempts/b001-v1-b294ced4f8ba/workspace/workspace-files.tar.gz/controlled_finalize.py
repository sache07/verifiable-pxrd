#!/usr/bin/env python3
"""Run controlled final-stage GSAS-II refinements from a stabilized inventory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def correlation_summary(project: G2sc.G2Project) -> dict:
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = covariance.get("varyList", [])
    matrix = covariance.get("covMatrix")
    if matrix is None or not names:
        return {"maximum_absolute": None, "pairs_above_0.8": []}
    matrix = np.asarray(matrix, dtype=float)
    sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    denominator = np.outer(sigma, sigma)
    with np.errstate(invalid="ignore", divide="ignore"):
        corr = np.divide(matrix, denominator, where=denominator > 0)
    pairs = []
    maximum = 0.0
    for i in range(len(names)):
        for j in range(i):
            value = float(corr[i, j])
            if not np.isfinite(value):
                continue
            maximum = max(maximum, abs(value))
            if abs(value) >= 0.8:
                pairs.append([names[j], names[i], value])
    pairs.sort(key=lambda item: abs(item[2]), reverse=True)
    return {"maximum_absolute": maximum, "pairs_above_0.8": pairs[:30]}


def summarize(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    covariance = project.data["Covariance"]["data"]
    phase_data = {}
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        phase_data[phase.name] = {
            "cell": phase.get_cell(),
            "composition": phase.composition,
            "Scale": hap["Scale"],
            "Size": hap["Size"],
            "Mustrain": hap["Mustrain"],
            "HStrain": hap["HStrain"],
            "Pref.Ori.": hap["Pref.Ori."],
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "refinement_flags": atom.refinement_flags,
                    "uiso": atom.uiso,
                }
                for atom in phase.atoms()
            ],
        }
    return {
        "residuals": hist.residuals,
        "Rvals": covariance.get("Rvals", {}),
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "frozen": [str(value) for value in project.get_Frozen()],
        "varyList": covariance.get("varyList", []),
        "variables": covariance.get("variables", []).tolist()
        if hasattr(covariance.get("variables", []), "tolist")
        else covariance.get("variables", []),
        "sig": covariance.get("sig", []).tolist()
        if hasattr(covariance.get("sig", []), "tolist")
        else covariance.get("sig", []),
        "correlations": correlation_summary(project),
        "constraints": {
            key: [str(item) for item in project.get_Constraints(key)]
            for key in ("Hist", "HAP", "Phase", "Global")
        },
        "phases": phase_data,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--global-x", action="store_true")
    parser.add_argument("--global-u", action="store_true")
    parser.add_argument("--pbwo4-common-uiso", action="store_true")
    parser.add_argument(
        "--fix-size",
        action="append",
        default=[],
        metavar="PHASE",
        help="fix a phase's isotropic size at 10 micrometres",
    )
    parser.add_argument("--polarization", type=float)
    parser.add_argument("--refine-polarization", action="store_true")
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
    hist = project.histogram(0)

    # U reached its physical lower bound in the prior staged test. Keep it at
    # zero, clear its flag and remove the stale frozen-variable marker.
    instrument = hist.data["Instrument Parameters"][0]
    instrument["U"][1] = 0.0
    instrument["U"][2] = False
    project.set_Frozen()

    if args.polarization is not None:
        if not 0.0 <= args.polarization <= 1.0:
            raise ValueError("polarization must be between 0 and 1")
        instrument["Polariz."][1] = args.polarization
        if not args.refine_polarization:
            instrument["Polariz."][2] = False
    if args.refine_polarization:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls(
            "parmMin", 0.5, variable=f":{hist.id}:Polariz."
        )
        project.set_Controls(
            "parmMax", 1.0, variable=f":{hist.id}:Polariz."
        )

    if args.global_x:
        instrument["X"][1] = 0.0
        hist.set_refinements({"Instrument Parameters": ["X"]})
        project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:X")

    if args.global_u:
        instrument["U"][1] = 0.0
        hist.set_refinements({"Instrument Parameters": ["U"]})
        project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:U")

    if args.pbwo4_common_uiso:
        phase = project.phase("PbWO4_scheelite")
        phase.set_refinements({"Atoms": {"all": "U"}})
        atom_variables = [
            f"{phase.id}::AUiso:{index}" for index, _ in enumerate(phase.atoms())
        ]
        project.add_EquivConstr(atom_variables)
        for variable in atom_variables:
            project.set_Controls("parmMin", 0.0, variable=variable)
            project.set_Controls("parmMax", 0.05, variable=variable)

    for phase_name in args.fix_size:
        phase = project.phase(phase_name)
        phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "refine": False,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            },
            [hist],
        )

    project.set_Controls("cycles", 12)
    project.save()
    for index in range(3):
        project.refine(printFile=f"{args.output}.stage{index + 1}.lst")
    project.save()

    result = summarize(project)
    args.output.with_suffix(".json").write_text(
        json.dumps(result, indent=2, default=str) + "\n"
    )
    print("CONTROLLED_SUMMARY " + json.dumps(result, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
