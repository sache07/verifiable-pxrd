#!/usr/bin/env python3
"""Stage phase-specific isotropic broadening from an inventory-refined GPX."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("specs", nargs="+", help="phase:size or phase:strain")
    parser.add_argument("--global-w", action="store_true")
    parser.add_argument("--global-u", action="store_true")
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    hist = project.histogram(0)
    for spec in args.specs:
        name, kind = spec.rsplit(":", 1)
        phase = project.phase(name)
        if kind == "size":
            phase.setSampleProfile(hist, "size", "isotropic", 0.05, LGmix=1.0)
            phase.set_HAP_refinements(
                {
                    "Size": {
                        "type": "isotropic",
                        "refine": True,
                        "LGmix": {"value": 1.0, "refine": False},
                    }
                },
                [hist],
            )
            project.set_Controls(
                "parmMin", 0.005, variable=f"{phase.id}:{hist.id}:Size;i"
            )
            project.set_Controls(
                "parmMax", 10.0, variable=f"{phase.id}:{hist.id}:Size;i"
            )
        elif kind == "strain":
            phase.setSampleProfile(
                hist, "microstrain", "isotropic", 2500.0, LGmix=1.0
            )
            phase.set_HAP_refinements(
                {
                    "Mustrain": {
                        "type": "isotropic",
                        "refine": True,
                        "LGmix": {"value": 1.0, "refine": False},
                    }
                },
                [hist],
            )
            project.set_Controls(
                "parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Mustrain;i"
            )
            project.set_Controls(
                "parmMax", 20000.0, variable=f"{phase.id}:{hist.id}:Mustrain;i"
            )
        else:
            raise ValueError(f"unknown profile kind: {kind}")

    if args.global_w:
        hist.set_refinements({"Instrument Parameters": ["W"]})
    if args.global_u:
        hist.set_refinements({"Instrument Parameters": ["U"]})
    project.set_Controls("cycles", 10)
    project.save()
    for _ in range(2):
        project.refine()

    result = {
        "wR_percent": hist.get_wR(),
        "Rvals": project.data["Covariance"]["data"].get("Rvals", {}),
        "fractions": hist.ComputeMassFracs(),
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "frozen": [str(value) for value in project.get_Frozen()],
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "Scale": phase.getHAPvalues(hist)["Scale"],
                "Size": phase.getHAPvalues(hist)["Size"],
                "Mustrain": phase.getHAPvalues(hist)["Mustrain"],
                "HStrain": phase.getHAPvalues(hist)["HStrain"],
                "Pref.Ori.": phase.getHAPvalues(hist)["Pref.Ori."],
            }
            for phase in project.phases()
        },
    }
    print("BROADEN_SUMMARY " + json.dumps(result, default=str, sort_keys=True))
    Path(args.output).with_suffix(".json").write_text(
        json.dumps(result, indent=2, default=str) + "\n"
    )
    project.save()


if __name__ == "__main__":
    main()
