#!/usr/bin/env python3
"""Build comparable, restrained GSAS-II phase-inventory trials."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)

RECORDS = {
    "scheelite": ("9009811", "PbWO4_scheelite"),
    "raspite": ("9007617", "PbWO4_raspite"),
    "defect_tungstate": ("9016035", "Pb7W8O28.8"),
    "wo3_mono": ("2311041", "WO3_monoclinic"),
    "wo3_mono_old": ("1528915", "WO3_monoclinic_old"),
    "wo3_tri": ("2106293", "WO3_triclinic"),
    "wo3_ortho": ("2107312", "WO3_orthorhombic"),
    "pb3o4": ("9012124", "Pb3O4"),
    "massicot": ("2310433", "PbO_massicot"),
    "litharge": ("9012700", "PbO_litharge"),
    "litharge_std": ("local_litharge", "PbO_litharge"),
}


def cod_path(cod_id: str) -> Path:
    if cod_id == "local_litharge":
        return Path("trials/litharge_standard.cif")
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summary(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    result = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
        "instrument": {
            key: value[1]
            for key, value in hist.data["Instrument Parameters"][0].items()
            if key in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"}
        },
        "sample": {
            key: hist.data["Sample Parameters"][key]
            for key in ("Scale", "Shift", "Transparency")
        },
        "phases": {},
        "frozen": [str(item) for item in project.get_Frozen()],
    }
    try:
        result["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as err:  # unavailable before a scale refinement
        result["mass_fraction_error"] = str(err)
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        result["phases"][phase.name] = {
            "composition": phase.composition,
            "cell": phase.get_cell(),
            "density": phase.density,
            "Scale": hap["Scale"],
            "Size": hap["Size"],
            "Mustrain": hap["Mustrain"],
            "HStrain": hap["HStrain"],
            "Pref.Ori.": hap["Pref.Ori."],
        }
    print("TRIAL_SUMMARY " + json.dumps(result, default=str, sort_keys=True))
    return result


def build_trial(output: Path, phase_keys: list[str], correction: str) -> G2sc.G2Project:
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 12,
                "coeffs": [1400.0] + [0.0] * 11,
            },
        }
    )
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [
        -750.0 if correction == "shift" else 0.0,
        correction == "shift",
    ]
    hist.data["Instrument Parameters"][0]["Zero"] = [
        0.43 if correction == "zero" else 0.0,
        0.43 if correction == "zero" else 0.0,
        correction == "zero",
    ]

    for key in phase_keys:
        cod_id, name = RECORDS[key]
        phase = project.add_phase(
            str(cod_path(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase.HAPvalue("Scale", newValue=1.0, targethistlist=[hist])
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
        # GSAS-II defaults (1 um size and 1000 ppm strain) are active even
        # when fixed. Make the neutral starting state explicit.
        phase.setSampleProfile(hist, "size", "isotropic", 1000.0, LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
        phase.set_refinements({"Cell": True})
        project.set_Controls(
            "parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale"
        )

    project.set_Controls("cycles", 8)
    project.set_Controls("parmMin", 0.001, variable=f":{hist.id}:W")
    project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:U")
    project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:X")
    project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:Y")
    project.save()
    return project


def refine_trial(project: G2sc.G2Project, profile: bool) -> list[dict]:
    hist = project.histogram(0)
    results = []
    # Refit background, all scales, angular correction and all cells together.
    for index in range(2):
        project.refine(printFile=f"{project.filename}.stage{index + 1}.lst")
        results.append(summary(project, f"inventory_{index + 1}"))

    if profile:
        # Add identifiable common Gaussian width terms one at a time.
        hist.set_refinements({"Instrument Parameters": ["W"]})
        project.refine(printFile=f"{project.filename}.stage3_W.lst")
        results.append(summary(project, "global_W"))
        hist.set_refinements({"Instrument Parameters": ["U"]})
        project.refine(printFile=f"{project.filename}.stage4_UW.lst")
        results.append(summary(project, "global_UW"))
        # Re-converge the same model after coupling profile and cells.
        project.refine(printFile=f"{project.filename}.stage5_reconverge.lst")
        results.append(summary(project, "global_UW_reconverged"))
    project.save()
    return results


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phases", nargs="+", choices=sorted(RECORDS))
    parser.add_argument("--correction", choices=("shift", "zero"), default="shift")
    parser.add_argument("--no-profile", action="store_true")
    args = parser.parse_args()
    project = build_trial(args.output, args.phases, args.correction)
    results = refine_trial(project, not args.no_profile)
    args.output.with_suffix(".json").write_text(
        json.dumps(results, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
