#!/usr/bin/env python3
"""Run reversible, common-model GSAS-II trials for MnWO4 prototypes."""

from __future__ import annotations

import json
import math
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
WORK = HERE / "work"
OBS = WORK / "pattern.xye"
INST = WORK / "cu_ka.instprm"
BG = [1358.0, -630.0, 392.0, -215.0, 77.0, -16.0]

CANDIDATES = {
    "wolframite_zn1520641": WORK / "mnwo4_wolframite_zn1520641.cif",
    "wolframite_fe9008124": WORK / "mnwo4_wolframite_fe9008124.cif",
    "wolframite_mg9013902": WORK / "mnwo4_wolframite_mg9013902.cif",
    "alternate_c2m_mnmoo4": WORK / "mnwo4_c2m_mnmoo4_1527061.cif",
    "alternate_scheelite_cawo4": WORK / "mnwo4_scheelite_cawo4_7219229.cif",
    "alternate_triclinic_cuwo4": WORK / "mnwo4_triclinic_cuwo4_4000806.cif",
}


def neutralize_hap(phase: G2sc.G2Phase, histogram: G2sc.G2PwdrData) -> None:
    hap = phase.getHAPvalues(histogram)
    hap["Scale"] = [10.0, True]
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [1.0e6, 1.0e6, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][4] = [1.0e6] * len(hap["Size"][4])
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][4] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Extinction"] = [0.0, False]
    for key in hap["Babinet"]:
        hap["Babinet"][key] = [0.0, False]


def configure(name: str, cif: Path, output: Path) -> G2sc.G2Project:
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(OBS), str(INST), fmthint="xye"
    )
    phase = project.add_phase(
        str(cif), phasename=name, histograms=[hist], fmthint="CIF"
    )
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    for key in ("Absorption", "DisplaceX", "DisplaceY", "Shift", "Transparency"):
        if key in hist.data["Sample Parameters"]:
            hist.data["Sample Parameters"][key] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]

    instrument = hist.data["Instrument Parameters"][0]
    values = {
        "Zero": 0.0,
        "Polariz.": 0.5,
        "U": 0.0,
        "V": 0.0,
        "W": 16.0,
        "X": 3.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }
    for key, value in values.items():
        instrument[key][0] = instrument[key][1] = value
        instrument[key][2] = False
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": len(BG),
                "coeffs": BG,
            }
        }
    )
    neutralize_hap(phase, hist)
    phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-7
    project.save()
    return project


def replay(path: Path, count: int = 1) -> G2sc.G2Project:
    project = G2sc.G2Project(str(path))
    for _ in range(count):
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(path))
    return project


def state(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    hap = phase.getHAPvalues(hist)
    return {
        "stage": label,
        "Rwp": hist.residuals.get("wR"),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "phase_scale": hap["Scale"][0],
        "sample_shift_um": hist.data["Sample Parameters"]["Shift"][0],
        "cell": phase.get_cell(),
        "W": inst["W"][1],
        "X": inst["X"][1],
        "SH_L": inst["SH/L"][1],
        "frozen": list(map(str, project.get_Frozen() or [])),
    }


def run_one(name: str, cif: Path) -> dict:
    path = WORK / f"trial_{name}.gpx"
    project = configure(name, cif, path)
    stages = []

    project = replay(path, 1)
    stages.append(state(project, "background_scale"))

    project.histogram(0).set_refinements({"Sample Parameters": ["Shift"]})
    project.save()
    project = replay(path, 1)
    stages.append(state(project, "plus_shift"))

    project.phase(0).set_refinements({"Cell": True})
    project.save()
    project = replay(path, 2)
    stages.append(state(project, "plus_cell"))

    project.histogram(0).set_refinements(
        {"Instrument Parameters": ["W", "X"]}
    )
    project.save()
    project = replay(path, 2)
    stages.append(state(project, "plus_W_X"))

    checkpoint = WORK / f"trial_{name}_before_shl.gpx"
    shutil.copy2(path, checkpoint)
    before = state(project, "before_SH_L")
    project.histogram(0).set_refinements(
        {"Instrument Parameters": ["SH/L"]}
    )
    project.save()
    project = replay(path, 2)
    after = state(project, "SH_L_trial")
    sh_supported = (
        after["Rwp"] is not None
        and before["Rwp"] is not None
        and before["Rwp"] - after["Rwp"] >= 0.01
        and 0.002 < after["SH_L"] < 0.2
        and not after["frozen"]
    )
    if not sh_supported:
        shutil.copy2(checkpoint, path)
        project = G2sc.G2Project(str(path))
        after = state(project, "SH_L_rejected")
    stages.append(after)
    project.save()
    return {
        "candidate": name,
        "cif": str(cif),
        "project": str(path),
        "SH_L_supported": sh_supported,
        "stages": stages,
        "final": state(project, "final"),
    }


def main() -> None:
    results = []
    for name, cif in CANDIDATES.items():
        try:
            results.append(run_one(name, cif))
        except Exception as exc:
            results.append(
                {"candidate": name, "cif": str(cif), "error": repr(exc)}
            )
    output = WORK / "source_trials_summary.json"
    output.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
