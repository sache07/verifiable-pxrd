#!/usr/bin/env python3
"""Final weak-phase and WO3-source challenges on the physical profile."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from source_trials import neutralize_hap


HERE = Path(__file__).resolve().parent
WORK = HERE / "work"
BASE = WORK / "nuisance_surface_roughness.gpx"
TRICLINIC_BASE = WORK / "inventory_WO3_triclinic_2106293.gpx"
COD_ROOT = Path(
    "<RUN>/"
    "resources/b001-c04/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


WATCH = {
    "Mn2O3_bixbyite_1514230": cod_path("1514230"),
    "MnO2_rutile_1514110": cod_path("1514110"),
    "Mn3WO6_2002703": cod_path("2002703"),
}


def replay(path: Path, count: int = 2) -> G2sc.G2Project:
    project = G2sc.G2Project(str(path))
    project.set_Controls("cycles", 14)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    for _ in range(count):
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(path))
    return project


def state(project: G2sc.G2Project, trial: str) -> dict:
    hist = project.histogram(0)
    fr = hist.ComputeMassFracs()
    return {
        "trial": trial,
        "Rwp": float(hist.residuals.get("wR", float("nan"))),
        "fractions": {k: float(v[0]) for k, v in fr.items()},
        "scales": {
            phase.name: float(phase.getHAPvalues(hist)["Scale"][0])
            for phase in project.phases()
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "roughness": {
            key: float(hist.data["Sample Parameters"][key][0])
            for key in ("SurfRoughA", "SurfRoughB")
        },
        "frozen": list(map(str, project.get_Frozen() or [])),
    }


def watch_trial(name: str, cif: Path) -> dict:
    path = WORK / f"watch_{name}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(path))
    hist = project.histogram(0)
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
    hist.clear_refinements(
        {
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
            "Instrument Parameters": ["W", "X"],
        }
    )
    phase = project.add_phase(
        str(cif), phasename=name, histograms=[hist], fmthint="CIF"
    )
    neutralize_hap(phase, hist)
    phase.getHAPvalues(hist)["Scale"] = [0.2, True]
    phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
    project.set_Frozen()
    project.save()
    project = replay(path, 1)
    stages = [state(project, "scale_on_physical_checkpoint")]

    for item in project.phases():
        item.set_refinements({"Cell": True})
        item.set_HAP_refinements({"Scale": True}, [project.histogram(0)])
    project.histogram(0).set_refinements(
        {
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
            "Instrument Parameters": ["W", "X"],
        }
    )
    project.save()
    project = replay(path, 2)
    stages.append(state(project, "reconverged_watch_phase"))
    return {"candidate": name, "project": str(path), "stages": stages}


def triclinic_wo3_trial() -> dict:
    name = "Mn3O4_hausmannite_9001963"
    path = WORK / "watch_triclinic_WO3_three_phase.gpx"
    project = G2sc.G2Project(str(TRICLINIC_BASE), newgpx=str(path))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cod_path("9001963")), phasename=name, histograms=[hist], fmthint="CIF"
    )
    neutralize_hap(phase, hist)
    phase.getHAPvalues(hist)["Scale"] = [1.0, True]
    for item in project.phases():
        item.set_refinements({"Cell": True})
        item.set_HAP_refinements({"Scale": True}, [hist])
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.3, True]
    sample["SurfRoughB"] = [0.58, True]
    hist.set_refinements(
        {
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
            "Instrument Parameters": ["W", "X"],
        }
    )
    project.set_Frozen()
    project.save()
    project = replay(path, 3)
    return state(project, "triclinic_WO3_three_phase")


def main() -> None:
    results = []
    for name, cif in WATCH.items():
        try:
            results.append(watch_trial(name, cif))
        except Exception as exc:
            results.append({"candidate": name, "error": repr(exc)})
    try:
        results.append(triclinic_wo3_trial())
    except Exception as exc:
        results.append({"trial": "triclinic_WO3_three_phase", "error": repr(exc)})
    output = WORK / "final_watch_trials_summary.json"
    output.write_text(json.dumps(results, indent=2, default=float) + "\n")
    print(json.dumps(results, indent=2, default=float))


if __name__ == "__main__":
    main()
