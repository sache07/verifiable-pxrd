#!/usr/bin/env python3
"""Prepare lossless GSAS-II input and chemically screened trial structures."""

from __future__ import annotations

import csv
import math
from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


HERE = Path(__file__).resolve().parent
COD_ROOT = Path(
    "<RUN>/"
    "resources/b001-c04/cif"
)
WORK = HERE / "work"


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_observations() -> None:
    """Copy every observation to xye and assign Poisson counting s.u.'s."""
    source = HERE / "inputs" / "pattern.csv"
    target = WORK / "pattern.xye"
    with source.open(newline="") as src, target.open("w", newline="") as dst:
        rows = csv.DictReader(src)
        dst.write("# Original observations; sigma=sqrt(counts), no resampling\n")
        for row in rows:
            x = row["two_theta_deg"]
            y = row["intensity"]
            dst.write(f"{x} {y} {math.sqrt(float(y)):.12g}\n")


def write_instrument() -> None:
    text = """#GSAS-II instrument parameter file for lab Cu Kalpha reflection data
Type:PXC;Bank:1
Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5
U:2.0;V:-2.0;W:5.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002
"""
    (WORK / "cu_ka.instprm").write_text(text)


def substituted(
    cod_id: str,
    replacements: dict[str, str],
    output: str,
    cell: tuple[float, float, float, float, float, float] | None = None,
) -> None:
    structure = Structure.from_file(cod_path(cod_id))
    structure.replace_species(replacements)
    if cell is not None:
        lattice = Lattice.from_parameters(*cell)
        structure = Structure(
            lattice,
            [site.species for site in structure],
            structure.frac_coords,
            coords_are_cartesian=False,
            site_properties=structure.site_properties,
        )
    CifWriter(structure, symprec=1e-3).write_file(WORK / output)


def main() -> None:
    WORK.mkdir(exist_ok=True)
    write_observations()
    write_instrument()

    # Peak-family least squares with no angular correction gives this safe
    # starting cell. Cell and one angular correction are refined in GSAS-II.
    start_cell = (4.8646, 5.8089, 5.0165, 90.0, 91.14, 90.0)
    substituted(
        "1520641", {"Zn": "Mn"}, "mnwo4_wolframite_zn1520641.cif", start_cell
    )
    substituted(
        "9008124", {"Fe": "Mn"}, "mnwo4_wolframite_fe9008124.cif", start_cell
    )
    substituted(
        "9013902", {"Mg": "Mn"}, "mnwo4_wolframite_mg9013902.cif", start_cell
    )
    substituted("1527061", {"Mo": "W"}, "mnwo4_c2m_mnmoo4_1527061.cif")
    substituted("7219229", {"Ca": "Mn"}, "mnwo4_scheelite_cawo4_7219229.cif")
    substituted("4000806", {"Cu": "Mn"}, "mnwo4_triclinic_cuwo4_4000806.cif")


if __name__ == "__main__":
    main()
