#!/usr/bin/env python3
"""Validate roughness stability and texture axes on the physical baseline."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
WORK = HERE / "work"
NEUTRAL = WORK / "nuisance_checkpoint.gpx"
ROUGH = WORK / "nuisance_surface_roughness.gpx"


def replay(path: Path, count: int = 2) -> G2sc.G2Project:
    project = G2sc.G2Project(str(path))
    project.set_Controls("cycles", 14)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    for _ in range(count):
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(path))
    return project


def state(project: G2sc.G2Project, trial: str) -> dict:
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    return {
        "trial": trial,
        "Rwp": float(hist.residuals.get("wR", float("nan"))),
        "fractions": {k: float(v[0]) for k, v in fractions.items()},
        "roughness": {
            key: float(hist.data["Sample Parameters"][key][0])
            for key in ("SurfRoughA", "SurfRoughB")
        },
        "profile": {
            key: float(hist.data["Instrument Parameters"][0][key][1])
            for key in ("U", "W", "X", "SH/L", "Polariz.")
        },
        "texture": {
            phase.name: [
                phase.getHAPvalues(hist)["Pref.Ori."][0],
                float(phase.getHAPvalues(hist)["Pref.Ori."][1]),
                bool(phase.getHAPvalues(hist)["Pref.Ori."][2]),
                [int(v) for v in phase.getHAPvalues(hist)["Pref.Ori."][3]],
            ]
            for phase in project.phases()
        },
        "vary_list": list(project.data["Covariance"]["data"].get("varyList", [])),
        "frozen": list(map(str, project.get_Frozen() or [])),
    }


def roughness_multistart(index: int, a: float, b: float) -> dict:
    tag = f"rough_multistart_{index}"
    path = WORK / f"physical_{tag}.gpx"
    project = G2sc.G2Project(str(NEUTRAL), newgpx=str(path))
    sample = project.histogram(0).data["Sample Parameters"]
    sample["SurfRoughA"] = [a, True]
    sample["SurfRoughB"] = [b, True]
    project.set_Frozen()
    project.save()
    return state(replay(path), tag)


def texture_trial(phase_index: int, axis: tuple[int, int, int]) -> dict:
    ptag = ("mnwo4", "wo3", "mn3o4")[phase_index]
    atag = "".join(map(str, axis))
    tag = f"texture_{ptag}_{atag}"
    path = WORK / f"physical_{tag}.gpx"
    project = G2sc.G2Project(str(ROUGH), newgpx=str(path))
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.getHAPvalues(hist)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][3] = list(axis)
    phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])
    project.set_Frozen()
    project.save()
    return state(replay(path), tag)


def main() -> None:
    results = []
    starts = [(0.15, 0.15), (0.5, 0.5), (0.8, 0.05), (0.2, 1.0)]
    for i, (a, b) in enumerate(starts):
        try:
            results.append(roughness_multistart(i, a, b))
        except Exception as exc:
            results.append({"trial": f"rough_multistart_{i}", "error": repr(exc)})

    axes = {
        0: [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (1, 1, 1)],
        1: [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (1, 1, 1)],
        2: [(1, 0, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (1, 1, 1)],
    }
    for phase_index, phase_axes in axes.items():
        for axis in phase_axes:
            try:
                results.append(texture_trial(phase_index, axis))
            except Exception as exc:
                results.append(
                    {
                        "trial": f"texture_phase{phase_index}_{axis}",
                        "error": repr(exc),
                    }
                )
    output = WORK / "physical_trials_summary.json"
    output.write_text(json.dumps(results, indent=2, default=float) + "\n")
    print(json.dumps(results, indent=2, default=float))


if __name__ == "__main__":
    main()
