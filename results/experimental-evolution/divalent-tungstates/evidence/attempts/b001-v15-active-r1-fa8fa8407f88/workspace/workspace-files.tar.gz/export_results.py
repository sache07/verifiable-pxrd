#!/usr/bin/env python3
"""Export all submitted products from the exact final GSAS-II project."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIpwd as G2pwd
from GSASII import GSASIIstrMain as G2str


HERE = Path(__file__).resolve().parent
PROJECT_PATH = HERE / "final.gpx"
INPUT_PATTERN = HERE / "inputs" / "pattern.csv"

PHASES = {
    "wolframite_mg9013902": {
        "name": "MnWO4 (wolframite)",
        "formula": "MnWO4",
        "cif_path": "phase_MnWO4_wolframite.cif",
        "source": "MgWO4 wolframite COD 9013902, Mg-to-Mn substitution",
    },
    "WO3_monoclinic_2311041": {
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif_path": "phase_WO3_monoclinic.cif",
        "source": "monoclinic WO3 COD 2311041",
    },
    "Mn3O4_hausmannite_9001963": {
        "name": "Mn3O4 (hausmannite)",
        "formula": "Mn3O4",
        "cif_path": "phase_Mn3O4_hausmannite.cif",
        "source": "hausmannite COD 9001963",
    },
}


def minimum_distance(phase: G2sc.G2Phase) -> float:
    controls, data = phase.InitDisAgl(useAll=False)
    controls["Factors"][1] = 0
    _labels, distances, _angles = G2str.RetDistAngle(controls, data, dmin=0.01)
    values = [float(row[-2]) for entries in distances.values() for row in entries]
    return min(values) if values else float("inf")


def exact_fit_statistics(hist: G2sc.G2PwdrData, number_variables: int) -> dict:
    observed = np.asarray(hist.getdata("yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("ycalc"), dtype=float)
    weights = np.asarray(hist.getdata("yweight"), dtype=float)
    used = weights > 0
    residual = observed[used] - calculated[used]
    chi_square = float(np.sum(weights[used] * residual**2))
    denominator = float(np.sum(weights[used] * observed[used] ** 2))
    number_observations = int(np.count_nonzero(used))
    degrees_of_freedom = number_observations - number_variables
    return {
        "Rwp_percent": 100.0 * math.sqrt(chi_square / denominator),
        "Rp_percent": 100.0
        * float(np.sum(np.abs(residual)))
        / float(np.sum(np.abs(observed[used]))),
        "Rexp_percent": 100.0 * math.sqrt(degrees_of_freedom / denominator),
        "goodness_of_fit": math.sqrt(chi_square / degrees_of_freedom),
        "chi_square": chi_square,
        "number_observations": number_observations,
        "number_refined_variables": number_variables,
        "degrees_of_freedom": degrees_of_freedom,
    }


def write_fit(hist: G2sc.G2PwdrData) -> None:
    x = np.asarray(hist.getdata("x"), dtype=float)
    observed = np.asarray(hist.getdata("yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("ycalc"), dtype=float)
    background = np.asarray(hist.getdata("background"), dtype=float)
    difference = np.asarray(hist.getdata("residual"), dtype=float)

    with INPUT_PATTERN.open(newline="") as stream:
        original_rows = list(csv.DictReader(stream))
    original_x = np.asarray([float(row["two_theta_deg"]) for row in original_rows])
    original_y = np.asarray([float(row["intensity"]) for row in original_rows])
    if not np.array_equal(x, original_x) or not np.array_equal(observed, original_y):
        raise RuntimeError("final.gpx observation grid differs from inputs/pattern.csv")
    if not np.allclose(difference, observed - calculated, rtol=0.0, atol=1.0e-10):
        raise RuntimeError("stored GSAS-II difference profile is inconsistent")

    with (HERE / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "background_intensity",
                "difference_intensity",
            ]
        )
        for row, yc, yb, yd in zip(
            original_rows, calculated, background, difference, strict=True
        ):
            # Preserve the two measured columns byte-for-byte as supplied;
            # calculated columns use enough digits for binary round-trip.
            writer.writerow(
                [
                    row["two_theta_deg"],
                    row["intensity"],
                    format(float(yc), ".17g"),
                    format(float(yb), ".17g"),
                    format(float(yd), ".17g"),
                ]
            )


def representative_profile_checks(hist: G2sc.G2PwdrData) -> list[dict]:
    phase_name = "wolframite_mg9013902"
    requested = [(1, 0, 0), (3, 1, -1), (4, 1, -1)]
    refs = hist.reflections()[phase_name]["RefList"]
    x = np.asarray(hist.getdata("x"), dtype=float)
    observed = np.asarray(hist.getdata("yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("ycalc"), dtype=float)
    background = np.asarray(hist.getdata("background"), dtype=float)
    checks = []
    for hkl in requested:
        rows = [row for row in refs if tuple(map(int, row[:3])) == hkl]
        if len(rows) != 1:
            raise RuntimeError(f"could not uniquely find representative reflection {hkl}")
        row = rows[0]
        position = float(row[5])
        fwhm = float(
            G2pwd.getgamFW(
                float(row[7]) / 100.0,
                math.sqrt(max(float(row[6]), 0.0001)) / 100.0,
            )
        )
        window = np.abs(x - position) < 0.22
        observed_max = float(x[window][np.argmax((observed - background)[window])])
        calculated_max = float(x[window][np.argmax((calculated - background)[window])])
        checks.append(
            {
                "hkl": list(hkl),
                "two_theta_deg": position,
                "FWHM_deg": fwhm,
                "observed_minus_calculated_peak_max_deg": observed_max
                - calculated_max,
            }
        )
    return checks


def cell_text(cell: dict) -> str:
    a, b, c = (cell[f"length_{axis}"] for axis in "abc")
    alpha, beta, gamma = (
        cell[f"angle_{name}"] for name in ("alpha", "beta", "gamma")
    )
    if max(abs(alpha - 90), abs(gamma - 90), abs(beta - 90)) < 1.0e-6:
        if abs(a - b) < 1.0e-6:
            return f"a=b={a:.5f}, c={c:.5f} Å"
        return f"a={a:.5f}, b={b:.5f}, c={c:.5f} Å"
    return f"a={a:.5f}, b={b:.5f}, c={c:.5f} Å, β={beta:.4f}°"


def main() -> None:
    project = G2sc.G2Project(str(PROJECT_PATH))
    if len(project.histograms()) != 1:
        raise RuntimeError("expected exactly one refinement histogram")
    hist = project.histogram(0)
    if set(phase.name for phase in project.phases()) != set(PHASES):
        raise RuntimeError("final.gpx inventory does not match the submitted inventory")
    if project.get_Frozen():
        raise RuntimeError(f"final.gpx has frozen variables: {project.get_Frozen()}")

    fractions = hist.ComputeMassFracs()
    number_variables = len(
        project.data.get("Covariance", {}).get("data", {}).get("varyList", [])
    )
    statistics = exact_fit_statistics(hist, number_variables)
    checks = representative_profile_checks(hist)
    write_fit(hist)

    result_phases = []
    report_rows = []
    minimum_distances = {}
    for phase in project.phases():
        meta = PHASES[phase.name]
        phase.export_CIF(str(HERE / meta["cif_path"]))
        fraction, fraction_esd = fractions[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        space_group = phase.data["General"]["SGData"]["SpGrp"].strip()
        phase_number = phase.id
        minimum_distances[meta["formula"]] = minimum_distance(phase)
        result_phases.append(
            {
                "name": meta["name"],
                "formula": meta["formula"],
                "space_group": space_group,
                "cif_path": meta["cif_path"],
                "weight_fraction": float(fraction),
                "weight_fraction_standard_uncertainty": float(fraction_esd),
                "unit_cell": {key: float(value) for key, value in cell.items()},
                "unit_cell_standard_uncertainty": {
                    key: float(value) for key, value in cell_esd.items()
                },
                "phase_fit_statistics": {
                    "RF_percent": float(hist.residuals[f"{phase_number}:0:Rf"]),
                    "RF2_percent": float(hist.residuals[f"{phase_number}:0:Rf^2"]),
                    "number_reflections": int(
                        hist.residuals[f"{phase_number}:0:Nref"]
                    ),
                },
                "structure_source": meta["source"],
            }
        )
        report_rows.append(
            "| {name} | {sg} | {cell} | {wt:.2f} ± {esd:.2f} |".format(
                name=meta["name"],
                sg=space_group,
                cell=cell_text(cell),
                wt=100.0 * float(fraction),
                esd=100.0 * float(fraction_esd),
            )
        )

    fraction_sum = sum(item["weight_fraction"] for item in result_phases)
    if abs(fraction_sum - 1.0) > 1.0e-10:
        raise RuntimeError(f"crystalline fractions do not sum to one: {fraction_sum}")

    result = {
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
        "refinement_histogram": hist.name,
        "weight_fraction_basis": (
            "normalized over the modeled crystalline phases; amorphous or "
            "unidentified material is not quantified"
        ),
        "phases": result_phases,
        "modeled_crystalline_weight_fraction_sum": fraction_sum,
        "fit_statistics": statistics,
        "measurement_model": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "two_theta_range_deg": [
                float(hist.getdata("x")[0]),
                float(hist.getdata("x")[-1]),
            ],
            "number_original_points": len(hist.getdata("x")),
            "profile_checks": checks,
        },
    }
    (HERE / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    sample = hist.data["Sample Parameters"]
    instrument = hist.data["Instrument Parameters"][0]
    check_text = "; ".join(
        "({h} {k} {l}) at {pos:.2f}°: FWHM {fwhm:.3f}°, peak-max Δ {delta:+.3f}°".format(
            h=item["hkl"][0],
            k=item["hkl"][1],
            l=item["hkl"][2],
            pos=item["two_theta_deg"],
            fwhm=item["FWHM_deg"],
            delta=item["observed_minus_calculated_peak_max_deg"],
        )
        for item in checks
    )
    report = f"""# Crystalline phase analysis

The reportable crystalline inventory is wolframite MnWO₄ with residual monoclinic WO₃ and hausmannite Mn₃O₄. Fractions below are normalized only over these modeled crystalline phases; the quoted uncertainties are GSAS-II covariance estimates and do not include model-selection systematics.

| Phase | Space group | Refined cell | Weight percent |
|---|---|---|---:|
{chr(10).join(report_rows)}

## Evidence and structural models

The dominant peak families index coherently as P2/c wolframite. No exact MnWO₄ record was present in the supplied index, so the required stoichiometric-analogue search was used. Ordered MgWO₄ (COD 9013902) was substituted Mg→Mn because Mg²⁺ and Mn²⁺ occupy the same octahedral wolframite site; ordered ZnWO₄ and FeWO₄ parents and C2/m, scheelite, and triclinic alternatives were challenged under the same nuisance model. The Mg-derived model gave the best physical fit (the Zn-derived model was close), while the non-wolframite alternatives were poor or collapsed to zero scale. The staged coordinate test subsequently moved Mn and W by only 0.044 and 0.023 Å.

Residual families required WO₃. Ambient monoclinic P2₁/c WO₃ (COD 2311041) was retained over a triclinic record: the latter lowered Rwp by only 0.045 percentage point before coordinate completion while adding cell freedom. Both W sites passed the staged coordinate test with moves of 0.058 and 0.077 Å. Remaining distinct/partly overlapped lines, including the isolated hausmannite 103 family near 31.76°, support I4₁/amd Mn₃O₄ (COD 9001963); an alternate hausmannite record was nearly equivalent, whereas Pbcm Mn₃O₄ collapsed to zero scale.

The final heavy-site geometry is physical: minimum interatomic distances are {minimum_distances['MnWO4']:.3f} Å (MnWO₄), {minimum_distances['WO3']:.3f} Å (WO₃), and {minimum_distances['Mn3O4']:.3f} Å (Mn₃O₄), with no GSAS-II short-contact warnings. The fresh reopen/replay retained all accepted coordinate gains and had no frozen variables.

## Fit and profile adequacy

All 8,301 observations from 9.90343322–100.09455322° 2θ were replayed without rounding or resampling. The model uses the reported Cu Kα₁/Kα₂ wavelengths and 0.5 intensity ratio, a smooth six-coefficient Chebyshev background, one specimen-displacement correction ({sample['Shift'][0] / 1000.0:.4f} mm), nonnegative W/X profile terms ({instrument['W'][1]:.4f}/{instrument['X'][1]:.4f}), and replay-stable Suortti roughness ({sample['SurfRoughA'][0]:.4f}/{sample['SurfRoughB'][0]:.4f}). Size, strain, texture, transparency, zero shift, and extra asymmetry terms were not retained. Representative least-overlapped MnWO₄ families span low, middle, and high angle with smoothly increasing widths and no monotonic position error: {check_text}. No phase-specific width term was supported.

The exact final profile gives Rwp = {statistics['Rwp_percent']:.4f}%, Rp = {statistics['Rp_percent']:.4f}%, Rexp = {statistics['Rexp_percent']:.4f}%, and goodness of fit = {statistics['goodness_of_fit']:.3f} for {statistics['number_refined_variables']} refined variables. Because the input supplied no pointwise uncertainties, Poisson counting uncertainties were used; the goodness of fit is therefore not an independently calibrated absolute error test.

## Remaining uncertainty

The fractions are reliable as a three-phase crystalline normalization, but no internal standard was supplied, so amorphous content cannot be measured. The near-tied wolframite parent records and monoclinic/triclinic WO₃ descriptions are the main structural systematics; they are larger than the tabulated covariance-only fraction errors.

Mn₂O₃ remains a watch-list possibility, not a reported phase. In the final-profile re-challenge, cubic bixbyite refined to 1.43 wt% and improved Rwp by only 0.023 percentage point: its strongest residual match was coherent, but the expected line near 37.95° worsened. An orthorhombic record reached 2.10 wt% only by distorting its nearly cubic reference cell from about 9.41 Å to 9.28/9.27/9.62 Å. Thus neither its structure nor fraction can be determined reliably from this pattern. Final-profile MnO₂ and Mn₃WO₆ trials reached only 1.20 and 0.62 wt%, with Rwp gains of 0.014 and 0.008 percentage point, respectively; neither showed enough independent evidence to report.
"""
    (HERE / "report.md").write_text(report)

    print(
        json.dumps(
            {
                "project": str(PROJECT_PATH),
                "histogram": hist.name,
                "points": len(hist.getdata("x")),
                "fractions": {
                    item["formula"]: item["weight_fraction"]
                    for item in result_phases
                },
                "fit_statistics": statistics,
                "outputs": [
                    "fit.csv",
                    "result.json",
                    "report.md",
                    *[item["cif_path"] for item in result_phases],
                ],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
