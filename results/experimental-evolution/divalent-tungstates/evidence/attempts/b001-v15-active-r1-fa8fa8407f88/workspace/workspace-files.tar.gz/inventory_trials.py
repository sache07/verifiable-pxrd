#!/usr/bin/env python3
"""Challenge plausible residual phases against a common wolframite profile."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from source_trials import neutralize_hap


HERE = Path(__file__).resolve().parent
WORK = HERE / "work"
BASE = WORK / "trial_wolframite_mg9013902.gpx"
COD_ROOT = Path(
    "<RUN>/"
    "resources/b001-c04/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = {
    "WO3_triclinic_2106293": cod_path("2106293"),
    "WO3_monoclinic_2311041": cod_path("2311041"),
    "WO3_monoclinic_1563541": cod_path("1563541"),
    "WO3_monoclinic_1528915": cod_path("1528915"),
    "Mn3O4_hausmannite_9001963": cod_path("9001963"),
    "Mn2O3_bixbyite_1514230": cod_path("1514230"),
    "Mn3WO6_2002703": cod_path("2002703"),
}


def replay(path: Path, count: int) -> G2sc.G2Project:
    project = G2sc.G2Project(str(path))
    for _ in range(count):
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(path))
    return project


def summary(project: G2sc.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    return {
        "stage": stage,
        "Rwp": float(hist.residuals.get("wR", float("nan"))),
        "GOF": float(
            project.data.get("Covariance", {})
            .get("data", {})
            .get("Rvals", {})
            .get("GOF", float("nan"))
        ),
        "fractions": {
            str(name): [float(value[0]), float(value[1])]
            for name, value in fractions.items()
        },
        "scales": {
            phase.name: float(phase.getHAPvalues(hist)["Scale"][0])
            for phase in project.phases()
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "shift_um": float(hist.data["Sample Parameters"]["Shift"][0]),
        "profile": {
            key: float(hist.data["Instrument Parameters"][0][key][1])
            for key in ("U", "W", "X", "SH/L")
        },
        "frozen": list(map(str, project.get_Frozen() or [])),
    }


def run_one(name: str, cif: Path) -> dict:
    path = WORK / f"inventory_{name}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(path))
    hist = project.histogram(0)
    main = project.phase(0)

    # First challenge only the new phase scale against the exact common
    # background/profile/cell checkpoint.
    main.set_refinements({"Cell": False})
    main.set_HAP_refinements({"Scale": True}, [hist])
    hist.clear_refinements(
        {
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["W", "X", "SH/L"],
        }
    )
    phase = project.add_phase(
        str(cif), phasename=name, histograms=[hist], fmthint="CIF"
    )
    neutralize_hap(phase, hist)
    phase.getHAPvalues(hist)["Scale"] = [1.0, True]
    phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
    project.set_Frozen()
    project.set_Controls("cycles", 14)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.save()
    project = replay(path, 1)
    stages = [summary(project, "scale_on_common_checkpoint")]

    # If the phase has coherent intensity, allow the inventory change to
    # rebuild cells, one angular correction and the W/X common profile.
    for p in project.phases():
        p.set_refinements({"Cell": True})
        p.set_HAP_refinements({"Scale": True}, [project.histogram(0)])
    project.histogram(0).set_refinements(
        {
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["W", "X"],
        }
    )
    project.save()
    project = replay(path, 2)
    stages.append(summary(project, "reconverged_inventory"))
    project.save()
    return {
        "candidate": name,
        "source_cif": str(cif),
        "project": str(path),
        "stages": stages,
        "final": stages[-1],
    }


def main() -> None:
    results = []
    for name, cif in CANDIDATES.items():
        try:
            results.append(run_one(name, cif))
        except Exception as exc:
            results.append(
                {"candidate": name, "source_cif": str(cif), "error": repr(exc)}
            )
    output = WORK / "inventory_trials_summary.json"
    output.write_text(json.dumps(results, indent=2, default=float) + "\n")
    print(json.dumps(results, indent=2, default=float))


if __name__ == "__main__":
    main()
