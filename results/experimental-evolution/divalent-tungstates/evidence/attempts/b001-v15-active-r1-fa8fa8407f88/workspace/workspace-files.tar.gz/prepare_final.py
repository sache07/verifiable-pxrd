#!/usr/bin/env python3
"""Create and replay the selected physical GSAS-II checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
SOURCE = HERE / "work" / "physical_rough_multistart_1.gpx"
OUTPUT = HERE / "final.gpx"


def max_shift(project: G2sc.G2Project) -> float | None:
    value = (
        project.data.get("Covariance", {})
        .get("data", {})
        .get("Rvals", {})
        .get("Max shft/sig")
    )
    return None if value is None else float(value)


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    project.set_Controls("cycles", 16)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-7
    project.set_Frozen()
    project.save()

    history = []
    for replay in range(6):
        project = G2sc.G2Project(str(OUTPUT))
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(OUTPUT))
        shift = max_shift(project)
        history.append(
            {
                "replay": replay + 1,
                "Rwp": float(project.histogram(0).residuals["wR"]),
                "max_shift_over_esd": shift,
            }
        )
        if shift is not None and abs(shift) < 0.05:
            break

    hist = project.histogram(0)
    result = {
        "history": history,
        "histogram": hist.name,
        "points": len(hist.getdata("x")),
        "phases": [phase.name for phase in project.phases()],
        "fractions": {
            key: [float(value[0]), float(value[1])]
            for key, value in hist.ComputeMassFracs().items()
        },
        "frozen": list(map(str, project.get_Frozen() or [])),
        "vary_list": list(
            project.data.get("Covariance", {}).get("data", {}).get("varyList", [])
        ),
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
