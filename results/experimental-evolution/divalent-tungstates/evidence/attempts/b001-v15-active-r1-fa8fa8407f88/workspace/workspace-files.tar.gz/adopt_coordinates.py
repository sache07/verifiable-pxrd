#!/usr/bin/env python3
"""Adopt the accepted heavy-coordinate project and verify a fresh replay."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
SOURCE = HERE / "coordinated.gpx"
OUTPUT = HERE / "final.gpx"


def max_shift(project: G2sc.G2Project) -> float | None:
    value = (
        project.data.get("Covariance", {})
        .get("data", {})
        .get("Rvals", {})
        .get("Max shft/sig")
    )
    return None if value is None else float(value)


def main() -> None:
    source = G2sc.G2Project(str(SOURCE))
    source_rwp = float(source.histogram(0).residuals["wR"])
    accepted_flags = {
        phase.name: {
            atom.label: atom.refinement_flags
            for atom in phase.atoms()
            if "X" in atom.refinement_flags
        }
        for phase in source.phases()
    }
    accepted_flags = {key: value for key, value in accepted_flags.items() if value}
    if not accepted_flags:
        raise RuntimeError("coordinated.gpx contains no accepted coordinate flags")

    project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    project.set_Controls("cycles", 16)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-7
    project.save()

    reopened_before = G2sc.G2Project(str(OUTPUT))
    before_rwp = float(reopened_before.histogram(0).residuals["wR"])
    reopened_before.refine(makeBack=False)
    reopened_before.save()
    final = G2sc.G2Project(str(OUTPUT))
    after_rwp = float(final.histogram(0).residuals["wR"])

    if before_rwp > source_rwp + 1.0e-8 or after_rwp > source_rwp + 0.003:
        raise RuntimeError("fresh reopen/replay did not preserve the accepted gain")

    hist = final.histogram(0)
    print(
        json.dumps(
            {
                "source_Rwp": source_rwp,
                "fresh_reopen_Rwp": before_rwp,
                "fresh_replay_Rwp": after_rwp,
                "max_shift_over_esd": max_shift(final),
                "points": len(hist.getdata("x")),
                "coordinate_flags": accepted_flags,
                "fractions": {
                    key: [float(value[0]), float(value[1])]
                    for key, value in hist.ComputeMassFracs().items()
                },
                "frozen": list(map(str, final.get_Frozen() or [])),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
