#!/usr/bin/env python3
"""Reversible profile, sample-broadening and texture trials."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
WORK = HERE / "work"
SOURCE = WORK / "rechallenge_Mn3O4_hausmannite_9001963.gpx"
CHECKPOINT = WORK / "nuisance_checkpoint.gpx"


def replay(path: Path, count: int = 2) -> G2sc.G2Project:
    project = G2sc.G2Project(str(path))
    for _ in range(count):
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(path))
    return project


def make_checkpoint() -> G2sc.G2Project:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(CHECKPOINT))
    project.set_Frozen()
    project.set_Controls("cycles", 16)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "Y", "Z", "SH/L"):
        inst[key][2] = False
    inst["U"][0] = inst["U"][1] = 0.0
    inst["V"][0] = inst["V"][1] = 0.0
    inst["Y"][0] = inst["Y"][1] = 0.0
    inst["Z"][0] = inst["Z"][1] = 0.0
    inst["SH/L"][0] = inst["SH/L"][1] = 0.002
    for key in ("SurfRoughA", "SurfRoughB", "Transparency"):
        hist.data["Sample Parameters"][key] = [0.0, False]
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [1.0e6, 1.0e6, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
    project.save()
    return replay(CHECKPOINT, 2)


def snapshot(project: G2sc.G2Project, trial: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    fractions = hist.ComputeMassFracs()
    phases = {}
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        phases[phase.name] = {
            "size_type": hap["Size"][0],
            "size_values": [float(v) for v in hap["Size"][1]],
            "size_flags": [bool(v) for v in hap["Size"][2]],
            "mustrain_type": hap["Mustrain"][0],
            "mustrain_values": [float(v) for v in hap["Mustrain"][1]],
            "mustrain_flags": [bool(v) for v in hap["Mustrain"][2]],
            "preferred_orientation": [
                hap["Pref.Ori."][0],
                float(hap["Pref.Ori."][1]),
                bool(hap["Pref.Ori."][2]),
                [int(v) for v in hap["Pref.Ori."][3]],
            ],
        }
    return {
        "trial": trial,
        "project": str(project.filename),
        "Rwp": float(hist.residuals.get("wR", float("nan"))),
        "GOF": float(
            project.data.get("Covariance", {})
            .get("data", {})
            .get("Rvals", {})
            .get("GOF", float("nan"))
        ),
        "instrument": {
            key: float(inst[key][1])
            for key in ("Polariz.", "U", "V", "W", "X", "Y", "SH/L")
        },
        "sample": {
            key: float(hist.data["Sample Parameters"][key][0])
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "fractions": {name: float(value[0]) for name, value in fractions.items()},
        "phases": phases,
        "frozen": list(map(str, project.get_Frozen() or [])),
    }


def copy_trial(tag: str) -> tuple[Path, G2sc.G2Project]:
    path = WORK / f"nuisance_{tag}.gpx"
    project = G2sc.G2Project(str(CHECKPOINT), newgpx=str(path))
    project.set_Frozen()
    project.save()
    return path, project


def instrument_trial(tag: str, parameter: str, initial: float) -> dict:
    path, project = copy_trial(tag)
    inst = project.histogram(0).data["Instrument Parameters"][0]
    inst[parameter][0] = inst[parameter][1] = initial
    project.histogram(0).set_refinements(
        {"Instrument Parameters": [parameter]}
    )
    project.save()
    return snapshot(replay(path), tag)


def roughness_trial() -> dict:
    path, project = copy_trial("surface_roughness")
    sample = project.histogram(0).data["Sample Parameters"]
    sample["SurfRoughA"] = [0.9, True]
    sample["SurfRoughB"] = [0.01, True]
    project.save()
    return snapshot(replay(path), "surface_roughness")


def broadening_trial(phase_index: int, mode: str) -> dict:
    target_tag = ("mnwo4", "wo3", "mn3o4")[phase_index]
    tag = f"{target_tag}_{mode}"
    path, project = copy_trial(tag)
    phase = project.phase(phase_index)
    hist = project.histogram(0)
    if mode in ("size", "size_strain"):
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": 1.0,
                    "refine": True,
                    "LGmix": {"value": 0.5, "refine": False},
                }
            },
            [hist],
        )
    if mode in ("strain", "size_strain"):
        hap = phase.getHAPvalues(hist)
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][2] = 0.5
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 0.5, "refine": False},
                }
            },
            [hist],
        )
    project.save()
    return snapshot(replay(path), tag)


def texture_trial(phase_index: int, axis: tuple[int, int, int]) -> dict:
    phase_tag = ("mnwo4", "wo3", "mn3o4")[phase_index]
    axis_tag = "".join(map(str, axis))
    tag = f"texture_{phase_tag}_{axis_tag}"
    path, project = copy_trial(tag)
    hap = project.phase(phase_index).getHAPvalues(project.histogram(0))
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    project.save()
    return snapshot(replay(path), tag)


def main() -> None:
    checkpoint = make_checkpoint()
    results = [snapshot(checkpoint, "neutral_checkpoint")]
    results.append(instrument_trial("instrument_U", "U", 1.0))
    results.append(instrument_trial("axial_SH_L", "SH/L", 0.02))
    results.append(instrument_trial("polarization", "Polariz.", 0.5))
    try:
        results.append(roughness_trial())
    except Exception as exc:
        results.append({"trial": "surface_roughness", "error": repr(exc)})
    for phase_index in range(3):
        for mode in ("size", "strain", "size_strain"):
            try:
                results.append(broadening_trial(phase_index, mode))
            except Exception as exc:
                results.append(
                    {
                        "trial": f"phase{phase_index}_{mode}",
                        "error": repr(exc),
                    }
                )
    axes = {
        0: [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (1, 1, 1)],
        1: [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (1, 1, 1)],
        2: [(1, 0, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (1, 1, 1)],
    }
    for phase_index, phase_axes in axes.items():
        for axis in phase_axes:
            try:
                results.append(texture_trial(phase_index, axis))
            except Exception as exc:
                results.append(
                    {
                        "trial": f"texture_phase{phase_index}_{axis}",
                        "error": repr(exc),
                    }
                )
    output = WORK / "nuisance_trials_summary.json"
    output.write_text(json.dumps(results, indent=2, default=float) + "\n")
    print(json.dumps(results, indent=2, default=float))


if __name__ == "__main__":
    main()
