#!/usr/bin/env python3
"""Re-challenge weak phases after establishing MnWO4 + monoclinic WO3."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from source_trials import neutralize_hap


HERE = Path(__file__).resolve().parent
WORK = HERE / "work"
BASE = WORK / "inventory_WO3_monoclinic_2311041.gpx"
COD_ROOT = Path(
    "<RUN>/"
    "resources/b001-c04/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = {
    "Mn3O4_hausmannite_9001963": cod_path("9001963"),
    "Mn3O4_hausmannite_1011262": cod_path("1011262"),
    "Mn3O4_Pbcm_1541183": cod_path("1541183"),
    "Mn2O3_bixbyite_1514230": cod_path("1514230"),
    "MnO_rocksalt_1514108": cod_path("1514108"),
    "MnO2_rutile_1514110": cod_path("1514110"),
    "Mn3WO6_2002703": cod_path("2002703"),
}


def replay(path: Path, count: int) -> G2sc.G2Project:
    project = G2sc.G2Project(str(path))
    for _ in range(count):
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(path))
    return project


def summary(project: G2sc.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    return {
        "stage": stage,
        "Rwp": float(hist.residuals.get("wR", float("nan"))),
        "fractions": {
            str(name): [float(value[0]), float(value[1])]
            for name, value in fractions.items()
        },
        "scales": {
            phase.name: float(phase.getHAPvalues(hist)["Scale"][0])
            for phase in project.phases()
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "shift_um": float(hist.data["Sample Parameters"]["Shift"][0]),
        "profile": {
            key: float(hist.data["Instrument Parameters"][0][key][1])
            for key in ("U", "W", "X", "SH/L")
        },
        "frozen": list(map(str, project.get_Frozen() or [])),
    }


def run_one(name: str, cif: Path) -> dict:
    path = WORK / f"rechallenge_{name}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(path))
    hist = project.histogram(0)
    for existing in project.phases():
        existing.set_refinements({"Cell": False})
        existing.set_HAP_refinements({"Scale": True}, [hist])
    hist.clear_refinements(
        {
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["W", "X", "SH/L"],
        }
    )
    phase = project.add_phase(
        str(cif), phasename=name, histograms=[hist], fmthint="CIF"
    )
    neutralize_hap(phase, hist)
    phase.getHAPvalues(hist)["Scale"] = [0.5, True]
    phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
    project.set_Frozen()
    project.set_Controls("cycles", 14)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.save()
    project = replay(path, 1)
    stages = [summary(project, "scale_on_two_phase_checkpoint")]

    for item in project.phases():
        item.set_refinements({"Cell": True})
        item.set_HAP_refinements({"Scale": True}, [project.histogram(0)])
    project.histogram(0).set_refinements(
        {
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["W", "X"],
        }
    )
    project.save()
    project = replay(path, 2)
    stages.append(summary(project, "reconverged_three_phase"))
    project.save()
    return {
        "candidate": name,
        "source_cif": str(cif),
        "project": str(path),
        "stages": stages,
        "final": stages[-1],
    }


def main() -> None:
    results = []
    for name, cif in CANDIDATES.items():
        try:
            results.append(run_one(name, cif))
        except Exception as exc:
            results.append(
                {"candidate": name, "source_cif": str(cif), "error": repr(exc)}
            )
    output = WORK / "rechallenge_trials_summary.json"
    output.write_text(json.dumps(results, indent=2, default=float) + "\n")
    print(json.dumps(results, indent=2, default=float))


if __name__ == "__main__":
    main()
