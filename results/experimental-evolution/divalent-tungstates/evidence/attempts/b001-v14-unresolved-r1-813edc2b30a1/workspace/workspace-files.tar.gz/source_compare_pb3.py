#!/usr/bin/env python3
"""Matched three-phase comparison for alternative Pb3O4 source records."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PBWO4_ID = "9009811"
WO3_ID = "2311041"


def cif_path(cod_id: str) -> str:
    return str(ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif")


def set_inactive_hap_terms(phase, hist) -> dict:
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    return hap


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("tag")
    parser.add_argument("pb3_cod_id")
    parser.add_argument(
        "--pb3-width", choices=("neutral", "size", "both"), default="both"
    )
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    mature = G2sc.G2Project("texture3_collect_PbWO4a_WO3b.gpx")
    mature_hist = mature.histogram(0)
    mature_inst = mature_hist.data["Instrument Parameters"][0]
    mature_bg = list(mature_hist.data["Background"][0][3:])

    project = G2sc.G2Project(newgpx=f"source3_pb3_{args.tag}.gpx")
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "cu_kalpha.instprm", fmthint="comma"
    )
    pbwo4 = project.add_phase(
        cif_path(PBWO4_ID), phasename="PbWO4", histograms=[hist], fmthint="CIF"
    )
    wo3 = project.add_phase(
        cif_path(WO3_ID), phasename="WO3", histograms=[hist], fmthint="CIF"
    )
    pb3 = project.add_phase(
        cif_path(args.pb3_cod_id), phasename="Pb3O4", histograms=[hist], fmthint="CIF"
    )
    project.set_Controls("cycles", 20)
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [9.90343322, 100.09455322],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": mature_bg,
                "refine": True,
            },
        }
    )
    inst = hist.data["Instrument Parameters"][0]
    for key in ("Zero", "U", "W", "X"):
        inst[key][0] = mature_inst[key][1]
        inst[key][1] = mature_inst[key][1]
        inst[key][2] = False
    for key, value in {
        "V": 0.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "Polariz.": 0.7,
        "I(L2)/I(L1)": 0.5,
    }.items():
        inst[key][0] = value
        inst[key][1] = value
        inst[key][2] = False

    mature_scales = {p.name: p.data["Histograms"][mature_hist.name]["Scale"][0]
                     for p in mature.phases()}
    haps = {}
    for phase in (pbwo4, wo3, pb3):
        hap = set_inactive_hap_terms(phase, hist)
        hap["Scale"] = [mature_scales[phase.name], True]
        phase.set_refinements({"Cell": False})
        haps[phase.name] = hap

    # Matched mature basis: cells, nonnegative U/W/X, supported phase widths,
    # and the compact texture leaders on PbWO4 and WO3. All flags are set
    # before the first refinement so no scriptable handles become stale.
    for phase in (pbwo4, wo3, pb3):
        phase.set_refinements({"Cell": True})
    for key in ("Zero", "U", "W", "X"):
        inst[key][2] = True
    haps["PbWO4"]["Size"][1][0] = 0.064
    haps["PbWO4"]["Size"][2][0] = True
    if args.pb3_width in ("size", "both"):
        haps["Pb3O4"]["Size"][1][0] = 0.039
        haps["Pb3O4"]["Size"][2][0] = True
    if args.pb3_width == "both":
        haps["Pb3O4"]["Mustrain"][1][0] = 1955.0
        haps["Pb3O4"]["Mustrain"][2][0] = True
    for name, axis, ratio in (
        ("PbWO4", [1, 0, 0], 1.021),
        ("WO3", [0, 1, 0], 1.010),
    ):
        haps[name]["Pref.Ori."][1] = ratio
        haps[name]["Pref.Ori."][2] = True
        haps[name]["Pref.Ori."][3] = axis

    for _ in range(6):
        project.refine()
    project.save()

    covariance = project.data["Covariance"]["data"]
    rvals = covariance.get("Rvals", {})
    result = {
        "tag": args.tag,
        "pb3_cod_id": args.pb3_cod_id,
        "pb3_width_model": args.pb3_width,
        "wR": hist.get_wR(),
        "chisq": rvals.get("chisq"),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "SVD0": rvals.get("SVD0"),
        "message": rvals.get("msg"),
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {key: inst[key][1] for key in ("Zero", "U", "W", "X")},
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size_um": hap["Size"][1][0],
            "microstrain": hap["Mustrain"][1][0],
            "march_ratio": hap["Pref.Ori."][1],
        }
    print("PB3_SOURCE_RESULT " + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
