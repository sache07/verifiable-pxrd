#!/usr/bin/env python3
"""Test one March-Dollase axis against the mature neutral checkpoint."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=["PbWO4", "WO3", "Pb3O4"])
    parser.add_argument("tag")
    parser.add_argument("h", type=int)
    parser.add_argument("k", type=int)
    parser.add_argument("l", type=int)
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(
        "profile3_UWX.gpx",
        newgpx=f"texture3_{args.phase}_{args.tag}.gpx",
    )
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = [args.h, args.k, args.l]
    project.set_Controls("cycles", 20)
    for _ in range(4):
        project.refine()
    project.save()

    covariance = project.data["Covariance"]["data"]
    rvals = covariance.get("Rvals", {})
    sigmas = dict(zip(covariance.get("varyList", []), covariance.get("sig", [])))
    md_sigma = None
    for name, sigma in sigmas.items():
        if name.endswith(":MD") and name.startswith(f"{phase.id}:"):
            md_sigma = sigma
            break
    result = {
        "phase": args.phase,
        "axis": [args.h, args.k, args.l],
        "ratio": hap["Pref.Ori."][1],
        "ratio_sigma": md_sigma,
        "wR": hist.get_wR(),
        "chisq": rvals.get("chisq"),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "SVD0": rvals.get("SVD0"),
        "message": rvals.get("msg"),
        "mass_fractions": hist.ComputeMassFracs(),
    }
    print("TEXTURE_RESULT " + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
