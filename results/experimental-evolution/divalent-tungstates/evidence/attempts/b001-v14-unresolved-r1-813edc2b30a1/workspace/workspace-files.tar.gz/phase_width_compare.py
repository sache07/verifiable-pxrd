#!/usr/bin/env python3
"""Compare one phase's isotropic size/strain model from a neutral checkpoint."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=["PbWO4", "WO3", "Pb3O4"])
    parser.add_argument("mode", choices=["size", "strain", "both"])
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    tag = f"{args.phase}_{args.mode}"
    project = G2sc.G2Project(
        "checkpoint_three_allneutral.gpx", newgpx=f"width3_{tag}.gpx"
    )
    hist = project.histogram(0)
    hap = project.phase(args.phase).data["Histograms"][hist.name]
    if args.mode in ("size", "both"):
        seed = 0.5 if args.phase == "WO3" else 0.1
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [seed, seed, 1.0]
        hap["Size"][2][:] = [True, False, False]
    if args.mode in ("strain", "both"):
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [1000.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [True, False, False]
    project.set_Controls("cycles", 20)
    for _ in range(4):
        project.refine()
    project.save()

    covariance = project.data["Covariance"]["data"]
    rvals = covariance.get("Rvals", {})
    result = {
        "phase": args.phase,
        "mode": args.mode,
        "wR": hist.get_wR(),
        "chisq": rvals.get("chisq"),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "SVD0": rvals.get("SVD0"),
        "message": rvals.get("msg"),
        "mass_fractions": hist.ComputeMassFracs(),
        "phases": {},
    }
    for phase in project.phases():
        phase_hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "scale": phase_hap["Scale"][0],
            "size_um": phase_hap["Size"][1][0],
            "size_refined": phase_hap["Size"][2][0],
            "microstrain": phase_hap["Mustrain"][1][0],
            "strain_refined": phase_hap["Mustrain"][2][0],
        }
    print("WIDTH_RESULT " + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
