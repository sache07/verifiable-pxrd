#!/usr/bin/env python3
"""Run a matched GSAS-II source-record comparison in a fresh process."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id: str) -> str:
    return str(ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("tag")
    parser.add_argument("pb_cod_id")
    parser.add_argument("wo3_cod_id")
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    leader = G2sc.G2Project("branch_strain_literal_WX.gpx")
    leader_hist = leader.histogram(0)
    leader_background = list(leader_hist.data["Background"][0][3:])
    leader_inst = leader_hist.data["Instrument Parameters"][0]

    project = G2sc.G2Project(newgpx=f"source_{args.tag}.gpx")
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "cu_kalpha.instprm", fmthint="comma"
    )
    pb = project.add_phase(
        cif_path(args.pb_cod_id),
        phasename="PbWO4",
        histograms=[hist],
        fmthint="CIF",
    )
    wo3 = project.add_phase(
        cif_path(args.wo3_cod_id),
        phasename="WO3",
        histograms=[hist],
        fmthint="CIF",
    )
    project.set_Controls("cycles", 20)
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [9.90343322, 100.09455322],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": leader_background,
                "refine": True,
            },
        }
    )
    inst = hist.data["Instrument Parameters"][0]
    start = {
        "Zero": leader_inst["Zero"][1],
        "U": 0.0,
        "V": 0.0,
        "W": leader_inst["W"][1],
        "X": leader_inst["X"][1],
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "Polariz.": 0.7,
        "I(L2)/I(L1)": 0.5,
    }
    for key, value in start.items():
        inst[key][0] = value
        inst[key][1] = value
        inst[key][2] = False

    for phase, scale in ((pb, 8.43), (wo3, 2.90)):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        phase.set_refinements({"Cell": False})

    project.refine()
    pb.set_refinements({"Cell": True})
    wo3.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero", "W", "X"]})
    pb_hap = pb.data["Histograms"][hist.name]
    pb_hap["Size"][1][0] = 0.05
    pb_hap["Size"][2][0] = True
    wo3_hap = wo3.data["Histograms"][hist.name]
    wo3_hap["Mustrain"][1][0] = 2000.0
    wo3_hap["Mustrain"][2][0] = True
    for _ in range(4):
        project.refine()
    project.save()

    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    result = {
        "tag": args.tag,
        "pb_cod_id": args.pb_cod_id,
        "wo3_cod_id": args.wo3_cod_id,
        "wR": hist.get_wR(),
        "chisq": rvals.get("chisq"),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "SVD0": rvals.get("SVD0"),
        "message": rvals.get("msg"),
        "instrument": {key: inst[key][1] for key in ("Zero", "U", "W", "X")},
        "mass_fractions": hist.ComputeMassFracs(),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size_um": hap["Size"][1][0],
            "microstrain": hap["Mustrain"][1][0],
        }
    print("SOURCE_RESULT " + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
