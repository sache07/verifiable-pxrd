#!/usr/bin/env python3
"""Freeze, replay, validate and export the final three-phase GSAS-II model."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


SOURCE = "texture3_collect_PbWO4a_WO3b.gpx"
PROJECT = "final.gpx"
CIFS = {
    "PbWO4": "phase_PbWO4.cif",
    "WO3": "phase_WO3.cif",
    "Pb3O4": "phase_Pb3O4.cif",
}


def enforce_model(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    project.set_Controls("cycles", 20)
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    hist.data["Background"][0][0] = "chebyschev-1"
    hist.data["Background"][0][1] = True
    hist.data["Background"][0][2] = 8

    sample = hist.data["Sample Parameters"]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key] = [0.0, False]
    sample["Scale"] = [1.0, False]

    inst = hist.data["Instrument Parameters"][0]
    for key, value in {
        "Lam1": 1.540598,
        "Lam2": 1.544426,
        "I(L2)/I(L1)": 0.5,
        "Polariz.": 0.7,
        "V": 0.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }.items():
        inst[key][0] = value
        inst[key][1] = value
        inst[key][2] = False
    for key in ("Zero", "U", "W", "X"):
        inst[key][2] = True

    settings = {
        "PbWO4": {
            "size": (None, True),
            "strain": (0.0, False),
            "axis": [1, 0, 0],
            "texture": True,
        },
        "WO3": {
            "size": (10.0, False),
            "strain": (0.0, False),
            "axis": [0, 1, 0],
            "texture": True,
        },
        "Pb3O4": {
            "size": (None, True),
            "strain": (None, True),
            "axis": [0, 0, 1],
            "texture": False,
        },
    }
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        size_value, size_flag = settings[phase.name]["size"]
        if size_value is not None:
            hap["Size"][1][0] = size_value
        hap["Size"][2][:] = [size_flag, False, False]
        hap["Mustrain"][0] = "isotropic"
        strain_value, strain_flag = settings[phase.name]["strain"]
        if strain_value is not None:
            hap["Mustrain"][1][0] = strain_value
        hap["Mustrain"][2][:] = [strain_flag, False, False]
        hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][2] = settings[phase.name]["texture"]
        hap["Pref.Ori."][3] = settings[phase.name]["axis"]
        if not settings[phase.name]["texture"]:
            hap["Pref.Ori."][1] = 1.0


def rvals(project: G2sc.G2Project) -> dict:
    return project.data["Covariance"]["data"].get("Rvals", {})


def validate(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    assert all(inst[key][1] >= 0 for key in ("U", "W", "X"))
    assert hist.data["Limits"][1] == list(hist.data["Limits"][0])
    assert hist.data["Sample Parameters"]["SurfRoughA"] == [0.0, False]
    assert hist.data["Sample Parameters"]["SurfRoughB"] == [0.0, False]
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        assert hap["Scale"][0] > 0
        assert hap["Size"][1][0] > 0
        assert hap["Mustrain"][1][0] >= 0
        assert hap["Pref.Ori."][1] > 0
    rv = rvals(project)
    assert rv.get("converged") is True
    assert rv.get("SVD0", 0) == 0


def summarize(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    rv = rvals(project)
    inst = hist.data["Instrument Parameters"][0]
    result = {
        "Rwp_percent": hist.get_wR(),
        "Rp_percent": hist.data["data"][0].get("R"),
        "GOF": rv.get("GOF"),
        "chi_squared": rv.get("chisq"),
        "Nobs": rv.get("Nobs"),
        "Nvars": rv.get("Nvars"),
        "max_shift_over_esd": rv.get("Max shft/sig"),
        "durbin_watson": hist.data["data"][0].get("Durbin-Watson"),
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {key: inst[key][1] for key in ("Zero", "U", "W", "X")},
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size_um": hap["Size"][1][0],
            "microstrain": hap["Mustrain"][1][0],
            "march_ratio": hap["Pref.Ori."][1],
            "march_axis": hap["Pref.Ori."][3],
        }
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(SOURCE, newgpx=PROJECT)
    enforce_model(project)
    for _ in range(4):
        project.refine()
    project.save()

    # Independent reopen/replay of the complete full-range project.
    replay = G2sc.G2Project(PROJECT)
    validate(replay)
    hist = replay.histogram(0)
    before_calc = np.asarray(hist.data["data"][1][3]).copy()
    before_fracs = {k: v[0] for k, v in hist.ComputeMassFracs().items()}
    before_rwp = hist.get_wR()
    replay.refine()
    replay.save()

    final = G2sc.G2Project(PROJECT)
    validate(final)
    final_hist = final.histogram(0)
    after_calc = np.asarray(final_hist.data["data"][1][3])
    after_fracs = {k: v[0] for k, v in final_hist.ComputeMassFracs().items()}

    for phase in final.phases():
        phase.export_CIF(CIFS[phase.name])

    profile = np.asarray(final_hist.data["data"][1])
    x, observed, calculated = profile[0], profile[1], profile[3]
    with Path("fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "difference"]
        )
        writer.writerows(
            zip(x, observed, calculated, np.asarray(observed) - np.asarray(calculated))
        )

    audit = {
        "replay": {
            "Rwp_before_percent": before_rwp,
            "Rwp_after_percent": final_hist.get_wR(),
            "max_abs_calculated_change": float(np.max(np.abs(after_calc - before_calc))),
            "max_abs_fraction_change": max(
                abs(after_fracs[key] - before_fracs[key]) for key in before_fracs
            ),
        },
        "final": summarize(final),
        "cifs": CIFS,
    }
    print("FINAL_AUDIT " + json.dumps(audit, sort_keys=True))


if __name__ == "__main__":
    main()
