#!/usr/bin/env python3
"""Compare literal nonnegative common U/W/X profile combinations."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("terms", choices=["U", "W", "X", "UW", "UX", "WX", "UWX"])
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(
        "width3_collect_Pb3O4_both.gpx",
        newgpx=f"profile3_{args.terms}.gpx",
    )
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    seeds = {"U": 10.0, "W": 20.0, "X": 5.0}
    for key, seed in seeds.items():
        value = seed if key in args.terms else 0.0
        inst[key][0] = value
        inst[key][1] = value
        inst[key][2] = key in args.terms
    project.set_Controls("cycles", 20)
    for _ in range(4):
        project.refine()
    project.save()
    covariance = project.data["Covariance"]["data"]
    rvals = covariance.get("Rvals", {})
    sigmas = dict(zip(covariance.get("varyList", []), covariance.get("sig", [])))
    result = {
        "terms": args.terms,
        "wR": hist.get_wR(),
        "chisq": rvals.get("chisq"),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "SVD0": rvals.get("SVD0"),
        "message": rvals.get("msg"),
        "instrument": {
            key: {"value": inst[key][1], "sigma": sigmas.get(f":0:{key}")}
            for key in ("U", "W", "X")
        },
        "mass_fractions": hist.ComputeMassFracs(),
    }
    print("PROFILE_RESULT " + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
