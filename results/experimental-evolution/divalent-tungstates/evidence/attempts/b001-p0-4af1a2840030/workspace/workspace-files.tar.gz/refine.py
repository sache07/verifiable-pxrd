#!/usr/bin/env python3
"""Build and refine the GSAS-II model for the supplied PXRD pattern."""

import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
PATTERN = ROOT / "inputs" / "pattern.csv"
GPX = ROOT / "final.gpx"
FIT_CSV = ROOT / "fit.csv"
RESULT_JSON = ROOT / "result.json"
REPORT_MD = ROOT / "report.md"
PHASE_CIF = ROOT / "CaWO4_scheelite.cif"
SOURCE_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/7/21/92/7219229.cif"
)


def prepare_inputs():
    """Convert the supplied CSV to GSAS-II's simple xye input format."""
    TMP.mkdir(exist_ok=True)
    arr = np.loadtxt(PATTERN, delimiter=",", skiprows=1)
    xye = TMP / "pattern.xye"
    # Counting uncertainties were not supplied. Since the data are original
    # counts, sqrt(I) is the least-assumptive pointwise counting uncertainty.
    np.savetxt(
        xye,
        np.column_stack((arr[:, 0], arr[:, 1], np.sqrt(np.maximum(arr[:, 1], 1.0)))),
        fmt=("%.8f", "%.8g", "%.8g"),
        header="two_theta_deg intensity_counts sigma_counts",
    )
    inst = TMP / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for Cu Kalpha reflection data\n"
        "Type:PXC;Bank:1;Diff-type:Bragg-Brentano\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;"
        "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:5.0;V:0.0;W:35.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )
    return xye, inst


def show_state(tag, project, hist, phase):
    print(f"\n--- {tag} ---")
    print("residuals", hist.residuals)
    print("cell", phase.get_cell())
    print(
        "instrument",
        {k: v for k, v in hist.InstrumentParameters.items()
         if k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)")},
    )
    print("background", hist.Background[0])
    print("sample", hist.SampleParameters)
    print("HAP", phase.getHAPvalues(hist.name))
    print(
        "atoms",
        [(a.label, a.element, a.coordinates, a.uiso, a.refinement_flags) for a in phase.atoms()],
    )
    cov = project.data.get("Covariance", {}).get("data", {})
    print("GOF", cov.get("Rvals", {}).get("GOF"), "Nvars", len(cov.get("varyList", [])))


def write_deliverables(project, hist, phase):
    """Export all requested outputs from the final in-memory project."""
    project.save(str(GPX))
    phase.export_CIF(str(PHASE_CIF))

    x = np.asarray(hist.getdata("X"))
    observed = np.asarray(hist.getdata("Yobs"))
    calculated = np.asarray(hist.getdata("Ycalc"))
    difference = np.asarray(hist.getdata("Residual"))
    background = np.asarray(hist.getdata("Background"))
    np.savetxt(
        FIT_CSV,
        np.column_stack((x, observed, calculated, difference, background)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference_observed_minus_calculated,background",
        comments="",
        fmt=("%.8f", "%.8g", "%.8g", "%.8g", "%.8g"),
    )

    residuals = hist.residuals
    rvals = project.data["Covariance"]["data"]["Rvals"]
    cell, cell_esd = phase.get_cell_and_esd()
    atoms = {a.label: a for a in phase.atoms()}
    phase_result = {
        "name": "Calcium tungstate (scheelite)",
        "formula": "CaWO4",
        "space_group": "I 41/a",
        "space_group_number": 88,
        "cif_path": PHASE_CIF.name,
        "weight_fraction": 1.0,
        "weight_percent": 100.0,
        "weight_fraction_standard_uncertainty": None,
    }
    fit_statistics = {
        "Rwp_percent": float(rvals["Rwp"]),
        "Rp_percent": float(residuals["R"]),
        "Rexp_percent": float(residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_square": float(rvals["chisq"]),
        "Bragg_Rf_percent": float(residuals["0:0:Rf"]),
        "Bragg_Rf_squared_percent": float(residuals["0:0:Rf^2"]),
        "number_of_observations": int(rvals["Nobs"]),
        "number_of_refined_variables": int(rvals["Nvars"]),
    }
    result = {
        "phase_count": 1,
        "weight_fraction_basis": "normalized_over_modeled_crystalline_phases",
        "phases": [phase_result],
        "fit_statistics": fit_statistics,
        "profile_path": FIT_CSV.name,
        "gsasii_project_path": GPX.name,
        "uncertainty_note": (
            "The single modeled crystalline phase normalizes exactly to 1.0; "
            "this is not an absolute crystalline-content measurement and has no "
            "independent fraction standard uncertainty."
        ),
    }
    RESULT_JSON.write_text(json.dumps(result, indent=2) + "\n")

    a, sa = cell["length_a"], cell_esd["length_a"]
    c, sc = cell["length_c"], cell_esd["length_c"]
    volume, svolume = cell["volume"], cell_esd["volume"]
    o = atoms["O1"]
    report = f"""# PXRD phase analysis

## Result

The pattern is modeled as a single crystalline phase: scheelite-type calcium tungstate, CaWO4, space group I 41/a (No. 88). Its weight fraction is **100.0 wt% after normalization over the modeled crystalline phases**. The refined model is in `{PHASE_CIF.name}` and the complete refinement is in `{GPX.name}`.

The refined tetragonal cell is a = {a:.6f}({sa * 1e6:.0f}) A, c = {c:.6f}({sc * 1e6:.0f}) A, and V = {volume:.5f}({svolume * 1e5:.0f}) A^3. The refined oxygen site is (x, y, z) = ({o.coordinates[0]:.6f}, {o.coordinates[1]:.6f}, {o.coordinates[2]:.6f}); Ca and W remain on their symmetry-fixed special positions.

## Evidence

The observed strong lines at 18.61, 28.70, 29.03, 31.42, 34.16, 39.17, 47.07, 49.06, 54.25, and 57.82 degrees 2theta form the characteristic I-centered scheelite CaWO4 pattern. A COD CaWO4 model (COD 7219229) was used as the starting structure. The alternative chemically plausible phases were rejected by required reflections absent from the data: CaO requires strong lines near 32.2 and 37.3 degrees; Ca3WO6 requires strong lines near 18.9, 22.1, and 31.5 degrees; common WO3 polymorphs require the 23.1-24.4 degree cluster; and monoclinic CaWO4 requires strong lines near 19.3 and 29.8 degrees. The final difference trace does not contain a coherent second set of reflections.

## Refinement

GSAS-II Rietveld refinement used the full measured range ({x[0]:.5f}-{x[-1]:.5f} degrees 2theta), the reported Cu Kalpha1/Kalpha2 wavelengths and fixed 0.5 intensity ratio, a 12-term shifted-Chebyshev background, and an effective Gaussian CW profile with axial-divergence asymmetry. Refined quantities were phase scale, cell, profile U/W and SH/L terms, oxygen coordinates, and isotropic displacement parameters. The zero offset was held at zero and polarization at 0.7 to avoid unsupported correlations because no calibrated instrument profile or effective polarization was supplied. With no supplied pointwise uncertainties, counting uncertainties sigma(I) = sqrt(I) were used.

Fit statistics are Rwp = {fit_statistics['Rwp_percent']:.4f}%, Rp = {fit_statistics['Rp_percent']:.4f}%, Rexp = {fit_statistics['Rexp_percent']:.4f}%, GOF = {fit_statistics['goodness_of_fit']:.4f}, and Bragg R(F) = {fit_statistics['Bragg_Rf_percent']:.4f}% ({fit_statistics['number_of_observations']} observations, {fit_statistics['number_of_refined_variables']} refined variables). `fit.csv` contains observed, calculated, observed-minus-calculated, and background profiles.

## Remaining uncertainty

The 100 wt% value is conditional on the crystalline model: without an internal standard it cannot quantify amorphous material, and trace impurities below the pattern's detection capability cannot be excluded. No quantitative detection limit was established. Statistical cell and coordinate uncertainties also understate possible systematic errors from specimen displacement and the uncalibrated instrumental profile. Crystallite size and microstrain were therefore not interpreted separately.
"""
    REPORT_MD.write_text(report)


def main():
    xye, inst = prepare_inputs()
    G2sc.SetPrintLevel("all")
    project = G2sc.G2Project(newgpx=str(GPX))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="Topas")
    phase = project.add_phase(
        str(SOURCE_CIF),
        phasename="CaWO4_scheelite",
        histograms=[hist],
        fmthint="CIF",
    )
    project.set_Controls("cycles", 20)
    # The histogram-level scale and the phase scale are mathematically
    # redundant for a single histogram. Keep the former fixed so phase scale
    # (the quantity used for phase fractions) is uniquely determined.
    hist.SampleParameters["Scale"][1] = False

    for variable in (":0:U", ":0:W", ":0:SH/L"):
        project.set_Controls("parmMin", 0.0, variable=variable)

    show_state("initial", project, hist, phase)

    recipes = [
        (
            "background and scale",
            {"set": {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 12}, "Scale": True}},
        ),
        ("cell", {"set": {"Cell": True}}),
        ("constant Gaussian profile", {"set": {"Instrument Parameters": ["W"]}}),
        ("angle-dependent Gaussian profile", {"set": {"Instrument Parameters": ["U"]}}),
        ("axial asymmetry", {"set": {"Instrument Parameters": ["SH/L"]}}),
        ("oxygen coordinates", {"set": {"Atoms": {"O1": "X"}}}),
        ("isotropic displacement parameters", {"set": {"Atoms": {"all": "U", "O1": "XU"}}}),
    ]
    for atom_index in range(3):
        project.set_Controls("parmMin", 0.0, variable=f"0::AUiso:{atom_index}")
    for tag, recipe in recipes:
        project.do_refinements([recipe])
        show_state(tag, project, hist, phase)

    # One unchanged final pass ensures the covariance matrix, calculated
    # profile and exported model all correspond to a fully converged state.
    project.do_refinements([{}])
    show_state("final", project, hist, phase)
    write_deliverables(project, hist, phase)
    print("\nSaved final deliverables")


if __name__ == "__main__":
    main()
