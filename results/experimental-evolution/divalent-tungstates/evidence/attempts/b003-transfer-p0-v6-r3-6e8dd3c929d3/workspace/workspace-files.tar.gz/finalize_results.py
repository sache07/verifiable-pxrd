import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE_PROJECT = ROOT / ".tmp" / "triclinic_metric_constrained.gpx"
FINAL_PROJECT = ROOT / "final.gpx"

phase_output = {
    "WO3_triclinic_P-1": ("WO3", "WO3_triclinic.cif"),
    "Cu3WO6_cubic_Pa-3": ("Cu3WO6", "Cu3WO6_cubic.cif"),
    "CuO_monoclinic_C2c": ("CuO", "CuO_monoclinic.cif"),
}

# Save under the required final name, then reload that file so every exported
# artifact is explicitly sourced from final.gpx.
project = G2sc.G2Project(str(SOURCE_PROJECT), newgpx=str(FINAL_PROJECT))
project.save()
project = G2sc.G2Project(str(FINAL_PROJECT))
hist = project.histogram(0)

mass_fractions = hist.ComputeMassFracs()
phases = []
for phase in project.phases():
    formula, cif_name = phase_output[phase.name]
    phase.export_CIF(str(ROOT / cif_name))
    fraction, fraction_esd = mass_fractions[phase.name]
    phases.append({
        "name": formula,
        "model_name": phase.name,
        "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
        "cif_path": cif_name,
        "weight_fraction": fraction,
        "weight_fraction_esd_formal": fraction_esd,
    })

# Export only the refined interval. Ycalc is the full calculated profile,
# including background; the difference is observed minus calculated.
x = np.asarray(hist.getdata("X"), dtype=float)
yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
ybkg = np.asarray(hist.getdata("Background"), dtype=float)
low, high = hist.data["Limits"][1]
# Match GSAS-II's sampled-limit convention exactly: the first point at or
# above each limit is found and the upper-limit point is included.
i_low = np.searchsorted(x, low)
i_high = np.searchsorted(x, high) + 1
fit = np.column_stack((
    x[i_low:i_high],
    yobs[i_low:i_high],
    ycalc[i_low:i_high],
    yobs[i_low:i_high] - ycalc[i_low:i_high],
    ybkg[i_low:i_high],
))
np.savetxt(
    ROOT / "fit.csv",
    fit,
    delimiter=",",
    header="two_theta_deg,observed_intensity,calculated_intensity,difference_observed_minus_calculated,background_intensity",
    comments="",
    fmt=["%.8f", "%.6f", "%.6f", "%.6f", "%.6f"],
)

residuals = hist.residuals
rvals = project.data["Covariance"]["data"]["Rvals"]
result = {
    "weight_fraction_basis": "normalized over modeled crystalline phases",
    "phases": phases,
    "fit_statistics": {
        "Rp_percent": residuals["R"],
        "Rwp_percent": residuals["wR"],
        "Rexp_percent": residuals["wRmin"],
        "goodness_of_fit": rvals["GOF"],
        "chi_squared": rvals["chisq"],
        "n_observations": rvals["Nobs"],
        "n_refined_variables": rvals["Nvars"],
        "refined_two_theta_range_deg": [low, high],
        "converged": bool(rvals["converged"]),
        "max_shift_over_esd": rvals["Max shft/sig"],
    },
}
with (ROOT / "result.json").open("w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

project.save()
