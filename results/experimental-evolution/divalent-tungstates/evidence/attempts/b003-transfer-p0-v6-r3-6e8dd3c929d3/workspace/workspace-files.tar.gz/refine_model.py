from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / ".tmp" / "two_phase.gpx"
PATTERN = ROOT / "inputs" / "pattern.csv"
INSTRUMENT = ROOT / "instrument.instprm"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
WO3_CIF = COD / "1" / "52" / "89" / "1528915.cif"
CU3WO6_CIF = COD / "1" / "52" / "74" / "1527404.cif"


def status(project, label):
    hist = project.histogram(0)
    print(f"\n--- {label} ---")
    print("residuals", hist.residuals)
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("Zero", "I(L2)/I(L1)", "U", "V", "W", "X", "Y", "Z", "SH/L")})
    print("background", hist.Background[0])
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        print(phase.name, "cell", phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"], "mustrain", hap["Mustrain"])
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as err:
        print("mass fractions unavailable", repr(err))


PROJECT.parent.mkdir(parents=True, exist_ok=True)
project = G2sc.G2Project(newgpx=str(PROJECT))
hist = project.add_powder_histogram(str(PATTERN), str(INSTRUMENT),
                                    fmthint="comma/tab/semicolon")
wo3 = project.add_phase(str(WO3_CIF), phasename="WO3_monoclinic_P21n",
                        histograms=[hist], fmthint="CIF")
cu3wo6 = project.add_phase(str(CU3WO6_CIF), phasename="Cu3WO6_cubic_Pa-3",
                           histograms=[hist], fmthint="CIF")

hist.Limits("lower", 10.0)
hist.Limits("upper", 100.0)
hist.SampleParameters["Scale"][1] = False
hist.Background[0][3:] = [1500.0] + [0.0] * 11
hist.Background[0][2] = 12

# Start the phase scales at values that give similar calculated and observed
# intensities. Their absolute values are arbitrary; only their mass-normalized
# ratio is used for quantitative phase analysis.
wo3.HAPvalue("Scale", 0.01, [hist])
cu3wo6.HAPvalue("Scale", 0.01, [hist])
project.set_Controls("cycles", 8)
project.save()

# Establish background and relative scales.
project.set_refinement({"set": {
    "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 12},
    "PhaseFraction": True,
}})
project.refine()
status(project, "background and phase scales")

# Refine lattice constants after the phase intensities are stable.
project.set_refinement({"set": {"Cell": True}})
project.refine()
status(project, "cells")

# The instrument was not supplied with a calibrated profile. Refine a common
# zero offset and the standard Caglioti/pseudo-Voigt profile coefficients.
project.set_refinement({"set": {
    "Instrument Parameters": ["Zero"],
}})
project.refine()
status(project, "zero")

project.set_refinement({"set": {
    "Instrument Parameters": ["U", "V", "W", "X", "Y"],
}})
project.refine()
status(project, "common profile")

# Allow phase-dependent finite-domain broadening. Start near 0.1 micrometre,
# consistent with the visibly broadened low-angle reflections.
for phase in project.phases():
    phase.setSampleProfile(hist, "size", "isotropic", 0.10, LGmix=1.0)
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
project.refine()
status(project, "phase size")

project.save()
