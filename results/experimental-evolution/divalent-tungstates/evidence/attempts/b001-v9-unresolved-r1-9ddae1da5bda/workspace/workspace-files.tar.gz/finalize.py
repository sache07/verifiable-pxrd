#!/usr/bin/env python3
"""Replay the accepted GSAS-II model and freeze all requested deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "trial_roughB.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "PbWO4_scheelite": {
        "display_name": "PbWO4 (scheelite)",
        "formula": "PbWO4",
        "cod_id": "9009811",
        "cif_path": "phase_PbWO4_scheelite.cif",
        "broadening": "size",
    },
    "WO3_monoclinic": {
        "display_name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cod_id": "2311041",
        "cif_path": "phase_WO3_monoclinic.cif",
        "broadening": None,
    },
    "Pb3O4_minium": {
        "display_name": "Pb3O4 (minium)",
        "formula": "Pb3O4",
        "cod_id": "9012124",
        "cif_path": "phase_Pb3O4_minium.cif",
        "broadening": "size",
    },
    "PbO_massicot": {
        "display_name": "PbO (massicot)",
        "formula": "PbO",
        "cod_id": "2310433",
        "cif_path": "phase_PbO_massicot.cif",
        "broadening": "strain",
    },
}


def configure(project: G2sc.G2Project) -> None:
    """Make the accepted parameterization explicit and remove latent terms."""
    hist = project.histogram(0)
    lo, hi = hist.data["Limits"][0]
    hist.data["Limits"][1] = [lo, hi]

    background = hist.data["Background"]
    background[0][0] = "chebyschev"
    background[0][1] = True
    background[0][2] = 6
    del background[0][9:]
    background[1]["nDebye"] = 0
    background[1]["debyeTerms"] = []
    background[1]["nPeaks"] = 0
    background[1]["peaksList"] = []
    background[1]["background PWDR"] = ["", 1.0, False]

    inst = hist.data["Instrument Parameters"][0]
    for key in ("V", "Y", "Z"):
        inst[key][1], inst[key][2] = 0.0, False
    for key in ("U", "W", "X"):
        inst[key][2] = True
    inst["Zero"][2] = True
    inst["SH/L"][1], inst["SH/L"][2] = 0.002, False
    inst["Polariz."][1], inst["Polariz."][2] = 0.7, False
    inst["I(L2)/I(L1)"][1], inst["I(L2)/I(L1)"][2] = 0.5, False

    sample = hist.data["Sample Parameters"]
    for key in ("Shift", "Transparency", "Absorption", "DisplaceX", "DisplaceY"):
        sample[key][0], sample[key][1] = 0.0, False
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"][1] = True
    sample["Scale"] = [1.0, False]

    for phase in project.phases():
        if phase.name not in PHASE_INFO:
            raise RuntimeError(f"Unexpected phase in accepted model: {phase.name}")
        phase.set_refinements({"Cell": True})
        cx = phase.data["General"]["AtomPtrs"][0]
        for atom in phase.data["Atoms"]:
            atom[cx - 1] = ""

        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        hap["Scale"][1] = True
        hap["LeBail"] = False
        hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
        hap["Extinction"] = [0.0, False]
        for key in hap["Babinet"]:
            hap["Babinet"][key] = [0.0, False]
        hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]

        hap["Size"][0] = "isotropic"
        hap["Size"][1][1:] = [10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][1:] = [0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]

        broadening = PHASE_INFO[phase.name]["broadening"]
        if broadening == "size":
            hap["Size"][2][0] = True
            hap["Mustrain"][1][0] = 0.0
        elif broadening == "strain":
            hap["Size"][1][0] = 10.0
            hap["Mustrain"][2][0] = True
        else:
            hap["Size"][1][0] = 10.0
            hap["Mustrain"][1][0] = 0.0

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-5


def peak_metrics(x: np.ndarray, signal: np.ndarray, center: float, radius: float) -> dict:
    sel = np.flatnonzero((x >= center - radius) & (x <= center + radius))
    if len(sel) < 5:
        raise RuntimeError(f"No profile points near {center}")
    i = int(sel[np.argmax(signal[sel])])
    peak = float(signal[i])
    half = peak / 2.0

    left = i
    while left > sel[0] and signal[left] > half:
        left -= 1
    right = i
    while right < sel[-1] and signal[right] > half:
        right += 1
    if left == sel[0] or right == sel[-1]:
        raise RuntimeError(f"Half-height crossing not bracketed near {center}")

    def crossing(i0: int, i1: int) -> float:
        y0, y1 = float(signal[i0]), float(signal[i1])
        return float(x[i0] + (half - y0) * (x[i1] - x[i0]) / (y1 - y0))

    xl = crossing(left, left + 1)
    xr = crossing(right - 1, right)
    xp = float(x[i])
    return {
        "position_deg": xp,
        "fwhm_deg": xr - xl,
        "left_half_width_deg": xp - xl,
        "right_half_width_deg": xr - xp,
    }


def write_outputs(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    profile = np.asarray(hist.data["data"][1], dtype=float)
    x, obs, weight, calc, background, difference = profile
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "difference", "background"]
        )
        writer.writerows(zip(x, obs, calc, difference, background))

    mass_fracs = hist.ComputeMassFracs()
    phases = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        cif = ROOT / info["cif_path"]
        phase.export_CIF(str(cif))
        fraction, esd = mass_fracs[phase.name]
        sgdata = phase.data["General"]["SGData"]
        phases.append(
            {
                "name": info["display_name"],
                "formula": info["formula"],
                "structure_source": f"COD {info['cod_id']}",
                "space_group": sgdata["SpGrp"].strip(),
                "crystal_system": sgdata["SGSys"],
                "cif_path": info["cif_path"],
                "weight_fraction": float(fraction),
                "weight_fraction_esd_statistical": float(esd),
            }
        )

    residual = hist.data["data"][0]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    fit_stats = {
        "Rwp_percent": float(residual["wR"]),
        "Rp_percent": float(residual["R"]),
        "R_bragg_percent": float(residual["Rb"]),
        "Rexp_percent": float(residual["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "weighted_chi_square": float(rvals["chisq"]),
        "reduced_chi_square": float(rvals["GOF"] ** 2),
        "durbin_watson": float(residual["Durbin-Watson"]),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_parameters": int(rvals["Nvars"]),
    }
    result = {
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "phases": phases,
        "fit_statistics": fit_stats,
    }
    if not np.isclose(sum(p["weight_fraction"] for p in phases), 1.0, atol=1e-10):
        raise RuntimeError("Phase fractions do not sum to one")
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    obs_signal = obs - background
    calc_signal = calc - background
    checks = {}
    for label, center, radius in (
        ("WO3_low", 23.53, 0.24),
        ("PbWO4_low", 27.81, 0.45),
        ("PbWO4_mid", 45.13, 0.42),
        ("PbWO4_high", 72.36, 0.55),
        ("PbWO4_highest", 94.04, 0.65),
    ):
        checks[label] = {
            "observed": peak_metrics(x, obs_signal, center, radius),
            "calculated": peak_metrics(x, calc_signal, center, radius),
        }
    (ROOT / "profile_checks.json").write_text(json.dumps(checks, indent=2) + "\n")
    return {"result": result, "profile_checks": checks, "rvals": rvals}


def main() -> None:
    project = G2sc.G2Project(str(BASE), newgpx=str(FINAL))
    configure(project)
    project.save()
    project.do_refinements([{}])
    first = dict(project.data["Covariance"]["data"]["Rvals"])

    # Required disk replay: reopen the actual final project and refine full range.
    project = G2sc.G2Project(str(FINAL))
    configure(project)
    project.do_refinements([{}])
    second = dict(project.data["Covariance"]["data"]["Rvals"])

    # Freeze products from a fresh read of precisely the submitted GPX.
    project = G2sc.G2Project(str(FINAL))
    payload = write_outputs(project)
    print(
        "FINAL_RESULT "
        + json.dumps(
            {
                "first_replay": first,
                "second_replay": second,
                "outputs": payload,
            },
            sort_keys=True,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
