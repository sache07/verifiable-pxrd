#!/usr/bin/env python3
"""Add a watch-list phase to the converged baseline and refine its scale only."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
BASE = ROOT / "trial_roughB.gpx"


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize(hap: dict) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    for key in hap["Babinet"]:
        hap["Babinet"][key] = [0.0, False]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("label")
    parser.add_argument("cod_id")
    parser.add_argument("--start-scale", type=float, default=0.1)
    args = parser.parse_args()

    output = ROOT / f"watch_{args.label}_{args.cod_id}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output))
    hist = project.histogram(0)
    alt = project.add_phase(
        str(cod_path(args.cod_id)),
        phasename=f"WATCH_{args.label}_{args.cod_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    hap = alt.data["Histograms"][hist.name]
    neutralize(hap)
    hap["Scale"] = [args.start_scale, True]
    hap["Use"] = True
    alt.set_refinements({"Cell": False})

    project.data["Controls"]["data"]["max cyc"] = 8
    project.save()
    project.do_refinements([{}])
    first = {"scale": alt.HAPvalue("Scale"), "wR_percent": hist.get_wR()}
    project.do_refinements([{}])
    second = {"scale": alt.HAPvalue("Scale"), "wR_percent": hist.get_wR()}
    result = {
        "label": args.label,
        "cod_id": args.cod_id,
        "project": str(output),
        "first": first,
        "second": second,
        "cell_fixed": alt.get_cell(),
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "max_shift_over_esd": max(
            abs(project.data["Covariance"]["data"].get("Lastshft", [0.0]))
        ),
    }
    print("WATCH_RESULT " + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
