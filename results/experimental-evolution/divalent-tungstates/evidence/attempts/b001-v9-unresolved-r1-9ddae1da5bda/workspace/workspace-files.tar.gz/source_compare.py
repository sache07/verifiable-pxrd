#!/usr/bin/env python3
"""Substitute one phase source into the saved matched-nuisance baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
BASE = ROOT / "trial_roughB.gpx"


MODELS = {
    "PbWO4_scheelite": {"size": 0.0609},
    "WO3_monoclinic": {},
    "Pb3O4_minium": {"size": 0.0330},
    "PbO_massicot": {"strain": 10425.0},
}


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize(hap: dict) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    for key in hap["Babinet"]:
        hap["Babinet"][key] = [0.0, False]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=sorted(MODELS))
    parser.add_argument("cod_id")
    args = parser.parse_args()

    output = ROOT / f"source_{args.phase}_{args.cod_id}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output))
    hist = project.histogram(0)
    old = project.phase(args.phase)
    old_hap = old.data["Histograms"][hist.name]
    old_scale = old_hap["Scale"][0]
    old_hap["Use"] = False
    old_hap["Scale"][1] = False
    old.set_refinements({"Cell": False})

    alt_name = f"ALT_{args.cod_id}"
    alt = project.add_phase(
        str(cod_path(args.cod_id)),
        phasename=alt_name,
        histograms=[hist],
        fmthint="CIF",
    )
    hap = alt.data["Histograms"][hist.name]
    neutralize(hap)
    hap["Scale"] = [old_scale, True]
    hap["Use"] = True
    model = MODELS[args.phase]
    if "size" in model:
        alt.setSampleProfile(hist.name, "size", "isotropic", model["size"], LGmix=1.0)
    if "strain" in model:
        alt.setSampleProfile(
            hist.name, "microstrain", "isotropic", model["strain"], LGmix=1.0
        )
    # Gate source selection with a scale-first replay while the candidate cell
    # and phase-specific profile terms remain fixed.
    alt.set_refinements({"Cell": False})

    project.data["Controls"]["data"]["max cyc"] = 8
    project.save()
    project.do_refinements([{}])

    if "size" in model:
        alt.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True,
                      "LGmix": {"value": 1.0, "refine": False}}}
        )
    if "strain" in model:
        alt.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True,
                          "LGmix": {"value": 1.0, "refine": False}}}
        )
    alt.set_refinements({"Cell": True})
    project.do_refinements([{}])
    project.do_refinements([{}])
    result = {
        "phase_replaced": args.phase,
        "cod_id": args.cod_id,
        "project": str(output),
        "wR_percent": hist.get_wR(),
        "alt_scale": alt.HAPvalue("Scale"),
        "cell": alt.get_cell(),
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "max_shift_over_esd": max(
            abs(project.data["Covariance"]["data"].get("Lastshft", [0.0]))
        ),
    }
    print("SOURCE_RESULT " + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
