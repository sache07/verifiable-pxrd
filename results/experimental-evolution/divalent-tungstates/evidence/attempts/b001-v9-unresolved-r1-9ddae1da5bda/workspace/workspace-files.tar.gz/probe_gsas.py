#!/usr/bin/env python3
"""Create a neutral two-phase GSAS-II probe project and print its controls."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


gpx = G2sc.G2Project(newgpx=str(ROOT / "probe.gpx"))
hist = gpx.add_powder_histogram(
    str(ROOT / "inputs/pattern.csv"),
    str(ROOT / "instrument.instprm"),
    fmthint="comma/tab/semicolon",
)
for source, name in [
    (cod_path("9009811"), "PbWO4_scheelite"),
    (cod_path("2311041"), "WO3_monoclinic"),
]:
    phase = gpx.add_phase(str(source), phasename=name, histograms=[hist], fmthint="CIF")
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [100.0, 100.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    for key in hap["Babinet"]:
        hap["Babinet"][key] = [0.0, False]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]

hist.data["Sample Parameters"]["Shift"] = [0.0, False]
hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
hist.data["Instrument Parameters"][0]["Zero"][1] = 0.42
hist.data["Background"][0][0] = "chebyschev"
hist.data["Background"][0][1] = False
hist.data["Background"][0][2] = 6
hist.data["Background"][0][3:] = [1500.0, -800.0, 300.0, -100.0, 30.0, -10.0]

gpx.save()
print("histogram", hist.name)
print("limits", hist.data["Limits"])
print("instrument", hist.data["Instrument Parameters"][0])
print("sample", hist.data["Sample Parameters"])
print("background", hist.data["Background"])
for phase in gpx.phases():
    print("phase", phase.name, phase.get_cell())
    print("HAP", phase.data["Histograms"][hist.name])
