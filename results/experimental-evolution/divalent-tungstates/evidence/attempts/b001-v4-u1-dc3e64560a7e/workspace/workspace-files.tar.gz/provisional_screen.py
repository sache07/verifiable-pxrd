#!/usr/bin/env python3
"""Uniform provisional GSAS-II phase/polymorph screening.

This is intentionally not the final profile pass. Each model is rebuilt from
the source CIFs and receives the same background, angular, cell, scale, and
fixed modest profile treatment.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2sc


BASE = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif(cod_id: str) -> str:
    return str(COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif")


PHASES = {
    "stolzite_9009811": (cif("9009811"), 0.04),
    "stolzite_1527935": (cif("1527935"), 0.04),
    "raspite_9007617": (cif("9007617"), 0.04),
    "WO3_mono_2311041": (cif("2311041"), 10.0),
    "WO3_mono_1528915": (cif("1528915"), 10.0),
    "WO3_tri_2106293": (cif("2106293"), 10.0),
    "WO3_ortho_2107312": (cif("2107312"), 10.0),
    "PbO_litharge_9012700": (cif("9012700"), 10.0),
    "PbO_massicot_2310433": (cif("2310433"), 10.0),
    "Pb3O4_9012124": (cif("9012124"), 10.0),
    "Pb3O4_9013442": (cif("9013442"), 10.0),
}

MODELS = {
    "stolzite_only": ["stolzite_9009811"],
    "base_mono231": ["stolzite_9009811", "WO3_mono_2311041"],
    "alt_stolzite": ["stolzite_1527935", "WO3_mono_2311041"],
    "raspite_replacement": ["raspite_9007617", "WO3_mono_2311041"],
    "mono152": ["stolzite_9009811", "WO3_mono_1528915"],
    "triclinic": ["stolzite_9009811", "WO3_tri_2106293"],
    "orthorhombic": ["stolzite_9009811", "WO3_ortho_2107312"],
    "add_raspite": ["stolzite_9009811", "WO3_mono_2311041", "raspite_9007617"],
    "add_litharge": ["stolzite_9009811", "WO3_mono_2311041", "PbO_litharge_9012700"],
    "add_massicot": ["stolzite_9009811", "WO3_mono_2311041", "PbO_massicot_2310433"],
    "add_minium135": ["stolzite_9009811", "WO3_mono_2311041", "Pb3O4_9012124"],
    "add_minium55": ["stolzite_9009811", "WO3_mono_2311041", "Pb3O4_9013442"],
}


def neutralize_histogram(hist) -> None:
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], (bool, np.bool_)):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    for key in (
        "Shift",
        "Transparency",
        "SurfRoughA",
        "SurfRoughB",
        "Absorption",
        "DisplaceX",
        "DisplaceY",
    ):
        if key in hist.SampleParameters:
            hist.SampleParameters[key] = [0.0, False]


def initialize_background(hist) -> None:
    x = np.asarray(hist.getdata("X"))
    y = np.asarray(hist.getdata("Yobs"))
    envelope = percentile_filter(y, 10, size=401, mode="nearest")
    points = []
    for target in np.linspace(x[0], x[-1], 31):
        index = int(np.argmin(np.abs(x - target)))
        points.append((float(x[index]), float(envelope[index])))
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "refine": False,
                "FixedPoints": points,
                "fit fixed points": True,
            }
        }
    )


def neutralize_hap(phase, hist, size: float) -> None:
    hap = phase.getHAPvalues(hist.name)
    hap["Scale"] = [1.0, True]
    hap["Pref.Ori."] = ["MD", 1.0, False, [0, 0, 1], 0, {}, [], 0.1]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [size, size, size]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [1000.0, 1000.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def covariance_value(project, variable: str) -> tuple[float | None, float | None]:
    covariance = project.data["Covariance"]["data"]
    names = covariance.get("varyList", [])
    if variable not in names:
        return None, None
    index = names.index(variable)
    return float(covariance["variables"][index]), float(covariance["sig"][index])


def fit_model(label: str, phase_names: list[str], output_dir: Path) -> dict:
    project_path = (output_dir / f"{label}.gpx").resolve()
    project = G2sc.G2Project(newgpx=str(project_path))
    hist = project.add_powder_histogram(
        str(BASE / "inputs/pattern.csv"),
        str(BASE / "instrument.instprm"),
        fmthint="comma",
    )
    neutralize_histogram(hist)
    for phase_name in phase_names:
        source, size = PHASES[phase_name]
        phase = project.add_phase(source, phasename=phase_name, histograms=[hist])
        neutralize_hap(phase, hist, size)

    initialize_background(hist)
    instrument = hist.InstrumentParameters
    values = {
        "Zero": 0.43,
        "U": 0.0,
        "V": 0.0,
        "W": 0.0,
        "X": 8.04,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }
    for key, value in values.items():
        instrument[key][0] = instrument[key][1] = value
        instrument[key][2] = False

    project.set_Controls("cycles", 4)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    for phase in project.phases():
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")

    # Uniform modest nuisance schedule: bkg/scales, then one angular term and cells.
    hist.set_refinements({"Background": {"refine": True}})
    project.refine()
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine()
    project.save()
    project = G2sc.G2Project(str(project_path))
    project.refine()
    hist = project.histogram(0)

    x = np.asarray(hist.getdata("X"))
    residual = np.asarray(hist.getdata("Residual"))
    weight = np.asarray(hist.getdata("Yweight"))
    windows = {
        "wo3_triplet": (23.25, 25.10),
        "wo3_29": (28.85, 29.75),
        "wo3_34": (33.45, 34.85),
        "mid_angle": (40.0, 60.0),
        "high_angle": (70.0, 100.1),
    }
    window_chi2 = {}
    for name, (low, high) in windows.items():
        use = (x >= low) & (x <= high)
        window_chi2[name] = float(np.sum(weight[use] * residual[use] ** 2) / np.sum(use))

    phase_rows = []
    for phase in project.phases():
        scale, scale_esd = covariance_value(project, f"{phase.id}:{hist.id}:Scale")
        phase_rows.append(
            {
                "name": phase.name,
                "scale": scale,
                "scale_esd": scale_esd,
                "cell": phase.get_cell(),
                "density": phase.density,
            }
        )
    result = {
        "model": label,
        "project": str(project_path.relative_to(BASE)),
        "phases": phase_rows,
        "residuals": {key: float(value) if isinstance(value, (float, int)) else value for key, value in hist.residuals.items()},
        "window_reduced_chi2": window_chi2,
        "zero": float(hist.InstrumentParameters["Zero"][1]),
        "frozen": project.get_Frozen(),
    }
    return result


def main() -> None:
    output_dir = BASE / ".tmp/provisional/screens"
    output_dir.mkdir(parents=True, exist_ok=True)
    results = []
    for label, phases in MODELS.items():
        print(f"\n===== {label}: {', '.join(phases)} =====", flush=True)
        try:
            result = fit_model(label, phases, output_dir)
        except Exception as exc:
            result = {"model": label, "error": f"{type(exc).__name__}: {exc}"}
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)
    with (output_dir / "screen_results.json").open("w") as handle:
        json.dump(results, handle, indent=2)


if __name__ == "__main__":
    main()
