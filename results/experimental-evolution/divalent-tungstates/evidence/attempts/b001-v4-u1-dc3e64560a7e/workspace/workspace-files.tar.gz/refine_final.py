#!/usr/bin/env python3
"""Clean GSAS-II profile/HAP branch testing and final export.

The provisional phase inventory is intentionally kept separate.  This script
starts from the neutral clean project and records each branch so that bound-
seeking profile terms can be rejected rather than silently retained.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


BASE = Path(__file__).resolve().parent
WORK = BASE / ".tmp" / "final_clean"
START = WORK / "stage_cells.gpx"
PROFILE_LOG = WORK / "profile_tests.json"
COMMON = WORK / "stage_common_profile.gpx"
HAP_LOG = WORK / "hap_branch_tests.json"
COMBINE_LOG = WORK / "combined_tests.json"
INTENSITY_LOG = WORK / "global_intensity_test.json"
TEXTURE_LOG = WORK / "texture_tests.json"
FINAL_PROJECT = BASE / "final.gpx"

FINAL_PHASES = [
    {
        "name": "PbWO4_stolzite",
        "formula": "PbWO4",
        "cod_id": "9009811",
        "cif": "phase_1_PbWO4_stolzite.cif",
    },
    {
        "name": "WO3_monoclinic",
        "formula": "WO3",
        "cod_id": "2311041",
        "cif": "phase_2_WO3_monoclinic.cif",
    },
    {
        "name": "Pb3O4_minium",
        "formula": "Pb3O4",
        "cod_id": "9012124",
        "cif": "phase_3_Pb3O4_minium.cif",
    },
    {
        "name": "PbO_massicot",
        "formula": "PbO",
        "cod_id": "2310433",
        "cif": "phase_4_PbO_massicot.cif",
    },
]


def copy_project(source: Path, target: Path):
    """Load *source* under a new filename and persist the copy."""
    target.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(source), newgpx=str(target))
    project.save()
    return project


def covariance_value(project, variable: str):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = covariance.get("varyList", [])
    if variable not in names:
        return None, None
    index = names.index(variable)
    return (
        float(covariance["variables"][index]),
        float(covariance["sig"][index]),
    )


def serial_residuals(histogram):
    result = {}
    for key, value in histogram.residuals.items():
        if isinstance(value, (int, float, np.integer, np.floating)):
            result[key] = float(value)
        elif isinstance(value, str):
            result[key] = value
    return result


def configure_cycles(project, cycles: int = 6):
    project.set_Controls("cycles", cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6


def set_all_nuisance(project, refine: bool):
    """Toggle only the accepted inventory nuisance terms."""
    histogram = project.histogram(0)
    if refine:
        histogram.set_refinements({"Background": {"refine": True}})
        histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    else:
        histogram.clear_refinements({"Background": {}})
        histogram.clear_refinements({"Instrument Parameters": ["Zero"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": refine})
        if refine:
            phase.set_HAP_refinements({"Scale": True})
        else:
            phase.clear_HAP_refinements({"Scale": True})


def clear_profile_flags(histogram):
    histogram.clear_refinements(
        {"Instrument Parameters": ["U", "V", "W", "X", "Y", "Z", "SH/L"]}
    )


def profile_windows(histogram):
    """Retain resolved WO3 lines from low through high angle."""
    included = [
        (23.35, 24.55),  # (20-2), (020)
        (33.50, 34.18),  # (22-2), (200)
        (41.72, 42.45),  # (220), (22-4)
        (48.48, 48.84),  # (040)
        (70.82, 71.28),  # (400), isolated high-angle diagnostic
    ]
    # Keep the endpoints unmasked: masking an active-range endpoint can cause
    # masked scalar propagation in the GSAS-II least-squares path.
    histogram.set_refinements({"Limits": [23.30, 71.32]})
    excluded = []
    cursor = 23.30
    for start, stop in included:
        if start > cursor and cursor != 23.30:
            excluded.append([cursor, start])
        cursor = stop
    histogram.Excluded(excluded)


def replay(path: Path, cycles: int = 6):
    project = G2sc.G2Project(str(path))
    configure_cycles(project, cycles)
    project.refine()
    project.save()
    return G2sc.G2Project(str(path))


def repeated_replay(path: Path, count: int = 3, cycles: int = 8):
    project = None
    for _ in range(count):
        project = replay(path, cycles=cycles)
    return project


def profile_branch(label: str, terms: dict[str, float], source: Path = START):
    path = WORK / f"profile_{label}.gpx"
    project = copy_project(source, path)
    configure_cycles(project)
    histogram = project.histogram(0)
    set_all_nuisance(project, False)
    clear_profile_flags(histogram)
    profile_windows(histogram)

    for term, value in terms.items():
        histogram.InstrumentParameters[term][0] = value
        histogram.InstrumentParameters[term][1] = value
    histogram.set_refinements({"Instrument Parameters": list(terms)})
    for term in terms:
        project.set_Controls("parmMin", 0.0 if term != "SH/L" else 0.001,
                             variable=f":0:{term}")
        if term == "SH/L":
            project.set_Controls("parmMax", 0.1, variable=f":0:{term}")
        elif term == "X":
            project.set_Controls("parmMax", 40.0, variable=f":0:{term}")
        else:
            project.set_Controls("parmMax", 100.0, variable=f":0:{term}")

    project.refine()
    project.save()
    project = replay(path)
    histogram = project.histogram(0)
    values = {}
    for term in terms:
        value, esd = covariance_value(project, f":0:{term}")
        values[term] = {
            "value": value,
            "esd": esd,
            "stored": float(histogram.InstrumentParameters[term][1]),
        }
    return {
        "label": label,
        "project": str(path.relative_to(BASE)),
        "selected_window_residuals": serial_residuals(histogram),
        "terms": values,
        "frozen": [str(item) for item in project.get_Frozen()],
    }


def make_common_stage(x_value: float):
    path = WORK / "stage_common_profile.gpx"
    project = copy_project(START, path)
    configure_cycles(project)
    histogram = project.histogram(0)
    histogram.Excluded([])
    clear_profile_flags(histogram)
    histogram.InstrumentParameters["X"][0] = x_value
    histogram.InstrumentParameters["X"][1] = x_value
    set_all_nuisance(project, True)
    project.refine()
    project.save()
    project = replay(path)
    histogram = project.histogram(0)
    return {
        "project": str(path.relative_to(BASE)),
        "full_range_residuals": serial_residuals(histogram),
        "X": float(histogram.InstrumentParameters["X"][1]),
        "zero": float(histogram.InstrumentParameters["Zero"][1]),
        "frozen": [str(item) for item in project.get_Frozen()],
    }


def neutralize_all_hap(project):
    histogram = project.histogram(0)
    for phase in project.phases():
        hap = phase.getHAPvalues(histogram.name)
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."] = ["MD", 1.0, False, [0, 0, 1], 0, {}, [], 0.1]
        hap["Extinction"] = [0.0, False]
        hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}


def hap_branch(phase_index: int, kind: str):
    source = COMMON
    phase_label = G2sc.G2Project(str(source)).phase(phase_index).name
    short = phase_label.lower().replace("_", "-")
    path = WORK / f"branch_{short}_{kind}.gpx"
    project = copy_project(source, path)
    configure_cycles(project, 8)
    histogram = project.histogram(0)
    histogram.clear_refinements({"Limits": []})
    histogram.Excluded([])
    clear_profile_flags(histogram)
    neutralize_all_hap(project)
    set_all_nuisance(project, True)
    phase = project.phase(phase_index)
    hap = phase.getHAPvalues(histogram.name)

    if kind == "size":
        hap["Size"][1] = [0.10, 0.10, 1.0]
        hap["Size"][2] = [True, False, False]
        variable = f"{phase.id}:{histogram.id}:Size;i"
        project.set_Controls("parmMin", 0.005, variable=variable)
        project.set_Controls("parmMax", 10.0, variable=variable)
    elif kind == "strain":
        hap["Mustrain"][1] = [1000.0, 1000.0, 1.0]
        hap["Mustrain"][2] = [True, False, False]
        variable = f"{phase.id}:{histogram.id}:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 10000.0, variable=variable)
    else:
        raise ValueError(kind)

    project.refine()
    project.save()
    project = replay(path, cycles=8)
    histogram = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.getHAPvalues(histogram.name)
    value, esd = covariance_value(project, variable)
    stored = (
        float(hap["Size"][1][0])
        if kind == "size"
        else float(hap["Mustrain"][1][0])
    )
    return {
        "phase": phase.name,
        "phase_id": phase.id,
        "kind": kind,
        "project": str(path.relative_to(BASE)),
        "variable": variable,
        "value": value,
        "esd": esd,
        "stored": stored,
        "residuals": serial_residuals(histogram),
        "mass_fractions": {
            name: {"value": value[0], "esd": value[1]}
            for name, value in histogram.ComputeMassFracs().items()
        },
        "frozen": [str(item) for item in project.get_Frozen()],
    }


def run_hap_tests():
    baseline = G2sc.G2Project(str(COMMON))
    results = {
        "baseline_project": str(COMMON.relative_to(BASE)),
        "baseline_residuals": serial_residuals(baseline.histogram(0)),
        "branches": [],
    }
    for phase_index in range(len(baseline.phases())):
        for kind in ("size", "strain"):
            result = hap_branch(phase_index, kind)
            results["branches"].append(result)
            print(
                f"{result['phase']} {kind}: {result['stored']:.6g}; "
                f"Rwp={result['residuals']['wR']:.5f}; frozen={result['frozen']}",
                flush=True,
            )
    with HAP_LOG.open("w", encoding="utf-8") as handle:
        json.dump(results, handle, indent=2)
    print(json.dumps(results, indent=2))


def set_isotropic_size(project, phase_index: int, value: float,
                       minimum: float = 0.005):
    histogram = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.getHAPvalues(histogram.name)
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [value, value, 1.0]
    hap["Size"][2] = [True, False, False]
    variable = f"{phase.id}:{histogram.id}:Size;i"
    project.set_Controls("parmMin", minimum, variable=variable)
    project.set_Controls("parmMax", 10.0, variable=variable)
    return variable


def set_isotropic_strain(project, phase_index: int, value: float):
    histogram = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.getHAPvalues(histogram.name)
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [value, value, 1.0]
    hap["Mustrain"][2] = [True, False, False]
    variable = f"{phase.id}:{histogram.id}:Mustrain;i"
    project.set_Controls("parmMin", 0.0, variable=variable)
    project.set_Controls("parmMax", 10000.0, variable=variable)
    return variable


def project_summary(project, variables=()):
    histogram = project.histogram(0)
    terms = {}
    for variable in variables:
        value, esd = covariance_value(project, variable)
        terms[variable] = {"value": value, "esd": esd}
    phase_terms = {}
    for phase in project.phases():
        hap = phase.getHAPvalues(histogram.name)
        phase_terms[phase.name] = {
            "size_um": float(hap["Size"][1][0]),
            "microstrain": float(hap["Mustrain"][1][0]),
            "scale": float(hap["Scale"][0]),
        }
    return {
        "project": str(Path(project.filename).resolve().relative_to(BASE)),
        "residuals": serial_residuals(histogram),
        "mass_fractions": {
            name: {"value": value[0], "esd": value[1]}
            for name, value in histogram.ComputeMassFracs().items()
        },
        "instrument": {
            key: float(histogram.InstrumentParameters[key][1])
            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Zero", "Polariz.")
        },
        "phase_terms": phase_terms,
        "variables": terms,
        "frozen": [str(item) for item in project.get_Frozen()],
    }


def build_combined_core():
    path = WORK / "stage_combined_core.gpx"
    project = copy_project(COMMON, path)
    configure_cycles(project, 10)
    histogram = project.histogram(0)
    histogram.clear_refinements({"Limits": []})
    histogram.Excluded([])
    neutralize_all_hap(project)
    set_all_nuisance(project, True)
    clear_profile_flags(histogram)
    # X is fixed at the independent sharp-WO3 calibration. Releasing it with
    # broad-phase size terms gives a non-identifiable (>96% correlated) branch.
    histogram.InstrumentParameters["X"][0] = 5.693131644077451
    histogram.InstrumentParameters["X"][1] = 5.693131644077451
    variables = [
        set_isotropic_size(project, 0, 0.0573),
        set_isotropic_strain(project, 1, 1459.0),
        set_isotropic_size(project, 2, 0.0159),
    ]
    project.refine()
    project.save()
    project = repeated_replay(path, count=3, cycles=10)
    return project_summary(project, variables)


def test_massicot_size():
    source = WORK / "stage_combined_core.gpx"
    path = WORK / "branch_combined_massicot_size.gpx"
    project = copy_project(source, path)
    configure_cycles(project, 10)
    variable = set_isotropic_size(project, 3, 0.02, minimum=0.001)
    project.refine()
    project.save()
    project = repeated_replay(path, count=3, cycles=10)
    return project_summary(project, [variable])


def run_combined_tests():
    results = {
        "core": build_combined_core(),
        "massicot_size_challenge": test_massicot_size(),
    }
    with COMBINE_LOG.open("w", encoding="utf-8") as handle:
        json.dump(results, handle, indent=2)
    print(json.dumps(results, indent=2))


def run_global_intensity_test():
    source = WORK / "branch_combined_massicot_size.gpx"
    path = WORK / "branch_global_polarization.gpx"
    project = copy_project(source, path)
    configure_cycles(project, 8)
    histogram = project.histogram(0)
    histogram.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.refine()
    project.save()
    project = repeated_replay(path, count=2, cycles=8)
    result = {
        "baseline": project_summary(G2sc.G2Project(str(source))),
        "polarization_branch": project_summary(project, [":0:Polariz."]),
    }
    with INTENSITY_LOG.open("w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)
    print(json.dumps(result, indent=2))


TEXTURE_AXES = {
    0: [(0, 0, 1), (1, 0, 0)],
    1: [(1, 0, 0), (0, 1, 0), (0, 0, 1)],
    2: [(0, 0, 1), (1, 0, 0)],
    3: [(1, 0, 0), (0, 1, 0), (0, 0, 1)],
}


def texture_branch(phase_index: int, axis: tuple[int, int, int]):
    source = WORK / "branch_combined_massicot_size.gpx"
    axis_text = "".join(str(value) for value in axis)
    phase_name = G2sc.G2Project(str(source)).phase(phase_index).name
    short = phase_name.lower().replace("_", "-")
    path = WORK / f"branch_texture_{short}_{axis_text}.gpx"
    project = copy_project(source, path)
    configure_cycles(project, 6)
    histogram = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.getHAPvalues(histogram.name)
    hap["Pref.Ori."] = ["MD", 1.0, True, list(axis), 0, {}, [], 0.1]
    variable = f"{phase.id}:{histogram.id}:MD"
    project.set_Controls("parmMin", 0.2, variable=variable)
    project.set_Controls("parmMax", 5.0, variable=variable)
    project.refine()
    project.save()
    project = repeated_replay(path, count=1, cycles=6)
    histogram = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.getHAPvalues(histogram.name)
    value, esd = covariance_value(project, variable)
    return {
        "phase": phase.name,
        "phase_id": phase.id,
        "axis": list(axis),
        "project": str(path.relative_to(BASE)),
        "MD": {"value": value, "esd": esd, "stored": float(hap["Pref.Ori."][1])},
        "residuals": serial_residuals(histogram),
        "mass_fractions": {
            name: {"value": values[0], "esd": values[1]}
            for name, values in histogram.ComputeMassFracs().items()
        },
        "frozen": [str(item) for item in project.get_Frozen()],
    }


def run_texture_tests():
    source = WORK / "branch_combined_massicot_size.gpx"
    baseline = G2sc.G2Project(str(source))
    result = {
        "baseline": project_summary(baseline),
        "branches": [],
    }
    for phase_index, axes in TEXTURE_AXES.items():
        for axis in axes:
            branch = texture_branch(phase_index, axis)
            result["branches"].append(branch)
            print(
                f"{branch['phase']} {axis}: MD={branch['MD']['stored']:.5f}; "
                f"Rwp={branch['residuals']['wR']:.5f}; frozen={branch['frozen']}",
                flush=True,
            )
    with TEXTURE_LOG.open("w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)
    print(json.dumps(result, indent=2))


def configure_final_model(project):
    histogram = project.histogram(0)
    histogram.clear_refinements({"Limits": []})
    histogram.Excluded([])
    histogram.set_refinements({"Background": {"refine": True}})
    clear_profile_flags(histogram)
    histogram.set_refinements({"Instrument Parameters": ["Zero"]})

    instrument_values = {
        "U": 0.0,
        "V": 0.0,
        "W": 0.0,
        "X": 5.693131644077451,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "Polariz.": 0.7,
        "I(L2)/I(L1)": 0.5,
    }
    for key, value in instrument_values.items():
        histogram.InstrumentParameters[key][0] = value
        histogram.InstrumentParameters[key][1] = value
        histogram.InstrumentParameters[key][2] = False

    for value in histogram.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    histogram.SampleParameters["Scale"] = [1.0, False]
    for key in (
        "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Absorption",
        "DisplaceX", "DisplaceY",
    ):
        if key in histogram.SampleParameters:
            histogram.SampleParameters[key] = [0.0, False]

    for index, phase in enumerate(project.phases()):
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.getHAPvalues(histogram.name)
        hap["Pref.Ori."] = ["MD", 1.0, False, [0, 0, 1], 0, {}, [], 0.1]
        hap["Extinction"] = [0.0, False]
        hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [index in (0, 2, 3), False, False]
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2] = [index == 1, False, False]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        if index != 1:
            hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        if index == 1:
            hap["Size"][1] = [10.0, 10.0, 1.0]
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{histogram.id}:Scale")
        if index in (0, 2, 3):
            project.set_Controls("parmMin", 0.005,
                                 variable=f"{phase.id}:{histogram.id}:Size;i")
            project.set_Controls("parmMax", 10.0,
                                 variable=f"{phase.id}:{histogram.id}:Size;i")
        if index == 1:
            project.set_Controls("parmMin", 0.0,
                                 variable=f"{phase.id}:{histogram.id}:Mustrain;i")
            project.set_Controls("parmMax", 10000.0,
                                 variable=f"{phase.id}:{histogram.id}:Mustrain;i")


def correlation_audit(project, threshold: float = 0.80):
    covariance = project.data["Covariance"]["data"]
    matrix = np.asarray(covariance["covMatrix"], dtype=float)
    names = list(covariance["varyList"])
    diagonal = np.sqrt(np.clip(np.diag(matrix), 0.0, None))
    denominator = np.outer(diagonal, diagonal)
    with np.errstate(divide="ignore", invalid="ignore"):
        correlation = np.divide(matrix, denominator, out=np.zeros_like(matrix),
                                where=denominator > 0)
    pairs = []
    for row in range(len(names)):
        for column in range(row):
            value = float(correlation[row, column])
            if abs(value) >= threshold:
                pairs.append(
                    {
                        "variable_1": names[column],
                        "variable_2": names[row],
                        "correlation": value,
                    }
                )
    pairs.sort(key=lambda item: abs(item["correlation"]), reverse=True)
    return pairs


def export_fit_csv(histogram, path: Path):
    x = np.asarray(histogram.getdata("X"), dtype=float)
    observed = np.asarray(histogram.getdata("Yobs"), dtype=float)
    calculated = np.asarray(histogram.getdata("Ycalc"), dtype=float)
    background = np.asarray(histogram.getdata("Background"), dtype=float)
    difference = observed - calculated
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            ["two_theta_deg", "observed_counts", "calculated_counts",
             "difference_counts", "background_counts"]
        )
        writer.writerows(zip(x, observed, calculated, difference, background))


def run_finalize():
    source = WORK / "branch_combined_massicot_size.gpx"
    project = copy_project(source, FINAL_PROJECT)
    configure_cycles(project, 8)
    configure_final_model(project)
    project.save()

    # Required native save/reopen/full-range replay. Repeat only if the first
    # fresh replay has not brought all shifts below 0.1 esd.
    for _ in range(3):
        project = replay(FINAL_PROJECT, cycles=8)
        rvals = project.data["Covariance"]["data"]["Rvals"]
        if float(rvals.get("Max shft/sig", math.inf)) < 0.1:
            break
    project.save()
    project = G2sc.G2Project(str(FINAL_PROJECT))
    histogram = project.histogram(0)

    # Synchronize ignored axial placeholders with their active isotropic values
    # so the saved project contains no stale provisional HAP defaults.
    for phase in project.phases():
        hap = phase.getHAPvalues(histogram.name)
        hap["Size"][1][1] = hap["Size"][1][0]
        hap["Mustrain"][1][1] = hap["Mustrain"][1][0]
    project.save()
    project = G2sc.G2Project(str(FINAL_PROJECT))
    histogram = project.histogram(0)

    mass_fractions = histogram.ComputeMassFracs()
    phase_rows = []
    for index, phase_info in enumerate(FINAL_PHASES):
        phase = project.phase(index)
        cif_path = BASE / phase_info["cif"]
        phase.export_CIF(str(cif_path))
        cell, cell_esd = phase.get_cell_and_esd()
        fraction, fraction_esd = mass_fractions[phase.name]
        phase_rows.append(
            {
                "name": phase.name,
                "formula": phase_info["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "source_cod_id": phase_info["cod_id"],
                "cif_path": phase_info["cif"],
                "weight_fraction": float(fraction),
                "weight_fraction_esd": float(fraction_esd),
                "cell": {key: float(value) for key, value in cell.items()},
                "cell_esd": {key: float(value) for key, value in cell_esd.items()},
            }
        )

    export_fit_csv(histogram, BASE / "fit.csv")
    rvals = project.data["Covariance"]["data"]["Rvals"]
    fit_statistics = {
        "rwp_percent": float(rvals["Rwp"]),
        "rp_percent": float(histogram.residuals["R"]),
        "rexp_percent": float(histogram.residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_square": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_variables": int(rvals["Nvars"]),
        "max_shift_over_esd": float(rvals["Max shft/sig"]),
    }
    result = {
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over the four modeled crystalline phases",
        "phases": phase_rows,
        "fit_statistics": fit_statistics,
    }
    with (BASE / "result.json").open("w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)

    audit = {
        "summary": project_summary(project),
        "frozen_variables": [str(item) for item in project.get_Frozen()],
        "correlations_abs_ge_0.80": correlation_audit(project),
        "result_weight_sum": float(sum(row["weight_fraction"] for row in phase_rows)),
        "difference_column_max_abs_error": float(
            np.max(
                np.abs(
                    np.asarray(histogram.getdata("Residual"), dtype=float)
                    - (
                        np.asarray(histogram.getdata("Yobs"), dtype=float)
                        - np.asarray(histogram.getdata("Ycalc"), dtype=float)
                    )
                )
            )
        ),
    }
    with (WORK / "final_audit.json").open("w", encoding="utf-8") as handle:
        json.dump(audit, handle, indent=2)
    print(json.dumps({"result": result, "audit": audit}, indent=2))


def run_profile_tests():
    results = {
        "purpose": "common profile calibration on resolved WO3 reflections",
        "windows": [
            [23.35, 24.55],
            [33.50, 34.18],
            [41.72, 42.45],
            [48.48, 48.84],
            [70.82, 71.28],
        ],
        "branches": [],
    }
    results["branches"].append(profile_branch("x_only", {"X": 8.0}))
    results["branches"].append(
        profile_branch("uwx", {"U": 0.1, "W": 0.1, "X": 8.0})
    )
    x_value = results["branches"][0]["terms"]["X"]["stored"]
    results["accepted_common"] = make_common_stage(x_value)

    # Test bounded axial-divergence asymmetry after reconverging the full range.
    shl_source = WORK / "stage_common_profile.gpx"
    results["branches"].append(
        profile_branch("shl", {"SH/L": 0.01}, source=shl_source)
    )

    with PROFILE_LOG.open("w", encoding="utf-8") as handle:
        json.dump(results, handle, indent=2)
    print(json.dumps(results, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "stage",
        choices=["profile", "hap", "combine", "intensity", "texture", "finalize"],
    )
    args = parser.parse_args()
    if args.stage == "profile":
        run_profile_tests()
    elif args.stage == "hap":
        run_hap_tests()
    elif args.stage == "combine":
        run_combined_tests()
    elif args.stage == "intensity":
        run_global_intensity_test()
    elif args.stage == "texture":
        run_texture_tests()
    elif args.stage == "finalize":
        run_finalize()


if __name__ == "__main__":
    main()
