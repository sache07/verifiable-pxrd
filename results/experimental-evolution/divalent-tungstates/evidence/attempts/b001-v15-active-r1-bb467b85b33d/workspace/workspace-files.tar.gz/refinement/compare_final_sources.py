#!/usr/bin/env python3
"""Compare final structural sources under the complete retained nuisance model."""

from __future__ import annotations

import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from run_inventory_trials import neutralize_hap


ROOT = Path(__file__).resolve().parents[1]
CANDIDATES = ROOT / "refinement" / "candidates"
OUTDIR = ROOT / "refinement" / "trials" / "final_sources"

MODELS = {
    "eu_monoalt": ("SrWO4_from_EuWO4_1561850.cif", "WO3_mono_alt_2311041.cif"),
    "ca_monoalt": ("SrWO4_from_CaWO4_7219229.cif", "WO3_mono_alt_2311041.cif"),
    "srmo_monoalt": ("SrWO4_from_SrMoO4_2300460.cif", "WO3_mono_alt_2311041.cif"),
    "eu_triclinic": ("SrWO4_from_EuWO4_1561850.cif", "WO3_triclinic_2106293.cif"),
}

BACKGROUND = [1018.02815, 0.77584, 1.36014, 0.63738, 0.61991, -0.16978]


def max_shift(project: G2sc.G2Project) -> float:
    value = (
        project.data.get("Covariance", {})
        .get("data", {})
        .get("Rvals", {})
        .get("Max shft/sig", math.inf)
    )
    try:
        return abs(float(value))
    except (TypeError, ValueError):
        return math.inf


def replay(path: Path, count: int) -> G2sc.G2Project:
    project = G2sc.G2Project(str(path))
    project.set_Controls("cycles", 24)
    for _ in range(count):
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(path))
        if max_shift(project) < 0.08:
            break
    return project


def run(name: str, main_file: str, wo3_file: str) -> dict:
    path = OUTDIR / f"{name}.gpx"
    project = G2sc.G2Project(newgpx=str(path))
    histogram = project.add_powder_histogram(
        str(ROOT / "refinement" / "pattern.xye"),
        str(ROOT / "refinement" / "instrument.instprm"),
    )
    histogram.clear_refinements({"Sample Parameters": ["Scale"]})
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": BACKGROUND,
            }
        }
    )
    instrument = histogram.data["Instrument Parameters"][0]
    for key, value in {
        "Zero": 0.0,
        "U": 0.0,
        "V": 0.0,
        "W": 39.45,
        "X": 4.23,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "Polariz.": 0.73,
    }.items():
        instrument[key][1] = value
        instrument[key][2] = False
    histogram.data["Sample Parameters"]["Shift"] = [1057.3, False]

    specs = [
        ("SrWO4", main_file, 7.5),
        ("SrCO3", "SrCO3_Pnma_9008198.cif", 4.5),
        ("WO3", wo3_file, 2.1),
    ]
    for index, (phase_name, filename, scale) in enumerate(specs):
        phase = project.add_phase(
            str(CANDIDATES / filename),
            phasename=phase_name,
            histograms=[histogram],
            fmthint="CIF",
        )
        neutralize_hap(phase, histogram.name)
        phase.getHAPvalues(histogram.name)["Scale"][0] = scale
        phase.set_HAP_refinements({"Scale": True})
        project.set_Controls("parmMin", 0.0, variable=f"{index}:0:Scale")

    project.save()
    project = replay(path, 3)
    histogram = project.histogram(0)
    instrument = histogram.data["Instrument Parameters"][0]
    for key in ("W", "X", "Polariz."):
        instrument[key][2] = True
    project.set_Controls("parmMin", 0.0, variable=":0:W")
    project.set_Controls("parmMax", 100.0, variable=":0:W")
    project.set_Controls("parmMin", 0.0, variable=":0:X")
    project.set_Controls("parmMax", 20.0, variable=":0:X")
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    histogram.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})

    # Retained residual-phase size terms.
    for index, value in ((1, 0.45), (2, 0.15)):
        phase = project.phase(index)
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": value,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )
        project.set_Controls("parmMin", 0.01, variable=f"{index}:0:Size;i")
        project.set_Controls("parmMax", 1000.0, variable=f"{index}:0:Size;i")

    # Supported main-phase [110] March-Dollase texture.
    preferred = project.phase(0).getHAPvalues(histogram.name)["Pref.Ori."]
    preferred[0] = "MD"
    preferred[1] = 0.74
    preferred[2] = True
    preferred[3] = [1, 1, 0]
    project.set_Controls("parmMin", 0.2, variable="0:0:MD")
    project.set_Controls("parmMax", 5.0, variable="0:0:MD")

    project.save()
    project = replay(path, 12)
    project.save()
    histogram = project.histogram(0)
    fractions = histogram.ComputeMassFracs()
    return {
        "name": name,
        "project": str(path.relative_to(ROOT)),
        "Rwp_percent": float(histogram.residuals["wR"]),
        "Rp_percent": float(histogram.residuals["R"]),
        "max_shift_over_esd": max_shift(project),
        "fractions": {key: float(val[0]) for key, val in fractions.items()},
        "polarization": float(histogram.data["Instrument Parameters"][0]["Polariz."][1]),
        "texture_MD_110": float(
            project.phase(0).getHAPvalues(histogram.name)["Pref.Ori."][1]
        ),
        "sizes_micrometre": {
            phase.name: float(phase.getHAPvalues(histogram.name)["Size"][1][0])
            for phase in project.phases()
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "frozen": [str(v) for v in (project.get_Frozen() or [])],
    }


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    results = []
    for name, (main_file, wo3_file) in MODELS.items():
        print("FINAL_SOURCE " + name, flush=True)
        try:
            results.append(run(name, main_file, wo3_file))
        except Exception as exc:
            results.append({"name": name, "error": repr(exc)})
    (ROOT / "refinement" / "final_source_trials.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )
    print("FINAL_SOURCE_RESULTS " + json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
