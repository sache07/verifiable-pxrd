#!/usr/bin/env python3
"""Re-challenge phase/source choices under the established common profile."""

from __future__ import annotations

import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from run_inventory_trials import neutralize_hap


ROOT = Path(__file__).resolve().parents[1]
CANDIDATES = ROOT / "refinement" / "candidates"
OUTDIR = ROOT / "refinement" / "trials" / "rechallenge"

EU = ("SrWO4", "SrWO4_from_EuWO4_1561850.cif", 8.2)
SRMO = ("SrWO4", "SrWO4_from_SrMoO4_2300460.cif", 8.2)
CAW = ("SrWO4", "SrWO4_from_CaWO4_7219229.cif", 8.2)
PNMA = ("SrCO3", "SrCO3_Pnma_9008198.cif", 4.8)
R3M = ("SrCO3", "SrCO3_R3m_1539128.cif", 4.8)
MONO = ("WO3", "WO3_mono_RT_1528915.cif", 2.1)
MONO_ALT = ("WO3", "WO3_mono_alt_2311041.cif", 2.1)
TRI = ("WO3", "WO3_triclinic_2106293.cif", 2.1)
ORTHO = ("WO3", "WO3_orthorhombic_2107312.cif", 2.1)

TRIALS = {
    "selected_all": [EU, PNMA, MONO],
    "without_carbonate": [EU, MONO],
    "without_wo3": [EU, PNMA],
    "carbonate_r3m": [EU, R3M, MONO],
    "wo3_mono_alt": [EU, PNMA, MONO_ALT],
    "wo3_triclinic": [EU, PNMA, TRI],
    "wo3_orthorhombic": [EU, PNMA, ORTHO],
    "main_srmo_parent": [SRMO, PNMA, MONO],
    "main_cawo_parent": [CAW, PNMA, MONO],
}

BACKGROUND = [
    1031.2975274647556,
    11.576814717386897,
    -7.204805420401038,
    -6.218312285258916,
    -2.548264195020037,
    -1.2717122562344174,
]


def max_shift(project: G2sc.G2Project) -> float:
    value = (
        project.data.get("Covariance", {})
        .get("data", {})
        .get("Rvals", {})
        .get("Max shft/sig", math.inf)
    )
    try:
        return abs(float(value))
    except (TypeError, ValueError):
        return math.inf


def replay(path: Path, count: int) -> G2sc.G2Project:
    project = G2sc.G2Project(str(path))
    project.set_Controls("cycles", 24)
    for _ in range(count):
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(path))
        if max_shift(project) < 0.08:
            break
    return project


def run(name: str, specs: list[tuple[str, str, float]]) -> dict:
    path = OUTDIR / f"{name}.gpx"
    project = G2sc.G2Project(newgpx=str(path))
    histogram = project.add_powder_histogram(
        str(ROOT / "refinement" / "pattern.xye"),
        str(ROOT / "refinement" / "instrument.instprm"),
    )
    histogram.clear_refinements({"Sample Parameters": ["Scale"]})
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": len(BACKGROUND),
                "coeffs": BACKGROUND,
            }
        }
    )
    instrument = histogram.data["Instrument Parameters"][0]
    for key, value in {
        "Zero": 0.0,
        "U": 0.0,
        "V": 0.0,
        "W": 41.321,
        "X": 4.5134,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }.items():
        instrument[key][1] = value
        instrument[key][2] = False
    histogram.data["Sample Parameters"]["Shift"] = [1061.3, False]

    for index, (phase_name, filename, scale) in enumerate(specs):
        phase = project.add_phase(
            str(CANDIDATES / filename),
            phasename=phase_name,
            histograms=[histogram],
            fmthint="CIF",
        )
        neutralize_hap(phase, histogram.name)
        phase.getHAPvalues(histogram.name)["Scale"][0] = scale
        phase.set_HAP_refinements({"Scale": True})
        project.set_Controls("parmMin", 0.0, variable=f"{index}:0:Scale")

    project.save()
    project = replay(path, 3)
    histogram = project.histogram(0)
    histogram.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.save()
    project = replay(path, 10)
    project.save()

    histogram = project.histogram(0)
    fractions = histogram.ComputeMassFracs()
    return {
        "name": name,
        "project": str(path.relative_to(ROOT)),
        "Rwp_percent": float(histogram.residuals["wR"]),
        "Rp_percent": float(histogram.residuals["R"]),
        "max_shift_over_esd": max_shift(project),
        "sample_shift_micrometre": float(histogram.data["Sample Parameters"]["Shift"][0]),
        "phases": [
            {
                "name": phase.name,
                "scale": float(phase.getHAPvalues(histogram.name)["Scale"][0]),
                "weight_fraction": float(fractions.get(phase.name, (float("nan"),))[0]),
                "cell": {k: float(v) for k, v in phase.get_cell().items()},
            }
            for phase in project.phases()
        ],
        "frozen": [str(v) for v in (project.get_Frozen() or [])],
    }


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    results = []
    for name, specs in TRIALS.items():
        print(f"RECHALLENGE {name}", flush=True)
        try:
            results.append(run(name, specs))
        except Exception as exc:
            results.append({"name": name, "error": repr(exc)})
    (ROOT / "refinement" / "rechallenge_trials.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )
    print("RECHALLENGE_RESULTS " + json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
