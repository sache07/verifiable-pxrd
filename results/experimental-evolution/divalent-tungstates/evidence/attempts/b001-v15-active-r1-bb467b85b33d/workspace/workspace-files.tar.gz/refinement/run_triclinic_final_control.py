#!/usr/bin/env python3
"""Build a staged triclinic-WO3 control under the retained nuisance model."""

from __future__ import annotations

import contextlib
import io
import json
import math
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "refinement" / "trials" / "rechallenge" / "wo3_triclinic.gpx"
OUTDIR = ROOT / "refinement" / "trials" / "triclinic_final_control"
BASE = OUTDIR / "base.gpx"
PROFILE_CHECKPOINT = OUTDIR / "profile.gpx"
NO_WO3_TEXTURE = OUTDIR / "no_wo3_texture.gpx"
AXES = ([1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 0], [1, 0, 1], [0, 1, 1], [1, 1, 1])


def load(path: Path) -> G2sc.G2Project:
    with contextlib.redirect_stdout(io.StringIO()):
        return G2sc.G2Project(str(path))


def max_shift(project: G2sc.G2Project) -> float:
    value = (
        project.data.get("Covariance", {})
        .get("data", {})
        .get("Rvals", {})
        .get("Max shft/sig", math.inf)
    )
    return abs(float(value))


def replay(path: Path, count: int = 20) -> G2sc.G2Project:
    stable = 0
    for _ in range(count):
        with contextlib.redirect_stdout(io.StringIO()):
            project = G2sc.G2Project(str(path))
            project.set_Controls("cycles", 32)
            before = float(project.histogram(0).residuals["wR"])
            project.refine(makeBack=False)
            project.save()
            project = G2sc.G2Project(str(path))
        after = float(project.histogram(0).residuals["wR"])
        if max_shift(project) < 0.05 and abs(after - before) < 2e-5:
            stable += 1
        else:
            stable = 0
        if stable >= 2:
            break
    return project


def summary(project: G2sc.G2Project, stage: str) -> dict:
    histogram = project.histogram(0)
    fractions = histogram.ComputeMassFracs()
    covariance = project.data.get("Covariance", {}).get("data", {})
    return {
        "stage": stage,
        "Rwp_percent": float(histogram.residuals["wR"]),
        "Rp_percent": float(histogram.residuals["R"]),
        "GOF": float(covariance.get("Rvals", {}).get("GOF", math.nan)),
        "variables": len(covariance.get("varyList", [])),
        "max_shift_over_esd": max_shift(project),
        "fractions": {name: float(value[0]) for name, value in fractions.items()},
        "frozen": [str(value) for value in (project.get_Frozen() or [])],
    }


def save_quiet(project: G2sc.G2Project) -> None:
    with contextlib.redirect_stdout(io.StringIO()):
        project.save()


def configure_size(project: G2sc.G2Project, index: int, value: float) -> None:
    phase = project.phase(index)
    phase.set_HAP_refinements(
        {
            "Size": {
                "type": "isotropic",
                "value": value,
                "refine": True,
                "LGmix": {"value": 1.0, "refine": False},
            }
        }
    )
    project.set_Controls("parmMin", 0.01, variable=f"{index}:0:Size;i")
    project.set_Controls("parmMax", 1000.0, variable=f"{index}:0:Size;i")


def configure_texture(
    project: G2sc.G2Project, index: int, axis: list[int], value: float
) -> None:
    histogram = project.histogram(0)
    preferred = project.phase(index).getHAPvalues(histogram.name)["Pref.Ori."]
    preferred[0] = "MD"
    preferred[1] = value
    preferred[2] = True
    preferred[3] = list(axis)
    preferred[4] = 0
    project.set_Controls("parmMin", 0.2, variable=f"{index}:0:MD")
    project.set_Controls("parmMax", 5.0, variable=f"{index}:0:MD")


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(SOURCE, BASE)
    project = load(BASE)
    histogram = project.histogram(0)
    instrument = histogram.data["Instrument Parameters"][0]
    for name, value in {
        "Zero": 0.0,
        "U": 0.0,
        "V": 0.0,
        "W": 39.0,
        "X": 4.3,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "Polariz.": 0.70,
    }.items():
        instrument[name][1] = value
        instrument[name][2] = name in ("W", "X", "Polariz.")
    histogram.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    histogram.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    for name, maximum in (("W", 100.0), ("X", 20.0), ("Polariz.", 1.0)):
        project.set_Controls("parmMin", 0.0, variable=f":0:{name}")
        project.set_Controls("parmMax", maximum, variable=f":0:{name}")
    save_quiet(project)
    project = replay(BASE)
    rows = [summary(project, "profile")]
    print("TRICLINIC_CONTROL " + json.dumps(rows[-1]), flush=True)
    shutil.copy2(BASE, PROFILE_CHECKPOINT)

    # The carbonate size term is deliberately not carried into the selected
    # control: its same-checkpoint trial collapsed to the 0.01 um lower bound
    # and froze. Retain only the independently stable WO3 size term.
    configure_size(project, 2, 0.15)
    save_quiet(project)
    project = replay(BASE)
    rows.append(summary(project, "wo3_size"))
    print("TRICLINIC_CONTROL " + json.dumps(rows[-1]), flush=True)

    configure_texture(project, 0, [1, 1, 0], 0.74)
    save_quiet(project)
    project = replay(BASE)
    rows.append(summary(project, "srwo4_texture"))
    print("TRICLINIC_CONTROL " + json.dumps(rows[-1]), flush=True)
    shutil.copy2(BASE, NO_WO3_TEXTURE)

    texture_rows = []
    for axis in AXES:
        tag = "".join(str(value) for value in axis)
        path = OUTDIR / f"wo3_{tag}.gpx"
        shutil.copy2(NO_WO3_TEXTURE, path)
        trial = load(path)
        configure_texture(trial, 2, list(axis), 0.9)
        save_quiet(trial)
        try:
            trial = replay(path)
            row = summary(trial, f"wo3_texture_{tag}")
            row["axis"] = list(axis)
            row["MD"] = float(
                trial.phase(2)
                .getHAPvalues(trial.histogram(0).name)["Pref.Ori."][1]
            )
            row["project"] = str(path.relative_to(ROOT))
        except Exception as exc:
            row = {"stage": f"wo3_texture_{tag}", "axis": list(axis), "error": repr(exc)}
        texture_rows.append(row)
        print("TRICLINIC_TEXTURE " + json.dumps(row), flush=True)

    output = {"stages": rows, "texture_trials": texture_rows}
    (ROOT / "refinement" / "triclinic_final_control.json").write_text(
        json.dumps(output, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
