#!/usr/bin/env python3
"""Compare neutral, size, strain and combined broadening phase by phase."""

from __future__ import annotations

import json
import math
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "refinement" / "trials" / "selected_common_profile.gpx"
OUTDIR = ROOT / "refinement" / "trials" / "width"


def max_shift(project: G2sc.G2Project) -> float:
    value = (
        project.data.get("Covariance", {})
        .get("data", {})
        .get("Rvals", {})
        .get("Max shft/sig", math.inf)
    )
    try:
        return abs(float(value))
    except (TypeError, ValueError):
        return math.inf


def replay(path: Path, count: int = 10) -> G2sc.G2Project:
    project = G2sc.G2Project(str(path))
    project.set_Controls("cycles", 24)
    for _ in range(count):
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(path))
        if max_shift(project) < 0.08:
            break
    return project


def configure_term(project: G2sc.G2Project, phase_index: int, mode: str) -> None:
    phase = project.phase(phase_index)
    histogram = project.histogram(0)
    hap = phase.getHAPvalues(histogram.name)
    if mode in ("size", "combined"):
        hap["Size"][1][0] = 1.0
        hap["Size"][1][2] = 1.0
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": 1.0,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )
        project.set_Controls("parmMin", 0.01, variable=f"{phase_index}:0:Size;i")
        project.set_Controls("parmMax", 1000.0, variable=f"{phase_index}:0:Size;i")
    if mode in ("strain", "combined"):
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][2] = 1.0
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )
        project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, variable=f"{phase_index}:0:Mustrain;i")


def run(phase_index: int, mode: str) -> dict:
    phase_tag = ["srwo4", "srco3", "wo3"][phase_index]
    name = f"{phase_tag}_{mode}"
    path = OUTDIR / f"{name}.gpx"
    shutil.copy2(SOURCE, path)
    project = G2sc.G2Project(str(path))
    configure_term(project, phase_index, mode)
    project.save()
    project = replay(path)
    project.save()
    histogram = project.histogram(0)
    instrument = histogram.data["Instrument Parameters"][0]
    fractions = histogram.ComputeMassFracs()
    return {
        "name": name,
        "phase": project.phase(phase_index).name,
        "mode": mode,
        "project": str(path.relative_to(ROOT)),
        "Rwp_percent": float(histogram.residuals["wR"]),
        "Rp_percent": float(histogram.residuals["R"]),
        "max_shift_over_esd": max_shift(project),
        "profile_W": float(instrument["W"][1]),
        "profile_X": float(instrument["X"][1]),
        "fractions": {name: float(value[0]) for name, value in fractions.items()},
        "phase_terms": [
            {
                "name": phase.name,
                "size_type": phase.getHAPvalues(histogram.name)["Size"][0],
                "size_micrometre": float(
                    phase.getHAPvalues(histogram.name)["Size"][1][0]
                ),
                "size_refined": bool(
                    phase.getHAPvalues(histogram.name)["Size"][2][0]
                ),
                "microstrain": float(
                    phase.getHAPvalues(histogram.name)["Mustrain"][1][0]
                ),
                "microstrain_refined": bool(
                    phase.getHAPvalues(histogram.name)["Mustrain"][2][0]
                ),
            }
            for phase in project.phases()
        ],
        "frozen": [str(v) for v in (project.get_Frozen() or [])],
    }


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    results = []
    for phase_index in range(3):
        for mode in ("size", "strain", "combined"):
            name = f"{phase_index}_{mode}"
            print("WIDTH_TRIAL " + name, flush=True)
            try:
                results.append(run(phase_index, mode))
            except Exception as exc:
                results.append({"name": name, "error": repr(exc)})
    (ROOT / "refinement" / "width_trials.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )
    print("WIDTH_RESULTS " + json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
