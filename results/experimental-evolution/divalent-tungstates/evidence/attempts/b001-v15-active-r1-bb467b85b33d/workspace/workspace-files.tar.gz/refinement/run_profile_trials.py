#!/usr/bin/env python3
"""Establish a restrained common instrumental profile and angular correction."""

from __future__ import annotations

import json
import math
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "refinement" / "trials" / "inventory" / "eu_carbonate_mono.gpx"
OUTDIR = ROOT / "refinement" / "trials" / "profile"


def max_shift(project: G2sc.G2Project) -> float:
    value = (
        project.data.get("Covariance", {})
        .get("data", {})
        .get("Rvals", {})
        .get("Max shft/sig", math.inf)
    )
    try:
        return abs(float(value))
    except (TypeError, ValueError):
        return math.inf


def replay(path: Path, count: int = 10) -> G2sc.G2Project:
    project = G2sc.G2Project(str(path))
    project.set_Controls("cycles", 24)
    for _ in range(count):
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(path))
        if max_shift(project) < 0.05:
            break
    return project


def set_bounds(project: G2sc.G2Project, names: list[str]) -> None:
    for name in names:
        project.set_Controls("parmMin", 0.0, variable=f":0:{name}")
    for name, maximum in {"U": 100.0, "W": 100.0, "X": 20.0, "SH/L": 0.2}.items():
        if name in names:
            project.set_Controls("parmMax", maximum, variable=f":0:{name}")


def run_variant(name: str, profile_names: list[str], angular: str = "zero") -> dict:
    path = OUTDIR / f"{name}.gpx"
    shutil.copy2(SOURCE, path)
    project = G2sc.G2Project(str(path))
    histogram = project.histogram(0)
    instrument = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]

    for key in ["U", "V", "W", "X", "Y", "Z", "SH/L", "Zero"]:
        instrument[key][2] = False
    sample["Shift"][1] = False

    if angular == "zero":
        instrument["Zero"][2] = True
    elif angular == "shift":
        instrument["Zero"][1] = 0.0
        sample["Shift"] = [1000.0, True]
        project.set_Controls("parmMin", -5000.0, variable=":0:Shift")
        project.set_Controls("parmMax", 5000.0, variable=":0:Shift")
    else:
        raise ValueError(angular)

    for key in profile_names:
        instrument[key][2] = True
    set_bounds(project, profile_names)
    project.save()
    project = replay(path)
    project.save()

    histogram = project.histogram(0)
    instrument = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]
    fractions = histogram.ComputeMassFracs()
    return {
        "name": name,
        "project": str(path.relative_to(ROOT)),
        "Rwp_percent": float(histogram.residuals["wR"]),
        "Rp_percent": float(histogram.residuals["R"]),
        "max_shift_over_esd": max_shift(project),
        "zero_deg": float(instrument["Zero"][1]),
        "sample_shift_micrometre": float(sample["Shift"][0]),
        "profile": {
            key: {"value": float(instrument[key][1]), "refined": bool(instrument[key][2])}
            for key in ["U", "V", "W", "X", "Y", "Z", "SH/L"]
        },
        "phases": [
            {
                "name": phase.name,
                "weight_fraction": float(fractions.get(phase.name, (float("nan"),))[0]),
                "cell": {k: float(v) for k, v in phase.get_cell().items()},
            }
            for phase in project.phases()
        ],
        "frozen": [str(v) for v in (project.get_Frozen() or [])],
    }


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    variants = [
        ("zero_uw", ["U", "W"], "zero"),
        ("zero_uwx", ["U", "W", "X"], "zero"),
        ("zero_uwx_shl", ["U", "W", "X", "SH/L"], "zero"),
        ("shift_uwx", ["U", "W", "X"], "shift"),
    ]
    results = []
    for args in variants:
        print("PROFILE_TRIAL " + args[0], flush=True)
        try:
            results.append(run_variant(*args))
        except Exception as exc:
            results.append({"name": args[0], "error": repr(exc)})
    (ROOT / "refinement" / "profile_trials.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )
    print("PROFILE_RESULTS " + json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
