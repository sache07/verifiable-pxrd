#!/usr/bin/env python3
"""Compare chemically plausible phase/source inventories under one baseline."""

from __future__ import annotations

import json
import math
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
CANDIDATES = ROOT / "refinement" / "candidates"
TRIALS = ROOT / "refinement" / "trials" / "inventory"

MAIN_EU = ("SrWO4", "SrWO4_from_EuWO4_1561850.cif", 4.0)
MAIN_SRMO = ("SrWO4", "SrWO4_from_SrMoO4_2300460.cif", 4.0)
MAIN_CAW = ("SrWO4", "SrWO4_from_CaWO4_7219229.cif", 4.0)
CARBONATE = ("SrCO3", "SrCO3_Pnma_9008198.cif", 0.5)
CARBONATE_R3M = ("SrCO3", "SrCO3_R3m_1539128.cif", 0.5)
MONO_RT = ("WO3", "WO3_mono_RT_1528915.cif", 0.5)
MONO_ALT = ("WO3", "WO3_mono_alt_2311041.cif", 0.5)
TRICLINIC = ("WO3", "WO3_triclinic_2106293.cif", 0.5)
ORTHORHOMBIC = ("WO3", "WO3_orthorhombic_2107312.cif", 0.5)
TETRAGONAL = ("WO3", "WO3_tetragonal_1521532.cif", 0.5)
HP_TUNGSTATE = ("Sr3W2O9", "Sr3W2O9_high_pressure_2311977.cif", 0.25)

INVENTORIES = {
    "eu_only": [MAIN_EU],
    "eu_carbonate": [MAIN_EU, CARBONATE],
    "eu_mono": [MAIN_EU, MONO_RT],
    "eu_carbonate_mono": [MAIN_EU, CARBONATE, MONO_RT],
    "eu_carbonate_mono_alt": [MAIN_EU, CARBONATE, MONO_ALT],
    "eu_carbonate_triclinic": [MAIN_EU, CARBONATE, TRICLINIC],
    "eu_carbonate_orthorhombic": [MAIN_EU, CARBONATE, ORTHORHOMBIC],
    "eu_carbonate_tetragonal": [MAIN_EU, CARBONATE, TETRAGONAL],
    "eu_r3m_mono": [MAIN_EU, CARBONATE_R3M, MONO_RT],
    "srmo_carbonate_mono": [MAIN_SRMO, CARBONATE, MONO_RT],
    "cawo_carbonate_mono": [MAIN_CAW, CARBONATE, MONO_RT],
    "hp_tungstate_only": [HP_TUNGSTATE],
    "eu_carbonate_mono_plus_hp": [MAIN_EU, CARBONATE, MONO_RT, HP_TUNGSTATE],
}


def neutralize_hap(phase: G2sc.G2Phase, histogram_name: str) -> None:
    hap = phase.getHAPvalues(histogram_name)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1000.0
    hap["Size"][1][1] = 1000.0
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def max_shift(project: G2sc.G2Project) -> float:
    value = (
        project.data.get("Covariance", {})
        .get("data", {})
        .get("Rvals", {})
        .get("Max shft/sig", math.inf)
    )
    try:
        return abs(float(value))
    except (TypeError, ValueError):
        return math.inf


def replay(path: Path, count: int, tolerance: float = 0.05) -> G2sc.G2Project:
    project = G2sc.G2Project(str(path))
    project.set_Controls("cycles", 20)
    for _ in range(count):
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(path))
        if max_shift(project) < tolerance:
            break
    return project


def create_trial(name: str, specs: list[tuple[str, str, float]]) -> dict:
    path = TRIALS / f"{name}.gpx"
    for stale in path.parent.glob(f"{name}*"):
        if stale.is_file():
            stale.unlink()

    project = G2sc.G2Project(newgpx=str(path))
    histogram = project.add_powder_histogram(
        str(ROOT / "refinement" / "pattern.xye"),
        str(ROOT / "refinement" / "instrument.instprm"),
    )
    histogram.clear_refinements({"Sample Parameters": ["Scale"]})
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": [1050.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            }
        }
    )
    instrument = histogram.data["Instrument Parameters"][0]
    instrument["Zero"][1] = -0.55
    instrument["Zero"][2] = False
    for key, value in {"U": 2.0, "V": 0.0, "W": 5.0, "X": 0.1, "Y": 0.0, "Z": 0.0}.items():
        instrument[key][1] = value
        instrument[key][2] = False
    instrument["SH/L"][1] = 0.002
    instrument["SH/L"][2] = False

    phases = []
    for index, (phase_name, filename, initial_scale) in enumerate(specs):
        phase = project.add_phase(
            str(CANDIDATES / filename),
            phasename=phase_name,
            histograms=[histogram],
            fmthint="CIF",
        )
        neutralize_hap(phase, histogram.name)
        phase.getHAPvalues(histogram.name)["Scale"][0] = initial_scale
        phase.set_HAP_refinements({"Scale": True})
        project.set_Controls("parmMin", 0.0, variable=f"{index}:0:Scale")
        phases.append(phase)

    project.set_Controls("cycles", 20)
    project.save()

    # First establish background and scales with physically neutral nuisance terms.
    project = replay(path, 3)

    # Then release the shared angular correction and all phase cells together.
    histogram = project.histogram(0)
    histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.save()
    project = replay(path, 5)
    project.save()

    histogram = project.histogram(0)
    fractions = histogram.ComputeMassFracs()
    return {
        "name": name,
        "project": str(path.relative_to(ROOT)),
        "Rwp_percent": float(histogram.residuals["wR"]),
        "Rp_percent": float(histogram.residuals["R"]),
        "GOF": float(
            project.data.get("Covariance", {})
            .get("data", {})
            .get("Rvals", {})
            .get("GOF", float("nan"))
        ),
        "max_shift_over_esd": max_shift(project),
        "zero_deg": float(histogram.data["Instrument Parameters"][0]["Zero"][1]),
        "background": [float(v) for v in histogram.data["Background"][0][3:]],
        "phases": [
            {
                "name": phase.name,
                "cell": {k: float(v) for k, v in phase.get_cell().items()},
                "scale": float(phase.getHAPvalues(histogram.name)["Scale"][0]),
                "weight_fraction": float(fractions.get(phase.name, (float("nan"),))[0]),
                "short_distances": phase.ShortDistances(useAll=False),
            }
            for phase in project.phases()
        ],
        "frozen": [str(v) for v in (project.get_Frozen() or [])],
    }


def main() -> None:
    TRIALS.mkdir(parents=True, exist_ok=True)
    results = []
    for name, specs in INVENTORIES.items():
        print(f"INVENTORY_TRIAL {name}", flush=True)
        try:
            results.append(create_trial(name, specs))
        except Exception as exc:
            results.append({"name": name, "error": repr(exc)})
    output = ROOT / "refinement" / "inventory_trials.json"
    output.write_text(json.dumps(results, indent=2) + "\n")
    print("INVENTORY_RESULTS " + json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
