#!/usr/bin/env python3
"""Export the submitted files from the converged final GSAS-II project."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
PROJECT_PATH = ROOT / "final.gpx"
PATTERN_PATH = ROOT / "inputs" / "pattern.csv"

PHASE_METADATA = {
    "SrWO4": {
        "formula": "SrWO4",
        "cif_path": "phase_SrWO4.cif",
        "structure_type": "scheelite",
    },
    "SrCO3": {
        "formula": "SrCO3",
        "cif_path": "phase_SrCO3.cif",
        "structure_type": "strontianite",
    },
    "WO3": {
        "formula": "WO3",
        "cif_path": "phase_WO3.cif",
        "structure_type": "triclinic tungsten trioxide",
    },
}


def as_float(value):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"non-finite value encountered: {value}")
    return value


def main() -> None:
    project = G2sc.G2Project(str(PROJECT_PATH))
    histograms = project.histograms()
    if len(histograms) != 1:
        raise RuntimeError(f"expected one histogram, found {len(histograms)}")
    histogram = histograms[0]

    observed_input = np.genfromtxt(
        PATTERN_PATH, delimiter=",", names=True, dtype=np.float64
    )
    input_x = np.asarray(observed_input["two_theta_deg"], dtype=np.float64)
    input_y = np.asarray(observed_input["intensity"], dtype=np.float64)
    x = np.asarray(histogram.getdata("x"), dtype=np.float64)
    yobs = np.asarray(histogram.getdata("yobs"), dtype=np.float64)
    ycalc = np.asarray(histogram.getdata("ycalc"), dtype=np.float64)
    difference = yobs - ycalc

    if len(x) != len(input_x) or not np.array_equal(x, input_x):
        raise RuntimeError("the final project does not retain the original 2theta grid")
    if not np.array_equal(yobs, input_y):
        raise RuntimeError("the final project does not retain the original observations")
    if not np.isfinite(ycalc).all() or not np.isfinite(difference).all():
        raise RuntimeError("calculated profile contains a non-finite value")

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "difference"]
        )
        for row in zip(input_x, input_y, ycalc, difference):
            # repr(float) is the shortest decimal that round-trips to the exact
            # binary value, so observations are not rounded during export.
            writer.writerow([repr(float(value)) for value in row])

    mass_fractions = histogram.ComputeMassFracs()
    fraction_sum = sum(as_float(value[0]) for value in mass_fractions.values())
    if not math.isclose(fraction_sum, 1.0, rel_tol=0.0, abs_tol=1e-10):
        raise RuntimeError(f"modeled phase fractions sum to {fraction_sum}, not one")

    phase_rows = []
    for phase in project.phases():
        if phase.name not in PHASE_METADATA:
            raise RuntimeError(f"unexpected phase in final project: {phase.name}")
        metadata = PHASE_METADATA[phase.name]
        cif_path = ROOT / metadata["cif_path"]
        phase.export_CIF(str(cif_path))
        fraction, fraction_esd = mass_fractions[phase.name]
        cell = phase.get_cell()
        hap = phase.data["Histograms"][histogram.name]
        residuals = histogram.residuals
        phase_id = phase.id
        phase_rows.append(
            {
                "name": phase.name,
                "formula": metadata["formula"],
                "structure_type": metadata["structure_type"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": metadata["cif_path"],
                "weight_fraction": as_float(fraction) / fraction_sum,
                "weight_fraction_esd": as_float(fraction_esd),
                "cell": {
                    "a_A": as_float(cell["length_a"]),
                    "b_A": as_float(cell["length_b"]),
                    "c_A": as_float(cell["length_c"]),
                    "alpha_deg": as_float(cell["angle_alpha"]),
                    "beta_deg": as_float(cell["angle_beta"]),
                    "gamma_deg": as_float(cell["angle_gamma"]),
                    "volume_A3": as_float(cell["volume"]),
                },
                "phase_fit_statistics": {
                    "R_F_percent": as_float(residuals[f"{phase_id}:0:Rf"]),
                    "R_F_squared_percent": as_float(
                        residuals[f"{phase_id}:0:Rf^2"]
                    ),
                    "reflection_count": int(residuals[f"{phase_id}:0:Nref"]),
                },
                "refined_scale": as_float(hap["Scale"][0]),
            }
        )

    covariance_rvals = (
        project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    )
    residuals = histogram.residuals
    result = {
        "refinement_histogram": histogram.name,
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over modeled crystalline phases",
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": as_float(residuals["wR"]),
            "Rp_percent": as_float(residuals["R"]),
            "R_expected_percent": as_float(residuals["wRmin"]),
            "GOF": as_float(covariance_rvals["GOF"]),
            "chi_squared": as_float(covariance_rvals["chisq"]),
            "background_R_percent": as_float(residuals["Rb"]),
            "weighted_background_R_percent": as_float(residuals["wRb"]),
            "observations": int(covariance_rvals["Nobs"]),
            "variables": int(covariance_rvals["Nvars"]),
            "maximum_shift_over_esd": as_float(
                covariance_rvals["Max shft/sig"]
            ),
        },
    }
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2, sort_keys=False)
        stream.write("\n")

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
