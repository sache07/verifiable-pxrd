#!/usr/bin/env python3
"""Prepare lossless powder input and chemically screened trial structures."""

from __future__ import annotations

import csv
import math
import shutil
from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parents[1]
RESOURCE = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)
CANDIDATES = ROOT / "refinement" / "candidates"


def cod_path(cod_id: str) -> Path:
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_xye() -> None:
    """Copy x/y text exactly and append Poisson counting uncertainties."""
    source = ROOT / "inputs" / "pattern.csv"
    output = ROOT / "refinement" / "pattern.xye"
    with source.open(newline="") as src, output.open("w") as dst:
        rows = csv.reader(src)
        next(rows)
        for x_text, y_text in rows:
            sigma = math.sqrt(max(float(y_text), 1.0))
            dst.write(f"{x_text} {y_text} {sigma:.12g}\n")


def write_instrument() -> None:
    text = """#GSAS-II instrument parameter file for measured Cu Kalpha lab data
Type:PXC;Bank:1
Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.5;Azimuth:0.0;I(L2)/I(L1):0.5
U:2.0;V:0.0;W:5.0;X:0.1;Y:0.0;Z:0.0;SH/L:0.002
"""
    (ROOT / "refinement" / "instrument.instprm").write_text(text)


def substituted(
    name: str,
    cod_id: str,
    substitutions: dict[str, str],
    target_lattice: Lattice | None = None,
) -> None:
    structure = Structure.from_file(cod_path(cod_id))
    structure.replace_species(substitutions)
    if target_lattice is not None:
        structure = Structure(
            target_lattice,
            structure.species,
            structure.frac_coords,
            site_properties=structure.site_properties,
        )
    CifWriter(structure, symprec=1e-3).write_file(CANDIDATES / name)


def copied(name: str, cod_id: str) -> None:
    shutil.copy2(cod_path(cod_id), CANDIDATES / name)


def main() -> None:
    CANDIDATES.mkdir(parents=True, exist_ok=True)
    write_xye()
    write_instrument()

    # Cross-chemistry scheelite prototypes. SrMoO4 preserves the A site;
    # EuWO4 and CaWO4 preserve the tetrahedral W site and offer physical
    # alternatives for the oxygen coordinate.
    # Put all parents on the same plausible SrWO4 metric so that the source
    # comparison tests coordinates/intensities rather than a starting-cell trap.
    srwo4_lattice = Lattice.tetragonal(5.4145, 11.9494)
    substituted(
        "SrWO4_from_SrMoO4_2300460.cif",
        "2300460",
        {"Mo": "W"},
        srwo4_lattice,
    )
    substituted(
        "SrWO4_from_EuWO4_1561850.cif",
        "1561850",
        {"Eu": "Sr"},
        srwo4_lattice,
    )
    substituted(
        "SrWO4_from_CaWO4_7219229.cif",
        "7219229",
        {"Ca": "Sr"},
        srwo4_lattice,
    )

    # Exact residual/source records and physically distinct WO3 alternatives.
    copied("SrCO3_Pnma_9008198.cif", "9008198")
    copied("SrCO3_R3m_1539128.cif", "1539128")
    copied("WO3_mono_RT_1528915.cif", "1528915")
    copied("WO3_mono_alt_2311041.cif", "2311041")
    copied("WO3_triclinic_2106293.cif", "2106293")
    copied("WO3_orthorhombic_2107312.cif", "2107312")
    copied("WO3_tetragonal_1521532.cif", "1521532")
    copied("Sr3W2O9_high_pressure_2311977.cif", "2311977")


if __name__ == "__main__":
    main()
