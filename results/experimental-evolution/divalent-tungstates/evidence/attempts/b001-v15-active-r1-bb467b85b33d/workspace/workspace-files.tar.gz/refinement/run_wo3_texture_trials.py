#!/usr/bin/env python3
"""Challenge low-index WO3 March-Dollase axes from the final checkpoint."""

from __future__ import annotations

import contextlib
import io
import json
import math
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "final.gpx"
OUTDIR = ROOT / "refinement" / "trials" / "wo3_texture"
AXES = ([1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 0], [1, 0, 1], [0, 1, 1], [1, 1, 1])


def max_shift(project: G2sc.G2Project) -> float:
    value = (
        project.data.get("Covariance", {})
        .get("data", {})
        .get("Rvals", {})
        .get("Max shft/sig", math.inf)
    )
    return abs(float(value))


def replay(path: Path, count: int = 12) -> G2sc.G2Project:
    stable = 0
    for _ in range(count):
        with contextlib.redirect_stdout(io.StringIO()):
            project = G2sc.G2Project(str(path))
            before = float(project.histogram(0).residuals["wR"])
            project.set_Controls("cycles", 32)
            project.refine(makeBack=False)
            project.save()
            project = G2sc.G2Project(str(path))
        after = float(project.histogram(0).residuals["wR"])
        if max_shift(project) < 0.05 and abs(after - before) < 2e-5:
            stable += 1
        else:
            stable = 0
        if stable >= 2:
            break
    return project


def run(axis: list[int]) -> dict:
    tag = "".join(str(value) for value in axis)
    path = OUTDIR / f"wo3_{tag}.gpx"
    shutil.copy2(SOURCE, path)
    with contextlib.redirect_stdout(io.StringIO()):
        project = G2sc.G2Project(str(path))
    histogram = project.histogram(0)
    phase = project.phase("WO3")
    preferred = phase.getHAPvalues(histogram.name)["Pref.Ori."]
    preferred[0] = "MD"
    preferred[1] = 1.0
    preferred[2] = True
    preferred[3] = list(axis)
    preferred[4] = 0
    project.set_Controls("parmMin", 0.2, variable="2:0:MD")
    project.set_Controls("parmMax", 5.0, variable="2:0:MD")
    with contextlib.redirect_stdout(io.StringIO()):
        project.save()
    project = replay(path)
    histogram = project.histogram(0)
    preferred = project.phase("WO3").getHAPvalues(histogram.name)["Pref.Ori."]
    covariance = project.data.get("Covariance", {}).get("data", {})
    vary_list = [str(value) for value in covariance.get("varyList", [])]
    correlations = covariance.get("covMatrix")
    return {
        "axis": axis,
        "project": str(path.relative_to(ROOT)),
        "Rwp_percent": float(histogram.residuals["wR"]),
        "MD": float(preferred[1]),
        "max_shift_over_esd": max_shift(project),
        "frozen": [str(value) for value in (project.get_Frozen() or [])],
        "varied_MD": any(value.endswith(":MD") for value in vary_list),
        "has_covariance": correlations is not None,
    }


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    rows = []
    for axis in AXES:
        try:
            row = run(list(axis))
        except Exception as exc:
            row = {"axis": list(axis), "error": repr(exc)}
        rows.append(row)
        print("WO3_TEXTURE " + json.dumps(row), flush=True)
    (ROOT / "refinement" / "wo3_texture_trials.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
