#!/usr/bin/env python3
"""Clean final-pass GSAS-II refinement and branch-testing helpers."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from analysis_rietveld import G2sc, build_project, refinement_snapshot


FINAL_SPECS = [
    ("CaWO4_scheelite", "7219229", 40.0),
    ("WO3_monoclinic", "2311041", 5.0),
    (
        "Ca3WO6_double_perovskite",
        ".tmp/Ca3WO6_from_Ca3OsO6_1562666_gsas.cif",
        10.0,
    ),
]


def set_common_bounds(project: G2sc.G2Project) -> None:
    project.set_Controls("parmMin", 0.0, variable="*:0:Scale")
    for variable, low, high in (
        (":0:U", 0.0, 1500.0),
        (":0:W", 0.0, 500.0),
        (":0:X", 0.0, 100.0),
        (":0:Shift", -1000.0, 1000.0),
    ):
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)


def save_reopen_replay(project: G2sc.G2Project) -> G2sc.G2Project:
    """Save, reopen, and run a fresh full-range native refinement."""
    filename = project.filename
    project.save()
    replay = G2sc.G2Project(filename)
    replay.set_Controls("cycles", 10)
    replay.refine()
    replay.save()
    return G2sc.G2Project(filename)


def build_clean_base(output: Path) -> G2sc.G2Project:
    project = build_project(output, FINAL_SPECS)
    project.set_Controls("cycles", 10)
    set_common_bounds(project)
    hist = project.histogram(0)
    phases = project.phases()

    # Clean inventory restart: only background and positive phase scales first.
    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    project.refine()

    # One identifiable angular correction: specimen displacement. Zero is fixed.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.refine()

    # Refit all cells while background/scales/displacement remain active.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.refine()

    # Fit the requested low-dimensional nonnegative common U/W/X profile.
    # With truly neutral phase broadening this must be challenged anew.
    inst = hist.data["Instrument Parameters"][0]
    inst["U"] = [80.0, 80.0, False]
    inst["V"] = [0.0, 0.0, False]
    inst["W"][1] = 30.0
    inst["X"][1] = 8.0
    inst["Y"] = [0.0, 0.0, False]
    inst["Z"] = [0.0, 0.0, False]
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.refine()
    project.refine()
    project.save()
    return save_reopen_replay(project)


def test_shl(source: Path, output: Path) -> G2sc.G2Project:
    project = G2sc.G2Project(str(source), newgpx=str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    shl = hist.data["Instrument Parameters"][0]["SH/L"]
    shl[1] = 0.002
    shl[2] = False
    project.set_Controls("parmMin", 0.0001, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.1, variable=":0:SH/L")
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    project.set_Controls("cycles", 10)
    project.save()
    project.refine()
    project.refine()
    project.save()
    return G2sc.G2Project(str(output))


def test_broadening(
    source: Path, output: Path, phase_index: int, mode: str
) -> G2sc.G2Project:
    """Challenge one isotropic size-only or strain-only phase branch."""
    project = G2sc.G2Project(str(source), newgpx=str(output))
    project.set_Frozen()
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.data["Histograms"][hist.name]
    if mode == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:3] = [1.0, 1.0, 1.0]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": 1.0,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )
        variable = f"{phase_index}:0:Size;i"
        project.set_Controls("parmMin", 0.005, variable=variable)
        project.set_Controls("parmMax", 20.0, variable=variable)
    elif mode == "strain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:3] = [1000.0, 1000.0, 1.0]
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )
        variable = f"{phase_index}:0:Mustrain;i"
        project.set_Controls("parmMin", 1.0, variable=variable)
        project.set_Controls("parmMax", 10000.0, variable=variable)
    else:
        raise ValueError(mode)
    project.save()
    project.refine()
    project.refine()
    project.save()
    return G2sc.G2Project(str(output))


def test_texture(
    source: Path, output: Path, phase_index: int, axis: tuple[int, int, int]
) -> G2sc.G2Project:
    """Test one bounded March-Dollase axis from an otherwise neutral HAP."""
    project = G2sc.G2Project(str(source), newgpx=str(output))
    project.set_Frozen()
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = list(axis)
    variable = f"{phase_index}:0:MD"
    project.set_Controls("parmMin", 0.2, variable=variable)
    project.set_Controls("parmMax", 5.0, variable=variable)
    project.save()
    project.refine()
    project.refine()
    project.save()
    return G2sc.G2Project(str(output))


def test_background(
    source: Path, output: Path, coefficients: int
) -> G2sc.G2Project:
    """Rechallenge the Chebyshev background dimensionality."""
    project = G2sc.G2Project(str(source), newgpx=str(output))
    project.set_Frozen()
    project.set_Controls("cycles", 10)
    project.histogram(0).set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True,
                        "no. coeffs": coefficients}}
    )
    project.save()
    project.refine()
    project.refine()
    project.save()
    return G2sc.G2Project(str(output))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "action", choices=("base", "shl", "broadening", "texture", "background", "snapshot")
    )
    parser.add_argument("--source", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--snapshot", type=Path)
    parser.add_argument("--phase-index", type=int)
    parser.add_argument("--mode", choices=("size", "strain"))
    parser.add_argument("--axis", nargs=3, type=int)
    parser.add_argument("--coefficients", type=int)
    args = parser.parse_args()
    if args.action == "base":
        project = build_clean_base(args.output)
    elif args.action == "shl":
        if args.source is None:
            parser.error("shl requires --source")
        project = test_shl(args.source, args.output)
    elif args.action == "broadening":
        if args.source is None or args.phase_index is None or args.mode is None:
            parser.error("broadening requires --source, --phase-index and --mode")
        project = test_broadening(
            args.source, args.output, args.phase_index, args.mode
        )
    elif args.action == "texture":
        if args.source is None or args.phase_index is None or args.axis is None:
            parser.error("texture requires --source, --phase-index and --axis")
        project = test_texture(
            args.source, args.output, args.phase_index, tuple(args.axis)
        )
    elif args.action == "background":
        if args.source is None or args.coefficients is None:
            parser.error("background requires --source and --coefficients")
        project = test_background(args.source, args.output, args.coefficients)
    else:
        project = G2sc.G2Project(str(args.output))
    snapshot = refinement_snapshot(project)
    payload = json.dumps(snapshot, indent=2, default=float) + "\n"
    print(payload)
    if args.snapshot:
        args.snapshot.write_text(payload)


if __name__ == "__main__":
    main()
