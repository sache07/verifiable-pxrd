#!/usr/bin/env python3
"""Scriptable GSAS-II helpers for the Ca--W--O phase analysis.

This file keeps the trial and final refinements reproducible.  It is not one
of the requested deliverables; the requested deliverables are generated from
the final project after model selection.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
COD_ROOT = Path(
    "<RUN>/"
    "resources/b001-c05/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_inputs() -> tuple[Path, Path]:
    """Create a Poisson-weighted xye file and the known Cu K-alpha setup."""
    TMP.mkdir(exist_ok=True)
    pattern = np.genfromtxt(
        ROOT / "inputs" / "pattern.csv", delimiter=",", names=True
    )
    x = np.asarray(pattern["two_theta_deg"], dtype=float)
    y = np.asarray(pattern["intensity"], dtype=float)
    sigma = np.sqrt(np.maximum(y, 1.0))
    xye = TMP / "pattern.xye"
    if not xye.exists():
        np.savetxt(xye, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")

    inst = TMP / "cu_kalpha.instprm"
    if not inst.exists():
        inst.write_text(
            "#GSAS-II instrument parameter file for reflection Cu K-alpha data\n"
            "Type:PXC;Bank:1;Diff-type:Bragg-Brentano;Gonio.radius:240.0\n"
            "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.5;"
            "Azimuth:0.0;I(L2)/I(L1):0.5\n"
            "U:80.0;V:0.0;W:30.0;X:5.0;Y:0.0;Z:0.0;SH/L:0.002\n"
        )
    return xye, inst


def neutralize_histogram(hist) -> None:
    """Set a clean reflection-geometry starting model."""
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "refine": False,
                "no. coeffs": 10,
                "coeffs": [1500.0] + [0.0] * 9,
            },
        }
    )
    inst = hist.data["Instrument Parameters"][0]
    starting = {
        "Lam1": 1.540598,
        "Lam2": 1.544426,
        "I(L2)/I(L1)": 0.5,
        "Zero": 0.0,
        "Polariz.": 0.5,
        "U": 80.0,
        "V": 0.0,
        "W": 30.0,
        "X": 5.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }
    for key, value in starting.items():
        inst[key][1] = value
        inst[key][2] = False

    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [300.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]


def neutralize_phase(phase, hist_name: str, start_scale: float) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"] = [float(start_scale), False]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    hap["Pref.Ori."] = ["MD", 1.0, False, [0, 0, 1], 0, {}, [], 0.1]
    hap["Size"][0] = "isotropic"
    # HAP values contribute even when their refine flags are off. Use the
    # GSAS-II practical no-broadening limits, not the GUI defaults.
    hap["Size"][1][:3] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:3] = [1.0, 1.0, 1.0]
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    if "HStrain" in hap:
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])


def build_project(
    output: Path,
    phase_specs: list[tuple[str, str, float]],
) -> G2sc.G2Project:
    """Create an unrefined project from (phase name, COD id, scale) specs."""
    xye, inst = prepare_inputs()
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    neutralize_histogram(hist)
    for name, cod_id, scale in phase_specs:
        phase_file = Path(cod_id)
        if phase_file.suffix.lower() != ".cif":
            phase_file = cod_path(cod_id)
        phase = project.add_phase(
            str(phase_file), phasename=name, histograms=[hist]
        )
        neutralize_phase(phase, hist.name, scale)
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
    project.save()
    return project


def refinement_snapshot(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "project": project.filename,
        "wR_percent": hist.get_wR(),
        "gof": cov.get("GOF"),
        "Rvals": cov.get("Rvals"),
        "instrument": {k: inst[k][1] for k in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Zero")},
        "sample": {
            k: sample[k][0]
            for k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
            if k in sample
        },
        "frozen": project.get_Frozen(),
        "varyList": [str(v) for v in cov.get("varyList", [])],
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    try:
        result["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        result["mass_fraction_error"] = repr(exc)
    return result


def run_provisional(output: Path, phase_specs: list[tuple[str, str, float]]) -> dict:
    """Run the same modest inventory schedule for a candidate phase set."""
    project = build_project(output, phase_specs)
    hist = project.histogram(0)
    phases = project.phases()

    # Physical bounds are deliberately broad. A bound hit is logged and the
    # branch is rejected rather than accepted as a frozen answer.
    project.set_Controls("parmMin", 0.0, variable="*:0:Scale")
    for var, low, high in (
        (":0:U", 0.0, 1500.0),
        (":0:W", 0.0, 500.0),
        (":0:X", 0.0, 100.0),
        (":0:Shift", -1000.0, 1000.0),
    ):
        project.set_Controls("parmMin", low, variable=var)
        project.set_Controls("parmMax", high, variable=var)

    # Background and all nonnegative phase scales.
    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    project.refine()

    # The single angular correction is specimen displacement; zero remains 0.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.refine()

    # Refit every cell with background, scales and displacement still active.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.refine()

    # Restrained common provisional profile, with V/Y/Z fixed at zero.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.refine()
    project.refine()
    project.save()
    return refinement_snapshot(project)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--phase",
        action="append",
        nargs=3,
        metavar=("NAME", "COD_ID", "START_SCALE"),
        required=True,
    )
    parser.add_argument("--snapshot", type=Path)
    args = parser.parse_args()
    specs = [(name, cod, float(scale)) for name, cod, scale in args.phase]
    snap = run_provisional(args.output, specs)
    print(json.dumps(snap, indent=2, default=float))
    if args.snapshot:
        args.snapshot.write_text(json.dumps(snap, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
