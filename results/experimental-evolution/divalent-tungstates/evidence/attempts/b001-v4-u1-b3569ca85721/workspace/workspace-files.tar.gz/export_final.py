#!/usr/bin/env python3
"""Export all submitted artifacts from the exact final GSAS-II project."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"

PHASE_EXPORTS = {
    "CaWO4_scheelite": {
        "formula": "CaWO4",
        "cif": "CaWO4.cif",
        "source_model": "COD 7219229",
    },
    "WO3_monoclinic": {
        "formula": "WO3",
        "cif": "WO3.cif",
        "source_model": "COD 2311041",
    },
    "Ca3WO6_double_perovskite": {
        "formula": "Ca3WO6",
        "cif": "Ca3WO6.cif",
        "source_model": "Ca3OsO6 COD 1562666 with Os6+ -> W6+",
    },
}


def main() -> None:
    project = G2sc.G2Project(str(PROJECT))
    histogram = project.histogram(0)
    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    if project.get_Frozen():
        raise RuntimeError(f"final project contains frozen variables: {project.get_Frozen()}")

    profile = np.ma.filled(histogram.data["data"][1], np.nan)
    two_theta, observed, weights, calculated, background, stored_difference = (
        np.asarray(row, dtype=float) for row in profile
    )
    difference = observed - calculated
    if not np.allclose(difference, stored_difference, rtol=0.0, atol=1e-7):
        raise RuntimeError("stored GSAS-II difference profile is inconsistent")
    if np.any(~np.isfinite(profile)):
        raise RuntimeError("nonfinite values in the final profile")

    source = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    if len(source) != len(two_theta):
        raise RuntimeError("final project does not contain every input point")
    if not np.allclose(source["two_theta_deg"], two_theta, rtol=0.0, atol=5e-8):
        raise RuntimeError("final-project angles differ from pattern.csv")
    if not np.allclose(source["intensity"], observed, rtol=0.0, atol=5e-6):
        raise RuntimeError("final-project observations differ from pattern.csv")

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta_deg", "observed_counts", "calculated_counts", "difference_counts"]
        )
        for row in zip(two_theta, observed, calculated, difference):
            writer.writerow((f"{row[0]:.8f}",) + tuple(f"{v:.8f}" for v in row[1:]))

    raw_fractions = histogram.ComputeMassFracs()
    total_fraction = sum(value[0] for value in raw_fractions.values())
    if total_fraction <= 0:
        raise RuntimeError("nonpositive crystalline fraction sum")

    metadata = histogram.data["data"][0]
    phase_results = []
    for phase_index, phase in enumerate(project.phases()):
        spec = PHASE_EXPORTS[phase.name]
        phase.export_CIF(str(ROOT / spec["cif"]))
        fraction, fraction_esd = raw_fractions[phase.name]
        cell = phase.get_cell()
        phase_results.append(
            {
                "name": phase.name,
                "formula": spec["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": spec["cif"],
                "source_model": spec["source_model"],
                "weight_fraction": fraction / total_fraction,
                "weight_percent": 100.0 * fraction / total_fraction,
                "weight_fraction_esd_formal": fraction_esd / total_fraction,
                "r_bragg_percent": metadata[f"{phase_index}:0:Rf"],
                "cell": cell,
            }
        )

    nobs = int(rvals["Nobs"])
    nvars = int(rvals["Nvars"])
    dof = nobs - nvars
    rwp = float(rvals["Rwp"])
    gof = float(rvals["GOF"])
    result = {
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "fraction_basis": (
            "normalized over the modeled crystalline phases; amorphous or other "
            "noncrystalline material is not quantified"
        ),
        "phases": phase_results,
        "fit_statistics": {
            "r_wp_percent": rwp,
            "r_p_percent": float(metadata["R"]),
            "r_expected_percent": rwp / gof,
            "goodness_of_fit": gof,
            "chi_square": float(rvals["chisq"]),
            "reduced_chi_square": float(rvals["chisq"]) / dof,
            "durbin_watson": float(metadata["Durbin-Watson"]),
            "n_observations": nobs,
            "n_refined_parameters": nvars,
            "degrees_of_freedom": dof,
            "fit_range_two_theta_deg": [float(two_theta[0]), float(two_theta[-1])],
            "weighting": "Poisson approximation: sigma = sqrt(max(counts, 1))",
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
