#!/usr/bin/env python3
"""Create the screened Ca3WO6 prototype used for GSAS-II import.

COD 1562666 is Ca3OsO6 (P21/n), with ordered Ca/Os sites and regular OsO6
octahedra.  Os6+ -> W6+ is isovalent and leaves the fully occupied framework
unchanged.  The cell is deliberately not rescaled here; it is refined against
the diffraction pattern before any profile specialization.
"""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
SOURCE = Path(
    "<RUN>/"
    "resources/b001-c05/cif/1/56/26/1562666.cif"
)
OUTPUT = ROOT / ".tmp" / "Ca3WO6_from_Ca3OsO6_1562666.cif"
OUTPUT_GSAS = ROOT / ".tmp" / "Ca3WO6_from_Ca3OsO6_1562666_gsas.cif"
SOURCE_U = Path(
    "<RUN>/"
    "resources/b001-c05/cif/2/31/04/2310470.cif"
)
OUTPUT_U = ROOT / ".tmp" / "Ca3WO6_from_Ca3UO6_2310470.cif"


def main() -> None:
    structure = Structure.from_file(SOURCE, primitive=False)
    structure.replace_species({"Os": "W"})
    OUTPUT.parent.mkdir(exist_ok=True)
    CifWriter(structure, symprec=0.01, refine_struct=False).write_file(OUTPUT)
    # GSAS-II's CIF reader requires its preferred P21/n setting. Preserve the
    # source setting and make the same isovalent label substitution there.
    source_text = SOURCE.read_text()
    source_text = source_text.replace("Os", "W").replace("406.44", "400.07")
    OUTPUT_GSAS.write_text(
        "# Derived prototype: COD 1562666 Ca3OsO6 with isovalent Os6+ -> W6+\n"
        + source_text
    )
    uranium_parent = Structure.from_file(SOURCE_U, primitive=False)
    uranium_parent.replace_species({"U": "W"})
    CifWriter(
        uranium_parent, symprec=0.01, refine_struct=False
    ).write_file(OUTPUT_U)
    print(OUTPUT)
    print(OUTPUT_GSAS)
    print(OUTPUT_U)
    print(structure.composition.reduced_formula)
    print(structure.lattice.parameters)


if __name__ == "__main__":
    main()
