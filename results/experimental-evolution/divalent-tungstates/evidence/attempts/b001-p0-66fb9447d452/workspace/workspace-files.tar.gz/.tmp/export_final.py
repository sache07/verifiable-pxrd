from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp" / "final_model.gpx"

project = G2sc.G2Project(str(SOURCE))
project.save(str(ROOT / "final.gpx"))

cif_names = {
    "ZnWO4": "ZnWO4.cif",
    "WO3": "WO3.cif",
    "ZnO": "ZnO.cif",
}
for phase in project.phases():
    phase.export_CIF(str(ROOT / cif_names[phase.name]))

histogram = project.histogram(0)
x = np.asarray(histogram.getdata("X"), dtype=float)
y_obs = np.asarray(histogram.getdata("Yobs"), dtype=float)
y_calc = np.asarray(histogram.getdata("Ycalc"), dtype=float)
difference = np.asarray(histogram.getdata("Residual"), dtype=float)
background = np.asarray(histogram.getdata("Background"), dtype=float)

if not np.allclose(difference, y_obs - y_calc, rtol=0.0, atol=1e-8):
    raise RuntimeError("GSAS-II residual is not observed minus calculated")

np.savetxt(
    ROOT / "fit.csv",
    np.column_stack((x, y_obs, y_calc, difference, background)),
    delimiter=",",
    header=(
        "two_theta_deg,observed_intensity,calculated_intensity,"
        "difference_observed_minus_calculated,background_intensity"
    ),
    comments="",
    fmt=("%.8f", "%.6f", "%.6f", "%.6f", "%.6f"),
)

project.save()
