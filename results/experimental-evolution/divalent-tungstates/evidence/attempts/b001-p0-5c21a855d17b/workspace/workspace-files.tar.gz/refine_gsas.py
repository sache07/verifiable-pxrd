#!/usr/bin/env python3
"""Build and refine the three-phase GSAS-II model for pattern.csv."""

from pathlib import Path
import json
import math

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
RESOURCE = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)
PROJECT = ROOT / "trial.gpx"

PHASE_INPUTS = [
    ("SrWO4", ROOT / "start_srwo4.cif"),
    ("WO3", RESOURCE / "2/31/10/2311041.cif"),
    ("SrCO3", RESOURCE / "9/00/81/9008198.cif"),
]


def show_state(project, label):
    hist = project.histogram(0)
    print(f"\n--- {label} ---")
    print("wR", hist.get_wR())
    print("residuals", hist.data["data"][0])
    inst = hist.data["Instrument Parameters"][0]
    print(
        "instrument",
        {k: inst[k][1] for k in ("Lam1", "Lam2", "Zero", "I(L2)/I(L1)", "U", "V", "W", "X", "Y", "Z", "SH/L")},
    )
    for phase in project.phases():
        print(
            phase.name,
            "cell",
            phase.get_cell(),
            "mass",
            phase.data["General"]["Mass"],
            "scale",
            phase.HAPvalue("Scale"),
            "atoms",
            len(phase.atoms()),
        )
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass fraction calculation failed", repr(exc))


def run_refinement(project, label):
    project.refine(makeBack=False)
    show_state(project, label)


def main():
    project = G2sc.G2Project(newgpx=str(PROJECT))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "cu_kalpha.instprm"),
        fmthint="comma",
    )
    phases = []
    for name, source in PHASE_INPUTS:
        phases.append(
            project.add_phase(
                str(source), phasename=name, histograms=[hist], fmthint="CIF"
            )
        )

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-6

    # With Bragg-Brentano data GSAS-II enables the histogram scale by
    # default. Fix it at unity because the three HAP scale factors already
    # provide the absolute and relative intensity scales.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]

    # The metadata does not provide a calibrated profile. These broad but
    # conservative starting values put calculated and observed peaks in
    # sufficient overlap for the first least-squares cycle.
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {
        "Zero": -0.608,
        "U": 10.0,
        "V": 0.0,
        "W": 30.0,
        "X": 5.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }.items():
        inst[key][0] = value
        inst[key][1] = value

    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
                "coeffs": [1050.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            },
        }
    )

    for phase, start_scale in zip(phases, (1.0, 0.15, 0.15)):
        phase.HAPvalue("Scale", start_scale)
        phase.set_HAP_refinements({"Scale": True})

    project.save()
    show_state(project, "initial")

    run_refinement(project, "background + phase scales")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    run_refinement(project, "add all unit cells")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(project, "add zero")

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    run_refinement(project, "add primary profile terms")

    hist.set_refinements({"Instrument Parameters": ["U", "V", "Y"]})
    run_refinement(project, "add remaining profile terms")

    project.save()


if __name__ == "__main__":
    main()
