#!/usr/bin/env python3
"""Finalize the selected GSAS-II model and write all requested deliverables."""

from pathlib import Path
import csv
import json
import math

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "wo3_po_10m1.gpx"
FINAL = ROOT / "final.gpx"

PHASE_META = {
    "SrWO4": {
        "display_name": "SrWO4 (scheelite)",
        "formula": "SrWO4",
        "space_group": "I 41/a",
        "cif": "SrWO4.cif",
        "systematic_uncertainty": 0.02,
    },
    "WO3": {
        "display_name": "WO3 (monoclinic gamma-WO3)",
        "formula": "WO3",
        "space_group": "P 21/c",
        "cif": "WO3.cif",
        "systematic_uncertainty": 0.015,
    },
    "SrCO3": {
        "display_name": "SrCO3 (strontianite)",
        "formula": "SrCO3",
        "space_group": "Pnma",
        "cif": "SrCO3.cif",
        "systematic_uncertainty": 0.015,
    },
}


def fmt_esd(value, esd, digits=6):
    return f"{value:.{digits}f} (formal s.u. {esd:.{digits}f})"


def main():
    project = G2sc.G2Project(str(BASE), newgpx=str(FINAL))
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-6

    hist = project.histogram(0)
    x = hist.data["data"][1][0]
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]

    # Preserve the selected parsimonious profile model and explicitly clear
    # parameters rejected during model testing.
    inst = hist.data["Instrument Parameters"][0]
    for key in ("Zero", "Polariz.", "W", "X"):
        inst[key][2] = True
    for key in ("Lam1", "Lam2", "I(L2)/I(L1)", "U", "V", "Y", "Z", "SH/L"):
        inst[key][2] = False

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""

    srwo4_po = project.phase("SrWO4").data["Histograms"][hist.name]["Pref.Ori."]
    srwo4_po[0:4] = ["MD", srwo4_po[1], True, [0, 0, 1]]
    wo3_po = project.phase("WO3").data["Histograms"][hist.name]["Pref.Ori."]
    wo3_po[0:4] = ["MD", wo3_po[1], True, [1, 0, -1]]
    srco3_po = project.phase("SrCO3").data["Histograms"][hist.name]["Pref.Ori."]
    srco3_po[1] = 1.0
    srco3_po[2] = False

    project.save()
    project.refine(makeBack=False)
    project.save()

    # Reloading guarantees that exported files and tabulated values all come
    # from exactly the serialized final.gpx project.
    project = G2sc.G2Project(str(FINAL))
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    residuals = hist.data["data"][0]
    covariance = project.data["Covariance"]["data"]

    for phase in project.phases():
        phase.export_CIF(str(ROOT / PHASE_META[phase.name]["cif"]))

    x, yobs, weights, ycalc, background, stored_diff = hist.data["data"][1]
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity_counts",
                "calculated_intensity_counts",
                "difference_observed_minus_calculated_counts",
                "background_intensity_counts",
            ]
        )
        for values in zip(x, yobs, ycalc, background):
            xx, yo, yc, bg = (float(v) for v in values)
            writer.writerow(
                [f"{xx:.8f}", f"{yo:.8f}", f"{yc:.8f}", f"{yo-yc:.8f}", f"{bg:.8f}"]
            )

    rexp = float(residuals["wRmin"])
    rwp = float(residuals["wR"])
    fit_stats = {
        "Rwp_percent": rwp,
        "Rp_percent": float(residuals["R"]),
        "Rexp_percent": rexp,
        "goodness_of_fit_Rwp_over_Rexp": rwp / rexp,
        "reduced_chi_square": (rwp / rexp) ** 2,
        "background_subtracted_Rp_percent": float(residuals["Rb"]),
        "background_subtracted_Rwp_percent": float(residuals["wRb"]),
        "durbin_watson": float(residuals["Durbin-Watson"]),
        "number_of_observations": int(residuals["Nobs"]),
        "number_of_refined_parameters": len(covariance.get("varyList", [])),
        "two_theta_range_deg": [float(x[0]), float(x[-1])],
        "weighting": "Poisson approximation, w = 1/Iobs; pointwise uncertainties were not supplied",
    }

    result_phases = []
    phase_rows = []
    cell_rows = []
    for phase in project.phases():
        meta = PHASE_META[phase.name]
        fraction, fraction_esd = fractions[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        pid = phase.id
        bragg_r = residuals.get(f"{pid}:0:Rf")
        bragg_r2 = residuals.get(f"{pid}:0:Rf^2")
        result_phases.append(
            {
                "name": meta["display_name"],
                "formula": meta["formula"],
                "space_group": meta["space_group"],
                "cif_path": meta["cif"],
                "weight_fraction": float(fraction),
                "weight_fraction_formal_esd": float(fraction_esd),
                "estimated_absolute_systematic_uncertainty": meta["systematic_uncertainty"],
                "Bragg_R_percent": None if bragg_r is None else float(bragg_r),
                "Bragg_R_F2_percent": None if bragg_r2 is None else float(bragg_r2),
                "unit_cell": {key: float(value) for key, value in cell.items()},
                "unit_cell_formal_esd": {
                    key: float(value) for key, value in cell_esd.items()
                },
            }
        )
        phase_rows.append(
            f"| {meta['display_name']} | {meta['space_group']} | {100*fraction:.2f} | "
            f"{100*fraction_esd:.2f} | ±{100*meta['systematic_uncertainty']:.1f} |"
        )
        if phase.name == "SrWO4":
            cell_text = (
                f"a = {cell['length_a']:.6f} Å, c = {cell['length_c']:.6f} Å"
            )
        elif phase.name == "WO3":
            cell_text = (
                f"a = {cell['length_a']:.6f} Å, b = {cell['length_b']:.6f} Å, "
                f"c = {cell['length_c']:.6f} Å, β = {cell['angle_beta']:.5f}°"
            )
        else:
            cell_text = (
                f"a = {cell['length_a']:.6f} Å, b = {cell['length_b']:.6f} Å, "
                f"c = {cell['length_c']:.6f} Å"
            )
        cell_rows.append(f"- {meta['display_name']}: {cell_text}.")

    result = {
        "phases": result_phases,
        "fraction_basis": "normalized over the three modeled crystalline phases; no amorphous fraction determined",
        "fit_statistics": fit_stats,
        "files": {
            "GSASII_project": "final.gpx",
            "profile": "fit.csv",
            "report": "report.md",
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    inst = hist.data["Instrument Parameters"][0]
    report = f"""# PXRD phase analysis

## Result

The crystalline pattern is modeled by three phases:

| Phase | Space group | wt% | formal s.u. (wt%) | estimated model systematic (wt%) |
|---|---:|---:|---:|---:|
{chr(10).join(phase_rows)}

Fractions are normalized only over the modeled crystalline phases. There was no internal standard, so an amorphous fraction cannot be measured.

## Evidence

Scheelite SrWO4 accounts for the dominant line sequence at approximately 17.46, 27.20, 29.44, 32.64, 44.82, 47.13, 55.53, and 56.82° 2θ. Monoclinic WO3 is required by the resolved 22.52/22.94/23.83° triplet and corroborating lines near 33.04–33.60, 41.31, and 49.46°. Orthorhombic SrCO3 (strontianite) is identified independently by the 24.65/25.30° pair and its lines near 36.07 and 43.67°. Together these phases account for the coherent peaks across 9.90–100.09°; no fourth repeatable peak set was found.

This assignment is also chemically consistent with partial conversion of SrCO3 and WO3 to SrWO4 during the reported 650 °C treatment. The rejected chemistry-only candidate Sr3W2O9 predicts strong low-angle lines near 13.2 and 18.9° that are absent.

## Refinement

The final GSAS-II Rietveld fit gives Rwp = {rwp:.3f}%, Rp = {fit_stats['Rp_percent']:.3f}%, Rexp = {rexp:.3f}%, GOF = {fit_stats['goodness_of_fit_Rwp_over_Rexp']:.3f}, and reduced χ² = {fit_stats['reduced_chi_square']:.3f} for {fit_stats['number_of_observations']} observations and {fit_stats['number_of_refined_parameters']} refined parameters. Cu Kα1/Kα2 wavelengths and the reported 0.5 ratio were fixed; the refined zero was {inst['Zero'][1]:.5f}°, and the effective polarization was {inst['Polariz.'][1]:.4f}. An eight-term Chebyshev background, phase scales/cells, physical W/X profile terms, and modest March–Dollase corrections for SrWO4 [001] ({srwo4_po[1]:.3f}) and WO3 [10-1] ({wo3_po[1]:.3f}) were refined.

Refined cells (the WO3 cell is the valid P21/c source setting):

{chr(10).join(cell_rows)}

## Remaining uncertainty

No pointwise uncertainties or calibrated instrument profile were supplied, so count-based Poisson weights were used. The approximately -0.64° refined zero is large; cell metrics and zero therefore have greater systematic uncertainty than their formal covariance s.u.'s. The quoted fraction s.u.'s are statistical only. Alternative reasonable texture/profile choices moved fractions by roughly 1–2 absolute wt%, which is the more realistic uncertainty scale reported above. Trace crystalline material below roughly 1–2 wt% cannot be excluded, and amorphous material is unconstrained.

Atomic coordinates were kept at the reference-model values while lattice parameters were refined. In particular, unconstrained SrWO4 oxygen-coordinate refinement was model-dependent and moved to chemically questionable values, so the powder data do not reliably determine new internal coordinates. The CIFs should therefore be read as reference structural models with refined cells, not as independent full structure determinations.
"""
    (ROOT / "report.md").write_text(report)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
