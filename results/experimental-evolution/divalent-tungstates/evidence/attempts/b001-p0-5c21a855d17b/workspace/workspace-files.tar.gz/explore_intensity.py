#!/usr/bin/env python3
"""Test physically interpretable intensity corrections."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def report(project, label):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    print("\n", label, "Rwp", hist.get_wR())
    print("polarization", inst["Polariz."])
    print("mass fractions", hist.ComputeMassFracs())
    for phase in project.phases():
        print(
            phase.name,
            "PO",
            phase.data["Histograms"][hist.name]["Pref.Ori."],
            "scale",
            phase.HAPvalue("Scale"),
        )


def refine_as(project, name, label):
    project.filename = str(ROOT / name)
    project.save()
    project.refine(makeBack=False)
    project.save()
    report(project, label)


def main():
    project = G2sc.G2Project(
        str(ROOT / "profile_wx.gpx"), newgpx=str(ROOT / "profile_pol.gpx")
    )
    project.data["Controls"]["data"]["max cyc"] = 8
    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine_as(project, "profile_pol.gpx", "refined polarization")

    phase = project.phase("SrWO4")
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = [0, 0, 1]
    refine_as(project, "profile_pol_po.gpx", "polarization + SrWO4 [001] MD")


if __name__ == "__main__":
    main()
