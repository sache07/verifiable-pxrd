#!/usr/bin/env python3
"""Compare simple March-Dollase axes for the SrCO3 impurity."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "wo3_po_10m1.gpx"
AXES = ([1, 1, 1], [1, 0, 2], [1, 0, 0], [0, 1, 0], [0, 0, 1])


def main():
    for axis in AXES:
        tag = "".join(str(v) for v in axis)
        output = ROOT / f"srco3_po_{tag}.gpx"
        project = G2sc.G2Project(str(BASE), newgpx=str(output))
        project.data["Controls"]["data"]["max cyc"] = 6
        hist = project.histogram(0)
        phase = project.phase("SrCO3")
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = list(axis)
        project.save()
        project.refine(makeBack=False)
        project.save()
        print(
            "AXIS",
            axis,
            "Rwp",
            hist.get_wR(),
            "MD",
            po[1],
            "fractions",
            hist.ComputeMassFracs(),
        )


if __name__ == "__main__":
    main()
