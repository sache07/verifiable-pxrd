#!/usr/bin/env python3
"""Compare restrained profile refinements from the completed trial model."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def report(project, label):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    print("\n", label, "Rwp", hist.get_wR())
    print({k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")})
    print(hist.ComputeMassFracs())
    for phase in project.phases():
        print(phase.name, phase.get_cell(), phase.HAPvalue("Scale"))


def refine_and_save(project, filename, label):
    project.save(str(ROOT / filename))
    project.refine(makeBack=False)
    project.save()
    report(project, label)


def main():
    project = G2sc.G2Project(str(ROOT / "trial.gpx"), newgpx=str(ROOT / "profile_wx.gpx"))
    project.data["Controls"]["data"]["max cyc"] = 8
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for key, value, refine in (
        ("U", 10.0, False),
        ("V", 0.0, False),
        ("W", 42.1, True),
        ("X", 2.0, True),
        ("Y", 0.0, False),
        ("SH/L", 0.002, False),
    ):
        inst[key][0] = value
        inst[key][1] = value
        inst[key][2] = refine
    refine_and_save(project, "profile_wx.gpx", "W+X")

    inst["U"][2] = True
    project.filename = str(ROOT / "profile_uwx.gpx")
    refine_and_save(project, "profile_uwx.gpx", "U+W+X")

    inst["SH/L"][2] = True
    project.filename = str(ROOT / "profile_uwx_shl.gpx")
    refine_and_save(project, "profile_uwx_shl.gpx", "U+W+X+SH/L")


if __name__ == "__main__":
    main()
