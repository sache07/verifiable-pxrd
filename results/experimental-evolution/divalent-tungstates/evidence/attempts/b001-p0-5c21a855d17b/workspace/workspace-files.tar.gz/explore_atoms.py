#!/usr/bin/env python3
"""Test the powder-data support for SrWO4 internal coordinates and Uiso."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def report(project, label):
    hist = project.histogram(0)
    phase = project.phase("SrWO4")
    print("\n", label, "Rwp", hist.get_wR(), "fractions", hist.ComputeMassFracs())
    for atom in phase.atoms():
        print(atom.label, atom.coordinates, atom.uiso, atom.refinement_flags)


def refine_as(project, name, label):
    project.filename = str(ROOT / name)
    project.save()
    project.refine(makeBack=False)
    project.save()
    report(project, label)


def main():
    project = G2sc.G2Project(
        str(ROOT / "wo3_po_10m1.gpx"), newgpx=str(ROOT / "atoms_o_xyz.gpx")
    )
    project.data["Controls"]["data"]["max cyc"] = 8
    phase = project.phase("SrWO4")
    phase.atom("O1").refinement_flags = "X"
    refine_as(project, "atoms_o_xyz.gpx", "O coordinates")

    for atom in phase.atoms():
        atom.refinement_flags += "U"
    refine_as(project, "atoms_o_xyz_uiso.gpx", "O coordinates + all SrWO4 Uiso")


if __name__ == "__main__":
    main()
