import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(".tmp/work").resolve()
BASE = WORK / "mature_polarization.gpx"
CIF_ROOT = Path("<RUN>/resources/b001-c05/cif")
CAO_CIF = CIF_ROOT / "1" / "56" / "31" / "1563196.cif"


def angular_bins(h):
    x = np.asarray(h.getdata("X"))
    y = np.asarray(h.getdata("Yobs"))
    d = np.asarray(h.getdata("Residual"))
    rows = []
    for lo in range(10, 100, 10):
        hi = lo + 10
        use = (x >= lo) & (x < hi)
        if not np.any(use):
            continue
        denom = np.sum(y[use] ** 2 / np.maximum(y[use], 1.0))
        numer = np.sum(d[use] ** 2 / np.maximum(y[use], 1.0))
        rows.append({
            "range_deg": [lo, hi],
            "weighted_R_percent": float(100.0 * np.sqrt(numer / denom)),
            "mean_standardized_signed_residual": float(np.mean(d[use] / np.sqrt(np.maximum(y[use], 1.0)))),
        })
    return rows


def summarize(gpx, name, path):
    h = gpx.histogram(0)
    cov = gpx.data.get("Covariance", {}).get("data", {})
    return {
        "name": name,
        "path": str(path),
        "Rwp_percent": float(h.residuals["wR"]),
        "Rp_percent": float(h.residuals["R"]),
        "GOF": float(cov.get("Rvals", {}).get("GOF", 0.0)),
        "max_shift_over_esd": float(cov.get("Rvals", {}).get("Max shft/sig", 0.0)),
        "message": cov.get("Rvals", {}).get("msg", ""),
        "frozen": gpx.get_Frozen(),
        "mass_fractions": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "background": list(h.data["Background"][0]),
        "polarization": list(h.InstrumentParameters["Polariz."][1:3]),
        "roughness": {k: list(h.SampleParameters[k]) for k in ("SurfRoughA", "SurfRoughB")},
        "angular_bins": angular_bins(h),
    }


def run(name, configure):
    out = WORK / f"polarization_{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    gpx.set_Frozen()
    configure(gpx)
    gpx.set_Controls("cycles", 15)
    gpx.save()
    gpx.refine()
    gpx.save()
    replay = G2sc.G2Project(str(out))
    replay.set_Frozen()
    replay.refine()
    replay.save()
    return summarize(replay, name, out)


def identity(gpx):
    pass


def delete_polarization(gpx):
    gpx.histogram(0).InstrumentParameters["Polariz."][1:3] = [0.5, False]


def background_6(gpx):
    h = gpx.histogram(0)
    coeff = list(h.data["Background"][0][3:9])
    h.set_refinements({"Background": {
        "type": "chebyschev-1", "refine": True,
        "no. coeffs": 6, "coeffs": coeff,
    }})


def add_roughness(gpx):
    h = gpx.histogram(0)
    h.SampleParameters["SurfRoughA"][:] = [0.3244, True]
    h.SampleParameters["SurfRoughB"][:] = [0.2052, True]
    gpx.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
    gpx.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
    gpx.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    gpx.set_Controls("parmMax", 1.0, variable=":0:SurfRoughB")


rows = [
    run("control", identity),
    run("delete", delete_polarization),
    run("background_6", background_6),
    run("plus_roughness", add_roughness),
]

# Recheck the CaO trace-phase hypothesis after the accepted angular correction.
out = WORK / "polarization_add_cao_scale.gpx"
gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
gpx.set_Frozen()
h = gpx.histogram(0)
cao = gpx.add_phase(str(CAO_CIF), phasename="CaO_1563196", histograms=[h], fmthint="CIF")
hap = cao.getHAPvalues(h)
hap["Scale"][:] = [0.005, True]
hap["Size"][0] = "isotropic"
hap["Size"][1] = [10.0, 10.0, 1.0]
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1] = [0.0, 0.0, 1.0]
hap["Mustrain"][2] = [False, False, False]
hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
cao.set_refinements({"Cell": False})
gpx.set_Controls("parmMin", 1e-10, variable="3:0:Scale")
gpx.set_Controls("cycles", 15)
gpx.refine()
gpx.save()
replay = G2sc.G2Project(str(out))
replay.set_Frozen()
replay.refine()
replay.save()
row = summarize(replay, "add_cao_scale", out)
cov = replay.data.get("Covariance", {}).get("data", {})
for var, value, esd in zip(cov.get("varyList", []), cov.get("variables", []), cov.get("sig", [])):
    if var == "3:0:Scale":
        row["cao_scale"] = float(value)
        row["cao_scale_esd"] = float(esd)
        row["cao_scale_significance"] = float(value / esd) if esd else None
rows.append(row)

with open(WORK / "polarization_stabilization_summary.json", "w") as stream:
    json.dump(rows, stream, indent=2)

print("POLARIZATION STABILIZATION")
for row in rows:
    print(row["name"], f"Rwp={row['Rwp_percent']:.6f}", f"GOF={row['GOF']:.6f}",
          "frozen=" + str(row["frozen"]),
          "pol=" + str(row["polarization"]),
          "rough=" + str(row["roughness"]),
          "msg=" + str(row["message"]),
          "fractions=" + str({k: round(v[0], 6) for k, v in row["mass_fractions"].items()}),
          "cao_sig=" + str(row.get("cao_scale_significance")))
