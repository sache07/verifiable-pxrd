import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(".tmp/work").resolve()
BASE = WORK / "two_mature.gpx"


def neutralize_profiles(gpx):
    h = gpx.histogram(0)
    for p in gpx.phases():
        hap = p.getHAPvalues(h)
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def neutralize_texture(gpx):
    h = gpx.histogram(0)
    for p in gpx.phases():
        po = p.getHAPvalues(h)["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = False
        po[3] = [0, 0, 1]
        po[4] = 0
        po[5] = {}


def summarize(gpx, branch, extra=None):
    h = gpx.histogram(0)
    row = {
        "branch": branch,
        "residuals": h.residuals,
        "mass_fractions": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "frozen": gpx.get_Frozen(),
        "instrument": {k: h.InstrumentParameters[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "phases": {},
    }
    for p in gpx.phases():
        hap = p.getHAPvalues(h)
        row["phases"][p.name] = {
            "cell": p.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    if extra:
        row.update(extra)
    return row


def refine_branch(branch, setup):
    out = WORK / f"challenge_{branch}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    gpx.set_Frozen()
    neutralize_profiles(gpx)
    neutralize_texture(gpx)
    setup(gpx)
    gpx.set_Controls("cycles", 12)
    gpx.refine()
    # Independent replay with every current value and flag reloaded.
    gpx.save()
    replay = G2sc.G2Project(str(out))
    replay.refine()
    replay.save()
    return summarize(replay, branch)


rows = []

# Neutral replay from the common mature checkpoint.
rows.append(refine_branch("neutral", lambda g: None))

# Per-phase neutral/size/strain/combined comparisons.
for phase_index, phase_tag in [(0, "cawo4"), (1, "wo3")]:
    for mode in ("size", "strain", "combined"):
        def setup(gpx, phase_index=phase_index, mode=mode):
            p = gpx.phase(phase_index)
            h = gpx.histogram(0)
            hap = p.getHAPvalues(h)
            if mode in ("size", "combined"):
                hap["Size"][1][0] = 1.0
                hap["Size"][2][0] = True
            if mode in ("strain", "combined"):
                hap["Mustrain"][1][0] = 100.0
                hap["Mustrain"][2][0] = True
        rows.append(refine_branch(f"width_{phase_tag}_{mode}", setup))

# Compact symmetry-aware March-Dollase basis for each phase.
texture_axes = {
    0: [(0, 0, 1), (1, 0, 0), (1, 1, 1), (1, 1, 2)],
    1: [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 1), (1, 1, 2), (1, 1, -2)],
}
for phase_index, axes in texture_axes.items():
    phase_tag = "cawo4" if phase_index == 0 else "wo3"
    for axis in axes:
        tag = "_".join("m" + str(abs(v)) if v < 0 else str(v) for v in axis)
        def setup(gpx, phase_index=phase_index, axis=axis):
            po = gpx.phase(phase_index).getHAPvalues(gpx.histogram(0))["Pref.Ori."]
            po[0] = "MD"
            po[1] = 1.0
            po[2] = True
            po[3] = list(axis)
        rows.append(refine_branch(f"texture_{phase_tag}_{tag}", setup))

with open(WORK / "challenges_summary.json", "w") as stream:
    json.dump(rows, stream, indent=2)

print("\nCHALLENGE SUMMARY")
for row in rows:
    values = []
    for name, p in row["phases"].items():
        values.append(
            f"{name}:wt={row['mass_fractions'][name][0]:.6f},"
            f"size={p['size'][1][0]:.6g},strain={p['mustrain'][1][0]:.6g},"
            f"MD={p['preferred_orientation'][1]:.6g}@{p['preferred_orientation'][3]}"
        )
    print(row["branch"], f"Rwp={row['residuals']['wR']:.6f}", "frozen=" + str(row["frozen"]), *values)
