from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<RUN>/resources/b001-c05/cif")
WORK = Path(".tmp/work").resolve()


def cif(cod_id: str) -> str:
    return str(ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif")


def report(gpx, label):
    h = gpx.histogram(0)
    print("\nREPORT", label, h.residuals)
    print("INST", {k: h.InstrumentParameters[k] for k in h.InstrumentParameters})
    print("BKG", h.Background[0])
    print("SAMPLE", h.SampleParameters)
    for p in gpx.phases():
        hap = p.getHAPvalues(h)
        print("PHASE", p.name, "scale", hap["Scale"], "cell", p.get_cell())
        print("  size", hap["Size"], "strain", hap["Mustrain"], "PO", hap["Pref.Ori."])
    try:
        print("MASS", h.ComputeMassFracs())
    except Exception as e:
        print("MASS ERROR", repr(e))
    print("FROZEN", gpx.get_Frozen())


out = WORK / "two_basic.gpx"
gpx = G2sc.G2Project(newgpx=str(out))
h = gpx.add_powder_histogram(str(WORK / "pattern.xye"), str(Path("instrument.instprm").resolve()), fmthint="xye")
p1 = gpx.add_phase(cif("7219229"), phasename="CaWO4_scheelite", histograms=[h], fmthint="CIF")
p2 = gpx.add_phase(cif("2311041"), phasename="WO3_monoclinic", histograms=[h], fmthint="CIF")

# Keep all inactive nuisance terms literal.
h.SampleParameters["Scale"][:] = [1.0, False]
for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Absorption", "DisplaceX", "DisplaceY"):
    if key in h.SampleParameters and isinstance(h.SampleParameters[key], list):
        h.SampleParameters[key][0] = 0.0
        h.SampleParameters[key][1] = False
h.InstrumentParameters["Zero"][1] = -0.15
h.set_refinements({"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 8, "coeffs": [2000.0] + [0.0] * 7}})
for p in (p1, p2):
    hap = p.getHAPvalues(h)
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    hap["Scale"][:] = [0.5, True]

gpx.set_Controls("cycles", 12)
for var in (":0:U", ":0:W", ":0:X", "0:0:Scale", "1:0:Scale"):
    gpx.set_Controls("parmMin", 1e-8 if var.endswith("Scale") else 0.0, variable=var)
gpx.save()
report(gpx, "initial")

# Linear terms first.
gpx.refine()
gpx.save(str(WORK / "two_step1.gpx"))
report(gpx, "background_scales")

# One common angular correction.
h = gpx.histogram(0)
h.set_refinements({"Instrument Parameters": ["Zero"]})
gpx.refine()
gpx.save(str(WORK / "two_step2.gpx"))
report(gpx, "zero")

# Cells, then the low-dimensional common profile.
for p in gpx.phases():
    p.set_refinements({"Cell": True})
gpx.refine()
gpx.save(str(WORK / "two_step3.gpx"))
report(gpx, "cells")

h = gpx.histogram(0)
h.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
gpx.refine()
gpx.save(str(WORK / "two_step4.gpx"))
report(gpx, "profile")

# Reopen all mature terms once.
gpx.refine()
gpx.save(str(WORK / "two_mature.gpx"))
report(gpx, "mature_replay")
