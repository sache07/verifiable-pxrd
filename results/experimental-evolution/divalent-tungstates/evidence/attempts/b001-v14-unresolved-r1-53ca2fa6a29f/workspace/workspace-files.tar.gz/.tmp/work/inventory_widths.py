import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(".tmp/work").resolve()
BASE = Path("final.gpx").resolve()


def set_target_profile(gpx, phase_index, mode):
    h = gpx.histogram(0)
    hap = gpx.phase(phase_index).getHAPvalues(h)
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    if mode in ("size", "combined"):
        hap["Size"][1][0] = 0.1 if phase_index == 0 else 1.0
        hap["Size"][2][0] = True
        gpx.set_Controls("parmMin", 0.005, variable=f"{phase_index}:0:Size;i")
        gpx.set_Controls("parmMax", 10000.0, variable=f"{phase_index}:0:Size;i")
    if mode in ("strain", "combined"):
        hap["Mustrain"][1][0] = 100.0
        hap["Mustrain"][2][0] = True
        gpx.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;i")
        gpx.set_Controls("parmMax", 10000.0, variable=f"{phase_index}:0:Mustrain;i")


def run(phase_index, phase_tag, mode):
    name = f"inv_width_{phase_tag}_{mode}"
    out = WORK / f"{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    gpx.set_Frozen()
    set_target_profile(gpx, phase_index, mode)
    # Reopen retained common terms at the mature checkpoint.
    h = gpx.histogram(0)
    h.InstrumentParameters["U"][2] = True
    h.InstrumentParameters["W"][2] = True
    h.InstrumentParameters["X"][1:3] = [0.0, False]
    gpx.set_Controls("cycles", 15)
    gpx.refine()
    gpx.save()
    replay = G2sc.G2Project(str(out))
    replay.refine()
    replay.save()
    h = replay.histogram(0)
    return {
        "name": name,
        "path": str(out),
        "r": h.residuals,
        "mass": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "frozen": replay.get_Frozen(),
        "inst": {k: h.InstrumentParameters[k][1] for k in ("U", "W", "X")},
        "profiles": {p.name: {"size": p.getHAPvalues(h)["Size"], "strain": p.getHAPvalues(h)["Mustrain"]}
                     for p in replay.phases()},
    }


rows = []
for index, tag in ((0, "cawo4"), (1, "wo3"), (2, "ca3wo6")):
    for mode in ("neutral", "size", "strain", "combined"):
        rows.append(run(index, tag, mode))

with open(WORK / "inventory_widths_summary.json", "w") as stream:
    json.dump(rows, stream, indent=2)
print("\nINVENTORY WIDTH SUMMARY")
for r in rows:
    target = r["name"].split("_")[2]
    p = next(v for k, v in r["profiles"].items() if target in k.lower().replace("3", "3") or
             (target == "cawo4" and "cawo4" in k.lower()) or (target == "wo3" and k.lower().startswith("wo3")))
    print(r["name"], f"Rwp={r['r']['wR']:.6f}", "frozen=" + str(r["frozen"]),
          f"size={p['size'][1][0]:.7g}", f"strain={p['strain'][1][0]:.7g}",
          "inst=" + str({k: round(v, 5) for k, v in r["inst"].items()}),
          "mass=" + str({k: round(v[0], 5) for k, v in r["mass"].items()}))
