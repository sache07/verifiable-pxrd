import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(".tmp/work").resolve()
ROOT = Path("<RUN>/resources/b001-c05/cif")


def cif(cod_id):
    return str(ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif")


def literal_terms(gpx):
    h = gpx.histogram(0)
    h.SampleParameters["Scale"][:] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Absorption", "DisplaceX", "DisplaceY"):
        if key in h.SampleParameters and isinstance(h.SampleParameters[key], list):
            h.SampleParameters[key][0:2] = [0.0, False]
    h.InstrumentParameters["Zero"][1] = -0.15
    h.set_refinements({"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 8, "coeffs": [2000.0] + [0.0] * 7}})
    for p in gpx.phases():
        hap = p.getHAPvalues(h)
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
        hap["Scale"][:] = [0.5, True]


def build(tag, ca_id, w_id):
    out = WORK / f"source_{tag}_neutral.gpx"
    gpx = G2sc.G2Project(newgpx=str(out))
    h = gpx.add_powder_histogram(str(WORK / "pattern.xye"), str(Path("instrument.instprm").resolve()), fmthint="xye")
    gpx.add_phase(cif(ca_id), phasename=f"CaWO4_{ca_id}", histograms=[h], fmthint="CIF")
    gpx.add_phase(cif(w_id), phasename=f"WO3_{w_id}", histograms=[h], fmthint="CIF")
    literal_terms(gpx)
    gpx.set_Controls("cycles", 15)
    for var in (":0:U", ":0:W", ":0:X", "0:0:Scale", "1:0:Scale"):
        gpx.set_Controls("parmMin", 1e-8 if var.endswith("Scale") else 0.0, variable=var)
    gpx.save()
    # Linear, angular, cell and common profile stages.
    gpx.refine()
    h = gpx.histogram(0)
    h.set_refinements({"Instrument Parameters": ["Zero"]})
    gpx.refine()
    for p in gpx.phases():
        p.set_refinements({"Cell": True})
    gpx.refine()
    h.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    gpx.refine()
    gpx.save()
    replay = G2sc.G2Project(str(out))
    replay.refine()
    replay.save()
    h = replay.histogram(0)
    return {
        "tag": tag,
        "path": str(out),
        "ca_source": ca_id,
        "wo3_source": w_id,
        "residuals": h.residuals,
        "mass": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "frozen": replay.get_Frozen(),
        "inst": {k: h.InstrumentParameters[k][1] for k in ("Zero", "U", "W", "X")},
        "cells": {p.name: p.get_cell() for p in replay.phases()},
    }


pairs = [
    ("control", "7219229", "2311041"),
    ("wo3_triclinic", "7219229", "2106293"),
    ("wo3_orthorhombic", "7219229", "2107312"),
    ("wo3_small_monoclinic", "7219229", "1563541"),
    ("wo3_standard_monoclinic_review", "7219229", "1528915"),
    ("cawo4_fergusonite", "1546035", "2311041"),
]
rows = [build(*pair) for pair in pairs]
with open(WORK / "source_neutral_summary.json", "w") as stream:
    json.dump(rows, stream, indent=2)
print("\nSOURCE NEUTRAL SUMMARY")
for r in rows:
    print(r["tag"], f"Rwp={r['residuals']['wR']:.6f}", "frozen=" + str(r["frozen"]),
          "mass=" + str({k: round(v[0], 5) for k, v in r["mass"].items()}), "cells=" + str(r["cells"]))
