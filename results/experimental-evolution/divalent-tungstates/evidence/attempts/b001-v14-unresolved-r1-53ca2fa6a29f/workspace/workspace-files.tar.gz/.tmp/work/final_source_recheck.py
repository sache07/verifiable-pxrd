import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(".tmp/work").resolve()
REFERENCE = G2sc.G2Project(str(WORK / "final_prune_control.gpx"))
RH = REFERENCE.histogram(0)
SOURCE_AXES = {"2311041": (1, 1, -2), "2106293": (1, 1, 1)}


def run(source_id):
    base = WORK / f"source_{source_id}_crossseed_compact.gpx"
    out = WORK / f"final_source_{source_id}_polarized_compact.gpx"
    gpx = G2sc.G2Project(str(base), newgpx=str(out))
    gpx.set_Frozen()
    h = gpx.histogram(0)

    # Cross-seed all shared nuisance terms from the accepted polarized model.
    ref_bkg = list(RH.data["Background"][0][3:])
    h.set_refinements({"Background": {
        "type": "chebyschev-1", "refine": True,
        "no. coeffs": len(ref_bkg), "coeffs": ref_bkg,
    }})
    for key in ("Zero", "U", "W", "Polariz."):
        h.InstrumentParameters[key][1:3] = [float(RH.InstrumentParameters[key][1]), True]
    for key in ("V", "X", "Y", "Z"):
        h.InstrumentParameters[key][1:3] = [0.0, False]
    h.InstrumentParameters["SH/L"][1:3] = [0.002, False]
    for key in ("SurfRoughA", "SurfRoughB"):
        h.SampleParameters[key][0:2] = [0.0, False]

    # Identical phase-profile opportunity; only the WO3 topology differs.
    for i, seed in enumerate((0.075203, 0.463887, 0.187042)):
        hap = gpx.phase(i).getHAPvalues(h)
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [seed, seed, 1.0]
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        gpx.set_Controls("parmMin", 0.005, variable=f"{i}:0:Size;i")
        gpx.set_Controls("parmMax", 10000.0, variable=f"{i}:0:Size;i")

    for i, axis, seed in (
        (0, (1, 1, 0), 1.26386),
        (1, SOURCE_AXES[source_id], 1.0),
        (2, (0, 0, 1), 1.0),
    ):
        po = gpx.phase(i).getHAPvalues(h)["Pref.Ori."]
        po[0:4] = ["MD", seed, True, list(axis)]
        gpx.set_Controls("parmMin", 0.2, variable=f"{i}:0:MD")
        gpx.set_Controls("parmMax", 5.0, variable=f"{i}:0:MD")

    # The CaWO4 and Ca3WO6 structures are identical across the source test.
    for i in (0, 2):
        gpx.phase(i).data["General"]["Cell"] = list(REFERENCE.phase(i).data["General"]["Cell"])

    for var in (":0:U", ":0:W"):
        gpx.set_Controls("parmMin", 0.0, variable=var)
    gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    gpx.set_Controls("cycles", 15)
    gpx.save()
    gpx.refine()
    gpx.save()
    replay = G2sc.G2Project(str(out))
    replay.set_Frozen()
    replay.refine()
    replay.save()

    hh = replay.histogram(0)
    return {
        "source_id": source_id,
        "path": str(out),
        "Rwp_percent": float(hh.residuals["wR"]),
        "Rp_percent": float(hh.residuals["R"]),
        "frozen": replay.get_Frozen(),
        "mass_fractions": {k: list(v) for k, v in hh.ComputeMassFracs().items()},
        "texture": {p.name: p.getHAPvalues(hh)["Pref.Ori."][:4] for p in replay.phases()},
        "instrument": {k: list(hh.InstrumentParameters[k][1:3]) for k in ("U", "W", "X", "Polariz.")},
    }


rows = [run(source_id) for source_id in SOURCE_AXES]
with open(WORK / "final_source_recheck_summary.json", "w") as stream:
    json.dump(rows, stream, indent=2)

print("FINAL SOURCE RECHECK")
for row in rows:
    print(row["source_id"], f"Rwp={row['Rwp_percent']:.6f}",
          "frozen=" + str(row["frozen"]),
          "polarization=" + str(row["instrument"]["Polariz."][0]),
          "texture=" + str({k: (round(v[1], 6), v[3]) for k, v in row["texture"].items()}),
          "fractions=" + str({k: round(v[0], 6) for k, v in row["mass_fractions"].items()}))
