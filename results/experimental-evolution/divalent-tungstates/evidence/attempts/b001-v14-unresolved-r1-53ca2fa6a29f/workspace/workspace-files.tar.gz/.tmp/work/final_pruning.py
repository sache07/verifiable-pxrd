import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(".tmp/work").resolve()
BASE = WORK / "polarization_control.gpx"


def summarize(gpx, name, path):
    h = gpx.histogram(0)
    return {
        "name": name,
        "path": str(path),
        "Rwp_percent": float(h.residuals["wR"]),
        "Rp_percent": float(h.residuals["R"]),
        "frozen": gpx.get_Frozen(),
        "mass_fractions": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "sizes_um": {p.name: list(p.getHAPvalues(h)["Size"][1]) for p in gpx.phases()},
        "size_flags": {p.name: list(p.getHAPvalues(h)["Size"][2]) for p in gpx.phases()},
        "texture": {p.name: list(p.getHAPvalues(h)["Pref.Ori."][:4]) for p in gpx.phases()},
        "polarization": list(h.InstrumentParameters["Polariz."][1:3]),
        "instrument": {k: list(h.InstrumentParameters[k][1:3]) for k in ("U", "W", "X")},
    }


def configure_minor_texture(gpx, delete_wo3, delete_ca3):
    h = gpx.histogram(0)
    if delete_wo3:
        gpx.phase(1).getHAPvalues(h)["Pref.Ori."][1:3] = [1.0, False]
    if delete_ca3:
        gpx.phase(2).getHAPvalues(h)["Pref.Ori."][1:3] = [1.0, False]


def run_from(base, name, configure):
    out = WORK / f"final_prune_{name}.gpx"
    gpx = G2sc.G2Project(str(base), newgpx=str(out))
    gpx.set_Frozen()
    configure(gpx)
    gpx.set_Controls("cycles", 15)
    gpx.save()
    gpx.refine()
    gpx.save()
    replay = G2sc.G2Project(str(out))
    replay.set_Frozen()
    replay.refine()
    replay.save()
    return summarize(replay, name, out), out


rows = []
for name, dw, dc in (
    ("delete_wo3_texture", True, False),
    ("delete_ca3_texture", False, True),
    ("delete_both_minor_textures", True, True),
):
    row, path = run_from(BASE, name, lambda g, dw=dw, dc=dc: configure_minor_texture(g, dw, dc))
    rows.append(row)
    if name == "delete_both_minor_textures":
        PRUNED_BASE = path


def identity(gpx):
    pass


def delete_texture(index):
    def configure(gpx):
        po = gpx.phase(index).getHAPvalues(gpx.histogram(0))["Pref.Ori."]
        po[1:3] = [1.0, False]
    return configure


def delete_size(index):
    def configure(gpx):
        size = gpx.phase(index).getHAPvalues(gpx.histogram(0))["Size"]
        size[0] = "isotropic"
        size[1] = [10.0, 10.0, 1.0]
        size[2] = [False, False, False]
        if len(size) > 5:
            size[5] = [False] * len(size[5])
    return configure


row, FINAL_PRUNED = run_from(PRUNED_BASE, "control", identity)
rows.append(row)
row, _ = run_from(FINAL_PRUNED, "delete_cawo4_texture", delete_texture(0))
rows.append(row)
for index, tag in enumerate(("cawo4", "wo3", "ca3wo6")):
    row, _ = run_from(FINAL_PRUNED, f"delete_{tag}_size", delete_size(index))
    rows.append(row)

with open(WORK / "final_pruning_summary.json", "w") as stream:
    json.dump(rows, stream, indent=2)

print("FINAL PRUNING")
for row in rows:
    print(row["name"], f"Rwp={row['Rwp_percent']:.6f}",
          "frozen=" + str(row["frozen"]),
          "texture=" + str({k: (round(v[1], 7), v[2], v[3]) for k, v in row["texture"].items()}),
          "sizes=" + str({k: (round(v[0], 7), row["size_flags"][k][0]) for k, v in row["sizes_um"].items()}),
          "fractions=" + str({k: round(v[0], 7) for k, v in row["mass_fractions"].items()}))
