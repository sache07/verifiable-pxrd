import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(".tmp/work").resolve()
REFERENCE = G2sc.G2Project(str(WORK / "joint_texture_both.gpx"))
REF_HIST = REFERENCE.histogram(0)

# Each source gets the same mature common nuisance values. U is held at the
# shared cross-seed while W is reopened, so the earlier U=0 bound cannot decide
# the structural comparison.
SHARED_U = float(REF_HIST.InstrumentParameters["U"][1])
SHARED_W = float(REF_HIST.InstrumentParameters["W"][1])
SHARED_ZERO = float(REF_HIST.InstrumentParameters["Zero"][1])
SHARED_BACKGROUND = list(REF_HIST.data["Background"][0][3:])

SOURCE_AXES = {
    "2311041": (1, 1, -2),
    "1528915": (0, 1, 0),
    "2106293": (1, 1, 1),
}


def set_size(gpx, index, seed):
    h = gpx.histogram(0)
    size = gpx.phase(index).getHAPvalues(h)["Size"]
    size[0] = "isotropic"
    size[1] = [float(seed), float(seed), 1.0]
    size[2] = [True, False, False]
    if len(size) > 5:
        size[5] = [False] * len(size[5])
    gpx.set_Controls("parmMin", 0.005, variable=f"{index}:0:Size;i")
    gpx.set_Controls("parmMax", 10000.0, variable=f"{index}:0:Size;i")


def set_po(gpx, index, axis, seed):
    h = gpx.histogram(0)
    po = gpx.phase(index).getHAPvalues(h)["Pref.Ori."]
    po[0:3] = ["MD", float(seed), True]
    po[3] = list(axis)
    gpx.set_Controls("parmMin", 0.2, variable=f"{index}:0:MD")
    gpx.set_Controls("parmMax", 5.0, variable=f"{index}:0:MD")


def run(source_id):
    base = WORK / f"inventory_source_{source_id}_neutral.gpx"
    out = WORK / f"source_{source_id}_crossseed_compact.gpx"
    gpx = G2sc.G2Project(str(base), newgpx=str(out))
    gpx.set_Frozen()
    h = gpx.histogram(0)

    # Same smooth background and one angular correction for every source.
    h.set_refinements({"Background": {
        "type": "chebyschev-1", "refine": True,
        "no. coeffs": len(SHARED_BACKGROUND), "coeffs": SHARED_BACKGROUND,
    }})
    h.InstrumentParameters["Zero"][1:3] = [SHARED_ZERO, True]
    h.InstrumentParameters["U"][1:3] = [SHARED_U, False]
    h.InstrumentParameters["W"][1:3] = [SHARED_W, True]
    h.InstrumentParameters["X"][1:3] = [0.0, False]
    for key in ("V", "Y", "Z"):
        h.InstrumentParameters[key][1:3] = [0.0, False]
    h.InstrumentParameters["SH/L"][1:3] = [0.002, False]
    h.InstrumentParameters["Polariz."][1:3] = [0.5, False]
    for key in ("SurfRoughA", "SurfRoughB"):
        h.SampleParameters[key][0:2] = [0.0, False]

    # Identical profile opportunity and compact texture basis leaders.
    for i, seed in enumerate((0.07891845, 0.5334514, 0.2156676)):
        set_size(gpx, i, seed)
        strain = gpx.phase(i).getHAPvalues(h)["Mustrain"]
        strain[0] = "isotropic"
        strain[1] = [0.0, 0.0, 1.0]
        strain[2] = [False, False, False]
        if len(strain) > 5:
            strain[5] = [False] * len(strain[5])
    set_po(gpx, 0, (1, 1, 0), 1.29195)
    set_po(gpx, 1, SOURCE_AXES[source_id], 1.0)
    set_po(gpx, 2, (0, 0, 1), 1.05062)

    gpx.set_Controls("parmMin", 0.0, variable=":0:W")
    gpx.set_Controls("cycles", 15)
    gpx.save()
    gpx.refine()
    gpx.save()
    replay = G2sc.G2Project(str(out))
    replay.set_Frozen()
    replay.refine()
    replay.save()

    hh = replay.histogram(0)
    return {
        "source_id": source_id,
        "path": str(out),
        "Rwp_percent": float(hh.residuals["wR"]),
        "Rp_percent": float(hh.residuals["R"]),
        "frozen": replay.get_Frozen(),
        "instrument": {k: list(hh.InstrumentParameters[k][1:3]) for k in ("U", "W", "X")},
        "mass_fractions": {k: list(v) for k, v in hh.ComputeMassFracs().items()},
        "texture": {p.name: p.getHAPvalues(hh)["Pref.Ori."] for p in replay.phases()},
        "sizes_um": {p.name: p.getHAPvalues(hh)["Size"][1][0] for p in replay.phases()},
    }


rows = [run(source_id) for source_id in SOURCE_AXES]
with open(WORK / "source_crossseed_summary.json", "w") as stream:
    json.dump(rows, stream, indent=2)

print("SOURCE CROSS-SEED COMPACT COMPARISON")
for row in rows:
    print(row["source_id"], f"Rwp={row['Rwp_percent']:.6f}",
          "frozen=" + str(row["frozen"]),
          "W=" + str(round(row["instrument"]["W"][0], 6)),
          "fractions=" + str({k: round(v[0], 6) for k, v in row["mass_fractions"].items()}))
