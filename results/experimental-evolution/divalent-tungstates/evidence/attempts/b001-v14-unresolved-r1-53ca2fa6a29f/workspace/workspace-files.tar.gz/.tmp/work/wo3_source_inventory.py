import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(".tmp/work").resolve()
ROOT = Path("<RUN>/resources/b001-c05/cif")
ANALOGUE = Path("candidate_Ca3WO6_P21c_from_Ca3OsO6.cif").resolve()


def cif(cod_id):
    return str(ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif")


def literal_phase(phase, hist, scale=0.5):
    hap = phase.getHAPvalues(hist)
    hap["Scale"][:] = [scale, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]


def build_neutral(cod_id):
    out = WORK / f"inventory_source_{cod_id}_neutral.gpx"
    gpx = G2sc.G2Project(newgpx=str(out))
    h = gpx.add_powder_histogram(str(WORK / "pattern.xye"), str(Path("instrument.instprm").resolve()), fmthint="xye")
    phases = [
        gpx.add_phase(cif("7219229"), phasename="CaWO4_scheelite", histograms=[h], fmthint="CIF"),
        gpx.add_phase(cif(cod_id), phasename=f"WO3_{cod_id}", histograms=[h], fmthint="CIF"),
        gpx.add_phase(str(ANALOGUE), phasename="Ca3WO6_P21c", histograms=[h], fmthint="CIF"),
    ]
    h.SampleParameters["Scale"][:] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Absorption", "DisplaceX", "DisplaceY"):
        if key in h.SampleParameters and isinstance(h.SampleParameters[key], list):
            h.SampleParameters[key][0:2] = [0.0, False]
    h.InstrumentParameters["Zero"][1] = -0.2
    h.InstrumentParameters["X"][1:3] = [0.0, False]
    h.set_refinements({"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 8,
                                       "coeffs": [1450.0, -700.0, 500.0, -400.0, 230.0, -95.0, 45.0, -3.0]}})
    for p in phases:
        literal_phase(p, h)
    gpx.set_Controls("cycles", 15)
    for i in range(3):
        gpx.set_Controls("parmMin", 1e-10, variable=f"{i}:0:Scale")
    for var in (":0:U", ":0:W"):
        gpx.set_Controls("parmMin", 0.0, variable=var)
    gpx.save()
    gpx.refine()  # scales/background, with every cell fixed
    h.set_refinements({"Instrument Parameters": ["Zero"]})
    gpx.refine()
    for p in gpx.phases():
        p.set_refinements({"Cell": True})
    gpx.refine()
    h.set_refinements({"Instrument Parameters": ["U", "W"]})
    gpx.refine()
    gpx.save()
    replay = G2sc.G2Project(str(out))
    replay.refine()
    replay.save()
    return out, replay


def summarize(gpx, name, path):
    h = gpx.histogram(0)
    return {
        "name": name,
        "path": str(path),
        "r": h.residuals,
        "mass": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "frozen": gpx.get_Frozen(),
        "inst": {k: h.InstrumentParameters[k][1] for k in ("U", "W", "X")},
        "cells": {p.name: p.get_cell() for p in gpx.phases()},
        "po": {p.name: p.getHAPvalues(h)["Pref.Ori."] for p in gpx.phases()},
    }


def elaborate(base, cod_id, axis):
    tag = "_".join("m" + str(abs(v)) if v < 0 else str(v) for v in axis)
    name = f"source_{cod_id}_elab_{tag}"
    out = WORK / f"{name}.gpx"
    gpx = G2sc.G2Project(str(base), newgpx=str(out))
    gpx.set_Frozen()
    h = gpx.histogram(0)
    # Same retained profile/texture opportunity for CaWO4 and Ca3WO6.
    for i, seed in ((0, 0.079), (1, 0.53), (2, 0.225)):
        size = gpx.phase(i).getHAPvalues(h)["Size"]
        size[0] = "isotropic"
        size[1] = [seed, seed, 1.0]
        size[2] = [True, False, False]
        gpx.set_Controls("parmMin", 0.005, variable=f"{i}:0:Size;i")
        gpx.set_Controls("parmMax", 10000.0, variable=f"{i}:0:Size;i")
    for i, ax in ((0, (1, 1, 0)), (1, axis), (2, (0, 0, 1))):
        po = gpx.phase(i).getHAPvalues(h)["Pref.Ori."]
        po[0:3] = ["MD", 1.0, True]
        po[3] = list(ax)
        gpx.set_Controls("parmMin", 0.2, variable=f"{i}:0:MD")
        gpx.set_Controls("parmMax", 5.0, variable=f"{i}:0:MD")
    h.InstrumentParameters["U"][2] = True
    h.InstrumentParameters["W"][2] = True
    h.InstrumentParameters["X"][1:3] = [0.0, False]
    gpx.set_Controls("cycles", 15)
    gpx.refine()
    gpx.save()
    replay = G2sc.G2Project(str(out))
    replay.refine()
    replay.save()
    return summarize(replay, name, out)


sources = ["2311041", "1528915", "2106293"]
compact = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 1), (1, 1, 2), (1, 1, -2)]
rows = []
bases = {}
for source_id in sources:
    path, model = build_neutral(source_id)
    bases[source_id] = path
    rows.append(summarize(model, f"source_{source_id}_neutral", path))
for source_id in sources:
    for axis in compact:
        rows.append(elaborate(bases[source_id], source_id, axis))

with open(WORK / "wo3_source_inventory_summary.json", "w") as stream:
    json.dump(rows, stream, indent=2)
print("\nWO3 SOURCE INVENTORY SUMMARY")
for r in rows:
    active = {k: (round(v[1], 5), v[3]) for k, v in r["po"].items() if v[2]}
    print(r["name"], f"Rwp={r['r']['wR']:.6f}", "frozen=" + str(r["frozen"]),
          "active=" + str(active), "mass=" + str({k: round(v[0], 5) for k, v in r["mass"].items()}))
