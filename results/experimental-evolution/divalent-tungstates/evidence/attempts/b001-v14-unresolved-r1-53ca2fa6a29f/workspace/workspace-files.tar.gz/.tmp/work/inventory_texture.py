import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(".tmp/work").resolve()
BASE = WORK / "collective_all_sizes.gpx"


axes = {
    0: [(0, 0, 1), (1, 0, 0), (1, 1, 1), (1, 1, 2), (1, 1, 0)],
    1: [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 1), (1, 1, 2), (1, 1, -2)],
    2: [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 1), (1, 1, 2), (1, 1, -2)],
}
tags = {0: "cawo4", 1: "wo3", 2: "ca3wo6"}


def neutralize(gpx, phase_index):
    po = gpx.phase(phase_index).getHAPvalues(gpx.histogram(0))["Pref.Ori."]
    po[0:3] = ["MD", 1.0, False]
    po[3] = [0, 0, 1]
    po[4] = 0
    po[5] = {}


def run(phase_index, axis=None):
    axis_tag = "neutral" if axis is None else "_".join("m" + str(abs(v)) if v < 0 else str(v) for v in axis)
    name = f"texture3_{tags[phase_index]}_{axis_tag}"
    out = WORK / f"{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    gpx.set_Frozen()
    neutralize(gpx, phase_index)
    if axis is not None:
        po = gpx.phase(phase_index).getHAPvalues(gpx.histogram(0))["Pref.Ori."]
        po[0:3] = ["MD", 1.0, True]
        po[3] = list(axis)
        gpx.set_Controls("parmMin", 0.2, variable=f"{phase_index}:0:MD")
        gpx.set_Controls("parmMax", 5.0, variable=f"{phase_index}:0:MD")
    gpx.set_Controls("cycles", 15)
    gpx.refine()
    gpx.save()
    replay = G2sc.G2Project(str(out))
    replay.refine()
    replay.save()
    h = replay.histogram(0)
    return {
        "name": name,
        "path": str(out),
        "r": h.residuals,
        "mass": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "frozen": replay.get_Frozen(),
        "po": {p.name: p.getHAPvalues(h)["Pref.Ori."] for p in replay.phases()},
        "sizes": {p.name: p.getHAPvalues(h)["Size"][1][0] for p in replay.phases()},
    }


rows = []
for i in range(3):
    rows.append(run(i, None))
    for axis in axes[i]:
        rows.append(run(i, axis))

with open(WORK / "inventory_texture_summary.json", "w") as stream:
    json.dump(rows, stream, indent=2)
print("\nINVENTORY TEXTURE SUMMARY")
for r in rows:
    active = {k: (round(v[1], 6), v[3]) for k, v in r["po"].items() if v[2]}
    print(r["name"], f"Rwp={r['r']['wR']:.6f}", "frozen=" + str(r["frozen"]),
          "active=" + str(active), "mass=" + str({k: round(v[0], 6) for k, v in r["mass"].items()}))
