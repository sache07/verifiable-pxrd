import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(".tmp/work").resolve()
BASE = Path("final.gpx").resolve()
seeds = [0.08365, 0.966, 0.290]


def configure(gpx, delete=None):
    h = gpx.histogram(0)
    for i, seed in enumerate(seeds):
        size = gpx.phase(i).getHAPvalues(h)["Size"]
        size[0] = "isotropic"
        size[1] = [seed, seed, 1.0]
        size[2] = [True, False, False]
        size[5] = [False] * len(size[5])
        strain = gpx.phase(i).getHAPvalues(h)["Mustrain"]
        strain[0] = "isotropic"
        strain[1] = [0.0, 0.0, 1.0]
        strain[2] = [False, False, False]
        gpx.set_Controls("parmMin", 0.005, variable=f"{i}:0:Size;i")
        gpx.set_Controls("parmMax", 10000.0, variable=f"{i}:0:Size;i")
    if delete is not None:
        size = gpx.phase(delete).getHAPvalues(h)["Size"]
        size[1] = [10.0, 10.0, 1.0]
        size[2] = [False, False, False]
    h.InstrumentParameters["U"][2] = True
    h.InstrumentParameters["W"][2] = True
    h.InstrumentParameters["X"][1:3] = [0.0, False]


def run(name, delete=None):
    out = WORK / f"collective_{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    gpx.set_Frozen()
    configure(gpx, delete)
    gpx.set_Controls("cycles", 15)
    gpx.refine()
    gpx.save()
    replay = G2sc.G2Project(str(out))
    replay.refine()
    replay.save()
    h = replay.histogram(0)
    return {
        "name": name,
        "path": str(out),
        "r": h.residuals,
        "mass": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "frozen": replay.get_Frozen(),
        "inst": {k: h.InstrumentParameters[k][1] for k in ("U", "W", "X")},
        "sizes": {p.name: p.getHAPvalues(h)["Size"] for p in replay.phases()},
    }


rows = [run("all_sizes")]
for i, tag in ((0, "delete_cawo4"), (1, "delete_wo3"), (2, "delete_ca3wo6")):
    rows.append(run(tag, i))
with open(WORK / "collective_widths_summary.json", "w") as stream:
    json.dump(rows, stream, indent=2)
print("\nCOLLECTIVE WIDTH SUMMARY")
for r in rows:
    print(r["name"], f"Rwp={r['r']['wR']:.6f}", "frozen=" + str(r["frozen"]),
          "sizes=" + str({k: round(v[1][0], 6) for k, v in r["sizes"].items()}),
          "mass=" + str({k: round(v[0], 6) for k, v in r["mass"].items()}),
          "inst=" + str({k: round(v, 5) for k, v in r["inst"].items()}))
