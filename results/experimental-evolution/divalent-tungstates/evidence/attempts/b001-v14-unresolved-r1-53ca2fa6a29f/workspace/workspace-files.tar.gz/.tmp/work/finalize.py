import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
WORK = ROOT / ".tmp" / "work"
SOURCE = WORK / "final_prune_control.gpx"
FINAL = ROOT / "final.gpx"


def enforce_final_schema(gpx):
    h = gpx.histogram(0)
    x = h.getdata("X")
    h.data["Limits"][1] = [float(x[0]), float(x[-1])]

    # Exactly one angular correction and a low-dimensional nonnegative common
    # profile. All unused terms are literal neutral values.
    h.InstrumentParameters["Zero"][2] = True
    for key in ("V", "X", "Y", "Z"):
        h.InstrumentParameters[key][1:3] = [0.0, False]
    for key in ("U", "W"):
        h.InstrumentParameters[key][2] = True
        gpx.set_Controls("parmMin", 0.0, variable=f":0:{key}")
    h.InstrumentParameters["SH/L"][1:3] = [0.002, False]
    h.InstrumentParameters["Polariz."][2] = True
    gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")

    h.SampleParameters["Scale"][:] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Absorption", "DisplaceX", "DisplaceY"):
        if key in h.SampleParameters and isinstance(h.SampleParameters[key], list):
            h.SampleParameters[key][0:2] = [0.0, False]

    # Retained phase sizes and CaWO4 texture are active. Unsupported strain and
    # minor-phase texture terms are exactly neutral.
    for i, phase in enumerate(gpx.phases()):
        hap = phase.getHAPvalues(h)
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [True, False, False]
        if len(hap["Size"]) > 5:
            hap["Size"][5] = [False] * len(hap["Size"][5])
        gpx.set_Controls("parmMin", 0.005, variable=f"{i}:0:Size;i")
        gpx.set_Controls("parmMax", 10000.0, variable=f"{i}:0:Size;i")
        if i == 0:
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [1, 1, 0]
            gpx.set_Controls("parmMin", 0.2, variable="0:0:MD")
            gpx.set_Controls("parmMax", 5.0, variable="0:0:MD")
        else:
            hap["Pref.Ori."][0:3] = ["MD", 1.0, False]


# Save under the requested name, reopen, and replay the complete measured range.
gpx = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
gpx.set_Frozen()
enforce_final_schema(gpx)
gpx.set_Controls("cycles", 15)
gpx.save()

gpx = G2sc.G2Project(str(FINAL))
gpx.set_Frozen()
enforce_final_schema(gpx)
gpx.refine()
gpx.save()

# Independent reopen for all exports and consistency checks.
gpx = G2sc.G2Project(str(FINAL))
h = gpx.histogram(0)
cov = gpx.data.get("Covariance", {}).get("data", {})
rvals = cov.get("Rvals", {})
if gpx.get_Frozen():
    raise RuntimeError(f"final project has frozen variables: {gpx.get_Frozen()}")
if not rvals.get("converged", False):
    raise RuntimeError(f"final replay did not converge: {rvals}")
if list(h.data["Limits"][1]) != [float(h.getdata("X")[0]), float(h.getdata("X")[-1])]:
    raise RuntimeError("final project does not use the full measured range")

phase_specs = [
    {
        "project_name": "CaWO4_scheelite",
        "name": "calcium tungstate (scheelite)",
        "formula": "CaWO4",
        "space_group": "I 41/a",
        "cif_path": "phase_CaWO4_scheelite.cif",
        "source": "COD 7219229",
    },
    {
        "project_name": "WO3_monoclinic",
        "name": "tungsten(VI) oxide (monoclinic)",
        "formula": "WO3",
        "space_group": "P 21/c",
        "cif_path": "phase_WO3_monoclinic.cif",
        "source": "COD 2311041",
    },
    {
        "project_name": "Ca3WO6_P21c",
        "name": "tricalcium tungstate (P21/n analogue model)",
        "formula": "Ca3WO6",
        "space_group": "P 21/n",
        "cif_path": "phase_Ca3WO6_P21n.cif",
        "source": "W-for-Os adaptation of COD 1562666 (Ca3OsO6)",
    },
]

mass = h.ComputeMassFracs()
phases = []
for spec in phase_specs:
    phase = gpx.phase(spec["project_name"])
    cif_path = ROOT / spec["cif_path"]
    phase.export_CIF(str(cif_path))
    fraction, esd = mass[spec["project_name"]]
    cell = phase.get_cell()
    phases.append({
        "name": spec["name"],
        "formula": spec["formula"],
        "space_group": spec["space_group"],
        "source_model": spec["source"],
        "cif_path": spec["cif_path"],
        "weight_fraction": float(fraction),
        "weight_fraction_esd": float(esd),
        "project_path": "final.gpx",
        "refined_cell": {key: float(value) for key, value in cell.items()},
    })

fraction_sum = sum(item["weight_fraction"] for item in phases)
if not np.isclose(fraction_sum, 1.0, atol=1e-10):
    raise RuntimeError(f"weight fractions do not sum to one: {fraction_sum}")

columns = [
    "two_theta_deg",
    "observed_intensity",
    "calculated_intensity",
    "difference_intensity",
    "background_intensity",
]
arrays = [h.getdata(key) for key in ("X", "Yobs", "Ycalc", "Residual", "Background")]
with open(ROOT / "fit.csv", "w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(columns)
    writer.writerows(zip(*arrays))

fit_statistics = {
    "Rwp_percent": float(h.residuals["wR"]),
    "Rp_percent": float(h.residuals["R"]),
    "Rwp_background_subtracted_percent": float(h.residuals["wRb"]),
    "Rp_background_subtracted_percent": float(h.residuals["Rb"]),
    "Rexp_percent": float(h.residuals["wRmin"]),
    "goodness_of_fit": float(rvals.get("GOF", 0.0)),
    "chi_squared": float(rvals.get("chisq", 0.0)),
    "n_observations": int(rvals.get("Nobs", len(arrays[0]))),
    "n_variables": int(rvals.get("Nvars", 0)),
    "converged": bool(rvals.get("converged", False)),
    "max_shift_over_esd": float(rvals.get("Max shft/sig", 0.0)),
}

result = {
    "phases": phases,
    "fit_statistics": fit_statistics,
    "project_path": "final.gpx",
    "profile_path": "fit.csv",
    "weight_fraction_basis": "normalized over the modeled crystalline phases; no amorphous fraction determined",
    "measurement_range_two_theta_deg": [float(arrays[0][0]), float(arrays[0][-1])],
    "radiation": {
        "anode": "Cu",
        "wavelength_1_angstrom": 1.540598,
        "wavelength_2_angstrom": 1.544426,
        "Kalpha2_to_Kalpha1_ratio": 0.5,
    },
}
with open(ROOT / "result.json", "w") as stream:
    json.dump(result, stream, indent=2)
with open(WORK / "final_export_summary.json", "w") as stream:
    json.dump(result, stream, indent=2)

print(json.dumps(result, indent=2))
