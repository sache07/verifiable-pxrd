import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(".tmp/work").resolve()
BASE = WORK / "two_mature.gpx"


def configure(gpx, axis, profile_mode):
    h = gpx.histogram(0)
    p = gpx.phase(0)
    size = p.getHAPvalues(h)["Size"]
    size[0] = "isotropic"
    size[1] = [0.078, 0.078, 1.0]
    size[2] = [True, False, False]
    po = p.getHAPvalues(h)["Pref.Ori."]
    po[0:3] = ["MD", 1.0, True]
    po[3] = list(axis)
    # WO3 stays literal neutral.
    wo = gpx.phase(1).getHAPvalues(h)
    wo["Size"][0] = "isotropic"
    wo["Size"][1] = [10.0, 10.0, 1.0]
    wo["Size"][2] = [False, False, False]
    wo["Mustrain"][1] = [0.0, 0.0, 1.0]
    wo["Mustrain"][2] = [False, False, False]
    wo["Pref.Ori."][0:3] = ["MD", 1.0, False]
    inst = h.InstrumentParameters
    # Start from the valid Ca-size branch, then enact literal term deletions.
    inst["U"][1] = 0.8581
    inst["W"][1] = 38.9332
    inst["X"][1] = 0.3766
    for key in ("U", "W", "X"):
        inst[key][2] = key in profile_mode
    if "U" not in profile_mode:
        inst["U"][1] = 0.0
    if "X" not in profile_mode:
        inst["X"][1] = 0.0


def run(axis, profile_mode):
    axis_tag = "_".join(map(str, axis))
    prof_tag = "".join(profile_mode)
    name = f"axis_{axis_tag}_prof_{prof_tag}"
    out = WORK / f"stable_{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    gpx.set_Frozen()
    configure(gpx, axis, profile_mode)
    gpx.set_Controls("cycles", 15)
    gpx.refine()
    gpx.save()
    replay = G2sc.G2Project(str(out))
    replay.refine()
    replay.save()
    h = replay.histogram(0)
    return {
        "name": name,
        "path": str(out),
        "residuals": h.residuals,
        "mass": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "frozen": replay.get_Frozen(),
        "inst": {k: h.InstrumentParameters[k] for k in ("U", "W", "X")},
        "size": replay.phase(0).getHAPvalues(h)["Size"],
        "po": replay.phase(0).getHAPvalues(h)["Pref.Ori."],
    }


rows = []
for axis in ((0, 0, 1), (1, 1, 1), (1, 1, 0)):
    for profile_mode in (("W", "X"), ("U", "W"), ("W",)):
        rows.append(run(axis, profile_mode))

with open(WORK / "stable_summary.json", "w") as stream:
    json.dump(rows, stream, indent=2)
print("\nSTABLE SUMMARY")
for r in rows:
    print(r["name"], f"Rwp={r['residuals']['wR']:.6f}", "frozen=" + str(r["frozen"]),
          "wt=" + str({k: round(v[0], 6) for k, v in r["mass"].items()}),
          "inst=" + str({k: round(v[1], 6) for k, v in r["inst"].items()}),
          f"size={r['size'][1][0]:.6g}", f"MD={r['po'][1]:.6g}@{r['po'][3]}")
