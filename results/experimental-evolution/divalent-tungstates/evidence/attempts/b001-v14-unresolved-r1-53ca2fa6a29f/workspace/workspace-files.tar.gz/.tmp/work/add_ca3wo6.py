import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(".tmp/work").resolve()
out_scale = WORK / "inventory_ca3wo6_scale.gpx"
out_cell = WORK / "inventory_ca3wo6_cell.gpx"
gpx = G2sc.G2Project(str(WORK / "stable_axis_1_1_0_prof_UW.gpx"), newgpx=str(out_scale))
h = gpx.histogram(0)
phase = gpx.add_phase(str(Path("candidate_Ca3WO6_P21c_from_Ca3OsO6.cif").resolve()),
                      phasename="Ca3WO6_P21c", histograms=[h], fmthint="CIF")
hap = phase.getHAPvalues(h)
hap["Size"][0] = "isotropic"
hap["Size"][1] = [10.0, 10.0, 1.0]
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1] = [0.0, 0.0, 1.0]
hap["Mustrain"][2] = [False, False, False]
hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
hap["Scale"][:] = [0.5, True]
gpx.set_Controls("parmMin", 1e-10, variable="2:0:Scale")
gpx.set_Controls("cycles", 18)

# New phase scale first; cell and phase profile remain fixed.
gpx.refine()
gpx.save()
scale_replay = G2sc.G2Project(str(out_scale))
scale_replay.refine()
scale_replay.save()
h_scale = scale_replay.histogram(0)
scale = scale_replay.phase("Ca3WO6_P21c").getHAPvalues(h_scale)["Scale"][0]

# Only after positive replay, release the analogue cell.
if scale > 0 and not scale_replay.get_Frozen():
    scale_replay.phase("Ca3WO6_P21c").set_refinements({"Cell": True})
    scale_replay.refine()
    scale_replay.save(str(out_cell))
    final = G2sc.G2Project(str(out_cell))
    final.refine()
    final.save()
else:
    final = scale_replay

h = final.histogram(0)
row = {
    "scale_before_cell": scale,
    "scale_checkpoint_rwp": h_scale.residuals["wR"],
    "residuals": h.residuals,
    "mass": {k: list(v) for k, v in h.ComputeMassFracs().items()},
    "frozen": final.get_Frozen(),
    "phases": {p.name: {"cell": p.get_cell(), "scale": p.getHAPvalues(h)["Scale"][0],
                          "size": p.getHAPvalues(h)["Size"], "po": p.getHAPvalues(h)["Pref.Ori."]}
               for p in final.phases()},
}
with open(WORK / "add_ca3wo6_summary.json", "w") as stream:
    json.dump(row, stream, indent=2)
print("CA3WO6 SUMMARY", json.dumps(row, indent=2))
