import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(".tmp/work").resolve()
BASE = WORK / "joint_texture_both.gpx"
CIF_ROOT = Path("<RUN>/resources/b001-c05/cif")
CAO_CIF = CIF_ROOT / "1" / "56" / "31" / "1563196.cif"


def summarize(gpx, name, path):
    h = gpx.histogram(0)
    return {
        "name": name,
        "path": str(path),
        "Rwp_percent": float(h.residuals["wR"]),
        "Rp_percent": float(h.residuals["R"]),
        "frozen": gpx.get_Frozen(),
        "mass_fractions": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "background": list(h.data["Background"][0]),
        "polarization": list(h.InstrumentParameters["Polariz."][1:3]),
        "roughness": {k: list(h.SampleParameters[k]) for k in ("SurfRoughA", "SurfRoughB")},
        "instrument": {k: list(h.InstrumentParameters[k][1:3]) for k in ("Zero", "U", "W", "X")},
    }


def replay_branch(name, configure):
    out = WORK / f"mature_{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    gpx.set_Frozen()
    configure(gpx)
    gpx.set_Controls("cycles", 15)
    gpx.save()
    gpx.refine()
    gpx.save()
    replay = G2sc.G2Project(str(out))
    replay.set_Frozen()
    replay.refine()
    replay.save()
    return summarize(replay, name, out)


def identity(gpx):
    pass


def background_n(n):
    def configure(gpx):
        h = gpx.histogram(0)
        coeff = list(h.data["Background"][0][3:3 + n])
        h.set_refinements({"Background": {
            "type": "chebyschev-1", "refine": True,
            "no. coeffs": n, "coeffs": coeff,
        }})
    return configure


def polarization(gpx):
    h = gpx.histogram(0)
    h.InstrumentParameters["Polariz."][1:3] = [0.5, True]
    gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")


def roughness(gpx):
    h = gpx.histogram(0)
    h.SampleParameters["SurfRoughA"][:] = [0.5, True]
    h.SampleParameters["SurfRoughB"][:] = [0.01, True]
    gpx.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
    gpx.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
    gpx.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    gpx.set_Controls("parmMax", 1.0, variable=":0:SurfRoughB")


rows = [
    replay_branch("control", identity),
    replay_branch("background_4", background_n(4)),
    replay_branch("background_6", background_n(6)),
    replay_branch("polarization", polarization),
    replay_branch("roughness", roughness),
]

# CaO is challenged only after the complete three-phase inventory is mature.
cao_scale_out = WORK / "mature_add_cao_scale.gpx"
cao_final_out = WORK / "mature_add_cao_cell.gpx"
gpx = G2sc.G2Project(str(BASE), newgpx=str(cao_scale_out))
gpx.set_Frozen()
h = gpx.histogram(0)
cao = gpx.add_phase(str(CAO_CIF), phasename="CaO_1563196", histograms=[h], fmthint="CIF")
hap = cao.getHAPvalues(h)
hap["Scale"][:] = [0.01, True]
hap["Size"][0] = "isotropic"
hap["Size"][1] = [10.0, 10.0, 1.0]
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1] = [0.0, 0.0, 1.0]
hap["Mustrain"][2] = [False, False, False]
hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
cao.set_refinements({"Cell": False})
gpx.set_Controls("parmMin", 1e-10, variable="3:0:Scale")
gpx.set_Controls("cycles", 15)
gpx.refine()
gpx.save()
scale_replay = G2sc.G2Project(str(cao_scale_out))
scale_replay.set_Frozen()
scale_replay.refine()
scale_replay.save()
scale_row = summarize(scale_replay, "add_cao_scale", cao_scale_out)
scale_row["cao_scale"] = float(scale_replay.phase("CaO_1563196").getHAPvalues(scale_replay.histogram(0))["Scale"][0])
rows.append(scale_row)

if scale_row["cao_scale"] > 0.0 and not scale_row["frozen"]:
    scale_replay.phase("CaO_1563196").set_refinements({"Cell": True})
    scale_replay.refine()
    scale_replay.save(str(cao_final_out))
    cell_replay = G2sc.G2Project(str(cao_final_out))
    cell_replay.set_Frozen()
    cell_replay.refine()
    cell_replay.save()
    cell_row = summarize(cell_replay, "add_cao_cell", cao_final_out)
    cell_row["cao_scale"] = float(cell_replay.phase("CaO_1563196").getHAPvalues(cell_replay.histogram(0))["Scale"][0])
    cell_row["cao_cell"] = cell_replay.phase("CaO_1563196").get_cell()
    rows.append(cell_row)

with open(WORK / "mature_challenges_summary.json", "w") as stream:
    json.dump(rows, stream, indent=2)

print("MATURE CHALLENGES")
for row in rows:
    print(row["name"], f"Rwp={row['Rwp_percent']:.6f}",
          "frozen=" + str(row["frozen"]),
          "pol=" + str(row["polarization"]),
          "rough=" + str(row["roughness"]),
          "fractions=" + str({k: round(v[0], 6) for k, v in row["mass_fractions"].items()}))
