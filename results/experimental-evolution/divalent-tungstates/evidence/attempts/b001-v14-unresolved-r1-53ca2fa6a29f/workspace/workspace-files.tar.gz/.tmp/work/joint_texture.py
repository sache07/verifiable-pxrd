import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(".tmp/work").resolve()
BASE = WORK / "collective_all_sizes.gpx"


def set_po(gpx, phase_index, axis, refine=True):
    po = gpx.phase(phase_index).getHAPvalues(gpx.histogram(0))["Pref.Ori."]
    po[0:3] = ["MD", 1.0, bool(refine)]
    po[3] = list(axis)
    if refine:
        gpx.set_Controls("parmMin", 0.2, variable=f"{phase_index}:0:MD")
        gpx.set_Controls("parmMax", 5.0, variable=f"{phase_index}:0:MD")


def run(name, use_wo3, use_ca3):
    out = WORK / f"joint_texture_{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    gpx.set_Frozen()
    # Replay the retained CaWO4 leader and optionally the minor-phase leaders.
    set_po(gpx, 0, (1, 1, 0), True)
    set_po(gpx, 1, (1, 1, -2), use_wo3)
    set_po(gpx, 2, (0, 0, 1), use_ca3)
    gpx.set_Controls("cycles", 15)
    gpx.refine()
    gpx.save()
    replay = G2sc.G2Project(str(out))
    replay.refine()
    replay.save()
    h = replay.histogram(0)
    return {
        "name": name,
        "path": str(out),
        "r": h.residuals,
        "mass": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "frozen": replay.get_Frozen(),
        "po": {p.name: p.getHAPvalues(h)["Pref.Ori."] for p in replay.phases()},
        "sizes": {p.name: p.getHAPvalues(h)["Size"][1][0] for p in replay.phases()},
    }


rows = [run("both", True, True), run("delete_wo3", False, True), run("delete_ca3", True, False)]
with open(WORK / "joint_texture_summary.json", "w") as stream:
    json.dump(rows, stream, indent=2)
print("\nJOINT TEXTURE SUMMARY")
for r in rows:
    print(r["name"], f"Rwp={r['r']['wR']:.6f}", "frozen=" + str(r["frozen"]),
          "po=" + str({k: (round(v[1], 6), v[3], v[2]) for k, v in r["po"].items()}),
          "mass=" + str({k: round(v[0], 6) for k, v in r["mass"].items()}))
