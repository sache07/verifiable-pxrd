import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(".tmp/work").resolve()


def neutral_texture(gpx):
    h = gpx.histogram(0)
    for p in gpx.phases():
        po = p.getHAPvalues(h)["Pref.Ori."]
        po[0:3] = ["MD", 1.0, False]
        po[3] = [0, 0, 1]
        po[4] = 0
        po[5] = {}


def set_texture(gpx, phase_index, axis):
    po = gpx.phase(phase_index).getHAPvalues(gpx.histogram(0))["Pref.Ori."]
    po[0:3] = ["MD", 1.0, True]
    po[3] = list(axis)


def set_size(gpx, phase_index, value=0.1, refine=True):
    size = gpx.phase(phase_index).getHAPvalues(gpx.histogram(0))["Size"]
    size[0] = "isotropic"
    size[1] = [float(value), float(value), 1.0]
    size[2] = [bool(refine), False, False]
    size[5] = [False] * len(size[5])


def summary(gpx, name):
    h = gpx.histogram(0)
    return {
        "branch": name,
        "r": h.residuals,
        "mass": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "frozen": gpx.get_Frozen(),
        "inst": {k: h.InstrumentParameters[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "phases": {
            p.name: {
                "cell": p.get_cell(),
                "scale": p.getHAPvalues(h)["Scale"][0],
                "size": p.getHAPvalues(h)["Size"],
                "strain": p.getHAPvalues(h)["Mustrain"],
                "po": p.getHAPvalues(h)["Pref.Ori."],
            }
            for p in gpx.phases()
        },
    }


def run(name, base, setup):
    out = WORK / f"focused_{name}.gpx"
    gpx = G2sc.G2Project(str(WORK / base), newgpx=str(out))
    gpx.set_Frozen()
    setup(gpx)
    gpx.set_Controls("cycles", 15)
    gpx.refine()
    gpx.save()
    replay = G2sc.G2Project(str(out))
    replay.refine()
    replay.save()
    return summary(replay, name)


rows = []

# One limited expansion for the CaWO4 texture ambiguity.
for axis in ((1, 0, 1), (1, 1, 0), (1, 0, 2)):
    tag = "_".join(map(str, axis))
    rows.append(run(f"texture_cawo4_{tag}", "two_mature.gpx", lambda g, axis=axis: (neutral_texture(g), set_texture(g, 0, axis))))

# Cross-seed the two supported CaWO4 terms from either mature leader.
for axis in ((0, 0, 1), (1, 1, 1)):
    tag = "_".join(map(str, axis))
    rows.append(run(f"casize_then_texture_{tag}", "challenge_width_cawo4_size.gpx", lambda g, axis=axis: set_texture(g, 0, axis)))
    def from_texture(g, axis=axis):
        set_size(g, 0, 0.077, True)
    rows.append(run(f"texture_then_casize_{tag}", f"challenge_texture_cawo4_{tag}.gpx", from_texture))

# Collective low-seed size release, with and without the texture leader.
def both_sizes(g):
    neutral_texture(g)
    set_size(g, 0, 0.1, True)
    set_size(g, 1, 0.1, True)

rows.append(run("both_sizes", "two_mature.gpx", both_sizes))

def both_sizes_texture(g):
    set_size(g, 0, 0.1, True)
    set_size(g, 1, 0.1, True)
    set_texture(g, 0, (0, 0, 1))

rows.append(run("both_sizes_texture_001", "two_mature.gpx", both_sizes_texture))

with open(WORK / "focused_summary.json", "w") as stream:
    json.dump(rows, stream, indent=2)

print("\nFOCUSED SUMMARY")
for row in rows:
    vals = []
    for pname, p in row["phases"].items():
        vals.append(f"{pname}:wt={row['mass'][pname][0]:.6f},size={p['size'][1][0]:.6g},MD={p['po'][1]:.6g}@{p['po'][3]}")
    print(row["branch"], f"Rwp={row['r']['wR']:.6f}", "frozen=" + str(row["frozen"]), *vals)
