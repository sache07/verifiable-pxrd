import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SOURCE = Path(".tmp/work/inventory_ca3wo6_cell.gpx").resolve()
FINAL = Path("final.gpx").resolve()

# Save under the deliverable name, reopen, and independently replay the full range.
gpx = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
gpx.save()
gpx = G2sc.G2Project(str(FINAL))
gpx.refine()
gpx.save()

h = gpx.histogram(0)
if gpx.get_Frozen():
    raise RuntimeError(f"checkpoint has frozen variables: {gpx.get_Frozen()}")

exports = [
    ("CaWO4_scheelite", "CaWO4", "phase_CaWO4_scheelite.cif"),
    ("WO3_monoclinic", "WO3", "phase_WO3_monoclinic.cif"),
    ("Ca3WO6_P21c", "Ca3WO6", "phase_Ca3WO6_P21n.cif"),
]
mass = h.ComputeMassFracs()
phases = []
for project_name, formula, cif_name in exports:
    phase = gpx.phase(project_name)
    phase.export_CIF(str(Path(cif_name).resolve()))
    value, esd = mass[project_name]
    phases.append({
        "name": project_name,
        "formula": formula,
        "cif_path": cif_name,
        "weight_fraction": float(value),
        "weight_fraction_esd": float(esd),
        "project_path": "final.gpx",
    })

columns = ["two_theta_deg", "observed_intensity", "calculated_intensity", "difference_intensity", "background_intensity"]
arrays = [h.getdata(k) for k in ("X", "Yobs", "Ycalc", "Residual", "Background")]
with open("fit.csv", "w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(columns)
    writer.writerows(zip(*arrays))

rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
fit_statistics = {
    "Rwp_percent": float(h.residuals["wR"]),
    "Rp_percent": float(h.residuals["R"]),
    "Rwp_background_subtracted_percent": float(h.residuals["wRb"]),
    "Rp_background_subtracted_percent": float(h.residuals["Rb"]),
    "Rexp_percent": float(h.residuals["wRmin"]),
    "goodness_of_fit": float(rvals.get("GOF", 0.0)),
    "chi_squared": float(rvals.get("chisq", 0.0)),
    "n_observations": int(rvals.get("Nobs", len(arrays[0]))),
    "n_variables": int(rvals.get("Nvars", 0)),
}
result = {
    "phases": phases,
    "fit_statistics": fit_statistics,
    "project_path": "final.gpx",
    "profile_path": "fit.csv",
    "weight_fraction_basis": "normalized over modeled crystalline phases",
}
with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2)

Path("report.md").write_text(
    "# PXRD phase analysis (checkpoint)\n\n"
    "A replay-stable three-phase model contains scheelite CaWO4, monoclinic WO3, "
    "and P21/n Ca3WO6. The Ca3WO6 model is an isovalent W(VI)-for-Os(VI) adaptation "
    "of Ca3OsO6 and accounts for independent residual families near 18.7, 19.3, "
    "22.0, 31.4, 45.1, and 57.0 degrees 2theta. Optional focused challenges are "
    "still in progress; see result.json for this checkpoint's fractions and fit statistics.\n"
)
print(json.dumps(result, indent=2))
