from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path("<RUN>/resources/b001-c05/cif")


def source(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make(cod_id: str, old: str, new: str, output: str) -> None:
    structure = Structure.from_file(source(cod_id))
    structure.replace_species({old: new})
    CifWriter(structure, symprec=0.01, refine_struct=False).write_file(output)


# Primary parent: Ca3OsO6 has the same Ca/O framework, P21/n (No. 14)
# topology and isovalent octahedral Os(VI), whose ionic size is close to
# W(VI). Preserve the reported n-glide setting verbatim because it is the
# setting accepted by GSAS-II; only the isovalent species/labels and formula
# metadata are changed.
text = source("1562666").read_text()
text = text.replace("Os", "W")
text = text.replace("_chemical_formula_weight         406.44", "_chemical_formula_weight         400.07")
Path("candidate_Ca3WO6_P21c_from_Ca3OsO6.cif").write_text(text)

# Structurally distinct challenge parent: polar P21 Ca3UO6. U->W is isovalent
# only for U(VI), but the larger actinide makes this a weaker geometric analogue.
make("2310470", "U", "W", "candidate_Ca3WO6_P21_from_Ca3UO6.cif")
