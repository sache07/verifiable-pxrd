import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(".tmp/work").resolve()
ROOT = Path("<RUN>/resources/b001-c05/cif")
src = ROOT / "1" / "56" / "31" / "1563196.cif"
out = WORK / "challenge_add_cao.gpx"
gpx = G2sc.G2Project(str(WORK / "stable_axis_1_1_0_prof_UW.gpx"), newgpx=str(out))
h = gpx.histogram(0)
cao = gpx.add_phase(str(src), phasename="CaO_1563196", histograms=[h], fmthint="CIF")
hap = cao.getHAPvalues(h)
hap["Size"][0] = "isotropic"
hap["Size"][1] = [10.0, 10.0, 1.0]
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1] = [0.0, 0.0, 1.0]
hap["Mustrain"][2] = [False, False, False]
hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
hap["Scale"][:] = [0.05, True]
gpx.set_Controls("parmMin", 1e-10, variable="2:0:Scale")
gpx.set_Controls("cycles", 15)

# Scale-only entry (existing mature terms remain open), then replay.
gpx.refine()
gpx.save(str(WORK / "challenge_add_cao_scale.gpx"))
scale_replay = G2sc.G2Project(str(WORK / "challenge_add_cao_scale.gpx"))
scale_replay.refine()
scale_replay.save()

# Refine the CaO cell only after a positive replayed scale.
cao = scale_replay.phase("CaO_1563196")
scale_before_cell = cao.getHAPvalues(scale_replay.histogram(0))["Scale"][0]
if scale_before_cell > 0 and not scale_replay.get_Frozen():
    cao.set_refinements({"Cell": True})
    scale_replay.refine()
    scale_replay.save(str(out))
    final = G2sc.G2Project(str(out))
    final.refine()
    final.save()
else:
    final = scale_replay

hh = final.histogram(0)
row = {
    "scale_before_cell": scale_before_cell,
    "residuals": hh.residuals,
    "mass": {k: list(v) for k, v in hh.ComputeMassFracs().items()},
    "frozen": final.get_Frozen(),
    "phases": {p.name: {"cell": p.get_cell(), "scale": p.getHAPvalues(hh)["Scale"][0]} for p in final.phases()},
}
with open(WORK / "add_cao_summary.json", "w") as stream:
    json.dump(row, stream, indent=2)
print("CAO SUMMARY", json.dumps(row, indent=2))
