#!/usr/bin/env python3
"""Build and inspect GSAS-II models for the CaO/WO3 PXRD pattern."""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
RESOURCE_CIFS = Path(
    "<RUN>/resources/"
    "b001-c05/cif"
)


def cod_cif(cod_id: str) -> Path:
    return (
        RESOURCE_CIFS
        / cod_id[0]
        / cod_id[1:3]
        / cod_id[3:5]
        / f"{cod_id}.cif"
    )


def prepare_inputs() -> tuple[Path, Path]:
    xye = ROOT / ".tmp" / "pattern.xye"
    inst = ROOT / ".tmp" / "cu_ka_lab.instprm"
    xye.parent.mkdir(parents=True, exist_ok=True)
    with (ROOT / "inputs" / "pattern.csv").open(newline="") as source, xye.open(
        "w"
    ) as target:
        reader = csv.DictReader(source)
        target.write("# Original counts; Poisson weights assigned by GSAS-II\n")
        for row in reader:
            target.write(f"{float(row['two_theta_deg']):.8f} {float(row['intensity']):.8f}\n")
    inst.write_text(
        "#GSAS-II instrument parameter file for lab CuKa data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.5;"
        "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:100.0;V:0.0;W:50.0;X:10.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )
    return xye, inst


def build_project(wo3_id: str, output: Path) -> G2sc.G2Project:
    xye, inst = prepare_inputs()
    if output.exists():
        output.unlink()
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(xye), str(inst), fmthint="Topas xye"
    )
    project.add_phase(
        str(cod_cif("7219229")),
        phasename="CaWO4_scheelite",
        histograms=[hist],
        fmthint="CIF",
    )
    project.add_phase(
        str(cod_cif(wo3_id)),
        phasename=f"WO3_{wo3_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    project.save()
    return project


def neutralize_phase_terms(project: G2sc.G2Project) -> None:
    """Remove default size/strain broadening and other inactive HAP effects."""
    hist = project.histogram(0)
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][1:3] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 10.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][4][:] = [10.0, 10.0, 10.0, 0.0, 0.0, 0.0]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]


def configure_baseline(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    neutralize_phase_terms(project)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 10,
            }
        }
    )
    instrument = hist.data["Instrument Parameters"][0]
    instrument["Zero"] = [-0.15, -0.15, False]
    instrument["U"] = [100.0, 100.0, False]
    instrument["V"] = [0.0, 0.0, False]
    instrument["W"] = [50.0, 50.0, False]
    instrument["X"] = [10.0, 10.0, False]
    instrument["Y"] = [0.0, 0.0, False]
    instrument["Z"] = [0.0, 0.0, False]
    instrument["SH/L"] = [0.002, 0.002, False]
    project.set_Controls("cycles", 12)
    for phase in project.phases():
        project.set_Controls(
            "parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale"
        )
    for term in ("U", "W", "X"):
        project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:{term}")
    project.save()


def refine_baseline(project: G2sc.G2Project) -> None:
    """Converge background/scales, cells, one angular term, then U/W/X."""
    hist = project.histogram(0)
    instrument = hist.data["Instrument Parameters"][0]
    project.do_refinements([{}])
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.do_refinements([{}])
    instrument["Zero"][2] = True
    project.do_refinements([{}])
    for term in ("U", "W", "X"):
        instrument[term][2] = True
    project.do_refinements([{}])
    project.do_refinements([{}])


def fit_summary(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    instrument = hist.data["Instrument Parameters"][0]
    summary = {
        "project": project.filename,
        "wR_percent": hist.get_wR(),
        "histogram_stats": dict(hist.data["data"][0]),
        "instrument": {
            key: instrument[key][1]
            for key in (
                "Zero",
                "Polariz.",
                "U",
                "V",
                "W",
                "X",
                "Y",
                "Z",
                "SH/L",
            )
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "scales": {
            phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
            for phase in project.phases()
        },
    }
    try:
        summary["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        summary["mass_fraction_error"] = repr(exc)
    return summary


def compare_candidates(ids: list[str]) -> None:
    rows = []
    for wo3_id in ids:
        print(f"\n===== FITTING WO3 {wo3_id} =====", flush=True)
        output = ROOT / ".tmp" / f"candidate_{wo3_id}.gpx"
        try:
            project = build_project(wo3_id, output)
            configure_baseline(project)
            refine_baseline(project)
            project.save()
            summary = fit_summary(project)
        except Exception as exc:
            summary = {"wo3_id": wo3_id, "error": repr(exc)}
        else:
            summary["wo3_id"] = wo3_id
        print(json.dumps(summary, indent=2, default=float), flush=True)
        rows.append(summary)
    (ROOT / ".tmp" / "candidate_fits.json").write_text(
        json.dumps(rows, indent=2, default=float) + "\n"
    )


def clone_baseline(name: str) -> G2sc.G2Project:
    source = ROOT / ".tmp" / "candidate_2311041.gpx"
    output = ROOT / ".tmp" / f"nuisance_{name}.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(output))
    controls = project["Controls"]["data"]
    controls.setdefault("parmFrozen", {})["FrozenList"] = []
    instrument = project.histogram(0).data["Instrument Parameters"][0]
    instrument["U"][1] = 0.0
    instrument["U"][2] = False
    project.set_Controls("cycles", 20)
    project.save()
    return project


def nuisance_tests() -> None:
    variants = [
        "background6",
        "background14",
        "polarization",
        "roughness",
        "polarization_roughness",
        "texture_c001",
        "roughness_texture_c001",
        "all_three",
    ]
    rows = []
    for name in variants:
        print(f"\n===== NUISANCE TEST {name} =====", flush=True)
        project = clone_baseline(name)
        hist = project.histogram(0)
        inst = hist.data["Instrument Parameters"][0]
        sample = hist.data["Sample Parameters"]
        if name == "background6":
            hist.set_refinements(
                {"Background": {"refine": True, "no. coeffs": 6}}
            )
        if name == "background14":
            hist.set_refinements(
                {"Background": {"refine": True, "no. coeffs": 14}}
            )
        if "polarization" in name or name == "all_three":
            inst["Polariz."][2] = True
            project.set_Controls(
                "parmMin", 0.0, variable=f":{hist.id}:Polariz."
            )
            project.set_Controls(
                "parmMax", 1.0, variable=f":{hist.id}:Polariz."
            )
        if "roughness" in name or name == "all_three":
            sample["SurfRoughA"] = [0.0, False]
            sample["SurfRoughB"] = [0.02, True]
            project.set_Controls(
                "parmMin", 0.0, variable=f":{hist.id}:SurfRoughB"
            )
            project.set_Controls(
                "parmMax", 1.0, variable=f":{hist.id}:SurfRoughB"
            )
        if "texture" in name or name == "all_three":
            phase = project.phase("CaWO4_scheelite")
            pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
            pref[0] = "MD"
            pref[1] = 0.8
            pref[2] = True
            pref[3] = [0, 0, 1]
            project.set_Controls(
                "parmMin", 0.2, variable=f"{phase.id}:{hist.id}:MD"
            )
            project.set_Controls(
                "parmMax", 5.0, variable=f"{phase.id}:{hist.id}:MD"
            )
        project.save()
        project.do_refinements([{}])
        project.do_refinements([{}])
        project.save()
        row = fit_summary(project)
        row.update(
            {
                "variant": name,
                "polarization": inst["Polariz."][1],
                "roughness_A": sample["SurfRoughA"][0],
                "roughness_B": sample["SurfRoughB"][0],
                "background_coefficients": hist.data["Background"][0][2],
                "ca_texture_ratio": project.phase("CaWO4_scheelite")
                .data["Histograms"][hist.name]["Pref.Ori."][1],
            }
        )
        print(json.dumps(row, indent=2, default=float), flush=True)
        rows.append(row)
    (ROOT / ".tmp" / "nuisance_tests.json").write_text(
        json.dumps(rows, indent=2, default=float) + "\n"
    )


def clone_improved(name: str) -> G2sc.G2Project:
    source = ROOT / ".tmp" / "nuisance_all_three.gpx"
    output = ROOT / ".tmp" / f"targeted_{name}.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(output))
    project["Controls"]["data"].setdefault("parmFrozen", {})[
        "FrozenList"
    ] = []
    project.set_Controls("cycles", 20)
    project.save()
    return project


def _set_isotropic_broadening(
    project: G2sc.G2Project,
    phase_name: str,
    kind: str,
) -> None:
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][hist.name]
    if kind == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 2.0
        hap["Size"][2][0] = True
        project.set_Controls(
            "parmMin", 0.05, variable=f"{phase.id}:{hist.id}:Size;i"
        )
        project.set_Controls(
            "parmMax", 10.0, variable=f"{phase.id}:{hist.id}:Size;i"
        )
    elif kind == "strain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2][0] = True
        project.set_Controls(
            "parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Mustrain;i"
        )
        project.set_Controls(
            "parmMax", 10000.0, variable=f"{phase.id}:{hist.id}:Mustrain;i"
        )
    else:
        raise ValueError(kind)


def targeted_tests() -> None:
    variants = [
        "cao_watch",
        "wo3_fixed_adp",
        "wo3_grouped_adp",
        "cawo4_size",
        "cawo4_strain",
        "wo3_size",
        "wo3_strain",
    ]
    rows = []
    for name in variants:
        print(f"\n===== TARGETED TEST {name} =====", flush=True)
        project = clone_improved(name)
        hist = project.histogram(0)
        if name == "cao_watch":
            phase = project.add_phase(
                str(cod_cif("1563196")),
                phasename="CaO_watch",
                histograms=[hist],
                fmthint="CIF",
            )
            hap = phase.data["Histograms"][hist.name]
            hap["Scale"] = [0.1, True]
            hap["Pref.Ori."][1:3] = [1.0, False]
            hap["Size"][1][:] = [10.0, 10.0, 10.0]
            hap["Size"][2][:] = [False, False, False]
            hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
            hap["Mustrain"][2][:] = [False, False, False]
            phase.set_refinements({"Cell": True})
            project.set_Controls(
                "parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale"
            )
        elif name in ("wo3_fixed_adp", "wo3_grouped_adp"):
            phase = project.phase("WO3_2311041")
            w_indices = []
            o_indices = []
            for index, atom in enumerate(phase.atoms()):
                atom.uiso = 0.005 if atom.element == "W" else 0.010
                atom.refinement_flags = (
                    "U" if name == "wo3_grouped_adp" else " "
                )
                (w_indices if atom.element == "W" else o_indices).append(index)
            if name == "wo3_grouped_adp":
                project.save()
                project.add_EquivConstr(
                    [f"{phase.id}::AUiso:{i}" for i in w_indices]
                )
                project.add_EquivConstr(
                    [f"{phase.id}::AUiso:{i}" for i in o_indices]
                )
                for index in w_indices + o_indices:
                    variable = f"{phase.id}::AUiso:{index}"
                    project.set_Controls("parmMin", 0.0, variable=variable)
                    project.set_Controls("parmMax", 0.05, variable=variable)
        elif name == "cawo4_size":
            _set_isotropic_broadening(
                project, "CaWO4_scheelite", "size"
            )
        elif name == "cawo4_strain":
            _set_isotropic_broadening(
                project, "CaWO4_scheelite", "strain"
            )
        elif name == "wo3_size":
            _set_isotropic_broadening(project, "WO3_2311041", "size")
        elif name == "wo3_strain":
            _set_isotropic_broadening(project, "WO3_2311041", "strain")
        project.save()
        project.do_refinements([{}])
        project.do_refinements([{}])
        project.save()
        row = fit_summary(project)
        row["variant"] = name
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            row.setdefault("phase_terms", {})[phase.name] = {
                "scale": hap["Scale"][0],
                "size_um": hap["Size"][1][0],
                "mustrain_ppm": hap["Mustrain"][1][0],
                "march_ratio": hap["Pref.Ori."][1],
                "cell": phase.get_cell(),
                "uiso": {
                    atom.label: atom.uiso for atom in phase.atoms()
                },
            }
        print(json.dumps(row, indent=2, default=float), flush=True)
        rows.append(row)
    (ROOT / ".tmp" / "targeted_tests.json").write_text(
        json.dumps(rows, indent=2, default=float) + "\n"
    )


def _prune_final_model(project: G2sc.G2Project) -> None:
    """Set inactive terms to physical neutral values and retain tested terms."""
    hist = project.histogram(0)
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    inst = hist.data["Instrument Parameters"][0]
    for term in ("V", "Y", "Z"):
        inst[term][1:] = [0.0, False]
    # U refined to its nonnegative lower bound in the baseline and is pruned.
    inst["U"][1:] = [0.0, False]
    # No repeated asymmetric mismatch justified release of SH/L.
    inst["SH/L"][1:] = [0.002, False]
    for term in ("W", "X", "Zero", "Polariz."):
        inst[term][2] = True

    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"][1] = True

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]
        if phase.name == "CaWO4_scheelite":
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [0, 0, 1]
            hap["Size"][0] = "uniaxial"
            hap["Size"][1][2] = 10.0
            hap["Size"][2][:] = [True, True, False]
            hap["Size"][3] = [0, 0, 1]
        else:
            hap["Pref.Ori."][1:3] = [1.0, False]
            hap["Size"][0] = "isotropic"
            hap["Size"][1][:] = [10.0, 10.0, 10.0]
            hap["Size"][2][:] = [False, False, False]
        hap["Size"][4][:] = [10.0, 10.0, 10.0, 0.0, 0.0, 0.0]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])

    controls = project["Controls"]["data"]
    controls.setdefault("parmFrozen", {})["FrozenList"] = []
    project.set_Controls("cycles", 20)


def _peak_halfwidth_checks(hist: G2sc.G2PwdrData) -> list[dict]:
    """Measure representative observed/calculated peak widths numerically."""
    from scipy.signal import find_peaks, peak_widths, savgol_filter

    x, observed, _, calculated, background, _ = hist.data["data"][1]
    traces = {
        "observed": savgol_filter(observed - background, 9, 2),
        "calculated": calculated - background,
    }
    targets = [18.434, 24.225, 46.930, 76.030, 90.370]
    rows = []
    for target in targets:
        row = {"target_two_theta_deg": target}
        for name, trace in traces.items():
            mask = (x > target - 0.35) & (x < target + 0.35)
            indices = np.flatnonzero(mask)
            peaks, _ = find_peaks(trace[mask], prominence=50.0)
            if not len(peaks):
                raise RuntimeError(f"No peak found near {target:.3f} deg")
            local = peaks[np.argmin(np.abs(x[indices[peaks]] - target))]
            index = indices[local]
            _, _, left, right = peak_widths(trace, [index], rel_height=0.5)
            left_x = np.interp(left[0], np.arange(len(x)), x)
            right_x = np.interp(right[0], np.arange(len(x)), x)
            position = x[index]
            row[name] = {
                "position_two_theta_deg": position,
                "fwhm_deg": right_x - left_x,
                "left_halfwidth_deg": position - left_x,
                "right_halfwidth_deg": right_x - position,
            }
        rows.append(row)
    return rows


def _final_diagnostics(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    x, observed, weight, calculated, _, _ = hist.data["data"][1]
    stats = dict(hist.data["data"][0])
    rexp = float(stats["wRmin"])
    rwp = float(stats["wR"])
    regions = []
    for lower, upper in ((9.9, 25.0), (25.0, 40.0), (40.0, 60.0),
                         (60.0, 80.0), (80.0, 100.1)):
        select = (x >= lower) & (x < upper)
        local_rwp = 100.0 * np.sqrt(
            np.sum(weight[select] * (observed[select] - calculated[select]) ** 2)
            / np.sum(weight[select] * observed[select] ** 2)
        )
        regions.append(
            {"range_two_theta_deg": [lower, upper], "rwp_percent": local_rwp}
        )
    mass = hist.ComputeMassFracs()
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phase_rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phase_rows.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "weight_fraction": mass[phase.name][0],
                "formal_weight_fraction_esd": mass[phase.name][1],
                "size_model": hap["Size"][0],
                "size_um": list(hap["Size"][1]),
                "size_axis_hkl": list(hap["Size"][3]),
                "microstrain_ppm": hap["Mustrain"][1][0],
                "march_ratio": hap["Pref.Ori."][1],
            }
        )
    return {
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": float(stats["R"]),
            "rexp_percent": rexp,
            "goodness_of_fit": rwp / rexp,
            "reduced_chi_squared": (rwp / rexp) ** 2,
            "durbin_watson": float(stats["Durbin-Watson"]),
            "n_observations": int(stats["Nobs"]),
            "n_refined_variables": len(
                project["Covariance"]["data"].get("varyList", [])
            ),
        },
        "instrument": {
            key: {"value": inst[key][1], "refined": bool(inst[key][2])}
            for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample": {
            "roughness_A": sample["SurfRoughA"],
            "roughness_B": sample["SurfRoughB"],
        },
        "phases": phase_rows,
        "regional_fit": regions,
        "peak_halfwidth_checks": _peak_halfwidth_checks(hist),
        "full_range_two_theta_deg": list(hist.data["Limits"][1]),
    }


def finalize() -> None:
    """Prune, save/reopen/replay, and export the accepted refinement."""
    source = ROOT / ".tmp" / "targeted_cawo4_uniaxial_size.gpx"
    output = ROOT / "final.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(output))
    _prune_final_model(project)
    project.save()

    replay = []
    for iteration in (1, 2):
        project = G2sc.G2Project(str(output))
        project.do_refinements([{}])
        project.save()
        replay.append({"iteration": iteration, **fit_summary(project)})

    # All submitted artifacts are made from this independently reopened copy.
    project = G2sc.G2Project(str(output))
    hist = project.histogram(0)
    project.phase("CaWO4_scheelite").export_CIF(str(ROOT / "CaWO4.cif"))
    project.phase("WO3_2311041").export_CIF(str(ROOT / "WO3.cif"))

    x, observed, _, calculated, background, _ = hist.data["data"][1]
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_intensity",
                "background_intensity",
            ]
        )
        for values in zip(
            x, observed, calculated, observed - calculated, background
        ):
            writer.writerow([f"{values[0]:.8f}"] + [f"{v:.8f}" for v in values[1:]])

    diagnostics = _final_diagnostics(project)
    diagnostics["replay"] = replay
    (ROOT / ".tmp" / "final_summary.json").write_text(
        json.dumps(diagnostics, indent=2, default=float) + "\n"
    )
    print(json.dumps(diagnostics, indent=2, default=float))


def summarize(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    print("HISTOGRAM", hist.name)
    print("LIMITS", hist.data["Limits"])
    print("BACKGROUND", hist.data["Background"])
    print("INSTRUMENT", hist.data["Instrument Parameters"])
    print("SAMPLE", hist.data["Sample Parameters"])
    for phase in project.phases():
        print("\nPHASE", phase.name)
        print("GENERAL CELL", phase.data["General"]["Cell"])
        print("HAP", phase.data["Histograms"][hist.name])


def main() -> None:
    if len(sys.argv) > 1 and sys.argv[1] == "compare":
        compare_candidates(
            [
                "1004057",
                "1521532",
                "1521533",
                "1528915",
                "1563541",
                "2311041",
                "2106293",
                "2107312",
            ]
        )
        return
    if len(sys.argv) > 1 and sys.argv[1] == "nuisance":
        nuisance_tests()
        return
    if len(sys.argv) > 1 and sys.argv[1] == "targeted":
        targeted_tests()
        return
    if len(sys.argv) > 1 and sys.argv[1] == "finalize":
        finalize()
        return
    wo3_id = sys.argv[1] if len(sys.argv) > 1 else "2107312"
    output = ROOT / ".tmp" / f"inspect_{wo3_id}.gpx"
    project = build_project(wo3_id, output)
    summarize(project)


if __name__ == "__main__":
    main()
