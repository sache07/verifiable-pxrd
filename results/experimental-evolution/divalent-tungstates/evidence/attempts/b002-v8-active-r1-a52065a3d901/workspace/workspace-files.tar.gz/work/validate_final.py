#!/usr/bin/env python3
"""Cross-check submitted files against the reopened final.gpx state."""

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parents[1]
result = json.loads((root / "result.json").read_text())
assert result["project_path"] == "final.gpx"
assert (root / result["project_path"]).is_file()
assert (root / result["fit_path"]).is_file()

fractions = [phase["weight_fraction"] for phase in result["phases"]]
assert all(isinstance(value, (int, float)) and math.isfinite(value) for value in fractions)
assert math.isclose(sum(fractions), 1.0, rel_tol=0.0, abs_tol=1e-12)
assert all((root / phase["cif_path"]).is_file() for phase in result["phases"])

project = G2sc.G2Project(str(root / "final.gpx"))
histogram = project.histogram(0)
project_fractions = histogram.ComputeMassFracs()
for phase in result["phases"]:
    expected, expected_esd = project_fractions[phase["name"]]
    assert math.isclose(phase["weight_fraction"], expected, abs_tol=1e-12)
    assert math.isclose(phase["weight_fraction_esd"], expected_esd, abs_tol=1e-12)

with (root / "fit.csv").open(newline="") as stream:
    rows = list(csv.DictReader(stream))
profile = histogram.data["data"][1]
columns = {
    "two_theta_deg": 0,
    "observed_counts": 1,
    "calculated_counts": 3,
    "difference_counts": 5,
    "background_counts": 4,
}
assert len(rows) == len(profile[0]) == result["fit_statistics"]["n_points"]
for name, index in columns.items():
    exported = np.array([float(row[name]) for row in rows])
    stored = np.ma.filled(profile[index], np.nan)
    assert np.allclose(exported, stored, rtol=0.0, atol=1e-10)

residuals = histogram.data["data"][0]
assert math.isclose(result["fit_statistics"]["Rwp_percent"], residuals["wR"])
assert math.isclose(result["fit_statistics"]["Rexp_percent"], residuals["wRmin"])
assert math.isclose(
    result["fit_statistics"]["GOF"], residuals["wR"] / residuals["wRmin"]
)

print(
    json.dumps(
        {
            "status": "pass",
            "phases": [phase["name"] for phase in result["phases"]],
            "fraction_sum": sum(fractions),
            "fit_rows": len(rows),
            "Rwp_percent": residuals["wR"],
            "project_path": result["project_path"],
        },
        indent=2,
    )
)
