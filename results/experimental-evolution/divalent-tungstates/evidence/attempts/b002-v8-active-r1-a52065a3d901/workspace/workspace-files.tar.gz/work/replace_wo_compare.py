#!/usr/bin/env python3
"""Replace WO3 in the converged baseline and reconverge all nuisance terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def neutralize(phase, histogram) -> None:
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"] = [0.8, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Extinction"] = [0.0, False]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("label")
    parser.add_argument("wo3_cif", type=Path)
    args = parser.parse_args()
    root = Path.cwd()
    out = root / "work" / f"compare_{args.label}.gpx"
    project = G2sc.G2Project(
        str(root / "work" / "compare_ba_srwo.gpx"), newgpx=str(out)
    )
    histogram = project.histogram(0)

    del project.data["Phases"]["WO3"]
    project.names[-1].remove("WO3")
    histogram.data["Reflection Lists"].pop("WO3", None)
    phase = project.add_phase(
        str(args.wo3_cif.resolve()),
        phasename="WO3",
        histograms=[histogram],
        fmthint="CIF",
    )
    neutralize(phase, histogram)

    # Refit the complete accepted nuisance model after the source change.
    for item in project.phases():
        item.set_refinements({"Cell": True})
        item.data["Histograms"][histogram.name]["Scale"][1] = True
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "refine": True,
            }
        }
    )
    sample = histogram.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"][1] = True
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    inst = histogram.data["Instrument Parameters"][0]
    for value in inst.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    inst["U"] = [0.0, 0.0, False]
    inst["V"] = [0.0, 0.0, False]
    inst["Y"] = [0.0, 0.0, False]
    inst["W"][2] = True
    inst["X"][2] = True
    project.data["Controls"]["data"]["max cyc"] = 10
    for _ in range(4):
        project.refine(printFile=str(root / "work" / f"compare_{args.label}.lst"))

    histogram = project.histogram(0)
    residuals = histogram.data["data"][0]
    result = {
        "label": args.label,
        "source": str(args.wo3_cif),
        "Rwp": residuals["wR"],
        "Rexp": residuals["wRmin"],
        "GOF": residuals["wR"] / residuals["wRmin"],
        "fractions": histogram.ComputeMassFracs(),
        "profile": {
            key: histogram.data["Instrument Parameters"][0][key][1]
            for key in ("U", "W", "X")
        },
        "shift": histogram.data["Sample Parameters"]["Shift"][0],
        "cells": {item.name: item.get_cell() for item in project.phases()},
    }
    project.save()
    (root / "work" / f"compare_{args.label}.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    print("MODEL_RESULT", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
