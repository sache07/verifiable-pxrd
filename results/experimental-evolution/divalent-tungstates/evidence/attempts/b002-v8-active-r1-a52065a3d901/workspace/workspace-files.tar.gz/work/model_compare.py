#!/usr/bin/env python3
"""Run a consistent three-phase GSAS-II model comparison."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def neutralize(phase, histogram, scale: float) -> None:
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"] = [float(scale), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Extinction"] = [0.0, False]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("label")
    parser.add_argument("bawo4_cif", type=Path)
    parser.add_argument("wo3_cif", type=Path)
    args = parser.parse_args()

    root = Path.cwd()
    out = root / "work" / f"compare_{args.label}.gpx"
    project = G2sc.G2Project(newgpx=str(out))
    histogram = project.add_powder_histogram(
        str(root / "inputs" / "pattern.csv"),
        str(root / "work" / "cu_kalpha.instprm"),
        fmthint="comma",
    )
    phases = [
        project.add_phase(
            str(args.bawo4_cif.resolve()),
            phasename="BaWO4",
            histograms=[histogram],
            fmthint="CIF",
        ),
        project.add_phase(
            str(args.wo3_cif.resolve()),
            phasename="WO3",
            histograms=[histogram],
            fmthint="CIF",
        ),
        project.add_phase(
            str((root / "candidates" / "ba3w2o9_cod1533878.cif").resolve()),
            phasename="Ba3W2O9",
            histograms=[histogram],
            fmthint="CIF",
        ),
    ]

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 10
    controls["min dM/M"] = 1e-5
    sample = histogram.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [-400.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "refine": True,
            }
        }
    )
    for phase, scale in zip(phases, [1.0, 0.15, 0.2]):
        neutralize(phase, histogram, scale)

    # Scales and background first, with approximate physical sample shift.
    project.save()
    project.refine(printFile=str(root / "work" / f"compare_{args.label}.lst"))

    # Reconcile cells and one angular correction, then a nonnegative common profile.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    histogram = project.histogram(0)
    histogram.data["Sample Parameters"]["Shift"][1] = True
    project.refine(printFile=str(root / "work" / f"compare_{args.label}.lst"))

    histogram = project.histogram(0)
    inst = histogram.data["Instrument Parameters"][0]
    for value in inst.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    inst["U"] = [0.0, 0.0, False]
    inst["V"] = [0.0, 0.0, False]
    inst["Y"] = [0.0, 0.0, False]
    inst["W"][2] = True
    inst["X"][2] = True
    for _ in range(3):
        project.refine(printFile=str(root / "work" / f"compare_{args.label}.lst"))

    histogram = project.histogram(0)
    residuals = histogram.data["data"][0]
    fractions = histogram.ComputeMassFracs()
    result = {
        "label": args.label,
        "project": str(out),
        "bawo4_source": str(args.bawo4_cif),
        "wo3_source": str(args.wo3_cif),
        "Rwp_percent": residuals.get("wR"),
        "Rexp_percent": residuals.get("wRmin"),
        "GOF": residuals.get("wR") / residuals.get("wRmin"),
        "shift_micrometre": histogram.data["Sample Parameters"]["Shift"][0],
        "profile": {
            key: histogram.data["Instrument Parameters"][0][key][1]
            for key in ("U", "V", "W", "X", "Y", "SH/L")
        },
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][histogram.name]["Scale"][0],
                "weight_fraction": fractions.get(phase.name, [None, None])[0],
                "weight_fraction_esd": fractions.get(phase.name, [None, None])[1],
                "Rf_percent": residuals.get(f"{phase.id}:0:Rf"),
            }
            for phase in project.phases()
        },
    }
    project.save()
    (root / "work" / f"compare_{args.label}.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    print("MODEL_RESULT", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
