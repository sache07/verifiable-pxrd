#!/usr/bin/env python3
"""Challenge the final model with phase-specific WO3 broadening."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def run(mode: str) -> None:
    output = ROOT / "work" / f"test_wo3_{mode}.gpx"
    project = G2sc.G2Project(str(ROOT / "final.gpx"), newgpx=str(output))
    histogram = project.histogram(0)
    phase = project.phase("WO3")
    hap = phase.data["Histograms"][histogram.name]

    # Begin from the explicitly neutral final state, then release one cause.
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    project.save()

    if mode == "size":
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
    elif mode == "strain":
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2][0] = True
    else:
        raise ValueError(mode)

    project.data["Controls"]["data"]["max cyc"] = 10
    for _ in range(4):
        project.refine(printFile=str(ROOT / "work" / f"test_wo3_{mode}.lst"))
        project.save()

    histogram = project.histogram(0)
    hap = project.phase("WO3").data["Histograms"][histogram.name]
    residuals = histogram.data["data"][0]
    print(
        "TEST_RESULT",
        json.dumps(
            {
                "mode": mode,
                "Rwp": residuals["wR"],
                "Rexp": residuals["wRmin"],
                "GOF": residuals["wR"] / residuals["wRmin"],
                "DW": residuals["Durbin-Watson"],
                "size": hap["Size"],
                "strain": hap["Mustrain"],
                "fractions": histogram.ComputeMassFracs(),
            },
            sort_keys=True,
        ),
    )


for test_mode in ("size", "strain"):
    run(test_mode)
