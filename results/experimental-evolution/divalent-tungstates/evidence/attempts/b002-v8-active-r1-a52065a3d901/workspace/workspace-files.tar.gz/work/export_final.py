#!/usr/bin/env python3
"""Export all submitted products from the reopened final GSAS-II project."""

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
PROJECT_PATH = ROOT / "final.gpx"
FIT_PATH = ROOT / "fit.csv"

PHASE_INFO = {
    "BaWO4": {"formula": "BaWO4", "cif_path": "BaWO4.cif"},
    "WO3": {"formula": "WO3", "cif_path": "WO3.cif"},
    "Ba3W2O9": {"formula": "Ba3W2O9", "cif_path": "Ba3W2O9.cif"},
    "BaCO3": {"formula": "BaCO3", "cif_path": "BaCO3.cif"},
}


project = G2sc.G2Project(str(PROJECT_PATH))
histogram = project.histogram(0)
residuals = histogram.data["data"][0]
profile = histogram.data["data"][1]

x = np.ma.filled(profile[0], np.nan)
yobs = np.ma.filled(profile[1], np.nan)
ycalc = np.ma.filled(profile[3], np.nan)
background = np.ma.filled(profile[4], np.nan)
difference = np.ma.filled(profile[5], np.nan)
if not np.allclose(difference, yobs - ycalc, rtol=0.0, atol=1e-8):
    raise RuntimeError("GSAS-II difference array does not equal observed minus calculated")

with FIT_PATH.open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(
        [
            "two_theta_deg",
            "observed_counts",
            "calculated_counts",
            "difference_counts",
            "background_counts",
        ]
    )
    writer.writerows(zip(x, yobs, ycalc, difference, background))

mass_fractions = histogram.ComputeMassFracs()
normalizer = sum(value[0] for value in mass_fractions.values())
if not math.isclose(normalizer, 1.0, rel_tol=0.0, abs_tol=1e-10):
    raise RuntimeError(f"GSAS-II mass fractions do not sum to unity: {normalizer}")

phases = []
for phase in project.phases():
    if phase.name not in PHASE_INFO:
        raise RuntimeError(f"unexpected phase in final project: {phase.name}")
    info = PHASE_INFO[phase.name]
    cif_path = ROOT / info["cif_path"]
    phase.export_CIF(str(cif_path))
    cell = phase.get_cell()
    fraction, fraction_esd = mass_fractions[phase.name]
    phases.append(
        {
            "name": phase.name,
            "formula": info["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "cif_path": info["cif_path"],
            "weight_fraction": float(fraction / normalizer),
            "weight_fraction_esd": float(fraction_esd / normalizer),
            "cell": {
                key: float(cell[key])
                for key in (
                    "length_a",
                    "length_b",
                    "length_c",
                    "angle_alpha",
                    "angle_beta",
                    "angle_gamma",
                    "volume",
                )
            },
        }
    )

rwp = float(residuals["wR"])
rexp = float(residuals["wRmin"])
result = {
    "project_path": "final.gpx",
    "fit_path": "fit.csv",
    "phases": phases,
    "fit_statistics": {
        "Rwp_percent": rwp,
        "Rp_percent": float(residuals["R"]),
        "Rexp_percent": rexp,
        "GOF": rwp / rexp,
        "reduced_chi_squared": (rwp / rexp) ** 2,
        "Durbin_Watson": float(residuals["Durbin-Watson"]),
        "n_points": int(residuals["Nobs"]),
        "two_theta_min_deg": float(x[0]),
        "two_theta_max_deg": float(x[-1]),
    },
}

with (ROOT / "result.json").open("w") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

print(json.dumps(result, indent=2))
