#!/usr/bin/env python3
"""Numerical final-profile peak position and half-width checks."""

import csv
import json

import numpy as np
from scipy.signal import savgol_filter


with open("fit.csv", newline="") as stream:
    rows = list(csv.DictReader(stream))

x = np.array([float(row["two_theta_deg"]) for row in rows])
obs = np.array([float(row["observed_counts"]) for row in rows])
calc = np.array([float(row["calculated_counts"]) for row in rows])
bkg = np.array([float(row["background_counts"]) for row in rows])


def interpolate_x(x0, y0, x1, y1, target):
    return x0 + (target - y0) * (x1 - x0) / (y1 - y0)


def peak_metrics(signal, target, search=0.18, span=0.55, smooth=False):
    keep = np.abs(x - target) <= span
    xx = x[keep]
    yy = (signal - bkg)[keep]
    if smooth:
        yy = savgol_filter(yy, 7, 2)
    candidates = np.where(np.abs(xx - target) <= search)[0]
    apex = candidates[np.argmax(yy[candidates])]
    half = yy[apex] / 2.0
    left = apex
    while left > 0 and yy[left] > half:
        left -= 1
    right = apex
    while right < len(yy) - 1 and yy[right] > half:
        right += 1
    if left == 0 or right == len(yy) - 1:
        raise RuntimeError(f"half-height crossing missing near {target}")
    xleft = interpolate_x(xx[left], yy[left], xx[left + 1], yy[left + 1], half)
    xright = interpolate_x(
        xx[right - 1], yy[right - 1], xx[right], yy[right], half
    )
    return {
        "position_deg": float(xx[apex]),
        "left_HWHM_deg": float(xx[apex] - xleft),
        "right_HWHM_deg": float(xright - xx[apex]),
        "FWHM_deg": float(xright - xleft),
    }


checks = []
for label, target in [
    ("BaWO4 low-angle family", 26.70),
    ("BaWO4 middle-angle family", 43.19),
    ("Ba3W2O9 broadened family", 63.82),
    ("BaWO4 high-angle family", 90.43),
]:
    checks.append(
        {
            "family": label,
            "target_deg": target,
            "observed": peak_metrics(obs, target, smooth=True),
            "calculated": peak_metrics(calc, target, smooth=False),
        }
    )

print(json.dumps(checks, indent=2))
