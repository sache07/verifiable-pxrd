#!/usr/bin/env python3
"""Freeze accepted terms, save final.gpx, reopen, and replay full range."""

from GSASII import GSASIIscriptable as G2sc


SOURCE = "work/test_wo3_size.gpx"
FINAL = "final.gpx"


def freeze(project) -> None:
    histogram = project.histogram(0)
    histogram.data["Limits"][1] = [9.90343322, 100.09455322]
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "refine": True,
            }
        }
    )
    bkg_extra = histogram.data["Background"][1]
    bkg_extra["nDebye"] = 0
    bkg_extra["debyeTerms"] = []
    bkg_extra["nPeaks"] = 0
    bkg_extra["peaksList"] = []

    sample = histogram.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"][1] = True
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"][1] = True
    sample["SurfRoughB"][1] = True

    inst = histogram.data["Instrument Parameters"][0]
    for value in inst.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    inst["Polariz."] = [inst["Polariz."][0], 0.5, False]
    inst["Zero"] = [inst["Zero"][0], 0.0, False]
    inst["V"] = [inst["V"][0], 0.0, False]
    inst["Y"] = [inst["Y"][0], 0.0, False]
    inst["Z"] = [inst["Z"][0], 0.0, False]
    inst["SH/L"] = [inst["SH/L"][0], 0.002, False]
    for key in ("U", "W", "X"):
        if inst[key][1] < 0:
            raise ValueError(f"nonphysical negative common-profile term {key}")
        inst[key][2] = True

    for phase in project.phases():
        phase.set_refinements({"Cell": True, "Atoms": {"all": " "}})
        phase.data["Histograms"][histogram.name]["Scale"][1] = True
        hap = phase.data["Histograms"][histogram.name]
        hap["LeBail"] = False
        hap["Size"][0] = "isotropic"
        if phase.name == "WO3":
            # Supported phase-specific broadening; all other size terms stay neutral.
            hap["Size"][1][1:] = [10.0, 1.0]
            hap["Size"][2] = [True, False, False]
        else:
            hap["Size"][1] = [10.0, 10.0, 1.0]
            hap["Size"][2] = [False, False, False]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        if phase.name == "Ba3W2O9":
            hap["Mustrain"][1][1] = 0.0
            hap["Mustrain"][1][2] = 1.0
            hap["Mustrain"][2][0] = True
        else:
            hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        hap["Extinction"] = [0.0, False]
        hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 10
    controls["min dM/M"] = 1e-5


project = G2sc.G2Project(SOURCE, newgpx=FINAL)
freeze(project)
project.save()

for replay in range(2):
    project = G2sc.G2Project(FINAL)
    freeze(project)
    project.refine(printFile="final.lst")
    project.save()
    histogram = project.histogram(0)
    residuals = histogram.data["data"][0]
    print(
        "REPLAY",
        replay + 1,
        "Rwp",
        residuals.get("wR"),
        "Rexp",
        residuals.get("wRmin"),
        "fractions",
        histogram.ComputeMassFracs(),
    )
