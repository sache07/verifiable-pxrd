#!/usr/bin/env python3
"""Compare low-order smooth backgrounds from one accepted combined model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/combined/both_plus_polarization.gpx"


def main() -> None:
    outdir = ROOT / ".tmp/background_tests"
    outdir.mkdir(parents=True, exist_ok=True)
    rows = []
    for terms in (10, 12, 16):
        outpath = outdir / f"chebyschev_{terms}.gpx"
        project = G2sc.G2Project(str(SOURCE), newgpx=str(outpath))
        project.set_Frozen()
        project.set_Controls("cycles", 12)
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
        hist = project.histogram(0)
        hist.set_refinements(
            {
                "Background": {
                    "type": "chebyschev-1",
                    "refine": True,
                    "no. coeffs": terms,
                }
            }
        )
        for _ in range(3):
            project.refine()
        project.save()
        rows.append(
            {
                "terms": terms,
                "gpx": str(outpath),
                "wR_percent": hist.get_wR(),
                "residuals": hist.data["data"][0].copy(),
                "background": hist.data["Background"][0][3:],
                "mass_fractions": {
                    key: {"value": val[0], "esd": val[1]}
                    for key, val in hist.ComputeMassFracs().items()
                },
                "frozen": project.get_Frozen(),
            }
        )
    (outdir / "summary.json").write_text(
        json.dumps(rows, indent=2, default=str) + "\n"
    )
    print(json.dumps(rows, indent=2, default=str))


if __name__ == "__main__":
    main()
