#!/usr/bin/env python3
"""Target WO3 strain-shape alternatives after the common-profile fit."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/background_tests/chebyschev_16.gpx"


def apply_test(name, project, hist, wo3):
    hap = wo3.data["Histograms"][hist.name]
    strain = float(hap["Mustrain"][1][0])
    if name == "isotropic_lgmix":
        wo3.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 0.5, "refine": True},
                }
            }
        )
        project.set_Controls("parmMin", 0.0, f"{wo3.id}:0:Mustrain;mx")
        project.set_Controls("parmMax", 1.0, f"{wo3.id}:0:Mustrain;mx")
    elif name.startswith("uniaxial_"):
        axis = {
            "uniaxial_100": [1, 0, 0],
            "uniaxial_010": [0, 1, 0],
            "uniaxial_001": [0, 0, 1],
        }[name]
        hap["Mustrain"][1][1] = strain
        wo3.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "uniaxial",
                    "direction": axis,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )
        for suffix in ("i", "a"):
            project.set_Controls("parmMin", 0.0, f"{wo3.id}:0:Mustrain;{suffix}")
            project.set_Controls("parmMax", 15000.0, f"{wo3.id}:0:Mustrain;{suffix}")
    else:
        raise ValueError(name)


def run(name):
    outdir = ROOT / ".tmp/profile_tests"
    outdir.mkdir(parents=True, exist_ok=True)
    path = outdir / f"{name}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = project.histogram(0)
    wo3 = project.phase("WO3")
    apply_test(name, project, hist, wo3)
    for _ in range(3):
        project.refine()
    project.save()
    hap = wo3.data["Histograms"][hist.name]
    return {
        "test": name,
        "gpx": str(path),
        "wR_percent": hist.get_wR(),
        "residuals": hist.data["data"][0].copy(),
        "strain_type": hap["Mustrain"][0],
        "strain_values": hap["Mustrain"][1],
        "strain_axis": hap["Mustrain"][3],
        "mass_fractions": {
            key: {"value": val[0], "esd": val[1]}
            for key, val in hist.ComputeMassFracs().items()
        },
        "frozen": project.get_Frozen(),
        "vary_list": project.data["Covariance"]["data"].get("varyList", []),
    }


def main():
    rows = []
    for name in ("isotropic_lgmix", "uniaxial_100", "uniaxial_010", "uniaxial_001"):
        try:
            rows.append(run(name))
        except Exception as exc:
            rows.append({"test": name, "error": repr(exc)})
    out = ROOT / ".tmp/profile_tests/summary.json"
    out.write_text(json.dumps(rows, indent=2, default=str) + "\n")
    print(json.dumps(rows, indent=2, default=str))


if __name__ == "__main__":
    main()
