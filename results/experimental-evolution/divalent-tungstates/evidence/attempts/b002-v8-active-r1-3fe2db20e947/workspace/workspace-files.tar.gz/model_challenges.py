#!/usr/bin/env python3
"""Replay structural paths and test restrained displacement-parameter models."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCES = {
    "simultaneous": ROOT / ".tmp/structure_tests/mgwo4_and_wo3_w_x.gpx",
    "mgwo4_first": ROOT / ".tmp/structure_tests/mgwo4_all_x.gpx",
    "wo3_first": ROOT / ".tmp/structure_tests/wo3_w_x.gpx",
}


def add_x_flags(project) -> None:
    mgwo4 = project.phase("MgWO4")
    wo3 = project.phase("WO3")
    for atom in mgwo4.atoms():
        atom.refinement_flags = "X"
    for atom in wo3.atoms():
        atom.refinement_flags = "X" if atom.element == "W" else ""


def add_wo3_u(project, two_groups: bool) -> None:
    wo3 = project.phase("WO3")
    wvars, ovars = [], []
    for index, atom in enumerate(wo3.atoms()):
        if atom.element == "W":
            atom.uiso = 0.004
            atom.refinement_flags = "XU"
            wvars.append(f"{wo3.id}::AUiso:{index}")
        else:
            atom.uiso = 0.008
            atom.refinement_flags = "U"
            ovars.append(f"{wo3.id}::AUiso:{index}")
        project.set_Controls("parmMin", 0.0, f"{wo3.id}::AUiso:{index}")
        project.set_Controls("parmMax", 0.05, f"{wo3.id}::AUiso:{index}")
    if two_groups:
        project.add_EquivConstr(tuple(wvars))
        project.add_EquivConstr(tuple(ovars))
    else:
        project.add_EquivConstr(tuple(wvars + ovars))


def add_mgwo4_u(project) -> None:
    phase = project.phase("MgWO4")
    for index, atom in enumerate(phase.atoms()):
        atom.refinement_flags = "XU"
        project.set_Controls("parmMin", 0.0, f"{phase.id}::AUiso:{index}")
        project.set_Controls("parmMax", 0.05, f"{phase.id}::AUiso:{index}")


def configure(name: str, project) -> None:
    add_x_flags(project)
    if name == "wo3_all_x":
        for atom in project.phase("WO3").atoms():
            atom.refinement_flags = "X"
    elif name == "wo3_common_u":
        add_wo3_u(project, False)
    elif name == "wo3_two_u":
        add_wo3_u(project, True)
    elif name == "mgwo4_u":
        add_mgwo4_u(project)
    elif name == "mgwo4_u_wo3_two_u":
        add_mgwo4_u(project)
        add_wo3_u(project, True)
    elif name not in ("from_mgwo4_first", "from_wo3_first"):
        raise ValueError(name)


def run(name: str, source: Path) -> dict:
    outdir = ROOT / ".tmp/model_challenges"
    outdir.mkdir(parents=True, exist_ok=True)
    outpath = outdir / f"{name}.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(outpath))
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    configure(name, project)
    for _ in range(2):
        project.refine()
    project.save()
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    return {
        "test": name,
        "source": str(source),
        "gpx": str(outpath),
        "wR_percent": hist.get_wR(),
        "residuals": hist.data["data"][0].copy(),
        "mass_fractions": {
            key: {"value": val[0], "esd": val[1]}
            for key, val in hist.ComputeMassFracs().items()
        },
        "atoms": {
            phase.name: [
                {
                    "label": atom.label,
                    "xyz": list(atom.coordinates),
                    "uiso": atom.uiso,
                    "flag": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ]
            for phase in project.phases()
        },
        "vary_list": cov.get("varyList", []),
        "sig": dict(zip(cov.get("varyList", []), cov.get("sig", []))),
        "frozen": project.get_Frozen(),
    }


def main() -> None:
    jobs = (
        ("from_mgwo4_first", SOURCES["mgwo4_first"]),
        ("from_wo3_first", SOURCES["wo3_first"]),
        ("wo3_all_x", SOURCES["simultaneous"]),
        ("wo3_common_u", SOURCES["simultaneous"]),
        ("wo3_two_u", SOURCES["simultaneous"]),
        ("mgwo4_u", SOURCES["simultaneous"]),
        ("mgwo4_u_wo3_two_u", SOURCES["simultaneous"]),
    )
    rows = []
    for name, source in jobs:
        try:
            rows.append(run(name, source))
        except Exception as exc:
            rows.append({"test": name, "error": repr(exc)})
    out = ROOT / ".tmp/model_challenges/summary.json"
    out.write_text(json.dumps(rows, indent=2, default=str) + "\n")
    print(json.dumps(rows, indent=2, default=str))


if __name__ == "__main__":
    main()
