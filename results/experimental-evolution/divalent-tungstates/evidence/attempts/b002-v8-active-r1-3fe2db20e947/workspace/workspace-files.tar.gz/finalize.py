#!/usr/bin/env python3
"""Freeze, replay, export and validate the selected GSAS-II model."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/model_challenges/from_mgwo4_first.gpx"
FINAL = ROOT / "final.gpx"
PHASE_FILES = {
    "MgWO4": ROOT / "MgWO4.cif",
    "WO3": ROOT / "WO3.cif",
    "MgO": ROOT / "MgO.cif",
}
PHASE_META = {
    "MgWO4": {
        "formula": "MgWO4",
        "phase_name": "magnesium tungstate (wolframite/huanzalaite type)",
        "space_group": "P 1 2/c 1",
        "source": "COD 9013902",
    },
    "WO3": {
        "formula": "WO3",
        "phase_name": "monoclinic gamma-WO3",
        "space_group": "P 1 21/c 1",
        "source": "COD 2311041",
    },
    "MgO": {
        "formula": "MgO",
        "phase_name": "periclase MgO",
        "space_group": "F m -3 m",
        "source": "COD 9000499",
    },
}


def freeze_selected_model(project: G2sc.G2Project) -> None:
    """Explicitly neutralize every rejected nuisance term."""
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.data["Constraints"]["data"].update(
        {"Hist": [], "HAP": [], "Phase": [], "Global": []}
    )

    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    hist.data["Limits"][1] = [float(arrays[0][0]), float(arrays[0][-1])]

    inst = hist.data["Instrument Parameters"][0]
    for key in ("V", "Y", "Z"):
        inst[key][1:] = [0.0, False]
    inst["SH/L"][1:] = [0.002, False]
    for key in ("U", "W", "X", "Zero", "Polariz."):
        inst[key][2] = True
    for key in ("Lam1", "Lam2", "I(L2)/I(L1)", "Azimuth"):
        inst[key][2] = False

    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    for key in (
        "Absorption",
        "DisplaceX",
        "DisplaceY",
        "Shift",
        "Transparency",
        "SurfRoughA",
        "SurfRoughB",
    ):
        sample[key] = [0.0, False]

    background = hist.data["Background"]
    background[0][0] = "chebyschev-1"
    background[0][1] = True
    background[0][2] = 16
    background[1]["nDebye"] = 0
    background[1]["debyeTerms"] = []
    background[1]["nPeaks"] = 0
    background[1]["peaksList"] = []

    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Use"] = True
        hap["LeBail"] = False

        # Ten micrometres is the neutral GSAS-II size limit used here.
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][4] = [100.0, 100.0, 100.0, 0.0, 0.0, 0.0]
        hap["Size"][5] = [False] * len(hap["Size"][5])

        hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]

        if phase.name == "MgWO4":
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [0, 1, 0]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1] = [0.0, 0.0, 1.0]
            hap["Mustrain"][2] = [False, False, False]
            hap["Mustrain"][4] = [0.0] * len(hap["Mustrain"][4])
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
            for atom in phase.atoms():
                atom.refinement_flags = "X"
        elif phase.name == "WO3":
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1][2] = 1.0
            hap["Mustrain"][2] = [True, True, False]
            hap["Mustrain"][3] = [1, 0, 0]
            hap["Mustrain"][4] = [0.0] * len(hap["Mustrain"][4])
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
            for atom in phase.atoms():
                atom.refinement_flags = "X" if atom.element == "W" else ""
        else:
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1] = [0.0, 0.0, 1.0]
            hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
            hap["Mustrain"][4] = [0.0] * len(hap["Mustrain"][4])
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
            for atom in phase.atoms():
                atom.refinement_flags = ""


def replay() -> G2sc.G2Project:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    freeze_selected_model(project)
    for _ in range(2):
        project.refine()
    project.save()

    # Required disk replay over the complete measured range.
    project = G2sc.G2Project(str(FINAL))
    freeze_selected_model(project)
    for _ in range(2):
        project.refine()
    project.save()

    # Reopen once more so every submitted value is read from final.gpx.
    return G2sc.G2Project(str(FINAL))


def crossing(x: np.ndarray, y: np.ndarray, peak: int, half: float, side: str) -> float:
    if side == "left":
        for i in range(peak - 1, -1, -1):
            if y[i] <= half <= y[i + 1]:
                return float(x[i] + (half - y[i]) * (x[i + 1] - x[i]) / (y[i + 1] - y[i]))
    else:
        for i in range(peak, len(y) - 1):
            if y[i] >= half >= y[i + 1]:
                return float(x[i] + (half - y[i]) * (x[i + 1] - x[i]) / (y[i + 1] - y[i]))
    return float("nan")


def peak_metric(
    xall: np.ndarray,
    signal_all: np.ndarray,
    target: float,
    window: float,
    smooth_sigma: float,
) -> dict:
    mask = (xall >= target - window) & (xall <= target + window)
    x = np.asarray(xall[mask], dtype=float)
    raw = np.asarray(signal_all[mask], dtype=float)
    nedge = max(3, len(raw) // 12)
    left = float(np.median(raw[:nedge]))
    right = float(np.median(raw[-nedge:]))
    baseline = np.linspace(left, right, len(raw))
    y = raw - baseline
    if smooth_sigma:
        y = gaussian_filter1d(y, smooth_sigma)
    central = np.where((x >= target - window / 2) & (x <= target + window / 2))[0]
    peak = int(central[np.argmax(y[central])])
    half = float(y[peak] / 2.0)
    xl = crossing(x, y, peak, half, "left")
    xr = crossing(x, y, peak, half, "right")
    return {
        "position_deg": float(x[peak]),
        "fwhm_deg": float(xr - xl),
        "left_half_width_deg": float(x[peak] - xl),
        "right_half_width_deg": float(xr - x[peak]),
    }


def diagnostics(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    x, yobs, weight, ycalc, ybkg, ydiff = [
        np.asarray(a, dtype=float) for a in hist.data["data"][1]
    ]
    checks = (
        ("MgWO4 (010)", 15.576, 0.24),
        ("MgWO4 (100)", 18.879, 0.24),
        ("MgWO4 (200)", 38.297, 0.30),
        ("MgO (200), Cu doublet", 42.916, 0.36),
        ("MgWO4 (023)", 65.376, 0.34),
        ("high-angle family near 82 deg", 81.991, 0.38),
        ("high-angle family near 88 deg", 88.326, 0.32),
    )
    spot = []
    for label, target, window in checks:
        spot.append(
            {
                "family": label,
                "observed": peak_metric(x, yobs - ybkg, target, window, 0.7),
                "calculated": peak_metric(x, ycalc - ybkg, target, window, 0.0),
            }
        )

    standardized = (yobs - ycalc) * np.sqrt(np.maximum(weight, 0.0))
    smooth = gaussian_filter1d(standardized, 2.0)
    pos, posprops = find_peaks(smooth, prominence=0.4, distance=8)
    neg, negprops = find_peaks(-smooth, prominence=0.4, distance=8)
    residual_peaks = [
        {
            "position_deg": float(x[i]),
            "standardized_smoothed_residual": float(smooth[i]),
            "sign": "positive",
            "prominence": float(posprops["prominences"][j]),
        }
        for j, i in enumerate(pos)
    ] + [
        {
            "position_deg": float(x[i]),
            "standardized_smoothed_residual": float(smooth[i]),
            "sign": "negative",
            "prominence": float(negprops["prominences"][j]),
        }
        for j, i in enumerate(neg)
    ]
    residual_peaks.sort(key=lambda row: abs(row["standardized_smoothed_residual"]), reverse=True)
    return {
        "spot_checks": spot,
        "largest_smoothed_standardized_residuals": residual_peaks[:20],
        "difference_array_matches_observed_minus_calculated": bool(
            np.allclose(ydiff, yobs - ycalc, rtol=0.0, atol=1.0e-8)
        ),
    }


def write_outputs(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    for phase in project.phases():
        phase.export_CIF(str(PHASE_FILES[phase.name]))

    x, yobs, _weight, ycalc, _ybkg, _ydiff = [
        np.asarray(a, dtype=float) for a in hist.data["data"][1]
    ]
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta_deg", "observed_counts", "calculated_counts", "difference_counts"]
        )
        for row in zip(x, yobs, ycalc, yobs - ycalc):
            writer.writerow([f"{value:.10g}" for value in row])

    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    residuals = hist.data["data"][0]
    mass = hist.ComputeMassFracs()
    phases = []
    for phase in project.phases():
        value, esd = mass[phase.name]
        entry = {
            "name": PHASE_META[phase.name]["phase_name"],
            "formula": PHASE_META[phase.name]["formula"],
            "space_group": PHASE_META[phase.name]["space_group"],
            "cif_path": PHASE_FILES[phase.name].name,
            "weight_fraction": float(value),
            "weight_fraction_esd": float(esd),
            "structure_source": PHASE_META[phase.name]["source"],
            "unit_cell": {key: float(val) for key, val in phase.get_cell().items()},
            "R_F_percent": float(residuals[f"{phase.id}:0:Rf"]),
            "R_F_squared_percent": float(residuals[f"{phase.id}:0:Rf^2"]),
        }
        phases.append(entry)

    total = sum(item["weight_fraction"] for item in phases)
    for item in phases:
        item["weight_fraction"] /= total

    result = {
        "project_path": FINAL.name,
        "pattern_path": "inputs/pattern.csv",
        "measurement": {
            "radiation": "Cu K-alpha1/K-alpha2",
            "wavelengths_angstrom": [1.540598, 1.544426],
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "geometry": "reflection Bragg-Brentano",
            "two_theta_range_deg": [float(x[0]), float(x[-1])],
        },
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": float(rvals["Rwp"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "durbin_watson": float(residuals["Durbin-Watson"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
            "degrees_of_freedom": int(rvals["Nobs"] - rvals["Nvars"]),
            "converged": bool(rvals["converged"]),
            "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def verify_result(result: dict) -> None:
    assert result["project_path"] == "final.gpx"
    assert FINAL.exists()
    assert math.isclose(
        sum(item["weight_fraction"] for item in result["phases"]),
        1.0,
        rel_tol=0.0,
        abs_tol=1.0e-10,
    )
    assert all(isinstance(item["weight_fraction"], float) for item in result["phases"])
    assert all((ROOT / item["cif_path"]).exists() for item in result["phases"])
    assert (ROOT / "fit.csv").exists()


def main() -> None:
    project = replay()
    assert not project.get_Frozen()
    result = write_outputs(project)
    verify_result(result)
    diag = diagnostics(project)
    (ROOT / ".tmp/final_diagnostics.json").write_text(json.dumps(diag, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    print(json.dumps(diag, indent=2))


if __name__ == "__main__":
    main()
