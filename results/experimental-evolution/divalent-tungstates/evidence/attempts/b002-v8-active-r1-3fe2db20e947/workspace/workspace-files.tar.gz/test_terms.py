#!/usr/bin/env python3
"""Replay targeted nuisance/profile tests from one saved GSAS-II baseline."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASELINE = ROOT / ".tmp/trials/monoclinic_2311041.gpx"


def branch(name: str):
    outdir = ROOT / ".tmp/term_tests"
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(BASELINE), newgpx=str(outdir / f"{name}.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    return project, project.histogram(0), project.phases()


def apply_term(name: str, project, hist, phases) -> None:
    if name == "polarization":
        hist.data["Instrument Parameters"][0]["Polariz."][2] = True
        project.set_Controls("parmMin", 0.0, ":0:Polariz.")
        project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    elif name == "roughness":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.5, True]
        sample["SurfRoughB"] = [0.01, True]
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughA")
        project.set_Controls("parmMax", 1.0, ":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
        project.set_Controls("parmMax", 1.0, ":0:SurfRoughB")
    elif name == "mgwo4_texture_100":
        hap = phases[0].data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 0.8
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = [1, 0, 0]
        project.set_Controls("parmMin", 0.2, f"{phases[0].id}:0:MD")
        project.set_Controls("parmMax", 5.0, f"{phases[0].id}:0:MD")
    elif name == "mgwo4_texture_010":
        hap = phases[0].data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.2
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = [0, 1, 0]
        project.set_Controls("parmMin", 0.2, f"{phases[0].id}:0:MD")
        project.set_Controls("parmMax", 5.0, f"{phases[0].id}:0:MD")
    elif name == "isotropic_size_all":
        for phase in phases:
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 10.0, "refine": True}}
            )
            project.set_Controls("parmMin", 0.05, f"{phase.id}:0:Size;i")
            project.set_Controls("parmMax", 10.0, f"{phase.id}:0:Size;i")
    elif name == "isotropic_strain_all":
        for phase in phases:
            hap = phase.data["Histograms"][hist.name]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 100.0
            hap["Mustrain"][2][0] = True
            project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Mustrain;i")
            project.set_Controls("parmMax", 10000.0, f"{phase.id}:0:Mustrain;i")
    else:
        raise ValueError(name)


def summarize(name: str, project, hist, phases) -> dict:
    sample = hist.data["Sample Parameters"]
    inst = hist.data["Instrument Parameters"][0]
    out = {
        "test": name,
        "gpx": project.filename,
        "wR_percent": hist.get_wR(),
        "residuals": hist.data["data"][0].copy(),
        "instrument": {
            key: inst[key][1]
            for key in ("Polariz.", "Zero", "U", "W", "X", "SH/L")
        },
        "sample": {
            key: sample[key][0]
            for key in ("SurfRoughA", "SurfRoughB", "Shift", "Transparency")
        },
        "mass_fractions": {
            key: {"value": val[0], "esd": val[1]}
            for key, val in hist.ComputeMassFracs().items()
        },
        "phase_terms": {},
        "vary_list": project.data["Covariance"]["data"].get("varyList", []),
    }
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        out["phase_terms"][phase.name] = {
            "MD": hap["Pref.Ori."][1],
            "MD_axis": hap["Pref.Ori."][3],
            "size_um": hap["Size"][1][0],
            "strain_ppm": hap["Mustrain"][1][0],
        }
    return out


def main() -> None:
    tests = [
        "polarization",
        "roughness",
        "mgwo4_texture_100",
        "mgwo4_texture_010",
        "isotropic_size_all",
        "isotropic_strain_all",
    ]
    rows = []
    for name in tests:
        try:
            project, hist, phases = branch(name)
            apply_term(name, project, hist, phases)
            project.refine()
            project.refine()
            project.save()
            rows.append(summarize(name, project, hist, phases))
        except Exception as exc:
            rows.append({"test": name, "error": repr(exc)})
    out = ROOT / ".tmp/term_tests/summary.json"
    out.write_text(json.dumps(rows, indent=2, default=str) + "\n")
    print(json.dumps(rows, indent=2, default=str))


if __name__ == "__main__":
    main()
