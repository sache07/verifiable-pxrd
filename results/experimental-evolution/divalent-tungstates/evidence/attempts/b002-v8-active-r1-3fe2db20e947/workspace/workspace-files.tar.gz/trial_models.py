#!/usr/bin/env python3
"""Fit a common neutral-profile model to competing WO3 structure records."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PHASES = {
    "MgWO4": COD / "9/01/39/9013902.cif",
    "MgO": COD / "9/00/04/9000499.cif",
}
WO3_MODELS = {
    "triclinic_2106293": COD / "2/10/62/2106293.cif",
    "orthorhombic_2107312": COD / "2/10/73/2107312.cif",
    "monoclinic_1563541": COD / "1/56/35/1563541.cif",
    "monoclinic_2311041": COD / "2/31/10/2311041.cif",
    "tetragonal_1521532": COD / "1/52/15/1521532.cif",
}


def neutralize_hap(phase, histogram_name: str) -> None:
    """Remove default size/strain/texture broadening before comparisons."""
    hap = phase.data["Histograms"][histogram_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 100.0  # micrometres; effectively neutral
    hap["Size"][1][1] = 100.0
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Size"][4] = [100.0, 100.0, 100.0, 0.0, 0.0, 0.0]
    hap["Size"][5] = [False] * len(hap["Size"][5])

    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0  # ppm
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][4] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])

    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def configure_histogram(hist) -> None:
    hist.set_refinements(
        {
            "Limits": [9.90343322, 100.09455322],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
                "coeffs": [3500.0] + [0.0] * 7,
            },
        }
    )
    sample = hist.data["Sample Parameters"]
    for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = False
    sample["Scale"][0] = 1.0
    sample["Shift"][0] = 0.0
    sample["Transparency"][0] = 0.0
    sample["SurfRoughA"][0] = 0.0
    sample["SurfRoughB"][0] = 0.0

    inst = hist.data["Instrument Parameters"][0]
    fixed = {
        "Lam1": 1.540598,
        "Lam2": 1.544426,
        "I(L2)/I(L1)": 0.5,
        "Polariz.": 0.5,
        "Zero": 0.0,
        "U": 10.0,
        "V": 0.0,
        "W": 25.0,
        "X": 1.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }
    for key, value in fixed.items():
        inst[key][1] = value
        inst[key][2] = False


def run_refinement(project, hist, phases) -> None:
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.index_ids()
    for phase in phases:
        project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Scale")
    for name in ("U", "W", "X"):
        project.set_Controls("parmMin", 0.0, f":0:{name}")

    # Background and nonnegative phase scales.
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    project.refine()

    # Cells plus exactly one angular correction (instrument zero).
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()

    # Common low-dimensional nonnegative profile baseline.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.refine()
    project.refine()


def summarize(project, hist, phases, label: str) -> dict:
    inst = hist.data["Instrument Parameters"][0]
    result = {
        "model": label,
        "gpx": str(Path(project.filename).resolve()),
        "wR_percent": hist.get_wR(),
        "residuals": hist.data["data"][0].copy(),
        "instrument": {key: inst[key][1] for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")},
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "scales": {
            phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
            for phase in phases
        },
    }
    try:
        result["mass_fractions"] = {
            key: {"value": value[0], "esd": value[1]}
            for key, value in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        result["mass_fraction_error"] = repr(exc)
    return result


def fit_one(label: str, wo3_path: Path) -> dict:
    outdir = ROOT / ".tmp" / "trials"
    outdir.mkdir(parents=True, exist_ok=True)
    gpx_path = outdir / f"{label}.gpx"
    project = G2sc.G2Project(newgpx=str(gpx_path))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    configure_histogram(hist)
    phase_specs = [
        ("MgWO4", PHASES["MgWO4"]),
        ("WO3", wo3_path),
        ("MgO", PHASES["MgO"]),
    ]
    phases = []
    for name, path in phase_specs:
        phase = project.add_phase(
            str(path), phasename=name, histograms=[hist], fmthint="CIF"
        )
        neutralize_hap(phase, hist.name)
        phases.append(phase)
    run_refinement(project, hist, phases)
    project.save()
    return summarize(project, hist, phases, label)


def main() -> None:
    summaries = []
    for label, path in WO3_MODELS.items():
        try:
            summaries.append(fit_one(label, path))
        except Exception as exc:
            summaries.append({"model": label, "error": repr(exc)})
    path = ROOT / ".tmp" / "trials" / "summary.json"
    path.write_text(json.dumps(summaries, indent=2, default=str) + "\n")
    print(json.dumps(summaries, indent=2, default=str))


if __name__ == "__main__":
    main()
