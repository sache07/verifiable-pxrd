#!/usr/bin/env python3
"""Check replay stability and complementarity of texture and WO3 strain."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCES = {
    "baseline": ROOT / ".tmp/trials/monoclinic_2311041.gpx",
    "texture": ROOT / ".tmp/term_tests/mgwo4_texture_010.gpx",
    "strain": ROOT / ".tmp/term_tests/isotropic_strain_all.gpx",
}


def reset_unwanted_strain(phases, hist_name: str) -> None:
    for index in (0, 2):
        hap = phases[index].data["Histograms"][hist_name]
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])


def add_texture(project, hist, phases, start=1.274) -> None:
    hap = phases[0].data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = start
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = [0, 1, 0]
    project.set_Controls("parmMin", 0.2, f"{phases[0].id}:0:MD")
    project.set_Controls("parmMax", 5.0, f"{phases[0].id}:0:MD")


def add_wo3_strain(project, hist, phases, start=5000.0) -> None:
    hap = phases[1].data["Histograms"][hist.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = start
    hap["Mustrain"][2][0] = True
    project.set_Controls("parmMin", 0.0, f"{phases[1].id}:0:Mustrain;i")
    project.set_Controls("parmMax", 10000.0, f"{phases[1].id}:0:Mustrain;i")


def refine_path(name: str, source: Path, add_pol=False) -> tuple[dict, Path]:
    outdir = ROOT / ".tmp/combined"
    outdir.mkdir(parents=True, exist_ok=True)
    outpath = outdir / f"{name}.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(outpath))
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = project.histogram(0)
    phases = project.phases()
    reset_unwanted_strain(phases, hist.name)
    add_texture(project, hist, phases)
    add_wo3_strain(project, hist, phases)
    if add_pol:
        hist.data["Instrument Parameters"][0]["Polariz."][2] = True
        project.set_Controls("parmMin", 0.0, ":0:Polariz.")
        project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    for _ in range(3):
        project.refine()
    project.save()
    mass = hist.ComputeMassFracs()
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    row = {
        "path": name,
        "source": str(source),
        "gpx": str(outpath),
        "wR_percent": hist.get_wR(),
        "residuals": hist.data["data"][0].copy(),
        "mass_fractions": {
            key: {"value": value[0], "esd": value[1]}
            for key, value in mass.items()
        },
        "MD_010": phases[0].data["Histograms"][hist.name]["Pref.Ori."][1],
        "WO3_strain_ppm": phases[1].data["Histograms"][hist.name]["Mustrain"][1][0],
        "instrument": {
            key: inst[key][1]
            for key in ("Polariz.", "Zero", "U", "W", "X", "SH/L")
        },
        "roughness": [sample["SurfRoughA"][0], sample["SurfRoughB"][0]],
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "vary_list": project.data["Covariance"]["data"].get("varyList", []),
        "frozen": project.get_Frozen(),
    }
    return row, outpath


def main() -> None:
    rows = []
    for name, source in (
        ("both_from_baseline", SOURCES["baseline"]),
        ("strain_on_texture", SOURCES["texture"]),
        ("texture_on_strain", SOURCES["strain"]),
    ):
        try:
            row, _ = refine_path(name, source)
            rows.append(row)
        except Exception as exc:
            rows.append({"path": name, "error": repr(exc)})

    best = min((row for row in rows if "wR_percent" in row), key=lambda row: row["wR_percent"])
    try:
        polrow, _ = refine_path("both_plus_polarization", Path(best["gpx"]), add_pol=True)
        rows.append(polrow)
    except Exception as exc:
        rows.append({"path": "both_plus_polarization", "error": repr(exc)})
    out = ROOT / ".tmp/combined/summary.json"
    out.write_text(json.dumps(rows, indent=2, default=str) + "\n")
    print(json.dumps(rows, indent=2, default=str))


if __name__ == "__main__":
    main()
