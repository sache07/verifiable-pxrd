#!/usr/bin/env python3
"""Challenge the selected profile with limited crystallographic refinements."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/profile_tests/uniaxial_100.gpx"


def set_atom_flags(phase, labels: tuple[str, ...], flag: str) -> None:
    for atom in phase.atoms():
        atom.refinement_flags = flag if atom.label in labels else ""


def run(name: str) -> dict:
    outdir = ROOT / ".tmp/structure_tests"
    outdir.mkdir(parents=True, exist_ok=True)
    outpath = outdir / f"{name}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(outpath))
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = project.histogram(0)
    mgwo4 = project.phase("MgWO4")
    wo3 = project.phase("WO3")

    # Ensure only the explicitly requested coordinates are varied.
    set_atom_flags(mgwo4, (), "")
    set_atom_flags(wo3, (), "")
    if name == "mgwo4_all_x":
        set_atom_flags(mgwo4, tuple(a.label for a in mgwo4.atoms()), "X")
    elif name == "wo3_w_x":
        set_atom_flags(wo3, ("W1", "W2"), "X")
    elif name == "wo3_all_x":
        set_atom_flags(wo3, tuple(a.label for a in wo3.atoms()), "X")
    elif name == "mgwo4_and_wo3_w_x":
        set_atom_flags(mgwo4, tuple(a.label for a in mgwo4.atoms()), "X")
        set_atom_flags(wo3, ("W1", "W2"), "X")
    else:
        raise ValueError(name)

    for _ in range(3):
        project.refine()
    project.save()
    exported = {}
    for phase in project.phases():
        path = outdir / f"{name}_{phase.name}.cif"
        phase.export_CIF(str(path))
        exported[phase.name] = str(path)

    cov = project.data["Covariance"]["data"]
    sig = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    mass = hist.ComputeMassFracs()
    return {
        "test": name,
        "gpx": str(outpath),
        "wR_percent": hist.get_wR(),
        "residuals": hist.data["data"][0].copy(),
        "mass_fractions": {
            key: {"value": val[0], "esd": val[1]} for key, val in mass.items()
        },
        "atoms": {
            phase.name: [
                {
                    "label": atom.label,
                    "xyz": list(atom.coordinates),
                    "uiso": atom.uiso,
                    "flag": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ]
            for phase in project.phases()
        },
        "atom_esds": {key: val for key, val in sig.items() if "::dA" in key},
        "vary_list": cov.get("varyList", []),
        "frozen": project.get_Frozen(),
        "cifs": exported,
    }


def main() -> None:
    rows = []
    for name in (
        "mgwo4_all_x",
        "wo3_w_x",
        "wo3_all_x",
        "mgwo4_and_wo3_w_x",
    ):
        try:
            rows.append(run(name))
        except Exception as exc:
            rows.append({"test": name, "error": repr(exc)})
    out = ROOT / ".tmp/structure_tests/summary.json"
    out.write_text(json.dumps(rows, indent=2, default=str) + "\n")
    print(json.dumps(rows, indent=2, default=str))


if __name__ == "__main__":
    main()
