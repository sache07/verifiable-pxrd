#!/usr/bin/env python3
"""Build and run restrained GSAS-II phase-inventory comparison branches."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
RESOURCE = Path(
    "<RUN>/resources/b001-c03/cif"
)


def cod_path(cod_id: str) -> Path:
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PRODUCTS = {
    "srmo": WORK / "candidates/SrWO4_from_SrMoO4_2300460.cif",
    "cawo": WORK / "candidates/SrWO4_from_CaWO4_7219229.cif",
}
CARBONATES = {"none": None, "pnma": cod_path("9008198"), "r3m": cod_path("1539128")}
WO3_MODELS = {
    "none": None,
    "p21n": cod_path("1528915"),
    "p21c": cod_path("2311041"),
    "p-1": cod_path("2106293"),
    "pnma": cod_path("2107312"),
    "small-p21c": cod_path("1563541"),
}


def neutralize_hap(phase, histogram) -> None:
    """Remove default sample broadening before any profile comparison."""
    hap = phase.data["Histograms"][histogram.name]
    hap["Size"][0] = "isotropic"
    # 10 micrometres is the GSAS-II upper bound and is effectively neutral here.
    hap["Size"][1][0] = 10.0
    hap["Size"][1][1] = 10.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Pref.Ori."][2] = False
    hap["Extinction"][1] = False
    hap["Babinet"]["BabA"][1] = False
    hap["Babinet"]["BabU"][1] = False
    hap["LeBail"] = False


def set_instrument_start(histogram) -> None:
    inst = histogram.data["Instrument Parameters"][0]
    starts = {
        "Zero": 0.0,
        "U": 0.0,
        "V": 0.0,
        "W": 52.0,
        "X": 0.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }
    for key, value in starts.items():
        inst[key][0] = value
        inst[key][1] = value
        inst[key][2] = False
    # Metadata values are fixed, including the reported K-alpha doublet ratio.
    inst["Lam1"][:2] = [1.540598, 1.540598]
    inst["Lam2"][:2] = [1.544426, 1.544426]
    inst["I(L2)/I(L1)"][:2] = [0.5, 0.5]
    inst["I(L2)/I(L1)"][2] = False


def add_phase(
    project, histogram, path: Path, name: str, initial_scale: float, refine_cell: bool = False
):
    phase = project.add_phase(str(path), phasename=name, histograms=[histogram])
    neutralize_hap(phase, histogram)
    phase.data["Histograms"][histogram.name]["Scale"] = [initial_scale, True]
    phase.data["General"]["Cell"][0] = refine_cell
    return phase


def snapshot(project, histogram, stage: str) -> dict:
    residuals = dict(histogram.data["data"][0])
    inst = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        phases[phase.name] = {
            "scale": hap["Scale"][0],
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "stage": stage,
        "residuals": {
            key: value
            for key, value in residuals.items()
            if key not in {"ranId"}
            and isinstance(value, (str, int, float, bool, type(None)))
        },
        "Rvals": copy.deepcopy(cov.get("Rvals", {})),
        "shift_micrometres": sample.get("Shift", [None])[0],
        "instrument": {key: inst[key][1] for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "phases": phases,
    }


def run_refinement(project, histogram, stage: str, log: list[dict]) -> None:
    project.refine(makeBack=False)
    log.append(snapshot(project, project.histogram(histogram.name), stage))


def configure_common_flags(project, histogram) -> None:
    histogram.data["Background"][0][1] = True
    histogram.data["Sample Parameters"]["Scale"][1] = False
    histogram.data["Sample Parameters"]["Shift"][1] = True
    histogram.data["Instrument Parameters"][0]["Zero"][2] = False
    for phase in project.phases():
        phase.data["Histograms"][histogram.name]["Scale"][1] = True


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--product", choices=PRODUCTS, default="srmo")
    parser.add_argument("--carbonate", choices=CARBONATES, default="pnma")
    parser.add_argument("--wo3", choices=WO3_MODELS, default="p21n")
    parser.add_argument("--label", required=True)
    parser.add_argument("--skip-profile", action="store_true")
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    trial_dir = WORK / "trials"
    trial_dir.mkdir(exist_ok=True)
    project_path = trial_dir / f"{args.label}.gpx"
    project = G2sc.G2Project(newgpx=str(project_path))
    project.data["Controls"]["data"].update(
        {"max cyc": 8, "min dM/M": 0.0001, "shift factor": 1.0}
    )
    histogram = project.add_powder_histogram(
        str(WORK / "inputs/pattern.csv"),
        str(WORK / "cu_ka_lab.instprm"),
        fmthint="comma",
    )
    histogram.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
                "coeffs": [1050.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            },
        }
    )
    set_instrument_start(histogram)
    histogram.data["Sample Parameters"]["Shift"] = [800.0, True]
    histogram.data["Sample Parameters"]["Scale"][1] = False

    log: list[dict] = []
    product = add_phase(
        project, histogram, PRODUCTS[args.product], "SrWO4", 1.0, refine_cell=True
    )
    configure_common_flags(project, histogram)
    run_refinement(project, histogram, "product_only", log)
    run_refinement(project, histogram, "product_only_reconverged", log)

    if CARBONATES[args.carbonate] is not None:
        carbonate = add_phase(
            project, histogram, CARBONATES[args.carbonate], "SrCO3", 0.1
        )
        configure_common_flags(project, histogram)
        run_refinement(project, histogram, "carbonate_scale_fixed_cell", log)
        carbonate = project.phase("SrCO3")
        carbonate.data["General"]["Cell"][0] = True
        run_refinement(project, project.histogram(0), "carbonate_cell_released", log)
        run_refinement(project, histogram, "carbonate_reconverged", log)

    if WO3_MODELS[args.wo3] is not None:
        wo3 = add_phase(project, histogram, WO3_MODELS[args.wo3], "WO3", 0.1)
        configure_common_flags(project, histogram)
        run_refinement(project, histogram, "wo3_scale_fixed_cell", log)
        wo3 = project.phase("WO3")
        wo3.data["General"]["Cell"][0] = True
        run_refinement(project, project.histogram(0), "wo3_cell_released", log)
        run_refinement(project, histogram, "inventory_reconverged", log)

    if not args.skip_profile:
        # Refine the low-angle Gaussian floor first. U is challenged separately
        # downstream because an unbounded U/W pair can produce nonphysical U < 0.
        inst = histogram.data["Instrument Parameters"][0]
        inst["W"][2] = True
        run_refinement(project, histogram, "profile_W", log)

    project.save(str(project_path))
    histogram = project.histogram(0)
    try:
        mass_fractions = histogram.ComputeMassFracs()
    except Exception as exc:
        mass_fractions = {"error": repr(exc)}
    result = {
        "branch": vars(args),
        "project": str(project_path),
        "stages": log,
        "mass_fractions": mass_fractions,
        "final": snapshot(project, histogram, "final"),
    }
    result_path = trial_dir / f"{args.label}.json"
    result_path.write_text(json.dumps(result, indent=2, default=float) + "\n")
    final = result["final"]
    print(
        json.dumps(
            {
                "project": result["project"],
                "wR": final["residuals"].get("wR"),
                "shift_micrometres": final["shift_micrometres"],
                "instrument": final["instrument"],
                "mass_fractions": mass_fractions,
                "cells": {name: row["cell"] for name, row in final["phases"].items()},
            },
            indent=2,
            default=float,
        )
    )


if __name__ == "__main__":
    main()
