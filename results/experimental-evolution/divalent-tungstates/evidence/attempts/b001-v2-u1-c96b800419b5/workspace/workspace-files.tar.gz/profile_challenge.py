#!/usr/bin/env python3
"""Challenge one profile/broadening term from a neutral replayed GSAS-II model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def clear_profile_flags(project, baseline_w: float, baseline_x: float) -> None:
    histogram = project.histogram(0)
    inst = histogram.data["Instrument Parameters"][0]
    for key, value in {
        "Zero": 0.0,
        "U": 0.0,
        "V": 0.0,
        "W": baseline_w,
        "X": baseline_x,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }.items():
        inst[key][1] = value
        inst[key][2] = False
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        hap["Pref.Ori."][2] = False


def top_correlations(project, limit: int = 20) -> list[dict]:
    cov = project.data["Covariance"]["data"]
    names = [str(v) for v in cov.get("varyList", [])]
    matrix = cov.get("covMatrix")
    if matrix is None or not names:
        return []
    matrix = np.asarray(matrix, float)
    sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    denom = np.outer(sigma, sigma)
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
    rows = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            rows.append(
                {"left": names[i], "right": names[j], "correlation": float(corr[i, j])}
            )
    rows.sort(key=lambda row: abs(row["correlation"]), reverse=True)
    return rows[:limit]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=Path("trials/product_alt2.gpx"))
    parser.add_argument("--label", required=True)
    parser.add_argument("--kind", choices=("W", "X", "WX", "size", "strain"), required=True)
    parser.add_argument("--phase", choices=("SrWO4", "SrCO3", "WO3"))
    parser.add_argument("--max-rounds", type=int, default=6)
    parser.add_argument("--baseline-w", type=float, default=52.0)
    parser.add_argument("--baseline-x", type=float, default=0.0)
    args = parser.parse_args()
    if args.kind in {"size", "strain"} and args.phase is None:
        parser.error("--phase is required for size/strain challenges")

    G2sc.SetPrintLevel("warn")
    output = Path("trials") / f"{args.label}.gpx"
    project = G2sc.G2Project(str(args.source), newgpx=str(output))
    project.data["Controls"]["data"].update(
        {"max cyc": 8, "min dM/M": 0.0001, "parmFrozen": {"FrozenList": []}}
    )
    clear_profile_flags(project, args.baseline_w, args.baseline_x)
    histogram = project.histogram(0)
    if args.kind in {"W", "X", "WX"}:
        for key in args.kind:
            histogram.data["Instrument Parameters"][0][key][2] = True
    else:
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][histogram.name]
        if args.kind == "size":
            hap["Size"][1][0] = 10.0
            hap["Size"][2][0] = True
        else:
            hap["Mustrain"][1][0] = 100.0
            hap["Mustrain"][2][0] = True

    project.save()
    history = []
    for iteration in range(1, args.max_rounds + 1):
        project.refine(makeBack=False)
        histogram = project.histogram(0)
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        history.append(
            {
                "iteration": iteration,
                "wR": histogram.get_wR(),
                "max_shift_over_esd": rvals.get("Max shft/sig"),
                "converged": rvals.get("converged"),
            }
        )
        if (
            history[-1]["converged"]
            and history[-1]["max_shift_over_esd"] is not None
            and history[-1]["max_shift_over_esd"] < 0.2
        ):
            break

    project.save()
    histogram = project.histogram(0)
    result = {
        "branch": {
            "source": str(args.source),
            "label": args.label,
            "kind": args.kind,
            "phase": args.phase,
            "max_rounds": args.max_rounds,
            "baseline_w": args.baseline_w,
            "baseline_x": args.baseline_x,
        },
        "project": str(output.resolve()),
        "history": history,
        "instrument": {
            key: histogram.data["Instrument Parameters"][0][key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "broadening": {
            phase.name: {
                "size": phase.data["Histograms"][histogram.name]["Size"],
                "mustrain": phase.data["Histograms"][histogram.name]["Mustrain"],
            }
            for phase in project.phases()
        },
        "mass_fractions": histogram.ComputeMassFracs(),
        "frozen": [
            str(value)
            for value in project.data["Controls"]["data"].get("parmFrozen", {}).get(
                "FrozenList", []
            )
        ],
        "top_correlations": top_correlations(project),
    }
    result_path = output.with_suffix(".challenge.json")
    result_path.write_text(json.dumps(result, indent=2, default=float) + "\n")
    print(
        json.dumps(
            {
                "label": args.label,
                "history": history,
                "instrument": result["instrument"],
                "target": None
                if args.phase is None
                else result["broadening"][args.phase],
                "frozen": result["frozen"],
                "top_correlations": result["top_correlations"][:5],
            },
            indent=2,
            default=float,
        )
    )


if __name__ == "__main__":
    main()
