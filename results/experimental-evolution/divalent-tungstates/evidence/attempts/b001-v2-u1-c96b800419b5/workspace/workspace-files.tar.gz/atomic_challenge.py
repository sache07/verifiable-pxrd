#!/usr/bin/env python3
"""Test the only structurally useful atomic refinement supported by this pattern.

The scheelite Sr and W sites are symmetry-fixed.  Oxygen is on a general site,
so its three coordinates are challenged together while the accepted modest
nuisance model is allowed to reconverge.  No occupancies or displacement
parameters are refined.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def covariance_summary(project, atom_id: int) -> dict:
    cov = project.data["Covariance"]["data"]
    names = [str(value) for value in cov.get("varyList", [])]
    values = np.asarray(cov.get("variables", []), float)
    sigmas = np.asarray(cov.get("sig", []), float)
    matrix = np.asarray(cov.get("covMatrix", []), float)
    rows = []
    atom_token = f"::A{atom_id}:"
    for index, name in enumerate(names):
        if atom_token in name:
            rows.append(
                {
                    "name": name,
                    "value": float(values[index]),
                    "esd": float(sigmas[index]),
                }
            )

    maximum = None
    if matrix.ndim == 2 and len(names) == matrix.shape[0]:
        sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
        denom = np.outer(sigma, sigma)
        corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
        atom_indices = [i for i, name in enumerate(names) if atom_token in name]
        pairs = []
        for i in atom_indices:
            for j in range(len(names)):
                if i != j:
                    pairs.append((abs(float(corr[i, j])), names[i], names[j], float(corr[i, j])))
        if pairs:
            _, left, right, value = max(pairs)
            maximum = {"left": left, "right": right, "correlation": value}
    return {"parameters": rows, "maximum_coordinate_correlation": maximum}


def refine_to_convergence(project, rounds: int = 8) -> list[dict]:
    history = []
    for iteration in range(1, rounds + 1):
        project.refine(makeBack=False)
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        row = {
            "iteration": iteration,
            "Rwp_percent": project.histogram(0).get_wR(),
            "max_shift_over_esd": rvals.get("Max shft/sig"),
            "converged": rvals.get("converged"),
        }
        history.append(row)
        if row["converged"] and row["max_shift_over_esd"] is not None and row["max_shift_over_esd"] < 0.2:
            break
    return history


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=Path("trials/accepted_profile_joint.gpx"))
    parser.add_argument("--output", type=Path, default=Path("trials/atomic_srwo4_o.gpx"))
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
    project.data["Controls"]["data"].update(
        {"max cyc": 8, "min dM/M": 0.0001, "parmFrozen": {"FrozenList": []}}
    )
    histogram = project.histogram(0)
    before = {
        "Rwp_percent": histogram.get_wR(),
        "coordinates": list(project.phase("SrWO4").atom("O1").coordinates),
    }

    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    oxygen = project.phase("SrWO4").atom("O1")
    oxygen.refinement_flags = "X"
    project.save()

    history = refine_to_convergence(project)
    project.save()
    result = {
        "source": str(args.source.resolve()),
        "project": str(args.output.resolve()),
        "before": before,
        "after": {
            "Rwp_percent": project.histogram(0).get_wR(),
            "coordinates": list(oxygen.coordinates),
        },
        "history": history,
        "covariance": covariance_summary(project, oxygen.ranId),
        "frozen": [
            str(value)
            for value in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])
        ],
    }
    args.output.with_suffix(".atomic.json").write_text(
        json.dumps(result, indent=2, default=float) + "\n"
    )
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
