#!/usr/bin/env python3
"""Assemble and covariance-check the accepted common and WO3 profile terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def correlations(project) -> list[dict]:
    cov = project.data["Covariance"]["data"]
    names = [str(value) for value in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix"), float)
    if matrix.ndim != 2 or not names:
        return []
    sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    denominator = np.outer(sigma, sigma)
    matrix = np.divide(matrix, denominator, out=np.zeros_like(matrix), where=denominator > 0)
    rows = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            rows.append(
                {"left": names[i], "right": names[j], "correlation": float(matrix[i, j])}
            )
    rows.sort(key=lambda row: abs(row["correlation"]), reverse=True)
    return rows


def refine_to_convergence(project, label: str, history: list[dict], rounds: int = 6) -> None:
    for iteration in range(1, rounds + 1):
        project.refine(makeBack=False)
        histogram = project.histogram(0)
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        row = {
            "stage": label,
            "iteration": iteration,
            "wR": histogram.get_wR(),
            "max_shift_over_esd": rvals.get("Max shft/sig"),
            "converged": rvals.get("converged"),
        }
        history.append(row)
        if (
            row["converged"]
            and row["max_shift_over_esd"] is not None
            and row["max_shift_over_esd"] < 0.2
        ):
            break


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=Path("trials/prof_final_common.gpx"))
    parser.add_argument("--output", type=Path, default=Path("trials/accepted_profile.gpx"))
    parser.add_argument("--joint", action="store_true")
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
    project.data["Controls"]["data"].update(
        {"max cyc": 8, "min dM/M": 0.0001, "parmFrozen": {"FrozenList": []}}
    )
    histogram = project.histogram(0)
    instrument = histogram.data["Instrument Parameters"][0]
    for key, value in {
        "Zero": 0.0,
        "U": 0.0,
        "V": 0.0,
        "W": 42.0,
        "X": 4.306554156346219,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }.items():
        instrument[key][1] = value
        instrument[key][2] = False

    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        hap["Pref.Ori."][2] = False

    wo3_hap = project.phase("WO3").data["Histograms"][histogram.name]
    wo3_hap["Mustrain"][1][0] = 3773.0
    wo3_hap["Mustrain"][2][0] = True
    project.save()
    history: list[dict] = []

    # Alternate terms so each is supported after the other is present.
    refine_to_convergence(project, "wo3_strain", history)
    histogram = project.histogram(0)
    wo3_hap = project.phase("WO3").data["Histograms"][histogram.name]
    wo3_hap["Mustrain"][2][0] = False
    histogram.data["Instrument Parameters"][0]["X"][2] = True
    refine_to_convergence(project, "common_X", history)
    histogram = project.histogram(0)
    histogram.data["Instrument Parameters"][0]["X"][2] = False
    wo3_hap = project.phase("WO3").data["Histograms"][histogram.name]
    wo3_hap["Mustrain"][2][0] = True
    refine_to_convergence(project, "wo3_strain_recheck", history)

    if args.joint:
        histogram = project.histogram(0)
        histogram.data["Instrument Parameters"][0]["X"][2] = True
        project.phase("WO3").data["Histograms"][histogram.name]["Mustrain"][2][0] = True
        refine_to_convergence(project, "joint_X_strain", history)

    project.save()
    histogram = project.histogram(0)
    result = {
        "project": str(args.output.resolve()),
        "history": history,
        "instrument": {
            key: histogram.data["Instrument Parameters"][0][key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "wo3_mustrain": project.phase("WO3").data["Histograms"][histogram.name][
            "Mustrain"
        ],
        "mass_fractions": histogram.ComputeMassFracs(),
        "top_correlations": correlations(project)[:25],
        "frozen": [
            str(value)
            for value in project.data["Controls"]["data"].get("parmFrozen", {}).get(
                "FrozenList", []
            )
        ],
    }
    args.output.with_suffix(".profile.json").write_text(
        json.dumps(result, indent=2, default=float) + "\n"
    )
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
