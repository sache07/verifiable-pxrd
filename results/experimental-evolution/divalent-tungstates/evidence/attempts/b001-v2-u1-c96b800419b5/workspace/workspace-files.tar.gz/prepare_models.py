#!/usr/bin/env python3
"""Create chemically adapted prototype CIFs used in refinement trials."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path("<RUN>/resources/b001-c03/cif")
OUT = Path("candidates")


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def substitute(cod_id: str, mapping: dict[str, str], output: str) -> None:
    structure = Structure.from_file(cod_path(cod_id))
    structure.replace_species(mapping)
    CifWriter(structure, symprec=0.02, refine_struct=False).write_file(OUT / output)


def main() -> None:
    OUT.mkdir(exist_ok=True)
    # Ordered, ambient-temperature scheelite parents selected after CIF audit.
    substitute("2300460", {"Mo": "W"}, "SrWO4_from_SrMoO4_2300460.cif")
    # The CaWO4 parent cell is too small for Sr and causes a numerical cell
    # collapse before its scale can be established. Retain its fractional
    # coordinates, but initialize the Sr-adapted model on the ordered SrMoO4
    # scheelite lattice (same space group and ambient-temperature topology).
    calcium_parent = Structure.from_file(cod_path("7219229"))
    calcium_parent.replace_species({"Ca": "Sr"})
    sr_lattice_parent = Structure.from_file(cod_path("2300460"))
    calcium_parent.lattice = Lattice.tetragonal(
        sr_lattice_parent.lattice.a, sr_lattice_parent.lattice.c
    )
    CifWriter(calcium_parent, symprec=0.02, refine_struct=False).write_file(
        OUT / "SrWO4_from_CaWO4_7219229.cif"
    )


if __name__ == "__main__":
    main()
