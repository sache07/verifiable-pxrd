#!/usr/bin/env python3
"""Audit local CIF candidates and compare their Cu K-alpha1 stick patterns."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.analysis.local_env import MinimumDistanceNN
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
from scipy.ndimage import gaussian_filter1d, percentile_filter
from scipy.signal import find_peaks


def audit(path: Path) -> dict:
    structure = Structure.from_file(path)
    sga = SpacegroupAnalyzer(structure, symprec=0.02, angle_tolerance=2)
    distances = structure.distance_matrix.copy()
    distances[distances < 1e-8] = np.inf
    partial = []
    for i, site in enumerate(structure):
        if len(site.species) != 1 or abs(sum(site.species.values()) - 1.0) > 1e-5:
            partial.append({"site": i, "species": str(site.species)})
    try:
        neighbors = MinimumDistanceNN(tol=0.15, cutoff=4.0)
        coordination = []
        for i, site in enumerate(structure):
            if str(site.specie) != "O":
                info = neighbors.get_nn_info(structure, i)
                coordination.append(
                    {
                        "site": i,
                        "element": str(site.specie),
                        "cn": len(info),
                        "distances": sorted(
                            round(float(structure.get_distance(i, row["site_index"], row["image"])), 4)
                            for row in info
                        ),
                    }
                )
    except Exception as exc:
        coordination = [{"error": repr(exc)}]
    pattern = XRDCalculator(wavelength=1.540598).get_pattern(
        structure, two_theta_range=(9.9, 100.1)
    )
    top = sorted(zip(pattern.x, pattern.y, pattern.hkls), key=lambda row: row[1], reverse=True)[:30]
    return {
        "path": str(path),
        "composition": str(structure.composition),
        "reduced_formula": structure.composition.reduced_formula,
        "n_sites": len(structure),
        "space_group_detected": [sga.get_space_group_symbol(), sga.get_space_group_number()],
        "cell": [round(v, 6) for v in (*structure.lattice.abc, *structure.lattice.angles)],
        "volume": round(structure.volume, 6),
        "density_g_cm3": round(structure.density, 6),
        "partial_or_disordered_sites": partial,
        "minimum_periodic_distance_A": round(float(np.min(distances)), 5),
        "coordination": coordination,
        "top_reflections": [
            {
                "two_theta": round(float(tt), 5),
                "relative_intensity": round(float(ii), 3),
                "hkl": [entry["hkl"] for entry in hkls],
            }
            for tt, ii, hkls in top
        ],
    }


def observed_peaks(pattern_path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    frame = pd.read_csv(pattern_path)
    x = frame.iloc[:, 0].to_numpy(float)
    y = frame.iloc[:, 1].to_numpy(float)
    smoothed = gaussian_filter1d(y, 1.3)
    baseline = percentile_filter(smoothed, percentile=20, size=401, mode="nearest")
    net = smoothed - baseline
    peaks, props = find_peaks(net, prominence=120, distance=7, width=2)
    order = np.argsort(props["prominences"])[::-1]
    return x[peaks][order], net[peaks][order], props["prominences"][order]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("cifs", type=Path, nargs="+")
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--compact", action="store_true")
    args = parser.parse_args()
    obs_x, obs_i, obs_p = observed_peaks(args.pattern)
    reports = []
    for path in args.cifs:
        try:
            report = audit(path)
        except Exception as exc:
            reports.append({"path": str(path), "error": repr(exc)})
            continue
        # Diagnostic nearest-observed differences for the 15 strongest calculated lines.
        diagnostics = []
        for line in report["top_reflections"][:15]:
            delta = obs_x - line["two_theta"]
            j = int(np.argmin(abs(delta)))
            diagnostics.append(
                {
                    "calc": line["two_theta"],
                    "obs": round(float(obs_x[j]), 5),
                    "delta_obs_minus_calc": round(float(delta[j]), 5),
                    "obs_net": round(float(obs_i[j]), 2),
                    "obs_prominence": round(float(obs_p[j]), 2),
                    "calc_relative_intensity": line["relative_intensity"],
                    "hkl": line["hkl"],
                }
            )
        report["diagnostic_matches"] = diagnostics
        if args.compact:
            unique_coordination = []
            seen_coordination = set()
            for row in report["coordination"]:
                signature = (row.get("element"), row.get("cn"), tuple(row.get("distances", [])))
                if signature not in seen_coordination:
                    seen_coordination.add(signature)
                    unique_coordination.append(row)
            report = {
                key: report[key]
                for key in (
                    "path",
                    "composition",
                    "reduced_formula",
                    "n_sites",
                    "space_group_detected",
                    "cell",
                    "volume",
                    "density_g_cm3",
                    "partial_or_disordered_sites",
                    "minimum_periodic_distance_A",
                    "diagnostic_matches",
                )
            }
            report["unique_coordination"] = unique_coordination
        reports.append(report)
    print(json.dumps(reports, indent=2))


if __name__ == "__main__":
    main()
