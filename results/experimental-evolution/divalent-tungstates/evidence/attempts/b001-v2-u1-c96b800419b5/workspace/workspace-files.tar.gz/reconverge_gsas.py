#!/usr/bin/env python3
"""Continue a GSAS-II branch until its reported maximum shift/esd is small."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("--max-rounds", type=int, default=8)
    parser.add_argument("--threshold", type=float, default=0.2)
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(args.project))
    project.data["Controls"]["data"].update({"max cyc": 8, "min dM/M": 0.0001})
    history = []
    for iteration in range(1, args.max_rounds + 1):
        project.refine(makeBack=False)
        histogram = project.histogram(0)
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        row = {
            "iteration": iteration,
            "wR": histogram.get_wR(),
            "max_shift_over_esd": rvals.get("Max shft/sig"),
            "converged": rvals.get("converged"),
            "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        }
        history.append(row)
        max_shift = row["max_shift_over_esd"]
        if row["converged"] and max_shift is not None and max_shift < args.threshold:
            break
    project.save()
    histogram = project.histogram(0)
    result = {
        "project": str(args.project.resolve()),
        "history": history,
        "mass_fractions": histogram.ComputeMassFracs(),
        "instrument": {
            key: histogram.data["Instrument Parameters"][0][key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "shift_micrometres": histogram.data["Sample Parameters"]["Shift"][0],
    }
    output = args.project.with_suffix(".reconverged.json")
    output.write_text(json.dumps(result, indent=2, default=float) + "\n")
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
