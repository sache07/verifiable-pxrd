#!/usr/bin/env python3
"""Create and replay-check the final GSAS-II project and exported results.

All submitted numerical artifacts are written from a project reopened after a
fresh full-range native Rietveld refinement.  Atomic coordinates, occupancies,
and displacement parameters remain fixed because the only useful coordinate
challenge produced chemically invalid SrWO4 geometry.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
SOURCE = WORK / "trials" / "accepted_profile_joint.gpx"
FINAL = WORK / "final.gpx"
PHASE_INFO = {
    "SrWO4": {"formula": "SrWO4", "cif": "SrWO4.cif"},
    "SrCO3": {"formula": "SrCO3", "cif": "SrCO3.cif"},
    "WO3": {"formula": "WO3", "cif": "WO3.cif"},
}


def configure_final_model(project) -> None:
    """Prune unused terms and enforce the accepted low-dimensional model."""
    project.data["Controls"]["data"].update(
        {
            "max cyc": 8,
            "min dM/M": 0.0001,
            "shift factor": 1.0,
            "parmFrozen": {"FrozenList": []},
        }
    )
    histogram = project.histogram(0)
    observed_range = list(histogram.data["Limits"][0])
    histogram.set_refinements({"Limits": observed_range})
    histogram.data["Limits"][1] = observed_range
    histogram.data["Background"][0][1] = True
    histogram.data["Sample Parameters"]["Scale"][1] = False
    histogram.data["Sample Parameters"]["Shift"][1] = True

    instrument = histogram.data["Instrument Parameters"][0]
    # Displacement is used for the angle-dependent offset; zero is not
    # co-refined. W is the sharp-phase lower-envelope baseline. X is the only
    # common-width term refined in the accepted branch.
    for key, value, refine in (
        ("Zero", 0.0, False),
        ("U", 0.0, False),
        ("V", 0.0, False),
        ("W", 42.0, False),
        ("X", float(instrument["X"][1]), True),
        ("Y", 0.0, False),
        ("Z", 0.0, False),
        ("SH/L", 0.002, False),
    ):
        instrument[key][1] = value
        instrument[key][2] = refine

    for phase in project.phases():
        phase.data["General"]["doPawley"] = False
        phase.data["General"]["Cell"][0] = True
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][histogram.name]
        hap["LeBail"] = False
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        hap["Pref.Ori."][2] = False
        if phase.name == "WO3":
            # Positive, reproducible broadening with a distinct angular
            # signature. It is jointly refined with common X.
            hap["Mustrain"][1][0] = max(float(hap["Mustrain"][1][0]), 1.0)
            hap["Mustrain"][2][0] = True
        else:
            hap["Mustrain"][1][0] = 0.0


def refine_to_convergence(project, stage: str, history: list[dict], rounds: int = 8) -> None:
    for iteration in range(1, rounds + 1):
        project.refine(makeBack=False)
        histogram = project.histogram(0)
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        row = {
            "stage": stage,
            "iteration": iteration,
            "Rwp_percent": float(histogram.get_wR()),
            "max_shift_over_esd": rvals.get("Max shft/sig"),
            "converged": bool(rvals.get("converged", False)),
            "limits_deg_2theta": list(histogram.data["Limits"][1]),
        }
        history.append(row)
        if (
            row["converged"]
            and row["max_shift_over_esd"] is not None
            and row["max_shift_over_esd"] < 0.2
        ):
            return
    raise RuntimeError(f"{stage} did not reconverge in {rounds} refinement calls")


def model_snapshot(project) -> dict:
    histogram = project.histogram(0)
    instrument = histogram.data["Instrument Parameters"][0]
    return {
        "Rwp_percent": float(histogram.get_wR()),
        "limits_deg_2theta": list(histogram.data["Limits"][1]),
        "instrument": {
            key: {"value": float(instrument[key][1]), "refined": bool(instrument[key][2])}
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample_displacement_micrometres": float(
            histogram.data["Sample Parameters"]["Shift"][0]
        ),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "mass_fractions": histogram.ComputeMassFracs(),
        "wo3_microstrain": float(
            project.phase("WO3").data["Histograms"][histogram.name]["Mustrain"][1][0]
        ),
        "le_bail": {
            phase.name: bool(phase.data["Histograms"][histogram.name].get("LeBail", False))
            for phase in project.phases()
        },
        "atomic_refinement_flags": {
            phase.name: {atom.label: atom.refinement_flags for atom in phase.atoms()}
            for phase in project.phases()
        },
        "frozen": [
            str(value)
            for value in project.data["Controls"]["data"].get("parmFrozen", {}).get(
                "FrozenList", []
            )
        ],
    }


def export_results(project) -> dict:
    histogram = project.histogram(0)
    fractions = histogram.ComputeMassFracs()
    phase_rows = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        cif_path = WORK / info["cif"]
        phase.export_CIF(str(cif_path))
        fraction, esd = fractions[phase.name]
        phase_rows.append(
            {
                "name": phase.name,
                "formula": info["formula"],
                "cif_path": info["cif"],
                "weight_fraction": float(fraction),
                "weight_fraction_esd": float(esd),
            }
        )

    powder = histogram.data["data"][1]
    x = np.asarray(powder[0], float)
    observed = np.asarray(powder[1], float)
    calculated = np.asarray(powder[3], float)
    difference = observed - calculated
    with (WORK / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
        for row in zip(x, observed, calculated, difference):
            writer.writerow([f"{row[0]:.8f}", f"{row[1]:.8f}", f"{row[2]:.8f}", f"{row[3]:.8f}"])

    summary = histogram.data["data"][0]
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    result = {
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": float(summary["wR"]),
            "Rp_percent": float(summary["R"]),
            "Rexp_percent": float(summary["wRmin"]),
            "GOF": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "Nobs": int(rvals["Nobs"]),
            "Nvars": int(rvals["Nvars"]),
        },
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over modeled crystalline phases",
    }
    (WORK / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    history: list[dict] = []

    # Assemble the clean final branch and reconverge after changing to the
    # complete measured angular range.
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    configure_final_model(project)
    project.save()
    refine_to_convergence(project, "full_range_reconvergence", history)
    project.save()
    assembled = model_snapshot(project)

    # Required replay: close/reopen, enforce native atomic Rietveld mode, and
    # refine again over the full range. This recomputes the profile rather than
    # trusting arrays stored by the profile challenge branch.
    project = G2sc.G2Project(str(FINAL))
    configure_final_model(project)
    refine_to_convergence(project, "reopened_native_atomic_replay", history)
    project.save()
    replayed = model_snapshot(project)

    # Export only from another reopen of the replay-checked project.
    project = G2sc.G2Project(str(FINAL))
    final_snapshot = model_snapshot(project)
    result = export_results(project)
    audit = {
        "source": str(SOURCE),
        "project": str(FINAL),
        "history": history,
        "assembled_before_reopen": assembled,
        "after_native_replay": replayed,
        "export_reopen": final_snapshot,
        "result": result,
    }
    (WORK / "final_replay.json").write_text(json.dumps(audit, indent=2, default=float) + "\n")
    print(json.dumps(audit, indent=2, default=float))


if __name__ == "__main__":
    main()
