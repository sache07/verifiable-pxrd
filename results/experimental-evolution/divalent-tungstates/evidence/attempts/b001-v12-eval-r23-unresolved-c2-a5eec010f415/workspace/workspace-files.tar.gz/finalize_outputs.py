#!/usr/bin/env python3
"""Freeze, reopen, replay and export the submitted GSAS-II model."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")

SOURCE = Path(".tmp/final_model.gpx")
PROJECT = Path("final.gpx")
CIF_PATHS = {
    "SrWO4": Path("phase_1_SrWO4.cif"),
    "WO3": Path("phase_2_WO3.cif"),
    "SrCO3": Path("phase_3_SrCO3.cif"),
}


def validate(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    if project.get_Frozen():
        raise RuntimeError(f"frozen parameters remain: {project.get_Frozen()}")
    if list(hist.data["Limits"][1]) != list(hist.data["Limits"][0]):
        raise RuntimeError("histogram is not using the complete measured range")
    for key in ("U", "W", "X"):
        value = float(hist.InstrumentParameters[key][1])
        if not math.isfinite(value) or value < 0.0:
            raise RuntimeError(f"invalid profile term {key}={value}")
    for phase in project.phases():
        scale = float(phase.HAPvalue("Scale", targethistlist=[0]))
        if not math.isfinite(scale) or scale <= 0.0:
            raise RuntimeError(f"invalid scale for {phase.name}: {scale}")
        hap = phase.data["Histograms"][hist.name]
        if phase.name != "WO3" and (
            float(hap["Size"][1][0]) < 9.999
            or float(hap["Mustrain"][1][0]) != 0.0
        ):
            raise RuntimeError(f"inactive broadening is not neutral for {phase.name}")


def replay() -> G2.G2Project:
    project = G2.G2Project(str(SOURCE), newgpx=str(PROJECT))
    hist = project.histogram(0)
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["shift factor"] = 1.0
    project.do_refinements([{}])
    project.save()

    # Reopen the serialized state and replay once more over the full range.
    project = G2.G2Project(str(PROJECT))
    project.histogram(0).data["Limits"][1] = list(
        project.histogram(0).data["Limits"][0]
    )
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["shift factor"] = 1.0
    project.do_refinements([{}])
    project.save()
    validate(project)
    return project


def main() -> None:
    project = replay()
    hist = project.histogram(0)
    mass_fracs = hist.ComputeMassFracs()
    fractions = {name: float(value[0]) for name, value in mass_fracs.items()}
    total = sum(fractions.values())
    fractions = {name: value / total for name, value in fractions.items()}
    if not math.isclose(sum(fractions.values()), 1.0, rel_tol=0.0, abs_tol=1.0e-12):
        raise RuntimeError("normalized phase fractions do not sum to one")

    phase_results = []
    for phase in project.phases():
        cif_path = CIF_PATHS[phase.name]
        phase.export_CIF(str(cif_path))
        cell = {key: float(value) for key, value in phase.get_cell().items()}
        phase_results.append(
            {
                "name": phase.name,
                "formula": phase.name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": str(cif_path),
                "project_path": str(PROJECT),
                "weight_fraction": fractions[phase.name],
                "cell": cell,
            }
        )

    arrays = np.asarray(hist.data["data"][1], dtype=float)
    x, observed, _weight, calculated, background, _stored_difference = arrays
    difference = observed - calculated
    np.savetxt(
        "fit.csv",
        np.column_stack((x, observed, calculated, difference, background)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
        fmt="%.10g",
    )

    residuals = hist.residuals
    rwp = float(residuals["wR"])
    rexp = float(residuals["wRmin"])
    result = {
        "phases": phase_results,
        "project_path": str(PROJECT),
        "fit_path": "fit.csv",
        "crystalline_weight_fraction_sum": sum(
            phase["weight_fraction"] for phase in phase_results
        ),
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": float(residuals["R"]),
            "RBragg_percent": float(residuals["Rb"]),
            "weighted_RBragg_percent": float(residuals["wRb"]),
            "Rexp_percent": rexp,
            "goodness_of_fit": rwp / rexp,
            "reduced_chi_squared": (rwp / rexp) ** 2,
            "data_points": int(len(x)),
            "two_theta_min_deg": float(x[0]),
            "two_theta_max_deg": float(x[-1]),
        },
        "weighting": "Poisson approximation sigma=sqrt(max(counts,1)); no pointwise uncertainties were supplied",
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
