#!/usr/bin/env python3
"""Replay-stable background, polarization, roughness and MD texture trials."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import gsas_trials as trials


G2.SetPrintLevel("warn")


def reset_texture(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = False
        po[3] = [0, 0, 1]
        po[4] = 0
        po[5] = {}


def fractions(project: G2.G2Project) -> dict[str, float]:
    values = project.histogram(0).ComputeMassFracs()
    return {name: float(value[0]) for name, value in values.items()}


def snapshot(project: G2.G2Project, args: argparse.Namespace) -> dict:
    hist = project.histogram(0)
    data = {
        "wR": float(hist.residuals.get("wR", math.nan)),
        "R": float(hist.residuals.get("R", math.nan)),
        "wRmin": float(hist.residuals.get("wRmin", math.nan)),
        "fractions": fractions(project),
        "zero": float(hist.InstrumentParameters["Zero"][1]),
        "W": float(hist.InstrumentParameters["W"][1]),
        "X": float(hist.InstrumentParameters["X"][1]),
        "U": float(hist.InstrumentParameters["U"][1]),
        "polarization": float(hist.InstrumentParameters["Polariz."][1]),
        "background": [float(v) if isinstance(v, (float, int)) else v for v in hist.Background[0]],
        "roughness_A": float(hist.data["Sample Parameters"]["SurfRoughA"][0]),
        "roughness_B": float(hist.data["Sample Parameters"]["SurfRoughB"][0]),
        "frozen": project.get_Frozen(),
    }
    if args.kind == "texture":
        po = project.phase(args.phase).data["Histograms"][hist.name]["Pref.Ori."]
        data["md_ratio"] = float(po[1])
        data["md_axis"] = list(po[3])
    return data


def configure(project: G2.G2Project, args: argparse.Namespace) -> None:
    hist = project.histogram(0)
    sample = hist.data["Sample Parameters"]
    if not args.preserve_roughness:
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.0, False]
    hist.InstrumentParameters["Polariz."][2] = False
    hist.InstrumentParameters["U"][2] = False
    if not args.preserve_texture:
        reset_texture(project)

    if args.kind == "background":
        hist.set_refinements(
            {
                "Background": {
                    "type": "chebyschev-1",
                    "refine": True,
                    "no. coeffs": args.order,
                }
            }
        )
    elif args.kind == "polarization":
        hist.InstrumentParameters["Polariz."][2] = True
    elif args.kind == "rough_b":
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.02, True]
    elif args.kind == "rough_ab":
        sample["SurfRoughA"] = [0.5, True]
        sample["SurfRoughB"] = [0.02, True]
    elif args.kind == "polar_rough_b":
        hist.InstrumentParameters["Polariz."][2] = True
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.02, True]
    elif args.kind == "instrument_u":
        hist.InstrumentParameters["U"][1] = 1.0
        hist.InstrumentParameters["U"][2] = True
    elif args.kind == "texture":
        po = project.phase(args.phase).data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = args.ratio
        po[2] = True
        po[3] = list(args.axis)


def validate(project: G2.G2Project, args: argparse.Namespace) -> tuple[bool, str]:
    hist = project.histogram(0)
    wr = float(hist.residuals.get("wR", math.nan))
    if not math.isfinite(wr) or wr >= 99.0:
        return False, "invalid residual"
    for key in ("U", "W", "X"):
        value = float(hist.InstrumentParameters[key][1])
        if not math.isfinite(value) or value < 0.0:
            return False, f"common profile {key} became negative"
    for phase in project.phases():
        scale = float(phase.HAPvalue("Scale", targethistlist=[0]))
        if not math.isfinite(scale) or scale <= 0.0:
            return False, f"{phase.name} scale collapsed"
    if args.kind in ("polarization", "polar_rough_b"):
        value = float(hist.InstrumentParameters["Polariz."][1])
        if not (0.005 < value < 0.995):
            return False, "polarization became nonphysical or reached a bound"
    if args.kind == "instrument_u":
        value = float(hist.InstrumentParameters["U"][1])
        if not math.isfinite(value) or value <= 1.0e-6:
            return False, "U collapsed or became nonphysical"
    if args.kind in ("rough_b", "polar_rough_b"):
        value = float(hist.data["Sample Parameters"]["SurfRoughB"][0])
        if not math.isfinite(value) or value <= 1.0e-6:
            return False, "roughness B collapsed or became nonphysical"
    elif args.kind == "rough_ab":
        a = float(hist.data["Sample Parameters"]["SurfRoughA"][0])
        b = float(hist.data["Sample Parameters"]["SurfRoughB"][0])
        if not (0.0 < a < 1.0) or not math.isfinite(b) or b <= 1.0e-6:
            return False, "roughness became nonphysical or reached a bound"
    elif args.kind == "texture":
        po = project.phase(args.phase).data["Histograms"][hist.name]["Pref.Ori."]
        ratio = float(po[1])
        if not math.isfinite(ratio) or not (0.011 < ratio < 99.0):
            return False, "March ratio became nonphysical or reached a bound"
    return True, "valid"


def stable(first: dict, second: dict, args: argparse.Namespace) -> tuple[bool, str]:
    for name, value in first["fractions"].items():
        if abs(second["fractions"][name] - value) > 0.005:
            return False, f"{name} fraction was not replay-stable"
    key = {
        "polarization": "polarization",
        "rough_b": "roughness_B",
        "texture": "md_ratio",
        "instrument_u": "U",
    }.get(args.kind)
    if key is not None:
        a, b = first[key], second[key]
        if abs(a - b) > max(0.05 * abs(a), 0.002):
            return False, f"{key} was not replay-stable"
    if args.kind == "rough_ab":
        for key in ("roughness_A", "roughness_B"):
            a, b = first[key], second[key]
            if abs(a - b) > max(0.05 * abs(a), 0.002):
                return False, f"{key} was not replay-stable"
    if args.kind == "polar_rough_b":
        for key in ("polarization", "roughness_B"):
            a, b = first[key], second[key]
            if abs(a - b) > max(0.05 * abs(a), 0.002):
                return False, f"{key} was not replay-stable"
    return True, "stable"


def parse_axis(value: str) -> list[int]:
    try:
        axis = [int(part) for part in value.split(",")]
    except ValueError as exc:
        raise argparse.ArgumentTypeError("axis must be h,k,l") from exc
    if len(axis) != 3 or axis == [0, 0, 0]:
        raise argparse.ArgumentTypeError("axis must be three nonzero-index integers")
    return axis


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "kind",
        choices=(
            "background",
            "polarization",
            "rough_b",
            "rough_ab",
            "polar_rough_b",
            "instrument_u",
            "texture",
        ),
    )
    parser.add_argument("--order", type=int, default=6)
    parser.add_argument("--phase")
    parser.add_argument("--axis", type=parse_axis, default=[0, 0, 1])
    parser.add_argument("--ratio", type=float, default=0.9)
    parser.add_argument("--preserve-texture", action="store_true")
    parser.add_argument("--preserve-roughness", action="store_true")
    args = parser.parse_args()
    if args.kind == "texture" and args.phase is None:
        parser.error("texture requires --phase")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(args.baseline), newgpx=str(args.output))
    configure(project, args)
    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["shift factor"] = 0.5
    project.save()
    project.do_refinements([{}])
    first = snapshot(project, args)
    first_valid, first_reason = validate(project, args)

    replay_valid = False
    replay_reason = "first pass invalid"
    second = first
    if first_valid:
        checkpoint = args.output.with_name(args.output.stem + "_checkpoint.gpx")
        project.save(str(checkpoint))
        project.set_Controls("cycles", 12)
        project.data["Controls"]["data"]["shift factor"] = 1.0
        project.do_refinements([{}])
        second = snapshot(project, args)
        replay_valid, replay_reason = validate(project, args)
        if replay_valid:
            replay_valid, replay_reason = stable(first, second, args)

    accepted_trial = first_valid and replay_valid
    if accepted_trial:
        project.save(str(args.output))
    else:
        project = G2.G2Project(str(args.baseline), newgpx=str(args.output))
        project.save()

    print(
        json.dumps(
            {
                "baseline": str(args.baseline),
                "kind": args.kind,
                "phase": args.phase,
                "axis": args.axis if args.kind == "texture" else None,
                "order": args.order if args.kind == "background" else None,
                "first_valid": first_valid,
                "first_reason": first_reason,
                "replay_valid": replay_valid,
                "replay_reason": replay_reason,
                "accepted_trial": accepted_trial,
                "first": first,
                "replay": second,
                "submitted": snapshot(project, args),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
