#!/usr/bin/env python3
"""Reversible phase-broadening challenges from one common GSAS-II checkpoint."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import gsas_trials as trials


G2.SetPrintLevel("warn")


def reset_widths(project: G2.G2Project, target: str | None = None) -> None:
    """Make all phase-specific profile terms genuinely neutral."""
    hist = project.histogram(0)
    for phase in project.phases():
        if target is not None and phase.name != target:
            continue
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 1000.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])


def activate(project: G2.G2Project, phase_name: str, mode: str) -> None:
    hist = project.histogram(0)
    hap = project.phase(phase_name).data["Histograms"][hist.name]
    if mode in ("size", "combined"):
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
    if mode in ("strain", "combined"):
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2][0] = True


def snapshot(project: G2.G2Project, phase_name: str) -> dict:
    summary = trials.summarize(project)
    hist = project.histogram(0)
    hap = project.phase(phase_name).data["Histograms"][hist.name]
    return {
        "wR": summary["residuals"].get("wR"),
        "R": summary["residuals"].get("R"),
        "wRmin": summary["residuals"].get("wRmin"),
        "instrument": summary["instrument"],
        "fractions": {
            phase["name"]: phase["mass_fraction"] for phase in summary["phases"]
        },
        "target_size_um": float(hap["Size"][1][0]),
        "target_mustrain": float(hap["Mustrain"][1][0]),
        "size_refined": bool(hap["Size"][2][0]),
        "mustrain_refined": bool(hap["Mustrain"][2][0]),
        "frozen": summary["frozen"],
    }


def finite_positive(value: float) -> bool:
    return math.isfinite(float(value)) and float(value) > 0.0


def validate(project: G2.G2Project, phase_name: str, mode: str) -> tuple[bool, str]:
    hist = project.histogram(0)
    wr = float(hist.residuals.get("wR", math.nan))
    if not math.isfinite(wr) or wr >= 99.0:
        return False, "invalid residual"
    for key in ("U", "W", "X"):
        value = float(hist.InstrumentParameters[key][1])
        if not math.isfinite(value) or value < 0.0:
            return False, f"common profile {key} became negative"
    for phase in project.phases():
        if not finite_positive(phase.HAPvalue("Scale", targethistlist=[0])):
            return False, f"{phase.name} scale collapsed"
    hap = project.phase(phase_name).data["Histograms"][hist.name]
    if mode in ("size", "combined"):
        size = float(hap["Size"][1][0])
        if not math.isfinite(size) or size <= 0.0011 or size >= 9.999:
            return False, "size collapsed or reached a bound"
    if mode in ("strain", "combined"):
        strain = float(hap["Mustrain"][1][0])
        if not math.isfinite(strain) or strain <= 0.01 or strain >= 9999.0:
            return False, "microstrain collapsed or reached a bound"
    return True, "valid"


def replay_stable(before: dict, after: dict, mode: str) -> tuple[bool, str]:
    if mode in ("size", "combined"):
        a, b = before["target_size_um"], after["target_size_um"]
        if abs(a - b) > max(0.05 * abs(a), 0.005):
            return False, "size was not replay-stable"
    if mode in ("strain", "combined"):
        a, b = before["target_mustrain"], after["target_mustrain"]
        if abs(a - b) > max(0.05 * abs(a), 1.0):
            return False, "microstrain was not replay-stable"
    for name, value in before["fractions"].items():
        if abs(float(after["fractions"][name]) - float(value)) > 0.005:
            return False, f"{name} fraction was not replay-stable"
    return True, "stable"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("mode", choices=("neutral", "size", "strain", "combined"))
    parser.add_argument("--preserve-other-widths", action="store_true")
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(args.baseline), newgpx=str(args.output))
    if args.phase not in [phase.name for phase in project.phases()]:
        parser.error(f"unknown phase {args.phase!r}")
    reset_widths(project, args.phase if args.preserve_other_widths else None)
    activate(project, args.phase, args.mode)
    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["shift factor"] = 0.5
    project.save()
    project.do_refinements([{}])
    first = snapshot(project, args.phase)
    first_valid, first_reason = validate(project, args.phase, args.mode)

    replay_valid = False
    replay_reason = "first pass invalid"
    second = first
    if first_valid:
        checkpoint = args.output.with_name(args.output.stem + "_checkpoint.gpx")
        project.save(str(checkpoint))
        project.set_Controls("cycles", 12)
        project.data["Controls"]["data"]["shift factor"] = 1.0
        project.do_refinements([{}])
        second = snapshot(project, args.phase)
        replay_valid, replay_reason = validate(project, args.phase, args.mode)
        if replay_valid:
            replay_valid, replay_reason = replay_stable(first, second, args.mode)

    accepted_trial = first_valid and replay_valid
    if not accepted_trial:
        # Full reload restores both values and flags after a failed/bound trial.
        project = G2.G2Project(str(args.baseline), newgpx=str(args.output))
        project.save()
    else:
        project.save(str(args.output))

    print(
        json.dumps(
            {
                "baseline": str(args.baseline),
                "phase": args.phase,
                "mode": args.mode,
                "first_valid": first_valid,
                "first_reason": first_reason,
                "replay_valid": replay_valid,
                "replay_reason": replay_reason,
                "accepted_trial": accepted_trial,
                "first": first,
                "replay": second,
                "submitted": snapshot(project, args.phase),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
