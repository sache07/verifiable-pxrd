#!/usr/bin/env python3
"""Build and run reproducible GSAS-II phase/source comparison trials."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")


def neutralize_phase(phase, hist) -> None:
    """Set all inactive phase-specific profile/intensity terms to neutral values."""
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Pref.Ori."][4] = 0
    hap["Pref.Ori."][5] = {}
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [1000.0, 1000.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]
    phase.data["General"]["Cell"][0] = False


def make_project(output: Path, phase_specs: list[tuple[str, Path]]) -> G2.G2Project:
    project = G2.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        "pattern.xye", "instrument.instprm", fmthint="xye"
    )
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in hist.data["Sample Parameters"]:
            hist.data["Sample Parameters"][key] = [0.0, False]
    hist.data["Background"] = [
        ["chebyschev-1", False, 6, 1080.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        {
            "nDebye": 0,
            "debyeTerms": [],
            "nPeaks": 0,
            "peaksList": [],
            "background PWDR": ["", 1.0, False],
        },
    ]
    for name, cif in phase_specs:
        phase = project.add_phase(str(cif), phasename=name, histograms=[hist])
        neutralize_phase(phase, hist)
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    project.save()
    return project


def do_refine(project: G2.G2Project, label: str) -> None:
    try:
        project.do_refinements([{}])
    except Exception as exc:
        raise RuntimeError(f"refinement stage {label!r} failed: {exc}") from exc


def run_baseline(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 6}}
    )
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, [hist])
    do_refine(project, "background and scales")

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    do_refine(project, "cells and zero")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    do_refine(project, "common U/W/X")
    do_refine(project, "baseline replay")
    project.save()


def finite_or_none(value):
    try:
        value = float(value)
    except (TypeError, ValueError):
        return str(value)
    return value if math.isfinite(value) else None


def summarize(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    try:
        mass_fracs = hist.ComputeMassFracs()
    except Exception:
        mass_fracs = {}
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "scale": finite_or_none(hap["Scale"][0]),
                "mass_fraction": finite_or_none(mass_fracs.get(phase.name, (math.nan,))[0]),
                "cell": {k: finite_or_none(v) for k, v in phase.get_cell().items()},
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    inst = {
        key: finite_or_none(value[1])
        for key, value in hist.InstrumentParameters.items()
        if key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
    }
    covariance = project.data.get("Covariance", {}).get("data", {})
    return {
        "project": project.filename,
        "residuals": {k: finite_or_none(v) for k, v in hist.residuals.items()},
        "instrument": inst,
        "background": hist.Background[0],
        "phases": phases,
        "vary_list": [str(v) for v in covariance.get("varyList", [])],
        "frozen": project.get_Frozen(),
    }


def parse_phase(value: str) -> tuple[str, Path]:
    if "=" not in value:
        raise argparse.ArgumentTypeError("phase must be NAME=CIF")
    name, path = value.split("=", 1)
    candidate = Path(path)
    if not candidate.is_file():
        raise argparse.ArgumentTypeError(f"CIF does not exist: {candidate}")
    return name, candidate


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", nargs="+", type=parse_phase)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = make_project(args.output, args.phase)
    run_baseline(project)
    print(json.dumps(summarize(project), indent=2))


if __name__ == "__main__":
    main()
