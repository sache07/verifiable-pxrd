#!/usr/bin/env python3
"""Prepare GSAS-II input data and chemistry-preserving candidate CIFs."""

from __future__ import annotations

import json
import math
import shutil
from pathlib import Path

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path("<RUN>/resources/b001-c03/cif")
OUT = Path("candidates")


def source(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_adapted(
    cod_id: str,
    filename: str,
    replacements: dict[str, str],
    scale: float = 1.0,
    lattice: tuple[float, float, float, float, float, float] | None = None,
    standardize: bool = False,
) -> None:
    structure = Structure.from_file(source(cod_id))
    structure.replace_species(replacements)
    structure.remove_oxidation_states()
    if lattice is not None:
        new_lattice = Lattice.from_parameters(*lattice)
        structure = Structure(
            new_lattice,
            structure.species,
            structure.frac_coords,
            site_properties=structure.site_properties,
        )
    elif scale != 1.0:
        a, b, c = structure.lattice.abc
        alpha, beta, gamma = structure.lattice.angles
        structure = Structure(
            Lattice.from_parameters(a * scale, b * scale, c * scale, alpha, beta, gamma),
            structure.species,
            structure.frac_coords,
            site_properties=structure.site_properties,
        )
    if standardize:
        structure = SpacegroupAnalyzer(structure, symprec=0.03).get_conventional_standard_structure()
    CifWriter(structure, symprec=0.03, refine_struct=False).write_file(OUT / filename)


def copy_exact(cod_id: str, filename: str) -> None:
    shutil.copyfile(source(cod_id), OUT / filename)


def write_canonical(cod_id: str, filename: str, standardize: bool = False) -> None:
    structure = Structure.from_file(source(cod_id))
    structure.remove_oxidation_states()
    if standardize:
        structure = SpacegroupAnalyzer(structure, symprec=0.03).get_conventional_standard_structure()
    CifWriter(structure, symprec=0.03, refine_struct=False).write_file(OUT / filename)


def main() -> None:
    OUT.mkdir(exist_ok=True)

    # Scheelite: exact Sr sublattice from SrMoO4, with isovalent Mo6+ -> W6+.
    write_adapted(
        "2300460",
        "srwo4_scheelite_from_srmoo4_2300460.cif",
        {"Mo": "W"},
    )
    # Independent scheelite record; Ca2+ -> Sr2+. Use the SrMoO4 metric so that
    # source ranking tests coordinates/intensities rather than a 4% cell offset.
    write_adapted(
        "7219229",
        "srwo4_scheelite_from_cawo4_7219229.cif",
        {"Ca": "Sr"},
        lattice=(5.402647, 5.402647, 12.04112, 90.0, 90.0, 90.0),
    )
    # Structurally distinct high-pressure fergusonite competitor.
    write_adapted(
        "1546035",
        "srwo4_fergusonite_from_cawo4_1546035.cif",
        {"Ca": "Sr"},
        scale=1.035,
        standardize=True,
    )

    # Exact and structurally distinct Sr3W2O9 candidates.
    copy_exact("2311977", "sr3w2o9_monoclinic_2311977.cif")
    write_adapted(
        "1533878",
        "sr3w2o9_rhombohedral_from_ba3w2o9_1533878.cif",
        {"Ba": "Sr"},
        scale=0.97,
    )

    # Exact WO3 polymorph/source challenge.
    copy_exact("2311041", "wo3_monoclinic_2311041.cif")
    write_canonical("1563541", "wo3_monoclinic_1563541.cif")
    write_canonical("2106293", "wo3_triclinic_2106293.cif")
    copy_exact("2107312", "wo3_orthorhombic_2107312.cif")
    write_canonical("1521532", "wo3_tetragonal_1521532.cif")
    write_canonical("1004057", "wo3_hexagonal_1004057.cif")

    # Exact SrCO3 polymorph challenge.
    copy_exact("9008198", "srco3_orthorhombic_9008198.cif")
    copy_exact("1539128", "srco3_trigonal_1539128.cif")

    # Non-1:1 charge-balanced watch-list competitors, generated only from
    # physically reported ternary oxide parents.
    write_adapted(
        "1563081",
        "sr3wo6_monoclinic_from_ca3wo6_1563081.cif",
        {"Ca": "Sr"},
        scale=1.045,
        standardize=True,
    )
    write_adapted(
        "2001752",
        "sr3wo6_monoclinic_from_sr3uo6_2001752.cif",
        {"U": "W"},
        standardize=True,
    )

    data = np.genfromtxt("inputs/pattern.csv", delimiter=",", names=True)
    x = np.asarray(data["two_theta_deg"], dtype=float)
    y = np.asarray(data["intensity"], dtype=float)
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(
        "pattern.xye",
        np.column_stack((x, y, sigma)),
        fmt=("%.8f", "%.8f", "%.8f"),
        header="2theta intensity sigma",
    )

    Path("instrument.instprm").write_text(
        "#GSAS-II instrument parameter file for measured Cu Kalpha reflection data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:50.0;V:0.0;W:90.0;X:5.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )

    manifest = {
        "note": "Adapted models preserve stoichiometry and parent topology; exact records are copied unchanged.",
        "candidates": sorted(str(p) for p in OUT.glob("*.cif")),
    }
    Path("candidates/manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


if __name__ == "__main__":
    main()
