#!/usr/bin/env python3
"""Re-challenge a weak fourth phase against the fully elaborated model."""

from __future__ import annotations

import argparse
import copy
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import gsas_trials as trials


G2.SetPrintLevel("warn")

SOURCES = {
    "SrWO4": Path("candidates/srwo4_scheelite_from_cawo4_7219229.cif"),
    "WO3": Path("candidates/wo3_monoclinic_2311041.cif"),
    "SrCO3": Path("candidates/srco3_orthorhombic_9008198.cif"),
}


def copy_baseline(base: G2.G2Project, project: G2.G2Project, candidate_name: str) -> None:
    source_hist = base.histogram(0)
    hist = project.histogram(0)
    hist.data["Background"] = copy.deepcopy(source_hist.data["Background"])
    hist.data["Instrument Parameters"] = copy.deepcopy(source_hist.data["Instrument Parameters"])
    hist.data["Sample Parameters"] = copy.deepcopy(source_hist.data["Sample Parameters"])
    hist.data["Sample Parameters"]["Scale"][1] = False
    for phase in project.phases():
        if phase.name == candidate_name:
            phase.HAPvalue("Scale", 0.01)
            phase.set_HAP_refinements({"Scale": True}, [hist])
            phase.set_refinements({"Cell": False})
            continue
        source_phase = base.phase(phase.name)
        phase.data["General"]["Cell"][1:8] = copy.deepcopy(
            source_phase.data["General"]["Cell"][1:8]
        )
        target_hap = phase.data["Histograms"][hist.name]
        source_hap = source_phase.data["Histograms"][source_hist.name]
        for key in ("Scale", "Size", "Mustrain", "Pref.Ori.", "HStrain"):
            target_hap[key] = copy.deepcopy(source_hap[key])
        phase.set_refinements({"Cell": False})


def status(project: G2.G2Project, name: str) -> dict:
    hist = project.histogram(0)
    summary = trials.summarize(project)
    mass = {p["name"]: p["mass_fraction"] for p in summary["phases"]}
    scale = float(project.phase(name).HAPvalue("Scale", targethistlist=[0]))
    profile_ok = all(
        math.isfinite(float(hist.InstrumentParameters[key][1]))
        and float(hist.InstrumentParameters[key][1]) >= 0.0
        for key in ("U", "W", "X")
    )
    wr = float(hist.residuals.get("wR", math.nan))
    return {
        "wR": wr,
        "scale": scale,
        "mass_fraction": mass.get(name),
        "fractions": mass,
        "valid": math.isfinite(wr) and wr < 99.0 and scale > 1.0e-8 and profile_ok,
        "frozen": project.get_Frozen(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--name", default="candidate")
    args = parser.parse_args()

    base = G2.G2Project(str(args.baseline))
    specs = list(SOURCES.items()) + [(args.name, args.candidate)]
    project = trials.make_project(args.output, specs)
    copy_baseline(base, project, args.name)
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["shift factor"] = 0.35
    project.save()
    project.do_refinements([{}])
    first = status(project, args.name)
    checkpoint = args.output.with_name(args.output.stem + "_scale.gpx")
    project.save(str(checkpoint))

    cell_valid = False
    cell = first
    if first["valid"]:
        project.phase(args.name).set_refinements({"Cell": True})
        project.data["Controls"]["data"]["shift factor"] = 0.15
        project.do_refinements([{}])
        cell = status(project, args.name)
        before_scale = float(first["scale"])
        after_scale = float(cell["scale"])
        cell_valid = cell["valid"] and abs(after_scale - before_scale) <= max(
            0.05 * abs(before_scale), 1.0e-4
        )
    if not cell_valid:
        project = G2.G2Project(str(checkpoint), newgpx=str(args.output))
        project.phase(args.name).set_refinements({"Cell": False})
    else:
        project.data["Controls"]["data"]["shift factor"] = 1.0
        project.do_refinements([{}])
        replay = status(project, args.name)
        cell_valid = replay["valid"] and abs(replay["scale"] - cell["scale"]) <= max(
            0.05 * abs(cell["scale"]), 1.0e-4
        )
        if not cell_valid:
            project = G2.G2Project(str(checkpoint), newgpx=str(args.output))
            project.phase(args.name).set_refinements({"Cell": False})
    project.save(str(args.output))
    print(
        json.dumps(
            {
                "candidate": str(args.candidate),
                "first": first,
                "cell": cell,
                "cell_replay_valid": cell_valid,
                "submitted": status(project, args.name),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
