#!/usr/bin/env python3
"""Conservative sequential cell refinement with full-value rollback and replay."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import gsas_trials as trials


G2.SetPrintLevel("warn")


def valid(project: G2.G2Project) -> tuple[bool, str]:
    hist = project.histogram(0)
    wr = float(hist.residuals.get("wR", math.nan))
    if not math.isfinite(wr) or wr >= 99.0:
        return False, "invalid residual"
    for key in ("U", "W", "X"):
        value = float(hist.InstrumentParameters[key][1])
        if not math.isfinite(value) or value < 0.0:
            return False, f"profile {key} became negative"
    for phase in project.phases():
        if float(phase.HAPvalue("Scale", targethistlist=[0])) <= 0.0:
            return False, f"{phase.name} scale collapsed"
        if any(not math.isfinite(float(v)) or float(v) <= 0.0 for v in phase.get_cell().values()):
            return False, f"{phase.name} cell became invalid"
    return True, "valid"


def compact(project: G2.G2Project) -> dict:
    summary = trials.summarize(project)
    return {
        "wR": summary["residuals"].get("wR"),
        "R": summary["residuals"].get("R"),
        "instrument": summary["instrument"],
        "phases": [
            {
                "name": phase["name"],
                "mass_fraction": phase["mass_fraction"],
                "cell": phase["cell"],
            }
            for phase in summary["phases"]
        ],
        "frozen": summary["frozen"],
    }


def refine_stage(project: G2.G2Project, output: Path, phase_names: list[str], label: str) -> tuple[G2.G2Project, dict]:
    for phase in project.phases():
        phase.set_refinements({"Cell": phase.name in phase_names})
    checkpoint = output.with_name(output.stem + f"_{label}_before.gpx")
    project.save(str(checkpoint))
    before = compact(project)
    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["shift factor"] = 0.35
    project.do_refinements([{}])
    first_valid, first_reason = valid(project)
    first = compact(project)
    replay_valid = False
    replay_reason = "first pass invalid"
    if first_valid:
        project.set_Controls("cycles", 12)
        project.data["Controls"]["data"]["shift factor"] = 1.0
        project.do_refinements([{}])
        replay_valid, replay_reason = valid(project)
    if not (first_valid and replay_valid):
        project = G2.G2Project(str(checkpoint), newgpx=str(output))
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
    project.save(str(output))
    return project, {
        "label": label,
        "before": before,
        "first": first,
        "first_valid": first_valid,
        "first_reason": first_reason,
        "replay_valid": replay_valid,
        "replay_reason": replay_reason,
        "accepted": first_valid and replay_valid,
        "submitted": compact(project),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    project = G2.G2Project(str(args.baseline), newgpx=str(args.output))
    stages = []
    for name in ("SrWO4", "WO3", "SrCO3"):
        project, result = refine_stage(project, args.output, [name], name)
        stages.append(result)
    project, result = refine_stage(
        project, args.output, ["SrWO4", "WO3", "SrCO3"], "joint"
    )
    stages.append(result)
    print(json.dumps({"stages": stages, "final": compact(project)}, sort_keys=True))


if __name__ == "__main__":
    main()
