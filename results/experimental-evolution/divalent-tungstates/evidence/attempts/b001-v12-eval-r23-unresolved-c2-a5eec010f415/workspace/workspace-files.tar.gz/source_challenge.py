#!/usr/bin/env python3
"""Cross-seeded GSAS-II source/polymorph and add-phase challenges."""

from __future__ import annotations

import argparse
import copy
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import gsas_trials as trials


G2.SetPrintLevel("warn")
BASELINE = Path(".tmp/leader_cells.gpx")
SRWO4 = Path("candidates/srwo4_scheelite_from_cawo4_7219229.cif")
WO3 = Path("candidates/wo3_monoclinic_2311041.cif")
SRCO3 = Path("candidates/srco3_orthorhombic_9008198.cif")


def set_cell(phase, values: list[float]) -> None:
    phase.data["General"]["Cell"][1:8] = list(values)


def volume_from_cell(a, b, c, alpha, beta, gamma) -> float:
    ar, br, gr = (math.radians(v) for v in (alpha, beta, gamma))
    factor = 1 + 2 * math.cos(ar) * math.cos(br) * math.cos(gr)
    factor -= math.cos(ar) ** 2 + math.cos(br) ** 2 + math.cos(gr) ** 2
    return a * b * c * math.sqrt(max(factor, 0.0))


def phase_specs(kind: str, candidate_name: str, candidate: Path):
    if kind == "srwo4":
        return [("SrWO4", candidate), ("WO3", WO3), ("SrCO3", SRCO3)], "SrWO4"
    if kind == "wo3":
        return [("SrWO4", SRWO4), ("WO3", candidate), ("SrCO3", SRCO3)], "WO3"
    if kind == "srco3":
        return [("SrWO4", SRWO4), ("WO3", WO3), ("SrCO3", candidate)], "SrCO3"
    if kind == "add":
        return [
            ("SrWO4", SRWO4),
            ("WO3", WO3),
            ("SrCO3", SRCO3),
            (candidate_name, candidate),
        ], candidate_name
    raise ValueError(kind)


def cross_seed(project, kind: str, replaced: str) -> None:
    baseline = G2.G2Project(str(BASELINE))
    source_hist = baseline.histogram(0)
    hist = project.histogram(0)
    hist.data["Background"] = copy.deepcopy(source_hist.data["Background"])
    for key, value in source_hist.InstrumentParameters.items():
        if key in hist.InstrumentParameters and len(value) > 1:
            hist.InstrumentParameters[key][1] = copy.deepcopy(value[1])
    hist.InstrumentParameters["U"][1] = 0.0
    hist.data["Sample Parameters"] = copy.deepcopy(source_hist.data["Sample Parameters"])
    hist.data["Sample Parameters"]["Scale"][1] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in hist.data["Sample Parameters"]:
            hist.data["Sample Parameters"][key] = [0.0, False]

    for phase in project.phases():
        trials.neutralize_phase(phase, hist)
        if phase.name != replaced:
            base_phase = baseline.phase(phase.name)
            set_cell(phase, base_phase.data["General"]["Cell"][1:8])
            phase.HAPvalue("Scale", base_phase.HAPvalue("Scale", targethistlist=[0]))
        elif kind == "add":
            phase.HAPvalue("Scale", 0.05)
        elif phase.name == "SrWO4":
            system = phase.data["General"]["SGData"]["SGSys"]
            base_cell = baseline.phase("SrWO4").data["General"]["Cell"]
            if system == "tetragonal":
                set_cell(phase, base_cell[1:8])
            elif system == "monoclinic":
                a = base_cell[1]
                b = base_cell[3]
                c = base_cell[1]
                beta = phase.data["General"]["Cell"][5]
                set_cell(phase, [a, b, c, 90.0, beta, 90.0, volume_from_cell(a, b, c, 90, beta, 90)])
            phase.HAPvalue("Scale", baseline.phase("SrWO4").HAPvalue("Scale", targethistlist=[0]))
        else:
            phase.HAPvalue(
                "Scale", baseline.phase(phase.name).HAPvalue("Scale", targethistlist=[0])
            )

    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        phase.set_HAP_refinements({"Scale": True}, [hist])
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 6}}
    )
    for key, value in hist.InstrumentParameters.items():
        if isinstance(value, list) and len(value) > 2:
            value[2] = key in ("Zero", "W", "X")


def valid(project, candidate_name: str) -> tuple[bool, str]:
    hist = project.histogram(0)
    phase = project.phase(candidate_name)
    scale = phase.HAPvalue("Scale", targethistlist=[0])
    if not math.isfinite(scale) or scale <= 1e-8:
        return False, "candidate scale collapsed or became nonpositive"
    for value in phase.get_cell().values():
        if not math.isfinite(value) or value <= 0:
            return False, "invalid candidate cell"
    for key in ("U", "W", "X"):
        value = float(hist.InstrumentParameters[key][1])
        if not math.isfinite(value) or value < 0:
            return False, f"shared profile {key} became negative"
    wr = hist.residuals.get("wR", math.nan)
    if not math.isfinite(float(wr)) or float(wr) >= 99:
        return False, "refinement residual invalid"
    return True, "valid"


def compact(summary: dict) -> dict:
    return {
        "project": summary["project"],
        "residuals": {
            key: summary["residuals"].get(key)
            for key in ("wR", "R", "Rb", "wRb", "wRmin")
        },
        "instrument": summary["instrument"],
        "phases": [
            {
                "name": phase["name"],
                "scale": phase["scale"],
                "mass_fraction": phase["mass_fraction"],
                "cell": phase["cell"],
            }
            for phase in summary["phases"]
        ],
        "frozen": summary["frozen"],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("kind", choices=("srwo4", "wo3", "srco3", "add"))
    parser.add_argument("candidate", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--name", default="candidate")
    args = parser.parse_args()
    if not args.candidate.is_file():
        parser.error(f"missing candidate: {args.candidate}")
    args.output.parent.mkdir(parents=True, exist_ok=True)

    specs, replaced = phase_specs(args.kind, args.name, args.candidate)
    project = trials.make_project(args.output, specs)
    cross_seed(project, args.kind, replaced)
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["shift factor"] = 0.5
    project.save()
    project.do_refinements([{}])
    project.save()

    scale_checkpoint = args.output.with_name(args.output.stem + "_scale_checkpoint.gpx")
    project.save(str(scale_checkpoint))
    scale_summary = trials.summarize(project)
    scale_valid, scale_reason = valid(project, replaced)

    cell_trial_valid = False
    cell_reason = "scale-only trial invalid"
    if scale_valid:
        project.phase(replaced).set_refinements({"Cell": True})
        project.set_Controls("cycles", 8)
        project.data["Controls"]["data"]["shift factor"] = 0.25
        project.save(str(args.output))
        project.do_refinements([{}])
        project.save()
        cell_trial_valid, cell_reason = valid(project, replaced)

    if not cell_trial_valid:
        # Full reload restores values and flags, not just the failed flag set.
        project = G2.G2Project(str(scale_checkpoint), newgpx=str(args.output))
        project.phase(replaced).set_refinements({"Cell": False})
        project.save()
    else:
        before = project.phase(replaced).HAPvalue("Scale", targethistlist=[0])
        project.set_Controls("cycles", 10)
        project.data["Controls"]["data"]["shift factor"] = 1.0
        project.do_refinements([{}])
        project.save()
        after = project.phase(replaced).HAPvalue("Scale", targethistlist=[0])
        replay_valid, replay_reason = valid(project, replaced)
        stable = abs(after - before) <= max(0.03 * abs(before), 1e-4)
        if not replay_valid or not stable:
            project = G2.G2Project(str(scale_checkpoint), newgpx=str(args.output))
            project.phase(replaced).set_refinements({"Cell": False})
            project.save()
            cell_trial_valid = False
            cell_reason = replay_reason if not replay_valid else "candidate scale not replay-stable"

    print(
        json.dumps(
            {
                "kind": args.kind,
                "candidate": str(args.candidate),
                "candidate_phase": replaced,
                "scale_trial_valid": scale_valid,
                "scale_trial_reason": scale_reason,
                "cell_trial_valid": cell_trial_valid,
                "cell_trial_reason": cell_reason,
                "scale_checkpoint": compact(scale_summary),
                "submitted_trial": compact(trials.summarize(project)),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
