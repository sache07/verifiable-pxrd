#!/usr/bin/env python3
"""Remove one retained phase and reconverge all surviving nuisance terms."""

from __future__ import annotations

import argparse
import copy
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import gsas_trials as trials


G2.SetPrintLevel("warn")

SOURCES = {
    "SrWO4": Path("candidates/srwo4_scheelite_from_cawo4_7219229.cif"),
    "WO3": Path("candidates/wo3_monoclinic_2311041.cif"),
    "SrCO3": Path("candidates/srco3_orthorhombic_9008198.cif"),
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("drop", choices=tuple(SOURCES))
    args = parser.parse_args()

    base = G2.G2Project(str(args.baseline))
    specs = [(name, source) for name, source in SOURCES.items() if name != args.drop]
    project = trials.make_project(args.output, specs)
    source_hist = base.histogram(0)
    hist = project.histogram(0)
    hist.data["Background"] = copy.deepcopy(source_hist.data["Background"])
    hist.data["Instrument Parameters"] = copy.deepcopy(
        source_hist.data["Instrument Parameters"]
    )
    hist.data["Sample Parameters"] = copy.deepcopy(source_hist.data["Sample Parameters"])
    hist.data["Sample Parameters"]["Scale"][1] = False

    for phase in project.phases():
        source_phase = base.phase(phase.name)
        phase.data["General"]["Cell"][1:8] = copy.deepcopy(
            source_phase.data["General"]["Cell"][1:8]
        )
        target_hap = phase.data["Histograms"][hist.name]
        source_hap = source_phase.data["Histograms"][source_hist.name]
        for key in ("Scale", "Size", "Mustrain", "Pref.Ori.", "HStrain"):
            target_hap[key] = copy.deepcopy(source_hap[key])
        phase.set_refinements({"Cell": False})

    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["shift factor"] = 0.5
    project.save()
    project.do_refinements([{}])
    first = trials.summarize(project)
    project.data["Controls"]["data"]["shift factor"] = 1.0
    project.do_refinements([{}])
    project.save()
    final = trials.summarize(project)

    wr = float(final["residuals"].get("wR", math.nan))
    valid = math.isfinite(wr) and wr < 99.0
    valid = valid and all(float(p["scale"]) > 0.0 for p in final["phases"])
    print(
        json.dumps(
            {
                "drop": args.drop,
                "valid": valid,
                "first_wR": first["residuals"].get("wR"),
                "final_wR": final["residuals"].get("wR"),
                "fractions": {
                    p["name"]: p["mass_fraction"] for p in final["phases"]
                },
                "instrument": final["instrument"],
                "frozen": final["frozen"],
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
