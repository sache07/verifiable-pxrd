#!/usr/bin/env python3
"""Build and refine a three-phase GSAS-II model for inputs/pattern.csv."""

from __future__ import annotations

import csv
import json
import math
import os
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
GPX = ROOT / "final.gpx"
XYE = TMP / "pattern.xye"
INST = TMP / "lab.instprm"


def make_xye() -> None:
    with (ROOT / "inputs" / "pattern.csv").open(newline="") as src, XYE.open("w") as dst:
        reader = csv.DictReader(src)
        for row in reader:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            # No pointwise uncertainties were supplied. Counts imply the
            # conventional Poisson estimate sigma(I)=sqrt(I).
            dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")


def add_phases(project: G2sc.G2Project, hist) -> None:
    # Wolframite-type NiWO4, COD 5910277 recast as an asymmetric unit.
    niwo4 = project.add_phase(
        phasename="NiWO4",
        histograms=[hist],
        spacegroup="P 1 2/c 1",
        cell=[4.6000, 5.6650, 4.9120, 90.0, 90.50, 90.0],
    )
    niwo4.add_atom(0.5000, 0.6530, 0.2500, "Ni", "Ni1", uiso=0.0)
    niwo4.add_atom(0.0000, 0.1800, 0.2500, "W", "W1", uiso=0.0)
    niwo4.add_atom(0.2200, 0.1100, 0.9600, "O", "O1", uiso=0.0)
    niwo4.add_atom(0.2600, 0.3800, 0.3900, "O", "O2", uiso=0.0)

    # Room-temperature gamma-WO3, monoclinic P21/n, COD 1528915.
    wo3 = project.add_phase(
        phasename="WO3",
        histograms=[hist],
        spacegroup="P 1 21/n 1",
        cell=[7.3000, 7.5300, 7.6800, 90.0, 90.90, 90.0],
    )
    wo3.add_atom(0.2470, 0.0330, 0.7810, "W", "W2", uiso=0.0)
    wo3.add_atom(0.2520, 0.0260, 0.2850, "W", "W1", uiso=0.0)
    wo3.add_atom(0.0000, 0.4750, 0.2200, "O", "O2", uiso=0.0)
    wo3.add_atom(0.0000, 0.0250, 0.2200, "O", "O1", uiso=0.0)
    wo3.add_atom(0.2900, 0.2900, 0.2650, "O", "O3", uiso=0.0)
    wo3.add_atom(0.2100, 0.2900, 0.7350, "O", "O4", uiso=0.0)
    wo3.add_atom(0.2800, 0.0400, 0.0300, "O", "O5", uiso=0.0)
    wo3.add_atom(0.2800, 0.2400, 0.9700, "O", "O6", uiso=0.0)

    # Rocksalt NiO, COD 1010093.
    nio = project.add_phase(
        phasename="NiO",
        histograms=[hist],
        spacegroup="F m -3 m",
        cell=[4.1684, 4.1684, 4.1684, 90.0, 90.0, 90.0],
    )
    nio.add_atom(0.0000, 0.0000, 0.0000, "Ni", "Ni1", uiso=0.0)
    nio.add_atom(0.5000, 0.5000, 0.5000, "O", "O1", uiso=0.0)


def print_state(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(f"\n--- {label} ---")
    print("residuals", hist.residuals)
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items() if k in {"Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)"}})
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        print(
            phase.name,
            "cell", phase.get_cell(),
            "scale", hap["Scale"],
            "size", hap["Size"],
            "mustrain", hap["Mustrain"],
        )


def main() -> None:
    make_xye()
    if GPX.exists():
        GPX.unlink()
    project = G2sc.G2Project(newgpx=str(GPX))
    hist = project.add_powder_histogram(
        str(XYE), str(INST), fmthint="Topas xye"
    )
    add_phases(project, hist)

    # Use the full measured range. A moderate Chebyshev background captures
    # the smooth air/instrument background while crystalline peaks are modeled.
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 12,
            "coeffs": [3400.0] + [0.0] * 11,
        },
    })
    for phase, start_scale in zip(project.phases(), [1.0, 0.55, 0.20]):
        phase.HAPvalue("Scale", start_scale, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])

    project.set_Controls("cycles", 8)
    project.save()
    print_state(project, "initial")

    # Scales and background first.
    project.refine(makeBack=False)
    print_state(project, "scales/background")

    # Lattice metrics and a small global zero correction.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine(makeBack=False)
    print_state(project, "cells/zero")

    # Instrument broadening, followed by phase-specific isotropic size and
    # microstrain terms. Initial values are deliberately conservative.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
    project.refine(makeBack=False)
    print_state(project, "instrument profile")

    for phase in project.phases():
        phase.setSampleProfile(hist, "size", "isotropic", 0.15, LGmix=0.5)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 500.0, LGmix=0.5)
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    project.refine(makeBack=False)
    print_state(project, "phase profiles")

    project.save()


if __name__ == "__main__":
    main()
