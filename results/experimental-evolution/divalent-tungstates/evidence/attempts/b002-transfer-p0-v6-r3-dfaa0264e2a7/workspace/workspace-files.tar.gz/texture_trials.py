#!/usr/bin/env python3
"""Compare symmetry-distinct March-Dollase axes under one fixed baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


AXES = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1), (1, 1, 1)]


def run(source: Path, output: Path, axis: tuple[int, int, int]) -> dict:
    project = G2sc.G2Project(gpxfile=str(source))
    project.save(str(output))
    project = G2sc.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 20)
    project.set_Frozen()
    hist = project.histogram(0)
    phase = project.phase(0)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(axis)
    project.set_Controls("parmMin", 0.05, variable="0:0:MD")
    project.set_Controls("parmMax", 20.0, variable="0:0:MD")
    project.refine()
    project.save()
    project = G2sc.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 20)
    project.refine()
    project.save()
    hist = project.histogram(0)
    po = project.phase(0).data["Histograms"][hist.name]["Pref.Ori."]
    return {
        "axis": axis,
        "md": po[1],
        "rwp": hist.get_wR(),
        "rp": hist.data["data"][0].get("R"),
        "fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "project": str(output),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--outdir", type=Path, required=True)
    args = parser.parse_args()
    args.outdir.mkdir(exist_ok=True)
    rows = []
    for axis in AXES:
        label = "".join(str(i) for i in axis)
        print(f"\n===== axis {axis} =====", flush=True)
        row = run(args.source, args.outdir / f"axis_{label}.gpx", axis)
        rows.append(row)
        print(json.dumps(row, indent=2, default=str), flush=True)
    (args.outdir / "summary.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
