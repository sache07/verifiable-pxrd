#!/usr/bin/env python3
"""Run reversible profile/nuisance trials from a converged GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def summarize(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    hname = hist.name
    return {
        "rwp": hist.get_wR(),
        "rp": hist.data["data"][0].get("R"),
        "durbin_watson": hist.data["data"][0].get("Durbin-Watson"),
        "fractions": hist.ComputeMassFracs(),
        "instrument": {k: inst[k][1] for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")},
        "hap": {
            phase.name: {
                "size": phase.data["Histograms"][hname]["Size"],
                "mustrain": phase.data["Histograms"][hname]["Mustrain"],
                "pref_ori": phase.data["Histograms"][hname]["Pref.Ori."],
            }
            for phase in project.phases()
        },
        "frozen": project.get_Frozen(),
    }


def clone(source: Path, output: Path) -> G2sc.G2Project:
    project = G2sc.G2Project(gpxfile=str(source))
    project.save(str(output))
    project = G2sc.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 20)
    project.set_Frozen()
    return project


def run_trial(source: Path, output: Path, kind: str, phase_index: int | None) -> dict:
    project = clone(source, output)
    hist = project.histogram(0)
    if kind == "shl":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        project.set_Controls("parmMin", 0.0005, variable=":0:SH/L")
        project.set_Controls("parmMax", 0.1, variable=":0:SH/L")
    elif kind == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif kind in ("size", "strain"):
        if phase_index is None:
            raise ValueError("phase index required")
        phase = project.phase(phase_index)
        hap = phase.data["Histograms"][hist.name]
        if kind == "size":
            hap["Size"][0] = "isotropic"
            hap["Size"][1] = [1.0, 1.0, 1.0]
            hap["Size"][2] = [True, False, False]
            project.set_Controls("parmMin", 0.005, variable=f"{phase_index}:0:Size;i")
            project.set_Controls("parmMax", 1000.0, variable=f"{phase_index}:0:Size;i")
        else:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1] = [500.0, 500.0, 1.0]
            hap["Mustrain"][2] = [True, False, False]
            project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;i")
            project.set_Controls("parmMax", 10000.0, variable=f"{phase_index}:0:Mustrain;i")
    else:
        raise ValueError(kind)

    project.refine()
    project.save()
    # Mandatory reopen/replay check for every accepted-candidate trial.
    project = G2sc.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 20)
    project.refine()
    project.save()
    result = summarize(project)
    result.update({"source": str(source), "project": str(output), "kind": kind, "phase_index": phase_index})
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument(
        "--spec",
        action="append",
        help="trial label (shl, polarization, size0..2, or strain0..2); repeat as needed",
    )
    args = parser.parse_args()
    args.outdir.mkdir(exist_ok=True)
    specs = [("shl", None), ("polarization", None)]
    specs += [(kind, phase) for kind in ("size", "strain") for phase in range(3)]
    if args.spec:
        specs = []
        for label in args.spec:
            if label in ("shl", "polarization"):
                specs.append((label, None))
            elif label[:-1] in ("size", "strain") and label[-1:] in ("0", "1", "2"):
                specs.append((label[:-1], int(label[-1])))
            else:
                raise ValueError(f"invalid --spec {label}")
    rows = []
    for kind, phase in specs:
        label = kind if phase is None else f"{kind}_p{phase}"
        print(f"\n===== {label} =====", flush=True)
        result = run_trial(args.source, args.outdir / f"{label}.gpx", kind, phase)
        rows.append(result)
        print(json.dumps(result, indent=2, default=str), flush=True)
    (args.outdir / "summary.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
