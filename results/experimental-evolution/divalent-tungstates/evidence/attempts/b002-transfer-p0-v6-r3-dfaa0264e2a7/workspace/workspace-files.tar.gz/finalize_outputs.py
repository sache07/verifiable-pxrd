#!/usr/bin/env python3
"""Replay the accepted full-range project and export all requested artifacts."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SOURCE = Path("atom_trials/mgwo4_wo3W_coords.gpx")
FINAL = Path("final.gpx")
PHASE_INFO = [
    ("MgWO4", "phase_1_MgWO4.cif", "wolframite-type magnesium tungstate"),
    ("WO3", "phase_2_WO3.cif", "monoclinic tungsten(VI) oxide"),
    ("MgO", "phase_3_MgO.cif", "periclase"),
]


def plain(value):
    if isinstance(value, dict):
        return {key: plain(val) for key, val in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(val) for val in value]
    try:
        return float(value)
    except (TypeError, ValueError):
        return value


def replay_full_range() -> G2sc.G2Project:
    project = G2sc.G2Project(gpxfile=str(SOURCE))
    hist = project.histogram(0)
    x = hist.data["data"][1][0]
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    project.set_Controls("cycles", 20)
    project.set_Frozen()
    project.save(str(FINAL))

    # Save/reopen/replay twice; the second pass is the serialization and
    # convergence audit from which all exports are made.
    for _ in range(2):
        project = G2sc.G2Project(gpxfile=str(FINAL))
        project.set_Controls("cycles", 20)
        project.refine()
        project.save()
    return G2sc.G2Project(gpxfile=str(FINAL))


def main() -> None:
    project = replay_full_range()
    hist = project.histogram(0)
    if project.get_Frozen():
        raise RuntimeError(f"final project has frozen variables: {project.get_Frozen()}")
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "W", "X"):
        if inst[key][1] < 0:
            raise RuntimeError(f"negative final profile coefficient {key}={inst[key][1]}")
    if hist.data["Sample Parameters"]["Scale"][1]:
        raise RuntimeError("redundant histogram scale is refined")

    fractions = hist.ComputeMassFracs()
    phase_rows = []
    for index, (formula, cif_name, description) in enumerate(PHASE_INFO):
        phase = project.phase(index)
        phase.export_CIF(cif_name)
        value, sigma = fractions[phase.name]
        cell, cell_sigma = phase.get_cell_and_esd()
        phase_rows.append(
            {
                "name": phase.name,
                "formula": formula,
                "description": description,
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": cif_name,
                "weight_fraction": float(value),
                "weight_percent": 100.0 * float(value),
                "formal_standard_uncertainty": float(sigma),
                "cell": plain(cell),
                "cell_standard_uncertainty": plain(cell_sigma),
            }
        )

    x, observed, weights, calculated, background, stored_difference = hist.data["data"][1]
    with Path("fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
                "weight",
            ]
        )
        for values in zip(x, observed, calculated, observed - calculated, background, weights):
            # Preserve enough digits to round-trip the exact project arrays.
            writer.writerow([f"{float(value):.17g}" for value in values])

    residual = hist.data["data"][0]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "fraction_basis": "normalized over the modeled crystalline phases; amorphous content is not quantified",
        "phases": phase_rows,
        "fit_statistics": {
            "r_wp_percent": float(residual["wR"]),
            "r_p_percent": float(residual["R"]),
            "r_exp_percent": float(residual["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_variables": int(rvals["Nvars"]),
            "durbin_watson": float(residual["Durbin-Watson"]),
            "converged": bool(rvals["converged"]),
            "max_shift_over_sigma": float(rvals["Max shft/sig"]),
        },
        "measurement_model": {
            "range_two_theta_deg": [float(x[0]), float(x[-1])],
            "wavelength_kalpha1_angstrom": float(inst["Lam1"][1]),
            "wavelength_kalpha2_angstrom": float(inst["Lam2"][1]),
            "kalpha2_to_kalpha1_ratio": float(inst["I(L2)/I(L1)"][1]),
            "weights": "1/observed_counts (Poisson counting approximation; pointwise uncertainties were not supplied)",
            "profile": {
                key: float(inst[key][1]) for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L")
            },
        },
        "project_path": str(FINAL),
        "profile_path": "fit.csv",
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
