#!/usr/bin/env python3
"""Re-challenge chemically plausible weak phases under the final common profile."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
CANDIDATES = {
    "MgO2_9002348": "9002348",
    "MgWO_1010642": "1010642",
    "MgWO6_1530034": "1530034",
    "WO2_1548686": "1548686",
    "W18O49_1528166": "1528166",
    "W3O8_2101049": "2101049",
}


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def run(source: Path, output: Path, name: str, cod_id: str) -> dict:
    project = G2sc.G2Project(gpxfile=str(source))
    project.save(str(output))
    project = G2sc.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 20)
    project.set_Frozen()
    hist = project.histogram(0)
    phase = project.add_phase(str(cod_path(cod_id)), phasename=name, histograms=[hist])
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.1, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][1:3] = [1.0, False]
    phase.set_refinements({"Cell": False})
    project.update_ids()
    p_id = len(project.phases()) - 1
    project.set_Controls("parmMin", 0.0, variable=f"{p_id}:0:Scale")
    project.refine()
    project.save()
    project = G2sc.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 20)
    project.refine()
    project.save()
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    return {
        "candidate": name,
        "cod_id": cod_id,
        "rwp": hist.get_wR(),
        "scale": project.phase(p_id).HAPvalue("Scale"),
        "weight_fraction": fractions.get(name),
        "frozen": project.get_Frozen(),
        "project": str(output),
    }


def main() -> None:
    source = Path("atom_trials/mgwo4_wo3W_coords.gpx")
    outdir = Path("watchlist")
    outdir.mkdir(exist_ok=True)
    rows = []
    for name, cod_id in CANDIDATES.items():
        print(f"\n===== {name} =====", flush=True)
        row = run(source, outdir / f"{name}.gpx", name, cod_id)
        rows.append(row)
        print(json.dumps(row, indent=2, default=str), flush=True)
    (outdir / "summary.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
