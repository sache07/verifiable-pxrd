#!/usr/bin/env python3
"""Fit candidate WO3 records under one conservative three-phase baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
MGWO4 = "9013902"
MGO = "9000499"


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def values(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    return {
        "rwp": hist.get_wR(),
        "residuals": hist.data["data"][0].copy(),
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {key: val[1] for key, val in inst.items() if isinstance(val, list) and len(val) > 1},
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "scales": {phase.name: phase.HAPvalue("Scale") for phase in project.phases()},
        "frozen": project.get_Frozen(),
    }


def build_and_fit(wo3_id: str, output: Path) -> dict:
    if output.exists():
        output.unlink()
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma/tab/semicolon separated"
    )
    phase_specs = [
        (MGWO4, "MgWO4_wolframite"),
        (wo3_id, f"WO3_{wo3_id}"),
        (MGO, "MgO_periclase"),
    ]
    for cod_id, name in phase_specs:
        project.add_phase(str(cod_path(cod_id)), phasename=name, histograms=[hist])

    project.set_Controls("cycles", 12)
    hist.set_refinements({
        "Limits": [10.0, 100.05],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 6,
            "coeffs": [3600.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        },
    })
    # The importer enables an overall histogram scale by default. It is
    # redundant with all phase scales and must remain fixed.
    hist.clear_refinements({"Sample Parameters": ["Scale"]})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        # GSAS-II's phase-link defaults contain finite 1-micron size and
        # 1000-microstrain broadening even when their refinement flags are off.
        # Make all unused phase broadening genuinely neutral for this screen.
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [1.0e6, 1.0e6, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][1:3] = [1.0, False]
        hap["Extinction"] = [0.0, False]
        hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": False})

    # Enforce physical nonnegative phase scales and profile coefficients.
    project.update_ids()
    for p_id in range(len(project.phases())):
        project.set_Controls("parmMin", 0.0, variable=f"{p_id}:0:Scale")
    for key in ("U", "W", "X"):
        project.set_Controls("parmMin", 0.0, variable=f":0:{key}")
    project.set_Controls("parmMin", -0.25, variable=":0:Zero")
    project.set_Controls("parmMax", 0.25, variable=":0:Zero")

    # First obtain stable scale/background values, then one angular correction
    # and all cells, and finally a shared low-dimensional profile.
    project.save()
    project.refine()
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine()
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.refine()
    project.refine()
    project.save()

    # Reopen and replay once to expose any serialization or convergence issue.
    reopened = G2sc.G2Project(gpxfile=str(output))
    reopened.set_Controls("cycles", 12)
    reopened.refine()
    reopened.save()
    result = values(reopened)
    result["wo3_id"] = wo3_id
    result["project"] = str(output)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_ids", nargs="+")
    parser.add_argument("--outdir", type=Path, default=Path("screening"))
    args = parser.parse_args()
    args.outdir.mkdir(exist_ok=True)
    rows = []
    for wo3_id in args.wo3_ids:
        print(f"\n===== screening WO3 COD {wo3_id} =====", flush=True)
        rows.append(build_and_fit(wo3_id, args.outdir / f"wo3_{wo3_id}.gpx"))
        print(json.dumps(rows[-1], indent=2, default=str), flush=True)
    (args.outdir / "summary.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
