#!/usr/bin/env python3
"""Challenge isotropic WO3 size or microstrain with uniaxial models."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


AXES = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1)]


def run(source: Path, output: Path, axis: tuple[int, int, int], kind: str) -> dict:
    project = G2sc.G2Project(gpxfile=str(source))
    project.save(str(output))
    project = G2sc.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 20)
    project.set_Frozen()
    hist = project.histogram(0)
    phase = project.phase(1)
    key = "Mustrain" if kind == "strain" else "Size"
    model = phase.data["Histograms"][hist.name][key]
    start = float(model[1][0])
    model[0] = "uniaxial"
    model[1] = [start, start, 1.0]
    model[2] = [True, True, False]
    model[3] = list(axis)
    for suffix in ("i", "a"):
        project.set_Controls(
            "parmMin", 0.0 if kind == "strain" else 0.005,
            variable=f"1:0:{key};{suffix}",
        )
        project.set_Controls(
            "parmMax", 10000.0 if kind == "strain" else 10.0,
            variable=f"1:0:{key};{suffix}",
        )
    project.refine()
    project.save()
    project = G2sc.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 20)
    project.refine()
    project.save()
    hist = project.histogram(0)
    model = project.phase(1).data["Histograms"][hist.name][key]
    return {
        "kind": kind,
        "axis": axis,
        "equatorial": model[1][0],
        "axial": model[1][1],
        "rwp": hist.get_wR(),
        "rp": hist.data["data"][0].get("R"),
        "fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "project": str(output),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--kind", choices=("strain", "size"), default="strain")
    args = parser.parse_args()
    args.outdir.mkdir(exist_ok=True)
    rows = []
    for axis in AXES:
        label = "".join(str(i) for i in axis)
        print(f"\n===== axis {axis} =====", flush=True)
        row = run(args.source, args.outdir / f"axis_{label}.gpx", axis, args.kind)
        rows.append(row)
        print(json.dumps(row, indent=2, default=str), flush=True)
    (args.outdir / "summary.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
