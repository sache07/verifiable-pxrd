#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
BASE = WORK / "stage3_replayed.gpx"


def set_inst(hist, key: str, value: float | None = None, refine: bool | None = None) -> None:
    entry = hist.InstrumentParameters[key]
    if value is not None:
        entry[0] = float(value)
        entry[1] = float(value)
    if refine is not None:
        entry[2] = bool(refine)


def run_trial(name: str, configure) -> dict:
    out = WORK / f"trial_{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = gpx.histogram(0)
    configure(gpx, hist)
    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.do_refinements([{}])
    gpx.save()
    gpx = G2sc.G2Project(str(out))
    gpx.do_refinements([{}])
    gpx.save()
    hist = gpx.histogram(0)
    result = {
        "trial": name,
        "Rwp": hist.residuals["wR"],
        "Rp": hist.residuals["R"],
        "GOF": (hist.residuals["wR"] / hist.residuals["wRmin"]) ** 2,
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "instrument": {
            k: [hist.InstrumentParameters[k][1], hist.InstrumentParameters[k][2]]
            for k in ("Zero", "Polariz.", "U", "W", "X", "SH/L")
        },
        "sample": {
            k: list(hist.SampleParameters[k])
            for k in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "cells": {p.name: p.get_cell() for p in gpx.phases()},
    }
    print(json.dumps(result, sort_keys=True))
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    rows = []

    rows.append(run_trial("zero", lambda g, h: None))

    def no_correction(gpx, hist):
        set_inst(hist, "Zero", 0.0, False)

    rows.append(run_trial("no_angular", no_correction))

    def displacement(gpx, hist):
        set_inst(hist, "Zero", 0.0, False)
        hist.SampleParameters["Shift"] = [0.0, True]

    rows.append(run_trial("shift", displacement))

    def polarization(gpx, hist):
        set_inst(hist, "Polariz.", refine=True)
        gpx.set_Controls("parmMin", 0.0, f"{hist.id}::Polariz.")
        gpx.set_Controls("parmMax", 1.0, f"{hist.id}::Polariz.")

    rows.append(run_trial("zero_polarization", polarization))

    def shl(gpx, hist):
        set_inst(hist, "SH/L", refine=True)
        gpx.set_Controls("parmMin", 0.0005, f"{hist.id}::SH/L")
        gpx.set_Controls("parmMax", 0.1, f"{hist.id}::SH/L")

    rows.append(run_trial("zero_shl", shl))

    def pol_shl(gpx, hist):
        polarization(gpx, hist)
        shl(gpx, hist)

    rows.append(run_trial("zero_pol_shl", pol_shl))

    def roughness(gpx, hist):
        hist.SampleParameters["SurfRoughA"] = [0.5, True]
        hist.SampleParameters["SurfRoughB"] = [0.01, True]
        for key in ("SurfRoughA", "SurfRoughB"):
            gpx.set_Controls("parmMin", 0.0, f"{hist.id}::{key}")
            gpx.set_Controls("parmMax", 1.0, f"{hist.id}::{key}")

    rows.append(run_trial("zero_roughness", roughness))

    with open(WORK / "nuisance_trials.json", "w") as handle:
        json.dump(rows, handle, indent=2, sort_keys=True)


if __name__ == "__main__":
    main()
