#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
INITIAL = WORK / "initial"


def report(gpx: G2sc.G2Project, label: str) -> None:
    hist = gpx.histogram(0)
    print("\n###", label)
    print("residuals", json.dumps(hist.residuals, sort_keys=True))
    print("mass_fracs", hist.ComputeMassFracs())
    inst = hist.InstrumentParameters
    print(
        "instrument",
        {k: inst[k][1:] for k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)")},
    )
    print(
        "sample",
        {k: hist.SampleParameters[k] for k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
    )
    print("background", hist.data["Background"][0])
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        print(
            phase.name,
            "cell",
            {k: round(v, 8) for k, v in phase.get_cell().items()},
            "scale",
            hap["Scale"],
            "size",
            hap["Size"],
            "mustrain",
            hap["Mustrain"],
            "pref",
            hap["Pref.Ori."],
        )


def save_reopen(gpx: G2sc.G2Project, path: Path) -> G2sc.G2Project:
    gpx.save(str(path))
    return G2sc.G2Project(str(path))


def main() -> None:
    G2sc.SetPrintLevel("all")
    gpx = G2sc.G2Project(newgpx=str(WORK / "explore.gpx"))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(INITIAL / "cu_ka.instprm"),
        fmthint="comma/tab/semicolon",
    )
    for name, filename in (
        ("NiWO4", "NiWO4_P2c.cif"),
        ("WO3", "WO3_P21n.cif"),
        ("NiO", "NiO_Fm3m.cif"),
    ):
        gpx.add_phase(
            str(INITIAL / filename),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )

    gpx.set_Controls("cycles", 12)
    hist.clear_refinements({"Sample Parameters": ["Scale"]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [3500.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": True,
            }
        }
    )
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        # A neutral phase profile: effectively infinite crystallite size and zero strain.
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [1000.0, 1000.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])

    gpx.save()
    for phase in gpx.phases():
        gpx.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Scale")
    gpx.save()

    gpx.do_refinements([{}])
    report(gpx, "scales + 6-term smooth background")
    gpx = save_reopen(gpx, WORK / "stage1_scales_background.gpx")

    hist = gpx.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    gpx.do_refinements([{}])
    report(gpx, "plus one zero correction + cells")
    gpx = save_reopen(gpx, WORK / "stage2_zero_cells.gpx")

    hist = gpx.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    for key in ("U", "W", "X"):
        gpx.set_Controls("parmMin", 0.0, f"{hist.id}::{key}")
    gpx.save()
    gpx.do_refinements([{}])
    report(gpx, "plus common nonnegative U/W/X profile")
    gpx = save_reopen(gpx, WORK / "stage3_common_profile.gpx")

    # Full-range replay after save/reopen.
    gpx.do_refinements([{}])
    report(gpx, "stage 3 replay")
    gpx.save(str(WORK / "stage3_replayed.gpx"))


if __name__ == "__main__":
    main()
