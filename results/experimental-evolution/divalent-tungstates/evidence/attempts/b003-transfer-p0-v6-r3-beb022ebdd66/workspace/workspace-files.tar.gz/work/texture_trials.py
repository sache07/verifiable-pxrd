#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
BASE = WORK / "trial_zero_polarization.gpx"


AXES = {
    "NiWO4": [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1), (1, 1, 1)],
    "WO3": [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1), (1, 1, 1)],
    "NiO": [(1, 0, 0), (1, 1, 0), (1, 1, 1)],
}


def run_trial(phase_name: str, axis: tuple[int, int, int]) -> dict:
    axis_name = "".join(str(v) for v in axis)
    name = f"texture_{phase_name}_{axis_name}"
    out = WORK / f"trial_{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = gpx.histogram(0)
    phase = gpx.phase(phase_name)
    pref = phase.getHAPvalues(hist)["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = list(axis)
    gpx.set_Controls("parmMin", 0.2, f"{phase.id}:{hist.id}:MD")
    gpx.set_Controls("parmMax", 5.0, f"{phase.id}:{hist.id}:MD")
    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.do_refinements([{}])
    gpx.save()
    gpx = G2sc.G2Project(str(out))
    gpx.do_refinements([{}])
    gpx.save()
    hist = gpx.histogram(0)
    phase = gpx.phase(phase_name)
    pref = phase.getHAPvalues(hist)["Pref.Ori."]
    var = f"{phase.id}:{hist.id}:MD"
    cov = gpx.data["Covariance"]["data"]
    esd = None
    if var in cov["varyList"]:
        esd = float(cov["sig"][cov["varyList"].index(var)])
    result = {
        "trial": name,
        "phase": phase_name,
        "axis": list(axis),
        "Rwp": hist.residuals["wR"],
        "Rp": hist.residuals["R"],
        "MD": pref[1],
        "MD_esd": esd,
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
    }
    print(json.dumps(result, sort_keys=True))
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    rows = []
    for phase_name, axes in AXES.items():
        for axis in axes:
            rows.append(run_trial(phase_name, axis))
    with open(WORK / "texture_trials.json", "w") as handle:
        json.dump(rows, handle, indent=2, sort_keys=True)


if __name__ == "__main__":
    main()
