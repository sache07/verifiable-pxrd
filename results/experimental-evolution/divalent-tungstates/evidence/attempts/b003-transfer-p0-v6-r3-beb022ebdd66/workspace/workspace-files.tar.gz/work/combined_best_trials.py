#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
BASE = WORK / "source_fe_neutron.gpx"


def add_strain(gpx, hist) -> None:
    phase = gpx.phase("NiWO4")
    strain = phase.getHAPvalues(hist)["Mustrain"]
    strain[0] = "isotropic"
    strain[1] = [200.0, 200.0, 1.0]
    strain[2] = [True, False, False]
    gpx.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Mustrain;i")
    gpx.set_Controls("parmMax", 10000.0, f"{phase.id}:{hist.id}:Mustrain;i")


def add_texture(gpx, hist, phase_name: str, axis: tuple[int, int, int], start: float) -> None:
    phase = gpx.phase(phase_name)
    pref = phase.getHAPvalues(hist)["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = start
    pref[2] = True
    pref[3] = list(axis)
    gpx.set_Controls("parmMin", 0.5, f"{phase.id}:{hist.id}:MD")
    gpx.set_Controls("parmMax", 2.0, f"{phase.id}:{hist.id}:MD")


def run(name: str, strain: bool, niwo4_texture: bool, wo3_texture: bool) -> dict:
    out = WORK / f"combined_{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = gpx.histogram(0)
    if strain:
        add_strain(gpx, hist)
    if niwo4_texture:
        add_texture(gpx, hist, "NiWO4", (1, 0, 1), 0.983)
    if wo3_texture:
        add_texture(gpx, hist, "WO3", (1, 1, 0), 0.961)
    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.do_refinements([{}])
    gpx.save()
    gpx = G2sc.G2Project(str(out))
    gpx.do_refinements([{}])
    gpx.save()
    hist = gpx.histogram(0)
    cov = gpx.data["Covariance"]["data"]
    result = {
        "trial": name,
        "Rwp": hist.residuals["wR"],
        "Rp": hist.residuals["R"],
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "cells": {p.name: p.get_cell() for p in gpx.phases()},
        "instrument": {k: hist.InstrumentParameters[k][1] for k in ("Zero", "Polariz.", "U", "W", "X")},
        "phase_terms": {
            p.name: {
                "strain": p.getHAPvalues(hist)["Mustrain"][1][0],
                "strain_refined": p.getHAPvalues(hist)["Mustrain"][2][0],
                "MD": p.getHAPvalues(hist)["Pref.Ori."][1],
                "axis": p.getHAPvalues(hist)["Pref.Ori."][3],
                "texture_refined": p.getHAPvalues(hist)["Pref.Ori."][2],
            }
            for p in gpx.phases()
        },
        "special_esds": {
            v: float(s)
            for v, s in zip(cov.get("varyList", []), cov.get("sig", []))
            if any(token in v for token in ("Mustrain", ":MD"))
        },
    }
    print(json.dumps(result, sort_keys=True))
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    specs = [
        ("textures", False, True, True),
        ("strain_ni_texture", True, True, False),
        ("strain_wo_texture", True, False, True),
        ("all", True, True, True),
    ]
    rows = [run(*spec) for spec in specs]
    with open(WORK / "combined_best_trials.json", "w") as handle:
        json.dump(rows, handle, indent=2, sort_keys=True)


if __name__ == "__main__":
    main()
