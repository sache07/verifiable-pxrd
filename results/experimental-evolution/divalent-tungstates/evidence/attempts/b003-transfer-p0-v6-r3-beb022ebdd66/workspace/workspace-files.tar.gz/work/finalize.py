#!/usr/bin/env python3
"""Replay the selected refinement and export all submitted artifacts.

Every numerical deliverable is read from the same final.gpx state after a
save/reopen/full-range replay. This keeps the CIFs, phase fractions and profile
strictly synchronized with the submitted GSAS-II project.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "work" / "coords_ni_metals.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "NiWO4": {"formula": "NiWO4", "cif_path": "NiWO4.cif"},
    "WO3": {"formula": "WO3", "cif_path": "WO3.cif"},
    "NiO": {"formula": "NiO", "cif_path": "NiO.cif"},
}


def plain_array(values) -> np.ndarray:
    return np.asarray(np.ma.filled(values, np.nan), dtype=float)


def main() -> None:
    G2sc.SetPrintLevel("warn")

    # Copy the selected state to the submission project and reconverge it.
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    project.set_Controls("cycles", 12)
    project.save()
    project.do_refinements([{}])
    project.save()

    # Required replay from disk over the full stored histogram range.
    project = G2sc.G2Project(str(FINAL))
    project.do_refinements([{}])
    project.save()

    # Reopen the exact persisted state used for every export below.
    project = G2sc.G2Project(str(FINAL))
    histogram = project.histogram(0)
    profile = histogram.data["data"][1]
    two_theta, observed, weight, calculated, background, stored_difference = (
        plain_array(profile[index]) for index in range(6)
    )
    difference = observed - calculated
    if not np.allclose(
        difference,
        stored_difference,
        rtol=0.0,
        atol=1.0e-8,
        equal_nan=True,
    ):
        raise RuntimeError("GSAS-II stored difference profile is inconsistent")

    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "background_counts",
                "difference_counts",
            ]
        )
        writer.writerows(
            zip(two_theta, observed, calculated, background, difference)
        )

    fractions = histogram.ComputeMassFracs()
    fraction_sum = sum(value[0] for value in fractions.values())
    if not np.isclose(fraction_sum, 1.0, rtol=0.0, atol=1.0e-10):
        raise RuntimeError(f"Crystalline phase fractions sum to {fraction_sum}")

    phases = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        phase.export_CIF(str(ROOT / info["cif_path"]))
        fraction, fraction_esd = fractions[phase.name]
        phases.append(
            {
                "name": phase.name,
                "formula": info["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": info["cif_path"],
                "weight_fraction": float(fraction),
                "weight_fraction_standard_uncertainty": float(fraction_esd),
                "cell": {
                    key: float(value) for key, value in phase.get_cell().items()
                },
            }
        )

    residuals = histogram.residuals
    rwp = float(residuals["wR"])
    rexp = float(residuals["wRmin"])
    result = {
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "fractions_basis": "normalized over modeled crystalline phases",
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": rexp,
            "goodness_of_fit_Rwp_over_Rexp": rwp / rexp,
            "reduced_chi_squared": (rwp / rexp) ** 2,
            "Bragg_R_percent": float(residuals["Rb"]),
            "weighted_Bragg_R_percent": float(residuals["wRb"]),
            "n_profile_points": int(two_theta.size),
            "two_theta_range_deg": [float(two_theta[0]), float(two_theta[-1])],
        },
        "measurement": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelengths_angstrom": [1.540598, 1.544426],
            "Kalpha2_over_Kalpha1": 0.5,
        },
    }
    with (ROOT / "result.json").open("w") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
