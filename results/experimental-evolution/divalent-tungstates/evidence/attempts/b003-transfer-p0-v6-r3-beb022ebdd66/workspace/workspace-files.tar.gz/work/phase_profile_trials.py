#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
BASE = WORK / "trial_zero_polarization.gpx"


def run_trial(name: str, configure) -> dict:
    out = WORK / f"trial_{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    configure(gpx, gpx.histogram(0))
    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.do_refinements([{}])
    gpx.save()
    gpx = G2sc.G2Project(str(out))
    gpx.do_refinements([{}])
    gpx.save()
    hist = gpx.histogram(0)
    result = {
        "trial": name,
        "Rwp": hist.residuals["wR"],
        "Rp": hist.residuals["R"],
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "UWX": {k: hist.InstrumentParameters[k][1] for k in ("U", "W", "X")},
        "profiles": {
            p.name: {
                "size": p.getHAPvalues(hist)["Size"],
                "mustrain": p.getHAPvalues(hist)["Mustrain"],
            }
            for p in gpx.phases()
        },
    }
    print(json.dumps(result, sort_keys=True))
    return result


def configure_size(phase_name: str):
    def configure(gpx, hist):
        phase = gpx.phase(phase_name)
        hap = phase.getHAPvalues(hist)
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [1.0, 1.0, 1.0]
        hap["Size"][2] = [True, False, False]
        gpx.set_Controls("parmMin", 0.001, f"{phase.id}:{hist.id}:Size;i")
        gpx.set_Controls("parmMax", 10.0, f"{phase.id}:{hist.id}:Size;i")
    return configure


def configure_strain(phase_name: str):
    def configure(gpx, hist):
        phase = gpx.phase(phase_name)
        hap = phase.getHAPvalues(hist)
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [500.0, 500.0, 1.0]
        hap["Mustrain"][2] = [True, False, False]
        gpx.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Mustrain;i")
        gpx.set_Controls("parmMax", 10000.0, f"{phase.id}:{hist.id}:Mustrain;i")
    return configure


def main() -> None:
    G2sc.SetPrintLevel("warn")
    rows = []
    for phase_name in ("NiWO4", "WO3", "NiO"):
        rows.append(run_trial(f"size_{phase_name}", configure_size(phase_name)))
        rows.append(run_trial(f"strain_{phase_name}", configure_strain(phase_name)))
    with open(WORK / "phase_profile_trials.json", "w") as handle:
        json.dump(rows, handle, indent=2, sort_keys=True)


if __name__ == "__main__":
    main()
