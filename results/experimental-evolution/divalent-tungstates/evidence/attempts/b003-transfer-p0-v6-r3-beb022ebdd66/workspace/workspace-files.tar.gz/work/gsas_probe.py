#!/usr/bin/env python3
from __future__ import annotations

import pprint
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
INITIAL = WORK / "initial"


def main() -> None:
    G2sc.SetPrintLevel("warn")
    gpx = G2sc.G2Project(newgpx=str(WORK / "probe.gpx"))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(INITIAL / "cu_ka.instprm"),
        fmthint="comma/tab/semicolon",
    )
    for name, filename in (
        ("NiWO4", "NiWO4_P2c.cif"),
        ("WO3", "WO3_P21n.cif"),
        ("NiO", "NiO_Fm3m.cif"),
    ):
        gpx.add_phase(
            str(INITIAL / filename),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
    gpx.set_Controls("cycles", 8)
    gpx.save()

    print("histogram", hist.name)
    print("residuals", hist.residuals)
    print("limits", hist.data["Limits"])
    print("background")
    pprint.pp(hist.data["Background"])
    print("instrument")
    pprint.pp(hist.InstrumentParameters)
    print("sample")
    pprint.pp(hist.SampleParameters)
    for phase in gpx.phases():
        print("\nPHASE", phase.name)
        print("cell", phase.get_cell())
        print("general mass", phase.data["General"].get("Mass"))
        print("HAP")
        pprint.pp(phase.getHAPvalues(hist))
        print("atoms")
        for atom in phase.atoms():
            print(atom.label, atom.element, list(atom.coordinates), atom.occupancy, atom.uiso)


if __name__ == "__main__":
    main()
