#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
INITIAL = WORK / "initial"

MODELS = {
    "zn_old": ("NiWO4_P2c.cif", "WO3_P21n.cif"),
    "zn_neutron": ("NiWO4_P2c.cif", "WO3_neutron_P21c.cif"),
    "fe_old": ("NiWO4_from_FeWO4_P2c.cif", "WO3_P21n.cif"),
    "fe_neutron": ("NiWO4_from_FeWO4_P2c.cif", "WO3_neutron_P21c.cif"),
}


def build_and_refine(name: str, niwo4_file: str, wo3_file: str) -> dict:
    out = WORK / f"source_{name}.gpx"
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(INITIAL / "cu_ka.instprm"),
        fmthint="comma/tab/semicolon",
    )
    for phase_name, phase_file in (
        ("NiWO4", niwo4_file),
        ("WO3", wo3_file),
        ("NiO", "NiO_Fm3m.cif"),
    ):
        gpx.add_phase(
            str(INITIAL / phase_file),
            phasename=phase_name,
            histograms=[hist],
            fmthint="CIF",
        )
    gpx.set_Controls("cycles", 12)
    hist.clear_refinements({"Sample Parameters": ["Scale"]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [3500.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": True,
            }
        }
    )
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
        gpx.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Scale")
    gpx.save()
    gpx.do_refinements([{}])

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    gpx.do_refinements([{}])

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    for key in ("U", "W", "X"):
        gpx.set_Controls("parmMin", 0.0, f"{hist.id}::{key}")
    gpx.save()
    gpx.do_refinements([{}])

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    gpx.set_Controls("parmMin", 0.0, f"{hist.id}::Polariz.")
    gpx.set_Controls("parmMax", 1.0, f"{hist.id}::Polariz.")
    gpx.save()
    gpx.do_refinements([{}])
    gpx.save()

    # Exact replay from disk over the full measured range.
    gpx = G2sc.G2Project(str(out))
    gpx.do_refinements([{}])
    gpx.save()
    hist = gpx.histogram(0)
    cov = gpx.data["Covariance"]["data"]
    result = {
        "model": name,
        "Rwp": hist.residuals["wR"],
        "Rp": hist.residuals["R"],
        "GOF": (hist.residuals["wR"] / hist.residuals["wRmin"]) ** 2,
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "cells": {p.name: p.get_cell() for p in gpx.phases()},
        "instrument": {
            k: hist.InstrumentParameters[k][1]
            for k in ("Zero", "Polariz.", "U", "W", "X", "SH/L")
        },
        "max_shift_over_esd": cov.get("Max shft/sig"),
    }
    print(json.dumps(result, sort_keys=True))
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    rows = [build_and_refine(name, *files) for name, files in MODELS.items()]
    with open(WORK / "source_trials.json", "w") as handle:
        json.dump(rows, handle, indent=2, sort_keys=True)


if __name__ == "__main__":
    main()
