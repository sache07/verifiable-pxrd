#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
BASE = WORK / "combined_all.gpx"


def refine_atoms(phase, labels: list[str]) -> None:
    phase.set_refinements({"Atoms": {label: "X" for label in labels}})


def add_niwo4_restraints(phase) -> dict:
    phase.proj.data["Restraints"]["data"].setdefault(
        phase.name,
        {"Bond": {"wtFactor": 1.0, "Range": 1.1, "Bonds": [], "Use": True}},
    )
    phase.clearDistRestraint()
    oxygens = [a for a in phase.atoms() if a.element == "O"]
    counts = {
        "W_short": phase.addDistRestraint(["W1"], oxygens, 1.748, factor=1.04, ESD=0.02),
        "W_mid": phase.addDistRestraint(["W1"], oxygens, 1.889, factor=1.04, ESD=0.02),
        "W_long": phase.addDistRestraint(["W1"], oxygens, 2.100, factor=1.04, ESD=0.025),
        "Ni_short": phase.addDistRestraint(["Ni1"], oxygens, 2.021, factor=1.02, ESD=0.025),
        "Ni_long": phase.addDistRestraint(["Ni1"], oxygens, 2.135, factor=1.03, ESD=0.03),
    }
    phase.setDistRestraintWeight(100.0)
    return counts


def run(name: str, configure) -> dict:
    out = WORK / f"coords_{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    info = configure(gpx)
    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.do_refinements([{}])
    gpx.save()
    gpx = G2sc.G2Project(str(out))
    gpx.do_refinements([{}])
    gpx.save()
    hist = gpx.histogram(0)
    cov = gpx.data["Covariance"]["data"]
    result = {
        "trial": name,
        "Rwp": hist.residuals["wR"],
        "Rp": hist.residuals["R"],
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "atoms": {
            p.name: {
                a.label: {
                    "element": a.element,
                    "xyz": [float(v) for v in a.coordinates],
                    "flags": a.refinement_flags,
                }
                for a in p.atoms()
            }
            for p in gpx.phases()
        },
        "coordinate_esds": {
            v: float(s)
            for v, s in zip(cov.get("varyList", []), cov.get("sig", []))
            if "::dA" in v
        },
        "short_distances": {p.name: p.ShortDistances() for p in gpx.phases()},
        "configuration": info,
    }
    print(json.dumps(result, sort_keys=True))
    for phase in gpx.phases():
        phase.export_CIF(str(WORK / f"coords_{name}_{phase.name}.cif"))
    return result


def ni_metals(gpx):
    refine_atoms(gpx.phase("NiWO4"), ["Ni1", "W1"])
    return {}


def wo_w(gpx):
    refine_atoms(gpx.phase("WO3"), ["W1", "W2"])
    return {}


def both_metals(gpx):
    ni_metals(gpx)
    wo_w(gpx)
    return {}


def ni_all_unrestrained(gpx):
    phase = gpx.phase("NiWO4")
    refine_atoms(phase, [a.label for a in phase.atoms()])
    return {}


def ni_all_restrained(gpx):
    phase = gpx.phase("NiWO4")
    counts = add_niwo4_restraints(phase)
    refine_atoms(phase, [a.label for a in phase.atoms()])
    return {"restraint_counts": counts, "weight": 100.0}


def ni_oxygen_restrained(gpx):
    phase = gpx.phase("NiWO4")
    counts = add_niwo4_restraints(phase)
    refine_atoms(phase, ["O1", "O2"])
    return {"restraint_counts": counts, "weight": 100.0}


def main() -> None:
    G2sc.SetPrintLevel("warn")
    rows = [
        run("ni_all_restrained", ni_all_restrained),
        run("ni_oxygen_restrained", ni_oxygen_restrained),
    ]
    with open(WORK / "coordinate_restraint_trials.json", "w") as handle:
        json.dump(rows, handle, indent=2, sort_keys=True)


if __name__ == "__main__":
    main()
