#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
BASE = WORK / "source_fe_neutron.gpx"
AXES = {
    "NiWO4": [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1), (1, 1, 1)],
    "WO3": [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1), (1, 1, 1)],
    "NiO": [(1, 0, 0), (1, 1, 0), (1, 1, 1)],
}


def run(name: str, configure) -> dict:
    out = WORK / f"best_{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = gpx.histogram(0)
    configure(gpx, hist)
    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.do_refinements([{}])
    gpx.save()
    gpx = G2sc.G2Project(str(out))
    gpx.do_refinements([{}])
    gpx.save()
    hist = gpx.histogram(0)
    cov = gpx.data["Covariance"]["data"]
    result = {
        "trial": name,
        "Rwp": hist.residuals["wR"],
        "Rp": hist.residuals["R"],
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "UWX": {k: hist.InstrumentParameters[k][1] for k in ("U", "W", "X")},
        "phase_terms": {},
    }
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        result["phase_terms"][phase.name] = {
            "size": hap["Size"][1][0],
            "strain": hap["Mustrain"][1][0],
            "MD": hap["Pref.Ori."][1],
            "axis": hap["Pref.Ori."][3],
            "texture_refined": hap["Pref.Ori."][2],
        }
    result["special_esds"] = {
        v: float(s)
        for v, s in zip(cov.get("varyList", []), cov.get("sig", []))
        if any(token in v for token in ("Size", "Mustrain", ":MD"))
    }
    print(json.dumps(result, sort_keys=True))
    return result


def size_config(phase_name: str):
    def configure(gpx, hist):
        phase = gpx.phase(phase_name)
        size = phase.getHAPvalues(hist)["Size"]
        size[0] = "isotropic"
        size[1] = [1.0, 1.0, 1.0]
        size[2] = [True, False, False]
        gpx.set_Controls("parmMin", 0.001, f"{phase.id}:{hist.id}:Size;i")
        gpx.set_Controls("parmMax", 10.0, f"{phase.id}:{hist.id}:Size;i")
    return configure


def strain_config(phase_name: str):
    def configure(gpx, hist):
        phase = gpx.phase(phase_name)
        strain = phase.getHAPvalues(hist)["Mustrain"]
        strain[0] = "isotropic"
        strain[1] = [500.0, 500.0, 1.0]
        strain[2] = [True, False, False]
        gpx.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Mustrain;i")
        gpx.set_Controls("parmMax", 10000.0, f"{phase.id}:{hist.id}:Mustrain;i")
    return configure


def texture_config(phase_name: str, axis: tuple[int, int, int]):
    def configure(gpx, hist):
        phase = gpx.phase(phase_name)
        pref = phase.getHAPvalues(hist)["Pref.Ori."]
        pref[0] = "MD"
        pref[1] = 0.98 if phase_name == "NiO" else 1.0
        pref[2] = True
        pref[3] = list(axis)
        gpx.set_Controls("parmMin", 0.5, f"{phase.id}:{hist.id}:MD")
        gpx.set_Controls("parmMax", 2.0, f"{phase.id}:{hist.id}:MD")
    return configure


def main() -> None:
    G2sc.SetPrintLevel("warn")
    profile_rows = []
    for phase in ("NiWO4", "WO3", "NiO"):
        profile_rows.append(run(f"size_{phase}", size_config(phase)))
        profile_rows.append(run(f"strain_{phase}", strain_config(phase)))
    with open(WORK / "best_profile_trials.json", "w") as handle:
        json.dump(profile_rows, handle, indent=2, sort_keys=True)

    texture_rows = []
    for phase, axes in AXES.items():
        for axis in axes:
            code = "".join(str(v) for v in axis)
            texture_rows.append(run(f"texture_{phase}_{code}", texture_config(phase, axis)))
    with open(WORK / "best_texture_trials.json", "w") as handle:
        json.dump(texture_rows, handle, indent=2, sort_keys=True)


if __name__ == "__main__":
    main()
