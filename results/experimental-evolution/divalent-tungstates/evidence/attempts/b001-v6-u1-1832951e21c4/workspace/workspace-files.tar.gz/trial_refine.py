#!/usr/bin/env python3
"""Build and refine restrained GSAS-II trial inventories for this dataset."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent


PHASES = {
    "srwo4_srmoo4": ("SrWO4", ROOT / "candidates/srwo4_from_srmoo4.cif"),
    "srwo4_bawo4": ("SrWO4", ROOT / "candidates/srwo4_from_bawo4.cif"),
    "srwo4_cawo4": ("SrWO4", ROOT / "candidates/srwo4_from_cawo4.cif"),
    "wo3_pnma": ("WO3", ROOT / "candidates/wo3_pnma_2107312.cif"),
    "wo3_p21c_a": ("WO3", ROOT / "candidates/wo3_p21c_1528915.cif"),
    "wo3_p21c_b": ("WO3", ROOT / "candidates/wo3_p21c_2311041.cif"),
    "wo3_p1": ("WO3", ROOT / "candidates/wo3_p1_2106293.cif"),
    "srco3_pnma": ("SrCO3", ROOT / "candidates/srco3_pnma_9008198.cif"),
    "srco3_r3m": ("SrCO3", ROOT / "candidates/srco3_r3m_1539128.cif"),
    "sr3w2o9": ("Sr3W2O9", ROOT / "candidates/sr3w2o9_2311977.cif"),
}


def set_cell(phase, values):
    phase.data["General"]["Cell"][1:7] = values
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(values))


def neutralize_hap(phase, hist_name):
    hap = phase.data["Histograms"][hist_name]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Mustrain"][0] = "isotropic"
    # These values contribute even when their refinement flags are off.
    # Zero microstrain and the GSAS-II upper size limit are the neutral state.
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]


def summary(project):
    hist = project.histogram(0)
    result = {
        "residuals": hist.residuals,
        "sample": {
            key: hist.SampleParameters[key][0]
            for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Zero", "Polariz.")
        },
        "background": hist.Background[0],
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "scale_refine": hap["Scale"][1],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    try:
        result["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        result["mass_fraction_error"] = repr(exc)
    cov = project.data.get("Covariance", {}).get("data", {})
    result["varyList"] = list(cov.get("varyList", []))
    result["variables"] = [float(x) for x in cov.get("variables", [])]
    result["sigmas"] = [float(x) for x in cov.get("sig", [])]
    return result


def report(project, label):
    print("SUMMARY", label)
    print(json.dumps(summary(project), indent=2, default=lambda x: list(x)))


def build(outpath: Path, phase_keys):
    project = G2sc.G2Project(newgpx=str(outpath))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "cu_kalpha.instprm"),
        fmthint="comma",
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [1000.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": [1050.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            }
        }
    )
    for key in phase_keys:
        name, filename = PHASES[key]
        phase = project.add_phase(
            str(filename), phasename=name, histograms=[hist], fmthint="CIF"
        )
        if key.startswith("srwo4"):
            set_cell(phase, [5.394, 5.394, 11.903, 90.0, 90.0, 90.0])
        neutralize_hap(phase, hist.name)
        phase.data["Histograms"][hist.name]["Scale"] = [1.0, True]
    project.set_Controls("cycles", 8)
    project.save()
    return project


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phases", nargs="+")
    parser.add_argument("--profile", action="store_true")
    args = parser.parse_args()
    project = build(args.output, args.phases)
    project.refine()
    report(project, "scales-background")

    hist = project.histogram(0)
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine()
    report(project, "cells-shift")

    if args.profile:
        for name in ("U", "W", "X"):
            project.set_Controls("parmMin", 0.0, variable=f":0:{name}")
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
        project.refine()
        report(project, "common-profile")

    project.save()


if __name__ == "__main__":
    main()
