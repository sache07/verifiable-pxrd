#!/usr/bin/env python3
"""Re-challenge the Sr3W2O9 watch-list phase against the final common profile."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import neutralize_hap


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "trials/retex_srco3_0_0_1.gpx"
OUT = ROOT / "trials/watch_exact_final.gpx"

project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(OUT))
hist = project.histogram(0)
phase = project.add_phase(
    str(ROOT / "candidates/sr3w2o9_2311977.cif"),
    phasename="Sr3W2O9",
    histograms=[hist],
    fmthint="CIF",
)
neutralize_hap(phase, hist.name)
phase.data["Histograms"][hist.name]["Scale"] = [0.01, True]
phase_id = phase.data["pId"]
project.set_Controls("parmMin", 0.0, variable=f"{phase_id}:0:Scale")
project.set_Controls("cycles", 8)
project.save()
project.refine()
project.save()

replay = G2sc.G2Project(gpxfile=str(OUT))
replay.refine()
replay.save()
hist = replay.histogram(0)
phase = replay.phase("Sr3W2O9")
cov = replay.data.get("Covariance", {}).get("data", {})
values = dict(
    zip(
        cov.get("varyList", []),
        zip(cov.get("variables", []), cov.get("sig", [])),
    )
)
print("residuals", hist.residuals)
print("mass", hist.ComputeMassFracs())
print("stored scale", phase.data["Histograms"][hist.name]["Scale"])
print("covariance scale", values.get(f"{phase.data['pId']}:0:Scale"))
