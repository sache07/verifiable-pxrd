#!/usr/bin/env python3
"""Create the exact final GSAS-II project and derived submission files."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/retex_srco3_0_0_1.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "SrWO4": {
        "formula": "SrWO4",
        "cif": "SrWO4.cif",
        "model_origin": "scheelite CaWO4 COD 7219229 with Ca-to-Sr substitution",
    },
    "WO3": {
        "formula": "WO3",
        "cif": "WO3.cif",
        "model_origin": "COD 2311041",
    },
    "SrCO3": {
        "formula": "SrCO3",
        "cif": "SrCO3.cif",
        "model_origin": "COD 9008198",
    },
}


def scalar(value):
    """Convert NumPy scalar values into JSON-native values."""
    return value.item() if hasattr(value, "item") else value


# Save and replay the full-range refinement under the final filename. This
# makes final.gpx, rather than an intermediate trial, the project that produced
# every submitted value and export.
project = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
project.set_Controls("cycles", 8)
project.save()
project.refine()
project.save()

project = G2sc.G2Project(gpxfile=str(FINAL))
project.refine()
project.save()

# Reopen after the replay so all exports come from the serialized final.gpx.
project = G2sc.G2Project(gpxfile=str(FINAL))
hist = project.histogram(0)

mass_fractions = hist.ComputeMassFracs()
fraction_sum = sum(value[0] for value in mass_fractions.values())
if not math.isclose(fraction_sum, 1.0, rel_tol=0.0, abs_tol=1e-10):
    raise RuntimeError(f"Mass fractions do not sum to unity: {fraction_sum}")

phases = []
for phase in project.phases():
    info = PHASE_INFO[phase.name]
    cif_path = ROOT / info["cif"]
    phase.export_CIF(str(cif_path))
    fraction, sigma = mass_fractions[phase.name]
    cell = phase.get_cell()
    residuals = hist.residuals
    p_id = phase.data["pId"]
    phases.append(
        {
            "name": phase.name,
            "formula": info["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": info["cif"],
            "weight_fraction": scalar(fraction),
            "weight_fraction_percent": scalar(100.0 * fraction),
            "weight_fraction_statistical_esd": scalar(sigma),
            "weight_fraction_percent_statistical_esd": scalar(100.0 * sigma),
            "cell_angstrom_degrees": {
                "a": scalar(cell["length_a"]),
                "b": scalar(cell["length_b"]),
                "c": scalar(cell["length_c"]),
                "alpha": scalar(cell["angle_alpha"]),
                "beta": scalar(cell["angle_beta"]),
                "gamma": scalar(cell["angle_gamma"]),
                "volume_angstrom_cubed": scalar(cell["volume"]),
            },
            "phase_fit_statistics": {
                "r_f_percent": scalar(residuals[f"{p_id}:0:Rf"]),
                "r_f_squared_percent": scalar(residuals[f"{p_id}:0:Rf^2"]),
            },
            "model_origin": info["model_origin"],
        }
    )

x = np.asarray(hist.getdata("x"), dtype=float)
y_obs = np.asarray(hist.getdata("yobs"), dtype=float)
y_calc = np.asarray(hist.getdata("ycalc"), dtype=float)
y_bkg = np.asarray(hist.getdata("background"), dtype=float)
lower, upper = hist.data["Limits"][1]
# GSAS-II includes the first grid point just above the requested upper limit;
# reproduce its exact profile slice rather than applying a floating-point mask.
first = int(np.searchsorted(x, lower))
last = min(len(x), int(np.searchsorted(x, upper)) + 1)
use = slice(first, last)
difference = y_obs - y_calc

with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as handle:
    writer = csv.writer(handle)
    writer.writerow(
        [
            "two_theta_deg",
            "observed_counts",
            "calculated_counts",
            "difference_counts",
            "background_counts",
        ]
    )
    writer.writerows(
        zip(x[use], y_obs[use], y_calc[use], difference[use], y_bkg[use])
    )

r_wp = float(hist.residuals["wR"])
r_exp = float(hist.residuals["wRmin"])
gof = r_wp / r_exp
result = {
    "phases": phases,
    "fraction_basis": (
        "Normalized over the modeled crystalline phases; no amorphous or "
        "unmodeled fraction is quantified."
    ),
    "fit_statistics": {
        "r_wp_percent": r_wp,
        "r_p_percent": float(hist.residuals["R"]),
        "r_exp_percent": r_exp,
        "goodness_of_fit": gof,
        "reduced_chi_square": gof * gof,
        "r_bragg_percent": float(hist.residuals["Rb"]),
        "weighted_r_bragg_percent": float(hist.residuals["wRb"]),
        "durbin_watson": float(hist.data["data"][0]["Durbin-Watson"]),
        "refinement_range_two_theta_deg": [float(lower), float(upper)],
            "profile_points": int(last - first),
    },
    "project_path": "final.gpx",
    "profile_path": "fit.csv",
}
(ROOT / "result.json").write_text(
    json.dumps(result, indent=2, sort_keys=False) + "\n", encoding="utf-8"
)

print(json.dumps(result, indent=2))
