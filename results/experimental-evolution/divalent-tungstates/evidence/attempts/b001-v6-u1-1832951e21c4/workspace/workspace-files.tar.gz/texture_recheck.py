#!/usr/bin/env python3
"""Replay March-Dollase axis alternatives from a common GSAS-II project."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def axis_label(axis: list[int] | None) -> str:
    if axis is None:
        return "none"
    return "_".join("m" + str(-x) if x < 0 else str(x) for x in axis)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("phase")
    parser.add_argument("prefix", type=Path)
    parser.add_argument(
        "axes",
        nargs="+",
        help="Comma-separated h,k,l values; use 'none' to disable texture",
    )
    args = parser.parse_args()

    for item in args.axes:
        axis = None if item == "none" else [int(v) for v in item.split(",")]
        if axis is not None and len(axis) != 3:
            raise ValueError(f"Expected h,k,l, got {item!r}")
        out = args.prefix.with_name(args.prefix.name + "_" + axis_label(axis) + ".gpx")
        project = G2sc.G2Project(gpxfile=str(args.base), newgpx=str(out))
        hist = project.histogram(0)
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][hist.name]
        if axis is None:
            hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
        else:
            hap["Pref.Ori."][:4] = ["MD", 1.0, True, axis]
        project.set_Controls("cycles", 8)
        project.save()
        project.refine()
        project.save()

        # Reopen and replay to test that the solution is not an in-memory state.
        replay = G2sc.G2Project(gpxfile=str(out))
        replay.refine()
        replay.save()
        hist = replay.histogram(0)
        hap = replay.phase(args.phase).data["Histograms"][hist.name]
        print(
            "CASE",
            axis_label(axis),
            "Rwp",
            hist.residuals["wR"],
            "Rp",
            hist.residuals["R"],
            "MD",
            hap["Pref.Ori."][:4],
            "mass",
            hist.ComputeMassFracs(),
            flush=True,
        )


if __name__ == "__main__":
    main()
