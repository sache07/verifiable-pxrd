#!/usr/bin/env python3
"""Cross-seed shared nuisance terms between competing WO3 source models."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from incremental_broadening import reset_phase


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("target", type=Path)
    parser.add_argument("seed", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--axis", nargs=3, type=int, default=[1, 0, 0])
    parser.add_argument("--texture-axis", nargs=3, type=int)
    args = parser.parse_args()

    target = G2sc.G2Project(
        str(args.target.resolve()), newgpx=str(args.output.resolve())
    )
    seed = G2sc.G2Project(str(args.seed.resolve()))
    th, sh = target.histogram(0), seed.histogram(0)

    # Cross-seed only terms shared by both topology choices.
    th.data["Background"] = copy.deepcopy(sh.data["Background"])
    for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."):
        th.InstrumentParameters[key] = copy.deepcopy(sh.InstrumentParameters[key])
    for phase_name in ("MgWO4", "WO3", "MgO"):
        td = target.phase(phase_name).data["Histograms"][th.name]
        sd = seed.phase(phase_name).data["Histograms"][sh.name]
        td["Scale"][0] = sd["Scale"][0]
    for phase_name in ("MgWO4", "MgO"):
        td = target.phase(phase_name).data["Histograms"][th.name]
        sd = seed.phase(phase_name).data["Histograms"][sh.name]
        for key in ("Size", "Mustrain", "Pref.Ori."):
            td[key] = copy.deepcopy(sd[key])
    for phase_name in ("MgWO4", "MgO"):
        target.phase(phase_name).data["General"]["Cell"][1:8] = copy.deepcopy(
            seed.phase(phase_name).data["General"]["Cell"][1:8]
        )

    wo3 = target.phase("WO3")
    reset_phase(wo3, th.name)
    hap = wo3.data["Histograms"][th.name]
    seed_hap = seed.phase("WO3").data["Histograms"][sh.name]
    initial_i = max(1000.0, float(seed_hap["Mustrain"][1][0]))
    initial_a = max(1000.0, float(seed_hap["Mustrain"][1][1]))
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = initial_i
    hap["Mustrain"][1][1] = initial_a
    wo3.set_HAP_refinements(
        {
            "Mustrain": {
                "type": "uniaxial",
                "direction": args.axis,
                "refine": True,
            }
        }
    )
    for suffix in ("i", "a"):
        target.set_Controls(
            "parmMin", 0.0, variable=f"{wo3.id}:{th.id}:Mustrain;{suffix}"
        )
    if args.texture_axis is not None:
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = float(seed_hap["Pref.Ori."][1])
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(args.texture_axis)
        target.set_Controls(
            "parmMin", 0.2, variable=f"{wo3.id}:{th.id}:MD"
        )
        target.set_Controls(
            "parmMax", 5.0, variable=f"{wo3.id}:{th.id}:MD"
        )
    for phase in target.phases():
        phase.set_refinements({"Cell": True})
    target.set_Controls("cycles", 16)
    target.refine()
    target.refine()
    target.save()
    print(
        json.dumps(
            {
                "residuals": th.residuals,
                "fractions": th.ComputeMassFracs(),
                "WO3_cell": wo3.get_cell(),
                "WO3_mustrain": hap["Mustrain"],
                "instrument": {
                    key: th.InstrumentParameters[key]
                    for key in ("Zero", "U", "W", "X")
                },
            },
            indent=2,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
