#!/usr/bin/env python3
"""Challenge one phase width model while preserving accepted other terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def reset_phase(phase, histname: str) -> None:
    hap = phase.data["Histograms"][histname]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][1][2] = 1.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][2] = 1.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("checkpoint", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", choices=["MgWO4", "WO3", "MgO"])
    parser.add_argument(
        "mode", choices=["neutral", "size", "strain", "combined", "uniaxial"]
    )
    parser.add_argument("--axis", nargs=3, type=int, default=[0, 0, 1])
    args = parser.parse_args()

    project = G2sc.G2Project(
        str(args.checkpoint.resolve()), newgpx=str(args.output.resolve())
    )
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    prior_strain = phase.data["Histograms"][hist.name]["Mustrain"][1][0]
    reset_phase(phase, hist.name)
    hap = phase.data["Histograms"][hist.name]

    if args.mode in {"size", "combined"}:
        hap["Size"][1][0] = 1.0
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}
        )
        project.set_Controls(
            "parmMin", 0.01, variable=f"{phase.id}:{hist.id}:Size;i"
        )
        project.set_Controls(
            "parmMax", 10.0, variable=f"{phase.id}:{hist.id}:Size;i"
        )
    if args.mode in {"strain", "combined"}:
        hap["Mustrain"][1][0] = 500.0
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
        project.set_Controls(
            "parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Mustrain;i"
        )
    if args.mode == "uniaxial":
        initial = prior_strain if prior_strain > 0 else 1000.0
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = initial
        hap["Mustrain"][1][1] = initial
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "uniaxial",
                    "direction": args.axis,
                    "refine": True,
                }
            }
        )
        for suffix in ("i", "a"):
            project.set_Controls(
                "parmMin",
                0.0,
                variable=f"{phase.id}:{hist.id}:Mustrain;{suffix}",
            )

    project.set_Controls("cycles", 16)
    project.refine()
    project.refine()
    project.save()
    print(
        json.dumps(
            {
                "residuals": hist.residuals,
                "fractions": hist.ComputeMassFracs(),
                "profile": {
                    key: hist.InstrumentParameters[key]
                    for key in ("U", "W", "X", "Zero")
                },
                "selected_hap": {
                    "size": hap["Size"],
                    "mustrain": hap["Mustrain"],
                },
                "vary_list": project.get_VaryList(),
            },
            indent=2,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
