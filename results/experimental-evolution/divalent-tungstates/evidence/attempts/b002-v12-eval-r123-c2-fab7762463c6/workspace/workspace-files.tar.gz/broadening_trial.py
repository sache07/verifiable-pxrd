#!/usr/bin/env python3
"""Replay a GSAS-II checkpoint with reversible phase-broadening choices."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def neutralize(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][1][2] = 1.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def apply_mode(project: G2sc.G2Project, phase_name: str, mode: str) -> None:
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][hist.name]
    if mode in {"size", "combined"}:
        hap["Size"][1][0] = 1.0
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}
        )
        project.set_Controls(
            "parmMin", 0.01, variable=f"{phase.id}:{hist.id}:Size;i"
        )
        project.set_Controls(
            "parmMax", 10.0, variable=f"{phase.id}:{hist.id}:Size;i"
        )
    if mode in {"strain", "combined"}:
        hap["Mustrain"][1][0] = 500.0
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
        project.set_Controls(
            "parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Mustrain;i"
        )


def summarize(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "scale": hap["Scale"],
            "size": hap["Size"][1],
            "size_flags": hap["Size"][2],
            "mustrain": hap["Mustrain"][1],
            "mustrain_flags": hap["Mustrain"][2],
        }
    return {
        "residuals": hist.residuals,
        "fractions": hist.ComputeMassFracs(),
        "profile": {
            key: hist.InstrumentParameters[key]
            for key in ("U", "V", "W", "X", "Y", "SH/L", "Zero")
        },
        "phases": phases,
        "vary_list": project.get_VaryList(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("checkpoint", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", choices=["MgWO4", "WO3", "MgO", "none"])
    parser.add_argument("mode", choices=["neutral", "size", "strain", "combined"])
    args = parser.parse_args()

    project = G2sc.G2Project(
        str(args.checkpoint.resolve()), newgpx=str(args.output.resolve())
    )
    neutralize(project)
    if args.phase != "none" and args.mode != "neutral":
        apply_mode(project, args.phase, args.mode)
    project.set_Controls("cycles", 12)
    project.refine()
    project.refine()
    project.save()
    print(json.dumps(summarize(project), indent=2, default=str))


if __name__ == "__main__":
    main()
