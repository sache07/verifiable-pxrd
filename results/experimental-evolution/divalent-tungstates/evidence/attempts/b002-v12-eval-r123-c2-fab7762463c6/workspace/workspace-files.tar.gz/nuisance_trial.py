#!/usr/bin/env python3
"""Replay a checkpoint with one smooth-background/intensity correction trial."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("checkpoint", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "mode",
        choices=[
            "background",
            "polarization",
            "polarization_fixed",
            "roughness",
            "texture",
            "shl",
        ],
    )
    parser.add_argument("--order", type=int, default=8)
    parser.add_argument("--phase", choices=["MgWO4", "WO3", "MgO"])
    parser.add_argument("--axis", nargs=3, type=int, default=[0, 0, 1])
    args = parser.parse_args()

    project = G2sc.G2Project(
        str(args.checkpoint.resolve()), newgpx=str(args.output.resolve())
    )
    hist = project.histogram(0)
    if args.mode == "background":
        hist.set_refinements(
            {
                "Background": {
                    "type": "chebyschev-1",
                    "no. coeffs": args.order,
                    "refine": True,
                }
            }
        )
    elif args.mode == "polarization":
        hist.InstrumentParameters["Polariz."][1] = 0.7
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=f":{hist.id}:Polariz.")
    elif args.mode == "polarization_fixed":
        hist.InstrumentParameters["Polariz."][1] = 0.7
        hist.InstrumentParameters["Polariz."][2] = False
    elif args.mode == "roughness":
        hist.SampleParameters["SurfRoughA"] = [0.5, True]
        hist.SampleParameters["SurfRoughB"] = [0.01, True]
        project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:SurfRoughA")
        project.set_Controls("parmMax", 1.0, variable=f":{hist.id}:SurfRoughA")
        project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:SurfRoughB")
    elif args.mode == "texture":
        if args.phase is None:
            parser.error("--phase is required for texture")
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(args.axis)
        project.set_Controls(
            "parmMin", 0.2, variable=f"{phase.id}:{hist.id}:MD"
        )
        project.set_Controls(
            "parmMax", 5.0, variable=f"{phase.id}:{hist.id}:MD"
        )
    elif args.mode == "shl":
        hist.InstrumentParameters["SH/L"][1] = 0.002
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:SH/L")
        project.set_Controls("parmMax", 0.1, variable=f":{hist.id}:SH/L")

    project.set_Controls("cycles", 16)
    project.refine()
    project.refine()
    project.save()
    texture = {}
    for phase in project.phases():
        texture[phase.name] = phase.data["Histograms"][hist.name]["Pref.Ori."]
    print(
        json.dumps(
            {
                "residuals": hist.residuals,
                "fractions": hist.ComputeMassFracs(),
                "background": hist.Background,
                "instrument": {
                    key: hist.InstrumentParameters[key]
                    for key in ("Polariz.", "SH/L", "U", "W", "X", "Zero")
                },
                "sample": {
                    key: hist.SampleParameters[key]
                    for key in ("SurfRoughA", "SurfRoughB")
                },
                "texture": texture,
                "vary_list": project.get_VaryList(),
            },
            indent=2,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
