#!/usr/bin/env python3
"""Create and refine a reversible GSAS-II trial for the PXRD pattern."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
INSTRUMENT = ROOT / "instrument.instprm"

SOURCES = {
    "MgWO4": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/9/01/39/9013902.cif"
    ),
    "MgO": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/9/00/04/9000499.cif"
    ),
    "WO3_2311041": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/2/31/10/2311041.cif"
    ),
    "WO3_1528915": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/1/52/89/1528915.cif"
    ),
    "WO3_2106293": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/2/10/62/2106293.cif"
    ),
    "WO3_2107312": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/2/10/73/2107312.cif"
    ),
    "WO3_1563541": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/1/56/35/1563541.cif"
    ),
    "WO3_1521532": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/1/52/15/1521532.cif"
    ),
    "WO3_1521533": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/1/52/15/1521533.cif"
    ),
    "WO3_1004057": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/1/00/40/1004057.cif"
    ),
}


def neutralize_hap(phase, histname: str) -> None:
    hap = phase.data["Histograms"][histname]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][1][2] = 1.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][2] = 1.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]


def project_summary(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": list(hap["Scale"]),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    try:
        fractions = {
            key: [float(value[0]), float(value[1])]
            for key, value in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": str(exc)}
    return {
        "residuals": hist.residuals,
        "instrument": {
            key: list(value) if isinstance(value, list) else value
            for key, value in inst.items()
        },
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": phases,
        "mass_fractions": fractions,
        "vary_list": project.get_VaryList(),
    }


def run_trial(output: Path, wo3_key: str, include_mgo: bool) -> dict:
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(PATTERN), str(INSTRUMENT), fmthint="comma"
    )
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "refine": True,
            },
        }
    )
    # Reflection geometry: keep roughness neutral unless explicitly challenged.
    for key in ("SurfRoughA", "SurfRoughB"):
        if key in hist.SampleParameters:
            hist.SampleParameters[key][0] = 0.0
            hist.SampleParameters[key][1] = False
    # The absolute histogram scale is arbitrary; fixing it avoids exact
    # collinearity with the independently refined phase scales.
    hist.SampleParameters["Scale"][1] = False

    phase_specs = [("MgWO4", SOURCES["MgWO4"]), ("WO3", SOURCES[wo3_key])]
    if include_mgo:
        phase_specs.append(("MgO", SOURCES["MgO"]))
    for name, source in phase_specs:
        phase = project.add_phase(
            str(source), phasename=name, histograms=[hist], fmthint="CIF"
        )
        neutralize_hap(phase, hist.name)
        phase.data["Histograms"][hist.name]["Scale"] = [1.0, True]

    project.set_Controls("cycles", 12)
    # Stable common checkpoint: background/scales, then cells+one angular term,
    # then nonnegative low-dimensional profile terms.
    project.refine()
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()

    # Keep U, W and X physically nonnegative. V and Y remain fixed at zero.
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMin", 0.0, variable=":0:W")
    project.set_Controls("parmMin", 0.0, variable=":0:X")
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.refine()
    project.refine()
    project.save()
    return project_summary(project)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--wo3", choices=[key for key in SOURCES if key.startswith("WO3_")], default="WO3_2311041")
    parser.add_argument("--without-mgo", action="store_true")
    parser.add_argument("--summary", type=Path)
    args = parser.parse_args()
    summary = run_trial(args.output.resolve(), args.wo3, not args.without_mgo)
    rendered = json.dumps(summary, indent=2, default=lambda value: value.tolist() if isinstance(value, np.ndarray) else str(value))
    print(rendered)
    if args.summary:
        args.summary.write_text(rendered + "\n")


if __name__ == "__main__":
    main()
