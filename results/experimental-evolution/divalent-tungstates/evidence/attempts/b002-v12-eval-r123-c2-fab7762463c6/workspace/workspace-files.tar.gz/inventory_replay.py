#!/usr/bin/env python3
"""Replay phase removal or scale-seed challenges from a common checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("checkpoint", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", choices=["MgWO4", "WO3", "MgO"])
    parser.add_argument("mode", choices=["remove", "scale"])
    parser.add_argument("--factor", type=float, default=1.0)
    args = parser.parse_args()

    project = G2sc.G2Project(
        str(args.checkpoint.resolve()), newgpx=str(args.output.resolve())
    )
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    if args.mode == "remove":
        hap["Use"] = False
        hap["Scale"][1] = False
    else:
        hap["Scale"][0] *= args.factor
        hap["Scale"][1] = True
    project.set_Controls("cycles", 16)
    project.refine()
    project.refine()
    project.save()
    print(
        json.dumps(
            {
                "residuals": hist.residuals,
                "fractions": hist.ComputeMassFracs(),
                "selected_scale": hap["Scale"],
                "selected_use": hap["Use"],
            },
            indent=2,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
