#!/usr/bin/env python3
"""Freeze, replay, and export the final GSAS-II refinement deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CHECKPOINT = ROOT / "floop_bg10.gpx"
FINAL_GPX = ROOT / "final.gpx"
CIF_NAMES = {
    "MgWO4": "phase_mgwo4.cif",
    "WO3": "phase_wo3.cif",
    "MgO": "phase_mgo.cif",
}
FORMULAS = {"MgWO4": "MgWO4", "WO3": "WO3", "MgO": "MgO"}


def freeze_supported_model(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    x = hist.data["data"][1][0]
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "refine": True,
            },
        }
    )
    sample = hist.SampleParameters
    sample["Scale"][1] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][0] = 0.0
        sample[key][1] = False

    inst = hist.InstrumentParameters
    for key in ("V", "Y", "Z"):
        inst[key][1] = 0.0
        inst[key][2] = False
    inst["SH/L"][1] = 0.002
    inst["SH/L"][2] = False
    inst["I(L2)/I(L1)"][1] = 0.5
    inst["I(L2)/I(L1)"][2] = False
    for key in ("U", "W", "X", "Zero", "Polariz."):
        inst[key][2] = True

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        hap["Scale"][1] = True
        project.set_Controls(
            "parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale"
        )
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][1][2] = 1.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]

        if phase.name == "WO3":
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][2] = [True, True, False]
            hap["Mustrain"][3] = [1, 0, 0]
            for suffix in ("i", "a"):
                project.set_Controls(
                    "parmMin",
                    0.0,
                    variable=f"{phase.id}:{hist.id}:Mustrain;{suffix}",
                )
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [1, 1, 0]
        else:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][1][2] = 1.0
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
            if phase.name == "MgWO4":
                hap["Pref.Ori."][0] = "MD"
                hap["Pref.Ori."][2] = True
                hap["Pref.Ori."][3] = [0, 1, 0]
            else:
                hap["Pref.Ori."][0] = "MD"
                hap["Pref.Ori."][1] = 1.0
                hap["Pref.Ori."][2] = False
                hap["Pref.Ori."][3] = [0, 0, 1]

        if hap["Pref.Ori."][2]:
            project.set_Controls(
                "parmMin", 0.2, variable=f"{phase.id}:{hist.id}:MD"
            )
            project.set_Controls(
                "parmMax", 5.0, variable=f"{phase.id}:{hist.id}:MD"
            )

    project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:U")
    project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:W")
    project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:X")
    project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=f":{hist.id}:Polariz.")
    project.set_Controls("cycles", 20)


def export_profile(hist, path: Path) -> None:
    x, observed, _weights, calculated, _background, _difference = hist.data[
        "data"
    ][1]
    with path.open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "difference"]
        )
        for values in zip(x, observed, calculated, observed - calculated):
            writer.writerow([f"{float(value):.10g}" for value in values])


def export_result(project: G2sc.G2Project, path: Path) -> dict:
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    total = sum(value[0] for value in fractions.values())
    x, observed, weights, calculated, _background, _difference = hist.data[
        "data"
    ][1]
    limits = hist.data["Limits"][1]
    mask = (x >= limits[0]) & (x <= limits[1])
    chi_square = float(np.sum(weights[mask] * (observed[mask] - calculated[mask]) ** 2))
    n_parameters = len(project.get_VaryList())
    n_observations = int(np.count_nonzero(mask))
    residuals = hist.residuals

    phases = []
    for phase in project.phases():
        value, esd = fractions[phase.name]
        cell = phase.get_cell()
        phases.append(
            {
                "name": phase.name,
                "formula": FORMULAS[phase.name],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": CIF_NAMES[phase.name],
                "weight_fraction": float(value / total),
                "weight_fraction_esd": float(esd / total),
                "cell": {key: float(number) for key, number in cell.items()},
                "R_F_percent": float(residuals[f"{phase.id}:{hist.id}:Rf"]),
                "R_F2_percent": float(residuals[f"{phase.id}:{hist.id}:Rf^2"]),
            }
        )

    result = {
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(residuals["wR"] / residuals["wRmin"]),
            "chi_square": chi_square,
            "reduced_chi_square": float(
                chi_square / (n_observations - n_parameters)
            ),
            "n_observations": n_observations,
            "n_refined_parameters": n_parameters,
            "two_theta_min_deg": float(limits[0]),
            "two_theta_max_deg": float(limits[1]),
        },
        "profile_path": "fit.csv",
        "project_path": "final.gpx",
    }
    path.write_text(json.dumps(result, indent=2) + "\n")
    return result


def main() -> None:
    project = G2sc.G2Project(str(CHECKPOINT), newgpx=str(FINAL_GPX))
    freeze_supported_model(project)
    project.refine()
    project.refine()
    project.save()

    # Required reopen/replay of the exact full-range project.
    project = G2sc.G2Project(str(FINAL_GPX))
    freeze_supported_model(project)
    project.refine()
    project.save()

    for phase in project.phases():
        phase.export_CIF(str(ROOT / CIF_NAMES[phase.name]))
    export_profile(project.histogram(0), ROOT / "fit.csv")
    result = export_result(project, ROOT / "result.json")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
