from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "profile_X.gpx"
OUT = ROOT / ".tmp" / "profile_X_SHL.gpx"


def main():
    gpx = G2sc.G2Project(str(BASE), newgpx=str(OUT))
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    inst["SH/L"][0] = inst["SH/L"][1] = 0.002
    inst["SH/L"][2] = True
    inst["X"][2] = True
    for key in ["U", "V", "W", "Y", "Z", "Zero"]:
        inst[key][2] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"][1] = True
    gpx.set_Controls("cycles", 12)
    gpx.set_Controls("parmMin", 0.002, variable=":0:SH/L")
    gpx.set_Controls("parmMax", 0.1, variable=":0:SH/L")
    recipe = {
        "Background": {"refine": True},
        "Scale": True,
        "Cell": True,
        "Sample Parameters": ["Shift"],
        "Instrument Parameters": ["X", "SH/L"],
    }
    gpx.do_refinements([{"set": recipe}, {}, {}])
    gpx.save()
    cov = gpx.data["Covariance"]["data"]
    names = list(cov.get("varyList", []))
    mat = np.asarray(cov.get("covMatrix", []))
    corr_rows = []
    if mat.size:
        sd = np.sqrt(np.maximum(np.diag(mat), 0))
        corr = mat / np.outer(sd, sd)
        for i in range(len(names)):
            for j in range(i):
                if ("SH/L" in names[i] or "SH/L" in names[j]) and abs(corr[i, j]) >= 0.8:
                    corr_rows.append([names[j], names[i], float(corr[i, j])])
    print("SHL_RESULT", json.dumps({
        "residuals": hist.residuals,
        "instrument": {k: inst[k] for k in ["U", "V", "W", "X", "Y", "Z", "SH/L"]},
        "shift": hist.SampleParameters["Shift"],
        "mass_fractions": hist.ComputeMassFracs(),
        "correlations": corr_rows,
    }, default=float, sort_keys=True))


if __name__ == "__main__":
    main()
