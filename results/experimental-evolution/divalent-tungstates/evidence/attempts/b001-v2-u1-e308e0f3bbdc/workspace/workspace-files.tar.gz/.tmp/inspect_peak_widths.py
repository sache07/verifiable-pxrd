from pathlib import Path
import numpy as np
from scipy.signal import find_peaks, peak_widths, savgol_filter

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
GPX = ROOT / ".tmp" / "accepted_profile_wo3_mn3o4.gpx"


def main():
    gpx = G2sc.G2Project(str(GPX))
    hist = gpx.histogram(0)
    x = np.asarray(hist.getdata("X"))
    raw_signal = np.asarray(hist.getdata("Yobs")) - np.asarray(hist.getdata("Background"))
    signal = savgol_filter(raw_signal, 9, 3)
    peaks, props = find_peaks(signal, prominence=80, distance=8)
    widths = peak_widths(signal, peaks, rel_height=0.5)
    dx = float(np.median(np.diff(x)))
    peak_x = x[peaks]
    peak_w = widths[0] * dx
    refs_by_phase = {}
    for phase, data in hist.data["Reflection Lists"].items():
        refs = np.asarray(data["RefList"])
        proxy = np.maximum(refs[:, 9] * refs[:, 11], 0)
        proxy /= max(float(proxy.max()), 1.0)
        refs_by_phase[phase] = (refs, proxy)
    for phase, (refs, proxy) in refs_by_phase.items():
        print("PHASE", phase)
        order = np.argsort(proxy)[::-1]
        shown = 0
        for i in order:
            pos = refs[i, 5]
            if not 12 <= pos <= 90 or proxy[i] < 0.025:
                continue
            j = int(np.argmin(np.abs(peak_x - pos)))
            if abs(peak_x[j] - pos) > 0.15:
                continue
            other_dist = 99.0
            for other, (orefs, oproxy) in refs_by_phase.items():
                if other == phase:
                    continue
                mask = oproxy >= 0.025
                if np.any(mask):
                    other_dist = min(other_dist, float(np.min(np.abs(orefs[mask, 5] - pos))))
            hkl = tuple(int(v) for v in refs[i, :3])
            print(f"  {hkl!s:>12} calc={pos:7.3f} relI={proxy[i]:6.3f} obs={peak_x[j]:7.3f} FWHM={peak_w[j]:6.3f} other={other_dist:6.3f} sig={refs[i,6]:6.2f} gam={refs[i,7]:6.2f}")
            shown += 1
            if shown >= 14:
                break


if __name__ == "__main__":
    main()
