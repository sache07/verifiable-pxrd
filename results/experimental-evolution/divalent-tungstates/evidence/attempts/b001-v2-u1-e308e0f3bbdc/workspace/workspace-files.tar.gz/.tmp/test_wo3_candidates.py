from pathlib import Path
import json
import numpy as np
from scipy.signal import find_peaks

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
CIF_ROOT = Path("<RUN>/resources/b001-c04/cif")
BASE = ROOT / ".tmp" / "trial_main.gpx"
CANDIDATES = ["2311041", "2106293", "2107312", "1521532", "1521533", "1004057", "1563541"]


def cif_path(cod_id):
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize(phase, hist):
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [3.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][4] = [0.0 for _ in hap["Mustrain"][4]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]


def residual_peaks(hist):
    x = np.asarray(hist.getdata("X"))
    r = np.asarray(hist.getdata("Residual"))
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi)
    pks, props = find_peaks(r[use], prominence=100, distance=8)
    xx, rr = x[use][pks], r[use][pks]
    order = np.argsort(props["prominences"])[::-1]
    return [(round(float(xx[i]), 5), round(float(rr[i]), 1), round(float(props["prominences"][i]), 1)) for i in order[:18]]


def main():
    for cod_id in CANDIDATES:
        out = ROOT / ".tmp" / f"wo3_{cod_id}.gpx"
        gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
        hist = gpx.histogram(0)
        phase = gpx.add_phase(
            str(cif_path(cod_id)),
            phasename=f"WO3_{cod_id}",
            histograms=[hist],
            fmthint="CIF",
        )
        neutralize(phase, hist)
        hist.SampleParameters["Scale"] = [1.0, False]
        gpx.set_Controls("cycles", 10)
        gpx.save()
        recipe = {"set": {"Background": {"refine": True}, "Scale": True, "Cell": True, "Instrument Parameters": ["Zero"]}}
        try:
            gpx.do_refinements([recipe, {}, {}])
            gpx.save()
            result = {
                "cod_id": cod_id,
                "residuals": hist.residuals,
                "phases": {
                    ph.name: {
                        "composition": ph.composition,
                        "cell": ph.get_cell(),
                        "scale": ph.data["Histograms"][hist.name]["Scale"],
                    }
                    for ph in gpx.phases()
                },
                "mass_fractions": hist.ComputeMassFracs(),
                "zero": hist.InstrumentParameters["Zero"],
                "residual_peaks": residual_peaks(hist),
            }
            print("CANDIDATE_RESULT", json.dumps(result, default=float, sort_keys=True))
        except Exception as err:
            print("CANDIDATE_ERROR", cod_id, type(err).__name__, str(err))


if __name__ == "__main__":
    main()
