from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "accepted_profile_wo3_mn3o4.gpx"
BRANCHES = {
    "cations": ["Mn1", "W1"],
    "all": ["Mn1", "W1", "O1", "O2"],
}


def correlations(gpx):
    cov = gpx.data["Covariance"]["data"]
    names = list(cov.get("varyList", []))
    mat = np.asarray(cov.get("covMatrix", []))
    rows = []
    if not mat.size:
        return rows
    sd = np.sqrt(np.maximum(np.diag(mat), 0))
    corr = mat / np.outer(sd, sd)
    for i in range(len(names)):
        for j in range(i):
            if not (names[i].startswith("0::A") or names[j].startswith("0::A")):
                continue
            if abs(corr[i, j]) >= 0.80:
                rows.append([names[j], names[i], float(corr[i, j])])
    return sorted(rows, key=lambda row: abs(row[2]), reverse=True)


def run(tag, labels):
    out = ROOT / ".tmp" / f"atomic_{tag}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    for atom in phase.atoms():
        atom.refinement_flags = "X" if atom.label in labels else " "
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"][1] = True
    inst = hist.InstrumentParameters
    for key in ["U", "V", "W", "Y", "Z", "Zero", "SH/L"]:
        inst[key][2] = False
    inst["X"][2] = True
    gpx.set_Controls("cycles", 18)
    recipe = {
        "Background": {"refine": True},
        "Scale": True,
        "Cell": True,
        "Sample Parameters": ["Shift"],
        "Instrument Parameters": ["X"],
    }
    gpx.do_refinements([{"set": recipe}, {}, {}, {}])
    gpx.save()
    cif = ROOT / ".tmp" / f"atomic_{tag}.cif"
    phase.export_CIF(str(cif))
    cov = gpx.data["Covariance"]["data"]
    vary = list(cov.get("varyList", []))
    sig = list(cov.get("sig", []))
    atom_sigmas = {name: float(s) for name, s in zip(vary, sig) if name.startswith("0::A")}
    print("ATOMIC_RESULT", json.dumps({
        "tag": tag,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "cell": phase.get_cell(),
        "coordinates": {a.label: a.coordinates for a in phase.atoms()},
        "atom_sigmas": atom_sigmas,
        "correlations": correlations(gpx),
        "frozen": [str(x) for x in gpx.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }, default=float, sort_keys=True))


def main():
    for tag, labels in BRANCHES.items():
        run(tag, labels)


if __name__ == "__main__":
    main()
