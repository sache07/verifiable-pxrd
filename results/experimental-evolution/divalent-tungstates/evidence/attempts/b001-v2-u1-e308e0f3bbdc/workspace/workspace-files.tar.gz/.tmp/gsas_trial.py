from pathlib import Path
import json
import numpy as np
from scipy.signal import find_peaks

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIpwd as G2pwd


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / ".tmp" / "trial_main.gpx"


def summarize(gpx, label):
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    inst = hist.InstrumentParameters
    hap = phase.data["Histograms"][hist.name]
    print("SUMMARY", label)
    print(" residuals", json.dumps(hist.residuals, sort_keys=True))
    print(" cell", phase.get_cell())
    print(" scale", hap["Scale"])
    print(" inst", {k: inst[k] for k in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)"]})
    print(" sample", hist.SampleParameters)
    print(" size", hap["Size"])
    print(" mustrain", hap["Mustrain"])
    x = np.asarray(hist.getdata("X"))
    resid = np.asarray(hist.getdata("Residual"))
    lo, hi = hist.data["Limits"][1]
    sel = (x >= lo) & (x <= hi)
    pks, props = find_peaks(resid[sel], prominence=100, distance=8)
    xx = x[sel][pks]
    rr = resid[sel][pks]
    order = np.argsort(props["prominences"])[::-1]
    print(" residual_peaks", [(round(float(xx[i]), 5), round(float(rr[i]), 1), round(float(props["prominences"][i]), 1)) for i in order[:30]])


def main():
    gpx = G2sc.G2Project(newgpx=str(OUT))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / ".tmp" / "cu_ka.instprm"),
        fmthint="comma",
    )
    phase = gpx.add_phase(
        str(ROOT / ".tmp" / "mnwo4_parent.cif"),
        phasename="MnWO4_wolframite",
        histograms=[hist],
        fmthint="CIF",
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    hist.Background[0] = ["chebyschev-1", True, 12] + [0.0] * 12
    inst = hist.InstrumentParameters
    for key, val in {"Zero": -0.416, "U": 0.0, "V": 0.0, "W": 25.0, "X": 0.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.002}.items():
        inst[key][0] = val
        inst[key][1] = val
        inst[key][2] = False
    hap = phase.data["Histograms"][hist.name]
    hap["Size"] = ["isotropic", [1000.0, 1000.0, 1.0], [False, False, False], [0, 0, 1], [1000.0, 1000.0, 1000.0, 0.0, 0.0, 0.0], [False] * 6]
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][4] = [0.0 for _ in hap["Mustrain"][4]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Scale"] = [1.0, True]
    hist.SampleParameters["Scale"] = [1.0, False]
    gpx.set_Controls("cycles", 12)
    gpx.save()

    # Refit the broad background and phase scale at the diagnostic cell.
    gpx.do_refinements([{"set": {"Background": {"refine": True}, "Scale": True}}])
    summarize(gpx, "background_scale")

    # Refit background, scale, one common angular correction, and cell together.
    gpx.do_refinements([{"set": {"Background": {"refine": True}, "Scale": True, "Cell": True, "Instrument Parameters": ["Zero"]}}])
    summarize(gpx, "cell_zero")
    gpx.do_refinements([{}])
    summarize(gpx, "reconverged")
    gpx.save()


if __name__ == "__main__":
    main()
