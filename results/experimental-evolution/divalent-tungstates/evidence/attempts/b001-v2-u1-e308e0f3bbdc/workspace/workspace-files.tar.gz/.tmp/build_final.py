from pathlib import Path
import csv
import json
import math

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "atomic_cations.gpx"
FINAL = ROOT / "final.gpx"
PHASE_OUTPUTS = [
    ("MnWO4 (wolframite)", "MnWO4", "phase_1_MnWO4.cif"),
    ("WO3 (monoclinic)", "WO3", "phase_2_WO3.cif"),
    ("Mn3O4 (hausmannite)", "Mn3O4", "phase_3_Mn3O4.cif"),
]


def enforce_clean_model(gpx):
    hist = gpx.histogram(0)
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"][1] = True
    for key in ["U", "V", "W", "Y", "Z", "Zero", "SH/L"]:
        hist.InstrumentParameters[key][2] = False
    hist.InstrumentParameters["X"][2] = True
    for index, phase in enumerate(gpx.phases()):
        # The nonstandard monoclinic WO3 metric (beta about 136 degrees) gives
        # a 0.93 correlation between two reciprocal-cell terms after it has
        # stabilized. Preserve that converged cell and omit it from the final
        # covariance replay; the other two phase cells remain active.
        phase.data["General"]["Cell"][0] = index != 1
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        if index in (1, 2):
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][2][0] = True
        for atom in phase.atoms():
            atom.refinement_flags = "X" if index == 0 and atom.label in ("Mn1", "W1") else " "
    controls = gpx.data["Controls"]["data"]
    controls.setdefault("parmFrozen", {})["FrozenList"] = []
    controls["shift factor"] = 1.0
    gpx.set_Controls("cycles", 18)
    return hist


def run_replay():
    gpx = G2sc.G2Project(str(BASE), newgpx=str(FINAL))
    enforce_clean_model(gpx)
    recipe = {
        "Background": {"refine": True},
        "Scale": True,
        "Cell": True,
        "Sample Parameters": ["Shift"],
        "Instrument Parameters": ["X"],
    }
    gpx.do_refinements([{"set": recipe}, {}, {}, {}])
    gpx.save()

    # Fresh disk replay over the complete measured range using only persisted
    # structural/profile state. This guards against improvements from stale arrays.
    replay = G2sc.G2Project(str(FINAL))
    enforce_clean_model(replay)
    replay.do_refinements([{}, {}, {}])
    replay.save()


def export_outputs():
    gpx = G2sc.G2Project(str(FINAL))
    hist = gpx.histogram(0)
    phases = gpx.phases()
    fractions = hist.ComputeMassFracs()
    result_phases = []
    for index, (phase, (display_name, formula, cif_name)) in enumerate(zip(phases, PHASE_OUTPUTS)):
        phase.export_CIF(str(ROOT / cif_name))
        value, sigma = fractions[phase.name]
        cell = phase.get_cell()
        result_phases.append({
            "name": display_name,
            "formula": formula,
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": cif_name,
            "weight_fraction": float(value),
            "weight_fraction_formal_esd": float(sigma),
            "weight_percent": float(100.0 * value),
            "cell": {key: float(cell[key]) for key in [
                "length_a", "length_b", "length_c",
                "angle_alpha", "angle_beta", "angle_gamma", "volume"
            ]},
            "R_F_percent": float(hist.residuals[f"{index}:0:Rf"]),
            "R_F_squared_percent": float(hist.residuals[f"{index}:0:Rf^2"]),
        })

    x = np.asarray(hist.getdata("X"), dtype=float)
    observed = np.asarray(hist.getdata("Yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("Ycalc"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)
    difference = observed - calculated
    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "two_theta_deg", "observed_counts", "calculated_counts",
            "difference_counts", "background_counts"
        ])
        for row in zip(x, observed, calculated, difference, background):
            writer.writerow([f"{row[0]:.8f}"] + [f"{value:.8f}" for value in row[1:]])

    rvals = gpx.data["Covariance"]["data"]["Rvals"]
    dof = int(rvals["Nobs"] - rvals["Nvars"])
    fit_statistics = {
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "Rexp_percent": float(hist.residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "reduced_chi_squared": float(rvals["chisq"] / dof),
        "number_of_observations": int(rvals["Nobs"]),
        "number_of_refined_parameters": int(rvals["Nvars"]),
        "degrees_of_freedom": dof,
    }
    payload = {
        "phases": result_phases,
        "weight_fraction_normalization": "normalized over the modeled crystalline phases; sum = 1",
        "fit_statistics": fit_statistics,
        "profile_path": "fit.csv",
        "gsasii_project_path": "final.gpx",
    }
    with (ROOT / "result.json").open("w") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")

    summary = {
        "fit_statistics": fit_statistics,
        "fractions": {item["formula"]: item["weight_fraction"] for item in result_phases},
        "fraction_esds": {item["formula"]: item["weight_fraction_formal_esd"] for item in result_phases},
        "sample_shift_micrometres": float(hist.SampleParameters["Shift"][0]),
        "instrument_X": float(hist.InstrumentParameters["X"][1]),
        "mustrain": {
            phase.name: float(phase.data["Histograms"][hist.name]["Mustrain"][1][0])
            for phase in phases
        },
        "cells": {item["formula"]: item["cell"] for item in result_phases},
        "limits": hist.data["Limits"],
    }
    print("FINAL_RESULT", json.dumps(summary, sort_keys=True))


def main():
    run_replay()
    export_outputs()


if __name__ == "__main__":
    main()
