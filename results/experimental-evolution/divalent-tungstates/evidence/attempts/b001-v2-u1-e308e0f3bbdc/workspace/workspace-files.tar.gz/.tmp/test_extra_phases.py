from pathlib import Path
import json
import numpy as np
from scipy.signal import find_peaks

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
CIF_ROOT = Path("<RUN>/resources/b001-c04/cif")
BASE = ROOT / ".tmp" / "wo3_2311041.gpx"
CANDIDATES = {
    "Mn3O4_hausmannite": "9001963",
    "Mn2O3_bixbyite": "1514230",
    "Mn3WO6": "2002703",
    "MnO_rocksalt": "1514108",
}


def cif_path(cod_id):
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize(phase, hist):
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.2, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][4] = [0.0 for _ in hap["Mustrain"][4]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]


def top_residuals(hist):
    x = np.asarray(hist.getdata("X"))
    r = np.asarray(hist.getdata("Residual"))
    pks, props = find_peaks(r, prominence=100, distance=8)
    order = np.argsort(props["prominences"])[::-1]
    return [(round(float(x[pks[i]]), 5), round(float(r[pks[i]]), 1), round(float(props["prominences"][i]), 1)) for i in order[:15]]


def main():
    for name, cod_id in CANDIDATES.items():
        out = ROOT / ".tmp" / f"extra_{cod_id}.gpx"
        gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
        hist = gpx.histogram(0)
        phase = gpx.add_phase(str(cif_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF")
        neutralize(phase, hist)
        hist.SampleParameters["Scale"] = [1.0, False]
        gpx.set_Controls("cycles", 10)
        gpx.save()
        recipe = {"set": {"Background": {"refine": True}, "Scale": True, "Cell": True, "Instrument Parameters": ["Zero"]}}
        try:
            gpx.do_refinements([recipe, {}, {}])
            gpx.save()
            result = {
                "candidate": name,
                "cod_id": cod_id,
                "residuals": hist.residuals,
                "mass_fractions": hist.ComputeMassFracs(),
                "phases": {
                    ph.name: {
                        "cell": ph.get_cell(),
                        "scale": ph.data["Histograms"][hist.name]["Scale"],
                    }
                    for ph in gpx.phases()
                },
                "top_residuals": top_residuals(hist),
            }
            print("EXTRA_RESULT", json.dumps(result, default=float, sort_keys=True))
        except Exception as err:
            print("EXTRA_ERROR", cod_id, type(err).__name__, str(err))


if __name__ == "__main__":
    main()
