from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "extra_9001963.gpx"


def run(mode):
    out = ROOT / ".tmp" / f"angular_{mode}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = gpx.histogram(0)
    hist.SampleParameters["Scale"] = [1.0, False]
    gpx.set_Controls("cycles", 12)
    if mode == "zero":
        hist.InstrumentParameters["Zero"][2] = True
        hist.SampleParameters["Shift"] = [0.0, False]
        angular = {"Instrument Parameters": ["Zero"]}
    else:
        hist.InstrumentParameters["Zero"] = [0.0, 0.0, False]
        hist.SampleParameters["Shift"] = [830.0, True]
        angular = {"Sample Parameters": ["Shift"]}
    recipe = {"Background": {"refine": True}, "Scale": True, "Cell": True, **angular}
    gpx.save()
    gpx.do_refinements([{"set": recipe}, {}, {}])
    gpx.save()
    result = {
        "mode": mode,
        "residuals": hist.residuals,
        "zero": hist.InstrumentParameters["Zero"],
        "shift": hist.SampleParameters["Shift"],
        "mass_fractions": hist.ComputeMassFracs(),
        "cells": {p.name: p.get_cell() for p in gpx.phases()},
    }
    print("ANGULAR_RESULT", json.dumps(result, default=float, sort_keys=True))


def main():
    run("zero")
    run("displacement")


if __name__ == "__main__":
    main()
