from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "parent_ZnWO4_1520641.gpx"


def neutralize(gpx):
    hist_name = gpx.histogram(0).name
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist_name]
        size = hap["Size"]
        size[0] = "isotropic"
        size[1][0] = 10.0
        size[1][2] = 1.0
        size[2] = [False for _ in size[2]]
        size[5] = [False for _ in size[5]]
        mustrain = hap["Mustrain"]
        mustrain[0] = "isotropic"
        mustrain[1][0] = 0.0
        mustrain[1][2] = 1.0
        mustrain[2] = [False for _ in mustrain[2]]
        mustrain[5] = [False for _ in mustrain[5]]
        hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]


def correlation_rows(gpx, needle):
    cov = gpx.data["Covariance"]["data"]
    names = list(cov.get("varyList", []))
    mat = np.asarray(cov.get("covMatrix", []))
    rows = []
    if not mat.size:
        return rows
    sd = np.sqrt(np.maximum(np.diag(mat), 0))
    corr = mat / np.outer(sd, sd)
    for i in range(len(names)):
        for j in range(i):
            if (needle in names[i] or needle in names[j]) and abs(corr[i, j]) >= 0.8:
                rows.append([names[j], names[i], float(corr[i, j])])
    return sorted(rows, key=lambda row: abs(row[2]), reverse=True)


def run(phase_index, kind):
    out = ROOT / ".tmp" / f"selected_broadening_p{phase_index}_{kind}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = gpx.histogram(0)
    neutralize(gpx)
    phase = gpx.phase(phase_index)
    hap = phase.data["Histograms"][hist.name]
    if kind == "size":
        hap["Size"][2][0] = True
        variable = f"{phase_index}:0:Size;i"
        gpx.set_Controls("parmMin", 0.02, variable=variable)
        gpx.set_Controls("parmMax", 10.0, variable=variable)
        gpx.data["Controls"]["data"]["shift factor"] = 0.1
        needle = "Size;i"
    else:
        hap["Mustrain"][2][0] = True
        variable = f"{phase_index}:0:Mustrain;i"
        gpx.set_Controls("parmMin", 0.0, variable=variable)
        gpx.set_Controls("parmMax", 50000.0, variable=variable)
        gpx.data["Controls"]["data"]["shift factor"] = 1.0
        needle = "Mustrain;i"
    inst = hist.InstrumentParameters
    for key in ["U", "V", "W", "X", "Y", "Z", "Zero", "SH/L"]:
        inst[key][2] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"][1] = True
    gpx.set_Controls("cycles", 16)
    recipe = {
        "Background": {"refine": True},
        "Scale": True,
        "Cell": True,
        "Sample Parameters": ["Shift"],
    }
    gpx.do_refinements([{"set": recipe}, {}, {}, {}])
    gpx.save()
    print("SELECTED_BROADENING_RESULT", json.dumps({
        "phase_index": phase_index,
        "phase": phase.name,
        "kind": kind,
        "residuals": hist.residuals,
        "X": inst["X"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "mass_fractions": hist.ComputeMassFracs(),
        "correlations": correlation_rows(gpx, needle),
        "frozen": [str(x) for x in gpx.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }, default=float, sort_keys=True))


def main():
    for phase_index in range(3):
        for kind in ["size", "strain"]:
            run(phase_index, kind)


if __name__ == "__main__":
    main()
