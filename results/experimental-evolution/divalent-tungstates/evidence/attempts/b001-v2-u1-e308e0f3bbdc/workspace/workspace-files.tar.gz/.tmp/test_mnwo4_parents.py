from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "profile_X.gpx"
PARENTS = {
    "FeWO4_9008124": {
        "Mn1": (0.5, 0.6744, 0.25),
        "W1": (0.0, 0.1799, 0.25),
        "O1": (0.2159, 0.1050, 0.5660),
        "O2": (0.2538, 0.3744, 0.1096),
    },
    "MgWO4_9013902": {
        "Mn1": (0.5, 0.6742, 0.25),
        "W1": (0.0, 0.1819, 0.25),
        "O1": (0.2160, 0.1070, 0.9370),
        "O2": (0.2560, 0.3766, 0.3970),
    },
    "ZnWO4_1520641": {
        "Mn1": (0.5, 0.6840, 0.25),
        "W1": (0.0, 0.18258, 0.25),
        "O1": (0.2169, 0.1051, -0.0637),
        "O2": (0.2565, 0.3777, 0.3996),
    },
    "MnReO4_2100243": {
        "Mn1": (0.5, 0.6811, 0.25),
        "W1": (0.0, 0.16966, 0.25),
        "O1": (0.2078, 0.1056, 0.9375),
        "O2": (0.2595, 0.3712, 0.3881),
    },
}


def run(parent, coordinates):
    out = ROOT / ".tmp" / f"parent_{parent}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    for label, xyz in coordinates.items():
        atom = phase.atom(label)
        atom.coordinates = xyz
        atom.refinement_flags = " "
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"][1] = True
    inst = hist.InstrumentParameters
    for key in ["U", "V", "W", "Y", "Z", "Zero", "SH/L"]:
        inst[key][2] = False
    inst["X"][2] = True
    gpx.set_Controls("cycles", 12)
    recipe = {
        "Background": {"refine": True},
        "Scale": True,
        "Cell": True,
        "Sample Parameters": ["Shift"],
        "Instrument Parameters": ["X"],
    }
    gpx.do_refinements([{"set": recipe}, {}, {}])
    gpx.save()
    phase.export_CIF(str(ROOT / ".tmp" / f"parent_{parent}.cif"))
    print("PARENT_RESULT", json.dumps({
        "parent": parent,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "X": inst["X"],
        "shift": hist.SampleParameters["Shift"],
        "cell": phase.get_cell(),
        "coordinates": {a.label: a.coordinates for a in phase.atoms()},
    }, default=float, sort_keys=True))


def main():
    for parent, coordinates in PARENTS.items():
        run(parent, coordinates)


if __name__ == "__main__":
    main()
