from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "parent_ZnWO4_1520641.gpx"


def prepare(gpx, include_mn3o4):
    hist = gpx.histogram(0)
    for index, phase in enumerate(gpx.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][1][2] = 1.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        for atom in phase.atoms():
            atom.refinement_flags = " "
    wo3 = gpx.phase(1).data["Histograms"][hist.name]["Mustrain"]
    wo3[1][0] = 6863.25
    wo3[2][0] = True
    gpx.set_Controls("parmMin", 0.0, variable="1:0:Mustrain;i")
    gpx.set_Controls("parmMax", 50000.0, variable="1:0:Mustrain;i")
    if include_mn3o4:
        mn3o4 = gpx.phase(2).data["Histograms"][hist.name]["Mustrain"]
        mn3o4[1][0] = 6234.0
        mn3o4[2][0] = True
        gpx.set_Controls("parmMin", 0.0, variable="2:0:Mustrain;i")
        gpx.set_Controls("parmMax", 50000.0, variable="2:0:Mustrain;i")
    inst = hist.InstrumentParameters
    for key in ["U", "V", "W", "Y", "Z", "Zero", "SH/L"]:
        inst[key][2] = False
    inst["X"][2] = True
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"][1] = True
    return hist, inst


def correlations(gpx):
    cov = gpx.data["Covariance"]["data"]
    names = list(cov.get("varyList", []))
    mat = np.asarray(cov.get("covMatrix", []))
    rows = []
    if not mat.size:
        return rows
    sd = np.sqrt(np.maximum(np.diag(mat), 0))
    corr = mat / np.outer(sd, sd)
    needles = ("Mustrain;i", ":X")
    for i in range(len(names)):
        for j in range(i):
            if not (any(n in names[i] for n in needles) or any(n in names[j] for n in needles)):
                continue
            if abs(corr[i, j]) >= 0.75:
                rows.append([names[j], names[i], float(corr[i, j])])
    return sorted(rows, key=lambda row: abs(row[2]), reverse=True)


def run(tag, include_mn3o4):
    out = ROOT / ".tmp" / f"accepted_profile_{tag}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist, inst = prepare(gpx, include_mn3o4)
    gpx.set_Controls("cycles", 16)
    recipe = {
        "Background": {"refine": True},
        "Scale": True,
        "Cell": True,
        "Sample Parameters": ["Shift"],
        "Instrument Parameters": ["X"],
    }
    gpx.do_refinements([{"set": recipe}, {}, {}, {}])
    gpx.save()
    cov = gpx.data["Covariance"]["data"]
    vary = list(cov.get("varyList", []))
    sig = list(cov.get("sig", []))
    sigmas = {name: float(s) for name, s in zip(vary, sig) if "Mustrain;i" in name or name.endswith(":X")}
    print("ACCEPTED_PROFILE_RESULT", json.dumps({
        "tag": tag,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {k: inst[k] for k in ["U", "V", "W", "X", "Y", "Z", "SH/L"]},
        "mustrain": {p.name: p.data["Histograms"][hist.name]["Mustrain"] for p in gpx.phases()},
        "correlations": correlations(gpx),
        "sigmas": sigmas,
        "frozen": [str(x) for x in gpx.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }, default=float, sort_keys=True))


def main():
    run("wo3", False)
    run("wo3_mn3o4", True)


if __name__ == "__main__":
    main()
