from pathlib import Path
import numpy as np
from scipy.signal import find_peaks, savgol_filter

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def main():
    gpx = G2sc.G2Project(str(ROOT / "final.gpx"))
    hist = gpx.histogram(0)
    x = np.asarray(hist.getdata("X"))
    residual = np.asarray(hist.getdata("Yobs")) - np.asarray(hist.getdata("Ycalc"))
    smooth = savgol_filter(residual, 11, 3)
    peaks, props = find_peaks(smooth, prominence=80, distance=7)
    refs = []
    for phase, data in hist.data["Reflection Lists"].items():
        arr = np.asarray(data["RefList"])
        proxy = np.maximum(arr[:, 9] * arr[:, 11], 0)
        proxy /= max(float(proxy.max()), 1.0)
        for row, strength in zip(arr, proxy):
            refs.append((float(row[5]), phase, tuple(int(v) for v in row[:3]), float(strength)))
    refs.sort()
    order = sorted(range(len(peaks)), key=lambda i: props["prominences"][i], reverse=True)
    print("TOP_POSITIVE_RESIDUALS")
    for i in order[:30]:
        p = peaks[i]
        nearest = min(refs, key=lambda item: abs(item[0] - x[p]))
        strong_nearest = min((item for item in refs if item[3] >= 0.02), key=lambda item: abs(item[0] - x[p]))
        print(
            f"{x[p]:8.3f} resid={smooth[p]:9.1f} prom={props['prominences'][i]:9.1f} "
            f"near={nearest[1]} {nearest[2]} d={abs(nearest[0]-x[p]):.3f} relI={nearest[3]:.3f} "
            f"strong_d={abs(strong_nearest[0]-x[p]):.3f}"
        )


if __name__ == "__main__":
    main()
