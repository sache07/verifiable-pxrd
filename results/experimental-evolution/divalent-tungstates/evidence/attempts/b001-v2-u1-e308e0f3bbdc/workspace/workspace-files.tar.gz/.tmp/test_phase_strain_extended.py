from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "profile_X.gpx"


def run(phase_index):
    out = ROOT / ".tmp" / f"strain_extended_p{phase_index}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = gpx.histogram(0)
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][1][2] = 1.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    target = gpx.phase(phase_index)
    target_hap = target.data["Histograms"][hist.name]
    target_hap["Mustrain"][2][0] = True
    var = f"{phase_index}:0:Mustrain;i"
    gpx.set_Controls("parmMin", 0.0, variable=var)
    gpx.set_Controls("parmMax", 50000.0, variable=var)
    inst = hist.InstrumentParameters
    for key in ["U", "V", "W", "X", "Y", "Z", "Zero", "SH/L"]:
        inst[key][2] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"][1] = True
    gpx.set_Controls("cycles", 16)
    recipe = {
        "Background": {"refine": True},
        "Scale": True,
        "Cell": True,
        "Sample Parameters": ["Shift"],
    }
    gpx.do_refinements([{"set": recipe}, {}, {}])
    gpx.save()
    cov = gpx.data["Covariance"]["data"]
    names = list(cov.get("varyList", []))
    mat = np.asarray(cov.get("covMatrix", []))
    corr_rows = []
    if mat.size:
        sd = np.sqrt(np.maximum(np.diag(mat), 0))
        corr = mat / np.outer(sd, sd)
        for i in range(len(names)):
            for j in range(i):
                if ("Mustrain;i" in names[i] or "Mustrain;i" in names[j]) and abs(corr[i, j]) >= 0.8:
                    corr_rows.append([names[j], names[i], float(corr[i, j])])
    print("EXTENDED_STRAIN_RESULT", json.dumps({
        "phase_index": phase_index,
        "phase": target.name,
        "residuals": hist.residuals,
        "X": inst["X"],
        "mustrain": target_hap["Mustrain"],
        "mass_fractions": hist.ComputeMassFracs(),
        "correlations": corr_rows,
        "frozen": [str(x) for x in gpx.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }, default=float, sort_keys=True))


def main():
    for phase_index in [1, 2]:
        run(phase_index)


if __name__ == "__main__":
    main()
