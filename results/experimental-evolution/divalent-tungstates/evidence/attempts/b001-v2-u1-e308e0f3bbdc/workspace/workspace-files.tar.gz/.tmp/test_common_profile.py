from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "angular_displacement.gpx"
BRANCHES = {
    "U": ["U"],
    "X": ["X"],
}


def correlations(gpx, selected):
    cov = gpx.data["Covariance"]["data"]
    names = list(cov.get("varyList", []))
    mat = cov.get("covMatrix")
    if mat is None:
        return []
    mat = np.asarray(mat)
    sd = np.sqrt(np.maximum(np.diag(mat), 0))
    corr = mat / np.outer(sd, sd)
    rows = []
    for i in range(len(names)):
        for j in range(i):
            if not (any(names[i].endswith(":" + q) for q in selected) or any(names[j].endswith(":" + q) for q in selected)):
                continue
            if abs(corr[i, j]) >= 0.80:
                rows.append((names[j], names[i], float(corr[i, j])))
    return sorted(rows, key=lambda row: abs(row[2]), reverse=True)[:20]


def run(name, varied):
    out = ROOT / ".tmp" / f"profile_{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    for key, value in {"U": 0.0, "V": 0.0, "W": 25.0, "X": 0.0, "Y": 0.0, "Z": 0.0}.items():
        inst[key][0] = value
        inst[key][1] = value
        inst[key][2] = key in varied
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"][1] = True
    gpx.set_Controls("cycles", 12)
    gpx.save()
    recipe = {
        "Background": {"refine": True},
        "Scale": True,
        "Cell": True,
        "Sample Parameters": ["Shift"],
        "Instrument Parameters": varied,
    }
    gpx.do_refinements([{"set": recipe}, {}, {}])
    gpx.save()
    result = {
        "branch": name,
        "residuals": hist.residuals,
        "instrument": {k: inst[k] for k in ["U", "V", "W", "X", "Y", "Z", "SH/L"]},
        "shift": hist.SampleParameters["Shift"],
        "mass_fractions": hist.ComputeMassFracs(),
        "correlations": correlations(gpx, varied),
    }
    print("PROFILE_RESULT", json.dumps(result, default=float, sort_keys=True))


def main():
    for name, varied in BRANCHES.items():
        run(name, varied)


if __name__ == "__main__":
    main()
