from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE_PROJECT = ROOT / "adptest_w_o10.gpx"
FINAL_PROJECT = ROOT / "final.gpx"


def main() -> None:
    project = G2sc.G2Project(
        str(SOURCE_PROJECT), newgpx=str(FINAL_PROJECT)
    )
    project.data["Controls"]["data"]["Author"] = "Codex PXRD phase analysis"
    project.set_Frozen()
    project.set_Controls("cycles", 20)

    # Re-refine under the final filename so the covariance, phase fractions,
    # exported structures and profile all come from final.gpx itself.
    for _ in range(3):
        project.refine()
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        if rvals.get("converged") and rvals.get("Max shft/sig", 1e9) < 0.1:
            break
    project.save()

    histogram = project.histogram(0)
    fractions = histogram.ComputeMassFracs()

    phase_dir = ROOT / "phases"
    phase_dir.mkdir(exist_ok=True)
    phase_records = []
    phase_metadata = {
        "CaWO4_scheelite": {
            "name": "Calcium tungstate (scheelite)",
            "formula": "CaWO4",
            "space_group": "I 41/a",
            "cif": phase_dir / "CaWO4_scheelite.cif",
            "cod_id": "7219229",
        },
        "WO3_P21c_alt": {
            "name": "Tungsten trioxide (monoclinic)",
            "formula": "WO3",
            "space_group": "P 21/c",
            "cif": phase_dir / "WO3_monoclinic.cif",
            "cod_id": "2311041",
        },
    }

    for phase in project.phases():
        metadata = phase_metadata[phase.name]
        phase.export_CIF(str(metadata["cif"]))
        fraction, sigma = fractions[phase.name]
        phase_records.append(
            {
                "name": metadata["name"],
                "project_phase_name": phase.name,
                "formula": metadata["formula"],
                "space_group": metadata["space_group"],
                "cif_path": metadata["cif"].relative_to(ROOT).as_posix(),
                "structure_reference": {
                    "database": "Crystallography Open Database",
                    "cod_id": metadata["cod_id"],
                },
                "weight_fraction": float(fraction),
                "weight_percent": float(100.0 * fraction),
                "formal_weight_fraction_standard_uncertainty": float(sigma),
                "refined_cell": {
                    key: float(value) for key, value in phase.get_cell().items()
                },
            }
        )

    x, y_obs, _weights, y_calc, _background, _stored_difference = (
        histogram.data["data"][1]
    )
    modeled = np.flatnonzero(np.asarray(y_calc) != 0.0)
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
            ]
        )
        for index in modeled:
            writer.writerow(
                [
                    f"{x[index]:.8f}",
                    f"{y_obs[index]:.8f}",
                    f"{y_calc[index]:.8f}",
                    f"{y_obs[index] - y_calc[index]:.8f}",
                ]
            )

    residuals = histogram.data["data"][0]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "phases": phase_records,
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "fit_statistics": {
            "Rwp_percent": float(rvals["Rwp"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "durbin_watson": float(residuals["Durbin-Watson"]),
            "number_of_observations": int(rvals["Nobs"]),
            "number_of_refined_variables": int(rvals["Nvars"]),
            "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
            "converged": bool(rvals["converged"]),
            "two_theta_range_deg": [
                float(x[modeled[0]]),
                float(x[modeled[-1]]),
            ],
        },
        "radiation": {
            "source": "Cu K-alpha",
            "Kalpha1_angstrom": 1.540598,
            "Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
        },
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
    }
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
