from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def summary(gpx, label):
    h = gpx.histogram(0)
    print(f"\n--- {label} ---")
    print("wR", h.get_wR(), "R", h.data["data"][0].get("R"),
          "GOF", gpx.data["Covariance"]["data"].get("Rvals", {}).get("GOF"))
    print("mass", h.ComputeMassFracs())
    print("sample scale", h.data["Sample Parameters"]["Scale"])
    print("inst", {k: v for k, v in h.data["Instrument Parameters"][0].items()
                    if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")})
    for ph in gpx.phases():
        hap = ph.data["Histograms"][h.name]
        print(ph.name, "scale", hap["Scale"], "size", hap["Size"][:3],
              "mustrain", hap["Mustrain"][:3], "cell", ph.get_cell())
    print("frozen", gpx.get_Frozen())


def main():
    gpx = G2sc.G2Project(str(ROOT / "trial.gpx"), newgpx=str(ROOT / "trial2.gpx"))
    h = gpx.histogram(0)
    phases = gpx.phases()

    # Remove the redundant histogram/phase scale product.
    overall = h.data["Sample Parameters"]["Scale"][0]
    h.data["Sample Parameters"]["Scale"] = [1.0, False]
    for ph in phases:
        ph.HAPvalue("Scale", ph.HAPvalue("Scale", targethistlist=[h]) * overall,
                    targethistlist=[h])

    # Reset the instrumental profile and put specimen broadening into each phase.
    inst = h.data["Instrument Parameters"][0]
    defaults = {"U": 2.0, "V": -2.0, "W": 5.0,
                "X": 0.0, "Y": 0.0, "SH/L": 0.002}
    for key, value in defaults.items():
        inst[key][1] = value
        inst[key][2] = False

    phases[0].setSampleProfile(h, "size", "isotropic", 0.045, LGmix=1.0)
    phases[0].setSampleProfile(h, "microstrain", "isotropic", 500.0, LGmix=1.0)
    phases[1].setSampleProfile(h, "size", "isotropic", 0.070, LGmix=1.0)
    phases[1].setSampleProfile(h, "microstrain", "isotropic", 500.0, LGmix=1.0)
    for ph in phases:
        ph.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }, [h])

    gpx.set_Controls("cycles", 12)
    gpx.refine()
    summary(gpx, "phase broadening")

    # Refine only the physically well-behaved Gaussian instrument terms.
    h.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
    gpx.refine()
    summary(gpx, "instrument gaussian")
    gpx.save()


if __name__ == "__main__":
    main()
