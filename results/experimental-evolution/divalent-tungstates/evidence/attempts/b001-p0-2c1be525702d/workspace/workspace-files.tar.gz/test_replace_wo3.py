import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
RESOURCE = Path("<RUN>/resources/b001-c05/cif")


def cod_path(cod_id):
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main():
    cod_id, label = sys.argv[1:3]
    out = ROOT / f"wo3model_{cod_id}.gpx"
    gpx = G2sc.G2Project(str(ROOT / "trial4.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    old_name = "WO3_monoclinic"
    old_scale = gpx.phase(old_name).HAPvalue("Scale", targethistlist=[hist])

    del gpx.data["Phases"][old_name]
    for item in gpx.names:
        if item[0] == "Phases" and old_name in item:
            item.remove(old_name)
    hist.data["Reflection Lists"].pop(old_name, None)
    gpx.update_ids()

    phase = gpx.add_phase(str(cod_path(cod_id)), phasename=label,
                          histograms=[hist], fmthint="CIF")
    phase.HAPvalue("Scale", old_scale, targethistlist=[hist])
    phase.set_HAP_refinements({"Scale": True}, [hist])
    phase.set_refinements({"Cell": True})
    phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 300.0, LGmix=1.0)
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    gpx.set_Controls("parmMin", 0.0, variable="1:0:Scale")
    gpx.set_Controls("parmMin", 0.0, variable="1:0:Mustrain;i")
    gpx.set_Controls("cycles", 12)
    gpx.refine()

    result = {
        "cod_id": cod_id,
        "label": label,
        "wR_percent": hist.get_wR(),
        "R_percent": hist.data["data"][0].get("R"),
        "Rf_percent": hist.data["data"][0].get("1:0:Rf"),
        "mass_fractions": hist.ComputeMassFracs(),
        "cell": phase.get_cell(),
        "scale": phase.HAPvalue("Scale", targethistlist=[hist]),
        "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
        "frozen": gpx.get_Frozen(),
    }
    gpx.save()
    print("RESULT_JSON=" + json.dumps(result, default=str))


if __name__ == "__main__":
    main()
