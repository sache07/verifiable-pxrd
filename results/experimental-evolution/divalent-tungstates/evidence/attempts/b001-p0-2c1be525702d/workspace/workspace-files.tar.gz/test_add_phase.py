import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
RESOURCE = Path("<RUN>/resources/b001-c05/cif")


def cod_path(cod_id):
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main():
    cod_id, label = sys.argv[1:3]
    out = ROOT / f"candidate_{cod_id}.gpx"
    gpx = G2sc.G2Project(str(ROOT / "trial4.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)

    # Remove the inactive WO3 size parameter that reached its upper bound.
    wo_hap = gpx.phase("WO3_monoclinic").data["Histograms"][hist.name]
    wo_hap["Size"][1][0] = 10.0
    wo_hap["Size"][2] = [False, False, False]

    phase = gpx.add_phase(str(cod_path(cod_id)), phasename=label,
                          histograms=[hist], fmthint="CIF")
    phase.HAPvalue("Scale", 0.25, targethistlist=[hist])
    phase.set_HAP_refinements({"Scale": True}, [hist])
    gpx.set_Controls("parmMin", 0.0, variable="2:0:Scale")
    gpx.set_Controls("cycles", 10)
    gpx.refine()

    first_mass = hist.ComputeMassFracs()
    candidate_mass = first_mass.get(label, (0.0, 0.0))[0]
    if candidate_mass > 0.002:
        phase.set_refinements({"Cell": True})
        phase.setSampleProfile(hist, "size", "isotropic", 0.1, LGmix=1.0)
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
        gpx.set_Controls("parmMin", 0.005, variable="2:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, variable="2:0:Size;i")
        gpx.refine()

    result = {
        "cod_id": cod_id,
        "label": label,
        "wR_percent": hist.get_wR(),
        "R_percent": hist.data["data"][0].get("R"),
        "mass_fractions": hist.ComputeMassFracs(),
        "candidate_cell": phase.get_cell(),
        "candidate_scale": phase.HAPvalue("Scale", targethistlist=[hist]),
        "candidate_profile": phase.data["Histograms"][hist.name]["Size"],
        "frozen": gpx.get_Frozen(),
    }
    gpx.save()
    print("RESULT_JSON=" + json.dumps(result, default=str))


if __name__ == "__main__":
    main()
