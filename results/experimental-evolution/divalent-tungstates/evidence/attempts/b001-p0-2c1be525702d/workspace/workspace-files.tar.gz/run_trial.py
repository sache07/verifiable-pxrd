from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
RESOURCE = Path("<RUN>/resources/b001-c05/cif")


def cod_path(cod_id):
    cod_id = str(cod_id)
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summarize(project, label):
    hist = project.histogram(0)
    out = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "residuals": hist.data["data"][0],
        "instrument": {
            k: v[1] for k, v in hist.data["Instrument Parameters"][0].items()
            if isinstance(v, list) and len(v) > 1
        },
        "phases": {},
    }
    for phase in project.phases():
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": phase.HAPvalue("Scale", targethistlist=[hist]),
        }
    try:
        out["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    print(json.dumps(out, indent=2, default=str))


def main():
    gpx = G2sc.G2Project(newgpx=str(ROOT / "trial.gpx"))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    cawo4 = gpx.add_phase(
        str(cod_path("7219229")), phasename="CaWO4_scheelite",
        histograms=[hist], fmthint="CIF",
    )
    wo3 = gpx.add_phase(
        str(cod_path("1528915")), phasename="WO3_monoclinic",
        histograms=[hist], fmthint="CIF",
    )

    gpx.set_Controls("cycles", 8)
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 12,
            "coeffs": [1600.0, -700.0, 350.0, -180.0, 100.0, -50.0,
                       25.0, -12.0, 6.0, -3.0, 1.0, 0.0],
        },
    })
    cawo4.HAPvalue("Scale", 1.0, targethistlist=[hist])
    wo3.HAPvalue("Scale", 0.15, targethistlist=[hist])

    # Establish scale and background first.
    cawo4.set_HAP_refinements({"Scale": True}, [hist])
    wo3.set_HAP_refinements({"Scale": True}, [hist])
    gpx.refine()
    summarize(gpx, "scale_background")

    # Then refine specimen-independent peak positions and both unit cells.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    cawo4.set_refinements({"Cell": True})
    wo3.set_refinements({"Cell": True})
    gpx.refine()
    summarize(gpx, "zero_cells")

    # Finally refine the global instrumental width terms.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]})
    gpx.refine()
    summarize(gpx, "profile")
    gpx.save()


if __name__ == "__main__":
    main()
