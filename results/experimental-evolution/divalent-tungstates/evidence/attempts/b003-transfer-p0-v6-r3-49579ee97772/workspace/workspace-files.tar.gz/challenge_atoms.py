#!/usr/bin/env python3
"""Test isotropic displacement refinements one phase at a time."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
SOURCE = TMP / "combined_Cu3size_CuOstrain.gpx"
PHASES = ("Cu3WO6", "WO3_2311041", "CuO_C2c")


def max_shift_over_esd(project) -> float | None:
    shifts, sigmas = project.get_LastFitResults()
    values = [abs(shifts[k] / sigmas[k]) for k in shifts if sigmas.get(k, 0) > 0]
    return max(values) if values else None


def run(phase_name: str) -> None:
    tag = phase_name.replace("_2311041", "").replace("_C2c", "")
    output = TMP / f"uiso_{tag}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
    phase = project.phase(phase_name)
    for index, atom in enumerate(phase.atoms()):
        atom.uiso = 0.005 if atom.element != "O" else 0.008
        atom.refinement_flags = "U"
        project.set_Controls("parmMin", 0.0, f"{phase.id}::AUiso:{index}")
        project.set_Controls("parmMax", 0.05, f"{phase.id}::AUiso:{index}")
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    for _ in range(5):
        project.refine()
    project.save()
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    sigmas = dict(zip(cov["varyList"], cov["sig"]))
    result = {
        "phase": phase_name,
        "residuals": {
            key: float(value)
            for key, value in hist.residuals.items()
            if isinstance(value, (int, float, np.integer, np.floating))
        },
        "max_shift_over_esd": max_shift_over_esd(project),
        "frozen": project.get_Frozen(),
        "atoms": [],
    }
    for index, atom in enumerate(phase.atoms()):
        variable = f"{phase.id}::AUiso:{index}"
        result["atoms"].append(
            {
                "label": atom.label,
                "element": atom.element,
                "uiso": float(atom.uiso),
                "esd": float(sigmas.get(variable, 0.0)),
                "refinement_flags": atom.refinement_flags,
            }
        )
    output.with_suffix(".json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=PHASES)
    run(parser.parse_args().phase)
