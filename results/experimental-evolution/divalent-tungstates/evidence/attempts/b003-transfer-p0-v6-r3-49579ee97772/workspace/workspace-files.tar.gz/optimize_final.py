#!/usr/bin/env python3
"""Rebuild and challenge profile terms for the accepted three-phase inventory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
INITIAL = TMP / "inventory_CuO_C2c.gpx"
BASE = TMP / "accepted_base.gpx"
PHASES = ("Cu3WO6", "WO3_2311041", "CuO_C2c")


def max_shift_over_esd(project) -> float | None:
    try:
        shifts, sigmas = project.get_LastFitResults()
    except Exception:
        return None
    values = [abs(shifts[k] / sigmas[k]) for k in shifts if sigmas.get(k, 0) > 0]
    return max(values) if values else None


def result(project, label: str) -> dict:
    hist = project.histogram(0)
    output = {
        "label": label,
        "residuals": {
            key: float(value)
            for key, value in hist.residuals.items()
            if isinstance(value, (int, float, np.integer, np.floating))
        },
        "max_shift_over_esd": max_shift_over_esd(project),
        "frozen": project.get_Frozen(),
        "limits": list(hist.data["Limits"][1]),
        "instrument": {
            key: list(value)
            for key, value in hist.InstrumentParameters.items()
            if key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)")
        },
        "background": list(hist.Background[0]),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        output["phases"][phase.name] = {
            "scale": list(hap["Scale"]),
            "cell": {key: float(value) for key, value in phase.get_cell().items()},
            "preferred_orientation": hap["Pref.Ori."],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    return output


def refine(project, repeats: int = 3) -> None:
    project.set_Controls("cycles", 12)
    for _ in range(repeats):
        project.refine()


def neutral_width(hap) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][4] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def rebuild_baseline() -> None:
    project = G2sc.G2Project(str(INITIAL), newgpx=str(BASE))
    hist = project.histogram(0)
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    hist.Background[0][0] = "chebyschev-1"
    hist.Background[0][1] = True
    hist.InstrumentParameters["W"] = [50.0, 0.0, False]
    hist.InstrumentParameters["V"] = [0.0, 0.0, False]
    hist.InstrumentParameters["Y"] = [0.0, 0.0, False]
    hist.InstrumentParameters["SH/L"] = [0.002, 0.002, False]
    hist.InstrumentParameters["I(L2)/I(L1)"][2] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key] = [0.0, False]
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        neutral_width(hap)
        hap["Scale"][1] = True
        phase.data["General"]["Cell"][0] = True
    project.set_Frozen()
    refine(project, 4)
    project.save()
    output = result(project, "accepted_inventory_common_profile")
    (TMP / "accepted_base.json").write_text(json.dumps(output, indent=2))
    print(json.dumps(output, indent=2))


def width_trial(phase_name: str, kind: str) -> None:
    tag = phase_name.replace("_2311041", "").replace("_C2c", "")
    output_path = TMP / f"width_{tag}_{kind}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output_path))
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    p_id = phase.id
    if kind == "size":
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": 1.0,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            },
            [hist],
        )
        project.set_Controls("parmMin", 0.01, f"{p_id}:0:Size;i")
        project.set_Controls("parmMax", 10.0, f"{p_id}:0:Size;i")
    else:
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            },
            [hist],
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 100.0
        project.set_Controls("parmMin", 0.0, f"{p_id}:0:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, f"{p_id}:0:Mustrain;i")
    project.set_Frozen()
    refine(project, 4)
    project.save()
    output = result(project, f"{phase_name}_{kind}")
    (TMP / f"width_{tag}_{kind}.json").write_text(json.dumps(output, indent=2))
    print(json.dumps(output, indent=2))


def asymmetry_trial() -> None:
    output_path = TMP / "profile_asymmetry.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output_path))
    hist = project.histogram(0)
    hist.InstrumentParameters["SH/L"] = [0.002, 0.01, True]
    project.set_Controls("parmMin", 0.002, ":0:SH/L")
    project.set_Controls("parmMax", 0.2, ":0:SH/L")
    project.set_Frozen()
    refine(project, 4)
    project.save()
    output = result(project, "common_SHL")
    (TMP / "profile_asymmetry.json").write_text(json.dumps(output, indent=2))
    print(json.dumps(output, indent=2))


def add_strain(project, phase_name: str, start: float) -> None:
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    phase.set_HAP_refinements(
        {
            "Mustrain": {
                "type": "isotropic",
                "refine": True,
                "LGmix": {"value": 1.0, "refine": False},
            }
        },
        [hist],
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][1][0] = start
    project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Mustrain;i")
    project.set_Controls("parmMax", 10000.0, f"{phase.id}:0:Mustrain;i")


def combination_trial(kind: str) -> None:
    if kind == "cu3_both":
        source = TMP / "width_Cu3WO6_size.gpx"
        output_path = TMP / "combined_Cu3_size_strain.gpx"
        project = G2sc.G2Project(str(source), newgpx=str(output_path))
        add_strain(project, "Cu3WO6", 500.0)
    elif kind == "cu3size_cuostrain":
        source = TMP / "width_Cu3WO6_size.gpx"
        output_path = TMP / "combined_Cu3size_CuOstrain.gpx"
        project = G2sc.G2Project(str(source), newgpx=str(output_path))
        add_strain(project, "CuO_C2c", 3000.0)
    else:
        source = TMP / "combined_Cu3size_CuOstrain.gpx"
        output_path = TMP / "combined_all_width.gpx"
        project = G2sc.G2Project(str(source), newgpx=str(output_path))
        add_strain(project, "Cu3WO6", 500.0)
    project.set_Frozen()
    refine(project, 5)
    project.save()
    output = result(project, kind)
    json_path = output_path.with_suffix(".json")
    json_path.write_text(json.dumps(output, indent=2))
    print(json.dumps(output, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("baseline")
    width = sub.add_parser("width")
    width.add_argument("phase", choices=PHASES)
    width.add_argument("kind", choices=("size", "strain"))
    sub.add_parser("asymmetry")
    combination = sub.add_parser("combine")
    combination.add_argument(
        "kind", choices=("cu3_both", "cu3size_cuostrain", "all")
    )
    args = parser.parse_args()
    if args.command == "baseline":
        rebuild_baseline()
    elif args.command == "width":
        width_trial(args.phase, args.kind)
    elif args.command == "asymmetry":
        asymmetry_trial()
    else:
        combination_trial(args.kind)


if __name__ == "__main__":
    main()
