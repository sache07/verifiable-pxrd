#!/usr/bin/env python3
"""Re-challenge weak phase candidates after the final common profile rebuild."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
SOURCE = TMP / "combined_Cu3size_CuOstrain.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
CANDIDATES = {
    "CuWO4_P1bar": "4000806",
    "CuWO4_P2c": "4000807",
    "Cu2WO4_P1": "2002403",
    "Cu2O_Pn3m": "1010941",
}


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def run(candidate: str) -> None:
    output = TMP / f"rechallenge_{candidate}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
    hist = project.histogram(0)
    phase_path = (
        TMP / "Cu2WO4_rewritten.cif"
        if candidate == "Cu2WO4_P1"
        else cod_path(CANDIDATES[candidate])
    )
    phase = project.add_phase(
        str(phase_path), phasename=candidate, histograms=[hist], fmthint="CIF"
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.01, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."] = ["MD", 1.0, False, [0, 0, 1], 0, {}, [], 0.1]
    project.set_Controls("parmMin", 0.0, "3:0:Scale")
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    for _ in range(4):
        project.refine()
    project.save()
    cov = project.data["Covariance"]["data"]
    sigmas = dict(zip(cov["varyList"], cov["sig"]))
    result = {
        "candidate": candidate,
        "scale": float(hap["Scale"][0]),
        "scale_esd": float(sigmas.get("3:0:Scale", 0.0)),
        "frozen": project.get_Frozen(),
        "residuals": {
            key: float(value)
            for key, value in hist.residuals.items()
            if isinstance(value, (int, float, np.integer, np.floating))
        },
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", choices=CANDIDATES)
    run(parser.parse_args().candidate)
