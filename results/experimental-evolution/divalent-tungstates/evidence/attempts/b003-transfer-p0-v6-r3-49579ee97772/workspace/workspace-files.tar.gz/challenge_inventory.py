#!/usr/bin/env python3
"""Add one watch-list phase to a common refined inventory and test its scale."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
SOURCE = TMP / "texture_10m1.gpx"


CANDIDATES = {
    "CuO_C2c": ("1011194", "CuO_C2c"),
    "CuO_Cc": ("9016057", "CuO_Cc"),
    "CuWO4_P1bar": ("4000806", "CuWO4_P1bar"),
    "CuWO4_P2c": ("4000807", "CuWO4_P2c"),
    "Cu2WO4_P1": ("2002403", "Cu2WO4_P1"),
    "Cu2O_Pn3m": ("1010941", "Cu2O_Pn3m"),
}


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize(phase, histname: str) -> None:
    hap = phase.data["Histograms"][histname]
    hap["Scale"] = [0.1, True]
    hap["Pref.Ori."] = ["MD", 1.0, False, [0, 0, 1], 0, {}, [], 0.1]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][4] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def max_shift_over_esd(project) -> float | None:
    try:
        shifts, sigmas = project.get_LastFitResults()
    except Exception:
        return None
    values = [abs(shifts[k] / sigmas[k]) for k in shifts if sigmas.get(k, 0) > 0]
    return max(values) if values else None


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    result = {
        "label": label,
        "residuals": {
            key: float(value)
            for key, value in hist.residuals.items()
            if isinstance(value, (int, float, np.integer, np.floating))
        },
        "max_shift_over_esd": max_shift_over_esd(project),
        "frozen": project.get_Frozen(),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "scale": float(hap["Scale"][0]),
            "scale_refine": bool(hap["Scale"][1]),
            "cell": {key: float(value) for key, value in phase.get_cell().items()},
        }
    return result


def refine(project, repeats: int) -> None:
    project.set_Controls("cycles", 12)
    for _ in range(repeats):
        project.refine()


def run(candidate: str) -> None:
    cod_id, phase_name = CANDIDATES[candidate]
    output = TMP / f"inventory_{candidate}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
    hist = project.histogram(0)
    phase_path = TMP / "Cu2WO4_rewritten.cif" if candidate == "Cu2WO4_P1" else cod_path(cod_id)
    phase = project.add_phase(
        str(phase_path), phasename=phase_name, histograms=[hist], fmthint="CIF"
    )
    neutralize(phase, hist.name)
    project.set_Controls("parmMin", 0.0, "2:0:Scale")
    project.set_Frozen()

    # Scale challenge under the unchanged nuisance model, then allow the cell.
    refine(project, 2)
    stages = [snapshot(project, "scale_only")]
    phase.set_refinements({"Cell": True})
    refine(project, 3)
    stages.append(snapshot(project, "cell_and_common_profile"))
    project.save()
    (TMP / f"inventory_{candidate}.json").write_text(json.dumps(stages, indent=2))
    print(json.dumps(stages, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", choices=CANDIDATES)
    run(parser.parse_args().candidate)
