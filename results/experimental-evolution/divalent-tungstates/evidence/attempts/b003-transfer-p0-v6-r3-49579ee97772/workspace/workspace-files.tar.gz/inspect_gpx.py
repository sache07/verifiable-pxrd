#!/usr/bin/env python3
"""Create compact profile diagnostics for a GSAS-II powder project."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.gpx))
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("X"))
    yo = np.asarray(hist.getdata("Yobs"))
    yc = np.asarray(hist.getdata("Ycalc"))
    bg = np.asarray(hist.getdata("Background"))
    diff = yo - yc

    output = args.output or args.gpx.with_suffix(".png")
    fig, axes = plt.subplots(4, 1, figsize=(14, 12), constrained_layout=True)
    windows = [(10, 100), (13, 38), (38, 65), (65, 100)]
    for ax, (lo, hi) in zip(axes, windows):
        use = (x >= lo) & (x <= hi)
        offset = -0.18 * np.max(yo[use])
        ax.plot(x[use], yo[use], color="black", lw=0.75, label="observed")
        ax.plot(x[use], yc[use], color="tab:red", lw=0.75, label="calculated")
        ax.plot(x[use], bg[use], color="tab:green", lw=0.55, label="background")
        ax.plot(x[use], diff[use] + offset, color="tab:blue", lw=0.55, label="difference + offset")
        ax.axhline(offset, color="0.6", lw=0.4)
        ax.set_xlim(lo, hi)
        ax.set_ylabel("counts")
    axes[-1].set_xlabel(r"$2\theta$ (degrees)")
    axes[0].legend(ncol=4, fontsize=8)
    fig.suptitle(f"{args.gpx.name}: Rwp={hist.get_wR():.3f}%")
    fig.savefig(output, dpi=170)
    print(output)

    # Report the strongest residual extrema outside the smooth background.
    score = np.abs(diff) / np.sqrt(np.maximum(yo, 1.0))
    candidates = np.argsort(score)[::-1]
    chosen = []
    for idx in candidates:
        if all(abs(x[idx] - x[j]) > 0.18 for j in chosen):
            chosen.append(idx)
        if len(chosen) == 30:
            break
    print("largest standardized residuals")
    for idx in chosen:
        print(f"{x[idx]:9.4f} obs={yo[idx]:9.1f} calc={yc[idx]:9.1f} diff={diff[idx]:9.1f} z={score[idx]:7.2f}")


if __name__ == "__main__":
    main()
