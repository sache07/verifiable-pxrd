#!/usr/bin/env python3
"""Challenge geometry and texture choices from a common GSAS-II baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
SOURCE = TMP / "trial_mono_neutron.gpx"


def numeric_residuals(hist) -> dict[str, float]:
    return {
        key: float(value)
        for key, value in hist.residuals.items()
        if isinstance(value, (int, float, np.integer, np.floating))
    }


def max_shift_over_esd(project) -> float | None:
    try:
        shifts, sigmas = project.get_LastFitResults()
    except Exception:
        return None
    values = [abs(shifts[key] / sigmas[key]) for key in shifts if sigmas.get(key, 0) > 0]
    return max(values) if values else None


def summarize(project, label: str) -> dict:
    hist = project.histogram(0)
    result = {
        "label": label,
        "residuals": numeric_residuals(hist),
        "instrument": {
            key: {"value": float(value[1]), "refine": bool(value[2])}
            for key, value in hist.InstrumentParameters.items()
            if key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)")
        },
        "sample": {
            key: list(hist.SampleParameters[key])
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
            if key in hist.SampleParameters
        },
        "max_shift_over_esd": max_shift_over_esd(project),
        "frozen": project.get_Frozen(),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "scale": float(hap["Scale"][0]),
            "cell": {key: float(value) for key, value in phase.get_cell().items()},
            "preferred_orientation": hap["Pref.Ori."],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    return result


def refine_repeated(project, repeats: int = 2) -> None:
    project.set_Controls("cycles", 12)
    for _ in range(repeats):
        project.refine()


def clean_common_baseline() -> Path:
    output = TMP / "baseline_clean.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
    hist = project.histogram(0)

    # W collapsed at its nonnegative bound when U/W/X were tried together.
    # Prune W, retain the replay-stable U/X profile, and clear the frozen list.
    hist.InstrumentParameters["W"][1] = 0.0
    hist.InstrumentParameters["W"][2] = False
    hist.InstrumentParameters["U"][2] = True
    hist.InstrumentParameters["X"][2] = True
    project.set_Frozen()

    # Effective polarization was not supplied. Fit it before any texture term.
    hist.InstrumentParameters["Polariz."][2] = True
    project.set_Controls("parmMin", 0.0, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    refine_repeated(project, 3)
    project.save()
    result = summarize(project, "clean_common_profile_zero")
    (TMP / "baseline_clean.json").write_text(json.dumps(result, indent=2, default=str))
    print(json.dumps(result, indent=2, default=str))
    return output


def geometry_trial(kind: str) -> None:
    source = TMP / "baseline_clean.gpx"
    output = TMP / f"geometry_{kind}.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(output))
    hist = project.histogram(0)
    if kind == "zero":
        hist.InstrumentParameters["Zero"][2] = True
        hist.SampleParameters["Shift"] = [0.0, False]
    else:
        hist.InstrumentParameters["Zero"] = [0.0, 0.0, False]
        hist.SampleParameters["Shift"] = [0.0, True]
        project.set_Controls("parmMin", -1.0, ":0:Shift")
        project.set_Controls("parmMax", 1.0, ":0:Shift")
    project.set_Frozen()
    refine_repeated(project, 3)
    project.save()
    result = summarize(project, f"geometry_{kind}")
    (TMP / f"geometry_{kind}.json").write_text(json.dumps(result, indent=2, default=str))
    print(json.dumps(result, indent=2, default=str))


AXES = {
    "100": [1, 0, 0],
    "010": [0, 1, 0],
    "001": [0, 0, 1],
    "10m1": [1, 0, -1],
    "110": [1, 1, 0],
    "101": [1, 0, 1],
    "011": [0, 1, 1],
    "11m1": [1, 1, -1],
}


def texture_trial(axis_name: str) -> None:
    source = TMP / "geometry_zero.gpx"
    output = TMP / f"texture_{axis_name}.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(output))
    hist = project.histogram(0)
    wo = project.phase("WO3_2311041")
    po = wo.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = AXES[axis_name]
    project.set_Controls("parmMin", 0.05, "1:0:MD")
    project.set_Controls("parmMax", 20.0, "1:0:MD")
    project.set_Frozen()
    refine_repeated(project, 3)
    project.save()
    result = summarize(project, f"texture_{axis_name}")
    (TMP / f"texture_{axis_name}.json").write_text(json.dumps(result, indent=2, default=str))
    print(json.dumps(result, indent=2, default=str))


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("baseline")
    geometry = sub.add_parser("geometry")
    geometry.add_argument("kind", choices=("zero", "shift"))
    texture = sub.add_parser("texture")
    texture.add_argument("axis", choices=AXES)
    args = parser.parse_args()
    if args.command == "baseline":
        clean_common_baseline()
    elif args.command == "geometry":
        geometry_trial(args.kind)
    else:
        texture_trial(args.axis)


if __name__ == "__main__":
    main()
