#!/usr/bin/env python3
"""Replay the accepted model and export all requested deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIstrMath as G2stMth


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "combined_Cu3size_CuOstrain.gpx"
FINAL_GPX = ROOT / "final.gpx"

PHASE_INFO = {
    "Cu3WO6": {
        "display_name": "Cu3WO6",
        "formula": "Cu3WO6",
        "space_group": "Pa-3",
        "space_group_number": 205,
        "source_cod_id": "1527404",
        "cif": "Cu3WO6.cif",
    },
    "WO3_2311041": {
        "display_name": "WO3",
        "formula": "WO3",
        "space_group": "P2_1/c",
        "space_group_number": 14,
        "source_cod_id": "2311041",
        "cif": "WO3.cif",
    },
    "CuO_C2c": {
        "display_name": "CuO",
        "formula": "CuO",
        "space_group": "C2/c",
        "space_group_number": 15,
        "source_cod_id": "1011194",
        "cif": "CuO.cif",
    },
}


def significant(value: float, digits: int = 6) -> str:
    return f"{value:.{digits}g}"


def replay() -> G2sc.G2Project:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL_GPX))
    hist = project.histogram(0)
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.save()
    project.refine()
    project.save()

    # Explicit save/reopen/replay check over the complete measured range.
    project = G2sc.G2Project(str(FINAL_GPX))
    project.set_Controls("cycles", 12)
    project.refine()
    project.save()
    return G2sc.G2Project(str(FINAL_GPX))


def covariance_values(project) -> tuple[dict[str, float], dict[str, float]]:
    covariance = project.data["Covariance"]["data"]
    values = dict(zip(covariance["varyList"], covariance["variables"]))
    sigmas = dict(zip(covariance["varyList"], covariance["sig"]))
    return values, sigmas


def mass_fractions(project) -> tuple[dict[str, float], dict[str, float]]:
    hist = project.histogram(0)
    covariance = project.data["Covariance"]["data"]
    phases = {phase.name: phase.data for phase in project.phases()}
    values, sigmas = G2stMth.calcMassFracs(
        covariance["varyList"],
        covariance["covMatrix"],
        phases,
        hist.name,
        hist.id,
    )
    return values, sigmas


def export_profile(project) -> None:
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("X"), dtype=float)
    observed = np.asarray(hist.getdata("Yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("Ycalc"), dtype=float)
    difference = np.asarray(hist.getdata("Residual"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)
    if not np.allclose(observed - calculated, difference, rtol=0, atol=1e-8):
        raise RuntimeError("GSAS-II residual array does not equal observed-calculated")
    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_intensity_obs_minus_calc",
                "background_intensity",
            ]
        )
        writer.writerows(zip(x, observed, calculated, difference, background))


def export_results(project) -> dict:
    hist = project.histogram(0)
    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    weight_values, weight_sigmas = mass_fractions(project)
    _, sigmas = covariance_values(project)

    phase_rows = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        phase.export_CIF(str(ROOT / info["cif"]))
        key = f"{phase.id}:{hist.id}:WgtFrac"
        cell, cell_esd = phase.get_cell_and_esd()
        hap = phase.data["Histograms"][hist.name]
        row = {
            "name": info["display_name"],
            "formula": info["formula"],
            "space_group": info["space_group"],
            "space_group_number": info["space_group_number"],
            "source_cod_id": info["source_cod_id"],
            "cif_path": info["cif"],
            "weight_fraction": float(weight_values[key]),
            "weight_fraction_esd": float(weight_sigmas[key]),
            "cell": {name: float(value) for name, value in cell.items()},
            "cell_esd": {name: float(value) for name, value in cell_esd.items()},
        }
        if phase.name == "WO3_2311041":
            row["preferred_orientation"] = {
                "model": "March-Dollase",
                "axis_hkl": list(hap["Pref.Ori."][3]),
                "parameter": float(hap["Pref.Ori."][1]),
                "parameter_esd": float(sigmas["1:0:MD"]),
            }
        if phase.name == "Cu3WO6":
            row["coherent_domain_size_micrometre"] = float(hap["Size"][1][0])
            row["coherent_domain_size_esd_micrometre"] = float(sigmas["0:0:Size;i"])
        if phase.name == "CuO_C2c":
            row["microstrain"] = float(hap["Mustrain"][1][0])
            row["microstrain_esd"] = float(sigmas["2:0:Mustrain;i"])
        phase_rows.append(row)

    result = {
        "phases": phase_rows,
        "modeled_crystalline_weight_fraction_sum": float(
            sum(row["weight_fraction"] for row in phase_rows)
        ),
        "fit_statistics": {
            "r_wp_percent": float(rvals["Rwp"]),
            "r_p_percent": float(hist.residuals["R"]),
            "r_exp_percent": float(hist.residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
        },
        "profile_path": "fit.csv",
        "gsasii_project_path": "final.gpx",
        "weight_fraction_basis": "Normalized over the modeled crystalline phases only",
    }
    if not np.isclose(result["modeled_crystalline_weight_fraction_sum"], 1.0, atol=1e-10):
        raise RuntimeError("crystalline phase fractions do not sum to one")
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def export_report(project, result: dict) -> None:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    phases = {row["name"]: row for row in result["phases"]}
    stats = result["fit_statistics"]
    wo_po = phases["WO3"]["preferred_orientation"]
    report = f"""# Powder diffraction phase analysis

## Result

The modeled crystalline material contains **Cu3WO6 (Pa-3)**, **WO3 (P2_1/c)**, and **CuO (C2/c)**. Weight fractions normalized over those crystalline phases are:

| Phase | Weight fraction | Formal 1-sigma | Refined cell |
|---|---:|---:|---|
| Cu3WO6 | {100 * phases['Cu3WO6']['weight_fraction']:.3f}% | {100 * phases['Cu3WO6']['weight_fraction_esd']:.3f}% | a = {phases['Cu3WO6']['cell']['length_a']:.5f} A |
| WO3 | {100 * phases['WO3']['weight_fraction']:.3f}% | {100 * phases['WO3']['weight_fraction_esd']:.3f}% | a = {phases['WO3']['cell']['length_a']:.5f}, b = {phases['WO3']['cell']['length_b']:.5f}, c = {phases['WO3']['cell']['length_c']:.5f} A; beta = {phases['WO3']['cell']['angle_beta']:.4f} deg |
| CuO | {100 * phases['CuO']['weight_fraction']:.3f}% | {100 * phases['CuO']['weight_fraction_esd']:.3f}% | a = {phases['CuO']['cell']['length_a']:.5f}, b = {phases['CuO']['cell']['length_b']:.5f}, c = {phases['CuO']['cell']['length_c']:.5f} A; beta = {phases['CuO']['cell']['angle_beta']:.4f} deg |

The final full-range fit has Rwp = {stats['r_wp_percent']:.4f}%, Rp = {stats['r_p_percent']:.4f}%, Rexp = {stats['r_exp_percent']:.4f}%, and goodness of fit = {stats['goodness_of_fit']:.4f} ({stats['n_observations']} points, {stats['n_refined_parameters']} variables). The last maximum shift/e.s.d. was {stats['max_shift_over_esd']:.4g}.

## Evidence and model selection

Cu3WO6 is supported by coherent Pa-3 families at approximately 15.76, 20.37, 32.94/33.08, 34.31, 36.81, 50.44, 58.19, and 63.88 degrees 2theta. Monoclinic WO3 accounts for the diagnostic 23.21/23.65/24.46 degree triplet and repeated families near 26.66, 28.71/29.02, 33.34/33.65, 47.36, 53.59, 62.37, and 76.35 degrees. CuO is required by its 35.68 and 38.81 degree pair plus corroborating higher-angle reflections near 48.99, 53.59, 58.19, and 61.98 degrees. Adding CuO lowered Rwp from 5.17% to 3.83% before phase-width refinement.

This assemblage is chemically consistent with reaction of the reported CuO and WO3 precursors at 550 degrees C to form Cu3WO6 while leaving residual precursor oxides.

Exact-composition records were screened for occupancy, symmetry, source conditions, and geometry. The selected structures are COD 1527404 (Cu3WO6), room-temperature neutron-derived COD 2311041 (WO3), and COD 1011194 (tenorite CuO), all fully occupied. Refined-cell geometry remains plausible: W-O distances are 1.79-2.08 A in Cu3WO6 and 1.71-2.16 A in WO3; Cu3WO6 has Cu-O distances of 1.92-2.24 A, while CuO retains four short Cu-O bonds near 1.95 A and two longer contacts near 2.79 A. The room-temperature monoclinic and low-temperature triclinic WO3 records fit very similarly; the room-temperature monoclinic record was selected on source conditions and marginal fit advantage. The high-pressure WO3 polymorph was strongly rejected. C2/c CuO was slightly better than the Cc alternate and is the standard tenorite symmetry.

After the three-phase common profile was rebuilt, CuWO4 (P-1 and P2/c), Cu2WO4, and Cu2O challenges had scales below 1.5 sigma and changed Rwp by less than 0.0005 percentage point; they were not retained. No coherent unmodeled peak family remains.

## Refinement choices and uncertainty

The baseline uses the supplied Cu Kalpha1/Kalpha2 wavelengths and fixed 0.5 ratio, a six-coefficient smooth Chebyshev background, one zero correction ({inst['Zero'][1]:.5f} degrees), and a nonnegative common U/X profile (U = {inst['U'][1]:.3f}, X = {inst['X'][1]:.3f}; V, W, and Y neutral). Roughness, transparency, extinction, and unused texture/size/strain terms are neutral. Common SH/L refinement collapsed to its lower bound and was pruned. WO3 requires March-Dollase orientation along {tuple(wo_po['axis_hkl'])}, with parameter {wo_po['parameter']:.5f}({int(round(wo_po['parameter_esd'] * 1e5)):d}). Replay-stable phase broadening consists of Cu3WO6 coherent size {phases['Cu3WO6']['coherent_domain_size_micrometre']:.4f}({int(round(phases['Cu3WO6']['coherent_domain_size_esd_micrometre'] * 1e4)):d}) micrometre and CuO strain {phases['CuO']['microstrain']:.0f}({phases['CuO']['microstrain_esd']:.0f}) microstrain. WO3 width trials and the complementary Cu3WO6 strain trial returned to neutral values and were removed.

The tabulated fraction e.s.d.s are covariance-only and do not include structural-model, preferred-orientation, absorption, or sampling systematics; a practical uncertainty of roughly 1-3 wt% is more realistic. Fractions exclude any amorphous material. Phase identities and cells are reliable, but this laboratory pattern cannot uniquely resolve the subtle monoclinic-versus-triclinic WO3 distortion. Atomic coordinates and displacement parameters were retained from the source structures because independent refinements produced bound or poorly determined values; the exported CIFs should therefore be interpreted as phase-identification/QPA models rather than new high-precision structure determinations.
"""
    (ROOT / "report.md").write_text(report)


def main() -> None:
    project = replay()
    if [phase.name for phase in project.phases()] != list(PHASE_INFO):
        raise RuntimeError("unexpected final phase inventory")
    if project.get_Frozen():
        raise RuntimeError(f"final project has frozen variables: {project.get_Frozen()}")
    export_profile(project)
    result = export_results(project)
    export_report(project, result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
