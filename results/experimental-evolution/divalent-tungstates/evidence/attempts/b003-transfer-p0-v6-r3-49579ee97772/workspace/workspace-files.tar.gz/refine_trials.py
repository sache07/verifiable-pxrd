#!/usr/bin/env python3
"""Build comparable GSAS-II trial refinements for the Cu-W-O pattern."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
PATTERN = ROOT / "inputs" / "pattern.csv"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


MODELS = {
    "mono_old": ("1527404", "1528915"),
    "mono_neutron": ("1527404", "2311041"),
    "triclinic": ("1527404", "2106293"),
    "mono_hp": ("1527404", "1563541"),
}


def prepare_inputs() -> tuple[Path, Path]:
    TMP.mkdir(exist_ok=True)
    xye = TMP / "pattern.xye"
    with PATTERN.open(newline="") as source, xye.open("w") as target:
        rows = csv.DictReader(source)
        target.write("# two_theta_deg intensity_counts\n")
        for row in rows:
            target.write(f"{float(row['two_theta_deg']):.8f} {float(row['intensity']):.8f}\n")

    inst = TMP / "cu_ka_lab.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for lab CuKa reflection data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;"
        "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:0.0;V:0.0;W:50.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )
    return xye, inst


def neutralize_phase(phase, histname: str) -> None:
    hap = phase.data["Histograms"][histname]
    hap["Pref.Ori."] = ["MD", 1.0, False, [0, 0, 1], 0, {}, [], 0.1]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [1000.0, 1000.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][4] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def set_parameter_limits(project) -> None:
    # Instrument-profile terms are constrained to physically meaningful signs.
    for variable in (":0:U", ":0:W", ":0:X"):
        project.set_Controls("parmMin", 0.0, variable)
    for variable, value in ((":0:U", 1000.0), (":0:W", 1000.0), (":0:X", 100.0)):
        project.set_Controls("parmMax", value, variable)


def summary(project, stage: str) -> dict:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    row = {
        "stage": stage,
        "residuals": {
            k: float(v)
            for k, v in hist.residuals.items()
            if isinstance(v, (int, float, np.integer, np.floating))
        },
        "instrument": {
            k: float(inst[k][1])
            for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)")
            if k in inst
        },
        "background": [float(v) for v in hist.Background[0][3:]],
        "phases": {},
        "frozen": project.get_Frozen(),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        row["phases"][phase.name] = {
            "cell": {k: float(v) for k, v in phase.get_cell().items()},
            "scale": float(hap["Scale"][0]),
            "size": list(hap["Size"][:3]),
            "mustrain": list(hap["Mustrain"][:3]),
        }
    print(json.dumps(row, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else x))
    return row


def run(model: str) -> None:
    xye, inst = prepare_inputs()
    cu_id, wo_id = MODELS[model]
    gpx_path = TMP / f"trial_{model}.gpx"
    if gpx_path.exists():
        gpx_path.unlink()
    project = G2sc.G2Project(newgpx=str(gpx_path))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": [1500.0, 600.0, 100.0, 0.0, 0.0, 0.0],
            },
        }
    )
    cu = project.add_phase(
        str(cod_path(cu_id)), phasename="Cu3WO6", histograms=[hist], fmthint="CIF"
    )
    wo = project.add_phase(
        str(cod_path(wo_id)), phasename=f"WO3_{wo_id}", histograms=[hist], fmthint="CIF"
    )
    for phase in (cu, wo):
        neutralize_phase(phase, hist.name)
        phase.set_HAP_refinements({"Scale": True}, [hist])

    # Reflection geometry: no roughness, transparency or texture surrogates.
    for name in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if name in hist.SampleParameters:
            hist.SampleParameters[name][0] = 0.0
            hist.SampleParameters[name][1] = False
    hist.SampleParameters["Scale"] = [1.0, False]

    project.set_Controls("cycles", 12)
    set_parameter_limits(project)
    stages = []

    # First obtain nonzero scales and a smooth common background.
    project.refine()
    stages.append(summary(project, "background_scales"))

    # One angular correction and both cells.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    cu.set_refinements({"Cell": True})
    wo.set_refinements({"Cell": True})
    project.refine()
    stages.append(summary(project, "zero_cells"))

    # Build a low-dimensional common profile. V and Y remain neutral and fixed.
    hist.set_refinements({"Instrument Parameters": ["W"]})
    project.refine()
    stages.append(summary(project, "profile_W"))
    hist.set_refinements({"Instrument Parameters": ["U", "X"]})
    project.refine()
    stages.append(summary(project, "profile_UWX"))

    project.save()
    (TMP / f"trial_{model}.json").write_text(json.dumps(stages, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("model", choices=MODELS)
    run(parser.parse_args().model)
