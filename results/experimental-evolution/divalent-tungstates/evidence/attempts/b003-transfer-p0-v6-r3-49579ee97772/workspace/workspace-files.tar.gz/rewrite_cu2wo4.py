#!/usr/bin/env python3
"""Normalize the one-operation P1 COD CIF so GSAS-II can import it."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


source = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/2/00/24/2002403.cif"
)
output = Path(__file__).resolve().parent / ".tmp" / "Cu2WO4_rewritten.cif"
structure = Structure.from_file(source)
CifWriter(structure, symprec=None).write_file(output)
# GSAS-II accepts oxidation states in element-sign-number order.
text = output.read_text()
text = text.replace("  Cu+  ", "  Cu+1 ")
text = text.replace("  W6+  ", "  W+6  ")
text = text.replace("  O2-  ", "  O-2  ")
output.write_text(text)
print(output)
