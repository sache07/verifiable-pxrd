#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/final_checks/polarization_refined.gpx"
AXES = {
    0: {
        "100": [1, 0, 0], "010": [0, 1, 0], "001": [0, 0, 1],
        "110": [1, 1, 0], "101": [1, 0, 1], "011": [0, 1, 1],
        "111": [1, 1, 1],
    },
    1: {
        "100": [1, 0, 0], "010": [0, 1, 0], "001": [0, 0, 1],
        "110": [1, 1, 0], "101": [1, 0, 1], "011": [0, 1, 1],
        "111": [1, 1, 1],
    },
    2: {"100": [1, 0, 0], "110": [1, 1, 0], "111": [1, 1, 1]},
}


def md_correlation(gpx, phase_index: int):
    cov = gpx.data.get("Covariance", {}).get("data", {})
    vary = cov.get("varyList", [])
    mat = cov.get("covMatrix")
    key = f"{phase_index}:0:MD"
    if mat is None or key not in vary:
        return None
    std = np.sqrt(np.clip(np.diag(mat), 1e-300, None))
    corr = mat / np.outer(std, std)
    i = vary.index(key)
    values = [(abs(float(corr[i, j])), vary[j], float(corr[i, j])) for j in range(len(vary)) if j != i]
    _, name, value = max(values)
    return name, value


def clear_textures(gpx) -> None:
    hist = gpx.histogram(0)
    for phase in gpx.phases():
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = False
        po[3] = [0, 0, 1]
        po[4] = 0
        po[5] = {}


def run(phase_index: int, label: str, axis: list[int] | None) -> None:
    outdir = ROOT / "trials/final_checks" / f"texture_phase{phase_index}"
    outdir.mkdir(parents=True, exist_ok=True)
    out = outdir / f"{label}.gpx"
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(out))
    gpx.set_Frozen()
    clear_textures(gpx)
    hist = gpx.histogram(0)
    # WO3 and MgO texture tests are challenges to the accepted model, so
    # retain the strongly supported MgWO4 [010] correction while testing them.
    if phase_index != 0:
        mgwo4_po = gpx.phase(0).data["Histograms"][hist.name]["Pref.Ori."]
        mgwo4_po[1] = 1.3028370631290003
        mgwo4_po[2] = True
        mgwo4_po[3] = [0, 1, 0]
    if axis is not None:
        po = gpx.phase(phase_index).data["Histograms"][hist.name]["Pref.Ori."]
        po[1] = 1.0
        po[2] = True
        po[3] = axis
        gpx.set_Controls("parmMin", 0.1, f"{phase_index}:0:MD")
        gpx.set_Controls("parmMax", 10.0, f"{phase_index}:0:MD")
    gpx.set_Controls("cycles", 12)
    for _ in range(2):
        gpx.refine(makeBack=False)
    gpx.save()
    gpx = G2sc.G2Project(str(out), newgpx=str(out))
    gpx.set_Frozen()
    gpx.refine(makeBack=False)
    gpx.save()

    hist = gpx.histogram(0)
    po = gpx.phase(phase_index).data["Histograms"][hist.name]["Pref.Ori."]
    cov = gpx.data.get("Covariance", {}).get("data", {})
    print(
        "FINAL_TEXTURE", phase_index, label,
        "Rwp", hist.get_wR(),
        "MD", po[1],
        "fractions", hist.ComputeMassFracs(),
        "Rf", [hist.residuals.get(f"{i}:0:Rf") for i in range(3)],
        "maxshift", cov.get("Rvals", {}).get("Max shft/sig"),
        "MDcorr", md_correlation(gpx, phase_index),
        "frozen", gpx.get_Frozen(),
        flush=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", type=int, choices=[0, 1, 2])
    args = parser.parse_args()
    if args.phase == 0:
        run(0, "none", None)
    for label, axis in AXES[args.phase].items():
        run(args.phase, label, axis)


if __name__ == "__main__":
    main()
