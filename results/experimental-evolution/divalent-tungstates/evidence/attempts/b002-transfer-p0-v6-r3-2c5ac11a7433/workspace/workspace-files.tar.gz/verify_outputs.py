#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from pymatgen.core import Structure


ROOT = Path(__file__).resolve().parent


def main() -> None:
    result = json.loads((ROOT / "result.json").read_text(encoding="utf-8"))
    gpx = G2sc.G2Project(str(ROOT / "final.gpx"))
    hist = gpx.histogram(0)

    with (ROOT / "fit.csv").open(newline="", encoding="utf-8") as handle:
        reader = csv.reader(handle)
        header = next(reader)
        profile = np.asarray([[float(value) for value in row] for row in reader])
    expected_header = [
        "two_theta_deg", "observed_counts", "calculated_counts",
        "difference_counts", "background_counts",
    ]
    assert header == expected_header
    assert profile.shape == (8301, 5)
    expected = np.column_stack([
        hist.getdata("X"), hist.getdata("Yobs"), hist.getdata("Ycalc"),
        hist.getdata("Residual"), hist.getdata("Background"),
    ])
    assert np.allclose(profile, expected, rtol=0.0, atol=1e-12)
    assert np.allclose(profile[:, 3], profile[:, 1] - profile[:, 2], rtol=0.0, atol=1e-8)

    fractions = hist.ComputeMassFracs()
    assert abs(sum(value[0] for value in fractions.values()) - 1.0) < 1e-12
    assert abs(result["fit_statistics"]["Rwp_percent"] - hist.get_wR()) < 1e-12
    assert result["fit_statistics"]["n_observations"] == profile.shape[0]
    assert not gpx.get_Frozen()

    expected_formulas = ["MgWO4", "WO3", "MgO"]
    checks = []
    for phase, phase_result, formula in zip(gpx.phases(), result["phases"], expected_formulas):
        cif_path = ROOT / phase_result["cif_path"]
        assert cif_path.is_file()
        structure = Structure.from_file(cif_path)
        assert structure.composition.reduced_formula == formula
        occupancies = [float(sum(site.species.values())) for site in structure]
        assert all(abs(value - 1.0) < 1e-8 for value in occupancies)
        distance_matrix = np.asarray(structure.distance_matrix)
        min_distance = float(np.min(distance_matrix[distance_matrix > 1e-8]))
        assert min_distance > 1.5
        cell = phase.get_cell()
        assert abs(structure.lattice.a - cell["length_a"]) < 2e-4
        assert abs(structure.lattice.b - cell["length_b"]) < 2e-4
        assert abs(structure.lattice.c - cell["length_c"]) < 2e-4
        fraction = fractions[phase.name][0]
        assert abs(phase_result["weight_fraction_normalized_crystalline"] - fraction) < 1e-12
        checks.append((formula, len(structure), min_distance, fraction))

    print(
        "VERIFIED",
        "profile_shape", profile.shape,
        "Rwp", hist.get_wR(),
        "maxshift", gpx.data["Covariance"]["data"]["Rvals"]["Max shft/sig"],
        "structures", checks,
        flush=True,
    )


if __name__ == "__main__":
    main()
