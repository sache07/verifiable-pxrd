#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/wo3_records/2311041_monoclinic_neutron_RT.gpx"
OUTPUT = ROOT / "trials/wo3_records/2311041_final_nuisance.gpx"


def top_correlations(covdata, count: int = 6):
    cov = covdata.get("covMatrix")
    vary = covdata.get("varyList", [])
    if cov is None or len(vary) < 2:
        return []
    sig = np.sqrt(np.clip(np.diag(cov), 1e-300, None))
    corr = cov / np.outer(sig, sig)
    pairs = []
    for i in range(len(vary)):
        for j in range(i):
            pairs.append((abs(float(corr[i, j])), vary[i], vary[j], float(corr[i, j])))
    return [(a, b, c) for _, a, b, c in sorted(pairs, reverse=True)[:count]]


def report(gpx, label: str) -> None:
    hist = gpx.histogram(0)
    wo3 = gpx.phase(1).data["Histograms"][hist.name]
    po = gpx.phase(0).data["Histograms"][hist.name]["Pref.Ori."]
    cov = gpx.data.get("Covariance", {}).get("data", {})
    print(
        "MONO_CHALLENGE", label,
        "Rwp", hist.get_wR(),
        "fractions", hist.ComputeMassFracs(),
        "MD", po[1],
        "WO3strain", wo3["Mustrain"][1][0],
        "profile", {k: hist.InstrumentParameters[k][1] for k in ["U", "W", "X"]},
        "maxshift", cov.get("Rvals", {}).get("Max shft/sig"),
        "corr", top_correlations(cov),
        "frozen", gpx.get_Frozen(),
        flush=True,
    )


def run_rounds(gpx, label: str, rounds: int) -> None:
    old = None
    for i in range(rounds):
        gpx.refine(makeBack=False)
        report(gpx, f"{label}_{i + 1}")
        cov = gpx.data.get("Covariance", {}).get("data", {})
        rwp = gpx.histogram(0).get_wR()
        maxshift = cov.get("Rvals", {}).get("Max shft/sig", 1e9)
        if old is not None and abs(rwp - old) < 1e-5 and maxshift is not None and maxshift < 0.05:
            break
        old = rwp


def main() -> None:
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    gpx.set_Frozen()
    gpx.set_Controls("cycles", 12)

    hist = gpx.histogram(0)
    po = gpx.phase(0).data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = [0, 1, 0]
    po[4] = 0
    po[5] = {}
    gpx.set_Controls("parmMin", 0.1, "0:0:MD")
    gpx.set_Controls("parmMax", 10.0, "0:0:MD")
    run_rounds(gpx, "texture", 4)

    wo3 = gpx.phase(1).data["Histograms"][hist.name]
    wo3["Size"][0] = "isotropic"
    wo3["Size"][1][:] = [10.0, 10.0, 1.0]
    wo3["Size"][2][:] = [False, False, False]
    wo3["Mustrain"][0] = "isotropic"
    wo3["Mustrain"][1][:] = [5000.0, 1.0e-6, 1.0]
    wo3["Mustrain"][2][:] = [True, False, False]
    gpx.set_Controls("parmMin", 0.0, "1:0:Mustrain;i")
    gpx.set_Controls("parmMax", 10000.0, "1:0:Mustrain;i")
    run_rounds(gpx, "strain", 7)
    gpx.save()

    # Serialized full-range replay.
    gpx = G2sc.G2Project(str(OUTPUT), newgpx=str(OUTPUT))
    gpx.set_Frozen()
    run_rounds(gpx, "replay", 4)
    gpx.save()
    report(gpx, "FINAL")


if __name__ == "__main__":
    main()
