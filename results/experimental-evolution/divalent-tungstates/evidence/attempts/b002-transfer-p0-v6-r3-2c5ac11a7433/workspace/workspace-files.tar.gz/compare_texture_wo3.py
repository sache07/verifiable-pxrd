#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/texture_mgwo4/mgwo4_MD_010.gpx"
OUTDIR = ROOT / "trials/texture_wo3"
AXES = {
    "100": [1, 0, 0],
    "010": [0, 1, 0],
    "001": [0, 0, 1],
    "110": [1, 1, 0],
    "101": [1, 0, 1],
    "011": [0, 1, 1],
    "111": [1, 1, 1],
}


def top_correlation(covdata):
    cov = covdata.get("covMatrix")
    vary = covdata.get("varyList", [])
    if cov is None or len(vary) < 2:
        return None
    sig = np.sqrt(np.clip(np.diag(cov), 1e-300, None))
    corr = cov / np.outer(sig, sig)
    np.fill_diagonal(corr, 0.0)
    i, j = np.unravel_index(np.argmax(np.abs(corr)), corr.shape)
    return vary[i], vary[j], float(corr[i, j])


def run(label: str, axis: list[int]) -> None:
    out = OUTDIR / f"wo3_MD_{label}.gpx"
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(out))
    gpx.set_Frozen()
    phase = gpx.phase(1)
    hist = gpx.histogram(0)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = axis
    po[4] = 0
    po[5] = {}
    gpx.set_Controls("parmMin", 0.1, "1:0:MD")
    gpx.set_Controls("parmMax", 10.0, "1:0:MD")
    gpx.set_Controls("cycles", 12)
    for _ in range(3):
        gpx.refine(makeBack=False)
    gpx.save()
    hist = gpx.histogram(0)
    po = gpx.phase(1).data["Histograms"][hist.name]["Pref.Ori."]
    cov = gpx.data["Covariance"]["data"]
    print(
        "WO3_TEXTURE_RESULT", label,
        "Rwp", hist.get_wR(),
        "MD", po[1],
        "fractions", hist.ComputeMassFracs(),
        "Rf", [hist.residuals.get(f"{i}:0:Rf") for i in range(3)],
        "profile", {k: hist.InstrumentParameters[k][1] for k in ["U", "W", "X"]},
        "maxshift", cov.get("Rvals", {}).get("Max shft/sig"),
        "topcorr", top_correlation(cov),
        "frozen", gpx.get_Frozen(),
        flush=True,
    )


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    for label, axis in AXES.items():
        run(label, axis)


if __name__ == "__main__":
    main()
