#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/texture_mgwo4/mgwo4_MD_010.gpx"
OUTDIR = ROOT / "trials/texture_mgo"
AXES = {"100": [1, 0, 0], "110": [1, 1, 0], "111": [1, 1, 1]}


def run(label: str, axis: list[int]) -> None:
    out = OUTDIR / f"mgo_MD_{label}.gpx"
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(out))
    gpx.set_Frozen()
    phase = gpx.phase(2)
    hist = gpx.histogram(0)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0:5] = ["MD", 1.0, True, axis, 0]
    po[5] = {}
    gpx.set_Controls("parmMin", 0.1, "2:0:MD")
    gpx.set_Controls("parmMax", 10.0, "2:0:MD")
    gpx.set_Controls("cycles", 12)
    for _ in range(3):
        gpx.refine(makeBack=False)
    gpx.save()
    hist = gpx.histogram(0)
    po = gpx.phase(2).data["Histograms"][hist.name]["Pref.Ori."]
    cov = gpx.data["Covariance"]["data"]
    vary = cov.get("varyList", [])
    sig = cov.get("sig", [])
    md_sig = sig[vary.index("2:0:MD")] if "2:0:MD" in vary else None
    print(
        "MGO_TEXTURE_RESULT", label,
        "Rwp", hist.get_wR(),
        "MD", po[1], "MD_sig", md_sig,
        "fractions", hist.ComputeMassFracs(),
        "Rf", [hist.residuals.get(f"{i}:0:Rf") for i in range(3)],
        "maxshift", cov.get("Rvals", {}).get("Max shft/sig"),
        "frozen", gpx.get_Frozen(),
        flush=True,
    )


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    for label, axis in AXES.items():
        run(label, axis)


if __name__ == "__main__":
    main()
