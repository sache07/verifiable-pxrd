#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/broadening/phase1_strain.gpx"
OUTPUT = ROOT / "trials/final_checks/triclinic_polarization_staged.gpx"


def report(gpx, label: str) -> None:
    hist = gpx.histogram(0)
    cov = gpx.data.get("Covariance", {}).get("data", {})
    print(
        "TRICLINIC_STAGE", label,
        "Rwp", hist.get_wR(),
        "polarization", hist.InstrumentParameters["Polariz."][1],
        "fractions", hist.ComputeMassFracs(),
        "maxshift", cov.get("Rvals", {}).get("Max shft/sig"),
        "frozen", gpx.get_Frozen(),
        flush=True,
    )


def set_full_flags(gpx, enabled: bool) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = enabled
    hist.SampleParameters["Shift"][1] = enabled
    for key in ["U", "W", "X"]:
        hist.InstrumentParameters[key][2] = enabled
    for i, phase in enumerate(gpx.phases()):
        phase.set_refinements({"Cell": enabled})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True  # scales stay active in both stages
        hap["Pref.Ori."][2] = enabled and i == 0
        hap["Size"][2][0] = False
        hap["Mustrain"][2][0] = enabled and i == 1


def main() -> None:
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    gpx.set_Frozen()
    gpx.set_Controls("cycles", 12)
    hist = gpx.histogram(0)
    hist.InstrumentParameters["Polariz."][2] = True
    gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
    gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")

    # Solve the angular intensity correction with only phase scales coupled.
    set_full_flags(gpx, False)
    for i in range(2):
        gpx.refine(makeBack=False)
        report(gpx, f"polarization_scales_{i + 1}")

    # Then reconverge every accepted nuisance term and structural metric.
    set_full_flags(gpx, True)
    for i in range(4):
        gpx.refine(makeBack=False)
        report(gpx, f"full_{i + 1}")
    gpx.save()
    gpx = G2sc.G2Project(str(OUTPUT), newgpx=str(OUTPUT))
    gpx.set_Frozen()
    for i in range(2):
        gpx.refine(makeBack=False)
        report(gpx, f"replay_{i + 1}")
    gpx.save()
    report(gpx, "FINAL")


if __name__ == "__main__":
    main()
