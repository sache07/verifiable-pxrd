#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import neutralize_hap

ROOT = Path(__file__).resolve().parent
TRIALS = ROOT / "trials" / "wo3_records"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
MGWO4 = COD / "9/01/39/9013902.cif"
MGO = COD / "9/00/04/9000499.cif"
WO3_RECORDS = {
    "1528915_monoclinic_xray_RT": COD / "1/52/89/1528915.cif",
    "2311041_monoclinic_neutron_RT": COD / "2/31/10/2311041.cif",
    "2106293_triclinic": COD / "2/10/62/2106293.cif",
    "2107312_orthorhombic": COD / "2/10/73/2107312.cif",
}


def setup(record_name: str, wo3_path: Path):
    out = TRIALS / f"{record_name}.gpx"
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    hist.data["Background"][0] = [
        "chebyschev-1", True, 6, 3500.0, 0.0, 0.0, 0.0, 0.0, 0.0
    ]
    for key in ["Absorption", "DisplaceX", "DisplaceY", "Shift", "SurfRoughA", "SurfRoughB", "Transparency"]:
        hist.SampleParameters[key] = [0.0, False]
    hist.SampleParameters["Scale"] = [1.0, False]
    phases = [
        ("MgWO4_wolframite", MGWO4),
        ("WO3", wo3_path),
        ("MgO_periclase", MGO),
    ]
    for name, path in phases:
        phase = gpx.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
        neutralize_hap(phase, hist.name)
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    for variable, lo, hi in [
        (":0:U", 0.0, 100.0),
        (":0:W", 0.0, 100.0),
        (":0:X", 0.0, 100.0),
        (":0:Shift", -500.0, 500.0),
        ("0:0:Scale", 1.0e-12, 1.0e6),
        ("1:0:Scale", 1.0e-12, 1.0e6),
        ("2:0:Scale", 1.0e-12, 1.0e6),
    ]:
        gpx.set_Controls("parmMin", lo, variable)
        gpx.set_Controls("parmMax", hi, variable)
    gpx.save()
    return gpx


def run(record_name: str, wo3_path: Path) -> None:
    gpx = setup(record_name, wo3_path)
    hist = gpx.histogram(0)
    gpx.refine(makeBack=False)
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    gpx.refine(makeBack=False)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    for _ in range(3):
        gpx.refine(makeBack=False)
    gpx.save()
    hist = gpx.histogram(0)
    cov = gpx.data["Covariance"]["data"]
    inst = hist.InstrumentParameters
    print(
        "RESULT",
        record_name,
        "Rwp", hist.get_wR(),
        "Rf", [hist.residuals.get(f"{i}:0:Rf") for i in range(3)],
        "fractions", hist.ComputeMassFracs(),
        "profile", {k: inst[k][1] for k in ["U", "W", "X", "SH/L"]},
        "shift", hist.SampleParameters["Shift"][0],
        "WO3cell", gpx.phase(1).get_cell(),
        "maxshift", cov.get("Rvals", {}).get("Max shft/sig"),
        "frozen", gpx.get_Frozen(),
        flush=True,
    )


def main() -> None:
    TRIALS.mkdir(parents=True, exist_ok=True)
    for record_name, path in WO3_RECORDS.items():
        run(record_name, path)


if __name__ == "__main__":
    main()
