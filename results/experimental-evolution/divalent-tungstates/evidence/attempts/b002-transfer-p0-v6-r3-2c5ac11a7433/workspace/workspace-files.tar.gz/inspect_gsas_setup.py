#!/usr/bin/env python3
from pathlib import Path
from pprint import pprint

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PHASES = [
    ("MgWO4_wolframite", COD / "9/01/39/9013902.cif"),
    ("WO3_monoclinic", COD / "1/52/89/1528915.cif"),
    ("MgO_periclase", COD / "9/00/04/9000499.cif"),
]

gpx = G2sc.G2Project(newgpx=str(ROOT / "setup_inspection.gpx"))
hist = gpx.add_powder_histogram(
    str(ROOT / "inputs/pattern.csv"),
    str(ROOT / "instrument.instprm"),
    fmthint="comma",
)
for name, path in PHASES:
    gpx.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")

print("HISTOGRAM", hist.name)
print("LIMITS")
pprint(hist.data["Limits"])
print("INSTRUMENT")
pprint(hist.InstrumentParameters)
print("SAMPLE")
pprint(hist.SampleParameters)
print("BACKGROUND")
pprint(hist.Background)
print("CONTROLS")
pprint(gpx.data["Controls"]["data"])
for phase in gpx.phases():
    print("PHASE", phase.name)
    print("CELL", phase.get_cell())
    print("COMPOSITION", phase.composition)
    print("HAP")
    pprint(phase.data["Histograms"][hist.name])
gpx.save()
