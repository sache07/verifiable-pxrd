#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/final_checks/polarization_refined.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = [
    {
        "name": "magnesium tungstate (wolframite)",
        "formula": "MgWO4",
        "cod_id": "9013902",
        "cif": "phase_1_MgWO4.cif",
    },
    {
        "name": "tungsten trioxide (monoclinic)",
        "formula": "WO3",
        "cod_id": "2311041",
        "cif": "phase_2_WO3.cif",
    },
    {
        "name": "magnesium oxide (periclase)",
        "formula": "MgO",
        "cod_id": "9000499",
        "cif": "phase_3_MgO.cif",
    },
]


def enforce_selected_model(gpx) -> None:
    """Prune rejected terms and leave only the selected refinement model."""
    gpx.set_Frozen()
    hist = gpx.histogram(0)
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    hist.Background[0][1] = True
    hist.SampleParameters["Scale"] = [1.0, False]
    for key in ["Absorption", "DisplaceX", "DisplaceY", "Transparency", "SurfRoughA", "SurfRoughB"]:
        hist.SampleParameters[key] = [0.0, False]
    hist.SampleParameters["Shift"][1] = True
    for key in ["U", "W", "X", "Polariz."]:
        hist.InstrumentParameters[key][2] = True
    for key in ["V", "Y", "SH/L"]:
        hist.InstrumentParameters[key][2] = False

    for i, phase in enumerate(gpx.phases()):
        phase.set_refinements({"Cell": True, "Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        hap["Scale"][1] = True
        hap["Extinction"] = [0.0, False]
        hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
        hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        po = hap["Pref.Ori."]
        po[0] = "MD"
        po[4] = 0
        po[5] = {}
        if i == 0:
            po[2] = True
            po[3] = [0, 1, 0]
        else:
            po[1] = 1.0
            po[2] = False
            po[3] = [0, 0, 1]

    # Only WO3 supports an additional isotropic microstrain contribution.
    hist = gpx.histogram(0)
    for i in [0, 2]:
        hap = gpx.phase(i).data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 1.0e-6
    wo3_hap = gpx.phase(1).data["Histograms"][hist.name]
    wo3_hap["Mustrain"][2][0] = True


def replay_final() -> G2sc.G2Project:
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    enforce_selected_model(gpx)
    gpx.set_Controls("cycles", 12)
    gpx.refine(makeBack=False)
    gpx.save()

    gpx = G2sc.G2Project(str(FINAL), newgpx=str(FINAL))
    enforce_selected_model(gpx)
    gpx.refine(makeBack=False)
    gpx.save()
    return G2sc.G2Project(str(FINAL))


def export_profile(hist) -> None:
    x = np.asarray(hist.getdata("X"), dtype=float)
    yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    difference = np.asarray(hist.getdata("Residual"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)
    if not np.allclose(difference, yobs - ycalc, rtol=0.0, atol=1e-8):
        raise RuntimeError("GSAS-II residual is not observed minus calculated")
    with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "two_theta_deg", "observed_counts", "calculated_counts",
            "difference_counts", "background_counts",
        ])
        writer.writerows(zip(x, yobs, ycalc, difference, background))


def cell_for_json(phase) -> dict[str, float]:
    cell = phase.get_cell()
    return {
        "a_A": float(cell["length_a"]),
        "b_A": float(cell["length_b"]),
        "c_A": float(cell["length_c"]),
        "alpha_deg": float(cell["angle_alpha"]),
        "beta_deg": float(cell["angle_beta"]),
        "gamma_deg": float(cell["angle_gamma"]),
        "volume_A3": float(cell["volume"]),
    }


def export_result_and_report(gpx) -> None:
    hist = gpx.histogram(0)
    fractions = hist.ComputeMassFracs()
    cov = gpx.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    phase_rows = []
    for i, (phase, info) in enumerate(zip(gpx.phases(), PHASE_INFO)):
        fraction, formal_esd = fractions[phase.name]
        sg = phase.data["General"]["SGData"]["SpGrp"].strip()
        row = {
            **info,
            "space_group": sg,
            "cif_path": info["cif"],
            "weight_fraction_normalized_crystalline": float(fraction),
            "weight_fraction_formal_esd": float(formal_esd),
            "weight_percent_normalized_crystalline": 100.0 * float(fraction),
            "cell": cell_for_json(phase),
        }
        row.pop("cif")
        phase_rows.append(row)

    result = {
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": float(hist.get_wR()),
            "Rp_percent": float(hist.residuals["R"]),
            "Rb_percent": float(hist.residuals["Rb"]),
            "wRb_percent": float(hist.residuals["wRb"]),
            "Rexp_percent": float(hist.residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_variables": int(rvals["Nvars"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
        },
        "normalization": "Modeled crystalline phases sum to 1. No amorphous fraction was determined.",
        "weighting": "Poisson counting weights (1/Yobs) because the supplied pattern had counts but no uncertainties.",
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")

    mg, wo, mgo = phase_rows
    inst = hist.InstrumentParameters
    shift = hist.SampleParameters["Shift"][0]
    md = gpx.phase(0).data["Histograms"][hist.name]["Pref.Ori."][1]
    strain = gpx.phase(1).data["Histograms"][hist.name]["Mustrain"][1][0]
    report = f"""# Quantitative phase analysis

## Result

The pattern is modeled by three crystalline phases, normalized over the modeled crystalline material:

| Phase | Structure used | Weight fraction |
|---|---|---:|
| MgWO4, wolframite | COD 9013902, {mg['space_group']} | {mg['weight_percent_normalized_crystalline']:.2f} wt% |
| WO3, monoclinic | COD 2311041, {wo['space_group']} | {wo['weight_percent_normalized_crystalline']:.2f} wt% |
| MgO, periclase | COD 9000499, {mgo['space_group']} | {mgo['weight_percent_normalized_crystalline']:.2f} wt% |

The final full-range fit has Rwp = {hist.get_wR():.3f}%, Rp = {hist.residuals['R']:.3f}%, and GOF = {rvals['GOF']:.3f}. These fractions do not measure amorphous content because no external standard was supplied.

## Evidence and model selection

The chemical context (MgO + WO3 heated at 700 °C) supports MgWO4 formation with residual WO3 and MgO. MgWO4 accounts for the intense 18.9° line and coherent families throughout the range; WO3 accounts for the 23.1–24.4° cluster and the numerous broader families at middle and high angle; MgO is supported by the coherent periclase sequence near 42.9°, 62.3°, 74.6°, 78.8°, and 93.8° 2theta. Removing MgO raises Rwp to 3.064%; removing WO3 or MgWO4 raises it to 17.57% and more than 21%, respectively. All selected source models are ordered, fully occupied records with chemically sensible geometry. Exact entries existed, so analogue substitution was not needed.

Several physical WO3 records were compared under the same restrained nuisance model. The room-temperature monoclinic neutron structure (COD 2311041) was selected. A triclinic alternative (COD 2106293) remained worse after staged polarization and three full reconvergences (Rwp 2.598%, still less stable, versus 2.392% for the replay-stable monoclinic model); orthorhombic/high-pressure alternatives either fit much worse or drove profile terms to bounds.

The retained refinement uses a smooth six-term Chebyshev background, all phase scales and cells, one specimen shift ({shift:.3f} micrometres in the GSAS-II convention), common nonnegative U/W/X profile terms, and a refined polarization fraction ({inst['Polariz.'][1]:.5f}). MgWO4 has a replay-stable March-Dollase [010] correction (coefficient {md:.5f}); no texture raises Rwp to 7.114%, and the other tested axial/diagonal axes are substantially worse. WO3 requires isotropic microstrain ({strain:.0f} microstrain); size alone is inferior, and combined size+strain is 93.5% correlated and gives no improvement. MgWO4/MgO size and strain, SH/L asymmetry, roughness, additional texture, and anisotropic broadening were rejected as unsupported, unstable, or bound-seeking. Atomic coordinates and occupancies were not refined.

## Uncertainty

The tabulated fractions are well supported as a three-phase crystalline inventory, but their realistic precision is limited by profile/texture and WO3-structure systematics. The formal covariance errors in `result.json` (about 0.07–0.10 absolute wt%) assume ideal Poisson statistics and are too optimistic; about 1–2 absolute wt% is a more defensible interpretation. Laboratory powder data do not uniquely prove the fine monoclinic-versus-triclinic distortion or detailed WO3 coordinates, although the selected ambient monoclinic model is both physically appropriate and the best stable fit. The smooth residual contains no coherent extra peak family requiring a fourth crystalline phase.
"""
    (ROOT / "report.md").write_text(report, encoding="utf-8")


def main() -> None:
    gpx = replay_final()
    hist = gpx.histogram(0)
    if gpx.get_Frozen():
        raise RuntimeError(f"Final project has frozen variables: {gpx.get_Frozen()}")
    if gpx.data["Covariance"]["data"]["Rvals"]["Max shft/sig"] >= 0.05:
        raise RuntimeError("Final serialized replay did not converge tightly")
    for phase, info in zip(gpx.phases(), PHASE_INFO):
        phase.export_CIF(str(ROOT / info["cif"]))
    export_profile(hist)
    export_result_and_report(gpx)
    print(
        "FINALIZED",
        "Rwp", hist.get_wR(),
        "fractions", hist.ComputeMassFracs(),
        "maxshift", gpx.data["Covariance"]["data"]["Rvals"]["Max shft/sig"],
        "frozen", gpx.get_Frozen(),
        flush=True,
    )


if __name__ == "__main__":
    main()
