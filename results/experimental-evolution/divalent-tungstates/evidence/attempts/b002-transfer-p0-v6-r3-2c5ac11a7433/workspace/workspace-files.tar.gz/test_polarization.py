#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/wo3_records/2311041_final_nuisance.gpx"
OUTPUT = ROOT / "trials/final_checks/polarization_refined.gpx"


def summarize(gpx, label: str) -> None:
    hist = gpx.histogram(0)
    cov = gpx.data.get("Covariance", {}).get("data", {})
    vary = cov.get("varyList", [])
    sig = cov.get("sig", [])
    var = ":0:Polariz."
    sigma = float(sig[vary.index(var)]) if var in vary else None
    corr = None
    if var in vary and cov.get("covMatrix") is not None:
        mat = cov["covMatrix"]
        std = np.sqrt(np.clip(np.diag(mat), 1e-300, None))
        cmat = mat / np.outer(std, std)
        i = vary.index(var)
        j = int(np.argmax(np.abs(np.delete(cmat[i], i))))
        if j >= i:
            j += 1
        corr = (vary[j], float(cmat[i, j]))
    print(
        "POLARIZATION", label,
        "Rwp", hist.get_wR(),
        "value", hist.InstrumentParameters["Polariz."][1],
        "sigma", sigma,
        "fractions", hist.ComputeMassFracs(),
        "maxshift", cov.get("Rvals", {}).get("Max shft/sig"),
        "correlation", corr,
        "frozen", gpx.get_Frozen(),
        flush=True,
    )


def refine_rounds(gpx, label: str, rounds: int = 4) -> None:
    for i in range(rounds):
        gpx.refine(makeBack=False)
        summarize(gpx, f"{label}_{i + 1}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=SOURCE)
    parser.add_argument("--output", type=Path, default=OUTPUT)
    args = parser.parse_args()
    output = args.output.resolve()
    source = args.source.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(str(source), newgpx=str(output))
    gpx.set_Frozen()
    gpx.set_Controls("cycles", 12)
    hist = gpx.histogram(0)
    hist.InstrumentParameters["Polariz."][2] = True
    gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
    gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")
    refine_rounds(gpx, "fit", 3)
    gpx.save()

    gpx = G2sc.G2Project(str(output), newgpx=str(output))
    gpx.set_Frozen()
    refine_rounds(gpx, "replay", 2)
    gpx.save()
    summarize(gpx, "FINAL")


if __name__ == "__main__":
    main()
