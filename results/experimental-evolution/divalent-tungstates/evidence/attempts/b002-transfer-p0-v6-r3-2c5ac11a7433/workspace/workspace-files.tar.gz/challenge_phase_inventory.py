#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/final_checks/polarization_refined.gpx"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", type=int, choices=[0, 1, 2])
    args = parser.parse_args()
    outdir = ROOT / "trials/final_checks/inventory"
    outdir.mkdir(parents=True, exist_ok=True)
    out = outdir / f"without_phase{args.phase}.gpx"

    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(out))
    gpx.set_Frozen()
    hist = gpx.histogram(0)
    removed = gpx.phase(args.phase)
    hap = removed.data["Histograms"][hist.name]
    hap["Use"] = False
    hap["Scale"][1] = False
    removed.set_refinements({"Cell": False})
    gpx.set_Controls("cycles", 12)
    for _ in range(2):
        gpx.refine(makeBack=False)
    gpx.save()
    gpx = G2sc.G2Project(str(out), newgpx=str(out))
    gpx.set_Frozen()
    gpx.refine(makeBack=False)
    gpx.save()
    hist = gpx.histogram(0)
    cov = gpx.data.get("Covariance", {}).get("data", {})
    print(
        "INVENTORY_CHALLENGE",
        "removed", args.phase, removed.name,
        "Rwp", hist.get_wR(),
        "Rp", hist.residuals.get("R"),
        "maxshift", cov.get("Rvals", {}).get("Max shft/sig"),
        "frozen", gpx.get_Frozen(),
        flush=True,
    )


if __name__ == "__main__":
    main()
