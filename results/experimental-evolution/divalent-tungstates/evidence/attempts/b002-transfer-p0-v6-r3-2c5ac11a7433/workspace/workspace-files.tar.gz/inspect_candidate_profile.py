#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "trials/final_checks/polarization_refined.gpx"
PLOT = ROOT / "trials/final_checks/polarization_refined.png"


def main() -> None:
    gpx = G2sc.G2Project(str(PROJECT))
    hist = gpx.histogram(0)
    x = np.asarray(hist.getdata("X"), dtype=float)
    yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    diff = np.asarray(hist.getdata("Residual"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)

    print("POINTS", len(x), "RANGE", (x[0], x[-1]))
    for low, high in [(9.9, 30), (30, 55), (55, 75), (75, 100.1)]:
        mask = (x >= low) & (x < high)
        print(
            "BAND", low, high,
            "rms", float(np.sqrt(np.mean(diff[mask] ** 2))),
            "mean", float(np.mean(diff[mask])),
            "maxabs", float(np.max(np.abs(diff[mask]))),
            "background_range", (float(np.min(background[mask])), float(np.max(background[mask]))),
        )

    fig, axes = plt.subplots(3, 1, figsize=(18, 11), constrained_layout=True)
    ranges = [(9.9, 40), (40, 70), (70, 100.1)]
    offset = float(np.quantile(background, 0.05) - 700.0)
    for ax, (low, high) in zip(axes, ranges):
        mask = (x >= low) & (x <= high)
        ax.plot(x[mask], yobs[mask], color="black", linewidth=0.65, label="Observed")
        ax.plot(x[mask], ycalc[mask], color="#d62728", linewidth=0.9, label="Calculated")
        ax.plot(x[mask], background[mask], color="#2ca02c", linewidth=0.7, label="Background")
        ax.plot(x[mask], diff[mask] + offset, color="#1f77b4", linewidth=0.65, label="Difference (offset)")
        ax.axhline(offset, color="0.65", linewidth=0.5)
        ax.set_xlim(low, high)
        ax.set_ylabel("counts")
        ax.grid(alpha=0.15)
    axes[0].legend(ncol=4, fontsize=9, loc="upper right")
    axes[-1].set_xlabel(r"$2\theta$ (deg)")
    fig.savefig(PLOT, dpi=180)
    print("WROTE", PLOT)


if __name__ == "__main__":
    main()
