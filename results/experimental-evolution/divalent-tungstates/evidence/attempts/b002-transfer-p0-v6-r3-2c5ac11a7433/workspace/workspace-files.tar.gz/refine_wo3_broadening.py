#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/broadening/phase1_strain.gpx"
OUTPUT = ROOT / "trials/broadening/wo3_size_strain.gpx"


def top_correlations(covdata, count: int = 8):
    cov = covdata.get("covMatrix")
    vary = covdata.get("varyList", [])
    if cov is None or len(vary) < 2:
        return []
    sig = np.sqrt(np.clip(np.diag(cov), 1e-300, None))
    corr = cov / np.outer(sig, sig)
    pairs = []
    for i in range(len(vary)):
        for j in range(i):
            pairs.append((abs(float(corr[i, j])), vary[i], vary[j], float(corr[i, j])))
    return [(a, b, c) for _, a, b, c in sorted(pairs, reverse=True)[:count]]


def state(gpx, label: str) -> None:
    hist = gpx.histogram(0)
    hap = gpx.phase(1).data["Histograms"][hist.name]
    cov = gpx.data.get("Covariance", {}).get("data", {})
    print(
        "STATE", label,
        "Rwp", hist.get_wR(),
        "size", hap["Size"][1][0], hap["Size"][2][0],
        "strain", hap["Mustrain"][1][0], hap["Mustrain"][2][0],
        "fractions", hist.ComputeMassFracs(),
        "profile", {k: hist.InstrumentParameters[k][1] for k in ["U", "W", "X"]},
        "maxshift", cov.get("Rvals", {}).get("Max shft/sig"),
        "correlations", top_correlations(cov),
        "frozen", gpx.get_Frozen(),
        flush=True,
    )


def refine_until_stable(gpx, label: str, rounds: int = 6):
    old_rwp = None
    for i in range(rounds):
        gpx.refine(makeBack=False)
        state(gpx, f"{label}_{i + 1}")
        cov = gpx.data.get("Covariance", {}).get("data", {})
        maxshift = cov.get("Rvals", {}).get("Max shft/sig", 1e9)
        rwp = gpx.histogram(0).get_wR()
        if old_rwp is not None and abs(rwp - old_rwp) < 1e-5 and maxshift is not None and maxshift < 0.02:
            break
        old_rwp = rwp
    return gpx


def main() -> None:
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    gpx.set_Frozen()
    gpx.set_Controls("cycles", 12)
    gpx.set_Controls("parmMin", 0.01, "1:0:Size;i")
    gpx.set_Controls("parmMax", 10.0, "1:0:Size;i")
    gpx.set_Controls("parmMin", 0.0, "1:0:Mustrain;i")
    gpx.set_Controls("parmMax", 10000.0, "1:0:Mustrain;i")

    # First make sure the accepted one-mechanism strain solution is stationary.
    gpx = refine_until_stable(gpx, "strain_only", rounds=5)

    # Add size only after the strain-only model has reconverged.
    hist = gpx.histogram(0)
    hap = gpx.phase(1).data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.20
    hap["Size"][2][0] = True
    gpx = refine_until_stable(gpx, "combined", rounds=8)
    gpx.save()

    # Full-range replay from the serialized project.
    gpx = G2sc.G2Project(str(OUTPUT), newgpx=str(OUTPUT))
    gpx.set_Frozen()
    gpx = refine_until_stable(gpx, "replay", rounds=5)
    gpx.save()
    state(gpx, "FINAL")


if __name__ == "__main__":
    main()
