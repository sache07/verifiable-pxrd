#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from pprint import pformat

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
TRIALS = ROOT / "trials"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PHASES = [
    ("MgWO4_wolframite", COD / "9/01/39/9013902.cif"),
    ("WO3_monoclinic", COD / "1/52/89/1528915.cif"),
    ("MgO_periclase", COD / "9/00/04/9000499.cif"),
]


def neutralize_hap(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."] = ["MD", 1.0, False, [0, 0, 1], 0, {}, [], 0.1]
    # Size is in micrometres and microstrain in 1e-6. These values make
    # their contributions negligible while avoiding singular derivatives.
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1000.0, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [1.0e-6, 1.0e-6, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Scale"] = [1.0, True]


def summarize(gpx, label: str) -> None:
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    cov = gpx.data.get("Covariance", {}).get("data", {})
    print(f"\n===== {label} =====")
    print("residuals", pformat(hist.residuals, sort_dicts=True))
    print(
        "profile",
        {k: inst[k][1] for k in ["U", "V", "W", "X", "Y", "SH/L", "Polariz."]},
    )
    print(
        "sample",
        {k: hist.SampleParameters[k][0] for k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]},
    )
    print("background", hist.Background[0])
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        print(
            phase.name,
            "cell", phase.get_cell(),
            "scale", hap["Scale"],
            "size", hap["Size"][:3],
            "strain", hap["Mustrain"][:3],
            "PO", hap["Pref.Ori."],
        )
    print("mass_fractions", hist.ComputeMassFracs())
    print(
        "covariance",
        {k: cov.get(k) for k in ["Rvals", "varyList", "sig"] if k in cov},
    )
    print("frozen", gpx.get_Frozen())


def refine_and_snapshot(gpx, label: str):
    gpx.refine(makeBack=False)
    out = TRIALS / f"baseline_{label}.gpx"
    gpx.save(str(out))
    gpx = G2sc.G2Project(str(out))
    summarize(gpx, label)
    return gpx


def main() -> None:
    TRIALS.mkdir(exist_ok=True)
    start = TRIALS / "baseline_start.gpx"
    gpx = G2sc.G2Project(newgpx=str(start))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    hist.data["Background"][0] = [
        "chebyschev-1", True, 6, 3500.0, 0.0, 0.0, 0.0, 0.0, 0.0
    ]
    for key in ["Absorption", "DisplaceX", "DisplaceY", "Shift", "SurfRoughA", "SurfRoughB", "Transparency"]:
        hist.SampleParameters[key][0] = 0.0
        hist.SampleParameters[key][1] = False
    hist.SampleParameters["Scale"] = [1.0, False]

    for name, path in PHASES:
        phase = gpx.add_phase(
            str(path), phasename=name, histograms=[hist], fmthint="CIF"
        )
        neutralize_hap(phase, hist.name)
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})

    gpx.set_Controls("cycles", 8)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    for variable, lo, hi in [
        (":0:U", 0.0, 100.0),
        (":0:W", 0.0, 100.0),
        (":0:X", 0.0, 100.0),
        (":0:SH/L", 0.0001, 0.2),
        (":0:Shift", -500.0, 500.0),
        ("0:0:Scale", 1.0e-12, 1.0e6),
        ("1:0:Scale", 1.0e-12, 1.0e6),
        ("2:0:Scale", 1.0e-12, 1.0e6),
    ]:
        gpx.set_Controls("parmMin", lo, variable)
        gpx.set_Controls("parmMax", hi, variable)
    gpx.save()

    # Inventory fit under a restrained common nuisance model.
    gpx = refine_and_snapshot(gpx, "01_scales_background")

    # Reconcile peak positions with one angular correction and all cells.
    hist = gpx.histogram(0)
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    gpx = refine_and_snapshot(gpx, "02_cells_shift")

    # Establish a common nonnegative U/W/X profile.
    hist = gpx.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    gpx = refine_and_snapshot(gpx, "03_common_profile")

    # Test axial-divergence asymmetry only after the symmetric baseline.
    hist = gpx.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    gpx = refine_and_snapshot(gpx, "04_asymmetry")

    # Full-range replay after save/reopen.
    gpx = refine_and_snapshot(gpx, "05_replay")


if __name__ == "__main__":
    main()
