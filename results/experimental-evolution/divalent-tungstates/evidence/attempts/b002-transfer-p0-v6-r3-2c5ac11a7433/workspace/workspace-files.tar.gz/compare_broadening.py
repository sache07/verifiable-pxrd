#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/texture_mgwo4/mgwo4_MD_010.gpx"
OUTDIR = ROOT / "trials/broadening"


def top_correlation(covdata):
    cov = covdata.get("covMatrix")
    vary = covdata.get("varyList", [])
    if cov is None or len(vary) < 2:
        return None
    sig = np.sqrt(np.clip(np.diag(cov), 1e-300, None))
    corr = cov / np.outer(sig, sig)
    np.fill_diagonal(corr, 0.0)
    i, j = np.unravel_index(np.argmax(np.abs(corr)), corr.shape)
    return vary[i], vary[j], float(corr[i, j])


def reset_broadening(gpx) -> None:
    hist = gpx.histogram(0)
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [1.0e-6, 1.0e-6, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])


def run(phase_index: int, mechanism: str) -> None:
    out = OUTDIR / f"phase{phase_index}_{mechanism}.gpx"
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(out))
    gpx.set_Frozen()
    reset_broadening(gpx)
    hist = gpx.histogram(0)
    phase = gpx.phase(phase_index)
    hap = phase.data["Histograms"][hist.name]
    if mechanism == "size":
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
        var = f"{phase_index}:0:Size;i"
        gpx.set_Controls("parmMin", 0.01, var)
        gpx.set_Controls("parmMax", 10.0, var)
    else:
        hap["Mustrain"][1][0] = 100.0
        hap["Mustrain"][2][0] = True
        var = f"{phase_index}:0:Mustrain;i"
        gpx.set_Controls("parmMin", 0.0, var)
        gpx.set_Controls("parmMax", 10000.0, var)
    gpx.set_Controls("cycles", 12)
    for _ in range(3):
        gpx.refine(makeBack=False)
    gpx.save()
    hist = gpx.histogram(0)
    phase = gpx.phase(phase_index)
    hap = phase.data["Histograms"][hist.name]
    cov = gpx.data["Covariance"]["data"]
    vary = cov.get("varyList", [])
    sigs = cov.get("sig", [])
    value = hap["Size"][1][0] if mechanism == "size" else hap["Mustrain"][1][0]
    sigma = float(sigs[vary.index(var)]) if var in vary else None
    print(
        "BROADENING_RESULT", phase_index, mechanism,
        "Rwp", hist.get_wR(),
        "value", value, "sig", sigma,
        "fractions", hist.ComputeMassFracs(),
        "Rf", [hist.residuals.get(f"{i}:0:Rf") for i in range(3)],
        "profile", {k: hist.InstrumentParameters[k][1] for k in ["U", "W", "X"]},
        "maxshift", cov.get("Rvals", {}).get("Max shft/sig"),
        "topcorr", top_correlation(cov),
        "frozen", gpx.get_Frozen(),
        flush=True,
    )


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    for phase_index in range(3):
        for mechanism in ["size", "strain"]:
            run(phase_index, mechanism)


if __name__ == "__main__":
    main()
