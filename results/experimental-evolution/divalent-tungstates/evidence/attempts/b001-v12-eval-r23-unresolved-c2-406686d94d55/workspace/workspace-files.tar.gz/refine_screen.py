#!/usr/bin/env python3
"""Run reproducible GSAS-II source-record screening refinements."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id: str) -> str:
    return str(ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif")


def set_neutral_hap(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Scale"][0] = 1.0
    hap["Scale"][1] = True


def snapshot(project, hist, label: str) -> dict:
    inst = hist.data["Instrument Parameters"][0]
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(hap["Scale"][0]),
                "size_um": float(hap["Size"][1][0]),
                "mustrain": float(hap["Mustrain"][1][0]),
            }
        )
    residuals = {
        key: float(value)
        for key, value in hist.residuals.items()
        if isinstance(value, (int, float)) and math.isfinite(value)
    }
    return {
        "label": label,
        "residuals": residuals,
        "phases": phases,
        "instrument": {
            key: float(inst[key][1])
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")
        },
        "background": [float(v) for v in hist.data["Background"][0][3:]],
    }


def run(main_id: str, wo3_id: str, tag: str, cycles: int) -> dict:
    out = Path(".tmp") / f"screen_{tag}.gpx"
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    main = project.add_phase(
        cif_path(main_id), phasename=f"main_{main_id}", histograms=[hist], fmthint="CIF"
    )
    wo3 = project.add_phase(
        cif_path(wo3_id), phasename=f"WO3_{wo3_id}", histograms=[hist], fmthint="CIF"
    )
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = cycles
    controls["min dM/M"] = 1.0e-5
    controls["shift factor"] = 1.0
    hist.data["Limits"][1] = [10.0, 100.0]
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.data["Background"][0] = [
        "chebyschev-1", True, 8, 1500.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
    ]
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {
        "Zero": 0.30,
        "U": 0.0,
        "V": 0.0,
        "W": 0.0,
        "X": 10.0,
        "Y": 0.0,
        "SH/L": 0.002,
        "Polariz.": 0.5,
    }.items():
        inst[key][1] = value
        inst[key][2] = False
    inst["Zero"][2] = True
    for phase in project.phases():
        set_neutral_hap(phase, hist.name)

    print(f"{tag}: baseline scales/background/zero", flush=True)
    project.save()
    project.refine()
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    print(f"{tag}: neutral-cell replay", flush=True)
    project.refine()
    neutral = snapshot(project, hist, "neutral")
    neutral_file = Path(".tmp") / f"screen_{tag}_neutral.gpx"
    project.save(str(neutral_file))

    # Reopen the exact neutral checkpoint before profile/size elaboration.
    project = G2sc.G2Project(str(neutral_file), newgpx=str(out))
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    main = project.phase(f"main_{main_id}")
    inst["X"][2] = True
    main.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 0.10, "refine": True}}
    )
    print(f"{tag}: isotropic-size elaboration", flush=True)
    project.refine()
    elaborated = snapshot(project, hist, "size")
    project.save()
    try:
        fractions = {
            key: [float(v) for v in value]
            for key, value in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": str(exc)}
    row = {
        "tag": tag,
        "main_id": main_id,
        "wo3_id": wo3_id,
        "neutral": neutral,
        "elaborated": elaborated,
        "fractions": fractions,
        "project": str(out),
    }
    print(
        f"{tag}: neutral wR={neutral['residuals'].get('wR')} "
        f"size wR={elaborated['residuals'].get('wR')} "
        f"X={elaborated['instrument']['X']:.4f} "
        f"size={elaborated['phases'][0]['size_um']:.5f}",
        flush=True,
    )
    return row


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--main-id", required=True)
    parser.add_argument("--wo3-id", required=True)
    parser.add_argument("--tag", required=True)
    parser.add_argument("--cycles", type=int, default=5)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    row = run(args.main_id, args.wo3_id, args.tag, args.cycles)
    if args.json:
        args.json.write_text(json.dumps(row, indent=2, sort_keys=True) + "\n")
    else:
        print(json.dumps(row, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
