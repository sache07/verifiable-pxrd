#!/usr/bin/env python3
"""Replay profile-boundary, anisotropic-size and simple MD texture challenges."""

from __future__ import annotations

import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASE = ".tmp/third_tet901.gpx"


def snapshot(project, hist, tag: str) -> dict:
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    fractions = hist.ComputeMassFracs()
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "scale": float(hap["Scale"][0]),
            "fraction": float(fractions[phase.name][0]),
            "size_type": hap["Size"][0],
            "size": [float(v) for v in hap["Size"][1]],
            "size_axis": list(hap["Size"][3]),
            "md_ratio": float(hap["Pref.Ori."][1]),
            "md_axis": list(hap["Pref.Ori."][3]),
        }
    return {
        "tag": tag,
        "wR": float(hist.get_wR()),
        "residuals": {
            k: float(v)
            for k, v in hist.residuals.items()
            if isinstance(v, (int, float)) and math.isfinite(v)
        },
        "polarization": float(inst["Polariz."][1]),
        "rough_b": float(sample["SurfRoughB"][0]),
        "phases": phases,
    }


def run(tag: str, setup) -> dict:
    out = f".tmp/challenge_{tag}.gpx"
    project = G2sc.G2Project(BASE, newgpx=out)
    hist = project.histogram(0)
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    setup(project, hist)
    project.save()
    states = []
    for replay in (1, 2):
        print(f"{tag}: replay {replay}", flush=True)
        project.refine()
        states.append(snapshot(project, hist, tag))
    project.save()
    print(f"{tag}: wR={states[-1]['wR']:.6f}", flush=True)
    return {"tag": tag, "project": out, "states": states}


def fixed_pol(value: float, rough: bool = False):
    def setup(project, hist):
        inst = hist.data["Instrument Parameters"][0]
        inst["Polariz."][1] = value
        inst["Polariz."][2] = False
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.01 if rough else 0.0, rough]
    return setup


def uniaxial_size(phase_name: str, axis):
    def setup(project, hist):
        hap = project.phase(phase_name).data["Histograms"][hist.name]
        current = float(hap["Size"][1][0])
        hap["Size"][0] = "uniaxial"
        hap["Size"][1][:] = [current, current, 1.0]
        hap["Size"][2][:] = [True, True, False]
        hap["Size"][3] = list(axis)
    return setup


def md_texture(phase_name: str, axis):
    def setup(project, hist):
        pref = project.phase(phase_name).data["Histograms"][hist.name]["Pref.Ori."]
        pref[0] = "MD"
        pref[1] = 1.0
        pref[2] = True
        pref[3] = list(axis)
    return setup


def main() -> None:
    trials = [
        ("pol1_fixed", fixed_pol(1.0)),
        ("pol1_fixed_roughb", fixed_pol(1.0, rough=True)),
        ("main_size_001", uniaxial_size("main_9009811", [0, 0, 1])),
        ("pb3_size_001", uniaxial_size("Pb3O4_9012124", [0, 0, 1])),
    ]
    for phase_name, short in (
        ("main_9009811", "main"),
        ("WO3_2311041", "wo3"),
        ("Pb3O4_9012124", "pb3"),
    ):
        for axis in ([0, 0, 1], [1, 0, 0], [1, 1, 0]):
            axis_tag = "".join(str(v) for v in axis)
            trials.append(
                (f"{short}_md_{axis_tag}", md_texture(phase_name, axis))
            )
    rows = [run(tag, setup) for tag, setup in trials]
    Path(".tmp/challenge_results.json").write_text(
        json.dumps(rows, indent=2, sort_keys=True) + "\n"
    )


if __name__ == "__main__":
    main()
