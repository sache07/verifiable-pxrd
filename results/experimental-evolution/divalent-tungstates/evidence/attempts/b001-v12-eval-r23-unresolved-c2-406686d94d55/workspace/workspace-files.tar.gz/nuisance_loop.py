#!/usr/bin/env python3
"""Replay simple background and shared-intensity nuisance trials."""

from __future__ import annotations

import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASE = ".tmp/third_tet901.gpx"


def metrics(project, hist) -> dict:
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    row = {
        "residuals": {
            k: float(v)
            for k, v in hist.residuals.items()
            if isinstance(v, (int, float)) and math.isfinite(v)
        },
        "polarization": float(inst["Polariz."][1]),
        "rough_a": float(sample["SurfRoughA"][0]),
        "rough_b": float(sample["SurfRoughB"][0]),
        "zero": float(inst["Zero"][1]),
        "x": float(inst["X"][1]),
        "background": [float(v) for v in hist.data["Background"][0][3:]],
        "phases": {},
    }
    try:
        fractions = hist.ComputeMassFracs()
    except Exception:
        fractions = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        row["phases"][phase.name] = {
            "scale": float(hap["Scale"][0]),
            "fraction": float(fractions.get(phase.name, (math.nan, math.nan))[0]),
            "size_um": float(hap["Size"][1][0]),
        }
    return row


def run(tag: str, background_order: int = 8, polarization: bool = False,
        rough_b: bool = False) -> dict:
    out = f".tmp/nuisance_{tag}.gpx"
    project = G2sc.G2Project(BASE, newgpx=out)
    hist = project.histogram(0)
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 8
    controls["min dM/M"] = 1e-5
    back = hist.data["Background"][0]
    coeffs = list(back[3:3 + background_order])
    coeffs += [0.0] * (background_order - len(coeffs))
    hist.data["Background"][0] = [back[0], True, background_order] + coeffs
    inst = hist.data["Instrument Parameters"][0]
    inst["Polariz."][1] = 0.5
    inst["Polariz."][2] = polarization
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.01 if rough_b else 0.0, rough_b]
    project.save()
    print(f"{tag}: replay 1", flush=True)
    project.refine()
    first = metrics(project, hist)
    print(f"{tag}: replay 2", flush=True)
    project.refine()
    second = metrics(project, hist)
    project.save()
    print(
        f"{tag}: wR={second['residuals'].get('wR')} pol={second['polarization']:.6f} "
        f"roughB={second['rough_b']:.6f}",
        flush=True,
    )
    return {"tag": tag, "first": first, "second": second, "project": out}


def main() -> None:
    rows = []
    for order in (6, 8, 10, 12):
        rows.append(run(f"bg{order}", background_order=order))
    rows.append(run("polarization", polarization=True))
    rows.append(run("roughb", rough_b=True))
    rows.append(run("pol_roughb", polarization=True, rough_b=True))
    Path(".tmp/nuisance_results.json").write_text(
        json.dumps(rows, indent=2, sort_keys=True) + "\n"
    )


if __name__ == "__main__":
    main()
