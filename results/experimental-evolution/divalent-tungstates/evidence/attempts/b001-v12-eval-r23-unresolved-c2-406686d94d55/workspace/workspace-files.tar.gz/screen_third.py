#!/usr/bin/env python3
"""Screen Pb3O4 source records from one two-phase GSAS-II checkpoint."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id: str) -> str:
    return str(ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif")


def neutral(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Scale"] = [0.5, True]


def state(project, hist, label: str) -> dict:
    inst = hist.data["Instrument Parameters"][0]
    return {
        "label": label,
        "residuals": {
            k: float(v)
            for k, v in hist.residuals.items()
            if isinstance(v, (int, float)) and math.isfinite(v)
        },
        "phases": [
            {
                "name": p.name,
                "cell": p.get_cell(),
                "scale": float(p.data["Histograms"][hist.name]["Scale"][0]),
                "size_um": float(p.data["Histograms"][hist.name]["Size"][1][0]),
            }
            for p in project.phases()
        ],
        "instrument": {k: float(inst[k][1]) for k in ("Zero", "X")},
    }


def run(source: str, tag: str, cycles: int) -> dict:
    base = ".tmp/screen_scheelite900_mono231.gpx"
    out = f".tmp/third_{tag}.gpx"
    project = G2sc.G2Project(base, newgpx=out)
    hist = project.histogram(0)
    project.data["Controls"]["data"]["max cyc"] = cycles
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    phase = project.add_phase(
        cif_path(source), phasename=f"Pb3O4_{source}", histograms=[hist], fmthint="CIF"
    )
    neutral(phase, hist.name)
    phase.data["General"]["Cell"][0] = False
    print(f"{tag}: neutral scale replay", flush=True)
    project.save()
    project.refine()
    phase.data["General"]["Cell"][0] = True
    print(f"{tag}: neutral cell replay", flush=True)
    project.refine()
    neutral_state = state(project, hist, "neutral")
    checkpoint = f".tmp/third_{tag}_neutral.gpx"
    project.save(checkpoint)

    project = G2sc.G2Project(checkpoint, newgpx=out)
    hist = project.histogram(0)
    phase = project.phase(f"Pb3O4_{source}")
    phase.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 0.10, "refine": True}}
    )
    print(f"{tag}: size replay", flush=True)
    project.refine()
    size_state = state(project, hist, "size")
    project.save()
    try:
        fractions = {
            k: [float(x) for x in v] for k, v in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": str(exc)}
    row = {
        "source": source,
        "tag": tag,
        "neutral": neutral_state,
        "size": size_state,
        "fractions": fractions,
        "project": out,
    }
    print(
        f"{tag}: neutral wR={neutral_state['residuals'].get('wR')} "
        f"size wR={size_state['residuals'].get('wR')} "
        f"scale={size_state['phases'][-1]['scale']:.5f} "
        f"size={size_state['phases'][-1]['size_um']:.5f}",
        flush=True,
    )
    return row


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True)
    parser.add_argument("--tag", required=True)
    parser.add_argument("--cycles", type=int, default=5)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    args.json.write_text(
        json.dumps(run(args.source, args.tag, args.cycles), indent=2, sort_keys=True)
        + "\n"
    )


if __name__ == "__main__":
    main()
