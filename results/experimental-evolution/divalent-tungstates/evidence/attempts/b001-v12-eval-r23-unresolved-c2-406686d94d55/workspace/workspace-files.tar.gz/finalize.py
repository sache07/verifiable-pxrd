#!/usr/bin/env python3
"""Replay the accepted model on the full range and freeze deliverables."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


BASE = ".tmp/accepted_checkpoint.gpx"
PROJECT = "final.gpx"

PHASE_INFO = {
    "main_9009811": {
        "name": "scheelite PbWO4",
        "formula": "PbWO4",
        "polymorph": "scheelite",
        "source_record": "COD 9009811",
        "cif_path": "PbWO4.cif",
    },
    "WO3_2311041": {
        "name": "monoclinic WO3",
        "formula": "WO3",
        "polymorph": "monoclinic",
        "source_record": "COD 2311041",
        "cif_path": "WO3.cif",
    },
    "Pb3O4_9012124": {
        "name": "tetragonal Pb3O4",
        "formula": "Pb3O4",
        "polymorph": "tetragonal (minium)",
        "source_record": "COD 9012124",
        "cif_path": "Pb3O4.cif",
    },
}


def neutral_strain(hap) -> None:
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])


def enforce_supported_model(project, hist) -> None:
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    project.data["Controls"]["data"]["shift factor"] = 1.0

    # Full measured range, including the endpoint points omitted during search.
    hist.data["Limits"][1] = [float(v) for v in hist.data["Limits"][0]]
    hist.data["Background"][0][0] = "chebyschev-1"
    hist.data["Background"][0][1] = True
    if hist.data["Background"][0][2] != 8:
        coeffs = list(hist.data["Background"][0][3:11])
        coeffs += [0.0] * (8 - len(coeffs))
        hist.data["Background"][0] = ["chebyschev-1", True, 8] + coeffs[:8]

    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "Y"):
        inst[key][1] = 0.0
        inst[key][2] = False
    inst["X"][2] = True
    inst["Zero"][2] = True
    inst["SH/L"][1] = 0.002
    inst["SH/L"][2] = False
    inst["Polariz."][1] = 0.5
    inst["Polariz."][2] = False

    sample = hist.data["Sample Parameters"]
    sample["Scale"][1] = False
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"][1] = True

    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        hap["Scale"][1] = True
        neutral_strain(hap)

        if phase.name == "main_9009811":
            hap["Size"][0] = "uniaxial"
            hap["Size"][2][:] = [True, True, False]
            hap["Size"][3] = [0, 0, 1]
            hap["Size"][5][:] = [False] * len(hap["Size"][5])
            hap["Pref.Ori."][0:4] = ["MD", hap["Pref.Ori."][1], True, [1, 0, 0]]
        elif phase.name == "Pb3O4_9012124":
            hap["Size"][0] = "uniaxial"
            hap["Size"][2][:] = [True, True, False]
            hap["Size"][3] = [0, 0, 1]
            hap["Size"][5][:] = [False] * len(hap["Size"][5])
            hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
        else:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][:] = [10.0, 10.0, 1.0]
            hap["Size"][2][:] = [False, False, False]
            hap["Size"][5][:] = [False] * len(hap["Size"][5])
            hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]


def residual_dict(hist) -> dict:
    return {
        k: float(v)
        for k, v in hist.residuals.items()
        if isinstance(v, (int, float)) and math.isfinite(v)
    }


def write_fit(hist) -> None:
    x, obs, weights, calc, background, stored_diff = (
        np.asarray(row, dtype=float) for row in hist.data["data"][1]
    )
    with Path("fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "difference", "background"]
        )
        for row in zip(x, obs, calc, obs - calc, background):
            writer.writerow([f"{v:.15g}" for v in row])


def write_result(project, hist) -> None:
    mass_fracs = hist.ComputeMassFracs()
    total = sum(v[0] for v in mass_fracs.values())
    if total <= 0:
        raise RuntimeError("Nonpositive modeled crystalline mass-fraction sum")
    cov = project.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    phases = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        fraction, esd = mass_fracs[phase.name]
        hap = phase.data["Histograms"][hist.name]
        cell, cell_esd = phase.get_cell_and_esd()
        phases.append(
            {
                **info,
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "weight_fraction": float(fraction / total),
                "weight_fraction_internal_esd": float(esd / total),
                "cif_path": info["cif_path"],
                "project_path": PROJECT,
                "cell": {k: float(v) for k, v in cell.items()},
                "cell_internal_esd": {k: float(v) for k, v in cell_esd.items()},
                "profile_terms": {
                    "size_model": hap["Size"][0],
                    "size_micrometre": [float(v) for v in hap["Size"][1][:2]],
                    "size_axis_hkl": list(hap["Size"][3]),
                    "march_dollase_ratio": float(hap["Pref.Ori."][1]),
                    "march_dollase_axis_hkl": list(hap["Pref.Ori."][3]),
                },
            }
        )
    result = {
        "project_path": PROJECT,
        "fit_path": "fit.csv",
        "weight_fraction_basis": "normalized over the three modeled crystalline phases",
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": float(rvals["Rwp"]),
            "Rp_percent": float(hist.residuals["R"]),
            "GOF": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
            "Rwp_min_percent": float(hist.residuals["wRmin"]),
            "two_theta_range_deg": [float(v) for v in hist.data["Limits"][1]],
            "weighting": "Poisson weights inferred from raw counts; pointwise sigmas were not supplied",
        },
        "refined_shared_terms": {
            "zero_deg": float(hist.data["Instrument Parameters"][0]["Zero"][1]),
            "lorentzian_X": float(hist.data["Instrument Parameters"][0]["X"][1]),
            "surface_roughness_B": float(hist.data["Sample Parameters"]["SurfRoughB"][0]),
            "background": "8-term Chebyshev-1",
        },
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")


def main() -> None:
    project = G2sc.G2Project(BASE, newgpx=PROJECT)
    hist = project.histogram(0)
    enforce_supported_model(project, hist)
    project.save()
    for replay in (1, 2):
        print(f"full-range replay {replay}", flush=True)
        project.refine()
    project.save()

    # Explicit reopen-and-replay check on the frozen full range.
    project = G2sc.G2Project(gpxfile=PROJECT)
    hist = project.histogram(0)
    enforce_supported_model(project, hist)
    print("full-range reopen replay", flush=True)
    project.refine()
    project.save()

    if set(phase.name for phase in project.phases()) != set(PHASE_INFO):
        raise RuntimeError("Unexpected phase inventory in final project")
    for phase in project.phases():
        phase.export_CIF(PHASE_INFO[phase.name]["cif_path"])
    write_fit(hist)
    write_result(project, hist)
    print("final Rwp", hist.get_wR(), flush=True)
    print("final fractions", hist.ComputeMassFracs(), flush=True)


if __name__ == "__main__":
    main()
