#!/usr/bin/env python3
"""Cross-seeded source-record challenges from the accepted profile checkpoint."""

from __future__ import annotations

import copy
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASE = ".tmp/accepted_checkpoint.gpx"
ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

# Cells are cross-seeded from the independent neutral/source screens. This
# prevents a literature-temperature cell from collapsing the scale before the
# candidate reaches the observed peak positions.
CELL_SEEDS = {
    "9009811": [5.47249, 5.47249, 12.07320, 90.0, 90.0, 90.0],
    "1527935": [5.47107, 5.47107, 12.07459, 90.0, 90.0, 90.0],
    "9016035": [7.73905, 7.73905, 12.07282, 90.0, 90.0, 90.0],
    "2311041": [7.70050, 7.54356, 10.53523, 90.0, 136.19108, 90.0],
    "1528915": [7.29367, 7.54354, 7.69886, 90.0, 90.75807, 90.0],
    "2106293": [7.29458, 7.54629, 7.70188, 88.52714, 90.88122, 90.21212],
    "9012124": [8.81084, 8.81084, 6.57116, 90.0, 90.0, 90.0],
    "1537983": [8.81084, 8.81084, 6.57116, 90.0, 90.0, 90.0],
    "9003043": [9.16107, 6.85776, 3.23295, 90.0, 90.0, 90.0],
}


def cif_path(cod_id: str) -> str:
    return str(ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif")


def cell_volume(cell) -> float:
    a, b, c, alpha, beta, gamma = cell
    ar, br, gr = (math.radians(v) for v in (alpha, beta, gamma))
    factor = (
        1.0
        + 2.0 * math.cos(ar) * math.cos(br) * math.cos(gr)
        - math.cos(ar) ** 2
        - math.cos(br) ** 2
        - math.cos(gr) ** 2
    )
    return a * b * c * math.sqrt(max(0.0, factor))


def neutral(hap) -> None:
    hap["Use"] = True
    hap["Scale"][1] = True
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]


def elaborate(hap, kind: str, target_hap, texture_axis=None) -> None:
    if kind in ("main", "pb3"):
        hap["Size"][0] = "uniaxial"
        hap["Size"][1][:] = copy.deepcopy(target_hap["Size"][1])
        hap["Size"][2][:] = [True, True, False]
        hap["Size"][3] = [0, 0, 1]
    if kind == "main":
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = float(target_hap["Pref.Ori."][1])
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(texture_axis or [1, 0, 0])


def snapshot(project, hist, candidate_name: str) -> dict:
    fractions = hist.ComputeMassFracs()
    phase = project.phase(candidate_name)
    hap = phase.data["Histograms"][hist.name]
    return {
        "wR": float(hist.get_wR()),
        "residuals": {
            k: float(v)
            for k, v in hist.residuals.items()
            if isinstance(v, (int, float)) and math.isfinite(v)
        },
        "cell": phase.get_cell(),
        "scale": float(hap["Scale"][0]),
        "size_type": hap["Size"][0],
        "size": [float(v) for v in hap["Size"][1]],
        "md_ratio": float(hap["Pref.Ori."][1]),
        "md_axis": list(hap["Pref.Ori."][3]),
        "fractions": {
            name: [float(v) for v in values]
            for name, values in fractions.items()
        },
    }


def run(kind: str, old_name: str, source: str, tag: str, texture_axis=None) -> dict:
    out = f".tmp/source_{tag}.gpx"
    project = G2sc.G2Project(BASE, newgpx=out)
    hist = project.histogram(0)
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    old_phase = project.phase(old_name)
    old_hap = old_phase.data["Histograms"][hist.name]
    target_hap = copy.deepcopy(old_hap)
    old_hap["Use"] = False
    old_hap["Scale"][1] = False

    candidate_name = f"trial_{tag}_{source}"
    candidate = project.add_phase(
        cif_path(source), phasename=candidate_name, histograms=[hist], fmthint="CIF"
    )
    hap = candidate.data["Histograms"][hist.name]
    neutral(hap)
    hap["Scale"][0] = float(target_hap["Scale"][0])
    seed = CELL_SEEDS[source]
    candidate.data["General"]["Cell"][1:7] = seed
    candidate.data["General"]["Cell"][7] = cell_volume(seed)
    candidate.data["General"]["Cell"][0] = False
    project.save()
    print(f"{tag}: neutral scale", flush=True)
    project.refine()
    candidate.data["General"]["Cell"][0] = True
    print(f"{tag}: neutral cell", flush=True)
    project.refine()
    neutral_state = snapshot(project, hist, candidate_name)

    elaborate(hap, kind, target_hap, texture_axis=texture_axis)
    states = []
    for replay in (1, 2):
        print(f"{tag}: elaborated replay {replay}", flush=True)
        project.refine()
        states.append(snapshot(project, hist, candidate_name))
    project.save()
    print(
        f"{tag}: neutral wR={neutral_state['wR']:.6f}; "
        f"elaborated wR={states[-1]['wR']:.6f}",
        flush=True,
    )
    return {
        "kind": kind,
        "source": source,
        "tag": tag,
        "project": out,
        "neutral": neutral_state,
        "elaborated": states,
    }


def main() -> None:
    jobs = [
        ("main", "main_9009811", "9009811", "main_control", [1, 0, 0]),
        ("main", "main_9009811", "1527935", "main_alt_scheelite", [1, 0, 0]),
        ("main", "main_9009811", "9016035", "main_pb7_axis100", [1, 0, 0]),
        ("main", "main_9009811", "9016035", "main_pb7_axis110", [1, 1, 0]),
        ("wo3", "WO3_2311041", "2311041", "wo3_control", None),
        ("wo3", "WO3_2311041", "1528915", "wo3_alt_mono", None),
        ("wo3", "WO3_2311041", "2106293", "wo3_alt_triclinic", None),
        ("pb3", "Pb3O4_9012124", "9012124", "pb3_control", None),
        ("pb3", "Pb3O4_9012124", "1537983", "pb3_alt_tetragonal", None),
        ("pb3", "Pb3O4_9012124", "9003043", "pb3_alt_orthorhombic", None),
    ]
    rows = [run(*job) for job in jobs]
    Path(".tmp/mature_source_results.json").write_text(
        json.dumps(rows, indent=2, sort_keys=True) + "\n"
    )


if __name__ == "__main__":
    main()
