#!/usr/bin/env python3
"""Rechallenge surviving broadening/intensity/background terms together."""

from __future__ import annotations

import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASE = ".tmp/challenge_main_size_001.gpx"


def set_pb3_anisotropy(project, hist) -> None:
    hap = project.phase("Pb3O4_9012124").data["Histograms"][hist.name]
    current = float(hap["Size"][1][0])
    hap["Size"][0] = "uniaxial"
    hap["Size"][1][:] = [current, current, 1.0]
    hap["Size"][2][:] = [True, True, False]
    hap["Size"][3] = [0, 0, 1]


def set_rough_b(hist, start=0.01) -> None:
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [start, True]


def set_rough_ab(hist) -> None:
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.1, True]
    sample["SurfRoughB"] = [0.1, True]


def set_md(project, hist, phase_name, axis) -> None:
    pref = project.phase(phase_name).data["Histograms"][hist.name]["Pref.Ori."]
    pref[0:4] = ["MD", 1.0, True, list(axis)]


def set_background(hist, order: int) -> None:
    back = hist.data["Background"][0]
    coeffs = list(back[3:3 + order])
    coeffs += [0.0] * (order - len(coeffs))
    hist.data["Background"][0] = [back[0], True, order] + coeffs


def snapshot(project, hist) -> dict:
    fractions = hist.ComputeMassFracs()
    sample = hist.data["Sample Parameters"]
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "fraction": float(fractions[phase.name][0]),
            "scale": float(hap["Scale"][0]),
            "size_type": hap["Size"][0],
            "size": [float(v) for v in hap["Size"][1]],
            "md_ratio": float(hap["Pref.Ori."][1]),
            "md_axis": list(hap["Pref.Ori."][3]),
        }
    return {
        "wR": float(hist.get_wR()),
        "residuals": {
            k: float(v)
            for k, v in hist.residuals.items()
            if isinstance(v, (int, float)) and math.isfinite(v)
        },
        "rough_a": float(sample["SurfRoughA"][0]),
        "rough_b": float(sample["SurfRoughB"][0]),
        "background": [float(v) for v in hist.data["Background"][0][3:]],
        "phases": phases,
    }


def run(tag, setup) -> dict:
    out = f".tmp/converge_{tag}.gpx"
    project = G2sc.G2Project(BASE, newgpx=out)
    hist = project.histogram(0)
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    setup(project, hist)
    project.save()
    states = []
    for replay in (1, 2):
        print(f"{tag}: replay {replay}", flush=True)
        project.refine()
        states.append(snapshot(project, hist))
    project.save()
    print(
        f"{tag}: wR={states[-1]['wR']:.6f} "
        f"rough=({states[-1]['rough_a']:.6f},{states[-1]['rough_b']:.6f})",
        flush=True,
    )
    return {"tag": tag, "project": out, "states": states}


def setup_terms(*terms):
    def setup(project, hist):
        for term in terms:
            term(project, hist)
    return setup


def rough(start=0.01):
    return lambda project, hist: set_rough_b(hist, start)


def bg(order):
    return lambda project, hist: set_background(hist, order)


def md(phase, axis):
    return lambda project, hist: set_md(project, hist, phase, axis)


def main() -> None:
    trials = [
        ("pb3_aniso", set_pb3_anisotropy),
        ("roughb", rough(0.01)),
        ("roughb_altstart", rough(0.30)),
        ("roughab", lambda project, hist: set_rough_ab(hist)),
        ("roughb_pb3_aniso", setup_terms(rough(), set_pb3_anisotropy)),
        (
            "roughb_main_md100",
            setup_terms(rough(), md("main_9009811", [1, 0, 0])),
        ),
        (
            "roughb_wo3_md110",
            setup_terms(rough(), md("WO3_2311041", [1, 1, 0])),
        ),
        ("roughb_bg10", setup_terms(rough(), bg(10))),
        ("roughb_bg12", setup_terms(rough(), bg(12))),
    ]
    rows = [run(tag, setup) for tag, setup in trials]
    Path(".tmp/convergence_results.json").write_text(
        json.dumps(rows, indent=2, sort_keys=True) + "\n"
    )


if __name__ == "__main__":
    main()
