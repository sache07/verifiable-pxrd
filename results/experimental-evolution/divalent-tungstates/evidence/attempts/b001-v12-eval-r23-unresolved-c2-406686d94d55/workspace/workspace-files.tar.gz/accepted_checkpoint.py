#!/usr/bin/env python3
"""Build and replay the supported three-phase convergence checkpoint."""

from GSASII import GSASIIscriptable as G2sc


BASE = ".tmp/converge_roughb_main_md100.gpx"
OUT = ".tmp/accepted_checkpoint.gpx"


def main() -> None:
    project = G2sc.G2Project(BASE, newgpx=OUT)
    hist = project.histogram(0)
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hap = project.phase("Pb3O4_9012124").data["Histograms"][hist.name]
    current = float(hap["Size"][1][0])
    hap["Size"][0] = "uniaxial"
    hap["Size"][1][:] = [current, current, 1.0]
    hap["Size"][2][:] = [True, True, False]
    hap["Size"][3] = [0, 0, 1]
    project.save()
    for replay in (1, 2):
        print(f"accepted checkpoint: replay {replay}", flush=True)
        project.refine()
    project.save()
    print(f"accepted checkpoint: wR={hist.get_wR():.6f}", flush=True)
    print("fractions", hist.ComputeMassFracs(), flush=True)


if __name__ == "__main__":
    main()
