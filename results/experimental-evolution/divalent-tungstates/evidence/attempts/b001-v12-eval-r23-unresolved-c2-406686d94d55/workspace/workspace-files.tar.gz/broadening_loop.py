#!/usr/bin/env python3
"""Compare neutral, size, strain and combined broadening from one checkpoint."""

from __future__ import annotations

import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASE_INPUT = ".tmp/third_tet901.gpx"
COMMON = ".tmp/common_neutral.gpx"


def make_neutral(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def metrics(project, hist) -> dict:
    inst = hist.data["Instrument Parameters"][0]
    return {
        "residuals": {
            k: float(v)
            for k, v in hist.residuals.items()
            if isinstance(v, (int, float)) and math.isfinite(v)
        },
        "instrument": {k: float(inst[k][1]) for k in ("Zero", "X")},
        "phases": {
            phase.name: {
                "scale": float(phase.data["Histograms"][hist.name]["Scale"][0]),
                "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "mustrain": float(phase.data["Histograms"][hist.name]["Mustrain"][1][0]),
                "cell": phase.get_cell(),
            }
            for phase in project.phases()
        },
    }


def create_common() -> dict:
    project = G2sc.G2Project(BASE_INPUT, newgpx=COMMON)
    hist = project.histogram(0)
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 7
    controls["min dM/M"] = 1e-5
    for phase in project.phases():
        make_neutral(phase, hist.name)
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "Y"):
        inst[key][1] = 0.0
        inst[key][2] = False
    inst["X"][1] = 8.8
    inst["X"][2] = True
    inst["Zero"][2] = True
    project.save()
    print("common: neutral replay 1", flush=True)
    project.refine()
    print("common: neutral replay 2", flush=True)
    project.refine()
    project.save()
    row = metrics(project, hist)
    print(
        f"common: wR={row['residuals'].get('wR')} X={row['instrument']['X']:.5f}",
        flush=True,
    )
    return row


def run_trial(phase_index: int, mode: str) -> dict:
    tag = f"p{phase_index}_{mode}"
    output = f".tmp/broad_{tag}.gpx"
    project = G2sc.G2Project(COMMON, newgpx=output)
    hist = project.histogram(0)
    project.data["Controls"]["data"]["max cyc"] = 7
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    phase = project.phase(phase_index)
    hap = phase.data["Histograms"][hist.name]
    if mode in ("size", "combined"):
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.10
        hap["Size"][2][0] = True
    if mode in ("strain", "combined"):
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True
    project.save()
    print(f"{tag}: replay 1", flush=True)
    project.refine()
    first = metrics(project, hist)
    print(f"{tag}: replay 2", flush=True)
    project.refine()
    second = metrics(project, hist)
    project.save()
    p = second["phases"][phase.name]
    print(
        f"{tag}: wR={second['residuals'].get('wR')} X={second['instrument']['X']:.5f} "
        f"size={p['size_um']:.6f} strain={p['mustrain']:.3f}",
        flush=True,
    )
    return {
        "phase_index": phase_index,
        "phase_name": phase.name,
        "mode": mode,
        "first": first,
        "second": second,
        "project": output,
    }


def main() -> None:
    rows = {"common": create_common(), "trials": []}
    for phase_index in range(3):
        for mode in ("neutral", "size", "strain", "combined"):
            rows["trials"].append(run_trial(phase_index, mode))
    Path(".tmp/broadening_results.json").write_text(
        json.dumps(rows, indent=2, sort_keys=True) + "\n"
    )


if __name__ == "__main__":
    main()
