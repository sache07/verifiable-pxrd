#!/usr/bin/env python3
"""Replay one physically interpretable refinement trial from a common GPX."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from candidate_refine import ROOT, summarize


SCENARIOS = (
    "baseline",
    "ca_size_lorentz",
    "ca_size_gauss",
    "ca_strain_lorentz",
    "ca_strain_gauss",
    "wo_size_lorentz",
    "wo_size_gauss",
    "wo_strain_lorentz",
    "wo_strain_gauss",
    "ca_size_lorentz_strain_gauss",
    "polarization",
    "shl",
    "surface_roughness",
    "polarization_surface_roughness",
    "polarization_ca_size",
    "roughness_ca_size",
    "polarization_roughness_ca_size",
    "polarization_roughness_ca_size_strain",
    "texture_001",
    "texture_100",
    "texture_110",
    "texture_101",
    "texture_111",
    "texture_112",
    "texture_102",
    "texture_211",
    "ca_size_uniaxial_001",
    "ca_size_uniaxial_110",
)


def set_size(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData, mix: float) -> None:
    size = phase.getHAPvalues(hist)["Size"]
    size[0] = "isotropic"
    size[1][:] = [1.0, 1.0, mix]
    size[2][:] = [True, False, False]
    size[5][:] = [False] * len(size[5])


def set_strain(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData, mix: float) -> None:
    strain = phase.getHAPvalues(hist)["Mustrain"]
    strain[0] = "isotropic"
    strain[1][:] = [500.0, 500.0, mix]
    strain[2][:] = [True, False, False]
    strain[5][:] = [False] * len(strain[5])


def set_uniaxial_size(
    phase: G2sc.G2Phase, hist: G2sc.G2PwdrData, axis: list[int]
) -> None:
    size = phase.getHAPvalues(hist)["Size"]
    start = max(0.01, float(size[1][0]))
    size[0] = "uniaxial"
    size[1][:] = [start, start, 1.0]
    size[2][:] = [True, True, False]
    size[3] = axis
    size[5][:] = [False] * len(size[5])


def configure(project: G2sc.G2Project, scenario: str) -> None:
    hist = project.histogram(0)
    ca, wo = project.phase(0), project.phase(1)
    if scenario == "ca_size_lorentz":
        set_size(ca, hist, 1.0)
    elif scenario == "ca_size_gauss":
        set_size(ca, hist, 0.0)
    elif scenario == "ca_strain_lorentz":
        set_strain(ca, hist, 1.0)
    elif scenario == "ca_strain_gauss":
        set_strain(ca, hist, 0.0)
    elif scenario == "wo_size_lorentz":
        set_size(wo, hist, 1.0)
    elif scenario == "wo_size_gauss":
        set_size(wo, hist, 0.0)
    elif scenario == "wo_strain_lorentz":
        set_strain(wo, hist, 1.0)
    elif scenario == "wo_strain_gauss":
        set_strain(wo, hist, 0.0)
    elif scenario == "ca_size_uniaxial_001":
        set_uniaxial_size(ca, hist, [0, 0, 1])
    elif scenario == "ca_size_uniaxial_110":
        set_uniaxial_size(ca, hist, [1, 1, 0])
    elif scenario == "ca_size_lorentz_strain_gauss":
        set_size(ca, hist, 1.0)
        set_strain(ca, hist, 0.0)
    elif scenario == "polarization":
        hist.data["Instrument Parameters"][0]["Polariz."][2] = True
    elif scenario == "shl":
        hist.data["Instrument Parameters"][0]["SH/L"][2] = True
    elif scenario == "surface_roughness":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"][:] = [0.05, True]
        sample["SurfRoughB"][:] = [0.10, True]
    elif scenario in {
        "polarization_surface_roughness",
        "polarization_ca_size",
        "roughness_ca_size",
        "polarization_roughness_ca_size",
        "polarization_roughness_ca_size_strain",
    }:
        if scenario.startswith("polarization"):
            hist.data["Instrument Parameters"][0]["Polariz."][2] = True
        if "roughness" in scenario:
            sample = hist.data["Sample Parameters"]
            sample["SurfRoughA"][:] = [0.05, True]
            sample["SurfRoughB"][:] = [0.10, True]
        if "ca_size" in scenario:
            set_size(ca, hist, 1.0)
        if scenario.endswith("strain"):
            set_strain(ca, hist, 0.0)
    elif scenario.startswith("texture_"):
        axes = {
            "texture_001": [0, 0, 1],
            "texture_100": [1, 0, 0],
            "texture_110": [1, 1, 0],
            "texture_101": [1, 0, 1],
            "texture_111": [1, 1, 1],
            "texture_112": [1, 1, 2],
            "texture_102": [1, 0, 2],
            "texture_211": [2, 1, 1],
        }
        po = ca.getHAPvalues(hist)["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = axes[scenario]


def run(base: Path, scenario: str, tag: str = "") -> dict:
    stem = f"trial_{tag}_{scenario}" if tag else f"trial_{scenario}"
    out = ROOT / ".tmp" / f"{stem}.gpx"
    if out.exists():
        out.unlink()
    project = G2sc.G2Project(str(base), newgpx=str(out))
    project.data["Controls"]["data"]["max cyc"] = 12
    configure(project, scenario)
    project.save()
    project.refine()
    project.save()
    # Explicit reopen/replay test for persistence of the accepted parameterization.
    project = G2sc.G2Project(str(out))
    project.refine()
    project.save()
    return summarize(project, stem)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tag", default="")
    parser.add_argument("base", type=Path)
    parser.add_argument("scenario", choices=SCENARIOS)
    args = parser.parse_args()
    result = run(args.base.resolve(), args.scenario, args.tag)
    stem = f"trial_{args.tag}_{args.scenario}" if args.tag else f"trial_{args.scenario}"
    out = ROOT / ".tmp" / f"{stem}.json"
    out.write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
