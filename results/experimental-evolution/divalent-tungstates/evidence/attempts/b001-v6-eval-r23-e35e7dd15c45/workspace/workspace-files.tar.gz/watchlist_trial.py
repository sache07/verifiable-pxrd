#!/usr/bin/env python3
"""Re-challenge weak/plausible phases under the accepted common profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from candidate_refine import CIF_ROOT, ROOT, neutralize_hap, summarize


CANDIDATES = {
    "cao": ("CaO_watch", "1/56/31/1563196.cif"),
    "bronze": ("Ca4.3W10O30_watch", "4/03/07/4030741.cif"),
    "fergusonite": ("CaWO4_fergusonite_watch", "1/54/60/1546035.cif"),
    "wo3_orthorhombic": ("WO3_orthorhombic_watch", "2/10/73/2107312.cif"),
    "wo3_tetragonal": ("WO3_tetragonal_watch", "1/52/15/1521532.cif"),
    "wo3_hexagonal": ("WO3_hexagonal_watch", "1/00/40/1004057.cif"),
}


def run(base: Path, key: str, tag: str = "") -> dict:
    stem = f"watch_{tag}_{key}" if tag else f"watch_{key}"
    out = ROOT / ".tmp" / f"{stem}.gpx"
    if out.exists():
        out.unlink()
    project = G2sc.G2Project(str(base), newgpx=str(out))
    hist = project.histogram(0)
    name, rel = CANDIDATES[key]
    phase = project.add_phase(str(CIF_ROOT / rel), phasename=name, histograms=[hist])
    neutralize_hap(phase, hist)
    phase.getHAPvalues(hist)["Scale"][:] = [0.1, True]
    phase.set_refinements({"Cell": False})
    project.data["Controls"]["data"]["max cyc"] = 12
    project.save()
    project.refine()
    project.save()
    project = G2sc.G2Project(str(out))
    project.refine()
    project.save()
    return summarize(project, stem)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tag", default="")
    parser.add_argument("base", type=Path)
    parser.add_argument("candidate", choices=sorted(CANDIDATES))
    args = parser.parse_args()
    result = run(args.base.resolve(), args.candidate, args.tag)
    stem = f"watch_{args.tag}_{args.candidate}" if args.tag else f"watch_{args.candidate}"
    out = ROOT / ".tmp" / f"{stem}.json"
    out.write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
