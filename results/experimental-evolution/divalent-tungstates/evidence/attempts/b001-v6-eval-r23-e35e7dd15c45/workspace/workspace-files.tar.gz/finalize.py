#!/usr/bin/env python3
"""Replay the accepted model and export the exact final deliverables."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "atom_ca_o_xyz_w_u.gpx"
FINAL = ROOT / "final.gpx"

PHASE_METADATA = {
    "CaWO4_scheelite": {
        "name": "Calcium tungstate (scheelite)",
        "formula": "CaWO4",
        "space_group": "I 41/a",
        "space_group_number": 88,
        "cif": "phase_CaWO4.cif",
        "source_record": "COD 7219229",
    },
    "WO3_monoclinic_2311041": {
        "name": "Tungsten trioxide (monoclinic)",
        "formula": "WO3",
        "space_group": "P 21/c",
        "space_group_number": 14,
        "cif": "phase_WO3.cif",
        "source_record": "COD 2311041",
        "cell_setting_note": "native nonconventional P 21/c setting retained",
    },
}


def enforce_accepted_model(project: G2sc.G2Project) -> None:
    """Make the final refined/fixed parameter inventory explicit."""
    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    x = np.asarray(arrays[0], dtype=float)
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})

    # One angular correction; one nonnegative low-dimensional profile term.
    inst = hist.data["Instrument Parameters"][0]
    for key, value in inst.items():
        if isinstance(value, list) and len(value) > 2:
            value[2] = key in {"Zero", "X", "Polariz."}
    inst["U"][1] = 0.0
    inst["V"][1] = 0.0
    inst["W"][1] = 0.0
    inst["Y"][1] = 0.0
    inst["Z"][1] = 0.0
    inst["SH/L"][1] = 0.002

    sample = hist.data["Sample Parameters"]
    for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = False
    sample["SurfRoughA"][0] = 0.0
    sample["SurfRoughB"][0] = 0.0

    # Preserve the accepted atomic model and ensure no trial flags survive.
    ca, wo = project.phase(0), project.phase(1)
    for atom in ca.atoms():
        atom.refinement_flags = "X" if atom.element == "O" else (
            "U" if atom.element == "W" else ""
        )
    for atom in wo.atoms():
        atom.refinement_flags = ""

    # The project already contains the accepted CaWO4 [110] MD texture,
    # uniaxial Lorentzian size, isotropic Gaussian strain, and neutral WO3
    # nuisance terms. Explicitly retain refined cells and scales.
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.getHAPvalues(hist)["Scale"][1] = True

    project.data["Controls"]["data"]["max cyc"] = 12
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5


def replay_final() -> G2sc.G2Project:
    if not BASE.exists():
        raise FileNotFoundError(BASE)
    project = G2sc.G2Project(str(BASE), newgpx=str(FINAL))
    enforce_accepted_model(project)
    project.save()
    project.refine()
    project.save()

    # Required persistence/replay check from the saved full-range project.
    project = G2sc.G2Project(str(FINAL))
    enforce_accepted_model(project)
    project.refine()
    project.save()
    return G2sc.G2Project(str(FINAL))


def fit_statistics(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    x, yo, wt, yc, _yb, _yd = [
        np.asarray(v, dtype=float) for v in hist.data["data"][1]
    ]
    low, high = map(float, hist.data["Limits"][1])
    use = (x >= low) & (x <= high) & np.isfinite(wt) & (wt > 0)
    residual = yo - yc
    wrss = float(np.sum(wt[use] * residual[use] ** 2))
    denominator = float(np.sum(wt[use] * yo[use] ** 2))
    rwp = 100.0 * math.sqrt(wrss / denominator)
    rp = 100.0 * float(np.sum(np.abs(residual[use]))) / float(
        np.sum(np.abs(yo[use]))
    )
    rvals = project.data["Covariance"]["data"]["Rvals"]
    gof = float(rvals["GOF"])
    return {
        "Rwp_percent": rwp,
        "Rp_percent": rp,
        "Rexp_percent": rwp / gof,
        "goodness_of_fit": gof,
        "reduced_chi_squared": gof**2,
        "weighted_residual_sum": wrss,
        "n_profile_points": int(np.count_nonzero(use)),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_parameters": int(rvals["Nvars"]),
        "fit_range_two_theta_deg": [low, high],
        "converged": bool(rvals.get("converged", False)),
        "maximum_shift_over_esd": float(rvals.get("Max shft/sig", float("nan"))),
        "weighting": "counting-statistics approximation, w = 1/Iobs",
    }


def write_fit(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    x, yo, _wt, yc, yb, _yd = [
        np.asarray(v, dtype=float) for v in hist.data["data"][1]
    ]
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "intensity_observed",
                "intensity_calculated",
                "intensity_difference_observed_minus_calculated",
                "intensity_background",
            ]
        )
        writer.writerows(zip(x, yo, yc, yo - yc, yb))


def write_cifs(project: G2sc.G2Project) -> None:
    for phase in project.phases():
        metadata = PHASE_METADATA[phase.name]
        phase.export_CIF(str(ROOT / metadata["cif"]))


def phase_results(project: G2sc.G2Project) -> list[dict]:
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    results = []
    for phase in project.phases():
        metadata = dict(PHASE_METADATA[phase.name])
        fraction, esd = fractions[phase.name]
        cell = {key: float(value) for key, value in phase.get_cell().items()}
        metadata.update(
            {
                "weight_fraction": float(fraction),
                "weight_fraction_esd_formal": float(esd),
                "weight_percent": 100.0 * float(fraction),
                "unit_cell": cell,
            }
        )
        results.append(metadata)
    return results


def write_result(project: G2sc.G2Project, stats: dict, phases: list[dict]) -> None:
    result = {
        "phases": phases,
        "weight_fraction_basis": (
            "normalized over the two modeled crystalline phases; no amorphous "
            "or absolute crystalline fraction was determined"
        ),
        "fit_statistics": stats,
        "profile": "fit.csv",
        "gsasii_project": "final.gpx",
        "uncertainty_note": (
            "Reported fraction esds are covariance-only. Model/source/profile "
            "systematics are larger; approximately 1-2 wt% absolute is a more "
            "realistic phase-fraction uncertainty."
        ),
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")


def write_report(stats: dict, phases: list[dict]) -> None:
    ca, wo = phases
    ca_cell = ca["unit_cell"]
    wo_cell = wo["unit_cell"]
    text = f"""# Quantitative crystalline-phase analysis

## Result

| Phase | Structural model | Weight fraction* |
|---|---|---:|
| CaWO4, scheelite | I 41/a (No. 88); a = {ca_cell['length_a']:.5f} Å, c = {ca_cell['length_c']:.5f} Å | {ca['weight_percent']:.2f}% |
| WO3, monoclinic | P 21/c (No. 14); a = {wo_cell['length_a']:.5f} Å, b = {wo_cell['length_b']:.5f} Å, c = {wo_cell['length_c']:.5f} Å, beta = {wo_cell['angle_beta']:.4f}° | {wo['weight_percent']:.2f}% |

*Normalized over the modeled crystalline phases. There is no external standard, so an amorphous fraction or absolute crystallinity cannot be obtained.

The final full-range fit gives Rwp = {stats['Rwp_percent']:.3f}%, Rp = {stats['Rp_percent']:.3f}%, Rexp = {stats['Rexp_percent']:.3f}%, and goodness of fit = {stats['goodness_of_fit']:.3f}. The elevated goodness of fit reflects counting-statistics weights applied to high-count data as well as remaining model/profile systematics; pointwise uncertainties were not supplied.

## Evidence and model selection

CaWO4 is fixed by the strong scheelite families at approximately 18.43°, 28.54°, 31.27°, 34.01°, 39.03°, 46.93°, 54.11°, 57.70°, 59.29°, and 76.05° 2theta. The 298 K scheelite source model (COD 7219229) fits, whereas a high-pressure fergusonite CaWO4 record gives a grossly inferior fit. Monoclinic WO3 is independently supported by its diagnostic 22.94°/23.42°/24.23° triplet and multiple higher-angle families. The selected neutron structure (COD 2311041) has a physically complete distorted WO6 environment; its beta near 136° is the valid native, nonconventional P 21/c cell setting. Both retained structures are stoichiometric with fully occupied sites; exported geometry gives CaWO4 W–O = 1.755 Å and Ca–O = 2.383–2.549 Å, and WO3 W–O = 1.713–2.157 Å. Alternative room-temperature monoclinic, low-temperature triclinic, and high-temperature orthorhombic/tetragonal/hexagonal records were challenged under the same nuisance model; none supplied a physically preferable improvement.

The accepted baseline uses the supplied Cu Kalpha1/Kalpha2 wavelengths and ratio, a six-term smooth Chebyshev background, one refined zero correction (-0.2007°), and a common nonnegative profile with U = W = 0 fixed and X = 9.29 refined. Isolated low-, middle-, and high-angle families show no remaining systematic position, FWHM, or asymmetry trend. Polarization was refined because it corrected a coherent cross-phase intensity trend. Repeated asymmetry did not support refining SH/L, which remained fixed at 0.002. Roughness was rejected as a highly correlated scale/background surrogate. For CaWO4 only, replay-stable [110] March-Dollase texture (1.262), [110] uniaxial Lorentzian size (0.117/0.189 µm), and isotropic Gaussian microstrain (4271 µstrain) were supported across multiple isolated families. WO3 size/strain terms collapsed to neutral bounds and were removed. The CaWO4 oxygen position and W Uiso were refined; extra Ca/O displacement parameters were not retained.

## Remaining uncertainty

CaO was kept on the weak-phase watch list. A fixed-cell trial produced a formal value near 1.2 wt%, but it improved only overlapped shoulders, worsened several other expected CaO regions, and a free-cell trial drifted to an implausible lattice parameter. It is therefore not reliably identified and is excluded from the quantitative inventory; roughly 1–2 wt% trace CaO cannot be ruled out. Other challenged watch-list phases refined to zero scale. The covariance-only fraction esds in `result.json` are much smaller than source/profile systematics; about 1–2 wt% absolute is a more realistic uncertainty on either reported fraction.
"""
    (ROOT / "report.md").write_text(text)


def main() -> None:
    project = replay_final()
    stats = fit_statistics(project)
    phases = phase_results(project)
    write_fit(project)
    write_cifs(project)
    write_result(project, stats, phases)
    write_report(stats, phases)
    print(json.dumps({"fit_statistics": stats, "phases": phases}, indent=2))


if __name__ == "__main__":
    main()
