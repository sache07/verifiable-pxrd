#!/usr/bin/env python3
"""Test limited atomic-coordinate/displacement refinements on the final profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from candidate_refine import ROOT, summarize


SCENARIOS = (
    "ca_o_xyz",
    "ca_all_u",
    "ca_o_xyz_all_u",
    "ca_o_xyz_w_u",
    "ca_o_xyz_ca_w_u",
)


def run(base: Path, scenario: str) -> dict:
    out = ROOT / ".tmp" / f"atom_{scenario}.gpx"
    if out.exists():
        out.unlink()
    project = G2sc.G2Project(str(base), newgpx=str(out))
    ca = project.phase(0)
    for atom in ca.atoms():
        atom.refinement_flags = ""
        if scenario in {
            "ca_o_xyz",
            "ca_o_xyz_all_u",
            "ca_o_xyz_w_u",
            "ca_o_xyz_ca_w_u",
        } and atom.element == "O":
            atom.refinement_flags += "X"
        if scenario in {"ca_all_u", "ca_o_xyz_all_u"}:
            atom.refinement_flags += "U"
        if scenario == "ca_o_xyz_w_u" and atom.element == "W":
            atom.refinement_flags += "U"
        if scenario == "ca_o_xyz_ca_w_u" and atom.element in {"Ca", "W"}:
            atom.refinement_flags += "U"
    project.data["Controls"]["data"]["max cyc"] = 12
    project.save()
    project.refine()
    project.save()
    project = G2sc.G2Project(str(out))
    project.refine()
    project.save()
    result = summarize(project, f"atom_{scenario}")
    result["atoms"] = {
        phase.name: [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": list(atom.coordinates),
                "occupancy": atom.occupancy,
                "Uiso": atom.uiso,
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ]
        for phase in project.phases()
    }
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("scenario", choices=SCENARIOS)
    args = parser.parse_args()
    result = run(args.base.resolve(), args.scenario)
    out = ROOT / ".tmp" / f"atom_{args.scenario}.json"
    out.write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
