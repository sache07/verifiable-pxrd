#!/usr/bin/env python3
"""Run common-baseline GSAS-II refinements for phase/source screening."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path(
    "<RUN>/resources/"
    "b001-c05/cif"
)

PHASES = {
    "scheelite": ("CaWO4_scheelite", "7/21/92/7219229.cif"),
    "fergusonite": ("CaWO4_fergusonite", "1/54/60/1546035.cif"),
    "wo3_mono_2311041": ("WO3_monoclinic_2311041", "2/31/10/2311041.cif"),
    "wo3_mono_2311041_reduced": (
        "WO3_monoclinic_2311041_reduced",
        None,
    ),
    "wo3_mono_1528915": ("WO3_monoclinic_1528915", "1/52/89/1528915.cif"),
    "wo3_triclinic": ("WO3_triclinic_2106293", "2/10/62/2106293.cif"),
    "wo3_orthorhombic": ("WO3_orthorhombic_2107312", "2/10/73/2107312.cif"),
    "wo3_tetragonal": ("WO3_tetragonal_1521532", "1/52/15/1521532.cif"),
    "wo3_hexagonal": ("WO3_hexagonal_1004057", "1/00/40/1004057.cif"),
    "cao": ("CaO", "1/56/31/1563196.cif"),
    "bronze": ("Ca4.3W10O30_bronze", "4/03/07/4030741.cif"),
}


def neutralize_hap(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData) -> None:
    """Remove default sample broadening and all other phase nuisances."""
    hap = phase.getHAPvalues(hist)
    hap["Scale"][:] = [1.0, True]
    hap["Pref.Ori."][1:3] = [1.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1.0e6, 1.0e6, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][4][:] = [1.0e6, 1.0e6, 1.0e6, 0.0, 0.0, 0.0]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def summarize(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    arrays = hist.data["data"][1]
    x, yo, wt, yc, yb, yd = [np.asarray(v) for v in arrays]
    limits = hist.data["Limits"][1]
    use = (x >= limits[0]) & (x <= limits[1]) & (wt > 0)
    wrss = float(np.sum(wt[use] * (yo[use] - yc[use]) ** 2))
    denom = float(np.sum(wt[use] * yo[use] ** 2))
    result = {
        "label": label,
        "gpx": str(Path(project.filename).relative_to(ROOT)),
        "n_points": int(np.count_nonzero(use)),
        "Rwp_percent_api": hist.get_wR(),
        "Rwp_percent_recomputed": 100.0 * (wrss / denom) ** 0.5,
        "weighted_residual_sum": wrss,
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")
        },
        "background": list(hist.data["Background"][0]),
        "phases": [],
    }
    try:
        mass_fracs = hist.ComputeMassFracs()
    except Exception as err:
        mass_fracs = {"error": repr(err)}
    result["mass_fractions"] = mass_fracs
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    cov = project.data.get("Covariance", {}).get("data", {})
    result["refinement"] = {
        "Rvals": cov.get("Rvals", {}),
        "varyList": cov.get("varyList", []),
        "variables": list(map(float, cov.get("variables", []))),
        "sig": list(map(float, cov.get("sig", []))),
    }
    return result


def build_and_refine(
    label: str, phase_keys: list[str], fixed_cells: set[str] | None = None
) -> dict:
    fixed_cells = fixed_cells or set()
    temp = ROOT / ".tmp"
    temp.mkdir(exist_ok=True)
    gpx = temp / f"{label}.gpx"
    if gpx.exists():
        gpx.unlink()
    project = G2sc.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma/tab/semicolon",
    )
    hist.data["Sample Parameters"]["Scale"][1] = False
    hist.data["Sample Parameters"]["Shift"][1] = False
    hist.data["Sample Parameters"]["Transparency"][1] = False
    hist.data["Sample Parameters"]["SurfRoughA"][1] = False
    hist.data["Sample Parameters"]["SurfRoughB"][1] = False
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [1434.4, -646.9, 362.7, -339.8, 175.3, -75.1],
                "refine": True,
            },
        }
    )
    inst = hist.data["Instrument Parameters"][0]
    for key in inst:
        if len(inst[key]) > 2:
            inst[key][2] = False

    phases = []
    for key in phase_keys:
        name, relpath = PHASES[key]
        phase_path = (
            ROOT / "wo3_2311041_reduced.cif"
            if relpath is None
            else CIF_ROOT / relpath
        )
        phase = project.add_phase(
            str(phase_path), phasename=name, histograms=[hist]
        )
        neutralize_hap(phase, hist)
        phases.append(phase)

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-5
    controls["deriv type"] = "analytic Hessian"
    project.save()

    # Inventory fit: common smooth background, all scales, and one zero correction.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()

    # Reconcile source cells against the same inventory and nuisance model.
    for key, phase in zip(phase_keys, phases):
        if key not in fixed_cells:
            phase.set_refinements({"Cell": True})
    project.refine()

    # Establish one common low-dimensional profile. U and W remain fixed at
    # their physical lower boundaries because unconstrained trials were negative.
    hist.set_refinements({"Instrument Parameters": ["X"]})
    project.refine()
    project.refine()
    project.save()
    return summarize(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--fix-cell", action="append", choices=sorted(PHASES), default=[])
    parser.add_argument("label")
    parser.add_argument("phases", nargs="+", choices=sorted(PHASES))
    args = parser.parse_args()
    result = build_and_refine(args.label, args.phases, set(args.fix_cell))
    out = ROOT / ".tmp" / f"{args.label}.json"
    out.write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
