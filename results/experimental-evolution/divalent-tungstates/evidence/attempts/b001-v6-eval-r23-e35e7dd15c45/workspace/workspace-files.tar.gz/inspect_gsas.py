#!/usr/bin/env python3
"""Build a minimal GSAS-II project and print the imported parameter layout."""

from __future__ import annotations

from pathlib import Path
from pprint import pprint

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path(
    "<RUN>/resources/"
    "b001-c05/cif"
)


def main() -> None:
    out = ROOT / ".tmp" / "inspect.gpx"
    out.parent.mkdir(exist_ok=True)
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma/tab/semicolon",
    )
    ca = project.add_phase(
        str(CIF_ROOT / "7/21/92/7219229.cif"),
        phasename="CaWO4_scheelite",
        histograms=[hist],
    )
    wo = project.add_phase(
        str(CIF_ROOT / "2/31/10/2311041.cif"),
        phasename="WO3_monoclinic",
        histograms=[hist],
    )
    project.save()
    print("hist", hist.name)
    print("limits")
    pprint(hist.data["Limits"])
    print("background")
    pprint(hist.data["Background"])
    print("instrument")
    pprint(hist.data["Instrument Parameters"])
    print("sample")
    pprint(hist.data["Sample Parameters"])
    for phase in (ca, wo):
        print("phase", phase.name)
        print("cell", phase.get_cell())
        pprint(phase.getHAPvalues(hist))


if __name__ == "__main__":
    main()
