#!/usr/bin/env python3
"""Freeze, replay and export the accepted GSAS-II refinement."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/restrained_weight_1000.gpx"
FINAL = ROOT / "final.gpx"

OUTPUT_PHASES = {
    "SrWO4": ("SrWO4", ROOT / "phases/srwo4.cif"),
    "WO3_mono": ("WO3", ROOT / "phases/wo3.cif"),
    "SrCO3": ("SrCO3", ROOT / "phases/srco3.cif"),
}


def prune_unsupported(project) -> None:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    # One angular correction only: instrument zero. Keep the measured doublet
    # wavelengths and reported intensity ratio fixed.
    inst["Zero"][2] = True
    for key in ("Lam1", "Lam2", "I(L2)/I(L1)"):
        inst[key][2] = False
    # Nonnegative common baseline. U is at its physical boundary; V/Y/Z and
    # SH/L were unsupported in controlled challenges and are neutralized.
    inst["U"][1:] = [0.0, False]
    inst["V"][1:] = [0.0, False]
    inst["W"][2] = True
    inst["X"][2] = True
    inst["Y"][1:] = [0.0, False]
    inst["Z"][1:] = [0.0, False]
    inst["SH/L"][1:] = [0.0, False]
    inst["Polariz."][2] = True

    sample = hist.SampleParameters
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    # Retain only accepted phase terms. A size value of 10 micrometres is the
    # GSAS-II upper bound and is negligible relative to this profile.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]

        if phase.name != "WO3_mono":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0:2] = [0.0, 0.0]
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]

        for atom in phase.atoms():
            atom.refinement_flags = " "

    project.phase("SrWO4").atom("O1").refinement_flags = "X"


def write_fit(hist) -> None:
    x, observed, weights, calculated, background, difference = hist.data["data"][1]
    target = ROOT / "fit.csv"
    with target.open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed",
                "calculated",
                "difference",
                "background",
            ]
        )
        writer.writerows(zip(x, observed, calculated, difference, background))


def write_result(project) -> dict:
    hist = project.histogram(0)
    mass = hist.ComputeMassFracs()
    fractions = {name: mass[name][0] for name in OUTPUT_PHASES}
    total = sum(fractions.values())
    residuals = hist.residuals
    phases = []
    for project_name, (display_name, path) in OUTPUT_PHASES.items():
        phase_id = project.phase(project_name).id
        phases.append(
            {
                "name": display_name,
                "cif_path": str(path.relative_to(ROOT)),
                "weight_fraction": float(fractions[project_name] / total),
                "weight_fraction_esd": float(mass[project_name][1]),
                "bragg_R_percent": float(residuals[f"{phase_id}:0:Rf"]),
            }
        )
    result = {
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(residuals["wR"] / residuals["wRmin"]),
        },
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
    }
    with (ROOT / "result.json").open("w") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    project.set_Controls("cycles", 16)
    prune_unsupported(project)
    project.save()
    for _ in range(3):
        project.refine(makeBack=False)
    project.save()

    # Required save/reopen/full-range replay before export.
    project = G2sc.G2Project(str(FINAL))
    project.set_Controls("cycles", 16)
    project.refine(makeBack=False)
    project.save()
    project = G2sc.G2Project(str(FINAL))

    (ROOT / "phases").mkdir(exist_ok=True)
    for project_name, (_, path) in OUTPUT_PHASES.items():
        project.phase(project_name).export_CIF(str(path))
    write_fit(project.histogram(0))
    result = write_result(project)

    hist = project.histogram(0)
    diagnostics = {
        "result": result,
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "textures": {
            phase.name: phase.data["Histograms"][hist.name]["Pref.Ori."]
            for phase in project.phases()
        },
        "mustrain": {
            phase.name: phase.data["Histograms"][hist.name]["Mustrain"]
            for phase in project.phases()
        },
        "atoms": {
            phase.name: [
                {
                    "label": atom.label,
                    "type": atom.type,
                    "xyz": list(atom.coordinates),
                    "uiso": atom.uiso,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ]
            for phase in project.phases()
        },
    }
    with (ROOT / ".tmp/final_diagnostics.json").open("w") as handle:
        json.dump(diagnostics, handle, indent=2)
    print(json.dumps(diagnostics, indent=2, default=float))


if __name__ == "__main__":
    main()
