#!/usr/bin/env python3
"""Re-challenge the refined model with the exact non-1:1 Sr3W2O9 record."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/restrained_weight_1000.gpx"
WATCH_CIF = Path(
    "<RUN>/"
    "resources/b001-c03/cif/2/31/19/2311977.cif"
)


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(SOURCE), newgpx=str(ROOT / ".tmp/watch_sr3w2o9.gpx"))
    project.set_Controls("cycles", 16)
    hist = project.histogram(0)
    phase = project.add_phase(
        str(WATCH_CIF),
        phasename="Sr3W2O9_watch",
        histograms=[hist],
        fmthint="CIF",
    )
    phase.data["General"]["Cell"][0] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.05, True]
    hap["Pref.Ori."][1:3] = [1.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    for _ in range(2):
        project.refine(makeBack=False)
    project.save()
    residuals = hist.residuals
    result = {
        "rwp": residuals["wR"],
        "gof": residuals["wR"] / residuals["wRmin"],
        "watch_scale": phase.data["Histograms"][hist.name]["Scale"][0],
        "mass_fractions": hist.ComputeMassFracs(),
    }
    print(json.dumps(result, indent=2, default=float))
    with (ROOT / ".tmp/watch_phase_challenge.json").open("w") as handle:
        json.dump(result, handle, indent=2)


if __name__ == "__main__":
    main()
