#!/usr/bin/env python3
"""Refine the SrWO4 oxygen position with a chemically screened W-O restraint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/anisotropy_uniaxial_010.gpx"


def run(weight: float) -> dict:
    label = f"weight_{weight:g}"
    target = ROOT / f".tmp/restrained_{label}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(target))
    project.set_Controls("cycles", 16)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    phase = project.phase("SrWO4")
    project.data["Restraints"]["data"].setdefault(
        phase.name,
        {"Bond": {"wtFactor": 1.0, "Range": 1.25, "Bonds": [], "Use": True}},
    )
    phase.clearDistRestraint()
    count = phase.addDistRestraint(["W1"], ["O1"], 1.79, factor=1.25, ESD=0.02)
    phase.setDistRestraintWeight(weight)
    phase.atom("O1").refinement_flags = "X"
    for _ in range(2):
        project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    residuals = hist.residuals
    result = {
        "weight": weight,
        "restraint_count": count,
        "rwp": residuals["wR"],
        "gof": residuals["wR"] / residuals["wRmin"],
        "oxygen_xyz": list(phase.atom("O1").coordinates),
        "mass_fractions": hist.ComputeMassFracs(),
    }
    phase.export_CIF(str(ROOT / f".tmp/restrained_{label}.cif"))
    print(json.dumps(result, indent=2, default=float))
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    records = [run(weight) for weight in (10.0, 100.0, 1000.0)]
    with (ROOT / ".tmp/restrained_structure_challenges.json").open("w") as handle:
        json.dump(records, handle, indent=2)


if __name__ == "__main__":
    main()
