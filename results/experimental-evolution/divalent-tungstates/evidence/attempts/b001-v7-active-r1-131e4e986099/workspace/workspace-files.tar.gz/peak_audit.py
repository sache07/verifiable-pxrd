#!/usr/bin/env python3
"""Numerically audit representative observed and calculated peak shapes."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.signal import savgol_filter


ROOT = Path(__file__).resolve().parent

SELECTIONS = [
    ("SrWO4", "low", (0, 1, 1), 0.45),
    ("SrWO4", "middle", (0, 2, 4), 0.45),
    ("SrWO4", "high", (4, 2, 4), 0.65),
    ("WO3_mono", "low", (2, 0, 0), 0.55),
    ("WO3_mono", "middle", (2, 2, 2), 0.65),
    ("WO3_mono", "high", (3, 4, 0), 0.35),
    ("SrCO3", "low", (1, 1, 1), 0.45),
    ("SrCO3", "middle", (1, 2, 2), 0.50),
    ("SrCO3", "high", (1, 2, 4), 0.45),
]


def reflection_position(reflections, phase: str, hkl: tuple[int, int, int]) -> float:
    matches = [
        row["two_theta_deg"]
        for row in reflections[phase]
        if tuple(row["hkl"]) == hkl
    ]
    if not matches:
        raise KeyError((phase, hkl))
    return matches[0]


def interpolate_crossing(x1, y1, x2, y2, target):
    if y2 == y1:
        return 0.5 * (x1 + x2)
    return x1 + (target - y1) * (x2 - x1) / (y2 - y1)


def shape_metrics(x, y, expected: float, window: float, smooth: bool) -> dict:
    mask = (x >= expected - window) & (x <= expected + window)
    xx = x[mask]
    yy = np.asarray(y[mask], dtype=float)
    if smooth:
        yy = savgol_filter(yy, 7, 2, mode="interp")

    edge = max(4, int(0.12 * len(xx)))
    baseline = float(np.median(np.r_[yy[:edge], yy[-edge:]]))
    yy = yy - baseline
    center_mask = np.abs(xx - expected) <= min(0.18, 0.45 * window)
    local_indices = np.flatnonzero(center_mask)
    peak_index = local_indices[np.argmax(yy[center_mask])]
    peak_position = float(xx[peak_index])
    peak_height = float(yy[peak_index])
    half = 0.5 * peak_height

    left_index = peak_index
    while left_index > 0 and yy[left_index] > half:
        left_index -= 1
    if left_index == 0 and yy[left_index] > half:
        raise RuntimeError(f"left half maximum not found near {expected}")
    left = interpolate_crossing(
        xx[left_index], yy[left_index], xx[left_index + 1], yy[left_index + 1], half
    )

    right_index = peak_index
    while right_index < len(xx) - 1 and yy[right_index] > half:
        right_index += 1
    if right_index == len(xx) - 1 and yy[right_index] > half:
        raise RuntimeError(f"right half maximum not found near {expected}")
    right = interpolate_crossing(
        xx[right_index - 1],
        yy[right_index - 1],
        xx[right_index],
        yy[right_index],
        half,
    )
    return {
        "position_deg": peak_position,
        "left_half_width_deg": float(peak_position - left),
        "right_half_width_deg": float(right - peak_position),
        "fwhm_deg": float(right - left),
        "height_counts": peak_height,
        "baseline_counts": baseline,
        "x_window": xx,
        "y_window": yy,
    }


def main() -> None:
    fit = pd.read_csv(ROOT / "fit.csv")
    x = fit["two_theta_deg"].to_numpy()
    observed = fit["observed"].to_numpy()
    calculated = fit["calculated"].to_numpy()
    components = {
        name: pd.read_csv(ROOT / f".tmp/component_{name}.csv")[
            "calculated_component"
        ].to_numpy()
        for name in ("SrWO4", "WO3_mono", "SrCO3")
    }
    with (ROOT / ".tmp/final_reflections.json").open() as handle:
        reflections = json.load(handle)

    rows = []
    fig, axes = plt.subplots(3, 3, figsize=(15, 11))
    for axis, (phase, region, hkl, window) in zip(axes.flat, SELECTIONS):
        expected = reflection_position(reflections, phase, hkl)
        phase_calc = components[phase]
        # Remove the refined background and the other two phase profiles from
        # the observation. This preserves measured noise and target-phase
        # model error while making weak, otherwise-overlapped lines auditable.
        phase_observed = observed - calculated + phase_calc
        obs_metrics = shape_metrics(x, phase_observed, expected, window, smooth=True)
        calc_metrics = shape_metrics(x, phase_calc, expected, window, smooth=False)

        row = {
            "phase": "WO3" if phase == "WO3_mono" else phase,
            "angle_region": region,
            "hkl": " ".join(str(value) for value in hkl),
            "expected_kalpha1_position_deg": expected,
        }
        for prefix, metrics in (("observed", obs_metrics), ("calculated", calc_metrics)):
            for key in (
                "position_deg",
                "left_half_width_deg",
                "right_half_width_deg",
                "fwhm_deg",
            ):
                row[f"{prefix}_{key}"] = metrics[key]
        rows.append(row)

        axis.plot(
            obs_metrics["x_window"],
            obs_metrics["y_window"],
            color="black",
            lw=1,
            label="observed, phase-isolated",
        )
        axis.plot(
            calc_metrics["x_window"],
            calc_metrics["y_window"],
            color="red",
            lw=1,
            label="calculated phase",
        )
        axis.axvline(expected, color="gray", lw=0.6, ls="--")
        axis.set_title(f"{row['phase']} {region}, ({row['hkl']})")
        axis.set_xlabel("2theta (degrees)")
        axis.set_ylabel("net counts")
        axis.grid(alpha=0.15)

    axes[0, 0].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(ROOT / ".tmp/peak_audit.png", dpi=180)

    columns = list(rows[0])
    with (ROOT / ".tmp/peak_audit.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)
    with (ROOT / ".tmp/peak_audit.json").open("w") as handle:
        json.dump(rows, handle, indent=2)
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
