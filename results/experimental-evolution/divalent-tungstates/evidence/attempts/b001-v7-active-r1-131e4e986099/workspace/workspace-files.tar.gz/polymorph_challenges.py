#!/usr/bin/env python3
"""Fit physical WO3 polymorph alternates with the same restrained model."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)

ALTERNATES = {
    "orthorhombic_Pnma": CIF_ROOT / "2/10/73/2107312.cif",
    "tetragonal_P4ncc": CIF_ROOT / "1/52/15/1521532.cif",
}


def make_xye() -> Path:
    target = ROOT / ".tmp/pattern.xye"
    if target.exists():
        return target
    x, y = [], []
    with (ROOT / "inputs/pattern.csv").open(newline="") as handle:
        for row in csv.DictReader(handle):
            x.append(float(row["two_theta_deg"]))
            y.append(float(row["intensity"]))
    x = np.asarray(x)
    y = np.asarray(y)
    np.savetxt(target, np.column_stack((x, y, np.sqrt(y))), fmt="%.8f %.8f %.8f")
    return target


def neutralize(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0:2] = [0.0, 0.0]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]


def run_model(name: str, path: Path, wo3_axis: tuple[int, int, int]) -> dict:
    axis_label = "".join(str(value) for value in wo3_axis)
    target = ROOT / f".tmp/polymorph_{name}_{axis_label}.gpx"
    project = G2sc.G2Project(newgpx=str(target))
    phase_specs = [
        ("SrWO4", ROOT / "models/srwo4_start.cif"),
        ("WO3_alt", path),
        ("SrCO3", CIF_ROOT / "9/00/81/9008198.cif"),
    ]
    for phase_name, phase_path in phase_specs:
        project.add_phase(str(phase_path), phasename=phase_name, fmthint="CIF")
    hist = project.add_powder_histogram(
        str(make_xye()),
        str(ROOT / "instrument.instprm"),
        phases="all",
        fmthint="xye",
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
                "coeffs": [1025.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            }
        }
    )
    for index, phase in enumerate(project.phases()):
        neutralize(phase, hist.name)
        phase.data["General"]["Cell"][0] = True
        phase.data["Histograms"][hist.name]["Scale"] = [
            [7.5, 2.0, 4.3][index],
            True,
        ]
        for atom in phase.atoms():
            atom.refinement_flags = " "

    inst = hist.InstrumentParameters
    for key in inst:
        if len(inst[key]) > 2:
            inst[key][2] = False
    for key, value in (("Zero", -0.638), ("Polariz.", 0.66), ("W", 40.0), ("X", 4.8)):
        inst[key][1] = value
        inst[key][2] = True
    inst["U"][1:] = [0.0, False]
    inst["V"][1:] = [0.0, False]
    inst["Y"][1:] = [0.0, False]

    texture = {
        "SrWO4": (1, 1, 0),
        "WO3_alt": wo3_axis,
        "SrCO3": (0, 0, 1),
    }
    for phase_name, axis in texture.items():
        pref = project.phase(phase_name).data["Histograms"][hist.name]["Pref.Ori."]
        pref[1] = 1.0
        pref[2] = True
        pref[3] = list(axis)

    # Give each alternate the same two-parameter uniaxial microstrain freedom.
    strain = project.phase("WO3_alt").data["Histograms"][hist.name]["Mustrain"]
    strain[0] = "uniaxial"
    strain[1][0:2] = [3000.0, 3000.0]
    strain[2][0:2] = [True, True]
    strain[3] = list(wo3_axis)

    project.set_Controls("cycles", 16)
    for _ in range(3):
        project.refine(makeBack=False)
    project.save()
    residuals = hist.residuals
    result = {
        "model": name,
        "axis": list(wo3_axis),
        "rwp": residuals["wR"],
        "gof": residuals["wR"] / residuals["wRmin"],
        "wo3_cell": project.phase("WO3_alt").get_cell(),
        "wo3_texture": project.phase("WO3_alt").data["Histograms"][hist.name]["Pref.Ori."],
        "wo3_strain": project.phase("WO3_alt").data["Histograms"][hist.name]["Mustrain"],
        "mass_fractions": hist.ComputeMassFracs(),
    }
    print(json.dumps(result, indent=2, default=float))
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    records = []
    for name, path in ALTERNATES.items():
        for axis in ((1, 0, 0), (0, 1, 0), (0, 0, 1)):
            records.append(run_model(name, path, axis))
    with (ROOT / ".tmp/polymorph_challenges.json").open("w") as handle:
        json.dump(records, handle, indent=2)


if __name__ == "__main__":
    main()
