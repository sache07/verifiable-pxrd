#!/usr/bin/env python3
"""Compare isotropic crystallite-size and microstrain terms phase by phase."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/texture_combined_best.gpx"


def neutral_broadening(project) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]


def run(phase_name: str, effect: str):
    label = f"{phase_name}_{effect}"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(ROOT / f".tmp/broadening_{label}.gpx"))
    project.set_Controls("cycles", 12)
    neutral_broadening(project)
    hist = project.histogram(0)
    hap = project.phase(phase_name).data["Histograms"][hist.name]
    if effect == "size":
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
    elif effect == "mustrain":
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True
    else:
        raise ValueError(effect)
    project.refine(makeBack=False)
    project.save()
    residuals = hist.residuals
    result = {
        "label": label,
        "rwp": residuals["wR"],
        "gof": residuals["wR"] / residuals["wRmin"],
        "size_um": {
            phase.name: phase.data["Histograms"][hist.name]["Size"][1][0]
            for phase in project.phases()
        },
        "microstrain": {
            phase.name: phase.data["Histograms"][hist.name]["Mustrain"][1][0]
            for phase in project.phases()
        },
        "mass_fractions": hist.ComputeMassFracs(),
    }
    print(json.dumps(result, indent=2, default=float))
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    records = []
    for phase_name in ("SrWO4", "WO3_mono", "SrCO3"):
        for effect in ("size", "mustrain"):
            records.append(run(phase_name, effect))
    with (ROOT / ".tmp/broadening_challenges.json").open("w") as handle:
        json.dump(records, handle, indent=2)


if __name__ == "__main__":
    main()
