#!/usr/bin/env python3
"""Staged GSAS-II refinement used to evaluate the three-phase baseline."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
RESOURCE_ROOT = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)

PHASES = [
    ("SrWO4", ROOT / "models/srwo4_start.cif"),
    ("WO3_mono", RESOURCE_ROOT / "1/52/89/1528915.cif"),
    ("SrCO3", RESOURCE_ROOT / "9/00/81/9008198.cif"),
]


def make_xye() -> Path:
    source = ROOT / "inputs/pattern.csv"
    target = ROOT / ".tmp/pattern.xye"
    x, y = [], []
    with source.open(newline="") as handle:
        for row in csv.DictReader(handle):
            x.append(float(row["two_theta_deg"]))
            y.append(float(row["intensity"]))
    x = np.asarray(x)
    y = np.asarray(y)
    # No pointwise uncertainties were supplied. Counts are used with a
    # Poisson counting estimate, sigma=sqrt(I), without resampling.
    np.savetxt(
        target,
        np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))),
        fmt="%.8f %.8f %.8f",
    )
    return target


def neutralize_hap(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:2] = [1.0e6, 1.0e6]
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:2] = [0.0, 0.0]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def project_state(gpx, label: str) -> dict:
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    state = {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L")
        },
        "cells": {phase.name: phase.get_cell() for phase in gpx.phases()},
        "scales": {
            phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
            for phase in gpx.phases()
        },
    }
    try:
        state["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        state["mass_fraction_error"] = str(exc)
    print(json.dumps(state, indent=2, default=float))
    return state


def refine_stage(gpx, label: str) -> dict:
    gpx.refine(makeBack=False)
    gpx.save()
    return project_state(gpx, label)


def main() -> None:
    G2sc.SetPrintLevel("warn")
    xye = make_xye()
    project = ROOT / ".tmp/baseline_three_phase.gpx"
    gpx = G2sc.G2Project(newgpx=project)
    for name, path in PHASES:
        gpx.add_phase(str(path), phasename=name, fmthint="CIF")
    hist = gpx.add_powder_histogram(
        str(xye),
        str(ROOT / "instrument.instprm"),
        phases="all",
        fmthint="xye",
    )

    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
                "coeffs": [1050.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            },
        }
    )
    for i, phase in enumerate(gpx.phases()):
        neutralize_hap(phase, hist.name)
        phase.data["General"]["Cell"][0] = False
        phase.data["Histograms"][hist.name]["Scale"] = [
            [1.0, 0.25, 0.15][i],
            True,
        ]
        for atom in phase.atoms():
            atom.refinement_flags = " "

    # Keep one angular correction (Zero), fixed at the indexed start until
    # phase cells and scales are stable. Keep the common profile low-dimensional.
    for key in hist.InstrumentParameters:
        if len(hist.InstrumentParameters[key]) > 2:
            hist.InstrumentParameters[key][2] = False

    gpx.set_Controls("cycles", 12)
    gpx.save()
    refine_stage(gpx, "background_scales")

    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = True
    refine_stage(gpx, "plus_cells")

    hist.InstrumentParameters["Zero"][2] = True
    refine_stage(gpx, "plus_zero")

    for key in ("U", "W", "X"):
        hist.InstrumentParameters[key][2] = True
    refine_stage(gpx, "plus_common_UWX")
    refine_stage(gpx, "reconverged")


if __name__ == "__main__":
    main()
