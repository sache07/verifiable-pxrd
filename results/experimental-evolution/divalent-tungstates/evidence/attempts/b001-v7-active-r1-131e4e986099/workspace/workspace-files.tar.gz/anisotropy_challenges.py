#!/usr/bin/env python3
"""Replay WO3 isotropic broadening and test compatible uniaxial strain."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp/texture_combined_best.gpx"


def reset_broadening(project) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0:2] = [0.0, 0.0]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]


def run(label: str, configure):
    target = ROOT / f".tmp/anisotropy_{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(target))
    project.set_Controls("cycles", 12)
    reset_broadening(project)
    configure(project)
    for _ in range(2):
        project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    hap = project.phase("WO3_mono").data["Histograms"][hist.name]
    residuals = hist.residuals
    result = {
        "label": label,
        "rwp": residuals["wR"],
        "gof": residuals["wR"] / residuals["wRmin"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "mass_fractions": hist.ComputeMassFracs(),
    }
    print(json.dumps(result, indent=2, default=float))
    return result


def isotropic(project) -> None:
    hist = project.histogram(0)
    hap = project.phase("WO3_mono").data["Histograms"][hist.name]
    hap["Mustrain"][1][0] = 4000.0
    hap["Mustrain"][2][0] = True


def size_and_strain(project) -> None:
    hist = project.histogram(0)
    hap = project.phase("WO3_mono").data["Histograms"][hist.name]
    hap["Size"][1][0] = 0.3
    hap["Size"][2][0] = True
    hap["Mustrain"][1][0] = 3000.0
    hap["Mustrain"][2][0] = True


def uniaxial(axis):
    def configure(project) -> None:
        hist = project.histogram(0)
        hap = project.phase("WO3_mono").data["Histograms"][hist.name]
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0:2] = [3000.0, 3000.0]
        hap["Mustrain"][2][0:2] = [True, True]
        hap["Mustrain"][3] = list(axis)

    return configure


def main() -> None:
    G2sc.SetPrintLevel("warn")
    records = [
        run("isotropic_strain", isotropic),
        run("size_plus_strain", size_and_strain),
    ]
    for axis in ((1, 0, 0), (0, 1, 0), (0, 0, 1)):
        label = "uniaxial_" + "".join(str(value) for value in axis)
        records.append(run(label, uniaxial(axis)))
    with (ROOT / ".tmp/anisotropy_challenges.json").open("w") as handle:
        json.dump(records, handle, indent=2)


if __name__ == "__main__":
    main()
