#!/usr/bin/env python3
"""Replay controlled nuisance-model challenges from one saved baseline."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
START = ROOT / ".tmp/baseline_three_phase.gpx"


def open_copy(source: Path, target: Path):
    project = G2sc.G2Project(str(source), newgpx=str(target))
    project.set_Controls("cycles", 12)
    return project


def summarize(project, label: str) -> dict:
    hist = project.histogram(0)
    residuals = hist.residuals
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    result = {
        "label": label,
        "rwp": residuals["wR"],
        "rexp": residuals["wRmin"],
        "gof": residuals["wR"] / residuals["wRmin"],
        "rp": residuals["R"],
        "zero": inst["Zero"][1],
        "polarization": inst["Polariz."][1],
        "U": inst["U"][1],
        "W": inst["W"][1],
        "X": inst["X"][1],
        "roughness_A": sample["SurfRoughA"][0],
        "roughness_B": sample["SurfRoughB"][0],
        "background_terms": hist.Background[0][2],
        "mass_fractions": hist.ComputeMassFracs(),
    }
    print(json.dumps(result, indent=2, default=float))
    return result


def replay(project, label: str, count: int = 2) -> dict:
    for _ in range(count):
        project.refine(makeBack=False)
    project.save()
    return summarize(project, label)


def main() -> None:
    G2sc.SetPrintLevel("warn")
    outputs = []

    # The unconstrained optimum made U slightly negative. Establish the
    # required nonnegative low-dimensional baseline at the boundary U=0,
    # while W and X remain refined and V/Y remain neutralized at zero.
    base_path = ROOT / ".tmp/baseline_nonnegative.gpx"
    base = open_copy(START, base_path)
    inst = base.histogram(0).InstrumentParameters
    inst["U"][1:] = [0.0, False]
    inst["V"][1:] = [0.0, False]
    inst["Y"][1:] = [0.0, False]
    outputs.append(replay(base, "baseline_nonnegative", 2))

    for terms in (6, 12):
        project = open_copy(base_path, ROOT / f".tmp/challenge_background_{terms}.gpx")
        bkg = project.histogram(0).Background[0]
        current = list(bkg[3:])
        coeffs = (current + [0.0] * terms)[:terms]
        project.histogram(0).set_refinements(
            {"Background": {"refine": True, "no. coeffs": terms, "coeffs": coeffs}}
        )
        outputs.append(replay(project, f"background_{terms}", 2))

    polar = open_copy(base_path, ROOT / ".tmp/challenge_polarization.gpx")
    polar.histogram(0).InstrumentParameters["Polariz."][2] = True
    outputs.append(replay(polar, "polarization", 2))

    rough = open_copy(base_path, ROOT / ".tmp/challenge_roughness.gpx")
    rough.histogram(0).SampleParameters["SurfRoughA"] = [0.35, True]
    rough.histogram(0).SampleParameters["SurfRoughB"] = [0.05, True]
    outputs.append(replay(rough, "surface_roughness", 2))

    combined = open_copy(base_path, ROOT / ".tmp/challenge_polar_rough.gpx")
    combined.histogram(0).InstrumentParameters["Polariz."][2] = True
    combined.histogram(0).SampleParameters["SurfRoughA"] = [0.35, True]
    combined.histogram(0).SampleParameters["SurfRoughB"] = [0.05, True]
    outputs.append(replay(combined, "polarization_plus_roughness", 2))

    with (ROOT / ".tmp/nuisance_challenges.json").open("w") as handle:
        json.dump(outputs, handle, indent=2)


if __name__ == "__main__":
    main()
