#!/usr/bin/env python3
"""Calculate fixed phase-only profiles from the reopened final project."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def freeze(project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    hist.Background[0][3:] = [0.0 for _ in hist.Background[0][3:]]
    for key, value in hist.InstrumentParameters.items():
        if len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]


def main() -> None:
    G2sc.SetPrintLevel("warn")
    reflection_data = {}
    for target_name in ("SrWO4", "WO3_mono", "SrCO3"):
        target = ROOT / f".tmp/component_{target_name}.gpx"
        project = G2sc.G2Project(str(ROOT / "final.gpx"), newgpx=str(target))
        project.set_Controls("cycles", 0)
        freeze(project)
        hist = project.histogram(0)
        for phase in project.phases():
            phase.data["Histograms"][hist.name]["Use"] = phase.name == target_name
        project.refine(makeBack=False)
        project.save()
        x, observed, weights, calculated, background, difference = hist.data["data"][1]
        np.savetxt(
            ROOT / f".tmp/component_{target_name}.csv",
            np.column_stack((x, calculated)),
            delimiter=",",
            header="two_theta_deg,calculated_component",
            comments="",
        )
        reflections = hist.data["Reflection Lists"][target_name]["RefList"]
        reflection_data[target_name] = [
            {
                "hkl": [int(value) for value in row[:3]],
                "multiplicity": int(row[3]),
                "d_angstrom": float(row[4]),
                "two_theta_deg": float(row[5]),
                "sigma": float(row[6]),
                "gamma": float(row[7]),
                "fcalc_sq": float(row[9]),
            }
            for row in reflections
        ]
    with (ROOT / ".tmp/final_reflections.json").open("w") as handle:
        json.dump(reflection_data, handle, indent=2)


if __name__ == "__main__":
    main()
