#!/usr/bin/env python3
"""Cross-check scorer-facing outputs against the reopened final project."""

from __future__ import annotations

import json
import math
import re
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PHASE_MAP = {"SrWO4": "SrWO4", "WO3": "WO3_mono", "SrCO3": "SrCO3"}


def cif_number(path: Path, tag: str) -> float:
    for line in path.read_text().splitlines():
        if line.startswith(tag):
            token = line.split(maxsplit=1)[1].strip().strip("'\"")
            token = re.sub(r"\([^)]*\)$", "", token)
            return float(token)
    raise KeyError(f"{tag} missing from {path}")


def main() -> None:
    with (ROOT / "result.json").open() as handle:
        result = json.load(handle)

    assert result["project_path"] == "final.gpx"
    assert result["profile_path"] == "fit.csv"
    assert (ROOT / result["project_path"]).is_file()
    assert (ROOT / result["profile_path"]).is_file()
    assert (ROOT / "report.md").is_file()

    listed = result["phases"]
    assert {row["name"] for row in listed} == set(PHASE_MAP)
    fractions = [row["weight_fraction"] for row in listed]
    assert all(
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(value)
        and value >= 0.0
        for value in fractions
    )
    assert abs(sum(fractions) - 1.0) < 1.0e-12
    for row in listed:
        assert (ROOT / row["cif_path"]).is_file()

    project = G2sc.G2Project(str(ROOT / "final.gpx"))
    assert {phase.name for phase in project.phases()} == set(PHASE_MAP.values())
    hist = project.histogram(0)
    mass = hist.ComputeMassFracs()
    mass_total = sum(mass[name][0] for name in PHASE_MAP.values())
    fraction_deltas = {}
    cif_cell_deltas = {}
    for row in listed:
        project_name = PHASE_MAP[row["name"]]
        expected = mass[project_name][0] / mass_total
        delta = abs(row["weight_fraction"] - expected)
        fraction_deltas[row["name"]] = delta
        assert delta < 1.0e-12

        phase_cell = project.phase(project_name).get_cell()
        cif = ROOT / row["cif_path"]
        keys = {
            "length_a": "_cell_length_a",
            "length_b": "_cell_length_b",
            "length_c": "_cell_length_c",
            "angle_alpha": "_cell_angle_alpha",
            "angle_beta": "_cell_angle_beta",
            "angle_gamma": "_cell_angle_gamma",
            "volume": "_cell_volume",
        }
        cell_deltas = {
            key: abs(phase_cell[key] - cif_number(cif, tag))
            for key, tag in keys.items()
        }
        cif_cell_deltas[row["name"]] = cell_deltas
        assert max(cell_deltas.values()) < 5.0e-4

    residuals = hist.residuals
    expected_stats = {
        "Rwp_percent": residuals["wR"],
        "Rp_percent": residuals["R"],
        "Rexp_percent": residuals["wRmin"],
        "goodness_of_fit": residuals["wR"] / residuals["wRmin"],
    }
    statistic_deltas = {
        key: abs(result["fit_statistics"][key] - value)
        for key, value in expected_stats.items()
    }
    assert max(statistic_deltas.values()) < 1.0e-12

    profile = np.genfromtxt(ROOT / "fit.csv", delimiter=",", names=True)
    x, observed, weights, calculated, background, difference = hist.data["data"][1]
    project_columns = {
        "two_theta_deg": x,
        "observed": observed,
        "calculated": calculated,
        "difference": difference,
        "background": background,
    }
    assert len(profile) == len(x) == 8301
    profile_max_abs_delta = {
        key: float(np.max(np.abs(profile[key] - values)))
        for key, values in project_columns.items()
    }
    assert max(profile_max_abs_delta.values()) < 1.0e-10
    assert abs(float(profile["two_theta_deg"][0]) - 9.90343322) < 1.0e-9
    assert abs(float(profile["two_theta_deg"][-1]) - 100.09455322) < 1.0e-9

    audit = {
        "status": "pass",
        "phase_count": len(listed),
        "weight_fraction_sum": sum(fractions),
        "fraction_max_abs_delta_from_project": max(fraction_deltas.values()),
        "fit_statistic_max_abs_delta_from_project": max(statistic_deltas.values()),
        "profile_max_abs_deltas_from_project": profile_max_abs_delta,
        "cif_cell_max_abs_deltas_from_project": {
            name: max(values.values()) for name, values in cif_cell_deltas.items()
        },
        "profile_points": len(profile),
        "profile_range_deg": [float(x[0]), float(x[-1])],
    }
    with (ROOT / ".tmp/submission_validation.json").open("w") as handle:
        json.dump(audit, handle, indent=2)
        handle.write("\n")
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
