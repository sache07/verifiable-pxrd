#!/usr/bin/env python3
"""Challenge the retained WO3 uniaxial strain with monoclinic Stephens terms."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIspc as G2spc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "final.gpx"


def run(label: str, active: tuple[int, ...]) -> dict:
    target = ROOT / f".tmp/generalized_strain_{label}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(target))
    project.set_Controls("cycles", 16)
    phase = project.phase("WO3_mono")
    hist = project.histogram(0)
    hap = phase.data["Histograms"][hist.name]
    general = phase.data["General"]
    names = G2spc.MustrainNames(general["SGData"])
    values = list(
        G2spc.Muiso2Shkl(4000.0, general["SGData"], general["Cell"][1:7])
    )
    hap["Mustrain"][0] = "generalized"
    hap["Mustrain"][4] = values
    hap["Mustrain"][5] = [index in active for index in range(len(values))]

    project.save()
    errors = []
    for _ in range(3):
        try:
            project.refine(makeBack=False)
        except Exception as error:  # record instability rather than hide it
            errors.append(repr(error))
            break
    project.save()
    # Reopen and replay to test that the terms survive serialization.
    project = G2sc.G2Project(str(target))
    try:
        project.refine(makeBack=False)
    except Exception as error:
        errors.append(repr(error))
    project.save()
    project = G2sc.G2Project(str(target))
    hist = project.histogram(0)
    hap = project.phase("WO3_mono").data["Histograms"][hist.name]
    residuals = hist.residuals
    record = {
        "label": label,
        "active_terms": [names[index] for index in active],
        "Rwp_percent": residuals["wR"],
        "Rexp_percent": residuals["wRmin"],
        "goodness_of_fit": residuals["wR"] / residuals["wRmin"],
        "values": dict(zip(names, hap["Mustrain"][4])),
        "refine_flags": dict(zip(names, hap["Mustrain"][5])),
        "mass_fractions": hist.ComputeMassFracs(),
        "errors": errors,
    }
    print(json.dumps(record, indent=2, default=float))
    return record


def main() -> None:
    G2sc.SetPrintLevel("warn")
    records = [
        run("principal", (0, 1, 2)),
        run("even_six", (0, 1, 2, 3, 4, 5)),
        run("full_nine", tuple(range(9))),
    ]
    with (ROOT / ".tmp/generalized_strain_challenge.json").open("w") as handle:
        json.dump(records, handle, indent=2)
        handle.write("\n")


if __name__ == "__main__":
    main()
