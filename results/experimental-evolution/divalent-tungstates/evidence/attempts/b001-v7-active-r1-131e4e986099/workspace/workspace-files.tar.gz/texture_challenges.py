#!/usr/bin/env python3
"""Compare no texture against axial and diagonal March-Dollase axes."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/challenge_polarization.gpx"

AXES = {
    "SrWO4": [(0, 0, 1), (1, 1, 0), (1, 1, 2)],
    "WO3_mono": [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 1)],
    "SrCO3": [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 1)],
}


def neutralize_all(project) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
        pref[0] = "MD"
        pref[1] = 1.0
        pref[2] = False
        pref[3] = [0, 0, 1]


def run_model(label: str, selections: dict[str, tuple[int, int, int]], cycles: int = 1):
    target = ROOT / f".tmp/texture_{label}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(target))
    project.set_Controls("cycles", 12)
    neutralize_all(project)
    hist = project.histogram(0)
    for phase_name, axis in selections.items():
        pref = project.phase(phase_name).data["Histograms"][hist.name]["Pref.Ori."]
        pref[1] = 1.0
        pref[2] = True
        pref[3] = list(axis)
    for _ in range(cycles):
        project.refine(makeBack=False)
    project.save()
    residuals = hist.residuals
    record = {
        "label": label,
        "selections": {key: list(value) for key, value in selections.items()},
        "rwp": residuals["wR"],
        "gof": residuals["wR"] / residuals["wRmin"],
        "md": {
            phase.name: phase.data["Histograms"][hist.name]["Pref.Ori."][1]
            for phase in project.phases()
        },
        "mass_fractions": hist.ComputeMassFracs(),
    }
    print(json.dumps(record, indent=2, default=float))
    return record


def main() -> None:
    G2sc.SetPrintLevel("warn")
    records = []
    for phase_name, axes in AXES.items():
        for axis in axes:
            axis_name = "".join(str(v) for v in axis)
            records.append(run_model(f"{phase_name}_{axis_name}", {phase_name: axis}))

    best = {}
    for phase_name in AXES:
        choices = [r for r in records if phase_name in r["selections"]]
        best[phase_name] = min(choices, key=lambda value: value["rwp"])
    combined_axes = {
        phase_name: tuple(record["selections"][phase_name])
        for phase_name, record in best.items()
    }
    records.append(run_model("combined_best", combined_axes, cycles=2))
    with (ROOT / ".tmp/texture_challenges.json").open("w") as handle:
        json.dump(records, handle, indent=2)


if __name__ == "__main__":
    main()
