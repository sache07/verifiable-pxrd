#!/usr/bin/env python3
"""Test restrained atomic and axial-divergence additions from the best baseline."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/anisotropy_uniaxial_010.gpx"


def run(label: str, configure):
    target = ROOT / f".tmp/atomic_{label}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(target))
    project.set_Controls("cycles", 16)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.histogram(0).InstrumentParameters["SH/L"][2] = False
    configure(project)
    for _ in range(2):
        project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    residuals = hist.residuals
    srwo4 = project.phase("SrWO4")
    result = {
        "label": label,
        "rwp": residuals["wR"],
        "gof": residuals["wR"] / residuals["wRmin"],
        "sh_over_l": hist.InstrumentParameters["SH/L"][1],
        "srwo4_atoms": [
            {
                "label": atom.label,
                "xyz": list(atom.coordinates),
                "uiso": atom.uiso,
                "flags": atom.refinement_flags,
            }
            for atom in srwo4.atoms()
        ],
        "mass_fractions": hist.ComputeMassFracs(),
    }
    print(json.dumps(result, indent=2, default=float))
    return result


def oxygen_xyz(project) -> None:
    project.phase("SrWO4").atom("O1").refinement_flags = "X"


def all_uiso(project) -> None:
    for atom in project.phase("SrWO4").atoms():
        atom.refinement_flags = "U"


def oxygen_xyz_all_uiso(project) -> None:
    for atom in project.phase("SrWO4").atoms():
        atom.refinement_flags = "U"
    project.phase("SrWO4").atom("O1").refinement_flags = "XU"


def axial_divergence(project) -> None:
    inst = project.histogram(0).InstrumentParameters
    inst["SH/L"][1] = 0.002
    inst["SH/L"][2] = True


def main() -> None:
    G2sc.SetPrintLevel("warn")
    records = [
        run("srwo4_oxygen_xyz", oxygen_xyz),
        run("srwo4_all_uiso", all_uiso),
        run("srwo4_oxygen_xyz_all_uiso", oxygen_xyz_all_uiso),
        run("axial_divergence", axial_divergence),
    ]
    with (ROOT / ".tmp/atomic_profile_challenges.json").open("w") as handle:
        json.dump(records, handle, indent=2)


if __name__ == "__main__":
    main()
