#!/usr/bin/env python3
"""Re-challenge chemically plausible weak phases under the final common profile."""

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
BASE = ROOT / "combined_bg8_pol_shl.gpx"


def cod_path(identifier):
    return COD / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


CANDIDATES = [
    ("CaO_rocksalt", "1563196"),
    ("Ca3WO6_P21n", "1563081"),
    ("WO3_gamma_ambient", "1528915"),
    ("WO3_gamma_alt", "2311041"),
    ("WO3_old_ambient", "1010618"),
    ("WO3_tetragonal_highT", "1521532"),
    ("CaCO3_calcite", "1547347"),
    ("CaOH2_portlandite", "7020138"),
]


def neutralize(phase, histogram):
    for atom in phase.atoms():
        atom.refinement_flags = ""
        atom.ADP = 0.0 if atom.adp_flag == "I" else [0.0] * 6
    hap = phase.getHAPvalues(histogram)
    hap["Scale"] = [0.05, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]


results = {}
for name, cod_id in CANDIDATES:
    out = ROOT / f"phase_test_{name}.gpx"
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(out))
    histogram = project.histogram(0)
    phase = project.add_phase(
        str(cod_path(cod_id)),
        phasename=name,
        histograms=[histogram],
        fmthint="CIF",
    )
    neutralize(phase, histogram)
    project.refine()
    first_scale = phase.getHAPvalues(histogram)["Scale"][0]
    try:
        first_value_esd = project.get_Variable("1:0:Scale")
    except Exception:
        first_value_esd = None
    try:
        first_mass_fracs = histogram.ComputeMassFracs()
    except Exception as error:
        first_mass_fracs = {"error": str(error)}
    project.save()
    # Full-range replay after save/reopen.
    project = G2sc.G2Project(gpxfile=str(out))
    histogram = project.histogram(0)
    phase = project.phase(1)
    project.refine()
    replay_scale = phase.getHAPvalues(histogram)["Scale"][0]
    try:
        replay_value_esd = project.get_Variable("1:0:Scale")
    except Exception:
        replay_value_esd = None
    try:
        replay_mass_fracs = histogram.ComputeMassFracs()
    except Exception as error:
        replay_mass_fracs = {"error": str(error)}
    project.save()
    yobs = np.asarray(histogram.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(histogram.getdata("Ycalc"), dtype=float)
    weight = np.asarray(histogram.getdata("Yweight"), dtype=float)
    result = {
        "cod_id": cod_id,
        "cif": str(cod_path(cod_id)),
        "first_scale": first_scale,
        "first_scale_value_esd": first_value_esd,
        "first_mass_fractions": first_mass_fracs,
        "replay_scale": replay_scale,
        "replay_scale_value_esd": replay_value_esd,
        "replay_mass_fractions": replay_mass_fracs,
        "rwp_percent": float(histogram.residuals["wR"]),
        "chi2": float(np.sum(weight * (yobs - ycalc) ** 2)),
    }
    print(name, result)
    results[name] = result

with open(ROOT / "phase_challenge_results.json", "w", encoding="utf-8") as stream:
    json.dump(results, stream, indent=2, default=float)
    stream.write("\n")
