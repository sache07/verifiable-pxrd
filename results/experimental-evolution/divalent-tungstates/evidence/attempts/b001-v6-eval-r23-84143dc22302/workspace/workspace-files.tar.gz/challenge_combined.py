#!/usr/bin/env python3
"""Test supported smooth-background/profile combinations."""

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "trial_u0_o.gpx"


def run(name, order, polar=False, axial=False, fix_zero=False):
    out = ROOT / f"combined_{name}.gpx"
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(out))
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"no. coeffs": order, "refine": True}})
    if polar:
        project.set_Controls("parmMin", 0.0, ":0:Polariz.")
        project.set_Controls("parmMax", 1.0, ":0:Polariz.")
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    if axial:
        project.set_Controls("parmMin", 0.0, ":0:SH/L")
        project.set_Controls("parmMax", 0.2, ":0:SH/L")
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    if fix_zero:
        hist.InstrumentParameters["Zero"][1] = 0.0
        hist.InstrumentParameters["Zero"][2] = False
    for _ in range(4 if axial else 2):
        project.refine()
    project.save()
    project = G2sc.G2Project(gpxfile=str(out))
    project.refine()
    project.save()
    hist = project.histogram(0)
    yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    weight = np.asarray(hist.getdata("Yweight"), dtype=float)
    result = {
        "rwp_percent": float(hist.residuals["wR"]),
        "rp_percent": float(hist.residuals["R"]),
        "chi2": float(np.sum(weight * (yobs - ycalc) ** 2)),
        "n_parameters": len(project.get_VaryList() or []),
        "bic_like": float(
            np.sum(weight * (yobs - ycalc) ** 2)
            + len(project.get_VaryList() or []) * np.log(len(yobs))
        ),
        "zero": hist.InstrumentParameters["Zero"][1],
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "sh_l": hist.InstrumentParameters["SH/L"][1],
        "background_coefficients": hist.Background[0][3:],
    }
    print(name, result)
    return result


results = {}
for args in [
    ("bg8", 8, False, False, False),
    ("bg10", 10, False, False, False),
    ("bg12", 12, False, False, False),
    ("bg8_pol", 8, True, False, False),
    ("bg8_shl", 8, False, True, False),
    ("bg8_pol_shl", 8, True, True, False),
    ("bg8_shl_zero_fixed", 8, False, True, True),
]:
    results[args[0]] = run(*args)

with open(ROOT / "combined_results.json", "w", encoding="utf-8") as stream:
    json.dump(results, stream, indent=2)
    stream.write("\n")
