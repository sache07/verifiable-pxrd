#!/usr/bin/env python3
"""Reproducible one-phase CaWO4 GSAS-II baseline refinement trial."""

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
GPX = ROOT / "baseline.gpx"
SOURCE_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/7/21/92/7219229.cif"
)


def show(stage, gpx, hist, phase):
    print(f"\n===== {stage} =====")
    print("residuals", hist.residuals)
    print("cell", phase.get_cell())
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()})
    print("sample", hist.SampleParameters)
    print("background", hist.Background)
    print("HAP", phase.getHAPvalues(hist))
    print("atoms", [
        (a.label, a.element, a.coordinates, a.occupancy, a.uiso, a.refinement_flags)
        for a in phase.atoms()
    ])
    print("vary", gpx.get_VaryList())


source = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
np.savetxt(ROOT / "pattern.xye", source, fmt=("%.8f", "%.8f"))

gpx = G2sc.G2Project(newgpx=str(GPX))
hist = gpx.add_powder_histogram(
    str(ROOT / "pattern.xye"),
    str(ROOT / "cu_kalpha.instprm"),
    fmthint="Topas xye",
)
phase = gpx.add_phase(
    str(SOURCE_CIF),
    phasename="CaWO4_scheelite",
    histograms=[hist],
    fmthint="CIF",
)

# Use phase scales (needed for QPA) and neutralize all unused phase broadening.
hist.clear_refinements({"Sample Parameters": ["Scale"]})
hap = phase.getHAPvalues(hist)
hap["Scale"] = [1.0, True]
hap["Size"][0] = "isotropic"
hap["Size"][1] = [1.0e6, 1.0e6, 1.0]
hap["Size"][2] = [False, False, False]
hap["Size"][5] = [False] * len(hap["Size"][5])
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1] = [0.0, 0.0, 1.0]
hap["Mustrain"][2] = [False, False, False]
hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
hap["HStrain"] = [[0.0] * len(hap["HStrain"][0]), [False] * len(hap["HStrain"][1])]
hap["Extinction"] = [0.0, False]
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = False

hist.set_refinements({
    "Background": {
        "type": "chebyschev-1",
        "refine": True,
        "no. coeffs": 6,
        "coeffs": [2000.0, 0.0, 0.0, 0.0, 0.0, 0.0],
    }
})
gpx.set_Controls("cycles", 10)
gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5

# 1. Low-order background and phase scale only.
gpx.refine()
show("background + scale", gpx, hist, phase)

# 2. One angular correction and the symmetry-constrained cell.
hist.set_refinements({"Instrument Parameters": ["Zero"]})
phase.set_refinements({"Cell": True})
gpx.refine()
show("zero + cell", gpx, hist, phase)

# 3. Common nonnegative low-dimensional profile; V/Y/Z remain fixed at zero.
for variable, lo, hi in [
    (":0:U", 0.0, 2000.0),
    (":0:W", 0.0, 1000.0),
    (":0:X", 0.0, 200.0),
]:
    gpx.set_Controls("parmMin", lo, variable)
    gpx.set_Controls("parmMax", hi, variable)
hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
gpx.refine()
show("common U/W/X profile", gpx, hist, phase)

# Replay from a saved/reopened project over the full measured range.
gpx.save()
gpx = G2sc.G2Project(gpxfile=str(GPX))
hist = gpx.histogram(0)
phase = gpx.phase(0)
hist.Limits("lower", float(source[0, 0]))
hist.Limits("upper", float(source[-1, 0]))
gpx.refine()
gpx.save()
show("saved/reopened full-range replay", gpx, hist, phase)
