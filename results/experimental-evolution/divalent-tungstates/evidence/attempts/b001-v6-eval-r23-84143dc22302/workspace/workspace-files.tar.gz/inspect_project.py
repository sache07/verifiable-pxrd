#!/usr/bin/env python3
"""Build a minimal GSAS-II project and inspect its initial data model."""

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
source = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
np.savetxt(ROOT / "pattern.xye", source, fmt=("%.8f", "%.8f"))

gpx = G2sc.G2Project(newgpx=str(ROOT / "trial.gpx"))
hist = gpx.add_powder_histogram(
    str(ROOT / "pattern.xye"),
    str(ROOT / "cu_kalpha.instprm"),
    fmthint="Topas xye",
)
phase = gpx.add_phase(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/7/21/92/7219229.cif",
    phasename="CaWO4_scheelite",
    histograms=[hist],
    fmthint="CIF",
)
print("histogram", hist.name)
print("limits", hist.data["Limits"])
print("background", hist.Background)
print("instrument", hist.InstrumentParameters)
print("sample", hist.SampleParameters)
print("cell", phase.get_cell())
print("atoms")
for atom in phase.atoms():
    print(atom.label, atom.element, atom.coordinates, atom.occupancy, atom.uiso)
print("HAP", phase.getHAPvalues(hist))
gpx.save()
