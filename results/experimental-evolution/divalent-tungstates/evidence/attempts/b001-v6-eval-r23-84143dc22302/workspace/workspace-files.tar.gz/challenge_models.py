#!/usr/bin/env python3
"""Challenge nuisance-model choices from the clean CaWO4 baseline."""

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "trial_u0_o.gpx"


def metrics(project, histogram):
    yobs = np.asarray(histogram.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(histogram.getdata("Ycalc"), dtype=float)
    weight = np.asarray(histogram.getdata("Yweight"), dtype=float)
    return {
        "rwp_percent": float(histogram.residuals["wR"]),
        "rp_percent": float(histogram.residuals["R"]),
        "chi2": float(np.sum(weight * (yobs - ycalc) ** 2)),
        "n_parameters": len(project.get_VaryList() or []),
    }


def run(name, mutate):
    path = ROOT / f"challenge_{name}.gpx"
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(path))
    histogram = project.histogram(0)
    phase = project.phase(0)
    mutate(project, histogram, phase)
    project.refine()
    project.save()
    # Saved/reopened replay is part of every model challenge.
    project = G2sc.G2Project(gpxfile=str(path))
    project.refine()
    project.save()
    histogram = project.histogram(0)
    phase = project.phase(0)
    result = metrics(project, histogram)
    result["instrument"] = {
        key: histogram.InstrumentParameters[key][1]
        for key in ("Zero", "Polariz.", "SH/L", "U", "W", "X")
    }
    result["sample_shift"] = histogram.SampleParameters["Shift"][0]
    hap = phase.getHAPvalues(histogram)
    result["size"] = hap["Size"][:3]
    result["mustrain"] = hap["Mustrain"][:3]
    result["preferred_orientation"] = hap["Pref.Ori."][:4]
    print(name, result)
    return result


def noop(project, histogram, phase):
    pass


def background_order(order):
    def mutate(project, histogram, phase):
        histogram.set_refinements({"Background": {"no. coeffs": order, "refine": True}})
    return mutate


def specimen_shift(project, histogram, phase):
    histogram.InstrumentParameters["Zero"][1] = 0.0
    histogram.InstrumentParameters["Zero"][2] = False
    histogram.SampleParameters["Shift"] = [0.0, True]


def polarization(project, histogram, phase):
    project.set_Controls("parmMin", 0.0, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    histogram.set_refinements({"Instrument Parameters": ["Polariz."]})


def shl(project, histogram, phase):
    project.set_Controls("parmMin", 0.0, ":0:SH/L")
    project.set_Controls("parmMax", 0.2, ":0:SH/L")
    histogram.set_refinements({"Instrument Parameters": ["SH/L"]})


def size(project, histogram, phase):
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": 10.0, "refine": True}
    }, [histogram])


def strain(project, histogram, phase):
    hap = phase.getHAPvalues(histogram)
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2][0] = True


def texture(axis):
    def mutate(project, histogram, phase):
        po = phase.getHAPvalues(histogram)["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = list(axis)
    return mutate


results = {}
for name, mutation in [
    ("baseline", noop),
    ("background4", background_order(4)),
    ("background5", background_order(5)),
    ("background8", background_order(8)),
    ("specimen_shift", specimen_shift),
    ("polarization", polarization),
    ("shl", shl),
    ("size_isotropic", size),
    ("strain_isotropic", strain),
    ("texture_001", texture((0, 0, 1))),
    ("texture_100", texture((1, 0, 0))),
    ("texture_110", texture((1, 1, 0))),
    ("texture_101", texture((1, 0, 1))),
    ("texture_111", texture((1, 1, 1))),
]:
    results[name] = run(name, mutation)

with open(ROOT / "challenge_results.json", "w", encoding="utf-8") as stream:
    json.dump(results, stream, indent=2)
    stream.write("\n")
