#!/usr/bin/env python3
"""Converge the accepted model and export all requested deliverables."""

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
START = ROOT / "combined_bg8_pol_shl.gpx"
FINAL = ROOT / "final.gpx"
CIF = ROOT / "phase_CaWO4.cif"


project = G2sc.G2Project(gpxfile=str(START), newgpx=str(FINAL))
histogram = project.histogram(0)
phase = project.phase(0)

# Reassert the accepted, physically screened model before final replay.
source = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
histogram.Limits("lower", float(source[0, 0]))
histogram.Limits("upper", float(source[-1, 0]))
histogram.Background[0][0] = "chebyschev-1"
histogram.Background[0][1] = True
histogram.Background[0][2] = 8
histogram.InstrumentParameters["V"][1:] = [0.0, False]
histogram.InstrumentParameters["Y"][1:] = [0.0, False]
histogram.InstrumentParameters["Z"][1:] = [0.0, False]
histogram.SampleParameters["Scale"] = [1.0, False]
histogram.SampleParameters["Shift"] = [0.0, False]
histogram.SampleParameters["Transparency"] = [0.0, False]
histogram.SampleParameters["SurfRoughA"] = [0.0, False]
histogram.SampleParameters["SurfRoughB"] = [0.0, False]

hap = phase.getHAPvalues(histogram)
hap["Scale"][1] = True
hap["Size"][0] = "isotropic"
hap["Size"][1][0] = 10.0
hap["Size"][2] = [False] * len(hap["Size"][2])
hap["Size"][5] = [False] * len(hap["Size"][5])
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][0] = 0.0
hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
hap["HStrain"] = [[0.0] * len(hap["HStrain"][0]), [False] * len(hap["HStrain"][1])]
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = False
hap["Extinction"] = [0.0, False]

# The data drive unconstrained ADPs negative. Keep the physical nonnegative
# limiting model and refine only the oxygen coordinates.
for atom in phase.atoms():
    atom.ADP = 0.0 if atom.adp_flag == "I" else [0.0] * 6
    atom.refinement_flags = "X" if atom.label == "O1" else ""

project.set_Controls("cycles", 10)
project.data["Controls"]["data"]["min dM/M"] = 1.0e-5

# Repeated convergence followed by a saved/reopened full-range replay.
for _ in range(5):
    project.refine()
project.save()
project = G2sc.G2Project(gpxfile=str(FINAL))
project.refine()
project.save()
histogram = project.histogram(0)
phase = project.phase(0)

# Export directly from the final project.
phase.export_CIF(str(CIF))
x = np.asarray(histogram.getdata("X"), dtype=float)
yobs = np.asarray(histogram.getdata("Yobs"), dtype=float)
ycalc = np.asarray(histogram.getdata("Ycalc"), dtype=float)
ybkg = np.asarray(histogram.getdata("Background"), dtype=float)
residual = yobs - ycalc
weight = np.asarray(histogram.getdata("Yweight"), dtype=float)
with open(ROOT / "fit.csv", "w", newline="", encoding="utf-8") as stream:
    writer = csv.writer(stream)
    writer.writerow([
        "two_theta_deg",
        "observed_intensity",
        "calculated_intensity",
        "difference_observed_minus_calculated",
        "calculated_background",
    ])
    writer.writerows(zip(x, yobs, ycalc, residual, ybkg))

res = histogram.residuals
n_points = len(x)
n_parameters = len(project.get_VaryList() or [])
chi2 = float(np.sum(weight * residual**2))
reduced_chi2 = chi2 / (n_points - n_parameters)
cell, cell_esd = phase.get_cell_and_esd()
try:
    mass_fractions = histogram.ComputeMassFracs()
    project_fraction, project_fraction_esd = mass_fractions[phase.name]
except Exception:
    project_fraction, project_fraction_esd = 1.0, 0.0

result = {
    "phases": [
        {
            "name": "Calcium tungstate (scheelite)",
            "formula": "CaWO4",
            "space_group": "I 41/a",
            "cif_path": CIF.name,
            "weight_fraction": 1.0,
            "weight_fraction_percent": 100.0,
            "weight_fraction_esd": None,
            "refined_project_mass_fraction_before_single_phase_normalization": float(project_fraction),
            "refined_project_mass_fraction_esd": float(project_fraction_esd),
            "cell": cell,
            "cell_esd": cell_esd,
        }
    ],
    "fit_statistics": {
        "Rwp_percent": float(res["wR"]),
        "Rp_percent": float(res["R"]),
        "Rwp_min_percent": float(res["wRmin"]),
        "goodness_of_fit": float(math.sqrt(reduced_chi2)),
        "chi_square": chi2,
        "reduced_chi_square": float(reduced_chi2),
        "phase_RF_percent": float(res["0:0:Rf"]),
        "phase_RF2_percent": float(res["0:0:Rf^2"]),
        "number_of_profile_points": n_points,
        "number_of_refined_parameters": n_parameters,
        "two_theta_range_deg": [float(x[0]), float(x[-1])],
    },
    "weighting": "Poisson counting weights w=1/I were used because pointwise uncertainties were not supplied.",
    "project_path": FINAL.name,
    "profile_path": "fit.csv",
}
with open(ROOT / "result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

inst = histogram.InstrumentParameters
o = phase.atom("O1")
report = f"""# PXRD phase analysis

## Result

The modeled crystalline fraction is **single-phase CaWO4 (scheelite, I 41/a)**, with a normalized crystalline weight fraction of **100.0%**. The refined cell is a = {cell['length_a']:.6f}({cell_esd['length_a'] * 1e6:.0f}) A and c = {cell['length_c']:.6f}({cell_esd['length_c'] * 1e6:.0f}) A. The oxygen position is ({o.coordinates[0]:.5f}, {o.coordinates[1]:.5f}, {o.coordinates[2]:.5f}).

## Evidence and refinement

The CaO + WO3 precursor context and 900 C treatment favor CaWO4. The observed independent scheelite families at 18.61, 28.70/29.03, 34.17, 47.08, 57.84, 76.13, 90.46, and 99.02 degrees are reproduced across the full 9.903-100.095 degree range by the ambient I 41/a record (COD 7219229); the pressure-induced monoclinic CaWO4 alternative does not reproduce the peak pattern. The starting record is fully occupied and disorder-free. The refined geometry remains sensible (W-O = 1.778 A; Ca-O = 2.462-2.467 A).

The final GSAS-II model uses the reported Cu Kalpha1/Kalpha2 wavelengths and 0.5 intensity ratio, an eight-coefficient smooth Chebyshev background, one refined zero correction ({inst['Zero'][1]:.6f} degrees), polarization ({inst['Polariz.'][1]:.5f}), and a common nonnegative U/W/X profile ({inst['U'][1]:.3f}/{inst['W'][1]:.3f}/{inst['X'][1]:.3f}) with SH/L = {inst['SH/L'][1]:.5f}. The corresponding Kalpha1-component FWHM rises smoothly from 0.144 degrees at 18.6 degrees to 0.157 degrees at 47.1 degrees and 0.210 degrees at 90.5 degrees; low-angle side bias supports the retained asymmetry term. V, Y, Z, specimen shift, transparency, roughness, size/strain broadening, extinction, and texture were neutralized. Isotropic size and strain trials were unsupported; March-Dollase trials for [001], [100], [110], [101], and [111] all refined essentially to unity. The saved/reopened full-range replay gives Rwp = {res['wR']:.4f}%, Rp = {res['R']:.4f}%, and GOF = {math.sqrt(reduced_chi2):.4f}.

CaO, Ca3WO6, several ambient/high-temperature WO3 records, Ca(OH)2, and CaCO3 were re-challenged under the common profile. No candidate produced a replay-stable, information-criterion-supported scale or coherent unique peak families. A Ca2WO5 analogue search found no exact record and only chemically/structurally diverse parents, so no unsupported substituted prototype was retained.

## Remaining uncertainty

The 100% value is normalized over the modeled crystalline phases; it does not quantify amorphous material. Trace crystalline impurities below roughly 0.3 wt% (phase- and microstructure-dependent) cannot be excluded. Unconstrained ADPs refined slightly negative, so all Uiso values were fixed at the physical lower limit of zero; these are idealized and **not reliable thermal parameters**. Zero and SH/L are strongly correlated, so those nuisance values should not be interpreted independently. The topology, symmetry, cell, and oxygen coordinates are supported, but the last digits of the oxygen position should not be overinterpreted.
"""
with open(ROOT / "report.md", "w", encoding="utf-8") as stream:
    stream.write(report)

print(json.dumps(result, indent=2))
