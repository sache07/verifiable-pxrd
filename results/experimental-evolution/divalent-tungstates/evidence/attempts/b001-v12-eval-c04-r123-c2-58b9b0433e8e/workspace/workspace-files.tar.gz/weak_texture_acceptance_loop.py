#!/usr/bin/env python3
"""Rechallenge background, profiles and all low-index axes after accepting Mn3O4 [110] texture."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("accepted_loop/nuisance/phase2_texture_1_1_0.gpx")
OUT = Path("accepted_loop/weak_texture")


def unchanged(project: G2sc.G2Project) -> None:
    del project


def background(order: int) -> Callable[[G2sc.G2Project], None]:
    def configure(project: G2sc.G2Project) -> None:
        terms = project.histogram(0).data["Background"][0]
        coeffs = (list(terms[3:]) + [0.0] * order)[:order]
        terms[:] = ["chebyschev-1", True, order, *coeffs]

    return configure


def wo3_profile(mode: str) -> Callable[[G2sc.G2Project], None]:
    def configure(project: G2sc.G2Project) -> None:
        hist = project.histogram(0)
        hap = project.phase(1).data["Histograms"][hist.name]
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        if mode == "isotropic":
            hap["Size"][0] = "isotropic"
            hap["Size"][1][:] = [0.07, 10.0, 1.0]
            hap["Size"][2][:] = [True, False, False]
        elif mode == "uniaxial_001":
            hap["Size"][0] = "uniaxial"
            hap["Size"][1][:] = [0.061, 0.106, 1.0]
            hap["Size"][2][:] = [True, True, False]
            hap["Size"][3][:] = [0, 0, 1]
        else:
            raise ValueError(mode)
        project.set_Controls("parmMin", 0.01, variable="1:0:Size;i")
        project.set_Controls("parmMax", 1000.0, variable="1:0:Size;i")
        project.set_Controls("parmMin", 0.01, variable="1:0:Size;a")
        project.set_Controls("parmMax", 1000.0, variable="1:0:Size;a")

    return configure


def weak_profile(mode: str) -> Callable[[G2sc.G2Project], None]:
    def configure(project: G2sc.G2Project) -> None:
        hist = project.histogram(0)
        hap = project.phase(2).data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        if mode in ("size", "combined"):
            hap["Size"][1][0] = 0.045
            hap["Size"][2][0] = True
        if mode in ("strain", "combined"):
            hap["Mustrain"][1][0] = 10600.0
            hap["Mustrain"][2][0] = True
        if mode not in ("neutral", "size", "strain", "combined"):
            raise ValueError(mode)
        project.set_Controls("parmMin", 0.01, variable="2:0:Size;i")
        project.set_Controls("parmMax", 1000.0, variable="2:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable="2:0:Mustrain;i")
        project.set_Controls("parmMax", 20000.0, variable="2:0:Mustrain;i")

    return configure


def weak_texture(axis: tuple[int, int, int]) -> Callable[[G2sc.G2Project], None]:
    def configure(project: G2sc.G2Project) -> None:
        hist = project.histogram(0)
        po = project.phase(2).data["Histograms"][hist.name]["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", 1.0, True, list(axis)
        project.set_Controls("parmMin", 0.2, variable="2:0:MD")
        project.set_Controls("parmMax", 5.0, variable="2:0:MD")

    return configure


def tag_axis(axis: tuple[int, int, int]) -> str:
    return "_".join(map(str, axis))


def run(tag: str, configure: Callable[[G2sc.G2Project], None]) -> dict:
    target = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(target))
    project.set_Frozen()
    configure(project)
    project.set_Controls("cycles", 20)
    project.save()
    replays = []
    for replay in range(4):
        project.refine()
        hist = project.histogram(0)
        cov = project.data["Covariance"]["data"]
        sigma = dict(zip(map(str, cov.get("varyList", [])), cov.get("sig", [])))
        replays.append(
            {
                "replay": replay,
                "residuals": hist.residuals,
                "fractions": hist.ComputeMassFracs(),
                "background": hist.data["Background"][0],
                "background_sigmas": [
                    sigma.get(f":0:Back;{i}")
                    for i in range(hist.data["Background"][0][2])
                ],
                "profiles": [
                    {
                        "size": phase.data["Histograms"][hist.name]["Size"],
                        "strain": phase.data["Histograms"][hist.name]["Mustrain"],
                        "march": phase.data["Histograms"][hist.name]["Pref.Ori."],
                    }
                    for phase in project.phases()
                ],
                "rvals": cov.get("Rvals", {}),
                "frozen": project.get_Frozen(),
            }
        )
        if project.get_Frozen():
            break
    project.save()
    return {"tag": tag, "project": str(target), "replays": replays}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    specs: list[tuple[str, Callable[[G2sc.G2Project], None]]] = [
        ("selected_replay", unchanged),
        ("background_10", background(10)),
        ("background_11", background(11)),
        ("background_12", background(12)),
        ("wo3_isotropic", wo3_profile("isotropic")),
        ("wo3_uniaxial_001", wo3_profile("uniaxial_001")),
        ("mn3o4_neutral", weak_profile("neutral")),
        ("mn3o4_size", weak_profile("size")),
        ("mn3o4_strain", weak_profile("strain")),
        ("mn3o4_combined", weak_profile("combined")),
    ]
    for axis in ((1, 0, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (1, 1, 1)):
        specs.append((f"mn3o4_texture_{tag_axis(axis)}", weak_texture(axis)))

    rows = []
    for tag, configure in specs:
        row = run(tag, configure)
        rows.append(row)
        last = row["replays"][-1]
        print(
            json.dumps(
                {
                    "tag": tag,
                    "wR": last["residuals"].get("wR"),
                    "fractions": last["fractions"],
                    "profiles": last["profiles"],
                    "background_tail": last["background"][-3:],
                    "background_sigma_tail": last["background_sigmas"][-3:],
                    "max_shift_over_sigma": last["rvals"].get("Max shft/sig"),
                    "frozen": last["frozen"],
                }
            ),
            flush=True,
        )
        (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
