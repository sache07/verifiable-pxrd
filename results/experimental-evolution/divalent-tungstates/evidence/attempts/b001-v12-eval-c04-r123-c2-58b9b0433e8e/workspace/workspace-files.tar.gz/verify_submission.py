#!/usr/bin/env python3
"""Audit the submitted JSON, GPX, CIFs, and profile against one another."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


CORE_PYTHON = "<HOME>/.local/share/pxrd-baseline/core/bin/python"


def close(left: float, right: float, tolerance: float = 1e-8) -> None:
    if not np.isclose(left, right, rtol=0.0, atol=tolerance):
        raise AssertionError(f"{left!r} != {right!r}")


def main() -> None:
    result = json.loads(Path("result.json").read_text())
    if result["project_path"] != "final.gpx":
        raise AssertionError("result.json does not name final.gpx")
    if not Path(result["project_path"]).is_file():
        raise AssertionError("final.gpx is missing")
    if result["fit_profile_path"] != "fit.csv" or not Path("fit.csv").is_file():
        raise AssertionError("fit.csv is missing or misnamed")

    fractions = [row["weight_fraction"] for row in result["phases"]]
    if any(not isinstance(value, (float, int)) or value <= 0 for value in fractions):
        raise AssertionError("Every phase needs a positive numeric weight fraction")
    close(sum(fractions), 1.0, 1e-12)
    for row in result["phases"]:
        if row["project_path"] != "final.gpx" or not Path(row["cif_path"]).is_file():
            raise AssertionError(f"Bad project/CIF path for {row['name']}")

    project = G2sc.G2Project("final.gpx")
    hist = project.histogram(0)
    if project.get_Frozen():
        raise AssertionError(f"Frozen variables remain: {project.get_Frozen()}")
    close(hist.data["Limits"][0][0], hist.data["Limits"][1][0])
    close(hist.data["Limits"][0][1], hist.data["Limits"][1][1])

    mass_fractions = hist.ComputeMassFracs()
    for row, phase in zip(result["phases"], project.phases()):
        close(row["weight_fraction"], mass_fractions[phase.name][0], 1e-10)

    # Verify that inactive physical terms are truly neutral.
    hname = hist.name
    main_hap = project.phase(0).data["Histograms"][hname]
    if main_hap["Size"][1][0] < 10 or any(main_hap["Size"][2]):
        raise AssertionError("MnWO4 inactive size term is not neutral")
    if main_hap["Mustrain"][1][0] != 0 or any(main_hap["Mustrain"][2]):
        raise AssertionError("MnWO4 inactive strain term is not neutral")
    if main_hap["Pref.Ori."][1] != 1 or main_hap["Pref.Ori."][2]:
        raise AssertionError("MnWO4 inactive texture term is not neutral")
    weak_hap = project.phase(2).data["Histograms"][hname]
    if weak_hap["Size"][1][0] < 10 or any(weak_hap["Size"][2]):
        raise AssertionError("Mn3O4 inactive size term is not neutral")

    profile = hist.data["data"][1]
    fit = np.genfromtxt("fit.csv", delimiter=",", names=True)
    source = np.genfromtxt("inputs/pattern.csv", delimiter=",", names=True)
    if len(fit) != 8301 or len(source) != len(fit):
        raise AssertionError("Profile row count is wrong")
    if not np.allclose(fit["two_theta_deg"], profile[0], rtol=0.0, atol=5e-9):
        raise AssertionError("fit.csv angles differ from final.gpx")
    if not np.allclose(fit["observed"], profile[1], rtol=0.0, atol=5e-8):
        raise AssertionError("fit.csv observations differ from final.gpx")
    if not np.allclose(fit["calculated"], profile[3], rtol=0.0, atol=5e-8):
        raise AssertionError("fit.csv calculations differ from final.gpx")
    if not np.allclose(fit["difference"], fit["observed"] - fit["calculated"], rtol=0.0, atol=1e-8):
        raise AssertionError("fit.csv difference is inconsistent")
    if not np.array_equal(fit["two_theta_deg"], source["two_theta_deg"]):
        raise AssertionError("fit.csv does not span the original angle grid")
    if not np.array_equal(fit["observed"], source["intensity"]):
        raise AssertionError("fit.csv does not contain the original observations")

    stats = result["fit_statistics"]
    cov = project.data["Covariance"]["data"]["Rvals"]
    close(stats["r_wp_percent"], hist.residuals["wR"])
    close(stats["r_p_percent"], hist.residuals["R"])
    close(stats["goodness_of_fit"], cov["GOF"])
    if stats["n_observations"] != cov["Nobs"] or stats["n_variables"] != cov["Nvars"]:
        raise AssertionError("Fit counts differ between JSON and GPX")

    health_run = subprocess.run(
        [
            CORE_PYTHON,
            "learned/cif_health.py",
            *[row["cif_path"] for row in result["phases"]],
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    health = json.loads(health_run.stdout)
    Path("final_cif_health.json").write_text(json.dumps(health, indent=2) + "\n")
    if len(health) != len(result["phases"]) or any(row["status"] != "pass" for row in health):
        raise AssertionError("A final CIF failed the health screen")

    verification = {
        "status": "pass",
        "fraction_sum": sum(fractions),
        "profile_points": len(fit),
        "full_range_deg_2theta": list(hist.data["Limits"][1]),
        "project_frozen_variables": project.get_Frozen(),
        "final_cif_health": [row["status"] for row in health],
        "r_wp_percent": stats["r_wp_percent"],
    }
    Path("verification.json").write_text(json.dumps(verification, indent=2) + "\n")
    print(json.dumps(verification, indent=2))


if __name__ == "__main__":
    main()
