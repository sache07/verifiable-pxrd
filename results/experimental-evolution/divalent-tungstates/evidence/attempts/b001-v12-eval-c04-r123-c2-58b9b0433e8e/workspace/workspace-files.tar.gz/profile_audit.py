#!/usr/bin/env python3
"""Audit weak-phase families with fitted positions and asymmetric half widths."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIpwd as G2pwd


PROJECTS = {
    "neutral": Path("joint_texture_trials/replay.gpx"),
    "size": Path("profile_boundary_replays/mn3o4_size_seed01.gpx"),
    "strain": Path("profile_boundary_replays/mn3o4_strain_seed2000.gpx"),
}
TARGETS = [(1, 0, 1), (1, 0, 3), (3, 2, 1), (4, 1, 3)]
PHASE = "9001963"


def peak_component(x: np.ndarray, pos: float, sig: float, gam: float, amp: float, inst: dict) -> np.ndarray:
    shl = max(float(inst["SH/L"][1]), 0.002)
    lam_ratio = 360.0 * (inst["Lam2"][1] - inst["Lam1"][1]) / (np.pi * inst["Lam1"][1])
    k_ratio = float(inst["I(L2)/I(L1)"][1])
    pos2 = pos + lam_ratio * np.tan(np.deg2rad(pos / 2.0))
    return amp * (
        G2pwd.getFCJVoigt3(pos, sig, gam, shl, x)[0]
        + k_ratio * G2pwd.getFCJVoigt3(pos2, sig, gam, shl, x)[0]
    )


def phase_partial(hist) -> np.ndarray:
    data = np.asarray(hist.data["data"][1])
    x = data[0]
    inst = hist.data["Instrument Parameters"][0]
    partial = np.zeros_like(x)
    for refl in hist.data["Reflection Lists"][PHASE]["RefList"]:
        pos, sig, gam = [float(v) for v in refl[5:8]]
        amp = float(refl[9] * refl[11])
        width = max(1.0, 8.0 * G2pwd.getgamFW(gam, np.sqrt(sig)) / 100.0)
        lo = np.searchsorted(x, pos - width)
        hi = np.searchsorted(x, pos + width)
        partial[lo:hi] += peak_component(x[lo:hi], pos, sig, gam, amp, inst)
    return partial


def half_widths(inst: dict, pos: float, sig: float, gam: float) -> tuple[float, float, float]:
    grid = np.linspace(pos - 1.5, pos + 1.5, 12001)
    profile = peak_component(grid, pos, sig, gam, 1.0, inst)
    imax = int(np.argmax(profile))
    half = profile[imax] / 2.0
    left_idx = np.where(profile[:imax] <= half)[0]
    right_idx = np.where(profile[imax:] <= half)[0]
    if not len(left_idx) or not len(right_idx):
        return float("nan"), float("nan"), float("nan")
    il = int(left_idx[-1])
    ir = int(imax + right_idx[0])
    # Linear interpolation at both crossings.
    xl = np.interp(half, [profile[il], profile[il + 1]], [grid[il], grid[il + 1]])
    xr = np.interp(half, [profile[ir], profile[ir - 1]], [grid[ir], grid[ir - 1]])
    center = grid[imax]
    return float(center - xl), float(xr - center), float(xr - xl)


def target_reflection(hist, hkl: tuple[int, int, int]) -> np.ndarray:
    for refl in hist.data["Reflection Lists"][PHASE]["RefList"]:
        if tuple(int(v) for v in refl[:3]) == hkl:
            return refl
    raise KeyError(hkl)


def main() -> None:
    loaded = {}
    for label, path in PROJECTS.items():
        project = G2sc.G2Project(str(path))
        hist = project.histogram(0)
        loaded[label] = (hist, np.asarray(hist.data["data"][1]), phase_partial(hist))

    strain_hist, strain_data, strain_partial = loaded["strain"]
    x, yobs, weights, ycalc = strain_data[0], strain_data[1], strain_data[2], strain_data[3]
    other_calc = ycalc - strain_partial
    isolated_signal = yobs - other_calc
    inst = strain_hist.data["Instrument Parameters"][0]
    rows = []

    for hkl in TARGETS:
        refl = target_reflection(strain_hist, hkl)
        p0, s0, g0 = [float(v) for v in refl[5:8]]
        a0 = float(refl[9] * refl[11])
        radius = 0.55 if p0 < 65.0 else 0.75
        mask = (x >= p0 - radius) & (x <= p0 + radius)
        xx, yy = x[mask], isolated_signal[mask]

        def residual(par: np.ndarray) -> np.ndarray:
            pos, sig, gam, amp, c0, c1 = par
            model = peak_component(xx, pos, sig, gam, amp, inst) + c0 + c1 * (xx - p0)
            return (yy - model) * np.sqrt(weights[mask])

        fit = least_squares(
            residual,
            x0=[p0, s0, g0, max(a0, 1.0), 0.0, 0.0],
            bounds=(
                [p0 - 0.18, 0.05, 0.0, 0.0, -1000.0, -2000.0],
                [p0 + 0.18, 400.0, 200.0, max(a0 * 10.0, 1000.0), 1000.0, 2000.0],
            ),
            max_nfev=300,
        )
        obs_pos, obs_sig, obs_gam = [float(v) for v in fit.x[:3]]
        obs_left, obs_right, obs_fwhm = half_widths(inst, obs_pos, obs_sig, obs_gam)

        models = {}
        for label, (hist, data, _) in loaded.items():
            r = target_reflection(hist, hkl)
            pos, sig, gam = [float(v) for v in r[5:8]]
            left, right, fwhm = half_widths(hist.data["Instrument Parameters"][0], pos, sig, gam)
            local = (data[0] >= p0 - radius) & (data[0] <= p0 + radius)
            chi = float(np.sum(data[2, local] * (data[1, local] - data[3, local]) ** 2))
            models[label] = {
                "position_deg": pos,
                "fwhm_deg": fwhm,
                "left_half_width_deg": left,
                "right_half_width_deg": right,
                "window_weighted_sse": chi,
            }

        rows.append(
            {
                "hkl": list(hkl),
                "angle_band": "low" if p0 < 40 else ("middle" if p0 < 70 else "high"),
                "observed_fit": {
                    "position_deg": obs_pos,
                    "fwhm_deg": obs_fwhm,
                    "left_half_width_deg": obs_left,
                    "right_half_width_deg": obs_right,
                    "success": bool(fit.success),
                    "weighted_sse": float(np.sum(fit.fun ** 2)),
                },
                "models": models,
            }
        )

    Path("profile_audit.json").write_text(json.dumps(rows, indent=2) + "\n")
    for row in rows:
        print(json.dumps(row), flush=True)


if __name__ == "__main__":
    main()
