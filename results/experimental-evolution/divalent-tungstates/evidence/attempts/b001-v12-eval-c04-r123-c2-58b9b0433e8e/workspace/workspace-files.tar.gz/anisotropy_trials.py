#!/usr/bin/env python3
"""Test low-dimensional symmetry-compatible WO3 size anisotropy."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("checkpoints/three_phase_wo3_size.gpx")
OUT = Path("anisotropy")


def run(direction: tuple[int, int, int]) -> dict:
    tag = "".join(str(value) for value in direction)
    project_path = OUT / f"wo3_uniaxial_{tag}.gpx"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(project_path))
    project.set_Frozen()
    histogram = project.histogram(0)
    phase = project.phase(1)
    hap = phase.data["Histograms"][histogram.name]
    isotropic_seed = float(hap["Size"][1][0])
    hap["Size"][0] = "uniaxial"
    hap["Size"][1][:] = [isotropic_seed, isotropic_seed, 1.0]
    hap["Size"][2][:] = [True, True, False]
    hap["Size"][3][:] = list(direction)
    project.set_Controls("cycles", 15)
    for name in ("Size;i", "Size;a"):
        project.set_Controls("parmMin", 0.01, variable=f"1:0:{name}")
        project.set_Controls("parmMax", 1000.0, variable=f"1:0:{name}")
    project.save()
    replays = []
    for replay in range(2):
        project.refine()
        histogram = project.histogram(0)
        phase = project.phase(1)
        hap = phase.data["Histograms"][histogram.name]
        replays.append(
            {
                "replay": replay,
                "residuals": histogram.residuals,
                "mass_fractions": histogram.ComputeMassFracs(),
                "size": hap["Size"],
                "profile": {
                    key: histogram.data["Instrument Parameters"][0][key][1]
                    for key in ("U", "W", "X")
                },
                "frozen": project.get_Frozen(),
                "vary_list": [str(item) for item in project.data["Covariance"]["data"].get("varyList", [])],
                "sigmas": [float(item) for item in project.data["Covariance"]["data"].get("sig", [])],
            }
        )
        if project.get_Frozen():
            break
    project.save()
    return {"direction": direction, "project": str(project_path), "replays": replays}


def main() -> None:
    OUT.mkdir(exist_ok=True)
    rows = []
    for direction in ((1, 0, 0), (0, 1, 0), (0, 0, 1)):
        row = run(direction)
        rows.append(row)
        last = row["replays"][-1]
        print(
            json.dumps(
                {
                    "direction": direction,
                    "wR": last["residuals"].get("wR"),
                    "size": last["size"],
                    "mass_fractions": last["mass_fractions"],
                    "frozen": last["frozen"],
                }
            ),
            flush=True,
        )
        (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
