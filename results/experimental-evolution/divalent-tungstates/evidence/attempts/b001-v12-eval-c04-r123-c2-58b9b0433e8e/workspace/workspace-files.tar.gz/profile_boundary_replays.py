#!/usr/bin/env python3
"""Complementary seeds/replays for profile terms that reversed, collapsed, or neared bounds."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("joint_texture_trials/replay.gpx")
OUT = Path("profile_boundary_replays")


def replay_existing(tag: str, source: Path, n: int = 3) -> dict:
    path = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 20)
    rows = []
    for replay in range(n):
        project.refine()
        hist = project.histogram(0)
        hap = project.phase(1).data["Histograms"][hist.name]
        rows.append({
            "replay": replay, "wR": hist.residuals.get("wR"),
            "fractions": hist.ComputeMassFracs(), "size": hap["Size"],
            "frozen": project.get_Frozen(),
        })
        if project.get_Frozen():
            break
    project.save()
    return {"tag": tag, "project": str(path), "replays": rows}


def wo3_isotropic() -> dict:
    path = OUT / "wo3_isotropic_seed0075.gpx"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(path))
    project.set_Frozen()
    hist = project.histogram(0)
    hap = project.phase(1).data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [0.075, 10.0, 1.0]
    hap["Size"][2][:] = [True, False, False]
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    project.set_Controls("parmMin", 0.01, variable="1:0:Size;i")
    project.set_Controls("parmMax", 1000.0, variable="1:0:Size;i")
    project.set_Controls("cycles", 20)
    project.save()
    rows = []
    for replay in range(3):
        project.refine()
        hist = project.histogram(0)
        hap = project.phase(1).data["Histograms"][hist.name]
        rows.append({"replay": replay, "wR": hist.residuals.get("wR"), "fractions": hist.ComputeMassFracs(), "size": hap["Size"], "frozen": project.get_Frozen()})
        if project.get_Frozen():
            break
    project.save()
    return {"tag": "wo3_isotropic_seed0075", "project": str(path), "replays": rows}


def weak_trial(tag: str, mode: str, seed: float) -> dict:
    path = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(path))
    project.set_Frozen()
    hist = project.histogram(0)
    hap = project.phase(2).data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    if mode == "strain":
        hap["Mustrain"][1][0] = seed
        hap["Mustrain"][2][0] = True
    else:
        hap["Size"][1][0] = seed
        hap["Size"][2][0] = True
    project.set_Controls("parmMin", 0.01, variable="2:0:Size;i")
    project.set_Controls("parmMax", 1000.0, variable="2:0:Size;i")
    project.set_Controls("parmMin", 0.0, variable="2:0:Mustrain;i")
    project.set_Controls("parmMax", 20000.0, variable="2:0:Mustrain;i")
    project.set_Controls("cycles", 20)
    project.save()
    rows = []
    for replay in range(3):
        project.refine()
        hist = project.histogram(0)
        hap = project.phase(2).data["Histograms"][hist.name]
        rows.append({"replay": replay, "wR": hist.residuals.get("wR"), "fractions": hist.ComputeMassFracs(), "size": hap["Size"], "mustrain": hap["Mustrain"], "frozen": project.get_Frozen()})
        if project.get_Frozen():
            break
    project.save()
    return {"tag": tag, "project": str(path), "replays": rows}


def main() -> None:
    OUT.mkdir(exist_ok=True)
    jobs = [
        lambda: wo3_isotropic(),
        lambda: replay_existing("wo3_uni100_more", Path("final_profile_loop/phase1_uni100.gpx")),
        lambda: replay_existing("wo3_uni010_more", Path("final_profile_loop/phase1_uni010.gpx")),
        lambda: replay_existing("wo3_uni001_more", Path("final_profile_loop/phase1_uni001.gpx")),
        lambda: weak_trial("mn3o4_strain_seed2000", "strain", 2000.0),
        lambda: weak_trial("mn3o4_strain_seed9000", "strain", 9000.0),
        lambda: weak_trial("mn3o4_size_seed01", "size", 0.1),
    ]
    rows = []
    for job in jobs:
        row = job()
        rows.append(row)
        print(json.dumps({"tag": row["tag"], **row["replays"][-1]}), flush=True)
        (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
