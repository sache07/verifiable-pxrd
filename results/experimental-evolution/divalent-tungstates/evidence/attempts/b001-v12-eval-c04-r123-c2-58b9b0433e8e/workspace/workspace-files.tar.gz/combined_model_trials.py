#!/usr/bin/env python3
"""Cross-challenge accepted coordinates against texture and weak-phase coordinates."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("coordinate_trials/mnwo4_all.gpx")
OUT = Path("combined_model_trials")


SPECS = [
    ("main_coords_replay", False, None, False),
    ("main_texture_11m1", False, (0, (1, 1, -1)), False),
    ("wo3_w_coords", True, None, False),
    ("wo3_texture_101", False, (1, (1, 0, 1)), False),
    ("wo3_w_coords_texture_101", True, (1, (1, 0, 1)), False),
    ("mn3o4_o_coords", False, None, True),
]


def run(tag: str, wo3_w: bool, texture: tuple[int, tuple[int, int, int]] | None, mn3o4_o: bool) -> dict:
    path = OUT / f"{tag}.gpx"
    cif_paths = [OUT / f"{tag}_phase{i}.cif" for i in range(3)]
    project = G2sc.G2Project(str(BASELINE), newgpx=str(path))
    project.set_Frozen()
    hist = project.histogram(0)
    for phase in project.phases():
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0], po[1], po[2] = "MD", 1.0, False
    project.phase(1).set_refinements({"Atoms": {"all": ""}})
    project.phase(2).set_refinements({"Atoms": {"all": ""}})
    if wo3_w:
        project.phase(1).set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
    if mn3o4_o:
        project.phase(2).set_refinements({"Atoms": {"O": "X"}})
    if texture:
        phase_index, axis = texture
        po = project.phase(phase_index).data["Histograms"][hist.name]["Pref.Ori."]
        po[1], po[2], po[3] = 1.0, True, list(axis)
        project.set_Controls("parmMin", 0.2, variable=f"{phase_index}:0:MD")
        project.set_Controls("parmMax", 5.0, variable=f"{phase_index}:0:MD")
    project.set_Controls("cycles", 20)
    project.save()
    replays = []
    for replay in range(2):
        project.refine()
        hist = project.histogram(0)
        replays.append(
            {
                "replay": replay,
                "residuals": hist.residuals,
                "fractions": hist.ComputeMassFracs(),
                "texture": [
                    phase.data["Histograms"][hist.name]["Pref.Ori."][1]
                    for phase in project.phases()
                ],
                "frozen": project.get_Frozen(),
            }
        )
        if project.get_Frozen():
            break
    project.save()
    for phase, cif_path in zip(project.phases(), cif_paths):
        phase.export_CIF(str(cif_path))
    return {
        "tag": tag,
        "project": str(path),
        "cifs": [str(p) for p in cif_paths],
        "replays": replays,
    }


def main() -> None:
    OUT.mkdir(exist_ok=True)
    rows = []
    for spec in SPECS:
        row = run(*spec)
        rows.append(row)
        print(json.dumps({"tag": row["tag"], **row["replays"][-1]}), flush=True)
        (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
