#!/usr/bin/env python3
"""Repeat texture ranking after accepted MnWO4 and WO3 coordinate refinement."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("combined_model_trials/wo3_w_coords.gpx")
OUT = Path("texture_rechallenge")
AXES = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (1, 0, -1), (0, 1, 1), (1, 1, 1), (1, 1, -1)]


def tag(axis: tuple[int, int, int]) -> str:
    return "_".join(f"m{-v}" if v < 0 else str(v) for v in axis)


def run(phase_index: int, axis: tuple[int, int, int]) -> dict:
    path = OUT / f"phase{phase_index}_{tag(axis)}.gpx"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(path))
    project.set_Frozen()
    hist = project.histogram(0)
    for phase in project.phases():
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0], po[1], po[2] = "MD", 1.0, False
    po = project.phase(phase_index).data["Histograms"][hist.name]["Pref.Ori."]
    po[1], po[2], po[3] = 1.0, True, list(axis)
    project.set_Controls("cycles", 20)
    project.set_Controls("parmMin", 0.2, variable=f"{phase_index}:0:MD")
    project.set_Controls("parmMax", 5.0, variable=f"{phase_index}:0:MD")
    project.save()
    replays = []
    for replay in range(2):
        project.refine()
        hist = project.histogram(0)
        cov = project.data["Covariance"]["data"]
        sigmas = dict(zip([str(v) for v in cov.get("varyList", [])], cov.get("sig", [])))
        po = project.phase(phase_index).data["Histograms"][hist.name]["Pref.Ori."]
        replays.append(
            {
                "replay": replay,
                "wR": hist.residuals.get("wR"),
                "fractions": hist.ComputeMassFracs(),
                "md": float(po[1]),
                "sigma": float(sigmas.get(f"{phase_index}:0:MD", 0.0)),
                "frozen": project.get_Frozen(),
            }
        )
        if project.get_Frozen():
            break
    project.save()
    return {"phase_index": phase_index, "axis": axis, "project": str(path), "replays": replays}


def main() -> None:
    OUT.mkdir(exist_ok=True)
    rows = []
    for phase_index in (0, 1):
        for axis in AXES:
            row = run(phase_index, axis)
            rows.append(row)
            print(json.dumps({"phase": phase_index, "axis": axis, **row["replays"][-1]}), flush=True)
            (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
