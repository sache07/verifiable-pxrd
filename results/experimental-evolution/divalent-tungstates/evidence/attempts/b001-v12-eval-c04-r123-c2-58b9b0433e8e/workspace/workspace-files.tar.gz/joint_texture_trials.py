#!/usr/bin/env python3
"""Test whether residual main/weak-phase texture adds to accepted WO3 [101] texture."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("combined_model_trials/wo3_w_coords_texture_101.gpx")
OUT = Path("joint_texture_trials")
SPECS = [
    ("replay", None, None),
    ("mnwo4_111", (0, (1, 1, 1)), None),
    ("mnwo4_11m1", (0, (1, 1, -1)), None),
    ("mnwo4_10m1", (0, (1, 0, -1)), None),
    ("mn3o4_110", None, (2, (1, 1, 0))),
    ("mn3o4_001", None, (2, (0, 0, 1))),
]


def run(tag: str, main_texture, weak_texture) -> dict:
    path = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(path))
    project.set_Frozen()
    hist = project.histogram(0)
    # Preserve the accepted WO3 [101] term and neutralize the other two phases.
    for index in (0, 2):
        po = project.phase(index).data["Histograms"][hist.name]["Pref.Ori."]
        po[0], po[1], po[2] = "MD", 1.0, False
    for item in (main_texture, weak_texture):
        if item is None:
            continue
        phase_index, axis = item
        po = project.phase(phase_index).data["Histograms"][hist.name]["Pref.Ori."]
        po[1], po[2], po[3] = 1.0, True, list(axis)
        project.set_Controls("parmMin", 0.2, variable=f"{phase_index}:0:MD")
        project.set_Controls("parmMax", 5.0, variable=f"{phase_index}:0:MD")
    project.set_Controls("cycles", 20)
    project.save()
    replays = []
    for replay in range(2):
        project.refine()
        hist = project.histogram(0)
        replays.append(
            {
                "replay": replay,
                "residuals": hist.residuals,
                "fractions": hist.ComputeMassFracs(),
                "md": [
                    phase.data["Histograms"][hist.name]["Pref.Ori."][1]
                    for phase in project.phases()
                ],
                "frozen": project.get_Frozen(),
            }
        )
        if project.get_Frozen():
            break
    project.save()
    return {"tag": tag, "project": str(path), "replays": replays}


def main() -> None:
    OUT.mkdir(exist_ok=True)
    rows = []
    for spec in SPECS:
        row = run(*spec)
        rows.append(row)
        print(json.dumps({"tag": row["tag"], **row["replays"][-1]}), flush=True)
        (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
