#!/usr/bin/env python3
"""Jointly replay the surviving WO3 and Mn3O4 profile alternatives."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("joint_texture_trials/replay.gpx")
OUT = Path("combined_profile_models")
SPECS = [
    ("wo3iso_mn3o4neutral", "iso", "neutral"),
    ("wo3iso_mn3o4strain", "iso", "strain"),
    ("wo3u001_mn3o4neutral", "u001", "neutral"),
    ("wo3u001_mn3o4strain", "u001", "strain"),
    ("wo3u001_mn3o4size", "u001", "size"),
]


def configure(project, wo3: str, mn3o4: str) -> None:
    hist = project.histogram(0)
    h1 = project.phase(1).data["Histograms"][hist.name]
    h1["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    h1["Mustrain"][2][:] = [False, False, False]
    if wo3 == "iso":
        h1["Size"][0] = "isotropic"
        h1["Size"][1][:] = [0.0745, 10.0, 1.0]
        h1["Size"][2][:] = [True, False, False]
    else:
        h1["Size"][0] = "uniaxial"
        h1["Size"][1][:] = [0.0645, 0.1210, 1.0]
        h1["Size"][2][:] = [True, True, False]
        h1["Size"][3][:] = [0, 0, 1]

    h2 = project.phase(2).data["Histograms"][hist.name]
    h2["Size"][0] = "isotropic"
    h2["Size"][1][:] = [10.0, 10.0, 1.0]
    h2["Size"][2][:] = [False, False, False]
    h2["Mustrain"][0] = "isotropic"
    h2["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    h2["Mustrain"][2][:] = [False, False, False]
    if mn3o4 == "strain":
        h2["Mustrain"][1][0] = 8800.0
        h2["Mustrain"][2][0] = True
    elif mn3o4 == "size":
        h2["Size"][1][0] = 0.056
        h2["Size"][2][0] = True


def run(tag: str, wo3: str, mn3o4: str) -> dict:
    path = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(path))
    project.set_Frozen()
    configure(project, wo3, mn3o4)
    for phase_index in (1, 2):
        project.set_Controls("parmMin", 0.01, variable=f"{phase_index}:0:Size;i")
        project.set_Controls("parmMax", 1000.0, variable=f"{phase_index}:0:Size;i")
        project.set_Controls("parmMin", 0.01, variable=f"{phase_index}:0:Size;a")
        project.set_Controls("parmMax", 1000.0, variable=f"{phase_index}:0:Size;a")
        project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;i")
        project.set_Controls("parmMax", 20000.0, variable=f"{phase_index}:0:Mustrain;i")
    project.set_Controls("cycles", 20)
    project.save()
    rows = []
    for replay in range(3):
        project.refine()
        hist = project.histogram(0)
        rows.append({
            "replay": replay, "residuals": hist.residuals,
            "fractions": hist.ComputeMassFracs(),
            "wo3_size": project.phase(1).data["Histograms"][hist.name]["Size"],
            "mn3o4_size": project.phase(2).data["Histograms"][hist.name]["Size"],
            "mn3o4_strain": project.phase(2).data["Histograms"][hist.name]["Mustrain"],
            "frozen": project.get_Frozen(),
        })
        if project.get_Frozen():
            break
    project.save()
    return {"tag": tag, "project": str(path), "replays": rows}


def main() -> None:
    OUT.mkdir(exist_ok=True)
    rows = []
    for spec in SPECS:
        row = run(*spec)
        rows.append(row)
        print(json.dumps({"tag": row["tag"], **row["replays"][-1]}), flush=True)
        (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
