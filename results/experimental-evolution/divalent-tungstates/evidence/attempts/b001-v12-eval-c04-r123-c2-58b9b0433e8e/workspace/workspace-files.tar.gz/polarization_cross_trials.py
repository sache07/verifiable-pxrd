#!/usr/bin/env python3
"""Cross-seed polarization/roughness to test whether the apparent trend is separable."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("intensity_geometry_trials/rough_020_020.gpx")
OUT = Path("polarization_cross_trials")


def run(tag: str, polar: bool, refine_a: bool, refine_b: bool) -> dict:
    path = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(path))
    project.set_Frozen()
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    inst["Polariz."][2] = polar
    sample["SurfRoughA"][1] = refine_a
    sample["SurfRoughB"][1] = refine_b
    project.set_Controls("cycles", 15)
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 5.0, variable=":0:SurfRoughB")
    project.save()
    replays = []
    for replay in range(2):
        project.refine()
        hist = project.histogram(0)
        sample = hist.data["Sample Parameters"]
        inst = hist.data["Instrument Parameters"][0]
        replays.append(
            {
                "replay": replay,
                "residuals": hist.residuals,
                "fractions": hist.ComputeMassFracs(),
                "polarization": inst["Polariz."],
                "roughness_a": sample["SurfRoughA"],
                "roughness_b": sample["SurfRoughB"],
                "frozen": project.get_Frozen(),
            }
        )
        if project.get_Frozen():
            break
    project.save()
    return {"tag": tag, "project": str(path), "replays": replays}


def main() -> None:
    OUT.mkdir(exist_ok=True)
    specs = [
        ("rough_replay", False, True, True),
        ("rough_plus_polar", True, True, True),
        ("rough_fixed_plus_polar", True, False, False),
        ("rough_a_fixed_b_refined", False, False, True),
        ("rough_a_refined_b_fixed", False, True, False),
    ]
    rows = []
    for spec in specs:
        row = run(*spec)
        rows.append(row)
        last = row["replays"][-1]
        print(json.dumps({"tag": row["tag"], **last}), flush=True)
        (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
