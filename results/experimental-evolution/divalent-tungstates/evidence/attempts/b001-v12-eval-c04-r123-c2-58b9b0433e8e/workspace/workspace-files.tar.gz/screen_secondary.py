#!/usr/bin/env python3
"""Screen exact precursor/source phases by scale from one neutral checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("checkpoints/mg_wx.gpx")


def neutralize(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [100.0, 100.0, 1.0]
    hap["Size"][2][:] = [False] * 3
    hap["Size"][4][:] = [100.0, 100.0, 100.0, 0.0, 0.0, 0.0]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False] * 3
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def screen(cif: Path, outdir: Path, baseline: Path) -> dict:
    label = cif.stem
    project_path = outdir / f"{label}.gpx"
    try:
        project = G2sc.G2Project(str(baseline), newgpx=str(project_path))
        histogram = project.histogram(0)
        phase = project.add_phase(
            str(cif.resolve()),
            phasename=label,
            histograms=[histogram],
            fmthint="CIF",
        )
        neutralize(phase, histogram.name)

        # Freeze all common values at the fully replayed checkpoint. The only
        # variable in this first gate is the new nonnegative phase scale.
        project.set_Frozen()
        histogram.data["Background"][0][1] = False
        for value in histogram.data["Instrument Parameters"][0].values():
            if isinstance(value, list) and len(value) > 2:
                value[2] = False
        for value in histogram.data["Sample Parameters"].values():
            if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
                value[1] = False
        new_phase_index = len(project.phases()) - 1
        for index, current_phase in enumerate(project.phases()):
            current_phase.data["General"]["Cell"][0] = False
            current_hap = current_phase.data["Histograms"][histogram.name]
            current_hap["Scale"][1] = index == new_phase_index
        phase.data["Histograms"][histogram.name]["Scale"][:] = [0.25, True]

        project.set_Controls("cycles", 10)
        scale_variable = f"{new_phase_index}:0:Scale"
        project.set_Controls("parmMin", 0.0, variable=scale_variable)
        project.set_Controls("parmMax", 1.0e8, variable=scale_variable)
        project.save()
        project.refine()
        histogram = project.histogram(0)
        phase = project.phase(new_phase_index)
        result = {
            "candidate": str(cif.resolve()),
            "project": str(project_path),
            "status": "ok",
            "residuals": histogram.residuals,
            "scale": phase.data["Histograms"][histogram.name]["Scale"][0],
            "cell": phase.get_cell(),
            "frozen": project.get_Frozen(),
        }
    except Exception as exc:
        result = {
            "candidate": str(cif.resolve()),
            "project": str(project_path),
            "status": "error",
            "error": repr(exc),
        }
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("cifs", nargs="+", type=Path)
    parser.add_argument("--outdir", type=Path, default=Path("secondary_scale"))
    parser.add_argument("--baseline", type=Path, default=BASELINE)
    args = parser.parse_args()
    args.outdir.mkdir(exist_ok=True)
    rows = []
    for cif in args.cifs:
        print("SCALE", cif, flush=True)
        row = screen(cif, args.outdir, args.baseline)
        rows.append(row)
        print(json.dumps(row), flush=True)
        (args.outdir / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
