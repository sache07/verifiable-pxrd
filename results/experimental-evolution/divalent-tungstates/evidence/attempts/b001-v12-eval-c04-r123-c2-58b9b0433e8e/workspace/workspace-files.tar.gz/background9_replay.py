#!/usr/bin/env python3
"""Prune the marginal tenth Chebyshev term and replay the order-nine model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SOURCE = Path("final_nuisance_challenges/background_10.gpx")
TARGET = Path("accepted_loop/background_9.gpx")


def main() -> None:
    TARGET.parent.mkdir(exist_ok=True)
    project = G2sc.G2Project(str(SOURCE), newgpx=str(TARGET))
    project.set_Frozen()
    background = project.histogram(0).data["Background"][0]
    background[:] = ["chebyschev-1", True, 9, *background[3:12]]
    project.set_Controls("cycles", 20)
    project.save()
    rows = []
    for replay in range(4):
        project.refine()
        hist = project.histogram(0)
        cov = project.data["Covariance"]["data"]
        sigmas = dict(zip(map(str, cov.get("varyList", [])), cov.get("sig", [])))
        rows.append(
            {
                "replay": replay,
                "residuals": hist.residuals,
                "fractions": hist.ComputeMassFracs(),
                "background": hist.data["Background"][0],
                "background_sigmas": [sigmas.get(f":0:Back;{i}") for i in range(9)],
                "rvals": cov.get("Rvals", {}),
                "frozen": project.get_Frozen(),
            }
        )
        print(json.dumps(rows[-1]), flush=True)
        if project.get_Frozen():
            break
    project.save()
    (TARGET.parent / "background_9.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
