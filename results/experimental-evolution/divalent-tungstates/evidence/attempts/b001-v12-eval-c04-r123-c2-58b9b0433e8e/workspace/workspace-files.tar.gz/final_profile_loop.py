#!/usr/bin/env python3
"""Repeat neutral/size/strain profile comparisons after structural refinement."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("joint_texture_trials/replay.gpx")
OUT = Path("final_profile_loop")
SPECS = [
    (0, "neutral"), (0, "size"), (0, "strain"), (0, "size_strain"),
    (1, "neutral"), (1, "size"), (1, "strain"), (1, "size_strain"),
    (1, "uni100"), (1, "uni010"), (1, "uni001"), (1, "uni100_strain"),
    (2, "neutral"), (2, "size"), (2, "strain"), (2, "size_strain"),
]


def neutralize(hap: dict) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False] * len(hap["Size"][2])
    hap["Size"][4][:] = [10.0, 10.0, 10.0, 0.0, 0.0, 0.0]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])


def run(phase_index: int, mode: str) -> dict:
    path = OUT / f"phase{phase_index}_{mode}.gpx"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(path))
    project.set_Frozen()
    hist = project.histogram(0)
    hap = project.phase(phase_index).data["Histograms"][hist.name]
    neutralize(hap)
    if mode in ("size", "size_strain"):
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
    if mode in ("strain", "size_strain"):
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2][0] = True
    if mode.startswith("uni"):
        axis = {
            "uni100": (1, 0, 0), "uni010": (0, 1, 0), "uni001": (0, 0, 1),
            "uni100_strain": (1, 0, 0),
        }[mode]
        hap["Size"][0] = "uniaxial"
        hap["Size"][1][:] = [0.12, 0.05, 1.0]
        hap["Size"][2][:] = [True, True, False]
        hap["Size"][3][:] = list(axis)
        if mode.endswith("strain"):
            hap["Mustrain"][1][0] = 500.0
            hap["Mustrain"][2][0] = True
    project.set_Controls("cycles", 20)
    for name in ("Size;i", "Size;a"):
        project.set_Controls("parmMin", 0.01, variable=f"{phase_index}:0:{name}")
        project.set_Controls("parmMax", 1000.0, variable=f"{phase_index}:0:{name}")
    project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;i")
    project.set_Controls("parmMax", 10000.0, variable=f"{phase_index}:0:Mustrain;i")
    project.save()
    replays = []
    for replay in range(2):
        project.refine()
        hist = project.histogram(0)
        hap = project.phase(phase_index).data["Histograms"][hist.name]
        replays.append(
            {
                "replay": replay,
                "wR": hist.residuals.get("wR"),
                "fractions": hist.ComputeMassFracs(),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "frozen": project.get_Frozen(),
            }
        )
        if project.get_Frozen():
            break
    project.save()
    return {"phase": phase_index, "mode": mode, "project": str(path), "replays": replays}


def main() -> None:
    OUT.mkdir(exist_ok=True)
    rows = []
    for spec in SPECS:
        row = run(*spec)
        rows.append(row)
        print(json.dumps({"phase": row["phase"], "mode": row["mode"], **row["replays"][-1]}), flush=True)
        (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
