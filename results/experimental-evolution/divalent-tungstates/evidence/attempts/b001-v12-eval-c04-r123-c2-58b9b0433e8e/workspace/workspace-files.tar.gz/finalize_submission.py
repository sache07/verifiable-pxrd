#!/usr/bin/env python3
"""Replay the accepted full-range model and write internally consistent outputs."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("accepted_loop/main_source_cross_seed/zn_1520641.gpx")
PROJECT_PATH = Path("final.gpx")
CIF_PATHS = [Path("phase_MnWO4.cif"), Path("phase_WO3.cif"), Path("phase_Mn3O4.cif")]
PHASE_INFO = [
    ("MnWO4 (wolframite)", "MnWO4"),
    ("WO3 (monoclinic)", "WO3"),
    ("Mn3O4 (hausmannite)", "Mn3O4"),
]


def neutral_profile(hap: dict) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]


def configure(project: G2sc.G2Project) -> None:
    """Make every retained and inactive term explicit before the final replay."""
    project.set_Frozen()
    project.set_Controls("cycles", 20)
    hist = project.histogram(0)
    hist.data["Limits"][1][:] = hist.data["Limits"][0]

    background = hist.data["Background"][0]
    if background[0] != "chebyschev-1" or background[2] != 11:
        raise RuntimeError("Final baseline does not contain the selected 11-term background")
    background[1] = True

    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "Y", "Z"):
        inst[key][1], inst[key][2] = 0.0, False
    inst["W"][2] = True
    inst["X"][2] = True
    inst["Zero"][1], inst["Zero"][2] = 0.0, False
    inst["Polariz."][1], inst["Polariz."][2] = 0.5, False
    inst["SH/L"][1], inst["SH/L"][2] = 0.002, False

    sample = hist.data["Sample Parameters"]
    sample["Shift"][1] = True
    sample["SurfRoughA"][1] = True
    sample["SurfRoughB"][1] = True
    for key in ("Absorption", "DisplaceX", "DisplaceY", "Transparency"):
        sample[key][1] = False

    phases = project.phases()
    for phase in phases:
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][0], hap["Extinction"][1] = 0.0, False
        hap["Pref.Ori."][0] = "MD"

    # Dominant wolframite: neutral size/strain/texture; all independent
    # coordinates were source-cross-seeded and remain refined.
    hap0 = phases[0].data["Histograms"][hist.name]
    neutral_profile(hap0)
    hap0["Pref.Ori."][1:4] = [1.0, False, [0, 0, 1]]
    phases[0].set_refinements({"Atoms": {"all": "X"}})

    # WO3: uniaxial coherent-domain term and one low-index MD correction.
    hap1 = phases[1].data["Histograms"][hist.name]
    hap1["Size"][0] = "uniaxial"
    hap1["Size"][2][:] = [True, True, False]
    hap1["Size"][3][:] = [0, 0, 1]
    hap1["Mustrain"][0] = "isotropic"
    hap1["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap1["Mustrain"][2][:] = [False, False, False]
    hap1["Pref.Ori."][1:4] = [hap1["Pref.Ori."][1], True, [1, 0, 1]]
    phases[1].set_refinements({"Atoms": {"all": ""}})
    phases[1].set_refinements({"Atoms": {"W1": "X", "W2": "X"}})

    # Residual Mn3O4: neutral size, isotropic strain, and replay-stable [110]
    # MD correction. No atomic coordinates are released for this weak phase.
    hap2 = phases[2].data["Histograms"][hist.name]
    neutral_profile(hap2)
    hap2["Mustrain"][1][0] = 10029.0
    hap2["Mustrain"][2][0] = True
    hap2["Pref.Ori."][1:4] = [hap2["Pref.Ori."][1], True, [1, 1, 0]]
    phases[2].set_refinements({"Atoms": {"all": ""}})


def write_fit(hist: G2sc.G2PwdrData) -> int:
    profile = hist.data["data"][1]
    two_theta = np.asarray(profile[0], dtype=float)
    observed = np.asarray(profile[1], dtype=float)
    calculated = np.asarray(profile[3], dtype=float)
    difference = observed - calculated
    with Path("fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
        writer.writerows(
            zip(
                (f"{value:.8f}" for value in two_theta),
                (f"{value:.8f}" for value in observed),
                (f"{value:.8f}" for value in calculated),
                (f"{value:.8f}" for value in difference),
            )
        )
    return len(two_theta)


def main() -> None:
    project = G2sc.G2Project(str(BASELINE), newgpx=str(PROJECT_PATH))
    configure(project)
    project.save()

    replay_log = []
    for replay in range(4):
        project.refine()
        hist = project.histogram(0)
        covariance = project.data["Covariance"]["data"]
        rvals = covariance.get("Rvals", {})
        replay_log.append(
            {
                "replay": replay,
                "r_wp_percent": hist.residuals.get("wR"),
                "weight_fractions": hist.ComputeMassFracs(),
                "max_shift_over_sigma": rvals.get("Max shft/sig"),
                "converged": rvals.get("converged"),
                "svd_zero_count": rvals.get("SVD0"),
                "frozen": project.get_Frozen(),
            }
        )
        if project.get_Frozen():
            raise RuntimeError(f"Final replay froze variables: {project.get_Frozen()}")

    project.save()
    hist = project.histogram(0)
    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    if not rvals.get("converged") or rvals.get("SVD0") != 0:
        raise RuntimeError(f"Final replay did not converge cleanly: {rvals}")
    if rvals.get("Max shft/sig", 1.0) > 0.1:
        raise RuntimeError(f"Final replay remains displaced: {rvals['Max shft/sig']}")

    for phase, cif_path in zip(project.phases(), CIF_PATHS):
        phase.export_CIF(str(cif_path))
    n_points = write_fit(hist)

    raw_fractions = hist.ComputeMassFracs()
    ordered = [raw_fractions[phase.name] for phase in project.phases()]
    total = sum(value[0] for value in ordered)
    fractions = [value[0] / total for value in ordered]
    fractions[-1] = 1.0 - sum(fractions[:-1])

    phase_rows = []
    for index, (phase, cif_path, info, fraction, raw) in enumerate(
        zip(project.phases(), CIF_PATHS, PHASE_INFO, fractions, ordered)
    ):
        cell = phase.data["General"]["Cell"]
        phase_rows.append(
            {
                "name": info[0],
                "formula": info[1],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": str(cif_path),
                "project_path": str(PROJECT_PATH),
                "weight_fraction": fraction,
                "weight_fraction_formal_esd": raw[1] / total,
                "cell": {
                    "a_A": cell[1],
                    "b_A": cell[2],
                    "c_A": cell[3],
                    "alpha_deg": cell[4],
                    "beta_deg": cell[5],
                    "gamma_deg": cell[6],
                    "volume_A3": cell[7],
                },
            }
        )

    fit_statistics = {
        "r_wp_percent": hist.residuals["wR"],
        "r_p_percent": hist.residuals["R"],
        "r_exp_percent": hist.residuals["wRmin"],
        "goodness_of_fit": rvals["GOF"],
        "chi_square": rvals["chisq"],
        "reduced_chi_square": rvals["GOF"] ** 2,
        "n_observations": rvals["Nobs"],
        "n_variables": rvals["Nvars"],
        "max_shift_over_sigma": rvals["Max shft/sig"],
    }
    result = {
        "project_path": str(PROJECT_PATH),
        "fit_profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "phases": phase_rows,
        "fit_statistics": fit_statistics,
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")
    Path("final_replay.json").write_text(
        json.dumps(
            {
                "baseline": str(BASELINE),
                "replays": replay_log,
                "fit_statistics": fit_statistics,
                "profile_points": n_points,
            },
            indent=2,
        )
        + "\n"
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
