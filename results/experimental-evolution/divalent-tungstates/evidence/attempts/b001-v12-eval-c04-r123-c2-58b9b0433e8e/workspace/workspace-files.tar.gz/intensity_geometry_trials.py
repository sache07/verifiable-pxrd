#!/usr/bin/env python3
"""Reversible polarization and surface-roughness challenges from one checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("intensity_trials/background_6.gpx")
OUT = Path("intensity_geometry_trials")


def run(tag: str, polarization: bool, rough_seed: tuple[float, float] | None) -> dict:
    path = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(path))
    project.set_Frozen()
    histogram = project.histogram(0)
    inst = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]

    inst["Polariz."][1] = 0.5
    inst["Polariz."][2] = polarization
    sample["SurfRoughA"][:] = [0.0, False]
    sample["SurfRoughB"][:] = [0.0, False]
    if rough_seed is not None:
        sample["SurfRoughA"][:] = [rough_seed[0], True]
        sample["SurfRoughB"][:] = [rough_seed[1], True]

    project.set_Controls("cycles", 15)
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 5.0, variable=":0:SurfRoughB")
    project.save()

    replays = []
    for replay in range(2):
        project.refine()
        histogram = project.histogram(0)
        cov = project.data["Covariance"]["data"]
        vary = [str(v) for v in cov.get("varyList", [])]
        sigmas = [float(v) for v in cov.get("sig", [])]
        sig = dict(zip(vary, sigmas))
        sample = histogram.data["Sample Parameters"]
        inst = histogram.data["Instrument Parameters"][0]
        replays.append(
            {
                "replay": replay,
                "residuals": histogram.residuals,
                "mass_fractions": histogram.ComputeMassFracs(),
                "polarization": inst["Polariz."],
                "roughness_a": sample["SurfRoughA"],
                "roughness_b": sample["SurfRoughB"],
                "sigmas": {
                    k: v
                    for k, v in sig.items()
                    if any(name in k for name in ("Polariz.", "SurfRough"))
                },
                "frozen": project.get_Frozen(),
            }
        )
        if project.get_Frozen():
            break
    project.save()
    return {
        "tag": tag,
        "project": str(path),
        "polarization_refined": polarization,
        "rough_seed": rough_seed,
        "replays": replays,
    }


def main() -> None:
    OUT.mkdir(exist_ok=True)
    specs = [
        ("neutral", False, None),
        ("polarization", True, None),
        ("rough_050_005", False, (0.5, 0.05)),
        ("rough_020_020", False, (0.2, 0.2)),
        ("rough_080_005", False, (0.8, 0.05)),
        ("polar_rough_050_005", True, (0.5, 0.05)),
    ]
    rows = []
    for spec in specs:
        row = run(*spec)
        rows.append(row)
        last = row["replays"][-1]
        print(
            json.dumps(
                {
                    "tag": row["tag"],
                    "wR": last["residuals"].get("wR"),
                    "fractions": last["mass_fractions"],
                    "polarization": last["polarization"],
                    "roughness_a": last["roughness_a"],
                    "roughness_b": last["roughness_b"],
                    "sigmas": last["sigmas"],
                    "frozen": last["frozen"],
                }
            ),
            flush=True,
        )
        (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
