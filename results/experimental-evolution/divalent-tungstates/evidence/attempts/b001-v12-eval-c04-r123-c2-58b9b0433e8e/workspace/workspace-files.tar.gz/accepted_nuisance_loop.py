#!/usr/bin/env python3
"""Final intensity, geometry and texture replay from the accepted physical model."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("accepted_loop/physical/selected_replay.gpx")
OUT = Path("accepted_loop/nuisance")


def unchanged(project: G2sc.G2Project) -> None:
    del project


def roughness(mode: str) -> Callable[[G2sc.G2Project], None]:
    def configure(project: G2sc.G2Project) -> None:
        hist = project.histogram(0)
        sample = hist.data["Sample Parameters"]
        inst = hist.data["Instrument Parameters"][0]
        inst["Polariz."][1:] = [0.5, False]
        if mode == "neutral":
            sample["SurfRoughA"][:] = [0.0, False]
            sample["SurfRoughB"][:] = [0.0, False]
        elif mode == "replay":
            sample["SurfRoughA"][1] = True
            sample["SurfRoughB"][1] = True
        elif mode == "fixed_plus_polar":
            sample["SurfRoughA"][1] = False
            sample["SurfRoughB"][1] = False
            inst["Polariz."][2] = True
        elif mode == "rough_plus_polar":
            sample["SurfRoughA"][1] = True
            sample["SurfRoughB"][1] = True
            inst["Polariz."][2] = True
        else:
            raise ValueError(mode)
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 5.0, variable=":0:SurfRoughB")

    return configure


def texture(
    phase_index: int, axis: tuple[int, int, int] | None
) -> Callable[[G2sc.G2Project], None]:
    def configure(project: G2sc.G2Project) -> None:
        hist = project.histogram(0)
        po = project.phase(phase_index).data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        if axis is None:
            po[1], po[2] = 1.0, False
        else:
            po[1], po[2], po[3] = 1.0, True, list(axis)
            project.set_Controls("parmMin", 0.2, variable=f"{phase_index}:0:MD")
            project.set_Controls("parmMax", 5.0, variable=f"{phase_index}:0:MD")

    return configure


def axis_tag(axis: tuple[int, int, int]) -> str:
    return "_".join(f"m{-v}" if v < 0 else str(v) for v in axis)


def run(tag: str, configure: Callable[[G2sc.G2Project], None]) -> dict:
    target = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(target))
    project.set_Frozen()
    configure(project)
    project.set_Controls("cycles", 20)
    project.save()
    replays = []
    for replay in range(4):
        project.refine()
        hist = project.histogram(0)
        inst = hist.data["Instrument Parameters"][0]
        sample = hist.data["Sample Parameters"]
        cov = project.data["Covariance"]["data"]
        replays.append(
            {
                "replay": replay,
                "residuals": hist.residuals,
                "fractions": hist.ComputeMassFracs(),
                "polarization": inst["Polariz."],
                "roughness_a": sample["SurfRoughA"],
                "roughness_b": sample["SurfRoughB"],
                "march": [
                    phase.data["Histograms"][hist.name]["Pref.Ori."]
                    for phase in project.phases()
                ],
                "rvals": cov.get("Rvals", {}),
                "frozen": project.get_Frozen(),
            }
        )
        if project.get_Frozen():
            break
    project.save()
    return {"tag": tag, "project": str(target), "replays": replays}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    specs: list[tuple[str, Callable[[G2sc.G2Project], None]]] = [
        ("selected_replay", unchanged),
        ("roughness_neutral", roughness("neutral")),
        ("roughness_replay", roughness("replay")),
        ("roughness_fixed_plus_polar", roughness("fixed_plus_polar")),
        ("roughness_plus_polar", roughness("rough_plus_polar")),
        ("wo3_texture_neutral", texture(1, None)),
    ]
    for phase_index, axes in (
        (0, ((1, 1, 1), (1, 1, -1), (1, 0, -1))),
        (1, ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 0, 1), (1, 1, 1))),
        (2, ((1, 1, 0), (0, 0, 1))),
    ):
        for axis in axes:
            specs.append(
                (f"phase{phase_index}_texture_{axis_tag(axis)}", texture(phase_index, axis))
            )

    rows = []
    for tag, configure in specs:
        row = run(tag, configure)
        rows.append(row)
        last = row["replays"][-1]
        print(
            json.dumps(
                {
                    "tag": tag,
                    "wR": last["residuals"].get("wR"),
                    "fractions": last["fractions"],
                    "polarization": last["polarization"],
                    "roughness": [last["roughness_a"], last["roughness_b"]],
                    "march": [entry[1:4] for entry in last["march"]],
                    "max_shift_over_sigma": last["rvals"].get("Max shft/sig"),
                    "frozen": last["frozen"],
                }
            ),
            flush=True,
        )
        (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
