#!/usr/bin/env python3
"""Run identical neutral GSAS-II screens for structural source candidates."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def neutralize_hap(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Size"] = [
        "isotropic",
        [100.0, 100.0, 1.0],
        [False, False, False],
        [0, 0, 1],
        [100.0, 100.0, 100.0, 0.0, 0.0, 0.0],
        [False] * 6,
    ]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Scale"][:] = [1.0, True]


def snapshot(project, histogram, phase, stage: str) -> dict:
    inst = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]
    hap = phase.data["Histograms"][histogram.name]
    return {
        "stage": stage,
        "residuals": histogram.residuals,
        "cell": phase.get_cell(),
        "phase_scale": hap["Scale"][0],
        "shift_micrometres": sample["Shift"][0],
        "profile": {key: inst[key][1] for key in ("U", "V", "W", "X", "Y", "SH/L")},
        "background": histogram.data["Background"][0][3:],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "frozen": project.get_Frozen(),
    }


def fit_candidate(cif: Path, outdir: Path) -> dict:
    label = cif.stem
    gpx = outdir / f"{label}.gpx"
    project = G2sc.G2Project(newgpx=str(gpx))
    histogram = project.add_powder_histogram("inputs/pattern.csv", "instrument.instprm")
    phase = project.add_phase(
        str(cif), phasename=label, histograms=[histogram], fmthint="CIF"
    )

    # Common profile checkpoint: neutral phase broadening/texture, one angular
    # correction, nonnegative low-dimensional instrument broadening.
    neutralize_hap(phase, histogram.name)
    histogram.data["Sample Parameters"]["Scale"][:] = [1.0, False]
    histogram.data["Sample Parameters"]["Shift"][:] = [430.0, False]
    histogram.data["Sample Parameters"]["Transparency"][:] = [0.0, False]
    histogram.data["Sample Parameters"]["SurfRoughA"][:] = [0.0, False]
    histogram.data["Sample Parameters"]["SurfRoughB"][:] = [0.0, False]
    histogram.data["Background"][0] = [
        "chebyschev-1", True, 6, 1900.0, -900.0, 0.0, 0.0, 0.0, 0.0
    ]
    inst = histogram.data["Instrument Parameters"][0]
    for key, value in {
        "U": 10.0,
        "V": 0.0,
        "W": 25.0,
        "X": 0.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }.items():
        inst[key][1] = value
        inst[key][2] = False

    project.set_Controls("cycles", 6)
    for variable in (":0:U", ":0:W", ":0:X"):
        project.set_Controls("parmMin", 0.0, variable=variable)
    project.set_Controls("parmMax", 1000.0, variable=":0:U")
    project.set_Controls("parmMax", 1000.0, variable=":0:W")
    project.set_Controls("parmMax", 20.0, variable=":0:X")
    project.set_Controls("parmMin", 0.0, variable="0:0:Scale")
    project.set_Controls("parmMax", 1.0e8, variable="0:0:Scale")
    project.set_Controls("parmMin", -2000.0, variable=":0:Shift")
    project.set_Controls("parmMax", 2000.0, variable=":0:Shift")
    project.save()

    stages = []
    try:
        project.refine()
        histogram, phase = project.histogram(0), project.phase(0)
        stages.append(snapshot(project, histogram, phase, "background_scale"))

        histogram.data["Sample Parameters"]["Shift"][1] = True
        project.refine()
        histogram, phase = project.histogram(0), project.phase(0)
        stages.append(snapshot(project, histogram, phase, "shift"))

        phase.set_refinements({"Cell": True})
        project.refine()
        histogram, phase = project.histogram(0), project.phase(0)
        stages.append(snapshot(project, histogram, phase, "cell"))

        histogram.set_refinements({"Instrument Parameters": ["W"]})
        project.refine()
        histogram, phase = project.histogram(0), project.phase(0)
        stages.append(snapshot(project, histogram, phase, "W"))

        histogram.set_refinements({"Instrument Parameters": ["U", "X"]})
        project.refine()
        histogram, phase = project.histogram(0), project.phase(0)
        stages.append(snapshot(project, histogram, phase, "U_W_X"))
        project.save()
        status = "ok"
        error = None
    except Exception as exc:
        status = "error"
        error = repr(exc)
        project.save()

    final = stages[-1] if stages else None
    return {
        "candidate": str(cif),
        "project": str(gpx),
        "status": status,
        "error": error,
        "stages": stages,
        "final": final,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("cifs", nargs="+", type=Path)
    parser.add_argument("--outdir", type=Path, default=Path("screen"))
    args = parser.parse_args()
    args.outdir.mkdir(exist_ok=True)
    results = []
    for cif in args.cifs:
        print(f"SCREEN {cif}", flush=True)
        result = fit_candidate(cif.resolve(), args.outdir.resolve())
        results.append(result)
        if result["final"]:
            print(
                json.dumps(
                    {
                        "candidate": str(cif),
                        "status": result["status"],
                        "wR": result["final"]["residuals"].get("wR"),
                        "scale": result["final"]["phase_scale"],
                        "cell": result["final"]["cell"],
                        "shift": result["final"]["shift_micrometres"],
                        "profile": result["final"]["profile"],
                        "frozen": result["final"]["frozen"],
                    }
                ),
                flush=True,
            )
        else:
            print(json.dumps({"candidate": str(cif), "error": result["error"]}), flush=True)
        (args.outdir / "screen_results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
