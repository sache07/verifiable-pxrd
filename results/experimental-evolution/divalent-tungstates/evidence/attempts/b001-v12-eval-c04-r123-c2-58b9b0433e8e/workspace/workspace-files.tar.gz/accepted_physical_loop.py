#!/usr/bin/env python3
"""Repeat the complete phase-profile loop after accepting background order 11."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("accepted_loop/background_cross_seed/background_11.gpx")
OUT = Path("accepted_loop/physical")


def neutralize(hap: dict) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]


def profile(
    phase_index: int,
    size: str = "neutral",
    strain: bool = False,
    axis: tuple[int, int, int] = (0, 0, 1),
) -> Callable[[G2sc.G2Project], None]:
    def configure(project: G2sc.G2Project) -> None:
        hist = project.histogram(0)
        hap = project.phase(phase_index).data["Histograms"][hist.name]
        neutralize(hap)
        if size == "iso":
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 0.075 if phase_index == 1 else 1.0
            hap["Size"][2][0] = True
        elif size == "weak_iso":
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 0.055
            hap["Size"][2][0] = True
        elif size == "uniaxial":
            hap["Size"][0] = "uniaxial"
            hap["Size"][1][:] = [0.063, 0.119, 1.0]
            hap["Size"][2][:] = [True, True, False]
            hap["Size"][3][:] = list(axis)
        elif size != "neutral":
            raise ValueError(size)
        if strain:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 9000.0 if phase_index == 2 else 500.0
            hap["Mustrain"][2][0] = True

        for suffix in ("Size;i", "Size;a"):
            project.set_Controls("parmMin", 0.01, variable=f"{phase_index}:0:{suffix}")
            project.set_Controls("parmMax", 1000.0, variable=f"{phase_index}:0:{suffix}")
        project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;i")
        project.set_Controls("parmMax", 20000.0, variable=f"{phase_index}:0:Mustrain;i")

    return configure


def unchanged(project: G2sc.G2Project) -> None:
    del project


def run(tag: str, configure: Callable[[G2sc.G2Project], None]) -> dict:
    target = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(target))
    project.set_Frozen()
    configure(project)
    project.set_Controls("cycles", 20)
    project.save()
    replays = []
    for replay in range(4):
        project.refine()
        hist = project.histogram(0)
        cov = project.data["Covariance"]["data"]
        replays.append(
            {
                "replay": replay,
                "residuals": hist.residuals,
                "fractions": hist.ComputeMassFracs(),
                "profiles": [
                    {
                        "size": phase.data["Histograms"][hist.name]["Size"],
                        "strain": phase.data["Histograms"][hist.name]["Mustrain"],
                    }
                    for phase in project.phases()
                ],
                "rvals": cov.get("Rvals", {}),
                "frozen": project.get_Frozen(),
            }
        )
        if project.get_Frozen():
            break
    project.save()
    return {"tag": tag, "project": str(target), "replays": replays}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    specs: list[tuple[str, Callable[[G2sc.G2Project], None]]] = [
        ("selected_replay", unchanged),
        ("mnwo4_neutral", profile(0)),
        ("mnwo4_size", profile(0, size="iso")),
        ("mnwo4_strain", profile(0, strain=True)),
        ("mnwo4_size_strain", profile(0, size="iso", strain=True)),
        ("wo3_neutral", profile(1)),
        ("wo3_isotropic", profile(1, size="iso")),
        ("wo3_uniaxial_100", profile(1, size="uniaxial", axis=(1, 0, 0))),
        ("wo3_uniaxial_010", profile(1, size="uniaxial", axis=(0, 1, 0))),
        ("wo3_uniaxial_001", profile(1, size="uniaxial", axis=(0, 0, 1))),
        ("wo3_uniaxial_001_strain", profile(1, size="uniaxial", strain=True, axis=(0, 0, 1))),
        ("mn3o4_neutral", profile(2)),
        ("mn3o4_size", profile(2, size="weak_iso")),
        ("mn3o4_strain", profile(2, strain=True)),
        ("mn3o4_size_strain", profile(2, size="weak_iso", strain=True)),
    ]
    rows = []
    for tag, configure in specs:
        row = run(tag, configure)
        rows.append(row)
        last = row["replays"][-1]
        print(
            json.dumps(
                {
                    "tag": tag,
                    "wR": last["residuals"].get("wR"),
                    "fractions": last["fractions"],
                    "profiles": last["profiles"],
                    "max_shift_over_sigma": last["rvals"].get("Max shft/sig"),
                    "frozen": last["frozen"],
                }
            ),
            flush=True,
        )
        (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
