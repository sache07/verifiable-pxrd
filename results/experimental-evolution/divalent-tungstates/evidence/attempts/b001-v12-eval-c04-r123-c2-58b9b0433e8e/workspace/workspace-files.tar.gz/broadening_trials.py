#!/usr/bin/env python3
"""Reversible neutral/size/strain broadening challenges from one checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("checkpoints/mg_wx.gpx")
OUT = Path("broadening")


def configure(project, mode: str):
    histogram = project.histogram(0)
    phase = project.phase(0)
    hap = phase.data["Histograms"][histogram.name]

    # Restore complete neutral values and flags before each challenge.
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [100.0, 100.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][4][:] = [100.0, 100.0, 100.0, 0.0, 0.0, 0.0]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False

    if mode in ("size", "size_strain"):
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
    if mode in ("strain", "size_strain"):
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2][0] = True

    inst = histogram.data["Instrument Parameters"][0]
    inst["U"][1] = 0.0
    inst["U"][2] = False
    inst["W"][2] = True
    inst["X"][2] = True
    histogram.data["Sample Parameters"]["Shift"][1] = True

    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.set_Controls("parmMin", 0.01, variable="0:0:Size;i")
    project.set_Controls("parmMax", 1000.0, variable="0:0:Size;i")
    project.set_Controls("parmMin", 0.0, variable="0:0:Mustrain;i")
    project.set_Controls("parmMax", 10000.0, variable="0:0:Mustrain;i")
    return histogram, phase


def run(mode: str) -> dict:
    output = OUT / f"{mode}.gpx"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(output))
    histogram, phase = configure(project, mode)
    project.save()
    replays = []
    for replay in range(2):
        project.refine()
        histogram, phase = project.histogram(0), project.phase(0)
        hap = phase.data["Histograms"][histogram.name]
        replays.append(
            {
                "replay": replay,
                "residuals": histogram.residuals,
                "cell": phase.get_cell(),
                "shift": histogram.data["Sample Parameters"]["Shift"][0],
                "profile": {
                    key: histogram.data["Instrument Parameters"][0][key][1]
                    for key in ("U", "W", "X")
                },
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "scale": hap["Scale"][0],
                "frozen": project.get_Frozen(),
                "vary_list": [str(value) for value in project.data["Covariance"]["data"].get("varyList", [])],
                "sigmas": [float(value) for value in project.data["Covariance"]["data"].get("sig", [])],
            }
        )
        if project.get_Frozen():
            break
    project.save()
    return {"mode": mode, "project": str(output), "replays": replays}


def main() -> None:
    OUT.mkdir(exist_ok=True)
    rows = []
    for mode in ("neutral", "size", "strain", "size_strain"):
        print("TRIAL", mode, flush=True)
        row = run(mode)
        rows.append(row)
        last = row["replays"][-1]
        print(
            json.dumps(
                {
                    "mode": mode,
                    "wR": last["residuals"].get("wR"),
                    "size": last["size"],
                    "mustrain": last["mustrain"],
                    "profile": last["profile"],
                    "frozen": last["frozen"],
                }
            ),
            flush=True,
        )
        (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
