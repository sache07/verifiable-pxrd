#!/usr/bin/env python3
"""Cross-seed adjacent background orders from the replayed order-nine checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("accepted_loop/background_9.gpx")
OUT = Path("accepted_loop/background_cross_seed")


def run(order: int) -> dict:
    target = OUT / f"background_{order}.gpx"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(target))
    project.set_Frozen()
    terms = project.histogram(0).data["Background"][0]
    coeffs = (list(terms[3:]) + [0.0] * order)[:order]
    terms[:] = ["chebyschev-1", True, order, *coeffs]
    project.set_Controls("cycles", 20)
    project.save()
    replays = []
    for replay in range(4):
        project.refine()
        hist = project.histogram(0)
        cov = project.data["Covariance"]["data"]
        sigma = dict(zip(map(str, cov.get("varyList", [])), cov.get("sig", [])))
        replays.append(
            {
                "replay": replay,
                "residuals": hist.residuals,
                "fractions": hist.ComputeMassFracs(),
                "coefficients": hist.data["Background"][0][3:],
                "coefficient_sigmas": [sigma.get(f":0:Back;{i}") for i in range(order)],
                "rvals": cov.get("Rvals", {}),
                "frozen": project.get_Frozen(),
            }
        )
        if project.get_Frozen():
            break
    project.save()
    return {"order": order, "project": str(target), "replays": replays}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for order in (8, 9, 10, 11, 12):
        row = run(order)
        rows.append(row)
        last = row["replays"][-1]
        print(
            json.dumps(
                {
                    "order": order,
                    "wR": last["residuals"].get("wR"),
                    "fractions": last["fractions"],
                    "coefficients": last["coefficients"],
                    "sigmas": last["coefficient_sigmas"],
                    "max_shift_over_sigma": last["rvals"].get("Max shft/sig"),
                    "frozen": last["frozen"],
                }
            ),
            flush=True,
        )
        (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
