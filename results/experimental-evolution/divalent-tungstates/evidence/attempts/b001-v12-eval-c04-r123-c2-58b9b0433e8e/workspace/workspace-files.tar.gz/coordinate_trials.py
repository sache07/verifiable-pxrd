#!/usr/bin/env python3
"""Reversible coordinate challenges before accepting preferred orientation."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("polarization_cross_trials/rough_replay.gpx")
OUT = Path("coordinate_trials")


SPECS = [
    ("mnwo4_cations", 0, ["Mn0", "W1"]),
    ("mnwo4_oxygen", 0, ["O2", "O3"]),
    ("mnwo4_all", 0, ["Mn0", "W1", "O2", "O3"]),
    ("wo3_w", 1, ["W1", "W2"]),
    ("wo3_o", 1, ["O1", "O2", "O3", "O4", "O5", "O6"]),
    ("wo3_all", 1, ["W1", "W2", "O1", "O2", "O3", "O4", "O5", "O6"]),
    ("mn3o4_o", 2, ["O"]),
]


def run(tag: str, phase_index: int, labels: list[str]) -> dict:
    path = OUT / f"{tag}.gpx"
    cif_path = OUT / f"{tag}.cif"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(path))
    project.set_Frozen()
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": ""}})
    selected = project.phase(phase_index)
    selected.set_refinements({"Atoms": {label: "X" for label in labels}})
    project.set_Controls("cycles", 20)
    project.save()
    replays = []
    for replay in range(2):
        project.refine()
        hist = project.histogram(0)
        replays.append(
            {
                "replay": replay,
                "residuals": hist.residuals,
                "fractions": hist.ComputeMassFracs(),
                "frozen": project.get_Frozen(),
                "atoms": [list(atom) for atom in selected.data["Atoms"]],
            }
        )
        if project.get_Frozen():
            break
    project.save()
    selected.export_CIF(str(cif_path))
    return {
        "tag": tag,
        "phase_index": phase_index,
        "phase_name": selected.name,
        "labels": labels,
        "project": str(path),
        "cif": str(cif_path),
        "replays": replays,
    }


def main() -> None:
    OUT.mkdir(exist_ok=True)
    rows = []
    for spec in SPECS:
        row = run(*spec)
        rows.append(row)
        last = row["replays"][-1]
        print(
            json.dumps(
                {
                    "tag": row["tag"],
                    "wR": last["residuals"].get("wR"),
                    "fractions": last["fractions"],
                    "frozen": last["frozen"],
                }
            ),
            flush=True,
        )
        (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
