#!/usr/bin/env python3
"""Build chemically adapted Mn-W-O candidate CIFs from screened analogues."""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(
    "<RUN>/"
    "resources/b001-c04/cif"
)
OUT = Path("candidates")

# A literature-scale wolframite MnWO4 cell. The diffraction refinement, not
# this seed, determines the final cell. Sharing it makes coordinate-parent
# comparisons independent of the parents' different lattice constants.
WOLFRAMITE_CELL = Lattice.monoclinic(4.8290, 5.7580, 4.9960, 91.0800)

SOURCES = [
    ("Fe9008124", ROOT / "9/00/81/9008124.cif", {"Fe": "Mn"}, WOLFRAMITE_CELL),
    ("Fe1567215", ROOT / "1/56/72/1567215.cif", {"Fe": "Mn"}, WOLFRAMITE_CELL),
    ("Fe1568792", ROOT / "1/56/87/1568792.cif", {"Fe": "Mn"}, WOLFRAMITE_CELL),
    ("Zn1520641", ROOT / "1/52/06/1520641.cif", {"Zn": "Mn"}, WOLFRAMITE_CELL),
    ("Mg9013902", ROOT / "9/01/39/9013902.cif", {"Mg": "Mn"}, WOLFRAMITE_CELL),
    ("Cd1520645", ROOT / "1/52/06/1520645.cif", {"Cd": "Mn"}, WOLFRAMITE_CELL),
    ("Cu4000807_P2c", ROOT / "4/00/08/4000807.cif", {"Cu": "Mn"}, WOLFRAMITE_CELL),
    ("Cu4000806_P1bar", ROOT / "4/00/08/4000806.cif", {"Cu": "Mn"}, None),
    ("MnMo1527061_C2m", ROOT / "1/52/70/1527061.cif", {"Mo": "W"}, None),
    ("Ca7219229_scheelite", ROOT / "7/21/92/7219229.cif", {"Ca": "Mn"}, None),
    ("Ca1546035_C2c", ROOT / "1/54/60/1546035.cif", {"Ca": "Mn"}, None),
]


def adapted_structure(source: Path, replacements: dict[str, str], lattice: Lattice | None) -> Structure:
    structure = Structure.from_file(source)
    structure.replace_species(replacements)
    if lattice is not None:
        structure = Structure(
            lattice,
            structure.species,
            structure.frac_coords,
            coords_are_cartesian=False,
        )
    return structure


def main() -> None:
    OUT.mkdir(exist_ok=True)
    manifest = []
    for label, source, replacements, lattice in SOURCES:
        structure = adapted_structure(source, replacements, lattice)
        destination = OUT / f"MnWO4_from_{label}.cif"
        CifWriter(structure, symprec=0.01, refine_struct=False).write_file(destination)
        manifest.append(
            {
                "candidate": str(destination),
                "source": str(source),
                "replacements": replacements,
                "formula": structure.composition.reduced_formula,
                "cell": list(structure.lattice.abc) + list(structure.lattice.angles),
            }
        )
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


if __name__ == "__main__":
    main()
