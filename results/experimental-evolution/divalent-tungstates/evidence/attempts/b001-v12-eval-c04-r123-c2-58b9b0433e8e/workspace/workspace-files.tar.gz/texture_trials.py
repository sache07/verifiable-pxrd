#!/usr/bin/env python3
"""Challenge low-index March-Dollase axes from a common replayed checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("polarization_cross_trials/rough_replay.gpx")
OUT = Path("texture_trials")


AXES = {
    0: [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (1, 0, -1), (0, 1, 1), (1, 1, 1), (1, 1, -1)],
    1: [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (1, 0, -1), (0, 1, 1), (1, 1, 1), (1, 1, -1)],
    2: [(1, 0, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (1, 1, 1)],
}


def axis_tag(axis: tuple[int, int, int]) -> str:
    return "_".join("m" + str(-v) if v < 0 else str(v) for v in axis)


def run(phase_index: int, axis: tuple[int, int, int]) -> dict:
    tag = f"phase{phase_index}_{axis_tag(axis)}"
    path = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(path))
    project.set_Frozen()
    hist = project.histogram(0)
    for phase in project.phases():
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = False
    selected = project.phase(phase_index)
    po = selected.data["Histograms"][hist.name]["Pref.Ori."]
    po[1] = 1.0
    po[2] = True
    po[3][:] = list(axis)
    project.set_Controls("cycles", 15)
    project.set_Controls("parmMin", 0.2, variable=f"{phase_index}:0:MD")
    project.set_Controls("parmMax", 5.0, variable=f"{phase_index}:0:MD")
    project.save()
    replays = []
    for replay in range(2):
        project.refine()
        hist = project.histogram(0)
        po = project.phase(phase_index).data["Histograms"][hist.name]["Pref.Ori."]
        cov = project.data["Covariance"]["data"]
        vary = [str(v) for v in cov.get("varyList", [])]
        sigmas = dict(zip(vary, [float(v) for v in cov.get("sig", [])]))
        replays.append(
            {
                "replay": replay,
                "residuals": hist.residuals,
                "fractions": hist.ComputeMassFracs(),
                "md_ratio": float(po[1]),
                "md_sigma": sigmas.get(f"{phase_index}:0:MD"),
                "frozen": project.get_Frozen(),
            }
        )
        if project.get_Frozen():
            break
    project.save()
    return {
        "phase_index": phase_index,
        "phase_name": selected.name,
        "axis": axis,
        "project": str(path),
        "replays": replays,
    }


def main() -> None:
    OUT.mkdir(exist_ok=True)
    rows = []
    for phase_index, axes in AXES.items():
        for axis in axes:
            row = run(phase_index, axis)
            rows.append(row)
            last = row["replays"][-1]
            print(
                json.dumps(
                    {
                        "phase": row["phase_name"],
                        "index": phase_index,
                        "axis": axis,
                        "wR": last["residuals"].get("wR"),
                        "md": last["md_ratio"],
                        "sigma": last["md_sigma"],
                        "fractions": last["fractions"],
                        "frozen": last["frozen"],
                    }
                ),
                flush=True,
            )
            (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
