#!/usr/bin/env python3
"""Challenge each retained phase with neutral, size, and strain profiles."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("checkpoints/three_phase_neutral.gpx")
OUT = Path("phase_broadening")


def neutralize(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [100.0, 100.0, 1.0]
    hap["Size"][2][:] = [False] * 3
    hap["Size"][4][:] = [100.0, 100.0, 100.0, 0.0, 0.0, 0.0]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False] * 3
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def run(phase_index: int, mode: str) -> dict:
    project_path = OUT / f"phase{phase_index}_{mode}.gpx"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(project_path))
    project.set_Frozen()
    histogram = project.histogram(0)
    for phase in project.phases():
        neutralize(phase, histogram.name)

    selected = project.phase(phase_index)
    hap = selected.data["Histograms"][histogram.name]
    if mode in ("size", "size_strain"):
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
    if mode in ("strain", "size_strain"):
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2][0] = True

    inst = histogram.data["Instrument Parameters"][0]
    inst["U"][1] = 0.0
    inst["U"][2] = False
    inst["W"][2] = True
    inst["X"][2] = True
    histogram.data["Sample Parameters"]["Shift"][1] = True
    project.set_Controls("cycles", 12)
    project.set_Controls("parmMin", 0.01, variable=f"{phase_index}:0:Size;i")
    project.set_Controls("parmMax", 1000.0, variable=f"{phase_index}:0:Size;i")
    project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;i")
    project.set_Controls("parmMax", 10000.0, variable=f"{phase_index}:0:Mustrain;i")
    project.save()

    replays = []
    for replay in range(2):
        project.refine()
        histogram = project.histogram(0)
        selected = project.phase(phase_index)
        hap = selected.data["Histograms"][histogram.name]
        replays.append(
            {
                "replay": replay,
                "residuals": histogram.residuals,
                "mass_fractions": histogram.ComputeMassFracs(),
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "profile": {
                    key: histogram.data["Instrument Parameters"][0][key][1]
                    for key in ("U", "W", "X")
                },
                "shift": histogram.data["Sample Parameters"]["Shift"][0],
                "frozen": project.get_Frozen(),
                "vary_list": [str(item) for item in project.data["Covariance"]["data"].get("varyList", [])],
                "sigmas": [float(item) for item in project.data["Covariance"]["data"].get("sig", [])],
            }
        )
        if project.get_Frozen():
            break
    project.save()
    return {
        "phase_index": phase_index,
        "phase_name": selected.name,
        "mode": mode,
        "project": str(project_path),
        "replays": replays,
    }


def main() -> None:
    OUT.mkdir(exist_ok=True)
    rows = []
    for phase_index in range(3):
        for mode in ("neutral", "size", "strain", "size_strain"):
            print("TRIAL", phase_index, mode, flush=True)
            row = run(phase_index, mode)
            rows.append(row)
            last = row["replays"][-1]
            print(
                json.dumps(
                    {
                        "phase": row["phase_name"],
                        "mode": mode,
                        "wR": last["residuals"].get("wR"),
                        "mass_fractions": last["mass_fractions"],
                        "size": last["size"],
                        "mustrain": last["mustrain"],
                        "profile": last["profile"],
                        "frozen": last["frozen"],
                    }
                ),
                flush=True,
            )
            (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
