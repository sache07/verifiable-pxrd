#!/usr/bin/env python3
"""Cross-seed the accepted MnWO4 model from distinct wolframite parents."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASELINE = Path("accepted_loop/weak_texture/selected_replay.gpx")
OUT = Path("accepted_loop/main_source_cross_seed")

# Site order is Mn, W, O2, O3. All candidates are health-screened P2/c
# wolframite records adapted to MnWO4 with the same conventional setting.
SEEDS = {
    "mg_9013902": [
        (0.5000, 0.32580, 0.7500),
        (0.0000, 0.18190, 0.2500),
        (0.2160, 0.10700, 0.9370),
        (0.2560, 0.37660, 0.3970),
    ],
    "cu_4000807": [
        (0.5000, 0.32990, 0.7500),
        (0.0000, 0.18670, 0.2500),
        (0.2260, 0.10300, 0.9263),
        (0.2530, 0.39700, 0.3852),
    ],
    "zn_1520641": [
        (0.5000, 0.31600, 0.7500),
        (0.0000, 0.18258, 0.2500),
        (0.2169, 0.10510, 0.9363),
        (0.2565, 0.37770, 0.3996),
    ],
}


def run(tag: str, coordinates: list[tuple[float, float, float]]) -> dict:
    target = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(target))
    project.set_Frozen()
    phase = project.phase(0)
    cx = phase.data["General"]["AtomPtrs"][0]
    for atom, xyz in zip(phase.data["Atoms"], coordinates):
        atom[cx : cx + 3] = xyz
    phase.set_refinements({"Atoms": {"all": "X"}})
    project.set_Controls("cycles", 20)
    project.save()

    replays = []
    for replay in range(4):
        project.refine()
        hist = project.histogram(0)
        cov = project.data["Covariance"]["data"]
        atoms = [atom[cx : cx + 3] for atom in phase.data["Atoms"]]
        replays.append(
            {
                "replay": replay,
                "r_wp_percent": hist.residuals.get("wR"),
                "fractions": hist.ComputeMassFracs(),
                "coordinates": atoms,
                "max_shift_over_sigma": cov.get("Rvals", {}).get("Max shft/sig"),
                "frozen": project.get_Frozen(),
            }
        )
        if project.get_Frozen():
            break
    project.save()
    cif = OUT / f"{tag}_MnWO4.cif"
    phase.export_CIF(str(cif))
    return {"tag": tag, "project": str(target), "cif": str(cif), "replays": replays}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for tag, coordinates in SEEDS.items():
        row = run(tag, coordinates)
        rows.append(row)
        print(json.dumps({"tag": tag, **row["replays"][-1]}), flush=True)
        (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
