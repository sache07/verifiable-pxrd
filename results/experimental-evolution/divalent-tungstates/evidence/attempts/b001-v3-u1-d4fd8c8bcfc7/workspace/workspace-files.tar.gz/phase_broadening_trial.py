#!/usr/bin/env python3
"""Challenge one phase with one isotropic broadening mechanism."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import neutralize_hap


def configure(project, selected_name: str, mode: str, seed: bool) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
            }
        }
    )
    for key, value in inst.items():
        if len(value) >= 3:
            value[2] = key in {"W", "X"}
    inst["Zero"][2] = False
    sample["Scale"][1] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = key == "Shift"
    for phase in project.phases():
        phase.set_refinements({"Cell": True, "LeBail": False})
        phase.set_HAP_refinements({"Scale": True}, [hist])
        if phase.name != selected_name:
            neutralize_hap(phase, hist.name)
    selected = project.phase(selected_name)
    hap = selected.data["Histograms"][hist.name]
    if seed:
        neutralize_hap(selected, hist.name)
    if mode == "size":
        # Seed at 1 micron after first neutralizing the inverse-size term.
        hap["Size"][0] = "isotropic"
        if seed:
            hap["Size"][1][:] = [1.0, 1.0e6, 1.0]
        hap["Size"][2][:] = [True, False, False]
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
    else:
        hap["Mustrain"][0] = "isotropic"
        if seed:
            hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [True, False, False]
        hap["Size"][1][:] = [1.0e6, 1.0e6, 1.0]
        hap["Size"][2][:] = [False, False, False]


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "scale": hap["Scale"][0],
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    row = {
        "label": label,
        "Rwp": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "profile": {key: inst[key][1] for key in ("U", "V", "W", "X", "Y", "SH/L")},
        "shift": hist.data["Sample Parameters"]["Shift"][0],
        "frozen": [str(item) for item in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
        "phases": phases,
    }
    print(json.dumps(row, default=float, sort_keys=True))
    return row


def run(project, label: str) -> dict:
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    return snapshot(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("project", type=Path)
    parser.add_argument("phase")
    parser.add_argument("mode", choices=("size", "strain"))
    args = parser.parse_args()
    args.project.parent.mkdir(parents=True, exist_ok=True)
    if args.project.exists():
        args.project.unlink()
    project = G2sc.G2Project(str(args.base), newgpx=str(args.project))
    project.data["Controls"]["data"]["shift factor"] = 0.25
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    phase = project.phase(args.phase)
    if phase is None:
        raise KeyError(f"Unknown phase: {args.phase}")
    p_id = phase.id
    for variable, lower, upper in (
        (":0:W", 0.0, 200.0),
        (":0:X", 0.0, 30.0),
        (":0:Shift", -1000.0, 1000.0),
        (f"{p_id}:0:Size;i", 0.01, 1.0e6),
        (f"{p_id}:0:Mustrain;i", 0.0, 10000.0),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    configure(project, args.phase, args.mode, seed=True)
    rows = []
    for replay in range(6):
        row = run(project, f"{args.phase}_{args.mode}_{replay + 1}")
        rows.append(row)
        if row["converged"] and abs(row.get("max_shift_esd") or 0.0) < 1.0:
            break
    project.save()
    project = G2sc.G2Project(str(args.project))
    configure(project, args.phase, args.mode, seed=False)
    rows.append(run(project, "fresh_native_atomic_replay"))
    project.save()
    args.project.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float))


if __name__ == "__main__":
    main()
