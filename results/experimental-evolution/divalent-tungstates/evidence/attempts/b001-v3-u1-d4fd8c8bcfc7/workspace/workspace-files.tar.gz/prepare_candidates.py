#!/usr/bin/env python3
"""Create chemically explicit local CIFs from screened COD prototypes."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path("<RUN>/resources/b001-c04/cif")
OUT = Path("candidates")


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_adapted(
    cod_id: str,
    output: str,
    substitutions: dict[str, str],
    lattice: Lattice | None = None,
) -> None:
    structure = Structure.from_file(cod_path(cod_id))
    structure.replace_species(substitutions)
    if lattice is not None:
        structure.lattice = lattice
    CifWriter(structure, symprec=0.01, refine_struct=False).write_file(OUT / output)


def main() -> None:
    OUT.mkdir(exist_ok=True)

    # Best-screened wolframite parent: fully occupied single-crystal ferberite,
    # COD 9008124. The trial cell is indexed from the observed low-angle
    # wolframite family and is deliberately only an initial value.
    write_adapted(
        "9008124",
        "mnwo4_wolframite_9008124_trial.cif",
        {"Fe": "Mn"},
        Lattice.monoclinic(4.83, 5.76, 4.99, 91.15),
    )

    # Physically sensible but structurally distinct ABX4 analogue, retained as
    # a polymorph challenge rather than as a source of case-specific geometry.
    write_adapted(
        "1527061",
        "mnwo4_c2m_1527061_trial.cif",
        {"Mo": "W"},
    )

    # Plausible residual precursor records that passed occupancy/geometry checks.
    for cod_id in ("1011262", "9001963"):
        structure = Structure.from_file(cod_path(cod_id))
        CifWriter(structure, symprec=0.01, refine_struct=False).write_file(
            OUT / f"mn3o4_{cod_id}.cif"
        )
    for cod_id in ("1563541", "2311041", "2106293", "2107312"):
        structure = Structure.from_file(cod_path(cod_id))
        CifWriter(structure, symprec=0.01, refine_struct=False).write_file(
            OUT / f"wo3_{cod_id}.cif"
        )


if __name__ == "__main__":
    main()
