#!/usr/bin/env python3
"""Run an alternate MnWO4 polymorph under the accepted common schedule."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import neutralize_hap


def configure(project, alt_name: str, release_cells: bool) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 8}}
    )
    for key, value in inst.items():
        if len(value) >= 3:
            value[2] = key in {"W", "X"}
    inst["Zero"][2] = False
    inst["Polariz."][2] = False
    sample["Scale"][1] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = key == "Shift"
    for phase in project.phases():
        phase.set_refinements(
            {"Cell": release_cells, "LeBail": False, "Atoms": {"all": ""}}
        )
        phase.set_HAP_refinements({"Scale": True, "Pref.Ori.": False}, [hist])


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    row = {
        "label": label,
        "Rwp": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [
            str(item)
            for item in project.data["Controls"]["data"]
            .get("parmFrozen", {})
            .get("FrozenList", [])
        ],
        "phases": {
            phase.name: {
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
                "cell": phase.get_cell(),
            }
            for phase in project.phases()
        },
    }
    try:
        row["fractions"] = {
            key: {"fraction": value[0], "su": value[1]}
            for key, value in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        row["fractions"] = {"error": str(exc)}
    print(json.dumps(row, default=float, sort_keys=True))
    return row


def run(project, label: str) -> dict:
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    return snapshot(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("alternate", type=Path)
    parser.add_argument("project", type=Path)
    parser.add_argument("--name", default="MnWO4_C2m_challenge")
    args = parser.parse_args()
    if args.project.exists():
        args.project.unlink()

    base = G2sc.G2Project(str(args.base))
    base_hist = base.histogram(0)
    project = G2sc.G2Project(newgpx=str(args.project))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    hist.data["Background"] = copy.deepcopy(base_hist.data["Background"])
    for key in ("W", "X", "Polariz.", "SH/L"):
        hist.data["Instrument Parameters"][0][key][1] = base_hist.data[
            "Instrument Parameters"
        ][0][key][1]
    for key in ("Shift", "SurfRoughA", "SurfRoughB"):
        hist.data["Sample Parameters"][key][0] = base_hist.data["Sample Parameters"][key][0]

    alt = project.add_phase(
        str(args.alternate), phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    wo3 = project.add_phase(
        "candidates/wo3_2311041.cif",
        phasename="WO3_monoclinic_2311041",
        histograms=[hist],
        fmthint="CIF",
    )
    mn3o4 = project.add_phase(
        "candidates/mn3o4_1011262.cif",
        phasename="Mn3O4_hausmannite",
        histograms=[hist],
        fmthint="CIF",
    )
    for phase in (alt, wo3, mn3o4):
        neutralize_hap(phase, hist.name)
    # Carry only the supported WO3 broadening term into the common comparison.
    base_wo3_hap = base.phase("WO3_monoclinic_2311041").data["Histograms"][base_hist.name]
    wo3_hap = wo3.data["Histograms"][hist.name]
    wo3_hap["Size"][1][0] = base_wo3_hap["Size"][1][0]
    wo3_hap["Size"][2][0] = True
    alt.data["Histograms"][hist.name]["Scale"] = [20.0, True]
    wo3.data["Histograms"][hist.name]["Scale"] = [4.0, True]
    mn3o4.data["Histograms"][hist.name]["Scale"] = [2.0, True]

    project.data["Controls"]["data"]["shift factor"] = 0.25
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    for variable, lower, upper in (
        (":0:W", 0.0, 200.0),
        (":0:X", 0.0, 30.0),
        (":0:Shift", -1000.0, 1000.0),
        ("0:0:Scale", 0.0, 1.0e6),
        ("1:0:Scale", 0.0, 1.0e6),
        ("2:0:Scale", 0.0, 1.0e6),
        ("1:0:Size;i", 0.01, 1.0e6),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    configure(project, args.name, release_cells=False)
    rows = []
    for replay in range(6):
        row = run(project, f"source_cells_{replay + 1}")
        rows.append(row)
        if row["converged"] and abs(row.get("max_shift_esd") or 0.0) < 1.0:
            break
    configure(project, args.name, release_cells=True)
    for replay in range(8):
        row = run(project, f"released_cells_{replay + 1}")
        rows.append(row)
        if row["converged"] and abs(row.get("max_shift_esd") or 0.0) < 1.0:
            break
    project.save()
    project = G2sc.G2Project(str(args.project))
    configure(project, args.name, release_cells=True)
    rows.append(run(project, "fresh_native_atomic_replay"))
    project.save()
    args.project.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float))


if __name__ == "__main__":
    main()
