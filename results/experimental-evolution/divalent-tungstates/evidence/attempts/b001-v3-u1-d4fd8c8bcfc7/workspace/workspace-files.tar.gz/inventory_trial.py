#!/usr/bin/env python3
"""Add a candidate to the converged profile model and replay all shared terms.

Existing phase broadening terms are retained.  The added phase starts with
neutral HAP terms and is tested first at its source cell and then with its cell
released, so that a fit gained only through cell distortion is visible.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import neutralize_hap


def configure(project, added_name: str, release_added_cell: bool) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
            }
        }
    )
    for key, value in inst.items():
        if len(value) >= 3:
            value[2] = key in {"W", "X"}
    inst["Zero"][2] = False
    sample["Scale"][1] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = key == "Shift"
    for phase in project.phases():
        phase.set_refinements(
            {"Cell": release_added_cell or phase.name != added_name, "LeBail": False}
        )
        phase.set_HAP_refinements({"Scale": True}, [hist])


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    vary = cov.get("varyList", [])
    sig = dict(zip(vary, cov.get("sig", [])))
    inst = hist.data["Instrument Parameters"][0]
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "scale": hap["Scale"][0],
            "scale_su": sig.get(f"{phase.id}:0:Scale"),
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    try:
        fractions = {
            key: {"fraction": value[0], "su": value[1]}
            for key, value in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": str(exc)}
    row = {
        "label": label,
        "Rwp": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "profile": {key: inst[key][1] for key in ("U", "V", "W", "X", "Y", "SH/L")},
        "shift": hist.data["Sample Parameters"]["Shift"][0],
        "frozen": [
            str(item)
            for item in project.data["Controls"]["data"]
            .get("parmFrozen", {})
            .get("FrozenList", [])
        ],
        "fractions": fractions,
        "phases": phases,
    }
    print(json.dumps(row, default=float, sort_keys=True))
    return row


def run(project, label: str) -> dict:
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    return snapshot(project, label)


def converge(project, added_name: str, release_cell: bool, label: str) -> list[dict]:
    rows = []
    configure(project, added_name, release_cell)
    for replay in range(6):
        row = run(project, f"{label}_{replay + 1}")
        rows.append(row)
        if row["converged"] and abs(row.get("max_shift_esd") or 0.0) < 1.0:
            break
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("cif", type=Path)
    parser.add_argument("project", type=Path)
    parser.add_argument("--name", required=True)
    args = parser.parse_args()
    args.project.parent.mkdir(parents=True, exist_ok=True)
    if args.project.exists():
        args.project.unlink()

    project = G2sc.G2Project(str(args.base), newgpx=str(args.project))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(args.cif), phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    neutralize_hap(phase, hist.name)
    phase.data["Histograms"][hist.name]["Scale"] = [0.5, True]
    project.data["Controls"]["data"]["shift factor"] = 0.25
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    for variable, lower, upper in (
        (":0:W", 0.0, 200.0),
        (":0:X", 0.0, 30.0),
        (":0:Shift", -1000.0, 1000.0),
        (f"{phase.id}:0:Scale", 0.0, 1.0e6),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)

    rows = []
    rows.extend(converge(project, args.name, False, "source_cell"))
    rows.extend(converge(project, args.name, True, "released_cell"))
    project.save()
    project = G2sc.G2Project(str(args.project))
    configure(project, args.name, True)
    rows.append(run(project, "fresh_native_atomic_replay"))
    project.save()
    args.project.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float))


if __name__ == "__main__":
    main()
