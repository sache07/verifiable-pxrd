#!/usr/bin/env python3
"""Challenge one shared intensity nuisance against a converged phase model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def configure(project, mode: str, seed: bool) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
            }
        }
    )
    for key, value in inst.items():
        if len(value) >= 3:
            value[2] = key in {"W", "X"}
    inst["Zero"][2] = False
    inst["Polariz."][2] = mode == "polarization"
    if seed and mode == "polarization":
        inst["Polariz."][1] = 0.7
    sample["Scale"][1] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = (
            key == "Shift"
            or (mode in {"roughness", "roughness2"} and key == "SurfRoughB")
            or (mode == "roughness2" and key == "SurfRoughA")
        )
    if seed:
        sample["SurfRoughA"][0] = 0.2 if mode == "roughness2" else 0.0
        sample["SurfRoughB"][0] = 0.05 if mode in {"roughness", "roughness2"} else 0.0
    for phase in project.phases():
        phase.set_refinements({"Cell": True, "LeBail": False})
        phase.set_HAP_refinements({"Scale": True}, [hist])


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    row = {
        "label": label,
        "Rwp": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "polarization": inst["Polariz."][1],
        "surface_roughness_A": sample["SurfRoughA"][0],
        "surface_roughness_B": sample["SurfRoughB"][0],
        "profile": {key: inst[key][1] for key in ("U", "V", "W", "X", "Y", "SH/L")},
        "shift": sample["Shift"][0],
        "frozen": [
            str(item)
            for item in project.data["Controls"]["data"]
            .get("parmFrozen", {})
            .get("FrozenList", [])
        ],
        "fractions": {
            key: {"fraction": value[0], "su": value[1]}
            for key, value in hist.ComputeMassFracs().items()
        },
    }
    print(json.dumps(row, default=float, sort_keys=True))
    return row


def run(project, label: str) -> dict:
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    return snapshot(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("project", type=Path)
    parser.add_argument("mode", choices=("polarization", "roughness", "roughness2"))
    args = parser.parse_args()
    if args.project.exists():
        args.project.unlink()
    project = G2sc.G2Project(str(args.base), newgpx=str(args.project))
    project.data["Controls"]["data"]["shift factor"] = 0.25
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    bounds = [
        (":0:W", 0.0, 200.0),
        (":0:X", 0.0, 30.0),
        (":0:Shift", -1000.0, 1000.0),
        (":0:Polariz.", 0.0, 1.0),
        (":0:SurfRoughA", 0.0, 1.0),
        (":0:SurfRoughB", 0.0, 1.0),
    ]
    for variable, lower, upper in bounds:
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    configure(project, args.mode, seed=True)
    rows = []
    for replay in range(6):
        row = run(project, f"{args.mode}_{replay + 1}")
        rows.append(row)
        if row["converged"] and abs(row.get("max_shift_esd") or 0.0) < 1.0:
            break
    project.save()
    project = G2sc.G2Project(str(args.project))
    configure(project, args.mode, seed=False)
    rows.append(run(project, "fresh_native_atomic_replay"))
    project.save()
    args.project.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float))


if __name__ == "__main__":
    main()
