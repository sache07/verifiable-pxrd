#!/usr/bin/env python3
"""Refine a selected, symmetry-reduced atom-coordinate set in stages."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def add_wolframite_restraints(phase, weight: float) -> None:
    """Apply soft octahedral distances inherited from the screened parent."""
    restraint_root = phase.proj.data["Restraints"]["data"]
    restraint_data = restraint_root.setdefault(
        phase.name,
        {
            "Bond": {"wtFactor": 1.0, "Range": 1.1, "Bonds": [], "Use": True},
            "Angle": {"wtFactor": 1.0, "Range": 0.85, "Angles": [], "Use": True},
            "Plane": {"wtFactor": 1.0, "Planes": [], "Use": True},
            "Chiral": {"wtFactor": 1.0, "Volumes": [], "Use": True},
            "Torsion": {"wtFactor": 1.0, "Coeff": {}, "Torsions": [], "Use": True},
            "Rama": {"wtFactor": 1.0, "Coeff": {}, "Ramas": [], "Use": True},
            "Texture": {"wtFactor": 1.0, "HKLs": [], "Use": True},
            "ChemComp": {"wtFactor": 1.0, "Sites": [], "Use": True},
            "General": {"wtFactor": 1.0, "General": [], "Use": True},
        },
    )
    if restraint_data["Bond"]["Bonds"]:
        phase.setDistRestraintWeight(weight)
        return
    phase.clearDistRestraint()
    # Targets are the five distinct Mn/Fe--O and W--O shells in COD 9008124.
    # Search factors are only used to select the intended symmetry mates.
    specifications = (
        ("W1", "O2", 1.812, 1.05),
        ("W1", "O1", 1.922, 1.04),
        ("W1", "O1", 2.159, 1.04),
        ("Mn0", "O1", 2.071, 1.04),
        ("Mn0", "O2", 2.197, 1.04),
    )
    for origin, target, distance, factor in specifications:
        phase.addDistRestraint(
            [origin], [target], distance, factor=factor, ESD=0.03
        )
    phase.setDistRestraintWeight(weight)


def configure(
    project,
    phase_name: str,
    atom_labels: list[str],
    wolframite_restraint_weight: float | None,
) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
            }
        }
    )
    for key, value in inst.items():
        if len(value) >= 3:
            value[2] = key in {"W", "X"}
    inst["Zero"][2] = False
    # Preserve an accepted polarization value, but do not couple it to atoms.
    inst["Polariz."][2] = False
    sample["Scale"][1] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = key == "Shift"
    for phase in project.phases():
        phase.set_refinements({"Cell": True, "LeBail": False, "Atoms": {"all": ""}})
        phase.set_HAP_refinements({"Scale": True}, [hist])
    target = project.phase(phase_name)
    target.set_refinements({"Atoms": {label: "X" for label in atom_labels}})
    if wolframite_restraint_weight is not None:
        add_wolframite_restraints(target, wolframite_restraint_weight)


def snapshot(project, label: str, phase_name: str) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    phase = project.phase(phase_name)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    row = {
        "label": label,
        "Rwp": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "profile": {key: inst[key][1] for key in ("U", "V", "W", "X", "Y", "SH/L")},
        "polarization": inst["Polariz."][1],
        "shift": sample["Shift"][0],
        "frozen": [
            str(item)
            for item in project.data["Controls"]["data"]
            .get("parmFrozen", {})
            .get("FrozenList", [])
        ],
        "fractions": {
            key: {"fraction": value[0], "su": value[1]}
            for key, value in hist.ComputeMassFracs().items()
        },
        "cell": phase.get_cell(),
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": list(atom.coordinates),
                "refinement_flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ],
    }
    print(json.dumps(row, default=float, sort_keys=True))
    return row


def run(project, label: str, phase_name: str) -> dict:
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    return snapshot(project, label, phase_name)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("project", type=Path)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--atoms", nargs="+", required=True)
    parser.add_argument("--wolframite-restraint-weight", type=float)
    args = parser.parse_args()
    if args.project.exists():
        args.project.unlink()
    project = G2sc.G2Project(str(args.base), newgpx=str(args.project))
    project.data["Controls"]["data"]["shift factor"] = 0.25
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    for variable, lower, upper in (
        (":0:W", 0.0, 200.0),
        (":0:X", 0.0, 30.0),
        (":0:Shift", -1000.0, 1000.0),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    configure(project, args.phase, args.atoms, args.wolframite_restraint_weight)
    rows = []
    for replay in range(8):
        row = run(project, f"coordinates_{replay + 1}", args.phase)
        rows.append(row)
        if row["converged"] and abs(row.get("max_shift_esd") or 0.0) < 1.0:
            break
    project.save()
    project = G2sc.G2Project(str(args.project))
    configure(project, args.phase, args.atoms, args.wolframite_restraint_weight)
    rows.append(run(project, "fresh_native_atomic_replay", args.phase))
    project.save()
    args.project.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float))


if __name__ == "__main__":
    main()
