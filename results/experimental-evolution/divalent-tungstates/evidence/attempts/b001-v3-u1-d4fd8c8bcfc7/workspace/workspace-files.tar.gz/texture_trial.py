#!/usr/bin/env python3
"""Compare one March-Dollase axis while replaying all shared profile terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def configure(project, phase_name: str, axis: list[int], seed: bool) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 8}}
    )
    for key, value in inst.items():
        if len(value) >= 3:
            value[2] = key in {"W", "X"}
    inst["Zero"][2] = False
    inst["Polariz."][2] = False
    sample["Scale"][1] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = key == "Shift"
    for phase in project.phases():
        phase.set_refinements({"Cell": True, "LeBail": False, "Atoms": {"all": ""}})
        phase.set_HAP_refinements({"Scale": True, "Pref.Ori.": False}, [hist])
    target = project.phase(phase_name)
    po = target.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    if seed:
        po[1] = 1.0
    po[2] = True
    po[3] = axis


def snapshot(project, label: str, phase_name: str) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    target = project.phase(phase_name)
    po = target.data["Histograms"][hist.name]["Pref.Ori."]
    inst = hist.data["Instrument Parameters"][0]
    row = {
        "label": label,
        "Rwp": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "MD": po[1],
        "axis": po[3],
        "profile": {key: inst[key][1] for key in ("U", "V", "W", "X", "Y", "SH/L")},
        "shift": hist.data["Sample Parameters"]["Shift"][0],
        "frozen": [
            str(item)
            for item in project.data["Controls"]["data"]
            .get("parmFrozen", {})
            .get("FrozenList", [])
        ],
        "fractions": {
            key: {"fraction": value[0], "su": value[1]}
            for key, value in hist.ComputeMassFracs().items()
        },
    }
    print(json.dumps(row, default=float, sort_keys=True))
    return row


def run(project, label: str, phase_name: str) -> dict:
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    return snapshot(project, label, phase_name)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("project", type=Path)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--axis", type=int, nargs=3, required=True)
    args = parser.parse_args()
    if args.project.exists():
        args.project.unlink()
    project = G2sc.G2Project(str(args.base), newgpx=str(args.project))
    project.data["Controls"]["data"]["shift factor"] = 0.25
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    target = project.phase(args.phase)
    for variable, lower, upper in (
        (":0:W", 0.0, 200.0),
        (":0:X", 0.0, 30.0),
        (":0:Shift", -1000.0, 1000.0),
        (f"{target.id}:0:MD", 0.5, 2.0),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    configure(project, args.phase, args.axis, seed=True)
    rows = []
    for replay in range(6):
        row = run(project, f"texture_{replay + 1}", args.phase)
        rows.append(row)
        if row["converged"] and abs(row.get("max_shift_esd") or 0.0) < 1.0:
            break
    project.save()
    project = G2sc.G2Project(str(args.project))
    configure(project, args.phase, args.axis, seed=False)
    rows.append(run(project, "fresh_native_atomic_replay", args.phase))
    project.save()
    args.project.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float))


if __name__ == "__main__":
    main()
