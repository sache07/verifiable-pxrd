#!/usr/bin/env python3
"""Add one phase to a converged base and fully reconverge shared nuisances."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import neutralize_hap


def configure(project, refine_cells: bool) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
            }
        }
    )
    for key, value in inst.items():
        if len(value) >= 3:
            value[2] = False
    inst["Zero"][2] = False
    sample["Scale"][1] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = key == "Shift"
    for phase in project.phases():
        phase.set_refinements({"Cell": refine_cells, "LeBail": False})
        phase.set_HAP_refinements({"Scale": True}, [hist])
        neutralize_hap(phase, hist.name)


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    row = {
        "label": label,
        "Rwp": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "shift": hist.data["Sample Parameters"]["Shift"][0],
        "phases": {
            phase.name: {
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
                "cell": phase.get_cell(),
            }
            for phase in project.phases()
        },
    }
    print(json.dumps(row, default=float, sort_keys=True))
    return row


def run(project, label: str) -> dict:
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    return snapshot(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("cif", type=Path)
    parser.add_argument("project", type=Path)
    parser.add_argument("--name", required=True)
    args = parser.parse_args()
    args.project.parent.mkdir(parents=True, exist_ok=True)
    if args.project.exists():
        args.project.unlink()

    project = G2sc.G2Project(str(args.base), newgpx=str(args.project))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(args.cif), phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    neutralize_hap(phase, hist.name)
    phase.data["Histograms"][hist.name]["Scale"] = [1.0, True]
    project.data["Controls"]["data"]["shift factor"] = 0.25
    project.set_Controls("parmMin", -1000.0, variable=":0:Shift")
    project.set_Controls("parmMax", 1000.0, variable=":0:Shift")

    rows = []
    configure(project, refine_cells=False)
    rows.append(run(project, "all_scales_background_shift"))
    configure(project, refine_cells=True)
    for replay in range(6):
        row = run(project, f"all_cells_scales_background_shift_{replay + 1}")
        rows.append(row)
        if row["converged"] and abs(row.get("max_shift_esd") or 0.0) < 1.0:
            break

    project.save()
    project = G2sc.G2Project(str(args.project))
    configure(project, refine_cells=True)
    rows.append(run(project, "fresh_native_atomic_replay"))
    project.save()
    args.project.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float))


if __name__ == "__main__":
    main()
