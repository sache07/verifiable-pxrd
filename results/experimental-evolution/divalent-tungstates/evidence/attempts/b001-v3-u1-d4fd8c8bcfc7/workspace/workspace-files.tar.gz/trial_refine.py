#!/usr/bin/env python3
"""Run a controlled single-candidate GSAS-II profile/refinement challenge."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def neutralize_hap(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1.0e6, 1.0e6, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])


def set_flags(project, correction: str, lebail: bool, profile: bool = False) -> None:
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
            },
        }
    )
    for key in inst:
        if len(inst[key]) >= 3:
            inst[key][2] = profile and key in {"U", "W", "X", "SH/L"}
    sample["Scale"][1] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = key == correction
    inst["Zero"][2] = correction == "Zero"
    phase.set_refinements({"Cell": True, "LeBail": lebail})
    phase.set_HAP_refinements({"Scale": True}, [hist])
    neutralize_hap(phase, hist.name)


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    row = {
        "label": label,
        "Rwp": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "Nvars": rvals.get("Nvars"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "cell": phase.get_cell(),
        "scale": phase.data["Histograms"][hist.name]["Scale"][0],
        "zero": inst["Zero"][1],
        "shift": sample["Shift"][0],
        "profile": {key: inst[key][1] for key in ("U", "V", "W", "X", "Y", "SH/L")},
        "polarization": inst["Polariz."][1],
        "ka2_ratio": inst["I(L2)/I(L1)"][1],
    }
    print(json.dumps(row, default=float, sort_keys=True))
    return row


def refine_once(project, label: str) -> dict:
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    return snapshot(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("cif", type=Path)
    parser.add_argument("project", type=Path)
    parser.add_argument("--correction", choices=("Shift", "Zero"), default="Shift")
    parser.add_argument("--name", default="candidate")
    args = parser.parse_args()

    args.project.parent.mkdir(parents=True, exist_ok=True)
    if args.project.exists():
        args.project.unlink()
    project = G2sc.G2Project(newgpx=str(args.project))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    phase = project.add_phase(
        str(args.cif), phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
                "coeffs": [1500.0, -500.0, 100.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            }
        }
    )
    neutralize_hap(phase, hist.name)
    phase.set_refinements({"LeBail": False})
    phase.set_HAP_refinements({"Scale": True}, [hist])
    if args.correction == "Zero":
        hist.data["Instrument Parameters"][0]["Zero"][:2] = [-0.25, -0.25]
    else:
        hist.data["Sample Parameters"]["Shift"][:2] = [435.0, False]

    # Limit empirically sensitive profile/correction terms and damp early cell
    # shifts. Bounds are deliberately wider than physically expected values.
    project.data["Controls"]["data"]["shift factor"] = 0.25
    for variable, lower, upper in (
        ("0:0:Scale", 0.0, 1.0e5),
        (":0:U", 0.0, 200.0),
        (":0:W", 0.0, 100.0),
        (":0:X", 0.0, 30.0),
        (":0:SH/L", 0.002, 0.20),
        (":0:Shift", -1000.0, 1000.0),
        (":0:Zero", -1.0, 1.0),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)

    rows = []
    rows.append(refine_once(project, "native_seed_background_scale"))

    # Re-establish background, phase scale, one angular correction, and cell.
    sample = hist.data["Sample Parameters"]
    inst = hist.data["Instrument Parameters"][0]
    if args.correction == "Shift":
        sample["Shift"][1] = True
        inst["Zero"][2] = False
    else:
        sample["Shift"][1] = False
        inst["Zero"][2] = True
    rows.append(refine_once(project, "native_angular"))
    phase.set_refinements({"Cell": True})
    for replay in range(6):
        row = refine_once(project, f"native_cell_angular_{replay + 1}")
        rows.append(row)
        if row["converged"] and abs(row.get("max_shift_esd") or 0.0) < 1.0:
            break

    # Save/reopen and run a fresh native atomic (non-Le Bail) replay.
    project.save()
    project = G2sc.G2Project(str(args.project))
    set_flags(project, args.correction, lebail=False, profile=False)
    rows.append(refine_once(project, "native_atomic_replay"))
    project.save()

    args.project.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float))


if __name__ == "__main__":
    main()
