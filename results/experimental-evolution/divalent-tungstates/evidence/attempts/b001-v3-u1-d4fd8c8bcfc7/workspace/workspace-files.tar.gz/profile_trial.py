#!/usr/bin/env python3
"""Challenge selected common-profile terms on an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import neutralize_hap


VALID_TERMS = {"U", "W", "X", "SH/L"}


def configure(project, terms: set[str]) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
            }
        }
    )
    for key, value in inst.items():
        if len(value) >= 3:
            value[2] = key in terms
    inst["Zero"][2] = False
    sample["Scale"][1] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = key == "Shift"
    for phase in project.phases():
        phase.set_refinements({"Cell": True, "LeBail": False})
        phase.set_HAP_refinements({"Scale": True}, [hist])
        neutralize_hap(phase, hist.name)


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    row = {
        "label": label,
        "Rwp": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "profile": {key: inst[key][1] for key in ("U", "V", "W", "X", "Y", "SH/L")},
        "shift": hist.data["Sample Parameters"]["Shift"][0],
        "frozen": [str(item) for item in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
        "phases": {
            phase.name: {
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
                "cell": phase.get_cell(),
            }
            for phase in project.phases()
        },
    }
    print(json.dumps(row, default=float, sort_keys=True))
    return row


def run(project, label: str) -> dict:
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    return snapshot(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("project", type=Path)
    parser.add_argument("terms", nargs="+", choices=sorted(VALID_TERMS))
    args = parser.parse_args()
    terms = set(args.terms)
    args.project.parent.mkdir(parents=True, exist_ok=True)
    if args.project.exists():
        args.project.unlink()
    project = G2sc.G2Project(str(args.base), newgpx=str(args.project))
    project.data["Controls"]["data"]["shift factor"] = 0.25
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    for variable, lower, upper in (
        (":0:U", 0.0, 200.0),
        (":0:W", 0.0, 200.0),
        (":0:X", 0.0, 30.0),
        (":0:SH/L", 0.002, 0.20),
        (":0:Shift", -1000.0, 1000.0),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    configure(project, terms)
    rows = []
    for replay in range(6):
        row = run(project, f"profile_{'_'.join(sorted(terms))}_{replay + 1}")
        rows.append(row)
        if row["converged"] and abs(row.get("max_shift_esd") or 0.0) < 1.0:
            break
    project.save()
    project = G2sc.G2Project(str(args.project))
    configure(project, terms)
    rows.append(run(project, "fresh_native_atomic_replay"))
    project.save()
    args.project.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float))


if __name__ == "__main__":
    main()
