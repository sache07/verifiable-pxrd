#!/usr/bin/env python3
"""Create the final converged GSAS-II project and required machine outputs."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from trial_refine import neutralize_hap


BASE = Path("trials/modern_texture_010.gpx")
PROJECT = Path("final.gpx")
PHASE_INFO = {
    "MnWO4_wolframite": {
        "display_name": "MnWO4 (wolframite)",
        "formula": "MnWO4",
        "cif": "phase_mnwo4.cif",
        "structure_source": "COD 9008124 FeWO4 prototype; Fe replaced by Mn",
    },
    "WO3_monoclinic_2311041": {
        "display_name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif": "phase_wo3.cif",
        "structure_source": "COD 2311041",
    },
    "Mn3O4_hausmannite": {
        "display_name": "Mn3O4 (hausmannite)",
        "formula": "Mn3O4",
        "cif": "phase_mn3o4.cif",
        "structure_source": "COD 9001963",
    },
}


def configure(project) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 8}}
    )
    for key, value in inst.items():
        if len(value) >= 3:
            value[2] = key in {"W", "X"}
    inst["U"][1] = 0.0
    inst["V"][1] = 0.0
    inst["Y"][1] = 0.0
    inst["SH/L"][1] = 0.002
    inst["Zero"][1] = 0.0
    inst["Zero"][2] = False
    inst["Polariz."][1] = 0.7
    inst["Polariz."][2] = False
    sample["Scale"][1] = False
    sample["SurfRoughA"][0] = 0.0
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = key in {"Shift", "SurfRoughB"}

    for phase in project.phases():
        phase.set_refinements({"Cell": True, "LeBail": False, "Atoms": {"all": ""}})
        phase.set_HAP_refinements({"Scale": True, "Pref.Ori.": False}, [hist])

    mnwo4 = project.phase("MnWO4_wolframite")
    mnwo4.set_refinements({"Atoms": {"Mn0": "X", "W1": "X"}})
    mn_hap = mnwo4.data["Histograms"][hist.name]
    # Neutral phase broadening and retain only the selected weak [010] texture.
    neutralize_hap(mnwo4, hist.name)
    mn_hap["Pref.Ori."][0] = "MD"
    mn_hap["Pref.Ori."][2] = True
    mn_hap["Pref.Ori."][3] = [0, 1, 0]

    wo3 = project.phase("WO3_monoclinic_2311041")
    wo3_hap = wo3.data["Histograms"][hist.name]
    wo3_hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    wo3_hap["Mustrain"][2][:] = [False, False, False]
    wo3_hap["Mustrain"][4][:] = [0.0] * len(wo3_hap["Mustrain"][4])
    wo3_hap["Mustrain"][5][:] = [False] * len(wo3_hap["Mustrain"][5])
    wo3_hap["HStrain"][0][:] = [0.0] * len(wo3_hap["HStrain"][0])
    wo3_hap["HStrain"][1][:] = [False] * len(wo3_hap["HStrain"][1])
    wo3_hap["Size"][0] = "isotropic"
    wo3_hap["Size"][2][:] = [True, False, False]

    mn3o4 = project.phase("Mn3O4_hausmannite")
    neutralize_hap(mn3o4, hist.name)
    project.data["Restraints"]["data"] = {}


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    row = {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_over_su": rvals.get("Max shft/sig"),
        "frozen": [
            str(item)
            for item in project.data["Controls"]["data"]
            .get("parmFrozen", {})
            .get("FrozenList", [])
        ],
        "fractions": {
            name: {"value": val, "su": su}
            for name, (val, su) in hist.ComputeMassFracs().items()
        },
    }
    print(json.dumps(row, sort_keys=True))
    return row


def refine(project, label: str) -> dict:
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    return snapshot(project, label)


def set_bounds(project) -> None:
    phase_ids = {phase.name: phase.id for phase in project.phases()}
    bounds = [
        (":0:W", 0.0, 200.0),
        (":0:X", 0.0, 30.0),
        (":0:Shift", -1000.0, 1000.0),
        (":0:SurfRoughB", 0.0, 1.0),
        (f"{phase_ids['MnWO4_wolframite']}:0:MD", 0.5, 2.0),
        (f"{phase_ids['WO3_monoclinic_2311041']}:0:Size;i", 0.01, 1.0e6),
    ]
    for phase in project.phases():
        bounds.append((f"{phase.id}:0:Scale", 0.0, 1.0e6))
    for variable, lower, upper in bounds:
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)


def correlation_diagnostics(project, threshold: float = 0.90) -> list[dict]:
    cov = project.data["Covariance"]["data"]
    matrix = np.asarray(cov["covMatrix"], dtype=float)
    sd = np.sqrt(np.diag(matrix))
    corr = matrix / np.outer(sd, sd)
    names = cov["varyList"]
    rows = []
    for i in range(len(names)):
        for j in range(i):
            if abs(corr[i, j]) >= threshold:
                rows.append(
                    {
                        "parameter_1": names[j],
                        "parameter_2": names[i],
                        "correlation": float(corr[i, j]),
                    }
                )
    return rows


def export_outputs(project, replay_log: list[dict]) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        phase.export_CIF(PHASE_INFO[phase.name]["cif"])

    arrays = np.asarray(hist.data["data"][1])
    with Path("fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "difference", "background"]
        )
        for two_theta, observed, calculated, difference, background in zip(
            arrays[0], arrays[1], arrays[3], arrays[5], arrays[4]
        ):
            writer.writerow(
                [
                    f"{float(two_theta):.8f}",
                    f"{float(observed):.8f}",
                    f"{float(calculated):.8f}",
                    f"{float(difference):.8f}",
                    f"{float(background):.8f}",
                ]
            )

    fractions = hist.ComputeMassFracs()
    cov = project.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    profile_stats = hist.data["data"][0]
    result_phases = []
    for phase in project.phases():
        frac, su = fractions[phase.name]
        general = phase.data["General"]
        entry = PHASE_INFO[phase.name]
        result_phases.append(
            {
                "name": entry["display_name"],
                "project_phase_name": phase.name,
                "formula": entry["formula"],
                "space_group": general["SGData"]["SpGrp"].strip(),
                "cif": entry["cif"],
                "weight_fraction": float(frac),
                "weight_fraction_su": float(su),
                "weight_percent": 100.0 * float(frac),
                "weight_percent_su": 100.0 * float(su),
                "cell": phase.get_cell(),
                "structure_source": entry["structure_source"],
            }
        )
    result = {
        "project": str(PROJECT),
        "profile": "fit.csv",
        "fraction_basis": "normalized over the modeled crystalline phases",
        "phases": result_phases,
        "fit_statistics": {
            "Rwp_percent": float(hist.get_wR()),
            "Rp_percent": float(profile_stats["R"]),
            "GOF": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "Nobs": int(rvals["Nobs"]),
            "Nvars": int(rvals["Nvars"]),
            "weighted_residual_floor_percent": float(profile_stats["wRmin"]),
        },
        "refinement_diagnostics": {
            "converged": bool(rvals.get("converged")),
            "max_shift_over_su": float(rvals.get("Max shft/sig")),
            "frozen_parameters": replay_log[-1]["frozen"],
            "absolute_correlations_at_least_0.90": correlation_diagnostics(project),
        },
    }
    Path("result.json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    Path("final_refinement_log.json").write_text(
        json.dumps(replay_log, indent=2, default=float) + "\n"
    )


def main() -> None:
    if PROJECT.exists():
        PROJECT.unlink()
    project = G2sc.G2Project(str(BASE), newgpx=str(PROJECT))
    project.data["Controls"]["data"]["shift factor"] = 0.25
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    configure(project)
    set_bounds(project)
    replay_log = []
    for cycle in range(8):
        row = refine(project, f"joint_replay_{cycle + 1}")
        replay_log.append(row)
        if row["converged"] and abs(row["max_shift_over_su"] or 0.0) < 0.25:
            break
    project.save()

    # Required fresh, reopened, native structure-factor replay over the full range.
    project = G2sc.G2Project(str(PROJECT))
    configure(project)
    set_bounds(project)
    for cycle in range(6):
        row = refine(project, f"fresh_reopened_native_atomic_replay_{cycle + 1}")
        replay_log.append(row)
        if row["converged"] and abs(row["max_shift_over_su"] or 0.0) < 0.25:
            break
    project.save()
    export_outputs(project, replay_log)


if __name__ == "__main__":
    main()
