#!/usr/bin/env python3
"""Run a modest, common-nuisance GSAS-II branch for phase discrimination."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize_hap(phase, hist_name: str, provisional_size: float | None = None) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][1][2] = 1.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = provisional_size if provisional_size is not None else 10000.0
    hap["Size"][1][1] = 10000.0
    hap["Size"][1][2] = 0.5 if provisional_size is not None else 1.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Scale"][0] = 0.01
    hap["Scale"][1] = True


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    out = {
        "stage": label,
        "residuals": hist.residuals,
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items() if isinstance(v, list) and len(v) > 1},
        "sample": {
            k: v[0] for k, v in hist.SampleParameters.items()
            if isinstance(v, list) and len(v) == 2 and isinstance(v[0], (int, float))
        },
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"][1],
            "mustrain": hap["Mustrain"][1],
        }
    try:
        out["mass_fractions"] = {
            key: [float(value[0]), float(value[1])]
            for key, value in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    cov = project.data.get("Covariance", {}).get("data", {})
    out["vary_list"] = cov.get("varyList", [])
    out["variables"] = [float(v) for v in cov.get("variables", [])]
    out["sigmas"] = [float(v) for v in cov.get("sig", [])]
    print("SNAPSHOT", json.dumps(out, sort_keys=True))
    return out


parser = argparse.ArgumentParser()
parser.add_argument("branch")
parser.add_argument("--phase", action="append", required=True, help="NAME=COD_ID")
parser.add_argument("--angular", choices=("shift", "zero"), default="shift")
parser.add_argument("--background", type=int, default=10)
args = parser.parse_args()

gpx_path = ROOT / f"branch_{args.branch}.gpx"
project = G2sc.G2Project(newgpx=str(gpx_path))
hist = project.add_powder_histogram(
    str(ROOT / "pattern.xye"), str(ROOT / "instrument.instprm"), fmthint="xye"
)
hist.Limits("lower", 10.0)
hist.Limits("upper", 100.0)
hist.set_refinements({
    "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": args.background}
})
hist.SampleParameters["Scale"] = [1.0, False]
hist.InstrumentParameters["Zero"] = [0.0, 0.0, False]
if args.angular == "shift":
    hist.SampleParameters["Shift"] = [-700.0, False]
else:
    hist.InstrumentParameters["Zero"] = [0.4, 0.4, False]
    hist.SampleParameters["Shift"] = [0.0, False]

phases = []
for idx, specification in enumerate(args.phase):
    name, cod_id = specification.split("=", 1)
    if cod_id.startswith("@"):
        phase_path = ROOT / cod_id[1:]
    else:
        phase_path = cod_path(cod_id)
    phase = project.add_phase(str(phase_path), phasename=name, histograms=[hist], fmthint="CIF")
    provisional = 0.04 if ("PbWO4" in name or "Pb7W8" in name) else None
    neutralize_hap(phase, hist.name, provisional)
    phase.set_refinements({"Cell": False})
    project.set_Controls("parmMin", 0.0, variable=f"{idx}:0:Scale")
    phases.append(phase)

project.set_Controls("cycles", 8)
project.data["Controls"]["data"]["min dM/M"] = 1e-4
if args.angular == "shift":
    project.set_Controls("parmMin", -1500.0, variable=":0:Shift")
    project.set_Controls("parmMax", 1500.0, variable=":0:Shift")
else:
    project.set_Controls("parmMin", -1.0, variable=":0:Zero")
    project.set_Controls("parmMax", 1.0, variable=":0:Zero")
project.save()

history = []
project.refine(printFile=str(ROOT / f"branch_{args.branch}.lst"))
history.append(snapshot(project, "background_scales_angular_fixed"))

if args.angular == "shift":
    project.histogram(0).SampleParameters["Shift"][1] = True
else:
    project.histogram(0).InstrumentParameters["Zero"][2] = True
project.refine(printFile=str(ROOT / f"branch_{args.branch}.lst"))
history.append(snapshot(project, "angular_reconverged"))

for phase in project.phases():
    phase.set_refinements({"Cell": True})
project.refine(printFile=str(ROOT / f"branch_{args.branch}.lst"))
history.append(snapshot(project, "cells_reconverged_1"))

project.refine(printFile=str(ROOT / f"branch_{args.branch}.lst"))
history.append(snapshot(project, "cells_reconverged_2"))

project.save()
(ROOT / f"branch_{args.branch}.json").write_text(json.dumps(history, indent=2) + "\n")
