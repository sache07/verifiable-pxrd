#!/usr/bin/env python3
"""Add one candidate to the stabilized three-phase profile and reconverge."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


parser = argparse.ArgumentParser()
parser.add_argument("name")
parser.add_argument("phase_name")
parser.add_argument("source", help="COD id or @workspace-relative CIF")
args = parser.parse_args()

project = G2sc.G2Project(
    str(ROOT / "secondary_pb3o4_size.gpx"), newgpx=str(ROOT / f"inventory_{args.name}.gpx")
)
hist = project.histogram(0)
project.set_Frozen()
project.set_Controls("cycles", 12)
project.data["Controls"]["data"]["min dM/M"] = 5e-5
if args.source.startswith("@"):
    source = ROOT / args.source[1:]
else:
    source = cod_path(args.source)
phase = project.add_phase(str(source), phasename=args.phase_name, histograms=[hist], fmthint="CIF")
hap = phase.data["Histograms"][hist.name]
hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][0] = 0.0
hap["Mustrain"][1][1] = 0.0
hap["Mustrain"][1][2] = 1.0
hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
hap["Size"][0] = "isotropic"
hap["Size"][1] = [10.0, 10.0, 1.0]
hap["Size"][2] = [False, False, False]
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = False
hap["Scale"] = [0.01, True]
phase.set_refinements({"Cell": True})
project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")

history = []
for cycle in range(3):
    project.refine(printFile=str(ROOT / f"inventory_{args.name}.lst"))
    cov = project.data["Covariance"]["data"]
    result = {
        "stage": cycle + 1,
        "residuals": hist.residuals,
        "mass_fractions": {key: list(value) for key, value in hist.ComputeMassFracs().items()},
        "phases": {
            item.name: {
                "cell": item.get_cell(),
                "scale": item.data["Histograms"][hist.name]["Scale"][0],
                "size": list(item.data["Histograms"][hist.name]["Size"][1]),
                "mustrain": list(item.data["Histograms"][hist.name]["Mustrain"][1]),
            }
            for item in project.phases()
        },
        "vary_list": cov.get("varyList", []),
        "variables": [float(v) for v in cov.get("variables", [])],
        "sigmas": [float(v) for v in cov.get("sig", [])],
        "frozen": project.get_Frozen(),
    }
    history.append(result)
    print("SNAPSHOT", json.dumps(result, sort_keys=True))

project.save()
(ROOT / f"inventory_{args.name}.json").write_text(json.dumps(history, indent=2) + "\n")
