#!/usr/bin/env python3
"""Plot a GSAS-II fit and list coherent positive residual peaks."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks, peak_widths

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("gpx")
parser.add_argument("--output", required=True)
args = parser.parse_args()

root = Path(__file__).resolve().parent
project = G2sc.G2Project(str(root / args.gpx))
hist = project.histogram(0)
x = np.asarray(hist.getdata("X"), float)
yobs = np.asarray(hist.getdata("Yobs"), float)
ycalc = np.asarray(hist.getdata("Ycalc"), float)
background = np.asarray(hist.getdata("Background"), float)
diff = np.asarray(hist.getdata("Residual"), float)
step = float(np.median(np.diff(x)))
mask = (x >= hist.Limits("lower")) & (x <= hist.Limits("upper"))

smooth = gaussian_filter1d(diff, 0.025 / step)
peaks, props = find_peaks(smooth, prominence=120, height=100, distance=max(2, int(0.08 / step)))
widths = peak_widths(smooth, peaks, rel_height=0.5)[0] * step

reflections = {}
for phase_name, values in hist.reflections().items():
    array = values["RefList"]
    # CW nuclear powder reflection rows: h,k,l,mult,d,position,...,Fobs2,Fcalc2,...
    reflections[phase_name] = [
        (float(row[5]), tuple(int(v) for v in row[:3]), float(row[9])) for row in array
    ]

rows = []
for index, width in zip(peaks, widths):
    if not mask[index]:
        continue
    assignments = []
    for phase_name, refls in reflections.items():
        close = sorted(refls, key=lambda item: abs(item[0] - x[index]))[:3]
        selected = [item for item in close if abs(item[0] - x[index]) <= max(0.20, 0.7 * width)]
        if selected:
            assignments.append(
                phase_name + ":" + ";".join(
                    f"{hkl}@{pos:.3f}(Fc2={fc2:.1f})" for pos, hkl, fc2 in selected
                )
            )
    rows.append({
        "two_theta_deg": x[index],
        "positive_residual_counts": smooth[index],
        "prominence_counts": props["prominences"][list(peaks).index(index)],
        "fwhm_deg_approx": width,
        "nearby_model_reflections": " | ".join(assignments),
    })

with (root / f"{args.output}_residual_peaks.csv").open("w", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(rows[0]) if rows else ["two_theta_deg"])
    writer.writeheader()
    writer.writerows(rows)

with (root / f"{args.output}_profile.csv").open("w", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(["two_theta_deg", "observed", "calculated", "background", "difference"])
    writer.writerows(zip(x, yobs, ycalc, background, diff))
with (root / f"{args.output}_reflections.csv").open("w", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(["phase", "two_theta_deg", "h", "k", "l", "Fcalc_squared"])
    for phase_name, refls in reflections.items():
        for pos, hkl, fc2 in refls:
            writer.writerow([phase_name, pos, *hkl, fc2])

print("residuals", hist.residuals)
try:
    print("mass fractions", hist.ComputeMassFracs())
except Exception as exc:
    print("mass fraction error", repr(exc))
for row in rows:
    print(
        f"{row['two_theta_deg']:8.3f} residual={row['positive_residual_counts']:8.1f} "
        f"prom={row['prominence_counts']:8.1f} width={row['fwhm_deg_approx']:.3f} "
        f"{row['nearby_model_reflections']}"
    )
