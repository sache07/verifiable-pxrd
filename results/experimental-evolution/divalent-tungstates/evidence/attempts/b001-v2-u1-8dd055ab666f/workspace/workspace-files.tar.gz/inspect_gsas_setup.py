#!/usr/bin/env python3
"""Create and inspect a minimal two-phase GSAS-II project."""

from pathlib import Path
from pprint import pprint

from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
cif_root = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return cif_root / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


project = G2sc.G2Project(newgpx=str(root / "setup_test.gpx"))
hist = project.add_powder_histogram(
    str(root / "pattern.xye"), str(root / "instrument.instprm"), fmthint="xye"
)
pbwo4 = project.add_phase(
    str(cod_path("9009811")), phasename="PbWO4_scheelite", histograms=[hist]
)
wo3 = project.add_phase(
    str(cod_path("2311041")), phasename="WO3_monoclinic", histograms=[hist]
)
hist.Limits("lower", 10.0)
hist.Limits("upper", 100.0)
project.save()

print("histogram", hist.name, hist.residuals)
print("instrument")
pprint(hist.InstrumentParameters)
print("sample")
pprint(hist.SampleParameters)
print("background")
pprint(hist.Background)
for phase in (pbwo4, wo3):
    print("\nPHASE", phase.name)
    print("cell", phase.get_cell())
    print("general keys", phase.data["General"].keys())
    print("atoms")
    for atom in phase.atoms():
        print(atom.label, atom.element, atom.coordinates, atom.occupancy, atom.uiso)
    print("HAP")
    pprint(phase.data["Histograms"][hist.name])
print("controls")
pprint(project.data["Controls"]["data"])
