#!/usr/bin/env python3
"""Physically screen chemically plausible PXRD candidate structures."""

from __future__ import annotations

import json
import math
import re
from pathlib import Path

import numpy as np
import pandas as pd
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
from scipy.optimize import differential_evolution, nnls


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = {
    "PbWO4_scheelite_9009811": "9009811",
    "PbWO4_scheelite_1527935": "1527935",
    "PbWO4_raspite_9007617": "9007617",
    "WO3_monoclinic_1528915": "1528915",
    "WO3_monoclinic_2311041": "2311041",
    "WO3_triclinic_2106293": "2106293",
    "WO3_HP_monoclinic_1563541": "1563541",
    "Pb3O4_ambient_9012124": "9012124",
    "Pb3O4_ambient_1537983": "1537983",
    "Pb3O4_HP_9003043": "9003043",
    "PbO_litharge_9012700": "9012700",
    "PbO_massicot_1533609": "1533609",
    "PbO_massicot_2310433": "2310433",
    "PbO2_1531016": "1531016",
    "PbO2_9007543": "9007543",
    "Pb7W8O28.8_9016035": "9016035",
    "Pb2WO5_from_Pb2MoO5_7220560": ("7220560", {"Mo": "W"}),
    "Pb2WO5_from_Pb2CrO5_8103050": ("8103050", {"Cr": "W"}),
    "Pb2WO5_from_Pb2TeO5_9015570": ("9015570", {"Te": "W"}),
}


def publication_context(path: Path) -> dict[str, str | None]:
    text = path.read_text(errors="replace")
    fields = {}
    for key in ("_publ_section_title", "_chemical_compound_source", "_diffrn_ambient_temperature"):
        # Handle both one-line and semicolon-delimited values sufficiently for screening.
        one = re.search(rf"(?m)^{re.escape(key)}\s+([^\n;].*)$", text)
        multi = re.search(rf"(?ms)^{re.escape(key)}\s*\n;\s*(.*?)\s*\n;", text)
        value = multi.group(1).strip().replace("\n", " ") if multi else (one.group(1).strip() if one else None)
        fields[key] = value
    return fields


def structure_summary(
    name: str, cod_id: str, replacement: dict[str, str] | None = None
) -> tuple[dict, Structure, list[tuple[float, float]]]:
    path = cod_path(cod_id)
    structure = Structure.from_file(path, primitive=False)
    if replacement:
        structure.replace_species(replacement)
    sga = SpacegroupAnalyzer(structure, symprec=0.02, angle_tolerance=2)
    occupied = structure.composition
    occupancies = [sum(site.species.values()) for site in structure]
    disordered = [str(site.species) for site in structure if not site.is_ordered or abs(sum(site.species.values()) - 1) > 1e-6]
    distance_matrix = structure.distance_matrix.copy()
    np.fill_diagonal(distance_matrix, np.inf)
    min_distance = float(distance_matrix.min())
    # Cation--oxygen coordination shell distances. Wide cutoff is diagnostic only.
    cation_o = {}
    for symbol in ("Pb", "W"):
        distances = []
        for i, site in enumerate(structure):
            if symbol not in [sp.symbol for sp in site.species]:
                continue
            for j, other in enumerate(structure):
                if "O" in [sp.symbol for sp in other.species]:
                    d = float(structure.get_distance(i, j))
                    if d < (3.5 if symbol == "Pb" else 2.65):
                        distances.append(d)
        cation_o[symbol] = sorted(round(v, 4) for v in distances)
    context = publication_context(path)
    calc = XRDCalculator(wavelength=1.540598)
    pattern = calc.get_pattern(structure, two_theta_range=(9.5, 101), scaled=False)
    sticks = list(zip(map(float, pattern.x), map(float, pattern.y)))
    summary = {
        "name": name,
        "cod_id": cod_id,
        "prototype_substitution": replacement,
        "path": str(path),
        "occupied_formula": occupied.formula,
        "reduced_formula": occupied.reduced_formula,
        "space_group": f"{sga.get_space_group_symbol()} ({sga.get_space_group_number()})",
        "lattice": [round(v, 6) for v in (*structure.lattice.abc, *structure.lattice.angles)],
        "volume": round(structure.volume, 5),
        "site_count": len(structure),
        "occupancy_min_max": [round(min(occupancies), 6), round(max(occupancies), 6)],
        "disordered_sites": disordered,
        "minimum_periodic_distance_A": round(min_distance, 5),
        "cation_O_distances_A": cation_o,
        "source_context": context,
    }
    return summary, structure, sticks


data = pd.read_csv(ROOT / "inputs" / "pattern.csv")
x = data.iloc[:, 0].to_numpy(float)
y = data.iloc[:, 1].to_numpy(float)
# A smooth data-derived baseline is used only for candidate discrimination, never final refinement.
from scipy.ndimage import gaussian_filter1d, percentile_filter

step = float(np.median(np.diff(x)))
baseline = percentile_filter(y, percentile=16, size=(int(round(7 / step)) | 1), mode="nearest")
baseline = gaussian_filter1d(baseline, 0.8 / step)
target = np.maximum(y - baseline, 0)
fit_mask = (x >= 15) & (x <= 98)


def profile(sticks, lattice_scale: float, displacement_deg: float, fwhm0: float, fwhm_tan: float) -> np.ndarray:
    out = np.zeros_like(x)
    for pos, area in sticks:
        theta = math.radians(pos / 2)
        arg = math.sin(theta) / lattice_scale
        if not -1 < arg < 1:
            continue
        shifted = math.degrees(2 * math.asin(arg)) + displacement_deg * math.cos(math.asin(arg))
        if shifted < x[0] - 1 or shifted > x[-1] + 1:
            continue
        theta2 = math.radians(shifted / 2)
        fwhm = math.sqrt(fwhm0 * fwhm0 + (fwhm_tan * math.tan(theta2)) ** 2)
        sigma = fwhm / 2.354820045
        lo = max(0, int(np.searchsorted(x, shifted - 4.5 * sigma)))
        hi = min(x.size, int(np.searchsorted(x, shifted + 4.5 * sigma)))
        if hi > lo:
            out[lo:hi] += area / (sigma * math.sqrt(2 * math.pi)) * np.exp(-0.5 * ((x[lo:hi] - shifted) / sigma) ** 2)
    return out


def candidate_objective(params, sticks) -> float:
    p = profile(sticks, *params)
    pm = p[fit_mask]
    tm = target[fit_mask]
    den = float(np.dot(pm, pm))
    scale = max(0.0, float(np.dot(pm, tm)) / den) if den else 0.0
    residual = tm - scale * pm
    # Weight lower-intensity regions enough to penalize unsupported extra peaks.
    weights = 1.0 / np.sqrt(np.maximum(y[fit_mask], 300))
    return float(np.mean((residual * weights) ** 2))


summaries = []
profiles = {}
for name, specification in CANDIDATES.items():
    if isinstance(specification, tuple):
        cod_id, replacement = specification
    else:
        cod_id, replacement = specification, None
    path = cod_path(cod_id)
    if not path.is_file():
        continue
    try:
        summary, structure, sticks = structure_summary(name, cod_id, replacement)
        result = differential_evolution(
            candidate_objective,
            bounds=[(0.97, 1.03), (-0.3, 0.9), (0.06, 0.55), (0.0, 0.55)],
            args=(sticks,),
            seed=20261102,
            popsize=10,
            maxiter=45,
            polish=True,
            workers=1,
        )
        p = profile(sticks, *result.x)
        pm, tm = p[fit_mask], target[fit_mask]
        scale = max(0.0, float(np.dot(pm, tm)) / float(np.dot(pm, pm)))
        residual = tm - scale * pm
        summary["single_phase_screen"] = {
            "lattice_scale": round(float(result.x[0]), 7),
            "cos_theta_shift_deg": round(float(result.x[1]), 7),
            "fwhm0_deg": round(float(result.x[2]), 7),
            "fwhm_tan_deg": round(float(result.x[3]), 7),
            "profile_scale": round(scale, 8),
            "weighted_objective": round(float(result.fun), 7),
            "unweighted_R_fraction": round(float(np.sum(np.abs(residual)) / np.sum(tm)), 6),
            "correlation": round(float(np.corrcoef(tm, scale * pm)[0, 1]), 6),
        }
        profiles[name] = scale * p
        summaries.append(summary)
    except Exception as exc:
        summaries.append({"name": name, "cod_id": cod_id, "error": repr(exc)})

(ROOT / "candidate_screen.json").write_text(json.dumps(summaries, indent=2) + "\n")

print("Candidate ranking (diagnostic full-profile screen):")
ranked = sorted(
    (s for s in summaries if "single_phase_screen" in s),
    key=lambda s: s["single_phase_screen"]["weighted_objective"],
)
for s in ranked:
    p = s["single_phase_screen"]
    print(
        f"{s['name']:<33s} obj={p['weighted_objective']:9.2f} "
        f"corr={p['correlation']:6.3f} R={p['unweighted_R_fraction']:6.3f} "
        f"cell={p['lattice_scale']:.5f} shift={p['cos_theta_shift_deg']:+.3f} "
        f"fwhm={p['fwhm0_deg']:.3f}/{p['fwhm_tan_deg']:.3f}"
    )

print("\nPhysical summaries:")
for s in summaries:
    if "error" in s:
        print(s)
        continue
    print(
        s["name"], s["occupied_formula"], s["space_group"], s["lattice"],
        "occ", s["occupancy_min_max"], "disorder", s["disordered_sites"],
        "minD", s["minimum_periodic_distance_A"], "source", s["source_context"],
    )
