#!/usr/bin/env python3
"""Convert the supplied CSV into a GSAS-II three-column xye file."""

import csv
import math
from pathlib import Path


root = Path(__file__).resolve().parent
with (root / "inputs" / "pattern.csv").open(newline="") as src, (root / "pattern.xye").open("w") as dst:
    reader = csv.DictReader(src)
    dst.write("# two_theta_deg intensity_counts poisson_sigma_counts\n")
    for row in reader:
        x = float(row["two_theta_deg"])
        y = float(row["intensity"])
        dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
