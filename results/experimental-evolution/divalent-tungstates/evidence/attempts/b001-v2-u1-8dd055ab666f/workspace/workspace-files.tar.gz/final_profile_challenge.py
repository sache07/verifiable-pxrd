#!/usr/bin/env python3
"""Challenge one phase profile term from the accepted four-phase inventory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("name")
parser.add_argument("phase")
parser.add_argument("mode", choices=("size", "strain", "add-strain"))
parser.add_argument("--source", default="inventory_massicot.gpx")
parser.add_argument("--size-start", type=float, default=1.0)
args = parser.parse_args()

project = G2sc.G2Project(
    str(ROOT / args.source), newgpx=str(ROOT / f"final_profile_{args.name}.gpx")
)
hist = project.histogram(0)
project.set_Frozen()
project.set_Controls("cycles", 12)
project.data["Controls"]["data"]["min dM/M"] = 5e-5

# The common instrumental envelope remains fixed at the sharp-phase lower
# envelope. Only the explicitly selected phase contribution is challenged.
for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
    hist.InstrumentParameters[key][2] = False

selected = project.phase(args.phase)
if selected is None:
    raise SystemExit(f"phase {args.phase!r} not found")
hap = selected.data["Histograms"][hist.name]
hap["Size"][2] = [False for _ in hap["Size"][2]]
hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]

if args.mode != "add-strain":
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][1][2] = 1.0

pidx = selected.id
if args.mode == "size":
    hap["Size"][1][0] = args.size_start
    hap["Size"][1][2] = 1.0
    hap["Size"][2][0] = True
    project.set_Controls("parmMin", 0.005, variable=f"{pidx}:0:Size;i")
    project.set_Controls("parmMax", 10.0, variable=f"{pidx}:0:Size;i")
else:
    # For add-strain, retain an already-supported size term and release only
    # the isotropic strain contribution from its neutral value.
    if args.mode == "add-strain":
        hap["Size"][2][0] = True
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2][0] = True
    project.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Mustrain;i")
    project.set_Controls("parmMax", 10000.0, variable=f"{pidx}:0:Mustrain;i")

history = []
for cycle in range(3):
    project.refine(printFile=str(ROOT / f"final_profile_{args.name}.lst"))
    cov = project.data.get("Covariance", {}).get("data", {})
    history.append(
        {
            "stage": cycle + 1,
            "residuals": hist.residuals,
            "mass_fractions": {
                key: list(value) for key, value in hist.ComputeMassFracs().items()
            },
            "profiles": {
                phase.name: {
                    "size": list(phase.data["Histograms"][hist.name]["Size"][1]),
                    "size_flags": list(
                        phase.data["Histograms"][hist.name]["Size"][2]
                    ),
                    "mustrain": list(
                        phase.data["Histograms"][hist.name]["Mustrain"][1]
                    ),
                    "mustrain_flags": list(
                        phase.data["Histograms"][hist.name]["Mustrain"][2]
                    ),
                }
                for phase in project.phases()
            },
            "vary_list": cov.get("varyList", []),
            "variables": [float(value) for value in cov.get("variables", [])],
            "sigmas": [float(value) for value in cov.get("sig", [])],
            "frozen": project.get_Frozen(),
        }
    )
    print("SNAPSHOT", json.dumps(history[-1], sort_keys=True))

project.save()
(ROOT / f"final_profile_{args.name}.json").write_text(
    json.dumps(history, indent=2) + "\n"
)
