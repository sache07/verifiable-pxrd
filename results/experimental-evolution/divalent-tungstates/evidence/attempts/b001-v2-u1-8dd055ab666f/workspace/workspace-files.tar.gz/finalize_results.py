#!/usr/bin/env python3
"""Create, replay-check and export the final GSAS-II Rietveld model."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "combined_atomic_pb3o4_only.gpx"
FINAL = ROOT / "final.gpx"

FORMULAS = {
    "PbWO4": "PbWO4",
    "WO3": "WO3",
    "Pb3O4": "Pb3O4",
    "PbO_massicot": "PbO",
}
DISPLAY_NAMES = {
    "PbWO4": "PbWO4 (scheelite)",
    "WO3": "WO3 (monoclinic)",
    "Pb3O4": "Pb3O4 (minium)",
    "PbO_massicot": "PbO (massicot)",
}
CIF_NAMES = {
    "PbWO4": "phase_PbWO4_scheelite.cif",
    "WO3": "phase_WO3_monoclinic.cif",
    "Pb3O4": "phase_Pb3O4_minium.cif",
    "PbO_massicot": "phase_PbO_massicot.cif",
}
SOURCES = {
    "PbWO4": {"database": "COD", "record": "9009811"},
    "WO3": {"database": "COD", "record": "2311041"},
    "Pb3O4": {"database": "COD", "record": "9012124"},
    "PbO_massicot": {"database": "COD", "record": "2310433"},
}


def configure(project: G2sc.G2Project) -> None:
    """Prune the project to the accepted low-dimensional refinement model."""
    hist = project.histogram(0)
    hist.data["Limits"][1][:] = list(hist.data["Limits"][0])
    project.set_Frozen()
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    project.set_Controls("cycles", 20)
    controls["min dM/M"] = 1e-6

    # A single common specimen-displacement correction is used. Zero and all
    # profile coefficients remain fixed to avoid correlated compensation.
    for key, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Shift"][1] = True
    for key, value in hist.InstrumentParameters.items():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
            value[2] = False
    hist.data["Background"][0][1] = True
    project.set_Controls("parmMin", -1500.0, variable=":0:Shift")
    project.set_Controls("parmMax", 1500.0, variable=":0:Shift")

    for phase in project.phases():
        phase.set_refinements({"Cell": True, "Atoms": {"all": " "}, "LeBail": False})
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        hap["Scale"][1] = True
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        for key in ("BabA", "BabU"):
            hap["Babinet"][key] = [0.0, False]
        hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")

        if phase.name in {"PbWO4", "Pb3O4", "PbO_massicot"}:
            hap["Size"][1][1:] = [10.0, 1.0]
            hap["Size"][2][0] = True
            hap["Mustrain"][1] = [0.0, 0.0, 1.0]
            project.set_Controls(
                "parmMin", 0.005, variable=f"{phase.id}:0:Size;i"
            )
            project.set_Controls(
                "parmMax", 10.0, variable=f"{phase.id}:0:Size;i"
            )
        elif phase.name == "WO3":
            hap["Size"][1] = [10.0, 10.0, 1.0]
            hap["Mustrain"][1][1:] = [0.0, 1.0]
            hap["Mustrain"][2][0] = True
            project.set_Controls(
                "parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i"
            )
            project.set_Controls(
                "parmMax", 10000.0, variable=f"{phase.id}:0:Mustrain;i"
            )

    # This is the only accepted coordinate group. All oxygen coordinates and
    # the other minor-phase coordinates retain their vetted source values.
    project.phase("Pb3O4").set_refinements({"Atoms": {"Pb2+": "X"}})


def replay(label: str) -> None:
    project = G2sc.G2Project(str(FINAL))
    configure(project)
    project.save()
    project.refine(printFile=str(ROOT / "final.lst"))
    project.save()
    if project.get_Frozen():
        raise RuntimeError(f"{label}: frozen variables remain: {project.get_Frozen()}")
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    if not rvals.get("converged", False):
        raise RuntimeError(f"{label}: refinement did not converge")
    print(
        label,
        "Rwp=", project.histogram(0).residuals.get("wR"),
        "max_shift_esd=", rvals.get("Max shft/sig"),
    )


# Build a clean project, save it, reopen it and perform two independent native
# replays. The second replay is the state used for every export below.
project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
configure(project)
project.save()
del project
replay("full-range replay 1")
replay("full-range replay 2")

project = G2sc.G2Project(str(FINAL))
hist = project.histogram(0)
if project.get_Frozen():
    raise RuntimeError(f"final project has frozen variables: {project.get_Frozen()}")
if not all(not phase.data["Histograms"][hist.name]["LeBail"] for phase in project.phases()):
    raise RuntimeError("final project is not an atomic Rietveld model")

# Export structures directly from the replay-checked project.
for phase in project.phases():
    phase.export_CIF(str(ROOT / CIF_NAMES[phase.name]))

x = np.asarray(hist.getdata("X"), dtype=float)
yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
if len(x) != 8301 or not np.all(np.isfinite(ycalc)):
    raise RuntimeError("final calculated profile is incomplete")
with (ROOT / "fit.csv").open("w", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
    writer.writerows(zip(x, yobs, ycalc, yobs - ycalc))

raw_fractions = hist.ComputeMassFracs()
fraction_sum = sum(value[0] for value in raw_fractions.values())
covariance = project.data["Covariance"]["data"]
rvals = covariance.get("Rvals", {})
phase_results = []
for phase in project.phases():
    fraction, esd = raw_fractions[phase.name]
    cell = {key: float(value) for key, value in phase.get_cell().items()}
    hap = phase.data["Histograms"][hist.name]
    entry = {
        "name": DISPLAY_NAMES[phase.name],
        "formula": FORMULAS[phase.name],
        "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
        "cif_path": CIF_NAMES[phase.name],
        "weight_fraction": float(fraction / fraction_sum),
        "weight_fraction_esd_formal": float(esd / fraction_sum),
        "cell": cell,
        "structure_source": SOURCES[phase.name],
        "R_F_percent": float(hist.residuals[f"{phase.id}:0:Rf"]),
        "R_F_squared_percent": float(hist.residuals[f"{phase.id}:0:Rf^2"]),
    }
    if hap["Size"][2][0]:
        entry["isotropic_size_micrometre"] = float(hap["Size"][1][0])
    if hap["Mustrain"][2][0]:
        entry["isotropic_microstrain"] = float(hap["Mustrain"][1][0])
    phase_results.append(entry)

nobs = int(rvals.get("Nobs", len(x)))
nvars = int(rvals.get("Nvars", len(covariance.get("varyList", []))))
chisq = float(rvals.get("chisq", math.nan))
result = {
    "project_path": "final.gpx",
    "fit_profile_path": "fit.csv",
    "fraction_basis": (
        "Normalized over the modeled crystalline phases; amorphous or "
        "unmodeled material is not quantified."
    ),
    "phases": phase_results,
    "fit_statistics": {
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "Rexp_percent": float(hist.residuals["wRmin"]),
        "goodness_of_fit": float(rvals.get("GOF", hist.residuals["wR"] / hist.residuals["wRmin"])),
        "chi_square": chisq,
        "reduced_chi_square": float(chisq / (nobs - nvars)),
        "observations": nobs,
        "refined_parameters": nvars,
    },
    "measurement": {
        "radiation": "Cu Kalpha1/Kalpha2",
        "wavelength_1_angstrom": 1.540598,
        "wavelength_2_angstrom": 1.544426,
        "I_Kalpha2_over_I_Kalpha1": 0.5,
        "two_theta_min_deg": float(x.min()),
        "two_theta_max_deg": float(x.max()),
        "points": int(len(x)),
    },
    "replay_check": {
        "converged": bool(rvals.get("converged", False)),
        "maximum_shift_over_esd": float(rvals.get("Max shft/sig", math.nan)),
        "frozen_variables": list(project.get_Frozen()),
        "Le_Bail": False,
    },
}
(ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
