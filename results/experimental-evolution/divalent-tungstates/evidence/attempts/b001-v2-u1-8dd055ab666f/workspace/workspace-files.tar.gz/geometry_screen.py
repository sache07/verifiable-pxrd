#!/usr/bin/env python3
"""Report CIF composition, symmetry, occupancies and nearest metal–O distances."""

from __future__ import annotations

import argparse
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


parser = argparse.ArgumentParser()
parser.add_argument("cifs", nargs="+")
args = parser.parse_args()

for filename in args.cifs:
    structure = Structure.from_file(filename)
    analyzer = SpacegroupAnalyzer(structure, symprec=0.02, angle_tolerance=2)
    print(
        f"{Path(filename).name}: formula={structure.composition.reduced_formula} "
        f"SG={analyzer.get_space_group_symbol()}({analyzer.get_space_group_number()}) "
        f"sites={len(structure)}"
    )
    for index, site in enumerate(structure):
        symbol = site.specie.symbol
        if symbol == "O":
            continue
        distances = sorted(
            neighbor.nn_distance
            for neighbor in structure.get_neighbors(site, 3.25)
            if neighbor.specie.symbol == "O"
        )
        compact = ", ".join(f"{value:.3f}" for value in distances[:12])
        print(f"  {index:3d} {symbol:2s} occ={site.species.num_atoms:.3f}: {compact}")
