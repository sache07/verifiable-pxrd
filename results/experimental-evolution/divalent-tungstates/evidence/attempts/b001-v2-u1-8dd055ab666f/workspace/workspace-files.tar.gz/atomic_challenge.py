#!/usr/bin/env python3
"""Test a small, explicitly selected set of atomic coordinates."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("name")
parser.add_argument("phase")
parser.add_argument("labels", nargs="*")
parser.add_argument("--source", default="final_profile_combined_wo3_strain.gpx")
args = parser.parse_args()

project = G2sc.G2Project(
    str(ROOT / args.source), newgpx=str(ROOT / f"atomic_{args.name}.gpx")
)
hist = project.histogram(0)
project.set_Frozen()
project.set_Controls("cycles", 12)
project.data["Controls"]["data"]["min dM/M"] = 5e-5

# Atom-coordinate challenges are isolated from each other. All source atomic
# parameters remain fixed except the labels named on the command line.
for phase in project.phases():
    phase.set_refinements({"Atoms": {"all": " "}})
selected = project.phase(args.phase)
if selected is None:
    raise SystemExit(f"phase {args.phase!r} not found")
if args.labels:
    selected.set_refinements({"Atoms": {label: "X" for label in args.labels}})

history = []
for cycle in range(3):
    project.refine(printFile=str(ROOT / f"atomic_{args.name}.lst"))
    cov = project.data.get("Covariance", {}).get("data", {})
    history.append(
        {
            "stage": cycle + 1,
            "residuals": hist.residuals,
            "mass_fractions": {
                key: list(value) for key, value in hist.ComputeMassFracs().items()
            },
            "atoms": {
                phase.name: [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": list(atom.coordinates),
                        "occupancy": atom.occupancy,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ]
                for phase in project.phases()
            },
            "vary_list": cov.get("varyList", []),
            "variables": [float(value) for value in cov.get("variables", [])],
            "sigmas": [float(value) for value in cov.get("sig", [])],
            "frozen": project.get_Frozen(),
        }
    )
    print("SNAPSHOT", json.dumps(history[-1], sort_keys=True))

project.save()
(ROOT / f"atomic_{args.name}.json").write_text(json.dumps(history, indent=2) + "\n")
