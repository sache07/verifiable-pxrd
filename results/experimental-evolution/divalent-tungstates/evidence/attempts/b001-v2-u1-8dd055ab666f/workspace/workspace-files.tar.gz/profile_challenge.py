#!/usr/bin/env python3
"""Challenge one phase at a time with size-only or strain-only broadening."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("name")
parser.add_argument("phase")
parser.add_argument("mode", choices=("size", "strain"))
parser.add_argument("--size-start", type=float, default=10.0)
parser.add_argument("--mix", type=float, default=1.0)
args = parser.parse_args()

project = G2sc.G2Project(
    str(ROOT / "branch_add_pb3o4.gpx"), newgpx=str(ROOT / f"profile_{args.name}.gpx")
)
hist = project.histogram(0)
project.set_Frozen()
project.set_Controls("cycles", 12)
project.data["Controls"]["data"]["min dM/M"] = 5e-5


def profile_state(phase):
    hap = phase.data["Histograms"][hist.name]
    return {
        "scale": hap["Scale"][0],
        "size": list(hap["Size"][1]),
        "size_flags": list(hap["Size"][2]),
        "mustrain": list(hap["Mustrain"][1]),
        "mustrain_flags": list(hap["Mustrain"][2]),
        "cell": phase.get_cell(),
    }


def snapshot(label):
    project.save()
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "stage": label,
        "residuals": hist.residuals,
        "mass_fractions": {
            key: list(value) for key, value in hist.ComputeMassFracs().items()
        },
        "profiles": {phase.name: profile_state(phase) for phase in project.phases()},
        "instrument": {key: value[1] for key, value in hist.InstrumentParameters.items() if isinstance(value, list) and len(value) > 1},
        "sample_shift": hist.SampleParameters["Shift"][0],
        "vary_list": cov.get("varyList", []),
        "variables": [float(v) for v in cov.get("variables", [])],
        "sigmas": [float(v) for v in cov.get("sig", [])],
        "frozen": project.get_Frozen(),
    }
    print("SNAPSHOT", json.dumps(result, sort_keys=True))
    return result


# Reset every phase to the neutral profile before testing any one contribution.
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][1][2] = 1.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]

project.save()
project.refine(printFile=str(ROOT / f"profile_{args.name}.lst"))
history = [snapshot("neutral_reconverged")]

selected = project.phase(args.phase)
if selected is None:
    raise SystemExit(f"phase {args.phase!r} not found")
pidx = selected.id
hap = selected.data["Histograms"][hist.name]
if args.mode == "size":
    hap["Size"][1][0] = args.size_start
    hap["Size"][1][2] = args.mix
    hap["Size"][2][0] = True
    project.set_Controls("parmMin", 0.005, variable=f"{pidx}:0:Size;i")
    project.set_Controls("parmMax", 10.0, variable=f"{pidx}:0:Size;i")
else:
    hap["Mustrain"][2][0] = True
    project.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Mustrain;i")
    project.set_Controls("parmMax", 10000.0, variable=f"{pidx}:0:Mustrain;i")

project.refine(printFile=str(ROOT / f"profile_{args.name}.lst"))
history.append(snapshot("profile_reconverged_1"))
project.refine(printFile=str(ROOT / f"profile_{args.name}.lst"))
history.append(snapshot("profile_reconverged_2"))
project.save()
(ROOT / f"profile_{args.name}.json").write_text(json.dumps(history, indent=2) + "\n")
