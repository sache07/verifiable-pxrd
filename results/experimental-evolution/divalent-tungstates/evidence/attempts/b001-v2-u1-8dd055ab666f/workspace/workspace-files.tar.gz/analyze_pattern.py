#!/usr/bin/env python3
"""Extract robust peak positions and widths from the supplied PXRD pattern."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter1d, percentile_filter
from scipy.signal import find_peaks, peak_widths


ROOT = Path(__file__).resolve().parent
data = pd.read_csv(ROOT / "inputs" / "pattern.csv")
x = data.iloc[:, 0].to_numpy(float)
y = data.iloc[:, 1].to_numpy(float)
step = float(np.median(np.diff(x)))

# A broad 8-degree lower-percentile envelope follows the fluorescence/air background
# without absorbing ordinary Bragg peaks. Smooth lightly only for peak discovery.
window = max(101, int(round(8.0 / step)) | 1)
background = percentile_filter(y, percentile=18, size=window, mode="nearest")
background = gaussian_filter1d(background, 1.0 / step)
net = y - background
smooth = gaussian_filter1d(net, 0.018 / step)

noise = 1.4826 * np.median(np.abs((y - gaussian_filter1d(y, 0.08 / step))))
peaks, properties = find_peaks(
    smooth,
    prominence=max(7 * noise, 180.0),
    height=max(10 * noise, 250.0),
    distance=max(2, int(round(0.07 / step))),
)
width_samples, _, left_ips, right_ips = peak_widths(smooth, peaks, rel_height=0.5)

rows = []
for rank, (idx, prom, width, left, right) in enumerate(
    zip(peaks, properties["prominences"], width_samples, left_ips, right_ips), start=1
):
    rows.append(
        {
            "two_theta_deg": x[idx],
            "d_angstrom_CuKa1": 1.540598 / (2 * np.sin(np.deg2rad(x[idx] / 2))),
            "intensity_counts": y[idx],
            "net_height": smooth[idx],
            "prominence": prom,
            "fwhm_deg_approx": width * step,
            "left_deg": np.interp(left, np.arange(x.size), x),
            "right_deg": np.interp(right, np.arange(x.size), x),
        }
    )

peaks_df = pd.DataFrame(rows).sort_values("two_theta_deg")
peaks_df.to_csv(ROOT / "peak_list.csv", index=False)

fig, axes = plt.subplots(2, 1, figsize=(15, 9), constrained_layout=True)
for ax, limits in zip(axes, [(9.9, 55), (50, 100.1)]):
    mask = (x >= limits[0]) & (x <= limits[1])
    ax.plot(x[mask], y[mask], color="black", lw=0.65)
    ax.plot(x[mask], background[mask], color="tab:orange", lw=0.8)
    selected = peaks_df[
        (peaks_df.two_theta_deg >= limits[0]) & (peaks_df.two_theta_deg <= limits[1])
    ]
    ax.scatter(selected.two_theta_deg, selected.intensity_counts, s=9, color="tab:red")
    for row in selected.itertuples():
        if row.prominence > np.percentile(peaks_df.prominence, 55):
            ax.text(row.two_theta_deg, row.intensity_counts, f"{row.two_theta_deg:.2f}",
                    rotation=90, va="bottom", ha="center", fontsize=6)
    ax.set_xlim(*limits)
    ax.set_ylabel("counts")
axes[-1].set_xlabel(r"$2\theta$ (degrees)")
fig.savefig(ROOT / "pattern_peaks.png", dpi=180)

print(f"points={x.size} range={x[0]:.6f}..{x[-1]:.6f} step={step:.8f}")
print(f"intensity min/median/max={y.min():.1f}/{np.median(y):.1f}/{y.max():.1f}")
print(f"robust high-frequency noise={noise:.2f} counts; detected peaks={len(peaks_df)}")
print(peaks_df.to_string(index=False, formatters={
    "two_theta_deg": "{:.5f}".format,
    "d_angstrom_CuKa1": "{:.5f}".format,
    "intensity_counts": "{:.0f}".format,
    "net_height": "{:.0f}".format,
    "prominence": "{:.0f}".format,
    "fwhm_deg_approx": "{:.4f}".format,
    "left_deg": "{:.4f}".format,
    "right_deg": "{:.4f}".format,
}))
