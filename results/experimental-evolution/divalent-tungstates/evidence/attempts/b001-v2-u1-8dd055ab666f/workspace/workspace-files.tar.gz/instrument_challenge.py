#!/usr/bin/env python3
"""Refine a bounded low-dimensional common instrument-width branch."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("name")
parser.add_argument("--parameters", nargs="+", choices=("U", "W", "X"), required=True)
args = parser.parse_args()

project = G2sc.G2Project(
    str(ROOT / "profile_pbwo4_size_L.gpx"), newgpx=str(ROOT / f"instrument_{args.name}.gpx")
)
hist = project.histogram(0)
project.set_Frozen()
project.set_Controls("cycles", 12)
project.data["Controls"]["data"]["min dM/M"] = 5e-5

for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
    hist.InstrumentParameters[key][2] = False
for key in args.parameters:
    hist.InstrumentParameters[key][2] = True
    project.set_Controls("parmMin", 0.0, variable=f":0:{key}")
    project.set_Controls("parmMax", 200.0, variable=f":0:{key}")

history = []
for cycle in range(2):
    project.refine(printFile=str(ROOT / f"instrument_{args.name}.lst"))
    cov = project.data["Covariance"]["data"]
    result = {
        "stage": cycle + 1,
        "residuals": hist.residuals,
        "mass_fractions": {key: list(value) for key, value in hist.ComputeMassFracs().items()},
        "instrument": {key: value[1] for key, value in hist.InstrumentParameters.items() if isinstance(value, list) and len(value) > 1},
        "profiles": {
            phase.name: {
                "size": list(phase.data["Histograms"][hist.name]["Size"][1]),
                "mustrain": list(phase.data["Histograms"][hist.name]["Mustrain"][1]),
            }
            for phase in project.phases()
        },
        "vary_list": cov.get("varyList", []),
        "variables": [float(v) for v in cov.get("variables", [])],
        "sigmas": [float(v) for v in cov.get("sig", [])],
        "frozen": project.get_Frozen(),
    }
    history.append(result)
    print("SNAPSHOT", json.dumps(result, sort_keys=True))

project.save()
(ROOT / f"instrument_{args.name}.json").write_text(json.dumps(history, indent=2) + "\n")
