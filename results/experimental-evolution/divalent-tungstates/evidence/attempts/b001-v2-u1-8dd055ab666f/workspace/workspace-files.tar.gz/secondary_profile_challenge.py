#!/usr/bin/env python3
"""Test broadening for a minor phase while retaining accepted PbWO4 size."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("name")
parser.add_argument("phase")
parser.add_argument("mode", choices=("size", "strain"))
args = parser.parse_args()

project = G2sc.G2Project(
    str(ROOT / "profile_pbwo4_size_L.gpx"), newgpx=str(ROOT / f"secondary_{args.name}.gpx")
)
hist = project.histogram(0)
project.set_Frozen()
project.set_Controls("cycles", 12)
project.data["Controls"]["data"]["min dM/M"] = 5e-5
for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
    hist.InstrumentParameters[key][2] = False

selected = project.phase(args.phase)
if selected is None:
    raise SystemExit(f"phase {args.phase!r} not found")
hap = selected.data["Histograms"][hist.name]
hap["Size"][0] = "isotropic"
hap["Size"][1] = [10.0, 10.0, 1.0]
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][0] = 0.0
hap["Mustrain"][1][1] = 0.0
hap["Mustrain"][1][2] = 1.0
hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]

pidx = selected.id
if args.mode == "size":
    # One micron is effectively neutral for this dataset but has a usable derivative.
    hap["Size"][1][0] = 1.0
    hap["Size"][2][0] = True
    project.set_Controls("parmMin", 0.005, variable=f"{pidx}:0:Size;i")
    project.set_Controls("parmMax", 10.0, variable=f"{pidx}:0:Size;i")
else:
    hap["Mustrain"][2][0] = True
    project.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Mustrain;i")
    project.set_Controls("parmMax", 10000.0, variable=f"{pidx}:0:Mustrain;i")

history = []
for cycle in range(2):
    project.refine(printFile=str(ROOT / f"secondary_{args.name}.lst"))
    cov = project.data["Covariance"]["data"]
    result = {
        "stage": cycle + 1,
        "residuals": hist.residuals,
        "mass_fractions": {key: list(value) for key, value in hist.ComputeMassFracs().items()},
        "profiles": {
            phase.name: {
                "size": list(phase.data["Histograms"][hist.name]["Size"][1]),
                "size_flags": list(phase.data["Histograms"][hist.name]["Size"][2]),
                "mustrain": list(phase.data["Histograms"][hist.name]["Mustrain"][1]),
                "mustrain_flags": list(phase.data["Histograms"][hist.name]["Mustrain"][2]),
            }
            for phase in project.phases()
        },
        "vary_list": cov.get("varyList", []),
        "variables": [float(v) for v in cov.get("variables", [])],
        "sigmas": [float(v) for v in cov.get("sig", [])],
        "frozen": project.get_Frozen(),
    }
    history.append(result)
    print("SNAPSHOT", json.dumps(result, sort_keys=True))

project.save()
(ROOT / f"secondary_{args.name}.json").write_text(json.dumps(history, indent=2) + "\n")
