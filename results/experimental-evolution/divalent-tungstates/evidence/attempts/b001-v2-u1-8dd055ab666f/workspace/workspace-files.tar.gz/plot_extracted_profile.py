#!/usr/bin/env python3
"""Plot profile and reflection files extracted from a GSAS-II project."""

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


parser = argparse.ArgumentParser()
parser.add_argument("stem")
args = parser.parse_args()
root = Path(__file__).resolve().parent
data = pd.read_csv(root / f"{args.stem}_profile.csv")
refs = pd.read_csv(root / f"{args.stem}_reflections.csv")
peaks = pd.read_csv(root / f"{args.stem}_residual_peaks.csv")

fig, axes = plt.subplots(
    3, 1, figsize=(15, 10), constrained_layout=True,
    gridspec_kw={"height_ratios": [3, 3, 1.25]},
)
ranges = [(10, 55), (50, 100)]
colors = ["tab:blue", "tab:orange", "tab:green", "tab:red", "tab:purple"]
for ax, limits in zip(axes[:2], ranges):
    local = data.two_theta_deg.between(*limits)
    ax.plot(data.two_theta_deg[local], data.observed[local], color="black", lw=0.65, label="observed")
    ax.plot(data.two_theta_deg[local], data.calculated[local], color="tab:red", lw=0.75, label="calculated")
    ax.plot(data.two_theta_deg[local], data.background[local], color="tab:gray", lw=0.6, label="background")
    offset = data.observed[local].min() - 180
    for pidx, (phase_name, group) in enumerate(refs.groupby("phase", sort=False)):
        positions = group.two_theta_deg[group.two_theta_deg.between(*limits)]
        ax.vlines(positions, offset - 65 * pidx, offset - 65 * (pidx + 0.7), color=colors[pidx], lw=0.45, label=phase_name)
    ax.set_xlim(*limits)
    ax.set_ylabel("counts")
    ax.legend(ncol=3, fontsize=7, loc="upper right")

local = data.two_theta_deg.between(10, 100)
axes[2].plot(data.two_theta_deg[local], data.difference[local], color="black", lw=0.55)
axes[2].axhline(0, color="tab:gray", lw=0.6)
if not peaks.empty:
    axes[2].scatter(peaks.two_theta_deg, peaks.positive_residual_counts, s=9, color="tab:red")
axes[2].set_xlim(10, 100)
axes[2].set_ylabel("obs − calc")
axes[2].set_xlabel(r"$2\theta$ (degrees)")
fig.savefig(root / f"{args.stem}.png", dpi=180)
