#!/usr/bin/env python3
"""Reconverge a small set of jointly supported atomic coordinates."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("name")
parser.add_argument("spec", nargs="+", help="phase=atom-label")
parser.add_argument("--source", default="atomic_baseline.gpx")
args = parser.parse_args()

project = G2sc.G2Project(
    str(ROOT / args.source), newgpx=str(ROOT / f"combined_atomic_{args.name}.gpx")
)
hist = project.histogram(0)
project.set_Frozen()
project.set_Controls("cycles", 16)
project.data["Controls"]["data"]["min dM/M"] = 2e-5
for phase in project.phases():
    phase.set_refinements({"Atoms": {"all": " "}})
for item in args.spec:
    phase_name, label = item.split("=", 1)
    phase = project.phase(phase_name)
    if phase is None:
        raise SystemExit(f"phase {phase_name!r} not found")
    phase.set_refinements({"Atoms": {label: "X"}})

history = []
for cycle in range(4):
    project.refine(printFile=str(ROOT / f"combined_atomic_{args.name}.lst"))
    cov = project.data.get("Covariance", {}).get("data", {})
    history.append(
        {
            "stage": cycle + 1,
            "residuals": hist.residuals,
            "mass_fractions": {
                key: list(value) for key, value in hist.ComputeMassFracs().items()
            },
            "atoms": {
                phase.name: [
                    {
                        "label": atom.label,
                        "coordinates": list(atom.coordinates),
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ]
                for phase in project.phases()
            },
            "vary_list": cov.get("varyList", []),
            "variables": [float(value) for value in cov.get("variables", [])],
            "sigmas": [float(value) for value in cov.get("sig", [])],
            "frozen": project.get_Frozen(),
        }
    )
    print("SNAPSHOT", json.dumps(history[-1], sort_keys=True))

project.save()
(ROOT / f"combined_atomic_{args.name}.json").write_text(
    json.dumps(history, indent=2) + "\n"
)
