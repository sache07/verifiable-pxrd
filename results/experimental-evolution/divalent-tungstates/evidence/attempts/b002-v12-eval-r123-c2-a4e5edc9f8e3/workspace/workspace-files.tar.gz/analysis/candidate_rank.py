#!/usr/bin/env python3
"""Fit MgWO4 plus each exact-formula WO3 source from a common neutral model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
MGWO4 = COD / "9/01/39/9013902.cif"


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make_neutral(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"] = [0.5, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def snapshot(project, stage: str) -> dict:
    hist = project.histogram(0)
    result = {
        "stage": stage,
        "Rwp_percent": float(hist.data["data"][0].get("wR", float("nan"))),
        "Rp_percent": float(hist.data["data"][0].get("R", float("nan"))),
        "GOF": float(project.data["Covariance"]["data"].get("Rvals", {}).get("GOF", float("nan"))),
        "zero_deg": float(hist.data["Instrument Parameters"][0]["Zero"][1]),
        "background": [float(v) for v in hist.data["Background"][0][3:]],
        "phases": {},
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }
    try:
        mass = hist.ComputeMassFracs()
    except Exception as exc:
        result["mass_fraction_error"] = str(exc)
        mass = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "scale": float(hap["Scale"][0]),
            "weight_fraction": float(mass.get(phase.name, (float("nan"), 0.0))[0]),
            "weight_fraction_esd": float(mass.get(phase.name, (0.0, float("nan")))[1]),
            "cell": {k: float(v) for k, v in phase.get_cell().items()},
        }
    return result


def fit_source(cod_id: str, out_dir: Path) -> dict:
    source = cod_path(cod_id)
    gpx = out_dir / f"wo3_{cod_id}.gpx"
    project = G2sc.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [3600.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": True,
            },
        }
    )
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][1] = 30.0
    inst["W"][1] = 0.0
    inst["X"][1] = 10.0
    inst["U"][2] = inst["W"][2] = inst["X"][2] = False
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]

    mg = project.add_phase(
        str(MGWO4), phasename="MgWO4", histograms=[hist], fmthint="CIF"
    )
    wo = project.add_phase(
        str(source), phasename=f"WO3_{cod_id}", histograms=[hist], fmthint="CIF"
    )
    make_neutral(mg, hist.name)
    make_neutral(wo, hist.name)
    mg.data["Histograms"][hist.name]["Scale"][0] = 70.0
    wo.data["Histograms"][hist.name]["Scale"][0] = 15.0

    project.set_Controls("cycles", 5)
    project.save()
    project.refine()
    neutral = snapshot(project, "neutral_source_cell")
    project.save(str(out_dir / f"wo3_{cod_id}_neutral.gpx"))

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.histogram(0).set_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Controls("cycles", 8)
    project.refine()
    project.refine()
    elaborated = snapshot(project, "cell_plus_zero")
    project.save(str(gpx))
    return {
        "cod_id": cod_id,
        "source": str(source),
        "project": str(gpx),
        "neutral": neutral,
        "elaborated": elaborated,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("cod_ids", nargs="+")
    parser.add_argument("--out", default=str(ROOT / ".tmp/source-ranking"))
    args = parser.parse_args()
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    results = []
    for cod_id in args.cod_ids:
        print(f"SOURCE_START {cod_id}", flush=True)
        try:
            result = fit_source(cod_id, out_dir)
        except Exception as exc:
            result = {"cod_id": cod_id, "error": repr(exc)}
        results.append(result)
        (out_dir / "ranking.json").write_text(json.dumps(results, indent=2) + "\n")
        if "error" in result:
            print(f"SOURCE_ERROR {cod_id} {result['error']}", flush=True)
        else:
            print(
                "SOURCE_DONE",
                cod_id,
                result["neutral"]["Rwp_percent"],
                result["elaborated"]["Rwp_percent"],
                result["elaborated"]["phases"][f"WO3_{cod_id}"]["weight_fraction"],
                flush=True,
            )


if __name__ == "__main__":
    main()
