#!/usr/bin/env python3
"""Challenge the converged MgWO4/WO3 model with residual MgO."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp/replay-common-profile/UWX.gpx"
MGO = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/9/00/04/9000499.cif"
)
OUT = ROOT / ".tmp/mgo-challenge"


def make_neutral(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Scale"] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def snapshot(project: G2sc.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    mass = hist.ComputeMassFracs()
    result = {
        "stage": stage,
        "Rwp_percent": float(hist.data["data"][0]["wR"]),
        "Rp_percent": float(hist.data["data"][0]["R"]),
        "GOF": float(rvals.get("GOF", float("nan"))),
        "frozen": project.get_Frozen(),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "scale": float(hap["Scale"][0]),
            "weight_fraction": float(mass[phase.name][0]),
            "weight_fraction_esd": float(mass[phase.name][1]),
            "cell": {key: float(value) for key, value in phase.get_cell().items()},
        }
    return result


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(gpxfile=str(BASE))
    hist = project.histogram(0)
    mgo = project.add_phase(
        str(MGO), phasename="MgO", histograms=[hist], fmthint="CIF"
    )
    make_neutral(mgo, hist.name)
    project.set_Controls("parmMin", 0.0, variable="2:0:Scale")
    project.set_Controls("cycles", 10)
    project.save(str(OUT / "mgo_scale_start.gpx"))
    project.refine()
    project.refine()
    scale_only = snapshot(project, "fixed_source_cell")
    project.save(str(OUT / "mgo_scale.gpx"))

    mgo.set_refinements({"Cell": True})
    project.refine()
    project.refine()
    cell = snapshot(project, "refined_cell")
    project.save(str(OUT / "mgo_cell.gpx"))

    result = {"source": str(MGO), "scale_only": scale_only, "cell": cell}
    (OUT / "challenge.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
