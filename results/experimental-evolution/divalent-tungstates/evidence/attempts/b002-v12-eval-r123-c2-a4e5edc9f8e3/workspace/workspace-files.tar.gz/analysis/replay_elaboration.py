#!/usr/bin/env python3
"""Replay profile, background, specimen terms and texture after MgO retention."""

from __future__ import annotations

import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/replay-after-mgo/width_p1_combined.gpx"
OUT = ROOT / ".tmp/replay-elaboration"


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    mass = hist.ComputeMassFracs()
    nobs = int(rvals.get("Nobs", hist.data["data"][0].get("Nobs", 0)))
    nvars = int(rvals.get("Nvars", len(cov.get("varyList", []))))
    chisq = float(rvals.get("chisq", float("nan")))
    inst = hist.data["Instrument Parameters"][0]
    result = {
        "label": label,
        "Rwp_percent": float(hist.data["data"][0]["wR"]),
        "Rp_percent": float(hist.data["data"][0]["R"]),
        "GOF": float(rvals.get("GOF", float("nan"))),
        "chisq": chisq,
        "Nobs": nobs,
        "Nvars": nvars,
        "BIC": chisq + nvars * math.log(nobs) if nobs else float("nan"),
        "frozen": project.get_Frozen(),
        "profile": {key: float(inst[key][1]) for key in ("U", "W", "X")},
        "profile_refine": {key: bool(inst[key][2]) for key in ("U", "W", "X")},
        "polarization": float(inst["Polariz."][1]),
        "polarization_refine": bool(inst["Polariz."][2]),
        "background": [float(value) for value in hist.data["Background"][0][3:]],
        "background_order": int(hist.data["Background"][0][2]),
        "roughness": {
            "A": [float(hist.data["Sample Parameters"]["SurfRoughA"][0]),
                  bool(hist.data["Sample Parameters"]["SurfRoughA"][1])],
            "B": [float(hist.data["Sample Parameters"]["SurfRoughB"][0]),
                  bool(hist.data["Sample Parameters"]["SurfRoughB"][1])],
        },
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "weight_fraction": float(mass[phase.name][0]),
            "weight_fraction_esd": float(mass[phase.name][1]),
            "MD_ratio": float(hap["Pref.Ori."][1]),
            "MD_refine": bool(hap["Pref.Ori."][2]),
            "MD_axis": [int(value) for value in hap["Pref.Ori."][3]],
        }
    return result


def refine_twice(project: G2sc.G2Project) -> None:
    project.set_Controls("cycles", 10)
    project.refine()
    project.refine()


def profile_trial(terms: str) -> tuple[Path, dict]:
    project = G2sc.G2Project(gpxfile=str(SOURCE))
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    starts = {key: float(inst[key][1]) for key in ("U", "W", "X")}
    for key in starts:
        inst[key][1] = starts[key] if key in terms else 0.0
        inst[key][2] = key in terms
        project.set_Controls("parmMin", 0.0, variable=f":0:{key}")
    project.set_Frozen()
    target = OUT / f"profile_{terms}.gpx"
    project.save(str(target))
    refine_twice(project)
    project.save(str(target))
    return target, snapshot(project, f"profile_{terms}")


def background_trial(base: Path, order: int) -> tuple[Path, dict]:
    project = G2sc.G2Project(gpxfile=str(base))
    hist = project.histogram(0)
    coeffs = list(hist.data["Background"][0][3:])
    coeffs = (coeffs + [0.0] * order)[:order]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": order,
                "coeffs": coeffs,
                "refine": True,
            }
        }
    )
    project.set_Frozen()
    target = OUT / f"background_{order}.gpx"
    project.save(str(target))
    refine_twice(project)
    project.save(str(target))
    return target, snapshot(project, f"background_{order}")


def specimen_trial(base: Path, mode: str) -> tuple[Path, dict]:
    project = G2sc.G2Project(gpxfile=str(base))
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    inst["Polariz."][1] = 0.5
    inst["Polariz."][2] = mode == "polarization"
    sample["SurfRoughA"] = [0.01 if mode == "roughness" else 0.0,
                            mode == "roughness"]
    sample["SurfRoughB"] = [0.01 if mode == "roughness" else 0.0,
                            mode == "roughness"]
    if mode == "polarization":
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    if mode == "roughness":
        for key in ("SurfRoughA", "SurfRoughB"):
            project.set_Controls("parmMin", 0.0, variable=f":0:{key}")
    project.set_Frozen()
    target = OUT / f"specimen_{mode}.gpx"
    project.save(str(target))
    refine_twice(project)
    project.save(str(target))
    return target, snapshot(project, f"specimen_{mode}")


def set_md_neutral(project: G2sc.G2Project, phase_index: int) -> None:
    hist = project.histogram(0)
    hap = project.phase(phase_index).data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def neutral_texture(base: Path, phase_index: int, label: str) -> tuple[Path, dict]:
    project = G2sc.G2Project(gpxfile=str(base))
    set_md_neutral(project, phase_index)
    project.set_Frozen()
    target = OUT / f"texture_{label}_neutral.gpx"
    project.save(str(target))
    refine_twice(project)
    project.save(str(target))
    return target, snapshot(project, f"texture_{label}_neutral")


def texture_trial(
    base: Path, phase_index: int, axis: tuple[int, int, int], label: str
) -> tuple[Path, dict]:
    project = G2sc.G2Project(gpxfile=str(base))
    hist = project.histogram(0)
    hap = project.phase(phase_index).data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.1
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    project.set_Controls("parmMin", 0.2, variable=f"{phase_index}:0:MD")
    project.set_Controls("parmMax", 5.0, variable=f"{phase_index}:0:MD")
    project.set_Frozen()
    axis_name = "_".join("m" + str(-v) if v < 0 else str(v) for v in axis)
    target = OUT / f"texture_{label}_{axis_name}.gpx"
    project.save(str(target))
    refine_twice(project)
    project.save(str(target))
    return target, snapshot(project, f"texture_{label}_{axis_name}")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    results: dict[str, object] = {}

    profile_results = []
    profile_paths = {}
    for terms in ("UX", "WX", "UWX"):
        print("PROFILE_START", terms, flush=True)
        path, result = profile_trial(terms)
        profile_paths[terms] = path
        profile_results.append(result)
        print("PROFILE_DONE", terms, result["Rwp_percent"], result["BIC"],
              result["frozen"], flush=True)
    results["profiles"] = profile_results

    background_results = []
    background_paths = {}
    for order in (4, 6, 8):
        print("BACKGROUND_START", order, flush=True)
        path, result = background_trial(profile_paths["UWX"], order)
        background_paths[order] = path
        background_results.append(result)
        print("BACKGROUND_DONE", order, result["Rwp_percent"], result["BIC"],
              result["frozen"], flush=True)
    results["backgrounds"] = background_results

    specimen_results = []
    for mode in ("polarization", "roughness"):
        print("SPECIMEN_START", mode, flush=True)
        _, result = specimen_trial(background_paths[6], mode)
        specimen_results.append(result)
        print("SPECIMEN_DONE", mode, result["Rwp_percent"], result["BIC"],
              result["frozen"], flush=True)
    results["specimen"] = specimen_results

    # Texture starts with only the tested phase neutralized. Other accepted
    # texture terms are retained, so each phase is challenged in sequence.
    p0_neutral, p0_base_result = neutral_texture(background_paths[6], 0, "p0")
    p0_results = [p0_base_result]
    p0_paths = {}
    axes = ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0),
            (1, 0, 1), (1, 0, -1), (0, 1, 1), (1, 1, 1))
    for axis in axes:
        print("TEXTURE_START 0", axis, flush=True)
        path, result = texture_trial(p0_neutral, 0, axis, "p0")
        p0_paths[axis] = path
        p0_results.append(result)
        print("TEXTURE_DONE 0", axis, result["Rwp_percent"], result["BIC"],
              result["frozen"], flush=True)
    results["texture_MgWO4"] = p0_results

    p1_neutral, p1_base_result = neutral_texture(p0_paths[(0, 1, 0)], 1, "p1")
    p1_results = [p1_base_result]
    for axis in axes:
        print("TEXTURE_START 1", axis, flush=True)
        _, result = texture_trial(p1_neutral, 1, axis, "p1")
        p1_results.append(result)
        print("TEXTURE_DONE 1", axis, result["Rwp_percent"], result["BIC"],
              result["frozen"], flush=True)
    results["texture_WO3"] = p1_results

    p2_neutral, p2_base_result = neutral_texture(p0_paths[(0, 1, 0)], 2, "p2")
    p2_results = [p2_base_result]
    for axis in ((1, 0, 0), (1, 1, 0), (1, 1, 1)):
        print("TEXTURE_START 2", axis, flush=True)
        _, result = texture_trial(p2_neutral, 2, axis, "p2")
        p2_results.append(result)
        print("TEXTURE_DONE 2", axis, result["Rwp_percent"], result["BIC"],
              result["frozen"], flush=True)
    results["texture_MgO"] = p2_results

    (OUT / "replay.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2), flush=True)


if __name__ == "__main__":
    main()
