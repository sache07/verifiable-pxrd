#!/usr/bin/env python3
"""Audit consistency and representative peak shapes in the frozen submission."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from scipy.signal import savgol_filter

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / ".tmp/final-audit"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def interpolate_crossing(
    x: np.ndarray, y: np.ndarray, start: int, direction: int, level: float
) -> float:
    index = start
    while 0 <= index + direction < len(y) and y[index + direction] > level:
        index += direction
    other = index + direction
    if not 0 <= other < len(y):
        return float("nan")
    return float(
        x[index]
        + (level - y[index]) * (x[other] - x[index]) / (y[other] - y[index])
    )


def peak_metrics(
    x: np.ndarray, y: np.ndarray, target: float, search_half_width: float = 0.12
) -> dict[str, float]:
    candidates = np.flatnonzero(np.abs(x - target) <= search_half_width)
    require(len(candidates) > 0, f"no data near peak target {target}")
    peak = int(candidates[np.argmax(y[candidates])])
    level = float(y[peak] / 2.0)
    left = interpolate_crossing(x, y, peak, -1, level)
    right = interpolate_crossing(x, y, peak, 1, level)
    require(math.isfinite(left) and math.isfinite(right), f"open FWHM at {target}")
    return {
        "maximum_two_theta_deg": float(x[peak]),
        "left_half_width_deg": float(x[peak] - left),
        "right_half_width_deg": float(right - x[peak]),
        "FWHM_deg": float(right - left),
    }


def cif_cell(path: Path) -> dict[str, float]:
    wanted = {
        "_cell_length_a": "length_a",
        "_cell_length_b": "length_b",
        "_cell_length_c": "length_c",
        "_cell_angle_alpha": "angle_alpha",
        "_cell_angle_beta": "angle_beta",
        "_cell_angle_gamma": "angle_gamma",
    }
    values: dict[str, float] = {}
    for line in path.read_text().splitlines():
        fields = line.split()
        if len(fields) >= 2 and fields[0] in wanted:
            values[wanted[fields[0]]] = float(fields[1].split("(")[0])
    require(set(values) == set(wanted.values()), f"incomplete cell in {path.name}")
    return values


def main() -> None:
    result_path = ROOT / "result.json"
    fit_path = ROOT / "fit.csv"
    project_path = ROOT / "final.gpx"
    result = json.loads(result_path.read_text())

    require(result["project_path"] == "final.gpx", "wrong top-level project path")
    require(result["fit_path"] == "fit.csv", "wrong fit path")
    require(project_path.is_file() and fit_path.is_file(), "missing project or profile")
    require(len(result["phases"]) == 3, "unexpected phase count")
    fractions = [phase["weight_fraction"] for phase in result["phases"]]
    require(all(isinstance(value, (int, float)) for value in fractions), "nonnumeric fraction")
    require(all(value >= 0 for value in fractions), "negative fraction")
    require(abs(sum(fractions) - 1.0) < 1e-12, "fractions do not sum to one")
    for phase in result["phases"]:
        require(phase["project_path"] == "final.gpx", "phase project path mismatch")
        require((ROOT / phase["cif_path"]).is_file(), f"missing {phase['cif_path']}")

    project = G2sc.G2Project(gpxfile=str(project_path))
    histogram = project.histogram(0)
    require(project.get_Frozen() == [], "project contains frozen parameters")
    arrays = histogram.data["data"][1]
    x, observed, weights, calculated, background, difference = arrays
    require(len(x) == result["fit_statistics"]["N_observations"], "Nobs mismatch")
    require(np.max(np.abs(difference - (observed - calculated))) < 1e-8,
            "project difference is not observed minus calculated")

    with fit_path.open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    require(len(rows) == len(x), "fit.csv row count mismatch")
    csv_arrays = {
        key: np.asarray([float(row[key]) for row in rows])
        for key in (
            "two_theta_deg",
            "observed_counts",
            "calculated_counts",
            "difference_counts",
        )
    }
    profile_deltas = {
        "two_theta_deg": float(np.max(np.abs(csv_arrays["two_theta_deg"] - x))),
        "observed_counts": float(np.max(np.abs(csv_arrays["observed_counts"] - observed))),
        "calculated_counts": float(np.max(np.abs(csv_arrays["calculated_counts"] - calculated))),
        "difference_counts": float(np.max(np.abs(csv_arrays["difference_counts"] - difference))),
    }
    require(profile_deltas["two_theta_deg"] < 1e-7, "fit x values disagree")
    require(profile_deltas["observed_counts"] < 1e-7, "fit observations disagree")
    require(profile_deltas["calculated_counts"] < 1e-3, "fit calculations disagree")
    require(profile_deltas["difference_counts"] < 1e-3, "fit differences disagree")
    require(np.max(np.abs(
        csv_arrays["difference_counts"]
        - (csv_arrays["observed_counts"] - csv_arrays["calculated_counts"])
    )) < 1e-3, "fit.csv difference column is inconsistent")

    rdata = histogram.data["data"][0]
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    project_stats = {
        "Rwp_percent": float(rdata["wR"]),
        "Rp_percent": float(rdata["R"]),
        "GOF": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "N_observations": int(rvals["Nobs"]),
        "N_variables": int(rvals["Nvars"]),
    }
    for key, value in project_stats.items():
        submitted = result["fit_statistics"][key]
        tolerance = 0 if isinstance(value, int) else 1e-9 * max(1.0, abs(value))
        require(abs(submitted - value) <= tolerance, f"statistic mismatch for {key}")

    phase_map = {
        "MgWO4": ("MgWO4", "MgWO4.cif"),
        "WO3": ("WO3_2311041", "WO3.cif"),
        "MgO": ("MgO", "MgO.cif"),
    }
    mass = histogram.ComputeMassFracs()
    mass_total = sum(float(mass[project_name][0]) for project_name, _ in phase_map.values())
    fraction_deltas: dict[str, float] = {}
    cell_deltas: dict[str, dict[str, float]] = {}
    for submitted_phase in result["phases"]:
        name = submitted_phase["name"]
        project_name, cif_name = phase_map[name]
        project_fraction = float(mass[project_name][0]) / mass_total
        fraction_deltas[name] = abs(submitted_phase["weight_fraction"] - project_fraction)
        require(fraction_deltas[name] < 1e-12, f"fraction mismatch for {name}")
        project_cell = project.phase(project_name).get_cell()
        exported_cell = cif_cell(ROOT / cif_name)
        cell_deltas[name] = {
            key: abs(float(project_cell[key]) - exported_cell[key]) for key in exported_cell
        }
        require(max(cell_deltas[name].values()) < 5.1e-4,
                f"exported cell mismatch for {name}")

    ranges = (("low", 9.9, 40.0), ("middle", 40.0, 70.0), ("high", 70.0, 100.1))
    range_statistics = []
    for label, lower, upper in ranges:
        selected = (x >= lower) & (x < upper)
        numerator = np.sum(weights[selected] * (observed[selected] - calculated[selected]) ** 2)
        denominator = np.sum(weights[selected] * observed[selected] ** 2)
        range_statistics.append(
            {
                "range": label,
                "limits_two_theta_deg": [lower, upper],
                "Rwp_percent": float(100.0 * np.sqrt(numerator / denominator)),
                "mean_difference_counts": float(np.mean(difference[selected])),
            }
        )

    # Targets are well-resolved profile maxima distributed across the scan. The
    # observed curve is lightly Savitzky-Golay filtered only for this diagnostic
    # so counting noise does not select a neighboring data point as the maximum.
    targets = (
        ("low", "MgWO4 (100)", 18.87908),
        ("low", "WO3 (20-2)", 23.12784),
        ("low", "MgWO4 (11-1)", 30.40833),
        ("middle", "MgO (111)", 36.93904),
        ("middle", "MgO (200)", 42.91556),
        ("middle", "MgWO4 (211)", 45.83862),
        ("high", "MgWO4 (041)", 68.65806),
        ("high", "MgWO4/WO3 family near 88.33", 88.32624),
        ("high", "MgWO4 family near 98.90", 98.89925),
    )
    observed_net = savgol_filter(observed - background, 7, 2)
    calculated_net = calculated - background
    peak_audit = []
    for region, family, target in targets:
        obs_metrics = peak_metrics(x, observed_net, target)
        calc_metrics = peak_metrics(x, calculated_net, target)
        peak_audit.append(
            {
                "range": region,
                "family": family,
                "observed": obs_metrics,
                "calculated": calc_metrics,
                "absolute_maximum_offset_deg": abs(
                    obs_metrics["maximum_two_theta_deg"]
                    - calc_metrics["maximum_two_theta_deg"]
                ),
                "absolute_FWHM_difference_deg": abs(
                    obs_metrics["FWHM_deg"] - calc_metrics["FWHM_deg"]
                ),
            }
        )

    audit = {
        "status": "pass",
        "project_has_no_frozen_parameters": True,
        "fraction_sum": float(sum(fractions)),
        "fraction_absolute_deltas": fraction_deltas,
        "fit_csv_maximum_absolute_deltas": profile_deltas,
        "cif_cell_absolute_deltas": cell_deltas,
        "project_fit_statistics": project_stats,
        "range_statistics": range_statistics,
        "peak_shape_audit": peak_audit,
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "audit.json").write_text(json.dumps(audit, indent=2) + "\n")
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
