#!/usr/bin/env python3
"""Replay the selected model over the full range and freeze submission files."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/final-convergence/selected.gpx"


def main() -> None:
    final_gpx = ROOT / "final.gpx"
    project = G2sc.G2Project(gpxfile=str(SOURCE))
    hist = project.histogram(0)
    measured_limits = hist.data["Limits"][0]
    hist.set_refinements(
        {"Limits": [float(measured_limits[0]), float(measured_limits[1])]}
    )
    project.set_Frozen()
    project.set_Controls("cycles", 10)
    project.save(str(final_gpx))
    project.refine()
    project.refine()
    project.save(str(final_gpx))

    cif_names = {
        "MgWO4": "MgWO4.cif",
        "WO3_2311041": "WO3.cif",
        "MgO": "MgO.cif",
    }
    for phase in project.phases():
        phase.export_CIF(str(ROOT / cif_names[phase.name]))

    x, yobs, _, ycalc, _, residual = hist.data["data"][1]
    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            ["two_theta_deg", "observed_counts", "calculated_counts", "difference_counts"]
        )
        for values in zip(x, yobs, ycalc, residual):
            writer.writerow([f"{float(value):.10g}" for value in values])

    mass = hist.ComputeMassFracs()
    rdata = hist.data["data"][0]
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    phase_specs = [
        ("MgWO4", "MgWO4", "MgWO4.cif", "9013902"),
        ("WO3_2311041", "WO3", "WO3.cif", "2311041"),
        ("MgO", "MgO", "MgO.cif", "9000499"),
    ]
    raw_fractions = [float(mass[key][0]) for key, *_ in phase_specs]
    total = sum(raw_fractions)
    fractions = [value / total for value in raw_fractions]
    fractions[-1] = 1.0 - sum(fractions[:-1])
    phases = []
    for (project_name, name, cif_path, cod_id), fraction in zip(
        phase_specs, fractions
    ):
        phase = project.phase(project_name)
        phases.append(
            {
                "name": name,
                "formula": name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "source_cod_id": cod_id,
                "cif_path": cif_path,
                "project_path": "final.gpx",
                "weight_fraction": fraction,
                "weight_fraction_esd": float(mass[project_name][1]) / total,
            }
        )
    result = {
        "phases": phases,
        "project_path": "final.gpx",
        "fit_path": "fit.csv",
        "fit_statistics": {
            "Rwp_percent": float(rdata["wR"]),
            "Rp_percent": float(rdata["R"]),
            "GOF": float(rvals.get("GOF", float("nan"))),
            "chi_squared": float(rvals.get("chisq", float("nan"))),
            "N_observations": int(rvals.get("Nobs", rdata.get("Nobs", 0))),
            "N_variables": int(rvals.get("Nvars", 0)),
        },
        "measurement_range_two_theta_deg": [
            float(measured_limits[0]), float(measured_limits[1])
        ],
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
