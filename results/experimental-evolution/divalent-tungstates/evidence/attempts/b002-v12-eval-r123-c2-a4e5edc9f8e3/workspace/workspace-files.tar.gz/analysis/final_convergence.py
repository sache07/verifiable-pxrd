#!/usr/bin/env python3
"""Combine supported terms and replay the full convergence loop once more."""

from __future__ import annotations

import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/replay-elaboration/background_8.gpx"
OUT = ROOT / ".tmp/final-convergence"


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    mass = hist.ComputeMassFracs()
    nobs = int(rvals.get("Nobs", hist.data["data"][0].get("Nobs", 0)))
    nvars = int(rvals.get("Nvars", len(cov.get("varyList", []))))
    chisq = float(rvals.get("chisq", float("nan")))
    inst = hist.data["Instrument Parameters"][0]
    result = {
        "label": label,
        "Rwp_percent": float(hist.data["data"][0]["wR"]),
        "Rp_percent": float(hist.data["data"][0]["R"]),
        "GOF": float(rvals.get("GOF", float("nan"))),
        "chisq": chisq,
        "Nobs": nobs,
        "Nvars": nvars,
        "BIC": chisq + nvars * math.log(nobs) if nobs else float("nan"),
        "frozen": project.get_Frozen(),
        "profile": {key: [float(inst[key][1]), bool(inst[key][2])]
                    for key in ("U", "W", "X")},
        "zero_deg": float(inst["Zero"][1]),
        "polarization": [float(inst["Polariz."][1]), bool(inst["Polariz."][2])],
        "background_order": int(hist.data["Background"][0][2]),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "scale": float(hap["Scale"][0]),
            "weight_fraction": float(mass[phase.name][0]),
            "weight_fraction_esd": float(mass[phase.name][1]),
            "size_micrometre": [float(hap["Size"][1][0]), bool(hap["Size"][2][0])],
            "microstrain": [float(hap["Mustrain"][1][0]),
                            bool(hap["Mustrain"][2][0])],
            "MD_ratio": [float(hap["Pref.Ori."][1]), bool(hap["Pref.Ori."][2])],
            "MD_axis": [int(value) for value in hap["Pref.Ori."][3]],
            "cell": {key: float(value) for key, value in phase.get_cell().items()},
        }
    return result


def refine_twice(project: G2sc.G2Project) -> None:
    project.set_Controls("cycles", 10)
    project.refine()
    project.refine()


def set_md(project: G2sc.G2Project, phase_index: int,
           axis: tuple[int, int, int] | None, ratio: float = 1.0) -> None:
    hist = project.histogram(0)
    hap = project.phase(phase_index).data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = ratio
    hap["Pref.Ori."][2] = axis is not None
    if axis is not None:
        hap["Pref.Ori."][3] = list(axis)
        project.set_Controls("parmMin", 0.2, variable=f"{phase_index}:0:MD")
        project.set_Controls("parmMax", 5.0, variable=f"{phase_index}:0:MD")


def build_selected() -> Path:
    project = G2sc.G2Project(gpxfile=str(SOURCE))
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["Polariz."][1] = 0.5118
    inst["Polariz."][2] = True
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    set_md(project, 1, (1, 0, 0), 1.027)
    set_md(project, 2, None)
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    project.set_Frozen()
    target = OUT / "selected.gpx"
    project.save(str(target))
    refine_twice(project)
    project.save(str(target))
    return target


def trial_profile(base: Path, terms: str) -> dict:
    project = G2sc.G2Project(gpxfile=str(base))
    inst = project.histogram(0).data["Instrument Parameters"][0]
    starts = {key: float(inst[key][1]) for key in ("U", "W", "X")}
    for key in starts:
        inst[key][1] = starts[key] if key in terms else 0.0
        inst[key][2] = key in terms
        project.set_Controls("parmMin", 0.0, variable=f":0:{key}")
    project.set_Frozen()
    target = OUT / f"profile_{terms}.gpx"
    project.save(str(target))
    refine_twice(project)
    project.save(str(target))
    return snapshot(project, f"profile_{terms}")


def trial_background(base: Path, order: int) -> dict:
    project = G2sc.G2Project(gpxfile=str(base))
    hist = project.histogram(0)
    coeffs = list(hist.data["Background"][0][3:])
    coeffs = (coeffs + [0.0] * order)[:order]
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "no. coeffs": order,
                        "coeffs": coeffs, "refine": True}}
    )
    project.set_Frozen()
    target = OUT / f"background_{order}.gpx"
    project.save(str(target))
    refine_twice(project)
    project.save(str(target))
    return snapshot(project, f"background_{order}")


def trial_polarization(base: Path, refine: bool) -> dict:
    project = G2sc.G2Project(gpxfile=str(base))
    inst = project.histogram(0).data["Instrument Parameters"][0]
    inst["Polariz."][1] = 0.5118 if refine else 0.5
    inst["Polariz."][2] = refine
    project.set_Frozen()
    label = "polarization_refined" if refine else "polarization_fixed"
    target = OUT / f"{label}.gpx"
    project.save(str(target))
    refine_twice(project)
    project.save(str(target))
    return snapshot(project, label)


def trial_texture(base: Path, axis: tuple[int, int, int] | None) -> dict:
    project = G2sc.G2Project(gpxfile=str(base))
    set_md(project, 1, axis, 1.027 if axis is not None else 1.0)
    project.set_Frozen()
    axis_name = "neutral" if axis is None else "_".join(str(v) for v in axis)
    target = OUT / f"wo3_texture_{axis_name}.gpx"
    project.save(str(target))
    refine_twice(project)
    project.save(str(target))
    return snapshot(project, f"wo3_texture_{axis_name}")


def neutral_broadening(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]


def build_neutral_width(base: Path) -> Path:
    project = G2sc.G2Project(gpxfile=str(base))
    neutral_broadening(project)
    project.set_Frozen()
    target = OUT / "width_neutral.gpx"
    project.save(str(target))
    refine_twice(project)
    project.save(str(target))
    return target


def trial_width(base: Path, phase_index: int, mode: str) -> dict:
    project = G2sc.G2Project(gpxfile=str(base))
    neutral_broadening(project)
    hist = project.histogram(0)
    hap = project.phase(phase_index).data["Histograms"][hist.name]
    if mode in ("size", "combined"):
        hap["Size"][1][0] = 0.16 if phase_index == 1 else 5.0
        hap["Size"][2][0] = True
        project.set_Controls("parmMin", 0.001, variable=f"{phase_index}:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{phase_index}:0:Size;i")
    if mode in ("strain", "combined"):
        hap["Mustrain"][1][0] = 4200.0 if phase_index == 1 else 100.0
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;i")
        project.set_Controls("parmMax", 10000.0,
                             variable=f"{phase_index}:0:Mustrain;i")
    project.set_Frozen()
    target = OUT / f"width_p{phase_index}_{mode}.gpx"
    project.save(str(target))
    refine_twice(project)
    project.save(str(target))
    return snapshot(project, f"width_p{phase_index}_{mode}")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    selected = build_selected()
    project = G2sc.G2Project(gpxfile=str(selected))
    results: dict[str, object] = {"selected": snapshot(project, "selected")}
    print("SELECTED", results["selected"]["Rwp_percent"], flush=True)

    results["profiles"] = []
    for terms in ("UX", "WX", "UWX"):
        print("PROFILE_START", terms, flush=True)
        result = trial_profile(selected, terms)
        results["profiles"].append(result)
        print("PROFILE_DONE", terms, result["Rwp_percent"], result["BIC"],
              result["frozen"], flush=True)

    results["backgrounds"] = []
    for order in (6, 8):
        print("BACKGROUND_START", order, flush=True)
        result = trial_background(selected, order)
        results["backgrounds"].append(result)
        print("BACKGROUND_DONE", order, result["Rwp_percent"], result["BIC"],
              result["frozen"], flush=True)

    results["polarization"] = []
    for refine in (False, True):
        print("POLARIZATION_START", refine, flush=True)
        result = trial_polarization(selected, refine)
        results["polarization"].append(result)
        print("POLARIZATION_DONE", refine, result["Rwp_percent"], result["BIC"],
              result["frozen"], flush=True)

    results["wo3_texture"] = []
    for axis in (None, (1, 0, 0), (1, 1, 0), (1, 0, 1), (1, 1, 1)):
        print("TEXTURE_START", axis, flush=True)
        result = trial_texture(selected, axis)
        results["wo3_texture"].append(result)
        print("TEXTURE_DONE", axis, result["Rwp_percent"], result["BIC"],
              result["frozen"], flush=True)

    neutral_width = build_neutral_width(selected)
    project = G2sc.G2Project(gpxfile=str(neutral_width))
    results["width_neutral"] = snapshot(project, "width_neutral")
    results["widths"] = []
    for phase_index in range(3):
        for mode in ("size", "strain", "combined"):
            print("WIDTH_START", phase_index, mode, flush=True)
            result = trial_width(neutral_width, phase_index, mode)
            results["widths"].append(result)
            print("WIDTH_DONE", phase_index, mode, result["Rwp_percent"],
                  result["BIC"], result["frozen"], flush=True)

    (OUT / "replay.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2), flush=True)


if __name__ == "__main__":
    main()
