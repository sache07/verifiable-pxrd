#!/usr/bin/env python3
"""Re-challenge serious WO3 source records with the final three-phase nuisance model."""

from __future__ import annotations

import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
MGWO4 = COD / "9/01/39/9013902.cif"
MGO = COD / "9/00/04/9000499.cif"
FINAL_SEED = ROOT / ".tmp/final-convergence/selected.gpx"
OUT = ROOT / ".tmp/final-source-challenge"


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    mass = hist.ComputeMassFracs()
    nobs = int(rvals.get("Nobs", hist.data["data"][0].get("Nobs", 0)))
    nvars = int(rvals.get("Nvars", len(cov.get("varyList", []))))
    chisq = float(rvals.get("chisq", float("nan")))
    result = {
        "label": label,
        "Rwp_percent": float(hist.data["data"][0]["wR"]),
        "Rp_percent": float(hist.data["data"][0]["R"]),
        "GOF": float(rvals.get("GOF", float("nan"))),
        "chisq": chisq,
        "Nobs": nobs,
        "Nvars": nvars,
        "BIC": chisq + nvars * math.log(nobs) if nobs else float("nan"),
        "frozen": project.get_Frozen(),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "scale": float(hap["Scale"][0]),
            "weight_fraction": float(mass[phase.name][0]),
            "size_micrometre": float(hap["Size"][1][0]),
            "microstrain": float(hap["Mustrain"][1][0]),
            "MD_ratio": float(hap["Pref.Ori."][1]),
            "MD_axis": [int(value) for value in hap["Pref.Ori."][3]],
            "cell": {key: float(value) for key, value in phase.get_cell().items()},
        }
    return result


def neutral_hap(phase, histogram_name: str, scale: float) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Scale"] = [scale, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def refine_twice(project: G2sc.G2Project) -> None:
    project.set_Controls("cycles", 10)
    project.refine()
    project.refine()


def build_neutral(cod_id: str, seed: G2sc.G2Project) -> Path:
    target = OUT / cod_id / "neutral.gpx"
    target.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(target))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"), str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    seed_hist = seed.histogram(0)
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [float(v) for v in seed_hist.data["Background"][0][3:]],
                "refine": True,
            },
        }
    )
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    seed_inst = seed_hist.data["Instrument Parameters"][0]
    inst = hist.data["Instrument Parameters"][0]
    for key in ("Zero", "U", "W", "X", "Polariz."):
        inst[key][1] = float(seed_inst[key][1])
        inst[key][2] = True
    mg = project.add_phase(str(MGWO4), phasename="MgWO4", histograms=[hist],
                           fmthint="CIF")
    wo = project.add_phase(str(cod_path(cod_id)), phasename=f"WO3_{cod_id}",
                           histograms=[hist], fmthint="CIF")
    mgo = project.add_phase(str(MGO), phasename="MgO", histograms=[hist],
                            fmthint="CIF")
    neutral_hap(mg, hist.name, 82.5)
    neutral_hap(wo, hist.name, 19.5)
    neutral_hap(mgo, hist.name, 39.7)
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMin", 0.0, variable=":0:W")
    project.set_Controls("parmMin", 0.0, variable=":0:X")
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    mg_hap = mg.data["Histograms"][hist.name]
    mg_hap["Pref.Ori."][1] = 1.302
    mg_hap["Pref.Ori."][2] = True
    mg_hap["Pref.Ori."][3] = [0, 1, 0]
    project.set_Controls("parmMin", 0.2, variable="0:0:MD")
    project.set_Controls("parmMax", 5.0, variable="0:0:MD")
    for phase_index, phase in enumerate(project.phases()):
        phase.set_refinements({"Cell": True})
        project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Scale")
    project.set_Frozen()
    project.save(str(target))
    refine_twice(project)
    project.save(str(target))
    return target


def width_trial(base: Path, cod_id: str, mode: str) -> tuple[Path, dict]:
    project = G2sc.G2Project(gpxfile=str(base))
    hist = project.histogram(0)
    wo = project.phase(1)
    neutral_hap(wo, hist.name, wo.data["Histograms"][hist.name]["Scale"][0])
    hap = wo.data["Histograms"][hist.name]
    if mode in ("size", "combined"):
        hap["Size"][1][0] = 0.17
        hap["Size"][2][0] = True
        project.set_Controls("parmMin", 0.001, variable="1:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable="1:0:Size;i")
    if mode in ("strain", "combined"):
        hap["Mustrain"][1][0] = 4400.0
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 0.0, variable="1:0:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, variable="1:0:Mustrain;i")
    project.set_Frozen()
    target = OUT / cod_id / f"width_{mode}.gpx"
    project.save(str(target))
    refine_twice(project)
    project.save(str(target))
    return target, snapshot(project, f"width_{mode}")


def texture_trial(base: Path, cod_id: str,
                  axis: tuple[int, int, int]) -> tuple[Path, dict]:
    project = G2sc.G2Project(gpxfile=str(base))
    hist = project.histogram(0)
    hap = project.phase(1).data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.03
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    project.set_Controls("parmMin", 0.2, variable="1:0:MD")
    project.set_Controls("parmMax", 5.0, variable="1:0:MD")
    project.set_Frozen()
    axis_name = "_".join("m" + str(-v) if v < 0 else str(v) for v in axis)
    target = OUT / cod_id / f"texture_{axis_name}.gpx"
    project.save(str(target))
    refine_twice(project)
    project.save(str(target))
    return target, snapshot(project, f"texture_{axis_name}")


def fit_source(cod_id: str, seed: G2sc.G2Project) -> dict:
    print("SOURCE_START", cod_id, flush=True)
    neutral_path = build_neutral(cod_id, seed)
    neutral_project = G2sc.G2Project(gpxfile=str(neutral_path))
    neutral = snapshot(neutral_project, "neutral")
    print("SOURCE_NEUTRAL", cod_id, neutral["Rwp_percent"],
          neutral["phases"][f"WO3_{cod_id}"]["weight_fraction"], flush=True)

    widths = []
    width_paths = {}
    for mode in ("size", "strain", "combined"):
        path, result = width_trial(neutral_path, cod_id, mode)
        width_paths[mode] = path
        widths.append(result)
        print("SOURCE_WIDTH", cod_id, mode, result["Rwp_percent"],
              result["frozen"], flush=True)
    valid = [(result["BIC"], result["label"].replace("width_", ""))
             for result in widths if not result["frozen"]]
    best_mode = min(valid)[1] if valid else "combined"

    axes = ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0),
            (1, 0, 1), (1, 0, -1), (0, 1, 1), (1, 1, 1))
    textures = []
    texture_paths = {}
    for axis in axes:
        path, result = texture_trial(width_paths[best_mode], cod_id, axis)
        texture_paths[result["label"]] = path
        textures.append(result)
        print("SOURCE_TEXTURE", cod_id, axis, result["Rwp_percent"],
              result["frozen"], flush=True)
    valid_textures = [result for result in textures if not result["frozen"]]
    best_texture = min(valid_textures, key=lambda item: item["BIC"])
    final_path = texture_paths[best_texture["label"]]
    print("SOURCE_DONE", cod_id, best_mode, best_texture["label"],
          best_texture["Rwp_percent"], flush=True)
    return {
        "cod_id": cod_id,
        "source": str(cod_path(cod_id)),
        "neutral": neutral,
        "widths": widths,
        "best_width": best_mode,
        "textures": textures,
        "best_texture": best_texture["label"],
        "best_project": str(final_path),
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    seed = G2sc.G2Project(gpxfile=str(FINAL_SEED))
    results = []
    for cod_id in ("2311041", "1528915", "2106293"):
        try:
            result = fit_source(cod_id, seed)
        except Exception as exc:
            result = {"cod_id": cod_id, "error": repr(exc)}
            print("SOURCE_ERROR", cod_id, repr(exc), flush=True)
        results.append(result)
        (OUT / "ranking.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2), flush=True)


if __name__ == "__main__":
    main()
