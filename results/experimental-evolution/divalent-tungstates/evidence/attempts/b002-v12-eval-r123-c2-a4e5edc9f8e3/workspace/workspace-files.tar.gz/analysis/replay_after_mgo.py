#!/usr/bin/env python3
"""Replay profile and isotropic phase broadening after retaining MgO."""

from __future__ import annotations

import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/mgo-challenge/mgo_cell.gpx"
OUT = ROOT / ".tmp/replay-after-mgo"


def neutral_broadening(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    mass = hist.ComputeMassFracs()
    nobs = int(rvals.get("Nobs", hist.data["data"][0].get("Nobs", 0)))
    nvars = int(rvals.get("Nvars", len(cov.get("varyList", []))))
    chisq = float(rvals.get("chisq", float("nan")))
    result = {
        "label": label,
        "Rwp_percent": float(hist.data["data"][0]["wR"]),
        "Rp_percent": float(hist.data["data"][0]["R"]),
        "GOF": float(rvals.get("GOF", float("nan"))),
        "chisq": chisq,
        "Nobs": nobs,
        "Nvars": nvars,
        "BIC": chisq + nvars * math.log(nobs) if nobs else float("nan"),
        "frozen": project.get_Frozen(),
        "instrument": {},
        "phases": {},
    }
    inst = hist.data["Instrument Parameters"][0]
    for key in ("Zero", "U", "W", "X"):
        result["instrument"][key] = {
            "value": float(inst[key][1]), "refine": bool(inst[key][2])
        }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "scale": float(hap["Scale"][0]),
            "weight_fraction": float(mass[phase.name][0]),
            "weight_fraction_esd": float(mass[phase.name][1]),
            "size_micrometre": float(hap["Size"][1][0]),
            "size_refine": bool(hap["Size"][2][0]),
            "microstrain": float(hap["Mustrain"][1][0]),
            "microstrain_refine": bool(hap["Mustrain"][2][0]),
        }
    return result


def refine_twice(project: G2sc.G2Project) -> None:
    project.set_Controls("cycles", 10)
    project.refine()
    project.refine()


def build_neutral() -> Path:
    project = G2sc.G2Project(gpxfile=str(SOURCE))
    hist = project.histogram(0)
    for phase in project.phases():
        neutral_broadening(phase, hist.name)
    project.set_Frozen()
    target = OUT / "neutral_width.gpx"
    project.save(str(target))
    refine_twice(project)
    project.save(str(target))
    return target


def profile_trial(base: Path, terms: str) -> tuple[Path, dict]:
    project = G2sc.G2Project(gpxfile=str(base))
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    starts = {"U": 18.0, "W": 18.0, "X": 3.0}
    for key in starts:
        inst[key][1] = starts[key] if key in terms else 0.0
        inst[key][2] = key in terms
        project.set_Controls("parmMin", 0.0, variable=f":0:{key}")
    project.set_Frozen()
    target = OUT / f"profile_{terms}.gpx"
    project.save(str(target))
    refine_twice(project)
    project.save(str(target))
    return target, snapshot(project, f"profile_{terms}")


def width_trial(base: Path, phase_index: int, mode: str) -> tuple[Path, dict]:
    project = G2sc.G2Project(gpxfile=str(base))
    hist = project.histogram(0)
    for phase in project.phases():
        neutral_broadening(phase, hist.name)
    phase = project.phase(phase_index)
    hap = phase.data["Histograms"][hist.name]
    if mode in ("size", "combined"):
        hap["Size"][1][0] = 0.2
        hap["Size"][2][0] = True
        project.set_Controls("parmMin", 0.001, variable=f"{phase_index}:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{phase_index}:0:Size;i")
    if mode in ("strain", "combined"):
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, variable=f"{phase_index}:0:Mustrain;i")
    project.set_Frozen()
    target = OUT / f"width_p{phase_index}_{mode}.gpx"
    project.save(str(target))
    refine_twice(project)
    project.save(str(target))
    return target, snapshot(project, f"width_p{phase_index}_{mode}")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    neutral = build_neutral()
    project = G2sc.G2Project(gpxfile=str(neutral))
    results = {"neutral_width": snapshot(project, "neutral_width")}
    profile_results = []
    profile_paths = {}
    for terms in ("X", "W", "UX", "UW", "WX", "UWX"):
        print(f"PROFILE_START {terms}", flush=True)
        path, result = profile_trial(neutral, terms)
        profile_paths[terms] = path
        profile_results.append(result)
        print(
            "PROFILE_DONE", terms, result["Rwp_percent"], result["BIC"],
            result["frozen"], flush=True,
        )
    results["profiles"] = profile_results

    # UWX is evaluated as the complete nonnegative common-profile checkpoint;
    # selection/pruning is made after inspecting all replayed trials.
    width_results = []
    for phase_index in range(3):
        for mode in ("size", "strain", "combined"):
            print(f"WIDTH_START {phase_index} {mode}", flush=True)
            _, result = width_trial(profile_paths["UWX"], phase_index, mode)
            width_results.append(result)
            print(
                "WIDTH_DONE", phase_index, mode, result["Rwp_percent"],
                result["BIC"], result["frozen"], flush=True,
            )
    results["widths_from_UWX"] = width_results
    (OUT / "replay.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2), flush=True)


if __name__ == "__main__":
    main()
