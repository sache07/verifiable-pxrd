#!/usr/bin/env python3
"""Apply one reversible model challenge to an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def reset_phase_terms(project) -> None:
    for phase in project.phases():
        hap = phase.getHAPvalues(project.histogram(0))
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False


def apply_action(project, action: str, phase_index: int, axis: list[int]) -> None:
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.getHAPvalues(hist)
    if action == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][1][2] = 1.0
        hap["Size"][2] = [True, False, False]
    elif action == "strain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 300.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2] = [True, False, False]
    elif action == "po":
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = [int(v) for v in axis]
    elif action == "shl":
        hist.InstrumentParameters["SH/L"][2] = True
    elif action == "polarization":
        hist.InstrumentParameters["Polariz."][2] = True
    elif action == "size_lgmix":
        hap["Size"][2][2] = True
    elif action == "none":
        pass
    else:
        raise ValueError(action)


def collect(project) -> dict:
    hist = project.histogram(0)
    result = {
        "residuals": hist.residuals,
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if isinstance(value, list) and len(value) > 1
        },
        "mass_fractions": hist.ComputeMassFracs(),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "--action",
        choices=["none", "size", "strain", "po", "shl", "polarization", "size_lgmix"],
        required=True,
    )
    parser.add_argument("--phase", type=int, default=0)
    parser.add_argument("--axis", type=int, nargs=3, default=[0, 0, 1])
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--keep-existing", action="store_true")
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(args.input.resolve()), newgpx=str(args.output.resolve()))
    project.set_Controls("cycles", 25)
    if not args.keep_existing:
        reset_phase_terms(project)
    project.histogram(0).InstrumentParameters["SH/L"][2] = False
    apply_action(project, args.action, args.phase, args.axis)
    project.save()
    history = []
    for _ in range(args.repeats):
        project.do_refinements([{}])
        project.reload()
        history.append(collect(project))
    result = history[-1]
    result["history_wR"] = [item["residuals"]["wR"] for item in history]
    args.summary.write_text(json.dumps(result, indent=2, default=str) + "\n")
    project.save()


if __name__ == "__main__":
    main()
