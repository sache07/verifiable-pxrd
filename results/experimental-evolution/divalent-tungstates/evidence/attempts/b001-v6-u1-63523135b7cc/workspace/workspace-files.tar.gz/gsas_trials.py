#!/usr/bin/env python3
"""Build comparable GSAS-II trial refinements for the CaO-WO3 pattern."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path(
    "<RUN>/"
    "resources/b001-c05/cif"
)


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize_hap(phase, hist) -> None:
    """Remove sample broadening/texture/extinction from a new HAP link."""
    hap = phase.getHAPvalues(hist)
    hap["Scale"] = [0.1, False]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1000.0
    hap["Size"][1][1] = 1000.0
    hap["Size"][1][2] = 1.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][1][2] = 1.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][4] = [0.0 for _ in hap["Mustrain"][4]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    # March-Dollase at unity is the neutral texture model.
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def initialize_project(out: Path, ca_id: str, wo_id: str, extra: str | None = None):
    if out.exists():
        out.unlink()
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    hist.Excluded([])
    # Smooth low-order background; the constant starts near the high-angle floor.
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": False,
                "no. coeffs": 6,
                "coeffs": [1450.0, -400.0, 250.0, -100.0, 50.0, -20.0],
            }
        }
    )
    # Keep only one angular correction and neutralize unrequested sample terms.
    sample = hist.SampleParameters
    for key, value in sample.items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for key in ("DisplaceX", "DisplaceY"):
        if key in sample:
            sample[key][0] = 0.0
    for key in ("SurfRoughA", "SurfRoughB"):
        if key in sample:
            sample[key][1] = False

    phases = [
        project.add_phase(
            str(cif_path(ca_id)), phasename=f"CaWO4_COD_{ca_id}",
            histograms=[hist], fmthint="CIF"
        ),
        project.add_phase(
            str(cif_path(wo_id)), phasename=f"WO3_COD_{wo_id}",
            histograms=[hist], fmthint="CIF"
        ),
    ]
    if extra:
        extra_path = Path(extra)
        if not extra_path.is_file():
            extra_path = cif_path(extra)
        extra_name = extra_path.stem
        phases.append(
            project.add_phase(
                str(extra_path.resolve()), phasename=f"watch_{extra_name}",
                histograms=[hist], fmthint="CIF"
            )
        )
    for phase in phases:
        neutralize_hap(phase, hist)

    inst = hist.InstrumentParameters
    # Ensure all profile and wavelength values are exactly the intended baseline.
    intended = {
        "Lam1": 1.540598,
        "Lam2": 1.544426,
        "I(L2)/I(L1)": 0.5,
        "Zero": 0.0,
        "U": 1.0,
        "V": 0.0,
        "W": 4.0,
        "X": 0.1,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }
    for key, value in intended.items():
        if key in inst:
            inst[key][0] = value
            inst[key][1] = value
            inst[key][2] = False
    project.set_Controls("cycles", 12)
    project.save()
    return project, hist, phases


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    result = {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if isinstance(value, list) and len(value) > 1
        },
        "background": list(hist.Background[0]),
        "sample": hist.SampleParameters,
        "phases": {},
    }
    try:
        result["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        result["mass_fraction_error"] = repr(exc)
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "density": phase.density,
            "composition": phase.composition,
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    print(json.dumps(result, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x)))
    return result


def refine_trial(out: Path, ca_id: str, wo_id: str, extra: str | None = None) -> dict:
    project, hist, phases = initialize_project(out, ca_id, wo_id, extra)
    snapshots = [snapshot(project, "initial")]

    # Stage 1: background and all nonnegative phase scales.
    project.do_refinements([
        {"set": {"Background": True, "Scale": True}},
    ])
    project.reload()
    snapshots.append(snapshot(project, "background_scales"))

    # Stage 2: one zero correction and all symmetry-constrained cells.
    project.do_refinements([
        {"set": {"Instrument Parameters": ["Zero"], "Cell": True}},
    ])
    project.reload()
    snapshots.append(snapshot(project, "zero_cells"))

    # Stage 3: low-dimensional common profile (U/W/X, with V/Y/Z fixed).
    project.do_refinements([
        {"set": {"Instrument Parameters": ["U", "W", "X"]}},
    ])
    project.reload()
    snapshots.append(snapshot(project, "common_profile"))

    # Replay once from the saved file to check project persistence.
    project.do_refinements([{}])
    project.reload()
    snapshots.append(snapshot(project, "replay"))
    project.save()
    return snapshots[-1]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ca", default="7219229")
    parser.add_argument("--wo", default="1528915")
    parser.add_argument("--extra")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--summary", type=Path)
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    final = refine_trial(args.out.resolve(), args.ca, args.wo, args.extra)
    if args.summary:
        args.summary.write_text(json.dumps(final, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
