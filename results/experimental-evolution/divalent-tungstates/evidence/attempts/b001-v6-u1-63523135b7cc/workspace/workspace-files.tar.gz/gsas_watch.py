#!/usr/bin/env python3
"""Re-challenge one watch-list phase against a converged GSAS-II model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from gsas_trials import cif_path, neutralize_hap


def collect(project) -> dict:
    hist = project.histogram(0)
    out = {
        "residuals": hist.residuals,
        "instrument": {
            key: val[1]
            for key, val in hist.InstrumentParameters.items()
            if isinstance(val, list) and len(val) > 1
        },
        "mass_fractions": hist.ComputeMassFracs(),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "composition": phase.composition,
        }
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("candidate")
    parser.add_argument("--summary", type=Path, required=True)
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(args.input.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    path = Path(args.candidate)
    if not path.is_file():
        path = cif_path(args.candidate)
    phase = project.add_phase(
        str(path.resolve()), phasename=f"watch_{path.stem}", histograms=[hist], fmthint="CIF"
    )
    neutralize_hap(phase, hist)
    phase.getHAPvalues(hist)["Scale"] = [0.01, True]
    phase.set_refinements({"Cell": False})
    project.set_Controls("cycles", 25)
    project.save()
    # Scale-first challenge with every accepted common term reconverged.
    history = []
    for _ in range(2):
        project.do_refinements([{}])
        project.reload()
        history.append(collect(project))
    new_phase = project.phase(len(project.phases()) - 1)
    scale = new_phase.getHAPvalues(project.histogram(0))["Scale"][0]
    if scale > 0.01:
        new_phase.set_refinements({"Cell": True})
        for _ in range(2):
            project.do_refinements([{}])
            project.reload()
            history.append(collect(project))
    result = history[-1]
    result["history_wR"] = [item["residuals"]["wR"] for item in history]
    args.summary.write_text(json.dumps(result, indent=2, default=str) + "\n")
    project.save()


if __name__ == "__main__":
    main()
