#!/usr/bin/env python3
"""Create the bounded, full-range final GSAS-II project and exact exports."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main() -> None:
    G2sc.SetPrintLevel("all")
    project = G2sc.G2Project(
        str(ROOT / "alt231_polarization.gpx"), newgpx=str(ROOT / "final.gpx")
    )
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("x"))
    hist.Limits("lower", float(x[0]))
    hist.Limits("upper", float(x[-1]))
    hist.Excluded([])
    project.set_Controls("cycles", 30)

    # Explicit physical bounds for the accepted model.
    for variable in (":0:U", ":0:W", ":0:X"):
        project.set_Controls("parmMin", 0.0, variable)
    project.set_Controls("parmMin", 0.0, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    for phase_id in range(3):
        project.set_Controls("parmMin", 0.0, f"{phase_id}:0:Scale")
    for variable in ("0:0:Size;i", "2:0:Size;i"):
        project.set_Controls("parmMin", 0.005, variable)
        project.set_Controls("parmMax", 10.0, variable)
    project.set_Controls("parmMin", 0.2, "0:0:MD")
    project.set_Controls("parmMax", 5.0, "0:0:MD")

    # Confirm unsupported terms are fixed and neutral before the final replay.
    inst = hist.InstrumentParameters
    for key in ("V", "Y", "Z", "SH/L", "I(L2)/I(L1)"):
        inst[key][2] = False
    inst["V"][1] = 0.0
    inst["Y"][1] = 0.0
    inst["Z"][1] = 0.0
    inst["SH/L"][1] = 0.002
    inst["I(L2)/I(L1)"][1] = 0.5
    sample = hist.SampleParameters
    for key in ("DisplaceX", "DisplaceY", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in sample and isinstance(sample[key], list):
            sample[key][1] = False
    for key in ("DisplaceX", "DisplaceY", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in sample and isinstance(sample[key], list):
            sample[key][0] = 0.0

    project.save()
    replay = []
    for _ in range(3):
        project.do_refinements([{}])
        project.reload()
        cov = project.data["Covariance"]["data"]
        replay.append(
            {
                "Rwp": project.histogram(0).residuals["wR"],
                "max_shift_over_sigma": cov["Rvals"].get("Max shft/sig"),
                "converged": cov["Rvals"].get("converged"),
            }
        )
    project.save()

    # Reload once more so all exports demonstrably come from final.gpx.
    project = G2sc.G2Project(str(ROOT / "final.gpx"))
    hist = project.histogram(0)
    cif_names = ["phase_CaWO4.cif", "phase_WO3.cif", "phase_Ca3WO6.cif"]
    for phase, name in zip(project.phases(), cif_names):
        phase.export_CIF(str(ROOT / name))

    arrays = {
        "two_theta_deg": np.asarray(hist.getdata("x")),
        "observed": np.asarray(hist.getdata("yobs")),
        "calculated": np.asarray(hist.getdata("ycalc")),
        "difference": np.asarray(hist.getdata("residual")),
    }
    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(arrays.keys())
        writer.writerows(zip(*arrays.values()))

    residuals = hist.residuals
    covariance = project.data["Covariance"]["data"]
    fractions = hist.ComputeMassFracs()
    metrics = {
        "replay": replay,
        "residuals": residuals,
        "Rvals": covariance["Rvals"],
        "fractions": fractions,
        "instrument": {
            key: val[1]
            for key, val in hist.InstrumentParameters.items()
            if isinstance(val, list) and len(val) > 1
        },
        "background": hist.Background,
        "limits": [hist.Limits("lower"), hist.Limits("upper")],
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        metrics["phases"][phase.name] = {
            "composition": phase.composition,
            "density": phase.density,
            "cell": phase.get_cell_and_esd(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    (ROOT / "final_metrics.json").write_text(
        json.dumps(metrics, indent=2, default=lambda value: value.tolist() if hasattr(value, "tolist") else str(value))
        + "\n"
    )
    print(json.dumps({"replay": replay, "fractions": fractions, "residuals": residuals}, indent=2))


if __name__ == "__main__":
    main()
