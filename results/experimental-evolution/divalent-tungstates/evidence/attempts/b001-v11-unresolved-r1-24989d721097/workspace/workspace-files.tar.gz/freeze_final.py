import csv
import json
import math
import os

import numpy as np
import GSASIIscriptable as G2sc


SOURCE = "stability_base.gpx"
PROJECT = "final.gpx"
HIST = "PWDR pattern.csv"


project = G2sc.G2Project(gpxfile=SOURCE)
histogram = project.histogram(HIST)

# Freeze the full measured range and the retained shared profile model.
histogram.data["Limits"][1] = list(histogram.data["Limits"][0])
background = histogram.data["Background"][0]
background[2] = 12
del background[15:]

sample = histogram.data["Sample Parameters"]
for name in ("Absorption", "DisplaceX", "DisplaceY", "Transparency"):
    if name in sample:
        sample[name][0] = 0.0
        sample[name][1] = False
sample["SurfRoughA"] = [0.0, False]
sample["SurfRoughB"] = [0.0, False]
sample["Shift"][1] = True

instrument = histogram.data["Instrument Parameters"][0]
for name in ("V", "Y", "Z"):
    instrument[name][1] = 0.0
    instrument[name][2] = False
for name in ("U", "W", "X"):
    instrument[name][2] = True
instrument["Zero"][1] = 0.0
instrument["Zero"][2] = False
instrument["SH/L"][1] = 0.002
instrument["SH/L"][2] = False
instrument["Polariz."][2] = True
instrument["I(L2)/I(L1)"][1] = 0.5
instrument["I(L2)/I(L1)"][2] = False


def phase_histogram(name):
    return project.phase(name).data["Histograms"][HIST]


for phase in project.phases():
    phase.data["General"]["Cell"][0] = True
    for atom in phase.data["Atoms"]:
        atom[2] = ""
    data = phase_histogram(phase.name)
    data["Use"] = True
    data["Scale"][1] = True
    data["Extinction"] = [0.0, False]
    data["HStrain"][0] = [0.0] * len(data["HStrain"][0])
    data["HStrain"][1] = [False] * len(data["HStrain"][1])
    data["Babinet"]["BabA"] = [0.0, False]
    data["Babinet"]["BabU"] = [0.0, False]

ca = phase_histogram("CaWO4")
ca["Size"][0] = "uniaxial"
ca["Size"][2] = [True, True, False]
ca["Size"][3] = [0, 0, 1]
ca["Mustrain"][0] = "uniaxial"
ca["Mustrain"][2] = [True, True, False]
ca["Mustrain"][3] = [0, 0, 1]
ca["Pref.Ori."][0:4] = ["MD", ca["Pref.Ori."][1], True, [1, 1, 0]]

wo = phase_histogram("WO3")
wo["Size"][0] = "isotropic"
wo["Size"][1][0:3] = [10.0, 10.0, 1.0]
wo["Size"][2] = [False, False, False]
wo["Mustrain"][0] = "uniaxial"
wo["Mustrain"][2] = [True, True, False]
wo["Mustrain"][3] = [0, 1, 0]
wo["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]

ca3 = phase_histogram("Ca3WO6_P21n")
ca3["Size"][0] = "uniaxial"
ca3["Size"][2] = [True, True, False]
ca3["Size"][3] = [0, 1, 0]
ca3["Mustrain"][0] = "isotropic"
ca3["Mustrain"][2] = [True, False, False]
ca3["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]

project.data["Controls"]["data"]["Author"] = "OpenAI Codex"
project.save(PROJECT)

# First convergence from the pruned state.
project.refine()
project.save()

# Required reopen and full-range replay. All submitted products are generated
# from this in-memory instance after the replay.
project = G2sc.G2Project(gpxfile=PROJECT)
project.refine()
project.save()

histogram = project.histogram(HIST)
covariance = project.data["Covariance"]["data"]
rvals = covariance["Rvals"]
profile = histogram.data["data"][1]
instrument = histogram.data["Instrument Parameters"][0]

with open("fit.csv", "w", encoding="utf-8", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
    for two_theta, observed, calculated, difference in zip(
        profile[0], profile[1], profile[3], profile[5]
    ):
        writer.writerow(
            [
                f"{float(two_theta):.8f}",
                f"{float(observed):.8f}",
                f"{float(calculated):.8f}",
                f"{float(difference):.8f}",
            ]
        )

cif_paths = {
    "CaWO4": "CaWO4.cif",
    "WO3": "WO3.cif",
    "Ca3WO6_P21n": "Ca3WO6.cif",
}
for phase in project.phases():
    phase.export_CIF(cif_paths[phase.name])

phase_state = {}
for phase in project.phases():
    data = phase.data["Histograms"][HIST]
    fraction_key = f"{phase.id}:0:WgtFrac"
    fraction, fraction_su = covariance["depSigDict"][fraction_key]
    phase_state[phase.name] = {
        "id": phase.id,
        "cif_path": cif_paths[phase.name],
        "space_group": phase.data["General"]["SGData"]["SpGrp"],
        "cell": phase.get_cell(),
        "weight_fraction": float(fraction),
        "weight_fraction_su": float(fraction_su),
        "scale": data["Scale"],
        "size": data["Size"][:4],
        "strain": data["Mustrain"][:4],
        "texture": data["Pref.Ori."][:4],
    }

state = {
    "project_path": PROJECT,
    "fit_path": "fit.csv",
    "reopened_and_replayed": True,
    "full_range_deg": list(histogram.data["Limits"][1]),
    "Rwp_percent": float(rvals["Rwp"]),
    "Rp_percent": float(histogram.data["data"][0]["R"]),
    "GOF": float(rvals["GOF"]),
    "chi_squared": float(rvals["chisq"]),
    "Nobs": int(rvals["Nobs"]),
    "Nvars": int(rvals["Nvars"]),
    "converged": bool(rvals["converged"]),
    "max_shift_esd": float(rvals["Max shft/sig"]),
    "SVD0": int(rvals["SVD0"]),
    "background_terms": int(histogram.data["Background"][0][2]),
    "profile": {
        key: {
            "value": float(instrument_value[1]),
            "refined": bool(instrument_value[2]),
        }
        for key, instrument_value in histogram.data["Instrument Parameters"][0].items()
        if key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
    },
    "phases": phase_state,
}
with open("final_state.json", "w", encoding="utf-8") as stream:
    json.dump(state, stream, indent=2)

print(json.dumps(state, indent=2), flush=True)
