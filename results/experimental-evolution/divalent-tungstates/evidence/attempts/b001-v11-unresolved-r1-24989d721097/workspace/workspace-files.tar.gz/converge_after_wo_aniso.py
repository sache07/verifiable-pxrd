import json
import os

import numpy as np
import GSASIIscriptable as G2sc


HIST = "PWDR pattern.csv"
SOURCE = "rechallenge_wo_uniaxial_strain_010.gpx"


def hap(project, phase):
    return project.phase(phase).data["Histograms"][HIST]


def mutate_isotropic_wo(project):
    term = hap(project, "WO3")["Mustrain"]
    term[0] = "isotropic"
    term[1][0] = sum(term[1][:2]) / 2.0
    term[2] = [True, False, False]


def mutate_ca3_uniaxial(project, keys):
    for key in keys:
        term = hap(project, "Ca3WO6_P21n")[key]
        value = term[1][0]
        term[0] = "uniaxial"
        term[1][0:2] = [value, value]
        term[2] = [True, True, False]
        term[3] = [0, 1, 0]


def mutate_texture(project, phase, axis):
    term = hap(project, phase)["Pref.Ori."]
    term[0] = "MD"
    term[1] = 1.0
    term[2] = True
    term[3] = axis


def mutate_background16(project):
    values = project.histograms()[0].data["Background"][0]
    values.extend([0.0] * (16 - int(values[2])))
    values[2] = 16


def mutate_roughness(project):
    project.histograms()[0].data["Sample Parameters"]["SurfRoughB"] = [0.04, True]


def summarize(project):
    cov = project.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    names = list(cov["varyList"])
    sigmas = np.asarray(cov["sig"], dtype=float)
    covariance = np.asarray(cov["covMatrix"], dtype=float)
    corr = covariance / np.outer(sigmas, sigmas)
    high = []
    for i, first in enumerate(names):
        for j in range(i):
            value = float(corr[i, j])
            if abs(value) >= 0.85:
                high.append([value, first, names[j]])
    high.sort(key=lambda item: abs(item[0]), reverse=True)
    terms = {}
    for phase in project.phases():
        data = hap(project, phase.name)
        terms[phase.name] = {
            "size": data["Size"][:4],
            "strain": data["Mustrain"][:4],
            "texture": data["Pref.Ori."][:4],
        }
    fractions = {
        phase.name: list(cov["depSigDict"][f"{phase.id}:0:WgtFrac"])
        for phase in project.phases()
    }
    return {
        "Rwp": float(rvals["Rwp"]),
        "GOF": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "Nvars": int(rvals["Nvars"]),
        "max_shift_esd": float(rvals["Max shft/sig"]),
        "converged": bool(rvals["converged"]),
        "SVD0": int(rvals["SVD0"]),
        "terms": terms,
        "fractions": fractions,
        "high_correlations": high,
    }


def run(label, mutator=lambda project: None):
    target = f"post_aniso_{label}.gpx"
    project = G2sc.G2Project(gpxfile=SOURCE)
    project.save(target)
    mutator(project)
    project.save()
    history = []
    for replay in range(2):
        project.refine()
        rvals = project.data["Covariance"]["data"]["Rvals"]
        item = {
            "Rwp": float(rvals["Rwp"]),
            "max_shift_esd": float(rvals["Max shft/sig"]),
            "converged": bool(rvals["converged"]),
            "SVD0": int(rvals["SVD0"]),
        }
        history.append(item)
        print(label, replay + 1, item, flush=True)
    result = {"label": label, "project": target, "history": history}
    result.update(summarize(project))
    return result


variants = [
    ("base", lambda project: None),
    ("wo_isotropic", mutate_isotropic_wo),
    ("ca3_size_uniaxial_010", lambda p: mutate_ca3_uniaxial(p, ["Size"])),
    ("ca3_strain_uniaxial_010", lambda p: mutate_ca3_uniaxial(p, ["Mustrain"])),
    (
        "ca3_combined_uniaxial_010",
        lambda p: mutate_ca3_uniaxial(p, ["Size", "Mustrain"]),
    ),
    ("wo_texture_010", lambda p: mutate_texture(p, "WO3", [0, 1, 0])),
    ("ca3_texture_110", lambda p: mutate_texture(p, "Ca3WO6_P21n", [1, 1, 0])),
    ("background16", mutate_background16),
    ("roughness", mutate_roughness),
]
results = [run(label, mutator) for label, mutator in variants]
with open("post_aniso_rechallenge.json", "w", encoding="utf-8") as stream:
    json.dump(results, stream, indent=2)
print("WROTE post_aniso_rechallenge.json", flush=True)
