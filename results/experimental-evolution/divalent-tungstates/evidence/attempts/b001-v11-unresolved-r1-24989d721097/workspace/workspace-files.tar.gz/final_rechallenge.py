import copy
import json
import os

import numpy as np
import GSASIIscriptable as G2sc


HIST = "PWDR pattern.csv"
BASE = "final_loop_checkpoint.gpx"


def hap(project, phase):
    return project.phase(phase).data["Histograms"][HIST]


def covariance_summary(project):
    cov = project.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    names = list(cov["varyList"])
    sigmas = np.asarray(cov["sig"], dtype=float)
    covariance = np.asarray(cov["covMatrix"], dtype=float)
    correlations = covariance / np.outer(sigmas, sigmas)
    high = []
    for i, first in enumerate(names):
        for j in range(i):
            corr = float(correlations[i, j])
            if abs(corr) >= 0.90:
                high.append([corr, first, names[j]])
    high.sort(key=lambda item: abs(item[0]), reverse=True)
    fractions = {}
    for phase in project.phases():
        key = f"{phase.id}:0:WgtFrac"
        if key in cov.get("depSigDict", {}):
            fractions[phase.name] = list(cov["depSigDict"][key])
    return {
        "Rwp": float(rvals["Rwp"]),
        "GOF": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "Nvars": int(rvals["Nvars"]),
        "converged": bool(rvals["converged"]),
        "max_shift_esd": float(rvals["Max shft/sig"]),
        "high_correlations": high,
        "fractions": fractions,
        "profile": {
            key: project.histograms()[0].data["Instrument Parameters"][0][key][1]
            for key in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.")
        },
        "phase_terms": {
            phase.name: {
                "use": hap(project, phase.name)["Use"],
                "scale": hap(project, phase.name)["Scale"],
                "size": hap(project, phase.name)["Size"][:4],
                "strain": hap(project, phase.name)["Mustrain"][:4],
                "texture": hap(project, phase.name)["Pref.Ori."][:4],
            }
            for phase in project.phases()
        },
    }


def run(source, target, label, mutate=lambda project: None, replays=2):
    project = G2sc.G2Project(gpxfile=source)
    project.save(target)
    mutate(project)
    project.save()
    history = []
    for replay in range(replays):
        project.refine()
        rvals = project.data["Covariance"]["data"]["Rvals"]
        item = {
            "replay": replay + 1,
            "Rwp": float(rvals["Rwp"]),
            "GOF": float(rvals["GOF"]),
            "max_shift_esd": float(rvals["Max shft/sig"]),
            "converged": bool(rvals["converged"]),
        }
        history.append(item)
        print(label, item, flush=True)
        if rvals["Rwp"] > 4.0 or not rvals["converged"]:
            break
    result = {"label": label, "project": target, "history": history}
    result.update(covariance_summary(project))
    return result


def neutral_size(project, phase):
    term = hap(project, phase)["Size"]
    term[0] = "isotropic"
    term[1][0] = 10.0
    term[2] = [False, False, False]


def neutral_strain(project, phase):
    term = hap(project, phase)["Mustrain"]
    term[0] = "isotropic"
    term[1][0] = 0.0
    term[2] = [False, False, False]


def add_wo_size(project):
    term = hap(project, "WO3")["Size"]
    term[0] = "isotropic"
    term[1][0] = 5.0
    term[2] = [True, False, False]


def ca3_neutral(project):
    neutral_size(project, "Ca3WO6_P21n")
    neutral_strain(project, "Ca3WO6_P21n")


def ca_neutral(project):
    neutral_size(project, "CaWO4")
    neutral_strain(project, "CaWO4")


def ca_isotropic(project):
    size = hap(project, "CaWO4")["Size"]
    size[0] = "isotropic"
    size[1][0] = sum(size[1][:2]) / 2.0
    size[2] = [True, False, False]
    strain = hap(project, "CaWO4")["Mustrain"]
    strain[0] = "isotropic"
    strain[1][0] = sum(strain[1][:2]) / 2.0
    strain[2] = [True, False, False]


def wo_anisotropic(project):
    term = hap(project, "WO3")["Mustrain"]
    value = term[1][0]
    term[0] = "uniaxial"
    term[1][0:2] = [value, value]
    term[2] = [True, True, False]
    term[3] = [0, 1, 0]


def ca3_anisotropic(project):
    for key in ("Size", "Mustrain"):
        term = hap(project, "Ca3WO6_P21n")[key]
        value = term[1][0]
        term[0] = "uniaxial"
        term[1][0:2] = [value, value]
        term[2] = [True, True, False]
        term[3] = [0, 1, 0]


def background(project, count):
    values = project.histograms()[0].data["Background"][0]
    current = int(values[2])
    if count < current:
        del values[3 + count : 3 + current]
    elif count > current:
        values.extend([0.0] * (count - current))
    values[2] = count


def roughness(project):
    sample = project.histograms()[0].data["Sample Parameters"]
    sample["SurfRoughB"] = [0.04, True]


def no_texture(project):
    term = hap(project, "CaWO4")["Pref.Ori."]
    term[1] = 1.0
    term[2] = False


def add_texture(project, phase, axis):
    term = hap(project, phase)["Pref.Ori."]
    term[0] = "MD"
    term[1] = 1.0
    term[2] = True
    term[3] = axis


results = []
variants = [
    ("ca_isotropic", ca_isotropic),
    ("wo_uniaxial_strain_010", wo_anisotropic),
    ("ca3_uniaxial_combined_010", ca3_anisotropic),
    ("background_8", lambda p: background(p, 8)),
    ("background_16", lambda p: background(p, 16)),
    ("roughness_B", roughness),
    ("ca_texture_neutral", no_texture),
    ("wo_texture_010", lambda p: add_texture(p, "WO3", [0, 1, 0])),
    ("ca3_texture_110", lambda p: add_texture(p, "Ca3WO6_P21n", [1, 1, 0])),
]
for label, mutator in variants:
    results.append(
        run(BASE, f"rechallenge_{label}.gpx", label, mutator, replays=2)
    )

with open("final_rechallenge_remaining.json", "w", encoding="utf-8") as stream:
    json.dump(results, stream, indent=2)
print("WROTE final_rechallenge_remaining.json", flush=True)
