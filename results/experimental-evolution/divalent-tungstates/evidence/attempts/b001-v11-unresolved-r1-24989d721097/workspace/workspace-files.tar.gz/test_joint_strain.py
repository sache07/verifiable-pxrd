import json
import math
import os

import numpy as np
import GSASIIscriptable as G2sc


def summarize(project, label, cycle_history):
    cov = project.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    names = list(cov["varyList"])
    sigmas = np.asarray(cov["sig"], dtype=float)
    values = np.asarray(cov["variables"], dtype=float)
    covariance = np.asarray(cov["covMatrix"], dtype=float)
    correlations = covariance / np.outer(sigmas, sigmas)

    focus = {
        "0:0:Mustrain;i",
        "0:0:Mustrain;a",
        "0:0:Size;i",
        "0:0:Size;a",
        "1:0:Mustrain;i",
        "2:0:Mustrain;i",
        "2:0:Size;i",
        ":0:U",
        ":0:W",
        ":0:X",
    }
    focused_correlations = []
    for i, first in enumerate(names):
        for j in range(i):
            second = names[j]
            corr = float(correlations[i, j])
            if abs(corr) >= 0.70 and (first in focus or second in focus):
                focused_correlations.append([corr, first, second])
    focused_correlations.sort(key=lambda item: abs(item[0]), reverse=True)

    variable_summary = {}
    for name in focus:
        if name in names:
            idx = names.index(name)
            variable_summary[name] = {
                "value": float(values[idx]),
                "sigma": float(sigmas[idx]),
                "value_over_sigma": float(values[idx] / sigmas[idx]),
            }

    phase_data = {}
    for phase in project.phases():
        hap = phase.data["Histograms"]["PWDR pattern.csv"]
        phase_data[phase.name] = {
            "scale": hap["Scale"][0],
            "size": hap["Size"][1],
            "size_flags": hap["Size"][2],
            "strain": hap["Mustrain"][1],
            "strain_flags": hap["Mustrain"][2],
        }
    project.histograms()[0].ComputeMassFracs()
    fractions = {
        phase.name: phase.data["Histograms"]["PWDR pattern.csv"].get("WgtFrac")
        for phase in project.phases()
    }
    return {
        "label": label,
        "project": os.path.basename(project.filename),
        "cycle_history": cycle_history,
        "Rwp": float(rvals["Rwp"]),
        "GOF": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "Nobs": int(rvals["Nobs"]),
        "Nvars": int(rvals["Nvars"]),
        "converged": bool(rvals["converged"]),
        "max_shift_esd": float(rvals["Max shft/sig"]),
        "variables": variable_summary,
        "focused_correlations": focused_correlations,
        "phases": phase_data,
        "fractions": fractions,
    }


def refine_variant(source, target, label, mutate):
    project = G2sc.G2Project(gpxfile=source)
    project.save(target)
    mutate(project)
    project.save()
    cycle_history = []
    for cycle in range(3):
        project.refine()
        rvals = project.data["Covariance"]["data"]["Rvals"]
        cycle_history.append(
            {
                "cycle": cycle + 1,
                "Rwp": float(rvals["Rwp"]),
                "GOF": float(rvals["GOF"]),
                "chi_squared": float(rvals["chisq"]),
                "max_shift_esd": float(rvals["Max shft/sig"]),
                "converged": bool(rvals["converged"]),
            }
        )
        print(label, cycle_history[-1], flush=True)
    project.save()
    return summarize(project, label, cycle_history)


def add_ca3_strain(project):
    hap = project.phase("Ca3WO6_P21n").data["Histograms"]["PWDR pattern.csv"]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 500.0
    hap["Mustrain"][2][0] = True


def add_wo_strain(project):
    hap = project.phase("WO3").data["Histograms"]["PWDR pattern.csv"]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 450.0
    hap["Mustrain"][2][0] = True


results = [
    refine_variant(
        "final_loop_wo_strain.gpx",
        "joint_strain_from_wo.gpx",
        "joint_from_wo",
        add_ca3_strain,
    ),
    refine_variant(
        "final_loop_ca3_strain.gpx",
        "joint_strain_from_ca3.gpx",
        "joint_from_ca3",
        add_wo_strain,
    ),
]
print("JOINT_RESULTS=" + json.dumps(results, indent=2), flush=True)
