import json

import numpy as np
import GSASIIscriptable as G2sc


HIST = "PWDR pattern.csv"
ALT = "Ca3WO6_P21_alt"


def hap(project, phase):
    return project.phase(phase).data["Histograms"][HIST]


def wo_uniaxial(project):
    term = hap(project, "WO3")["Mustrain"]
    term[0] = "uniaxial"
    term[1][0:2] = [480.0, 810.0]
    term[2] = [True, True, False]
    term[3] = [0, 1, 0]


def alt_size_isotropic(project):
    term = hap(project, ALT)["Size"]
    term[0] = "isotropic"
    term[1][0] = 0.35
    term[2] = [True, False, False]


def alt_size_uniaxial(project):
    term = hap(project, ALT)["Size"]
    term[0] = "uniaxial"
    term[1][0:2] = [0.35, 0.45]
    term[2] = [True, True, False]
    term[3] = [0, 1, 0]


def alt_strain_uniaxial(project):
    term = hap(project, ALT)["Mustrain"]
    value = term[1][0]
    term[0] = "uniaxial"
    term[1][0:2] = [value, value]
    term[2] = [True, True, False]
    term[3] = [0, 1, 0]


def summarize(project):
    cov = project.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    names = list(cov["varyList"])
    sigmas = np.asarray(cov["sig"], dtype=float)
    matrix = np.asarray(cov["covMatrix"], dtype=float)
    corr = matrix / np.outer(sigmas, sigmas)
    high = []
    for i, first in enumerate(names):
        for j in range(i):
            value = float(corr[i, j])
            if abs(value) >= 0.85:
                high.append([value, first, names[j]])
    high.sort(key=lambda item: abs(item[0]), reverse=True)
    active = {}
    for phase in project.phases():
        data = hap(project, phase.name)
        if not data["Use"]:
            continue
        active[phase.name] = {
            "scale": data["Scale"],
            "size": data["Size"][:4],
            "strain": data["Mustrain"][:4],
            "texture": data["Pref.Ori."][:4],
        }
    return {
        "Rwp": float(rvals["Rwp"]),
        "GOF": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "Nvars": int(rvals["Nvars"]),
        "max_shift_esd": float(rvals["Max shft/sig"]),
        "converged": bool(rvals["converged"]),
        "SVD0": int(rvals["SVD0"]),
        "active_phases": active,
        "high_correlations": high,
    }


def run(source, target, label, mutator=lambda project: None):
    project = G2sc.G2Project(gpxfile=source)
    project.save(target)
    mutator(project)
    project.save()
    history = []
    for replay in range(3):
        project.refine()
        rvals = project.data["Covariance"]["data"]["Rvals"]
        state = {
            "Rwp": float(rvals["Rwp"]),
            "max_shift_esd": float(rvals["Max shft/sig"]),
            "SVD0": int(rvals["SVD0"]),
        }
        history.append(state)
        print(label, replay + 1, state, flush=True)
        if replay >= 1 and state["max_shift_esd"] < 0.05:
            break
    result = {"label": label, "project": target, "history": history}
    result.update(summarize(project))
    return result


base = run(
    "source_Ca3WO6_P21_strain.gpx",
    "p21_equal_base.gpx",
    "P21_strain_WO_aniso",
    wo_uniaxial,
)
variants = [
    ("P21_combined_isotropic", alt_size_isotropic),
    ("P21_size_uniaxial", alt_size_uniaxial),
    ("P21_strain_uniaxial", alt_strain_uniaxial),
]
results = [base]
for label, mutator in variants:
    results.append(run("p21_equal_base.gpx", f"p21_equal_{label}.gpx", label, mutator))
with open("p21_equal_profile.json", "w", encoding="utf-8") as stream:
    json.dump(results, stream, indent=2)
print("WROTE p21_equal_profile.json", flush=True)
