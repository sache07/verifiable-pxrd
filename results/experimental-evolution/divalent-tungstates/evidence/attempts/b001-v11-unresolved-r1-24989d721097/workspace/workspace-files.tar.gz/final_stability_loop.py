import json

import numpy as np
import GSASIIscriptable as G2sc


HIST = "PWDR pattern.csv"
SOURCE = "post_aniso_ca3_size_uniaxial_010.gpx"


def hap(project, phase):
    return project.phase(phase).data["Histograms"][HIST]


def wo_isotropic(project):
    term = hap(project, "WO3")["Mustrain"]
    term[0] = "isotropic"
    term[1][0] = sum(term[1][:2]) / 2.0
    term[2] = [True, False, False]


def wo_size(project):
    term = hap(project, "WO3")["Size"]
    term[0] = "isotropic"
    term[1][0] = 5.0
    term[2] = [True, False, False]


def ca3_size_isotropic(project):
    term = hap(project, "Ca3WO6_P21n")["Size"]
    term[0] = "isotropic"
    term[1][0] = sum(term[1][:2]) / 2.0
    term[2] = [True, False, False]


def ca3_strain_uniaxial(project):
    term = hap(project, "Ca3WO6_P21n")["Mustrain"]
    value = term[1][0]
    term[0] = "uniaxial"
    term[1][0:2] = [value, value]
    term[2] = [True, True, False]
    term[3] = [0, 1, 0]


def background(project, count):
    values = project.histograms()[0].data["Background"][0]
    current = int(values[2])
    if count < current:
        del values[3 + count : 3 + current]
    else:
        values.extend([0.0] * (count - current))
    values[2] = count


def roughness(project):
    project.histograms()[0].data["Sample Parameters"]["SurfRoughB"] = [0.04, True]


def texture(project, phase, axis):
    term = hap(project, phase)["Pref.Ori."]
    term[0] = "MD"
    term[1] = 1.0
    term[2] = True
    term[3] = axis


def ca_isotropic(project):
    for key in ("Size", "Mustrain"):
        term = hap(project, "CaWO4")[key]
        term[0] = "isotropic"
        term[1][0] = sum(term[1][:2]) / 2.0
        term[2] = [True, False, False]


def summary(project):
    cov = project.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    names = list(cov["varyList"])
    sigmas = np.asarray(cov["sig"], dtype=float)
    covariance = np.asarray(cov["covMatrix"], dtype=float)
    corr = covariance / np.outer(sigmas, sigmas)
    high = []
    for i, first in enumerate(names):
        for j in range(i):
            value = float(corr[i, j])
            if abs(value) >= 0.85:
                high.append([value, first, names[j]])
    high.sort(key=lambda item: abs(item[0]), reverse=True)
    return {
        "Rwp": float(rvals["Rwp"]),
        "GOF": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "Nvars": int(rvals["Nvars"]),
        "max_shift_esd": float(rvals["Max shft/sig"]),
        "converged": bool(rvals["converged"]),
        "SVD0": int(rvals["SVD0"]),
        "high_correlations": high,
        "fractions": {
            phase.name: list(cov["depSigDict"][f"{phase.id}:0:WgtFrac"])
            for phase in project.phases()
        },
        "terms": {
            phase.name: {
                "size": hap(project, phase.name)["Size"][:4],
                "strain": hap(project, phase.name)["Mustrain"][:4],
                "texture": hap(project, phase.name)["Pref.Ori."][:4],
            }
            for phase in project.phases()
        },
    }


def run(label, mutator=lambda project: None):
    target = f"stability_{label}.gpx"
    project = G2sc.G2Project(gpxfile=SOURCE)
    project.save(target)
    mutator(project)
    project.save()
    history = []
    for replay in range(2):
        project.refine()
        rvals = project.data["Covariance"]["data"]["Rvals"]
        state = {
            "Rwp": float(rvals["Rwp"]),
            "max_shift_esd": float(rvals["Max shft/sig"]),
            "SVD0": int(rvals["SVD0"]),
        }
        history.append(state)
        print(label, replay + 1, state, flush=True)
        if rvals["Rwp"] > 4.0:
            break
    result = {"label": label, "project": target, "history": history}
    result.update(summary(project))
    return result


variants = [
    ("base", lambda project: None),
    ("wo_isotropic", wo_isotropic),
    ("wo_size_add", wo_size),
    ("ca3_size_isotropic", ca3_size_isotropic),
    ("ca3_strain_uniaxial", ca3_strain_uniaxial),
    ("ca_isotropic", ca_isotropic),
    ("background8", lambda p: background(p, 8)),
    ("background16", lambda p: background(p, 16)),
    ("roughness", roughness),
    ("wo_texture", lambda p: texture(p, "WO3", [0, 1, 0])),
    ("ca3_texture", lambda p: texture(p, "Ca3WO6_P21n", [1, 1, 0])),
]
results = [run(label, mutator) for label, mutator in variants]
with open("final_stability_loop.json", "w", encoding="utf-8") as stream:
    json.dump(results, stream, indent=2)
print("WROTE final_stability_loop.json", flush=True)
