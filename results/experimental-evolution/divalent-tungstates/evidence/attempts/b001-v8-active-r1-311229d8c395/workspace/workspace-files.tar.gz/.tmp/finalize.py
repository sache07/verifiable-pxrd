from pathlib import Path
import csv
import json

import numpy as np
import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp" / "test_sh4_strain_replay_full.gpx"
PROJECT = ROOT / "final.gpx"


def neutralize_phase_terms(project):
    hist = project.histograms()[0]
    hname = hist.name
    for phase in project.phases():
        hap = phase.data["Histograms"][hname]
        hap["Use"] = True
        hap["LeBail"] = False
        hap["Scale"][1] = True

        size = hap["Size"]
        size[0] = "isotropic"
        size[1][:] = [10.0, 10.0, 1.0]
        size[2][:] = [False] * len(size[2])
        size[3][:] = [0, 0, 1]
        size[4][:] = [1.0, 1.0, 1.0, 0.0, 0.0, 0.0]
        size[5][:] = [False] * len(size[5])

        strain = hap["Mustrain"]
        strain[0] = "isotropic"
        strain[1][1:] = [0.0, 1.0]
        strain[2][:] = [False] * len(strain[2])
        strain[3][:] = [0, 0, 1]
        strain[4][:] = [0.01] * len(strain[4])
        strain[5][:] = [False] * len(strain[5])
        if phase.name == "WO3":
            strain[2][0] = True
        else:
            strain[1][0] = 0.0

        hstrain = hap["HStrain"]
        hstrain[0][:] = [0.0] * len(hstrain[0])
        hstrain[1][:] = [False] * len(hstrain[1])
        hap["Extinction"][:] = [0.0, False]
        hap["Babinet"]["BabA"][:] = [0.0, False]
        hap["Babinet"]["BabU"][:] = [0.0, False]
        if "Layer Disp" in hap:
            hap["Layer Disp"][:] = [0.0, False]

        if phase.name == "SrWO4":
            po = hap["Pref.Ori."]
            po[0] = "SH"
            po[1] = 1.0
            po[2] = True
            po[3][:] = [0, 0, 1]
            po[4] = 4
            po[6][:] = []
            po[7] = 0.1
        elif phase.name == "WO3":
            ratio = float(hap["Pref.Ori."][1])
            hap["Pref.Ori."][:] = ["MD", ratio, True, [1, 0, -1], 0, {}, [], 0.1]
        else:
            hap["Pref.Ori."][:] = ["MD", 1.0, False, [0, 0, 1], 0, {}, [], 0.1]


def neutralize_histogram_terms(project):
    hist = project.histograms()[0]
    x = np.asarray(hist.data["data"][1][0], dtype=float)
    hist.data["Limits"][1][:] = [float(x[0]), float(x[-1])]

    sample = hist.data["Sample Parameters"]
    sample["Scale"][:] = [1.0, False]
    sample["Absorption"][:] = [0.0, False]
    sample["DisplaceX"][:] = [0.0, False]
    sample["DisplaceY"][:] = [0.0, False]
    sample["Transparency"][:] = [0.0, False]
    sample["SurfRoughA"][:] = [0.0, False]
    sample["SurfRoughB"][:] = [0.0, False]
    sample["Shift"][1] = True

    inst = hist.data["Instrument Parameters"][0]
    inst["Zero"][1:] = [0.0, False]
    inst["I(L2)/I(L1)"][1:] = [0.5, False]
    inst["Polariz."][2] = True
    inst["U"][1:] = [0.0, False]
    inst["V"][1:] = [0.0, False]
    inst["W"][2] = True
    inst["X"][2] = True
    inst["Y"][1:] = [0.0, False]
    inst["Z"][1:] = [0.0, False]
    inst["SH/L"][1:] = [0.002, False]

    background = hist.data["Background"]
    background[0][0] = "chebyschev-1"
    background[0][1] = True
    background[0][2] = 6
    background[1]["nDebye"] = 0
    background[1]["debyeTerms"] = []
    background[1]["nPeaks"] = 0
    background[1]["peaksList"] = []
    background[1]["background PWDR"][:] = ["", 1.0, False]


def export_outputs(project):
    names = {
        "SrWO4": ROOT / "phase_srwo4.cif",
        "WO3": ROOT / "phase_wo3.cif",
        "SrCO3": ROOT / "phase_srco3.cif",
    }
    for phase in project.phases():
        phase.export_CIF(str(names[phase.name]))

    hist = project.histograms()[0]
    x, observed, weights, calculated, background, difference = [
        np.asarray(v, dtype=float) for v in hist.data["data"][1]
    ]
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        writer.writerows(zip(x, observed, calculated, observed - calculated, background))

    cov = project.data["Covariance"]["data"]
    stats = hist.data["data"][0]
    summary = {
        "rwp_percent": float(stats["wR"]),
        "rp_percent": float(stats["R"]),
        "rbkg_percent": float(stats["Rb"]),
        "rwp_bkg_percent": float(stats["wRb"]),
        "rexp_percent": float(stats["wRmin"]),
        "gof": float(cov["Rvals"]["GOF"]),
        "chi_squared": float(cov["Rvals"]["chisq"]),
        "n_observations": int(stats["Nobs"]),
        "n_parameters": int(len(cov["varyList"])),
        "durbin_watson": float(stats["Durbin-Watson"]),
        "max_shift_over_esd": float(cov["Rvals"].get("Max shft/sig", np.nan)),
        "mass_fractions": hist.ComputeMassFracs(),
        "cells": {
            phase.name: phase.get_cell_and_esd() for phase in project.phases()
        },
        "profile": {
            "polarization": float(hist.data["Instrument Parameters"][0]["Polariz."][1]),
            "W": float(hist.data["Instrument Parameters"][0]["W"][1]),
            "X": float(hist.data["Instrument Parameters"][0]["X"][1]),
            "sample_shift_micrometres": float(hist.data["Sample Parameters"]["Shift"][0]),
            "wo3_microstrain_ppm": float(
                project.phase("WO3").data["Histograms"][hist.name]["Mustrain"][1][0]
            ),
        },
    }
    (ROOT / ".tmp" / "final_summary.json").write_text(
        json.dumps(summary, indent=2, default=lambda obj: list(obj)) + "\n"
    )


project = G2sc.G2Project(str(SOURCE), newgpx=str(PROJECT))
neutralize_phase_terms(project)
neutralize_histogram_terms(project)
project.data["Controls"]["data"]["max cyc"] = 8
project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
project.save(str(PROJECT))

# Explicitly reopen and replay the complete measured angular range twice. The
# second replay verifies convergence from the saved accepted state.
for _ in range(2):
    project = G2sc.G2Project(str(PROJECT))
    project.do_refinements([{}])

project = G2sc.G2Project(str(PROJECT))
export_outputs(project)
print((ROOT / ".tmp" / "final_summary.json").read_text())
