#!/usr/bin/env python3
"""Export and verify deliverables from the converged final.gpx project."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
PROJECT = HERE / "final.gpx"

PHASE_META = {
    "SrWO4_scheelite": {
        "display_name": "SrWO4 (scheelite)",
        "formula": "SrWO4",
        "space_group_number": 88,
        "cif": "SrWO4_scheelite.cif",
        "source": "COD 2300460 SrMoO4, with Mo replaced by W",
    },
    "WO3": {
        "display_name": "WO3 (monoclinic)",
        "formula": "WO3",
        "space_group_number": 14,
        "cif": "WO3_monoclinic.cif",
        "source": "COD 2311041",
    },
    "SrCO3": {
        "display_name": "SrCO3 (strontianite)",
        "formula": "SrCO3",
        "space_group_number": 62,
        "cif": "SrCO3_strontianite.cif",
        "source": "COD 9008198",
    },
}


def covariance_map(gpx: G2sc.G2Project) -> dict[str, tuple[float, float]]:
    cov = gpx.data["Covariance"]["data"]
    return {
        str(name): (float(value), float(su))
        for name, value, su in zip(cov["varyList"], cov["variables"], cov["sig"])
    }


def rounded_cell(cell: dict, cell_su: dict) -> dict:
    key_map = {
        "length_a": "a_angstrom",
        "length_b": "b_angstrom",
        "length_c": "c_angstrom",
        "angle_alpha": "alpha_deg",
        "angle_beta": "beta_deg",
        "angle_gamma": "gamma_deg",
        "volume": "volume_angstrom3",
    }
    return {
        key_map[key]: {"value": float(cell[key]), "formal_su": float(cell_su[key])}
        for key in key_map
    }


def main() -> None:
    G2sc.SetPrintLevel("warn")
    gpx = G2sc.G2Project(str(PROJECT))
    hist = gpx.histogram(0)
    if gpx.get_Frozen():
        raise RuntimeError(f"Final project has frozen variables: {gpx.get_Frozen()}")
    if [p.name for p in gpx.phases()] != list(PHASE_META):
        raise RuntimeError("Unexpected final phase order/names")

    # Native GSAS-II phase exports from the exact submitted project.
    for phase in gpx.phases():
        phase.export_CIF(str(HERE / PHASE_META[phase.name]["cif"]))

    x = np.asarray(hist.getdata("x"), dtype=float)
    yobs = np.asarray(hist.getdata("yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("ycalc"), dtype=float)
    difference = np.asarray(hist.getdata("residual"), dtype=float)
    if not np.allclose(difference, yobs - ycalc, atol=1e-10, rtol=0.0):
        raise RuntimeError("Stored GSAS-II residual does not equal observed-calculated")
    with (HERE / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
        writer.writerows(
            (f"{xx:.8f}", f"{yo:.8f}", f"{yc:.8f}", f"{dy:.8f}")
            for xx, yo, yc, dy in zip(x, yobs, ycalc, difference)
        )

    fractions = hist.ComputeMassFracs()
    fraction_sum = sum(value for value, _ in fractions.values())
    if not math.isclose(fraction_sum, 1.0, abs_tol=2e-12):
        raise RuntimeError(f"Mass fractions do not sum to one: {fraction_sum}")

    residuals = hist.residuals
    cov_data = gpx.data["Covariance"]["data"]
    cov_values = covariance_map(gpx)
    vary_names = [str(v) for v in cov_data["varyList"]]
    cov_matrix = np.asarray(cov_data["covMatrix"], dtype=float)
    cov_sigma = np.sqrt(np.diag(cov_matrix))
    correlation = cov_matrix / np.outer(cov_sigma, cov_sigma)
    np.fill_diagonal(correlation, 0.0)
    corr_index = np.unravel_index(np.nanargmax(np.abs(correlation)), correlation.shape)
    max_corr = float(correlation[corr_index])
    scale_pol_corr = float(
        correlation[
            vary_names.index("0:0:Scale"), vary_names.index(":0:Polariz.")
        ]
    )
    short_contacts = {phase.name: phase.ShortDistances() for phase in gpx.phases()}
    if any(short_contacts.values()):
        raise RuntimeError(f"Unphysical short contacts found: {short_contacts}")
    phase_results = []
    for phase in gpx.phases():
        meta = PHASE_META[phase.name]
        value, su = fractions[phase.name]
        cell, cell_su = phase.get_cell_and_esd()
        pid = phase.id
        phase_results.append(
            {
                "name": meta["display_name"],
                "formula": meta["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "space_group_number": meta["space_group_number"],
                "cif_path": meta["cif"],
                "structure_source": meta["source"],
                "weight_fraction": float(value),
                "weight_percent": float(100.0 * value),
                "weight_fraction_formal_su": float(su),
                "cell": rounded_cell(cell, cell_su),
                "phase_fit_statistics": {
                    "R_F_percent": float(residuals[f"{pid}:0:Rf"]),
                    "R_F_squared_percent": float(residuals[f"{pid}:0:Rf^2"]),
                    "reflection_count": int(residuals[f"{pid}:0:Nref"]),
                },
            }
        )

    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    result = {
        "input_pattern": "inputs/pattern.csv",
        "metadata": "inputs/metadata.json",
        "final_project": "final.gpx",
        "fit_profile": "fit.csv",
        "modeled_crystalline_phase_count": len(phase_results),
        "weight_fraction_basis": (
            "Normalized over the modeled crystalline phases only; no amorphous "
            "or unmodeled fraction is quantified."
        ),
        "phases": phase_results,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(cov_data["Rvals"]["GOF"]),
            "chi_square": float(cov_data["Rvals"]["chisq"]),
            "number_of_observations": int(cov_data["Rvals"]["Nobs"]),
            "number_of_refined_variables": int(cov_data["Rvals"]["Nvars"]),
            "maximum_shift_over_su": float(cov_data["Rvals"]["Max shft/sig"]),
            "two_theta_range_deg": [float(x.min()), float(x.max())],
            "weighting": (
                "GSAS-II Poisson surrogate weights (1/I), because pointwise "
                "standard uncertainties were not supplied."
            ),
        },
        "refinement_model": {
            "wavelength_Kalpha1_angstrom": float(inst["Lam1"][1]),
            "wavelength_Kalpha2_angstrom": float(inst["Lam2"][1]),
            "Kalpha2_to_Kalpha1_ratio": float(inst["I(L2)/I(L1)"][1]),
            "common_profile": {
                key: float(inst[key][1]) for key in ["U", "V", "W", "X", "Y", "Z", "SH/L"]
            },
            "effective_specimen_displacement_micrometre": {
                "value": float(sample["Shift"][0]),
                "formal_su": cov_values[":0:Shift"][1],
            },
            "polarization": {
                "value": float(inst["Polariz."][1]),
                "formal_su": cov_values[":0:Polariz."][1],
            },
            "WO3_isotropic_microstrain": {
                "value_microstrain": cov_values["1:0:Mustrain;i"][0],
                "formal_su_microstrain": cov_values["1:0:Mustrain;i"][1],
            },
            "march_dollase": {
                "SrWO4_[110]": {
                    "value": cov_values["0:0:MD"][0],
                    "formal_su": cov_values["0:0:MD"][1],
                },
                "WO3_[101]": {
                    "value": cov_values["1:0:MD"][0],
                    "formal_su": cov_values["1:0:MD"][1],
                },
                "SrCO3_[001]": {
                    "value": cov_values["2:0:MD"][0],
                    "formal_su": cov_values["2:0:MD"][1],
                },
            },
        },
        "uncertainty_note": (
            "Weight-fraction uncertainties are covariance-based formal values. "
            "They exclude structural-model, preferred-orientation, angular-"
            "calibration, absorption and unmodeled/amorphous-phase systematics."
        ),
        "validation": {
            "frozen_variables": gpx.get_Frozen(),
            "short_contact_check_below_1p1_angstrom": "passed",
            "largest_off_diagonal_correlation": {
                "coefficient": max_corr,
                "variables": [vary_names[corr_index[0]], vary_names[corr_index[1]]],
            },
            "SrWO4_scale_polarization_correlation": scale_pol_corr,
            "CIF_round_trip_project_agreement": "passed",
        },
    }
    (HERE / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    # Chemistry check: the residual precursor moles should be similar for a
    # partially completed 1:1 SrCO3 + WO3 -> SrWO4 + CO2 reaction.
    formula_masses = {
        "SrWO4_scheelite": 335.466,
        "WO3": 231.847,
        "SrCO3": 147.628,
    }
    moles_per_100g = {
        key: 100.0 * fractions[key][0] / formula_masses[key] for key in fractions
    }
    conversion = moles_per_100g["SrWO4_scheelite"] / (
        moles_per_100g["SrWO4_scheelite"]
        + 0.5 * (moles_per_100g["WO3"] + moles_per_100g["SrCO3"])
    )

    p0, p1, p2 = phase_results
    report = f"""# PXRD phase analysis

## Result

The pattern is modeled by three crystalline phases. Fractions are normalized to these phases; no amorphous fraction can be measured without an internal standard.

| Phase | Space group | Refined cell (Å, °) | Weight fraction |
|---|---|---|---:|
| SrWO4, scheelite | I41/a (No. 88) | a = {p0['cell']['a_angstrom']['value']:.6f}, c = {p0['cell']['c_angstrom']['value']:.6f} | {p0['weight_percent']:.2f} ± {100*p0['weight_fraction_formal_su']:.2f} wt% |
| WO3, monoclinic | P21/c (No. 14, nonconventional source setting) | a = {p1['cell']['a_angstrom']['value']:.5f}, b = {p1['cell']['b_angstrom']['value']:.5f}, c = {p1['cell']['c_angstrom']['value']:.5f}, β = {p1['cell']['beta_deg']['value']:.5f} | {p1['weight_percent']:.2f} ± {100*p1['weight_fraction_formal_su']:.2f} wt% |
| SrCO3, strontianite | Pnma (No. 62) | a = {p2['cell']['a_angstrom']['value']:.5f}, b = {p2['cell']['b_angstrom']['value']:.5f}, c = {p2['cell']['c_angstrom']['value']:.5f} | {p2['weight_percent']:.2f} ± {100*p2['weight_fraction_formal_su']:.2f} wt% |

Final full-range statistics are Rwp = {residuals['wR']:.4f}%, Rp = {residuals['R']:.4f}%, Rexp = {residuals['wRmin']:.4f}% and goodness-of-fit = {cov_data['Rvals']['GOF']:.3f} for {len(x):,} points.

## Evidence and model selection

The SrWO4 assignment accounts for resolved low-, middle- and high-angle scheelite families. Because the supplied index has no exact SrWO4 entry, COD 2300460 (room-temperature, fully occupied SrMoO4 in I41/a) was selected from stoichiometric analogues and Mo was replaced by W. CaWO4 required an additional A-site substitution, while the available BaWO4 record has split half-occupied oxygen sites. The final substituted model has no short contacts (W–O = 1.727 Å; Sr–O = 2.606–2.610 Å).

Monoclinic WO3 is required by the diagnostic 22.52/22.94/23.82° triplet. The fully occupied neutron model COD 2311041 outperformed the alternative conventional monoclinic record and tetragonal polymorphs under the same nuisance model. Orthorhombic room-temperature SrCO3 (COD 9008198) explains the 24.62–25.30° carbonate group; a high-temperature disordered R-3m record fit worse. A watched Sr3W2O9 candidate refined to the nonnegative scale floor, and its unique low-angle families are absent.

The phase fractions are chemically coherent with partial reaction of the reported precursors: per 100 g of modeled crystal content, residual WO3 and SrCO3 are {moles_per_100g['WO3']:.4f} and {moles_per_100g['SrCO3']:.4f} mol, respectively. Their near 1:1 ratio is expected for SrCO3 + WO3 → SrWO4 + CO2 and corresponds to about {100*conversion:.0f}% conversion on this crystalline-only basis.

The Cu Kα1/Kα2 doublet was modeled explicitly. A specimen-displacement-only branch was retained over zero-only; the refined {sample['Shift'][0]:.0f} µm value should be treated as an effective angular correction because no independent calibration was supplied. The common nonnegative profile converged from two interior starts; U returned to zero, while W, X and SH/L were retained. Only WO3 isotropic strain survived phase-by-phase size/strain replay. An eight-term smooth background was retained; extra background terms gave negligible gain. Polarization survived three starts, whereas roughness was unstable, bound-hitting and highly correlated. March–Dollase axes [110] for SrWO4, [101] for WO3 and [001] for SrCO3 were supported by multiple isolated families and conditional axis swaps. The final project was saved, reopened and replayed over the complete measured range with no frozen parameters.

## Remaining uncertainty

The final audit found no frozen/bound variables or sub-1.1 Å contacts, and all exported CIFs round-trip to the project cells and atom counts. The largest off-diagonal correlation is {max_corr:+.3f} between {vary_names[corr_index[0]]} and {vary_names[corr_index[1]]} (coupled WO3 reciprocal-cell terms); the SrWO4 scale–polarization correlation is {scale_pol_corr:+.3f}.

The tabulated uncertainties are formal covariance values only. Pointwise uncertainties were absent, so 1/I Poisson-surrogate weights were used. Preferred orientation, the large uncalibrated angular correction, fixed source coordinates/occupancies and the SrMoO4→SrWO4 prototype substitution create larger model-systematic uncertainty than the formal sub-0.2 wt% values; the fractions are best regarded as robust to a few absolute wt%, not to their last reported decimal. Atomic coordinates were not independently refined from this multiphase laboratory pattern. A very weak phase with fully overlapped peaks cannot be excluded or quantified reliably.
"""
    (HERE / "report.md").write_text(report)

    # Round-trip all exported CIFs and check project/export agreement.
    check = G2sc.G2Project(newgpx=str(HERE / ".tmp" / "cif_roundtrip.gpx"))
    for original in gpx.phases():
        path = HERE / PHASE_META[original.name]["cif"]
        imported = check.add_phase(str(path), phasename=original.name, fmthint="CIF")
        c0 = original.get_cell()
        c1 = imported.get_cell()
        scalar_keys = [
            "length_a",
            "length_b",
            "length_c",
            "angle_alpha",
            "angle_beta",
            "angle_gamma",
        ]
        if max(abs(c0[key] - c1[key]) for key in scalar_keys) > 2e-4:
            raise RuntimeError(f"CIF cell mismatch for {original.name}")
        if abs(c0["volume"] - c1["volume"]) > 0.02:
            raise RuntimeError(f"CIF volume mismatch for {original.name}")
        if len(original.atoms()) != len(imported.atoms()):
            raise RuntimeError(f"CIF atom-count mismatch for {original.name}")

    print(
        json.dumps(
            {
                "rows_in_fit_csv": len(x),
                "fraction_sum": fraction_sum,
                "cifs_round_trip_verified": True,
                "frozen_variables": gpx.get_Frozen(),
                "Rwp_percent": residuals["wR"],
            }
        )
    )


if __name__ == "__main__":
    main()
