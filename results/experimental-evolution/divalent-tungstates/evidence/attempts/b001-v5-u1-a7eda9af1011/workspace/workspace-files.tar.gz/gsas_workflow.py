#!/usr/bin/env python3
"""GSAS-II screening and refinement helpers for the supplied PXRD pattern.

This script is intentionally explicit about nuisance/profile terms so that
candidate structures are compared under the same model. It writes trial GPX
files below trials/ and prints a compact JSON summary for each fit.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


HERE = Path(__file__).resolve().parent
PATTERN = HERE / "inputs" / "pattern.csv"
INSTRUMENT = HERE / "instrument.instprm"
CIF_ROOT = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)


def cod_cif(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


SRMOO4 = cod_cif("2300460")
SRCO3_ORTHO = cod_cif("9008198")
SRCO3_RHOMBO = cod_cif("1539128")

WO3_CANDIDATES = {
    "p21n_1960": cod_cif("1528915"),
    "p21c_hp": cod_cif("1563541"),
    "p21c_1966": cod_cif("2311041"),
    "triclinic": cod_cif("2106293"),
    "pnma": cod_cif("2107312"),
    "p21m": cod_cif("1010618"),
    "p4ncc": cod_cif("1521532"),
    "p4nmm": cod_cif("1521533"),
    "p6mmm": cod_cif("1004057"),
}


def set_cell(phase, cell: list[float]) -> None:
    phase.data["General"]["Cell"][1:7] = [float(v) for v in cell]
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def substitute_srwo4(phase) -> None:
    """Convert the screened SrMoO4 scheelite parent to SrWO4."""
    for atom in phase.atoms():
        if atom.element == "Mo":
            atom.type = "W+6"
            atom.label = "W1"
    phase.data["General"]["Name"] = phase.name
    # Refresh scattering factors, mass, density and composition after substitution.
    G2sc.SetupGeneral(phase.data, None)


def neutralize_hap(phase, hist_name: str) -> None:
    """Remove broadening/texture defaults that otherwise alter comparisons."""
    hap = phase.data["Histograms"][hist_name]
    # Preserve a converged scale when this is called on an existing project;
    # newly-added phases carry the GSAS-II default value of one.
    scale = float(hap.get("Scale", [1.0])[0])
    hap["Scale"] = [scale, True]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [1.0e6, 1.0e6, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    if "Layer Disp" in hap:
        hap["Layer Disp"] = [0.0, False]


def configure_histogram(hist) -> None:
    # Use the complete measured interval (metadata/pattern.csv), including the
    # short tails beyond the round-number 10--100 degree range.
    hist.set_refinements({"Limits": [9.90343322, 100.09455322]})
    hist.Excluded([])
    # Eight-term smooth Chebyshev background; coefficients start from a flat
    # level close to the measured baseline.
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
                "coeffs": [1080.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            }
        }
    )
    sample = hist.SampleParameters
    sample["Scale"] = [1.0, False]
    sample["Type"] = "Bragg-Brentano"
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    inst = hist.InstrumentParameters
    # Keep source wavelengths and ratio fixed to metadata values.
    for key, val in {
        "Lam1": 1.540598,
        "Lam2": 1.544426,
        "I(L2)/I(L1)": 0.5,
        "Polariz.": 0.5,
        "Zero": 0.0,
        "U": 120.0,
        "V": 0.0,
        "W": 55.0,
        "X": 4.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.01,
    }.items():
        if key in inst:
            inst[key][1] = val
            inst[key][2] = False


def make_project(
    output: Path,
    wo3: Path,
    carbonate: Path = SRCO3_ORTHO,
    include_wo3: bool = True,
    include_carbonate: bool = True,
) -> G2sc.G2Project:
    output.parent.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(newgpx=str(output))
    hist = gpx.add_powder_histogram(
        str(PATTERN), str(INSTRUMENT), fmthint="comma"
    )
    configure_histogram(hist)

    main = gpx.add_phase(
        str(SRMOO4), phasename="SrWO4_scheelite", histograms=[hist], fmthint="CIF"
    )
    substitute_srwo4(main)
    # Indexed from resolved low-, mid- and high-angle scheelite families with
    # a provisional common angular correction.
    set_cell(main, [5.40, 5.40, 11.91, 90.0, 90.0, 90.0])

    phases = [main]
    if include_wo3:
        phases.append(
            gpx.add_phase(
                str(wo3), phasename="WO3", histograms=[hist], fmthint="CIF"
            )
        )
    if include_carbonate:
        phases.append(
            gpx.add_phase(
                str(carbonate), phasename="SrCO3", histograms=[hist], fmthint="CIF"
            )
        )
    for phase in phases:
        neutralize_hap(phase, hist.name)

    gpx.set_Controls("cycles", 5)
    # Physical bounds for the common profile and provisional angular correction.
    for var, lo, hi in [
        (":0:U", 0.0, 1000.0),
        (":0:W", 0.0, 500.0),
        (":0:X", 0.0, 100.0),
        (":0:SH/L", 0.0002, 0.08),
        (":0:Zero", -1.5, 1.5),
        (":0:Shift", -2000.0, 2000.0),
    ]:
        gpx.set_Controls("parmMin", lo, variable=var)
        gpx.set_Controls("parmMax", hi, variable=var)
    for phase in phases:
        # Negative phase scales are never physically admissible and can send a
        # weak candidate's cell refinement into an invalid metric tensor.
        gpx.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
        gpx.set_Controls("parmMax", 1000.0, variable=f"{phase.id}:0:Scale")
    gpx.save()
    return gpx


def clear_all_refine_flags(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    hist.clear_refinements(
        {
            "Background": True,
            "Sample Parameters": [k for k, v in hist.SampleParameters.items() if isinstance(v, list) and len(v) > 1],
            "Instrument Parameters": [
                k for k, v in hist.InstrumentParameters.items() if isinstance(v, list) and len(v) > 2
            ],
        }
    )
    for phase in gpx.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "HStrain": True,
                "Pref.Ori.": True,
                "Extinction": True,
                "Babinet": ["BabA", "BabU"],
            }
        )


def run_provisional(
    gpx: G2sc.G2Project, angular: str = "zero", refine_profile: bool = False
) -> None:
    """Converge common modest nuisance terms for inventory comparison."""
    clear_all_refine_flags(gpx)
    hist = gpx.histogram(0)
    hist.set_refinements({"Background": True})
    phases = gpx.phases()
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})

    # Start each angular branch from the interior solution obtained by fitting
    # resolved scheelite families. The parameter remains fixed for the first
    # scale pass and is released only after each cell has been challenged.
    if angular == "zero":
        hist.InstrumentParameters["Zero"][1] = -0.60
    elif angular == "shift":
        hist.SampleParameters["Shift"][0] = 950.0
    elif angular != "none":
        raise ValueError(angular)

    # Establish nonnegative scales before allowing any cell to move.
    gpx.refine()

    # Move cells one phase at a time. This keeps a weak trial candidate from
    # destabilizing otherwise well-determined phases.
    for phase in phases:
        for other in phases:
            other.clear_refinements({"Cell": True})
        if phase_scale(phase, hist.name) <= 1.0e-8:
            continue
        phase.set_refinements({"Cell": True})
        gpx.refine()

    # Re-converge all cells/scales/background with one provisional angular term.
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        if phase_scale(phase, hist.name) > 1.0e-8:
            phase.set_refinements({"Cell": True})
    if angular == "zero":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    elif angular == "shift":
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    gpx.refine()

    if refine_profile:
        # Fit the same nonnegative common profile for selected inventory branches.
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
        gpx.refine()
        frozen = gpx.get_Frozen()
        profile_frozen = [
            v for v in frozen if v.rsplit(":", 1)[-1] in {"U", "W", "X", "SH/L"}
        ]
        if profile_frozen:
            # A bound branch is retried from an interior point, rather than
            # interpreted as absence of that term.
            for variable in profile_frozen:
                gpx.set_Frozen(variable=variable)
            inst = hist.InstrumentParameters
            for key, val in {"U": 160.0, "W": 45.0, "X": 3.0, "SH/L": 0.008}.items():
                inst[key][1] = val
            gpx.refine()
    gpx.save()


def phase_scale(phase, hist_name: str) -> float:
    return float(phase.data["Histograms"][hist_name]["Scale"][0])


def summary(gpx: G2sc.G2Project) -> dict:
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    return {
        "project": gpx.filename,
        "residuals": hist.residuals,
        "profile": {
            k: inst[k][1]
            for k in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]
            if k in inst
        },
        "sample": {
            k: v[0]
            for k, v in hist.SampleParameters.items()
            if k in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]
        },
        "frozen": gpx.get_Frozen(),
        "phases": [
            {
                "name": phase.name,
                "scale": phase_scale(phase, hist.name),
                "cell": phase.get_cell(),
                "density": phase.density,
            }
            for phase in gpx.phases()
        ],
    }


def cmd_screen(args) -> None:
    labels = list(WO3_CANDIDATES) if args.wo3 == "all" else [args.wo3]
    for label in labels:
        profile_tag = (
            f"_{args.profile_start}" if args.profile or args.profile_start != "default" else ""
        )
        out = HERE / "trials" / f"screen_{label}_{args.carbonate}_{args.angular}{profile_tag}.gpx"
        carbonate = SRCO3_ORTHO if args.carbonate == "ortho" else SRCO3_RHOMBO
        try:
            gpx = make_project(out, WO3_CANDIDATES[label], carbonate=carbonate)
            if args.profile_start == "alt":
                inst = gpx.histogram(0).InstrumentParameters
                for key, val in {"U": 260.0, "W": 30.0, "X": 1.5, "SH/L": 0.004}.items():
                    inst[key][1] = val
            elif args.profile_start == "converged":
                inst = gpx.histogram(0).InstrumentParameters
                for key, val in {"U": 0.0, "W": 41.41, "X": 4.69, "SH/L": 0.0002}.items():
                    inst[key][1] = val
            run_provisional(gpx, angular=args.angular, refine_profile=args.profile)
            print(json.dumps({"candidate": label, **summary(gpx)}, default=float))
        except Exception as exc:
            print(json.dumps({"candidate": label, "error": repr(exc)}))


def cmd_inspect(args) -> None:
    gpx = G2sc.G2Project(args.project)
    print(json.dumps(summary(gpx), indent=2, default=float))


def main() -> None:
    G2sc.SetPrintLevel("warn")
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(required=True)
    p = sub.add_parser("screen")
    p.add_argument("--wo3", choices=["all", *WO3_CANDIDATES], default="all")
    p.add_argument("--carbonate", choices=["ortho", "rhombo"], default="ortho")
    p.add_argument("--angular", choices=["none", "zero", "shift"], default="zero")
    p.add_argument("--profile", action="store_true")
    p.add_argument(
        "--profile-start", choices=["default", "alt", "converged"], default="default"
    )
    p.set_defaults(func=cmd_screen)
    p = sub.add_parser("inspect")
    p.add_argument("project")
    p.set_defaults(func=cmd_inspect)
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
