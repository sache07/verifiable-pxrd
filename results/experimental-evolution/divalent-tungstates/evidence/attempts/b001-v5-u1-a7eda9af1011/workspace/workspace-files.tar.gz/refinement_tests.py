#!/usr/bin/env python3
"""Controlled GSAS-II branches used after the common-profile fit.

Each branch starts from a saved project, fixes the already-determined common
instrument profile, and reconverges background, scales, specimen displacement
and cells.  Optional accepted phase/sample terms in an input project are
recognized from their stored non-neutral values and replayed.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from gsas_workflow import CIF_ROOT, clear_all_refine_flags, neutralize_hap, summary


HERE = Path(__file__).resolve().parent
WATCH_SR3W2O9 = CIF_ROOT / "2" / "31" / "19" / "2311977.cif"


def clone_project(source: str | Path, output: str | Path) -> G2sc.G2Project:
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    return G2sc.G2Project(str(source), newgpx=str(output))


def set_bounds(gpx: G2sc.G2Project, variable: str, lo: float, hi: float) -> None:
    gpx.set_Controls("parmMin", lo, variable=variable)
    gpx.set_Controls("parmMax", hi, variable=variable)


def prepare_replay(gpx: G2sc.G2Project, preserve_nonneutral: bool = True) -> None:
    """Set a consistent replay model while leaving common W/X/SH-L fixed."""
    gpx.set_Frozen()
    clear_all_refine_flags(gpx)
    hist = gpx.histogram(0)
    hist.set_refinements({"Background": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})

    # Profile terms remain fixed at the converged common-profile solution.
    for key in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]:
        if key in hist.InstrumentParameters:
            hist.InstrumentParameters[key][2] = False

    # Replay accepted shared intensity corrections if they are stored in the
    # input model. Their neutral values are Polariz.=0.5 and roughness A=B=0.
    if preserve_nonneutral:
        if abs(float(hist.InstrumentParameters["Polariz."][1]) - 0.5) > 1e-8:
            hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        if (
            abs(float(hist.SampleParameters["SurfRoughA"][0])) > 1e-10
            or abs(float(hist.SampleParameters["SurfRoughB"][0])) > 1e-10
        ):
            hist.set_refinements(
                {"Sample Parameters": ["SurfRoughA", "SurfRoughB"]}
            )

    for phase in gpx.phases():
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        if not preserve_nonneutral:
            continue
        size = hap["Size"]
        if size[0] == "isotropic" and float(size[1][0]) < 9.999:
            size[2][0] = True
        elif size[0] == "uniaxial" and min(map(float, size[1][:2])) < 9.999:
            size[2][0] = size[2][1] = True
        strain = hap["Mustrain"]
        if strain[0] == "isotropic" and float(strain[1][0]) > 1e-8:
            strain[2][0] = True
        elif strain[0] == "uniaxial" and max(map(float, strain[1][:2])) > 1e-8:
            strain[2][0] = strain[2][1] = True
        po = hap["Pref.Ori."]
        if po[0] == "MD" and abs(float(po[1]) - 1.0) > 1e-8:
            po[2] = True

    set_bounds(gpx, ":0:Shift", -2000.0, 2000.0)
    set_bounds(gpx, ":0:Polariz.", 0.0, 1.0)
    set_bounds(gpx, ":0:SurfRoughA", 0.0, 1.0)
    set_bounds(gpx, ":0:SurfRoughB", 0.0, 5.0)
    for phase in gpx.phases():
        set_bounds(gpx, f"{phase.id}:0:Scale", 0.0, 1000.0)
        set_bounds(gpx, f"{phase.id}:0:Size;i", 0.01, 10.0)
        set_bounds(gpx, f"{phase.id}:0:Size;a", 0.01, 10.0)
        set_bounds(gpx, f"{phase.id}:0:Mustrain;i", 0.0, 10000.0)
        set_bounds(gpx, f"{phase.id}:0:Mustrain;a", 0.0, 10000.0)
        set_bounds(gpx, f"{phase.id}:0:MD", 0.2, 5.0)
    gpx.set_Controls("cycles", 6)


def covariance_values(gpx: G2sc.G2Project) -> dict[str, dict[str, float | None]]:
    cov = gpx.data.get("Covariance", {}).get("data", {})
    names = [str(v) for v in cov.get("varyList", [])]
    vals = list(cov.get("variables", []))
    sigs = list(cov.get("sig", []))
    out = {}
    for i, name in enumerate(names):
        out[name] = {
            "value": float(vals[i]) if i < len(vals) else None,
            "su": float(sigs[i]) if i < len(sigs) else None,
        }
    return out


def branch_summary(gpx: G2sc.G2Project) -> dict:
    hist = gpx.histogram(0)
    data = summary(gpx)
    try:
        data["mass_fractions"] = {
            key: {"value": val[0], "su": val[1]}
            for key, val in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        data["mass_fraction_error"] = repr(exc)
    data["hap"] = {}
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        data["hap"][phase.name] = {
            "Size": hap["Size"][:4],
            "Mustrain": hap["Mustrain"][:4],
            "Pref.Ori.": hap["Pref.Ori."][:4],
        }
    data["polarization"] = hist.InstrumentParameters["Polariz."][1]
    data["background"] = hist.data["Background"][0]
    data["covariance_parameters"] = covariance_values(gpx)
    return data


def run_and_report(gpx: G2sc.G2Project, label: str) -> None:
    gpx.refine()
    gpx.save()
    print(json.dumps({"label": label, **branch_summary(gpx)}, default=float))


def cmd_watch(args) -> None:
    gpx = clone_project(args.source, args.output)
    hist = gpx.histogram(0)
    watched = gpx.add_phase(
        str(WATCH_SR3W2O9),
        phasename="Sr3W2O9_watch",
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize_hap(watched, hist.name)
    prepare_replay(gpx)
    # First establish a nonnegative scale without moving a marginal cell.
    watched.clear_refinements({"Cell": True})
    gpx.refine()
    scale = float(watched.data["Histograms"][hist.name]["Scale"][0])
    if scale > 1e-6:
        watched.set_refinements({"Cell": True})
    run_and_report(gpx, "watch_Sr3W2O9")


def neutral_broadening(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]


def cmd_broadening(args) -> None:
    source = Path(args.source)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    probe = G2sc.G2Project(str(source))
    phase_names = [p.name for p in probe.phases()]
    for phase_index, phase_name in enumerate(phase_names):
        for kind, starts in (("size", args.size_starts), ("strain", args.strain_starts)):
            for start in starts:
                tag = str(start).replace(".", "p")
                output = outdir / f"{kind}_p{phase_index}_start{tag}.gpx"
                gpx = clone_project(source, output)
                prepare_replay(gpx, preserve_nonneutral=False)
                neutral_broadening(gpx)
                phase = gpx.phases()[phase_index]
                hap = phase.data["Histograms"][gpx.histogram(0).name]
                if kind == "size":
                    hap["Size"][1] = [float(start), 10.0, 1.0]
                    hap["Size"][2] = [True, False, False]
                else:
                    hap["Mustrain"][1] = [float(start), 0.0, 1.0]
                    hap["Mustrain"][2] = [True, False, False]
                try:
                    run_and_report(gpx, f"{kind}:{phase_name}:start={start}")
                except Exception as exc:
                    print(
                        json.dumps(
                            {
                                "label": f"{kind}:{phase_name}:start={start}",
                                "project": str(output),
                                "error": repr(exc),
                            }
                        )
                    )


def cmd_combined(args) -> None:
    gpx = clone_project(args.source, args.output)
    prepare_replay(gpx, preserve_nonneutral=False)
    neutral_broadening(gpx)
    hist = gpx.histogram(0)
    for spec in args.term:
        phase_index, kind, value = spec.split(":")
        phase = gpx.phases()[int(phase_index)]
        hap = phase.data["Histograms"][hist.name]
        if kind == "size":
            hap["Size"][1] = [float(value), 10.0, 1.0]
            hap["Size"][2] = [True, False, False]
        elif kind == "strain":
            hap["Mustrain"][1] = [float(value), 0.0, 1.0]
            hap["Mustrain"][2] = [True, False, False]
        else:
            raise ValueError(spec)
    run_and_report(gpx, "combined:" + ",".join(args.term))


def cmd_replay(args) -> None:
    """Reopen a stored model and perform a native full-range replay."""
    gpx = clone_project(args.source, args.output)
    prepare_replay(gpx)
    if args.full_range:
        hist = gpx.histogram(0)
        x = hist.getdata("x")
        hist.set_refinements({"Limits": [float(x.min()), float(x.max())]})
    run_and_report(gpx, "replay")


def set_background_order(hist, order: int) -> None:
    back = hist.data["Background"][0]
    coeffs = list(map(float, back[3:]))
    if order < len(coeffs):
        coeffs = coeffs[:order]
    else:
        coeffs.extend([0.0] * (order - len(coeffs)))
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": order,
                "coeffs": coeffs,
            }
        }
    )


def cmd_shared(args) -> None:
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    branches: list[tuple[str, dict]] = []
    for order in args.background_orders:
        branches.append((f"background_{order}", {"background": order}))
    branches.append(("polarization", {"polarization": True}))
    for a, b in args.roughness_start:
        branches.append((f"roughness_{a}_{b}", {"roughness": (a, b)}))
    for label, options in branches:
        output = outdir / f"{label.replace('.', 'p')}.gpx"
        gpx = clone_project(args.source, output)
        prepare_replay(gpx)
        hist = gpx.histogram(0)
        # Each comparison starts with the shared intensity terms neutral.
        hist.InstrumentParameters["Polariz."][1] = 0.5
        hist.InstrumentParameters["Polariz."][2] = False
        hist.SampleParameters["SurfRoughA"] = [0.0, False]
        hist.SampleParameters["SurfRoughB"] = [0.0, False]
        if "background" in options:
            set_background_order(hist, int(options["background"]))
        elif options.get("polarization"):
            hist.InstrumentParameters["Polariz."][2] = True
        elif "roughness" in options:
            a, b = options["roughness"]
            hist.SampleParameters["SurfRoughA"] = [float(a), True]
            hist.SampleParameters["SurfRoughB"] = [float(b), True]
        try:
            run_and_report(gpx, label)
        except Exception as exc:
            print(json.dumps({"label": label, "project": str(output), "error": repr(exc)}))


def cmd_correction(args) -> None:
    """Probe polarization alone or together with a roughness start."""
    gpx = clone_project(args.source, args.output)
    prepare_replay(gpx)
    hist = gpx.histogram(0)
    hist.InstrumentParameters["Polariz."] = [
        hist.InstrumentParameters["Polariz."][0],
        float(args.polarization),
        True,
    ]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    label = f"polarization_start={args.polarization}"
    if args.roughness is not None:
        a, b = args.roughness
        hist.SampleParameters["SurfRoughA"] = [float(a), True]
        hist.SampleParameters["SurfRoughB"] = [float(b), True]
        label += f":roughness_start={a},{b}"
    run_and_report(gpx, label)


def cmd_texture(args) -> None:
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    phase_axes = {
        0: ([0, 0, 1], [1, 1, 0]),
        1: ([0, 1, 0], [1, 0, 1]),
        2: ([0, 0, 1], [1, 1, 0]),
    }
    for phase_index, axes in phase_axes.items():
        for axis in axes:
            axis_tag = "".join(map(str, axis))
            for start in args.starts:
                output = outdir / f"texture_p{phase_index}_{axis_tag}_{str(start).replace('.', 'p')}.gpx"
                gpx = clone_project(args.source, output)
                prepare_replay(gpx)
                hist = gpx.histogram(0)
                # Probe exactly one texture term; preserve accepted broadening
                # and shared corrections already stored in the input project.
                for phase in gpx.phases():
                    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
                    po[0], po[1], po[2] = "MD", 1.0, False
                phase = gpx.phases()[phase_index]
                po = phase.data["Histograms"][hist.name]["Pref.Ori."]
                po[0], po[1], po[2], po[3] = "MD", float(start), True, list(axis)
                try:
                    run_and_report(
                        gpx,
                        f"texture:{phase.name}:axis={axis}:start={start}",
                    )
                except Exception as exc:
                    print(
                        json.dumps(
                            {
                                "label": f"texture:{phase.name}:axis={axis}:start={start}",
                                "project": str(output),
                                "error": repr(exc),
                            }
                        )
                    )


def cmd_combined_texture(args) -> None:
    gpx = clone_project(args.source, args.output)
    prepare_replay(gpx)
    hist = gpx.histogram(0)
    for phase in gpx.phases():
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0], po[1], po[2] = "MD", 1.0, False
    for spec in args.term:
        phase_text, axis_text, value_text = spec.split(":")
        phase = gpx.phases()[int(phase_text)]
        axis = [int(v) for v in axis_text.split(",")]
        if len(axis) != 3:
            raise ValueError(spec)
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", float(value_text), True, axis
    run_and_report(gpx, "combined_texture:" + ";".join(args.term))


def cmd_drop(args) -> None:
    """Replay a final model with one accepted term returned to neutral."""
    gpx = clone_project(args.source, args.output)
    prepare_replay(gpx)
    hist = gpx.histogram(0)
    if args.term == "polarization":
        hist.InstrumentParameters["Polariz."][1] = 0.5
        hist.InstrumentParameters["Polariz."][2] = False
    elif args.term == "wo3-strain":
        strain = gpx.phases()[1].data["Histograms"][hist.name]["Mustrain"]
        strain[1][0] = 0.0
        strain[2][0] = False
    elif args.term.startswith("texture-"):
        phase_index = int(args.term.split("-", 1)[1])
        po = gpx.phases()[phase_index].data["Histograms"][hist.name]["Pref.Ori."]
        po[1], po[2] = 1.0, False
    else:
        raise ValueError(args.term)
    run_and_report(gpx, "drop:" + args.term)


def main() -> None:
    G2sc.SetPrintLevel("warn")
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(required=True)

    p = sub.add_parser("watch")
    p.add_argument("source")
    p.add_argument("output")
    p.set_defaults(func=cmd_watch)

    p = sub.add_parser("broadening")
    p.add_argument("source")
    p.add_argument("outdir")
    p.add_argument("--size-starts", type=float, nargs="+", default=[10.0, 2.0])
    p.add_argument("--strain-starts", type=float, nargs="+", default=[0.0, 500.0])
    p.set_defaults(func=cmd_broadening)

    p = sub.add_parser("combined")
    p.add_argument("source")
    p.add_argument("output")
    p.add_argument(
        "--term",
        action="append",
        required=True,
        help="phase-index:size|strain:start-value",
    )
    p.set_defaults(func=cmd_combined)

    p = sub.add_parser("replay")
    p.add_argument("source")
    p.add_argument("output")
    p.add_argument("--full-range", action="store_true")
    p.set_defaults(func=cmd_replay)

    p = sub.add_parser("shared")
    p.add_argument("source")
    p.add_argument("outdir")
    p.add_argument("--background-orders", type=int, nargs="+", default=[6, 8, 10])
    p.add_argument(
        "--roughness-start",
        type=float,
        nargs=2,
        action="append",
        default=[[0.5, 0.1], [0.8, 0.03]],
    )
    p.set_defaults(func=cmd_shared)

    p = sub.add_parser("texture")
    p.add_argument("source")
    p.add_argument("outdir")
    p.add_argument("--starts", type=float, nargs="+", default=[0.85, 1.15])
    p.set_defaults(func=cmd_texture)

    p = sub.add_parser("correction")
    p.add_argument("source")
    p.add_argument("output")
    p.add_argument("--polarization", type=float, default=0.5)
    p.add_argument("--roughness", type=float, nargs=2)
    p.set_defaults(func=cmd_correction)

    p = sub.add_parser("combined-texture")
    p.add_argument("source")
    p.add_argument("output")
    p.add_argument(
        "--term",
        action="append",
        required=True,
        help="phase-index:h,k,l:start-value",
    )
    p.set_defaults(func=cmd_combined_texture)

    p = sub.add_parser("drop")
    p.add_argument("source")
    p.add_argument("output")
    p.add_argument(
        "term",
        choices=["polarization", "wo3-strain", "texture-0", "texture-1", "texture-2"],
    )
    p.set_defaults(func=cmd_drop)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
