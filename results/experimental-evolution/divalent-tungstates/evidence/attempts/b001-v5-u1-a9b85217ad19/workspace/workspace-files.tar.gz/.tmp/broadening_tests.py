from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
BASE = TMP / "mono_ctrl_zero.gpx"


def neutral_broadening(project) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        inst[key][2] = False
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 0.5]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 0.5]
        hap["Mustrain"][2] = [False, False, False]


def run(phase_index: int, kind: str) -> list[dict]:
    base = G2sc.G2Project(str(BASE))
    phase_name = base.phase(phase_index).name
    short = (phase_name.replace("_scheelite", "").replace("_monoclinic_P21c", "")
             .replace("_P21n", ""))
    tag = f"broad_{short}_{kind}"
    project = G2sc.G2Project(str(BASE), newgpx=str(TMP / f"{tag}.gpx"))
    project.set_Controls("cycles", 10)
    neutral_broadening(project)
    project.update_ids()
    phase = project.phase(phase_index)
    hist = project.histogram(0)
    hap = phase.data["Histograms"][hist.name]
    if kind == "size":
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
        var = f"{phase.id}:0:Size;i"
        project.set_Controls("parmMin", 0.001, variable=var)
        project.set_Controls("parmMax", 10.0, variable=var)
    elif kind == "strain":
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True
        var = f"{phase.id}:0:Mustrain;i"
        project.set_Controls("parmMin", 0.001, variable=var)
        project.set_Controls("parmMax", 100000.0, variable=var)
    else:
        raise ValueError(kind)
    project.save()

    rows = []
    for replay in range(1, 4):
        project.refine(printFile=str(TMP / f"{tag}.lst"))
        hist = project.histogram(0)
        hap = project.phase(phase_index).data["Histograms"][hist.name]
        row = {
            "tag": tag, "phase": phase_name, "kind": kind, "replay": replay,
            "rwp": hist.get_wR(), "gof": hist.get_wR() / hist.data["data"][0]["wRmin"],
            "size_um": hap["Size"][1][0],
            "microstrain": hap["Mustrain"][1][0],
            "zero": hist.data["Instrument Parameters"][0]["Zero"][1],
            "frozen": project.get_Frozen(),
        }
        rows.append(row)
        print("BROADENING_RESULT", json.dumps(row, sort_keys=True), flush=True)
        project.save()
    return rows


def main() -> None:
    rows = {}
    for i in range(3):
        for kind in ("size", "strain"):
            key = f"{i}_{kind}"
            rows[key] = run(i, kind)
    print("BROADENING_ALL", json.dumps(rows, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
