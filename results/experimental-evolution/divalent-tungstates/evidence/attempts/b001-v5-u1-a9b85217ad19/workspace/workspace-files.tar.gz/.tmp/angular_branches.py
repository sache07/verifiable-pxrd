from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"


def summarize(project: G2sc.G2Project, branch: str, replay: int) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    return {
        "branch": branch,
        "replay": replay,
        "rwp": hist.get_wR(),
        "gof": (hist.get_wR() / hist.data["data"][0]["wRmin"]),
        "zero": inst["Zero"][1],
        "shift_um": sample["Shift"][0],
        "profile": {k: inst[k][1] for k in ("U", "W", "X", "SH/L")},
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "scales": {p.name: p.HAPvalue("Scale") for p in project.phases()},
        "frozen": project.get_Frozen(),
        "vary": [str(v) for v in (project.get_VaryList() or [])],
    }


def run(branch: str) -> list[dict]:
    project = G2sc.G2Project(
        str(TMP / "profile_a.gpx"), newgpx=str(TMP / f"angular_{branch}.gpx")
    )
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    if branch == "zero":
        inst["Zero"][1:] = [-0.147, True]
        sample["Shift"] = [0.0, False]
        project.set_Controls("parmMin", -1.0, variable=":0:Zero")
        project.set_Controls("parmMax", 1.0, variable=":0:Zero")
    elif branch == "shift":
        inst["Zero"][1:] = [0.0, False]
        sample["Shift"] = [250.0, True]
        project.set_Controls("parmMin", -1000.0, variable=":0:Shift")
        project.set_Controls("parmMax", 1000.0, variable=":0:Shift")
    else:
        raise ValueError(branch)
    project.save()
    rows = []
    for replay in range(1, 4):
        project.refine(printFile=str(TMP / f"angular_{branch}.lst"))
        row = summarize(project, branch, replay)
        rows.append(row)
        print("ANGLE_RESULT", json.dumps(row, sort_keys=True))
        project.save()
    return rows


def main() -> None:
    rows = run("zero") + run("shift")
    print("ANGLE_ALL", json.dumps(rows, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
