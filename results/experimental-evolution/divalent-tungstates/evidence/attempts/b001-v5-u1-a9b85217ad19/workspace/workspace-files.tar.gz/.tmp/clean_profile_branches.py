from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
COD = Path("<RUN>/resources/b001-c05/cif")


def cod(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PHASES = [
    ("CaWO4_scheelite", cod("7219229"), [5.24586, 5.24586, 11.38341, 90, 90, 90], 49.0),
    ("WO3_Pnma", cod("2107312"), [7.53685, 7.29846, 7.70741, 90, 90, 90], 2.9),
    ("Ca3WO6_P21n", TMP / "Ca3WO6_prototype.cif", [5.53757, 5.78408, 8.02274, 90, 90.02, 90], 11.0),
]


def neutralize_hap(phase, histname: str) -> None:
    hap = phase.data["Histograms"][histname]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    size = hap["Size"]
    size[0] = "isotropic"
    size[1] = [1.0e6, 1.0e6, 0.5]
    size[2] = [False, False, False]
    size[4] = [1.0e6, 1.0e6, 1.0e6, 0.0, 0.0, 0.0]
    size[5] = [False for _ in size[5]]
    strain = hap["Mustrain"]
    strain[0] = "isotropic"
    strain[1] = [0.0, 0.0, 0.5]
    strain[2] = [False, False, False]
    strain[4] = [0.0 for _ in strain[4]]
    strain[5] = [False for _ in strain[5]]
    po = hap["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = False
    po[4] = 0
    po[5] = {}


def build_project(path: Path, starts: dict[str, float]) -> G2sc.G2Project:
    project = G2sc.G2Project(newgpx=str(path))
    hist = project.add_powder_histogram(
        str(TMP / "pattern.xye"), str(TMP / "lab_cuka.instprm"), fmthint="Topas"
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in hist.data["Sample Parameters"]:
            hist.data["Sample Parameters"][key] = [0.0, False]

    for name, source, cell, scale in PHASES:
        phase = project.add_phase(str(source), phasename=name, histograms=[hist], fmthint="CIF")
        phase.data["General"]["Cell"][1:7] = cell
        phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))
        phase.HAPvalue("Scale", scale)
        phase.set_HAP_refinements({"Scale": True})
        neutralize_hap(phase, hist.name)

    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1", "refine": True, "no. coeffs": 6,
            "coeffs": [1400.0, -670.0, 470.0, -420.0, 225.0, -110.0],
        }
    })
    inst = hist.data["Instrument Parameters"][0]
    values = {
        "Zero": -0.147, "Polariz.": 0.5, "U": starts["U"], "V": 0.0,
        "W": starts["W"], "X": starts["X"], "Y": 0.0, "Z": 0.0,
        "SH/L": starts["SH/L"], "I(L2)/I(L1)": 0.5,
    }
    for key, value in values.items():
        inst[key][1] = value
        inst[key][2] = False

    project.set_Controls("cycles", 6)
    project.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
    project.data["Controls"]["data"]["shift factor"] = 1.0
    for key, lo, hi in (
        ("U", 0.01, 1000.0), ("W", 0.01, 1000.0), ("X", 0.001, 50.0),
        ("SH/L", 0.0021, 0.5),
    ):
        project.set_Controls("parmMin", lo, variable=f":0:{key}")
        project.set_Controls("parmMax", hi, variable=f":0:{key}")
    project.save()
    return project


def run_refine(project: G2sc.G2Project, tag: str) -> dict:
    project.refine(printFile=str(TMP / f"{Path(project.filename).stem}.lst"))
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    out = {
        "tag": tag,
        "rwp": hist.get_wR(),
        "profile": {k: inst[k][1] for k in ("U", "V", "W", "X", "SH/L", "Zero")},
        "frozen": project.get_Frozen(),
        "scales": {p.name: p.HAPvalue("Scale") for p in project.phases()},
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "vary": [str(v) for v in (project.get_VaryList() or [])],
    }
    print("RESULT", json.dumps(out, sort_keys=True))
    return out


def branch(name: str, starts: dict[str, float]) -> list[dict]:
    project = build_project(TMP / f"profile_{name}.gpx", starts)
    hist = project.histogram(0)
    results = [run_refine(project, "scales_background")]
    for key in ("W", "X", "U", "SH/L"):
        hist.set_refinements({"Instrument Parameters": [key]})
        results.append(run_refine(project, f"add_{key}"))
        if project.get_Frozen():
            break
    if not project.get_Frozen():
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
        results.append(run_refine(project, "cells_and_full_replay"))
        project.save()
    return results


def main() -> None:
    starts = {
        "a": {"U": 50.0, "W": 50.0, "X": 5.0, "SH/L": 0.05},
        "b": {"U": 250.0, "W": 100.0, "X": 2.0, "SH/L": 0.08},
        "c": {"U": 100.0, "W": 250.0, "X": 8.0, "SH/L": 0.03},
    }
    all_results = {name: branch(name, vals) for name, vals in starts.items()}
    print("ALL_RESULTS", json.dumps(all_results, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
