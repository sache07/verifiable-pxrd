from __future__ import annotations

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat

from clean_profile_branches import neutralize_hap


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
COD = Path("<RUN>/resources/b001-c05/cif")


def cod(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


BASE_SOURCES = {
    "CaWO4_scheelite": cod("7219229"),
    "WO3_Pnma": cod("2107312"),
    "Ca3WO6_P21n": TMP / "Ca3WO6_prototype.cif",
}


def freeze_common(hist) -> None:
    inst = hist.data["Instrument Parameters"][0]
    for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in inst:
            inst[key][2] = False
    sample = hist.data["Sample Parameters"]
    for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in sample:
            sample[key][1] = False


def set_positive_scale_bounds(project) -> None:
    project.update_ids()
    for phase in project.phases():
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")


def summarize(project, tag: str, replay: int) -> dict:
    hist = project.histogram(0)
    return {
        "tag": tag,
        "replay": replay,
        "rwp": hist.get_wR(),
        "gof": hist.get_wR() / hist.data["data"][0]["wRmin"],
        "scales": {p.name: p.HAPvalue("Scale") for p in project.phases()},
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "frozen": project.get_Frozen(),
    }


def replay(project, tag: str, count: int = 3) -> list[dict]:
    rows = []
    listing = TMP / f"{tag}.lst"
    for n in range(1, count + 1):
        project.refine(printFile=str(listing))
        row = summarize(project, tag, n)
        rows.append(row)
        print("INVENTORY_RESULT", json.dumps(row, sort_keys=True), flush=True)
        project.save()
    return rows


def added_candidate(tag: str, source: Path, start_scale: float) -> list[dict]:
    project = G2sc.G2Project(
        str(TMP / "angular_zero.gpx"), newgpx=str(TMP / f"{tag}.gpx")
    )
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)
    freeze_common(hist)
    phase = project.add_phase(
        str(source), phasename=tag, histograms=[hist], fmthint="CIF"
    )
    neutralize_hap(phase, hist.name)
    phase.HAPvalue("Scale", start_scale)
    phase.set_HAP_refinements({"Scale": True})
    # Inventory additions are challenged scale-first at the reported cell.
    # A nearly absent phase cannot constrain a cell and releasing both at once
    # can create a spurious metric collapse.
    phase.set_refinements({"Cell": False})
    set_positive_scale_bounds(project)
    project.save()
    return replay(project, tag)


def replacement_project(tag: str, replacement_name: str, replacement_source: Path) -> G2sc.G2Project:
    base = G2sc.G2Project(str(TMP / "angular_zero.gpx"))
    base_hist = base.histogram(0)
    base_phase = {p.name: p for p in base.phases()}

    project = G2sc.G2Project(newgpx=str(TMP / f"{tag}.gpx"))
    hist = project.add_powder_histogram(
        str(TMP / "pattern.xye"), str(TMP / "lab_cuka.instprm"), fmthint="Topas"
    )
    hist.data["Limits"] = copy.deepcopy(base_hist.data["Limits"])
    hist.data["Background"] = copy.deepcopy(base_hist.data["Background"])
    hist.data["Background"][0][1] = True
    hist.data["Instrument Parameters"] = copy.deepcopy(
        base_hist.data["Instrument Parameters"]
    )
    hist.data["Sample Parameters"] = copy.deepcopy(base_hist.data["Sample Parameters"])
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    freeze_common(hist)

    for name in ("CaWO4_scheelite", "WO3_Pnma", "Ca3WO6_P21n"):
        if name == replacement_name:
            source = replacement_source
            phase_name = tag
        else:
            source = BASE_SOURCES[name]
            phase_name = name
        phase = project.add_phase(
            str(source), phasename=phase_name, histograms=[hist], fmthint="CIF"
        )
        neutralize_hap(phase, hist.name)
        phase.HAPvalue("Scale", base_phase[name].HAPvalue("Scale"))
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})
        if name != replacement_name:
            cell_dict = base_phase[name].get_cell()
            cell = [
                cell_dict["length_a"], cell_dict["length_b"], cell_dict["length_c"],
                cell_dict["angle_alpha"], cell_dict["angle_beta"], cell_dict["angle_gamma"],
            ]
            phase.data["General"]["Cell"][1:7] = cell
            phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))

    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
    set_positive_scale_bounds(project)
    project.save()
    return project


def replacement(tag: str, replacement_name: str, replacement_source: Path) -> list[dict]:
    return replay(replacement_project(tag, replacement_name, replacement_source), tag)


def main() -> None:
    all_rows = {}
    # Two physically interior starts are used for weak additions so a failed
    # lower-bound branch is not treated as phase evidence.
    for start in (0.1, 2.0):
        tag = f"watch_CaO_s{str(start).replace('.', 'p')}"
        all_rows[tag] = added_candidate(tag, cod("1563196"), start)
    for start in (0.05, 1.0):
        tag = f"watch_bronze_s{str(start).replace('.', 'p')}"
        all_rows[tag] = added_candidate(tag, cod("4030741"), start)

    all_rows["alt_WO3_P21n"] = replacement(
        "alt_WO3_P21n", "WO3_Pnma", cod("1528915")
    )
    all_rows["alt_WO3_Pminus1"] = replacement(
        "alt_WO3_Pminus1", "WO3_Pnma", cod("2106293")
    )
    all_rows["alt_CaWO4_fergusonite"] = replacement(
        "alt_CaWO4_fergusonite", "CaWO4_scheelite", cod("1546035")
    )
    print("INVENTORY_ALL", json.dumps(all_rows, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
