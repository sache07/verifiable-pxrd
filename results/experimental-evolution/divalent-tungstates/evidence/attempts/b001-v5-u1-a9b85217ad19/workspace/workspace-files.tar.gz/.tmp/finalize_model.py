from __future__ import annotations

import csv
import json
import re
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
FINAL = ROOT / "final.gpx"
LISTING = ROOT / "final.lst"


def refine_reopen() -> G2sc.G2Project:
    project = G2sc.G2Project(
        str(TMP / "posttexture_base.gpx"), newgpx=str(FINAL)
    )
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("X"), dtype=float)
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    project.set_Controls("cycles", 10)
    project.save()
    project.refine(printFile=str(LISTING))
    project.save()

    # Native save/reopen replay of the project that will be submitted.
    project = G2sc.G2Project(str(FINAL))
    project.set_Controls("cycles", 10)
    project.refine(printFile=str(LISTING))
    project.save()
    return G2sc.G2Project(str(FINAL))


def export_outputs(project: G2sc.G2Project) -> None:
    cif_paths = [
        ROOT / "phase_CaWO4.cif",
        ROOT / "phase_WO3.cif",
        ROOT / "phase_Ca3WO6.cif",
    ]
    for phase, output in zip(project.phases(), cif_paths, strict=True):
        phase.export_CIF(str(output))

    hist = project.histogram(0)
    arrays = [
        np.ma.filled(hist.getdata(name), np.nan)
        for name in ("X", "Yobs", "Ycalc", "Residual")
    ]
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg", "intensity_observed_counts",
            "intensity_calculated_counts", "difference_observed_minus_calculated_counts",
        ])
        writer.writerows(zip(*arrays, strict=True))


def weight_fractions() -> list[float]:
    text = LISTING.read_text()
    values = [float(x) for x in re.findall(
        r"Weight fraction\s+:\s+([0-9]+(?:\.[0-9]+)?)", text
    )]
    if len(values) < 3:
        raise RuntimeError("Could not locate all final GSAS-II weight fractions")
    return values[-3:]


def covariance_summary(project: G2sc.G2Project) -> dict:
    cov = project.data["Covariance"]["data"]
    matrix = np.asarray(cov.get("covMatrix"), dtype=float)
    names = [str(x) for x in cov.get("varyList", [])]
    if matrix.size == 0:
        return {"max_abs_correlation": None, "pair": None}
    sigma = np.sqrt(np.clip(np.diag(matrix), 0.0, None))
    denom = np.outer(sigma, sigma)
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
    np.fill_diagonal(corr, 0.0)
    idx = np.unravel_index(np.nanargmax(np.abs(corr)), corr.shape)
    return {
        "max_abs_correlation": float(abs(corr[idx])),
        "pair": [names[idx[0]], names[idx[1]]],
    }


def main() -> None:
    project = refine_reopen()
    export_outputs(project)
    hist = project.histogram(0)
    stats = hist.data["data"][0]
    weights = weight_fractions()
    total = sum(weights)
    inst = hist.data["Instrument Parameters"][0]
    summary = {
        "rwp_percent": hist.get_wR(),
        "rp_percent": stats["R"],
        "rb_percent": stats["Rb"],
        "wrmin_percent": stats["wRmin"],
        "gof": hist.get_wR() / stats["wRmin"],
        "n_observations": stats["Nobs"],
        "durbin_watson": stats["Durbin-Watson"],
        "weights": {
            p.name: w / total for p, w in zip(project.phases(), weights, strict=True)
        },
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "scales": {p.name: p.HAPvalue("Scale") for p in project.phases()},
        "profile": {k: inst[k][1] for k in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
        "zero_deg": inst["Zero"][1],
        "polarization": inst["Polariz."][1],
        "frozen": project.get_Frozen(),
        "active_variables": [str(x) for x in (project.get_VaryList() or [])],
        "covariance": covariance_summary(project),
    }
    print("FINAL_SUMMARY", json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
