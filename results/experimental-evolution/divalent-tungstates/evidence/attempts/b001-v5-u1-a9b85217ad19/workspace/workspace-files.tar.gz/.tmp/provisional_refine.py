from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np
import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
COD = Path("<RUN>/resources/b001-c05/cif")


def cod(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def phase_summary(project: G2sc.G2Project) -> list[dict]:
    hist = project.histogram(0)
    rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        rows.append(
            {
                "name": phase.name,
                "scale": hap["Scale"][0],
                "cell": phase.get_cell(),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    return rows


def print_summary(project: G2sc.G2Project, tag: str) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    print("SUMMARY", tag)
    print("wR", hist.get_wR(), "residuals", hist.data["data"][0])
    print("instrument", {k: v for k, v in inst.items()})
    print("sample", sample)
    print("phases", json.dumps(phase_summary(project), indent=2, default=str))
    print("vary", [str(v) for v in (project.get_VaryList() or [])])
    print("frozen", project.get_Frozen())


def make_project(outfile: Path, phase_specs: list[tuple[str, Path]]) -> G2sc.G2Project:
    project = G2sc.G2Project(newgpx=str(outfile))
    hist = project.add_powder_histogram(
        str(TMP / "pattern.xye"),
        str(TMP / "lab_cuka.instprm"),
        fmthint="Topas",
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    for name, path in phase_specs:
        project.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
    project.data["Controls"]["data"]["shift factor"] = 1.0

    # Neutral defaults and physically moderate starting profile.
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 100.0, "V": 0.0, "W": 100.0, "X": 1.0, "Y": 0.0,
                       "Z": 0.0, "SH/L": 0.02, "Zero": 0.0, "Polariz.": 0.5}.items():
        inst[key][1] = value
        inst[key][2] = False
    sample = hist.data["Sample Parameters"]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in sample:
            sample[key][0] = 0.0
            sample[key][1] = False

    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 6,
            "coeffs": [1500.0, -800.0, 400.0, -200.0, 100.0, -50.0],
        }
    })
    for i, phase in enumerate(project.phases()):
        phase.HAPvalue("Scale", [1.0, 0.15, 0.10][i])
        phase.set_HAP_refinements({"Scale": True})

    project.save()
    return project


def main() -> None:
    phase_specs = [
        ("CaWO4_scheelite", cod("7219229")),
        ("WO3_Pnma", cod("2107312")),
        ("Ca3WO6_P21n", TMP / "Ca3WO6_prototype.cif"),
    ]
    project = make_project(TMP / "provisional_3phase.gpx", phase_specs)
    print_summary(project, "initial")
    project.refine(printFile=str(TMP / "provisional_3phase.lst"))
    print_summary(project, "scales_background")

    hist = project.histogram(0)
    # Provisional common profile from an interior start, before moving cells.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    project.refine(printFile=str(TMP / "provisional_3phase.lst"))
    print_summary(project, "plus_UWX_SHL")

    # Provisional angular correction, then cells only once positive scales exist.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine(printFile=str(TMP / "provisional_3phase.lst"))
    print_summary(project, "plus_zero")
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine(printFile=str(TMP / "provisional_3phase.lst"))
    print_summary(project, "plus_cells")
    project.save()


if __name__ == "__main__":
    main()
