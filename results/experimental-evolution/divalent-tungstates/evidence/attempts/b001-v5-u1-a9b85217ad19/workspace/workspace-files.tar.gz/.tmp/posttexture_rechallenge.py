from __future__ import annotations

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat

from clean_profile_branches import neutralize_hap


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
COD = Path("<RUN>/resources/b001-c05/cif")
BASE = TMP / "posttexture_base.gpx"


def cod(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


SOURCES = {
    "CaWO4_scheelite": cod("7219229"),
    "WO3_monoclinic_P21c": cod("2311041"),
    "Ca3WO6_P21n": TMP / "Ca3WO6_prototype.cif",
}


def cell_list(phase) -> list[float]:
    c = phase.get_cell()
    return [c["length_a"], c["length_b"], c["length_c"],
            c["angle_alpha"], c["angle_beta"], c["angle_gamma"]]


def common_controls(project) -> None:
    project.set_Controls("cycles", 10)
    project.update_ids()
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        inst[key][2] = False
    inst["Zero"][2] = True
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    project.set_Controls("parmMin", -1.0, variable=":0:Zero")
    project.set_Controls("parmMax", 1.0, variable=":0:Zero")
    project.set_Controls("parmMin", 0.001, variable=":0:Polariz.")
    project.set_Controls("parmMax", 0.999, variable=":0:Polariz.")
    for phase in project.phases():
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
    if project.phases():
        project.set_Controls("parmMin", 0.001, variable=f"{project.phase(0).id}:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{project.phase(0).id}:0:Size;i")
        project.set_Controls("parmMin", 0.2, variable=f"{project.phase(0).id}:0:MD")
        project.set_Controls("parmMax", 5.0, variable=f"{project.phase(0).id}:0:MD")


def summarize(project, tag: str, replay: int) -> dict:
    hist = project.histogram(0)
    return {
        "tag": tag, "replay": replay, "rwp": hist.get_wR(),
        "gof": hist.get_wR() / hist.data["data"][0]["wRmin"],
        "frozen": project.get_Frozen(),
        "scales": {p.name: p.HAPvalue("Scale") for p in project.phases()},
        "cells": {p.name: p.get_cell() for p in project.phases()},
    }


def replay(project, tag: str) -> list[dict]:
    rows = []
    for i in (1, 2):
        project.refine(printFile=str(TMP / f"{tag}.lst"))
        row = summarize(project, tag, i)
        rows.append(row)
        print("POSTTEXTURE_INVENTORY", json.dumps(row, sort_keys=True), flush=True)
        project.save()
    return rows


def add_candidate(tag: str, source: Path, start_scale: float) -> list[dict]:
    project = G2sc.G2Project(str(BASE), newgpx=str(TMP / f"{tag}.gpx"))
    hist = project.histogram(0)
    phase = project.add_phase(str(source), phasename=tag, histograms=[hist], fmthint="CIF")
    neutralize_hap(phase, hist.name)
    phase.HAPvalue("Scale", start_scale)
    phase.set_HAP_refinements({"Scale": True})
    phase.set_refinements({"Cell": False})
    common_controls(project)
    project.save()
    return replay(project, tag)


def replacement(tag: str, old_name: str, source: Path,
                start_cell: list[float] | None = None) -> list[dict]:
    base = G2sc.G2Project(str(BASE))
    bh = base.histogram(0)
    bp = {p.name: p for p in base.phases()}
    project = G2sc.G2Project(newgpx=str(TMP / f"{tag}.gpx"))
    hist = project.add_powder_histogram(
        str(TMP / "pattern.xye"), str(TMP / "lab_cuka.instprm"), fmthint="Topas"
    )
    for key in ("Limits", "Background", "Instrument Parameters", "Sample Parameters"):
        hist.data[key] = copy.deepcopy(bh.data[key])
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]

    for name in ("CaWO4_scheelite", "WO3_monoclinic_P21c", "Ca3WO6_P21n"):
        replacing = name == old_name
        phase = project.add_phase(
            str(source if replacing else SOURCES[name]),
            phasename=tag if replacing else name, histograms=[hist], fmthint="CIF"
        )
        phase.HAPvalue("Scale", bp[name].HAPvalue("Scale"))
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})
        cell = start_cell if replacing and start_cell else cell_list(bp[name])
        phase.data["General"]["Cell"][1:7] = cell
        phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))
        if replacing:
            neutralize_hap(phase, hist.name)
        else:
            old_hap = bp[name].data["Histograms"][bh.name]
            new_hap = phase.data["Histograms"][hist.name]
            for key in ("Size", "Mustrain", "Pref.Ori.", "HStrain", "Extinction", "Babinet"):
                new_hap[key] = copy.deepcopy(old_hap[key])

    common_controls(project)
    project.save()
    return replay(project, tag)


def main() -> None:
    rows = {}
    rows["post_watch_CaO_s0p1"] = add_candidate("post_watch_CaO_s0p1", cod("1563196"), 0.1)
    rows["post_watch_CaO_s2"] = add_candidate("post_watch_CaO_s2", cod("1563196"), 2.0)
    rows["post_watch_bronze"] = add_candidate("post_watch_bronze", cod("4030741"), 0.1)
    rows["post_alt_Ca3_Uprototype"] = replacement(
        "post_alt_Ca3_Uprototype", "Ca3WO6_P21n", TMP / "Ca3WO6_Uprototype.cif"
    )
    rows["post_alt_WO3_Pminus1"] = replacement(
        "post_alt_WO3_Pminus1", "WO3_monoclinic_P21c", cod("2106293"),
        [7.309, 7.522, 7.678, 88.81, 90.92, 90.93],
    )
    print("POSTTEXTURE_ALL", json.dumps(rows, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
