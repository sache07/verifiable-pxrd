from __future__ import annotations

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat

from clean_profile_branches import neutralize_hap


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
COD = Path("<RUN>/resources/b001-c05/cif")
BASE = TMP / "mono_ctrl_zero.gpx"


def cod(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


SOURCES = {
    "CaWO4_scheelite": cod("7219229"),
    "WO3_monoclinic_P21c": cod("2311041"),
    "Ca3WO6_P21n": TMP / "Ca3WO6_prototype.cif",
}


def cell_list(phase) -> list[float]:
    c = phase.get_cell()
    return [c["length_a"], c["length_b"], c["length_c"],
            c["angle_alpha"], c["angle_beta"], c["angle_gamma"]]


def fix_profile(hist) -> None:
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        inst[key][2] = False
    # Retain the selected zero-only branch and allow the provisional zero to
    # reconverge after a phase/source change.
    inst["Zero"][2] = True
    sample = hist.data["Sample Parameters"]
    sample["Shift"] = [0.0, False]
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        if key in sample:
            sample[key] = [0.0, False]


def set_scale_bounds(project) -> None:
    project.update_ids()
    for phase in project.phases():
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")


def result(project, tag: str, replay: int) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    return {
        "tag": tag, "replay": replay, "rwp": hist.get_wR(),
        "gof": hist.get_wR() / hist.data["data"][0]["wRmin"],
        "zero": inst["Zero"][1], "frozen": project.get_Frozen(),
        "scales": {p.name: p.HAPvalue("Scale") for p in project.phases()},
        "cells": {p.name: p.get_cell() for p in project.phases()},
    }


def replay(project, tag: str, n: int = 3) -> list[dict]:
    rows = []
    for i in range(1, n + 1):
        project.refine(printFile=str(TMP / f"{tag}.lst"))
        row = result(project, tag, i)
        rows.append(row)
        print("MONO_INVENTORY", json.dumps(row, sort_keys=True), flush=True)
        project.save()
    return rows


def add_candidate(tag: str, source: Path, scale: float) -> list[dict]:
    project = G2sc.G2Project(str(BASE), newgpx=str(TMP / f"{tag}.gpx"))
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)
    fix_profile(hist)
    phase = project.add_phase(str(source), phasename=tag, histograms=[hist], fmthint="CIF")
    neutralize_hap(phase, hist.name)
    phase.HAPvalue("Scale", scale)
    phase.set_HAP_refinements({"Scale": True})
    phase.set_refinements({"Cell": False})
    set_scale_bounds(project)
    project.save()
    return replay(project, tag)


def replacement(tag: str, old_name: str, new_source: Path,
                start_cell: list[float] | None = None) -> list[dict]:
    base = G2sc.G2Project(str(BASE))
    bh = base.histogram(0)
    bp = {p.name: p for p in base.phases()}
    project = G2sc.G2Project(newgpx=str(TMP / f"{tag}.gpx"))
    hist = project.add_powder_histogram(
        str(TMP / "pattern.xye"), str(TMP / "lab_cuka.instprm"), fmthint="Topas"
    )
    hist.data["Limits"] = copy.deepcopy(bh.data["Limits"])
    hist.data["Background"] = copy.deepcopy(bh.data["Background"])
    hist.data["Background"][0][1] = True
    hist.data["Instrument Parameters"] = copy.deepcopy(bh.data["Instrument Parameters"])
    hist.data["Sample Parameters"] = copy.deepcopy(bh.data["Sample Parameters"])
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    fix_profile(hist)

    for name in ("CaWO4_scheelite", "WO3_monoclinic_P21c", "Ca3WO6_P21n"):
        replacing = name == old_name
        source = new_source if replacing else SOURCES[name]
        phase_name = tag if replacing else name
        phase = project.add_phase(str(source), phasename=phase_name,
                                  histograms=[hist], fmthint="CIF")
        neutralize_hap(phase, hist.name)
        phase.HAPvalue("Scale", bp[name].HAPvalue("Scale"))
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})
        cell = start_cell if replacing and start_cell else cell_list(bp[name])
        phase.data["General"]["Cell"][1:7] = cell
        phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))

    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
    project.set_Controls("parmMin", -1.0, variable=":0:Zero")
    project.set_Controls("parmMax", 1.0, variable=":0:Zero")
    set_scale_bounds(project)
    project.save()
    return replay(project, tag)


def main() -> None:
    rows = {}
    rows["mono_watch_CaO"] = add_candidate("mono_watch_CaO", cod("1563196"), 1.0)
    rows["mono_watch_bronze"] = add_candidate("mono_watch_bronze", cod("4030741"), 0.1)
    rows["mono_alt_WO3_Pnma"] = replacement(
        "mono_alt_WO3_Pnma", "WO3_monoclinic_P21c", cod("2107312"),
        [7.5327, 7.2876, 7.6817, 90, 90, 90],
    )
    rows["mono_alt_WO3_Pminus1"] = replacement(
        "mono_alt_WO3_Pminus1", "WO3_monoclinic_P21c", cod("2106293")
    )
    rows["mono_alt_Ca3_Uprototype"] = replacement(
        "mono_alt_Ca3_Uprototype", "Ca3WO6_P21n", TMP / "Ca3WO6_Uprototype.cif"
    )
    print("MONO_INVENTORY_ALL", json.dumps(rows, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
