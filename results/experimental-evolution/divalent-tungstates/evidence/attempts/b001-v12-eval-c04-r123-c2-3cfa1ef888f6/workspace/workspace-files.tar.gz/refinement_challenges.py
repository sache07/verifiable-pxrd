#!/usr/bin/env python3
"""Run reversible GSAS-II challenges from a saved common checkpoint.

Every output is a fresh copy of the input GPX, so a failed or bounded trial
cannot leak values back into the accepted refinement.
"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from gsas_trials import cov_summary, neutralize_phase_profile


def clone_project(source: str, output: str) -> G2sc.G2Project:
    source_path = Path(source).resolve()
    output_path = Path(output).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source_path, output_path)
    return G2sc.G2Project(str(output_path))


def replay(project: G2sc.G2Project, count: int = 2) -> None:
    project.set_Controls("cycles", 12)
    for _ in range(count):
        project.do_refinements([{}])
        project.save()


def compact_state(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    return {
        "project": project.filename,
        "residuals": hist.residuals,
        "covariance": cov_summary(project),
        "frozen": project.get_Frozen(),
        "mass_fractions": hist.ComputeMassFracs(),
        "scales": {
            phase.name: phase.data["Histograms"][hist.name]["Scale"]
            for phase in project.phases()
        },
    }


def add_phase(args: argparse.Namespace) -> None:
    project = clone_project(args.source, args.output)
    hist = project.histogram(0)
    phase = project.add_phase(
        str(Path(args.cif).resolve()),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize_phase_profile(phase, hist)
    phase.HAPvalue("Scale", args.scale)
    phase.set_HAP_refinements({"Scale": True})
    phase.set_refinements({"Cell": False})
    phase_id = len(project.phases()) - 1
    project.set_Controls("parmMin", 0.0, f"{phase_id}:0:Scale")
    project.save()
    replay(project, args.replays)
    print(json.dumps(compact_state(project), indent=2, default=float))


def phase_cell(args: argparse.Namespace) -> None:
    project = clone_project(args.source, args.output)
    project.phase(args.phase).set_refinements({"Cell": True})
    project.save()
    replay(project, args.replays)
    print(json.dumps(compact_state(project), indent=2, default=float))


def phase_broadening(args: argparse.Namespace) -> None:
    project = clone_project(args.source, args.output)
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]

    use_size = args.mode in {"size", "both"}
    use_strain = args.mode in {"strain", "both"}
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = args.size_start if use_size else 10.0
    hap["Size"][2][0] = use_size
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = args.strain_start if use_strain else 0.0
    hap["Mustrain"][2][0] = use_strain

    phase_id = phase.data["pId"]
    project.set_Controls("parmMin", 0.01, f"{phase_id}:0:Size;i")
    project.set_Controls("parmMax", 10.0, f"{phase_id}:0:Size;i")
    project.set_Controls("parmMin", 0.0, f"{phase_id}:0:Mustrain;i")
    project.set_Controls("parmMax", args.strain_max, f"{phase_id}:0:Mustrain;i")
    project.save()
    replay(project, args.replays)
    state = compact_state(project)
    state["tested_profile"] = {
        "phase": phase.name,
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
    }
    print(json.dumps(state, indent=2, default=float))


def replay_project(args: argparse.Namespace) -> None:
    project = clone_project(args.source, args.output)
    replay(project, args.replays)
    print(json.dumps(compact_state(project), indent=2, default=float))


def background_order(args: argparse.Namespace) -> None:
    project = clone_project(args.source, args.output)
    hist = project.histogram(0)
    current = hist.data["Background"][0]
    coeffs = list(current[3:])[: args.order]
    coeffs.extend([0.0] * (args.order - len(coeffs)))
    hist.data["Background"][0] = [current[0], True, args.order, *coeffs]
    project.save()
    replay(project, args.replays)
    state = compact_state(project)
    state["background"] = hist.data["Background"][0]
    print(json.dumps(state, indent=2, default=float))


def polarization(args: argparse.Namespace) -> None:
    project = clone_project(args.source, args.output)
    hist = project.histogram(0)
    polar = hist.data["Instrument Parameters"][0]["Polariz."]
    polar[1] = args.start
    polar[2] = True
    project.set_Controls("parmMin", 0.0, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    project.save()
    replay(project, args.replays)
    state = compact_state(project)
    state["polarization"] = polar
    print(json.dumps(state, indent=2, default=float))


def roughness(args: argparse.Namespace) -> None:
    project = clone_project(args.source, args.output)
    hist = project.histogram(0)
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"][:] = [0.0, False]
    sample["SurfRoughB"][:] = [0.0, False]
    if args.mode == "B":
        sample["SurfRoughB"][:] = [args.start_b, True]
    elif args.mode == "both":
        sample["SurfRoughA"][:] = [args.start_a, True]
        sample["SurfRoughB"][:] = [args.start_b, True]
    project.set_Controls("parmMin", 0.0, ":0:SurfRoughA")
    project.set_Controls("parmMax", 1.0, ":0:SurfRoughA")
    project.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
    project.set_Controls("parmMax", 2.0, ":0:SurfRoughB")
    project.save()
    replay(project, args.replays)
    state = compact_state(project)
    state["roughness"] = {
        "A": sample["SurfRoughA"],
        "B": sample["SurfRoughB"],
    }
    print(json.dumps(state, indent=2, default=float))


def texture(args: argparse.Namespace) -> None:
    project = clone_project(args.source, args.output)
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    axis = [int(value) for value in args.axis.split(",")]
    if len(axis) != 3 or axis == [0, 0, 0]:
        raise ValueError("axis must be three comma-separated integers")
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = axis
    phase_id = phase.data["pId"]
    project.set_Controls("parmMin", 0.2, f"{phase_id}:0:MD")
    project.set_Controls("parmMax", 5.0, f"{phase_id}:0:MD")
    project.save()
    replay(project, args.replays)
    state = compact_state(project)
    state["texture"] = {"phase": phase.name, "Pref.Ori.": hap["Pref.Ori."]}
    print(json.dumps(state, indent=2, default=float))


def angular_correction(args: argparse.Namespace) -> None:
    project = clone_project(args.source, args.output)
    hist = project.histogram(0)
    instrument = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    if args.mode == "shift":
        instrument["Zero"][1:] = [0.0, False]
        sample["Shift"][:] = [args.shift_start, True]
        project.set_Controls("parmMin", -2000.0, ":0:Shift")
        project.set_Controls("parmMax", 2000.0, ":0:Shift")
    else:
        sample["Shift"][:] = [0.0, False]
        instrument["Zero"][2] = True
    project.save()
    replay(project, args.replays)
    state = compact_state(project)
    state["angular_correction"] = {
        "zero": instrument["Zero"],
        "shift": sample["Shift"],
    }
    print(json.dumps(state, indent=2, default=float))


def atom_coordinates(args: argparse.Namespace) -> None:
    project = clone_project(args.source, args.output)
    phase = project.phase(args.phase)
    phase.set_refinements({"Atoms": {"all": "X"}})
    project.save()
    replay(project, args.replays)
    state = compact_state(project)
    state["coordinate_phase"] = phase.name
    state["coordinate_variables"] = [
        str(item)
        for item in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])
        if str(item).startswith(f"{phase.data['pId']}::dA")
    ]
    print(json.dumps(state, indent=2, default=float))


def phase_off(args: argparse.Namespace) -> None:
    project = clone_project(args.source, args.output)
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][:] = [1.0e-12, False]
    neutralize_phase_profile(phase, hist)
    phase.set_refinements({"Cell": False})
    for atom in phase.atoms():
        atom.refinement_flags = " "
    project.save()
    replay(project, args.replays)
    state = compact_state(project)
    state["disabled_phase"] = phase.name
    print(json.dumps(state, indent=2, default=float))


def print_compact(args: argparse.Namespace) -> None:
    project = G2sc.G2Project(args.project)
    print(json.dumps(compact_state(project), indent=2, default=float))


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser()
    commands = root.add_subparsers(dest="command", required=True)

    add = commands.add_parser("add-phase")
    add.add_argument("--source", required=True)
    add.add_argument("--output", required=True)
    add.add_argument("--cif", required=True)
    add.add_argument("--name", required=True)
    add.add_argument("--scale", type=float, default=0.05)
    add.add_argument("--replays", type=int, default=2)
    add.set_defaults(func=add_phase)

    cell = commands.add_parser("phase-cell")
    cell.add_argument("--source", required=True)
    cell.add_argument("--output", required=True)
    cell.add_argument("--phase", type=int, required=True)
    cell.add_argument("--replays", type=int, default=2)
    cell.set_defaults(func=phase_cell)

    broad = commands.add_parser("phase-broadening")
    broad.add_argument("--source", required=True)
    broad.add_argument("--output", required=True)
    broad.add_argument("--phase", type=int, required=True)
    broad.add_argument("--mode", choices=["neutral", "size", "strain", "both"], required=True)
    broad.add_argument("--size-start", type=float, default=1.0)
    broad.add_argument("--strain-start", type=float, default=1000.0)
    broad.add_argument("--strain-max", type=float, default=10000.0)
    broad.add_argument("--replays", type=int, default=2)
    broad.set_defaults(func=phase_broadening)

    again = commands.add_parser("replay")
    again.add_argument("--source", required=True)
    again.add_argument("--output", required=True)
    again.add_argument("--replays", type=int, default=2)
    again.set_defaults(func=replay_project)

    back = commands.add_parser("background")
    back.add_argument("--source", required=True)
    back.add_argument("--output", required=True)
    back.add_argument("--order", type=int, required=True)
    back.add_argument("--replays", type=int, default=2)
    back.set_defaults(func=background_order)

    polar = commands.add_parser("polarization")
    polar.add_argument("--source", required=True)
    polar.add_argument("--output", required=True)
    polar.add_argument("--start", type=float, default=0.7)
    polar.add_argument("--replays", type=int, default=2)
    polar.set_defaults(func=polarization)

    rough = commands.add_parser("roughness")
    rough.add_argument("--source", required=True)
    rough.add_argument("--output", required=True)
    rough.add_argument("--mode", choices=["neutral", "B", "both"], required=True)
    rough.add_argument("--start-a", type=float, default=0.1)
    rough.add_argument("--start-b", type=float, default=0.1)
    rough.add_argument("--replays", type=int, default=2)
    rough.set_defaults(func=roughness)

    tex = commands.add_parser("texture")
    tex.add_argument("--source", required=True)
    tex.add_argument("--output", required=True)
    tex.add_argument("--phase", type=int, required=True)
    tex.add_argument("--axis", required=True)
    tex.add_argument("--replays", type=int, default=2)
    tex.set_defaults(func=texture)

    angular = commands.add_parser("angular")
    angular.add_argument("--source", required=True)
    angular.add_argument("--output", required=True)
    angular.add_argument("--mode", choices=["zero", "shift"], required=True)
    angular.add_argument("--shift-start", type=float, default=840.0)
    angular.add_argument("--replays", type=int, default=2)
    angular.set_defaults(func=angular_correction)

    coords = commands.add_parser("coordinates")
    coords.add_argument("--source", required=True)
    coords.add_argument("--output", required=True)
    coords.add_argument("--phase", type=int, required=True)
    coords.add_argument("--replays", type=int, default=2)
    coords.set_defaults(func=atom_coordinates)

    off = commands.add_parser("phase-off")
    off.add_argument("--source", required=True)
    off.add_argument("--output", required=True)
    off.add_argument("--phase", type=int, required=True)
    off.add_argument("--replays", type=int, default=3)
    off.set_defaults(func=phase_off)

    compact = commands.add_parser("compact")
    compact.add_argument("project")
    compact.set_defaults(func=print_compact)
    return root


def main() -> None:
    args = parser().parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
