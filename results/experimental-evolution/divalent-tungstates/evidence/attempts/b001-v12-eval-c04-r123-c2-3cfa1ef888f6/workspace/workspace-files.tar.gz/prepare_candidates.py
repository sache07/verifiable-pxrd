#!/usr/bin/env python3
"""Build explicit Mn-W-O analogue CIFs used in source challenges.

The substitutions preserve the parent topology and fractional coordinates.
The isotropic lattice factors come only from a bounded whole-pattern position
screen and are starting values; they are not treated as refined results.
"""

from __future__ import annotations

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(
    "<RUN>/"
    "resources/b001-c04/cif"
)
OUT = Path("work/candidates")


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


MODELS = {
    "mnwo4_from_mg_9013902.cif": ("9013902", {"Mg": "Mn"}, 1.022),
    "mnwo4_from_zn_1520641.cif": ("1520641", {"Zn": "Mn"}, 1.015),
    "mnwo4_from_fe_9008124.cif": ("9008124", {"Fe": "Mn"}, 1.007),
    "mnwo4_from_fe_1567215.cif": ("1567215", {"Fe": "Mn"}, 1.000),
    "mnwo4_from_fe_1568792.cif": ("1568792", {"Fe": "Mn"}, 1.003),
    "mnwo4_from_mnmoo4_1527061.cif": ("1527061", {"Mo": "W"}, 1.058),
    "mnwo4_scheelite_from_ca_7219229.cif": ("7219229", {"Ca": "Mn"}, 0.962),
}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    for filename, (cod_id, substitutions, lattice_factor) in MODELS.items():
        structure = Structure.from_file(cod_path(cod_id))
        structure.replace_species(substitutions)
        structure.scale_lattice(structure.volume * lattice_factor**3)
        CifWriter(structure, symprec=0.01, refine_struct=False).write_file(
            OUT / filename
        )
        print(filename, structure.composition.reduced_formula, structure.lattice)

    # Cell anchored from isolated 010/100/011/110/11-1/111 families and
    # replayed against isolated middle/high-angle wolframite reflections.
    # Fractional coordinates remain those of the health-screened MgWO4 parent.
    parent = Structure.from_file(cod_path("9013902"))
    parent.replace_species({"Mg": "Mn"})
    indexed = Structure(
        Lattice.monoclinic(4.8340, 5.7647, 4.9998, 91.1484),
        parent.species,
        parent.frac_coords,
        site_properties=parent.site_properties,
    )
    filename = "mnwo4_wolframite_indexed.cif"
    CifWriter(indexed, symprec=0.01, refine_struct=False).write_file(OUT / filename)
    print(filename, indexed.composition.reduced_formula, indexed.lattice)


if __name__ == "__main__":
    main()
