#!/usr/bin/env python3
"""Replay the accepted GSAS-II model and export the submission artifacts."""

from __future__ import annotations

import contextlib
import csv
import io
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "work" / "trials" / "p1_001_cross_high.gpx"
PROJECT = ROOT / "final.gpx"

PHASE_EXPORTS = [
    {
        "name": "MnWO4 (wolframite)",
        "formula": "MnWO4",
        "cif_path": "phase_mnwo4.cif",
    },
    {
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif_path": "phase_wo3.cif",
    },
    {
        "name": "Mn3O4 (hausmannite)",
        "formula": "Mn3O4",
        "cif_path": "phase_mn3o4.cif",
    },
]


def replay(project: G2sc.G2Project, count: int) -> list[dict[str, float]]:
    """Refine repeatedly and return convergence statistics for each replay."""
    project.set_Controls("cycles", 16)
    history = []
    capture = io.StringIO()
    with contextlib.redirect_stdout(capture):
        for _ in range(count):
            project.do_refinements([{}])
            project.save()
            rvals = project.data["Covariance"]["data"]["Rvals"]
            history.append(
                {
                    "chi_squared": float(rvals["chisq"]),
                    "Rwp_percent": float(rvals["Rwp"]),
                    "max_shift_over_sigma": float(rvals["Max shft/sig"]),
                }
            )
    return history


def main() -> None:
    if not SOURCE.is_file():
        raise FileNotFoundError(SOURCE)
    shutil.copy2(SOURCE, PROJECT)

    # Explicitly reopen the complete measured range before the first replay.
    project = G2sc.G2Project(str(PROJECT))
    histogram = project.histogram(0)
    x = np.asarray(histogram.data["data"][1][0], dtype=float)
    histogram.data["Limits"][1][:] = [float(x[0]), float(x[-1])]
    project.save()
    replay_history = replay(project, 3)

    # Reopen the saved GPX and replay again so all exports come from a tested
    # serialization of the final project, not only from an in-memory state.
    project = G2sc.G2Project(str(PROJECT))
    replay_history.extend(replay(project, 2))
    histogram = project.histogram(0)

    if len(project.phases()) != len(PHASE_EXPORTS):
        raise RuntimeError(f"Expected three phases, found {len(project.phases())}")
    if project.get_Frozen():
        raise RuntimeError(f"Final project has frozen parameters: {project.get_Frozen()}")

    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    if float(rvals["Max shft/sig"]) >= 0.1:
        raise RuntimeError(f"Final replay did not converge: {rvals['Max shft/sig']}")

    mass_fractions = histogram.ComputeMassFracs()
    phases = []
    for phase, descriptor in zip(project.phases(), PHASE_EXPORTS, strict=True):
        cif_path = ROOT / descriptor["cif_path"]
        phase.export_CIF(str(cif_path))
        fraction, fraction_esd = mass_fractions[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        phase_id = phase.data["pId"]
        phases.append(
            {
                **descriptor,
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "weight_fraction": float(fraction),
                "weight_fraction_esd": float(fraction_esd),
                "cif_path": descriptor["cif_path"],
                "project_path": "final.gpx",
                "lattice_parameters": {key: float(value) for key, value in cell.items()},
                "lattice_parameter_esds": {
                    key: float(value) for key, value in cell_esd.items()
                },
                "bragg_R_percent": float(histogram.residuals[f"{phase_id}:0:Rf"]),
                "bragg_R_F2_percent": float(
                    histogram.residuals[f"{phase_id}:0:Rf^2"]
                ),
            }
        )

    fraction_sum = sum(item["weight_fraction"] for item in phases)
    if not math.isclose(fraction_sum, 1.0, rel_tol=0.0, abs_tol=1.0e-10):
        raise RuntimeError(f"Mass fractions sum to {fraction_sum}, not one")

    profile = [np.asarray(item, dtype=float) for item in histogram.data["data"][1]]
    x, observed, weights, calculated, background, stored_difference = profile[:6]
    difference = observed - calculated
    if not np.allclose(difference, stored_difference, rtol=0.0, atol=1.0e-7):
        raise RuntimeError("Stored and recomputed difference profiles disagree")
    if not all(np.all(np.isfinite(item)) for item in profile[:6]):
        raise RuntimeError("Non-finite value found in final profile")

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
                "weight",
            ]
        )
        writer.writerows(
            zip(x, observed, calculated, difference, background, weights, strict=True)
        )

    result = {
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
        "weight_fraction_normalization": "modeled crystalline phases only",
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": float(rvals["Rwp"]),
            "Rp_percent": float(histogram.residuals["R"]),
            "Rexp_percent": float(histogram.residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_variables": int(rvals["Nvars"]),
            "max_shift_over_sigma": float(rvals["Max shft/sig"]),
            "two_theta_min_deg": float(x[0]),
            "two_theta_max_deg": float(x[-1]),
        },
        "replay_history": replay_history,
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
