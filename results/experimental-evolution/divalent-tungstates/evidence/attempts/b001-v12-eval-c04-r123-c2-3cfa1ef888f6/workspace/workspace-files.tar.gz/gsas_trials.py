#!/usr/bin/env python3
"""Create and challenge GSAS-II powder refinements for this dataset."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import spsolve

from GSASII import GSASIIscriptable as G2sc


PATTERN = Path("inputs/pattern.csv").resolve()
INSTRUMENT = Path("work/cu_ka1ka2.instprm").resolve()


def asymmetric_baseline(y: np.ndarray, lam: float = 3e7, p: float = 0.002) -> np.ndarray:
    """Return a smooth baseline used only to initialize GSAS-II coefficients."""
    length = len(y)
    second_difference = sparse.diags(
        [1.0, -2.0, 1.0], [0, 1, 2], shape=(length - 2, length)
    )
    weights = np.ones(length)
    for _ in range(18):
        system = sparse.spdiags(weights, 0, length, length)
        system = system + lam * second_difference.T @ second_difference
        baseline = spsolve(system, weights * y)
        weights = p * (y > baseline) + (1.0 - p) * (y < baseline)
    return np.asarray(baseline)


def initialize_background(hist, order: int) -> None:
    x, y = [np.asarray(v) for v in hist.data["data"][1][:2]]
    baseline = asymmetric_baseline(y)
    normalized_x = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    coeffs = np.polynomial.chebyshev.chebfit(normalized_x, baseline, order - 1)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": False,
                "no. coeffs": order,
                "coeffs": [float(value) for value in coeffs],
            }
        }
    )


def neutralize_phase_profile(phase, hist) -> None:
    """Make all inactive phase-specific profile/intensity terms neutral."""
    hap = phase.data["Histograms"][hist.name]

    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [100.0, 100.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][4][:] = [100.0] * len(hap["Size"][4])
    hap["Size"][5][:] = [False] * len(hap["Size"][5])

    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])

    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def neutralize_histogram(hist) -> None:
    sample = hist.data["Sample Parameters"]
    sample["Scale"][:] = [1.0, False]
    for key in [
        "Shift",
        "Transparency",
        "SurfRoughA",
        "SurfRoughB",
        "Absorption",
        "DisplaceX",
        "DisplaceY",
    ]:
        if key in sample:
            sample[key][:] = [0.0, False]
    instrument = hist.data["Instrument Parameters"][0]
    for key in instrument:
        if len(instrument[key]) >= 3:
            instrument[key][2] = False


def set_bounds(project: G2sc.G2Project, phase_count: int) -> None:
    for variable, maximum in [(":0:U", 2000.0), (":0:W", 2000.0), (":0:X", 200.0)]:
        project.set_Controls("parmMin", 0.0, variable)
        project.set_Controls("parmMax", maximum, variable)
    project.set_Controls("parmMin", -0.5, ":0:Zero")
    project.set_Controls("parmMax", 0.5, ":0:Zero")
    for phase_id in range(phase_count):
        project.set_Controls("parmMin", 0.0, f"{phase_id}:0:Scale")


def cov_summary(project: G2sc.G2Project) -> dict:
    covariance = project.data.get("Covariance", {}).get("data", {}) or {}
    rvals = covariance.get("Rvals", {}) or {}
    wanted = ["Rwp", "Rexp", "GOF", "chisq", "Nobs", "Nvars", "Max shft/sig"]
    return {key: rvals[key] for key in wanted if key in rvals}


def summary(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    output = {
        "project": project.filename,
        "residuals": hist.residuals,
        "covariance": cov_summary(project),
        "instrument": {
            key: inst[key][1]
            for key in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]
            if key in inst
        },
        "background": {
            "type": hist.data["Background"][0][0],
            "order": hist.data["Background"][0][2],
            "coeffs": hist.data["Background"][0][3:],
        },
        "sample": {
            key: value[0]
            for key, value in hist.data["Sample Parameters"].items()
            if isinstance(value, list) and len(value) == 2
        },
        "frozen": project.get_Frozen(),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        output["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    try:
        output["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        output["mass_fraction_error"] = str(exc)
    return output


def ensure_finite(project: G2sc.G2Project) -> None:
    state = summary(project)
    numbers = [state["residuals"].get("wR", math.nan)]
    for phase in state["phases"].values():
        numbers.extend(phase["cell"].values())
        numbers.append(phase["scale"])
    if not all(np.isfinite(value) for value in numbers):
        raise RuntimeError(f"non-finite refinement state: {state}")


def refine(project: G2sc.G2Project, label: str) -> None:
    project.do_refinements([{}])
    ensure_finite(project)
    project.save()
    print(json.dumps({"step": label, **summary(project)}, indent=2, default=float))


def build_neutral(model: Path, output: Path, phase_name: str, background_order: int) -> G2sc.G2Project:
    project = G2sc.G2Project(newgpx=str(output.resolve()))
    hist = project.add_powder_histogram(
        str(PATTERN), str(INSTRUMENT), fmthint="comma"
    )
    phase = project.add_phase(
        str(model.resolve()),
        phasename=phase_name,
        histograms=[hist],
        fmthint="CIF",
    )
    hist.set_refinements({"Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])]})
    neutralize_histogram(hist)
    neutralize_phase_profile(phase, hist)
    initialize_background(hist, background_order)
    phase.HAPvalue("Scale", 0.05)
    project.set_Controls("cycles", 12)
    project.save()
    set_bounds(project, 1)
    project.save()
    return project


def run_baseline(args: argparse.Namespace) -> None:
    project = build_neutral(
        Path(args.model), Path(args.output), args.phase_name, args.background_order
    )
    hist = project.histogram(0)
    phase = project.phase(0)

    hist.set_refinements({"Background": {"refine": True}})
    phase.set_HAP_refinements({"Scale": True})
    refine(project, "background+scale")

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "cell+zero")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(project, "common-profile")
    refine(project, "replay")


def run_summary(args: argparse.Namespace) -> None:
    project = G2sc.G2Project(args.project)
    print(json.dumps(summary(project), indent=2, default=float))


def parser() -> argparse.ArgumentParser:
    out = argparse.ArgumentParser()
    sub = out.add_subparsers(dest="command", required=True)
    baseline = sub.add_parser("baseline")
    baseline.add_argument("--model", required=True)
    baseline.add_argument("--output", required=True)
    baseline.add_argument("--phase-name", default="MnWO4_wolframite")
    baseline.add_argument("--background-order", type=int, default=10)
    baseline.set_defaults(func=run_baseline)
    show = sub.add_parser("summary")
    show.add_argument("project")
    show.set_defaults(func=run_summary)
    return out


def main() -> None:
    args = parser().parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
