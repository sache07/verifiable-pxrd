#!/usr/bin/env python3
"""Challenge physically plausible WO3 source records under one nuisance model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from refine_work import background_points, cod_cif, prepare_inputs


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"


def neutral(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][1:3] = [1.0, False]


def replay(gpx: G2sc.G2Project, max_passes: int = 4) -> None:
    previous = None
    for _ in range(max_passes):
        gpx.refine(makeBack=False)
        current = float(gpx.histogram(0).residuals["wR"])
        gpx.save()
        gpx.reload()
        if previous is not None and abs(previous - current) < 2e-4:
            break
        previous = current


def run(wo3_id: str) -> dict:
    xye, instfile = prepare_inputs()
    pattern = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    out = TMP / f"source_WO3_{wo3_id}.gpx"
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(str(xye), str(instfile), fmthint="xye")
    hist.set_refinements({"Limits": [10.0, 100.0]})
    phase_defs = [("ZnWO4", "1520641"), ("WO3", wo3_id), ("ZnO", "9004178")]
    phases = []
    for name, cid in phase_defs:
        phase = gpx.add_phase(str(cod_cif(cid)), phasename=name, histograms=[hist], fmthint="CIF")
        neutral(phase, hist)
        phases.append(phase)
    hist.SampleParameters["Scale"] = [1.0, False]
    for key in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]:
        if key in hist.SampleParameters:
            hist.SampleParameters[key] = [0.0, False]
    for phase, scale in zip(phases, [0.0001, 0.0001, 0.0003]):
        phase.data["Histograms"][hist.name]["Scale"] = [scale, False]
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 8,
            "refine": True,
            "FixedPoints": background_points(pattern[:, 0], pattern[:, 1]),
            "fit fixed points": True,
        }
    })
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-5
    gpx.save()
    for var in [":0:W"]:
        gpx.set_Controls("parmMin", 0.0, var)
    for pid in range(3):
        gpx.set_Controls("parmMin", 0.0, f"{pid}:0:Scale")
        gpx.set_Controls("parmMin", 0.005, f"{pid}:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, f"{pid}:0:Size;i")

    gpx.set_refinement({"set": {"Scale": True}})
    replay(gpx)
    gpx.set_refinement({"set": {"Instrument Parameters": ["Zero"]}})
    replay(gpx)
    gpx.set_refinement({"set": {"Cell": True}})
    replay(gpx)
    gpx.set_refinement({"set": {"Instrument Parameters": ["W"]}})
    replay(gpx)
    for phase, seed in zip(phases, [0.08, 0.15, 0.4]):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][1][0] = seed
        hap["Size"][2][0] = True
        replay(gpx)

    hist = gpx.histogram(0)
    mf = hist.ComputeMassFracs()
    result = {
        "wo3_cod_id": wo3_id,
        "wR": float(hist.residuals["wR"]),
        "R": float(hist.residuals["R"]),
        "frozen": gpx.get_Frozen(),
        "W": float(hist.InstrumentParameters["W"][1]),
        "zero": float(hist.InstrumentParameters["Zero"][1]),
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "fraction": float(mf[phase.name][0]),
            "size_um": float(hap["Size"][1][0]),
            "cell": phase.get_cell(),
        }
    print(json.dumps(result, indent=2))
    return result


def main() -> None:
    results = [run(cid) for cid in ["1528915", "2311041", "2106293", "1563541"]]
    (TMP / "source_trials.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
