#!/usr/bin/env python3
"""Compare replayed profile/size/strain models from a common GSAS-II state."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
BASE = TMP / "03_cells.gpx"


def clean_model(gpx: G2sc.G2Project, values: dict[str, float], vary: list[str]) -> None:
    hist = gpx.histogram(0)
    for key in ["U", "V", "W", "X", "Y", "Z", "SH/L"]:
        hist.InstrumentParameters[key][2] = False
    for key, value in values.items():
        hist.InstrumentParameters[key][1] = value
    for key in vary:
        hist.InstrumentParameters[key][2] = True

    # Reset all phase-specific broadening to a negligible state.
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])

    controls = gpx.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    gpx.set_Controls("cycles", 12)
    gpx.save()
    for var in [":0:U", ":0:W", ":0:X"]:
        gpx.set_Controls("parmMin", 0.0, var)
    for pid in range(len(gpx.phases())):
        gpx.set_Controls("parmMin", 0.005, f"{pid}:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, f"{pid}:0:Size;i")
        gpx.set_Controls("parmMin", 0.0, f"{pid}:0:Mustrain;i")


def state(gpx: G2sc.G2Project, model: str, stage: str) -> dict:
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    result = {
        "model": model,
        "stage": stage,
        "wR": float(hist.residuals["wR"]),
        "R": float(hist.residuals["R"]),
        "chi2": float(gpx.data["Covariance"]["data"]["Rvals"]["GOF"] ** 2),
        "last_shift": float(
            np.max(np.abs(gpx.data["Covariance"]["data"].get("Lastshft", [-1.0])))
        ),
        "frozen": gpx.get_Frozen(),
        "instrument": {k: float(inst[k][1]) for k in ["U", "V", "W", "X", "Y", "Z", "SH/L"]},
        "phases": {},
    }
    try:
        mf = hist.ComputeMassFracs()
    except Exception:
        mf = {}
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "fraction": float(mf.get(phase.name, [float("nan")])[0]),
            "size_um": float(hap["Size"][1][0]),
            "size_vary": bool(hap["Size"][2][0]),
            "microstrain": float(hap["Mustrain"][1][0]),
            "microstrain_vary": bool(hap["Mustrain"][2][0]),
        }
    print(json.dumps(result, indent=2))
    return result


def replay(gpx: G2sc.G2Project, model: str, stage: str, log: list[dict]) -> None:
    previous = None
    # Save/reopen/replay until the global residual stabilizes.
    for idx in range(5):
        gpx.refine(makeBack=False)
        current = float(gpx.histogram(0).residuals["wR"])
        gpx.save()
        gpx.reload()
        if previous is not None and abs(previous - current) < 2.0e-4:
            break
        previous = current
    log.append(state(gpx, model, stage))


def add_size(gpx: G2sc.G2Project, name: str, seed: float) -> None:
    hist = gpx.histogram(0)
    phase = gpx.phase(name)
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = seed
    hap["Size"][2][0] = True


def add_strain(gpx: G2sc.G2Project, name: str, seed: float) -> None:
    hist = gpx.histogram(0)
    phase = gpx.phase(name)
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = seed
    hap["Mustrain"][2][0] = True


def run_variant(
    model: str,
    values: dict[str, float],
    vary: list[str],
    broadening: str,
) -> list[dict]:
    output = TMP / f"trial_{model}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(output))
    clean_model(gpx, values, vary)
    log: list[dict] = []
    replay(gpx, model, "common_profile", log)
    if broadening == "size":
        for phase, seed in [("ZnWO4", 0.10), ("WO3", 0.20), ("ZnO", 1.0)]:
            add_size(gpx, phase, seed)
            replay(gpx, model, f"size_{phase}", log)
    elif broadening == "strain":
        for phase, seed in [("ZnWO4", 800.0), ("WO3", 500.0), ("ZnO", 200.0)]:
            add_strain(gpx, phase, seed)
            replay(gpx, model, f"strain_{phase}", log)
    return log


def main() -> None:
    all_results: list[dict] = []
    variants = [
        ("W_size", {"U": 2.0, "W": 5.0, "X": 0.0}, ["W"], "size"),
        ("UW_size", {"U": 2.0, "W": 5.0, "X": 0.0}, ["U", "W"], "size"),
        ("WX_size", {"U": 2.0, "W": 5.0, "X": 1.0}, ["W", "X"], "size"),
        ("UX_size_W5", {"U": 2.0, "W": 5.0, "X": 1.0}, ["U", "X"], "size"),
        ("UW_strain", {"U": 2.0, "W": 5.0, "X": 0.0}, ["U", "W"], "strain"),
    ]
    for args in variants:
        all_results.extend(run_variant(*args))
    (TMP / "profile_trials.json").write_text(json.dumps(all_results, indent=2))


if __name__ == "__main__":
    main()
