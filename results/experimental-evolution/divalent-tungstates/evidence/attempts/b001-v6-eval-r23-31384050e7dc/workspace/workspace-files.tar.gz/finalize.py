#!/usr/bin/env python3
"""Create the exact final GSAS-II project and user-facing deliverables."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/combined_coords.gpx"
FINAL_GPX = ROOT / "final.gpx"

PHASE_INFO = {
    "ZnWO4": {
        "display_name": "zinc tungstate",
        "formula": "ZnWO4",
        "cod_id": "1520641",
        "cif": "ZnWO4.cif",
    },
    "WO3": {
        "display_name": "monoclinic tungsten trioxide",
        "formula": "WO3",
        "cod_id": "2311041",
        "cif": "WO3.cif",
    },
    "ZnO": {
        "display_name": "wurtzite zinc oxide",
        "formula": "ZnO",
        "cod_id": "9004178",
        "cif": "ZnO.cif",
    },
}


def replay_full_range() -> G2sc.G2Project:
    pattern = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL_GPX))
    hist = gpx.histogram(0)
    hist.set_refinements({"Limits": [float(pattern[0, 0]), float(pattern[-1, 0])]})
    hist.Excluded([])
    gpx.data["Controls"]["data"]["parmFrozen"] = {}
    gpx.set_Controls("cycles", 12)
    gpx.save()

    previous = None
    for _ in range(5):
        gpx.refine(makeBack=False)
        current = float(gpx.histogram(0).residuals["wR"])
        gpx.save()
        gpx.reload()
        if previous is not None and abs(current - previous) < 2.0e-4:
            break
        previous = current
    gpx.save(FINAL_GPX)
    return G2sc.G2Project(str(FINAL_GPX))


def main() -> None:
    gpx = replay_full_range()
    hist = gpx.histogram(0)
    if gpx.get_Frozen():
        raise RuntimeError(f"Final project contains frozen variables: {gpx.get_Frozen()}")

    # Export CIFs directly from the reloaded final project.
    for phase in gpx.phases():
        phase.export_CIF(str(ROOT / PHASE_INFO[phase.name]["cif"]))

    profile = np.column_stack(
        [
            hist.getdata("X"),
            hist.getdata("Yobs"),
            hist.getdata("Ycalc"),
            hist.getdata("Residual"),
            hist.getdata("Background"),
        ]
    )
    # Guard the semantic contract for the difference column.
    if not np.allclose(profile[:, 3], profile[:, 1] - profile[:, 2], atol=1e-8):
        raise RuntimeError("GSAS-II residual is not observed minus calculated")
    np.savetxt(
        ROOT / "fit.csv",
        profile,
        delimiter=",",
        fmt="%.8f",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )

    mass = hist.ComputeMassFracs()
    total = sum(value[0] for value in mass.values())
    cov = gpx.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    residuals = hist.residuals
    phases_json = []
    for phase in gpx.phases():
        info = PHASE_INFO[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        hap = phase.data["Histograms"][hist.name]
        frac, frac_esd = mass[phase.name]
        phases_json.append(
            {
                "name": info["display_name"],
                "formula": info["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "source_cod_id": info["cod_id"],
                "cif_path": info["cif"],
                "weight_fraction": float(frac / total),
                "weight_percent": float(100.0 * frac / total),
                "formal_weight_fraction_esd": float(frac_esd),
                "cell": {key: float(value) for key, value in cell.items()},
                "cell_esd": {key: float(value) for key, value in cell_esd.items()},
                "isotropic_size_micrometre": float(hap["Size"][1][0]),
                "isotropic_microstrain": float(hap["Mustrain"][1][0]),
            }
        )

    fit_statistics = {
        "r_wp_percent": float(residuals["wR"]),
        "r_p_percent": float(residuals["R"]),
        "r_exp_percent": float(residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "reduced_chi_square": float(rvals["GOF"] ** 2),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_variables": int(rvals["Nvars"]),
        "two_theta_range_deg": [float(profile[0, 0]), float(profile[-1, 0])],
        "weighting": "Poisson estimate sigma=sqrt(counts); pointwise uncertainties were not supplied",
    }
    result = {
        "phases": phases_json,
        "fit_statistics": fit_statistics,
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "fractions_normalized_over": "modeled crystalline phases",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    by_formula = {row["formula"]: row for row in phases_json}
    report = f"""# PXRD phase analysis

## Result

Three crystalline phases are required. Weight fractions are normalized over the modeled crystalline phases:

| Phase | Structural model | Weight fraction |
|---|---|---:|
| ZnWO4 | wolframite type, P2/c | {by_formula['ZnWO4']['weight_percent']:.2f} wt% |
| WO3 | monoclinic, P2_1/c | {by_formula['WO3']['weight_percent']:.2f} wt% |
| ZnO | wurtzite, P6_3mc | {by_formula['ZnO']['weight_percent']:.2f} wt% |

The final full-range refinement gives Rwp = {fit_statistics['r_wp_percent']:.3f}%, Rp = {fit_statistics['r_p_percent']:.3f}%, Rexp = {fit_statistics['r_exp_percent']:.3f}%, and goodness of fit = {fit_statistics['goodness_of_fit']:.3f} over {fit_statistics['two_theta_range_deg'][0]:.4f}–{fit_statistics['two_theta_range_deg'][1]:.4f}° 2theta.

## Evidence and model selection

ZnWO4 is supported by its coherent families near 18.9°, 30.4/30.7°, 36.3°, 38.3°, 51.7°, and higher angles. Monoclinic WO3 is identified independently by the 23.2/23.6/24.4° triplet and matching groups near 33–34°, 42°, and 50–56°. Residual ZnO is required by the sharp wurtzite sequence at about 31.8°, 34.5°, 36.3°, 47.6°, 56.6°, 62.9°, and 68.1°. All three scales remain strongly positive after replay.

Exact-composition COD records were screened for composition, occupancy, symmetry, cell, and geometry. The retained starting records are COD 1520641 (ZnWO4), 2311041 (WO3), and 9004178 (ZnO). For WO3, COD 2311041 outperformed the alternate conventional monoclinic record under the same nuisance model; a triclinic record was slightly worse despite lower symmetry, and the small-cell monoclinic polymorph failed. Cubic ZnO alternatives do not reproduce the observed wurtzite sequence. The final octahedral/tetrahedral distances remain chemically normal: W–O about 1.81–2.16 Å and Zn–O about 2.00–2.17 Å in ZnWO4, W–O about 1.68–2.22 Å in WO3, and Zn–O about 1.98 Å in ZnO.

The baseline uses an eight-coefficient smooth Chebyshev background, one zero correction, refined effective polarization, and a common nonnegative W Gaussian-width term; U/V/X/Y/Z are fixed at zero and SH/L is held at its near-neutral default because repeated asymmetry is not evident. Isotropic size is supported for each phase. Only WO3 supports complementary isotropic microstrain; ZnWO4 and ZnO strain trials collapse to zero. Multiple March–Dollase axes were tested and rejected because improvements were negligible and coefficients stayed near unity. No roughness, transparency, or texture correction is active. ZnWO4 atomic coordinates and the two WO3 W positions were refined; unconstrained WO3 oxygen refinement was rejected after it produced implausible octahedral distortion.

## Remaining uncertainty

The formal covariance fraction uncertainties are smaller than realistic model/systematic errors. A conservative interpretation is roughly ±1.0 wt% for ZnWO4, ±0.7 wt% for WO3, and ±0.5 wt% for ZnO. Because no internal standard or amorphous model was supplied, the absolute crystalline content and any amorphous fraction cannot be determined; the reported fractions sum to 100% only across the three modeled crystalline phases. Pointwise uncertainties were not supplied, so Poisson counting uncertainties were estimated for refinement. No additional crystalline phase is supported by a coherent residual family, but a trace phase below the pattern's practical detection limit cannot be excluded reliably.
"""
    (ROOT / "report.md").write_text(report)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
