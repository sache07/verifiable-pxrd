#!/usr/bin/env python3
"""Residual-led polarization, complementary strain, and texture challenges."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
BASE = TMP / "source_WO3_2311041.gpx"


def replay(gpx: G2sc.G2Project, passes: int = 4) -> None:
    prev = None
    gpx.set_Controls("cycles", 12)
    for _ in range(passes):
        gpx.refine(makeBack=False)
        wr = float(gpx.histogram(0).residuals["wR"])
        gpx.save()
        gpx.reload()
        if prev is not None and abs(wr - prev) < 2e-4:
            break
        prev = wr


def snapshot(gpx: G2sc.G2Project, trial: str) -> dict:
    h = gpx.histogram(0)
    mf = h.ComputeMassFracs()
    out = {
        "trial": trial,
        "wR": float(h.residuals["wR"]),
        "R": float(h.residuals["R"]),
        "polarization": float(h.InstrumentParameters["Polariz."][1]),
        "W": float(h.InstrumentParameters["W"][1]),
        "frozen": gpx.get_Frozen(),
        "phases": {},
    }
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        out["phases"][p.name] = {
            "fraction": float(mf[p.name][0]),
            "size_um": float(hap["Size"][1][0]),
            "microstrain": float(hap["Mustrain"][1][0]),
            "microstrain_vary": bool(hap["Mustrain"][2][0]),
            "MD": float(hap["Pref.Ori."][1]),
            "MD_vary": bool(hap["Pref.Ori."][2]),
            "MD_axis": list(hap["Pref.Ori."][3]),
        }
    print(json.dumps(out, indent=2))
    return out


def project(src: Path, trial: str) -> G2sc.G2Project:
    out = TMP / f"challenge_{trial}.gpx"
    gpx = G2sc.G2Project(str(src), newgpx=str(out))
    gpx.data["Controls"]["data"]["parmFrozen"] = {}
    gpx.save()
    return gpx


def polarization_trial() -> tuple[Path, dict]:
    trial = "polarization"
    gpx = project(BASE, trial)
    h = gpx.histogram(0)
    h.InstrumentParameters["Polariz."][2] = True
    gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
    gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")
    replay(gpx)
    return Path(gpx.filename), snapshot(gpx, trial)


def strain_trial(src: Path, phase_name: str) -> dict:
    trial = f"strain_{phase_name}"
    gpx = project(src, trial)
    h = gpx.histogram(0)
    p = gpx.phase(phase_name)
    hap = p.data["Histograms"][h.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 300.0
    hap["Mustrain"][2][0] = True
    gpx.set_Controls("parmMin", 0.0, f"{p.id}:0:Mustrain;i")
    replay(gpx)
    return snapshot(gpx, trial)


def texture_trial(src: Path, phase_name: str, axis: tuple[int, int, int]) -> dict:
    label = "".join(str(v).replace("-", "m") for v in axis)
    trial = f"texture_{phase_name}_{label}"
    gpx = project(src, trial)
    h = gpx.histogram(0)
    p = gpx.phase(phase_name)
    po = p.data["Histograms"][h.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 0.98
    po[2] = True
    po[3] = list(axis)
    gpx.set_Controls("parmMin", 0.2, f"{p.id}:0:MD")
    gpx.set_Controls("parmMax", 5.0, f"{p.id}:0:MD")
    replay(gpx)
    return snapshot(gpx, trial)


def main() -> None:
    results: list[dict] = [snapshot(G2sc.G2Project(str(BASE)), "baseline")]
    pol_path, pol_result = polarization_trial()
    results.append(pol_result)
    # Use the polarization model only if it is interior and improves the fit.
    src = pol_path if 0.0 < pol_result["polarization"] < 1.0 and pol_result["wR"] < results[0]["wR"] else BASE
    for name in ["ZnWO4", "WO3", "ZnO"]:
        results.append(strain_trial(src, name))
    axes = {
        "ZnWO4": [(0, 1, 0), (1, 0, 0), (0, 0, 1), (1, 0, 1), (1, 1, 0)],
        "WO3": [(0, 1, 0), (1, 0, 0), (0, 0, 1), (1, 0, 1), (1, 1, 0)],
        "ZnO": [(0, 0, 1), (1, 0, 0), (1, 0, 1)],
    }
    for name, choices in axes.items():
        for axis in choices:
            results.append(texture_trial(src, name, axis))
    (TMP / "model_challenges.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
