#!/usr/bin/env python3
"""Staged GSAS-II refinement for the ZnO-WO3 reaction pattern.

This is a working/reproducibility script. Final deliverables are written by a
separate finalization pass after model selection.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
TMP.mkdir(exist_ok=True)

COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_cif(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PHASES = [
    ("ZnWO4", "1520641"),
    ("WO3", "1528915"),
    ("ZnO", "9004178"),
]


def prepare_inputs() -> tuple[Path, Path]:
    pattern = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    xye = TMP / "pattern.xye"
    # Counts are unprocessed. No pointwise s.u.'s were supplied, so use the
    # counting-statistics estimate sigma=sqrt(counts), explicitly documented
    # in the final report.
    sigma = np.sqrt(np.maximum(pattern[:, 1], 1.0))
    np.savetxt(xye, np.column_stack((pattern, sigma)), fmt="%.8f %.8f %.8f")

    inst = TMP / "cu_kalpha.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for reflection Cu Kalpha data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;"
        "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:2.0;V:0.0;W:5.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )
    return xye, inst


def background_points(x: np.ndarray, y: np.ndarray) -> list[tuple[float, float]]:
    """Low-envelope points used only to initialize a smooth polynomial."""
    points: list[tuple[float, float]] = []
    for center in np.arange(10.0, 100.01, 2.5):
        mask = np.abs(x - center) <= 0.75
        if np.any(mask):
            points.append((float(center), float(np.percentile(y[mask], 8))))
    return points


def neutralize_hap(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData) -> None:
    hap = phase.data["Histograms"][hist.name]
    # Large size and zero microstrain make both contributions negligible.
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1000.0, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def summary(gpx: G2sc.G2Project, label: str) -> dict:
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    out = {
        "stage": label,
        "residuals": {
            k: float(v)
            for k, v in hist.residuals.items()
            if not k.endswith("::Name")
        },
        "instrument": {
            k: float(inst[k][1])
            for k in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]
        },
        "background": [float(v) for v in hist.Background[0][3:]],
        "phases": {},
    }
    try:
        mass = hist.ComputeMassFracs()
    except Exception as exc:
        mass = {p.name: (float("nan"), float("nan")) for p in gpx.phases()}
        out["mass_fraction_error"] = repr(exc)
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": {k: float(v) for k, v in phase.get_cell().items()},
            "scale": float(hap["Scale"][0]),
            "mass_fraction": [float(v) for v in mass.get(phase.name, (math.nan, math.nan))],
            "size": [hap["Size"][0], [float(v) for v in hap["Size"][1]], list(hap["Size"][2])],
            "mustrain": [
                hap["Mustrain"][0],
                [float(v) for v in hap["Mustrain"][1]],
                list(hap["Mustrain"][2]),
            ],
            "preferred_orientation": list(hap["Pref.Ori."][:4]),
        }
    print(json.dumps(out, indent=2, default=str))
    return out


def refine_and_log(gpx: G2sc.G2Project, log: list[dict], label: str) -> None:
    gpx.refine(makeBack=False)
    log.append(summary(gpx, label))
    gpx.save(TMP / f"{label}.gpx")


def main() -> None:
    xye, instfile = prepare_inputs()
    pattern = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)

    work_gpx = TMP / "work.gpx"
    if work_gpx.exists():
        work_gpx.unlink()
    gpx = G2sc.G2Project(newgpx=str(work_gpx))
    hist = gpx.add_powder_histogram(str(xye), str(instfile), fmthint="xye")
    hist.set_refinements({"Limits": [10.0, 100.0]})

    phases = []
    for name, cod_id in PHASES:
        phase = gpx.add_phase(
            str(cod_cif(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        neutralize_hap(phase, hist)
        phases.append(phase)

    # Keep all non-selected sample corrections neutral. Use one angular
    # correction (Zero) later, never simultaneously with specimen shift.
    sample = hist.SampleParameters
    sample["Scale"][0] = 1.0
    sample["Scale"][1] = False
    for key in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]:
        if key in sample and isinstance(sample[key], list):
            sample[key][0] = 0.0
            sample[key][1] = False

    # Reasonable scale seeds avoid a huge initial calculated pattern. All are
    # freely re-estimated in the first least-squares pass.
    for phase, scale in zip(phases, [0.00010, 0.00010, 0.00030]):
        phase.data["Histograms"][hist.name]["Scale"][0] = scale

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "refine": True,
                "FixedPoints": background_points(pattern[:, 0], pattern[:, 1]),
                "fit fixed points": True,
            }
        }
    )

    gpx.set_Controls("cycles", 10)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    gpx.data["Controls"]["data"]["shift factor"] = 1.0
    gpx.save()

    # Physically meaningful bounds. These also make a collapsed trial obvious.
    for var in [":0:U", ":0:W", ":0:X"]:
        gpx.set_Controls("parmMin", 0.0, var)
    for pid in range(len(phases)):
        gpx.set_Controls("parmMin", 0.0, f"{pid}:0:Scale")
        gpx.set_Controls("parmMin", 0.005, f"{pid}:0:Size;i")
        gpx.set_Controls("parmMax", 1000.0, f"{pid}:0:Size;i")
        gpx.set_Controls("parmMin", 0.0, f"{pid}:0:Mustrain;i")

    log: list[dict] = []

    # Inventory scales and smooth background first.
    gpx.set_refinement({"set": {"Scale": True}})
    refine_and_log(gpx, log, "01_scales_background")

    # One angular correction, followed by all cells under the same nuisance model.
    gpx.set_refinement({"set": {"Instrument Parameters": ["Zero"]}})
    refine_and_log(gpx, log, "02_zero")
    gpx.set_refinement({"set": {"Cell": True}})
    refine_and_log(gpx, log, "03_cells")

    # Common nonnegative profile, built one term at a time. V/Y/Z stay zero.
    gpx.set_refinement({"set": {"Instrument Parameters": ["W"]}})
    refine_and_log(gpx, log, "04_profile_W")
    gpx.set_refinement({"set": {"Instrument Parameters": ["U"]}})
    refine_and_log(gpx, log, "05_profile_UW")
    gpx.set_refinement({"set": {"Instrument Parameters": ["X"]}})
    refine_and_log(gpx, log, "06_profile_UWX")

    # Revisit broadening phase by phase. These are provisional accepted-model
    # passes; separate trial projects will compare size against strain.
    for idx, (phase, seed) in enumerate(zip(phases, [0.05, 0.10, 0.50]), start=7):
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": seed, "refine": True}},
            [hist],
        )
        refine_and_log(gpx, log, f"{idx:02d}_size_{phase.name}")

    gpx.save(TMP / "provisional.gpx")
    (TMP / "refinement_log.json").write_text(json.dumps(log, indent=2, default=str))

    # Profile for visual residual inspection.
    hist = gpx.histogram(0)
    arrays = np.column_stack(
        [
            hist.getdata("X"),
            hist.getdata("Yobs"),
            hist.getdata("Ycalc"),
            hist.getdata("Background"),
            hist.getdata("Residual"),
        ]
    )
    np.savetxt(
        TMP / "provisional_fit.csv",
        arrays,
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference",
        comments="",
    )


if __name__ == "__main__":
    main()
