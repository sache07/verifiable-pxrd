#!/usr/bin/env python3
"""Test limited coordinate refinement without committing unstable models."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
BASE = TMP / "challenge_strain_WO3_U0.gpx"


def run(label: str, selections: dict[str, list[str]]) -> dict:
    gpx = G2sc.G2Project(str(BASE), newgpx=str(TMP / f"atom_{label}.gpx"))
    gpx.data["Controls"]["data"]["parmFrozen"] = {}
    for phase_name, atom_labels in selections.items():
        phase = gpx.phase(phase_name)
        for atom_label in atom_labels:
            phase.atom(atom_label).refinement_flags = "X"
    gpx.set_Controls("cycles", 12)
    gpx.save()
    previous = None
    for _ in range(5):
        gpx.refine(makeBack=False)
        wr = float(gpx.histogram(0).residuals["wR"])
        gpx.save()
        gpx.reload()
        if previous is not None and abs(wr - previous) < 2e-4:
            break
        previous = wr
    h = gpx.histogram(0)
    result = {
        "trial": label,
        "wR": float(h.residuals["wR"]),
        "R": float(h.residuals["R"]),
        "frozen": gpx.get_Frozen(),
        "vary_count": len(gpx.get_VaryList()),
        "mass_fractions": {k: float(v[0]) for k, v in h.ComputeMassFracs().items()},
        "atoms": {},
    }
    for phase in gpx.phases():
        result["atoms"][phase.name] = {
            atom.label: {
                "element": atom.element,
                "xyz": [float(v) for v in atom.coordinates],
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        }
        phase.export_CIF(str(TMP / f"atom_{label}_{phase.name}.cif"))
    print(json.dumps(result, indent=2))
    return result


def main() -> None:
    trials = [
        ("ZnWO4_heavy", {"ZnWO4": ["W", "Zn"]}),
        ("ZnWO4_all", {"ZnWO4": ["W", "Zn", "O1", "O2"]}),
        ("WO3_W", {"WO3": ["W1", "W2"]}),
        ("WO3_all", {"WO3": ["O6", "O2", "W1", "O5", "O3", "O1", "W2", "O4"]}),
        ("ZnO_O", {"ZnO": ["O"]}),
    ]
    results = [run(label, selection) for label, selection in trials]
    (TMP / "atom_trials.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
