#!/usr/bin/env python3
"""Finish the texture portion of the split four-phase stability replay."""

import copy
import json
import shutil
from pathlib import Path

import final_coordinate as fc
import refine_workflow as rw


TMP = Path(".tmp")
checkpoint = TMP / "finalcoord_texture_PbWO4_scheelite_neutral.gpx"
state = {
    "profile": ["W", "X"],
    "background": 10,
    "polarization": True,
    "roughness_B": False,
    "broadening": {
        "PbWO4_scheelite": ["size"],
        "Pb3O4": ["size"],
        "Pb3WO6_analogue": ["strain"],
    },
    "texture": {"Pb3WO6_analogue": [1, 0, 0]},
}
axes = {
    "WO3_monoclinic": [(0, 0, 0), (1, 0, 0), (0, 1, 0),
                        (0, 0, 1), (1, 0, 1), (1, 1, 0), (0, 1, 1)],
    "Pb3O4": [(0, 0, 0), (0, 0, 1), (1, 0, 0),
               (1, 1, 0), (1, 0, 1)],
    "Pb3WO6_analogue": [(0, 0, 0), (1, 0, 0), (0, 1, 0),
                         (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1)],
}


def main():
    global checkpoint, state
    rows = []
    selected = [{"phase": "PbWO4_scheelite", "axis": [0, 0, 0]}]
    for phase_name in ("WO3_monoclinic", "Pb3O4", "Pb3WO6_analogue"):
        reference = rw.G2sc.G2Project(str(checkpoint))
        href = reference.histogram(0)
        reference_fraction = float(href.ComputeMassFracs()[phase_name][0])
        reference_cell = reference.phase(phase_name).get_cell()
        group = []
        for axis in axes[phase_name]:
            trial_state = copy.deepcopy(state)
            if axis == (0, 0, 0):
                trial_state["texture"].pop(phase_name, None)
                suffix = "neutral"
                required = None
            else:
                trial_state["texture"][phase_name] = list(axis)
                suffix = "".join(map(str, axis))
                required = phase_name
            row = fc.run_trial(
                checkpoint, f"finish_texture_{phase_name}_{suffix}",
                trial_state, reset_texture=[phase_name],
                require_texture=required, passes=2,
            )
            if (row["valid"] and phase_name == "Pb3WO6_analogue" and
                    axis != (0, 0, 0)):
                fraction = float(row["mass_fractions"][phase_name][0])
                fraction_ratio = fraction / reference_fraction
                cell = row["summary"]["phases"][phase_name]["cell"]
                ratios = {
                    key: float(cell[key]) / float(reference_cell[key])
                    for key in ("length_a", "length_b", "length_c")
                }
                if not 0.5 <= fraction_ratio <= 2.0:
                    row["valid"] = False
                    row["reason"] = f"fraction ratio={fraction_ratio} unstable"
                elif any(not 0.95 <= value <= 1.05 for value in ratios.values()):
                    row["valid"] = False
                    row["reason"] = f"cell-length ratios={ratios} unstable"
            rows.append(row)
            group.append(row)
        neutral = group[0]
        winner = fc.choose(group, neutral, gain=0.02)
        checkpoint = Path(winner["path"])
        state = copy.deepcopy(winner["state"])
        selected.append({"phase": phase_name, "axis": winner["state"]["texture"].get(phase_name, [0, 0, 0]),
                         "tag": winner["tag"]})
    output = TMP / "four_texture_complete.gpx"
    shutil.copyfile(checkpoint, output)
    final = rw.G2sc.G2Project(str(output))
    payload = {"final_state": state, "selected": selected, "trials": rows,
               "final": rw.summary(final, "four_texture_complete")}
    (TMP / "four_texture_completion.json").write_text(
        json.dumps(payload, indent=2, default=float) + "\n"
    )
    print(json.dumps({"final_state": state, "selected": selected,
                      "final": payload["final"]}, indent=2, default=float))


if __name__ == "__main__":
    main()
