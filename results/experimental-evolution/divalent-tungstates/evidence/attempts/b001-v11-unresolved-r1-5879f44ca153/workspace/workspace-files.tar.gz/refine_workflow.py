#!/usr/bin/env python3
"""Reproducible GSAS-II refinement and model-challenge workflow for this dataset."""

from __future__ import annotations

import argparse
import copy
import csv
import json
import math
import shutil
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
XYE = TMP / "pattern.xye"
INST = ROOT / "instrument.instprm"


def chebyshev_background(ncoeff: int = 8) -> list[float]:
    data = np.genfromtxt(XYE)
    x, y = data[:, 0], data[:, 1]
    smooth_floor = percentile_filter(y, percentile=12, size=401, mode="nearest")
    xpos = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    return list(np.polynomial.chebyshev.chebfit(xpos, smooth_floor, ncoeff - 1))


def set_neutral_hap(phase, hist) -> None:
    hap = phase.getHAPvalues(hist.name)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Scale"][:] = [1.0, False]


def build_project(output: Path, phases: list[tuple[str, Path]]) -> G2sc.G2Project:
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(XYE), str(INST), fmthint="xye"
    )
    hist.data["Limits"][1][:] = [9.90343322, 100.09455322]
    hist.data["Sample Parameters"]["Scale"][:] = [1.0, False]
    hist.data["Sample Parameters"]["DisplaceX"][:] = [0.0, False]
    hist.data["Sample Parameters"]["DisplaceY"][:] = [0.0, False]
    # GSAS-II uses micrometres for Bragg-Brentano specimen shift.
    hist.data["Sample Parameters"]["Shift"][:] = [-700.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"][:] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"][:] = [0.0, False]
    bkg = hist.data["Background"][0]
    coeffs = chebyshev_background(8)
    bkg[:] = ["chebyschev-1", False, len(coeffs), *coeffs]
    for name, cif in phases:
        phase = project.add_phase(
            str(cif), phasename=name, histograms=[hist], fmthint="CIF"
        )
        set_neutral_hap(phase, hist)
    project.save()
    return project


def set_all_flags_off(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for key, value in hist.data["Sample Parameters"].items():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        phase.clear_HAP_refinements(
            {"Scale": False, "Size": False, "Mustrain": False,
             "HStrain": False, "Pref.Ori.": False}
        )


def summary(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    out = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "residuals": copy.deepcopy(hist.data["data"][0]),
        "instrument": {
            key: value[1]
            for key, value in inst.items()
            if isinstance(value, list) and len(value) > 1
        },
        "sample": {
            key: value[0]
            for key, value in hist.data["Sample Parameters"].items()
            if isinstance(value, list) and len(value) == 2
        },
        "background": list(hist.data["Background"][0]),
        "phases": {},
    }
    try:
        mass = hist.ComputeMassFracs()
    except Exception as exc:
        mass = {"error": str(exc)}
    out["mass_fractions"] = mass
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": list(hap["Scale"]),
            "size": copy.deepcopy(hap["Size"]),
            "mustrain": copy.deepcopy(hap["Mustrain"]),
            "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
        }
    return out


def refine_and_log(project: G2sc.G2Project, label: str, log: list[dict]) -> None:
    project.data["Controls"]["data"]["max cyc"] = 12
    project.refine(makeBack=False)
    project.save()
    row = summary(project, label)
    log.append(row)
    print(json.dumps(row, indent=2, default=float))


def converge(project: G2sc.G2Project, label: str, log: list[dict], passes: int = 3) -> dict:
    previous = None
    for index in range(passes):
        refine_and_log(project, f"{label}_pass_{index + 1}", log)
        current = float(project.histogram(0).get_wR())
        if previous is not None and abs(previous - current) < 1.0e-4:
            break
        previous = current
    return summary(project, label)


def valid_common_profile(project: G2sc.G2Project) -> tuple[bool, str]:
    inst = project.histogram(0).data["Instrument Parameters"][0]
    for key in ("U", "W", "X"):
        value = float(inst[key][1])
        if not math.isfinite(value) or value < 0.0:
            return False, f"{key}={value} is negative or non-finite"
    for phase in project.phases():
        scale = float(phase.getHAPvalues(project.histogram(0).name)["Scale"][0])
        if not math.isfinite(scale) or scale <= 0.0:
            return False, f"{phase.name} scale={scale} is non-positive"
    return True, "ok"


def profile_trials(checkpoint: Path, output: Path, log: list[dict]) -> G2sc.G2Project:
    trials = [
        ("neutral", ()),
        ("W", ("W",)),
        ("X", ("X",)),
        ("U_W", ("U", "W")),
        ("W_X", ("W", "X")),
        ("U_W_X", ("U", "W", "X")),
    ]
    rows = []
    for name, terms in trials:
        trial_path = TMP / f"profile_{name}.gpx"
        project = G2sc.G2Project(str(checkpoint), newgpx=str(trial_path))
        set_all_flags_off(project)
        hist = project.histogram(0)
        hist.data["Background"][0][1] = True
        hist.data["Sample Parameters"]["Shift"][1] = True
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
            phase.set_HAP_refinements({"Scale": True})
        inst = hist.data["Instrument Parameters"][0]
        inst["U"][1] = 2.0
        inst["W"][1] = 16.0
        inst["X"][1] = 0.5
        for term in terms:
            inst[term][2] = True
        result = converge(project, f"profile_{name}", log, passes=3)
        valid, reason = valid_common_profile(project)
        rows.append(
            {
                "name": name,
                "terms": list(terms),
                "path": str(trial_path),
                "wR_percent": result["wR_percent"],
                "valid": valid,
                "reason": reason,
                "U": inst["U"][1],
                "W": inst["W"][1],
                "X": inst["X"][1],
            }
        )
    valid_rows = [row for row in rows if row["valid"]]
    if not valid_rows:
        raise RuntimeError(f"No valid common-profile trial: {rows}")
    winner = min(valid_rows, key=lambda row: row["wR_percent"])
    shutil.copyfile(winner["path"], output)
    (TMP / "profile_trials.json").write_text(
        json.dumps({"trials": rows, "winner": winner}, indent=2) + "\n"
    )
    return G2sc.G2Project(str(output))


def activate_base_flags(project: G2sc.G2Project) -> None:
    set_all_flags_off(project)
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    hist.data["Sample Parameters"]["Shift"][1] = True
    hist.data["Instrument Parameters"][0]["X"][2] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})


def activate_phase_terms(phase, terms: set[str]) -> None:
    if "size" in terms:
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}
        )
    if "strain" in terms:
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )


def reset_phase_broadening(phase, hist) -> None:
    hap = phase.getHAPvalues(hist.name)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])


def valid_phase_trial(project: G2sc.G2Project, phase_name: str,
                      terms: set[str]) -> tuple[bool, str]:
    valid, reason = valid_common_profile(project)
    if not valid:
        return valid, reason
    hist = project.histogram(0)
    hap = project.phase(phase_name).getHAPvalues(hist.name)
    if "size" in terms:
        value = float(hap["Size"][1][0])
        if not math.isfinite(value) or value <= 0.0:
            return False, f"size={value} is non-positive or non-finite"
        if value >= 9.95:
            return False, f"size={value} collapsed to the neutral boundary"
    if "strain" in terms:
        value = float(hap["Mustrain"][1][0])
        if not math.isfinite(value) or value < 0.0:
            return False, f"mustrain={value} is negative or non-finite"
        if value <= 1.0e-4:
            return False, f"mustrain={value} collapsed to zero"
    return True, "ok"


def challenge_one_phase(checkpoint: Path, phase_name: str,
                        retained: dict[str, set[str]], loop_index: int,
                        log: list[dict]) -> tuple[Path, set[str], list[dict]]:
    variants = [
        ("neutral", set()),
        ("size", {"size"}),
        ("strain", {"strain"}),
        ("size_strain", {"size", "strain"}),
    ]
    rows = []
    safe_name = phase_name.replace(" ", "_")
    for variant_name, terms in variants:
        trial_path = TMP / f"broad_L{loop_index}_{safe_name}_{variant_name}.gpx"
        project = G2sc.G2Project(str(checkpoint), newgpx=str(trial_path))
        activate_base_flags(project)
        hist = project.histogram(0)
        target = project.phase(phase_name)
        reset_phase_broadening(target, hist)
        for phase in project.phases():
            if phase.name != phase_name:
                activate_phase_terms(phase, retained[phase.name])
        activate_phase_terms(target, terms)
        result = converge(
            project,
            f"broad_L{loop_index}_{safe_name}_{variant_name}",
            log,
            passes=3,
        )
        valid, reason = valid_phase_trial(project, phase_name, terms)
        hap = target.getHAPvalues(hist.name)
        rows.append(
            {
                "phase": phase_name,
                "variant": variant_name,
                "terms": sorted(terms),
                "path": str(trial_path),
                "wR_percent": result["wR_percent"],
                "valid": valid,
                "reason": reason,
                "size_um": hap["Size"][1][0],
                "mustrain_micro": hap["Mustrain"][1][0],
                "mass_fractions": result["mass_fractions"],
            }
        )
    valid_rows = [row for row in rows if row["valid"]]
    if not valid_rows:
        raise RuntimeError(f"No valid broadening trial for {phase_name}: {rows}")
    winner = min(valid_rows, key=lambda row: row["wR_percent"])
    # Do not retain complexity for a numerically negligible gain.
    neutral = next(row for row in rows if row["variant"] == "neutral")
    if winner["terms"] and neutral["wR_percent"] - winner["wR_percent"] < 0.01:
        winner = neutral
    accepted = TMP / f"broad_L{loop_index}_{safe_name}_accepted.gpx"
    shutil.copyfile(winner["path"], accepted)
    return accepted, set(winner["terms"]), rows


def broadening_loop(input_project: Path, output: Path) -> None:
    project = G2sc.G2Project(str(input_project))
    names = [phase.name for phase in project.phases()]
    retained = {name: set() for name in names}
    checkpoint = input_project
    log: list[dict] = []
    all_rows = []
    loop_summaries = []
    for loop_index in range(1, 3):
        before = {name: sorted(terms) for name, terms in retained.items()}
        for phase_name in names:
            checkpoint, terms, rows = challenge_one_phase(
                checkpoint, phase_name, retained, loop_index, log
            )
            retained[phase_name] = terms
            all_rows.extend(rows)
        after = {name: sorted(terms) for name, terms in retained.items()}
        loop_summaries.append({"loop": loop_index, "before": before, "after": after})
    shutil.copyfile(checkpoint, output)
    final_project = G2sc.G2Project(str(output))
    (TMP / "broadening_trials.json").write_text(
        json.dumps(
            {
                "trials": all_rows,
                "loops": loop_summaries,
                "retained": {name: sorted(terms) for name, terms in retained.items()},
                "final": summary(final_project, "broadening_selected"),
            },
            indent=2,
            default=float,
        ) + "\n"
    )
    (TMP / "broadening_log.json").write_text(
        json.dumps(log, indent=2, default=float) + "\n"
    )


def activate_shared_state(project: G2sc.G2Project, state: dict) -> None:
    activate_base_flags(project)
    # Terms retained by the stable three-phase broadening loop must remain
    # active while shared intensity corrections are challenged.
    if any(phase.name == "Pb3O4" for phase in project.phases()):
        project.phase("Pb3O4").set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}
        )
    hist = project.histogram(0)
    bkg = hist.data["Background"][0]
    target_n = int(state["background_coefficients"])
    coeffs = list(bkg[3:])
    if target_n > len(coeffs):
        coeffs += [0.0] * (target_n - len(coeffs))
    else:
        coeffs = coeffs[:target_n]
    bkg[:] = ["chebyschev-1", True, target_n, *coeffs]
    if state.get("polarization", False):
        hist.data["Instrument Parameters"][0]["Polariz."][2] = True
    else:
        hist.data["Instrument Parameters"][0]["Polariz."][1] = 0.5
    if state.get("roughness_B", False):
        # A and B are strongly correlated here. The lower-dimensional model
        # fixes A at its neutral boundary and challenges B alone.
        hist.data["Sample Parameters"]["SurfRoughA"][:] = [0.0, False]
        hist.data["Sample Parameters"]["SurfRoughB"][1] = True
    else:
        hist.data["Sample Parameters"]["SurfRoughA"][:] = [0.0, False]
        hist.data["Sample Parameters"]["SurfRoughB"][:] = [0.0, False]


def valid_shared_trial(project: G2sc.G2Project, state: dict) -> tuple[bool, str]:
    valid, reason = valid_common_profile(project)
    if not valid:
        return valid, reason
    hist = project.histogram(0)
    if any(phase.name == "Pb3O4" for phase in project.phases()):
        size = float(project.phase("Pb3O4").getHAPvalues(hist.name)["Size"][1][0])
        if not math.isfinite(size) or size <= 0.0 or size >= 9.95:
            return False, f"Pb3O4 size={size} is nonphysical or collapsed"
    if state.get("polarization", False):
        value = float(hist.data["Instrument Parameters"][0]["Polariz."][1])
        if not math.isfinite(value) or not 0.0 <= value <= 1.0:
            return False, f"polarization={value} is outside [0,1]"
    if state.get("roughness_B", False):
        a = float(hist.data["Sample Parameters"]["SurfRoughA"][0])
        b = float(hist.data["Sample Parameters"]["SurfRoughB"][0])
        if not (math.isfinite(a) and math.isfinite(b)):
            return False, "roughness is non-finite"
        if not 0.0 <= a <= 1.0 or b < 0.0:
            return False, f"roughness A={a}, B={b} is outside physical bounds"
        if b < 1.0e-5:
            return False, f"roughness B={b} collapsed to zero"
    return True, "ok"


def shared_trial(checkpoint: Path, trial_path: Path, state: dict,
                 label: str, log: list[dict], rough_seed=None) -> dict:
    project = G2sc.G2Project(str(checkpoint), newgpx=str(trial_path))
    activate_shared_state(project, state)
    hist = project.histogram(0)
    if rough_seed is not None:
        hist.data["Sample Parameters"]["SurfRoughA"][0] = 0.0
        hist.data["Sample Parameters"]["SurfRoughB"][0] = float(rough_seed)
    result = converge(project, label, log, passes=3)
    valid, reason = valid_shared_trial(project, state)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    return {
        "label": label,
        "path": str(trial_path),
        "state": copy.deepcopy(state),
        "wR_percent": result["wR_percent"],
        "valid": valid,
        "reason": reason,
        "polarization": inst["Polariz."][1],
        "roughness_A": sample["SurfRoughA"][0],
        "roughness_B": sample["SurfRoughB"][0],
        "mass_fractions": result["mass_fractions"],
    }


def shared_intensity_loop(input_project: Path, output: Path) -> None:
    checkpoint = input_project
    state = {
        "background_coefficients": 8,
        "polarization": False,
        "roughness_B": False,
    }
    log: list[dict] = []
    rows = []
    loop_states = []
    for loop_index in range(1, 4):
        # Smooth-background coordinate.
        bg_rows = []
        for count in (6, 8, 10):
            trial_state = copy.deepcopy(state)
            trial_state["background_coefficients"] = count
            path = TMP / f"shared_L{loop_index}_bg{count}.gpx"
            row = shared_trial(
                checkpoint, path, trial_state, f"shared_L{loop_index}_bg{count}", log
            )
            bg_rows.append(row)
            rows.append(row)
        valid_bg = [row for row in bg_rows if row["valid"]]
        winner = min(valid_bg, key=lambda row: row["wR_percent"])
        current = next(
            row for row in bg_rows
            if row["state"]["background_coefficients"] == state["background_coefficients"]
        )
        if (winner["state"]["background_coefficients"] >
                current["state"]["background_coefficients"] and
                current["wR_percent"] - winner["wR_percent"] < 0.01):
            winner = current
        checkpoint = Path(winner["path"])
        state = copy.deepcopy(winner["state"])

        # Polarization coordinate.
        pol_rows = []
        for refine in (False, True):
            trial_state = copy.deepcopy(state)
            trial_state["polarization"] = refine
            path = TMP / f"shared_L{loop_index}_polar_{int(refine)}.gpx"
            row = shared_trial(
                checkpoint, path, trial_state,
                f"shared_L{loop_index}_polar_{int(refine)}", log
            )
            pol_rows.append(row)
            rows.append(row)
        valid_pol = [row for row in pol_rows if row["valid"]]
        winner = min(valid_pol, key=lambda row: row["wR_percent"])
        fixed = pol_rows[0]
        if winner["state"]["polarization"] and fixed["wR_percent"] - winner["wR_percent"] < 0.01:
            winner = fixed
        checkpoint = Path(winner["path"])
        state = copy.deepcopy(winner["state"])

        # Suortti roughness coordinate. Two physical nonzero seeds are used
        # because both derivatives vanish at the exact neutral point.
        rough_rows = []
        fixed_state = copy.deepcopy(state)
        fixed_state["roughness_B"] = False
        fixed_path = TMP / f"shared_L{loop_index}_rough_0.gpx"
        fixed = shared_trial(
            checkpoint, fixed_path, fixed_state,
            f"shared_L{loop_index}_rough_0", log
        )
        rough_rows.append(fixed)
        rows.append(fixed)
        for seed_index, seed in enumerate((0.10, 0.03), start=1):
            trial_state = copy.deepcopy(state)
            trial_state["roughness_B"] = True
            path = TMP / f"shared_L{loop_index}_rough_{seed_index}.gpx"
            row = shared_trial(
                checkpoint, path, trial_state,
                f"shared_L{loop_index}_rough_{seed_index}", log,
                rough_seed=seed,
            )
            rough_rows.append(row)
            rows.append(row)
        valid_rough = [row for row in rough_rows if row["valid"]]
        winner = min(valid_rough, key=lambda row: row["wR_percent"])
        if (winner["state"]["roughness_B"] and fixed["valid"] and
                fixed["wR_percent"] - winner["wR_percent"] < 0.01):
            winner = fixed
        checkpoint = Path(winner["path"])
        state = copy.deepcopy(winner["state"])
        loop_states.append({"loop": loop_index, "state": copy.deepcopy(state)})

    shutil.copyfile(checkpoint, output)
    final_project = G2sc.G2Project(str(output))
    final_valid, final_reason = valid_shared_trial(final_project, state)
    if not final_valid:
        raise RuntimeError(f"Selected shared-intensity model is invalid: {final_reason}")
    (TMP / "shared_intensity_trials.json").write_text(
        json.dumps(
            {
                "trials": rows,
                "loops": loop_states,
                "retained": state,
                "final": summary(final_project, "shared_intensity_selected"),
            },
            indent=2,
            default=float,
        ) + "\n"
    )
    (TMP / "shared_intensity_log.json").write_text(
        json.dumps(log, indent=2, default=float) + "\n"
    )


def activate_final_nuisance(project: G2sc.G2Project) -> None:
    state = {
        "background_coefficients": 8,
        "polarization": True,
        "roughness_B": False,
    }
    activate_shared_state(project, state)


def set_texture(phase, hist, axis, refine: bool) -> None:
    pref = phase.getHAPvalues(hist.name)["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = bool(refine)
    pref[3] = [int(value) for value in axis]


def texture_trial(checkpoint: Path, trial_path: Path, phase_name: str, axis,
                  retained: dict, label: str, log: list[dict]) -> dict:
    project = G2sc.G2Project(str(checkpoint), newgpx=str(trial_path))
    activate_final_nuisance(project)
    hist = project.histogram(0)
    for phase in project.phases():
        if phase.name in retained:
            retained_axis = retained[phase.name]
            pref = phase.getHAPvalues(hist.name)["Pref.Ori."]
            pref[0] = "MD"
            pref[2] = True
            pref[3] = list(retained_axis)
    target = project.phase(phase_name)
    set_texture(target, hist, axis, axis != (0, 0, 0))
    result = converge(project, label, log, passes=3)
    pref = target.getHAPvalues(hist.name)["Pref.Ori."]
    valid, reason = valid_shared_trial(
        project,
        {"background_coefficients": 8,
         "polarization": True, "roughness_B": False},
    )
    ratio = float(pref[1])
    if valid and axis != (0, 0, 0):
        if not math.isfinite(ratio) or not 0.2 <= ratio <= 5.0:
            valid, reason = False, f"March ratio={ratio} outside [0.2,5]"
        elif abs(ratio - 1.0) < 0.005:
            valid, reason = False, f"March ratio={ratio} collapsed to neutral"
    return {
        "label": label,
        "phase": phase_name,
        "axis": list(axis),
        "path": str(trial_path),
        "wR_percent": result["wR_percent"],
        "valid": valid,
        "reason": reason,
        "march_ratio": ratio,
        "mass_fractions": result["mass_fractions"],
    }


def texture_loop(input_project: Path, output: Path) -> None:
    project = G2sc.G2Project(str(input_project))
    names = [phase.name for phase in project.phases()]
    axes = {
        "PbWO4_scheelite": [(0, 0, 0), (0, 0, 1), (1, 0, 0),
                             (1, 1, 0), (1, 1, 2)],
        "WO3_monoclinic": [(0, 0, 0), (1, 0, 0), (0, 1, 0),
                            (0, 0, 1), (1, 0, 1), (1, 1, 0), (0, 1, 1)],
        "Pb3O4": [(0, 0, 0), (0, 0, 1), (1, 0, 0),
                   (1, 1, 0), (1, 0, 1)],
    }
    checkpoint = input_project
    retained: dict[str, tuple[int, int, int]] = {}
    rows = []
    log: list[dict] = []
    loops = []
    for loop_index in range(1, 3):
        before = {name: list(axis) for name, axis in retained.items()}
        for phase_name in names:
            phase_rows = []
            for axis in axes[phase_name]:
                suffix = "neutral" if axis == (0, 0, 0) else "".join(map(str, axis))
                path = TMP / f"texture_L{loop_index}_{phase_name}_{suffix}.gpx"
                row = texture_trial(
                    checkpoint, path, phase_name, axis, retained,
                    f"texture_L{loop_index}_{phase_name}_{suffix}", log,
                )
                phase_rows.append(row)
                rows.append(row)
            valid_rows = [row for row in phase_rows if row["valid"]]
            winner = min(valid_rows, key=lambda row: row["wR_percent"])
            neutral = next(row for row in phase_rows if row["axis"] == [0, 0, 0])
            if winner["axis"] != [0, 0, 0] and neutral["wR_percent"] - winner["wR_percent"] < 0.02:
                winner = neutral
            checkpoint = Path(winner["path"])
            if winner["axis"] == [0, 0, 0]:
                retained.pop(phase_name, None)
            else:
                retained[phase_name] = tuple(winner["axis"])
        after = {name: list(axis) for name, axis in retained.items()}
        loops.append({"loop": loop_index, "before": before, "after": after})
    shutil.copyfile(checkpoint, output)
    final_project = G2sc.G2Project(str(output))
    (TMP / "texture_trials.json").write_text(
        json.dumps(
            {
                "trials": rows,
                "loops": loops,
                "retained": {name: list(axis) for name, axis in retained.items()},
                "final": summary(final_project, "texture_selected"),
            },
            indent=2,
            default=float,
        ) + "\n"
    )
    (TMP / "texture_log.json").write_text(
        json.dumps(log, indent=2, default=float) + "\n"
    )


def activate_source_base(project: G2sc.G2Project, profile_terms=()) -> None:
    set_all_flags_off(project)
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    hist.data["Sample Parameters"]["Shift"][1] = True
    for term in profile_terms:
        hist.data["Instrument Parameters"][0][term][2] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})


def source_fit(tag: str, lead_cif: Path, wo3_cif: Path,
               health: dict[str, str]) -> dict:
    log: list[dict] = []
    initial = TMP / f"source_{tag}_initial.gpx"
    project = build_project(
        initial,
        [("lead_tungstate", lead_cif), ("tungsten_oxide", wo3_cif)],
    )
    hist = project.histogram(0)
    set_all_flags_off(project)
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    converge(project, f"source_{tag}_scales", log, passes=2)
    hist.data["Sample Parameters"]["Shift"][1] = True
    converge(project, f"source_{tag}_shift", log, passes=2)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    converge(project, f"source_{tag}_cells", log, passes=3)
    cell_checkpoint = TMP / f"source_{tag}_cell_checkpoint.gpx"
    project.save(str(cell_checkpoint))

    profile_rows = []
    for profile_name, terms in (("neutral", ()), ("W", ("W",)), ("X", ("X",))):
        path = TMP / f"source_{tag}_profile_{profile_name}.gpx"
        trial = G2sc.G2Project(str(cell_checkpoint), newgpx=str(path))
        activate_source_base(trial, terms)
        result = converge(
            trial, f"source_{tag}_profile_{profile_name}", log, passes=3
        )
        valid, reason = valid_common_profile(trial)
        shift = trial.histogram(0).data["Sample Parameters"]["Shift"][0]
        if valid and not -2000.0 <= shift <= 500.0:
            valid, reason = False, f"sample shift={shift} is unphysical"
        inst = trial.histogram(0).data["Instrument Parameters"][0]
        profile_rows.append(
            {
                "name": profile_name,
                "terms": list(terms),
                "path": str(path),
                "wR_percent": result["wR_percent"],
                "valid": valid,
                "reason": reason,
                "U": inst["U"][1], "W": inst["W"][1], "X": inst["X"][1],
            }
        )
    valid_profiles = [row for row in profile_rows if row["valid"]]
    if not valid_profiles:
        return {
            "tag": tag, "valid": False, "reason": "no valid profile",
            "lead_cif": str(lead_cif), "wo3_cif": str(wo3_cif),
            "profile_trials": profile_rows,
        }
    profile_winner = min(valid_profiles, key=lambda row: row["wR_percent"])

    shared_path = TMP / f"source_{tag}_shared.gpx"
    project = G2sc.G2Project(profile_winner["path"], newgpx=str(shared_path))
    activate_source_base(project, profile_winner["terms"])
    hist = project.histogram(0)
    bkg = hist.data["Background"][0]
    coeffs = list(bkg[3:]) + [0.0, 0.0]
    bkg[:] = ["chebyschev-1", True, 10, *coeffs[:10]]
    hist.data["Sample Parameters"]["SurfRoughA"][:] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"][:] = [0.036, True]
    hist.data["Instrument Parameters"][0]["Polariz."][:] = [0.5, 0.5, False]
    converge(project, f"source_{tag}_roughness", log, passes=3)
    hist.data["Instrument Parameters"][0]["Polariz."][2] = True
    final = converge(project, f"source_{tag}_polarization", log, passes=3)
    project.save(str(shared_path))

    valid, reason = valid_common_profile(project)
    polar = float(hist.data["Instrument Parameters"][0]["Polariz."][1])
    rough_b = float(hist.data["Sample Parameters"]["SurfRoughB"][0])
    shift = float(hist.data["Sample Parameters"]["Shift"][0])
    if valid and not 0.0 <= polar <= 1.0:
        valid, reason = False, f"polarization={polar} outside [0,1]"
    if valid and rough_b < 0.0:
        valid, reason = False, f"roughness B={rough_b} is negative"
    if valid and not -2000.0 <= shift <= 500.0:
        valid, reason = False, f"sample shift={shift} is unphysical"
    return {
        "tag": tag,
        "valid": valid,
        "reason": reason,
        "lead_cif": str(lead_cif),
        "lead_health": health[lead_cif.name],
        "wo3_cif": str(wo3_cif),
        "wo3_health": health[wo3_cif.name],
        "project": str(shared_path),
        "profile_trials": profile_rows,
        "profile_winner": profile_winner,
        "wR_percent": final["wR_percent"],
        "mass_fractions": final["mass_fractions"],
        "polarization": polar,
        "roughness_B": rough_b,
        "sample_shift_um": shift,
        "phases": final["phases"],
    }


def source_competition(output: Path) -> None:
    health_rows = json.loads((TMP / "serious_source_health.json").read_text())
    health = {Path(row["path"]).name: row["status"] for row in health_rows}
    pb_ref = TMP / "PbWO4_9009811.cif"
    wo_ref = TMP / "WO3_2311041.cif"
    candidates = [
        ("reference", pb_ref, wo_ref),
        ("pb_old_scheelite", TMP / "PbWO4_1527935.cif", wo_ref),
        ("pb_raspite", TMP / "PbWO4_raspite_9007617.cif", wo_ref),
        ("pb_defect", TMP / "Pb7W8O28p8_9016035.cif", wo_ref),
        ("wo_old_monoclinic", pb_ref, TMP / "WO3_1528915.cif"),
        ("wo_halfcell", pb_ref, TMP / "WO3_1563541.cif"),
        ("wo_triclinic", pb_ref, TMP / "WO3_triclinic_2106293.cif"),
    ]
    rows = []
    for tag, lead, wo3 in candidates:
        rows.append(source_fit(tag, lead, wo3, health))
    valid = [row for row in rows if row.get("valid")]
    winner = min(valid, key=lambda row: row["wR_percent"])
    shutil.copyfile(winner["project"], output)
    (TMP / "source_competition.json").write_text(
        json.dumps({"candidates": rows, "numerical_winner": winner["tag"]},
                   indent=2, default=float) + "\n"
    )


def baseline(output: Path, phase_specs: list[tuple[str, Path]]) -> None:
    log: list[dict] = []
    project = build_project(output, phase_specs)
    hist = project.histogram(0)

    set_all_flags_off(project)
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    converge(project, "background_scales", log, passes=2)

    hist.data["Sample Parameters"]["Shift"][1] = True
    converge(project, "plus_sample_shift", log, passes=2)

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    converge(project, "plus_cells", log, passes=3)
    checkpoint = TMP / f"{output.stem}_cell_checkpoint.gpx"
    project.save(str(checkpoint))

    project = profile_trials(checkpoint, output, log)
    log.append(summary(project, "selected_common_profile"))

    (TMP / f"{output.stem}_baseline_log.json").write_text(
        json.dumps(log, indent=2, default=float) + "\n"
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=TMP / "baseline.gpx")
    parser.add_argument(
        "--mode", choices=("baseline", "broadening", "shared", "texture", "sources"),
        default="baseline"
    )
    parser.add_argument("--input-project", type=Path)
    args = parser.parse_args()
    if args.mode == "baseline":
        baseline(
            args.output,
            [
                ("PbWO4_scheelite", TMP / "PbWO4_9009811.cif"),
                ("WO3_monoclinic", TMP / "WO3_2311041.cif"),
            ],
        )
    elif args.mode == "broadening":
        if args.input_project is None:
            parser.error("--input-project is required for broadening mode")
        broadening_loop(args.input_project, args.output)
    elif args.mode == "shared":
        if args.input_project is None:
            parser.error("--input-project is required for shared mode")
        shared_intensity_loop(args.input_project, args.output)
    elif args.mode == "texture":
        if args.input_project is None:
            parser.error("--input-project is required for texture mode")
        texture_loop(args.input_project, args.output)
    else:
        source_competition(args.output)


if __name__ == "__main__":
    main()
