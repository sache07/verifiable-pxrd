#!/usr/bin/env python3
"""One complete post-texture coordinate-descent replay for the final model."""

from __future__ import annotations

import copy
import json
import math
import shutil
from pathlib import Path

import refine_workflow as rw


TMP = Path(".tmp")
START = TMP / "four_texture_complete.gpx"
OUTPUT = TMP / "four_coordinate_final.gpx"

UNIAXIAL_SIZE_AXES = {
    "PbWO4_scheelite": [0, 0, 1],
    "WO3_monoclinic": [0, 1, 0],
    "Pb3O4": [0, 0, 1],
    "Pb3WO6_analogue": [0, 1, 0],
}


def activate(project, state, *, reset_profile=False, reset_broad=None,
             broad_seed=None, reset_texture=None, rough_seed=None):
    rw.set_all_flags_off(project)
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    bkg = hist.data["Background"][0]
    count = int(state["background"])
    coeff = list(bkg[3:])
    coeff = (coeff + [0.0] * max(0, count - len(coeff)))[:count]
    bkg[:] = ["chebyschev-1", True, count, *coeff]
    hist.data["Sample Parameters"]["Shift"][1] = True

    inst = hist.data["Instrument Parameters"][0]
    if reset_profile:
        inst["U"][1], inst["W"][1], inst["X"][1] = 2.0, 16.0, 0.5
    for term in state["profile"]:
        inst[term][2] = True
    if state["polarization"]:
        inst["Polariz."][2] = True
    else:
        inst["Polariz."][1] = 0.5

    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"][:] = [0.0, False]
    if state["roughness_B"]:
        sample["SurfRoughB"][1] = True
        if rough_seed is not None:
            sample["SurfRoughB"][0] = float(rough_seed)
    else:
        sample["SurfRoughB"][:] = [0.0, False]

    reset_broad = set(reset_broad or ())
    broad_seed = broad_seed or {}
    reset_texture = set(reset_texture or ())
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        if phase.name in reset_broad:
            rw.reset_phase_broadening(phase, hist)
        seeds = broad_seed.get(phase.name, {})
        hap = phase.getHAPvalues(hist.name)
        if "size" in seeds:
            hap["Size"][1][0] = float(seeds["size"])
        if "strain" in seeds:
            hap["Mustrain"][1][0] = float(seeds["strain"])
        terms = set(state["broadening"].get(phase.name, ()))
        if "size_uniaxial" in terms:
            hap["Size"][0] = "uniaxial"
            if "size_eq" in seeds:
                hap["Size"][1][0] = float(seeds["size_eq"])
            if "size_ax" in seeds:
                hap["Size"][1][1] = float(seeds["size_ax"])
            hap["Size"][2][:] = [True, True, False]
            hap["Size"][3] = list(UNIAXIAL_SIZE_AXES[phase.name])
        else:
            rw.activate_phase_terms(phase, terms)

        pref = phase.getHAPvalues(hist.name)["Pref.Ori."]
        if phase.name in reset_texture:
            pref[1] = 1.0
        if phase.name in state["texture"]:
            pref[0] = "MD"
            pref[2] = True
            pref[3] = list(state["texture"][phase.name])
        else:
            pref[0] = "MD"
            pref[1] = 1.0
            pref[2] = False
            pref[3] = [0, 0, 1]


def valid(project, state, *, require_texture=None):
    ok, reason = rw.valid_common_profile(project)
    if not ok:
        return ok, reason
    hist = project.histogram(0)
    shift = float(hist.data["Sample Parameters"]["Shift"][0])
    if not -2000.0 <= shift <= 500.0:
        return False, f"sample shift={shift} outside physical range"
    polar = float(hist.data["Instrument Parameters"][0]["Polariz."][1])
    if state["polarization"] and not (math.isfinite(polar) and 0.0 <= polar <= 1.0):
        return False, f"polarization={polar} outside [0,1]"
    b = float(hist.data["Sample Parameters"]["SurfRoughB"][0])
    if state["roughness_B"] and (not math.isfinite(b) or b <= 1e-5):
        return False, f"roughness B={b} is negative or collapsed"
    for phase_name, terms in state["broadening"].items():
        hap = project.phase(phase_name).getHAPvalues(hist.name)
        if "size_uniaxial" in terms:
            values = [float(v) for v in hap["Size"][1][:2]]
            if not all(math.isfinite(v) and 0.0 < v < 9.95 for v in values):
                return False, f"{phase_name} uniaxial sizes={values} nonphysical or collapsed"
            if max(values) / min(values) > 5.0:
                return False, f"{phase_name} uniaxial size ratio is unstable"
        if "size" in terms:
            size = float(hap["Size"][1][0])
            if not math.isfinite(size) or size <= 0.0 or size >= 9.95:
                return False, f"{phase_name} size={size} nonphysical or collapsed"
        if "strain" in terms:
            strain = float(hap["Mustrain"][1][0])
            if not math.isfinite(strain) or strain <= 1e-4:
                return False, f"{phase_name} strain={strain} nonphysical or collapsed"
    for phase_name in state["texture"]:
        ratio = float(project.phase(phase_name).getHAPvalues(hist.name)["Pref.Ori."][1])
        if not math.isfinite(ratio) or not 0.2 <= ratio <= 5.0:
            return False, f"{phase_name} March ratio={ratio} outside [0.2,5]"
        if require_texture == phase_name and abs(ratio - 1.0) < 0.005:
            return False, f"{phase_name} March ratio={ratio} collapsed"
    return True, "ok"


def run_trial(checkpoint, tag, state, *, reset_profile=False,
              reset_broad=None, broad_seed=None, reset_texture=None, rough_seed=None,
              require_texture=None, passes=1):
    path = TMP / f"finalcoord_{tag}.gpx"
    project = rw.G2sc.G2Project(str(checkpoint), newgpx=str(path))
    activate(project, state, reset_profile=reset_profile,
             reset_broad=reset_broad, broad_seed=broad_seed,
             reset_texture=reset_texture,
             rough_seed=rough_seed)
    log = []
    result = rw.converge(project, f"finalcoord_{tag}", log, passes=passes)
    ok, reason = valid(project, state, require_texture=require_texture)
    hist = project.histogram(0)
    return {
        "tag": tag,
        "path": str(path),
        "state": copy.deepcopy(state),
        "wR_percent": result["wR_percent"],
        "valid": ok,
        "reason": reason,
        "mass_fractions": result["mass_fractions"],
        "polarization": hist.data["Instrument Parameters"][0]["Polariz."][1],
        "roughness_B": hist.data["Sample Parameters"]["SurfRoughB"][0],
        "summary": result,
    }


def choose(rows, neutral, gain=0.0):
    candidates = [row for row in rows if row["valid"]]
    if not candidates:
        raise RuntimeError(f"No valid trial among {rows}")
    winner = min(candidates, key=lambda row: row["wR_percent"])
    if winner is not neutral and neutral["valid"]:
        if neutral["wR_percent"] - winner["wR_percent"] < gain:
            winner = neutral
    return winner


def main():
    checkpoint = START
    state = {
        "profile": ["W", "X"],
        "background": 10,
        "polarization": True,
        "roughness_B": False,
        "broadening": {
            "PbWO4_scheelite": ["size"],
            "Pb3O4": ["size"],
            "Pb3WO6_analogue": ["strain"],
        },
        "texture": {"Pb3WO6_analogue": [1, 0, 1]},
    }
    initial_state = copy.deepcopy(state)
    rows = []
    selected = []

    # Common profile coordinate, reset to the same neutral U/W/X values.
    profile_variants = [
        ("neutral", []), ("W", ["W"]), ("X", ["X"]),
        ("U_W", ["U", "W"]), ("W_X", ["W", "X"]),
        ("U_W_X", ["U", "W", "X"]),
    ]
    group = []
    for name, terms in profile_variants:
        trial_state = copy.deepcopy(state)
        trial_state["profile"] = terms
        row = run_trial(checkpoint, f"profile_{name}", trial_state,
                        reset_profile=True)
        rows.append(row); group.append(row)
    neutral = group[0]
    winner = choose(group, neutral, gain=0.01)
    checkpoint = Path(winner["path"])
    state = copy.deepcopy(winner["state"])
    selected.append({"coordinate": "profile", "winner": winner["tag"]})

    # Phase-specific broadening coordinate.
    names = [p.name for p in rw.G2sc.G2Project(str(checkpoint)).phases()]
    for phase_name in names:
        current_terms = set(state["broadening"].get(phase_name, ()))
        current_project = rw.G2sc.G2Project(str(checkpoint))
        current_hap = current_project.phase(phase_name).getHAPvalues(
            current_project.histogram(0).name
        )
        current_size = float(current_hap["Size"][1][0])
        if not (0.0 < current_size < 9.95):
            current_size = 0.05
        current_strain = float(current_hap["Mustrain"][1][0])
        if current_strain <= 1.0e-4:
            current_strain = 1000.0
        group = []
        current_eq = float(current_hap["Size"][1][0])
        current_ax = float(current_hap["Size"][1][1])
        if not (0.0 < current_eq < 9.95):
            current_eq = current_size
        if not (0.0 < current_ax < 9.95):
            current_ax = current_size
        for label, terms in (
            ("neutral", []), ("size", ["size"]),
            ("size_uniaxial", ["size_uniaxial"]),
            ("strain", ["strain"]), ("size_strain", ["size", "strain"]),
        ):
            trial_state = copy.deepcopy(state)
            if terms:
                trial_state["broadening"][phase_name] = terms
            else:
                trial_state["broadening"].pop(phase_name, None)
            candidate_terms = set(terms)
            preserve = bool(candidate_terms) and candidate_terms == current_terms
            seeds = {}
            if not preserve:
                if "size" in candidate_terms:
                    seeds["size"] = current_size
                if "size_uniaxial" in candidate_terms:
                    seeds["size_eq"] = current_eq
                    seeds["size_ax"] = current_ax
                if "strain" in candidate_terms:
                    seeds["strain"] = current_strain
            row = run_trial(
                checkpoint, f"broad_{phase_name}_{label}", trial_state,
                reset_broad=[] if preserve else [phase_name],
                broad_seed={phase_name: seeds} if seeds else None,
            )
            rows.append(row); group.append(row)
        neutral = group[0]
        winner = choose(group, neutral, gain=0.01)
        isotropic = group[1]
        uniaxial = group[2]
        if (winner is uniaxial and isotropic["valid"] and
                isotropic["wR_percent"] - uniaxial["wR_percent"] < 0.01):
            winner = isotropic
        checkpoint = Path(winner["path"])
        state = copy.deepcopy(winner["state"])
        selected.append({"coordinate": f"broadening:{phase_name}",
                         "winner": winner["tag"]})

    # Shared intensity coordinates.
    group = []
    for count in (6, 8, 10):
        trial_state = copy.deepcopy(state); trial_state["background"] = count
        row = run_trial(checkpoint, f"background_{count}", trial_state)
        rows.append(row); group.append(row)
    current = next(r for r in group if r["state"]["background"] == state["background"])
    winner = min((r for r in group if r["valid"]), key=lambda r: r["wR_percent"])
    if winner["state"]["background"] > current["state"]["background"] and \
            current["wR_percent"] - winner["wR_percent"] < 0.01:
        winner = current
    checkpoint = Path(winner["path"]); state = copy.deepcopy(winner["state"])
    selected.append({"coordinate": "background", "winner": winner["tag"]})

    group = []
    for refine in (False, True):
        trial_state = copy.deepcopy(state); trial_state["polarization"] = refine
        row = run_trial(checkpoint, f"polarization_{int(refine)}", trial_state)
        rows.append(row); group.append(row)
    fixed = group[0]
    winner = choose(group, fixed, gain=0.01)
    checkpoint = Path(winner["path"]); state = copy.deepcopy(winner["state"])
    selected.append({"coordinate": "polarization", "winner": winner["tag"]})

    group = []
    trial_state = copy.deepcopy(state); trial_state["roughness_B"] = False
    fixed = run_trial(checkpoint, "roughness_0", trial_state)
    rows.append(fixed); group.append(fixed)
    for i, seed in enumerate((0.03, 0.10), 1):
        trial_state = copy.deepcopy(state); trial_state["roughness_B"] = True
        row = run_trial(checkpoint, f"roughness_{i}", trial_state,
                        rough_seed=seed)
        rows.append(row); group.append(row)
    winner = choose(group, fixed, gain=0.01)
    checkpoint = Path(winner["path"]); state = copy.deepcopy(winner["state"])
    selected.append({"coordinate": "roughness", "winner": winner["tag"]})

    # Symmetry-compatible low-index March-Dollase axes.
    axes = {
        "PbWO4_scheelite": [(0, 0, 0), (0, 0, 1), (1, 0, 0),
                             (1, 1, 0), (1, 1, 2)],
        "WO3_monoclinic": [(0, 0, 0), (1, 0, 0), (0, 1, 0),
                            (0, 0, 1), (1, 0, 1), (1, 1, 0), (0, 1, 1)],
        "Pb3O4": [(0, 0, 0), (0, 0, 1), (1, 0, 0),
                   (1, 1, 0), (1, 0, 1)],
        "Pb3WO6_analogue": [(0, 0, 0), (1, 0, 0), (0, 1, 0),
                             (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1)],
    }
    for phase_name in names:
        texture_reference = rw.G2sc.G2Project(str(checkpoint))
        reference_hist = texture_reference.histogram(0)
        reference_fraction = float(
            reference_hist.ComputeMassFracs()[phase_name][0]
        )
        reference_cell = texture_reference.phase(phase_name).get_cell()
        group = []
        for axis in axes[phase_name]:
            trial_state = copy.deepcopy(state)
            if axis == (0, 0, 0):
                trial_state["texture"].pop(phase_name, None)
                suffix = "neutral"
                required = None
            else:
                trial_state["texture"][phase_name] = list(axis)
                suffix = "".join(map(str, axis))
                required = phase_name
            row = run_trial(
                checkpoint, f"texture_{phase_name}_{suffix}", trial_state,
                reset_texture=[phase_name], require_texture=required,
            )
            if (row["valid"] and phase_name == "Pb3WO6_analogue" and
                    axis != (0, 0, 0)):
                fraction = float(row["mass_fractions"][phase_name][0])
                fraction_ratio = fraction / reference_fraction
                cell = row["summary"]["phases"][phase_name]["cell"]
                length_ratios = {
                    key: float(cell[key]) / float(reference_cell[key])
                    for key in ("length_a", "length_b", "length_c")
                }
                if not 0.5 <= fraction_ratio <= 2.0:
                    row["valid"] = False
                    row["reason"] = (
                        f"weak-phase fraction ratio={fraction_ratio} is unstable"
                    )
                elif any(not 0.95 <= value <= 1.05
                         for value in length_ratios.values()):
                    row["valid"] = False
                    row["reason"] = (
                        f"weak-phase cell-length ratios={length_ratios} are unstable"
                    )
            rows.append(row); group.append(row)
        neutral = group[0]
        winner = choose(group, neutral, gain=0.02)
        checkpoint = Path(winner["path"]); state = copy.deepcopy(winner["state"])
        selected.append({"coordinate": f"texture:{phase_name}",
                         "winner": winner["tag"]})

    shutil.copyfile(checkpoint, OUTPUT)
    final = rw.G2sc.G2Project(str(OUTPUT))
    payload = {
        "initial_state": initial_state,
        "final_state": state,
        "state_stable": state == initial_state,
        "selected": selected,
        "trials": rows,
        "final": rw.summary(final, "post_texture_coordinate_loop"),
    }
    (TMP / "final_coordinate_trials.json").write_text(
        json.dumps(payload, indent=2, default=float) + "\n"
    )
    print(json.dumps({k: payload[k] for k in
                      ("initial_state", "final_state", "state_stable", "selected", "final")},
                     indent=2, default=float))


if __name__ == "__main__":
    main()
