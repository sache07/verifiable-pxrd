#!/usr/bin/env python3
"""Replay plausible fourth phases against the converged three-phase model."""

from __future__ import annotations

import json
import math
from pathlib import Path

import final_coordinate as fc
import refine_workflow as rw


TMP = Path(".tmp")
CHECKPOINT = TMP / "three_coordinate_stable4.gpx"
STATE = {
    "profile": ["W", "X"],
    "background": 10,
    "polarization": True,
    "roughness_B": False,
    "broadening": {
        "PbWO4_scheelite": ["size_uniaxial"],
        "Pb3O4": ["size"],
    },
    "texture": {"PbWO4_scheelite": [1, 0, 0]},
}
CANDIDATES = [
    ("PbO", TMP / "PbO_9012700.cif", "pass"),
    ("PbWO4_raspite", TMP / "PbWO4_raspite_9007617.cif", "pass"),
    ("Pb7W8O28p8_defect", TMP / "Pb7W8O28p8_9016035.cif", "review"),
    ("Pb2WO5_analogue", TMP / "Pb2WO5_from_Pb2MoO5.cif", "pass"),
    ("Pb3WO6_analogue", TMP / "Pb3WO6_from_Pb3UO6.cif", "pass"),
]


def scale_value(phase, hist):
    return float(phase.getHAPvalues(hist.name)["Scale"][0])


def one_candidate(tag, cif, health):
    path = TMP / f"watch_{tag}.gpx"
    project = rw.G2sc.G2Project(str(CHECKPOINT), newgpx=str(path))
    hist = project.histogram(0)
    phase_name = f"watch_{tag}"
    phase = project.add_phase(
        str(cif), phasename=phase_name, histograms=[hist], fmthint="CIF"
    )
    rw.set_neutral_hap(phase, hist)
    phase.getHAPvalues(hist.name)["Scale"][0] = 0.05
    source_volume = float(phase.get_cell()["volume"])
    project.save()

    # Scale gate: all phase scales can repartition, but no profile, cell or
    # background parameter is allowed to rescue the candidate at this stage.
    rw.set_all_flags_off(project)
    for item in project.phases():
        item.set_HAP_refinements({"Scale": True})
    scale_log = []
    scale_result = rw.converge(project, f"watch_{tag}_scales", scale_log, passes=2)
    first_scale = scale_value(phase, hist)
    first_positive = math.isfinite(first_scale) and first_scale > 0.0

    row = {
        "tag": tag,
        "cif": str(cif),
        "health": health,
        "project": str(path),
        "scale_gate": {
            "scale": first_scale,
            "positive": first_positive,
            "wR_percent": scale_result["wR_percent"],
            "mass_fractions": scale_result["mass_fractions"],
        },
    }
    if not first_positive:
        row.update({"replay_valid": False,
                    "reason": "non-positive scale at the scale-only gate"})
        return row

    # Full matched replay, initially holding the candidate cell at its source
    # value. Existing retained nuisance terms are all active.
    fc.activate(project, STATE)
    phase.data["General"]["Cell"][0] = False
    replay_log = []
    replay = rw.converge(project, f"watch_{tag}_replay_fixed_cell",
                         replay_log, passes=3)
    ok, reason = fc.valid(project, STATE)
    replay_scale = scale_value(phase, hist)
    if not math.isfinite(replay_scale) or replay_scale <= 0.0:
        ok, reason = False, f"replay scale={replay_scale} is non-positive"

    cell_released = False
    if ok:
        phase.set_refinements({"Cell": True})
        replay = rw.converge(project, f"watch_{tag}_replay_cell",
                             replay_log, passes=3)
        cell_released = True
        ok, reason = fc.valid(project, STATE)
        replay_scale = scale_value(phase, hist)
        if not math.isfinite(replay_scale) or replay_scale <= 0.0:
            ok, reason = False, f"cell-released scale={replay_scale} is non-positive"

    final_volume = float(phase.get_cell()["volume"])
    volume_ratio = final_volume / source_volume
    if ok and not 0.8 <= volume_ratio <= 1.2:
        ok, reason = False, f"cell volume ratio={volume_ratio} is unstable"
    fractions = hist.ComputeMassFracs()
    row.update({
        "replay_valid": ok,
        "reason": reason,
        "cell_released": cell_released,
        "replay_scale": replay_scale,
        "source_volume_A3": source_volume,
        "final_volume_A3": final_volume,
        "volume_ratio": volume_ratio,
        "wR_percent": replay["wR_percent"],
        "mass_fractions": fractions,
        "candidate_weight_fraction": (
            float(fractions[phase_name][0]) if phase_name in fractions else None
        ),
    })
    project.save()
    return row


def main():
    base = rw.G2sc.G2Project(str(CHECKPOINT))
    rows = [one_candidate(*spec) for spec in CANDIDATES]
    payload = {
        "baseline_wR_percent": base.histogram(0).get_wR(),
        "baseline_mass_fractions": base.histogram(0).ComputeMassFracs(),
        "candidates": rows,
    }
    (TMP / "watchlist_final_replay.json").write_text(
        json.dumps(payload, indent=2, default=float) + "\n"
    )
    print(json.dumps(payload, indent=2, default=float))


if __name__ == "__main__":
    main()
