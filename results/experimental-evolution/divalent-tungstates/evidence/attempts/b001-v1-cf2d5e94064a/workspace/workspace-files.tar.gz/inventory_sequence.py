#!/usr/bin/env python3
"""Add the chemically expected phases one at a time and reconverge each model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from scipy.signal import find_peaks

from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = Path(".tmp/inventory")


def cif_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def initialize_hap(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Mustrain"][1][0:2] = [0.0, 0.0]
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Size"][1][0:2] = [1000.0, 1000.0]
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Scale"] = [1.0, True]


def residual_peaks(histogram) -> list[dict]:
    x = np.asarray(histogram.getdata("x"))
    residual = np.asarray(histogram.getdata("yobs")) - np.asarray(
        histogram.getdata("ycalc")
    )
    smooth = gaussian_filter1d(residual, 1.2)
    peaks, properties = find_peaks(smooth, prominence=80.0, distance=5, height=40.0)
    order = np.argsort(properties["prominences"])[::-1]
    return [
        {
            "two_theta_deg": float(x[peaks[index]]),
            "residual_counts": float(smooth[peaks[index]]),
            "prominence_counts": float(properties["prominences"][index]),
        }
        for index in order[:15]
    ]


def summarize(project, histogram, stage: str) -> dict:
    covariance = project.data["Covariance"]["data"]
    return {
        "stage": stage,
        "wR_percent": histogram.residuals["wR"],
        "R_percent": histogram.residuals["R"],
        "GOF": covariance["Rvals"]["GOF"],
        "fractions": {
            key: {"value": value[0], "esd": value[1]}
            for key, value in histogram.ComputeMassFracs().items()
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "top_positive_residuals": residual_peaks(histogram),
        "frozen": project.get_Frozen(),
        "max_shift_over_esd": covariance["Rvals"].get("Max shft/sig"),
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(OUT / "inventory_sequence.gpx"))
    histogram = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    histogram.SampleParameters["Scale"] = [1.0, False]
    inst = histogram.InstrumentParameters
    for key, value in {
        "U": 12.5062875306,
        "V": 0.0,
        "W": 7.47035117015,
        "X": 12.2223508809,
        "Y": 0.0,
    }.items():
        inst[key][1] = value
        inst[key][2] = False

    x = np.asarray(histogram.getdata("x"))
    y = np.asarray(histogram.getdata("yobs"))
    step = float(np.median(np.diff(x)))
    baseline = percentile_filter(
        y, 15, size=(int(round(3.0 / step)) | 1), mode="nearest"
    )
    baseline = gaussian_filter1d(baseline, 30)
    normalized_x = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    coefficients = np.polynomial.chebyshev.chebfit(normalized_x, baseline, 9)
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": coefficients.tolist(),
                "refine": True,
            },
            "Instrument Parameters": ["Zero"],
        }
    )
    project.set_Controls("cycles", 20)
    project.save()

    stages = []
    records = [
        ("1520641", "ZnWO4"),
        ("2311041", "WO3"),
        ("9004178", "ZnO"),
    ]
    for index, (cod_id, name) in enumerate(records, start=1):
        phase = project.add_phase(
            str(cif_path(cod_id)),
            phasename=name,
            histograms=[histogram],
            fmthint="CIF",
        )
        initialize_hap(phase, histogram.name)
        project.set_Controls("parmMin", -0.15, ":0:Zero")
        project.set_Controls("parmMax", 0.15, ":0:Zero")
        for existing in project.phases():
            existing.set_refinements({"Cell": True})
            project.set_Controls("parmMin", 0.0, f"{existing.id}:0:Scale")

        # Two passes ensure that background, every scale, zero and all cells
        # are re-converged after each inventory change.
        project.refine()
        project.refine()
        snapshot = OUT / f"stage_{index}_{name}.gpx"
        project.save(str(snapshot))
        stages.append(summarize(project, histogram, "+".join(p.name for p in project.phases())))

    (OUT / "summary.json").write_text(json.dumps(stages, indent=2) + "\n")
    print(json.dumps(stages, indent=2))


if __name__ == "__main__":
    main()
