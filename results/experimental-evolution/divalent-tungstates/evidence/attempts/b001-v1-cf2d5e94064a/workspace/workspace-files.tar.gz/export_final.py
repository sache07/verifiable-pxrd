#!/usr/bin/env python3
"""Export all submitted artifacts from the selected, saved GSAS-II project."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


SOURCE_PROJECT = Path(".tmp/displacement_trial.bak0.gpx")
FINAL_PROJECT = Path("final.gpx").resolve()
PHASE_INFO = {
    "ZnWO4": {"formula": "ZnWO4", "cod_id": "1520641", "cif": "ZnWO4.cif"},
    "WO3": {"formula": "WO3", "cod_id": "2311041", "cif": "WO3.cif"},
    "ZnO": {"formula": "ZnO", "cod_id": "9004178", "cif": "ZnO.cif"},
}


def covariance_values(project) -> tuple[dict[str, float], dict[str, float]]:
    covariance = project.data["Covariance"]["data"]
    values = dict(zip(covariance["varyList"], covariance["variables"]))
    sigmas = dict(zip(covariance["varyList"], covariance["sig"]))
    return values, sigmas


def main() -> None:
    # Save under the required final name, then reload that exact file before
    # computing fractions or exporting any submitted artifact.
    selected = G2sc.G2Project(str(SOURCE_PROJECT), newgpx=str(FINAL_PROJECT))
    selected.save()
    project = G2sc.G2Project(str(FINAL_PROJECT))
    histogram = project.histogram(0)
    values, sigmas = covariance_values(project)

    raw_fractions = histogram.ComputeMassFracs()
    fraction_sum = sum(value for value, _ in raw_fractions.values())
    normalized_fractions = {
        name: (value / fraction_sum, sigma / fraction_sum)
        for name, (value, sigma) in raw_fractions.items()
    }

    exported_phases = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        output_path = Path(info["cif"]).resolve()
        phase.export_CIF(str(output_path))
        cell, cell_esd = phase.get_cell_and_esd()
        hap = phase.data["Histograms"][histogram.name]
        entry = {
            "name": phase.name,
            "formula": info["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "source": {
                "database": "Crystallography Open Database",
                "cod_id": info["cod_id"],
            },
            "cif_path": info["cif"],
            "weight_fraction": normalized_fractions[phase.name][0],
            "weight_fraction_esd_formal": normalized_fractions[phase.name][1],
            "weight_percent": 100.0 * normalized_fractions[phase.name][0],
            "weight_percent_esd_formal": 100.0
            * normalized_fractions[phase.name][1],
            "refined_cell": cell,
            "refined_cell_esd": cell_esd,
            "scale": hap["Scale"][0],
            "scale_refined": hap["Scale"][1],
            "atomic_coordinates_refined": any(
                bool(atom.refinement_flags.strip()) for atom in phase.atoms()
            ),
        }
        if phase.name == "ZnWO4":
            entry["isotropic_crystallite_size_micrometre"] = hap["Size"][1][0]
            entry["isotropic_crystallite_size_esd_micrometre"] = sigmas.get(
                f"{phase.id}:0:Size;i"
            )
        if phase.name == "WO3":
            entry["march_dollase_axis"] = hap["Pref.Ori."][3]
            entry["march_dollase_ratio"] = hap["Pref.Ori."][1]
            entry["march_dollase_ratio_esd"] = sigmas.get(f"{phase.id}:0:MD")
        exported_phases.append(entry)

    x = np.asarray(histogram.getdata("x"), dtype=float)
    observed = np.asarray(histogram.getdata("yobs"), dtype=float)
    calculated = np.asarray(histogram.getdata("ycalc"), dtype=float)
    difference = observed - calculated
    background = np.asarray(histogram.getdata("background"), dtype=float)
    weights = np.asarray(histogram.getdata("yweight"), dtype=float)
    with Path("fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity_counts",
                "calculated_intensity_counts",
                "difference_observed_minus_calculated_counts",
                "calculated_background_counts",
            ]
        )
        writer.writerows(zip(x, observed, calculated, difference, background))

    residuals = histogram.residuals
    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    manual_rwp = 100.0 * np.sqrt(
        np.sum(weights * difference**2) / np.sum(weights * observed**2)
    )
    result = {
        "modeled_crystalline_phase_count": len(exported_phases),
        "phase_fraction_basis": (
            "Normalized over the modeled crystalline phases; no amorphous fraction "
            "or absolute crystalline content was determined."
        ),
        "phases": exported_phases,
        "fit_statistics": {
            "Rwp_percent": residuals["wR"],
            "Rp_percent": residuals["R"],
            "Rwp_background_percent": residuals["wRb"],
            "Rp_background_percent": residuals["Rb"],
            "Rwp_expected_percent": residuals["wRmin"],
            "goodness_of_fit": rvals["GOF"],
            "chi_squared": rvals["chisq"],
            "number_of_observations": rvals["Nobs"],
            "number_of_refined_variables": rvals["Nvars"],
            "maximum_shift_over_esd": rvals["Max shft/sig"],
            "manual_Rwp_from_fit_csv_percent": float(manual_rwp),
        },
        "measurement_model": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelength_Kalpha1_angstrom": histogram.InstrumentParameters["Lam1"][1],
            "wavelength_Kalpha2_angstrom": histogram.InstrumentParameters["Lam2"][1],
            "Kalpha2_to_Kalpha1_ratio": histogram.InstrumentParameters[
                "I(L2)/I(L1)"
            ][1],
            "specimen_displacement_micrometre": histogram.SampleParameters["Shift"][0],
            "specimen_displacement_esd_micrometre": sigmas.get(":0:Shift"),
            "zero_offset_deg": histogram.InstrumentParameters["Zero"][1],
            "profile": {
                key: histogram.InstrumentParameters[key][1]
                for key in ["U", "V", "W", "X", "Y", "SH/L"]
            },
        },
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "project_checks": {
            "fraction_sum": sum(
                phase["weight_fraction"] for phase in exported_phases
            ),
            "frozen_variables": project.get_Frozen(),
            "converged": rvals["converged"],
            "svd_zero_count": rvals["SVD0"],
        },
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")

    # A final reload verifies that the submitted project can replay the exact
    # arrays and phase fractions just exported.
    replay = G2sc.G2Project(str(FINAL_PROJECT))
    replay_histogram = replay.histogram(0)
    replay_fractions = replay_histogram.ComputeMassFracs()
    assert np.array_equal(x, np.asarray(replay_histogram.getdata("x"), dtype=float))
    assert np.array_equal(
        calculated, np.asarray(replay_histogram.getdata("ycalc"), dtype=float)
    )
    for name, (value, _) in raw_fractions.items():
        assert abs(value - replay_fractions[name][0]) < 1e-12
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
