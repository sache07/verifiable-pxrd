#!/usr/bin/env python3
"""Compare physically plausible WO3 records with one common nuisance model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter

from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = Path(".tmp/wo3_candidates")
WO3_IDS = ["2311041", "2106293", "2107312", "1563541"]


def cif_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def set_inactive_phase_broadening(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Mustrain"][1][0:2] = [0.0, 0.0]
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Size"][1][0:2] = [1000.0, 1000.0]
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Scale"] = [1.0, True]


def build_and_refine(wo3_id: str) -> dict:
    output = OUT / f"wo3_{wo3_id}.gpx"
    project = G2sc.G2Project(newgpx=str(output))
    histogram = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    histogram.SampleParameters["Scale"] = [1.0, False]

    # Common profile fixed for all polymorph tests. V=Y=0 makes both the
    # Gaussian and Lorentzian width functions nonnegative over the scan.
    inst = histogram.InstrumentParameters
    for key, value in {
        "U": 12.5062875306,
        "V": 0.0,
        "W": 7.47035117015,
        "X": 12.2223508809,
        "Y": 0.0,
    }.items():
        inst[key][1] = value
        inst[key][2] = False

    x = np.asarray(histogram.getdata("x"))
    y = np.asarray(histogram.getdata("yobs"))
    step = float(np.median(np.diff(x)))
    baseline = percentile_filter(
        y, 15, size=(int(round(3.0 / step)) | 1), mode="nearest"
    )
    baseline = gaussian_filter1d(baseline, 30)
    normalized_x = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    coefficients = np.polynomial.chebyshev.chebfit(normalized_x, baseline, 9)
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": coefficients.tolist(),
                "refine": True,
            }
        }
    )

    records = [
        ("1520641", "ZnWO4"),
        (wo3_id, f"WO3_{wo3_id}"),
        ("9004178", "ZnO"),
    ]
    for cod_id, name in records:
        phase = project.add_phase(
            str(cif_path(cod_id)),
            phasename=name,
            histograms=[histogram],
            fmthint="CIF",
        )
        set_inactive_phase_broadening(phase, histogram.name)

    project.set_Controls("cycles", 18)
    project.save()
    project.refine()

    histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Controls("parmMin", -0.15, ":0:Zero")
    project.set_Controls("parmMax", 0.15, ":0:Zero")
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Scale")

    # Re-converge background, all scales, zero and all cells before judgment.
    project.refine()
    project.refine()
    project.save()

    covariance = project.data["Covariance"]["data"]
    return {
        "cod_id": wo3_id,
        "gpx": str(output),
        "wR_percent": histogram.residuals["wR"],
        "R_percent": histogram.residuals["R"],
        "GOF": covariance["Rvals"]["GOF"],
        "zero_deg": histogram.InstrumentParameters["Zero"][1],
        "mass_fractions": {
            key: {"value": value[0], "esd": value[1]}
            for key, value in histogram.ComputeMassFracs().items()
        },
        "cell": {phase.name: phase.get_cell() for phase in project.phases()},
        "frozen": project.get_Frozen(),
        "max_shift_over_esd": covariance["Rvals"].get("Max shft/sig"),
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    summaries = [build_and_refine(cod_id) for cod_id in WO3_IDS]
    (OUT / "summary.json").write_text(json.dumps(summaries, indent=2) + "\n")
    print(json.dumps(summaries, indent=2))


if __name__ == "__main__":
    main()
