import csv
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "working" / "finalcheck_mn3strain_keep.gpx"
FINAL = ROOT / "final.gpx"
HIST = "PWDR pattern.csv"


project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
hist = project.histogram(HIST)
x = np.asarray(hist.data["data"][1][0], dtype=float)
hist.data["Limits"][1] = [float(x[0]), float(x[-1])]
project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
project.set_Controls("cycles", 12)
project.save()

# Full measured-range convergence.
for _ in range(4):
    project.refine()
    rv = project.data["Covariance"]["data"]["Rvals"]
    if (
        rv.get("converged")
        and abs(rv.get("DelChi2", 1.0)) < 1.0e-4
        and rv.get("Max shft/sig", 99) < 1.0
    ):
        break
project.save()

# Required save/reopen native replay.
project = G2sc.G2Project(str(FINAL))
project.set_Controls("cycles", 12)
project.refine()
project.save()

hist = project.histogram(HIST)
exports = {
    "MnWO4_wolframite": ROOT / "MnWO4_wolframite.cif",
    "WO3_triclinic": ROOT / "WO3_triclinic.cif",
    "Mn3O4_hausmannite": ROOT / "Mn3O4_hausmannite.cif",
}
for phase_name, path in exports.items():
    project.phase(phase_name).export_CIF(str(path))

data = hist.data["data"][1]
with (ROOT / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(
        ["two_theta_deg", "observed_counts", "calculated_counts", "difference_counts"]
    )
    for row in zip(data[0], data[1], data[3], data[5]):
        writer.writerow([f"{float(v):.10g}" for v in row])

rv = project.data["Covariance"]["data"]["Rvals"]
print("Rvals", rv)
print("profile_residuals", hist.data["data"][0])
print("fractions", hist.ComputeMassFracs())
print("limits", hist.data["Limits"])
print("instrument", hist.data["Instrument Parameters"][0])
print("sample", hist.data["Sample Parameters"])
print("background", hist.data["Background"])
print("frozen", project.data["Controls"]["data"].get("parmFrozen"))
for phase in project.phases():
    hap = phase.data["Histograms"][HIST]
    print(
        "phase", phase.name,
        "cell", phase.data["General"]["Cell"],
        "scale", hap["Scale"],
        "size", hap["Size"][:3],
        "strain", hap["Mustrain"][:3],
    )
    for atom in phase.atoms():
        print("atom", phase.name, atom.label, atom.element, atom.coordinates, atom.uiso)
