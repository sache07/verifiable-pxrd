from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "working" / "profile_T2.gpx"
HIST = "PWDR pattern.csv"


def neutral_hap(phase, scale):
    hap = phase.data["Histograms"][HIST]
    hap["Use"] = True
    hap["Scale"] = [float(scale), True]
    hap["Size"][:3] = ["isotropic", [1.0e6, 1.0e6, 0.5], [False, False, False]]
    hap["Mustrain"][:3] = ["isotropic", [0.001, 0.001, 0.5], [False, False, False]]
    hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"] = [0.0, False]


def converge(project, passes=4):
    for _ in range(passes):
        project.refine()
        rv = project.data["Covariance"]["data"]["Rvals"]
        if rv.get("converged") and abs(rv.get("DelChi2", 1.0)) < 1.0e-4:
            break


def challenge(tag, path, name, scale):
    out = ROOT / "working" / f"watch_T_{tag}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = project.histogram(HIST)
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "W", "X", "SH/L"):
        inst[key][2] = False
    phase = project.add_phase(str(path), phasename=name, histograms=[hist])
    neutral_hap(phase, scale)
    phase.data["General"]["Cell"][0] = False
    pid = phase.data["pId"]
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
    project.set_Controls("parmMax", 1.0e6, variable=f"{pid}:0:Scale")
    project.set_Controls("cycles", 12)
    project.save()
    converge(project, 3)
    first = hist.ComputeMassFracs().get(name, (0.0, 0.0))
    if first[0] > max(0.0002, first[1] * 0.25):
        phase.data["General"]["Cell"][0] = True
        project.save()
        converge(project, 4)
    project.save()
    rv = project.data["Covariance"]["data"]["Rvals"]
    print(
        tag,
        "Rwp", rv["Rwp"],
        "GOF", rv["GOF"],
        "fraction", hist.ComputeMassFracs().get(name),
        "cell", phase.data["General"]["Cell"][1:8],
        "cell_refined", phase.data["General"]["Cell"][0],
        "converged", rv.get("converged"),
        "DelChi2", rv.get("DelChi2"),
    )


cif_root = Path(
    "<RUN>/"
    "resources/b001-c04/cif"
)
challenge(
    "Mn2O3",
    cif_root / "1/51/42/1514230.cif",
    "Mn2O3_watch",
    0.15,
)
challenge(
    "MnO",
    cif_root / "1/51/41/1514108.cif",
    "MnO_watch",
    0.15,
)
challenge(
    "Mn3WO6",
    cif_root / "2/00/27/2002703.cif",
    "Mn3WO6_watch",
    0.15,
)
challenge(
    "MnWO4_C2m",
    ROOT / "working" / "mnwo4_c2m_mnmoo4_parent.cif",
    "MnWO4_C2m_watch",
    0.15,
)
