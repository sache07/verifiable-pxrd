from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "working" / "finalsource_WO3_2106293.gpx"
HIST = "PWDR pattern.csv"
ACTIVE = {"Mn3O4_9001963", "MnWO4_Zn_parent", "WO3_2106293_test"}


def reset_hap(phase):
    hap = phase.data["Histograms"][HIST]
    hap["Size"][:3] = ["isotropic", [1.0e6, 1.0e6, 0.5], [False, False, False]]
    hap["Mustrain"][:3] = ["isotropic", [0.001, 0.001, 0.5], [False, False, False]]
    hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"] = [0.0, False]
    if "Babinet" in hap:
        for key in hap["Babinet"]:
            hap["Babinet"][key] = [0.0, False]


starts = {
    "T1": (26.0, 4.0, 1.8, 0.10),
    "T2": (12.0, 10.0, 0.8, 0.055),
    "T3": (45.0, 1.5, 3.5, 0.155),
}

for tag, (u, w, x, shl) in starts.items():
    out = ROOT / "working" / f"profile_{tag}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = project.histogram(HIST)
    for phase in project.phases():
        reset_hap(phase)
        if phase.name in ACTIVE:
            phase.data["Histograms"][HIST]["Use"] = True
            phase.data["Histograms"][HIST]["Scale"][1] = True
            phase.data["General"]["Cell"][0] = True
        else:
            phase.data["Histograms"][HIST]["Use"] = False
            phase.data["Histograms"][HIST]["Scale"][1] = False
            phase.data["General"]["Cell"][0] = False

    sample = hist.data["Sample Parameters"]
    sample["Shift"][1] = True
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    inst = hist.data["Instrument Parameters"][0]
    inst["Zero"] = [inst["Zero"][0], 0.0, False]
    inst["U"] = [inst["U"][0], u, True]
    inst["V"] = [inst["V"][0], 0.0, False]
    inst["W"] = [inst["W"][0], w, True]
    inst["X"] = [inst["X"][0], x, True]
    inst["Y"] = [inst["Y"][0], 0.0, False]
    inst["Z"] = [inst["Z"][0], 0.0, False]
    inst["SH/L"] = [inst["SH/L"][0], shl, True]
    project.set_Controls("cycles", 12)
    for variable, minimum, maximum in (
        (":0:U", 0.0, 500.0),
        (":0:W", 0.0, 500.0),
        (":0:X", 0.0, 50.0),
        (":0:SH/L", 0.002, 0.2),
        (":0:Shift", -1000.0, 1000.0),
    ):
        project.set_Controls("parmMin", minimum, variable=variable)
        project.set_Controls("parmMax", maximum, variable=variable)
    project.save()
    for _ in range(5):
        project.refine()
        rv = project.data["Covariance"]["data"]["Rvals"]
        if rv.get("converged") and abs(rv.get("DelChi2", 1.0)) < 1.0e-4:
            break
    project.save()
    rv = project.data["Covariance"]["data"]["Rvals"]
    print(
        tag,
        "Rwp", rv["Rwp"],
        "GOF", rv["GOF"],
        "profile", {k: inst[k][1] for k in ("U", "W", "X", "SH/L")},
        "shift", sample["Shift"][0],
        "fractions", hist.ComputeMassFracs(),
        "DelChi2", rv.get("DelChi2"),
    )
