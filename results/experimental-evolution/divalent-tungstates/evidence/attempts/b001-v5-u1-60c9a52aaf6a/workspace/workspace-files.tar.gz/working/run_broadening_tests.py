from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "working" / "profile_T2.gpx"
HIST = "PWDR pattern.csv"
PHASES = ("MnWO4_Zn_parent", "WO3_2106293_test", "Mn3O4_9001963")


def run_one(task):
    from GSASII import GSASIIscriptable as G2sc

    phase_name, kind = task
    short = {
        "MnWO4_Zn_parent": "MnWO4",
        "WO3_2106293_test": "WO3",
        "Mn3O4_9001963": "Mn3O4",
    }[phase_name]
    out = ROOT / "working" / f"broad_{short}_{kind}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = project.histogram(HIST)
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "W", "X", "SH/L"):
        inst[key][2] = False
    for phase in project.phases():
        if HIST not in phase.data.get("Histograms", {}):
            continue
        hap = phase.data["Histograms"][HIST]
        hap["Size"][:3] = ["isotropic", [10.0, 1.0e6, 0.5], [False, False, False]]
        hap["Mustrain"][:3] = ["isotropic", [0.001, 0.001, 0.5], [False, False, False]]
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][HIST]
    pid = phase.data["pId"]
    if kind == "size":
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
        variable = f"{pid}:0:Size;i"
        project.set_Controls("parmMin", 0.02, variable=variable)
        project.set_Controls("parmMax", 1000.0, variable=variable)
    else:
        hap["Mustrain"][1][0] = 200.0
        hap["Mustrain"][2][0] = True
        variable = f"{pid}:0:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 10000.0, variable=variable)
    project.set_Controls("cycles", 12)
    project.save()
    for _ in range(5):
        project.refine()
        rv = project.data["Covariance"]["data"]["Rvals"]
        if rv.get("converged") and abs(rv.get("DelChi2", 1.0)) < 1.0e-4:
            break
    project.save()
    rv = project.data["Covariance"]["data"]["Rvals"]
    cov = project.data["Covariance"]["data"]
    sig = None
    for v, s in zip(cov.get("varyList", []), cov.get("sig", [])):
        if str(v) == variable:
            sig = float(s)
            break
    value = hap["Size"][1][0] if kind == "size" else hap["Mustrain"][1][0]
    frozen = [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])]
    return {
        "phase": phase_name,
        "kind": kind,
        "Rwp": rv["Rwp"],
        "GOF": rv["GOF"],
        "value": value,
        "sig": sig,
        "converged": rv.get("converged"),
        "DelChi2": rv.get("DelChi2"),
        "frozen": frozen,
        "file": str(out.relative_to(ROOT)),
    }


if __name__ == "__main__":
    tasks = [(phase, kind) for phase in PHASES for kind in ("size", "strain")]
    with ProcessPoolExecutor(max_workers=3) as pool:
        futures = [pool.submit(run_one, task) for task in tasks]
        for future in as_completed(futures):
            print(future.result(), flush=True)
