from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "working"
SOURCE = WORK / "clean_model.gpx"
STABLE = WORK / "stable_model.gpx"
BEST = WORK / "stable_model_best.gpx"
HIST = "PWDR pattern.csv"


def configure(project):
    hist = project.histogram(HIST)
    hist.data["Background"][0][1] = True
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "W", "X", "SH/L", "Polariz."):
        inst[key][2] = True
    inst["Zero"][1:] = [0.0, False]
    for key in ("V", "Y", "Z"):
        inst[key][1:] = [0.0, False]
    sample = hist.data["Sample Parameters"]
    sample["Shift"][1] = True
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][HIST]
        hap["Scale"][1] = True
        hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        for atom in phase.atoms():
            atom.refinement_flags = ""
    wo3 = project.phase("WO3_triclinic")
    wo3.data["Histograms"][HIST]["Size"][2][0] = True
    wo3.data["Histograms"][HIST]["Mustrain"][2][0] = True
    mn3o4 = project.phase("Mn3O4_hausmannite")
    mn3o4.data["Histograms"][HIST]["Mustrain"][2][0] = True

    # Restore the physically interior Uiso values from the successful block
    # refinement and hold them fixed. The fully simultaneous Uiso branch hit a
    # bound and is intentionally rejected.
    mnwo4 = project.phase("MnWO4_wolframite")
    uiso = (0.0088448757, 0.0085884989, 0.0062051061, 0.0076105196)
    for atom, value in zip(mnwo4.atoms(), uiso):
        atom.uiso = value
        atom.refinement_flags = "X"
    for atom in wo3.atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"

    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 1)
    return hist


def save_clone(source, destination):
    clone = G2sc.G2Project(str(source), newgpx=str(destination))
    clone.save()


project = G2sc.G2Project(str(SOURCE), newgpx=str(STABLE))
hist = configure(project)
project.save()

# First one-cycle replay synchronizes the calculated profile after restoring
# Uiso and clearing the failed frozen branch.
project.refine()
project.save()
rv = project.data["Covariance"]["data"]["Rvals"]
best_rwp = rv["Rwp"]
print("sync", best_rwp, rv.get("DelChi2"), rv.get("Max shft/sig"))
save_clone(STABLE, BEST)

for step in range(12):
    candidate = G2sc.G2Project(str(BEST), newgpx=str(STABLE))
    configure(candidate)
    candidate.save()
    candidate.refine()
    candidate.save()
    rv = candidate.data["Covariance"]["data"]["Rvals"]
    frozen = candidate.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])
    print(
        "replay", step, rv["Rwp"], rv.get("DelChi2"),
        rv.get("Max shft/sig"), "frozen", [str(v) for v in frozen],
    )
    if frozen or rv["Rwp"] > best_rwp + 1.0e-7:
        break
    improvement = best_rwp - rv["Rwp"]
    best_rwp = rv["Rwp"]
    save_clone(STABLE, BEST)
    if improvement < 1.0e-6:
        break

# Reopen the accepted state and preserve it as the stable clean project.
project = G2sc.G2Project(str(BEST), newgpx=str(STABLE))
hist = configure(project)
project.save()
rv = project.data["Covariance"]["data"]["Rvals"]
print("accepted", rv)
print("fractions", hist.ComputeMassFracs())
print("frozen", project.data["Controls"]["data"].get("parmFrozen"))
for phase in project.phases():
    hap = phase.data["Histograms"][HIST]
    print(
        phase.name,
        "cell", phase.data["General"]["Cell"],
        "scale", hap["Scale"],
        "size", hap["Size"][:3],
        "strain", hap["Mustrain"][:3],
    )
