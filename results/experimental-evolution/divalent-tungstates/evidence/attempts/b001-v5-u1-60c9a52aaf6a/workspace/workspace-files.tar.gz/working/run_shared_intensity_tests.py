from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "working" / "broadening_selected.gpx"
HIST = "PWDR pattern.csv"
TASKS = ("base8", "background6", "polarization", "roughness")


def run_one(kind):
    from GSASII import GSASIIscriptable as G2sc

    out = ROOT / "working" / f"shared_{kind}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = project.histogram(HIST)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    # Hold positions and accepted line-shape terms fixed for this intensity-only
    # comparison; refine background and all active scales in every branch.
    for key in ("U", "W", "X", "SH/L"):
        inst[key][2] = False
    inst["Polariz."][2] = False
    sample["Shift"][1] = False
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data.get("Histograms", {}).get(HIST)
        if hap is None:
            continue
        if hap.get("Use", False):
            hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
    bkg = hist.data["Background"][0]
    bkg[1] = True
    if kind == "background6":
        bkg[2] = 6
        del bkg[9:]
    elif kind == "polarization":
        inst["Polariz."][1] = 0.7
        inst["Polariz."][2] = True
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif kind == "roughness":
        sample["SurfRoughA"] = [0.5, True]
        sample["SurfRoughB"] = [0.10, True]
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 5.0, variable=":0:SurfRoughB")
    project.set_Controls("cycles", 12)
    project.save()
    for _ in range(5):
        project.refine()
        rv = project.data["Covariance"]["data"]["Rvals"]
        frozen = project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])
        if frozen:
            break
        if rv.get("converged") and abs(rv.get("DelChi2", 1.0)) < 1.0e-4:
            break
    project.save()
    rv = project.data["Covariance"]["data"]["Rvals"]
    cov = project.data["Covariance"]["data"]
    sig = {str(v): float(s) for v, s in zip(cov.get("varyList", []), cov.get("sig", []))}
    return {
        "kind": kind,
        "Rwp": rv["Rwp"],
        "GOF": rv["GOF"],
        "polarization": inst["Polariz."][1],
        "polarization_sig": sig.get(":0:Polariz."),
        "roughA": sample["SurfRoughA"][0],
        "roughA_sig": sig.get(":0:SurfRoughA"),
        "roughB": sample["SurfRoughB"][0],
        "roughB_sig": sig.get(":0:SurfRoughB"),
        "bkg_n": bkg[2],
        "fractions": hist.ComputeMassFracs(),
        "converged": rv.get("converged"),
        "DelChi2": rv.get("DelChi2"),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
        "file": str(out.relative_to(ROOT)),
    }


if __name__ == "__main__":
    with ProcessPoolExecutor(max_workers=4) as pool:
        futures = [pool.submit(run_one, task) for task in TASKS]
        for future in as_completed(futures):
            print(future.result(), flush=True)
