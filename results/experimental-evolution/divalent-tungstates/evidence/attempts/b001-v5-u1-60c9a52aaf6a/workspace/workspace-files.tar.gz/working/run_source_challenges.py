from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "working" / "profile_Z2.gpx"
HIST = "PWDR pattern.csv"


def neutral_hap(phase, scale):
    hap = phase.data["Histograms"][HIST]
    hap["Use"] = True
    hap["Scale"] = [float(scale), True]
    hap["Size"][:3] = ["isotropic", [1.0e6, 1.0e6, 0.5], [False, False, False]]
    hap["Mustrain"][:3] = ["isotropic", [0.001, 0.001, 0.5], [False, False, False]]
    hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"] = [0.0, False]
    if "Babinet" in hap:
        for key in hap["Babinet"]:
            hap["Babinet"][key] = [0.0, False]


def disable(phase):
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][HIST]
    hap["Use"] = False
    hap["Scale"][1] = False


def challenge(out_name, old_name, cif_path, new_name, scale):
    out = ROOT / "working" / out_name
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    histogram = project.histogram(HIST)
    disable(project.phase(old_name))
    phase = project.add_phase(
        str(cif_path), phasename=new_name, histograms=[histogram]
    )
    neutral_hap(phase, scale)
    phase.data["General"]["Cell"][0] = True
    pid = phase.data["pId"]
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
    project.set_Controls("cycles", 12)
    project.save()
    for _ in range(5):
        project.refine()
        rvals = project.data["Covariance"]["data"]["Rvals"]
        if rvals.get("converged") and rvals.get("DelChi2", 1.0) < 1.0e-4:
            break
    project.save()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    fractions = histogram.ComputeMassFracs()
    print(
        out_name,
        "Rwp", rvals["Rwp"],
        "GOF", rvals["GOF"],
        "cell", phase.data["General"]["Cell"][1:8],
        "fraction", fractions.get(new_name),
        "converged", rvals.get("converged"),
        "DelChi2", rvals.get("DelChi2"),
    )


cif_root = Path(
    "<RUN>/"
    "resources/b001-c04/cif"
)

challenge(
    "finalsource_WO3_1528915.gpx",
    "WO3_2311041",
    cif_root / "1/52/89/1528915.cif",
    "WO3_1528915_test",
    2.65,
)
challenge(
    "finalsource_WO3_2106293.gpx",
    "WO3_2311041",
    cif_root / "2/10/62/2106293.cif",
    "WO3_2106293_test",
    2.65,
)
challenge(
    "finalsource_Mn3O4_1011262.gpx",
    "Mn3O4_9001963",
    cif_root / "1/01/12/1011262.cif",
    "Mn3O4_1011262_test",
    1.52,
)
