from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "working" / "broadening_selected.gpx"
HIST = "PWDR pattern.csv"


project = G2sc.G2Project(
    str(ROOT / "working" / "replay_WO3_both.gpx"), newgpx=str(OUT)
)
hist = project.histogram(HIST)
wo3 = project.phase("WO3_2106293_test")
mn3o4 = project.phase("Mn3O4_9001963")
qwo = wo3.data["Histograms"][HIST]
qmn = mn3o4.data["Histograms"][HIST]
qmn["Size"][:3] = ["isotropic", [10.0, 1.0e6, 0.5], [False, False, False]]
qmn["Mustrain"][:3] = ["isotropic", [7750.0, 0.001, 0.5], [False, False, False]]


def set_nuisance(flag):
    hist.data["Background"][0][1] = flag
    hist.data["Sample Parameters"]["Shift"][1] = flag
    for phase in project.phases():
        hap = phase.data.get("Histograms", {}).get(HIST)
        if hap is None or not hap.get("Use", False):
            continue
        hap["Scale"][1] = flag
        phase.data["General"]["Cell"][0] = flag


def set_micro(flag):
    qwo["Size"][2][0] = flag
    qwo["Mustrain"][2][0] = flag
    qmn["Mustrain"][2][0] = flag


for key in ("U", "W", "X", "SH/L"):
    hist.data["Instrument Parameters"][0][key][2] = False
project.set_Controls("parmMin", 0.02, variable=f"{wo3.data['pId']}:0:Size;i")
project.set_Controls("parmMax", 10.0, variable=f"{wo3.data['pId']}:0:Size;i")
for phase in (wo3, mn3o4):
    pid = phase.data["pId"]
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
    project.set_Controls("parmMax", 20000.0, variable=f"{pid}:0:Mustrain;i")
project.set_Controls("cycles", 12)
project.save()

for outer in range(3):
    set_micro(False)
    set_nuisance(True)
    project.save()
    project.refine()
    rv = project.data["Covariance"]["data"]["Rvals"]
    print("nuisance", outer, rv["Rwp"], rv.get("DelChi2"), rv.get("Max shft/sig"))

    set_nuisance(False)
    set_micro(True)
    project.save()
    project.refine()
    rv = project.data["Covariance"]["data"]["Rvals"]
    print(
        "micro", outer, rv["Rwp"], rv.get("DelChi2"), rv.get("Max shft/sig"),
        "WO3", qwo["Size"][1][0], qwo["Mustrain"][1][0],
        "Mn3O4", qmn["Mustrain"][1][0],
    )

set_nuisance(True)
set_micro(True)
project.save()
for replay in range(4):
    project.refine()
    rv = project.data["Covariance"]["data"]["Rvals"]
    print(
        "full", replay, rv["Rwp"], rv.get("DelChi2"), rv.get("Max shft/sig"),
        "WO3", qwo["Size"][1][0], qwo["Mustrain"][1][0],
        "Mn3O4", qmn["Mustrain"][1][0],
    )
    if rv.get("converged") and abs(rv.get("DelChi2", 1.0)) < 1.0e-4 and rv.get("Max shft/sig", 99) < 1.0:
        break
project.save()
print("fractions", hist.ComputeMassFracs())
