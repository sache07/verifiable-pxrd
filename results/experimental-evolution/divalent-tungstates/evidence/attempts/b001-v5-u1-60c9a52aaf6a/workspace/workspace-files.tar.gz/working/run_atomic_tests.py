from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "working" / "shared_polarization.gpx"
HIST = "PWDR pattern.csv"
TASKS = ("MnWO4_X", "MnWO4_U", "WO3_W_X", "Mn3O4_O_X")


def run_one(kind):
    from GSASII import GSASIIscriptable as G2sc

    out = ROOT / "working" / f"atomic_{kind}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = project.histogram(HIST)
    hist.data["Instrument Parameters"][0]["Polariz."][2] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
        hap = phase.data.get("Histograms", {}).get(HIST)
        if hap is not None:
            hap["Size"][2] = [False, False, False]
            hap["Mustrain"][2] = [False, False, False]
            hap["Pref.Ori."][2] = False
    target = None
    if kind == "MnWO4_X":
        target = project.phase("MnWO4_Zn_parent")
        for atom in target.atoms():
            atom.refinement_flags = "X"
    elif kind == "MnWO4_U":
        target = project.phase("MnWO4_Zn_parent")
        pid = target.data["pId"]
        for idx, atom in enumerate(target.atoms()):
            atom.refinement_flags = "U"
            project.set_Controls("parmMin", 0.001, variable=f"{pid}::AUiso:{idx}")
            project.set_Controls("parmMax", 0.05, variable=f"{pid}::AUiso:{idx}")
    elif kind == "WO3_W_X":
        target = project.phase("WO3_2106293_test")
        for atom in target.atoms():
            if atom.element == "W":
                atom.refinement_flags = "X"
    elif kind == "Mn3O4_O_X":
        target = project.phase("Mn3O4_9001963")
        for atom in target.atoms():
            if atom.element == "O":
                atom.refinement_flags = "X"
    project.set_Controls("cycles", 12)
    project.save()
    for _ in range(5):
        project.refine()
        rv = project.data["Covariance"]["data"]["Rvals"]
        frozen = project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])
        if frozen:
            break
        if rv.get("converged") and abs(rv.get("DelChi2", 1.0)) < 1.0e-4:
            break
    project.save()
    rv = project.data["Covariance"]["data"]["Rvals"]
    atoms = [
        {
            "label": atom.label,
            "element": atom.element,
            "xyz": tuple(float(v) for v in atom.coordinates),
            "uiso": float(atom.uiso),
            "flags": atom.refinement_flags,
        }
        for atom in target.atoms()
    ]
    return {
        "kind": kind,
        "Rwp": rv["Rwp"],
        "GOF": rv["GOF"],
        "fractions": hist.ComputeMassFracs(),
        "atoms": atoms,
        "converged": rv.get("converged"),
        "DelChi2": rv.get("DelChi2"),
        "MaxShift": rv.get("Max shft/sig"),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
        "file": str(out.relative_to(ROOT)),
    }


if __name__ == "__main__":
    with ProcessPoolExecutor(max_workers=4) as pool:
        futures = [pool.submit(run_one, task) for task in TASKS]
        for future in as_completed(futures):
            print(future.result(), flush=True)
