from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "working" / "profile_T2.gpx"
HIST = "PWDR pattern.csv"


TASKS = (
    ("WO3_2106293_test", "size", 0.15, None, "WO3_size_replay"),
    ("WO3_2106293_test", "strain", None, 5000.0, "WO3_strain_replay"),
    ("WO3_2106293_test", "both", 0.08, 5000.0, "WO3_both"),
    ("Mn3O4_9001963", "strain", None, 1500.0, "Mn3O4_strain_low"),
    ("Mn3O4_9001963", "strain", None, 8000.0, "Mn3O4_strain_high"),
    ("Mn3O4_9001963", "size", 0.20, None, "Mn3O4_size_replay"),
    ("MnWO4_Zn_parent", "size", 0.15, None, "MnWO4_size_replay"),
    ("MnWO4_Zn_parent", "strain", None, 1500.0, "MnWO4_strain_replay"),
)


def run_one(task):
    from GSASII import GSASIIscriptable as G2sc

    phase_name, kind, size0, strain0, tag = task
    out = ROOT / "working" / f"replay_{tag}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = project.histogram(HIST)
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "W", "X", "SH/L"):
        inst[key][2] = False
    for phase in project.phases():
        if HIST not in phase.data.get("Histograms", {}):
            continue
        hap = phase.data["Histograms"][HIST]
        hap["Size"][:3] = ["isotropic", [10.0, 1.0e6, 0.5], [False, False, False]]
        hap["Mustrain"][:3] = ["isotropic", [0.001, 0.001, 0.5], [False, False, False]]
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][HIST]
    pid = phase.data["pId"]
    variables = []
    if size0 is not None:
        hap["Size"][1][0] = float(size0)
        hap["Size"][2][0] = True
        var = f"{pid}:0:Size;i"
        variables.append(var)
        project.set_Controls("parmMin", 0.02, variable=var)
        project.set_Controls("parmMax", 10.0, variable=var)
    if strain0 is not None:
        hap["Mustrain"][1][0] = float(strain0)
        hap["Mustrain"][2][0] = True
        var = f"{pid}:0:Mustrain;i"
        variables.append(var)
        project.set_Controls("parmMin", 0.0, variable=var)
        project.set_Controls("parmMax", 20000.0, variable=var)
    project.set_Controls("cycles", 12)
    project.save()
    for _ in range(6):
        project.refine()
        rv = project.data["Covariance"]["data"]["Rvals"]
        frozen = project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])
        if frozen:
            break
        if rv.get("converged") and abs(rv.get("DelChi2", 1.0)) < 1.0e-4:
            break
    project.save()
    rv = project.data["Covariance"]["data"]["Rvals"]
    cov = project.data["Covariance"]["data"]
    sigmas = {str(v): float(s) for v, s in zip(cov.get("varyList", []), cov.get("sig", []))}
    frozen = [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])]
    return {
        "tag": tag,
        "Rwp": rv["Rwp"],
        "GOF": rv["GOF"],
        "size": hap["Size"][1][0] if size0 is not None else None,
        "size_sig": sigmas.get(f"{pid}:0:Size;i"),
        "strain": hap["Mustrain"][1][0] if strain0 is not None else None,
        "strain_sig": sigmas.get(f"{pid}:0:Mustrain;i"),
        "fractions": hist.ComputeMassFracs(),
        "converged": rv.get("converged"),
        "DelChi2": rv.get("DelChi2"),
        "frozen": frozen,
        "file": str(out.relative_to(ROOT)),
    }


if __name__ == "__main__":
    with ProcessPoolExecutor(max_workers=3) as pool:
        futures = [pool.submit(run_one, task) for task in TASKS]
        for future in as_completed(futures):
            print(future.result(), flush=True)
