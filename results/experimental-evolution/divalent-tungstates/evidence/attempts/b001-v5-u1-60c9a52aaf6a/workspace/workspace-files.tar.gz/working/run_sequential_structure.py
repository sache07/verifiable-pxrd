from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
HIST = "PWDR pattern.csv"


def clear_atom_flags(project):
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = ""


def converge(project, passes=5):
    project.set_Controls("cycles", 12)
    project.save()
    for _ in range(passes):
        project.refine()
        rv = project.data["Covariance"]["data"]["Rvals"]
        if rv.get("converged") and abs(rv.get("DelChi2", 1.0)) < 1.0e-4 and rv.get("Max shft/sig", 99) < 1.0:
            break
    project.save()


def show(project, tag, phase_name):
    rv = project.data["Covariance"]["data"]["Rvals"]
    hist = project.histogram(HIST)
    phase = project.phase(phase_name)
    print(
        tag,
        "Rwp", rv["Rwp"],
        "GOF", rv["GOF"],
        "DelChi2", rv.get("DelChi2"),
        "MaxShift", rv.get("Max shft/sig"),
        "fractions", hist.ComputeMassFracs(),
    )
    for atom in phase.atoms():
        print(tag, atom.label, atom.element, atom.coordinates, atom.uiso, atom.refinement_flags)


project = G2sc.G2Project(str(ROOT / "working" / "atomic_MnWO4_X.gpx"))
hist = project.histogram(HIST)
hist.data["Instrument Parameters"][0]["Polariz."][2] = False
for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    hap = phase.data.get("Histograms", {}).get(HIST)
    if hap is not None:
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False

# Refine isotropic displacement factors for the main MnWO4 phase while its
# accepted coordinates are held fixed.
clear_atom_flags(project)
mnwo4 = project.phase("MnWO4_Zn_parent")
pid = mnwo4.data["pId"]
for idx, atom in enumerate(mnwo4.atoms()):
    atom.refinement_flags = "U"
    project.set_Controls("parmMin", 0.001, variable=f"{pid}::AUiso:{idx}")
    project.set_Controls("parmMax", 0.05, variable=f"{pid}::AUiso:{idx}")
project.save(str(ROOT / "working" / "structure_MnWO4_XU.gpx"))
converge(project)
show(project, "MnWO4_XU", "MnWO4_Zn_parent")

# Then refine only W positions in triclinic WO3.
clear_atom_flags(project)
wo3 = project.phase("WO3_2106293_test")
for atom in wo3.atoms():
    if atom.element == "W":
        atom.refinement_flags = "X"
project.save(str(ROOT / "working" / "structure_plus_WO3_WX.gpx"))
converge(project, passes=7)
show(project, "WO3_WX", "WO3_2106293_test")

# Finally challenge the two free oxygen coordinates in minor Mn3O4.
clear_atom_flags(project)
mn3o4 = project.phase("Mn3O4_9001963")
for atom in mn3o4.atoms():
    if atom.element == "O":
        atom.refinement_flags = "X"
project.save(str(ROOT / "working" / "structure_plus_Mn3O4_OX.gpx"))
converge(project)
show(project, "Mn3O4_OX", "Mn3O4_9001963")
