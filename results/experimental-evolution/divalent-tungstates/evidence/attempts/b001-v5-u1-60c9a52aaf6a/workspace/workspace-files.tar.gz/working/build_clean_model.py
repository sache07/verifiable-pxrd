import copy
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "working"
HIST = "PWDR pattern.csv"
TEMPLATE_FILE = WORK / "structure_plus_WO3_WX.gpx"
OUT = WORK / "clean_model.gpx"


template = G2sc.G2Project(str(TEMPLATE_FILE))
template_hist = template.histogram(HIST)
seed_specs = (
    ("MnWO4_Zn_parent", "MnWO4_wolframite", WORK / "seed_MnWO4.cif"),
    ("WO3_2106293_test", "WO3_triclinic", WORK / "seed_WO3.cif"),
    ("Mn3O4_9001963", "Mn3O4_hausmannite", WORK / "seed_Mn3O4.cif"),
)
for old_name, _, path in seed_specs:
    template.phase(old_name).export_CIF(str(path))

project = G2sc.G2Project(newgpx=str(OUT))
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(WORK / "cu_ka.instprm"),
)
phase_map = {}
for old_name, new_name, path in seed_specs:
    phase_map[new_name] = project.add_phase(
        str(path), phasename=new_name, histograms=[hist]
    )

# Copy the converged histogram model, while retaining the freshly imported
# observed data arrays and the clean three-phase tree.
hist.data["Limits"] = copy.deepcopy(template_hist.data["Limits"])
hist.data["Background"] = copy.deepcopy(template_hist.data["Background"])
hist.data["Instrument Parameters"] = copy.deepcopy(
    template_hist.data["Instrument Parameters"]
)
hist.data["Sample Parameters"] = copy.deepcopy(
    template_hist.data["Sample Parameters"]
)

for old_name, new_name, _ in seed_specs:
    old_hap = template.phase(old_name).data["Histograms"][HIST]
    hap = phase_map[new_name].data["Histograms"][HIST]
    for key in (
        "Scale", "Size", "Mustrain", "Pref.Ori.", "Extinction", "Babinet",
        "HStrain", "Layer Disp", "LeBail", "newLeBail",
    ):
        if key in old_hap and key in hap:
            hap[key] = copy.deepcopy(old_hap[key])
    hap["Use"] = True
    hap["Scale"][1] = False
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"] = [0.0, False]

# Explicitly carry the accepted microstructure values into the clean project.
wo3_hap = phase_map["WO3_triclinic"].data["Histograms"][HIST]
mn3o4_hap = phase_map["Mn3O4_hausmannite"].data["Histograms"][HIST]
mnwo4_hap = phase_map["MnWO4_wolframite"].data["Histograms"][HIST]
mnwo4_hap["Size"][:3] = ["isotropic", [10.0, 1.0e6, 0.5], [False] * 3]
mnwo4_hap["Mustrain"][:3] = ["isotropic", [0.001, 0.001, 0.5], [False] * 3]
wo3_hap["Size"][2] = [False, False, False]
wo3_hap["Mustrain"][2] = [False, False, False]
mn3o4_hap["Size"][:3] = ["isotropic", [10.0, 1.0e6, 0.5], [False] * 3]
mn3o4_hap["Mustrain"][2] = [False, False, False]


def clear_atom_flags():
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = ""


def set_base(flag):
    hist.data["Background"][0][1] = flag
    hist.data["Sample Parameters"]["Shift"][1] = flag
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = flag
        phase.data["Histograms"][HIST]["Scale"][1] = flag


def set_profile(flag):
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "W", "X", "SH/L"):
        inst[key][2] = flag
    inst["Polariz."][2] = flag


def set_micro(flag):
    wo3_hap["Size"][2][0] = flag
    wo3_hap["Mustrain"][2][0] = flag
    mn3o4_hap["Mustrain"][2][0] = flag


def set_atoms(flag):
    clear_atom_flags()
    if not flag:
        return
    for atom in phase_map["MnWO4_wolframite"].atoms():
        atom.refinement_flags = "XU"
    for atom in phase_map["WO3_triclinic"].atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"


def converge(tag, max_passes=5):
    project.save()
    for i in range(max_passes):
        project.refine()
        rv = project.data["Covariance"]["data"]["Rvals"]
        print(
            tag, i, "Rwp", rv["Rwp"], "GOF", rv["GOF"],
            "DelChi2", rv.get("DelChi2"), "MaxShift", rv.get("Max shft/sig"),
        )
        if (
            rv.get("converged")
            and abs(rv.get("DelChi2", 1.0)) < 1.0e-4
            and rv.get("Max shft/sig", 99) < 1.0
        ):
            break
    project.save()


# Physical bounds.
project.set_Controls("cycles", 12)
for phase in project.phases():
    pid = phase.data["pId"]
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
    project.set_Controls("parmMax", 1.0e6, variable=f"{pid}:0:Scale")
for var, low, high in (
    (":0:Shift", -1000.0, 1000.0),
    (":0:U", 0.0, 500.0),
    (":0:W", 0.0, 500.0),
    (":0:X", 0.0, 50.0),
    (":0:SH/L", 0.002, 0.2),
    (":0:Polariz.", 0.0, 1.0),
):
    project.set_Controls("parmMin", low, variable=var)
    project.set_Controls("parmMax", high, variable=var)
wo_pid = phase_map["WO3_triclinic"].data["pId"]
mn3_pid = phase_map["Mn3O4_hausmannite"].data["pId"]
project.set_Controls("parmMin", 0.02, variable=f"{wo_pid}:0:Size;i")
project.set_Controls("parmMax", 10.0, variable=f"{wo_pid}:0:Size;i")
for var in (f"{wo_pid}:0:Mustrain;i", f"{mn3_pid}:0:Mustrain;i"):
    project.set_Controls("parmMin", 0.0, variable=var)
    project.set_Controls("parmMax", 20000.0, variable=var)
mn_pid = phase_map["MnWO4_wolframite"].data["pId"]
for idx, _ in enumerate(phase_map["MnWO4_wolframite"].atoms()):
    project.set_Controls("parmMin", 0.001, variable=f"{mn_pid}::AUiso:{idx}")
    project.set_Controls("parmMax", 0.05, variable=f"{mn_pid}::AUiso:{idx}")

# Ensure zero-only remains disabled and nuisance terms are physically neutral.
inst = hist.data["Instrument Parameters"][0]
inst["Zero"][1:] = [0.0, False]
for key in ("V", "Y", "Z"):
    inst[key][1:] = [0.0, False]
sample = hist.data["Sample Parameters"]
sample["Transparency"] = [0.0, False]
sample["SurfRoughA"] = [0.0, False]
sample["SurfRoughB"] = [0.0, False]

# Staged clean convergence.
set_base(False)
set_profile(False)
set_micro(False)
set_atoms(False)
hist.data["Background"][0][1] = True
for phase in project.phases():
    phase.data["Histograms"][HIST]["Scale"][1] = True
project.save()
converge("scales_background", 3)

set_base(True)
converge("cells_shift", 4)

set_profile(True)
converge("common_profile_polarization", 5)

# Refine accepted microstructure first as a block, then with nuisance terms.
set_base(False)
set_profile(False)
set_micro(True)
converge("micro_only", 4)
set_base(True)
set_profile(True)
converge("micro_full", 5)

# Refine accepted coordinates/Uiso first as a block, then jointly.
set_base(False)
set_profile(False)
set_micro(False)
set_atoms(True)
converge("atoms_only", 4)
set_base(True)
set_profile(True)
set_micro(True)
set_atoms(True)
converge("all_variables", 6)

project.save()
print("fractions", hist.ComputeMassFracs())
print("profile", {k: inst[k][1] for k in ("U", "W", "X", "SH/L", "Polariz.")})
print("sample", sample)
for phase in project.phases():
    hap = phase.data["Histograms"][HIST]
    print(
        phase.name,
        "cell", phase.data["General"]["Cell"],
        "scale", hap["Scale"],
        "size", hap["Size"][:3],
        "strain", hap["Mustrain"][:3],
    )
