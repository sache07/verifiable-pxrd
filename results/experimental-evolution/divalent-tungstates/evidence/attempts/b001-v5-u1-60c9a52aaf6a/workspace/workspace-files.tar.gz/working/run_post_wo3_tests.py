from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
HIST = "PWDR pattern.csv"


TASKS = (
    ("Mn3O4_size", "Mn3O4_9001963", 0.15, None),
    ("Mn3O4_strain", "Mn3O4_9001963", None, 2500.0),
    ("Mn3O4_both", "Mn3O4_9001963", 0.10, 3000.0),
)


def run_one(task):
    from GSASII import GSASIIscriptable as G2sc

    tag, phase_name, size0, strain0 = task
    base = ROOT / "working" / "replay_WO3_both.gpx"
    out = ROOT / "working" / f"postWO3_{tag}.gpx"
    project = G2sc.G2Project(str(base), newgpx=str(out))
    hist = project.histogram(HIST)
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "W", "X", "SH/L"):
        inst[key][2] = False
    # Retain the accepted WO3 broadening values, but hold them fixed while
    # challenging Mn3O4.
    wo3hap = project.phase("WO3_2106293_test").data["Histograms"][HIST]
    wo3hap["Size"][2] = [False, False, False]
    wo3hap["Mustrain"][2] = [False, False, False]
    target = project.phase(phase_name)
    hap = target.data["Histograms"][HIST]
    hap["Size"][:3] = ["isotropic", [10.0, 1.0e6, 0.5], [False, False, False]]
    hap["Mustrain"][:3] = ["isotropic", [0.001, 0.001, 0.5], [False, False, False]]
    pid = target.data["pId"]
    if size0 is not None:
        hap["Size"][1][0] = size0
        hap["Size"][2][0] = True
        project.set_Controls("parmMin", 0.02, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{pid}:0:Size;i")
    if strain0 is not None:
        hap["Mustrain"][1][0] = strain0
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 20000.0, variable=f"{pid}:0:Mustrain;i")
    project.set_Controls("cycles", 12)
    project.save()
    for _ in range(6):
        project.refine()
        rv = project.data["Covariance"]["data"]["Rvals"]
        frozen = project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])
        if frozen:
            break
        if rv.get("converged") and abs(rv.get("DelChi2", 1.0)) < 1.0e-4:
            break
    project.save()
    rv = project.data["Covariance"]["data"]["Rvals"]
    cov = project.data["Covariance"]["data"]
    sig = {str(v): float(s) for v, s in zip(cov.get("varyList", []), cov.get("sig", []))}
    return {
        "tag": tag,
        "Rwp": rv["Rwp"],
        "GOF": rv["GOF"],
        "size": hap["Size"][1][0] if size0 is not None else None,
        "size_sig": sig.get(f"{pid}:0:Size;i"),
        "strain": hap["Mustrain"][1][0] if strain0 is not None else None,
        "strain_sig": sig.get(f"{pid}:0:Mustrain;i"),
        "fractions": hist.ComputeMassFracs(),
        "converged": rv.get("converged"),
        "DelChi2": rv.get("DelChi2"),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
        "file": str(out.relative_to(ROOT)),
    }


if __name__ == "__main__":
    with ProcessPoolExecutor(max_workers=3) as pool:
        futures = [pool.submit(run_one, task) for task in TASKS]
        for future in as_completed(futures):
            print(future.result(), flush=True)
