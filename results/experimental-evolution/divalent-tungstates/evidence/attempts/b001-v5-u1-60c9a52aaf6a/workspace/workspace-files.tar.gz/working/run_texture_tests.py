from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "working" / "shared_polarization.gpx"
HIST = "PWDR pattern.csv"

TASKS = (
    ("MnWO4_Zn_parent", (0, 1, 0)),
    ("MnWO4_Zn_parent", (0, 0, 1)),
    ("MnWO4_Zn_parent", (1, 0, 1)),
    ("WO3_2106293_test", (1, 0, 0)),
    ("WO3_2106293_test", (0, 1, 0)),
    ("WO3_2106293_test", (0, 0, 1)),
    ("WO3_2106293_test", (1, 1, 0)),
    ("Mn3O4_9001963", (0, 0, 1)),
    ("Mn3O4_9001963", (1, 0, 0)),
    ("Mn3O4_9001963", (1, 1, 0)),
)


def run_one(task):
    from GSASII import GSASIIscriptable as G2sc

    phase_name, axis = task
    short = {
        "MnWO4_Zn_parent": "MnWO4",
        "WO3_2106293_test": "WO3",
        "Mn3O4_9001963": "Mn3O4",
    }[phase_name]
    ax = "".join(str(v) for v in axis)
    out = ROOT / "working" / f"texture_{short}_{ax}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = project.histogram(HIST)
    hist.data["Instrument Parameters"][0]["Polariz."][2] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data.get("Histograms", {}).get(HIST)
        if hap is None:
            continue
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][HIST]
    hap["Pref.Ori."][:4] = ["MD", 0.9, True, list(axis)]
    pid = phase.data["pId"]
    project.set_Controls("parmMin", 0.2, variable=f"{pid}:0:MD")
    project.set_Controls("parmMax", 5.0, variable=f"{pid}:0:MD")
    project.set_Controls("cycles", 12)
    project.save()
    for _ in range(5):
        project.refine()
        rv = project.data["Covariance"]["data"]["Rvals"]
        frozen = project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])
        if frozen:
            break
        if rv.get("converged") and abs(rv.get("DelChi2", 1.0)) < 1.0e-4:
            break
    project.save()
    rv = project.data["Covariance"]["data"]["Rvals"]
    cov = project.data["Covariance"]["data"]
    sig = {str(v): float(s) for v, s in zip(cov.get("varyList", []), cov.get("sig", []))}
    return {
        "phase": phase_name,
        "axis": axis,
        "Rwp": rv["Rwp"],
        "GOF": rv["GOF"],
        "MD": hap["Pref.Ori."][1],
        "MD_sig": sig.get(f"{pid}:0:MD"),
        "fractions": hist.ComputeMassFracs(),
        "converged": rv.get("converged"),
        "DelChi2": rv.get("DelChi2"),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
        "file": str(out.relative_to(ROOT)),
    }


if __name__ == "__main__":
    with ProcessPoolExecutor(max_workers=4) as pool:
        futures = [pool.submit(run_one, task) for task in TASKS]
        for future in as_completed(futures):
            print(future.result(), flush=True)
