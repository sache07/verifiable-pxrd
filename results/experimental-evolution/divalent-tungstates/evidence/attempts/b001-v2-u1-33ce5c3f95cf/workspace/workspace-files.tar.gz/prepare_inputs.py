#!/usr/bin/env python3
"""Prepare GSAS-II input files and the Ca3WO6 prototype model."""

from __future__ import annotations

import csv
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
CIF_ROOT = Path(
    "<RUN>/"
    "resources/b001-c05/cif"
)


def cod_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    TMP.mkdir(exist_ok=True)

    with (ROOT / "inputs/pattern.csv").open(newline="") as source, (
        TMP / "pattern.xye"
    ).open("w") as target:
        reader = csv.DictReader(source)
        target.write("# Original counts; Poisson weights assigned by GSAS-II\n")
        for row in reader:
            target.write(f"{row['two_theta_deg']} {row['intensity']}\n")

    (TMP / "cu_ka.instprm").write_text(
        "#GSAS-II instrument parameter file for supplied Cu Kalpha scan\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;"
        "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:0.0;V:0.0;W:80.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )

    # Ca3OsO6 (COD 1562666) is an isostructural, fully occupied P21/n
    # parent. Os6+ -> W6+ is isovalent and preserves the octahedral B site.
    prototype = Structure.from_file(cod_path("1562666"))
    prototype.replace_species({"Os": "W"})
    CifWriter(prototype, symprec=0.01).write_file(TMP / "Ca3WO6_prototype.cif")

    # Preserve the near-orthogonal P21/n parent setting as a second import
    # option. This avoids the strongly correlated oblique P21/c cell selected
    # by pymatgen while leaving fractional coordinates and symmetry unchanged.
    parent_text = cod_path("1562666").read_text()
    parent_text = parent_text.replace("Os", "W")
    parent_text = parent_text.replace("406.44", "400.08")
    (TMP / "Ca3WO6_parent_setting.cif").write_text(parent_text)


if __name__ == "__main__":
    main()
