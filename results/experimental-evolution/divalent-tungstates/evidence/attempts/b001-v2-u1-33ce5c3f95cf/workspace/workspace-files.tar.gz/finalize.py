from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "branch_polarization.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "CaWO4": {
        "formula": "CaWO4",
        "cif_path": "CaWO4.cif",
        "structure_source": "COD 7219229",
    },
    "WO3": {
        "formula": "WO3",
        "cif_path": "WO3.cif",
        "structure_source": "COD 2311041",
    },
    "Ca3WO6": {
        "formula": "Ca3WO6",
        "cif_path": "Ca3WO6.cif",
        "structure_source": (
            "COD 1562666 Ca3OsO6 prototype with isovalent Os6+ -> W6+ substitution"
        ),
    },
}


def neutralize_unused_hap(project: G2sc.G2Project) -> None:
    """Make all rejected phase-broadening terms explicitly neutral."""
    hist = project.histograms()[0]
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["LeBail"] = False
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        if phase.name != "CaWO4":
            # GSAS-II caps this parameter at 10 micrometres when it updates
            # HAP values; that cap is its effectively unbroadened state.
            hap["Size"][1][0] = 10.0
            hap["Size"][2] = [False, False, False]
            hap["Size"][5] = [False] * len(hap["Size"][5])

    controls = project["Controls"]["data"]
    controls.setdefault("parmFrozen", {})["FrozenList"] = []


def refine_to_stability(project: G2sc.G2Project, max_passes: int = 6) -> None:
    for idx in range(max_passes):
        project.do_refinements([{}])
        rvals = project["Covariance"]["data"]["Rvals"]
        shift = abs(float(rvals.get("Max shft/sig", math.inf)))
        delta = abs(float(rvals.get("DelChi2", math.inf)))
        print(
            f"replay pass {idx + 1}: Rwp={rvals['Rwp']:.8f}% "
            f"GOF={rvals['GOF']:.8f} max_shift/esd={shift:.5g} "
            f"|delta_chi2|={delta:.5g}"
        )
        if shift < 0.01 and delta < 2.0e-5:
            break
    project.save()


def largest_correlations(project: G2sc.G2Project, count: int = 8):
    cov = project["Covariance"]["data"]
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    variables = [str(v) for v in cov.get("varyList", [])]
    if matrix.size == 0:
        return []
    sig = np.sqrt(np.clip(np.diag(matrix), 0.0, None))
    denom = np.outer(sig, sig)
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
    pairs = []
    for i in range(len(variables)):
        for j in range(i):
            pairs.append((abs(float(corr[i, j])), float(corr[i, j]), variables[i], variables[j]))
    pairs.sort(reverse=True)
    return pairs[:count]


def main() -> None:
    if not SOURCE.exists():
        raise FileNotFoundError(SOURCE)

    # Make the clean final branch and save before replaying it from disk.
    project = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    neutralize_unused_hap(project)
    project.save()

    # First full-pattern native-structure replay after reopening.
    project = G2sc.G2Project(gpxfile=str(FINAL))
    hist = project.histograms()[0]
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    if any(p.data["Histograms"][hist.name]["LeBail"] for p in project.phases()):
        raise RuntimeError("Le Bail mode must be off for the atomic replay")
    refine_to_stability(project)

    # Reopen once more and perform the final replay used for every export.
    project = G2sc.G2Project(gpxfile=str(FINAL))
    refine_to_stability(project)
    hist = project.histograms()[0]

    frozen = project.get_Frozen()
    if frozen:
        raise RuntimeError(f"Final project contains frozen variables: {frozen}")
    if any(p.data["Histograms"][hist.name]["LeBail"] for p in project.phases()):
        raise RuntimeError("Final project contains a Le Bail phase")

    mass_fractions = hist.ComputeMassFracs()
    if not math.isclose(sum(v[0] for v in mass_fractions.values()), 1.0, abs_tol=1e-10):
        raise RuntimeError("Crystalline mass fractions do not sum to unity")

    phase_results = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        cif_path = ROOT / info["cif_path"]
        phase.export_CIF(str(cif_path))
        fraction, esd = mass_fractions[phase.name]
        cell = phase.data["General"]["Cell"]
        phase_results.append(
            {
                "name": phase.name,
                "formula": info["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": info["cif_path"],
                "weight_fraction": float(fraction),
                "weight_fraction_formal_esd": float(esd),
                "weight_percent": 100.0 * float(fraction),
                "refined_cell_angstrom_deg": {
                    "a": float(cell[1]),
                    "b": float(cell[2]),
                    "c": float(cell[3]),
                    "alpha": float(cell[4]),
                    "beta": float(cell[5]),
                    "gamma": float(cell[6]),
                    "volume_angstrom3": float(cell[7]),
                },
                "structure_source": info["structure_source"],
            }
        )

    profile = np.ma.asarray(hist.data["data"][1]).filled(np.nan)
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_observed_minus_calculated",
                "calculated_background",
            ]
        )
        for x, obs, calc, bkg in zip(profile[0], profile[1], profile[3], profile[4]):
            writer.writerow(
                [
                    f"{x:.8f}",
                    f"{obs:.8f}",
                    f"{calc:.8f}",
                    f"{obs - calc:.8f}",
                    f"{bkg:.8f}",
                ]
            )

    rvals = project["Covariance"]["data"]["Rvals"]
    hist_stats = hist.data["data"][0]
    result = {
        "phases": phase_results,
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "modeled_crystalline_weight_fraction_sum": sum(
            item["weight_fraction"] for item in phase_results
        ),
        "fit_statistics": {
            "Rp_percent": float(hist_stats["R"]),
            "Rwp_percent": float(rvals["Rwp"]),
            "Rexp_percent": float(hist_stats["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "reduced_chi_square": float(rvals["GOF"]) ** 2,
            "n_observations": int(rvals["Nobs"]),
            "n_variables": int(rvals["Nvars"]),
            "durbin_watson": float(hist_stats["Durbin-Watson"]),
        },
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
    }
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")

    print("mass fractions", mass_fractions)
    print("largest absolute correlations")
    for absolute, signed, var1, var2 in largest_correlations(project):
        print(f"  |r|={absolute:.5f} r={signed:+.5f}: {var1} / {var2}")
    print("frozen variables", frozen)
    print("wrote", FINAL, ROOT / "fit.csv", ROOT / "result.json")


if __name__ == "__main__":
    main()
