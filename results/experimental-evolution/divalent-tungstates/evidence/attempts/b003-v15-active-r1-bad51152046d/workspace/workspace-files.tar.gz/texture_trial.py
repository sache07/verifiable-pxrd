#!/usr/bin/env python3
"""Test one March-Dollase texture axis from a common saved checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("h", type=int)
    parser.add_argument("k", type=int)
    parser.add_argument("l", type=int)
    parser.add_argument("--baseline", type=Path, default=Path(".tmp/broad_accepted.gpx"))
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.baseline), newgpx=str(args.output))
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = [args.h, args.k, args.l]
    project.set_Controls("cycles", 16)
    project.save()

    history = []
    for _ in range(8):
        project = G2sc.G2Project(str(args.output))
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(args.output))
        hist = project.histogram(0)
        phase = project.phase(args.phase)
        pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        history.append(
            {
                "Rwp": hist.residuals.get("wR"),
                "ratio": pref[1],
                "max_shift_over_sigma": rvals.get("Max shft/sig"),
            }
        )
        shift = rvals.get("Max shft/sig")
        if shift is not None and abs(float(shift)) < 0.05:
            break

    summary = {
        "project": str(args.output),
        "phase": args.phase,
        "axis": [args.h, args.k, args.l],
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "GOF": rvals.get("GOF"),
        "ratio": pref[1],
        "history": history,
        "fractions": {
            key: value[0] for key, value in hist.ComputeMassFracs().items()
        },
        "frozen": list(map(str, project.get_Frozen() or [])),
    }
    print("TEXTURE_SUMMARY " + json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
