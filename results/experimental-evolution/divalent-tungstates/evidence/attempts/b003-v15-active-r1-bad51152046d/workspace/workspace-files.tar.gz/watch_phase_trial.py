#!/usr/bin/env python3
"""Challenge one watch-list phase against the converged common profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cif_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("cod_id")
    parser.add_argument("name")
    parser.add_argument("--baseline", type=Path, default=Path(".tmp/common_positive.gpx"))
    parser.add_argument("--scale", type=float, default=0.05)
    parser.add_argument("--refine-cell", action="store_true")
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.baseline), newgpx=str(args.output))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cif_path(args.cod_id)),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    phase.HAPvalue("Scale", args.scale, targethistlist=[hist])
    phase.set_HAP_refinements({"Scale": True})
    phase.set_refinements({"Cell": args.refine_cell})
    project.set_Controls("cycles", 16)
    project.save()

    history = []
    for _ in range(8):
        project = G2sc.G2Project(str(args.output))
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(args.output))
        hist = project.histogram(0)
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        history.append(
            {
                "Rwp": hist.residuals.get("wR"),
                "candidate_scale": project.phase(args.name).HAPvalue(
                    "Scale", targethistlist=[hist]
                ),
                "max_shift_over_sigma": rvals.get("Max shft/sig"),
            }
        )
        shift = rvals.get("Max shft/sig")
        if shift is not None and abs(float(shift)) < 0.05:
            break

    fractions = hist.ComputeMassFracs()
    summary = {
        "project": str(args.output),
        "candidate": args.name,
        "cod_id": args.cod_id,
        "refine_cell": args.refine_cell,
        "history": history,
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "frozen": list(map(str, project.get_Frozen() or [])),
        "phases": [],
    }
    for item in project.phases():
        summary["phases"].append(
            {
                "name": item.name,
                "scale": item.HAPvalue("Scale", targethistlist=[hist]),
                "weight_fraction": fractions.get(item.name, (None, None))[0],
                "weight_fraction_esd": fractions.get(item.name, (None, None))[1],
                "cell": item.get_cell(),
            }
        )
    print("WATCH_SUMMARY " + json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
