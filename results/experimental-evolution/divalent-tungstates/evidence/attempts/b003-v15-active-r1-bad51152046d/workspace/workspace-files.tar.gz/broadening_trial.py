#!/usr/bin/env python3
"""Compare phase-specific size/strain terms from one saved checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("mode", choices=("neutral", "size", "strain", "combined"))
    parser.add_argument("--baseline", type=Path, default=Path(".tmp/profile_ux.gpx"))
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.baseline), newgpx=str(args.output))
    hist = project.histogram(0)
    target = project.phase(args.phase)
    hap = target.data["Histograms"][hist.name]
    if args.mode in ("size", "combined"):
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 2.0
        hap["Size"][1][2] = 1.0
        hap["Size"][2] = [True, False, False]
    if args.mode in ("strain", "combined"):
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2] = [True, False, False]

    project.set_Controls("cycles", 16)
    project.save()
    history = []
    for _ in range(8):
        project = G2sc.G2Project(str(args.output))
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(args.output))
        hist = project.histogram(0)
        target = project.phase(args.phase)
        hap = target.data["Histograms"][hist.name]
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        history.append(
            {
                "Rwp": hist.residuals.get("wR"),
                "max_shift_over_sigma": rvals.get("Max shft/sig"),
                "size_um": hap["Size"][1][0],
                "microstrain": hap["Mustrain"][1][0],
            }
        )
        shift = rvals.get("Max shft/sig")
        if shift is not None and abs(float(shift)) < 0.05:
            break

    summary = {
        "project": str(args.output),
        "phase": args.phase,
        "mode": args.mode,
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "GOF": rvals.get("GOF"),
        "history": history,
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "profile": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "fractions": {
            key: value[0] for key, value in hist.ComputeMassFracs().items()
        },
        "frozen": list(map(str, project.get_Frozen() or [])),
    }
    print("BROADENING_SUMMARY " + json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
