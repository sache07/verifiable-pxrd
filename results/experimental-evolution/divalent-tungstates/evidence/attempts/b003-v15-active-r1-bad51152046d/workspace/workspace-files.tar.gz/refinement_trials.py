#!/usr/bin/env python3
"""Build reproducible GSAS-II inventory/source trials on one common baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cif_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def parse_phase(spec: str) -> tuple[str, str, float]:
    cod_id, name, scale = spec.split(":", 2)
    return cod_id, name, float(scale)


def replay(path: Path, count: int = 10) -> G2sc.G2Project:
    for _ in range(count):
        project = G2sc.G2Project(str(path))
        project.set_Controls("cycles", 16)
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(path))
        shift = project.data.get("Covariance", {}).get("data", {}).get(
            "Rvals", {}
        ).get("Max shft/sig")
        if shift is not None and abs(float(shift)) < 0.05:
            return project
    return project


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", nargs="+", type=parse_phase)
    parser.add_argument("--baseline", type=Path, default=Path(".tmp/common_positive.gpx"))
    args = parser.parse_args()

    baseline = G2sc.G2Project(str(args.baseline))
    baseline_hist = baseline.histogram(0)
    base_inst = baseline_hist.InstrumentParameters
    base_background = baseline_hist.Background[0]

    project = G2sc.G2Project(newgpx=str(args.output))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": len(base_background) - 3,
                "coeffs": list(base_background[3:]),
            }
        }
    )
    for key in ("U", "V", "W", "Y", "Z"):
        hist.InstrumentParameters[key][0] = 0.0
        hist.InstrumentParameters[key][1] = 0.0
        hist.InstrumentParameters[key][2] = False
    # A small fixed Gaussian floor avoids numerical underflow for dense,
    # low-symmetry reflection lists while keeping the common profile neutral.
    hist.InstrumentParameters["W"][0] = 1.0
    hist.InstrumentParameters["W"][1] = 1.0
    for key in ("Zero", "X"):
        value = float(base_inst[key][1])
        hist.InstrumentParameters[key][0] = value
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = True
    hist.InstrumentParameters["SH/L"][0] = 0.002
    hist.InstrumentParameters["SH/L"][1] = 0.002
    hist.InstrumentParameters["SH/L"][2] = False

    source_ids = {}
    for cod_id, name, scale in args.phase:
        phase = project.add_phase(
            str(cif_path(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase.HAPvalue("Scale", scale, targethistlist=[hist])
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})
        source_ids[name] = cod_id

    project.set_Controls("cycles", 16)
    project.save()
    project = replay(args.output)
    hist = project.histogram(0)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    fractions = hist.ComputeMassFracs()
    summary = {
        "project": str(args.output),
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "GOF": rvals.get("GOF"),
        "max_shift_over_sigma": rvals.get("Max shft/sig"),
        "frozen": list(map(str, project.get_Frozen() or [])),
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "phases": [],
    }
    for phase in project.phases():
        summary["phases"].append(
            {
                "name": phase.name,
                "cod_id": source_ids[phase.name],
                "scale": phase.HAPvalue("Scale", targethistlist=[hist]),
                "weight_fraction": fractions.get(phase.name, (None, None))[0],
                "weight_fraction_esd": fractions.get(phase.name, (None, None))[1],
                "cell": phase.get_cell(),
            }
        )
    print("TRIAL_SUMMARY " + json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
