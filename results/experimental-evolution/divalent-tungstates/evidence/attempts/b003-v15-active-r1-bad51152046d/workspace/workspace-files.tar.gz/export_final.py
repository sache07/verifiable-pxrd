#!/usr/bin/env python3
"""Export all submission artifacts from the exact saved final GSAS-II project."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


PROJECT = Path("final.gpx")
CIF_PATHS = {
    "Cu3WO6": Path("Cu3WO6.cif"),
    "WO3_monoclinic": Path("WO3_monoclinic.cif"),
    "CuO_C2c": Path("CuO.cif"),
}
PHASE_LABELS = {
    "Cu3WO6": "Cu3WO6 (cubic Pa-3)",
    "WO3_monoclinic": "WO3 (monoclinic P21/n)",
    "CuO_C2c": "CuO (tenorite, C2/c)",
}


def main() -> None:
    project = G2sc.G2Project(str(PROJECT))
    histograms = project.histograms()
    if len(histograms) != 1:
        raise RuntimeError(f"expected one final histogram, found {len(histograms)}")
    histogram = histograms[0]

    for phase in project.phases():
        phase.export_CIF(str(CIF_PATHS[phase.name]))

    x = np.asarray(histogram.getdata("X"), dtype=float)
    observed = np.asarray(histogram.getdata("Yobs"), dtype=float)
    calculated = np.asarray(histogram.getdata("Ycalc"), dtype=float)
    difference = np.asarray(histogram.getdata("Residual"), dtype=float)
    background = np.asarray(histogram.getdata("Background"), dtype=float)
    if not (
        len(x)
        == len(observed)
        == len(calculated)
        == len(difference)
        == len(background)
        == 8301
    ):
        raise RuntimeError("final profile arrays do not preserve the original grid")

    with Path("fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_observed_minus_calculated",
                "calculated_background",
            ]
        )
        writer.writerows(zip(x, observed, calculated, difference, background))

    fractions = histogram.ComputeMassFracs()
    total = sum(value[0] for value in fractions.values())
    residuals = histogram.residuals
    rvals = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "refinement_project": str(PROJECT),
        "refinement_histogram": histogram.name,
        "weight_fraction_basis": "normalized over modeled crystalline phases",
        "phases": [],
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_variables": int(rvals["Nvars"]),
            "max_shift_over_sigma": float(rvals["Max shft/sig"]),
        },
    }
    for phase in project.phases():
        fraction, esd = fractions[phase.name]
        result["phases"].append(
            {
                "name": PHASE_LABELS[phase.name],
                "project_phase_name": phase.name,
                "cif_path": str(CIF_PATHS[phase.name]),
                "weight_fraction": float(fraction / total),
                "weight_percent": float(100.0 * fraction / total),
                "formal_weight_fraction_esd": float(esd / total),
            }
        )

    with Path("result.json").open("w") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")


if __name__ == "__main__":
    main()
