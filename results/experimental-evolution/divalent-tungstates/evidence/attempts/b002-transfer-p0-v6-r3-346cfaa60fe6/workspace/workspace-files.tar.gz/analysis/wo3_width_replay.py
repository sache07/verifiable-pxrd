#!/usr/bin/env python3
"""Check path stability of WO3 size/strain after adopting the 1966 source."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/trials/uwx_wo3_1966.gpx"


def snapshot(project, stage: str) -> dict:
    histogram = project.histogram(0)
    phase = project.phase("WO3")
    pid = phase.data["pId"]
    cov = project.data["Covariance"]["data"]
    names = list(map(str, cov.get("varyList", [])))
    values = np.asarray(cov.get("variables", []), dtype=float)
    sigmas = np.asarray(cov.get("sig", []), dtype=float)
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    parameters = {}
    indices = {}
    for label, suffix in (("size_micrometre", "Size;i"), ("strain_microstrain", "Mustrain;i")):
        name = f"{pid}:0:{suffix}"
        if name in names:
            index = names.index(name)
            indices[label] = index
            parameters[label] = {"value": float(values[index]), "sigma": float(sigmas[index])}
    correlation = None
    if len(indices) == 2:
        first, second = indices.values()
        correlation = float(matrix[first, second] / (sigmas[first] * sigmas[second]))
    return {
        "stage": stage,
        "Rwp_percent": float(histogram.residuals["wR"]),
        "parameters": parameters,
        "size_strain_correlation": correlation,
        "fractions": {
            name: [float(value[0]), float(value[1])]
            for name, value in histogram.ComputeMassFracs().items()
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", required=True, choices=("size_only", "both_low_seed"))
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    output = ROOT / f".tmp/trials/wo3_1966_width_{args.mode}.gpx"
    project = G2sc.G2Project(gpxfile=SOURCE, newgpx=output)
    histogram = project.histogram(0)
    phase = project.phase("WO3")
    hap = phase.data["Histograms"][histogram.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [0.3 if args.mode == "size_only" else 0.1, 10.0, 1.0]
    hap["Size"][2][:] = [True, False, False]
    hap["Mustrain"][0] = "isotropic"
    if args.mode == "size_only":
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
    else:
        hap["Mustrain"][1][:] = [500.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [True, False, False]

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 15
    controls["min dM/M"] = 1.0e-7
    controls["shift factor"] = 0.3
    stages = []
    for label in ("refine", "reconverge"):
        project.refine(makeBack=False)
        stages.append(snapshot(project, label))
    project.save(output)
    project = G2sc.G2Project(gpxfile=output)
    project.refine(makeBack=False)
    stages.append(snapshot(project, "reopen_replay"))
    project.save(output)
    result = {"mode": args.mode, "source": str(SOURCE), "project": str(output), "stages": stages}
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
