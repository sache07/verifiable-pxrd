#!/usr/bin/env python3
"""Compare one phase-specific isotropic size or strain term by replay."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TRIALS = ROOT / ".tmp/trials"
SOURCE = TRIALS / "four_common_roughB.gpx"


def safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", value).strip("_")


def covariance_value(project, exact_name: str) -> tuple[float | None, float | None]:
    cov = project.data.get("Covariance", {}).get("data", {})
    for name, value, sigma in zip(
        cov.get("varyList", []), cov.get("variables", []), cov.get("sig", [])
    ):
        if str(name) == exact_name:
            return float(value), float(sigma)
    return None, None


def snapshot(project, phase_name: str, term: str, stage: str) -> dict:
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][hist.name]
    parameter = f"{phase.data['pId']}:0:{'Size;i' if term == 'size' else 'Mustrain;i'}"
    value, sigma = covariance_value(project, parameter)
    return {
        "stage": stage,
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "parameter": parameter,
        "value": value,
        "sigma": sigma,
        "value_over_sigma": None if value is None or not sigma else value / sigma,
        "profile_record": hap["Size"] if term == "size" else hap["Mustrain"],
        "fractions": {
            name: [float(item[0]), float(item[1])]
            for name, item in hist.ComputeMassFracs().items()
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=SOURCE)
    parser.add_argument("--prefix", default="four_width")
    parser.add_argument(
        "--phase",
        required=True,
        choices=("BaWO4", "WO3", "Ba3W2O9", "BaCO3_watch"),
    )
    parser.add_argument("--term", required=True, choices=("size", "strain"))
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    stem = f"{safe_name(args.prefix)}_{safe_name(args.phase)}_{args.term}"
    output = TRIALS / f"{stem}.gpx"
    project = G2sc.G2Project(gpxfile=args.source, newgpx=output)
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    if args.term == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [0.5, 10.0, 1.0]
        hap["Size"][2][:] = [True, False, False]
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [1000.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [True, False, False]

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-6
    controls["shift factor"] = 0.35

    stages = []
    for label in ("refine", "reconverge"):
        project.refine(makeBack=False)
        stages.append(snapshot(project, args.phase, args.term, label))
    project.save(output)

    project = G2sc.G2Project(gpxfile=output)
    project.refine(makeBack=False)
    stages.append(snapshot(project, args.phase, args.term, "reopen_replay"))
    project.save(output)

    result = {
        "source": str(args.source),
        "project": str(output),
        "phase": args.phase,
        "term": args.term,
        "stages": stages,
    }
    (TRIALS / f"{stem}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
