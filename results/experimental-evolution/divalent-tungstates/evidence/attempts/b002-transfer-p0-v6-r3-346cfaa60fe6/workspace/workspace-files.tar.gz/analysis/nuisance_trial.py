#!/usr/bin/env python3
"""Replay one common-profile nuisance alternative from the accepted baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TRIALS = ROOT / ".tmp/trials"
SOURCE = TRIALS / "four_strain_base.gpx"


def covariance_items(project, token: str) -> list[dict]:
    cov = project.data.get("Covariance", {}).get("data", {})
    result = []
    for name, value, sigma in zip(
        cov.get("varyList", []), cov.get("variables", []), cov.get("sig", [])
    ):
        if token in str(name):
            result.append({"name": str(name), "value": float(value), "sigma": float(sigma)})
    return result


def strongest_correlations(project, threshold: float = 0.80) -> list[dict]:
    cov = project.data.get("Covariance", {}).get("data", {})
    names = [str(item) for item in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    sigmas = np.asarray(cov.get("sig", []), dtype=float)
    if matrix.ndim != 2 or len(sigmas) != len(names):
        return []
    denom = np.outer(sigmas, sigmas)
    with np.errstate(divide="ignore", invalid="ignore"):
        corr = np.where(denom > 0, matrix / denom, 0.0)
    result = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            value = float(corr[i, j])
            if abs(value) >= threshold:
                result.append({"a": names[i], "b": names[j], "correlation": value})
    result.sort(key=lambda item: abs(item["correlation"]), reverse=True)
    return result[:12]


def snapshot(project, token: str, stage: str) -> dict:
    hist = project.histogram(0)
    return {
        "stage": stage,
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "parameters": covariance_items(project, token),
        "strong_correlations": strongest_correlations(project),
        "instrument": {
            key: float(hist.InstrumentParameters[key][1])
            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
        },
        "roughness": {
            "A": float(hist.SampleParameters["SurfRoughA"][0]),
            "B": float(hist.SampleParameters["SurfRoughB"][0]),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=SOURCE)
    parser.add_argument("--prefix", default="four_nuisance")
    parser.add_argument("--term", required=True, choices=("W", "SHL", "polarization", "roughA"))
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    output = TRIALS / f"{args.prefix}_{args.term}.gpx"
    project = G2sc.G2Project(gpxfile=args.source, newgpx=output)
    hist = project.histogram(0)
    if args.term == "W":
        hist.InstrumentParameters["W"][1:] = [1.0, True]
        token = ":W"
    elif args.term == "SHL":
        hist.InstrumentParameters["SH/L"][1:] = [0.002, True]
        token = "SH/L"
    elif args.term == "polarization":
        hist.InstrumentParameters["Polariz."][1:] = [0.7, True]
        token = "Polariz"
    else:
        hist.SampleParameters["SurfRoughA"][:] = [0.02, True]
        token = "SurfRough"

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-6
    controls["shift factor"] = 0.35

    stages = []
    for label in ("refine", "reconverge"):
        project.refine(makeBack=False)
        stages.append(snapshot(project, token, label))
    project.save(output)
    project = G2sc.G2Project(gpxfile=output)
    project.refine(makeBack=False)
    stages.append(snapshot(project, token, "reopen_replay"))
    project.save(output)

    result = {
        "source": str(args.source),
        "project": str(output),
        "term": args.term,
        "stages": stages,
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
