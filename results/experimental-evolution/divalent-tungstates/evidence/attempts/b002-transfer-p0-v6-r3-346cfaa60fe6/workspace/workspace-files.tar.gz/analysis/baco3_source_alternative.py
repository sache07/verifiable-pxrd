#!/usr/bin/env python3
"""Compare a physically regular witherite record under the final nuisance model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import cod_path, neutralize_phase_profile


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/trials/wo3_1966_width_both_low_seed.gpx"
OUTPUT = ROOT / ".tmp/trials/source1966_baco3_1935.gpx"
ALTERNATE = ROOT / "analysis/candidates/baco3_1935_compatible.cif"


def remove_phase(project, name: str) -> None:
    del project.data["Phases"][name]
    for item in project.names:
        if item and item[0] == "Phases" and name in item:
            item.remove(name)
    for histogram in project.histograms():
        histogram.data.get("Reflection Lists", {}).pop(name, None)
    project.update_ids()


def snapshot(project, stage: str) -> dict:
    histogram = project.histogram(0)
    phase = project.phase("BaCO3_watch")
    return {
        "stage": stage,
        "Rwp_percent": float(histogram.residuals["wR"]),
        "Rp_percent": float(histogram.residuals["R"]),
        "fractions": {
            name: [float(value[0]), float(value[1])]
            for name, value in histogram.ComputeMassFracs().items()
        },
        "BaCO3_cell": {key: float(value) for key, value in phase.get_cell().items()},
        "BaCO3_strain": float(phase.data["Histograms"][histogram.name]["Mustrain"][1][0]),
        "profile": {
            key: float(histogram.InstrumentParameters[key][1])
            for key in ("U", "W", "X", "Zero")
        },
    }


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(gpxfile=SOURCE, newgpx=OUTPUT)
    histogram = project.histogram(0)
    old = project.phase("BaCO3_watch")
    old_hap = old.data["Histograms"][histogram.name]
    initial_scale = float(old_hap["Scale"][0])
    initial_strain = float(old_hap["Mustrain"][1][0])
    remove_phase(project, "BaCO3_watch")

    histogram = project.histogram(0)
    phase = project.add_phase(
        ALTERNATE,
        phasename="BaCO3_watch",
        histograms=[histogram],
        fmthint="CIF",
    )
    neutralize_phase_profile(phase, histogram.name)
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"][:] = [initial_scale, True]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [initial_strain, 0.0, 1.0]
    hap["Mustrain"][2][:] = [True, False, False]
    phase.data["General"]["Cell"][0] = True
    for atom in phase.atoms():
        atom.refinement_flags = " "

    histogram = project.histogram(0)
    histogram.data["Background"][0][1] = True
    histogram.SampleParameters["SurfRoughB"][1] = True
    for key in ("Zero", "U", "W", "X"):
        histogram.InstrumentParameters[key][2] = True
    for existing in project.phases():
        existing.data["General"]["Cell"][0] = True
        existing.data["Histograms"][histogram.name]["Scale"][1] = True

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 15
    controls["min dM/M"] = 1.0e-7
    controls["shift factor"] = 0.3
    stages = []
    for index in range(4):
        project.refine(makeBack=False)
        stages.append(snapshot(project, f"reconverge_{index + 1}"))
    project.save(OUTPUT)
    project = G2sc.G2Project(gpxfile=OUTPUT)
    project.refine(makeBack=False)
    stages.append(snapshot(project, "reopen_replay"))
    project.save(OUTPUT)

    result = {
        "source": str(SOURCE),
        "replacement": "BaCO3 COD 1011149 (1935 witherite)",
        "project": str(OUTPUT),
        "stages": stages,
    }
    OUTPUT.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
