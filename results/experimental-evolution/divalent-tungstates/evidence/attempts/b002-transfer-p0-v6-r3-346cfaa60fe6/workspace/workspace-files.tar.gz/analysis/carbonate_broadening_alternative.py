#!/usr/bin/env python3
"""Replay a carbonate size-only alternative to quantify fraction sensitivity."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/trials/uwx_strain_base.gpx"
OUTPUT = ROOT / ".tmp/trials/uwx_alt_baco3_size.gpx"


def snapshot(project, stage: str) -> dict:
    hist = project.histogram(0)
    phase = project.phase("BaCO3_watch")
    hap = phase.data["Histograms"][hist.name]
    cov = project.data["Covariance"]["data"]
    values = dict(zip(map(str, cov.get("varyList", [])), zip(cov.get("variables", []), cov.get("sig", []))))
    key = f"{phase.data['pId']}:0:Size;i"
    value, sigma = values.get(key, (None, None))
    return {
        "stage": stage,
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "carbonate_size_micrometre": None if value is None else float(value),
        "carbonate_size_sigma": None if sigma is None else float(sigma),
        "carbonate_profile": {"Size": hap["Size"], "Mustrain": hap["Mustrain"]},
        "fractions": {
            name: [float(item[0]), float(item[1])]
            for name, item in hist.ComputeMassFracs().items()
        },
    }


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(gpxfile=SOURCE, newgpx=OUTPUT)
    hist = project.histogram(0)
    phase = project.phase("BaCO3_watch")
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [0.06, 10.0, 1.0]
    hap["Size"][2][:] = [True, False, False]

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-6
    controls["shift factor"] = 0.35
    stages = []
    for label in ("refine", "reconverge"):
        project.refine(makeBack=False)
        stages.append(snapshot(project, label))
    project.save(OUTPUT)
    project = G2sc.G2Project(gpxfile=OUTPUT)
    project.refine(makeBack=False)
    stages.append(snapshot(project, "reopen_replay"))
    project.save(OUTPUT)

    result = {"source": str(SOURCE), "project": str(OUTPUT), "stages": stages}
    OUTPUT.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
