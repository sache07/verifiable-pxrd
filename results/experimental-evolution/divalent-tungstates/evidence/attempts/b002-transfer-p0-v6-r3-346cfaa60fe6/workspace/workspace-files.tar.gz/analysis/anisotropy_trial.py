#!/usr/bin/env python3
"""Challenge an accepted isotropic strain term with a uniaxial alternative."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TRIALS = ROOT / ".tmp/trials"
SOURCE = TRIALS / "four_strain_base.gpx"


def covariance(project, parameter: str) -> tuple[float | None, float | None]:
    cov = project.data.get("Covariance", {}).get("data", {})
    for name, value, sigma in zip(
        cov.get("varyList", []), cov.get("variables", []), cov.get("sig", [])
    ):
        if str(name) == parameter:
            return float(value), float(sigma)
    return None, None


def snapshot(project, phase_name: str, stage: str) -> dict:
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    prefix = f"{phase.data['pId']}:0:Mustrain"
    parameters = {}
    for suffix in ("i", "a"):
        value, sigma = covariance(project, f"{prefix};{suffix}")
        parameters[suffix] = {
            "value": value,
            "sigma": sigma,
            "value_over_sigma": None if value is None or not sigma else value / sigma,
        }
    return {
        "stage": stage,
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "parameters": parameters,
        "record": phase.data["Histograms"][hist.name]["Mustrain"],
        "fractions": {
            name: [float(item[0]), float(item[1])]
            for name, item in hist.ComputeMassFracs().items()
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=SOURCE)
    parser.add_argument("--prefix", default="four_aniso")
    parser.add_argument("--phase", required=True, choices=("WO3", "Ba3W2O9", "BaCO3_watch"))
    parser.add_argument("--axis", required=True, help="Three comma-separated Miller indices")
    args = parser.parse_args()
    axis = [int(value) for value in args.axis.split(",")]
    if len(axis) != 3 or axis == [0, 0, 0]:
        raise ValueError("--axis must contain three nonzero-as-a-vector integers")

    G2sc.SetPrintLevel("warn")
    axis_tag = "".join(str(value).replace("-", "m") for value in axis)
    phase_tag = args.phase.replace("_watch", "")
    output = TRIALS / f"{args.prefix}_{phase_tag}_{axis_tag}.gpx"
    project = G2sc.G2Project(gpxfile=args.source, newgpx=output)
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    record = phase.data["Histograms"][hist.name]["Mustrain"]
    initial = float(record[1][0])
    record[0] = "uniaxial"
    record[1][:] = [initial, initial, 1.0]
    record[2][:] = [True, True, False]
    record[3][:] = axis

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-6
    controls["shift factor"] = 0.35

    stages = []
    for label in ("refine", "reconverge"):
        project.refine(makeBack=False)
        stages.append(snapshot(project, args.phase, label))
    project.save(output)
    project = G2sc.G2Project(gpxfile=output)
    project.refine(makeBack=False)
    stages.append(snapshot(project, args.phase, "reopen_replay"))
    project.save(output)

    result = {
        "source": str(args.source),
        "project": str(output),
        "phase": args.phase,
        "axis": axis,
        "stages": stages,
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
