#!/usr/bin/env python3
"""Replay the accepted model and export all deliverables from the exact final GPX."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/trials/source1966_baco3_1935.gpx"
FINAL = ROOT / "final.gpx"
FIT = ROOT / "fit.csv"
RESULT = ROOT / "result.json"

PHASE_INFO = {
    "BaWO4": {
        "formula": "BaWO4",
        "space_group_number": 88,
        "cif_path": "phase_BaWO4.cif",
        "structure_source": "ordered EuWO4 prototype, COD 1561850; Eu2+ replaced by Ba2+",
    },
    "WO3": {
        "formula": "WO3",
        "space_group_number": 14,
        "cif_path": "phase_WO3.cif",
        "structure_source": "COD 2311041 (1966 neutron model)",
    },
    "Ba3W2O9": {
        "formula": "Ba3W2O9",
        "space_group_number": 167,
        "cif_path": "phase_Ba3W2O9.cif",
        "structure_source": "COD 1533878",
    },
    "BaCO3": {
        "formula": "BaCO3",
        "space_group_number": 62,
        "cif_path": "phase_BaCO3.cif",
        "structure_source": "COD 1011149 transformed into a GSAS-II-compatible Pmcn setting",
    },
}


def rename_phase(project, old: str, new: str) -> None:
    phases = project.data["Phases"]
    if old not in phases:
        return
    if new in phases:
        raise ValueError(f"Cannot rename {old}: {new} already exists")
    phases[new] = phases.pop(old)
    phases[new]["General"]["Name"] = new
    for item in project.names:
        if item and item[0] == "Phases" and old in item:
            item[item.index(old)] = new
    for histogram in project.histograms():
        reflections = histogram.data.get("Reflection Lists", {})
        if old in reflections:
            reflections[new] = reflections.pop(old)


def enforce_accepted_model(project) -> None:
    histogram = project.histogram(0)
    background = histogram.data["Background"][0]
    if background[0] != "chebyschev-1" or int(background[2]) != 6:
        raise ValueError("Expected the accepted six-term Chebyshev background")
    background[1] = True

    sample = histogram.SampleParameters
    sample["Scale"][:] = [1.0, False]
    sample["Shift"][:] = [0.0, False]
    sample["Transparency"][:] = [0.0, False]
    sample["SurfRoughA"][:] = [0.0, False]
    sample["SurfRoughB"][1] = True

    instrument = histogram.InstrumentParameters
    instrument["Lam1"][1:] = [1.540598, False]
    instrument["Lam2"][1:] = [1.544426, False]
    instrument["I(L2)/I(L1)"][1:] = [0.5, False]
    instrument["Polariz."][1:] = [0.7, False]
    instrument["SH/L"][1:] = [0.002, False]
    for key in ("V", "Y", "Z"):
        instrument[key][1:] = [0.0, False]
    for key in ("Zero", "U", "W", "X"):
        instrument[key][2] = True

    strained = {"WO3", "Ba3W2O9", "BaCO3"}
    sized = {"WO3"}
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][histogram.name]
        hap["Use"] = True
        hap["LeBail"] = False
        hap["Scale"][1] = True
        hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
        hap["Size"][0] = "isotropic"
        if phase.name in sized:
            hap["Size"][2][:] = [True, False, False]
        else:
            hap["Size"][1][:] = [10.0, 10.0, 1.0]
            hap["Size"][2][:] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        if phase.name in strained:
            hap["Mustrain"][2][:] = [True, False, False]
        else:
            hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
            hap["Mustrain"][2][:] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"][:] = [0.0, False]
        hap["Babinet"]["BabA"][:] = [0.0, False]
        hap["Babinet"]["BabU"][:] = [0.0, False]

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-7
    controls["shift factor"] = 0.35


def export_fit(histogram) -> None:
    arrays = histogram.data["data"][1]
    two_theta = np.asarray(arrays[0], dtype=float)
    observed = np.asarray(arrays[1], dtype=float)
    calculated = np.asarray(arrays[3], dtype=float)
    background = np.asarray(arrays[4], dtype=float)
    difference = observed - calculated
    table = np.column_stack((two_theta, observed, calculated, difference, background))
    np.savetxt(
        FIT,
        table,
        delimiter=",",
        header=(
            "two_theta_deg,observed_intensity,calculated_intensity,"
            "difference_observed_minus_calculated,background_intensity"
        ),
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f", "%.8f"],
    )


def result_document(project) -> dict:
    histogram = project.histogram(0)
    fractions = histogram.ComputeMassFracs()
    residuals = histogram.residuals
    covariance = project.data["Covariance"]["data"]
    rvals = covariance.get("Rvals", {})
    phases = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        cell, cell_su = phase.get_cell_and_esd()
        fraction, fraction_su = fractions[phase.name]
        pid = phase.data["pId"]
        phase_result = {
            "name": phase.name,
            "formula": info["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "space_group_number": info["space_group_number"],
            "cif_path": info["cif_path"],
            "weight_fraction": float(fraction),
            "weight_fraction_formal_su": float(fraction_su),
            "cell": {key: float(value) for key, value in cell.items()},
            "cell_formal_su": {key: float(value) for key, value in cell_su.items()},
            "structure_source": info["structure_source"],
            "bragg_R_percent": float(residuals[f"{pid}:0:Rf"]),
            "bragg_R_F2_percent": float(residuals[f"{pid}:0:Rf^2"]),
        }
        phases.append(phase_result)

    def finite_or_none(value):
        value = float(value)
        return value if np.isfinite(value) else None

    fit_statistics = {
        "Rwp_percent": float(residuals["wR"]),
        "Rp_percent": float(residuals["R"]),
        "Rexp_percent": float(residuals["wRmin"]),
        "goodness_of_fit": float(rvals.get("GOF", residuals["wR"] / residuals["wRmin"])),
        "chi_square": finite_or_none(rvals.get("chisq", np.nan)),
        "background_R_percent": float(residuals["Rb"]),
        "weighted_background_R_percent": float(residuals["wRb"]),
        "number_observations": int(rvals.get("Nobs", len(histogram.data["data"][1][0]))),
        "number_refined_parameters": int(rvals.get("Nvars", len(covariance.get("varyList", [])))),
    }
    return {
        "phases": phases,
        "fractions_normalized_over_modeled_crystalline_phases": True,
        "fit_statistics": fit_statistics,
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
        "measurement": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_intensity_ratio": 0.5,
            "two_theta_range_deg": [
                float(histogram.data["data"][1][0][0]),
                float(histogram.data["data"][1][0][-1]),
            ],
            "weighting": "Poisson weights 1/count (no pointwise uncertainties supplied)",
        },
    }


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(gpxfile=SOURCE, newgpx=FINAL)
    rename_phase(project, "BaCO3_watch", "BaCO3")
    enforce_accepted_model(project)

    for _ in range(2):
        project.refine(makeBack=False)
    project.save(FINAL)

    # Reopen and replay the exact file that will be submitted.
    project = G2sc.G2Project(gpxfile=FINAL)
    enforce_accepted_model(project)
    project.refine(makeBack=False)
    project.save(FINAL)

    # Reopen once more without changing the model; all exports derive from this file.
    project = G2sc.G2Project(gpxfile=FINAL)
    histogram = project.histogram(0)
    for phase in project.phases():
        phase.export_CIF(ROOT / PHASE_INFO[phase.name]["cif_path"])
    export_fit(histogram)
    result = result_document(project)
    RESULT.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
