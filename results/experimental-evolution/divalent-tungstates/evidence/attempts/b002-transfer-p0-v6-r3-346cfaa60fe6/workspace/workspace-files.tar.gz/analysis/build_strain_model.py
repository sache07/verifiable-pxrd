#!/usr/bin/env python3
"""Add independently supported phase-strain terms one phase at a time."""

from __future__ import annotations

import json
import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TRIALS = ROOT / ".tmp/trials"
SOURCE = TRIALS / "four_common_roughB.gpx"
OUTPUT = TRIALS / "four_strain_base.gpx"


def covariance(project, name: str) -> tuple[float | None, float | None]:
    cov = project.data.get("Covariance", {}).get("data", {})
    for var, value, sigma in zip(
        cov.get("varyList", []), cov.get("variables", []), cov.get("sig", [])
    ):
        if str(var) == name:
            return float(value), float(sigma)
    return None, None


def snapshot(project, stage: str) -> dict:
    hist = project.histogram(0)
    terms = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if hap["Mustrain"][2][0]:
            var = f"{phase.data['pId']}:0:Mustrain;i"
            value, sigma = covariance(project, var)
            terms[phase.name] = {
                "variable": var,
                "value_microstrain": value,
                "sigma": sigma,
                "value_over_sigma": None if value is None or not sigma else value / sigma,
            }
    return {
        "stage": stage,
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "terms": terms,
        "fractions": {
            name: [float(value[0]), float(value[1])]
            for name, value in hist.ComputeMassFracs().items()
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=SOURCE)
    parser.add_argument("--output", type=Path, default=OUTPUT)
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(gpxfile=args.source, newgpx=args.output)
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-6
    controls["shift factor"] = 0.35
    stages = []

    for phase_name, initial in (
        ("WO3", 3400.0),
        ("Ba3W2O9", 1000.0),
        ("BaCO3_watch", 8200.0),
    ):
        hist = project.histogram(0)
        phase = project.phase(phase_name)
        record = phase.data["Histograms"][hist.name]["Mustrain"]
        record[0] = "isotropic"
        record[1][:] = [initial, 0.0, 1.0]
        record[2][:] = [True, False, False]
        for replay in range(2):
            project.refine(makeBack=False)
            stages.append(snapshot(project, f"add_{phase_name}_strain_{replay + 1}"))

    project.save(args.output)
    project = G2sc.G2Project(gpxfile=args.output)
    project.refine(makeBack=False)
    stages.append(snapshot(project, "reopen_replay"))
    project.save(args.output)

    result = {
        "source": str(args.source),
        "project": str(args.output),
        "stages": stages,
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
