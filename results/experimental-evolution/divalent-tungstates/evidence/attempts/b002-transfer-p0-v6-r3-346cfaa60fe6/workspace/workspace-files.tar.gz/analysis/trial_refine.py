#!/usr/bin/env python3
"""Run a restrained GSAS-II candidate-model comparison refinement."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


BA_MODELS = {
    "exact": cod_path("1527204"),
    "bamo": ROOT / "analysis/candidates/bawo4_ordered_bamo4_prototype.cif",
    "srwo": ROOT / "analysis/candidates/bawo4_ordered_srwo4_prototype.cif",
    "pbwo": ROOT / "analysis/candidates/bawo4_ordered_pbwo4_prototype.cif",
    "euwo": ROOT / "analysis/candidates/bawo4_ordered_euwo4_prototype.cif",
}

WO_MODELS = {
    "p21n_1960": cod_path("1528915"),
    "p21c_1966": cod_path("2311041"),
    "p21m_1931": cod_path("1010618"),
    "triclinic_1978": cod_path("2106293"),
    "p21c_2010": cod_path("1563541"),
    "pnma_1977": cod_path("2107312"),
}

CARBONATE = cod_path("9010928")
BA3W2O9 = cod_path("1533878")


def initial_background(ncoef: int = 6) -> list[float]:
    raw = np.genfromtxt(ROOT / "inputs/pattern.csv", delimiter=",", skip_header=1)
    x, y = raw[:, 0], raw[:, 1]
    step = float(np.median(np.diff(x)))
    baseline = percentile_filter(y, size=max(31, int(2.5 / step)), percentile=12, mode="nearest")
    baseline = gaussian_filter1d(baseline, max(10, int(0.5 / step)))
    tx = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    return np.polynomial.chebyshev.chebfit(tx, baseline, ncoef - 1).tolist()


def neutralize_phase_profile(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Size"][0] = "isotropic"
    # GSAS-II stores [equatorial size (micrometre), axial size, LG mix].
    # Ten micrometres is the accepted upper neutral value; the mix must stay in [0, 1].
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def snapshot(project, hist, stage: str) -> dict:
    phases = {}
    for ph in project.phases():
        hap = ph.data["Histograms"][hist.name]
        phases[ph.name] = {
            "scale": float(hap["Scale"][0]),
            "cell": {k: float(v) for k, v in ph.get_cell().items()},
        }
    try:
        fractions = {
            k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": str(exc)}
    residuals = {}
    for key, value in hist.residuals.items():
        try:
            residuals[key] = float(value)
        except (TypeError, ValueError):
            residuals[key] = str(value)
    return {
        "stage": stage,
        "residuals": residuals,
        "fractions": fractions,
        "shift_micrometre": float(hist.SampleParameters["Shift"][0]),
        "instrument": {
            k: float(hist.InstrumentParameters[k][1])
            for k in ("U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "background": [float(v) for v in hist.data["Background"][0][3:]],
        "phases": phases,
    }


def run_refinement(project, hist, label: str, log: list[dict]) -> None:
    project.refine(makeBack=False)
    log.append(snapshot(project, project.histogram(hist.name), label))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ba", choices=BA_MODELS, default="bamo")
    parser.add_argument("--wo", choices=WO_MODELS, default="p21n_1960")
    parser.add_argument("--carbonate", action="store_true")
    parser.add_argument("--ba3w2o9", action="store_true")
    parser.add_argument("--profile", choices=("ux", "uw", "wx", "x"), default="ux")
    parser.add_argument("--tag", required=True)
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    trial_dir = ROOT / ".tmp/trials"
    trial_dir.mkdir(parents=True, exist_ok=True)
    gpx_path = trial_dir / f"{args.tag}.gpx"
    project = G2sc.G2Project(newgpx=gpx_path)
    hist = project.add_powder_histogram(
        ROOT / "inputs/pattern.csv",
        ROOT / "analysis/cu_ka12.instprm",
        fmthint="comma",
    )

    # Use phase scales only; varying the histogram scale as well would be singular.
    hist.SampleParameters["Scale"][:] = [1.0, False]
    hist.SampleParameters["Shift"][:] = [-430.0, False]
    hist.SampleParameters["Transparency"][:] = [0.0, False]
    hist.SampleParameters["SurfRoughA"][:] = [0.0, False]
    hist.SampleParameters["SurfRoughB"][:] = [0.0, False]

    inst = hist.InstrumentParameters
    profile_initial = {
        "ux": {"U": 5.0, "W": 0.0, "X": 7.0},
        "uw": {"U": 5.0, "W": 45.0, "X": 0.0},
        "wx": {"U": 0.0, "W": 45.0, "X": 5.0},
        "x": {"U": 0.0, "W": 0.0, "X": 7.0},
    }[args.profile]
    for name, value in {
        "U": profile_initial["U"],
        "V": 0.0,
        "W": profile_initial["W"],
        "X": profile_initial["X"],
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }.items():
        inst[name][1] = value
        inst[name][2] = False

    coeffs = initial_background(6)
    hist.data["Background"][0] = ["chebyschev-1", True, len(coeffs), *coeffs]

    phase_specs = [
        ("BaWO4", BA_MODELS[args.ba], 1.0),
        ("WO3", WO_MODELS[args.wo], 0.2),
    ]
    if args.ba3w2o9:
        phase_specs.append(("Ba3W2O9", BA3W2O9, 0.2))
    if args.carbonate:
        phase_specs.append(("BaCO3", CARBONATE, 0.03))

    for name, path, scale in phase_specs:
        phase = project.add_phase(path, phasename=name, histograms=[hist], fmthint="CIF")
        neutralize_phase_profile(phase, hist.name)
        phase.data["Histograms"][hist.name]["Scale"][:] = [scale, True]
        phase.set_refinements({"Cell": False})

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = args.cycles
    controls["min dM/M"] = 1.0e-5
    controls["shift factor"] = 0.5

    log: list[dict] = []
    run_refinement(project, hist, "background_scales", log)

    hist = project.histogram(0)
    hist.SampleParameters["Shift"][1] = True
    run_refinement(project, hist, "add_sample_displacement", log)

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run_refinement(project, hist, "add_cells", log)

    if args.profile == "ux":
        hist.InstrumentParameters["X"][2] = True
        run_refinement(project, hist, "add_X", log)
        hist.InstrumentParameters["U"][2] = True
        run_refinement(project, hist, "add_U", log)
    elif args.profile == "uw":
        hist.InstrumentParameters["W"][2] = True
        run_refinement(project, hist, "add_W", log)
        hist.InstrumentParameters["U"][2] = True
        run_refinement(project, hist, "add_U", log)
    elif args.profile == "wx":
        hist.InstrumentParameters["W"][2] = True
        hist.InstrumentParameters["X"][2] = True
        run_refinement(project, hist, "add_W_X", log)
    else:
        hist.InstrumentParameters["X"][2] = True
        run_refinement(project, hist, "add_X", log)
    run_refinement(project, hist, "reconverge", log)
    run_refinement(project, hist, "replay", log)

    project.save(gpx_path)
    result = {
        "tag": args.tag,
        "ba_model": args.ba,
        "wo_model": args.wo,
        "carbonate": args.carbonate,
        "ba3w2o9": args.ba3w2o9,
        "profile": args.profile,
        "gpx": str(gpx_path),
        "stages": log,
    }
    out = trial_dir / f"{args.tag}.json"
    out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result["stages"][-1], indent=2))


if __name__ == "__main__":
    main()
