#!/usr/bin/env python3
"""Replace the physically weak 1960 WO3 record with the 1966 neutron model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import WO_MODELS, neutralize_phase_profile


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/trials/uwx_strain_base.gpx"
OUTPUT = ROOT / ".tmp/trials/uwx_wo3_1966.gpx"


def remove_phase(project, name: str) -> None:
    del project.data["Phases"][name]
    for item in project.names:
        if item and item[0] == "Phases" and name in item:
            item.remove(name)
    for histogram in project.histograms():
        histogram.data.get("Reflection Lists", {}).pop(name, None)
    project.update_ids()


def covariance(project, exact: str) -> tuple[float | None, float | None]:
    cov = project.data.get("Covariance", {}).get("data", {})
    for name, value, sigma in zip(
        cov.get("varyList", []), cov.get("variables", []), cov.get("sig", [])
    ):
        if str(name) == exact:
            return float(value), float(sigma)
    return None, None


def snapshot(project, stage: str) -> dict:
    histogram = project.histogram(0)
    fractions = histogram.ComputeMassFracs()
    phase = project.phase("WO3")
    strain_name = f"{phase.data['pId']}:0:Mustrain;i"
    strain, strain_su = covariance(project, strain_name)
    return {
        "stage": stage,
        "Rwp_percent": float(histogram.residuals["wR"]),
        "Rp_percent": float(histogram.residuals["R"]),
        "fractions": {
            name: [float(value[0]), float(value[1])]
            for name, value in fractions.items()
        },
        "WO3_cell": {key: float(value) for key, value in phase.get_cell().items()},
        "WO3_strain": strain,
        "WO3_strain_su": strain_su,
        "profile": {
            key: float(histogram.InstrumentParameters[key][1])
            for key in ("U", "W", "X", "Zero")
        },
    }


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(gpxfile=SOURCE, newgpx=OUTPUT)
    histogram = project.histogram(0)
    old = project.phase("WO3")
    old_hap = old.data["Histograms"][histogram.name]
    initial_scale = float(old_hap["Scale"][0])
    initial_strain = float(old_hap["Mustrain"][1][0])
    remove_phase(project, "WO3")

    histogram = project.histogram(0)
    phase = project.add_phase(
        WO_MODELS["p21c_1966"],
        phasename="WO3",
        histograms=[histogram],
        fmthint="CIF",
    )
    neutralize_phase_profile(phase, histogram.name)
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"][:] = [initial_scale, True]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [initial_strain, 0.0, 1.0]
    hap["Mustrain"][2][:] = [True, False, False]
    phase.data["General"]["Cell"][0] = True
    for atom in phase.atoms():
        atom.refinement_flags = " "

    # Reconnect every accepted variable after the source change.
    histogram = project.histogram(0)
    histogram.data["Background"][0][1] = True
    histogram.SampleParameters["SurfRoughB"][1] = True
    for key in ("Zero", "U", "W", "X"):
        histogram.InstrumentParameters[key][2] = True
    for existing in project.phases():
        existing.data["General"]["Cell"][0] = True
        existing.data["Histograms"][histogram.name]["Scale"][1] = True

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 15
    controls["min dM/M"] = 1.0e-7
    controls["shift factor"] = 0.3

    stages = []
    for index in range(4):
        project.refine(makeBack=False)
        stages.append(snapshot(project, f"reconverge_{index + 1}"))
    project.save(OUTPUT)
    project = G2sc.G2Project(gpxfile=OUTPUT)
    project.refine(makeBack=False)
    stages.append(snapshot(project, "reopen_replay"))
    project.save(OUTPUT)

    result = {
        "source": str(SOURCE),
        "replacement": "WO3 COD 2311041 (1966 neutron, P21/c)",
        "project": str(OUTPUT),
        "stages": stages,
    }
    OUTPUT.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
