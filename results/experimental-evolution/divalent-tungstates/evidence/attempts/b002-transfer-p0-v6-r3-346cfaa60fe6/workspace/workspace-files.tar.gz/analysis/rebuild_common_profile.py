#!/usr/bin/env python3
"""Rebuild a neutral four-phase common profile after inventory revision."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import neutralize_phase_profile


ROOT = Path(__file__).resolve().parents[1]
TRIALS = ROOT / ".tmp/trials"
SOURCE = TRIALS / "watch_baco3.gpx"
NO_ROUGH = TRIALS / "four_common_norough.gpx"
ROUGH = TRIALS / "four_common_roughB.gpx"


def max_correlations(project, limit: int = 8) -> list[dict]:
    cov = project.data.get("Covariance", {}).get("data", {})
    result = []
    for pair, value in cov.get("covMatrix", {}).items() if isinstance(cov.get("covMatrix"), dict) else []:
        result.append({"pair": str(pair), "correlation": float(value)})
    # GSAS-II usually stores high correlations in a preformatted list.
    for item in cov.get("Hcorr", []):
        result.append({"item": str(item)})
    return result[:limit]


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    return {
        "stage": label,
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "Rexp_percent": float(hist.residuals["wRmin"]),
        "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
        "U": float(hist.InstrumentParameters["U"][1]),
        "X": float(hist.InstrumentParameters["X"][1]),
        "roughness_B": float(hist.SampleParameters["SurfRoughB"][0]),
        "fractions": {
            name: [float(value[0]), float(value[1])]
            for name, value in hist.ComputeMassFracs().items()
        },
        "cells": {
            phase.name: {key: float(value) for key, value in phase.get_cell().items()}
            for phase in project.phases()
        },
        "high_correlations": max_correlations(project),
    }


def refine(project, label: str, stages: list[dict], repeats: int = 1) -> None:
    for index in range(repeats):
        project.refine(makeBack=False)
        suffix = f"_{index + 1}" if repeats > 1 else ""
        stages.append(snapshot(project, label + suffix))


def configure_neutral(project) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        neutralize_phase_profile(phase, hist.name)
        phase.set_refinements({"Cell": True})
    hist.data["Background"][0][1] = True
    hist.SampleParameters["Scale"][:] = [1.0, False]
    hist.SampleParameters["Shift"][:] = [0.0, False]
    hist.SampleParameters["Transparency"][:] = [0.0, False]
    hist.SampleParameters["SurfRoughA"][:] = [0.0, False]
    hist.SampleParameters["SurfRoughB"][:] = [0.0, False]

    instrument = hist.InstrumentParameters
    for key, value in {
        "Zero": 0.279,
        "U": 20.0,
        "V": 0.0,
        "W": 0.0,
        "X": 6.5,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "Polariz.": 0.7,
    }.items():
        instrument[key][1] = value
        instrument[key][2] = False
    instrument["Zero"][2] = True

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-6
    controls["shift factor"] = 0.35


def main() -> None:
    G2sc.SetPrintLevel("warn")
    stages: list[dict] = []
    project = G2sc.G2Project(gpxfile=SOURCE, newgpx=NO_ROUGH)
    configure_neutral(project)
    refine(project, "geometry_scales_background_zero", stages, repeats=2)

    hist = project.histogram(0)
    hist.InstrumentParameters["X"][2] = True
    refine(project, "add_X", stages, repeats=2)
    hist = project.histogram(0)
    hist.InstrumentParameters["U"][2] = True
    refine(project, "add_U", stages, repeats=2)
    project.save(NO_ROUGH)

    project = G2sc.G2Project(gpxfile=NO_ROUGH)
    refine(project, "norough_reopen_replay", stages)
    project.save(NO_ROUGH)

    rough_stages: list[dict] = []
    project = G2sc.G2Project(gpxfile=NO_ROUGH, newgpx=ROUGH)
    project.histogram(0).SampleParameters["SurfRoughB"][:] = [0.08, True]
    refine(project, "add_single_roughness_B", rough_stages, repeats=2)
    project.save(ROUGH)
    project = G2sc.G2Project(gpxfile=ROUGH)
    refine(project, "roughness_reopen_replay", rough_stages)
    project.save(ROUGH)

    result = {
        "source": str(SOURCE),
        "neutral_common_profile": str(NO_ROUGH),
        "single_roughness_profile": str(ROUGH),
        "neutral_stages": stages,
        "roughness_stages": rough_stages,
    }
    (TRIALS / "four_common_profile.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
