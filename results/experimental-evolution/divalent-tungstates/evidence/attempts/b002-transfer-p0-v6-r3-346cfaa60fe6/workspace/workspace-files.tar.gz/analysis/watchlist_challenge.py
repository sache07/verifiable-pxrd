#!/usr/bin/env python3
"""Challenge a residual precursor phase against the accepted common profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import CARBONATE, neutralize_phase_profile


ROOT = Path(__file__).resolve().parents[1]


def covariance_parameter(project, suffix: str) -> tuple[float | None, float | None, str | None]:
    cov = project.data.get("Covariance", {}).get("data", {})
    names = cov.get("varyList", [])
    values = cov.get("variables", [])
    sigmas = cov.get("sig", [])
    for name, value, sigma in zip(names, values, sigmas):
        if str(name).endswith(suffix):
            return float(value), float(sigma), str(name)
    return None, None, None


def summary(project, hist, carbonate) -> dict:
    scale, scale_su, variable = covariance_parameter(project, ":Scale")
    # Prefer the phase-specific name when several phase scales are present.
    phase_id = carbonate.data["pId"]
    scale, scale_su, variable = covariance_parameter(project, f"{phase_id}:0:Scale")
    try:
        fractions = {
            key: [float(value[0]), float(value[1])]
            for key, value in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": str(exc)}
    return {
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "carbonate_scale": scale,
        "carbonate_scale_su": scale_su,
        "carbonate_scale_variable": variable,
        "fractions": fractions,
        "carbonate_cell": {
            key: float(value) for key, value in carbonate.get_cell().items()
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input",
        type=Path,
        default=ROOT / ".tmp/trials/baseline_zero.gpx",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / ".tmp/trials/watch_baco3.gpx",
    )
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(gpxfile=args.input, newgpx=args.output)
    hist = project.histogram(0)
    carbonate = project.add_phase(
        CARBONATE,
        phasename="BaCO3_watch",
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize_phase_profile(carbonate, hist.name)
    hap = carbonate.data["Histograms"][hist.name]
    hap["Scale"][:] = [0.002, True]
    carbonate.set_refinements({"Cell": False})

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-6
    controls["shift factor"] = 0.35

    stages = []
    for label in ("common_profile_reconvergence_1", "common_profile_reconvergence_2"):
        project.refine(makeBack=False)
        hist = project.histogram(0)
        carbonate = project.phase("BaCO3_watch")
        stages.append({"stage": label, **summary(project, hist, carbonate)})

    # Replay from disk to check that any weak scale is not path-dependent.
    project.save(args.output)
    project = G2sc.G2Project(gpxfile=args.output)
    project.refine(makeBack=False)
    hist = project.histogram(0)
    carbonate = project.phase("BaCO3_watch")
    stages.append({"stage": "reopen_replay", **summary(project, hist, carbonate)})
    project.save(args.output)

    result = {
        "candidate": "BaCO3 (witherite, COD 9010928)",
        "input_project": str(args.input),
        "output_project": str(args.output),
        "stages": stages,
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
