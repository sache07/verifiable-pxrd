#!/usr/bin/env python3
"""Run neutral, cross-seeded GSAS-II source comparisons."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


WORK = Path(__file__).resolve().parent
ROOT = Path("<RUN>/resources/b001-c05/cif")
OUT = WORK / ".tmp" / "source_screen"
OUT.mkdir(parents=True, exist_ok=True)


def cod(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CAWO4 = {
    "scheelite_7219229": cod("7219229"),
    "monoclinic_1546035": cod("1546035"),
}

WO3 = {
    "monoclinic_1528915": cod("1528915"),
    "monoclinic_2311041": cod("2311041"),
    "triclinic_2106293": cod("2106293"),
    "orthorhombic_2107312": cod("2107312"),
    "small_monoclinic_1563541": cod("1563541"),
    "tetragonal_1521532": cod("1521532"),
    "tetragonal_1521533": cod("1521533"),
    "hexagonal_1004057": cod("1004057"),
}

SEED_SCALE = {"CaWO4": 47.58, "WO3": 5.16, "CaO": 2.87, "Ca3WO6": 11.24}
SEED_BACK = [
    1394.24,
    -697.03,
    542.22,
    -451.41,
    274.12,
    -129.80,
    63.78,
    -9.10,
]

REFINED_CELLS = {
    "CaWO4": [5.2427393, 5.2427393, 11.3768440, 90.0, 90.0, 90.0],
    "WO3": [7.2888076, 7.5313121, 7.6835857, 90.0, 90.92952, 90.0],
    "CaO": [4.7720156, 4.7720156, 4.7720156, 90.0, 90.0, 90.0],
    "Ca3WO6": [5.5346397, 5.7809408, 8.0171611, 90.0, 90.01447, 90.0],
}


def neutral_hap(phase, histogram, scale: float) -> None:
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"] = [float(scale), True]
    hap["Size"] = [
        "isotropic",
        [10.0, 10.0, 1.0],
        [False, False, False],
        [0, 0, 1],
        [10.0, 10.0, 10.0, 0.0, 0.0, 0.0],
        [False] * 6,
    ]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    phase.clear_refinements({"Cell": True})


def set_cell(phase, values) -> None:
    cell = phase.data["General"]["Cell"]
    cell[1:7] = [float(v) for v in values]
    cell[7] = G2lat.calc_V(G2lat.cell2A(values))


def make_project(tag: str, cawo4_path: Path, wo3_path: Path):
    gpx = OUT / f"{tag}.gpx"
    project = G2sc.G2Project(newgpx=str(gpx))
    histogram = project.add_powder_histogram(
        str(WORK / "inputs" / "pattern.csv"),
        str(WORK / "instrument.instprm"),
        fmthint="comma",
    )
    phases = []
    specs = [
        (cawo4_path, "CaWO4", "CIF"),
        (wo3_path, "WO3", "CIF"),
        (cod("1563196"), "CaO", "CIF"),
        (WORK / "candidate_Ca3WO6.cif", "Ca3WO6", "CIF"),
    ]
    for path, name, hint in specs:
        phase = project.add_phase(
            str(path), phasename=name, histograms=[histogram], fmthint=hint
        )
        neutral_hap(phase, histogram, SEED_SCALE[name])
        if name in ("CaO", "Ca3WO6"):
            set_cell(phase, REFINED_CELLS[name])
        elif name == "CaWO4" and cawo4_path == CAWO4["scheelite_7219229"]:
            set_cell(phase, REFINED_CELLS[name])
        elif name == "WO3" and wo3_path == WO3["monoclinic_1528915"]:
            set_cell(phase, REFINED_CELLS[name])
        phases.append(phase)

    histogram.data["Sample Parameters"]["Scale"] = [1.0, False]
    for key in (
        "Absorption",
        "DisplaceX",
        "DisplaceY",
        "Shift",
        "Transparency",
        "SurfRoughA",
        "SurfRoughB",
    ):
        if key in histogram.data["Sample Parameters"]:
            histogram.data["Sample Parameters"][key] = [0.0, False]

    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": SEED_BACK,
                "refine": True,
            }
        }
    )
    inst = histogram.data["Instrument Parameters"][0]
    for key in ("V", "Y", "Z", "SH/L"):
        inst[key][2] = False
    inst["V"][1] = 0.0
    inst["Y"][1] = 0.0
    inst["Z"][1] = 0.0
    inst["SH/L"][1] = 0.002
    for key, value in {"Zero": -0.2012, "U": 5.41, "W": 29.05, "X": 11.55}.items():
        inst[key][1] = value
        inst[key][2] = True
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-6
    project.save()
    return project, histogram, phases


def refine_replay(project, histogram, phases, tag: str) -> dict:
    stages = []
    for stage in ("scale", "cell", "replay"):
        if stage == "cell":
            target = phases[0] if tag.startswith("cawo4__") else phases[1]
            target.set_refinements({"Cell": True})
        project.refine(printFile=str(OUT / f"{tag}.lst"))
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        stages.append(
            {
                "stage": stage,
                "rwp": histogram.get_wR(),
                "gof": rvals.get("GOF"),
                "converged": rvals.get("converged"),
                "max_shift_esd": rvals.get("Max shft/sig"),
            }
        )
    inst = histogram.data["Instrument Parameters"][0]
    scales = {p.name: p.HAPvalue("Scale") for p in phases}
    invalid = (
        any(not math.isfinite(v) or v <= 1.0e-8 for v in scales.values())
        or any(inst[k][1] < 0 for k in ("U", "W", "X"))
    )
    try:
        mass = {k: list(v) for k, v in histogram.ComputeMassFracs().items()}
    except Exception as exc:
        mass = {"error": str(exc)}
        invalid = True
    return {
        "stages": stages,
        "invalid_or_collapsed": invalid,
        "scales": scales,
        "mass_fractions": mass,
        "profile": {k: inst[k][1] for k in ("Zero", "U", "W", "X")},
        "cells": {p.name: p.get_cell() for p in phases},
        "project": str(Path(project.filename).relative_to(WORK)),
    }


def main() -> None:
    mode = sys.argv[1] if len(sys.argv) > 1 else "all"
    cases = []
    if mode in ("all", "cawo4"):
        for name, path in CAWO4.items():
            cases.append((f"cawo4__{name}", path, WO3["monoclinic_1528915"]))
    if mode in ("all", "wo3"):
        for name, path in WO3.items():
            cases.append((f"wo3__{name}", CAWO4["scheelite_7219229"], path))

    results = {}
    for tag, cawo4_path, wo3_path in cases:
        try:
            project, histogram, phases = make_project(tag, cawo4_path, wo3_path)
            result = refine_replay(project, histogram, phases, tag)
        except Exception as exc:
            result = {"error": f"{type(exc).__name__}: {exc}"}
        results[tag] = result
        final = result.get("stages", [{}])[-1]
        print(
            "SOURCE_RESULT",
            tag,
            "Rwp",
            final.get("rwp"),
            "collapsed",
            result.get("invalid_or_collapsed"),
            "mass",
            result.get("mass_fractions"),
            flush=True,
        )

    with (OUT / f"results_{mode}.json").open("w") as handle:
        json.dump(results, handle, indent=2)


if __name__ == "__main__":
    main()
