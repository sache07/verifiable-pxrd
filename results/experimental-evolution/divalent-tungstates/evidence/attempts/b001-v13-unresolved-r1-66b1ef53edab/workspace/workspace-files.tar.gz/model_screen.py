#!/usr/bin/env python3
"""Build neutral 3-phase checkpoints and screen profile/texture models."""

from __future__ import annotations

import json
import math
import os
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
from functools import reduce
from math import gcd
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


G2sc.SetPrintLevel("error")
WORK = Path(__file__).resolve().parent
ROOT = Path("<RUN>/resources/b001-c05/cif")
OUT = WORK / ".tmp" / "model_screen"
OUT.mkdir(parents=True, exist_ok=True)


def cod(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


SOURCES = {
    "mono": {
        "wo3": cod("2311041"),
        "cells": {
            "CaWO4": [5.2427393, 5.2427393, 11.3768440, 90.0, 90.0, 90.0],
            "WO3": [7.6839706, 7.5313791, 10.5046914, 90.0, 136.0700631, 90.0],
            "Ca3WO6": [5.5346397, 5.7809408, 8.0171611, 90.0, 90.01447, 90.0],
        },
        "scales": {"CaWO4": 47.36, "WO3": 4.97, "Ca3WO6": 11.43},
        "profile": {"Zero": -0.20140, "U": 5.68, "W": 29.37, "X": 11.41},
    },
    "tri": {
        "wo3": cod("2106293"),
        "cells": {
            "CaWO4": [5.2427393, 5.2427393, 11.3768440, 90.0, 90.0, 90.0],
            "WO3": [
                7.2894542,
                7.5310113,
                7.6842236,
                90.0139100,
                90.9284306,
                89.9990671,
            ],
            "Ca3WO6": [5.5346397, 5.7809408, 8.0171611, 90.0, 90.01447, 90.0],
        },
        "scales": {"CaWO4": 47.46, "WO3": 5.04, "Ca3WO6": 11.27},
        "profile": {"Zero": -0.20111, "U": 7.11, "W": 29.53, "X": 11.47},
    },
}

BACK = [1397.82, -696.82, 540.43, -453.03, 278.04, -132.72, 65.34, -7.90]


def set_cell(phase, values) -> None:
    cell = phase.data["General"]["Cell"]
    cell[1:7] = [float(v) for v in values]
    cell[7] = G2lat.calc_V(G2lat.cell2A(values))


def neutral_hap(phase, histogram, scale=None) -> None:
    hap = phase.data["Histograms"][histogram.name]
    hap["Use"] = True
    if scale is not None:
        hap["Scale"] = [float(scale), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][3] = [0, 0, 1]
    hap["Size"][4] = [10.0, 10.0, 10.0, 0.0, 0.0, 0.0]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][3] = [0, 0, 1]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]


def setup_project(source: str) -> tuple:
    spec = SOURCES[source]
    path = OUT / f"neutral_{source}.gpx"
    project = G2sc.G2Project(newgpx=str(path))
    histogram = project.add_powder_histogram(
        str(WORK / "inputs" / "pattern.csv"),
        str(WORK / "instrument.instprm"),
        fmthint="comma",
    )
    phase_specs = [
        (cod("7219229"), "CaWO4"),
        (spec["wo3"], "WO3"),
        (WORK / "candidate_Ca3WO6.cif", "Ca3WO6"),
    ]
    phases = []
    for phase_path, name in phase_specs:
        phase = project.add_phase(
            str(phase_path), phasename=name, histograms=[histogram], fmthint="CIF"
        )
        neutral_hap(phase, histogram, spec["scales"][name])
        set_cell(phase, spec["cells"][name])
        phase.set_refinements({"Cell": True})
        phases.append(phase)

    sample = histogram.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    for key in (
        "Absorption",
        "DisplaceX",
        "DisplaceY",
        "Shift",
        "Transparency",
        "SurfRoughA",
        "SurfRoughB",
    ):
        if key in sample:
            sample[key] = [0.0, False]
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(BACK),
                "coeffs": BACK,
                "refine": True,
            }
        }
    )
    inst = histogram.data["Instrument Parameters"][0]
    for key in ("V", "Y", "Z", "SH/L", "Polariz.", "I(L2)/I(L1)"):
        inst[key][2] = False
    inst["V"][1] = 0.0
    inst["Y"][1] = 0.0
    inst["Z"][1] = 0.0
    inst["SH/L"][1] = 0.002
    inst["Polariz."][1] = 0.5
    inst["I(L2)/I(L1)"][1] = 0.5
    for key, value in spec["profile"].items():
        inst[key][1] = float(value)
        inst[key][2] = True
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 15
    controls["min dM/M"] = 1.0e-6
    project.save()
    return project, histogram, phases


def checkpoint_path(source: str) -> Path:
    return OUT / f"neutral_{source}.gpx"


def result(project, histogram) -> dict:
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    inst = histogram.data["Instrument Parameters"][0]
    phases = project.phases()
    scales = {p.name: float(p.HAPvalue("Scale")) for p in phases}
    try:
        fractions = {
            key: [float(value[0]), float(value[1])]
            for key, value in histogram.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": str(exc)}
    max_shift = float(rvals.get("Max shft/sig", math.nan))
    invalid = (
        histogram.get_wR() is None
        or histogram.get_wR() >= 99.0
        or not bool(rvals.get("converged", False))
        or not math.isfinite(max_shift)
        or max_shift >= 1.0
        or any(not math.isfinite(v) or v <= 1.0e-10 for v in scales.values())
        or any(not math.isfinite(inst[k][1]) or inst[k][1] < 0 for k in ("U", "W", "X"))
    )
    haps = {}
    for phase in phases:
        hap = phase.data["Histograms"][histogram.name]
        haps[phase.name] = {
            "size_type": hap["Size"][0],
            "size_values": [float(v) for v in hap["Size"][1]],
            "size_flags": [bool(v) for v in hap["Size"][2]],
            "size_axis": [int(v) for v in hap["Size"][3]],
            "strain_type": hap["Mustrain"][0],
            "strain_values": [float(v) for v in hap["Mustrain"][1]],
            "strain_flags": [bool(v) for v in hap["Mustrain"][2]],
            "strain_axis": [int(v) for v in hap["Mustrain"][3]],
            "md_ratio": float(hap["Pref.Ori."][1]),
            "md_flag": bool(hap["Pref.Ori."][2]),
            "md_axis": [int(v) for v in hap["Pref.Ori."][3]],
        }
        for value, active in zip(hap["Size"][1], hap["Size"][2]):
            if active and (
                not math.isfinite(value) or value <= 0.01 or value >= 9.5
            ):
                invalid = True
        for value, active in zip(hap["Mustrain"][1], hap["Mustrain"][2]):
            if active and (not math.isfinite(value) or value <= 0.0):
                invalid = True
    return {
        "rwp": float(histogram.get_wR()),
        "gof": float(rvals.get("GOF", math.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": float(rvals.get("Max shft/sig", math.nan)),
        "invalid_or_collapsed": invalid,
        "fractions": fractions,
        "scales": scales,
        "profile": {k: float(inst[k][1]) for k in ("Zero", "U", "W", "X")},
        "cells": {p.name: p.get_cell() for p in phases},
        "haps": haps,
        "nvars": int(rvals.get("Nvars", 0)),
    }


def replay(path: Path, attempts: int = 3):
    project = None
    for _ in range(attempts):
        project = G2sc.G2Project(str(path))
        project.data["Controls"]["data"]["max cyc"] = 15
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
        project.refine(printFile=str(path.with_suffix(".lst")))
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        if rvals.get("converged") and rvals.get("Max shft/sig", 999) < 1.0:
            break
    return project, project.histogram(0)


def build(source: str) -> dict:
    project, histogram, _ = setup_project(source)
    project.refine(printFile=str(checkpoint_path(source).with_suffix(".lst")))
    project, histogram = replay(checkpoint_path(source), attempts=3)
    row = result(project, histogram)
    row["project"] = str(checkpoint_path(source).relative_to(WORK))
    return row


def trial(source: str, tag: str, mutate) -> dict:
    path = OUT / f"trial_{source}_{tag}.gpx"
    project = G2sc.G2Project(str(checkpoint_path(source)), newgpx=str(path))
    histogram = project.histogram(0)
    mutate(project, histogram)
    project.save()
    project.refine(printFile=str(path.with_suffix(".lst")))
    project, histogram = replay(path, attempts=2)
    row = result(project, histogram)
    row["project"] = str(path.relative_to(WORK))
    return row


def trial_from(source: str, base_path: Path, prefix: str, tag: str, mutate) -> dict:
    path = OUT / f"trial_{source}_{prefix}_{tag}.gpx"
    project = G2sc.G2Project(str(base_path), newgpx=str(path))
    histogram = project.histogram(0)
    mutate(project, histogram)
    project.save()
    project.refine(printFile=str(path.with_suffix(".lst")))
    project, histogram = replay(path, attempts=2)
    row = result(project, histogram)
    row["project"] = str(path.relative_to(WORK))
    return row


def activate_isotropic(project, histogram, phase_name: str, size: bool, strain: bool):
    for phase in project.phases():
        neutral_hap(phase, histogram)
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][histogram.name]
    if size:
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
    if strain:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 100.0
        hap["Mustrain"][2][0] = True


def canonical_axis(values) -> tuple[int, int, int]:
    vals = [int(round(v)) for v in values]
    div = reduce(gcd, (abs(v) for v in vals if v), 0) or 1
    vals = [v // div for v in vals]
    for value in vals:
        if value:
            if value < 0:
                vals = [-v for v in vals]
            break
    return tuple(vals)


def inequivalent_axes(phase, max_index: int = 2) -> list[tuple[int, int, int]]:
    operations = [np.asarray(op[0], dtype=int) for op in phase.data["General"]["SGData"]["SGOps"]]
    candidates = set()
    for h in range(-max_index, max_index + 1):
        for k in range(-max_index, max_index + 1):
            for l in range(-max_index, max_index + 1):
                if (h, k, l) == (0, 0, 0):
                    continue
                candidates.add(canonical_axis((h, k, l)))
    classes = {}
    for axis in candidates:
        orbit = []
        vector = np.asarray(axis, dtype=int)
        for operation in operations:
            transformed = np.rint(np.linalg.inv(operation).T @ vector).astype(int)
            orbit.append(canonical_axis(transformed))
        key = min(orbit)
        classes.setdefault(key, []).append(axis)
    return sorted(min(values) for values in classes.values())


def run_iso(source: str) -> dict:
    rows = {}
    for phase_name in ("CaWO4", "WO3", "Ca3WO6"):
        for model, use_size, use_strain in (
            ("size", True, False),
            ("strain", False, True),
            ("size_strain", True, True),
        ):
            tag = f"iso_{phase_name}_{model}"
            row = trial(
                source,
                tag,
                lambda p, h, n=phase_name, s=use_size, m=use_strain: activate_isotropic(
                    p, h, n, s, m
                ),
            )
            rows[tag] = row
            print(
                "ISO_RESULT",
                source,
                tag,
                f"Rwp={row['rwp']:.6f}",
                f"invalid={row['invalid_or_collapsed']}",
                row["haps"][phase_name],
                flush=True,
            )
    return rows


def activate_texture(project, histogram, phase_name: str, axis) -> None:
    for phase in project.phases():
        neutral_hap(phase, histogram)
    hap = project.phase(phase_name).data["Histograms"][histogram.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = [int(v) for v in axis]


def texture_job(args):
    source, phase_name, axis = args
    axis = tuple(axis)
    axis_tag = "_".join("m" + str(abs(v)) if v < 0 else str(v) for v in axis)
    tag = f"md_{phase_name}_{axis_tag}"
    row = trial(
        source,
        tag,
        lambda p, h, n=phase_name, a=axis: activate_texture(p, h, n, a),
    )
    ratio = row["haps"][phase_name]["md_ratio"]
    if ratio <= 0.15 or ratio >= 6.0:
        row["invalid_or_collapsed"] = True
    return tag, phase_name, axis, ratio, row


def run_texture(source: str) -> dict:
    base = G2sc.G2Project(str(checkpoint_path(source)))
    rows = {}
    jobs = []
    for phase_name in ("CaWO4", "WO3", "Ca3WO6"):
        axes = inequivalent_axes(base.phase(phase_name), 2)
        print("AXIS_INVENTORY", source, phase_name, len(axes), axes, flush=True)
        for axis in axes:
            jobs.append((source, phase_name, axis))
    workers = max(1, int(os.environ.get("MODEL_WORKERS", "6")))
    with ProcessPoolExecutor(max_workers=workers) as executor:
        futures = [executor.submit(texture_job, job) for job in jobs]
        for future in as_completed(futures):
            tag, phase_name, axis, ratio, row = future.result()
            rows[tag] = row
            print(
                "MD_RESULT",
                source,
                phase_name,
                axis,
                f"Rwp={row['rwp']:.6f}",
                f"ratio={ratio:.6f}",
                f"invalid={row['invalid_or_collapsed']}",
                flush=True,
            )
    return rows


def activate_uniaxial_size(project, histogram, phase_name: str, axis) -> None:
    for phase in project.phases():
        neutral_hap(phase, histogram)
    hap = project.phase(phase_name).data["Histograms"][histogram.name]
    hap["Size"][0] = "uniaxial"
    hap["Size"][1] = [0.1, 0.1, 1.0]
    hap["Size"][2] = [True, True, False]
    hap["Size"][3] = [int(v) for v in axis]


def anisotropy_job(args):
    source, phase_name, axis = args
    axis = tuple(axis)
    axis_tag = "_".join("m" + str(abs(v)) if v < 0 else str(v) for v in axis)
    tag = f"uniax_size_{phase_name}_{axis_tag}"
    row = trial(
        source,
        tag,
        lambda p, h, n=phase_name, a=axis: activate_uniaxial_size(p, h, n, a),
    )
    return tag, phase_name, axis, row


def run_anisotropy(source: str) -> dict:
    base = G2sc.G2Project(str(checkpoint_path(source)))
    phase_name = "CaWO4"
    axes = inequivalent_axes(base.phase(phase_name), 2)
    print("ANISO_AXIS_INVENTORY", source, phase_name, len(axes), axes, flush=True)
    rows = {}
    workers = max(1, int(os.environ.get("MODEL_WORKERS", "6")))
    jobs = [(source, phase_name, axis) for axis in axes]
    with ProcessPoolExecutor(max_workers=workers) as executor:
        futures = [executor.submit(anisotropy_job, job) for job in jobs]
        for future in as_completed(futures):
            tag, phase_name, axis, row = future.result()
            rows[tag] = row
            values = row["haps"][phase_name]["size_values"][:2]
            print(
                "ANISO_RESULT",
                source,
                phase_name,
                axis,
                f"Rwp={row['rwp']:.6f}",
                f"sizes={values}",
                f"invalid={row['invalid_or_collapsed']}",
                flush=True,
            )
    return rows


def activate_collective(
    project,
    histogram,
    phase_names,
    size_seed: float | None,
    strain_seed: float | None,
) -> None:
    for phase in project.phases():
        neutral_hap(phase, histogram)
    for phase_name in phase_names:
        hap = project.phase(phase_name).data["Histograms"][histogram.name]
        if size_seed is not None:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = float(size_seed)
            hap["Size"][2][0] = True
        if strain_seed is not None:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = float(strain_seed)
            hap["Mustrain"][2][0] = True


def collective_job(args):
    source, tag, phase_names, size_seed, strain_seed = args
    row = trial(
        source,
        tag,
        lambda p, h: activate_collective(
            p, h, phase_names, size_seed, strain_seed
        ),
    )
    return tag, row


def run_collective(source: str) -> dict:
    all_phases = ("CaWO4", "WO3", "Ca3WO6")
    jobs = []
    for seed in (0.05, 0.2, 1.0):
        jobs.append((source, f"collect_all_size_{seed:g}", all_phases, seed, None))
        jobs.append((source, f"reseed_CaWO4_size_{seed:g}", ("CaWO4",), seed, None))
    for seed in (10.0, 100.0):
        jobs.append((source, f"collect_all_strain_{seed:g}", all_phases, None, seed))
    for size_seed, strain_seed in ((0.05, 10.0), (0.2, 100.0)):
        jobs.append(
            (
                source,
                f"collect_all_size_strain_{size_seed:g}_{strain_seed:g}",
                all_phases,
                size_seed,
                strain_seed,
            )
        )
    rows = {}
    workers = max(1, int(os.environ.get("MODEL_WORKERS", "6")))
    with ProcessPoolExecutor(max_workers=workers) as executor:
        futures = [executor.submit(collective_job, job) for job in jobs]
        for future in as_completed(futures):
            tag, row = future.result()
            rows[tag] = row
            print(
                "COLLECTIVE_RESULT",
                source,
                tag,
                f"Rwp={row['rwp']:.6f}",
                f"invalid={row['invalid_or_collapsed']}",
                {name: data for name, data in row["haps"].items()},
                flush=True,
            )
    return rows


def elaborated_path(source: str) -> Path:
    return OUT / f"elaborated_{source}.gpx"


def build_elaborated(source: str) -> dict:
    path = elaborated_path(source)
    project = G2sc.G2Project(str(checkpoint_path(source)), newgpx=str(path))
    histogram = project.histogram(0)
    activate_uniaxial_size(project, histogram, "CaWO4", (0, 1, 0))
    project.save()
    project.refine(printFile=str(path.with_suffix(".lst")))
    project, histogram = replay(path, attempts=3)
    row = result(project, histogram)
    row["project"] = str(path.relative_to(WORK))
    return row


def activate_texture_preserve_width(project, histogram, phase_name: str, axis) -> None:
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
    hap = project.phase(phase_name).data["Histograms"][histogram.name]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = [int(v) for v in axis]


def texture_elaborated_job(args):
    source, phase_name, axis = args
    axis = tuple(axis)
    axis_tag = "_".join("m" + str(abs(v)) if v < 0 else str(v) for v in axis)
    tag = f"md_{phase_name}_{axis_tag}"
    row = trial_from(
        source,
        elaborated_path(source),
        "elab",
        tag,
        lambda p, h, n=phase_name, a=axis: activate_texture_preserve_width(
            p, h, n, a
        ),
    )
    ratio = row["haps"][phase_name]["md_ratio"]
    if ratio <= 0.15 or ratio >= 6.0:
        row["invalid_or_collapsed"] = True
    return tag, phase_name, axis, ratio, row


def run_texture_elaborated(source: str) -> dict:
    base = G2sc.G2Project(str(elaborated_path(source)))
    rows = {}
    jobs = []
    for phase_name in ("CaWO4", "WO3", "Ca3WO6"):
        axes = inequivalent_axes(base.phase(phase_name), 2)
        print(
            "ELAB_AXIS_INVENTORY", source, phase_name, len(axes), axes, flush=True
        )
        jobs.extend((source, phase_name, axis) for axis in axes)
    workers = max(1, int(os.environ.get("MODEL_WORKERS", "6")))
    with ProcessPoolExecutor(max_workers=workers) as executor:
        futures = [executor.submit(texture_elaborated_job, job) for job in jobs]
        for future in as_completed(futures):
            tag, phase_name, axis, ratio, row = future.result()
            rows[tag] = row
            print(
                "ELAB_MD_RESULT",
                source,
                phase_name,
                axis,
                f"Rwp={row['rwp']:.6f}",
                f"ratio={ratio:.6f}",
                f"invalid={row['invalid_or_collapsed']}",
                flush=True,
            )
    return rows


def joint_path(source: str) -> Path:
    return OUT / f"joint_{source}.gpx"


def best_elaborated_trial_path(source: str) -> Path:
    return OUT / f"trial_{source}_elab_md_CaWO4_1_m2_m1.gpx"


def build_joint(source: str) -> dict:
    path = joint_path(source)
    project = G2sc.G2Project(str(best_elaborated_trial_path(source)), newgpx=str(path))
    project.save()
    project, histogram = replay(path, attempts=3)
    row = result(project, histogram)
    row["project"] = str(path.relative_to(WORK))
    return row


def activate_size_preserve_texture(
    project, histogram, phase_name: str, axis=None, isotropic: bool = False
) -> None:
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Size"][3] = [0, 0, 1]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][3] = [0, 0, 1]
    hap = project.phase(phase_name).data["Histograms"][histogram.name]
    if isotropic:
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [0.1, 10.0, 1.0]
        hap["Size"][2] = [True, False, False]
    else:
        hap["Size"][0] = "uniaxial"
        hap["Size"][1] = [0.2, 0.067, 1.0]
        hap["Size"][2] = [True, True, False]
        hap["Size"][3] = [int(v) for v in axis]


def joint_anisotropy_job(args):
    source, axis = args
    if axis is None:
        tag = "size_isotropic"
        row = trial_from(
            source,
            joint_path(source),
            "joint",
            tag,
            lambda p, h: activate_size_preserve_texture(
                p, h, "CaWO4", isotropic=True
            ),
        )
    else:
        axis = tuple(axis)
        axis_tag = "_".join(
            "m" + str(abs(v)) if v < 0 else str(v) for v in axis
        )
        tag = f"size_uniax_CaWO4_{axis_tag}"
        row = trial_from(
            source,
            joint_path(source),
            "joint",
            tag,
            lambda p, h, a=axis: activate_size_preserve_texture(
                p, h, "CaWO4", axis=a
            ),
        )
    return tag, axis, row


def run_joint_anisotropy(source: str) -> dict:
    base = G2sc.G2Project(str(joint_path(source)))
    axes = inequivalent_axes(base.phase("CaWO4"), 2)
    print("JOINT_SIZE_AXIS_INVENTORY", source, len(axes), axes, flush=True)
    jobs = [(source, axis) for axis in axes] + [(source, None)]
    rows = {}
    workers = max(1, int(os.environ.get("MODEL_WORKERS", "6")))
    with ProcessPoolExecutor(max_workers=workers) as executor:
        futures = [executor.submit(joint_anisotropy_job, job) for job in jobs]
        for future in as_completed(futures):
            tag, axis, row = future.result()
            rows[tag] = row
            size = row["haps"]["CaWO4"]["size_values"]
            print(
                "JOINT_SIZE_RESULT",
                source,
                axis,
                f"Rwp={row['rwp']:.6f}",
                f"size={size}",
                f"invalid={row['invalid_or_collapsed']}",
                flush=True,
            )
    return rows


def elaborated2_path(source: str) -> Path:
    return OUT / f"elaborated2_{source}.gpx"


def best_joint_size_trial_path(source: str) -> Path:
    return OUT / f"trial_{source}_joint_size_uniax_CaWO4_1_2_0.gpx"


def build_elaborated2(source: str) -> dict:
    path = elaborated2_path(source)
    project = G2sc.G2Project(str(best_joint_size_trial_path(source)), newgpx=str(path))
    project.save()
    project, histogram = replay(path, attempts=3)
    row = result(project, histogram)
    row["project"] = str(path.relative_to(WORK))
    return row


def texture_elaborated2_job(args):
    source, phase_name, axis = args
    axis = tuple(axis)
    axis_tag = "_".join("m" + str(abs(v)) if v < 0 else str(v) for v in axis)
    tag = f"md_{phase_name}_{axis_tag}"
    row = trial_from(
        source,
        elaborated2_path(source),
        "elab2",
        tag,
        lambda p, h, n=phase_name, a=axis: activate_texture_preserve_width(
            p, h, n, a
        ),
    )
    ratio = row["haps"][phase_name]["md_ratio"]
    if ratio <= 0.15 or ratio >= 6.0:
        row["invalid_or_collapsed"] = True
    return tag, phase_name, axis, ratio, row


def run_texture_elaborated2(source: str) -> dict:
    base = G2sc.G2Project(str(elaborated2_path(source)))
    rows = {}
    jobs = []
    for phase_name in ("CaWO4", "WO3", "Ca3WO6"):
        axes = inequivalent_axes(base.phase(phase_name), 2)
        print(
            "ELAB2_AXIS_INVENTORY", source, phase_name, len(axes), axes, flush=True
        )
        jobs.extend((source, phase_name, axis) for axis in axes)
    workers = max(1, int(os.environ.get("MODEL_WORKERS", "6")))
    with ProcessPoolExecutor(max_workers=workers) as executor:
        futures = [executor.submit(texture_elaborated2_job, job) for job in jobs]
        for future in as_completed(futures):
            tag, phase_name, axis, ratio, row = future.result()
            rows[tag] = row
            print(
                "ELAB2_MD_RESULT",
                source,
                phase_name,
                axis,
                f"Rwp={row['rwp']:.6f}",
                f"ratio={ratio:.6f}",
                f"invalid={row['invalid_or_collapsed']}",
                flush=True,
            )
    return rows


def rough_path(source: str) -> Path:
    if source == "mono":
        return OUT / "challenge_mono_roughness_ab.gpx"
    return OUT / "nuisance_rough_tri.gpx"


def rough_texture_job(args):
    source, phase_name, axis = args
    axis = tuple(axis)
    axis_tag = "_".join("m" + str(abs(v)) if v < 0 else str(v) for v in axis)
    tag = f"md_{phase_name}_{axis_tag}"
    row = trial_from(
        source,
        rough_path(source),
        "rough",
        tag,
        lambda p, h, n=phase_name, a=axis: activate_texture_preserve_width(
            p, h, n, a
        ),
    )
    ratio = row["haps"][phase_name]["md_ratio"]
    if ratio <= 0.15 or ratio >= 6.0:
        row["invalid_or_collapsed"] = True
    return tag, phase_name, axis, ratio, row


def run_rough_texture(source: str) -> dict:
    base = G2sc.G2Project(str(rough_path(source)))
    rows = {}
    jobs = []
    for phase_name in ("CaWO4", "WO3", "Ca3WO6"):
        axes = inequivalent_axes(base.phase(phase_name), 2)
        print("ROUGH_AXIS_INVENTORY", source, phase_name, len(axes), axes, flush=True)
        jobs.extend((source, phase_name, axis) for axis in axes)
    workers = max(1, int(os.environ.get("MODEL_WORKERS", "6")))
    with ProcessPoolExecutor(max_workers=workers) as executor:
        futures = [executor.submit(rough_texture_job, job) for job in jobs]
        for future in as_completed(futures):
            tag, phase_name, axis, ratio, row = future.result()
            rows[tag] = row
            print(
                "ROUGH_MD_RESULT",
                source,
                phase_name,
                axis,
                f"Rwp={row['rwp']:.6f}",
                f"ratio={ratio:.6f}",
                f"invalid={row['invalid_or_collapsed']}",
                flush=True,
            )
    return rows


def write_rows(name: str, rows: dict) -> None:
    with (OUT / name).open("w") as handle:
        json.dump(rows, handle, indent=2)


def main() -> None:
    if len(sys.argv) < 3:
        raise SystemExit(
            "usage: model_screen.py SOURCE build|iso|texture|anisotropy|collective|build_elaborated|texture_elaborated|build_joint|joint_anisotropy|build_elaborated2|texture_elaborated2|rough_texture"
        )
    source, mode = sys.argv[1:3]
    if source not in SOURCES:
        raise SystemExit(f"unknown source {source}")
    if mode == "build":
        row = build(source)
        write_rows(f"build_{source}.json", row)
        print("BUILD_RESULT", source, json.dumps(row), flush=True)
    elif mode == "iso":
        rows = run_iso(source)
        write_rows(f"iso_{source}.json", rows)
    elif mode == "texture":
        rows = run_texture(source)
        write_rows(f"texture_{source}.json", rows)
    elif mode == "anisotropy":
        rows = run_anisotropy(source)
        write_rows(f"anisotropy_{source}.json", rows)
    elif mode == "collective":
        rows = run_collective(source)
        write_rows(f"collective_{source}.json", rows)
    elif mode == "build_elaborated":
        row = build_elaborated(source)
        write_rows(f"build_elaborated_{source}.json", row)
        print("ELAB_BUILD_RESULT", source, json.dumps(row), flush=True)
    elif mode == "texture_elaborated":
        rows = run_texture_elaborated(source)
        write_rows(f"texture_elaborated_{source}.json", rows)
    elif mode == "build_joint":
        row = build_joint(source)
        write_rows(f"build_joint_{source}.json", row)
        print("JOINT_BUILD_RESULT", source, json.dumps(row), flush=True)
    elif mode == "joint_anisotropy":
        rows = run_joint_anisotropy(source)
        write_rows(f"joint_anisotropy_{source}.json", rows)
    elif mode == "build_elaborated2":
        row = build_elaborated2(source)
        write_rows(f"build_elaborated2_{source}.json", row)
        print("ELAB2_BUILD_RESULT", source, json.dumps(row), flush=True)
    elif mode == "texture_elaborated2":
        rows = run_texture_elaborated2(source)
        write_rows(f"texture_elaborated2_{source}.json", rows)
    elif mode == "rough_texture":
        rows = run_rough_texture(source)
        write_rows(f"rough_texture_{source}.json", rows)
    else:
        raise SystemExit(f"unknown mode {mode}")


if __name__ == "__main__":
    main()
