#!/usr/bin/env python3
"""Follow-up competition between roughness, polarization and background."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc

import model_screen as ms


G2sc.SetPrintLevel("error")
OUT = ms.OUT


def refine(base, tag, mutate) -> dict:
    path = OUT / f"nuisance_{tag}.gpx"
    project = G2sc.G2Project(str(base), newgpx=str(path))
    histogram = project.histogram(0)
    mutate(project, histogram)
    project.save()
    project.refine(printFile=str(path.with_suffix(".lst")))
    project, histogram = ms.replay(path, attempts=3)
    row = ms.result(project, histogram)
    row["project"] = str(path.relative_to(ms.WORK))
    sample = histogram.data["Sample Parameters"]
    inst = histogram.data["Instrument Parameters"][0]
    row["polarization"] = float(inst["Polariz."][1])
    row["polarization_refined"] = bool(inst["Polariz."][2])
    row["roughness_a"] = float(sample["SurfRoughA"][0])
    row["roughness_b"] = float(sample["SurfRoughB"][0])
    row["background_count"] = int(histogram.data["Background"][0][2])
    print(
        "NUISANCE_RESULT",
        tag,
        f"Rwp={row['rwp']:.6f}",
        f"P={row['polarization']:.6f}",
        f"rough={row['roughness_a']:.6f},{row['roughness_b']:.6f}",
        f"bg={row['background_count']}",
        f"invalid={row['invalid_or_collapsed']}",
        flush=True,
    )
    return row


def rough_seed(project, histogram) -> None:
    sample = histogram.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.3779, True]
    sample["SurfRoughB"] = [0.5480, True]


def add_polarization(project, histogram) -> None:
    inst = histogram.data["Instrument Parameters"][0]
    inst["Polariz."][1] = 0.5
    inst["Polariz."][2] = True


def rough_and_pol(project, histogram) -> None:
    rough_seed(project, histogram)
    add_polarization(project, histogram)


def background_count(project, histogram, count: int) -> None:
    data = histogram.data["Background"][0]
    coefficients = list(data[3:])
    if count < len(coefficients):
        coefficients = coefficients[:count]
    else:
        coefficients.extend([0.0] * (count - len(coefficients)))
    histogram.data["Background"][0] = [data[0], True, count, *coefficients]


def rough_bg(project, histogram, count: int) -> None:
    rough_seed(project, histogram)
    background_count(project, histogram, count)


def add_rough_to_polarization(project, histogram) -> None:
    rough_seed(project, histogram)


def main() -> None:
    mono = ms.elaborated2_path("mono")
    tri = ms.elaborated2_path("tri")
    rough_mono = OUT / "challenge_mono_roughness_ab.gpx"
    pol_mono = OUT / "challenge_mono_polarization.gpx"
    rows = {
        "rough_tri": refine(tri, "rough_tri", rough_seed),
        "rough_plus_pol": refine(rough_mono, "rough_plus_pol", add_polarization),
        "pol_plus_rough": refine(pol_mono, "pol_plus_rough", add_rough_to_polarization),
        "rough_bg6": refine(mono, "rough_bg6", lambda p, h: rough_bg(p, h, 6)),
        "rough_bg10": refine(mono, "rough_bg10", lambda p, h: rough_bg(p, h, 10)),
    }
    with (OUT / "nuisance_followup.json").open("w") as handle:
        json.dump(rows, handle, indent=2)


if __name__ == "__main__":
    main()
