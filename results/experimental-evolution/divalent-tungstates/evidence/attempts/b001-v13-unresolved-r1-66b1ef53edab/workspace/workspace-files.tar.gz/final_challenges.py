#!/usr/bin/env python3
"""Deletion, collective-width, inventory and nuisance challenges for final basis."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import model_screen as ms


G2sc.SetPrintLevel("error")
OUT = ms.OUT


def run(source: str, tag: str, mutate, attempts: int = 3) -> dict:
    path = OUT / f"challenge_{source}_{tag}.gpx"
    project = G2sc.G2Project(str(ms.elaborated2_path(source)), newgpx=str(path))
    histogram = project.histogram(0)
    mutate(project, histogram)
    project.save()
    project.refine(printFile=str(path.with_suffix(".lst")))
    project, histogram = ms.replay(path, attempts=attempts)
    row = ms.result(project, histogram)
    row["project"] = str(path.relative_to(ms.WORK))
    print(
        "CHALLENGE_RESULT",
        source,
        tag,
        f"Rwp={row['rwp']:.6f}",
        f"invalid={row['invalid_or_collapsed']}",
        flush=True,
    )
    return row


def delete_texture(project, histogram) -> None:
    hap = project.phase("CaWO4").data["Histograms"][histogram.name]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def isotropic_size(project, histogram) -> None:
    hap = project.phase("CaWO4").data["Histograms"][histogram.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [0.094, 10.0, 1.0]
    hap["Size"][2] = [True, False, False]
    hap["Size"][3] = [0, 0, 1]


def delete_size(project, histogram) -> None:
    hap = project.phase("CaWO4").data["Histograms"][histogram.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][3] = [0, 0, 1]


def add_ca3_texture(project, histogram) -> None:
    hap = project.phase("Ca3WO6").data["Histograms"][histogram.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 0.70
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = [1, -1, -2]


def collective_extra_sizes(project, histogram, seed: float) -> None:
    for name in ("WO3", "Ca3WO6"):
        hap = project.phase(name).data["Histograms"][histogram.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [float(seed), 10.0, 1.0]
        hap["Size"][2] = [True, False, False]
        hap["Size"][3] = [0, 0, 1]


def collective_strains(project, histogram, seed: float) -> None:
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [float(seed), 0.0, 1.0]
        hap["Mustrain"][2] = [True, False, False]
        hap["Mustrain"][3] = [0, 0, 1]


def collective_all(project, histogram) -> None:
    collective_extra_sizes(project, histogram, 0.2)
    collective_strains(project, histogram, 10.0)


def remove_ca3(project, histogram) -> None:
    hap = project.phase("Ca3WO6").data["Histograms"][histogram.name]
    hap["Use"] = False
    hap["Scale"][1] = False


def add_physical_cao(project, histogram) -> None:
    phase = project.add_phase(
        str(ms.cod("1563196")),
        phasename="CaO_challenge",
        histograms=[histogram],
        fmthint="CIF",
    )
    ms.neutral_hap(phase, histogram, 0.2)
    phase.set_refinements({"Cell": False})


def background_count(project, histogram, count: int) -> None:
    data = histogram.data["Background"][0]
    coefficients = list(data[3:])
    if count < len(coefficients):
        coefficients = coefficients[:count]
    else:
        coefficients.extend([0.0] * (count - len(coefficients)))
    histogram.data["Background"][0] = [data[0], True, count, *coefficients]


def refine_polarization(project, histogram) -> None:
    inst = histogram.data["Instrument Parameters"][0]
    inst["Polariz."][1] = 0.5
    inst["Polariz."][2] = True


def roughness_b(project, histogram) -> None:
    sample = histogram.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.01, True]


def roughness_ab(project, histogram) -> None:
    sample = histogram.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.5, True]
    sample["SurfRoughB"] = [0.01, True]


def cross_seed(target: str, donor: str) -> dict:
    path = OUT / f"challenge_{target}_crossseed_from_{donor}.gpx"
    project = G2sc.G2Project(str(ms.elaborated2_path(target)), newgpx=str(path))
    source = G2sc.G2Project(str(ms.elaborated2_path(donor)))
    hist = project.histogram(0)
    donor_hist = source.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    donor_inst = donor_hist.data["Instrument Parameters"][0]
    for key in ("Zero", "U", "W", "X"):
        inst[key][1] = float(donor_inst[key][1])
    hist.data["Background"][0][3:] = list(donor_hist.data["Background"][0][3:])
    for name in ("CaWO4", "Ca3WO6"):
        phase = project.phase(name)
        donor_phase = source.phase(name)
        ms.set_cell(
            phase,
            [
                donor_phase.get_cell()[key]
                for key in (
                    "length_a",
                    "length_b",
                    "length_c",
                    "angle_alpha",
                    "angle_beta",
                    "angle_gamma",
                )
            ],
        )
        hap = phase.data["Histograms"][hist.name]
        donor_hap = donor_phase.data["Histograms"][donor_hist.name]
        hap["Scale"][0] = float(donor_hap["Scale"][0])
        if name == "CaWO4":
            hap["Size"][1] = list(donor_hap["Size"][1])
            hap["Pref.Ori."][1] = float(donor_hap["Pref.Ori."][1])
    project.phase("WO3").data["Histograms"][hist.name]["Scale"][0] = float(
        source.phase("WO3").data["Histograms"][donor_hist.name]["Scale"][0]
    )
    project.save()
    project.refine(printFile=str(path.with_suffix(".lst")))
    project, hist = ms.replay(path, attempts=3)
    row = ms.result(project, hist)
    row["project"] = str(path.relative_to(ms.WORK))
    print(
        "CROSSSEED_RESULT",
        target,
        donor,
        f"Rwp={row['rwp']:.6f}",
        f"invalid={row['invalid_or_collapsed']}",
        flush=True,
    )
    return row


def main() -> None:
    rows = {}
    for source in ("mono", "tri"):
        rows[source] = {}
        for tag, mutate in (
            ("delete_texture", delete_texture),
            ("isotropic_size", isotropic_size),
            ("delete_size", delete_size),
            ("add_ca3_texture", add_ca3_texture),
            ("collect_extra_sizes_0p2", lambda p, h: collective_extra_sizes(p, h, 0.2)),
            ("collect_all_strains_10", lambda p, h: collective_strains(p, h, 10.0)),
            ("collect_sizes_strains", collective_all),
        ):
            rows[source][tag] = run(source, tag, mutate)
    rows["mono"]["remove_ca3"] = run("mono", "remove_ca3", remove_ca3)
    rows["mono"]["add_physical_cao"] = run(
        "mono", "add_physical_cao", add_physical_cao
    )
    for count in (6, 10):
        rows["mono"][f"background_{count}"] = run(
            "mono", f"background_{count}", lambda p, h, n=count: background_count(p, h, n)
        )
    rows["mono"]["polarization"] = run(
        "mono", "polarization", refine_polarization
    )
    rows["mono"]["roughness_b"] = run("mono", "roughness_b", roughness_b)
    rows["mono"]["roughness_ab"] = run("mono", "roughness_ab", roughness_ab)
    rows["crossseed"] = {
        "mono_from_tri": cross_seed("mono", "tri"),
        "tri_from_mono": cross_seed("tri", "mono"),
    }
    with (OUT / "final_challenges.json").open("w") as handle:
        json.dump(rows, handle, indent=2)


if __name__ == "__main__":
    main()
