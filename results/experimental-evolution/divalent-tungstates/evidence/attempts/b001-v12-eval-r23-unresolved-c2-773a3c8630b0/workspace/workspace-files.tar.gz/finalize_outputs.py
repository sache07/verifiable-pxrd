#!/usr/bin/env python3
"""Replay the full measured range and freeze final GSAS-II/CIF/profile/JSON outputs."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


BASE = Path("trials/final_candidate.gpx")
PROJECT = Path("final.gpx")
FIT = Path("fit.csv")
RESULT = Path("result.json")

PHASE_OUTPUTS = {
    "SrWO4_scheelite": ("SrWO4 (scheelite)", "SrWO4", Path("phase_srwo4.cif"), "COD 2300460 adapted SrMoO4->SrWO4"),
    "WO3_C2c_2311041": ("WO3 (monoclinic)", "WO3", Path("phase_wo3.cif"), "COD 2311041"),
    "SrCO3_Pnma_9008198": ("SrCO3 (strontianite)", "SrCO3", Path("phase_srco3.cif"), "COD 9008198"),
}


def scalar(value):
    if value is None:
        return None
    return float(value)


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(BASE))
    project.save(str(PROJECT))
    histogram = project.histogram(0)
    measured_limits = histogram.data["Limits"][0]
    histogram.data["Limits"][1] = [float(measured_limits[0]), float(measured_limits[1])]
    project.save()

    replay = []
    for cycle in range(8):
        project.refine()
        rvals = project["Covariance"]["data"].get("Rvals", {})
        replay.append(
            {
                "cycle": cycle,
                "Rwp_percent": scalar(histogram.get_wR()),
                "GOF": scalar(rvals.get("GOF")),
                "max_shift_over_esd": scalar(rvals.get("Max shft/sig")),
            }
        )
        if rvals.get("Max shft/sig", 999.0) < 0.05:
            break
    project.save()

    inst = histogram.data["Instrument Parameters"][0]
    for key in ("U", "W", "X"):
        if inst[key][1] < 0:
            raise RuntimeError(f"final profile parameter {key} is negative")

    mass = histogram.ComputeMassFracs()
    total = sum(float(mass[name][0]) for name in PHASE_OUTPUTS)
    if total <= 0:
        raise RuntimeError("non-positive modeled crystalline mass total")

    phases = []
    for internal_name, (name, formula, cif_path, source) in PHASE_OUTPUTS.items():
        phase = project.phase(internal_name)
        hap = phase.data["Histograms"][histogram.name]
        if hap["Scale"][0] <= 0:
            raise RuntimeError(f"non-positive final scale for {internal_name}")
        phase.export_CIF(str(cif_path))
        fraction, fraction_esd = mass[internal_name]
        phases.append(
            {
                "name": name,
                "formula": formula,
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": str(cif_path),
                "project_path": str(PROJECT),
                "source_model": source,
                "weight_fraction": float(fraction) / total,
                "weight_fraction_esd": float(fraction_esd) / total,
            }
        )

    arrays = np.ma.filled(np.asarray(histogram.data["data"][1]), np.nan)
    x, observed, _weight, calculated, background, difference = arrays
    with FIT.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference", "background"])
        for row in zip(x, observed, calculated, difference, background):
            writer.writerow([f"{float(value):.10g}" for value in row])

    covariance = project["Covariance"]["data"]
    rvals = covariance.get("Rvals", {})
    summary = histogram.data["data"][0]
    fit_statistics = {
        "Rwp_percent": scalar(histogram.get_wR()),
        "Rp_percent": scalar(summary.get("R")),
        "GOF": scalar(rvals.get("GOF")),
        "reduced_chi_square": scalar(rvals.get("GOF") ** 2 if rvals.get("GOF") is not None else None),
        "chi_square": scalar(rvals.get("chisq")),
        "Nobs": int(rvals.get("Nobs")),
        "Nvars": int(rvals.get("Nvars")),
        "Durbin_Watson": scalar(summary.get("Durbin-Watson")),
        "refinement_range_two_theta_deg": [float(measured_limits[0]), float(measured_limits[1])],
    }
    output = {
        "project_path": str(PROJECT),
        "profile_path": str(FIT),
        "phases": phases,
        "fit_statistics": fit_statistics,
        "final_replay": replay,
        "fraction_basis": "normalized over modeled crystalline phases",
    }
    RESULT.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
