#!/usr/bin/env python3
"""Replay nuisance/instrument challenges from an accepted texture checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import traceback

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output_dir")
    parser.add_argument("results")
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    outdir = Path(args.output_dir)
    outdir.mkdir(parents=True, exist_ok=True)
    trials = [
        "replay",
        "background4",
        "background8",
        "polarization_fixed_0p5",
        "kalpha_ratio_refine",
        "kalpha1_only",
        "roughness_B_only",
    ]
    rows = []
    for trial in trials:
        row = {"trial": trial}
        try:
            project = G2sc.G2Project(args.base)
            project.save(outdir / f"{trial}.gpx")
            histogram = project.histogram(0)
            inst = histogram.data["Instrument Parameters"][0]
            sample = histogram.data["Sample Parameters"]
            if trial.startswith("background"):
                order = int(trial.replace("background", ""))
                histogram.set_refinements(
                    {
                        "Background": {
                            "type": "chebyschev-1",
                            "refine": True,
                            "no. coeffs": order,
                        }
                    }
                )
            elif trial == "polarization_fixed_0p5":
                inst["Polariz."][1:] = [0.5, False]
            elif trial == "kalpha_ratio_refine":
                inst["I(L2)/I(L1)"][1:] = [0.5, True]
            elif trial == "kalpha1_only":
                inst["I(L2)/I(L1)"][1:] = [0.0, False]
            elif trial == "roughness_B_only":
                sample["SurfRoughA"] = [0.0, False]
                sample["SurfRoughB"] = [0.02, True]
            project.save()
            history = []
            invalid = None
            for cycle in range(8):
                project.refine()
                rvals = project["Covariance"]["data"].get("Rvals", {})
                history.append(
                    {
                        "cycle": cycle,
                        "rwp_percent": histogram.get_wR(),
                        "gof": rvals.get("GOF"),
                        "converged": rvals.get("converged"),
                        "max_shift_over_esd": rvals.get("Max shft/sig"),
                    }
                )
                if trial == "kalpha_ratio_refine" and not (
                    0.0 <= inst["I(L2)/I(L1)"][1] <= 1.0
                ):
                    invalid = "K-alpha2/K-alpha1 ratio outside [0,1]"
                    break
                if trial == "roughness_B_only" and not (
                    0.0 <= sample["SurfRoughB"][0] <= 2.0
                ):
                    invalid = "roughness B outside conservative physical range"
                    break
                if rvals.get("Max shft/sig", 999.0) < 0.15:
                    break
            project.save()
            row.update(
                {
                    "status": "invalid" if invalid else "ok",
                    "invalid_reason": invalid,
                    "history": history,
                    "mass_fractions": histogram.ComputeMassFracs(),
                    "background": histogram.data["Background"][0],
                    "polarization": inst["Polariz."],
                    "kalpha_ratio": inst["I(L2)/I(L1)"],
                    "roughness_A": sample["SurfRoughA"],
                    "roughness_B": sample["SurfRoughB"],
                    "profile": {
                        key: inst[key] for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")
                    },
                    "shift": sample["Shift"],
                    "vary_list": project["Covariance"]["data"].get("varyList", []),
                }
            )
        except Exception as exc:
            row.update(
                {
                    "status": "error",
                    "error": str(exc),
                    "traceback": traceback.format_exc(),
                }
            )
        rows.append(row)
        print(json.dumps(row, indent=2), flush=True)
    Path(args.results).write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
