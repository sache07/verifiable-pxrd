#!/usr/bin/env python3
"""Replay source-model trials from the same neutral SrWO4 checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import traceback

from GSASII import GSASIIscriptable as G2sc


def neutralize(phase, histogram, scale: float) -> None:
    hap = phase.data["Histograms"][histogram.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [100.0, 100.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Scale"] = [scale, True]


def snapshot(project, histogram, phase, stage: str) -> dict:
    hap = phase.data["Histograms"][histogram.name]
    covariance = project["Covariance"]["data"]
    rvals = covariance.get("Rvals", {})
    scale_name = f"{phase.id}:{histogram.id}:Scale"
    scale_esd = None
    if scale_name in covariance.get("varyList", []):
        i = covariance["varyList"].index(scale_name)
        scale_esd = float(covariance["sig"][i])
    return {
        "stage": stage,
        "rwp_percent": histogram.get_wR(),
        "gof": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "scale": float(hap["Scale"][0]),
        "scale_esd": scale_esd,
        "cell": phase.get_cell(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output_dir")
    parser.add_argument("results")
    parser.add_argument("candidates_json")
    parser.add_argument("--initial-scale", type=float, default=0.5)
    parser.add_argument("--labels", nargs="*")
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    outdir = Path(args.output_dir)
    outdir.mkdir(parents=True, exist_ok=True)
    candidates = json.loads(Path(args.candidates_json).read_text())
    if args.labels:
        candidates = [row for row in candidates if row["label"] in args.labels]
    rows = []

    for candidate in candidates:
        label = candidate["label"]
        output = outdir / f"{label}.gpx"
        row = {"label": label, "cif": candidate["cif"], "stages": []}
        try:
            project = G2sc.G2Project(args.base)
            project.save(output)
            histogram = project.histogram(0)
            phase = project.add_phase(candidate["cif"], label, [histogram])
            neutralize(phase, histogram, args.initial_scale)
            phase.set_refinements({"Cell": False})
            project.save()

            project.refine()
            row["stages"].append(snapshot(project, histogram, phase, "scale_neutral"))
            if phase.HAPvalue("Scale", targethistlist=[histogram]) <= 0:
                raise RuntimeError("non-positive scale in neutral trial")

            phase.set_refinements({"Cell": True})
            project.refine()
            row["stages"].append(snapshot(project, histogram, phase, "cell_open"))
            project.refine()
            row["stages"].append(snapshot(project, histogram, phase, "replay"))
            project.save()
            row["status"] = "ok"
        except Exception as exc:
            row["status"] = "error"
            row["error"] = str(exc)
            row["traceback"] = traceback.format_exc()
        rows.append(row)
        print(json.dumps(row, indent=2), flush=True)

    Path(args.results).write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
