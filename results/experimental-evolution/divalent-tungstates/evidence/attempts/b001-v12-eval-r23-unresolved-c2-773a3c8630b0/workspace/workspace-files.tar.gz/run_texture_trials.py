#!/usr/bin/env python3
"""Compare simple low-index March-Dollase axes from one checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import traceback

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("phase")
    parser.add_argument("output_dir")
    parser.add_argument("results")
    parser.add_argument("axes", nargs="+", help="h,k,l entries such as 0,0,1")
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    outdir = Path(args.output_dir)
    outdir.mkdir(parents=True, exist_ok=True)
    rows = []
    for token in args.axes:
        axis = [int(value) for value in token.split(",")]
        tag = "".join(str(value).replace("-", "m") for value in axis)
        row = {"phase": args.phase, "axis": axis}
        try:
            project = G2sc.G2Project(args.base)
            project.save(outdir / f"md_{tag}.gpx")
            histogram = project.histogram(0)
            phase = project.phase(args.phase)
            hap = phase.data["Histograms"][histogram.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = axis
            project.save()
            history = []
            invalid = None
            for cycle in range(6):
                project.refine()
                rvals = project["Covariance"]["data"].get("Rvals", {})
                history.append(
                    {
                        "cycle": cycle,
                        "rwp_percent": histogram.get_wR(),
                        "gof": rvals.get("GOF"),
                        "converged": rvals.get("converged"),
                        "max_shift_over_esd": rvals.get("Max shft/sig"),
                        "ratio": float(hap["Pref.Ori."][1]),
                    }
                )
                if not 0.05 < hap["Pref.Ori."][1] < 20.0:
                    invalid = "March ratio outside conservative physical range"
                    break
                if rvals.get("Max shft/sig", 999.0) < 0.15:
                    break
            project.save()
            row.update(
                {
                    "status": "invalid" if invalid else "ok",
                    "invalid_reason": invalid,
                    "history": history,
                    "preferred_orientation": hap["Pref.Ori."],
                    "mass_fractions": histogram.ComputeMassFracs(),
                    "vary_list": project["Covariance"]["data"].get("varyList", []),
                }
            )
        except Exception as exc:
            row.update(
                {
                    "status": "error",
                    "error": str(exc),
                    "traceback": traceback.format_exc(),
                }
            )
        rows.append(row)
        print(json.dumps(row, indent=2), flush=True)
    Path(args.results).write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
