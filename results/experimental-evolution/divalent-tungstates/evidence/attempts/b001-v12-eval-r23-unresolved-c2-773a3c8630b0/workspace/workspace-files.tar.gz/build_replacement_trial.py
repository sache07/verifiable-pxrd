#!/usr/bin/env python3
"""Replace one active phase by a candidate while preserving shared nuisance values."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import traceback

from GSASII import GSASIIscriptable as G2sc


def neutralize(hap: dict) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]


def snapshot(project, histogram, phase, stage: str) -> dict:
    rvals = project["Covariance"]["data"].get("Rvals", {})
    hap = phase.data["Histograms"][histogram.name]
    return {
        "stage": stage,
        "rwp_percent": histogram.get_wR(),
        "gof": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "scale": float(hap["Scale"][0]),
        "cell": phase.get_cell(),
        "mass_fractions": histogram.ComputeMassFracs(),
    }


def replay(project, histogram, phase, stage: str, limit: int = 8) -> list[dict]:
    history = []
    for cycle in range(limit):
        project.refine()
        row = snapshot(project, histogram, phase, f"{stage}_{cycle}")
        history.append(row)
        if row["max_shift_over_esd"] is not None and row["max_shift_over_esd"] < 0.15:
            break
    return history


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("old_phase")
    parser.add_argument("candidate_cif")
    parser.add_argument("new_phase")
    parser.add_argument("output")
    parser.add_argument("result")
    parser.add_argument("--initial-scale", type=float, default=2.0)
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    row = {
        "base": args.base,
        "old_phase": args.old_phase,
        "candidate_cif": args.candidate_cif,
        "new_phase": args.new_phase,
        "history": [],
    }
    try:
        project = G2sc.G2Project(args.base)
        project.save(args.output)
        histogram = project.histogram(0)
        old = project.phase(args.old_phase)
        old.set_refinements({"Cell": False})
        old_hap = old.data["Histograms"][histogram.name]
        neutralize(old_hap)
        old_hap["Scale"] = [0.0, False]

        phase = project.add_phase(args.candidate_cif, args.new_phase, [histogram])
        phase.set_refinements({"Cell": False})
        hap = phase.data["Histograms"][histogram.name]
        neutralize(hap)
        hap["Scale"] = [args.initial_scale, True]
        project.save()

        row["history"].extend(replay(project, histogram, phase, "scale"))
        if hap["Scale"][0] <= 0.0:
            raise RuntimeError("replacement scale became non-positive")
        phase.set_refinements({"Cell": True})
        row["history"].extend(replay(project, histogram, phase, "cell"))
        project.save()
        row.update(
            {
                "status": "ok",
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "mass_fractions": histogram.ComputeMassFracs(),
                "vary_list": project["Covariance"]["data"].get("varyList", []),
            }
        )
    except Exception as exc:
        row.update(
            {
                "status": "error",
                "error": str(exc),
                "traceback": traceback.format_exc(),
            }
        )
    Path(args.result).write_text(json.dumps(row, indent=2) + "\n")
    print(json.dumps(row, indent=2))


if __name__ == "__main__":
    main()
