#!/usr/bin/env python3
"""Compare neutral, isotropic-size, strain and combined HAP profiles."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import traceback

from GSASII import GSASIIscriptable as G2sc


def neutral(hap: dict) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output_dir")
    parser.add_argument("results")
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    seed = G2sc.G2Project(args.base)
    phase_names = [phase.name for phase in seed.phases()]
    rows = []
    for phase_name in phase_names:
        for mode in ("neutral", "size", "strain", "combined"):
            label = phase_name.replace("/", "_") + "__" + mode
            row = {"phase": phase_name, "mode": mode, "label": label}
            try:
                project = G2sc.G2Project(args.base)
                project.save(output_dir / f"{label}.gpx")
                histogram = project.histogram(0)
                for phase in project.phases():
                    neutral(phase.data["Histograms"][histogram.name])
                phase = project.phase(phase_name)
                hap = phase.data["Histograms"][histogram.name]
                if mode in ("size", "combined"):
                    hap["Size"][1][0] = 2.0
                    hap["Size"][2][0] = True
                if mode in ("strain", "combined"):
                    hap["Mustrain"][1][0] = 500.0
                    hap["Mustrain"][2][0] = True
                project.save()
                history = []
                for cycle in range(5):
                    project.refine()
                    rvals = project["Covariance"]["data"].get("Rvals", {})
                    history.append(
                        {
                            "cycle": cycle,
                            "rwp_percent": histogram.get_wR(),
                            "gof": rvals.get("GOF"),
                            "converged": rvals.get("converged"),
                            "max_shift_over_esd": rvals.get("Max shft/sig"),
                        }
                    )
                    if rvals.get("Max shft/sig", 999.0) < 0.15:
                        break
                project.save()
                covariance = project["Covariance"]["data"]
                row.update(
                    {
                        "status": "ok",
                        "history": history,
                        "size": hap["Size"],
                        "mustrain": hap["Mustrain"],
                        "mass_fractions": histogram.ComputeMassFracs(),
                        "profile": {
                            key: histogram.data["Instrument Parameters"][0][key]
                            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")
                        },
                        "shift": histogram.data["Sample Parameters"]["Shift"],
                        "vary_list": covariance.get("varyList", []),
                        "sigmas": [float(value) for value in covariance.get("sig", [])],
                    }
                )
            except Exception as exc:
                row.update(
                    {
                        "status": "error",
                        "error": str(exc),
                        "traceback": traceback.format_exc(),
                    }
                )
            rows.append(row)
            print(json.dumps(row, indent=2), flush=True)
    Path(args.results).write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
