#!/usr/bin/env python3
"""Deactivate one phase completely and replay the remaining model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("phase")
    parser.add_argument("output")
    parser.add_argument("result")
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(args.base)
    project.save(args.output)
    histogram = project.histogram(0)
    phase = project.phase(args.phase)
    phase.set_refinements({"Cell": False})
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"] = [0.0, False]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    project.save()
    history = []
    for cycle in range(8):
        project.refine()
        rvals = project["Covariance"]["data"].get("Rvals", {})
        history.append(
            {
                "cycle": cycle,
                "rwp_percent": histogram.get_wR(),
                "gof": rvals.get("GOF"),
                "converged": rvals.get("converged"),
                "max_shift_over_esd": rvals.get("Max shft/sig"),
            }
        )
        if rvals.get("Max shft/sig", 999.0) < 0.15:
            break
    project.save()
    row = {
        "removed_phase": args.phase,
        "history": history,
        "mass_fractions": histogram.ComputeMassFracs(),
        "vary_list": project["Covariance"]["data"].get("varyList", []),
    }
    Path(args.result).write_text(json.dumps(row, indent=2) + "\n")
    print(json.dumps(row, indent=2))


if __name__ == "__main__":
    main()
