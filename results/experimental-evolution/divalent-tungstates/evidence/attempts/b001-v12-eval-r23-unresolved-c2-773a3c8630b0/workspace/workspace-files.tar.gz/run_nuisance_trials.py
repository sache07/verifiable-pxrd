#!/usr/bin/env python3
"""Reversible background, polarization and roughness comparisons."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import traceback

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output_dir")
    parser.add_argument("results")
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    outdir = Path(args.output_dir)
    outdir.mkdir(parents=True, exist_ok=True)
    trials = ["background4", "background6", "background8", "polarization", "roughness"]
    rows = []
    for trial in trials:
        row = {"trial": trial}
        try:
            project = G2sc.G2Project(args.base)
            project.save(outdir / f"{trial}.gpx")
            histogram = project.histogram(0)
            inst = histogram.data["Instrument Parameters"][0]
            sample = histogram.data["Sample Parameters"]
            if trial.startswith("background"):
                order = int(trial.replace("background", ""))
                histogram.set_refinements(
                    {
                        "Background": {
                            "type": "chebyschev-1",
                            "refine": True,
                            "no. coeffs": order,
                        }
                    }
                )
            elif trial == "polarization":
                inst["Polariz."][1] = 0.5
                inst["Polariz."][2] = True
            elif trial == "roughness":
                sample["SurfRoughA"] = [0.35, True]
                sample["SurfRoughB"] = [0.05, True]
            project.save()
            history = []
            invalid = None
            for cycle in range(6):
                project.refine()
                rvals = project["Covariance"]["data"].get("Rvals", {})
                history.append(
                    {
                        "cycle": cycle,
                        "rwp_percent": histogram.get_wR(),
                        "gof": rvals.get("GOF"),
                        "converged": rvals.get("converged"),
                        "max_shift_over_esd": rvals.get("Max shft/sig"),
                    }
                )
                if trial == "polarization" and not 0.0 <= inst["Polariz."][1] <= 1.0:
                    invalid = "polarization outside [0,1]"
                    break
                if trial == "roughness" and not (
                    0.0 <= sample["SurfRoughA"][0] <= 1.0
                    and sample["SurfRoughB"][0] >= 0.0
                ):
                    invalid = "roughness outside physical range"
                    break
                if rvals.get("Max shft/sig", 999.0) < 0.15:
                    break
            project.save()
            row.update(
                {
                    "status": "invalid" if invalid else "ok",
                    "invalid_reason": invalid,
                    "history": history,
                    "mass_fractions": histogram.ComputeMassFracs(),
                    "background": histogram.data["Background"][0],
                    "polarization": inst["Polariz."],
                    "roughness_A": sample["SurfRoughA"],
                    "roughness_B": sample["SurfRoughB"],
                    "profile": {key: inst[key] for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
                    "shift": sample["Shift"],
                    "vary_list": project["Covariance"]["data"].get("varyList", []),
                }
            )
        except Exception as exc:
            row.update(
                {
                    "status": "error",
                    "error": str(exc),
                    "traceback": traceback.format_exc(),
                }
            )
        rows.append(row)
        print(json.dumps(row, indent=2), flush=True)
    Path(args.results).write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
