#!/usr/bin/env python3
"""Run one reversible HAP broadening trial while preserving other phases."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import traceback

from GSASII import GSASIIscriptable as G2sc


def neutral(hap: dict) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("phase")
    parser.add_argument("mode", choices=("neutral", "size", "strain", "combined"))
    parser.add_argument("output")
    parser.add_argument("result")
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    row = {"phase": args.phase, "mode": args.mode, "base": args.base}
    try:
        project = G2sc.G2Project(args.base)
        project.save(args.output)
        histogram = project.histogram(0)
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][histogram.name]
        neutral(hap)
        if args.mode in ("size", "combined"):
            hap["Size"][1][0] = 2.0
            hap["Size"][2][0] = True
        if args.mode in ("strain", "combined"):
            hap["Mustrain"][1][0] = 500.0
            hap["Mustrain"][2][0] = True
        project.save()
        history = []
        invalid = None
        for cycle in range(6):
            project.refine()
            rvals = project["Covariance"]["data"].get("Rvals", {})
            history.append(
                {
                    "cycle": cycle,
                    "rwp_percent": histogram.get_wR(),
                    "gof": rvals.get("GOF"),
                    "converged": rvals.get("converged"),
                    "max_shift_over_esd": rvals.get("Max shft/sig"),
                    "size_um": float(hap["Size"][1][0]),
                    "mustrain_micro": float(hap["Mustrain"][1][0]),
                }
            )
            if hap["Size"][2][0] and not 0.00101 < hap["Size"][1][0] < 9.999:
                invalid = "size reached a bound"
                break
            if hap["Mustrain"][2][0] and hap["Mustrain"][1][0] <= 0.0:
                invalid = "mustrain became non-positive"
                break
            if rvals.get("Max shft/sig", 999.0) < 0.15:
                break
        project.save()
        covariance = project["Covariance"]["data"]
        row.update(
            {
                "status": "invalid" if invalid else "ok",
                "invalid_reason": invalid,
                "history": history,
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "mass_fractions": histogram.ComputeMassFracs(),
                "profile": {
                    key: histogram.data["Instrument Parameters"][0][key]
                    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")
                },
                "shift": histogram.data["Sample Parameters"]["Shift"],
                "vary_list": covariance.get("varyList", []),
            }
        )
    except Exception as exc:
        row.update(
            {
                "status": "error",
                "error": str(exc),
                "traceback": traceback.format_exc(),
            }
        )
    Path(args.result).write_text(json.dumps(row, indent=2) + "\n")
    print(json.dumps(row, indent=2))


if __name__ == "__main__":
    main()
