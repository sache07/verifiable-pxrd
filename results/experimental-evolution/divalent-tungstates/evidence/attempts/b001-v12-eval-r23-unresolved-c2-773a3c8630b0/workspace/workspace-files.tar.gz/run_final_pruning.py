#!/usr/bin/env python3
"""Replay final-model term removals and boundary challenges from one checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import traceback

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output_dir")
    parser.add_argument("results")
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    outdir = Path(args.output_dir)
    outdir.mkdir(parents=True, exist_ok=True)
    trials = [
        "replay",
        "background4",
        "background8",
        "polarization_fixed_0p5",
        "roughness_off",
        "profile_U_reopen",
        "profile_X_off",
        "srwo4_texture_off",
        "wo3_texture_off",
        "srco3_texture_off",
        "wo3_size_off",
        "wo3_phase_off",
        "srco3_phase_off",
    ]
    rows = []
    for trial in trials:
        row = {"trial": trial}
        try:
            project = G2sc.G2Project(args.base)
            project.save(outdir / f"{trial}.gpx")
            histogram = project.histogram(0)
            inst = histogram.data["Instrument Parameters"][0]
            sample = histogram.data["Sample Parameters"]
            phases = {phase.name: phase for phase in project.phases()}
            if trial.startswith("background"):
                order = int(trial.replace("background", ""))
                histogram.set_refinements(
                    {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": order}}
                )
            elif trial == "polarization_fixed_0p5":
                inst["Polariz."][1:] = [0.5, False]
            elif trial == "roughness_off":
                sample["SurfRoughA"] = [0.0, False]
                sample["SurfRoughB"] = [0.0, False]
            elif trial == "profile_U_reopen":
                inst["U"][1:] = [0.5, True]
            elif trial == "profile_X_off":
                inst["X"][1:] = [0.0, False]
            elif trial == "srwo4_texture_off":
                phases["SrWO4_scheelite"].data["Histograms"][histogram.name]["Pref.Ori."][1:3] = [1.0, False]
            elif trial == "wo3_texture_off":
                phases["WO3_C2c_2311041"].data["Histograms"][histogram.name]["Pref.Ori."][1:3] = [1.0, False]
            elif trial == "srco3_texture_off":
                phases["SrCO3_Pnma_9008198"].data["Histograms"][histogram.name]["Pref.Ori."][1:3] = [1.0, False]
            elif trial == "wo3_size_off":
                hap = phases["WO3_C2c_2311041"].data["Histograms"][histogram.name]
                hap["Size"][1][0] = 10.0
                hap["Size"][2][0] = False
            elif trial == "wo3_phase_off":
                phases["WO3_C2c_2311041"].data["Histograms"][histogram.name]["Scale"] = [0.0, False]
            elif trial == "srco3_phase_off":
                phases["SrCO3_Pnma_9008198"].data["Histograms"][histogram.name]["Scale"] = [0.0, False]
            project.save()
            history = []
            invalid = None
            for cycle in range(8):
                project.refine()
                rvals = project["Covariance"]["data"].get("Rvals", {})
                history.append(
                    {
                        "cycle": cycle,
                        "rwp_percent": histogram.get_wR(),
                        "gof": rvals.get("GOF"),
                        "converged": rvals.get("converged"),
                        "max_shift_over_esd": rvals.get("Max shft/sig"),
                    }
                )
                if trial == "profile_U_reopen" and inst["U"][1] < 0.0:
                    invalid = "U became negative"
                    break
                if rvals.get("Max shft/sig", 999.0) < 0.15:
                    break
            project.save()
            row.update(
                {
                    "status": "invalid" if invalid else "ok",
                    "invalid_reason": invalid,
                    "history": history,
                    "mass_fractions": histogram.ComputeMassFracs(),
                    "background": histogram.data["Background"][0],
                    "polarization": inst["Polariz."],
                    "roughness_A": sample["SurfRoughA"],
                    "roughness_B": sample["SurfRoughB"],
                    "profile": {key: inst[key] for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
                    "terms": {
                        name: {
                            "scale": phase.data["Histograms"][histogram.name]["Scale"],
                            "size": phase.data["Histograms"][histogram.name]["Size"][:3],
                            "texture": phase.data["Histograms"][histogram.name]["Pref.Ori."][:4],
                        }
                        for name, phase in phases.items()
                    },
                    "vary_list": project["Covariance"]["data"].get("varyList", []),
                }
            )
        except Exception as exc:
            row.update({"status": "error", "error": str(exc), "traceback": traceback.format_exc()})
        rows.append(row)
        print(json.dumps(row, indent=2), flush=True)
    Path(args.results).write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
