#!/usr/bin/env python3
"""Reopen and replay all active refinements from a saved GSAS-II checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output")
    parser.add_argument("result")
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(args.base)
    project.save(args.output)
    histogram = project.histogram(0)
    history = []
    for cycle in range(args.cycles):
        project.refine()
        rvals = project["Covariance"]["data"].get("Rvals", {})
        history.append(
            {
                "cycle": cycle,
                "rwp_percent": histogram.get_wR(),
                "gof": rvals.get("GOF"),
                "converged": rvals.get("converged"),
                "max_shift_over_esd": rvals.get("Max shft/sig"),
            }
        )
        if rvals.get("Max shft/sig", 999.0) < 0.05:
            break
    project.save()
    row = {
        "base": args.base,
        "history": history,
        "mass_fractions": histogram.ComputeMassFracs(),
        "vary_list": project["Covariance"]["data"].get("varyList", []),
    }
    Path(args.result).write_text(json.dumps(row, indent=2) + "\n")
    print(json.dumps(row, indent=2))


if __name__ == "__main__":
    main()
