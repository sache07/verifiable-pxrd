#!/usr/bin/env python3
"""Reopen nonnegative common U from a saved candidate checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output")
    parser.add_argument("result")
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(args.base)
    project.save(args.output)
    histogram = project.histogram(0)
    inst = histogram.data["Instrument Parameters"][0]
    inst["U"][1:] = [0.5, True]
    project.save()
    history = []
    status = "ok"
    reason = None
    for cycle in range(8):
        project.refine()
        rvals = project["Covariance"]["data"].get("Rvals", {})
        history.append(
            {
                "cycle": cycle,
                "rwp_percent": histogram.get_wR(),
                "gof": rvals.get("GOF"),
                "max_shift_over_esd": rvals.get("Max shft/sig"),
                "U": float(inst["U"][1]),
            }
        )
        if inst["U"][1] < 0.0:
            status, reason = "invalid", "U became negative"
            break
        if rvals.get("Max shft/sig", 999.0) < 0.15:
            break
    project.save()
    row = {
        "base": args.base,
        "status": status,
        "invalid_reason": reason,
        "history": history,
        "mass_fractions": histogram.ComputeMassFracs(),
        "profile": {key: inst[key] for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
    }
    Path(args.result).write_text(json.dumps(row, indent=2) + "\n")
    print(json.dumps(row, indent=2))


if __name__ == "__main__":
    main()
