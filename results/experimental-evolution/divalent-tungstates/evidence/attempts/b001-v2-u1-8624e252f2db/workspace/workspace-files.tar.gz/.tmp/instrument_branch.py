import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument('terms', choices=('UW', 'WX', 'UWX'))
args = parser.parse_args()

work = Path(__file__).resolve().parents[1]
source = work / '.tmp' / 'profile_size.gpx'
target = work / '.tmp' / f'instrument_{args.terms.lower()}.gpx'
gpx = G2sc.G2Project(str(source), newgpx=str(target))
gpx.data['Controls']['data']['max cyc'] = 12
gpx.data['Controls']['data']['min dM/M'] = 1e-5
hist = gpx.histogram(0)

for phase in gpx.phases():
    phase.clear_HAP_refinements({'Size': True, 'Mustrain': True}, [hist])

for term in ('U', 'V', 'W', 'X', 'Y', 'Z', 'SH/L'):
    hist.InstrumentParameters[term][2] = term in args.terms
for term in args.terms:
    gpx.set_Controls('parmMin', 0.0, variable=f':0:{term}')
    gpx.set_Controls('parmMax', 100.0, variable=f':0:{term}')

gpx.save()
gpx.do_refinements([{}, {}])
print(args.terms, hist.residuals)
print('instrument', {k: hist.InstrumentParameters[k] for k in ('U', 'V', 'W', 'X', 'Y', 'Z', 'SH/L')})
for phase in gpx.phases():
    hap = phase.getHAPvalues(hist)
    print(phase.name, 'size', hap['Size'][:3], 'strain', hap['Mustrain'][:3])
print('frozen', gpx.get_Frozen())
print('vary', gpx.get_VaryList())
print('last', gpx.data['Covariance']['data'].get('Rvals'))
gpx.save()
