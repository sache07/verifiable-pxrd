from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
gpx = G2sc.G2Project(str(work / '.tmp' / 'all_size.gpx'), newgpx=str(work / '.tmp' / 'test_shl.gpx'))
gpx.data['Controls']['data']['max cyc'] = 12
gpx.data['Controls']['data']['min dM/M'] = 1e-5
hist = gpx.histogram(0)
hist.InstrumentParameters['SH/L'][2] = True
gpx.set_Controls('parmMin', 0.002, variable=':0:SH/L')
gpx.set_Controls('parmMax', 0.1, variable=':0:SH/L')
gpx.save()
gpx.do_refinements([{}, {}])
print('residuals', hist.residuals)
print('SH/L', hist.InstrumentParameters['SH/L'])
print('frozen', gpx.get_Frozen(), 'last', gpx.data['Covariance']['data']['Rvals'])
gpx.save()
