from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
source = work / '.tmp' / 'instrument_uw.gpx'
target = work / '.tmp' / 'clean_baseline.gpx'
gpx = G2sc.G2Project(str(source), newgpx=str(target))
gpx.data['Controls']['data']['max cyc'] = 10
gpx.data['Controls']['data']['min dM/M'] = 1e-5
hist = gpx.histogram(0)

baseline_w = float(hist.InstrumentParameters['W'][1])
for term in ('U', 'V', 'X', 'Y', 'Z'):
    hist.InstrumentParameters[term] = [0.0, 0.0, False]
hist.InstrumentParameters['W'] = [baseline_w, baseline_w, False]
hist.InstrumentParameters['SH/L'] = [0.002, 0.002, False]
gpx.set_Frozen()
gpx.data['Controls']['data']['parmMinDict'] = {}
gpx.data['Controls']['data']['parmMaxDict'] = {}
for phase in gpx.phases():
    phase.clear_HAP_refinements({'Size': True, 'Mustrain': True}, [hist])
    phase.setSampleProfile(hist, 'microstrain', 'isotropic', 0.0, LGmix=1.0)

gpx.save()
gpx.do_refinements([{}, {}])
print('residuals', hist.residuals)
print('instrument', hist.InstrumentParameters)
for phase in gpx.phases():
    print(phase.name, phase.getHAPvalues(hist)['Size'][:3])
print('frozen', gpx.get_Frozen(), 'vary', gpx.get_VaryList())
gpx.save()
