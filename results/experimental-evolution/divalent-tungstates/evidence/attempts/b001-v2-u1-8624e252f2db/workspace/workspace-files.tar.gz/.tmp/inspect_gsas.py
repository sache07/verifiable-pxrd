from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

work = Path(__file__).resolve().parents[1]
root = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')


def cif(cod_id: str) -> Path:
    return root / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


gpx = G2sc.G2Project(newgpx=str(work / '.tmp' / 'inspect.gpx'))
hist = gpx.add_powder_histogram(
    str(work / 'inputs' / 'pattern.csv'),
    str(work / '.tmp' / 'lab_cuka.instprm'),
    fmthint='comma',
)
for name, cod_id in [('ZnWO4', '1520641'), ('ZnO', '9004178'), ('WO3', '2311041')]:
    gpx.add_phase(str(cif(cod_id)), phasename=name, histograms=[hist], fmthint='CIF')

print('hist', hist.name)
print('limits', hist.data['Limits'])
print('background', hist.Background)
print('instrument', hist.InstrumentParameters)
print('sample', hist.SampleParameters)
for phase in gpx.phases():
    print('\nPHASE', phase.name)
    print('composition', phase.composition)
    print('cell', phase.get_cell())
    print('HAP', phase.getHAPvalues(hist))
gpx.save()
