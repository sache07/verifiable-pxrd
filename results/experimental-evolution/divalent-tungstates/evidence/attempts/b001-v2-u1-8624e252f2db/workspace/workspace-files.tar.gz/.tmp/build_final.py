import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
COD_ROOT = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
FINAL_GPX = WORK / 'final.gpx'


def cod_cif(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


def fit_snapshot(gpx):
    hist = gpx.histogram(0)
    mass = hist.ComputeMassFracs()
    return {
        'Rwp': float(hist.residuals['wR']),
        'Rp': float(hist.residuals['R']),
        'GOF': float(gpx.data['Covariance']['data']['Rvals']['GOF']),
        'fractions': {name: float(value[0]) for name, value in mass.items()},
        'cells': {phase.name: phase.get_cell() for phase in gpx.phases()},
    }


G2sc.SetPrintLevel('all')
gpx = G2sc.G2Project(newgpx=str(FINAL_GPX))
gpx.data['Controls']['data']['max cyc'] = 12
gpx.data['Controls']['data']['min dM/M'] = 1e-5
hist = gpx.add_powder_histogram(
    str(WORK / 'inputs' / 'pattern.csv'),
    str(WORK / '.tmp' / 'lab_cuka.instprm'),
    fmthint='comma',
)

# Use every measured point and a fixed overall scale.
hist.set_refinements({'Limits': list(hist.data['Limits'][0])})
hist.SampleParameters['Scale'] = [1.0, False]
hist.SampleParameters['Shift'] = [-46.8, True]
hist.SampleParameters['DisplaceX'][1] = False
hist.SampleParameters['DisplaceY'][1] = False

# Clean common profile: lower-envelope W only; no unused width terms.
for term in ('U', 'V', 'X', 'Y', 'Z'):
    hist.InstrumentParameters[term] = [0.0, 0.0, False]
hist.InstrumentParameters['W'] = [6.603375079520773, 6.603375079520773, False]
hist.InstrumentParameters['SH/L'] = [0.002, 0.002, False]
hist.InstrumentParameters['Zero'] = [0.0, 0.0, False]
hist.InstrumentParameters['Polariz.'] = [0.5, 0.5, False]
hist.InstrumentParameters['I(L2)/I(L1)'] = [0.5, 0.5, False]

background = [
    1288.585168759918, -698.2646042508472, 472.0126666806133,
    -254.4303086276119, 118.458190747446, -38.147278647007795,
    11.50693709120367, -2.6993669898637296, 6.898189424946424,
    4.806467427526561,
]
hist.set_refinements({'Background': {
    'type': 'chebyschev-1', 'refine': True,
    'no. coeffs': len(background), 'coeffs': background,
}})

records = [
    ('ZnWO4', cod_cif('1520641'), 21.19055, 0.06218),
    ('ZnO', cod_cif('9004178'), 9.64906, 0.23104),
    ('WO3', WORK / '.tmp' / 'wo3_231_short.cif', 1.68636, 0.11310),
]
for i, (name, source, scale, size) in enumerate(records):
    phase = gpx.add_phase(str(source), phasename=name, histograms=[hist], fmthint='CIF')
    phase.HAPvalue('Scale', scale, [hist])
    phase.setSampleProfile(hist, 'size', 'isotropic', size, LGmix=1.0)
    phase.setSampleProfile(hist, 'microstrain', 'isotropic', 0.0, LGmix=1.0)
    phase.set_HAP_refinements({'Scale': True, 'Size': {
        'type': 'isotropic', 'refine': True,
    }}, [hist])
    phase.set_refinements({'Cell': True})
    gpx.set_Controls('parmMin', 0.005, variable=f'{i}:0:Size;i')
    gpx.set_Controls('parmMax', 5.0, variable=f'{i}:0:Size;i')

gpx.save()
gpx.do_refinements([{}, {}])
pre_replay = fit_snapshot(gpx)

# Remove temporary optimization bounds/frozen state, save, reopen, and replay
# the complete native GSAS-II calculation/refinement over the full data range.
gpx.set_Frozen()
gpx.data['Controls']['data']['parmMinDict'] = {}
gpx.data['Controls']['data']['parmMaxDict'] = {}
gpx.save()
del gpx

gpx = G2sc.G2Project(str(FINAL_GPX))
hist = gpx.histogram(0)
hist.set_refinements({'Limits': list(hist.data['Limits'][0])})
gpx.do_refinements([{}, {}])
gpx.save()
replay_1 = fit_snapshot(gpx)
del gpx

# A second reopen confirms that the submitted arrays are not stale.
gpx = G2sc.G2Project(str(FINAL_GPX))
hist = gpx.histogram(0)
gpx.do_refinements([{}])
gpx.save()
replay_2 = fit_snapshot(gpx)

if gpx.get_Frozen():
    raise RuntimeError(f'Final project contains frozen variables: {gpx.get_Frozen()}')

phase_paths = {
    'ZnWO4': WORK / 'ZnWO4.cif',
    'ZnO': WORK / 'ZnO.cif',
    'WO3': WORK / 'WO3.cif',
}
for phase in gpx.phases():
    phase.export_CIF(str(phase_paths[phase.name]))

profile = hist.data['data'][1]
fit_array = np.column_stack((profile[0], profile[1], profile[3], profile[4], profile[5]))
np.savetxt(
    WORK / 'fit.csv', fit_array, delimiter=',',
    header='two_theta_deg,observed,calculated,total_background,difference_observed_minus_calculated',
    comments='', fmt=['%.8f', '%.8f', '%.8f', '%.8f', '%.8f'],
)

mass = hist.ComputeMassFracs()
rvals = gpx.data['Covariance']['data']['Rvals']
residuals = hist.residuals
phase_source = {
    'ZnWO4': {'database': 'COD', 'record': '1520641'},
    'ZnO': {'database': 'COD', 'record': '9004178'},
    'WO3': {'database': 'COD', 'record': '2311041', 'setting': 'unimodular short-cell P 21/n'},
}
result = {
    'weight_fraction_basis': 'normalized over modeled crystalline phases',
    'phases': [],
    'fit_statistics': {
        'Rwp_percent': float(residuals['wR']),
        'Rp_percent': float(residuals['R']),
        'Rexp_percent': float(residuals['wRmin']),
        'GOF': float(rvals['GOF']),
        'chi_square': float(rvals['chisq']),
        'n_observations': int(rvals['Nobs']),
        'n_variables': int(rvals['Nvars']),
    },
    'replay_check': {
        'pre_replay': pre_replay,
        'first_reopen': replay_1,
        'second_reopen': replay_2,
    },
}
for phase in gpx.phases():
    value, esd = mass[phase.name]
    result['phases'].append({
        'name': phase.name,
        'formula': phase.name,
        'cif': phase_paths[phase.name].name,
        'weight_fraction': float(value),
        'weight_fraction_esd_statistical': float(esd),
        'source': phase_source[phase.name],
        'space_group': phase.data['General']['SGData']['SpGrp'].strip(),
        'cell': phase.get_cell(),
        'isotropic_size_micrometre': float(phase.getHAPvalues(hist)['Size'][1][0]),
    })

with open(WORK / 'result.json', 'w') as handle:
    json.dump(result, handle, indent=2)
    handle.write('\n')

print(json.dumps(result, indent=2))
print('final frozen', gpx.get_Frozen())
print('final vary', gpx.get_VaryList())
