import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('size', 'strain'))
args = parser.parse_args()

work = Path(__file__).resolve().parents[1]
source = work / '.tmp' / 'corr_shift.gpx'
target = work / '.tmp' / f'profile_{args.mode}.gpx'
gpx = G2sc.G2Project(str(source), newgpx=str(target))
gpx.data['Controls']['data']['max cyc'] = 12
gpx.data['Controls']['data']['min dM/M'] = 1e-5
hist = gpx.histogram(0)

for i, phase in enumerate(gpx.phases()):
    phase.clear_HAP_refinements({'Size': True, 'Mustrain': True}, [hist])
    if args.mode == 'size':
        phase.setSampleProfile(hist, 'size', 'isotropic', 0.05, LGmix=1.0)
        phase.setSampleProfile(hist, 'microstrain', 'isotropic', 0.0, LGmix=1.0)
        phase.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}}, [hist])
        gpx.set_Controls('parmMin', 0.005, variable=f'{i}:0:Size;i')
        gpx.set_Controls('parmMax', 5.0, variable=f'{i}:0:Size;i')
    else:
        phase.setSampleProfile(hist, 'size', 'isotropic', 1000.0, LGmix=1.0)
        phase.setSampleProfile(hist, 'microstrain', 'isotropic', 1000.0, LGmix=1.0)
        phase.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}}, [hist])
        gpx.set_Controls('parmMin', 0.0, variable=f'{i}:0:Mustrain;i')
        gpx.set_Controls('parmMax', 10000.0, variable=f'{i}:0:Mustrain;i')

gpx.save()
gpx.do_refinements([{}, {}])
print(args.mode, hist.residuals)
for phase in gpx.phases():
    hap = phase.getHAPvalues(hist)
    print(phase.name, 'size', hap['Size'][:3], 'strain', hap['Mustrain'][:3])
print('frozen', gpx.get_Frozen())
print('vary', gpx.get_VaryList())
print('last', gpx.data['Covariance']['data'].get('Rvals'))
gpx.save()
