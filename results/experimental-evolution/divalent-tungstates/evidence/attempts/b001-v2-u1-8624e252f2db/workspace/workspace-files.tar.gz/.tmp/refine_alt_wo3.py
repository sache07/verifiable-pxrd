from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
gpx = G2sc.G2Project(str(work / '.tmp' / 'wo3_152.gpx'), newgpx=str(work / '.tmp' / 'alt_wo3_final_profile.gpx'))
gpx.data['Controls']['data']['max cyc'] = 12
gpx.data['Controls']['data']['min dM/M'] = 1e-5
gpx.set_Frozen()
gpx.data['Controls']['data']['parmMinDict'] = {}
gpx.data['Controls']['data']['parmMaxDict'] = {}
hist = gpx.histogram(0)
hist.SampleParameters['Shift'] = [-46.8, True]
hist.SampleParameters['DisplaceX'][1] = False
hist.InstrumentParameters['Zero'][2] = False
for term in ('U', 'V', 'X', 'Y', 'Z'):
    hist.InstrumentParameters[term] = [0.0, 0.0, False]
hist.InstrumentParameters['W'] = [6.6033750795, 6.6033750795, False]
hist.InstrumentParameters['SH/L'] = [0.002, 0.002, False]
for i, (phase, start) in enumerate(zip(gpx.phases(), (0.0622, 0.231, 0.113))):
    phase.clear_HAP_refinements({'Size': True, 'Mustrain': True}, [hist])
    phase.setSampleProfile(hist, 'size', 'isotropic', start, LGmix=1.0)
    phase.setSampleProfile(hist, 'microstrain', 'isotropic', 0.0, LGmix=1.0)
    phase.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}}, [hist])
    gpx.set_Controls('parmMin', 0.005, variable=f'{i}:0:Size;i')
    gpx.set_Controls('parmMax', 5.0, variable=f'{i}:0:Size;i')
gpx.save()
gpx.do_refinements([{}, {}])
print('residuals', hist.residuals)
print('mass', hist.ComputeMassFracs())
for phase in gpx.phases():
    print(phase.name, phase.get_cell(), phase.getHAPvalues(hist)['Size'][:3])
print('frozen', gpx.get_Frozen(), 'last', gpx.data['Covariance']['data']['Rvals'])
gpx.save()
