from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
source = WORK / '.tmp' / 'wo3_231.gpx'

for mode in ('shift',):
    target = WORK / '.tmp' / f'corr_{mode}.gpx'
    gpx = G2sc.G2Project(str(source), newgpx=str(target))
    gpx.data['Controls']['data']['max cyc'] = 10
    gpx.data['Controls']['data']['min dM/M'] = 1e-5
    hist = gpx.histogram(0)
    hist.InstrumentParameters['Zero'][2] = mode == 'zero'
    hist.SampleParameters['Shift'][1] = mode == 'shift'
    hist.SampleParameters['DisplaceX'][1] = False
    hist.SampleParameters['DisplaceY'][1] = False
    gpx.save()
    gpx.do_refinements([{}, {}])
    print(mode, hist.residuals)
    print('zero', hist.InstrumentParameters['Zero'])
    print('displaceX', hist.SampleParameters['DisplaceX'])
    print('shift', hist.SampleParameters['Shift'])
    print('cells', {p.name: p.get_cell() for p in gpx.phases()})
    print('last', gpx.data['Covariance']['data'].get('Rvals'))
    gpx.save()
