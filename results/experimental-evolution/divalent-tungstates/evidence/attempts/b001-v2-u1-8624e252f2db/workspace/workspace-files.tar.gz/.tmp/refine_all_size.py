from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
source = work / '.tmp' / 'clean_baseline.gpx'
target = work / '.tmp' / 'all_size.gpx'
gpx = G2sc.G2Project(str(source), newgpx=str(target))
gpx.data['Controls']['data']['max cyc'] = 12
gpx.data['Controls']['data']['min dM/M'] = 1e-5
hist = gpx.histogram(0)
starts = (0.06215, 0.2330, 0.11282)
for i, (phase, start) in enumerate(zip(gpx.phases(), starts)):
    phase.clear_HAP_refinements({'Size': True, 'Mustrain': True}, [hist])
    phase.setSampleProfile(hist, 'size', 'isotropic', start, LGmix=1.0)
    phase.setSampleProfile(hist, 'microstrain', 'isotropic', 0.0, LGmix=1.0)
    phase.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}}, [hist])
    gpx.set_Controls('parmMin', 0.005, variable=f'{i}:0:Size;i')
    gpx.set_Controls('parmMax', 5.0, variable=f'{i}:0:Size;i')

gpx.save()
gpx.do_refinements([{}, {}])
print('residuals', hist.residuals)
print('mass', hist.ComputeMassFracs())
for phase in gpx.phases():
    hap = phase.getHAPvalues(hist)
    print(phase.name, 'cell', phase.get_cell(), 'size', hap['Size'][:3])
print('frozen', gpx.get_Frozen(), 'vary', gpx.get_VaryList())
print('last', gpx.data['Covariance']['data']['Rvals'])
gpx.save()
