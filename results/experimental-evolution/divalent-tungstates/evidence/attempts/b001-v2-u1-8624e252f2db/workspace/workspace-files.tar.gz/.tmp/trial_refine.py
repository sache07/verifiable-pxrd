import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
COD_ROOT = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')


def cif(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


def report(gpx, label):
    hist = gpx.histogram(0)
    print(f'\n## {label}')
    print('residuals', hist.residuals)
    print('instrument', {k: v[1:] for k, v in hist.InstrumentParameters.items()
                         if k in ('Zero', 'U', 'V', 'W', 'X', 'Y', 'SH/L')})
    print('sample', {k: hist.SampleParameters[k] for k in ('Scale', 'DisplaceX')})
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        print(phase.name, 'scale', hap['Scale'], 'cell', phase.get_cell(),
              'size', hap['Size'][:3], 'strain', hap['Mustrain'][:3])


parser = argparse.ArgumentParser()
parser.add_argument('wo3_id')
parser.add_argument('name')
args = parser.parse_args()

G2sc.SetPrintLevel('all')
out = WORK / '.tmp' / f'{args.name}.gpx'
gpx = G2sc.G2Project(newgpx=str(out))
gpx.data['Controls']['data']['max cyc'] = 8
gpx.data['Controls']['data']['min dM/M'] = 1e-5
hist = gpx.add_powder_histogram(
    str(WORK / 'inputs' / 'pattern.csv'),
    str(WORK / '.tmp' / 'lab_cuka.instprm'),
    fmthint='comma',
)
hist.SampleParameters['Scale'] = [1.0, False]
hist.set_refinements({'Limits': [10.0, 100.0]})
hist.set_refinements({'Background': {
    'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 10,
    'coeffs': [1400.0, -700.0, 350.0, -180.0, 90.0, -45.0, 20.0, -10.0, 5.0, 0.0],
}})

records = [('ZnWO4', '1520641'), ('ZnO', '9004178'), ('WO3', args.wo3_id)]
for name, cod_id in records:
    phase = gpx.add_phase(str(cif(cod_id)), phasename=name, histograms=[hist], fmthint='CIF')
    phase.HAPvalue('Scale', 1e-4, [hist])
    phase.setSampleProfile(hist, 'size', 'isotropic', 0.05, LGmix=1.0)
    phase.setSampleProfile(hist, 'microstrain', 'isotropic', 0.0, LGmix=1.0)

gpx.save()
report(gpx, 'initial')

# Refit background and all scales together, then reconverge with cells.
gpx.set_refinement({'set': {'Scale': True, 'Background': True}})
gpx.do_refinements([{}])
report(gpx, 'background + scales')

gpx.set_refinement({'set': {'Cell': True}})
gpx.do_refinements([{}])
gpx.do_refinements([{}])
report(gpx, 'background + scales + cells')
gpx.save()
