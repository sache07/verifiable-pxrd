import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument('phase_index', type=int, choices=(0, 1, 2))
parser.add_argument('mode', choices=('size', 'strain'))
args = parser.parse_args()

work = Path(__file__).resolve().parents[1]
source = work / '.tmp' / 'clean_baseline.gpx'
target = work / '.tmp' / f'challenge_p{args.phase_index}_{args.mode}.gpx'
gpx = G2sc.G2Project(str(source), newgpx=str(target))
gpx.data['Controls']['data']['max cyc'] = 12
gpx.data['Controls']['data']['min dM/M'] = 1e-5
hist = gpx.histogram(0)

for phase in gpx.phases():
    phase.clear_HAP_refinements({'Size': True, 'Mustrain': True}, [hist])

phase = gpx.phase(args.phase_index)
if args.mode == 'size':
    phase.setSampleProfile(hist, 'size', 'isotropic', 0.1, LGmix=1.0)
    phase.setSampleProfile(hist, 'microstrain', 'isotropic', 0.0, LGmix=1.0)
    phase.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}}, [hist])
    gpx.set_Controls('parmMin', 0.005, variable=f'{args.phase_index}:0:Size;i')
    gpx.set_Controls('parmMax', 5.0, variable=f'{args.phase_index}:0:Size;i')
else:
    phase.setSampleProfile(hist, 'size', 'isotropic', 1000.0, LGmix=1.0)
    phase.setSampleProfile(hist, 'microstrain', 'isotropic', 100.0, LGmix=1.0)
    phase.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}}, [hist])
    gpx.set_Controls('parmMin', 0.0, variable=f'{args.phase_index}:0:Mustrain;i')
    gpx.set_Controls('parmMax', 20000.0, variable=f'{args.phase_index}:0:Mustrain;i')

gpx.save()
gpx.do_refinements([{}, {}])
hap = phase.getHAPvalues(hist)
print(phase.name, args.mode, 'Rwp', hist.residuals['wR'], 'GOF', gpx.data['Covariance']['data']['Rvals']['GOF'])
print('size', hap['Size'][:3], 'strain', hap['Mustrain'][:3])
print('frozen', gpx.get_Frozen(), 'vary', gpx.get_VaryList())
gpx.save()
