#!/usr/bin/env python3
"""Numerically audit measured and calculated isolated peak profiles by phase."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TARGETS = {
    "MgWO4": [
        ("low", "100", 18.8655, 0.48, 0.16),
        ("middle", "211", 45.8346, 0.45, 0.18),
        ("high", "23-2", 74.5642, 0.48, 0.16),
    ],
    "WO3": [
        ("low", "002", 24.3498, 0.60, 0.25),
        ("middle", "004/041 family", 49.9178, 0.65, 0.28),
        ("high", "408/250/044 family", 71.9421, 0.70, 0.35),
    ],
    "MgO": [
        ("low", "200", 42.9129, 0.45, 0.17),
        ("middle", "220", 62.3144, 0.45, 0.17),
        ("high", "222", 78.6493, 0.48, 0.17),
    ],
}


def phase_profiles() -> tuple[np.ndarray, np.ndarray, dict[str, np.ndarray], float]:
    final = G2sc.G2Project(str(ROOT / "final.gpx"))
    full = final.histogram(0).data["data"][1]
    x = np.asarray(full[0], dtype=float)
    observed = np.asarray(full[1], dtype=float)
    difference = np.asarray(full[5], dtype=float)
    components: dict[str, np.ndarray] = {}
    for keep in TARGETS:
        path = ROOT / ".tmp" / f"audit_{keep}.gpx"
        project = G2sc.G2Project(str(ROOT / "final.gpx"), newgpx=str(path))
        hist = project.histogram(0)
        for phase in project.phases():
            if phase.name != keep:
                phase.data["Histograms"][hist.name]["Use"] = False
        project.set_Controls("cycles", 0)
        project.refine()
        arrays = hist.data["data"][1]
        components[keep] = np.asarray(arrays[3], dtype=float) - np.asarray(arrays[4], dtype=float)
    reconstructed = np.sum(list(components.values()), axis=0) + np.asarray(full[4], dtype=float)
    reconstruction_error = float(np.max(np.abs(reconstructed - np.asarray(full[3], dtype=float))))
    # Near a phase-isolated feature, measured phase signal is the calculated
    # phase component plus the measured whole-profile residual.
    observed_components = {name: component + difference for name, component in components.items()}
    return x, observed, {f"calc:{k}": v for k, v in components.items()} | {
        f"obs:{k}": v for k, v in observed_components.items()
    }, reconstruction_error


def metric(x: np.ndarray, y: np.ndarray, center: float, window: float, search: float) -> dict[str, float]:
    use = (x >= center - window) & (x <= center + window)
    xx = x[use]
    yy = gaussian_filter1d(np.asarray(y[use], dtype=float), 1.0)
    edge = max(4, len(xx) // 10)
    left_level = float(np.median(yy[:edge]))
    right_level = float(np.median(yy[-edge:]))
    baseline = np.linspace(left_level, right_level, len(xx))
    signal = yy - baseline

    local = (xx >= center - search) & (xx <= center + search)
    candidates = np.flatnonzero(local)
    peak_index = int(candidates[np.argmax(signal[local])])
    step = float(np.median(np.diff(xx)))
    position = float(xx[peak_index])
    if 0 < peak_index < len(xx) - 1:
        a, b, c = signal[peak_index - 1 : peak_index + 2]
        denominator = a - 2.0 * b + c
        if denominator:
            position += float(0.5 * (a - c) / denominator * step)

    half = float(signal[peak_index] / 2.0)
    left = peak_index
    while left > 0 and signal[left] > half:
        left -= 1
    right = peak_index
    while right < len(signal) - 1 and signal[right] > half:
        right += 1
    if left == peak_index or right == peak_index or left == 0 or right == len(signal) - 1:
        raise RuntimeError(f"half-height crossing not found near {center}")

    def crossing(i: int, j: int) -> float:
        return float(xx[i] + (half - signal[i]) * (xx[j] - xx[i]) / (signal[j] - signal[i]))

    xleft = crossing(left, left + 1)
    xright = crossing(right - 1, right)
    return {
        "position_deg": position,
        "fwhm_deg": xright - xleft,
        "left_half_width_deg": position - xleft,
        "right_half_width_deg": xright - position,
        "peak_height_counts": float(signal[peak_index]),
    }


def main() -> None:
    G2sc.SetPrintLevel("warn")
    x, _, profiles, reconstruction_error = phase_profiles()
    rows = []
    for phase, targets in TARGETS.items():
        for region, hkl, center, window, search in targets:
            observed = metric(x, profiles[f"obs:{phase}"], center, window, search)
            calculated = metric(x, profiles[f"calc:{phase}"], center, window, search)
            rows.append(
                {
                    "phase": phase,
                    "region": region,
                    "hkl": hkl,
                    "reference_position_deg": center,
                    "observed": observed,
                    "calculated": calculated,
                }
            )
    output = {"component_reconstruction_max_error_counts": reconstruction_error, "peaks": rows}
    (ROOT / "peak_audit.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
