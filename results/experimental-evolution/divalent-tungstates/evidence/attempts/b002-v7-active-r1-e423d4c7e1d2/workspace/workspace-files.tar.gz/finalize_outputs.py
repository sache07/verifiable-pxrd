#!/usr/bin/env python3
"""Freeze, replay, and export the accepted GSAS-II model."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "challenges" / "mono231_size_uni110_plus_strain" / "model.gpx"
FINAL = ROOT / "final.gpx"


def prune_and_freeze(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    x = np.asarray(hist.data["data"][1][0], dtype=float)
    hist.data["Limits"][1] = [float(x.min()), float(x.max())]

    # Retain a smooth ten-term background and one angular correction (Zero).
    background = hist.data["Background"][0]
    background[0] = "chebyschev-1"
    background[1] = True
    while len(background[3:]) > 10:
        background.pop()
    while len(background[3:]) < 10:
        background.append(0.0)

    inst = hist.data["Instrument Parameters"][0]
    for key in inst:
        if isinstance(inst[key], list) and len(inst[key]) > 2:
            inst[key][2] = False
    # U refined to its nonnegative lower bound and is therefore pruned.
    for key in ["U", "V", "Y", "Z"]:
        inst[key][0] = 0.0
        inst[key][1] = 0.0
    inst["W"][2] = True
    inst["X"][2] = True
    inst["Zero"][2] = True
    inst["SH/L"][0] = inst["SH/L"][1] = 0.002
    inst["Polariz."][0] = inst["Polariz."][1] = 0.5
    inst["I(L2)/I(L1)"][0] = inst["I(L2)/I(L1)"][1] = 0.5

    sample = hist.data["Sample Parameters"]
    for key, value in sample.items():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.set_refinements({"Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        hap["LeBail"] = False
        hap["Scale"][1] = True
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False
        for item in hap["Babinet"].values():
            item[0] = 0.0
            item[1] = False

    mgwo4 = project.phase("MgWO4").data["Histograms"][hist.name]
    mgwo4["Pref.Ori."][0] = "MD"
    mgwo4["Pref.Ori."][2] = True
    mgwo4["Pref.Ori."][3] = [0, 1, 0]

    wo3 = project.phase("WO3").data["Histograms"][hist.name]
    wo3["Size"][0] = "uniaxial"
    wo3["Size"][2] = [True, True, False]
    wo3["Size"][3] = [1, 1, 0]
    wo3["Mustrain"][0] = "isotropic"
    wo3["Mustrain"][2] = [True, False, False]

    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    for key in ["parmMinDict", "parmMaxDict"]:
        if key in controls:
            controls[key] = {var: val for var, val in controls[key].items() if str(var) != ":0:U"}


def converge(project: G2sc.G2Project, maximum_runs: int = 6) -> None:
    project.set_Controls("cycles", 16)
    for _ in range(maximum_runs):
        project.refine()
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        if rvals.get("converged") and rvals.get("Max shft/sig", 999.0) < 0.05:
            break
    project.save()


def export_outputs(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    phase_files = {
        "MgWO4": ROOT / "phase_MgWO4.cif",
        "WO3": ROOT / "phase_WO3.cif",
        "MgO": ROOT / "phase_MgO.cif",
    }
    for phase in project.phases():
        phase.export_CIF(str(phase_files[phase.name]))

    arrays = hist.data["data"][1]
    profile = np.column_stack([arrays[0], arrays[1], arrays[3], arrays[5], arrays[4]])
    np.savetxt(
        ROOT / "fit.csv",
        profile,
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
        fmt="%.10g",
    )

    mass_fractions = hist.ComputeMassFracs()
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    residuals = hist.residuals
    formulas = {"MgWO4": "MgWO4", "WO3": "WO3", "MgO": "MgO"}
    result = {
        "phases": [
            {
                "name": phase.name,
                "formula": formulas[phase.name],
                "cif_path": phase_files[phase.name].name,
                "weight_fraction": float(mass_fractions[phase.name][0]),
                "weight_fraction_esd": float(mass_fractions[phase.name][1]),
            }
            for phase in project.phases()
        ],
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
        },
        "profile_path": "fit.csv",
        "project_path": "final.gpx",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def verify(result: dict) -> None:
    parsed = json.loads((ROOT / "result.json").read_text())
    fractions = [phase["weight_fraction"] for phase in parsed["phases"]]
    assert all(isinstance(value, (int, float)) and math.isfinite(value) for value in fractions)
    assert abs(sum(fractions) - 1.0) < 1e-9
    assert parsed["project_path"] == "final.gpx"
    assert FINAL.is_file()
    assert (ROOT / parsed["profile_path"]).is_file()
    assert all((ROOT / phase["cif_path"]).is_file() for phase in parsed["phases"])
    assert parsed == result

    reopened = G2sc.G2Project(str(FINAL))
    fractions_reopened = reopened.histogram(0).ComputeMassFracs()
    for phase in parsed["phases"]:
        assert abs(phase["weight_fraction"] - fractions_reopened[phase["name"]][0]) < 1e-9
    arrays = reopened.histogram(0).data["data"][1]
    fit = np.genfromtxt(ROOT / "fit.csv", delimiter=",", names=True)
    assert len(fit) == len(arrays[0])
    assert np.allclose(fit["observed"], arrays[1], rtol=0, atol=1e-6)
    assert np.allclose(fit["calculated"], arrays[3], rtol=0, atol=1e-5)
    assert np.allclose(fit["difference"], arrays[5], rtol=0, atol=1e-5)


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    prune_and_freeze(project)
    project.save()
    converge(project)

    # Required reopen/replay of the complete measured range.
    project = G2sc.G2Project(str(FINAL))
    converge(project)
    result = export_outputs(project)
    verify(result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
