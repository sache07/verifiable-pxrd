#!/usr/bin/env python3
"""Replay a saved GSAS-II baseline with one controlled nuisance-model change."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def converge(project: G2sc.G2Project, max_runs: int = 6) -> None:
    project.set_Controls("cycles", 12)
    for _ in range(max_runs):
        project.refine()
        result = project.data["Covariance"]["data"].get("Rvals", {})
        if result.get("converged") and result.get("Max shft/sig", 999.0) < 0.1:
            break
    project.save()


def summary(project: G2sc.G2Project, mode: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "mode": mode,
        "Rwp": hist.residuals.get("wR"),
        "Rexp": hist.residuals.get("wRmin"),
        "GOF": rvals.get("GOF"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "n_variables": rvals.get("Nvars"),
        "mass_fractions": hist.ComputeMassFracs(),
        "background_coefficients": hist.data["Background"][0][3:],
        "instrument": {key: inst[key][1] for key in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]},
        "sample": {key: sample[key][0] for key in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]},
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
                "pref_ori": phase.data["Histograms"][hist.name]["Pref.Ori."],
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in project.phases()
        },
        "vary_list": project.get_VaryList(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("tag")
    parser.add_argument(
        "mode",
        choices=[
            "background",
            "polarization",
            "roughness",
            "texture",
            "size",
            "strain",
            "size_uniaxial",
            "size_plus_strain",
            "omit_phase",
        ],
    )
    parser.add_argument("--coefficients", type=int)
    parser.add_argument("--phase", default="MgWO4")
    parser.add_argument("--axis", type=int, nargs=3)
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    outdir = ROOT / "challenges" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    output = outdir / "model.gpx"
    project = G2sc.G2Project(gpxfile=str(args.source), newgpx=str(output))
    project.save()
    hist = project.histogram(0)

    if args.mode == "background":
        if args.coefficients is None:
            parser.error("--coefficients is required for background mode")
        hist.set_refinements({"Background": {"refine": True, "no. coeffs": args.coefficients}})
    elif args.mode == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif args.mode == "roughness":
        hist.data["Sample Parameters"]["SurfRoughA"] = [0.5, True]
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.01, True]
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    elif args.mode == "texture":
        if args.axis is None:
            parser.error("--axis is required for texture mode")
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(args.axis)
        project.set_Controls("parmMin", 0.1, variable=f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 10.0, variable=f"{phase.id}:0:MD")
    elif args.mode in {"size", "strain"}:
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][hist.name]
        if args.mode == "size":
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 1.0
            hap["Size"][2] = [False for _ in hap["Size"][2]]
            hap["Size"][2][0] = True
        else:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 1000.0
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
            hap["Mustrain"][2][0] = True
    elif args.mode == "size_uniaxial":
        if args.axis is None:
            parser.error("--axis is required for size_uniaxial mode")
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][hist.name]
        starting_size = float(hap["Size"][1][0])
        hap["Size"][0] = "uniaxial"
        hap["Size"][1][0] = starting_size
        hap["Size"][1][1] = starting_size
        hap["Size"][2] = [True, True, False]
        hap["Size"][3] = list(args.axis)
    elif args.mode == "size_plus_strain":
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][2][0] = True
    elif args.mode == "omit_phase":
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = False
        hap["Scale"][1] = False

    converge(project)
    result = summary(project, args.mode)
    (outdir / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: result[k] for k in ["mode", "Rwp", "Rexp", "GOF", "max_shift_over_esd", "mass_fractions", "instrument", "sample"]}))
    if args.mode == "texture":
        print(json.dumps({args.phase: result["phases"][args.phase]["pref_ori"]}))


if __name__ == "__main__":
    main()
