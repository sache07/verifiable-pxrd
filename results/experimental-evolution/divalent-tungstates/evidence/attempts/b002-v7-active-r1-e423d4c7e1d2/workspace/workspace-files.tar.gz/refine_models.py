#!/usr/bin/env python3
"""Build and refine controlled GSAS-II candidate models for the PXRD pattern."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PHASES = {
    "MgWO4": "9013902",
    "MgO": "9000499",
    "WO3_1528915": "1528915",
    "WO3_2311041": "2311041",
    "WO3_2106293": "2106293",
    "WO3_1010618": "1010618",
    "WO3_2107312": "2107312",
    "WO3_1521532": "1521532",
    "WO3_1521533": "1521533",
}


def cif_for(key: str) -> Path:
    cod_id = PHASES[key]
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def scalar(v):
    if isinstance(v, np.generic):
        return v.item()
    return v


def state(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    out = {
        "label": label,
        "residuals": {k: scalar(v) for k, v in hist.residuals.items()},
        "instrument": {k: scalar(v[1]) for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
        "background": [scalar(v) for v in hist.data["Background"][0][3:]],
        "phases": {},
    }
    try:
        mass_fracs = hist.ComputeMassFracs()
    except Exception as exc:
        mass_fracs = {"error": repr(exc)}
    out["mass_fractions"] = mass_fracs
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": {k: scalar(v) for k, v in phase.get_cell().items()},
            "scale": scalar(hap["Scale"][0]),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    print(
        json.dumps(
            {
                "label": label,
                "Rwp": out["residuals"].get("wR"),
                "GOF": rvals.get("GOF"),
                "max_shift_over_esd": rvals.get("Max shft/sig"),
                "mass_fractions": mass_fracs,
                "Zero": out["instrument"].get("Zero"),
                "U": out["instrument"].get("U"),
                "W": out["instrument"].get("W"),
                "X": out["instrument"].get("X"),
            },
            default=scalar,
        )
    )
    return out


def set_initial_model(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    # The histogram/sample scale is fixed; only phase scales are varied.
    hist.data["Sample Parameters"]["Scale"][0] = 1.0
    hist.data["Sample Parameters"]["Scale"][1] = False
    # Smooth, low-dimensional background. Unused profile terms are fixed at zero.
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 10,
                "coeffs": [3650.0] + [0.0] * 9,
            },
        }
    )
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {
        "U": 2.0,
        "V": 0.0,
        "W": 1.0,
        "X": 0.5,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "Zero": 0.0,
        "Polariz.": 0.5,
        "I(L2)/I(L1)": 0.5,
    }.items():
        inst[key][0] = value
        inst[key][1] = value
        inst[key][2] = False
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][0] = {"MgWO4": 60.0, "WO3": 10.0, "MgO": 25.0}.get(phase.name, 10.0)
        hap["Scale"][1] = True
        phase.data["General"]["Cell"][0] = False
        # Neutralize all phase-specific nuisance terms for the baseline.
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        for item in hap["Babinet"].values():
            item[0] = 0.0
            item[1] = False


def build(tag: str, wo3_key: str, include_mgo: bool = True, include_wo3: bool = True) -> tuple[G2sc.G2Project, Path]:
    outdir = ROOT / "models" / tag
    outdir.mkdir(parents=True, exist_ok=True)
    gpx = outdir / "model.gpx"
    if gpx.exists():
        gpx.unlink()
    project = G2sc.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma/tab/semicolon separated",
    )
    project.add_phase(str(cif_for("MgWO4")), phasename="MgWO4", histograms=[hist], fmthint="CIF")
    if include_wo3:
        project.add_phase(str(cif_for(wo3_key)), phasename="WO3", histograms=[hist], fmthint="CIF")
    if include_mgo:
        project.add_phase(str(cif_for("MgO")), phasename="MgO", histograms=[hist], fmthint="CIF")
    project.set_Controls("cycles", 12)
    set_initial_model(project)
    project.save()
    return project, outdir


def run_baseline(project: G2sc.G2Project, outdir: Path) -> list[dict]:
    hist = project.histogram(0)
    log = []

    # Establish scales/background first with source cells and a neutral profile.
    project.refine()
    log.append(state(project, "scales_background"))

    # Refit source cells with one common angular correction (zero shift).
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    log.append(state(project, "cells_zero"))

    # Common low-dimensional nonnegative U/W/X instrumental baseline.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMin", 0.0, variable=":0:W")
    project.set_Controls("parmMin", 0.0, variable=":0:X")
    project.refine()
    log.append(state(project, "common_UWX"))

    # Replay once after any parameter-limit freezing (typically U=0) and save.
    project.refine()
    log.append(state(project, "common_UWX_replay"))

    project.save()
    (outdir / "states.json").write_text(json.dumps(log, indent=2, default=scalar) + "\n")
    return log


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tag", required=True)
    parser.add_argument("--wo3", default="WO3_2311041", choices=sorted(k for k in PHASES if k.startswith("WO3_")))
    parser.add_argument("--no-mgo", action="store_true")
    parser.add_argument("--no-wo3", action="store_true")
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    project, outdir = build(args.tag, args.wo3, not args.no_mgo, not args.no_wo3)
    run_baseline(project, outdir)


if __name__ == "__main__":
    main()
