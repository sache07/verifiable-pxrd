from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summarize(project, label):
    hist = project.histogram(0)
    print(f"\nSUMMARY {label}")
    print("residuals", hist.residuals)
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items() if k not in ("Type", "Bank")})
    print("background", hist.data["Background"][0])
    print("sample", hist.SampleParameters)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("phase", phase.name, "cell", phase.get_cell(), "scale", hap["Scale"], "size", hap["Size"], "mustrain", hap["Mustrain"])
    cov = project.data.get("Covariance", {}).get("data", {})
    print("varyList", cov.get("varyList", []))
    print("variables", cov.get("variables", []))
    print("sig", cov.get("sig", []))
    print("Rvals", cov.get("Rvals", {}))
    print("frozen", project.data["Controls"]["data"].get("parmFrozen", {}))


gpx = ROOT / ".tmp" / "baseline.gpx"
project = G2sc.G2Project(newgpx=str(gpx))
hist = project.add_powder_histogram(
    str(ROOT / ".tmp" / "pattern.xye"),
    str(ROOT / ".tmp" / "cu_ka_lab.instprm"),
    fmthint="xye",
)

for name, cod_id in [
    ("PbWO4_scheelite", "9009811"),
    ("WO3_monoclinic", "1528915"),
    ("Pb3O4_minium", "9012124"),
]:
    phase = project.add_phase(
        str(cod_path(cod_id)),
        phasename=name,
        histograms=[hist],
        fmthint="CIF",
    )
    for atom in phase.atoms():
        if atom.uiso <= 0:
            atom.uiso = 0.01
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]

hist.SampleParameters["Scale"] = [1.0, False]
hist.set_refinements({
    "Limits": [10.0, 100.0],
    "Background": {
        "type": "chebyschev-1",
        "refine": True,
        "no. coeffs": 12,
        "coeffs": [1900.0, -1300.0, 300.0, -150.0, 80.0, -40.0, 20.0, -10.0, 5.0, 0.0, 0.0, 0.0],
    },
})
project.set_Controls("cycles", 8)
project.save()
project.refine()
summarize(project, "background_scales")

hist.set_refinements({"Instrument Parameters": ["Zero"]})
for phase in project.phases():
    phase.set_refinements({"Cell": True})
project.refine()
summarize(project, "zero_cells")
project.save()
