import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parents[1]
project = G2sc.G2Project(str(root / "final.gpx"))
hist = project.histogram(0)
phases = project.phases()
if len(phases) != 3:
    raise RuntimeError(f"Expected three final phases, found {len(phases)}")

phase_meta = [
    {
        "name": "PbWO4",
        "phase_label": "scheelite",
        "space_group": "I 41/a",
        "space_group_number": 88,
        "cod_id": "9009811",
        "cif_path": "phase_PbWO4_scheelite.cif",
    },
    {
        "name": "WO3",
        "phase_label": "monoclinic",
        "space_group": "P 21/c",
        "space_group_number": 14,
        "cod_id": "2311041",
        "cif_path": "phase_WO3_monoclinic.cif",
    },
    {
        "name": "Pb3O4",
        "phase_label": "minium",
        "space_group": "P 42/m b c",
        "space_group_number": 135,
        "cod_id": "9012124",
        "cif_path": "phase_Pb3O4_minium.cif",
    },
]

mass = hist.ComputeMassFracs()
phase_results = []
for phase, meta in zip(phases, phase_meta):
    phase.export_CIF(str(root / meta["cif_path"]))
    fraction, fraction_esd = mass[phase.name]
    cell, cell_esd = phase.get_cell_and_esd()
    item = dict(meta)
    cod_id = item.pop("cod_id")
    item.update(
        {
            "cif_path": meta["cif_path"],
            "weight_fraction": float(fraction),
            "weight_percent": float(100.0 * fraction),
            "weight_fraction_formal_esd": float(fraction_esd),
            "cell": {key: float(value) for key, value in cell.items()},
            "cell_formal_esd": {
                key: float(value) for key, value in cell_esd.items()
            },
            "source_structure": {
                "database": "Crystallography Open Database",
                "id": cod_id,
            },
        }
    )
    phase_results.append(item)

x, yobs, weight, ycalc, ybkg, ydiff = [
    np.asarray(values, dtype=float) for values in hist.data["data"][1][:6]
]
with (root / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(
        [
            "two_theta_deg",
            "observed_counts",
            "calculated_counts",
            "difference_counts",
            "background_counts",
            "weight",
        ]
    )
    writer.writerows(zip(x, yobs, ycalc, ydiff, ybkg, weight))

rvals = project.data["Covariance"]["data"]["Rvals"]
residuals = hist.residuals
gof = float(rvals["GOF"])
result = {
    "method": "GSAS-II Rietveld refinement",
    "input_pattern": "inputs/pattern.csv",
    "project_path": "final.gpx",
    "fit_profile_path": "fit.csv",
    "phase_fraction_normalization": (
        "Weight fractions sum to 1 over the three modeled crystalline phases; "
        "amorphous or unidentified content is not quantified."
    ),
    "phases": phase_results,
    "fit_statistics": {
        "Rwp_percent": float(residuals["wR"]),
        "Rp_percent": float(residuals["R"]),
        "R_expected_percent": float(residuals["wRmin"]),
        "background_Rwp_percent": float(residuals["wRb"]),
        "goodness_of_fit_sqrt_reduced_chi_squared": gof,
        "reduced_chi_squared": gof * gof,
        "weighted_sum_of_squares": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_parameters": int(rvals["Nvars"]),
        "max_shift_over_esd_last_cycle": float(rvals["Max shft/sig"]),
    },
}

with (root / "result.json").open("w") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

print(json.dumps(result, indent=2))
