import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


path = Path(sys.argv[1]).resolve()
project = G2sc.G2Project(str(path))
project.set_Controls("cycles", 12)
project.data["Controls"]["data"]["parmFrozen"] = {}

variables = []
for phase_index, phase in enumerate(project.phases()):
    for atom_index, atom in enumerate(phase.atoms()):
        if atom.adp_flag != "I":
            raise RuntimeError("Final model unexpectedly contains anisotropic ADPs")
        atom.ADP = 0.005
        atom.refinement_flags = "U"
        variable = f"{phase_index}::AUiso:{atom_index}"
        variables.append(variable)
        project.set_Controls("parmMin", 0.0005, variable)
        project.set_Controls("parmMax", 0.03, variable)

project.add_EquivConstr(tuple(variables))
project.save()
hist = project.histogram(0)
for index in range(8):
    project.refine()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    values = [[atom.uiso for atom in phase.atoms()] for phase in project.phases()]
    print(
        "PASS", index + 1, "Uiso", values, "Rwp", hist.get_wR(),
        "maxshift", rvals.get("Max shft/sig"),
        "frozen", project.data["Controls"]["data"].get("parmFrozen", {}),
    )
    if rvals.get("converged") and abs(rvals.get("Max shft/sig", 1e9)) < 0.1:
        break
project.save()
print(
    "COMMON_ADP_SUMMARY",
    json.dumps(
        {
            "Rwp": hist.get_wR(),
            "Uiso": project.phase(0).atoms()[0].uiso,
            "mass_fractions": hist.ComputeMassFracs(),
            "maxshift": rvals.get("Max shft/sig"),
            "frozen": project.data["Controls"]["data"].get("parmFrozen", {}),
        },
        default=str,
        sort_keys=True,
    ),
)
