from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


root = Path(__file__).resolve().parents[1]
data = np.genfromtxt(root / "fit.csv", delimiter=",", names=True)
x = data["two_theta_deg"]
yobs = data["observed_counts"]
ycalc = data["calculated_counts"]
ydiff = data["difference_counts"]
ybkg = data["background_counts"]

fig, axes = plt.subplots(4, 1, figsize=(13, 11), constrained_layout=True)
for ax, (low, high) in zip(axes, [(9.9, 100.1), (20, 35), (43, 60), (68, 88)]):
    sel = (x >= low) & (x <= high)
    ax.plot(x[sel], yobs[sel], color="black", lw=0.7, label="observed")
    ax.plot(x[sel], ycalc[sel], color="crimson", lw=0.7, label="calculated")
    ax.plot(x[sel], ydiff[sel], color="royalblue", lw=0.6, label="difference")
    ax.plot(x[sel], ybkg[sel], color="darkorange", lw=0.5, label="background")
    ax.set_xlim(low, high)
    ax.set_ylabel("counts")
axes[0].legend(ncol=4, fontsize=8)
axes[-1].set_xlabel(r"2$\theta$ (degrees)")
fig.savefig(root / ".tmp" / "final_fit_audit.png", dpi=180)
