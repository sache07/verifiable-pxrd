import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def refine_passes(project, label, maximum=6):
    hist = project.histogram(0)
    for index in range(maximum):
        project.refine()
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        print(
            "PASS",
            label,
            index + 1,
            "Rwp",
            hist.get_wR(),
            "converged",
            rvals.get("converged"),
            "maxshift",
            rvals.get("Max shft/sig"),
        )
        if rvals.get("converged") and abs(rvals.get("Max shft/sig", 1e9)) < 0.1:
            break


parser = argparse.ArgumentParser()
parser.add_argument("tag")
parser.add_argument("ids", nargs="+")
args = parser.parse_args()

role_names = ["product", "tungsten_oxide", "lead_oxide", "added_phase"]
gpx = ROOT / ".tmp" / f"trial_{args.tag}.gpx"
project = G2sc.G2Project(newgpx=str(gpx))
hist = project.add_powder_histogram(
    str(ROOT / ".tmp" / "pattern.xye"),
    str(ROOT / ".tmp" / "cu_ka_lab.instprm"),
    fmthint="xye",
)

for phase_index, cod_id in enumerate(args.ids):
    phase = project.add_phase(
        str(cod_path(cod_id)),
        phasename=f"{role_names[phase_index]}_{cod_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    # Use one common, fixed ADP convention so record-specific ADPs cannot win a trial.
    for atom in phase.atoms():
        if atom.adp_flag == "I":
            atom.ADP = 0.01
        else:
            atom.ADP = [0.01, 0.01, 0.01, 0.0, 0.0, 0.0]
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]

hist.SampleParameters["Scale"] = [1.0, False]
hist.SampleParameters["Shift"] = [0.0, False]
hist.SampleParameters["Transparency"] = [0.0, False]
hist.SampleParameters["SurfRoughA"] = [0.0, False]
hist.SampleParameters["SurfRoughB"] = [0.0, False]

inst = hist.InstrumentParameters
for name, value in {
    "Zero": 0.45,
    "U": 0.0,
    "V": 0.0,
    "W": 12.3,
    "X": 5.0,
    "Y": 0.0,
    "SH/L": 0.020,
    "Polariz.": 0.5,
}.items():
    inst[name][1] = value
    inst[name][2] = False

# Accepted isotropic size-only branches for broad product and residual Pb3O4.
if len(project.phases()) >= 1:
    project.phase(0).data["Histograms"][hist.name]["Size"][1][0] = 0.063
if len(project.phases()) >= 3:
    project.phase(2).data["Histograms"][hist.name]["Size"][1][0] = 0.038

hist.set_refinements({
    "Limits": [10.0, 100.0],
    "Background": {
        "type": "chebyschev-1",
        "refine": True,
        "no. coeffs": 12,
        "coeffs": [1900.0, -1300.0, 300.0, -150.0, 80.0, -40.0, 20.0, -10.0, 5.0, 0.0, 0.0, 0.0],
    },
})
project.set_Controls("cycles", 12)
project.save()

refine_passes(project, "scales_background", maximum=2)

hist.set_refinements({"Instrument Parameters": ["Zero"]})
project.set_Controls("parmMin", 0.0, ":0:Zero")
project.set_Controls("parmMax", 1.0, ":0:Zero")
for phase in project.phases():
    phase.set_refinements({"Cell": True})
refine_passes(project, "zero_cells", maximum=3)

hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
for variable, low, high in [
    (":0:W", 0.1, 100.0),
    (":0:X", 0.0, 50.0),
    (":0:SH/L", 0.002, 0.05),
]:
    project.set_Controls("parmMin", low, variable)
    project.set_Controls("parmMax", high, variable)
if len(project.phases()) >= 1:
    project.phase(0).set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    project.set_Controls("parmMin", 0.005, "0:0:Size;i")
    project.set_Controls("parmMax", 100.0, "0:0:Size;i")
if len(project.phases()) >= 3:
    project.phase(2).set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    project.set_Controls("parmMin", 0.005, "2:0:Size;i")
    project.set_Controls("parmMax", 100.0, "2:0:Size;i")
refine_passes(project, "common_profile_sizes", maximum=8)
project.save()

summary = {
    "tag": args.tag,
    "ids": args.ids,
    "residuals": hist.residuals,
    "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
    "phases": [],
    "frozen": [str(v) for values in project.data["Controls"]["data"].get("parmFrozen", {}).values() for v in values],
}
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    summary["phases"].append({
        "name": phase.name,
        "cell": phase.get_cell(),
        "scale": hap["Scale"][0],
        "size": hap["Size"][1][0],
    })
print("TRIAL_SUMMARY", json.dumps(summary, sort_keys=True))
