from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parents[1]
project = G2sc.G2Project(str(root / "final.gpx"))
hist = project.histogram(0)
x = hist.data["data"][1][0]
hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
project.save()
