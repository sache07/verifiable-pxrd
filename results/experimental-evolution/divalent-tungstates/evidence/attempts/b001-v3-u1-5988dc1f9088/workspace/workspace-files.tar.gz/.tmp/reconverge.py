import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


path = Path(sys.argv[1]).resolve()
project = G2sc.G2Project(str(path))
project.set_Controls("cycles", 12)
for index in range(6):
    project.refine()
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    print(
        "PASS",
        index + 1,
        "Rwp",
        project.histogram(0).get_wR(),
        "converged",
        rvals.get("converged"),
        "DelChi2",
        rvals.get("DelChi2"),
        "maxshift",
        rvals.get("Max shft/sig"),
    )
    if rvals.get("converged") and abs(rvals.get("Max shft/sig", 1e9)) < 0.1:
        break
project.save()
