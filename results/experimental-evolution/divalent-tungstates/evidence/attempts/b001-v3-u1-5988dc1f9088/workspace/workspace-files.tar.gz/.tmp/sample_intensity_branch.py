import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


path = Path(sys.argv[1]).resolve()
mode = sys.argv[2]
project = G2sc.G2Project(str(path))
project.set_Controls("cycles", 12)
hist = project.histogram(0)
sample = hist.SampleParameters

if mode == "rough_b":
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.01, True]
    project.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
    project.set_Controls("parmMax", 2.0, ":0:SurfRoughB")
elif mode == "rough_ab":
    sample["SurfRoughA"] = [0.5, True]
    sample["SurfRoughB"] = [0.01, True]
    for name in ("SurfRoughA", "SurfRoughB"):
        project.set_Controls("parmMin", 0.0, f":0:{name}")
        project.set_Controls("parmMax", 1.0 if name.endswith("A") else 2.0, f":0:{name}")
elif mode == "transparency":
    sample["Transparency"] = [0.001, True]
    project.set_Controls("parmMin", 0.0, ":0:Transparency")
    project.set_Controls("parmMax", 0.1, ":0:Transparency")
else:
    raise ValueError(mode)

project.save()
for index in range(8):
    project.refine()
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    print(
        "PASS",
        index + 1,
        mode,
        "sample",
        {k: sample[k] for k in ("SurfRoughA", "SurfRoughB", "Transparency")},
        "Rwp",
        hist.get_wR(),
        "converged",
        rvals.get("converged"),
        "DelChi2",
        rvals.get("DelChi2"),
        "maxshift",
        rvals.get("Max shft/sig"),
        "frozen",
        project.data["Controls"]["data"].get("parmFrozen", {}),
    )
    if rvals.get("converged") and abs(rvals.get("Max shft/sig", 1e9)) < 0.1:
        break
project.save()
