import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


path = Path(sys.argv[1]).resolve()
phase_index = int(sys.argv[2])
axis = [int(v) for v in sys.argv[3].split(",")]
project = G2sc.G2Project(str(path))
project.set_Controls("cycles", 12)
hist = project.histogram(0)
phase = project.phase(phase_index)
hap = phase.data["Histograms"][hist.name]
hap["Pref.Ori."][0] = "MD"
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = True
hap["Pref.Ori."][3] = axis
project.set_Controls("parmMin", 0.2, f"{phase_index}:0:MD")
project.set_Controls("parmMax", 5.0, f"{phase_index}:0:MD")
project.save()

for index in range(8):
    project.refine()
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    print(
        "PASS",
        index + 1,
        phase.name,
        "axis",
        axis,
        "MD",
        hap["Pref.Ori."][1],
        "Rwp",
        hist.get_wR(),
        "converged",
        rvals.get("converged"),
        "DelChi2",
        rvals.get("DelChi2"),
        "maxshift",
        rvals.get("Max shft/sig"),
        "frozen",
        project.data["Controls"]["data"].get("parmFrozen", {}),
    )
    if rvals.get("converged") and abs(rvals.get("Max shft/sig", 1e9)) < 0.1:
        break
project.save()
