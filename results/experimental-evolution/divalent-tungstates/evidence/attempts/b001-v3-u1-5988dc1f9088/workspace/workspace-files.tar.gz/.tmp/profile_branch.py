import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


path = Path(sys.argv[1]).resolve()
kind = sys.argv[2]
phase_index = int(sys.argv[3])
start = float(sys.argv[4]) if len(sys.argv) > 4 else None

project = G2sc.G2Project(str(path))
project.set_Controls("cycles", 12)
phase = project.phase(phase_index)
hist = project.histogram(0)
hap = phase.data["Histograms"][hist.name]

if kind == "size":
    if start is not None:
        hap["Size"][1][0] = start
    hap["Size"][2][0] = True
    variable = f"{phase_index}:0:Size;i"
    project.set_Controls("parmMin", 0.005, variable)
    project.set_Controls("parmMax", 100.0, variable)
elif kind == "strain":
    if start is not None:
        hap["Mustrain"][1][0] = start
    hap["Mustrain"][2][0] = True
    variable = f"{phase_index}:0:Mustrain;i"
    project.set_Controls("parmMin", 0.0, variable)
    project.set_Controls("parmMax", 20000.0, variable)
else:
    raise ValueError(kind)

project.save()
for index in range(8):
    project.refine()
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    print(
        "PASS",
        index + 1,
        phase.name,
        kind,
        "value",
        hap[kind.capitalize() if kind == "size" else "Mustrain"][1][0],
        "Rwp",
        hist.get_wR(),
        "converged",
        rvals.get("converged"),
        "DelChi2",
        rvals.get("DelChi2"),
        "maxshift",
        rvals.get("Max shft/sig"),
        "frozen",
        project.data["Controls"]["data"].get("parmFrozen", {}),
    )
    if rvals.get("converged") and abs(rvals.get("Max shft/sig", 1e9)) < 0.1:
        break
project.save()
