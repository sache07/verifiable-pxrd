from pathlib import Path

from pymatgen.core import Structure


root = Path(__file__).resolve().parents[1]
for name in [
    "phase_PbWO4_scheelite.cif",
    "phase_WO3_monoclinic.cif",
    "phase_Pb3O4_minium.cif",
]:
    structure = Structure.from_file(root / name)
    minima = {}
    for i, site_i in enumerate(structure):
        for j in range(i + 1, len(structure)):
            site_j = structure[j]
            pair = tuple(sorted((str(site_i.specie), str(site_j.specie))))
            distance = structure.get_distance(i, j)
            minima[pair] = min(minima.get(pair, 1e9), distance)
    print(name)
    print("  formula", structure.composition.reduced_formula)
    print("  symmetry", structure.get_space_group_info())
    print("  volume", structure.volume)
    for pair, distance in sorted(minima.items()):
        print(" ", "-".join(pair), f"{distance:.4f}")
