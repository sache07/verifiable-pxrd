import csv
import json
from pathlib import Path


root = Path(__file__).resolve().parents[1]
result = json.loads((root / "result.json").read_text())
fractions = [phase["weight_fraction"] for phase in result["phases"]]
assert abs(sum(fractions) - 1.0) < 1e-12
assert len(result["phases"]) == 3
for phase in result["phases"]:
    path = root / phase["cif_path"]
    assert path.is_file() and path.stat().st_size > 500
for required in ["final.gpx", "fit.csv", "result.json", "report.md"]:
    assert (root / required).is_file()

with (root / "fit.csv").open(newline="") as stream:
    rows = list(csv.DictReader(stream))
assert len(rows) == 8301
max_difference_error = max(
    abs(
        float(row["observed_counts"])
        - float(row["calculated_counts"])
        - float(row["difference_counts"])
    )
    for row in rows
)
assert max_difference_error < 1e-8
assert abs(float(rows[0]["two_theta_deg"]) - 9.90343322) < 1e-8
assert abs(float(rows[-1]["two_theta_deg"]) - 100.09455322) < 1e-8

print(
    "validated",
    {"fraction_sum": sum(fractions), "fit_rows": len(rows),
     "max_difference_error": max_difference_error},
)
