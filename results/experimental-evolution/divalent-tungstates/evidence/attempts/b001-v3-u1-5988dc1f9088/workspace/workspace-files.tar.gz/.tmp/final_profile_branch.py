import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


path = Path(sys.argv[1]).resolve()
kind = sys.argv[2]
project = G2sc.G2Project(str(path))
project.set_Controls("cycles", 12)
hist = project.histogram(0)
inst = hist.InstrumentParameters

# Challenge the accepted common Lorentzian term with a neutral WO3-only term.
inst["X"][1] = 0.0
inst["X"][2] = False
wo3 = project.phase(1)
hap = wo3.data["Histograms"][hist.name]
hap["Size"][1][0] = 10.0
hap["Size"][2][0] = False
hap["Mustrain"][1][0] = 0.0
hap["Mustrain"][2][0] = False

if kind == "size":
    hap["Size"][1][0] = 0.20
    hap["Size"][2][0] = True
    project.set_Controls("parmMin", 0.005, "1:0:Size;i")
    project.set_Controls("parmMax", 100.0, "1:0:Size;i")
elif kind == "strain":
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2][0] = True
    project.set_Controls("parmMin", 0.0, "1:0:Mustrain;i")
    project.set_Controls("parmMax", 20000.0, "1:0:Mustrain;i")
elif kind != "none":
    raise ValueError(kind)

project.data["Controls"]["data"]["parmFrozen"] = {}
project.save()
for index in range(8):
    project.refine()
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    print(
        "PASS", index + 1, kind, "Rwp", hist.get_wR(),
        "maxshift", rvals.get("Max shft/sig"),
        "converged", rvals.get("converged"),
    )
    if rvals.get("converged") and abs(rvals.get("Max shft/sig", 1e9)) < 0.1:
        break
project.save()

summary = {
    "kind": kind,
    "Rwp": hist.get_wR(),
    "W": inst["W"][1],
    "X": inst["X"][1],
    "SH/L": inst["SH/L"][1],
    "WO3_size_um": hap["Size"][1][0],
    "WO3_microstrain": hap["Mustrain"][1][0],
    "frozen": project.data["Controls"]["data"].get("parmFrozen", {}),
}
print("BRANCH_SUMMARY", json.dumps(summary, sort_keys=True, default=str))
