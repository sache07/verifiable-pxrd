from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parents[1]
project = G2sc.G2Project(str(root / "final.gpx"))
hist = project.histogram(0)
cov = project.data["Covariance"]["data"]

vary = [str(v) for v in cov["varyList"]]
matrix = np.asarray(cov["covMatrix"], dtype=float)
sd = np.sqrt(np.clip(np.diag(matrix), 0.0, None))
corr = matrix / np.outer(sd, sd)
pairs = []
for i in range(len(vary)):
    for j in range(i):
        if np.isfinite(corr[i, j]):
            pairs.append((abs(corr[i, j]), corr[i, j], vary[i], vary[j]))
print("TOP_CORRELATIONS")
for _, value, a, b in sorted(pairs, reverse=True)[:15]:
    print(f"{value:+.5f} {a} :: {b}")

data = hist.data["data"][1]
x, yobs, weight, ycalc, ybkg, ydiff = [np.asarray(v, dtype=float) for v in data[:6]]
smooth = gaussian_filter1d(ydiff, 2.0)
prom = max(40.0, np.percentile(np.abs(smooth), 85) * 0.35)
pos, pprop = find_peaks(smooth, distance=8, prominence=prom)
neg, nprop = find_peaks(-smooth, distance=8, prominence=prom)
events = [(abs(smooth[i]), smooth[i], i) for i in pos]
events += [(abs(smooth[i]), smooth[i], i) for i in neg]

refs = []
for phase_name, block in hist.data["Reflection Lists"].items():
    arr = np.asarray(block["RefList"], dtype=float)
    for row in arr:
        refs.append((row[5], phase_name, tuple(int(v) for v in row[:3]), row[9]))

print("RESIDUAL_EXTREMA")
for _, value, idx in sorted(events, reverse=True)[:30]:
    nearby = sorted(refs, key=lambda item: abs(item[0] - x[idx]))[:3]
    match = " | ".join(
        f"{name}:{hkl}@{pos:.3f} d={abs(pos-x[idx]):.3f} I={inten:.1f}"
        for pos, name, hkl, inten in nearby
    )
    print(
        f"{x[idx]:.4f} diff={value:+.1f} obs={yobs[idx]:.1f} "
        f"calc={ycalc[idx]:.1f} nearest {match}"
    )

print("ANGLE_BANDS")
for low, high in [(10, 20), (20, 30), (30, 40), (40, 50), (50, 60),
                  (60, 70), (70, 80), (80, 90), (90, 100)]:
    sel = (x >= low) & (x < high)
    chi = np.sum(weight[sel] * ydiff[sel] ** 2)
    n = np.count_nonzero(sel)
    rms = np.sqrt(np.mean(ydiff[sel] ** 2))
    print(f"{low:02d}-{high:03d} n={n} chi/n={chi/n:.4f} rms={rms:.2f}")
