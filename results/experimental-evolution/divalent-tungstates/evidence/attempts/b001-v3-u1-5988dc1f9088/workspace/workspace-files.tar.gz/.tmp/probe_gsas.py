from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


project = G2sc.G2Project(newgpx=str(ROOT / ".tmp" / "probe.gpx"))
hist = project.add_powder_histogram(
    str(ROOT / ".tmp" / "pattern.xye"),
    str(ROOT / ".tmp" / "cu_ka_lab.instprm"),
    fmthint="xye",
)
for name, cod_id in [
    ("PbWO4_scheelite", "9009811"),
    ("WO3_monoclinic", "1528915"),
    ("Pb3O4_minium", "9012124"),
]:
    project.add_phase(
        str(cod_path(cod_id)),
        phasename=name,
        histograms=[hist],
        fmthint="CIF",
    )

print("hist", hist.name)
print("instrument", hist.data["Instrument Parameters"])
print("sample", hist.data["Sample Parameters"])
print("background", hist.data["Background"])
print("limits", hist.data["Limits"])
for phase in project.phases():
    print("PHASE", phase.name)
    print("cell", phase.data["General"]["Cell"])
    print("SG", phase.data["General"]["SGData"]["SpGrp"])
    print("HAP", phase.data["Histograms"][hist.name])
    print("atoms")
    for atom in phase.atoms():
        print(atom.label, atom.element, atom.coordinates, atom.occupancy, atom.ADP, atom.refinement_flags)
project.save()
