import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


path = Path(sys.argv[1]).resolve()
project = G2sc.G2Project(str(path))
project.set_Controls("cycles", 12)

selected = {
    0: [0, 1],       # Pb, W in PbWO4
    1: [1, 7],       # two W sites in WO3
    2: [0, 1],       # Pb(IV), Pb(II) in Pb3O4
}
for phase_index, atom_indices in selected.items():
    phase = project.phase(phase_index)
    atoms = phase.atoms()
    for atom_index in atom_indices:
        atoms[atom_index].uiso = 0.005
        atoms[atom_index].refinement_flags = "U"
        variable = f"{phase_index}::AUiso:{atom_index}"
        project.set_Controls("parmMin", 0.0005, variable)
        project.set_Controls("parmMax", 0.05, variable)

# Keep equivalent heavy-atom sites on one common Uiso within WO3 and Pb3O4.
project.add_EquivConstr(("1::AUiso:1", "1::AUiso:7"))
project.add_EquivConstr(("2::AUiso:0", "2::AUiso:1"))
project.save()

hist = project.histogram(0)
for index in range(8):
    project.refine()
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    values = {}
    for phase_index, atom_indices in selected.items():
        atoms = project.phase(phase_index).atoms()
        values[project.phase(phase_index).name] = {
            atoms[i].label: atoms[i].uiso for i in atom_indices
        }
    print(
        "PASS",
        index + 1,
        "values",
        values,
        "Rwp",
        hist.get_wR(),
        "converged",
        rvals.get("converged"),
        "DelChi2",
        rvals.get("DelChi2"),
        "maxshift",
        rvals.get("Max shft/sig"),
        "frozen",
        project.data["Controls"]["data"].get("parmFrozen", {}),
    )
    if rvals.get("converged") and abs(rvals.get("Max shft/sig", 1e9)) < 0.1:
        break
project.save()
