import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


path = Path(sys.argv[1]).resolve()
params = sys.argv[2].split(",")
project = G2sc.G2Project(str(path))
project.set_Controls("cycles", 12)
hist = project.histogram(0)
inst = hist.InstrumentParameters

starts = {"U": 4.0, "W": 9.0, "X": 5.0, "SH/L": 0.002, "Polariz.": 0.5}
limits = {
    "U": (0.0, 100.0),
    "W": (0.1, 100.0),
    "X": (0.0, 50.0),
    "SH/L": (0.002, 0.05),
    "Polariz.": (0.0, 1.0),
}
for param in params:
    if len(sys.argv) > 3 and len(params) == 1:
        starts[param] = float(sys.argv[3])
    inst[param][1] = starts[param]
    inst[param][2] = True
    if param in limits:
        low, high = limits[param]
        project.set_Controls("parmMin", low, f":0:{param}")
        project.set_Controls("parmMax", high, f":0:{param}")

project.save()
for index in range(8):
    project.refine()
    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    print(
        "PASS",
        index + 1,
        "values",
        {p: inst[p][1] for p in params},
        "Rwp",
        hist.get_wR(),
        "converged",
        rvals.get("converged"),
        "DelChi2",
        rvals.get("DelChi2"),
        "maxshift",
        rvals.get("Max shft/sig"),
        "frozen",
        project.data["Controls"]["data"].get("parmFrozen", {}),
    )
    if rvals.get("converged") and abs(rvals.get("Max shft/sig", 1e9)) < 0.1:
        break
project.save()
