import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


path = Path(sys.argv[1]).resolve()
uiso = float(sys.argv[2])
project = G2sc.G2Project(str(path))
project.set_Controls("cycles", 12)
project.data["Controls"]["data"]["parmFrozen"] = {}
for phase in project.phases():
    for atom in phase.atoms():
        if atom.adp_flag == "I":
            atom.ADP = uiso
        else:
            atom.ADP = [uiso, uiso, uiso, 0.0, 0.0, 0.0]
        atom.refinement_flags = " "
project.save()

hist = project.histogram(0)
for index in range(6):
    project.refine()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    if rvals.get("converged") and abs(rvals.get("Max shft/sig", 1e9)) < 0.1:
        break
project.save()
print(
    "ADP_SENSITIVITY",
    json.dumps(
        {
            "Uiso": uiso,
            "Rwp": hist.get_wR(),
            "mass_fractions": hist.ComputeMassFracs(),
            "maxshift": rvals.get("Max shft/sig"),
        },
        default=str,
        sort_keys=True,
    ),
)
