#!/usr/bin/env python3
"""Export all requested deliverables from the exact final GSAS-II checkpoint."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIstrMain as G2str


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "final.gpx"

PHASE_META = {
    "NiWO4": {
        "phase": "nickel tungstate (wolframite)",
        "formula": "NiWO4",
        "space_group_number": 13,
        "cif_path": "NiWO4.cif",
    },
    "WO3": {
        "phase": "monoclinic tungsten trioxide",
        "formula": "WO3",
        "space_group_number": 14,
        "cif_path": "WO3.cif",
    },
    "NiO": {
        "phase": "nickel(II) oxide (rocksalt)",
        "formula": "NiO",
        "space_group_number": 225,
        "cif_path": "NiO.cif",
    },
}


def minimum_distance(phase: G2sc.G2Phase) -> float:
    controls, data = phase.InitDisAgl(useAll=False)
    controls["Factors"][1] = 0
    _labels, distances, _angles = G2str.RetDistAngle(controls, data, dmin=0.01)
    values = [float(row[-2]) for entries in distances.values() for row in entries]
    return min(values) if values else math.inf


def assert_physical_checkpoint(project: G2sc.G2Project) -> None:
    if project.get_Frozen():
        raise RuntimeError(f"final project has frozen variables: {project.get_Frozen()}")
    if len(project.histograms()) != 1:
        raise RuntimeError("final project must contain exactly one histogram")

    histogram = project.histogram(0)
    instrument = histogram.data["Instrument Parameters"][0]
    for key in ("U", "W", "X"):
        if float(instrument[key][1]) < 0:
            raise RuntimeError(f"negative profile coefficient {key}")

    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        if not hap.get("Use", True):
            raise RuntimeError(f"inactive submitted phase: {phase.name}")
        if any(hap["Size"][2]) or any(hap["Mustrain"][2]):
            raise RuntimeError(f"unsupported broadening remains for {phase.name}")
        if hap["Pref.Ori."][2] or abs(float(hap["Pref.Ori."][1]) - 1.0) > 1e-12:
            raise RuntimeError(f"preferred orientation remains for {phase.name}")
        if hap["Extinction"][1] or any(v[1] for v in hap["Babinet"].values()):
            raise RuntimeError(f"unsupported intensity correction remains for {phase.name}")


def source_observations() -> tuple[np.ndarray, np.ndarray]:
    x_values: list[float] = []
    y_values: list[float] = []
    with (ROOT / "inputs/pattern.csv").open(newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            x_values.append(float(row["two_theta_deg"]))
            y_values.append(float(row["intensity"]))
    return np.asarray(x_values), np.asarray(y_values)


def main() -> None:
    project = G2sc.G2Project(str(PROJECT))
    assert_physical_checkpoint(project)
    histogram = project.histogram(0)
    arrays = histogram.data["data"][1]
    x = np.asarray(arrays[0], dtype=float)
    observed = np.asarray(arrays[1], dtype=float)
    calculated = np.asarray(arrays[3], dtype=float)
    background = np.asarray(arrays[4], dtype=float)
    difference = np.asarray(arrays[5], dtype=float)

    source_x, source_y = source_observations()
    if not np.array_equal(x, source_x) or not np.array_equal(observed, source_y):
        raise RuntimeError("final project does not preserve the original observation grid")
    if not np.allclose(difference, observed - calculated, rtol=0.0, atol=1e-10):
        raise RuntimeError("GSAS-II difference profile is inconsistent")

    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_observed_minus_calculated",
                "calculated_background",
            ]
        )
        for row in zip(x, observed, calculated, difference, background):
            writer.writerow([repr(float(value)) for value in row])

    phases = project.phases()
    if {phase.name for phase in phases} != set(PHASE_META):
        raise RuntimeError("unexpected phase inventory in final.gpx")
    for phase in phases:
        phase.export_CIF(str(ROOT / PHASE_META[phase.name]["cif_path"]))

    raw_fractions = histogram.ComputeMassFracs()
    fraction_total = sum(float(value) for value, _su in raw_fractions.values())
    if fraction_total <= 0:
        raise RuntimeError("nonpositive crystalline fraction total")

    phase_rows = []
    for phase in phases:
        value, su = raw_fractions[phase.name]
        meta = PHASE_META[phase.name]
        cell, cell_su = phase.get_cell_and_esd()
        phase_rows.append(
            {
                "phase": meta["phase"],
                "formula": meta["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "space_group_number": meta["space_group_number"],
                "cif_path": meta["cif_path"],
                "weight_fraction": float(value) / fraction_total,
                "weight_fraction_standard_uncertainty": float(su) / fraction_total,
                "unit_cell": {key: float(number) for key, number in cell.items()},
                "unit_cell_standard_uncertainty": {
                    key: float(number) for key, number in cell_su.items()
                },
                "minimum_interatomic_distance_angstrom": minimum_distance(phase),
            }
        )

    rvals = project.data["Covariance"]["data"]["Rvals"]
    residuals = histogram.residuals
    instrument = histogram.data["Instrument Parameters"][0]
    result = {
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "refinement_histogram": histogram.name,
        "weight_fraction_normalization": "modeled crystalline phases only",
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "R_expected_percent": float(residuals["wRmin"]),
            "background_R_percent": float(residuals["Rb"]),
            "weighted_background_R_percent": float(residuals["wRb"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "number_of_observations": int(rvals["Nobs"]),
            "number_of_refined_variables": int(rvals["Nvars"]),
            "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
        },
        "measurement_model": {
            "radiation": "Cu K-alpha doublet",
            "wavelength_Kalpha1_angstrom": float(instrument["Lam1"][1]),
            "wavelength_Kalpha2_angstrom": float(instrument["Lam2"][1]),
            "Kalpha2_to_Kalpha1_ratio": float(instrument["I(L2)/I(L1)"][1]),
            "two_theta_min_deg": float(x[0]),
            "two_theta_max_deg": float(x[-1]),
            "points": int(len(x)),
            "weighting": "Poisson 1/I; pointwise uncertainties were not supplied",
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    fractions = {row["formula"]: 100.0 * row["weight_fraction"] for row in phase_rows}
    fraction_su = {
        row["formula"]: 100.0 * row["weight_fraction_standard_uncertainty"]
        for row in phase_rows
    }
    cells = {row["formula"]: row["unit_cell"] for row in phase_rows}
    minima = {
        row["formula"]: row["minimum_interatomic_distance_angstrom"]
        for row in phase_rows
    }
    report = f"""# Quantitative crystalline phase analysis

## Result

The pattern is described by three crystalline phases, normalized over the modeled crystalline material:

| Phase | Space group | Weight percent | Refined cell (Å, °) |
|---|---:|---:|---|
| NiWO4 (wolframite) | P 2/c (13) | {fractions['NiWO4']:.4f} ± {fraction_su['NiWO4']:.4f} | a={cells['NiWO4']['length_a']:.6f}, b={cells['NiWO4']['length_b']:.6f}, c={cells['NiWO4']['length_c']:.6f}, β={cells['NiWO4']['angle_beta']:.5f} |
| WO3 (monoclinic) | P 21/c (14) | {fractions['WO3']:.4f} ± {fraction_su['WO3']:.4f} | a={cells['WO3']['length_a']:.6f}, b={cells['WO3']['length_b']:.6f}, c={cells['WO3']['length_c']:.6f}, β={cells['WO3']['angle_beta']:.5f} |
| NiO (rocksalt) | F m -3 m (225) | {fractions['NiO']:.4f} ± {fraction_su['NiO']:.4f} | a={cells['NiO']['length_a']:.6f} |

The quoted ± values are GSAS-II least-squares standard uncertainties in weight-percentage points. Rwp={residuals['wR']:.4f}%, Rp={residuals['R']:.4f}%, Rexp={residuals['wRmin']:.4f}%, and GOF={rvals['GOF']:.4f} for 8,301 original observations and 32 refined variables.

## Evidence and model selection

The precursor chemistry (NiO + WO3, heated to 700 °C) supports nickel tungstate formation with residual reactants. NiWO4 is required by coherent families near 15.62, 19.27, and 30.85–31.03° 2θ; monoclinic WO3 by the 23.14/23.56/24.38° triplet; and NiO by the rocksalt 37.33, 43.43, and 63.07° peaks. After reconverging the same background/profile model, omitting NiWO4, WO3, or NiO raised Rwp from 3.588% (the pre-coordinate common-profile checkpoint) to 33.43%, 22.91%, or 7.11%, respectively.

The archived exact NiWO4 COD record 5910277 contained duplicated symmetry-equivalent sites and an unphysical NiWO6 transcription, so it was not used verbatim. A physically valid P2/c Ni-for-Mg wolframite analogue from COD 9013902, initialized with the NiWO4 cell, fit better than a corrected exact transcription and a ZnWO4 parent under the same nuisance model (Rwp 4.167%, 4.197%, and 5.035%). For WO3, the P21/c model from COD 2311041 outperformed the tested P21/n and triclinic records; NiO used COD 1010093. The required staged heavy-atom test accepted Ni and W coordinates in NiWO4 and both W coordinates in WO3, reducing Rwp from 3.5880% to 1.8642%. All accepted shifts were ≤0.060 Å; final minimum contacts are {minima['NiWO4']:.3f}, {minima['WO3']:.3f}, and {minima['NiO']:.3f} Å, with no GSAS-II short-contact flags.

## Refinement adequacy and uncertainty

The model uses the measured Cu Kα doublet on the untouched 9.90343322–100.09455322° grid, an eight-term smooth Chebyshev background, phase scales and cells, one zero correction, nonnegative W/X profile terms, and a refined polarization factor. Size/strain trials were rejected because gains were negligible, solutions hit the neutral size limit, or strain became negative. SH/L asymmetry gave only a 0.0051 percentage-point gain and was 97% correlated with zero. Symmetry-distinct texture trials gave at most a 0.0105 percentage-point gain with March ratios within 1% of unity; NiO texture trials were unstable. Size, strain, texture, roughness, extinction, and Babinet terms therefore remain neutral.

Phase identities and bulk crystalline proportions are well supported, but the formal fraction uncertainties are smaller than source/profile systematics; practical uncertainty is approximately 0.5–1 weight-percentage point. Fractions are normalized only over modeled crystalline phases, so amorphous content cannot be determined without an internal standard. Oxygen coordinates were retained from the screened parent structures and are not independently determined reliably by this laboratory pattern; the submitted CIFs should be treated as Rietveld models rather than complete single-crystal structure determinations.
"""
    (ROOT / "report.md").write_text(report)

    print(
        "EXPORTED "
        + json.dumps(
            {
                "Rwp_percent": float(residuals["wR"]),
                "fractions": {
                    row["formula"]: row["weight_fraction"] for row in phase_rows
                },
                "points": int(len(x)),
                "fraction_sum": sum(row["weight_fraction"] for row in phase_rows),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
