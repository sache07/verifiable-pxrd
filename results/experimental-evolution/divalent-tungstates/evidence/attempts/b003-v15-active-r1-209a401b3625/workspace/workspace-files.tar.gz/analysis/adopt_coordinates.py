#!/usr/bin/env python3
"""Adopt the accepted coordinate checkpoint and replay it to convergence."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "coordinated.gpx"
OUTPUT = ROOT / "final.gpx"


def main() -> None:
    source = G2sc.G2Project(str(SOURCE))
    source_rwp = float(source.histogram(0).residuals["wR"])
    project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    project.set_Controls("cycles", 16)
    project.save()

    replays = 0
    for _ in range(12):
        project = G2sc.G2Project(str(OUTPUT))
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(OUTPUT))
        replays += 1
        shift = project.data["Covariance"]["data"]["Rvals"].get("Max shft/sig")
        if shift is not None and abs(float(shift)) < 0.03:
            break

    histogram = project.histogram(0)
    rvals = project.data["Covariance"]["data"]["Rvals"]
    row = {
        "source_Rwp_percent": source_rwp,
        "final_Rwp_percent": float(histogram.residuals["wR"]),
        "GOF": float(rvals["GOF"]),
        "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
        "replays": replays,
        "points": int(len(histogram.data["data"][1][0])),
        "fractions": {
            name: {"value": float(value), "su": float(su)}
            for name, (value, su) in histogram.ComputeMassFracs().items()
        },
        "coordinate_flags": {
            phase.name: {
                atom.label: atom.refinement_flags.strip()
                for atom in phase.atoms()
                if atom.refinement_flags.strip()
            }
            for phase in project.phases()
        },
        "frozen": project.get_Frozen(),
    }
    print("ADOPTED_COORDINATES " + json.dumps(row, sort_keys=True))


if __name__ == "__main__":
    main()
