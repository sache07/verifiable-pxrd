#!/usr/bin/env python3
"""Challenge symmetry-distinct March-Dollase axes one phase at a time."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/global_polarization.gpx"
AXES = {
    "NiWO4": [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1)],
    "WO3": [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1)],
    "NiO": [(1, 0, 0), (1, 1, 0), (1, 1, 1)],
}


def replay(path: Path, maximum: int = 5) -> G2sc.G2Project:
    project = G2sc.G2Project(str(path))
    project.set_Controls("cycles", 16)
    for _ in range(maximum):
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(path))
        shift = project.data["Covariance"]["data"]["Rvals"].get("Max shft/sig")
        if shift is not None and abs(float(shift)) < 0.03:
            break
    return project


def main() -> None:
    baseline = G2sc.G2Project(str(SOURCE))
    baseline_rwp = float(baseline.histogram(0).residuals["wR"])
    rows = []
    for phase_name, axes in AXES.items():
        for axis in axes:
            axis_tag = "".join(str(value) for value in axis)
            output = ROOT / ".tmp" / f"texture_{phase_name}_{axis_tag}.gpx"
            project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
            project.save()
            project = G2sc.G2Project(str(output))
            histogram = project.histogram(0)
            for phase in project.phases():
                hap = phase.data["Histograms"][histogram.name]
                hap["Pref.Ori."][0] = "MD"
                hap["Pref.Ori."][1] = 1.0
                hap["Pref.Ori."][2] = False
            phase = project.phase(phase_name)
            hap = phase.data["Histograms"][histogram.name]
            hap["Pref.Ori."][3] = list(axis)
            phase.set_HAP_refinements({"Pref.Ori.": True})
            project.save()
            project = replay(output)
            histogram = project.histogram(0)
            hap = project.phase(phase_name).data["Histograms"][histogram.name]
            rvals = project.data["Covariance"]["data"]["Rvals"]
            row = {
                "phase": phase_name,
                "axis": list(axis),
                "project": str(output.relative_to(ROOT)),
                "Rwp_percent": float(histogram.residuals["wR"]),
                "Rwp_gain": baseline_rwp - float(histogram.residuals["wR"]),
                "GOF": float(rvals["GOF"]),
                "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
                "march_dollase_ratio": float(hap["Pref.Ori."][1]),
                "fractions": {
                    name: {"value": float(value), "su": float(su)}
                    for name, (value, su) in histogram.ComputeMassFracs().items()
                },
                "frozen": project.get_Frozen(),
            }
            print("TEXTURE " + json.dumps(row, sort_keys=True))
            rows.append(row)
    (ROOT / ".tmp/texture_summary.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
