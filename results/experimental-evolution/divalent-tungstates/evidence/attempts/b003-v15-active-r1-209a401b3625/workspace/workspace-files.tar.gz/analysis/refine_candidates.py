#!/usr/bin/env python3
"""Fit physically screened phase-source combinations with one neutral profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


NI_SOURCES = {
    "exact": ROOT / "models/NiWO4_exact_corrected.cif",
    "znproto": ROOT / "models/NiWO4_ZnWO4_prototype.cif",
    "mgproto": ROOT / "models/NiWO4_MgWO4_prototype.cif",
}

WO3_SOURCES = {
    "loopstra": cod("2311041"),
    "tanisaki": cod("1528915"),
    "triclinic": cod("2106293"),
}

NIO_SOURCE = cod("1010093")


def neutralize_hap(phase: G2sc.G2Phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1.0e6, 1.0e6, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def replay(path: Path, maximum: int = 5, threshold: float = 0.03) -> G2sc.G2Project:
    project = G2sc.G2Project(str(path))
    project.set_Controls("cycles", 16)
    for _ in range(maximum):
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(path))
        shift = (
            project.data.get("Covariance", {})
            .get("data", {})
            .get("Rvals", {})
            .get("Max shft/sig")
        )
        if shift is not None and abs(float(shift)) < threshold:
            break
    return project


def build_and_fit(tag: str, ni_source: Path, wo3_source: Path) -> dict:
    output = ROOT / ".tmp" / f"candidate_{tag}.gpx"
    project = G2sc.G2Project(newgpx=str(output))
    histogram = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "models/CuKa_reflection.instprm"),
        fmthint="comma",
    )
    histogram.data["Sample Parameters"]["Scale"][1] = False
    histogram.data["Sample Parameters"]["SurfRoughA"][:] = [0.0, False]
    histogram.data["Sample Parameters"]["SurfRoughB"][:] = [0.0, False]
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
                "coeffs": [3300.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            }
        }
    )
    instrument = histogram.data["Instrument Parameters"][0]
    for name in ["U", "V", "W", "X", "Y", "Z", "SH/L"]:
        instrument[name][2] = False
    instrument["U"][1] = 0.0
    instrument["V"][1] = 0.0
    instrument["W"][1] = 5.0
    instrument["X"][1] = 0.0
    instrument["Y"][1] = 0.0
    instrument["Z"][1] = 0.0
    instrument["SH/L"][1] = 0.002

    source_rows = [
        ("NiWO4", ni_source),
        ("WO3", wo3_source),
        ("NiO", NIO_SOURCE),
    ]
    for name, source in source_rows:
        phase = project.add_phase(
            str(source), phasename=name, histograms=[histogram], fmthint="CIF"
        )
        neutralize_hap(phase, histogram.name)
        phase.set_HAP_refinements({"Scale": True})

    project.set_Controls("cycles", 16)
    project.save()
    project = replay(output, maximum=4)

    histogram = project.histogram(0)
    histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.save()
    project = replay(output, maximum=6)

    histogram = project.histogram(0)
    instrument = histogram.data["Instrument Parameters"][0]
    instrument["U"][1] = 0.0
    instrument["W"][1] = 5.0
    instrument["X"][1] = 1.0
    histogram.set_refinements({"Instrument Parameters": ["W", "X"]})
    project.save()
    project = replay(output, maximum=6)

    histogram = project.histogram(0)
    instrument = histogram.data["Instrument Parameters"][0]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    fractions = histogram.ComputeMassFracs()
    row = {
        "tag": tag,
        "project": str(output.relative_to(ROOT)),
        "ni_source": str(ni_source),
        "wo3_source": str(wo3_source),
        "Rwp_percent": float(histogram.residuals["wR"]),
        "GOF": float(rvals["GOF"]),
        "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
        "profile": {
            key: {"value": float(instrument[key][1]), "refined": bool(instrument[key][2])}
            for key in ["U", "V", "W", "X", "Y", "Z", "SH/L"]
        },
        "zero_deg": float(instrument["Zero"][1]),
        "fractions": {
            name: {"value": float(value), "su": float(su)}
            for name, (value, su) in fractions.items()
        },
        "scales": {
            phase.name: float(phase.data["Histograms"][histogram.name]["Scale"][0])
            for phase in project.phases()
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "frozen": project.get_Frozen(),
    }
    print("CANDIDATE " + json.dumps(row, sort_keys=True))
    return row


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("tags", nargs="*")
    args = parser.parse_args()
    trials = {
        "exact_loopstra": (NI_SOURCES["exact"], WO3_SOURCES["loopstra"]),
        "znproto_loopstra": (NI_SOURCES["znproto"], WO3_SOURCES["loopstra"]),
        "mgproto_loopstra": (NI_SOURCES["mgproto"], WO3_SOURCES["loopstra"]),
        "exact_tanisaki": (NI_SOURCES["exact"], WO3_SOURCES["tanisaki"]),
        "znproto_tanisaki": (NI_SOURCES["znproto"], WO3_SOURCES["tanisaki"]),
        "mgproto_tanisaki": (NI_SOURCES["mgproto"], WO3_SOURCES["tanisaki"]),
        "znproto_triclinic": (NI_SOURCES["znproto"], WO3_SOURCES["triclinic"]),
        "mgproto_triclinic": (NI_SOURCES["mgproto"], WO3_SOURCES["triclinic"]),
    }
    selected = args.tags or list(trials)
    rows = []
    for tag in selected:
        rows.append(build_and_fit(tag, *trials[tag]))
    summary = ROOT / ".tmp" / "candidate_summary.json"
    old = []
    if summary.is_file():
        old = json.loads(summary.read_text())
    by_tag = {row["tag"]: row for row in old}
    by_tag.update({row["tag"]: row for row in rows})
    summary.write_text(json.dumps(list(by_tag.values()), indent=2) + "\n")


if __name__ == "__main__":
    main()
