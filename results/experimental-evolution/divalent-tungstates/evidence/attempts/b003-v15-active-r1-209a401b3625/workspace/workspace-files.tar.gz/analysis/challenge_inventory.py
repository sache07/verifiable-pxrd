#!/usr/bin/env python3
"""Re-fit the clean common profile after withholding each proposed phase."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/global_polarization.gpx"


def replay(path: Path, maximum: int = 8) -> G2sc.G2Project:
    project = G2sc.G2Project(str(path))
    project.set_Controls("cycles", 16)
    for _ in range(maximum):
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(path))
        shift = (
            project.data.get("Covariance", {})
            .get("data", {})
            .get("Rvals", {})
            .get("Max shft/sig")
        )
        if shift is not None and abs(float(shift)) < 0.03:
            break
    return project


def summarize(project: G2sc.G2Project, omitted: str | None, path: Path) -> dict:
    histogram = project.histogram(0)
    rvals = project.data["Covariance"]["data"]["Rvals"]
    return {
        "omitted_phase": omitted,
        "project": str(path.relative_to(ROOT)),
        "Rwp_percent": float(histogram.residuals["wR"]),
        "Rp_percent": float(histogram.residuals["R"]),
        "GOF": float(rvals["GOF"]),
        "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
        "active_phases": [
            phase.name
            for phase in project.phases()
            if phase.data["Histograms"][histogram.name].get("Use", True)
        ],
        "frozen": project.get_Frozen(),
    }


def main() -> None:
    baseline = G2sc.G2Project(str(SOURCE))
    rows = [summarize(baseline, None, SOURCE)]

    for omitted in ["NiWO4", "WO3", "NiO"]:
        output = ROOT / ".tmp" / f"inventory_without_{omitted}.gpx"
        project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
        phase = project.phase(omitted)
        phase.set_HAP_refinements({"Use": False})
        phase.clear_HAP_refinements({"Scale": True})
        phase.clear_refinements({"Cell": True})
        project.save()
        project = replay(output)
        row = summarize(project, omitted, output)
        rows.append(row)
        print("INVENTORY " + json.dumps(row, sort_keys=True))

    (ROOT / ".tmp/inventory_summary.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
