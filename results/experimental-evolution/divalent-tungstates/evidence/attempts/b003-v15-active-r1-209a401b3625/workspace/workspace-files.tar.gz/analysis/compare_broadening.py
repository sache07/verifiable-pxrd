#!/usr/bin/env python3
"""Compare neutral, size, strain and combined phase broadening from one checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/candidate_mgproto_loopstra.gpx"


def replay(path: Path, maximum: int = 6) -> G2sc.G2Project:
    project = G2sc.G2Project(str(path))
    project.set_Controls("cycles", 16)
    for _ in range(maximum):
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(path))
        shift = project.data["Covariance"]["data"]["Rvals"].get("Max shft/sig")
        if shift is not None and abs(float(shift)) < 0.03:
            break
    return project


def fit_trial(phase_name: str, model: str) -> dict:
    tag = f"broad_{phase_name}_{model}"
    output = ROOT / ".tmp" / f"{tag}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
    project.save()
    project = G2sc.G2Project(str(output))
    histogram = project.histogram(0)
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][histogram.name]

    phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][1][2] = 1.0
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][2] = 1.0

    if model in {"size", "combined"}:
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": 1.0,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )
    if model in {"strain", "combined"}:
        hap["Mustrain"][1][0] = 100.0
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )

    project.save()
    project = replay(output)
    histogram = project.histogram(0)
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][histogram.name]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    row = {
        "phase": phase_name,
        "model": model,
        "project": str(output.relative_to(ROOT)),
        "Rwp_percent": float(histogram.residuals["wR"]),
        "GOF": float(rvals["GOF"]),
        "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
        "size_micrometre": float(hap["Size"][1][0]),
        "size_flags": [bool(value) for value in hap["Size"][2]],
        "microstrain": float(hap["Mustrain"][1][0]),
        "microstrain_flags": [bool(value) for value in hap["Mustrain"][2]],
        "fractions": {
            name: {"value": float(value), "su": float(su)}
            for name, (value, su) in histogram.ComputeMassFracs().items()
        },
        "frozen": project.get_Frozen(),
    }
    print("BROADENING " + json.dumps(row, sort_keys=True))
    return row


def main() -> None:
    rows = []
    for phase_name in ["NiWO4", "WO3", "NiO"]:
        for model in ["neutral", "size", "strain", "combined"]:
            if model == "neutral":
                project = G2sc.G2Project(str(SOURCE))
                histogram = project.histogram(0)
                rvals = project.data["Covariance"]["data"]["Rvals"]
                row = {
                    "phase": phase_name,
                    "model": model,
                    "project": str(SOURCE.relative_to(ROOT)),
                    "Rwp_percent": float(histogram.residuals["wR"]),
                    "GOF": float(rvals["GOF"]),
                    "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
                    "size_micrometre": 10.0,
                    "microstrain": 0.0,
                    "fractions": {
                        name: {"value": float(value), "su": float(su)}
                        for name, (value, su) in histogram.ComputeMassFracs().items()
                    },
                    "frozen": project.get_Frozen(),
                }
                print("BROADENING " + json.dumps(row, sort_keys=True))
            else:
                row = fit_trial(phase_name, model)
            rows.append(row)
    (ROOT / ".tmp/broadening_summary.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
