#!/usr/bin/env python3
"""Copy the selected physical model to final.gpx and replay after reopening."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/global_polarization.gpx"
OUTPUT = ROOT / "final.gpx"


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    project.set_Controls("cycles", 16)
    project.save()
    for _ in range(6):
        project = G2sc.G2Project(str(OUTPUT))
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(str(OUTPUT))
        shift = project.data["Covariance"]["data"]["Rvals"].get("Max shft/sig")
        if shift is not None and abs(float(shift)) < 0.03:
            break

    histogram = project.histogram(0)
    rvals = project.data["Covariance"]["data"]["Rvals"]
    row = {
        "project": str(OUTPUT.relative_to(ROOT)),
        "histogram": histogram.name,
        "points": int(len(histogram.data["data"][1][0])),
        "Rwp_percent": float(histogram.residuals["wR"]),
        "GOF": float(rvals["GOF"]),
        "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
        "fractions": {
            name: {"value": float(value), "su": float(su)}
            for name, (value, su) in histogram.ComputeMassFracs().items()
        },
        "frozen": project.get_Frozen(),
    }
    print("FINAL_CHECKPOINT " + json.dumps(row, sort_keys=True))


if __name__ == "__main__":
    main()
