#!/usr/bin/env python3
"""Verify that every submitted numeric output is sourced from final.gpx."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    project = G2sc.G2Project(str(ROOT / "final.gpx"))
    histogram = project.histogram(0)
    arrays = histogram.data["data"][1]

    with (ROOT / "fit.csv").open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    if len(rows) != len(arrays[0]):
        raise RuntimeError("fit.csv row count mismatch")
    columns = [
        np.asarray([float(row[name]) for row in rows])
        for name in [
            "two_theta_deg",
            "observed_intensity",
            "calculated_intensity",
            "difference_observed_minus_calculated",
            "calculated_background",
        ]
    ]
    for exported, index in zip(columns, [0, 1, 3, 5, 4]):
        if not np.array_equal(exported, np.asarray(arrays[index], dtype=float)):
            raise RuntimeError(f"fit.csv column does not exactly match GSAS array {index}")

    result = json.loads((ROOT / "result.json").read_text())
    rvals = project.data["Covariance"]["data"]["Rvals"]
    expected_stats = {
        "Rwp_percent": histogram.residuals["wR"],
        "Rp_percent": histogram.residuals["R"],
        "R_expected_percent": histogram.residuals["wRmin"],
        "goodness_of_fit": rvals["GOF"],
        "chi_squared": rvals["chisq"],
        "number_of_observations": rvals["Nobs"],
        "number_of_refined_variables": rvals["Nvars"],
        "maximum_shift_over_esd": rvals["Max shft/sig"],
    }
    for key, value in expected_stats.items():
        if result["fit_statistics"][key] != value:
            raise RuntimeError(f"result.json statistic mismatch: {key}")

    expected_fractions = histogram.ComputeMassFracs()
    found_fractions = {row["formula"]: row["weight_fraction"] for row in result["phases"]}
    for name, (value, _su) in expected_fractions.items():
        if found_fractions[name] != value:
            raise RuntimeError(f"result.json fraction mismatch: {name}")
    if sum(found_fractions.values()) != 1.0:
        raise RuntimeError("weight fractions are not exactly normalized")
    if project.get_Frozen():
        raise RuntimeError("final.gpx contains frozen variables")

    print(
        "VALIDATED "
        + json.dumps(
            {
                "histogram": histogram.name,
                "points": len(rows),
                "Rwp_percent": histogram.residuals["wR"],
                "fraction_sum": sum(found_fractions.values()),
                "frozen": project.get_Frozen(),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
