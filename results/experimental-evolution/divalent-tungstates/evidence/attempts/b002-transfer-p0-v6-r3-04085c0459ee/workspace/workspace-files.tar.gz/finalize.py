import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE_PROJECT = ROOT / "test_four_minsize.gpx"
FINAL_PROJECT = ROOT / "final.gpx"

PHASE_INFO = {
    "BaWO4": {
        "formula": "BaWO4",
        "cif": "BaWO4.cif",
        "reference": "COD 1527204; conventional scheelite O(16f) model used",
    },
    "Ba3W2O9": {
        "formula": "Ba3W2O9",
        "cif": "Ba3W2O9.cif",
        "reference": "COD 1533878",
    },
    "WO3": {
        "formula": "WO3",
        "cif": "WO3.cif",
        "reference": "COD 1528915",
    },
    "BaCO3": {
        "formula": "BaCO3",
        "cif": "BaCO3.cif",
        "reference": "COD 9010928",
    },
}


def clean_float(value):
    return float(value)


def main():
    project = G2sc.G2Project(str(SOURCE_PROJECT), newgpx=str(FINAL_PROJECT))
    histogram = project.histogram(0)

    # Include every measured point in both the final refinement and fit.csv.
    x = np.asarray(histogram.getdata("X"), dtype=float)
    histogram.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    project.set_Controls("cycles", 20)

    # The source project is converged. One pass updates the newly extended
    # limits; a second pass verifies stationarity and updates the covariance.
    project.refine()
    project.refine()
    project.save(str(FINAL_PROJECT))

    fractions = histogram.ComputeMassFracs()
    residuals = histogram.residuals
    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]

    profile = np.column_stack(
        [
            np.asarray(histogram.getdata("X"), dtype=float),
            np.asarray(histogram.getdata("Yobs"), dtype=float),
            np.asarray(histogram.getdata("Ycalc"), dtype=float),
            np.asarray(histogram.getdata("Residual"), dtype=float),
            np.asarray(histogram.getdata("Background"), dtype=float),
        ]
    )
    np.savetxt(
        ROOT / "fit.csv",
        profile,
        delimiter=",",
        header=(
            "two_theta_deg,observed_intensity,calculated_intensity,"
            "difference_observed_minus_calculated,calculated_background"
        ),
        comments="",
        fmt=["%.8f", "%.6f", "%.6f", "%.6f", "%.6f"],
    )

    phase_results = []
    report_rows = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        cif_path = ROOT / info["cif"]
        phase.export_CIF(str(cif_path))

        fraction, fraction_esd = fractions[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        sg = phase.data["General"]["SGData"]["SpGrp"].strip()
        p_id = phase.id
        h_id = histogram.id
        phase_result = {
            "name": phase.name,
            "formula": info["formula"],
            "space_group": sg,
            "cif_path": info["cif"],
            "weight_fraction": clean_float(fraction),
            "weight_fraction_esd": clean_float(fraction_esd),
            "weight_percent": clean_float(100.0 * fraction),
            "weight_percent_esd": clean_float(100.0 * fraction_esd),
            "cell_angstrom_degrees": {
                key: clean_float(value) for key, value in cell.items()
            },
            "cell_esd": {
                key: clean_float(value) for key, value in cell_esd.items()
            },
            "bragg_Rf_percent": clean_float(residuals[f"{p_id}:{h_id}:Rf"]),
            "bragg_Rf2_percent": clean_float(residuals[f"{p_id}:{h_id}:Rf^2"]),
            "starting_structure": info["reference"],
        }
        phase_results.append(phase_result)
        report_rows.append(
            f"| {phase.name} | {sg} | {100*fraction:.2f} | "
            f"{cell['length_a']:.5f}, {cell['length_b']:.5f}, "
            f"{cell['length_c']:.5f} |"
        )

    n_obs = int(rvals["Nobs"])
    n_vars = int(rvals["Nvars"])
    chi_square = clean_float(rvals["chisq"])
    fit_statistics = {
        "Rwp_percent": clean_float(residuals["wR"]),
        "Rp_percent": clean_float(residuals["R"]),
        "Rexp_percent": clean_float(residuals["wRmin"]),
        "goodness_of_fit": clean_float(rvals["GOF"]),
        "chi_square": chi_square,
        "reduced_chi_square": chi_square / (n_obs - n_vars),
        "n_observations": n_obs,
        "n_refined_variables": n_vars,
        "two_theta_range_deg": [clean_float(profile[0, 0]), clean_float(profile[-1, 0])],
    }
    result = {
        "method": "Four-phase GSAS-II Rietveld refinement",
        "normalization": "Weight fractions normalized over the modeled crystalline phases",
        "weighting": (
            "Poisson counting approximation (w=1/I); pointwise uncertainties "
            "were not supplied"
        ),
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
        "phases": phase_results,
        "fit_statistics": fit_statistics,
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    report = f"""# Powder diffraction phase analysis

## Result

Four crystalline phases are required. The fractions below are normalized to the modeled crystalline material; they do not measure any amorphous content.

| Phase | Space group | wt% | Refined a, b, c (Å) |
|---|---:|---:|---:|
{chr(10).join(report_rows)}

The final whole-pattern fit has Rwp = {fit_statistics['Rwp_percent']:.3f}%, Rp = {fit_statistics['Rp_percent']:.3f}%, Rexp = {fit_statistics['Rexp_percent']:.3f}%, and goodness-of-fit = {fit_statistics['goodness_of_fit']:.3f} over {fit_statistics['two_theta_range_deg'][0]:.3f}–{fit_statistics['two_theta_range_deg'][1]:.3f}° 2θ.

## Evidence and model

The chemistry is consistent with incomplete reaction of WO3 and BaCO3 at 750 °C. Scheelite BaWO4 accounts for the dominant reflections (including 17.49, 26.70, 28.39, 32.05, 43.19, and 53.68°). Ba3W2O9 is required by its independent reflections near 17.79, 26.27, 30.82, 37.67, 40.80, 51.84, and 63.82°. Monoclinic WO3 accounts for the resolved 23.40/23.87/24.66° and 33.56/33.86/34.45° groups. After those three phases were fitted, a coherent residual family at 24.17, 24.58, 34.84, 42.26, and 45.18° identified orthorhombic BaCO3; adding it removed the largest remaining structured residual.

The refinement used the reported Cu Kα1/Kα2 wavelengths and fixed 0.5 intensity ratio, Poisson count weights, a 12-term Chebyshev background, refined zero offset and common profile coefficients, phase scales and cells, and phase-specific broadening for the minor phases. The old split-oxygen BaWO4 entry was replaced by the conventional scheelite O(16f) model; its oxygen position was refined. Ba3W2O9 W/O coordinates were refined and retain reasonable octahedral W–O distances. WO3 and BaCO3 internal coordinates were held to their reference structures because this multiphase powder pattern does not determine them reliably. Mild [110] preferred orientation was modeled for WO3.

Starting structures were COD 1527204 (BaWO4), 1533878 (Ba3W2O9), 1528915 (WO3), and 9010928 (BaCO3). The submitted CIFs were exported from `final.gpx`, not copied from those references.

## Uncertainty

Formal covariance errors on the fractions are about 0.1–0.2 wt%, but they are conditional on the profile and structural models. Equally parameterized size/strain alternatives changed individual fractions by at most about 0.4 wt%; a practical uncertainty of roughly ±0.5 wt% is therefore more realistic. BaCO3 and WO3 overlap strongly around 24–25°, so their errors are partly anticorrelated. Without an internal standard, an amorphous fraction cannot be determined, and all reported fractions are crystalline-only. No additional crystalline phase is supported by a distinct residual peak family; trace material below roughly the percent level cannot be excluded.
"""
    (ROOT / "report.md").write_text(report)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
