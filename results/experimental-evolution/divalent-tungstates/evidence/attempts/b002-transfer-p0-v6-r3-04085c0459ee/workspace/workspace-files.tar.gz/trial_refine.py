from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def status(project, label):
    hist = project.histogram(0)
    print(f"\n===== {label} =====")
    print("residuals", hist.residuals)
    print("instrument")
    for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)"):
        print(key, hist.InstrumentParameters.get(key))
    print("cells/scales")
    for phase in project.phases():
        print(
            phase.name,
            phase.get_cell(),
            phase.data["Histograms"][hist.name]["Scale"],
            "mass", phase.data["General"]["Mass"],
        )
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass fraction error", repr(exc))


def refine(project, label):
    project.refine()
    status(project, label)


def main():
    project = G2sc.G2Project(newgpx=str(ROOT / "trial.gpx"))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    # With one histogram, refining this overall scale together with all phase
    # scales is exactly redundant. Keep it fixed and refine only phase scales.
    hist.SampleParameters["Scale"] = [1.0, False]
    phase_specs = [
        ("BaWO4", "1527204", 1.0),
        ("Ba3W2O9", "1533878", 0.05),
        ("WO3", "1528915", 0.10),
    ]
    for name, cod_id, scale in phase_specs:
        phase = project.add_phase(
            str(cod_cif(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase.data["Histograms"][hist.name]["Scale"][0] = scale

    project.set_Controls("cycles", 8)
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 12,
                "coeffs": [1000.0] + [0.0] * 11,
            },
        }
    )
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    refine(project, "background + scales")

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, "add cells")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "add zero")

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
    refine(project, "add profile")

    project.save()


if __name__ == "__main__":
    main()
