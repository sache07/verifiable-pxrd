#!/usr/bin/env python3
"""Focused convergence and output checks for the final GSAS-II model.

This script complements ``refine_workflow.py``.  Every model comparison opens
an explicit common checkpoint and writes a separate GPX file, so failed or
bounded trials cannot leak values into the accepted branch.
"""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TRIALS = ROOT / "trials"
CHECKPOINTS = ROOT / "checkpoints"


def copy_project(source: Path, destination: Path):
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    return G2sc.G2Project(str(destination))


def replay(project, cycles: int = 2) -> None:
    project.set_Controls("cycles", 30)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    for _ in range(cycles):
        project.refine(makeBack=False)
    project.save()


def phase_by_name(project, name: str):
    for phase in project.phases():
        if phase.name == name:
            return phase
    raise KeyError(name)


def mass_fractions(project) -> dict[str, list[float]]:
    values = project.histogram(0).ComputeMassFracs()
    return {
        key: [float(value[0]), float(value[1])] for key, value in values.items()
    }


def concise_summary(project) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    output = {
        "project": str(Path(project.filename).relative_to(ROOT)),
        "wR": float(hist.get_wR()),
        "GOF": float(cov.get("Rvals", {}).get("GOF", math.nan)),
        "Nvars": int(cov.get("Rvals", {}).get("Nvars", 0)),
        "fractions": mass_fractions(project),
        "MD": {},
    }
    for phase in project.phases():
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        output["MD"][phase.name] = {
            "ratio": float(po[1]),
            "refine": bool(po[2]),
            "axis": [int(i) for i in po[3]],
        }
    return output


def set_md(project, phase_name: str, axis: tuple[int, int, int], refine: bool) -> None:
    hist = project.histogram(0)
    phase = phase_by_name(project, phase_name)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = bool(refine)
    po[3] = list(axis)


def set_instrument(project, key: str, value: float, refine: bool) -> None:
    item = project.histogram(0).data["Instrument Parameters"][0][key]
    item[0] = float(value)
    item[1] = float(value)
    item[2] = bool(refine)


def set_background_order(project, order: int) -> None:
    background = project.histogram(0).data["Background"][0]
    values = [float(value) for value in background[3:]]
    if len(values) < order:
        values.extend([0.0] * (order - len(values)))
    background[:] = [background[0], True, int(order), *values[:order]]


def geometry_summary(project) -> dict:
    output = concise_summary(project)
    hist = project.histogram(0)
    sample = hist.data["Sample Parameters"]
    inst = hist.data["Instrument Parameters"][0]
    output.update(
        {
            "background": list(hist.data["Background"][0]),
            "roughness_A": list(sample["SurfRoughA"]),
            "roughness_B": list(sample["SurfRoughB"]),
            "polarization": list(inst["Polariz."]),
            "U": list(inst["U"]),
            "W": list(inst["W"]),
            "X": list(inst["X"]),
        }
    )
    return output


def broadening_summary(project) -> dict:
    output = concise_summary(project)
    hist_name = project.histogram(0).name
    output["broadening"] = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist_name]
        output["broadening"][phase.name] = {
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    return output


def set_isotropic_broadening(
    project,
    phase_name: str,
    size_value: float,
    refine_size: bool,
    strain_value: float,
    refine_strain: bool,
) -> None:
    phase = phase_by_name(project, phase_name)
    hap = phase.data["Histograms"][project.histogram(0).name]
    size = hap["Size"]
    size[0] = "isotropic"
    size[1][:] = [float(size_value), 100.0, 1.0]
    size[2][:] = [bool(refine_size), False, False]
    size[5][:] = [False] * len(size[5])
    strain = hap["Mustrain"]
    strain[0] = "isotropic"
    strain[1][:] = [float(strain_value), 0.0, 1.0]
    strain[2][:] = [bool(refine_strain), False, False]
    strain[4][:] = [0.0] * len(strain[4])
    strain[5][:] = [False] * len(strain[5])


def set_uniaxial_term(
    project,
    phase_name: str,
    term: str,
    axis: tuple[int, int, int],
) -> None:
    phase = phase_by_name(project, phase_name)
    hap = phase.data["Histograms"][project.histogram(0).name]
    item = hap[term]
    base = max(float(item[1][0]), 1e-6)
    item[0] = "uniaxial"
    item[1][:] = [base, base, 1.0]
    item[2][:] = [True, True, False]
    item[3] = list(axis)
    item[5][:] = [False] * len(item[5])


def run_texture_loop() -> None:
    source = CHECKPOINTS / "12_revised_broadening.gpx"
    results: dict[str, object] = {"removals": [], "single_axis": []}

    baseline_path = TRIALS / "texture_reloop_baseline.gpx"
    baseline = copy_project(source, baseline_path)
    replay(baseline)
    results["baseline"] = concise_summary(baseline)

    # Removal comparisons all reopen exactly the same accepted-width checkpoint.
    for name in ["BaWO4", "Ba3W2O9", "WO3"]:
        path = TRIALS / f"texture_reloop_remove_{name.lower()}.gpx"
        project = copy_project(source, path)
        current_axis = tuple(
            phase_by_name(project, name).data["Histograms"][
                project.histogram(0).name
            ]["Pref.Ori."][3]
        )
        set_md(project, name, current_axis, False)
        replay(project)
        item = concise_summary(project)
        item["removed"] = name
        results["removals"].append(item)

    neutral_path = TRIALS / "texture_reloop_all_neutral.gpx"
    neutral = copy_project(source, neutral_path)
    for name in ["BaWO4", "Ba3W2O9", "WO3"]:
        set_md(neutral, name, (0, 0, 1), False)
    replay(neutral)
    results["all_neutral"] = concise_summary(neutral)

    axes = {
        "BaWO4": [(0, 0, 1), (1, 0, 0), (1, 1, 0), (1, 0, 1), (1, 1, 2)],
        "Ba3W2O9": [(0, 0, 1), (1, 0, 0), (1, 1, 0), (1, 0, 1)],
        "WO3": [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 1, 1)],
    }
    # Single-axis trials start from the fully reconverged neutral project.
    for name, phase_axes in axes.items():
        for axis in phase_axes:
            tag = "".join(str(abs(i)) for i in axis)
            path = TRIALS / f"texture_reloop_{name.lower()}_{tag}.gpx"
            project = copy_project(neutral_path, path)
            set_md(project, name, axis, True)
            replay(project)
            item = concise_summary(project)
            item["phase"] = name
            item["axis_tested"] = list(axis)
            results["single_axis"].append(item)

    (TRIALS / "texture_reloop.json").write_text(
        json.dumps(results, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(results, indent=2))


def accept_texture() -> None:
    source = CHECKPOINTS / "12_revised_broadening.gpx"
    trial_path = TRIALS / "accepted_pruned_texture.gpx"
    project = copy_project(source, trial_path)
    set_md(project, "BaWO4", (1, 1, 2), False)
    set_md(project, "Ba3W2O9", (1, 1, 0), False)
    # [001] is the only replay-stable, phase-specific texture correction.
    wo3 = phase_by_name(project, "WO3")
    po = wo3.data["Histograms"][project.histogram(0).name]["Pref.Ori."]
    po[2] = True
    po[3] = [0, 0, 1]
    replay(project, cycles=3)
    destination = CHECKPOINTS / "13_pruned_texture.gpx"
    shutil.copy2(trial_path, destination)
    print(json.dumps(concise_summary(project), indent=2))


def run_geometry_loop() -> None:
    source = CHECKPOINTS / "13_pruned_texture.gpx"
    results: dict[str, object] = {
        "background_orders": [],
        "roughness": [],
        "profile": [],
    }

    for order in [5, 6, 7, 8, 9, 10]:
        path = TRIALS / f"geometry_reloop_background_{order}.gpx"
        project = copy_project(source, path)
        set_background_order(project, order)
        replay(project)
        item = geometry_summary(project)
        item["order_tested"] = order
        results["background_orders"].append(item)

    roughness_trials = {
        "none": ([0.0, False], [0.0, False]),
        "A_only": ([0.01, True], [0.0, False]),
        "B_only": ([0.0, False], None),
        "A_and_B": ([0.01, True], None),
    }
    for label, (a_setting, b_setting) in roughness_trials.items():
        path = TRIALS / f"geometry_reloop_roughness_{label}.gpx"
        project = copy_project(source, path)
        sample = project.histogram(0).data["Sample Parameters"]
        sample["SurfRoughA"] = list(a_setting)
        if b_setting is not None:
            sample["SurfRoughB"] = list(b_setting)
        replay(project)
        item = geometry_summary(project)
        item["roughness_tested"] = label
        results["roughness"].append(item)

    path = TRIALS / "geometry_reloop_polarization.gpx"
    project = copy_project(source, path)
    set_instrument(project, "Polariz.", 0.7, True)
    replay(project)
    results["polarization"] = geometry_summary(project)

    # Complementary common-profile challenges reopen all saved values.
    profile_trials = {
        "W_only": {"U": (0.0, False), "X": (0.0, False)},
        "release_U": {"U": (1.0, True), "X": (None, None)},
        "U_W_no_X": {"U": (1.0, True), "X": (0.0, False)},
    }
    for label, settings in profile_trials.items():
        path = TRIALS / f"geometry_reloop_profile_{label}.gpx"
        project = copy_project(source, path)
        for key, (value, flag) in settings.items():
            if value is not None:
                set_instrument(project, key, value, bool(flag))
        replay(project)
        item = geometry_summary(project)
        item["profile_tested"] = label
        results["profile"].append(item)

    (TRIALS / "geometry_reloop.json").write_text(
        json.dumps(results, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(results, indent=2))


def accept_u() -> None:
    source = TRIALS / "geometry_reloop_profile_release_U.gpx"
    destination = CHECKPOINTS / "14_positive_common_U.gpx"
    project = copy_project(source, TRIALS / "accepted_positive_common_U.gpx")
    replay(project, cycles=2)
    shutil.copy2(project.filename, destination)
    print(json.dumps(geometry_summary(project), indent=2))


def run_broadening_loop() -> None:
    source = CHECKPOINTS / "14_positive_common_U.gpx"
    results: dict[str, list[dict]] = {"isotropic": [], "anisotropic": []}
    starts = {
        "BaWO4": (1.0, 300.0),
        "Ba3W2O9": (0.5, 1200.0),
        "WO3": (0.155, 2100.0),
    }
    modes = {
        "neutral": (10.0, False, 0.0, False),
        "size": (None, True, 0.0, False),
        "strain": (10.0, False, None, True),
        "combined": (None, True, None, True),
    }
    for phase_name, (size_start, strain_start) in starts.items():
        for label, settings in modes.items():
            size_value, refine_size, strain_value, refine_strain = settings
            size_value = size_start if size_value is None else size_value
            strain_value = strain_start if strain_value is None else strain_value
            path = TRIALS / f"broadening_reloop_{phase_name.lower()}_{label}.gpx"
            project = copy_project(source, path)
            set_isotropic_broadening(
                project,
                phase_name,
                size_value,
                refine_size,
                strain_value,
                refine_strain,
            )
            replay(project)
            item = broadening_summary(project)
            item["phase_tested"] = phase_name
            item["mode_tested"] = label
            results["isotropic"].append(item)

    anisotropic_tests = [
        ("Ba3W2O9", "Mustrain", (0, 0, 1)),
        ("Ba3W2O9", "Mustrain", (1, 0, 0)),
        ("Ba3W2O9", "Mustrain", (1, 1, 0)),
        ("WO3", "Size", (1, 0, 0)),
        ("WO3", "Size", (0, 1, 0)),
        ("WO3", "Size", (0, 0, 1)),
        ("WO3", "Mustrain", (1, 0, 0)),
        ("WO3", "Mustrain", (0, 1, 0)),
        ("WO3", "Mustrain", (0, 0, 1)),
    ]
    for phase_name, term, axis in anisotropic_tests:
        tag = "".join(str(abs(i)) for i in axis)
        path = TRIALS / (
            f"broadening_reloop_{phase_name.lower()}_{term.lower()}_uniaxial_{tag}.gpx"
        )
        project = copy_project(source, path)
        set_uniaxial_term(project, phase_name, term, axis)
        replay(project)
        item = broadening_summary(project)
        item["phase_tested"] = phase_name
        item["term_tested"] = term
        item["axis_tested"] = list(axis)
        results["anisotropic"].append(item)

    (TRIALS / "broadening_reloop_after_U.json").write_text(
        json.dumps(results, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(results, indent=2))


def accept_broadening() -> None:
    source = CHECKPOINTS / "14_positive_common_U.gpx"
    path = TRIALS / "accepted_anisotropic_broadening.gpx"
    project = copy_project(source, path)
    # BaWO4 remains genuinely neutral; its apparent size term traded almost
    # one-for-one with the common X width.
    set_isotropic_broadening(project, "BaWO4", 10.0, False, 0.0, False)

    set_isotropic_broadening(project, "Ba3W2O9", 10.0, False, 1260.0, True)
    ba3 = phase_by_name(project, "Ba3W2O9").data["Histograms"][
        project.histogram(0).name
    ]["Mustrain"]
    ba3[0] = "uniaxial"
    ba3[1][:] = [1410.8, 936.8, 1.0]
    ba3[2][:] = [True, True, False]
    ba3[3] = [0, 0, 1]

    set_isotropic_broadening(project, "WO3", 0.2285, True, 2190.0, True)
    wo3 = phase_by_name(project, "WO3").data["Histograms"][
        project.histogram(0).name
    ]["Mustrain"]
    wo3[0] = "uniaxial"
    wo3[1][:] = [2190.3, 6398.5, 1.0]
    wo3[2][:] = [True, True, False]
    wo3[3] = [0, 0, 1]

    replay(project, cycles=3)
    shutil.copy2(project.filename, CHECKPOINTS / "15_anisotropic_broadening.gpx")
    print(json.dumps(broadening_summary(project), indent=2))


def run_combined_broadening_challenges() -> None:
    source = CHECKPOINTS / "15_anisotropic_broadening.gpx"
    results: list[dict] = []

    # Remove each anisotropy while preserving the complementary accepted terms.
    path = TRIALS / "challenge_ba3_isotropic_strain.gpx"
    project = copy_project(source, path)
    phase = phase_by_name(project, "Ba3W2O9")
    strain = phase.data["Histograms"][project.histogram(0).name]["Mustrain"]
    strain[0] = "isotropic"
    strain[1][:] = [1260.0, 0.0, 1.0]
    strain[2][:] = [True, False, False]
    replay(project)
    item = broadening_summary(project)
    item["challenge"] = "Ba3W2O9 isotropic strain"
    results.append(item)

    path = TRIALS / "challenge_wo3_isotropic_strain.gpx"
    project = copy_project(source, path)
    phase = phase_by_name(project, "WO3")
    strain = phase.data["Histograms"][project.histogram(0).name]["Mustrain"]
    strain[0] = "isotropic"
    strain[1][:] = [2500.0, 0.0, 1.0]
    strain[2][:] = [True, False, False]
    replay(project)
    item = broadening_summary(project)
    item["challenge"] = "WO3 isotropic strain"
    results.append(item)

    # Test whether a second anisotropic size term supplies independent evidence.
    path = TRIALS / "challenge_wo3_uniaxial_size_and_strain.gpx"
    project = copy_project(source, path)
    set_uniaxial_term(project, "WO3", "Size", (0, 0, 1))
    replay(project)
    item = broadening_summary(project)
    item["challenge"] = "WO3 uniaxial size plus uniaxial strain"
    results.append(item)

    # Re-test the coupled BaWO4 size term in the fully combined width model.
    path = TRIALS / "challenge_bawo4_size_after_anisotropy.gpx"
    project = copy_project(source, path)
    set_isotropic_broadening(project, "BaWO4", 1.0, True, 0.0, False)
    replay(project)
    item = broadening_summary(project)
    item["challenge"] = "BaWO4 isotropic size"
    results.append(item)

    # Texture must remain useful after the width topology changes.
    path = TRIALS / "challenge_no_wo3_texture_after_anisotropy.gpx"
    project = copy_project(source, path)
    set_md(project, "WO3", (0, 0, 1), False)
    replay(project)
    item = broadening_summary(project)
    item["challenge"] = "no WO3 texture"
    results.append(item)

    (TRIALS / "combined_broadening_challenges.json").write_text(
        json.dumps(results, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(results, indent=2))


def run_final_geometry_loop() -> None:
    source = CHECKPOINTS / "15_anisotropic_broadening.gpx"
    results: dict[str, object] = {"background": [], "challenges": []}

    for order in [7, 8, 9, 10, 11, 12]:
        path = TRIALS / f"final_geometry_background_{order}.gpx"
        project = copy_project(source, path)
        set_background_order(project, order)
        replay(project)
        item = geometry_summary(project)
        item["order_tested"] = order
        results["background"].append(item)

    path = TRIALS / "final_geometry_no_roughness.gpx"
    project = copy_project(source, path)
    sample = project.histogram(0).data["Sample Parameters"]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    replay(project)
    item = geometry_summary(project)
    item["challenge"] = "no roughness"
    results["challenges"].append(item)

    # Decouple the polarization check from the roughness/scale degeneracy by
    # holding the accepted B value fixed for this comparison.
    path = TRIALS / "final_geometry_polarization_fixed_B.gpx"
    project = copy_project(source, path)
    sample = project.histogram(0).data["Sample Parameters"]
    sample["SurfRoughB"][1] = False
    set_instrument(project, "Polariz.", 0.7, True)
    replay(project)
    item = geometry_summary(project)
    item["challenge"] = "polarization with roughness B fixed"
    results["challenges"].append(item)

    path = TRIALS / "final_geometry_no_U.gpx"
    project = copy_project(source, path)
    set_instrument(project, "U", 0.0, False)
    replay(project)
    item = geometry_summary(project)
    item["challenge"] = "no U"
    results["challenges"].append(item)

    path = TRIALS / "final_geometry_no_X.gpx"
    project = copy_project(source, path)
    set_instrument(project, "X", 0.0, False)
    replay(project)
    item = geometry_summary(project)
    item["challenge"] = "no X"
    results["challenges"].append(item)

    (TRIALS / "final_geometry_reloop.json").write_text(
        json.dumps(results, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(results, indent=2))


def residual_audit(project) -> dict:
    arrays = np.asarray(project.histogram(0).data["data"][1], dtype=float)
    x, obs, weights, calc = arrays[0], arrays[1], arrays[2], arrays[3]

    def metric(mask) -> dict:
        mask = np.asarray(mask, dtype=bool)
        numerator = float(np.sum(weights[mask] * (obs[mask] - calc[mask]) ** 2))
        denominator = float(np.sum(weights[mask] * obs[mask] ** 2))
        return {
            "n": int(mask.sum()),
            "weighted_R_percent": 100.0 * math.sqrt(numerator / denominator),
            "mean_difference_counts": float(np.mean(obs[mask] - calc[mask])),
        }

    output = {
        "low_10_40": metric((x >= 10.0) & (x < 40.0)),
        "mid_40_70": metric((x >= 40.0) & (x < 70.0)),
        "high_70_100": metric((x >= 70.0) & (x <= 100.1)),
    }
    peak_sets = {
        "BaWO4": [17.488, 26.692, 28.387, 32.038, 43.187, 48.979, 53.684, 54.651],
        "Ba3W2O9": [16.478, 17.760, 26.279, 27.800, 30.821, 37.656, 40.797, 51.837, 63.073, 63.823, 71.505],
        "WO3": [23.399, 23.878, 24.649, 33.560, 34.450],
    }
    for phase_name, centers in peak_sets.items():
        mask = np.zeros_like(x, dtype=bool)
        for center in centers:
            mask |= np.abs(x - center) <= 0.22
        output[f"isolated_{phase_name}"] = metric(mask)
    return output


def accept_background() -> None:
    source = TRIALS / "final_geometry_background_11.gpx"
    project = copy_project(source, TRIALS / "accepted_background_11.gpx")
    replay(project, cycles=2)
    shutil.copy2(project.filename, CHECKPOINTS / "16_background_11.gpx")
    result = geometry_summary(project)
    result["residual_audit"] = residual_audit(project)
    print(json.dumps(result, indent=2))


def run_polarization_loop() -> None:
    source = CHECKPOINTS / "16_background_11.gpx"
    results: list[dict] = []

    configurations = [
        ("baseline", 0.7, False, None),
        ("refine_polarization_fixed_B", 0.732, True, False),
        ("fixed_polarization_refine_B", 0.732, False, True),
        ("refine_polarization_and_B", 0.732, True, True),
        ("refine_polarization_no_roughness", 0.732, True, "zero"),
    ]
    for label, p_value, p_refine, b_mode in configurations:
        path = TRIALS / f"polarization_loop_{label}.gpx"
        project = copy_project(source, path)
        sample = project.histogram(0).data["Sample Parameters"]
        set_instrument(project, "Polariz.", p_value, p_refine)
        if b_mode is False:
            sample["SurfRoughB"][1] = False
        elif b_mode is True:
            sample["SurfRoughB"][1] = True
        elif b_mode == "zero":
            sample["SurfRoughB"] = [0.0, False]
        replay(project)
        item = geometry_summary(project)
        item["mode"] = label
        item["residual_audit"] = residual_audit(project)
        results.append(item)

    (TRIALS / "polarization_loop.json").write_text(
        json.dumps(results, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(results, indent=2))


def add_neutral_phase(project, cif: Path, name: str, scale: float):
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cif), phasename=name, histograms=[hist], fmthint="CIF"
    )
    set_isotropic_broadening(project, name, 10.0, False, 0.0, False)
    set_md(project, name, (0, 0, 1), False)
    phase.set_refinements({"Cell": False})
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [float(scale), True]
    return phase


def run_watchlist() -> None:
    source = CHECKPOINTS / "16_background_11.gpx"
    cod = Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif"
    )
    candidates = {
        "BaCO3_orth_9010928": cod / "9/01/09/9010928.cif",
        "BaCO3_orth_1011149": cod / "1/01/11/1011149.cif",
        "BaCO3_hex_9006847": cod / "9/00/68/9006847.cif",
        "Ba3WO6_disordered_1534803": cod / "1/53/48/1534803.cif",
        "Ba3WO6_ordered_analogue": ROOT / "candidates/ba3_wo6_ca3wo6_adapted.cif",
        "WO3_triclinic_extra": cod / "2/10/62/2106293.cif",
        "WO3_orthorhombic_extra": cod / "2/10/73/2107312.cif",
    }
    results: list[dict] = []
    for label, cif in candidates.items():
        for start in [0.001, 0.02]:
            tag = str(start).replace(".", "p")
            path = TRIALS / f"watch_{label}_{tag}.gpx"
            try:
                project = copy_project(source, path)
                add_neutral_phase(project, cif, label, start)
                replay(project)
                item = concise_summary(project)
                phase = phase_by_name(project, label)
                hap = phase.data["Histograms"][project.histogram(0).name]
                item.update(
                    {
                        "candidate": label,
                        "cif": str(cif),
                        "starting_scale": start,
                        "final_scale": float(hap["Scale"][0]),
                        "scale_refined": bool(hap["Scale"][1]),
                    }
                )
            except Exception as exc:
                item = {
                    "candidate": label,
                    "cif": str(cif),
                    "starting_scale": start,
                    "error": f"{type(exc).__name__}: {exc}",
                }
            results.append(item)

    (TRIALS / "watchlist_rechallenge.json").write_text(
        json.dumps(results, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(results, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "command",
        choices=[
            "texture",
            "accept-texture",
            "geometry",
            "accept-U",
            "broadening",
            "accept-broadening",
            "broadening-challenges",
            "final-geometry",
            "accept-background",
            "polarization-loop",
            "watchlist",
        ],
    )
    args = parser.parse_args()
    if args.command == "texture":
        run_texture_loop()
    elif args.command == "accept-texture":
        accept_texture()
    elif args.command == "geometry":
        run_geometry_loop()
    elif args.command == "accept-U":
        accept_u()
    elif args.command == "broadening":
        run_broadening_loop()
    elif args.command == "accept-broadening":
        accept_broadening()
    elif args.command == "broadening-challenges":
        run_combined_broadening_challenges()
    elif args.command == "final-geometry":
        run_final_geometry_loop()
    elif args.command == "accept-background":
        accept_background()
    elif args.command == "polarization-loop":
        run_polarization_loop()
    elif args.command == "watchlist":
        run_watchlist()


if __name__ == "__main__":
    main()
