#!/usr/bin/env python3
"""Replay the accepted full-range GSAS-II model and freeze deliverables."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

from finalize_refinement import CHECKPOINTS, ROOT, copy_project, replay


PHASE_OUTPUTS = {
    "BaWO4": ("BaWO4", "phases/ba_wo4.cif", "COD 1546036 SrWO4 topology adapted to BaWO4"),
    "Ba3W2O9": ("Ba3W2O9", "phases/ba3_w2_o9.cif", "COD 1533878"),
    "WO3": ("WO3", "phases/wo3_monoclinic.cif", "COD 2311041"),
    "BaCO3_orth_9010928": ("BaCO3", "phases/ba_co3_orthorhombic.cif", "COD 9010928"),
}


def main() -> None:
    project = copy_project(CHECKPOINTS / "21_final_geometry.gpx", ROOT / "final.gpx")
    hist = project.histogram(0)

    # Explicitly replay the complete measured range and preserve the accepted
    # fixed polarization and neutral texture state.
    limits = hist.data["Limits"]
    limits[1] = list(limits[0])
    hist.data["Instrument Parameters"][0]["Polariz."] = [0.7, 0.7, False]
    for phase in project.phases():
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0], po[1], po[2] = "MD", 1.0, False
    replay(project, cycles=3)

    phase_dir = ROOT / "phases"
    phase_dir.mkdir(parents=True, exist_ok=True)
    for phase in project.phases():
        _, relative_path, _ = PHASE_OUTPUTS[phase.name]
        phase.export_CIF(str(ROOT / relative_path))

    arrays = np.asarray(hist.data["data"][1], dtype=float)
    x, observed, weights, calculated, background = arrays[:5]
    difference = observed - calculated
    with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_observed_minus_calculated",
                "background_intensity",
            ]
        )
        for values in zip(x, observed, calculated, difference, background):
            writer.writerow([f"{float(value):.15g}" for value in values])

    mask = weights > 0
    numerator = float(np.sum(weights[mask] * difference[mask] ** 2))
    denominator = float(np.sum(weights[mask] * observed[mask] ** 2))
    rwp = 100.0 * math.sqrt(numerator / denominator)
    rp = 100.0 * float(np.sum(np.abs(difference[mask]))) / float(
        np.sum(np.abs(observed[mask]))
    )
    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    gof = float(rvals["GOF"])
    rexp = rwp / gof

    mass = hist.ComputeMassFracs()
    raw = {name: float(value[0]) for name, value in mass.items()}
    total = sum(raw.values())
    fractions = {name: value / total for name, value in raw.items()}

    phases = []
    for phase in project.phases():
        formula, relative_path, source = PHASE_OUTPUTS[phase.name]
        cell = [float(value) for value in phase.data["General"]["Cell"][1:8]]
        phases.append(
            {
                "name": phase.name,
                "formula": formula,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cell": {
                    "a_angstrom": cell[0],
                    "b_angstrom": cell[1],
                    "c_angstrom": cell[2],
                    "alpha_deg": cell[3],
                    "beta_deg": cell[4],
                    "gamma_deg": cell[5],
                    "volume_angstrom3": cell[6],
                },
                "source_model": source,
                "cif_path": relative_path,
                "project_path": "final.gpx",
                "weight_fraction": fractions[phase.name],
                "weight_fraction_esd": float(mass[phase.name][1]),
            }
        )

    result = {
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "Rexp_percent": rexp,
            "GOF": gof,
            "reduced_chi_squared": gof * gof,
            "chi_squared": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_parameters": int(rvals["Nvars"]),
            "two_theta_min_deg": float(x[mask][0]),
            "two_theta_max_deg": float(x[mask][-1]),
            "converged": bool(rvals.get("converged", False)),
            "maximum_shift_over_esd": float(rvals.get("Max shft/sig", math.nan)),
        },
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
