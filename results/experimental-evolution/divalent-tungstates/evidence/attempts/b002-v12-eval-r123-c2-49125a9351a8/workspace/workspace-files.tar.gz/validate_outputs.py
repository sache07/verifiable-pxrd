#!/usr/bin/env python3
"""Cross-check frozen JSON, CIF, profile, and GPX deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main() -> None:
    result = json.loads((ROOT / "result.json").read_text(encoding="utf-8"))
    assert result["project_path"] == "final.gpx"
    assert (ROOT / result["project_path"]).is_file()
    assert (ROOT / result["fit_profile_path"]).is_file()
    assert len(result["phases"]) == 4
    assert abs(sum(float(p["weight_fraction"]) for p in result["phases"]) - 1.0) < 1e-12
    for phase in result["phases"]:
        assert isinstance(phase["weight_fraction"], (int, float))
        assert phase["weight_fraction"] > 0
        assert phase["project_path"] == "final.gpx"
        assert (ROOT / phase["cif_path"]).is_file()

    with (ROOT / "fit.csv").open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == result["fit_statistics"]["n_observations"] == 8301
    table = np.array(
        [
            [
                float(row["two_theta_deg"]),
                float(row["observed_intensity"]),
                float(row["calculated_intensity"]),
                float(row["difference_observed_minus_calculated"]),
                float(row["background_intensity"]),
            ]
            for row in rows
        ]
    )
    assert np.allclose(table[:, 3], table[:, 1] - table[:, 2], rtol=0, atol=2e-6)

    project = G2sc.G2Project(str(ROOT / "final.gpx"))
    hist = project.histogram(0)
    arrays = np.asarray(hist.data["data"][1], dtype=float)
    expected = np.column_stack(
        [arrays[0], arrays[1], arrays[3], arrays[1] - arrays[3], arrays[4]]
    )
    assert np.allclose(table, expected, rtol=2e-9, atol=2e-6)
    assert abs(hist.get_wR() - result["fit_statistics"]["Rwp_percent"]) < 1e-8

    mass = hist.ComputeMassFracs()
    total = sum(float(value[0]) for value in mass.values())
    json_fractions = {p["name"]: float(p["weight_fraction"]) for p in result["phases"]}
    assert set(mass) == set(json_fractions)
    for name, value in mass.items():
        assert abs(float(value[0]) / total - json_fractions[name]) < 1e-10
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        assert hap["Scale"][0] > 0
        assert hap["Pref.Ori."][1] == 1.0
        assert hap["Pref.Ori."][2] is False

    print(
        json.dumps(
            {
                "status": "pass",
                "phases": list(mass),
                "fraction_sum": sum(json_fractions.values()),
                "fit_rows": len(rows),
                "Rwp_percent": hist.get_wR(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
