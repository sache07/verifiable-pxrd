#!/usr/bin/env python3
"""Reproducible GSAS-II refinement workflow for the Ba-W-O powder pattern.

Run with the Python interpreter from the bundled GSAS-II environment.
The script deliberately saves checkpoints between refinement stages so that
profile, phase-inventory and source-model trials can all start from a common
state.
"""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
INSTRUMENT = ROOT / "instrument.instprm"
DEFAULT_BAWO4 = ROOT / "candidates" / "ba_wo4_bamo_adapted.cif"
DEFAULT_BA3W2O9 = ROOT / "candidates" / "ba3_w2_o9_cod1533878.cif"


def instrument_value(hist, key: str, value: float, refine: bool | None = None) -> None:
    item = hist.data["Instrument Parameters"][0][key]
    item[0] = float(value)
    item[1] = float(value)
    if refine is not None:
        item[2] = bool(refine)


def neutralize_phase_terms(phase, hist_name: str) -> None:
    """Put inactive HAP profile/intensity terms at genuinely neutral values."""
    hap = phase.data["Histograms"][hist_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [100.0, 100.0, 1.0]  # micrometres
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])


def checkpoint(project, label: str) -> Path:
    project.save()
    destination = ROOT / "checkpoints" / f"{label}.gpx"
    shutil.copy2(project.filename, destination)
    return destination


def project_summary(project) -> dict:
    hist = project.histogram(0)
    covariance = project.data.get("Covariance", {}).get("data", {})
    try:
        fractions = hist.ComputeMassFracs()
    except Exception:
        fractions = {}
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "scale_refined": bool(hap["Scale"][1]),
            "mass_fraction": (
                None if phase.name not in fractions else float(fractions[phase.name][0])
            ),
            "mass_fraction_esd": (
                None if phase.name not in fractions else float(fractions[phase.name][1])
            ),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    return {
        "project": str(Path(project.filename).resolve()),
        "wR_percent": hist.get_wR(),
        "residuals": dict(hist.data["data"][0]),
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "Nobs": covariance.get("Rvals", {}).get("Nobs"),
        "Nvars": covariance.get("Rvals", {}).get("Nvars"),
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"],
        "phases": phases,
        "vary_list": [str(v) for v in covariance.get("varyList", [])],
        "variables": [float(v) for v in covariance.get("variables", [])],
        "sigmas": [float(v) for v in covariance.get("sig", [])],
    }


def print_summary(project, label: str) -> None:
    summary = project_summary(project)
    print(f"\n=== {label} ===")
    print("wR (%)", summary["wR_percent"], "GOF", summary["GOF"])
    print(
        "instrument",
        {
            key: summary["instrument"][key]
            for key in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]
        },
    )
    print("sample Shift", summary["sample"].get("Shift"))
    for name, phase in summary["phases"].items():
        print(
            name,
            "scale",
            phase["scale"],
            "wtfrac",
            phase["mass_fraction"],
            "cell",
            phase["cell"],
        )


def refine(project, label: str) -> None:
    """Run one refinement and fail on non-finite or obviously invalid results."""
    project.refine(makeBack=False)
    summary = project_summary(project)
    wr = summary["wR_percent"]
    if wr is None or not math.isfinite(float(wr)):
        raise RuntimeError(f"{label}: non-finite weighted profile residual")
    for name, phase in summary["phases"].items():
        if phase["scale"] < 0 or not math.isfinite(phase["scale"]):
            raise RuntimeError(f"{label}: invalid scale for {name}: {phase['scale']}")
    print_summary(project, label)


def build_initial_project(output: Path, bawo4_cif: Path = DEFAULT_BAWO4):
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(PATTERN), str(INSTRUMENT), fmthint="comma"
    )
    project.add_phase(
        str(bawo4_cif), phasename="BaWO4", histograms=[hist], fmthint="CIF"
    )
    project.add_phase(
        str(DEFAULT_BA3W2O9),
        phasename="Ba3W2O9",
        histograms=[hist],
        fmthint="CIF",
    )

    # Full measured range and counting-statistics weights from the CSV reader.
    hist.set_refinements({"Limits": [9.90343322, 100.09455322]})
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]

    # Smooth, low-order common profile baseline.
    for key, value in {
        "U": 5.0,
        "V": 0.0,
        "W": 15.0,
        "X": 0.1,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "Zero": 0.0,
        "Polariz.": 0.70,
    }.items():
        instrument_value(hist, key, value, refine=False)

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": [1200.0, -700.0, 300.0, -100.0, 30.0, -10.0],
            }
        }
    )
    for phase in project.phases():
        neutralize_phase_terms(phase, hist.name)
        phase.set_refinements({"Cell": False})
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])

    project.set_Controls("cycles", 30)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    project.save()
    return project


def run_common(output: Path, bawo4_cif: Path = DEFAULT_BAWO4) -> None:
    project = build_initial_project(output, bawo4_cif)
    hist = project.histogram(0)

    checkpoint(project, "00_inventory_neutral")
    refine(project, "background and scales")
    checkpoint(project, "01_background_scales")

    # One angular correction appropriate to reflection geometry.
    hist.data["Sample Parameters"]["Shift"] = [0.0, True]
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, "cells and specimen displacement")
    checkpoint(project, "02_cells_displacement")

    # Nonnegative, low-dimensional common width model. V/Y/Z remain fixed at zero.
    hist.set_refinements({"Instrument Parameters": ["W"]})
    refine(project, "common W")
    instrument_value(hist, "U", hist.data["Instrument Parameters"][0]["U"][1], True)
    instrument_value(hist, "X", max(0.1, hist.data["Instrument Parameters"][0]["X"][1]), True)
    refine(project, "common U/W/X")
    checkpoint(project, "03_common_profile")

    project.save()
    (ROOT / "trials" / "common_summary.json").write_text(
        json.dumps(project_summary(project), indent=2, default=str) + "\n"
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["common", "summary"])
    parser.add_argument("--project", type=Path, default=ROOT / "trials" / "common.gpx")
    parser.add_argument("--bawo4", type=Path, default=DEFAULT_BAWO4)
    args = parser.parse_args()
    if args.command == "common":
        run_common(args.project.resolve(), args.bawo4.resolve())
    else:
        project = G2sc.G2Project(str(args.project.resolve()))
        print(json.dumps(project_summary(project), indent=2, default=str))


if __name__ == "__main__":
    main()
