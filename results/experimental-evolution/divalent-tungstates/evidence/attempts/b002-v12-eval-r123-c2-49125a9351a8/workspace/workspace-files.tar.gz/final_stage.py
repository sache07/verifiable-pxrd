#!/usr/bin/env python3
"""Final inventory and convergence loops after the BaCO3 watch-list hit.

Each comparison reloads a named common checkpoint.  This keeps bounded or
singular trials from contaminating the accepted branch and makes all model
selection decisions replayable from the saved GPX files.
"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from finalize_refinement import (
    CHECKPOINTS,
    ROOT,
    TRIALS,
    broadening_summary,
    add_neutral_phase,
    concise_summary,
    copy_project,
    geometry_summary,
    phase_by_name,
    replay,
    set_background_order,
    set_instrument,
    set_isotropic_broadening,
    set_md,
    set_uniaxial_term,
)


CARBONATE = "BaCO3_orth_9010928"


def write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def cell_summary(project) -> dict:
    result = concise_summary(project)
    result["cells"] = {}
    for phase in project.phases():
        general = phase.data["General"]
        result["cells"][phase.name] = {
            "space_group": general["SGData"]["SpGrp"],
            "cell": [float(value) for value in general["Cell"][1:8]],
            "cell_refine": bool(general["Cell"][0]),
        }
    return result


def accept_carbonate_cell() -> None:
    source = TRIALS / "watch_BaCO3_orth_9010928_0p001.gpx"
    trial = TRIALS / "accepted_baco3_cell.gpx"
    project = copy_project(source, trial)
    phase_by_name(project, CARBONATE).set_refinements({"Cell": True})
    replay(project, cycles=3)
    shutil.copy2(project.filename, CHECKPOINTS / "17_baco3_cell.gpx")
    print(json.dumps(cell_summary(project), indent=2))


def carbonate_broadening_loop() -> None:
    source = CHECKPOINTS / "17_baco3_cell.gpx"
    results: dict[str, list[dict]] = {"isotropic": [], "anisotropic": []}
    modes = {
        "neutral": (10.0, False, 0.0, False),
        "size": (1.0, True, 0.0, False),
        "strain": (10.0, False, 500.0, True),
        "combined": (1.0, True, 500.0, True),
    }
    for label, settings in modes.items():
        path = TRIALS / f"baco3_broadening_{label}.gpx"
        project = copy_project(source, path)
        set_isotropic_broadening(project, CARBONATE, *settings)
        replay(project, cycles=3)
        item = broadening_summary(project)
        item["mode_tested"] = label
        results["isotropic"].append(item)

    # Orthorhombic symmetry permits independent low-index uniaxial tests.
    for term in ["Size", "Mustrain"]:
        for axis in [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0)]:
            tag = "".join(str(i) for i in axis)
            path = TRIALS / f"baco3_{term.lower()}_uniaxial_{tag}.gpx"
            project = copy_project(source, path)
            if term == "Size":
                set_isotropic_broadening(project, CARBONATE, 1.0, True, 0.0, False)
            else:
                set_isotropic_broadening(project, CARBONATE, 10.0, False, 500.0, True)
            set_uniaxial_term(project, CARBONATE, term, axis)
            replay(project, cycles=3)
            item = broadening_summary(project)
            item["term_tested"] = term
            item["axis_tested"] = list(axis)
            results["anisotropic"].append(item)

    write_json(TRIALS / "baco3_broadening_loop.json", results)
    print(json.dumps(results, indent=2))


def accept_carbonate_broadening() -> None:
    """Accept the replay-stable [010] uniaxial strain model provisionally."""
    source = TRIALS / "baco3_mustrain_uniaxial_010.gpx"
    project = copy_project(source, TRIALS / "accepted_baco3_broadening.gpx")
    replay(project, cycles=3)
    shutil.copy2(project.filename, CHECKPOINTS / "18_baco3_broadening.gpx")
    print(json.dumps(broadening_summary(project), indent=2))


def inventory_broadening_loop() -> None:
    """Re-challenge every retained phase after adding carbonate."""
    source = CHECKPOINTS / "18_baco3_broadening.gpx"
    results: list[dict] = []

    def run(label: str, configure) -> None:
        project = copy_project(source, TRIALS / f"inventory_width_{label}.gpx")
        configure(project)
        replay(project, cycles=2)
        item = broadening_summary(project)
        item["challenge"] = label
        results.append(item)

    run("baseline", lambda project: None)
    run(
        "bawo4_size",
        lambda project: set_isotropic_broadening(
            project, "BaWO4", 1.0, True, 0.0, False
        ),
    )
    run(
        "bawo4_strain",
        lambda project: set_isotropic_broadening(
            project, "BaWO4", 10.0, False, 300.0, True
        ),
    )
    run(
        "bawo4_combined",
        lambda project: set_isotropic_broadening(
            project, "BaWO4", 1.0, True, 300.0, True
        ),
    )
    run(
        "ba3_neutral",
        lambda project: set_isotropic_broadening(
            project, "Ba3W2O9", 10.0, False, 0.0, False
        ),
    )
    run(
        "ba3_isotropic_strain",
        lambda project: set_isotropic_broadening(
            project, "Ba3W2O9", 10.0, False, 1200.0, True
        ),
    )
    run(
        "ba3_size",
        lambda project: set_isotropic_broadening(
            project, "Ba3W2O9", 0.5, True, 0.0, False
        ),
    )
    run(
        "wo3_neutral",
        lambda project: set_isotropic_broadening(
            project, "WO3", 10.0, False, 0.0, False
        ),
    )
    run(
        "wo3_size",
        lambda project: set_isotropic_broadening(
            project, "WO3", 0.25, True, 0.0, False
        ),
    )
    run(
        "wo3_isotropic_strain",
        lambda project: set_isotropic_broadening(
            project, "WO3", 10.0, False, 2500.0, True
        ),
    )
    run(
        "wo3_isotropic_combined",
        lambda project: set_isotropic_broadening(
            project, "WO3", 0.25, True, 2500.0, True
        ),
    )
    run(
        "baco3_neutral",
        lambda project: set_isotropic_broadening(
            project, CARBONATE, 10.0, False, 0.0, False
        ),
    )
    run(
        "baco3_isotropic_strain",
        lambda project: set_isotropic_broadening(
            project, CARBONATE, 10.0, False, 6800.0, True
        ),
    )

    write_json(TRIALS / "inventory_broadening_rechallenge.json", results)
    print(json.dumps(results, indent=2))


def accept_inventory_broadening() -> None:
    """Prune the unsupported post-carbonate WO3 strain anisotropy."""
    source = TRIALS / "inventory_width_wo3_isotropic_combined.gpx"
    project = copy_project(source, TRIALS / "accepted_inventory_broadening.gpx")
    # Carbonate makes the former WO3 texture ratio refine to unity. Start the
    # new texture loop from a genuinely neutral checkpoint for every phase.
    for name in ["BaWO4", "Ba3W2O9", "WO3", CARBONATE]:
        set_md(project, name, (0, 0, 1), False)
    replay(project, cycles=3)
    shutil.copy2(project.filename, CHECKPOINTS / "19_pruned_broadening.gpx")
    print(json.dumps(broadening_summary(project), indent=2))


def postcarbonate_texture_loop() -> None:
    source = CHECKPOINTS / "19_pruned_broadening.gpx"
    names = ["BaWO4", "Ba3W2O9", "WO3", CARBONATE]
    results: dict[str, object] = {"single_axis": []}

    baseline = copy_project(source, TRIALS / "postcarbonate_texture_baseline.gpx")
    replay(baseline, cycles=2)
    results["baseline"] = concise_summary(baseline)

    neutral_path = TRIALS / "postcarbonate_texture_all_neutral.gpx"
    neutral = copy_project(source, neutral_path)
    for name in names:
        set_md(neutral, name, (0, 0, 1), False)
    replay(neutral, cycles=2)
    results["all_neutral"] = concise_summary(neutral)

    axes = {
        "BaWO4": [(0, 0, 1), (1, 0, 0), (1, 1, 0), (1, 1, 2)],
        "Ba3W2O9": [(0, 0, 1), (1, 0, 0), (1, 1, 0), (1, 0, 1)],
        "WO3": [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 1, 1)],
        CARBONATE: [
            (1, 0, 0),
            (0, 1, 0),
            (0, 0, 1),
            (1, 1, 0),
            (1, 0, 1),
            (0, 1, 1),
        ],
    }
    for name, candidates in axes.items():
        for axis in candidates:
            tag = "".join(str(i) for i in axis)
            path = TRIALS / f"postcarbonate_texture_{name.lower()}_{tag}.gpx"
            project = copy_project(neutral_path, path)
            set_md(project, name, axis, True)
            replay(project, cycles=2)
            item = concise_summary(project)
            item["phase_tested"] = name
            item["axis_tested"] = list(axis)
            results["single_axis"].append(item)

    write_json(TRIALS / "postcarbonate_texture_loop.json", results)
    print(json.dumps(results, indent=2))


def accept_neutral_texture() -> None:
    source = TRIALS / "postcarbonate_texture_all_neutral.gpx"
    project = copy_project(source, TRIALS / "accepted_neutral_texture.gpx")
    replay(project, cycles=3)
    shutil.copy2(project.filename, CHECKPOINTS / "20_neutral_texture.gpx")
    print(json.dumps(concise_summary(project), indent=2))


def postcarbonate_geometry_loop() -> None:
    source = CHECKPOINTS / "20_neutral_texture.gpx"
    results: dict[str, object] = {
        "background": [],
        "profile_and_geometry": [],
    }

    for order in [7, 8, 9, 10, 11, 12, 13]:
        project = copy_project(source, TRIALS / f"postcarbonate_background_{order}.gpx")
        set_background_order(project, order)
        replay(project, cycles=2)
        item = geometry_summary(project)
        item["order_tested"] = order
        results["background"].append(item)

    def run(label: str, configure) -> None:
        project = copy_project(source, TRIALS / f"postcarbonate_geometry_{label}.gpx")
        configure(project)
        replay(project, cycles=2)
        item = geometry_summary(project)
        item["challenge"] = label
        results["profile_and_geometry"].append(item)

    def no_roughness(project) -> None:
        sample = project.histogram(0).data["Sample Parameters"]
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.0, False]

    def roughness_a_only(project) -> None:
        sample = project.histogram(0).data["Sample Parameters"]
        sample["SurfRoughA"] = [0.01, True]
        sample["SurfRoughB"] = [0.0, False]

    def polarization_fixed_b(project) -> None:
        project.histogram(0).data["Sample Parameters"]["SurfRoughB"][1] = False
        set_instrument(project, "Polariz.", 0.7, True)

    def polarization_and_b(project) -> None:
        project.histogram(0).data["Sample Parameters"]["SurfRoughB"][1] = True
        set_instrument(project, "Polariz.", 0.7, True)

    def no_shift(project) -> None:
        project.histogram(0).data["Sample Parameters"]["Shift"] = [0.0, False]

    run("no_roughness", no_roughness)
    run("roughness_A_only", roughness_a_only)
    run("polarization_fixed_B", polarization_fixed_b)
    run("polarization_and_B", polarization_and_b)
    run("no_sample_shift", no_shift)
    run("no_U", lambda project: set_instrument(project, "U", 0.0, False))
    run("no_X", lambda project: set_instrument(project, "X", 0.0, False))

    write_json(TRIALS / "postcarbonate_geometry_loop.json", results)
    print(json.dumps(results, indent=2))


def recover_geometry_results() -> None:
    """Finish stable challenges after stopping the intentionally bad shift run."""
    source = CHECKPOINTS / "20_neutral_texture.gpx"
    results: dict[str, object] = {
        "baseline": geometry_summary(copy_project(source, TRIALS / "geometry_recovery_baseline.gpx")),
        "background": [],
        "profile_and_geometry": [],
        "invalid_trials": [
            {
                "challenge": "no_sample_shift",
                "reason": "chi-square increased by orders of magnitude and the replay became singular",
            }
        ],
    }
    for order in [7, 8, 9, 10, 11, 12, 13]:
        project = copy_project(
            TRIALS / f"postcarbonate_background_{order}.gpx",
            TRIALS / f"geometry_recovery_background_{order}.gpx",
        )
        item = geometry_summary(project)
        item["order_tested"] = order
        results["background"].append(item)

    for label in [
        "no_roughness",
        "roughness_A_only",
        "polarization_fixed_B",
        "polarization_and_B",
    ]:
        path = TRIALS / f"postcarbonate_geometry_{label}.gpx"
        project = copy_project(path, TRIALS / f"geometry_recovery_{label}.gpx")
        item = geometry_summary(project)
        item["challenge"] = label
        results["profile_and_geometry"].append(item)

    stable = {
        "no_U": lambda project: set_instrument(project, "U", 0.0, False),
        "no_X": lambda project: set_instrument(project, "X", 0.0, False),
    }
    for label, configure in stable.items():
        project = copy_project(source, TRIALS / f"geometry_recovery_{label}.gpx")
        configure(project)
        replay(project, cycles=2)
        item = geometry_summary(project)
        item["challenge"] = label
        results["profile_and_geometry"].append(item)

    write_json(TRIALS / "postcarbonate_geometry_loop.json", results)
    print(json.dumps(results, indent=2))


def accept_geometry() -> None:
    source = TRIALS / "postcarbonate_background_10.gpx"
    project = copy_project(source, TRIALS / "accepted_postcarbonate_geometry.gpx")
    set_instrument(project, "Polariz.", 0.7, False)
    replay(project, cycles=3)
    shutil.copy2(project.filename, CHECKPOINTS / "21_final_geometry.gpx")
    print(json.dumps(geometry_summary(project), indent=2))


def final_watchlist() -> None:
    source = CHECKPOINTS / "21_final_geometry.gpx"
    cod = Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif"
    )
    candidates = {
        "BaCO3_orth_alt_1011149": cod / "1/01/11/1011149.cif",
        "BaCO3_hex_9006847": cod / "9/00/68/9006847.cif",
        "Ba3WO6_disordered_1534803": cod / "1/53/48/1534803.cif",
        "Ba3WO6_ordered_analogue": ROOT / "candidates/ba3_wo6_ca3wo6_adapted.cif",
        "WO3_triclinic_extra": cod / "2/10/62/2106293.cif",
        "WO3_orthorhombic_extra": cod / "2/10/73/2107312.cif",
    }
    results: list[dict] = []
    for label, cif in candidates.items():
        for start in [0.001, 0.02]:
            tag = str(start).replace(".", "p")
            path = TRIALS / f"final_watch_{label}_{tag}.gpx"
            try:
                project = copy_project(source, path)
                add_neutral_phase(project, cif, label, start)
                replay(project, cycles=2)
                item = concise_summary(project)
                phase = phase_by_name(project, label)
                hap = phase.data["Histograms"][project.histogram(0).name]
                item.update(
                    {
                        "candidate": label,
                        "cif": str(cif),
                        "starting_scale": start,
                        "final_scale": float(hap["Scale"][0]),
                    }
                )
            except Exception as exc:
                item = {
                    "candidate": label,
                    "cif": str(cif),
                    "starting_scale": start,
                    "error": f"{type(exc).__name__}: {exc}",
                }
            results.append(item)
    write_json(TRIALS / "final_watchlist_rechallenge.json", results)
    print(json.dumps(results, indent=2))


def remove_phase(project, name: str) -> None:
    hist = project.histogram(0)
    del project.data["Phases"][name]
    hist.data.get("Reflection Lists", {}).pop(name, None)
    # GSASIIscriptable keeps a parallel tree-name cache. Remove the phase
    # there as well so update_ids() cannot construct a stale None phase.
    for node in project.names:
        if node and node[0] == "Phases" and name in node:
            node.remove(name)
            break
    project.update_ids()


def wo3_coexistence_loop() -> None:
    """Stress-test the weak same-formula triclinic WO3 scale."""
    source = TRIALS / "final_watch_WO3_triclinic_extra_0p001.gpx"
    tri = "WO3_triclinic_extra"
    results: list[dict] = []

    def run(label: str, configure) -> None:
        project = copy_project(source, TRIALS / f"wo3_coexist_{label}.gpx")
        configure(project)
        replay(project, cycles=2)
        item = broadening_summary(project)
        item["challenge"] = label
        results.append(item)

    run("baseline", lambda project: None)
    run(
        "triclinic_size",
        lambda project: set_isotropic_broadening(project, tri, 0.5, True, 0.0, False),
    )
    run(
        "triclinic_strain",
        lambda project: set_isotropic_broadening(project, tri, 10.0, False, 1000.0, True),
    )
    run(
        "triclinic_combined",
        lambda project: set_isotropic_broadening(project, tri, 0.5, True, 1000.0, True),
    )
    run(
        "monoclinic_neutral",
        lambda project: set_isotropic_broadening(project, "WO3", 10.0, False, 0.0, False),
    )
    run(
        "monoclinic_size",
        lambda project: set_isotropic_broadening(project, "WO3", 0.35, True, 0.0, False),
    )
    run(
        "monoclinic_strain",
        lambda project: set_isotropic_broadening(project, "WO3", 10.0, False, 1700.0, True),
    )
    for axis in [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0)]:
        tag = "".join(str(i) for i in axis)

        def configure(project, axis=axis) -> None:
            set_isotropic_broadening(project, "WO3", 0.35, True, 1700.0, True)
            set_uniaxial_term(project, "WO3", "Mustrain", axis)

        run(f"monoclinic_uniaxial_strain_{tag}", configure)

    def refine_tri_cell(project) -> None:
        phase_by_name(project, tri).set_refinements({"Cell": True})

    run("triclinic_cell", refine_tri_cell)
    for phase_name, axes in {
        "WO3": [(0, 0, 1), (1, 1, 0)],
        tri: [(1, 0, 0), (0, 1, 0), (0, 0, 1)],
    }.items():
        for axis in axes:
            tag = "".join(str(i) for i in axis)
            run(
                f"texture_{phase_name.lower()}_{tag}",
                lambda project, phase_name=phase_name, axis=axis: set_md(
                    project, phase_name, axis, True
                ),
            )

    write_json(TRIALS / "wo3_coexistence_loop.json", results)
    print(json.dumps(results, indent=2))


def source_ranking_loop() -> None:
    """Repeat retained-source rankings on the final common profile."""
    source = CHECKPOINTS / "21_final_geometry.gpx"
    cod = Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif"
    )
    results: dict[str, list[dict]] = {"WO3": [], "BaWO4": [], "BaCO3": []}

    wo3_sources = {
        "monoclinic_2311041": (cod / "2/31/10/2311041.cif", True),
        "triclinic_2106293": (cod / "2/10/62/2106293.cif", False),
        "orthorhombic_2107312": (cod / "2/10/73/2107312.cif", False),
    }
    for label, (cif, is_current) in wo3_sources.items():
        neutral_path = TRIALS / f"source_rank_wo3_{label}_neutral.gpx"
        project = copy_project(source, neutral_path)
        phase_name = "WO3" if is_current else f"WO3_source_{label}"
        if is_current:
            set_isotropic_broadening(project, phase_name, 10.0, False, 0.0, False)
            replay(project, cycles=2)
        else:
            remove_phase(project, "WO3")
            add_neutral_phase(project, cif, phase_name, 0.5)
            replay(project, cycles=1)  # scale before cell
            phase_by_name(project, phase_name).set_refinements({"Cell": True})
            replay(project, cycles=2)
        item = broadening_summary(project)
        item.update({"formula": "WO3", "source": label, "mode": "neutral"})
        results["WO3"].append(item)

        modes = {
            "size": (0.25, True, 0.0, False),
            "strain": (10.0, False, 2000.0, True),
            "combined": (0.25, True, 2000.0, True),
        }
        for mode, settings in modes.items():
            trial = copy_project(
                neutral_path, TRIALS / f"source_rank_wo3_{label}_{mode}.gpx"
            )
            set_isotropic_broadening(trial, phase_name, *settings)
            replay(trial, cycles=2)
            item = broadening_summary(trial)
            item.update({"formula": "WO3", "source": label, "mode": mode})
            results["WO3"].append(item)

    bawo_sources = {
        "SrWO4_topology_adapted": (ROOT / "candidates/ba_wo4_srwo_adapted.cif", True),
        "exact_split_1527204": (cod / "1/52/72/1527204.cif", False),
        "BaMoO4_topology_adapted": (ROOT / "candidates/ba_wo4_bamo_adapted.cif", False),
    }
    for label, (cif, is_current) in bawo_sources.items():
        path = TRIALS / f"source_rank_bawo4_{label}.gpx"
        project = copy_project(source, path)
        phase_name = "BaWO4" if is_current else f"BaWO4_source_{label}"
        if is_current:
            set_isotropic_broadening(project, phase_name, 10.0, False, 0.0, False)
            replay(project, cycles=2)
        else:
            remove_phase(project, "BaWO4")
            add_neutral_phase(project, cif, phase_name, 5.0)
            replay(project, cycles=1)
            phase_by_name(project, phase_name).set_refinements({"Cell": True})
            replay(project, cycles=2)
        item = broadening_summary(project)
        item.update({"formula": "BaWO4", "source": label, "mode": "neutral"})
        results["BaWO4"].append(item)

    # The alternate orthorhombic CIF has an incompatible setting on import;
    # the structurally distinct hexagonal polymorph remains a valid competitor.
    path = TRIALS / "source_rank_baco3_hexagonal.gpx"
    project = copy_project(source, path)
    remove_phase(project, CARBONATE)
    add_neutral_phase(project, cod / "9/00/68/9006847.cif", "BaCO3_hex_source", 1.0)
    replay(project, cycles=1)
    phase_by_name(project, "BaCO3_hex_source").set_refinements({"Cell": True})
    replay(project, cycles=2)
    item = broadening_summary(project)
    item.update({"formula": "BaCO3", "source": "hexagonal_9006847", "mode": "neutral"})
    results["BaCO3"].append(item)
    current = copy_project(source, TRIALS / "source_rank_baco3_orth_current.gpx")
    replay(current, cycles=2)
    item = broadening_summary(current)
    item.update({"formula": "BaCO3", "source": "orthorhombic_9010928", "mode": "accepted"})
    results["BaCO3"].append(item)

    write_json(TRIALS / "final_source_ranking.json", results)
    print(json.dumps(results, indent=2))


def finish_source_ranking() -> None:
    """Complete non-WO3 replacements after rejected WO3 trials were stopped."""
    source = CHECKPOINTS / "21_final_geometry.gpx"
    cod = Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif"
    )
    results: dict[str, list[dict]] = {"WO3": [], "BaWO4": [], "BaCO3": []}

    def summarize(project, formula: str, source_label: str, mode: str) -> dict:
        item = broadening_summary(project)
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        item.update(
            {
                "formula": formula,
                "source": source_label,
                "mode": mode,
                "converged": bool(rvals.get("converged", False)),
                "max_shift_over_esd": float(rvals.get("Max shft/sig", float("nan"))),
            }
        )
        return item

    for label in ["monoclinic_2311041", "triclinic_2106293"]:
        for mode in ["neutral", "size", "strain", "combined"]:
            path = TRIALS / f"source_rank_wo3_{label}_{mode}.gpx"
            if path.exists():
                project = copy_project(
                    path, TRIALS / f"source_rank_summary_wo3_{label}_{mode}.gpx"
                )
                results["WO3"].append(summarize(project, "WO3", label, mode))

    # Orthorhombic replacement: scale, then cell, then a combined width model.
    orth_path = TRIALS / "source_rank_finish_wo3_orth_neutral.gpx"
    orth = copy_project(source, orth_path)
    remove_phase(orth, "WO3")
    orth_name = "WO3_source_orthorhombic_2107312"
    add_neutral_phase(orth, cod / "2/10/73/2107312.cif", orth_name, 1.0)
    replay(orth, cycles=1)
    phase_by_name(orth, orth_name).set_refinements({"Cell": True})
    replay(orth, cycles=1)
    results["WO3"].append(summarize(orth, "WO3", "orthorhombic_2107312", "neutral"))
    orth_combined = copy_project(
        orth_path, TRIALS / "source_rank_finish_wo3_orth_combined.gpx"
    )
    set_isotropic_broadening(orth_combined, orth_name, 0.25, True, 2000.0, True)
    replay(orth_combined, cycles=1)
    results["WO3"].append(
        summarize(orth_combined, "WO3", "orthorhombic_2107312", "combined")
    )

    bawo_sources = {
        "SrWO4_topology_adapted": (ROOT / "candidates/ba_wo4_srwo_adapted.cif", True),
        "exact_split_1527204": (cod / "1/52/72/1527204.cif", False),
        "BaMoO4_topology_adapted": (ROOT / "candidates/ba_wo4_bamo_adapted.cif", False),
    }
    for label, (cif, is_current) in bawo_sources.items():
        path = TRIALS / f"source_rank_finish_bawo4_{label}.gpx"
        project = copy_project(source, path)
        phase_name = "BaWO4" if is_current else f"BaWO4_source_{label}"
        if is_current:
            replay(project, cycles=1)
        else:
            remove_phase(project, "BaWO4")
            add_neutral_phase(project, cif, phase_name, 7.0)
            replay(project, cycles=1)
            phase_by_name(project, phase_name).set_refinements({"Cell": True})
            replay(project, cycles=1)
        results["BaWO4"].append(summarize(project, "BaWO4", label, "neutral"))

    current = copy_project(source, TRIALS / "source_rank_finish_baco3_orth.gpx")
    replay(current, cycles=1)
    results["BaCO3"].append(
        summarize(current, "BaCO3", "orthorhombic_9010928", "accepted")
    )
    hexagonal = copy_project(source, TRIALS / "source_rank_finish_baco3_hex.gpx")
    remove_phase(hexagonal, CARBONATE)
    add_neutral_phase(
        hexagonal, cod / "9/00/68/9006847.cif", "BaCO3_source_hexagonal", 1.6
    )
    replay(hexagonal, cycles=1)
    phase_by_name(hexagonal, "BaCO3_source_hexagonal").set_refinements({"Cell": True})
    replay(hexagonal, cycles=1)
    results["BaCO3"].append(
        summarize(hexagonal, "BaCO3", "hexagonal_9006847", "neutral")
    )

    write_json(TRIALS / "final_source_ranking.json", results)
    print(json.dumps(results, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "command",
        choices=[
            "accept-carbonate-cell",
            "carbonate-broadening",
            "accept-carbonate-broadening",
            "inventory-broadening",
            "accept-inventory-broadening",
            "postcarbonate-texture",
            "accept-neutral-texture",
            "postcarbonate-geometry",
            "recover-geometry",
            "accept-geometry",
            "final-watchlist",
            "wo3-coexistence",
            "source-ranking",
            "finish-source-ranking",
        ],
    )
    args = parser.parse_args()
    if args.command == "accept-carbonate-cell":
        accept_carbonate_cell()
    elif args.command == "carbonate-broadening":
        carbonate_broadening_loop()
    elif args.command == "accept-carbonate-broadening":
        accept_carbonate_broadening()
    elif args.command == "inventory-broadening":
        inventory_broadening_loop()
    elif args.command == "accept-inventory-broadening":
        accept_inventory_broadening()
    elif args.command == "postcarbonate-texture":
        postcarbonate_texture_loop()
    elif args.command == "accept-neutral-texture":
        accept_neutral_texture()
    elif args.command == "postcarbonate-geometry":
        postcarbonate_geometry_loop()
    elif args.command == "recover-geometry":
        recover_geometry_results()
    elif args.command == "accept-geometry":
        accept_geometry()
    elif args.command == "final-watchlist":
        final_watchlist()
    elif args.command == "wo3-coexistence":
        wo3_coexistence_loop()
    elif args.command == "source-ranking":
        source_ranking_loop()
    elif args.command == "finish-source-ranking":
        finish_source_ranking()


if __name__ == "__main__":
    main()
