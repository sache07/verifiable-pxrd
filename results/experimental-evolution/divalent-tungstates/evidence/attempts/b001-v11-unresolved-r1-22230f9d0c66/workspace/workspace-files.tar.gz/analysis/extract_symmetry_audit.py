#!/usr/bin/env python3
"""Extract GSAS-II arrays for the symmetry-audit plot."""

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
PATHS = {
    "tri": ROOT / "analysis" / "triclinic_equal" / "broad" / "WO3_uniaxial_010.gpx",
    "mono": ROOT / "analysis" / "aniso_combination" / "WO3_uniaxial_010.gpx",
}
arrays = {}
for label, path in PATHS.items():
    project = G2sc.G2Project(str(path))
    hist = project.histogram(0)
    data = hist.data["data"][1]
    wo_name = next(name for name in hist.data["Reflection Lists"] if name.startswith("WO3"))
    for index, item in enumerate(data):
        arrays[f"{label}_data_{index}"] = np.asarray(item, float)
    arrays[f"{label}_refs"] = hist.data["Reflection Lists"][wo_name]["RefList"]
np.savez_compressed(ROOT / "analysis" / "symmetry_audit.npz", **arrays)
