#!/usr/bin/env python3
"""Prune, full-range replay, freeze, export and validate the selected project."""

from __future__ import annotations

import contextlib
import csv
import json
import math
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2sc

sys.path.insert(0, str(Path(__file__).resolve().parent))
import converge_models as conv  # noqa: E402


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "triclinic_equal" / "broad" / "WO3_uniaxial_010.gpx"
FINAL = ROOT / "final.gpx"
REPLAY = ROOT / "analysis" / "final_replay.gpx"
LOG = ROOT / "analysis" / "freeze_outputs.log"

PHASE_INFO = {
    "SrWO4": {"output": "SrWO4.cif", "formula": "SrWO4", "space_group": "I 41/a"},
    "WO3": {"output": "WO3_triclinic.cif", "formula": "WO3", "space_group": "P -1"},
    "SrCO3": {"output": "SrCO3.cif", "formula": "SrCO3", "space_group": "P n m a"},
}


def phase_by_prefix(project: G2sc.G2Project, prefix: str) -> G2sc.G2Phase:
    return next(phase for phase in project.phases() if phase.name.startswith(prefix))


def set_neutral_size(hap: dict) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 1.0, 1.0]
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Size"][5] = [False] * len(hap["Size"][5])


def set_texture(hap: dict, value: float, axis: list[int]) -> None:
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = float(value)
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)


def set_uniaxial_strain(hap: dict, values: tuple[float, float], axis: list[int]) -> None:
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][:3] = [float(values[0]), float(values[1]), 1.0]
    hap["Mustrain"][2] = [True, True, False]
    hap["Mustrain"][3] = list(axis)
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def set_neutral_strain(hap: dict) -> None:
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 1000.0, 1.0]
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def prune(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    measured, _used = hist.data["Limits"]
    hist.data["Limits"][1] = [float(measured[0]), float(measured[1])]
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "no. coeffs": 14, "refine": True}}
    )

    inst = hist.data["Instrument Parameters"][0]
    for key, value in (("U", 1.0), ("V", 0.0), ("Y", 0.0), ("Z", 0.0)):
        inst[key][1] = value
        inst[key][2] = False
    inst["W"][2] = True
    inst["X"][2] = True
    inst["SH/L"][1] = 0.002
    inst["SH/L"][2] = False
    inst["Zero"][1] = 0.0
    inst["Zero"][2] = False
    inst["Polariz."][2] = True

    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    sample["Shift"][1] = True

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        hap["Scale"][1] = True
        set_neutral_size(hap)

    sr_hap = phase_by_prefix(project, "SrWO4").data["Histograms"][hist.name]
    wo_hap = phase_by_prefix(project, "WO3").data["Histograms"][hist.name]
    co_hap = phase_by_prefix(project, "SrCO3").data["Histograms"][hist.name]
    set_uniaxial_strain(sr_hap, (sr_hap["Mustrain"][1][0], sr_hap["Mustrain"][1][1]), [0, 0, 1])
    set_uniaial_values = (wo_hap["Mustrain"][1][0], wo_hap["Mustrain"][1][1])
    set_uniaxial_strain(wo_hap, set_uniaial_values, [0, 1, 0])
    set_neutral_strain(co_hap)
    set_texture(sr_hap, sr_hap["Pref.Ori."][1], [1, 1, 0])
    set_texture(wo_hap, wo_hap["Pref.Ori."][1], [0, 0, 1])
    set_texture(co_hap, co_hap["Pref.Ori."][1], [0, 0, 1])


def fit_statistics(project: G2sc.G2Project) -> dict:
    rvals = project.histogram(0).data["data"][0]
    cov_rvals = project.data["Covariance"]["data"]["Rvals"]
    return {
        "Rwp_percent": float(rvals["wR"]),
        "Rp_percent": float(rvals["R"]),
        "Rexp_percent": float(rvals["wRmin"]),
        "goodness_of_fit": float(cov_rvals["GOF"]),
        "chi_squared": float(cov_rvals["chisq"]),
        "n_observations": int(cov_rvals["Nobs"]),
        "n_variables": int(cov_rvals["Nvars"]),
        "durbin_watson": float(rvals["Durbin-Watson"]),
    }


def export_outputs(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    raw_fractions = hist.ComputeMassFracs()
    total = sum(float(value[0]) for value in raw_fractions.values())
    phase_rows = []
    for prefix, info in PHASE_INFO.items():
        phase = phase_by_prefix(project, prefix)
        cif_path = ROOT / info["output"]
        phase.export_CIF(str(cif_path))
        fraction, formal_esd = raw_fractions[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        phase_rows.append(
            {
                "name": prefix if prefix != "WO3" else "WO3 (triclinic)",
                "formula": info["formula"],
                "space_group": info["space_group"],
                "cif_path": info["output"],
                "project_path": "final.gpx",
                "weight_fraction": float(fraction) / total,
                "formal_weight_fraction_esd": float(formal_esd) / total,
                "cell": {key: float(value) for key, value in cell.items()},
                "cell_esd": {key: float(value) for key, value in cell_esd.items()},
            }
        )

    arrays = [np.asarray(item, float) for item in hist.data["data"][1]]
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed", "calculated", "background", "difference"])
        for row in zip(arrays[0], arrays[1], arrays[3], arrays[4], arrays[5]):
            writer.writerow([f"{float(value):.10g}" for value in row])

    result = {
        "project_path": "final.gpx",
        "modeled_crystalline_fraction_basis": "normalized to the three modeled crystalline phases",
        "phases": phase_rows,
        "fit_statistics": fit_statistics(project),
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    return result


def main() -> None:
    with LOG.open("w") as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        project = conv.reopen(SOURCE, FINAL)
        prune(project)
        conv.refine(project, 3)
        conv.save(project, FINAL)
        ok, reason = conv.common_valid(project)
        if not ok:
            raise RuntimeError(f"full-range final project invalid: {reason}")

        # Reopen and replay into a separate checkpoint, then freeze that exact replay as final.gpx.
        replay = conv.reopen(FINAL, REPLAY)
        conv.refine(replay, 2)
        conv.save(replay, REPLAY)
        ok, reason = conv.common_valid(replay)
        if not ok:
            raise RuntimeError(f"reopened replay invalid: {reason}")
        replay.save(str(FINAL))

        final = G2sc.G2Project(str(FINAL))
        ok, reason = conv.common_valid(final)
        if not ok:
            raise RuntimeError(f"frozen project invalid after reopen: {reason}")
        result = export_outputs(final)
        data = [np.asarray(item, float) for item in final.histogram(0).data["data"][1]]
        if len(data[0]) != len(data[1]) or not np.allclose(data[1] - data[3], data[5], atol=1e-6):
            raise RuntimeError("fit profile arrays are inconsistent")
        fractions = [row["weight_fraction"] for row in result["phases"]]
        if not math.isclose(sum(fractions), 1.0, rel_tol=0, abs_tol=1e-10):
            raise RuntimeError("weight fractions do not sum to one")
        print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
