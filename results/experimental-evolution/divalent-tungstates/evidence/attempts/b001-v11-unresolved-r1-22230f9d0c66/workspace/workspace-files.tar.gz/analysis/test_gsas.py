#!/usr/bin/env python3
"""Create and lightly refine a one-phase GSAS-II smoke-test project."""

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "analysis" / "pattern.xye"
INST = ROOT / "analysis" / "cu_kalpha.instprm"
CIF = ROOT / "candidates" / "SrWO4_scheelite_from_SrMoO4.cif"
GPX = ROOT / "analysis" / "smoke.gpx"


def write_xye() -> None:
    values = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skip_header=1)
    x = values[:, 0]
    y = values[:, 1]
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(DATA, np.column_stack([x, y, sigma]), fmt="%.8f %.8f %.8f")


def main() -> None:
    write_xye()
    project = G2sc.G2Project(newgpx=str(GPX))
    histogram = project.add_powder_histogram(
        str(DATA), str(INST), fmthint="xye"
    )
    phase = project.add_phase(
        str(CIF), phasename="SrWO4", histograms=[histogram], fmthint="CIF"
    )
    histogram.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 8,
            "refine": True,
        },
    })
    histogram.data["Sample Parameters"]["Scale"] = [1.0, False]
    histogram.data["Sample Parameters"]["Shift"] = [1000.0, False]
    phase.HAPvalue("Scale", 0.05)
    phase.set_HAP_refinements({
        "Scale": True,
        "Size": {"type": "isotropic", "value": 10.0, "refine": False},
        "Mustrain": {"type": "isotropic", "refine": False},
    })
    hap = phase.data["Histograms"][histogram.name]
    hap["Mustrain"][1][0] = 0.0
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["max cyc"] = 8
    project.do_refinements([{}])
    phase.set_refinements({"Cell": True})
    histogram.set_refinements({"Sample Parameters": ["Shift"]})
    project.do_refinements([{}])
    histogram.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.do_refinements([{}])
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": 10.0, "refine": True},
    })
    project.do_refinements([{}])
    project.save()
    print("histogram", histogram.name)
    print("residuals", histogram.residuals)
    print("cell", phase.get_cell())
    print("scale", phase.HAPvalue("Scale"))
    print("instrument", histogram.data["Instrument Parameters"][0])
    print("sample", histogram.data["Sample Parameters"])
    print("HAP", hap)


if __name__ == "__main__":
    main()
