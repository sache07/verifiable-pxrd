#!/usr/bin/env python3
"""Plot local profile windows that distinguish monoclinic and triclinic WO3."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "analysis" / "symmetry_audit.png"
cache = np.load(ROOT / "analysis" / "symmetry_audit.npz")
tri = [cache[f"tri_data_{index}"] for index in range(6)]
mono = [cache[f"mono_data_{index}"] for index in range(6)]
tri_refs = cache["tri_refs"]
mono_refs = cache["mono_refs"]
x, y, _, yc_tri, bkg_tri, _ = tri
yc_mono = mono[3]

windows = [
    (22.15, 24.15),
    (32.35, 33.90),
    (40.55, 41.60),
    (46.30, 47.05),
    (49.00, 50.45),
    (54.70, 55.85),
    (75.45, 76.50),
    (85.20, 87.20),
]
fig, axes = plt.subplots(4, 2, figsize=(13, 13), constrained_layout=True)
for ax, (lo, hi) in zip(axes.flat, windows):
    mask = (x >= lo) & (x <= hi)
    ax.plot(x[mask], y[mask], "k.", ms=2.3, label="observed")
    ax.plot(x[mask], yc_tri[mask], color="#0072B2", lw=1.25, label="triclinic")
    ax.plot(x[mask], yc_mono[mask], color="#D55E00", lw=1.0, label="monoclinic")
    base = float(np.min(bkg_tri[mask]))
    span = float(np.max(y[mask]) - np.min(y[mask]))
    for refs, color, offset in ((tri_refs, "#0072B2", 0.02), (mono_refs, "#D55E00", 0.07)):
        selected = refs[(refs[:, 5] >= lo) & (refs[:, 5] <= hi)]
        if selected.size:
            strength = selected[:, 9]
            cutoff = max(float(np.max(strength)) * 0.08, 500.0)
            for pos in selected[strength >= cutoff, 5]:
                ax.vlines(pos, base + offset * span, base + (offset + 0.035) * span, color=color, lw=0.7)
    ax.set_xlim(lo, hi)
    ax.set_title(f"{lo:.2f}–{hi:.2f}° 2θ")
    ax.set_xlabel("2θ (deg)")
    ax.set_ylabel("counts")
axes.flat[0].legend(frameon=False, fontsize=9)
fig.savefig(OUT, dpi=180)
print(OUT)
