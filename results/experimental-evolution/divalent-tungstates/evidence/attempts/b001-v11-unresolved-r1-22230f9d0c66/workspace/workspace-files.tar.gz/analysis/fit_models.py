#!/usr/bin/env python3
"""Run equal, reversible GSAS-II baseline fits for candidate phase inventories.

The script intentionally keeps phase-specific size, strain and preferred
orientation inactive. Shared profile alternatives are each started from the
same post-cell checkpoint; negative or collapsed terms reject a branch.
"""

from __future__ import annotations

import argparse
import contextlib
import json
import math
import os
from pathlib import Path
import shutil
import sys
from typing import Any

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
RESOURCE = Path(
    "<RUN>/"
    "resources/b001-c03/cif"
)
TRIALS = ROOT / "analysis" / "trials"
DATA = ROOT / "analysis" / "pattern.xye"
INST = ROOT / "analysis" / "cu_kalpha.instprm"

PHASES: dict[str, dict[str, Any]] = {
    "SrWO4": {
        "path": ROOT / "candidates" / "SrWO4_scheelite_from_SrMoO4.cif",
        "scale": 5.0,
    },
    "SrWO4_CaParent": {
        "path": ROOT / "candidates" / "SrWO4_scheelite_from_CaWO4.cif",
        "scale": 5.0,
    },
    "WO3_tet130": {
        "path": RESOURCE / "1/52/15/1521532.cif",
        "scale": 1.0,
    },
    "WO3_tet129": {
        "path": RESOURCE / "1/52/15/1521533.cif",
        "scale": 1.0,
    },
    "WO3_mono_review": {
        "path": RESOURCE / "1/52/89/1528915.cif",
        "scale": 1.0,
    },
    "WO3_mono": {
        "path": ROOT / "candidates" / "WO3_monoclinic_cleaned_1563541.cif",
        "scale": 1.0,
    },
    "WO3_mono_alt": {
        "path": RESOURCE / "2/31/10/2311041.cif",
        "scale": 1.0,
    },
    "WO3_triclinic": {
        "path": RESOURCE / "2/10/62/2106293.cif",
        "scale": 1.0,
    },
    "WO3_Pnma": {
        "path": RESOURCE / "2/10/73/2107312.cif",
        "scale": 1.0,
    },
    "WO3_hex": {
        "path": RESOURCE / "1/00/40/1004057.cif",
        "scale": 1.0,
    },
    "SrCO3_Pnma": {
        "path": RESOURCE / "9/00/81/9008198.cif",
        "scale": 1.0,
    },
    "SrCO3_R3m_review": {
        "path": RESOURCE / "1/53/91/1539128.cif",
        "scale": 1.0,
    },
    "Sr3W2O9": {
        "path": RESOURCE / "2/31/19/2311977.cif",
        "scale": 1.0,
    },
}


MODELS: dict[str, list[str]] = {
    "main": ["SrWO4"],
    "main_tet130": ["SrWO4", "WO3_tet130"],
    "main_tet129": ["SrWO4", "WO3_tet129"],
    "main_mono_review": ["SrWO4", "WO3_mono_review"],
    "main_mono": ["SrWO4", "WO3_mono"],
    "main_mono_alt": ["SrWO4", "WO3_mono_alt"],
    "main_triclinic": ["SrWO4", "WO3_triclinic"],
    "main_pnma_wo3": ["SrWO4", "WO3_Pnma"],
    "main_hex": ["SrWO4", "WO3_hex"],
    "main_carbonate": ["SrWO4", "SrCO3_Pnma"],
    "main_carbonate_r3m": ["SrWO4", "SrCO3_R3m_review"],
    "main_sr3w2o9": ["SrWO4", "Sr3W2O9"],
    "main_tet130_carbonate": ["SrWO4", "WO3_tet130", "SrCO3_Pnma"],
    "main_mono_carbonate": ["SrWO4", "WO3_mono", "SrCO3_Pnma"],
    "main_mono_review_carbonate": ["SrWO4", "WO3_mono_review", "SrCO3_Pnma"],
    "main_mono_alt_carbonate": ["SrWO4", "WO3_mono_alt", "SrCO3_Pnma"],
    "main_triclinic_carbonate": ["SrWO4", "WO3_triclinic", "SrCO3_Pnma"],
    "main_pnma_carbonate": ["SrWO4", "WO3_Pnma", "SrCO3_Pnma"],
    "main_tet129_carbonate": ["SrWO4", "WO3_tet129", "SrCO3_Pnma"],
    "caparent_mono_alt_carbonate": ["SrWO4_CaParent", "WO3_mono_alt", "SrCO3_Pnma"],
    "caparent_triclinic_carbonate": ["SrWO4_CaParent", "WO3_triclinic", "SrCO3_Pnma"],
}


def write_xye() -> None:
    values = np.genfromtxt(
        ROOT / "inputs" / "pattern.csv", delimiter=",", skip_header=1
    )
    sigma = np.sqrt(np.maximum(values[:, 1], 1.0))
    np.savetxt(
        DATA,
        np.column_stack([values[:, 0], values[:, 1], sigma]),
        fmt="%.8f %.8f %.8f",
    )


def neutralize(phase: G2sc.G2Phase, histogram: G2sc.G2PwdrData, scale: float) -> None:
    phase.HAPvalue("Scale", scale)
    phase.set_HAP_refinements(
        {
            "Scale": True,
            "Size": {"type": "isotropic", "value": 10.0, "refine": False},
            "Mustrain": {"type": "isotropic", "refine": False},
        }
    )
    hap = phase.data["Histograms"][histogram.name]
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]


def make_project(label: str, names: list[str]) -> tuple[G2sc.G2Project, Path]:
    target = TRIALS / f"{label}.gpx"
    project = G2sc.G2Project(newgpx=str(target))
    histogram = project.add_powder_histogram(
        str(DATA), str(INST), fmthint="xye"
    )
    histogram.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "refine": True,
            },
        }
    )
    sample = histogram.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [1000.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    for name in names:
        spec = PHASES[name]
        phase = project.add_phase(
            str(spec["path"]),
            phasename=name,
            histograms=[histogram],
            fmthint="CIF",
        )
        neutralize(phase, histogram, spec["scale"])
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 0.0001
    return project, target


def rwp(project: G2sc.G2Project) -> float:
    value = project.histogram(0).get_wR()
    return float(value if value is not None else math.inf)


def phase_scales(project: G2sc.G2Project) -> dict[str, float]:
    return {p.name: float(p.HAPvalue("Scale")) for p in project.phases()}


def profile(project: G2sc.G2Project) -> dict[str, float]:
    inst = project.histogram(0).data["Instrument Parameters"][0]
    return {key: float(inst[key][1]) for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")}


def cells(project: G2sc.G2Project) -> dict[str, dict[str, float]]:
    return {p.name: {k: float(v) for k, v in p.get_cell().items()} for p in project.phases()}


def snapshot(project: G2sc.G2Project, path: Path) -> None:
    project.save(str(path))


def reopen(path: Path, output: Path) -> G2sc.G2Project:
    return G2sc.G2Project(str(path), newgpx=str(output))


def refine(project: G2sc.G2Project) -> None:
    project.do_refinements([{}], makeBack=False)


def valid_common(project: G2sc.G2Project, varied: tuple[str, ...]) -> tuple[bool, str]:
    p = profile(project)
    for key in varied:
        if not math.isfinite(p[key]) or p[key] < 0:
            return False, f"{key}={p[key]:.8g} is negative/nonfinite"
        if p[key] < 1e-7:
            return False, f"{key}={p[key]:.8g} collapsed at zero"
    for name, value in phase_scales(project).items():
        if not math.isfinite(value) or value <= 0:
            return False, f"{name} scale={value:.8g} is nonpositive/nonfinite"
    return True, "ok"


def set_profile_flags(project: G2sc.G2Project, varied: tuple[str, ...]) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    starts = {"U": 1.0, "W": 25.0, "X": 0.25}
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        inst[key][2] = False
    inst["V"][1] = 0.0
    inst["Y"][1] = 0.0
    inst["Z"][1] = 0.0
    inst["SH/L"][1] = 0.002
    for key in ("U", "W", "X"):
        inst[key][1] = starts[key]
    hist.set_refinements({"Instrument Parameters": list(varied)})


def run_model(label: str, names: list[str]) -> dict[str, Any]:
    model_dir = TRIALS / label
    model_dir.mkdir(parents=True, exist_ok=True)
    log_path = model_dir / "run.log"
    with log_path.open("w") as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        project, target = make_project(label, names)
        hist = project.histogram(0)

        # Smooth background and positive phase scales; all phase terms neutral.
        refine(project)
        scale_checkpoint = model_dir / "01_scales.gpx"
        snapshot(project, scale_checkpoint)

        # Refine cells with exactly one physically appropriate angular correction.
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        refine(project)
        refine(project)
        cell_checkpoint = model_dir / "02_cells_shift.gpx"
        snapshot(project, cell_checkpoint)

        # Compare common nonnegative profile terms from the same checkpoint.
        common_trials: list[dict[str, Any]] = []
        for tag, varied in [
            ("neutral", ()),
            ("W", ("W",)),
            ("UW", ("U", "W")),
            ("WX", ("W", "X")),
            ("UWX", ("U", "W", "X")),
        ]:
            trial_path = model_dir / f"profile_{tag}.gpx"
            trial = reopen(cell_checkpoint, trial_path)
            set_profile_flags(trial, varied)
            if varied:
                refine(trial)
                refine(trial)
            ok, reason = valid_common(trial, varied)
            row = {
                "tag": tag,
                "varied": list(varied),
                "valid": bool(ok),
                "reason": reason,
                "rwp": rwp(trial),
                "profile": profile(trial),
                "scales": phase_scales(trial),
                "path": str(trial_path),
            }
            common_trials.append(row)
            snapshot(trial, trial_path)

        valid_trials = [row for row in common_trials if row["valid"]]
        if not valid_trials:
            raise RuntimeError(f"no valid common-profile branch for {label}")
        winner = min(valid_trials, key=lambda row: row["rwp"])
        project = reopen(Path(winner["path"]), target)
        # Replay the full range once from the winning profile branch.
        refine(project)
        snapshot(project, target)

        hist = project.histogram(0)
        residuals = {k: float(v) if isinstance(v, (float, int, np.number)) else v
                     for k, v in hist.residuals.items()}
        result: dict[str, Any] = {
            "label": label,
            "phases": names,
            "rwp": rwp(project),
            "gof_from_rwp": float(rwp(project) / hist.residuals["wRmin"]),
            "residuals": residuals,
            "scales": phase_scales(project),
            "cells": cells(project),
            "shift_um": float(hist.data["Sample Parameters"]["Shift"][0]),
            "profile": profile(project),
            "profile_winner": winner["tag"],
            "profile_trials": common_trials,
            "project": str(target),
            "log": str(log_path),
        }
        try:
            result["mass_fractions"] = {
                key: [float(value[0]), float(value[1])]
                for key, value in hist.ComputeMassFracs().items()
            }
        except Exception as exc:
            result["mass_fraction_error"] = repr(exc)
        return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("models", nargs="*", help="model labels; default is all")
    args = parser.parse_args()
    labels = args.models or list(MODELS)
    unknown = sorted(set(labels) - set(MODELS))
    if unknown:
        parser.error(f"unknown models: {', '.join(unknown)}")
    TRIALS.mkdir(parents=True, exist_ok=True)
    write_xye()
    rows = []
    for label in labels:
        try:
            row = run_model(label, MODELS[label])
            status = "ok"
        except Exception as exc:
            row = {"label": label, "phases": MODELS[label], "error": repr(exc)}
            status = "error"
        rows.append(row)
        print(
            json.dumps(
                {
                    "label": label,
                    "status": status,
                    "rwp": row.get("rwp"),
                    "winner": row.get("profile_winner"),
                    "scales": row.get("scales"),
                    "mass_fractions": row.get("mass_fractions"),
                    "error": row.get("error"),
                },
                sort_keys=True,
            ),
            flush=True,
        )
    summary = TRIALS / "summary.json"
    existing: dict[str, Any] = {}
    if summary.exists():
        try:
            existing = {row["label"]: row for row in json.loads(summary.read_text())}
        except Exception:
            existing = {}
    existing.update({row["label"]: row for row in rows})
    summary.write_text(json.dumps(list(existing.values()), indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
