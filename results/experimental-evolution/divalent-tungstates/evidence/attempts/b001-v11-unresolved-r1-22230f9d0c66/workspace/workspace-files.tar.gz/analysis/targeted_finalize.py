#!/usr/bin/env python3
"""Targeted replay/pruning challenges from the last clean finalist checkpoint."""

from __future__ import annotations

import argparse
import contextlib
import json
from pathlib import Path
import sys
from typing import Callable

from GSASII import GSASIIscriptable as G2sc

sys.path.insert(0, str(Path(__file__).resolve().parent))
import converge_models as conv  # noqa: E402


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "converge" / "mono" / "p3_SrWO4_CaParent_strain.gpx"
OUT = ROOT / "analysis" / "targeted"


def phase_kind(project: G2sc.G2Project, prefix: str) -> G2sc.G2Phase:
    return next(phase for phase in project.phases() if phase.name.startswith(prefix))


def hap(project: G2sc.G2Project, prefix: str):
    phase = phase_kind(project, prefix)
    hist = project.histogram(0)
    return phase, phase.data["Histograms"][hist.name]


def no_texture(prefix: str) -> Callable[[G2sc.G2Project], None]:
    def mutate(project: G2sc.G2Project) -> None:
        _, data = hap(project, prefix)
        data["Pref.Ori."][1] = 1.0
        data["Pref.Ori."][2] = False
    return mutate


def texture_axis(prefix: str, axis: list[int]) -> Callable[[G2sc.G2Project], None]:
    def mutate(project: G2sc.G2Project) -> None:
        _, data = hap(project, prefix)
        data["Pref.Ori."][1] = min(max(float(data["Pref.Ori."][1]), 0.5), 1.5)
        data["Pref.Ori."][2] = True
        data["Pref.Ori."][3] = list(axis)
    return mutate


def no_strain(prefix: str) -> Callable[[G2sc.G2Project], None]:
    def mutate(project: G2sc.G2Project) -> None:
        _, data = hap(project, prefix)
        data["Mustrain"][0] = "isotropic"
        data["Mustrain"][1][0] = 0.0
        data["Mustrain"][2] = [False] * len(data["Mustrain"][2])
        data["Mustrain"][5] = [False] * len(data["Mustrain"][5])
    return mutate


def remove_phase(prefix: str) -> Callable[[G2sc.G2Project], None]:
    def mutate(project: G2sc.G2Project) -> None:
        phase, data = hap(project, prefix)
        data["Use"] = False
        data["Scale"][1] = False
    return mutate


def uniaxial_strain(prefix: str, axis: list[int]) -> Callable[[G2sc.G2Project], None]:
    def mutate(project: G2sc.G2Project) -> None:
        _, data = hap(project, prefix)
        strain = data["Mustrain"]
        value = max(float(strain[1][0]), 1.0)
        strain[0] = "uniaxial"
        strain[1][0] = value
        strain[1][1] = value
        strain[2] = [True, True, False]
        strain[3] = list(axis)
        strain[5] = [False] * len(strain[5])
    return mutate


def broadening_mode(prefix: str, mode: str) -> Callable[[G2sc.G2Project], None]:
    def mutate(project: G2sc.G2Project) -> None:
        phase = phase_kind(project, prefix)
        conv.set_broadening_mode(phase, project.histogram(0), mode)
    return mutate


def no_roughness(project: G2sc.G2Project) -> None:
    sample = project.histogram(0).data["Sample Parameters"]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]


def roughness_b(project: G2sc.G2Project) -> None:
    sample = project.histogram(0).data["Sample Parameters"]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.03, True]


def fixed_polarization(project: G2sc.G2Project) -> None:
    pol = project.histogram(0).data["Instrument Parameters"][0]["Polariz."]
    pol[1] = 0.5
    pol[2] = False


def no_shared(project: G2sc.G2Project) -> None:
    no_roughness(project)
    fixed_polarization(project)


def background10(project: G2sc.G2Project) -> None:
    project.histogram(0).set_refinements(
        {"Background": {"type": "chebyschev-1", "no. coeffs": 10, "refine": True}}
    )


def background12(project: G2sc.G2Project) -> None:
    project.histogram(0).set_refinements(
        {"Background": {"type": "chebyschev-1", "no. coeffs": 12, "refine": True}}
    )


def no_shift(project: G2sc.G2Project) -> None:
    project.histogram(0).data["Sample Parameters"]["Shift"] = [0.0, False]


def profile_uw(project: G2sc.G2Project) -> None:
    inst = project.histogram(0).data["Instrument Parameters"][0]
    inst["U"][2] = True
    inst["W"][2] = True
    inst["X"][1] = 0.0
    inst["X"][2] = False


def profile_uwx(project: G2sc.G2Project) -> None:
    inst = project.histogram(0).data["Instrument Parameters"][0]
    for key in ("U", "W", "X"):
        inst[key][2] = True


def no_x(project: G2sc.G2Project) -> None:
    inst = project.histogram(0).data["Instrument Parameters"][0]
    inst["X"][1] = 0.0
    inst["X"][2] = False
    inst["W"][2] = True


def no_sr_size(project: G2sc.G2Project) -> None:
    # Explicit complementary-size challenge with size fixed at neutral boundary.
    _, data = hap(project, "SrWO4")
    data["Size"][0] = "isotropic"
    data["Size"][1][0] = 10.0
    data["Size"][2] = [False] * len(data["Size"][2])
    data["Size"][5] = [False] * len(data["Size"][5])


TRIALS: list[tuple[str, Callable[[G2sc.G2Project], None]]] = [
    ("replay", lambda project: None),
    ("remove_WO3", remove_phase("WO3")),
    ("remove_SrCO3", remove_phase("SrCO3")),
    ("remove_SrWO4", remove_phase("SrWO4")),
    ("no_texture_SrWO4", no_texture("SrWO4")),
    ("no_texture_WO3", no_texture("WO3")),
    ("no_texture_SrCO3", no_texture("SrCO3")),
    ("no_strain_SrWO4", no_strain("SrWO4")),
    ("no_strain_WO3", no_strain("WO3")),
    ("no_roughness", no_roughness),
    ("roughness_B", roughness_b),
    ("fixed_polarization", fixed_polarization),
    ("no_shared_intensity", no_shared),
    ("background10", background10),
    ("background12", background12),
    ("no_X", no_x),
    ("profile_UW", profile_uw),
    ("profile_UWX", profile_uwx),
    ("no_shift", no_shift),
    ("texture_SrWO4_001", texture_axis("SrWO4", [0, 0, 1])),
    ("texture_SrWO4_100", texture_axis("SrWO4", [1, 0, 0])),
    ("texture_SrWO4_110", texture_axis("SrWO4", [1, 1, 0])),
    ("texture_WO3_001", texture_axis("WO3", [0, 0, 1])),
    ("texture_WO3_010", texture_axis("WO3", [0, 1, 0])),
    ("texture_WO3_100", texture_axis("WO3", [1, 0, 0])),
    ("texture_WO3_111", texture_axis("WO3", [1, 1, 1])),
    ("texture_WO3_110", texture_axis("WO3", [1, 1, 0])),
    ("texture_WO3_101", texture_axis("WO3", [1, 0, 1])),
    ("texture_WO3_011", texture_axis("WO3", [0, 1, 1])),
    ("texture_SrCO3_001", texture_axis("SrCO3", [0, 0, 1])),
    ("texture_SrCO3_010", texture_axis("SrCO3", [0, 1, 0])),
    ("texture_SrCO3_100", texture_axis("SrCO3", [1, 0, 0])),
    ("texture_SrCO3_101", texture_axis("SrCO3", [1, 0, 1])),
    ("SrWO4_neutral", broadening_mode("SrWO4", "neutral")),
    ("SrWO4_size", broadening_mode("SrWO4", "size")),
    ("SrWO4_strain", broadening_mode("SrWO4", "strain")),
    ("SrWO4_combined", broadening_mode("SrWO4", "combined")),
    ("WO3_neutral", broadening_mode("WO3", "neutral")),
    ("WO3_size", broadening_mode("WO3", "size")),
    ("WO3_strain", broadening_mode("WO3", "strain")),
    ("WO3_combined", broadening_mode("WO3", "combined")),
    ("SrCO3_neutral", broadening_mode("SrCO3", "neutral")),
    ("SrCO3_size", broadening_mode("SrCO3", "size")),
    ("SrCO3_strain", broadening_mode("SrCO3", "strain")),
    ("SrCO3_combined", broadening_mode("SrCO3", "combined")),
    ("SrWO4_uniaxial_001", uniaxial_strain("SrWO4", [0, 0, 1])),
    ("SrWO4_uniaxial_110", uniaxial_strain("SrWO4", [1, 1, 0])),
    ("SrWO4_uniaxial_100", uniaxial_strain("SrWO4", [1, 0, 0])),
    ("WO3_uniaxial_001", uniaxial_strain("WO3", [0, 0, 1])),
    ("WO3_uniaxial_010", uniaxial_strain("WO3", [0, 1, 0])),
    ("WO3_uniaxial_100", uniaxial_strain("WO3", [1, 0, 0])),
    ("WO3_uniaxial_110", uniaxial_strain("WO3", [1, 1, 0])),
    ("WO3_uniaxial_101", uniaxial_strain("WO3", [1, 0, 1])),
    ("WO3_uniaxial_011", uniaxial_strain("WO3", [0, 1, 1])),
    ("WO3_uniaxial_111", uniaxial_strain("WO3", [1, 1, 1])),
]


def run(
    tags: set[str] | None = None,
    source: Path = SOURCE,
    outdir: Path = OUT,
) -> list[dict]:
    outdir.mkdir(parents=True, exist_ok=True)
    rows = []
    logpath = outdir / "targeted.log"
    with logpath.open("w") as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        for tag, mutation in TRIALS:
            if tags is not None and tag not in tags:
                continue
            path = outdir / f"{tag}.gpx"
            project = conv.reopen(source, path)
            mutation(project)
            conv.refine(project, 2)
            conv.save(project, path)
            valid, reason = conv.common_valid(project)
            hist = project.histogram(0)
            use = {
                phase.name: bool(phase.data["Histograms"][hist.name]["Use"])
                for phase in project.phases()
            }
            row = conv.branch_row(project, path, tag=tag)
            row["valid"] = valid
            row["reason"] = reason
            row["phase_use"] = use
            rows.append(row)
    (outdir / "summary.json").write_text(json.dumps(rows, indent=2, sort_keys=True) + "\n")
    return rows


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("tags", nargs="*")
    parser.add_argument("--source", type=Path, default=SOURCE)
    parser.add_argument("--out", type=Path, default=OUT)
    args = parser.parse_args()
    requested = set(args.tags) or None
    for row in run(requested, args.source, args.out):
        print(json.dumps({
            "tag": row["tag"],
            "valid": row["valid"],
            "reason": row["reason"],
            "rwp": row["rwp"],
            "scales": row["scales"],
        }, sort_keys=True), flush=True)
