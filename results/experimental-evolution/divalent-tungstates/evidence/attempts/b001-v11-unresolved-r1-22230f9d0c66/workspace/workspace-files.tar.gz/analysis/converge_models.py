#!/usr/bin/env python3
"""Reversible profile/broadening/intensity convergence for finalist models."""

from __future__ import annotations

import argparse
import contextlib
import json
import math
from pathlib import Path
from typing import Any

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
OUTROOT = ROOT / "analysis" / "converge"
BASES = {
    "mono": ROOT / "analysis" / "trials" / "caparent_mono_alt_carbonate.gpx",
    "triclinic": ROOT / "analysis" / "trials" / "caparent_triclinic_carbonate.gpx",
}


def rwp(project: G2sc.G2Project) -> float:
    value = project.histogram(0).get_wR()
    return float(value if value is not None else math.inf)


def reopen(source: Path, output: Path) -> G2sc.G2Project:
    return G2sc.G2Project(str(source), newgpx=str(output))


def save(project: G2sc.G2Project, path: Path) -> None:
    project.save(str(path))


def refine(project: G2sc.G2Project, repeat: int = 2) -> None:
    for _ in range(repeat):
        project.do_refinements([{}], makeBack=False)


def profile(project: G2sc.G2Project) -> dict[str, float]:
    inst = project.histogram(0).data["Instrument Parameters"][0]
    return {key: float(inst[key][1]) for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")}


def scales(project: G2sc.G2Project) -> dict[str, float]:
    return {phase.name: float(phase.HAPvalue("Scale")) for phase in project.phases()}


def broadening(project: G2sc.G2Project) -> dict[str, dict[str, Any]]:
    hist = project.histogram(0)
    out: dict[str, dict[str, Any]] = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out[phase.name] = {
            "size_type": hap["Size"][0],
            "size_values": [float(v) for v in hap["Size"][1]],
            "size_flags": [bool(v) for v in hap["Size"][2]],
            "size_axis": list(hap["Size"][3]),
            "strain_type": hap["Mustrain"][0],
            "strain_values": [float(v) for v in hap["Mustrain"][1]],
            "strain_flags": [bool(v) for v in hap["Mustrain"][2]],
            "strain_axis": list(hap["Mustrain"][3]),
            "MD": float(hap["Pref.Ori."][1]),
            "MD_axis": list(hap["Pref.Ori."][3]),
            "MD_refine": bool(hap["Pref.Ori."][2]),
        }
    return out


def covariance_info(project: G2sc.G2Project) -> dict[str, Any]:
    data = project.data["Covariance"]["data"]
    names = list(data.get("varyList", []))
    sig = np.asarray(data.get("sig", []), float)
    cov = np.asarray(data.get("covMatrix", []), float)
    pairs: list[dict[str, Any]] = []
    if cov.ndim == 2 and len(names) == cov.shape[0]:
        denom = np.sqrt(np.maximum(np.diag(cov), 0))
        with np.errstate(divide="ignore", invalid="ignore"):
            corr = cov / np.outer(denom, denom)
        for i in range(len(names)):
            for j in range(i):
                value = float(corr[i, j])
                if math.isfinite(value) and abs(value) >= 0.90:
                    pairs.append({"left": names[j], "right": names[i], "corr": value})
    rvals = data.get("Rvals", {})
    return {
        "vary": names,
        "sig": {name: float(sig[i]) for i, name in enumerate(names) if i < len(sig)},
        "high_correlations": sorted(pairs, key=lambda row: -abs(row["corr"]))[:30],
        "converged": bool(rvals.get("converged", False)),
        "svd_zero": int(rvals.get("SVD0", 0)),
        "max_shift_over_esd": float(rvals.get("Max shft/sig", math.inf)),
    }


def common_valid(project: G2sc.G2Project) -> tuple[bool, str]:
    if not math.isfinite(rwp(project)):
        return False, "nonfinite Rwp"
    prof = profile(project)
    for key in ("U", "W", "X"):
        if not math.isfinite(prof[key]) or prof[key] < 0:
            return False, f"{key}={prof[key]:.7g} negative/nonfinite"
    for name, value in scales(project).items():
        if not math.isfinite(value) or value <= 1e-10:
            return False, f"{name} scale={value:.7g} collapsed/nonpositive"
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        size = hap["Size"]
        strain = hap["Mustrain"]
        if any(size[2]) or any(size[5]):
            active_values = [size[1][i] for i, flag in enumerate(size[2][:2]) if flag]
            active_values += [value for value, flag in zip(size[4], size[5]) if flag]
            if any((not math.isfinite(float(v))) or float(v) <= 0.005 or float(v) >= 9.999 for v in active_values):
                return False, f"{phase.name} active size is bound/collapsed: {active_values}"
        if any(strain[2]) or any(strain[5]):
            active_values = [strain[1][i] for i, flag in enumerate(strain[2][:2]) if flag]
            active_values += [value for value, flag in zip(strain[4], strain[5]) if flag]
            if any((not math.isfinite(float(v))) or float(v) <= 1e-5 or float(v) >= 1e5 for v in active_values):
                return False, f"{phase.name} active strain is bound/collapsed: {active_values}"
        po = hap["Pref.Ori."]
        if po[2] and (not math.isfinite(float(po[1])) or not (0.2 < float(po[1]) < 5.0)):
            return False, f"{phase.name} active March ratio is nonphysical: {po[1]}"
        cell = phase.get_cell()
        if any(not math.isfinite(float(value)) or float(value) <= 0 for value in cell.values()):
            return False, f"{phase.name} has nonfinite/nonpositive cell"
    sample = hist.data["Sample Parameters"]
    if sample["SurfRoughA"][1] and not (0 <= float(sample["SurfRoughA"][0]) <= 1):
        return False, f"roughness A={sample['SurfRoughA'][0]} outside [0,1]"
    if sample["SurfRoughB"][1] and not (1e-8 < float(sample["SurfRoughB"][0]) < 10):
        return False, f"roughness B={sample['SurfRoughB'][0]} bound/nonphysical"
    inst = hist.data["Instrument Parameters"][0]
    if inst["Polariz."][2] and not (0.02 < float(inst["Polariz."][1]) < 0.98):
        return False, f"polarization={inst['Polariz.'][1]} bound/nonphysical"
    info = covariance_info(project)
    if not info["converged"] or info["svd_zero"]:
        return False, f"refinement convergence={info['converged']} SVD0={info['svd_zero']}"
    if not math.isfinite(info["max_shift_over_esd"]) or info["max_shift_over_esd"] > 10:
        return False, f"max shift/esd={info['max_shift_over_esd']} is unstable"
    if any(abs(row["corr"]) >= 0.995 for row in info["high_correlations"]):
        worst = next(row for row in info["high_correlations"] if abs(row["corr"]) >= 0.995)
        return False, f"correlation {worst['left']} / {worst['right']} = {worst['corr']:.5f}"
    return True, "ok"


def set_neutral_broadening(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][1][1] = 1.0
    hap["Size"][1][2] = 1.0
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 1000.0
    hap["Mustrain"][1][2] = 1.0
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def set_broadening_mode(
    phase: G2sc.G2Phase, hist: G2sc.G2PwdrData, mode: str
) -> None:
    set_neutral_broadening(phase, hist)
    if mode in ("size", "combined"):
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 10.0, "refine": True}},
            [hist],
        )
    if mode in ("strain", "combined"):
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}},
            [hist],
        )


def broadening_valid(
    project: G2sc.G2Project, phase_name: str, mode: str
) -> tuple[bool, str]:
    ok, reason = common_valid(project)
    if not ok:
        return ok, reason
    values = broadening(project)[phase_name]
    if mode in ("size", "combined"):
        size = values["size_values"][0]
        if not math.isfinite(size) or size <= 0.005 or size >= 1e4:
            return False, f"size={size:.7g} collapsed/nonphysical"
    if mode in ("strain", "combined"):
        strain = values["strain_values"][0]
        if not math.isfinite(strain) or strain <= 1e-5 or strain >= 1e5:
            return False, f"strain={strain:.7g} collapsed/nonphysical"
    return True, "ok"


def branch_row(project: G2sc.G2Project, path: Path, **extra: Any) -> dict[str, Any]:
    ok, reason = common_valid(project)
    row: dict[str, Any] = {
        "path": str(path),
        "rwp": rwp(project),
        "valid": ok,
        "reason": reason,
        "profile": profile(project),
        "scales": scales(project),
        "broadening": broadening(project),
        "covariance": covariance_info(project),
    }
    row.update(extra)
    return row


def select_with_threshold(rows: list[dict[str, Any]], neutral_tag: str, threshold: float) -> dict[str, Any]:
    neutral = next(row for row in rows if row["tag"] == neutral_tag)
    valid = [row for row in rows if row["valid"]]
    winner = min(valid, key=lambda row: row["rwp"])
    if winner["tag"] != neutral_tag and neutral["rwp"] - winner["rwp"] < threshold:
        return neutral
    # Prefer a simpler valid model if its Rwp is indistinguishable at this threshold.
    complexity = {
        "neutral": 0,
        "size": 1,
        "strain": 1,
        "combined": 2,
        "polar": 1,
        "roughB": 1,
        "roughAB": 2,
        "polar_roughB": 2,
    }
    near = [row for row in valid if row["rwp"] <= winner["rwp"] + threshold]
    winner = min(near, key=lambda row: (complexity.get(row["tag"], 1), row["rwp"]))
    return winner


def broadening_pass(
    checkpoint: Path, outdir: Path, pass_index: int, history: list[dict[str, Any]]
) -> Path:
    current = checkpoint
    probe = G2sc.G2Project(str(current))
    phase_names = [phase.name for phase in probe.phases()]
    for phase_name in phase_names:
        rows = []
        for mode in ("neutral", "size", "strain", "combined"):
            tag = f"p{pass_index}_{phase_name}_{mode}"
            path = outdir / f"{tag}.gpx"
            project = reopen(current, path)
            phase = project.phase(phase_name)
            hist = project.histogram(0)
            set_broadening_mode(phase, hist, mode)
            refine(project, 2)
            ok, reason = broadening_valid(project, phase_name, mode)
            save(project, path)
            row = branch_row(
                project, path, tag=mode, phase=phase_name, pass_index=pass_index
            )
            row["valid"] = ok
            row["reason"] = reason
            rows.append(row)
        winner = select_with_threshold(rows, "neutral", 0.003)
        history.append(
            {
                "stage": "broadening",
                "pass": pass_index,
                "phase": phase_name,
                "trials": rows,
                "winner": winner["tag"],
                "winner_rwp": winner["rwp"],
            }
        )
        current = Path(winner["path"])
    return current


def background_trials(checkpoint: Path, outdir: Path, history: list[dict[str, Any]]) -> Path:
    rows = []
    for count in (6, 8, 10, 12, 14):
        tag = f"background_{count}"
        path = outdir / f"{tag}.gpx"
        project = reopen(checkpoint, path)
        hist = project.histogram(0)
        hist.set_refinements(
            {"Background": {"type": "chebyschev-1", "no. coeffs": count, "refine": True}}
        )
        refine(project, 2)
        save(project, path)
        row = branch_row(project, path, tag=str(count), coefficient_count=count)
        arrays = hist.data["data"][1]
        lo, hi = hist.data["Limits"][1]
        mask = (arrays[0] >= lo) & (arrays[0] <= hi)
        bkg = np.asarray(arrays[4][mask], float)
        row["background_min"] = float(np.min(bkg))
        row["background_max"] = float(np.max(bkg))
        if row["background_min"] < 0:
            row["valid"] = False
            row["reason"] = "negative fitted background"
        rows.append(row)
    # Use 10 as the neutral complexity. Require a useful gain for extra terms.
    valid = [row for row in rows if row["valid"]]
    base = next(row for row in rows if row["coefficient_count"] == 10)
    winner = min(valid, key=lambda row: row["rwp"])
    if winner["coefficient_count"] > 10 and base["rwp"] - winner["rwp"] < 0.005:
        winner = base
    history.append(
        {"stage": "background", "trials": rows, "winner": winner["coefficient_count"], "winner_rwp": winner["rwp"]}
    )
    return Path(winner["path"])


def set_shared_intensity(project: G2sc.G2Project, mode: str) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    inst["Polariz."][1] = 0.5
    inst["Polariz."][2] = False
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    if "polar" in mode:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    if "roughB" in mode:
        hist.set_refinements({"Sample Parameters": ["SurfRoughB"]})
    if "roughAB" in mode:
        sample["SurfRoughA"] = [0.1, True]
        sample["SurfRoughB"] = [0.01, True]


def shared_intensity_valid(project: G2sc.G2Project, mode: str) -> tuple[bool, str]:
    ok, reason = common_valid(project)
    if not ok:
        return ok, reason
    hist = project.histogram(0)
    pol = float(hist.data["Instrument Parameters"][0]["Polariz."][1])
    a = float(hist.data["Sample Parameters"]["SurfRoughA"][0])
    b = float(hist.data["Sample Parameters"]["SurfRoughB"][0])
    if "polar" in mode and not (0.02 < pol < 0.98):
        return False, f"polarization={pol:.7g} at/nonphysical boundary"
    if "rough" in mode and (not (0 <= a <= 1) or b <= 1e-8 or b > 10):
        return False, f"roughness A={a:.7g} B={b:.7g} collapsed/nonphysical"
    return True, "ok"


def shared_intensity_trials(checkpoint: Path, outdir: Path, history: list[dict[str, Any]]) -> Path:
    rows = []
    for mode in ("neutral", "polar", "roughB", "roughAB", "polar_roughB"):
        path = outdir / f"shared_{mode}.gpx"
        project = reopen(checkpoint, path)
        set_shared_intensity(project, mode)
        refine(project, 2)
        save(project, path)
        ok, reason = shared_intensity_valid(project, mode)
        hist = project.histogram(0)
        row = branch_row(project, path, tag=mode)
        row["valid"] = ok
        row["reason"] = reason
        row["polarization"] = float(hist.data["Instrument Parameters"][0]["Polariz."][1])
        row["roughness"] = {
            "A": float(hist.data["Sample Parameters"]["SurfRoughA"][0]),
            "B": float(hist.data["Sample Parameters"]["SurfRoughB"][0]),
        }
        rows.append(row)
    winner = select_with_threshold(rows, "neutral", 0.005)
    history.append(
        {"stage": "shared_intensity", "trials": rows, "winner": winner["tag"], "winner_rwp": winner["rwp"]}
    )
    return Path(winner["path"])


def texture_axes(phase_name: str) -> list[list[int]]:
    if phase_name.startswith("SrWO4"):
        return [[0, 0, 1], [1, 0, 0], [1, 1, 0]]
    if phase_name.startswith("SrCO3"):
        return [[1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 0, 1]]
    return [[1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 1]]


def set_texture(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData, axis: list[int] | None) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = axis is not None
    if axis is not None:
        hap["Pref.Ori."][3] = list(axis)


def texture_valid(project: G2sc.G2Project, phase_name: str, active: bool) -> tuple[bool, str]:
    ok, reason = common_valid(project)
    if not ok:
        return ok, reason
    values = broadening(project)[phase_name]
    ratio = values["MD"]
    if active and (not math.isfinite(ratio) or not (0.2 < ratio < 5.0) or abs(ratio - 1) < 1e-5):
        return False, f"March ratio={ratio:.7g} collapsed/nonphysical"
    return True, "ok"


def texture_pass(
    checkpoint: Path, outdir: Path, pass_index: int, history: list[dict[str, Any]]
) -> Path:
    current = checkpoint
    probe = G2sc.G2Project(str(current))
    phase_names = [phase.name for phase in probe.phases()]
    for phase_name in phase_names:
        rows = []
        choices: list[tuple[str, list[int] | None]] = [("neutral", None)]
        choices += [("_".join(map(str, axis)), axis) for axis in texture_axes(phase_name)]
        for tag, axis in choices:
            safe_phase = phase_name.replace("/", "_")
            path = outdir / f"texture_p{pass_index}_{safe_phase}_{tag}.gpx"
            project = reopen(current, path)
            phase = project.phase(phase_name)
            hist = project.histogram(0)
            set_texture(phase, hist, axis)
            refine(project, 2)
            save(project, path)
            ok, reason = texture_valid(project, phase_name, axis is not None)
            row = branch_row(project, path, tag=tag, phase=phase_name, axis=axis)
            row["valid"] = ok
            row["reason"] = reason
            rows.append(row)
        winner = select_with_threshold(rows, "neutral", 0.01)
        history.append(
            {
                "stage": "texture",
                "pass": pass_index,
                "phase": phase_name,
                "trials": rows,
                "winner": winner["tag"],
                "winner_rwp": winner["rwp"],
            }
        )
        current = Path(winner["path"])
    return current


def summarize_final(project: G2sc.G2Project, path: Path) -> dict[str, Any]:
    hist = project.histogram(0)
    try:
        fractions = {
            name: [float(value[0]), float(value[1])]
            for name, value in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": repr(exc)}
    return {
        "path": str(path),
        "rwp": rwp(project),
        "gof": float(project.data["Covariance"]["data"]["Rvals"].get("GOF", math.nan)),
        "profile": profile(project),
        "scales": scales(project),
        "mass_fractions": fractions,
        "broadening": broadening(project),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "shift_um": float(hist.data["Sample Parameters"]["Shift"][0]),
        "polarization": float(hist.data["Instrument Parameters"][0]["Polariz."][1]),
        "roughness": {
            "A": float(hist.data["Sample Parameters"]["SurfRoughA"][0]),
            "B": float(hist.data["Sample Parameters"]["SurfRoughB"][0]),
        },
        "background_coefficients": int(hist.data["Background"][0][2]),
        "covariance": covariance_info(project),
    }


def run(label: str) -> dict[str, Any]:
    outdir = OUTROOT / label
    outdir.mkdir(parents=True, exist_ok=True)
    logpath = outdir / "run.log"
    history: list[dict[str, Any]] = []
    with logpath.open("w") as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        start = outdir / "00_start.gpx"
        project = reopen(BASES[label], start)
        refine(project, 2)
        save(project, start)
        history.append({"stage": "start_replay", **branch_row(project, start, tag="start")})

        # Two full isotropic broadening passes implement coordinate descent.
        current = broadening_pass(start, outdir, 1, history)
        current = broadening_pass(current, outdir, 2, history)

        # Reopen background/shared-intensity terms before low-order texture.
        current = background_trials(current, outdir, history)
        current = shared_intensity_trials(current, outdir, history)
        current = texture_pass(current, outdir, 1, history)

        # Any accepted intensity/texture change requires another broadening loop.
        current = broadening_pass(current, outdir, 3, history)
        current = texture_pass(current, outdir, 2, history)

        final_path = outdir / "converged.gpx"
        project = reopen(current, final_path)
        refine(project, 2)
        save(project, final_path)
        final = summarize_final(project, final_path)
    result = {"label": label, "base": str(BASES[label]), "log": str(logpath), "history": history, "final": final}
    (outdir / "summary.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("labels", nargs="*", choices=list(BASES))
    args = parser.parse_args()
    labels = args.labels or list(BASES)
    OUTROOT.mkdir(parents=True, exist_ok=True)
    for label in labels:
        try:
            result = run(label)
            print(json.dumps({"label": label, "status": "ok", "final": result["final"]}, sort_keys=True), flush=True)
        except Exception as exc:
            print(json.dumps({"label": label, "status": "error", "error": repr(exc)}, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
