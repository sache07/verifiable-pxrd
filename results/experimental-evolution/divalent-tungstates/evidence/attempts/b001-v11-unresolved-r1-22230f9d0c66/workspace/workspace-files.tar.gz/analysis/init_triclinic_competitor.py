#!/usr/bin/env python3
"""Build a matched-nuisance triclinic WO3 competitor in reversible stages."""

from pathlib import Path
import contextlib
import sys

from GSASII import GSASIIscriptable as G2sc

sys.path.insert(0, str(Path(__file__).resolve().parent))
import converge_models as conv  # noqa: E402


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "trials" / "caparent_triclinic_carbonate.gpx"
OUT = ROOT / "analysis" / "triclinic_equal"


def phase(project, prefix):
    return next(item for item in project.phases() if item.name.startswith(prefix))


def set_texture(project, prefix, value, axis):
    hist = project.histogram(0)
    po = phase(project, prefix).data["Histograms"][hist.name]["Pref.Ori."]
    po[1] = float(value)
    po[2] = True
    po[3] = list(axis)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    logpath = OUT / "init.log"
    final = OUT / "matched_start.gpx"
    with logpath.open("w") as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        project = conv.reopen(SOURCE, OUT / "stage0.gpx")
        hist = project.histogram(0)

        # Matched common terms; roughness remains at the neutral value.
        hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 14, "refine": True}})
        inst = hist.data["Instrument Parameters"][0]
        for key in ("U", "V", "Y", "Z"):
            inst[key][2] = False
        inst["U"][1] = 1.0
        inst["W"][1:3] = [40.4, True]
        inst["X"][1:3] = [3.24, True]
        inst["Polariz."][1:3] = [0.783, True]
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.0, False]
        sample["Shift"][1] = True
        conv.refine(project, 2)
        conv.save(project, OUT / "stage1_common.gpx")

        # Terms supported independently by the two non-WO3 phases.
        for item in project.phases():
            conv.set_neutral_broadening(item, hist)
        srhap = phase(project, "SrWO4").data["Histograms"][hist.name]
        srhap["Mustrain"][0] = "uniaxial"
        srhap["Mustrain"][1][:2] = [1220.0, 137.0]
        srhap["Mustrain"][2] = [True, True, False]
        srhap["Mustrain"][3] = [0, 0, 1]
        wohap = phase(project, "WO3").data["Histograms"][hist.name]
        wohap["Mustrain"][0] = "isotropic"
        wohap["Mustrain"][1][0] = 4200.0
        wohap["Mustrain"][2] = [True, False, False]
        set_texture(project, "SrWO4", 0.737, [1, 1, 0])
        set_texture(project, "SrCO3", 0.832, [0, 0, 1])
        conv.refine(project, 2)
        conv.save(project, final)

        ok, reason = conv.common_valid(project)
        print("valid", ok, reason, "Rwp", conv.rwp(project), "fractions", hist.ComputeMassFracs())


if __name__ == "__main__":
    main()
