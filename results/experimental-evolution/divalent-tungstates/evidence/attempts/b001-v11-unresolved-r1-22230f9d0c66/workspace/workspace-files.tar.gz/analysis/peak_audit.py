#!/usr/bin/env python3
"""Empirical local peak-position and half-width audit for the final project."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.signal import find_peaks, savgol_filter
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
project = G2sc.G2Project(str(ROOT / "final.gpx"))
hist = project.histogram(0)
x, observed, _weight, calculated, background, _difference = [
    np.asarray(item, float) for item in hist.data["data"][1]
]

SELECTIONS = [
    ("SrWO4", "low", "011", 17.15, 17.75, "phase-dominant"),
    ("SrWO4", "middle", "024", 44.50, 45.05, "phase-dominant"),
    ("SrWO4", "high", "136/316", 72.40, 72.90, "phase-dominant"),
    ("WO3 (triclinic)", "low", "020", 22.72, 23.16, "phase-dominant"),
    ("WO3 (triclinic)", "middle", "2-20/202/220", 33.30, 33.90, "split family"),
    ("WO3 (triclinic)", "high", "mixed 86.6-87.0 family", 86.45, 87.18, "overlaps SrWO4 244/424"),
    ("SrCO3", "low", "111", 24.36, 24.86, "phase-dominant"),
    ("SrCO3", "middle", "203/122", 43.35, 43.90, "mostly phase-dominant"),
    ("SrCO3", "high", "413/331 family", 73.10, 73.68, "weak/noisy family"),
]


def metric(values: np.ndarray, low: float, high: float) -> dict:
    mask = (x >= low) & (x <= high)
    xx = x[mask]
    yy = savgol_filter(values[mask], 7, 2)
    edge = max(3, len(yy) // 10)
    left_base = float(np.median(yy[:edge]))
    right_base = float(np.median(yy[-edge:]))
    baseline = left_base + (right_base - left_base) * (xx - xx[0]) / (xx[-1] - xx[0])
    net = yy - baseline
    peak_index = int(np.argmax(net))
    half = float(net[peak_index] / 2)
    crossings: list[float | None] = []
    for side in (-1, 1):
        indices = range(peak_index - 1, -1, -1) if side < 0 else range(peak_index, len(net) - 1)
        crossing = None
        for index in indices:
            y0, y1 = float(net[index]), float(net[index + 1])
            bracketed = y0 <= half <= y1 if side < 0 else y0 >= half >= y1
            if bracketed and y1 != y0:
                crossing = float(xx[index] + (half - y0) * (xx[index + 1] - xx[index]) / (y1 - y0))
                break
        crossings.append(crossing)
    prominence = max(10.0, 0.08 * float(np.max(net)))
    maxima, _ = find_peaks(net, prominence=prominence, distance=3)
    result = {
        "position_deg": float(xx[peak_index]),
        "net_peak_height": float(net[peak_index]),
        "resolved_local_maxima_deg": [float(xx[index]) for index in maxima],
    }
    if all(value is not None for value in crossings):
        left, right = float(crossings[0]), float(crossings[1])
        result.update(
            {
                "fwhm_deg": right - left,
                "left_half_width_deg": float(xx[peak_index]) - left,
                "right_half_width_deg": right - float(xx[peak_index]),
            }
        )
    else:
        result.update({"fwhm_deg": None, "left_half_width_deg": None, "right_half_width_deg": None})
    return result


rows = []
for phase, angle_band, family, low, high, qualification in SELECTIONS:
    rows.append(
        {
            "phase": phase,
            "angle_band": angle_band,
            "family": family,
            "window_deg": [low, high],
            "qualification": qualification,
            "observed": metric(observed - background, low, high),
            "calculated": metric(calculated - background, low, high),
        }
    )

(ROOT / "analysis" / "peak_audit.json").write_text(json.dumps(rows, indent=2) + "\n")
print(json.dumps(rows, indent=2))
