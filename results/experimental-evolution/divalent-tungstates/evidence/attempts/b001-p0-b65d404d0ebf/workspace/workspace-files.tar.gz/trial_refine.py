#!/usr/bin/env python3
"""Run reproducible GSAS-II trial refinements for the Ca-W-O pattern."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from scipy.signal import savgol_filter

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
RESOURCE = Path(
    "<RUN>/"
    "resources/b001-c05/cif"
)


def cif_path(cod_id: str) -> Path:
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make_inputs() -> tuple[Path, Path, np.ndarray, np.ndarray]:
    tmp = ROOT / ".tmp"
    tmp.mkdir(exist_ok=True)
    pattern = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skip_header=1)
    x = pattern[:, 0]
    y = pattern[:, 1]

    xye = tmp / "pattern.xye"
    np.savetxt(xye, np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))), fmt="%.8f %.8f %.8f")

    inst = tmp / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for measured Cu K-alpha data\n"
        "Type:PXC;Bank:1;InstrName:PANalytical PIXcel1D;Diff-type:Bragg-Brentano\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.5;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:40.0;V:-20.0;W:180.0;X:4.0;Y:4.0;Z:0.0;SH/L:0.02\n"
    )
    return xye, inst, x, y


def background_points(x: np.ndarray, y: np.ndarray) -> list[tuple[float, float]]:
    # A conservative lower-envelope estimate used only to initialize the
    # subsequently refined Chebyshev background.
    base = percentile_filter(y, size=301, percentile=12, mode="nearest")
    base = savgol_filter(base, 501, 2, mode="interp")
    pick = np.unique(np.r_[np.arange(0, len(x), 70), len(x) - 1])
    return [(float(x[i]), float(max(base[i], 1.0))) for i in pick]


def run(args: argparse.Namespace) -> None:
    xye, inst, x, y = make_inputs()
    output = ROOT / args.output
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": False,
                "no. coeffs": args.background_terms,
                "FixedPoints": background_points(x, y),
                "fit fixed points": True,
            }
        }
    )

    phases = [
        project.add_phase(
            str(cif_path("7219229")),
            phasename="CaWO4_scheelite",
            histograms=[hist],
            fmthint="CIF",
        ),
        project.add_phase(
            str(cif_path(args.wo3_id)),
            phasename=f"WO3_{args.wo3_id}",
            histograms=[hist],
            fmthint="CIF",
        ),
    ]
    if args.cao:
        phases.append(
            project.add_phase(
                str(cif_path("1563196")),
                phasename="CaO_lime",
                histograms=[hist],
                fmthint="CIF",
            )
        )

    # Reasonable starting scales reduce transient correlations in the first fit.
    for phase, scale in zip(phases, [1.0, 0.2, 0.02]):
        phase.data["Histograms"][hist.name]["Scale"][0] = scale

    project.set_Controls("cycles", 8)
    project.save()

    stages = [
        {"set": {"Background": True, "Scale": True}},
        {"set": {"Cell": True, "Instrument Parameters": ["Zero"]}},
        {"set": {"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]}},
        {
            "set": {
                "Size": {
                    "type": "isotropic",
                    "value": 0.10,
                    "refine": True,
                    "LGmix": {"value": 0.5, "refine": False},
                }
            }
        },
    ]
    for i, stage in enumerate(stages, 1):
        print(f"\n=== refinement stage {i} ===")
        project.do_refinements([stage])
        print(json.dumps(hist.residuals, indent=2, default=float))
        print("cells", {p.name: p.get_cell() for p in phases})
        print("scales", {p.name: p.data["Histograms"][hist.name]["Scale"] for p in phases})

    project.save()
    try:
        mass = hist.ComputeMassFracs()
    except Exception as exc:
        mass = {"error": repr(exc)}
    summary = {
        "output": str(output),
        "wo3_id": args.wo3_id,
        "cao": args.cao,
        "residuals": hist.residuals,
        "mass_fractions": mass,
        "instrument": hist.InstrumentParameters,
        "cells": {p.name: p.get_cell() for p in phases},
        "scales": {p.name: p.data["Histograms"][hist.name]["Scale"] for p in phases},
    }
    print("\n=== FINAL SUMMARY ===")
    print(json.dumps(summary, indent=2, default=float))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3-id", default="1528915")
    parser.add_argument("--cao", action="store_true")
    parser.add_argument("--background-terms", type=int, default=18)
    parser.add_argument("--output", default=".tmp/trial.gpx")
    run(parser.parse_args())
