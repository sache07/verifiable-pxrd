#!/usr/bin/env python3
"""Finalize the selected GSAS-II model and write all requested deliverables."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE_GPX = ROOT / ".tmp" / "trial-po-stable.gpx"
FINAL_GPX = ROOT / "final.gpx"

PHASE_OUTPUTS = {
    "CaWO4_scheelite": ("Calcium tungstate (scheelite)", "CaWO4", "phase_CaWO4.cif"),
    "WO3_1528915": ("Tungsten trioxide (monoclinic)", "WO3", "phase_WO3.cif"),
    "CaO_lime": ("Calcium oxide (lime)", "CaO", "phase_CaO.cif"),
}


def as_float(value):
    return float(value) if value is not None else None


project = G2sc.G2Project(str(SOURCE_GPX), newgpx=str(FINAL_GPX))
hist = project.histogram(0)

# Use every supplied point in the final fit. The source trial omitted only the
# narrow edge slivers below 10 and above 100 degrees.
x_all = np.asarray(hist.data["data"][1][0], dtype=float)
hist.data["Limits"][1] = [float(x_all[0]), float(x_all[-1])]

# The overall histogram scale is fixed to avoid its exact degeneracy with all
# phase scales. Structural coordinates remain fixed at literature values; the
# refined variables are phase scales/cells, background, zero, and the mild
# scheelite [001] March-Dollase term.
hist.SampleParameters["Scale"] = [1.0, False]
project.set_Controls("cycles", 20)
project.save()

for _ in range(5):
    project.do_refinements([{}])
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    if rvals.get("converged") and abs(rvals.get("Max shft/sig", 1.0)) < 0.05:
        break
project.save()

hist = project.histogram(0)
mass_fractions = hist.ComputeMassFracs()
rvals = project.data["Covariance"]["data"]["Rvals"]
residuals = hist.residuals

phase_rows = []
for phase in project.phases():
    display_name, formula, cif_name = PHASE_OUTPUTS[phase.name]
    phase.export_CIF(str(ROOT / cif_name))
    cell, cell_esd = phase.get_cell_and_esd()
    fraction, fraction_esd = mass_fractions[phase.name]
    systematic = {"CaWO4_scheelite": 0.02, "WO3_1528915": 0.01, "CaO_lime": 0.01}[phase.name]
    phase_rows.append(
        {
            "name": display_name,
            "formula": formula,
            "cif_path": cif_name,
            "weight_fraction": float(fraction),
            "weight_percent": float(100.0 * fraction),
            "weight_fraction_esd_from_refinement": float(fraction_esd),
            "estimated_absolute_model_uncertainty": systematic,
            "cell": {key: float(value) for key, value in cell.items()},
            "cell_esd": {key: float(value) for key, value in cell_esd.items()},
        }
    )

xy = hist.data["data"][1]
x = np.asarray(xy[0], dtype=float)
observed = np.asarray(xy[1], dtype=float)
calculated = np.asarray(xy[3], dtype=float)
background = np.asarray(xy[4], dtype=float)
difference = observed - calculated
low, high = hist.data["Limits"][1]
use = (x >= low) & (x <= high)
np.savetxt(
    ROOT / "fit.csv",
    np.column_stack((x[use], observed[use], calculated[use], difference[use], background[use])),
    delimiter=",",
    header="two_theta_deg,observed_intensity,calculated_intensity,difference_observed_minus_calculated,calculated_background",
    comments="",
    fmt=["%.8f", "%.8f", "%.8f", "%.8f", "%.8f"],
)

n_obs = int(rvals["Nobs"])
n_vars = int(rvals["Nvars"])
chi_square = float(rvals["chisq"])
fit_statistics = {
    "Rp_percent": float(residuals["R"]),
    "Rwp_percent": float(residuals["wR"]),
    "Rexp_percent": float(residuals["wRmin"]),
    "Rp_background_subtracted_percent": float(residuals["Rb"]),
    "Rwp_background_subtracted_percent": float(residuals["wRb"]),
    "goodness_of_fit": float(rvals["GOF"]),
    "chi_square": chi_square,
    "reduced_chi_square": chi_square / (n_obs - n_vars),
    "number_of_observations": n_obs,
    "number_of_refined_parameters": n_vars,
    "two_theta_range_deg": [float(low), float(high)],
    "converged": bool(rvals["converged"]),
    "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
}

result = {
    "phases": phase_rows,
    "weight_fraction_basis": "Normalized over the modeled crystalline phases; no amorphous fraction determined.",
    "fit_statistics": fit_statistics,
    "project_path": "final.gpx",
    "profile_path": "fit.csv",
    "radiation": {
        "source": "Cu K-alpha",
        "wavelength_Kalpha1_angstrom": 1.540598,
        "wavelength_Kalpha2_angstrom": 1.544426,
        "Kalpha2_to_Kalpha1_ratio": 0.5,
    },
    "weighting": "Poisson counting weights (1/I) were assumed because pointwise uncertainties were not supplied.",
}
(ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

fraction_text = ", ".join(
    f"{row['formula']} {row['weight_percent']:.2f} wt%" for row in phase_rows
)
cell_by_formula = {row["formula"]: row["cell"] for row in phase_rows}

report = f"""# PXRD phase analysis

The crystalline model contains three phases: {fraction_text}. Fractions are normalized only over these modeled crystalline phases; an amorphous fraction cannot be obtained without an internal standard.

## Evidence

Scheelite CaWO4 (I41/a, No. 88) accounts for the dominant 18.43, 28.54/28.81, 31.27, 34.01, 39.03, 46.93, 54.11, and 57.70 degree lines. Monoclinic WO3 (P21/n, No. 14) is required by the characteristic 22.94/23.42/24.23 degree triplet and the 26.44, 33.10/33.43, and 41.31/41.76 degree splittings. Weak CaO (Fm-3m, No. 225) improves the 32.18 and 37.53 degree regions and several overlapping higher-angle lines. Its presence is also chemically self-consistent: the refined residual WO3:CaO mass ratio is approximately the ratio expected for equal molar amounts of the two unreacted precursors.

Alternative low-temperature WO3 cells were tested. The selected monoclinic model fit better than triclinic and orthorhombic candidates while retaining a plausible cell. A mild CaWO4 [001] March-Dollase correction was supported by the 004/200 intensity mismatch and lowered Rwp relative to an untextured model. Refined cells are CaWO4 a={cell_by_formula['CaWO4']['length_a']:.5f}, c={cell_by_formula['CaWO4']['length_c']:.5f} A; WO3 a={cell_by_formula['WO3']['length_a']:.5f}, b={cell_by_formula['WO3']['length_b']:.5f}, c={cell_by_formula['WO3']['length_c']:.5f} A, beta={cell_by_formula['WO3']['angle_beta']:.4f} degrees; and CaO a={cell_by_formula['CaO']['length_a']:.5f} A.

## Refinement and uncertainty

The GSAS-II Rietveld fit used the reported Cu Kalpha1/Kalpha2 wavelengths and 0.5 intensity ratio, Poisson counting weights, a refined zero offset, phase scales and cells, an 18-term Chebyshev background, and empirical profile/size broadening. Atomic coordinates were retained from COD 7219229 (CaWO4), 1528915 (WO3), and 1563196 (CaO); coordinate refinement was not stable enough to justify changes. The final statistics are Rp={fit_statistics['Rp_percent']:.3f}%, Rwp={fit_statistics['Rwp_percent']:.3f}%, Rexp={fit_statistics['Rexp_percent']:.3f}%, and GOF={fit_statistics['goodness_of_fit']:.3f}.

The formal covariance errors are smaller than the real uncertainty because no pointwise standard uncertainties or calibrated instrument profile were supplied and residual preferred orientation/profile mismatch remains. Plausible profile variants gave approximately CaWO4 82.6-84.3 wt%, WO3 12.4-13.1 wt%, and CaO 3.1-4.2 wt%. Thus sensible rounded estimates are 84 +/- 2 wt%, 12.5 +/- 1 wt%, and 3.5 +/- 1 wt%, respectively. CaO is the least certain phase because it is minor and most of its stronger lines overlap; its structure is credible, but its fraction should not be quoted more precisely than about one absolute wt%.
"""
(ROOT / "report.md").write_text(report)

# Save once more after all exports so final.gpx is exactly the project from
# which the submitted profile, fractions, and CIFs were read.
project.save()
print(json.dumps(result, indent=2))
