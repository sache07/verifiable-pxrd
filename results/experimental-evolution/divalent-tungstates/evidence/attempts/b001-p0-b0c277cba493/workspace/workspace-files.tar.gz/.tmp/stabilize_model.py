from pathlib import Path
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
source = ROOT / ".tmp" / "variant_pv_shift_b20.gpx"
target = ROOT / ".tmp" / "stabilized.gpx"
if target.exists():
    target.unlink()
gpx = G2sc.G2Project(gpxfile=str(source), newgpx=str(target))
hist = gpx.histogram(0)
inst_keys = ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]

def max_shift():
    shifts, sigmas = gpx.get_LastFitResults()
    ratios = {k: abs(shifts[k] / sigmas[k]) for k in shifts
              if k in sigmas and np.isfinite(sigmas[k]) and sigmas[k] > 0}
    return max(ratios.items(), key=lambda item: item[1]) if ratios else (None, 0.0)

# Isolate the weak ZnO lattice fit from the correlated global/profile terms.
hist.clear_refinements({"Background": True,
                        "Instrument Parameters": inst_keys,
                        "Sample Parameters": ["Shift"]})
for phase in gpx.phases():
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Scale": True})
gpx.phase("ZnO").set_refinements({"Cell": True})
gpx.set_Controls("cycles", 20)
for i in range(8):
    gpx.do_refinements([{}])
    key, ratio = max_shift()
    print("ZNO_ONLY", i, gpx.histogram(0).residuals["wR"], key, ratio)
    if ratio < 0.05:
        break
zno_cell = gpx.phase("ZnO").get_cell_and_esd()

# Keep that independently optimized ZnO cell fixed, then finish all other
# parameters and the three phase scales together.
gpx.phase("ZnO").clear_refinements({"Cell": True})
hist.set_refinements({"Background": True,
                      "Instrument Parameters": ["W", "X", "Y", "Polariz."],
                      "Sample Parameters": ["Shift"]})
for phase in gpx.phases():
    phase.set_HAP_refinements({"Scale": True})
for name in ("ZnWO4", "WO3"):
    gpx.phase(name).set_refinements({"Cell": True})

for i in range(15):
    gpx.do_refinements([{}])
    key, ratio = max_shift()
    print("GLOBAL", i, gpx.histogram(0).residuals["wR"], key, ratio)
    if ratio < 0.05:
        break
gpx.save()
print("ZNO_CELL", zno_cell)
print("FRACS", gpx.histogram(0).ComputeMassFracs())
for phase in gpx.phases():
    print("CELL", phase.name, phase.get_cell_and_esd(), "flag", phase.data["General"]["Cell"][0])
print("INST", {k: v for k, v in gpx.histogram(0).InstrumentParameters.items()
               if k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")})
print("SHIFT", gpx.histogram(0).SampleParameters["Shift"])
print("RES", gpx.histogram(0).residuals)
