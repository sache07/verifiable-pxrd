from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
GPX = ROOT / ".tmp" / "trial.gpx"
PATTERN = ROOT / "inputs" / "pattern.csv"
IPARM = ROOT / ".tmp" / "cu_ka.instprm"

REFS = [
    ("ZnWO4", Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/06/1520641.cif")),
    ("WO3", Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif")),
    ("ZnO", Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/00/41/9004178.cif")),
]

if GPX.exists():
    GPX.unlink()
gpx = G2sc.G2Project(newgpx=str(GPX))
hist = gpx.add_powder_histogram(str(PATTERN), str(IPARM), fmthint="comma")
for name, cif in REFS:
    gpx.add_phase(str(cif), phasename=name, histograms=[hist], fmthint="CIF")

hist.set_refinements({
    "Limits": [10.0, 100.0],
    "Background": {
        "type": "chebyschev-1",
        "refine": True,
        "no. coeffs": 15,
        "coeffs": [1200.0] + [0.0] * 14,
    },
})
for phase in gpx.phases():
    phase.set_HAP_refinements({"Scale": True})

gpx.set_Controls("cycles", 8)

def show(tag):
    hist = gpx.histogram(0)
    print("\nSTATE", tag)
    print("residuals", hist.residuals)
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
          if k in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")})
    for p in gpx.phases():
        print(p.name, "scale", p.HAPvalue("Scale"), "cell", p.get_cell())
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as err:
        print("mass fractions unavailable", repr(err))

show("initial")
gpx.do_refinements([{}])
show("scale_background")

for p in gpx.phases():
    p.set_refinements({"Cell": True})
gpx.do_refinements([{}])
show("cell")

hist.set_refinements({"Instrument Parameters": ["Zero", "W", "X"]})
gpx.do_refinements([{}])
show("profile_1")

hist.set_refinements({"Instrument Parameters": ["U", "V", "Y", "SH/L", "Polariz."]})
gpx.do_refinements([{}])
show("profile_2")

gpx.do_refinements([{}])
show("repeat")
gpx.save()

out = {
    "residuals": gpx.histogram(0).residuals,
    "mass_fractions": gpx.histogram(0).ComputeMassFracs(),
    "instrument": gpx.histogram(0).InstrumentParameters,
    "phases": {p.name: {"cell": p.get_cell_and_esd(), "scale": p.HAPvalue("Scale")}
               for p in gpx.phases()},
    "vary_list": gpx.get_VaryList(),
}
print("\nFINAL_JSON")
print(json.dumps(out, indent=2, default=lambda obj: obj.tolist() if hasattr(obj, "tolist") else str(obj)))
