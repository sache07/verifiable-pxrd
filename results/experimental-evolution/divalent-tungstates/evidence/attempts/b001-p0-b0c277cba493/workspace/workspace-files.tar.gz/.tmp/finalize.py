from pathlib import Path
import json
import math
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp" / "stabilized.gpx"
FINAL = ROOT / "final.gpx"

if FINAL.exists():
    FINAL.unlink()
project = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
project.save()

# Reload the submitted project and generate every numerical/structural artifact
# from that file, ensuring all outputs share the exact same model state.
project = G2sc.G2Project(str(FINAL))
hist = project.histogram(0)

cif_names = {
    "ZnWO4": "ZnWO4.cif",
    "WO3": "WO3.cif",
    "ZnO": "ZnO.cif",
}
for phase in project.phases():
    phase.export_CIF(str(ROOT / cif_names[phase.name]))

x = np.asarray(hist.getdata("X"), dtype=float)
yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
ybkg = np.asarray(hist.getdata("Background"), dtype=float)
ydiff = np.asarray(hist.getdata("Residual"), dtype=float)
profile = np.column_stack((x, yobs, ycalc, ybkg, ydiff))
np.savetxt(
    ROOT / "fit.csv",
    profile,
    delimiter=",",
    header="two_theta_deg,observed_intensity,calculated_intensity,background_intensity,difference_observed_minus_calculated",
    comments="",
    fmt=["%.8f", "%.8f", "%.8f", "%.8f", "%.8f"],
)

mass_fractions = hist.ComputeMassFracs()
residuals = hist.residuals
rvals = project.data["Covariance"]["data"]["Rvals"]
phase_meta = {
    "ZnWO4": {"formula": "ZnWO4", "space_group": "P 2/c", "reference_cod_id": "1520641"},
    "WO3": {"formula": "WO3", "space_group": "P 21/n", "reference_cod_id": "1528915"},
    "ZnO": {"formula": "ZnO", "space_group": "P 63 m c", "reference_cod_id": "9004178"},
}

phases = []
for phase in project.phases():
    fraction, fraction_su = mass_fractions[phase.name]
    pid = phase.id
    phases.append({
        "name": phase.name,
        **phase_meta[phase.name],
        "cif_path": cif_names[phase.name],
        "weight_fraction": fraction,
        "weight_fraction_formal_su": fraction_su,
        "weight_percent": 100.0 * fraction,
        "weight_percent_formal_su": 100.0 * fraction_su,
        "phase_Rf_percent": residuals.get(f"{pid}:0:Rf"),
        "phase_Rf_squared_percent": residuals.get(f"{pid}:0:Rf^2"),
    })

result = {
    "weight_fraction_basis": "normalized over the modeled crystalline phases; no amorphous or absolute crystalline fraction determined",
    "phases": phases,
    "fit_statistics": {
        "Rp_percent": residuals["R"],
        "Rwp_percent": residuals["wR"],
        "Rexp_percent": residuals["wRmin"],
        "goodness_of_fit": rvals["GOF"],
        "reduced_chi_squared": rvals["GOF"] ** 2,
        "chi_squared": rvals["chisq"],
        "n_observations": rvals["Nobs"],
        "n_refined_variables": rvals["Nvars"],
    },
    "project_path": "final.gpx",
    "profile_path": "fit.csv",
}
with open(ROOT / "result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

print(json.dumps(result, indent=2))
