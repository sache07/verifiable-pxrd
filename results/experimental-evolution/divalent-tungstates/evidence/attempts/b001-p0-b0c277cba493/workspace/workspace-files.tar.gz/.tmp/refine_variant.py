from pathlib import Path
import argparse
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
PATTERN = ROOT / "inputs" / "pattern.csv"
IPARM = ROOT / ".tmp" / "cu_ka.instprm"
REFS = [
    ("ZnWO4", "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/06/1520641.cif"),
    ("WO3", "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif"),
    ("ZnO", "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/00/41/9004178.cif"),
]

MODELS = {
    "lorentz_fixed_y": ["Zero", "X", "Polariz."],
    "lorentz": ["Zero", "X", "Y", "Polariz."],
    "pv_w5": ["Zero", "X", "Y", "Polariz."],
    "pv_w10": ["Zero", "X", "Y", "Polariz."],
    "pv_w20": ["Zero", "X", "Y", "Polariz."],
    "pv_refine": ["Zero", "W", "X", "Y", "Polariz."],
    "pv_refine_fixed_y": ["Zero", "W", "X", "Polariz."],
    "pv_shift": ["W", "X", "Y", "Polariz."],
    "pv_zero_shift": ["Zero", "W", "X", "Y", "Polariz."],
    "simple": ["Zero", "W", "X", "Polariz."],
    "wxy": ["Zero", "W", "X", "Y", "Polariz."],
    "uwx": ["Zero", "U", "W", "X", "Polariz."],
    "uvwx": ["Zero", "U", "V", "W", "X", "Polariz."],
    "full_no_shl": ["Zero", "U", "V", "W", "X", "Y", "Polariz."],
    "full": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."],
}

parser = argparse.ArgumentParser()
parser.add_argument("model", choices=MODELS)
parser.add_argument("--background", type=int, default=15)
args = parser.parse_args()

gpx_path = ROOT / ".tmp" / f"variant_{args.model}_b{args.background}.gpx"
if gpx_path.exists():
    gpx_path.unlink()
gpx = G2sc.G2Project(newgpx=str(gpx_path))
hist = gpx.add_powder_histogram(str(PATTERN), str(IPARM), fmthint="comma")
for name, cif in REFS:
    gpx.add_phase(cif, phasename=name, histograms=[hist], fmthint="CIF")

# A powder-histogram scale and all phase scales are exactly redundant. Keep the
# former fixed so phase-scale covariance and mass-fraction uncertainties are valid.
hist.SampleParameters["Scale"][:] = [1.0, False]
if args.model.startswith("lorentz"):
    for key in ("U", "V", "W"):
        hist.InstrumentParameters[key][0:2] = [0.0, 0.0]
elif args.model.startswith("pv_w"):
    fixed_w = float(args.model.removeprefix("pv_w"))
    for key in ("U", "V"):
        hist.InstrumentParameters[key][0:2] = [0.0, 0.0]
    hist.InstrumentParameters["W"][0:2] = [fixed_w, fixed_w]
elif args.model.startswith("pv_refine"):
    for key in ("U", "V"):
        hist.InstrumentParameters[key][0:2] = [0.0, 0.0]
    hist.InstrumentParameters["W"][0:2] = [10.0, 10.0]
elif args.model.startswith("pv_shift") or args.model.startswith("pv_zero_shift"):
    for key in ("U", "V"):
        hist.InstrumentParameters[key][0:2] = [0.0, 0.0]
    hist.InstrumentParameters["W"][0:2] = [10.0, 10.0]
hist.set_refinements({
    "Limits": [9.90343322, 100.09455322],
    "Background": {
        "type": "chebyschev-1",
        "refine": True,
        "no. coeffs": args.background,
        "coeffs": [1200.0] + [0.0] * (args.background - 1),
    },
})
for phase in gpx.phases():
    phase.set_HAP_refinements({"Scale": True})

gpx.set_Controls("cycles", 10)
gpx.do_refinements([{}])
for phase in gpx.phases():
    phase.set_refinements({"Cell": True})
gpx.do_refinements([{}])

# Introduce stable peak-position and Lorentzian-width terms first.
first_profile = ["X"] if args.model == "pv_shift" else ["Zero", "X"]
hist.set_refinements({"Instrument Parameters": first_profile})
if "shift" in args.model:
    hist.set_refinements({"Sample Parameters": ["Shift"]})
gpx.do_refinements([{}])
hist.set_refinements({"Instrument Parameters": MODELS[args.model]})

history = []
for _ in range(8):
    gpx.do_refinements([{}])
    shifts, sigmas = gpx.get_LastFitResults()
    ratios = [abs(shifts[k] / sigmas[k]) for k in shifts
              if k in sigmas and np.isfinite(sigmas[k]) and sigmas[k] > 0]
    history.append({"rwp": gpx.histogram(0).residuals.get("wR"),
                    "max_shift_over_esd": max(ratios, default=None)})
    if ratios and max(ratios) < 0.1:
        break

gpx.save()
hist = gpx.histogram(0)
cov = gpx.data["Covariance"]["data"]
cmat = cov.get("covMatrix")
correlations = []
if cmat is not None and len(cmat):
    esd = np.sqrt(np.diag(cmat))
    corr = cmat / np.outer(esd, esd)
    for i in range(len(corr)):
        for j in range(i + 1, len(corr)):
            if abs(corr[i, j]) >= 0.90:
                correlations.append([cov["varyList"][i], cov["varyList"][j], float(corr[i, j])])

result = {
    "model": args.model,
    "background_coefficients": args.background,
    "residuals": hist.residuals,
    "mass_fractions": hist.ComputeMassFracs(),
    "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items()
                   if k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")},
    "cells": {p.name: p.get_cell_and_esd() for p in gpx.phases()},
    "history": history,
    "high_correlations": correlations,
    "vary_count": len(cov.get("varyList", [])),
}
print("RESULT_JSON " + json.dumps(result, default=lambda x: x.tolist() if hasattr(x, "tolist") else x))
