#!/usr/bin/env python3
"""Freeze, replay and export the selected GSAS-II model."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
SOURCE = WORK / ".tmp/final_source_trials/Pb3O4_tetragonal_9012124.gpx"
PROJECT = WORK / "final.gpx"
PHASE_FILES = {
    "PbWO4_stolzite": WORK / "phase_pbwo4_stolzite.cif",
    "WO3_monoclinic": WORK / "phase_wo3_monoclinic.cif",
    "Pb3O4_minium": WORK / "phase_pb3o4_minium.cif",
    "PbO_massicot": WORK / "phase_pbo_massicot.cif",
}


def neutral_size(hap: dict) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Size"][4] = [10.0, 10.0, 10.0, 0.0, 0.0, 0.0]
    hap["Size"][5] = [False] * len(hap["Size"][5])


def neutral_strain(hap: dict) -> None:
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][4] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def prune(proj: G2sc.G2Project) -> None:
    hist = proj.histogram(0)
    # Explicitly use the complete measured range.
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    for phase in proj.phases():
        hap = phase.data["Histograms"][hist.name]
        size = float(hap["Size"][1][0])
        strain = float(hap["Mustrain"][1][0])
        neutral_size(hap)
        neutral_strain(hap)
        if phase.name == "PbWO4_stolzite":
            hap["Size"][1][0] = size
            hap["Size"][2][0] = True
        elif phase.name == "WO3_monoclinic":
            hap["Mustrain"][1][0] = strain
            hap["Mustrain"][2][0] = True
        elif phase.name == "Pb3O4_minium":
            hap["Size"][1][0] = size
            hap["Size"][2][0] = True
            hap["Mustrain"][1][0] = strain
            hap["Mustrain"][2][0] = True
        elif phase.name == "PbO_massicot":
            hap["Mustrain"][1][0] = strain
            hap["Mustrain"][2][0] = True
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]
        hap["Scale"][1] = True
        phase.set_refinements({"Cell": True})

    inst = hist.data["Instrument Parameters"][0]
    for key in ("Zero", "Polariz.", "V", "X", "Y", "Z", "SH/L"):
        inst[key][2] = False
    inst["Zero"][1] = 0.0
    inst["Polariz."][1] = 1.0
    inst["V"][1] = 0.0
    inst["X"][1] = 0.0
    inst["Y"][1] = 0.0
    inst["Z"][1] = 0.0
    inst["SH/L"][1] = 0.002
    inst["U"][2] = True
    inst["W"][2] = True

    sample = hist.data["Sample Parameters"]
    sample["Shift"][1] = True
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    hist.data["Background"][0][1] = True


def refine_and_save(source: Path, destination: Path, cycles: int) -> None:
    proj = G2sc.G2Project(str(source), newgpx=str(destination))
    prune(proj)
    proj.data["Controls"]["data"]["max cyc"] = 8
    proj.data["Controls"]["data"]["min dM/M"] = 1e-5
    for _ in range(cycles):
        proj.refine()
    proj.save()


def main() -> None:
    G2sc.SetPrintLevel("warn")
    refine_and_save(SOURCE, PROJECT, 3)
    # Reopen the exact saved project and replay once more before all exports.
    proj = G2sc.G2Project(str(PROJECT))
    prune(proj)
    proj.data["Controls"]["data"]["max cyc"] = 8
    proj.data["Controls"]["data"]["min dM/M"] = 1e-5
    proj.refine()
    proj.save()

    hist = proj.histogram(0)
    for phase in proj.phases():
        phase.export_CIF(str(PHASE_FILES[phase.name]))

    x = hist.getdata("x")
    observed = hist.getdata("yobs")
    calculated = hist.getdata("ycalc")
    background = hist.getdata("background")
    with (WORK / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "background", "difference"]
        )
        for row in zip(x, observed, calculated, background):
            writer.writerow([*map(float, row), float(row[1] - row[2])])

    cov = proj.data["Covariance"]["data"]
    inst = hist.data["Instrument Parameters"][0]
    summary = {
        "residuals": hist.residuals,
        "Rvals": cov["Rvals"],
        "fractions": {
            key: {"value": float(value[0]), "esd": float(value[1])}
            for key, value in hist.ComputeMassFracs().items()
        },
        "instrument": {
            key: float(inst[key][1]) for key in ("U", "W", "X", "Polariz.")
        },
        "sample_shift_micrometre": float(hist.data["Sample Parameters"]["Shift"][0]),
        "limits_deg": list(map(float, hist.data["Limits"][1])),
        "cells": {},
    }
    for phase in proj.phases():
        cell, esd = phase.get_cell_and_esd()
        summary["cells"][phase.name] = {"value": cell, "esd": esd}
    print(json.dumps(summary, sort_keys=True, default=float))


if __name__ == "__main__":
    main()
