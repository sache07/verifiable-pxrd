#!/usr/bin/env python3
"""Replay phase-profile alternatives from one saved GSAS-II checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
BASE = (
    WORK
    / ".tmp/source_trials/PbWO4_stolzite_9009811_elaborated.gpx"
)
PHASES = {
    "PbWO4": "PbWO4_stolzite",
    "WO3": "WO3_monoclinic",
    "Pb3O4": "Pb3O4_minium",
    "PbO": "PbO_massicot",
}
SIZE_START = {"PbWO4": 0.0505, "WO3": 0.20, "Pb3O4": 0.0281, "PbO": 0.0445}
UNIAXIAL_AXIS = {
    "PbWO4": [0, 0, 1],
    "WO3": [0, 0, 1],
    "Pb3O4": [0, 0, 1],
    "PbO": [0, 0, 1],
}


def neutral_profile(hap: dict) -> None:
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Size"][4] = [10.0, 10.0, 10.0, 0.0, 0.0, 0.0]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][4] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def set_profile(hap: dict, formula: str, mode: str) -> None:
    neutral_profile(hap)
    if mode in ("size", "combined"):
        hap["Size"][1] = [SIZE_START[formula], 10.0, 1.0]
        hap["Size"][2][0] = True
    if mode in ("strain", "combined"):
        hap["Mustrain"][1] = [1000.0, 0.0, 1.0]
        hap["Mustrain"][2][0] = True
    if mode == "uniaxial_size":
        hap["Size"][0] = "uniaxial"
        hap["Size"][1] = [SIZE_START[formula], SIZE_START[formula], 1.0]
        hap["Size"][2] = [True, True, False]
        hap["Size"][3] = list(UNIAXIAL_AXIS[formula])


def run(formula: str, mode: str, output_dir: Path, base: Path = BASE) -> dict:
    output = output_dir / f"{formula}_{mode}.gpx"
    proj = G2sc.G2Project(str(base), newgpx=str(output))
    hist = proj.histogram(0)
    phase = proj.phase(PHASES[formula])
    hap = phase.data["Histograms"][hist.name]
    set_profile(hap, formula, mode)

    # The boundary-seeking free polarization trial has already been replayed;
    # use its physical limiting value as a fixed common correction here.
    inst = hist.data["Instrument Parameters"][0]
    inst["Polariz."][1] = 1.0
    inst["Polariz."][2] = False
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    proj.data["Controls"]["data"]["max cyc"] = 8
    proj.data["Controls"]["data"]["min dM/M"] = 1e-4
    for _ in range(3):
        proj.refine()
    proj.save()

    fractions = hist.ComputeMassFracs()
    size = hap["Size"]
    strain = hap["Mustrain"]
    values = proj.data["Covariance"]["data"].get("variables", [])
    vary = proj.data["Covariance"]["data"].get("varyList", [])
    sig = proj.data["Covariance"]["data"].get("sig", [])
    refined = {
        str(key): {"value": float(value), "esd": float(esd)}
        for key, value, esd in zip(vary, values, sig)
        if str(key).startswith(f"{phase.id}:{hist.id}:")
        and ("Size" in str(key) or "Mustrain" in str(key))
    }
    collapsed = False
    if mode in ("size", "combined", "uniaxial_size"):
        active_sizes = [size[1][i] for i, flag in enumerate(size[2][:2]) if flag]
        collapsed = any(value <= 0.00101 or value >= 9.5 for value in active_sizes)
    if mode in ("strain", "combined"):
        active_strains = [
            strain[1][i] for i, flag in enumerate(strain[2][:2]) if flag
        ]
        collapsed = collapsed or any(value <= 0.0 for value in active_strains)

    return {
        "phase": formula,
        "mode": mode,
        "project": str(output),
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "collapsed_or_bound": bool(collapsed),
        "size": size,
        "mustrain": strain,
        "refined_profile": refined,
        "fractions": {
            key: {"value": float(value[0]), "esd": float(value[1])}
            for key, value in fractions.items()
        },
        "instrument": {
            key: float(inst[key][1]) for key in ("Zero", "W", "U", "X", "Polariz.")
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=tuple(PHASES))
    parser.add_argument(
        "--modes",
        nargs="+",
        choices=("neutral", "size", "strain", "combined", "uniaxial_size"),
        default=("neutral", "size", "strain", "combined"),
    )
    parser.add_argument("--output-dir", type=Path, default=WORK / ".tmp/profile_trials")
    parser.add_argument("--base", type=Path, default=BASE)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    for mode in args.modes:
        try:
            result = run(args.phase, mode, args.output_dir, args.base)
        except Exception as exc:
            result = {"phase": args.phase, "mode": mode, "error": repr(exc)}
        print(json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
