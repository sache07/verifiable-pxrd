#!/usr/bin/env python3
"""Rebuild and compare GSAS-II phase-source models from common seeds.

This is an audit utility for the current dataset. Each model is rebuilt from
the raw pattern so a rejected trial cannot leak parameter values into another.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod(cod_id: str) -> str:
    return str(COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif")


SOURCES = {
    "PbWO4": {
        "stolzite_9009811": cod("9009811"),
        "stolzite_1527935": cod("1527935"),
        "raspite_9007617": cod("9007617"),
    },
    "WO3": {
        "monoclinic_2311041": cod("2311041"),
        "monoclinic_1528915": cod("1528915"),
        "monoclinic_1563541": cod("1563541"),
        "orthorhombic_2107312": cod("2107312"),
    },
    "Pb3O4": {
        "tetragonal_9012124": cod("9012124"),
        "tetragonal_1537983": cod("1537983"),
        "orthorhombic_9013442": str(WORK / "candidates/pb3o4_9013442_clean.cif"),
        "orthorhombic_9003043": cod("9003043"),
    },
    "PbO": {
        "massicot_2310433": cod("2310433"),
        "litharge_9012700": cod("9012700"),
        "orthorhombic_1533609": cod("1533609"),
    },
}

BASELINE = {
    "PbWO4": "stolzite_9009811",
    "WO3": "monoclinic_2311041",
    "Pb3O4": "tetragonal_9012124",
    "PbO": "massicot_2310433",
}

PHASE_NAMES = {
    "PbWO4": "PbWO4_stolzite",
    "WO3": "WO3_monoclinic",
    "Pb3O4": "Pb3O4_minium",
    "PbO": "PbO_massicot",
}

# Seeds are taken from the first stable four-phase replay. They are starting
# values only and are re-refined independently for every source model.
SCALE_SEEDS = {"PbWO4": 7.0, "WO3": 2.1, "Pb3O4": 1.4, "PbO": 1.1}
SIZE_SEEDS = {"PbWO4": 0.0505, "Pb3O4": 0.0281, "PbO": 0.0447}
BACKGROUND_SEED = [
    1471.0,
    -1174.0,
    655.0,
    -286.0,
    94.0,
    -35.0,
]


def neutralize_hap(hap: dict) -> None:
    """Set phase-specific profile and intensity modifiers to neutral values."""
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Size"][4] = [10.0, 10.0, 10.0, 0.0, 0.0, 0.0]
    hap["Size"][5] = [False] * len(hap["Size"][5])

    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][4] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])

    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def build_model(
    changed_phase: str,
    source_key: str,
    mode: str,
    output_dir: Path,
) -> dict:
    selected = dict(BASELINE)
    selected[changed_phase] = source_key
    tag = f"{changed_phase}_{source_key}_{mode}".replace("/", "-")
    output = output_dir / f"{tag}.gpx"

    proj = G2sc.G2Project(newgpx=str(output))
    hist = proj.add_powder_histogram(
        str(WORK / "inputs/pattern.csv"),
        str(WORK / "instrument.instprm"),
        fmthint="comma",
    )

    phase_objects = {}
    for formula in ("PbWO4", "WO3", "Pb3O4", "PbO"):
        phase = proj.add_phase(
            SOURCES[formula][selected[formula]],
            phasename=PHASE_NAMES[formula],
            histograms=[hist],
        )
        phase_objects[formula] = phase
        hap = phase.data["Histograms"][hist.name]
        neutralize_hap(hap)
        hap["Scale"] = [SCALE_SEEDS[formula], True]
        if mode == "elaborated" and formula in SIZE_SEEDS:
            hap["Size"][1][0] = SIZE_SEEDS[formula]
            hap["Size"][2][0] = True
        phase.set_refinements({"Cell": True})

    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key] = [0.0, False]

    inst = hist.data["Instrument Parameters"][0]
    starts = {
        "Zero": 0.4406,
        "Polariz.": 1.0,
        "U": 2.0,
        "V": 0.0,
        "W": 29.2,
        "X": 0.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }
    for key, value in starts.items():
        inst[key][1] = value
        inst[key][2] = False

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": len(BACKGROUND_SEED),
                "coeffs": BACKGROUND_SEED,
            },
            "Instrument Parameters": ["Zero", "W"],
        }
    )
    proj.data["Controls"]["data"]["max cyc"] = 8
    proj.data["Controls"]["data"]["min dM/M"] = 1e-4

    # Repeated calls force a full replay after the large first scale/cell move.
    for _ in range(3 if mode == "elaborated" else 2):
        proj.refine()
    proj.save()

    fractions = hist.ComputeMassFracs()
    result = {
        "changed_phase": changed_phase,
        "source": source_key,
        "mode": mode,
        "project": str(output),
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "fractions": {
            key: {"value": float(value[0]), "esd": float(value[1])}
            for key, value in fractions.items()
        },
        "instrument": {
            key: float(inst[key][1]) for key in ("Zero", "Polariz.", "U", "W", "X")
        },
        "phases": {},
    }
    for formula, phase in phase_objects.items():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][formula] = {
            "scale": float(hap["Scale"][0]),
            "cell": {key: float(value) for key, value in phase.get_cell().items()},
            "size_micrometre": float(hap["Size"][1][0]),
            "microstrain": float(hap["Mustrain"][1][0]),
        }
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=tuple(SOURCES))
    parser.add_argument(
        "--mode", choices=("neutral", "elaborated", "both"), default="both"
    )
    parser.add_argument("--source", choices=None)
    parser.add_argument("--output-dir", type=Path, default=WORK / ".tmp/source_trials")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    modes = ("neutral", "elaborated") if args.mode == "both" else (args.mode,)
    G2sc.SetPrintLevel("warn")
    if args.source is not None and args.source not in SOURCES[args.phase]:
        parser.error(f"unknown source for {args.phase}: {args.source}")
    source_keys = [args.source] if args.source is not None else SOURCES[args.phase]
    for source_key in source_keys:
        for mode in modes:
            try:
                row = build_model(args.phase, source_key, mode, args.output_dir)
            except Exception as exc:
                row = {
                    "changed_phase": args.phase,
                    "source": source_key,
                    "mode": mode,
                    "error": repr(exc),
                }
            print(json.dumps(row, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
