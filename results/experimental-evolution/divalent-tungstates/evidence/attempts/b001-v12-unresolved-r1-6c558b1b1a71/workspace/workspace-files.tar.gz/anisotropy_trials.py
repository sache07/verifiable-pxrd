#!/usr/bin/env python3
"""Challenge accepted isotropic phase broadening with simple uniaxial models."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
BASE = WORK / ".tmp/accepted_loop1.gpx"
PHASES = {
    "PbWO4": "PbWO4_stolzite",
    "WO3": "WO3_monoclinic",
    "Pb3O4": "Pb3O4_minium",
    "PbO": "PbO_massicot",
}


def run(formula: str, term: str, axis: list[int], output_dir: Path, base: Path) -> dict:
    axis_tag = "".join(str(i) for i in axis)
    output = output_dir / f"{formula}_{term}_{axis_tag}.gpx"
    proj = G2sc.G2Project(str(base), newgpx=str(output))
    hist = proj.histogram(0)
    phase = proj.phase(PHASES[formula])
    hap = phase.data["Histograms"][hist.name]
    key = "Size" if term == "size" else "Mustrain"
    profile = hap[key]
    start = float(profile[1][0])
    profile[0] = "uniaxial"
    profile[1][0] = start
    profile[1][1] = start
    profile[2] = [True, True, False]
    profile[3] = list(axis)

    # Keep the already accepted complementary size/strain term unchanged.
    inst = hist.data["Instrument Parameters"][0]
    inst["Polariz."][1:] = [1.0, False]
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    proj.data["Controls"]["data"]["max cyc"] = 8
    proj.data["Controls"]["data"]["min dM/M"] = 1e-4
    for _ in range(4):
        proj.refine()
    proj.save()

    vals = profile[1][:2]
    if term == "size":
        collapsed = any(v <= 0.00101 or v >= 9.5 for v in vals)
    else:
        collapsed = any(v <= 0.0 or v >= 1.0e5 for v in vals)
    fractions = hist.ComputeMassFracs()
    vary = proj.data["Covariance"]["data"].get("varyList", [])
    values = proj.data["Covariance"]["data"].get("variables", [])
    sig = proj.data["Covariance"]["data"].get("sig", [])
    refined = {
        str(k): {"value": float(v), "esd": float(s)}
        for k, v, s in zip(vary, values, sig)
        if str(k).startswith(f"{phase.id}:{hist.id}:")
        and ("Size" in str(k) or "Mustrain" in str(k))
    }
    return {
        "phase": formula,
        "term": term,
        "axis": axis,
        "project": str(output),
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "collapsed_or_bound": bool(collapsed),
        "profile": profile,
        "refined_profile": refined,
        "fractions": {
            name: {"value": float(value[0]), "esd": float(value[1])}
            for name, value in fractions.items()
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=tuple(PHASES))
    parser.add_argument("term", choices=("size", "strain"))
    parser.add_argument("axis", nargs=3, type=int)
    parser.add_argument("--base", type=Path, default=BASE)
    parser.add_argument("--output-dir", type=Path, default=WORK / ".tmp/anisotropy")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    try:
        result = run(args.phase, args.term, args.axis, args.output_dir, args.base)
    except Exception as exc:
        result = {"phase": args.phase, "term": args.term, "axis": args.axis, "error": repr(exc)}
    print(json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
