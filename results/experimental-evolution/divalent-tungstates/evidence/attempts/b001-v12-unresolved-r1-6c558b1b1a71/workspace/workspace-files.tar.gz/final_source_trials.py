#!/usr/bin/env python3
"""Rebuild source competitors with the converged common profile checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import model_trials as mt


WORK = Path(__file__).resolve().parent
CHECKPOINT = WORK / ".tmp/common_isotropic.gpx"


def run(changed_phase: str, source_key: str, output_dir: Path) -> dict:
    seed = G2sc.G2Project(str(CHECKPOINT))
    seed_hist = seed.histogram(0)
    seed_inst = seed_hist.data["Instrument Parameters"][0]
    seed_sample = seed_hist.data["Sample Parameters"]
    seed_background = list(seed_hist.data["Background"][0][3:])
    seed_haps = {
        formula: seed.phase(mt.PHASE_NAMES[formula]).data["Histograms"][seed_hist.name]
        for formula in mt.PHASE_NAMES
    }

    selected = dict(mt.BASELINE)
    selected[changed_phase] = source_key
    tag = f"{changed_phase}_{source_key}".replace("/", "-")
    output = output_dir / f"{tag}.gpx"
    proj = G2sc.G2Project(newgpx=str(output))
    hist = proj.add_powder_histogram(
        str(WORK / "inputs/pattern.csv"),
        str(WORK / "instrument.instprm"),
        fmthint="comma",
    )

    phase_objects = {}
    for formula in ("PbWO4", "WO3", "Pb3O4", "PbO"):
        phase = proj.add_phase(
            mt.SOURCES[formula][selected[formula]],
            phasename=mt.PHASE_NAMES[formula],
            histograms=[hist],
        )
        phase_objects[formula] = phase
        hap = phase.data["Histograms"][hist.name]
        mt.neutralize_hap(hap)
        old = seed_haps[formula]
        hap["Scale"] = [float(old["Scale"][0]), True]
        if formula == "PbWO4":
            hap["Size"][1][0] = float(old["Size"][1][0])
            hap["Size"][2][0] = True
        elif formula == "WO3":
            hap["Mustrain"][1][0] = float(old["Mustrain"][1][0])
            hap["Mustrain"][2][0] = True
        elif formula == "Pb3O4":
            hap["Size"][1][0] = float(old["Size"][1][0])
            hap["Size"][2][0] = True
            hap["Mustrain"][1][0] = float(old["Mustrain"][1][0])
            hap["Mustrain"][2][0] = True
        elif formula == "PbO":
            hap["Mustrain"][1][0] = float(old["Mustrain"][1][0])
            hap["Mustrain"][2][0] = True
        phase.set_refinements({"Cell": True})

    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [float(seed_sample["Shift"][0]), True]
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key] = [0.0, False]

    inst = hist.data["Instrument Parameters"][0]
    for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"):
        inst[key][1] = float(seed_inst[key][1])
        inst[key][2] = key in ("U", "W")
    inst["Zero"][1:] = [0.0, False]
    inst["Polariz."][1:] = [1.0, False]
    inst["X"][1:] = [0.0, False]

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": len(seed_background),
                "coeffs": seed_background,
            }
        }
    )
    proj.data["Controls"]["data"]["max cyc"] = 8
    proj.data["Controls"]["data"]["min dM/M"] = 1e-5
    for _ in range(6):
        proj.refine()
    proj.save()

    covariance = proj.data["Covariance"]["data"]
    fractions = hist.ComputeMassFracs()
    result = {
        "changed_phase": changed_phase,
        "source": source_key,
        "project": str(output),
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "GOF": float(covariance["Rvals"]["GOF"]),
        "max_shift_esd": float(covariance["Rvals"].get("Max shft/sig", 0.0)),
        "fractions": {
            name: {"value": float(value[0]), "esd": float(value[1])}
            for name, value in fractions.items()
        },
        "instrument": {
            key: float(inst[key][1]) for key in ("U", "W", "X", "Polariz.")
        },
        "sample_shift_micrometre": float(sample["Shift"][0]),
        "phases": {},
    }
    for formula, phase in phase_objects.items():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][formula] = {
            "scale": float(hap["Scale"][0]),
            "cell": {key: float(value) for key, value in phase.get_cell().items()},
            "size_micrometre": float(hap["Size"][1][0]),
            "microstrain": float(hap["Mustrain"][1][0]),
        }
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=tuple(mt.SOURCES))
    parser.add_argument("source", choices=None)
    parser.add_argument("--output-dir", type=Path, default=WORK / ".tmp/final_source_trials")
    args = parser.parse_args()
    if args.source not in mt.SOURCES[args.phase]:
        parser.error(f"unknown source for {args.phase}: {args.source}")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    try:
        result = run(args.phase, args.source, args.output_dir)
    except Exception as exc:
        result = {"changed_phase": args.phase, "source": args.source, "error": repr(exc)}
    print(json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
