#!/usr/bin/env python3
"""Challenge common intensity/profile nuisance terms and replay the result."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--asymmetry", action="store_true")
    args = parser.parse_args()
    output = Path(args.output).resolve()
    gpx = G2sc.G2Project(str(Path(args.base).resolve()), newgpx=str(output))
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    inst["Polariz."][2] = bool(args.polarization)
    inst["SH/L"][2] = bool(args.asymmetry)
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, bool(args.roughness)]
    gpx.set_Controls("cycles", 12)
    gpx.save()
    if args.polarization:
        gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    if args.roughness:
        gpx.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    if args.asymmetry:
        gpx.set_Controls("parmMin", 0.0005, variable=":0:SH/L")
    gpx.refine(makeBack=False)
    gpx.save()
    reopened = G2sc.G2Project(str(output))
    reopened.refine(makeBack=False)
    reopened.save()
    hist = reopened.histogram(0)
    print(
        "NUISANCE_SUMMARY "
        + json.dumps(
            {
                "polarization_refined": args.polarization,
                "roughness_refined": args.roughness,
                "asymmetry_refined": args.asymmetry,
                "polarization": float(hist.InstrumentParameters["Polariz."][1]),
                "roughness_A": float(hist.SampleParameters["SurfRoughA"][0]),
                "roughness_B": float(hist.SampleParameters["SurfRoughB"][0]),
                "SH/L": float(hist.InstrumentParameters["SH/L"][1]),
                "residuals": hist.residuals,
                "mass_fractions": {
                    k: [float(v[0]), float(v[1])]
                    for k, v in hist.ComputeMassFracs().items()
                },
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
