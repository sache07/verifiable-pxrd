#!/usr/bin/env python3
"""Remove one accepted texture term, reconverge, reopen and replay."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", required=True)
    args = parser.parse_args()
    output = Path(args.output).resolve()
    gpx = G2sc.G2Project(str(Path(args.base).resolve()), newgpx=str(output))
    hist = gpx.histogram(0)
    po = gpx.phase(args.phase).data["Histograms"][hist.name]["Pref.Ori."]
    po[1], po[2] = 1.0, False
    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    reopened = G2sc.G2Project(str(output))
    reopened.refine(makeBack=False)
    reopened.save()
    hist = reopened.histogram(0)
    print(
        "PRUNE_SUMMARY "
        + json.dumps(
            {
                "removed_phase_texture": args.phase,
                "residuals": hist.residuals,
                "mass_fractions": {
                    k: [float(v[0]), float(v[1])]
                    for k, v in hist.ComputeMassFracs().items()
                },
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
