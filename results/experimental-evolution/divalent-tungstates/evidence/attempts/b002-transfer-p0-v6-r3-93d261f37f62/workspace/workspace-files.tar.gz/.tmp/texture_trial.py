#!/usr/bin/env python3
"""Test one March-Dollase axis from a converged common-profile project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", default="MgWO4")
    parser.add_argument("--axis", nargs=3, type=int, required=True)
    parser.add_argument("--preserve-other", action="store_true")
    args = parser.parse_args()

    output = Path(args.output).resolve()
    gpx = G2sc.G2Project(str(Path(args.base).resolve()), newgpx=str(output))
    hist = gpx.histogram(0)
    # Ensure only this texture trial is active unless an already accepted
    # orientation on another phase is explicitly preserved.
    phases_to_clear = (
        [gpx.phase(args.phase)] if args.preserve_other else gpx.phases()
    )
    for phase in phases_to_clear:
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", 1.0, False, [0, 0, 1]
    po = gpx.phase(args.phase).data["Histograms"][hist.name]["Pref.Ori."]
    po[1], po[2], po[3] = 1.0, True, list(args.axis)
    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    reopened = G2sc.G2Project(str(output))
    reopened.refine(makeBack=False)
    reopened.save()
    hist = reopened.histogram(0)
    phase = reopened.phase(args.phase)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    print(
        "TEXTURE_SUMMARY "
        + json.dumps(
            {
                "phase": args.phase,
                "axis": list(args.axis),
                "coefficient": float(po[1]),
                "residuals": hist.residuals,
                "mass_fractions": {
                    k: [float(v[0]), float(v[1])]
                    for k, v in hist.ComputeMassFracs().items()
                },
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
