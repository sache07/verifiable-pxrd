#!/usr/bin/env python3
"""Independent CIF readback and first-shell cation--oxygen geometry check."""

from __future__ import annotations

import json
from pathlib import Path

from ase.io import read
from ase.neighborlist import neighbor_list


WORK = Path(__file__).resolve().parents[1]


def first_shell(path: Path):
    atoms = read(path)
    i_idx, j_idx, distance = neighbor_list("ijd", atoms, 3.0)
    shells = {}
    for i, symbol in enumerate(atoms.get_chemical_symbols()):
        if symbol not in {"Mg", "W"}:
            continue
        values = sorted(
            float(d)
            for ii, jj, d in zip(i_idx, j_idx, distance)
            if ii == i and atoms[jj].symbol == "O"
        )[:6]
        shells[f"{symbol}{i + 1}"] = values
    return {
        "formula": atoms.get_chemical_formula(),
        "cell": atoms.cell.cellpar().tolist(),
        "cation_oxygen_first_shells_angstrom": shells,
    }


print(
    json.dumps(
        {name: first_shell(WORK / f"{name}.cif") for name in ("MgWO4", "WO3", "MgO")},
        indent=2,
        sort_keys=True,
    )
)
