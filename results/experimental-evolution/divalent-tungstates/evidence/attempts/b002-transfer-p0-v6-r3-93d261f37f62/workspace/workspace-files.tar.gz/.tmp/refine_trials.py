#!/usr/bin/env python3
"""Build reproducible GSAS-II trial refinements for phase-inventory tests."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize_hap(phase, hist_name: str, initial_scale: float) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"] = [float(initial_scale), False]
    hap["Pref.Ori."] = ["MD", 1.0, False, [0, 0, 1], 0, {}, [], 0.1]
    # Size is in micrometres; GSAS-II's allowed maximum of 10 and zero
    # microstrain are effectively neutral relative to this laboratory profile.
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][4] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}


def set_inst_value(inst: dict, key: str, value: float, refine: bool = False) -> None:
    inst[key][0] = float(value)
    inst[key][1] = float(value)
    inst[key][2] = bool(refine)


def summarize(gpx, label: str) -> dict:
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    out = {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {
            k: {"value": float(inst[k][1]), "refine": bool(inst[k][2])}
            for k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)")
        },
        "background": {
            "type": hist.Background[0][0],
            "coefficients": [float(x) for x in hist.Background[0][3:]],
        },
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "scale": float(hap["Scale"][0]),
            "cell": {k: float(v) for k, v in phase.get_cell().items()},
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    try:
        out["mass_fractions"] = {
            k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        out["mass_fraction_error"] = str(exc)
    print("SUMMARY " + json.dumps(out, sort_keys=True))
    return out


def refine_and_report(gpx, label: str) -> dict:
    gpx.refine(makeBack=False)
    return summarize(gpx, label)


def build(args) -> None:
    output = Path(args.output).resolve()
    if output.exists():
        output.unlink()
    gpx = G2sc.G2Project(newgpx=str(output))
    hist = gpx.add_powder_histogram(
        str(WORK / "inputs" / "pattern.csv"),
        str(WORK / ".tmp" / "lab_cuka.instprm"),
        fmthint="comma/tab/semicolon",
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    # Smooth low-order background, initialized at the observed baseline.
    hist.Background[0][:] = ["chebyschev-1", False, 6, 3600.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    inst = hist.InstrumentParameters
    for key, value in {
        "Zero": 0.0,
        "U": 10.0,
        "V": 0.0,
        "W": 25.0,
        "X": 2.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "I(L2)/I(L1)": 0.5,
        "Polariz.": 0.7,
    }.items():
        set_inst_value(inst, key, value, False)
    # No sample nuisance parameter is active; only instrument Zero will be used.
    for key, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], (bool, np.bool_)):
            value[1] = False

    specs = [
        ("MgWO4", "9013902", 1.0),
        ("WO3", args.wo3, 0.35),
    ]
    if args.mgo:
        specs.append(("MgO", "9000499", 0.03))
    for name, cod_id, scale in specs:
        phase = gpx.add_phase(
            str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
        )
        neutralize_hap(phase, hist.name, scale)
        for atom in phase.atoms():
            atom.refinement_flags = " "

    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    gpx.save()
    summarize(gpx, "initial")

    # Establish inventory under a common neutral profile.
    hist.set_refinements({"Background": {"refine": True}})
    for phase in gpx.phases():
        phase.set_HAP_refinements({"Scale": True}, [hist])
    refine_and_report(gpx, "scales_background")

    # Reconcile positions using one angular correction and symmetry-constrained cells.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    refine_and_report(gpx, "zero_cells")

    # Build a nonnegative, low-dimensional common profile sequentially.
    for term in ("W", "U", "X"):
        hist.set_refinements({"Instrument Parameters": [term]})
        refine_and_report(gpx, f"profile_{term}")

    if args.asymmetry:
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        refine_and_report(gpx, "asymmetry")

    # Re-converge all accepted common terms and save/reopen/replay.
    refine_and_report(gpx, "reconverged")
    gpx.save()
    reopened = G2sc.G2Project(str(output))
    reopened.refine(makeBack=False)
    summarize(reopened, "reopened_replay")
    reopened.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", default="2311041")
    parser.add_argument("--mgo", action="store_true")
    parser.add_argument("--asymmetry", action="store_true")
    parser.add_argument("--output", required=True)
    build(parser.parse_args())


if __name__ == "__main__":
    main()
