#!/usr/bin/env python3
"""Refine selected atomic coordinates, replay, and export for geometry checks."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--selection", choices=["all", "cations", "tungsten"], required=True)
    args = parser.parse_args()
    output = Path(args.output).resolve()
    gpx = G2sc.G2Project(str(Path(args.base).resolve()), newgpx=str(output))
    for phase in gpx.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    phase = gpx.phase(args.phase)
    selected = []
    for atom in phase.atoms():
        use = args.selection == "all"
        if args.selection == "cations":
            use = atom.element != "O"
        elif args.selection == "tungsten":
            use = atom.element == "W"
        if use:
            atom.refinement_flags = "X"
            selected.append(atom.label)
    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    reopened = G2sc.G2Project(str(output))
    reopened.refine(makeBack=False)
    reopened.save()
    phase = reopened.phase(args.phase)
    phase.export_CIF(str(output.with_suffix(".cif")))
    hist = reopened.histogram(0)
    print(
        "COORDINATE_SUMMARY "
        + json.dumps(
            {
                "phase": args.phase,
                "selection": args.selection,
                "selected_atoms": selected,
                "residuals": hist.residuals,
                "mass_fractions": {
                    k: [float(v[0]), float(v[1])]
                    for k, v in hist.ComputeMassFracs().items()
                },
                "atoms": {
                    atom.label: {
                        "element": atom.element,
                        "coordinates": [float(x) for x in atom.coordinates],
                        "uiso": float(atom.uiso),
                    }
                    for atom in phase.atoms()
                },
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
