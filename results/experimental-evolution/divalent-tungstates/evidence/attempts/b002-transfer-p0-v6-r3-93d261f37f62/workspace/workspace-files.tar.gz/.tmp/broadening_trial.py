#!/usr/bin/env python3
"""Test one phase-specific size or microstrain term from neutral values."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument(
        "--term", choices=["size", "strain", "strain_mix"], required=True
    )
    parser.add_argument("--preserve-accepted", action="store_true")
    args = parser.parse_args()

    output = Path(args.output).resolve()
    gpx = G2sc.G2Project(str(Path(args.base).resolve()), newgpx=str(output))
    hist = gpx.histogram(0)
    # Return all phase-specific broadening to neutral before one-term tests.
    # For combination tests, retain the already accepted term(s).
    if not args.preserve_accepted:
        for phase in gpx.phases():
            hap = phase.data["Histograms"][hist.name]
            hap["Size"][0] = "isotropic"
            hap["Size"][1] = [10.0, 10.0, 1.0]
            hap["Size"][2] = [False, False, False]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1] = [0.0, 0.0, 1.0]
            hap["Mustrain"][2] = [False, False, False]
    phase = gpx.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    gpx.set_Controls("cycles", 12)
    gpx.save()
    if args.term == "size":
        hap["Size"][2][0] = True
        variable = f"{phase.id}:{hist.id}:Size;i"
        gpx.set_Controls("parmMin", 0.01, variable=variable)
        gpx.set_Controls("parmMax", 10.0, variable=variable)
    elif args.term == "strain":
        hap["Mustrain"][2][0] = True
        variable = f"{phase.id}:{hist.id}:Mustrain;i"
        gpx.set_Controls("parmMin", 0.0, variable=variable)
        gpx.set_Controls("parmMax", 10000.0, variable=variable)
    else:
        hap["Mustrain"][2][2] = True
        variable = f"{phase.id}:{hist.id}:Mustrain;mx"
        gpx.set_Controls("parmMin", 0.0, variable=variable)
        gpx.set_Controls("parmMax", 1.0, variable=variable)
    gpx.refine(makeBack=False)
    gpx.save()
    reopened = G2sc.G2Project(str(output))
    reopened.refine(makeBack=False)
    reopened.save()
    hist = reopened.histogram(0)
    phase = reopened.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    print(
        "BROADENING_SUMMARY "
        + json.dumps(
            {
                "phase": args.phase,
                "term": args.term,
                "size_um": float(hap["Size"][1][0]),
                "microstrain": float(hap["Mustrain"][1][0]),
                "strain_LGmix": float(hap["Mustrain"][1][2]),
                "residuals": hist.residuals,
                "mass_fractions": {
                    k: [float(v[0]), float(v[1])]
                    for k, v in hist.ComputeMassFracs().items()
                },
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
