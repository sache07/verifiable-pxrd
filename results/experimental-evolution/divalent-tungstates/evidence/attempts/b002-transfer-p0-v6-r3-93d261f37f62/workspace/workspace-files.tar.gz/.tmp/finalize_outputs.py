#!/usr/bin/env python3
"""Replay the accepted model and export synchronized final deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
SOURCE = WORK / ".tmp" / "coords_combined.gpx"
FINAL = WORK / "final.gpx"
RANGE = (10.0, 100.0)

PHASE_META = {
    "MgWO4": {"formula": "MgWO4", "source_cod_id": "9013902"},
    "WO3": {"formula": "WO3", "source_cod_id": "2311041"},
    "MgO": {"formula": "MgO", "source_cod_id": "9000499"},
}


def f(value):
    """Convert numpy scalar values to JSON-safe Python floats."""
    return float(value)


def set_bound(gpx, variable: str, lower=None, upper=None) -> None:
    if lower is not None:
        gpx.set_Controls("parmMin", float(lower), variable=variable)
    if upper is not None:
        gpx.set_Controls("parmMax", float(upper), variable=variable)


def configure_physical_bounds(gpx) -> None:
    """Keep accepted profile and microstructure terms in physical domains."""
    for variable in (":0:U", ":0:W", ":0:X"):
        set_bound(gpx, variable, lower=0.0)
    set_bound(gpx, ":0:SH/L", lower=0.0005)
    set_bound(gpx, ":0:Polariz.", lower=0.0, upper=1.0)
    set_bound(gpx, "0:0:MD", lower=0.3, upper=3.0)
    set_bound(gpx, "1:0:MD", lower=0.3, upper=3.0)
    set_bound(gpx, "1:0:Size;i", lower=0.01, upper=10.0)
    set_bound(gpx, "1:0:Mustrain;i", lower=0.0, upper=10000.0)


def replay_final_project() -> G2sc.G2Project:
    if FINAL.exists():
        FINAL.unlink()
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    hist = gpx.histogram(0)
    hist.set_refinements({"Limits": list(RANGE)})

    # Polarization was accepted in the common-profile challenge. A later
    # one-term asymmetry trial retained its value but inadvertently cleared
    # its refinement flag, so explicitly restore that accepted flag here.
    hist.InstrumentParameters["Polariz."][2] = True
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-7
    configure_physical_bounds(gpx)
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()

    # Required save/reopen/replay check on the complete refinement range.
    replay = G2sc.G2Project(str(FINAL))
    replay.refine(makeBack=False)
    replay.save()
    return G2sc.G2Project(str(FINAL))


def export_cifs(gpx) -> dict[str, str]:
    paths = {}
    for phase in gpx.phases():
        path = WORK / f"{phase.name}.cif"
        phase.export_CIF(str(path))
        paths[phase.name] = path.name
    return paths


def export_fit(hist) -> int:
    x = np.asarray(hist.getdata("x"), dtype=float)
    yobs = np.asarray(hist.getdata("yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("ycalc"), dtype=float)
    background = np.asarray(hist.getdata("background"), dtype=float)
    # GSAS-II evaluates one interpolating point beyond the nominal upper
    # limit. Select the exact calculated span rather than independently
    # rounding the angle endpoints, so this file contains all observations
    # counted by the final refinement (and no zero-filled excluded tails).
    use = ycalc != 0.0
    with (WORK / "fit.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        for values in zip(
            x[use],
            yobs[use],
            ycalc[use],
            yobs[use] - ycalc[use],
            background[use],
        ):
            writer.writerow([repr(float(value)) for value in values])
    return int(np.count_nonzero(use))


def build_result(gpx, cif_paths: dict[str, str], n_points: int) -> dict:
    hist = gpx.histogram(0)
    residuals = hist.residuals
    raw_mass = hist.ComputeMassFracs()
    mass_sum = sum(f(value[0]) for value in raw_mass.values())
    phases = []
    for phase in gpx.phases():
        fraction, esd = raw_mass[phase.name]
        cell = phase.get_cell()
        phases.append(
            {
                "name": phase.name,
                "formula": PHASE_META[phase.name]["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": cif_paths[phase.name],
                "source_cod_id": PHASE_META[phase.name]["source_cod_id"],
                "weight_fraction": f(fraction) / mass_sum,
                "weight_fraction_esd_formal": f(esd) / mass_sum,
                "cell": {key: f(value) for key, value in cell.items()},
                "R_bragg_percent": f(residuals[f"{phase.id}:0:Rf"]),
            }
        )

    rwp = f(residuals["wR"])
    rexp = f(residuals["wRmin"])
    result = {
        "project_path": FINAL.name,
        "phase_fraction_basis": "normalized over modeled crystalline phases",
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": f(residuals["R"]),
            "Rexp_percent": rexp,
            "goodness_of_fit": rwp / rexp,
            "reduced_chi_squared": (rwp / rexp) ** 2,
            "refinement_range_two_theta_deg": list(RANGE),
            "profile_points": n_points,
        },
        "measurement_model": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelength_Kalpha1_angstrom": f(
                hist.InstrumentParameters["Lam1"][1]
            ),
            "wavelength_Kalpha2_angstrom": f(
                hist.InstrumentParameters["Lam2"][1]
            ),
            "Kalpha2_to_Kalpha1_ratio": f(
                hist.InstrumentParameters["I(L2)/I(L1)"][1]
            ),
        },
    }
    with (WORK / "result.json").open("w", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    return result


def main() -> None:
    gpx = replay_final_project()
    cif_paths = export_cifs(gpx)
    n_points = export_fit(gpx.histogram(0))
    result = build_result(gpx, cif_paths, n_points)
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    summary = {
        "result": result,
        "instrument": {
            key: {"value": f(inst[key][1]), "refine": bool(inst[key][2])}
            for key in (
                "Zero",
                "U",
                "V",
                "W",
                "X",
                "Y",
                "Z",
                "SH/L",
                "Polariz.",
                "I(L2)/I(L1)",
            )
        },
        "background": [f(value) for value in hist.Background[0][3:]],
        "phase_model": {
            phase.name: {
                "preferred_orientation": phase.data["Histograms"][hist.name][
                    "Pref.Ori."
                ],
                "size": phase.data["Histograms"][hist.name]["Size"],
                "microstrain": phase.data["Histograms"][hist.name]["Mustrain"],
                "atoms": {
                    atom.label: {
                        "element": atom.element,
                        "coordinates": [f(v) for v in atom.coordinates],
                        "refinement_flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                },
            }
            for phase in gpx.phases()
        },
    }
    print("FINAL_SUMMARY " + json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
