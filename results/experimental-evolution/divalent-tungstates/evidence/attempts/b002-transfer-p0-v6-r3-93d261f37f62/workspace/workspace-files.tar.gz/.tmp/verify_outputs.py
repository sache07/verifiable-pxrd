#!/usr/bin/env python3
"""Cross-check the submitted artifacts against the reopened final GPX."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]


def main() -> None:
    required = [
        "final.gpx",
        "fit.csv",
        "result.json",
        "MgWO4.cif",
        "WO3.cif",
        "MgO.cif",
    ]
    assert all((WORK / name).is_file() for name in required)

    result = json.loads((WORK / "result.json").read_text())
    gpx = G2sc.G2Project(str(WORK / "final.gpx"))
    hist = gpx.histogram(0)
    project_mass = hist.ComputeMassFracs()
    submitted = {phase["name"]: phase for phase in result["phases"]}
    assert abs(sum(phase["weight_fraction"] for phase in result["phases"]) - 1) < 1e-14
    for name, values in project_mass.items():
        assert abs(submitted[name]["weight_fraction"] - float(values[0])) < 1e-14
        assert (WORK / submitted[name]["cif_path"]).is_file()

    stats = result["fit_statistics"]
    assert abs(stats["Rwp_percent"] - hist.residuals["wR"]) < 1e-14
    assert abs(stats["Rp_percent"] - hist.residuals["R"]) < 1e-14
    assert abs(stats["Rexp_percent"] - hist.residuals["wRmin"]) < 1e-14

    fit = np.genfromtxt(WORK / "fit.csv", delimiter=",", names=True)
    x = np.asarray(hist.getdata("x"), dtype=float)
    yobs = np.asarray(hist.getdata("yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("ycalc"), dtype=float)
    background = np.asarray(hist.getdata("background"), dtype=float)
    use = ycalc != 0.0
    assert len(fit) == int(np.count_nonzero(use)) == stats["profile_points"] == 8284
    assert np.array_equal(fit["two_theta_deg"], x[use])
    assert np.array_equal(fit["observed_counts"], yobs[use])
    assert np.array_equal(fit["calculated_counts"], ycalc[use])
    assert np.array_equal(fit["difference_counts"], yobs[use] - ycalc[use])
    assert np.array_equal(fit["background_counts"], background[use])
    assert np.isfinite(fit.view((float, len(fit.dtype.names)))).all()

    inst = hist.InstrumentParameters
    assert all(inst[key][1] >= 0 for key in ("U", "W", "X"))
    assert all(inst[key][1] == 0 and not inst[key][2] for key in ("V", "Y", "Z"))
    assert inst["Zero"][2]
    sample = hist.SampleParameters
    assert sample["SurfRoughA"] == [0.0, False]
    assert sample["SurfRoughB"] == [0.0, False]

    print(
        json.dumps(
            {
                "verified": required,
                "fit_points": len(fit),
                "fraction_sum": sum(
                    phase["weight_fraction"] for phase in result["phases"]
                ),
            },
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
