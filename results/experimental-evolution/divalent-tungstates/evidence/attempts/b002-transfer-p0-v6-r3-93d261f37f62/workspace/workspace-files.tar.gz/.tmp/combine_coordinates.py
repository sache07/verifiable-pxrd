#!/usr/bin/env python3
"""Combine accepted MgWO4 coordinates with WO3 W-site refinement."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
output = work / ".tmp" / "coords_combined.gpx"
gpx = G2sc.G2Project(str(work / ".tmp" / "coord_mg_all.gpx"), newgpx=str(output))
for phase in gpx.phases():
    for atom in phase.atoms():
        atom.refinement_flags = " "
for atom in gpx.phase("MgWO4").atoms():
    atom.refinement_flags = "X"
for atom in gpx.phase("WO3").atoms():
    if atom.element == "W":
        atom.refinement_flags = "X"
gpx.set_Controls("cycles", 12)
gpx.save()
gpx.refine(makeBack=False)
gpx.save()
reopened = G2sc.G2Project(str(output))
reopened.refine(makeBack=False)
reopened.save()
for phase in reopened.phases():
    phase.export_CIF(str(work / ".tmp" / f"combined_{phase.name}.cif"))
hist = reopened.histogram(0)
print(
    "COMBINED_SUMMARY "
    + json.dumps(
        {
            "residuals": hist.residuals,
            "mass_fractions": {
                k: [float(v[0]), float(v[1])]
                for k, v in hist.ComputeMassFracs().items()
            },
            "atoms": {
                phase.name: {
                    atom.label: [float(v) for v in atom.coordinates]
                    for atom in phase.atoms()
                }
                for phase in reopened.phases()
            },
        },
        sort_keys=True,
    )
)
