from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parents[1]
out = root / ".tmp" / "single.gpx"
gpx = G2sc.G2Project(newgpx=str(out))
hist = gpx.add_powder_histogram(
    str(root / "inputs" / "pattern.csv"),
    str(root / ".tmp" / "cu_ka.instprm"),
)
phase = gpx.add_phase(
    str(root / ".tmp" / "initial_mnwo4.cif"),
    phasename="MnWO4",
    histograms=[hist],
    fmthint="CIF",
)

gpx.data["Controls"]["data"]["max cyc"] = 12
gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5

# The observed pattern has a nearly constant negative angular offset relative
# to the starting cell. Seed this value so that the first least-squares cycle
# starts with overlapping peaks.
inst = hist.data["Instrument Parameters"][0]
inst["Zero"][1] = -0.23

# Establish a smooth starting background from binned lower-envelope points,
# and then allow a moderate-order Chebyshev background to refine. (The local
# GSAS-II environment does not bundle its optional pybaselines dependency.)
xobs, yobs = hist.data["data"][1][:2]
edges = np.linspace(xobs[0], xobs[-1], 121)
fixed_points = []
for lo, hi in zip(edges[:-1], edges[1:]):
    sel = (xobs >= lo) & (xobs < hi)
    fixed_points.append((float((lo + hi) / 2), float(np.percentile(yobs[sel], 20))))
hist.set_refinements({
    "Background": {
        "type": "chebyschev-1",
        "no. coeffs": 12,
        "FixedPoints": fixed_points,
        "fit fixed points": True,
        "refine": True,
    }
})

def refine(label):
    print(f"\n===== {label} =====")
    gpx.do_refinements([{}])
    gpx.save()
    print("wR", hist.get_wR())
    print("GOF", gpx.data["Covariance"]["data"].get("GOF"))

# Scale/background and peak offset.
hist.set_refinements({"Instrument Parameters": ["Zero"]})
refine("scale background zero")

# Unit cell, followed by the empirical line profile. No calibrated instrument
# profile was supplied, so these terms represent combined instrument/sample
# broadening.
phase.set_refinements({"Cell": True})
refine("cell")
hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
refine("Gaussian profile")
hist.set_refinements({"Instrument Parameters": ["X", "Y", "SH/L"]})
refine("Lorentzian profile and asymmetry")

# Atomic positions and isotropic displacement parameters are released only
# after the profile and metric have stabilized.
phase.set_refinements({"Atoms": {"all": "X"}})
refine("atomic coordinates")
phase.set_refinements({"Atoms": {"all": "XU"}})
refine("coordinates and Uiso")

# Test/refine the measured doublet ratio last.
hist.set_refinements({"Instrument Parameters": ["I(L2)/I(L1)"]})
refine("Kalpha doublet ratio")

print("\nFINAL")
print("wR", hist.get_wR())
print("cov", {k: gpx.data["Covariance"]["data"].get(k) for k in ("Rvals", "GOF", "Nobs", "Nvars")})
print("cell", phase.data["General"]["Cell"])
print("inst", hist.data["Instrument Parameters"][0])
print("background", hist.data["Background"][0])
print("sample", hist.data["Sample Parameters"])
for atom in phase.atoms():
    print("atom", atom.label, atom.element, atom.coordinates, atom.occupancy, atom.uiso, atom.refinement_flags)
print("massfracs", hist.ComputeMassFracs())
