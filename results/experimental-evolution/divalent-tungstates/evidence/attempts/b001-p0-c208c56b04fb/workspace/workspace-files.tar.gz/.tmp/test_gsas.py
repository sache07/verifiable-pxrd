from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parents[1]
gpx = G2sc.G2Project(newgpx=str(root / ".tmp" / "test.gpx"))
hist = gpx.add_powder_histogram(
    str(root / "inputs" / "pattern.csv"),
    str(root / ".tmp" / "cu_ka.instprm"),
)
phase = gpx.add_phase(
    str(root / ".tmp" / "initial_mnwo4.cif"),
    phasename="MnWO4",
    histograms=[hist],
    fmthint="CIF",
)
gpx.save()
print(gpx)
print(hist)
print(phase)
print("points", len(hist.data["data"][1][0]))
print("range", hist.data["data"][1][0][0], hist.data["data"][1][0][-1])
print("inst", hist.data["Instrument Parameters"][0])
print("background", hist.data["Background"])
print("sample", hist.data["Sample Parameters"])
print("phase general", phase.data["General"])
print("HAP", phase.data["Histograms"])
