import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.signal import savgol_filter, find_peaks

a = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
x, y = a.T
ys = savgol_filter(y, 11, 3)

fig, axes = plt.subplots(4, 1, figsize=(16, 12), constrained_layout=True)
windows = [(9.9, 100.1), (9.9, 35), (35, 60), (60, 100.1)]
for ax, (lo, hi) in zip(axes, windows):
    m = (x >= lo) & (x <= hi)
    ax.plot(x[m], y[m], color="0.72", lw=0.45)
    ax.plot(x[m], ys[m], color="black", lw=0.8)
    ax.set_xlim(lo, hi)
    ax.set_ylabel("counts")
    ax.grid(alpha=0.15)
axes[-1].set_xlabel(r"$2\theta$ (degrees)")
fig.savefig(".tmp/pattern.png", dpi=150)
