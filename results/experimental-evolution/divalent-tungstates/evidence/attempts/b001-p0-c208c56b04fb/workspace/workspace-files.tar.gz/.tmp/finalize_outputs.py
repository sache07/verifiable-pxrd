from pathlib import Path
import numpy as np
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parents[1]
src = root / ".tmp" / "final_candidate.gpx"
gpx = G2sc.G2Project(gpxfile=str(src))
gpx.save(str(root / "final.gpx"))
hist = gpx.histogram(0)

out_cifs = {
    "MnWO4": root / "phase_MnWO4.cif",
    "WO3": root / "phase_WO3.cif",
    "Mn3O4": root / "phase_Mn3O4.cif",
}
for name, path in out_cifs.items():
    gpx.phase(name).export_CIF(str(path))

x, yobs, weight, ycalc, background, difference = hist.data["data"][1]
np.savetxt(
    root / "fit.csv",
    np.column_stack((x, yobs, ycalc, difference, background)),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference,background",
    comments="",
    fmt=["%.8f", "%.8f", "%.8f", "%.8f", "%.8f"],
)

rv = gpx.data["Covariance"]["data"]["Rvals"]
mass = hist.ComputeMassFracs()
rp = 100.0 * np.sum(np.abs(yobs - ycalc)) / np.sum(np.abs(yobs))
rexp = rv["Rwp"] / rv["GOF"]
redchi = rv["chisq"] / (rv["Nobs"] - rv["Nvars"])
print("Rwp", rv["Rwp"])
print("Rp", rp)
print("Rexp", rexp)
print("GOF", rv["GOF"])
print("reduced_chi_square", redchi)
print("Nobs", rv["Nobs"], "Nvars", rv["Nvars"])
print("massfracs", mass, "sum", sum(v[0] for v in mass.values()))
for ph in gpx.phases():
    print(ph.name, ph.data["General"]["Cell"])
