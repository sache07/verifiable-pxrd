from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parents[1]
gpx = G2sc.G2Project(gpxfile=str(root / ".tmp" / "three.gpx"))
gpx.save(str(root / ".tmp" / "final_candidate.gpx"))
hist = gpx.histogram(0)
mn = gpx.phase("MnWO4")
wo = gpx.phase("WO3")
sp = gpx.phase("Mn3O4")
phases = (mn, wo, sp)
hname = hist.name
gpx.data["Controls"]["data"]["max cyc"] = 8
gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5

# Start from a known, explicit flag state.
hist.data["Background"][0][1] = True
hist.data["Sample Parameters"]["Scale"][1] = False
for val in hist.data["Instrument Parameters"][0].values():
    if isinstance(val, list) and len(val) > 2: val[2] = False
inst = hist.data["Instrument Parameters"][0]
inst["Zero"][2] = True
inst["I(L2)/I(L1)"][2] = True

for ph in phases:
    ph.data["General"]["Cell"][0] = True
    for atom in ph.atoms(): atom.refinement_flags = " "
    hap = ph.data["Histograms"][hname]
    hap["Scale"][1] = True
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][2] = False

for atom in mn.atoms(): atom.refinement_flags = "X"
wo.data["Histograms"][hname]["Size"][2][0] = True

print("===== final joint refinement =====", flush=True)
gpx.do_refinements([{}])
gpx.save()
rv = gpx.data["Covariance"]["data"]["Rvals"]
print("Rvals", rv, flush=True)
print("massfracs", hist.ComputeMassFracs(), flush=True)
print("instrument", inst, flush=True)
print("background", hist.data["Background"][0], flush=True)
for ph in phases:
    print(ph.name, "cell", ph.data["General"]["Cell"], "scale", ph.data["Histograms"][hname]["Scale"], flush=True)
    for atom in ph.atoms(): print("atom", atom.label, atom.element, atom.coordinates, atom.uiso, atom.refinement_flags, flush=True)
