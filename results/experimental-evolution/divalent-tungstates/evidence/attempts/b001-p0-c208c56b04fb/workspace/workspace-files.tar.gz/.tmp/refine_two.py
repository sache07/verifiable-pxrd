from pathlib import Path
import numpy as np
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parents[1]
src = root / ".tmp" / "single.gpx"
out = root / ".tmp" / "two.gpx"
wo3_cif = Path("<RUN>/resources/b001-c04/cif/1/52/89/1528915.cif")

gpx = G2sc.G2Project(gpxfile=str(src))
gpx.save(str(out))
hist = gpx.histogram(0)
mn = gpx.phase("MnWO4")

gpx.data["Controls"]["data"]["max cyc"] = 16
gpx.data["Controls"]["data"]["min dM/M"] = 2.0e-5

# Freeze the mature one-phase model while the second-phase scale is found.
hist.clear_refinements({
    "Background": True,
    "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)"],
    "Sample Parameters": ["Scale"],
})
mn.clear_refinements({"Cell": True, "Atoms": [a.label for a in mn.atoms()]})

wo = gpx.add_phase(
    str(wo3_cif),
    phasename="WO3",
    histograms=[hist],
    fmthint="CIF",
)
for atom in wo.atoms():
    atom.uiso = 0.006

hname = hist.name
mn_hap = mn.data["Histograms"][hname]
wo_hap = wo.data["Histograms"][hname]
mn_hap["Scale"] = [1.0, True]
wo_hap["Scale"] = [0.15, True]

def refine(label):
    print(f"\n===== {label} =====")
    gpx.do_refinements([{}])
    gpx.save()
    rv = gpx.data["Covariance"]["data"].get("Rvals", {})
    print("Rwp", rv.get("Rwp"), "GOF", rv.get("GOF"), "converged", rv.get("converged"))
    print("scales", mn_hap["Scale"], wo_hap["Scale"])

refine("phase scales")

# Determine the WO3 metric and its extra broadening before reopening shared
# instrumental/profile terms.
wo.set_refinements({"Cell": True})
refine("WO3 cell")
wo.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.08, "refine": True}})
refine("WO3 isotropic size")

# Reoptimize the common angular calibration and both metrics.
mn.set_refinements({"Cell": True})
hist.set_refinements({"Instrument Parameters": ["Zero"]})
refine("both cells and zero")

# Background and shared profile cleanup.
hist.set_refinements({"Background": True})
refine("background")
hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]})
refine("shared profile")

# MnWO4 coordinates are supported by many sharp reflections. Keep the much
# broader minor-phase coordinates at their literature values.
mn.set_refinements({"Atoms": {"all": "X"}})
refine("MnWO4 coordinates")

print("\nFINAL")
rv = gpx.data["Covariance"]["data"].get("Rvals", {})
print("Rvals", rv)
print("massfracs", hist.ComputeMassFracs())
print("Mn cell", mn.data["General"]["Cell"])
print("WO cell", wo.data["General"]["Cell"])
print("inst", hist.data["Instrument Parameters"][0])
print("Mn HAP", mn_hap)
print("WO HAP", wo_hap)
for ph in (mn, wo):
    for atom in ph.atoms():
        print(ph.name, atom.label, atom.element, atom.coordinates, atom.occupancy, atom.uiso, atom.refinement_flags)
