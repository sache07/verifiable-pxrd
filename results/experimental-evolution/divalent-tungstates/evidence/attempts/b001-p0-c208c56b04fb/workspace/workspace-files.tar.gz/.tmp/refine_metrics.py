from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parents[1]
gpx = G2sc.G2Project(gpxfile=str(root / ".tmp" / "clean.gpx"))
gpx.save(str(root / ".tmp" / "metrics.gpx"))
hist = gpx.histogram(0)
mn = gpx.phase("MnWO4")
wo = gpx.phase("WO3")
hname = hist.name
gpx.data["Controls"]["data"]["max cyc"] = 8
gpx.data["Controls"]["data"]["min dM/M"] = 2.0e-5

# Explicitly freeze every flag, avoiding a GSAS-II scripting helper return
# path that can leave later histogram flags unchanged.
hist.data["Background"][0][1] = False
hist.data["Sample Parameters"]["Scale"][1] = False
for val in hist.data["Instrument Parameters"][0].values():
    if isinstance(val, list) and len(val) > 2:
        val[2] = False
for ph in (mn, wo):
    ph.data["General"]["Cell"][0] = True
    for atom in ph.atoms():
        atom.refinement_flags = " "
    hap = ph.data["Histograms"][hname]
    hap["Scale"][1] = True
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][2] = False

inst = hist.data["Instrument Parameters"][0]
inst["I(L2)/I(L1)"][1] = 0.5
inst["I(L2)/I(L1)"][2] = False
inst["Zero"][2] = True

print("===== both cells plus common zero =====", flush=True)
gpx.do_refinements([{}])
gpx.save()
rv = gpx.data["Covariance"]["data"]["Rvals"]
print("Rvals", rv, flush=True)
print("massfracs", hist.ComputeMassFracs(), flush=True)
print("Mn cell", mn.data["General"]["Cell"], flush=True)
print("WO cell", wo.data["General"]["Cell"], flush=True)
print("zero", inst["Zero"], flush=True)
