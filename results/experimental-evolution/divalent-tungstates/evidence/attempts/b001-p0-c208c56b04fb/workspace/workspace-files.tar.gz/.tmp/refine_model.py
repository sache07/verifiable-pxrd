from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parents[1]
gpx = G2sc.G2Project(gpxfile=str(root / ".tmp" / "metrics.gpx"))
gpx.save(str(root / ".tmp" / "model.gpx"))
hist = gpx.histogram(0)
mn = gpx.phase("MnWO4")
wo = gpx.phase("WO3")
hname = hist.name
gpx.data["Controls"]["data"]["max cyc"] = 8
gpx.data["Controls"]["data"]["min dM/M"] = 2.0e-5

def freeze_all():
    hist.data["Background"][0][1] = False
    hist.data["Sample Parameters"]["Scale"][1] = False
    for val in hist.data["Instrument Parameters"][0].values():
        if isinstance(val, list) and len(val) > 2:
            val[2] = False
    for ph in (mn, wo):
        ph.data["General"]["Cell"][0] = False
        for atom in ph.atoms():
            atom.refinement_flags = " "
        hap = ph.data["Histograms"][hname]
        hap["Scale"][1] = False
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False

def phase_scales():
    mn.data["Histograms"][hname]["Scale"][1] = True
    wo.data["Histograms"][hname]["Scale"][1] = True

def refine(label):
    print(f"\n===== {label} =====", flush=True)
    gpx.do_refinements([{}])
    gpx.save()
    rv = gpx.data["Covariance"]["data"]["Rvals"]
    print("Rwp", rv.get("Rwp"), "GOF", rv.get("GOF"), "converged", rv.get("converged"), flush=True)
    print("massfracs", hist.ComputeMassFracs(), flush=True)

freeze_all()
phase_scales()
hist.data["Background"][0][1] = True
hist.data["Instrument Parameters"][0]["I(L2)/I(L1)"][2] = True
refine("background and Kalpha2 ratio")
print("Kalpha ratio", hist.data["Instrument Parameters"][0]["I(L2)/I(L1)"], flush=True)

freeze_all()
phase_scales()
for atom in mn.atoms():
    atom.refinement_flags = "X"
refine("MnWO4 coordinates")

print("Mn atoms", flush=True)
for atom in mn.atoms():
    print(atom.label, atom.coordinates, atom.uiso, flush=True)
