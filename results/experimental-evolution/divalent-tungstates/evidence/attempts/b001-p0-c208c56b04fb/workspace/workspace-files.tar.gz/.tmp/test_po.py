from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parents[1]
src = root / ".tmp" / "model.gpx"
axes = [(0, 0, 1), (0, 1, 0), (1, 0, 0), (1, 1, 0), (1, 1, 1), (1, 1, -1)]

for axis in axes:
    tag = "_".join(str(i).replace("-", "m") for i in axis)
    gpx = G2sc.G2Project(gpxfile=str(src))
    gpx.save(str(root / ".tmp" / f"po_{tag}.gpx"))
    hist = gpx.histogram(0)
    mn = gpx.phase("MnWO4")
    wo = gpx.phase("WO3")
    hname = hist.name
    gpx.data["Controls"]["data"]["max cyc"] = 4
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist.data["Background"][0][1] = False
    hist.data["Sample Parameters"]["Scale"][1] = False
    for val in hist.data["Instrument Parameters"][0].values():
        if isinstance(val, list) and len(val) > 2:
            val[2] = False
    for ph in (mn, wo):
        ph.data["General"]["Cell"][0] = False
        for atom in ph.atoms():
            atom.refinement_flags = " "
        hap = ph.data["Histograms"][hname]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
    po = mn.data["Histograms"][hname]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(axis)
    print(f"\n===== axis {axis} =====", flush=True)
    gpx.do_refinements([{}])
    gpx.save()
    rv = gpx.data["Covariance"]["data"]["Rvals"]
    print("RESULT", axis, "Rwp", rv.get("Rwp"), "GOF", rv.get("GOF"), "MD", po[1], "mass", hist.ComputeMassFracs(), flush=True)
