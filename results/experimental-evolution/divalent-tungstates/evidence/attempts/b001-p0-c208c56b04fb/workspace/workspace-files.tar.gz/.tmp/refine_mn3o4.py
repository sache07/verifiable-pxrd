from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parents[1]
gpx = G2sc.G2Project(gpxfile=str(root / ".tmp" / "third_Mn3O4.gpx"))
gpx.save(str(root / ".tmp" / "three.gpx"))
hist = gpx.histogram(0)
phases = gpx.phases()
hname = hist.name
gpx.data["Controls"]["data"]["max cyc"] = 7
gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5

hist.data["Background"][0][1] = False
hist.data["Sample Parameters"]["Scale"][1] = False
for val in hist.data["Instrument Parameters"][0].values():
    if isinstance(val, list) and len(val) > 2: val[2] = False
for ph in phases:
    ph.data["General"]["Cell"][0] = False
    for atom in ph.atoms(): atom.refinement_flags = " "
    hap = ph.data["Histograms"][hname]
    hap["Scale"][1] = True
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][2] = False
gpx.phase("Mn3O4").data["General"]["Cell"][0] = True

print("===== Mn3O4 cell and all phase scales =====", flush=True)
gpx.do_refinements([{}])
gpx.save()
rv = gpx.data["Covariance"]["data"]["Rvals"]
print("Rvals", rv, flush=True)
print("massfracs", hist.ComputeMassFracs(), flush=True)
for ph in phases: print(ph.name, ph.data["General"]["Cell"], flush=True)
