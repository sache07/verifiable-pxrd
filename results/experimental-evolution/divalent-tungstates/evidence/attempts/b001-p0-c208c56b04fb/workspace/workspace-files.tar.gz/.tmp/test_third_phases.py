from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parents[1]
src = root / ".tmp" / "model.gpx"
base = Path("<RUN>/resources/b001-c04/cif")
candidates = {
    "Mn3O4": ("9001963", base / "9/00/19/9001963.cif"),
    "Mn2O3": ("1010586", base / "1/01/05/1010586.cif"),
    "MnO": ("1514108", base / "1/51/41/1514108.cif"),
    "Mn3WO6": ("2002703", base / "2/00/27/2002703.cif"),
}

for name, (cid, cif) in candidates.items():
    gpx = G2sc.G2Project(gpxfile=str(src))
    gpx.save(str(root / ".tmp" / f"third_{name}.gpx"))
    hist = gpx.histogram(0)
    old = gpx.phases()
    test = gpx.add_phase(str(cif), phasename=name, histograms=[hist], fmthint="CIF")
    phases = old + [test]
    hname = hist.name
    gpx.data["Controls"]["data"]["max cyc"] = 4
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist.data["Background"][0][1] = False
    hist.data["Sample Parameters"]["Scale"][1] = False
    for val in hist.data["Instrument Parameters"][0].values():
        if isinstance(val, list) and len(val) > 2: val[2] = False
    for ph in phases:
        ph.data["General"]["Cell"][0] = False
        for atom in ph.atoms(): atom.refinement_flags = " "
        hap = ph.data["Histograms"][hname]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
    test.data["Histograms"][hname]["Scale"][0] = 0.002
    print(f"\n===== test {name} ({cid}) =====", flush=True)
    gpx.do_refinements([{}])
    gpx.save()
    rv = gpx.data["Covariance"]["data"]["Rvals"]
    print("RESULT", name, "Rwp", rv.get("Rwp"), "scale", test.data["Histograms"][hname]["Scale"][0], "mass", hist.ComputeMassFracs(), flush=True)
