from pathlib import Path
import sys
import numpy as np
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parents[1]
gpx_path = Path(sys.argv[1]) if len(sys.argv) > 1 else root / ".tmp" / "single.gpx"
csv_path = Path(sys.argv[2]) if len(sys.argv) > 2 else root / ".tmp" / "single_fit_data.csv"
p = G2sc.G2Project(gpxfile=str(gpx_path))
h = p.histogram(0)
x, yo, w, yc, bkg, diff = h.data["data"][1]

np.savetxt(
    csv_path,
    np.column_stack((x, yo, yc, diff, bkg)),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference,background",
    comments="",
)

ds = np.convolve(diff, np.ones(9) / 9, mode="same")
peaks = np.where((ds[1:-1] > ds[:-2]) & (ds[1:-1] >= ds[2:]) & (ds[1:-1] > 50))[0] + 1
prom = ds[peaks] - np.maximum(
    np.minimum.accumulate(ds)[peaks],
    np.minimum.accumulate(ds[::-1])[::-1][peaks],
)
order = np.argsort(prom)[::-1]
print("wR", h.get_wR())
print("residual positive peaks")
for j in order[:100]:
    i = peaks[j]
    print(f"{x[i]:9.4f} diff={diff[i]:9.2f} smooth={ds[i]:9.2f} rank={prom[j]:9.2f}")
