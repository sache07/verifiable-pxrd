from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parents[1]
gpx = G2sc.G2Project(gpxfile=str(root / ".tmp" / "two.gpx"))
gpx.save(str(root / ".tmp" / "clean.gpx"))
hist = gpx.histogram(0)
mn = gpx.phase("MnWO4")
wo = gpx.phase("WO3")
hname = hist.name

gpx.data["Controls"]["data"]["max cyc"] = 10
gpx.data["Controls"]["data"]["min dM/M"] = 2.0e-5

def freeze_all():
    hist.data["Background"][0][1] = False
    hist.data["Sample Parameters"]["Scale"][1] = False
    for val in hist.data["Instrument Parameters"][0].values():
        if isinstance(val, list) and len(val) > 2:
            val[2] = False
    for ph in (mn, wo):
        ph.data["General"]["Cell"][0] = False
        for atom in ph.atoms():
            atom.refinement_flags = " "
        hap = ph.data["Histograms"][hname]
        hap["Scale"][1] = False
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False

def refine(label):
    print(f"\n===== {label} =====", flush=True)
    gpx.do_refinements([{}])
    gpx.save()
    rv = gpx.data["Covariance"]["data"].get("Rvals", {})
    print("Rwp", rv.get("Rwp"), "GOF", rv.get("GOF"), "converged", rv.get("converged"), flush=True)
    print("scales", mn.data["Histograms"][hname]["Scale"], wo.data["Histograms"][hname]["Scale"], flush=True)
    print("WO cell", wo.data["General"]["Cell"], flush=True)

freeze_all()
mn.data["Histograms"][hname]["Scale"][1] = True
wo.data["Histograms"][hname]["Scale"][1] = True
wo.data["General"]["Cell"][0] = True
refine("WO3 cell and phase scales")

freeze_all()
mn.data["Histograms"][hname]["Scale"][1] = True
wo.data["Histograms"][hname]["Scale"][1] = True
wo.data["General"]["Cell"][0] = True
wo_hap = wo.data["Histograms"][hname]
wo_hap["Size"][0] = "isotropic"
wo_hap["Size"][1][0] = 0.15
wo_hap["Size"][2][0] = True
refine("WO3 cell scale and isotropic size")

print("massfracs", hist.ComputeMassFracs(), flush=True)
