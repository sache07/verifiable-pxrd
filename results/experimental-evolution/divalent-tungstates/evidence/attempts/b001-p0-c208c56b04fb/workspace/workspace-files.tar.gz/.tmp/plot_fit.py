from pathlib import Path
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

root = Path(__file__).resolve().parents[1]
csv_path = Path(sys.argv[1]) if len(sys.argv) > 1 else root / ".tmp" / "single_fit_data.csv"
png_path = Path(sys.argv[2]) if len(sys.argv) > 2 else root / ".tmp" / "single_fit.png"
x, yo, yc, diff, bkg = np.loadtxt(csv_path, delimiter=",", skiprows=1).T
fig, axes = plt.subplots(4, 1, figsize=(17, 12), constrained_layout=True)
windows = [(9.9, 100.1), (9.9, 40), (40, 70), (70, 100.1)]
for ax, (lo, hi) in zip(axes, windows):
    m = (x >= lo) & (x <= hi)
    ax.plot(x[m], yo[m], color="black", lw=0.65, label="observed")
    ax.plot(x[m], yc[m], color="#d62728", lw=0.7, label="calculated")
    ax.plot(x[m], diff[m], color="#1f77b4", lw=0.55, label="difference")
    ax.plot(x[m], bkg[m], color="0.5", lw=0.5, label="background")
    ax.set_xlim(lo, hi)
    ax.grid(alpha=0.15)
axes[0].legend(ncol=4, fontsize=8)
axes[-1].set_xlabel(r"$2\theta$ (degrees)")
fig.savefig(png_path, dpi=160)
