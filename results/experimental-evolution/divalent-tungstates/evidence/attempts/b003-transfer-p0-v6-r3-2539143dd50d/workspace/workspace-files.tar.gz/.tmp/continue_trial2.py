from pathlib import Path

import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
project = G2sc.G2Project(str(ROOT / ".tmp" / "trial2.gpx"))
hist = project.histogram(0)


def show(label):
    print(f"\n--- {label} ---")
    print("residuals", hist.residuals)
    print("mass fractions", hist.ComputeMassFracs())
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"][:3], "mustrain", hap["Mustrain"][:3])
        print([(a.label, a.coordinates, a.uiso, a.refinement_flags) for a in phase.atoms()])


# Thermal parameters are not independently stable with the phase scales in
# this laboratory mixture. Keep heavy-atom coordinates refined, but set the
# heavy-atom Uiso values to zero (the convention of the source structures).
for label in ("Ni1", "W1"):
    atom = project.phase("NiWO4").atom(label)
    atom.uiso = 0.0
    atom.refinement_flags = "X"
for label in ("W1", "W2"):
    atom = project.phase("WO3").atom(label)
    atom.uiso = 0.0
    atom.refinement_flags = "X"
nio_ni = project.phase("NiO").atom("Ni1")
nio_ni.refinement_flags = " "

# NiO has only six reflections in range and its size/strain terms were 98%
# correlated. Use the simpler, physical size-only model.
nio_hap = project.phase("NiO").data["Histograms"][hist.name]
nio_hap["Mustrain"][1][0] = 0.0
nio_hap["Mustrain"][2][0] = False

project.refine()
show("physical Uiso and NiO size-only")

# The polarization was not supplied in metadata. Refine its effective value
# against the broad angular range while all atomic displacement terms are fixed.
hist.set_refinements({"Instrument Parameters": ["Polariz."]})
project.refine()
project.refine()
show("effective polarization")

# Test axial divergence as the last common profile term.
hist.set_refinements({"Instrument Parameters": ["SH/L"]})
project.refine()
project.refine()
show("axial divergence")
project.save()
