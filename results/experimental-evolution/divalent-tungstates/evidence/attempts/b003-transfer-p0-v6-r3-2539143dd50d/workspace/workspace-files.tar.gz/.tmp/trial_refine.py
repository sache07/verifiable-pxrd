from __future__ import annotations

import csv
import math
from pathlib import Path

import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"


def make_xye() -> Path:
    source = ROOT / "inputs" / "pattern.csv"
    target = TMP / "pattern.xye"
    with source.open(newline="") as src, target.open("w") as dst:
        rows = csv.DictReader(src)
        for row in rows:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    return target


def snapshot(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(f"\n--- {label} ---")
    print("residuals", hist.residuals)
    print("mass fractions", hist.ComputeMassFracs())
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "SH/L")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"], "mustrain", hap["Mustrain"])


def main() -> None:
    xye = make_xye()
    gpx = TMP / "trial.gpx"
    project = G2sc.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(
        str(xye), str(TMP / "instrument.instprm"), fmthint="xye"
    )
    phases = [
        project.add_phase(str(TMP / "start_niwo4.cif"), phasename="NiWO4", histograms=[hist]),
        project.add_phase(str(TMP / "start_wo3.cif"), phasename="WO3", histograms=[hist]),
        project.add_phase(str(TMP / "start_nio.cif"), phasename="NiO", histograms=[hist]),
    ]
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 12},
    })
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})

    project.save()
    project.refine()
    snapshot(project, "background and scales")

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    snapshot(project, "cells and zero")

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
    project.refine()
    snapshot(project, "shared profile")

    # Preserve WO3 as the sharp reference phase and refine sample broadening
    # only for the two visibly broader nickel-containing phases.
    for name in ("NiWO4", "NiO"):
        project.phase(name).set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 1.0, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    project.refine()
    snapshot(project, "phase broadening")
    project.save()


if __name__ == "__main__":
    main()
