from __future__ import annotations

import csv
import json
from pathlib import Path

import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
source = ROOT / ".tmp" / "trial2.gpx"
final = ROOT / "final.gpx"

project = G2sc.G2Project(gpxfile=str(source), newgpx=str(final))
hist = project.histogram(0)

# The axial-divergence trial produced no material fit improvement and was 97%
# correlated with zero. Restore the fixed starting value for the submitted model.
hist.InstrumentParameters["SH/L"][1] = 0.002
hist.InstrumentParameters["SH/L"][2] = False
project.refine()
project.refine()
project.save()

cif_names = {
    "NiWO4": "NiWO4.cif",
    "WO3": "WO3.cif",
    "NiO": "NiO.cif",
}
formulas = {"NiWO4": "NiWO4", "WO3": "WO3", "NiO": "NiO"}
display_names = {
    "NiWO4": "nickel tungstate (wolframite)",
    "WO3": "tungsten trioxide (monoclinic)",
    "NiO": "nickel(II) oxide (rocksalt)",
}
for phase_name, cif_name in cif_names.items():
    project.phase(phase_name).export_CIF(str(ROOT / cif_name))

x, yobs, weights, ycalc, ybkg, ydiff = hist.data["data"][1]
with (ROOT / "fit.csv").open("w", newline="") as fp:
    writer = csv.writer(fp)
    writer.writerow([
        "two_theta_deg",
        "observed_intensity",
        "calculated_intensity",
        "difference_intensity",
        "background_intensity",
    ])
    for row in zip(x, yobs, ycalc, ydiff, ybkg):
        writer.writerow([f"{float(v):.8f}" for v in row])

mass_fracs = hist.ComputeMassFracs()
residuals = hist.residuals
rvals = project.data["Covariance"]["data"]["Rvals"]
phase_rows = []
for phase_name in ("NiWO4", "WO3", "NiO"):
    phase = project.phase(phase_name)
    frac, frac_esd = mass_fracs[phase_name]
    phase_rows.append({
        "name": display_names[phase_name],
        "formula": formulas[phase_name],
        "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
        "cif_path": cif_names[phase_name],
        "weight_fraction": frac,
        "weight_fraction_formal_esd": frac_esd,
        "R_Bragg_percent": residuals[f"{phase.id}:0:Rf"],
    })

result = {
    "phases": phase_rows,
    "weight_fraction_basis": "normalized over the modeled crystalline phases",
    "fit_statistics": {
        "Rp_percent": residuals["R"],
        "Rwp_percent": residuals["wR"],
        "Rexp_percent": residuals["wRmin"],
        "goodness_of_fit": rvals["GOF"],
        "chi_squared": rvals["chisq"],
        "number_of_observations": rvals["Nobs"],
        "number_of_refined_parameters": rvals["Nvars"],
        "two_theta_range_deg": [float(x[0]), float(x[-1])],
    },
    "profile_path": "fit.csv",
    "gsas_project_path": "final.gpx",
}
with (ROOT / "result.json").open("w") as fp:
    json.dump(result, fp, indent=2)
    fp.write("\n")

print(json.dumps(result, indent=2))
print("cells")
for phase in project.phases():
    print(phase.name, phase.get_cell_and_esd())
print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                     if k in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")})
print("covariance message", rvals.get("msg", ""))
