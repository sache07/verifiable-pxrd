from __future__ import annotations

import csv
import math
from pathlib import Path

import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"


def make_xye() -> Path:
    source = ROOT / "inputs" / "pattern.csv"
    target = TMP / "pattern.xye"
    with source.open(newline="") as src, target.open("w") as dst:
        for row in csv.DictReader(src):
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    return target


def snapshot(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(f"\n--- {label} ---")
    print("residuals", hist.residuals)
    print("mass fractions", hist.ComputeMassFracs())
    print("sample scale", hist.SampleParameters["Scale"])
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"][:3], "mustrain", hap["Mustrain"][:3])
        print(" atoms", [(a.label, a.coordinates, a.uiso, a.refinement_flags) for a in phase.atoms()])


def refine(project: G2sc.G2Project, label: str, repeats: int = 1) -> None:
    for _ in range(repeats):
        project.refine()
    snapshot(project, label)


def main() -> None:
    gpx = TMP / "trial2.gpx"
    project = G2sc.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(
        str(make_xye()), str(TMP / "instrument.instprm"), fmthint="xye"
    )
    phases = {
        "NiWO4": project.add_phase(str(TMP / "start_niwo4.cif"), phasename="NiWO4", histograms=[hist]),
        "WO3": project.add_phase(str(TMP / "start_wo3.cif"), phasename="WO3", histograms=[hist]),
        "NiO": project.add_phase(str(TMP / "start_nio.cif"), phasename="NiO", histograms=[hist]),
    }

    # Fix the overall histogram scale. Refining it with all phase scales is
    # rank-deficient; the phase scales alone contain all required information.
    hist.SampleParameters["Scale"][:] = [1.0, False]
    hist.InstrumentParameters["U"][1] = 5.0
    hist.InstrumentParameters["V"][1] = 0.0
    hist.InstrumentParameters["W"][1] = 15.0
    hist.InstrumentParameters["X"][1] = 0.0
    hist.InstrumentParameters["Y"][1] = 0.0
    phases["NiWO4"].HAPvalue("Scale", 145.0)
    phases["WO3"].HAPvalue("Scale", 24.0)
    phases["NiO"].HAPvalue("Scale", 44.0)

    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    hist.set_refinements({
        "Limits": [9.90343322, 100.09455322],
        "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 14},
    })
    for phase in phases.values():
        phase.set_HAP_refinements({"Scale": True})
    refine(project, "background and phase scales")

    for phase in phases.values():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "cells and zero")

    # The nickel phases are appreciably broader than WO3. Start with physical
    # size and strain values, and refine these before touching the common profile.
    for name, size, strain in (("NiWO4", 0.50, 800.0), ("NiO", 0.50, 1400.0)):
        phase = phases[name]
        phase.setSampleProfile(hist, "size", "isotropic", size, LGmix=0.5)
        phase.setSampleProfile(hist, "microstrain", "isotropic", strain, LGmix=0.5)
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
        })
    refine(project, "isotropic size")

    for name in ("NiWO4", "NiO"):
        phases[name].set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    refine(project, "isotropic size and strain", repeats=2)

    # Refine two independent terms in the common Gaussian profile; V, X and Y
    # remain fixed to avoid the strong profile correlations seen in the first pass.
    hist.set_refinements({"Instrument Parameters": ["U", "W"]})
    refine(project, "common profile U and W", repeats=2)

    # Heavy-atom coordinates and isotropic displacement parameters carry most
    # of the X-ray structural information. Oxygen positions are retained from
    # the reference models because they are weakly determined in this mixture.
    phases["NiWO4"].set_refinements({"Atoms": {"Ni1": "XU", "W1": "XU"}})
    phases["WO3"].set_refinements({"Atoms": {"W1": "XU", "W2": "XU"}})
    phases["NiO"].set_refinements({"Atoms": {"Ni1": "U"}})
    refine(project, "heavy atoms", repeats=2)

    project.save()


if __name__ == "__main__":
    main()
