#!/usr/bin/env python3
"""Compare no texture with one March-Dollase axis for one phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", choices=["NiWO4", "WO3", "NiO"])
    parser.add_argument("axis", nargs=3, type=int)
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.base), newgpx=str(args.output))
    hist = gpx.histogram(0)
    for phase in gpx.phases():
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = False
        po[3] = [0, 0, 1]
    phase = gpx.phase(args.phase)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[3] = list(args.axis)
    phase.set_HAP_refinements({"Pref.Ori.": True})
    gpx.set_Controls("parmMin", 0.2, variable=f"{phase.id}:{hist.id}:MD")
    gpx.set_Controls("parmMax", 5.0, variable=f"{phase.id}:{hist.id}:MD")

    gpx.set_Controls("cycles", 20)
    gpx.do_refinements([{}], outputnames=[str(args.output)])
    gpx = G2sc.G2Project(str(args.output), newgpx=str(args.output))
    gpx.set_Controls("cycles", 20)
    gpx.do_refinements([{}], outputnames=[str(args.output)])
    hist = gpx.histogram(0)
    phase = gpx.phase(args.phase)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    result = {
        "phase": args.phase,
        "axis": args.axis,
        "Rwp_percent": hist.get_wR(),
        "preferred_orientation": po,
        "mass_fractions": hist.ComputeMassFracs(),
    }
    print("TEXTURE_CHALLENGE", json.dumps(result, indent=2, default=str))
    gpx.save(str(args.output))


if __name__ == "__main__":
    main()
