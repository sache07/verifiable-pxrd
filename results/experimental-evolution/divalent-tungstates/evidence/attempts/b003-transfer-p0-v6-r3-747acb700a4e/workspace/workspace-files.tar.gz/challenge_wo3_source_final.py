#!/usr/bin/env python3
"""Rebuild a WO3 source-record challenge under the accepted common model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.base), newgpx=str(args.output))
    h = gpx.histogram(0)
    inst = h.data["Instrument Parameters"][0]
    sample = h.data["Sample Parameters"]

    # Re-establish the same restrained nuisance model for every source record.
    sample["Scale"] = [1.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    for key, value in (("U", 0.0), ("V", 0.0), ("Y", 0.0)):
        inst[key][1] = value
        inst[key][2] = False
    inst["SH/L"][1] = 0.002
    inst["SH/L"][2] = False
    inst["Polariz."][1] = 0.5
    inst["Polariz."][2] = False
    h.set_refinements({"Instrument Parameters": ["Polariz."]})

    for phase in gpx.phases():
        hap = phase.data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    niw = gpx.phase("NiWO4")
    niw.data["Histograms"][h.name]["Mustrain"][1][0] = 10.0
    niw.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    gpx.set_Controls("parmMin", 0.0, variable=f"{niw.id}:{h.id}:Mustrain;i")
    gpx.set_Controls("cycles", 20)

    # First establish scales/profile/cells with the accepted global nuisance
    # terms, then release the symmetry-allowed NiWO4 coordinates.
    gpx.do_refinements([{}], outputnames=[str(args.output)])
    niw = gpx.phase("NiWO4")
    niw.set_refinements({"Atoms": {"all": "X"}})
    gpx.do_refinements([{}], outputnames=[str(args.output)])
    gpx = G2sc.G2Project(str(args.output), newgpx=str(args.output))
    gpx.set_Controls("cycles", 20)
    gpx.do_refinements([{}], outputnames=[str(args.output)])

    h = gpx.histogram(0)
    cov = gpx.data["Covariance"]["data"]
    print(
        "SOURCE_CHALLENGE",
        json.dumps(
            {
                "source_project": str(args.base),
                "WO3_space_group": gpx.phase("WO3").data["General"]["SGData"]["SpGrp"],
                "Rwp_percent": h.get_wR(),
                "GOF": cov["Rvals"]["GOF"],
                "max_shift_over_esd": cov["Rvals"].get("Max shft/sig"),
                "mass_fractions": h.ComputeMassFracs(),
            },
            indent=2,
            default=str,
        ),
    )
    gpx.save(str(args.output))


if __name__ == "__main__":
    main()
