#!/usr/bin/env python3
"""Refit the common model after omitting one candidate crystalline phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("omit", choices=["NiWO4", "WO3", "NiO"])
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.base), newgpx=str(args.output))
    gpx.phase(args.omit).set_HAP_refinements({"Use": False})
    gpx.set_Controls("cycles", 20)
    gpx.do_refinements([{}], outputnames=[str(args.output)])
    gpx = G2sc.G2Project(str(args.output), newgpx=str(args.output))
    gpx.set_Controls("cycles", 20)
    gpx.do_refinements([{}], outputnames=[str(args.output)])
    h = gpx.histogram(0)
    print(
        "INVENTORY_CHALLENGE",
        json.dumps(
            {
                "omitted": args.omit,
                "Rwp_percent": h.get_wR(),
                "residuals": h.data["data"][0],
                "mass_fractions": h.ComputeMassFracs(),
            },
            indent=2,
            default=str,
        ),
    )
    gpx.save(str(args.output))


if __name__ == "__main__":
    main()
