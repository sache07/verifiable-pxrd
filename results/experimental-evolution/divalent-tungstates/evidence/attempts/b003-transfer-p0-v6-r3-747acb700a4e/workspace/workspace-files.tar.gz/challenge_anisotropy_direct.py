#!/usr/bin/env python3
"""Challenge one phase's strain anisotropy while preserving an accepted profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", choices=["NiWO4", "WO3", "NiO"])
    parser.add_argument("direction", nargs=3, type=int)
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.base), newgpx=str(args.output))
    h = gpx.histogram(0)
    phase = gpx.phase(args.phase)
    hap = phase.data["Histograms"][h.name]
    start = max(float(hap["Mustrain"][1][0]), 10.0)
    hap["Mustrain"][1][0] = start
    hap["Mustrain"][1][1] = start
    phase.set_HAP_refinements(
        {
            "Mustrain": {
                "type": "uniaxial",
                "direction": args.direction,
                "refine": True,
            }
        }
    )
    for suffix in ("i", "a"):
        gpx.set_Controls(
            "parmMin", 0.0, variable=f"{phase.id}:{h.id}:Mustrain;{suffix}"
        )
    gpx.set_Controls("cycles", 30)
    gpx.do_refinements([{}], outputnames=[str(args.output)])
    gpx = G2sc.G2Project(str(args.output), newgpx=str(args.output))
    gpx.set_Controls("cycles", 30)
    gpx.do_refinements([{}], outputnames=[str(args.output)])
    h = gpx.histogram(0)
    cov = gpx.data["Covariance"]["data"]
    print(
        "DIRECT_ANISOTROPY",
        json.dumps(
            {
                "phase": args.phase,
                "direction": args.direction,
                "Rwp_percent": h.get_wR(),
                "GOF": cov["Rvals"]["GOF"],
                "max_shift_over_esd": cov["Rvals"].get("Max shft/sig"),
                "mustrain": gpx.phase(args.phase).data["Histograms"][h.name]["Mustrain"],
                "mass_fractions": h.ComputeMassFracs(),
            },
            indent=2,
            default=str,
        ),
    )
    gpx.save(str(args.output))


if __name__ == "__main__":
    main()
