#!/usr/bin/env python3
"""Replay controlled global nuisance-model challenges from one GSAS-II baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--mode", choices=["polarization", "rough_b", "rough_ab", "polarization_rough_b"], required=True)
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.base), newgpx=str(args.output))
    hist = gpx.histogram(0)
    sample = hist.data["Sample Parameters"]
    inst = hist.data["Instrument Parameters"][0]

    # Every challenge starts from the same neutral state.
    inst["Polariz."][1] = 0.5
    inst["Polariz."][2] = False
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    if args.mode in {"polarization", "polarization_rough_b"}:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    if args.mode == "rough_b":
        sample["SurfRoughB"] = [0.02, True]
    elif args.mode == "rough_ab":
        sample["SurfRoughA"] = [0.5, True]
        sample["SurfRoughB"] = [0.05, True]
    elif args.mode == "polarization_rough_b":
        sample["SurfRoughB"] = [0.02, True]

    gpx.set_Controls("cycles", 10)
    gpx.do_refinements([{}], outputnames=[str(args.output)])
    hist = gpx.histogram(0)
    result = {
        "mode": args.mode,
        "Rwp_percent": hist.get_wR(),
        "GOF": hist.residuals.get("wR", 0.0) / hist.residuals.get("wRmin", 1.0),
        "instrument": {key: val for key, val in hist.data["Instrument Parameters"][0].items()},
        "sample": hist.data["Sample Parameters"],
        "mass_fractions": hist.ComputeMassFracs(),
    }
    print("CHALLENGE", json.dumps(result, indent=2, default=str))
    gpx.save(str(args.output))


if __name__ == "__main__":
    main()
