#!/usr/bin/env python3
"""Extract residual diagnostics and a profile table from a GSAS-II project."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
from scipy.signal import find_peaks, peak_widths

from GSASII import GSASIIscriptable as G2sc


def weighted_r(yobs, ycalc, weight, sel) -> float:
    return 100.0 * np.sqrt(np.sum(weight[sel] * (yobs[sel] - ycalc[sel]) ** 2) /
                           np.sum(weight[sel] * yobs[sel] ** 2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx", type=Path)
    parser.add_argument("--csv", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.gpx))
    hist = gpx.histogram(0)
    x = np.asarray(hist.getdata("X"))
    yobs = np.asarray(hist.getdata("Yobs"))
    weight = np.asarray(hist.getdata("Yweight"))
    ycalc = np.asarray(hist.getdata("Ycalc"))
    bkg = np.asarray(hist.getdata("Background"))
    diff = np.asarray(hist.getdata("Residual"))
    step = float(np.median(np.diff(x)))

    report = {
        "project": str(args.gpx),
        "Rwp_percent": hist.get_wR(),
        "ranges": {},
        "largest_residuals": [],
        "peak_widths": [],
        "reflection_intensity_ratios": {},
    }
    for lo, hi in [(10, 30), (30, 60), (60, 100), (10, 100)]:
        sel = (x >= lo) & (x <= hi)
        report["ranges"][f"{lo}-{hi}"] = {
            "Rwp_percent": weighted_r(yobs, ycalc, weight, sel),
            "mean_difference_counts": float(np.mean(diff[sel])),
            "rms_difference_counts": float(np.sqrt(np.mean(diff[sel] ** 2))),
        }

    # Report separated residual extrema, useful for detecting omitted families.
    ridx, props = find_peaks(np.abs(diff), prominence=100, distance=max(1, int(0.10 / step)))
    order = ridx[np.argsort(np.abs(diff[ridx]))[::-1]][:40]
    report["largest_residuals"] = [
        {"two_theta_deg": float(x[i]), "difference_counts": float(diff[i])}
        for i in order
    ]

    # Compare observed and calculated FWHM at well-separated prominent peaks.
    sobs = yobs - bkg
    scal = ycalc - bkg
    op, oprop = find_peaks(sobs, prominence=800, distance=max(1, int(0.12 / step)))
    cp, cprop = find_peaks(scal, prominence=800, distance=max(1, int(0.12 / step)))
    ow = peak_widths(sobs, op, rel_height=0.5)[0] * step
    cw = peak_widths(scal, cp, rel_height=0.5)[0] * step
    for j, oi in enumerate(op):
        k = int(np.argmin(np.abs(x[cp] - x[oi])))
        if abs(x[cp[k]] - x[oi]) > 0.08:
            continue
        # Reject obvious multiplets where another observed local maximum is too close.
        if np.sum(np.abs(x[op] - x[oi]) < 0.30) > 1:
            continue
        report["peak_widths"].append({
            "two_theta_obs_deg": float(x[oi]),
            "two_theta_calc_deg": float(x[cp[k]]),
            "FWHM_obs_deg": float(ow[j]),
            "FWHM_calc_deg": float(cw[k]),
            "prominence_obs_counts": float(oprop["prominences"][j]),
        })

    # GSAS-II reflection list columns 8 and 9 contain extracted and calculated
    # squared structure-factor terms. Keep only strong, approximately isolated
    # reflections to expose coherent phase-specific intensity trends.
    refl = hist.reflections()
    all_pos = []
    for name, block in refl.items():
        arr = np.asarray(block["RefList"])
        all_pos.extend((name, i, float(row[5])) for i, row in enumerate(arr))
    for name, block in refl.items():
        arr = np.asarray(block["RefList"])
        rows = []
        if not len(arr):
            continue
        threshold = np.percentile(arr[:, 9], 75)
        for i, row in enumerate(arr):
            if row[9] <= max(threshold, 1e-6):
                continue
            near = [(n, j, p) for n, j, p in all_pos
                    if not (n == name and j == i) and abs(p - row[5]) < 0.15]
            if near:
                continue
            rows.append({
                "hkl": [int(round(row[0])), int(round(row[1])), int(round(row[2]))],
                "two_theta_deg": float(row[5]),
                "Fobs2": float(row[8]),
                "Fcalc2": float(row[9]),
                "Fobs2_over_Fcalc2": float(row[8] / row[9]) if row[9] else None,
            })
        report["reflection_intensity_ratios"][name] = rows

    if args.csv:
        with args.csv.open("w", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(["two_theta_deg", "observed", "calculated", "background", "difference"])
            writer.writerows(zip(x, yobs, ycalc, bkg, diff))
    text = json.dumps(report, indent=2)
    if args.json:
        args.json.write_text(text + "\n")
    print(text)


if __name__ == "__main__":
    main()
