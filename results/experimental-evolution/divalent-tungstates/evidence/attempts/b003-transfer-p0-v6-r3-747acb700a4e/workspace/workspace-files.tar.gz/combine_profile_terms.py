#!/usr/bin/env python3
"""Combine accepted isotropic strain terms and challenge one uniaxial variant."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


START = {"NiWO4": 120.0, "WO3": 180.0, "NiO": 20.0}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--isotropic", nargs="*", default=[])
    parser.add_argument("--size-phase", choices=["NiWO4", "WO3", "NiO"])
    parser.add_argument("--niwo4-anisotropic", action="store_true")
    parser.add_argument("--wo3-anisotropic", action="store_true")
    parser.add_argument("--uniaxial-phase", choices=["NiWO4", "WO3", "NiO"])
    parser.add_argument("--direction", nargs=3, type=int)
    args = parser.parse_args()
    if args.uniaxial_phase and args.direction is None:
        parser.error("--direction is required with --uniaxial-phase")

    gpx = G2sc.G2Project(str(args.base), newgpx=str(args.output))
    h = gpx.histogram(0)
    for phase in gpx.phases():
        hap = phase.data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])

    for name in args.isotropic:
        phase = gpx.phase(name)
        hap = phase.data["Histograms"][h.name]
        hap["Mustrain"][1][0] = START[name]
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        gpx.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{h.id}:Mustrain;i")

    if args.size_phase:
        phase = gpx.phase(args.size_phase)
        hap = phase.data["Histograms"][h.name]
        hap["Size"][1][0] = 5.0
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 5.0, "refine": True}}
        )
        gpx.set_Controls("parmMin", 0.01, variable=f"{phase.id}:{h.id}:Size;i")
        gpx.set_Controls("parmMax", 10.0, variable=f"{phase.id}:{h.id}:Size;i")

    if args.niwo4_anisotropic and args.uniaxial_phase != "NiWO4":
        phase = gpx.phase("NiWO4")
        hap = phase.data["Histograms"][h.name]
        hap["Mustrain"][1][0] = 327.0
        hap["Mustrain"][1][1] = 500.0
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "uniaxial",
                    "direction": [1, 0, 0],
                    "refine": True,
                }
            }
        )
        for suffix in ("i", "a"):
            gpx.set_Controls(
                "parmMin", 0.0, variable=f"{phase.id}:{h.id}:Mustrain;{suffix}"
            )

    if args.wo3_anisotropic and args.uniaxial_phase != "WO3":
        phase = gpx.phase("WO3")
        hap = phase.data["Histograms"][h.name]
        hap["Mustrain"][1][0] = 1016.0
        hap["Mustrain"][1][1] = 660.0
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "uniaxial",
                    "direction": [1, 1, 0],
                    "refine": True,
                }
            }
        )
        for suffix in ("i", "a"):
            gpx.set_Controls(
                "parmMin", 0.0, variable=f"{phase.id}:{h.id}:Mustrain;{suffix}"
            )

    if args.uniaxial_phase:
        name = args.uniaxial_phase
        phase = gpx.phase(name)
        hap = phase.data["Histograms"][h.name]
        hap["Mustrain"][1][0] = START[name]
        hap["Mustrain"][1][1] = START[name]
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "uniaxial",
                    "direction": args.direction,
                    "refine": True,
                }
            }
        )
        for suffix in ("i", "a"):
            gpx.set_Controls(
                "parmMin", 0.0, variable=f"{phase.id}:{h.id}:Mustrain;{suffix}"
            )

    gpx.set_Controls("cycles", 20)
    gpx.do_refinements([{}], outputnames=[str(args.output)])
    gpx = G2sc.G2Project(str(args.output), newgpx=str(args.output))
    gpx.set_Controls("cycles", 20)
    gpx.do_refinements([{}], outputnames=[str(args.output)])
    h = gpx.histogram(0)
    cov = gpx.data["Covariance"]["data"]
    print(
        "COMBINED_PROFILE",
        json.dumps(
            {
                "isotropic": args.isotropic,
                "size_phase": args.size_phase,
                "niwo4_anisotropic": args.niwo4_anisotropic,
                "wo3_anisotropic": args.wo3_anisotropic,
                "uniaxial_phase": args.uniaxial_phase,
                "direction": args.direction,
                "Rwp_percent": h.get_wR(),
                "GOF": cov["Rvals"]["GOF"],
                "max_shift_over_esd": cov["Rvals"].get("Max shft/sig"),
                "terms": {
                    p.name: {
                        "mustrain": p.data["Histograms"][h.name]["Mustrain"],
                        "size": p.data["Histograms"][h.name]["Size"],
                    }
                    for p in gpx.phases()
                },
                "mass_fractions": h.ComputeMassFracs(),
            },
            indent=2,
            default=str,
        ),
    )
    gpx.save(str(args.output))


if __name__ == "__main__":
    main()
