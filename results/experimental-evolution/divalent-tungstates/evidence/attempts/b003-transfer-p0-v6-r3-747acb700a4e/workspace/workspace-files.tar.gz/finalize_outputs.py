#!/usr/bin/env python3
"""Replay the accepted GSAS-II model and export its exact final products."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "direct_aniso_NiO_100_replay.gpx"
FINAL = ROOT / "final.gpx"


def prune_unsupported_terms(gpx: G2sc.G2Project) -> None:
    h = gpx.histogram(0)
    inst = h.data["Instrument Parameters"][0]
    sample = h.data["Sample Parameters"]

    sample["Scale"] = [1.0, False]
    for key in ("SurfRoughA", "SurfRoughB", "Absorption", "DisplaceX", "DisplaceY"):
        if key in sample:
            sample[key] = [0.0, False]
    for key in ("U", "V", "Y", "Z"):
        if key in inst:
            inst[key][1] = 0.0
            inst[key][2] = False
    inst["SH/L"][1] = 0.002
    inst["SH/L"][2] = False

    for phase in gpx.phases():
        hap = phase.data["Histograms"][h.name]
        hap["Use"] = True
        hap["LeBail"] = False
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]
        if phase.name != "NiWO4":
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 10.0
            hap["Size"][2] = [False] * len(hap["Size"][2])
            hap["Size"][5] = [False] * len(hap["Size"][5])


def replay() -> G2sc.G2Project:
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    prune_unsupported_terms(gpx)
    gpx.set_Controls("cycles", 40)
    gpx.save(str(FINAL))
    for _ in range(3):
        gpx.do_refinements([{}], outputnames=[str(FINAL)])
        gpx = G2sc.G2Project(str(FINAL), newgpx=str(FINAL))
        prune_unsupported_terms(gpx)
        gpx.set_Controls("cycles", 40)
    gpx.do_refinements([{}], outputnames=[str(FINAL)])
    gpx.save(str(FINAL))
    return G2sc.G2Project(str(FINAL))


def export(gpx: G2sc.G2Project) -> dict:
    h = gpx.histogram(0)
    for phase in gpx.phases():
        phase.export_CIF(str(ROOT / f"{phase.name}.cif"))

    x = np.asarray(h.getdata("X"), dtype=float)
    yobs = np.asarray(h.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(h.getdata("Ycalc"), dtype=float)
    bkg = np.asarray(h.getdata("Background"), dtype=float)
    lo, hi = h.data["Limits"][1]
    # GSAS-II includes the first grid point at or above each limit, so the
    # upper endpoint is the searchsorted index even when it lies just above
    # the nominal limit. This slice therefore has exactly Nobs rows.
    first = int(np.searchsorted(x, lo))
    last = int(np.searchsorted(x, hi))
    use = slice(first, last + 1)
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "background", "difference"]
        )
        writer.writerows(
            zip(x[use], yobs[use], ycalc[use], bkg[use], (yobs - ycalc)[use])
        )

    cov = gpx.data["Covariance"]["data"]
    residuals = h.data["data"][0]
    fractions = h.ComputeMassFracs()
    return {
        "Rwp_percent": h.get_wR(),
        "Rp_percent": residuals.get("R"),
        "R_background_percent": residuals.get("Rb"),
        "wR_background_percent": residuals.get("wRb"),
        "Rwp_expected_percent": residuals.get("wRmin"),
        "GOF": cov["Rvals"]["GOF"],
        "chi_squared": cov["Rvals"]["chisq"],
        "Nobs": cov["Rvals"]["Nobs"],
        "Nvars": cov["Rvals"]["Nvars"],
        "max_shift_over_esd": cov["Rvals"].get("Max shft/sig"),
        "limits": [lo, hi],
        "fractions": fractions,
        "phases": {
            phase.name: {
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "composition": phase.composition,
                "cell": phase.get_cell(),
                "Rf_percent": residuals.get(f"{phase.id}:{h.id}:Rf"),
                "Rf2_percent": residuals.get(f"{phase.id}:{h.id}:Rf^2"),
                "size": phase.data["Histograms"][h.name]["Size"],
                "mustrain": phase.data["Histograms"][h.name]["Mustrain"],
                "preferred_orientation": phase.data["Histograms"][h.name]["Pref.Ori."],
            }
            for phase in gpx.phases()
        },
        "instrument": {
            key: value
            for key, value in h.data["Instrument Parameters"][0].items()
            if key in {"Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."}
        },
        "background": h.data["Background"],
    }


if __name__ == "__main__":
    print("FINAL_SUMMARY", json.dumps(export(replay()), indent=2, default=str))
