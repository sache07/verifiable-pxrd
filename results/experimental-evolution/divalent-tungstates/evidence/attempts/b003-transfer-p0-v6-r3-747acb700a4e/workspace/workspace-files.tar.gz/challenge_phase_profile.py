#!/usr/bin/env python3
"""Challenge one phase-specific broadening model at a time."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", choices=["NiWO4", "WO3", "NiO"])
    parser.add_argument(
        "mode",
        choices=["none", "size", "mustrain", "size_mustrain", "mustrain_uniaxial"],
    )
    parser.add_argument("--direction", nargs=3, type=int)
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.base), newgpx=str(args.output))
    hist = gpx.histogram(0)
    # Re-neutralize all phase profile terms before each controlled challenge.
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]

    phase = gpx.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    if args.mode in {"size", "size_mustrain"}:
        # 10 micrometres is the GSAS-II effectively neutral upper value.
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 10.0, "refine": True}})
    if args.mode in {"mustrain", "size_mustrain"}:
        # Start near neutral but away from a zero derivative.
        hap["Mustrain"][1][0] = 10.0
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        gpx.set_Controls(
            "parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Mustrain;i"
        )
    elif args.mode == "mustrain_uniaxial":
        if args.direction is None:
            parser.error("--direction is required for mustrain_uniaxial")
        hap["Mustrain"][1][0] = 270.0
        hap["Mustrain"][1][1] = 270.0
        phase.set_HAP_refinements({
            "Mustrain": {
                "type": "uniaxial",
                "direction": args.direction,
                "refine": True,
            }
        })
        gpx.set_Controls(
            "parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Mustrain;i"
        )
        gpx.set_Controls(
            "parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Mustrain;a"
        )

    # Two full-range passes make this a save/reopen-style replay challenge,
    # rather than a comparison made from a partly converged inherited model.
    gpx.set_Controls("cycles", 20)
    gpx.do_refinements([{}], outputnames=[str(args.output)])
    gpx = G2sc.G2Project(str(args.output), newgpx=str(args.output))
    gpx.set_Controls("cycles", 20)
    gpx.do_refinements([{}], outputnames=[str(args.output)])
    hist = gpx.histogram(0)
    phase = gpx.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    result = {
        "phase": args.phase,
        "mode": args.mode,
        "Rwp_percent": hist.get_wR(),
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "mass_fractions": hist.ComputeMassFracs(),
    }
    print("PROFILE_CHALLENGE", json.dumps(result, indent=2, default=str))
    gpx.save(str(args.output))


if __name__ == "__main__":
    main()
