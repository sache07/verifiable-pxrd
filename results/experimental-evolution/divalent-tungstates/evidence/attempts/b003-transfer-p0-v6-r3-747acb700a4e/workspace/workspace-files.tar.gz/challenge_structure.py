#!/usr/bin/env python3
"""Compare/refine physically plausible NiWO4 structural records."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ZN_PARENT = {
    "Ni1": (0.5000, 0.6840, 0.2500),
    "W1": (0.0000, 0.18258, 0.2500),
    "O1": (0.2169, 0.1051, -0.0637),
    "O2": (0.2565, 0.3777, 0.3996),
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("mode", choices=["znparent", "heavy", "all", "znparent_heavy", "znparent_all"])
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.base), newgpx=str(args.output))
    phase = gpx.phase("NiWO4")
    if args.mode.startswith("znparent"):
        for label, xyz in ZN_PARENT.items():
            phase.atom(label).coordinates = xyz

    if args.mode in {"heavy", "znparent_heavy"}:
        phase.set_refinements({"Atoms": {"Ni1": "X", "W1": "X"}})
    elif args.mode in {"all", "znparent_all"}:
        phase.set_refinements({"Atoms": {"all": "X"}})

    gpx.set_Controls("cycles", 12)
    gpx.save(str(args.output))
    gpx.do_refinements([{}], outputnames=[str(args.output)])
    hist = gpx.histogram(0)
    phase = gpx.phase("NiWO4")
    result = {
        "mode": args.mode,
        "Rwp_percent": hist.get_wR(),
        "coordinates": {atom.label: atom.coordinates for atom in phase.atoms()},
        "flags": {atom.label: atom.refinement_flags for atom in phase.atoms()},
        "mass_fractions": hist.ComputeMassFracs(),
    }
    print("STRUCTURE_CHALLENGE", json.dumps(result, indent=2, default=str))
    gpx.save(str(args.output))


if __name__ == "__main__":
    main()
