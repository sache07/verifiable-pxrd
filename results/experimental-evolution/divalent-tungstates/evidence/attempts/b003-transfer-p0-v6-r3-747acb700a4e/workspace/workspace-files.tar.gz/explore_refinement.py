#!/usr/bin/env python3
"""Build and probe GSAS-II Rietveld models for the NiO/WO3 reaction pattern."""

from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summarize(gpx: G2sc.G2Project, label: str) -> dict:
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    out = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "instrument": {key: val[1] for key, val in inst.items() if isinstance(val, list) and len(val) > 1},
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"][0],
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "composition": phase.composition,
            "density": phase.density,
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    print("SUMMARY", json.dumps(out, default=str, indent=2))
    return out


def set_neutral_hap(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    # Keep all phase-specific broadening and preferred orientation neutral.
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0e6
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def build_project(outfile: Path, wo3_id: str, phases: list[str]) -> G2sc.G2Project:
    if outfile.exists():
        outfile.unlink()
    gpx = G2sc.G2Project(newgpx=str(outfile))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 6,
            "coeffs": [3300.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        },
    })
    # Avoid an exact scale indeterminacy: use fixed histogram scale and refine
    # one independent scale for every crystalline phase.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    choices = {
        "NiWO4": ROOT / "NiWO4_start.cif",
        "WO3": cod_path(wo3_id),
        "NiO": cod_path("1010093"),
    }
    for name in phases:
        phase = gpx.add_phase(
            str(choices[name]),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        set_neutral_hap(phase, hist.name)
        phase.set_HAP_refinements({"Scale": True})
    # Use conservative least-squares controls and enough cycles to reconverge.
    gpx.set_Controls("cycles", 8)
    gpx.save()
    return gpx


def refine_sequence(gpx: G2sc.G2Project, prefix: Path) -> list[dict]:
    hist = gpx.histogram(0)
    rows = []

    # Background and all phase scales only.
    gpx.do_refinements([{}], outputnames=[str(prefix) + "_01.gpx"])
    rows.append(summarize(gpx, "scales_background"))

    # One angular correction and all cells under the same smooth background.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    gpx.do_refinements([{}], outputnames=[str(prefix) + "_02.gpx"])
    rows.append(summarize(gpx, "zero_cells"))

    # Establish a common nonnegative low-dimensional Gaussian/Lorentzian profile.
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    gpx.do_refinements([{}], outputnames=[str(prefix) + "_03.gpx"])
    rows.append(summarize(gpx, "common_U0_WX"))

    # Challenge FCJ asymmetry only after the baseline has converged. This test
    # project is retained for comparison; unsupported SH/L is pruned later.
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    gpx.do_refinements([{}], outputnames=[str(prefix) + "_04.gpx"])
    rows.append(summarize(gpx, "common_UWX_SHL"))

    gpx.save(str(prefix) + "_final.gpx")
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", default="2311041")
    parser.add_argument("--phases", nargs="+", default=["NiWO4", "WO3", "NiO"])
    parser.add_argument("--tag", default="trial")
    args = parser.parse_args()
    prefix = ROOT / args.tag
    gpx = build_project(prefix.with_suffix(".gpx"), args.wo3, args.phases)
    rows = refine_sequence(gpx, prefix)
    with open(str(prefix) + "_summary.json", "w") as handle:
        json.dump(rows, handle, indent=2, default=str)


if __name__ == "__main__":
    main()
