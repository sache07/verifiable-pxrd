#!/usr/bin/env python3
"""Second-pass trials on the replay-stable U/W common profile."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from model_trials import metrics


ROOT = Path(__file__).resolve().parent
BASE_UW = ROOT / "trial_profile_U.gpx"


def refine(gpx: G2sc.G2Project) -> None:
    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.do_refinements([{}])


def branch(label: str, steps) -> dict:
    path = ROOT / f"trial2_{label}.gpx"
    gpx = G2sc.G2Project(str(BASE_UW), newgpx=str(path))
    for step in steps:
        step(gpx)
        refine(gpx)
    gpx.save()
    replay = G2sc.G2Project(str(path))
    replay.do_refinements([{}])
    replay.save()
    out = metrics(replay, label)
    print("ADV_RESULT " + json.dumps(out, default=float))
    return out


def instrument(name, start, low, high):
    def apply(gpx):
        hist = gpx.histogram(0)
        hist.data["Instrument Parameters"][0][name][1] = float(start)
        hist.set_refinements({"Instrument Parameters": [name]})
        gpx.set_Controls("parmMin", low, variable=f":0:{name}")
        gpx.set_Controls("parmMax", high, variable=f":0:{name}")

    return apply


def atom_uiso(gpx):
    phase = gpx.phase(0)
    phase.set_refinements({"Atoms": {"all": "U"}})
    for idx in range(len(phase.atoms())):
        gpx.set_Controls("parmMin", 0.0005, variable=f"0::AUiso:{idx}")
        gpx.set_Controls("parmMax", 0.08, variable=f"0::AUiso:{idx}")


def oxygen_xyz(gpx):
    gpx.phase(0).set_refinements({"Atoms": {"O1": "X"}})


def oxygen_xyz_uiso(gpx):
    phase = gpx.phase(0)
    phase.set_refinements({"Atoms": {"Ca1": "U", "W1": "U", "O1": "XU"}})
    for idx in range(len(phase.atoms())):
        gpx.set_Controls("parmMin", 0.0005, variable=f"0::AUiso:{idx}")
        gpx.set_Controls("parmMax", 0.08, variable=f"0::AUiso:{idx}")


def background8(gpx):
    gpx.histogram(0).set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 8}}
    )


def phase_size(gpx):
    gpx.phase(0).set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}
    )


def phase_mustrain(gpx):
    phase = gpx.phase(0)
    hist = gpx.histogram(0)
    term = phase.data["Histograms"][hist.name]["Mustrain"]
    term[0] = "isotropic"
    term[1][0] = 100.0
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})


def texture(axis):
    def apply(gpx):
        phase = gpx.phase(0)
        hist = gpx.histogram(0)
        pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
        pref[0], pref[1], pref[2], pref[3] = "MD", 1.0, True, list(axis)
        gpx.set_Controls("parmMin", 0.5, variable="0:0:MD")
        gpx.set_Controls("parmMax", 2.0, variable="0:0:MD")

    return apply


def main() -> None:
    pol = instrument("Polariz.", 0.62, 0.2, 0.8)
    xterm = instrument("X", 0.8, 0.0, 100.0)
    trials = [
        ("UW", []),
        ("UWX", [xterm]),
        ("UW_pol", [pol]),
        ("UWX_pol", [xterm, pol]),
        ("UW_pol_Uiso", [pol, atom_uiso]),
        ("UW_pol_Oxyz", [pol, oxygen_xyz]),
        ("UW_pol_Oxyz_Uiso", [pol, oxygen_xyz_uiso]),
        ("UW_pol_background8", [pol, background8]),
        ("UW_pol_size", [pol, phase_size]),
        ("UW_pol_mustrain", [pol, phase_mustrain]),
        ("UW_pol_texture001", [pol, texture([0, 0, 1])]),
        ("UW_pol_texture100", [pol, texture([1, 0, 0])]),
        ("UW_pol_texture110", [pol, texture([1, 1, 0])]),
        ("UW_pol_texture101", [pol, texture([1, 0, 1])]),
    ]
    results = []
    for label, steps in trials:
        try:
            results.append(branch(label, steps))
        except Exception as exc:
            results.append({"label": label, "error": repr(exc)})
            print("ADV_ERROR " + label + " " + repr(exc))
    with open(ROOT / "advanced_trials.json", "w", encoding="utf-8") as handle:
        json.dump(results, handle, indent=2, default=float)


if __name__ == "__main__":
    main()
