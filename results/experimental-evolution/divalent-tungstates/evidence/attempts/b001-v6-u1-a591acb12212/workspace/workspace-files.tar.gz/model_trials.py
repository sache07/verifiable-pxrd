#!/usr/bin/env python3
"""Reversible branches from the common-profile CaWO4 baseline."""

from __future__ import annotations

import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "trial_baseline.gpx"


def metrics(gpx: G2sc.G2Project, label: str) -> dict:
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    data = hist.data["data"][0]
    inst = hist.data["Instrument Parameters"][0]
    x = np.asarray(hist.getdata("X"))
    yo = np.asarray(hist.getdata("Yobs"))
    yc = np.asarray(hist.getdata("Ycalc"))
    wt = np.asarray(hist.getdata("Yweight"))
    use = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    nvar = len(gpx.get_VaryList() or [])
    chi2 = float(np.sum(wt[use] * (yo[use] - yc[use]) ** 2))
    cov = gpx.data.get("Covariance", {}).get("data", {})
    maxcorr = None
    cmat = cov.get("covMatrix")
    if cmat is not None and np.size(cmat):
        sd = np.sqrt(np.maximum(np.diag(cmat), 0.0))
        denom = np.outer(sd, sd)
        with np.errstate(divide="ignore", invalid="ignore"):
            corr = np.divide(cmat, denom, out=np.zeros_like(cmat), where=denom > 0)
        corr[np.diag_indices_from(corr)] = 0.0
        maxcorr = float(np.max(np.abs(corr)))
    hap = phase.data["Histograms"][hist.name]
    return {
        "label": label,
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": float(data.get("R", np.nan)),
        "GOF": float(np.sqrt(chi2 / (int(use.sum()) - nvar))),
        "Durbin_Watson": float(data.get("Durbin-Watson", np.nan)),
        "Rf2_percent": float(data.get("0:0:Rf^2", np.nan)),
        "n_variables": nvar,
        "max_abs_correlation": maxcorr,
        "cell": phase.get_cell(),
        "instrument": {
            k: float(inst[k][1])
            for k in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"]
        },
        "background_coefficients": [float(v) for v in hist.data["Background"][0][3:]],
        "atoms": [
            {
                "label": a.label,
                "element": a.element,
                "xyz": [float(v) for v in a.coordinates],
                "uiso": float(a.uiso),
                "flags": a.refinement_flags,
            }
            for a in phase.atoms()
        ],
        "size": copy.deepcopy(hap["Size"]),
        "mustrain": copy.deepcopy(hap["Mustrain"]),
        "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
        "vary_list": [str(v) for v in (gpx.get_VaryList() or [])],
    }


def branch(label: str, setup) -> dict:
    path = ROOT / f"trial_{label}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path))
    gpx.set_Controls("cycles", 12)
    setup(gpx)
    gpx.save()
    gpx.do_refinements([{}])
    gpx.save()
    replay = G2sc.G2Project(str(path))
    replay.do_refinements([{}])
    replay.save()
    out = metrics(replay, label)
    print("TRIAL_RESULT " + json.dumps(out, default=float))
    return out


def set_inst(name: str, start: float, low: float, high: float):
    def apply(gpx):
        hist = gpx.histogram(0)
        hist.data["Instrument Parameters"][0][name][1] = start
        hist.set_refinements({"Instrument Parameters": [name]})
        gpx.set_Controls("parmMin", low, variable=f":0:{name}")
        gpx.set_Controls("parmMax", high, variable=f":0:{name}")

    return apply


def set_background(n: int):
    def apply(gpx):
        gpx.histogram(0).set_refinements(
            {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": n}}
        )

    return apply


def set_atom_flags(flags: dict[str, str], bounds: bool = False):
    def apply(gpx):
        phase = gpx.phase(0)
        phase.set_refinements({"Atoms": flags})
        if bounds:
            for idx, atom in enumerate(phase.atoms()):
                if "U" in atom.refinement_flags:
                    gpx.set_Controls("parmMin", 0.0005, variable=f"0::AUiso:{idx}")
                    gpx.set_Controls("parmMax", 0.08, variable=f"0::AUiso:{idx}")

    return apply


def set_size(gpx):
    phase = gpx.phase(0)
    phase.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}
    )


def set_mustrain(gpx):
    phase = gpx.phase(0)
    hist = gpx.histogram(0)
    term = phase.data["Histograms"][hist.name]["Mustrain"]
    term[0] = "isotropic"
    term[1][0] = 100.0
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})


def set_texture(axis):
    def apply(gpx):
        phase = gpx.phase(0)
        hist = gpx.histogram(0)
        pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
        pref[0] = "MD"
        pref[1] = 1.0
        pref[2] = True
        pref[3] = list(axis)
        gpx.set_Controls("parmMin", 0.5, variable="0:0:MD")
        gpx.set_Controls("parmMax", 2.0, variable="0:0:MD")

    return apply


def main() -> None:
    results = [metrics(G2sc.G2Project(str(BASE)), "baseline_W")]
    trials = [
        ("profile_X", set_inst("X", 1.0, 0.0, 100.0)),
        ("profile_U", set_inst("U", 5.0, 0.0, 1000.0)),
        ("profile_SHL", set_inst("SH/L", 0.01, 0.002, 0.2)),
        ("background_4", set_background(4)),
        ("background_8", set_background(8)),
        ("polarization", set_inst("Polariz.", 0.5, 0.2, 0.8)),
        ("atom_Uiso", set_atom_flags({"all": "U"}, bounds=True)),
        ("oxygen_xyz", set_atom_flags({"O1": "X"})),
        ("phase_size", set_size),
        ("phase_mustrain", set_mustrain),
        ("texture_001", set_texture([0, 0, 1])),
        ("texture_100", set_texture([1, 0, 0])),
        ("texture_110", set_texture([1, 1, 0])),
        ("texture_101", set_texture([1, 0, 1])),
    ]
    for label, setup in trials:
        try:
            results.append(branch(label, setup))
        except Exception as exc:
            results.append({"label": label, "error": repr(exc)})
            print("TRIAL_ERROR " + label + " " + repr(exc))
    with open(ROOT / "trials.json", "w", encoding="utf-8") as handle:
        json.dump(results, handle, indent=2, default=float)


if __name__ == "__main__":
    main()
