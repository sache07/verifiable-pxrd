#!/usr/bin/env python3
"""Replay the selected model and export all requested, project-matched artifacts."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "trial_full_range.gpx"
FINAL = ROOT / "final.gpx"
CIF = ROOT / "CaWO4_scheelite.cif"


def enforce_selected_model(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    x = np.asarray(hist.getdata("X"))
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    hist.Excluded([])
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
            }
        }
    )

    inst = hist.data["Instrument Parameters"][0]
    for key, value in inst.items():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
            value[2] = key in {"Zero", "Polariz.", "U", "W", "X"}
    # Keep the measured radiation constants fixed.
    inst["Lam1"][:2] = [1.540598, 1.540598]
    inst["Lam2"][:2] = [1.544426, 1.544426]
    inst["I(L2)/I(L1)"][:2] = [0.5, 0.5]
    inst["V"][1] = 0.0
    inst["Y"][1] = 0.0
    inst["Z"][1] = 0.0
    inst["SH/L"][1] = 0.002

    sample = hist.data["Sample Parameters"]
    for value in sample.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for key in ["Absorption", "DisplaceX", "DisplaceY", "Shift", "Transparency",
                "SurfRoughA", "SurfRoughB"]:
        if key in sample:
            sample[key][0] = 0.0

    phase.set_refinements({"Cell": True, "Atoms": {"all": " "}, "LeBail": False})
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = True
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]

    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 12)
    for variable, low, high in [
        (":0:Zero", -0.15, 0.15),
        (":0:Polariz.", 0.2, 0.8),
        (":0:U", 0.0, 1000.0),
        (":0:W", 0.0, 1000.0),
        (":0:X", 0.0, 100.0),
    ]:
        gpx.set_Controls("parmMin", low, variable=variable)
        gpx.set_Controls("parmMax", high, variable=variable)


def fit_statistics(gpx: G2sc.G2Project) -> dict:
    hist = gpx.histogram(0)
    x = np.asarray(hist.getdata("X"))
    yo = np.asarray(hist.getdata("Yobs"))
    yc = np.asarray(hist.getdata("Ycalc"))
    wt = np.asarray(hist.getdata("Yweight"))
    use = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    nvar = len(gpx.get_VaryList() or [])
    raw_chi2 = float(np.sum(wt[use] * (yo[use] - yc[use]) ** 2))
    dof = int(use.sum()) - nvar
    data = hist.data["data"][0]
    return {
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": float(data["R"]),
        "Rexp_percent": float(data["wRmin"]),
        "goodness_of_fit": float(np.sqrt(raw_chi2 / dof)),
        "reduced_chi_squared": float(raw_chi2 / dof),
        "chi_squared_sum": raw_chi2,
        "Rf_percent": float(data["0:0:Rf"]),
        "Rf2_percent": float(data["0:0:Rf^2"]),
        "durbin_watson": float(data["Durbin-Watson"]),
        "n_observations": int(data["Nobs"]),
        "n_refined_parameters": nvar,
        "degrees_of_freedom": dof,
        "two_theta_range_deg": [float(x[0]), float(x[-1])],
    }


def write_fit(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    columns = [
        np.asarray(hist.getdata("X")),
        np.asarray(hist.getdata("Yobs")),
        np.asarray(hist.getdata("Ycalc")),
        np.asarray(hist.getdata("Residual")),
        np.asarray(hist.getdata("Background")),
    ]
    with open(ROOT / "fit.csv", "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "difference_obs_minus_calc", "background"]
        )
        writer.writerows(zip(*columns))


def main() -> None:
    gpx = G2sc.G2Project(str(BASE), newgpx=str(FINAL))
    enforce_selected_model(gpx)
    gpx.save()
    gpx.do_refinements([{}])
    gpx.save()

    # Required persistence/replay test on the complete measured range.
    replay = G2sc.G2Project(str(FINAL))
    enforce_selected_model(replay)
    replay.do_refinements([{}])
    replay.save()

    # All exports below are read from the saved, replayed final project.
    final = G2sc.G2Project(str(FINAL))
    hist = final.histogram(0)
    phase = final.phase(0)
    stats = fit_statistics(final)
    cell, cell_esd = phase.get_cell_and_esd()
    inst = hist.data["Instrument Parameters"][0]
    phase.export_CIF(str(CIF))
    write_fit(final)

    result = {
        "phases": [
            {
                "name": "CaWO4_scheelite",
                "formula": "CaWO4",
                "space_group": "I 41/a",
                "space_group_number": 88,
                "cif": "CaWO4_scheelite.cif",
                "weight_fraction": 1.0,
                "weight_fraction_esd": None,
                "cell_angstrom_degrees": cell,
                "cell_esd": cell_esd,
            }
        ],
        "weight_fraction_normalization": "modeled crystalline phases only",
        "fit_statistics": stats,
        "project": "final.gpx",
        "profile": "fit.csv",
        "radiation": {
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
        },
        "refined_common_profile": {
            "zero_deg": float(inst["Zero"][1]),
            "polarization": float(inst["Polariz."][1]),
            "U": float(inst["U"][1]),
            "V": float(inst["V"][1]),
            "W": float(inst["W"][1]),
            "X": float(inst["X"][1]),
            "Y": float(inst["Y"][1]),
            "SH_over_L": float(inst["SH/L"][1]),
        },
        "notes": [
            "Fractions are normalized over modeled crystalline phases; amorphous content was not measured.",
            "A marginal CaO trial refined to about 0.18(7) wt%, but lacked support from multiple peak families and was not retained.",
        ],
    }
    with open(ROOT / "result.json", "w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)

    a = cell["length_a"]
    c = cell["length_c"]
    sa = cell_esd["length_a"]
    sc = cell_esd["length_c"]
    report = f"""# PXRD phase analysis

The crystalline product is **scheelite CaWO4** (space group *I* 41/*a*, No. 88). Its refined tetragonal cell is a = {a:.6f} ± {sa:.6f} Å and c = {c:.6f} ± {sc:.6f} Å. The crystalline-phase-normalized weight fraction is 1.000; this normalization does not measure amorphous material.

## Evidence

The room-temperature, fully occupied scheelite record COD 7219229 accounts for all major and weak observed families, including the peaks near 18.61, 28.70, 29.03, 31.43, 34.17, 47.08, 57.84, and 76.13° 2theta. The refined geometry remains chemically normal (four W–O bonds about 1.76 Å and eight Ca–O bonds about 2.47 Å). The high-pressure monoclinic CaWO4 polymorph is inconsistent with both the 900 °C ambient-pressure synthesis context and the observed peak positions.

The final full-range replay used a six-coefficient smooth Chebyshev background, one zero correction, and a nonnegative common U/W/X profile. The unknown effective polarization refined to {inst['Polariz.'][1]:.4f}; specimen roughness, phase size/strain, texture, extinction, and Babinet terms were neutral. Observed/calculated FWHM values agree at representative isolated low-, mid-, and high-angle families (about 0.155/0.155° at 18.61°, 0.220/0.223° at 47.08°, and 0.212/0.218° at 82.05°). The final statistics are Rwp = {stats['Rwp_percent']:.4f}%, Rp = {stats['Rp_percent']:.4f}%, Rexp = {stats['Rexp_percent']:.4f}%, GOF = {stats['goodness_of_fit']:.4f}, R(F²) = {stats['Rf2_percent']:.4f}%, and Durbin–Watson = {stats['durbin_watson']:.3f}.

## Alternatives and uncertainty

Ca3WO6 and ambient monoclinic, triclinic, and orthorhombic WO3 records all refined to zero scale under the same common profile. CaO is the only marginal watch-list candidate: a two-phase trial gave 0.18(7) wt%, but almost all improvement came from one weak 200-region residual near 37.25°; the other expected CaO families did not improve coherently, and BIC favored the one-phase model. CaO was therefore not quantified as a phase; a model-conditional trace-level upper bound is roughly 0.4 wt% (3 sigma).

Atomic coordinates and isotropic displacement parameters were retained from the screened scheelite source while the cell was refined. ADP trials were strongly correlated with the unknown polarization (maximum correlation about 0.98), so more detailed atomic refinement is not reliable from this pattern. Likewise, instrumental Lorentzian broadening and crystallite size are indistinguishable without a calibrated instrument profile; no crystallite size is reported. Trace phases below the stated sensitivity and amorphous content remain possible.
"""
    with open(ROOT / "report.md", "w", encoding="utf-8") as handle:
        handle.write(report)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
