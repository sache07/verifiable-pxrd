#!/usr/bin/env python3
"""Challenge chemically plausible minor phases against the common final profile."""

from __future__ import annotations

import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "trial2_UWX_pol.gpx"
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = [
    ("CaO", "1563196", "unreacted precursor; ambient rocksalt"),
    ("Ca3WO6", "1563081", "Ca-rich ternary; ordered double perovskite"),
    ("WO3_monoclinic", "1528915", "unreacted precursor; ambient monoclinic"),
    ("WO3_triclinic", "2106293", "physical ambient WO3 alternate"),
    ("WO3_orthorhombic", "2107312", "metastable/high-temperature WO3 alternate"),
]


def neutralize(phase, hist) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def fit_stats(gpx) -> dict:
    hist = gpx.histogram(0)
    x = np.asarray(hist.getdata("X"))
    yo = np.asarray(hist.getdata("Yobs"))
    yc = np.asarray(hist.getdata("Ycalc"))
    wt = np.asarray(hist.getdata("Yweight"))
    use = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    nvar = len(gpx.get_VaryList() or [])
    chi2 = float(np.sum(wt[use] * (yo[use] - yc[use]) ** 2))
    return {
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": float(hist.data["data"][0].get("R", np.nan)),
        "GOF": float(np.sqrt(chi2 / (int(use.sum()) - nvar))),
        "chi2": chi2,
        "n_variables": nvar,
        "Durbin_Watson": float(hist.data["data"][0].get("Durbin-Watson", np.nan)),
    }


def phase_rows(gpx) -> list[dict]:
    hist = gpx.histogram(0)
    try:
        mass = hist.ComputeMassFracs()
    except Exception as exc:
        mass = {phase.name: (None, None) for phase in gpx.phases()}
        mass["error"] = repr(exc)
    rows = []
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        val = mass.get(phase.name, (None, None))
        rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "scale_refined": bool(hap["Scale"][1]),
                "weight_fraction": val[0],
                "weight_fraction_esd": val[1],
                "cell": phase.get_cell(),
            }
        )
    return rows


def run_candidate(name: str, cod_id: str, rationale: str) -> dict:
    outpath = ROOT / f"inventory_{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(outpath))
    hist = gpx.histogram(0)
    phase = gpx.add_phase(
        str(cod_path(cod_id)), phasename=name, histograms=[hist]
    )
    neutralize(phase, hist)
    phase.data["Histograms"][hist.name]["Scale"] = [0.2, True]
    gpx.set_Controls("parmMin", 0.0, variable="1:0:Scale")
    gpx.set_Controls("parmMax", 100.0, variable="1:0:Scale")
    gpx.set_Controls("cycles", 12)
    # Scale is tested before candidate cell parameters.
    gpx.save()
    gpx.do_refinements([{}])
    scale_after_first = float(phase.data["Histograms"][hist.name]["Scale"][0])
    first_vary = [str(v) for v in (gpx.get_VaryList() or [])]
    if scale_after_first > 1.0e-5 and "1:0:Scale" in first_vary:
        phase.set_refinements({"Cell": True})
        gpx.do_refinements([{}])
    gpx.save()
    replay = G2sc.G2Project(str(outpath))
    replay.do_refinements([{}])
    replay.save()
    result = {
        "candidate": name,
        "cod_id": cod_id,
        "rationale": rationale,
        "scale_after_first": scale_after_first,
        "fit": fit_stats(replay),
        "phases": phase_rows(replay),
        "vary_list": [str(v) for v in (replay.get_VaryList() or [])],
    }
    print("INVENTORY_RESULT " + json.dumps(result, default=float))
    return result


def main() -> None:
    base = G2sc.G2Project(str(BASE))
    results = [{"candidate": "none", "fit": fit_stats(base), "phases": phase_rows(base)}]
    for args in CANDIDATES:
        try:
            results.append(run_candidate(*args))
        except Exception as exc:
            results.append({"candidate": args[0], "cod_id": args[1], "error": repr(exc)})
            print("INVENTORY_ERROR " + args[0] + " " + repr(exc))
    with open(ROOT / "inventory_trials.json", "w", encoding="utf-8") as handle:
        json.dump(results, handle, indent=2, default=float)


if __name__ == "__main__":
    main()
