#!/usr/bin/env python3
"""Build and interrogate a GSAS-II refinement for the supplied PXRD pattern."""

from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
INSTRUMENT = ROOT / "instrument.instprm"
CAWO4_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/7/21/92/7219229.cif"
)


def summary(gpx: G2sc.G2Project, label: str) -> dict:
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    out = {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "cell": phase.get_cell(),
        "instrument": {
            key: inst[key][1]
            for key in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)"]
        },
        "background": hist.data["Background"][0],
        "scale": phase.data["Histograms"][hist.name]["Scale"],
        "size": phase.data["Histograms"][hist.name]["Size"],
        "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
        "pref_ori": phase.data["Histograms"][hist.name]["Pref.Ori."],
        "vary": [str(v) for v in (gpx.get_VaryList() or [])],
    }
    print(json.dumps(out, indent=2, default=float))
    return out


def build(path: Path) -> G2sc.G2Project:
    gpx = G2sc.G2Project(newgpx=str(path))
    hist = gpx.add_powder_histogram(
        str(PATTERN), str(INSTRUMENT), fmthint="comma"
    )
    phase = gpx.add_phase(
        str(CAWO4_CIF), phasename="CaWO4_scheelite", histograms=[hist]
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
            }
        }
    )
    # Explicitly neutralize phase-dependent profile and intensity corrections.
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    # GSAS-II uses micrometres and caps this term at 10; 10 um is the
    # effectively neutral value for these ~0.2 degree laboratory peaks.
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]
    sample = hist.data["Sample Parameters"]
    sample["Scale"][1] = False
    for key in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]:
        if key in sample:
            sample[key][1] = False
    if "SurfRoughA" in sample:
        sample["SurfRoughA"][0] = 0.0
    if "SurfRoughB" in sample:
        sample["SurfRoughB"][0] = 0.0
    gpx.set_Controls("cycles", 8)
    gpx.save()
    return gpx


def run() -> None:
    trial = ROOT / "trial_baseline.gpx"
    gpx = build(trial)
    phase = gpx.phase(0)
    hist = gpx.histogram(0)

    # 1: smooth low-order background and scale only.
    phase.set_HAP_refinements({"Scale": True})
    gpx.do_refinements([{}])
    summary(gpx, "background+scale")

    # 2: one angular correction and tetragonal cell.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    phase.set_refinements({"Cell": True})
    gpx.set_Controls("parmMin", -0.15, variable=":0:Zero")
    gpx.set_Controls("parmMax", 0.15, variable=":0:Zero")
    gpx.do_refinements([{}])
    summary(gpx, "add_zero+cell")

    # 3: common nonnegative constant Gaussian width. A U/W trial drove U
    # to its zero bound, so U is pruned and V remains zero.
    hist.set_refinements({"Instrument Parameters": ["W"]})
    for variable in [":0:W"]:
        gpx.set_Controls("parmMin", 0.0, variable=variable)
        gpx.set_Controls("parmMax", 1000.0, variable=variable)
    gpx.do_refinements([{}])
    summary(gpx, "add_W")

    # Reopen and replay to test project persistence.
    gpx.save()
    replay = G2sc.G2Project(str(trial))
    replay.do_refinements([{}])
    summary(replay, "reopened_replay")


if __name__ == "__main__":
    run()
