#!/usr/bin/env python3
"""Rebuild, save, reopen, and replay the selected full-range project."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import test_watchlist as tw


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "profile_wo3_size_lorentzian.gpx"
FINAL = ROOT / "final.gpx"


def configure(gpx) -> None:
    hist = gpx.histogram(0)
    x = hist.getdata("x")
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]

    hist.Background[0][1] = True
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.SampleParameters["Shift"][1] = True

    inst = hist.InstrumentParameters
    for key in ("U", "V", "Y", "Z"):
        inst[key][1:] = [0.0, False]
    inst["Zero"][1:] = [0.0, False]
    inst["I(L2)/I(L1)"][1:] = [0.5, False]
    for key in ("W", "X", "SH/L", "Polariz."):
        inst[key][2] = True

    # Clear all optional phase terms, then restore only the supported WO3 size.
    wo3_size = gpx.phase("WO3_triclinic_2106293").data["Histograms"][hist.name]["Size"][1][0]
    for phase in gpx.phases():
        tw.neutralize_hap(phase, hist)
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
    gpx.phase("WO3_triclinic_2106293").set_HAP_refinements({
        "Size": {
            "type": "isotropic",
            "value": wo3_size,
            "refine": True,
            "LGmix": {"value": 1.0, "refine": False},
        }
    })

    # Only MnWO4 coordinates are supported by this powder pattern.
    for atom in gpx.phase("MnWO4").atoms():
        atom.refinement_flags = "X"
    for phase_name in ("WO3_triclinic_2106293", "Mn3O4_hausmannite"):
        for atom in gpx.phase(phase_name).atoms():
            atom.refinement_flags = " "

    for pid in range(3):
        gpx.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
    for variable, minimum in (
        (":0:W", 0.0),
        (":0:X", 0.0),
        (":0:SH/L", 0.0005),
        (":0:Polariz.", 0.0),
        ("1:0:Size;i", 0.01),
    ):
        gpx.set_Controls("parmMin", minimum, variable=variable)
    gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    gpx.set_Controls("parmMax", 10.0, variable="1:0:Size;i")


def state(gpx, stage: str) -> dict:
    hist = gpx.histogram(0)
    cov = gpx.data["Covariance"]["data"]
    return {
        "stage": stage,
        "limits": hist.data["Limits"][1],
        "residuals": hist.residuals,
        "rvals": cov.get("Rvals", {}),
        "fractions": hist.ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell_and_esd() for phase in gpx.phases()},
        "instrument": {
            key: hist.InstrumentParameters[key][1:]
            for key in ("Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample": {
            key: hist.SampleParameters[key]
            for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "background": hist.Background[0],
        "phase_terms": {
            phase.name: {
                "size": phase.data["Histograms"][hist.name]["Size"],
                "strain": phase.data["Histograms"][hist.name]["Mustrain"],
                "texture": phase.data["Histograms"][hist.name]["Pref.Ori."],
            }
            for phase in gpx.phases()
        },
    }


def main() -> None:
    G2sc.SetPrintLevel("warn")
    if FINAL.exists():
        FINAL.unlink()
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    configure(gpx)
    for _ in range(4):
        gpx.refine()
    gpx.save()
    first = state(gpx, "pre_reopen")

    # Reopen from disk and replay every active parameter over the full range.
    gpx = G2sc.G2Project(str(FINAL))
    configure(gpx)
    for _ in range(3):
        gpx.refine()
    gpx.save()
    second = state(gpx, "post_reopen_replay")
    print(json.dumps([first, second], default=str, indent=2))


if __name__ == "__main__":
    main()
