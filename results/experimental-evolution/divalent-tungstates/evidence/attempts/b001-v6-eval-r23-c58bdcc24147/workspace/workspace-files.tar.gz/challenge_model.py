#!/usr/bin/env python3
"""Challenge coordinate replay and optional nuisance terms one at a time."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "structure_all.gpx"


def fresh(name: str):
    out = ROOT / f"challenge_{name}.gpx"
    if out.exists():
        out.unlink()
    return G2sc.G2Project(str(SOURCE), newgpx=str(out)), out


def cycles(gpx, count: int = 5) -> None:
    for _ in range(count):
        gpx.refine()
    gpx.save()


def snapshot(gpx, label: str) -> dict:
    hist = gpx.histogram(0)
    cov = gpx.data["Covariance"]["data"]
    return {
        "label": label,
        "residuals": hist.residuals,
        "fractions": hist.ComputeMassFracs(),
        "instrument": {
            key: hist.InstrumentParameters[key][1:]
            for key in ("Polariz.", "W", "X", "SH/L")
        },
        "sample_shift_um": hist.SampleParameters["Shift"],
        "phases": {
            phase.name: {
                "cell": phase.get_cell_and_esd(),
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in gpx.phases()
        },
        "atoms": {
            atom.label: atom.coordinates
            for atom in gpx.phase("MnWO4").atoms()
        },
        "vary": [str(v) for v in cov.get("varyList", [])],
        "sig": cov.get("sig", []),
        "rvals": cov.get("Rvals", {}),
    }


def replay_from_mg() -> dict:
    gpx, _ = fresh("replay_mg")
    phase = gpx.phase("MnWO4")
    # MgWO4 COD 9013902, transformed to the same P 1 2/c 1 setting.
    starts = {
        "W1": (0.0, 0.1819, 0.25),
        "Mn1": (0.5, 0.6742, 0.25),
        "O1": (0.2160, 0.1070, -0.0630),
        "O2": (0.2560, 0.3766, 0.3970),
    }
    for label, xyz in starts.items():
        phase.atom(label).coordinates = xyz
    cycles(gpx, 6)
    return snapshot(gpx, "replay_mg")


def polarization() -> dict:
    gpx, _ = fresh("polarization")
    hist = gpx.histogram(0)
    hist.InstrumentParameters["Polariz."][2] = True
    gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    cycles(gpx)
    return snapshot(gpx, "polarization")


def phase_width(phase_index: int, kind: str) -> dict:
    phase_name = G2sc.G2Project(str(SOURCE)).phase(phase_index).name
    label = f"{kind}_{phase_index}_{phase_name}"
    gpx, _ = fresh(label)
    phase = gpx.phase(phase_index)
    hist = gpx.histogram(0)
    hap = phase.data["Histograms"][hist.name]
    if kind == "size":
        phase.set_HAP_refinements({
            "Size": {
                "type": "isotropic",
                "value": 1.0,
                "refine": True,
                "LGmix": {"value": 0.5, "refine": False},
            }
        })
        gpx.set_Controls("parmMin", 0.01, variable=f"{phase_index}:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, variable=f"{phase_index}:0:Size;i")
    elif kind == "strain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 100.0
        hap["Mustrain"][1][2] = 0.5
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][2] = False
        gpx.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;i")
    else:
        raise ValueError(kind)
    cycles(gpx)
    return snapshot(gpx, label)


def main() -> None:
    G2sc.SetPrintLevel("warn")
    results = [snapshot(G2sc.G2Project(str(SOURCE)), "baseline")]
    results.append(replay_from_mg())
    results.append(polarization())
    for phase_index in range(3):
        results.append(phase_width(phase_index, "size"))
        results.append(phase_width(phase_index, "strain"))
    print(json.dumps(results, default=str, indent=2))


if __name__ == "__main__":
    main()
