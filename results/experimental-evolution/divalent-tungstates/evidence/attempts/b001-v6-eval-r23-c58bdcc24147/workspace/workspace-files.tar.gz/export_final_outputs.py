#!/usr/bin/env python3
"""Export all submitted artifacts from the reopened final GSAS-II project."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"


PHASE_EXPORTS = [
    ("MnWO4", "MnWO4", "phase_1_MnWO4.cif", "P 2/c", 13, "COD 1520641 ZnWO4 parent; Mn-for-Zn substitution"),
    ("WO3_monoclinic_2311041", "WO3", "phase_2_WO3.cif", "P 21/c", 14, "COD 2311041"),
    ("Mn3O4_hausmannite", "Mn3O4", "phase_3_Mn3O4.cif", "I 41/a m d", 141, "COD 9001963"),
]


def clean_number(value):
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    return value


def main() -> None:
    G2sc.SetPrintLevel("warn")
    # This explicit reopen is the source of every submitted numerical output.
    gpx = G2sc.G2Project(str(PROJECT))
    hist = gpx.histogram(0)
    cov = gpx.data["Covariance"]["data"]
    fractions = hist.ComputeMassFracs()
    fraction_sum = sum(value[0] for value in fractions.values())
    if not np.isclose(fraction_sum, 1.0, atol=1e-12):
        raise RuntimeError(f"Mass fractions do not sum to unity: {fraction_sum}")

    phase_results = []
    for project_name, formula, filename, display_sg, sg_number, source in PHASE_EXPORTS:
        phase = gpx.phase(project_name)
        phase.export_CIF(str(ROOT / filename))
        cell, cell_esd = phase.get_cell_and_esd()
        fraction, fraction_esd = fractions[project_name]
        pid = phase.id
        phase_results.append({
            "name": formula,
            "project_phase_name": project_name,
            "formula": formula,
            "space_group": display_sg,
            "space_group_number": sg_number,
            "cif_path": filename,
            "weight_fraction": fraction,
            "weight_fraction_esd_formal": fraction_esd,
            "weight_percent": 100.0 * fraction,
            "weight_percent_esd_formal": 100.0 * fraction_esd,
            "cell": {key: clean_number(value) for key, value in cell.items()},
            "cell_esd": {key: clean_number(value) for key, value in cell_esd.items()},
            "structure_source": source,
            "Rf_percent": hist.residuals.get(f"{pid}:0:Rf"),
            "reflections": hist.residuals.get(f"{pid}:0:Nref"),
        })

    x = np.asarray(hist.getdata("x").filled(np.nan), dtype=float)
    observed = np.asarray(hist.getdata("yobs").filled(np.nan), dtype=float)
    calculated = np.asarray(hist.getdata("ycalc").filled(np.nan), dtype=float)
    difference = np.asarray(hist.getdata("residual").filled(np.nan), dtype=float)
    background = np.asarray(hist.getdata("background").filled(np.nan), dtype=float)
    weights = np.asarray(hist.getdata("yweight").filled(np.nan), dtype=float)
    if not np.allclose(difference, observed - calculated, rtol=0.0, atol=1e-8, equal_nan=True):
        raise RuntimeError("GSAS-II residual does not equal observed minus calculated")
    if not np.isfinite(np.column_stack((x, observed, calculated, difference, background))).all():
        raise RuntimeError("Non-finite value found in final profile")
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference, background)),
        delimiter=",",
        header="two_theta_deg,observed_counts,calculated_counts,difference_obs_minus_calc,background_counts",
        comments="",
        fmt="%.10g",
    )

    sigmas = {
        str(var): float(sig)
        for var, sig in zip(cov.get("varyList", []), cov.get("sig", []))
    }
    rvals = cov.get("Rvals", {})
    result = {
        "pattern_path": "inputs/pattern.csv",
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
        "fraction_basis": "normalized over the three modeled crystalline phases; amorphous/unmodeled content excluded",
        "phases": phase_results,
        "fit_statistics": {
            "Rwp_percent": hist.residuals["wR"],
            "Rp_percent": hist.residuals["R"],
            "Rexp_percent": hist.residuals["wRmin"],
            "GOF": rvals.get("GOF"),
            "chi_squared": rvals.get("chisq"),
            "number_observations": rvals.get("Nobs"),
            "number_refined_parameters": rvals.get("Nvars"),
            "maximum_shift_over_esd": rvals.get("Max shft/sig"),
            "converged": rvals.get("converged"),
        },
        "measurement_model": {
            "range_two_theta_deg": [float(x[0]), float(x[-1])],
            "points": int(x.size),
            "wavelength_Kalpha1_angstrom": hist.InstrumentParameters["Lam1"][1],
            "wavelength_Kalpha2_angstrom": hist.InstrumentParameters["Lam2"][1],
            "Kalpha2_to_Kalpha1_ratio": hist.InstrumentParameters["I(L2)/I(L1)"][1],
            "effective_polarization": hist.InstrumentParameters["Polariz."][1],
            "specimen_displacement_micrometre": hist.SampleParameters["Shift"][0],
            "profile_W": hist.InstrumentParameters["W"][1],
            "profile_X": hist.InstrumentParameters["X"][1],
            "profile_SH_over_L": hist.InstrumentParameters["SH/L"][1],
            "background_function": hist.Background[0][0],
            "background_coefficients": hist.Background[0][3:],
            "weights": "Poisson approximation, sigma=sqrt(observed counts), because pointwise uncertainties were not supplied",
        },
        "supported_phase_broadening": {
            "phase": "WO3",
            "model": "isotropic Lorentzian crystallite size",
            "size_micrometre": gpx.phase("WO3_monoclinic_2311041").data["Histograms"][hist.name]["Size"][1][0],
            "size_esd_micrometre_formal": sigmas.get("1:0:Size;i"),
        },
        "reliability_notes": {
            "MnWO4": "High-confidence phase and fraction; coordinates replayed from independent wolframite analogue starts.",
            "WO3": "High-confidence phase and approximate fraction; monoclinic atomic coordinates are parent-record dependent and were not refined.",
            "Mn3O4": "Phase presence is supported, but the exact fraction is less reliable; phase-width alternatives span approximately 5-9 wt% and the high-strain alternative was rejected as a background surrogate.",
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({
        "fractions": fractions,
        "fit_statistics": result["fit_statistics"],
        "wo3_size": result["supported_phase_broadening"],
        "profile_rows": int(x.size),
        "profile_identity_max_error": float(np.max(np.abs(difference - (observed - calculated)))),
        "background_range": [float(background.min()), float(background.max())],
        "weight_range": [float(weights.min()), float(weights.max())],
    }, default=str, indent=2))


if __name__ == "__main__":
    main()
