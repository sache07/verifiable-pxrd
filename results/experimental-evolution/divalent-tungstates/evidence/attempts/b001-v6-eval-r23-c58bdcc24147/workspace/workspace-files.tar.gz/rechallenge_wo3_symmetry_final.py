#!/usr/bin/env python3
"""Re-challenge physical monoclinic WO3 records under the final profile."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import test_watchlist as tw


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path("<RUN>/resources/b001-c04/cif")


def cif(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def swap_wo3(cod_id: str, new_name: str) -> dict:
    out = ROOT / f"final_watch_{cod_id}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(ROOT / "final.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    old_name = "WO3_triclinic_2106293"
    old_scale = gpx.phase(old_name).HAPvalue("Scale")

    del gpx.data["Phases"][old_name]
    for item in gpx.names:
        if item[0] == "Phases":
            item.remove(old_name)
            phase_names = item
            break
    hist.data["Reflection Lists"].pop(old_name, None)

    new_phase = gpx.add_phase(
        str(cif(cod_id)), phasename=new_name, histograms=[hist], fmthint="CIF"
    )
    # Keep the physically useful order and IDs: MnWO4, WO3, Mn3O4.
    phase_names[:] = ["Phases", "MnWO4", new_name, "Mn3O4_hausmannite"]
    gpx.index_ids()
    gpx.update_ids()

    new_phase = gpx.phase(new_name)
    tw.neutralize_hap(new_phase, hist)
    new_phase.HAPvalue("Scale", old_scale)
    new_phase.set_HAP_refinements({
        "Scale": True,
        "Size": {
            "type": "isotropic",
            "value": 0.075,
            "refine": True,
            "LGmix": {"value": 1.0, "refine": False},
        },
    })
    new_phase.set_refinements({"Cell": True})
    for atom in new_phase.atoms():
        atom.refinement_flags = " "

    # Re-establish the shared baseline and discard stale phase-specific bounds.
    controls = gpx.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    hist.Background[0][1] = True
    for key in ("W", "X", "SH/L", "Polariz."):
        hist.InstrumentParameters[key][2] = True
    hist.SampleParameters["Shift"][1] = True
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
    for pid in range(3):
        gpx.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
    for variable, minimum in (
        (":0:W", 0.0),
        (":0:X", 0.0),
        (":0:SH/L", 0.0005),
        (":0:Polariz.", 0.0),
        ("1:0:Size;i", 0.01),
    ):
        gpx.set_Controls("parmMin", minimum, variable=variable)
    gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    gpx.set_Controls("parmMax", 10.0, variable="1:0:Size;i")

    gpx.save()
    history = []
    for cycle in range(8):
        gpx.refine()
        history.append({
            "cycle": cycle + 1,
            "Rwp": hist.residuals["wR"],
            "max_shift_esd": gpx.data["Covariance"]["data"].get("Rvals", {}).get("Max shft/sig"),
            "cell": new_phase.get_cell(),
            "size_um": new_phase.data["Histograms"][hist.name]["Size"][1][0],
        })
    gpx.save()
    cov = gpx.data["Covariance"]["data"]
    return {
        "cod_id": cod_id,
        "phase_name": new_name,
        "history": history,
        "residuals": hist.residuals,
        "rvals": cov.get("Rvals", {}),
        "fractions": hist.ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell_and_esd() for phase in gpx.phases()},
        "wo3_size_um": new_phase.data["Histograms"][hist.name]["Size"][1][0],
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Polariz.", "W", "X", "SH/L")
        },
    }


def main() -> None:
    G2sc.SetPrintLevel("warn")
    tests = [
        swap_wo3("1528915", "WO3_monoclinic_1528915"),
        swap_wo3("2311041", "WO3_monoclinic_2311041"),
    ]
    print(json.dumps(tests, default=str, indent=2))


if __name__ == "__main__":
    main()
