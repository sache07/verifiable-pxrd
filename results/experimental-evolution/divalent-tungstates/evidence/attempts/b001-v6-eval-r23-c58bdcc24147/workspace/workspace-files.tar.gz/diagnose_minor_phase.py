#!/usr/bin/env python3
"""Map the Mn3O4 strain gain onto its reflection families."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIpwd as G2pwd


ROOT = Path(__file__).resolve().parent


def arrays(filename: str):
    gpx = G2sc.G2Project(str(ROOT / filename))
    hist = gpx.histogram(0)
    return gpx, hist, {
        key: np.asarray(hist.getdata(key).filled(np.nan), dtype=float)
        for key in ("x", "yobs", "yweight", "ycalc", "background", "residual")
    }


def main() -> None:
    G2sc.SetPrintLevel("warn")
    p0, h0, a0 = arrays("profile_wo3_size_lorentzian.gpx")
    p1, h1, a1 = arrays("candidate_with_mn3o4_strain.gpx")
    x = a0["x"]
    use = (x >= 10.0) & (x <= 100.0)
    chi0 = a0["yweight"] * (a0["yobs"] - a0["ycalc"]) ** 2
    chi1 = a1["yweight"] * (a1["yobs"] - a1["ycalc"]) ** 2

    refl = h1.reflections()["Mn3O4_hausmannite"]["RefList"]
    rows = []
    for row in refl:
        h, k, l, mult, dsp, pos, sig, gam, fobs, fcalc = row[:10]
        fwhm = 0.01 * G2pwd.getgamFW(gam, sig)
        strength = mult * max(fcalc, 0.0)
        near = np.abs(x - pos) <= max(0.12, 1.25 * fwhm)
        rows.append({
            "hkl": [int(h), int(k), int(l)],
            "position_deg": float(pos),
            "fwhm_deg": float(fwhm),
            "multiplicity": int(mult),
            "Fcalc2": float(fcalc),
            "strength_proxy": float(strength),
            "delta_chi2_local": float(np.nansum(chi0[near] - chi1[near])),
            "points": int(near.sum()),
        })
    rows.sort(key=lambda r: r["strength_proxy"], reverse=True)

    bins = []
    for lo in range(10, 100, 10):
        mask = (x >= lo) & (x < lo + 10)
        bins.append({
            "range_deg": [lo, lo + 10],
            "delta_chi2": float(np.nansum(chi0[mask] - chi1[mask])),
        })

    # Measure the fraction of the fit gain near at least one Mn3O4 family.
    near_any = np.zeros_like(x, dtype=bool)
    for row in rows:
        near_any |= np.abs(x - row["position_deg"]) <= max(0.12, 1.25 * row["fwhm_deg"])
    summary = {
        "total_delta_chi2": float(np.nansum((chi0 - chi1)[use])),
        "delta_chi2_near_mn3o4": float(np.nansum((chi0 - chi1)[use & near_any])),
        "fraction_gain_near_mn3o4": float(
            np.nansum((chi0 - chi1)[use & near_any]) / np.nansum((chi0 - chi1)[use])
        ),
        "angular_bins": bins,
        "strongest_reflections": rows[:18],
    }
    print(json.dumps(summary, indent=2))

    np.savetxt(
        ROOT / "minor_phase_profiles.csv",
        np.column_stack((x, a0["yobs"], a0["ycalc"], a1["ycalc"], a1["background"])),
        delimiter=",",
        header="two_theta_deg,observed,no_mn3o4_strain,with_mn3o4_strain,background",
        comments="",
    )


if __name__ == "__main__":
    main()
