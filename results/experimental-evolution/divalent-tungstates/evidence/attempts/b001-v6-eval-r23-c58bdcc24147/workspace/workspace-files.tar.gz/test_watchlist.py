#!/usr/bin/env python3
"""Challenge plausible secondary phases against one shared GSAS-II profile."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path("<RUN>/resources/b001-c04/cif")


def cif(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = [
    ("WO3_triclinic_2106293", "2106293"),
    ("WO3_monoclinic_1528915", "1528915"),
    ("WO3_orthorhombic_2107312", "2107312"),
    ("WO3_HP_monoclinic_1563541", "1563541"),
    ("Mn2O3_bixbyite_1514230", "1514230"),
    ("Mn3O4_hausmannite_9001963", "9001963"),
    ("Mn3WO6_2002703", "2002703"),
]


def neutralize_hap(phase, hist) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:3] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:3] = [1.0, 1.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}


def refine_twice(gpx) -> None:
    gpx.refine()
    gpx.refine()


def test(name: str, cod_id: str) -> dict:
    out = ROOT / f"watch_{cod_id}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(ROOT / "baseline_shift.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    major = gpx.phase(0)
    minor = gpx.add_phase(str(cif(cod_id)), phasename=name, histograms=[hist], fmthint="CIF")
    neutralize_hap(minor, hist)
    minor.HAPvalue("Scale", 1.0)
    minor.set_HAP_refinements({"Scale": True})
    gpx.save()
    gpx.set_Controls("parmMin", 0.0, variable="1:0:Scale")

    # First test the scale under the accepted common profile.
    hist.clear_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    major.clear_refinements({"Cell": True})
    refine_twice(gpx)
    scale_only = {
        "rwp": hist.residuals["wR"],
        "major_scale": major.HAPvalue("Scale"),
        "minor_scale": minor.HAPvalue("Scale"),
    }

    # Re-establish background/scales, the single angular correction, and cells.
    major.set_refinements({"Cell": True})
    minor.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine_twice(gpx)
    cell_stage = {
        "rwp": hist.residuals["wR"],
        "major_scale": major.HAPvalue("Scale"),
        "minor_scale": minor.HAPvalue("Scale"),
        "minor_cell": minor.get_cell(),
    }

    # Rebuild the common profile after changing inventory.
    hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    refine_twice(gpx)
    gpx.save()
    final = {
        "rwp": hist.residuals["wR"],
        "major_scale": major.HAPvalue("Scale"),
        "minor_scale": minor.HAPvalue("Scale"),
        "major_cell": major.get_cell(),
        "minor_cell": minor.get_cell(),
        "shift_um": hist.SampleParameters["Shift"][0],
        "profile": {k: hist.InstrumentParameters[k][1] for k in ("W", "X", "SH/L")},
        "rvals": gpx.data["Covariance"]["data"].get("Rvals", {}),
    }
    result = {"candidate": name, "cod_id": cod_id, "scale_only": scale_only, "cell_stage": cell_stage, "final": final}
    print(json.dumps(result, default=str), flush=True)
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    results = [test(*spec) for spec in CANDIDATES]
    print("SUMMARY " + json.dumps(results, default=str))


if __name__ == "__main__":
    main()
