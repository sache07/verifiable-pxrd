#!/usr/bin/env python3
"""Create and probe a restrained single-phase GSAS-II baseline."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def snapshot(gpx: G2sc.G2Project, label: str) -> None:
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    inst = hist.InstrumentParameters
    hap = phase.data["Histograms"][hist.name]
    row = {
        "stage": label,
        "residuals": hist.residuals,
        "cell": phase.get_cell(),
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)")
            if key in inst
        },
        "background": hist.Background[0],
        "scale": hap["Scale"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "vary": gpx.get_VaryList(),
    }
    print(json.dumps(row, default=lambda x: x.tolist() if isinstance(x, np.ndarray) else str(x)))


def refine(gpx: G2sc.G2Project, label: str) -> None:
    gpx.refine()
    snapshot(gpx, label)


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = ROOT / "probe.gpx"
    if project.exists():
        project.unlink()
    gpx = G2sc.G2Project(newgpx=str(project))
    hist = gpx.add_powder_histogram(
        str(ROOT / "pattern.xye"),
        str(ROOT / "cu_ka_lab.instprm"),
        fmthint="xye",
    )
    phase = gpx.add_phase(
        str(ROOT / "mnwo4_zn_prototype.cif"),
        phasename="MnWO4",
        histograms=[hist],
        fmthint="CIF",
    )
    gpx.set_Controls("cycles", 8)
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 6,
            "coeffs": [1500.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            "refine": True,
        },
    })
    phase.HAPvalue("Scale", 0.2)
    phase.set_HAP_refinements({"Scale": True})
    # Explicitly neutralize optional phase terms.
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": 1.0e6, "refine": False},
        "Mustrain": {"type": "isotropic", "refine": False},
        "Pref.Ori.": False,
        "Extinction": False,
        "Babinet": [],
    })
    refine(gpx, "background_scale")

    # One angular correction only. Start with the instrumental zero; the
    # displacement alternative is tested in a separate replay.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(gpx, "plus_zero")

    phase.set_refinements({"Cell": True})
    refine(gpx, "plus_cell")

    # Refine a nonnegative low-dimensional common profile.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(gpx, "plus_UWX")

    # Axial divergence is strongly visible below 25 degrees.
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    refine(gpx, "plus_SHL")
    gpx.save()


if __name__ == "__main__":
    main()
