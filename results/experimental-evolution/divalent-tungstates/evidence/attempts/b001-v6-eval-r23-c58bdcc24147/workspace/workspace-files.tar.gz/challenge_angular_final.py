#!/usr/bin/env python3
"""Re-compare zero and specimen displacement on the final inventory."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main() -> None:
    G2sc.SetPrintLevel("warn")
    out = ROOT / "challenge_final_zero.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(ROOT / "final.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.InstrumentParameters["Zero"][1:] = [-0.15, True]
    gpx.set_Controls("parmMin", -1.0, variable=":0:Zero")
    gpx.set_Controls("parmMax", 1.0, variable=":0:Zero")
    history = []
    for cycle in range(8):
        gpx.refine()
        history.append({
            "cycle": cycle + 1,
            "Rwp": hist.residuals["wR"],
            "zero_deg": hist.InstrumentParameters["Zero"][1],
            "max_shift_esd": gpx.data["Covariance"]["data"].get("Rvals", {}).get("Max shft/sig"),
        })
    gpx.save()
    cov = gpx.data["Covariance"]["data"]
    sigmas = {
        str(var): float(sig)
        for var, sig in zip(cov.get("varyList", []), cov.get("sig", []))
        if str(var) in (":0:Zero", ":0:SH/L")
    }
    print(json.dumps({
        "history": history,
        "residuals": hist.residuals,
        "rvals": cov.get("Rvals", {}),
        "fractions": hist.ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell_and_esd() for phase in gpx.phases()},
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Zero", "W", "X", "SH/L", "Polariz.")
        },
        "sample_shift": hist.SampleParameters["Shift"],
        "sigmas": sigmas,
    }, default=str, indent=2))


if __name__ == "__main__":
    main()
