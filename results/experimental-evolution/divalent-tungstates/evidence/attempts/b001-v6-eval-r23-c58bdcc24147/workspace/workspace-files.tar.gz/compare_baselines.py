#!/usr/bin/env python3
"""Replay zero and specimen-displacement baselines from identical starts."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def neutralize_hap(phase, hist) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:3] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:3] = [1.0, 1.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}


def state(gpx, tag: str) -> dict:
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    hap = phase.data["Histograms"][hist.name]
    return {
        "tag": tag,
        "residuals": hist.residuals,
        "cell": phase.get_cell(),
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample": {
            key: hist.SampleParameters[key]
            for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "phase_scale": hap["Scale"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "background": hist.Background[0],
        "vary": gpx.get_VaryList(),
    }


def cycle(gpx, tag: str, count: int = 2) -> None:
    for _ in range(count):
        gpx.refine()
    print(json.dumps(state(gpx, tag), default=lambda x: x.tolist() if isinstance(x, np.ndarray) else str(x)))


def build(correction: str) -> None:
    out = ROOT / f"baseline_{correction}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "cu_ka_lab.instprm"), fmthint="xye"
    )
    phase = gpx.add_phase(
        str(ROOT / "mnwo4_zn_prototype.cif"),
        phasename="MnWO4",
        histograms=[hist],
        fmthint="CIF",
    )
    gpx.set_Controls("cycles", 12)
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 6,
            "coeffs": [1500.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            "refine": True,
        },
    })
    # Use only the phase scale; the histogram scale otherwise duplicates it.
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    phase.HAPvalue("Scale", 40.0)
    phase.set_HAP_refinements({"Scale": True})
    neutralize_hap(phase, hist)

    inst = hist.InstrumentParameters
    for key, value in (("U", 0.0), ("V", 0.0), ("W", 25.0), ("X", 0.2), ("Y", 0.0), ("Z", 0.0), ("SH/L", 0.02)):
        inst[key][1] = value
        inst[key][2] = False
    if correction == "zero":
        inst["Zero"][1:] = [-0.15, False]
        hist.SampleParameters["Shift"] = [0.0, False]
    elif correction == "shift":
        inst["Zero"][1:] = [0.0, False]
        hist.SampleParameters["Shift"] = [260.0, False]
    else:
        raise ValueError(correction)

    gpx.save()
    for var, minimum in (("0:0:Scale", 0.0), (":0:W", 0.0), (":0:X", 0.0), (":0:SH/L", 0.0005)):
        gpx.set_Controls("parmMin", minimum, variable=var)
    cycle(gpx, f"{correction}:background_scale")

    if correction == "zero":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    else:
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    cycle(gpx, f"{correction}:angular")

    phase.set_refinements({"Cell": True})
    cycle(gpx, f"{correction}:cell")

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    cycle(gpx, f"{correction}:WX")

    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    cycle(gpx, f"{correction}:SHL", count=3)
    gpx.save()


def main() -> None:
    G2sc.SetPrintLevel("warn")
    for correction in ("zero", "shift"):
        build(correction)


if __name__ == "__main__":
    main()
