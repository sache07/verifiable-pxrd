#!/usr/bin/env python3
"""Build the selected Lorentzian-WO3 model and challenge Mn3O4 strain."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main() -> None:
    G2sc.SetPrintLevel("warn")
    out = ROOT / "candidate_with_mn3o4_strain.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(
        str(ROOT / "profile_wo3_size_lorentzian.gpx"), newgpx=str(out)
    )
    hist = gpx.histogram(0)
    phase = gpx.phase("Mn3O4_hausmannite")
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 12000.0
    hap["Mustrain"][1][2] = 0.5
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][2] = False
    gpx.set_Controls("parmMin", 0.0, variable="2:0:Mustrain;i")
    for _ in range(6):
        gpx.refine()
    gpx.save()
    cov = gpx.data["Covariance"]["data"]
    sigmas = {
        str(var): float(sig)
        for var, sig in zip(cov.get("varyList", []), cov.get("sig", []))
        if "Size" in str(var) or "Mustrain" in str(var)
    }
    print(json.dumps({
        "residuals": hist.residuals,
        "rvals": cov.get("Rvals", {}),
        "fractions": hist.ComputeMassFracs(),
        "sigmas": sigmas,
        "mn3o4_mustrain": hap["Mustrain"],
        "wo3_size": gpx.phase("WO3_triclinic_2106293").data["Histograms"][hist.name]["Size"],
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Polariz.", "W", "X", "SH/L")
        },
        "shift_um": hist.SampleParameters["Shift"][0],
    }, default=str, indent=2))


if __name__ == "__main__":
    main()
