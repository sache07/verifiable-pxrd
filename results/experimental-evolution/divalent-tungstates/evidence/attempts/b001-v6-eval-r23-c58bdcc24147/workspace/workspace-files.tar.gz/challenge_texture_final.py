#!/usr/bin/env python3
"""Compare no texture with symmetry-distinct MnWO4 March-Dollase axes."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def trial(axis: tuple[int, int, int]) -> dict:
    tag = "_".join(str(v).replace("-", "m") for v in axis)
    out = ROOT / f"texture_{tag}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(ROOT / "final.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    phase = gpx.phase("MnWO4")
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = list(axis)
    gpx.set_Controls("parmMin", 0.5, variable="0:0:MD")
    gpx.set_Controls("parmMax", 2.0, variable="0:0:MD")
    history = []
    for cycle in range(5):
        gpx.refine()
        history.append({
            "cycle": cycle + 1,
            "Rwp": hist.residuals["wR"],
            "MD": pref[1],
            "max_shift_esd": gpx.data["Covariance"]["data"].get("Rvals", {}).get("Max shft/sig"),
        })
    gpx.save()
    cov = gpx.data["Covariance"]["data"]
    sigma = next(
        (float(sig) for var, sig in zip(cov.get("varyList", []), cov.get("sig", [])) if str(var) == "0:0:MD"),
        None,
    )
    return {
        "axis": axis,
        "history": history,
        "Rwp": hist.residuals["wR"],
        "Rp": hist.residuals["R"],
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "MD": pref[1],
        "MD_esd": sigma,
        "fractions": hist.ComputeMassFracs(),
        "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
    }


def main() -> None:
    G2sc.SetPrintLevel("warn")
    axes = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 0, 1), (1, 0, -1)]
    print(json.dumps([trial(axis) for axis in axes], default=str, indent=2))


if __name__ == "__main__":
    main()
