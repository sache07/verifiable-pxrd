#!/usr/bin/env python3
"""Scale-only re-challenge of weak phases under the accepted two-phase model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import test_watchlist as tw


ROOT = Path(__file__).resolve().parent
CANDIDATES = [
    ("MnO_1514108", "1514108"),
    ("Mn2O3_bixbyite_1514230", "1514230"),
    ("Mn3O4_hausmannite_9001963", "9001963"),
    ("Mn3WO6_2002703", "2002703"),
]


def test(name: str, cod_id: str) -> dict:
    out = ROOT / f"rechallenge_{cod_id}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(ROOT / "watch_2106293.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    baseline = hist.residuals["wR"]
    hist.Background[0][1] = False
    hist.clear_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    for phase in gpx.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Scale": True})
    phase = gpx.add_phase(str(tw.cif(cod_id)), phasename=name, histograms=[hist], fmthint="CIF")
    tw.neutralize_hap(phase, hist)
    phase.HAPvalue("Scale", 0.1)
    phase.set_HAP_refinements({"Scale": True})
    gpx.save()
    gpx.set_Controls("parmMin", 0.0, variable="2:0:Scale")
    gpx.refine()
    gpx.refine()
    result = {
        "candidate": name,
        "cod_id": cod_id,
        "baseline_rwp": baseline,
        "rwp": hist.residuals["wR"],
        "scale": phase.HAPvalue("Scale"),
        "rvals": gpx.data["Covariance"]["data"].get("Rvals", {}),
    }
    print(json.dumps(result, default=str), flush=True)
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    print("SUMMARY " + json.dumps([test(*x) for x in CANDIDATES], default=str))


if __name__ == "__main__":
    main()
