#!/usr/bin/env python3
"""Adopt the stable monoclinic-WO3 project and perform the final disk replay."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "final_watch_2311041.gpx"
FINAL = ROOT / "final.gpx"


def state(gpx, stage: str) -> dict:
    hist = gpx.histogram(0)
    cov = gpx.data["Covariance"]["data"]
    return {
        "stage": stage,
        "residuals": hist.residuals,
        "rvals": cov.get("Rvals", {}),
        "fractions": hist.ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell_and_esd() for phase in gpx.phases()},
        "wo3_size_um": gpx.phase("WO3_monoclinic_2311041").data["Histograms"][hist.name]["Size"][1][0],
        "instrument": {
            key: hist.InstrumentParameters[key][1:]
            for key in ("Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "shift_um": hist.SampleParameters["Shift"],
        "limits": hist.data["Limits"][1],
    }


def main() -> None:
    G2sc.SetPrintLevel("warn")
    if FINAL.exists():
        FINAL.unlink()
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    gpx.save()
    before = state(gpx, "copied")

    gpx = G2sc.G2Project(str(FINAL))
    for _ in range(3):
        gpx.refine()
    gpx.save()
    after = state(gpx, "reopened_replayed")
    print(json.dumps([before, after], default=str, indent=2))


if __name__ == "__main__":
    main()
