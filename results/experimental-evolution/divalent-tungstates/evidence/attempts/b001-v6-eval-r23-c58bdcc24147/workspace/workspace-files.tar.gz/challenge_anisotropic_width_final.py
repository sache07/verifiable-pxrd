#!/usr/bin/env python3
"""Challenge low-dimensional uniaxial MnWO4 size/strain broadening."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def trial(kind: str, axis: tuple[int, int, int]) -> dict:
    tag = "_".join(str(v).replace("-", "m") for v in axis)
    out = ROOT / f"anisowidth_{kind}_{tag}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(ROOT / "final.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    phase = gpx.phase("MnWO4")
    hap = phase.data["Histograms"][hist.name]
    if kind == "strain":
        values = hap["Mustrain"]
        values[0] = "uniaxial"
        values[1][:3] = [100.0, 100.0, 0.5]
        values[2][:3] = [True, True, False]
        values[3] = list(axis)
        for var in ("0:0:Mustrain;i", "0:0:Mustrain;a"):
            gpx.set_Controls("parmMin", 0.0, variable=var)
    elif kind == "size":
        values = hap["Size"]
        values[0] = "uniaxial"
        values[1][:3] = [1.0, 1.0, 0.5]
        values[2][:3] = [True, True, False]
        values[3] = list(axis)
        for var in ("0:0:Size;i", "0:0:Size;a"):
            gpx.set_Controls("parmMin", 0.01, variable=var)
            gpx.set_Controls("parmMax", 10.0, variable=var)
    else:
        raise ValueError(kind)
    history = []
    for cycle in range(5):
        gpx.refine()
        history.append({
            "cycle": cycle + 1,
            "Rwp": hist.residuals["wR"],
            "values": list(values[1][:3]),
            "max_shift_esd": gpx.data["Covariance"]["data"].get("Rvals", {}).get("Max shft/sig"),
        })
    gpx.save()
    cov = gpx.data["Covariance"]["data"]
    sigmas = {
        str(var): float(sig)
        for var, sig in zip(cov.get("varyList", []), cov.get("sig", []))
        if kind.capitalize() in str(var) or (kind == "strain" and "Mustrain" in str(var))
    }
    return {
        "kind": kind,
        "axis": axis,
        "history": history,
        "Rwp": hist.residuals["wR"],
        "Rp": hist.residuals["R"],
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "values": values,
        "sigmas": sigmas,
        "fractions": hist.ComputeMassFracs(),
        "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
    }


def main() -> None:
    G2sc.SetPrintLevel("warn")
    axes = [(1, 0, 0), (0, 1, 0), (0, 0, 1)]
    print(json.dumps(
        [trial("size", axis) for axis in axes],
        default=str,
        indent=2,
    ))


if __name__ == "__main__":
    main()
