#!/usr/bin/env python3
"""Final phase-width and WO3 size-shape challenges on the clean baseline."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "wo3_size.gpx"


def fresh(label: str):
    out = ROOT / f"profile_{label}.gpx"
    if out.exists():
        out.unlink()
    return G2sc.G2Project(str(SOURCE), newgpx=str(out))


def refine(gpx, count: int = 5) -> None:
    for _ in range(count):
        gpx.refine()
    gpx.save()


def result(gpx, label: str) -> dict:
    hist = gpx.histogram(0)
    cov = gpx.data["Covariance"]["data"]
    return {
        "label": label,
        "Rwp": hist.residuals["wR"],
        "Rp": hist.residuals["R"],
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "fractions": hist.ComputeMassFracs(),
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Polariz.", "W", "X", "SH/L")
        },
        "phases": {
            phase.name: {
                "size": phase.data["Histograms"][hist.name]["Size"],
                "strain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in gpx.phases()
        },
        "sigmas": {
            str(var): float(sig)
            for var, sig in zip(cov.get("varyList", []), cov.get("sig", []))
            if "Size" in str(var) or "Mustrain" in str(var)
        },
    }


def size_shape(mode: str) -> dict:
    gpx = fresh(f"wo3_size_{mode}")
    phase = gpx.phase("WO3_triclinic_2106293")
    if mode == "gaussian":
        mix, flag = 0.0, False
    elif mode == "lorentzian":
        mix, flag = 1.0, False
    elif mode == "refined_mix":
        mix, flag = 0.5, True
    else:
        raise ValueError(mode)
    phase.set_HAP_refinements({
        "Size": {
            "type": "isotropic",
            "refine": True,
            "LGmix": {"value": mix, "refine": flag},
        }
    })
    if flag:
        gpx.set_Controls("parmMin", 0.0, variable="1:0:Size;mx")
        gpx.set_Controls("parmMax", 1.0, variable="1:0:Size;mx")
    refine(gpx)
    return result(gpx, f"wo3_size_{mode}")


def extra_width(phase_index: int, kind: str) -> dict:
    gpx = fresh(f"phase{phase_index}_{kind}")
    phase = gpx.phase(phase_index)
    hist = gpx.histogram(0)
    hap = phase.data["Histograms"][hist.name]
    if kind == "size":
        phase.set_HAP_refinements({
            "Size": {
                "type": "isotropic",
                "value": 1.0,
                "refine": True,
                "LGmix": {"value": 0.5, "refine": False},
            }
        })
        gpx.set_Controls("parmMin", 0.01, variable=f"{phase_index}:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, variable=f"{phase_index}:0:Size;i")
    elif kind == "strain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 100.0
        hap["Mustrain"][1][2] = 0.5
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][2] = False
        gpx.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;i")
    else:
        raise ValueError(kind)
    refine(gpx)
    return result(gpx, f"phase{phase_index}_{kind}")


def main() -> None:
    G2sc.SetPrintLevel("warn")
    tests = [size_shape(mode) for mode in ("gaussian", "lorentzian", "refined_mix")]
    for phase_index in (0, 2):
        for kind in ("size", "strain"):
            tests.append(extra_width(phase_index, kind))
    print(json.dumps(tests, default=str, indent=2))


if __name__ == "__main__":
    main()
