#!/usr/bin/env python3
"""Build a fully reconverged MnWO4 + WO3 + weak Mn3O4 project."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import test_watchlist as tw


ROOT = Path(__file__).resolve().parent


def main() -> None:
    G2sc.SetPrintLevel("warn")
    out = ROOT / "three_phase.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(ROOT / "watch_2106293.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    spinel = gpx.add_phase(
        str(tw.cif("9001963")),
        phasename="Mn3O4_hausmannite",
        histograms=[hist],
        fmthint="CIF",
    )
    tw.neutralize_hap(spinel, hist)
    spinel.HAPvalue("Scale", 1.52)
    gpx.save()
    gpx.set_Controls("parmMin", 0.0, variable="2:0:Scale")

    hist.Background[0][1] = True
    hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        tw.neutralize_hap(phase, hist)

    for _ in range(5):
        gpx.refine()
    gpx.save()
    result = {
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell_and_esd() for phase in gpx.phases()},
        "scales": {phase.name: phase.HAPvalue("Scale") for phase in gpx.phases()},
        "instrument": {k: hist.InstrumentParameters[k][1] for k in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
        "sample": {k: hist.SampleParameters[k] for k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
        "background": hist.Background[0],
        "rvals": gpx.data["Covariance"]["data"].get("Rvals", {}),
    }
    print(json.dumps(result, default=str))


if __name__ == "__main__":
    main()
