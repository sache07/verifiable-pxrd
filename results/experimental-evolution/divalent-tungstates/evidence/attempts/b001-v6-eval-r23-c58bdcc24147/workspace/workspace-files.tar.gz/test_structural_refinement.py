#!/usr/bin/env python3
"""Test replay-stable MnWO4 coordinate refinements only."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def run(mode: str) -> None:
    out = ROOT / f"structure_{mode}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(ROOT / "three_phase.gpx"), newgpx=str(out))
    phase = gpx.phase("MnWO4")
    if mode == "cations":
        phase.set_refinements({"Atoms": {"W1": "X", "Mn1": "X"}})
    elif mode == "all":
        phase.set_refinements({"Atoms": {"all": "X"}})
    else:
        raise ValueError(mode)
    for _ in range(5):
        gpx.refine()
    gpx.save()
    phase.export_CIF(str(ROOT / f"structure_{mode}_MnWO4.cif"))
    cov = gpx.data["Covariance"]["data"]
    result = {
        "mode": mode,
        "residuals": gpx.histogram(0).residuals,
        "mass_fractions": gpx.histogram(0).ComputeMassFracs(),
        "atoms": {
            atom.label: {
                "coordinates": atom.coordinates,
                "flags": atom.refinement_flags,
                "uiso": atom.data[phase.data["General"]["AtomPtrs"][3] + 1],
            }
            for atom in phase.atoms()
        },
        "atom_variables": {
            var: sig
            for var, sig in zip(cov.get("varyList", []), cov.get("sig", []))
            if "::dA" in var
        },
        "rvals": cov.get("Rvals", {}),
    }
    print(json.dumps(result, default=str), flush=True)


def main() -> None:
    G2sc.SetPrintLevel("warn")
    for mode in ("cations", "all"):
        run(mode)


if __name__ == "__main__":
    main()
