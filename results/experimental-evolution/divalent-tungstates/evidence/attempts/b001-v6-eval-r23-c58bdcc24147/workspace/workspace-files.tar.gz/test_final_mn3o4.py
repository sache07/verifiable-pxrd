#!/usr/bin/env python3
"""Quantify the final Mn3O4 contribution by a leave-one-phase-out replay."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main() -> None:
    G2sc.SetPrintLevel("warn")
    out = ROOT / "final_without_mn3o4.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(ROOT / "final.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    phase = gpx.phase("Mn3O4_hausmannite")
    phase.HAPvalue("Scale", 0.0)
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Scale": True})
    for _ in range(5):
        gpx.refine()
    gpx.save()
    cov = gpx.data["Covariance"]["data"]
    print(json.dumps({
        "residuals": hist.residuals,
        "rvals": cov.get("Rvals", {}),
        "fractions": hist.ComputeMassFracs(),
        "cells": {p.name: p.get_cell_and_esd() for p in gpx.phases()[:2]},
    }, default=str, indent=2))


if __name__ == "__main__":
    main()
