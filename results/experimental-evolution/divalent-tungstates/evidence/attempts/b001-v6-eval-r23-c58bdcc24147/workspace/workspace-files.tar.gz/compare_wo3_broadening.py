#!/usr/bin/env python3
"""Compare WO3 finite-size and microstrain broadening under polarization."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "challenge_polarization.gpx"


def build(mode: str) -> dict:
    out = ROOT / f"wo3_{mode}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(out))
    hist = gpx.histogram(0)
    phase = gpx.phase("WO3_triclinic_2106293")
    hap = phase.data["Histograms"][hist.name]

    if mode in ("size", "both"):
        phase.set_HAP_refinements({
            "Size": {
                "type": "isotropic",
                "value": 0.06,
                "refine": True,
                "LGmix": {"value": 0.5, "refine": False},
            }
        })
        gpx.set_Controls("parmMin", 0.01, variable="1:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, variable="1:0:Size;i")
    if mode in ("strain", "both"):
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 5000.0 if mode == "both" else 10000.0
        hap["Mustrain"][1][2] = 0.5
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][2] = False
        gpx.set_Controls("parmMin", 0.0, variable="1:0:Mustrain;i")

    for _ in range(6):
        gpx.refine()
    gpx.save()
    cov = gpx.data["Covariance"]["data"]
    values = {}
    for key, value in (
        ("size_um", hap["Size"][1][0]),
        ("microstrain", hap["Mustrain"][1][0]),
        ("size_mix", hap["Size"][1][2]),
        ("strain_mix", hap["Mustrain"][1][2]),
    ):
        values[key] = value
    sigmas = {
        str(var): float(sig)
        for var, sig in zip(cov.get("varyList", []), cov.get("sig", []))
        if "Size;i" in str(var) or "Mustrain;i" in str(var)
    }
    return {
        "mode": mode,
        "residuals": hist.residuals,
        "fractions": hist.ComputeMassFracs(),
        "values": values,
        "sigmas": sigmas,
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Polariz.", "W", "X", "SH/L")
        },
        "shift_um": hist.SampleParameters["Shift"][0],
        "rvals": cov.get("Rvals", {}),
    }


def main() -> None:
    G2sc.SetPrintLevel("warn")
    print(json.dumps([build(mode) for mode in ("size", "strain", "both")], indent=2))


if __name__ == "__main__":
    main()
