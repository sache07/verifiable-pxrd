#!/usr/bin/env python3
"""Re-rank structurally distinct source records in the complete 3-phase basis."""

import contextlib
import io
import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUTDIR = ROOT / ".tmp" / "source_challenge3"
OUTDIR.mkdir(parents=True, exist_ok=True)

BASE = {
    "pb": ("9009811", "9/00/98/9009811.cif"),
    "wo": ("2311041", "2/31/10/2311041.cif"),
    "pbo": ("9012124", "9/01/21/9012124.cif"),
}
CHALLENGES = [
    ("baseline", BASE["pb"], BASE["wo"], BASE["pbo"]),
    ("pbwo4_1527935", ("1527935", "1/52/79/1527935.cif"), BASE["wo"], BASE["pbo"]),
    ("pbwo4_9007617", ("9007617", "9/00/76/9007617.cif"), BASE["wo"], BASE["pbo"]),
    ("wo3_1528915", BASE["pb"], ("1528915", "1/52/89/1528915.cif"), BASE["pbo"]),
    ("wo3_2106293", BASE["pb"], ("2106293", "2/10/62/2106293.cif"), BASE["pbo"]),
    ("wo3_2107312", BASE["pb"], ("2107312", "2/10/73/2107312.cif"), BASE["pbo"]),
    ("pb3o4_9003043", BASE["pb"], BASE["wo"], ("9003043", "9/00/30/9003043.cif")),
]


def neutralize(phase, histogram_name):
    hap = phase.data["Histograms"][histogram_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]


def build(label, pb, wo, pbo, texture):
    suffix = "texture" if texture else "neutral"
    path = OUTDIR / f"{label}_{suffix}.gpx"
    gpx = G2sc.G2Project(newgpx=str(path))
    h = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"), str(ROOT / "instrument.instprm"),
        fmthint="comma/tab/semicolon separated")
    phases = [
        gpx.add_phase(str(COD / pb[1]), phasename=f"PbWO4_source_{pb[0]}",
                      histograms=[h], fmthint="CIF"),
        gpx.add_phase(str(COD / wo[1]), phasename=f"WO3_source_{wo[0]}",
                      histograms=[h], fmthint="CIF"),
        gpx.add_phase(str(COD / pbo[1]), phasename=f"Pb3O4_source_{pbo[0]}",
                      histograms=[h], fmthint="CIF"),
    ]
    h.set_refinements({"Limits": [10.0, 100.0]})
    h.SampleParameters["Scale"][:] = [1.0, False]
    h.SampleParameters["SurfRoughA"][:] = [0.0, False]
    h.SampleParameters["SurfRoughB"][:] = [0.0, False]
    for key, value, refine in (
        ("Zero", 0.44, True), ("U", 0.0, False), ("V", 0.0, False),
        ("W", 0.0, False), ("X", 8.8, False), ("Y", 0.0, False),
        ("Z", 0.0, False), ("SH/L", 0.0005, False),
        ("Polariz.", 0.5, False),
    ):
        h.InstrumentParameters[key][1] = value
        h.InstrumentParameters[key][2] = refine
    h.set_refinements({"Background": {
        "type": "chebyschev-1", "refine": True, "no. coeffs": 8,
        "coeffs": [1515.0, -1177.0, 614.0, -243.0, 72.0, -24.0, 8.0, 5.0],
    }})
    for phase, scale in zip(phases, (8.0, 3.0, 1.5)):
        neutralize(phase, h.name)
        phase.HAPvalue("Scale", scale)
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})
    for index, seed in ((0, 0.07), (2, 0.04)):
        size = phases[index].data["Histograms"][h.name]["Size"]
        size[1][0], size[2][0] = seed, True
        gpx.set_Controls("parmMin", 0.001, variable=f"{index}:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, variable=f"{index}:0:Size;i")
    if texture:
        po = phases[0].data["Histograms"][h.name]["Pref.Ori."]
        po[0:4] = ["MD", 1.15, True, [0, 1, -1]]
        gpx.set_Controls("parmMin", 0.2, variable="0:0:MD")
        gpx.set_Controls("parmMax", 5.0, variable="0:0:MD")
    gpx.set_Controls("parmMin", 0.0, variable=":0:X")
    gpx.set_Controls("parmMax", 200.0, variable=":0:X")
    gpx.set_Controls("cycles", 30)
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        gpx.save()
        gpx.refine()
        h = gpx.histogram(0)
        h.InstrumentParameters["X"][2] = True
        gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        gpx.refine()
        replay = G2sc.G2Project(str(path))
        replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        replay.refine()
    h = replay.histogram(0)
    rv = replay.data["Covariance"]["data"].get("Rvals", {})
    try:
        fractions = {name: pair[0] for name, pair in h.ComputeMassFracs().items()}
    except (KeyError, TypeError, ValueError):
        fractions = {}
    return {
        "label": label,
        "sources": {"PbWO4": pb[0], "WO3": wo[0], "Pb3O4": pbo[0]},
        "texture": texture,
        "project": str(path.relative_to(ROOT)),
        "Rwp": h.get_wR(),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "message": rv.get("msg", ""),
        "zero": h.InstrumentParameters["Zero"][1],
        "X": h.InstrumentParameters["X"][1],
        "march_ratio": replay.phase(0).data["Histograms"][h.name]["Pref.Ori."][1],
        "sizes_um": {p.name: p.data["Histograms"][h.name]["Size"][1][0]
                     for p in replay.phases()},
        "fractions": fractions,
    }


rows = []
selected = set(sys.argv[1:])
for challenge in CHALLENGES:
    if selected and challenge[0] not in selected:
        continue
    for texture in (False, True):
        row = build(*challenge, texture)
        rows.append(row)
        print(json.dumps(row, sort_keys=True), flush=True)
with open(ROOT / "source_challenge3.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
