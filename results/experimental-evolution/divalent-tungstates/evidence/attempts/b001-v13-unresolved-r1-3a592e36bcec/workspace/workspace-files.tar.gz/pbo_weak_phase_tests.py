#!/usr/bin/env python3
"""Replay-stability and broadening tests for the possible weak PbO phase."""

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
BASE = ROOT / ".tmp" / "source900_polarization" / "seed0.8.gpx"
OUTDIR = ROOT / ".tmp" / "pbo_weak_phase_tests"
OUTDIR.mkdir(parents=True, exist_ok=True)

BRANCHES = [
    ("supercell_replay", "1/53/36/1533609.cif", 8, None, None),
    ("supercell_background6", "1/53/36/1533609.cif", 6, None, None),
    ("supercell_background10", "1/53/36/1533609.cif", 10, None, None),
    ("supercell_polseed02", "1/53/36/1533609.cif", 8, 0.2, None),
    ("supercell_polseed08", "1/53/36/1533609.cif", 8, 0.8, None),
    ("supercell_size002", "1/53/36/1533609.cif", 8, None, 0.02),
    ("supercell_size005", "1/53/36/1533609.cif", 8, None, 0.05),
    ("supercell_size020", "1/53/36/1533609.cif", 8, None, 0.20),
    ("massicot_replay", "2/31/04/2310433.cif", 8, None, None),
]


def neutralize(phase, histogram_name):
    hap = phase.data["Histograms"][histogram_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]


rows = []
for name, relcif, nback, polseed, sizeseed in BRANCHES:
    path = OUTDIR / f"{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path))
    h = gpx.histogram(0)
    phase = gpx.add_phase(str(COD / relcif), phasename=f"PbO_{name}",
                          histograms=[h], fmthint="CIF")
    neutralize(phase, h.name)
    phase.data["General"]["Cell"][0] = False
    phase.HAPvalue("Scale", 0.01)
    phase.set_HAP_refinements({"Scale": True})
    gpx.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
    gpx.set_Controls("parmMax", 100.0, variable=f"{phase.id}:0:Scale")

    coeffs = list(h.Background[0][3:])
    h.set_refinements({"Background": {
        "type": "chebyschev-1", "refine": True, "no. coeffs": nback,
        "coeffs": (coeffs + [0.0] * nback)[:nback],
    }})
    if polseed is not None:
        h.InstrumentParameters["Polariz."][1:3] = [polseed, True]
        gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    if sizeseed is not None:
        size = phase.data["Histograms"][h.name]["Size"]
        size[1][0], size[2][0] = sizeseed, True
        gpx.set_Controls("parmMin", 0.001, variable=f"{phase.id}:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, variable=f"{phase.id}:0:Size;i")

    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 50)
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured), contextlib.redirect_stderr(captured):
        gpx.save()
        gpx.refine()
        replay = G2sc.G2Project(str(path))
        replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        replay.set_Controls("cycles", 50)
        replay.refine()
    h = replay.histogram(0)
    phase = replay.phase(3)
    rv = replay.data["Covariance"]["data"].get("Rvals", {})
    cov = replay.data["Covariance"]["data"]
    scale_var = f"{phase.id}:0:Scale"
    scale_esd = None
    if scale_var in cov.get("varyList", []):
        scale_esd = float(cov["sig"][cov["varyList"].index(scale_var)])
    hap = phase.data["Histograms"][h.name]
    row = {
        "name": name,
        "source_cif": str(COD / relcif),
        "project": str(path.relative_to(ROOT)),
        "Rwp": h.get_wR(),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "message": rv.get("msg", ""),
        "background_coefficients": len(h.Background[0]) - 3,
        "polarization": h.InstrumentParameters["Polariz."][1],
        "scale": hap["Scale"][0],
        "scale_esd": scale_esd,
        "size_um": hap["Size"][1][0],
        "size_refine": hap["Size"][2][0],
        "cell": list(phase.data["General"]["Cell"][1:7]),
        "cell_refine": phase.data["General"]["Cell"][0],
        "fractions": {n: v[0] for n, v in h.ComputeMassFracs().items()},
    }
    diagnostic = captured.getvalue()
    if "Warning" in diagnostic or "Error" in diagnostic or "singular" in diagnostic.lower():
        row["diagnostic_tail"] = diagnostic[-4000:]
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "pbo_weak_phase_tests.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
