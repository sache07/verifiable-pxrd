#!/usr/bin/env python3
"""Scale-first PbO additions and a Pb3O4 source replacement on the final basis."""

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
BASE = ROOT / ".tmp" / "source900_polarization" / "seed0.8.gpx"
OUTDIR = ROOT / ".tmp" / "watchlist_challenges"
OUTDIR.mkdir(parents=True, exist_ok=True)

CHALLENGES = (
    ("add_PbO_9012700", COD / "9/01/27/9012700.cif", "PbO_source_9012700", False),
    ("add_PbO_1533609", COD / "1/53/36/1533609.cif", "PbO_source_1533609", False),
    ("replace_Pb3O4_9003043", COD / "9/00/30/9003043.cif",
     "Pb3O4_source_9003043", True),
)


def neutralize(phase, histogram_name):
    hap = phase.data["Histograms"][histogram_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]


def stage_summary(gpx, added, stage, diagnostic):
    h = gpx.histogram(0)
    rv = gpx.data["Covariance"]["data"].get("Rvals", {})
    try:
        fractions = {n: v[0] for n, v in h.ComputeMassFracs().items()}
    except Exception as err:
        fractions = {"error": str(err)}
    row = {
        "stage": stage,
        "Rwp": h.get_wR(),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "message": rv.get("msg", ""),
        "added_phase": added.name,
        "added_scale": added.data["Histograms"][h.name]["Scale"][0],
        "added_scale_refine": added.data["Histograms"][h.name]["Scale"][1],
        "fractions": fractions,
    }
    if "Warning" in diagnostic or "Error" in diagnostic or "singular" in diagnostic.lower():
        row["diagnostic_tail"] = diagnostic[-4000:]
    return row


rows = []
for label, cif, phase_name, replacement in CHALLENGES:
    path = OUTDIR / f"{label}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path))
    h = gpx.histogram(0)
    if replacement:
        # Literal replacement: the retained Pb3O4 record is present but inactive.
        gpx.phase(2).data["Histograms"][h.name]["Scale"][:] = [0.0, False]
    added = gpx.add_phase(str(cif), phasename=phase_name,
                          histograms=[h], fmthint="CIF")
    neutralize(added, h.name)
    added.set_refinements({"Cell": False})
    added.HAPvalue("Scale", 1.0 if replacement else 0.05)
    added.set_HAP_refinements({"Scale": True})
    gpx.set_Controls("parmMin", 0.0, variable=f"{added.id}:0:Scale")
    gpx.set_Controls("parmMax", 100.0, variable=f"{added.id}:0:Scale")
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 45)

    captured = io.StringIO()
    with contextlib.redirect_stdout(captured), contextlib.redirect_stderr(captured):
        gpx.save()
        gpx.refine()
        replay = G2sc.G2Project(str(path))
        replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        replay.phase(3).data["Histograms"][replay.histogram(0).name]["Scale"][1] = True
        replay.refine()
    added_replay = replay.phase(3)
    first = stage_summary(replay, added_replay, "scale_only_replay", captured.getvalue())

    challenge = {
        "label": label,
        "source_cif": str(cif),
        "replacement": replacement,
        "project": str(path.relative_to(ROOT)),
        "stages": [first],
    }

    scale = first["added_scale"]
    frac = first["fractions"].get(phase_name, 0.0) if isinstance(first["fractions"], dict) else 0.0
    if scale > 1e-7 and frac > 1e-5 and "frozen" not in first["message"].lower():
        # Only a positive interior scale earns cell/size refinement.
        replay.phase(3).set_refinements({"Cell": True})
        size = replay.phase(3).data["Histograms"][replay.histogram(0).name]["Size"]
        size[1][0], size[2][0] = 0.05, True
        replay.set_Controls("parmMin", 0.001, variable=f"{replay.phase(3).id}:0:Size;i")
        replay.set_Controls("parmMax", 10.0, variable=f"{replay.phase(3).id}:0:Size;i")
        replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        captured2 = io.StringIO()
        with contextlib.redirect_stdout(captured2), contextlib.redirect_stderr(captured2):
            replay.save()
            replay.refine()
            replay2 = G2sc.G2Project(str(path))
            replay2.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
            replay2.refine()
        challenge["stages"].append(
            stage_summary(replay2, replay2.phase(3), "cell_size_replay", captured2.getvalue())
        )

    rows.append(challenge)
    print(json.dumps(challenge, sort_keys=True), flush=True)

with open(ROOT / "watchlist_challenges.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
