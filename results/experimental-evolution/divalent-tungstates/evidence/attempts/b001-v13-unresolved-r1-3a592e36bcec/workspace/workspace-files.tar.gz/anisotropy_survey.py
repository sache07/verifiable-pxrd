#!/usr/bin/env python3
import contextlib
import io
import itertools
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
BASE = ROOT / "survey_p0_size.gpx"
OUTDIR = ROOT / ".tmp" / "anisotropy_survey"
OUTDIR.mkdir(parents=True, exist_ok=True)


def canonical_axis(vector):
    vector = tuple(int(round(v)) for v in vector)
    divisor = math.gcd(*[abs(v) for v in vector if v])
    vector = tuple(v // divisor for v in vector)
    for value in vector:
        if value:
            return tuple(-v for v in vector) if value < 0 else vector
    raise ValueError("zero axis")


def inequivalent_axes(phase, maximum=2):
    rotations = []
    for matrix, _translation in phase.data["General"]["SGData"]["SGOps"]:
        reciprocal = np.rint(np.linalg.inv(np.asarray(matrix)).T).astype(int)
        if not any(np.array_equal(reciprocal, old) for old in rotations):
            rotations.append(reciprocal)
    candidates = set()
    for vector in itertools.product(range(-maximum, maximum + 1), repeat=3):
        if vector == (0, 0, 0):
            continue
        if math.gcd(*[abs(v) for v in vector if v]) != 1:
            continue
        candidates.add(canonical_axis(vector))
    seen, representatives = set(), []
    ordering = lambda v: (max(map(abs, v)), sum(abs(x) for x in v), v)
    for vector in sorted(candidates, key=ordering):
        if vector in seen:
            continue
        orbit = {canonical_axis(rotation @ np.asarray(vector))
                 for rotation in rotations}
        seen.update(orbit)
        representatives.append(vector)
    return representatives

template = G2sc.G2Project(str(BASE))
axis_sets = {p.id: inequivalent_axes(p) for p in template.phases()}
rows = []

for phase_index, axes in axis_sets.items():
    for axis in axes:
        tag = "_".join(str(value).replace("-", "m") for value in axis)
        project_path = OUTDIR / f"p{phase_index}_{tag}.gpx"
        gpx = G2sc.G2Project(str(BASE), newgpx=str(project_path))
        h = gpx.histogram(0)
        p = gpx.phase(phase_index)
        size = p.data["Histograms"][h.name]["Size"]
        seed = size[1][0] if phase_index == 0 else 1.0
        size[0] = "uniaxial"
        size[1][0:3] = [seed, seed, 1.0]
        size[2][0:3] = [True, True, False]
        size[3] = list(axis)
        gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        for suffix in ("i", "a"):
            gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;{suffix}")
            gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;{suffix}")
        gpx.set_Controls("cycles", 10)
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            gpx.save()
            gpx.refine()
        h = gpx.histogram(0)
        p = gpx.phase(phase_index)
        size = p.data["Histograms"][h.name]["Size"]
        rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
        row = {
            "phase_index": phase_index,
            "phase": p.name,
            "axis": list(axis),
            "equatorial_size_um": size[1][0],
            "axial_size_um": size[1][1],
            "Rwp": h.get_wR(),
            "GOF": rvals.get("GOF"),
            "converged": rvals.get("converged"),
            "message": rvals.get("msg", ""),
            "fractions": {name: pair[0] for name, pair in h.ComputeMassFracs().items()},
            "project": str(project_path.relative_to(ROOT)),
        }
        rows.append(row)
        print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "anisotropy_survey.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
