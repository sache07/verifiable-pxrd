#!/usr/bin/env python3
"""Delete each retained term from the replay-stable four-phase checkpoint."""

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "four_phase_axis_cross" / "p2_0_1_m1_p3_0_2_m1_tex1.gpx"
OUTDIR = ROOT / ".tmp" / "four_phase_term_deletions"
OUTDIR.mkdir(parents=True, exist_ok=True)

MODES = (
    "replay", "delete_p0_size", "delete_p2_size", "p2_isotropic",
    "delete_p3_size", "p3_isotropic", "delete_p3_texture",
    "delete_W", "delete_X", "delete_polarization", "nuisance_cross_seed",
)


def inactive_size(size):
    size[0] = "isotropic"; size[1][:] = [10.0, 10.0, 1.0]
    size[2][:] = [False, False, False]
    size[5][:] = [False] * len(size[5])


def isotropic(gpx, index, seed):
    h = gpx.histogram(0); p = gpx.phase(index)
    size = p.data["Histograms"][h.name]["Size"]
    inactive_size(size); size[1][0], size[2][0] = seed, True
    gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;i")
    gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;i")


def configure(gpx, mode):
    h = gpx.histogram(0)
    if mode == "delete_p0_size": inactive_size(gpx.phase(0).data["Histograms"][h.name]["Size"])
    elif mode == "delete_p2_size": inactive_size(gpx.phase(2).data["Histograms"][h.name]["Size"])
    elif mode == "p2_isotropic": isotropic(gpx, 2, 0.030)
    elif mode == "delete_p3_size": inactive_size(gpx.phase(3).data["Histograms"][h.name]["Size"])
    elif mode == "p3_isotropic": isotropic(gpx, 3, 0.045)
    elif mode == "delete_p3_texture":
        gpx.phase(3).data["Histograms"][h.name]["Pref.Ori."][0:4] = [
            "MD", 1.0, False, [1, -1, -1]
        ]
    elif mode in ("delete_W", "delete_X"):
        key = mode[-1]; h.InstrumentParameters[key][1:3] = [0.0, False]
    elif mode == "delete_polarization":
        h.InstrumentParameters["Polariz."][1:3] = [0.5, False]
    elif mode == "nuisance_cross_seed":
        h.InstrumentParameters["Polariz."][1] = 0.9693
        h.InstrumentParameters["W"][1] = 10.2466
        h.InstrumentParameters["X"][1] = 5.7375
        gpx.phase(0).data["Histograms"][h.name]["Size"][1][0] = 0.0599
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 55)


rows = []
for mode in MODES:
    path = OUTDIR / f"{mode}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path)); configure(gpx, mode)
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured), contextlib.redirect_stderr(captured):
        gpx.save(); gpx.refine()
        replay = G2sc.G2Project(str(path))
        replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        replay.set_Controls("cycles", 55); replay.refine()
    h = replay.histogram(0); rv = replay.data["Covariance"]["data"].get("Rvals", {})
    row = {
        "mode": mode, "project": str(path.relative_to(ROOT)),
        "Rwp": h.get_wR(), "GOF": rv.get("GOF"),
        "converged": rv.get("converged"), "message": rv.get("msg", ""),
        "profile": {k: h.InstrumentParameters[k][1] for k in ("U", "W", "X")},
        "polarization": h.InstrumentParameters["Polariz."][1],
        "p3_march_ratio": replay.phase(3).data["Histograms"][h.name]["Pref.Ori."][1],
        "fractions": {n: v[0] for n, v in h.ComputeMassFracs().items()},
        "sizes": {p.name: {
            "model": p.data["Histograms"][h.name]["Size"][0],
            "values": list(p.data["Histograms"][h.name]["Size"][1][:2]),
        } for p in replay.phases()},
    }
    diagnostic = captured.getvalue()
    if "Warning" in diagnostic or "Error" in diagnostic or "singular" in diagnostic.lower():
        row["diagnostic_tail"] = diagnostic[-5000:]
    rows.append(row); print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "four_phase_term_deletions.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
