#!/usr/bin/env python3
"""Cross-seed the serious 9009811 PbWO4 source into the accepted W/X basis."""

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "pbwo4_source_axis_cross" / "s9009811_0_1_m1_seed1.40.gpx"
OUTDIR = ROOT / ".tmp" / "source900_profile"
OUTDIR.mkdir(parents=True, exist_ok=True)

rows = []
for w_seed, x_seed in ((1.0, 6.0), (9.0, 6.0), (20.0, 2.0)):
    tag = f"w{w_seed:.0f}_x{x_seed:.0f}"
    path = OUTDIR / f"{tag}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path))
    h = gpx.histogram(0)
    h.InstrumentParameters["U"][:] = [0.0, 0.0, False]
    h.InstrumentParameters["W"][:] = [w_seed, w_seed, True]
    h.InstrumentParameters["X"][:] = [x_seed, x_seed, True]
    for key in ("W", "X"):
        gpx.set_Controls("parmMin", 0.0, variable=f":0:{key}")
        gpx.set_Controls("parmMax", 200.0, variable=f":0:{key}")
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 40)
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        gpx.save()
        gpx.refine()
        replay = G2sc.G2Project(str(path))
        replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        replay.refine()
    h = replay.histogram(0)
    rv = replay.data["Covariance"]["data"].get("Rvals", {})
    row = {
        "seed": [w_seed, x_seed],
        "project": str(path.relative_to(ROOT)),
        "Rwp": h.get_wR(),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "message": rv.get("msg", ""),
        "profile": {k: h.InstrumentParameters[k][1] for k in ("U", "W", "X")},
        "fractions": {n: v[0] for n, v in h.ComputeMassFracs().items()},
    }
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "source900_profile.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
