#!/usr/bin/env python3
"""Apply the accepted polarization correction to the best 9009811 source branch."""

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "axes_source900_size" / "p0_0_0_1.gpx"
OUTDIR = ROOT / ".tmp" / "source900_polarization"
OUTDIR.mkdir(parents=True, exist_ok=True)

rows = []
for seed in (0.2, 0.5, 0.8):
    path = OUTDIR / f"seed{seed:.1f}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path))
    h = gpx.histogram(0)
    h.InstrumentParameters["Polariz."][1] = seed
    h.InstrumentParameters["Polariz."][2] = True
    gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 45)
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        gpx.save()
        gpx.refine()
        replay = G2sc.G2Project(str(path))
        replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        replay.refine()
    h = replay.histogram(0)
    rv = replay.data["Covariance"]["data"].get("Rvals", {})
    row = {
        "seed": seed, "project": str(path.relative_to(ROOT)),
        "Rwp": h.get_wR(), "GOF": rv.get("GOF"),
        "converged": rv.get("converged"), "message": rv.get("msg", ""),
        "polarization": h.InstrumentParameters["Polariz."][1],
        "fractions": {n: v[0] for n, v in h.ComputeMassFracs().items()},
    }
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "source900_polarization.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
