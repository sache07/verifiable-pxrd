#!/usr/bin/env python3
from pathlib import Path
from pprint import pprint

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

gpx = G2sc.G2Project(newgpx=str(ROOT / "scratch.gpx"))
h = gpx.add_powder_histogram(
    str(ROOT / "inputs/pattern.csv"),
    str(ROOT / "instrument.instprm"),
    fmthint="comma/tab/semicolon separated",
)
p1 = gpx.add_phase(
    str(COD / "9/00/98/9009811.cif"),
    phasename="PbWO4_scheelite",
    histograms=[h],
    fmthint="CIF",
)
p2 = gpx.add_phase(
    str(COD / "2/31/10/2311041.cif"),
    phasename="WO3_monoclinic",
    histograms=[h],
    fmthint="CIF",
)
gpx.save()
print("HIST", h.name)
pprint(h.InstrumentParameters)
pprint(h.SampleParameters)
pprint(h.Background)
for p in [p1, p2]:
    print("PHASE", p.name)
    pprint(p.data["General"]["Cell"])
    pprint(p.data["Histograms"][h.name])
