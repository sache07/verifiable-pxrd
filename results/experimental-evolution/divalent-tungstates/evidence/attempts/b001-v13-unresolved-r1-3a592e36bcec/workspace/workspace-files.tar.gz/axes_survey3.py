#!/usr/bin/env python3
"""Complete low-index March-Dollase or uniaxial-size axis survey."""

import argparse
import contextlib
import io
import itertools
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "coupled_deletion_profile" / "baseline.gpx"


def canonical_axis(vector):
    vector = tuple(int(round(v)) for v in vector)
    divisor = math.gcd(*[abs(v) for v in vector if v])
    vector = tuple(v // divisor for v in vector)
    for value in vector:
        if value:
            return tuple(-v for v in vector) if value < 0 else vector
    raise ValueError("zero axis")


def inequivalent_axes(phase, maximum=2):
    rotations = []
    for matrix, _translation in phase.data["General"]["SGData"]["SGOps"]:
        reciprocal = np.rint(np.linalg.inv(np.asarray(matrix)).T).astype(int)
        if not any(np.array_equal(reciprocal, old) for old in rotations):
            rotations.append(reciprocal)
    candidates = set()
    for vector in itertools.product(range(-maximum, maximum + 1), repeat=3):
        if vector == (0, 0, 0):
            continue
        if math.gcd(*[abs(v) for v in vector if v]) != 1:
            continue
        candidates.add(canonical_axis(vector))
    seen, representatives = set(), []
    ordering = lambda v: (max(map(abs, v)), sum(abs(x) for x in v), v)
    for vector in sorted(candidates, key=ordering):
        if vector in seen:
            continue
        orbit = {canonical_axis(rotation @ np.asarray(vector))
                 for rotation in rotations}
        seen.update(orbit)
        representatives.append(vector)
    return representatives


parser = argparse.ArgumentParser()
parser.add_argument("mode", choices=("texture", "size"))
parser.add_argument("--base", default=str(BASE))
parser.add_argument("--prefix", default="axes_survey3")
parser.add_argument("--phase", type=int)
args = parser.parse_args()
BASE = Path(args.base)
if not BASE.is_absolute():
    BASE = ROOT / BASE
OUTDIR = ROOT / ".tmp" / f"{args.prefix}_{args.mode}"
OUTDIR.mkdir(parents=True, exist_ok=True)

template = G2sc.G2Project(str(BASE))
axis_sets = {p.id: inequivalent_axes(p) for p in template.phases()
             if args.phase is None or p.id == args.phase}
print(json.dumps({template.phase(i).name: axes for i, axes in axis_sets.items()}),
      flush=True)

rows = []
for phase_index, axes in axis_sets.items():
    for axis in axes:
        tag = "_".join(str(value).replace("-", "m") for value in axis)
        path = OUTDIR / f"p{phase_index}_{tag}.gpx"
        gpx = G2sc.G2Project(str(BASE), newgpx=str(path))
        h = gpx.histogram(0)
        p = gpx.phase(phase_index)
        hap = p.data["Histograms"][h.name]
        gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        gpx.set_Controls("cycles", 12)

        if args.mode == "texture":
            po = hap["Pref.Ori."]
            po[0:4] = ["MD", 1.0, True, list(axis)]
            gpx.set_Controls("parmMin", 0.2, variable=f"{p.id}:0:MD")
            gpx.set_Controls("parmMax", 5.0, variable=f"{p.id}:0:MD")
        else:
            size = hap["Size"]
            seed = size[1][0] if size[2][0] and size[1][0] < 9.0 else 0.10
            size[0] = "uniaxial"
            size[1][0:3] = [seed, seed, 1.0]
            size[2][0:3] = [True, True, False]
            size[3] = list(axis)
            for suffix in ("i", "a"):
                gpx.set_Controls("parmMin", 0.001,
                                 variable=f"{p.id}:0:Size;{suffix}")
                gpx.set_Controls("parmMax", 10.0,
                                 variable=f"{p.id}:0:Size;{suffix}")

        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            gpx.save()
            gpx.refine()

        h = gpx.histogram(0)
        p = gpx.phase(phase_index)
        hap = p.data["Histograms"][h.name]
        rv = gpx.data["Covariance"]["data"].get("Rvals", {})
        row = {
            "phase_index": phase_index,
            "phase": p.name,
            "mode": args.mode,
            "axis": list(axis),
            "Rwp": h.get_wR(),
            "GOF": rv.get("GOF"),
            "converged": rv.get("converged"),
            "message": rv.get("msg", ""),
            "fractions": {name: pair[0] for name, pair in h.ComputeMassFracs().items()},
            "project": str(path.relative_to(ROOT)),
        }
        if args.mode == "texture":
            row["march_ratio"] = hap["Pref.Ori."][1]
        else:
            row["equatorial_size_um"] = hap["Size"][1][0]
            row["axial_size_um"] = hap["Size"][1][1]
        rows.append(row)
        print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / f"{args.prefix}_{args.mode}.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
