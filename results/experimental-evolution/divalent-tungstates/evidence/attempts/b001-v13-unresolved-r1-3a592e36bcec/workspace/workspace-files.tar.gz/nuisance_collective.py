#!/usr/bin/env python3
"""Cross-seed polarization/background/roughness interactions."""

import contextlib
import io
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "anisotropy_replay" / "eq0.10_ax0.05.gpx"
OUTDIR = ROOT / ".tmp" / "nuisance_collective"
OUTDIR.mkdir(parents=True, exist_ok=True)

BRANCHES = [
    ("pol_seed02", 8, 0.2, None),
    ("pol_seed05", 8, 0.5, None),
    ("pol_seed08", 8, 0.8, None),
    ("pol_bg6", 6, 0.5, None),
    ("pol_bg10", 10, 0.5, None),
    ("rough_seed_low", 8, None, (0.03, 0.03)),
    ("rough_seed_high", 8, None, (0.30, 0.20)),
    ("pol_rough_low", 8, 0.5, (0.03, 0.03)),
    ("pol_rough_high", 8, 0.8, (0.30, 0.20)),
]


def roughness_curve(a, b):
    tth = np.asarray([15.0, 30.0, 50.0, 70.0, 90.0])
    sth = np.sin(np.radians(tth / 2.0))
    t1 = np.exp(-b / sth)
    t2 = a + (1.0 - a) * np.exp(-b)
    return [float(v) for v in ((a + (1.0 - a) * t1) / t2)]


def configure(gpx, background_count, polarization_seed, roughness_seed):
    h = gpx.histogram(0)
    coeffs = list(h.Background[0][3:])
    if background_count != len(coeffs):
        h.set_refinements({"Background": {
            "type": "chebyschev-1", "refine": True,
            "no. coeffs": background_count,
            "coeffs": (coeffs + [0.0] * background_count)[:background_count],
        }})
    h.InstrumentParameters["Polariz."][2] = polarization_seed is not None
    if polarization_seed is not None:
        h.InstrumentParameters["Polariz."][1] = polarization_seed
        gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    h.SampleParameters["SurfRoughA"][:] = [0.0, False]
    h.SampleParameters["SurfRoughB"][:] = [0.0, False]
    if roughness_seed is not None:
        h.SampleParameters["SurfRoughA"][:] = [roughness_seed[0], True]
        h.SampleParameters["SurfRoughB"][:] = [roughness_seed[1], True]
        for name in ("SurfRoughA", "SurfRoughB"):
            gpx.set_Controls("parmMin", 0.0, variable=f":0:{name}")
            gpx.set_Controls("parmMax", 1.0, variable=f":0:{name}")
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 45)


rows = []
for name, background_count, polarization_seed, roughness_seed in BRANCHES:
    path = OUTDIR / f"{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path))
    configure(gpx, background_count, polarization_seed, roughness_seed)
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        gpx.save()
        gpx.refine()
        replay = G2sc.G2Project(str(path))
        replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        replay.refine()
    h = replay.histogram(0)
    rv = replay.data["Covariance"]["data"].get("Rvals", {})
    a = h.SampleParameters["SurfRoughA"][0]
    b = h.SampleParameters["SurfRoughB"][0]
    row = {
        "name": name,
        "project": str(path.relative_to(ROOT)),
        "Rwp": h.get_wR(),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "message": rv.get("msg", ""),
        "background_coefficients": len(h.Background[0]) - 3,
        "polarization": h.InstrumentParameters["Polariz."][1],
        "roughness_A": a,
        "roughness_B": b,
        "roughness_curve_15_30_50_70_90deg": roughness_curve(a, b),
        "fractions": {n: v[0] for n, v in h.ComputeMassFracs().items()},
    }
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "nuisance_collective.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
