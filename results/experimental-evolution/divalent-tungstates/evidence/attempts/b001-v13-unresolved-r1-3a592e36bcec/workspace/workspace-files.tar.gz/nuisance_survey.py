#!/usr/bin/env python3
"""Compare simple backgrounds, polarization, roughness and asymmetry."""

import contextlib
import io
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "anisotropy_replay" / "eq0.10_ax0.05.gpx"
OUTDIR = ROOT / ".tmp" / "nuisance_survey"
OUTDIR.mkdir(parents=True, exist_ok=True)

MODES = ("baseline", "background4", "background6", "background10",
         "polarization", "roughness_A", "roughness_AB", "SHL")


def configure(gpx, mode):
    h = gpx.histogram(0)
    coeffs = list(h.Background[0][3:])
    if mode.startswith("background"):
        count = int(mode.replace("background", ""))
        values = (coeffs + [0.0] * count)[:count]
        h.set_refinements({"Background": {
            "type": "chebyschev-1", "refine": True,
            "no. coeffs": count, "coeffs": values,
        }})
    elif mode == "polarization":
        h.InstrumentParameters["Polariz."][1] = 0.5
        h.InstrumentParameters["Polariz."][2] = True
        gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif mode == "roughness_A":
        h.SampleParameters["SurfRoughA"][:] = [0.01, True]
        h.SampleParameters["SurfRoughB"][:] = [0.0, False]
        gpx.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
        gpx.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
    elif mode == "roughness_AB":
        h.SampleParameters["SurfRoughA"][:] = [0.01, True]
        h.SampleParameters["SurfRoughB"][:] = [0.01, True]
        for name in ("SurfRoughA", "SurfRoughB"):
            gpx.set_Controls("parmMin", 0.0, variable=f":0:{name}")
            gpx.set_Controls("parmMax", 1.0, variable=f":0:{name}")
    elif mode == "SHL":
        h.InstrumentParameters["SH/L"][1] = 0.002
        h.InstrumentParameters["SH/L"][2] = True
        gpx.set_Controls("parmMin", 0.0005, variable=":0:SH/L")
        gpx.set_Controls("parmMax", 0.10, variable=":0:SH/L")
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 35)


def angular_statistics(h):
    x, obs, weights, calc = [np.asarray(a) for a in h.data["data"][1][:4]]
    active = (x >= h.data["Limits"][1][0]) & (x <= h.data["Limits"][1][1])
    bins = ((10, 30), (30, 55), (55, 75), (75, 100))
    result = []
    for low, high in bins:
        mask = active & (x >= low) & (x < high)
        numerator = np.sum(weights[mask] * (obs[mask] - calc[mask]) ** 2)
        denominator = np.sum(weights[mask] * obs[mask] ** 2)
        result.append({
            "range_deg": [low, high],
            "Rwp_percent": float(100.0 * np.sqrt(numerator / denominator)),
            "mean_difference": float(np.mean(obs[mask] - calc[mask])),
        })
    return result


rows = []
for mode in MODES:
    path = OUTDIR / f"{mode}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path))
    configure(gpx, mode)
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        gpx.save()
        gpx.refine()
        replay = G2sc.G2Project(str(path))
        replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        replay.refine()
    h = replay.histogram(0)
    rv = replay.data["Covariance"]["data"].get("Rvals", {})
    row = {
        "mode": mode,
        "project": str(path.relative_to(ROOT)),
        "Rwp": h.get_wR(),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "message": rv.get("msg", ""),
        "background_coefficients": len(h.Background[0]) - 3,
        "polarization": h.InstrumentParameters["Polariz."][1],
        "roughness_A": h.SampleParameters["SurfRoughA"][0],
        "roughness_B": h.SampleParameters["SurfRoughB"][0],
        "SHL": h.InstrumentParameters["SH/L"][1],
        "fractions": {n: v[0] for n, v in h.ComputeMassFracs().items()},
        "angular_statistics": angular_statistics(h),
    }
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "nuisance_survey.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
