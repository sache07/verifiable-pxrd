#!/usr/bin/env python3
"""Final background, polarization, roughness and SH/L comparisons."""

import contextlib
import io
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "four_phase_term_deletions" / "nuisance_cross_seed.gpx"
OUTDIR = ROOT / ".tmp" / "four_phase_nuisance"
OUTDIR.mkdir(parents=True, exist_ok=True)

BRANCHES = [
    ("replay", 8, 0.8, None, None),
    ("background6", 6, 0.8, None, None),
    ("background10", 10, 0.8, None, None),
    ("background12", 12, 0.8, None, None),
    ("background14", 14, 0.8, None, None),
    ("polarization02", 8, 0.2, None, None),
    ("polarization05", 8, 0.5, None, None),
    ("no_polarization", 8, None, None, None),
    ("rough_only", 8, None, (0.10, 0.10), None),
    ("pol_rough_low", 8, 0.5, (0.03, 0.03), None),
    ("pol_rough_high", 8, 0.8, (0.30, 0.20), None),
    ("shl002", 8, 0.8, None, 0.002),
    ("shl010", 8, 0.8, None, 0.010),
]


def rough_curve(a, b):
    tth = np.asarray([15., 30., 50., 70., 90.]); sth = np.sin(np.radians(tth / 2.))
    return [float(v) for v in ((a + (1-a)*np.exp(-b/sth)) / (a + (1-a)*np.exp(-b)))]


def configure(gpx, nback, polseed, roughseed, shlseed):
    h = gpx.histogram(0); coeffs = list(h.Background[0][3:])
    h.set_refinements({"Background": {"type": "chebyschev-1", "refine": True,
        "no. coeffs": nback, "coeffs": (coeffs + [0.0]*nback)[:nback]}})
    h.InstrumentParameters["Polariz."][1:3] = [0.5 if polseed is None else polseed,
                                                polseed is not None]
    if polseed is not None:
        gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    h.SampleParameters["SurfRoughA"][:] = [0.0, False]
    h.SampleParameters["SurfRoughB"][:] = [0.0, False]
    if roughseed:
        h.SampleParameters["SurfRoughA"][:] = [roughseed[0], True]
        h.SampleParameters["SurfRoughB"][:] = [roughseed[1], True]
        for key in ("SurfRoughA", "SurfRoughB"):
            gpx.set_Controls("parmMin", 0.0, variable=f":0:{key}")
            gpx.set_Controls("parmMax", 1.0, variable=f":0:{key}")
    h.InstrumentParameters["SH/L"][1:3] = [0.0005 if shlseed is None else shlseed,
                                            shlseed is not None]
    if shlseed is not None:
        gpx.set_Controls("parmMin", 0.0005, variable=":0:SH/L")
        gpx.set_Controls("parmMax", 0.2, variable=":0:SH/L")
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 55)


rows=[]
for name,nback,polseed,roughseed,shlseed in BRANCHES:
    path=OUTDIR/f"{name}.gpx"; gpx=G2sc.G2Project(str(BASE),newgpx=str(path))
    configure(gpx,nback,polseed,roughseed,shlseed); captured=io.StringIO()
    with contextlib.redirect_stdout(captured),contextlib.redirect_stderr(captured):
        gpx.save(); gpx.refine(); replay=G2sc.G2Project(str(path))
        replay.data["Controls"]["data"]["parmFrozen"]={"FrozenList":[]}
        replay.set_Controls("cycles",55); replay.refine()
    h=replay.histogram(0); rv=replay.data["Covariance"]["data"].get("Rvals",{})
    a=h.SampleParameters["SurfRoughA"][0]; b=h.SampleParameters["SurfRoughB"][0]
    y=h.data["data"][1]; x=np.asarray(y[0]); resid=np.asarray(y[1])-np.asarray(y[3])
    seg={}
    for lo,hi in ((10,30),(30,60),(60,80),(80,100)):
        use=(x>=lo)&(x<hi); seg[f"{lo}_{hi}"]=float(np.sqrt(np.mean(resid[use]**2)))
    row={"name":name,"project":str(path.relative_to(ROOT)),"Rwp":h.get_wR(),
         "GOF":rv.get("GOF"),"chisq":rv.get("chisq"),"Nobs":rv.get("Nobs"),
         "Nvars":rv.get("Nvars"),"converged":rv.get("converged"),
         "message":rv.get("msg",""),"background_coefficients":len(h.Background[0])-3,
         "background_values":list(h.Background[0][3:]),
         "polarization":h.InstrumentParameters["Polariz."][1],
         "roughness_A":a,"roughness_B":b,"roughness_curve":rough_curve(a,b),
         "SH_L":h.InstrumentParameters["SH/L"][1],"segment_residual_rms":seg,
         "fractions":{n:v[0] for n,v in h.ComputeMassFracs().items()}}
    diagnostic=captured.getvalue()
    if "Warning" in diagnostic or "Error" in diagnostic or "singular" in diagnostic.lower():
        row["diagnostic_tail"]=diagnostic[-5000:]
    rows.append(row); print(json.dumps(row,sort_keys=True),flush=True)
with open(ROOT/"four_phase_nuisance.json","w") as stream:
    json.dump(rows,stream,indent=2,sort_keys=True)
