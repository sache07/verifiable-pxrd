#!/usr/bin/env python3
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "explore.bak0.gpx"


def set_neutral(gpx):
    h = gpx.histogram(0)
    inst = h.InstrumentParameters
    for key, value in (("U", 0.0), ("V", 0.0), ("W", 0.0),
                       ("X", 10.0), ("Y", 0.0), ("Z", 0.0)):
        inst[key][1] = value
        inst[key][2] = key == "X"
    inst["Zero"][2] = True
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    controls = gpx.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("parmMin", 0.0, variable=":0:X")
    gpx.set_Controls("parmMax", 200.0, variable=":0:X")
    gpx.set_Controls("cycles", 20)


def set_model(gpx, phase_index, model):
    h = gpx.histogram(0)
    p = gpx.phase(phase_index)
    hap = p.data["Histograms"][h.name]
    if model in ("size", "combined"):
        hap["Size"][1][0] = 0.10
        hap["Size"][2][0] = True
        gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;i")
    if model in ("strain", "combined"):
        hap["Mustrain"][1][0] = 750.0
        hap["Mustrain"][2][0] = True
        gpx.set_Controls("parmMin", 0.0, variable=f"{p.id}:0:Mustrain;i")
        gpx.set_Controls("parmMax", 10000.0, variable=f"{p.id}:0:Mustrain;i")


def one_branch(phase_index, model):
    name = f"survey_p{phase_index}_{model}"
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(ROOT / f"{name}.gpx"))
    set_neutral(gpx)
    set_model(gpx, phase_index, model)
    h = gpx.histogram(0)
    if model != "neutral":
        h.InstrumentParameters["X"][2] = False
    gpx.save()
    gpx.refine()
    if model != "neutral":
        h = gpx.histogram(0)
        h.InstrumentParameters["X"][2] = True
        gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        gpx.refine()
    # Mandatory replay with all accepted values and flags reloaded.
    replay = G2sc.G2Project(str(ROOT / f"{name}.gpx"))
    replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    replay.refine()
    h = replay.histogram(0)
    rvals = replay.data["Covariance"]["data"].get("Rvals", {})
    phases = []
    for p in replay.phases():
        hap = p.data["Histograms"][h.name]
        phases.append({
            "name": p.name,
            "scale": hap["Scale"][0],
            "size_um": hap["Size"][1][0],
            "size_refine": hap["Size"][2][0],
            "mustrain": hap["Mustrain"][1][0],
            "mustrain_refine": hap["Mustrain"][2][0],
        })
    msg = rvals.get("msg", "")
    return {
        "phase_index": phase_index,
        "model": model,
        "project": f"{name}.gpx",
        "Rwp": h.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "delta_chi2": rvals.get("DelChi2"),
        "message": msg,
        "zero": h.InstrumentParameters["Zero"][1],
        "X": h.InstrumentParameters["X"][1],
        "fractions": {k: v[0] for k, v in h.ComputeMassFracs().items()},
        "phases": phases,
    }


rows = []
for phase_index in (0, 1):
    for model in ("neutral", "size", "strain", "combined"):
        row = one_branch(phase_index, model)
        rows.append(row)
        print(json.dumps(row, sort_keys=True))

with open(ROOT / "width_survey.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
