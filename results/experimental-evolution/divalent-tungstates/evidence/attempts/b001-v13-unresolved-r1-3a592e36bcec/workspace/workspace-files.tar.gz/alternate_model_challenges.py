#!/usr/bin/env python3
"""Replay and prune the leading 1527935 PbWO4 coupled model."""

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "pbwo4_source_axis_cross" / "s1527935_0_1_m2_seed1.40.gpx"
OUTDIR = ROOT / ".tmp" / "alternate_model_challenges"
OUTDIR.mkdir(parents=True, exist_ok=True)

MODES = (
    "replay", "delete_pbwo4_size", "delete_pb3o4_size", "delete_texture",
    "pbwo4_strain_only", "pb3o4_strain_only", "sizes_plus_both_strains",
    "wo3_size", "wo3_strain", "full_profile_0.1", "full_profile_2.0",
)


def inactive_size(hap):
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])


def inactive_strain(hap):
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])


def add_strain(gpx, index, seed=1000.0):
    h = gpx.histogram(0)
    p = gpx.phase(index)
    hap = p.data["Histograms"][h.name]
    inactive_strain(hap)
    hap["Mustrain"][1][0] = seed
    hap["Mustrain"][2][0] = True
    gpx.set_Controls("parmMin", 0.0, variable=f"{p.id}:0:Mustrain;i")
    gpx.set_Controls("parmMax", 10000.0, variable=f"{p.id}:0:Mustrain;i")


def configure(gpx, mode):
    h = gpx.histogram(0)
    for p in gpx.phases():
        inactive_strain(p.data["Histograms"][h.name])
    for key in ("U", "V", "W", "X", "Y", "Z"):
        h.InstrumentParameters[key][2] = key == "X"
    h.InstrumentParameters["U"][1] = 0.0
    h.InstrumentParameters["V"][1] = 0.0
    h.InstrumentParameters["W"][1] = 0.0
    h.InstrumentParameters["Y"][1] = 0.0
    h.InstrumentParameters["Z"][1] = 0.0
    h.InstrumentParameters["Zero"][2] = True

    if mode == "delete_pbwo4_size":
        inactive_size(gpx.phase(0).data["Histograms"][h.name])
    elif mode == "delete_pb3o4_size":
        inactive_size(gpx.phase(2).data["Histograms"][h.name])
    elif mode == "delete_texture":
        gpx.phase(0).data["Histograms"][h.name]["Pref.Ori."][0:4] = [
            "MD", 1.0, False, [0, 1, -2]]
    elif mode == "pbwo4_strain_only":
        inactive_size(gpx.phase(0).data["Histograms"][h.name])
        add_strain(gpx, 0)
    elif mode == "pb3o4_strain_only":
        inactive_size(gpx.phase(2).data["Histograms"][h.name])
        add_strain(gpx, 2)
    elif mode == "sizes_plus_both_strains":
        add_strain(gpx, 0, 500.0)
        add_strain(gpx, 2, 500.0)
    elif mode == "wo3_size":
        p = gpx.phase(1)
        hap = p.data["Histograms"][h.name]
        inactive_size(hap)
        hap["Size"][1][0] = 0.10
        hap["Size"][2][0] = True
        gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;i")
    elif mode == "wo3_strain":
        add_strain(gpx, 1)
    elif mode.startswith("full_profile"):
        seed = float(mode.rsplit("_", 1)[1])
        h.InstrumentParameters["U"][:] = [seed, seed, True]
        h.InstrumentParameters["W"][:] = [seed, seed, True]
        for variable in (":0:U", ":0:W", ":0:X"):
            gpx.set_Controls("parmMin", 0.0, variable=variable)
            gpx.set_Controls("parmMax", 200.0, variable=variable)
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 30)


def summarize(gpx, mode, path):
    h = gpx.histogram(0)
    rv = gpx.data["Covariance"]["data"].get("Rvals", {})
    return {
        "mode": mode,
        "project": str(path.relative_to(ROOT)),
        "Rwp": h.get_wR(),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "message": rv.get("msg", ""),
        "profile": {k: h.InstrumentParameters[k][1] for k in ("U", "W", "X")},
        "fractions": {name: pair[0] for name, pair in h.ComputeMassFracs().items()},
        "texture": {
            "axis": gpx.phase(0).data["Histograms"][h.name]["Pref.Ori."][3],
            "ratio": gpx.phase(0).data["Histograms"][h.name]["Pref.Ori."][1],
            "refine": gpx.phase(0).data["Histograms"][h.name]["Pref.Ori."][2],
        },
        "widths": {
            p.name: {
                "size_um": p.data["Histograms"][h.name]["Size"][1][0],
                "size_refine": p.data["Histograms"][h.name]["Size"][2][0],
                "strain": p.data["Histograms"][h.name]["Mustrain"][1][0],
                "strain_refine": p.data["Histograms"][h.name]["Mustrain"][2][0],
            } for p in gpx.phases()
        },
    }


rows = []
for mode in MODES:
    path = OUTDIR / f"{mode}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path))
    configure(gpx, mode)
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        gpx.save()
        gpx.refine()
        replay = G2sc.G2Project(str(path))
        replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        replay.refine()
    row = summarize(replay, mode, path)
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "alternate_model_challenges.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
