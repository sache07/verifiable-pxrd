#!/usr/bin/env python3
import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUTDIR = ROOT / ".tmp" / "three_phase_survey"
OUTDIR.mkdir(parents=True, exist_ok=True)

PBWO4 = COD / "9/00/98/9009811.cif"
WO3 = COD / "2/31/10/2311041.cif"
PB3O4_SOURCES = [
    ("9012124", COD / "9/01/21/9012124.cif"),
    ("9013442", COD / "9/01/34/9013442.cif"),
    ("9003043", COD / "9/00/30/9003043.cif"),
]


def neutralize(p, hname):
    hap = p.data["Histograms"][hname]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]


def build(source_id, source_path):
    project_path = OUTDIR / f"pb3o4_{source_id}.gpx"
    gpx = G2sc.G2Project(newgpx=str(project_path))
    h = gpx.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"), str(ROOT / "instrument.instprm"),
        fmthint="comma/tab/semicolon separated")
    phases = [
        gpx.add_phase(str(PBWO4), phasename="PbWO4_scheelite",
                      histograms=[h], fmthint="CIF"),
        gpx.add_phase(str(WO3), phasename="WO3_monoclinic",
                      histograms=[h], fmthint="CIF"),
        gpx.add_phase(str(source_path), phasename=f"Pb3O4_source_{source_id}",
                      histograms=[h], fmthint="CIF"),
    ]
    h.set_refinements({"Limits": [10.0, 100.0]})
    h.SampleParameters["Scale"][:] = [1.0, False]
    h.SampleParameters["SurfRoughA"][:] = [0.0, False]
    h.SampleParameters["SurfRoughB"][:] = [0.0, False]
    for key, value, refine in (
        ("Zero", 0.435, True), ("U", 0.0, False), ("V", 0.0, False),
        ("W", 0.0, False), ("X", 8.7, True), ("Y", 0.0, False),
        ("Z", 0.0, False), ("SH/L", 0.0005, False),
        ("Polariz.", 0.5, False),
    ):
        h.InstrumentParameters[key][1] = value
        h.InstrumentParameters[key][2] = refine
    h.set_refinements({"Background": {
        "type": "chebyschev-1", "refine": True, "no. coeffs": 8,
        "coeffs": [1515.0, -1177.0, 614.0, -243.0, 72.0, -24.0, 8.0, 5.0],
    }})
    for phase, scale in zip(phases, (8.0, 3.0, 1.5)):
        neutralize(phase, h.name)
        phase.HAPvalue("Scale", scale)
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})
    pb_size = phases[0].data["Histograms"][h.name]["Size"]
    pb_size[1][0], pb_size[2][0] = 0.068, True
    gpx.set_Controls("parmMin", 0.001, variable="0:0:Size;i")
    gpx.set_Controls("parmMax", 10.0, variable="0:0:Size;i")
    gpx.set_Controls("parmMin", 0.0, variable=":0:X")
    gpx.set_Controls("parmMax", 200.0, variable=":0:X")
    gpx.set_Controls("cycles", 20)
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        gpx.save()
        gpx.refine()
        gpx.refine()
    h = gpx.histogram(0)
    rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
    return {
        "source": source_id,
        "project": str(project_path.relative_to(ROOT)),
        "Rwp": h.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "message": rvals.get("msg", ""),
        "zero": h.InstrumentParameters["Zero"][1],
        "X": h.InstrumentParameters["X"][1],
        "fractions": {name: pair[0] for name, pair in h.ComputeMassFracs().items()},
        "scales": {p.name: p.data["Histograms"][h.name]["Scale"][0]
                   for p in gpx.phases()},
        "cells": {p.name: p.get_cell() for p in gpx.phases()},
        "pbwo4_size_um": gpx.phase(0).data["Histograms"][h.name]["Size"][1][0],
    }


rows = []
for source_id, source_path in PB3O4_SOURCES:
    row = build(source_id, source_path)
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)
with open(ROOT / "three_phase_survey.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
