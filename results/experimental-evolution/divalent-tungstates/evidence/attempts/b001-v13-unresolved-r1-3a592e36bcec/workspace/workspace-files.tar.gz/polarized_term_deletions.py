#!/usr/bin/env python3
"""Delete/prune terms after accepting the polarization correction."""

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "nuisance_collective" / "pol_seed05.gpx"
OUTDIR = ROOT / ".tmp" / "polarized_term_deletions"
OUTDIR.mkdir(parents=True, exist_ok=True)

MODES = ("replay", "isotropic_pbwo4_size", "delete_pbwo4_size",
         "delete_pb3o4_size", "delete_texture", "delete_W", "delete_X",
         "delete_polarization")


def inactive_size(size):
    size[0] = "isotropic"
    size[1][:] = [10.0, 10.0, 1.0]
    size[2][:] = [False, False, False]
    size[5][:] = [False] * len(size[5])


def configure(gpx, mode):
    h = gpx.histogram(0)
    if mode == "isotropic_pbwo4_size":
        p = gpx.phase(0)
        size = p.data["Histograms"][h.name]["Size"]
        size[0] = "isotropic"
        size[1][:] = [0.060, 10.0, 1.0]
        size[2][:] = [True, False, False]
        size[5][:] = [False] * len(size[5])
        gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;i")
    elif mode == "delete_pbwo4_size":
        inactive_size(gpx.phase(0).data["Histograms"][h.name]["Size"])
    elif mode == "delete_pb3o4_size":
        inactive_size(gpx.phase(2).data["Histograms"][h.name]["Size"])
    elif mode == "delete_texture":
        gpx.phase(0).data["Histograms"][h.name]["Pref.Ori."][0:4] = [
            "MD", 1.0, False, [0, 1, -2]]
    elif mode in ("delete_W", "delete_X"):
        key = mode[-1]
        h.InstrumentParameters[key][1] = 0.0
        h.InstrumentParameters[key][2] = False
    elif mode == "delete_polarization":
        h.InstrumentParameters["Polariz."][1] = 0.5
        h.InstrumentParameters["Polariz."][2] = False
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 40)


rows = []
for mode in MODES:
    path = OUTDIR / f"{mode}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path))
    configure(gpx, mode)
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        gpx.save()
        gpx.refine()
        replay = G2sc.G2Project(str(path))
        replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        replay.refine()
    h = replay.histogram(0)
    rv = replay.data["Covariance"]["data"].get("Rvals", {})
    p0size = replay.phase(0).data["Histograms"][h.name]["Size"]
    row = {
        "mode": mode,
        "project": str(path.relative_to(ROOT)),
        "Rwp": h.get_wR(),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "message": rv.get("msg", ""),
        "profile": {k: h.InstrumentParameters[k][1] for k in ("U", "W", "X")},
        "polarization": h.InstrumentParameters["Polariz."][1],
        "pbwo4_size_model": p0size[0],
        "pbwo4_sizes_um": list(p0size[1][:2]),
        "fractions": {n: v[0] for n, v in h.ComputeMassFracs().items()},
    }
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "polarized_term_deletions.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
