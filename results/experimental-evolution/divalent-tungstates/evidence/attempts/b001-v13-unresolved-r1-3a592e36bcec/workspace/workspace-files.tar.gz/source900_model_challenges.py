#!/usr/bin/env python3
"""Replay-stable model/deletion/collective-width tests for source 9009811."""

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "source900_polarization" / "seed0.8.gpx"
OUTDIR = ROOT / ".tmp" / "source900_model_challenges"
OUTDIR.mkdir(parents=True, exist_ok=True)

MODES = (
    "replay",
    "p0_isotropic",
    "p0_axis_120",
    "p2_axis_001",
    "p2_axis_02m1",
    "p2_axis_01m1",
    "release_U_seed01",
    "release_U_seed2",
    "delete_W",
    "delete_X",
    "delete_p0_size",
    "delete_p2_size",
    "delete_texture",
    "delete_polarization",
    "p1_size_seed10",
    "p1_strain_seed500",
    "collective_sizes_low",
    "collective_p0p2_strains_low",
    "collective_all_widths_low",
)


def clear_frozen(gpx):
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def set_profile_bounds(gpx, include_u=False, u_seed=0.1):
    h = gpx.histogram(0)
    if include_u:
        h.InstrumentParameters["U"][1:3] = [u_seed, True]
    for key in ("U", "W", "X"):
        if h.InstrumentParameters[key][2]:
            gpx.set_Controls("parmMin", 0.0, variable=f":0:{key}")
            gpx.set_Controls("parmMax", 200.0, variable=f":0:{key}")


def inactive_size(size):
    size[0] = "isotropic"
    size[1][:] = [10.0, 10.0, 1.0]
    size[2][:] = [False, False, False]
    size[5][:] = [False] * len(size[5])


def inactive_strain(strain):
    strain[0] = "isotropic"
    strain[1][:] = [0.0, 0.0, 1.0]
    strain[2][:] = [False, False, False]
    strain[4][:] = [0.0] * len(strain[4])
    strain[5][:] = [False] * len(strain[5])


def set_isotropic_size(gpx, index, seed):
    h = gpx.histogram(0)
    p = gpx.phase(index)
    size = p.data["Histograms"][h.name]["Size"]
    inactive_size(size)
    size[1][0] = seed
    size[2][0] = True
    gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;i")
    gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;i")


def set_uniaxial_size(gpx, index, axis, equatorial, axial):
    h = gpx.histogram(0)
    p = gpx.phase(index)
    size = p.data["Histograms"][h.name]["Size"]
    inactive_size(size)
    size[0] = "uniaxial"
    size[1][0:3] = [equatorial, axial, 1.0]
    size[2][0:3] = [True, True, False]
    size[3] = list(axis)
    for suffix in ("i", "a"):
        gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;{suffix}")
        gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;{suffix}")


def set_isotropic_strain(gpx, index, seed):
    h = gpx.histogram(0)
    p = gpx.phase(index)
    strain = p.data["Histograms"][h.name]["Mustrain"]
    inactive_strain(strain)
    strain[1][0] = seed
    strain[2][0] = True
    gpx.set_Controls("parmMin", 0.0, variable=f"{p.id}:0:Mustrain;i")
    gpx.set_Controls("parmMax", 10000.0, variable=f"{p.id}:0:Mustrain;i")


def configure(gpx, mode):
    h = gpx.histogram(0)
    clear_frozen(gpx)
    set_profile_bounds(gpx)

    if mode == "p0_isotropic":
        set_isotropic_size(gpx, 0, 0.060)
    elif mode == "p0_axis_120":
        set_uniaxial_size(gpx, 0, (1, 2, 0), 0.0505, 0.0803)
    elif mode == "p2_axis_001":
        set_uniaxial_size(gpx, 2, (0, 0, 1), 0.0348, 0.0277)
    elif mode == "p2_axis_02m1":
        set_uniaxial_size(gpx, 2, (0, 2, -1), 0.0364, 0.0134)
    elif mode == "p2_axis_01m1":
        set_uniaxial_size(gpx, 2, (0, 1, -1), 0.0354, 0.0200)
    elif mode.startswith("release_U_seed"):
        set_profile_bounds(gpx, include_u=True,
                           u_seed=0.1 if mode.endswith("01") else 2.0)
    elif mode in ("delete_W", "delete_X"):
        key = mode[-1]
        h.InstrumentParameters[key][1:3] = [0.0, False]
    elif mode == "delete_p0_size":
        inactive_size(gpx.phase(0).data["Histograms"][h.name]["Size"])
    elif mode == "delete_p2_size":
        inactive_size(gpx.phase(2).data["Histograms"][h.name]["Size"])
    elif mode == "delete_texture":
        gpx.phase(0).data["Histograms"][h.name]["Pref.Ori."][0:4] = [
            "MD", 1.0, False, [0, 1, -1]
        ]
    elif mode == "delete_polarization":
        h.InstrumentParameters["Polariz."][1:3] = [0.5, False]
    elif mode == "p1_size_seed10":
        set_isotropic_size(gpx, 1, 0.10)
    elif mode == "p1_strain_seed500":
        set_isotropic_strain(gpx, 1, 500.0)
    elif mode == "collective_sizes_low":
        set_profile_bounds(gpx, include_u=True, u_seed=0.1)
        set_uniaxial_size(gpx, 0, (0, 0, 1), 0.050, 0.050)
        set_isotropic_size(gpx, 2, 0.030)
    elif mode == "collective_p0p2_strains_low":
        set_profile_bounds(gpx, include_u=True, u_seed=0.1)
        set_isotropic_strain(gpx, 0, 100.0)
        set_isotropic_strain(gpx, 2, 100.0)
    elif mode == "collective_all_widths_low":
        set_profile_bounds(gpx, include_u=True, u_seed=0.1)
        set_uniaxial_size(gpx, 0, (0, 0, 1), 0.050, 0.050)
        set_isotropic_size(gpx, 1, 0.10)
        set_isotropic_size(gpx, 2, 0.030)
        for index in range(3):
            set_isotropic_strain(gpx, index, 100.0)

    clear_frozen(gpx)
    gpx.set_Controls("cycles", 45)


def summary(gpx, mode, path):
    h = gpx.histogram(0)
    rv = gpx.data["Covariance"]["data"].get("Rvals", {})
    phases = []
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        phases.append({
            "name": p.name,
            "size_model": hap["Size"][0],
            "size_values": list(hap["Size"][1][:2]),
            "size_flags": list(hap["Size"][2][:2]),
            "size_axis": list(hap["Size"][3]),
            "strain_values": list(hap["Mustrain"][1][:2]),
            "strain_flags": list(hap["Mustrain"][2][:2]),
            "march_ratio": hap["Pref.Ori."][1],
        })
    return {
        "mode": mode,
        "project": str(path.relative_to(ROOT)),
        "Rwp": h.get_wR(),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "message": rv.get("msg", ""),
        "profile": {k: h.InstrumentParameters[k][1]
                    for k in ("U", "W", "X")},
        "polarization": h.InstrumentParameters["Polariz."][1],
        "fractions": {n: v[0] for n, v in h.ComputeMassFracs().items()},
        "phases": phases,
    }


rows = []
for mode in MODES:
    path = OUTDIR / f"{mode}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path))
    configure(gpx, mode)
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured), contextlib.redirect_stderr(captured):
        gpx.save()
        gpx.refine()
        replay = G2sc.G2Project(str(path))
        clear_frozen(replay)
        replay.set_Controls("cycles", 45)
        replay.refine()
    row = summary(replay, mode, path)
    diagnostic = captured.getvalue()
    if "Warning" in diagnostic or "Error" in diagnostic or "singular" in diagnostic.lower():
        row["diagnostic_tail"] = diagnostic[-4000:]
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "source900_model_challenges.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
