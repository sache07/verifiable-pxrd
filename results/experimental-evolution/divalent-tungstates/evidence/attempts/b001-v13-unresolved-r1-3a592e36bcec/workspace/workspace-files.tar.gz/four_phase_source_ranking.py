#!/usr/bin/env python3
"""Replace each phase source in the elaborated four-phase basis and replay."""

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT=Path(__file__).resolve().parent
COD=Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
BASE=ROOT/".tmp"/"four_phase_background_elbow"/"background18.gpx"
OUTDIR=ROOT/".tmp"/"four_phase_source_ranking"; OUTDIR.mkdir(parents=True,exist_ok=True)
CHALLENGES=[
 ("PbWO4_1527935",0,"1/52/79/1527935.cif"),("PbWO4_9007617",0,"9/00/76/9007617.cif"),
 ("WO3_1528915",1,"1/52/89/1528915.cif"),("WO3_2106293",1,"2/10/62/2106293.cif"),
 ("WO3_2107312",1,"2/10/73/2107312.cif"),("Pb3O4_9003043",2,"9/00/30/9003043.cif"),
 ("PbO_1533609",3,"1/53/36/1533609.cif"),("PbO_9012700",3,"9/01/27/9012700.cif"),
]

def inactive_size(size):
    size[0]="isotropic"; size[1][:]=[10.,10.,1.]; size[2][:]=[False,False,False]
    size[5][:]=[False]*len(size[5])
def inactive_strain(strain):
    strain[0]="isotropic"; strain[1][:]=[0.,0.,1.]; strain[2][:]=[False,False,False]
    strain[4][:]=[0.]*len(strain[4]); strain[5][:]=[False]*len(strain[5])
def neutralize(p,hname):
    hap=p.data["Histograms"][hname]; inactive_size(hap["Size"]); inactive_strain(hap["Mustrain"])
    hap["Pref.Ori."][0:4]=["MD",1.,False,[0,0,1]]
def summarize(gpx,newp,stage,diag):
    h=gpx.histogram(0); rv=gpx.data["Covariance"]["data"].get("Rvals",{}); hap=newp.data["Histograms"][h.name]
    row={"stage":stage,"Rwp":h.get_wR(),"GOF":rv.get("GOF"),"converged":rv.get("converged"),
         "message":rv.get("msg",""),"scale":hap["Scale"][0],"cell":list(newp.data["General"]["Cell"][1:7]),
         "size_model":hap["Size"][0],"size":list(hap["Size"][1][:2]),
         "fractions":{n:v[0] for n,v in h.ComputeMassFracs().items()}}
    if "Warning" in diag or "Error" in diag or "singular" in diag.lower(): row["diagnostic_tail"]=diag[-5000:]
    return row

rows=[]
for label,target,relcif in CHALLENGES:
    scale_path=OUTDIR/f"{label}_scale.gpx"; gpx=G2sc.G2Project(str(BASE),newgpx=str(scale_path)); h=gpx.histogram(0)
    old=gpx.phase(target); oldscale=old.data["Histograms"][h.name]["Scale"][0]
    old.data["General"]["Cell"][0]=False; neutralize(old,h.name); old.data["Histograms"][h.name]["Scale"][:]=[0.,False]
    newp=gpx.add_phase(str(COD/relcif),phasename=f"alternate_{label}",histograms=[h],fmthint="CIF")
    neutralize(newp,h.name); newp.data["General"]["Cell"][0]=False
    newp.HAPvalue("Scale",max(0.01,oldscale)); newp.set_HAP_refinements({"Scale":True})
    gpx.set_Controls("parmMin",0.,variable=f"{newp.id}:0:Scale"); gpx.set_Controls("parmMax",100.,variable=f"{newp.id}:0:Scale")
    gpx.data["Controls"]["data"]["parmFrozen"]={"FrozenList":[]}; gpx.set_Controls("cycles",55)
    cap=io.StringIO()
    with contextlib.redirect_stdout(cap),contextlib.redirect_stderr(cap):
        gpx.save(); gpx.refine(); replay=G2sc.G2Project(str(scale_path))
        replay.data["Controls"]["data"]["parmFrozen"]={"FrozenList":[]}; replay.set_Controls("cycles",55); replay.refine()
    challenge={"label":label,"target_index":target,"source_cif":str(COD/relcif),
               "scale_project":str(scale_path.relative_to(ROOT)),"stages":[summarize(replay,replay.phase(4),"scale_only",cap.getvalue())]}
    first=challenge["stages"][0]
    if first["scale"]>1e-10 and "frozen" not in first["message"].lower():
        path=OUTDIR/f"{label}_elaborated.gpx"; model=G2sc.G2Project(str(scale_path),newgpx=str(path)); h=model.histogram(0); p=model.phase(4)
        p.data["General"]["Cell"][0]=True; size=p.data["Histograms"][h.name]["Size"]
        if target==0:
            size[1][0],size[2][0]=0.064,True; model.set_Controls("parmMin",0.001,variable="4:0:Size;i"); model.set_Controls("parmMax",10.,variable="4:0:Size;i")
        elif target==2:
            size[0]="uniaxial"; size[1][0:3]=[0.036,0.022,1.]; size[2][0:3]=[True,True,False]; size[3]=[0,1,-1]
            for s in ("i","a"): model.set_Controls("parmMin",0.001,variable=f"4:0:Size;{s}"); model.set_Controls("parmMax",10.,variable=f"4:0:Size;{s}")
        elif target==3:
            size[1][0],size[2][0]=0.05,True; model.set_Controls("parmMin",0.001,variable="4:0:Size;i"); model.set_Controls("parmMax",10.,variable="4:0:Size;i")
        model.data["Controls"]["data"]["parmFrozen"]={"FrozenList":[]}; model.set_Controls("cycles",55); cap2=io.StringIO()
        with contextlib.redirect_stdout(cap2),contextlib.redirect_stderr(cap2):
            model.save(); model.refine(); replay2=G2sc.G2Project(str(path))
            replay2.data["Controls"]["data"]["parmFrozen"]={"FrozenList":[]}; replay2.set_Controls("cycles",55); replay2.refine()
        challenge["elaborated_project"]=str(path.relative_to(ROOT)); challenge["stages"].append(summarize(replay2,replay2.phase(4),"cell_width",cap2.getvalue()))
    rows.append(challenge); print(json.dumps(challenge,sort_keys=True),flush=True)
with open(ROOT/"four_phase_source_ranking.json","w") as stream: json.dump(rows,stream,indent=2,sort_keys=True)
