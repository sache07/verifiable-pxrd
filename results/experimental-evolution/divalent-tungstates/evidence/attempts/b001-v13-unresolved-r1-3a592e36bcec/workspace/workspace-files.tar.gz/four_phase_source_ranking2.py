#!/usr/bin/env python3
"""Scale-first, staged source replacement on a fixed four-phase checkpoint."""

import contextlib, io, json
from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT=Path(__file__).resolve().parent
COD=Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
BASE=ROOT/".tmp"/"four_phase_background_elbow"/"background18.gpx"
OUTDIR=ROOT/".tmp"/"four_phase_source_ranking2"; OUTDIR.mkdir(parents=True,exist_ok=True)
CHALLENGES=[
 ("PbWO4_1527935",0,"1/52/79/1527935.cif"),("PbWO4_9007617",0,"9/00/76/9007617.cif"),
 ("WO3_1528915",1,"1/52/89/1528915.cif"),("WO3_2106293",1,"2/10/62/2106293.cif"),
 ("WO3_2107312",1,"2/10/73/2107312.cif"),("Pb3O4_9003043",2,"9/00/30/9003043.cif"),
 ("PbO_1533609",3,"1/53/36/1533609.cif"),("PbO_9012700",3,"9/01/27/9012700.cif")]

def inactive_strain(x):
 x[0]="isotropic"; x[1][:]=[0.,0.,1.]; x[2][:]=[False,False,False]; x[4][:]=[0.]*len(x[4]); x[5][:]=[False]*len(x[5])
def neutralize(p,hname):
 hap=p.data["Histograms"][hname]; inactive_strain(hap["Mustrain"]); hap["Pref.Ori."][0:4]=["MD",1.,False,[0,0,1]]
def fixed_width(p,hname,target):
 s=p.data["Histograms"][hname]["Size"]; s[5][:]=[False]*len(s[5])
 if target==0: s[0]="isotropic"; s[1][:]=[0.064,10.,1.]; s[2][:]=[False,False,False]
 elif target==1: s[0]="isotropic"; s[1][:]=[10.,10.,1.]; s[2][:]=[False,False,False]
 elif target==2: s[0]="uniaxial"; s[1][:]=[0.036,0.022,1.]; s[2][:]=[False,False,False]; s[3]=[0,1,-1]
 else: s[0]="isotropic"; s[1][:]=[0.05,10.,1.]; s[2][:]=[False,False,False]
def setup(gpx,target,relcif,scale,freeze_all):
 h=gpx.histogram(0); old=gpx.phase(target); old.data["General"]["Cell"][0]=False; neutralize(old,h.name)
 old.data["Histograms"][h.name]["Scale"][:]=[0.,False]
 old.data["Histograms"][h.name]["Size"][2][:]=[False,False,False]
 p=gpx.add_phase(str(COD/relcif),phasename=f"alternate_{Path(relcif).stem}",histograms=[h],fmthint="CIF")
 neutralize(p,h.name); fixed_width(p,h.name,target); p.data["General"]["Cell"][0]=False
 p.HAPvalue("Scale",scale); p.set_HAP_refinements({"Scale":True})
 gpx.set_Controls("parmMin",0.,variable=f"{p.id}:0:Scale"); gpx.set_Controls("parmMax",100.,variable=f"{p.id}:0:Scale")
 if freeze_all:
  h.Background[0][1]=False
  for val in h.InstrumentParameters.values():
   if isinstance(val,list) and len(val)>2 and isinstance(val[2],bool): val[2]=False
  for q in gpx.phases():
   q.data["General"]["Cell"][0]=False; hap=q.data["Histograms"][h.name]
   hap["Scale"][1]=q.id==p.id; hap["Size"][2][:]=[False,False,False]; hap["Mustrain"][2][:]=[False,False,False]; hap["Pref.Ori."][2]=False
 return p
def summary(gpx,p,stage,diag):
 h=gpx.histogram(0); rv=gpx.data["Covariance"]["data"].get("Rvals",{}); hap=p.data["Histograms"][h.name]
 row={"stage":stage,"Rwp":h.get_wR(),"GOF":rv.get("GOF"),"converged":rv.get("converged"),"message":rv.get("msg",""),
      "scale":hap["Scale"][0],"cell":list(p.data["General"]["Cell"][1:7]),"size_model":hap["Size"][0],"size":list(hap["Size"][1][:2]),
      "fractions":{n:v[0] for n,v in h.ComputeMassFracs().items()}}
 if "Warning" in diag or "Error" in diag or "singular" in diag.lower(): row["diagnostic_tail"]=diag[-4000:]
 return row

template=G2sc.G2Project(str(BASE)); base_scales=[p.data["Histograms"][template.histogram(0).name]["Scale"][0] for p in template.phases()]
rows=[]
for label,target,relcif in CHALLENGES:
 sp=OUTDIR/f"{label}_scale.gpx"; g=G2sc.G2Project(str(BASE),newgpx=str(sp)); p=setup(g,target,relcif,max(.01,base_scales[target]),True)
 g.data["Controls"]["data"]["parmFrozen"]={"FrozenList":[]}; g.set_Controls("cycles",30); cap=io.StringIO()
 with contextlib.redirect_stdout(cap),contextlib.redirect_stderr(cap): g.save(); g.refine(); r=G2sc.G2Project(str(sp)); r.data["Controls"]["data"]["parmFrozen"]={"FrozenList":[]}; r.refine()
 first=summary(r,r.phase(4),"scale_only",cap.getvalue()); item={"label":label,"source_cif":str(COD/relcif),"stages":[first]}
 if first["scale"]>1e-10 and "frozen" not in first["message"].lower():
  ep=OUTDIR/f"{label}_elaborated.gpx"; m=G2sc.G2Project(str(BASE),newgpx=str(ep)); q=setup(m,target,relcif,first["scale"],False); h=m.histogram(0); q.data["General"]["Cell"][0]=True
  s=q.data["Histograms"][h.name]["Size"]
  if target==0:
   s[2][0]=True; m.set_Controls("parmMin",.001,variable="4:0:Size;i"); m.set_Controls("parmMax",10.,variable="4:0:Size;i")
  elif target in (2,3):
   s[0]="isotropic"; s[2][:]=[True,False,False]; m.set_Controls("parmMin",.001,variable="4:0:Size;i"); m.set_Controls("parmMax",10.,variable="4:0:Size;i")
  m.data["Controls"]["data"]["parmFrozen"]={"FrozenList":[]}; m.set_Controls("cycles",55); cap2=io.StringIO()
  with contextlib.redirect_stdout(cap2),contextlib.redirect_stderr(cap2): m.save(); m.refine(); r2=G2sc.G2Project(str(ep)); r2.data["Controls"]["data"]["parmFrozen"]={"FrozenList":[]}; r2.refine()
  item["stages"].append(summary(r2,r2.phase(4),"cell_width",cap2.getvalue()))
 rows.append(item); print(json.dumps(item,sort_keys=True),flush=True)
with open(ROOT/"four_phase_source_ranking2.json","w") as f: json.dump(rows,f,indent=2,sort_keys=True)
