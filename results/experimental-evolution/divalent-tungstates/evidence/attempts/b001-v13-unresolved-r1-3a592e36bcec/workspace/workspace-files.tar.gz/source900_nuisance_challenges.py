#!/usr/bin/env python3
"""Background, polarization, roughness and asymmetry tests on source 9009811."""

import contextlib
import io
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "source900_polarization" / "seed0.8.gpx"
OUTDIR = ROOT / ".tmp" / "source900_nuisance_challenges"
OUTDIR.mkdir(parents=True, exist_ok=True)

BRANCHES = [
    ("replay", 8, 0.8, None, None),
    ("background4", 4, 0.8, None, None),
    ("background6", 6, 0.8, None, None),
    ("background10", 10, 0.8, None, None),
    ("background12", 12, 0.8, None, None),
    ("background14", 14, 0.8, None, None),
    ("polarization02", 8, 0.2, None, None),
    ("polarization05", 8, 0.5, None, None),
    ("no_polarization", 8, None, None, None),
    ("rough_only_low", 8, None, (0.03, 0.03), None),
    ("rough_only_high", 8, None, (0.30, 0.20), None),
    ("pol_rough_low", 8, 0.5, (0.03, 0.03), None),
    ("pol_rough_high", 8, 0.8, (0.30, 0.20), None),
    ("shl_seed002", 8, 0.8, None, 0.002),
    ("shl_seed01", 8, 0.8, None, 0.010),
]


def roughness_curve(a, b):
    tth = np.asarray([15.0, 30.0, 50.0, 70.0, 90.0])
    sth = np.sin(np.radians(tth / 2.0))
    t1 = np.exp(-b / sth)
    t2 = a + (1.0 - a) * np.exp(-b)
    return [float(v) for v in ((a + (1.0 - a) * t1) / t2)]


def configure(gpx, background_count, polarization_seed, roughness_seed, shl_seed):
    h = gpx.histogram(0)
    coeffs = list(h.Background[0][3:])
    h.set_refinements({"Background": {
        "type": "chebyschev-1",
        "refine": True,
        "no. coeffs": background_count,
        "coeffs": (coeffs + [0.0] * background_count)[:background_count],
    }})

    h.InstrumentParameters["Polariz."][1] = 0.5 if polarization_seed is None else polarization_seed
    h.InstrumentParameters["Polariz."][2] = polarization_seed is not None
    if polarization_seed is not None:
        gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")

    h.SampleParameters["SurfRoughA"][:] = [0.0, False]
    h.SampleParameters["SurfRoughB"][:] = [0.0, False]
    if roughness_seed is not None:
        h.SampleParameters["SurfRoughA"][:] = [roughness_seed[0], True]
        h.SampleParameters["SurfRoughB"][:] = [roughness_seed[1], True]
        for name in ("SurfRoughA", "SurfRoughB"):
            gpx.set_Controls("parmMin", 0.0, variable=f":0:{name}")
            gpx.set_Controls("parmMax", 1.0, variable=f":0:{name}")

    h.InstrumentParameters["SH/L"][1] = 0.0005 if shl_seed is None else shl_seed
    h.InstrumentParameters["SH/L"][2] = shl_seed is not None
    if shl_seed is not None:
        gpx.set_Controls("parmMin", 0.0005, variable=":0:SH/L")
        gpx.set_Controls("parmMax", 0.2, variable=":0:SH/L")

    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 50)


rows = []
for name, nback, polseed, roughseed, shlseed in BRANCHES:
    path = OUTDIR / f"{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path))
    configure(gpx, nback, polseed, roughseed, shlseed)
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured), contextlib.redirect_stderr(captured):
        gpx.save()
        gpx.refine()
        replay = G2sc.G2Project(str(path))
        replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        replay.set_Controls("cycles", 50)
        replay.refine()
    h = replay.histogram(0)
    rv = replay.data["Covariance"]["data"].get("Rvals", {})
    a = h.SampleParameters["SurfRoughA"][0]
    b = h.SampleParameters["SurfRoughB"][0]
    y = h.data["data"][1]
    x = np.asarray(y[0])
    obs = np.asarray(y[1])
    calc = np.asarray(y[3])
    resid = obs - calc
    segment_rms = {}
    for lo, hi in ((10, 30), (30, 60), (60, 80), (80, 100)):
        use = (x >= lo) & (x < hi)
        segment_rms[f"{lo}_{hi}"] = float(np.sqrt(np.mean(resid[use] ** 2)))
    row = {
        "name": name,
        "project": str(path.relative_to(ROOT)),
        "Rwp": h.get_wR(),
        "GOF": rv.get("GOF"),
        "chisq": rv.get("chisq"),
        "Nobs": rv.get("Nobs"),
        "Nvars": rv.get("Nvars"),
        "converged": rv.get("converged"),
        "message": rv.get("msg", ""),
        "background_coefficients": len(h.Background[0]) - 3,
        "background_values": list(h.Background[0][3:]),
        "polarization": h.InstrumentParameters["Polariz."][1],
        "roughness_A": a,
        "roughness_B": b,
        "roughness_curve_15_30_50_70_90deg": roughness_curve(a, b),
        "SH_L": h.InstrumentParameters["SH/L"][1],
        "segment_unweighted_residual_rms": segment_rms,
        "fractions": {n: v[0] for n, v in h.ComputeMassFracs().items()},
    }
    diagnostic = captured.getvalue()
    if "Warning" in diagnostic or "Error" in diagnostic or "singular" in diagnostic.lower():
        row["diagnostic_tail"] = diagnostic[-4000:]
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "source900_nuisance_challenges.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
