#!/usr/bin/env python3
"""Independent reseeds and replay for the leading PbWO4 uniaxial-size axis."""

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "final_term_deletions" / "delete_U.gpx"
OUTDIR = ROOT / ".tmp" / "anisotropy_replay"
OUTDIR.mkdir(parents=True, exist_ok=True)

SEEDS = ((0.03, 0.03), (0.05, 0.10), (0.10, 0.05), (0.20, 0.02))


rows = []
for equatorial, axial in SEEDS:
    tag = f"eq{equatorial:.2f}_ax{axial:.2f}"
    path = OUTDIR / f"{tag}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path))
    h = gpx.histogram(0)
    p = gpx.phase(0)
    size = p.data["Histograms"][h.name]["Size"]
    size[0] = "uniaxial"
    size[1][0:3] = [equatorial, axial, 1.0]
    size[2][0:3] = [True, True, False]
    size[3] = [1, -2, -2]
    for suffix in ("i", "a"):
        gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;{suffix}")
        gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;{suffix}")
    for key in ("W", "X"):
        h.InstrumentParameters[key][2] = True
        gpx.set_Controls("parmMin", 0.0, variable=f":0:{key}")
        gpx.set_Controls("parmMax", 200.0, variable=f":0:{key}")
    h.InstrumentParameters["U"][:] = [0.0, 0.0, False]
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 40)
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        gpx.save()
        gpx.refine()
        replay = G2sc.G2Project(str(path))
        replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        replay.refine()
    h = replay.histogram(0)
    size = replay.phase(0).data["Histograms"][h.name]["Size"]
    rv = replay.data["Covariance"]["data"].get("Rvals", {})
    row = {
        "seed": [equatorial, axial],
        "project": str(path.relative_to(ROOT)),
        "Rwp": h.get_wR(),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "message": rv.get("msg", ""),
        "equatorial_size_um": size[1][0],
        "axial_size_um": size[1][1],
        "profile": {k: h.InstrumentParameters[k][1] for k in ("U", "W", "X")},
        "fractions": {n: v[0] for n, v in h.ComputeMassFracs().items()},
    }
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "anisotropy_replay.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
