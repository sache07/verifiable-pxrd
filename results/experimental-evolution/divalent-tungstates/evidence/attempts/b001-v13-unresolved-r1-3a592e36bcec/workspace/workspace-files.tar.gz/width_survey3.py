#!/usr/bin/env python3
import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "three_phase_survey" / "pb3o4_9012124.gpx"
OUTDIR = ROOT / ".tmp" / "width_survey3"
OUTDIR.mkdir(parents=True, exist_ok=True)


def reset(gpx):
    h = gpx.histogram(0)
    for key, value in (("U", 0.0), ("V", 0.0), ("W", 0.0),
                       ("X", 8.0), ("Y", 0.0), ("Z", 0.0)):
        h.InstrumentParameters[key][1] = value
        h.InstrumentParameters[key][2] = key == "X"
    h.InstrumentParameters["Zero"][2] = True
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("parmMin", 0.0, variable=":0:X")
    gpx.set_Controls("parmMax", 200.0, variable=":0:X")
    gpx.set_Controls("cycles", 20)


def set_model(gpx, phase_index, model):
    h = gpx.histogram(0)
    p = gpx.phase(phase_index)
    hap = p.data["Histograms"][h.name]
    if model in ("size", "combined"):
        hap["Size"][1][0] = 0.10
        hap["Size"][2][0] = True
        gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;i")
    if model in ("strain", "combined"):
        hap["Mustrain"][1][0] = 750.0
        hap["Mustrain"][2][0] = True
        gpx.set_Controls("parmMin", 0.0, variable=f"{p.id}:0:Mustrain;i")
        gpx.set_Controls("parmMax", 10000.0, variable=f"{p.id}:0:Mustrain;i")


def branch(phase_index, model):
    name = f"p{phase_index}_{model}"
    project_path = OUTDIR / f"{name}.gpx"
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(project_path))
    reset(gpx)
    set_model(gpx, phase_index, model)
    h = gpx.histogram(0)
    if model != "neutral":
        h.InstrumentParameters["X"][2] = False
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        gpx.save()
        gpx.refine()
        if model != "neutral":
            h = gpx.histogram(0)
            h.InstrumentParameters["X"][2] = True
            gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
            gpx.refine()
        replay = G2sc.G2Project(str(project_path))
        replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        replay.refine()
    h = replay.histogram(0)
    rvals = replay.data["Covariance"]["data"].get("Rvals", {})
    return {
        "phase_index": phase_index,
        "phase": replay.phase(phase_index).name,
        "model": model,
        "project": str(project_path.relative_to(ROOT)),
        "Rwp": h.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "message": rvals.get("msg", ""),
        "zero": h.InstrumentParameters["Zero"][1],
        "X": h.InstrumentParameters["X"][1],
        "fractions": {name: pair[0] for name, pair in h.ComputeMassFracs().items()},
        "widths": {
            p.name: {
                "size_um": p.data["Histograms"][h.name]["Size"][1][0],
                "size_refine": p.data["Histograms"][h.name]["Size"][2][0],
                "mustrain": p.data["Histograms"][h.name]["Mustrain"][1][0],
                "mustrain_refine": p.data["Histograms"][h.name]["Mustrain"][2][0],
            } for p in replay.phases()
        },
    }


rows = []
for phase_index in range(3):
    for model in ("neutral", "size", "strain", "combined"):
        row = branch(phase_index, model)
        rows.append(row)
        print(json.dumps(row, sort_keys=True), flush=True)
with open(ROOT / "width_survey3.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
