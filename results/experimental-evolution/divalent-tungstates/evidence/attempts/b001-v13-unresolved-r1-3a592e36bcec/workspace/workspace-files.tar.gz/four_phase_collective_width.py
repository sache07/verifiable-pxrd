#!/usr/bin/env python3
"""Low-seed collective size/strain/profile challenges for the four-phase basis."""

import contextlib
import io
import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "four_phase_elaborated" / "sizes_replay.gpx"
OUTDIR = ROOT / ".tmp" / "four_phase_collective_width"
OUTDIR.mkdir(parents=True, exist_ok=True)

MODES = (
    "replay", "reseed_sizes_low", "release_U_seed01", "release_U_seed2",
    "p1_size_low", "p0_strain_low", "p1_strain_low", "p2_strain_low",
    "p3_strain_low", "supported_strains_low", "supported_widths_low",
    "all_widths_low",
)


def clear(gpx):
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def inactive_size(size):
    size[0] = "isotropic"
    size[1][:] = [10.0, 10.0, 1.0]
    size[2][:] = [False, False, False]
    size[5][:] = [False] * len(size[5])


def inactive_strain(strain):
    strain[0] = "isotropic"
    strain[1][:] = [0.0, 0.0, 1.0]
    strain[2][:] = [False, False, False]
    strain[4][:] = [0.0] * len(strain[4])
    strain[5][:] = [False] * len(strain[5])


def set_iso_size(gpx, index, seed):
    h = gpx.histogram(0); p = gpx.phase(index)
    size = p.data["Histograms"][h.name]["Size"]
    inactive_size(size); size[1][0], size[2][0] = seed, True
    gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;i")
    gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;i")


def set_uniaxial_size(gpx, index, axis, seed):
    h = gpx.histogram(0); p = gpx.phase(index)
    size = p.data["Histograms"][h.name]["Size"]
    inactive_size(size); size[0] = "uniaxial"
    size[1][0:3] = [seed, seed, 1.0]
    size[2][0:3] = [True, True, False]; size[3] = list(axis)
    for suffix in ("i", "a"):
        gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;{suffix}")
        gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;{suffix}")


def set_strain(gpx, index, seed=100.0):
    h = gpx.histogram(0); p = gpx.phase(index)
    strain = p.data["Histograms"][h.name]["Mustrain"]
    inactive_strain(strain); strain[1][0], strain[2][0] = seed, True
    gpx.set_Controls("parmMin", 0.0, variable=f"{p.id}:0:Mustrain;i")
    gpx.set_Controls("parmMax", 10000.0, variable=f"{p.id}:0:Mustrain;i")


def set_u(gpx, seed):
    h = gpx.histogram(0)
    h.InstrumentParameters["U"][1:3] = [seed, True]
    for key in ("U", "W", "X"):
        h.InstrumentParameters[key][2] = True
        gpx.set_Controls("parmMin", 0.0, variable=f":0:{key}")
        gpx.set_Controls("parmMax", 200.0, variable=f":0:{key}")


def low_supported_sizes(gpx):
    set_iso_size(gpx, 0, 0.030)
    set_uniaxial_size(gpx, 2, (0, 1, -1), 0.030)
    set_uniaxial_size(gpx, 3, (0, 2, -1), 0.030)


def configure(gpx, mode):
    h = gpx.histogram(0)
    for p in gpx.phases():
        inactive_strain(p.data["Histograms"][h.name]["Mustrain"])
    if mode == "reseed_sizes_low":
        low_supported_sizes(gpx)
    elif mode == "release_U_seed01":
        set_u(gpx, 0.1)
    elif mode == "release_U_seed2":
        set_u(gpx, 2.0)
    elif mode == "p1_size_low":
        set_iso_size(gpx, 1, 0.10)
    elif mode.startswith("p") and mode.endswith("_strain_low"):
        set_strain(gpx, int(mode[1]))
    elif mode == "supported_strains_low":
        for index in (0, 2, 3): set_strain(gpx, index)
    elif mode == "supported_widths_low":
        low_supported_sizes(gpx); set_u(gpx, 0.1)
        for index in (0, 2, 3): set_strain(gpx, index)
    elif mode == "all_widths_low":
        low_supported_sizes(gpx); set_iso_size(gpx, 1, 0.10); set_u(gpx, 0.1)
        for index in range(4): set_strain(gpx, index)
    clear(gpx); gpx.set_Controls("cycles", 55)


def summarize(gpx, mode, path, diagnostic):
    h = gpx.histogram(0); rv = gpx.data["Covariance"]["data"].get("Rvals", {})
    row = {
        "mode": mode, "project": str(path.relative_to(ROOT)),
        "Rwp": h.get_wR(), "GOF": rv.get("GOF"),
        "converged": rv.get("converged"), "message": rv.get("msg", ""),
        "profile": {k: h.InstrumentParameters[k][1] for k in ("U", "W", "X")},
        "polarization": h.InstrumentParameters["Polariz."][1],
        "fractions": {n: v[0] for n, v in h.ComputeMassFracs().items()},
        "widths": {},
    }
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        row["widths"][p.name] = {
            "size_model": hap["Size"][0], "size": list(hap["Size"][1][:2]),
            "size_flags": list(hap["Size"][2][:2]),
            "strain": hap["Mustrain"][1][0],
            "strain_refine": hap["Mustrain"][2][0],
        }
    if "Warning" in diagnostic or "Error" in diagnostic or "singular" in diagnostic.lower():
        row["diagnostic_tail"] = diagnostic[-5000:]
    return row


rows = []
selected = set(sys.argv[1:])
for mode in MODES:
    if selected and mode not in selected:
        continue
    path = OUTDIR / f"{mode}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path)); configure(gpx, mode)
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured), contextlib.redirect_stderr(captured):
        gpx.save(); gpx.refine()
        replay = G2sc.G2Project(str(path)); clear(replay)
        replay.set_Controls("cycles", 55); replay.refine()
    row = summarize(replay, mode, path, captured.getvalue()); rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)
    with open(ROOT / "four_phase_collective_width.json", "w") as stream:
        json.dump(rows, stream, indent=2, sort_keys=True)

with open(ROOT / "four_phase_collective_width.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
