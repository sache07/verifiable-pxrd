#!/usr/bin/env python3
"""Delete supported phase widths and challenge the common U/W/X basis."""

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "collective_width3" / "sizes_seed05.gpx"
OUTDIR = ROOT / ".tmp" / "coupled_deletion_profile"
OUTDIR.mkdir(parents=True, exist_ok=True)


def clear_frozen(gpx):
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 30)


def configure(gpx, mode):
    h = gpx.histogram(0)
    # Reload every saved value and flag explicitly for each comparison.
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    for key in ("U", "V", "W", "X", "Y", "Z"):
        h.InstrumentParameters[key][2] = key == "X"
    h.InstrumentParameters["U"][1] = 0.0
    h.InstrumentParameters["V"][1] = 0.0
    h.InstrumentParameters["W"][1] = 0.0
    h.InstrumentParameters["Y"][1] = 0.0
    h.InstrumentParameters["Z"][1] = 0.0
    h.InstrumentParameters["Zero"][2] = True

    if mode == "delete_pbwo4_size":
        hap = gpx.phase(0).data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
    elif mode == "delete_pb3o4_size":
        hap = gpx.phase(2).data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
    elif mode.startswith("full_profile"):
        seed = float(mode.rsplit("_", 1)[1])
        h.InstrumentParameters["U"][:] = [seed, seed, True]
        h.InstrumentParameters["W"][:] = [seed, seed, True]
        h.InstrumentParameters["X"][2] = True
        for variable in (":0:U", ":0:W", ":0:X"):
            gpx.set_Controls("parmMin", 0.0, variable=variable)
            gpx.set_Controls("parmMax", 200.0, variable=variable)
    clear_frozen(gpx)


def summarize(gpx, name, path):
    h = gpx.histogram(0)
    rv = gpx.data["Covariance"]["data"].get("Rvals", {})
    return {
        "name": name,
        "project": str(path.relative_to(ROOT)),
        "Rwp": h.get_wR(),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "message": rv.get("msg", ""),
        "profile": {key: h.InstrumentParameters[key][1]
                    for key in ("U", "W", "X")},
        "profile_flags": {key: h.InstrumentParameters[key][2]
                          for key in ("U", "W", "X")},
        "fractions": {n: v[0] for n, v in h.ComputeMassFracs().items()},
        "sizes_um": {
            p.name: p.data["Histograms"][h.name]["Size"][1][0]
            for p in gpx.phases()
        },
        "size_flags": {
            p.name: p.data["Histograms"][h.name]["Size"][2][0]
            for p in gpx.phases()
        },
    }


rows = []
for mode in ("baseline", "delete_pbwo4_size", "delete_pb3o4_size",
             "full_profile_0.1", "full_profile_2.0"):
    path = OUTDIR / f"{mode}.gpx"
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(path))
    configure(gpx, mode)
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        gpx.save()
        gpx.refine()
        replay = G2sc.G2Project(str(path))
        clear_frozen(replay)
        replay.refine()
    row = summarize(replay, mode, path)
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "coupled_deletion_profile.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
