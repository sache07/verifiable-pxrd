#!/usr/bin/env python3
"""Cross-seed complete PbWO4 texture axes for the two serious scheelite records."""

import contextlib
import io
import itertools
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCES = {
    "9009811": ROOT / ".tmp" / "source_challenge3" / "baseline_neutral.gpx",
    "1527935": ROOT / ".tmp" / "source_challenge3" / "pbwo4_1527935_neutral.gpx",
}
OUTDIR = ROOT / ".tmp" / "pbwo4_source_axis_cross"
OUTDIR.mkdir(parents=True, exist_ok=True)


def canonical(vector):
    vector = tuple(int(round(v)) for v in vector)
    divisor = math.gcd(*[abs(v) for v in vector if v])
    vector = tuple(v // divisor for v in vector)
    for value in vector:
        if value:
            return tuple(-v for v in vector) if value < 0 else vector
    raise ValueError("zero")


def axes(phase, maximum=2):
    rotations = []
    for matrix, _translation in phase.data["General"]["SGData"]["SGOps"]:
        reciprocal = np.rint(np.linalg.inv(np.asarray(matrix)).T).astype(int)
        if not any(np.array_equal(reciprocal, old) for old in rotations):
            rotations.append(reciprocal)
    candidates = {
        canonical(v) for v in itertools.product(range(-maximum, maximum + 1), repeat=3)
        if v != (0, 0, 0) and math.gcd(*[abs(x) for x in v if x]) == 1
    }
    seen, result = set(), []
    ordering = lambda v: (max(map(abs, v)), sum(abs(x) for x in v), v)
    for vector in sorted(candidates, key=ordering):
        if vector in seen:
            continue
        seen.update(canonical(rotation @ np.asarray(vector)) for rotation in rotations)
        result.append(vector)
    return result


rows = []
for source_id, base in SOURCES.items():
    template = G2sc.G2Project(str(base))
    source_axes = axes(template.phase(0))
    print(json.dumps({source_id: source_axes}), flush=True)
    for axis in source_axes:
        for seed in (0.70, 1.40):
            tag = "_".join(str(v).replace("-", "m") for v in axis)
            path = OUTDIR / f"s{source_id}_{tag}_seed{seed:.2f}.gpx"
            gpx = G2sc.G2Project(str(base), newgpx=str(path))
            h = gpx.histogram(0)
            phase = gpx.phase(0)
            po = phase.data["Histograms"][h.name]["Pref.Ori."]
            po[0:4] = ["MD", seed, True, list(axis)]
            gpx.set_Controls("parmMin", 0.2, variable="0:0:MD")
            gpx.set_Controls("parmMax", 5.0, variable="0:0:MD")
            gpx.set_Controls("cycles", 20)
            gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                gpx.save()
                gpx.refine()
            h = gpx.histogram(0)
            po = gpx.phase(0).data["Histograms"][h.name]["Pref.Ori."]
            rv = gpx.data["Covariance"]["data"].get("Rvals", {})
            row = {
                "source": source_id,
                "axis": list(axis),
                "seed": seed,
                "march_ratio": po[1],
                "Rwp": h.get_wR(),
                "GOF": rv.get("GOF"),
                "converged": rv.get("converged"),
                "message": rv.get("msg", ""),
                "fractions": {name: pair[0] for name, pair in h.ComputeMassFracs().items()},
                "project": str(path.relative_to(ROOT)),
            }
            rows.append(row)
            print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "pbwo4_source_axis_cross.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
