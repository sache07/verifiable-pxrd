#!/usr/bin/env python3
"""Cross-seed the two tied PbWO4 anisotropic-size directions with polarization."""

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "nuisance_collective" / "pol_seed05.gpx"
OUTDIR = ROOT / ".tmp" / "final_aniso_axis_cross"
OUTDIR.mkdir(parents=True, exist_ok=True)

AXES = ((0, 1, -2), (1, -2, -2))
SEEDS = ((0.03, 0.03), (0.05, 0.10), (0.10, 0.05))

rows = []
for axis in AXES:
    for eq_seed, ax_seed in SEEDS:
        axis_tag = "_".join(str(v).replace("-", "m") for v in axis)
        path = OUTDIR / f"axis{axis_tag}_eq{eq_seed:.2f}_ax{ax_seed:.2f}.gpx"
        gpx = G2sc.G2Project(str(BASE), newgpx=str(path))
        h = gpx.histogram(0)
        p = gpx.phase(0)
        size = p.data["Histograms"][h.name]["Size"]
        size[0] = "uniaxial"
        size[1][0:3] = [eq_seed, ax_seed, 1.0]
        size[2][0:3] = [True, True, False]
        size[3] = list(axis)
        for suffix in ("i", "a"):
            gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;{suffix}")
            gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;{suffix}")
        gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        gpx.set_Controls("cycles", 45)
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            gpx.save()
            gpx.refine()
            replay = G2sc.G2Project(str(path))
            replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
            replay.refine()
        h = replay.histogram(0)
        size = replay.phase(0).data["Histograms"][h.name]["Size"]
        rv = replay.data["Covariance"]["data"].get("Rvals", {})
        row = {
            "axis": list(axis), "seed": [eq_seed, ax_seed],
            "project": str(path.relative_to(ROOT)),
            "Rwp": h.get_wR(), "GOF": rv.get("GOF"),
            "converged": rv.get("converged"), "message": rv.get("msg", ""),
            "equatorial_size_um": size[1][0], "axial_size_um": size[1][1],
            "polarization": h.InstrumentParameters["Polariz."][1],
            "fractions": {n: v[0] for n, v in h.ComputeMassFracs().items()},
        }
        rows.append(row)
        print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "final_aniso_axis_cross.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
