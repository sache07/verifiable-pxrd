#!/usr/bin/env python3
"""Delete each surviving term from the interior coupled checkpoint."""

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "full_profile_collective2" / "baseline.gpx"
OUTDIR = ROOT / ".tmp" / "final_term_deletions"
OUTDIR.mkdir(parents=True, exist_ok=True)

MODES = ("replay", "delete_U", "delete_W", "delete_X",
         "delete_pbwo4_size", "delete_pb3o4_size", "delete_texture")


def configure(gpx, mode):
    h = gpx.histogram(0)
    for key in ("U", "W", "X"):
        h.InstrumentParameters[key][2] = True
        gpx.set_Controls("parmMin", 0.0, variable=f":0:{key}")
        gpx.set_Controls("parmMax", 200.0, variable=f":0:{key}")
    for key in ("V", "Y", "Z"):
        h.InstrumentParameters[key][1] = 0.0
        h.InstrumentParameters[key][2] = False
    if mode.startswith("delete_") and mode[-1] in "UWX":
        key = mode[-1]
        h.InstrumentParameters[key][1] = 0.0
        h.InstrumentParameters[key][2] = False
    elif mode == "delete_pbwo4_size":
        size = gpx.phase(0).data["Histograms"][h.name]["Size"]
        size[0] = "isotropic"
        size[1][:] = [10.0, 10.0, 1.0]
        size[2][:] = [False, False, False]
    elif mode == "delete_pb3o4_size":
        size = gpx.phase(2).data["Histograms"][h.name]["Size"]
        size[0] = "isotropic"
        size[1][:] = [10.0, 10.0, 1.0]
        size[2][:] = [False, False, False]
    elif mode == "delete_texture":
        gpx.phase(0).data["Histograms"][h.name]["Pref.Ori."][0:4] = [
            "MD", 1.0, False, [0, 1, -2]]
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 35)


rows = []
for mode in MODES:
    path = OUTDIR / f"{mode}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path))
    configure(gpx, mode)
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        gpx.save()
        gpx.refine()
        replay = G2sc.G2Project(str(path))
        replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        replay.refine()
    h = replay.histogram(0)
    rv = replay.data["Covariance"]["data"].get("Rvals", {})
    row = {
        "mode": mode,
        "project": str(path.relative_to(ROOT)),
        "Rwp": h.get_wR(),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "message": rv.get("msg", ""),
        "profile": {k: h.InstrumentParameters[k][1] for k in ("U", "W", "X")},
        "fractions": {n: v[0] for n, v in h.ComputeMassFracs().items()},
        "sizes_um": {p.name: p.data["Histograms"][h.name]["Size"][1][0]
                     for p in replay.phases()},
        "march_ratio": replay.phase(0).data["Histograms"][h.name]["Pref.Ori."][1],
    }
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "final_term_deletions.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
