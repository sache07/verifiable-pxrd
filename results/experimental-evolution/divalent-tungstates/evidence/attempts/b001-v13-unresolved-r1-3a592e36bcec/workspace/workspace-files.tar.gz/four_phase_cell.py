#!/usr/bin/env python3
"""Refine and replay the massicot PbO cell after its scale has converged."""

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "pbo_weak_phase_tests" / "massicot_replay.gpx"
OUT = ROOT / ".tmp" / "four_phase_cell" / "cell_replay.gpx"
OUT.parent.mkdir(parents=True, exist_ok=True)

gpx = G2sc.G2Project(str(BASE), newgpx=str(OUT))
gpx.phase(3).data["General"]["Cell"][0] = True
gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
gpx.set_Controls("cycles", 50)
captured = io.StringIO()
with contextlib.redirect_stdout(captured), contextlib.redirect_stderr(captured):
    gpx.save()
    gpx.refine()
    replay = G2sc.G2Project(str(OUT))
    replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    replay.set_Controls("cycles", 50)
    replay.refine()

h = replay.histogram(0)
rv = replay.data["Covariance"]["data"].get("Rvals", {})
row = {
    "project": str(OUT.relative_to(ROOT)),
    "Rwp": h.get_wR(),
    "GOF": rv.get("GOF"),
    "converged": rv.get("converged"),
    "message": rv.get("msg", ""),
    "cell": list(replay.phase(3).data["General"]["Cell"][1:8]),
    "fractions": {n: v[0] for n, v in h.ComputeMassFracs().items()},
}
diagnostic = captured.getvalue()
if "Warning" in diagnostic or "Error" in diagnostic or "singular" in diagnostic.lower():
    row["diagnostic_tail"] = diagnostic[-4000:]
print(json.dumps(row, sort_keys=True))
with open(ROOT / "four_phase_cell.json", "w") as stream:
    json.dump(row, stream, indent=2, sort_keys=True)
