#!/usr/bin/env python3
from pathlib import Path
from pprint import pformat

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def neutralize_phase(phase, hist_name):
    hap = phase.data["Histograms"][hist_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [100.0, 100.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][4][:] = [100.0, 100.0, 100.0, 0.0, 0.0, 0.0]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"][:] = [0.0, False]
    for term in hap["HStrain"]:
        if isinstance(term, list):
            for i in range(len(term)):
                term[i] = False if isinstance(term[i], bool) else 0.0
    for key in ("BabA", "BabU"):
        hap["Babinet"][key][:] = [0.0, False]


def report(gpx, label):
    h = gpx.histogram(0)
    print(f"\n===== {label} =====")
    print("residuals", h.residuals)
    print("instrument", {k: v for k, v in h.InstrumentParameters.items()
                         if k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")})
    print("background", h.Background[0])
    print("sample", {k: h.SampleParameters[k] for k in
                     ("Scale", "DisplaceX", "DisplaceY", "Shift", "Transparency",
                      "SurfRoughA", "SurfRoughB")})
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        print(p.name, "cell", p.data["General"]["Cell"], "scale", hap["Scale"])
        print("  size", hap["Size"], "strain", hap["Mustrain"], "PO", hap["Pref.Ori."])
    try:
        print("mass fractions", h.ComputeMassFracs())
    except Exception as exc:
        print("mass fractions unavailable", repr(exc))
    cov = gpx.data.get("Covariance", {}).get("data", {})
    print("Rvals", pformat(cov.get("Rvals", {})))
    print("vary", list(zip(cov.get("varyList", []), cov.get("variables", []), cov.get("sig", []))))


gpx = G2sc.G2Project(newgpx=str(ROOT / "explore.gpx"))
h = gpx.add_powder_histogram(
    str(ROOT / "inputs/pattern.csv"), str(ROOT / "instrument.instprm"),
    fmthint="comma/tab/semicolon separated")
p1 = gpx.add_phase(str(COD / "9/00/98/9009811.cif"), phasename="PbWO4_scheelite",
                   histograms=[h], fmthint="CIF")
p2 = gpx.add_phase(str(COD / "2/31/10/2311041.cif"), phasename="WO3_monoclinic",
                   histograms=[h], fmthint="CIF")

gpx.set_Controls("cycles", 12)
h.set_refinements({"Limits": [10.0, 100.0]})
h.SampleParameters["Scale"][:] = [1.0, False]
for key in ("SurfRoughA", "SurfRoughB"):
    h.SampleParameters[key][:] = [0.0, False]
inst = h.InstrumentParameters
for key, value in {"Zero": 0.45, "U": 2.0, "V": 0.0, "W": 5.0,
                   "X": 0.1, "Y": 0.0, "Z": 0.0, "SH/L": 0.0,
                   "Polariz.": 0.5}.items():
    inst[key][1] = value
    inst[key][2] = False
h.set_refinements({"Background": {"type": "chebyschev-1", "refine": True,
                                  "no. coeffs": 8,
                                  "coeffs": [1500.0, -800.0, 300.0, -100.0,
                                             30.0, -10.0, 3.0, -1.0]}})
for p, start in ((p1, 0.001), (p2, 0.0002)):
    neutralize_phase(p, h.name)
    p.HAPvalue("Scale", start)
    p.set_HAP_refinements({"Scale": True})

gpx.save()
gpx.refine()
report(gpx, "background + phase scales")

for p in gpx.phases():
    p.set_refinements({"Cell": True})
h.set_refinements({"Instrument Parameters": ["Zero"]})
gpx.refine()
report(gpx, "cells + zero")

h.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
gpx.refine()
report(gpx, "common U/W/X")
gpx.save()
