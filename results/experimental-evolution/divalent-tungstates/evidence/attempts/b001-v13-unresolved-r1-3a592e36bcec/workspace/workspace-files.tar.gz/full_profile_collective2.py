#!/usr/bin/env python3
"""Joint low-seed width release against the accepted interior U/W/X profile."""

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "alternate_model_challenges" / "full_profile_0.1.gpx"
OUTDIR = ROOT / ".tmp" / "full_profile_collective2"
OUTDIR.mkdir(parents=True, exist_ok=True)

BRANCHES = [
    ("baseline", {0: (0.062, None), 2: (0.035, None)}),
    ("sizes_seed03", {0: (0.030, None), 2: (0.030, None)}),
    ("sizes_seed06", {0: (0.060, None), 2: (0.060, None)}),
    ("all_sizes", {0: (0.050, None), 1: (0.20, None), 2: (0.030, None)}),
    ("sizes_wo3strain", {0: (0.050, None), 1: (None, 1000.0), 2: (0.030, None)}),
    ("sizes_pb_strains", {0: (0.050, 500.0), 2: (0.030, 500.0)}),
    ("all_sizes_strains", {0: (0.050, 500.0), 1: (0.20, 500.0), 2: (0.030, 500.0)}),
]


def neutralize_widths(gpx):
    h = gpx.histogram(0)
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])


def configure(gpx, terms):
    h = gpx.histogram(0)
    neutralize_widths(gpx)
    for key in ("U", "W", "X"):
        h.InstrumentParameters[key][2] = True
        gpx.set_Controls("parmMin", 0.0, variable=f":0:{key}")
        gpx.set_Controls("parmMax", 200.0, variable=f":0:{key}")
    for key in ("V", "Y", "Z"):
        h.InstrumentParameters[key][1] = 0.0
        h.InstrumentParameters[key][2] = False
    h.InstrumentParameters["Zero"][2] = True
    for index, (size_seed, strain_seed) in terms.items():
        p = gpx.phase(index)
        hap = p.data["Histograms"][h.name]
        if size_seed is not None:
            hap["Size"][1][0] = size_seed
            hap["Size"][2][0] = True
            gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;i")
            gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;i")
        if strain_seed is not None:
            hap["Mustrain"][1][0] = strain_seed
            hap["Mustrain"][2][0] = True
            gpx.set_Controls("parmMin", 0.0, variable=f"{p.id}:0:Mustrain;i")
            gpx.set_Controls("parmMax", 10000.0, variable=f"{p.id}:0:Mustrain;i")
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 40)


def summarize(gpx, name, path):
    h = gpx.histogram(0)
    rv = gpx.data["Covariance"]["data"].get("Rvals", {})
    return {
        "name": name,
        "project": str(path.relative_to(ROOT)),
        "Rwp": h.get_wR(),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "message": rv.get("msg", ""),
        "profile": {k: h.InstrumentParameters[k][1] for k in ("U", "W", "X")},
        "fractions": {n: v[0] for n, v in h.ComputeMassFracs().items()},
        "widths": {
            p.name: {
                "size_um": p.data["Histograms"][h.name]["Size"][1][0],
                "size_refine": p.data["Histograms"][h.name]["Size"][2][0],
                "strain": p.data["Histograms"][h.name]["Mustrain"][1][0],
                "strain_refine": p.data["Histograms"][h.name]["Mustrain"][2][0],
            } for p in gpx.phases()
        },
    }


rows = []
for name, terms in BRANCHES:
    path = OUTDIR / f"{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path))
    configure(gpx, terms)
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        gpx.save()
        gpx.refine()
        replay = G2sc.G2Project(str(path))
        replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        replay.refine()
    row = summarize(replay, name, path)
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "full_profile_collective2.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
