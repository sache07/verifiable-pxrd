#!/usr/bin/env python3
import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUTDIR = ROOT / ".tmp" / "source_survey"
OUTDIR.mkdir(parents=True, exist_ok=True)

SOURCES = [
    ("9009811", "9/00/98/9009811.cif", "2311041", "2/31/10/2311041.cif"),
    ("1527935", "1/52/79/1527935.cif", "2311041", "2/31/10/2311041.cif"),
    ("9009811", "9/00/98/9009811.cif", "2106293", "2/10/62/2106293.cif"),
    ("9009811", "9/00/98/9009811.cif", "2107312", "2/10/73/2107312.cif"),
    ("9009811", "9/00/98/9009811.cif", "1528915", "1/52/89/1528915.cif"),
]


def neutralize(p, hname):
    hap = p.data["Histograms"][hname]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]


def build(pb_id, pb_rel, wo_id, wo_rel):
    project_path = OUTDIR / f"pb{pb_id}_wo{wo_id}.gpx"
    gpx = G2sc.G2Project(newgpx=str(project_path))
    h = gpx.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"), str(ROOT / "instrument.instprm"),
        fmthint="comma/tab/semicolon separated")
    pb = gpx.add_phase(str(COD / pb_rel), phasename="PbWO4_scheelite",
                       histograms=[h], fmthint="CIF")
    wo = gpx.add_phase(str(COD / wo_rel), phasename=f"WO3_source_{wo_id}",
                       histograms=[h], fmthint="CIF")
    h.set_refinements({"Limits": [10.0, 100.0]})
    h.SampleParameters["Scale"][:] = [1.0, False]
    h.SampleParameters["SurfRoughA"][:] = [0.0, False]
    h.SampleParameters["SurfRoughB"][:] = [0.0, False]
    for key, value, refine in (
        ("Zero", 0.435, True), ("U", 0.0, False), ("V", 0.0, False),
        ("W", 0.0, False), ("X", 8.7, True), ("Y", 0.0, False),
        ("Z", 0.0, False), ("SH/L", 0.0005, False),
        ("Polariz.", 0.5, False),
    ):
        h.InstrumentParameters[key][1] = value
        h.InstrumentParameters[key][2] = refine
    h.set_refinements({"Background": {
        "type": "chebyschev-1", "refine": True, "no. coeffs": 8,
        "coeffs": [1515.0, -1177.0, 614.0, -243.0, 72.0, -24.0, 8.0, 5.0],
    }})
    for phase, scale in ((pb, 9.3), (wo, 3.25)):
        neutralize(phase, h.name)
        phase.HAPvalue("Scale", scale)
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})
    pb_hap = pb.data["Histograms"][h.name]
    pb_hap["Size"][1][0] = 0.068
    pb_hap["Size"][2][0] = True
    gpx.set_Controls("parmMin", 0.001, variable="0:0:Size;i")
    gpx.set_Controls("parmMax", 10.0, variable="0:0:Size;i")
    gpx.set_Controls("parmMin", 0.0, variable=":0:X")
    gpx.set_Controls("parmMax", 200.0, variable=":0:X")
    gpx.set_Controls("cycles", 20)
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        gpx.save()
        gpx.refine()
        gpx.refine()
    h = gpx.histogram(0)
    rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
    return {
        "pb_source": pb_id,
        "wo3_source": wo_id,
        "project": str(project_path.relative_to(ROOT)),
        "Rwp": h.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "message": rvals.get("msg", ""),
        "zero": h.InstrumentParameters["Zero"][1],
        "X": h.InstrumentParameters["X"][1],
        "fractions": {name: pair[0] for name, pair in h.ComputeMassFracs().items()},
        "cells": {p.name: p.get_cell() for p in gpx.phases()},
        "pb_size_um": gpx.phase(0).data["Histograms"][h.name]["Size"][1][0],
    }


rows = []
for source in SOURCES:
    row = build(*source)
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "source_survey.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
