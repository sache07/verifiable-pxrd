#!/usr/bin/env python3
"""Locate the final smooth-background elbow with SH/L active."""

import contextlib
import io
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT=Path(__file__).resolve().parent
BASE=ROOT/".tmp"/"four_phase_nuisance"/"shl010.gpx"
OUTDIR=ROOT/".tmp"/"four_phase_background_elbow"; OUTDIR.mkdir(parents=True,exist_ok=True)
rows=[]
for count in (8,10,12,14,16,18,20):
    path=OUTDIR/f"background{count}.gpx"; gpx=G2sc.G2Project(str(BASE),newgpx=str(path)); h=gpx.histogram(0)
    coeffs=list(h.Background[0][3:])
    h.set_refinements({"Background":{"type":"chebyschev-1","refine":True,
        "no. coeffs":count,"coeffs":(coeffs+[0.0]*count)[:count]}})
    h.InstrumentParameters["SH/L"][2]=True
    gpx.set_Controls("parmMin",0.0005,variable=":0:SH/L"); gpx.set_Controls("parmMax",0.2,variable=":0:SH/L")
    gpx.data["Controls"]["data"]["parmFrozen"]={"FrozenList":[]}; gpx.set_Controls("cycles",55)
    captured=io.StringIO()
    with contextlib.redirect_stdout(captured),contextlib.redirect_stderr(captured):
        gpx.save(); gpx.refine(); replay=G2sc.G2Project(str(path))
        replay.data["Controls"]["data"]["parmFrozen"]={"FrozenList":[]}; replay.set_Controls("cycles",55); replay.refine()
    h=replay.histogram(0); rv=replay.data["Covariance"]["data"].get("Rvals",{}); y=h.data["data"][1]
    x=np.asarray(y[0]); resid=np.asarray(y[1])-np.asarray(y[3]); seg={}
    for lo,hi in ((10,30),(30,60),(60,80),(80,100)):
        use=(x>=lo)&(x<hi); seg[f"{lo}_{hi}"]=float(np.sqrt(np.mean(resid[use]**2)))
    row={"coefficients":count,"project":str(path.relative_to(ROOT)),"Rwp":h.get_wR(),
         "GOF":rv.get("GOF"),"chisq":rv.get("chisq"),"Nobs":rv.get("Nobs"),"Nvars":rv.get("Nvars"),
         "converged":rv.get("converged"),"message":rv.get("msg",""),
         "SH_L":h.InstrumentParameters["SH/L"][1],"polarization":h.InstrumentParameters["Polariz."][1],
         "background_values":list(h.Background[0][3:]),"segment_residual_rms":seg,
         "fractions":{n:v[0] for n,v in h.ComputeMassFracs().items()}}
    diagnostic=captured.getvalue()
    if "Warning" in diagnostic or "Error" in diagnostic or "singular" in diagnostic.lower(): row["diagnostic_tail"]=diagnostic[-4000:]
    rows.append(row); print(json.dumps(row,sort_keys=True),flush=True)
with open(ROOT/"four_phase_background_elbow.json","w") as stream: json.dump(rows,stream,indent=2,sort_keys=True)
