#!/usr/bin/env python3
import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "three_phase_survey" / "pb3o4_9012124.gpx"
OUTDIR = ROOT / ".tmp" / "collective_width3"
OUTDIR.mkdir(parents=True, exist_ok=True)

BRANCHES = [
    ("sizes_seed05", {0: (0.05, 0.0), 2: (0.05, 0.0)}),
    ("sizes_seed10", {0: (0.10, 0.0), 2: (0.10, 0.0)}),
    ("pbsize_pb3strain", {0: (0.05, 0.0), 2: (None, 5000.0)}),
    ("sizes_pb3strain", {0: (0.05, 0.0), 2: (0.05, 5000.0)}),
]


def reset(gpx):
    h = gpx.histogram(0)
    for key, value in (("U", 0.0), ("V", 0.0), ("W", 0.0),
                       ("X", 8.0), ("Y", 0.0), ("Z", 0.0)):
        h.InstrumentParameters[key][1] = value
        h.InstrumentParameters[key][2] = False
    h.InstrumentParameters["Zero"][2] = True
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 30)


def run(name, terms):
    path = OUTDIR / f"{name}.gpx"
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(path))
    reset(gpx)
    h = gpx.histogram(0)
    for phase_index, (size_seed, strain_seed) in terms.items():
        p = gpx.phase(phase_index)
        hap = p.data["Histograms"][h.name]
        if size_seed is not None:
            hap["Size"][1][0] = size_seed
            hap["Size"][2][0] = True
            gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;i")
            gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;i")
        if strain_seed:
            hap["Mustrain"][1][0] = strain_seed
            hap["Mustrain"][2][0] = True
            gpx.set_Controls("parmMin", 0.0, variable=f"{p.id}:0:Mustrain;i")
            gpx.set_Controls("parmMax", 10000.0, variable=f"{p.id}:0:Mustrain;i")
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        gpx.save()
        gpx.refine()
        h = gpx.histogram(0)
        h.InstrumentParameters["X"][2] = True
        gpx.set_Controls("parmMin", 0.0, variable=":0:X")
        gpx.set_Controls("parmMax", 200.0, variable=":0:X")
        gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        gpx.refine()
        replay = G2sc.G2Project(str(path))
        replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        replay.refine()
    h = replay.histogram(0)
    rv = replay.data["Covariance"]["data"].get("Rvals", {})
    return {
        "name": name,
        "project": str(path.relative_to(ROOT)),
        "Rwp": h.get_wR(),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "message": rv.get("msg", ""),
        "X": h.InstrumentParameters["X"][1],
        "zero": h.InstrumentParameters["Zero"][1],
        "fractions": {n: pair[0] for n, pair in h.ComputeMassFracs().items()},
        "widths": {
            p.name: {
                "size_um": p.data["Histograms"][h.name]["Size"][1][0],
                "size_refine": p.data["Histograms"][h.name]["Size"][2][0],
                "mustrain": p.data["Histograms"][h.name]["Mustrain"][1][0],
                "mustrain_refine": p.data["Histograms"][h.name]["Mustrain"][2][0],
            } for p in replay.phases()
        },
    }


rows = []
for name, terms in BRANCHES:
    row = run(name, terms)
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)
with open(ROOT / "collective_width3.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
