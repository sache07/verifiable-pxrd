#!/usr/bin/env python3
"""Prune the accepted model, replay the full range, and freeze deliverables."""

import contextlib
import csv
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "close_source_crossseeds" / "pbwo4_9009811_from_1527935.gpx"
FINAL = ROOT / "final.gpx"

PHASE_OUTPUTS = (
    ("PbWO4 (scheelite)", "PbWO4", "phase_1_PbWO4.cif", "COD 9009811"),
    ("WO3 (monoclinic)", "WO3", "phase_2_WO3.cif", "COD 2311041"),
    ("Pb3O4 (minium)", "Pb3O4", "phase_3_Pb3O4.cif", "COD 9012124"),
    ("PbO (massicot)", "PbO", "phase_4_PbO.cif", "COD 2310433"),
)


def clear(gpx):
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 55)


def inactive_strain(strain):
    strain[0] = "isotropic"
    strain[1][:] = [0.0, 0.0, 1.0]
    strain[2][:] = [False, False, False]
    strain[4][:] = [0.0] * len(strain[4])
    strain[5][:] = [False] * len(strain[5])


def set_size(gpx, index, model, values, axis=(0, 0, 1), refine=(False, False)):
    h = gpx.histogram(0); p = gpx.phase(index)
    size = p.data["Histograms"][h.name]["Size"]
    size[0] = model; size[1][:] = [values[0], values[1], 1.0]
    size[2][:] = [refine[0], refine[1], False]; size[3] = list(axis)
    size[5][:] = [False] * len(size[5])
    if refine[0]:
        gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;i")
    if refine[1]:
        gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;a")
        gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;a")


def configure(gpx):
    h = gpx.histogram(0)
    low, high = h.data["Limits"][0]
    h.data["Limits"][1] = [float(low), float(high)]

    # Accepted smooth background and one angular correction.
    h.Background[0][1] = True
    for key in ("U", "V", "Y", "Z"):
        h.InstrumentParameters[key][1:3] = [0.0, False]
    for key in ("W", "X"):
        h.InstrumentParameters[key][2] = True
        gpx.set_Controls("parmMin", 0.0, variable=f":0:{key}")
        gpx.set_Controls("parmMax", 200.0, variable=f":0:{key}")
    h.InstrumentParameters["Zero"][2] = True
    h.InstrumentParameters["Polariz."][2] = True
    h.InstrumentParameters["SH/L"][2] = True
    gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")

    # Inactive sample terms are literal.
    for key in ("SurfRoughA", "SurfRoughB"):
        h.SampleParameters[key][:] = [0.0, False]

    # The source cross-seed converged to equal PbWO4 uniaxial widths and a
    # March ratio near one, so prune both unsupported elaborations.
    set_size(gpx, 0, "isotropic", (0.0640, 10.0), refine=(True, False))
    set_size(gpx, 1, "isotropic", (10.0, 10.0), refine=(False, False))
    set_size(gpx, 2, "uniaxial", (0.0361, 0.0211),
             axis=(0, 1, -1), refine=(True, True))
    set_size(gpx, 3, "uniaxial", (0.0587, 0.0210),
             axis=(0, 2, -1), refine=(True, True))

    for index, p in enumerate(gpx.phases()):
        p.data["General"]["Cell"][0] = True
        hap = p.data["Histograms"][h.name]
        hap["Scale"][1] = True
        inactive_strain(hap["Mustrain"])
        if index != 3:
            hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
        gpx.set_Controls("parmMin", 0.0, variable=f"{p.id}:0:Scale")
        gpx.set_Controls("parmMax", 100.0, variable=f"{p.id}:0:Scale")

    po = gpx.phase(3).data["Histograms"][h.name]["Pref.Ori."]
    po[0:4] = ["MD", 0.742, True, [1, -1, -1]]
    gpx.set_Controls("parmMin", 0.2, variable="3:0:MD")
    gpx.set_Controls("parmMax", 5.0, variable="3:0:MD")
    clear(gpx)


gpx = G2sc.G2Project(str(BASE), newgpx=str(FINAL))
configure(gpx)
captured = io.StringIO()
with contextlib.redirect_stdout(captured), contextlib.redirect_stderr(captured):
    gpx.save(); gpx.refine()
    replay = G2sc.G2Project(str(FINAL)); clear(replay); replay.refine()
    replay = G2sc.G2Project(str(FINAL)); clear(replay); replay.refine()

# Reopen once more so every output is generated from the exact saved project.
project = G2sc.G2Project(str(FINAL)); h = project.histogram(0)
rv = project.data["Covariance"]["data"].get("Rvals", {})
diagnostic = captured.getvalue()
(ROOT / ".tmp" / "final_refinement_diagnostic.txt").write_text(diagnostic)

if not rv.get("converged", False):
    raise RuntimeError(f"Final refinement did not converge: {rv.get('msg', '')}")
bad_words = ("parameter(s) dropped", "outside limits and were frozen", "hessian normalization problem")
if any(word in diagnostic.lower() for word in bad_words):
    raise RuntimeError("Final replay contained a dropped, frozen, or singular parameter")

mass = h.ComputeMassFracs()
raw = [float(mass[p.name][0]) for p in project.phases()]
esd = [float(mass[p.name][1]) for p in project.phases()]
total = sum(raw)
fractions = [value / total for value in raw]
fractions[-1] = 1.0 - sum(fractions[:-1])

phase_rows = []
for index, (phase, metadata) in enumerate(zip(project.phases(), PHASE_OUTPUTS)):
    display_name, formula, filename, source = metadata
    cif_path = ROOT / filename
    phase.export_CIF(str(cif_path))
    cell = phase.get_cell()
    phase_rows.append({
        "name": display_name,
        "formula": formula,
        "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
        "source_record": source,
        "cif_path": filename,
        "project_path": "final.gpx",
        "weight_fraction": fractions[index],
        "weight_fraction_esd": esd[index],
        "weight_percent": 100.0 * fractions[index],
        "cell": {
            "a_angstrom": float(cell["length_a"]),
            "b_angstrom": float(cell["length_b"]),
            "c_angstrom": float(cell["length_c"]),
            "alpha_deg": float(cell["angle_alpha"]),
            "beta_deg": float(cell["angle_beta"]),
            "gamma_deg": float(cell["angle_gamma"]),
            "volume_angstrom3": float(cell["volume"]),
        },
    })

profile = h.data["data"][0]
arrays = h.data["data"][1]
with open(ROOT / "fit.csv", "w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(("two_theta_deg", "observed_counts", "calculated_counts",
                     "difference_counts", "background_counts"))
    for x, observed, calculated, background in zip(arrays[0], arrays[1], arrays[3], arrays[4]):
        observed = float(observed); calculated = float(calculated)
        writer.writerow((f"{float(x):.8f}", f"{observed:.10g}",
                         f"{calculated:.10g}", f"{observed-calculated:.10g}",
                         f"{float(background):.10g}"))

result = {
    "project_path": "final.gpx",
    "pattern_path": "inputs/pattern.csv",
    "fit_path": "fit.csv",
    "quantification_basis": "modeled crystalline phases, normalized to 1.0",
    "phases": phase_rows,
    "fit_statistics": {
        "r_wp_percent": float(h.get_wR()),
        "r_p_percent": float(profile.get("R", float("nan"))),
        "r_exp_percent": float(profile.get("wRmin", float("nan"))),
        "goodness_of_fit": float(rv.get("GOF", float("nan"))),
        "chi_squared": float(rv.get("chisq", float("nan"))),
        "n_observations": int(rv.get("Nobs", profile.get("Nobs", 0))),
        "n_variables": int(rv.get("Nvars", 0)),
        "durbin_watson": float(profile.get("Durbin-Watson", float("nan"))),
        "converged": bool(rv.get("converged", False)),
    },
    "measurement_range_two_theta_deg": [float(h.data["Limits"][0][0]),
                                         float(h.data["Limits"][0][1])],
}
with open(ROOT / "result.json", "w") as stream:
    json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)

summary = {
    "diagnostic_has_warning": "warning" in diagnostic.lower(),
    "result": result,
    "profile": {key: h.InstrumentParameters[key][1] for key in
                ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")},
    "active_limits": list(h.data["Limits"][1]),
    "background_coefficients": len(h.Background[0]) - 3,
    "roughness": {key: h.SampleParameters[key] for key in ("SurfRoughA", "SurfRoughB")},
    "phase_models": {},
}
for p in project.phases():
    hap = p.data["Histograms"][h.name]
    summary["phase_models"][p.name] = {
        "size_model": hap["Size"][0], "size_um": list(hap["Size"][1][:2]),
        "size_flags": list(hap["Size"][2][:2]),
        "strain": hap["Mustrain"][1][0], "strain_flags": list(hap["Mustrain"][2]),
        "march_ratio": hap["Pref.Ori."][1], "march_refine": hap["Pref.Ori."][2],
        "march_axis": list(hap["Pref.Ori."][3]),
    }
with open(ROOT / ".tmp" / "final_summary.json", "w") as stream:
    json.dump(summary, stream, indent=2, sort_keys=True)

print(json.dumps(result, indent=2, sort_keys=True))
