#!/usr/bin/env python3
"""Cross-seed the two close source alternatives on the final four-phase basis."""

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
FINAL_BASE = ROOT / ".tmp" / "four_phase_background_elbow" / "background18.gpx"
PBWO4_ALT_BASE = ROOT / ".tmp" / "nuisance_collective" / "pol_seed05.gpx"
PBO_ALT_BASE = ROOT / ".tmp" / "axes_pbo1533609_texture" / "p4_0_1_0.gpx"
OUTDIR = ROOT / ".tmp" / "close_source_crossseeds"
OUTDIR.mkdir(parents=True, exist_ok=True)


def clear(gpx):
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 55)


def inactive_strain(strain):
    strain[0] = "isotropic"
    strain[1][:] = [0.0, 0.0, 1.0]
    strain[2][:] = [False, False, False]
    strain[4][:] = [0.0] * len(strain[4])
    strain[5][:] = [False] * len(strain[5])


def set_iso_size(gpx, index, seed, refine=True):
    h = gpx.histogram(0); p = gpx.phase(index)
    size = p.data["Histograms"][h.name]["Size"]
    size[0] = "isotropic"; size[1][:] = [seed, 10.0, 1.0]
    size[2][:] = [refine, False, False]
    size[5][:] = [False] * len(size[5])
    if refine:
        gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;i")


def set_uniax_size(gpx, index, axis, values, refine=True):
    h = gpx.histogram(0); p = gpx.phase(index)
    size = p.data["Histograms"][h.name]["Size"]
    size[0] = "uniaxial"; size[1][:] = [values[0], values[1], 1.0]
    size[2][:] = [refine, refine, False]; size[3] = list(axis)
    size[5][:] = [False] * len(size[5])
    if refine:
        for suffix in ("i", "a"):
            gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;{suffix}")
            gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;{suffix}")


def set_strain(gpx, index, seed=100.0):
    h = gpx.histogram(0); p = gpx.phase(index)
    strain = p.data["Histograms"][h.name]["Mustrain"]
    inactive_strain(strain); strain[1][0] = seed; strain[2][0] = True
    gpx.set_Controls("parmMin", 0.0, variable=f"{p.id}:0:Mustrain;i")
    gpx.set_Controls("parmMax", 10000.0, variable=f"{p.id}:0:Mustrain;i")


def set_texture(gpx, index, axis, ratio, refine=True):
    h = gpx.histogram(0); p = gpx.phase(index)
    po = p.data["Histograms"][h.name]["Pref.Ori."]
    po[0:4] = ["MD", ratio, refine, list(axis)]
    if refine:
        gpx.set_Controls("parmMin", 0.2, variable=f"{p.id}:0:MD")
        gpx.set_Controls("parmMax", 5.0, variable=f"{p.id}:0:MD")


def set_profile(gpx, zero, polarization, w, x, shl):
    h = gpx.histogram(0)
    for key in ("U", "V", "Y", "Z"):
        h.InstrumentParameters[key][1:3] = [0.0, False]
    h.InstrumentParameters["Zero"][1:3] = [zero, True]
    h.InstrumentParameters["Polariz."][1:3] = [polarization, True]
    h.InstrumentParameters["W"][1:3] = [w, True]
    h.InstrumentParameters["X"][1:3] = [x, True]
    h.InstrumentParameters["SH/L"][1:3] = [shl, True]
    gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    for key in ("W", "X"):
        gpx.set_Controls("parmMin", 0.0, variable=f":0:{key}")
        gpx.set_Controls("parmMax", 200.0, variable=f":0:{key}")


def run(gpx, path, mode):
    clear(gpx)
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured), contextlib.redirect_stderr(captured):
        gpx.save(); gpx.refine()
        replay = G2sc.G2Project(str(path)); clear(replay); replay.refine()
    h = replay.histogram(0); rv = replay.data["Covariance"]["data"].get("Rvals", {})
    row = {
        "mode": mode, "project": str(path.relative_to(ROOT)),
        "Rwp": h.get_wR(), "GOF": rv.get("GOF"),
        "converged": rv.get("converged"), "message": rv.get("msg", ""),
        "profile": {k: h.InstrumentParameters[k][1] for k in
                    ("Zero", "Polariz.", "U", "W", "X", "SH/L")},
        "fractions": {name: pair[0] for name, pair in h.ComputeMassFracs().items()},
        "phases": {},
    }
    for p in replay.phases():
        hap = p.data["Histograms"][h.name]
        row["phases"][p.name] = {
            "cell": list(p.data["General"]["Cell"][1:7]),
            "scale": hap["Scale"][0], "scale_refine": hap["Scale"][1],
            "size_model": hap["Size"][0], "size": list(hap["Size"][1][:2]),
            "size_flags": list(hap["Size"][2][:2]),
            "strain": hap["Mustrain"][1][0],
            "strain_refine": hap["Mustrain"][2][0],
            "march_ratio": hap["Pref.Ori."][1],
            "march_axis": list(hap["Pref.Ori."][3]),
            "march_refine": hap["Pref.Ori."][2],
        }
    diagnostic = captured.getvalue()
    if any(word in diagnostic.lower() for word in ("warning", "error", "singular", "dropped")):
        row["diagnostic_tail"] = diagnostic[-6000:]
    print(json.dumps(row, sort_keys=True), flush=True)
    return replay, row


rows = []

# Re-seed the retained scheelite record from the nuisance/topology basin favored
# by COD 1527935. This explicitly tests the prior rank reversal.
path = OUTDIR / "pbwo4_9009811_from_1527935.gpx"
gpx = G2sc.G2Project(str(FINAL_BASE), newgpx=str(path))
set_profile(gpx, 0.44005, 0.71510, 8.8468, 5.8814, 0.0168)
set_uniax_size(gpx, 0, (1, -2, -2), (0.0552, 0.0867))
set_texture(gpx, 0, (0, 1, -2), 1.3451)
_, row = run(gpx, path, "pbwo4_9009811_from_1527935")
rows.append(row)

# Build a clean four-phase COD 1527935 model from its converged three-phase
# checkpoint and add the accepted massicot phase with identical elaboration.
path = OUTDIR / "pbwo4_1527935_four_phase.gpx"
gpx = G2sc.G2Project(str(PBWO4_ALT_BASE), newgpx=str(path)); h = gpx.histogram(0)
base = G2sc.G2Project(str(FINAL_BASE)); hb = base.histogram(0)
coeffs = list(hb.Background[0][3:])
h.set_refinements({"Background": {"type": "chebyschev-1", "refine": True,
                                  "no. coeffs": len(coeffs), "coeffs": coeffs}})
set_profile(gpx, 0.44005, 0.71510, 8.8468, 5.8814, 0.0168)
set_uniax_size(gpx, 0, (1, -2, -2), (0.0552, 0.0867))
set_texture(gpx, 0, (0, 1, -2), 1.3451)
set_uniax_size(gpx, 2, (0, 1, -1), (0.0360, 0.0211))
p = gpx.add_phase(str(COD / "2/31/04/2310433.cif"),
                  phasename="PbO_massicot_crossseed", histograms=[h], fmthint="CIF")
p.data["General"]["Cell"][0] = True
p.data["General"]["Cell"][1:7] = [5.88772, 5.48683, 4.75937, 90.0, 90.0, 90.0]
p.data["Histograms"][h.name]["Scale"][:] = [1.1133, True]
inactive_strain(p.data["Histograms"][h.name]["Mustrain"])
set_uniax_size(gpx, 3, (0, 2, -1), (0.05975, 0.02131))
set_texture(gpx, 3, (1, -1, -1), 0.7460)
gpx.set_Controls("parmMin", 0.0, variable="3:0:Scale")
gpx.set_Controls("parmMax", 100.0, variable="3:0:Scale")
_, row = run(gpx, path, "pbwo4_1527935_four_phase")
rows.append(row)

# Combine the best complete-axis size and texture branches for the PbO
# supercell record, then replay its supported widths from low physical seeds.
path = OUTDIR / "pbo_1533609_combined.gpx"
gpx = G2sc.G2Project(str(PBO_ALT_BASE), newgpx=str(path))
set_uniax_size(gpx, 4, (0, 1, 0), (0.06496, 0.03182))
set_texture(gpx, 4, (0, 1, 0), 1.08816)
interior, row = run(gpx, path, "pbo_1533609_combined")
rows.append(row)

path = OUTDIR / "pbo_1533609_sizes_low.gpx"
gpx = G2sc.G2Project(str(interior.filename), newgpx=str(path))
set_iso_size(gpx, 0, 0.030)
set_uniax_size(gpx, 2, (0, 1, -1), (0.030, 0.030))
set_uniax_size(gpx, 4, (0, 1, 0), (0.030, 0.030))
interior_low, row = run(gpx, path, "pbo_1533609_sizes_low")
rows.append(row)

path = OUTDIR / "pbo_1533609_collective_strain.gpx"
gpx = G2sc.G2Project(str(interior_low.filename), newgpx=str(path))
for index in (0, 2, 4):
    set_strain(gpx, index, 100.0)
_, row = run(gpx, path, "pbo_1533609_collective_strain")
rows.append(row)

with open(ROOT / "close_source_crossseeds.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
