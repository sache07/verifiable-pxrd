#!/usr/bin/env python3
"""Build the neutral-texture collective size checkpoint for four phases."""

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "four_phase_cell" / "cell_replay.gpx"
OUT = ROOT / ".tmp" / "four_phase_elaborated" / "sizes_replay.gpx"
OUT.parent.mkdir(parents=True, exist_ok=True)


def inactive_size(size):
    size[0] = "isotropic"
    size[1][:] = [10.0, 10.0, 1.0]
    size[2][:] = [False, False, False]
    size[5][:] = [False] * len(size[5])


def set_iso(gpx, index, seed):
    h = gpx.histogram(0)
    p = gpx.phase(index)
    size = p.data["Histograms"][h.name]["Size"]
    inactive_size(size)
    size[1][0], size[2][0] = seed, True
    gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;i")
    gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;i")


def set_uniaxial(gpx, index, axis, equatorial, axial):
    h = gpx.histogram(0)
    p = gpx.phase(index)
    size = p.data["Histograms"][h.name]["Size"]
    inactive_size(size)
    size[0] = "uniaxial"
    size[1][0:3] = [equatorial, axial, 1.0]
    size[2][0:3] = [True, True, False]
    size[3] = list(axis)
    for suffix in ("i", "a"):
        gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;{suffix}")
        gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;{suffix}")


gpx = G2sc.G2Project(str(BASE), newgpx=str(OUT))
h = gpx.histogram(0)
for p in gpx.phases():
    p.data["Histograms"][h.name]["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
set_iso(gpx, 0, 0.067)
inactive_size(gpx.phase(1).data["Histograms"][h.name]["Size"])
set_uniaxial(gpx, 2, (0, 1, -1), 0.0373, 0.0209)
set_uniaxial(gpx, 3, (0, 2, -1), 0.0659, 0.0179)

for key in ("V", "Y", "Z"):
    h.InstrumentParameters[key][1:3] = [0.0, False]
h.InstrumentParameters["U"][1:3] = [0.0, False]
for key in ("W", "X"):
    h.InstrumentParameters[key][2] = True
    gpx.set_Controls("parmMin", 0.0, variable=f":0:{key}")
    gpx.set_Controls("parmMax", 200.0, variable=f":0:{key}")
h.InstrumentParameters["SH/L"][1:3] = [0.0005, False]
h.SampleParameters["SurfRoughA"][:] = [0.0, False]
h.SampleParameters["SurfRoughB"][:] = [0.0, False]
gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
gpx.set_Controls("cycles", 55)

captured = io.StringIO()
with contextlib.redirect_stdout(captured), contextlib.redirect_stderr(captured):
    gpx.save()
    gpx.refine()
    replay = G2sc.G2Project(str(OUT))
    replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    replay.set_Controls("cycles", 55)
    replay.refine()

h = replay.histogram(0)
rv = replay.data["Covariance"]["data"].get("Rvals", {})
row = {
    "project": str(OUT.relative_to(ROOT)),
    "Rwp": h.get_wR(), "GOF": rv.get("GOF"),
    "converged": rv.get("converged"), "message": rv.get("msg", ""),
    "profile": {k: h.InstrumentParameters[k][1] for k in ("U", "W", "X")},
    "fractions": {n: v[0] for n, v in h.ComputeMassFracs().items()},
    "sizes": {
        p.name: {
            "model": p.data["Histograms"][h.name]["Size"][0],
            "values": list(p.data["Histograms"][h.name]["Size"][1][:2]),
            "axis": list(p.data["Histograms"][h.name]["Size"][3]),
        } for p in replay.phases()
    },
}
diagnostic = captured.getvalue()
if "Warning" in diagnostic or "Error" in diagnostic or "singular" in diagnostic.lower():
    row["diagnostic_tail"] = diagnostic[-4000:]
print(json.dumps(row, sort_keys=True))
with open(ROOT / "four_phase_elaborated.json", "w") as stream:
    json.dump(row, stream, indent=2, sort_keys=True)
