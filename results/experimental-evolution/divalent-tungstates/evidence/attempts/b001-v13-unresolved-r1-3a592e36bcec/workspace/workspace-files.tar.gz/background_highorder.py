#!/usr/bin/env python3
"""Locate the smooth-background order elbow with polarization active."""

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "nuisance_collective" / "pol_seed05.gpx"
OUTDIR = ROOT / ".tmp" / "background_highorder"
OUTDIR.mkdir(parents=True, exist_ok=True)

rows = []
for count in (8, 10, 12, 14):
    path = OUTDIR / f"background{count}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path))
    h = gpx.histogram(0)
    coeffs = list(h.Background[0][3:])
    h.set_refinements({"Background": {
        "type": "chebyschev-1", "refine": True, "no. coeffs": count,
        "coeffs": (coeffs + [0.0] * count)[:count],
    }})
    h.InstrumentParameters["Polariz."][2] = True
    gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 40)
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        gpx.save()
        gpx.refine()
        replay = G2sc.G2Project(str(path))
        replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        replay.refine()
    h = replay.histogram(0)
    rv = replay.data["Covariance"]["data"].get("Rvals", {})
    row = {
        "coefficients": count,
        "project": str(path.relative_to(ROOT)),
        "Rwp": h.get_wR(),
        "GOF": rv.get("GOF"),
        "chisq": rv.get("chisq"),
        "Nobs": rv.get("Nobs"),
        "Nvars": rv.get("Nvars"),
        "converged": rv.get("converged"),
        "message": rv.get("msg", ""),
        "polarization": h.InstrumentParameters["Polariz."][1],
        "background_values": list(h.Background[0][3:]),
        "fractions": {n: v[0] for n, v in h.ComputeMassFracs().items()},
    }
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "background_highorder.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
