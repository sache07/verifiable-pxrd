#!/usr/bin/env python3
"""Cross-seed leading Pb3O4/PbO size axes with the only supported texture trial."""

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "four_phase_elaborated" / "sizes_replay.gpx"
OUTDIR = ROOT / ".tmp" / "four_phase_axis_cross"
OUTDIR.mkdir(parents=True, exist_ok=True)

P2_AXES = ((0, 1, -1), (0, 2, -1), (0, 0, 1))
P3_AXES = ((0, 2, -1), (0, 1, -1), (1, -2, 0), (1, -1, 0))
BRANCHES = []
for p3axis in P3_AXES:
    for texture in (False, True):
        BRANCHES.append(((0, 1, -1), p3axis, texture))
for p2axis in P2_AXES[1:]:
    for texture in (False, True):
        BRANCHES.append((p2axis, (0, 2, -1), texture))


def tag(axis):
    return "_".join(str(v).replace("-", "m") for v in axis)


def set_axis(gpx, index, axis, values):
    h = gpx.histogram(0); p = gpx.phase(index)
    size = p.data["Histograms"][h.name]["Size"]
    size[0] = "uniaxial"; size[1][0:3] = [values[0], values[1], 1.0]
    size[2][0:3] = [True, True, False]; size[3] = list(axis)
    for suffix in ("i", "a"):
        gpx.set_Controls("parmMin", 0.001, variable=f"{p.id}:0:Size;{suffix}")
        gpx.set_Controls("parmMax", 10.0, variable=f"{p.id}:0:Size;{suffix}")


rows = []
for p2axis, p3axis, texture in BRANCHES:
    name = f"p2_{tag(p2axis)}_p3_{tag(p3axis)}_tex{int(texture)}"
    path = OUTDIR / f"{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path)); h = gpx.histogram(0)
    set_axis(gpx, 2, p2axis, (0.0367, 0.0215))
    set_axis(gpx, 3, p3axis, (0.0648, 0.0194))
    for p in gpx.phases():
        p.data["Histograms"][h.name]["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    if texture:
        po = gpx.phase(3).data["Histograms"][h.name]["Pref.Ori."]
        po[0:4] = ["MD", 0.75, True, [1, -1, -1]]
        gpx.set_Controls("parmMin", 0.2, variable="3:0:MD")
        gpx.set_Controls("parmMax", 5.0, variable="3:0:MD")
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 55)
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured), contextlib.redirect_stderr(captured):
        gpx.save(); gpx.refine()
        replay = G2sc.G2Project(str(path))
        replay.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        replay.set_Controls("cycles", 55); replay.refine()
    h = replay.histogram(0); rv = replay.data["Covariance"]["data"].get("Rvals", {})
    row = {
        "name": name, "project": str(path.relative_to(ROOT)),
        "p2_axis": list(p2axis), "p3_axis": list(p3axis), "texture": texture,
        "Rwp": h.get_wR(), "GOF": rv.get("GOF"),
        "converged": rv.get("converged"), "message": rv.get("msg", ""),
        "p2_sizes": list(replay.phase(2).data["Histograms"][h.name]["Size"][1][:2]),
        "p3_sizes": list(replay.phase(3).data["Histograms"][h.name]["Size"][1][:2]),
        "p3_march_ratio": replay.phase(3).data["Histograms"][h.name]["Pref.Ori."][1],
        "fractions": {n: v[0] for n, v in h.ComputeMassFracs().items()},
    }
    diagnostic = captured.getvalue()
    if "Warning" in diagnostic or "Error" in diagnostic or "singular" in diagnostic.lower():
        row["diagnostic_tail"] = diagnostic[-4000:]
    rows.append(row); print(json.dumps(row, sort_keys=True), flush=True)

with open(ROOT / "four_phase_axis_cross.json", "w") as stream:
    json.dump(rows, stream, indent=2, sort_keys=True)
