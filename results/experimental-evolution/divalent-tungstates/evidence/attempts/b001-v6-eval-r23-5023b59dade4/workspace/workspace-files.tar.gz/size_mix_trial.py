#!/usr/bin/env python3
"""Refine size Gaussian/Lorentzian mixing for selected phases."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("phase_indices", nargs="+", type=int)
    args = parser.parse_args()

    project = G2sc.G2Project(gpxfile=str(ROOT / args.input), newgpx=str(ROOT / args.output))
    project.data["Controls"]["data"]["max cyc"] = 8
    project.set_Frozen()
    hist = project.histogram(0)
    selected = set(args.phase_indices)
    for index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][2] = index in selected
        project.set_Controls("parmMin", 0.0, variable=f"{index}:0:Size;mx")
        project.set_Controls("parmMax", 1.0, variable=f"{index}:0:Size;mx")

    project.save()
    project.do_refinements([{}])
    project.do_refinements([{}])
    project.save()

    cov = project.data["Covariance"]["data"]
    sig = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    result = {
        "selected": sorted(selected),
        "Rwp": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "frozen": project.get_Frozen(),
        "mass_fractions": hist.ComputeMassFracs(),
        "phases": {},
    }
    for index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "size": hap["Size"],
            "mix_sigma": sig.get(f"{index}:0:Size;mx"),
        }
    print("RESULT", json.dumps(result, separators=(",", ":")))


if __name__ == "__main__":
    main()
