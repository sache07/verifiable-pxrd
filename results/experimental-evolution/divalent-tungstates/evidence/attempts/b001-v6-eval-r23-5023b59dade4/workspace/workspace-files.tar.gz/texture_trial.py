#!/usr/bin/env python3
"""Compare March-Dollase texture axes for one phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("phase_index", type=int)
    parser.add_argument("axis", nargs=3, type=int)
    args = parser.parse_args()

    project = G2sc.G2Project(gpxfile=str(ROOT / args.input), newgpx=str(ROOT / args.output))
    project.data["Controls"]["data"]["max cyc"] = 8
    project.set_Frozen()
    hist = project.histogram(0)
    for index, phase in enumerate(project.phases()):
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = index == args.phase_index
        if index == args.phase_index:
            po[3] = list(args.axis)
            project.set_Controls("parmMin", 0.2, variable=f"{index}:0:MD")
            project.set_Controls("parmMax", 5.0, variable=f"{index}:0:MD")

    project.save()
    project.do_refinements([{}])
    project.do_refinements([{}])
    project.save()

    cov = project.data["Covariance"]["data"]
    sig = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    phase = project.phase(args.phase_index)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    result = {
        "phase": phase.name,
        "axis": args.axis,
        "Rwp": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "MD": po,
        "MD_sigma": sig.get(f"{args.phase_index}:0:MD"),
        "frozen": project.get_Frozen(),
        "mass_fractions": hist.ComputeMassFracs(),
    }
    print("RESULT", json.dumps(result, separators=(",", ":")))


if __name__ == "__main__":
    main()
