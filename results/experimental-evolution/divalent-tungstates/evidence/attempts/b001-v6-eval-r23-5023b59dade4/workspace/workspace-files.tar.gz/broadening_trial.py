#!/usr/bin/env python3
"""Apply one phase-broadening trial to a converged restrained baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--pb", choices=("none", "size", "strain", "both"), default="none")
    parser.add_argument("--wo", choices=("none", "size", "strain", "both"), default="none")
    args = parser.parse_args()

    project = G2sc.G2Project(gpxfile=str(ROOT / args.input), newgpx=str(ROOT / args.output))
    project.data["Controls"]["data"]["max cyc"] = 8
    hist = project.histogram(0)
    phases = project.phases()

    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 0.5]
        hap["Size"][2][:] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
        hap["Mustrain"][2][:] = [False, False, False]

    for phase, mode, start_size in ((phases[0], args.pb, 0.10), (phases[1], args.wo, 0.30)):
        if mode in ("size", "both"):
            phase.setSampleProfile(hist, "size", "isotropic", start_size, LGmix=0.5)
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "refine": True, "LGmix": {"refine": False}}},
                [hist],
            )
        if mode in ("strain", "both"):
            phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=0.5)
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True, "LGmix": {"refine": False}}},
                [hist],
            )

    project.save()
    project.do_refinements([{}])
    project.do_refinements([{}])
    project.save()

    cov = project.data["Covariance"]["data"]
    result = {
        "input": args.input,
        "output": args.output,
        "pb": args.pb,
        "wo": args.wo,
        "Rwp": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "mass_fractions": hist.ComputeMassFracs(),
        "phases": {},
        "vary_list": cov.get("varyList", []),
        "variables": [float(v) for v in cov.get("variables", [])],
        "sigmas": [float(v) for v in cov.get("sig", [])],
    }
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
        }
    print("RESULT", json.dumps(result, separators=(",", ":")))


if __name__ == "__main__":
    main()
