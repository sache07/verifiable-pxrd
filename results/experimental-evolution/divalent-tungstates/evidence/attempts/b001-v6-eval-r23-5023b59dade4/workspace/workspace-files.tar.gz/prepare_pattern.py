#!/usr/bin/env python3
"""Convert the supplied count data to a GSAS-II xye input.

No pointwise uncertainties were supplied. For refinement weighting, use the
counting-statistics estimate sigma=sqrt(max(counts, 1)).
"""

from pathlib import Path

import numpy as np


root = Path(__file__).resolve().parent
data = np.loadtxt(root / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
sigma = np.sqrt(np.maximum(data[:, 1], 1.0))
np.savetxt(
    root / "work_pattern.xye",
    np.column_stack((data, sigma)),
    fmt=("%.8f", "%.8f", "%.8f"),
    header="two_theta_deg intensity sigma_poisson",
)
