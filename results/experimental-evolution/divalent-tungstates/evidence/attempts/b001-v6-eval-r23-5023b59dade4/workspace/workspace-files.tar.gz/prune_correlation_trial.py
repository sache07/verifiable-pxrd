#!/usr/bin/env python3
"""Test fixing the highly correlated Pb3O4 size-mixing coefficient."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
project = G2sc.G2Project(
    gpxfile=str(root / "final.gpx"),
    newgpx=str(root / "prune_correlation_trial.gpx"),
)
hist = project.histogram(0)
for phase_name in ("PbWO4_scheelite", "WO3_monoclinic", "Pb3O4_minium"):
    phase = project.phase(phase_name)
    size = phase.data["Histograms"][hist.name]["Size"]
    size[2][2] = False
project.data["Controls"]["data"]["max cyc"] = 30
project.data["Controls"]["data"]["min dM/M"] = 1e-8
project.save()
project.do_refinements([{}])
project.save()
project = G2sc.G2Project(gpxfile=str(root / "prune_correlation_trial.gpx"))
project.do_refinements([{}])
project.save()
cov = project.data["Covariance"]["data"]
print("Rwp", project.histogram(0).get_wR())
print("GOF", cov["Rvals"]["GOF"])
print("fractions", project.histogram(0).ComputeMassFracs())
for phase_name in ("PbWO4_scheelite", "WO3_monoclinic", "Pb3O4_minium", "PbO_massicot"):
    print("size", phase_name, project.phase(phase_name).data["Histograms"][hist.name]["Size"])
print("correlations", cov.get("Lastshft", "not stored"))
