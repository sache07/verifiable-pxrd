#!/usr/bin/env python3
"""Refine a restrained two-phase candidate model for inventory screening."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from numpy.polynomial import chebyshev
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    path = COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def run_cycle(project: G2sc.G2Project, label: str) -> None:
    print(f"\n===== {label} =====")
    project.save()
    project.do_refinements([{}])
    print("wR", project.histogram(0).get_wR())


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("pbwo4_id")
    parser.add_argument("wo3_id")
    parser.add_argument("output")
    args = parser.parse_args()

    output = ROOT / args.output
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(ROOT / "work_pattern.xye"),
        str(ROOT / "work.instprm"),
        fmthint="xye",
    )
    pb = project.add_phase(
        str(cod_path(args.pbwo4_id)),
        phasename=f"PbWO4_{args.pbwo4_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    wo = project.add_phase(
        str(cod_path(args.wo3_id)),
        phasename=f"WO3_{args.wo3_id}",
        histograms=[hist],
        fmthint="CIF",
    )

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 8
    controls["min dM/M"] = 1e-4

    # Restrained baseline: fixed histogram scale, neutral sample effects,
    # one specimen-height correction, and a smooth six-term background.
    sample = hist.data["Sample Parameters"]
    for key in ("Scale", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = False
    sample["Scale"][0] = 1.0
    sample["Shift"] = [-650.0, False]

    x, y = hist.data["data"][1][:2]
    smooth_floor = percentile_filter(np.asarray(y), percentile=15, size=401)
    xnorm = -1.0 + 2.0 * (np.asarray(x) - x[0]) / (x[-1] - x[0])
    coeffs = chebyshev.chebfit(xnorm, smooth_floor, 5)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": coeffs.tolist(),
            }
        }
    )

    inst = hist.data["Instrument Parameters"][0]
    inst["U"][0] = inst["U"][1] = 1.0
    inst["V"][0] = inst["V"][1] = 0.0
    inst["W"][0] = inst["W"][1] = 4.0
    inst["X"][0] = inst["X"][1] = 0.5
    inst["Y"][0] = inst["Y"][1] = 0.0
    inst["Z"][0] = inst["Z"][1] = 0.0
    inst["SH/L"][0] = inst["SH/L"][1] = 0.002

    for phase in (pb, wo):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [1000.0, 1000.0, 0.5]
        hap["Size"][2][:] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
        hap["Extinction"] = [0.0, False]

    run_cycle(project, "background and phase scales")

    sample["Shift"][1] = True
    run_cycle(project, "specimen height")

    pb.set_refinements({"Cell": True})
    wo.set_refinements({"Cell": True})
    run_cycle(project, "cells")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    run_cycle(project, "common U/W/X profile")
    run_cycle(project, "reconvergence")

    project.save()
    summary = {
        "pbwo4": args.pbwo4_id,
        "wo3": args.wo3_id,
        "wR_percent": hist.get_wR(),
        "shift_micrometre": sample["Shift"][0],
        "instrument": {key: inst[key][1] for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
        "mass_fractions": hist.ComputeMassFracs(),
        "phases": {
            phase.name: {
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
                "cell": phase.get_cell(),
            }
            for phase in (pb, wo)
        },
    }
    print("SUMMARY", json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
