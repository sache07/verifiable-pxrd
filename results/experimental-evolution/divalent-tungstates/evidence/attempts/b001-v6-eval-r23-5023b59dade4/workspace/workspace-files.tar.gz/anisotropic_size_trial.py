#!/usr/bin/env python3
"""Challenge a uniaxial crystallite-size model for one phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("phase_index", type=int)
    parser.add_argument("axis", nargs=3, type=int)
    parser.add_argument("--fix-polarization", action="store_true")
    args = parser.parse_args()

    project = G2sc.G2Project(gpxfile=str(ROOT / args.input), newgpx=str(ROOT / args.output))
    project.data["Controls"]["data"]["max cyc"] = 8
    project.set_Frozen()
    hist = project.histogram(0)
    if args.fix_polarization:
        hist.data["Instrument Parameters"][0]["Polariz."][2] = False
    phase = project.phase(args.phase_index)
    size = phase.data["Histograms"][hist.name]["Size"]
    initial = float(size[1][0])
    mix = float(size[1][2])
    phase.setSampleProfile(hist, "size", "uniaxial", initial, initial, args.axis, LGmix=mix)
    size[2][:] = [True, True, True]
    for suffix in ("i", "a"):
        project.set_Controls("parmMin", 0.001, variable=f"{args.phase_index}:0:Size;{suffix}")
        project.set_Controls("parmMax", 10.0, variable=f"{args.phase_index}:0:Size;{suffix}")
    project.set_Controls("parmMin", 0.0, variable=f"{args.phase_index}:0:Size;mx")
    project.set_Controls("parmMax", 1.0, variable=f"{args.phase_index}:0:Size;mx")

    project.save()
    project.do_refinements([{}])
    project.do_refinements([{}])
    project.save()
    cov = project.data["Covariance"]["data"]
    sig = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    result = {
        "phase": phase.name,
        "axis": args.axis,
        "Rwp": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "size": size,
        "sigmas": {
            suffix: sig.get(f"{args.phase_index}:0:Size;{suffix}")
            for suffix in ("i", "a", "mx")
        },
        "frozen": project.get_Frozen(),
        "mass_fractions": hist.ComputeMassFracs(),
    }
    print("RESULT", json.dumps(result, separators=(",", ":")))


if __name__ == "__main__":
    main()
