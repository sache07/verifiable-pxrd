#!/usr/bin/env python3
"""Challenge positive common instrument-profile terms on a converged model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("terms", help="subset of U, W and X, e.g. UW")
    parser.add_argument("--base-u", type=float)
    parser.add_argument("--base-w", type=float)
    parser.add_argument("--base-x", type=float)
    args = parser.parse_args()

    terms = list(dict.fromkeys(args.terms.upper()))
    if any(term not in ("U", "W", "X") for term in terms):
        raise ValueError(args.terms)

    project = G2sc.G2Project(gpxfile=str(ROOT / args.input), newgpx=str(ROOT / args.output))
    project.data["Controls"]["data"]["max cyc"] = 8
    project.set_Frozen()
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for term, value in (("U", args.base_u), ("W", args.base_w), ("X", args.base_x)):
        if value is not None:
            inst[term][0] = inst[term][1] = value
    for term in ("U", "W", "X"):
        inst[term][2] = term in terms
        project.set_Controls("parmMin", 0.0, variable=f":0:{term}")
        project.set_Controls("parmMax", 100.0, variable=f":0:{term}")

    project.save()
    project.do_refinements([{}])
    # A limit crossing freezes a parameter in GSAS-II. Replay once and report
    # the frozen list explicitly so bound solutions can be rejected.
    project.do_refinements([{}])
    project.save()

    cov = project.data["Covariance"]["data"]
    result = {
        "terms": terms,
        "Rwp": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "profile": {key: inst[key] for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
        "frozen": project.get_Frozen(),
        "mass_fractions": hist.ComputeMassFracs(),
        "vary_list": cov.get("varyList", []),
        "variables": [float(v) for v in cov.get("variables", [])],
        "sigmas": [float(v) for v in cov.get("sig", [])],
    }
    print("RESULT", json.dumps(result, separators=(",", ":")))


if __name__ == "__main__":
    main()
