#!/usr/bin/env python3
"""Challenge selected global instrument nuisance terms on a converged model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument(
        "terms", nargs="+", choices=("polarization", "shl", "ratio")
    )
    args = parser.parse_args()

    project = G2sc.G2Project(gpxfile=str(ROOT / args.input), newgpx=str(ROOT / args.output))
    project.data["Controls"]["data"]["max cyc"] = 8
    project.set_Frozen()
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    mapping = {
        "polarization": ("Polariz.", 0.0, 1.0),
        "shl": ("SH/L", 0.0, 0.1),
        "ratio": ("I(L2)/I(L1)", 0.3, 0.7),
    }
    selected = {mapping[key][0] for key in args.terms}
    for key, (_, lower, upper) in mapping.items():
        name = mapping[key][0]
        inst[name][2] = name in selected
        project.set_Controls("parmMin", lower, variable=f":0:{name}")
        project.set_Controls("parmMax", upper, variable=f":0:{name}")

    project.save()
    project.do_refinements([{}])
    project.do_refinements([{}])
    project.save()
    cov = project.data["Covariance"]["data"]
    sig = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    result = {
        "terms": args.terms,
        "Rwp": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "values": {name: inst[name] for name in selected},
        "sigmas": {f":0:{name}": sig.get(f":0:{name}") for name in selected},
        "frozen": project.get_Frozen(),
        "mass_fractions": hist.ComputeMassFracs(),
    }
    print("RESULT", json.dumps(result, separators=(",", ":")))


if __name__ == "__main__":
    main()
