#!/usr/bin/env python3
"""Refine physically restrained candidate models and profile-broadening trials."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from numpy.polynomial import chebyshev
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    path = COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def cycle(project: G2sc.G2Project, label: str) -> float:
    print(f"\n===== {label} =====")
    project.save()
    project.do_refinements([{}])
    wr = float(project.histogram(0).get_wR())
    print("TRIAL_RWP", label, wr)
    return wr


def neutral_hap(phase, hist) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1000.0, 1000.0, 0.5]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def enable_broadening(phase, hist, mode: str, label: str, project) -> list[tuple[str, float]]:
    history = []
    if mode in ("size", "both"):
        start_size = 0.10 if label == "PbWO4" else 0.30
        phase.setSampleProfile(hist, "size", "isotropic", start_size, LGmix=0.5)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True, "LGmix": {"refine": False}}},
            [hist],
        )
        history.append((f"{label} isotropic size", cycle(project, f"{label} isotropic size")))
    if mode in ("strain", "both"):
        phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=0.5)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True, "LGmix": {"refine": False}}},
            [hist],
        )
        history.append((f"{label} isotropic strain", cycle(project, f"{label} isotropic strain")))
    return history


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("pbwo4_id")
    parser.add_argument("wo3_id")
    parser.add_argument("output")
    parser.add_argument("--pb", choices=("none", "size", "strain", "both"), default="none")
    parser.add_argument("--wo", choices=("none", "size", "strain", "both"), default="none")
    parser.add_argument("--polarization", type=float, default=0.5)
    parser.add_argument("--shl", type=float, default=0.002)
    args = parser.parse_args()

    project = G2sc.G2Project(newgpx=str(ROOT / args.output))
    hist = project.add_powder_histogram(
        str(ROOT / "work_pattern.xye"), str(ROOT / "work.instprm"), fmthint="xye"
    )
    pb = project.add_phase(
        str(cod_path(args.pbwo4_id)),
        phasename=f"PbWO4_{args.pbwo4_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    wo = project.add_phase(
        str(cod_path(args.wo3_id)),
        phasename=f"WO3_{args.wo3_id}",
        histograms=[hist],
        fmthint="CIF",
    )

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 6
    controls["min dM/M"] = 1e-4

    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [-700.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    x, y = hist.data["data"][1][:2]
    floor = percentile_filter(np.asarray(y), percentile=15, size=401)
    xnorm = -1.0 + 2.0 * (np.asarray(x) - x[0]) / (x[-1] - x[0])
    coeffs = chebyshev.chebfit(xnorm, floor, 5)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": coeffs.tolist(),
            }
        }
    )

    # Narrow, positive common profile. It is deliberately held fixed while
    # phase-specific broadening is challenged one term at a time.
    inst = hist.data["Instrument Parameters"][0]
    values = {
        "U": 5.0,
        "V": 0.0,
        "W": 4.0,
        "X": 0.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": args.shl,
        "Polariz.": args.polarization,
    }
    for key, value in values.items():
        inst[key][0] = inst[key][1] = value
        inst[key][2] = False

    neutral_hap(pb, hist)
    neutral_hap(wo, hist)
    history = []
    history.append(("background and scales", cycle(project, "background and scales")))

    sample["Shift"][1] = True
    history.append(("specimen height", cycle(project, "specimen height")))

    pb.set_refinements({"Cell": True})
    wo.set_refinements({"Cell": True})
    history.append(("cells", cycle(project, "cells")))
    history.append(("baseline replay", cycle(project, "baseline replay")))

    history.extend(enable_broadening(pb, hist, args.pb, "PbWO4", project))
    history.extend(enable_broadening(wo, hist, args.wo, "WO3", project))
    history.append(("final replay", cycle(project, "final replay")))

    project.save()
    cov = project.data["Covariance"]["data"]
    summary = {
        "pbwo4": args.pbwo4_id,
        "wo3": args.wo3_id,
        "pb_broadening": args.pb,
        "wo_broadening": args.wo,
        "history": history,
        "wR_percent": hist.get_wR(),
        "reduced_chi_square": cov.get("Rvals", {}).get("GOF"),
        "shift_micrometre": sample["Shift"][0],
        "instrument": {key: inst[key][1] for key in values},
        "mass_fractions": hist.ComputeMassFracs(),
        "phases": {},
        "vary_list": cov.get("varyList", []),
        "variables": [float(v) for v in cov.get("variables", [])],
        "sigmas": [float(v) for v in cov.get("sig", [])],
    }
    for phase in (pb, wo):
        hap = phase.data["Histograms"][hist.name]
        summary["phases"][phase.name] = {
            "scale": hap["Scale"][0],
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    print("SUMMARY", json.dumps(summary, indent=2))
    print("SUMMARY_COMPACT", json.dumps(summary, separators=(",", ":")))


if __name__ == "__main__":
    main()
