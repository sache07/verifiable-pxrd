#!/usr/bin/env python3
"""Add residual-supported watch-list phases to a converged GSAS-II model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    path = COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def cycle(project, label):
    project.save()
    project.do_refinements([{}])
    wr = float(project.histogram(0).get_wR())
    print("TRIAL_RWP", label, wr)
    return wr


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("cod_ids", nargs="+")
    parser.add_argument("--refine-size", action="store_true")
    parser.add_argument("--fix-polarization", action="store_true")
    args = parser.parse_args()

    project = G2sc.G2Project(gpxfile=str(ROOT / args.input), newgpx=str(ROOT / args.output))
    project.data["Controls"]["data"]["max cyc"] = 8
    hist = project.histogram(0)
    if args.fix_polarization:
        hist.data["Instrument Parameters"][0]["Polariz."][2] = False
    added = []
    for cod_id in args.cod_ids:
        phase = project.add_phase(
            str(cod_path(cod_id)),
            phasename=f"candidate_{cod_id}",
            histograms=[hist],
            fmthint="CIF",
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [0.5, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 0.5]
        hap["Size"][2][:] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
        hap["Extinction"] = [0.0, False]
        added.append(phase)

    history = [("scales", cycle(project, "scales"))]
    for phase in added:
        phase.set_refinements({"Cell": True})
    history.append(("cells", cycle(project, "cells")))

    if args.refine_size:
        for phase in added:
            phase.setSampleProfile(hist, "size", "isotropic", 0.05, LGmix=0.5)
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "refine": True, "LGmix": {"refine": False}}},
                [hist],
            )
            history.append((f"size {phase.name}", cycle(project, f"size {phase.name}")))
    history.append(("replay", cycle(project, "replay")))
    project.save()

    cov = project.data["Covariance"]["data"]
    result = {
        "cod_ids": args.cod_ids,
        "history": history,
        "Rwp": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "mass_fractions": hist.ComputeMassFracs(),
        "phases": {},
        "vary_list": cov.get("varyList", []),
        "variables": [float(v) for v in cov.get("variables", [])],
        "sigmas": [float(v) for v in cov.get("sig", [])],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "scale": hap["Scale"],
            "cell": phase.get_cell(),
            "size": hap["Size"],
        }
    print("RESULT", json.dumps(result, separators=(",", ":")))


if __name__ == "__main__":
    main()
