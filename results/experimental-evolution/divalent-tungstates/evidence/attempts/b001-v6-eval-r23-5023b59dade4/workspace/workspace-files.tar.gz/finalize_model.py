#!/usr/bin/env python3
"""Create the final replayed GSAS-II project and requested exports."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE_GPX = ROOT / "anis_pb3o4_fixedpol.gpx"
FINAL_GPX = ROOT / "final.gpx"

PHASE_INFO = [
    {
        "old": "PbWO4_9009811",
        "name": "PbWO4_scheelite",
        "formula": "PbWO4",
        "space_group": "I 41/a",
        "source_cod_id": "9009811",
        "cif": "phase_1_PbWO4_scheelite.cif",
    },
    {
        "old": "WO3_2311041",
        "name": "WO3_monoclinic",
        "formula": "WO3",
        "space_group": "P 21/c",
        "source_cod_id": "2311041",
        "cif": "phase_2_WO3_monoclinic.cif",
    },
    {
        "old": "candidate_9012124",
        "name": "Pb3O4_minium",
        "formula": "Pb3O4",
        "space_group": "P 42/mbc",
        "source_cod_id": "9012124",
        "cif": "phase_3_Pb3O4_minium.cif",
    },
    {
        "old": "candidate_2310433",
        "name": "PbO_massicot",
        "formula": "PbO",
        "space_group": "Pbcm",
        "source_cod_id": "2310433",
        "cif": "phase_4_PbO_massicot.cif",
    },
]


def rename_phase(project: G2sc.G2Project, old: str, new: str) -> None:
    phases = project.data["Phases"]
    phase_data = phases.pop(old)
    phases[new] = phase_data
    phase_data["General"]["Name"] = new
    for entry in project.names:
        if entry and entry[0] == "Phases":
            entry[entry.index(old)] = new
        elif entry and entry[0] == "Restraints" and old in entry:
            entry[entry.index(old)] = new
    restraints = project.data.get("Restraints", {})
    if old in restraints:
        restraints[new] = restraints.pop(old)
    for hist in project.histograms():
        reflections = hist.data.get("Reflection Lists", {})
        if old in reflections:
            reflections[new] = reflections.pop(old)


def clean_flags(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"][1] = True
    for key in ("Transparency", "SurfRoughA", "SurfRoughB", "Absorption", "DisplaceX", "DisplaceY"):
        if key in sample and isinstance(sample[key], list):
            sample[key][1] = False

    inst = hist.data["Instrument Parameters"][0]
    fixed = {
        "U": 5.0,
        "V": 0.0,
        "W": 4.0,
        "X": 0.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "I(L2)/I(L1)": 0.5,
        "Polariz.": 0.9968891912242098,
        "Zero": 0.0,
    }
    for key, value in fixed.items():
        inst[key][0] = inst[key][1] = value
        inst[key][2] = False

    hist.data["Background"][0][0] = "chebyschev-1"
    hist.data["Background"][0][1] = True
    # L/G size-mixing values were selected in one-at-a-time profile trials and
    # are fixed for the final replay because refining them together with size
    # magnitudes produced >97% covariance without a meaningful fit gain.
    fixed_size_mix = {
        0: 0.7519596314732895,
        1: 0.3862675589676817,
        2: 0.9008231772984293,
        3: 0.5,
    }
    for index, phase in enumerate(project.phases()):
        phase.set_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
        hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]
        hap["Size"][1][2] = fixed_size_mix[index]
        if index in (0, 1):
            hap["Size"][0] = "isotropic"
            hap["Size"][2][:] = [True, False, False]
            hap["Size"][5][:] = [False] * len(hap["Size"][5])
        elif index == 2:
            hap["Size"][0] = "uniaxial"
            hap["Size"][3] = [0, 0, 1]
            hap["Size"][2][:] = [True, True, False]
            hap["Size"][5][:] = [False] * len(hap["Size"][5])
        else:
            hap["Size"][0] = "isotropic"
            hap["Size"][2][:] = [True, False, False]
            hap["Size"][5][:] = [False] * len(hap["Size"][5])


def replay() -> G2sc.G2Project:
    project = G2sc.G2Project(gpxfile=str(SOURCE_GPX), newgpx=str(FINAL_GPX))
    for info in PHASE_INFO:
        rename_phase(project, info["old"], info["name"])
    project.update_ids()
    clean_flags(project)
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 30
    controls["min dM/M"] = 1e-8
    controls["Author"] = "Codex PXRD phase analysis"
    controls["parmFrozen"] = {}
    project.save()

    # Required save/reopen/replay over the full measured range.
    project = G2sc.G2Project(gpxfile=str(FINAL_GPX))
    project.do_refinements([{}])
    project.save()
    project = G2sc.G2Project(gpxfile=str(FINAL_GPX))
    project.do_refinements([{}])
    project.save()
    return G2sc.G2Project(gpxfile=str(FINAL_GPX))


def export_outputs(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    mass_fractions = hist.ComputeMassFracs()
    xy = [np.asarray(values) for values in hist.data["data"][1]]
    x, observed, weights, calculated, background, difference = xy
    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "difference", "background"]
        )
        writer.writerows(zip(x, observed, calculated, difference, background))

    phases_json = []
    for info, phase in zip(PHASE_INFO, project.phases()):
        cif_path = ROOT / info["cif"]
        phase.export_CIF(str(cif_path))
        fraction, fraction_esd = mass_fractions[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        phases_json.append(
            {
                "name": info["name"],
                "formula": info["formula"],
                "space_group": info["space_group"],
                "source_cod_id": info["source_cod_id"],
                "cif_path": info["cif"],
                "weight_fraction": float(fraction),
                "weight_fraction_esd_formal": float(fraction_esd),
                "cell": {key: float(value) for key, value in cell.items()},
                "cell_esd": {key: float(value) for key, value in cell_esd.items()},
            }
        )

    hist_stats = hist.data["data"][0]
    covariance = project.data["Covariance"]["data"]
    rvals = covariance.get("Rvals", {})
    fit_stats = {
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": float(hist_stats.get("R", rvals.get("R", float("nan")))),
        "goodness_of_fit": float(rvals.get("GOF", float("nan"))),
        "chi_square": float(covariance.get("Rvals", {}).get("chisq", covariance.get("chisq", float("nan")))),
        "n_observations": int(len(x)),
        "n_refined_parameters": int(len(covariance.get("varyList", []))),
        "weighting": "sigma = sqrt(max(counts,1)); pointwise uncertainties were not supplied",
    }
    result = {
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over modeled crystalline phases",
        "phases": phases_json,
        "fit_statistics": fit_stats,
    }
    with (ROOT / "result.json").open("w") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")
    return result


def verify(project: G2sc.G2Project, result: dict) -> None:
    hist = project.histogram(0)
    fractions = [entry["weight_fraction"] for entry in result["phases"]]
    if not np.isclose(sum(fractions), 1.0, atol=1e-10):
        raise RuntimeError(f"phase fractions sum to {sum(fractions)}")
    if not np.isclose(result["fit_statistics"]["Rwp_percent"], hist.get_wR(), atol=1e-10):
        raise RuntimeError("result.json Rwp does not match final.gpx")
    fit = np.loadtxt(ROOT / "fit.csv", delimiter=",", skiprows=1)
    source = hist.data["data"][1]
    if fit.shape != (len(source[0]), 5):
        raise RuntimeError("fit.csv shape mismatch")
    if not np.allclose(fit[:, 0], source[0]) or not np.allclose(fit[:, 1], source[1]):
        raise RuntimeError("fit.csv observed data mismatch")
    if not np.allclose(fit[:, 2], source[3]) or not np.allclose(fit[:, 3], source[5]):
        raise RuntimeError("fit.csv calculated/difference mismatch")
    if not np.allclose(fit[:, 4], source[4]):
        raise RuntimeError("fit.csv background mismatch")
    for entry in result["phases"]:
        if not (ROOT / entry["cif_path"]).is_file():
            raise RuntimeError(f"missing CIF {entry['cif_path']}")


def main() -> None:
    project = replay()
    result = export_outputs(project)
    verify(project, result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
