#!/usr/bin/env python3
"""Create an ordered isovalent substitution analogue from a CIF parent."""

from __future__ import annotations

import argparse
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("old_element")
    parser.add_argument("new_element")
    parser.add_argument("--symprec", type=float, default=0.01)
    parser.add_argument("--linear-scale", type=float, default=1.0)
    args = parser.parse_args()
    structure = Structure.from_file(args.source)
    structure.replace_species({args.old_element: args.new_element})
    if args.linear_scale != 1.0:
        structure.scale_lattice(structure.volume * args.linear_scale**3)
    writer = CifWriter(structure, symprec=args.symprec, refine_struct=True)
    writer.write_file(args.output)
    print(args.output, structure.composition.reduced_formula, structure.get_space_group_info())


if __name__ == "__main__":
    main()
