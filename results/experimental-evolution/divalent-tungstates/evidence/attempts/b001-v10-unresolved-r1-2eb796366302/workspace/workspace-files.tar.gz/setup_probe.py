#!/usr/bin/env python3
from pathlib import Path
import csv
import math

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
data = ROOT / "pattern.xye"
with (ROOT / "inputs" / "pattern.csv").open(newline="") as src, data.open("w") as dst:
    rows = csv.DictReader(src)
    for row in rows:
        x = float(row["two_theta_deg"])
        y = float(row["intensity"])
        dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")

gpx = G2sc.G2Project(newgpx=str(ROOT / "probe.gpx"))
hist = gpx.add_powder_histogram(str(data), str(ROOT / "instrument.instprm"), fmthint="xye")
cif = Path("<RUN>/resources/b001-c05/cif/7/21/92/7219229.cif")
phase = gpx.add_phase(str(cif), phasename="CaWO4_7219229", histograms=[hist], fmthint="CIF")
gpx.save()
print("HIST", hist.name)
print("INST", hist.data["Instrument Parameters"])
print("SAMPLE", hist.data["Sample Parameters"])
print("BKG", hist.data["Background"])
print("HAP", phase.data["Histograms"][hist.name])
print("PHASE CELL", phase.data["General"]["Cell"])
print("ATOMS", phase.data["Atoms"])
