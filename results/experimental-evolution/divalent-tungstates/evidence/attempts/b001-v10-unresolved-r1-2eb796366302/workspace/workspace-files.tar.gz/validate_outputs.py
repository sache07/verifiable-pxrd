#!/usr/bin/env python3
"""Check that all submitted numeric files agree with the reopened project."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main() -> None:
    result = json.loads((ROOT / "result.json").read_text())
    assert result["project_path"] == "final.gpx"
    assert result["profile_path"] == "fit.csv"
    assert isinstance(result["phases"], list) and len(result["phases"]) == 3
    fractions = [row["weight_fraction"] for row in result["phases"]]
    assert all(isinstance(value, (int, float)) and np.isfinite(value) for value in fractions)
    assert abs(sum(fractions) - 1.0) < 1e-12
    for row in result["phases"]:
        assert (ROOT / row["cif_path"]).is_file()

    project = G2sc.G2Project(str(ROOT / result["project_path"]))
    hist = project.histogram(0)
    mass = hist.ComputeMassFracs()
    name_map = {"CaWO4": "CaWO4", "WO3": "WO3_2311041", "Ca3WO6": "Ca3WO6_Os"}
    for row in result["phases"]:
        assert abs(row["weight_fraction"] - float(mass[name_map[row["name"]]][0])) < 1e-12

    with (ROOT / "fit.csv").open(newline="") as stream:
        rows = list(csv.DictReader(stream))
    x = np.asarray(hist.getdata("X"), dtype=float)
    obs = np.asarray(hist.getdata("Yobs"), dtype=float)
    calc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    bkg = np.asarray(hist.getdata("Background"), dtype=float)
    columns = {
        "two_theta_deg": x,
        "observed": obs,
        "calculated": calc,
        "difference": obs - calc,
        "background": bkg,
    }
    assert len(rows) == len(x)
    for key, expected in columns.items():
        actual = np.asarray([float(row[key]) for row in rows])
        assert np.max(np.abs(actual - expected)) < 1e-9

    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "X", "Y", "Z"):
        if key in inst:
            assert inst[key][1] == 0.0 and inst[key][2] is False
    assert inst["W"][1] >= 0 and inst["W"][2] is True
    assert inst["Polariz."][2] is True
    sample = hist.data["Sample Parameters"]
    assert sample["Scale"] == [1.0, False]
    assert sample["Shift"][1] is True
    assert sample["SurfRoughA"] == [0.0, False]
    assert sample["SurfRoughB"][1] is True

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if phase.name == "CaWO4":
            assert hap["Size"][0] == "uniaxial" and hap["Size"][2][:2] == [True, True]
            assert hap["Pref.Ori."][2] is True and hap["Pref.Ori."][3] == [1, 1, 0]
        else:
            assert hap["Size"][1][0] >= 10.0 and not any(hap["Size"][2])
            assert hap["Pref.Ori."][1] == 1.0 and hap["Pref.Ori."][2] is False
        assert hap["Mustrain"][1][0] == 0.0 and not any(hap["Mustrain"][2])

    print(
        json.dumps(
            {
                "status": "pass",
                "fraction_sum": sum(fractions),
                "profile_points": len(rows),
                "full_range_deg_2theta": [float(x[0]), float(x[-1])],
                "project": str(ROOT / result["project_path"]),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
