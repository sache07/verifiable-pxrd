#!/usr/bin/env python3
"""Build matched-nuisance GSAS-II trial projects for structural source records."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def prepare_pattern() -> Path:
    output = ROOT / "pattern.xye"
    with (ROOT / "inputs" / "pattern.csv").open(newline="") as source, output.open("w") as target:
        for row in csv.DictReader(source):
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            target.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    return output


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    row = {
        "label": label,
        "Rwp": hist.data["data"][0].get("wR"),
        "Rp": hist.data["data"][0].get("R"),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "Shift": sample["Shift"][0],
        "Zero": inst["Zero"][1],
        "U": inst["U"][1],
        "V": inst["V"][1],
        "W": inst["W"][1],
        "X": inst["X"][1],
        "Y": inst["Y"][1],
        "SH/L": inst["SH/L"][1],
        "background": list(hist.data["Background"][0]),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        row["phases"][phase.name] = {
            "scale": hap["Scale"][0],
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    try:
        row["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        row["mass_fraction_error"] = str(exc)
    print("SNAPSHOT", json.dumps(row, default=float, sort_keys=True))
    return row


def run_refine(project: G2sc.G2Project, label: str) -> dict:
    project.refine(makeBack=False)
    project.save()
    return snapshot(project, label)


def build(output: Path, cifs: list[Path], names: list[str], physical: bool = False) -> list[dict]:
    pattern = prepare_pattern()
    project = G2sc.G2Project(newgpx=str(output))
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.add_powder_histogram(
        str(pattern), str(ROOT / "instrument.instprm"), fmthint="xye"
    )
    phases = [
        project.add_phase(str(cif), phasename=name, histograms=[hist], fmthint="CIF")
        for cif, name in zip(cifs, names)
    ]

    # Fix the redundant histogram scale and refine independent HAP scales.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [330.0 if physical else 0.14, False]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["DisplaceX"] = [0.0, False]
    hist.data["Sample Parameters"]["DisplaceY"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.data["Background"][0] = [
        "chebyschev-1", True, 6, 1700.0, -900.0, 450.0, -200.0, 80.0, -30.0
    ]
    for phase_index, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
        if physical and phase_index == 0:
            hap["Size"][1][0] = 0.075
            hap["Size"][2][0] = True

    if physical:
        inst = hist.data["Instrument Parameters"][0]
        inst["U"][1:3] = [0.0, False]
        inst["W"][1:3] = [40.0, False]
        inst["X"][1:3] = [0.0, False]

    project.save()
    results = []
    results.append(run_refine(project, "background_scales"))

    # One physically appropriate angular correction for reflection geometry.
    hist.data["Sample Parameters"]["Shift"][1] = True
    results.append(run_refine(project, "sample_shift"))

    for phase in phases:
        phase.data["General"]["Cell"][0] = True
    results.append(run_refine(project, "cells"))

    # Low-dimensional, nonnegative starting instrumental baseline; V/Y/Z stay neutral.
    inst = hist.data["Instrument Parameters"][0]
    inst["W"][2] = True
    results.append(run_refine(project, "profile_W"))
    if not physical:
        inst["X"][2] = True
        results.append(run_refine(project, "profile_WX"))

    # Reconverge all active baseline parameters.
    results.append(run_refine(project, "replay"))
    project.save()
    return results


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("cifs", type=Path, nargs="+")
    parser.add_argument("--names", nargs="+")
    parser.add_argument("--physical", action="store_true")
    args = parser.parse_args()
    names = args.names or [cif.stem for cif in args.cifs]
    if len(names) != len(args.cifs):
        parser.error("--names must match the number of CIF paths")
    results = build(
        args.output.resolve(), [p.resolve() for p in args.cifs], names, args.physical
    )
    args.output.with_suffix(".json").write_text(json.dumps(results, indent=2, default=float))


if __name__ == "__main__":
    main()
