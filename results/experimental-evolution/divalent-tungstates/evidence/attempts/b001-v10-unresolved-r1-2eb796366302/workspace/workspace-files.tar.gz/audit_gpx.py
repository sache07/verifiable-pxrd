#!/usr/bin/env python3
"""Print profile/residual evidence from a GSAS-II project."""

from __future__ import annotations

import argparse
import json

import numpy as np
from scipy.signal import find_peaks, peak_widths

from GSASII import GSASIIscriptable as G2sc


def crossings(x: np.ndarray, y: np.ndarray, index: int, level: float) -> tuple[float, float]:
    left = index
    while left > 0 and y[left] > level:
        left -= 1
    right = index
    while right < len(y) - 1 and y[right] > level:
        right += 1
    if left == index or right == index:
        return float("nan"), float("nan")
    xl = x[left] + (level - y[left]) * (x[left + 1] - x[left]) / (y[left + 1] - y[left])
    xr = x[right - 1] + (level - y[right - 1]) * (x[right] - x[right - 1]) / (y[right] - y[right - 1])
    return float(xl), float(xr)


def nearest_peak(x: np.ndarray, signal: np.ndarray, target: float, window: float = 0.45) -> int:
    lo, hi = np.searchsorted(x, [target - window, target + window])
    return int(lo + np.argmax(signal[lo:hi]))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("--targets", nargs="*", type=float, default=[])
    args = parser.parse_args()
    project = G2sc.G2Project(args.project)
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("X"), dtype=float)
    obs = np.asarray(hist.getdata("Yobs"), dtype=float)
    calc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    bkg = np.asarray(hist.getdata("Background"), dtype=float)
    diff = obs - calc
    onet = obs - bkg
    cnet = calc - bkg

    print("PROFILE_AUDIT")
    for target in args.targets:
        io = nearest_peak(x, onet, target)
        ic = nearest_peak(x, cnet, target)
        lob, rob = crossings(x, onet, io, 0.5 * onet[io])
        lca, rca = crossings(x, cnet, ic, 0.5 * cnet[ic])
        print(json.dumps({
            "target": target,
            "obs_pos": float(x[io]), "calc_pos": float(x[ic]),
            "obs_height": float(onet[io]), "calc_height": float(cnet[ic]),
            "obs_left_hwhm": float(x[io] - lob), "obs_right_hwhm": float(rob - x[io]),
            "calc_left_hwhm": float(x[ic] - lca), "calc_right_hwhm": float(rca - x[ic]),
            "obs_fwhm": float(rob - lob), "calc_fwhm": float(rca - lca),
        }, sort_keys=True))

    # Coherent positive residual families after modest smoothing.
    smooth = np.convolve(diff, np.ones(5) / 5.0, mode="same")
    peaks, props = find_peaks(smooth, prominence=80.0, width=3, distance=8)
    widths = peak_widths(smooth, peaks, rel_height=0.5)[0] * float(np.median(np.diff(x)))
    order = np.argsort(props["prominences"])[::-1]
    print("POSITIVE_RESIDUALS")
    for rank in order[:80]:
        i = peaks[rank]
        print(f"{x[i]:9.4f} diff={diff[i]:9.1f} smooth={smooth[i]:9.1f} "
              f"prom={props['prominences'][rank]:9.1f} width={widths[rank]:.4f}")

    print("PHASE_REFLECTIONS")
    for name, refs in hist.reflections().items():
        arr = np.asarray(refs["RefList"])
        # CW reflection columns: h,k,l,mult,d,pos,...,Fcalc^2,...
        rows = sorted(arr.tolist(), key=lambda row: row[5])
        print(name, "count", len(rows))
        print(" ".join(f"{row[5]:.4f}" for row in rows[:120]))


if __name__ == "__main__":
    main()
