#!/usr/bin/env python3
"""Compare pointwise profile evidence from two GSAS-II projects."""

from __future__ import annotations

import argparse
import json

import numpy as np
from scipy.ndimage import uniform_filter1d

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("reference")
    parser.add_argument("competitor")
    args = parser.parse_args()
    projects = [G2sc.G2Project(args.reference), G2sc.G2Project(args.competitor)]
    hists = [project.histogram(0) for project in projects]
    x = np.asarray(hists[0].getdata("X"), dtype=float)
    obs = np.asarray(hists[0].getdata("Yobs"), dtype=float)
    weight = np.asarray(hists[0].getdata("Yweight"), dtype=float)
    calc = [np.asarray(hist.getdata("Ycalc"), dtype=float) for hist in hists]
    chi = [(obs - model) ** 2 * weight for model in calc]
    delta = chi[0] - chi[1]  # positive means competitor is better
    step = float(np.median(np.diff(x)))
    width_points = max(3, round(0.30 / step))
    local = uniform_filter1d(delta, width_points) * width_points
    order = np.argsort(np.abs(local))[::-1]
    selected = []
    for index in order:
        if any(abs(x[index] - old) < 0.35 for old in selected):
            continue
        selected.append(float(x[index]))
        if len(selected) == 30:
            break
    print(json.dumps({
        "reference": args.reference,
        "competitor": args.competitor,
        "chi2_reference": float(np.sum(chi[0])),
        "chi2_competitor": float(np.sum(chi[1])),
        "delta_chi2_positive_competitor_better": float(np.sum(delta)),
    }, indent=2))
    for pos in selected:
        i = int(np.argmin(np.abs(x - pos)))
        print(f"{x[i]:9.4f} local_delta_chi2={local[i]:+12.3f} "
              f"obs={obs[i]:9.1f} calc_ref={calc[0][i]:9.1f} calc_cmp={calc[1][i]:9.1f}")


if __name__ == "__main__":
    main()
