#!/usr/bin/env python3
"""Replay one targeted GSAS-II model challenge from a saved baseline."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from compare_sources import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "mode",
        choices=[
            "size", "size_X0", "uniaxial_size", "strain", "U", "U0", "SHL",
            "polarization", "polarization_fixed", "roughness", "roughness_B",
            "roughness_zero", "texture", "full_nuisance"
            , "texture_none"
        ],
    )
    parser.add_argument("--phase", type=int, default=0)
    parser.add_argument("--axis", type=int, nargs=3, default=[0, 0, 1])
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
    project.data["Controls"]["data"]["max cyc"] = 12
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]

    snapshot(project, "restored_baseline")
    if args.mode in ("size", "size_X0"):
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [0.10 if args.mode == "size_X0" else 1.0, 10.0, 1.0]
        hap["Size"][2] = [True, False, False]
        if args.mode == "size_X0":
            inst = hist.data["Instrument Parameters"][0]
            inst["X"][1] = 0.0
            inst["X"][2] = False
    elif args.mode == "uniaxial_size":
        current = float(hap["Size"][1][0])
        hap["Size"][0] = "uniaxial"
        hap["Size"][1] = [current, current, 1.0]
        hap["Size"][2] = [True, True, False]
        hap["Size"][3] = list(args.axis)
    elif args.mode == "strain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [200.0, 0.0, 1.0]
        hap["Mustrain"][2] = [True, False, False]
    elif args.mode == "U":
        inst = hist.data["Instrument Parameters"][0]
        inst["U"][1] = 10.0
        inst["U"][2] = True
    elif args.mode == "U0":
        inst = hist.data["Instrument Parameters"][0]
        inst["U"][1] = 0.0
        inst["U"][2] = False
    elif args.mode == "SHL":
        inst = hist.data["Instrument Parameters"][0]
        inst["SH/L"][1] = 0.002
        inst["SH/L"][2] = True
    elif args.mode == "polarization":
        inst = hist.data["Instrument Parameters"][0]
        inst["Polariz."][1] = 0.5
        inst["Polariz."][2] = True
    elif args.mode == "polarization_fixed":
        inst = hist.data["Instrument Parameters"][0]
        inst["Polariz."][1] = 0.5
        inst["Polariz."][2] = False
    elif args.mode == "roughness":
        hist.data["Sample Parameters"]["SurfRoughA"] = [0.5, True]
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.01, True]
    elif args.mode == "roughness_B":
        hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.10, True]
    elif args.mode == "roughness_zero":
        hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    elif args.mode == "texture":
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(args.axis)
    elif args.mode == "texture_none":
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    elif args.mode == "full_nuisance":
        # Matched leading physical nuisance model used for source re-challenges.
        hap["Size"][0] = "uniaxial"
        hap["Size"][1] = [0.066, 0.137, 1.0]
        hap["Size"][2] = [True, True, False]
        hap["Size"][3] = [0, 0, 1]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.29
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = [1, 1, 0]
        hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.03, True]
        inst = hist.data["Instrument Parameters"][0]
        inst["Polariz."][1] = 0.72
        inst["Polariz."][2] = True

    project.save()
    project.refine(makeBack=False)
    project.save()
    snapshot(project, f"{args.mode}_challenge")
    project.refine(makeBack=False)
    project.save()
    snapshot(project, f"{args.mode}_replay")


if __name__ == "__main__":
    main()
