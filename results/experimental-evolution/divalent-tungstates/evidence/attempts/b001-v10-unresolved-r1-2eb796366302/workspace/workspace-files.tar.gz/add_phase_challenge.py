#!/usr/bin/env python3
"""Add a watch-list phase to a saved GSAS-II model, scale-first then cell."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from compare_sources import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("cif", type=Path)
    parser.add_argument("name")
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
    project.data["Controls"]["data"]["max cyc"] = 12
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.histogram(0)
    phase = project.add_phase(
        str(args.cif.resolve()), phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.2, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
    phase.data["General"]["Cell"][0] = False

    project.save()
    snapshot(project, "phase_added_neutral")
    project.refine(makeBack=False)
    project.save()
    snapshot(project, "scale_fixed_cell")

    # A collapsed fixed-cell scale rejects this source record; do not let a
    # meaningless cell branch move after its intensity contribution vanishes.
    if float(hap["Scale"][0]) <= 1e-8:
        phase.data["General"]["Cell"][0] = False
        project.save()
        return

    phase.data["General"]["Cell"][0] = True
    project.refine(makeBack=False)
    project.save()
    snapshot(project, "cell_released")
    project.refine(makeBack=False)
    project.save()
    snapshot(project, "replay")


if __name__ == "__main__":
    main()
