#!/usr/bin/env python3
"""Replay the selected GSAS-II model and write synchronized deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "add_Ca3WO6_Os.gpx"
FINAL = ROOT / "final.gpx"


PHASE_OUTPUTS = {
    "CaWO4": ("CaWO4", "CaWO4", ROOT / "CaWO4.cif"),
    "WO3_2311041": ("WO3", "WO3", ROOT / "WO3.cif"),
    "Ca3WO6_Os": ("Ca3WO6", "Ca3WO6", ROOT / "Ca3WO6.cif"),
}


def enforce_selected_model(project: G2sc.G2Project) -> None:
    """Make all selected and neutral terms explicit before final replay."""
    project.data["Controls"]["data"]["max cyc"] = 12
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("X"), dtype=float)
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]

    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"][1] = True
    sample["Transparency"] = [0.0, False]
    sample["DisplaceX"] = [0.0, False]
    sample["DisplaceY"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"][1] = True

    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "X", "Y", "Z"):
        if key in inst:
            inst[key][1] = 0.0
            inst[key][2] = False
    inst["W"][2] = True
    inst["SH/L"][1] = 0.002
    inst["SH/L"][2] = False
    inst["Zero"][1] = 0.0
    inst["Zero"][2] = False
    inst["Polariz."][2] = True

    background = hist.data["Background"][0]
    background[0] = "chebyschev-1"
    background[1] = True
    background[2] = 6

    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]

        if phase.name == "CaWO4":
            equatorial, axial = map(float, hap["Size"][1][:2])
            hap["Size"][0] = "uniaxial"
            hap["Size"][1] = [equatorial, axial, 1.0]
            hap["Size"][2] = [True, True, False]
            hap["Size"][3] = [0, 0, 1]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [1, 1, 0]
        else:
            hap["Size"][0] = "isotropic"
            hap["Size"][1] = [10.0, 10.0, 1.0]
            hap["Size"][2] = [False, False, False]
            hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]


def replay() -> G2sc.G2Project:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    enforce_selected_model(project)
    project.save()
    project.refine(makeBack=False)
    project.save()

    # The submitted state is produced after reopening and replaying the full range.
    project = G2sc.G2Project(str(FINAL))
    enforce_selected_model(project)
    project.refine(makeBack=False)
    project.save()
    return G2sc.G2Project(str(FINAL))


def main() -> None:
    project = replay()
    hist = project.histogram(0)
    mass = hist.ComputeMassFracs()
    fraction_sum = sum(float(row[0]) for row in mass.values())
    if not np.isfinite(fraction_sum) or abs(fraction_sum - 1.0) > 1e-8:
        raise RuntimeError(f"invalid mass-fraction sum: {fraction_sum}")

    phase_rows = []
    hist_stats = hist.data["data"][0]
    for index, phase in enumerate(project.phases()):
        if phase.name not in PHASE_OUTPUTS:
            raise RuntimeError(f"unexpected retained phase: {phase.name}")
        public_name, formula, cif_path = PHASE_OUTPUTS[phase.name]
        phase.export_CIF(str(cif_path))
        fraction, esd = mass[phase.name]
        phase_rows.append(
            {
                "name": public_name,
                "formula": formula,
                "cif_path": cif_path.name,
                "weight_fraction": float(fraction),
                "weight_fraction_esd": float(esd),
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cell": {key: float(value) for key, value in phase.get_cell().items()},
                "fit_statistics": {
                    "Rf_percent": float(hist_stats.get(f"{index}:0:Rf", np.nan)),
                    "Rf2_percent": float(hist_stats.get(f"{index}:0:Rf^2", np.nan)),
                },
            }
        )

    x = np.asarray(hist.getdata("X"), dtype=float)
    obs = np.asarray(hist.getdata("Yobs"), dtype=float)
    calc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    bkg = np.asarray(hist.getdata("Background"), dtype=float)
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "difference", "background"]
        )
        writer.writerows(zip(x, obs, calc, obs - calc, bkg))

    rvals = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": float(hist_stats["wR"]),
            "Rp_percent": float(hist_stats["R"]),
            "Rexp_percent": float(hist_stats["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
        },
        "project_path": FINAL.name,
        "profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "weight_fraction_sum": float(sum(row["weight_fraction"] for row in phase_rows)),
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
