from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
order = int(sys.argv[1])
dest = work / ".tmp" / f"shpo_{order}.gpx"
shutil.copyfile(work / ".tmp" / "size_test.gpx", dest)

G2sc.SetPrintLevel("warn")
gpx = G2sc.G2Project(str(dest))
hist = gpx.histogram(0)
phase = gpx.phase("CaWO4")
phase.HAPvalue("PO", order)
pref = phase.getHAPvalues(hist.name)["Pref.Ori."]
pref[2] = True
for _ in range(4):
    gpx.refine(makeBack=False)
gpx.save()
print(
    json.dumps(
        {
            "order": order,
            "rwp": hist.residuals["wR"],
            "rp": hist.residuals["R"],
            "ca_bragg_r": hist.residuals["0:0:Rf"],
            "wo_bragg_r": hist.residuals["1:0:Rf"],
            "coefficients": pref[5],
            "mass_fractions": hist.ComputeMassFracs(),
            "project": str(dest),
        }
    )
)
