from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
root = Path(
    "<RUN>/resources/"
    "b001-c05/cif"
)
cod_id = sys.argv[1]
dest = work / ".tmp" / f"add_{cod_id}.gpx"
shutil.copyfile(work / ".tmp" / "final_candidate_2311041.gpx", dest)

G2sc.SetPrintLevel("warn")
gpx = G2sc.G2Project(str(dest))
hist = gpx.histogram(0)
path = root / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"
phase = gpx.add_phase(
    str(path), phasename=f"test_{cod_id}", histograms=[hist], fmthint="CIF"
)
# Some historical CIFs encode mixed tungsten valences (for example W+5),
# which this GSAS-II build does not tabulate. Use neutral-element X-ray
# factors for this screening refinement; the candidate is only retained if
# it gives a clear profile improvement and can then be treated explicitly.
for atom in phase.atoms():
    atom.type = atom.element
G2sc.SetupGeneral(phase.data, None)
phase.getHAPvalues(hist.name)["Scale"] = [0.2, True]
gpx.save()
for _ in range(2):
    gpx.refine(makeBack=False)
gpx.save()
print(
    "RESULT "
    + json.dumps(
        {
            "candidate": cod_id,
            "formula": phase.data["General"].get("Name", phase.name),
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "rwp": hist.residuals["wR"],
            "bragg_r": hist.residuals.get(f"{phase.id}:0:Rf"),
            "mass_fractions": hist.ComputeMassFracs(),
            "project": str(dest),
        }
    )
)
