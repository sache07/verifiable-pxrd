from __future__ import annotations

import json
import sys
import traceback
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
CIF_ROOT = Path(
    "<RUN>/resources/"
    "b001-c05/cif"
)


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def refine_candidate(wo3_id: str) -> dict:
    out = WORK / ".tmp" / f"candidate_{wo3_id}.gpx"
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(WORK / "inputs" / "pattern.csv"),
        str(WORK / ".tmp" / "instrument.instprm"),
        fmthint="comma",
    )
    phases = [
        gpx.add_phase(
            str(cif_path("7219229")),
            phasename="CaWO4",
            histograms=[hist],
            fmthint="CIF",
        ),
        gpx.add_phase(
            str(cif_path(wo3_id)),
            phasename="WO3",
            histograms=[hist],
            fmthint="CIF",
        ),
    ]

    # Establish stable starting values before the staged refinements.
    hist.SampleParameters["Scale"][1] = False
    hist.InstrumentParameters["Zero"][1] = -0.16
    hist.Background[0][:] = [
        "chebyschev-1",
        True,
        12,
        1500.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
    ]
    for phase, scale in zip(phases, [35.0, 4.0]):
        phase.data["Histograms"][hist.name]["Scale"] = [scale, True]

    gpx.save()
    gpx.refine(makeBack=False)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    gpx.refine(makeBack=False)
    for phase in phases:
        phase.set_refinements({"Cell": True})
    gpx.refine(makeBack=False)
    hist.set_refinements({"Instrument Parameters": ["W", "X", "Y"]})
    gpx.refine(makeBack=False)
    # A final cycle is useful because the scriptable interface defaults to
    # only three LM cycles per call.
    gpx.refine(makeBack=False)
    gpx.save()

    return {
        "candidate": wo3_id,
        "space_group": phases[1].data["General"]["SGData"]["SpGrp"],
        "rwp": hist.residuals.get("wR"),
        "rp": hist.residuals.get("R"),
        "gof": hist.residuals.get("wR") / hist.residuals.get("wRmin"),
        "zero": hist.InstrumentParameters["Zero"][1],
        "profile": {
            key: hist.InstrumentParameters[key][1]
            for key in ("U", "V", "W", "X", "Y")
        },
        "phases": [
            {
                "name": phase.name,
                "scale": phase.getHAPvalues(hist.name)["Scale"][0],
                "cell": phase.get_cell(),
                "bragg_r": hist.residuals.get(f"{phase.id}:0:Rf"),
            }
            for phase in phases
        ],
        "project": str(out),
    }


def main(ids: list[str]) -> None:
    G2sc.SetPrintLevel("warn")
    results = []
    for cod_id in ids:
        try:
            result = refine_candidate(cod_id)
            print(json.dumps(result), flush=True)
            results.append(result)
        except Exception as exc:
            result = {
                "candidate": cod_id,
                "error": f"{type(exc).__name__}: {exc}",
                "traceback": traceback.format_exc(),
            }
            print(json.dumps(result), flush=True)
            results.append(result)
    (WORK / ".tmp" / "candidate_results.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )


if __name__ == "__main__":
    main(sys.argv[1:])
