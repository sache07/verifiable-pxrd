from __future__ import annotations

import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
project = G2sc.G2Project(str(work / "final.gpx"))
hist = project.histogram(0)

cif_names = {
    "CaWO4": "CaWO4.cif",
    "WO3": "WO3.cif",
    "CaO": "CaO.cif",
}
reference_ids = {
    "CaWO4": "COD 7219229",
    "WO3": "COD 2311041",
    "CaO": "COD 1563196",
}
formulae = {
    "CaWO4": "CaWO4",
    "WO3": "WO3",
    "CaO": "CaO",
}

for phase in project.phases():
    phase.export_CIF(str(work / cif_names[phase.name]))

x = hist.getdata("x")
y_obs = hist.getdata("yobs")
y_calc = hist.getdata("ycalc")
y_bkg = hist.getdata("background")
y_diff = y_obs - y_calc
with (work / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(
        [
            "two_theta_deg",
            "observed_intensity",
            "calculated_intensity",
            "difference_observed_minus_calculated",
            "calculated_background",
        ]
    )
    for row in zip(x, y_obs, y_calc, y_diff, y_bkg):
        writer.writerow(
            [
                f"{float(row[0]):.8f}",
                f"{float(row[1]):.6f}",
                f"{float(row[2]):.6f}",
                f"{float(row[3]):.6f}",
                f"{float(row[4]):.6f}",
            ]
        )

mass_fractions = hist.ComputeMassFracs()
residuals = hist.residuals
phases = []
for phase in project.phases():
    fraction, fraction_esd = mass_fractions[phase.name]
    cell, cell_esd = phase.get_cell_and_esd()
    phases.append(
        {
            "name": phase.name,
            "formula": formulae[phase.name],
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "cif_path": cif_names[phase.name],
            "structural_reference": reference_ids[phase.name],
            "weight_fraction": fraction,
            "weight_fraction_formal_esd": fraction_esd,
            "bragg_r_percent": residuals[f"{phase.id}:0:Rf"],
            "unit_cell": cell,
            "unit_cell_formal_esd": cell_esd,
        }
    )

covariance_rvals = project.data["Covariance"]["data"]["Rvals"]
gof = covariance_rvals["GOF"]
r_exp = residuals["wR"] / gof
result = {
    "phases": phases,
    "weight_fraction_basis": (
        "Normalized to 1.0 over the three modeled crystalline phases; "
        "no amorphous or unidentified fraction is quantified."
    ),
    "fit_statistics": {
        "r_wp_percent": residuals["wR"],
        "r_p_percent": residuals["R"],
        "r_exp_percent": r_exp,
        "r_wp_minimum_percent": residuals["wRmin"],
        "goodness_of_fit": gof,
        "reduced_chi_squared": gof**2,
        "chi_squared": covariance_rvals["chisq"],
        "r_wp_background_percent": residuals["wRb"],
        "r_p_background_percent": residuals["Rb"],
        "number_of_profile_points": len(x),
        "number_of_refined_parameters": len(
            project.data["Covariance"]["data"]["varyList"]
        ),
        "degrees_of_freedom": (
            covariance_rvals["Nobs"] - covariance_rvals["Nvars"]
        ),
        "weighting": (
            "Poisson counting weights (1/I) assigned by the GSAS-II CSV "
            "importer because pointwise uncertainties were not supplied."
        ),
    },
    "profile_path": "fit.csv",
    "gsas_project_path": "final.gpx",
    "input_pattern_path": "inputs/pattern.csv",
}
with (work / "result.json").open("w") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

print(json.dumps(result, indent=2))
