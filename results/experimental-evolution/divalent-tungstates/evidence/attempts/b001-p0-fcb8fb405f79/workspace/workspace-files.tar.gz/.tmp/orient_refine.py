from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
hkl = [int(v) for v in sys.argv[1:4]]
tag = "".join(str(v).replace("-", "m") for v in hkl)
dest = work / ".tmp" / f"orient_{tag}.gpx"
shutil.copyfile(work / ".tmp" / "size_test.gpx", dest)

G2sc.SetPrintLevel("warn")
gpx = G2sc.G2Project(str(dest))
hist = gpx.histogram(0)
phase = gpx.phase("CaWO4")
pref = phase.getHAPvalues(hist.name)["Pref.Ori."]
pref[0] = "MD"
pref[1] = 1.0
pref[2] = True
pref[3] = hkl
for _ in range(3):
    gpx.refine(makeBack=False)
gpx.save()
print(
    json.dumps(
        {
            "hkl": hkl,
            "rwp": hist.residuals["wR"],
            "rp": hist.residuals["R"],
            "ca_bragg_r": hist.residuals["0:0:Rf"],
            "wo_bragg_r": hist.residuals["1:0:Rf"],
            "march_ratio": pref[1],
            "mass_fractions": hist.ComputeMassFracs(),
            "project": str(dest),
        }
    )
)
