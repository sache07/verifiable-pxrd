from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


work = Path(__file__).resolve().parents[1]
cif_root = Path(
    "<RUN>/resources/"
    "b001-c05/cif"
)
cod_id = sys.argv[1]
dest = work / ".tmp" / f"final_candidate_{cod_id}.gpx"
shutil.copyfile(work / ".tmp" / f"candidate_{cod_id}.gpx", dest)

G2sc.SetPrintLevel("warn")
gpx = G2sc.G2Project(str(dest))
hist = gpx.histogram(0)
ca = gpx.phase("CaWO4")
ca.set_HAP_refinements(
    {"Size": {"type": "isotropic", "value": 0.05, "refine": True}}
)
for _ in range(3):
    gpx.refine(makeBack=False)

ca.HAPvalue("PO", 4)
ca.getHAPvalues(hist.name)["Pref.Ori."][2] = True
for _ in range(3):
    gpx.refine(makeBack=False)

cao_id = "1563196"
cao_path = (
    cif_root
    / cao_id[0]
    / cao_id[1:3]
    / cao_id[3:5]
    / f"{cao_id}.cif"
)
cao = gpx.add_phase(
    str(cao_path), phasename="CaO", histograms=[hist], fmthint="CIF"
)
cao.getHAPvalues(hist.name)["Scale"] = [0.5, True]
gpx.save()
for _ in range(2):
    gpx.refine(makeBack=False)
cao.set_refinements({"Cell": True})
for _ in range(3):
    gpx.refine(makeBack=False)
gpx.save()

print(
    json.dumps(
        {
            "candidate": cod_id,
            "rwp": hist.residuals["wR"],
            "rp": hist.residuals["R"],
            "bragg_r": {
                phase.name: hist.residuals[f"{phase.id}:0:Rf"]
                for phase in gpx.phases()
            },
            "mass_fractions": hist.ComputeMassFracs(),
            "cells": {phase.name: phase.get_cell() for phase in gpx.phases()},
            "project": str(dest),
        }
    )
)
