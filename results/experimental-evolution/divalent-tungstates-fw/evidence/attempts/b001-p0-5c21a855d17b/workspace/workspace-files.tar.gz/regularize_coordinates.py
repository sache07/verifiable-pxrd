#!/usr/bin/env python3
"""Project refined coordinates into the framework's reference-mismatch bounds."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


PARENTS = {
    "CaWO4_scheelite": "7219229",
    "WO3_monoclinic": "2311041",
    "CaCO3_calcite": "1547347",
    "CaO_rocksalt": "1563196",
}


def lattice_matrix(cell: dict[str, float]) -> np.ndarray:
    a, b, c = (cell[f"length_{key}"] for key in "abc")
    alpha, beta, gamma = np.deg2rad(
        [cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]]
    )
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * np.cos(gamma), b * np.sin(gamma), 0.0])
    cx = c * np.cos(beta)
    cy = c * (np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma)
    cz = np.sqrt(max(0.0, c * c - cx * cx - cy * cy))
    return np.vstack((va, vb, [cx, cy, cz]))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--heavy-limit", type=float, default=0.04)
    parser.add_argument("--oxygen-limit", type=float, default=0.05)
    args = parser.parse_args()

    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    parent_project = G2.G2Project(newgpx=str((output.parent / "_parents.gpx").resolve()))
    report = {}

    for phase in project.phases():
        cod_id = PARENTS[phase.name]
        parent = parent_project.add_phase(
            str((Path("candidates") / f"cod_{cod_id}.cif").resolve()),
            phasename=phase.name, fmthint="CIF"
        )
        atoms = phase.atoms()
        parent_atoms = parent.atoms()
        if len(atoms) != len(parent_atoms):
            raise ValueError(f"atom count differs for {phase.name}")
        matrix = lattice_matrix(parent.get_cell())
        by_element: dict[str, list[int]] = {}
        deltas = []
        for index, (atom, reference) in enumerate(zip(atoms, parent_atoms)):
            if atom.element != reference.element:
                raise ValueError(f"atom ordering differs for {phase.name}")
            delta = np.asarray(atom.coordinates) - np.asarray(reference.coordinates)
            delta -= np.rint(delta)
            deltas.append(delta)
            by_element.setdefault(atom.element, []).append(index)
        deltas = np.asarray(deltas)
        phase_report = {}
        for element, indices in by_element.items():
            cart = deltas[indices] @ matrix
            before = float(np.sqrt(np.mean(np.sum(cart * cart, axis=1))))
            limit = args.oxygen_limit if element == "O" else args.heavy_limit
            factor = min(1.0, limit / max(before, 1e-15))
            deltas[indices] *= factor
            after_cart = deltas[indices] @ matrix
            after = float(np.sqrt(np.mean(np.sum(after_cart * after_cart, axis=1))))
            phase_report[element] = {
                "before_rms_A": before, "after_rms_A": after,
                "limit_A": limit, "scale_factor": factor,
            }
        for atom, reference, delta in zip(atoms, parent_atoms, deltas):
            atom.coordinates = tuple((np.asarray(reference.coordinates) + delta) % 1.0)
            atom.refinement_flags = ""
        report[phase.name] = phase_report
    project.save()
    output.with_suffix(".coordinates.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
