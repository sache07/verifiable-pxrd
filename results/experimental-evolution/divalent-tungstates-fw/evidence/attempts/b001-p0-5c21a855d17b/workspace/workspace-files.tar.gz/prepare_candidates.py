#!/usr/bin/env python3
"""Prepare framework-normalized CIF candidates from the frozen COD library."""

from pathlib import Path
import sys
import warnings

from pymatgen.io.cif import CifParser


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
RUNTIME = Path("learned/divalent-tungstates/runtime").resolve()
sys.path.insert(0, str(RUNTIME))
from models import write_synthetic_model  # noqa: E402


IDS = [
    # CaWO4
    "7219229", "5910088", "1546035",
    # WO3 polymorphs
    "1010618", "1528915", "2311041", "2106293", "2107312",
    "1521532", "1521533", "1563541", "1004057",
    # CaCO3 polymorphs / representative calcites
    "1547347", "1547370", "1547371", "1547372", "1547373",
    "1547374", "1547375", "1547376", "1547377", "1547378",
    "1547379", "1547380", "1508970", "2103119", "2106394",
    "9013565",
    # CaO and other plausible Ca-W-O products
    "1563196", "1563081", "4030741",
]


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    out = Path("candidates")
    out.mkdir(exist_ok=True)
    for cod_id in IDS:
        source = cod_path(cod_id)
        if not source.is_file():
            print(f"missing {cod_id}: {source}")
            continue
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                parser = CifParser(source, occupancy_tolerance=1.0,
                                   site_tolerance=1e-5, frac_tolerance=0)
                structures = parser.parse_structures(primitive=False,
                                                     on_error="raise")
            if len(structures) != 1:
                raise ValueError(f"expected one structure, got {len(structures)}")
            structure = structures[0]
            structure.remove_oxidation_states()
            destination = out / f"cod_{cod_id}.cif"
            write_synthetic_model(structure, destination)
            sg = structure.get_space_group_info()
            print(cod_id, structure.composition.reduced_formula, len(structure),
                  sg, tuple(round(v, 6) for v in structure.lattice.abc),
                  f"warnings={len(caught)}")
        except Exception as exc:
            print(f"failed {cod_id}: {type(exc).__name__}: {exc}")


if __name__ == "__main__":
    main()
