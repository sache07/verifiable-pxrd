#!/usr/bin/env python3
"""Refine one isotropic displacement parameter per selected phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist) -> float:
    arrays = hist.data["data"][1]
    y, w, calc = (np.asarray(arrays[i], float) for i in (1, 2, 3))
    return float(100.0 * np.sqrt(np.sum(w * (y - calc) ** 2) /
                                 np.sum(w * y ** 2)))


def fractions(project, hist) -> dict[str, float]:
    raw = {
        phase.name: float(phase.data["Histograms"][hist.name]["Scale"][0])
        * float(phase.data["General"]["Mass"])
        for phase in project.phases()
    }
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("phase", nargs="+")
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--repeat", type=int, default=2)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()),
                           newgpx=str(output))
    hist = project.histogram(0)

    # This helper owns the phase constraints in its output. Rebuild them on
    # every pass so alternating profile/Uiso refinements do not accumulate
    # duplicate equivalence relations.
    project.data["Constraints"]["data"]["Phase"] = []

    # Hold structural and line-profile terms. Refine scales, background,
    # polarization and one constrained AUiso value for each requested phase.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = ""
        phase.set_refinements({"Cell": False})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.InstrumentParameters["Polariz."][2] = True
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key][1] = False

    frozen = project.data["Controls"]["data"].setdefault("parmFrozen", {})
    if isinstance(frozen, dict):
        frozen["FrozenList"] = []

    selected = set(args.phase)
    unknown = selected - {phase.name for phase in project.phases()}
    if unknown:
        raise ValueError(f"unknown phase(s): {sorted(unknown)}")
    for phase in project.phases():
        if phase.name not in selected:
            continue
        atoms = list(phase.atoms())
        for atom in atoms:
            atom.refinement_flags = "U"
        variables = tuple(f"{phase.id}::AUiso:{index}"
                          for index in range(len(atoms)))
        if len(variables) > 1:
            project.add_EquivConstr(variables)
        for variable in variables:
            project.set_Controls("parmMin", 0.003, variable)
            project.set_Controls("parmMax", 0.020, variable)

    project.set_Controls("parmMin", 0.0, f":{hist.id}:Polariz.")
    project.set_Controls("parmMax", 1.0, f":{hist.id}:Polariz.")
    project.set_Controls("cycles", args.cycles)
    project.save()
    sequence = []
    for _ in range(args.repeat):
        project.refine(makeBack=False)
        sequence.append(rwp(hist))
    project.save()

    result = {
        "input": str(Path(args.input).resolve()),
        "output": str(output),
        "rwp_sequence_percent": sequence,
        "fractions": fractions(project, hist),
        "polarization": float(hist.InstrumentParameters["Polariz."][1]),
        "uiso": {
            phase.name: [float(atom.uiso) for atom in phase.atoms()]
            for phase in project.phases()
        },
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
