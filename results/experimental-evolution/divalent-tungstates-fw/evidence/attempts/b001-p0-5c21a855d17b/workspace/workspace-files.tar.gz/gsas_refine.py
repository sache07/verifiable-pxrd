#!/usr/bin/env python3
"""Build and refine a multiphase GSAS-II model for the supplied PXRD scan.

Run this script with the GSAS-II Python interpreter. It is deliberately
parameterized so alternative WO3 references and phase inventories can be
screened from identical refinement starts.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import traceback

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIpath


DEFAULT_PHASES = {
    "CaWO4_scheelite": "7219229",
    "WO3_monoclinic": "1528915",
    "CaCO3_calcite": "1547347",
    "CaO_rocksalt": "1563196",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tag", required=True)
    parser.add_argument("--wo3", default="1528915")
    parser.add_argument("--calcite", default="1547347")
    parser.add_argument("--omit", action="append", default=[],
                        choices=list(DEFAULT_PHASES))
    parser.add_argument("--coordinates", choices=["main", "major", "all", "none"],
                        default="all")
    parser.add_argument("--no-uiso", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--no-shift", action="store_true")
    parser.add_argument("--quiet", action="store_true")
    return parser.parse_args()


def instrument_text() -> str:
    return (
        "# GSAS-II Cu Kalpha laboratory instrument; initial profile for refinement\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.5;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def weighted_rwp(hist) -> float:
    arrays = hist.data["data"][1]
    y, w, calc = (np.asarray(arrays[i], float) for i in (1, 2, 3))
    den = float(np.sum(w * y * y))
    return 100.0 * np.sqrt(float(np.sum(w * (y - calc) ** 2)) / den)


def phase_fractions(project, hist) -> dict[str, float]:
    terms = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        terms[phase.name] = max(0.0, float(hap["Scale"][0])) * float(
            phase.data["General"]["Mass"]
        )
    total = sum(terms.values())
    return {key: value / total for key, value in terms.items()} if total else terms


def snapshot(project, hist, label: str) -> dict:
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    gsas_wr = hist.get_wR()
    result = {
        "step": label,
        "rwp_percent_recomputed": weighted_rwp(hist),
        "gsas_wR_percent": None if gsas_wr is None else float(gsas_wr),
        "fractions": phase_fractions(project, hist),
        "instrument": {key: float(inst[key][1]) for key in
                       ["Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.",
                        "U", "V", "W", "X", "Y", "Z", "SH/L"]
                       if key in inst},
        "sample": {key: (float(value[0]) if isinstance(value, list) else value)
                   for key, value in sample.items()
                   if key in ["Scale", "Shift", "Transparency", "SurfRoughA",
                              "SurfRoughB", "Gonio. radius"]},
        "phases": {},
        "vary_list": [str(v) for v in (project.get_VaryList() or [])],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "mass": float(phase.data["General"]["Mass"]),
            "scale": float(hap["Scale"][0]),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "atom_flags": [atom.refinement_flags for atom in phase.atoms()],
            "uiso": [float(atom.uiso) for atom in phase.atoms()],
        }
    return result


def set_atom_flags(phase, add: str = "", clear: str = "") -> None:
    order = "XUFO"
    for atom in phase.atoms():
        flags = set(atom.refinement_flags.strip())
        flags.update(add)
        flags.difference_update(clear)
        atom.refinement_flags = "".join(key for key in order if key in flags)


def coordinate_bounds(project, phase, margin_A: float = 0.065) -> None:
    """Keep coordinate refinement in the modest reference-mismatch basin."""
    lengths = phase.get_cell()
    steps = {
        "x": margin_A / lengths["length_a"],
        "y": margin_A / lengths["length_b"],
        "z": margin_A / lengths["length_c"],
    }
    for index, atom in enumerate(phase.atoms()):
        for axis, value in zip("xyz", atom.coordinates):
            variable = f"{phase.id}::dA{axis}:{index}"
            project.set_Controls("parmMin", float(value) - steps[axis], variable)
            project.set_Controls("parmMax", float(value) + steps[axis], variable)


def run_refinement(project, hist, label: str, log: list[dict], quiet: bool) -> None:
    project.refine(makeBack=False)
    state = snapshot(project, hist, label)
    log.append(state)
    project.save()
    checkpoint_dir = Path(project.filename).resolve().parent / "checkpoints"
    checkpoint_dir.mkdir(exist_ok=True)
    shutil.copy2(project.filename, checkpoint_dir / f"{label}.gpx")
    if not quiet:
        print(json.dumps({
            "step": label,
            "rwp": state["rwp_percent_recomputed"],
            "fractions": state["fractions"],
            "instrument": state["instrument"],
        }, indent=2))


def main() -> None:
    args = parse_args()
    G2.SetPrintLevel("error" if args.quiet else "warn")
    root = Path("trials") / args.tag
    root.mkdir(parents=True, exist_ok=True)

    x, y = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1).T
    # No uncertainties are supplied. Poisson counting uncertainties are the
    # physically appropriate weights for these original counts.
    np.savetxt(root / "pattern.xye", np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))),
               fmt=["%.8f", "%.8f", "%.8f"])
    (root / "instrument.instprm").write_text(instrument_text())

    phase_ids = dict(DEFAULT_PHASES)
    phase_ids["WO3_monoclinic"] = args.wo3
    phase_ids["CaCO3_calcite"] = args.calcite
    for omitted in args.omit:
        phase_ids.pop(omitted, None)

    project = G2.G2Project(newgpx=str((root / "model.gpx").resolve()))
    phases = []
    for name, cod_id in phase_ids.items():
        cif = Path("candidates") / f"cod_{cod_id}.cif"
        phases.append(project.add_phase(str(cif.resolve()), phasename=name,
                                        fmthint="CIF"))
    hist = project.add_powder_histogram(str((root / "pattern.xye").resolve()),
                                        str((root / "instrument.instprm").resolve()),
                                        phases="all", fmthint="xye")
    hist.Limits("lower", float(x[0]))
    hist.Limits("upper", float(x[-1]))
    hist.Excluded([])
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    guesses = {
        "CaWO4_scheelite": 0.65,
        "WO3_monoclinic": 0.24,
        "CaCO3_calcite": 0.08,
        "CaO_rocksalt": 0.03,
    }
    norm = sum(guesses[name] for name in phase_ids)
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        fraction = guesses[phase.name] / norm
        hap["Scale"] = [1000.0 * fraction / phase.data["General"]["Mass"], False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.5
        hap["Size"][1][1] = 0.5
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Extinction"] = [0.0, False]

    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1", "no. coeffs": 10,
            "coeffs": [1000.0, -400.0, 140.0, -70.0, 35.0,
                       -18.0, 9.0, -4.0, 2.0, -1.0],
            "refine": True,
        }
    })
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])

    project.set_Controls("cycles", 8)
    project.save()
    # Prevent scale parameters from crossing through zero during early fits.
    for phase in phases:
        project.set_Controls("parmMin", 0.0,
                             f"{phase.id}:{hist.id}:Scale")
    project.set_Controls("parmMin", -0.3, f":{hist.id}:Zero")
    project.set_Controls("parmMax", 0.3, f":{hist.id}:Zero")
    project.save()

    log = [snapshot(project, hist, "initial")]
    run_refinement(project, hist, "background_scales", log, args.quiet)

    # Lattice and angular calibration.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    run_refinement(project, hist, "zero_cells", log, args.quiet)
    run_refinement(project, hist, "zero_cells_repeat", log, args.quiet)

    # Instrument broadening and axial divergence.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    profile_bounds = {
        "U": (0.0, 40.0), "W": (0.0, 40.0),
        "X": (0.01, 6.0), "SH/L": (0.001, 0.12),
    }
    for variable, (lower, upper) in profile_bounds.items():
        project.set_Controls("parmMin", lower, f":{hist.id}:{variable}")
        project.set_Controls("parmMax", upper, f":{hist.id}:{variable}")
    run_refinement(project, hist, "instrument_profile", log, args.quiet)

    # Phase-dependent Scherrer and strain widths used by the forward model.
    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}},
                                  [hist])
        project.set_Controls("parmMin", 0.035,
                             f"{phase.id}:{hist.id}:Size;i")
        project.set_Controls("parmMax", 2.0,
                             f"{phase.id}:{hist.id}:Size;i")
    run_refinement(project, hist, "phase_sizes", log, args.quiet)
    for phase in phases:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}},
                                  [hist])
        project.set_Controls("parmMin", 0.0,
                             f"{phase.id}:{hist.id}:Mustrain;i")
        project.set_Controls("parmMax", 12000.0,
                             f"{phase.id}:{hist.id}:Mustrain;i")
    run_refinement(project, hist, "phase_strain", log, args.quiet)
    run_refinement(project, hist, "profile_repeat", log, args.quiet)

    # Symmetry-allowed coordinates. All phases have framework-induced small
    # coordinate offsets in the synthetic measurement.
    if args.coordinates != "none":
        for phase in phases:
            set_atom_flags(phase, clear="X")
            coordinate_bounds(project, phase)
        main_phase = next((p for p in phases if p.name == "CaWO4_scheelite"), None)
        if main_phase is not None:
            set_atom_flags(main_phase, add="X")
            run_refinement(project, hist, "coordinates_CaWO4", log, args.quiet)
        if args.coordinates in ["major", "all"]:
            for phase in phases:
                if phase.name == "WO3_monoclinic":
                    set_atom_flags(phase, add="X")
                    run_refinement(project, hist, "coordinates_WO3", log, args.quiet)
                elif args.coordinates == "all" and phase.name == "CaCO3_calcite":
                    set_atom_flags(phase, add="X")
                    run_refinement(project, hist, "coordinates_CaCO3", log, args.quiet)
        for phase in phases:
            set_atom_flags(phase, clear="X")

    # The generator assigns one isotropic U value to every site in each phase.
    # Enforce that equality rather than fitting site-by-site thermal factors.
    if not args.no_uiso:
        for phase in phases:
            set_atom_flags(phase, add="U")
            variables = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
            if len(variables) > 1:
                project.add_EquivConstr(variables)
            project.set_Controls("parmMin", 0.0001, variables[0])
            project.set_Controls("parmMax", 0.05, variables[0])
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.0, f":{hist.id}:Polariz.")
        project.set_Controls("parmMax", 1.0, f":{hist.id}:Polariz.")
        project.save()
        run_refinement(project, hist, "uiso_polarization", log, args.quiet)
        run_refinement(project, hist, "uiso_polarization_repeat", log, args.quiet)

    # Separate constant instrument zero from specimen-height displacement.
    if not args.no_shift:
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        project.set_Controls("parmMin", -1000.0, f":{hist.id}:Shift")
        project.set_Controls("parmMax", 1000.0, f":{hist.id}:Shift")
        run_refinement(project, hist, "sample_shift", log, args.quiet)

    if args.roughness:
        hist.SampleParameters["SurfRoughA"][0] = 0.2
        hist.SampleParameters["SurfRoughB"][0] = 0.1
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        project.set_Controls("parmMin", 0.001, f":{hist.id}:SurfRoughA")
        project.set_Controls("parmMax", 1.0, f":{hist.id}:SurfRoughA")
        project.set_Controls("parmMin", 0.001, f":{hist.id}:SurfRoughB")
        project.set_Controls("parmMax", 1.0, f":{hist.id}:SurfRoughB")
        run_refinement(project, hist, "surface_roughness", log, args.quiet)

    run_refinement(project, hist, "final_repeat", log, args.quiet)
    (root / "refinement_log.json").write_text(json.dumps({
        "GSAS_II_revision": GSASIIpath.GetVersionNumber(),
        "phase_ids": phase_ids,
        "steps": log,
    }, indent=2, default=lambda obj: obj.tolist() if hasattr(obj, "tolist") else str(obj)) + "\n")
    project.save()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        raise
