#!/usr/bin/env python3
"""Refine scale/background after omitting each phase from a saved model."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist) -> float:
    arrays = hist.data["data"][1]
    y, w, calc = (np.asarray(arrays[i], float) for i in (1, 2, 3))
    return float(100 * np.sqrt(np.sum(w * (y - calc) ** 2) /
                               np.sum(w * y ** 2)))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("output_dir")
    args = parser.parse_args()
    source = Path(args.project).resolve()
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")

    baseline = G2.G2Project(gpxfile=str(source))
    names = [phase.name for phase in baseline.phases()]
    report = {"baseline_rwp_percent": rwp(baseline.histogram(0)), "tests": {}}

    for omitted in names:
        slug = re.sub(r"[^A-Za-z0-9]+", "_", omitted).strip("_")
        target = output_dir / f"without_{slug}.gpx"
        project = G2.G2Project(gpxfile=str(source), newgpx=str(target))
        hist = project.histogram(0)
        project.data["Constraints"]["data"]["Phase"] = []
        for phase in project.phases():
            phase.set_refinements({"Cell": False})
            for atom in phase.atoms():
                atom.refinement_flags = ""
            hap = phase.data["Histograms"][hist.name]
            hap["Scale"][1] = phase.name != omitted
            hap["Use"] = phase.name != omitted
            if phase.name == omitted:
                hap["Scale"][0] = 0.0
            hap["Pref.Ori."][2] = False
            hap["Size"][2] = [False for _ in hap["Size"][2]]
            hap["Size"][5] = [False for _ in hap["Size"][5]]
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        for value in hist.InstrumentParameters.values():
            if isinstance(value, list) and len(value) > 2:
                value[2] = False
        for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
            hist.SampleParameters[key][1] = False
        frozen = project.data["Controls"]["data"].setdefault("parmFrozen", {})
        if isinstance(frozen, dict):
            frozen["FrozenList"] = []
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.refine(makeBack=False)
        project.save()
        report["tests"][omitted] = {"rwp_percent": rwp(hist),
                                     "project": str(target)}

    (output_dir / "deletion_tests.json").write_text(
        json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
