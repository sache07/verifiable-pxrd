#!/usr/bin/env python3
"""Stage, replay and export the final powder-diffraction submission."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


PHASE_META = {
    "CaWO4_scheelite": {
        "display_name": "CaWO4 (scheelite)",
        "formula": "CaWO4",
        "cif": "phase_CaWO4_scheelite.cif",
        "reference": "COD 7219229",
    },
    "WO3_monoclinic": {
        "display_name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif": "phase_WO3_monoclinic.cif",
        "reference": "COD 2311041",
    },
    "CaCO3_calcite": {
        "display_name": "CaCO3 (calcite)",
        "formula": "CaCO3",
        "cif": "phase_CaCO3_calcite.cif",
        "reference": "COD 1547347",
    },
    "CaO_rocksalt": {
        "display_name": "CaO (rocksalt)",
        "formula": "CaO",
        "cif": "phase_CaO_rocksalt.cif",
        "reference": "COD 1563196",
    },
}


def stage(root: Path, source: Path) -> None:
    final = root / "final.gpx"
    shutil.copy2(source, final)
    project = G2.G2Project(gpxfile=str(final))
    hist = project.histogram(0)
    replay_dir = root / ".tmp" / "final_replay"
    replay_dir.mkdir(parents=True, exist_ok=True)
    request = {
        "project": str(final.resolve()),
        "observed": str((root / "inputs" / "pattern.csv").resolve()),
        "histogram": hist.name,
    }
    (replay_dir / "request.json").write_text(json.dumps(request, indent=2) + "\n")
    print(json.dumps({"final_project": str(final), "request": request}, indent=2))


def fraction_esds(project, hist, phase_names: list[str]) -> dict[str, float | None]:
    """Propagate the final scale covariance into normalized mass fractions."""
    covariance = project.data.get("Covariance", {}).get("data", {})
    vary = [str(v) for v in covariance.get("varyList", [])]
    matrix = np.asarray(covariance.get("covMatrix", []), float)
    if matrix.shape != (len(vary), len(vary)):
        return {name: None for name in phase_names}
    phases = [project.phase(name) for name in phase_names]
    variables = [f"{phase.id}:{hist.id}:Scale" for phase in phases]
    if any(variable not in vary for variable in variables):
        return {name: None for name in phase_names}
    indices = [vary.index(variable) for variable in variables]
    scale_cov = matrix[np.ix_(indices, indices)]
    scales = np.array([
        float(phase.data["Histograms"][hist.name]["Scale"][0])
        for phase in phases
    ])
    masses = np.array([float(phase.data["General"]["Mass"])
                       for phase in phases])
    terms = scales * masses
    total = float(terms.sum())
    output: dict[str, float | None] = {}
    for i, name in enumerate(phase_names):
        gradient = -terms[i] * masses / total**2
        gradient[i] += masses[i] / total
        variance = float(gradient @ scale_cov @ gradient)
        output[name] = float(np.sqrt(max(variance, 0.0)))
    return output


def finish(root: Path) -> None:
    replay_dir = root / ".tmp" / "final_replay"
    replay = json.loads((replay_dir / "replay.json").read_text())
    if replay.get("status") != "replayed":
        raise RuntimeError(f"final project did not replay: {replay}")

    profile = np.load(replay_dir / "prediction.npz")
    x = np.asarray(profile["x"], float)
    observed = np.asarray(profile["observed"], float)
    calculated = np.asarray(profile["predicted"], float)
    background = np.asarray(profile["background"], float)
    public = np.loadtxt(root / "inputs" / "pattern.csv", delimiter=",",
                        skiprows=1, ndmin=2)
    if (public.shape != (len(x), 2)
            or not np.allclose(public[:, 0], x, atol=1e-7, rtol=0)
            or not np.allclose(public[:, 1], observed, atol=1e-5, rtol=0)):
        raise RuntimeError("replayed profile is not on the original measured grid")

    difference = observed - calculated
    curve = np.column_stack((x, observed, calculated, difference, background))
    np.savetxt(root / "fit.csv", curve, delimiter=",", fmt="%.10g",
               header="two_theta,observed,calculated,difference,background",
               comments="")

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100 * np.sqrt(chi_square / denominator))
    rp = float(100 * np.sum(np.abs(difference)) / np.sum(observed))

    project = G2.G2Project(gpxfile=str(root / "final.gpx"))
    hist = project.histogram(replay["histogram"])
    phase_names = [record["name"] for record in replay["phases"]]
    if set(phase_names) != set(PHASE_META):
        raise RuntimeError(f"unexpected final phase inventory: {phase_names}")
    esds = fraction_esds(project, hist, phase_names)

    phases = []
    for index, record in enumerate(replay["phases"]):
        name = record["name"]
        meta = PHASE_META[name]
        destination = root / meta["cif"]
        shutil.copy2(replay_dir / record["cif"], destination)
        phase = project.phase(name)
        cell = phase.get_cell()
        phases.append({
            "name": meta["display_name"],
            "project_phase_name": name,
            "formula": meta["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": meta["cif"],
            "weight_fraction": float(record["weight_fraction"]),
            "formal_weight_fraction_esd": esds[name],
            "reference_structure": meta["reference"],
            "cell": {key: float(value) for key, value in cell.items()
                     if key != "Volume"},
        })

    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    result = {
        "phases": phases,
        "fraction_basis": "normalized over the four modeled crystalline phases",
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "weighted_chi_square": chi_square,
            "goodness_of_fit": float(rvals.get("GOF", np.nan)),
            "number_of_points": int(len(x)),
            "weighting": "1/max(observed_counts,1)",
            "difference_definition": "observed - calculated",
            "profile_source": "independent no-refinement replay of final.gpx",
        },
        "refinement_histogram": replay["histogram"],
        "gsas_project": "final.gpx",
        "calibration": {
            "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
            "sample_displacement_um": float(hist.SampleParameters["Shift"][0]),
        },
    }
    (root / "result.json").write_text(json.dumps(result, indent=2,
                                                   allow_nan=False) + "\n")

    deletion = json.loads((root / "trials" / "deletion231" /
                           "deletion_tests.json").read_text())
    deletion_rwp = {key: value["rwp_percent"]
                    for key, value in deletion["tests"].items()}
    rows = []
    for entry in phases:
        uncertainty = entry["formal_weight_fraction_esd"]
        esd_text = "n/a" if uncertainty is None else f"{100*uncertainty:.2f}"
        rows.append(f"| {entry['name']} | {100*entry['weight_fraction']:.2f} | "
                    f"{esd_text} | {entry['space_group']} | {entry['cif_path']} |")
    table = "\n".join(rows)
    report = f"""# Powder XRD phase analysis

## Result

Four crystalline phases were required. Weight fractions are normalized over the modeled crystalline material; they do not measure any amorphous fraction.

| Phase | wt% | formal 1σ (wt%) | Space group | Structural model |
|---|---:|---:|---|---|
{table}

The independently regenerated GSAS-II profile gives **Rwp = {rwp:.3f}%**, **Rp = {rp:.3f}%**, and goodness of fit **{float(rvals.get('GOF', np.nan)):.3f}** over all {len(x)} measured points. The difference column in `fit.csv` is observed minus calculated.

## Evidence

The precursor chemistry and 650 °C treatment support partial formation of scheelite CaWO4 with residual WO3 and Ca-bearing precursor/decomposition products. The whole-pattern assignments are anchored by the CaWO4 reflections near 18.7° and 28.8° 2θ, the characteristic monoclinic WO3 multiplet from about 23.2–24.5°, the calcite line near 29.5°, and the CaO series near 32.3°, 37.4°, 53.9°, and 91.4°. Candidate monoclinic, triclinic, and orthorhombic WO3 reference structures were screened; the COD 2311041 monoclinic model gave the best stable whole-pattern refinement.

Phase-deletion controls increased Rwp from {deletion['baseline_rwp_percent']:.3f}% to {deletion_rwp['CaWO4_scheelite']:.2f}% without CaWO4, {deletion_rwp['WO3_monoclinic']:.2f}% without WO3, {deletion_rwp['CaCO3_calcite']:.2f}% without calcite, and {deletion_rwp['CaO_rocksalt']:.2f}% without CaO. Thus even the two minor phases are supported by reproducible multi-line residuals, not solely by a single overlapped peak.

The Rietveld model uses the supplied Cu Kα doublet, refined unit cells, phase scales, isotropic size broadening, microstrain (uniaxial for WO3), a modest [111] March–Dollase correction for WO3, specimen displacement, polarization, and a smooth Chebyshev background. Atomic coordinates were allowed only small symmetry-preserving departures from the published reference structures.

## Remaining uncertainty

The tabulated 1σ values are conditional least-squares errors and are smaller than the likely systematic uncertainty from peak overlap, absorption, preferred orientation, and model choice. In particular, the 2.85 wt% CaO fraction and the exact oxygen coordinates in low-symmetry WO3 are less secure than the phase identities. Thermal displacement and polarization terms are strongly correlated, so their individual values should not be interpreted independently. No crystalline phase is left unidentified in the fitted pattern, but trace phases below the detection limit and amorphous material cannot be excluded; consequently, absolute bulk phase fractions cannot be determined reliably without an internal standard. The submitted fractions are reliable as normalized crystalline-phase estimates, with the minor-phase values carrying the greatest practical uncertainty.
"""
    (root / "report.md").write_text(report)
    print(json.dumps({"rwp_percent": rwp, "rp_percent": rp,
                      "chi_square": chi_square, "phases": phases}, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("stage", "finish"))
    parser.add_argument("--source", default="trials/uiso_tied231/final_model.gpx")
    args = parser.parse_args()
    root = Path.cwd().resolve()
    if args.mode == "stage":
        stage(root, (root / args.source).resolve())
    else:
        finish(root)


if __name__ == "__main__":
    main()
