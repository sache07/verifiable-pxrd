#!/usr/bin/env python3
"""Apply and screen selected specimen/profile effects in an existing GPX."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def axis(text: str) -> list[int]:
    value = [int(v) for v in text.replace(",", " ").split()]
    if len(value) != 3 or value == [0, 0, 0]:
        raise argparse.ArgumentTypeError("axis must be three nonzero hkl integers")
    return value


def phase_axis(text: str) -> tuple[str, list[int]]:
    try:
        name, hkl = text.split(":", 1)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("use PHASE:h,k,l") from exc
    return name, axis(hkl)


def phase_value(text: str) -> tuple[str, float]:
    try:
        name, value = text.split("=", 1)
        return name, float(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("use PHASE=value") from exc


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--orientation", action="append", type=phase_axis, default=[])
    parser.add_argument("--uniaxial-strain", action="append", type=phase_axis, default=[])
    parser.add_argument("--uiso", action="append", type=phase_value, default=[])
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--shift", action="store_true")
    parser.add_argument("--release-profile", action="store_true")
    parser.add_argument("--release-cells", action="store_true")
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--repeat", type=int, default=1)
    parser.add_argument("--quiet", action="store_true")
    return parser.parse_args()


def rwp(hist) -> float:
    a = hist.data["data"][1]
    y, w, calc = (np.asarray(a[i], float) for i in [1, 2, 3])
    return float(100 * np.sqrt(np.sum(w * (y - calc) ** 2) / np.sum(w * y ** 2)))


def fractions(project, hist) -> dict[str, float]:
    terms = {
        phase.name: float(phase.data["Histograms"][hist.name]["Scale"][0])
        * float(phase.data["General"]["Mass"])
        for phase in project.phases()
    }
    total = sum(terms.values())
    return {key: value / total for key, value in terms.items()}


def clear_frozen(project) -> None:
    controls = project.data["Controls"]["data"]
    frozen = controls.setdefault("parmFrozen", {})
    if isinstance(frozen, dict):
        frozen["FrozenList"] = []


def set_bounds(project, variable: str, lower: float, upper: float) -> None:
    project.set_Controls("parmMin", lower, variable)
    project.set_Controls("parmMax", upper, variable)


def main() -> None:
    args = parse_args()
    G2.SetPrintLevel("error" if args.quiet else "warn")
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    hist = project.histogram(0)
    initial = rwp(hist)

    # Begin from a stable parameter subset: background and phase scales remain
    # active, while positions, cells and peak shapes are held unless requested.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = ""
        phase.set_refinements({"Cell": False})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False
        hap["Scale"][1] = True
    inst = hist.InstrumentParameters
    for key, value in inst.items():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for key in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]:
        hist.SampleParameters[key][1] = False
    clear_frozen(project)

    if args.roughness:
        hist.SampleParameters["SurfRoughA"] = [0.2, True]
        hist.SampleParameters["SurfRoughB"] = [0.1, True]
        set_bounds(project, f":{hist.id}:SurfRoughA", 0.05, 0.9)
        set_bounds(project, f":{hist.id}:SurfRoughB", 0.02, 0.8)

    for phase_name, hkl in args.orientation:
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        current_ratio = float(hap["Pref.Ori."][1]) if (
            hap["Pref.Ori."][0] == "MD" and hap["Pref.Ori."][3] == hkl
        ) else 1.0
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = current_ratio
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = hkl
        set_bounds(project, f"{phase.id}:{hist.id}:MD", 0.5, 2.0)

    for phase_name, hkl in args.uniaxial_strain:
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        current = max(10.0, float(hap["Mustrain"][1][0]))
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = current
        hap["Mustrain"][1][1] = current
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        hap["Mustrain"][3] = hkl
        set_bounds(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 16000.0)
        set_bounds(project, f"{phase.id}:{hist.id}:Mustrain;a", 0.0, 16000.0)

    for phase_name, value in args.uiso:
        if not 0 <= value <= 0.05:
            raise ValueError("Uiso values must lie in [0, 0.05] A^2")
        phase = project.phase(phase_name)
        for atom in phase.atoms():
            atom.uiso = value

    if args.polarization:
        inst["Polariz."][2] = True
        set_bounds(project, f":{hist.id}:Polariz.", 0.0, 1.0)
    if args.shift:
        hist.SampleParameters["Shift"][1] = True
        set_bounds(project, f":{hist.id}:Shift", -900.0, 900.0)

    if args.release_cells:
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
    if args.release_profile:
        for key in ["Zero", "U", "W", "X", "SH/L"]:
            inst[key][2] = True
        set_bounds(project, f":{hist.id}:Zero", -0.3, 0.3)
        set_bounds(project, f":{hist.id}:U", 0.0, 40.0)
        set_bounds(project, f":{hist.id}:W", 0.0, 40.0)
        set_bounds(project, f":{hist.id}:X", 0.01, 6.0)
        set_bounds(project, f":{hist.id}:SH/L", 0.001, 0.12)
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            if hap["Size"][0] == "isotropic":
                hap["Size"][2][0] = True
            if hap["Mustrain"][0] == "isotropic":
                hap["Mustrain"][2][0] = True
            elif hap["Mustrain"][0] == "uniaxial":
                hap["Mustrain"][2][0:2] = [True, True]
    project.set_Controls("cycles", args.cycles)
    project.save()
    sequence = []
    for index in range(args.repeat):
        project.refine(makeBack=False)
        sequence.append(rwp(hist))
    project.save()

    report = {
        "input": str(Path(args.input).resolve()),
        "output": str(output),
        "initial_rwp_percent": initial,
        "rwp_sequence_percent": sequence,
        "fractions": fractions(project, hist),
        "instrument": {key: float(value[1]) for key, value in inst.items()
                       if key in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]},
        "sample": {key: float(hist.SampleParameters[key][0]) for key in
                   ["Shift", "SurfRoughA", "SurfRoughB"]},
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        report["phases"][phase.name] = {
            "cell": phase.get_cell(), "scale": float(hap["Scale"][0]),
            "size": hap["Size"], "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "uiso": [float(atom.uiso) for atom in phase.atoms()],
        }
    output.with_suffix(".json").write_text(json.dumps(report, indent=2, default=str) + "\n")
    if args.quiet:
        print(json.dumps({
            "output": str(output), "initial_rwp": initial,
            "rwp": sequence[-1] if sequence else initial,
            "fractions": report["fractions"],
            "instrument": report["instrument"], "sample": report["sample"],
            "preferred_orientation": {
                name: values["preferred_orientation"][:4]
                for name, values in report["phases"].items()
            },
            "uiso": {name: values["uiso"][0]
                      for name, values in report["phases"].items()},
        }))
    else:
        print(json.dumps(report, indent=2, default=str))


if __name__ == "__main__":
    main()
