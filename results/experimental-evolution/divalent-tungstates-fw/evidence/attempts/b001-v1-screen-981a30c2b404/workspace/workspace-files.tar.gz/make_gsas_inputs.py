#!/usr/bin/env python3
"""Create GSAS-II input files from the public count scan."""

from pathlib import Path

import numpy as np


# Importing through a package path is inconvenient because the framework folder
# contains a hyphen.  Keep the explicit, documented GSAS-II instrument syntax
# here instead.
def render_instrument() -> str:
    return (
        "#GSAS-II instrument parameter file; Cu K-alpha Bragg-Brentano starting model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.8;Azimuth:0.0\n"
        "U:5.0;V:0.0;W:5.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def main() -> None:
    root = Path(__file__).resolve().parent
    scan = np.genfromtxt(root / "inputs/pattern.csv", delimiter=",", names=True)
    x = np.asarray(scan["two_theta_deg"], float)
    y = np.asarray(scan["intensity"], float)
    sigma = np.sqrt(np.maximum(y, 1.0))
    with (root / "observed.xye").open("w") as stream:
        stream.write("# Observed public scan\n")
        for xx, yy, ss in zip(x, y, sigma):
            stream.write(f"{xx:.8f} {yy:.8f} {ss:.8f}\n")
    (root / "instrument.instprm").write_text(render_instrument())


if __name__ == "__main__":
    main()
