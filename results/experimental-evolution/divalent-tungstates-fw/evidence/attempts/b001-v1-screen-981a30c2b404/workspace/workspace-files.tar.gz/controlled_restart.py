#!/usr/bin/env python3
"""Run a profile/background restart in stages to test model stability."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_models import diagnostics


def refine(project: G2.G2Project, history: list[dict], label: str, cycles: int) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    project.save()
    row = diagnostics(project, label)
    history.append(row)
    print(f"{label:24s} Rwp={row['residuals'].get('wR'):.6f}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("--out", required=True)
    parser.add_argument("--background-terms", type=int, default=10)
    parser.add_argument("--profile-u", type=float, default=45.0)
    parser.add_argument("--profile-x", type=float, default=4.0)
    parser.add_argument("--cycles", type=int, default=30)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = Path(args.out).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(Path(args.input).resolve()),
        newgpx=str(outdir / "model.gpx"),
    )
    hist = project.histogram(0)
    history = [diagnostics(project, "source")]

    old_background = list(hist.Background[0][3:])
    coefficients = (old_background + [0.0] * args.background_terms)[: args.background_terms]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_terms,
                "coeffs": coefficients,
                "refine": True,
            }
        }
    )
    hist.InstrumentParameters["U"] = [args.profile_u, args.profile_u, True]
    hist.InstrumentParameters["X"] = [args.profile_x, args.profile_x, True]

    saved = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        saved.append(
            {
                "phase": phase,
                "cell": bool(phase.data["General"]["Cell"][0]),
                "atoms": [(atom, atom.refinement_flags) for atom in phase.atoms()],
                "size": list(hap["Size"][2]),
                "strain": list(hap["Mustrain"][2]),
            }
        )
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]

    project.save()
    refine(project, history, "profile_background", 20)

    for row in saved:
        phase = row["phase"]
        phase.data["General"]["Cell"][0] = row["cell"]
        for atom, flag in row["atoms"]:
            atom.refinement_flags = flag
    refine(project, history, "restore_structure", 20)

    for row in saved:
        phase = row["phase"]
        phase.data["Histograms"][hist.name]["Mustrain"][2] = row["strain"]
    refine(project, history, "restore_strain", args.cycles)

    for row in saved:
        phase = row["phase"]
        phase.data["Histograms"][hist.name]["Size"][2] = row["size"]
    refine(project, history, "restore_size", args.cycles)
    refine(project, history, "settle", args.cycles)

    controls = project.data.get("Controls", {}).get("data", {})
    frozen = controls.get("parmFrozen", {})
    (outdir / "summary.json").write_text(
        json.dumps(
            {"arguments": vars(args), "history": history, "frozen": frozen},
            indent=2,
            default=str,
        )
        + "\n"
    )
    print(f"frozen={frozen}")


if __name__ == "__main__":
    main()
