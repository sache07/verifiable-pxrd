#!/usr/bin/env python3
"""Normalize public-library PXRD candidates and run the supplied physical screen.

The ZnWO4 composition is absent from the supplied filtered library.  For those
models, all occupied non-W/non-O cation species in a published tungstate parent
are mapped onto Zn while keeping the parent framework and coordinates.
"""

from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path(__file__).resolve().parent
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/"
    "resources/b001-c04/cif"
)
SCORER = ROOT / "learned/divalent-tungstates/scorer/src"
sys.path.insert(0, str(SCORER))
from structure_metrics import physical_screen  # noqa: E402


def cod_path(cod_id: str) -> Path:
    return LIB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = [
    # Same-composition analogue-derived wolframite candidates.
    ("znwo4_cd011_wolframite", "1520642", "ZnWO4", "map all Cd/Zn cation occupancy to Zn"),
    ("znwo4_cu015_wolframite", "9005254", "ZnWO4", "map all Cu/Zn cation occupancy to Zn"),
    ("znwo4_mg_wolframite", "9013902", "ZnWO4", "map Mg to Zn"),
    ("znwo4_mn_wolframite", "1520200", "ZnWO4", "map Mn to Zn"),
    ("znwo4_fe_wolframite", "1567215", "ZnWO4", "map Fe to Zn"),
    ("znwo4_cd_wolframite", "1520645", "ZnWO4", "map Cd to Zn"),
    # Alternate framework/polymorph checks.
    ("znwo4_cd_scheelite", "1549132", "ZnWO4", "map Cd to Zn in scheelite parent"),
    ("znwo4_ca_fergusonite", "1546035", "ZnWO4", "map Ca to Zn in fergusonite parent"),
    # Residual precursor candidates.
    ("zno_wurtzite_9004178", "9004178", None, "none"),
    ("zno_rocksalt_1534836", "1534836", None, "none"),
    # WO3 polymorph/source comparison.
    ("wo3_hex_1004057", "1004057", None, "none"),
    ("wo3_p21m_1010618", "1010618", None, "none"),
    ("wo3_p4ncc_1521532", "1521532", None, "none"),
    ("wo3_p4nmm_1521533", "1521533", None, "none"),
    ("wo3_p21c_1528915", "1528915", None, "none"),
    ("wo3_p21c_1563541", "1563541", None, "none"),
    ("wo3_p21c_2311041", "2311041", None, "none"),
    ("wo3_p1_2106293", "2106293", None, "none"),
    ("wo3_pnma_2107312", "2107312", None, "none"),
]


def map_to_zinc_tungstate(structure: Structure) -> Structure:
    result = structure.copy()
    for i, site in enumerate(list(result)):
        mapped: dict[str, float] = {}
        for species, occupancy in site.species.items():
            symbol = species.symbol
            target = symbol if symbol in {"W", "O"} else "Zn"
            mapped[target] = mapped.get(target, 0.0) + float(occupancy)
        result.replace(i, mapped)
    return result


def main() -> None:
    outdir = ROOT / "candidates"
    outdir.mkdir(exist_ok=True)
    records = []
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for name, cod_id, target, transformation in CANDIDATES:
            source = cod_path(cod_id)
            structure = Structure.from_file(source, primitive=False)
            source_formula = structure.composition.reduced_formula
            if target == "ZnWO4":
                structure = map_to_zinc_tungstate(structure)

            # CifWriter's refinement regularizes the setting and symmetry,
            # eliminating parser-dependent duplicated/near-special sites.
            destination = outdir / f"{name}.cif"
            CifWriter(
                structure,
                symprec=1e-4,
                angle_tolerance=0.1,
                significant_figures=10,
                refine_struct=True,
            ).write_file(destination)
            normalized = Structure.from_file(destination, primitive=False)
            sga = SpacegroupAnalyzer(normalized, symprec=1e-4, angle_tolerance=0.1)
            screen = physical_screen(normalized)
            records.append(
                {
                    "name": name,
                    "path": str(destination.relative_to(ROOT)),
                    "cod_id": cod_id,
                    "source_path": str(source),
                    "source_formula": source_formula,
                    "normalized_formula": normalized.composition.reduced_formula,
                    "model_basis": "analogue_derived" if target else "published",
                    "transformation": transformation,
                    "space_group": sga.get_space_group_symbol(),
                    "space_group_number": sga.get_space_group_number(),
                    "sites_in_cell": len(normalized),
                    "cell": {
                        "a": normalized.lattice.a,
                        "b": normalized.lattice.b,
                        "c": normalized.lattice.c,
                        "alpha": normalized.lattice.alpha,
                        "beta": normalized.lattice.beta,
                        "gamma": normalized.lattice.gamma,
                    },
                    "density_g_cm3": float(normalized.density),
                    "physical_screen": screen,
                }
            )
    (outdir / "screen.json").write_text(json.dumps(records, indent=2) + "\n")
    for row in records:
        print(
            f"{row['name']:30s} {row['normalized_formula']:10s} "
            f"{row['space_group']:8s} {row['physical_screen']['status']}"
        )


if __name__ == "__main__":
    main()
