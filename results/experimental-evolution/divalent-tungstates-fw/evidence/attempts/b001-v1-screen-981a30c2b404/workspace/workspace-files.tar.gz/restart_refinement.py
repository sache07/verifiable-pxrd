#!/usr/bin/env python3
"""Restart a fitted GSAS-II model on an alternate nuisance branch."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_models import diagnostics


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("--out", required=True)
    parser.add_argument("--background-terms", type=int)
    parser.add_argument("--angular", choices=["keep", "zero", "shift"], default="keep")
    parser.add_argument("--restart-profile", action="store_true")
    parser.add_argument("--profile-u", type=float, default=50.0)
    parser.add_argument("--profile-x", type=float, default=5.0)
    parser.add_argument("--staged", action="store_true")
    parser.add_argument("--clear-sample-broadening", action="store_true")
    parser.add_argument("--size-um", type=float)
    parser.add_argument("--refine-all-strain", action="store_true")
    parser.add_argument("--fix-zero-strain", action="store_true")
    parser.add_argument("--cycles", type=int, default=30)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = Path(args.out).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(Path(args.input).resolve()), newgpx=str(outdir / "model.gpx")
    )
    hist = project.histogram(0)
    before = diagnostics(project, "before_restart")

    if args.background_terms:
        old = list(hist.Background[0][3:])
        coefficients = (old + [0.0] * args.background_terms)[: args.background_terms]
        hist.set_refinements(
            {
                "Background": {
                    "type": "chebyschev-1",
                    "no. coeffs": args.background_terms,
                    "coeffs": coefficients,
                    "refine": True,
                }
            }
        )
    if args.angular == "shift":
        hist.InstrumentParameters["Zero"] = [0.0, 0.0, False]
        hist.SampleParameters["Shift"] = [-650.0, True]
    elif args.angular == "zero":
        hist.SampleParameters["Shift"] = [0.0, False]
        hist.InstrumentParameters["Zero"] = [0.2, 0.2, True]
    if args.restart_profile:
        hist.InstrumentParameters["U"] = [args.profile_u, args.profile_u, True]
        hist.InstrumentParameters["V"] = [0.0, 0.0, False]
        hist.InstrumentParameters["W"] = [0.0, 0.0, False]
        hist.InstrumentParameters["X"] = [args.profile_x, args.profile_x, True]
    if args.clear_sample_broadening:
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 1000.0
            hap["Size"][2] = [False, False, False]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2] = [False, False, False]
    if args.size_um is not None:
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = args.size_um
            hap["Size"][2] = [False, False, False]
    if args.refine_all_strain:
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][2] = [True, False, False]
            project.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Mustrain;i")
            project.set_Controls("parmMax", 50000.0, f"{phase.id}:{hist.id}:Mustrain;i")
    if args.fix_zero_strain:
        project.set_Frozen()
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            if abs(float(hap["Mustrain"][1][0])) < 1e-9:
                hap["Mustrain"][1][0] = 0.0
                hap["Mustrain"][2] = [False, False, False]

    saved_phase_flags = []
    if args.staged:
        for phase in project.phases():
            saved_phase_flags.append(
                (
                    phase,
                    bool(phase.data["General"]["Cell"][0]),
                    [(atom, atom.refinement_flags) for atom in phase.atoms()],
                )
            )
            phase.data["General"]["Cell"][0] = False
            for atom in phase.atoms():
                atom.refinement_flags = " "

    project.save()
    if args.staged:
        project.set_Controls("cycles", 15)
        project.refine(makeBack=False)
        for phase, cell_flag, atom_flags in saved_phase_flags:
            phase.data["General"]["Cell"][0] = cell_flag
            for atom, flag in atom_flags:
                atom.refinement_flags = flag
    project.set_Controls("cycles", args.cycles)
    project.refine(makeBack=False)
    project.save()
    after = diagnostics(project, "after_restart")
    (outdir / "summary.json").write_text(
        json.dumps({"arguments": vars(args), "before": before, "final": after}, indent=2, default=str) + "\n"
    )
    print(
        f"restart Rwp {before['residuals'].get('wR')} -> {after['residuals'].get('wR')} "
        f"({args.angular}, bkg={args.background_terms})"
    )


if __name__ == "__main__":
    main()
