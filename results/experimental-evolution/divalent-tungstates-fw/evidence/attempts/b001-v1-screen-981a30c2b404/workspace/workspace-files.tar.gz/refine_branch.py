#!/usr/bin/env python3
"""Apply one interpretable GSAS-II refinement effect to an existing project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_models import diagnostics


def phase_selection(project: G2.G2Project, name: str):
    if name == "all":
        return project.phases()
    return [project.phase(name)]


def set_effect(project: G2.G2Project, args: argparse.Namespace) -> None:
    hist = project.histogram(0)
    phases = phase_selection(project, args.phase)
    if args.effect == "settle":
        return
    if args.effect == "size":
        for phase in phases:
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": args.value, "refine": True}}, [hist]
            )
            project.set_Controls("parmMin", 0.005, f"{phase.id}:{hist.id}:Size;i")
            project.set_Controls("parmMax", 20.0, f"{phase.id}:{hist.id}:Size;i")
        return
    if args.effect == "strain":
        for phase in phases:
            hap = phase.data["Histograms"][hist.name]["Mustrain"]
            hap[0] = "isotropic"
            hap[1][0] = args.value
            hap[2] = [True, False, False]
            project.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Mustrain;i")
            project.set_Controls("parmMax", 50000.0, f"{phase.id}:{hist.id}:Mustrain;i")
        return
    if args.effect == "texture":
        hkl = [int(v) for v in args.hkl.split(",")]
        if len(hkl) != 3:
            raise ValueError("--hkl must have three comma-separated integers")
        for phase in phases:
            po = phase.data["Histograms"][hist.name]["Pref.Ori."]
            po[0] = "MD"
            po[1] = args.value
            po[2] = True
            po[3] = hkl
            project.set_Controls("parmMin", 0.2, f"{phase.id}:{hist.id}:MD")
            project.set_Controls("parmMax", 5.0, f"{phase.id}:{hist.id}:MD")
        return
    if args.effect == "roughness":
        hist.SampleParameters["SurfRoughA"] = [0.5, True]
        hist.SampleParameters["SurfRoughB"] = [0.1, True]
        project.set_Controls("parmMin", 1e-5, f"::{hist.id}:SurfRoughA")
        project.set_Controls("parmMax", 1.0, f"::{hist.id}:SurfRoughA")
        project.set_Controls("parmMin", 1e-5, f"::{hist.id}:SurfRoughB")
        project.set_Controls("parmMax", 2.0, f"::{hist.id}:SurfRoughB")
        return
    if args.effect == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.0, f":{hist.id}:Polariz.")
        project.set_Controls("parmMax", 1.0, f":{hist.id}:Polariz.")
        return
    if args.effect in {"coords", "uiso", "coords_uiso"}:
        flags = {"coords": "X", "uiso": "U", "coords_uiso": "XU"}[args.effect]
        labels = None if args.atoms == "all" else set(args.atoms.split(","))
        for phase in phases:
            for atom in phase.atoms():
                if labels is None or atom.label in labels:
                    atom.refinement_flags = flags
        return
    raise ValueError(args.effect)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("--out", required=True)
    parser.add_argument(
        "--effect",
        required=True,
        choices=["settle", "size", "strain", "texture", "roughness", "polarization", "coords", "uiso", "coords_uiso"],
    )
    parser.add_argument("--phase", default="all")
    parser.add_argument("--hkl", default="0,0,1")
    parser.add_argument("--value", type=float, default=1.0)
    parser.add_argument("--atoms", default="all")
    parser.add_argument("--cycles", type=int, default=12)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = Path(args.out).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    output = outdir / "model.gpx"
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    before = diagnostics(project, "before")
    set_effect(project, args)
    project.save()
    project.set_Controls("cycles", args.cycles)
    project.refine(makeBack=False)
    project.save()
    after = diagnostics(project, "after")
    summary = {"arguments": vars(args), "before": before, "final": after}
    (outdir / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(f"{args.effect} {args.phase} Rwp {before['residuals'].get('wR')} -> {after['residuals'].get('wR')}")


if __name__ == "__main__":
    main()
