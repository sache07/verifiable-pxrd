#!/usr/bin/env python3
"""Export the selected stable GSAS-II branch and independently replay it."""

from __future__ import annotations

import csv
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/clean-size-strain-settled-2/model.gpx"
REPLAY_WORKER = ROOT / "learned/divalent-tungstates/scorer/runtime/replay_worker.py"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    final_gpx = ROOT / "final.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(final_gpx))
    histograms = project.histograms()
    if len(histograms) != 1:
        raise RuntimeError(f"Expected one histogram, found {len(histograms)}")
    hist = histograms[0]
    phases = project.phases()
    if [p.name for p in phases] != ["ZnWO4", "ZnO", "WO3"]:
        raise RuntimeError(f"Unexpected phase inventory: {[p.name for p in phases]}")
    for phase in phases:
        hap = phase.data["Histograms"].get(hist.name)
        if not hap or not hap.get("Use", True) or float(hap["Scale"][0]) <= 0:
            raise RuntimeError(f"Unused or nonpositive phase: {phase.name}")
    project.save()

    cif_names = {"ZnWO4": "phase_znwo4.cif", "ZnO": "phase_zno.cif", "WO3": "phase_wo3.cif"}
    for phase in phases:
        phase.export_CIF(str(ROOT / cif_names[phase.name]))

    replay_dir = ROOT / ".tmp" / "final-replay"
    if replay_dir.exists():
        shutil.rmtree(replay_dir)
    replay_dir.mkdir(parents=True)
    request = {
        "project": str(final_gpx),
        "observed": str(ROOT / "inputs/pattern.csv"),
        "histogram": hist.name,
    }
    request_path = replay_dir / "request.json"
    request_path.write_text(json.dumps(request, indent=2) + "\n")
    run = subprocess.run(
        [sys.executable, str(REPLAY_WORKER), str(request_path)],
        cwd=replay_dir,
        capture_output=True,
        text=True,
        timeout=120,
    )
    (replay_dir / "stdout.log").write_text(run.stdout)
    (replay_dir / "stderr.log").write_text(run.stderr)
    replay = json.loads((replay_dir / "replay.json").read_text())
    if run.returncode or replay.get("status") != "replayed":
        raise RuntimeError(f"Replay failed: {replay}")
    if replay.get("profile_review_flags"):
        raise RuntimeError(f"Project profile requires review: {replay['profile_review_flags']}")
    if replay.get("project_sha256") != sha256(final_gpx):
        raise RuntimeError("Replay project hash mismatch")

    with np.load(replay_dir / "prediction.npz", allow_pickle=False) as arrays:
        x = arrays["x"].copy()
        observed = arrays["observed"].copy()
        calculated = arrays["predicted"].copy()
        background = arrays["background"].copy()
    difference = observed - calculated
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta", "observed", "calculated", "difference", "background"])
        for row in zip(x, observed, calculated, difference, background):
            writer.writerow([f"{row[0]:.8f}", *(f"{v:.8f}" for v in row[1:])])

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    covariance = project.data.get("Covariance", {}).get("data", {})
    n_parameters = len(covariance.get("varyList", []))
    degrees_of_freedom = max(1, len(x) - n_parameters)
    reduced_chi_square = chi_square / degrees_of_freedom

    replay_by_name = {row["name"]: row for row in replay["phases"]}
    saved_mass = hist.ComputeMassFracs()
    phase_records = []
    labels = {
        "ZnWO4": "ZnWO4 (wolframite)",
        "ZnO": "ZnO (wurtzite)",
        "WO3": "WO3 (monoclinic)",
    }
    provenance = {
        "ZnWO4": {
            "model_basis": "analogue_derived",
            "parent": "COD 1520642, Zn0.89Cd0.11WO4 wolframite",
            "transformation": "all Cd/Zn cation occupancy mapped to Zn before refinement",
        },
        "ZnO": {"model_basis": "published", "parent": "COD 9004178"},
        "WO3": {"model_basis": "published", "parent": "COD 2311041"},
    }
    for phase in phases:
        row = replay_by_name[phase.name]
        fraction = float(row["weight_fraction"])
        if fraction <= 0:
            raise RuntimeError(f"Nonpositive replay fraction for {phase.name}")
        phase_records.append(
            {
                "name": labels[phase.name],
                "formula": phase.name,
                "cif_path": cif_names[phase.name],
                "weight_fraction": fraction,
                "weight_fraction_esd": float(saved_mass[phase.name][1]),
                "provenance": provenance[phase.name],
            }
        )
    total = sum(row["weight_fraction"] for row in phase_records)
    if abs(total - 1.0) > 1e-10:
        raise RuntimeError(f"Fractions do not sum to one: {total}")

    result = {
        "schema_version": 1,
        "refinement_histogram": hist.name,
        "phases": phase_records,
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "chi_square": chi_square,
            "reduced_chi_square": reduced_chi_square,
            "goodness_of_fit": float(np.sqrt(reduced_chi_square)),
            "expected_rwp_percent": float(hist.residuals.get("wRmin", np.nan)),
            "n_points": int(len(x)),
            "n_refined_parameters": int(n_parameters),
            "weighting": "1/max(observed_counts,1)",
            "profile_source": "independent native GSAS-II replay of final.gpx over the full observed grid",
        },
        "calibration": {
            "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
            "specimen_shift_um": float(hist.SampleParameters["Shift"][0]),
        },
        "project_sha256": sha256(final_gpx),
        "fit_csv": "fit.csv",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
