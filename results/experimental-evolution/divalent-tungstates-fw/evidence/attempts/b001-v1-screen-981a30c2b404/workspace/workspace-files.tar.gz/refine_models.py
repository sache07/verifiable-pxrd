#!/usr/bin/env python3
"""Build comparable fixed-coordinate GSAS-II models for candidate inventories.

Run with GSAS-II's Python.  This script intentionally keeps all atomic
coordinates fixed so candidate sources and phase inventories are compared with
the same low-flexibility nuisance model.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def candidate(name: str) -> Path:
    path = ROOT / "candidates" / f"{name}.cif"
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def diagnostics(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    residuals = dict(hist.residuals)
    try:
        raw_result = project.get_LastFitResults()
        if isinstance(raw_result, tuple) and len(raw_result) == 2:
            shifts, esds = raw_result
            result = {"shifts": shifts, "esds": esds}
        elif isinstance(raw_result, dict):
            result = raw_result
        else:
            result = {"value": str(raw_result)}
    except Exception:
        result = {}
    cov = project.data.get("Covariance", {}).get("data", {}) or {}
    vary = list(cov.get("varyList", [])) if isinstance(cov, dict) else []
    values = list(cov.get("variables", [])) if isinstance(cov, dict) else []
    sig = list(cov.get("sig", [])) if isinstance(cov, dict) else []
    params = []
    for i, var in enumerate(vary):
        params.append(
            {
                "name": str(var),
                "value": float(values[i]) if i < len(values) else None,
                "sigma": float(sig[i]) if i < len(sig) and sig[i] is not None else None,
            }
        )
    return {
        "stage": label,
        "residuals": {
            k: (str(v) if isinstance(v, str) else float(v))
            for k, v in residuals.items()
            if np.isscalar(v)
        },
        "last_fit": result,
        "parameters": params,
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "scales": {
            p.name: [float(x) if isinstance(x, (int, float)) else x for x in p.data["Histograms"][hist.name]["Scale"]]
            for p in project.phases()
        },
        "instrument": {
            k: list(v) if isinstance(v, list) else v
            for k, v in hist.InstrumentParameters.items()
        },
        "sample": {
            k: list(v) if isinstance(v, list) else v
            for k, v in hist.SampleParameters.items()
            if k in {"Scale", "Type", "Gonio. radius", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"}
        },
        "background": list(hist.Background[0]),
    }


def run_refinement(project: G2.G2Project, history: list, label: str, cycles: int = 5) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    project.save()
    row = diagnostics(project, label)
    history.append(row)
    rwp = row["residuals"].get("wR", float("nan"))
    print(f"{label:24s} Rwp={rwp:9.4f}")


def build(args: argparse.Namespace) -> tuple[G2.G2Project, list]:
    outdir = Path(args.out).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    gpx = outdir / "model.gpx"
    if gpx.exists():
        gpx.unlink()

    project = G2.G2Project(newgpx=str(gpx))
    phases = []
    if args.znwo4:
        phases.append(project.add_phase(str(candidate(args.znwo4)), phasename="ZnWO4", fmthint="CIF"))
    if args.zno:
        phases.append(project.add_phase(str(candidate(args.zno)), phasename="ZnO", fmthint="CIF"))
    if args.wo3:
        phases.append(project.add_phase(str(candidate(args.wo3)), phasename="WO3", fmthint="CIF"))
    if not phases:
        raise ValueError("At least one phase is required")

    hist = project.add_powder_histogram(
        str(ROOT / "observed.xye"),
        str(ROOT / "instrument.instprm"),
        phases=phases,
        fmthint="xye",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    for variable, lower in [(":0:U", 0.0), (":0:W", 0.0), (":0:X", 0.0), (":0:SH/L", 0.001)]:
        project.set_Controls("parmMin", lower, variable)
    hist.set_refinements({"Limits": {"low": 10.0, "high": 100.0}})
    hist.set_refinements(
        {
            "Background": {
                "type": args.background,
                "no. coeffs": args.background_terms,
                "coeffs": [1100.0] + [0.0] * (args.background_terms - 1),
                "refine": True,
            }
        }
    )

    # Peak matching on the public scan gives safe count-scale starts. These are
    # only numerical initializations and all phase scales are subsequently fit.
    scale_starts = {"ZnWO4": 10.0, "ZnO": 0.5, "WO3": 0.2}
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale_starts.get(phase.name, 0.5), False]
        phase.set_refinements({"Atoms": {"all": " "}})
        project.set_Controls("parmMin", 1e-8, f"{phase.id}:{hist.id}:Scale")

    # Start the chosen angular branch near the common offset visible in the
    # indexed peak families, then refine only that branch.
    if args.angular == "shift":
        hist.SampleParameters["Shift"] = [-400.0, False]
    elif args.angular == "zero":
        hist.InstrumentParameters["Zero"] = [0.22, 0.22, False]

    project.save()
    history = [diagnostics(project, "created")]
    run_refinement(project, history, "background_only", 3)

    # Establish the dominant phase registration before fitting residual phases.
    anchor = phases[0]
    anchor.set_refinements({"Cell": True})
    anchor.set_HAP_refinements({"Scale": True}, [hist])
    if args.angular == "shift":
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    elif args.angular == "zero":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    elif args.angular != "none":
        raise ValueError(args.angular)
    run_refinement(project, history, f"anchor_cell_angular_{args.angular}", 5)

    # Now give every supported phase the same scale/cell flexibility.
    for phase in phases:
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True}, [hist])
    run_refinement(project, history, "all_scales_cells", 6)

    # Shared instrumental broadening; coordinates and phase-specific effects
    # remain fixed for a fair source/inventory comparison.
    hist.InstrumentParameters["W"] = [0.0, 0.0, False]
    hist.set_refinements({"Instrument Parameters": ["U", "X"]})
    run_refinement(project, history, "common_profile", 7)
    run_refinement(project, history, "settle", 4)
    return project, history


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--znwo4")
    parser.add_argument("--zno")
    parser.add_argument("--wo3")
    parser.add_argument("--out", required=True)
    parser.add_argument("--angular", choices=["shift", "zero", "none"], default="shift")
    parser.add_argument("--background", default="chebyschev-1")
    parser.add_argument("--background-terms", type=int, default=8)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project, history = build(args)
    outdir = Path(args.out).resolve()
    (outdir / "history.json").write_text(json.dumps(history, indent=2, default=str) + "\n")
    final = diagnostics(project, "final")
    summary = {
        "arguments": vars(args),
        "final": final,
        "project": str(Path(project.filename).name),
    }
    (outdir / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
