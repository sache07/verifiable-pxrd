"""Test a coordinate or isotropic-displacement block with the full model fixed in scope."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def atom_record(atom):
    rec = {
        "label": atom.label,
        "element": atom.element,
        "coordinates": list(atom.coordinates),
        "occupancy": atom.occupancy,
        "flags": atom.refinement_flags,
    }
    try:
        rec["uiso"] = atom.uiso
    except Exception:
        rec["uiso"] = None
    return rec


def snapshot(proj, stage):
    hist = proj.histogram(0)
    rec = {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": proj.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
        "atoms": {phase.name: [atom_record(a) for a in phase.atoms()] for phase in proj.phases()},
    }
    print("ATOMIC_BLOCK " + json.dumps(rec, sort_keys=True))
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--phase", required=True)
    selector = ap.add_mutually_exclusive_group(required=True)
    selector.add_argument("--element")
    selector.add_argument("--labels", nargs="+")
    ap.add_argument("--kind", choices=("coordinates", "uiso"), default="coordinates")
    ap.add_argument("--max-cyc", type=int, default=8)
    ap.add_argument("--passes", type=int, default=2)
    args = ap.parse_args()

    outdir = ROOT / "trials" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    proj = G2sc.G2Project(str(ROOT / args.base), newgpx=str(outdir / "branch.gpx"))
    controls = proj.data["Controls"]["data"]
    controls["max cyc"] = args.max_cyc
    controls["min dM/M"] = 1.0e-6
    phase = proj.phase(args.phase)
    if phase is None:
        raise ValueError(args.phase)
    selected = []
    for atom in phase.atoms():
        match = atom.element == args.element if args.element else atom.label in args.labels
        if match:
            atom.refinement_flags = "X" if args.kind == "coordinates" else "U"
            selected.append(atom.label)
    if not selected:
        raise ValueError("atom selector matched no sites")
    proj.save()

    records = []
    for i in range(args.passes):
        proj.refine(makeBack=False)
        proj.save()
        records.append(snapshot(proj, f"pass_{i + 1}"))
    phase.export_CIF(str(outdir / f"{args.phase}.cif"))
    (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
