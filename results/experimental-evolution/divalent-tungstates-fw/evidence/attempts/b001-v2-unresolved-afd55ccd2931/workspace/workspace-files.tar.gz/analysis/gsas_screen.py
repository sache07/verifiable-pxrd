"""Matched low-flexibility GSAS-II comparison of candidate phase inventories.

Run with the GSAS-II Python interpreter. Coordinates and displacement
parameters remain fixed; only scales, cells, a common profile, and optional
isotropic phase broadening are varied.
"""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def summarize(proj, label):
    hist = proj.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    record = {
        "stage": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": proj.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "sample_scale": sample["Scale"][0],
        "zero_deg": inst["Zero"][1],
        "profile": {k: inst[k][1] for k in ("U", "V", "W", "X", "Y", "SH/L")},
        "phases": {},
    }
    for phase in proj.phases():
        hap = phase.data["Histograms"][hist.name]
        record["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    try:
        record["mass_fractions"] = {
            k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        record["mass_fraction_error"] = repr(exc)
    print("SCREEN_STAGE " + json.dumps(record, sort_keys=True, default=float))
    return copy.deepcopy(record)


def run_refinement(proj, label, records):
    proj.refine(makeBack=False)
    proj.save()
    records.append(summarize(proj, label))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--tag", required=True)
    parser.add_argument(
        "--phase",
        action="append",
        nargs=2,
        metavar=("NAME", "CIF"),
        required=True,
        help="Repeat for each phase; first phase is the reference scale.",
    )
    parser.add_argument("--no-broadening", action="store_true")
    parser.add_argument(
        "--stop-after",
        choices=("cells", "zero", "profile_WX", "profile_UVWXY"),
        default=None,
    )
    args = parser.parse_args()

    outdir = ROOT / "trials" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    gpx = outdir / "screen.gpx"
    proj = G2sc.G2Project(newgpx=str(gpx))
    hist = proj.add_powder_histogram(
        str(ROOT / "analysis" / "pattern.xye"),
        str(ROOT / "analysis" / "cu_ka.instprm"),
        fmthint="xye",
    )
    phases = []
    for name, cif in args.phase:
        phases.append(
            proj.add_phase(
                str(ROOT / cif), phasename=name, histograms=[hist], fmthint="CIF"
            )
        )

    controls = proj.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-5
    controls["shift factor"] = 1.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, True]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
                "coeffs": [800.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            },
        }
    )
    for i, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0 if i == 0 else 0.15, i != 0]
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
    proj.save()

    records = []
    run_refinement(proj, "scale_background", records)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    run_refinement(proj, "cells", records)
    if args.stop_after == "cells":
        (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))
        return

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(proj, "zero", records)
    if args.stop_after == "zero":
        (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))
        return

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    run_refinement(proj, "profile_WX", records)
    if args.stop_after == "profile_WX":
        (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))
        return

    hist.set_refinements({"Instrument Parameters": ["U", "V", "Y"]})
    run_refinement(proj, "profile_UVWXY", records)
    if args.stop_after == "profile_UVWXY":
        (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))
        return

    if not args.no_broadening:
        for phase in phases:
            phase.set_HAP_refinements(
                {
                    "Size": {
                        "type": "isotropic",
                        "value": 1.0,
                        "refine": True,
                        "LGmix": {"value": 0.5, "refine": False},
                    }
                },
                [hist],
            )
        run_refinement(proj, "isotropic_size", records)

        for phase in phases:
            phase.set_HAP_refinements(
                {
                    "Mustrain": {
                        "type": "isotropic",
                        "refine": True,
                        "LGmix": {"value": 0.5, "refine": False},
                    }
                },
                [hist],
            )
        run_refinement(proj, "isotropic_size_strain", records)

    (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))
    proj.save()


if __name__ == "__main__":
    main()
