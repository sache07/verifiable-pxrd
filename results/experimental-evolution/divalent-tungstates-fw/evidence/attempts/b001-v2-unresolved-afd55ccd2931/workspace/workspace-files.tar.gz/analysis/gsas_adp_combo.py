"""Joint isotropic-ADP tests while preserving accepted coordinate blocks."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def atom_record(atom):
    rec = {
        "label": atom.label,
        "element": atom.element,
        "coordinates": list(atom.coordinates),
        "flags": atom.refinement_flags,
    }
    try:
        rec["uiso"] = atom.uiso
    except Exception:
        rec["uiso"] = None
    return rec


def snapshot(proj, stage):
    hist = proj.histogram(0)
    return {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": proj.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
        "atoms": {phase.name: [atom_record(a) for a in phase.atoms()] for phase in proj.phases()},
    }


def add_flag(atom, flag):
    flags = atom.refinement_flags.strip()
    if flag not in flags:
        flags += flag
    atom.refinement_flags = flags


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--caw-elements", nargs="*", default=[])
    ap.add_argument("--wo-elements", nargs="*", default=[])
    ap.add_argument("--wo-start", type=float, default=None)
    ap.add_argument("--max-cyc", type=int, default=12)
    ap.add_argument("--passes", type=int, default=2)
    args = ap.parse_args()
    if not args.caw_elements and not args.wo_elements:
        raise ValueError("select at least one ADP block")

    outdir = ROOT / "trials" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    proj = G2sc.G2Project(str(ROOT / args.base), newgpx=str(outdir / "branch.gpx"))
    controls = proj.data["Controls"]["data"]
    controls["max cyc"] = args.max_cyc
    controls["min dM/M"] = 1.0e-6

    for atom in proj.phase("CaWO4").atoms():
        if atom.element in args.caw_elements:
            add_flag(atom, "U")
    for atom in proj.phase("WO3").atoms():
        if atom.element in args.wo_elements:
            if args.wo_start is not None:
                atom.uiso = args.wo_start
            add_flag(atom, "U")
    proj.save()

    records = []
    for i in range(args.passes):
        proj.refine(makeBack=False)
        proj.save()
        rec = snapshot(proj, f"pass_{i + 1}")
        print("ADP_COMBO " + json.dumps(rec, sort_keys=True))
        records.append(rec)
    for name in ("CaWO4", "WO3"):
        proj.phase(name).export_CIF(str(outdir / f"{name}.cif"))
    (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
