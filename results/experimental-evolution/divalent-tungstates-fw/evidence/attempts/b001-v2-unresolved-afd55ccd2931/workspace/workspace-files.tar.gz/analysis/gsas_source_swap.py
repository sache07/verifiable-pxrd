"""Matched restart comparison for alternative WO3 structural sources."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
PHASE_FILES = {
    "CaWO4": ROOT / "refs" / "CaWO4_7219229.cif",
    "CaO": ROOT / "refs" / "CaO_1563196.cif",
    "calcite": ROOT / "refs" / "calcite_1547347.cif",
}


def copy_isotropic_hap(source, target):
    for key in ("Scale", "Extinction", "Babinet"):
        target[key] = copy.deepcopy(source[key])
    for key in ("Size", "Mustrain"):
        target[key][0] = source[key][0]
        target[key][1][:3] = copy.deepcopy(source[key][1][:3])
        target[key][2][:3] = copy.deepcopy(source[key][2][:3])
        target[key][3] = copy.deepcopy(source[key][3])
    target["Pref.Ori."] = copy.deepcopy(source["Pref.Ori."])


def snapshot(proj, stage, source):
    hist = proj.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    rec = {
        "stage": stage,
        "wo3_source": source,
        "Rwp_percent": hist.get_wR(),
        "GOF": proj.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "profile": {k: inst[k][1] for k in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.")},
        "sample": {k: sample[k][0] for k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")},
        "fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
        "cells": {p.name: p.get_cell() for p in proj.phases()},
        "broadening": {
            p.name: {
                "size": p.data["Histograms"][hist.name]["Size"],
                "mustrain": p.data["Histograms"][hist.name]["Mustrain"],
            }
            for p in proj.phases()
        },
    }
    print("SOURCE_STAGE " + json.dumps(rec, sort_keys=True))
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--wo3-cif", required=True)
    ap.add_argument("--wo-size-start", type=float, default=None)
    ap.add_argument("--wo-strain-start", type=float, default=None)
    ap.add_argument("--zero-start", type=float, default=None)
    ap.add_argument("--shift-start", type=float, default=None)
    ap.add_argument("--wo-cell-scale", type=float, default=1.0)
    ap.add_argument("--max-cyc", type=int, default=15)
    ap.add_argument("--passes", type=int, default=3)
    args = ap.parse_args()

    outdir = ROOT / "trials" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    base = G2sc.G2Project(str(ROOT / args.base))
    base_hist = base.histogram(0)
    out = G2sc.G2Project(newgpx=str(outdir / "branch.gpx"))
    hist = out.add_powder_histogram(
        str(ROOT / "analysis" / "pattern.xye"),
        str(ROOT / "analysis" / "cu_ka.instprm"),
        fmthint="xye",
    )
    for key in ("Background", "Instrument Parameters", "Sample Parameters", "Limits", "Peak List"):
        if key in base_hist.data:
            hist.data[key] = copy.deepcopy(base_hist.data[key])

    files = {
        "CaWO4": PHASE_FILES["CaWO4"],
        "WO3": ROOT / args.wo3_cif,
        "CaO": PHASE_FILES["CaO"],
        "calcite": PHASE_FILES["calcite"],
    }
    phases = {}
    for name, path in files.items():
        phases[name] = out.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")

    for name, phase in phases.items():
        source_phase = base.phase(name)
        source_hap = source_phase.data["Histograms"][base_hist.name]
        target_hap = phase.data["Histograms"][hist.name]
        copy_isotropic_hap(source_hap, target_hap)
        if name != "WO3":
            phase.data["General"]["Cell"] = copy.deepcopy(source_phase.data["General"]["Cell"])
        phase.data["General"]["Cell"][0] = True
        for atom in phase.atoms():
            atom.refinement_flags = " "

    wo_hap = phases["WO3"].data["Histograms"][hist.name]
    if args.wo_size_start is not None:
        wo_hap["Size"][1][0] = args.wo_size_start
    if args.wo_strain_start is not None:
        wo_hap["Mustrain"][1][0] = args.wo_strain_start
    if args.wo_cell_scale != 1.0:
        for i in (1, 2, 3):
            phases["WO3"].data["General"]["Cell"][i] *= args.wo_cell_scale
    if args.zero_start is not None:
        hist.data["Instrument Parameters"][0]["Zero"][1] = args.zero_start
    if args.shift_start is not None:
        hist.data["Sample Parameters"]["Shift"][0] = args.shift_start

    controls = out.data["Controls"]["data"]
    controls["max cyc"] = args.max_cyc
    controls["min dM/M"] = 1.0e-6
    controls["shift factor"] = 1.0
    out.save()

    records = []
    for i in range(args.passes):
        out.refine(makeBack=False)
        out.save()
        records.append(snapshot(out, f"restart_pass_{i + 1}", args.wo3_cif))
    (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
