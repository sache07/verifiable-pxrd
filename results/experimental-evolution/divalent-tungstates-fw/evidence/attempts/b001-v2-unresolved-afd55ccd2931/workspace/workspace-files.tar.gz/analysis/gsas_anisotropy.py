"""Matched uniaxial size/microstrain axis screen from an isotropic model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def snapshot(proj, stage):
    hist = proj.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = {}
    for phase in proj.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {"size": hap["Size"], "mustrain": hap["Mustrain"], "cell": phase.get_cell()}
    rec = {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": proj.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "zero_deg": inst["Zero"][1],
        "shift_micrometres": sample["Shift"][0],
        "fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
        "phases": phases,
    }
    print("ANISOTROPY_STAGE " + json.dumps(rec, sort_keys=True))
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--phase", required=True)
    ap.add_argument("--kind", choices=("size", "strain"), required=True)
    ap.add_argument("--axis", nargs=3, type=int, required=True)
    ap.add_argument("--max-cyc", type=int, default=12)
    ap.add_argument("--passes", type=int, default=2)
    args = ap.parse_args()

    outdir = ROOT / "trials" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    proj = G2sc.G2Project(str(ROOT / args.base), newgpx=str(outdir / "branch.gpx"))
    hist = proj.histogram(0)
    controls = proj.data["Controls"]["data"]
    controls["max cyc"] = args.max_cyc
    controls["min dM/M"] = 1.0e-6
    phase = proj.phase(args.phase)
    if phase is None:
        raise ValueError(args.phase)
    hap = phase.data["Histograms"][hist.name]
    item = hap["Size"] if args.kind == "size" else hap["Mustrain"]
    isotropic = item[1][0]
    item[0] = "uniaxial"
    item[1][0] = isotropic
    item[1][1] = isotropic
    item[2] = [False for _ in item[2]]
    item[2][0] = True
    item[2][1] = True
    item[3] = list(args.axis)
    proj.save()

    records = []
    for i in range(args.passes):
        proj.refine(makeBack=False)
        proj.save()
        records.append(snapshot(proj, f"pass_{i + 1}"))
    (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
