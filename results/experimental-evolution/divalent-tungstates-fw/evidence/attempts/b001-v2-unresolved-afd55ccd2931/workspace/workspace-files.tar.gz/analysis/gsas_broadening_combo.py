"""Cumulative positive phase-broadening combinations."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def set_iso(item, value):
    item[0] = "isotropic"
    item[1][0] = value
    item[1][2] = 0.5
    item[2] = [False for _ in item[2]]
    item[2][0] = True


def snapshot(proj, stage):
    hist = proj.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = {}
    for phase in proj.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "cell": phase.get_cell(),
        }
    theta = np.deg2rad(np.linspace(5.0, 50.0, 901))
    sigma2 = inst["U"][1] * np.tan(theta) ** 2 + inst["V"][1] * np.tan(theta) + inst["W"][1]
    gamma = inst["Z"][1] + inst["X"][1] / np.cos(theta) + inst["Y"][1] * np.tan(theta)
    rec = {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": proj.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "profile": {k: inst[k][1] for k in ("U", "V", "W", "X", "Y", "SH/L")},
        "profile_positive": bool(np.all(sigma2 > 0) and np.all(gamma > 0) and inst["SH/L"][1] > 0),
        "zero_deg": inst["Zero"][1],
        "shift_micrometres": sample["Shift"][0],
        "fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
        "phases": phases,
    }
    print("COMBO_STAGE " + json.dumps(rec, sort_keys=True))
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--wo3", choices=("size", "strain", "both"), required=True)
    ap.add_argument("--no-cawo4-strain", action="store_true")
    ap.add_argument("--wo-size-start", type=float, default=0.052)
    ap.add_argument("--wo-strain-start", type=float, default=12000.0)
    ap.add_argument("--caw-strain-start", type=float, default=760.0)
    args = ap.parse_args()

    outdir = ROOT / "trials" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    proj = G2sc.G2Project(str(ROOT / args.base), newgpx=str(outdir / "branch.gpx"))
    hist = proj.histogram(0)
    controls = proj.data["Controls"]["data"]
    controls["max cyc"] = 15
    controls["min dM/M"] = 1.0e-6
    hist.data["Background"][0][1] = True
    sample = hist.data["Sample Parameters"]
    sample["Scale"][1] = True
    sample["Shift"][1] = True
    inst = hist.data["Instrument Parameters"][0]
    for value in inst.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    inst["Zero"][2] = True

    for i, phase in enumerate(proj.phases()):
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = i != 0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        for atom in phase.atoms():
            atom.refinement_flags = " "

    caw = proj.phase("CaWO4").data["Histograms"][hist.name]
    wo = proj.phase("WO3").data["Histograms"][hist.name]
    if not args.no_cawo4_strain:
        set_iso(caw["Mustrain"], args.caw_strain_start)
    if args.wo3 in ("size", "both"):
        set_iso(wo["Size"], args.wo_size_start)
    if args.wo3 in ("strain", "both"):
        set_iso(wo["Mustrain"], args.wo_strain_start)

    proj.save()
    records = []
    for i in range(2):
        proj.refine(makeBack=False)
        proj.save()
        records.append(snapshot(proj, f"broadening_pass_{i + 1}"))
    for key in ("W", "X", "SH/L"):
        inst[key][2] = True
    for i in range(2):
        proj.refine(makeBack=False)
        proj.save()
        records.append(snapshot(proj, f"profile_pass_{i + 1}"))
    (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
