"""Add one candidate to a stabilized GSAS-II model and test it cumulatively."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def snapshot(proj, stage):
    hist = proj.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    result = {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": proj.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "zero_deg": inst["Zero"][1],
        "profile": {k: inst[k][1] for k in ("U", "V", "W", "X", "Y", "SH/L")},
        "phases": {},
    }
    for phase in proj.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
        }
    try:
        result["mass_fractions"] = {
            k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        result["mass_fraction_error"] = repr(exc)
    print("ADD_STAGE " + json.dumps(result, sort_keys=True))
    return copy.deepcopy(result)


def refine(proj, stage, records):
    proj.refine(makeBack=False)
    proj.save()
    records.append(snapshot(proj, stage))


def set_all_fixed(proj):
    hist = proj.histogram(0)
    hist.data["Background"][0][1] = False
    hist.data["Sample Parameters"]["Scale"][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for phase in proj.phases():
        phase.data["General"]["Cell"][0] = False
        phase.data["Histograms"][hist.name]["Scale"][1] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--tag", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--cif", required=True)
    parser.add_argument("--initial-scale", type=float, default=0.1)
    parser.add_argument("--scale-only", action="store_true")
    args = parser.parse_args()

    outdir = ROOT / "trials" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    proj = G2sc.G2Project(str(ROOT / args.base), newgpx=str(outdir / "screen.gpx"))
    hist = proj.histogram(0)
    phase = proj.add_phase(
        str(ROOT / args.cif), phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    controls = proj.data["Controls"]["data"]
    controls["max cyc"] = 10
    controls["min dM/M"] = 1.0e-5
    set_all_fixed(proj)
    phase.data["Histograms"][hist.name]["Scale"] = [args.initial_scale, True]
    proj.save()

    records = []
    refine(proj, "new_scale", records)
    new_fraction = records[-1].get("mass_fractions", {}).get(args.name, [0.0])[0]
    if args.scale_only or new_fraction <= 1.0e-6:
        (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))
        return

    phase.data["General"]["Cell"][0] = True
    refine(proj, "new_scale_cell", records)

    # Re-equilibrate the cumulative model with the same low-flexibility setup.
    hist.data["Background"][0][1] = True
    hist.data["Sample Parameters"]["Scale"][1] = True
    inst = hist.data["Instrument Parameters"][0]
    for key in ("Zero", "W", "X"):
        inst[key][2] = True
    for i, ph in enumerate(proj.phases()):
        ph.data["General"]["Cell"][0] = True
        ph.data["Histograms"][hist.name]["Scale"][1] = i != 0
    refine(proj, "cumulative_profile_WX", records)

    (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
