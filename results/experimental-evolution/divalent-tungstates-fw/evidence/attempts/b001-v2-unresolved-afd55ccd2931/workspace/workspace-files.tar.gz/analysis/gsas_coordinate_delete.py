"""Reset accepted coordinate blocks to their public parent values for deletion tests."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
PARENT = {
    ("CaWO4", "O1"): (0.15202, 0.01135, 0.20864),
    ("WO3", "W1"): (0.028, 0.037, 0.746),
    ("WO3", "W2"): (0.534, 0.023, 0.750),
    ("WO3", "O4"): (0.519, 0.259, 0.789),
    ("WO3", "O6"): (0.714, 0.487, 0.721),
}


def reset(phase, labels):
    for atom in phase.atoms():
        if atom.label in labels:
            atom.coordinates = PARENT[(phase.name, atom.label)]
            atom.refinement_flags = atom.refinement_flags.replace("X", "").strip() or " "


def snapshot(proj, stage):
    hist = proj.histogram(0)
    return {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": proj.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
        "coordinates": {
            phase.name: {a.label: list(a.coordinates) for a in phase.atoms()}
            for phase in proj.phases()
        },
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--drop-caw-o", action="store_true")
    ap.add_argument("--drop-wo-w", action="store_true")
    ap.add_argument("--drop-wo-o46", action="store_true")
    ap.add_argument("--max-cyc", type=int, default=12)
    ap.add_argument("--passes", type=int, default=2)
    args = ap.parse_args()
    if not (args.drop_caw_o or args.drop_wo_w or args.drop_wo_o46):
        raise ValueError("select at least one coordinate block")

    outdir = ROOT / "trials" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    proj = G2sc.G2Project(str(ROOT / args.base), newgpx=str(outdir / "branch.gpx"))
    controls = proj.data["Controls"]["data"]
    controls["max cyc"] = args.max_cyc
    controls["min dM/M"] = 1.0e-6
    if args.drop_caw_o:
        reset(proj.phase("CaWO4"), {"O1"})
    if args.drop_wo_w:
        reset(proj.phase("WO3"), {"W1", "W2"})
    if args.drop_wo_o46:
        reset(proj.phase("WO3"), {"O4", "O6"})
    proj.save()

    records = []
    for i in range(args.passes):
        proj.refine(makeBack=False)
        proj.save()
        rec = snapshot(proj, f"pass_{i + 1}")
        print("COORD_DELETE " + json.dumps(rec, sort_keys=True))
        records.append(rec)
    (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
