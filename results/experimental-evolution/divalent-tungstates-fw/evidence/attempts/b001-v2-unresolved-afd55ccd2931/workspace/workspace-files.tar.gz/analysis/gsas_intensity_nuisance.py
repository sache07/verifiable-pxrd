"""Matched polarization and Bragg-Brentano surface-roughness trials."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def roughness_correction(a, b):
    tth = np.linspace(10.0, 100.0, 901)
    sth = np.sin(np.deg2rad(tth / 2.0))
    den = a + (1.0 - a) * np.exp(-b)
    corr = (a + (1.0 - a) * np.exp(-b / sth)) / den
    return [float(corr.min()), float(corr.max()), float(corr[100])]


def snapshot(proj, stage):
    hist = proj.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    a, b = sample["SurfRoughA"][0], sample["SurfRoughB"][0]
    rec = {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": proj.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "polarization": inst["Polariz."][1],
        "roughness_A_B": [a, b],
        "roughness_correction_min_max_at20": roughness_correction(a, b) if b != 0 or a != 0 else [1.0, 1.0, 1.0],
        "zero_deg": inst["Zero"][1],
        "shift_micrometres": sample["Shift"][0],
        "fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
        "cells": {p.name: p.get_cell() for p in proj.phases()},
    }
    print("INTENSITY_STAGE " + json.dumps(rec, sort_keys=True))
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--polarization", action="store_true")
    ap.add_argument("--polarization-start", type=float, default=0.8)
    ap.add_argument("--roughness", action="store_true")
    ap.add_argument("--roughness-start", nargs=2, type=float, default=(0.2, 0.1))
    ap.add_argument("--roughness-mode", choices=("both", "A", "B"), default="both")
    args = ap.parse_args()
    if not args.polarization and not args.roughness:
        raise ValueError("select a nuisance mechanism")

    outdir = ROOT / "trials" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    proj = G2sc.G2Project(str(ROOT / args.base), newgpx=str(outdir / "branch.gpx"))
    hist = proj.histogram(0)
    controls = proj.data["Controls"]["data"]
    controls["max cyc"] = 15
    controls["min dM/M"] = 1.0e-6
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    inst["Polariz."][1] = args.polarization_start
    inst["Polariz."][2] = args.polarization
    refine_a = args.roughness and args.roughness_mode in ("both", "A")
    refine_b = args.roughness and args.roughness_mode in ("both", "B")
    sample["SurfRoughA"] = [args.roughness_start[0], refine_a]
    sample["SurfRoughB"] = [args.roughness_start[1], refine_b]
    proj.save()

    records = []
    for i in range(2):
        proj.refine(makeBack=False)
        proj.save()
        records.append(snapshot(proj, f"pass_{i + 1}"))
    (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
