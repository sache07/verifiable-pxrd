"""Matched background-family/order trials on a stabilized GSAS-II model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def design_matrix(family, order, x, wavelength):
    if family == "chebyschev-1":
        xpos = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
        return np.column_stack([np.cos(i * np.arccos(xpos)) for i in range(order)])
    if family == "cosine":
        return np.column_stack([np.cos(np.pi * x * i / x[-1]) for i in range(order)])
    if family in ("Q^-2 power series", "Q^2 power series"):
        q = 4.0 * np.pi * np.sin(np.deg2rad(x / 2.0)) / wavelength
        cols = [np.ones_like(x)]
        term = np.ones_like(x)
        for i in range(order - 1):
            if family == "Q^-2 power series":
                term = term * (i + 1) * q ** -2
            else:
                term = term * q**2 / (i + 1)
            cols.append(term.copy())
        return np.column_stack(cols)
    raise ValueError(family)


def snapshot(proj, stage):
    hist = proj.histogram(0)
    x, y, w, yc, yb = hist.data["data"][1][:5]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    rec = {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": proj.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "background": hist.data["Background"][0],
        "background_min_max": [float(np.min(yb)), float(np.max(yb))],
        "zero_deg": inst["Zero"][1],
        "shift_micrometres": sample["Shift"][0],
        "fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
        "cells": {p.name: p.get_cell() for p in proj.phases()},
    }
    print("BACKGROUND_STAGE " + json.dumps(rec, sort_keys=True))
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument(
        "--family",
        choices=("chebyschev-1", "cosine", "Q^-2 power series", "Q^2 power series"),
        required=True,
    )
    ap.add_argument("--order", type=int, required=True)
    args = ap.parse_args()

    outdir = ROOT / "trials" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    proj = G2sc.G2Project(str(ROOT / args.base), newgpx=str(outdir / "branch.gpx"))
    hist = proj.histogram(0)
    controls = proj.data["Controls"]["data"]
    controls["max cyc"] = 15
    controls["min dM/M"] = 1.0e-6

    x, _, _, _, yb = hist.data["data"][1][:5]
    wavelength = hist.data["Instrument Parameters"][0]["Lam1"][1]
    matrix = design_matrix(args.family, args.order, np.asarray(x), wavelength)
    coeffs = np.linalg.lstsq(matrix, np.asarray(yb), rcond=None)[0]
    hist.set_refinements(
        {
            "Background": {
                "type": args.family,
                "refine": True,
                "no. coeffs": args.order,
                "coeffs": coeffs.tolist(),
            }
        }
    )
    hist.data["Sample Parameters"]["Scale"][1] = True
    hist.data["Sample Parameters"]["Shift"][1] = True
    inst = hist.data["Instrument Parameters"][0]
    for value in inst.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for key in ("Zero", "W", "X"):
        inst[key][2] = True
    for i, phase in enumerate(proj.phases()):
        phase.data["General"]["Cell"][0] = True
        phase.data["Histograms"][hist.name]["Scale"][1] = i != 0
        for atom in phase.atoms():
            atom.refinement_flags = " "
    proj.save()

    records = []
    for i in range(2):
        proj.refine(makeBack=False)
        proj.save()
        records.append(snapshot(proj, f"pass_{i + 1}"))
    (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
