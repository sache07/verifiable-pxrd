"""Package the independent forward replay into fit.csv and result.json."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
REPLAY = ROOT / "analysis" / "replay_output"


def main():
    replay = json.loads((REPLAY / "replay.json").read_text())
    snapshot = json.loads((ROOT / "analysis" / "final_snapshot.json").read_text())
    with np.load(REPLAY / "prediction.npz", allow_pickle=False) as data:
        x = data["x"].astype(float)
        observed = data["observed"].astype(float)
        calculated = data["predicted"].astype(float)
        background = data["background"].astype(float)
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference, background)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference_observed_minus_calculated,background",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f", "%.8f"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi2 = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    nobs = len(observed)
    nvars = int(snapshot["fit_statistics_saved_profile"]["n_refined_variables"])
    dof = nobs - nvars
    fit_statistics = {
        "Rwp_percent": float(100.0 * np.sqrt(chi2 / denominator)),
        "Rp_percent": float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed))),
        "Rexp_percent": float(100.0 * np.sqrt(dof / denominator)),
        "GOF": float(np.sqrt(chi2 / dof)),
        "weighted_chi_square": chi2,
        "n_observations": nobs,
        "n_refined_variables": nvars,
        "weighting": "Poisson, w = 1/max(observed_counts, 1)",
        "evaluation_range_two_theta_deg": [float(x[0]), float(x[-1])],
        "calculation": "independent zero-optimization replay from final.gpx",
    }

    labels = {
        "CaWO4": ("CaWO4", "scheelite calcium tungstate", "phase_CaWO4.cif"),
        "WO3": ("WO3", "monoclinic tungsten(VI) oxide", "phase_WO3.cif"),
        "CaO": ("CaO", "calcium oxide (lime)", "phase_CaO.cif"),
        "calcite": ("CaCO3", "calcite", "phase_calcite.cif"),
    }
    replay_by_name = {phase["name"]: phase for phase in replay["phases"]}
    phases = []
    for name in ("CaWO4", "WO3", "CaO", "calcite"):
        formula, identification, cif = labels[name]
        phase = replay_by_name[name]
        esd = snapshot["phases"][name]["weight_fraction_esd"]
        phases.append(
            {
                "name": name,
                "formula": formula,
                "identification": identification,
                "cif_path": cif,
                "weight_fraction": float(phase["weight_fraction"]),
                "weight_fraction_esd": float(esd),
            }
        )
    result = {
        "project_path": "final.gpx",
        "refinement_histogram": replay["histogram"],
        "weight_fraction_basis": "normalized over the modeled crystalline phases; no amorphous fraction determined",
        "phases": phases,
        "fit_statistics": fit_statistics,
        "saved_refinement_range_fit_statistics": snapshot["fit_statistics_saved_profile"],
        "independent_replay": {
            "status": replay["status"],
            "project_sha256": replay["project_sha256"],
            "parameters_optimized": replay["parameters_optimized"],
            "project_unchanged": replay["project_unchanged"],
            "profile_review_flags": replay["profile_review_flags"],
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, sort_keys=False) + "\n")


if __name__ == "__main__":
    main()
