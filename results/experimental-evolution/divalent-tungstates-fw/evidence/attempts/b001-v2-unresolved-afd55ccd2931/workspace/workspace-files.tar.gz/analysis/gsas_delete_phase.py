"""Rebuild and refine a cumulative model with selected phases deleted."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
PHASE_FILES = {
    "CaWO4": ROOT / "refs" / "CaWO4_7219229.cif",
    "WO3": ROOT / "refs" / "WO3_2311041.cif",
    "CaO": ROOT / "refs" / "CaO_1563196.cif",
    "calcite": ROOT / "refs" / "calcite_1547347.cif",
}


def snapshot(proj, stage):
    hist = proj.histogram(0)
    rec = {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": proj.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
        "cells": {p.name: p.get_cell() for p in proj.phases()},
    }
    print("DELETE_PHASE " + json.dumps(rec, sort_keys=True))
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--delete", nargs="+", required=True)
    ap.add_argument("--max-cyc", type=int, default=12)
    ap.add_argument("--passes", type=int, default=2)
    args = ap.parse_args()
    deleted = set(args.delete)

    outdir = ROOT / "trials" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    base = G2sc.G2Project(str(ROOT / args.base))
    base_hist = base.histogram(0)
    out = G2sc.G2Project(newgpx=str(outdir / "branch.gpx"))
    hist = out.add_powder_histogram(
        str(ROOT / "analysis" / "pattern.xye"),
        str(ROOT / "analysis" / "cu_ka.instprm"),
        fmthint="xye",
    )
    for key in ("Background", "Instrument Parameters", "Sample Parameters", "Limits", "Peak List"):
        if key in base_hist.data:
            hist.data[key] = copy.deepcopy(base_hist.data[key])

    for name in PHASE_FILES:
        if name in deleted:
            continue
        source = base.phase(name)
        target = out.add_phase(str(PHASE_FILES[name]), phasename=name, histograms=[hist], fmthint="CIF")
        target_pid = target.data["pId"]
        source_data = copy.deepcopy(source.data)
        source_hap = source_data["Histograms"].pop(base_hist.name)
        source_data["Histograms"] = {hist.name: source_hap}
        target.data.clear()
        target.data.update(source_data)
        target.data["pId"] = target_pid
        target.data["General"]["Name"] = name

    out.data["Controls"]["data"] = copy.deepcopy(base.data["Controls"]["data"])
    controls = out.data["Controls"]["data"]
    controls["max cyc"] = args.max_cyc
    controls["min dM/M"] = 1.0e-6
    out.save()

    records = []
    for i in range(args.passes):
        out.refine(makeBack=False)
        out.save()
        records.append(snapshot(out, f"pass_{i + 1}"))
    (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
