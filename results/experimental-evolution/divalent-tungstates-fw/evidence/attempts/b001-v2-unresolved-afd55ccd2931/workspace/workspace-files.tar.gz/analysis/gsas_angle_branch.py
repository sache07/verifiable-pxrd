"""Matched zero/specimen-displacement branches for a stabilized project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def state(proj, label):
    hist = proj.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    x, y, w, yc = hist.data["data"][1][:4]
    rec = {
        "stage": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": proj.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "weighted_curve_rms_percent": float(np.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y**2)) * 100),
        "zero_deg": inst["Zero"][1],
        "shift_micrometres": sample["Shift"][0],
        "profile": {k: inst[k][1] for k in ("U", "V", "W", "X", "Y", "SH/L")},
        "cells": {p.name: p.get_cell() for p in proj.phases()},
        "mass_fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
    }
    print("ANGLE_STAGE " + json.dumps(rec, sort_keys=True))
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--branch", choices=("zero", "shift", "joint"), required=True)
    ap.add_argument("--zero-start", type=float, default=0.0)
    ap.add_argument("--shift-start", type=float, default=0.0)
    args = ap.parse_args()

    outdir = ROOT / "trials" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    proj = G2sc.G2Project(str(ROOT / args.base), newgpx=str(outdir / "branch.gpx"))
    hist = proj.histogram(0)
    controls = proj.data["Controls"]["data"]
    controls["max cyc"] = 15
    controls["min dM/M"] = 1.0e-6
    controls["shift factor"] = 1.0

    hist.data["Background"][0][1] = True
    sample = hist.data["Sample Parameters"]
    sample["Scale"][1] = True
    sample["Shift"] = [args.shift_start, args.branch in ("shift", "joint")]
    inst = hist.data["Instrument Parameters"][0]
    for value in inst.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    inst["Zero"] = [inst["Zero"][0], args.zero_start, args.branch in ("zero", "joint")]
    inst["W"][2] = True
    inst["X"][2] = True

    for i, phase in enumerate(proj.phases()):
        phase.data["General"]["Cell"][0] = True
        phase.data["Histograms"][hist.name]["Scale"][1] = i != 0
        for atom in phase.atoms():
            atom.refinement_flags = " "
    proj.save()

    records = []
    for i in range(2):
        proj.refine(makeBack=False)
        proj.save()
        records.append(state(proj, f"pass_{i + 1}"))
    (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
