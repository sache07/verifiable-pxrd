"""Continue a GSAS-II refinement without changing the active model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def snapshot(proj, stage):
    hist = proj.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = {}
    for phase in proj.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    rec = {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": proj.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "zero_deg": inst["Zero"][1],
        "shift_micrometres": sample["Shift"][0],
        "roughness_A_B": [sample["SurfRoughA"][0], sample["SurfRoughB"][0]],
        "polarization": inst["Polariz."][1],
        "fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
        "phases": phases,
    }
    print("CONTINUE_STAGE " + json.dumps(rec, sort_keys=True))
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--max-cyc", type=int, default=12)
    ap.add_argument("--passes", type=int, default=2)
    args = ap.parse_args()

    outdir = ROOT / "trials" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    proj = G2sc.G2Project(str(ROOT / args.base), newgpx=str(outdir / "branch.gpx"))
    controls = proj.data["Controls"]["data"]
    controls["max cyc"] = args.max_cyc
    controls["min dM/M"] = 1.0e-6
    proj.save()

    records = []
    for i in range(args.passes):
        proj.refine(makeBack=False)
        proj.save()
        records.append(snapshot(proj, f"pass_{i + 1}"))
    (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
