"""One-at-a-time phase-size or microstrain screening on a cumulative model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def snapshot(proj, stage):
    hist = proj.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = {}
    for phase in proj.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "cell": phase.get_cell(),
        }
    rec = {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": proj.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "profile": {k: inst[k][1] for k in ("U", "V", "W", "X", "Y", "SH/L")},
        "zero_deg": inst["Zero"][1],
        "shift_micrometres": sample["Shift"][0],
        "fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
        "phases": phases,
    }
    print("BROADENING_STAGE " + json.dumps(rec, sort_keys=True))
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--phase", required=True)
    ap.add_argument("--kind", choices=("size_iso", "strain_iso", "size_uniaxial", "strain_uniaxial"), required=True)
    ap.add_argument("--start", type=float, default=None)
    ap.add_argument("--axis", nargs=3, type=int, default=(0, 0, 1))
    ap.add_argument("--reequilibrate-profile", action="store_true")
    args = ap.parse_args()

    outdir = ROOT / "trials" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    proj = G2sc.G2Project(str(ROOT / args.base), newgpx=str(outdir / "branch.gpx"))
    hist = proj.histogram(0)
    controls = proj.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-6

    hist.data["Background"][0][1] = True
    sample = hist.data["Sample Parameters"]
    sample["Scale"][1] = True
    sample["Shift"][1] = True
    inst = hist.data["Instrument Parameters"][0]
    for value in inst.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    inst["Zero"][2] = True

    selected = proj.phase(args.phase)
    if selected is None:
        raise ValueError(args.phase)
    for i, phase in enumerate(proj.phases()):
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = i != 0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        for atom in phase.atoms():
            atom.refinement_flags = " "

    hap = selected.data["Histograms"][hist.name]
    if args.kind.startswith("size"):
        item = hap["Size"]
        start = 0.5 if args.start is None else args.start
    else:
        item = hap["Mustrain"]
        start = 1000.0 if args.start is None else args.start
    if args.kind.endswith("iso"):
        item[0] = "isotropic"
        item[1][0] = start
        item[1][2] = 0.5
        item[2][0] = True
        item[2][2] = False
    else:
        item[0] = "uniaxial"
        item[1][0] = start
        item[1][1] = start
        item[1][2] = 0.5
        item[2][0] = True
        item[2][1] = True
        item[2][2] = False
        item[3] = list(args.axis)

    proj.save()
    records = []
    for i in range(2):
        proj.refine(makeBack=False)
        proj.save()
        records.append(snapshot(proj, f"screen_pass_{i + 1}"))
    if args.reequilibrate_profile:
        for key in ("W", "X", "SH/L"):
            inst[key][2] = True
        proj.refine(makeBack=False)
        proj.save()
        records.append(snapshot(proj, "profile_reequilibrated"))
    (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
