"""Matched deletion tests for weak nuisance/profile terms in the final model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def snapshot(proj, stage):
    hist = proj.histogram(0)
    caw = proj.phase("CaWO4").data["Histograms"][hist.name]
    cal = proj.phase("calcite").data["Histograms"][hist.name]
    rec = {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": proj.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "nvars": len(proj.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
        "background_terms": hist.data["Background"][0][2],
        "cawo4_texture": caw["Pref.Ori."],
        "calcite_strain": cal["Mustrain"],
    }
    print("SIMPLIFY " + json.dumps(rec, sort_keys=True))
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--drop-caw-texture", action="store_true")
    ap.add_argument("--drop-calcite-strain", action="store_true")
    ap.add_argument("--background-terms", type=int, default=None)
    ap.add_argument("--max-cyc", type=int, default=12)
    ap.add_argument("--passes", type=int, default=2)
    args = ap.parse_args()

    outdir = ROOT / "trials" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    proj = G2sc.G2Project(str(ROOT / args.base), newgpx=str(outdir / "branch.gpx"))
    hist = proj.histogram(0)
    controls = proj.data["Controls"]["data"]
    controls["max cyc"] = args.max_cyc
    controls["min dM/M"] = 1.0e-6
    if args.drop_caw_texture:
        po = proj.phase("CaWO4").data["Histograms"][hist.name]["Pref.Ori."]
        po[1] = 1.0
        po[2] = False
    if args.drop_calcite_strain:
        strain = proj.phase("calcite").data["Histograms"][hist.name]["Mustrain"]
        strain[0] = "isotropic"
        strain[1][0] = 0.0
        strain[2] = [False for _ in strain[2]]
    if args.background_terms is not None:
        background = hist.data["Background"][0]
        if args.background_terms < 1 or args.background_terms > background[2]:
            raise ValueError("background term count must reduce the current model")
        background[2] = args.background_terms
        del background[3 + args.background_terms :]
    proj.save()

    records = []
    for i in range(args.passes):
        proj.refine(makeBack=False)
        proj.save()
        records.append(snapshot(proj, f"pass_{i + 1}"))
    (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
