"""Enable one isotropic phase-broadening term while preserving the full model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def snapshot(proj, stage):
    hist = proj.histogram(0)
    rec = {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": proj.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
        "broadening": {
            phase.name: {
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in proj.phases()
        },
    }
    print("BROADENING_RETEST " + json.dumps(rec, sort_keys=True))
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--phase", required=True)
    ap.add_argument("--kind", choices=("size", "strain"), required=True)
    ap.add_argument("--start", type=float, required=True)
    ap.add_argument("--max-cyc", type=int, default=6)
    ap.add_argument("--passes", type=int, default=1)
    args = ap.parse_args()

    outdir = ROOT / "trials" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    proj = G2sc.G2Project(str(ROOT / args.base), newgpx=str(outdir / "branch.gpx"))
    hist = proj.histogram(0)
    controls = proj.data["Controls"]["data"]
    controls["max cyc"] = args.max_cyc
    controls["min dM/M"] = 1.0e-6
    phase = proj.phase(args.phase)
    if phase is None:
        raise ValueError(args.phase)
    hap = phase.data["Histograms"][hist.name]
    item = hap["Size"] if args.kind == "size" else hap["Mustrain"]
    item[0] = "isotropic"
    item[1][0] = args.start
    item[2] = [False for _ in item[2]]
    item[2][0] = True
    proj.save()

    records = []
    for i in range(args.passes):
        proj.refine(makeBack=False)
        proj.save()
        records.append(snapshot(proj, f"pass_{i + 1}"))
    (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
