from pathlib import Path

import numpy as np


root = Path(__file__).resolve().parents[1]
data = np.loadtxt(root / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
x, y = data.T
sigma = np.sqrt(np.clip(y, 1.0, None))
np.savetxt(
    root / "analysis" / "pattern.xye",
    np.column_stack((x, y, sigma)),
    fmt=("%.8f", "%.8f", "%.8f"),
    header="two_theta_deg intensity sigma_poisson",
)
