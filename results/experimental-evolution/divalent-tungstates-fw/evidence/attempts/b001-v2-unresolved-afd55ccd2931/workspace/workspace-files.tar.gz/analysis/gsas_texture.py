"""Matched March-Dollase preferred-orientation axis screen."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def snapshot(proj, stage):
    hist = proj.histogram(0)
    rec = {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": proj.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
        "texture": {
            phase.name: phase.data["Histograms"][hist.name]["Pref.Ori."]
            for phase in proj.phases()
        },
    }
    print("TEXTURE_STAGE " + json.dumps(rec, sort_keys=True))
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--phase", required=True)
    ap.add_argument("--axis", nargs=3, type=int, required=True)
    ap.add_argument("--start", type=float, default=1.0)
    ap.add_argument("--max-cyc", type=int, default=6)
    ap.add_argument("--passes", type=int, default=1)
    args = ap.parse_args()

    outdir = ROOT / "trials" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    proj = G2sc.G2Project(str(ROOT / args.base), newgpx=str(outdir / "branch.gpx"))
    hist = proj.histogram(0)
    controls = proj.data["Controls"]["data"]
    controls["max cyc"] = args.max_cyc
    controls["min dM/M"] = 1.0e-6
    phase = proj.phase(args.phase)
    if phase is None:
        raise ValueError(args.phase)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = args.start
    po[2] = True
    po[3] = list(args.axis)
    proj.save()

    records = []
    for i in range(args.passes):
        proj.refine(makeBack=False)
        proj.save()
        records.append(snapshot(proj, f"pass_{i + 1}"))
    (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
