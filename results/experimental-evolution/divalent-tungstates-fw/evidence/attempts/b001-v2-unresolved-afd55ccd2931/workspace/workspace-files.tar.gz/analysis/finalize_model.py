"""Create the submission GPX and CIFs from the independently reproduced model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    args = ap.parse_args()

    proj = G2sc.G2Project(str(ROOT / args.base), newgpx=str(ROOT / "final.gpx"))
    controls = proj.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-6
    proj.save()
    proj.refine(makeBack=False)
    proj.save()

    hist = proj.histogram(0)
    x = np.asarray(hist.getdata("x"), dtype=float)
    yobs = np.asarray(hist.getdata("yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("ycalc"), dtype=float)
    weights = np.asarray(hist.getdata("yweight"), dtype=float)
    lo, hi = hist.data["Limits"][1]
    used = (x >= lo) & (x <= hi) & (weights > 0)
    residual = yobs - ycalc
    chi2 = float(np.sum(weights[used] * residual[used] ** 2))
    denominator = float(np.sum(weights[used] * yobs[used] ** 2))
    nobs = int(np.count_nonzero(used))
    nvars = len(proj.data.get("Covariance", {}).get("data", {}).get("varyList", []))
    dof = nobs - nvars
    stats = {
        "Rwp_percent": float(100.0 * np.sqrt(chi2 / denominator)),
        "Rp_percent": float(100.0 * np.sum(np.abs(residual[used])) / np.sum(np.abs(yobs[used]))),
        "Rexp_percent": float(100.0 * np.sqrt(dof / denominator)),
        "GOF": float(np.sqrt(chi2 / dof)),
        "weighted_chi_square": chi2,
        "n_observations": nobs,
        "n_refined_variables": nvars,
        "fit_range_two_theta_deg": [float(lo), float(hi)],
    }
    mass = hist.ComputeMassFracs()
    phase_files = {}
    phase_details = {}
    for phase in proj.phases():
        filename = f"phase_{phase.name}.cif"
        phase.export_CIF(str(ROOT / filename))
        phase_files[phase.name] = filename
        hap = phase.data["Histograms"][hist.name]
        phase_details[phase.name] = {
            "cif": filename,
            "weight_fraction": float(mass[phase.name][0]),
            "weight_fraction_esd": float(mass[phase.name][1]),
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    snapshot = {
        "histogram": hist.name,
        "fit_statistics_saved_profile": stats,
        "phases": phase_details,
        "profile": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
    }
    (ROOT / "analysis" / "final_snapshot.json").write_text(
        json.dumps(snapshot, indent=2, sort_keys=True, default=lambda value: value.tolist()) + "\n"
    )
    print("FINAL_MODEL " + json.dumps(snapshot, sort_keys=True, default=lambda value: value.tolist()))


if __name__ == "__main__":
    main()
