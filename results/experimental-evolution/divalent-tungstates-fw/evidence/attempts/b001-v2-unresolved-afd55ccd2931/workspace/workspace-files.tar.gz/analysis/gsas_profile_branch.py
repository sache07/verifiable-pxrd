"""Matched common-profile and axial-divergence trials."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def profile_screen(inst):
    two_theta = np.linspace(10.0, 100.0, 901)
    theta = np.deg2rad(two_theta / 2.0)
    sigma2 = inst["U"][1] * np.tan(theta) ** 2 + inst["V"][1] * np.tan(theta) + inst["W"][1]
    gamma = inst["Z"][1] + inst["X"][1] / np.cos(theta) + inst["Y"][1] * np.tan(theta)
    return {
        "sigma2_min_max_centideg2": [float(sigma2.min()), float(sigma2.max())],
        "gamma_min_max_centideg": [float(gamma.min()), float(gamma.max())],
        "positive_over_range": bool(np.all(sigma2 > 0) and np.all(gamma > 0) and inst["SH/L"][1] > 0),
    }


def snapshot(proj, stage):
    hist = proj.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    rec = {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": proj.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "profile": {k: inst[k][1] for k in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
        "profile_screen": profile_screen(inst),
        "zero_deg": inst["Zero"][1],
        "shift_micrometres": sample["Shift"][0],
        "fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
        "cells": {p.name: p.get_cell() for p in proj.phases()},
    }
    print("PROFILE_STAGE " + json.dumps(rec, sort_keys=True))
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--terms", required=True, help="Comma-separated terms among U,V,W,X,Y,SH/L")
    ap.add_argument("--shl-start", type=float, default=None)
    args = ap.parse_args()

    terms = [x.strip() for x in args.terms.split(",") if x.strip()]
    allowed = {"U", "V", "W", "X", "Y", "SH/L"}
    if not set(terms) <= allowed:
        raise ValueError(set(terms) - allowed)

    outdir = ROOT / "trials" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    proj = G2sc.G2Project(str(ROOT / args.base), newgpx=str(outdir / "branch.gpx"))
    hist = proj.histogram(0)
    controls = proj.data["Controls"]["data"]
    controls["max cyc"] = 15
    controls["min dM/M"] = 1.0e-6

    hist.data["Background"][0][1] = True
    sample = hist.data["Sample Parameters"]
    sample["Scale"][1] = True
    sample["Shift"][1] = True
    inst = hist.data["Instrument Parameters"][0]
    if args.shl_start is not None:
        inst["SH/L"][1] = args.shl_start
    for value in inst.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    inst["Zero"][2] = True
    for key in terms:
        inst[key][2] = True
    for i, phase in enumerate(proj.phases()):
        phase.data["General"]["Cell"][0] = True
        phase.data["Histograms"][hist.name]["Scale"][1] = i != 0
        for atom in phase.atoms():
            atom.refinement_flags = " "
    proj.save()

    records = []
    for i in range(2):
        proj.refine(makeBack=False)
        proj.save()
        records.append(snapshot(proj, f"pass_{i + 1}"))
    (outdir / "summary.json").write_text(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
