import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


p = argparse.ArgumentParser()
p.add_argument("fit", type=Path)
p.add_argument("--output", type=Path)
args = p.parse_args()
d = np.genfromtxt(args.fit, delimiter=",", names=True)
x = d["two_theta_deg"]
y = d["observed"]
yc = d["calculated"]
diff = d["difference"]
bkg = d["background"] if "background" in d.dtype.names else np.zeros_like(x)

fig, axes = plt.subplots(3, 1, figsize=(16, 10), sharex=True, gridspec_kw={"height_ratios": [2, 1, 1]})
axes[0].plot(x, y, color="black", lw=0.65, label="Observed")
axes[0].plot(x, yc, color="tab:red", lw=0.7, label="Calculated")
axes[0].plot(x, bkg, color="tab:blue", lw=0.7, label="Background")
axes[0].legend(loc="upper right")
axes[0].set_ylabel("Counts")
axes[1].plot(x, diff, color="tab:blue", lw=0.65)
axes[1].axhline(0, color="black", lw=0.5)
axes[1].set_ylabel("Obs. - calc.")
axes[2].plot(x, diff / np.sqrt(np.maximum(y, 1.0)), color="black", lw=0.55)
axes[2].axhline(0, color="tab:red", lw=0.5)
axes[2].set_ylabel("Weighted residual")
axes[2].set_xlabel(r"$2\theta$ (deg)")
fig.tight_layout()
out = args.output or args.fit.with_suffix(".png")
fig.savefig(out, dpi=160)
