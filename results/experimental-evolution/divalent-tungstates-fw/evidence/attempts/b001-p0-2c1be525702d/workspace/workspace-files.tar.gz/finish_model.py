"""Final low-risk convergence of the accepted structural/profile model."""

import argparse
import json
import math
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_groups import freeze_all, phase_fractions


p = argparse.ArgumentParser()
p.add_argument("source", type=Path)
p.add_argument("out", type=Path)
args = p.parse_args()
args.out.mkdir(parents=True, exist_ok=True)
destination = (args.out / "finished.gpx").resolve()
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(destination))
hist = project.histogram(0)
log = []


def row(stage, accepted=True):
    result = {
        "stage": stage,
        "accepted": accepted,
        "rwp": float(hist.get_wR()),
        "fractions": phase_fractions(project, hist),
    }
    print(json.dumps(result))
    return result


log.append(row("loaded"))


def bg_scale():
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])


def run(name, setup, cycles=5):
    global project, hist
    freeze_all(project, hist)
    setup()
    project.save()
    checkpoint = args.out / f"before_{name}.gpx"
    shutil.copy2(destination, checkpoint)
    before = float(hist.get_wR())
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.data["Controls"]["data"]["shift factor"] = 0.4
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    project.save()
    after = float(hist.get_wR())
    if math.isfinite(after) and after <= before:
        log.append(row(name, True))
    else:
        log.append(row(name + "_rejected", False))
        project = G2.G2Project(
            gpxfile=str(checkpoint.resolve()), newgpx=str(destination)
        )
        hist = project.histogram(0)
        log.append(row(name + "_rollback", True))


run("background_scales", bg_scale, 5)


def cells():
    bg_scale()
    for phase in project.phases():
        phase.set_refinements({"Cell": True})


run("cells_background_scales", cells, 4)


def specimen():
    bg_scale()
    hist.set_refinements(
        {
            "Instrument Parameters": ["Zero", "Polariz.", "SH/L"],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    project.phase(1).set_HAP_refinements({"Pref.Ori.": True}, histograms=[hist])


run("specimen_texture", specimen, 5)
run("final_background_scales", bg_scale, 4)

freeze_all(project, hist)
project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
project.save()
(args.out / "stages.json").write_text(json.dumps(log, indent=2) + "\n")
