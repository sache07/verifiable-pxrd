"""Freeze the accepted GSAS-II model and export all requested deliverables."""

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_groups import freeze_all, phase_fractions


SOURCE = Path("trials/finished/finished.gpx").resolve()
FINAL = Path("final.gpx").resolve()
CIF_PATHS = [Path("phase_CaWO4.cif"), Path("phase_WO3.cif"), Path("phase_Ca3WO6.cif")]

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
hist = project.histogram(0)
freeze_all(project, hist)
project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
project.set_Controls("cycles", 0)
project.refine(makeBack=False)
project.save()

for phase, path in zip(project.phases(), CIF_PATHS):
    phase.export_CIF(str(path.resolve()))

arrays = hist.data["data"][1]
x = np.asarray(arrays[0], float)
observed = np.asarray(arrays[1], float)
weights = np.asarray(arrays[2], float)
calculated = np.asarray(arrays[3], float)
background = np.asarray(arrays[4], float)
difference = np.asarray(arrays[5], float)
np.savetxt(
    "fit.csv",
    np.column_stack((x, observed, calculated, difference, background)),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference,background",
    comments="",
    fmt="%.10g",
)

valid = np.isfinite(weights) & (weights > 0)
weighted_sse = float(np.sum(weights[valid] * difference[valid] ** 2))
weighted_denominator = float(np.sum(weights[valid] * observed[valid] ** 2))
rwp = 100.0 * np.sqrt(weighted_sse / weighted_denominator)
rp = 100.0 * float(np.sum(np.abs(difference[valid]))) / float(np.sum(observed[valid]))
rexp = float(hist.residuals.get("wRmin", float("nan")))
summary = {
    "rwp_percent_full_grid": float(rwp),
    "rwp_percent_gsas": float(hist.get_wR()),
    "rp_percent_full_grid": float(rp),
    "rexp_percent_gsas": rexp,
    "goodness_of_fit": float(rwp / rexp),
    "reduced_chi_square": float((rwp / rexp) ** 2),
    "weighted_sse": weighted_sse,
    "n_points": int(len(x)),
    "two_theta_min_deg": float(x[0]),
    "two_theta_max_deg": float(x[-1]),
    "background_min": float(np.min(background)),
    "background_max": float(np.max(background)),
    "fractions": phase_fractions(project, hist),
    "residuals": {
        key: float(value)
        for key, value in hist.residuals.items()
        if isinstance(value, (int, float))
    },
}
Path("final_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
