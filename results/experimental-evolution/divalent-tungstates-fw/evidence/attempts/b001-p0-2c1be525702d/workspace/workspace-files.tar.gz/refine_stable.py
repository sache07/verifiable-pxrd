"""Conservative staged GSAS-II refinement for the three-phase model.

The script deliberately switches all refinement flags off between stages.  This
avoids carrying a poorly conditioned set of atomic-coordinate variables into
the next phase, which can otherwise produce an attractive but chemically
impossible false minimum.
"""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fractions(project, hist):
    raw = {
        phase.name: float(phase.data["Histograms"][hist.name]["Scale"][0])
        * float(phase.data["General"]["Mass"])
        for phase in project.phases()
    }
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def set_bound(project, variable, lower=None, upper=None):
    if lower is not None:
        project.set_Controls("parmMin", float(lower), variable=variable)
    if upper is not None:
        project.set_Controls("parmMax", float(upper), variable=variable)


def all_off(project, hist):
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hist.clear_refinements(
        {
            "Background": False,
            "Instrument Parameters": list(inst),
            "Sample Parameters": [
                key
                for key, value in sample.items()
                if isinstance(value, list) and len(value) > 1
            ],
        }
    )
    for phase in project.phases():
        phase.clear_refinements(
            {"Cell": None, "Atoms": [atom.label for atom in phase.atoms()]}
        )
        phase.clear_HAP_refinements(
            {
                "Scale": None,
                "Size": None,
                "Mustrain": None,
                "Pref.Ori.": None,
                "HStrain": None,
                "Extinction": None,
            },
            histograms=[hist],
        )


def base_flags(project, hist, include_specimen=True):
    all_off(project, hist)
    hist.set_refinements(
        {
            "Background": True,
            "Instrument Parameters": ["W", "SH/L", "Zero", "Polariz."],
        }
    )
    if include_specimen:
        hist.set_refinements(
            {"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]}
        )
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements(
            {
                "Scale": True,
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            histograms=[hist],
        )


def record(project, hist, label):
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    row = {
        "stage": label,
        "rwp": float(hist.get_wR()),
        "fractions": fractions(project, hist),
        "instrument": {
            key: float(value[1])
            for key, value in inst.items()
            if isinstance(value, list)
            and len(value) > 1
            and isinstance(value[1], (int, float))
        },
        "sample": {
            key: float(value[0])
            for key, value in sample.items()
            if isinstance(value, list)
            and len(value) > 1
            and isinstance(value[0], (int, float))
        },
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        row["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size_um": float(hap["Size"][1][0]),
            "microstrain_ppm": float(hap["Mustrain"][1][0]),
            "preferred_orientation": hap["Pref.Ori."][:4],
            "uiso_A2": [float(atom.uiso) for atom in phase.atoms()],
        }
    print(label, f"Rwp={row['rwp']:.6f}", json.dumps(row["fractions"], sort_keys=True))
    return row


def refine(project, hist, label, log, cycles=6, shift_factor=1.0):
    project.set_Controls("cycles", cycles)
    project.data["Controls"]["data"]["shift factor"] = float(shift_factor)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.refine(makeBack=False)
    project.save()
    row = record(project, hist, label)
    log.append(row)
    return row["rwp"]


def load(source, destination):
    return G2.G2Project(
        gpxfile=str(source.resolve()), newgpx=str(destination.resolve())
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    main_gpx = args.out / "stable.gpx"
    G2.SetPrintLevel("warn")
    project = load(args.source, main_gpx)
    hist = project.histogram(0)
    phases = project.phases()
    log = [record(project, hist, "loaded")]

    # Include every supplied data point in the final calculation.
    x = hist.data["data"][1][0]
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})

    # Start the profile decomposition from positive, well-conditioned values.
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 10.0, "W": 6.0, "X": 1.0, "SH/L": 0.02}.items():
        inst[key][1] = value
        inst[key][2] = False
    inst["Zero"][1] = max(-0.2, min(0.2, float(inst["Zero"][1])))
    inst["Polariz."][1] = 0.70
    sample = hist.data["Sample Parameters"]
    sample["Shift"] = [0.0, False]
    sample["SurfRoughA"] = [0.20, False]
    sample["SurfRoughB"] = [0.06, False]

    starts = [(0.10, 700.0), (0.08, 900.0), (0.07, 1200.0)]
    for pidx, (phase, (size, strain)) in enumerate(zip(phases, starts)):
        phase.setSampleProfile(hist, "size", "isotropic", size)
        phase.setSampleProfile(hist, "microstrain", "isotropic", strain)
        set_bound(project, f"{pidx}:0:Scale", 0.0, 1000.0)
        set_bound(project, f"{pidx}:0:Size;i", 0.02, 2.0)
        set_bound(project, f"{pidx}:0:Mustrain;i", 0.0, 12000.0)
    for variable, lo, hi in [
        (":0:W", 0.01, 80.0),
        (":0:SH/L", 0.0005, 0.15),
        (":0:Zero", -0.25, 0.25),
        (":0:Polariz.", 0.5, 1.0),
        (":0:Shift", -800.0, 800.0),
        (":0:SurfRoughA", 0.0, 0.75),
        (":0:SurfRoughB", 0.0, 0.6),
    ]:
        set_bound(project, variable, lo, hi)

    # First establish peak positions and breadth without specimen-intensity terms.
    base_flags(project, hist, include_specimen=False)
    hist.clear_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, hist, "profile_cell_scale", log, cycles=8)

    # Add the shared specimen terms only after the phase profiles are stable.
    base_flags(project, hist, include_specimen=True)
    refine(project, hist, "specimen_and_polarization", log, cycles=8, shift_factor=0.7)

    all_off(project, hist)
    project.save()
    (args.out / "stages.json").write_text(json.dumps(log, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
