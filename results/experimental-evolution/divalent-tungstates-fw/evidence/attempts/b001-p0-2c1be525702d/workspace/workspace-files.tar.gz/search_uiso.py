"""Grid-search one physically allowed isotropic Uiso per phase."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_groups import freeze_all, phase_fractions


VALUES = (0.003, 0.005, 0.008, 0.012, 0.018)


p = argparse.ArgumentParser()
p.add_argument("source", type=Path)
p.add_argument("out", type=Path)
args = p.parse_args()
args.out.mkdir(parents=True, exist_ok=True)
G2.SetPrintLevel("warn")
working = args.source.resolve()
records = []

for pidx in range(3):
    trials = []
    for value in VALUES:
        path = (args.out / f"p{pidx}_u{value:.3f}.gpx").resolve()
        project = G2.G2Project(gpxfile=str(working), newgpx=str(path))
        hist = project.histogram(0)
        for atom in project.phase(pidx).atoms():
            atom.uiso = value
        freeze_all(project, hist)
        hist.set_refinements({"Background": True})
        for phase in project.phases():
            phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.data["Controls"]["data"]["shift factor"] = 0.5
        project.set_Controls("cycles", 4)
        project.refine(makeBack=False)
        project.save()
        row = {
            "uiso_A2": value,
            "rwp": float(hist.get_wR()),
            "fractions": phase_fractions(project, hist),
            "path": str(path),
        }
        trials.append(row)
        print(pidx, value, row["rwp"])
    best = min(trials, key=lambda row: row["rwp"])
    records.append({"phase": pidx, "trials": trials, "selected": best})
    working = Path(best["path"])
    print("selected", pidx, best["uiso_A2"], best["rwp"])

final = G2.G2Project(
    gpxfile=str(working), newgpx=str((args.out / "uiso.gpx").resolve())
)
freeze_all(final, final.histogram(0))
final.save()
(args.out / "uiso_trials.json").write_text(json.dumps(records, indent=2) + "\n")
print("final", final.histogram(0).get_wR(), phase_fractions(final, final.histogram(0)))
