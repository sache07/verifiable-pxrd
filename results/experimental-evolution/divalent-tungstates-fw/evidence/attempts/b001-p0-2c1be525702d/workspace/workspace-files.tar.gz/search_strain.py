"""Test uniaxial microstrain axes for the Ca3WO6 phase."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from search_orientation import freeze_except_po


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def freeze_all(project):
    freeze_except_po(project)
    hist = project.histogram(0)
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Pref.Ori."][2] = False


p = argparse.ArgumentParser()
p.add_argument("source", type=Path)
p.add_argument("out", type=Path)
p.add_argument("--phase", type=int, default=2)
args = p.parse_args()
args.out.mkdir(parents=True, exist_ok=True)
G2.SetPrintLevel("warn")
source = args.source.resolve()
base = G2.G2Project(gpxfile=str(source))
base_hist = base.histogram(0)
base_hap = base.phase(args.phase).data["Histograms"][base_hist.name]
equatorial = float(base_hap["Mustrain"][1][0])
records = [{"axis": None, "equatorial": equatorial, "axial": equatorial, "rwp": float(base_hist.get_wR())}]

for axis in AXES:
    label = "".join(map(str, axis))
    test = G2.G2Project(gpxfile=str(source), newgpx=str((args.out / f"axis_{label}.gpx").resolve()))
    freeze_all(test)
    hist = test.histogram(0)
    phase = test.phase(args.phase)
    phase.setSampleProfile(hist, "microstrain", "uniaxial", equatorial, equatorial, axis)
    mustrain = phase.data["Histograms"][hist.name]["Mustrain"]
    mustrain[2][0] = True
    mustrain[2][1] = True
    test.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;i")
    test.set_Controls("parmMax", 25000.0, variable=f"{args.phase}:0:Mustrain;i")
    test.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;a")
    test.set_Controls("parmMax", 25000.0, variable=f"{args.phase}:0:Mustrain;a")
    test.set_Controls("cycles", 10)
    test.refine()
    hap = test.phase(args.phase).data["Histograms"][test.histogram(0).name]
    row = {
        "axis": list(axis),
        "equatorial": float(hap["Mustrain"][1][0]),
        "axial": float(hap["Mustrain"][1][1]),
        "rwp": float(test.histogram(0).get_wR()),
    }
    records.append(row)
    print(row)

best = min(records, key=lambda row: row["rwp"])
final = G2.G2Project(gpxfile=str(source), newgpx=str((args.out / "strain.gpx").resolve()))
if best["axis"] is not None:
    hist = final.histogram(0)
    phase = final.phase(args.phase)
    phase.setSampleProfile(hist, "microstrain", "uniaxial", best["equatorial"], best["axial"], best["axis"])
    mustrain = phase.data["Histograms"][hist.name]["Mustrain"]
    mustrain[2][0] = True
    mustrain[2][1] = True
    final.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;i")
    final.set_Controls("parmMax", 25000.0, variable=f"{args.phase}:0:Mustrain;i")
    final.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;a")
    final.set_Controls("parmMax", 25000.0, variable=f"{args.phase}:0:Mustrain;a")
    final.set_Controls("cycles", 15)
    final.refine()
final.save()
print("selected", best, "full_rwp", final.histogram(0).get_wR())
(args.out / "strain_trials.json").write_text(json.dumps({"trials": records, "selected": best}, indent=2) + "\n")
