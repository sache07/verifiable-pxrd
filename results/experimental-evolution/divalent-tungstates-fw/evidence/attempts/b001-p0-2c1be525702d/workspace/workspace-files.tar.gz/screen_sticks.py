from pathlib import Path
import warnings

from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure


ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/resources/b001-c05/cif")
IDS = [
    "7219229", "1546035", "4030741", "1563196",
    "1004057", "1010618", "1521532", "1521533", "1528915",
    "1563541", "2106293", "2107312", "2311041",
    "1523082", "2101049", "2107065", "9016940", "1538315",
]

paths = {p.stem: p for p in ROOT.rglob("*.cif") if p.stem in IDS}
calc = XRDCalculator(wavelength="CuKa1", symprec=0)
warnings.filterwarnings("ignore")

for cod_id in IDS:
    try:
        structure = Structure.from_file(paths[cod_id])
        pattern = calc.get_pattern(structure, two_theta_range=(9.9, 100.1), scaled=True)
    except Exception as exc:
        print(f"{cod_id}: ERROR {exc}")
        continue
    peaks = [(float(x), float(y), hkls) for x, y, hkls in zip(pattern.x, pattern.y, pattern.hkls) if y >= 3.0]
    print(f"\n{cod_id} {structure.composition.reduced_formula} cell={tuple(round(v, 4) for v in structure.lattice.abc)}")
    for x, y, hkls in peaks:
        labels = "/".join(str(tuple(v["hkl"])) for v in hkls)
        print(f"  {x:8.3f} {y:7.2f} {labels}")
