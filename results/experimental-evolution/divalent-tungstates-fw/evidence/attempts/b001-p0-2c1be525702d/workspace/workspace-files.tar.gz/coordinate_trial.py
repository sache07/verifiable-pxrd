"""Run an isolated one-cycle atomic-coordinate trial for one phase."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_groups import freeze_all, phase_fractions


p = argparse.ArgumentParser()
p.add_argument("source", type=Path)
p.add_argument("destination", type=Path)
p.add_argument("phase", type=int)
args = p.parse_args()
args.destination.parent.mkdir(parents=True, exist_ok=True)
G2.SetPrintLevel("warn")
project = G2.G2Project(
    gpxfile=str(args.source.resolve()), newgpx=str(args.destination.resolve())
)
hist = project.histogram(0)
freeze_all(project, hist)
phase = project.phase(args.phase)
before = {
    atom.label: {"xyz": list(atom.coordinates), "uiso": atom.uiso}
    for atom in phase.atoms()
}
phase.set_refinements({"Atoms": {"all": "X"}})
project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
project.data["Controls"]["data"]["shift factor"] = 0.25
project.set_Controls("cycles", 1)
project.refine(makeBack=False)
project.save()
after = {
    atom.label: {"xyz": list(atom.coordinates), "uiso": atom.uiso}
    for atom in phase.atoms()
}
result = {
    "phase": phase.name,
    "rwp": float(hist.get_wR()),
    "fractions": phase_fractions(project, hist),
    "before": before,
    "after": after,
}
args.destination.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result))
