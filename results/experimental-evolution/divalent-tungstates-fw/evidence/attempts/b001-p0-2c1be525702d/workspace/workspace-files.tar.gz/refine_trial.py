"""Build and stage a GSAS-II Rietveld refinement for candidate phase sets."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


PHASE_NAMES = {
    "7219229": "CaWO4_scheelite",
    "1546035": "CaWO4_fergusonite",
    "4030741": "Ca4.26W10O30",
    "1563196": "CaO",
    "1004057": "WO3_hexagonal",
    "1010618": "WO3_monoclinic_small",
    "1521532": "WO3_tetragonal_P4ncc",
    "1521533": "WO3_tetragonal_P4nmm",
    "1528915": "WO3_gamma_P21c",
    "1563541": "WO3_monoclinic_P21c_small",
    "2106293": "WO3_triclinic",
    "2107312": "WO3_orthorhombic",
    "2311041": "WO3_gamma_P21c_alt",
    "1523082": "WO4_incomplete_Li2WO4_model",
    "2101049": "W3O8_Pm",
    "2107065": "W17O47",
    "9016940": "CaO2_P21c",
    "1538315": "W18O49",
    "1530292": "CaO2_tetragonal",
    "2101050": "W3O8_Amm2",
    "9014468": "W3O10",
    "Ca3WO6_from_Ca3UO6": "Ca3WO6_P21_analogue",
}


def instrument_text() -> str:
    return (
        "#GSAS-II instrument parameter file for uncalibrated lab CuKa data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.12;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:8.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def phase_fractions(project: G2.G2Project, hist: G2.G2PwdrData) -> dict[str, float]:
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        raw[phase.name] = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
    total = sum(raw.values())
    return {key: val / total for key, val in raw.items()} if total > 0 else raw


def snapshot(project: G2.G2Project, hist: G2.G2PwdrData, label: str, verbose: bool = True) -> dict:
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    numeric = lambda value: isinstance(value, (int, float, np.integer, np.floating))
    result = {
        "stage": label,
        "residuals": {k: float(v) for k, v in hist.residuals.items() if numeric(v)},
        "fractions": phase_fractions(project, hist),
        "instrument": {k: float(v[1]) for k, v in inst.items() if isinstance(v, list) and len(v) >= 2 and numeric(v[1])},
        "sample": {k: float(v[0]) for k, v in sample.items() if isinstance(v, list) and len(v) >= 2 and numeric(v[0])},
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    if verbose:
        print(json.dumps(result, indent=2, default=str))
    return result


def refine(project: G2.G2Project, hist: G2.G2PwdrData, label: str, records: list[dict], verbose: bool) -> None:
    project.refine()
    records.append(snapshot(project, hist, label, verbose))
    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phases", nargs="+", required=True, choices=sorted(PHASE_NAMES))
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--background-terms", type=int, default=12)
    parser.add_argument("--atomic", action="store_true")
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--screen-only", action="store_true")
    parser.add_argument("--fixed-cell", nargs="*", default=[])
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.out.mkdir(parents=True, exist_ok=True)
    pattern = np.genfromtxt("inputs/pattern.csv", delimiter=",", names=True)
    x = np.asarray(pattern["two_theta_deg"], float)
    y = np.asarray(pattern["intensity"], float)
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(args.out / "pattern.xye", np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")
    (args.out / "instrument.instprm").write_text(instrument_text())

    project = G2.G2Project(newgpx=str((args.out / "trial.gpx").resolve()))
    phases = []
    for cod_id in args.phases:
        phase = project.add_phase(
            str(Path("prepared", f"{cod_id}.cif").resolve()),
            phasename=PHASE_NAMES[cod_id],
            fmthint="CIF",
        )
        phases.append(phase)
    hist = project.add_powder_histogram(
        str((args.out / "pattern.xye").resolve()),
        str((args.out / "instrument.instprm").resolve()),
        phases=phases,
        fmthint="xye",
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.set_refinements({"Limits": [10.0, 100.0]})
    coeffs = [float(np.percentile(y, 25))] + [0.0] * (args.background_terms - 1)
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": args.background_terms,
            "coeffs": coeffs,
            "refine": True,
        }
    })

    initial_scales = {
        "CaWO4_scheelite": 8.0,
        "CaWO4_fergusonite": 8.0,
        "WO3_gamma_P21c": 2.0,
        "WO3_gamma_P21c_alt": 2.0,
        "CaO": 1.0,
        "Ca4.26W10O30": 2.0,
    }
    phase_ids = {phase.name: cod_id for phase, cod_id in zip(phases, args.phases)}
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [initial_scales.get(phase.name, 2.0), True]
        phase.setSampleProfile(hist, "size", "isotropic", 1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 500.0)
        phase.set_refinements({"Cell": False})

    project.set_Controls("cycles", 8)
    verbose = not args.quiet
    records = [snapshot(project, hist, "initial", verbose)]
    refine(project, hist, "background_scale", records, verbose)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": phase_ids[phase.name] not in args.fixed_cell})
    refine(project, hist, "zero_cells", records, verbose)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, hist, "instrument_profile", records, verbose)

    if not args.screen_only:
        for phase in phases:
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        refine(project, hist, "isotropic_size", records, verbose)

        for phase in phases:
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        refine(project, hist, "isotropic_strain", records, verbose)

        hist.set_refinements({"Sample Parameters": ["Shift"]})
        refine(project, hist, "sample_shift", records, verbose)

        # Refine the two Suortti surface-roughness parameters from a mild interior start.
        hist.data["Sample Parameters"]["SurfRoughA"] = [0.15, True]
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.08, True]
        refine(project, hist, "surface_roughness", records, verbose)

        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        refine(project, hist, "polarization", records, verbose)

        if args.atomic:
            for pidx, phase in enumerate(phases):
                phase.set_refinements({"Atoms": {"all": "X"}})
                atoms = phase.atoms()
                if len(atoms) > 1:
                    project.add_EquivConstr(
                        tuple(f"{pidx}::AUiso:{aidx}" for aidx in range(len(atoms))),
                        reloadIdx=(pidx == 0),
                    )
                phase.set_refinements({"Atoms": {"all": "XU"}})
            refine(project, hist, "atomic_positions_uiso", records, verbose)

    project.save()
    (args.out / "stages.json").write_text(json.dumps(records, indent=2, default=str) + "\n")
    arrays = hist.data["data"][1]
    np.savetxt(
        args.out / "fit.csv",
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[5], arrays[4])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )


if __name__ == "__main__":
    main()
