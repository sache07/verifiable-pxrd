"""Run additional GSAS-II cycles on an existing project and export its profile."""

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


p = argparse.ArgumentParser()
p.add_argument("source", type=Path)
p.add_argument("destination", type=Path)
p.add_argument("--cycles", type=int, default=15)
p.add_argument("--repeats", type=int, default=2)
args = p.parse_args()
args.destination.parent.mkdir(parents=True, exist_ok=True)
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.destination.resolve()))
project.set_Controls("cycles", args.cycles)
for repeat in range(args.repeats):
    project.refine()
    hist = project.histogram(0)
    print(repeat + 1, hist.get_wR())
project.save()
hist = project.histogram(0)
arrays = hist.data["data"][1]
fit_path = args.destination.with_suffix(".fit.csv")
np.savetxt(
    fit_path,
    np.column_stack((arrays[0], arrays[1], arrays[3], arrays[5], arrays[4])),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference,background",
    comments="",
)
