"""Rank chemically allowed candidate structures against residual Bragg intensity."""

from pathlib import Path
import warnings

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure


fit = np.genfromtxt("trials/two_phase/fit.csv", delimiter=",", names=True)
x = np.asarray(fit["two_theta_deg"], float)
y = np.asarray(fit["observed"], float)
residual = np.asarray(fit["difference"], float)
weights = 1.0 / np.maximum(y, 1.0)

calc = XRDCalculator(wavelength="CuKa1", symprec=0)
rows = []
warnings.filterwarnings("ignore")


def profile(positions, intensities, shift):
    result = np.zeros_like(x)
    for pos, area in zip(positions + shift, intensities):
        # Empirical screening width; final ranking is verified by Rietveld fits.
        fwhm = 0.145 + 0.0022 * pos
        sigma = fwhm / 2.35482
        lo = np.searchsorted(x, pos - 4.5 * sigma)
        hi = np.searchsorted(x, pos + 4.5 * sigma)
        if hi > lo:
            z = (x[lo:hi] - pos) / sigma
            result[lo:hi] += area * np.exp(-0.5 * z * z) / sigma
    return result


for cif in sorted(Path("prepared").glob("*.cif")):
    cod_id = cif.stem
    try:
        structure = Structure.from_file(cif)
        pattern = calc.get_pattern(structure, two_theta_range=(9.5, 100.5), scaled=False)
    except Exception as exc:
        print(cod_id, "ERROR", exc)
        continue
    pos = np.asarray(pattern.x, float)
    inten = np.asarray(pattern.y, float)
    best = None
    for shift in np.linspace(-0.35, 0.25, 121):
        p = profile(pos, inten, shift)
        denom = float(np.sum(weights * p * p))
        amplitude = max(0.0, float(np.sum(weights * p * residual)) / denom) if denom else 0.0
        improvement = float(np.sum(weights * (residual * residual - (residual - amplitude * p) ** 2)))
        if best is None or improvement > best[0]:
            best = (improvement, shift, amplitude)
    rows.append((best[0], cod_id, structure.composition.reduced_formula, best[1], best[2]))

print("weighted_SSE_reduction COD formula shift amplitude")
for row in sorted(rows, reverse=True):
    print(f"{row[0]:14.3f} {row[1]:>8s} {row[2]:>16s} {row[3]:8.3f} {row[4]:12.5g}")
