"""Construct and screen a Ca3WO6 model from the isochemical Ca3UO6 analogue."""

from pathlib import Path
import sys
import warnings

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Lattice, Structure


SOURCE = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/resources/b001-c05/cif/2/31/04/2310470.cif")
fit = np.genfromtxt("trials/two_phase_atomic/fit.csv", delimiter=",", names=True)
x = np.asarray(fit["two_theta_deg"], float)
y = np.asarray(fit["observed"], float)
residual = np.asarray(fit["difference"], float)
weights = 1.0 / np.maximum(y, 1.0)
calc = XRDCalculator(wavelength="CuKa1", symprec=0)


def broaden(positions, intensities, shift):
    out = np.zeros_like(x)
    for pos, area in zip(positions + shift, intensities):
        fwhm = 0.145 + 0.0022 * pos
        sigma = fwhm / 2.35482
        lo = np.searchsorted(x, pos - 4.5 * sigma)
        hi = np.searchsorted(x, pos + 4.5 * sigma)
        z = (x[lo:hi] - pos) / sigma
        out[lo:hi] += area * np.exp(-0.5 * z * z) / sigma
    return out


warnings.filterwarnings("ignore")
base = Structure.from_file(SOURCE)
base.replace_species({"U": "W"})
rows = []
for scale in np.linspace(0.88, 1.0, 121):
    trial = Structure(
        Lattice(base.lattice.matrix * scale),
        base.species,
        base.frac_coords,
        site_properties=base.site_properties,
    )
    patt = calc.get_pattern(trial, two_theta_range=(9.5, 100.5), scaled=False)
    pos = np.asarray(patt.x, float)
    inten = np.asarray(patt.y, float)
    best = None
    for shift in np.linspace(-0.30, 0.20, 101):
        profile = broaden(pos, inten, shift)
        denom = float(np.sum(weights * profile * profile))
        amplitude = max(0.0, float(np.sum(weights * profile * residual)) / denom) if denom else 0.0
        improvement = float(np.sum(weights * (residual**2 - (residual - amplitude * profile) ** 2)))
        if best is None or improvement > best[0]:
            best = (improvement, shift, amplitude)
    rows.append((best[0], scale, best[1], best[2], trial, pos, inten))

best = max(rows, key=lambda row: row[0])
print(f"best weighted SSE reduction={best[0]:.3f} scale={best[1]:.5f} shift={best[2]:.5f} amplitude={best[3]:.6g}")
print("cell", tuple(round(v, 6) for v in best[4].lattice.abc), tuple(round(v, 6) for v in best[4].lattice.angles))
scaled = best[6] / np.max(best[6]) * 100.0
for pos, intensity in zip(best[5], scaled):
    if intensity >= 3.0:
        print(f"{pos:9.4f} {intensity:8.2f}")

sys.path.insert(0, str(Path("learned/divalent-tungstates/runtime").resolve()))
from models import write_synthetic_model  # noqa: E402

out = Path("prepared/Ca3WO6_from_Ca3UO6.cif")
write_synthetic_model(best[4], out)
print(out)
