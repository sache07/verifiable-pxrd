"""Refine well-conditioned parameter groups with rollback on deterioration."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def phase_fractions(project, hist):
    raw = {
        phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
        * phase.data["General"]["Mass"]
        for phase in project.phases()
    }
    total = sum(raw.values())
    return {name: float(value / total) for name, value in raw.items()}


def freeze_all(project, hist):
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    # GSAS-II's Background boolean branch returns early, so these must be
    # separate calls.
    hist.clear_refinements({"Background": False})
    hist.clear_refinements({"Instrument Parameters": list(inst)})
    hist.clear_refinements(
        {
            "Sample Parameters": [
                key
                for key, value in sample.items()
                if isinstance(value, list) and len(value) > 1
            ]
        }
    )
    for phase in project.phases():
        phase.clear_refinements(
            {"Cell": None, "Atoms": [atom.label for atom in phase.atoms()]}
        )
        phase.clear_HAP_refinements(
            {
                "Scale": None,
                "Size": None,
                "Mustrain": None,
                "Pref.Ori.": None,
                "HStrain": None,
                "Extinction": None,
            },
            histograms=[hist],
        )


def set_bound(project, variable, lower, upper):
    project.set_Controls("parmMin", float(lower), variable=variable)
    project.set_Controls("parmMax", float(upper), variable=variable)


def snapshot(project, hist, stage, accepted=True):
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    row = {
        "stage": stage,
        "accepted": accepted,
        "rwp": float(hist.get_wR()),
        "fractions": phase_fractions(project, hist),
        "instrument": {
            key: float(value[1])
            for key, value in inst.items()
            if isinstance(value, list)
            and len(value) > 1
            and isinstance(value[1], (int, float))
        },
        "sample": {
            key: float(value[0])
            for key, value in sample.items()
            if isinstance(value, list)
            and len(value) > 1
            and isinstance(value[0], (int, float))
        },
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        row["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size_um": float(hap["Size"][1][0]),
            "microstrain_ppm": float(hap["Mustrain"][1][0]),
            "preferred_orientation": hap["Pref.Ori."][:4],
        }
    print(stage, accepted, f"Rwp={row['rwp']:.6f}", json.dumps(row["fractions"], sort_keys=True))
    return row


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    destination = (args.out / "grouped.gpx").resolve()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.source.resolve()), newgpx=str(destination)
    )
    hist = project.histogram(0)
    log = [snapshot(project, hist, "loaded")]

    # Remove the statistically negligible Ca3WO6 texture term selected in the
    # exploratory search (ratio was only 1.0165).
    ca3_hap = project.phase(2).data["Histograms"][hist.name]
    ca3_hap["Pref.Ori."][1] = 1.0
    ca3_hap["Pref.Ori."][2] = False

    for pidx in range(len(project.phases())):
        set_bound(project, f"{pidx}:0:Scale", 0.0, 1000.0)
        set_bound(project, f"{pidx}:0:Size;i", 0.02, 2.0)
        set_bound(project, f"{pidx}:0:Mustrain;i", 0.0, 12000.0)
        set_bound(project, f"{pidx}:0:MD", 0.7, 1.4)
    for var, lo, hi in [
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
        (":0:SurfRoughA", 0.0, 0.75),
        (":0:SurfRoughB", 0.0, 0.6),
        (":0:Polariz.", 0.5, 1.0),
        (":0:SH/L", 0.0005, 0.15),
    ]:
        set_bound(project, var, lo, hi)

    def run_stage(name, setup, cycles=6, tolerance=0.002):
        nonlocal project, hist
        freeze_all(project, hist)
        setup(project, hist)
        project.save()
        checkpoint = args.out / f"before_{name}.gpx"
        shutil.copy2(destination, checkpoint)
        before = float(hist.get_wR())
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.data["Controls"]["data"]["shift factor"] = 0.5
        project.set_Controls("cycles", cycles)
        project.refine(makeBack=False)
        project.save()
        after = float(hist.get_wR())
        accept = math.isfinite(after) and after <= before + tolerance
        if accept:
            log.append(snapshot(project, hist, name, True))
        else:
            trial = snapshot(project, hist, name + "_rejected_trial", False)
            log.append(trial)
            project = G2.G2Project(
                gpxfile=str(checkpoint.resolve()), newgpx=str(destination)
            )
            hist = project.histogram(0)
            log.append(snapshot(project, hist, name + "_rollback", True))

    def background_scales(project, hist):
        hist.set_refinements({"Background": True})
        for phase in project.phases():
            phase.set_HAP_refinements({"Scale": True}, histograms=[hist])

    run_stage("background_scales", background_scales, cycles=6)

    def cells(project, hist):
        background_scales(project, hist)
        for phase in project.phases():
            phase.set_refinements({"Cell": True})

    run_stage("cells_background_scales", cells, cycles=6)

    def profiles(project, hist):
        background_scales(project, hist)
        for phase in project.phases():
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True},
                },
                histograms=[hist],
            )

    run_stage("profiles_background_scales", profiles, cycles=6)

    def specimen_texture(project, hist):
        background_scales(project, hist)
        hist.set_refinements(
            {
                "Instrument Parameters": ["Zero", "Polariz.", "SH/L"],
                "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
            }
        )
        project.phase(1).set_HAP_refinements(
            {"Pref.Ori.": True}, histograms=[hist]
        )

    run_stage("specimen_texture_background_scales", specimen_texture, cycles=8)

    def joint(project, hist):
        specimen_texture(project, hist)
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True},
                },
                histograms=[hist],
            )

    run_stage("joint_nonstructural", joint, cycles=6)

    freeze_all(project, hist)
    project.save()
    (args.out / "stages.json").write_text(json.dumps(log, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
