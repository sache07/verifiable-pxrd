from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import percentile_filter
from scipy.signal import find_peaks, peak_widths


data = np.genfromtxt("inputs/pattern.csv", delimiter=",", names=True)
x = np.asarray(data["two_theta_deg"], float)
y = np.asarray(data["intensity"], float)

# A broad lower-envelope estimate used only for peak finding/visualization.
background = percentile_filter(y, percentile=20, size=401, mode="nearest")
signal = y - background
peaks, props = find_peaks(signal, prominence=35.0, distance=4)
widths = peak_widths(signal, peaks, rel_height=0.5)[0] * np.median(np.diff(x))

order = np.argsort(props["prominences"])[::-1]
print(f"points={len(x)} range={x[0]:.8f}..{x[-1]:.8f} step={np.median(np.diff(x)):.8f}")
print(f"intensity min/median/max={y.min():.1f}/{np.median(y):.1f}/{y.max():.1f}")
print("rank  2theta_deg  counts  prominence  FWHM_deg")
for rank, idx in enumerate(order[:100], 1):
    p = peaks[idx]
    print(f"{rank:4d} {x[p]:11.5f} {y[p]:8.1f} {props['prominences'][idx]:11.1f} {widths[idx]:9.4f}")

fig, axes = plt.subplots(2, 1, figsize=(14, 8), sharex=True)
axes[0].plot(x, y, lw=0.65, color="black")
axes[0].plot(x, background, lw=0.8, color="tab:orange")
axes[0].set_ylabel("Counts")
axes[1].plot(x, signal, lw=0.65, color="black")
axes[1].scatter(x[peaks], signal[peaks], s=6, color="tab:red")
axes[1].set_xlabel(r"$2\theta$ (deg, Cu K$\alpha$)")
axes[1].set_ylabel("Counts above envelope")
fig.tight_layout()
fig.savefig("pattern_overview.png", dpi=160)
