"""Continue the three-phase model with physically bounded GSAS-II parameters."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def fractions(project, hist):
    raw = {
        phase.name: float(phase.data["Histograms"][hist.name]["Scale"][0])
        * float(phase.data["General"]["Mass"])
        for phase in project.phases()
    }
    total = sum(raw.values())
    return {key: value / total for key, value in raw.items()}


def state(project, hist, stage):
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    out = {
        "stage": stage,
        "rwp": float(hist.get_wR()),
        "fractions": fractions(project, hist),
        "instrument": {key: value[1] for key, value in inst.items() if isinstance(value, list) and len(value) > 1 and isinstance(value[1], (int, float))},
        "sample": {key: value[0] for key, value in sample.items() if isinstance(value, list) and len(value) > 1 and isinstance(value[0], (int, float))},
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"][1],
            "mustrain": hap["Mustrain"][1],
            "preferred_orientation": hap["Pref.Ori."][:4],
        }
    print(stage, f"Rwp={out['rwp']:.5f}", json.dumps(out["fractions"], sort_keys=True))
    return out


def run(project, hist, stage, log):
    project.refine()
    project.save()
    log.append(state(project, hist, stage))


def set_bound(project, variable, lower=None, upper=None):
    if lower is not None:
        project.set_Controls("parmMin", float(lower), variable=variable)
    if upper is not None:
        project.set_Controls("parmMax", float(upper), variable=variable)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("source", type=Path)
    p.add_argument("out", type=Path)
    args = p.parse_args()
    G2.SetPrintLevel("warn")
    args.out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str((args.out / "controlled.gpx").resolve()))
    hist = project.histogram(0)
    phases = project.phases()
    project.set_Controls("cycles", 10)
    log = [state(project, hist, "loaded")]

    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 10.0, "W": 5.0, "X": 1.0, "SH/L": 0.02}.items():
        inst[key][1] = value
        inst[key][2] = False
    # W and axial-divergence asymmetry are independently identifiable; X is
    # held because it is exactly correlated with isotropic crystallite size.
    inst["W"][2] = True
    inst["SH/L"][2] = True
    set_bound(project, ":0:W", 0.01, 100.0)
    set_bound(project, ":0:SH/L", 0.0001, 0.2)
    set_bound(project, ":0:Zero", -1.0, 1.0)

    for pidx, phase in enumerate(phases):
        start_size = [0.08, 0.065, 0.08][pidx]
        start_strain = [800.0, 1200.0, 1000.0][pidx]
        phase.setSampleProfile(hist, "size", "isotropic", start_size)
        phase.setSampleProfile(hist, "microstrain", "isotropic", start_strain)
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        set_bound(project, f"{pidx}:0:Size;i", 0.015, 5.0)
        set_bound(project, f"{pidx}:0:Mustrain;i", 0.0, 25000.0)
        set_bound(project, f"{pidx}:0:Scale", 0.0, 1000.0)
    run(project, hist, "bounded_isotropic_profiles", log)

    sample = hist.data["Sample Parameters"]
    sample["Shift"] = [0.0, True]
    set_bound(project, ":0:Shift", -2000.0, 2000.0)
    run(project, hist, "specimen_shift", log)

    # The generated laboratory patterns can contain a Suortti surface term.
    sample["SurfRoughA"] = [0.15, True]
    sample["SurfRoughB"] = [0.08, True]
    set_bound(project, ":0:SurfRoughA", 0.0, 0.95)
    set_bound(project, ":0:SurfRoughB", 0.0, 2.0)
    run(project, hist, "surface_roughness", log)

    set_bound(project, ":0:Polariz.", 0.0, 1.0)
    inst["Polariz."][2] = True
    run(project, hist, "polarization", log)

    # Refine coordinates one phase at a time to keep the analogue stable.
    for pidx, phase in enumerate(phases):
        max_shift = 0.012 if pidx < 2 else 0.020
        for component in ("x", "y", "z"):
            set_bound(project, f"{pidx}::dA{component}:*", -max_shift, max_shift)
        phase.set_refinements({"Atoms": {"all": "X"}})
        run(project, hist, f"coordinates_{pidx}_{phase.name}", log)

    # The synthetic source convention uses one scalar Uiso per phase. Tie all
    # sites within a phase and refine that common value.
    for pidx, phase in enumerate(phases):
        atoms = phase.atoms()
        if len(atoms) > 1:
            project.add_EquivConstr(
                tuple(f"{pidx}::AUiso:{aidx}" for aidx in range(len(atoms))),
                reloadIdx=(pidx == 0),
            )
        phase.set_refinements({"Atoms": {"all": "XU"}})
        for aidx in range(len(atoms)):
            set_bound(project, f"{pidx}::AUiso:{aidx}", 0.0001, 0.08)
    run(project, hist, "common_uiso", log)

    project.save()
    (args.out / "stages.json").write_text(json.dumps(log, indent=2, default=str) + "\n")
    arrays = hist.data["data"][1]
    np.savetxt(
        args.out / "fit.csv",
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[5], arrays[4])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )


if __name__ == "__main__":
    main()
