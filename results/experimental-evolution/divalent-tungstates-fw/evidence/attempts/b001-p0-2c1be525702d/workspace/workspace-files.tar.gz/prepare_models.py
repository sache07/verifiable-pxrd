"""Normalize candidate COD models to the synthetic generator's CIF convention."""

from pathlib import Path
import sys
import warnings

from pymatgen.io.cif import CifParser


ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/resources/b001-c05/cif")
OUT = Path("prepared")
IDS = sys.argv[1:] or [
    "7219229", "1546035", "4030741", "1563196",
    "1004057", "1010618", "1521532", "1521533", "1528915",
    "1563541", "2106293", "2107312", "2311041",
]

sys.path.insert(0, str(Path("learned/divalent-tungstates/runtime").resolve()))
from models import write_synthetic_model  # noqa: E402


paths = {p.stem: p for p in ROOT.rglob("*.cif") if p.stem in IDS}
OUT.mkdir(exist_ok=True)
for cod_id in IDS:
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            parser = CifParser(paths[cod_id], occupancy_tolerance=1.0, site_tolerance=1e-5, frac_tolerance=0)
            structures = parser.parse_structures(primitive=False, on_error="raise")
    except Exception as exc:
        print(cod_id, "SKIP", str(exc).splitlines()[0])
        continue
    if len(structures) != 1:
        raise RuntimeError(f"{cod_id}: expected one structure, found {len(structures)}")
    structure = structures[0]
    structure.remove_oxidation_states()
    destination = OUT / f"{cod_id}.cif"
    try:
        write_synthetic_model(structure, destination)
    except Exception as exc:
        print(cod_id, "SKIP", str(exc).splitlines()[0])
        continue
    print(cod_id, structure.composition.reduced_formula, len(structure), destination)
