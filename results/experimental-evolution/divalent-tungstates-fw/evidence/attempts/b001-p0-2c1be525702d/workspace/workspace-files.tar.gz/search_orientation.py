"""Select March-Dollase axes by isolated one-parameter GSAS-II trials."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def freeze_except_po(project):
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False


def main():
    p = argparse.ArgumentParser()
    p.add_argument("source", type=Path)
    p.add_argument("out", type=Path)
    args = p.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    working = args.source.resolve()
    records = []

    for pidx in range(3):
        axis_results = []
        baseline = G2.G2Project(gpxfile=str(working))
        baseline_rwp = float(baseline.histogram(0).get_wR())
        axis_results.append({"axis": None, "ratio": 1.0, "rwp": baseline_rwp})
        for axis in AXES:
            label = "".join(map(str, axis))
            test_path = (args.out / f"p{pidx}_{label}.gpx").resolve()
            test = G2.G2Project(gpxfile=str(working), newgpx=str(test_path))
            freeze_except_po(test)
            hist = test.histogram(0)
            phase = test.phase(pidx)
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(axis)
            test.set_Controls("cycles", 8)
            test.set_Controls("parmMin", 0.2, variable=f"{pidx}:0:MD")
            test.set_Controls("parmMax", 5.0, variable=f"{pidx}:0:MD")
            test.refine()
            ratio = float(test.phase(pidx).data["Histograms"][test.histogram(0).name]["Pref.Ori."][1])
            rwp = float(test.histogram(0).get_wR())
            axis_results.append({"axis": list(axis), "ratio": ratio, "rwp": rwp})
            print(pidx, axis, ratio, rwp)
        best = min(axis_results, key=lambda row: row["rwp"])
        records.append({"phase": pidx, "trials": axis_results, "selected": best})

        next_path = (args.out / f"selected_p{pidx}.gpx").resolve()
        selected = G2.G2Project(gpxfile=str(working), newgpx=str(next_path))
        if best["axis"] is not None:
            hist = selected.histogram(0)
            hap = selected.phase(pidx).data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = best["ratio"]
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = best["axis"]
            selected.set_Controls("parmMin", 0.2, variable=f"{pidx}:0:MD")
            selected.set_Controls("parmMax", 5.0, variable=f"{pidx}:0:MD")
            selected.set_Controls("cycles", 12)
            selected.refine()
        selected.save()
        working = next_path
        print("selected", pidx, best, "full_rwp", selected.histogram(0).get_wR())

    final = G2.G2Project(gpxfile=str(working), newgpx=str((args.out / "orientation.gpx").resolve()))
    final.save()
    (args.out / "orientation_trials.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
