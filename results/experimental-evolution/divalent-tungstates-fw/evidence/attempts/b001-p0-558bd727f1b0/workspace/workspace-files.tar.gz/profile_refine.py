#!/usr/bin/env python3
"""Continue a GSAS-II refinement with physically bounded profile parameters."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


START_SIZE = {"CaWO4": 0.30, "WO3": 0.10, "CaO": 1.00, "CaCO3": 0.50}
START_STRAIN = {"CaWO4": 1500.0, "WO3": 1500.0, "CaO": 500.0, "CaCO3": 1000.0}


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histograms()[0]
    masses = np.array(
        [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()]
    )
    masses /= masses.sum()
    return {p.name: float(v) for p, v in zip(project.phases(), masses)}


def status(project: G2.G2Project, label: str) -> None:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    print(
        "RESULT",
        label,
        "Rwp",
        hist.get_wR(),
        "instrument",
        {k: inst[k][1] for k in ("Zero", "U", "W", "X", "SH/L", "Polariz.")},
        "shift",
        sample["Shift"][0],
        "fractions",
        fractions(project),
    )
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(
            "PROFILE",
            phase.name,
            "size",
            hap["Size"][0],
            hap["Size"][1][:2],
            "strain",
            hap["Mustrain"][0],
            hap["Mustrain"][1][:2],
            "po",
            hap["Pref.Ori."][:4],
        )


def run(project: G2.G2Project, label: str) -> None:
    project.refine(makeBack=False)
    status(project, label)


def bound(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--strain-phases", nargs="*", default=["CaWO4", "WO3"])
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--no-shift", action="store_true")
    parser.add_argument("--no-polarization", action="store_true")
    args = parser.parse_args()

    out = Path(args.output).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()))
    project.save(str(out))
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    project.update_ids()
    hist = project.histograms()[0]
    h_id = hist.id
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 10.0, "W": 10.0, "X": 2.7, "SH/L": 0.02}.items():
        inst[key][1] = value
        inst[key][2] = False
    inst["Polariz."][1] = 0.75
    inst["Polariz."][2] = False
    hist.data["Sample Parameters"]["Shift"][1] = False

    bound(project, f":{h_id}:U", 0.0, 50.0)
    bound(project, f":{h_id}:W", 0.1, 50.0)
    bound(project, f":{h_id}:X", 0.01, 10.0)
    bound(project, f":{h_id}:SH/L", 0.001, 0.2)
    bound(project, f":{h_id}:Polariz.", 0.45, 1.0)
    bound(project, f":{h_id}:Zero", -0.5, 0.5)
    bound(project, f":{h_id}:Shift", -1000.0, 1000.0)

    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        phase.setSampleProfile(hist, "size", "isotropic", START_SIZE.get(phase.name, 0.3))
        phase.setSampleProfile(hist, "microstrain", "isotropic", START_STRAIN.get(phase.name, 1000.0))
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
        if phase.name in args.strain_phases:
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
        bound(project, f"{phase.id}:{h_id}:Size;i", 0.02, 3.0)
        bound(project, f"{phase.id}:{h_id}:Mustrain;i", 0.0, 15000.0)

    run(project, "phase-profile-fixed-instrument")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    project.set_Frozen()
    run(project, "free-instrument")

    if not args.no_shift:
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        project.set_Frozen()
        run(project, "sample-shift")

    if not args.no_polarization:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Frozen()
        run(project, "polarization")

    project.save(str(out))


if __name__ == "__main__":
    main()
