#!/usr/bin/env python3
"""Build and refine exploratory GSAS-II models for the supplied PXRD scan.

Run with the GSAS-II Python interpreter. This is intentionally kept separate
from the final export script so candidate structures/profile models can be
compared without overwriting the submitted project.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    prepared = Path("trials/models") / f"{cod_id}.cif"
    if prepared.is_file():
        return prepared.resolve()
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def instrument_text() -> str:
    return (
        "# GSAS-II Cu K-alpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:15.0;V:0.0;W:15.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def report(project: G2.G2Project, label: str) -> None:
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    print(f"STEP {label}: Rwp={hist.get_wR()} GOF={cov.get('Rvals', {}).get('GOF')}")
    inst = hist.data["Instrument Parameters"][0]
    print("  instrument", {k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")})
    sp = hist.data["Sample Parameters"]
    print("  sample", {k: sp[k][0] if isinstance(sp[k], list) else sp[k] for k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(
            "  phase",
            phase.name,
            "cell=",
            [round(v, 7) for v in phase.get_cell()["length_a":"length_c"]]
            if False
            else {k: phase.get_cell()[k] for k in ("length_a", "length_b", "length_c", "angle_alpha", "angle_beta", "angle_gamma", "volume")},
            "scale=",
            hap["Scale"][0],
            "size=",
            hap["Size"][:4],
            "mustrain=",
            hap["Mustrain"][:4],
            "PO=",
            hap["Pref.Ori."][:4],
        )


def refine(project: G2.G2Project, label: str) -> None:
    project.refine(makeBack=False)
    report(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="trial.gpx")
    parser.add_argument(
        "--phases",
        nargs="+",
        default=["7219229:CaWO4", "1528915:WO3", "1563196:CaO", "1547347:CaCO3"],
        help="CODID:name entries",
    )
    parser.add_argument("--background", type=int, default=10)
    parser.add_argument("--stop", choices=["scales", "cells", "instrument", "profile", "sample", "atoms", "all"], default="all")
    args = parser.parse_args()

    out = Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    instfile = out.with_suffix(".instprm")
    instfile.write_text(instrument_text())

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(out))
    phases = []
    for item in args.phases:
        cod_id, name = item.split(":", 1)
        phases.append(project.add_phase(str(cod_path(cod_id)), phasename=name, fmthint="CIF"))
    hist = project.add_powder_histogram(
        str(Path("inputs/pattern.csv").resolve()),
        str(instfile),
        phases=phases,
        fmthint="comma/tab/semicolon separated",
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background,
                "coeffs": [900.0] + [0.0] * (args.background - 1),
                "refine": True,
            },
        }
    )
    for i, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0 / phase.data["General"]["Mass"], True]
        phase.setSampleProfile(hist, "size", "isotropic", 0.5)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0)
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Extinction"] = [0.0, False]

    project.set_Controls("cycles", 8)
    refine(project, "scales-background")
    refine(project, "scales-background-settle")
    if args.stop == "scales":
        return

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "zero-cells")
    refine(project, "zero-cells-settle")
    if args.stop == "cells":
        return

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, "instrument-profile")
    if args.stop == "instrument":
        return

    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    refine(project, "phase-size")
    if args.stop == "profile":
        return

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "sample-shift")
    if args.stop == "sample":
        return

    # Reference-mismatch perturbations preserve symmetry. Coordinates are
    # refined only for the two W-bearing phases, where the data carry enough
    # scattering information; occupancies and ADPs remain fixed here.
    for phase in phases[:2]:
        phase.set_refinements({"Atoms": {"all": "X"}})
    refine(project, "coordinates")
    if args.stop == "atoms":
        return

    # One settling cycle with all selected parameters active.
    refine(project, "settle")
    project.save(str(out))
    summary = {
        "Rwp": hist.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "phases": [p.name for p in phases],
    }
    out.with_suffix(".summary.json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
