#!/usr/bin/env python3
"""Prepare COD candidates using the framework's registered-model convention."""

from pathlib import Path
import sys
import warnings

from pymatgen.io.cif import CifParser


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
RUNTIME = Path("learned/divalent-tungstates/runtime").resolve()
sys.path.insert(0, str(RUNTIME))
from models import write_synthetic_model  # noqa: E402


IDS = [
    "7219229",  # scheelite CaWO4
    "1528915",  # monoclinic WO3
    "2311041",  # monoclinic WO3, alternate setting/model
    "1010618",  # monoclinic WO3, smaller cell
    "2106293",  # triclinic WO3
    "1563541",  # monoclinic WO3, smaller cell
    "2107312",  # orthorhombic WO3
    "1563196",  # rocksalt CaO
    "1547347",  # calcite CaCO3
    "2106394",  # monoclinic CaCO3
]


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    out = Path("trials/models")
    out.mkdir(parents=True, exist_ok=True)
    for cod_id in IDS:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            structure = CifParser(
                cod_path(cod_id), occupancy_tolerance=1.0, site_tolerance=1e-5, frac_tolerance=0
            ).parse_structures(primitive=False, on_error="raise")[0]
        structure.remove_oxidation_states()
        target = out / f"{cod_id}.cif"
        write_synthetic_model(structure, target)
        print(cod_id, structure.composition.reduced_formula, len(structure), target)


if __name__ == "__main__":
    main()
