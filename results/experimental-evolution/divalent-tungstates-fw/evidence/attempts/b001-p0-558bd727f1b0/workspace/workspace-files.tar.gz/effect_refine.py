#!/usr/bin/env python3
"""Apply one controlled specimen/phase effect to an existing GSAS-II project."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def phase_fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histograms()[0]
    raw = np.array(
        [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()]
    )
    raw /= raw.sum()
    return {p.name: float(v) for p, v in zip(project.phases(), raw)}


def set_bound(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--surface", action="store_true")
    parser.add_argument("--po", nargs=4, metavar=("PHASE", "H", "K", "L"))
    parser.add_argument("--uniaxial-strain", nargs=4, metavar=("PHASE", "H", "K", "L"))
    parser.add_argument("--isotropic-strain", metavar="PHASE")
    parser.add_argument("--uiso", action="store_true", help="refine one common isotropic U per phase")
    parser.add_argument("--coords", metavar="PHASE", help="refine symmetry-allowed coordinates for one phase")
    parser.add_argument("--coord-window", type=float, default=0.02, help="fractional-coordinate bound around the input model")
    parser.add_argument("--cycles", type=int, default=16)
    args = parser.parse_args()
    if sum([
        args.surface,
        args.po is not None,
        args.uniaxial_strain is not None,
        args.isotropic_strain is not None,
        args.uiso,
        args.coords is not None,
    ]) != 1:
        parser.error("select exactly one effect")

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()))
    out = Path(args.output).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(out))
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    project.update_ids()
    hist = project.histograms()[0]
    # Cell metrics are already converged in the input project. Holding them for
    # one effect-selection step prevents a weak minor phase from destabilizing
    # the metric while a new intensity correction is introduced.
    for phase in project.phases():
        phase.set_refinements({"Cell": False})

    if args.surface:
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.25, True]
        sample["SurfRoughB"] = [0.10, True]
        set_bound(project, f":{hist.id}:SurfRoughA", 0.01, 1.0)
        set_bound(project, f":{hist.id}:SurfRoughB", 0.001, 1.0)
        label = "surface"
    elif args.po:
        name, *axis_text = args.po
        phase = project.phase(name)
        axis = [int(v) for v in axis_text]
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
        set_bound(project, f"{phase.id}:{hist.id}:MD", 0.5, 2.0)
        label = "po-" + name + "-" + "".join(axis_text)
    elif args.uniaxial_strain:
        name, *axis_text = args.uniaxial_strain
        phase = project.phase(name)
        axis = [int(v) for v in axis_text]
        hap = phase.data["Histograms"][hist.name]
        equatorial = max(100.0, float(hap["Mustrain"][1][0]))
        phase.setSampleProfile(hist, "microstrain", "uniaxial", equatorial, equatorial, axis)
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        hap["Mustrain"][2][2] = False
        set_bound(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 15000.0)
        set_bound(project, f"{phase.id}:{hist.id}:Mustrain;a", 0.0, 15000.0)
        label = "strain-" + name + "-" + "".join(axis_text)
    elif args.isotropic_strain:
        phase = project.phase(args.isotropic_strain)
        hap = phase.data["Histograms"][hist.name]
        phase.setSampleProfile(hist, "microstrain", "isotropic", max(100.0, float(hap["Mustrain"][1][0])))
        hap["Mustrain"][2] = [True, False, False]
        set_bound(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 15000.0)
        label = "isotropic-strain-" + args.isotropic_strain
    elif args.uiso:
        # The synthetic reference convention and specimen model assign one
        # scalar Uiso to every atom in a phase. Equivalence constraints retain
        # that physically meaningful parameterization.
        for phase in project.phases():
            phase.set_refinements({"Atoms": {"all": "U"}})
        project.save()
        for phase in project.phases():
            variables = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.data["Atoms"])]
            if len(variables) > 1:
                project.add_EquivConstr(variables, reloadIdx=False)
            for variable in variables:
                set_bound(project, variable, 0.001, 0.03)
        label = "common-uiso"
    else:
        for item in project.phases():
            item.set_refinements({"Atoms": {"all": " "}})
        phase = project.phase(args.coords)
        phase.set_refinements({"Atoms": {"all": "X"}})
        for i, atom in enumerate(phase.data["Atoms"]):
            for axis, value in zip("xyz", atom[3:6]):
                set_bound(
                    project,
                    f"{phase.id}::dA{axis}:{i}",
                    float(value) - args.coord_window,
                    float(value) + args.coord_window,
                )
        label = "coords-" + args.coords

    project.refine(makeBack=False)
    sample = hist.data["Sample Parameters"]
    print(
        "RESULT",
        label,
        "Rwp",
        hist.get_wR(),
        "surface",
        sample["SurfRoughA"][0],
        sample["SurfRoughB"][0],
        "fractions",
        phase_fractions(project),
    )
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("EFFECT", phase.name, "PO", hap["Pref.Ori."][:4], "strain", hap["Mustrain"][:4])
    print("VARY", project.data.get("Covariance", {}).get("data", {}).get("varyList", []))
    project.save(str(out))


if __name__ == "__main__":
    main()
