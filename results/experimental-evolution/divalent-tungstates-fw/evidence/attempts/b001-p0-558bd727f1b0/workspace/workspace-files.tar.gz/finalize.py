#!/usr/bin/env python3
"""Create the submission artifacts from the selected converged GSAS-II model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = Path("trials/coords_caco3.gpx")
FORMULAS = {"CaWO4": "CaWO4", "WO3": "WO3", "CaO": "CaO", "CaCO3": "CaCO3"}
CIF_NAMES = {
    "CaWO4": "phase_CaWO4.cif",
    "WO3": "phase_WO3.cif",
    "CaO": "phase_CaO.cif",
    "CaCO3": "phase_CaCO3.cif",
}


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE.resolve()))
    source_rvals = dict(project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}))
    project.save(str(Path("final.gpx").resolve()))

    # Force one no-optimization forward calculation so the saved profile arrays
    # and reflection lists are regenerated from the final atomic/profile model.
    project = G2.G2Project(gpxfile=str(Path("final.gpx").resolve()))
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    project = G2.G2Project(gpxfile=str(Path("final.gpx").resolve()))
    hist = project.histograms()[0]

    masses = np.array(
        [phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0] for phase in project.phases()],
        dtype=float,
    )
    fractions = masses / masses.sum()

    # Export saved atom values rather than applying possibly stale covariance
    # corrections; this is also the independent replay convention.
    export_project = G2.G2Project(gpxfile=str(Path("final.gpx").resolve()))
    export_project.data["Covariance"]["data"] = {}
    phase_rows = []
    for phase, fraction in zip(export_project.phases(), fractions):
        filename = CIF_NAMES[phase.name]
        phase.export_CIF(filename)
        phase_rows.append(
            {
                "name": phase.name,
                "formula": FORMULAS[phase.name],
                "cif_path": filename,
                "weight_fraction": float(fraction),
                "weight_percent": float(100.0 * fraction),
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            }
        )

    x, observed, weights, calculated, background, difference = [
        np.asarray(v, dtype=float) for v in hist.data["data"][1]
    ]
    difference = observed - calculated
    np.savetxt(
        "fit.csv",
        np.column_stack([x, observed, calculated, difference]),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )

    n_observations = len(x)
    n_variables = int(source_rvals.get("Nvars", 0))
    chi_square = float(np.sum(weights * difference**2))
    rwp = float(100.0 * np.sqrt(chi_square / np.sum(weights * observed**2)))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    gof = float(np.sqrt(chi_square / max(1, n_observations - n_variables)))
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "phases": phase_rows,
        "unresolved_components": [],
        "refinement_histogram": hist.name,
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "goodness_of_fit": gof,
            "chi_square": chi_square,
            "n_observations": n_observations,
            "n_refined_variables": n_variables,
            "durbin_watson": float(hist.data["data"][0].get("Durbin-Watson")),
        },
        "calibration": {
            "zero_deg": float(inst["Zero"][1]),
            "specimen_shift_micrometre_gsasii": float(sample["Shift"][0]),
            "wavelength_Kalpha1_angstrom": float(inst["Lam1"][1]),
            "wavelength_Kalpha2_angstrom": float(inst["Lam2"][1]),
        },
        "quantification_basis": "GSAS-II Rietveld scale times refined unit-cell mass, normalized over the four modeled crystalline phases",
    }
    Path("result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
