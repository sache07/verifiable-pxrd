#!/usr/bin/env python3
"""Add or delete a phase in a converged project for inventory tests."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--add", type=Path)
    group.add_argument("--delete", type=int)
    parser.add_argument("--name", default="test_phase")
    parser.add_argument("--initial-scale", type=float, default=0.05)
    parser.add_argument("--max-cycles", type=int, default=6)
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.input), newgpx=str(args.output.resolve()))
    hist = gpx.histogram(0)
    gpx.data["Controls"]["data"]["max cyc"] = args.max_cycles
    if args.add:
        phase = gpx.add_phase(
            str(args.add.resolve()), phasename=args.name, histograms=[hist], fmthint="CIF"
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [args.initial_scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.1
        hap["Size"][2][0] = False
        phase.set_refinements({"Cell": False})
    else:
        phase = gpx.phases()[args.delete]
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Use"] = False
    gpx.save()
    gpx.refine()
    gpx.refine()
    gpx.save()

    fractions = {}
    try:
        fractions = {k: v[0] for k, v in hist.ComputeMassFracs().items()}
    except Exception:
        pass
    print(
        json.dumps(
            {
                "rwp": hist.get_wR(),
                "fractions": fractions,
                "phases": {
                    phase.name: phase.data["Histograms"][hist.name]
                    for phase in gpx.phases()
                },
            },
            indent=2,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
