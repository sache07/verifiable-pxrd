#!/usr/bin/env python3
"""Apply controlled profile/specimen branches to an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def values(gpx: G2sc.G2Project) -> dict:
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = {}
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "scale": hap["Scale"][0],
            "size": hap["Size"][1],
            "size_flags": hap["Size"][2],
            "mustrain": hap["Mustrain"][1],
            "mustrain_flags": hap["Mustrain"][2],
            "pref_ori": hap["Pref.Ori."],
            "cell": phase.get_cell(),
        }
    try:
        fractions = {k: v[0] for k, v in hist.ComputeMassFracs().items()}
    except Exception:
        fractions = {}
    return {
        "rwp": hist.get_wR(),
        "residuals": hist.residuals,
        "fractions": fractions,
        "instrument": {
            key: {"value": inst[key][1], "refine": inst[key][2]}
            for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")
            if key in inst
        },
        "sample": {
            key: sample[key]
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
            if key in sample
        },
        "phases": phases,
    }


def clear_profile_flags(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "X", "Y", "SH/L", "Polariz."):
        if key in inst:
            inst[key][2] = False
    sample = hist.data["Sample Parameters"]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in sample:
            sample[key][1] = False
    for phase in gpx.phases():
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )


def apply_step(gpx: G2sc.G2Project, step: str, args) -> None:
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    if step.startswith("size"):
        suffix = step.removeprefix("size")
        selected = gpx.phases() if not suffix else [gpx.phases()[int(suffix)]]
        starts = args.size_start or [0.10] * len(selected)
        if len(starts) == 1:
            starts *= len(selected)
        for phase, start in zip(selected, starts):
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": start, "refine": True}}
            )
    elif step.startswith("strain"):
        suffix = step.removeprefix("strain")
        selected = gpx.phases() if not suffix else [gpx.phases()[int(suffix)]]
        starts = args.strain_start or [1000.0] * len(selected)
        if len(starts) == 1:
            starts *= len(selected)
        for phase, start in zip(selected, starts):
            hap = phase.data["Histograms"][hist.name]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = float(start)
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )
    elif step.startswith("ustrain"):
        key, _, hkl_text = step.partition(":")
        phase = gpx.phases()[int(key.removeprefix("ustrain"))]
        hkl = [int(v) for v in hkl_text]
        if len(hkl) != 3:
            raise ValueError("uniaxial strain direction must have three digits")
        hap = phase.data["Histograms"][hist.name]
        start = float(hap["Mustrain"][1][0])
        hap["Mustrain"][1][0] = start
        hap["Mustrain"][1][1] = start
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "uniaxial",
                    "direction": hkl,
                    "refine": True,
                }
            }
        )
    elif step in {"w", "x", "y", "shl", "pol", "uvw", "uvwx"}:
        keys = {
            "w": ["W"],
            "x": ["X"],
            "y": ["Y"],
            "shl": ["SH/L"],
            "pol": ["Polariz."],
            "uvw": ["U", "V", "W"],
            "uvwx": ["U", "V", "W", "X"],
        }[step]
        hist.set_refinements({"Instrument Parameters": keys})
    elif step == "narrow":
        # Resolution-scale restart motivated by the narrowest isolated peaks;
        # phase broadening remains active and is re-equilibrated by refinement.
        starts = {"U": 0.5, "V": -0.3, "W": 2.0, "X": 0.2, "Y": 0.0, "SH/L": 0.01}
        for key, value in starts.items():
            inst[key][1] = value
            inst[key][2] = False
    elif step in {"jitterlo", "jitterhi"}:
        factor = 0.8 if step == "jitterlo" else 1.2
        inst["W"][1] = 6.0 if step == "jitterlo" else 11.0
        inst["Polariz."][1] = 0.85 if step == "jitterlo" else 0.95
        inst["Zero"][1] = 0.18 if step == "jitterlo" else 0.34
        for phase in gpx.phases():
            hap = phase.data["Histograms"][hist.name]
            hap["Size"][1][0] *= factor
            hap["Mustrain"][1][0] /= factor
    elif step == "fulllimits":
        x = hist.data["data"][1][0]
        hist.data["Limits"][1] = [float(x[0]), float(x[-1])]
    elif step == "zero":
        inst["Zero"][2] = True
        sample["Shift"][0] = 0.0
        sample["Shift"][1] = False
    elif step == "shift":
        inst["Zero"][1] = 0.0
        inst["Zero"][2] = False
        sample["Shift"][1] = True
    elif step == "joint":
        inst["Zero"][2] = True
        sample["Shift"][1] = True
    elif step == "rough":
        # Positive starts avoid the singular A=B=0 point.
        sample["SurfRoughA"] = [0.10, True]
        sample["SurfRoughB"] = [0.05, True]
    elif step.startswith("bkg:"):
        _, family_text, count_text = step.split(":", 2)
        family = {
            "cheb1": "chebyschev-1",
            "cheb": "chebyschev",
            "cos": "cosine",
            "q2": "Q^2 power series",
            "qm2": "Q^-2 power series",
            "lin": "lin interpolate",
            "inv": "inv interpolate",
            "log": "log interpolate",
        }[family_text]
        count = int(count_text)
        current = hist.data["Background"][0]
        if family == current[0]:
            coeffs = list(current[3 : 3 + count])
            coeffs += [0.0] * (count - len(coeffs))
        elif "interpolate" in family:
            coeffs = [2800.0] * count
        else:
            coeffs = [2800.0] + [0.0] * (count - 1)
        hist.set_refinements(
            {
                "Background": {
                    "type": family,
                    "no. coeffs": count,
                    "coeffs": coeffs,
                    "refine": True,
                }
            }
        )
    elif step.startswith("texture"):
        texture_key, _, hkl_text = step.partition(":")
        hkl = [int(v) for v in (hkl_text or "001")]
        if len(hkl) != 3:
            raise ValueError("texture direction must be three digits, e.g. texture:001")
        suffix = texture_key.removeprefix("texture")
        selected = gpx.phases() if not suffix else [gpx.phases()[int(suffix)]]
        for phase in selected:
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][3] = hkl
            phase.set_HAP_refinements({"Pref.Ori.": True})
    elif step.startswith("atoms"):
        key, _, element = step.partition(":")
        phase = gpx.phases()[int(key.removeprefix("atoms"))]
        selected = {
            atom.label: (atom.refinement_flags + "X" if "X" not in atom.refinement_flags else atom.refinement_flags)
            for atom in phase.atoms()
            if atom.element == element
        }
        if not selected:
            raise ValueError(f"no {element} atoms in phase {phase.name}")
        phase.set_refinements({"Atoms": selected})
    elif step == "freezeatoms":
        for phase in gpx.phases():
            phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
    elif step.startswith("cell"):
        phase = gpx.phases()[int(step.removeprefix("cell"))]
        phase.set_refinements({"Cell": True})
    elif step.startswith("site"):
        key, _, label = step.partition(":")
        phase = gpx.phases()[int(key.removeprefix("site"))]
        atom = phase.atom(label)
        if atom is None:
            raise ValueError(f"no atom {label} in phase {phase.name}")
        flags = atom.refinement_flags
        phase.set_refinements(
            {"Atoms": {label: flags + "X" if "X" not in flags else flags}}
        )
    elif step.startswith("uiso"):
        key, _, element = step.partition(":")
        phase = gpx.phases()[int(key.removeprefix("uiso"))]
        for atom in phase.atoms():
            if atom.element == element and atom.uiso <= 0:
                atom.uiso = 0.005
        selected = {
            atom.label: (atom.refinement_flags + "U" if "U" not in atom.refinement_flags else atom.refinement_flags)
            for atom in phase.atoms()
            if atom.element == element
        }
        if not selected:
            raise ValueError(f"no {element} atoms in phase {phase.name}")
        phase.set_refinements({"Atoms": selected})
    elif step == "reopt":
        pass
    else:
        raise ValueError(f"unknown step {step}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("steps", nargs="+")
    parser.add_argument("--size-start", type=float, action="append")
    parser.add_argument("--strain-start", type=float, action="append")
    parser.add_argument("--keep-existing-profile-flags", action="store_true")
    parser.add_argument("--max-cycles", type=int, default=5)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(str(args.input), newgpx=str(args.output.resolve()))
    gpx.data["Controls"]["data"]["max cyc"] = args.max_cycles
    gpx.data["Controls"]["data"]["min dM/M"] = 0.0005
    if not args.keep_existing_profile_flags:
        clear_profile_flags(gpx)
    gpx.save()

    for step in args.steps:
        apply_step(gpx, step, args)
        gpx.refine()
        gpx.save()
        print(json.dumps({"step": step, **values(gpx)}, default=str))

    print(json.dumps(values(gpx), indent=2, default=str))


if __name__ == "__main__":
    main()
