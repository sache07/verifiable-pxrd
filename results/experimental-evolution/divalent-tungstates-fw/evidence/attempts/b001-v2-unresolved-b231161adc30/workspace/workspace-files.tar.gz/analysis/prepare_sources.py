#!/usr/bin/env python3
"""Normalize the serious structural parents and build one diagnostic analogue."""

from pathlib import Path

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path(__file__).resolve().parents[1]
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
OUT = ROOT / "analysis" / "sources"


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def load(cod_id: str) -> Structure:
    return CifParser(cod_path(cod_id), occupancy_tolerance=2).parse_structures(
        primitive=False
    )[0]


def write(structure: Structure, filename: str) -> None:
    CifWriter(structure, symprec=0.05, refine_struct=False).write_file(OUT / filename)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)

    # COD 2311041 is a physically sound P21/c WO3 parent in an obtuse setting.
    # This determinant-one basis change gives the familiar pseudo-orthogonal
    # monoclinic setting without changing the structure or cell volume.
    wo3 = load("2311041")
    wo3.make_supercell([[-1, 0, -1], [0, 1, 0], [1, 0, 0]])
    write(wo3, "WO3_from_COD_2311041.cif")

    baco3 = load("9010928")
    write(baco3, "BaCO3_from_COD_9010928.cif")

    # Diagnostic BaWO4 candidate: use the fully occupied, high-quality
    # scheelite BaMoO4 coordinates from COD 2300459, substitute Mo -> W, and
    # adopt the published BaWO4 cell from COD 1527204. The direct BaWO4 entry
    # has overlapping half-occupied oxygen alternatives and is not suitable
    # for refinement without this repair.
    bawo4 = load("2300459")
    bawo4.replace_species({"Mo": "W"})
    frac = bawo4.frac_coords.copy()
    species = [site.species for site in bawo4]
    bawo4 = Structure(Lattice.tetragonal(5.614, 12.719), species, frac)
    write(bawo4, "BaWO4_diagnostic_from_COD_2300459_1527204.cif")


if __name__ == "__main__":
    main()
