#!/usr/bin/env python3
"""Create the submission artifacts directly from the converged GSAS-II project."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "trials" / "full_limits.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "WO3_2311041": {
        "name": "monoclinic tungsten trioxide",
        "formula": "WO3",
        "cif_path": "phase_WO3.cif",
        "source_provenance": "COD 2311041 (published monoclinic WO3 parent)",
    },
    "BaCO3_9010928": {
        "name": "orthorhombic barium carbonate (witherite)",
        "formula": "BaCO3",
        "cif_path": "phase_BaCO3.cif",
        "source_provenance": "COD 9010928 (published witherite parent)",
    },
}


def main() -> None:
    # Refine once from the converged source project so final.gpx is itself the
    # project used for all values and exports below.
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    gpx.refine()
    gpx.save()

    hist = gpx.histogram(0)
    phases = gpx.phases()
    if {p.name for p in phases} != set(PHASE_INFO):
        raise RuntimeError("Unexpected phase inventory in final project")

    fractions = hist.ComputeMassFracs()
    total = sum(float(value[0]) for value in fractions.values())
    if not np.isclose(total, 1.0, atol=1e-10):
        raise RuntimeError(f"Phase fractions do not sum to one: {total}")

    phase_rows = []
    for phase in phases:
        info = PHASE_INFO[phase.name]
        phase.export_CIF(str(ROOT / info["cif_path"]))
        fraction, esd = fractions[phase.name]
        general = phase.data["General"]
        cell = general["Cell"]
        phase_rows.append(
            {
                **info,
                "project_phase_name": phase.name,
                "space_group": general["SGData"]["SpGrp"],
                "weight_fraction": float(fraction),
                "weight_fraction_esd": float(esd),
                "cell": {
                    "a_angstrom": float(cell[1]),
                    "b_angstrom": float(cell[2]),
                    "c_angstrom": float(cell[3]),
                    "alpha_deg": float(cell[4]),
                    "beta_deg": float(cell[5]),
                    "gamma_deg": float(cell[6]),
                    "volume_angstrom3": float(cell[7]),
                },
            }
        )

    # GSAS-II profile order is x, observed, weight, calculated, background,
    # and stored difference. Recompute the submitted difference explicitly.
    profile = np.asarray(np.ma.filled(hist.data["data"][1], np.nan), dtype=float)
    x, observed, _, calculated, background, _ = profile
    difference = observed - calculated
    if not np.all(np.isfinite(np.vstack((x, observed, calculated, difference)))):
        raise RuntimeError("Non-finite final profile")
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference, background)),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt=["%.8f", "%.10g", "%.10g", "%.10g", "%.10g"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    independent_rwp = float(100.0 * np.sqrt(chi_square / denominator))
    covariance = gpx.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    residuals = hist.residuals
    result = {
        "phases": phase_rows,
        "refinement_histogram": hist.name,
        "fit_statistics": {
            "rwp_percent": independent_rwp,
            "gsas_ii_rwp_percent": float(residuals["wR"]),
            "rp_percent": float(residuals["R"]),
            "rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square": chi_square,
            "n_points": int(x.size),
            "n_refined_parameters": int(rvals["Nvars"]),
            "converged": bool(rvals["converged"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
