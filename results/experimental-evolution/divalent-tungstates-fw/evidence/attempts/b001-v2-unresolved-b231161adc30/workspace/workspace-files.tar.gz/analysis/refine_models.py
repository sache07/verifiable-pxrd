#!/usr/bin/env python3
"""Create and refine matched GSAS-II trial models for the public PXRD data.

Run with the GSAS-II Python interpreter. Candidate arguments have the form
``name=COD_ID``. The script deliberately keeps atomic coordinates fixed; the
trial stage is for inventory and parent-structure comparison.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_xye() -> Path:
    """Convert the public CSV to GSAS-II xye with Poisson count weights."""
    source = ROOT / "inputs" / "pattern.csv"
    target = ROOT / "analysis" / "pattern.xye"
    rows = np.loadtxt(source, delimiter=",", skiprows=1)
    sigma = np.sqrt(np.maximum(rows[:, 1], 1.0))
    np.savetxt(target, np.column_stack((rows, sigma)), fmt="%.8f %.8f %.8f")
    return target


def set_starting_values(hist) -> None:
    inst = hist.data["Instrument Parameters"][0]
    # Explicit observed-profile starts; refinement flags are set separately.
    starts = {
        "Zero": 0.0,
        "Polariz.": 0.70,
        "U": 2.0,
        "V": -1.0,
        "W": 12.0,
        "X": 1.0,
        "Y": 0.0,
        "SH/L": 0.02,
    }
    for key, value in starts.items():
        if key in inst:
            inst[key][1] = value
    sample = hist.data["Sample Parameters"]
    if "Scale" in sample:
        # Keep the histogram scale fixed: varying it with all phase scales is
        # exactly singular and corrupts quantitative phase analysis.
        sample["Scale"] = [1.0, False]
    if "Shift" in sample:
        sample["Shift"][0] = 0.0
    if "SurfRoughA" in sample:
        sample["SurfRoughA"][0] = 0.0
        sample["SurfRoughB"][0] = 0.0


def source_path(source: str) -> Path:
    if source.isdigit() and len(source) == 7:
        return cod_path(source)
    path = Path(source)
    return path if path.is_absolute() else ROOT / path


def make_project(out: Path, candidates: list[tuple[str, str]]) -> G2sc.G2Project:
    xye = prepare_xye()
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(xye), str(ROOT / "analysis" / "instrument.instprm"), fmthint="xye"
    )
    set_starting_values(hist)
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [2800.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": False,
            },
        }
    )
    for name, source in candidates:
        path = source_path(source)
        if not path.exists():
            raise FileNotFoundError(path)
        gpx.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
    # Stable positive initial scales.
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][0] = 0.5 / max(len(candidates), 1)
        hap["Scale"][1] = False
    gpx.save()
    return gpx


def refine_shortlist(gpx: G2sc.G2Project) -> None:
    """Matched low-flexibility refinement used to rank structural parents."""
    hist = gpx.histogram(0)
    phases = gpx.phases()
    # Background and scales first, then cells and a single angular correction.
    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    gpx.refine()

    for phase in phases:
        phase.set_refinements({"Cell": True})
    gpx.refine()

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    gpx.refine()

    gpx.refine()
    gpx.save()


def refine_basic(gpx: G2sc.G2Project) -> None:
    refine_shortlist(gpx)
    hist = gpx.histogram(0)
    # Common peak-shape pass; coordinates remain fixed.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "SH/L"]})
    gpx.refine()
    gpx.refine()
    gpx.save()


def phase_fractions(gpx: G2sc.G2Project) -> dict[str, float]:
    hist = gpx.histogram(0)
    # GSAS-II quantitative phase analysis normalizes phase scale * cell mass.
    raw = {}
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        scale = float(hap["Scale"][0])
        mass = float(phase.data["General"].get("Mass", 0.0))
        raw[phase.name] = max(scale * mass, 0.0)
    total = sum(raw.values())
    return {key: value / total for key, value in raw.items()} if total else raw


def summary(gpx: G2sc.G2Project) -> dict:
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    return {
        "project": gpx.filename,
        "residuals": hist.residuals,
        "fractions": phase_fractions(gpx),
        "cells": {p.name: p.get_cell() for p in gpx.phases()},
        "instrument": {
            k: inst[k][1]
            for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")
            if k in inst
        },
        "sample": {
            k: sample[k][0]
            for k in ("Shift", "SurfRoughA", "SurfRoughB")
            if k in sample
        },
    }


def parse_candidate(text: str) -> tuple[str, str]:
    try:
        name, cid = text.split("=", 1)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("candidate must be NAME=COD_ID") from exc
    if not name or not cid:
        raise argparse.ArgumentTypeError("candidate must be NAME=COD_ID_OR_CIF_PATH")
    return name, cid


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--candidate", action="append", type=parse_candidate, required=True)
    parser.add_argument("--setup-only", action="store_true")
    parser.add_argument("--mode", choices=("shortlist", "basic"), default="basic")
    args = parser.parse_args()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    gpx = make_project(args.out.resolve(), args.candidate)
    if not args.setup_only and args.mode == "shortlist":
        refine_shortlist(gpx)
    elif not args.setup_only:
        refine_basic(gpx)
    print(json.dumps(summary(gpx), indent=2, default=str))


if __name__ == "__main__":
    main()
