#!/usr/bin/env python3
"""Continue a GSAS-II project with selected physically constrained refinements."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def refine(project: G2.G2Project, label: str, repeats: int = 1) -> None:
    project.set_Controls("cycles", 10)
    for i in range(repeats):
        before = project.histogram(0).get_wR()
        project.refine()
        after = project.histogram(0).get_wR()
        print(f"{label}.{i}: {before:.8f} -> {after:.8f}", flush=True)


def set_bound(project: G2.G2Project, var: str, lo: float, hi: float) -> None:
    project.set_Controls("parmMin", lo, variable=var)
    project.set_Controls("parmMax", hi, variable=var)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument(
        "--actions",
        default="uiso,polarization",
        help="comma-separated: stable,uiso,polarization,roughness",
    )
    ap.add_argument("--shift", type=float, default=0.0)
    ap.add_argument("--keep-shift-refining", action="store_true")
    ap.add_argument(
        "--rough-a",
        type=float,
        default=None,
        help="fix SurfRoughA at this value and refine only SurfRoughB",
    )
    ap.add_argument("--phase", default=None, help="phase name for texture/strain action")
    ap.add_argument("--axis", default="0,0,1", help="h,k,l for texture/strain action")
    args = ap.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    hist = project.histogram(0)
    actions = {a.strip() for a in args.actions.split(",") if a.strip()}
    axis = [int(v) for v in args.axis.split(",")]
    if len(axis) != 3:
        raise ValueError("--axis requires h,k,l")

    # Variables that hit a physical boundary in the exploratory refinement are
    # fixed at that boundary before clearing GSAS-II's frozen-variable cache.
    inst = hist.InstrumentParameters
    for name in ("U", "W", "SH/L"):
        inst[name][2] = False
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if hap["Mustrain"][1][0] <= 0.0:
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2][0] = False
    project.data["Controls"]["data"]["parmFrozen"] = {}

    if "uiso" not in actions:
        for phase in project.phases():
            for atom in phase.atoms():
                if atom.uiso <= 0.0030001:
                    atom.refinement_flags = atom.refinement_flags.replace("U", "")

    hist.SampleParameters["Shift"][0] = float(args.shift)
    hist.SampleParameters["Shift"][1] = bool(args.keep_shift_refining)

    if "stable" in actions:
        refine(project, "stable", 2)

    if "uiso" in actions:
        for phase in project.phases():
            vars_ = []
            for i, atom in enumerate(phase.atoms()):
                atom.uiso = 0.01
                atom.refinement_flags = "XU"
                var = f"{phase.id}::AUiso:{i}"
                vars_.append(var)
                set_bound(project, var, 0.003, 0.020)
            project.add_EquivConstr(vars_)
        refine(project, "uiso", 2)

    if "polarization" in actions:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        set_bound(project, f":{hist.id}:Polariz.", 0.5, 1.0)
        refine(project, "polarization", 2)

    if "roughness" in actions:
        rough_a = 0.15 if args.rough_a is None else float(args.rough_a)
        hist.SampleParameters["SurfRoughA"] = [rough_a, args.rough_a is None]
        hist.SampleParameters["SurfRoughB"] = [0.05, True]
        set_bound(project, f":{hist.id}:SurfRoughA", 0.0, 0.6)
        set_bound(project, f":{hist.id}:SurfRoughB", 0.0, 0.5)
        refine(project, "roughness", 2)

    if "texture" in actions:
        if args.phase is None:
            raise ValueError("texture requires --phase")
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
        set_bound(project, f"{phase.id}:{hist.id}:MD", 0.7, 1.4)
        refine(project, f"texture-{phase.name}-{axis}", 2)

    if "uniaxial-strain" in actions:
        if args.phase is None:
            raise ValueError("uniaxial-strain requires --phase")
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][hist.name]
        start = max(300.0, float(hap["Mustrain"][1][0]))
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = start
        hap["Mustrain"][1][1] = start
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        hap["Mustrain"][3] = axis
        set_bound(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 8000.0)
        set_bound(project, f"{phase.id}:{hist.id}:Mustrain;a", 0.0, 8000.0)
        refine(project, f"strain-{phase.name}-{axis}", 2)

    project.save()
    print("final", project.histogram(0).get_wR())


if __name__ == "__main__":
    main()
