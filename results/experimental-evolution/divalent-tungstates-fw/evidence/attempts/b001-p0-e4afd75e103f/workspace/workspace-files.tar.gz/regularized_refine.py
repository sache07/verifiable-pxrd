#!/usr/bin/env python3
"""Refine published coordinates with soft Cartesian displacement priors.

GSAS-II's parameter limits are applied only after an unconstrained least-
squares pass, which is unsuitable for stabilizing correlated light-atom
coordinates.  Here each coordinate shift is instead included as a genuine
least-squares restraint, centred on the published structure.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIobj as G2obj


PARENT_COORDS = {
    "BaCO3": {
        "Ba": (0.25, 0.4162, 0.7556),
        "C": (0.25, 0.7434, -0.0711),
        "O1": (0.25, 0.9011, -0.0775),
        "O2": (0.4654, 0.6805, -0.0788),
    },
    "WO3": {
        "O6": (0.28, 0.24, -0.03),
        "W2": (0.247, 0.033, 0.781),
        "O2": (0.0, 0.475, 0.22),
        "O5": (0.28, 0.04, 0.03),
        "O4": (0.21, 0.29, 0.735),
        "O3": (0.29, 0.29, 0.265),
        "O1": (0.0, 0.025, 0.22),
        "W1": (0.252, 0.026, 0.285),
    },
}


def coordinate_restraint(variable: str) -> G2obj.ExpressionObj:
    expression = G2obj.ExpressionObj()
    expression.expression = "q"
    expression.assgnVars = {"q": variable}
    return expression


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "--prior-a",
        type=float,
        default=0.025,
        help="one-sigma prior for each Cartesian coordinate shift, in A",
    )
    parser.add_argument("--cycles", type=int, default=15)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    histogram = project.histogram(0)

    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    # Remove obsolete Uiso equivalences from the exploratory project.
    project.data["Constraints"]["data"]["Phase"] = []
    project.data["Restraints"]["data"] = {}

    for phase in project.phases():
        parent = PARENT_COORDS[phase.name]
        cell = phase.get_cell()
        lengths = (cell["length_a"], cell["length_b"], cell["length_c"])
        general = {"wtFactor": 1.0, "General": [], "Use": True}
        project.data["Restraints"]["data"][phase.name] = {"General": general}
        for atom_index, atom in enumerate(phase.atoms()):
            atom.coordinates = parent[atom.label]
            atom.refinement_flags = "X"
            # The synthetic structures use one isotropic displacement value
            # per phase. Keep the conservative lower-bound value fixed while
            # establishing the coordinate model.
            atom.uiso = 0.003
            for axis, axis_length in zip("xyz", lengths):
                variable = f"{phase.id}::dA{axis}:{atom_index}"
                expression = coordinate_restraint(variable)
                fractional_esd = float(args.prior_a) / float(axis_length)
                general["General"].append((expression, 0.0, fractional_esd))

    project.set_Controls("cycles", args.cycles)
    before = histogram.get_wR()
    project.refine()
    regularized = project.histogram(0).get_wR()
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    print(
        f"regularized coordinate pass: {before:.8f} -> {regularized:.8f}; "
        f"restraint sum={rvals.get('RestraintSum')}",
        flush=True,
    )

    # The shift variables are relative to the coordinates at the start of a
    # refinement. Freeze the resulting coordinates before any repeat pass so
    # that the prior centre cannot drift.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = ""
    project.data["Restraints"]["data"] = {}
    controls["parmFrozen"] = {}
    project.refine()
    final = project.histogram(0).get_wR()
    print(f"fixed-coordinate nuisance pass: {regularized:.8f} -> {final:.8f}")
    project.save()


if __name__ == "__main__":
    main()
