#!/usr/bin/env python3
"""Stabilize atomic refinement by fitting one independent site at a time."""

from __future__ import annotations

import argparse
import copy
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

from regularized_refine import PARENT_COORDS, coordinate_restraint


def set_nuisance_flags(project: G2.G2Project, enabled: bool) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = enabled
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = enabled and value[2]
    # Instrument flags must be restored explicitly because the previous loop
    # intentionally cannot remember which parameters had been selected.
    if enabled:
        for name in ("Zero", "Polariz.", "X"):
            hist.InstrumentParameters[name][2] = True
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    if enabled:
        hist.SampleParameters["SurfRoughB"][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = enabled
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = enabled
        hap["Size"][2][0] = enabled
        hap["Mustrain"][2][0] = enabled and phase.name == "WO3"


def displacement_norm(phase: G2.G2Phase, atom, parent) -> float:
    delta = np.asarray(atom.coordinates, dtype=float) - np.asarray(parent, dtype=float)
    delta -= np.rint(delta)
    amat, _ = G2lat.cell2AB(phase.data["General"]["Cell"][1:7])
    return float(np.linalg.norm(amat @ delta))


def cap_atom_displacement(phase: G2.G2Phase, atom, cap: float) -> tuple[float, float]:
    parent = np.asarray(PARENT_COORDS[phase.name][atom.label], dtype=float)
    delta = np.asarray(atom.coordinates, dtype=float) - parent
    delta -= np.rint(delta)
    before = displacement_norm(phase, atom, parent)
    factor = min(1.0, cap / max(before, 1e-15))
    atom.coordinates = tuple(parent + factor * delta)
    return before, before * factor


def cap_element_rms(phase: G2.G2Phase, element: str, cap: float) -> tuple[float, float]:
    chosen = [a for a in phase.atoms() if a.element == element]
    vectors = []
    amat, _ = G2lat.cell2AB(phase.data["General"]["Cell"][1:7])
    for atom in chosen:
        delta = np.asarray(atom.coordinates) - np.asarray(
            PARENT_COORDS[phase.name][atom.label]
        )
        delta -= np.rint(delta)
        vectors.append((atom, delta, float(np.linalg.norm(amat @ delta))))
    before = float(np.sqrt(np.mean([v[2] ** 2 for v in vectors])))
    factor = min(1.0, cap / max(before, 1e-15))
    for atom, delta, _norm in vectors:
        parent = np.asarray(PARENT_COORDS[phase.name][atom.label])
        atom.coordinates = tuple(parent + factor * delta)
    return before, before * factor


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--prior-a", type=float, default=0.025)
    parser.add_argument("--heavy-cap-a", type=float, default=0.04)
    parser.add_argument("--oxygen-cap-a", type=float, default=0.05)
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--immediate-cap", action="store_true")
    parser.add_argument("--sweeps", type=int, default=1)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.data["Constraints"]["data"]["Phase"] = []
    project.data["Restraints"]["data"] = {}
    for phase in project.phases():
        for atom in phase.atoms():
            atom.coordinates = PARENT_COORDS[phase.name][atom.label]
            atom.uiso = 0.003
            atom.refinement_flags = ""

    set_nuisance_flags(project, False)
    project.set_Controls("cycles", args.cycles)

    # Heavy scatterers first, then the light atoms. Each pass starts from the
    # published site and contains only the site's 2-3 symmetry-independent
    # shifts, avoiding the severe all-site correlations in this pattern.
    order = []
    for phase in project.phases():
        order.extend((phase, i) for i, atom in enumerate(phase.atoms()) if atom.element != "O")
    for phase in project.phases():
        order.extend((phase, i) for i, atom in enumerate(phase.atoms()) if atom.element == "O")

    for sweep in range(args.sweeps):
        for phase, atom_index in order:
            atom = phase.atoms()[atom_index]
            atom.refinement_flags = "X"
            cell = phase.get_cell()
            lengths = (cell["length_a"], cell["length_b"], cell["length_c"])
            entries = []
            for axis, length in zip("xyz", lengths):
                entries.append(
                    (
                        coordinate_restraint(f"{phase.id}::dA{axis}:{atom_index}"),
                        0.0,
                        args.prior_a / length,
                    )
                )
            project.data["Restraints"]["data"] = {
                phase.name: {
                    "General": {"wtFactor": 1.0, "General": entries, "Use": True}
                }
            }
            before = project.histogram(0).get_wR()
            project.refine()
            after = project.histogram(0).get_wR()
            atom = phase.atoms()[atom_index]
            atom.refinement_flags = ""
            move = displacement_norm(phase, atom, PARENT_COORDS[phase.name][atom.label])
            cap_note = ""
            if args.immediate_cap:
                cap = args.oxygen_cap_a if atom.element == "O" else args.heavy_cap_a
                unclipped, move = cap_atom_displacement(phase, atom, cap)
                cap_note = f" (proposal {unclipped:.4f} A)"
            print(
                f"s{sweep + 1} {phase.name}/{atom.label}: "
                f"{before:.6f} -> {after:.6f}; move={move:.4f} A{cap_note}",
                flush=True,
            )

    project.data["Restraints"]["data"] = {}
    for phase in project.phases():
        for element in sorted({a.element for a in phase.atoms()}):
            cap = args.oxygen_cap_a if element == "O" else args.heavy_cap_a
            before, after = cap_element_rms(phase, element, cap)
            print(f"{phase.name}/{element} RMS: {before:.4f} -> {after:.4f} A")

    set_nuisance_flags(project, True)
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 15)
    before = project.histogram(0).get_wR()
    project.refine()
    print(
        f"final nuisance pass: {before:.8f} -> {project.histogram(0).get_wR():.8f}"
    )
    project.save()


if __name__ == "__main__":
    main()
