#!/usr/bin/env python3
"""Coordinate refinement stabilized by short-range distance restraints."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIImath as G2mth

from regularized_refine import PARENT_COORDS


def restraint_template() -> dict:
    return {
        "Bond": {"wtFactor": 1.0, "Range": 2.0, "Bonds": [], "Use": True},
    }


def set_parent_distance_targets(phase: G2.G2Phase, cutoff: float, esd: float) -> int:
    atoms = phase.atoms()
    phase.addDistRestraint(
        list(range(len(atoms))),
        list(range(len(atoms))),
        bond=2.0,
        factor=2.0,
        ESD=esd,
    )
    bonds = phase.proj.data["Restraints"]["data"][phase.name]["Bond"]["Bonds"]
    by_id = {atom.ranId: np.asarray(atom.coordinates, dtype=float) for atom in atoms}
    amat, _ = G2lat.cell2AB(phase.data["General"]["Cell"][1:7])
    selected = []
    seen = set()
    for indices, operations, _target, _old_esd in bonds:
        xyz = np.asarray([by_id[i] for i in indices], dtype=float)
        xyz = G2mth.getSyXYZ(xyz, operations, phase.data["General"]["SGData"])
        distance = float(G2mth.getRestDist(xyz, amat))
        if not 1.0 <= distance <= cutoff:
            continue
        # searchBondRestr can report exact duplicates from inverse searches.
        # Retaining one copy avoids unintentionally changing its weight.
        key = (tuple(indices), tuple(operations))
        if key in seen:
            continue
        seen.add(key)
        selected.append([indices, operations, distance, float(esd)])
    phase.proj.data["Restraints"]["data"][phase.name]["Bond"]["Bonds"] = selected
    return len(selected)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--esd", type=float, default=0.04)
    parser.add_argument("--weight", type=float, default=1.0)
    parser.add_argument("--cutoff", type=float, default=3.2)
    parser.add_argument("--cycles", type=int, default=15)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    project.data["Constraints"]["data"]["Phase"] = []
    project.data["Restraints"]["data"] = {}

    for phase in project.phases():
        for atom in phase.atoms():
            atom.coordinates = PARENT_COORDS[phase.name][atom.label]
            atom.refinement_flags = "X"
            atom.uiso = 0.003
        project.data["Restraints"]["data"][phase.name] = restraint_template()
        count = set_parent_distance_targets(phase, args.cutoff, args.esd)
        phase.setDistRestraintWeight(args.weight)
        print(f"{phase.name}: {count} distance restraints", flush=True)

    project.set_Controls("cycles", args.cycles)
    before = project.histogram(0).get_wR()
    project.refine()
    restrained = project.histogram(0).get_wR()
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    print(
        f"restrained coordinate pass: {before:.8f} -> {restrained:.8f}; "
        f"restraint sum={rvals.get('RestraintSum')}",
        flush=True,
    )

    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = ""
    project.data["Restraints"]["data"] = {}
    controls["parmFrozen"] = {}
    project.refine()
    print(
        f"fixed-coordinate nuisance pass: {restrained:.8f} -> "
        f"{project.histogram(0).get_wR():.8f}"
    )
    project.save()


if __name__ == "__main__":
    main()
