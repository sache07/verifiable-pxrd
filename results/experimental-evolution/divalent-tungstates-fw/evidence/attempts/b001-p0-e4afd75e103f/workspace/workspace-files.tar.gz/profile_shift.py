#!/usr/bin/env python3
"""Profile a fixed Bragg-Brentano specimen displacement."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("shift_um", type=float)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    hist = project.histogram(0)
    hist.SampleParameters["Shift"] = [float(args.shift_um), False]
    # Start on the near-degenerate Zero/Shift ridge so that a large fixed
    # displacement does not present the cell refiner with displaced peaks.
    hist.InstrumentParameters["Zero"][1] = 0.257315 + 0.000599 * args.shift_um
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 15)
    project.refine()
    print(
        f"shift={args.shift_um:.1f} Rwp={hist.get_wR():.8f} "
        f"zero={hist.InstrumentParameters['Zero'][1]:.8f}"
    )
    project.save()


if __name__ == "__main__":
    main()
