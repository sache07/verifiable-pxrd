#!/usr/bin/env python3
"""Profile physically capped coordinate directions with atoms held fixed."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

from regularized_refine import PARENT_COORDS


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path, help="project supplying nuisance parameters")
    parser.add_argument("directions", type=Path, help="project supplying coordinate directions")
    parser.add_argument("output", type=Path)
    parser.add_argument("--heavy-cap-a", type=float, default=0.04)
    parser.add_argument("--oxygen-cap-a", type=float, default=0.05)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    direction_project = G2.G2Project(gpxfile=str(args.directions))
    project.data["Constraints"]["data"]["Phase"] = []
    project.data["Restraints"]["data"] = {}
    project.data["Controls"]["data"]["parmFrozen"] = {}

    for phase in project.phases():
        direction_phase = direction_project.phase(phase.name)
        direction_by_label = {a.label: a for a in direction_phase.atoms()}
        amat, _ = G2lat.cell2AB(phase.data["General"]["Cell"][1:7])
        for element in sorted({a.element for a in phase.atoms()}):
            atoms = [a for a in phase.atoms() if a.element == element]
            deltas = []
            for atom in atoms:
                parent = np.asarray(PARENT_COORDS[phase.name][atom.label])
                delta = np.asarray(direction_by_label[atom.label].coordinates) - parent
                delta -= np.rint(delta)
                deltas.append(delta)
            rms = float(
                np.sqrt(np.mean([np.linalg.norm(amat @ delta) ** 2 for delta in deltas]))
            )
            cap = args.oxygen_cap_a if element == "O" else args.heavy_cap_a
            factor = min(1.0, cap / max(rms, 1e-15))
            for atom, delta in zip(atoms, deltas):
                parent = np.asarray(PARENT_COORDS[phase.name][atom.label])
                atom.coordinates = tuple(parent + factor * delta)
                atom.refinement_flags = ""
                atom.uiso = 0.003
            print(
                f"{phase.name}/{element}: direction RMS {rms:.5f} A, "
                f"used {rms * factor:.5f} A"
            )

    project.set_Controls("cycles", 15)
    project.refine()
    print(f"final Rwp={project.histogram(0).get_wR():.8f}")
    project.save()


if __name__ == "__main__":
    main()
