#!/usr/bin/env python3
"""Refit from published coordinates with bounded coordinate displacements."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


PARENT_COORDS = {
    "BaCO3": {
        "Ba": (0.25, 0.4162, 0.7556),
        "C": (0.25, 0.7434, -0.0711),
        "O1": (0.25, 0.9011, -0.0775),
        "O2": (0.4654, 0.6805, -0.0788),
    },
    "WO3": {
        "O6": (0.28, 0.24, -0.03),
        "W2": (0.247, 0.033, 0.781),
        "O2": (0.0, 0.475, 0.22),
        "O5": (0.28, 0.04, 0.03),
        "O4": (0.21, 0.29, 0.735),
        "O3": (0.29, 0.29, 0.265),
        "O1": (0.0, 0.025, 0.22),
        "W1": (0.252, 0.026, 0.285),
    },
}


def bound(project: G2.G2Project, variable: str, center: float, limit: float) -> None:
    # GSAS-II names refined fractional coordinates dAx/dAy/dAz, but these
    # variables contain the absolute fractional coordinate, not an increment.
    project.set_Controls("parmMin", center - limit, variable=variable)
    project.set_Controls("parmMax", center + limit, variable=variable)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--coords", choices=("none", "heavy", "all"), default="all")
    ap.add_argument("--frac-limit", type=float, default=0.012)
    ap.add_argument("--uiso", type=float, default=0.005)
    args = ap.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {}
    # Remove the exploratory Uiso equivalences. Uiso is fixed phasewise here.
    project.data["Constraints"]["data"]["Phase"] = []

    for phase in project.phases():
        parent = PARENT_COORDS[phase.name]
        for i, atom in enumerate(phase.atoms()):
            atom.coordinates = parent[atom.label]
            atom.uiso = float(args.uiso)
            refine = args.coords == "all" or (
                args.coords == "heavy" and atom.element in {"Ba", "W"}
            )
            atom.refinement_flags = "X" if refine else ""
            if refine:
                for xyz, center in zip("xyz", parent[atom.label]):
                    bound(
                        project,
                        f"{phase.id}::dA{xyz}:{i}",
                        center,
                        args.frac_limit,
                    )

    project.set_Controls("cycles", 10)
    before = hist.get_wR()
    project.refine()
    after_coords = project.histogram(0).get_wR()
    print(f"coordinate pass: {before:.8f} -> {after_coords:.8f}", flush=True)

    # Freeze the bounded structural result and let only nuisance parameters
    # settle. This prevents cumulative coordinate drift over repeated cycles.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = ""
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.refine()
    print(f"nuisance pass: {after_coords:.8f} -> {project.histogram(0).get_wR():.8f}")
    project.save()


if __name__ == "__main__":
    main()
