#!/usr/bin/env python3
"""Create the requested final GSAS-II project and synchronized exports."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "final_candidate2.gpx"
FINAL = ROOT / "final.gpx"


def main() -> None:
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    histogram = project.histogram(0)

    # These two profile terms were selected by profiling and are strongly
    # correlated with phase size/scale if left simultaneous. Holding them at
    # their profiled values gives a stable final covariance calculation without
    # changing the calculated curve materially.
    histogram.InstrumentParameters["X"][2] = False
    histogram.SampleParameters["SurfRoughB"][1] = False
    histogram.SampleParameters["Shift"][1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.data["Constraints"]["data"]["Phase"] = []
    project.data["Restraints"]["data"] = {}
    project.set_Controls("cycles", 15)
    project.refine()
    project.save()

    # Reload what is actually on disk before every export, ensuring the CIFs,
    # fractions and profile all derive from final.gpx rather than an in-memory
    # precursor.
    project = G2.G2Project(gpxfile=str(FINAL))
    histogram = project.histogram(0)
    cif_names = {
        "BaCO3": "BaCO3_witherite.cif",
        "WO3": "WO3_monoclinic.cif",
    }
    for phase in project.phases():
        phase.export_CIF(str(ROOT / cif_names[phase.name]))

    original = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    x_original, y_original = original.T
    arrays = histogram.data["data"][1]
    x_project = np.asarray(arrays[0], dtype=float)
    y_project = np.asarray(arrays[1], dtype=float)
    y_calculated = np.asarray(arrays[3], dtype=float)
    if not np.array_equal(x_original, x_project):
        raise RuntimeError("final.gpx grid differs from inputs/pattern.csv")
    if not np.array_equal(y_original, y_project):
        raise RuntimeError("final.gpx observations differ from inputs/pattern.csv")
    if not np.all(np.isfinite(y_calculated)) or np.min(y_calculated) < 0:
        raise RuntimeError("invalid calculated profile")
    fit = np.column_stack(
        (x_original, y_original, y_calculated, y_original - y_calculated)
    )
    np.savetxt(
        ROOT / "fit.csv",
        fit,
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.1f", "%.10f", "%.10f"],
    )

    weights = 1.0 / np.maximum(y_original, 1.0)
    difference = y_original - y_calculated
    rwp = 100.0 * math.sqrt(
        float(np.sum(weights * difference**2))
        / float(np.sum(weights * y_original**2))
    )
    rp = 100.0 * float(np.sum(np.abs(difference))) / float(np.sum(y_original))
    rvals = project.data["Covariance"]["data"]["Rvals"]

    mass_scales = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        mass_scales.append(float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]))
    normalizer = sum(mass_scales)
    fractions = [value / normalizer for value in mass_scales]

    phase_details = {
        "BaCO3": {
            "display_name": "Witherite (BaCO3)",
            "formula": "BaCO3",
            "space_group": "Pmcn (No. 62; witherite setting)",
            "reference": "COD 9010928",
        },
        "WO3": {
            "display_name": "Monoclinic tungsten(VI) oxide (WO3)",
            "formula": "WO3",
            "space_group": "P21/n (No. 14)",
            "reference": "COD 1528915",
        },
    }
    result_phases = []
    for phase, fraction in zip(project.phases(), fractions):
        details = phase_details[phase.name]
        result_phases.append(
            {
                "name": details["display_name"],
                "formula": details["formula"],
                "space_group": details["space_group"],
                "reference_structure": details["reference"],
                "cif_path": cif_names[phase.name],
                "weight_fraction": fraction,
            }
        )

    result = {
        "schema_version": 1,
        "phases": result_phases,
        "weight_fraction_basis": "normalized over the two modeled crystalline phases",
        "refinement_histogram": histogram.name,
        "fit_statistics": {
            "r_wp_percent": rwp,
            "r_p_percent": rp,
            "r_expected_percent": float(histogram.residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    baco3 = 100.0 * fractions[0]
    wo3 = 100.0 * fractions[1]
    report = f"""# Powder XRD phase analysis

## Result

The crystalline pattern is explained by two residual precursor phases:

- witherite BaCO3, Pmcn (No. 62): **{baco3:.2f} wt%**
- monoclinic WO3, P21/n (No. 14): **{wo3:.2f} wt%**

Fractions are normalized over the modeled crystalline material. They do not quantify amorphous material. A practical uncertainty of about ±1 wt% is more realistic than the much smaller least-squares scale errors because scale, surface roughness, profile shape and light-atom coordinates are correlated.

## Evidence and refinement

Reference structures COD 9010928 (witherite) and COD 1528915 (monoclinic WO3) account for all coherent peaks in a two-phase Rietveld fit. The WO3 low-angle triplet at about 23.42, 23.87 and 24.64° 2theta, the BaCO3-dominant feature at 24.10°, and the phase-specific groups near 33.5–34.7°, 42.1–45.1°, 50.2° and 56.2° are reproduced together. The strongest scheelite BaWO4 line expected near 26.5–26.7° is absent, and adding a tungstate phase was not justified by coherent residual peaks.

The final fit uses the supplied Cu Kalpha1/Kalpha2 wavelengths and 0.5 intensity ratio, Poisson count weights, a refined polynomial background, phase scales and cells, isotropic size/profile terms, polarization, zero offset and a profiled Bragg-Brentano specimen displacement. Fit statistics are Rwp = {rwp:.4f}%, Rp = {rp:.4f}%, Rexp = {float(histogram.residuals['wRmin']):.4f}% and GOF = {float(rvals['GOF']):.4f} for {int(rvals['Nobs'])} points.

## Remaining uncertainty

The phase identities and approximately 46:54 mass ratio are robust; that ratio also agrees with unreacted 1:1-metal BaCO3/WO3 dosing. Atomic shifts were kept close to the published structures because an unrestricted refinement overfit correlated oxygen coordinates. Consequently the structure topology, cells and heavy-atom sites are defensible, but individual oxygen displacements and isotropic displacement parameters cannot be determined reliably from this powder pattern and should not be interpreted as a new high-precision structure determination. The zero offset and specimen displacement are likewise highly correlated. The short O–O contact intrinsic to this historical monoclinic WO3 model remains a crystallographic-model caveat, not evidence for an additional phase.

No unindexed crystalline phase is evident above the residual/noise level; a trace phase with strongly overlapping peaks cannot be excluded reliably.
"""
    (ROOT / "report.md").write_text(report)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
