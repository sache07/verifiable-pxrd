#!/usr/bin/env python3
"""Build and run a conservative GSAS-II trial refinement for candidate phases.

Run with the GSAS-II Python interpreter. This is an analysis helper; the final
submission is exported separately after model selection.
"""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def run_refinement(project: G2.G2Project, label: str) -> None:
    project.set_Controls("cycles", 8)
    project.refine()
    hist = project.histogram(0)
    print(f"{label}: wR={hist.get_wR():.5f} residuals={hist.residuals}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--wo3", default="1528915")
    parser.add_argument("--baco3", default="9010928")
    parser.add_argument("--bawo4", default=None)
    parser.add_argument("--atoms", action="store_true")
    args = parser.parse_args()

    out = args.outdir.resolve()
    out.mkdir(parents=True, exist_ok=True)

    # GSAS-II's xye reader uses sigma in column 3. Poisson sigma is the
    # appropriate uncertainty for these original counts.
    raw = np.genfromtxt("inputs/pattern.csv", delimiter=",", names=True)
    x = np.asarray(raw["two_theta_deg"], dtype=float)
    y = np.asarray(raw["intensity"], dtype=float)
    sigma = np.sqrt(np.maximum(y, 1.0))
    data_path = out / "pattern.xye"
    np.savetxt(data_path, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")

    inst_path = out / "instrument.instprm"
    inst_path.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )

    candidates = [("BaCO3", args.baco3), ("WO3", args.wo3)]
    if args.bawo4:
        candidates.append(("BaWO4", args.bawo4))

    project = G2.G2Project(newgpx=str(out / "trial.gpx"))
    phases = []
    for name, cod_id in candidates:
        source = cod_path(cod_id)
        local = out / f"source_{name}_{cod_id}.cif"
        shutil.copyfile(source, local)
        phases.append(project.add_phase(str(local), phasename=name, fmthint="CIF"))

    hist = project.add_powder_histogram(
        str(data_path), str(inst_path), phases="all", fmthint="xye"
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [float(np.median(y))] + [0.0] * 9,
                "refine": True,
            },
        }
    )
    for phase in phases:
        phase.HAPvalue("Scale", 1.0)
        phase.set_HAP_refinements({"Scale": True})

    # Keep every profile/specimen parameter inside the laboratory's physical
    # support (with zero allowed for phase microstrain when it is absent).
    bounds = {
        ":0:Zero": (-0.30, 0.30),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.50, 1.00),
        ":0:Shift": (-800.0, 800.0),
        ":0:SurfRoughA": (0.0, 0.60),
        ":0:SurfRoughB": (0.0, 0.50),
    }
    for phase in phases:
        pfx = f"{phase.id}:{hist.id}:"
        bounds[pfx + "Scale"] = (0.0, 1000.0)
        bounds[pfx + "Size;i"] = (0.04, 1.50)
        bounds[pfx + "Mustrain;i"] = (0.0, 8000.0)
    for variable, (lower, upper) in bounds.items():
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)

    # Scales/background first, followed by peak positions and widths.
    run_refinement(project, "scale-background")
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    run_refinement(project, "zero-cell")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run_refinement(project, "instrument")

    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.15
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 300.0
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    run_refinement(project, "phase-broadening")

    # Shift is introduced only after a stable cell/zero solution exists.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_refinement(project, "sample-shift")

    if args.atoms:
        for phase in phases:
            phase.set_refinements({"Atoms": {"all": "X"}})
        run_refinement(project, "coordinates")
        run_refinement(project, "coordinates-repeat")

    project.save()
    arrays = hist.data["data"][1]
    yobs = np.asarray(arrays[1], dtype=float)
    ycalc = np.asarray(arrays[3], dtype=float)
    weights = np.asarray(arrays[2], dtype=float)
    mask = np.isfinite(yobs) & np.isfinite(ycalc) & np.isfinite(weights) & (weights > 0)
    rwp = 100.0 * math.sqrt(
        np.sum(weights[mask] * (yobs[mask] - ycalc[mask]) ** 2)
        / np.sum(weights[mask] * yobs[mask] ** 2)
    )
    metrics = {
        "wo3_cod_id": args.wo3,
        "baco3_cod_id": args.baco3,
        "bawo4_cod_id": args.bawo4,
        "Rwp_percent_manual": rwp,
        "Rwp_percent_GSASII": hist.get_wR(),
        "residuals": hist.residuals,
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "phases": {},
    }
    scales = []
    for phase in phases:
        scale = float(phase.data["Histograms"][hist.name]["Scale"][0])
        mass = float(phase.data["General"]["Mass"])
        scales.append(scale * mass)
    total = sum(scales)
    for phase, weighted_scale in zip(phases, scales):
        hap = phase.data["Histograms"][hist.name]
        metrics["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "mass_fraction": weighted_scale / total,
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    (out / "metrics.json").write_text(json.dumps(metrics, indent=2, default=str) + "\n")
    print(json.dumps(metrics, indent=2, default=str))


if __name__ == "__main__":
    main()
