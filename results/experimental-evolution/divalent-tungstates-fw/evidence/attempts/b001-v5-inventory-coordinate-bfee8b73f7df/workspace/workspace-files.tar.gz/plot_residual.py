"""Plot arrays exported by residual_diagnostics.py."""
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

source, output = sys.argv[1:3]
data = np.load(source)
x = data["x"]
observed = data["observed"]
calculated = data["calculated"]
background = data["background"]
standardized = data["standardized"]
smooth = data["smooth"]
rwp = float(data["rwp"])

fig, axes = plt.subplots(3, 1, figsize=(14, 10), sharex=False,
                         gridspec_kw={"height_ratios": [2.2, 1, 1]})
axes[0].plot(x, observed, color="black", lw=0.55, label="observed")
axes[0].plot(x, calculated, color="#c62828", lw=0.7, label="calculated")
axes[0].plot(x, background, color="#1565c0", lw=0.55, label="background")
axes[0].set_yscale("log")
axes[0].set_ylim(max(1, np.min(observed) * 0.7), np.max(observed) * 1.25)
axes[0].legend(loc="upper right", ncol=3)
axes[0].set_ylabel("counts (log)")
axes[0].set_title(f"Rwp={rwp:.4f}%")
axes[1].plot(x, standardized, color="#37474f", lw=0.45)
axes[1].plot(x, smooth, color="#ef6c00", lw=0.8)
axes[1].axhline(0, color="black", lw=0.5)
axes[1].set_ylabel("(obs-calc)/sqrt(obs)")
axes[1].set_xlim(x[0], x[-1])
axes[2].plot(x, standardized, color="#37474f", lw=0.55)
axes[2].plot(x, smooth, color="#ef6c00", lw=0.9)
axes[2].axhline(0, color="black", lw=0.5)
axes[2].set_xlim(10, 60)
axes[2].set_ylim(-20, 20)
axes[2].set_ylabel("standardized residual")
axes[2].set_xlabel(r"2$\theta$ (deg)")
fig.tight_layout()
fig.savefig(output, dpi=180)
