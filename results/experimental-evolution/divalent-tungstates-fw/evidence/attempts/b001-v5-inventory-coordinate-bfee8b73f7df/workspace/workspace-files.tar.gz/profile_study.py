"""Run one controlled GSAS-II profile-mechanism branch from a supplied project."""
from __future__ import annotations

import json
import math
import shutil
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent


def plain(value):
    if isinstance(value, dict):
        return {str(key): plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(item) for item in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def clear_frozen(project):
    project.set_Frozen()


def set_limit(project, variable, lower=None, upper=None):
    if lower is not None:
        project.set_Controls("parmMin", float(lower), variable)
    if upper is not None:
        project.set_Controls("parmMax", float(upper), variable)


def set_isotropic_strain(project, phase_index, refine, value):
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.data["Histograms"][hist.name]
    phase.clear_HAP_refinements({"Mustrain": True}, [hist])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:3] = [float(value), 1000.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    if refine:
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True,
                           "LGmix": {"value": 1.0, "refine": False}}}, [hist]
        )
        set_limit(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 20000.0)


def set_texture(project, phase_index, axis):
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.data["Histograms"][hist.name]
    phase.clear_HAP_refinements({"Pref.Ori.": True}, [hist])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = list(axis)
    phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])
    set_limit(project, f"{phase.id}:{hist.id}:MD", 0.2, 5.0)


def apply_mode(project, mode):
    hist = project.histogram(0)
    instrument = hist.InstrumentParameters
    sample = hist.SampleParameters

    if mode == "settle":
        return

    if mode.startswith("bg"):
        family = hist.data["Background"][0][0]
        count = 10
        if mode[2:].isdigit():
            count = int(mode[2:])
        elif mode == "bg_chebyschev":
            family = "chebyschev"
        elif mode == "bg_cosine":
            family = "cosine"
        elif mode == "bg_qminus2":
            family = "Q^-2 power series"
        else:
            raise ValueError(f"unknown background mode {mode}")
        if family == hist.data["Background"][0][0]:
            hist.set_refinements({"Background": {"type": family, "no. coeffs": count, "refine": True}})
        else:
            observed = np.asarray(hist.data["data"][1][1], dtype=float)
            seed = max(1.0, float(np.percentile(observed, 5)))
            hist.set_refinements({"Background": {"type": family, "no. coeffs": count,
                                                  "coeffs": [seed] + [0.0] * (count - 1),
                                                  "refine": True}})
        return

    if mode in {"zero_only", "shift_only", "zero_shift"}:
        old_zero = float(instrument["Zero"][1])
        hist.clear_refinements({"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]})
        instrument["Zero"][1] = old_zero if mode in {"zero_only", "zero_shift"} else 0.0
        sample["Shift"][0] = 0.0
        if mode in {"zero_only", "zero_shift"}:
            hist.set_refinements({"Instrument Parameters": ["Zero"]})
            set_limit(project, f":{hist.id}:Zero", -1.0, 1.0)
        if mode in {"shift_only", "zero_shift"}:
            if mode == "shift_only":
                # Seed the displacement near the angular offset represented by
                # the prior zero term, avoiding a poorly staged cell excursion.
                radius = float(sample.get("Gonio. radius", 200.0))
                sample["Shift"][0] = -old_zero * math.pi * radius / 0.36
            hist.set_refinements({"Sample Parameters": ["Shift"]})
            set_limit(project, f":{hist.id}:Shift", -1500.0, 1500.0)
        return

    if mode in {"rough_none", "rough_A", "rough_B", "rough_AB"}:
        hist.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        if mode == "rough_none":
            sample["SurfRoughA"][0] = 0.0
            sample["SurfRoughB"][0] = 0.0
        elif mode == "rough_A":
            sample["SurfRoughB"][0] = 0.0
            hist.set_refinements({"Sample Parameters": ["SurfRoughA"]})
        elif mode == "rough_B":
            sample["SurfRoughA"][0] = 0.0
            hist.set_refinements({"Sample Parameters": ["SurfRoughB"]})
        else:
            hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        for key in ("SurfRoughA", "SurfRoughB"):
            set_limit(project, f":{hist.id}:{key}", 0.0, 5.0)
        return

    if mode == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        set_limit(project, f":{hist.id}:Polariz.", 0.0, 1.0)
        return

    if mode in {"w", "vw", "uw", "uvw", "asym", "uw_asym", "uvw_asym"}:
        names = []
        if mode in {"w", "vw", "uw", "uvw", "uw_asym", "uvw_asym"}:
            names.append("W")
        if mode in {"uw", "uvw", "uw_asym", "uvw_asym"}:
            names.append("U")
        if mode in {"vw", "uvw", "uvw_asym"}:
            names.append("V")
        if mode in {"asym", "uw_asym", "uvw_asym"}:
            names.append("SH/L")
        hist.set_refinements({"Instrument Parameters": names})
        for key in ("U", "W"):
            if key in names:
                set_limit(project, f":{hist.id}:{key}", 0.0, 200.0)
        if "V" in names:
            set_limit(project, f":{hist.id}:V", -200.0, 200.0)
        if "SH/L" in names:
            set_limit(project, f":{hist.id}:SH/L", 0.0001, 0.5)
        return

    if mode == "strain_none":
        for index in range(len(project.phases())):
            set_isotropic_strain(project, index, False, 0.0)
        return

    if mode == "strain_all":
        for index in range(len(project.phases())):
            old = project.phase(index).data["Histograms"][hist.name]["Mustrain"][1][0]
            set_isotropic_strain(project, index, True, old if old > 0 else 300.0)
        return

    if mode.startswith("strain_p"):
        selected = {int(character) for character in mode.split("p", 1)[1]}
        for idx in range(len(project.phases())):
            old = project.phase(idx).data["Histograms"][hist.name]["Mustrain"][1][0]
            seed = old if old > 0 or idx not in selected else 300.0
            set_isotropic_strain(project, idx, idx in selected, seed)
        return

    if mode.startswith("tex_p"):
        # tex_p2_001, etc.
        _, ptoken, atoken = mode.split("_")
        index = int(ptoken[1:])
        axis = tuple(int(ch) for ch in atoken)
        set_texture(project, index, axis)
        return

    if mode.startswith("usize_p"):
        # usize_p0_001, etc.
        _, ptoken, atoken = mode.split("_")
        index = int(ptoken[1:])
        axis = tuple(int(ch) for ch in atoken)
        phase = project.phase(index)
        hap = phase.data["Histograms"][hist.name]
        old = max(0.01, float(hap["Size"][1][0]))
        phase.clear_HAP_refinements({"Size": True}, [hist])
        hap["Size"][0] = "uniaxial"
        hap["Size"][1][:3] = [old, old, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Size"][3] = list(axis)
        phase.set_HAP_refinements({"Size": {"type": "uniaxial", "direction": list(axis),
                                             "refine": True,
                                             "LGmix": {"value": 1.0, "refine": False}}}, [hist])
        for suffix in ("i", "a"):
            set_limit(project, f"{phase.id}:{hist.id}:Size;{suffix}", 0.01, 20.0)
        return

    if mode.startswith("ustrain_p"):
        # ustrain_p0_001, etc.
        _, ptoken, atoken = mode.split("_")
        index = int(ptoken[1:])
        axis = tuple(int(ch) for ch in atoken)
        phase = project.phase(index)
        hap = phase.data["Histograms"][hist.name]
        old = max(100.0, float(hap["Mustrain"][1][0]))
        phase.clear_HAP_refinements({"Mustrain": True}, [hist])
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][:3] = [old, old, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][3] = list(axis)
        phase.set_HAP_refinements({"Mustrain": {"type": "uniaxial", "direction": list(axis),
                                                 "refine": True,
                                                 "LGmix": {"value": 1.0, "refine": False}}}, [hist])
        for suffix in ("i", "a"):
            set_limit(project, f"{phase.id}:{hist.id}:Mustrain;{suffix}", 0.0, 20000.0)
        return

    if mode.startswith("gstrain_p"):
        index = int(mode.split("p", 1)[1])
        phase = project.phase(index)
        hap = phase.data["Histograms"][hist.name]
        phase.clear_HAP_refinements({"Mustrain": True}, [hist])
        hap["Mustrain"][0] = "generalized"
        hap["Mustrain"][4] = [max(0.01, float(value)) for value in hap["Mustrain"][4]]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][4])
        phase.set_HAP_refinements({"Mustrain": {"type": "generalized", "refine": True,
                                                 "LGmix": {"value": 1.0, "refine": False}}}, [hist])
        for coefficient in range(len(hap["Mustrain"][4])):
            set_limit(project, f"{phase.id}:{hist.id}:Mustrain;{coefficient}", 0.0, 20000.0)
        return

    raise ValueError(f"unknown mode {mode}")


def profile_screen(hist):
    x, observed, weights, calculated, background, difference = [
        np.asarray(a, dtype=float) for a in hist.data["data"][1][:6]
    ]
    inst = hist.InstrumentParameters
    theta = np.radians(x / 2.0)
    gaussian = inst["U"][1] * np.tan(theta) ** 2 + inst["V"][1] * np.tan(theta) + inst["W"][1]
    lorentzian = inst["X"][1] / np.maximum(np.cos(theta), 1e-12) + inst["Y"][1] * np.tan(theta) + inst["Z"][1]
    return {
        "background_min": float(np.nanmin(background)),
        "background_max": float(np.nanmax(background)),
        "gaussian_width_sq_min": float(np.nanmin(gaussian)),
        "lorentzian_width_min": float(np.nanmin(lorentzian)),
        "calculated_min": float(np.nanmin(calculated)),
        "finite": bool(np.all(np.isfinite(calculated))),
    }


def summarize(project, mode, history):
    hist = project.histogram(0)
    covariance = project.data.get("Covariance", {}).get("data", {})
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        masses.append(mass_scale)
        phases.append({
            "name": phase.name,
            "fraction": None,
            "cell": phase.get_cell(),
            "scale": plain(hap["Scale"]),
            "size": plain(hap["Size"]),
            "mustrain": plain(hap["Mustrain"]),
            "texture": plain(hap["Pref.Ori."]),
        })
    total = sum(masses)
    for phase, contribution in zip(phases, masses):
        phase["fraction"] = contribution / total
    return {
        "mode": mode,
        "history": history,
        "rwp": hist.get_wR(),
        "rp": hist.residuals.get("R"),
        "gof": covariance.get("Rvals", {}).get("GOF"),
        "rmin": hist.residuals.get("wRmin"),
        "rvals": plain(covariance.get("Rvals", {})),
        "vary": [str(v) for v in covariance.get("varyList", [])],
        "frozen": project.get_Frozen(),
        "background": plain(hist.data["Background"][0]),
        "instrument": {key: plain(hist.InstrumentParameters[key]) for key in
                       ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")},
        "sample": {key: plain(hist.SampleParameters[key]) for key in
                   ("Shift", "SurfRoughA", "SurfRoughB")},
        "screen": profile_screen(hist),
        "phases": phases,
    }


def run(source, mode, output):
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    clear_frozen(project)
    apply_mode(project, mode)
    project.set_Controls("cycles", 16)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    history = []
    previous = None
    # Repeated starts make the final shift report meaningful and expose drift.
    for iteration in range(3):
        project.refine()
        rwp = float(project.histogram(0).get_wR())
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        history.append({"iteration": iteration + 1, "rwp": rwp,
                        "max_shift_over_esd": rvals.get("Max shft/sig"),
                        "converged": rvals.get("converged"),
                        "del_chi2": rvals.get("DelChi2")})
        if previous is not None and abs(previous - rwp) < 1e-6 and abs(float(rvals.get("Max shft/sig", 999))) < 0.5:
            break
        previous = rwp
    project.save(str(output))
    print("PROFILE", json.dumps(summarize(project, mode, history), allow_nan=True))


if __name__ == "__main__":
    if len(sys.argv) != 4:
        raise SystemExit("usage: profile_study.py SOURCE.gpx MODE OUTPUT.gpx")
    G2.SetPrintLevel("warn")
    run(Path(sys.argv[1]).resolve(), sys.argv[2], Path(sys.argv[3]).resolve())
