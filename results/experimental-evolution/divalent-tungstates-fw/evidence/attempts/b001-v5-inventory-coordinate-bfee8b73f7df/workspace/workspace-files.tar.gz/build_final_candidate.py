"""Normalize the selected model, re-equilibrate coordinate blocks, and freeze them."""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def refine(project, stage, repeats):
    history = []
    previous = None
    project.set_Frozen()
    for iteration in range(repeats):
        project.refine()
        r = project.data["Covariance"]["data"]["Rvals"]
        history.append({"stage": stage, "iteration": iteration + 1,
                        "rwp": r["Rwp"], "max_shift": r["Max shft/sig"],
                        "converged": r["converged"], "lamMax": r.get("lamMax")})
        if (previous is not None and r["converged"]
                and abs(previous - r["Rwp"]) < 1e-6
                and abs(r["Max shft/sig"]) < 0.5):
            break
        previous = r["Rwp"]
    return history


def atom_flags(project, enabled):
    selected = {
        0: {"O1": "XU"},
        1: {"W1": "X", "W2": "X", "O1": "X", "O3": "X", "O6": "X"},
        2: {"Ca1": "X", "O1": "X", "O2": "X", "O3": "X"},
    }
    for idx, phase in enumerate(project.phases()):
        for atom in phase.data["Atoms"]:
            atom[2] = selected.get(idx, {}).get(atom[0], "") if enabled else ""


def normalize_wo3(project):
    phase = project.phase(1)
    uiso = phase.data["General"]["AtomPtrs"][2] + 3
    for atom in phase.data["Atoms"]:
        atom[uiso] = 0.01


def screen(project):
    hist = project.histogram(0)
    x, yo, wt, yc, yb, yd = [np.asarray(v, dtype=float) for v in hist.data["data"][1][:6]]
    inst = hist.InstrumentParameters
    theta = np.radians(x / 2.0)
    g2 = inst["U"][1] * np.tan(theta) ** 2 + inst["V"][1] * np.tan(theta) + inst["W"][1]
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(phase.data["General"]["Mass"] * hap["Scale"][0])
        phases.append({"name": phase.name, "cell": phase.get_cell(),
                       "size": plain(hap["Size"]), "strain": plain(hap["Mustrain"]),
                       "texture": plain(hap["Pref.Ori."])})
    total = sum(masses)
    for phase, mass in zip(phases, masses):
        phase["fraction"] = mass / total
    r = project.data["Covariance"]["data"]["Rvals"]
    return {"rwp": r["Rwp"], "rp": hist.residuals.get("R"), "gof": r["GOF"],
            "rmin": hist.residuals.get("wRmin"), "max_shift": r["Max shft/sig"],
            "converged": r["converged"], "nvars": r["Nvars"],
            "frozen": project.get_Frozen(), "background_min": float(np.min(yb)),
            "gaussian_width_sq_min": float(np.min(g2)),
            "calculated_min": float(np.min(yc)), "phases": phases}


def run(source, output):
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 18)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    normalize_wo3(project)

    atom_flags(project, False)
    history = refine(project, "normalized_profile", 4)
    atom_flags(project, True)
    history += refine(project, "selected_coordinates", 5)
    atom_flags(project, False)
    history += refine(project, "coordinates_frozen_final_profile", 4)

    project.save(str(output))
    print("FINALCAND", json.dumps({"history": history, "screen": screen(project)},
                                  allow_nan=True))


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: build_final_candidate.py SOURCE.gpx OUTPUT.gpx")
    G2.SetPrintLevel("warn")
    run(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
