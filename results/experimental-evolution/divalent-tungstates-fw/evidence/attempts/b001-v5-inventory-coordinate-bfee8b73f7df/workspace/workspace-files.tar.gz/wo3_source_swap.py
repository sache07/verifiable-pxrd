"""Final fixed-coordinate comparison of the shortlisted WO3 sources.

The two candidates are inserted into the same mechanism-complete three-phase
project.  All atomic parameters are fixed for this source-choice step and the
otherwise identical profile/cell/scale model is re-equilibrated.
"""
from __future__ import annotations

import copy
import json
import math
import shutil
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
DB = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/resources/b001-c05/cif")


def cif(cid: str) -> Path:
    return DB / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def set_limit(project, variable, lower, upper):
    project.set_Controls("parmMin", float(lower), variable)
    project.set_Controls("parmMax", float(upper), variable)


def freeze_atoms_and_normalize_wo3(project):
    for phase in project.phases():
        ptrs = phase.data["General"]["AtomPtrs"]
        uiso = ptrs[2] + 3
        for atom in phase.data["Atoms"]:
            atom[2] = ""
            if phase.data["General"]["Name"].startswith("WO3_"):
                atom[uiso] = 0.01


def delete_phase(project, name):
    del project.data["Phases"][name]
    for item in project.names:
        if item and item[0] == "Phases" and name in item:
            item.remove(name)
    for hist in project.histograms():
        hist.data.get("Reflection Lists", {}).pop(name, None)
    restraints = project.data.get("Restraints", {})
    restraints.pop(name, None)
    project.index_ids()
    project.update_ids()


def move_phase_to_index(project, name, index):
    """Reorder phase storage so existing phase-number controls stay aligned."""
    names = [p.name for p in project.phases()]
    names.remove(name)
    names.insert(index, name)
    phase_store = project.data["Phases"]
    rebuilt = {"data": phase_store.get("data")}
    for phase_name in names:
        rebuilt[phase_name] = phase_store[phase_name]
    project.data["Phases"] = rebuilt
    for item in project.names:
        if item and item[0] == "Phases":
            item[:] = ["Phases"] + names
            break
    project.index_ids()
    project.update_ids()


def configure_wo3(project, phase, hist, old_hap, cid):
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [float(old_hap["Scale"][0]), True]
    phase.set_HAP_refinements({"Scale": True}, [hist])
    phase.set_refinements({"Cell": True})

    # Monoclinic [011] maps to triclinic [110] for these equivalent cells.
    axis = [0, 1, 1] if cid == "2311041" else [1, 1, 0]
    hap["Size"][0] = "uniaxial"
    hap["Size"][1][:3] = [float(old_hap["Size"][1][0]),
                            float(old_hap["Size"][1][1]), 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][3] = axis
    phase.set_HAP_refinements({
        "Size": {"type": "uniaxial", "direction": axis, "refine": True,
                 "LGmix": {"value": 1.0, "refine": False}}
    }, [hist])

    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:3] = [float(old_hap["Mustrain"][1][0]), 1000.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    phase.set_HAP_refinements({
        "Mustrain": {"type": "isotropic", "refine": True,
                     "LGmix": {"value": 1.0, "refine": False}}
    }, [hist])

    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = float(old_hap["Pref.Ori."][1])
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = axis
    phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])

    set_limit(project, f"{phase.id}:{hist.id}:Scale", 0.0, 1.0e6)
    set_limit(project, f"{phase.id}:{hist.id}:Size;i", 0.01, 20.0)
    set_limit(project, f"{phase.id}:{hist.id}:Size;a", 0.01, 20.0)
    set_limit(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 20000.0)
    set_limit(project, f"{phase.id}:{hist.id}:MD", 0.2, 5.0)


def summarize(project, cid, history):
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"]["Rvals"]
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(mass_scale)
        phases.append({"name": phase.name, "cell": phase.get_cell(),
                       "scale": plain(hap["Scale"]), "size": plain(hap["Size"]),
                       "strain": plain(hap["Mustrain"]),
                       "texture": plain(hap["Pref.Ori."])})
    total = sum(masses)
    for phase, mass in zip(phases, masses):
        phase["fraction"] = mass / total
    return {
        "cid": cid,
        "rwp": rvals["Rwp"],
        "gof": rvals["GOF"],
        "chisq": rvals["chisq"],
        "nobs": rvals["Nobs"],
        "nvars": rvals["Nvars"],
        "bic": rvals["chisq"] + rvals["Nvars"] * math.log(rvals["Nobs"]),
        "max_shift": rvals["Max shft/sig"],
        "frozen": project.get_Frozen(),
        "history": history,
        "phases": phases,
    }


def run(source: Path, cid: str, output: Path):
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    old = project.phase(1)
    old_name = old.name
    old_hap = copy.deepcopy(old.data["Histograms"][hist.name])

    phase = project.add_phase(str(cif(cid)), phasename=f"candidate_WO3_{cid}",
                              histograms=[hist], fmthint="CIF")
    new_name = phase.name
    delete_phase(project, old_name)
    move_phase_to_index(project, new_name, 1)
    phase = project.phase(new_name)
    configure_wo3(project, phase, hist, old_hap, cid)
    freeze_atoms_and_normalize_wo3(project)

    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    history = []
    prior = None
    for iteration in range(5):
        project.refine()
        rvals = project.data["Covariance"]["data"]["Rvals"]
        history.append({"iteration": iteration + 1, "rwp": rvals["Rwp"],
                        "max_shift": rvals["Max shft/sig"],
                        "converged": rvals["converged"]})
        if (prior is not None and abs(prior - rvals["Rwp"]) < 1e-6
                and abs(rvals["Max shft/sig"]) < 0.5):
            break
        prior = rvals["Rwp"]
    project.save(str(output))
    print("SWAP", json.dumps(summarize(project, cid, history), allow_nan=True))


if __name__ == "__main__":
    if len(sys.argv) != 4:
        raise SystemExit("usage: wo3_source_swap.py SOURCE.gpx COD_ID OUTPUT.gpx")
    G2.SetPrintLevel("warn")
    run(Path(sys.argv[1]).resolve(), sys.argv[2], Path(sys.argv[3]).resolve())
