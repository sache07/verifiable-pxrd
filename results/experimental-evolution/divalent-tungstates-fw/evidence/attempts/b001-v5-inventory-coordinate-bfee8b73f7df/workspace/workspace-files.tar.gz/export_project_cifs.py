"""Export every phase in a GSAS-II project as a quick-mode CIF."""
import re
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2

project_path = Path(sys.argv[1]).resolve()
output_dir = Path(sys.argv[2]).resolve()
output_dir.mkdir(parents=True, exist_ok=True)
project = G2.G2Project(gpxfile=str(project_path))
for index, phase in enumerate(project.phases()):
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", phase.name).strip("_")
    output = output_dir / f"{index}_{safe}.cif"
    phase.export_CIF(str(output))
    print(output)
