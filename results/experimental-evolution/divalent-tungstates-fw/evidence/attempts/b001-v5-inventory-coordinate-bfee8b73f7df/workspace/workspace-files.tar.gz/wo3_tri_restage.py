"""Restage the credible triclinic WO3 source from low flexibility.

This is used after a simultaneous full-profile start collapsed its broadening
terms.  Phase-specific terms are enabled cumulatively only after scale/cell
have equilibrated.
"""
from __future__ import annotations

import copy
import json
import math
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from wo3_source_swap import (cif, delete_phase, freeze_atoms_and_normalize_wo3,
                             move_phase_to_index, plain, set_limit)


def refine_stage(project, label, repeats=3):
    out = []
    prior = None
    project.set_Frozen()
    for iteration in range(repeats):
        project.refine()
        r = project.data["Covariance"]["data"]["Rvals"]
        out.append({"stage": label, "iteration": iteration + 1,
                    "rwp": r["Rwp"], "max_shift": r["Max shft/sig"],
                    "converged": r["converged"]})
        if prior is not None and abs(prior - r["Rwp"]) < 1e-6 and abs(r["Max shft/sig"]) < 0.5:
            break
        prior = r["Rwp"]
    return out


def report(project, history):
    hist = project.histogram(0)
    r = project.data["Covariance"]["data"]["Rvals"]
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(phase.data["General"]["Mass"] * hap["Scale"][0])
        phases.append({"name": phase.name, "cell": phase.get_cell(),
                       "size": plain(hap["Size"]), "strain": plain(hap["Mustrain"]),
                       "texture": plain(hap["Pref.Ori."])})
    total = sum(masses)
    for item, mass in zip(phases, masses):
        item["fraction"] = mass / total
    return {"rwp": r["Rwp"], "gof": r["GOF"], "chisq": r["chisq"],
            "nobs": r["Nobs"], "nvars": r["Nvars"],
            "bic": r["chisq"] + r["Nvars"] * math.log(r["Nobs"]),
            "max_shift": r["Max shft/sig"], "frozen": project.get_Frozen(),
            "history": history, "phases": phases}


def run(source, output):
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    old = project.phase(1)
    old_name = old.name
    old_hap = copy.deepcopy(old.data["Histograms"][hist.name])

    phase = project.add_phase(str(cif("2106293")), phasename="candidate_WO3_2106293",
                              histograms=[hist], fmthint="CIF")
    new_name = phase.name
    delete_phase(project, old_name)
    move_phase_to_index(project, new_name, 1)
    phase = project.phase(new_name)
    freeze_atoms_and_normalize_wo3(project)
    hap = phase.data["Histograms"][hist.name]

    hap["Scale"] = [float(old_hap["Scale"][0]), True]
    phase.set_HAP_refinements({"Scale": True}, [hist])
    phase.set_refinements({"Cell": True})

    # Start with physically plausible but fixed isotropic broadening.
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:3] = [0.09, 1.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:3] = [4000.0, 1000.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.36
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [1, 1, 0]

    project.set_Controls("cycles", 18)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    history = refine_stage(project, "scale_cell", 3)

    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True,
                 "LGmix": {"value": 1.0, "refine": False}}
    }, [hist])
    set_limit(project, f"{phase.id}:{hist.id}:Size;i", 0.01, 20.0)
    history += refine_stage(project, "plus_isotropic_size", 3)

    phase.set_HAP_refinements({
        "Mustrain": {"type": "isotropic", "refine": True,
                     "LGmix": {"value": 1.0, "refine": False}}
    }, [hist])
    set_limit(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 20000.0)
    history += refine_stage(project, "plus_isotropic_strain", 3)

    phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])
    set_limit(project, f"{phase.id}:{hist.id}:MD", 0.2, 5.0)
    history += refine_stage(project, "plus_texture_110", 3)

    project.save(str(output))
    print("RESTAGE", json.dumps(report(project, history), allow_nan=True))


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: wo3_tri_restage.py SOURCE.gpx OUTPUT.gpx")
    G2.SetPrintLevel("warn")
    run(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
