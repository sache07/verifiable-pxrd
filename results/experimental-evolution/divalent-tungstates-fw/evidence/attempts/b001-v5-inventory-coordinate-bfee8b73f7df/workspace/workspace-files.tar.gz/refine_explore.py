"""Exploratory, public-evidence Rietveld refinement for the Ca-W-O scan."""
from __future__ import annotations

from pathlib import Path
import json
import math
import shutil
import sys

import numpy as np
from scipy.ndimage import percentile_filter, gaussian_filter1d
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
SOURCE_CIF = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/resources/"
    "b001-c05/cif/7/21/92/7219229.cif"
)


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return plain(value.tolist())
    if isinstance(value, np.generic):
        return value.item()
    return value


def prepare_inputs():
    data = np.loadtxt(PATTERN, delimiter=",", skiprows=1)
    x, y = data.T
    np.savetxt(
        ROOT / "pattern.xye",
        np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))),
        fmt="%.8f %.8f %.8f",
    )
    (ROOT / "instrument.instprm").write_text(
        "#GSAS-II instrument parameter file for Cu Kalpha laboratory reflection geometry\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:5.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return x, y


def starting_background(x, y, order=10):
    # A low local percentile gives a peak-resistant starting baseline. This is
    # only an initial value; all coefficients are then fitted by GSAS-II.
    envelope = percentile_filter(y, size=401, percentile=15, mode="nearest")
    envelope = gaussian_filter1d(envelope, 120)
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(t, envelope, order - 1).tolist()


def build(path: Path, order=10):
    x, y = prepare_inputs()
    gpx = G2.G2Project(newgpx=str(path))
    phase = gpx.add_phase(
        str(SOURCE_CIF), phasename="CaWO4_scheelite", fmthint="CIF"
    )
    hist = gpx.add_powder_histogram(
        str(ROOT / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
        phases=[phase],
        fmthint="xye",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    coeffs = starting_background(x, y, order)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": order,
                "coeffs": coeffs,
                "refine": False,
            }
        }
    )
    phase.data["Histograms"][hist.name]["Scale"] = [1.0, False]
    gpx.set_Controls("cycles", 12)
    gpx.save()
    return gpx


def summary(gpx, tag):
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    hap = phase.data["Histograms"][hist.name]
    cov = gpx.data.get("Covariance", {}).get("data", {})
    out = {
        "tag": tag,
        "wR_percent": hist.get_wR(),
        "residuals": plain(hist.residuals),
        "cell": plain(phase.get_cell()),
        "background": plain(hist.data["Background"][0]),
        "instrument": {k: plain(inst[k]) for k in inst},
        "sample": {
            k: plain(sample[k])
            for k in ("Scale", "Gonio. radius", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
            if k in sample
        },
        "hap": {
            k: plain(hap[k])
            for k in ("Scale", "Size", "Mustrain", "Pref.Ori.", "Extinction", "HStrain")
        },
        "atoms": plain(phase.data["Atoms"]),
        "varyList": [str(v) for v in cov.get("varyList", [])],
        "Rvals": plain(cov.get("Rvals", {})),
    }
    print("SUMMARY", json.dumps(out, allow_nan=True))
    return out


def refine(gpx, tag):
    print(f"\n===== {tag} =====")
    try:
        gpx.refine()
    except Exception as exc:
        print("REFINE_ERROR", type(exc).__name__, str(exc))
        raise
    gpx.save()
    return summary(gpx, tag)


def run_sequence(outpath: Path):
    G2.SetPrintLevel("warn")
    gpx = build(outpath)
    hist, phase = gpx.histogram(0), gpx.phase(0)
    summary(gpx, "built")

    # Establish scale against a robust fixed background.
    phase.set_HAP_refinements({"Scale": True}, [hist])
    refine(gpx, "scale")

    # Refit the empirical background and scale together.
    hist.set_refinements({"Background": True})
    refine(gpx, "background_scale")

    # Lattice and a constant angular zero correction align the line family.
    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(gpx, "cell_zero")

    # Common Caglioti/Lorentzian widths and axial divergence.
    hist.set_refinements(
        {"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]}
    )
    refine(gpx, "instrument_profile")

    # Add physically interpretable sample broadening after the common profile.
    phase.set_HAP_refinements(
        {
            "Size": {
                "type": "isotropic",
                "value": 1.0,
                "refine": True,
                "LGmix": {"value": 1.0, "refine": False},
            },
            "Mustrain": {
                "type": "isotropic",
                "refine": True,
                "LGmix": {"value": 1.0, "refine": False},
            },
        },
        [hist],
    )
    refine(gpx, "iso_size_strain")
    shutil.copy2(gpx.filename, ROOT / "explore_base.gpx")
    return gpx


if __name__ == "__main__":
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "explore.gpx"
    run_sequence(target.resolve())
