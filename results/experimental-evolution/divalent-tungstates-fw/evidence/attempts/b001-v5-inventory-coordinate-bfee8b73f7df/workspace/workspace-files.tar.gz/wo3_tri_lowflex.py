"""Independent low-flexibility nuisance restart for triclinic WO3."""
from __future__ import annotations

import copy
import json
import math
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from wo3_source_swap import (cif, delete_phase, freeze_atoms_and_normalize_wo3,
                             move_phase_to_index, plain, set_limit)


def stage(project, name, repeats=3):
    rows = []
    project.set_Frozen()
    previous = None
    for iteration in range(repeats):
        project.refine()
        r = project.data["Covariance"]["data"]["Rvals"]
        rows.append({"stage": name, "iteration": iteration + 1,
                     "rwp": r["Rwp"], "max_shift": r["Max shft/sig"],
                     "converged": r["converged"], "lamMax": r.get("lamMax")})
        if (previous is not None and r["converged"]
                and abs(previous - r["Rwp"]) < 1e-6
                and abs(r["Max shft/sig"]) < 0.5):
            break
        previous = r["Rwp"]
    return rows


def set_size(project, phase, hist, mode, values, direction, refine):
    phase.clear_HAP_refinements({"Size": True}, [hist])
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = mode
    hap["Size"][1][:3] = list(values) + [1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][3] = list(direction)
    if refine:
        phase.set_HAP_refinements({
            "Size": {"type": mode, "direction": list(direction), "refine": True,
                     "LGmix": {"value": 1.0, "refine": False}}
        }, [hist])
        set_limit(project, f"{phase.id}:{hist.id}:Size;i", 0.01, 20.0)
        if mode == "uniaxial":
            set_limit(project, f"{phase.id}:{hist.id}:Size;a", 0.01, 20.0)


def set_strain(project, phase, hist, value, refine):
    phase.clear_HAP_refinements({"Mustrain": True}, [hist])
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:3] = [float(value), 1000.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    if refine:
        phase.set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "refine": True,
                         "LGmix": {"value": 1.0, "refine": False}}
        }, [hist])
        set_limit(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 20000.0)


def summarize(project, history):
    hist = project.histogram(0)
    r = project.data["Covariance"]["data"]["Rvals"]
    masses, phases = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(phase.data["General"]["Mass"] * hap["Scale"][0])
        phases.append({"name": phase.name, "cell": phase.get_cell(),
                       "size": plain(hap["Size"]), "strain": plain(hap["Mustrain"]),
                       "texture": plain(hap["Pref.Ori."])})
    total = sum(masses)
    for item, mass in zip(phases, masses):
        item["fraction"] = mass / total
    return {"rwp": r["Rwp"], "gof": r["GOF"], "chisq": r["chisq"],
            "nobs": r["Nobs"], "nvars": r["Nvars"],
            "bic": r["chisq"] + r["Nvars"] * math.log(r["Nobs"]),
            "max_shift": r["Max shft/sig"], "converged": r["converged"],
            "frozen": project.get_Frozen(), "history": history, "phases": phases}


def run(source, output):
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    old = project.phase(1)
    old_name = old.name
    old_hap = copy.deepcopy(old.data["Histograms"][hist.name])

    new = project.add_phase(str(cif("2106293")), phasename="candidate_WO3_2106293",
                            histograms=[hist], fmthint="CIF")
    new_name = new.name
    delete_phase(project, old_name)
    move_phase_to_index(project, new_name, 1)
    tri = project.phase(1)
    freeze_atoms_and_normalize_wo3(project)

    # Freeze the complete inherited nuisance subspace for a clean structural start.
    hist.clear_refinements({"Background": True,
                            "Instrument Parameters": ["Zero", "U", "V", "W"],
                            "Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Scale": True, "Size": True,
                                     "Mustrain": True, "Pref.Ori.": True}, [hist])

    hap = tri.data["Histograms"][hist.name]
    hap["Scale"] = [float(old_hap["Scale"][0]), True]
    tri.set_HAP_refinements({"Scale": True}, [hist])
    tri.set_refinements({"Cell": True})
    set_size(project, tri, hist, "isotropic", [0.09, 1.0], [0, 0, 1], False)
    set_strain(project, tri, hist, 4000.0, False)
    hap["Pref.Ori."][0:4] = ["MD", 1.36, False, [1, 1, 0]]

    project.set_Controls("cycles", 14)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    history = stage(project, "tri_scale_cell", 3)

    set_size(project, tri, hist, "isotropic", [0.09, 1.0], [0, 0, 1], True)
    history += stage(project, "tri_plus_size", 3)
    set_strain(project, tri, hist, 4000.0, True)
    history += stage(project, "tri_plus_strain", 3)
    tri.set_HAP_refinements({"Pref.Ori.": True}, [hist])
    set_limit(project, f"{tri.id}:{hist.id}:MD", 0.2, 5.0)
    history += stage(project, "tri_plus_texture", 3)

    # Release retained-phase scales/cells first.
    for idx in (0, 2):
        phase = project.phase(idx)
        phase.set_HAP_refinements({"Scale": True}, [hist])
        phase.set_refinements({"Cell": True})
    history += stage(project, "release_scales_cells", 3)

    # Restore the supported retained-phase broadening mechanisms from source.
    for idx in (0, 2):
        phase = project.phase(idx)
        source_hap = phase.data["Histograms"][hist.name]
        values = source_hap["Size"][1][:2]
        direction = source_hap["Size"][3]
        set_size(project, phase, hist, source_hap["Size"][0], values, direction, True)
    set_strain(project, project.phase(2), hist,
               project.phase(2).data["Histograms"][hist.name]["Mustrain"][1][0], True)
    history += stage(project, "release_retained_broadening", 3)

    # Finally release the independently initialized common nuisance subspace.
    hist.set_refinements({"Background": {"type": hist.data["Background"][0][0],
                                          "no. coeffs": len(hist.data["Background"][0][3:]),
                                          "refine": True},
                          "Instrument Parameters": ["Zero", "U", "V", "W"],
                          "Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    history += stage(project, "release_common_profile", 4)

    project.save(str(output))
    print("LOWFLEX", json.dumps(summarize(project, history), allow_nan=True))


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: wo3_tri_lowflex.py SOURCE.gpx OUTPUT.gpx")
    G2.SetPrintLevel("warn")
    run(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
