"""Final phase-deletion and trace-CaO inventory checks."""
from __future__ import annotations

import json
import math
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2

CAO = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/resources/b001-c05/cif/1/56/31/1563196.cif")


def settle(project, repeats=4):
    rows, previous = [], None
    project.set_Frozen()
    for iteration in range(repeats):
        project.refine()
        r = project.data["Covariance"]["data"]["Rvals"]
        rows.append({"iteration": iteration + 1, "rwp": r["Rwp"],
                     "max_shift": r["Max shft/sig"], "converged": r["converged"]})
        if (previous is not None and r["converged"]
                and abs(previous-r["Rwp"]) < 1e-6 and abs(r["Max shft/sig"]) < 0.5):
            break
        previous = r["Rwp"]
    return rows


def report(project, mode, history):
    hist = project.histogram(0)
    r = project.data["Covariance"]["data"]["Rvals"]
    masses, phases = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = phase.data["General"]["Mass"] * hap["Scale"][0] if hap["Use"] else 0.0
        masses.append(mass)
        phases.append({"name": phase.name, "use": hap["Use"], "scale": hap["Scale"],
                       "cell": phase.get_cell(), "size": hap["Size"],
                       "strain": hap["Mustrain"]})
    total = sum(masses)
    for item, mass in zip(phases, masses):
        item["fraction"] = mass / total if total else 0.0
    return {"mode": mode, "rwp": r["Rwp"], "gof": r["GOF"],
            "chisq": r["chisq"], "nvars": r["Nvars"],
            "bic": r["chisq"] + r["Nvars"] * math.log(r["Nobs"]),
            "max_shift": r["Max shft/sig"], "converged": r["converged"],
            "frozen": project.get_Frozen(), "history": history, "phases": phases}


def deletion(source, index, output):
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histogram(0)
    phase = project.phase(index)
    hap = phase.data["Histograms"][hist.name]
    hap["Use"] = False
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Scale": True, "Size": True,
                                 "Mustrain": True, "Pref.Ori.": True}, [hist])
    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    history = settle(project)
    project.save(str(output))
    print("INVCHECK", json.dumps(report(project, f"delete_{index}", history), allow_nan=True))


def add_cao(source, output):
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    phase = project.add_phase(str(CAO), phasename="CaO_1563196",
                              histograms=[hist], fmthint="CIF")
    ptrs = phase.data["General"]["AtomPtrs"]
    for atom in phase.data["Atoms"]:
        atom[2] = ""
        atom[ptrs[2] + 3] = 0.01
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [2.0, True]
    phase.set_HAP_refinements({"Scale": True}, [hist])
    phase.set_refinements({"Cell": True})
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:3] = [0.10, 1.0, 1.0]
    hap["Size"][2] = [False, False, False]
    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    history = settle(project, 3)

    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True,
                 "LGmix": {"value": 1.0, "refine": False}}
    }, [hist])
    project.set_Controls("parmMin", 0.01, f"{phase.id}:{hist.id}:Size;i")
    project.set_Controls("parmMax", 20.0, f"{phase.id}:{hist.id}:Size;i")
    history += settle(project, 4)
    project.save(str(output))
    print("INVCHECK", json.dumps(report(project, "add_CaO", history), allow_nan=True))


if __name__ == "__main__":
    if len(sys.argv) != 4:
        raise SystemExit("usage: inventory_validation.py SOURCE.gpx delete0|delete1|delete2|cao OUTPUT.gpx")
    G2.SetPrintLevel("warn")
    source, mode, output = Path(sys.argv[1]).resolve(), sys.argv[2], Path(sys.argv[3]).resolve()
    if mode.startswith("delete"):
        deletion(source, int(mode[-1]), output)
    elif mode == "cao":
        add_cao(source, output)
    else:
        raise SystemExit(f"unknown mode {mode}")
