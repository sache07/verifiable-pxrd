"""Compact atom/refinement summary for one or more GSAS-II projects."""
import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel("warn")
for raw in sys.argv[1:]:
    project = G2.G2Project(gpxfile=str(Path(raw).resolve()))
    hist = project.histogram(0)
    covariance = project.data.get("Covariance", {}).get("data", {})
    masses = [phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
              for phase in project.phases()]
    print("ATOMS", json.dumps({
        "file": Path(raw).name,
        "rwp": hist.get_wR(),
        "max_shift": covariance.get("Rvals", {}).get("Max shft/sig"),
        "converged": covariance.get("Rvals", {}).get("converged"),
        "frozen": project.get_Frozen(),
        "fractions": [float(value / sum(masses)) for value in masses],
        "phases": [{
            "name": phase.name,
            "atoms": [{"label": atom.label, "element": atom.element,
                       "xyz": list(map(float, atom.coordinates)),
                       "adp_flag": atom.adp_flag,
                       "adp": atom.ADP if isinstance(atom.ADP, list) else float(atom.ADP),
                       "flags": atom.refinement_flags}
                      for atom in phase.atoms()],
        } for phase in project.phases()],
    }, allow_nan=True))
