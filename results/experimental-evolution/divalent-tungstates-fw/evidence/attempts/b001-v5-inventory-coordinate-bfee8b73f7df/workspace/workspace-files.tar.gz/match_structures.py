"""Pairwise pymatgen StructureMatcher comparison for CIFs."""
import json
import sys
from pathlib import Path

from pymatgen.analysis.structure_matcher import StructureMatcher
from pymatgen.core import Structure

structures = [(Path(path).name, Structure.from_file(path)) for path in sys.argv[1:]]
matcher = StructureMatcher(ltol=0.2, stol=0.3, angle_tol=5,
                           primitive_cell=False, scale=True,
                           attempt_supercell=False)
for index, (name_a, structure_a) in enumerate(structures):
    for name_b, structure_b in structures[index + 1:]:
        rms = matcher.get_rms_dist(structure_a, structure_b)
        print(json.dumps({"a": name_a, "b": name_b,
                          "match": bool(matcher.fit(structure_a, structure_b)),
                          "rms": None if rms is None else [float(value) for value in rms]}))
