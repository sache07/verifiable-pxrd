"""Prepare and screen Ca3WO6 models from published ordered-perovskite parents."""
from __future__ import annotations

from pathlib import Path
import json

import numpy as np
from scipy.ndimage import gaussian_filter1d
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter

ROOT=Path(__file__).resolve().parent
DB=Path('<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/resources/b001-c05/cif')
OUT=ROOT/'analogues';OUT.mkdir(exist_ok=True)
PARENTS={
    'ca2mg_2013468':('2013468',{'Mg':'Ca'}),
    'sr2ca_2104688':('2104688',{'Sr':'Ca'}),
    'ba2ca_1529016':('1529016',{'Ba':'Ca'}),
    'ca2co_7222332':('7222332',{'Co':'Ca'}),
    'ca2ni_7222333':('7222333',{'Ni':'Ca'}),
    'ba2fe_1531103':('1531103',{'Ba':'Ca','Fe':'Ca'}),
    'ba3_1534803':('1534803',{'Ba':'Ca'}),
    'sr2ni_tet_1526460':('1526460',{'Sr':'Ca','Ni':'Ca'}),
    'sr2ni_cub_1541621':('1541621',{'Sr':'Ca','Ni':'Ca'}),
}

def cif(cid):return DB/cid[0]/cid[1:3]/cid[3:5]/f'{cid}.cif'

q=np.load(ROOT/'inventory_wo3_2311041.npz');x=q['x'];target=np.maximum(q['y']-q['yc'],0)
# Compare broad coherent families rather than fitting counting noise.
target=gaussian_filter1d(target,8)
step=float(np.median(np.diff(x)))
calc=XRDCalculator(wavelength=1.540598)

def scaled(s,fac):
    t=s.copy();t.scale_lattice(s.volume*fac**3);return t

def scale_search(s):
    # Uniform cell scaling moves d spacings linearly, so generate structure
    # factors once and scan scale globally. This avoids local-correlation traps.
    pat=calc.get_pattern(s,two_theta_range=(7.,130.),scaled=False)
    d=np.asarray(pat.d_hkls,float);inten=np.asarray(pat.y,float)
    def score(fac):
        arg=1.540598/(2*d*fac);ok=(arg>0)&(arg<1)
        pos=np.degrees(2*np.arcsin(arg[ok]))-0.13;ii=inten[ok]
        bins=np.rint((pos-x[0])/step).astype(int);use=(bins>=0)&(bins<len(x))
        y=np.zeros_like(x);np.add.at(y,bins[use],ii[use]);y=gaussian_filter1d(y,0.13/step)
        den=np.sqrt(np.dot(target,target)*np.dot(y,y))
        return float(np.dot(target,y)/den) if den else 0.
    coarse=np.linspace(.75,1.18,431);scores=np.array([score(f) for f in coarse]);i=int(np.argmax(scores))
    fine=np.linspace(max(.75,coarse[i]-.002),min(1.18,coarse[i]+.002),81)
    fs=np.array([score(f) for f in fine]);j=int(np.argmax(fs))
    return float(fine[j]),float(fs[j])

def distances(s):
    vals={}
    for a,b in [('W','O'),('Ca','O'),('O','O'),('Ca','W'),('Ca','Ca')]:
        ds=[]
        for i,site in enumerate(s):
            if site.species_string!=a:continue
            for nn in s.get_neighbors(site,4.0):
                if nn.species_string==b and nn.nn_distance>1e-5:ds.append(float(nn.nn_distance))
        vals[a+'-'+b]=min(ds) if ds else None
    return vals

records=[]
for name,(cid,mapping) in PARENTS.items():
    try:parent=Structure.from_file(cif(cid))
    except Exception as exc:
        records.append(dict(name=name,parent_id=cid,status='parse_failed',error=str(exc)));continue
    mapped=parent.copy();mapped.replace_species(mapping)
    if mapped.composition.reduced_formula!='Ca3WO6':
        records.append(dict(name=name,parent_id=cid,status='wrong_composition',formula=mapped.composition.reduced_formula));continue
    fac,corr=scale_search(mapped);model=scaled(mapped,fac)
    # Substitution can duplicate parent site labels (for example Ca1 and Mg1
    # both becoming Ca1). Give every expanded site a unique label before CIF
    # symmetrization so downstream refinement can address each orbit cleanly.
    counts={};labels=[]
    for site in model:
        el=site.species_string;counts[el]=counts.get(el,0)+1;labels.append(f'{el}{counts[el]}')
    model=Structure(model.lattice,[site.species for site in model],model.frac_coords,
                    site_properties=model.site_properties,labels=labels)
    path=OUT/f'{name}_Ca3WO6.cif'
    CifWriter(model,symprec=1e-4,refine_struct=False).write_file(path)
    reread=Structure.from_file(path)
    rec=dict(name=name,parent_id=cid,parent_cif=str(cif(cid)),model_cif=str(path),status='prepared',
             parent_formula=parent.composition.reduced_formula,parent_sg=parent.get_space_group_info(),
             substitutions=mapping,isotropic_cell_factor=fac,correlation=corr,
             model_formula=reread.composition.reduced_formula,model_sg=reread.get_space_group_info(),
             cell=[reread.lattice.a,reread.lattice.b,reread.lattice.c,reread.lattice.alpha,reread.lattice.beta,reread.lattice.gamma],
             density=float(reread.density),distances_A=distances(reread))
    records.append(rec)
    print(json.dumps(rec))
(OUT/'provenance.json').write_text(json.dumps({'schema_version':1,'records':records},indent=2)+'\n')
