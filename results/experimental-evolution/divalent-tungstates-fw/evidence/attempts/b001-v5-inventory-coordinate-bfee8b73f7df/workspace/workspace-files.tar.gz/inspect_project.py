"""Print compact diagnostics from a GSAS-II project without changing it."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def main(path: str) -> None:
    project = G2.G2Project(gpxfile=str(Path(path).resolve()))
    hist = project.histogram(0)
    covariance = project.data.get("Covariance", {}).get("data", {})
    variables = [str(v) for v in covariance.get("varyList", [])]
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    sigmas = np.sqrt(np.maximum(np.diag(matrix), 0.0)) if matrix.ndim == 2 else np.array([])
    shifts = covariance.get("Rvals", {}).get("lastShifts", {})
    shift_ratios = []
    for index, variable in enumerate(variables):
        sigma = float(sigmas[index]) if index < len(sigmas) else float("nan")
        shift = float(shifts.get(variable, float("nan")))
        ratio = shift / sigma if np.isfinite(sigma) and sigma > 0 else float("nan")
        shift_ratios.append((abs(ratio) if np.isfinite(ratio) else -1.0, variable, shift, sigma, ratio))
    phases = []
    phase_weights = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        contribution = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        phase_weights.append(contribution)
        atoms = []
        for atom in phase.atoms():
            atoms.append({
                "label": atom.label,
                "type": atom.element,
                "xyz": list(map(float, atom.coordinates)),
                "occ": float(atom.occupancy),
                "uiso": float(atom.uiso),
                "flags": atom.refinement_flags,
            })
        phases.append({
            "name": phase.name,
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "cell": phase.get_cell(),
            "mass": float(phase.data["General"]["Mass"]),
            "scale": plain(hap["Scale"]),
            "size": plain(hap["Size"]),
            "mustrain": plain(hap["Mustrain"]),
            "texture": plain(hap["Pref.Ori."]),
            "atoms": atoms,
        })
    total = sum(phase_weights)
    for phase, weight in zip(phases, phase_weights):
        phase["weight_fraction"] = weight / total if total else float("nan")
    output = {
        "path": str(Path(path).resolve()),
        "rwp": hist.get_wR(),
        "residuals": plain(hist.residuals),
        "background": plain(hist.data["Background"]),
        "instrument": {key: plain(value) for key, value in hist.InstrumentParameters.items()},
        "sample": plain(hist.SampleParameters),
        "controls": plain(project.data["Controls"]["data"]),
        "rvals": plain(covariance.get("Rvals", {})),
        "largest_shift_over_sigma": [
            {"variable": v, "shift": s, "sigma": e, "ratio": r}
            for _, v, s, e, r in sorted(shift_ratios, reverse=True)[:12]
        ],
        "phases": phases,
    }
    print(json.dumps(output, indent=2, allow_nan=True))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main(sys.argv[1])
