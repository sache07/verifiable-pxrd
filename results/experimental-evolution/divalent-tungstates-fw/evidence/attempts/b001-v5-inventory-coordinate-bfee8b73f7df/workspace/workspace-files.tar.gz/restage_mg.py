"""Lower-flexibility restart for the initially failed Ca2MgWO6-mapped finalist."""
from pathlib import Path
import json
import shutil
import sys

from GSASII import GSASIIscriptable as G2


def settle(project, label, rounds=3):
    project.set_Frozen()
    project.set_Controls("cycles", 18)
    history = []
    for iteration in range(rounds):
        project.refine()
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        history.append([project.histogram(0).get_wR(), rvals.get("Max shft/sig"), rvals.get("converged")])
    print("MG_STAGE", label, json.dumps(history))


source, output = map(Path, sys.argv[1:3])
shutil.copy2(source, output)
project = G2.G2Project(gpxfile=str(output.resolve()))
hist = project.histogram(0)
phase = project.phase(2)
hap = phase.data["Histograms"][hist.name]
project.set_Frozen()
phase.set_refinements({"Atoms": {"all": ""}, "Cell": False})
phase.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])
hap["Size"][0] = "isotropic"
hap["Size"][1][:3] = [0.15, 1.0, 1.0]
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][:3] = [4200.0, 1000.0, 1.0]
hap["Mustrain"][2] = [False, False, False]
settle(project, "fixed_cell_width")

phase.set_refinements({"Cell": True})
settle(project, "cell")
phase.set_HAP_refinements({
    "Size": {"type": "isotropic", "value": 0.15, "refine": True,
             "LGmix": {"value": 1.0, "refine": False}},
}, [hist])
project.set_Controls("parmMin", 0.01, f"{phase.id}:{hist.id}:Size;i")
project.set_Controls("parmMax", 20.0, f"{phase.id}:{hist.id}:Size;i")
settle(project, "size")
phase.set_HAP_refinements({
    "Mustrain": {"type": "isotropic", "refine": True,
                 "LGmix": {"value": 1.0, "refine": False}},
}, [hist])
project.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Mustrain;i")
project.set_Controls("parmMax", 20000.0, f"{phase.id}:{hist.id}:Mustrain;i")
settle(project, "strain")

general_ca = [atom.label for atom in phase.atoms() if atom.element == "Ca" and atom.mult == 4]
oxygens = [atom.label for atom in phase.atoms() if atom.element == "O"]
phase.set_refinements({"Atoms": {general_ca[0]: "X"}})
settle(project, "general_ca")
for label in oxygens:
    phase.set_refinements({"Atoms": {label: "X"}})
    settle(project, "oxygen_" + label)
settle(project, "final", 4)
project.save(str(output.resolve()))
print("MG_DONE", project.histogram(0).get_wR(), project.get_Frozen())
