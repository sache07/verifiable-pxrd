from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
src = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
x, y = src.T
np.savetxt(ROOT / "pattern.xye", np.column_stack([x, y, np.sqrt(np.maximum(y, 1.0))]), fmt="%.8f %.8f %.8f")
(ROOT / "instrument.instprm").write_text(
    "#GSAS-II instrument parameter file for Cu Kalpha laboratory reflection geometry\n"
    "Type:PXC;Bank:1\n"
    "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
    "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
    "U:5.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
)
gpx = G2.G2Project(newgpx=str(ROOT / "probe.gpx"))
phase = gpx.add_phase(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/resources/b001-c05/cif/7/21/92/7219229.cif",
    phasename="CaWO4_scheelite",
    fmthint="CIF",
)
hist = gpx.add_powder_histogram(
    str(ROOT / "pattern.xye"), str(ROOT / "instrument.instprm"), phases=[phase], fmthint="xye"
)
hist.SampleParameters["Type"] = "Bragg-Brentano"
gpx.save()

def plain(v):
    if isinstance(v, dict): return {str(k): plain(x) for k,x in v.items()}
    if isinstance(v, (list, tuple)): return [plain(x) for x in v]
    if isinstance(v, np.ndarray): return plain(v.tolist())
    if isinstance(v, np.generic): return v.item()
    return v

print("hist", hist.name)
print("data lengths", [len(a) if hasattr(a, "__len__") else None for a in hist.data["data"][1]])
print("residuals", hist.residuals)
print("instrument", json.dumps(plain(hist.InstrumentParameters), indent=2))
print("sample", json.dumps(plain(hist.SampleParameters), indent=2))
print("background", json.dumps(plain(hist.data["Background"]), indent=2))
print("phase general", json.dumps(plain({k:phase.data["General"][k] for k in ["Name","Type","Cell","Mass","AtomPtrs"]}), indent=2))
print("HAP", json.dumps(plain(phase.data["Histograms"][hist.name]), indent=2))
print("atoms", json.dumps(plain(phase.data["Atoms"]), indent=2))
