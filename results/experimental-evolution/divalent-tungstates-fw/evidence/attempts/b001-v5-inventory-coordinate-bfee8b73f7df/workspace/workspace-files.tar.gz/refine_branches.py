"""Mechanism branches from the initial CaWO4 inventory fit."""
from __future__ import annotations

from pathlib import Path
import json
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent


def plain(v):
    if isinstance(v, dict): return {str(k): plain(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)): return [plain(x) for x in v]
    if isinstance(v, np.ndarray): return plain(v.tolist())
    if isinstance(v, np.generic): return v.item()
    return v


def report(gpx, tag):
    h, p = gpx.histogram(0), gpx.phase(0)
    hap = p.data["Histograms"][h.name]
    cov = gpx.data.get("Covariance", {}).get("data", {})
    d = {
        "tag": tag,
        "wR": h.get_wR(),
        "cell": p.get_cell(),
        "inst": {k: plain(h.InstrumentParameters[k]) for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")},
        "sample": {k: plain(h.SampleParameters[k]) for k in ("Shift", "SurfRoughA", "SurfRoughB")},
        "scale": plain(hap["Scale"]),
        "size": plain(hap["Size"]),
        "mustrain": plain(hap["Mustrain"]),
        "texture": plain(hap["Pref.Ori."]),
        "background": plain(h.data["Background"][0]),
        "Rvals": plain(cov.get("Rvals", {})),
        "vary": [str(x) for x in cov.get("varyList", [])],
    }
    print("BRANCH", json.dumps(d, allow_nan=True))
    return d


def do(gpx, tag, out):
    print("\n=====", tag, "=====")
    gpx.set_Controls("cycles", 18)
    gpx.refine()
    gpx.save(str(out))
    report(gpx, tag)
    return gpx


def load_copy(source, output):
    shutil.copy2(source, output)
    return G2.G2Project(gpxfile=str(output))


def reset_physical(source, output):
    g = load_copy(source, output)
    h, p = g.histogram(0), g.phase(0)
    # Reject the negative/singular unrestricted profile branch.
    h.clear_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]})
    for key, val in {"U": 5.0, "V": 0.0, "W": 5.0, "X": 0.1, "Y": 0.0, "SH/L": 0.02}.items():
        h.InstrumentParameters[key][1] = val
    p.clear_HAP_refinements({"Size": True, "Mustrain": True}, [h])
    hap = p.data["Histograms"][h.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:3] = [0.30, 1.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:3] = [1000.0, 1000.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    # Refine specimen broadening; common X/Y stay fixed to avoid exact duplication.
    p.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": 0.30, "refine": True, "LGmix": {"value": 1.0, "refine": False}},
            "Mustrain": {"type": "isotropic", "refine": True, "LGmix": {"value": 1.0, "refine": False}},
        }, [h]
    )
    h.set_refinements({"Instrument Parameters": ["SH/L"]})
    g.set_Controls("parmMin", 0.003, "0:0:Size;i")
    g.set_Controls("parmMax", 20.0, "0:0:Size;i")
    g.set_Controls("parmMin", 0.0, "0:0:Mustrain;i")
    g.set_Controls("parmMax", 50000.0, "0:0:Mustrain;i")
    g.set_Controls("parmMin", 0.0001, ":0:SH/L")
    g.set_Controls("parmMax", 0.5, ":0:SH/L")
    return do(g, "physical_iso", output)


def branch_roughness(source, mode):
    output = ROOT / f"branch_{mode}.gpx"
    g = load_copy(source, output)
    h = g.histogram(0)
    h.SampleParameters["SurfRoughA"] = [0.20, False]
    h.SampleParameters["SurfRoughB"] = [0.10, False]
    params = []
    if mode in ("roughA", "roughAB", "roughABpol"): params.append("SurfRoughA")
    if mode in ("roughB", "roughAB", "roughABpol"): params.append("SurfRoughB")
    if params: h.set_refinements({"Sample Parameters": params})
    if mode in ("pol", "roughABpol"):
        h.set_refinements({"Instrument Parameters": ["Polariz."]})
    return do(g, mode, output)


def branch_texture(source, axis):
    name = "".join(str(abs(int(i))) for i in axis)
    output = ROOT / f"branch_tex{name}.gpx"
    g = load_copy(source, output)
    h, p = g.histogram(0), g.phase(0)
    hap = p.data["Histograms"][h.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][3] = list(axis)
    p.set_HAP_refinements({"Pref.Ori.": True}, [h])
    g.set_Controls("parmMin", 0.2, "0:0:MD")
    g.set_Controls("parmMax", 5.0, "0:0:MD")
    return do(g, "texture_" + name, output)


def branch_strain(source, kind, axis=(0, 0, 1)):
    name = kind + "_" + "".join(str(abs(int(i))) for i in axis)
    output = ROOT / f"branch_{name}.gpx"
    g = load_copy(source, output)
    h, p = g.histogram(0), g.phase(0)
    hap = p.data["Histograms"][h.name]
    p.clear_HAP_refinements({"Mustrain": True}, [h])
    if kind == "uniaxial":
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][:3] = [max(100.0, hap["Mustrain"][1][0]), max(100.0, hap["Mustrain"][1][0]), 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][3] = list(axis)
        p.set_HAP_refinements({"Mustrain": {"type": "uniaxial", "direction": list(axis), "refine": True, "LGmix": {"value": 1.0, "refine": False}}}, [h])
        for v in ("0:0:Mustrain;i", "0:0:Mustrain;a"):
            g.set_Controls("parmMin", 0.0, v); g.set_Controls("parmMax", 50000.0, v)
    elif kind == "generalized":
        hap["Mustrain"][0] = "generalized"
        # Seed all tetragonal Stephens coefficients at a small positive value.
        hap["Mustrain"][4] = [max(0.001, float(v)) for v in hap["Mustrain"][4]]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][4])
        p.set_HAP_refinements({"Mustrain": {"type": "generalized", "refine": True, "LGmix": {"value": 1.0, "refine": False}}}, [h])
        for i in range(len(hap["Mustrain"][4])):
            g.set_Controls("parmMin", 0.0, f"0:0:Mustrain;{i}")
            g.set_Controls("parmMax", 1000.0, f"0:0:Mustrain;{i}")
    return do(g, name, output)


def main():
    G2.SetPrintLevel("warn")
    source = ROOT / "explore.gpx"
    physical = ROOT / "branch_physical_iso.gpx"
    reset_physical(source, physical)
    for mode in ("roughA", "roughB", "roughAB", "pol", "roughABpol"):
        branch_roughness(physical, mode)
    # Broadening branches from the best simple intensity correction are run
    # after inspection; here compare them all from the combined branch.
    intensity = ROOT / "branch_roughABpol.gpx"
    for axis in ((0,0,1), (1,0,0), (1,1,0), (1,1,1)):
        branch_texture(intensity, axis)
    for axis in ((0,0,1), (1,0,0), (1,1,0)):
        branch_strain(intensity, "uniaxial", axis)
    branch_strain(intensity, "generalized")


if __name__ == "__main__": main()
