"""Run a selective atom-coordinate or Uiso refinement branch."""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def run(source, output, phase_index, labels, flags, reset):
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Frozen()
    if reset:
        for phase in project.phases():
            phase.set_refinements({"Atoms": {"all": ""}})
    phase = project.phase(phase_index)
    requested = {}
    available = {atom.label: atom for atom in phase.atoms()}
    for label in labels:
        if label not in available:
            raise ValueError(f"atom {label} not in {phase.name}: {sorted(available)}")
        if "U" in flags and available[label].uiso <= 0:
            available[label].uiso = 0.01
        requested[label] = flags
    phase.set_refinements({"Atoms": requested})
    project.set_Controls("cycles", 18)
    project.data["Controls"]["data"]["min dM/M"] = 0.00005
    history = []
    previous = None
    for iteration in range(4):
        project.refine()
        hist = project.histogram(0)
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        history.append({"iteration": iteration + 1, "rwp": hist.get_wR(),
                        "max_shift": rvals.get("Max shft/sig"),
                        "converged": rvals.get("converged")})
        if previous is not None and abs(previous - hist.get_wR()) < 1e-6 and abs(float(rvals.get("Max shft/sig", 999))) < 0.5:
            break
        previous = hist.get_wR()
    project.save(str(output))
    hist = project.histogram(0)
    covariance = project.data.get("Covariance", {}).get("data", {})
    masses = [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
              for p in project.phases()]
    atoms = []
    for pindex, current_phase in enumerate(project.phases()):
        for atom in current_phase.atoms():
            atoms.append({"phase": pindex, "phase_name": current_phase.name,
                          "label": atom.label, "element": atom.element,
                          "xyz": list(map(float, atom.coordinates)),
                          "uiso": float(atom.uiso), "flags": atom.refinement_flags})
    record = {
        "source": str(source), "output": str(output), "phase_index": phase_index,
        "labels": labels, "flags": flags, "history": history,
        "rwp": hist.get_wR(), "gof": covariance.get("Rvals", {}).get("GOF"),
        "max_shift": covariance.get("Rvals", {}).get("Max shft/sig"),
        "converged": covariance.get("Rvals", {}).get("converged"),
        "frozen": project.get_Frozen(),
        "fractions": [float(value / sum(masses)) for value in masses],
        "vary": [str(v) for v in covariance.get("varyList", [])],
        "atoms": atoms,
    }
    print("COORD", json.dumps(plain(record), allow_nan=True))


if __name__ == "__main__":
    if len(sys.argv) < 7:
        raise SystemExit("usage: coordinate_study.py SOURCE OUTPUT PHASE FLAGS RESET LABEL [LABEL ...]")
    G2.SetPrintLevel("warn")
    run(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve(), int(sys.argv[3]),
        sys.argv[6:], sys.argv[4], sys.argv[5].lower() in {"1", "true", "yes"})
