"""Emit one compact JSON record per GSAS-II project."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main(paths):
    for raw in paths:
        path = Path(raw)
        try:
            project = G2.G2Project(gpxfile=str(path.resolve()))
            hist = project.histogram(0)
            cov = project.data.get("Covariance", {}).get("data", {})
            masses = []
            phases = []
            for phase in project.phases():
                hap = phase.data["Histograms"][hist.name]
                masses.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
                phases.append({
                    "name": phase.name,
                    "cell": phase.get_cell(),
                    "size": float(hap["Size"][1][0]),
                    "size_full": hap["Size"],
                    "size_refine": bool(hap["Size"][2][0]),
                    "strain": float(hap["Mustrain"][1][0]),
                    "strain_full": hap["Mustrain"],
                    "strain_refine": bool(hap["Mustrain"][2][0]),
                    "texture": float(hap["Pref.Ori."][1]),
                    "texture_refine": bool(hap["Pref.Ori."][2]),
                })
            total = sum(masses)
            for phase, mass in zip(phases, masses):
                phase["fraction"] = mass / total
            x, obs, weight, calc, bkg, diff = [np.asarray(v, dtype=float) for v in hist.data["data"][1][:6]]
            record = {
                "file": path.name,
                "rwp": hist.get_wR(),
                "rp": hist.residuals.get("R"),
                "gof": cov.get("Rvals", {}).get("GOF"),
                "max_shift": cov.get("Rvals", {}).get("Max shft/sig"),
                "converged": cov.get("Rvals", {}).get("converged"),
                "nvars": cov.get("Rvals", {}).get("Nvars"),
                "frozen": project.get_Frozen(),
                "background": hist.data["Background"][0][:3],
                "background_min": float(np.min(bkg)),
                "zero": hist.InstrumentParameters["Zero"],
                "shift": hist.SampleParameters["Shift"],
                "polarization": hist.InstrumentParameters["Polariz."],
                "uvwxysh": {key: hist.InstrumentParameters[key] for key in ("U", "V", "W", "X", "Y", "SH/L")},
                "rough_a": hist.SampleParameters["SurfRoughA"],
                "rough_b": hist.SampleParameters["SurfRoughB"],
                "phases": phases,
            }
            print("SUMMARY", json.dumps(record, allow_nan=True))
        except Exception as exc:
            print("ERROR", path.name, repr(exc))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main(sys.argv[1:])
