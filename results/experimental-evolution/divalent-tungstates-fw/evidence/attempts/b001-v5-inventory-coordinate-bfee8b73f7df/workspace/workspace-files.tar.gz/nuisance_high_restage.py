"""Restage the high nuisance start after its simultaneous UVW branch hit W=0."""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def stage(project, label, repeats=3):
    rows = []
    previous = None
    project.set_Frozen()
    for iteration in range(repeats):
        project.refine()
        r = project.data["Covariance"]["data"]["Rvals"]
        rows.append({"stage": label, "iteration": iteration + 1,
                     "rwp": r["Rwp"], "max_shift": r["Max shft/sig"],
                     "converged": r["converged"]})
        if (previous is not None and r["converged"]
                and abs(previous-r["Rwp"]) < 1e-6 and abs(r["Max shft/sig"]) < 0.5):
            break
        previous = r["Rwp"]
    return rows


def summary(project, history):
    hist = project.histogram(0)
    r = project.data["Covariance"]["data"]["Rvals"]
    masses, phases = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(phase.data["General"]["Mass"] * hap["Scale"][0])
        phases.append({"name": phase.name, "cell": phase.get_cell(),
                       "size": hap["Size"][1][:2], "strain": hap["Mustrain"][1][0],
                       "texture": hap["Pref.Ori."][1]})
    total = sum(masses)
    for item, mass in zip(phases, masses):
        item["fraction"] = mass / total
    return {"rwp": r["Rwp"], "gof": r["GOF"], "max_shift": r["Max shft/sig"],
            "converged": r["converged"], "frozen": project.get_Frozen(),
            "uvw": [hist.InstrumentParameters[x][1] for x in ("U", "V", "W")],
            "history": history, "phases": phases}


def run(source, output):
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    for key, value in zip(("U", "V", "W"), (72.0, -52.0, 19.0)):
        hist.InstrumentParameters[key][1] = value
    hist.InstrumentParameters["Zero"][1] = -0.22
    hist.SampleParameters["SurfRoughA"][0] = 0.52
    hist.SampleParameters["SurfRoughB"][0] = 0.47
    factors = (1.14, 0.84, 1.11)
    for idx, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][0] *= factors[idx]
        hap["Size"][1][0] *= 0.72
        hap["Size"][1][1] *= 0.72
        if hap["Mustrain"][2][0]:
            hap["Mustrain"][1][0] *= 1.45
    project.phase(1).data["Histograms"][hist.name]["Pref.Ori."][1] = 1.55

    hist.clear_refinements({"Instrument Parameters": ["U", "V", "W"]})
    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    history = stage(project, "high_widths_fixed", 4)

    hist.set_refinements({"Instrument Parameters": ["W"]})
    project.set_Controls("parmMin", 1.0, f":{hist.id}:W")
    project.set_Controls("parmMax", 200.0, f":{hist.id}:W")
    history += stage(project, "release_W", 3)

    hist.set_refinements({"Instrument Parameters": ["U", "W"]})
    project.set_Controls("parmMin", 0.0, f":{hist.id}:U")
    project.set_Controls("parmMax", 200.0, f":{hist.id}:U")
    history += stage(project, "release_UW", 3)

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
    project.set_Controls("parmMin", -200.0, f":{hist.id}:V")
    project.set_Controls("parmMax", 200.0, f":{hist.id}:V")
    history += stage(project, "release_UVW", 5)

    project.save(str(output))
    print("HIGHRESTAGE", json.dumps(summary(project, history), allow_nan=True))


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: nuisance_high_restage.py SOURCE.gpx OUTPUT.gpx")
    G2.SetPrintLevel("warn")
    run(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
