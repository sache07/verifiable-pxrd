"""Test residual CaO as the chemically paired unreacted precursor."""
from pathlib import Path
import json, shutil
import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT=Path(__file__).resolve().parent
CAO=Path('<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/resources/b001-c05/cif/1/56/31/1563196.cif')

def plain(v):
    if isinstance(v,dict):return {str(k):plain(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [plain(x) for x in v]
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    return v

def run(cid):
    source=ROOT/f'inventory_wo3_{cid}.gpx';out=ROOT/f'inventory_wo3_{cid}_cao.gpx';shutil.copy2(source,out)
    g=G2.G2Project(gpxfile=str(out));h=g.histogram(0)
    p=g.add_phase(str(CAO),phasename='CaO_1563196',histograms=[h],fmthint='CIF')
    hap=p.data['Histograms'][h.name];hap['Scale']=[10.0,False]
    p.set_HAP_refinements({'Scale':True},[h]);p.set_refinements({'Cell':True})
    g.set_Controls('cycles',18);g.refine();g.save(str(out))
    hap=p.data['Histograms'][h.name];hap['Size'][0]='isotropic';hap['Size'][1][:3]=[0.1,1.,1.];hap['Size'][2]=[False]*3
    p.set_HAP_refinements({'Size':{'type':'isotropic','value':0.1,'refine':True,'LGmix':{'value':1.,'refine':False}}},[h])
    g.set_Controls('parmMin',0.003,f'{p.id}:{h.id}:Size;i');g.set_Controls('parmMax',20.,f'{p.id}:{h.id}:Size;i')
    g.set_Controls('cycles',18);g.refine();g.save(str(out))
    masses=[];ps=[]
    for ph in g.phases():
        hp=ph.data['Histograms'][h.name];m=ph.data['General']['Mass']*hp['Scale'][0];masses.append(m)
        ps.append(dict(name=ph.name,scale=plain(hp['Scale']),cell=ph.get_cell(),size=plain(hp['Size'])))
    for x,m in zip(ps,masses):x['weight_fraction']=m/sum(masses)
    cov=g.data.get('Covariance',{}).get('data',{})
    print('CAOTEST',json.dumps(dict(cid=cid,wR=h.get_wR(),phases=ps,Rvals=plain(cov.get('Rvals',{}))),allow_nan=True))

if __name__=='__main__':
    G2.SetPrintLevel('warn')
    import sys
    run(sys.argv[1])
