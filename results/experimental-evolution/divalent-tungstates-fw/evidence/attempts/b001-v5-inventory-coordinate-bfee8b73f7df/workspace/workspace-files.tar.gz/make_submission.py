"""Create the requested final PXRD deliverables from the selected GSAS-II project."""
from __future__ import annotations

import csv
import json
import shutil
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


PHASE_INFO = [
    {"name": "scheelite CaWO4", "formula": "CaWO4", "cif_path": "phase_CaWO4.cif",
     "source": "COD 7219229"},
    {"name": "monoclinic WO3", "formula": "WO3", "cif_path": "phase_WO3.cif",
     "source": "COD 2311041"},
    {"name": "ordered double-perovskite Ca3WO6", "formula": "Ca3WO6",
     "cif_path": "phase_Ca3WO6.cif",
     "source": "Ca-mapped Sr2CaWO6 analogue, COD 2104688"},
]


def run(source: Path, root: Path):
    final_gpx = root / "final.gpx"
    shutil.copy2(source, final_gpx)
    project = G2.G2Project(gpxfile=str(final_gpx))
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"]["Rvals"]

    mass_fracs = hist.ComputeMassFracs()
    phases = []
    for index, (phase, info) in enumerate(zip(project.phases(), PHASE_INFO)):
        output = root / info["cif_path"]
        phase.export_CIF(str(output))
        fraction, esd = mass_fracs[phase.name]
        cell = phase.get_cell()
        phases.append({
            **info,
            "cif": info["cif_path"],
            "weight_fraction": fraction,
            "weight_fraction_esd": esd,
            "weight_percent": 100.0 * fraction,
            "weight_percent_esd": 100.0 * esd,
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "cell": {
                "a_angstrom": cell["length_a"], "b_angstrom": cell["length_b"],
                "c_angstrom": cell["length_c"], "alpha_deg": cell["angle_alpha"],
                "beta_deg": cell["angle_beta"], "gamma_deg": cell["angle_gamma"],
                "volume_angstrom3": cell["volume"],
            },
        })

    x, observed, weights, calculated, background, stored_difference = [
        np.asarray(v, dtype=float) for v in hist.data["data"][1][:6]
    ]
    difference = observed - calculated
    with (root / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed_counts", "calculated_counts",
                         "difference_counts", "background_counts"])
        writer.writerows(zip(x, observed, calculated, difference, background))

    result = {
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": float(rvals["Rwp"]),
            "Rp_percent": float(hist.residuals["R"]),
            "GOF": float(rvals["GOF"]),
            "Rmin_percent": float(hist.residuals["wRmin"]),
            "chi_square": float(rvals["chisq"]),
            "Nobs": int(rvals["Nobs"]),
            "Nvars": int(rvals["Nvars"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
            "converged": bool(rvals["converged"]),
        },
        "project": "final.gpx",
        "profile": "fit.csv",
        "weight_fraction_basis": "normalized over modeled crystalline phases",
    }
    (root / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print("SUBMISSION", json.dumps(result, allow_nan=False))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: make_submission.py SOURCE.gpx")
    G2.SetPrintLevel("warn")
    run(Path(sys.argv[1]).resolve(), Path.cwd())
