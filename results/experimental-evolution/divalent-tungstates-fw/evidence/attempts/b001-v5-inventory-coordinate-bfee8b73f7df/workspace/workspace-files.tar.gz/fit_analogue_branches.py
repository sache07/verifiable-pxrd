"""Completed cumulative GSAS-II fits for mapped Ca3WO6 framework parents."""
from pathlib import Path
import json, shutil, sys
import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT=Path(__file__).resolve().parent
PROVENANCE=json.loads((ROOT/'analogues'/'provenance.json').read_text())['records']
MODELS={r['name']+'_Ca3WO6':r for r in PROVENANCE if r.get('status')=='prepared'}

def plain(v):
    if isinstance(v,dict):return {str(k):plain(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [plain(x) for x in v]
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    return v

def report(g,name,stage):
    h=g.histogram(0);m=[];ps=[]
    for p in g.phases():
        hp=p.data['Histograms'][h.name];z=p.data['General']['Mass']*hp['Scale'][0];m.append(z)
        ps.append(dict(name=p.name,scale=plain(hp['Scale']),cell=p.get_cell(),size=plain(hp['Size']),mustrain=plain(hp['Mustrain'])))
    for p,z in zip(ps,m):p['weight_fraction']=z/sum(m)
    cov=g.data.get('Covariance',{}).get('data',{})
    print('ANALOGUE',json.dumps(dict(model=name,stage=stage,wR=h.get_wR(),phases=ps,
          zero=h.InstrumentParameters['Zero'][1],sh=h.InstrumentParameters['SH/L'][1],
          rough=[h.SampleParameters['SurfRoughA'][0],h.SampleParameters['SurfRoughB'][0]],
          Rvals=plain(cov.get('Rvals',{})),vary=[str(v) for v in cov.get('varyList',[])]),allow_nan=True))

def run(name):
    model=MODELS[name];out=ROOT/f'analogue_fit_{name}.gpx';shutil.copy2(ROOT/'inventory_wo3_2311041.gpx',out)
    g=G2.G2Project(gpxfile=str(out));h=g.histogram(0);ca=g.phase(0)
    # The predecessor had two variables frozen at lower bounds. Restage with
    # those unsupported terms fixed at physical values before changing inventory.
    g.data['Controls']['data'].get('parmFrozen',{}).setdefault('FrozenList',[]).clear()
    h.clear_refinements({'Instrument Parameters':['SH/L']});h.InstrumentParameters['SH/L'][1]=0.005
    ca.clear_HAP_refinements({'Mustrain':True},[h]);ca.data['Histograms'][h.name]['Mustrain'][1][0]=0.0
    g.set_Controls('cycles',18);g.refine();g.save(str(out));report(g,name,'restaged_base')
    # Import the published parent in its original GSAS-compatible setting,
    # then perform the recorded element mapping and isotropic cell adaptation.
    p=g.add_phase(model['parent_cif'],phasename='Ca3WO6_'+name,histograms=[h],fmthint='CIF')
    mapping=model['substitutions'];counts={}
    for atom in p.atoms():
        el=mapping.get(atom.element,atom.element)
        if el in ('Ca','W','O'): atom.type=el
        counts[el]=counts.get(el,0)+1;atom.label=f'{el}{counts[el]}'
    fac=float(model['isotropic_cell_factor']);cell=p.data['General']['Cell']
    cell[1]*=fac;cell[2]*=fac;cell[3]*=fac;cell[7]*=fac**3
    G2.SetupGeneral(p.data,None)
    # Preserve a normalized transformed CIF for provenance and screening.
    (ROOT/'analogues_gsas').mkdir(exist_ok=True)
    p.export_CIF(str(ROOT/'analogues_gsas'/f'{name}.cif'))
    hp=p.data['Histograms'][h.name];hp['Scale']=[4.0,False]
    p.set_HAP_refinements({'Scale':True},[h]);p.set_refinements({'Cell':True})
    g.set_Controls('cycles',18);g.refine();g.save(str(out));report(g,name,'scale_cell')
    hp=p.data['Histograms'][h.name];hp['Size'][0]='isotropic';hp['Size'][1][:3]=[0.08,1.,1.];hp['Size'][2]=[False]*3
    p.set_HAP_refinements({'Size':{'type':'isotropic','value':0.08,'refine':True,'LGmix':{'value':1.,'refine':False}}},[h])
    g.set_Controls('parmMin',0.003,f'{p.id}:{h.id}:Size;i');g.set_Controls('parmMax',20.,f'{p.id}:{h.id}:Size;i')
    g.set_Controls('cycles',18);g.refine();g.save(str(out));report(g,name,'plus_size')

if __name__=='__main__':
    G2.SetPrintLevel('warn');run(sys.argv[1])
