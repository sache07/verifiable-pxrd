"""Matched, cumulative coordinate comparison for mapped Ca3WO6 parents."""
from __future__ import annotations

import copy
import json
import shutil
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def isotropic_adp(atom, value=0.01):
    atom.data[atom.cia] = "I"
    atom.data[atom.cia + 1] = float(value)
    atom.data[atom.cia + 2:atom.cia + 8] = [0.0] * 6


def settle(project, stage, rounds=3):
    project.set_Frozen()
    project.set_Controls("cycles", 18)
    project.data["Controls"]["data"]["min dM/M"] = 0.00005
    history = []
    previous = None
    for iteration in range(rounds):
        project.refine()
        hist = project.histogram(0)
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        history.append({"iteration": iteration + 1, "rwp": hist.get_wR(),
                        "max_shift": rvals.get("Max shft/sig"),
                        "converged": rvals.get("converged")})
        if previous is not None and abs(previous - hist.get_wR()) < 1e-6 and abs(float(rvals.get("Max shft/sig", 999))) < 0.5:
            break
        previous = hist.get_wR()
    print("FINALIST_STAGE", json.dumps({"stage": stage, "history": history}))
    return history


def summary(project, name, stages):
    hist = project.histogram(0)
    covariance = project.data.get("Covariance", {}).get("data", {})
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
        phases.append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "scale": plain(hap["Scale"]),
            "size": plain(hap["Size"]),
            "mustrain": plain(hap["Mustrain"]),
            "texture": plain(hap["Pref.Ori."]),
            "atoms": [{"label": atom.label, "element": atom.element,
                       "mult": atom.mult, "xyz": list(map(float, atom.coordinates)),
                       "adp_flag": atom.adp_flag, "adp": plain(atom.ADP),
                       "flags": atom.refinement_flags} for atom in phase.atoms()],
        })
    for phase, mass in zip(phases, masses):
        phase["fraction"] = mass / sum(masses)
    return {
        "name": name, "stages": stages, "rwp": hist.get_wR(),
        "gof": covariance.get("Rvals", {}).get("GOF"),
        "max_shift": covariance.get("Rvals", {}).get("Max shft/sig"),
        "converged": covariance.get("Rvals", {}).get("converged"),
        "frozen": project.get_Frozen(),
        "background": plain(hist.data["Background"][0]),
        "instrument": {key: plain(hist.InstrumentParameters[key]) for key in
                       ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")},
        "sample": {key: plain(hist.SampleParameters[key]) for key in
                   ("Shift", "SurfRoughA", "SurfRoughB")},
        "phases": phases,
    }


def run(source, reference, output, name):
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    ref = G2.G2Project(gpxfile=str(reference))
    hist = project.histogram(0)
    refhist = ref.histogram(0)

    # Matched nuisance model and known-phase structures.
    for key in ("Background", "Instrument Parameters", "Sample Parameters", "Limits"):
        hist.data[key] = copy.deepcopy(refhist.data[key])
    for index in (0, 1):
        phase = project.phase(index)
        refphase = ref.phase(index)
        phase.data["General"] = copy.deepcopy(refphase.data["General"])
        phase.data["Atoms"] = copy.deepcopy(refphase.data["Atoms"])
        phase.data["Histograms"][hist.name] = copy.deepcopy(
            refphase.data["Histograms"][refhist.name])

    # Preserve the candidate framework coordinates/cell but normalize ADPs and
    # use the same profile flexibility as all other candidates.
    candidate = project.phase(2)
    refhap = ref.phase(2).data["Histograms"][refhist.name]
    hap = candidate.data["Histograms"][hist.name]
    candidate_scale = copy.deepcopy(hap["Scale"])
    for key in ("Size", "Mustrain", "Pref.Ori.", "HStrain", "Extinction", "Babinet"):
        if key in refhap and key in hap:
            hap[key] = copy.deepcopy(refhap[key])
    hap["Scale"] = candidate_scale
    hap["Scale"][1] = True
    candidate.data["General"]["Cell"][0] = True
    for atom in candidate.atoms():
        atom.refinement_flags = ""
        isotropic_adp(atom, 0.01)
    G2.SetupGeneral(candidate.data, None)

    # Use the same parameter bounds/controls, then remove any inherited frozen vars.
    controls = project.data["Controls"]["data"]
    refcontrols = ref.data["Controls"]["data"]
    for key in ("parmMinDict", "parmMaxDict", "deriv type", "SVDtol"):
        if key in refcontrols:
            controls[key] = copy.deepcopy(refcontrols[key])
    project.set_Frozen()

    stages = {"profile": settle(project, "profile", 4)}
    candidate = project.phase(2)
    general_ca = [atom.label for atom in candidate.atoms()
                  if atom.element == "Ca" and atom.mult == 4]
    oxygens = [atom.label for atom in candidate.atoms() if atom.element == "O"]
    if len(general_ca) != 1 or len(oxygens) != 3:
        raise RuntimeError(f"unexpected mapped framework sites: Ca={general_ca}, O={oxygens}")

    candidate.set_refinements({"Atoms": {general_ca[0]: "X"}})
    stages["general_ca"] = settle(project, "general_ca", 3)
    for label in oxygens:
        candidate.set_refinements({"Atoms": {label: "X"}})
        stages[f"oxygen_{label}"] = settle(project, f"oxygen_{label}", 3)
    stages["final_settle"] = settle(project, "final_settle", 3)
    project.save(str(output))
    record = summary(project, name, stages)
    print("FINALIST", json.dumps(record, allow_nan=True))


if __name__ == "__main__":
    if len(sys.argv) != 5:
        raise SystemExit("usage: finalist_study.py SOURCE REF OUTPUT NAME")
    G2.SetPrintLevel("warn")
    run(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve(),
        Path(sys.argv[3]).resolve(), sys.argv[4])
