"""Independently refine a copy of final.gpx and compare all submitted quantities."""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def snapshot(project):
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    phases = []
    for phase in project.phases():
        ptrs = phase.data["General"]["AtomPtrs"]
        atoms = []
        for atom in phase.data["Atoms"]:
            atoms.append({"label": atom[0], "xyz": [float(v) for v in atom[ptrs[0]:ptrs[0]+3]],
                          "uiso": float(atom[ptrs[2]+3])})
        phases.append({"name": phase.name, "fraction": fractions[phase.name][0],
                       "cell": phase.get_cell(), "atoms": atoms})
    r = project.data["Covariance"]["data"]["Rvals"]
    arrays = [np.asarray(v, dtype=float).copy() for v in hist.data["data"][1][:6]]
    return {"phases": phases, "rwp": float(r["Rwp"]), "gof": float(r["GOF"]),
            "frozen": list(project.get_Frozen()), "arrays": arrays}


def periodic_delta(a, b):
    delta = np.asarray(a) - np.asarray(b)
    return np.minimum(np.abs(delta), np.abs(delta - np.round(delta)))


def run(root):
    final_path = root / "final.gpx"
    result = json.loads((root / "result.json").read_text())
    fit = np.genfromtxt(root / "fit.csv", delimiter=",", names=True)
    original_project = G2.G2Project(gpxfile=str(final_path))
    original = snapshot(original_project)

    work = root / ".tmp"
    work.mkdir(exist_ok=True)
    replay_path = work / "final_replay.gpx"
    shutil.copy2(final_path, replay_path)
    replay_project = G2.G2Project(gpxfile=str(replay_path))
    replay_project.set_Frozen()
    replay_project.set_Controls("cycles", 20)
    replay_project.data["Controls"]["data"]["min dM/M"] = 0.0001
    replay_history = []
    for iteration in range(2):
        replay_project.refine()
        r = replay_project.data["Covariance"]["data"]["Rvals"]
        replay_history.append({"iteration": iteration + 1, "rwp": r["Rwp"],
                               "max_shift": r["Max shft/sig"],
                               "converged": r["converged"]})
    replay_project.save(str(replay_path))
    replay = snapshot(replay_project)

    fraction_delta = max(abs(a["fraction"] - b["fraction"])
                         for a, b in zip(original["phases"], replay["phases"]))
    cell_keys = ("length_a", "length_b", "length_c", "angle_alpha",
                 "angle_beta", "angle_gamma", "volume")
    cell_delta = max(abs(a["cell"][key] - b["cell"][key])
                     for a, b in zip(original["phases"], replay["phases"])
                     for key in cell_keys)
    atom_delta = max(float(np.max(periodic_delta(a_atom["xyz"], b_atom["xyz"])))
                     for a, b in zip(original["phases"], replay["phases"])
                     for a_atom, b_atom in zip(a["atoms"], b["atoms"]))
    calc_delta = replay["arrays"][3] - original["arrays"][3]

    fit_delta = {
        "two_theta": float(np.max(np.abs(fit["two_theta_deg"] - original["arrays"][0]))),
        "observed": float(np.max(np.abs(fit["observed_counts"] - original["arrays"][1]))),
        "calculated": float(np.max(np.abs(fit["calculated_counts"] - original["arrays"][3]))),
        "difference": float(np.max(np.abs(fit["difference_counts"] -
                                            (original["arrays"][1] - original["arrays"][3])))),
    }
    result_fraction_delta = max(
        abs(item["weight_fraction"] - phase["fraction"])
        for item, phase in zip(result["phases"], original["phases"])
    )
    names_match = ([p["name"] for p in original["phases"]]
                   == [p["name"] for p in replay["phases"]])
    positive = all(p["fraction"] > 0 for p in replay["phases"])
    passed = (names_match and positive and not replay["frozen"]
              and fraction_delta < 1e-5 and cell_delta < 1e-3 and atom_delta < 1e-12
              and abs(replay["rwp"] - original["rwp"]) < 1e-3
              and max(fit_delta.values()) < 1e-8 and result_fraction_delta < 1e-12)
    check = {
        "passed": passed,
        "replay_history": replay_history,
        "phase_names_match": names_match,
        "all_replayed_fractions_positive": positive,
        "replay_frozen_variables": replay["frozen"],
        "max_weight_fraction_change": fraction_delta,
        "max_cell_parameter_change": cell_delta,
        "max_atomic_coordinate_change": atom_delta,
        "rwp_original_percent": original["rwp"],
        "rwp_replay_percent": replay["rwp"],
        "calculated_profile_rms_change_counts": float(np.sqrt(np.mean(calc_delta**2))),
        "calculated_profile_max_change_counts": float(np.max(np.abs(calc_delta))),
        "fit_csv_max_absolute_differences": fit_delta,
        "result_json_max_fraction_difference": result_fraction_delta,
    }
    (root / "replay_check.json").write_text(json.dumps(check, indent=2) + "\n")
    print("REPLAY", json.dumps(check, allow_nan=False))
    if not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    run(Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd())
