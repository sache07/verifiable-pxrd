"""Screen CIF composition, density, symmetry and shortest interatomic contacts."""
import json
import sys
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

for raw in sys.argv[1:]:
    path = Path(raw)
    try:
        structure = Structure.from_file(path)
        distances = structure.distance_matrix
        contacts = []
        for i in range(len(structure)):
            for j in range(i + 1, len(structure)):
                contacts.append((float(distances[i, j]),
                                 str(structure[i].specie), str(structure[j].specie), i, j))
        contacts.sort()
        analyzer = SpacegroupAnalyzer(structure, symprec=1e-3, angle_tolerance=2)
        print("SCREEN", json.dumps({
            "file": str(path),
            "formula": structure.composition.reduced_formula,
            "density_g_cm3": float(structure.density),
            "volume_a3": float(structure.volume),
            "space_group": analyzer.get_space_group_symbol(),
            "space_group_number": analyzer.get_space_group_number(),
            "shortest_contacts": [
                {"distance": d, "elements": [a, b], "indices": [i, j]}
                for d, a, b, i, j in contacts[:12]
            ],
        }))
    except Exception as exc:
        print("ERROR", json.dumps({"file": str(path), "error": repr(exc)}))
