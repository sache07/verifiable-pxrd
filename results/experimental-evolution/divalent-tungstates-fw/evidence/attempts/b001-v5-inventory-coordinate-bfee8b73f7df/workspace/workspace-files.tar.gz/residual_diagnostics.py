"""Create residual plots and list coherent standardized residual peaks."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks, peak_widths
from GSASII import GSASIIscriptable as G2


def main(project_path, output_stem):
    project = G2.G2Project(gpxfile=str(Path(project_path).resolve()))
    hist = project.histogram(0)
    x, observed, weights, calculated, background, difference = [
        np.asarray(values, dtype=float) for values in hist.data["data"][1][:6]
    ]
    # A one-pixel Gaussian suppresses point noise without joining distinct lines.
    standardized = (observed - calculated) / np.sqrt(np.maximum(observed, 1.0))
    smooth = gaussian_filter1d(standardized, 1.0)
    distance = max(2, int(round(0.05 / np.median(np.diff(x)))))
    pos, props = find_peaks(smooth, prominence=1.5, distance=distance)
    neg, nprops = find_peaks(-smooth, prominence=1.5, distance=distance)
    records = []
    for sign, indices, values in ((1, pos, smooth), (-1, neg, -smooth)):
        widths = peak_widths(values, indices, rel_height=0.5)[0] * np.median(np.diff(x))
        for index, width in zip(indices, widths):
            records.append({
                "sign": sign,
                "two_theta": float(x[index]),
                "standardized_height": float(standardized[index]),
                "smoothed_height": float(sign * smooth[index]),
                "counts_residual": float(observed[index] - calculated[index]),
                "fwhm_deg": float(width),
            })
    records.sort(key=lambda item: abs(item["smoothed_height"]), reverse=True)
    Path(output_stem + ".json").write_text(json.dumps({
        "project": str(Path(project_path).resolve()),
        "rwp": hist.get_wR(),
        "rmin": hist.residuals.get("wRmin"),
        "peaks": records[:100],
    }, indent=2))
    np.savez_compressed(output_stem + ".npz", x=x, observed=observed,
                        calculated=calculated, background=background,
                        standardized=standardized, smooth=smooth,
                        rwp=float(hist.get_wR()))

    for record in records[:30]:
        print("PEAK", json.dumps(record))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main(sys.argv[1], sys.argv[2])
