"""List calculated phase reflections near selected two-theta positions."""
import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

project = G2.G2Project(gpxfile=str(Path(sys.argv[1]).resolve()))
hist = project.histogram(0)
targets = [float(value) for value in sys.argv[2:]]
for phase_name, block in hist.data["Reflection Lists"].items():
    reflections = np.asarray(block.get("RefList", []))
    print("PHASE", phase_name, "keys", list(block), "shape", reflections.shape)
    if not len(reflections):
        continue
    print("FIRST", json.dumps(reflections[0].tolist()))
    # For constant-wavelength powder data, column 5 is calculated 2theta.
    for target in targets:
        rows = reflections[np.abs(reflections[:, 5] - target) <= 0.45]
        rows = rows[np.argsort(np.abs(rows[:, 5] - target))]
        for row in rows[:12]:
            print("REFL", json.dumps({"phase": phase_name, "target": target,
                                      "hkl": [int(v) for v in row[:3]],
                                      "two_theta": float(row[5]),
                                      "row": row.tolist()}))
