"""Run independent physically plausible nuisance starts for stability testing."""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


STARTS = {
    "low": {
        "uvw": (25.0, -15.0, 8.0), "zero": -0.08, "rough": (0.22, 0.18),
        "scale": (0.86, 1.16, 0.91), "size": 1.35, "strain": 0.65, "texture": 1.16,
    },
    "high": {
        "uvw": (72.0, -52.0, 19.0), "zero": -0.22, "rough": (0.52, 0.47),
        "scale": (1.14, 0.84, 1.11), "size": 0.72, "strain": 1.45, "texture": 1.55,
    },
}


def summarize(project, mode, history):
    hist = project.histogram(0)
    r = project.data["Covariance"]["data"]["Rvals"]
    masses, phases = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(phase.data["General"]["Mass"] * hap["Scale"][0])
        phases.append({"name": phase.name, "cell": phase.get_cell(),
                       "size": hap["Size"][1][:2], "strain": hap["Mustrain"][1][0],
                       "texture": hap["Pref.Ori."][1]})
    total = sum(masses)
    for item, mass in zip(phases, masses):
        item["fraction"] = mass / total
    return {"mode": mode, "rwp": r["Rwp"], "gof": r["GOF"],
            "max_shift": r["Max shft/sig"], "converged": r["converged"],
            "frozen": project.get_Frozen(), "history": history,
            "uvw": [hist.InstrumentParameters[x][1] for x in ("U", "V", "W")],
            "zero": hist.InstrumentParameters["Zero"][1],
            "rough": [hist.SampleParameters[x][0] for x in ("SurfRoughA", "SurfRoughB")],
            "phases": phases}


def run(source, mode, output):
    cfg = STARTS[mode]
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    for key, value in zip(("U", "V", "W"), cfg["uvw"]):
        hist.InstrumentParameters[key][1] = value
    hist.InstrumentParameters["Zero"][1] = cfg["zero"]
    hist.SampleParameters["SurfRoughA"][0] = cfg["rough"][0]
    hist.SampleParameters["SurfRoughB"][0] = cfg["rough"][1]
    for idx, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][0] *= cfg["scale"][idx]
        hap["Size"][1][0] *= cfg["size"]
        if hap["Size"][0] == "uniaxial":
            hap["Size"][1][1] *= cfg["size"]
        if hap["Mustrain"][2][0]:
            hap["Mustrain"][1][0] *= cfg["strain"]
    project.phase(1).data["Histograms"][hist.name]["Pref.Ori."][1] = cfg["texture"]

    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    history = []
    previous = None
    for iteration in range(6):
        project.refine()
        r = project.data["Covariance"]["data"]["Rvals"]
        history.append({"iteration": iteration + 1, "rwp": r["Rwp"],
                        "max_shift": r["Max shft/sig"], "converged": r["converged"]})
        if (previous is not None and r["converged"]
                and abs(previous - r["Rwp"]) < 1e-6
                and abs(r["Max shft/sig"]) < 0.5):
            break
        previous = r["Rwp"]
    project.save(str(output))
    print("RESTART", json.dumps(summarize(project, mode, history), allow_nan=True))


if __name__ == "__main__":
    if len(sys.argv) != 4 or sys.argv[2] not in STARTS:
        raise SystemExit("usage: nuisance_restart.py SOURCE.gpx low|high OUTPUT.gpx")
    G2.SetPrintLevel("warn")
    run(Path(sys.argv[1]).resolve(), sys.argv[2], Path(sys.argv[3]).resolve())
