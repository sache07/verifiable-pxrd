"""Add and compare chemically plausible residual WO3 structures."""
from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
DB = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/resources/b001-c05/cif")
CANDIDATES = ["2311041", "2106293", "2107312", "1563541"]


def cif(cid): return DB / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


def plain(v):
    if isinstance(v, dict): return {str(k): plain(x) for k,x in v.items()}
    if isinstance(v, (list,tuple)): return [plain(x) for x in v]
    if isinstance(v,np.ndarray): return v.tolist()
    if isinstance(v,np.generic): return v.item()
    return v


def report(g, cid, stage):
    h=g.histogram(0); cov=g.data.get('Covariance',{}).get('data',{})
    phases=[]
    masses=[]
    for p in g.phases():
        hap=p.data['Histograms'][h.name]
        m=hap['Scale'][0]*p.data['General']['Mass'];masses.append(m)
        phases.append(dict(name=p.name,cell=p.get_cell(),mass=p.data['General']['Mass'],scale=plain(hap['Scale']),
                           size=plain(hap['Size']),mustrain=plain(hap['Mustrain'])))
    for p,m in zip(phases,masses):p['weight_fraction']=m/sum(masses)
    out=dict(cid=cid,stage=stage,wR=h.get_wR(),phases=phases,
             rough=[h.SampleParameters['SurfRoughA'][0],h.SampleParameters['SurfRoughB'][0]],
             zero=h.InstrumentParameters['Zero'][1],sh=h.InstrumentParameters['SH/L'][1],
             Rvals=plain(cov.get('Rvals',{})),vary=[str(v) for v in cov.get('varyList',[])])
    print('INVENTORY',json.dumps(out,allow_nan=True))


def run(cid):
    out=ROOT/f'inventory_wo3_{cid}.gpx'
    shutil.copy2(ROOT/'branch_roughAB.gpx',out)
    g=G2.G2Project(gpxfile=str(out));h=g.histogram(0)
    p=g.add_phase(str(cif(cid)),phasename=f'WO3_{cid}',histograms=[h],fmthint='CIF')
    hap=p.data['Histograms'][h.name]
    hap['Scale']=[8.0,False]
    # Comparable low-flexibility first stage: scale and symmetry-allowed cell.
    p.set_HAP_refinements({'Scale':True},[h]);p.set_refinements({'Cell':True})
    g.set_Controls('cycles',18);g.refine();g.save(str(out));report(g,cid,'scale_cell')
    # Give the new phase its own isotropic coherent-domain width, while common
    # instrumental widths remain fixed and coordinates remain untouched.
    hap=p.data['Histograms'][h.name]
    hap['Size'][0]='isotropic';hap['Size'][1][:3]=[0.10,1.0,1.0];hap['Size'][2]=[False,False,False]
    p.set_HAP_refinements({'Size':{'type':'isotropic','value':0.10,'refine':True,
                                  'LGmix':{'value':1.0,'refine':False}}},[h])
    g.set_Controls('parmMin',0.003,f'{p.id}:{h.id}:Size;i')
    g.set_Controls('parmMax',20.0,f'{p.id}:{h.id}:Size;i')
    g.set_Controls('cycles',18);g.refine();g.save(str(out));report(g,cid,'plus_size')


def continue_size(cid):
    """Complete the matched size stage when a slow low-symmetry cell timed out."""
    out=ROOT/f'inventory_wo3_{cid}.gpx'
    g=G2.G2Project(gpxfile=str(out));h=g.histogram(0);p=g.phase(1)
    hap=p.data['Histograms'][h.name]
    hap['Size'][0]='isotropic';hap['Size'][1][:3]=[0.10,1.0,1.0];hap['Size'][2]=[False,False,False]
    p.set_HAP_refinements({'Size':{'type':'isotropic','value':0.10,'refine':True,
                                  'LGmix':{'value':1.0,'refine':False}}},[h])
    g.set_Controls('parmMin',0.003,f'{p.id}:{h.id}:Size;i')
    g.set_Controls('parmMax',20.0,f'{p.id}:{h.id}:Size;i')
    g.set_Controls('cycles',18);g.refine();g.save(str(out));report(g,cid,'plus_size')


if __name__=='__main__':
    G2.SetPrintLevel('warn')
    for candidate in CANDIDATES: run(candidate)
