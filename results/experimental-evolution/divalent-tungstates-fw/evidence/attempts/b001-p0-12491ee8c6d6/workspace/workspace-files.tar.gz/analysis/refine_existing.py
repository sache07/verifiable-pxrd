#!/usr/bin/env python3
"""Continue a converged GSAS-II project with controlled profile/structure stages."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def clear_flags(project, hist) -> None:
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True, "HStrain": True},
            [hist],
        )
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    project.data["Covariance"]["data"] = {}


def state(project, hist, stage):
    masses = []
    profile = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
        profile[phase.name] = {
            "size": float(hap["Size"][1][0]),
            "mustrain": float(hap["Mustrain"][1][0]),
            "MD": float(hap["Pref.Ori."][1]),
            "MD_axis": list(hap["Pref.Ori."][3]),
        }
    total = sum(masses)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    print(
        json.dumps(
            {
                "stage": stage,
                "Rwp_percent": float(hist.get_wR()),
                "fractions": {p.name: masses[i] / total for i, p in enumerate(project.phases())},
                "instrument": {k: float(inst[k][1]) for k in ["Zero", "U", "W", "X", "SH/L", "Polariz."]},
                "shift_um": float(sample["Shift"][0]),
                "profile": profile,
            },
            sort_keys=True,
        )
    )


def cycle(project, hist, stage, cycles=12):
    project.set_Controls("cycles", cycles)
    project.refine()
    state(project, hist, stage)


def main(args):
    args.out.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.out.resolve()))
    hist = project.histogram(0)
    clear_flags(project, hist)
    if args.preserve_profile:
        for phase in project.phases():
            phase.set_HAP_refinements({"Scale": True}, [hist])
        hist.set_refinements({"Background": True})
        cycle(project, hist, "preserved_profile_scale")
        if args.atoms:
            project.phase("PbWO4_scheelite").set_refinements({"Atoms": {"O1": "X"}})
            cycle(project, hist, "PbWO4_oxygen", cycles=10)
            project.phase("WO3_monoclinic").set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
            cycle(project, hist, "WO3_tungsten", cycles=12)
            project.phase("PbCO3_cerussite").set_refinements({"Atoms": {"Pb0": "X"}})
            cycle(project, hist, "PbCO3_lead", cycles=10)
        project.save(str(args.out.resolve()))
        return
    x = np.asarray(hist.data["data"][1][0], float)
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})

    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": args.U, "W": args.W, "X": args.X, "SH/L": args.shl}.items():
        inst[key][1] = float(value)
        inst[key][2] = False
    starts = [(0.30, 600.0), (1.2, 1000.0), (1.5, 0.0)]
    for phase, (size, strain) in zip(project.phases(), starts):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        hap["Mustrain"][1][1] = strain
        hap["Mustrain"][2] = [False, False, False]
        phase.set_HAP_refinements({"Scale": True}, [hist])
    hist.set_refinements({"Background": True})
    cycle(project, hist, "reset_profile")

    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    cycle(project, hist, "sizes")
    for phase in project.phases():
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    cycle(project, hist, "isotropic_profiles")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    cycle(project, hist, "instrument_and_profiles")

    if args.atoms:
        project.phase("PbWO4_scheelite").set_refinements({"Atoms": {"O1": "X"}})
        project.phase("PbCO3_cerussite").set_refinements({"Atoms": {"Pb0": "X"}})
        project.phase("WO3_monoclinic").set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
        cycle(project, hist, "heavy_atom_coordinates", cycles=16)

    project.save(str(args.out.resolve()))


def parser():
    p = argparse.ArgumentParser()
    p.add_argument("--input", type=Path, default=Path("analysis/run3/working.gpx"))
    p.add_argument("--out", type=Path, default=Path("analysis/continued1.gpx"))
    p.add_argument("--U", type=float, default=5.0)
    p.add_argument("--W", type=float, default=5.0)
    p.add_argument("--X", type=float, default=1.0)
    p.add_argument("--shl", type=float, default=0.03)
    p.add_argument("--atoms", action="store_true")
    p.add_argument("--preserve-profile", action="store_true")
    return p


if __name__ == "__main__":
    main(parser().parse_args())
