#!/usr/bin/env python3
"""Screen the generator-supported March-Dollase axes against the observed scan."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2

from refine_existing import clear_flags


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def main(args):
    G2.SetPrintLevel("error")
    args.out.mkdir(parents=True, exist_ok=True)
    summary = []
    seed = G2.G2Project(gpxfile=str(args.input.resolve()))
    names = [p.name for p in seed.phases()]
    for phase_name in names:
        for axis in AXES:
            tag = phase_name.split("_")[0] + "_" + "".join(map(str, axis))
            output = args.out / (tag + ".gpx")
            project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(output.resolve()))
            hist = project.histogram(0)
            clear_flags(project, hist)
            for phase in project.phases():
                phase.set_HAP_refinements({"Scale": True}, [hist])
            hist.set_refinements({"Background": True})
            phase = project.phase(phase_name)
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][3] = list(axis)
            phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])
            project.set_Controls("cycles", args.cycles)
            project.refine()
            project.save(str(output.resolve()))
            masses = [
                p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
                for p in project.phases()
            ]
            total = sum(masses)
            row = {
                "phase": phase_name,
                "axis": list(axis),
                "MD_ratio": float(hap["Pref.Ori."][1]),
                "Rwp_percent": float(hist.get_wR()),
                "fractions": {p.name: masses[i] / total for i, p in enumerate(project.phases())},
                "project": str(output),
            }
            summary.append(row)
            print(json.dumps(row, sort_keys=True), flush=True)
    (args.out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")


def parser():
    p = argparse.ArgumentParser()
    p.add_argument("--input", type=Path, default=Path("analysis/physical2.gpx"))
    p.add_argument("--out", type=Path, default=Path("analysis/texture_trials"))
    p.add_argument("--cycles", type=int, default=8)
    return p


if __name__ == "__main__":
    main(parser().parse_args())
