#!/usr/bin/env python3
"""Refine one symmetry-independent Uiso value per phase using equivalence constraints."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2

from refine_existing import clear_flags


def main(args):
    G2.SetPrintLevel('warn')
    project=G2.G2Project(gpxfile=str(args.input.resolve()),newgpx=str(args.out.resolve()))
    hist=project.histogram(0)
    clear_flags(project,hist)
    project.data['Constraints']['data']['Phase']=[]
    project.save()
    for i,phase in enumerate(project.phases()):
        atoms=phase.atoms()
        for atom in atoms:
            atom.uiso=args.start
            atom.refinement_flags='U'
        if len(atoms)>1:
            project.add_EquivConstr(
                [f'{i}::AUiso:{j}' for j in range(len(atoms))],
                reloadIdx=(i==0),override=True)
        phase.set_HAP_refinements({'Scale':True},[hist])
    hist.set_refinements({'Background':True,'Instrument Parameters':['Polariz.']})
    # Keep the accepted texture terms active while Uiso changes intensities.
    for name in ['PbCO3_cerussite','WO3_monoclinic']:
        project.phase(name).set_HAP_refinements({'Pref.Ori.':True},[hist])
    project.set_Controls('cycles',16)
    project.refine()
    masses=[]
    values={}
    for phase in project.phases():
        hap=phase.data['Histograms'][hist.name]
        masses.append(phase.data['General']['Mass']*hap['Scale'][0])
        values[phase.name]=[a.uiso for a in phase.atoms()]
    total=sum(masses)
    print(json.dumps({
        'Rwp_percent':hist.get_wR(),'Uiso_A2':values,
        'fractions':{p.name:masses[i]/total for i,p in enumerate(project.phases())},
        'polarization':hist.data['Instrument Parameters'][0]['Polariz.'][1],
    },sort_keys=True))
    project.save(str(args.out.resolve()))


def parser():
    p=argparse.ArgumentParser()
    p.add_argument('--input',type=Path,default=Path('analysis/nuisance1.gpx'))
    p.add_argument('--out',type=Path,default=Path('analysis/uiso1.gpx'))
    p.add_argument('--start',type=float,default=0.01)
    return p


if __name__=='__main__':main(parser().parse_args())
