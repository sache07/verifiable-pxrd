#!/usr/bin/env python3
"""Freeze, export, replay and document the selected GSAS-II model."""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_existing import clear_flags


def main(args):
    root = args.root.resolve()
    source = args.input.resolve()
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(root / "final.gpx"))
    hist = project.histogram(0)
    project.save(str(root / "final.gpx"))
    statistical = hist.ComputeMassFracs()
    native = dict(hist.data["data"][0])

    # Freeze all flags and remove development-only constraints/limits. Values are unchanged.
    clear_flags(project, hist)
    for key in ("Phase", "HAP", "Hist", "Global"):
        project.data["Constraints"]["data"][key] = []
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    for key in list(hist.data["data"][0]):
        if str(key).startswith("3:"):
            del hist.data["data"][0][key]
    project.save(str(root / "final.gpx"))

    exports = ["PbWO4.cif", "PbCO3.cif", "WO3.cif"]
    for phase, filename in zip(project.phases(), exports):
        phase.export_CIF(str(root / filename))

    # Recalculate the complete original grid exactly as the independent evaluator does.
    replay_dir = root / "analysis" / "final_replay"
    replay_dir.mkdir(parents=True, exist_ok=True)
    runtime = root / "learned" / "divalent-tungstates" / "scorer" / "runtime"
    sys.path.insert(0, str(runtime))
    from replay_worker import replay

    here = Path.cwd()
    os.chdir(replay_dir)
    try:
        replay_report = replay(
            {
                "project": str((root / "final.gpx").resolve()),
                "observed": str((root / "inputs" / "pattern.csv").resolve()),
            }
        )
    finally:
        os.chdir(here)
    if replay_report["status"] != "replayed":
        raise RuntimeError("final project did not replay: " + json.dumps(replay_report))

    with np.load(replay_dir / "prediction.npz", allow_pickle=False) as z:
        x = z["x"].copy()
        observed = z["observed"].copy()
        calculated = z["predicted"].copy()
    difference = observed - calculated
    np.savetxt(
        root / "fit.csv",
        np.column_stack([x, observed, calculated, difference]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    full_rwp = float(100.0 * np.sqrt(chi_square / denominator))
    reduced = float(chi_square / len(observed))

    phases = project.phases()
    replay_by_name = {row["name"]: row for row in replay_report["phases"]}
    labels = ["PbWO4 (scheelite)", "PbCO3 (cerussite)", "WO3 (monoclinic)"]
    records = []
    for phase, label, filename in zip(phases, labels, exports):
        row = replay_by_name[phase.name]
        cell = phase.data["General"]["Cell"]
        records.append(
            {
                "name": label,
                "cif_path": filename,
                "weight_fraction": row["weight_fraction"],
                "weight_fraction_esd_statistical": statistical[phase.name][1],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cell_angstrom_degree": {
                    "a": cell[1],
                    "b": cell[2],
                    "c": cell[3],
                    "alpha": cell[4],
                    "beta": cell[5],
                    "gamma": cell[6],
                },
            }
        )
    result = {
        "phases": records,
        "fit_statistics": {
            "rwp_percent_full_grid_replay": full_rwp,
            "rwp_percent_gsas_fit_interval": float(native["wR"]),
            "rp_percent_gsas_fit_interval": float(native["R"]),
            "weighted_chi_square_full_grid": chi_square,
            "chi_square_per_point_full_grid": reduced,
            "points_full_grid": int(len(observed)),
            "fit_interval_two_theta_deg": [10.0, 100.0],
            "replay_profile_review_flags": replay_report["profile_review_flags"],
        },
        "refinement_histogram": hist.name,
        "fraction_basis": "normalized over the three modeled crystalline phases",
    }
    (root / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    report = f"""# Powder XRD phase analysis

The pattern is explained by three crystalline phases. The refined crystalline weight fractions are **{100*records[0]['weight_fraction']:.2f}% PbWO4**, **{100*records[1]['weight_fraction']:.2f}% PbCO3**, and **{100*records[2]['weight_fraction']:.2f}% WO3** (normalized over modeled crystalline material).

## Evidence

- Scheelite PbWO4 accounts for the dominant series at approximately 27.90, 33.27, 45.21, 47.53, 55.71 and 72.42 degrees 2theta. Because exact PbWO4 entries were absent from the supplied library, its I41/a model was adapted from isostructural PbMoO4/SrWO4 references and its oxygen coordinate was refined.
- Monoclinic P21/c WO3 accounts for the 23.64/24.12/24.90 degree triplet and the associated 33.78-34.69 degree group. COD 2311041 gave the best physically valid WO3 model; the older close-fitting model produced implausibly short O-O contacts.
- Cerussite PbCO3 is required by its independent lines near 25.33, 26.05, 29.48, 36.69 and 44.09 degrees. This is chemically consistent with residual precursor after firing at 550 C.
- The refined assemblage is also chemically self-consistent: the residual PbCO3 and WO3 amounts are approximately equimolar (0.696 and 0.753 mmol per gram of crystalline material), and the total Pb:W molar ratio is 0.974, close to the stated 1:1 precursor ratio.

The independently regenerated full-grid profile has Rwp = {full_rwp:.3f}% and chi-square per point = {reduced:.3f}; no additional coherent peak family remains. All three exported structures pass the broad occupancy/contact screen, and the replay reports no profile-review flags.

## Remaining uncertainty

Formal scale-factor uncertainties are about 0.23-0.26 wt%, but preferred orientation, profile/ADP correlation and reference-model choice dominate; approximately 1-2 wt% absolute uncertainty is more realistic. The WO3 framework is secure, while its detailed oxygen coordinates and choice among closely related monoclinic descriptions are less unique. Oxygen positions in PbWO4 are also weakly constrained by Cu X-ray scattering.

Absolute lattice parameters are less reliable than the phase identities: without an internal standard, angular zero, specimen displacement and cell dimensions were strongly correlated. The saved project uses the best empirical common angular correction (Zero = -0.934 degrees and Shift = -2432 micrometres); those nuisance values should not be interpreted as a physical specimen height. No amorphous fraction was quantified, so all reported fractions are crystalline-normalized.
"""
    (root / "report.md").write_text(report)
    print(json.dumps(result, indent=2))


def parser():
    p = argparse.ArgumentParser()
    p.add_argument("--input", type=Path, default=Path("analysis/clean231_uiso2.gpx"))
    p.add_argument("--root", type=Path, default=Path("."))
    return p


if __name__ == "__main__":
    main(parser().parse_args())
