#!/usr/bin/env python3
"""Screen supported uniaxial microstrain axes for the broadened phases."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2

from refine_existing import clear_flags


AXES=([0,0,1],[1,0,0],[0,1,0],[1,1,0],[1,1,1])


def main(args):
    G2.SetPrintLevel('error')
    args.out.mkdir(parents=True,exist_ok=True)
    rows=[]
    for phase_name in ['PbWO4_scheelite','PbCO3_cerussite']:
        for axis in AXES:
            tag=phase_name.split('_')[0]+'_'+''.join(map(str,axis))
            output=args.out/(tag+'.gpx')
            project=G2.G2Project(gpxfile=str(args.input.resolve()),newgpx=str(output.resolve()))
            hist=project.histogram(0);clear_flags(project,hist)
            for phase in project.phases():phase.set_HAP_refinements({'Scale':True},[hist])
            hist.set_refinements({'Background':True})
            phase=project.phase(phase_name);hap=phase.data['Histograms'][hist.name]
            start=max(0.,float(hap['Mustrain'][1][0]))
            hap['Mustrain'][0]='uniaxial';hap['Mustrain'][1][0]=start;hap['Mustrain'][1][1]=start
            phase.set_HAP_refinements({'Mustrain':{'type':'uniaxial','direction':list(axis),'refine':True}},[hist])
            project.set_Controls('cycles',12);project.refine();project.save(str(output.resolve()))
            row={'phase':phase_name,'axis':list(axis),'Rwp_percent':hist.get_wR(),
                 'equatorial_ppm':hap['Mustrain'][1][0],'axial_ppm':hap['Mustrain'][1][1],
                 'project':str(output)}
            rows.append(row);print(json.dumps(row,sort_keys=True),flush=True)
    (args.out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')


def parser():
    p=argparse.ArgumentParser()
    p.add_argument('--input',type=Path,default=Path('analysis/uiso1.gpx'))
    p.add_argument('--out',type=Path,default=Path('analysis/anisotropy_trials'))
    return p


if __name__=='__main__':main(parser().parse_args())
