#!/usr/bin/env python3
"""Re-express the peak positions with plausible zero/specimen displacement and refit cells."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

from refine_existing import clear_flags


def main(args):
    G2.SetPrintLevel('warn')
    project=G2.G2Project(gpxfile=str(args.input.resolve()),newgpx=str(args.out.resolve()))
    hist=project.histogram(0);clear_flags(project,hist)
    hist.data['Instrument Parameters'][0]['Zero'][1]=args.zero
    hist.data['Sample Parameters']['Shift'][0]=args.shift
    for phase in project.phases():
        cell=phase.data['General']['Cell']
        cell[1]*=args.cell_factor;cell[2]*=args.cell_factor;cell[3]*=args.cell_factor
        cell[7]=G2lat.calc_V(G2lat.cell2A(cell[1:7]))
        phase.set_HAP_refinements({'Scale':True},[hist])
    hist.set_refinements({'Background':True})
    project.set_Controls('cycles',0);project.refine()
    print(json.dumps({'stage':'start','Rwp_percent':hist.get_wR()}))
    for phase in project.phases():phase.set_refinements({'Cell':True})
    project.set_Controls('cycles',16);project.refine()
    masses=[];cells={}
    for phase in project.phases():
        hap=phase.data['Histograms'][hist.name]
        masses.append(phase.data['General']['Mass']*hap['Scale'][0])
        cells[phase.name]=phase.data['General']['Cell'][1:7]
    total=sum(masses)
    print(json.dumps({'stage':'cell_refined','Rwp_percent':hist.get_wR(),
        'zero_deg':args.zero,'shift_um':args.shift,'cells':cells,
        'fractions':{p.name:masses[i]/total for i,p in enumerate(project.phases())}},sort_keys=True))
    project.save(str(args.out.resolve()))


def parser():
    p=argparse.ArgumentParser()
    p.add_argument('--input',type=Path,default=Path('analysis/uiso1.gpx'))
    p.add_argument('--out',type=Path,default=Path('analysis/angle1.gpx'))
    p.add_argument('--zero',type=float,default=0.0)
    p.add_argument('--shift',type=float,default=-800.0)
    p.add_argument('--cell-factor',type=float,default=1.0022)
    return p


if __name__=='__main__':main(parser().parse_args())
