#!/usr/bin/env python3
"""Remove nonphysical profile compensation from a converged trial project."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2

from refine_existing import clear_flags


def report(project, hist, stage):
    mass = []
    profiles = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass.append(phase.data["General"]["Mass"] * hap["Scale"][0])
        profiles[phase.name] = {"size_um": hap["Size"][1][0], "mustrain_ppm": hap["Mustrain"][1][0]}
    total = sum(mass)
    inst = hist.data["Instrument Parameters"][0]
    print(json.dumps({
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "fractions": {p.name: mass[i]/total for i,p in enumerate(project.phases())},
        "instrument": {k: inst[k][1] for k in ["U","W","X","SH/L","Zero"]},
        "profiles": profiles,
    }, sort_keys=True))


def refine(project, hist, stage, cycles=10):
    project.set_Controls("cycles", cycles)
    project.refine()
    report(project, hist, stage)


def main(args):
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.out.resolve()))
    hist = project.histogram(0)
    clear_flags(project, hist)
    inst = hist.data["Instrument Parameters"][0]
    inst["X"][1] = args.X
    inst["SH/L"][1] = args.shl
    wo3 = project.phase("WO3_monoclinic")
    whap = wo3.data["Histograms"][hist.name]
    whap["Mustrain"][0] = "isotropic"
    whap["Mustrain"][1][0] = 0.0
    whap["Mustrain"][1][1] = 0.0
    whap["Mustrain"][2] = [False, False, False]
    whap["Size"][0] = "isotropic"
    whap["Size"][1][0] = args.wo3_size
    whap["Size"][2] = [False, False, False]
    ch = project.phase("PbCO3_cerussite").data["Histograms"][hist.name]
    ch["Size"][0] = "isotropic"
    ch["Size"][1][0] = args.pbco3_size
    ch["Size"][2] = [False, False, False]
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, [hist])
    hist.set_refinements({"Background": True})
    refine(project, hist, "fixed_physical_reset")

    project.phase("PbWO4_scheelite").set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    }, [hist])
    project.phase("PbCO3_cerussite").set_HAP_refinements({
        "Mustrain": {"type": "isotropic", "refine": True},
    }, [hist])
    refine(project, hist, "major_phase_profiles", cycles=12)

    if args.refine_uw:
        hist.set_refinements({"Instrument Parameters": ["U", "W"]})
        refine(project, hist, "UW_and_major_profiles", cycles=12)
    if args.main_oxygen:
        clear_flags(project, hist)
        for phase in project.phases():
            phase.set_HAP_refinements({"Scale": True}, [hist])
        hist.set_refinements({"Background": True})
        project.phase("PbWO4_scheelite").set_refinements({"Atoms": {"O1": "X"}})
        refine(project, hist, "PbWO4_oxygen", cycles=12)
    project.save(str(args.out.resolve()))


def parser():
    p=argparse.ArgumentParser()
    p.add_argument("--input", type=Path, default=Path("analysis/run3/working.gpx"))
    p.add_argument("--out", type=Path, default=Path("analysis/physical1.gpx"))
    p.add_argument("--X", type=float, default=6.0)
    p.add_argument("--shl", type=float, default=0.005)
    p.add_argument("--wo3-size", type=float, default=1.5)
    p.add_argument("--pbco3-size", type=float, default=1.5)
    p.add_argument("--refine-uw", action="store_true")
    p.add_argument("--main-oxygen", action="store_true")
    return p


if __name__ == "__main__":
    main(parser().parse_args())
