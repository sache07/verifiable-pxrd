#!/usr/bin/env python3
"""Refine supported orientation and intensity nuisance terms from a stable model."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2

from refine_existing import clear_flags


def snapshot(project, hist, stage):
    masses=[]
    md={}
    for phase in project.phases():
        hap=phase.data['Histograms'][hist.name]
        masses.append(phase.data['General']['Mass']*hap['Scale'][0])
        md[phase.name]={'ratio':hap['Pref.Ori.'][1],'axis':hap['Pref.Ori.'][3]}
    total=sum(masses)
    print(json.dumps({
        'stage':stage,'Rwp_percent':hist.get_wR(),
        'fractions':{p.name:masses[i]/total for i,p in enumerate(project.phases())},
        'MD':md,'polarization':hist.data['Instrument Parameters'][0]['Polariz.'][1],
        'surface_roughness':{
            'A':hist.data['Sample Parameters']['SurfRoughA'][0],
            'B':hist.data['Sample Parameters']['SurfRoughB'][0]},
    },sort_keys=True))


def main(args):
    G2.SetPrintLevel('warn')
    project=G2.G2Project(gpxfile=str(args.input.resolve()),newgpx=str(args.out.resolve()))
    hist=project.histogram(0)
    clear_flags(project,hist)
    for phase in project.phases(): phase.set_HAP_refinements({'Scale':True},[hist])
    hist.set_refinements({'Background':True})
    settings=[('PbCO3_cerussite',[1,0,0],1.13),('WO3_monoclinic',[0,1,0],1.06)]
    for name,axis,ratio in settings:
        phase=project.phase(name);hap=phase.data['Histograms'][hist.name]
        hap['Pref.Ori.'][0]='MD';hap['Pref.Ori.'][1]=ratio;hap['Pref.Ori.'][3]=axis
        phase.set_HAP_refinements({'Pref.Ori.':True},[hist])
    project.set_Controls('cycles',12);project.refine();snapshot(project,hist,'textures')
    if args.polarization:
        hist.set_refinements({'Instrument Parameters':['Polariz.']})
        project.set_Controls('cycles',12);project.refine();snapshot(project,hist,'textures_polarization')
    if args.roughness:
        sample=hist.data['Sample Parameters']
        sample['SurfRoughA'][0]=0.1;sample['SurfRoughB'][0]=0.1
        hist.set_refinements({'Sample Parameters':['SurfRoughA','SurfRoughB']})
        project.set_Controls('cycles',12);project.refine();snapshot(project,hist,'textures_polarization_roughness')
    project.save(str(args.out.resolve()))


def parser():
    p=argparse.ArgumentParser()
    p.add_argument('--input',type=Path,default=Path('analysis/physical2.gpx'))
    p.add_argument('--out',type=Path,default=Path('analysis/nuisance1.gpx'))
    p.add_argument('--polarization',action='store_true')
    p.add_argument('--roughness',action='store_true')
    return p


if __name__=='__main__':main(parser().parse_args())
