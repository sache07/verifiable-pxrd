#!/usr/bin/env python3
"""Compare allowed WO3 reference structures in an otherwise fixed three-phase model."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2

from refine_existing import clear_flags


IDS=('1528915','2311041','2106293','1010618','1563541','2107312')


def cif_path(root,cid):
    return root/cid[0]/cid[1:3]/cid[3:5]/(cid+'.cif')


def main(args):
    G2.SetPrintLevel('warn');args.out.mkdir(parents=True,exist_ok=True)
    summary=[]
    for cid in IDS:
        output=args.out/(cid+'.gpx')
        project=G2.G2Project(gpxfile=str(args.input.resolve()),newgpx=str(output.resolve()))
        hist=project.histogram(0);clear_flags(project,hist)
        for key in ('Phase','HAP','Hist','Global'):project.data['Constraints']['data'][key]=[]
        old=project.phase('WO3_monoclinic');oldhap=old.data['Histograms'][hist.name]
        old_mass=old.data['General']['Mass']*oldhap['Scale'][0]
        oldhap['Scale']=[0.0,False];oldhap['Use']=False
        new=project.add_phase(str(cif_path(args.root.resolve(),cid)),phasename='WO3_'+cid,histograms=[hist],fmthint='CIF')
        hap=new.data['Histograms'][hist.name]
        hap['Scale']=[old_mass/new.data['General']['Mass'],True]
        hap['Size'][0]='isotropic';hap['Size'][1][0]=1.5;hap['Size'][2]=[False,False,False]
        hap['Mustrain'][0]='isotropic';hap['Mustrain'][1][0]=0.;hap['Mustrain'][1][1]=0.;hap['Mustrain'][2]=[False,False,False]
        hap['Pref.Ori.'][0]='MD';hap['Pref.Ori.'][1]=1.;hap['Pref.Ori.'][2]=False;hap['Pref.Ori.'][3]=[0,1,0]
        for atom in new.atoms():atom.uiso=0.02
        for phase in project.phases():
            if phase.name!='WO3_monoclinic':phase.set_HAP_refinements({'Scale':True},[hist])
        hist.set_refinements({'Background':True});new.set_refinements({'Cell':True})
        project.set_Controls('cycles',20);project.refine();project.save(str(output.resolve()))
        row={'id':cid,'Rwp_percent':hist.get_wR(),'cell':new.data['General']['Cell'][1:7],
             'formula':new.data['General']['F000X'],'project':str(output)}
        summary.append(row);print(json.dumps(row,sort_keys=True),flush=True)
    (args.out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')


def parser():
    p=argparse.ArgumentParser()
    p.add_argument('--input',type=Path,default=Path('analysis/cellfinal2.gpx'))
    p.add_argument('--out',type=Path,default=Path('analysis/wo3_trials'))
    p.add_argument('--root',type=Path,default=Path('<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/resources/b001-c06/cif'))
    return p


if __name__=='__main__':main(parser().parse_args())
