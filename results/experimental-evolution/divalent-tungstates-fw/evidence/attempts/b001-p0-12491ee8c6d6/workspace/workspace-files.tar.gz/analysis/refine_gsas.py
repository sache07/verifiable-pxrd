#!/usr/bin/env python3
"""Build and stage a three-phase GSAS-II Rietveld refinement."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.optimize import lsq_linear
from GSASII import GSASIIscriptable as G2


def write_xye(pattern: Path, output: Path) -> None:
    x, y = np.loadtxt(pattern, delimiter=",", skiprows=1).T
    np.savetxt(output, np.column_stack([x, y, np.sqrt(np.maximum(y, 1.0))]), fmt="%.8f %.8f %.8f")


def write_inst(output: Path, zero: float) -> None:
    output.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        f"Zero:{zero};Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def rwp(project: G2.G2Project, hist) -> float:
    value = hist.get_wR()
    return float(value) if value is not None else float("nan")


def summarize(project: G2.G2Project, hist, label: str) -> None:
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
    total = sum(masses)
    fracs = [m / total for m in masses]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    cells = {p.name: [float(v) for v in p.data["General"]["Cell"][1:7]] for p in project.phases()}
    print(
        json.dumps(
            {
                "stage": label,
                "Rwp_percent": rwp(project, hist),
                "fractions": dict(zip([p.name for p in project.phases()], fracs)),
                "zero": float(inst["Zero"][1]),
                "U": float(inst["U"][1]),
                "W": float(inst["W"][1]),
                "X": float(inst["X"][1]),
                "SH_L": float(inst["SH/L"][1]),
                "polarization": float(inst["Polariz."][1]),
                "shift_um": float(sample["Shift"][0]),
                "cells": cells,
            },
            sort_keys=True,
        )
    )


def refine(project: G2.G2Project, hist, label: str) -> None:
    project.set_Controls("cycles", 12)
    project.refine()
    summarize(project, hist, label)


def initialize_linear(project: G2.G2Project, hist, phases) -> None:
    """Fit nonnegative phase scales and a 3-term Chebyshev background."""
    bkg = hist.data["Background"][0]
    bkg[3:] = [0.0, 0.0, 0.0]
    for phase in phases:
        phase.data["Histograms"][hist.name]["Scale"][0] = 1.0e-12
    project.set_Controls("cycles", 0)
    profiles = []
    for selected in phases:
        selected.data["Histograms"][hist.name]["Scale"][0] = 1.0
        project.refine()
        arrays = hist.data["data"][1]
        profiles.append(np.asarray(arrays[3], float) - np.asarray(arrays[4], float))
        selected.data["Histograms"][hist.name]["Scale"][0] = 1.0e-12
    arrays = hist.data["data"][1]
    x = np.asarray(arrays[0], float)
    y = np.asarray(arrays[1], float)
    weights = np.asarray(arrays[2], float)
    lo, hi = map(float, hist.data["Limits"][1])
    use = (x >= lo) & (x <= hi)
    t = 2.0 * (x - lo) / (hi - lo) - 1.0
    basis = np.column_stack([*profiles, np.polynomial.chebyshev.chebvander(t, 2)])
    root_w = np.sqrt(np.maximum(weights, 0.0))
    lower = np.array([0.0] * len(phases) + [0.0, -np.inf, -np.inf])
    upper = np.full(basis.shape[1], np.inf)
    result = lsq_linear(
        basis[use] * root_w[use, None],
        y[use] * root_w[use],
        bounds=(lower, upper),
        max_iter=1000,
        lsmr_tol="auto",
    )
    if not result.success:
        raise RuntimeError("linear initialization failed: " + result.message)
    for phase, value in zip(phases, result.x[: len(phases)]):
        phase.data["Histograms"][hist.name]["Scale"][0] = float(value)
    bkg[3:] = [float(v) for v in result.x[len(phases) :]]
    project.refine()


def build(args: argparse.Namespace) -> None:
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    xye = out / "pattern.xye"
    inst = out / "instrument.instprm"
    write_xye(args.pattern.resolve(), xye)
    write_inst(inst, args.initial_zero)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(out / "working.gpx"))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [float(args.initial_shift), False]
    hist.set_refinements(
        {
            "Limits": [float(args.low), float(args.high)],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 3,
                "coeffs": [800.0, 100.0, 0.0],
                "refine": False,
            },
        }
    )

    model_paths = [args.pbwo4.resolve(), args.pbco3.resolve(), args.wo3.resolve()]
    names = ["PbWO4_scheelite", "PbCO3_cerussite", "WO3_monoclinic"]
    phases = [
        project.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
        for path, name in zip(model_paths, names)
    ]
    project.save()
    bounds = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.5, 1.0),
    }
    for i in range(len(phases)):
        bounds[f"{i}:0:Scale"] = (0.0, 1000.0)
        bounds[f"{i}:0:Size;i"] = (0.04, 1.5)
        bounds[f"{i}:0:Mustrain;i"] = (0.0, 8000.0)
    for variable, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    initial_fractions = np.asarray([0.55, 0.25, 0.20])
    for phase, fraction in zip(phases, initial_fractions):
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"])
        hap["Scale"] = [10000.0 * float(fraction) / mass, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.5
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]

    initialize_linear(project, hist, phases)
    summarize(project, hist, "initial")

    # First fit only linear intensity terms.
    hist.set_refinements({"Background": True})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    refine(project, hist, "scale_background")

    # Peak positions: establish common angular terms before freeing phase cells.
    if args.position_mode in ("zero", "both"):
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    if args.position_mode in ("shift", "both"):
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, hist, "common_position")
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, hist, "positions")

    # Shared instrumental broadening, followed by phase-dependent broadening.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, hist, "instrument_profile")
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.5, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    refine(project, hist, "phase_profile")

    project.save(str(out / "working.gpx"))


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser()
    p.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    p.add_argument("--pbwo4", type=Path, default=Path("analysis/models/pbwo4_start.cif"))
    p.add_argument("--pbco3", type=Path, default=Path("analysis/models/pbco3_standard.cif"))
    p.add_argument("--wo3", type=Path, default=Path("analysis/models/wo3_start.cif"))
    p.add_argument("--out", type=Path, default=Path("analysis/run1"))
    p.add_argument("--low", type=float, default=10.0)
    p.add_argument("--high", type=float, default=100.0)
    p.add_argument("--initial-zero", type=float, default=0.0)
    p.add_argument("--initial-shift", type=float, default=-600.0)
    p.add_argument("--position-mode", choices=["zero", "shift", "both", "none"], default="both")
    return p


if __name__ == "__main__":
    build(parser().parse_args())
