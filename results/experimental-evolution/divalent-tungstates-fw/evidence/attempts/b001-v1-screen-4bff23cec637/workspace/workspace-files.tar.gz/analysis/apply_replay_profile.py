#!/usr/bin/env python3
"""Make fit.csv and reported profile statistics identical to the fresh replay."""

import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
folder = ROOT / "analysis/replay"
replay = json.loads((folder / "replay.json").read_text())
if replay.get("status") != "replayed" or replay.get("profile_review_flags"):
    raise SystemExit("Replay did not pass cleanly: " + repr(replay))
with np.load(folder / "prediction.npz", allow_pickle=False) as z:
    x = z["x"].copy()
    observed = z["observed"].copy()
    calculated = z["predicted"].copy()
    background = z["background"].copy()
difference = observed - calculated
np.savetxt(
    ROOT / "fit.csv",
    np.column_stack([x, observed, calculated, difference, background]),
    delimiter=",",
    header="two_theta,observed,calculated,difference,background",
    comments="",
    fmt="%.15g",
)

result = json.loads((ROOT / "result.json").read_text())
stats = result["fit_statistics"]
weights = 1 / np.maximum(observed, 1)
loss = float(np.sum(weights * difference**2))
denominator = float(np.sum(weights * observed**2))
nobs, nvars = stats["Nobs"], stats["Nvars"]
stats["saved_refinement_Rwp_percent"] = stats["Rwp_percent"]
stats.update(
    Rwp_percent=float(100 * np.sqrt(loss / denominator)),
    Rp_percent=float(100 * np.sum(np.abs(difference)) / np.sum(observed)),
    Rexp_percent=float(100 * np.sqrt((nobs - nvars) / denominator)),
    goodness_of_fit=float(np.sqrt(loss / (nobs - nvars))),
    chi_square=loss,
    reduced_chi_square=float(loss / (nobs - nvars)),
)
result["independent_replay"] = {
    "status": "passed",
    "parameters_optimized": replay["parameters_optimized"],
    "project_unchanged": replay["project_unchanged"],
    "profile_review_flags": replay["profile_review_flags"],
    "project_sha256": replay["project_sha256"],
    "phase_weight_fractions": [p["weight_fraction"] for p in replay["phases"]],
    "fit_csv_sha256": hashlib.sha256((ROOT / "fit.csv").read_bytes()).hexdigest(),
}
(ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(json.dumps({"Rwp_percent": stats["Rwp_percent"], "fit_csv_sha256": result["independent_replay"]["fit_csv_sha256"]}, indent=2))
