#!/usr/bin/env python3
"""Addition and deletion tests from the selected three-phase refinement."""

import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis/three_coords_combined_from_ca/coords0_O.gpx"
OUT = ROOT / "analysis/inventory_tests"
OUT.mkdir(parents=True, exist_ok=True)

ADDITIONS = {
    "add_cao": ROOT / "analysis/candidate_pool/models/cao_1563196.cif",
    "add_ca_w_bronze": ROOT / "analysis/candidate_pool/models/ca_w_bronze_4030741.cif",
    "add_cawo4_fergusonite": ROOT / "analysis/candidate_pool/models/cawo4_fergusonite_1546035.cif",
    "add_wo3_triclinic": ROOT / "analysis/candidate_pool/models/wo3_triclinic_2106293.cif",
}


def refine(project, tag):
    project.set_Controls("cycles", 12)
    history = []
    for attempt in range(1, 4):
        project.refine(printFile=str(OUT / f"{tag}_{attempt}.lst"))
        rv = project.data["Covariance"]["data"].get("Rvals", {})
        history.append(
            {
                "attempt": attempt,
                "Rwp_percent": rv.get("Rwp"),
                "converged": bool(rv.get("converged", False)),
                "max_shift_over_sigma": rv.get("Max shft/sig"),
                "message": rv.get("msg", ""),
            }
        )
        if rv.get("converged", False) and abs(float(rv.get("Max shft/sig", math.inf))) < 1:
            break
    return history


def summary(project, tag, history):
    hist = project.histograms()[0]
    terms = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        use = bool(hap.get("Use", True))
        term = max(0.0, float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])) if use else 0.0
        terms.append(term)
        phases.append({"name": phase.name, "scale": float(hap["Scale"][0]), "use": use})
    total = sum(terms)
    for phase, term in zip(phases, terms):
        phase["weight_fraction"] = term / total if total else None
    rv = project.data["Covariance"]["data"].get("Rvals", {})
    result = {
        "tag": tag,
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rv.get("converged", False)),
        "max_shift_over_sigma": rv.get("Max shft/sig"),
        "message": rv.get("msg", ""),
        "phases": phases,
        "history": history,
        "project": str(Path(project.filename).relative_to(ROOT)),
    }
    (OUT / f"{tag}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(tag, f"Rwp={result['Rwp_percent']:.4f}%", [(p["name"], round(p["weight_fraction"] or 0, 6)) for p in phases])
    return result


def addition(tag, path):
    target = OUT / f"{tag}.gpx"
    shutil.copy2(BASE, target)
    project = G2.G2Project(str(target))
    hist = project.histograms()[0]
    phase = project.add_phase(str(path), phasename=tag, histograms=[hist], fmthint="CIF")
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.1, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    project.set_Controls("parmMin", 0.0, variable=f"{len(project.phases()) - 1}:0:Scale")
    history = refine(project, tag)
    project.save()
    return summary(project, tag, history)


def deletion(index):
    tag = f"delete_phase{index}"
    target = OUT / f"{tag}.gpx"
    shutil.copy2(BASE, target)
    project = G2.G2Project(str(target))
    hist = project.histograms()[0]
    phase = project.phases()[index]
    hap = phase.data["Histograms"][hist.name]
    hap["Use"] = False
    hap["Scale"] = [0.0, False]
    history = refine(project, tag)
    project.save()
    return summary(project, tag, history)


def main():
    G2.SetPrintLevel("warn")
    results = [deletion(i) for i in range(3)]
    results.extend(addition(tag, path) for tag, path in ADDITIONS.items())
    (OUT / "inventory_summary.json").write_text(json.dumps({"base_project": str(BASE.relative_to(ROOT)), "base_Rwp_percent": 4.757833251576511, "tests": results}, indent=2) + "\n")


if __name__ == "__main__":
    main()
