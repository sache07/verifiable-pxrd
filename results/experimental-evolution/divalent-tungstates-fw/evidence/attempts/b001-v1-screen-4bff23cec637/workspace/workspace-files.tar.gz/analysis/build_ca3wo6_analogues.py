#!/usr/bin/env python3
"""Create Ca3WO6 framework analogues by cation substitution in public COD parents."""

import json
import warnings
from pathlib import Path

from pymatgen.io.cif import CifParser, CifWriter

ROOT = Path(__file__).resolve().parents[1]
COD = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/resources/b001-c05/cif")
OUT = ROOT / "analysis/analogue_sources"
OUT.mkdir(parents=True, exist_ok=True)

PARENTS = {
    "ca3wo6_pnma_from_mgpb2_1001661": "1001661",
    "ca3wo6_p21c_from_ca2mg_2013468": "2013468",
    "ca3wo6_p21c_from_sr2mn_1532958": "1532958",
    "ca3wo6_p21c_from_sr2fe_1531102": "1531102",
    "ca3wo6_tetragonal_from_ba2ca_1529016": "1529016",
    "ca3wo6_cubic_from_ba2fe_1531103": "1531103",
}


def cod_path(ident):
    return COD / ident[0] / ident[1:3] / ident[3:5] / f"{ident}.cif"


records = []
for name, ident in PARENTS.items():
    source = cod_path(ident)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        structure = CifParser(
            source, occupancy_tolerance=1.0, site_tolerance=1e-5, frac_tolerance=0
        ).parse_structures(primitive=False, on_error="raise")[0]
    parent_formula = structure.composition.reduced_formula
    substitutions = {}
    for index, site in enumerate(list(structure)):
        mapped_occupancy = 0.0
        for element, occupancy in site.species.items():
            if element.symbol in {"W", "O"}:
                continue
            substitutions[element.symbol] = "Ca"
            mapped_occupancy += float(occupancy)
        if mapped_occupancy:
            structure.replace(index, {"Ca": mapped_occupancy})
    structure.remove_oxidation_states()
    target = OUT / f"{name}.cif"
    target.write_text(str(CifWriter(structure, symprec=0.001, significant_figures=10)) + "\n")
    records.append(
        {
            "id": name,
            "parent_cod_id": ident,
            "parent_path": str(source),
            "parent_formula": parent_formula,
            "product_formula": structure.composition.reduced_formula,
            "substitutions": substitutions,
            "transformation": "All occupied non-W, non-O cation species mapped onto Ca while preserving distinct parent sites, fractional coordinates, occupancies, symmetry, and parent lattice as the refinement start.",
            "cif_path": str(target.relative_to(ROOT)),
        }
    )

(OUT / "provenance.json").write_text(json.dumps({"records": records}, indent=2) + "\n")
for record in records:
    print(record["id"], record["parent_formula"], "->", record["product_formula"])
