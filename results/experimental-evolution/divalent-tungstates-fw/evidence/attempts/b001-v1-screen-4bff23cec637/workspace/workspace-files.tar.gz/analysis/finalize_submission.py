#!/usr/bin/env python3
"""Export a self-consistent submission from the selected GSAS-II project."""

import json
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis/three_coords_combined_from_ca/coords0_O.gpx"
FINAL = ROOT / "final.gpx"
GSAS_PYTHON = Path("<HOME>/.local/share/characterizagent/backends/gsas2/venv/bin/python")


# Copy first so every export and scalar below is generated from final.gpx itself.
shutil.copy2(SOURCE, FINAL)

worker = ROOT / "analysis/export_final_worker.py"
if not worker.exists():
    raise SystemExit(f"Missing GSAS export worker: {worker}")
subprocess.run([str(GSAS_PYTHON), str(worker), str(FINAL), str(ROOT)], check=True)

sys.path.insert(0, str(ROOT / "learned/divalent-tungstates/scorer/src"))
from structure_metrics import load_structure, physical_screen  # noqa: E402

result_path = ROOT / "result.json"
result = json.loads(result_path.read_text())
audits = []
for phase in result["phases"]:
    audit = physical_screen(load_structure(ROOT / phase["cif_path"]))
    phase["physical_screen"] = audit
    audits.append(audit["status"])
if any(status != "pass" for status in audits):
    raise SystemExit("Final exported CIF failed the supplied physical screen: " + repr(audits))
result["physical_screen_status"] = "pass"
result_path.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

f = result["fit_statistics"]
p = result["phases"]
report = f"""# Powder XRD phase analysis

## Result

The crystalline model contains three Ca–W–O phases. Fractions are normalized over those modeled crystalline phases:

| Phase | Structure model | Weight fraction |
|---|---|---:|
| Scheelite CaWO4 | I4_1/a, COD 7219229 parent | {100*p[0]['weight_fraction']:.2f}% |
| Monoclinic WO3 | P2_1/c, COD 2311041 parent | {100*p[1]['weight_fraction']:.2f}% |
| Ca3WO6 | P2_1/c ordered-perovskite analogue derived from Sr2MnWO6 (COD 1532958; Sr and Mn mapped to distinct Ca sites) | {100*p[2]['weight_fraction']:.2f}% |

The final whole-pattern fit has Rwp = {f['Rwp_percent']:.3f}%, Rp = {f['Rp_percent']:.3f}%, Rexp = {f['Rexp_percent']:.3f}%, and goodness of fit = {f['goodness_of_fit']:.3f}. All three submitted CIFs pass the supplied geometry/occupancy screen.

## Evidence and model selection

The dominant scheelite family includes 18.50, 28.57, 31.32, 34.03 and 46.96 degrees 2theta. A second family at 23.02/23.45/24.27, 26.51, 28.89 and 33.15 degrees identifies monoclinic WO3. With those two phases fitted, a coherent residual family remained at about 18.76, 19.35, 22.04, 30.65, 31.45, 32.11, 36.54/37.44, 45.14, 50.84 and 56.85 degrees. Ordered A2BWO6 frameworks were therefore tested after mapping all non-W cation sites to Ca. The low-symmetry Ca3WO6 model accounts for that full family; deleting Ca3WO6 raises Rwp from {f['Rwp_percent']:.2f}% to 10.97%. Deleting WO3 or CaWO4 raises it to 15.57% or 47.12%, respectively.

All serious CIF candidates were normalized before refinement and screened physically. Fixed-coordinate comparisons selected scheelite over high-pressure fergusonite CaWO4 (about 13.5% versus 46.3% Rwp in the two-phase comparison). For WO3, monoclinic and triclinic passing sources were nearly tied; the selected higher-symmetry room-temperature neutron model was preferred. A nominally slightly better old monoclinic source was rejected because the supplied screen flags 1.575 A O–O contacts. For Ca3WO6, the selected P2_1/c Sr2MnWO6-derived parent gave 9.23% Rwp in the common fixed-coordinate three-phase test, compared with 9.26% for the Sr2Fe parent, 9.35% for Pnma, 12.18% for the high-symmetry control, and zero support for the tetragonal control.

The retained nuisance terms are a one-parameter Suortti roughness correction, [001] March–Dollase texture and isotropic size broadening for WO3, and a shift-only specimen-displacement term. Each survived 6/8/10-term background restarts. Simultaneous zero plus displacement (>99.8% correlation), refined U or SH/L terms, simultaneous size plus strain, a second roughness parameter, and refined polarization were rejected as bounded, redundant, or strongly correlated. CaO and triclinic-WO3 additions refined to zero; Ca–W bronze and fergusonite additions stayed below 0.1 wt% with negligible fit change.

Coordinates were refined last and selectively. Only the scheelite O site and the analogue-derived Ca site in Ca3WO6 were retained; both improvements reproduced across background branches and the resulting structures pass. WO3 coordinates remain at the published parent because their improvements were weak/unstable. Unrestrained Ca3WO6 oxygen refinement produced impossible 0.50–0.60 A contacts and was rejected; those O sites remain at the defensible parent framework.

## Uncertainty

Formal covariance-only fraction standard uncertainties are {100*p[0]['formal_weight_fraction_esd']:.2f}, {100*p[1]['formal_weight_fraction_esd']:.2f}, and {100*p[2]['formal_weight_fraction_esd']:.2f} percentage points, but they exclude source/model systematics. The 6-, 8- and 10-background branches changed each fraction by less than 0.03 percentage point. A conservative interpretation is about +/-1 percentage point absolute for each fraction. Ca3WO6 is securely required as a phase, but its exact light-atom coordinates are not reliably determined by this Cu X-ray pattern; the submitted oxygen sublattice is therefore the physically passing parent analogue rather than an unstable apparent optimum.
"""
(ROOT / "report.md").write_text(report)
print(json.dumps({"final_project": str(FINAL), "fractions": [x["weight_fraction"] for x in p], "Rwp_percent": f["Rwp_percent"], "physical": audits}, indent=2))
