#!/usr/bin/env python3
"""Run the supplied scorer physical screen on every normalized candidate."""

import json
import sys
from pathlib import Path

from pymatgen.core import Structure

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "learned/divalent-tungstates/scorer/src"))
from structure_metrics import physical_screen  # noqa: E402


pool = ROOT / "analysis/candidate_pool"
catalog = json.loads((pool / "catalog.json").read_text())
rows = []
for record in catalog["records"]:
    path = pool / record["model_path"]
    structure = Structure.from_file(path, primitive=False)
    audit = physical_screen(structure)
    rows.append(
        {
            "id": record["id"],
            "path": str(path.relative_to(ROOT)),
            "formula": structure.composition.reduced_formula,
            "space_group": structure.get_space_group_info(symprec=0.01)[0],
            "cell": [*structure.lattice.abc, *structure.lattice.angles],
            "density_g_cm3": float(structure.density),
            "physical_screen": audit,
        }
    )

out = {
    "screen_source": "learned/divalent-tungstates/scorer/src/structure_metrics.py",
    "normalization_catalog": str((pool / "catalog.json").relative_to(ROOT)),
    "candidates": rows,
}
(ROOT / "analysis/physical_screen.json").write_text(json.dumps(out, indent=2) + "\n")
for row in rows:
    print(f"{row['id']:35s} {row['formula']:12s} {row['space_group']:10s} {row['physical_screen']['status']}")
