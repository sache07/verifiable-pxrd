#!/usr/bin/env python3
"""GSAS-II-environment worker used by finalize_submission.py."""

import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

gpx = Path(sys.argv[1]).resolve()
root = Path(sys.argv[2]).resolve()
project = G2.G2Project(str(gpx))
histograms = project.histograms()
if len(histograms) != 1:
    raise RuntimeError("Final project must contain exactly one powder histogram")
hist = histograms[0]
phases = project.phases()
if len(phases) != 3:
    raise RuntimeError("Final project must contain exactly three phases")

names = [
    ("Scheelite CaWO4", "phase_CaWO4_scheelite.cif", "published", "COD 7219229"),
    ("Monoclinic WO3", "phase_WO3_monoclinic.cif", "published", "COD 2311041"),
    (
        "Ca3WO6 ordered-perovskite analogue",
        "phase_Ca3WO6_P21c.cif",
        "analogue_derived",
        "COD 1532958 Sr2MnWO6 parent; Sr and Mn mapped to distinct Ca sites",
    ),
]

terms = []
for phase, (_, filename, _, _) in zip(phases, names):
    hap = phase.data["Histograms"][hist.name]
    if not hap.get("Use", True) or float(hap["Scale"][0]) <= 0:
        raise RuntimeError(f"Nonpositive or unused final phase: {phase.name}")
    phase.export_CIF(str(root / filename))
    terms.append(float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]))
terms = np.asarray(terms)
fractions = terms / terms.sum()

cov = project.data["Covariance"]["data"]
vary = [str(v) for v in cov["varyList"]]
matrix = np.asarray(cov["covMatrix"], dtype=float)
scale_indices = [vary.index(f"{i}:0:Scale") for i in range(3)]
scales = np.asarray([float(phase.data["Histograms"][hist.name]["Scale"][0]) for phase in phases])
masses = np.asarray([float(phase.data["General"]["Mass"]) for phase in phases])
total = float(np.sum(scales * masses))
jac = np.zeros((3, 3))
for i in range(3):
    for j in range(3):
        jac[i, j] = masses[i] * ((1.0 if i == j else 0.0) * total - scales[i] * masses[j]) / total**2
fraction_cov = jac @ matrix[np.ix_(scale_indices, scale_indices)] @ jac.T
fraction_esd = np.sqrt(np.maximum(np.diag(fraction_cov), 0.0))

arrays = hist.data["data"][1]
x, observed, weights, calculated, background = [np.asarray(v, dtype=float) for v in arrays[:5]]
difference = observed - calculated
np.savetxt(
    root / "fit.csv",
    np.column_stack([x, observed, calculated, difference, background]),
    delimiter=",",
    header="two_theta,observed,calculated,difference,background",
    comments="",
    fmt="%.10g",
)
denominator = float(np.sum(weights * observed**2))
loss = float(np.sum(weights * difference**2))
rp = float(100 * np.sum(np.abs(difference)) / np.sum(observed))
rwp = float(100 * np.sqrt(loss / denominator))
rvals = cov["Rvals"]
nobs, nvars = int(rvals["Nobs"]), int(rvals["Nvars"])
rexp = float(100 * np.sqrt((nobs - nvars) / denominator))

phase_rows = []
for index, (phase, (name, filename, basis, source), fraction, esd) in enumerate(
    zip(phases, names, fractions, fraction_esd)
):
    cell = phase.data["General"]["Cell"]
    phase_rows.append(
        {
            "name": name,
            "identification": phase.name,
            "cif_path": filename,
            "weight_fraction": float(fraction),
            "formal_weight_fraction_esd": float(esd),
            "model_basis": basis,
            "source": source,
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cell": {
                "a_angstrom": float(cell[1]),
                "b_angstrom": float(cell[2]),
                "c_angstrom": float(cell[3]),
                "alpha_deg": float(cell[4]),
                "beta_deg": float(cell[5]),
                "gamma_deg": float(cell[6]),
                "volume_angstrom3": float(cell[7]),
            },
        }
    )

result = {
    "phases": phase_rows,
    "fit_statistics": {
        "Rwp_percent": rwp,
        "Rp_percent": rp,
        "Rexp_percent": rexp,
        "goodness_of_fit": float(np.sqrt(loss / (nobs - nvars))),
        "chi_square": loss,
        "reduced_chi_square": float(loss / (nobs - nvars)),
        "Nobs": nobs,
        "Nvars": nvars,
    },
    "refinement_histogram": hist.name,
    "project_path": "final.gpx",
    "fit_path": "fit.csv",
    "fraction_basis": "Normalized over the three modeled crystalline phases",
    "calibration_and_specimen": {
        "zero_deg": float(hist.data["Instrument Parameters"][0]["Zero"][1]),
        "specimen_shift_um": float(hist.data["Sample Parameters"]["Shift"][0]),
        "surface_roughness_A": float(hist.data["Sample Parameters"]["SurfRoughA"][0]),
        "surface_roughness_B": float(hist.data["Sample Parameters"]["SurfRoughB"][0]),
    },
}
(root / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
