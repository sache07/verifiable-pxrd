#!/usr/bin/env python3
"""One-effect-at-a-time GSAS-II refinement experiments from the stable base."""

import json
import math
import os
import shutil
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parents[1]
BASE = Path(os.environ.get("PXRD_EXPERIMENT_BASE", ROOT / "analysis/comparisons/restart_scheelite_plus_mono.gpx")).resolve()
OUT = Path(os.environ.get("PXRD_EXPERIMENT_OUT", ROOT / "analysis/effects_restart")).resolve()
OUT.mkdir(parents=True, exist_ok=True)


def set_bound(project, name, lower=None, upper=None):
    if lower is not None:
        project.set_Controls("parmMin", float(lower), variable=name)
    if upper is not None:
        project.set_Controls("parmMax", float(upper), variable=name)


def configure(tag, project):
    hist = project.histograms()[0]
    phases = project.phases()
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    if tag == "shift_only":
        inst["Zero"][1:] = [0.0, False]
        sample["Shift"] = [0.0, True]
        set_bound(project, ":0:Shift", -2000.0, 2000.0)
    elif tag == "zero_plus_shift":
        sample["Shift"] = [0.0, True]
        set_bound(project, ":0:Shift", -2000.0, 2000.0)
    elif tag == "instrument_U":
        hist.set_refinements({"Instrument Parameters": ["U"]})
        set_bound(project, ":0:U", 0.0, 1000.0)
    elif tag == "instrument_SHL":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        set_bound(project, ":0:SH/L", 0.0001, 1.0)
    elif tag == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        set_bound(project, ":0:Polariz.", 0.0, 1.0)
    elif tag in {"background6", "background10"}:
        n = int(tag.replace("background", ""))
        old = list(hist.data["Background"][0][3:])
        coeffs = (old + [0.0] * n)[:n]
        hist.set_refinements(
            {"Background": {"type": "chebyschev-1", "no. coeffs": n, "coeffs": coeffs, "refine": True}}
        )
    elif tag == "roughness":
        sample["SurfRoughA"] = [0.1, True]
        sample["SurfRoughB"] = [0.1, True]
        set_bound(project, ":0:SurfRoughA", 0.0001, 2.0)
        set_bound(project, ":0:SurfRoughB", 0.0001, 2.0)
    elif tag == "roughB":
        # Stable one-parameter limiting form of the Suortti correction.
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.05, True]
        set_bound(project, ":0:SurfRoughB", 0.0, 2.0)
    elif tag.startswith("size"):
        indexes = range(len(phases)) if tag == "size_both" else [int(tag[-1])]
        for i in indexes:
            phases[i].set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}
            )
            set_bound(project, f"{i}:0:Size;i", 0.005, 100.0)
    elif tag.startswith("strain"):
        indexes = range(len(phases)) if tag == "strain_both" else [int(tag[-1])]
        for i in indexes:
            hap = phases[i].data["Histograms"][hist.name]
            hap["Mustrain"][1][0] = 1000.0
            phases[i].set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
            set_bound(project, f"{i}:0:Mustrain;i", 0.0, 50000.0)
    elif tag.startswith("texture"):
        # texture{phase}_{h}{k}{l}, e.g. texture0_001
        left, axis_text = tag.split("_")
        i = int(left[-1])
        axis = [int(v) for v in axis_text]
        hap = phases[i].data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = axis
        phases[i].set_HAP_refinements({"Pref.Ori.": True})
        set_bound(project, f"{i}:0:MD", 0.2, 5.0)
    elif tag.startswith("coords"):
        # coords{phase}_{species}; species is O, W, or all.
        left, species = tag.split("_")
        i = int(left[-1])
        selected = {
            atom.label: "X"
            for atom in phases[i].atoms()
            if species == "all" or atom.label.startswith(species)
        }
        if not selected:
            raise ValueError(f"no atoms selected for {tag}")
        phases[i].set_refinements({"Atoms": selected})
    else:
        raise ValueError(f"unknown experiment {tag}")


def correlation_summary(cov):
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    names = [str(v) for v in cov.get("varyList", [])]
    if matrix.ndim != 2 or matrix.shape[0] < 2:
        return None
    sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    denom = np.outer(sigma, sigma)
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
    np.fill_diagonal(corr, 0.0)
    i, j = np.unravel_index(np.nanargmax(np.abs(corr)), corr.shape)
    return {"absolute": float(abs(corr[i, j])), "signed": float(corr[i, j]), "pair": [names[i], names[j]]}


def run(tag):
    target = OUT / f"{tag}.gpx"
    shutil.copy2(BASE, target)
    project = G2.G2Project(str(target))
    configure(tag, project)
    project.set_Controls("cycles", 12)
    history = []
    for attempt in range(1, 4):
        project.refine(printFile=str(OUT / f"{tag}_{attempt}.lst"))
        rv = project.data["Covariance"]["data"].get("Rvals", {})
        history.append(
            {
                "attempt": attempt,
                "Rwp_percent": rv.get("Rwp"),
                "GOF": rv.get("GOF"),
                "max_shift_over_sigma": rv.get("Max shft/sig"),
                "converged": bool(rv.get("converged", False)),
                "message": rv.get("msg", ""),
            }
        )
        if rv.get("converged", False) and abs(float(rv.get("Max shft/sig", math.inf))) < 1.0:
            break
    project.save()
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    cov = project.data["Covariance"]["data"]
    rv = cov.get("Rvals", {})
    arrays = hist.data["data"][1]
    result = {
        "tag": tag,
        "Rwp_percent": float(hist.get_wR()),
        "GOF": rv.get("GOF"),
        "converged": bool(rv.get("converged", False)),
        "max_shift_over_sigma": rv.get("Max shft/sig"),
        "message": rv.get("msg", ""),
        "strongest_correlation": correlation_summary(cov),
        "instrument": {k: float(inst[k][1]) for k in ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]},
        "sample": {k: float(sample[k][0]) for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "background_min": float(np.min(arrays[4])),
        "phase_parameters": [],
        "history": history,
        "project": str(target.relative_to(ROOT)),
    }
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        term = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        masses.append(term)
        result["phase_parameters"].append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "size_um": float(hap["Size"][1][0]),
                "microstrain_ppm": float(hap["Mustrain"][1][0]),
                "MD_ratio": float(hap["Pref.Ori."][1]),
                "MD_axis": list(hap["Pref.Ori."][3]),
            }
        )
    total = sum(masses)
    for row, value in zip(result["phase_parameters"], masses):
        row["weight_fraction"] = value / total
    (OUT / f"{tag}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        f"{tag:22s} Rwp={result['Rwp_percent']:8.4f}% "
        f"conv={result['converged']} maxcorr={result['strongest_correlation']}"
    )
    return result


def main():
    G2.SetPrintLevel("warn")
    tags = sys.argv[1:]
    if not tags:
        raise SystemExit("supply one or more experiment tags")
    results = [run(tag) for tag in tags]
    combined = OUT / "effect_summary.json"
    old = {}
    if combined.exists():
        old = {r["tag"]: r for r in json.loads(combined.read_text())["experiments"]}
    old.update({r["tag"]: r for r in results})
    base_project = G2.G2Project(str(BASE))
    base_rwp = float(base_project.histograms()[0].get_wR())
    combined.write_text(json.dumps({"base_project": str(BASE), "base_Rwp_percent": base_rwp, "experiments": list(old.values())}, indent=2) + "\n")


if __name__ == "__main__":
    main()
