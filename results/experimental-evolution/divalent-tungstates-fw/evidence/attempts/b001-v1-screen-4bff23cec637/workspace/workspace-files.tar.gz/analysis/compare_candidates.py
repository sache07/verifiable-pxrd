#!/usr/bin/env python3
"""Compare normalized phase candidates with one fixed-coordinate GSAS-II recipe.

Run with the GSAS-II Python interpreter. The model intentionally has low
flexibility: eight smooth-background coefficients, phase scales, one common
zero, phase cells, and common W/X profile terms. Atomic coordinates, ADPs,
size, strain, texture, roughness, and displacement remain fixed.
"""

import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parents[1]
POOL = ROOT / "analysis/candidate_pool/models"
ANALOGUE_POOL = ROOT / "analysis/analogue_pool/models"
OUT = ROOT / "analysis/comparisons"
OUT.mkdir(parents=True, exist_ok=True)

SCHEELITE = "cawo4_scheelite_7219229"
FERGUSONITE = "cawo4_fergusonite_1546035"
MONO = "wo3_monoclinic_2311041"

MODELS = {
    "scheelite_only": [SCHEELITE],
    "scheelite_plus_cao": [SCHEELITE, "cao_1563196"],
    "scheelite_plus_bronze": [SCHEELITE, "ca_w_bronze_4030741"],
    "fergusonite_plus_mono": [FERGUSONITE, MONO],
    "scheelite_plus_hex": [SCHEELITE, "wo3_hex_1004057"],
    "scheelite_plus_tet130": [SCHEELITE, "wo3_tet130_1521532"],
    "scheelite_plus_tet129": [SCHEELITE, "wo3_tet129_1521533"],
    "scheelite_plus_mono_review": [SCHEELITE, "wo3_monoclinic_review_1528915"],
    "scheelite_plus_mono_small": [SCHEELITE, "wo3_monoclinic_small_1563541"],
    "scheelite_plus_mono": [SCHEELITE, MONO],
    "scheelite_plus_triclinic": [SCHEELITE, "wo3_triclinic_2106293"],
    "scheelite_plus_orthorhombic": [SCHEELITE, "wo3_orthorhombic_2107312"],
    "restart_scheelite_only": [SCHEELITE],
    "restart_scheelite_plus_mono_review": [SCHEELITE, "wo3_monoclinic_review_1528915"],
    "restart_scheelite_plus_mono": [SCHEELITE, MONO],
    "restart_scheelite_plus_triclinic": [SCHEELITE, "wo3_triclinic_2106293"],
    "restart_scheelite_plus_orthorhombic": [SCHEELITE, "wo3_orthorhombic_2107312"],
    "three_phase_pnma": [SCHEELITE, MONO, "ca3wo6_pnma_from_mgpb2_1001661"],
    "three_phase_p21c_ca2mg": [SCHEELITE, MONO, "ca3wo6_p21c_from_ca2mg_2013468"],
    "three_phase_p21c_sr2mn": [SCHEELITE, MONO, "ca3wo6_p21c_from_sr2mn_1532958"],
    "three_phase_p21c_sr2fe": [SCHEELITE, MONO, "ca3wo6_p21c_from_sr2fe_1531102"],
    "three_phase_tetragonal": [SCHEELITE, MONO, "ca3wo6_tetragonal_from_ba2ca_1529016"],
    "three_phase_cubic": [SCHEELITE, MONO, "ca3wo6_cubic_from_ba2fe_1531103"],
}


def rvals(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine_stage(project, label, history, repeats=3):
    for attempt in range(1, repeats + 1):
        project.refine(printFile=str(OUT / f"{Path(project.filename).stem}_{label}_{attempt}.lst"))
        rv = dict(rvals(project))
        history.append(
            {
                "stage": label,
                "attempt": attempt,
                "Rwp_percent": rv.get("Rwp"),
                "GOF": rv.get("GOF"),
                "max_shift_over_sigma": rv.get("Max shft/sig"),
                "converged": bool(rv.get("converged", False)),
                "message": rv.get("msg", ""),
            }
        )
        if rv.get("converged", False) and abs(float(rv.get("Max shft/sig", math.inf))) < 1.0:
            break


def fit_one(tag, names):
    gpx = OUT / f"{tag}.gpx"
    if gpx.exists():
        gpx.unlink()
    project = G2.G2Project(newgpx=str(gpx))
    for name in names:
        model_path = POOL / f"{name}.cif"
        if not model_path.exists():
            model_path = ANALOGUE_POOL / f"{name}.cif"
        project.add_phase(
            str(model_path),
            phasename=name,
            histograms=[],
            fmthint="CIF",
        )
    hist = project.add_powder_histogram(
        str(ROOT / "analysis/pattern.xye"),
        str(ROOT / "analysis/lab_cuka.instprm"),
        phases="all",
        fmthint="xye",
    )
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [1000.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": True,
            }
        }
    )
    for index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10.0 if index < 2 else 1.0, True]
        # Explicitly neutralize GSAS-II's nonzero default phase broadening.
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1000.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        project.set_Controls("parmMin", 0.0, variable=f"{index}:0:Scale")
    project.set_Controls("cycles", 12)
    history = []
    refine_stage(project, "scales_background", history)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_stage(project, "zero", history)
    inactive = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if float(hap["Scale"][0]) <= 1.0e-6:
            hap["Scale"] = [0.0, False]
            inactive.append(phase.name)
        else:
            phase.set_refinements({"Cell": True})
    refine_stage(project, "cells", history)
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine_stage(project, "common_profile_WX", history)
    project.save()

    arrays = hist.data["data"][1]
    inst = hist.data["Instrument Parameters"][0]
    phase_rows = []
    mass_terms = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        scale = float(hap["Scale"][0])
        mass = float(phase.data["General"]["Mass"])
        mass_terms.append(max(0.0, scale * mass))
        phase_rows.append(
            {
                "name": phase.name,
                "scale": scale,
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:7]],
                "cell_volume": float(phase.data["General"]["Cell"][7]),
            }
        )
    total = sum(mass_terms)
    for row, term in zip(phase_rows, mass_terms):
        row["weight_fraction"] = term / total if total > 0 else None
    rv = dict(rvals(project))
    result = {
        "tag": tag,
        "phases": phase_rows,
        "fixed_atomic_coordinates": True,
        "Rwp_percent": float(hist.get_wR()),
        "GOF": rv.get("GOF"),
        "chi_square": rv.get("chisq"),
        "Nobs": rv.get("Nobs"),
        "Nvars": rv.get("Nvars"),
        "converged": bool(rv.get("converged", False)),
        "max_shift_over_sigma": rv.get("Max shft/sig"),
        "inactive_at_nonnegative_scale_boundary": inactive,
        "correlation_message": rv.get("msg", ""),
        "instrument": {key: float(inst[key][1]) for key in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]},
        "background_min": float(np.min(arrays[4])),
        "background_max": float(np.max(arrays[4])),
        "history": history,
        "project": str(gpx.relative_to(ROOT)),
    }
    (OUT / f"{tag}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(f"{tag:36s} Rwp={result['Rwp_percent']:8.3f}% conv={result['converged']} phases=" + ", ".join(f"{p['name']}:{p['weight_fraction']:.4f}" for p in phase_rows))
    return result


def main():
    G2.SetPrintLevel("warn")
    selected = sys.argv[1:] or list(MODELS)
    unknown = [name for name in selected if name not in MODELS]
    if unknown:
        raise SystemExit("Unknown comparison tags: " + ", ".join(unknown))
    results = [fit_one(tag, MODELS[tag]) for tag in selected]
    combined_path = OUT / "candidate_comparison.json"
    previous = {}
    if combined_path.exists():
        previous = {row["tag"]: row for row in json.loads(combined_path.read_text())["comparisons"]}
    previous.update({row["tag"]: row for row in results})
    combined_path.write_text(json.dumps({"comparisons": list(previous.values())}, indent=2) + "\n")


if __name__ == "__main__":
    main()
