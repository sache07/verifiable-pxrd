#!/usr/bin/env python3
"""Targeted structural refinement with physically small coordinate bounds."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(project: G2.G2Project) -> float:
    _, y, w, yc = [
        np.asarray(v, float) for v in project.histogram(0).data["data"][1][:4]
    ]
    return 100.0 * math.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y**2))


def clear_all(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    hist.clear_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements(
            {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
        )
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "Extinction": True,
            }
        )
    controls = project.data["Controls"]["data"]
    controls.get("parmFrozen", {}).setdefault("FrozenList", [])
    controls["parmFrozen"]["FrozenList"] = []


def recalc(project: G2.G2Project) -> None:
    project.set_Controls("cycles", 0)
    project.refine()


def report(project: G2.G2Project, label: str) -> None:
    cov = project.data.get("Covariance", {}).get("data", {})
    row = {
        "label": label,
        "rwp_percent": rwp(project),
        "vary_list": [str(v) for v in cov.get("varyList", [])],
        "values": np.asarray(cov.get("variables", []), float).tolist(),
        "sigmas": np.asarray(cov.get("sig", []), float).tolist(),
        "coordinates": {
            phase.name: {atom.label: atom.coordinates for atom in phase.atoms()}
            for phase in project.phases()
        },
    }
    print(json.dumps(row), flush=True)


def save(project: G2.G2Project, outdir: Path, index: int, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, outdir / f"stage-{index:02d}-{label}.gpx")


def refine_selected_atoms(
    project: G2.G2Project,
    phase_index: int,
    atom_indices: list[int],
    half_widths: tuple[float, float, float],
) -> None:
    phase = project.phase(phase_index)
    for atom_index in atom_indices:
        atom = phase.atoms()[atom_index]
        atom.refinement_flags = "X"
        for axis, value, width in zip(("x", "y", "z"), atom.coordinates, half_widths):
            variable = f"{phase_index}::dA{axis}:{atom_index}"
            project.set_Controls("parmMin", value - width, variable=variable)
            project.set_Controls("parmMax", value + width, variable=variable)
    project.set_Controls("cycles", 8)
    project.refine()
    phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
    project.data["Controls"]["data"]["parmFrozen"]["FrozenList"] = []
    recalc(project)


def run(base: Path, outdir: Path) -> None:
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(base), newgpx=str(outdir / "targeted.gpx"))
    clear_all(project)
    recalc(project)
    report(project, "base")
    save(project, outdir, 0, "base")

    # Tungsten dominates the WO3 structure factor. The +/-0.008 fractional
    # window corresponds to roughly 0.06 A and is close to the generator's
    # stated coordinate-mismatch scale without freeing 18 weak O parameters.
    wo3 = project.phase(1)
    w_indices = [i for i, atom in enumerate(wo3.atoms()) if atom.element == "W"]
    refine_selected_atoms(project, 1, w_indices, (0.008, 0.008, 0.008))
    report(project, "WO3_tungsten")
    save(project, outdir, 1, "wo3-tungsten")

    # Calcite has a single positional degree of freedom (oxygen x).
    refine_selected_atoms(project, 3, [2], (0.010, 0.010, 0.010))
    report(project, "calcite_oxygen")
    save(project, outdir, 2, "calcite-oxygen")

    # Refit only the linear terms after changing structure factors.
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    project.histogram(0).set_refinements({"Background": {"refine": True}})
    project.set_Controls("cycles", 5)
    project.refine()
    for phase in project.phases():
        phase.clear_HAP_refinements({"Scale": True})
    project.histogram(0).clear_refinements({"Background": True})
    project.data["Controls"]["data"]["parmFrozen"]["FrozenList"] = []
    recalc(project)
    report(project, "linear_cleanup")
    save(project, outdir, 3, "linear-cleanup")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    run(args.base, args.outdir)
