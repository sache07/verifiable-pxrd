#!/usr/bin/env python3
"""Screen the generator-supported March-Dollase axes against a base GPX."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def rwp(project: G2.G2Project) -> float:
    a = [np.asarray(v, float) for v in project.histogram(0).data["data"][1][:4]]
    _, y, w, yc = a
    return 100.0 * math.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y**2))


def clear_nuisance_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    hist.clear_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": []})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
        phase.clear_HAP_refinements({"Scale": True})
    controls = project.data["Controls"]["data"]
    controls.get("parmFrozen", {}).setdefault("FrozenList", [])
    controls["parmFrozen"]["FrozenList"] = []
    project.set_Controls("cycles", 6)


def run(base: Path, outdir: Path, phase_indices: list[int]) -> None:
    G2.SetPrintLevel("error")
    outdir.mkdir(parents=True, exist_ok=True)
    results = []
    for pidx in phase_indices:
        for axis in AXES:
            tag = f"p{pidx}-" + "".join(map(str, axis))
            output = outdir / f"{tag}.gpx"
            project = G2.G2Project(str(base), newgpx=str(output))
            clear_nuisance_flags(project)
            phase = project.phase(pidx)
            hap = phase.data["Histograms"][project.histogram(0).name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(axis)
            project.set_Controls("parmMin", 0.7, variable=f"{pidx}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{pidx}:0:MD")
            project.refine()
            project.refine()
            value = phase.data["Histograms"][project.histogram(0).name]["Pref.Ori."][1]
            row = {
                "phase_index": pidx,
                "phase": phase.name,
                "axis": list(axis),
                "ratio": value,
                "rwp_percent": rwp(project),
                "gpx": str(output),
            }
            results.append(row)
            print(json.dumps(row), flush=True)
            project.save()
    (outdir / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--phase-indices", default="0,1,2,3")
    args = parser.parse_args()
    run(args.base, args.outdir, [int(v) for v in args.phase_indices.split(",")])
