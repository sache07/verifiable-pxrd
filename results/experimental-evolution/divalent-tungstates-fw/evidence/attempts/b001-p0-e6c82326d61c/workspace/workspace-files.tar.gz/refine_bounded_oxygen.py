#!/usr/bin/env python3
"""Refine weak oxygen coordinates and project them onto stated RMS bounds."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


PARENTS = {
    0: {2: np.array([0.15202, 0.01135, 0.20864])},
    1: {
        0: np.array([0.714, 0.487, 0.721]),
        1: np.array([0.225, 0.474, 0.007]),
        3: np.array([0.716, 0.043, 0.708]),
        4: np.array([0.998, 0.262, 0.712]),
        5: np.array([0.206, 0.042, 0.995]),
        7: np.array([0.519, 0.259, 0.789]),
    },
    3: {2: np.array([0.2553, 0.0, 0.25])},
}


def rwp(project: G2.G2Project) -> float:
    _, y, w, yc = [
        np.asarray(v, float) for v in project.histogram(0).data["data"][1][:4]
    ]
    return 100.0 * math.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y**2))


def lattice_matrix(cell: list[float]) -> np.ndarray:
    a, b, c, alpha, beta, gamma = cell
    al, be, ga = np.deg2rad([alpha, beta, gamma])
    avec = np.array([a, 0.0, 0.0])
    bvec = np.array([b * np.cos(ga), b * np.sin(ga), 0.0])
    cx = c * np.cos(be)
    cy = c * (np.cos(al) - np.cos(be) * np.cos(ga)) / np.sin(ga)
    cz = math.sqrt(max(0.0, c * c - cx * cx - cy * cy))
    return np.vstack([avec, bvec, [cx, cy, cz]])


def clear_all(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    hist.clear_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements(
            {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
        )
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    project.data["Controls"]["data"]["parmFrozen"]["FrozenList"] = []


def recalc(project: G2.G2Project) -> None:
    project.data["Controls"]["data"]["parmFrozen"]["FrozenList"] = []
    project.set_Controls("cycles", 0)
    project.refine()


def rms_displacement(project: G2.G2Project, pidx: int) -> float:
    phase = project.phase(pidx)
    matrix = lattice_matrix(phase.data["General"]["Cell"][1:7])
    deltas = []
    for aidx, parent in PARENTS[pidx].items():
        delta = np.asarray(phase.atoms()[aidx].coordinates) - parent
        delta -= np.rint(delta)
        deltas.append(delta @ matrix)
    return float(np.sqrt(np.mean(np.sum(np.square(deltas), axis=1))))


def project_rms(project: G2.G2Project, pidx: int, maximum: float) -> float:
    phase = project.phase(pidx)
    rms = rms_displacement(project, pidx)
    if rms > maximum:
        factor = maximum / rms
        for aidx, parent in PARENTS[pidx].items():
            delta = np.asarray(phase.atoms()[aidx].coordinates) - parent
            delta -= np.rint(delta)
            phase.atoms()[aidx].coordinates = ((parent + factor * delta) % 1).tolist()
    return rms_displacement(project, pidx)


def refine_group(
    project: G2.G2Project,
    pidx: int,
    half_widths: tuple[float, float, float],
    cycles: int,
) -> None:
    phase = project.phase(pidx)
    for aidx, parent in PARENTS[pidx].items():
        phase.atoms()[aidx].refinement_flags = "X"
        for axis, value, width in zip(("x", "y", "z"), parent, half_widths):
            variable = f"{pidx}::dA{axis}:{aidx}"
            project.set_Controls("parmMin", float(value - width), variable=variable)
            project.set_Controls("parmMax", float(value + width), variable=variable)
    project.set_Controls("cycles", cycles)
    project.refine()
    phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})


def record(project: G2.G2Project, label: str) -> dict:
    return {
        "label": label,
        "rwp_percent": rwp(project),
        "rms_A": {str(i): rms_displacement(project, i) for i in PARENTS},
        "coordinates": {
            phase.name: {atom.label: atom.coordinates for atom in phase.atoms()}
            for phase in project.phases()
        },
    }


def save(project: G2.G2Project, outdir: Path, index: int, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, outdir / f"stage-{index:02d}-{label}.gpx")


def run(base: Path, outdir: Path) -> None:
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(base), newgpx=str(outdir / "oxygen.gpx"))
    clear_all(project)
    recalc(project)
    rows = [record(project, "base")]
    print(json.dumps(rows[-1]), flush=True)
    save(project, outdir, 0, "base")

    # Revisit the well-observed scheelite oxygen orbit using bounds measured
    # from the unperturbed library model, then enforce the 0.05 A O RMS cap.
    refine_group(project, 0, (0.010, 0.010, 0.005), 6)
    project_rms(project, 0, 0.050)
    recalc(project)
    rows.append(record(project, "CaWO4_O"))
    print(json.dumps(rows[-1]), flush=True)
    save(project, outdir, 1, "cawo4-o")

    # Six independent WO3 oxygen orbits are weak individually. Fractional
    # windows correspond to about 0.05 A; the aggregate is projected to the
    # exact laboratory upper bound after the least-squares direction is found.
    refine_group(project, 1, (0.007, 0.007, 0.005), 9)
    project_rms(project, 1, 0.050)
    recalc(project)
    rows.append(record(project, "WO3_O"))
    print(json.dumps(rows[-1]), flush=True)
    save(project, outdir, 2, "wo3-o")

    # Calcite contributes only weakly; retain the unconstrained estimate inside
    # the same physically small coordinate window without forcing a direction.
    refine_group(project, 3, (0.010, 0.010, 0.005), 6)
    project_rms(project, 3, 0.050)
    recalc(project)
    rows.append(record(project, "calcite_O"))
    print(json.dumps(rows[-1]), flush=True)
    save(project, outdir, 3, "calcite-o")

    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    project.histogram(0).set_refinements({"Background": {"refine": True}})
    project.set_Controls("cycles", 5)
    project.refine()
    clear_all(project)
    recalc(project)
    rows.append(record(project, "linear_cleanup"))
    print(json.dumps(rows[-1]), flush=True)
    save(project, outdir, 4, "linear-cleanup")
    (outdir / "history.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    run(args.base, args.outdir)
