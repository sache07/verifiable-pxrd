#!/usr/bin/env python3
"""Build and iteratively refine candidate Ca/WO3 powder models in GSAS-II.

This is an exploratory driver. It keeps every candidate in its own directory so
that phase inventories and parent structures can be compared on the same data.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def instrument_text() -> str:
    # Broad but physically plausible starting profile. V and Y are fixed at zero,
    # matching the synthetic laboratory's instrument family.
    return (
        "#GSAS-II instrument parameter file; Cu Kalpha Bragg-Brentano start\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.05;Polariz.:0.8;Azimuth:0.0\n"
        "U:25.0;V:0.0;W:10.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def read_pattern(path: Path) -> tuple[np.ndarray, np.ndarray]:
    z = np.genfromtxt(path, delimiter=",", names=True)
    return np.asarray(z["two_theta_deg"], float), np.asarray(z["intensity"], float)


def write_xye(path: Path, x: np.ndarray, y: np.ndarray) -> None:
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(path, np.column_stack([x, y, sigma]), fmt="%.8f %.8f %.8f")


def profile_stats(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    x, yobs, weight, ycalc, ybkg, ydiff = [np.asarray(v, float) for v in arrays[:6]]
    mask = np.isfinite(x + yobs + weight + ycalc)
    mask &= weight > 0
    num = float(np.sum(weight[mask] * (yobs[mask] - ycalc[mask]) ** 2))
    den = float(np.sum(weight[mask] * yobs[mask] ** 2))
    rwp = 100.0 * math.sqrt(num / den)
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = hist.data.get("Residuals", {})
    out = {
        "label": label,
        "rwp_recomputed_percent": rwp,
        "gof": cov.get("Rvals", {}).get("GOF"),
        "gsas_residuals": rvals,
        "n_variables": len(cov.get("varyList", [])),
        "vary_list": [str(v) for v in cov.get("varyList", [])],
        "min_calc": float(np.min(ycalc)),
        "min_background": float(np.min(ybkg)),
        "max_calc": float(np.max(ycalc)),
    }
    print(json.dumps(out, default=str), flush=True)
    return out


def configure_hap(phase: G2.G2Phase, histname: str, start_scale: float) -> None:
    hap = phase.data["Histograms"][histname]
    hap["Scale"] = [float(start_scale), False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.5
    hap["Size"][1][1] = 0.5
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][1][1] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]


def save_stage(project: G2.G2Project, outdir: Path, index: int, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, outdir / f"stage-{index:02d}-{label}.gpx")


def set_bounds(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def bound_initial_cells(project: G2.G2Project, phases: list[G2.G2Phase]) -> None:
    for pidx, phase in enumerate(phases):
        cell = phase.data["General"]["Cell"][1:7]
        avec = G2lat.cell2A(cell)
        for aidx, val in enumerate(avec):
            # The diagonal reciprocal-metric terms are positive. Off-diagonal
            # terms can cross zero, so give those an absolute safety interval.
            if aidx < 3:
                low, high = 0.96 * val, 1.04 * val
            else:
                width = max(abs(val) * 0.20, 2.0e-4)
                low, high = val - width, val + width
            set_bounds(project, f"{pidx}::A{aidx}", min(low, high), max(low, high))


def run(outdir: Path, phase_specs: list[tuple[str, str]]) -> None:
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    x, y = read_pattern(Path("inputs/pattern.csv"))
    datafile = outdir / "pattern.xye"
    instfile = outdir / "instrument.instprm"
    write_xye(datafile, x, y)
    instfile.write_text(instrument_text())

    gpx = outdir / "candidate.gpx"
    project = G2.G2Project(newgpx=str(gpx))
    phases = []
    for name, cid in phase_specs:
        phases.append(
            project.add_phase(
                str(cod_path(cid).resolve()), phasename=name, fmthint="CIF"
            )
        )
    hist = project.add_powder_histogram(
        str(datafile.resolve()),
        str(instfile.resolve()),
        phases=phases,
        fmthint="xye",
    )
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.1, False]
    hist.SampleParameters["SurfRoughB"] = [0.1, False]

    # A moderately flexible smooth background. The first coefficient is a
    # sensible count-level start and the rest begin at zero.
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 15,
                "coeffs": [700.0] + [0.0] * 14,
                "refine": False,
            }
        }
    )
    for phase in phases:
        configure_hap(phase, hist.name, start_scale=20.0)

    project.set_Controls("cycles", 5)
    # Bounds mirror the stated laboratory's instrument/specimen family and
    # prevent poorly constrained early cycles from producing invalid projects.
    for variable, low, high in [
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
        (":0:SurfRoughA", 0.0, 0.70),
        (":0:SurfRoughB", 0.0, 0.70),
    ]:
        set_bounds(project, variable, low, high)
    for pidx in range(len(phases)):
        set_bounds(project, f"{pidx}:0:Scale", 1.0e-8, 1.0e5)
    bound_initial_cells(project, phases)
    project.save()
    project.refine()
    stats = [profile_stats(project, "initial")]
    save_stage(project, outdir, 0, "initial")

    # Linear terms: phase scales and background.
    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    project.refine()
    stats.append(profile_stats(project, "scales_background"))
    save_stage(project, outdir, 1, "scales-background")

    # First align all phases with a single bounded angular zero.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    stats.append(profile_stats(project, "zero"))
    save_stage(project, outdir, 2, "zero")

    # Then refine each symmetry-allowed cell separately. This avoids an absent
    # or tiny candidate phase destabilizing the cells of strong phases. Two
    # passes allow the scales/background to settle around each update.
    cell_stage = 3
    for cell_pass in range(2):
        for phase in phases:
            phase.set_refinements({"Cell": True})
            project.refine()
            label = f"cell_{cell_pass + 1}_{phase.name}"
            stats.append(profile_stats(project, label))
            save_stage(project, outdir, cell_stage, label.replace("_", "-"))
            cell_stage += 1
            phase.clear_refinements({"Cell": True})

    # Sample displacement has a different angular dependence from Zero and is
    # activated only after the cells are close.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.refine()
    stats.append(profile_stats(project, "zero_shift_cells"))
    save_stage(project, outdir, cell_stage, "zero-shift-cells")
    cell_stage += 1

    # Common instrumental profile.
    hist.set_refinements(
        {
            "Instrument Parameters": ["U", "W", "X"]
        }
    )
    project.refine()
    stats.append(profile_stats(project, "instrument_profile"))
    save_stage(project, outdir, cell_stage, "instrument-profile")
    cell_stage += 1

    # Isotropic phase broadening. These are intentionally refined only after
    # the instrument is close to avoid an ill-conditioned first cycle.
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.5, "refine": True},
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 0.5, "refine": False},
                },
            }
        )
    for pidx in range(len(phases)):
        set_bounds(project, f"{pidx}:0:Size;i", 0.04, 1.5)
        set_bounds(project, f"{pidx}:0:Mustrain;i", 0.0, 8000.0)
    project.refine()
    stats.append(profile_stats(project, "phase_broadening"))
    save_stage(project, outdir, cell_stage, "phase-broadening")
    cell_stage += 1

    # Asymmetry, polarization and optional low-angle surface deficit are much
    # safer once widths and scales are established.
    hist.set_refinements(
        {
            "Instrument Parameters": ["SH/L", "Polariz."],
            "Sample Parameters": ["SurfRoughA", "SurfRoughB"],
        }
    )
    project.refine()
    stats.append(profile_stats(project, "asymmetry_polarization_roughness"))
    save_stage(project, outdir, cell_stage, "asymmetry-polarization-roughness")
    cell_stage += 1

    # One cleanup cycle with all current flags retained.
    project.refine()
    stats.append(profile_stats(project, "cleanup"))
    save_stage(project, outdir, cell_stage, "cleanup")
    project.save()

    summary = {
        "phases": [
            {
                "name": p.name,
                "cod_id": cid,
                "cell": p.get_cell(),
                "composition": p.composition,
                "mass": p.data["General"]["Mass"],
                "hap": p.data["Histograms"][hist.name],
            }
            for p, (_, cid) in zip(phases, phase_specs)
        ],
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.SampleParameters,
        "background": hist.data["Background"],
        "stats": stats,
    }
    (outdir / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("outdir", type=Path)
    parser.add_argument(
        "phases",
        nargs="+",
        help="phase specifications as NAME=COD_ID",
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    specs = []
    for item in args.phases:
        name, cid = item.split("=", 1)
        specs.append((name, cid))
    run(args.outdir, specs)
