#!/usr/bin/env python3
"""Staged, replay-consistent GSAS-II profile refinement for the four-phase model."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(project: G2.G2Project) -> float:
    _, y, w, yc = [
        np.asarray(v, float) for v in project.histogram(0).data["data"][1][:4]
    ]
    return 100.0 * math.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y**2))


def clear_frozen(project: G2.G2Project) -> None:
    controls = project.data["Controls"]["data"]
    controls.get("parmFrozen", {}).setdefault("FrozenList", [])
    controls["parmFrozen"]["FrozenList"] = []


def clear_all(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    hist.clear_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements(
            {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
        )
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "Extinction": True,
            }
        )
    clear_frozen(project)


def summary(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    parts = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        part = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        parts.append(part)
        phases.append(
            {
                "name": phase.name,
                "scale": hap["Scale"][0],
                "size": hap["Size"][:4],
                "mustrain": hap["Mustrain"][:4],
                "preferred_orientation": hap["Pref.Ori."][:4],
            }
        )
    fractions = np.asarray(parts) / np.sum(parts)
    row = {
        "label": label,
        "rwp_percent": rwp(project),
        "instrument": {
            k: v[1]
            for k, v in hist.data["Instrument Parameters"][0].items()
            if k in ("Zero", "U", "W", "X", "SH/L", "Polariz.")
        },
        "sample": {
            k: hist.SampleParameters[k][0]
            for k in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "fractions": fractions.tolist(),
        "phases": phases,
        "vary_list": [
            str(v)
            for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])
        ],
    }
    print(json.dumps(row), flush=True)
    return row


def snapshot(project: G2.G2Project, outdir: Path, index: int, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, outdir / f"stage-{index:02d}-{label}.gpx")


def recalc(project: G2.G2Project) -> None:
    clear_frozen(project)
    project.set_Controls("cycles", 0)
    project.refine()


def refine_hist_parameter(
    project: G2.G2Project,
    key: str,
    low: float,
    high: float,
    sample: bool = False,
) -> None:
    hist = project.histogram(0)
    if sample:
        hist.set_refinements({"Sample Parameters": [key]})
        variable = f":0:{key}"
    else:
        hist.set_refinements({"Instrument Parameters": [key]})
        variable = f":0:{key}"
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)
    project.set_Controls("cycles", 7)
    project.refine()
    if sample:
        hist.clear_refinements({"Sample Parameters": [key]})
    else:
        hist.clear_refinements({"Instrument Parameters": [key]})
    recalc(project)


def refine_hap_parameter(
    project: G2.G2Project,
    pidx: int,
    kind: str,
    variable_suffix: str,
    low: float,
    high: float,
) -> None:
    phase = project.phase(pidx)
    if kind == "Size":
        phase.set_HAP_refinements(
            {"Size": {"type": phase.data["Histograms"][project.histogram(0).name]["Size"][0], "refine": True}}
        )
    elif kind == "Mustrain-i":
        hap = phase.data["Histograms"][project.histogram(0).name]
        hap["Mustrain"][2][0] = True
    elif kind == "Mustrain-a":
        hap = phase.data["Histograms"][project.histogram(0).name]
        hap["Mustrain"][2][1] = True
    variable = f"{pidx}:0:{variable_suffix}"
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)
    project.set_Controls("cycles", 7)
    project.refine()
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    recalc(project)


def run(base: Path, outdir: Path) -> None:
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(base), newgpx=str(outdir / "profile.gpx"))
    clear_all(project)
    rows = []
    recalc(project)
    rows.append(summary(project, "base"))
    snapshot(project, outdir, 0, "base")

    # Adopt the modest CaWO4 uniaxial improvement found in the axis screen.
    ca_hap = project.phase(0).data["Histograms"][project.histogram(0).name]
    ca_hap["Mustrain"][0] = "uniaxial"
    ca_hap["Mustrain"][1][0] = 3826.4
    ca_hap["Mustrain"][1][1] = 2272.0
    ca_hap["Mustrain"][3] = [0, 1, 0]
    recalc(project)
    rows.append(summary(project, "CaWO4_uniaxial_start"))
    snapshot(project, outdir, 1, "cawo4-uniaxial-start")

    stage = 2
    # Instrument terms are optimized one at a time and revisited once.
    for pass_index in range(2):
        for key, low, high in (("U", 0.0, 40.0), ("W", 2.0, 40.0), ("X", 0.1, 6.0)):
            refine_hist_parameter(project, key, low, high)
            label = f"instrument_{pass_index + 1}_{key}"
            rows.append(summary(project, label))
            snapshot(project, outdir, stage, label.replace("_", "-"))
            stage += 1

    # Phase line profiles: size for all phases and strain only where present.
    for pidx in range(4):
        refine_hap_parameter(project, pidx, "Size", "Size;i", 0.04, 1.5)
        label = f"size_{project.phase(pidx).name}"
        rows.append(summary(project, label))
        snapshot(project, outdir, stage, label.replace("_", "-"))
        stage += 1
        hap = project.phase(pidx).data["Histograms"][project.histogram(0).name]
        if hap["Mustrain"][0] == "uniaxial":
            for kind, suffix in (("Mustrain-i", "Mustrain;i"), ("Mustrain-a", "Mustrain;a")):
                high = 8000.0 if kind == "Mustrain-i" else 32000.0
                refine_hap_parameter(project, pidx, kind, suffix, 0.0, high)
        elif float(hap["Mustrain"][1][0]) > 0:
            refine_hap_parameter(project, pidx, "Mustrain-i", "Mustrain;i", 0.0, 8000.0)
        label = f"strain_{project.phase(pidx).name}"
        rows.append(summary(project, label))
        snapshot(project, outdir, stage, label.replace("_", "-"))
        stage += 1

    # Low-angle/asymmetry terms, each isolated to avoid known correlations.
    for key, low, high, sample in (
        ("SH/L", 0.005, 0.10, False),
        ("Polariz.", 0.5, 1.0, False),
        ("SurfRoughA", 0.0, 0.6, True),
        ("SurfRoughB", 0.0, 0.5, True),
    ):
        refine_hist_parameter(project, key, low, high, sample=sample)
        label = f"nuisance_{key.replace('/', '')}"
        rows.append(summary(project, label))
        snapshot(project, outdir, stage, label.replace("_", "-"))
        stage += 1

    # Finish with linear scale/background optimization and a consistent replay.
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    project.histogram(0).set_refinements({"Background": {"refine": True}})
    project.set_Controls("cycles", 5)
    project.refine()
    for phase in project.phases():
        phase.clear_HAP_refinements({"Scale": True})
    project.histogram(0).clear_refinements({"Background": True})
    recalc(project)
    rows.append(summary(project, "linear_cleanup"))
    snapshot(project, outdir, stage, "linear-cleanup")
    (outdir / "profile-history.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    run(args.base, args.outdir)
