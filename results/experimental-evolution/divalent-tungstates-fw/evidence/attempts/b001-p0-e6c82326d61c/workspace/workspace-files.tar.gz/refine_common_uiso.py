#!/usr/bin/env python3
"""Refine one physically bounded isotropic displacement value per phase."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(project: G2.G2Project) -> float:
    _, y, w, yc = [
        np.asarray(v, float) for v in project.histogram(0).data["data"][1][:4]
    ]
    return 100.0 * math.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y**2))


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    hist.clear_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements(
            {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
        )
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    project.data["Controls"]["data"]["parmFrozen"]["FrozenList"] = []


def run(base: Path, outdir: Path) -> None:
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(base), newgpx=str(outdir / "uiso.gpx"))
    clear_flags(project)
    project.set_Controls("cycles", 0)
    project.refine()
    print(json.dumps({"stage": "base", "rwp_percent": rwp(project)}), flush=True)

    # Recreate phase equivalence constraints explicitly. Some intermediate
    # replay projects intentionally remove dormant constraints after fixing U.
    project.data["Constraints"]["data"]["Phase"] = []
    for pidx, phase in enumerate(project.phases()):
        for atom in phase.atoms():
            atom.refinement_flags = "U"
        variables = [f"{pidx}::AUiso:{aidx}" for aidx in range(len(phase.atoms()))]
        if len(variables) > 1:
            project.add_EquivConstr(
                variables, reloadIdx=(pidx == 0), override=True
            )
        project.set_Controls("parmMin", 0.003, variable=f"{pidx}::AUiso:0")
        project.set_Controls("parmMax", 0.020, variable=f"{pidx}::AUiso:0")
        phase.set_HAP_refinements({"Scale": True})
    project.histogram(0).set_refinements({"Background": {"refine": True}})
    project.set_Controls("cycles", 9)
    project.refine()
    cov = project.data.get("Covariance", {}).get("data", {})
    print(
        json.dumps(
            {
                "stage": "common_uiso",
                "rwp_percent": rwp(project),
                "uiso": [phase.atoms()[0].uiso for phase in project.phases()],
                "vary_list": [str(v) for v in cov.get("varyList", [])],
                "sigmas": np.asarray(cov.get("sig", []), float).tolist(),
            }
        ),
        flush=True,
    )

    # Ensure exact phase-wide equality even if a bound froze a master variable,
    # then remove dormant constraints for a warning-free replay project.
    for phase in project.phases():
        value = float(np.clip(phase.atoms()[0].uiso, 0.003, 0.020))
        for atom in phase.atoms():
            atom.uiso = value
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True})
    project.histogram(0).clear_refinements({"Background": True})
    project.data["Constraints"]["data"]["Phase"] = []
    project.data["Controls"]["data"]["parmFrozen"]["FrozenList"] = []
    project.set_Controls("cycles", 0)
    project.refine()
    project.save()
    shutil.copy2(project.filename, outdir / "stage-01-common-uiso.gpx")
    print(
        json.dumps(
            {
                "stage": "replay",
                "rwp_percent": rwp(project),
                "uiso": [phase.atoms()[0].uiso for phase in project.phases()],
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    run(args.base, args.outdir)
