#!/usr/bin/env python3
"""Stable coordinate-descent refinement at fixed crystalline fractions."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_fixed_fractions import TARGET, clear_all, fractions


def rwp(project: G2.G2Project) -> float:
    _, y, w, yc = [
        np.asarray(v, float) for v in project.histogram(0).data["data"][1][:4]
    ]
    return 100.0 * math.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y**2))


def log(project: G2.G2Project, stage: str) -> None:
    print(
        json.dumps(
            {
                "stage": stage,
                "rwp_percent": rwp(project),
                "fractions": fractions(project).tolist(),
                "uiso": [p.atoms()[0].uiso for p in project.phases()],
            }
        ),
        flush=True,
    )


def recalc(project: G2.G2Project) -> None:
    project.data["Controls"]["data"]["parmFrozen"]["FrozenList"] = []
    project.set_Controls("cycles", 0)
    project.refine()


def set_exact_fraction_scales(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    masses = np.array([p.data["General"]["Mass"] for p in project.phases()])
    total = sum(
        p.data["Histograms"][hist.name]["Scale"][0] * mass
        for p, mass in zip(project.phases(), masses)
    )
    scales = total * TARGET / masses
    for phase, value in zip(project.phases(), scales):
        phase.data["Histograms"][hist.name]["Scale"][0] = float(value)
        phase.clear_HAP_refinements({"Scale": True})
    project.data["Constraints"]["data"]["HAP"] = []


def run(base: Path, outdir: Path) -> None:
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(base), newgpx=str(outdir / "fixed-iterative.gpx"))
    clear_all(project)
    recalc(project)
    log(project, "base")

    set_exact_fraction_scales(project)
    # GSAS-II's histogram sample scale multiplies every phase and therefore
    # supplies one global normalization without disturbing HAP scale ratios.
    project.histogram(0).SampleParameters["Scale"] = [1.0, True]
    project.histogram(0).set_refinements({"Sample Parameters": ["Scale"]})
    project.histogram(0).set_refinements({"Background": {"refine": True}})
    project.set_Controls("cycles", 6)
    project.refine()
    log(project, "scale_background")

    # Refine one phase-wide Uiso at a time, retaining only the common intensity
    # scale and background as nuisance terms. Coordinate descent is much better
    # conditioned than releasing all four U/scale blocks in one normal matrix.
    for pass_index in range(2):
        for pidx, phase in enumerate(project.phases()):
            project.data["Constraints"]["data"]["Phase"] = []
            for atom in phase.atoms():
                atom.refinement_flags = "U"
            uvars = [f"{pidx}::AUiso:{i}" for i in range(len(phase.atoms()))]
            if len(uvars) > 1:
                project.add_EquivConstr(uvars, reloadIdx=True, override=True)
            project.set_Controls("parmMin", 0.003, variable=f"{pidx}::AUiso:0")
            project.set_Controls("parmMax", 0.020, variable=f"{pidx}::AUiso:0")
            project.data["Controls"]["data"]["parmFrozen"]["FrozenList"] = []
            project.set_Controls("cycles", 6)
            project.refine()
            value = float(np.clip(phase.atoms()[0].uiso, 0.003, 0.020))
            for atom in phase.atoms():
                atom.uiso = value
            phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})
            log(project, f"uiso_pass{pass_index + 1}_phase{pidx}")

    # Remove all refinement flags and constraints, then force a fresh replay.
    project.histogram(0).clear_refinements({"Background": True})
    project.histogram(0).clear_refinements({"Sample Parameters": ["Scale"]})
    for phase in project.phases():
        phase.clear_HAP_refinements({"Scale": True})
        phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})
    project.data["Constraints"]["data"]["HAP"] = []
    project.data["Constraints"]["data"]["Phase"] = []
    recalc(project)
    log(project, "replay")
    project.save()
    shutil.copy2(project.filename, outdir / "stage-final.gpx")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    run(args.base, args.outdir)
