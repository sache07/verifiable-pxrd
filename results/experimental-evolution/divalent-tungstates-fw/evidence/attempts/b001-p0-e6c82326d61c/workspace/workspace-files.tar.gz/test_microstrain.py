#!/usr/bin/env python3
"""Screen supported uniaxial microstrain axes for selected GPX phases."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def rwp(project: G2.G2Project) -> float:
    _, y, w, yc = [
        np.asarray(v, float) for v in project.histogram(0).data["data"][1][:4]
    ]
    return 100.0 * math.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y**2))


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    hist.clear_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements(
            {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
        )
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
            }
        )
    project.data["Controls"]["data"].get("parmFrozen", {}).setdefault(
        "FrozenList", []
    )
    project.data["Controls"]["data"]["parmFrozen"]["FrozenList"] = []


def run(base: Path, outdir: Path, phase_indices: list[int]) -> None:
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    rows = []
    for pidx in phase_indices:
        for axis in AXES:
            tag = f"p{pidx}-" + "".join(map(str, axis))
            output = outdir / f"{tag}.gpx"
            project = G2.G2Project(str(base), newgpx=str(output))
            clear_flags(project)
            hist = project.histogram(0)
            phase = project.phase(pidx)
            strain = phase.data["Histograms"][hist.name]["Mustrain"]
            start = max(300.0, float(strain[1][0]))
            strain[0] = "uniaxial"
            strain[1][0] = min(start, 8000.0)
            strain[1][1] = min(start, 8000.0)
            strain[2][0] = True
            strain[2][1] = True
            strain[2][2] = False
            strain[3] = list(axis)
            project.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Mustrain;i")
            project.set_Controls("parmMax", 8000.0, variable=f"{pidx}:0:Mustrain;i")
            project.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Mustrain;a")
            project.set_Controls("parmMax", 32000.0, variable=f"{pidx}:0:Mustrain;a")
            project.set_Controls("cycles", 7)
            project.refine()
            project.refine()
            strain = phase.data["Histograms"][hist.name]["Mustrain"]
            row = {
                "phase_index": pidx,
                "phase": phase.name,
                "axis": list(axis),
                "equatorial_ppm": strain[1][0],
                "axial_ppm": strain[1][1],
                "rwp_percent": rwp(project),
                "gpx": str(output),
            }
            rows.append(row)
            print(json.dumps(row), flush=True)
            project.save()
    (outdir / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--phase-indices", default="0,1,3")
    args = parser.parse_args()
    run(args.base, args.outdir, [int(v) for v in args.phase_indices.split(",")])
