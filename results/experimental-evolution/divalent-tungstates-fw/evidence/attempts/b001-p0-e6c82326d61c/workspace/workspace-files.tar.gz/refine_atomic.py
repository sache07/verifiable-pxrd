#!/usr/bin/env python3
"""Refine common phase Uiso values and symmetry-constrained coordinates."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(project: G2.G2Project) -> float:
    _, y, w, yc = [
        np.asarray(v, float) for v in project.histogram(0).data["data"][1][:4]
    ]
    return 100.0 * math.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y**2))


def report(project: G2.G2Project, label: str) -> None:
    row = {
        "label": label,
        "rwp_percent": rwp(project),
        "vary_list": [
            str(v)
            for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])
        ],
        "phases": [],
    }
    for phase in project.phases():
        row["phases"].append(
            {
                "name": phase.name,
                "atoms": [
                    {
                        "label": atom.label,
                        "xyz": atom.coordinates,
                        "U": atom.ADP,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    print(json.dumps(row, default=str), flush=True)


def clear_all_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    # Background must be cleared separately because GSAS-II's convenience
    # method returns immediately after handling a Boolean Background request.
    hist.clear_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements(
            {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
        )
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "Extinction": True,
            }
        )
    controls = project.data["Controls"]["data"]
    controls.get("parmFrozen", {}).setdefault("FrozenList", [])
    controls["parmFrozen"]["FrozenList"] = []


def make_isotropic(atom: G2.G2AtomRecord, value: float) -> None:
    atom.data[atom.cia] = "I"
    atom.data[atom.cia + 1] = float(value)


def save_stage(project: G2.G2Project, outdir: Path, index: int, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, outdir / f"stage-{index:02d}-{label}.gpx")


def run(base: Path, outdir: Path) -> None:
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(base), newgpx=str(outdir / "atomic.gpx"))
    clear_all_flags(project)

    # Recalculate once from the saved model so diagnostics never rely on stale
    # arrays from a bounded refinement step.
    project.set_Controls("cycles", 0)
    project.refine()
    report(project, "recalculated_base")
    save_stage(project, outdir, 0, "recalculated-base")

    # The generator assigns one scalar Uiso to every site in each phase. Convert
    # source anisotropic records to that representation and constrain all sites
    # in a phase to a common refined value.
    for pidx, phase in enumerate(project.phases()):
        atoms = phase.atoms()
        for atom in atoms:
            make_isotropic(atom, 0.010)
            atom.refinement_flags = "U"
        variables = [f"{pidx}::AUiso:{aidx}" for aidx in range(len(atoms))]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=(pidx == 0), override=True)
    project.set_Controls("cycles", 6)
    project.refine()
    report(project, "common_uiso")
    save_stage(project, outdir, 1, "common-uiso")

    # Enforce the laboratory's physical Uiso range after the unconstrained
    # estimate. A value landing below the range is held at the stated floor.
    for phase in project.phases():
        value = float(np.clip(phase.atoms()[0].uiso, 0.003, 0.020))
        for atom in phase.atoms():
            atom.uiso = value
    # Fix Uiso at the physical common values and refine each framework in turn.
    for phase in project.phases():
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
    project.set_Controls("cycles", 0)
    project.refine()
    report(project, "physical_uiso")
    save_stage(project, outdir, 2, "physical-uiso")

    stage = 3
    for pidx in (0, 1, 3):  # CaO has no positional degrees of freedom.
        phase = project.phase(pidx)
        for aidx, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "X"
            for axis, value in zip(("x", "y", "z"), atom.coordinates):
                variable = f"{pidx}::dA{axis}:{aidx}"
                project.set_Controls("parmMin", value - 0.02, variable=variable)
                project.set_Controls("parmMax", value + 0.02, variable=variable)
        project.set_Controls("cycles", 8 if pidx == 1 else 5)
        project.refine()
        report(project, f"coordinates_{phase.name}")
        save_stage(project, outdir, stage, f"coordinates-{phase.name}")
        stage += 1
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})

    # Reoptimize the linear scale/background terms after the structure factors
    # have changed, keeping all structural/profile values fixed.
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    project.histogram(0).set_refinements({"Background": {"refine": True}})
    project.set_Controls("cycles", 4)
    project.refine()
    report(project, "linear_cleanup")
    save_stage(project, outdir, stage, "linear-cleanup")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    run(args.base, args.outdir)
