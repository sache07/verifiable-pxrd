#!/usr/bin/env python3
"""Profile refinement that preserves fixed HAP scale ratios/fractions."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_fixed_fractions import fractions


def rwp(project: G2.G2Project) -> float:
    _, y, w, yc = [
        np.asarray(v, float) for v in project.histogram(0).data["data"][1][:4]
    ]
    return 100.0 * math.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y**2))


def clear_all(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
            "Sample Parameters": ["Scale", "Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    hist.clear_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements(
            {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
        )
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    project.data["Controls"]["data"]["parmFrozen"]["FrozenList"] = []
    project.data["Constraints"]["data"]["Phase"] = []
    project.data["Constraints"]["data"]["HAP"] = []


def recalc(project: G2.G2Project) -> None:
    project.data["Controls"]["data"]["parmFrozen"]["FrozenList"] = []
    project.set_Controls("cycles", 0)
    project.refine()


def row(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    return {
        "label": label,
        "rwp_percent": rwp(project),
        "fractions": fractions(project).tolist(),
        "sample_scale": hist.SampleParameters["Scale"][0],
        "instrument": {
            k: hist.data["Instrument Parameters"][0][k][1]
            for k in ("U", "W", "X", "SH/L", "Polariz.")
        },
        "profiles": [
            {
                "phase": p.name,
                "size": p.data["Histograms"][hist.name]["Size"][:4],
                "mustrain": p.data["Histograms"][hist.name]["Mustrain"][:4],
                "po": p.data["Histograms"][hist.name]["Pref.Ori."][:4],
            }
            for p in project.phases()
        ],
    }


def checkpoint(project: G2.G2Project, outdir: Path, index: int, label: str, rows: list[dict]) -> None:
    recalc(project)
    rows.append(row(project, label))
    print(json.dumps(rows[-1]), flush=True)
    project.save()
    shutil.copy2(project.filename, outdir / f"stage-{index:02d}-{label}.gpx")


def refine_hist(project: G2.G2Project, key: str, low: float, high: float, sample: bool = False) -> None:
    hist = project.histogram(0)
    group = "Sample Parameters" if sample else "Instrument Parameters"
    hist.set_refinements({group: [key]})
    project.set_Controls("parmMin", low, variable=f":0:{key}")
    project.set_Controls("parmMax", high, variable=f":0:{key}")
    project.set_Controls("cycles", 6)
    project.refine()
    hist.clear_refinements({group: [key]})


def refine_size(project: G2.G2Project, pidx: int) -> None:
    phase = project.phase(pidx)
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    project.set_Controls("parmMin", 0.04, variable=f"{pidx}:0:Size;i")
    project.set_Controls("parmMax", 1.5, variable=f"{pidx}:0:Size;i")
    project.set_Controls("cycles", 6)
    project.refine()
    phase.clear_HAP_refinements({"Size": True})


def refine_strain(project: G2.G2Project, pidx: int) -> None:
    phase = project.phase(pidx)
    hap = phase.data["Histograms"][project.histogram(0).name]
    if hap["Mustrain"][0] == "uniaxial":
        for index, suffix, high in ((0, "i", 8000.0), (1, "a", 32000.0)):
            hap["Mustrain"][2][index] = True
            project.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Mustrain;{suffix}")
            project.set_Controls("parmMax", high, variable=f"{pidx}:0:Mustrain;{suffix}")
            project.set_Controls("cycles", 6)
            project.refine()
            hap["Mustrain"][2][index] = False
    elif float(hap["Mustrain"][1][0]) > 0:
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pidx}:0:Mustrain;i")
        project.set_Controls("cycles", 6)
        project.refine()
        hap["Mustrain"][2][0] = False


def run(base: Path, outdir: Path) -> None:
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(base), newgpx=str(outdir / "profile-fixed.gpx"))
    clear_all(project)
    rows: list[dict] = []
    checkpoint(project, outdir, 0, "base", rows)
    stage = 1

    for key, low, high in (("U", 0.0, 40.0), ("W", 2.0, 40.0), ("X", 0.1, 6.0)):
        refine_hist(project, key, low, high)
        checkpoint(project, outdir, stage, f"instrument-{key}", rows)
        stage += 1

    for pidx in range(4):
        refine_size(project, pidx)
        refine_strain(project, pidx)
        checkpoint(project, outdir, stage, f"profile-p{pidx}", rows)
        stage += 1

    # Retain the identified WO3 [100] texture axis and update only its ratio.
    hap = project.phase(1).data["Histograms"][project.histogram(0).name]
    hap["Pref.Ori."][2] = True
    project.set_Controls("parmMin", 0.7, variable="1:0:MD")
    project.set_Controls("parmMax", 1.4, variable="1:0:MD")
    project.set_Controls("cycles", 6)
    project.refine()
    hap["Pref.Ori."][2] = False
    checkpoint(project, outdir, stage, "wo3-texture", rows)
    stage += 1

    for key, low, high, sample in (
        ("SH/L", 0.005, 0.10, False),
        ("Polariz.", 0.5, 1.0, False),
        ("SurfRoughA", 0.0, 0.6, True),
        ("SurfRoughB", 0.0, 0.5, True),
    ):
        refine_hist(project, key, low, high, sample=sample)
        checkpoint(project, outdir, stage, f"nuisance-{key.replace('/', '')}", rows)
        stage += 1

    # Linear cleanup uses one global sample scale, preserving all phase ratios.
    hist = project.histogram(0)
    hist.set_refinements({"Sample Parameters": ["Scale"]})
    hist.set_refinements({"Background": {"refine": True}})
    project.set_Controls("parmMin", 0.5, variable=":0:Scale")
    project.set_Controls("parmMax", 1.5, variable=":0:Scale")
    project.set_Controls("cycles", 6)
    project.refine()
    hist.clear_refinements({"Sample Parameters": ["Scale"]})
    hist.clear_refinements({"Background": True})
    checkpoint(project, outdir, stage, "linear-cleanup", rows)
    (outdir / "history.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    run(args.base, args.outdir)
