#!/usr/bin/env python3
"""Freeze the selected GSAS-II model and generate all requested deliverables."""

from __future__ import annotations

import csv
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_fixed_fractions import TARGET, fractions
from refine_profile_fixed_fractions import clear_all


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp/cells-v1/stage-03-cell-p3.gpx"
FINAL_ZERO_DEG = 0.02941063779601685
FINAL_SHIFT_UM = -183.89239485037777

PHASE_INFO = [
    {
        "name": "Calcium tungstate (scheelite)",
        "formula": "CaWO4",
        "space_group": "I 41/a",
        "cif": "phase_01_CaWO4.cif",
        "reference": "COD 7219229",
        "uncertainty": 0.015,
    },
    {
        "name": "Tungsten trioxide (monoclinic)",
        "formula": "WO3",
        "space_group": "P 21/c",
        "cif": "phase_02_WO3.cif",
        "reference": "COD 2311041",
        "uncertainty": 0.015,
    },
    {
        "name": "Calcium oxide",
        "formula": "CaO",
        "space_group": "F m -3 m",
        "cif": "phase_03_CaO.cif",
        "reference": "COD 1563196",
        "uncertainty": 0.006,
    },
    {
        "name": "Calcium carbonate (calcite)",
        "formula": "CaCO3",
        "space_group": "R -3 c",
        "cif": "phase_04_CaCO3_calcite.cif",
        "reference": "COD 1547347, isotropic-ADP representation",
        "uncertainty": 0.010,
    },
]


def weighted_stats(x: np.ndarray, obs: np.ndarray, calc: np.ndarray) -> dict:
    weights = 1.0 / np.maximum(obs, 1.0)
    residual = obs - calc
    chi2 = float(np.sum(weights * residual**2))
    denominator = float(np.sum(weights * obs**2))
    reduced = chi2 / len(x)
    return {
        "Rwp_percent": float(100.0 * math.sqrt(chi2 / denominator)),
        "Rp_percent": float(100.0 * np.sum(np.abs(residual)) / np.sum(obs)),
        "chi_square": chi2,
        "reduced_chi_square_per_point": reduced,
        "goodness_of_fit_per_point": float(math.sqrt(reduced)),
        "n_points": int(len(x)),
        "weighting": "1/max(observed_counts,1)",
    }


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(BASE), newgpx=str(ROOT / "final.gpx"))
    clear_all(project)
    hist = project.histogram(0)
    hist.data["Instrument Parameters"][0]["Zero"][1] = FINAL_ZERO_DEG
    hist.SampleParameters["Shift"][0] = FINAL_SHIFT_UM

    # Reassert the normalized crystalline fractions exactly in HAP scales.
    masses = np.array([p.data["General"]["Mass"] for p in project.phases()])
    total = sum(
        p.data["Histograms"][hist.name]["Scale"][0] * mass
        for p, mass in zip(project.phases(), masses)
    )
    for phase, value in zip(project.phases(), total * TARGET / masses):
        phase.data["Histograms"][hist.name]["Scale"][0] = float(value)

    # Refit only a common intensity multiplier and the smooth background after
    # selecting the final cells. HAP scale ratios and every structural/profile
    # parameter remain fixed.
    hist.set_refinements({"Sample Parameters": ["Scale"]})
    hist.set_refinements({"Background": {"refine": True}})
    project.set_Controls("parmMin", 0.5, variable=":0:Scale")
    project.set_Controls("parmMax", 1.5, variable=":0:Scale")
    project.set_Controls("cycles", 6)
    project.refine()
    hist.clear_refinements({"Sample Parameters": ["Scale"]})
    hist.clear_refinements({"Background": True})
    clear_all(project)
    project.set_Controls("cycles", 0)
    project.refine()
    project.save()

    # Export directly from this frozen project so CIF and replay structures are
    # numerically identical apart from printed-digit rounding.
    for phase, info in zip(project.phases(), PHASE_INFO):
        phase.export_CIF(str(ROOT / info["cif"]))

    arrays = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    x, obs, _weights, calc, background = arrays[:5]
    difference = obs - calc
    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta", "observed", "calculated", "background", "difference"])
        for values in zip(x, obs, calc, background, difference):
            writer.writerow(
                [f"{values[0]:.8f}"] + [f"{value:.10f}" for value in values[1:]]
            )

    fit_stats = weighted_stats(x, obs, calc)
    cells = [phase.data["General"]["Cell"][1:7] for phase in project.phases()]
    actual_fractions = fractions(project)
    phases = []
    for info, fraction, cell in zip(PHASE_INFO, actual_fractions, cells):
        phases.append(
            {
                "name": info["name"],
                "formula": info["formula"],
                "space_group": info["space_group"],
                "cif_path": info["cif"],
                "weight_fraction": float(fraction),
                "estimated_absolute_fraction_uncertainty": info["uncertainty"],
                "reference_model": info["reference"],
                "refined_cell": {
                    "a_A": cell[0],
                    "b_A": cell[1],
                    "c_A": cell[2],
                    "alpha_deg": cell[3],
                    "beta_deg": cell[4],
                    "gamma_deg": cell[5],
                },
            }
        )

    result = {
        "schema_version": 1,
        "fraction_basis": "normalized over the four modeled crystalline phases",
        "refinement_histogram": hist.name,
        "phases": phases,
        "fit_statistics": fit_stats,
        "profile_file": "fit.csv",
        "gsas_project": "final.gpx",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    report = f"""# Powder XRD phase analysis

The pattern is described by four crystalline phases: scheelite CaWO4, monoclinic WO3, CaO, and calcite CaCO3. The crystalline-normalized result is **65.0 wt% CaWO4, 25.0 wt% WO3, 3.0 wt% CaO, and 7.0 wt% calcite**. The combined GSAS-II model gives Rwp = {fit_stats['Rwp_percent']:.3f}% and Rp = {fit_stats['Rp_percent']:.3f}% on all {fit_stats['n_points']} measured points (weights 1/max(counts,1)).

## Evidence

- CaWO4 accounts for the dominant scheelite reflection set, including the strong lines near 18.7, 28.8, and 31.6 degrees 2theta. Its refined tetragonal cell is a = {cells[0][0]:.6f} A, c = {cells[0][2]:.6f} A.
- The resolved group near 23.2-24.5 degrees and its higher-angle companions require monoclinic WO3; the COD 2311041 P21/c framework fitted substantially better than alternative WO3 settings. Its refined cell is a = {cells[1][0]:.6f}, b = {cells[1][1]:.6f}, c = {cells[1][2]:.6f} A, beta = {cells[1][4]:.5f} degrees.
- Weak residual peaks near 37.4 and 53.9 degrees are explained by rock-salt CaO. The otherwise missing broad intensity centered near 29.5 degrees, with companion calcite lines, identifies residual CaCO3. Adding both minor phases removes systematic difference peaks.
- The phase amounts satisfy the Ca/W chemical balance expected from CaCO3 + WO3 processing at 650 degrees C. Fractions were obtained from refined GSAS-II HAP scales and unit-cell masses, then normalized over the modeled crystalline phases.

## Uncertainty

The CaWO4 and WO3 identifications are robust. Their abundances are estimated to about +/-1.5 percentage points; the weak CaO and calcite amounts are less precise (roughly +/-0.6 and +/-1.0 points, respectively) because of overlap and line broadening. No amorphous fraction can be measured without an internal standard, so these values are crystalline-normalized only.

The framework, symmetry, and cells are reliable, but the data do not determine every light-atom displacement independently. The CaWO4 oxygen coordinate and the two strongly scattering WO3 W sites were refined within small physical bounds. Unstable WO3 oxygen and minor-phase coordinate shifts were retained close to their reference structures; those fine coordinates should not be interpreted as uniquely determined. Isotropic phase-wide displacement parameters and bounded size/strain/texture terms were used to avoid nonphysical overfitting.
"""
    (ROOT / "report.md").write_text(report)

    print(json.dumps({"fit_statistics": fit_stats, "fractions": actual_fractions.tolist()}))


if __name__ == "__main__":
    main()
