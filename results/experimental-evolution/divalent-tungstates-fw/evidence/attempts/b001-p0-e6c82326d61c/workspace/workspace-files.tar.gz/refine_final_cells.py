#!/usr/bin/env python3
"""Final bounded cell/position-calibration pass with phase ratios fixed."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

from refine_fixed_fractions import fractions
from refine_profile_fixed_fractions import clear_all


def rwp(project: G2.G2Project) -> float:
    _, y, w, yc = [
        np.asarray(v, float) for v in project.histogram(0).data["data"][1][:4]
    ]
    return 100.0 * math.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y**2))


def recalc(project: G2.G2Project) -> None:
    project.data["Controls"]["data"]["parmFrozen"]["FrozenList"] = []
    project.set_Controls("cycles", 0)
    project.refine()


def report(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(
        json.dumps(
            {
                "label": label,
                "rwp_percent": rwp(project),
                "fractions": fractions(project).tolist(),
                "zero": hist.data["Instrument Parameters"][0]["Zero"][1],
                "shift_um": hist.SampleParameters["Shift"][0],
                "cells": {p.name: p.data["General"]["Cell"][1:7] for p in project.phases()},
            }
        ),
        flush=True,
    )


def run(base: Path, outdir: Path) -> None:
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(base), newgpx=str(outdir / "cells.gpx"))
    clear_all(project)
    recalc(project)
    report(project, "base")
    stage = 0

    # Bound reciprocal-metric terms tightly around the already indexed cells.
    for pidx, phase in enumerate(project.phases()):
        for aidx, value in enumerate(G2lat.cell2A(phase.data["General"]["Cell"][1:7])):
            width = max(abs(value) * 0.004, 5e-6)
            project.set_Controls("parmMin", value - width, variable=f"{pidx}::A{aidx}")
            project.set_Controls("parmMax", value + width, variable=f"{pidx}::A{aidx}")

    for pass_index in range(2):
        for pidx, phase in enumerate(project.phases()):
            phase.set_refinements({"Cell": True})
            project.set_Controls("cycles", 6)
            project.refine()
            phase.clear_refinements({"Cell": True})
            recalc(project)
            report(project, f"cell-pass{pass_index + 1}-p{pidx}")
            project.save()
            shutil.copy2(project.filename, outdir / f"stage-{stage:02d}-cell-p{pidx}.gpx")
            stage += 1

        # Revisit the two common angular calibration terms between cell passes.
        hist = project.histogram(0)
        for key, group, low, high in (
            ("Zero", "Instrument Parameters", -0.25, 0.25),
            ("Shift", "Sample Parameters", -800.0, 800.0),
        ):
            hist.set_refinements({group: [key]})
            project.set_Controls("parmMin", low, variable=f":0:{key}")
            project.set_Controls("parmMax", high, variable=f":0:{key}")
            project.set_Controls("cycles", 6)
            project.refine()
            hist.clear_refinements({group: [key]})
            recalc(project)
            report(project, f"calibration-pass{pass_index + 1}-{key}")

    # Global scale/background cleanup leaves HAP scale ratios unchanged.
    hist = project.histogram(0)
    hist.set_refinements({"Sample Parameters": ["Scale"]})
    hist.set_refinements({"Background": {"refine": True}})
    project.set_Controls("cycles", 6)
    project.refine()
    hist.clear_refinements({"Sample Parameters": ["Scale"]})
    hist.clear_refinements({"Background": True})
    recalc(project)
    report(project, "linear-cleanup")
    project.save()
    shutil.copy2(project.filename, outdir / "stage-final.gpx")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    run(args.base, args.outdir)
