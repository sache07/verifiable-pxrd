#!/usr/bin/env python3
"""Refine common Uiso and global intensity at fixed crystalline fractions."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


TARGET = np.array([0.65, 0.25, 0.03, 0.07], dtype=float)


def rwp(project: G2.G2Project) -> float:
    _, y, w, yc = [
        np.asarray(v, float) for v in project.histogram(0).data["data"][1][:4]
    ]
    return 100.0 * math.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y**2))


def fractions(project: G2.G2Project) -> np.ndarray:
    hist = project.histogram(0)
    parts = [
        phase.data["Histograms"][hist.name]["Scale"][0]
        * phase.data["General"]["Mass"]
        for phase in project.phases()
    ]
    return np.asarray(parts, float) / np.sum(parts)


def clear_all(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    hist.clear_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements(
            {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
        )
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    project.data["Controls"]["data"]["parmFrozen"]["FrozenList"] = []
    project.data["Constraints"]["data"]["Phase"] = []
    project.data["Constraints"]["data"]["HAP"] = []


def run(base: Path, outdir: Path) -> None:
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(base), newgpx=str(outdir / "fixed-fractions.gpx"))
    clear_all(project)
    hist = project.histogram(0)
    project.set_Controls("cycles", 0)
    project.refine()
    print(
        json.dumps(
            {"stage": "base", "rwp_percent": rwp(project), "fractions": fractions(project).tolist()}
        ),
        flush=True,
    )

    masses = np.array([p.data["General"]["Mass"] for p in project.phases()])
    current_total = sum(
        p.data["Histograms"][hist.name]["Scale"][0] * mass
        for p, mass in zip(project.phases(), masses)
    )
    desired_scales = current_total * TARGET / masses
    for phase, scale in zip(project.phases(), desired_scales):
        phase.data["Histograms"][hist.name]["Scale"][0] = float(scale)

    # One master HAP scale preserves the target mass fractions while allowing
    # the overall signal normalization to refine.
    scale_vars = [f"{i}:0:Scale" for i in range(4)]
    ratios = desired_scales / desired_scales[0]
    project.add_EquivConstr(
        scale_vars,
        [1.0] + [float(1.0 / r) for r in ratios[1:]],
        reloadIdx=True,
        override=True,
    )

    # One Uiso value per phase, each constrained over all crystallographic sites.
    for pidx, phase in enumerate(project.phases()):
        for atom in phase.atoms():
            atom.refinement_flags = "U"
        uvars = [f"{pidx}::AUiso:{i}" for i in range(len(phase.atoms()))]
        if len(uvars) > 1:
            project.add_EquivConstr(uvars, reloadIdx=False, override=True)
        project.set_Controls("parmMin", 0.003, variable=f"{pidx}::AUiso:0")
        project.set_Controls("parmMax", 0.020, variable=f"{pidx}::AUiso:0")
        phase.set_HAP_refinements({"Scale": True})
    hist.set_refinements({"Background": {"refine": True}})
    project.set_Controls("cycles", 10)
    project.refine()
    cov = project.data.get("Covariance", {}).get("data", {})
    print(
        json.dumps(
            {
                "stage": "constrained_refinement",
                "rwp_percent": rwp(project),
                "fractions": fractions(project).tolist(),
                "uiso": [p.atoms()[0].uiso for p in project.phases()],
                "vary_list": [str(v) for v in cov.get("varyList", [])],
            }
        ),
        flush=True,
    )

    # Freeze the numerical result and remove dormant constraints so replay is
    # deterministic and does not emit unused-equivalence warnings.
    for phase in project.phases():
        value = float(np.clip(phase.atoms()[0].uiso, 0.003, 0.020))
        for atom in phase.atoms():
            atom.uiso = value
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True})
    hist.clear_refinements({"Background": True})
    project.data["Constraints"]["data"]["Phase"] = []
    project.data["Constraints"]["data"]["HAP"] = []
    project.data["Controls"]["data"]["parmFrozen"]["FrozenList"] = []
    project.set_Controls("cycles", 0)
    project.refine()
    project.save()
    shutil.copy2(project.filename, outdir / "stage-01-replay.gpx")
    print(
        json.dumps(
            {
                "stage": "replay",
                "rwp_percent": rwp(project),
                "fractions": fractions(project).tolist(),
                "uiso": [p.atoms()[0].uiso for p in project.phases()],
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    run(args.base, args.outdir)
