#!/usr/bin/env python3
"""Test one specimen/profile effect from a converged GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(project: G2.G2Project) -> float:
    a = project.histogram(0).data["data"][1]
    y, w, c = map(np.asarray, (a[1], a[2], a[3]))
    return float(100 * np.sqrt(np.sum(w * (y - c) ** 2) / np.sum(w * y**2)))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    group = ap.add_mutually_exclusive_group(required=True)
    group.add_argument("--roughness", action="store_true")
    group.add_argument("--background", type=int)
    group.add_argument("--common-uiso", action="store_true")
    group.add_argument("--coords-heavy", action="store_true")
    group.add_argument("--coords-all", action="store_true")
    group.add_argument("--zero-range", action="store_true")
    group.add_argument("--fix-zero", type=float)
    group.add_argument("--orientation", nargs=4, metavar=("PHASE", "H", "K", "L"), type=int)
    args = ap.parse_args()
    dst = Path(args.output).resolve()
    dst.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(dst))
    h = p.histogram(0)
    p.set_Controls("cycles", 10)
    coordinate_mode = args.coords_heavy or args.coords_all
    if args.fix_zero is not None:
        h.data["Instrument Parameters"][0]["Zero"][1] = args.fix_zero
        h.data["Instrument Parameters"][0]["Zero"][2] = False
    elif args.zero_range:
        p.set_Controls("parmMin", -0.25, ":0:Zero")
        p.set_Controls("parmMax", 0.25, ":0:Zero")
        p.set_Controls("parmMin", -800.0, ":0:Shift")
        p.set_Controls("parmMax", 800.0, ":0:Shift")
    elif coordinate_mode:
        for phase in p.phases():
            for index, atom in enumerate(phase.atoms()):
                selected = args.coords_all or atom.element in {"Ba", "W"}
                atom.refinement_flags = "XU" if selected else "U"
                if selected:
                    for axis, coordinate in zip("xyz", atom.coordinates):
                        variable = f"{phase.id}::dA{axis}:{index}"
                        p.set_Controls("parmMin", coordinate - 0.003, variable)
                        p.set_Controls("parmMax", coordinate + 0.003, variable)
    elif args.common_uiso:
        for phase in p.phases():
            variables = []
            for index, atom in enumerate(phase.atoms()):
                atom.uiso = 0.01
                atom.refinement_flags = "U"
                variable = f"{phase.id}::AUiso:{index}"
                variables.append(variable)
                p.set_Controls("parmMin", 0.001, variable)
                p.set_Controls("parmMax", 0.03, variable)
            p.add_EquivConstr(variables, reloadIdx=True, override=True)
    elif args.background is not None:
        old = h.data["Background"][0]
        coeffs = list(old[3:]) + [0.0] * max(0, args.background - old[2])
        h.set_refinements({"Background": {"type": old[0], "no. coeffs": args.background,
                                           "coeffs": coeffs[:args.background], "refine": True}})
    elif args.roughness:
        h.data["Sample Parameters"]["SurfRoughA"] = [0.2, True]
        h.data["Sample Parameters"]["SurfRoughB"] = [0.1, True]
        p.set_Controls("parmMin", 0.05, ":0:SurfRoughA")
        p.set_Controls("parmMax", 0.6, ":0:SurfRoughA")
        p.set_Controls("parmMin", 0.02, ":0:SurfRoughB")
        p.set_Controls("parmMax", 0.5, ":0:SurfRoughB")
    else:
        phase_index, hh, kk, ll = args.orientation
        phase = p.phase(phase_index)
        po = phase.data["Histograms"][h.name]["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", 1.0, True, [hh, kk, ll]
        p.set_Controls("parmMin", 0.5, f"{phase.id}:0:MD")
        p.set_Controls("parmMax", 2.0, f"{phase.id}:0:MD")
    p.refine(printFile=str(dst.with_suffix(".lst")))
    if args.zero_range:
        p.set_Controls("cycles", 8)
        p.refine(printFile=str(dst.with_name(dst.stem + "_post.lst")))
    if coordinate_mode:
        for phase in p.phases():
            for atom in phase.atoms():
                atom.refinement_flags = "U"
        p.set_Controls("cycles", 6)
        p.refine(printFile=str(dst.with_name(dst.stem + "_post.lst")))
    p.save()
    print(json.dumps({
        "rwp": rwp(p),
        "sample": h.data["Sample Parameters"],
        "orientations": {ph.name: ph.data["Histograms"][h.name]["Pref.Ori."] for ph in p.phases()},
        "frozen": p.data["Controls"]["data"].get("parmFrozen", {}),
    }, default=str))


if __name__ == "__main__":
    main()
