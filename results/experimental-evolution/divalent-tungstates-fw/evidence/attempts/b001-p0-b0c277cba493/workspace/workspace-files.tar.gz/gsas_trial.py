#!/usr/bin/env python3
"""Build and refine a trial GSAS-II model for the supplied powder pattern."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def instrument_text() -> str:
    return (
        "#GSAS-II instrument parameter file for Cu Kalpha Bragg-Brentano data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.15;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )


def summarize(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    x, obs, weights, calc, background, diff = map(np.asarray, arrays[:6])
    denominator = float(np.sum(weights * obs**2))
    rwp = 100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / denominator)
    result = {
        "stage": label,
        "rwp_percent": float(rwp),
        "gsas_wR_percent": hist.get_wR(),
        "background": hist.data["Background"][0],
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "phases": {},
    }
    for phase in project.phases():
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "hap": phase.getHAPvalues(hist.name),
        }
    print(json.dumps(result, default=str))
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    parser.add_argument("cifs", nargs="+")
    parser.add_argument("--cycles", type=int, default=6)
    args = parser.parse_args()

    root = Path(args.out).resolve()
    root.mkdir(parents=True, exist_ok=True)
    observed = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
    x, y = observed.T
    sigma = np.sqrt(np.maximum(y, 1.0))
    data_path = root / "observed.xye"
    np.savetxt(data_path, np.column_stack([x, y, sigma]), fmt="%.8f %.8f %.8f")
    inst_path = root / "instrument.instprm"
    inst_path.write_text(instrument_text())

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(root / "trial.gpx"))
    phases = []
    for i, cif in enumerate(args.cifs):
        name = Path(cif).stem
        phases.append(project.add_phase(str(Path(cif).resolve()), phasename=name, fmthint="CIF"))
    hist = project.add_powder_histogram(
        str(data_path), str(inst_path), phases=phases, fmthint="xye"
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [float(np.percentile(y, 20)), 0, 0, 0, 0, 0, 0, 0],
                "refine": False,
            },
        }
    )
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][0] = 1.0
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])

    project.set_Controls("cycles", 0)
    project.refine(printFile=str(root / "stage0.lst"))
    summarize(project, "initial")

    project.set_Controls("cycles", args.cycles)
    hist.set_refinements({"Background": {"refine": True}})
    project.refine(printFile=str(root / "stage1.lst"))
    summarize(project, "background_scale")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine(printFile=str(root / "stage2.lst"))
    summarize(project, "cell_zero")

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.refine(printFile=str(root / "stage3.lst"))
    summarize(project, "cell_zero_shift")

    project.save()


if __name__ == "__main__":
    main()
