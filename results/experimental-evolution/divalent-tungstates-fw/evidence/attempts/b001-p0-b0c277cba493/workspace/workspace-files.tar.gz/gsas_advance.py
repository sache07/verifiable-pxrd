#!/usr/bin/env python3
"""Continue a trial GSAS-II refinement in conservative, inspectable stages."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(project: G2.G2Project) -> float:
    arr = project.histogram(0).data["data"][1]
    obs, weights, calc = map(np.asarray, (arr[1], arr[2], arr[3]))
    return float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2)))


def status(project: G2.G2Project, stage: str) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    row = {
        "stage": stage,
        "rwp": rwp(project),
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) >= 2},
        "sample": {k: v[0] for k, v in sample.items() if isinstance(v, list) and len(v) == 2 and isinstance(v[0], (int, float))},
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        row["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"][1],
            "mustrain": hap["Mustrain"][1],
            "preferred_orientation": hap["Pref.Ori."],
        }
    print(json.dumps(row, default=str), flush=True)


def run(project: G2.G2Project, stage: str, root: Path, cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(printFile=str(root / f"{stage}.lst"))
    status(project, stage)


def bound(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable)
    project.set_Controls("parmMax", high, variable)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--profile-only", action="store_true")
    args = parser.parse_args()
    src = Path(args.input).resolve()
    dst = Path(args.output).resolve()
    dst.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(src), newgpx=str(dst))
    hist = project.histogram(0)
    phases = project.phases()
    status(project, "loaded")

    # Keep all physically bounded profile terms in valid regions.
    for var, lo, hi in [
        (":0:U", 0.0, 100.0), (":0:W", 0.1, 100.0),
        (":0:X", 0.001, 20.0), (":0:SH/L", 0.001, 0.3),
        (":0:Polariz.", 0.0, 1.0), (":0:Zero", -1.0, 1.0),
        (":0:Shift", -2000.0, 2000.0),
    ]:
        bound(project, var, lo, hi)
    for phase in phases:
        pid = phase.id
        bound(project, f"{pid}:0:Scale", 0.0, 1000.0)
        bound(project, f"{pid}:0:Size;i", 0.01, 10.0)
        bound(project, f"{pid}:0:Mustrain;i", 0.0, 30000.0)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run(project, "profile_global", dst.parent)

    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, histograms=[hist])
    run(project, "size", dst.parent)

    for phase in phases:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, histograms=[hist])
    run(project, "size_strain", dst.parent)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    run(project, "polarization", dst.parent)
    if args.profile_only:
        project.save()
        status(project, "saved_profile_only")
        return

    # Refine symmetry-allowed coordinates, then isotropic ADPs. Atomic terms
    # are introduced only after the lattice/profile model has converged.
    for phase in phases:
        phase.set_refinements({"Atoms": {"all": "X"}})
    run(project, "coordinates", dst.parent, cycles=10)

    for phase in phases:
        phase.set_refinements({"Atoms": {"all": "XU"}})
        for index, atom in enumerate(phase.atoms()):
            bound(project, f"{phase.id}::AUiso:{index}", 0.0005, 0.05)
    run(project, "coordinates_uiso", dst.parent, cycles=10)

    project.save()
    status(project, "saved")


if __name__ == "__main__":
    main()
