#!/usr/bin/env python3
"""Freeze a selected refinement and export the required submission artifacts."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("source")
    args = ap.parse_args()
    root = Path.cwd()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(Path(args.source).resolve()), newgpx=str(root / "final.gpx")
    )
    previous_vary = project.data.get("Covariance", {}).get("data", {}).get("varyList", [])
    n_parameters = len(previous_vary)

    # A zero-cycle native GSAS-II calculation makes the stored profile and all
    # exports correspond exactly to the final atomic/profile parameters.
    project.set_Controls("cycles", 0)
    project.refine(printFile=str(root / "final.lst"))
    project.save()

    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    x, observed, weights, calculated, background, difference = map(
        np.asarray, arrays[:6]
    )
    # Recompute the difference explicitly to avoid depending on a display array.
    difference = observed - calculated
    np.savetxt(
        root / "fit.csv",
        np.column_stack([x, observed, calculated, difference]),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )

    loss = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    dof = max(1, len(x) - n_parameters)
    stats = {
        "rwp_percent": float(100 * np.sqrt(loss / denominator)),
        "rp_percent": float(100 * np.sum(np.abs(difference)) / np.sum(observed)),
        "rexp_percent": float(100 * np.sqrt(dof / denominator)),
        "goodness_of_fit": float(np.sqrt(loss / dof)),
        "chi_square": loss,
        "reduced_chi_square": float(loss / dof),
        "n_points": int(len(x)),
        "n_refined_parameters_last_cycle": int(n_parameters),
        "weighting": "1/max(observed_counts,1)",
    }

    labels = [
        ("Orthorhombic BaCO3 (witherite)", "BaCO3", "phase_baco3.cif", "COD 9010928"),
        ("Monoclinic WO3", "WO3", "phase_wo3.cif", "COD 2311041"),
    ]
    phases = project.phases()
    if len(phases) != len(labels):
        raise RuntimeError("Expected exactly two final phases")
    amounts = []
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        amounts.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
    total = sum(amounts)
    rows = []
    for phase, amount, (name, formula, cif_name, source) in zip(phases, amounts, labels):
        phase.export_CIF(str(root / cif_name))
        general = phase.data["General"]
        rows.append(
            {
                "name": name,
                "formula": formula,
                "space_group": general["SGData"]["SpGrp"].strip(),
                "cif_path": cif_name,
                "weight_fraction": float(amount / total),
                "reference_source": source,
            }
        )
    result = {
        "phases": rows,
        "fit_statistics": stats,
        "refinement_histogram": hist.name,
        "fraction_basis": "normalized over the modeled crystalline phases",
    }
    (root / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
