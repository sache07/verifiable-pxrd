#!/usr/bin/env python3
"""Remove comparison-only phases and replay the selected physical model."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--remove", action="append", default=[])
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve())
    )
    histogram = project.histograms()[0]
    for name in args.remove:
        if name not in project.data["Phases"]:
            raise KeyError(f"No phase named {name!r}")
        del project.data["Phases"][name]
        phase_names = project.names[-1]
        if name in phase_names:
            phase_names.remove(name)
        histogram.data.get("Reflection Lists", {}).pop(name, None)
        project.data.get("Restraints", {}).get("data", {}).pop(name, None)

    project.update_ids()
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["shift factor"] = 0.25
    controls["max cyc"] = 36
    project.save()

    # Reload to ensure the serialized tree and new phase IDs are self-consistent.
    project = G2.G2Project(gpxfile=str(args.output.resolve()))
    histogram = project.histograms()[0]
    for pidx, _phase in enumerate(project.phases()):
        project.set_Controls("parmMin", 0.0, f"{pidx}:0:Scale")
    project.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
    project.set_Controls("parmMin", 0.0, ":0:X")
    project.set_Controls("parmMin", 0.0, ":0:Z")
    project.set_Controls("parmMin", 0.0, "1:0:Mustrain;i")
    project.set_Controls("parmMin", 0.0, "2:0:Mustrain;i")
    project.set_Controls("parmMin", 0.05, "2:0:MD")
    project.set_Controls("parmMax", 20.0, "2:0:MD")
    project.save()
    for _ in range(2):
        project.refine()
        project.save()


if __name__ == "__main__":
    main()
