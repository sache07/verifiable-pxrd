#!/usr/bin/env python3
"""Matched replacement of the provisional WO3 phase in a refined project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_branch import summarize


LIBRARY = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/"
    "resources/b001-c05/cif"
)


def source_path(cod_id: str) -> Path:
    return LIBRARY / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("cod_id")
    parser.add_argument("--axis", default="0,0,1")
    parser.add_argument("--old-phase", type=int, default=1)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve())
    )
    project.set_Controls("cycles", 12)
    hist = project.histograms()[0]
    phases = project.phases()
    old = phases[args.old_phase]
    old_hap = old.data["Histograms"][hist.name]

    source = source_path(args.cod_id)
    phase = project.add_phase(
        str(source),
        phasename=f"WO3_COD_{args.cod_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    # Equalize the displacement model for a fair source comparison. Coordinates
    # remain exactly as deposited at this stage.
    cia = phase.data["General"]["AtomPtrs"][3]
    for atom in phase.atoms():
        atom.data[cia] = "I"
        atom.data[cia + 1] = 0.01
        atom.data[cia + 2 : cia + 8] = [0.0] * 6
        atom.refinement_flags = " "

    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [float(old_hap["Scale"][0]), True]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = float(old_hap["Mustrain"][1][0])
    hap["Mustrain"][2][0] = True
    axis = [int(v) for v in args.axis.split(",")]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = float(old_hap["Pref.Ori."][1])
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = axis

    # Disable the provisional source completely; it remains only so the branch
    # can be compared without rebuilding the rest of the project.
    old_hap["Use"] = False
    old_hap["Scale"][1] = False
    old.data["General"]["Cell"][0] = False
    for atom in old.atoms():
        atom.refinement_flags = " "

    pidx = len(project.phases()) - 1
    phase.set_refinements({"Cell": True})
    project.set_Controls("parmMin", 0.0, f"{pidx}:0:Scale")
    project.set_Controls("parmMin", 0.0, f"{pidx}:0:Mustrain;i")
    project.set_Controls("parmMin", 0.05, f"{pidx}:0:MD")
    project.set_Controls("parmMax", 20.0, f"{pidx}:0:MD")

    records = [summarize(project, "matched_swap_start")]
    for label in ("matched_swap_refine_1", "matched_swap_refine_2", "matched_swap_refine_3"):
        project.refine()
        project.save()
        records.append(summarize(project, label))
    project.save()
    (args.output.parent / "swap_history.json").write_text(
        json.dumps(records, indent=2, default=float) + "\n"
    )
    (args.output.parent / "source_provenance.json").write_text(
        json.dumps(
            {
                "cod_id": args.cod_id,
                "source_cif": str(source),
                "coordinates": "fixed deposited coordinates",
                "normalized_Uiso_A2": 0.01,
                "preferred_orientation_axis": axis,
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
