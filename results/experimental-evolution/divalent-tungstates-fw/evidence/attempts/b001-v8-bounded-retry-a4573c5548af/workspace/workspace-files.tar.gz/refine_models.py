#!/usr/bin/env python3
"""Build and refine candidate GSAS-II models for the public PXRD scan.

This is an analysis helper. It deliberately uses only inputs/pattern.csv,
inputs/metadata.json and explicitly selected CIFs from the public library.
"""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
LIBRARY = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/"
    "resources/b001-c05/cif"
)
SOURCES = {
    "CaWO4_scheelite_7219229": "7219229",
    "WO3_monoclinic_1528915": "1528915",
    "CaO_rocksalt_1563196": "1563196",
    "Ca3WO6_from_Ca2MgWO6_2013468": "2013468",
    "Ca3WO6_from_Ca2CoWO6_7222332": "7222332",
    "Ca3WO6_from_Ca2NiWO6_7222333": "7222333",
    "Ca3WO6_from_Sr2CaWO6_2104688": "2104688",
}


def source_path(cod_id: str) -> Path:
    return LIBRARY / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_files(work: Path) -> tuple[Path, Path]:
    work.mkdir(parents=True, exist_ok=True)
    data = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    xye = work / "pattern.xye"
    # No pointwise uncertainties were supplied. Poisson standard deviations
    # are the defensible approximation for raw photon counts.
    np.savetxt(xye, np.column_stack((data[:, 0], data[:, 1], np.sqrt(np.maximum(data[:, 1], 1.0)))), fmt="%.8f %.8f %.8f")
    inst = work / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file; Cu K-alpha starting model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.15;Polariz.:0.8;Azimuth:0.0\n"
        "U:5.0;V:0.0;W:5.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return xye, inst


def build_project(output: Path, phase_names: list[str], background_terms: int = 6) -> G2.G2Project:
    work = output.parent
    xye, inst = prepare_files(work)
    project = G2.G2Project(newgpx=str(output))
    histogram = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    histogram.SampleParameters["Type"] = "Bragg-Brentano"
    histogram.SampleParameters["Gonio. radius"] = 200.0
    # Keep the histogram scale fixed and let only phase scales vary. Refining
    # both creates a redundant scale degree of freedom.
    histogram.SampleParameters["Scale"] = [1.0, False]
    histogram.set_refinements(
        {
            "Limits": [float(histogram.data["data"][1][0][0]), float(histogram.data["data"][1][0][-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": background_terms,
                "coeffs": [1150.0, -500.0] + [0.0] * (background_terms - 2),
                "refine": False,
            },
        }
    )
    for name in phase_names:
        source = SOURCES[name]
        src = source_path(source) if source.isdigit() else ROOT / source
        if not src.exists():
            raise FileNotFoundError(src)
        copied = work / f"source_{name}.cif"
        shutil.copyfile(src, copied)
        phase = project.add_phase(str(copied), phasename=name, histograms=[histogram], fmthint="CIF")
        if name.startswith("Ca3WO6_from_"):
            # Preserve the parent's setting and coordinates in GSAS-II, while
            # collapsing every non-W cation site onto chemically required Ca.
            for i, atom in enumerate(phase.atoms()):
                if atom.element not in {"Ca", "W", "O"}:
                    atom.type = "Ca"
                    atom.label = f"Ca_mapped_{i + 1}"
            G2.SetupGeneral(phase.data, str(src.parent))
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][0] = 1.0
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 100.0
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = [0, 0, 1]
    project.set_Controls("cycles", 8)
    project.save()
    return project


def fractions(project: G2.G2Project, histname: str) -> dict[str, float]:
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][histname]
        if hap.get("Use", True) and hap["Scale"][0] > 0:
            raw[phase.name] = float(phase.data["General"]["Mass"] * hap["Scale"][0])
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()} if total > 0 else raw


def summary(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    out = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "residuals": dict(hist.residuals),
        "fractions": fractions(project, hist.name),
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
        "sample": {
            k: v[0]
            for k, v in sample.items()
            if isinstance(v, list) and len(v) > 1 and isinstance(v[0], (int, float))
        },
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    print(json.dumps(out, indent=2, default=float))
    return out


def refine_once(project: G2.G2Project, label: str) -> dict:
    project.refine()
    project.save()
    return summary(project, label)


def initial_refinement(output: Path, phase_names: list[str], background_terms: int = 6) -> None:
    G2.SetPrintLevel("warn")
    project = build_project(output, phase_names, background_terms)
    hist = project.histograms()[0]
    records = [summary(project, "built")]

    # Stable linear terms first.
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    records.append(refine_once(project, "background_scales"))

    # Phase cells, then the common angular correction.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    records.append(refine_once(project, "cells"))
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    records.append(refine_once(project, "zero"))

    # Common instrument peak shape. U/W/X are staged before V and axial
    # divergence to avoid a needlessly ill-conditioned first profile cycle.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    records.append(refine_once(project, "profile_uwx"))
    hist.set_refinements({"Instrument Parameters": ["V", "SH/L"]})
    records.append(refine_once(project, "profile_full"))

    (output.parent / "history.json").write_text(json.dumps(records, indent=2, default=float) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phases", nargs="+", choices=sorted(SOURCES))
    parser.add_argument("--background-terms", type=int, default=6)
    args = parser.parse_args()
    initial_refinement(args.output.resolve(), args.phases, args.background_terms)


if __name__ == "__main__":
    main()
