#!/usr/bin/env python3
"""Create element-mapped Ca3WO6 analogue candidates with provenance screens."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path(__file__).resolve().parent
LIBRARY = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/"
    "resources/b001-c05/cif"
)
PARENTS = {
    "Ca2MgWO6_2013468": "2013468",
    "Ca2CoWO6_7222332": "7222332",
    "Ca2NiWO6_7222333": "7222333",
    "Sr2CaWO6_2104688": "2104688",
}


def source_path(cod_id: str) -> Path:
    return LIBRARY / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    outdir = ROOT / ".tmp/analogues"
    outdir.mkdir(parents=True, exist_ok=True)
    reports = []
    for label, cod_id in PARENTS.items():
        src = source_path(cod_id)
        structure = Structure.from_file(src, primitive=False)
        substitutions = {
            el: "Ca"
            for el in structure.composition.elements
            if el.symbol not in {"W", "O", "Ca"}
        }
        structure.replace_species(substitutions)
        path = outdir / f"Ca3WO6_from_{label}.cif"
        CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(path)

        reread = Structure.from_file(path, primitive=False)
        analyzer = SpacegroupAnalyzer(reread, symprec=0.03)
        distances = np.asarray(reread.distance_matrix, float)
        np.fill_diagonal(distances, np.inf)
        report = {
            "model": str(path.relative_to(ROOT)),
            "parent_cod_id": cod_id,
            "parent_formula": label.rsplit("_", 1)[0],
            "transformation": {
                "element_mapping": {str(k): v for k, v in substitutions.items()},
                "coordinates": "unchanged from parent",
                "lattice": "unchanged from parent before refinement",
            },
            "composition": reread.composition.reduced_formula,
            "site_count": len(reread),
            "space_group": analyzer.get_space_group_symbol(),
            "space_group_number": analyzer.get_space_group_number(),
            "cell": {
                "a": reread.lattice.a,
                "b": reread.lattice.b,
                "c": reread.lattice.c,
                "alpha": reread.lattice.alpha,
                "beta": reread.lattice.beta,
                "gamma": reread.lattice.gamma,
                "volume": reread.volume,
            },
            "density_g_cm3": reread.density,
            "minimum_interatomic_distance_A": float(distances.min()),
            "charge_balance_basis": "3 Ca(II) + W(VI) + 6 O(-II) = 0",
            "physical_screen": "pass" if reread.composition.reduced_formula == "Ca3WO6" and distances.min() > 1.5 else "review",
        }
        reports.append(report)
    (outdir / "provenance_and_screen.json").write_text(json.dumps(reports, indent=2) + "\n")
    print(json.dumps(reports, indent=2))


if __name__ == "__main__":
    main()
