#!/usr/bin/env python3
"""Create the submission artifacts from the selected GSAS-II project."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


PHASE_INFO = {
    "CaWO4_scheelite_7219229": {
        "name": "CaWO4 (scheelite)",
        "formula": "CaWO4",
        "cif": "phase_CaWO4.cif",
        "source": "COD 7219229",
    },
    "Ca3WO6_from_Ca2MgWO6_2013468": {
        "name": "Ca3WO6 (ordered double-perovskite-type)",
        "formula": "Ca3WO6",
        "cif": "phase_Ca3WO6.cif",
        "source": "COD 2013468 Ca2MgWO6 parent, Mg mapped to Ca",
    },
    "WO3_COD_2311041": {
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif": "phase_WO3.cif",
        "source": "COD 2311041",
    },
}


def fraction_esds(project: G2.G2Project, histogram, phases) -> tuple[np.ndarray, np.ndarray]:
    masses = np.asarray([p.data["General"]["Mass"] for p in phases], float)
    scales = np.asarray([p.data["Histograms"][histogram.name]["Scale"][0] for p in phases], float)
    products = masses * scales
    total = float(products.sum())
    fractions = products / total

    covariance = project.data["Covariance"]["data"]
    names = [str(v) for v in covariance.get("varyList", [])]
    matrix = np.asarray(covariance.get("covMatrix", []), float)
    try:
        indices = [names.index(f"{i}:0:Scale") for i in range(len(phases))]
        scale_covariance = matrix[np.ix_(indices, indices)]
        jacobian = np.zeros((len(phases), len(phases)))
        for i in range(len(phases)):
            for j in range(len(phases)):
                jacobian[i, j] = (
                    masses[i] * (1.0 if i == j else 0.0) * total
                    - products[i] * masses[j]
                ) / total**2
        fraction_covariance = jacobian @ scale_covariance @ jacobian.T
        esds = np.sqrt(np.maximum(np.diag(fraction_covariance), 0.0))
    except (ValueError, IndexError):
        esds = np.full(len(phases), np.nan)
    return fractions, esds


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("workspace", type=Path)
    args = parser.parse_args()
    args.workspace.mkdir(parents=True, exist_ok=True)
    final_path = args.workspace / "final.gpx"

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.input.resolve()), newgpx=str(final_path.resolve())
    )
    histogram = project.histograms()[0]
    phases = project.phases()
    if [p.name for p in phases] != list(PHASE_INFO):
        raise RuntimeError(f"Unexpected final phase inventory: {[p.name for p in phases]}")
    if not all(p.data["Histograms"][histogram.name].get("Use", True) for p in phases):
        raise RuntimeError("Final project contains a disabled phase")

    # Remove only stale residual-summary keys left by the deleted comparison
    # phase. The fitted arrays, parameters and covariance are unchanged.
    metadata = histogram.data["data"][0]
    for key in list(metadata):
        match = re.match(r"^(\d+):", str(key))
        if match and int(match.group(1)) >= len(phases):
            metadata.pop(key)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.save()

    # Reload the exact submitted project before exporting all dependent files.
    project = G2.G2Project(gpxfile=str(final_path.resolve()))
    histogram = project.histograms()[0]
    phases = project.phases()
    fractions, fraction_esd = fraction_esds(project, histogram, phases)

    phase_rows = []
    for index, (phase, fraction, esd) in enumerate(zip(phases, fractions, fraction_esd)):
        info = PHASE_INFO[phase.name]
        cif_path = args.workspace / info["cif"]
        phase.export_CIF(str(cif_path.resolve()))
        cell = phase.get_cell()
        phase_rows.append(
            {
                "name": info["name"],
                "formula": info["formula"],
                "cif_path": info["cif"],
                "weight_fraction": float(fraction),
                "weight_fraction_esd": None if not np.isfinite(esd) else float(esd),
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cell": {k: float(v) for k, v in cell.items()},
                "structural_source": info["source"],
                "project_phase_index": index,
            }
        )

    arrays = np.asarray(histogram.data["data"][1], float)
    x, observed, _weights, calculated, background, _stored_difference = arrays
    difference = observed - calculated
    if np.any(~np.isfinite(calculated)) or np.any(calculated < 0):
        raise RuntimeError("Final calculated profile is nonfinite or negative")
    np.savetxt(
        args.workspace / "fit.csv",
        np.column_stack([x, observed, calculated, difference]),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt="%.10g",
    )

    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    residuals = histogram.residuals
    result = {
        "phases": phase_rows,
        "fraction_normalization": "normalized over the modeled crystalline phases",
        "unresolved_components": [],
        "refinement_histogram": histogram.name,
        "fit_statistics": {
            "rwp_percent": float(rvals.get("Rwp", histogram.get_wR())),
            "rp_percent": float(residuals.get("R", np.nan)),
            "background_subtracted_rwp_percent": float(residuals.get("wRb", np.nan)),
            "minimum_expected_rwp_percent": float(residuals.get("wRmin", np.nan)),
            "goodness_of_fit": float(rvals.get("GOF", np.nan)),
            "chi_squared": float(rvals.get("chisq", np.nan)),
            "n_observations": int(rvals.get("Nobs", len(x))),
            "n_refined_parameters": int(rvals.get("Nvars", 0)),
            "converged": bool(rvals.get("converged", False)),
            "durbin_watson": float(metadata.get("Durbin-Watson", np.nan)),
        },
        "calibration": {
            "zero_deg": float(histogram.data["Instrument Parameters"][0]["Zero"][1]),
            "wavelengths_angstrom": [
                float(histogram.data["Instrument Parameters"][0]["Lam1"][1]),
                float(histogram.data["Instrument Parameters"][0]["Lam2"][1]),
            ],
            "kalpha2_to_kalpha1_ratio": float(
                histogram.data["Instrument Parameters"][0]["I(L2)/I(L1)"][1]
            ),
        },
        "profile_files": {
            "observed_calculated_difference": "fit.csv",
            "gsasii_project": "final.gpx",
        },
        "notes": [
            "Fractions are Rietveld scale-derived and are not constrained by reaction stoichiometry.",
            "Reported ESDs are covariance-only counting-statistical estimates; model/source uncertainty is larger.",
        ],
    }
    (args.workspace / "result.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
