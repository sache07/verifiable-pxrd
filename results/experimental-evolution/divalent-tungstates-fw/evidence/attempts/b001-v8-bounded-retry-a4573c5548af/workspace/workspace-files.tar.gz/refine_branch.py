#!/usr/bin/env python3
"""Apply staged mechanism trials to an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def phase_fractions(project, histname):
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][histname]
        if hap.get("Use", True) and hap["Scale"][0] > 0:
            raw[phase.name] = float(phase.data["General"]["Mass"] * hap["Scale"][0])
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()} if total else raw


def correlations(project, threshold=0.85):
    cov = project.data.get("Covariance", {}).get("data", {})
    names = list(cov.get("varyList", []))
    matrix = np.asarray(cov.get("covMatrix", []), float)
    if matrix.shape != (len(names), len(names)) or not len(names):
        return []
    sd = np.sqrt(np.maximum(np.diag(matrix), 0))
    denom = np.outer(sd, sd)
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
    found = []
    for i in range(len(names)):
        for j in range(i):
            if abs(corr[i, j]) >= threshold:
                found.append([names[j], names[i], float(corr[i, j])])
    return sorted(found, key=lambda x: abs(x[2]), reverse=True)


def physical_profile(project):
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    current = lambda key: float(inst[key][1])
    theta = np.deg2rad(np.linspace(9.90343322, 100.09455322, 1000) / 2)
    tan = np.tan(theta)
    gaussian = current("U") * tan**2 + current("V") * tan + current("W")
    lorentzian = current("X") / np.cos(theta) + current("Y") * tan + current("Z")
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "scale": float(hap["Scale"][0]),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    return {
        "gaussian_min": float(gaussian.min()),
        "lorentzian_min": float(lorentzian.min()),
        "sh_l": current("SH/L"),
        "polarization": current("Polariz."),
        "phases": phases,
    }


def summarize(project, label):
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "residuals": dict(hist.residuals),
        "fractions": phase_fractions(project, hist.name),
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
        "sample": {
            k: v[0]
            for k, v in sample.items()
            if isinstance(v, list) and len(v) > 1 and isinstance(v[0], (int, float))
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "profile_screen": physical_profile(project),
        "vary_list": list(cov.get("varyList", [])),
        "variables": [float(v) for v in cov.get("variables", [])],
        "sigmas": [float(v) for v in cov.get("sig", [])],
        "correlations_abs_ge_0.85": correlations(project),
    }
    print(json.dumps(result, indent=2, default=float))
    return result


def set_texture(phase, histname, axis, start=1.0, refine=True):
    hap = phase.data["Histograms"][histname]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = float(start)
    hap["Pref.Ori."][2] = bool(refine)
    hap["Pref.Ori."][3] = list(axis)


def apply_operation(project, operation):
    hist = project.histograms()[0]
    phases = project.phases()
    fields = operation.split(":")
    name = fields[0]

    if name == "size":
        value = float(fields[1]) if len(fields) > 1 else 1.0
        for phase in phases:
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": value, "refine": True}})
    elif name == "strain":
        value = float(fields[1]) if len(fields) > 1 else 500.0
        for phase in phases:
            hap = phase.data["Histograms"][hist.name]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = value
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    elif name == "strain_phase":
        pidx = int(fields[1]); value = float(fields[2]) if len(fields) > 2 else 500.0
        hap = phases[pidx].data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = value
        phases[pidx].set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    elif name == "size_phase":
        pidx = int(fields[1]); value = float(fields[2]) if len(fields) > 2 else 1.0
        phases[pidx].set_HAP_refinements({"Size": {"type": "isotropic", "value": value, "refine": True}})
    elif name == "uniaxial_strain":
        pidx = int(fields[1]); axis = [int(v) for v in fields[2].split(",")]
        value = float(fields[3]) if len(fields) > 3 else 500.0
        hap = phases[pidx].data["Histograms"][hist.name]
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = value
        hap["Mustrain"][1][1] = value
        hap["Mustrain"][3] = axis
        phases[pidx].set_HAP_refinements({"Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}})
        project.set_Controls("parmMin", 0.0, f"{pidx}:0:Mustrain;i")
        project.set_Controls("parmMin", 0.0, f"{pidx}:0:Mustrain;a")
    elif name == "clear_size":
        for phase in phases: phase.clear_HAP_refinements({"Size": True})
    elif name == "clear_strain":
        for phase in phases: phase.clear_HAP_refinements({"Mustrain": True})
    elif name == "clear_strain_phase":
        pidx = int(fields[1])
        phases[pidx].clear_HAP_refinements({"Mustrain": True})
        phases[pidx].data["Histograms"][hist.name]["Mustrain"][1][0] = 0.0
    elif name == "clear_size_phase":
        pidx = int(fields[1])
        phases[pidx].clear_HAP_refinements({"Size": True})
    elif name == "disable_phase":
        pidx = int(fields[1])
        hap = phases[pidx].data["Histograms"][hist.name]
        hap["Use"] = False
        hap["Scale"][1] = False
        phases[pidx].data["General"]["Cell"][0] = False
        for atom in phases[pidx].atoms():
            atom.refinement_flags = " "
    elif name == "texture":
        pidx = int(fields[1]); axis = [int(v) for v in fields[2].split(",")]
        start = float(fields[3]) if len(fields) > 3 else 1.0
        set_texture(phases[pidx], hist.name, axis, start, True)
    elif name == "clear_texture":
        for phase in phases:
            phase.clear_HAP_refinements({"Pref.Ori.": True})
            phase.data["Histograms"][hist.name]["Pref.Ori."][1] = 1.0
    elif name == "clear_texture_phase":
        pidx = int(fields[1])
        phases[pidx].clear_HAP_refinements({"Pref.Ori.": True})
        phases[pidx].data["Histograms"][hist.name]["Pref.Ori."][1] = 1.0
    elif name == "polarization":
        if len(fields) > 1: hist.data["Instrument Parameters"][0]["Polariz."][1] = float(fields[1])
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif name == "roughness":
        a = float(fields[1]) if len(fields) > 1 else 0.1
        b = float(fields[2]) if len(fields) > 2 else 0.1
        hist.data["Sample Parameters"]["SurfRoughA"] = [a, True]
        hist.data["Sample Parameters"]["SurfRoughB"] = [b, True]
    elif name == "roughness_fix_a":
        a = float(fields[1]) if len(fields) > 1 else 0.0
        hist.data["Sample Parameters"]["SurfRoughA"] = [a, False]
        hist.data["Sample Parameters"]["SurfRoughB"][1] = True
    elif name == "roughness_fix_b":
        b = float(fields[1]) if len(fields) > 1 else 0.0
        hist.data["Sample Parameters"]["SurfRoughB"] = [b, False]
        hist.data["Sample Parameters"]["SurfRoughA"][1] = True
    elif name == "clear_roughness":
        hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    elif name == "transparency":
        value = float(fields[1]) if len(fields) > 1 else 0.001
        hist.data["Sample Parameters"]["Transparency"] = [value, True]
        project.set_Controls("parmMin", 0.0, ":0:Transparency")
    elif name == "clear_transparency":
        hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    elif name == "zero_only":
        hist.data["Instrument Parameters"][0]["Zero"][2] = True
        hist.data["Sample Parameters"]["Shift"][1] = False
        hist.data["Sample Parameters"]["Shift"][0] = 0.0
    elif name == "set_zero":
        hist.data["Instrument Parameters"][0]["Zero"][1] = float(fields[1])
        hist.data["Instrument Parameters"][0]["Zero"][2] = True
        hist.data["Sample Parameters"]["Shift"][1] = False
        hist.data["Sample Parameters"]["Shift"][0] = 0.0
    elif name == "shift_only":
        hist.data["Instrument Parameters"][0]["Zero"][2] = False
        hist.data["Instrument Parameters"][0]["Zero"][1] = 0.0
        if len(fields) > 1: hist.data["Sample Parameters"]["Shift"][0] = float(fields[1])
        hist.data["Sample Parameters"]["Shift"][1] = True
    elif name == "zero_shift":
        hist.data["Instrument Parameters"][0]["Zero"][2] = True
        if len(fields) > 1: hist.data["Sample Parameters"]["Shift"][0] = float(fields[1])
        hist.data["Sample Parameters"]["Shift"][1] = True
    elif name == "background":
        terms = int(fields[1]); kind = fields[2] if len(fields) > 2 else "chebyschev-1"
        kind = {
            "q2": "Q^2 power series",
            "qm2": "Q^-2 power series",
            "lin": "lin interpolate",
            "inv": "inv interpolate",
            "log": "log interpolate",
        }.get(kind, kind)
        hist.set_refinements({"Background": {"type": kind, "no. coeffs": terms, "refine": True}})
    elif name == "instrument":
        keys = fields[1].split(",")
        hist.set_refinements({"Instrument Parameters": keys})
    elif name == "fix_instrument":
        keys = fields[1].split(",")
        hist.clear_refinements({"Instrument Parameters": keys})
    elif name == "coords":
        pidx = int(fields[1]); elements = set(fields[2].split(","))
        for atom in phases[pidx].atoms():
            if atom.element in elements: atom.refinement_flags = "X"
    elif name == "coords_label":
        pidx = int(fields[1]); label = fields[2]
        atom = phases[pidx].atom(label)
        if atom is None: raise ValueError(f"No atom label {label} in phase {pidx}")
        atom.refinement_flags = atom.refinement_flags.replace("X", "") + "X"
    elif name == "coords_general_element":
        pidx = int(fields[1]); element = fields[2]
        cs = phases[pidx].data["General"]["AtomPtrs"][2]
        for atom in phases[pidx].atoms():
            if atom.element == element and str(atom.data[cs]).strip() == "1":
                atom.refinement_flags = atom.refinement_flags.replace("X", "") + "X"
    elif name == "fix_coords":
        for phase in phases:
            for atom in phase.atoms(): atom.refinement_flags = " "
    elif name == "restore_coords_phase":
        pidx = int(fields[1]); reference_path = fields[2]
        reference = G2.G2Project(gpxfile=reference_path)
        source = reference.phases()[pidx]
        target = phases[pidx]
        sx = source.data["General"]["AtomPtrs"][0]
        tx = target.data["General"]["AtomPtrs"][0]
        if len(source.data["Atoms"]) != len(target.data["Atoms"]):
            raise ValueError("Reference and target phase atom counts differ")
        for src, dst in zip(source.data["Atoms"], target.data["Atoms"]):
            dst[tx : tx + 3] = list(src[sx : sx + 3])
        for atom in target.atoms():
            atom.refinement_flags = atom.refinement_flags.replace("X", "")
    elif name == "uiso":
        pidx = int(fields[1]); elements = set(fields[2].split(","))
        cia = phases[pidx].data["General"]["AtomPtrs"][3]
        for aidx, atom in enumerate(phases[pidx].atoms()):
            if atom.element in elements:
                atom.data[cia] = "I"
                atom.refinement_flags = atom.refinement_flags.replace("U", "") + "U"
                project.set_Controls("parmMin", 0.0, f"{pidx}::AUiso:{aidx}")
    elif name == "normalize_uiso":
        pidx = int(fields[1]); value = float(fields[2])
        cia = phases[pidx].data["General"]["AtomPtrs"][3]
        for atom in phases[pidx].atoms():
            atom.data[cia] = "I"
            atom.data[cia + 1] = value
            atom.data[cia + 2:cia + 8] = [0.0] * 6
            atom.refinement_flags = atom.refinement_flags.replace("U", "")
    elif name == "uiso_site":
        pidx = int(fields[1]); aidx = int(fields[2])
        atom = phases[pidx].atoms()[aidx]
        cia = phases[pidx].data["General"]["AtomPtrs"][3]
        atom.data[cia] = "I"
        atom.refinement_flags = atom.refinement_flags.replace("U", "") + "U"
        project.set_Controls("parmMin", 0.0, f"{pidx}::AUiso:{aidx}")
    elif name == "cycles":
        project.set_Controls("cycles", int(fields[1]))
    elif name == "shift_factor":
        project.data["Controls"]["data"]["shift factor"] = float(fields[1])
    elif name == "soft_wo_oo_restraints":
        pidx = int(fields[1]); weight = float(fields[2]) if len(fields) > 2 else 10.0
        phase = phases[pidx]
        project.data["Restraints"]["data"][phase.name] = {
            "Bond": {"wtFactor": weight, "Range": 1.1, "Bonds": [], "Use": True}
        }
        w_atoms = [a for a in phase.atoms() if a.element == "W"]
        o_atoms = [a for a in phase.atoms() if a.element == "O"]
        phase.addDistRestraint(w_atoms, o_atoms, 1.91, factor=1.12, ESD=0.04)
        phase.addDistRestraint(o_atoms, o_atoms, 2.70, factor=1.10, ESD=0.06)
    elif name == "set_shl":
        hist.data["Instrument Parameters"][0]["SH/L"][1] = float(fields[1])
    elif name == "fix_shl":
        value = float(fields[1]) if len(fields) > 1 else 0.0005
        hist.data["Instrument Parameters"][0]["SH/L"][1] = value
        hist.data["Instrument Parameters"][0]["SH/L"][2] = False
        frozen = project.data["Controls"]["data"].get("parmFrozen", {})
        if "FrozenList" in frozen:
            frozen["FrozenList"] = [v for v in frozen["FrozenList"] if "SH/L" not in str(v)]
    elif name == "set_profile":
        keys = ["U", "V", "W", "X", "Y", "Z", "SH/L"]
        for key, value in zip(keys, map(float, fields[1].split(","))):
            hist.data["Instrument Parameters"][0][key][1] = value
    elif name == "physical_bounds":
        project.set_Controls("parmMin", 1e-6, ":0:SH/L")
        project.set_Controls("parmMin", 0.0, ":0:Polariz.")
        project.set_Controls("parmMax", 1.0, ":0:Polariz.")
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
        for pidx, _phase in enumerate(phases):
            project.set_Controls("parmMin", 1e-4, f"{pidx}:0:Size;i")
            project.set_Controls("parmMin", 0.0, f"{pidx}:0:Mustrain;i")
            project.set_Controls("parmMin", 0.05, f"{pidx}:0:MD")
            project.set_Controls("parmMax", 20.0, f"{pidx}:0:MD")
    else:
        raise ValueError(f"Unknown operation: {operation}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("operations", nargs="+")
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    project.set_Controls("cycles", 12)
    records = [summarize(project, "input")]
    for operation in args.operations:
        if operation == "refine":
            project.refine()
            project.save()
            records.append(summarize(project, f"refine_{len(records)}"))
        else:
            apply_operation(project, operation)
    project.save()
    (args.output.parent / f"{args.output.stem}_branch_history.json").write_text(
        json.dumps(records, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    main()
