#!/usr/bin/env python3
"""Add an indexed, element-mapped Ca3WO6 phase to a refined project."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_branch import summarize


LIBRARY = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/"
    "resources/b001-c05/cif"
)
PARENTS = {
    "mg": ("2013468", "Ca2MgWO6"),
    "co": ("7222332", "Ca2CoWO6"),
    "ni": ("7222333", "Ca2NiWO6"),
    "srca": ("2104688", "Sr2CaWO6"),
}


def source_path(cod_id):
    return LIBRARY / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def cell_volume(cell):
    a, b, c, alpha, beta, gamma = cell
    ca, cb, cg = (math.cos(math.radians(v)) for v in (alpha, beta, gamma))
    return a * b * c * math.sqrt(1 + 2 * ca * cb * cg - ca * ca - cb * cb - cg * cg)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("parent", choices=sorted(PARENTS))
    parser.add_argument("--scale", type=float, default=1.0)
    parser.add_argument("--cell", default="5.80093,5.53755,7.99976,90,90,90")
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histograms()[0]
    cod_id, formula = PARENTS[args.parent]
    src = source_path(cod_id)
    copied = args.output.parent / f"parent_{formula}_{cod_id}.cif"
    shutil.copyfile(src, copied)
    name = f"Ca3WO6_from_{formula}_{cod_id}"
    phase = project.add_phase(str(copied), phasename=name, histograms=[hist], fmthint="CIF")
    mapping = {}
    for i, atom in enumerate(phase.atoms()):
        if atom.element not in {"Ca", "W", "O"}:
            mapping[atom.element] = "Ca"
            atom.type = "Ca"
            atom.label = f"Ca_mapped_{i + 1}"
    G2.SetupGeneral(phase.data, str(src.parent))

    cell = [float(v) for v in args.cell.split(",")]
    if len(cell) != 6:
        raise ValueError("cell must contain a,b,c,alpha,beta,gamma")
    phase.data["General"]["Cell"][1:8] = cell + [cell_volume(cell)]
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [float(args.scale), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    project.set_Controls("cycles", 12)
    pidx = len(project.phases()) - 1
    project.set_Controls("parmMin", 0.0, f"{pidx}:0:Scale")
    project.set_Controls("parmMin", 1e-4, f"{pidx}:0:Size;i")
    project.set_Controls("parmMin", 0.0, f"{pidx}:0:Mustrain;i")
    project.save()

    records = [summarize(project, "added_indexed_fixed_cell")]
    project.refine(); project.save()
    records.append(summarize(project, "scale_with_indexed_cell"))
    phase.set_refinements({"Cell": True})
    project.refine(); project.save()
    records.append(summarize(project, "cell_and_scale"))
    project.refine(); project.save()
    records.append(summarize(project, "cell_and_scale_repeat"))
    provenance = {
        "parent_cod_id": cod_id,
        "parent_formula": formula,
        "transformation": {"element_mapping": mapping, "coordinates": "fixed parent", "starting_cell": cell},
        "indexed_reflections": {
            "011": 19.3463,
            "110": 22.0412,
            "112": 31.4515,
            "121_check": 37.4389,
            "220_check": 45.1323,
        },
    }
    (args.output.parent / "branch_history.json").write_text(json.dumps(records, indent=2, default=float) + "\n")
    (args.output.parent / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")


if __name__ == "__main__":
    main()
