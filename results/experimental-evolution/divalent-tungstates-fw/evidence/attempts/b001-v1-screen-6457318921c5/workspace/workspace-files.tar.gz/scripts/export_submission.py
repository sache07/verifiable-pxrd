#!/usr/bin/env python3
"""Save the selected GSAS-II branch and export its submitted phase model."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--project", type=Path, default=Path("final.gpx"))
    parser.add_argument("--cif", type=Path, default=Path("CaWO4_scheelite.cif"))
    parser.add_argument(
        "--summary", type=Path, default=Path("analysis/final_project_summary.json")
    )
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.source.resolve()), newgpx=str(args.project.resolve())
    )
    if len(project.histograms()) != 1 or len(project.phases()) != 1:
        raise ValueError("Selected final branch must contain exactly one histogram and phase")
    project.save(str(args.project.resolve()))
    phase = project.phase(0)
    hist = project.histogram(0)
    phase.export_CIF(str(args.cif.resolve()))

    arrays = hist.data["data"][1]
    x, y, weights, calculated, background = [
        np.asarray(value, float) for value in arrays[:5]
    ]
    difference = y - calculated
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi)
    chi_square = float(np.sum(weights[use] * difference[use] ** 2))
    denominator = float(np.sum(weights[use] * y[use] ** 2))
    rwp = 100.0 * math.sqrt(chi_square / denominator)
    rp = 100.0 * float(np.sum(np.abs(difference[use]))) / float(np.sum(y[use]))
    covariance = project.data.get("Covariance", {}).get("data", {})
    n_parameters = len(covariance.get("varyList", []))
    dof = int(np.count_nonzero(use)) - n_parameters
    hap = phase.data["Histograms"][hist.name]
    mass_scale = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
    payload = {
        "source_branch": str(args.source),
        "final_project": str(args.project),
        "histogram": hist.name,
        "phase": phase.name,
        "exported_cif": str(args.cif),
        "phase_mass_scale": mass_scale,
        "weight_fraction": 1.0,
        "fit": {
            "rwp_percent_cached": rwp,
            "rp_percent_cached": rp,
            "chi_square_cached": chi_square,
            "reduced_chi_square_cached": chi_square / dof,
            "goodness_of_fit_cached": math.sqrt(chi_square / dof),
            "n_points": int(np.count_nonzero(use)),
            "n_refined_parameters": n_parameters,
            "degrees_of_freedom": dof,
            "poisson_rwp_min_percent": float(hist.residuals["wRmin"]),
            "gsas_residuals": {
                key: float(value)
                for key, value in hist.residuals.items()
                if isinstance(value, (int, float, np.integer, np.floating))
            },
        },
        "cell": phase.get_cell(),
        "instrument": {
            key: float(hist.InstrumentParameters[key][1])
            for key in [
                "Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.",
                "U", "V", "W", "X", "Y", "Z", "SH/L",
            ]
            if key in hist.InstrumentParameters
        },
        "background": {
            "type": hist.Background[0][0],
            "coefficients": [float(value) for value in hist.Background[0][3:]],
            "minimum_cached_counts": float(np.min(background)),
            "maximum_cached_counts": float(np.max(background)),
            "auxiliary_peak_count": int(hist.Background[1].get("nPeaks", 0)),
        },
        "vary_list": list(covariance.get("varyList", [])),
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(payload, indent=2, allow_nan=False) + "\n")
    print(json.dumps(payload, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
