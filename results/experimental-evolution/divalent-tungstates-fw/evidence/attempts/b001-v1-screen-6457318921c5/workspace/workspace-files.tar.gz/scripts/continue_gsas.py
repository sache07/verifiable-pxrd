#!/usr/bin/env python3
"""Continue a saved GSAS-II refinement in a new project file."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--cycles", type=int, default=20)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve())
    )
    project.set_Controls("cycles", args.cycles)
    for index in range(args.repeats):
        project.refine(makeBack=False)
        hist = project.histogram(0)
        print(index + 1, hist.residuals)
    project.save(str(args.output))


if __name__ == "__main__":
    main()
