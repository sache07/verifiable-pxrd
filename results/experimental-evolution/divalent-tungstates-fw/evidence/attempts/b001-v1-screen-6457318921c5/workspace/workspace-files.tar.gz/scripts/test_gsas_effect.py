#!/usr/bin/env python3
"""Add one candidate effect to a converged GSAS-II branch and retest it."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_refine import snapshot


def configure(project, effect: str, axis: list[int]) -> None:
    hist = project.histogram(0)
    phase = project.phase(0)
    if effect == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif effect == "axial-divergence":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    elif effect == "roughness":
        hist.SampleParameters["SurfRoughA"] = [0.1, True]
        hist.SampleParameters["SurfRoughB"] = [0.1, True]
    elif effect == "texture":
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
    elif effect == "size":
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 1.0, "refine": True}},
            [hist],
        )
    elif effect == "strain":
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True
    elif effect == "oxygen-coordinates":
        for atom in phase.atoms():
            if atom.element == "O":
                atom.refinement_flags = "X"
    elif effect == "oxygen-uiso":
        for atom in phase.atoms():
            if atom.element == "O":
                atom.refinement_flags = "U"
    elif effect == "oxygen-xu":
        for atom in phase.atoms():
            if atom.element == "O":
                atom.refinement_flags = "XU"
    elif effect in {"oxygen-xzu", "oxygen-zu"}:
        for index, atom in enumerate(phase.atoms()):
            if atom.element != "O":
                continue
            x, y, z = atom.coordinates
            if effect == "oxygen-zu":
                x = 0.15202
            y = 0.01135
            atom.coordinates = (x, y, z)
            atom.refinement_flags = "XU"
            held = [f"{phase.id}::dAy:{index}"]
            if effect == "oxygen-zu":
                held.append(f"{phase.id}::dAx:{index}")
            project.add_HoldConstr(held)
    elif effect == "all-uiso":
        for atom in phase.atoms():
            atom.refinement_flags = "U"
    elif effect == "published-uiso":
        published = {"Ca": 0.01225, "W": 0.01098, "O": 0.02571}
        for atom in phase.atoms():
            atom.uiso = published[atom.element]
            atom.refinement_flags = ""
    else:
        raise ValueError(effect)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "--effect",
        required=True,
        choices=[
            "polarization",
            "axial-divergence",
            "roughness",
            "texture",
            "size",
            "strain",
            "oxygen-coordinates",
            "oxygen-uiso",
            "oxygen-xu",
            "oxygen-xzu",
            "oxygen-zu",
            "all-uiso",
            "published-uiso",
        ],
    )
    parser.add_argument("--axis", type=int, nargs=3, default=[0, 0, 1])
    parser.add_argument("--cycles", type=int, default=20)
    parser.add_argument("--repeats", type=int, default=3)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve())
    )
    project.set_Controls("cycles", args.cycles)
    before = snapshot(project, "before")
    configure(project, args.effect, args.axis)
    history = []
    for index in range(args.repeats):
        project.refine(makeBack=False)
        item = snapshot(project, f"refine {index + 1}")
        history.append(item)
        print(index + 1, item["rwp_percent"], item["gsas_residuals"])
    project.save(str(args.output))
    cif = args.output.with_suffix(".cif")
    project.phase(0).export_CIF(str(cif))
    payload = {
        "input": str(args.input),
        "effect": args.effect,
        "axis": args.axis,
        "before": before,
        "history": history,
        "final": snapshot(project, "final"),
        "exported_cif": str(cif),
    }
    args.output.with_suffix(".json").write_text(
        json.dumps(payload, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
