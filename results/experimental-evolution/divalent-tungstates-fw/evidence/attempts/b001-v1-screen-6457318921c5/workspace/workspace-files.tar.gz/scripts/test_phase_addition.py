#!/usr/bin/env python3
"""Test one normalized candidate phase against a converged GSAS-II residual."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from gsas_refine import set_negligible_phase_broadening, snapshot


def fractions(project) -> list[float]:
    hist = project.histogram(0)
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
    total = sum(masses)
    return [value / total for value in masses] if total else [float("nan")] * len(masses)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--initial-weight-fraction", type=float, default=0.01)
    parser.add_argument("--cycles", type=int, default=20)
    parser.add_argument("--repeats", type=int, default=3)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve())
    )
    project.set_Controls("cycles", args.cycles)
    hist = project.histogram(0)
    before = snapshot(project, "before")
    primary = project.phase(0)
    candidate = project.add_phase(
        str(args.candidate.resolve()),
        phasename=args.candidate.stem,
        histograms=[hist],
        fmthint="CIF",
    )
    set_negligible_phase_broadening(candidate, hist.name)
    primary_mass = float(primary.data["General"]["Mass"])
    candidate_mass = float(candidate.data["General"]["Mass"])
    primary_scale = float(primary.data["Histograms"][hist.name]["Scale"][0])
    f = args.initial_weight_fraction
    candidate.data["Histograms"][hist.name]["Scale"] = [
        primary_scale * primary_mass / candidate_mass * f / (1.0 - f),
        True,
    ]
    candidate.set_refinements({"Cell": False})
    history = []
    for index in range(args.repeats):
        project.refine(makeBack=False)
        item = snapshot(project, f"refine {index + 1}")
        item["weight_fractions"] = fractions(project)
        history.append(item)
        print(index + 1, item["rwp_percent"], item["weight_fractions"])
    project.save(str(args.output))
    final = snapshot(project, "final")
    final["weight_fractions"] = fractions(project)
    cov = project.data.get("Covariance", {}).get("data", {})
    scale_name = f"{candidate.id}:{hist.id}:Scale"
    if scale_name in cov.get("varyList", []):
        index = cov["varyList"].index(scale_name)
        final["candidate_scale_esd"] = float(cov["sig"][index])
        final["candidate_scale"] = float(cov["variables"][index])
        final["candidate_scale_z"] = (
            float(cov["variables"][index] / cov["sig"][index])
            if cov["sig"][index] else None
        )
    payload = {
        "input": str(args.input),
        "candidate": str(args.candidate),
        "before": before,
        "history": history,
        "final": final,
    }
    args.output.with_suffix(".json").write_text(
        json.dumps(payload, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
