#!/usr/bin/env python3
"""Normalize public COD candidates and apply the supplied physical screen.

This is deliberately separate from model selection.  Every candidate listed
here was selected from the public chemistry and observed peak families; no
generator realization or hidden case information is read.
"""

from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
SCREEN_SOURCE = ROOT / "learned/divalent-tungstates/scorer/src"
sys.path.insert(0, str(SCREEN_SOURCE))
from structure_metrics import physical_screen  # noqa: E402


CANDIDATES = {
    "cawo4_scheelite_7219229": {
        "cod_id": "7219229",
        "role": "same-composition scheelite source",
        "basis": "published",
    },
    "cawo4_scheelite_5910088_repaired": {
        "cod_id": "5910088",
        "role": "same-composition scheelite source",
        "basis": "repaired",
        "transformation": (
            "The legacy CIF redundantly lists symmetry-equivalent Ca, W and O "
            "sites, causing modern readers to sum occupancies above one. The "
            "first Ca, W and O representatives were expanded once in I41/a "
            "using the published cell and coordinates."
        ),
    },
    "cawo4_monoclinic_1546035": {
        "cod_id": "1546035",
        "role": "same-composition high-pressure polymorph check",
        "basis": "published",
    },
    "ca3wo6_1563081": {
        "cod_id": "1563081",
        "role": "Ca-rich product check",
        "basis": "published",
    },
    "ca_w_bronze_4030741": {
        "cod_id": "4030741",
        "role": "off-stoichiometric Ca-W-O check",
        "basis": "published",
    },
    "cao_1563196": {
        "cod_id": "1563196",
        "role": "residual precursor check",
        "basis": "published",
    },
    "wo3_monoclinic_2311041": {
        "cod_id": "2311041",
        "role": "residual precursor check",
        "basis": "published",
    },
    "wo3_triclinic_2106293": {
        "cod_id": "2106293",
        "role": "residual precursor polymorph check",
        "basis": "published",
    },
    "wo3_orthorhombic_2107312": {
        "cod_id": "2107312",
        "role": "residual precursor polymorph check",
        "basis": "published",
    },
}


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def parse_published(path: Path) -> Structure:
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        parser = CifParser(
            path,
            occupancy_tolerance=1.0,
            site_tolerance=1e-5,
            frac_tolerance=0,
        )
        structures = parser.parse_structures(primitive=False, on_error="raise")
    if len(structures) != 1:
        raise ValueError(f"Expected one model in {path}, found {len(structures)}")
    structure = structures[0]
    structure.remove_oxidation_states()
    return structure


def repaired_5910088() -> Structure:
    # Published values in COD 5910088. The atom list contains four redundant
    # representatives for each orbit; expanding one representative per orbit
    # restores Ca4W4O16 without changing the reported geometry.
    return Structure.from_spacegroup(
        "I4_1/a",
        Lattice.tetragonal(5.24, 11.38),
        ["Ca", "W", "O"],
        [[0.0, 0.0, 0.5], [0.0, 0.0, 0.0], [0.11, 0.25, 0.32]],
    )


def normalize(structure: Structure, path: Path) -> Structure:
    """Write and re-read a symmetry-normalized CIF, then return that model."""
    path.parent.mkdir(parents=True, exist_ok=True)
    writer = CifWriter(structure, symprec=1e-3, significant_figures=10)
    path.write_text(str(writer) + "\n")
    normalized = parse_published(path)
    if normalized.composition.almost_equals(structure.composition, rtol=0, atol=1e-6) is False:
        raise ValueError(f"Composition changed while normalizing {path}")
    return normalized


def main() -> None:
    out = ROOT / "analysis/candidates"
    records = []
    for name, info in CANDIDATES.items():
        source = cod_path(info["cod_id"])
        if name == "cawo4_scheelite_5910088_repaired":
            structure = repaired_5910088()
        else:
            structure = parse_published(source)
        target = out / f"{name}.cif"
        normalized = normalize(structure, target)
        audit = physical_screen(normalized)
        records.append(
            {
                **info,
                "name": name,
                "source_path": str(source),
                "normalized_cif": str(target.relative_to(ROOT)),
                "formula": normalized.composition.reduced_formula,
                "site_count": len(normalized),
                "density_g_cm3": float(normalized.density),
                "cell": {
                    "a": normalized.lattice.a,
                    "b": normalized.lattice.b,
                    "c": normalized.lattice.c,
                    "alpha": normalized.lattice.alpha,
                    "beta": normalized.lattice.beta,
                    "gamma": normalized.lattice.gamma,
                },
                "space_group": normalized.get_space_group_info(symprec=1e-3)[0],
                "physical_screen": audit,
            }
        )
    payload = {
        "screen_implementation": str(
            (SCREEN_SOURCE / "structure_metrics.py").relative_to(ROOT)
        ),
        "normalization": (
            "pymatgen full-cell parse, oxidation-state removal, CifWriter "
            "symmetry normalization at 0.001 A, and full re-parse"
        ),
        "records": records,
    }
    report = ROOT / "analysis/candidate_screen.json"
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(json.dumps(payload, indent=2, allow_nan=False) + "\n")
    for row in records:
        print(
            f"{row['name']}: {row['formula']} {row['space_group']} "
            f"screen={row['physical_screen']['status']}"
        )


if __name__ == "__main__":
    main()
