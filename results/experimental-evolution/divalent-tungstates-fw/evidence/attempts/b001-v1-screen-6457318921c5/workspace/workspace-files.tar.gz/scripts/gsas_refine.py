#!/usr/bin/env python3
"""Build and refine a low-flexibility GSAS-II powder model.

Run this with the GSAS-II Python interpreter. It is an analysis helper, not a
source of chemical candidates. Coordinates remain fixed unless the caller asks
for a later, explicit coordinate stage.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def instrument_text() -> str:
    # W=20 and X=0.5 give an approximately 0.11 degree starting FWHM, as
    # estimated directly from isolated observed peaks. Other values are neutral
    # starting values and are refined, not treated as calibration data.
    return (
        "# GSAS-II instrument parameter file; Cu K-alpha reflection starting model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:0.0;V:0.0;W:20.0;X:0.5;Y:0.0;Z:0.0;SH/L:0.02\n"
    )


def write_inputs(pattern: Path, work: Path) -> tuple[Path, Path]:
    x, y = np.loadtxt(pattern, delimiter=",", skiprows=1).T
    sigma = np.sqrt(np.maximum(y, 1.0))
    data = work / "pattern.xye"
    np.savetxt(data, np.column_stack((x, y, sigma)), fmt="%.10g")
    inst = work / "instrument.instprm"
    inst.write_text(instrument_text())
    return data, inst


def external_stats(hist) -> dict:
    arrays = hist.data["data"][1]
    x = np.asarray(arrays[0], float)
    y = np.asarray(arrays[1], float)
    w = np.asarray(arrays[2], float)
    yc = np.asarray(arrays[3], float)
    resid = y - yc
    use = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    loss = float(np.sum(w[use] * resid[use] ** 2))
    denom = float(np.sum(w[use] * y[use] ** 2))
    return {
        "rwp_percent": 100.0 * math.sqrt(loss / denom),
        "chi_square": loss,
        "n_points": int(np.count_nonzero(use)),
        "gsas_residuals": {
            key: float(value) for key, value in hist.residuals.items()
            if isinstance(value, (int, float, np.integer, np.floating))
        },
    }


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(hap["Scale"][0]),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    covariance = project.data.get("Covariance", {}).get("data", {})
    return {
        "label": label,
        **external_stats(hist),
        "instrument": {
            key: float(inst[key][1])
            for key in [
                "Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.",
                "U", "V", "W", "X", "Y", "Z", "SH/L",
            ]
            if key in inst
        },
        "sample": {
            key: (float(value[0]) if isinstance(value, list) else value)
            for key, value in sample.items()
            if key in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]
        },
        "background": {
            "type": hist.Background[0][0],
            "refine": bool(hist.Background[0][1]),
            "coefficients": [float(v) for v in hist.Background[0][3:]],
            "n_peaks": int(hist.Background[1].get("nPeaks", 0)),
        },
        "phases": phases,
        "vary_list": list(covariance.get("varyList", [])),
        "variables": [float(v) for v in covariance.get("variables", [])],
        "sigmas": [float(v) for v in covariance.get("sig", [])],
        "covariance": (
            np.asarray(covariance.get("covMatrix"), float).tolist()
            if covariance.get("covMatrix") is not None else None
        ),
    }


def set_negligible_phase_broadening(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1000.0
    hap["Size"][1][1] = 1000.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]


def refine(project, label: str, history: list[dict]) -> None:
    project.refine(makeBack=False)
    item = snapshot(project, label)
    history.append(item)
    print(
        f"{label:28s} Rwp={item['rwp_percent']:.5f}% "
        f"GSAS={item['gsas_residuals'].get('wR', float('nan')):.5f}%"
    )


def build(args) -> tuple[G2.G2Project, list[dict]]:
    work = args.output.parent / (args.output.stem + "_work")
    work.mkdir(parents=True, exist_ok=True)
    data, inst = write_inputs(args.pattern, work)
    project = G2.G2Project(newgpx=str(args.output))
    phases = [
        project.add_phase(str(path.resolve()), phasename=path.stem, fmthint="CIF")
        for path in args.cif
    ]
    hist = project.add_powder_histogram(
        str(data), str(inst), phases=phases, fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    # Keep the histogram scale fixed because phase/HAP scales carry the
    # quantitative intensity. Refining both creates an exact singularity.
    hist.SampleParameters["Scale"] = [1.0, False]
    for phase in phases:
        set_negligible_phase_broadening(phase, hist.name)

    project.set_Controls("cycles", args.cycles)
    median = float(np.median(hist.data["data"][1][1]))
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_terms,
                "coeffs": [median] + [0.0] * (args.background_terms - 1),
                "refine": True,
            }
        }
    )
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])

    history: list[dict] = [snapshot(project, "initial")]
    refine(project, "scale + background", history)

    # Refine lattice before angular calibration, then jointly once both are
    # close. Coordinates and ADPs remain fixed for source comparison.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "cells", history)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "zero + cells", history)

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine(project, "basic profile W X", history)

    if args.profile in {"common", "full"}:
        hist.set_refinements(
            {"Instrument Parameters": ["U", "V", "Y"]}
        )
        refine(project, "common profile U V W X Y", history)

    if args.profile == "full":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        refine(project, "add axial divergence", history)

    project.save(str(args.output))
    return project, history


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--cif", type=Path, action="append", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--background-terms", type=int, default=8)
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument(
        "--profile", choices=["basic", "common", "full"], default="common"
    )
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project, history = build(args)
    payload = {
        "pattern": str(args.pattern),
        "cifs": [str(v) for v in args.cif],
        "background_terms": args.background_terms,
        "profile": args.profile,
        "history": history,
        "final": snapshot(project, "final"),
    }
    args.output.with_suffix(".json").write_text(
        json.dumps(payload, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
