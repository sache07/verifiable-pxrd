#!/usr/bin/env python3
"""Scripted GSAS-II Rietveld comparison with fixed atomic coordinates.

Usage (under the GSAS-II Python environment):
    python gsas_refine.py CONFIG.json OUTPUT.gpx

The JSON config supplies ``phases`` as a list of ``{"name", "cif"}`` records.
This script is intentionally conservative: it refines background, scales,
angular calibration, cells and common profile terms in staged passes while
leaving all atomic coordinates fixed. More specialized specimen and phase
profile trials are performed in later scripts from the saved projects.
"""

from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


def write_instrument(path: Path, cfg: dict) -> None:
    inst = cfg.get("instrument", {})
    path.write_text(
        "#GSAS-II Cu K-alpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        f"Zero:{inst.get('Zero', 0.18)};Polariz.:{inst.get('Polariz.', 0.7)};Azimuth:0.0\n"
        f"U:{inst.get('U', 5.0)};V:{inst.get('V', 0.0)};W:{inst.get('W', 5.0)};"
        f"X:{inst.get('X', 1.0)};Y:{inst.get('Y', 0.0)};Z:{inst.get('Z', 0.0)};"
        f"SH/L:{inst.get('SH/L', 0.02)}\n"
    )


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    masses = []
    phase_rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"])
        scale = float(hap["Scale"][0])
        masses.append(max(0.0, mass * scale))
        phase_rows.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": scale,
                "mass_times_scale": mass * scale,
            }
        )
    total = sum(masses)
    for row, value in zip(phase_rows, masses):
        row["weight_fraction"] = value / total if total > 0 else None
    inst = {
        key: value[1] if isinstance(value, list) and len(value) > 1 else value
        for key, value in hist.InstrumentParameters.items()
    }
    sample = {
        key: value[0] if isinstance(value, list) else value
        for key, value in hist.SampleParameters.items()
        if key in {"Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Scale", "Gonio. radius"}
    }
    return {
        "stage": label,
        "residuals": hist.residuals,
        "instrument": inst,
        "sample": sample,
        "background": hist.Background[0],
        "phases": phase_rows,
    }


def run_refinement(project: G2.G2Project, history: list[dict], label: str) -> None:
    project.refine()
    history.append(snapshot(project, label))


def main(config_path: str, output_path: str) -> None:
    cfg = json.loads(Path(config_path).read_text())
    output = Path(output_path).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    inst_path = output.with_suffix(".instprm")
    write_instrument(inst_path, cfg)

    G2.SetPrintLevel(cfg.get("print_level", "warn"))
    project = G2.G2Project(newgpx=str(output))
    phases = []
    for record in cfg["phases"]:
        phases.append(
            project.add_phase(
                str(Path(record["cif"]).resolve()),
                phasename=record["name"],
                fmthint="CIF",
            )
        )
    hist = project.add_powder_histogram(
        str(Path(cfg.get("pattern", "pattern.xye")).resolve()),
        str(inst_path),
        phases=phases,
        fmthint="xye",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = float(cfg.get("goniometer_radius_mm", 200.0))
    # A freely refined histogram scale is exactly degenerate with all phase
    # scales and adds no physical information for a single-pattern fit.
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [float(cfg.get("initial_shift_um", 0.0)), False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({
        "Limits": [float(cfg.get("low", 9.90343322)), float(cfg.get("high", 100.09455322))],
        "Background": {
            "type": cfg.get("background_type", "chebyschev-1"),
            "no. coeffs": int(cfg.get("background_order", 8)),
            "coeffs": (
                list(cfg.get("background_coeffs", [1100.0, -350.0, 180.0, -80.0, 30.0]))
                + [0.0] * int(cfg.get("background_order", 8))
            )[: int(cfg.get("background_order", 8))],
            "refine": True,
        },
    })
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][0] = float(cfg.get("initial_phase_scale", 0.05))
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = float(cfg.get("initial_size_um", 1.0))
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    project.set_Controls("cycles", int(cfg.get("cycles", 8)))
    history: list[dict] = []

    # Low-flexibility matched comparison sequence.
    run_refinement(project, history, "background_scales")
    branch = cfg.get("calibration_branch", "zero")
    if branch in {"zero", "joint"}:
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    if branch in {"shift", "joint"}:
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_refinement(project, history, f"calibration_{branch}")
    for phase in phases:
        phase.set_refinements({"Cell": True})
    run_refinement(project, history, "cells")
    hist.set_refinements({
        "Instrument Parameters": cfg.get("common_profile_parameters", ["U", "W", "X", "SH/L"])
    })
    run_refinement(project, history, "common_profile")
    # Re-equilibrate the same retained model once more.
    run_refinement(project, history, "common_profile_restart")

    project.save(str(output))
    report = {
        "config": cfg,
        "output": str(output),
        "history": history,
        "final": snapshot(project, "final"),
        "covariance": {
            "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
            "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
            "sig": np.asarray(project.data.get("Covariance", {}).get("data", {}).get("sig", [])).tolist(),
        },
    }
    output.with_suffix(".json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
