#!/usr/bin/env python3
"""Prepare public-library comparison models for the ZnO/WO3 pattern.

Every generated CIF retains a provenance comment naming its COD parent.  The
only structural transformation performed here is a chemically explicit site
substitution; cells and fractional coordinates are otherwise unchanged.
"""

from __future__ import annotations

from pathlib import Path
import shutil

import numpy as np
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/"
    "resources/b001-c04/cif"
)
OUT = Path("candidates")


def source_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def copy_source(cod_id: str, name: str) -> None:
    src = source_path(cod_id)
    if not src.exists():
        raise FileNotFoundError(src)
    dst = OUT / name
    shutil.copyfile(src, dst)
    with dst.open("a") as stream:
        stream.write(f"\n# Public filtered-COD parent: COD {cod_id}; unchanged copy.\n")


def substituted(cod_id: str, name: str, mapping: dict[str, str]) -> None:
    src = source_path(cod_id)
    structure = Structure.from_file(src, primitive=False)
    changed: list[str] = []
    for index, site in enumerate(structure):
        symbols = {element.symbol for element in site.species.elements}
        replacements = {mapping[symbol] for symbol in symbols if symbol in mapping}
        retained = {symbol for symbol in symbols if symbol not in mapping}
        if replacements:
            if retained and retained != replacements:
                # Mixed parent sites such as Zn/Cu collapse onto one Zn site.
                if len(replacements | retained) != 1:
                    raise ValueError(f"Ambiguous mixed-site substitution at {site}")
            target = next(iter(replacements))
            structure.replace(index, target)
            changed.append(f"{'+'.join(sorted(symbols))}->{target}")
    dst = OUT / name
    text = str(CifWriter(structure, symprec=1e-3, refine_struct=False))
    provenance = (
        f"# Public filtered-COD parent: COD {cod_id}.\n"
        f"# Analogue-derived transformation: {', '.join(sorted(set(changed)))}; "
        "fractional coordinates and parent cell retained.\n"
    )
    dst.write_text(text + "\n" + provenance)


def write_pattern() -> None:
    raw = np.genfromtxt("inputs/pattern.csv", delimiter=",", names=True)
    x = raw["two_theta_deg"]
    y = raw["intensity"]
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt("pattern.xye", np.column_stack([x, y, sigma]), fmt="%.8f %.8f %.8f")


def main() -> None:
    OUT.mkdir(exist_ok=True)

    # Wolframite finalists: closest Zn-rich mixed parent plus chemically and
    # topologically equivalent independent divalent-metal tungstates.
    substituted("9005254", "znwo4_from_9005254.cif", {"Cu": "Zn"})
    substituted("1520642", "znwo4_from_1520642.cif", {"Cd": "Zn"})
    substituted("9013902", "znwo4_from_9013902.cif", {"Mg": "Zn"})
    substituted("1520200", "znwo4_from_1520200.cif", {"Mn": "Zn"})

    # Precursors and tungsten-oxide polymorph/stoichiometry alternatives.
    for cod_id, name in [
        ("9004178", "zno_wurtzite_9004178.cif"),
        ("1537875", "zno_zincblende_1537875.cif"),
        ("1534836", "zno_rocksalt_1534836.cif"),
        ("2311041", "wo3_2311041.cif"),
        ("2106293", "wo3_2106293.cif"),
        ("2107312", "wo3_2107312.cif"),
        ("1563541", "wo3_1563541.cif"),
        ("1528915", "wo3_1528915_diagnostic.cif"),
        ("1538315", "w18o49_1538315.cif"),
        ("1538317", "w10o29_1538317.cif"),
        ("1548686", "wo2_1548686.cif"),
    ]:
        copy_source(cod_id, name)

    # Ordered multication parents explicitly tested after collapsing their
    # distinct alkaline-earth and Zn sites to Zn-rich candidate frameworks.
    substituted("1537302", "zn3wo6_from_ba2znwo6_1537302.cif", {"Ba": "Zn"})
    substituted("1541623", "zn3wo6_from_sr2znwo6_1541623.cif", {"Sr": "Zn"})
    substituted("1563083", "zn3wo6_from_sr2znwo6_1563083.cif", {"Sr": "Zn"})

    write_pattern()


if __name__ == "__main__":
    main()
