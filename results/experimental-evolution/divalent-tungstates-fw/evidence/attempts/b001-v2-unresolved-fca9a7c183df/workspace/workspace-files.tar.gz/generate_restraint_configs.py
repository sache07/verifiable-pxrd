#!/usr/bin/env python3
"""Create parent-geometry restrained WO3 oxygen-coordinate trials."""

from pathlib import Path
import json


BONDS = [
    ("W1", "O3", 1.7145),
    ("W1", "O6", 1.7904),
    ("W1", "O1", 1.8893),
    ("W1", "O2", 1.9063),
    ("W1", "O5", 2.1296),
    ("W1", "O3", 2.1588),
    ("W2", "O5", 1.7509),
    ("W2", "O4", 1.8480),
    ("W2", "O2", 1.8523),
    ("W2", "O1", 1.9252),
    ("W2", "O4", 2.0137),
    ("W2", "O6", 2.1539),
]

OO_BONDS = [
    ("O2", "O4", 2.53904), ("O6", "O2", 2.56024),
    ("O3", "O1", 2.59560), ("O1", "O4", 2.62392),
    ("O5", "O1", 2.63179), ("O2", "O5", 2.65782),
    ("O6", "O4", 2.67461), ("O2", "O5", 2.69128),
    ("O6", "O4", 2.69389), ("O2", "O3", 2.69643),
    ("O5", "O3", 2.70124), ("O3", "O1", 2.70373),
    ("O2", "O4", 2.70830), ("O5", "O3", 2.71411),
    ("O2", "O3", 2.72507), ("O6", "O3", 2.72958),
    ("O6", "O2", 2.73364), ("O5", "O4", 2.74385),
    ("O6", "O1", 2.75356), ("O6", "O1", 2.77857),
    ("O5", "O1", 2.79752), ("O1", "O4", 2.80402),
    ("O5", "O4", 2.81627), ("O6", "O3", 2.81976),
]


def main() -> None:
    root = Path("configs/restraints")
    root.mkdir(parents=True, exist_ok=True)
    for esd in [0.02, 0.05, 0.10, 0.20]:
        payload = {
            "phases": {"WO3": {"atom_flags": {"W": "X", "O": "X"}}},
            "distance_restraints": {
                "WO3": {
                    "weight": 1.0,
                    "esd": esd,
                    "bonds": [
                        {
                            "origin": [origin],
                            "target": [target],
                            "distance": distance,
                            "search_factor": 1.012,
                        }
                        for origin, target, distance in BONDS
                    ],
                }
            },
            "cycles": 15,
            "restarts": 6,
            "print_level": "warn",
        }
        (root / f"wo3_parent_bonds_esd_{int(esd * 100):02d}.json").write_text(
            json.dumps(payload, indent=2) + "\n"
        )
        all_payload = json.loads(json.dumps(payload))
        all_payload["distance_restraints"]["WO3"]["bonds"].extend(
            {
                "origin": [origin],
                "target": [target],
                "distance": distance,
                "search_factor": 1.003,
            }
            for origin, target, distance in OO_BONDS
        )
        (root / f"wo3_all_bonds_esd_{int(esd * 100):02d}.json").write_text(
            json.dumps(all_payload, indent=2) + "\n"
        )


if __name__ == "__main__":
    main()
