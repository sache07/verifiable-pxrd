#!/usr/bin/env python3
"""Export every phase from one or more GSAS-II projects."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def main(output_dir: str, *projects: str) -> None:
    root = Path(output_dir)
    root.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    for project_path in projects:
        path = Path(project_path)
        project = G2.G2Project(gpxfile=str(path.resolve()))
        for phase in project.phases():
            safe = phase.name.replace(" ", "_").replace("/", "_")
            phase.export_CIF(str(root / f"{path.stem}__{safe}.cif"))


if __name__ == "__main__":
    main(sys.argv[1], *sys.argv[2:])
