#!/usr/bin/env python3
"""Generate systematic crystallographic-axis trial configurations."""

from pathlib import Path
import json


OUT = Path("configs/generated")
AXES = {
    "100": [1, 0, 0],
    "010": [0, 1, 0],
    "001": [0, 0, 1],
    "110": [1, 1, 0],
    "111": [1, 1, 1],
}
PHASES = {"zwo": "ZnWO4", "zno": "ZnO", "wo3": "WO3"}
STRAIN_START = {"ZnWO4": 3600.0, "ZnO": 250.0, "WO3": 1100.0}
SIZE_START = {"ZnWO4": 0.13, "WO3": 0.45}


def save(name: str, payload: dict) -> None:
    (OUT / f"{name}.json").write_text(json.dumps(payload, indent=2) + "\n")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    for slug, phase in PHASES.items():
        for axis_name, axis in AXES.items():
            strain = STRAIN_START[phase]
            save(
                f"uniaxial_strain_{slug}_{axis_name}",
                {
                    "phases": {
                        phase: {
                            "mustrain": {
                                "type": "uniaxial",
                                "equatorial": strain,
                                "axial": strain,
                                "direction": axis,
                                "refine": True,
                            }
                        }
                    },
                    "cycles": 10,
                    "restarts": 2,
                    "print_level": "warn",
                },
            )
            save(
                f"texture_{slug}_{axis_name}",
                {
                    "phases": {
                        phase: {
                            "texture": {"axis": axis, "ratio": 1.02, "refine": True}
                        }
                    },
                    "cycles": 10,
                    "restarts": 2,
                    "print_level": "warn",
                },
            )
    for slug, phase in {"zwo": "ZnWO4", "wo3": "WO3"}.items():
        for axis_name, axis in AXES.items():
            size = SIZE_START[phase]
            save(
                f"uniaxial_size_{slug}_{axis_name}",
                {
                    "phases": {
                        phase: {
                            "size": {
                                "type": "uniaxial",
                                "equatorial": size,
                                "axial": size,
                                "direction": axis,
                                "refine": True,
                            }
                        }
                    },
                    "cycles": 10,
                    "restarts": 2,
                    "print_level": "warn",
                },
            )


if __name__ == "__main__":
    main()
