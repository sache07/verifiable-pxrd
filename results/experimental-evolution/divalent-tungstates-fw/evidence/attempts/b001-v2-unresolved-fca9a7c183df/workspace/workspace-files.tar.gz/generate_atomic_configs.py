#!/usr/bin/env python3
"""Generate selective coordinate and isotropic-ADP screening configs."""

from pathlib import Path
import json


OUT = Path("configs/atomic")


def save(name: str, phase: str, selector: dict[str, str], restarts: int = 3) -> None:
    payload = {
        "phases": {phase: {"atom_flags": selector}},
        "cycles": 12,
        "restarts": restarts,
        "print_level": "warn",
    }
    (OUT / f"{name}.json").write_text(json.dumps(payload, indent=2) + "\n")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    for label in ["Zn0", "W1", "O1", "O2"]:
        save(f"coord_zwo_{label.lower()}", "ZnWO4", {label: "X"})
        save(f"uiso_zwo_{label.lower()}", "ZnWO4", {label: "U"})
    save("coord_zwo_oall", "ZnWO4", {"O": "X"})
    save("uiso_zwo_oall", "ZnWO4", {"O": "U"})

    save("coord_zno_zn", "ZnO", {"Zn": "X"})
    save("coord_zno_o", "ZnO", {"O": "X"})

    for label in ["W1", "W2", "O1", "O2", "O3", "O4", "O5", "O6"]:
        save(f"coord_wo3_{label.lower()}", "WO3", {label: "X"})
        save(f"uiso_wo3_{label.lower()}", "WO3", {label: "U"})
    save("coord_wo3_wall", "WO3", {"W": "X"})
    save("coord_wo3_oall", "WO3", {"O": "X"})
    save("uiso_wo3_wall", "WO3", {"W": "U"})
    save("uiso_wo3_oall", "WO3", {"O": "U"})

    # Late-stage Uiso trials that preserve already-supported coordinate flags.
    save("cumu_uiso_zwo_zn0", "ZnWO4", {"Zn0": "U"})
    save("cumu_uiso_zwo_w1", "ZnWO4", {"W1": "XU"})
    save("cumu_uiso_zwo_o1", "ZnWO4", {"O1": "XU"})
    save("cumu_uiso_zwo_o2", "ZnWO4", {"O2": "XU"})
    save("cumu_uiso_zwo_oall", "ZnWO4", {"O": "XU"})
    save("cumu_uiso_wo3_w1", "WO3", {"W1": "XU"})
    save("cumu_uiso_wo3_w2", "WO3", {"W2": "XU"})
    save("cumu_uiso_wo3_wall", "WO3", {"W": "XU"})
    for label in ["O1", "O2", "O3", "O4", "O5", "O6"]:
        save(f"cumu_uiso_wo3_{label.lower()}", "WO3", {label: "U"})
    save("cumu_uiso_wo3_oall", "WO3", {"O": "U"})


if __name__ == "__main__":
    main()
