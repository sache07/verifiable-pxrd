#!/usr/bin/env python3
"""Apply a controlled mechanism trial to an existing GSAS-II project."""

from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


def phase_fraction_rows(project: G2.G2Project, hist) -> list[dict]:
    rows, products = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        scale = float(hap["Scale"][0])
        product = scale * float(phase.data["General"]["Mass"])
        products.append(max(product, 0.0))
        rows.append(
            {
                "name": phase.name,
                "scale": scale,
                "cell": phase.get_cell(),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": atom.label,
                        "type": atom.type,
                        "coordinates": list(atom.coordinates),
                        "occupancy": atom.occupancy,
                        "adp_flag": atom.adp_flag,
                        "ADP": atom.ADP,
                        "refinement_flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    total = sum(products)
    for row, product in zip(rows, products):
        row["weight_fraction"] = product / total if total else None
    return rows


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    inst = {
        key: value[1] if isinstance(value, list) and len(value) > 1 else value
        for key, value in hist.InstrumentParameters.items()
    }
    sample = {
        key: value[0] if isinstance(value, list) else value
        for key, value in hist.SampleParameters.items()
        if key in {"Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Scale", "Gonio. radius"}
    }
    return {
        "stage": label,
        "residuals": hist.residuals,
        "instrument": inst,
        "sample": sample,
        "background": hist.Background,
        "phases": phase_fraction_rows(project, hist),
        "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    }


def configure_phase(phase, hist, action: dict) -> None:
    hap = phase.data["Histograms"][hist.name]
    if "use" in action:
        hap["Use"] = bool(action["use"])
    if "scale_refine" in action:
        hap["Scale"][1] = bool(action["scale_refine"])
    if "cell_refine" in action:
        phase.set_refinements({"Cell": bool(action["cell_refine"])})

    if "size" in action:
        spec = action["size"]
        typ = spec.get("type", "isotropic")
        value = float(spec.get("value", 1.0))
        hap["Size"][0] = typ
        if typ == "isotropic":
            hap["Size"][1][0] = value
            hap["Size"][2] = [bool(spec.get("refine", True)), False, False]
        elif typ == "uniaxial":
            hap["Size"][1][0] = float(spec.get("equatorial", value))
            hap["Size"][1][1] = float(spec.get("axial", value))
            hap["Size"][3] = list(map(int, spec.get("direction", [0, 0, 1])))
            refine = spec.get("refine", True)
            hap["Size"][2][0] = bool(refine)
            hap["Size"][2][1] = bool(refine)
        else:
            raise ValueError(f"Unsupported size type {typ}")
    if action.get("clear_size"):
        hap["Size"][2] = [False, False, False]
        hap["Size"][5] = [False] * len(hap["Size"][5])

    if "mustrain" in action:
        spec = action["mustrain"]
        typ = spec.get("type", "isotropic")
        value = float(spec.get("value", 1000.0))
        hap["Mustrain"][0] = typ
        if typ == "isotropic":
            hap["Mustrain"][1][0] = value
            hap["Mustrain"][2] = [bool(spec.get("refine", True)), False, False]
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        elif typ == "uniaxial":
            hap["Mustrain"][1][0] = float(spec.get("equatorial", value))
            hap["Mustrain"][1][1] = float(spec.get("axial", value))
            hap["Mustrain"][3] = list(map(int, spec.get("direction", [0, 0, 1])))
            refine = bool(spec.get("refine", True))
            hap["Mustrain"][2][0] = refine
            hap["Mustrain"][2][1] = refine
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        else:
            raise ValueError(f"Unsupported microstrain type {typ}")
    if action.get("clear_mustrain"):
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])

    if "texture" in action:
        spec = action["texture"]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = float(spec.get("ratio", 1.0))
        hap["Pref.Ori."][2] = bool(spec.get("refine", True))
        hap["Pref.Ori."][3] = list(map(int, spec.get("axis", [0, 0, 1])))
    if action.get("clear_texture"):
        hap["Pref.Ori."][2] = False

    if "atom_flags" in action:
        for atom in phase.atoms():
            selector = action["atom_flags"]
            if atom.label in selector:
                atom.refinement_flags = selector[atom.label]
            elif atom.element in selector:
                atom.refinement_flags = selector[atom.element]
            elif "all" in selector:
                atom.refinement_flags = selector["all"]
    if "atom_adp_values" in action:
        selector = action["atom_adp_values"]
        for atom in phase.atoms():
            if atom.label in selector:
                atom.ADP = selector[atom.label]
            elif atom.element in selector:
                atom.ADP = selector[atom.element]
            elif "all" in selector:
                atom.ADP = selector["all"]


def main(config_path: str, input_path: str, output_path: str) -> None:
    cfg = json.loads(Path(config_path).read_text())
    output = Path(output_path).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel(cfg.get("print_level", "warn"))
    project = G2.G2Project(gpxfile=str(Path(input_path).resolve()), newgpx=str(output))
    hist = project.histograms()[0]

    for name in cfg.get("instrument_clear", []):
        hist.InstrumentParameters[name][2] = False
    for name, value in cfg.get("instrument_values", {}).items():
        hist.InstrumentParameters[name][1] = float(value)
    for name in cfg.get("instrument_refine", []):
        hist.InstrumentParameters[name][2] = True

    for name in cfg.get("sample_clear", []):
        hist.SampleParameters[name][1] = False
    for name, value in cfg.get("sample_values", {}).items():
        hist.SampleParameters[name][0] = float(value)
    for name in cfg.get("sample_refine", []):
        hist.SampleParameters[name][1] = True

    if "background" in cfg:
        spec = cfg["background"]
        order = int(spec.get("order", hist.Background[0][2]))
        coeffs = (list(spec.get("coeffs", hist.Background[0][3:])) + [0.0] * order)[:order]
        hist.set_refinements({
            "Background": {
                "type": spec.get("type", hist.Background[0][0]),
                "no. coeffs": order,
                "coeffs": coeffs,
                "refine": bool(spec.get("refine", True)),
            }
        })

    phase_actions = cfg.get("phases", {})
    for phase in project.phases():
        action = phase_actions.get(phase.name, phase_actions.get("all", {}))
        configure_phase(phase, hist, action)

    for phase_name, restraint_spec in cfg.get("distance_restraints", {}).items():
        phase = project.phase(phase_name)
        project.data["Restraints"]["data"].setdefault(
            phase_name,
            {"Bond": {"wtFactor": 1.0, "Range": 1.1, "Bonds": [], "Use": True}},
        )
        phase.clearDistRestraint()
        for record in restraint_spec.get("bonds", []):
            phase.addDistRestraint(
                record["origin"],
                record["target"],
                float(record["distance"]),
                factor=float(record.get("search_factor", 1.02)),
                ESD=float(record.get("esd", restraint_spec.get("esd", 0.05))),
            )
        phase.setDistRestraintWeight(float(restraint_spec.get("weight", 1.0)))

    project.set_Controls("cycles", int(cfg.get("cycles", 10)))
    history = [snapshot(project, "configured")]
    for index in range(int(cfg.get("restarts", 2))):
        project.refine()
        history.append(snapshot(project, f"restart_{index + 1}"))
    project.save(str(output))
    report = {
        "config": cfg,
        "input": str(Path(input_path).resolve()),
        "output": str(output),
        "history": history,
        "final": snapshot(project, "final"),
        "covariance": {
            "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
            "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
            "sig": np.asarray(project.data.get("Covariance", {}).get("data", {}).get("sig", [])).tolist(),
        },
    }
    output.with_suffix(".json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3])
