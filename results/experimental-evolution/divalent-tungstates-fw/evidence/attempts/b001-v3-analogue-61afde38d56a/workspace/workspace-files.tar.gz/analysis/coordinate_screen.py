#!/usr/bin/env python3
"""Element/site-block coordinate trials after the nuisance model is fixed."""

from __future__ import annotations

import json
import shutil
import traceback
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
SOURCE = WORK / "analysis" / "final_position" / "shift.gpx"
OUT = WORK / "analysis" / "coordinate_screen"

BLOCKS = {
    "product_Zn": {"ZnWO4": ["Zn0"]},
    "product_W": {"ZnWO4": ["W1"]},
    "product_O2": {"ZnWO4": ["O2"]},
    "product_O3": {"ZnWO4": ["O3"]},
    "product_O_all": {"ZnWO4": ["O2", "O3"]},
    "product_metals": {"ZnWO4": ["Zn0", "W1"]},
    "wo3_W0": {"WO3": ["W0"]},
    "wo3_W1": {"WO3": ["W1"]},
    "wo3_W_all": {"WO3": ["W0", "W1"]},
    "wo3_O2": {"WO3": ["O2"]},
    "wo3_O3": {"WO3": ["O3"]},
    "wo3_O4": {"WO3": ["O4"]},
    "wo3_O5": {"WO3": ["O5"]},
    "wo3_O6": {"WO3": ["O6"]},
    "wo3_O7": {"WO3": ["O7"]},
    "wo3_O_all": {"WO3": ["O2", "O3", "O4", "O5", "O6", "O7"]},
    "zno_O": {"ZnO": ["O1"]},
}


def coordinates(project):
    return {
        phase.name: {
            atom.label: {
                "element": atom.element,
                "xyz": [float(value) for value in atom.coordinates],
                "uiso": float(atom.uiso),
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        }
        for phase in project.phases()
    }


def run(label, selection):
    path = OUT / f"{label}.gpx"
    shutil.copy2(SOURCE, path)
    project = G2sc.G2Project(str(path))
    project.save(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    for phase_name, labels in selection.items():
        for atom_label in labels:
            project.phase(phase_name).atom(atom_label).refinement_flags = "X"
    project.refine()
    project.refine()
    project.save()
    hist = project.histogram(0)
    return {
        "label": label,
        "selection": selection,
        "project": str(path),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "coordinates": coordinates(project),
    }


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for label, selection in BLOCKS.items():
        print(f"### {label}", flush=True)
        try:
            result = run(label, selection)
        except Exception as exc:
            traceback.print_exc()
            result = {"label": label, "status": "failed", "error": repr(exc)}
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
