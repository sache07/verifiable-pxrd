#!/usr/bin/env python3
"""Retest WO3 parents cumulatively with the leading wolframite parent."""

from __future__ import annotations

import json
import shutil
import traceback
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import analogue_swaps as swaps


PRODUCT = "znwo4_zncd_p2c_1520642"
AXES = {
    "wo3_monoclinic_2311041": [[0, 0, 1]],
    "wo3_monoclinic_1528915": [[1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 0, 1], [1, 0, -1]],
    "wo3_triclinic_2106293": [[1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 0, 1], [1, 0, -1], [1, 1, 0]],
}


def axis_slug(axis: list[int]) -> str:
    return "_".join(f"m{-v}" if v < 0 else str(v) for v in axis)


def summarize(project, label, model, axis=None):
    hist = project.histogram(0)
    return {
        "label": label,
        "wo3_model": model,
        "texture_axis": axis,
        "project": project.filename,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "pref_ori": phase.data["Histograms"][hist.name]["Pref.Ori."],
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in project.phases()
        },
    }


def texture_branch(source: Path, model: str, axis: list[int]):
    label = f"cumulative_{model}_texture_{axis_slug(axis)}"
    path = swaps.OUT / f"{label}.gpx"
    shutil.copy2(source, path)
    project = G2sc.G2Project(str(path))
    project.save(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    hist = project.histogram(0)
    wo3 = project.phase("WO3")
    pref = wo3.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0], pref[1], pref[2], pref[3] = "MD", 0.9, True, list(axis)
    project.set_Controls("parmMin", 0.3, f"{wo3.id}:0:MD")
    project.set_Controls("parmMax", 3.0, f"{wo3.id}:0:MD")
    project.refine()
    project.refine()
    project.save()
    return summarize(project, label, model, axis)


def main() -> None:
    results = []
    built = {}
    for model in swaps.WO3_MODELS:
        label = f"cumulative_{model}"
        print(f"### {label}", flush=True)
        try:
            result = swaps.build(label, PRODUCT, model)
            built[model] = Path(result["project"])
        except Exception as exc:
            traceback.print_exc()
            result = {"label": label, "status": "failed", "error": repr(exc)}
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)

    for model, source in built.items():
        for axis in AXES[model]:
            label = f"{model}_{axis_slug(axis)}"
            print(f"### texture {label}", flush=True)
            try:
                result = texture_branch(source, model, axis)
            except Exception as exc:
                traceback.print_exc()
                result = {"label": label, "status": "failed", "error": repr(exc)}
            results.append(result)
            print(json.dumps(result, indent=2), flush=True)
    (swaps.OUT / "cumulative_results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
