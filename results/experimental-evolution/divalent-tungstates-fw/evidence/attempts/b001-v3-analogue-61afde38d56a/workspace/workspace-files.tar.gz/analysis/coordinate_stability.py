#!/usr/bin/env python3
"""Repeat the full coordinate gain from distinct plausible nuisance starts."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
SOURCE = WORK / "analysis" / "analogue_swaps" / "product_znwo4_zncu_p2c_9005254.gpx"
OUT = WORK / "analysis" / "coordinate_stability"

STARTS = {
    "low_bg14": {
        "order": 14,
        "md": 0.75,
        "product_size": [0.07, 0.20],
        "product_strain": 2200.0,
        "wo3_size": 0.25,
        "wo3_strain": [600.0, 1400.0],
    },
    "middle_bg16": {
        "order": 16,
        "md": 1.0,
        "product_size": [0.11, 0.14],
        "product_strain": 3200.0,
        "wo3_size": 0.42,
        "wo3_strain": [900.0, 1000.0],
    },
    "high_bg18": {
        "order": 18,
        "md": 1.55,
        "product_size": [0.25, 0.08],
        "product_strain": 5200.0,
        "wo3_size": 0.80,
        "wo3_strain": [1600.0, 600.0],
    },
}

SELECTION = {
    "ZnWO4": ["Zn0", "W1", "O2", "O3"],
    "WO3": ["W0", "W1", "O2", "O3", "O4", "O5", "O6", "O7"],
    "ZnO": ["O1"],
}


def atom_state(project):
    return {
        phase.name: {
            atom.label: [float(value) for value in atom.coordinates]
            for atom in phase.atoms()
        }
        for phase in project.phases()
    }


def snapshot(project):
    hist = project.histogram(0)
    return {
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "atoms": atom_state(project),
        "background_order": hist.data["Background"][0][2],
        "texture": project.phase("WO3").data["Histograms"][hist.name]["Pref.Ori."],
        "product_size": project.phase("ZnWO4").data["Histograms"][hist.name]["Size"],
        "product_strain": project.phase("ZnWO4").data["Histograms"][hist.name]["Mustrain"],
        "wo3_size": project.phase("WO3").data["Histograms"][hist.name]["Size"],
        "wo3_strain": project.phase("WO3").data["Histograms"][hist.name]["Mustrain"],
    }


def run(label, spec):
    path = OUT / f"{label}.gpx"
    shutil.copy2(SOURCE, path)
    project = G2sc.G2Project(str(path))
    project.save(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 30)
    hist = project.histogram(0)
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": spec["order"]}}
    )
    product = project.phase("ZnWO4")
    phap = product.data["Histograms"][hist.name]
    phap["Size"][1][0:2] = spec["product_size"]
    phap["Mustrain"][1][0] = spec["product_strain"]
    wo3 = project.phase("WO3")
    whap = wo3.data["Histograms"][hist.name]
    whap["Pref.Ori."][1] = spec["md"]
    whap["Size"][1][0] = spec["wo3_size"]
    whap["Mustrain"][1][0:2] = spec["wo3_strain"]
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.refine()
    project.refine()
    before = snapshot(project)

    for phase_name, labels in SELECTION.items():
        phase = project.phase(phase_name)
        for atom_label in labels:
            phase.atom(atom_label).refinement_flags = "X"
    project.refine()
    project.refine()
    project.refine()
    project.save()
    return {
        "label": label,
        "project": str(path),
        "before_coordinates": before,
        "after_coordinates": snapshot(project),
    }


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for label, spec in STARTS.items():
        print(f"### {label}", flush=True)
        result = run(label, spec)
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
