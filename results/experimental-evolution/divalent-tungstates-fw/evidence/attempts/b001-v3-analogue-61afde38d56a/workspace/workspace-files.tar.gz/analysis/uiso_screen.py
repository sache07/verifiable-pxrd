#!/usr/bin/env python3
"""Screen isotropic displacement parameters by phase/element blocks."""

from __future__ import annotations

import json
import shutil
import traceback
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
SOURCE = WORK / "analysis" / "coordinate_stability" / "middle_bg16.gpx"
OUT = WORK / "analysis" / "uiso_screen"

BLOCKS = {
    "product_Zn_U": {"ZnWO4": ["Zn0"]},
    "product_W_U": {"ZnWO4": ["W1"]},
    "product_O_U": {"ZnWO4": ["O2", "O3"]},
    "product_all_U": {"ZnWO4": ["Zn0", "W1", "O2", "O3"]},
    "wo3_W_U": {"WO3": ["W0", "W1"]},
    "wo3_O_U": {"WO3": ["O2", "O3", "O4", "O5", "O6", "O7"]},
    "wo3_all_U": {"WO3": ["W0", "W1", "O2", "O3", "O4", "O5", "O6", "O7"]},
    "zno_all_U": {"ZnO": ["Zn0", "O1"]},
}


def atom_state(project):
    return {
        phase.name: {
            atom.label: {
                "uiso": float(atom.uiso),
                "flags": atom.refinement_flags,
                "xyz": [float(value) for value in atom.coordinates],
            }
            for atom in phase.atoms()
        }
        for phase in project.phases()
    }


def run(label, selection):
    path = OUT / f"{label}.gpx"
    shutil.copy2(SOURCE, path)
    project = G2sc.G2Project(str(path))
    project.save(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 30)
    for phase_name, labels in selection.items():
        phase = project.phase(phase_name)
        for atom_label in labels:
            atom = phase.atom(atom_label)
            atom.refinement_flags = "XU" if "X" in atom.refinement_flags else "U"
    project.refine()
    project.refine()
    project.save()
    hist = project.histogram(0)
    return {
        "label": label,
        "selection": selection,
        "project": str(path),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "atoms": atom_state(project),
    }


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for label, selection in BLOCKS.items():
        print(f"### {label}", flush=True)
        try:
            result = run(label, selection)
        except Exception as exc:
            traceback.print_exc()
            result = {"label": label, "status": "failed", "error": repr(exc)}
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
