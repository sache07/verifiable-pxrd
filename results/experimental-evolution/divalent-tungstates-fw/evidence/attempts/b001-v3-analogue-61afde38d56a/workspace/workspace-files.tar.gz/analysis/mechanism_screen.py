#!/usr/bin/env python3
"""Screen texture and uniaxial broadening after common-profile refinement."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
SOURCE = WORK / "analysis" / "broadening_branches" / "hybrid_product_size_wo3.gpx"
OUT = WORK / "analysis" / "mechanism_screen"
BASE = OUT / "base_profile.gpx"

AXES = {
    "ZnWO4": [[1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 0, 1], [1, 0, -1]],
    "WO3": [[1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 0, 1], [1, 0, -1], [1, 1, 0]],
    "ZnO": [[0, 0, 1], [1, 0, 0], [1, 0, 1]],
}


def slug(axis: list[int]) -> str:
    return "_".join(f"m{-value}" if value < 0 else str(value) for value in axis)


def prepare(path: Path, source: Path = BASE) -> G2sc.G2Project:
    shutil.copy2(source, path)
    project = G2sc.G2Project(str(path))
    project.save(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 15)
    return project


def make_base() -> dict[str, object]:
    project = prepare(BASE, SOURCE)
    hist = project.histogram(0)
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 12}}
    )
    hist.InstrumentParameters["Polariz."][1] = 0.55
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Controls("parmMin", 0.05, ":0:Polariz.")
    project.set_Controls("parmMax", 0.95, ":0:Polariz.")
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    project.refine()
    project.refine()
    project.save()
    return summary(project, "base_profile", BASE)


def summary(project: G2sc.G2Project, label: str, path: Path) -> dict[str, object]:
    hist = project.histogram(0)
    return {
        "label": label,
        "project": str(path),
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "background": hist.data["Background"][0],
        "phases": {
            phase.name: {
                "pref_ori": phase.data["Histograms"][hist.name]["Pref.Ori."],
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
                "cell": phase.get_cell(),
            }
            for phase in project.phases()
        },
    }


def run_texture(phase_name: str, axis: list[int]) -> dict[str, object]:
    label = f"texture_{phase_name}_{slug(axis)}"
    path = OUT / f"{label}.gpx"
    project = prepare(path)
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    phase = project.phase(phase_name)
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 0.9
    pref[2] = True
    pref[3] = list(axis)
    project.set_Controls("parmMin", 0.3, f"{phase.id}:0:MD")
    project.set_Controls("parmMax", 3.0, f"{phase.id}:0:MD")
    project.refine()
    project.refine()
    project.save()
    return summary(project, label, path)


def run_uniaxial(phase_name: str, axis: list[int], mechanism: str) -> dict[str, object]:
    label = f"{mechanism}_{phase_name}_{slug(axis)}"
    path = OUT / f"{label}.gpx"
    project = prepare(path)
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][hist.name]
    if mechanism == "size":
        item = hap["Size"]
        start = float(item[1][0])
        if start > 5.0:
            start = 2.0
        item[0] = "uniaxial"
        item[1][0] = start
        item[1][1] = start
        item[2][0] = True
        item[2][1] = True
        item[2][2] = False
        item[3] = list(axis)
        for var in ["Size;i", "Size;a"]:
            project.set_Controls("parmMin", 0.005, f"{phase.id}:0:{var}")
            project.set_Controls("parmMax", 100.0, f"{phase.id}:0:{var}")
    else:
        item = hap["Mustrain"]
        start = float(item[1][0])
        if start < 10.0:
            start = 500.0
        item[0] = "uniaxial"
        item[1][0] = start
        item[1][1] = start
        item[2][0] = True
        item[2][1] = True
        item[2][2] = False
        item[3] = list(axis)
        for var in ["Mustrain;i", "Mustrain;a"]:
            project.set_Controls("parmMin", 0.0, f"{phase.id}:0:{var}")
            project.set_Controls("parmMax", 50000.0, f"{phase.id}:0:{var}")
    project.refine()
    project.refine()
    project.save()
    return summary(project, label, path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["texture", "size", "strain", "all"])
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    if not BASE.exists():
        base_result = make_base()
    else:
        base_result = summary(G2sc.G2Project(str(BASE)), "base_profile", BASE)
    print(json.dumps({"label": base_result["label"], "wR": base_result["wR"]}), flush=True)

    modes = [args.mode] if args.mode != "all" else ["texture", "size", "strain"]
    results = [base_result]
    for mode in modes:
        for phase_name, axes in AXES.items():
            for axis in axes:
                if mode == "texture":
                    result = run_texture(phase_name, axis)
                else:
                    result = run_uniaxial(phase_name, axis, mode)
                results.append(result)
                print(
                    json.dumps(
                        {
                            "label": result["label"],
                            "wR": result["wR"],
                            "fractions": result["mass_fractions"],
                            "frozen": result["frozen"],
                            "pref": result["phases"][phase_name]["pref_ori"],
                            "size": result["phases"][phase_name]["size"],
                            "mustrain": result["phases"][phase_name]["mustrain"],
                        }
                    ),
                    flush=True,
                )
    (OUT / f"{args.mode}_results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
