#!/usr/bin/env python3
"""Retest retained profile and Uiso mechanisms after coordinate refinement."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
SOURCE = WORK / "analysis" / "uiso_combinations" / "heavy_bg16_start010.gpx"
OUT = WORK / "analysis" / "post_atomic_profile"

BRANCHES = [
    "source",
    "product_size_isotropic",
    "product_no_size",
    "product_no_strain",
    "wo3_strain_isotropic",
    "wo3_no_strain",
    "both_isotropic",
    "no_texture",
    "no_polarization",
    "no_product_W_U",
    "no_wo3_W_U",
    "no_heavy_U",
    "background_14",
    "background_18",
    "background_20",
]


def remove_u(atom):
    atom.uiso = 0.01
    atom.refinement_flags = atom.refinement_flags.replace("U", "") or " "


def configure(project, label):
    hist = project.histogram(0)
    product = project.phase("ZnWO4")
    phap = product.data["Histograms"][hist.name]
    wo3 = project.phase("WO3")
    whap = wo3.data["Histograms"][hist.name]

    if label in {"product_size_isotropic", "both_isotropic"}:
        mean = sum(phap["Size"][1][0:2]) / 2.0
        phap["Size"][0] = "isotropic"
        phap["Size"][1][0] = mean
        phap["Size"][2] = [True, False, False]
    if label == "product_no_size":
        phap["Size"][0] = "isotropic"
        phap["Size"][1][0] = 10.0
        phap["Size"][2] = [False, False, False]
    if label == "product_no_strain":
        phap["Mustrain"][0] = "isotropic"
        phap["Mustrain"][1][0] = 1.0
        phap["Mustrain"][2] = [False, False, False]
    if label in {"wo3_strain_isotropic", "both_isotropic"}:
        mean = sum(whap["Mustrain"][1][0:2]) / 2.0
        whap["Mustrain"][0] = "isotropic"
        whap["Mustrain"][1][0] = mean
        whap["Mustrain"][2] = [True, False, False]
    if label == "wo3_no_strain":
        whap["Mustrain"][0] = "isotropic"
        whap["Mustrain"][1][0] = 1.0
        whap["Mustrain"][2] = [False, False, False]
    if label == "no_texture":
        whap["Pref.Ori."][1] = 1.0
        whap["Pref.Ori."][2] = False
    if label == "no_polarization":
        hist.InstrumentParameters["Polariz."][1] = 0.7
        hist.InstrumentParameters["Polariz."][2] = False
    if label in {"no_product_W_U", "no_heavy_U"}:
        remove_u(product.atom("W1"))
    if label in {"no_wo3_W_U", "no_heavy_U"}:
        remove_u(wo3.atom("W0"))
        remove_u(wo3.atom("W1"))
    if label.startswith("background_"):
        order = int(label.split("_")[1])
        hist.set_refinements(
            {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": order}}
        )


def snapshot(project, label, path):
    hist = project.histogram(0)
    return {
        "label": label,
        "project": str(path),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "background_order": hist.data["Background"][0][2],
        "polarization": hist.InstrumentParameters["Polariz."][1:3],
        "product": {
            "size": project.phase("ZnWO4").data["Histograms"][hist.name]["Size"],
            "mustrain": project.phase("ZnWO4").data["Histograms"][hist.name]["Mustrain"],
            "W_uiso": project.phase("ZnWO4").atom("W1").uiso,
        },
        "wo3": {
            "pref_ori": project.phase("WO3").data["Histograms"][hist.name]["Pref.Ori."],
            "size": project.phase("WO3").data["Histograms"][hist.name]["Size"],
            "mustrain": project.phase("WO3").data["Histograms"][hist.name]["Mustrain"],
            "W_uiso": [project.phase("WO3").atom(label).uiso for label in ["W0", "W1"]],
        },
    }


def run(label):
    path = OUT / f"{label}.gpx"
    shutil.copy2(SOURCE, path)
    project = G2sc.G2Project(str(path))
    project.save(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 30)
    configure(project, label)
    project.refine()
    project.refine()
    project.refine()
    project.save()
    return snapshot(project, label, path)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for label in BRANCHES:
        print(f"### {label}", flush=True)
        result = run(label)
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
