#!/usr/bin/env python3
"""Restage WO3 texture-axis swaps that failed from the full profile."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import analogue_swaps as swaps
from cumulative_swaps import AXES, axis_slug


MODELS = ["wo3_monoclinic_1528915", "wo3_triclinic_2106293"]


def snap(project, label, model, axis, stage):
    hist = project.histogram(0)
    hap = project.phase("WO3").data["Histograms"][hist.name]
    return {
        "label": label,
        "stage": stage,
        "wo3_model": model,
        "axis": axis,
        "project": project.filename,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "pref_ori": hap["Pref.Ori."],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
    }


def run(model: str, axis: list[int]):
    label = f"restaged_{model}_{axis_slug(axis)}"
    source = swaps.OUT / f"cumulative_{model}.gpx"
    stage1_path = swaps.OUT / f"{label}_texture_only.gpx"
    shutil.copy2(source, stage1_path)
    project = G2sc.G2Project(str(stage1_path))
    project.save(str(stage1_path))
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    hist = project.histogram(0)
    wo3 = project.phase("WO3")
    hap = wo3.data["Histograms"][hist.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    project.set_Controls("parmMin", 0.3, f"{wo3.id}:0:MD")
    project.set_Controls("parmMax", 3.0, f"{wo3.id}:0:MD")
    project.refine()
    project.refine()
    project.save()
    results = [snap(project, label, model, axis, "texture_only")]

    stage2_path = swaps.OUT / f"{label}_full.gpx"
    project.save(str(stage2_path))
    project = G2sc.G2Project(str(stage2_path))
    project.save(str(stage2_path))
    project.set_Frozen()
    hist = project.histogram(0)
    wo3 = project.phase("WO3")
    hap = wo3.data["Histograms"][hist.name]
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][1][1] = 1000.0
    hap["Mustrain"][2] = [True, True, False]
    hap["Mustrain"][3] = list(axis)
    for var in ["Mustrain;i", "Mustrain;a"]:
        project.set_Controls("parmMin", 0.0, f"{wo3.id}:0:{var}")
        project.set_Controls("parmMax", 50000.0, f"{wo3.id}:0:{var}")
    project.refine()
    project.refine()
    project.save()
    results.append(snap(project, label, model, axis, "full"))
    return results


def main() -> None:
    results = []
    for model in MODELS:
        for axis in AXES[model]:
            print(f"### {model} {axis}", flush=True)
            branches = run(model, axis)
            results.extend(branches)
            print(json.dumps(branches, indent=2), flush=True)
    (swaps.OUT / "restaged_wo3_texture.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
