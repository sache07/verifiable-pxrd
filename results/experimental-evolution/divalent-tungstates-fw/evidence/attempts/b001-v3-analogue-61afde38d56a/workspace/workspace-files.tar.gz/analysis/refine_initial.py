#!/usr/bin/env python3
"""Build an initial two-phase GSAS-II model and run conservative stages."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
ANALYSIS = WORK / "analysis"
OUT = ANALYSIS / "initial"


def summary(project: G2sc.G2Project, label: str) -> dict[str, object]:
    hist = project.histogram(0)
    result: dict[str, object] = {
        "stage": label,
        "residuals": hist.residuals,
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if key in {"Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."}
        },
        "sample": {
            key: value[0]
            for key, value in hist.SampleParameters.items()
            if key in {"Shift", "Transparency", "SurfRoughA", "SurfRoughB"}
        },
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"][1],
            "mustrain": hap["Mustrain"][1],
        }
    try:
        result["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        result["mass_fraction_error"] = repr(exc)
    print(json.dumps(result, indent=2))
    return result


def background_points(hist: G2sc.G2PwdrData) -> list[tuple[float, float]]:
    x = np.asarray(hist.getdata("X"))
    y = np.asarray(hist.getdata("Yobs"))
    points: list[tuple[float, float]] = []
    for center in np.arange(10.0, 100.01, 3.0):
        mask = np.abs(x - center) <= 1.25
        points.append((center, float(np.percentile(y[mask], 8))))
    return points


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    gpx_path = OUT / "initial_znwo4_zno.gpx"
    project = G2sc.G2Project(newgpx=str(gpx_path))
    hist = project.add_powder_histogram(
        str(WORK / "inputs" / "pattern.csv"),
        str(ANALYSIS / "cu_ka.instprm"),
        fmthint="comma",
    )
    znwo4 = project.add_phase(
        str(ANALYSIS / "candidates" / "znwo4_zncu_p2c_9005254.cif"),
        phasename="ZnWO4",
        histograms=[hist],
        fmthint="CIF",
    )
    zno = project.add_phase(
        str(ANALYSIS / "candidates" / "zno_wurtzite_9004178.cif"),
        phasename="ZnO",
        histograms=[hist],
        fmthint="CIF",
    )

    project.set_Controls("cycles", 12)
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.SampleParameters["Scale"][1] = False
    hist.InstrumentParameters["Zero"][1] = 0.28
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "FixedPoints": background_points(hist),
                "fit fixed points": True,
                "refine": True,
            }
        }
    )
    # Broad product reflections and sharp residual-ZnO reflections are already
    # evident. These are only starting values and both sizes are later refined.
    znwo4.data["Histograms"][hist.name]["Size"][1][0] = 0.10
    zno.data["Histograms"][hist.name]["Size"][1][0] = 1.0
    for phase in (znwo4, zno):
        phase.set_HAP_refinements({"Scale": True})

    log: list[dict[str, object]] = []
    project.refine()
    log.append(summary(project, "background_scales"))

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine()
    log.append(summary(project, "cells"))

    # Fit a common low-flexibility instrumental profile while phase sizes are
    # still fixed. This prevents the broad principal phase from forcing a
    # common width onto the sharp ZnO family.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
    project.refine()
    log.append(summary(project, "common_profile"))

    for phase in project.phases():
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True, "LGmix": {"value": 1.0, "refine": False}}}
        )
    project.refine()
    log.append(summary(project, "isotropic_sizes"))

    project.save()
    (OUT / "initial_log.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
