#!/usr/bin/env python3
"""Test broadening stability and non-structural intensity mechanisms."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
COMMON = WORK / "analysis" / "profile" / "common_axial.gpx"
CURRENT = WORK / "analysis" / "broadening_branches" / "hybrid_product_size_wo3.gpx"
OUT = WORK / "analysis" / "stability_nuisance"


STARTS = {
    "start_small": (0.12, 3000.0, 0.12),
    "start_middle": (0.30, 5000.0, 0.30),
}


def correlations(project: G2sc.G2Project, count: int = 10) -> list[dict[str, object]]:
    cov = project.data.get("Covariance", {}).get("data", {})
    vary = [str(item) for item in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.size == 0:
        return []
    sigma = np.sqrt(np.clip(np.diag(matrix), 0, None))
    denom = np.outer(sigma, sigma)
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom != 0)
    pairs = sorted(
        (
            (abs(float(corr[i, j])), vary[i], vary[j], float(corr[i, j]))
            for i in range(len(vary))
            for j in range(i)
        ),
        reverse=True,
    )
    return [
        {"abs": value, "a": a, "b": b, "value": signed}
        for value, a, b, signed in pairs[:count]
    ]


def snapshot(project: G2sc.G2Project, label: str, path: Path) -> dict[str, object]:
    hist = project.histogram(0)
    return {
        "label": label,
        "project": str(path),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "background": hist.data["Background"][0],
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ["U", "V", "W", "X", "Y", "SH/L", "Polariz."]
        },
        "sample": {
            key: hist.SampleParameters[key][0]
            for key in ["Shift", "SurfRoughA", "SurfRoughB"]
        },
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][hist.name]["Scale"],
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in project.phases()
        },
        "largest_correlations": correlations(project),
    }


def clean_project(path: Path) -> G2sc.G2Project:
    project = G2sc.G2Project(str(path))
    project.save(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["X", "Y"]})
    hist.InstrumentParameters["X"][1] = 0.0
    hist.InstrumentParameters["Y"][1] = 0.0
    return project


def run_hybrid_start(label: str, start: tuple[float, float, float]) -> dict[str, object]:
    path = OUT / f"hybrid_{label}.gpx"
    shutil.copy2(COMMON, path)
    project = clean_project(path)
    hist = project.histogram(0)
    product_size, product_strain, wo3_size = start
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Mustrain"][0] = "isotropic"
        if phase.name == "ZnWO4":
            hap["Size"][1][0] = product_size
            hap["Size"][2][0] = True
            hap["Mustrain"][1][0] = product_strain
            hap["Mustrain"][2][0] = True
        elif phase.name == "WO3":
            hap["Size"][1][0] = wo3_size
            hap["Size"][2][0] = True
            hap["Mustrain"][1][0] = 1.0
            hap["Mustrain"][2][0] = False
        else:
            hap["Size"][1][0] = 10.0
            hap["Size"][2][0] = False
            hap["Mustrain"][1][0] = 1.0
            hap["Mustrain"][2][0] = False
    project.refine()
    project.refine()
    project.save()
    return snapshot(project, f"hybrid_{label}", path)


def run_branch(label: str, setup) -> dict[str, object]:
    path = OUT / f"{label}.gpx"
    shutil.copy2(CURRENT, path)
    project = clean_project(path)
    hist = project.histogram(0)
    setup(project, hist)
    project.refine()
    project.refine()
    project.save()
    return snapshot(project, label, path)


def background_setup(order: int, kind: str = "chebyschev-1"):
    def setup(project, hist):
        hist.set_refinements(
            {"Background": {"type": kind, "refine": True, "no. coeffs": order}}
        )
    return setup


def polar_setup(project, hist):
    hist.InstrumentParameters["Polariz."][1] = 0.7
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Controls("parmMin", 0.05, ":0:Polariz.")
    project.set_Controls("parmMax", 0.95, ":0:Polariz.")


def rough_setup(mode: str):
    def setup(project, hist):
        hist.SampleParameters["SurfRoughA"] = [0.5, mode in {"a", "ab"}]
        hist.SampleParameters["SurfRoughB"] = [0.02, mode in {"b", "ab"}]
        project.set_Controls("parmMin", 0.001, ":0:SurfRoughA")
        project.set_Controls("parmMax", 0.999, ":0:SurfRoughA")
        project.set_Controls("parmMin", 0.000001, ":0:SurfRoughB")
        project.set_Controls("parmMax", 3.0, ":0:SurfRoughB")
    return setup


def combined_setup(project, hist):
    polar_setup(project, hist)
    rough_setup("ab")(project, hist)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    results: list[dict[str, object]] = []
    for label, start in STARTS.items():
        print(f"\n### hybrid {label}", flush=True)
        existing = OUT / f"hybrid_{label}.gpx"
        if existing.exists():
            result = snapshot(G2sc.G2Project(str(existing)), f"hybrid_{label}", existing)
        else:
            result = run_hybrid_start(label, start)
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)

    branches = {
        "background_cheb6": background_setup(6),
        "background_cheb8": background_setup(8),
        "background_cheb10": background_setup(10),
        "background_cheb12": background_setup(12),
        "polarization": polar_setup,
        "roughness_a": rough_setup("a"),
        "roughness_b": rough_setup("b"),
        "roughness_ab": rough_setup("ab"),
        "polarization_roughness_ab": combined_setup,
    }
    for label, setup in branches.items():
        print(f"\n### {label}", flush=True)
        result = run_branch(label, setup)
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)

    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
