#!/usr/bin/env python3
"""Restage topology swaps that hit bounds under wolframite-specific broadening."""

from __future__ import annotations

import json
import traceback

import analogue_swaps as swaps


MODELS = [
    "znwo4_zncu_p1_9005253",
    "znwo4_ordered_liyb_p2c_1527650",
    "znwo4_scheelite_ca_i41a_7219229",
]


def main() -> None:
    results = []
    for model in MODELS:
        label = f"restaged_{model}"
        print(f"### {label}", flush=True)
        try:
            result = swaps.build(label, model, swaps.WO3_MODELS[0], simplified=True)
        except Exception as exc:
            traceback.print_exc()
            result = {"label": label, "status": "failed", "error": repr(exc)}
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)
    (swaps.OUT / "restaged_results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
