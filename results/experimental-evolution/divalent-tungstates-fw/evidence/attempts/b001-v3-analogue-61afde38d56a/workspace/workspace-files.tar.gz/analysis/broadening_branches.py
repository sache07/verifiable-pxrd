#!/usr/bin/env python3
"""Restage phase broadening after the all-at-once model became singular."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
SOURCE = WORK / "analysis" / "profile" / "common_axial.gpx"
OUT = WORK / "analysis" / "broadening_branches"


BRANCHES = {
    "size_product_size_wo3": {
        "ZnWO4": {"size": 0.10, "ref_size": True, "strain": 1.0, "ref_strain": False},
        "WO3": {"size": 0.30, "ref_size": True, "strain": 1.0, "ref_strain": False},
        "ZnO": {"size": 10.0, "ref_size": False, "strain": 1.0, "ref_strain": False},
    },
    "strain_product_size_wo3": {
        "ZnWO4": {"size": 10.0, "ref_size": False, "strain": 5000.0, "ref_strain": True},
        "WO3": {"size": 0.30, "ref_size": True, "strain": 1.0, "ref_strain": False},
        "ZnO": {"size": 10.0, "ref_size": False, "strain": 1.0, "ref_strain": False},
    },
    "strain_product_strain_wo3": {
        "ZnWO4": {"size": 10.0, "ref_size": False, "strain": 5000.0, "ref_strain": True},
        "WO3": {"size": 10.0, "ref_size": False, "strain": 1000.0, "ref_strain": True},
        "ZnO": {"size": 10.0, "ref_size": False, "strain": 1.0, "ref_strain": False},
    },
    "hybrid_product_size_wo3": {
        "ZnWO4": {"size": 0.30, "ref_size": True, "strain": 5000.0, "ref_strain": True},
        "WO3": {"size": 0.30, "ref_size": True, "strain": 1.0, "ref_strain": False},
        "ZnO": {"size": 10.0, "ref_size": False, "strain": 1.0, "ref_strain": False},
    },
    "strain_product_size_wo3_strain_zno": {
        "ZnWO4": {"size": 10.0, "ref_size": False, "strain": 5000.0, "ref_strain": True},
        "WO3": {"size": 0.30, "ref_size": True, "strain": 1.0, "ref_strain": False},
        "ZnO": {"size": 10.0, "ref_size": False, "strain": 500.0, "ref_strain": True},
    },
}


def correlations(project: G2sc.G2Project) -> list[dict[str, object]]:
    cov = project.data.get("Covariance", {}).get("data", {})
    vary = cov.get("varyList", [])
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if not matrix.size:
        return []
    sigma = np.sqrt(np.clip(np.diag(matrix), 0, None))
    denominator = np.outer(sigma, sigma)
    corr = np.divide(matrix, denominator, out=np.zeros_like(matrix), where=denominator != 0)
    pairs = sorted(
        (
            (abs(float(corr[i, j])), str(vary[i]), str(vary[j]), float(corr[i, j]))
            for i in range(len(vary))
            for j in range(i)
        ),
        reverse=True,
    )
    return [
        {"abs": p[0], "a": p[1], "b": p[2], "value": p[3]}
        for p in pairs[:12]
    ]


def run(name: str, settings: dict[str, dict[str, object]]) -> dict[str, object]:
    path = OUT / f"{name}.gpx"
    shutil.copy2(SOURCE, path)
    project = G2sc.G2Project(str(path))
    project.save(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    hist = project.histogram(0)
    # The X and Y trials attempted nonphysical negative values; they are
    # explicitly removed before testing alternate sample broadening.
    hist.clear_refinements({"Instrument Parameters": ["X", "Y"]})
    hist.InstrumentParameters["X"][1] = 0.0
    hist.InstrumentParameters["Y"][1] = 0.0

    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        spec = settings[phase.name]
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = float(spec["size"])
        hap["Size"][2][0] = bool(spec["ref_size"])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = float(spec["strain"])
        hap["Mustrain"][2][0] = bool(spec["ref_strain"])

    # Two calls ensure a branch that takes a damped first step is fully
    # re-equilibrated; no new flags are added between calls.
    project.refine()
    project.refine()
    project.save()
    return {
        "branch": name,
        "project": str(path),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ["U", "V", "W", "X", "Y", "SH/L"]
        },
        "shift_um": hist.SampleParameters["Shift"][0],
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in project.phases()
        },
        "largest_correlations": correlations(project),
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for name, settings in BRANCHES.items():
        print(f"\n### {name}", flush=True)
        result = run(name, settings)
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)
    (OUT / "branches.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
