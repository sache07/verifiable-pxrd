#!/usr/bin/env python3
"""Final phase-deletion tests and residual-family extraction."""

from __future__ import annotations

import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
SOURCE = WORK / "analysis" / "post_atomic_profile" / "both_isotropic.gpx"
OUT = WORK / "analysis" / "deletion_tests"


def top_residuals(hist, count=12, separation=0.25):
    arrays = hist.data["data"][1]
    x = np.asarray(arrays[0], dtype=float)
    diff = np.asarray(arrays[5], dtype=float)
    low, high = hist.data["Limits"][1]
    mask = (x >= low) & (x <= high)
    indices = np.where(mask)[0]
    local = [
        i
        for i in indices[1:-1]
        if abs(diff[i]) >= abs(diff[i - 1]) and abs(diff[i]) >= abs(diff[i + 1])
    ]
    local.sort(key=lambda i: abs(diff[i]), reverse=True)
    chosen = []
    for i in local:
        if all(abs(x[i] - x[j]) >= separation for j in chosen):
            chosen.append(i)
        if len(chosen) >= count:
            break
    return [
        {"two_theta_deg": float(x[i]), "difference_counts": float(diff[i])}
        for i in chosen
    ]


def snapshot(project, label, path):
    hist = project.histogram(0)
    result = {
        "label": label,
        "project": str(path),
        "residuals": hist.residuals,
        "frozen": project.get_Frozen(),
        "top_residuals": top_residuals(hist),
    }
    try:
        result["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        result["mass_fraction_error"] = repr(exc)
    return result


def run_deleted(phase_name):
    label = f"without_{phase_name}"
    path = OUT / f"{label}.gpx"
    source_project = G2sc.G2Project(str(SOURCE))
    source_hist = source_project.histogram(0)
    project = G2sc.G2Project(newgpx=str(path))
    hist = project.add_powder_histogram(
        str(WORK / "inputs" / "pattern.csv"),
        str(WORK / "analysis" / "cu_ka.instprm"),
        fmthint="comma",
    )
    for source_phase in source_project.phases():
        if source_phase.name == phase_name:
            continue
        project.add_phase(
            str(OUT / f"final_{source_phase.name}.cif"),
            phasename=source_phase.name,
            histograms=[hist],
            fmthint="CIF",
        )
    sample_ran_id = hist.data["Sample Parameters"].get("ranId")
    hist.data["Limits"] = copy.deepcopy(source_hist.data["Limits"])
    hist.data["Background"] = copy.deepcopy(source_hist.data["Background"])
    hist.data["Instrument Parameters"] = copy.deepcopy(source_hist.data["Instrument Parameters"])
    hist.data["Sample Parameters"] = copy.deepcopy(source_hist.data["Sample Parameters"])
    if sample_ran_id is not None:
        hist.data["Sample Parameters"]["ranId"] = sample_ran_id
    # Deletion fits use the validated full-model profile as a fixed forward
    # model and re-equilibrate only the smooth background and surviving scales.
    # Letting widths/cells chase an absent phase produces invalid negative
    # profile terms and makes the deletion numerically meaningless.
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        source_phase = source_project.phase(phase.name)
        source_hap = source_phase.data["Histograms"][source_hist.name]
        hap = phase.data["Histograms"][hist.name]
        for key in ["Scale", "Pref.Ori.", "Extinction", "Babinet"]:
            hap[key] = copy.deepcopy(source_hap[key])
        hap["Size"][0:4] = copy.deepcopy(source_hap["Size"][0:4])
        hap["Mustrain"][0:4] = copy.deepcopy(source_hap["Mustrain"][0:4])
        hap["hId"] = hist.id
        phase.data["General"]["Cell"][0] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.set_Controls("cycles", 30)
    project.set_Frozen()
    project.save()
    project.refine()
    project.refine()
    project.refine()
    project.save()
    return snapshot(project, label, path)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    source_project = G2sc.G2Project(str(SOURCE))
    for phase in source_project.phases():
        phase.export_CIF(str(OUT / f"final_{phase.name}.cif"))
    results = [snapshot(source_project, "full_model", SOURCE)]
    for phase_name in ["ZnWO4", "WO3", "ZnO"]:
        print(f"### without {phase_name}", flush=True)
        result = run_deleted(phase_name)
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
