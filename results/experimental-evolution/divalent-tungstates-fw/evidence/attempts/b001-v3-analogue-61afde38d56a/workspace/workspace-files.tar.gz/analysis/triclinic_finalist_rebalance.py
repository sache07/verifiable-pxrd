#!/usr/bin/env python3
"""Apply the final heavy-W and isotropic profile choices to triclinic WO3."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
SOURCE = WORK / "analysis" / "triclinic_coordinate_complete" / "all_coordinates.gpx"
OUT = WORK / "analysis" / "triclinic_finalist_rebalance"


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "triclinic_finalist.gpx"
    shutil.copy2(SOURCE, path)
    project = G2sc.G2Project(str(path))
    project.save(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 35)
    hist = project.histogram(0)
    product = project.phase("ZnWO4")
    phap = product.data["Histograms"][hist.name]
    phap["Size"][0] = "isotropic"
    phap["Size"][1][0] = sum(phap["Size"][1][0:2]) / 2.0
    phap["Size"][2] = [True, False, False]
    wo3 = project.phase("WO3")
    whap = wo3.data["Histograms"][hist.name]
    whap["Mustrain"][0] = "isotropic"
    whap["Mustrain"][1][0] = sum(whap["Mustrain"][1][0:2]) / 2.0
    whap["Mustrain"][2] = [True, False, False]

    product_w = product.atom("W1")
    product_w.uiso = 0.011
    product_w.refinement_flags = "XU"
    for atom in wo3.atoms():
        if atom.element == "W":
            atom.uiso = 0.005
            atom.refinement_flags = "XU"
    project.refine()
    project.refine()
    project.refine()
    project.save()
    cov = project.data["Covariance"]["data"]
    result = {
        "project": str(path),
        "residuals": hist.residuals,
        "Rvals": {key: cov.get("Rvals", {}).get(key) for key in ["chisq", "Nobs", "Nvars", "GOF", "converged"]},
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "W_uiso": {
            "ZnWO4": product_w.uiso,
            "WO3": {atom.label: atom.uiso for atom in wo3.atoms() if atom.element == "W"},
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }
    (OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
