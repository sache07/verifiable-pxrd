#!/usr/bin/env python3
"""Test stability of defensible heavy-atom displacement blocks."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
OUT = WORK / "analysis" / "uiso_combinations"

SPECS = [
    ("heavy_bg16_start003", "middle_bg16", 0.003, "heavy"),
    ("heavy_bg16_start010", "middle_bg16", 0.010, "heavy"),
    ("heavy_bg16_start020", "middle_bg16", 0.020, "heavy"),
    ("heavy_bg18_start010", "high_bg18", 0.010, "heavy"),
    ("productall_wo3W_bg16", "middle_bg16", 0.010, "productall"),
]


def snapshot(project, label, path):
    hist = project.histogram(0)
    return {
        "label": label,
        "project": str(path),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "background_order": hist.data["Background"][0][2],
        "atoms": {
            phase.name: {
                atom.label: {
                    "uiso": float(atom.uiso),
                    "flags": atom.refinement_flags,
                    "xyz": [float(value) for value in atom.coordinates],
                }
                for atom in phase.atoms()
            }
            for phase in project.phases()
        },
    }


def run(label, source_name, start, mode):
    source = WORK / "analysis" / "coordinate_stability" / f"{source_name}.gpx"
    path = OUT / f"{label}.gpx"
    shutil.copy2(source, path)
    project = G2sc.G2Project(str(path))
    project.save(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 30)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "X" if "X" in atom.refinement_flags else " "
    product_labels = ["W1"] if mode == "heavy" else ["Zn0", "W1", "O2", "O3"]
    selections = {"ZnWO4": product_labels, "WO3": ["W0", "W1"]}
    for phase_name, labels in selections.items():
        phase = project.phase(phase_name)
        for atom_label in labels:
            atom = phase.atom(atom_label)
            atom.uiso = start
            atom.refinement_flags = "XU" if "X" in atom.refinement_flags else "U"
    project.refine()
    project.refine()
    project.refine()
    project.save()
    return snapshot(project, label, path)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for spec in SPECS:
        print(f"### {spec[0]}", flush=True)
        result = run(*spec)
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
