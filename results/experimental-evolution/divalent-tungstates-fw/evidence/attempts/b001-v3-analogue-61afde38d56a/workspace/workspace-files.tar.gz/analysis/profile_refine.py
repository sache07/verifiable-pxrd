#!/usr/bin/env python3
"""Mechanism-complete common and isotropic profile refinement."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
SOURCE = WORK / "analysis" / "position_branches" / "shift_only.gpx"
OUT = WORK / "analysis" / "profile"


def covariance_diagnostics(project: G2sc.G2Project) -> list[dict[str, object]]:
    cov = project.data.get("Covariance", {}).get("data", {})
    vary = cov.get("varyList", [])
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.size == 0:
        return []
    sigma = np.sqrt(np.clip(np.diag(matrix), 0, None))
    denom = np.outer(sigma, sigma)
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom != 0)
    pairs = sorted(
        (
            (abs(float(corr[i, j])), str(vary[i]), str(vary[j]), float(corr[i, j]))
            for i in range(len(vary))
            for j in range(i)
        ),
        reverse=True,
    )
    return [
        {"abs": item[0], "a": item[1], "b": item[2], "value": item[3]}
        for item in pairs[:15]
    ]


def snapshot(project: G2sc.G2Project, stage: str) -> dict[str, object]:
    hist = project.histogram(0)
    result = {
        "stage": stage,
        "residuals": hist.residuals,
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if key in {"Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."}
        },
        "sample": {
            key: value[0]
            for key, value in hist.SampleParameters.items()
            if key in {"Shift", "SurfRoughA", "SurfRoughB"}
        },
        "mass_fractions": hist.ComputeMassFracs(),
        "phases": {},
        "largest_correlations": covariance_diagnostics(project),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    print(json.dumps(result, indent=2), flush=True)
    return result


def refine(project: G2sc.G2Project, stage: str, log: list[dict[str, object]]) -> None:
    print(f"\n### {stage}", flush=True)
    project.refine()
    log.append(snapshot(project, stage))
    project.save(OUT / f"{stage}.gpx")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "profile_work.gpx"
    shutil.copy2(SOURCE, path)
    project = G2sc.G2Project(str(path))
    project.save(str(path))
    project.set_Controls("cycles", 20)
    hist = project.histogram(0)
    hist.clear_refinements(
        {"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L", "Polariz."]}
    )
    # Broad limits catch numerical drift while remaining far wider than the
    # observed sharp-line profile requires.
    for variable, low, high in [
        (":0:U", 0.0, 500.0),
        (":0:V", -500.0, 500.0),
        (":0:W", 0.0, 200.0),
        (":0:X", 0.0, 20.0),
        (":0:Y", 0.0, 20.0),
        (":0:SH/L", 0.0001, 0.3),
    ]:
        project.set_Controls("parmMin", low, variable)
        project.set_Controls("parmMax", high, variable)

    log: list[dict[str, object]] = []
    hist.set_refinements({"Instrument Parameters": ["W"]})
    refine(project, "common_W", log)

    hist.set_refinements({"Instrument Parameters": ["U", "V"]})
    refine(project, "common_UVW", log)

    hist.set_refinements({"Instrument Parameters": ["X"]})
    refine(project, "common_UVWX", log)

    hist.set_refinements({"Instrument Parameters": ["Y"]})
    refine(project, "common_UVWXY", log)

    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    refine(project, "common_axial", log)

    for phase in project.phases():
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True, "LGmix": {"value": 1.0, "refine": False}}}
        )
    refine(project, "isotropic_size", log)

    for phase in project.phases():
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True, "LGmix": {"value": 1.0, "refine": False}}}
        )
    refine(project, "isotropic_size_strain", log)

    project.save(OUT / "profile_complete.gpx")
    (OUT / "profile_log.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
