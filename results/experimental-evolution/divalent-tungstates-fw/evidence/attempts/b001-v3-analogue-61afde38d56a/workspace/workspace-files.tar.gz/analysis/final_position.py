#!/usr/bin/env python3
"""Final clean zero/displacement comparison after cumulative model selection."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
SOURCE = WORK / "analysis" / "analogue_swaps" / "cumulative_wo3_monoclinic_2311041.gpx"
OUT = WORK / "analysis" / "final_position"

SPECS = {
    "zero": (0.30, 0.0, True, False),
    "shift": (0.0, -540.0, False, True),
    "joint_a": (0.10, -300.0, True, True),
    "joint_b": (-0.20, -800.0, True, True),
}


def run(label, spec):
    path = OUT / f"{label}.gpx"
    shutil.copy2(SOURCE, path)
    project = G2sc.G2Project(str(path))
    project.save(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    hist = project.histogram(0)
    zero, shift, ref_zero, ref_shift = spec
    hist.InstrumentParameters["Zero"][1:3] = [zero, ref_zero]
    hist.SampleParameters["Shift"][0:2] = [shift, ref_shift]
    project.set_Controls("parmMin", -1.0, ":0:Zero")
    project.set_Controls("parmMax", 1.0, ":0:Zero")
    project.set_Controls("parmMin", -3000.0, ":0:Shift")
    project.set_Controls("parmMax", 3000.0, ":0:Shift")
    project.refine()
    project.refine()
    project.save()
    return {
        "label": label,
        "project": str(path),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "zero": hist.InstrumentParameters["Zero"][1],
        "shift": hist.SampleParameters["Shift"][0],
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for label, spec in SPECS.items():
        result = run(label, spec)
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
