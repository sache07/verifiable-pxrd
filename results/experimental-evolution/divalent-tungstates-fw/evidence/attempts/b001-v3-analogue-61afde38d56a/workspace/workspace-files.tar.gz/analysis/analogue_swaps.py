#!/usr/bin/env python3
"""Matched, mechanism-complete structural-parent swaps with fixed coordinates."""

from __future__ import annotations

import copy
import json
import traceback
from pathlib import Path

from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
ANALYSIS = WORK / "analysis"
TEMPLATE = ANALYSIS / "final_profile_screen" / "combined_mid_bg16_no_y.gpx"
OUT = ANALYSIS / "analogue_swaps"

PRODUCT_MODELS = [
    "znwo4_zncu_p2c_9005254",
    "znwo4_zncd_p2c_1520642",
    "znwo4_mg_p2c_9013902",
    "znwo4_mn_p2c_1520200",
    "znwo4_zncu_p1_9005253",
    "znwo4_ordered_liyb_p2c_1527650",
    "znwo4_scheelite_ca_i41a_7219229",
]

WO3_MODELS = [
    "wo3_monoclinic_2311041",
    "wo3_monoclinic_1528915",
    "wo3_triclinic_2106293",
]

FILES = {
    "ZnWO4": "znwo4_zncu_p2c_9005254",
    "WO3": "wo3_monoclinic_2311041",
    "ZnO": "zno_wurtzite_9004178",
}

WO3_START_CELLS = {
    "wo3_monoclinic_2311041": [7.29435, 7.53779, 10.50715, 90.0, 133.02592, 90.0],
    "wo3_monoclinic_1528915": [7.29057, 7.53529, 10.49998, 90.0, 133.04002, 90.0],
    "wo3_triclinic_2106293": [7.28992, 7.53158, 7.67301, 89.63845, 89.08198, 89.93050],
}


def set_cell(phase: G2sc.G2Phase, cell: list[float], refine: bool = True) -> None:
    phase.data["General"]["Cell"][0] = refine
    phase.data["General"]["Cell"][1:7] = [float(value) for value in cell]
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def product_start_cell(model: str, template_cell: dict[str, float], phase: G2sc.G2Phase) -> list[float]:
    a = template_cell["length_a"]
    b = template_cell["length_b"]
    c = template_cell["length_c"]
    beta = template_cell["angle_beta"]
    if model in {
        "znwo4_zncu_p2c_9005254",
        "znwo4_zncd_p2c_1520642",
        "znwo4_mg_p2c_9013902",
        "znwo4_mn_p2c_1520200",
    }:
        return [a, b, c, 90.0, beta, 90.0]
    if model == "znwo4_zncu_p1_9005253":
        source = phase.get_cell()
        return [a, b, c, source["angle_alpha"], source["angle_beta"], source["angle_gamma"]]
    if model == "znwo4_ordered_liyb_p2c_1527650":
        source = phase.get_cell()
        return [2.0 * a, b, c, 90.0, source["angle_beta"], 90.0]
    if model == "znwo4_scheelite_ca_i41a_7219229":
        source = phase.get_cell()
        target_volume = 2.0 * template_cell["volume"]
        factor = (target_volume / source["volume"]) ** (1.0 / 3.0)
        return [
            source["length_a"] * factor,
            source["length_b"] * factor,
            source["length_c"] * factor,
            90.0,
            90.0,
            90.0,
        ]
    raise KeyError(model)


def copy_histogram_model(template_hist, hist) -> None:
    sample_ran_id = hist.data["Sample Parameters"].get("ranId")
    hist.data["Limits"] = copy.deepcopy(template_hist.data["Limits"])
    hist.data["Background"] = copy.deepcopy(template_hist.data["Background"])
    hist.data["Instrument Parameters"] = copy.deepcopy(template_hist.data["Instrument Parameters"])
    hist.data["Sample Parameters"] = copy.deepcopy(template_hist.data["Sample Parameters"])
    if sample_ran_id is not None:
        hist.data["Sample Parameters"]["ranId"] = sample_ran_id


def configure_hap(project: G2sc.G2Project, template: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    thist = template.histogram(0)
    for phase in project.phases():
        source_phase = template.phase(phase.name)
        source_hap = source_phase.data["Histograms"][thist.name]
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = copy.deepcopy(source_hap["Scale"])
        hap["Pref.Ori."] = copy.deepcopy(source_hap["Pref.Ori."])
        hap["Size"][0:4] = copy.deepcopy(source_hap["Size"][0:4])
        hap["Mustrain"][0:4] = copy.deepcopy(source_hap["Mustrain"][0:4])
        hap["Extinction"] = copy.deepcopy(source_hap["Extinction"])
        hap["Babinet"] = copy.deepcopy(source_hap["Babinet"])
        hap["hId"] = hist.id
        hap["Use"] = True
        hap["LeBail"] = False
        phase.data["General"]["Cell"][0] = True
        for atom in phase.atoms():
            atom.refinement_flags = " "

        # Reapply symmetry-independent bounds for retained uniaxial terms.
        if phase.name == "ZnWO4":
            for var in ["Size;i", "Size;a"]:
                project.set_Controls("parmMin", 0.005, f"{phase.id}:0:{var}")
                project.set_Controls("parmMax", 100.0, f"{phase.id}:0:{var}")
        if phase.name == "WO3":
            for var in ["Mustrain;i", "Mustrain;a"]:
                project.set_Controls("parmMin", 0.0, f"{phase.id}:0:{var}")
                project.set_Controls("parmMax", 50000.0, f"{phase.id}:0:{var}")


def build(label: str, product_model: str, wo3_model: str, simplified: bool = False) -> dict[str, object]:
    path = OUT / f"{label}.gpx"
    template = G2sc.G2Project(str(TEMPLATE))
    template_hist = template.histogram(0)
    project = G2sc.G2Project(newgpx=str(path))
    hist = project.add_powder_histogram(
        str(WORK / "inputs" / "pattern.csv"),
        str(ANALYSIS / "cu_ka.instprm"),
        fmthint="comma",
    )
    model_files = {
        "ZnWO4": product_model,
        "WO3": wo3_model,
        "ZnO": FILES["ZnO"],
    }
    for name in ["ZnWO4", "WO3", "ZnO"]:
        project.add_phase(
            str(ANALYSIS / "candidates" / f"{model_files[name]}.cif"),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )

    copy_histogram_model(template_hist, hist)
    configure_hap(project, template)
    if simplified:
        # Restage a bound-hitting topology with low-flexibility isotropic
        # broadening. This gives the parent a clean cell/scale comparison
        # without forcing the wolframite-specific uniaxial directions on it.
        product_hap = project.phase("ZnWO4").data["Histograms"][hist.name]
        product_hap["Size"][0] = "isotropic"
        product_hap["Size"][1][0] = 0.10
        product_hap["Size"][2] = [True, False, False]
        product_hap["Mustrain"][0] = "isotropic"
        product_hap["Mustrain"][1][0] = 1.0
        product_hap["Mustrain"][2] = [False, False, False]
        wo3_hap = project.phase("WO3").data["Histograms"][hist.name]
        wo3_hap["Size"][0] = "isotropic"
        wo3_hap["Size"][1][0] = 0.30
        wo3_hap["Size"][2] = [True, False, False]
        wo3_hap["Mustrain"][0] = "isotropic"
        wo3_hap["Mustrain"][1][0] = 1.0
        wo3_hap["Mustrain"][2] = [False, False, False]
    template_product_cell = template.phase("ZnWO4").get_cell()
    set_cell(
        project.phase("ZnWO4"),
        product_start_cell(product_model, template_product_cell, project.phase("ZnWO4")),
    )
    set_cell(project.phase("WO3"), WO3_START_CELLS[wo3_model])
    zno_cell = template.phase("ZnO").get_cell()
    set_cell(
        project.phase("ZnO"),
        [
            zno_cell["length_a"],
            zno_cell["length_b"],
            zno_cell["length_c"],
            zno_cell["angle_alpha"],
            zno_cell["angle_beta"],
            zno_cell["angle_gamma"],
        ],
    )
    project.set_Controls("cycles", 25)
    project.set_Controls("parmMin", -3000.0, ":0:Shift")
    project.set_Controls("parmMax", 3000.0, ":0:Shift")
    project.set_Frozen()

    # A lower-flexibility first stage lets adapted cells/scales settle before
    # the complete profile model is re-enabled.
    flags = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        flags[phase.name] = {
            "size": copy.deepcopy(hap["Size"][2]),
            "mustrain": copy.deepcopy(hap["Mustrain"][2]),
            "pref": bool(hap["Pref.Ori."][2]),
        }
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = False
    project.refine()

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = flags[phase.name]["size"]
        hap["Mustrain"][2] = flags[phase.name]["mustrain"]
        hap["Pref.Ori."][2] = flags[phase.name]["pref"]
    project.refine()
    project.refine()
    project.save()
    return summarize(project, label, path, product_model, wo3_model)


def summarize(project, label, path, product_model, wo3_model) -> dict[str, object]:
    hist = project.histogram(0)
    return {
        "label": label,
        "project": str(path),
        "product_model": product_model,
        "wo3_model": wo3_model,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "shift": hist.SampleParameters["Shift"][0],
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][hist.name]["Scale"],
                "pref_ori": phase.data["Histograms"][hist.name]["Pref.Ori."],
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in project.phases()
        },
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    tasks = []
    for model in PRODUCT_MODELS:
        tasks.append((f"product_{model}", model, WO3_MODELS[0]))
    for model in WO3_MODELS:
        tasks.append((f"wo3_{model}", PRODUCT_MODELS[0], model))
    for label, product_model, wo3_model in tasks:
        print(f"### {label}", flush=True)
        try:
            result = build(label, product_model, wo3_model)
        except Exception as exc:
            traceback.print_exc()
            result = {
                "label": label,
                "product_model": product_model,
                "wo3_model": wo3_model,
                "status": "failed",
                "error": repr(exc),
            }
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
