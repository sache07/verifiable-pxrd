#!/usr/bin/env python3
"""Independently reload, refine, and compare the submitted GSAS-II project."""

from __future__ import annotations

import csv
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
FINAL = WORK / "final.gpx"
REPLAY_DIR = WORK / "analysis" / "replay"
REPLAY = REPLAY_DIR / "final_replay.gpx"


def normalized_fractions(project):
    values = project.histogram(0).ComputeMassFracs()
    total = sum(value[0] for value in values.values())
    return {name: value[0] / total for name, value in values.items()}


def snapshot(project):
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    return {
        "x": np.asarray(hist.getdata("X"), dtype=float),
        "ycalc": np.asarray(hist.getdata("Ycalc"), dtype=float),
        "background": np.asarray(hist.getdata("Background"), dtype=float),
        "fractions": normalized_fractions(project),
        "cells": {
            phase.name: phase.get_cell_and_esd()[0]
            for phase in project.phases()
        },
        "rwp": float(hist.residuals["wR"]),
        "chisq": float(cov["Rvals"]["chisq"]),
        "nobs": int(cov["Rvals"]["Nobs"]),
        "nvars": int(cov["Rvals"]["Nvars"]),
        "converged": bool(cov["Rvals"]["converged"]),
        "frozen": [str(item) for item in project.get_Frozen()],
    }


def max_cell_delta(left, right):
    deltas = []
    for name in left:
        for key, value in left[name].items():
            if key.startswith("length_") or key.startswith("angle_") or key == "volume":
                deltas.append(abs(float(value) - float(right[name][key])))
    return max(deltas, default=0.0)


def main():
    original = G2sc.G2Project(str(FINAL))
    before = snapshot(original)

    # Cross-check the serialized tabular and JSON products against a fresh
    # project load before doing the replay refinement.
    result = json.loads((WORK / "result.json").read_text())
    result_fractions = {
        item["name"]: float(item["weight_fraction"])
        for item in result["phases"]
    }
    result_fraction_delta = max(
        abs(before["fractions"][name] - value)
        for name, value in result_fractions.items()
    )

    with (WORK / "fit.csv").open(newline="") as stream:
        rows = list(csv.DictReader(stream))
    fit = {
        key: np.asarray([float(row[key]) for row in rows], dtype=float)
        for key in [
            "two_theta_deg",
            "observed_counts",
            "calculated_counts",
            "difference_counts",
            "background_counts",
        ]
    }
    hist = original.histogram(0)
    yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
    mask = before["ycalc"] != 0.0
    expected = {
        "two_theta_deg": before["x"][mask],
        "observed_counts": yobs[mask],
        "calculated_counts": before["ycalc"][mask],
        "difference_counts": (yobs - before["ycalc"])[mask],
        "background_counts": before["background"][mask],
    }
    fit_max_delta = {
        key: float(np.max(np.abs(fit[key] - expected[key])))
        for key in fit
    }

    REPLAY_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(FINAL, REPLAY)
    replay = G2sc.G2Project(str(REPLAY))
    replay.set_Frozen()
    replay.set_Controls("cycles", 20)
    replay.refine()
    replay.refine()
    replay.save()
    after = snapshot(replay)

    fraction_delta = max(
        abs(before["fractions"][name] - after["fractions"][name])
        for name in before["fractions"]
    )
    used = (before["ycalc"] != 0.0) | (after["ycalc"] != 0.0)
    curve_delta = float(np.max(np.abs(before["ycalc"][used] - after["ycalc"][used])))
    background_delta = float(
        np.max(np.abs(before["background"][used] - after["background"][used]))
    )

    checks = {
        "original_converged": before["converged"],
        "replay_converged": after["converged"],
        "original_frozen_empty": not before["frozen"],
        "replay_frozen_empty": not after["frozen"],
        "fit_row_count_matches_nobs": len(rows) == before["nobs"],
        "fit_values_match_project_to_rounding": max(fit_max_delta.values()) <= 5.1e-9,
        "result_fractions_match_project": result_fraction_delta <= 1e-12,
        "phase_sets_match": set(before["fractions"]) == set(after["fractions"]),
        "replay_fraction_stable": fraction_delta <= 1e-6,
        # A one-count pointwise change on steep peak flanks is far below the
        # Poisson noise in this pattern; the corresponding Rwp and fractions
        # are checked separately above.
        "replay_curve_stable_counts": curve_delta <= 2.0,
        "replay_cell_stable": max_cell_delta(before["cells"], after["cells"]) <= 2e-5,
    }
    audit = {
        "checks": checks,
        "all_checks_pass": all(checks.values()),
        "original": {
            key: value
            for key, value in before.items()
            if key not in {"x", "ycalc", "background"}
        },
        "replay": {
            key: value
            for key, value in after.items()
            if key not in {"x", "ycalc", "background"}
        },
        "deltas": {
            "rwp_percent": abs(before["rwp"] - after["rwp"]),
            "chi_square": abs(before["chisq"] - after["chisq"]),
            "max_weight_fraction": fraction_delta,
            "max_calculated_counts": curve_delta,
            "max_background_counts": background_delta,
            "max_cell_parameter_or_volume": max_cell_delta(before["cells"], after["cells"]),
            "result_weight_fraction": result_fraction_delta,
            "fit_columns": fit_max_delta,
        },
    }
    output = REPLAY_DIR / "replay_check.json"
    output.write_text(json.dumps(audit, indent=2) + "\n")
    print(json.dumps(audit, indent=2))
    if not audit["all_checks_pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
