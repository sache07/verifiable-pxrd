#!/usr/bin/env python3
"""Create all requested submission files from the selected final project."""

from __future__ import annotations

import csv
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
SOURCE = WORK / "analysis" / "post_atomic_profile" / "both_isotropic.gpx"
FINAL = WORK / "final.gpx"

PHASE_INFO = {
    "ZnWO4": {
        "formula": "ZnWO4",
        "structure_type": "wolframite",
        "source_model": "COD 9005254 (Zn/Cu wolframite; mixed divalent site mapped to Zn)",
    },
    "WO3": {
        "formula": "WO3",
        "structure_type": "monoclinic tungsten trioxide",
        "source_model": "COD 2311041",
    },
    "ZnO": {
        "formula": "ZnO",
        "structure_type": "wurtzite",
        "source_model": "COD 9004178",
    },
}


def top_correlations(project, count=8):
    cov = project.data["Covariance"]["data"]
    vary = [str(value) for value in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.size == 0:
        return []
    sigma = np.sqrt(np.clip(np.diag(matrix), 0, None))
    denominator = np.outer(sigma, sigma)
    corr = np.divide(matrix, denominator, out=np.zeros_like(matrix), where=denominator != 0)
    pairs = sorted(
        (
            (abs(float(corr[i, j])), vary[i], vary[j], float(corr[i, j]))
            for i in range(len(vary))
            for j in range(i)
        ),
        reverse=True,
    )
    return [
        {"parameter_1": a, "parameter_2": b, "correlation": signed}
        for _, a, b, signed in pairs[:count]
    ]


def screen_project(project):
    hist = project.histogram(0)
    problems = []
    if project.get_Frozen():
        problems.append(f"frozen variables: {project.get_Frozen()}")
    if not project.data["Covariance"]["data"].get("Rvals", {}).get("converged", False):
        problems.append("last refinement is not marked converged")
    polar = float(hist.InstrumentParameters["Polariz."][1])
    shl = float(hist.InstrumentParameters["SH/L"][1])
    if not 0.0 < polar < 1.0:
        problems.append(f"nonphysical polarization {polar}")
    if shl <= 0.0:
        problems.append(f"nonpositive SH/L {shl}")
    u, v, w = [float(hist.InstrumentParameters[key][1]) for key in ["U", "V", "W"]]
    theta = np.radians(np.linspace(5.0, 50.0, 500))
    gaussian_width = u * np.tan(theta) ** 2 + v * np.tan(theta) + w
    if np.min(gaussian_width) <= 0.0:
        problems.append("common Gaussian width is nonpositive in the fitted range")
    x = np.asarray(hist.getdata("X"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)
    low, high = hist.data["Limits"][1]
    used = (x >= low) & (x <= high)
    if np.min(background[used]) <= 0.0:
        problems.append("background is nonpositive in the fitted range")
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if hap["Scale"][0] <= 0.0:
            problems.append(f"{phase.name} has nonpositive scale")
        if hap["Size"][1][0] <= 0.0:
            problems.append(f"{phase.name} has nonpositive size")
        if hap["Mustrain"][1][0] < 0.0:
            problems.append(f"{phase.name} has negative microstrain")
        if hap["Pref.Ori."][1] <= 0.0:
            problems.append(f"{phase.name} has nonpositive texture ratio")
        for atom in phase.atoms():
            if not 0.0 < atom.occupancy <= 1.0:
                problems.append(f"{phase.name}/{atom.label} has occupancy {atom.occupancy}")
            if atom.uiso < 0.0:
                problems.append(f"{phase.name}/{atom.label} has negative Uiso {atom.uiso}")
    if problems:
        raise RuntimeError("; ".join(problems))


def main():
    shutil.copy2(SOURCE, FINAL)
    project = G2sc.G2Project(str(FINAL))
    project.save(str(FINAL))
    project.set_Frozen()
    project.set_Controls("cycles", 35)
    project.refine()
    project.refine()
    project.save()
    screen_project(project)

    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    fractions_raw = hist.ComputeMassFracs()
    total = sum(value[0] for value in fractions_raw.values())
    fractions = {
        name: (value[0] / total, value[1] / total)
        for name, value in fractions_raw.items()
    }

    phases_json = []
    for phase in project.phases():
        cif_name = f"{phase.name}.cif"
        phase.export_CIF(str(WORK / cif_name))
        cell, cell_esd = phase.get_cell_and_esd()
        sg = phase.data["General"]["SGData"]["SpGrp"].strip()
        info = PHASE_INFO[phase.name]
        value, esd = fractions[phase.name]
        phases_json.append(
            {
                "name": phase.name,
                "formula": info["formula"],
                "structure_type": info["structure_type"],
                "space_group": sg,
                "cif_path": cif_name,
                "weight_fraction": value,
                "weight_fraction_esd": esd,
                "weight_percent": 100.0 * value,
                "weight_percent_esd": 100.0 * esd,
                "cell": cell,
                "cell_esd": cell_esd,
                "source_model": info["source_model"],
            }
        )

    x = np.asarray(hist.getdata("X"), dtype=float)
    yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)
    # GSAS-II calculates through the first grid point above the upper limit
    # (the endpoint returned by its searchsorted-based range selection). Use
    # the populated calculated-profile array so this export contains exactly
    # the observations included in the saved refinement and reported Nobs.
    used = np.isfinite(ycalc) & (ycalc != 0.0)
    if int(np.count_nonzero(used)) != int(rvals["Nobs"]):
        raise RuntimeError(
            "calculated-profile point count does not match refinement Nobs: "
            f"{np.count_nonzero(used)} != {rvals['Nobs']}"
        )
    difference = yobs - ycalc
    with (WORK / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        for row in zip(x[used], yobs[used], ycalc[used], difference[used], background[used]):
            writer.writerow([f"{row[0]:.8f}"] + [f"{value:.8f}" for value in row[1:]])

    fit_statistics = {
        "r_wp_percent": float(hist.residuals["wR"]),
        "r_p_percent": float(hist.residuals["R"]),
        "r_exp_percent": float(hist.residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_square": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_variables": int(rvals["Nvars"]),
        "converged": bool(rvals["converged"]),
    }
    result = {
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
        "crystalline_fraction_basis": "Normalized over the modeled crystalline phases; amorphous content is not determined.",
        "phases": phases_json,
        "fit_statistics": fit_statistics,
        "formal_uncertainty_note": "Weight-fraction ESDs are covariance-derived internal uncertainties and do not include model/systematic uncertainty.",
    }
    (WORK / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    deletion = json.loads((WORK / "analysis" / "deletion_tests" / "results.json").read_text())
    deletion_rwp = {item["label"]: item["residuals"].get("wR") for item in deletion}
    corr = top_correlations(project)
    max_corr = max((abs(item["correlation"]) for item in corr), default=0.0)
    fraction_rows = "\n".join(
        f"| {item['name']} | {item['structure_type']} | {item['space_group']} | "
        f"{item['weight_percent']:.3f} ± {item['weight_percent_esd']:.3f} | "
        f"{item['cell']['length_a']:.5f}, {item['cell']['length_b']:.5f}, {item['cell']['length_c']:.5f} |"
        for item in phases_json
    )
    report = f"""# Powder XRD phase analysis

## Result

The pattern is modeled as three crystalline phases. Fractions are normalized only over these modeled crystalline phases.

| Phase | Model | Space group | Weight % | a, b, c (Å) |
|---|---|---:|---:|---|
{fraction_rows}

Fit statistics: Rwp = {fit_statistics['r_wp_percent']:.4f}%, Rp = {fit_statistics['r_p_percent']:.4f}%, Rexp = {fit_statistics['r_exp_percent']:.4f}%, GOF = {fit_statistics['goodness_of_fit']:.4f} ({fit_statistics['n_observations']} observations, {fit_statistics['n_variables']} variables).

## Evidence and model selection

The metadata reports ZnO + WO3 precursors heated at 750 °C and reflection Cu Kα data (λ1 = 1.540598 Å, λ2 = 1.544426 Å, Kα2/Kα1 = 0.5). The broad dominant family indexes as wolframite ZnWO4; sharp residual families identify monoclinic WO3 and wurtzite ZnO. Clean deletion fits raise Rwp from {fit_statistics['r_wp_percent']:.2f}% to {deletion_rwp['without_ZnWO4']:.2f}% without ZnWO4, {deletion_rwp['without_WO3']:.2f}% without WO3, and {deletion_rwp['without_ZnO']:.2f}% without ZnO. The WO3 deletion restores the 23.45/23.89/24.70° and related families; ZnO deletion restores 32.07/34.74/36.57/47.84/56.87/63.16° lines.

The ZnWO4 model derives from COD 9005254 after mapping its mixed Zn/Cu divalent site to Zn. Zn/Cd-, Mg-, Mn-, triclinic, doubled ordered, and scheelite parents were cell-adapted and compared. The Zn/Cu- and Zn/Cd-derived P2/c parents converge to effectively identical refined coordinates (Rwp difference <0.001%); the Zn/Cu source was retained because it is the composition-nearest parent. The low-symmetry and alternate-topology parents remained substantially worse after clean restarts.

For WO3, COD 2311041 monoclinic, COD 1528915 monoclinic, and COD 2106293 triclinic parents were compared with the cumulative inventory. After matched coordinate, heavy-W displacement, and profile refinement, the triclinic finalist gave Rwp 2.6762% with 104 variables, versus 2.6664% with 76 variables for the selected monoclinic source; monoclinic is favored by both χ² and parsimony. WO3 [001] March–Dollase texture is strongly required (ratio {project.phase('WO3').data['Histograms'][hist.name]['Pref.Ori.'][1]:.4f}); deleting it raises Rwp to 4.15%.

Coordinates were refined last by site/element blocks. The retained structures pass composition, occupancy, density, and interatomic-distance screening. The final nuisance model uses a positive 16-term Chebyshev background, specimen displacement, physical polarization, axial divergence, isotropic ZnWO4 size/strain, isotropic WO3 size/strain, WO3 texture, and stable heavy-W Uiso terms. Surface roughness, X/Y broadening, joint zero/displacement, and anisotropic post-atomic broadening were rejected because they hit bounds, were branch-dependent, or were unsupported. The largest retained parameter correlation is {max_corr:.3f}; independent starts reproduced the calculated curve, cells, fractions, and structure without frozen variables.

## Remaining uncertainty

The phase identities are secure, but the exact public parent for ZnWO4 is not uniquely distinguishable after coordinate refinement; the Zn/Cu- and Zn/Cd-derived P2/c models converge to the same powder solution. The reported ± values are formal covariance ESDs. Across valid nuisance/source restarts the fractions varied by roughly 0.1 weight-percentage point or less, but systematic uncertainty is larger than the formal ESDs; a practical interpretation is about ±0.2–0.4 percentage point per phase. No external standard was supplied, so amorphous material (if present) and absolute crystalline yield cannot be quantified. The final residual contains small isolated intensity/profile mismatches but no coherent unmodeled multi-line family.
"""
    (WORK / "report.md").write_text(report)

    audit = {
        "final_project": str(FINAL),
        "frozen": project.get_Frozen(),
        "fit_statistics": fit_statistics,
        "fractions": fractions,
        "top_correlations": corr,
        "background_min_counts": float(np.min(background[used])),
        "background_max_counts": float(np.max(background[used])),
        "instrument": {key: hist.InstrumentParameters[key][1] for key in ["U", "V", "W", "X", "Y", "SH/L", "Polariz."]},
        "shift_um": hist.SampleParameters["Shift"][0],
    }
    (WORK / "analysis" / "final_audit.json").write_text(json.dumps(audit, indent=2) + "\n")
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
