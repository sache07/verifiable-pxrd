#!/usr/bin/env python3
"""Recombine supported coordinate blocks across structural finalists."""

from __future__ import annotations

import json
import shutil
import traceback
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
OUT = WORK / "analysis" / "coordinate_combinations"

SOURCES = {
    "zncd_mono": WORK / "analysis" / "final_position" / "shift.gpx",
    "zncu_mono": WORK / "analysis" / "analogue_swaps" / "product_znwo4_zncu_p2c_9005254.gpx",
    "zncd_triclinic": WORK / "analysis" / "analogue_swaps" / "cumulative_wo3_triclinic_2106293.gpx",
}

P_METALS = {"ZnWO4": ["Zn0", "W1"]}
P_O2 = {"ZnWO4": ["Zn0", "W1", "O2"]}
P_O3 = {"ZnWO4": ["Zn0", "W1", "O3"]}
P_ALL = {"ZnWO4": ["Zn0", "W1", "O2", "O3"]}
P_WO3W = {
    "ZnWO4": ["Zn0", "W1", "O2", "O3"],
    "WO3": ["W0", "W1"],
}
P_WO3W_ZNO = {
    "ZnWO4": ["Zn0", "W1", "O2", "O3"],
    "WO3": ["W0", "W1"],
    "ZnO": ["O1"],
}
P_WO3_ALL = {
    "ZnWO4": ["Zn0", "W1", "O2", "O3"],
    "WO3": ["W0", "W1", "O2", "O3", "O4", "O5", "O6", "O7"],
}
ALL_COORDS = {
    "ZnWO4": ["Zn0", "W1", "O2", "O3"],
    "WO3": ["W0", "W1", "O2", "O3", "O4", "O5", "O6", "O7"],
    "ZnO": ["O1"],
}

FULL_BLOCKS = {
    "product_metals": P_METALS,
    "product_metals_O2": P_O2,
    "product_metals_O3": P_O3,
    "product_all": P_ALL,
    "product_all_wo3W": P_WO3W,
    "product_all_wo3W_znoO": P_WO3W_ZNO,
    "product_all_wo3_all": P_WO3_ALL,
    "all_coordinates": ALL_COORDS,
}

SHORT_BLOCKS = {
    "product_metals": P_METALS,
    "product_all": P_ALL,
    "product_all_wo3W": P_WO3W,
    "all_coordinates": ALL_COORDS,
}


def atom_state(project):
    return {
        phase.name: {
            atom.label: {
                "element": atom.element,
                "xyz": [float(v) for v in atom.coordinates],
                "uiso": float(atom.uiso),
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        }
        for phase in project.phases()
    }


def run(source_name, source, block_name, selection):
    label = f"{source_name}_{block_name}"
    path = OUT / f"{label}.gpx"
    shutil.copy2(source, path)
    project = G2sc.G2Project(str(path))
    project.save(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 30)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    for phase_name, labels in selection.items():
        phase = project.phase(phase_name)
        for label_name in labels:
            phase.atom(label_name).refinement_flags = "X"
    project.refine()
    project.refine()
    project.refine()
    project.save()
    hist = project.histogram(0)
    return {
        "label": label,
        "source": source_name,
        "block": block_name,
        "selection": selection,
        "project": str(path),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "atoms": atom_state(project),
    }


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for source_name, source in SOURCES.items():
        blocks = FULL_BLOCKS if source_name == "zncd_mono" else SHORT_BLOCKS
        for block_name, selection in blocks.items():
            print(f"### {source_name} {block_name}", flush=True)
            try:
                result = run(source_name, source, block_name, selection)
            except Exception as exc:
                traceback.print_exc()
                result = {
                    "label": f"{source_name}_{block_name}",
                    "status": "failed",
                    "error": repr(exc),
                }
            results.append(result)
            print(json.dumps(result, indent=2), flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
