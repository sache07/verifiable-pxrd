#!/usr/bin/env python3
"""Matched low-flexibility comparison of public WO3 references."""

from __future__ import annotations

import json
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
ANALYSIS = WORK / "analysis"
OUT = ANALYSIS / "wo3_comparison"
WO3_MODELS = [
    "wo3_monoclinic_2311041",
    "wo3_monoclinic_1528915",
    "wo3_triclinic_2106293",
    "wo3_orthorhombic_2107312",
    "wo3_tetragonal_1521532",
]


def background_points(hist: G2sc.G2PwdrData) -> list[tuple[float, float]]:
    x = np.asarray(hist.getdata("X"))
    y = np.asarray(hist.getdata("Yobs"))
    return [
        (
            float(center),
            float(np.percentile(y[np.abs(x - center) <= 1.25], 8)),
        )
        for center in np.arange(10.0, 100.01, 3.0)
    ]


def build(model: str) -> dict[str, object]:
    path = OUT / f"{model}.gpx"
    project = G2sc.G2Project(newgpx=str(path))
    hist = project.add_powder_histogram(
        str(WORK / "inputs" / "pattern.csv"),
        str(ANALYSIS / "cu_ka.instprm"),
        fmthint="comma",
    )
    phase_files = [
        ("ZnWO4", "znwo4_zncu_p2c_9005254", 0.10),
        ("WO3", model, 1.0),
        ("ZnO", "zno_wurtzite_9004178", 1.0),
    ]
    phases = []
    for name, filename, size in phase_files:
        phase = project.add_phase(
            str(ANALYSIS / "candidates" / f"{filename}.cif"),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase.data["Histograms"][hist.name]["Size"][1][0] = size
        phase.set_HAP_refinements({"Scale": True})
        phases.append(phase)
    project.set_Controls("cycles", 12)
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.SampleParameters["Scale"][1] = False
    hist.InstrumentParameters["Zero"][1] = 0.28
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "FixedPoints": background_points(hist),
                "fit fixed points": True,
                "refine": True,
            }
        }
    )
    project.refine()
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine()
    for phase in project.phases():
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True, "LGmix": {"value": 1.0, "refine": False}}}
        )
    project.refine()
    project.save()
    return {
        "model": model,
        "status": "ok",
        "project": str(path),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "sizes": {
            phase.name: phase.data["Histograms"][hist.name]["Size"][1]
            for phase in project.phases()
        },
        "scales": {
            phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
            for phase in project.phases()
        },
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for model in WO3_MODELS:
        print(f"\n### {model}", flush=True)
        try:
            result = build(model)
        except Exception as exc:
            traceback.print_exc()
            result = {"model": model, "status": "failed", "error": repr(exc)}
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)
    (OUT / "comparison.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
