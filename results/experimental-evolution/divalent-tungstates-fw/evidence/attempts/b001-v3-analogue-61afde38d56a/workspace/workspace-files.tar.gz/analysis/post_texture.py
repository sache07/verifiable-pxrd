#!/usr/bin/env python3
"""Re-equilibrate profile mechanisms after retaining WO3 [001] texture."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
UNORIENTED = WORK / "analysis" / "mechanism_screen" / "base_profile.gpx"
TEXTURED = WORK / "analysis" / "mechanism_screen" / "texture_WO3_0_0_1.gpx"
OUT = WORK / "analysis" / "post_texture"


def prepare(path: Path, source: Path = TEXTURED) -> G2sc.G2Project:
    shutil.copy2(source, path)
    project = G2sc.G2Project(str(path))
    project.save(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 20)
    return project


def correlations(project: G2sc.G2Project, count: int = 12) -> list[dict[str, object]]:
    cov = project.data.get("Covariance", {}).get("data", {})
    vary = [str(item) for item in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.size == 0:
        return []
    sigma = np.sqrt(np.clip(np.diag(matrix), 0, None))
    denom = np.outer(sigma, sigma)
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom != 0)
    pairs = sorted(
        (
            (abs(float(corr[i, j])), vary[i], vary[j], float(corr[i, j]))
            for i in range(len(vary))
            for j in range(i)
        ),
        reverse=True,
    )
    return [
        {"abs": value, "a": a, "b": b, "value": signed}
        for value, a, b, signed in pairs[:count]
    ]


def summary(project: G2sc.G2Project, label: str, path: Path) -> dict[str, object]:
    hist = project.histogram(0)
    return {
        "label": label,
        "project": str(path),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "background": hist.data["Background"][0],
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ["U", "V", "W", "X", "Y", "SH/L", "Polariz."]
        },
        "sample": {
            key: hist.SampleParameters[key][0]
            for key in ["Shift", "SurfRoughA", "SurfRoughB"]
        },
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "pref_ori": phase.data["Histograms"][hist.name]["Pref.Ori."],
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in project.phases()
        },
        "largest_correlations": correlations(project),
    }


def refine_twice(project: G2sc.G2Project) -> None:
    project.refine()
    project.refine()
    project.save()


def texture_start(label: str, ratio: float) -> dict[str, object]:
    path = OUT / f"{label}.gpx"
    project = prepare(path, UNORIENTED)
    hist = project.histogram(0)
    phase = project.phase("WO3")
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0], pref[1], pref[2], pref[3] = "MD", ratio, True, [0, 0, 1]
    project.set_Controls("parmMin", 0.3, f"{phase.id}:0:MD")
    project.set_Controls("parmMax", 3.0, f"{phase.id}:0:MD")
    refine_twice(project)
    return summary(project, label, path)


def set_uniaxial(project: G2sc.G2Project, phase_name: str, mechanism: str, axis: list[int]) -> None:
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][hist.name]
    if mechanism == "size":
        item = hap["Size"]
        start = float(item[1][0])
        item[0] = "uniaxial"
        item[1][0] = start
        item[1][1] = start
        item[2] = [True, True, False]
        item[3] = list(axis)
        for variable in ["Size;i", "Size;a"]:
            project.set_Controls("parmMin", 0.005, f"{phase.id}:0:{variable}")
            project.set_Controls("parmMax", 100.0, f"{phase.id}:0:{variable}")
    else:
        item = hap["Mustrain"]
        start = max(float(item[1][0]), 500.0)
        item[0] = "uniaxial"
        item[1][0] = start
        item[1][1] = start
        item[2] = [True, True, False]
        item[3] = list(axis)
        for variable in ["Mustrain;i", "Mustrain;a"]:
            project.set_Controls("parmMin", 0.0, f"{phase.id}:0:{variable}")
            project.set_Controls("parmMax", 50000.0, f"{phase.id}:0:{variable}")


def mechanism_branch(label: str, mechanisms: list[tuple[str, str, list[int]]]) -> dict[str, object]:
    path = OUT / f"{label}.gpx"
    project = prepare(path)
    for phase_name, mechanism, axis in mechanisms:
        set_uniaxial(project, phase_name, mechanism, axis)
    refine_twice(project)
    return summary(project, label, path)


def background_branch(order: int) -> dict[str, object]:
    label = f"background_{order}"
    path = OUT / f"{label}.gpx"
    project = prepare(path)
    project.histogram(0).set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": order}}
    )
    refine_twice(project)
    return summary(project, label, path)


def retry_branch(label: str) -> dict[str, object]:
    path = OUT / f"{label}.gpx"
    project = prepare(path)
    hist = project.histogram(0)
    if label == "retry_X":
        names = ["X"]
    elif label == "retry_Y":
        names = ["Y"]
    elif label == "retry_XY":
        names = ["X", "Y"]
    else:
        names = []
        hist.SampleParameters["SurfRoughA"] = [0.5, True]
        hist.SampleParameters["SurfRoughB"] = [0.02, True]
        project.set_Controls("parmMin", 0.001, ":0:SurfRoughA")
        project.set_Controls("parmMax", 0.999, ":0:SurfRoughA")
        project.set_Controls("parmMin", 0.000001, ":0:SurfRoughB")
        project.set_Controls("parmMax", 3.0, ":0:SurfRoughB")
    if names:
        hist.set_refinements({"Instrument Parameters": names})
        for name in names:
            hist.InstrumentParameters[name][1] = 0.01
            project.set_Controls("parmMin", 0.0, f":0:{name}")
            project.set_Controls("parmMax", 20.0, f":0:{name}")
    refine_twice(project)
    return summary(project, label, path)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    results = [summary(G2sc.G2Project(str(TEXTURED)), "textured_source", TEXTURED)]
    tasks = [
        ("texture_start_0p5", lambda: texture_start("texture_start_0p5", 0.5)),
        ("texture_start_1p5", lambda: texture_start("texture_start_1p5", 1.5)),
    ]
    branches = {
        "product_size_101": [("ZnWO4", "size", [1, 0, 1])],
        "product_size_010": [("ZnWO4", "size", [0, 1, 0])],
        "product_strain_101": [("ZnWO4", "strain", [1, 0, 1])],
        "wo3_size_001": [("WO3", "size", [0, 0, 1])],
        "wo3_strain_001": [("WO3", "strain", [0, 0, 1])],
        "product_size_wo3_strain": [
            ("ZnWO4", "size", [1, 0, 1]),
            ("WO3", "strain", [0, 0, 1]),
        ],
        "product_strain_wo3_strain": [
            ("ZnWO4", "strain", [1, 0, 1]),
            ("WO3", "strain", [0, 0, 1]),
        ],
        "product_size_wo3_size": [
            ("ZnWO4", "size", [1, 0, 1]),
            ("WO3", "size", [0, 0, 1]),
        ],
    }
    tasks.extend((label, lambda label=label, specs=specs: mechanism_branch(label, specs)) for label, specs in branches.items())
    tasks.extend((f"background_{order}", lambda order=order: background_branch(order)) for order in [8, 10, 12, 14, 16])
    tasks.extend((label, lambda label=label: retry_branch(label)) for label in ["retry_X", "retry_Y", "retry_XY", "retry_roughness"])

    for label, task in tasks:
        print(f"### {label}", flush=True)
        result = task()
        results.append(result)
        print(
            json.dumps(
                {
                    "label": label,
                    "wR": result["residuals"].get("wR"),
                    "mass_fractions": result["mass_fractions"],
                    "frozen": result["frozen"],
                    "instrument": result["instrument"],
                    "sample": result["sample"],
                    "background_order": result["background"][2],
                    "phases": {
                        name: {
                            "pref": phase["pref_ori"],
                            "size": phase["size"],
                            "mustrain": phase["mustrain"],
                        }
                        for name, phase in result["phases"].items()
                    },
                }
            ),
            flush=True,
        )
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
