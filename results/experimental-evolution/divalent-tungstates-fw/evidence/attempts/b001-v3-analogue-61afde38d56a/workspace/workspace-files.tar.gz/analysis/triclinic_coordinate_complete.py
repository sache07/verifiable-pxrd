#!/usr/bin/env python3
"""Complete element-driven coordinate blocks for the triclinic WO3 finalist."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
SOURCE = WORK / "analysis" / "analogue_swaps" / "cumulative_wo3_triclinic_2106293.gpx"
OUT = WORK / "analysis" / "triclinic_coordinate_complete"


def run(label, wo3_mode, include_zno=False):
    path = OUT / f"{label}.gpx"
    shutil.copy2(SOURCE, path)
    project = G2sc.G2Project(str(path))
    project.save(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 35)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    for atom in project.phase("ZnWO4").atoms():
        atom.refinement_flags = "X"
    for atom in project.phase("WO3").atoms():
        if wo3_mode == "all" or atom.element == "W":
            atom.refinement_flags = "X"
    if include_zno:
        project.phase("ZnO").atom("O1").refinement_flags = "X"
    project.refine()
    project.refine()
    project.refine()
    project.save()
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    return {
        "label": label,
        "project": str(path),
        "residuals": hist.residuals,
        "Rvals": {key: cov.get("Rvals", {}).get(key) for key in ["chisq", "Nobs", "Nvars", "GOF", "converged"]},
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "atoms": {
            phase.name: {
                atom.label: {
                    "element": atom.element,
                    "xyz": [float(value) for value in atom.coordinates],
                    "uiso": float(atom.uiso),
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            }
            for phase in project.phases()
        },
    }


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    specs = [
        ("product_all_wo3_W_all", "W", False),
        ("product_all_wo3_all", "all", False),
        ("all_coordinates", "all", True),
    ]
    results = []
    for spec in specs:
        print(f"### {spec[0]}", flush=True)
        result = run(*spec)
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
