#!/usr/bin/env python3
"""Independent composition, symmetry, occupancy, and geometry checks for CIFs."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


WORK = Path(__file__).resolve().parents[1]
EXPECTED = {
    "ZnWO4": {"elements": {"Zn": 1, "W": 1, "O": 4}, "sg_number": 13},
    "WO3": {"elements": {"W": 1, "O": 3}, "sg_number": 14},
    "ZnO": {"elements": {"Zn": 1, "O": 1}, "sg_number": 186},
}


def reduced_counts(structure):
    comp = structure.composition.element_composition
    reduced, factor = comp.get_reduced_composition_and_factor()
    return {str(element): float(amount) for element, amount in reduced.items()}


def metal_oxygen_shells(structure):
    rows = []
    for index, site in enumerate(structure):
        symbol = site.specie.symbol
        if symbol not in {"Zn", "W"}:
            continue
        cutoff = 2.60 if symbol == "Zn" else 2.45
        distances = sorted(
            float(neighbor.nn_distance)
            for neighbor in structure.get_neighbors(site, cutoff)
            if neighbor.specie.symbol == "O"
        )
        rows.append(
            {
                "site_index": index,
                "element": symbol,
                "oxygen_coordination_within_cutoff": len(distances),
                "distances_angstrom": distances,
            }
        )
    return rows


def main():
    result = json.loads((WORK / "result.json").read_text())
    result_by_name = {phase["name"]: phase for phase in result["phases"]}
    output = {}
    all_pass = True
    for name, expected in EXPECTED.items():
        path = WORK / result_by_name[name]["cif_path"]
        structure = Structure.from_file(path, primitive=False)
        analyzer = SpacegroupAnalyzer(structure, symprec=1e-3, angle_tolerance=0.1)
        distances = np.asarray(structure.distance_matrix, dtype=float)
        np.fill_diagonal(distances, np.inf)
        occupancies = [float(site.species.num_atoms) for site in structure]
        counts = reduced_counts(structure)
        formula_ok = counts == {key: float(value) for key, value in expected["elements"].items()}
        occupancy_ok = all(abs(value - 1.0) < 1e-8 for value in occupancies)
        min_distance = float(np.min(distances))
        distance_ok = min_distance > 1.25
        sg_number = int(analyzer.get_space_group_number())
        symmetry_ok = sg_number == expected["sg_number"]
        phase_pass = formula_ok and occupancy_ok and distance_ok and symmetry_ok
        all_pass &= phase_pass
        output[name] = {
            "path": str(path),
            "formula": structure.composition.formula,
            "reduced_formula": structure.composition.reduced_formula,
            "reduced_element_counts": counts,
            "sites_in_expanded_cell": len(structure),
            "density_g_cm3": float(structure.density),
            "minimum_interatomic_distance_angstrom": min_distance,
            "occupancy_min": min(occupancies),
            "occupancy_max": max(occupancies),
            "detected_space_group": analyzer.get_space_group_symbol(),
            "detected_space_group_number": sg_number,
            "metal_oxygen_shells": metal_oxygen_shells(structure),
            "checks": {
                "formula": formula_ok,
                "full_occupancy": occupancy_ok,
                "minimum_distance": distance_ok,
                "symmetry": symmetry_ok,
            },
            "all_checks_pass": phase_pass,
        }
    audit = {"all_checks_pass": all_pass, "phases": output}
    (WORK / "analysis" / "cif_screen.json").write_text(json.dumps(audit, indent=2) + "\n")
    print(json.dumps(audit, indent=2))
    if not all_pass:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
