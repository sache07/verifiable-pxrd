#!/usr/bin/env python3
"""Stability, background-order and peak-position tests for the retained profile."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
SOURCE = WORK / "analysis" / "mechanism_screen" / "texture_WO3_0_0_1.gpx"
OUT = WORK / "analysis" / "final_profile_screen"


def prepare(path: Path, source: Path = SOURCE) -> G2sc.G2Project:
    shutil.copy2(source, path)
    project = G2sc.G2Project(str(path))
    project.save(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    return project


def set_combined(
    project: G2sc.G2Project,
    product_size: tuple[float, float],
    wo3_strain: tuple[float, float],
    y_start: float,
    background_order: int,
    refine_y: bool = True,
) -> None:
    hist = project.histogram(0)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": background_order,
            }
        }
    )
    hist.clear_refinements({"Instrument Parameters": ["X", "Y"]})
    hist.InstrumentParameters["X"][1] = 0.0
    hist.InstrumentParameters["Y"][1] = y_start
    hist.InstrumentParameters["Y"][2] = refine_y
    project.set_Controls("parmMin", 0.0, ":0:Y")
    project.set_Controls("parmMax", 20.0, ":0:Y")
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    product = project.phase("ZnWO4")
    phap = product.data["Histograms"][hist.name]
    psize = phap["Size"]
    psize[0] = "uniaxial"
    psize[1][0], psize[1][1] = product_size
    psize[2] = [True, True, False]
    psize[3] = [1, 0, 1]
    for var in ["Size;i", "Size;a"]:
        project.set_Controls("parmMin", 0.005, f"{product.id}:0:{var}")
        project.set_Controls("parmMax", 100.0, f"{product.id}:0:{var}")

    wo3 = project.phase("WO3")
    whap = wo3.data["Histograms"][hist.name]
    strain = whap["Mustrain"]
    strain[0] = "uniaxial"
    strain[1][0], strain[1][1] = wo3_strain
    strain[2] = [True, True, False]
    strain[3] = [0, 0, 1]
    for var in ["Mustrain;i", "Mustrain;a"]:
        project.set_Controls("parmMin", 0.0, f"{wo3.id}:0:{var}")
        project.set_Controls("parmMax", 50000.0, f"{wo3.id}:0:{var}")


def refine_three(project: G2sc.G2Project) -> None:
    project.refine()
    project.refine()
    project.refine()
    project.save()


def curve_diagnostics(hist) -> dict[str, float]:
    arrays = hist.data["data"][1]
    x = np.asarray(arrays[0], dtype=float)
    bkg = np.asarray(arrays[4], dtype=float)
    used = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    bx = bkg[used]
    dx = float(np.mean(np.diff(x[used])))
    second = np.diff(bx, n=2) / (dx * dx)
    return {
        "background_min": float(np.min(bx)),
        "background_max": float(np.max(bx)),
        "background_second_derivative_rms": float(np.sqrt(np.mean(second * second))),
        "background_total_variation": float(np.sum(np.abs(np.diff(bx)))),
    }


def summary(project: G2sc.G2Project, label: str, path: Path) -> dict[str, object]:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "label": label,
        "project": str(path),
        "residuals": hist.residuals,
        "Rvals": cov.get("Rvals", {}),
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "curve": curve_diagnostics(hist),
        "background": hist.data["Background"][0],
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]
        },
        "sample": {
            key: hist.SampleParameters[key][0]
            for key in ["Shift", "SurfRoughA", "SurfRoughB"]
        },
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][hist.name]["Scale"],
                "pref_ori": phase.data["Histograms"][hist.name]["Pref.Ori."],
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in project.phases()
        },
        "vary_list": [str(value) for value in cov.get("varyList", [])],
    }


def combined_branch(
    label: str,
    product_size: tuple[float, float],
    wo3_strain: tuple[float, float],
    y_start: float,
    background_order: int,
    refine_y: bool = True,
) -> dict[str, object]:
    path = OUT / f"{label}.gpx"
    project = prepare(path)
    set_combined(project, product_size, wo3_strain, y_start, background_order, refine_y)
    refine_three(project)
    return summary(project, label, path)


def position_branch(label: str, source: Path, zero: float, shift: float, ref_zero: bool, ref_shift: bool) -> dict[str, object]:
    path = OUT / f"{label}.gpx"
    project = prepare(path, source)
    hist = project.histogram(0)
    hist.InstrumentParameters["Zero"][1] = zero
    hist.InstrumentParameters["Zero"][2] = ref_zero
    hist.SampleParameters["Shift"][0] = shift
    hist.SampleParameters["Shift"][1] = ref_shift
    project.set_Controls("parmMin", -1.0, ":0:Zero")
    project.set_Controls("parmMax", 1.0, ":0:Zero")
    project.set_Controls("parmMin", -3000.0, ":0:Shift")
    project.set_Controls("parmMax", 3000.0, ":0:Shift")
    refine_three(project)
    return summary(project, label, path)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    specs = [
        ("combined_small_bg16_y", (0.07, 0.09), (500.0, 500.0), 0.2, 16, True),
        ("combined_mid_bg16_y", (0.11, 0.14), (900.0, 1100.0), 1.0, 16, True),
        ("combined_large_bg16_y", (0.3, 0.5), (2500.0, 500.0), 3.0, 16, True),
        ("combined_mid_bg16_no_y", (0.11, 0.14), (900.0, 1100.0), 0.0, 16, False),
        ("combined_mid_bg18_y", (0.11, 0.14), (900.0, 1100.0), 1.0, 18, True),
        ("combined_mid_bg20_y", (0.11, 0.14), (900.0, 1100.0), 1.0, 20, True),
        ("combined_mid_bg24_y", (0.11, 0.14), (900.0, 1100.0), 1.0, 24, True),
    ]
    results = []
    for spec in specs:
        label = spec[0]
        print(f"### {label}", flush=True)
        result = combined_branch(*spec)
        results.append(result)
        print(json.dumps({"label": label, "wR": result["residuals"].get("wR"), "fractions": result["mass_fractions"], "frozen": result["frozen"], "curve": result["curve"]}), flush=True)

    source = OUT / "combined_mid_bg16_y.gpx"
    position_specs = [
        ("position_zero", 0.30, 0.0, True, False),
        ("position_shift", 0.0, -535.0, False, True),
        ("position_joint_a", 0.10, -300.0, True, True),
        ("position_joint_b", -0.20, -800.0, True, True),
    ]
    for label, zero, shift, ref_zero, ref_shift in position_specs:
        print(f"### {label}", flush=True)
        result = position_branch(label, source, zero, shift, ref_zero, ref_shift)
        results.append(result)
        print(json.dumps({"label": label, "wR": result["residuals"].get("wR"), "fractions": result["mass_fractions"], "frozen": result["frozen"], "zero": result["instrument"]["Zero"], "shift": result["sample"]["Shift"]}), flush=True)

    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
