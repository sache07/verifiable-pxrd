#!/usr/bin/env python3
"""Compare zero, specimen-displacement, and joint peak-position branches."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parents[1]
SOURCE = WORK / "analysis" / "wo3_comparison" / "wo3_monoclinic_2311041.gpx"
OUT = WORK / "analysis" / "position_branches"


BRANCHES = {
    "zero_only": {"zero": 0.28, "shift": 0.0, "ref_zero": True, "ref_shift": False},
    "shift_only": {"zero": 0.0, "shift": -500.0, "ref_zero": False, "ref_shift": True},
    "joint": {"zero": 0.10, "shift": -300.0, "ref_zero": True, "ref_shift": True},
}


def covariance_diagnostics(project: G2sc.G2Project) -> dict[str, object]:
    cov = project.data.get("Covariance", {}).get("data", {})
    vary = cov.get("varyList", [])
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.size == 0:
        return {}
    sigma = np.sqrt(np.clip(np.diag(matrix), 0, None))
    denom = np.outer(sigma, sigma)
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom != 0)
    pairs = []
    for i in range(len(vary)):
        for j in range(i):
            pairs.append((abs(float(corr[i, j])), str(vary[i]), str(vary[j]), float(corr[i, j])))
    pairs.sort(reverse=True)
    return {
        "vary_list": [str(value) for value in vary],
        "largest_correlations": [
            {"abs": item[0], "a": item[1], "b": item[2], "value": item[3]}
            for item in pairs[:12]
        ],
    }


def run_branch(name: str, settings: dict[str, object]) -> dict[str, object]:
    path = OUT / f"{name}.gpx"
    shutil.copy2(SOURCE, path)
    project = G2sc.G2Project(str(path))
    project.save(str(path))
    project.set_Controls("cycles", 20)
    project.set_Controls("parmMin", -1.0, ":0:Zero")
    project.set_Controls("parmMax", 1.0, ":0:Zero")
    project.set_Controls("parmMin", -3000.0, ":0:Shift")
    project.set_Controls("parmMax", 3000.0, ":0:Shift")
    hist = project.histogram(0)
    hist.InstrumentParameters["Zero"][1] = settings["zero"]
    hist.InstrumentParameters["Zero"][2] = bool(settings["ref_zero"])
    hist.SampleParameters["Shift"][0] = settings["shift"]
    hist.SampleParameters["Shift"][1] = bool(settings["ref_shift"])
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True})
    project.refine()
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine()
    project.save()
    return {
        "branch": name,
        "project": str(path),
        "residuals": hist.residuals,
        "zero_deg": hist.InstrumentParameters["Zero"][1],
        "shift_um": hist.SampleParameters["Shift"][0],
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "mass_fractions": hist.ComputeMassFracs(),
        "covariance": covariance_diagnostics(project),
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for name, settings in BRANCHES.items():
        print(f"\n### {name}", flush=True)
        result = run_branch(name, settings)
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)
    (OUT / "branches.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
