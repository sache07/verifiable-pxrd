#!/usr/bin/env python3
"""Prepare composition-normalized structural candidates from public COD CIFs.

All source IDs and transformations are explicit so that provenance can be
retained while the exact Zn-W-O composition is absent from the supplied
library. This script does not inspect generator or scoring information.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/"
    "resources/b001-c04/cif"
)
OUT = Path(__file__).resolve().parent / "candidates"


# Several independent wolframite relatives, a lower-symmetry Zn/Cu member,
# an ordered doubled wolframite relative, and a scheelite topology are kept.
SOURCES = {
    "znwo4_zncu_p2c_9005254": {
        "id": "9005254",
        "kind": "wolframite",
        "transformation": "Replace Cu/Zn mixed metal site by fully occupied Zn.",
    },
    "znwo4_zncd_p2c_1520642": {
        "id": "1520642",
        "kind": "wolframite",
        "transformation": "Replace Cd/Zn mixed metal site by fully occupied Zn.",
    },
    "znwo4_mg_p2c_9013902": {
        "id": "9013902",
        "kind": "wolframite",
        "transformation": "Isovalent Mg-to-Zn substitution on the metal site.",
    },
    "znwo4_mn_p2c_1520200": {
        "id": "1520200",
        "kind": "wolframite",
        "transformation": "Isovalent Mn-to-Zn substitution on the metal site.",
    },
    "znwo4_zncu_p1_9005253": {
        "id": "9005253",
        "kind": "triclinic-wolframite-relative",
        "transformation": "Replace Cu/Zn mixed metal site by fully occupied Zn.",
    },
    "znwo4_ordered_liyb_p2c_1527650": {
        "id": "1527650",
        "kind": "ordered-doubled-wolframite-relative",
        "transformation": (
            "Map the distinct Li and Yb metal sites to fully occupied Zn; "
            "retain the doubled P2/c parent framework for matched testing."
        ),
    },
    "znwo4_scheelite_ca_i41a_7219229": {
        "id": "7219229",
        "kind": "scheelite",
        "transformation": "Isovalent Ca-to-Zn substitution in the scheelite framework.",
    },
    "zno_wurtzite_9004178": {
        "id": "9004178",
        "kind": "wurtzite",
        "transformation": "No compositional transformation.",
    },
    "wo3_monoclinic_2311041": {
        "id": "2311041",
        "kind": "wo3-monoclinic",
        "transformation": "No compositional transformation; alternative P21/c setting retained.",
    },
    "wo3_monoclinic_1528915": {
        "id": "1528915",
        "kind": "wo3-monoclinic",
        "transformation": "No compositional transformation.",
    },
    "wo3_triclinic_2106293": {
        "id": "2106293",
        "kind": "wo3-triclinic",
        "transformation": "No compositional transformation.",
    },
    "wo3_orthorhombic_2107312": {
        "id": "2107312",
        "kind": "wo3-orthorhombic",
        "transformation": "No compositional transformation.",
    },
    "wo3_tetragonal_1521532": {
        "id": "1521532",
        "kind": "wo3-tetragonal",
        "transformation": "No compositional transformation.",
    },
}


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def normalize_to_chemistry(structure: Structure, phase_kind: str) -> Structure:
    """Return an ordered O/W/Zn structure with all non-W/O sites set to Zn."""
    species: list[str] = []
    for site in structure:
        symbols = {element.symbol for element in site.species.elements}
        if symbols == {"O"}:
            species.append("O")
        elif symbols == {"W"}:
            species.append("W")
        elif phase_kind == "wurtzite" and symbols == {"Zn"}:
            species.append("Zn")
        else:
            species.append("Zn")
    return Structure(
        structure.lattice,
        species,
        [site.frac_coords for site in structure],
        coords_are_cartesian=False,
    )


def neighbor_shells(structure: Structure) -> dict[str, list[list[float]]]:
    """List six nearest oxygen distances for symmetry-distinct metal sites."""
    analyzer = SpacegroupAnalyzer(structure, symprec=1e-3, angle_tolerance=3)
    symm = analyzer.get_symmetrized_structure()
    shells: dict[str, list[list[float]]] = {"Zn": [], "W": []}
    for equivalent_indices in symm.equivalent_indices:
        i = equivalent_indices[0]
        symbol = structure[i].specie.symbol
        if symbol not in shells:
            continue
        distances = sorted(
            structure[i].distance(structure[j])
            for j in range(len(structure))
            if structure[j].specie.symbol == "O"
        )
        shells[symbol].append([round(float(value), 5) for value in distances[:6]])
    return shells


def screen(structure: Structure) -> dict[str, object]:
    matrix = structure.distance_matrix.copy()
    np.fill_diagonal(matrix, np.inf)
    analyzer = SpacegroupAnalyzer(structure, symprec=1e-3, angle_tolerance=3)
    formula = structure.composition.reduced_formula
    shells = neighbor_shells(structure)
    min_distance = float(matrix.min())
    composition_ok = formula in {"ZnWO4", "ZnO", "WO3"}
    # Broad, chemistry-based sanity limits only; detailed source choice is made
    # from the data and matched refinements, not from this screen.
    # W is tetrahedral in scheelite and octahedral in wolframite; checking the
    # four nearest O neighbors screens clashes without falsely rejecting either
    # defensible topology. The full listed shells remain available for review.
    metal_oxygen_ok = all(
        all(1.55 <= distance <= 2.85 for distance in shell[:4])
        for values in shells.values()
        for shell in values
    )
    return {
        "formula": formula,
        "space_group": analyzer.get_space_group_symbol(),
        "space_group_number": analyzer.get_space_group_number(),
        "lattice": [round(float(x), 8) for x in (*structure.lattice.abc, *structure.lattice.angles)],
        "volume_A3": round(float(structure.volume), 8),
        "density_g_cm3": round(float(structure.density), 6),
        "minimum_interatomic_distance_A": round(min_distance, 6),
        "metal_oxygen_shells_A": shells,
        "composition_ok": composition_ok,
        "metal_oxygen_geometry_ok": metal_oxygen_ok,
        "passes_initial_screen": bool(composition_ok and min_distance > 1.45 and metal_oxygen_ok),
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    records: list[dict[str, object]] = []
    for name, metadata in SOURCES.items():
        source = cod_path(metadata["id"])
        structure = Structure.from_file(source, primitive=False)
        normalized = normalize_to_chemistry(structure, metadata["kind"])
        output = OUT / f"{name}.cif"
        CifWriter(normalized, symprec=1e-4).write_file(output)
        record = {
            "name": name,
            **metadata,
            "source_cif": str(source),
            "candidate_cif": str(output),
            "screen": screen(normalized),
        }
        records.append(record)
    (OUT / "provenance_and_screen.json").write_text(
        json.dumps({"schema_version": 1, "records": records}, indent=2) + "\n"
    )
    for record in records:
        result = record["screen"]
        print(
            f"{record['name']}: {result['formula']} "
            f"{result['space_group']} ({result['space_group_number']}), "
            f"V={result['volume_A3']:.3f} A^3, "
            f"dmin={result['minimum_interatomic_distance_A']:.3f} A, "
            f"pass={result['passes_initial_screen']}"
        )


if __name__ == "__main__":
    main()
