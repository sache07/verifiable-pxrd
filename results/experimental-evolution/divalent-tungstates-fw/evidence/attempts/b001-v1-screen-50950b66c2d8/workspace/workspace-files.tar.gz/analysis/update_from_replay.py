#!/usr/bin/env python3
"""Replace profile/statistics with the independently regenerated GPX replay."""

import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
with np.load(ROOT / "analysis" / "final_replay_direct" / "prediction.npz") as replay:
    x = replay["x"].copy()
    observed = replay["observed"].copy()
    calculated = replay["predicted"].copy()

difference = observed - calculated
weights = 1.0 / np.maximum(observed, 1.0)
chi2 = float(np.sum(weights * difference**2))
denominator = float(np.sum(weights * observed**2))
rwp = float(100.0 * np.sqrt(chi2 / denominator))
rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))

result_path = ROOT / "result.json"
result = json.loads(result_path.read_text())
n_parameters = int(result["fit_statistics"]["number_of_refined_parameters"])
dof = max(1, len(x) - n_parameters)
result["fit_statistics"].update(
    {
        "rwp_percent": rwp,
        "rp_percent": rp,
        "chi_square_weighted_residual": chi2,
        "reduced_chi_square": chi2 / dof,
        "gof": float(np.sqrt(chi2 / dof)),
        "profile_source": "independent no-refinement replay of final.gpx",
    }
)
result_path.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

np.savetxt(
    ROOT / "fit.csv",
    np.column_stack((x, observed, calculated, difference)),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference",
    comments="",
    fmt="%.8f",
)
