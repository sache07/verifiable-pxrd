#!/usr/bin/env python3
"""Low-flexibility GSAS-II source/inventory comparison with fixed coordinates.

Run with the GSAS-II Python environment. Candidate IDs refer to the normalized
catalog generated in analysis/candidate_pool. The script writes a GPX, a profile
CSV and a compact JSON audit for each comparison.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
CATALOG_PATH = ROOT / "analysis" / "candidate_pool_v2" / "catalog.json"


def instrument_text(profile_restart: str = "default") -> str:
    # Initial widths are estimated from isolated observed lines. Coordinates,
    # occupancies and ADPs remain fixed during all comparisons.
    if profile_restart == "broad":
        u, v, w, x = 35.0, 0.0, 35.0, 8.0
    else:
        u, v, w, x = 20.0, 0.0, 25.0, 5.0
    return (
        "# GSAS-II public Cu K-alpha metadata; profile initialized from observed widths\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.5;Azimuth:0.0\n"
        f"U:{u};V:{v};W:{w};X:{x};Y:0.0;Z:0.0;SH/L:0.002\n"
    )


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def run_refinement(
    phase_ids: list[str],
    output_dir: Path,
    fixed_cell_ids: set[str] | None = None,
    position_model: str = "zero",
    background_coefficients: int = 6,
    stop_after: str | None = None,
    profile_restart: str = "default",
) -> dict:
    fixed_cell_ids = fixed_cell_ids or set()
    output_dir.mkdir(parents=True, exist_ok=True)
    catalog = json.loads(CATALOG_PATH.read_text())
    records = {r["id"]: r for r in catalog["records"]}
    missing = [p for p in phase_ids if p not in records]
    if missing:
        raise KeyError(f"Unknown candidate IDs: {missing}")

    pattern = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    x, y = pattern.T
    sigma = np.sqrt(np.maximum(y, 1.0))
    data_path = output_dir / "observed.xye"
    np.savetxt(data_path, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")
    inst_path = output_dir / "instrument.instprm"
    inst_path.write_text(instrument_text(profile_restart))

    gpx_path = output_dir / "comparison.gpx"
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(gpx_path))
    histogram = project.add_powder_histogram(
        str(data_path), str(inst_path), phases=[], fmthint="xye"
    )
    phases = []
    for phase_id in phase_ids:
        record = records[phase_id]
        cif = CATALOG_PATH.parent / record["model_path"]
        phase = project.add_phase(
            str(cif), phasename=phase_id, histograms=[histogram], fmthint="CIF"
        )
        phases.append(phase)

    histogram.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": background_coefficients,
                "coeffs": [float(np.percentile(y, 35))]
                + [0.0] * (background_coefficients - 1),
                "refine": False,
            },
        }
    )
    histogram.SampleParameters["Type"] = "Bragg-Brentano"
    histogram.SampleParameters["Scale"] = [1.0, False]
    for phase in phases:
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]

    project.set_Controls("cycles", 8)
    project.save()

    stages = [
        ("background_scales", {"set": {"Background": True, "Scale": True}}),
        ("cells", None),
        ("position", None),
        ("profile_WX", {"set": {"Instrument Parameters": ["W", "X"]}}),
        ("profile_UVY", {"set": {"Instrument Parameters": ["U", "V", "Y"]}}),
        ("settle", {}),
    ]
    audit_stages = []
    for name, refinement in stages:
        if name == "cells":
            for phase in phases:
                phase.set_refinements({"Cell": phase.name not in fixed_cell_ids})
            project.do_refinements([{}], makeBack=False)
        elif name == "position":
            if position_model == "zero":
                histogram.set_refinements({"Instrument Parameters": ["Zero"]})
            elif position_model == "shift":
                histogram.set_refinements({"Sample Parameters": ["Shift"]})
            elif position_model != "none":
                raise ValueError(f"Unknown position model: {position_model}")
            project.do_refinements([{}], makeBack=False)
        else:
            project.do_refinements([refinement], makeBack=False)
        cov = project.data.get("Covariance", {}).get("data", {})
        audit_stages.append(
            {
                "stage": name,
                "rwp_percent": float(histogram.get_wR()),
                "gof": plain(cov.get("Rvals", {}).get("GOF")),
                "vary_list": plain(cov.get("varyList", [])),
                "variables": plain(cov.get("variables", [])),
                "sigmas": plain(cov.get("sig", [])),
            }
        )
        if stop_after == name:
            break

    project.save(str(gpx_path))
    data = histogram.data["data"][1]
    profile_path = output_dir / "fit.csv"
    np.savetxt(
        profile_path,
        np.column_stack((data[0], data[1], data[3], data[1] - data[3], data[4])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
        fmt="%.8f",
    )

    inst = histogram.data["Instrument Parameters"][0]
    masses = []
    raw_mass_scales = []
    phase_rows = []
    for phase in phases:
        mass = float(phase.data["General"]["Mass"])
        scale = float(phase.data["Histograms"][histogram.name]["Scale"][0])
        masses.append(mass)
        raw_mass_scales.append(mass * scale)
    total = float(sum(raw_mass_scales))
    for phase, mass, mass_scale in zip(phases, masses, raw_mass_scales):
        phase_rows.append(
            {
                "id": phase.name,
                "weight_fraction": mass_scale / total if total > 0 else None,
                "scale": float(phase.data["Histograms"][histogram.name]["Scale"][0]),
                "cell_mass": mass,
                "cell": phase.get_cell(),
                "atoms_refined": False,
            }
        )
    weights = 1.0 / np.maximum(data[1], 1.0)
    chi2 = float(np.sum(weights * (data[1] - data[3]) ** 2))
    rwp = float(100.0 * np.sqrt(chi2 / np.sum(weights * data[1] ** 2)))
    result = {
        "phase_ids": phase_ids,
        "fixed_coordinates": True,
        "fixed_cell_ids": sorted(fixed_cell_ids),
        "position_model": position_model,
        "background_coefficient_count": background_coefficients,
        "profile_restart": profile_restart,
        "profile_model": "common instrumental U,V,W,X,Y; fixed 10 um isotropic size; zero microstrain; no texture",
        "rwp_percent_recomputed": rwp,
        "rwp_percent_gsas": float(histogram.get_wR()),
        "chi_square_weighted_residual": chi2,
        "instrument": {k: plain(v) for k, v in inst.items()},
        "background": plain(histogram.data["Background"]),
        "sample_parameters": plain(histogram.data["Sample Parameters"]),
        "phases": phase_rows,
        "stages": audit_stages,
        "gpx": str(gpx_path.relative_to(ROOT)),
        "fit_csv": str(profile_path.relative_to(ROOT)),
    }
    (output_dir / "audit.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phases", nargs="+", required=True)
    parser.add_argument("--fixed-cell", nargs="*", default=[])
    parser.add_argument("--position-model", choices=["zero", "shift", "none"], default="zero")
    parser.add_argument("--background-coefficients", type=int, default=6)
    parser.add_argument(
        "--stop-after",
        choices=["background_scales", "cells", "position", "profile_WX", "profile_UVY", "settle"],
    )
    parser.add_argument("--profile-restart", choices=["default", "broad"], default="default")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    result = run_refinement(
        args.phases,
        args.out.resolve(),
        set(args.fixed_cell),
        args.position_model,
        args.background_coefficients,
        args.stop_after,
        args.profile_restart,
    )
    print(json.dumps({k: result[k] for k in ["phase_ids", "rwp_percent_recomputed", "phases"]}, indent=2))


if __name__ == "__main__":
    main()
