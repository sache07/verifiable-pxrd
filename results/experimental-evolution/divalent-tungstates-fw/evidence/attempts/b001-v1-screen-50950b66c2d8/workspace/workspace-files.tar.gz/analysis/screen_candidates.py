#!/usr/bin/env python3
"""Apply the benchmark physical screen to normalized candidate CIFs."""

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCORER = ROOT / "learned" / "divalent-tungstates" / "scorer" / "src"
sys.path.insert(0, str(SCORER))

from common import load_structure  # noqa: E402
from structure_metrics import physical_screen  # noqa: E402


catalog_path = ROOT / "analysis" / "candidate_pool_v2" / "catalog.json"
catalog = json.loads(catalog_path.read_text())
results = []
for record in catalog["records"]:
    cif_path = catalog_path.parent / record["model_path"]
    structure = load_structure(cif_path)
    screen = physical_screen(structure)
    results.append(
        {
            "id": record["id"],
            "normalized_cif": str(cif_path.relative_to(ROOT)),
            "formula": record["formula"],
            "space_group": structure.get_space_group_info(),
            "cell": [*structure.lattice.abc, *structure.lattice.angles],
            "density_g_cm3": float(structure.density),
            "minimum_separation_A": record["minimum_separation_A"],
            "physical_screen": screen,
            "provenance": record["provenance"],
            "source_conditions": record["source_conditions"],
        }
    )

out = ROOT / "analysis" / "candidate_screens.json"
out.write_text(json.dumps(results, indent=2, allow_nan=False) + "\n")
for result in results:
    screen = result["physical_screen"]
    print(
        result["id"],
        result["space_group"],
        screen["status"],
        "flags=", screen["flagged_contact_count"],
        "dmin=", f"{result['minimum_separation_A']:.4f}",
    )
