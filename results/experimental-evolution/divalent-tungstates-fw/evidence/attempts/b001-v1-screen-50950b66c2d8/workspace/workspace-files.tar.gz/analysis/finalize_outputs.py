#!/usr/bin/env python3
"""Export submission artifacts from the selected, already-refined GSAS-II project."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE_GPX = ROOT / "analysis" / "fourphase" / "test_profile_YU" / "refined.gpx"
FINAL_GPX = ROOT / "final.gpx"

PHASE_INFO = {
    "cawo4_scheelite_7219229": {
        "name": "CaWO4 (scheelite)",
        "cif_path": "phase_CaWO4_scheelite.cif",
        "source": "COD 7219229",
    },
    "wo3_triclinic_2106293": {
        "name": "WO3 (triclinic)",
        "cif_path": "phase_WO3_triclinic.cif",
        "source": "COD 2106293",
    },
    "calcite_1547347": {
        "name": "CaCO3 (calcite)",
        "cif_path": "phase_CaCO3_calcite.cif",
        "source": "COD 1547347",
    },
    "cao_rocksalt_1563196": {
        "name": "CaO (rocksalt)",
        "cif_path": "phase_CaO_rocksalt.cif",
        "source": "COD 1563196",
    },
}


project = G2.G2Project(gpxfile=str(SOURCE_GPX))
project.save(str(FINAL_GPX))
histogram = project.histograms()[0]

mass_scales = []
for phase in project.phases():
    info = PHASE_INFO[phase.name]
    phase.export_CIF(str(ROOT / info["cif_path"]))
    hap = phase.data["Histograms"][histogram.name]
    mass_scales.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
total_mass_scale = float(sum(mass_scales))

profile = histogram.data["data"][1]
x, observed, calculated, background = [np.asarray(profile[i], float) for i in [0, 1, 3, 4]]
difference = observed - calculated
weights = 1.0 / np.maximum(observed, 1.0)
chi2 = float(np.sum(weights * difference**2))
denominator = float(np.sum(weights * observed**2))
rwp = float(100.0 * np.sqrt(chi2 / denominator))
rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
vary_count = len(project.data.get("Covariance", {}).get("data", {}).get("varyList", []))
dof = max(1, len(x) - vary_count)
reduced_chi2 = chi2 / dof

np.savetxt(
    ROOT / "fit.csv",
    np.column_stack((x, observed, calculated, difference)),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference",
    comments="",
    fmt="%.8f",
)

phase_rows = []
for phase, mass_scale in zip(project.phases(), mass_scales):
    info = PHASE_INFO[phase.name]
    phase_rows.append(
        {
            "name": info["name"],
            "cif_path": info["cif_path"],
            "weight_fraction": mass_scale / total_mass_scale,
            "source": info["source"],
        }
    )

result = {
    "phases": phase_rows,
    "fit_statistics": {
        "rwp_percent": rwp,
        "rp_percent": rp,
        "chi_square_weighted_residual": chi2,
        "reduced_chi_square": reduced_chi2,
        "gof": float(np.sqrt(reduced_chi2)),
        "number_of_points": int(len(x)),
        "number_of_refined_parameters": int(vary_count),
        "weighting": "1/max(observed_counts,1)",
    },
    "refinement_histogram": histogram.name,
    "fraction_basis": "normalized over modeled crystalline phases",
}
(ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

print(json.dumps(result, indent=2))
