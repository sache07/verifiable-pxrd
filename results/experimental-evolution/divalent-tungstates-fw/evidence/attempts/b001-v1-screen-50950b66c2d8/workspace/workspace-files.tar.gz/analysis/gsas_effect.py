#!/usr/bin/env python3
"""Apply one or more reversible GSAS-II refinement effects to a saved branch."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def correlations(cov: dict, threshold: float = 0.8) -> list[dict]:
    names = cov.get("varyList", [])
    matrix = cov.get("covMatrix")
    if matrix is None or not names:
        return []
    matrix = np.asarray(matrix, float)
    sd = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    denom = sd[:, None] * sd[None, :]
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
    rows = []
    for i in range(len(names)):
        for j in range(i):
            if abs(corr[i, j]) >= threshold:
                rows.append(
                    {"a": str(names[j]), "b": str(names[i]), "correlation": float(corr[i, j])}
                )
    return sorted(rows, key=lambda r: -abs(r["correlation"]))[:100]


def apply_effect(project: G2.G2Project, effect: str) -> None:
    histogram = project.histograms()[0]
    inst = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]
    parts = effect.split(":")
    kind = parts[0]
    if kind == "shl":
        inst["SH/L"][2] = True
    elif kind == "instrument":
        if len(parts) != 2 or parts[1] not in inst:
            raise ValueError("instrument syntax is instrument:PARAMETER")
        inst[parts[1]][2] = True
    elif kind == "polarization":
        inst["Polariz."][2] = True
    elif kind == "roughness":
        sample["SurfRoughA"] = [0.5, True]
        sample["SurfRoughB"] = [0.01, True]
    elif kind == "size":
        phase = project.phase(":".join(parts[1:]))
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [True, False, False]
    elif kind == "strain":
        phase = project.phase(":".join(parts[1:]))
        hap = phase.data["Histograms"][histogram.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 100.0
        hap["Mustrain"][1][1] = 100.0
        hap["Mustrain"][2] = [True, False, False]
    elif kind == "texture":
        if len(parts) != 5:
            raise ValueError("texture syntax is texture:PHASE:h:k:l")
        phase = project.phase(parts[1])
        hap = phase.data["Histograms"][histogram.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = [int(v) for v in parts[2:5]]
    elif kind == "atomxyz":
        if len(parts) != 3:
            raise ValueError("atomxyz syntax is atomxyz:PHASE:LABEL")
        atom = project.phase(parts[1]).atom(parts[2])
        if atom is None:
            raise ValueError(f"No atom {parts[2]} in {parts[1]}")
        atom.refinement_flags = "X"
    elif kind == "phase_xyz":
        if len(parts) != 2:
            raise ValueError("phase_xyz syntax is phase_xyz:PHASE")
        project.phase(parts[1]).set_refinements({"Atoms": {"all": "X"}})
    elif kind == "element_xyz":
        if len(parts) != 3:
            raise ValueError("element_xyz syntax is element_xyz:PHASE:ELEMENT")
        phase = project.phase(parts[1])
        selected = [atom for atom in phase.atoms() if atom.element == parts[2]]
        if not selected:
            raise ValueError(f"No {parts[2]} atoms in {parts[1]}")
        for atom in selected:
            atom.refinement_flags = "X"
    else:
        raise ValueError(f"Unknown effect: {effect}")


def phase_rows(project: G2.G2Project, histogram) -> list[dict]:
    raw = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        mass = float(phase.data["General"]["Mass"])
        scale = float(hap["Scale"][0])
        raw.append((phase, hap, mass, scale, mass * scale))
    total = sum(row[-1] for row in raw)
    return [
        {
            "id": phase.name,
            "weight_fraction": mass_scale / total,
            "scale": scale,
            "cell_mass": mass,
            "cell": phase.get_cell(),
            "size": plain(hap["Size"]),
            "mustrain": plain(hap["Mustrain"]),
            "preferred_orientation": plain(hap["Pref.Ori."]),
            "atom_refinement_flags": {atom.label: atom.refinement_flags for atom in phase.atoms()},
        }
        for phase, hap, mass, scale, mass_scale in raw
    ]


def snapshot(project: G2.G2Project, label: str) -> dict:
    histogram = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    data = histogram.data["data"][1]
    weights = 1.0 / np.maximum(data[1], 1.0)
    chi2 = float(np.sum(weights * (data[1] - data[3]) ** 2))
    denominator = float(np.sum(weights * data[1] ** 2))
    return {
        "stage": label,
        "rwp_percent": float(100 * np.sqrt(chi2 / denominator)),
        "chi_square_weighted_residual": chi2,
        "gof": plain(cov.get("Rvals", {}).get("GOF")),
        "vary_list": plain(cov.get("varyList", [])),
        "variables": plain(cov.get("variables", [])),
        "sigmas": plain(cov.get("sig", [])),
        "high_correlations": correlations(cov),
        "instrument": plain(histogram.data["Instrument Parameters"][0]),
        "sample_parameters": plain(histogram.data["Sample Parameters"]),
        "background": plain(histogram.data["Background"]),
        "phases": phase_rows(project, histogram),
    }


def run(input_gpx: Path, output_dir: Path, effects: list[str]) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    gpx_path = output_dir / "refined.gpx"
    shutil.copy2(input_gpx, gpx_path)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(gpx_path))
    project.set_Controls("cycles", 8)
    stages = [snapshot(project, "input")]
    for effect in effects:
        apply_effect(project, effect)
        project.do_refinements([{}], makeBack=False)
        stages.append(snapshot(project, effect))
    project.do_refinements([{}], makeBack=False)
    stages.append(snapshot(project, "settle"))
    project.save(str(gpx_path))

    histogram = project.histograms()[0]
    data = histogram.data["data"][1]
    fit_path = output_dir / "fit.csv"
    np.savetxt(
        fit_path,
        np.column_stack((data[0], data[1], data[3], data[1] - data[3], data[4])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
        fmt="%.8f",
    )
    final = stages[-1]
    bkg = np.asarray(data[4], float)
    inst = histogram.data["Instrument Parameters"][0]
    theta = np.deg2rad(np.asarray(data[0], float) / 2)
    sigma_inst = inst["U"][1] * np.tan(theta) ** 2 + inst["V"][1] * np.tan(theta) + inst["W"][1]
    gamma_inst = inst["X"][1] / np.cos(theta) + inst["Y"][1] * np.tan(theta) + inst["Z"][1]
    audit = {
        "input_gpx": str(input_gpx.relative_to(ROOT)),
        "output_gpx": str(gpx_path.relative_to(ROOT)),
        "effects": effects,
        "stages": stages,
        "final": final,
        "screens": {
            "background_minimum": float(bkg.min()),
            "instrument_sigma_minimum": float(sigma_inst.min()),
            "instrument_gamma_minimum": float(gamma_inst.min()),
            "profile_widths_positive_on_grid": bool(
                sigma_inst.min() >= 0 and gamma_inst.min() >= 0
            ),
        },
    }
    (output_dir / "audit.json").write_text(json.dumps(audit, indent=2, allow_nan=False) + "\n")
    print(
        json.dumps(
            {
                "effects": effects,
                "rwp_percent": final["rwp_percent"],
                "fractions": {p["id"]: p["weight_fraction"] for p in final["phases"]},
                "screens": audit["screens"],
            },
            indent=2,
        )
    )
    return audit


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--effect", action="append", default=[])
    args = parser.parse_args()
    run(args.input.resolve(), args.out.resolve(), args.effect)


if __name__ == "__main__":
    main()
