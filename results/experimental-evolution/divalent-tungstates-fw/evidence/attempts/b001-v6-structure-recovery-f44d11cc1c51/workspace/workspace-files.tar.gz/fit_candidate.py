"""Build and run a moderate-flexibility GSAS-II candidate refinement."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2


def metrics(project: G2.G2Project, histogram: G2.G2PwdrData, label: str) -> dict:
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(max(0.0, mass_scale))
        phases.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "mass_scale": mass_scale,
                "cell": phase.get_cell(),
                "size": list(hap["Size"][1]),
                "mustrain": list(hap["Mustrain"][1]),
            }
        )
    total = sum(masses)
    for phase, value in zip(phases, masses):
        phase["weight_fraction"] = value / total if total else 0.0
    controls = project.data.get("Covariance", {}).get("data", {})
    return {
        "stage": label,
        "Rwp_percent": histogram.get_wR(),
        "GOF": controls.get("Rvals", {}).get("GOF"),
        "Nvars": len(controls.get("varyList", [])),
        "instrument": {
            key: value[1]
            for key, value in histogram.InstrumentParameters.items()
            if isinstance(value, list) and len(value) > 1
        },
        "sample": {
            key: value[0] if isinstance(value, list) else value
            for key, value in histogram.SampleParameters.items()
            if key in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"}
        },
        "background": list(histogram.Background[0]),
        "phases": phases,
    }


def refine(project, histogram, label, history):
    project.refine(makeBack=False)
    history.append(metrics(project, histogram, label))
    item = history[-1]
    print(
        label,
        f"Rwp={item['Rwp_percent']:.4f}",
        "fractions=" + ",".join(
            f"{p['name']}:{p['weight_fraction']:.5f}" for p in item["phases"]
        ),
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--third", help="optional third-phase CIF")
    parser.add_argument("--wo3", default="candidates/wo3_2311041.cif")
    parser.add_argument("--out", required=True)
    parser.add_argument("--angular", choices=("zero", "shift"), default="zero")
    parser.add_argument("--profile", action="store_true", help="refine moderate common profile")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(out))

    phase_specs = [
        ("CaWO4", "candidates/cawo4_7219229.cif"),
        ("WO3", args.wo3),
    ]
    if args.third:
        phase_specs.append((Path(args.third).stem, args.third))
    phases = [
        project.add_phase(str(Path(cif).resolve()), phasename=name, fmthint="CIF")
        for name, cif in phase_specs
    ]
    histogram = project.add_powder_histogram(
        str(Path("inputs/pattern.csv").resolve()),
        str(Path("instrument.instprm").resolve()),
        phases="all",
        fmthint="comma",
    )
    histogram.SampleParameters["Type"] = "Bragg-Brentano"
    histogram.SampleParameters["Gonio. radius"] = 240.0
    histogram.SampleParameters["Scale"] = [1.0, False]

    # Initialize a six-term positive, slowly varying background from a local
    # low percentile. It is then refined against the full Poisson-weighted scan.
    x = np.asarray(histogram.getdata("X"), float)
    y = np.asarray(histogram.getdata("Yobs"), float)
    baseline = percentile_filter(y, percentile=15, size=501, mode="nearest")
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    coeffs = np.polynomial.chebyshev.chebfit(t, baseline, 5).tolist()
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": coeffs,
                "refine": True,
            }
        }
    )
    # Rough positive starts; only their ratios matter before scale refinement.
    starts = [1.0, 0.12, 0.08]
    for phase, start in zip(phases, starts):
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"] = [start, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 300.0

    project.update_ids()
    project.set_Controls("cycles", 12)
    for phase in phases:
        prefix = f"{phase.id}:{histogram.id}:"
        project.set_Controls("parmMin", 1e-8, variable=prefix + "Scale")
        project.set_Controls("parmMin", 0.02, variable=prefix + "Size;i")
        project.set_Controls("parmMax", 100.0, variable=prefix + "Size;i")
        project.set_Controls("parmMin", 0.0, variable=prefix + "Mustrain;i")
        project.set_Controls("parmMax", 10000.0, variable=prefix + "Mustrain;i")
    project.set_Controls("parmMin", 0.0, variable=f":{histogram.id}:W")
    project.set_Controls("parmMax", 200.0, variable=f":{histogram.id}:W")
    project.set_Controls("parmMin", 0.0, variable=f":{histogram.id}:X")
    project.set_Controls("parmMax", 100.0, variable=f":{histogram.id}:X")
    project.set_Controls("parmMin", -0.5, variable=f":{histogram.id}:Zero")
    project.set_Controls("parmMax", 0.5, variable=f":{histogram.id}:Zero")
    project.set_Controls("parmMin", -1000.0, variable=f":{histogram.id}:Shift")
    project.set_Controls("parmMax", 1000.0, variable=f":{histogram.id}:Shift")
    history = []
    refine(project, histogram, "background_scales", history)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    if args.angular == "zero":
        histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    else:
        histogram.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, histogram, "cells_angular", history)

    if args.profile:
        histogram.set_refinements({"Instrument Parameters": ["W", "X"]})
        refine(project, histogram, "common_profile", history)
        # One simple broadening term per phase, released one category at a time.
        for phase in phases:
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}
            )
        refine(project, histogram, "phase_size", history)
        for phase in phases:
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )
        refine(project, histogram, "phase_mustrain", history)

    project.save(str(out))
    out.with_suffix(".json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
