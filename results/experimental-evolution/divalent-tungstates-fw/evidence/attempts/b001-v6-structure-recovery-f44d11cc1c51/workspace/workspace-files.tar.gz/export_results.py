"""Export final CIFs, profile and machine-readable phase results."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


PROJECT = Path("final.gpx").resolve()
PHASE_FILES = [
    ("CaWO4", "CaWO4 (scheelite)", "phase_CaWO4.cif"),
    ("WO3", "WO3 (monoclinic)", "phase_WO3.cif"),
    ("Ca3WO6", "Ca3WO6 (ordered perovskite-related)", "phase_Ca3WO6.cif"),
]


def main() -> None:
    project = G2.G2Project(gpxfile=str(PROJECT))
    histogram = project.histogram(0)
    phases = project.phases()
    if len(phases) != len(PHASE_FILES):
        raise RuntimeError("Expected exactly three final crystalline phases")

    masses = []
    rows = []
    for phase, (formula, display_name, filename) in zip(phases, PHASE_FILES):
        phase.export_CIF(str(Path(filename).resolve()), quickmode=True)
        hap = phase.data["Histograms"][histogram.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        if mass_scale <= 0:
            raise RuntimeError(f"Nonpositive phase contribution for {phase.name}")
        masses.append(mass_scale)
        rows.append(
            {
                "name": display_name,
                "formula": formula,
                "project_phase": phase.name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif": filename,
                "weight_fraction": None,
                "weight_percent": None,
            }
        )
    total = sum(masses)
    for row, mass in zip(rows, masses):
        fraction = mass / total
        row["weight_fraction"] = fraction
        row["weight_percent"] = 100.0 * fraction

    x = np.asarray(histogram.getdata("X"), float)
    observed = np.asarray(histogram.getdata("Yobs"), float)
    calculated = np.asarray(histogram.getdata("Ycalc"), float)
    difference = observed - calculated
    weights = np.asarray(histogram.getdata("Yweight"), float)
    with Path("fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta_deg", "observed_counts", "calculated_counts", "difference_counts"]
        )
        writer.writerows(zip(x, observed, calculated, difference))

    n_parameters = 26
    chi_squared = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = 100.0 * np.sqrt(chi_squared / denominator)
    rp = 100.0 * float(np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
    degrees_of_freedom = int(len(x) - n_parameters)
    reduced_chi_squared = chi_squared / degrees_of_freedom
    rexp = 100.0 * np.sqrt(degrees_of_freedom / denominator)
    result = {
        "refinement_histogram": histogram.name,
        "project": "final.gpx",
        "phases": rows,
        "fit_statistics": {
            "n_points": int(len(x)),
            "n_refined_parameters": n_parameters,
            "degrees_of_freedom": degrees_of_freedom,
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "Rexp_percent": rexp,
            "chi_squared": chi_squared,
            "reduced_chi_squared": reduced_chi_squared,
            "goodness_of_fit": float(np.sqrt(reduced_chi_squared)),
        },
        "fraction_basis": "Normalized over the three modeled crystalline phases only",
        "notes": [
            "No amorphous fraction or internal-standard absolute fraction was determined.",
            "Ca3WO6 uses a chemistry-mapped ordered-perovskite parent; its exact cation/oxygen coordinates are less secure than its phase assignment and cell.",
        ],
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
