"""Bounded coordinate recovery using one-cycle GSAS-II damped steps."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_coordinates import (
    add_parent_geometry_network,
    initialize_bond_restraints,
    retarget_restraints_to_current,
    snapshot,
)


def clear_frozen(project):
    project.data["Controls"]["data"]["parmFrozen"] = {}


def calculate(project, histogram, stage, history):
    saved_flags = {
        phase.name: [atom.refinement_flags for atom in phase.atoms()]
        for phase in project.phases()
    }
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    item = snapshot(project, histogram, stage)
    history.append(item)
    print(
        stage,
        f"Rwp={item['Rwp_percent']:.5f}",
        "fractions=" + ",".join(
            f"{p['name']}:{p['weight_fraction']:.5f}" for p in item["phases"]
        ),
    )
    for phase in project.phases():
        for atom, flags in zip(phase.atoms(), saved_flags[phase.name]):
            atom.refinement_flags = flags
    project.save()


def damped_steps(project, anchors, steps, step_limit=0.001, total_limit=0.006):
    """Apply capped one-cycle coordinate shifts around the literature parent."""
    for _ in range(steps):
        clear_frozen(project)
        old = {
            phase.name: [np.asarray(atom.coordinates, float) for atom in phase.atoms()]
            for phase in project.phases()
        }
        project.set_Controls("cycles", 1)
        project.refine(makeBack=False)
        for phase in project.phases():
            for index, atom in enumerate(phase.atoms()):
                if "X" not in atom.refinement_flags:
                    continue
                new = np.asarray(atom.coordinates, float)
                delta = new - old[phase.name][index]
                delta -= np.rint(delta)
                delta = np.clip(delta, -step_limit, step_limit)
                proposed = old[phase.name][index] + delta
                total = proposed - anchors[phase.name][index]
                total -= np.rint(total)
                total = np.clip(total, -total_limit, total_limit)
                atom.coordinates = (anchors[phase.name][index] + total).tolist()
        project.save()


def set_flags(phase, elements):
    for atom in phase.atoms():
        if atom.element in elements:
            atom.refinement_flags = "X"


def add_restraint_model(project, phase):
    initialize_bond_restraints(project, phase)
    w_atoms = [atom for atom in phase.atoms() if atom.element == "W"]
    ca_atoms = [atom for atom in phase.atoms() if atom.element == "Ca"]
    o_atoms = [atom for atom in phase.atoms() if atom.element == "O"]
    if w_atoms and o_atoms:
        phase.addDistRestraint(w_atoms, o_atoms, 1.90, factor=1.35, ESD=0.05)
    if ca_atoms and o_atoms:
        phase.addDistRestraint(ca_atoms, o_atoms, 2.45, factor=1.32, ESD=0.08)
    if o_atoms:
        phase.addDistRestraint(o_atoms, o_atoms, 2.80, factor=1.18, ESD=0.08)
    retarget_restraints_to_current(phase, 0.06)
    add_parent_geometry_network(phase, esd=0.12)
    phase.setDistRestraintWeight(100.0)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--perturb", type=float, default=0.0)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=args.input, newgpx=str(output))
    histogram = project.histogram(0)
    phases = project.phases()
    if len(phases) != 3:
        raise ValueError("Damped recovery expects a closed three-phase inventory")

    clear_frozen(project)
    histogram.SampleParameters["Scale"] = [1.0, False]
    histogram.Background[0][1] = True
    for key, value in histogram.InstrumentParameters.items():
        if isinstance(value, list) and len(value) > 2:
            value[2] = key == "Zero"
    for phase in phases:
        phase.set_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
            atom.uiso = 0.01
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Mustrain"][1][0] = 0.0

    history = []
    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    calculate(project, histogram, "moderate_baseline", history)

    phases = project.phases()
    for phase in phases:
        add_restraint_model(project, phase)
    anchors = {
        phase.name: [np.asarray(atom.coordinates, float) for atom in phase.atoms()]
        for phase in phases
    }
    if args.perturb:
        rng = np.random.default_rng(args.seed)
        for phase in phases:
            for atom in phase.atoms():
                if atom.element == "O":
                    displacement = np.clip(
                        rng.normal(0.0, args.perturb, 3), -0.004, 0.004
                    )
                    atom.coordinates = (
                        np.asarray(atom.coordinates) + displacement
                    ).tolist()
        project.save()

    cawo4, wo3, third = project.phases()
    set_flags(cawo4, {"O"})
    damped_steps(project, anchors, 8)
    calculate(project, histogram, "cawo4_ligand", history)

    set_flags(wo3, {"W", "O"})
    damped_steps(project, anchors, 10)
    calculate(project, histogram, "wo3_connected", history)

    set_flags(third, {"O"})
    damped_steps(project, anchors, 10)
    calculate(project, histogram, "ca3wo6_ligand", history)
    set_flags(third, {"Ca"})
    damped_steps(project, anchors, 8)
    calculate(project, histogram, "ca3wo6_connected", history)

    damped_steps(project, anchors, 10)
    calculate(project, histogram, "coordinate_restart", history)

    # Profile re-equilibration with all coordinates held.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    histogram = project.histogram(0)
    histogram.set_refinements({"Instrument Parameters": ["W", "X"]})
    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    calculate(project, histogram, "profile_recheck", history)

    histogram = project.histogram(0)
    histogram.InstrumentParameters["W"][2] = False
    histogram.InstrumentParameters["X"][2] = False
    cawo4, wo3, third = project.phases()
    set_flags(cawo4, {"O"})
    set_flags(wo3, {"W", "O"})
    set_flags(third, {"Ca", "O"})
    damped_steps(project, anchors, 12)
    calculate(project, histogram, "coordinate_retest", history)

    # Leave the submitted project with no active coordinate flags and freshly
    # regenerated calculated intensities for its saved coordinates.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    project.save(str(output))
    output.with_suffix(".json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
