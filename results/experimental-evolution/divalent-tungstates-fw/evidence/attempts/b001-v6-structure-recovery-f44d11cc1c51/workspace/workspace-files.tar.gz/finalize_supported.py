"""Finalize the supported low-complexity model with separated trust blocks."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_coordinates import snapshot
from stable_refine import (
    calculate,
    freeze_all,
    parameter_state,
    physically_valid,
    restore_state,
    trust_block,
)


def custom_block(project, history, stage, setup, valid, steps=10, shift=0.15):
    freeze_all(project)
    setup(project)
    current = calculate(project)
    accepted = 0
    failed = 0
    for attempt in range(1, steps + 1):
        before = parameter_state(project)
        project.data["Controls"]["data"]["parmFrozen"] = {}
        project.data["Controls"]["data"]["shift factor"] = shift
        project.set_Controls("cycles", 1)
        project.refine(makeBack=False)
        trial = calculate(project)
        if physically_valid(project) and valid(project) and trial < current - 1e-6:
            improvement = current - trial
            current = trial
            accepted += 1
            failed = 0
            shift = min(0.5, shift * 1.25)
            print(
                f"{stage} step={attempt} accepted Rwp={current:.6f}% "
                f"delta={improvement:.6f}"
            )
        else:
            restore_state(project, before)
            project.data["Controls"]["data"]["parmFrozen"] = {}
            current = calculate(project)
            shift *= 0.5
            failed += 1
            print(f"{stage} step={attempt} rejected kept={current:.6f}%")
            if shift < 0.005 or failed >= 2:
                break
        freeze_all(project)
        setup(project)
    item = snapshot(project, project.histogram(0), stage)
    item["accepted_steps"] = accepted
    history.append(item)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument(
        "--fix-polarization",
        action="store_true",
        help="hold the standard unpolarized Bragg-Brentano value of 0.5",
    )
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    project = G2.G2Project(gpxfile=args.input, newgpx=str(output))
    histogram = project.histogram(0)
    if args.fix_polarization:
        histogram.InstrumentParameters["Polariz."][1] = 0.5
        histogram.InstrumentParameters["Polariz."][2] = False
    freeze_all(project)
    project.data["Controls"]["data"]["parmFrozen"] = {}
    history = [snapshot(project, histogram, "supported_start")]
    print(f"supported_start Rwp={calculate(project):.6f}%")

    standard_blocks = [
        (
            "final_linear",
            5,
            0.5,
            {"background": True, "scales": True},
        ),
        (
            "final_cells_shift",
            8,
            0.1,
            {
                "background": True,
                "scales": True,
                "cells": True,
                "shift_correction": True,
            },
        ),
        (
            "final_common_profile",
            8,
            0.05,
            {
                "background": True,
                "scales": True,
                "cells": True,
                "shift_correction": True,
                "common_profile": True,
            },
        ),
    ]
    for stage, steps, shift, activation in standard_blocks:
        trust_block(
            project,
            stage,
            history,
            steps=steps,
            shift=shift,
            activation=activation,
        )

    for phase_index, phase in enumerate(project.phases()):
        trust_block(
            project,
            f"final_size_{phase.name}",
            history,
            steps=5,
            shift=0.05,
            activation={
                "background": True,
                "scales": True,
                "size_phase": phase_index,
            },
        )

    def setup_polarization(proj):
        hist = proj.histogram(0)
        hist.InstrumentParameters["Polariz."][2] = True
        proj.set_Controls("parmMin", 0.0, variable=f":{hist.id}:Polariz.")
        proj.set_Controls("parmMax", 1.0, variable=f":{hist.id}:Polariz.")

    def valid_polarization(proj):
        value = proj.histogram(0).InstrumentParameters["Polariz."][1]
        return 0.0 < value < 1.0

    def setup_texture(proj):
        hist = proj.histogram(0)
        hap = proj.phases()[0].data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = [1, 1, 1]
        proj.update_ids()
        variable = f"{proj.phases()[0].id}:{hist.id}:MD"
        proj.set_Controls("parmMin", 0.5, variable=variable)
        proj.set_Controls("parmMax", 2.0, variable=variable)

    def valid_texture(proj):
        hist = proj.histogram(0)
        value = proj.phases()[0].data["Histograms"][hist.name]["Pref.Ori."][1]
        return 0.5 < value < 2.0

    # Two separated alternations demonstrate that polarization and texture do
    # not rely on being released in one correlated Newton step.
    for round_number in range(1, 3):
        if not args.fix_polarization:
            custom_block(
                project,
                history,
                f"polarization_r{round_number}",
                setup_polarization,
                valid_polarization,
            )
            trust_block(
                project,
                f"linear_after_polarization_r{round_number}",
                history,
                steps=4,
                shift=0.4,
                activation={"background": True, "scales": True},
            )
        custom_block(
            project,
            history,
            f"texture_111_r{round_number}",
            setup_texture,
            valid_texture,
        )
        trust_block(
            project,
            f"linear_after_texture_r{round_number}",
            history,
            steps=4,
            shift=0.4,
            activation={"background": True, "scales": True},
        )

    freeze_all(project)
    final = calculate(project)
    project.save(str(output))
    history.append(snapshot(project, project.histogram(0), "final_fixed_replay"))
    output.with_suffix(".json").write_text(json.dumps(history, indent=2) + "\n")
    print(f"final fixed replay Rwp={final:.6f}%")


if __name__ == "__main__":
    main()
