"""Final phase-deletion tests with linear scale/background rebalancing."""

from __future__ import annotations

import numpy as np
from GSASII import GSASIIscriptable as G2

from stable_refine import calculate, freeze_all, parameter_state, restore_state


def valid(project, deleted):
    histogram = project.histogram(0)
    x = np.asarray(histogram.getdata("X"), float)
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    background = np.polynomial.chebyshev.chebval(t, histogram.Background[0][3:])
    if np.min(background) <= 0:
        return False
    for index, phase in enumerate(project.phases()):
        scale = phase.data["Histograms"][histogram.name]["Scale"][0]
        if index != deleted and scale <= 0:
            return False
    return True


def main():
    for deleted in range(3):
        output = f".tmp/deletion_{deleted}.gpx"
        project = G2.G2Project(gpxfile="final.gpx", newgpx=output)
        histogram = project.histogram(0)
        name = project.phases()[deleted].name
        freeze_all(project)
        project.phases()[deleted].data["Histograms"][histogram.name]["Scale"] = [
            0.0,
            False,
        ]
        initial = calculate(project)
        current = initial
        for _ in range(4):
            freeze_all(project)
            histogram.Background[0][1] = True
            for index, phase in enumerate(project.phases()):
                if index != deleted:
                    phase.data["Histograms"][histogram.name]["Scale"][1] = True
            before = parameter_state(project)
            project.data["Controls"]["data"]["shift factor"] = 0.5
            project.set_Controls("cycles", 1)
            project.refine(makeBack=False)
            freeze_all(project)
            trial = calculate(project)
            if valid(project, deleted) and trial < current:
                current = trial
            else:
                restore_state(project, before)
                current = calculate(project)
                break
        print(name, f"deleted_raw={initial:.6f}%", f"rebalanced={current:.6f}%")


if __name__ == "__main__":
    main()
