"""Screen low-index March-Dollase axes with replay-consistent refinements."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_coordinates import snapshot
from stable_refine import calculate, freeze_all, parameter_state, restore_state


AXES = ([0, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1], [1, 1, 2])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output_dir")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    summary = []
    for axis in AXES:
        tag = "".join(str(value) for value in axis)
        output = output_dir / f"texture_{tag}.gpx"
        project = G2.G2Project(gpxfile=args.input, newgpx=str(output))
        freeze_all(project)
        histogram = project.histogram(0)
        for phase in project.phases():
            phase.data["Histograms"][histogram.name]["Pref.Ori."][2] = False
        hap = project.phases()[0].data["Histograms"][histogram.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        project.update_ids()
        variable = f"{project.phases()[0].id}:{histogram.id}:MD"
        project.set_Controls("parmMin", 0.2, variable=variable)
        project.set_Controls("parmMax", 5.0, variable=variable)
        current = calculate(project)
        shift = 0.2
        accepted = 0
        for _attempt in range(8):
            before = parameter_state(project)
            project.data["Controls"]["data"]["parmFrozen"] = {}
            project.data["Controls"]["data"]["shift factor"] = shift
            project.set_Controls("cycles", 1)
            project.refine(makeBack=False)
            trial = calculate(project)
            ratio = hap["Pref.Ori."][1]
            if 0.2 <= ratio <= 5.0 and trial < current - 1.0e-6:
                current = trial
                accepted += 1
                shift = min(0.5, shift * 1.25)
            else:
                restore_state(project, before)
                current = calculate(project)
                shift *= 0.5
                if shift < 0.01:
                    break
            hap = project.phases()[0].data["Histograms"][histogram.name]
        freeze_all(project)
        final = calculate(project)
        project.save(str(output))
        item = snapshot(project, project.histogram(0), f"MD_{tag}")
        item["axis"] = list(axis)
        item["MD_ratio"] = project.phases()[0].data["Histograms"][
            project.histogram(0).name
        ]["Pref.Ori."][1]
        item["accepted_steps"] = accepted
        summary.append(item)
        print(tag, f"Rwp={final:.6f}%", f"MD={item['MD_ratio']:.6f}")
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
