"""Rebuild a saved screening stage and force a fresh GSAS-II calculation.

The screening JSON records the parameter vector after each refinement stage,
whereas a bound-terminated GSAS-II run can leave an older calculated profile
cached in the project.  This helper reconstructs a selected recorded stage and
then calculates it with zero refinement cycles so that parameters and profile
are guaranteed to agree.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx")
    parser.add_argument("history_json")
    parser.add_argument("stage")
    parser.add_argument("output")
    args = parser.parse_args()

    output = Path(args.output).resolve()
    history = json.loads(Path(args.history_json).read_text())
    state = next(item for item in history if item["stage"] == args.stage)
    project = G2.G2Project(gpxfile=args.gpx, newgpx=str(output))
    histogram = project.histogram(0)

    # Restore the complete recorded nonstructural parameter vector.
    histogram.Background[0] = list(state["background"])
    histogram.Background[0][1] = False
    for key, value in state["instrument"].items():
        target = histogram.InstrumentParameters.get(key)
        if isinstance(target, list) and len(target) > 1:
            target[1] = value
            if len(target) > 2:
                target[2] = False
    for key, value in state.get("sample", {}).items():
        target = histogram.SampleParameters.get(key)
        if isinstance(target, list):
            target[0] = value
            if len(target) > 1:
                target[1] = False

    phase_states = {item["name"]: item for item in state["phases"]}
    for phase in project.phases():
        item = phase_states[phase.name]
        cell = item["cell"]
        phase.data["General"]["Cell"] = [
            False,
            cell["length_a"],
            cell["length_b"],
            cell["length_c"],
            cell["angle_alpha"],
            cell["angle_beta"],
            cell["angle_gamma"],
            cell["volume"],
        ]
        for atom in phase.atoms():
            atom.refinement_flags = " "
            atom.uiso = 0.01
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"] = [item["scale"], False]
        hap["Size"][1] = list(item["size"])
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][1] = [0.0, 1000.0, 1.0]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]

    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    project.save(str(output))
    print(f"{args.stage} replay-consistent Rwp={histogram.get_wR():.6f}%")


if __name__ == "__main__":
    main()
