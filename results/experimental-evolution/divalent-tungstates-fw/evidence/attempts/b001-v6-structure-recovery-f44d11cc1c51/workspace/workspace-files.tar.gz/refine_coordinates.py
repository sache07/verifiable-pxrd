"""Cumulative, restrained coordinate recovery from a candidate GSAS-II fit."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIImath as G2mth


def initialize_bond_restraints(project, phase):
    project.data["Restraints"]["data"][phase.name] = {
        "Bond": {"wtFactor": 1.0, "Range": 1.1, "Bonds": [], "Use": True}
    }


def retarget_restraints_to_current(phase, esd, start=0):
    """Preserve each parent's individual bond geometry with soft restraints."""
    bond_data = phase.proj.data["Restraints"]["data"][phase.name]["Bond"]
    general = phase.data["General"]
    cx, _ct, _cs, cia = general["AtomPtrs"]
    atoms = phase.data["Atoms"]
    lookup = G2mth.FillAtomLookUp(atoms, cia + 8)
    amat, _bmat = G2lat.cell2AB(general["Cell"][1:7])
    for restraint in bond_data["Bonds"][start:]:
        ids, operations, _target, _old_esd = restraint
        xyz = np.asarray([atoms[lookup[atom_id]][cx : cx + 3] for atom_id in ids])
        xyz = G2mth.getSyXYZ(xyz, operations, general["SGData"])
        restraint[2] = float(G2mth.getRestDist(xyz, amat))
        restraint[3] = float(esd)


def add_parent_geometry_network(phase, esd=0.10):
    """Restrain all parent contacts from 2.0--4.5 A to prevent site crossing."""
    bond_data = phase.proj.data["Restraints"]["data"][phase.name]["Bond"]
    start = len(bond_data["Bonds"])
    atoms = phase.atoms()
    phase.addDistRestraint(atoms, atoms, 3.0, factor=1.5, ESD=esd)
    retarget_restraints_to_current(phase, esd, start=start)


def atom_snapshot(phase):
    return [
        {
            "label": atom.label,
            "element": atom.element,
            "xyz": [float(v) for v in atom.coordinates],
            "uiso": float(atom.uiso),
            "flags": atom.refinement_flags,
        }
        for atom in phase.atoms()
    ]


def snapshot(project, histogram, stage):
    mass_scales = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        mass_scales.append(max(0.0, mass_scale))
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(hap["Scale"][0]),
                "mass_scale": mass_scale,
                "size_um": float(hap["Size"][1][0]),
                "mustrain_ppm": float(hap["Mustrain"][1][0]),
                "atoms": atom_snapshot(phase),
            }
        )
    total = sum(mass_scales)
    for phase, mass_scale in zip(phases, mass_scales):
        phase["weight_fraction"] = mass_scale / total if total else 0.0
    covariance = project.data.get("Covariance", {}).get("data", {})
    return {
        "stage": stage,
        "Rwp_percent": histogram.get_wR(),
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "Nvars": len(covariance.get("varyList", [])),
        "max_shift_esd": covariance.get("Rvals", {}).get("Max shft/sig"),
        "instrument": {
            key: value[1]
            for key, value in histogram.InstrumentParameters.items()
            if isinstance(value, list) and len(value) > 1
        },
        "background": list(histogram.Background[0]),
        "phases": phases,
    }


def run_refinement(project, histogram, stage, history, cycles=12):
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    result = snapshot(project, histogram, stage)
    history.append(result)
    print(
        stage,
        f"Rwp={result['Rwp_percent']:.5f}",
        "fractions=" + ",".join(
            f"{p['name']}:{p['weight_fraction']:.5f}" for p in result["phases"]
        ),
    )


def set_atom_flags(phase, predicate, flags="X"):
    labels = []
    for atom in phase.atoms():
        if predicate(atom):
            atom.refinement_flags = flags
            labels.append(atom.label)
    return labels


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--perturb", type=float, default=0.0)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=args.input, newgpx=str(output))
    histogram = project.histogram(0)
    phases = project.phases()
    if len(phases) != 3:
        raise ValueError("Coordinate recovery expects the closed three-phase inventory")

    # Remove bound freezes from the source-screening branch and return to a
    # low-flexibility, physically positive profile while coordinates move.
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.data["Controls"]["data"]["shift factor"] = 0.25
    histogram.Background[0][1] = True
    for key, value in histogram.InstrumentParameters.items():
        if isinstance(value, list) and len(value) > 2:
            value[2] = key == "Zero"
    histogram.SampleParameters["Scale"] = [1.0, False]
    for phase in phases:
        phase.set_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
            atom.uiso = 0.01
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        # Bound-screening branches that tried to drive strain negative are
        # normalized back to zero and held during structure recovery.
        hap["Mustrain"][1][0] = 0.0

    if args.perturb:
        rng = np.random.default_rng(args.seed)
        # Ligand-only perturbations preserve cation topology and special sites.
        for phase in phases:
            for atom in phase.atoms():
                if atom.element == "O":
                    atom.coordinates = (
                        np.asarray(atom.coordinates)
                        + rng.normal(0.0, args.perturb, 3)
                    ).tolist()

    history = []
    run_refinement(project, histogram, "moderate_baseline", history)

    # Scheelite: the oxygen orbit is the complete independent ligand framework.
    cawo4 = phases[0]
    initialize_bond_restraints(project, cawo4)
    cawo4.addDistRestraint(
        [a for a in cawo4.atoms() if a.element == "W"],
        [a for a in cawo4.atoms() if a.element == "O"],
        1.78,
        factor=1.20,
        ESD=0.04,
    )
    cawo4.addDistRestraint(
        [a for a in cawo4.atoms() if a.element == "Ca"],
        [a for a in cawo4.atoms() if a.element == "O"],
        2.47,
        factor=1.12,
        ESD=0.04,
    )
    cawo4.addDistRestraint(
        [a for a in cawo4.atoms() if a.element == "O"],
        [a for a in cawo4.atoms() if a.element == "O"],
        2.90,
        factor=1.12,
        ESD=0.06,
    )
    retarget_restraints_to_current(cawo4, 0.025)
    add_parent_geometry_network(cawo4, esd=0.10)
    cawo4.setDistRestraintWeight(2000.0)
    set_atom_flags(cawo4, lambda atom: atom.element == "O")
    project.data["Controls"]["data"]["shift factor"] = 0.02
    run_refinement(project, histogram, "cawo4_ligand", history)

    # Monoclinic WO3: release each W center with the full connected O network.
    wo3 = phases[1]
    initialize_bond_restraints(project, wo3)
    wo3.addDistRestraint(
        [a for a in wo3.atoms() if a.element == "W"],
        [a for a in wo3.atoms() if a.element == "O"],
        1.90,
        factor=1.32,
        ESD=0.12,
    )
    wo3.addDistRestraint(
        [a for a in wo3.atoms() if a.element == "O"],
        [a for a in wo3.atoms() if a.element == "O"],
        2.70,
        factor=1.14,
        ESD=0.08,
    )
    retarget_restraints_to_current(wo3, 0.04)
    add_parent_geometry_network(wo3, esd=0.10)
    wo3.setDistRestraintWeight(1000.0)
    set_atom_flags(wo3, lambda atom: atom.element in {"W", "O"})
    project.data["Controls"]["data"]["shift factor"] = 0.01
    run_refinement(project, histogram, "wo3_connected", history, cycles=16)

    # Ca3WO6: compare mapped parents only after releasing the complete W-O
    # octahedral network; then release the coupled Ca sublattice as a final block.
    third = phases[2]
    initialize_bond_restraints(project, third)
    third.addDistRestraint(
        [a for a in third.atoms() if a.element == "W"],
        [a for a in third.atoms() if a.element == "O"],
        1.95,
        factor=1.28,
        ESD=0.08,
    )
    third.addDistRestraint(
        [a for a in third.atoms() if a.element == "O"],
        [a for a in third.atoms() if a.element == "O"],
        2.88,
        factor=1.14,
        ESD=0.08,
    )
    third.addDistRestraint(
        [a for a in third.atoms() if a.element == "Ca"],
        [a for a in third.atoms() if a.element == "O"],
        2.45,
        factor=1.30,
        ESD=0.15,
    )
    retarget_restraints_to_current(third, 0.04)
    add_parent_geometry_network(third, esd=0.10)
    third.setDistRestraintWeight(1000.0)
    set_atom_flags(third, lambda atom: atom.element == "O")
    project.data["Controls"]["data"]["shift factor"] = 0.01
    run_refinement(project, histogram, "ca3wo6_ligand", history, cycles=16)
    set_atom_flags(third, lambda atom: atom.element == "Ca")
    project.data["Controls"]["data"]["shift factor"] = 0.01
    run_refinement(project, histogram, "ca3wo6_connected", history, cycles=16)

    # Cumulative restarts are required for the coupled coordinate/profile
    # blocks; a single nominally successful least-squares pass is not enough.
    project.data["Controls"]["data"]["shift factor"] = 0.01
    for index in range(1, 4):
        run_refinement(
            project,
            histogram,
            f"coordinate_restart_{index}",
            history,
            cycles=16,
        )

    # Re-equilibrate the common width with coordinates fixed, avoiding a
    # large mixed coordinate/profile Newton step.
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = " "
    histogram.set_refinements({"Instrument Parameters": ["W", "X"]})
    project.data["Controls"]["data"]["shift factor"] = 0.30
    run_refinement(project, histogram, "profile_recheck", history)

    # Retest the same connected coordinate blocks under the stabilized profile.
    histogram.InstrumentParameters["W"][2] = False
    histogram.InstrumentParameters["X"][2] = False
    set_atom_flags(cawo4, lambda atom: atom.element == "O")
    set_atom_flags(wo3, lambda atom: atom.element in {"W", "O"})
    set_atom_flags(third, lambda atom: atom.element in {"Ca", "O"})
    project.data["Controls"]["data"]["shift factor"] = 0.01
    for index in range(1, 4):
        run_refinement(
            project,
            histogram,
            f"coordinate_retest_{index}",
            history,
            cycles=16,
        )

    project.save(str(output))
    output.with_suffix(".json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
