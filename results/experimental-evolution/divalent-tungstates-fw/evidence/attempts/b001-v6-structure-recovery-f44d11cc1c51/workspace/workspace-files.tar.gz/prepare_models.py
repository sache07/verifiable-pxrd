"""Prepare composition-mapped candidate CIFs and print physical screens."""

from pathlib import Path
import warnings

import numpy as np
from pymatgen.core import Element, Structure
from pymatgen.io.cif import CifWriter


LIBRARY = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/"
    "resources/b001-c05/cif"
)
OUT = Path("candidates")

# Scale factors are only convergence starts estimated from observed line positions.
# GSAS-II subsequently refines all symmetry-independent cell terms.
MODELS = {
    "cawo4_7219229": ("7219229", 1.0, False),
    "wo3_2311041": ("2311041", 1.0, False),
    "wo3_1528915": ("1528915", 1.0, False),
    "ca3wo6_4003582": ("4003582", 1.045, True),
    "ca3wo6_1562382": ("1562382", 1.045, True),
    "ca3wo6_1562385": ("1562385", 1.043, True),
    "ca3wo6_7222332": ("7222332", 1.040, True),
    "ca3wo6_7222333": ("7222333", 1.028, True),
    "ca3wo6_2013468": ("2013468", 1.025, True),
    "ca3wo6_1526329": ("1526329", 1.000, True),
    "ca3wo6_1001661": ("1001661", 0.983, True),
    "ca3w2o9_1533878": ("1533878", 0.902, True),
    "ca3w2o9_2311977": ("2311977", 0.980, True),
}


def source_path(cod_id: str) -> Path:
    paths = list(LIBRARY.rglob(f"{cod_id}.cif"))
    if len(paths) != 1:
        raise FileNotFoundError(f"Expected one CIF for COD {cod_id}, found {paths}")
    return paths[0]


def map_to_ca(structure: Structure) -> Structure:
    mapped = structure.copy()
    substitutions = {
        el: Element("Ca")
        for el in mapped.composition.elements
        if el.symbol not in {"O", "W"}
    }
    mapped.replace_species(substitutions)
    return mapped


def distance_screen(structure: Structure) -> dict[str, float]:
    values: dict[str, list[float]] = {"Ca-O": [], "W-O": [], "O-O": []}
    symbols = [site.species.elements[0].symbol for site in structure]
    for i, si in enumerate(structure):
        for j in range(i + 1, len(structure)):
            sj = structure[j]
            pair = "-".join(sorted((symbols[i], symbols[j])))
            if pair == "Ca-O":
                key = "Ca-O"
            elif pair == "O-W":
                key = "W-O"
            elif pair == "O-O":
                key = "O-O"
            else:
                continue
            values[key].append(float(si.distance(sj)))
    return {key: min(distances) for key, distances in values.items() if distances}


def main() -> None:
    OUT.mkdir(exist_ok=True)
    for name, (cod_id, scale, substitute) in MODELS.items():
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            structure = Structure.from_file(source_path(cod_id))
        if substitute:
            structure = map_to_ca(structure)
        if scale != 1.0:
            structure.scale_lattice(structure.volume * scale**3)
        target = OUT / f"{name}.cif"
        CifWriter(
            structure,
            symprec=1e-3,
            significant_figures=8,
            refine_struct=True,
        ).write_file(target)
        sg = structure.get_space_group_info(symprec=1e-3)
        mins = distance_screen(structure)
        print(
            name,
            structure.composition.reduced_formula,
            f"SG={sg[0]}({sg[1]})",
            "cell=" + ",".join(f"{v:.5f}" for v in structure.lattice.parameters),
            "mins=" + ",".join(f"{k}:{v:.3f}" for k, v in mins.items()),
        )


if __name__ == "__main__":
    main()
