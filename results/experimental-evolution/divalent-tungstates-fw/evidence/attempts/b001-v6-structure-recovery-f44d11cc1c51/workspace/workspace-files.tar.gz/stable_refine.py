"""Replay-consistent, trust-stepped GSAS-II whole-pattern refinement.

GSAS-II reports the residual evaluated before its final Newton shift.  This
driver therefore recalculates after every one-cycle shift and only accepts a
step when the saved parameter vector itself improves the profile.  It keeps
coordinates fixed and alternates low-correlation nuisance blocks.
"""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_coordinates import snapshot


def clear_frozen(project: G2.G2Project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {}


def freeze_all(project: G2.G2Project) -> None:
    histogram = project.histogram(0)
    histogram.Background[0][1] = False
    for value in histogram.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in histogram.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1:
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def activate(
    project: G2.G2Project,
    *,
    background: bool = True,
    scales: bool = True,
    cells: bool = False,
    zero: bool = False,
    shift_correction: bool = False,
    common_profile: bool = False,
    size_phase: int | None = None,
) -> None:
    freeze_all(project)
    histogram = project.histogram(0)
    histogram.Background[0][1] = background
    if zero:
        histogram.InstrumentParameters["Zero"][2] = True
    if shift_correction:
        histogram.SampleParameters["Shift"][1] = True
    if common_profile:
        histogram.InstrumentParameters["W"][2] = True
        histogram.InstrumentParameters["X"][2] = True
    for index, phase in enumerate(project.phases()):
        phase.data["General"]["Cell"][0] = cells
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][1] = scales
        if index == size_phase:
            hap["Size"][2][0] = True


def parameter_state(project: G2.G2Project) -> dict:
    histogram = project.histogram(0)
    return {
        "background": copy.deepcopy(histogram.Background),
        "instrument": copy.deepcopy(histogram.InstrumentParameters),
        "sample": copy.deepcopy(histogram.SampleParameters),
        "phases": [
            {
                "cell": copy.deepcopy(phase.data["General"]["Cell"]),
                "atoms": copy.deepcopy(phase.data["Atoms"]),
                "hap": copy.deepcopy(phase.data["Histograms"][histogram.name]),
            }
            for phase in project.phases()
        ],
    }


def restore_state(project: G2.G2Project, state: dict) -> None:
    histogram = project.histogram(0)
    histogram.Background[:] = copy.deepcopy(state["background"])
    histogram.InstrumentParameters.clear()
    histogram.InstrumentParameters.update(copy.deepcopy(state["instrument"]))
    histogram.SampleParameters.clear()
    histogram.SampleParameters.update(copy.deepcopy(state["sample"]))
    for phase, item in zip(project.phases(), state["phases"]):
        phase.data["General"]["Cell"] = copy.deepcopy(item["cell"])
        phase.data["Atoms"] = copy.deepcopy(item["atoms"])
        phase.data["Histograms"][histogram.name] = copy.deepcopy(item["hap"])


def calculate(project: G2.G2Project) -> float:
    clear_frozen(project)
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    return float(project.histogram(0).get_wR())


def physically_valid(project: G2.G2Project) -> bool:
    histogram = project.histogram(0)
    ip = histogram.InstrumentParameters
    if not (0.0 <= ip["W"][1] <= 200.0 and 0.0 <= ip["X"][1] <= 100.0):
        return False
    if not (-0.5 <= ip["Zero"][1] <= 0.5):
        return False
    x = np.asarray(histogram.getdata("X"), float)
    lo, hi = float(x[0]), float(x[-1])
    t = 2.0 * (x - lo) / (hi - lo) - 1.0
    background = np.polynomial.chebyshev.chebval(t, histogram.Background[0][3:])
    if np.min(background) <= 0.0:
        return False
    for phase in project.phases():
        cell = phase.data["General"]["Cell"]
        if any(not np.isfinite(v) or v <= 0 for v in cell[1:4]):
            return False
        hap = phase.data["Histograms"][histogram.name]
        if hap["Scale"][0] <= 0.0 or hap["Size"][1][0] < 0.02:
            return False
    return True


def trust_block(
    project: G2.G2Project,
    stage: str,
    history: list,
    *,
    steps: int,
    shift: float,
    activation: dict,
) -> None:
    activate(project, **activation)
    current = calculate(project)
    accepted = 0
    failed = 0
    for attempt in range(1, steps + 1):
        before = parameter_state(project)
        project.data["Controls"]["data"]["shift factor"] = shift
        clear_frozen(project)
        project.set_Controls("cycles", 1)
        project.refine(makeBack=False)
        trial = calculate(project)
        if physically_valid(project) and trial < current - 1.0e-5:
            improvement = current - trial
            current = trial
            accepted += 1
            failed = 0
            shift = min(0.5, shift * 1.25)
            print(
                f"{stage} step={attempt} accepted Rwp={current:.6f}% "
                f"delta={improvement:.6f} shift={shift:.4f}"
            )
        else:
            restore_state(project, before)
            clear_frozen(project)
            current = calculate(project)
            shift *= 0.5
            failed += 1
            print(
                f"{stage} step={attempt} rejected Rwp={trial:.6f}% "
                f"kept={current:.6f}% shift={shift:.4f}"
            )
            if shift < 0.003 or failed >= 2:
                break
    item = snapshot(project, project.histogram(0), stage)
    item["accepted_steps"] = accepted
    item["ending_shift_factor"] = shift
    history.append(item)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--angular", choices=("zero", "shift"), default="zero")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    project = G2.G2Project(gpxfile=args.input, newgpx=str(output))
    histogram = project.histogram(0)
    histogram.SampleParameters["Scale"] = [1.0, False]
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
            atom.uiso = 0.01
        hap = phase.data["Histograms"][histogram.name]
        hap["Mustrain"][1][0] = 0.0
    clear_frozen(project)

    project.update_ids()
    for phase in project.phases():
        prefix = f"{phase.id}:{histogram.id}:"
        project.set_Controls("parmMin", 1.0e-8, variable=prefix + "Scale")
        project.set_Controls("parmMin", 0.02, variable=prefix + "Size;i")
        project.set_Controls("parmMax", 100.0, variable=prefix + "Size;i")
    project.set_Controls("parmMin", 0.0, variable=f":{histogram.id}:W")
    project.set_Controls("parmMax", 200.0, variable=f":{histogram.id}:W")
    project.set_Controls("parmMin", 0.0, variable=f":{histogram.id}:X")
    project.set_Controls("parmMax", 100.0, variable=f":{histogram.id}:X")
    project.set_Controls("parmMin", -0.5, variable=f":{histogram.id}:Zero")
    project.set_Controls("parmMax", 0.5, variable=f":{histogram.id}:Zero")

    history: list[dict] = []
    angular_flags = {
        "zero": args.angular == "zero",
        "shift_correction": args.angular == "shift",
    }
    baseline = calculate(project)
    print(f"replayed baseline Rwp={baseline:.6f}%")
    history.append(snapshot(project, histogram, "replayed_baseline"))

    trust_block(
        project,
        "linear_rebalance",
        history,
        steps=8,
        shift=0.5,
        activation={"background": True, "scales": True},
    )
    trust_block(
        project,
        "cells_zero",
        history,
        steps=12,
        shift=0.2,
        activation={
            "background": True,
            "scales": True,
            "cells": True,
            **angular_flags,
        },
    )
    trust_block(
        project,
        "common_profile",
        history,
        steps=12,
        shift=0.1,
        activation={
            "background": True,
            "scales": True,
            "cells": True,
            **angular_flags,
            "common_profile": True,
        },
    )
    # Alternate phase-specific size blocks with a common-profile rebalance.
    for round_number in range(1, 3):
        for phase_index, phase in enumerate(project.phases()):
            trust_block(
                project,
                f"size_r{round_number}_{phase.name}",
                history,
                steps=8,
                shift=0.08,
                activation={
                    "background": True,
                    "scales": True,
                    "size_phase": phase_index,
                },
            )
        trust_block(
            project,
            f"profile_rebalance_r{round_number}",
            history,
            steps=8,
            shift=0.05,
            activation={
                "background": True,
                "scales": True,
                "cells": True,
                **angular_flags,
                "common_profile": True,
            },
        )

    # The deliverable is saved with all refinement flags off and a newly
    # calculated profile, not a stale pre-shift residual.
    freeze_all(project)
    final_rwp = calculate(project)
    project.save(str(output))
    history.append(snapshot(project, project.histogram(0), "final_fixed_replay"))
    output.with_suffix(".json").write_text(json.dumps(history, indent=2) + "\n")
    print(f"final replay-consistent Rwp={final_rwp:.6f}%")


if __name__ == "__main__":
    main()
