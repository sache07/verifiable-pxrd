"""Physically screened, replay-consistent coordinate recovery for three phases."""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIIspc as G2spc

from refine_coordinates import snapshot
from refine_coordinates_damped import add_restraint_model, clear_frozen
from stable_refine import calculate, freeze_all, parameter_state, restore_state


def expanded_atoms(phase):
    general = phase.data["General"]
    sgdata = general["SGData"]
    expanded = []
    for atom in phase.atoms():
        seen = set()
        for generated in G2spc.GenAtom(
            np.asarray(atom.coordinates) % 1.0, sgdata, All=True, Move=True
        ):
            xyz = np.asarray(generated[0], float) % 1.0
            key = tuple(np.round(xyz, 7))
            if key not in seen:
                seen.add(key)
                expanded.append((atom.element, xyz))
    return expanded


def minimum_contact(phase):
    atoms = expanded_atoms(phase)
    amat, _bmat = G2lat.cell2AB(phase.data["General"]["Cell"][1:7])
    shifts = np.asarray(list(itertools.product((-1, 0, 1), repeat=3)), float)
    best = (np.inf, "", "")
    for i, (element_i, xyz_i) in enumerate(atoms):
        for j in range(i + 1, len(atoms)):
            element_j, xyz_j = atoms[j]
            delta = xyz_j - xyz_i
            distances = np.linalg.norm((delta + shifts) @ amat.T, axis=1)
            distance = float(np.min(distances))
            if distance < best[0]:
                best = (distance, element_i, element_j)
    return best


def coordinates_physical(project, anchors, total_limit=0.012):
    thresholds = {
        ("O", "O"): 2.20,
        ("O", "W"): 1.62,
        ("Ca", "O"): 1.88,
        ("Ca", "W"): 2.55,
        ("Ca", "Ca"): 2.55,
        ("W", "W"): 2.55,
    }
    contacts = []
    for phase in project.phases():
        for index, atom in enumerate(phase.atoms()):
            delta = np.asarray(atom.coordinates) - anchors[phase.name][index]
            delta -= np.rint(delta)
            if np.max(np.abs(delta)) > total_limit + 1.0e-9:
                return False, contacts
        contact = minimum_contact(phase)
        pair = tuple(sorted(contact[1:]))
        threshold = thresholds.get(pair, 1.50)
        contacts.append((phase.name, *contact))
        if contact[0] < threshold:
            return False, contacts
    return True, contacts


def cap_coordinate_step(project, old, anchors, step_limit=0.0005, total_limit=0.012):
    for phase in project.phases():
        for index, atom in enumerate(phase.atoms()):
            if "X" not in atom.refinement_flags:
                continue
            new = np.asarray(atom.coordinates, float)
            delta = new - old[phase.name][index]
            delta -= np.rint(delta)
            delta = np.clip(delta, -step_limit, step_limit)
            proposed = old[phase.name][index] + delta
            total = proposed - anchors[phase.name][index]
            total -= np.rint(total)
            total = np.clip(total, -total_limit, total_limit)
            atom.coordinates = (anchors[phase.name][index] + total).tolist()


def set_group(project, phase_index, elements):
    freeze_all(project)
    phase = project.phases()[phase_index]
    labels = []
    for atom in phase.atoms():
        if atom.element in elements:
            atom.refinement_flags = "X"
            labels.append(atom.label)
    return labels


def coordinate_block(
    project,
    anchors,
    history,
    stage,
    phase_index,
    elements,
    steps=8,
    shift=0.02,
):
    labels = set_group(project, phase_index, elements)
    current = calculate(project)
    accepted = 0
    failed = 0
    for attempt in range(1, steps + 1):
        before = parameter_state(project)
        old = {
            phase.name: [np.asarray(atom.coordinates, float) for atom in phase.atoms()]
            for phase in project.phases()
        }
        clear_frozen(project)
        project.data["Controls"]["data"]["shift factor"] = shift
        project.set_Controls("cycles", 1)
        project.refine(makeBack=False)
        cap_coordinate_step(project, old, anchors)
        trial = calculate(project)
        physical, contacts = coordinates_physical(project, anchors)
        if physical and trial < current - 1.0e-5:
            improvement = current - trial
            current = trial
            accepted += 1
            failed = 0
            shift = min(0.08, shift * 1.25)
            print(
                f"{stage} step={attempt} accepted Rwp={current:.6f}% "
                f"delta={improvement:.6f} shift={shift:.5f}"
            )
        else:
            restore_state(project, before)
            clear_frozen(project)
            current = calculate(project)
            shift *= 0.5
            failed += 1
            print(
                f"{stage} step={attempt} rejected Rwp={trial:.6f}% "
                f"physical={physical} kept={current:.6f}% shift={shift:.5f}"
            )
            if shift < 0.001 or failed >= 2:
                break
    item = snapshot(project, project.histogram(0), stage)
    item["atoms_tested"] = labels
    item["accepted_steps"] = accepted
    _physical, contacts = coordinates_physical(project, anchors)
    item["minimum_contacts"] = contacts
    history.append(item)


def linear_rebalance(project, anchors, history, stage):
    freeze_all(project)
    histogram = project.histogram(0)
    histogram.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][histogram.name]["Scale"][1] = True
    current = calculate(project)
    before = parameter_state(project)
    project.data["Controls"]["data"]["shift factor"] = 0.5
    project.set_Controls("cycles", 1)
    project.refine(makeBack=False)
    trial = calculate(project)
    physical, _contacts = coordinates_physical(project, anchors)
    if not physical or trial >= current:
        restore_state(project, before)
        trial = calculate(project)
    print(f"{stage} Rwp={trial:.6f}%")
    history.append(snapshot(project, histogram, stage))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument(
        "--anchor-project",
        help="project supplying the original parent coordinates for a restart",
    )
    parser.add_argument("--perturb", type=float, default=0.0)
    parser.add_argument(
        "--perturb-phase",
        choices=("all", "0", "1", "2"),
        default="all",
    )
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument(
        "--only",
        choices=("all", "cawo4", "wo3", "third"),
        default="all",
        help="run one coordinate block for a focused cumulative restart",
    )
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    project = G2.G2Project(gpxfile=args.input, newgpx=str(output))
    freeze_all(project)
    clear_frozen(project)
    for phase in project.phases():
        add_restraint_model(project, phase)
    anchor_project = (
        G2.G2Project(gpxfile=args.anchor_project)
        if args.anchor_project
        else project
    )
    anchors = {
        phase.name: [np.asarray(atom.coordinates, float) for atom in phase.atoms()]
        for phase in anchor_project.phases()
    }
    if args.perturb:
        rng = np.random.default_rng(args.seed)
        for phase_index, phase in enumerate(project.phases()):
            if args.perturb_phase != "all" and phase_index != int(args.perturb_phase):
                continue
            for atom in phase.atoms():
                if atom.element == "O":
                    displacement = np.clip(
                        rng.normal(0.0, args.perturb, 3), -0.003, 0.003
                    )
                    atom.coordinates = (
                        np.asarray(atom.coordinates) + displacement
                    ).tolist()
        project.save(str(output))

    history = []
    initial = calculate(project)
    physical, contacts = coordinates_physical(project, anchors)
    print(f"coordinate_start Rwp={initial:.6f}% physical={physical}")
    item = snapshot(project, project.histogram(0), "coordinate_start")
    item["minimum_contacts"] = contacts
    history.append(item)

    if args.only in {"all", "cawo4"}:
        coordinate_block(project, anchors, history, "cawo4_O", 0, {"O"})
        linear_rebalance(project, anchors, history, "rebalance_after_cawo4")
    if args.only in {"all", "wo3"}:
        coordinate_block(project, anchors, history, "wo3_connected_O", 1, {"O"})
        linear_rebalance(project, anchors, history, "rebalance_after_wo3")
    if args.only in {"all", "third"}:
        coordinate_block(project, anchors, history, "ca3wo6_connected_O", 2, {"O"})
        coordinate_block(
            project,
            anchors,
            history,
            "ca3wo6_connected_CaO",
            2,
            {"Ca", "O"},
            shift=0.01,
        )
        linear_rebalance(project, anchors, history, "rebalance_after_ca3wo6")

    freeze_all(project)
    final = calculate(project)
    physical, contacts = coordinates_physical(project, anchors)
    item = snapshot(project, project.histogram(0), "final_coordinate_replay")
    item["minimum_contacts"] = contacts
    item["physical"] = physical
    history.append(item)
    project.save(str(output))
    output.with_suffix(".json").write_text(json.dumps(history, indent=2) + "\n")
    print(f"final coordinate Rwp={final:.6f}% physical={physical}")


if __name__ == "__main__":
    main()
