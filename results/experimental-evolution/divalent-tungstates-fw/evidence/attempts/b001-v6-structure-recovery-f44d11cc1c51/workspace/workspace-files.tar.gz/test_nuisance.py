"""Replay-consistent one-category nuisance screens."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_coordinates import snapshot
from stable_refine import calculate, freeze_all, parameter_state, restore_state


def linear_rebalance(project):
    freeze_all(project)
    histogram = project.histogram(0)
    histogram.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][histogram.name]["Scale"][1] = True
    current = calculate(project)
    before = parameter_state(project)
    project.data["Controls"]["data"]["shift factor"] = 0.5
    project.set_Controls("cycles", 1)
    project.refine(makeBack=False)
    trial = calculate(project)
    if trial >= current:
        restore_state(project, before)
        trial = calculate(project)
    return trial


def run_branch(input_gpx, output, label, setup, valid):
    project = G2.G2Project(gpxfile=input_gpx, newgpx=str(output))
    freeze_all(project)
    setup(project)
    current = calculate(project)
    start = current
    shift = 0.2
    accepted = 0
    for _attempt in range(10):
        before = parameter_state(project)
        project.data["Controls"]["data"]["parmFrozen"] = {}
        project.data["Controls"]["data"]["shift factor"] = shift
        project.set_Controls("cycles", 1)
        project.refine(makeBack=False)
        trial = calculate(project)
        if valid(project) and trial < current - 1.0e-6:
            current = trial
            accepted += 1
            shift = min(0.5, shift * 1.25)
        else:
            restore_state(project, before)
            current = calculate(project)
            shift *= 0.5
            if shift < 0.01:
                break
        setup(project, preserve=True)
    rebalance = linear_rebalance(project)
    freeze_all(project)
    final = calculate(project)
    project.save(str(output))
    item = snapshot(project, project.histogram(0), label)
    item["start_Rwp_percent"] = start
    item["accepted_steps"] = accepted
    item["final_Rwp_percent"] = final
    item["rebalance_Rwp_percent"] = rebalance
    return item


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output_dir")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    def asym_setup(project, preserve=False):
        histogram = project.histogram(0)
        if not preserve:
            histogram.InstrumentParameters["SH/L"][1] = max(
                0.002, histogram.InstrumentParameters["SH/L"][1]
            )
        histogram.InstrumentParameters["SH/L"][2] = True
        project.set_Controls(
            "parmMin", 0.0005, variable=f":{histogram.id}:SH/L"
        )
        project.set_Controls("parmMax", 0.2, variable=f":{histogram.id}:SH/L")

    def asym_valid(project):
        value = project.histogram(0).InstrumentParameters["SH/L"][1]
        return 0.0005 <= value <= 0.2

    def polarization_setup(project, preserve=False):
        histogram = project.histogram(0)
        histogram.InstrumentParameters["Polariz."][2] = True
        project.set_Controls(
            "parmMin", 0.0, variable=f":{histogram.id}:Polariz."
        )
        project.set_Controls(
            "parmMax", 1.0, variable=f":{histogram.id}:Polariz."
        )

    def polarization_valid(project):
        value = project.histogram(0).InstrumentParameters["Polariz."][1]
        return 0.0 <= value <= 1.0

    branches = [
        ("asymmetry", asym_setup, asym_valid),
        ("polarization", polarization_setup, polarization_valid),
    ]
    summary = []
    for label, setup, valid in branches:
        output = output_dir / f"{label}.gpx"
        item = run_branch(args.input, output, label, setup, valid)
        summary.append(item)
        project = G2.G2Project(gpxfile=str(output))
        histogram = project.histogram(0)
        print(
            label,
            f"Rwp={item['final_Rwp_percent']:.6f}%",
            f"SH/L={histogram.InstrumentParameters['SH/L'][1]:.6f}",
            f"polariz={histogram.InstrumentParameters['Polariz.'][1]:.6f}",
        )
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
