#!/usr/bin/env python3
"""Targeted model-selection refinements from the stable one-phase solution."""

from pathlib import Path
import json
import shutil
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp/refinement/stage06_polarization.gpx"
OUT = ROOT / ".tmp/variants"


def load(name):
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"{name}.gpx"
    target.unlink(missing_ok=True)
    p = G2.G2Project(gpxfile=str(BASE), newgpx=str(target))
    clear_all(p)
    return p


def clear_all(p):
    h, ph = p.histogram(0), p.phase(0)
    h.clear_refinements({"Background": {}})
    inst = h.data["Instrument Parameters"][0]
    h.clear_refinements(
        {"Instrument Parameters": [k for k, v in inst.items() if isinstance(v, list) and len(v) > 2]}
    )
    for key, value in h.data["Sample Parameters"].items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    ph.clear_refinements({"Cell": False, "Atoms": [a.label for a in ph.atoms()]})
    ph.clear_HAP_refinements(
        {"Scale": False, "Size": False, "Mustrain": False, "Pref.Ori.": False}
    )


def refine(p, cycles=20):
    p.set_Controls("cycles", cycles)
    p.refine(makeBack=False)
    p.save()
    h, ph = p.histogram(0), p.phase(0)
    cov = p.data.get("Covariance", {}).get("data", {})
    cx, ct, cs, cia = ph.data["General"]["AtomPtrs"]
    print(
        json.dumps(
            {
                "file": p.filename,
                "stored_rwp": h.get_wR(),
                "gof": cov.get("Rvals", {}).get("GOF"),
                "vary": cov.get("varyList", []),
                "values": cov.get("variables", []).tolist()
                if hasattr(cov.get("variables", []), "tolist")
                else cov.get("variables", []),
                "atoms": [
                    {
                        "label": a[ct - 1],
                        "xyz": a[cx : cx + 3],
                        "uiso": a[cia + 1],
                        "flags": a[ct + 1],
                    }
                    for a in ph.data["Atoms"]
                ],
                "sample": h.data["Sample Parameters"],
                "hap": ph.data["Histograms"][h.name],
            },
            indent=2,
            default=str,
        )
    )


def oxygen():
    p = load("oxygen")
    p.phase(0).set_refinements({"Atoms": {"O1": "X"}})
    refine(p)


def common_adp():
    p = load("common_adp")
    ph = p.phase(0)
    ph.set_refinements({"Atoms": {"Ca1": "U", "W1": "U", "O1": "U"}})
    p.add_EquivConstr(("0::AUiso:0", "0::AUiso:1", "0::AUiso:2"))
    refine(p)


def oxygen_common_adp():
    p = load("oxygen_common_adp")
    ph = p.phase(0)
    ph.set_refinements({"Atoms": {"Ca1": "U", "W1": "U", "O1": "XU"}})
    p.add_EquivConstr(("0::AUiso:0", "0::AUiso:1", "0::AUiso:2"))
    ph.set_HAP_refinements({"Scale": True})
    refine(p)


def texture(axis):
    label = "".join(map(str, axis))
    p = load("texture_" + label)
    ph, h = p.phase(0), p.histogram(0)
    hap = ph.data["Histograms"][h.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    ph.set_HAP_refinements({"Scale": True})
    refine(p)


def roughness():
    p = load("roughness")
    h, ph = p.histogram(0), p.phase(0)
    h.data["Sample Parameters"]["SurfRoughA"] = [0.3, True]
    h.data["Sample Parameters"]["SurfRoughB"] = [0.1, True]
    ph.set_HAP_refinements({"Scale": True})
    refine(p)


def isotropic_strain():
    p = load("isotropic_strain")
    h, ph = p.histogram(0), p.phase(0)
    hap = ph.data["Histograms"][h.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 300.0
    hap["Mustrain"][2][0] = True
    h.set_refinements({"Instrument Parameters": ["U", "W"]})
    refine(p)


def uniaxial_strain(axis):
    label = "".join(map(str, axis))
    p = load("uniaxial_strain_" + label)
    h, ph = p.histogram(0), p.phase(0)
    hap = ph.data["Histograms"][h.name]
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = 300.0
    hap["Mustrain"][1][1] = 300.0
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    hap["Mustrain"][3] = list(axis)
    h.set_refinements({"Instrument Parameters": ["U", "W"]})
    refine(p)


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    jobs = {
        "oxygen": oxygen,
        "common_adp": common_adp,
        "oxygen_common_adp": oxygen_common_adp,
        "roughness": roughness,
        "isotropic_strain": isotropic_strain,
        "texture_001": lambda: texture([0, 0, 1]),
        "texture_100": lambda: texture([1, 0, 0]),
        "texture_110": lambda: texture([1, 1, 0]),
        "texture_111": lambda: texture([1, 1, 1]),
        "uniaxial_strain_001": lambda: uniaxial_strain([0, 0, 1]),
        "uniaxial_strain_100": lambda: uniaxial_strain([1, 0, 0]),
    }
    selected = sys.argv[1:] or list(jobs)
    for name in selected:
        print("\n###", name)
        jobs[name]()
