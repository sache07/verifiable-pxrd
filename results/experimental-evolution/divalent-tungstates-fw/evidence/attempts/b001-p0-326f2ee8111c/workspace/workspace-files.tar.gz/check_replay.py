#!/usr/bin/env python3
"""Recompute final-project profiles exactly as the bundled scorer does."""

from pathlib import Path
import json
import os
import shutil
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "learned/divalent-tungstates/scorer/runtime"))
from replay_worker import replay  # noqa: E402


def check(path):
    path = Path(path).resolve()
    out = ROOT / ".tmp" / "replay" / path.stem
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    previous = Path.cwd()
    os.chdir(out)
    try:
        report = replay(
            {
                "project": str(path),
                "observed": str((ROOT / "inputs/pattern.csv").resolve()),
                "histogram": None,
            }
        )
        z = np.load("prediction.npz")
        y, c = z["observed"], z["predicted"]
        w = 1 / np.maximum(y, 1)
        chi = float(np.sum(w * (y - c) ** 2))
        rwp = 100 * np.sqrt(chi / np.sum(w * y**2))
        report.update(chi_square=chi, rwp_percent=float(rwp))
        (out / "replay.json").write_text(json.dumps(report, indent=2) + "\n")
        print(path.name, "Rwp", rwp, "chi2", chi, "flags", report["profile_review_flags"])
    finally:
        os.chdir(previous)


if __name__ == "__main__":
    for arg in sys.argv[1:]:
        check(arg)
