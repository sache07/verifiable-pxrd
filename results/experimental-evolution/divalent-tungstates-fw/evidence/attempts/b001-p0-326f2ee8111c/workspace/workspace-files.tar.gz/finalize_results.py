#!/usr/bin/env python3
"""Create the submission artifacts from the selected GSAS-II project."""

from pathlib import Path
import json
import os
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/variants/powerbg_iter3.gpx"
FINAL = ROOT / "final.gpx"
CIF = ROOT / "phase_1_CaWO4.cif"
REPLAY_DIR = ROOT / ".tmp/final_replay"


def main():
    G2.SetPrintLevel("error")
    FINAL.unlink(missing_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    project.save()
    histogram_name = project.histogram(0).name
    native_gof = project.data["Covariance"]["data"].get("Rvals", {}).get("GOF")
    nvars = project.data["Covariance"]["data"].get("Rvals", {}).get("Nvars")

    # Export the full-precision saved atom values. GSAS-II's covariance keeps
    # shift variables from the last cycle; clearing it in this throwaway
    # in-memory copy prevents those shifts from being applied a second time.
    export_project = G2.G2Project(gpxfile=str(FINAL))
    export_project.data["Covariance"]["data"] = {}
    CIF.unlink(missing_ok=True)
    export_project.phase(0).export_CIF(str(CIF))

    # Use exactly the evaluator's fresh atomic replay to create fit.csv and the
    # reported statistics; do not rely on cached calculated arrays in the GPX.
    sys.path.insert(0, str(ROOT / "learned/divalent-tungstates/scorer/runtime"))
    from replay_worker import replay

    if REPLAY_DIR.exists():
        shutil.rmtree(REPLAY_DIR)
    REPLAY_DIR.mkdir(parents=True)
    previous = Path.cwd()
    os.chdir(REPLAY_DIR)
    try:
        replay_report = replay(
            {
                "project": str(FINAL),
                "observed": str(ROOT / "inputs/pattern.csv"),
                "histogram": histogram_name,
            }
        )
        with np.load("prediction.npz") as z:
            x = z["x"].copy()
            observed = z["observed"].copy()
            calculated = z["predicted"].copy()
    finally:
        os.chdir(previous)

    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, observed, calculated, difference]),
        delimiter=",",
        # Keep the angle label within the scorer's documented aliases; units
        # are degrees 2theta as stated in metadata.json and report.md.
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8g", "%.10g", "%.10g"],
    )
    weights = 1 / np.maximum(observed, 1)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100 * np.sqrt(chi_square / denominator))
    rp = float(100 * np.sum(np.abs(difference)) / np.sum(observed))
    phases = replay_report["phases"]
    if len(phases) != 1:
        raise RuntimeError("Selected final project is not the intended one-phase model")
    result = {
        "phases": [
            {
                "name": "calcium tungstate (scheelite)",
                "formula": "CaWO4",
                "space_group": "I 41/a (No. 88)",
                "cif_path": CIF.name,
                "weight_fraction": float(phases[0]["weight_fraction"]),
            }
        ],
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "weighted_chi_square": chi_square,
            "goodness_of_fit": float(native_gof),
            "n_points": int(len(x)),
            "refined_variables_last_cycle": int(nvars),
            "weighting": "1/max(observed_counts, 1)",
        },
        "refinement_histogram": histogram_name,
        "profile_review_flags": replay_report["profile_review_flags"],
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
