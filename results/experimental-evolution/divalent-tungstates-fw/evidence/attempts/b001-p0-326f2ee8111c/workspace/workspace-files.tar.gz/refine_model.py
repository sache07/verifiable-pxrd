#!/usr/bin/env python3
"""Build and refine a GSAS-II model for the supplied powder pattern.

This script is intentionally kept in the workspace as an auditable record of
how final.gpx and the tabulated fit were produced. Run it with GSAS2_PYTHON.
"""

from pathlib import Path
import json
import shutil
import sys

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp" / "refinement"
INPUT = ROOT / "inputs" / "pattern.csv"
REFERENCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/7/21/92/7219229.cif"
)


def prepare_input_files():
    TMP.mkdir(parents=True, exist_ok=True)
    x, y = np.loadtxt(INPUT, delimiter=",", skiprows=1).T
    # The measurement supplies counts but no pointwise uncertainties. Poisson
    # count uncertainties reproduce the weighting used for final validation.
    np.savetxt(
        TMP / "pattern.xye",
        np.column_stack([x, y, np.sqrt(np.maximum(y, 1.0))]),
        fmt=["%.8f", "%.8g", "%.10g"],
        header="2theta intensity sigma",
    )
    (TMP / "instrument.instprm").write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return x, y


def set_atom_uiso(phase, value=0.01):
    cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
    for atom in phase.data["Atoms"]:
        atom[cia] = "I"
        atom[cia + 1] = float(value)


def status(project, tag):
    hist = project.histogram(0)
    phase = project.phase(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    sample = hist.data["Sample Parameters"]
    inst = hist.data["Instrument Parameters"][0]
    hap = phase.data["Histograms"][hist.name]
    atoms = []
    cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
    for atom in phase.data["Atoms"]:
        atoms.append(
            {
                "label": atom[ct - 1],
                "type": atom[ct],
                "xyz": list(map(float, atom[cx : cx + 3])),
                "uiso": float(atom[cia + 1]),
                "flags": atom[ct + 1],
            }
        )
    row = {
        "tag": tag,
        "rwp": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "cell": phase.get_cell(),
        "background": hist.data["Background"][0],
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
        "sample": {
            k: (v[0] if isinstance(v, list) else v)
            for k, v in sample.items()
            if k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"]
        },
        "hap_scale": hap["Scale"][0],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "pref_ori": hap["Pref.Ori."],
        "atoms": atoms,
        "vary": list(cov.get("varyList", [])),
        "variables": [float(v) for v in cov.get("variables", [])],
        "sig": [float(v) for v in cov.get("sig", [])],
    }
    print(json.dumps(row, indent=2, default=str))
    # Keep the active project filename fixed. GSAS-II writes the active file at
    # the start of the next refinement, so changing it here would overwrite the
    # preceding stage. Copying gives immutable diagnostic snapshots instead.
    project.save()
    snapshot = TMP / f"{tag}.gpx"
    if Path(project.filename).resolve() != snapshot.resolve():
        shutil.copy2(project.filename, snapshot)
    return row


def run_refinement(project, tag, cycles=8):
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    return status(project, tag)


def build():
    G2.SetPrintLevel("warn")
    x, y = prepare_input_files()
    work = TMP / "working.gpx"
    work.unlink(missing_ok=True)
    project = G2.G2Project(newgpx=str(work))
    phase = project.add_phase(
        str(REFERENCE), phasename="CaWO4_scheelite", fmthint="CIF"
    )
    hist = project.add_powder_histogram(
        str(TMP / "pattern.xye"),
        str(TMP / "instrument.instprm"),
        phases=[phase],
        fmthint="xye",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})

    # A robust smooth estimate gives the first background/scale fit a stable
    # starting point. GSAS-II uses Chebyshev T_n on [-1,1] here.
    baseline = percentile_filter(y, percentile=20, size=401, mode="nearest")
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    bgcoef = np.polynomial.chebyshev.chebfit(t, baseline, 11)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(bgcoef),
                "coeffs": bgcoef.tolist(),
                "refine": True,
            }
        }
    )
    set_atom_uiso(phase, 0.01)
    phase.set_HAP_refinements({"Scale": True})
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]
    status(project, "stage00_initial")

    # Establish scale and smooth background first.
    run_refinement(project, "stage01_scale_background", 12)

    # Peak positions: tetragonal cell, angular zero and specimen displacement.
    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(project, "stage02_cell_zero", 12)
    hist.SampleParameters["Shift"] = [0.0, True]
    run_refinement(project, "stage03_shift", 12)

    # Instrument profile and asymmetry. Isotropic specimen size/strain are
    # intentionally initially negligible because their angular dependences are
    # degenerate with X/U; anisotropy is assessed separately below.
    hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    run_refinement(project, "stage04_profile_wx", 12)
    hist.set_refinements({"Instrument Parameters": ["U"]})
    run_refinement(project, "stage05_profile_u", 12)

    # Polarization and the symmetry-allowed oxygen coordinate displacement.
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    run_refinement(project, "stage06_polarization", 12)
    phase.set_refinements({"Atoms": {"O1": "X"}})
    run_refinement(project, "stage07_structure", 16)

    # The synthetic measurement uses one isotropic Uiso per phase. Constrain
    # that physically by refining a common value through an explicit GSAS
    # equivalence after first allowing the heavy-atom values to settle.
    phase.set_refinements({"Atoms": {"Ca1": "U", "W1": "U", "O1": "XU"}})
    project.add_EquivConstr(("0::AUiso:0", "0::AUiso:1", "0::AUiso:2"))
    run_refinement(project, "stage08_common_adp", 16)

    # Save the current best project for model-selection experiments.
    project.save(TMP / "base_refined.gpx")
    return project


if __name__ == "__main__":
    build()
