#!/usr/bin/env python3
"""Alternately fit a physical power-law background and the atomic model."""

from pathlib import Path
import json
import os
import shutil
import sys

import numpy as np
from scipy.optimize import least_squares
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / "learned/divalent-tungstates/scorer/runtime"
sys.path.insert(0, str(RUNTIME))
from replay_worker import replay  # noqa: E402


def replay_arrays(project, label):
    project = Path(project).resolve()
    folder = ROOT / ".tmp/power_background_replay" / label
    if folder.exists():
        shutil.rmtree(folder)
    folder.mkdir(parents=True)
    previous = Path.cwd()
    os.chdir(folder)
    try:
        report = replay(
            {
                "project": str(project),
                "observed": str((ROOT / "inputs/pattern.csv").resolve()),
                "histogram": None,
            }
        )
        with np.load("prediction.npz") as z:
            arrays = {k: z[k].copy() for k in z.files}
    finally:
        os.chdir(previous)
    return report, arrays


def power_background(x, p):
    t = (x - x[0]) / (x[-1] - x[0])
    dx = x - x[0]
    floor = p[0] * (1 - t) ** 2 + 2 * p[1] * t * (1 - t) + p[2] * t**2
    return floor + p[3] * (1 + dx / p[4]) ** (-p[5])


def fit_power(arrays, initial=None):
    x, y, signal = arrays["x"], arrays["observed"], arrays["signal"]
    sqw = np.sqrt(1 / np.maximum(y, 1))
    if initial is None:
        initial = np.array([510.0, 550.0, 525.0, 1735.0, 12.5, 2.5])
    lower = [0, 0, 0, 0, 0.1, 0.05]
    upper = [5000, 5000, 5000, 10000, 200, 10]
    result = least_squares(
        lambda p: (y - signal - power_background(x, p)) * sqw,
        initial,
        bounds=(lower, upper),
        max_nfev=10000,
        xtol=1e-14,
        ftol=1e-14,
        gtol=1e-14,
    )
    return result.x, float(np.sum(result.fun**2))


def install_background(project, x, values, ncoef=40):
    h = project.histogram(0)
    u = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    coeff = np.polynomial.chebyshev.chebfit(u, values, ncoef - 1)
    approx = np.polynomial.chebyshev.chebval(u, coeff)
    h.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": ncoef,
                "coeffs": coeff.tolist(),
                "refine": False,
            }
        }
    )
    return float(np.max(np.abs(values - approx)))


def one_cycle(source, output, initial=None):
    source, output = Path(source), Path(output)
    before, arrays = replay_arrays(source, output.stem + "_before")
    params, chi = fit_power(arrays, initial)
    output.unlink(missing_ok=True)
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    error = install_background(project, arrays["x"], power_background(arrays["x"], params))
    project.set_Controls("cycles", 30)
    project.refine(makeBack=False)
    project.save()
    after, final_arrays = replay_arrays(output, output.stem + "_after")
    y, c = final_arrays["observed"], final_arrays["predicted"]
    w = 1 / np.maximum(y, 1)
    final_chi = float(np.sum(w * (y - c) ** 2))
    print(
        json.dumps(
            {
                "source": str(source),
                "output": str(output),
                "power_parameters": params.tolist(),
                "conditional_chi_square": chi,
                "chebyshev_max_error_counts": error,
                "final_chi_square": final_chi,
                "final_rwp_percent": float(100 * np.sqrt(final_chi / np.sum(w * y**2))),
                "profile_review_flags": after["profile_review_flags"],
            },
            indent=2,
        )
    )
    return params


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    source = Path(sys.argv[1])
    prefix = Path(sys.argv[2])
    params = None
    for i in range(1, 5):
        output = prefix.with_name(prefix.name + f"_iter{i}.gpx")
        params = one_cycle(source, output, params)
        source = output
