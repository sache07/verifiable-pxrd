#!/usr/bin/env python3
"""Nonnegative residual-profile tests for chemically plausible extra phases."""

from pathlib import Path
import json
import os
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp/variants/powerbg_iter3.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = ROOT / ".tmp/omission_tests"
sys.path.insert(0, str(ROOT / "learned/divalent-tungstates/scorer/runtime"))
from replay_worker import replay  # noqa: E402


CANDIDATES = {
    "CaO": "1563196",
    "WO3_monoclinic": "1528915",
    "Ca3WO6": "1563081",
    "CaWO4_monoclinic": "1546035",
    "Ca4.26W10O30": "4030741",
}


def cod_path(record):
    return COD / record[0] / record[1:3] / record[3:5] / (record + ".cif")


def replay_arrays(project, label):
    folder = OUT / label
    if folder.exists():
        shutil.rmtree(folder)
    folder.mkdir(parents=True)
    old = Path.cwd()
    os.chdir(folder)
    try:
        report = replay(
            {
                "project": str(Path(project).resolve()),
                "observed": str((ROOT / "inputs/pattern.csv").resolve()),
                "histogram": None,
            }
        )
        with np.load("prediction.npz") as z:
            arrays = {key: z[key].copy() for key in z.files}
    finally:
        os.chdir(old)
    return report, arrays


def set_uiso(phase, value):
    cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
    for atom in phase.data["Atoms"]:
        atom[cia] = "I"
        atom[cia + 1] = value


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    base_report, base = replay_arrays(BASE.resolve(), "base")
    y, pred = base["observed"], base["predicted"]
    w = 1 / np.maximum(y, 1)
    residual = y - pred
    base_chi = float(np.sum(w * residual**2))
    main_mass_scale = base_report["phases"][0]["cell_mass"] * base_report["phases"][0]["scale"]
    results = []
    for name, record in CANDIDATES.items():
        gpx = OUT / (name.replace(".", "_") + ".gpx")
        project = G2.G2Project(gpxfile=str(BASE), newgpx=str(gpx))
        hist = project.histogram(0)
        phase = project.add_phase(
            str(cod_path(record)), phasename=name, histograms=[hist], fmthint="CIF"
        )
        set_uiso(phase, 0.01)
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        project.save()
        report, mixed = replay_arrays(gpx.resolve(), name.replace(".", "_"))
        candidate = mixed["predicted"] - pred
        information = float(np.sum(w * candidate**2))
        unconstrained = float(np.sum(w * candidate * residual) / information)
        scale = max(0.0, unconstrained)
        fitted = pred + scale * candidate
        chi = float(np.sum(w * (y - fitted) ** 2))
        sigma_scale = information ** -0.5
        upper_scale = max(0.0, unconstrained) + 1.645 * sigma_scale
        cell_mass = next(p["cell_mass"] for p in report["phases"] if p["name"] == name)
        fraction = cell_mass * scale / (main_mass_scale + cell_mass * scale)
        upper_fraction = cell_mass * upper_scale / (main_mass_scale + cell_mass * upper_scale)
        results.append(
            {
                "phase": name,
                "cod_id": record,
                "unconstrained_scale": unconstrained,
                "nonnegative_weight_fraction": fraction,
                "approximate_one_sided_95pct_weight_fraction_upper": upper_fraction,
                "chi_square_improvement": base_chi - chi,
            }
        )
    result = {
        "base_chi_square": base_chi,
        "method": "One-at-a-time nonnegative weighted residual projection at the reference cell; upper limits are local linear-profile estimates, not universal detection limits.",
        "candidates": results,
    }
    (OUT / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    main()
