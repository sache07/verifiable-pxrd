#!/usr/bin/env python3
"""Finalize the selected GSAS-II branch and export all requested artifacts."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis/model_comparisons/zero_bg6_minprofile/model.gpx"
FINAL = ROOT / "final.gpx"


def main() -> None:
    if FINAL.exists():
        FINAL.unlink()
    project = G2.G2Project(str(SOURCE), newgpx=str(FINAL))
    G2.SetPrintLevel("warn")
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("X"), dtype=float)
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    project.save()

    cov = project.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    fractions = hist.ComputeMassFracs()
    total = sum(float(value[0]) for value in fractions.values())
    if total <= 0:
        raise RuntimeError("nonpositive modeled crystalline mass")

    cif_names = {
        "WO3_COD_2311041": "phase_WO3.cif",
        "BaCO3_COD_9010928": "phase_BaCO3.cif",
    }
    phase_rows = []
    for phase in project.phases():
        if phase.name not in cif_names:
            raise RuntimeError(f"unexpected phase in final project: {phase.name}")
        cif_name = cif_names[phase.name]
        phase.export_CIF(str(ROOT / cif_name))
        value, esd = fractions[phase.name]
        phase_rows.append(
            {
                "name": "monoclinic WO3" if phase.name.startswith("WO3") else "orthorhombic BaCO3 (witherite)",
                "formula": "WO3" if phase.name.startswith("WO3") else "BaCO3",
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": cif_name,
                "weight_fraction": float(value / total),
                "weight_fraction_esd": float(esd / total),
                "source": (
                    "COD 2311041, neutron-diffraction WO3 parent"
                    if phase.name.startswith("WO3")
                    else "COD 9010928, room-temperature synthetic witherite parent"
                ),
            }
        )

    columns = [
        np.asarray(hist.getdata(key), dtype=float)
        for key in ["X", "Yobs", "Ycalc", "Residual", "Background"]
    ]
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta",
                "observed",
                "calculated",
                "difference_observed_minus_calculated",
                "background",
            ]
        )
        writer.writerows(zip(*columns))

    result = {
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": float(hist.get_wR()),
            "Rp_percent": float(hist.residuals["R"]),
            "Rexp_percent": float(hist.residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
            "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
            "weighting": "1/max(observed_counts,1); counting uncertainties inferred as sqrt(counts)",
            "fit_range_two_theta_deg": [float(x[0]), float(x[-1])],
        },
        "refinement_histogram": hist.name,
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "notes": [
            "Fractions are normalized over the two modeled crystalline phases.",
            "Atomic coordinates were retained from physically passing published parents; cells were refined.",
        ],
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
