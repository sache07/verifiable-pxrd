#!/usr/bin/env python3
"""Round-trip candidate CIFs through GSAS-II into compatible normalized files."""

from __future__ import annotations

import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
OUT = ROOT / "analysis/candidates"


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    for cod_id in sys.argv[1:]:
        project = G2.G2Project(newgpx=str(OUT / f"normalize_{cod_id}.gpx"))
        phase = project.add_phase(str(cod_path(cod_id)), fmthint="CIF")
        phase.export_CIF(str(OUT / f"cod_{cod_id}.cif"))


if __name__ == "__main__":
    main()
