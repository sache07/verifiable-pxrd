#!/usr/bin/env python3
"""Inventory deletion/addition and nuisance-branch comparisons in GSAS-II."""

from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIobj as G2obj


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "analysis/model_comparisons"
CAND = ROOT / "analysis/candidates"

PHASES = {
    "wo3": (CAND / "cod_2311041.cif", "WO3_COD_2311041"),
    "wo3_triclinic": (CAND / "cod_2106293.cif", "WO3_COD_2106293"),
    "baco3": (CAND / "cod_9010928.cif", "BaCO3_COD_9010928"),
    "bawo4": (CAND / "bawo4_repaired.cif", "BaWO4_repaired_COD_1527204"),
}

STANDARD_PROFILE = {"U": 20.0, "V": -10.0, "W": 40.0, "X": 2.0, "Y": 2.0}
ALTERNATE_PROFILE = {"U": 10.0, "V": 0.0, "W": 25.0, "X": 4.0, "Y": 0.0}
MINIMAL_PROFILE = {"U": 0.0, "V": 0.0, "W": 25.0, "X": 4.0, "Y": 0.0}

CONFIGS = {
    "zero_bg4": {"phases": ["wo3", "baco3"], "angular": "zero", "background": 4},
    "zero_bg6": {"phases": ["wo3", "baco3"], "angular": "zero", "background": 6},
    "zero_bg8": {"phases": ["wo3", "baco3"], "angular": "zero", "background": 8},
    "shift_bg6": {"phases": ["wo3", "baco3"], "angular": "shift", "background": 6},
    "zero_bg6_altprofile": {
        "phases": ["wo3", "baco3"],
        "angular": "zero",
        "background": 6,
        "profile": ALTERNATE_PROFILE,
    },
    "zero_bg6_minprofile": {
        "phases": ["wo3", "baco3"],
        "angular": "zero",
        "background": 6,
        "profile": MINIMAL_PROFILE,
    },
    "triclinic_minprofile": {
        "phases": ["wo3_triclinic", "baco3"],
        "angular": "zero",
        "background": 6,
        "profile": MINIMAL_PROFILE,
    },
    "wo3_only": {"phases": ["wo3"], "angular": "zero", "background": 6},
    "baco3_only": {"phases": ["baco3"], "angular": "zero", "background": 6},
    "plus_bawo4": {
        "phases": ["wo3", "baco3", "bawo4"],
        "angular": "zero",
        "background": 6,
    },
}


def prepare_data(branch: Path, profile: dict[str, float], angular: str) -> tuple[Path, Path]:
    branch.mkdir(parents=True, exist_ok=True)
    xye = branch / "pattern.xye"
    with (ROOT / "inputs/pattern.csv").open() as src, xye.open("w") as dst:
        for row in csv.DictReader(src):
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    inst = branch / "instrument.instprm"
    zero = 0.18 if angular == "zero" else 0.0
    inst.write_text(
        "# GSAS-II Cu Kalpha laboratory Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        f"Zero:{zero};Polariz.:0.5;Azimuth:0.0\n"
        f"U:{profile['U']};V:{profile['V']};W:{profile['W']};"
        f"X:{profile['X']};Y:{profile['Y']};Z:0.0;SH/L:0.002\n"
    )
    return xye, inst


def add_nonnegative_scale_bounds(project: G2.G2Project, count: int) -> None:
    controls = project.data["Controls"]["data"]
    G2obj.patchControls(controls)
    for index in range(count):
        controls["parmMinDict"][G2obj.G2VarObj(f"{index}:0:Scale")] = 0.0


def collect(project: G2.G2Project, tag: str, config: dict, stages: list[dict]) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    try:
        fractions = hist.ComputeMassFracs()
    except Exception:
        fractions = {}
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "weight_fraction": float(fractions.get(phase.name, (np.nan,))[0]),
            "weight_fraction_esd": float(fractions.get(phase.name, (np.nan, np.nan))[1]),
            "hap_scale": float(hap["Scale"][0]),
            "cell": {key: float(value) for key, value in phase.get_cell().items()},
        }
    return {
        "tag": tag,
        "config": config,
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": float(hist.residuals["R"]),
        "GOF": float(rvals.get("GOF", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", np.nan)),
        "instrument": {
            key: {"value": float(value[1]), "refined": bool(value[2])}
            for key, value in hist.InstrumentParameters.items()
            if key in {"Zero", "U", "V", "W", "X", "Y", "Polariz."}
        },
        "sample": {
            key: value
            for key, value in hist.SampleParameters.items()
            if key in {"Gonio. radius", "Shift"}
        },
        "phases": phases,
        "frozen": [str(item) for item in project.get_Frozen()],
        "stages": stages,
        "project": str(Path(project.filename).relative_to(ROOT)),
    }


def stage(project: G2.G2Project, name: str, stages: list[dict]) -> None:
    project.refine(makeBack=False)
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    stages.append(
        {
            "name": name,
            "Rwp_percent": float(hist.get_wR()),
            "GOF": float(rvals.get("GOF", np.nan)),
            "max_shift_over_sigma": float(rvals.get("Max shft/sig", np.nan)),
        }
    )


def run(tag: str, config: dict) -> dict:
    branch = OUT / tag
    profile = dict(config.get("profile", STANDARD_PROFILE))
    xye, inst = prepare_data(branch, profile, config["angular"])
    gpx = branch / "model.gpx"
    if gpx.exists():
        gpx.unlink()
    project = G2.G2Project(newgpx=str(gpx))
    G2.SetPrintLevel("warn")
    phases = []
    for key in config["phases"]:
        cif, name = PHASES[key]
        phases.append(project.add_phase(str(cif), phasename=name, fmthint="CIF"))
    hist = project.add_powder_histogram(str(xye), str(inst), phases=phases, fmthint="xye")
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    coeffs = [2850.0] + [0.0] * (config["background"] - 1)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": config["background"],
                "coeffs": coeffs,
                "refine": True,
            }
        }
    )
    for index, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        initial_scale = 0.08 if config["phases"][index] == "bawo4" else 4.0
        hap["Scale"] = [initial_scale, True]
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
    add_nonnegative_scale_bounds(project, len(phases))
    project.set_Controls("cycles", 8)
    stages: list[dict] = []
    stage(project, "background_scales", stages)
    for key, phase in zip(config["phases"], phases):
        # A phase must first earn nonzero scale support before its cell is varied.
        # Keep the diagnostic BaWO4 parent fixed during this addition test.
        if key != "bawo4":
            phase.set_refinements({"Cell": True})
    stage(project, "cells", stages)
    if config["angular"] == "zero":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    else:
        hist.SampleParameters["Shift"] = [-440.0, True]
    stage(project, config["angular"], stages)
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    stage(project, "profile_WX", stages)
    stage(project, "repeat", stages)
    project.save()
    result = collect(project, tag, config, stages)
    (branch / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        tag,
        f"Rwp={result['Rwp_percent']:.5f}",
        f"GOF={result['GOF']:.4f}",
        {key: round(value["weight_fraction"], 6) for key, value in result["phases"].items()},
        "frozen=", result["frozen"],
        flush=True,
    )
    return result


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    requested = sys.argv[1:] or list(CONFIGS)
    results = []
    for tag in requested:
        try:
            results.append(run(tag, CONFIGS[tag]))
        except Exception as exc:
            error = {"tag": tag, "error": f"{type(exc).__name__}: {exc}"}
            results.append(error)
            print(tag, error["error"], flush=True)
    (OUT / "summary.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
