#!/usr/bin/env python3
"""Compare candidate phase sources with one fixed-coordinate GSAS-II model."""

from __future__ import annotations

import csv
import json
import math
import shutil
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "analysis/source_screen"
CANDIDATES = ROOT / "analysis/candidates"

WO3_IDS = ["2106293", "2311041", "2107312"]
BAC_IDS = ["9010928", "9006847"]


def prepare_data() -> tuple[Path, Path]:
    OUT.mkdir(parents=True, exist_ok=True)
    xye = OUT / "pattern.xye"
    with (ROOT / "inputs/pattern.csv").open() as src, xye.open("w") as dst:
        reader = csv.DictReader(src)
        for row in reader:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")

    inst = OUT / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha laboratory Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.18;Polariz.:0.5;Azimuth:0.0\n"
        "U:20.0;V:-10.0;W:40.0;X:2.0;Y:2.0;Z:0.0;SH/L:0.002\n"
    )
    return xye, inst


def snapshot(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    result = {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "residuals": dict(hist.residuals),
        "instrument": {
            key: float(value[1])
            for key, value in inst.items()
            if key in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"}
        },
        "cells": {
            phase.name: {key: float(value) for key, value in phase.get_cell().items()}
            for phase in project.phases()
        },
        "hap_scales": {
            phase.name: float(phase.data["Histograms"][hist.name]["Scale"][0])
            for phase in project.phases()
        },
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }
    try:
        result["mass_fractions"] = {
            key: [float(value[0]), float(value[1])]
            for key, value in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        result["mass_fraction_error"] = str(exc)
    return result


def refine(project: G2.G2Project, stage: str, log: list[dict]) -> None:
    project.refine(makeBack=False)
    log.append(snapshot(project, stage))


def run_branch(wo3_id: str, bac_id: str, xye: Path, instfile: Path) -> dict:
    tag = f"wo3_{wo3_id}__baco3_{bac_id}"
    branch = OUT / tag
    branch.mkdir(parents=True, exist_ok=True)
    gpx = branch / "screen.gpx"
    if gpx.exists():
        gpx.unlink()
    project = G2.G2Project(newgpx=str(gpx))
    G2.SetPrintLevel("warn")
    phases = [
        project.add_phase(
            str(CANDIDATES / f"cod_{wo3_id}.cif"),
            phasename=f"WO3_COD_{wo3_id}",
            fmthint="CIF",
        ),
        project.add_phase(
            str(CANDIDATES / f"cod_{bac_id}.cif"),
            phasename=f"BaCO3_COD_{bac_id}",
            fmthint="CIF",
        ),
    ]
    hist = project.add_powder_histogram(
        str(xye), str(instfile), phases=phases, fmthint="xye"
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [2850.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": True,
            }
        }
    )
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [4.0, True]
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})

    project.set_Controls("cycles", 8)
    log: list[dict] = []
    refine(project, "background_scales", log)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "cells", log)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "zero", log)

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine(project, "profile_WX", log)
    refine(project, "profile_WX_repeat", log)
    project.save()

    result = {
        "tag": tag,
        "wo3_cod_id": wo3_id,
        "baco3_cod_id": bac_id,
        "coordinates_refined": False,
        "effects": {"size": False, "microstrain": False, "texture": False},
        "stages": log,
        "project": str(gpx.relative_to(ROOT)),
    }
    (branch / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def main() -> None:
    xye, instfile = prepare_data()
    requested = sys.argv[1:]
    pairs = [(w, "9010928") for w in WO3_IDS]
    pairs += [("2106293", b) for b in BAC_IDS if b != "9010928"]
    if requested:
        pairs = [tuple(item.split(",", 1)) for item in requested]
    all_results = []
    for wo3_id, bac_id in pairs:
        print(f"Running {wo3_id} + {bac_id}", flush=True)
        try:
            all_results.append(run_branch(wo3_id, bac_id, xye, instfile))
        except Exception as exc:
            all_results.append(
                {
                    "tag": f"wo3_{wo3_id}__baco3_{bac_id}",
                    "wo3_cod_id": wo3_id,
                    "baco3_cod_id": bac_id,
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )
            print(f"FAILED: {type(exc).__name__}: {exc}", flush=True)
    (OUT / "summary.json").write_text(json.dumps(all_results, indent=2) + "\n")
    for result in all_results:
        if "error" in result:
            print(result["tag"], result["error"])
        else:
            final = result["stages"][-1]
            print(
                result["tag"],
                f"Rwp={final['Rwp_percent']:.4f}%",
                final.get("mass_fractions", {}),
            )


if __name__ == "__main__":
    main()
