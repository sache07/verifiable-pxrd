#!/usr/bin/env python3
"""One-at-a-time profile/specimen tests from the stable source-screen model."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIobj as G2obj


ROOT = Path(__file__).resolve().parents[1]
BASE = (
    ROOT
    / "analysis/source_screen/wo3_2311041__baco3_9010928/screen.gpx"
)
OUT = ROOT / "analysis/effect_tests"


def metrics(project: G2.G2Project, tag: str) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    inst = hist.InstrumentParameters
    x = np.linspace(10.0, 100.0, 901)
    tan = np.tan(np.radians(x / 2.0))
    cos = np.cos(np.radians(x / 2.0))
    sig = inst["U"][1] * tan**2 + inst["V"][1] * tan + inst["W"][1]
    gam = inst["X"][1] / cos + inst["Y"][1] * tan + inst["Z"][1]
    result = {
        "tag": tag,
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": float(hist.residuals["R"]),
        "GOF": float(cov.get("Rvals", {}).get("GOF", np.nan)),
        "converged": bool(cov.get("Rvals", {}).get("converged", False)),
        "max_shift_over_sigma": float(cov.get("Rvals", {}).get("Max shft/sig", np.nan)),
        "instrument": {
            key: {"value": float(value[1]), "refined": bool(value[2])}
            for key, value in inst.items()
            if key
            in {
                "Zero",
                "U",
                "V",
                "W",
                "X",
                "Y",
                "Z",
                "SH/L",
                "Polariz.",
            }
        },
        "minimum_instrument_gaussian_variance_centideg2": float(sig.min()),
        "minimum_instrument_lorentzian_fwhm_centideg": float(gam.min()),
        "sample": {
            key: value
            for key, value in hist.SampleParameters.items()
            if key in {"Gonio. radius", "Shift", "SurfRoughA", "SurfRoughB"}
        },
        "phases": {},
        "vary_list": list(cov.get("varyList", [])),
    }
    try:
        fracs = hist.ComputeMassFracs()
    except Exception:
        fracs = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "weight_fraction": float(fracs.get(phase.name, (np.nan,))[0]),
            "scale": list(hap["Scale"]),
            "size": hap["Size"],
            "microstrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "cell": {key: float(value) for key, value in phase.get_cell().items()},
        }
    return result


def run(tag: str, setup) -> dict:
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / f"{tag}.gpx"
    shutil.copy2(BASE, path)
    project = G2.G2Project(str(path))
    project.set_Controls("cycles", 8)
    setup(project)
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    project.save()
    result = metrics(project, tag)
    (OUT / f"{tag}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        tag,
        f"Rwp={result['Rwp_percent']:.5f}",
        f"GOF={result['GOF']:.4f}",
        f"shift/esd={result['max_shift_over_sigma']:.3f}",
        {k: round(v["weight_fraction"], 6) for k, v in result["phases"].items()},
        flush=True,
    )
    return result


def profile_u(project: G2.G2Project) -> None:
    project.histogram(0).set_refinements({"Instrument Parameters": ["U"]})


def polarization(project: G2.G2Project) -> None:
    project.histogram(0).set_refinements({"Instrument Parameters": ["Polariz."]})


def profile_bounded(project: G2.G2Project) -> None:
    bounds = {
        ":0:U": (0.0, 200.0),
        ":0:V": (-50.0, 100.0),
        ":0:W": (0.001, 200.0),
        ":0:X": (0.0, 100.0),
        ":0:Y": (0.0, 100.0),
    }
    controls = project.data["Controls"]["data"]
    G2obj.patchControls(controls)
    for variable, (lower, upper) in bounds.items():
        key = G2obj.G2VarObj(variable)
        controls["parmMinDict"][key] = lower
        controls["parmMaxDict"][key] = upper
    project.histogram(0).set_refinements(
        {"Instrument Parameters": ["U", "V", "W", "X", "Y"]}
    )


def polarization_bounded(project: G2.G2Project) -> None:
    controls = project.data["Controls"]["data"]
    G2obj.patchControls(controls)
    key = G2obj.G2VarObj(":0:Polariz.")
    controls["parmMinDict"][key] = 0.0
    controls["parmMaxDict"][key] = 1.0
    polarization(project)


def size_phase(index: int):
    def setup(project: G2.G2Project) -> None:
        phase = project.phases()[index]
        phase.setSampleProfile(0, "size", "isotropic", 2.0, LGmix=1.0)
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": 2.0,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )

    return setup


def strain_phase(index: int):
    def setup(project: G2.G2Project) -> None:
        phase = project.phases()[index]
        phase.setSampleProfile(0, "microstrain", "isotropic", 200.0, LGmix=0.5)
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 0.5, "refine": False},
                }
            }
        )

    return setup


def texture_phase(index: int, axis: list[int]):
    def setup(project: G2.G2Project) -> None:
        phase = project.phases()[index]
        hap = phase.data["Histograms"][project.histogram(0).name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = axis
        phase.set_HAP_refinements({"Pref.Ori.": True})

    return setup


def coords_wo3_w(project: G2.G2Project) -> None:
    project.phases()[0].set_refinements(
        {"Atoms": {"W1": "X", "W2": "X"}}
    )


def coords_baco3_ba(project: G2.G2Project) -> None:
    project.phases()[1].set_refinements({"Atoms": {"Ba": "X"}})


def coords_heavy_both(project: G2.G2Project) -> None:
    coords_wo3_w(project)
    coords_baco3_ba(project)


TESTS = {
    "profile_u": profile_u,
    "profile_bounded": profile_bounded,
    "polarization": polarization,
    "polarization_bounded": polarization_bounded,
    "size_wo3": size_phase(0),
    "size_baco3": size_phase(1),
    "strain_wo3": strain_phase(0),
    "strain_baco3": strain_phase(1),
    "texture_wo3_001": texture_phase(0, [0, 0, 1]),
    "texture_wo3_100": texture_phase(0, [1, 0, 0]),
    "texture_wo3_010": texture_phase(0, [0, 1, 0]),
    "texture_baco3_001": texture_phase(1, [0, 0, 1]),
    "texture_baco3_100": texture_phase(1, [1, 0, 0]),
    "texture_baco3_010": texture_phase(1, [0, 1, 0]),
    "coords_wo3_w": coords_wo3_w,
    "coords_baco3_ba": coords_baco3_ba,
    "coords_heavy_both": coords_heavy_both,
}


def main() -> None:
    import sys

    requested = sys.argv[1:] or list(TESTS)
    results = []
    for tag in requested:
        try:
            results.append(run(tag, TESTS[tag]))
        except Exception as exc:
            error = {"tag": tag, "error": f"{type(exc).__name__}: {exc}"}
            results.append(error)
            print(tag, error["error"], flush=True)
    (OUT / "summary.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
