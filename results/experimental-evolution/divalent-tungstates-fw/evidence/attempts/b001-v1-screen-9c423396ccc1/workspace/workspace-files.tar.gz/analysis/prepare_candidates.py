#!/usr/bin/env python3
"""Normalize public COD candidates and apply the supplied physical screen."""

from __future__ import annotations

import json
import os
import subprocess
import sys
import warnings
from pathlib import Path

from pymatgen.analysis.structure_matcher import StructureMatcher
from pymatgen.core import Structure


ROOT = Path(__file__).resolve().parents[1]
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
SCORER_SRC = ROOT / "learned/divalent-tungstates/scorer/src"
sys.path.insert(0, str(SCORER_SRC))
from structure_metrics import physical_screen  # noqa: E402


CANDIDATES = {
    # Same-composition, low-symmetry WO3 sources. The two P21/c entries are
    # retained separately because one source triggers the supplied O--O review.
    "2106293": {"role": "WO3", "basis": "published COD; triclinic P-1"},
    "2311041": {"role": "WO3", "basis": "published COD; monoclinic P21/c"},
    "1528915": {"role": "WO3", "basis": "published COD; monoclinic P21/c"},
    "2107312": {"role": "WO3", "basis": "published COD; orthorhombic Pnma"},
    # Ambient orthorhombic witherite sources and a distinct hexagonal polymorph.
    "9010928": {"role": "BaCO3", "basis": "published COD; witherite Pmcn/Pnma"},
    "9006847": {"role": "BaCO3", "basis": "published COD; hexagonal polymorph"},
    # Chemically plausible reaction product, screened for an inventory test only.
    "1527204": {"role": "BaWO4", "basis": "published COD; scheelite I41/a"},
}


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    out_dir = ROOT / "analysis/candidates"
    out_dir.mkdir(parents=True, exist_ok=True)
    records = []
    matcher = StructureMatcher(
        primitive_cell=True,
        scale=False,
        attempt_supercell=False,
        ltol=1e-5,
        stol=1e-5,
        angle_tol=1e-3,
    )

    gsas_python = os.environ.get("GSAS2_PYTHON")
    if not gsas_python:
        raise RuntimeError("GSAS2_PYTHON is not set")
    subprocess.run(
        [
            gsas_python,
            str(ROOT / "analysis/normalize_candidates_gsas.py"),
            *CANDIDATES.keys(),
        ],
        check=True,
        cwd=ROOT,
    )

    for cod_id, metadata in CANDIDATES.items():
        source = cod_path(cod_id)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            original = Structure.from_file(source)
        normalized_path = out_dir / f"cod_{cod_id}.cif"
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            normalized = Structure.from_file(normalized_path)
        if original.composition.reduced_composition != normalized.composition.reduced_composition:
            raise RuntimeError(f"composition changed while normalizing {cod_id}")
        if not matcher.fit(original, normalized, symmetric=True):
            raise RuntimeError(f"geometry changed while normalizing {cod_id}")
        screen = physical_screen(normalized)
        records.append(
            {
                "cod_id": cod_id,
                **metadata,
                "source_path": str(source),
                "normalized_path": str(normalized_path.relative_to(ROOT)),
                "formula": normalized.composition.reduced_formula,
                "space_group": normalized.get_space_group_info(symprec=0.03)[0],
                "site_count": len(normalized),
                "density_g_cm3": normalized.density,
                "physical_screen": screen,
            }
        )

    report = {
        "normalization": (
            "Imported and re-exported by GSAS-II in a GSAS-compatible setting, then "
            "reloaded by pymatgen and required to match the source without lattice scaling."
        ),
        "records": records,
    }
    (ROOT / "analysis/candidate_screens.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )
    for record in records:
        screen = record["physical_screen"]
        print(
            record["cod_id"],
            record["formula"],
            record["space_group"],
            screen["status"],
            screen["flagged_contact_count"],
        )


if __name__ == "__main__":
    main()
