#!/usr/bin/env python3
"""Export the selected GSAS-II project and all requested submission files."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "refine" / "simple_pearson13" / "trial.gpx"
FINAL = ROOT / "final.gpx"
CIF = ROOT / "CaWO4.cif"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    if not SOURCE.is_file():
        raise FileNotFoundError(SOURCE)
    shutil.copy2(SOURCE, FINAL)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(FINAL))
    if len(project.histograms()) != 1 or len(project.phases()) != 1:
        raise RuntimeError("Selected project is not the expected one-phase/one-histogram model")
    hist = project.histograms()[0]
    phase = project.phases()[0]
    project.save(str(FINAL))
    phase.export_CIF(str(CIF))
    histogram_name = hist.name
    covariance = project.data.get("Covariance", {}).get("data", {})
    n_parameters = len(covariance.get("variables", covariance.get("varyList", [])))

    # Regenerate reflections and the complete profile from the saved atomic
    # project exactly as the evaluator does (without fitting cached arrays).
    worker_path = ROOT / "learned" / "divalent-tungstates" / "scorer" / "runtime" / "replay_worker.py"
    spec = importlib.util.spec_from_file_location("direct_replay_worker", worker_path)
    worker = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(worker)
    replay_dir = ROOT / ".tmp" / "final_replay"
    replay_dir.mkdir(parents=True, exist_ok=True)
    old_cwd = Path.cwd()
    os.chdir(replay_dir)
    try:
        replay = worker.replay(
            {"project": str(FINAL), "observed": str(ROOT / "inputs" / "pattern.csv"), "histogram": histogram_name}
        )
    finally:
        os.chdir(old_cwd)
    if replay.get("status") != "replayed":
        raise RuntimeError(f"Final project replay failed: {replay}")
    if replay.get("profile_review_flags"):
        raise RuntimeError(f"Final project has profile review flags: {replay['profile_review_flags']}")

    with np.load(replay_dir / "prediction.npz", allow_pickle=False) as data:
        x = data["x"].copy()
        observed = data["observed"].copy()
        calculated = data["predicted"].copy()
        background = data["background"].copy()
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference, background)),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f", "%.8f"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100 * np.sqrt(chi_square / denominator))
    safe = np.maximum(calculated, 1e-12)
    poisson_deviance = float(
        2 * np.sum(safe - observed + np.where(observed > 0, observed * np.log(observed / safe), 0.0))
    )
    dof = max(1, len(x) - n_parameters)

    replay_phase = replay["phases"][0]
    fraction = float(replay_phase["weight_fraction"])
    cell = list(map(float, phase.data["General"]["Cell"][1:]))
    atoms = {a.element: a for a in phase.atoms()}
    oxygen = atoms["O"]
    result = {
        "phases": [
            {
                "name": "CaWO4 (scheelite)",
                "formula": "CaWO4",
                "space_group": "I 41/a",
                "cif_path": CIF.name,
                "weight_fraction": fraction,
            }
        ],
        "fit_statistics": {
            "rwp_percent": rwp,
            "chi_square": chi_square,
            "reduced_chi_square": chi_square / dof,
            "poisson_deviance": poisson_deviance,
            "n_points": int(len(x)),
            "n_refined_parameters": int(n_parameters),
            "weighting": "1/max(observed_counts,1) for reported Rwp and chi-square",
        },
        "refinement_histogram": histogram_name,
        "project_path": FINAL.name,
        "project_sha256": sha256(FINAL),
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

    report = f"""# Powder XRD phase analysis

The pattern is modeled as a single crystalline phase: scheelite CaWO4 (space group I 41/a), at a normalized crystalline weight fraction of {fraction:.6f} ({100*fraction:.2f} wt%). The refined cell is a = b = {cell[0]:.6f} A, c = {cell[2]:.6f} A, V = {cell[6]:.3f} A^3. The independent oxygen coordinate is ({oxygen.coordinates[0]:.6f}, {oxygen.coordinates[1]:.6f}, {oxygen.coordinates[2]:.6f}).

Evidence: all resolved Bragg peaks, including 18.63, 28.72, 29.04, 31.43, 34.18, 39.20, 47.11, 54.29, and 57.88 degrees 2theta, index to the scheelite cell with the expected Cu Kalpha1/Kalpha2 splitting. Diagnostic lines for residual CaO (notably near 37.3 and 53.8 degrees), monoclinic WO3 (the 23.1-24.4 degree cluster), and Ca3WO6 (strong low-angle lines near 18.9-22.2 degrees) are absent. Adding texture, surface roughness, anisotropic strain, or extra smooth-background terms did not give physically supported improvements.

The fresh atomic-model replay of `final.gpx` gives Rwp = {rwp:.4f}% and chi-square = {chi_square:.2f} over {len(x)} points (Poisson deviance {poisson_deviance:.2f}); no negative background, displacement tensor, or peak-width flags were found. `fit.csv` was generated from this replay rather than from cached profile arrays.

Uncertainty: 100 wt% is normalized only over the modeled crystalline phases; it does not quantify amorphous material or absolute reaction yield. A trace, strongly overlapped crystalline impurity below practical detection cannot be excluded. The Ca/W framework and lattice are well constrained by this laboratory X-ray pattern, while oxygen coordinates are less precise and correlated with intensity/profile terms. Instrumental Lorentzian broadening and isotropic crystallite-size broadening are mathematically non-unique here, so the profile was retained but no unique size interpretation is claimed.
"""
    (ROOT / "report.md").write_text(report)

    print(json.dumps({"result": result, "replay": replay}, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
