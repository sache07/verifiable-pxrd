#!/usr/bin/env python3
"""Staged GSAS-II refinement for the CaO + WO3 powder pattern.

This is an analysis helper. It creates trial projects under .tmp/refine/ and
prints compact diagnostics after each refinement stage. Final artifact export
is handled separately once the best nuisance/profile model has been selected.
"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
SOURCE_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/"
    "dara/cod-filtered-2024/cif/7/21/92/7219229.cif"
)


def instrument_text() -> str:
    # Mid-range starting values for the uncalibrated Cu Kalpha instrument.
    return (
        "#GSAS-II instrument parameter file; Cu Kalpha Bragg-Brentano\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def initial_background(ncoef: int) -> list[float]:
    x, y = np.loadtxt(PATTERN, delimiter=",", skiprows=1).T
    # A broad lower envelope suppresses the sharp Bragg peaks while retaining
    # the smooth low-angle tail. Fit in the same [-1,1] basis GSAS-II uses for
    # the chebyschev-1 background.
    baseline = percentile_filter(y, percentile=25, size=301, mode="nearest")
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    coef = np.polynomial.chebyshev.chebfit(t, baseline, ncoef - 1)
    return coef.tolist()


def snapshot(proj: G2.G2Project, label: str) -> dict:
    hist = proj.histograms()[0]
    phase = proj.phases()[0]
    arrays = hist.data["data"][1]
    x, obs, wt, calc, back = [np.asarray(v, float) for v in arrays[:5]]
    resid = obs - calc
    scorer_wt = 1.0 / np.maximum(obs, 1.0)
    loss = float(np.sum(scorer_wt * resid**2))
    denom = float(np.sum(scorer_wt * obs**2))
    project_loss = float(np.sum(wt * resid**2))
    safe_calc = np.maximum(calc, 1e-12)
    poisson = float(2 * np.sum(safe_calc - obs + np.where(
        obs > 0, obs * np.log(obs / safe_calc), 0.0
    )))
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    hap = phase.data["Histograms"][hist.name]
    report = {
        "stage": label,
        "rwp_percent_recomputed": 100 * np.sqrt(loss / denom),
        "rwp_percent_gsas": hist.get_wR(),
        "chi_square": loss,
        "project_weighted_chi_square": project_loss,
        "poisson_deviance_observed": poisson,
        "cell": list(map(float, phase.data["General"]["Cell"][1:])),
        "instrument": {
            k: float(inst[k][1])
            for k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
            if k in inst
        },
        "sample": {
            k: float(sample[k][0])
            for k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
            if k in sample
        },
        "hap_scale": float(hap["Scale"][0]),
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "atoms": [
            {
                "label": a.label,
                "element": a.element,
                "xyz": list(map(float, a.coordinates)),
                "uiso": float(a.uiso),
                "flags": a.refinement_flags,
            }
            for a in phase.atoms()
        ],
        "background": {
            "type": hist.Background[0][0],
            "refine": bool(hist.Background[0][1]),
            "coefficients": list(map(float, hist.Background[0][3:])),
            "min_counts": float(np.min(back)),
        },
        "residual_mean": float(np.mean(resid)),
        "residual_std": float(np.std(resid)),
        "bins": len(x),
    }
    print(json.dumps(report, indent=2, default=lambda o: np.asarray(o).tolist()))
    return report


def run_refine(proj: G2.G2Project, label: str, reports: list[dict], cycles: int = 8) -> None:
    proj.set_Controls("cycles", cycles)
    proj.refine()
    reports.append(snapshot(proj, label))


def build(args: argparse.Namespace) -> None:
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    gpx = out / "trial.gpx"
    if gpx.exists():
        gpx.unlink()
    inst_path = out / "instrument.instprm"
    inst_path.write_text(instrument_text())

    G2.SetPrintLevel("warn")
    proj = G2.G2Project(newgpx=str(gpx))
    hist = proj.add_powder_histogram(
        str(PATTERN), str(inst_path), fmthint="comma/tab/semicolon"
    )
    phase = proj.add_phase(
        str(SOURCE_CIF), phasename="CaWO4_scheelite", histograms=[hist], fmthint="CIF"
    )

    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    nbg = args.background_terms
    hist.set_refinements(
        {
            "Limits": [float(np.loadtxt(PATTERN, delimiter=",", skiprows=1)[0, 0]),
                       float(np.loadtxt(PATTERN, delimiter=",", skiprows=1)[-1, 0])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": nbg,
                "coeffs": initial_background(nbg),
                "refine": True,
            },
        }
    )

    # The generator uses one isotropic Uiso per phase. Start all sites at the
    # same physically plausible value; equality is added before U refinement.
    for atom in phase.atoms():
        atom.uiso = 0.01

    phase.HAPvalue("Scale", 1.0)
    phase.setSampleProfile(hist, "size", "isotropic", 1.0)
    phase.setSampleProfile(hist, "micro", "isotropic", 500.0)
    phase.set_HAP_refinements({"Scale": True})

    reports: list[dict] = []
    proj.save()
    reports.append(snapshot(proj, "initial"))

    run_refine(proj, "scale_background", reports, 8)

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refine(proj, "cell_zero", reports, 8)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_refine(proj, "cell_zero_shift", reports, 8)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run_refine(proj, "instrument_profile", reports, 10)

    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }
    )
    run_refine(proj, "sample_broadening", reports, 10)

    # Refine the only positional degrees of freedom (the general O site), and
    # one common phase Uiso. Ca and W positions are fixed special positions.
    oxygen_labels = [a.label for a in phase.atoms() if a.element == "O"]
    if len(oxygen_labels) != 1:
        raise RuntimeError(f"Expected one independent oxygen site, got {oxygen_labels}")
    phase.set_refinements({"Atoms": {oxygen_labels[0]: "X", "all": "U"}})
    # set_refinements with 'all' overwrites O's X flag, so restore XU.
    phase.atom(oxygen_labels[0]).refinement_flags = "XU"
    proj.add_EquivConstr(tuple(f"0::AUiso:{i}" for i, _ in enumerate(phase.atoms())))
    run_refine(proj, "oxygen_common_uiso", reports, 12)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    run_refine(proj, "polarization", reports, 10)

    proj.save()
    phase.export_CIF(str(out / "trial.cif"))
    arrays = hist.data["data"][1]
    np.savetxt(
        out / "trial_fit.csv",
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[1] - arrays[3], arrays[4])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
        fmt="%.10g",
    )
    (out / "diagnostics.json").write_text(json.dumps(reports, indent=2) + "\n")


def clone(args: argparse.Namespace) -> None:
    src = Path(args.source).resolve()
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    dst = out / "trial.gpx"
    shutil.copy2(src, dst)
    G2.SetPrintLevel("warn")
    proj = G2.G2Project(gpxfile=str(dst))
    hist = proj.histograms()[0]
    phase = proj.phases()[0]
    # Keep a single intensity scale (the HAP phase scale) in one-phase fits.
    hist.SampleParameters["Scale"][1] = False
    if args.neyman:
        arrays = hist.data["data"][1]
        arrays[2][:] = 1.0 / np.maximum(np.asarray(arrays[1], float), 1.0)
    reports = [snapshot(proj, "clone_initial")]

    if args.simplify:
        hap = phase.data["Histograms"][hist.name]
        # Profile decomposition is non-identifiable: GSAS-II's instrumental X
        # and isotropic-size terms have the same angular dependence. Preserve
        # the fitted size value but refine only X. The refined microstrain is
        # statistically zero; fix it to zero and retain the simpler model.
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hist.SampleParameters["SurfRoughA"] = [0.0, False]
        hist.SampleParameters["SurfRoughB"] = [0.0, False]

    if args.orientation_axis:
        axis = [int(v) for v in args.orientation_axis.split(",")]
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = axis
        phase.set_HAP_refinements({"Pref.Ori.": True})
    if args.roughness:
        hist.SampleParameters["SurfRoughA"] = [0.3, True]
        hist.SampleParameters["SurfRoughB"] = [0.08, True]
    if args.strain_axis:
        axis = [int(v) for v in args.strain_axis.split(",")]
        hap = phase.data["Histograms"][hist.name]
        current = max(float(hap["Mustrain"][1][0]), 100.0)
        phase.setSampleProfile(hist, "micro", "uniaxial", current, current, axis)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}}
        )
    if args.background_terms:
        old = hist.Background[0]
        coeffs = list(map(float, old[3:]))
        coeffs.extend([0.0] * max(0, args.background_terms - len(coeffs)))
        hist.set_refinements(
            {"Background": {"type": "chebyschev-1", "no. coeffs": args.background_terms,
                            "coeffs": coeffs[:args.background_terms], "refine": True}}
        )

    run_refine(proj, "variant", reports, 15)
    for i in range(args.pearson_iterations):
        arrays = hist.data["data"][1]
        arrays[2][:] = 1.0 / np.maximum(np.asarray(arrays[3], float), 1.0)
        run_refine(proj, f"pearson_irls_{i + 1}", reports, 12)
    proj.save()
    phase.export_CIF(str(out / "trial.cif"))
    arrays = hist.data["data"][1]
    np.savetxt(
        out / "trial_fit.csv",
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[1] - arrays[3], arrays[4])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
        fmt="%.10g",
    )
    (out / "diagnostics.json").write_text(json.dumps(reports, indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("build")
    p.add_argument("--out", default=str(ROOT / ".tmp" / "refine" / "base"))
    p.add_argument("--background-terms", type=int, default=14)
    p.set_defaults(func=build)

    p = sub.add_parser("clone")
    p.add_argument("source")
    p.add_argument("--out", required=True)
    p.add_argument("--orientation-axis")
    p.add_argument("--strain-axis")
    p.add_argument("--roughness", action="store_true")
    p.add_argument("--simplify", action="store_true")
    p.add_argument("--background-terms", type=int)
    p.add_argument("--pearson-iterations", type=int, default=0)
    p.add_argument("--neyman", action="store_true")
    p.set_defaults(func=clone)
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
