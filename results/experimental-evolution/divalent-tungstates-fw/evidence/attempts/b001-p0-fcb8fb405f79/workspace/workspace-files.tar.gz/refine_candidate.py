#!/usr/bin/env python3
"""Apply the selected physical effects and atomic refinement to one candidate."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def snapshot(project, stage: str) -> dict:
    hist = project.histogram(0)
    return {
        "stage": stage,
        "rwp": float(hist.get_wR()),
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "atoms": {
            phase.name: [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": list(atom.coordinates),
                    "uiso": float(atom.uiso),
                }
                for atom in phase.atoms()
            ]
            for phase in project.phases()
        },
    }


def main() -> None:
    G2.SetPrintLevel("warn")
    source_id = sys.argv[1]
    base = ROOT / f".tmp/three_phase_screens/{source_id}/screen.gpx"
    directory = ROOT / f".tmp/candidate_refinements/{source_id}"
    directory.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(base), newgpx=str(directory / "refined.gpx"))
    hist = project.histogram(0)
    phases = project.phases()
    project.set_Controls("cycles", 15)

    # Effects established independently from the residual signatures.
    hist.SampleParameters["SurfRoughA"] = [0.20, False]
    hist.SampleParameters["SurfRoughB"] = [0.14, True]
    hist.SampleParameters["Shift"] = [0.0, True]
    hist.InstrumentParameters["Zero"][2] = False
    wo3_po = phases[1].data["Histograms"][hist.name]["Pref.Ori."]
    wo3_po[0] = "MD"
    wo3_po[1] = 0.82
    wo3_po[2] = True
    wo3_po[3] = [0, 0, 1]
    ca3_po = phases[2].data["Histograms"][hist.name]["Pref.Ori."]
    ca3_po[1] = 1.0
    ca3_po[2] = False
    project.refine()
    project.save(directory / "stage_effects.gpx")
    history = [snapshot(project, "effects")]
    print(source_id, "effects", history[-1]["rwp"], flush=True)

    project.update_ids()
    for phase in phases:
        variables = []
        for atom_index, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "U"
            variable = f"{phase.id}::AUiso:{atom_index}"
            variables.append(variable)
            project.set_Controls("parmMin", variable=variable, value=0.001)
            project.set_Controls("parmMax", variable=variable, value=0.05)
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
    project.refine()
    project.save(directory / "stage_uiso.gpx")
    history.append(snapshot(project, "common_uiso"))
    print(source_id, "uiso", history[-1]["rwp"], flush=True)

    for phase_index, phase in enumerate(phases):
        for atom in phase.atoms():
            atom.refinement_flags = "XU"
        project.refine()
        project.save(directory / f"stage_coords_{phase_index}.gpx")
        history.append(snapshot(project, f"coordinates_{phase.name}"))
        print(source_id, history[-1]["stage"], history[-1]["rwp"], flush=True)

    project.save(directory / "refined.gpx")
    (directory / "summary.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
