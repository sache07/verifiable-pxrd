#!/usr/bin/env python3
"""Rietveld-screen monoclinic WO3 references against the observed pattern."""

from pathlib import Path
import json
import traceback

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
MODELS = TMP / "models"
WO3_IDS = ["1010618", "1528915", "1563541", "2311041", "2106293", "2107312"]


def write_inputs() -> tuple[Path, Path]:
    data = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    xye = TMP / "pattern.xye"
    np.savetxt(xye, np.column_stack((data, np.sqrt(np.maximum(data[:, 1], 1.0)))), fmt="%.8f %.8f %.8f")
    inst = TMP / "screen.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file; initial laboratory Cu Ka profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.10;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def set_limits(project: G2.G2Project, hist, phases) -> None:
    limits = [
        ("parmMin", f":{hist.id}:U", 0.0),
        ("parmMin", f":{hist.id}:W", 0.0),
        ("parmMin", f":{hist.id}:X", 0.0),
        ("parmMin", f":{hist.id}:SH/L", 0.001),
        ("parmMax", f":{hist.id}:SH/L", 0.2),
        ("parmMin", f":{hist.id}:Polariz.", 0.0),
        ("parmMax", f":{hist.id}:Polariz.", 1.0),
    ]
    for phase in phases:
        limits.append(("parmMin", f"{phase.id}:{hist.id}:Scale", 0.0))
        limits.append(("parmMin", f"{phase.id}:{hist.id}:Size;i", 0.01))
        limits.append(("parmMin", f"{phase.id}:{hist.id}:Mustrain;i", 0.0))
    for control, variable, value in limits:
        try:
            project.set_Controls(control, variable=variable, value=value)
        except Exception:
            pass


def fit_one(cod_id: str, xye: Path, inst: Path) -> dict:
    out = TMP / "screens" / cod_id
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(out / "screen.gpx"))
    phases = [
        project.add_phase(str(MODELS / "7219229.cif"), phasename="CaWO4_scheelite", fmthint="CIF"),
        project.add_phase(str(MODELS / f"{cod_id}.cif"), phasename=f"WO3_{cod_id}", fmthint="CIF"),
        project.add_phase(str(MODELS / "1563196.cif"), phasename="CaO", fmthint="CIF"),
    ]
    hist = project.add_powder_histogram(str(xye), str(inst), phases=phases, fmthint="xye")
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.2, False]
    hist.SampleParameters["SurfRoughB"] = [0.1, False]
    hist.set_refinements({
        "Limits": [float(np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)[0, 0]), 100.08],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 14,
            "coeffs": [900.0] + [0.0] * 13,
            "refine": True,
        },
    })
    for phase in phases:
        phase.setSampleProfile(hist, "size", "isotropic", 0.5)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0)
        phase.set_HAP_refinements({"Scale": True}, [hist])
    project.update_ids()
    set_limits(project, hist, phases)
    project.set_Controls("cycles", 8)

    history = []

    def refine(label: str) -> None:
        project.refine()
        history.append({"stage": label, "rwp": float(hist.get_wR()), "residuals": dict(hist.residuals)})

    refine("background_scales")
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]})
    refine("cells_positions")
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine("instrument")
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    refine("phase_profiles")
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine("polarization")
    project.save()

    masses = hist.ComputeMassFracs()
    result = {
        "cod_id": cod_id,
        "rwp": float(hist.get_wR()),
        "history": history,
        "mass_fractions": {k: list(v) for k, v in masses.items()},
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "scales": {phase.name: phase.HAPvalue("Scale", targethistlist=[hist]) for phase in phases},
        "instrument": {k: v for k, v in hist.InstrumentParameters.items() if k in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]},
        "sample": {k: hist.SampleParameters[k] for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "profiles": {
            phase.name: {
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in phases
        },
    }
    (out / "summary.json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    return result


def main() -> None:
    G2.SetPrintLevel("warn")
    (TMP / "screens").mkdir(parents=True, exist_ok=True)
    xye, inst = write_inputs()
    results = []
    for cod_id in WO3_IDS:
        try:
            result = fit_one(cod_id, xye, inst)
            results.append(result)
            print(cod_id, "Rwp", result["rwp"], "fractions", result["mass_fractions"], flush=True)
        except Exception as exc:
            print(cod_id, "FAILED", repr(exc), flush=True)
            traceback.print_exc()
            results.append({"cod_id": cod_id, "error": repr(exc)})
    (TMP / "screens" / "summary.json").write_text(json.dumps(results, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
