#!/usr/bin/env python3
"""Profile the poorly separated surface-roughness A parameter."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp/atom_refinement/refined.gpx"
VALUES = [0.05, 0.10, 0.20, 0.35, 0.50, 0.60]


def main() -> None:
    G2.SetPrintLevel("warn")
    directory = ROOT / ".tmp/surface_a_tests"
    directory.mkdir(parents=True, exist_ok=True)
    rows = []
    for index, value in enumerate(VALUES):
        project = G2.G2Project(gpxfile=str(BASE), newgpx=str(directory / f"a_{index}.gpx"))
        hist = project.histogram(0)
        hist.SampleParameters["SurfRoughA"] = [value, False]
        hist.SampleParameters["SurfRoughB"] = [0.10, True]
        project.set_Controls("cycles", 15)
        project.set_Frozen(variable=f":{hist.id}:SurfRoughB")
        project.refine()
        project.save()
        row = {
            "A": value,
            "B": float(hist.SampleParameters["SurfRoughB"][0]),
            "rwp": float(hist.get_wR()),
            "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        }
        rows.append(row)
        print(row, flush=True)
    (directory / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
