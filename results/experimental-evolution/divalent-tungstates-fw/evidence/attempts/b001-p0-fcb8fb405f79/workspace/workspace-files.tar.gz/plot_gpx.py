#!/usr/bin/env python3
"""Extract a GSAS-II powder fit and print the largest residual regions."""

from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import gaussian_filter1d
from GSASII import GSASIIscriptable as G2


def main() -> None:
    gpx = Path(sys.argv[1])
    output = Path(sys.argv[2])
    project = G2.G2Project(gpxfile=str(gpx))
    hist = project.histogram(0)
    x, observed, weight, calculated, background, difference = map(
        np.asarray, hist.data["data"][1][:6]
    )
    smooth = gaussian_filter1d(difference / np.sqrt(np.maximum(observed, 1.0)), 3)
    peaks = np.argsort(np.abs(smooth))[::-1]
    chosen = []
    for index in peaks:
        if all(abs(x[index] - angle) > 0.20 for angle in chosen):
            chosen.append(float(x[index]))
        if len(chosen) == 30:
            break
    print("Rwp", hist.get_wR())
    print("largest standardized residual regions")
    for angle in chosen:
        i = int(np.argmin(abs(x - angle)))
        print(f"{x[i]:9.4f} obs={observed[i]:9.2f} calc={calculated[i]:9.2f} "
              f"diff={difference[i]:9.2f} z_smooth={smooth[i]:8.2f}")

    np.savez_compressed(
        output,
        x=x,
        observed=observed,
        calculated=calculated,
        difference=difference,
        background=background,
        smooth=smooth,
    )


if __name__ == "__main__":
    main()
