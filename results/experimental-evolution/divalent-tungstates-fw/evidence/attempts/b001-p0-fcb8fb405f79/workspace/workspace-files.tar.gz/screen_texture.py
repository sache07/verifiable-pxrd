#!/usr/bin/env python3
"""Screen March-Dollase axes for one phase in the leading refinement."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp/surface_tests/start_0.gpx"
AXES = [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]


def main() -> None:
    G2.SetPrintLevel("warn")
    phase_index = int(sys.argv[1])
    base = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else BASE
    rows = []
    directory = ROOT / f".tmp/texture_tests/phase_{phase_index}"
    directory.mkdir(parents=True, exist_ok=True)
    for index, axis in enumerate(AXES):
        output = directory / f"axis_{index}.gpx"
        project = G2.G2Project(gpxfile=str(base), newgpx=str(output))
        hist = project.histogram(0)
        phase = project.phase(phase_index)
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = axis
        project.set_Controls("cycles", 12)
        project.update_ids()
        project.set_Controls("parmMin", variable=f"{phase.id}:{hist.id}:MD", value=0.5)
        project.set_Controls("parmMax", variable=f"{phase.id}:{hist.id}:MD", value=2.0)
        project.refine()
        project.save()
        row = {
            "axis": axis,
            "rwp": float(hist.get_wR()),
            "ratio": float(po[1]),
            "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        }
        rows.append(row)
        print(row, flush=True)
    (directory / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
