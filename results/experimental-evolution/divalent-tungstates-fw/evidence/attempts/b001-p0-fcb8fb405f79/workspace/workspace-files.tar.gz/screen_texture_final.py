#!/usr/bin/env python3
"""Screen the five generator-supported March-Dollase axes on a mature model."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


AXES = [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]


def main() -> None:
    G2.SetPrintLevel("warn")
    source = Path(sys.argv[1]).resolve()
    phase_index = int(sys.argv[2])
    directory = Path(sys.argv[3]).resolve()
    directory.mkdir(parents=True, exist_ok=True)
    rows = []
    for index, axis in enumerate(AXES):
        output = directory / f"axis_{index}.gpx"
        project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
        project.data["Controls"]["data"]["max cyc"] = 25
        project.data["Controls"]["data"]["min dM/M"] = 1e-5
        hist = project.histogram(0)
        phase = project.phases()[phase_index]
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = axis
        project.set_Controls("parmMin", variable=f"{phase.id}:{hist.id}:MD", value=0.7)
        project.set_Controls("parmMax", variable=f"{phase.id}:{hist.id}:MD", value=1.4)
        project.refine()
        project.save(output)
        row = {
            "axis": axis,
            "rwp": float(hist.get_wR()),
            "ratio": float(po[1]),
            "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
            "rvals": project.data["Covariance"]["data"].get("Rvals", {}),
        }
        rows.append(row)
        print(phase_index, axis, row["rwp"], row["ratio"], flush=True)
    (directory / "summary.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
