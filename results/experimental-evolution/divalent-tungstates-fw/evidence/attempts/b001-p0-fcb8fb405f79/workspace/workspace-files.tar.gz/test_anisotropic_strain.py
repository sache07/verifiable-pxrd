#!/usr/bin/env python3
"""Test generator-supported uniaxial microstrain axes for the third phase."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


def run(source: Path, output: Path, axis: list[int] | None) -> dict:
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    project.data["Controls"]["data"]["max cyc"] = 25
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.histogram(0)
    phase = project.phases()[2]
    hap = phase.data["Histograms"][hist.name]
    strain = float(hap["Mustrain"][1][0])
    if axis is None:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][1] = strain
        hap["Mustrain"][2] = [True, False, False]
    else:
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][1] = strain
        hap["Mustrain"][2] = [True, True, False]
        hap["Mustrain"][3] = axis
        project.set_Controls(
            "parmMin", variable=f"{phase.id}:{hist.id}:Mustrain;a", value=0.0
        )
        project.set_Controls(
            "parmMax", variable=f"{phase.id}:{hist.id}:Mustrain;a", value=10000.0
        )
    project.refine()
    project.save(output)
    result = {
        "axis": axis,
        "rwp": float(hist.get_wR()),
        "mustrain": hap["Mustrain"],
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "rvals": project.data["Covariance"]["data"].get("Rvals", {}),
    }
    return result


def main() -> None:
    G2.SetPrintLevel("warn")
    source = Path(sys.argv[1]).resolve()
    directory = Path(sys.argv[2]).resolve()
    cases = [("isotropic", None), ("001", [0, 0, 1]), ("100", [1, 0, 0]), ("010", [0, 1, 0])]
    results = []
    for name, axis in cases:
        result = run(source, directory / f"{name}.gpx", axis)
        results.append(result)
        print(name, result["rwp"], result["mustrain"][:4], flush=True)
    (directory / "summary.json").write_text(json.dumps(results, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
