#!/usr/bin/env python3
"""Stable three-phase screens for analogue-derived Ca3WO6 models."""

from pathlib import Path
import json
import sys
import traceback

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
MODELS = TMP / "models"
DEFAULT_IDS = ["1532958", "1563083", "4002545", "2104688"]
BASE_BACKGROUND = [
    863.9303570869113,
    -584.6489309250696,
    269.8930082655079,
    -121.15102673530448,
    41.240970667233256,
    -19.75349309442655,
    -3.540027834413986,
    -19.971768332672344,
    19.845689601621125,
    -17.116634650921647,
    13.55008818262686,
    -6.201939178683677,
    23.72186843513974,
    -11.178718689366834,
]


def ensure_inputs() -> tuple[Path, Path]:
    data = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    xye = TMP / "pattern.xye"
    if not xye.exists():
        np.savetxt(
            xye,
            np.column_stack((data, np.sqrt(np.maximum(data[:, 1], 1.0)))),
            fmt="%.8f %.8f %.8f",
        )
    inst = TMP / "three_phase.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file; laboratory Cu Ka profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.125;Polariz.:0.70;Azimuth:0.0\n"
        "U:5.0;V:0.0;W:8.0;X:3.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return xye, inst


def control_limit(project, kind: str, name: str, value: float) -> None:
    try:
        project.set_Controls(kind, variable=name, value=value)
    except Exception:
        pass


def fit_one(source_id: str, xye: Path, inst: Path) -> dict:
    out = TMP / "three_phase_screens" / source_id
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(out / "screen.gpx"))
    phases = [
        project.add_phase(str(MODELS / "7219229.cif"), phasename="CaWO4", fmthint="CIF"),
        project.add_phase(str(MODELS / "2311041.cif"), phasename="WO3", fmthint="CIF"),
        project.add_phase(
            str(MODELS / f"Ca3WO6_from_{source_id}_scaled.cif"),
            phasename=f"Ca3WO6_from_{source_id}",
            fmthint="CIF",
        ),
    ]
    hist = project.add_powder_histogram(str(xye), str(inst), phases=phases, fmthint="xye")
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [9.90343322, 100.08],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(BASE_BACKGROUND),
                "coeffs": BASE_BACKGROUND,
                "refine": True,
            },
        }
    )

    initial_scales = [38.0, 5.4, 5.0]
    initial_profiles = [(0.35, 500.0), (0.15, 1000.0), (0.25, 1000.0)]
    for phase, scale, (size, strain) in zip(phases, initial_scales, initial_profiles):
        phase.HAPvalue("Scale", scale, targethistlist=[hist])
        phase.setSampleProfile(hist, "size", "isotropic", size)
        phase.setSampleProfile(hist, "microstrain", "isotropic", strain)
        phase.set_HAP_refinements({"Scale": True}, [hist])

    project.update_ids()
    project.set_Controls("cycles", 10)
    for phase in phases:
        control_limit(project, "parmMin", f"{phase.id}:{hist.id}:Scale", 0.0)
        control_limit(project, "parmMin", f"{phase.id}:{hist.id}:Size;i", 0.02)
        control_limit(project, "parmMax", f"{phase.id}:{hist.id}:Size;i", 10.0)
        control_limit(project, "parmMin", f"{phase.id}:{hist.id}:Mustrain;i", 0.0)
        control_limit(project, "parmMax", f"{phase.id}:{hist.id}:Mustrain;i", 10000.0)
    for key, low, high in [("U", 0.0, 40.0), ("W", 0.0, 40.0), ("X", 0.0, 10.0), ("SH/L", 0.001, 0.2)]:
        control_limit(project, "parmMin", f":{hist.id}:{key}", low)
        control_limit(project, "parmMax", f":{hist.id}:{key}", high)

    history = []

    def refine(label: str) -> None:
        project.refine()
        history.append({"stage": label, "rwp": float(hist.get_wR())})

    refine("scales_background")
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine("cells_zero")
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine("instrument")
    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    refine("size")
    for phase in phases:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    refine("microstrain")
    project.save()

    result = {
        "source_id": source_id,
        "rwp": float(hist.get_wR()),
        "history": history,
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "instrument": {k: hist.InstrumentParameters[k] for k in ["Zero", "U", "W", "X", "SH/L"]},
        "profiles": {
            phase.name: {
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in phases
        },
    }
    (out / "summary.json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    return result


def main() -> None:
    G2.SetPrintLevel("warn")
    ids = sys.argv[1:] or DEFAULT_IDS
    (TMP / "three_phase_screens").mkdir(parents=True, exist_ok=True)
    xye, inst = ensure_inputs()
    results = []
    for source_id in ids:
        try:
            result = fit_one(source_id, xye, inst)
            results.append(result)
            print(source_id, "Rwp", result["rwp"], "fractions", result["fractions"], flush=True)
        except Exception as exc:
            traceback.print_exc()
            results.append({"source_id": source_id, "error": repr(exc)})
    (TMP / "three_phase_screens/summary.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    main()
