#!/usr/bin/env python3
"""Freeze the selected project, export its CIFs, and record exact model values."""

from pathlib import Path
import json
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
CIF_NAMES = ["CaWO4.cif", "WO3.cif", "Ca3WO6.cif"]


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def main() -> None:
    G2.SetPrintLevel("warn")
    source = Path(sys.argv[1]).resolve()
    final = ROOT / "final.gpx"
    project = G2.G2Project(gpxfile=str(source), newgpx=str(final))
    project.save(final)
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    report = {
        "source_project": str(source),
        "final_project": str(final),
        "histogram": hist.name,
        "histogram_count": len(project.histograms()),
        "phase_count": len(project.phases()),
        "saved_rwp_percent": float(hist.get_wR()),
        "rvals": plain(rvals),
        "phases": [],
        "instrument": plain(hist.InstrumentParameters),
        "sample": plain(hist.SampleParameters),
        "background": plain(hist.data["Background"]),
    }
    if len(project.phases()) != len(CIF_NAMES):
        raise RuntimeError("Expected exactly three phases")
    # Export directly from the saved atoms. Suppressing the covariance table
    # avoids attaching stale e.s.d. values to the otherwise exact CIF export.
    project.data["Covariance"]["data"] = {}
    for phase, filename in zip(project.phases(), CIF_NAMES):
        path = ROOT / filename
        phase.export_CIF(str(path))
        report["phases"].append(
            {
                "project_name": phase.name,
                "cif": filename,
                "weight_fraction": float(fractions[phase.name][0]),
                "weight_fraction_esd": float(fractions[phase.name][1]),
                "cell": phase.get_cell(),
                "histogram_parameters": plain(
                    phase.data["Histograms"][hist.name]
                ),
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": list(atom.coordinates),
                        "occupancy": float(atom.occupancy),
                        "uiso_A2": float(atom.uiso),
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    summary = ROOT / ".tmp/final_summary.json"
    summary.parent.mkdir(parents=True, exist_ok=True)
    summary.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(json.dumps(report, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
