#!/usr/bin/env python3
"""Refine the effective incident-beam polarization on a project copy."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


def main() -> None:
    G2.SetPrintLevel("warn")
    source, output = map(Path, sys.argv[1:3])
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source.resolve()), newgpx=str(output.resolve()))
    project.data["Controls"]["data"]["max cyc"] = 30
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.histogram(0)
    hist.InstrumentParameters["Polariz."][2] = True
    project.set_Controls("parmMin", variable=f":{hist.id}:Polariz.", value=0.5)
    project.set_Controls("parmMax", variable=f":{hist.id}:Polariz.", value=1.0)
    project.refine()
    project.save(output.resolve())
    report = {
        "rwp": float(hist.get_wR()),
        "polarization": hist.InstrumentParameters["Polariz."],
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "rvals": project.data["Covariance"]["data"].get("Rvals", {}),
    }
    output.with_suffix(".json").write_text(json.dumps(report, indent=2, default=str) + "\n")
    print(json.dumps(report, indent=2, default=str))


if __name__ == "__main__":
    main()
