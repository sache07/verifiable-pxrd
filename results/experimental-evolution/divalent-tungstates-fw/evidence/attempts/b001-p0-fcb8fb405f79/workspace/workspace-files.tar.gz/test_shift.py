#!/usr/bin/env python3
"""Test Bragg-Brentano specimen displacement after texture selection."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp/texture_tests/phase_1/axis_0.gpx"


def main() -> None:
    G2.SetPrintLevel("warn")
    rows = []
    directory = ROOT / ".tmp/shift_tests"
    directory.mkdir(parents=True, exist_ok=True)
    for refine_zero in [False, True]:
        tag = "shift_zero" if refine_zero else "shift_only"
        project = G2.G2Project(gpxfile=str(BASE), newgpx=str(directory / f"{tag}.gpx"))
        hist = project.histogram(0)
        hist.SampleParameters["Shift"] = [0.0, True]
        hist.InstrumentParameters["Zero"][2] = refine_zero
        project.set_Controls("cycles", 15)
        project.set_Controls("parmMin", variable=f":{hist.id}:Shift", value=-1000.0)
        project.set_Controls("parmMax", variable=f":{hist.id}:Shift", value=1000.0)
        project.refine()
        project.save()
        row = {
            "mode": tag,
            "rwp": float(hist.get_wR()),
            "zero": hist.InstrumentParameters["Zero"],
            "shift": hist.SampleParameters["Shift"],
            "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        }
        rows.append(row)
        print(row, flush=True)
    (directory / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
