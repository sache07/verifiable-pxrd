#!/usr/bin/env python3
"""Test Suortti surface-roughness starts on the leading three-phase model."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp/three_phase_screens/2104688/screen.gpx"
STARTS = [(0.10, 0.03), (0.30, 0.10), (0.50, 0.25)]


def main() -> None:
    G2.SetPrintLevel("warn")
    rows = []
    for index, (a, b) in enumerate(STARTS):
        out = ROOT / f".tmp/surface_tests/start_{index}.gpx"
        out.parent.mkdir(parents=True, exist_ok=True)
        project = G2.G2Project(gpxfile=str(BASE), newgpx=str(out))
        hist = project.histogram(0)
        hist.SampleParameters["SurfRoughA"] = [a, True]
        hist.SampleParameters["SurfRoughB"] = [b, True]
        project.set_Controls("cycles", 12)
        project.set_Controls("parmMin", variable=f":{hist.id}:SurfRoughA", value=0.001)
        project.set_Controls("parmMax", variable=f":{hist.id}:SurfRoughA", value=0.95)
        project.set_Controls("parmMin", variable=f":{hist.id}:SurfRoughB", value=0.001)
        project.set_Controls("parmMax", variable=f":{hist.id}:SurfRoughB", value=2.0)
        project.refine()
        project.save()
        row = {
            "start": [a, b],
            "rwp": float(hist.get_wR()),
            "surface": {
                "A": hist.SampleParameters["SurfRoughA"],
                "B": hist.SampleParameters["SurfRoughB"],
            },
            "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        }
        rows.append(row)
        print(row, flush=True)
    (ROOT / ".tmp/surface_tests/summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
