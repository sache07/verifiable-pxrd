#!/usr/bin/env python3
"""Screen analogue-derived Ca3WO6 double-perovskite models in GSAS-II."""

from pathlib import Path
import json
import sys
import traceback

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
BASE = TMP / "screens/2311041/screen.gpx"
DEFAULT_IDS = ["1532958", "1563083", "4002545", "2104688"]


def clear_profile_flags(hap: dict) -> None:
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def fit_one(source_id: str) -> dict:
    out = TMP / "ca3_screens" / source_id
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(out / "screen.gpx"))
    hist = project.histogram(0)

    # Collapse the highly correlated previous zero/shift result into one angular
    # correction before introducing the missing phase.
    hist.InstrumentParameters["Zero"][1] = -0.125
    hist.InstrumentParameters["Zero"][2] = False
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.InstrumentParameters["Polariz."][2] = False
    for key in ["U", "W", "X", "SH/L"]:
        hist.InstrumentParameters[key][2] = False

    phases = project.phases()
    for phase in phases:
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        clear_profile_flags(hap)

    candidate = project.add_phase(
        str(TMP / "models" / f"Ca3WO6_from_{source_id}_scaled.cif"),
        phasename=f"Ca3WO6_from_{source_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    phases = project.phases()
    candidate.setSampleProfile(hist, "size", "isotropic", 0.25)
    candidate.setSampleProfile(hist, "microstrain", "isotropic", 1000.0)
    candidate.HAPvalue("Scale", 4.0, targethistlist=[hist])
    candidate.set_HAP_refinements({"Scale": True}, [hist])
    candidate.data["General"]["Cell"][0] = False
    clear_profile_flags(candidate.data["Histograms"][hist.name])

    hist.data["Background"][0][1] = True
    project.set_Controls("cycles", 8)
    project.update_ids()
    for phase in phases:
        try:
            project.set_Controls("parmMin", variable=f"{phase.id}:{hist.id}:Scale", value=0.0)
        except Exception:
            pass

    history = []

    def refine(label: str) -> None:
        project.refine()
        history.append({"stage": label, "rwp": float(hist.get_wR())})

    refine("add_scale")
    for phase in phases:
        phase.data["General"]["Cell"][0] = True
    hist.InstrumentParameters["Zero"][2] = True
    refine("cells_zero")

    for key in ["U", "W", "X", "SH/L"]:
        hist.InstrumentParameters[key][2] = True
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    refine("profiles")
    project.save()

    result = {
        "source_id": source_id,
        "rwp": float(hist.get_wR()),
        "history": history,
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "instrument": {k: hist.InstrumentParameters[k] for k in ["Zero", "U", "W", "X", "SH/L"]},
    }
    (out / "summary.json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    return result


def main() -> None:
    G2.SetPrintLevel("warn")
    ids = sys.argv[1:] or DEFAULT_IDS
    (TMP / "ca3_screens").mkdir(parents=True, exist_ok=True)
    results = []
    for source_id in ids:
        try:
            result = fit_one(source_id)
            results.append(result)
            print(source_id, "Rwp", result["rwp"], "fractions", result["fractions"], flush=True)
        except Exception as exc:
            traceback.print_exc()
            results.append({"source_id": source_id, "error": repr(exc)})
    (TMP / "ca3_screens/summary.json").write_text(json.dumps(results, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
