#!/usr/bin/env python3
"""Export each phase from a saved GSAS-II project without changing it."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def main() -> None:
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    output.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source))
    project.data["Covariance"]["data"] = {}
    for index, phase in enumerate(project.phases()):
        path = output / f"phase_{index}.cif"
        phase.export_CIF(str(path))
        print(index, phase.name, path)


if __name__ == "__main__":
    main()
