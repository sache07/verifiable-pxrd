#!/usr/bin/env python3
"""Print the profile and specimen state of a GSAS-II project."""

from pathlib import Path
from pprint import pprint
import sys

from GSASII import GSASIIscriptable as G2


def main() -> None:
    project = G2.G2Project(gpxfile=str(Path(sys.argv[1])))
    hist = project.histogram(0)
    print("histogram", hist.name, "Rwp", hist.get_wR())
    print("limits")
    pprint(hist.data.get("Limits"))
    print("instrument")
    pprint(hist.InstrumentParameters)
    print("sample")
    pprint(hist.SampleParameters)
    print("background")
    pprint(hist.data.get("Background"))
    for phase in project.phases():
        print("phase", phase.name, "id", phase.id)
        print("cell", phase.get_cell())
        print("HAP")
        pprint(phase.data["Histograms"][hist.name])
    print("controls")
    pprint(project.data.get("Controls"))
    print("covariance keys")
    pprint(project.data.get("Covariance", {}).get("data", {}).keys())
    pprint(project.data.get("Covariance", {}).get("data", {}).get("Rvals"))


if __name__ == "__main__":
    main()
