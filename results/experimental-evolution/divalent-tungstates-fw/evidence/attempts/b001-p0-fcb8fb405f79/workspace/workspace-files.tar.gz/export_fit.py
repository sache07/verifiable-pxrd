#!/usr/bin/env python3
"""Write the independently replayed full-grid profile to fit.csv."""

from pathlib import Path
import json
import sys

import numpy as np


def main() -> None:
    prediction = Path(sys.argv[1])
    output = Path(sys.argv[2])
    with np.load(prediction, allow_pickle=False) as data:
        x = data["x"].copy()
        observed = data["observed"].copy()
        calculated = data["predicted"].copy()
    difference = observed - calculated
    profile = np.column_stack([x, observed, calculated, difference])
    np.savetxt(
        output,
        profile,
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f"],
    )
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    nvars = 80
    stats = {
        "points": int(len(x)),
        "Rwp_percent": float(100 * np.sqrt(chi_square / denominator)),
        "Rp_percent": float(100 * np.sum(np.abs(difference)) / np.sum(observed)),
        "chi_square": chi_square,
        "degrees_of_freedom": int(len(x) - 1 - nvars),
        "reduced_chi_square": float(chi_square / (len(x) - 1 - nvars)),
        "goodness_of_fit": float(np.sqrt(chi_square / (len(x) - 1 - nvars))),
        "difference_convention": "observed - calculated",
    }
    stats_path = output.parent / ".tmp/fit_stats.json"
    stats_path.parent.mkdir(parents=True, exist_ok=True)
    stats_path.write_text(json.dumps(stats, indent=2) + "\n")
    print(json.dumps(stats, indent=2))


if __name__ == "__main__":
    main()
