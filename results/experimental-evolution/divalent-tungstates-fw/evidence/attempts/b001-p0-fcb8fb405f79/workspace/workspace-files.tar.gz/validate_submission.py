#!/usr/bin/env python3
"""Run the public submission parser and project/CIF consistency checks."""

from pathlib import Path
import json
import sys

import numpy as np


ROOT = Path(__file__).resolve().parent
SCORER = ROOT / "learned/divalent-tungstates/scorer/src"
sys.path.insert(0, str(SCORER))

from replay import annotated_structure, model_agrees  # noqa: E402
from structure_metrics import parse_submission  # noqa: E402


def main() -> None:
    submission, rows, notes = parse_submission(ROOT, {"Ca", "W", "O", "H", "C"})
    replay = json.loads((ROOT / ".tmp/replay/replay.json").read_text())
    agreements = []
    for index, phase in enumerate(replay["phases"]):
        native = annotated_structure(ROOT / ".tmp/replay" / phase["cif"])
        submitted = annotated_structure(rows[index]["path"])
        agreements.append(
            {
                "project_phase": phase["name"],
                "submitted_cif": str(rows[index]["path"].relative_to(ROOT)),
                "model_agrees": bool(model_agrees(native, submitted)),
                "fraction_error": float(
                    abs(phase["weight_fraction"] - rows[index]["fraction"])
                ),
                "physical": rows[index]["physical"],
            }
        )
    fit = np.loadtxt(ROOT / "fit.csv", delimiter=",", skiprows=1)
    observed = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    profile_ok = bool(
        fit.shape == (8301, 4)
        and np.array_equal(fit[:, 0], observed[:, 0])
        and np.array_equal(fit[:, 1], observed[:, 1])
        and np.allclose(fit[:, 3], fit[:, 1] - fit[:, 2], rtol=0, atol=2e-10)
    )
    report = {
        "submission_parsing": submission["_submission_parsing"],
        "notes": notes,
        "agreements": agreements,
        "fit_profile_consistent": profile_ok,
    }
    print(json.dumps(report, indent=2, default=str))
    if not profile_ok or not all(row["model_agrees"] for row in agreements):
        raise SystemExit(1)
    if any(row["physical"]["status"] != "pass" for row in agreements):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
