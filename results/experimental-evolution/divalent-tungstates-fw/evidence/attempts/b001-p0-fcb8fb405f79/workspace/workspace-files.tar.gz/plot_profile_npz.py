#!/usr/bin/env python3
"""Plot profile arrays extracted from a GSAS-II project."""

from pathlib import Path
import sys

import matplotlib.pyplot as plt
import numpy as np


def main() -> None:
    arrays = np.load(sys.argv[1])
    output = Path(sys.argv[2])
    x = arrays["x"]
    observed = arrays["observed"]
    calculated = arrays["calculated"]
    difference = arrays["difference"]
    background = arrays["background"]
    smooth = arrays["smooth"]

    fig, axes = plt.subplots(4, 1, figsize=(16, 12), sharex=False)
    for ax, (lo, hi) in zip(axes[:3], [(9.9, 40), (40, 70), (70, 100.1)]):
        mask = (x >= lo) & (x <= hi)
        ax.plot(x[mask], observed[mask], color="black", lw=0.65, label="observed")
        ax.plot(x[mask], calculated[mask], color="tab:red", lw=0.7, label="calculated")
        ax.plot(x[mask], difference[mask], color="tab:blue", lw=0.55, label="difference")
        ax.plot(x[mask], background[mask], color="tab:green", lw=0.5, label="background")
        ax.set_xlim(lo, hi)
        ax.legend(loc="upper right", ncol=4, fontsize=8)
    axes[3].plot(x, smooth, color="tab:purple", lw=0.7)
    axes[3].axhline(0, color="black", lw=0.5)
    axes[3].set_xlim(x[0], x[-1])
    axes[3].set_ylabel("smoothed residual / sqrt(I)")
    axes[3].set_xlabel(r"$2\theta$ (degrees)")
    fig.tight_layout()
    fig.savefig(output, dpi=150)


if __name__ == "__main__":
    main()
