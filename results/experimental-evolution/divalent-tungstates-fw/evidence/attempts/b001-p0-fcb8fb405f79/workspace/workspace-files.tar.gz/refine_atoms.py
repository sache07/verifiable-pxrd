#!/usr/bin/env python3
"""Refine common phase Uiso values and symmetry-constrained coordinates."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp/texture_tests/phase_2/axis_4.gpx"
OUTDIR = ROOT / ".tmp/atom_refinement"


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    row = {
        "stage": label,
        "rwp": float(hist.get_wR()),
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "phases": {},
    }
    for phase in project.phases():
        row["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": list(atom.coordinates),
                    "uiso": float(atom.uiso),
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    return row


def main() -> None:
    G2.SetPrintLevel("warn")
    OUTDIR.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUTDIR / "refined.gpx"))
    project.set_Controls("cycles", 15)
    project.update_ids()
    project.save()
    history = [snapshot(project, "start")]

    # The generator assigns one isotropic displacement value to every site in
    # a phase. Preserve that physically useful equality during refinement.
    for phase in project.phases():
        variables = []
        for atom_index, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "U"
            variable = f"{phase.id}::AUiso:{atom_index}"
            variables.append(variable)
            project.set_Controls("parmMin", variable=variable, value=0.001)
            project.set_Controls("parmMax", variable=variable, value=0.05)
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
    project.refine()
    project.save(OUTDIR / "stage_uiso.gpx")
    history.append(snapshot(project, "common_uiso"))
    print(history[-1]["stage"], history[-1]["rwp"], flush=True)

    for phase_index, phase in enumerate(project.phases()):
        for atom in phase.atoms():
            atom.refinement_flags = "XU"
        project.refine()
        project.save(OUTDIR / f"stage_coords_{phase_index}.gpx")
        history.append(snapshot(project, f"coordinates_{phase.name}"))
        print(history[-1]["stage"], history[-1]["rwp"], flush=True)

    project.save(OUTDIR / "refined.gpx")
    (OUTDIR / "summary.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
