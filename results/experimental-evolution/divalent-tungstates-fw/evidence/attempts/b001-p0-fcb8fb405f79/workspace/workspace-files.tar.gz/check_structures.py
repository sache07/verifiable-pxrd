#!/usr/bin/env python3
"""Report broad physical screens and nearest-neighbour geometry for CIF files."""

from collections import defaultdict
from pathlib import Path
import json
import sys

import numpy as np
from pymatgen.core import Structure


def species(site) -> str:
    return site.specie.symbol


def inspect(path: Path) -> dict:
    structure = Structure.from_file(path)
    n = len(structure)
    matrix = structure.distance_matrix.copy()
    matrix[np.arange(n), np.arange(n)] = np.inf
    pair_min = defaultdict(lambda: np.inf)
    for i in range(n):
        for j in range(i + 1, n):
            key = "-".join(sorted((species(structure[i]), species(structure[j]))))
            pair_min[key] = min(pair_min[key], float(matrix[i, j]))
    environments = []
    seen = set()
    for index, site in enumerate(structure):
        signature = (species(site), tuple(np.round(site.frac_coords, 4)))
        if signature in seen:
            continue
        seen.add(signature)
        oxygen = sorted(
            float(nn.nn_distance)
            for nn in structure.get_neighbors(site, 3.5)
            if species(nn) == "O"
        )
        environments.append(
            {
                "site": f"{species(site)}{index}",
                "nearest_oxygen_A": oxygen[:12],
            }
        )
    return {
        "path": str(path),
        "formula": structure.composition.reduced_formula,
        "density_g_cm3": float(structure.density),
        "sites": n,
        "min_contact_A": float(np.min(matrix)),
        "pair_min_A": dict(sorted(pair_min.items())),
        "physical_screen": {
            "status": "fail"
            if np.min(matrix) < 0.8
            else (
                "needs_adjudication"
                if pair_min.get("O-O", np.inf) < 1.8
                else "pass"
            ),
            "hard_contact_A": 0.8,
            "oxide_oxygen_contact_review_A": 1.8,
        },
        "environments": environments,
    }


def main() -> None:
    print(json.dumps([inspect(Path(arg)) for arg in sys.argv[1:]], indent=2))


if __name__ == "__main__":
    main()
