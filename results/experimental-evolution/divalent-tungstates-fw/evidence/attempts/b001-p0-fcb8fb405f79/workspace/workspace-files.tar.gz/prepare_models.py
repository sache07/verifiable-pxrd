#!/usr/bin/env python3
"""Normalize selected COD models exactly as the synthetic generator does."""

from pathlib import Path
import sys

from pymatgen.io.cif import CifParser


ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/"
    "resources/b001-c05/cif"
)
RUNTIME = Path("learned/divalent-tungstates/runtime").resolve()
sys.path.insert(0, str(RUNTIME))
from models import write_synthetic_model  # noqa: E402


IDS = [
    "7219229",  # scheelite CaWO4
    "5910088",  # alternate scheelite CaWO4 coordinates
    "1546035",  # wolframite-type CaWO4 comparator
    "1563196",  # rock-salt CaO
    "1010618",
    "1521532",
    "1521533",
    "1528915",
    "1563541",
    "2311041",
    "2106293",
    "2107312",
    "2013468",  # Ca2MgWO6 double-perovskite analogue
    "7222332",  # Ca2CoWO6 double-perovskite analogue
    "7222333",  # Ca2NiWO6 double-perovskite analogue
    "4002219",  # Ca2FeMoO6 double-perovskite analogue
    "1536764",  # Sr2CaMoO6 double-perovskite analogue
    "2104688",  # Sr2CaWO6 double-perovskite analogue
    "1532958",  # Sr2MnWO6 double-perovskite analogue
    "4002545",  # Sr2CoWO6 double-perovskite analogue
    "1563083",  # Sr2ZnWO6 double-perovskite analogue
]

SUBSTITUTIONS = {
    "2013468": {"Mg": "Ca"},
    "7222332": {"Co": "Ca"},
    "7222333": {"Ni": "Ca"},
    "4002219": {"Fe": "Ca", "Mo": "W"},
    "1536764": {"Sr": "Ca", "Mo": "W"},
    "2104688": {"Sr": "Ca"},
    "1532958": {"Sr": "Ca", "Mn": "Ca"},
    "4002545": {"Sr": "Ca", "Co": "Ca"},
    "1563083": {"Sr": "Ca", "Zn": "Ca"},
}


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    out = Path(".tmp/models")
    out.mkdir(parents=True, exist_ok=True)
    for cod_id in IDS:
        parser = CifParser(
            cod_path(cod_id),
            occupancy_tolerance=1.0,
            site_tolerance=1e-5,
            frac_tolerance=0,
        )
        structures = parser.parse_structures(primitive=False, on_error="raise")
        if len(structures) != 1:
            raise RuntimeError(f"Expected one model for COD {cod_id}")
        write_synthetic_model(structures[0], out / f"{cod_id}.cif")
        print(cod_id, structures[0].composition.reduced_formula, len(structures[0]))
        if cod_id in SUBSTITUTIONS:
            target = structures[0].copy()
            target.replace_species(SUBSTITUTIONS[cod_id])
            write_synthetic_model(target, out / f"Ca3WO6_from_{cod_id}.cif")
            target.scale_lattice(258.404)
            write_synthetic_model(target, out / f"Ca3WO6_from_{cod_id}_scaled.cif")
            print("  ->", target.composition.reduced_formula)


if __name__ == "__main__":
    main()
