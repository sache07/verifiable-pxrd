#!/usr/bin/env python3
"""Jointly refine global profile terms and common Uiso values."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from physical_refine import freeze_all, fractions


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("target", type=Path)
    parser.add_argument("--cycles", type=int, default=80)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.target.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(args.source))
    project.save(str(args.target))
    project.set_Controls("cycles", args.cycles)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls.setdefault("parmFrozen", {})["FrozenList"] = []
    project.get_Constraints("Phase").clear()
    hist = project.histograms()[0]
    freeze_all(project, hist)

    hist.data["Background"][0][1] = True
    hist.data["Instrument Parameters"][0]["W"][2] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.getHAPvalues(hist)["Scale"][1] = True

    znwo4 = project.phase("ZnWO4").getHAPvalues(hist)
    znwo4["Size"][2][0] = True
    znwo4["Mustrain"][2][0] = True
    wo3 = project.phase("WO3").getHAPvalues(hist)
    wo3["Mustrain"][2][0] = True
    wo3["Pref.Ori."][2] = True

    # The generator's physical lower bound is 0.003 A^2; the WO3 maximum-
    # likelihood estimate reaches that bound, so keep it fixed there.
    for atom in project.phase("WO3").atoms():
        atom.uiso = 0.003
    for phase_index, phase in enumerate(project.phases()):
        if phase.name not in {"ZnWO4", "ZnO"}:
            continue
        atoms = list(phase.atoms())
        for atom in atoms:
            atom.refinement_flags = "U"
        variables = tuple(
            f"{phase_index}::AUiso:{atom_index}" for atom_index in range(len(atoms))
        )
        project.add_EquivConstr(variables, reloadIdx=True, override=True)

    project.refine()
    project.save()
    covariance = project.data.get("Covariance", {}).get("data", {})
    result = {
        "Rwp_percent": hist.get_wR(),
        "fractions": fractions(project, hist),
        "uiso": {
            phase.name: [float(atom.uiso) for atom in phase.atoms()]
            for phase in project.phases()
        },
        "varyList": covariance.get("varyList", []),
        "Rvals": covariance.get("Rvals", {}),
    }
    args.target.with_suffix(".json").write_text(
        json.dumps(result, indent=2, default=str) + "\n"
    )
    print(json.dumps(result, default=str))


if __name__ == "__main__":
    main()
