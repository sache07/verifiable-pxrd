#!/usr/bin/env python3
"""Refine selected atom coordinates in an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from physical_refine import freeze_all


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("target", type=Path)
    parser.add_argument("phase")
    parser.add_argument("labels", help="comma-separated atom labels")
    parser.add_argument("--cycles", type=int, default=16)
    parser.add_argument(
        "--max-step",
        type=float,
        help="optional symmetric bound on each fractional-coordinate shift",
    )
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.target.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(args.source))
    project.save(str(args.target))
    project.set_Controls("cycles", args.cycles)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls.setdefault("parmFrozen", {})["FrozenList"] = []
    project.get_Constraints("Phase").clear()
    hist = project.histograms()[0]
    freeze_all(project, hist)

    phase = project.phase(args.phase)
    wanted = {x.strip() for x in args.labels.split(",") if x.strip()}
    found = set()
    for atom_index, atom in enumerate(phase.atoms()):
        if atom.label not in wanted:
            continue
        found.add(atom.label)
        atom.refinement_flags = "X"
        if args.max_step is not None:
            # Despite the dA prefix, GSAS bounds these variables in absolute
            # fractional coordinates. Unused site-symmetry variables are
            # harmless because only permitted degrees enter varyList.
            for axis, coordinate in zip("xyz", atom.coordinates):
                variable = f"{phase.id}::dA{axis}:{atom_index}"
                controls["parmMinDict"][variable] = coordinate - abs(args.max_step)
                controls["parmMaxDict"][variable] = coordinate + abs(args.max_step)
    if found != wanted:
        raise ValueError(f"Unknown labels for {phase.name}: {sorted(wanted - found)}")

    project.refine()
    # Freeze the coordinates at their refined values. A later whole-pattern
    # refinement will regenerate a fully consistent calculated profile.
    for atom in phase.atoms():
        atom.refinement_flags = " "
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    project.save()

    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "phase": phase.name,
        "selected": sorted(wanted),
        "Rwp_percent": hist.get_wR(),
        "cell": phase.get_cell(),
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": atom.coordinates,
                "uiso": atom.uiso,
            }
            for atom in phase.atoms()
        ],
        "varyList": cov.get("varyList", []),
        "Rvals": cov.get("Rvals", {}),
    }
    args.target.with_suffix(".json").write_text(
        json.dumps(result, indent=2, default=str) + "\n"
    )
    print(json.dumps({"target": str(args.target), **result}, default=str))


if __name__ == "__main__":
    main()
