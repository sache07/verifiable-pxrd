#!/usr/bin/env python3
"""Refine one common isotropic displacement parameter for selected phases."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from physical_refine import freeze_all


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("target", type=Path)
    parser.add_argument("phases", help="comma-separated phase names")
    parser.add_argument("--set", action="append", nargs=2, metavar=("PHASE", "UISO"))
    parser.add_argument("--cycles", type=int, default=40)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.target.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(args.source))
    project.save(str(args.target))
    project.set_Controls("cycles", args.cycles)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls.setdefault("parmFrozen", {})["FrozenList"] = []
    project.get_Constraints("Phase").clear()
    hist = project.histograms()[0]
    freeze_all(project, hist)

    requested = {x.strip() for x in args.phases.split(",") if x.strip()}
    assignments = {name: float(value) for name, value in (args.set or [])}
    known = {phase.name for phase in project.phases()}
    if not requested <= known or not assignments.keys() <= known:
        raise ValueError("Unknown phase name")
    for phase_index, phase in enumerate(project.phases()):
        if phase.name in assignments:
            for atom in phase.atoms():
                atom.uiso = assignments[phase.name]
        if phase.name not in requested:
            continue
        atoms = list(phase.atoms())
        for atom in atoms:
            atom.refinement_flags = "U"
        variables = tuple(
            f"{phase_index}::AUiso:{atom_index}" for atom_index in range(len(atoms))
        )
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=True, override=True)

    project.refine()
    project.save()
    covariance = project.data.get("Covariance", {}).get("data", {})
    result = {
        "Rwp_percent": hist.get_wR(),
        "uiso": {
            phase.name: [float(atom.uiso) for atom in phase.atoms()]
            for phase in project.phases()
        },
        "varyList": covariance.get("varyList", []),
        "Rvals": covariance.get("Rvals", {}),
    }
    args.target.with_suffix(".json").write_text(
        json.dumps(result, indent=2, default=str) + "\n"
    )
    print(json.dumps(result, default=str))


if __name__ == "__main__":
    main()
