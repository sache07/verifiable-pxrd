#!/usr/bin/env python3
"""Copy selected phase coordinates between GSAS-II projects."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("target", type=Path)
    parser.add_argument(
        "--from-project",
        action="append",
        nargs=2,
        metavar=("PHASE", "GPX"),
        default=[],
        help="copy all coordinates for PHASE from GPX (repeatable)",
    )
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.base))
    copied = {}
    for phase_name, source_name in args.from_project:
        source = G2.G2Project(str(source_name))
        source_atoms = {atom.label: atom for atom in source.phase(phase_name).atoms()}
        rows = []
        for atom in project.phase(phase_name).atoms():
            source_atom = source_atoms.get(atom.label)
            if source_atom is None or source_atom.element != atom.element:
                raise ValueError(f"Atom mismatch for {phase_name}/{atom.label}")
            atom.coordinates = source_atom.coordinates
            atom.refinement_flags = " "
            rows.append({"label": atom.label, "coordinates": atom.coordinates})
        copied[phase_name] = {"source": source_name, "atoms": rows}

    project.get_Constraints("Phase").clear()
    args.target.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(args.target))
    args.target.with_suffix(".merge.json").write_text(
        json.dumps(copied, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
