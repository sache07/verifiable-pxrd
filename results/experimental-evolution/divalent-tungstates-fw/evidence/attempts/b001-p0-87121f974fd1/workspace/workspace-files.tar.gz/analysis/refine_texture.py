#!/usr/bin/env python3
"""Continue a GSAS-II trial while testing one March-Dollase axis."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("target", type=Path)
    parser.add_argument("phase")
    parser.add_argument("axis", nargs=3, type=int)
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--only", action="store_true", help="refine only the texture ratio")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.target.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(args.source))
    project.save(str(args.target))
    project.set_Controls("cycles", args.cycles)
    hist = project.histograms()[0]
    phase = project.phase(args.phase)
    if args.only:
        hist.data["Background"][0][1] = False
        for value in hist.data["Instrument Parameters"][0].values():
            if isinstance(value, list) and len(value) > 2:
                value[2] = False
        for value in hist.data["Sample Parameters"].values():
            if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
                value[1] = False
        for item in project.phases():
            item.clear_refinements({"Cell": False})
            item.clear_refinements({"Atoms": [atom.label for atom in item.atoms()]})
            item.clear_HAP_refinements({
                "Scale": False,
                "Size": False,
                "Mustrain": False,
                "HStrain": False,
                "Pref.Ori.": False,
            }, [hist])
    hap = phase.getHAPvalues(hist)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(args.axis)
    index = [item.name for item in project.phases()].index(phase.name)
    variable = f"{index}:0:MD"
    project.set_Controls("parmMin", 0.7, variable=variable)
    project.set_Controls("parmMax", 1.4, variable=variable)
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    project.refine()
    project.save()

    mass_terms = []
    for item in project.phases():
        mass_terms.append(max(0.0, item.getHAPvalues(hist)["Scale"][0] * item.data["General"]["Mass"]))
    total = sum(mass_terms)
    result = {
        "Rwp_percent": hist.get_wR(),
        "texture_phase": phase.name,
        "texture_axis": list(args.axis),
        "texture_ratio": phase.getHAPvalues(hist)["Pref.Ori."][1],
        "fractions": {item.name: value / total for item, value in zip(project.phases(), mass_terms)},
        "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    }
    args.target.with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps(result, default=str))


if __name__ == "__main__":
    main()
