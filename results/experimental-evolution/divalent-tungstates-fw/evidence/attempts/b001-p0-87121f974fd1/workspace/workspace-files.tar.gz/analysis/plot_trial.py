#!/usr/bin/env python3
"""Export a GSAS-II profile to CSV and a compact diagnostic plot."""

import argparse
import csv
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    out = args.out or args.gpx.with_suffix("")

    project = G2.G2Project(str(args.gpx))
    hist = project.histograms()[0]
    data = hist.data["data"][1]
    x, yobs, weight, ycalc, background, residual = [np.asarray(v) for v in data[:6]]
    with out.with_suffix(".csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed", "calculated", "background", "difference"])
        writer.writerows(zip(x, yobs, ycalc, background, yobs - ycalc))

    try:
        import matplotlib.pyplot as plt
    except ModuleNotFoundError:
        return
    fig, axes = plt.subplots(3, 1, figsize=(15, 10), sharex=True)
    regions = [(9.9, 40), (40, 70), (70, 100.1)]
    for axis, (lo, hi) in zip(axes, regions):
        mask = (x >= lo) & (x <= hi)
        axis.plot(x[mask], yobs[mask], color="black", lw=0.7, label="observed")
        axis.plot(x[mask], ycalc[mask], color="#d62728", lw=0.8, label="calculated")
        axis.plot(x[mask], (yobs - ycalc)[mask] - 700, color="#1f77b4", lw=0.6, label="difference - 700")
        axis.axhline(-700, color="0.6", lw=0.4)
        axis.set_xlim(lo, hi)
        axis.set_ylabel("counts")
    axes[0].legend(ncol=3, fontsize=8)
    axes[-1].set_xlabel(r"2$\theta$ (degrees)")
    fig.tight_layout()
    fig.savefig(out.with_suffix(".png"), dpi=160)


if __name__ == "__main__":
    main()
