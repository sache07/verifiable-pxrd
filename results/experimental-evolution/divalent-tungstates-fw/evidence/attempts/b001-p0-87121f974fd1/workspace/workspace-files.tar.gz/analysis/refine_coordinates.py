#!/usr/bin/env python3
"""Test symmetry-constrained coordinate refinement for one phase."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from physical_refine import freeze_all


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("target", type=Path)
    parser.add_argument("phase")
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--elements", help="comma-separated element symbols to refine")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.target.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(args.source))
    project.save(str(args.target))
    project.set_Controls("cycles", args.cycles)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls.setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.histograms()[0]
    freeze_all(project, hist)
    phase = project.phase(args.phase)
    selected = set(args.elements.split(",")) if args.elements else None
    for atom in phase.atoms():
        if selected is None or atom.element in selected:
            atom.refinement_flags = "X"
    project.refine()
    project.save()

    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "phase": phase.name,
        "Rwp_percent": hist.get_wR(),
        "cell": phase.get_cell(),
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": atom.coordinates,
                "uiso": atom.uiso,
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ],
        "varyList": cov.get("varyList", []),
        "Rvals": cov.get("Rvals", {}),
    }
    args.target.with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps(result, default=str))


if __name__ == "__main__":
    main()
