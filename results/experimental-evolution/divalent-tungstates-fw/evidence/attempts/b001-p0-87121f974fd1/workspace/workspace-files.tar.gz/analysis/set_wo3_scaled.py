#!/usr/bin/env python3
"""Set regularized WO3 coordinates along independently refined directions."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


PARENT = {
    "W0": (0.028, 0.537, 0.782),
    "W1": (0.466, 0.023, 0.216),
    "O2": (0.002, 0.238, 0.214),
    "O3": (0.206, 0.542, 0.711),
    "O4": (0.225, 0.526, 0.218),
    "O5": (0.284, 0.043, 0.992),
    "O6": (0.286, 0.013, 0.507),
    "O7": (0.481, 0.241, 0.770),
}


def interpolate(parent: tuple[float, float, float], candidate, scale: float):
    delta = [float(b) - float(a) for a, b in zip(parent, candidate)]
    delta = [d - round(d) for d in delta]
    return tuple((a + scale * d) % 1.0 for a, d in zip(parent, delta))


def coordinates(path: Path) -> dict[str, tuple[float, float, float]]:
    data = json.loads(path.read_text())
    return {row["label"]: tuple(row["coordinates"]) for row in data["atoms"]}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("target", type=Path)
    parser.add_argument("--w-scale", type=float, required=True)
    parser.add_argument("--o-scale", type=float, required=True)
    parser.add_argument(
        "--w-candidate",
        type=Path,
        default=Path("analysis/coords/v6_wo3W_retry.json"),
    )
    parser.add_argument(
        "--o-directory",
        type=Path,
        default=Path("analysis/coord_screen2"),
    )
    parser.add_argument(
        "--o-candidate",
        type=Path,
        help="JSON containing all WO3 oxygen candidates (overrides --o-directory)",
    )
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.source))
    phase = project.phase("WO3")
    candidate = coordinates(args.w_candidate)
    oxygen_labels = ("O2", "O3", "O4", "O5", "O6", "O7")
    if args.o_candidate:
        oxygen_candidates = coordinates(args.o_candidate)
        candidate.update({label: oxygen_candidates[label] for label in oxygen_labels})
    else:
        for label in oxygen_labels:
            candidate.update(
                {
                    label: coordinates(
                        args.o_directory / f"wo3_{label.lower()}.json"
                    )[label]
                }
            )

    report = {}
    for atom in phase.atoms():
        scale = args.w_scale if atom.element == "W" else args.o_scale
        atom.coordinates = interpolate(PARENT[atom.label], candidate[atom.label], scale)
        atom.refinement_flags = " "
        report[atom.label] = {
            "parent": PARENT[atom.label],
            "candidate": candidate[atom.label],
            "scale": scale,
            "coordinates": atom.coordinates,
        }
    project.get_Constraints("Phase").clear()
    args.target.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(args.target))
    args.target.with_suffix(".coordinates.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
