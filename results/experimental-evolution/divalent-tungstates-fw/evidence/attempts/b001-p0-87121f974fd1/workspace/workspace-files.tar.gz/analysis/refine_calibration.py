#!/usr/bin/env python3
"""Refine selected angular calibration terms with all else fixed."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from physical_refine import freeze_all


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("target", type=Path)
    parser.add_argument("--zero", type=float)
    parser.add_argument("--shift", type=float)
    parser.add_argument("--refine-zero", action="store_true")
    parser.add_argument("--refine-shift", action="store_true")
    parser.add_argument("--cycles", type=int, default=14)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.target.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(args.source))
    project.save(str(args.target))
    project.set_Controls("cycles", args.cycles)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls.setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.histograms()[0]
    freeze_all(project, hist)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    if args.zero is not None:
        inst["Zero"][1] = args.zero
    if args.shift is not None:
        sample["Shift"][0] = args.shift
    inst["Zero"][2] = args.refine_zero
    sample["Shift"][1] = args.refine_shift
    project.refine()
    project.save()
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "Rwp_percent": hist.get_wR(),
        "zero": inst["Zero"],
        "shift": sample["Shift"],
        "varyList": cov.get("varyList", []),
        "Rvals": cov.get("Rvals", {}),
    }
    args.target.with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps(result, default=str))


if __name__ == "__main__":
    main()
