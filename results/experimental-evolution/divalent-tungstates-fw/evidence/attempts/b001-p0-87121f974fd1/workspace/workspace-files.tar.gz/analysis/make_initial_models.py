#!/usr/bin/env python3
"""Build solver-side starting models from the supplied filtered COD library."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parents[1]
COD = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/"
    "resources/b001-c04/cif"
)
OUT = ROOT / "analysis" / "models"


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_cif(structure: Structure, path: Path) -> None:
    structure = structure.copy()
    structure.remove_oxidation_states()
    path.parent.mkdir(parents=True, exist_ok=True)
    CifWriter(structure, symprec=1e-3, significant_figures=10).write_file(path)


def main() -> None:
    # All four parents are wolframite P2/c analogues. The Mg analogue is the
    # closest cell match; the others allow coordinate-model sensitivity tests.
    parents = {
        "mg_9013902": ("9013902", "Mg"),
        "mn_1520200": ("1520200", "Mn"),
        "fe_1567215": ("1567215", "Fe"),
        "cd_1520645": ("1520645", "Cd"),
    }
    for name, (cod_id, old_element) in parents.items():
        structure = Structure.from_file(cod_path(cod_id), primitive=False)
        structure.replace_species({old_element: "Zn"})
        write_cif(structure, OUT / f"ZnWO4_from_{name}.cif")

    # Copy through pymatgen to make local, parser-normalized starting files.
    sources = {
        "ZnO_wurtzite_9004178": "9004178",
        "WO3_P21c_1528915": "1528915",
        "WO3_P21c_1563541": "1563541",
        "WO3_P21m_1010618": "1010618",
        "WO3_Pnma_2107312": "2107312",
        "WO3_Pminus1_2106293": "2106293",
        "WO3_P21c_2311041": "2311041",
    }
    for name, cod_id in sources.items():
        structure = Structure.from_file(cod_path(cod_id), primitive=False)
        write_cif(structure, OUT / f"{name}.cif")


if __name__ == "__main__":
    main()
