#!/usr/bin/env python3
"""Screen a phase-shared Suortti surface-roughness correction."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from physical_refine import freeze_all


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("target", type=Path)
    parser.add_argument("--a", type=float, required=True)
    parser.add_argument("--b", type=float, required=True)
    parser.add_argument("--cycles", type=int, default=30)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.target.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(args.source))
    project.save(str(args.target))
    project.set_Controls("cycles", args.cycles)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls.setdefault("parmFrozen", {})["FrozenList"] = []
    project.get_Constraints("Phase").clear()
    hist = project.histograms()[0]
    freeze_all(project, hist)
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [args.a, True]
    sample["SurfRoughB"] = [args.b, True]
    project.refine()
    project.save()

    covariance = project.data.get("Covariance", {}).get("data", {})
    result = {
        "Rwp_percent": hist.get_wR(),
        "SurfRoughA": sample["SurfRoughA"],
        "SurfRoughB": sample["SurfRoughB"],
        "varyList": covariance.get("varyList", []),
        "Rvals": covariance.get("Rvals", {}),
    }
    args.target.with_suffix(".json").write_text(
        json.dumps(result, indent=2, default=str) + "\n"
    )
    print(json.dumps(result, default=str))


if __name__ == "__main__":
    main()
