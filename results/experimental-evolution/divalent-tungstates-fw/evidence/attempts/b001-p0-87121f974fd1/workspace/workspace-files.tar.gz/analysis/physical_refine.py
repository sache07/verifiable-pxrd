#!/usr/bin/env python3
"""Rebuild a physically bounded, replay-consistent refinement in stages."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def freeze_all(project: G2.G2Project, hist: G2.G2PwdrData) -> None:
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False


def refine(project: G2.G2Project, hist: G2.G2PwdrData, label: str) -> dict:
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    project.refine()
    cov = project.data.get("Covariance", {}).get("data", {})
    record = {
        "step": label,
        "Rwp_percent": hist.get_wR(),
        "Rvals": cov.get("Rvals", {}),
        "varyList": cov.get("varyList", []),
    }
    print(json.dumps({"step": label, "Rwp_percent": hist.get_wR(), "Nvars": len(record["varyList"])}))
    return record


def fractions(project: G2.G2Project, hist: G2.G2PwdrData) -> dict[str, float]:
    terms = [
        max(0.0, float(phase.getHAPvalues(hist)["Scale"][0]) * float(phase.data["General"]["Mass"]))
        for phase in project.phases()
    ]
    total = sum(terms)
    return {phase.name: value / total for phase, value in zip(project.phases(), terms)}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("target", type=Path)
    parser.add_argument("--zero", type=float, default=-0.23)
    parser.add_argument("--shift", type=float, default=-800.0)
    parser.add_argument("--shl", type=float, default=0.005)
    parser.add_argument("--u", type=float)
    parser.add_argument("--x", type=float)
    parser.add_argument("--cycles", type=int, default=14)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.target.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(args.source))
    project.save(str(args.target))
    project.set_Controls("cycles", args.cycles)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls.setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.histograms()[0]
    freeze_all(project, hist)

    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    inst["Zero"][1:] = [args.zero, False]
    inst["SH/L"][1:] = [args.shl, False]
    inst["Polariz."][1] = min(1.0, max(0.5, float(inst["Polariz."][1])))
    if args.u is not None:
        inst["U"][1] = args.u
    if args.x is not None:
        inst["X"][1] = args.x
    inst["U"][1] = min(40.0, max(0.0, float(inst["U"][1])))
    inst["W"][1] = min(40.0, max(2.0, float(inst["W"][1])))
    inst["X"][1] = min(6.0, max(0.1, float(inst["X"][1])))
    sample["Shift"] = [args.shift, False]
    sample["Gonio. radius"] = 200.0

    # Negative strain and sizes above the generator's range represent the
    # absence of measurable extra broadening. Place those phases at physical
    # boundary values and keep them fixed; retain the resolved ZnWO4 terms.
    zno = project.phase("ZnO").getHAPvalues(hist)
    zno["Size"][1][0] = 1.5
    zno["Mustrain"][1][0] = 0.0
    wo3 = project.phase("WO3").getHAPvalues(hist)
    wo3["Size"][1][0] = 1.5
    wo3["Mustrain"][1][0] = max(0.0, min(8000.0, float(wo3["Mustrain"][1][0])))
    znwo4 = project.phase("ZnWO4").getHAPvalues(hist)
    znwo4["Size"][1][0] = min(1.5, max(0.04, float(znwo4["Size"][1][0])))
    znwo4["Mustrain"][1][0] = min(8000.0, max(0.0, float(znwo4["Mustrain"][1][0])))

    history = []
    # First restore peak positions and quantitative scales under physical
    # calibration, with profile and texture held fixed.
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.getHAPvalues(hist)["Scale"][1] = True
    history.append(refine(project, hist, "cells_scales_background"))

    # Refine only the in-range common profile family and the resolved phase
    # broadening. SH/L, calibration and boundary broadening remain fixed.
    # U and polarization are already well determined at physical values in the
    # source fit; hold them to avoid trading Gaussian width against phase terms.
    for key in ("W",):
        inst[key][2] = True
    znwo4["Size"][2][0] = True
    znwo4["Mustrain"][2][0] = True
    wo3["Mustrain"][2][0] = True
    history.append(refine(project, hist, "profile_broadening"))

    # Finally refine the independently diagnosed WO3 March-Dollase ratio.
    wo3["Pref.Ori."][0] = "MD"
    wo3["Pref.Ori."][3] = [0, 0, 1]
    wo3["Pref.Ori."][1] = min(1.4, max(0.7, float(wo3["Pref.Ori."][1])))
    wo3["Pref.Ori."][2] = True
    history.append(refine(project, hist, "wo3_texture"))

    project.save()
    result = {
        "Rwp_percent": hist.get_wR(),
        "fractions": fractions(project, hist),
        "history": history,
        "instrument": inst,
        "sample": sample,
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": phase.getHAPvalues(hist)["Scale"],
                "size": phase.getHAPvalues(hist)["Size"],
                "mustrain": phase.getHAPvalues(hist)["Mustrain"],
                "preferred_orientation": phase.getHAPvalues(hist)["Pref.Ori."],
            }
            for phase in project.phases()
        },
    }
    args.target.with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
