#!/usr/bin/env python3
"""Test a uniaxial phase microstrain model with all other terms fixed."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from physical_refine import freeze_all


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("target", type=Path)
    parser.add_argument("phase")
    parser.add_argument("axis", nargs=3, type=int)
    parser.add_argument("--cycles", type=int, default=14)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.target.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(args.source))
    project.save(str(args.target))
    project.set_Controls("cycles", args.cycles)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls.setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.histograms()[0]
    freeze_all(project, hist)
    phase = project.phase(args.phase)
    hap = phase.getHAPvalues(hist)
    strain = hap["Mustrain"]
    initial = max(1.0, float(strain[1][0]))
    strain[0] = "uniaxial"
    strain[1][0] = initial
    strain[1][1] = initial
    strain[2][0] = True
    strain[2][1] = True
    strain[3] = list(args.axis)
    project.refine()
    project.save()

    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "phase": phase.name,
        "Rwp_percent": hist.get_wR(),
        "axis": list(args.axis),
        "mustrain": phase.getHAPvalues(hist)["Mustrain"],
        "varyList": cov.get("varyList", []),
        "Rvals": cov.get("Rvals", {}),
    }
    args.target.with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps(result, default=str))


if __name__ == "__main__":
    main()
