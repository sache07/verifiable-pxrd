#!/usr/bin/env python3
"""Create the requested submission files from the selected GSAS-II project."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis/final_candidates/joint4.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "ZnWO4": {
        "formula": "ZnWO4",
        "space_group": "P 2/c",
        "space_group_number": 13,
        "cif": "ZnWO4.cif",
        "model_origin": "wolframite MgWO4 analogue (COD 9013902), Mg replaced by Zn and coordinates refined",
    },
    "ZnO": {
        "formula": "ZnO",
        "space_group": "P 63 m c",
        "space_group_number": 186,
        "cif": "ZnO.cif",
        "model_origin": "wurtzite ZnO (COD 9004178), refined",
    },
    "WO3": {
        "formula": "WO3",
        "space_group": "P 21/c",
        "space_group_number": 14,
        "cif": "WO3.cif",
        "model_origin": "monoclinic WO3 (COD 2311041), refined",
    },
}


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE))
    project.save(str(FINAL))
    # Reload what will actually be submitted before deriving every other file.
    project = G2.G2Project(str(FINAL))
    hist = project.histograms()[0]
    x, observed, _, calculated, background, _ = [
        np.asarray(array, dtype=float) for array in hist.data["data"][1][:6]
    ]
    public = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    if not (
        public.shape == (len(x), 2)
        and np.allclose(public[:, 0], x, rtol=0, atol=1e-8)
        and np.allclose(public[:, 1], observed, rtol=0, atol=1e-8)
    ):
        raise RuntimeError("Final project does not contain the original observed scan")

    phase_terms = []
    for phase in project.phases():
        if phase.name not in PHASE_INFO:
            raise RuntimeError(f"Unexpected phase {phase.name}")
        phase.export_CIF(str(ROOT / PHASE_INFO[phase.name]["cif"]))
        hap = phase.getHAPvalues(hist)
        phase_terms.append(
            (phase, float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]))
        )
    total = sum(value for _, value in phase_terms)
    fractions = {phase.name: value / total for phase, value in phase_terms}

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "difference", "background"]
        )
        for row in zip(x, observed, calculated, observed - calculated, background):
            writer.writerow([f"{value:.10g}" for value in row])

    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    nvars = len(covariance.get("varyList", []))
    weights = 1.0 / np.maximum(observed, 1.0)
    weighted_sum = float(np.sum(weights * (observed - calculated) ** 2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(weighted_sum / denominator))
    rp = float(100.0 * np.sum(np.abs(observed - calculated)) / np.sum(observed))
    gof = float(np.sqrt(weighted_sum / (len(observed) - nvars)))
    rexp = rwp / gof

    phases = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        phases.append(
            {
                "name": phase.name,
                "formula": info["formula"],
                "space_group": info["space_group"],
                "space_group_number": info["space_group_number"],
                "cif_path": info["cif"],
                "weight_fraction": fractions[phase.name],
                "cell": phase.get_cell(),
                "model_origin": info["model_origin"],
            }
        )

    result = {
        "schema_version": 1,
        "refinement_method": "three-phase GSAS-II Rietveld refinement",
        "refinement_histogram": hist.name,
        "fraction_basis": "normalized over the modeled crystalline phases",
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "Rexp_percent": rexp,
            "goodness_of_fit": gof,
            "weighted_sum_of_squares": weighted_sum,
            "number_of_observations": int(len(observed)),
            "number_of_refined_parameters": int(nvars),
            "weighting": "1/max(observed_counts, 1)",
            "GSAS_Rwp_percent": float(rvals.get("Rwp", rwp)),
        },
        "calibration": {
            "zero_offset_deg": float(
                hist.data["Instrument Parameters"][0]["Zero"][1]
            ),
            "specimen_displacement_um": float(
                hist.data["Sample Parameters"]["Shift"][0]
            ),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    residual_mole_ratio = (fractions["ZnO"] / 81.38) / (
        fractions["WO3"] / 231.84
    )
    report = f"""# Powder XRD phase analysis

## Result

The pattern is described by three crystalline phases: wolframite-type ZnWO4 (P 2/c), wurtzite ZnO (P 63 m c), and monoclinic WO3 (P 21/c). The refined crystalline-phase fractions are {100*fractions['ZnWO4']:.2f} wt% ZnWO4, {100*fractions['ZnO']:.2f} wt% ZnO, and {100*fractions['WO3']:.2f} wt% WO3. These values are normalized over the modeled crystalline material; an amorphous fraction cannot be determined from this scan without an internal standard.

The final fit has Rwp = {rwp:.3f}%, Rp = {rp:.3f}%, Rexp = {rexp:.3f}%, and GOF = {gof:.3f} ({len(observed)} points, {nvars} refined parameters). A fresh native GSAS-II replay regenerated the atomic structure factors and reflection lists with no physical-review flags.

## Evidence

ZnWO4 accounts for the dominant wolframite reflections, including the low-angle peaks near 15.8 and 19.2 degrees and the dense 24-37 degree group. Because the exact Zn-W-O entry was withheld from the supplied search library, its starting model was made from the isostructural MgWO4 model COD 9013902 by Mg-to-Zn substitution, followed by cell and symmetry-constrained coordinate refinement.

Residual peaks at about 31.8, 34.5, and 47.6 degrees identify wurtzite ZnO (COD 9004178). The characteristic WO3 cluster at about 23.4-24.7 degrees and additional peaks near 33.6-34.5 degrees select the monoclinic P21/c model COD 2311041. WO3 required a modest [001] March-Dollase correction (ratio about 1.29). The residual ZnO:WO3 mole ratio is {residual_mole_ratio:.2f}:1, independently consistent with partial conversion of a nominal 1:1 ZnO/WO3 charge.

## Uncertainty

The phase inventory and wolframite/wurtzite/monoclinic assignments are well supported by multiple non-overlapping reflections. Fractions for the minor ZnO and textured WO3 phases are correlated with preferred orientation and overlapping peaks; a practical uncertainty of roughly 1-2 wt% is more realistic than the least-squares precision. The ZnWO4 topology and heavy-atom sites are reliable, but its oxygen coordinates inherit some analogue-model uncertainty. WO3 oxygen coordinates are weakly constrained by X-ray contrast and were regularized to the documented reference-mismatch range; its refined Uiso reached the allowed lower bound, so that displacement parameter is not independently reliable. No amorphous or unidentified crystalline fraction is quantified.
"""
    (ROOT / "report.md").write_text(report)


if __name__ == "__main__":
    main()
