#!/usr/bin/env python3
"""Create and refine a trial multiphase GSAS-II project.

Run with the GSAS-II Python interpreter. This is intentionally conservative:
it refines global terms and phase cells before phase-dependent broadening.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
MODELS = ROOT / "analysis" / "models"


def write_observed(path: Path) -> None:
    rows = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    x = np.asarray(rows["two_theta_deg"], float)
    y = np.asarray(rows["intensity"], float)
    sig = np.sqrt(np.maximum(y, 1.0))
    with path.open("w") as stream:
        stream.write("# Observed powder pattern; sigma=sqrt(counts)\n")
        for xx, yy, ss in zip(x, y, sig):
            stream.write(f"{xx:.8f} {yy:.8f} {ss:.8f}\n")


def write_instrument(path: Path) -> None:
    path.write_text(
        "#GSAS-II instrument parameter file for Cu Kalpha lab data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:15.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def set_cycles(project: G2.G2Project, cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)


def run_refinement(project: G2.G2Project, hist: G2.G2PwdrData, label: str) -> dict:
    # Limits can freeze a parameter for one refinement. Clear that transient
    # list between staged fits so newly introduced correlated terms can move a
    # parameter back into the interior of its physical interval.
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    project.refine()
    result = {
        "step": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "Nvars": len(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }
    print(json.dumps(result, sort_keys=True))
    return result


def phase_summary(project: G2.G2Project, hist: G2.G2PwdrData) -> list[dict]:
    values = []
    raw_mass = []
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        scale = float(hap["Scale"][0])
        mass = float(phase.data["General"]["Mass"])
        raw_mass.append(max(scale * mass, 0.0))
    denom = sum(raw_mass)
    for phase, amount in zip(project.phases(), raw_mass):
        hap = phase.getHAPvalues(hist)
        values.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "hap_scale": float(hap["Scale"][0]),
                "weight_fraction": amount / denom if denom else None,
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    return values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", required=True)
    parser.add_argument("--znwo4", default="ZnWO4_from_mg_9013902.cif")
    parser.add_argument("--wo3", default="WO3_P21c_1528915.cif")
    parser.add_argument("--without-zno", action="store_true")
    parser.add_argument("--without-wo3", action="store_true")
    parser.add_argument("--coordinates", action="store_true")
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--unbounded", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    out = ROOT / "analysis" / "trials" / args.name
    out.mkdir(parents=True, exist_ok=True)
    datafile = out / "observed.xye"
    instfile = out / "instrument.instprm"
    write_observed(datafile)
    write_instrument(instfile)

    project = G2.G2Project(newgpx=str(out / "trial.gpx"))
    phase_specs = [("ZnWO4", MODELS / args.znwo4)]
    if not args.without_zno:
        phase_specs.append(("ZnO", MODELS / "ZnO_wurtzite_9004178.cif"))
    if not args.without_wo3:
        phase_specs.append(("WO3", MODELS / args.wo3))
    phases = [
        project.add_phase(str(path), phasename=name, fmthint="CIF")
        for name, path in phase_specs
    ]
    hist = project.add_powder_histogram(
        str(datafile), str(instfile), phases=phases, fmthint="xye"
    )
    set_cycles(project, args.cycles)

    # Use all observations. Initialize a flexible but smooth Chebyshev background.
    hist.set_refinements({
        "Limits": [9.90343322, 100.09455322],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 10,
            "coeffs": [1050.0] + [0.0] * 9,
            "refine": True,
        },
    })
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, True]
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]

    # Keep every fitted nuisance parameter within the frozen laboratory's
    # physically generated range. This also prevents correlations between
    # cell, specimen height and profile terms from wandering to false minima.
    limits = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.5, 1.0),
    }
    if not args.unbounded:
        for variable, (lower, upper) in limits.items():
            project.set_Controls("parmMin", lower, variable=variable)
            project.set_Controls("parmMax", upper, variable=variable)

    # Similar initial mass fractions avoid zero-scale traps.
    initial_fractions = {"ZnWO4": 0.65, "ZnO": 0.10, "WO3": 0.25}
    for phase in phases:
        hap = phase.getHAPvalues(hist)
        hap["Scale"][0] = 10000.0 * initial_fractions.get(phase.name, 1.0) / float(
            phase.data["General"]["Mass"]
        )
        phase.set_HAP_refinements({"Scale": False}, [hist])
    if not args.unbounded:
        for index, phase in enumerate(phases):
            for suffix, lower, upper in (
                ("Scale", 0.0, 1000.0),
                ("Size;i", 0.04, 1.5),
                ("Mustrain;i", 0.0, 8000.0),
            ):
                variable = f"{index}:0:{suffix}"
                project.set_Controls("parmMin", lower, variable=variable)
                project.set_Controls("parmMax", upper, variable=variable)

    history = []
    history.append(run_refinement(project, hist, "background_overall_scale"))

    # Refine the global angular offset first, then cells. The phase cells are
    # sufficiently close that this sequence is stable.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    history.append(run_refinement(project, hist, "zero"))
    for phase in phases:
        phase.set_refinements({"Cell": True})
    history.append(run_refinement(project, hist, "cells"))

    # Once phase peaks overlap the observations, switch from one overall scale
    # to independent phase scales for quantitative analysis.
    hist.data["Sample Parameters"]["Scale"][1] = False
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    history.append(run_refinement(project, hist, "phase_scales"))

    # Separate specimen height from the constant zero using the full angular range.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    history.append(run_refinement(project, hist, "sample_shift"))

    # Generator uses V=Y=Z=0. Refine only the supported instrumental family.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    history.append(run_refinement(project, hist, "instrument_profile"))

    # Start with isotropic phase broadening. Anisotropic alternatives are tested
    # only after this baseline converges.
    for phase in phases:
        phase.setSampleProfile(hist, "size", "isotropic", 0.3, LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=1.0)
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    history.append(run_refinement(project, hist, "phase_broadening"))

    if args.coordinates:
        # Symmetry-compatible coordinate refinement; occupancies and ADPs remain
        # fixed here to avoid correlations with phase scale.
        for phase in phases:
            phase.set_refinements({"Atoms": {"all": "X"}})
        history.append(run_refinement(project, hist, "coordinates"))

    project.save()
    summary = {
        "name": args.name,
        "history": history,
        "histogram": hist.name,
        "Rwp_percent": hist.get_wR(),
        "phases": phase_summary(project, hist),
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"],
        "covariance": {
            "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
            "sig": project.data.get("Covariance", {}).get("data", {}).get("sig", []).tolist()
            if hasattr(project.data.get("Covariance", {}).get("data", {}).get("sig", []), "tolist")
            else project.data.get("Covariance", {}).get("data", {}).get("sig", []),
            "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
        },
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
