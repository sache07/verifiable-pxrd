#!/usr/bin/env python3
"""Plot a profile CSV previously exported from a GSAS-II project."""

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("csv", type=Path)
    args = parser.parse_args()
    data = np.genfromtxt(args.csv, delimiter=",", names=True)
    x = data["two_theta_deg"]
    yobs = data["observed"]
    ycalc = data["calculated"]
    fig, axes = plt.subplots(3, 1, figsize=(15, 10))
    for axis, (lo, hi) in zip(axes, [(9.9, 40), (40, 70), (70, 100.1)]):
        mask = (x >= lo) & (x <= hi)
        axis.plot(x[mask], yobs[mask], color="black", lw=0.7, label="observed")
        axis.plot(x[mask], ycalc[mask], color="#d62728", lw=0.8, label="calculated")
        axis.plot(x[mask], (yobs - ycalc)[mask] - 700, color="#1f77b4", lw=0.6, label="difference - 700")
        axis.axhline(-700, color="0.6", lw=0.4)
        axis.set_xlim(lo, hi)
        axis.set_ylabel("counts")
    axes[0].legend(ncol=3, fontsize=8)
    axes[-1].set_xlabel(r"2$\theta$ (degrees)")
    fig.tight_layout()
    fig.savefig(args.csv.with_suffix(".png"), dpi=160)


if __name__ == "__main__":
    main()
