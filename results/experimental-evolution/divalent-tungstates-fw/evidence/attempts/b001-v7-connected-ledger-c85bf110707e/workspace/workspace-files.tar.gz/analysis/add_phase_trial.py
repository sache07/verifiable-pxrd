#!/usr/bin/env python3
"""Add one candidate phase to a converged project with staged low flexibility."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from build_inventory import clear_flags, normalize_uiso, profile_screen, set_cell


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--cif", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--scale", type=float, default=1.0)
    parser.add_argument("--size", type=float, default=0.05)
    parser.add_argument(
        "--fix-size", action="store_true",
        help="Keep the candidate size fixed during lower-flexibility restaging",
    )
    parser.add_argument(
        "--cell", nargs=6, type=float,
        metavar=("A", "B", "C", "ALPHA", "BETA", "GAMMA"),
        help="Optional physically screened starting cell for an adapted analogue",
    )
    parser.add_argument("--axis", nargs=3, type=int)
    parser.add_argument("--cycles", type=int, default=18)
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.input, newgpx=args.out)
    hist = gpx.histogram(0)
    phase = gpx.add_phase(str(Path(args.cif).resolve()), phasename=args.name, histograms=[hist])
    normalize_uiso(phase, 0.01)
    if args.cell:
        set_cell(phase, args.cell)
    for atom in phase.atoms():
        atom.refinement_flags = " "
    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = args.cycles
    controls["min dM/M"] = 1e-5
    controls["SVDtol"] = 1e-6
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [args.scale, True]
    phase.data["General"]["Cell"][0] = True
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = args.size
    hap["Size"][2][0] = not args.fix_size
    stages = []

    # Save the converged model's refinement flags. The candidate first gets a
    # low-flexibility scale/cell/size fit so a poor initial cell cannot force a
    # premature scale collapse or destabilize the established phases.
    state = {
        "background": hist.data["Background"][0][1],
        "instrument": {
            k: v[2] for k, v in hist.data["Instrument Parameters"][0].items()
            if isinstance(v, list) and len(v) >= 3 and isinstance(v[2], bool)
        },
        "sample": {
            k: v[1] for k, v in hist.data["Sample Parameters"].items()
            if isinstance(v, list) and len(v) >= 2 and isinstance(v[1], bool)
        },
        "phases": {},
    }
    for p in gpx.phases():
        phap = p.data["Histograms"][hist.name]
        state["phases"][p.name] = {
            "cell": p.data["General"]["Cell"][0],
            "atoms": {a.label: a.refinement_flags for a in p.atoms()},
            "scale": phap["Scale"][1],
            "po": phap["Pref.Ori."][2],
            "size2": copy.deepcopy(phap["Size"][2]),
            "size5": copy.deepcopy(phap["Size"][5]),
            "strain2": copy.deepcopy(phap["Mustrain"][2]),
            "strain5": copy.deepcopy(phap["Mustrain"][5]),
        }

    def refine(label):
        gpx.save()
        gpx.refine(makeBack=False)
        stages.append({
            "stage": label,
            "Rwp_percent": hist.get_wR(),
            "scale": hap["Scale"][0],
            "fractions": hist.ComputeMassFracs(),
        })

    clear_flags(gpx)
    phase.set_HAP_refinements({"Scale": True}, [hist])
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": args.size, "refine": False}
    }, [hist])
    controls["max cyc"] = max(args.cycles, 25)
    refine("candidate_scale")
    phase.set_refinements({"Cell": True})
    refine("candidate_cell")
    if args.axis:
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = args.axis
        phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])
        refine("candidate_texture")
    if not args.fix_size:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": args.size, "refine": True}
        }, [hist])
        refine("candidate_size")

    hist.data["Background"][0][1] = state["background"]
    for k, flag in state["instrument"].items():
        hist.data["Instrument Parameters"][0][k][2] = flag
    for k, flag in state["sample"].items():
        hist.data["Sample Parameters"][k][1] = flag
    for p in gpx.phases():
        saved = state["phases"][p.name]
        p.data["General"]["Cell"][0] = saved["cell"]
        for atom in p.atoms():
            atom.refinement_flags = saved["atoms"][atom.label]
        phap = p.data["Histograms"][hist.name]
        phap["Scale"][1] = saved["scale"]
        phap["Pref.Ori."][2] = saved["po"]
        phap["Size"][2] = saved["size2"]
        phap["Size"][5] = saved["size5"]
        phap["Mustrain"][2] = saved["strain2"]
        phap["Mustrain"][5] = saved["strain5"]
    if args.axis:
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = args.axis
        phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])
    controls["max cyc"] = args.cycles
    refine("full_replay")
    gpx.save()
    print(json.dumps({
        "name": phase.name,
        "space_group": phase.data["General"]["SGData"]["SpGrp"],
        "cell": phase.get_cell(),
        "Rwp_percent": hist.get_wR(),
        "GOF": gpx.data["Covariance"]["data"]["Rvals"].get("GOF"),
        "profile": profile_screen(hist),
        "size": hap["Size"],
        "preferred_orientation": hap["Pref.Ori."],
        "stages": stages,
    }, default=float, sort_keys=True))


if __name__ == "__main__":
    main()
