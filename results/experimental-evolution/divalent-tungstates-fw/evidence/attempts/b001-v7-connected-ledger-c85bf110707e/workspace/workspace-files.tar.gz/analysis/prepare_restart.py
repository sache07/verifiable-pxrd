#!/usr/bin/env python3
"""Prepare an independently perturbed GSAS-II restart without refining it."""

from __future__ import annotations

import argparse

from GSASII import GSASIIscriptable as G2sc

from build_inventory import set_cell


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--phase")
    parser.add_argument("--cell", nargs=6, type=float)
    parser.add_argument("--po", type=float)
    parser.add_argument("--set", nargs="*", default=[])
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.input, newgpx=args.out)
    hist = gpx.histogram(0)
    if args.phase:
        phase = gpx.phase(args.phase)
        if args.cell:
            set_cell(phase, args.cell)
        if args.po is not None:
            phase.data["Histograms"][hist.name]["Pref.Ori."][1] = args.po
    elif args.cell or args.po is not None:
        raise ValueError("--phase is required with --cell or --po")

    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    for item in args.set:
        key, raw = item.split("=", 1)
        value = float(raw)
        if key in inst:
            inst[key][1] = value
        elif key in sample:
            sample[key][0] = value
        else:
            raise KeyError(key)
    gpx.save()


if __name__ == "__main__":
    main()
