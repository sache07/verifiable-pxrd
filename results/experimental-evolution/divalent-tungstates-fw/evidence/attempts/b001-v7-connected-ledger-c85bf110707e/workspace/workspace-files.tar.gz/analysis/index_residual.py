#!/usr/bin/env python3
"""Index coherent residual peak families with the GSAS-II cell search."""

from __future__ import annotations

import json
import math
import random
from pathlib import Path

from GSASII import GSASIIindex as G2index


WAVELENGTH = 1.540598
ZERO = -0.087115

PEAK_SETS = {
    "core": [
        18.760, 19.314, 30.658, 31.430, 32.136, 36.537,
        46.947, 55.097, 55.629, 56.966, 59.226,
    ],
    "extended": [
        18.760, 19.314, 24.660, 28.550, 30.658, 31.430, 32.136,
        34.038, 36.537, 37.548, 39.025, 40.514, 46.947, 48.251,
        49.033, 49.881, 55.097, 55.629, 56.966, 59.226, 63.996,
        68.636,
    ],
    "family_a": [18.760, 30.658, 36.537, 46.947, 49.881, 55.097, 63.996, 68.636],
    "family_b": [19.314, 31.430, 32.136, 34.038, 40.514, 48.251, 49.033, 55.629, 56.966, 59.226],
}

BRAVAIS = {
    2: "Cubic-P",
    4: "Hexagonal-P",
    5: "Tetragonal-I",
    6: "Tetragonal-P",
    8: "Orthorhombic-I",
    11: "Orthorhombic-C",
    12: "Orthorhombic-P",
    13: "Monoclinic-I",
    15: "Monoclinic-C",
    16: "Monoclinic-P",
}


def make_peaks(positions):
    peaks = []
    for position in sorted(positions):
        true_position = position - ZERO
        d_spacing = WAVELENGTH / (2.0 * math.sin(math.radians(true_position / 2.0)))
        peaks.append([position, 1.0, True, False, 0, 0, 0, d_spacing, 0.0])
    return peaks


def main():
    records = []
    # Search several chemically plausible volume scales independently. A short
    # deterministic timeout is used because these are residual-family screens.
    selected_sets = ["core", "family_a", "family_b"]
    for set_index, set_name in enumerate(selected_sets):
        positions = PEAK_SETS[set_name]
        if len(positions) < 7:
            continue
        for volume in (150.0, 300.0):
            for bravais_index, bravais_name in BRAVAIS.items():
                random.seed(13007 + 1000 * set_index + int(volume) + bravais_index)
                flags = [False] * 18
                flags[bravais_index] = True
                controls = [False, ZERO, 6, volume]
                try:
                    ok, dmin, cells = G2index.DoIndexPeaks(
                        make_peaks(positions),
                        controls,
                        flags,
                        None,
                        ifX20=True,
                        timeout=3.0,
                        M20_min=3.0,
                        X20_max=4,
                        return_Nc=True,
                    )
                except Exception as exc:
                    records.append({
                        "peak_set": set_name,
                        "start_volume": volume,
                        "bravais": bravais_name,
                        "error": f"{type(exc).__name__}: {exc}",
                    })
                    continue
                for cell in cells[:8]:
                    records.append({
                        "peak_set": set_name,
                        "start_volume": volume,
                        "bravais": bravais_name,
                        "M20": cell[0],
                        "X20": cell[1],
                        "indexed_reflections": cell[12] if len(cell) > 12 else None,
                        "cell": cell[3:10],
                        "dmin": dmin,
                    })
    records.sort(key=lambda item: (-item.get("M20", -1.0), item.get("X20", 99)))
    output = Path("analysis/residual_indexing.json")
    with output.open("w") as stream:
        json.dump({"schema_version": 1, "zero_deg": ZERO, "records": records}, stream, indent=2)
        stream.write("\n")
    print(json.dumps(records[:50], indent=2))


if __name__ == "__main__":
    main()
