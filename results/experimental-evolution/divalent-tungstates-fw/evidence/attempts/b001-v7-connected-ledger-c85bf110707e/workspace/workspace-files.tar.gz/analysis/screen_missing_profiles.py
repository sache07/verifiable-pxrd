#!/usr/bin/env python3
"""Low-flexibility residual-profile screen for plausible missing phases.

This is a shortlist generator, not a structural refinement. Source fractional
coordinates are fixed. Only symmetry-allowed cell dimensions and one common
Gaussian width are varied, followed by an analytical nonnegative scale fit to
the residual from the converged three-phase GSAS-II model.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Lattice, Structure
from scipy.optimize import differential_evolution


LAMBDA = ((1.540598, 1.0), (1.544426, 0.5))


def parameterization(structure: Structure):
    system = structure.get_space_group_info()[0]
    number = structure.get_space_group_info()[1]
    a, b, c = structure.lattice.abc
    alpha, beta, gamma = structure.lattice.angles
    if number >= 195:
        names = ["a", "fwhm"]
        bounds = [(0.72 * a, 1.20 * a), (0.08, 1.50)]
        make = lambda p: Lattice.cubic(p[0])
    elif number >= 168:
        names = ["a", "c", "fwhm"]
        bounds = [(0.72 * a, 1.20 * a), (0.72 * c, 1.20 * c), (0.08, 1.50)]
        make = lambda p: Lattice.hexagonal(p[0], p[1])
    elif number >= 143:
        # All candidates here use the conventional hexagonal setting.
        names = ["a", "c", "fwhm"]
        bounds = [(0.72 * a, 1.20 * a), (0.72 * c, 1.20 * c), (0.08, 1.50)]
        make = lambda p: Lattice.hexagonal(p[0], p[1])
    elif number >= 75:
        names = ["a", "c", "fwhm"]
        bounds = [(0.72 * a, 1.20 * a), (0.72 * c, 1.20 * c), (0.08, 1.50)]
        make = lambda p: Lattice.tetragonal(p[0], p[1])
    elif number >= 16:
        names = ["a", "b", "c", "fwhm"]
        bounds = [
            (0.72 * a, 1.20 * a),
            (0.72 * b, 1.20 * b),
            (0.72 * c, 1.20 * c),
            (0.08, 1.50),
        ]
        make = lambda p: Lattice.orthorhombic(p[0], p[1], p[2])
    elif number >= 3:
        names = ["a", "b", "c", "beta", "fwhm"]
        bounds = [
            (0.72 * a, 1.20 * a),
            (0.72 * b, 1.20 * b),
            (0.72 * c, 1.20 * c),
            (max(75.0, beta - 18.0), min(125.0, beta + 18.0)),
            (0.08, 1.50),
        ]
        make = lambda p: Lattice.monoclinic(p[0], p[1], p[2], p[3])
    else:
        names = ["a", "b", "c", "alpha", "beta", "gamma", "fwhm"]
        bounds = [
            (0.72 * a, 1.20 * a),
            (0.72 * b, 1.20 * b),
            (0.72 * c, 1.20 * c),
            (max(70.0, alpha - 15.0), min(120.0, alpha + 15.0)),
            (max(70.0, beta - 15.0), min(120.0, beta + 15.0)),
            (max(70.0, gamma - 15.0), min(120.0, gamma + 15.0)),
            (0.08, 1.50),
        ]
        make = lambda p: Lattice.from_parameters(*p[:6])
    return system, names, bounds, make


def reflections(structure: Structure):
    pattern = XRDCalculator(wavelength=LAMBDA[0][0]).get_pattern(
        structure, two_theta_range=(4.0, 145.0), scaled=False
    )
    hkls = []
    intensities = []
    for intensity, group in zip(pattern.y, pattern.hkls):
        total_multiplicity = sum(item["multiplicity"] for item in group)
        for item in group:
            hkl = item["hkl"]
            # pymatgen reports hexagonal/trigonal reflections in the
            # four-index Miller-Bravais convention (h,k,i,l). The reciprocal
            # lattice calculation below uses the conventional three-index
            # basis (h,k,l).
            if len(hkl) == 4:
                hkl = (hkl[0], hkl[1], hkl[3])
            hkls.append(hkl)
            intensities.append(float(intensity) * item["multiplicity"] / total_multiplicity)
    return np.asarray(hkls, dtype=float), np.asarray(intensities, dtype=float)


def screen(path: Path, x, residual, weight, seed: int):
    structure = Structure.from_file(path, primitive=False)
    crystal_system, names, bounds, make_lattice = parameterization(structure)
    hkls, intensities = reflections(structure)
    base = float(np.sum(weight * residual**2))

    def profile(parameters):
        lattice = make_lattice(parameters)
        reciprocal = lattice.reciprocal_lattice_crystallographic.matrix
        inv_d = np.linalg.norm(hkls @ reciprocal, axis=1)
        d = 1.0 / inv_d
        fwhm = parameters[-1]
        sigma = fwhm / 2.354820045
        calculated = np.zeros_like(x)
        for wavelength, ratio in LAMBDA:
            argument = wavelength / (2.0 * d)
            valid = (argument > 0.0) & (argument < 1.0)
            positions = 2.0 * np.degrees(np.arcsin(argument[valid]))
            line_intensities = ratio * intensities[valid]
            for position, intensity in zip(positions, line_intensities):
                if position < x[0] - 4 * sigma or position > x[-1] + 4 * sigma:
                    continue
                lower = np.searchsorted(x, position - 4 * sigma)
                upper = np.searchsorted(x, position + 4 * sigma)
                calculated[lower:upper] += intensity * np.exp(
                    -0.5 * ((x[lower:upper] - position) / sigma) ** 2
                )
        return calculated

    def objective(parameters, details=False):
        candidate = profile(parameters)
        denominator = float(np.sum(weight * candidate**2))
        scale = (
            max(0.0, float(np.sum(weight * residual * candidate) / denominator))
            if denominator > 0.0
            else 0.0
        )
        value = float(np.sum(weight * (residual - scale * candidate) ** 2))
        if details:
            return value, scale, candidate
        return value / base

    result = differential_evolution(
        objective,
        bounds,
        seed=seed,
        popsize=8,
        maxiter=55,
        tol=2e-6,
        polish=True,
        updating="immediate",
        workers=1,
    )
    value, scale, candidate = objective(result.x, details=True)
    lattice = make_lattice(result.x)
    adapted = structure.copy()
    adapted.lattice = lattice
    minima = {"Ca-O": 99.0, "W-O": 99.0, "O-O": 99.0, "all": 99.0}
    for index_a, site_a in enumerate(adapted):
        element_a = max(site_a.species.items(), key=lambda item: item[1])[0].symbol
        for index_b in range(index_a + 1, len(adapted)):
            site_b = adapted[index_b]
            element_b = max(site_b.species.items(), key=lambda item: item[1])[0].symbol
            distance = adapted.get_distance(index_a, index_b)
            minima["all"] = min(minima["all"], distance)
            pair = "-".join(sorted((element_a, element_b)))
            if pair == "Ca-O":
                minima["Ca-O"] = min(minima["Ca-O"], distance)
            elif pair == "O-W":
                minima["W-O"] = min(minima["W-O"], distance)
            elif pair == "O-O":
                minima["O-O"] = min(minima["O-O"], distance)
    return {
        "path": str(path),
        "formula": adapted.composition.formula,
        "space_group": structure.get_space_group_info(),
        "crystal_system": crystal_system,
        "parameters": {name: float(value) for name, value in zip(names, result.x)},
        "cell": [float(item) for item in (*lattice.abc, *lattice.angles)],
        "profile_scale": scale,
        "weighted_SSE_ratio": value / base,
        "Rwp_ratio_if_model_fixed": float(np.sqrt(value / base)),
        "density_g_cm3": float(adapted.density),
        "minimum_distances_A": {key: float(value) for key, value in minima.items()},
        "optimizer_success": bool(result.success),
        "optimizer_message": result.message,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("paths", nargs="+")
    parser.add_argument("--residual", default="analysis/current_residual.npz")
    parser.add_argument("--out", default="analysis/missing_profile_screen.json")
    parser.add_argument("--seed", type=int, default=173)
    args = parser.parse_args()
    data = np.load(args.residual)
    x = np.asarray(data["x"], dtype=float)
    residual = np.asarray(data["r"], dtype=float)
    weight = np.asarray(data["w"], dtype=float)
    weight[~np.isfinite(weight)] = 0.0
    records = []
    for offset, item in enumerate(args.paths):
        try:
            record = screen(Path(item), x, residual, weight, args.seed + offset)
        except Exception as exc:
            record = {"path": item, "error": f"{type(exc).__name__}: {exc}"}
        records.append(record)
        print(json.dumps(record, sort_keys=True), flush=True)
    records.sort(key=lambda item: item.get("weighted_SSE_ratio", 99.0))
    with Path(args.out).open("w") as stream:
        json.dump({"schema_version": 1, "records": records}, stream, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    main()
