#!/usr/bin/env python3
"""Compare a Ca3WO6 analogue by a matched swap into a converged project."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from build_inventory import ROOT, normalize_uiso, profile_screen, set_cell


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--candidate", required=True)
    parser.add_argument("--cycles", type=int, default=18)
    parser.add_argument("--skip-po", action="store_true")
    parser.add_argument("--skip-size", action="store_true")
    args = parser.parse_args()

    out = Path(args.out).resolve()
    gpx = G2sc.G2Project(args.input, newgpx=str(out))
    hist = gpx.histogram(0)
    old = gpx.phase("Ca3WO6")
    old_hap = old.data["Histograms"][hist.name]
    old_cell = old.get_cell()
    cell = [
        old_cell["length_a"], old_cell["length_b"], old_cell["length_c"],
        old_cell["angle_alpha"], old_cell["angle_beta"], old_cell["angle_gamma"],
    ]

    old_hap["Use"] = False
    old_hap["Scale"][0] = 0.0
    old_hap["Scale"][1] = False

    candidate_path = ROOT / "analysis" / "analogues" / f"ca3wo6_from_{args.candidate}.cif"
    alt = gpx.add_phase(
        str(candidate_path), phasename=f"Ca3WO6_parent_{args.candidate}", histograms=[hist]
    )
    normalize_uiso(alt, 0.01)
    for atom in alt.atoms():
        atom.refinement_flags = " "
    system = alt.data["General"]["SGData"]["SGSys"]
    if system == "cubic":
        set_cell(alt, [7.95, 7.95, 7.95, 90.0, 90.0, 90.0])
    elif system == "tetragonal":
        basal = (cell[0] + cell[1]) / 2.0
        set_cell(alt, [basal, basal, cell[2], 90.0, 90.0, 90.0])
    else:
        set_cell(alt, cell)

    # Transfer every phase-profile term, value and flag from the old model so
    # only the parent coordinates/source differ at the start of the swap.
    alt.data["Histograms"][hist.name] = copy.deepcopy(
        gpx.phase("Ca3WO6").data["Histograms"][hist.name]
    )
    alt_hap = alt.data["Histograms"][hist.name]
    alt_hap["Use"] = True
    alt_hap["Scale"][0] = 9.27
    alt_hap["Scale"][1] = True
    if args.skip_po:
        alt_hap["Pref.Ori."][1] = 1.0
        alt_hap["Pref.Ori."][2] = False
    if args.skip_size:
        alt_hap["Size"][0] = "isotropic"
        alt_hap["Size"][1][0] = 1.0
        alt_hap["Size"][2] = [False] * len(alt_hap["Size"][2])
    alt.set_refinements({"Cell": True})

    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = args.cycles
    controls["min dM/M"] = 1e-5
    controls["SVDtol"] = 1e-6
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()

    fractions = hist.ComputeMassFracs()
    print(json.dumps({
        "candidate": args.candidate,
        "Rwp_percent": hist.get_wR(),
        "GOF": gpx.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "profile": profile_screen(hist),
        "fractions": fractions,
        "cell": alt.get_cell(),
        "preferred_orientation": alt_hap["Pref.Ori."],
        "size": alt_hap["Size"],
    }, default=float, sort_keys=True))


if __name__ == "__main__":
    main()
