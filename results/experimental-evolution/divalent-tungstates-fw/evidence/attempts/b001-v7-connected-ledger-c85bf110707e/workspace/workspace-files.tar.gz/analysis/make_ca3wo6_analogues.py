#!/usr/bin/env python3
"""Create Ca3WO6 analogue models from public COD reference CIFs.

Every non-W, non-O cation is mapped to Ca without moving fractional
coordinates. Source cells and symmetry are retained for subsequent restrained
whole-pattern comparison. A provenance ledger and basic physical screen are
written next to the candidates.
"""

from __future__ import annotations

import json
import copy
import re
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifBlock, CifFile, CifParser


SOURCE_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/"
    "resources/b001-c05/cif"
)

SOURCE_IDS = [
    "2013468",  # Ca2MgWO6, P21/c
    "7222332",  # Ca2CoWO6, P21/c
    "7222333",  # Ca2NiWO6, P21/c
    "2104688",  # Sr2CaWO6, P21/c
    "4002545",  # Sr2CoWO6, P21/c
    "1563083",  # Sr2ZnWO6, P21/c
    "1541622",  # Sr2CoWO6, Fm-3m
    "1537301",  # Ba2MgWO6, Fm-3m
    "1529016",  # Ba2CaWO6, I4/m
]


def source_path(cod_id: str) -> Path:
    return SOURCE_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def nearest_distances(structure: Structure):
    minima = {"Ca-O": 99.0, "W-O": 99.0, "O-O": 99.0, "all": 99.0}
    for i, a in enumerate(structure):
        for j in range(i + 1, len(structure)):
            b = structure[j]
            d = structure.get_distance(i, j)
            minima["all"] = min(minima["all"], d)
            pair = "-".join(sorted((a.specie.symbol, b.specie.symbol)))
            if pair == "Ca-O":
                minima["Ca-O"] = min(minima["Ca-O"], d)
            elif pair == "O-W":
                minima["W-O"] = min(minima["W-O"], d)
            elif pair == "O-O":
                minima["O-O"] = min(minima["O-O"], d)
    return {k: round(v, 5) for k, v in minima.items()}


def write_mapped_cif(src: Path, target: Path, cod_id: str) -> None:
    """Map cation labels/types in the parent CIF while preserving its setting."""
    parser = CifParser(src)
    blocks = copy.deepcopy(parser._cif.data)
    for key, block in blocks.items():
        data = copy.deepcopy(block.data)
        loops = copy.deepcopy(block.loops)

        labels = list(data["_atom_site_label"])
        mapped_labels = []
        ca_index = 0
        for label in labels:
            match = re.match(r"([A-Z][a-z]?)", str(label))
            symbol = match.group(1) if match else ""
            if symbol not in {"W", "O"}:
                ca_index += 1
                mapped_labels.append(f"Ca{ca_index}")
            else:
                mapped_labels.append(str(label))
        data["_atom_site_label"] = mapped_labels

        if "_atom_site_type_symbol" in data:
            mapped_types = []
            for symbol in data["_atom_site_type_symbol"]:
                match = re.match(r"([A-Z][a-z]?)", str(symbol))
                el = match.group(1) if match else ""
                mapped_types.append(el if el in {"W", "O"} else "Ca")
            data["_atom_site_type_symbol"] = mapped_types

        for tag in list(data):
            if tag in {"_chemical_formula_weight", "_exptl_crystal_density_diffrn", "_cod_database_code"}:
                del data[tag]
            elif tag.startswith("_chemical_formula_"):
                data[tag] = "Ca3 O6 W"
            elif tag.startswith("_geom_"):
                del data[tag]
        loops = [[tag for tag in loop if tag in data] for loop in loops]
        loops = [loop for loop in loops if loop]
        data["_audit_creation_method"] = (
            f"Analogue-derived Ca3WO6 model from COD {cod_id}; all non-W/O cation sites mapped to Ca"
        )
        blocks[key] = CifBlock(data, loops, f"Ca3WO6_from_COD_{cod_id}")

    mapped_file = CifFile(
        blocks,
        comment=(
            f"# Analogue-derived model; parent COD {cod_id}. Fractional coordinates, "
            "cell and symmetry setting retained; non-W/O cations mapped to Ca."
        ),
    )
    target.write_text(str(mapped_file))


def main():
    outdir = Path(__file__).resolve().parent / "analogues"
    outdir.mkdir(parents=True, exist_ok=True)
    records = []
    for cod_id in SOURCE_IDS:
        src = source_path(cod_id)
        parent = Structure.from_file(src, primitive=False)
        mapped = parent.copy()
        substitutions = {
            el.symbol: "Ca"
            for el in mapped.composition.elements
            if el.symbol not in {"Ca", "W", "O"}
        }
        # Include pre-existing Ca only in the mapped composition, not in the
        # substitution provenance statement.
        mapped.replace_species(substitutions)
        target = outdir / f"ca3wo6_from_{cod_id}.cif"
        write_mapped_cif(src, target, cod_id)
        mapped = Structure.from_file(target, primitive=False)
        record = {
            "candidate": str(target.relative_to(Path(__file__).resolve().parents[1])),
            "model_basis": "analogue_derived",
            "parent_cod_id": cod_id,
            "parent_path": str(src),
            "parent_formula": parent.composition.formula,
            "transformation": f"Mapped {substitutions} onto Ca; retained parent fractional coordinates, cell and detected symmetry.",
            "mapped_formula": mapped.composition.formula,
            "space_group": mapped.get_space_group_info(),
            "cell": {
                "a": mapped.lattice.a,
                "b": mapped.lattice.b,
                "c": mapped.lattice.c,
                "alpha": mapped.lattice.alpha,
                "beta": mapped.lattice.beta,
                "gamma": mapped.lattice.gamma,
                "volume": mapped.volume,
            },
            "density_g_cm3": mapped.density,
            "minimum_distances_A": nearest_distances(mapped),
        }
        records.append(record)
        print(json.dumps(record, sort_keys=True))
    with (outdir / "provenance.json").open("w") as fp:
        json.dump({"schema_version": 1, "records": records}, fp, indent=2)
        fp.write("\n")


if __name__ == "__main__":
    main()
