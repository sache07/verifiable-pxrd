#!/usr/bin/env python3
"""Create chemistry-nearest Ca--W--O analogue models with provenance.

Fractional coordinates, symmetry, and the source setting are retained. Only
the explicitly listed element identities are changed; cells are adapted later
against the public powder pattern.
"""

from __future__ import annotations

import copy
import json
import re
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifBlock, CifFile, CifParser


SOURCE_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/"
    "resources/b001-c05/cif"
)

SPECS = [
    # Charge- and composition-nearest parent for the absent Ca2WO5 entry.
    ("7220560", {"Pb": "Ca", "Mo": "W"}, "Ca2 O5 W", "ca2wo5"),
    # Divalent-cation A3W2O9 parents.
    ("1533878", {"Ba": "Ca"}, "Ca3 O9 W2", "ca3w2o9"),
    ("2311977", {"Sr": "Ca"}, "Ca3 O9 W2", "ca3w2o9"),
    # Additional A3WO6 topology parents, distinct from the ordered
    # double-perovskite lineage already compared in the main inventory.
    ("1534803", {"Ba": "Ca"}, "Ca3 O6 W", "ca3wo6"),
    ("1527404", {"Cu": "Ca"}, "Ca3 O6 W", "ca3wo6"),
    ("2002703", {"Mn": "Ca"}, "Ca3 O6 W", "ca3wo6"),
    # Same-composition monoclinic tungstate parents for matched comparison.
    ("9007617", {"Pb": "Ca"}, "Ca O4 W", "cawo4"),
    ("1546037", {"Sr": "Ca"}, "Ca O4 W", "cawo4"),
    ("1520645", {"Cd": "Ca"}, "Ca O4 W", "cawo4"),
    ("9013902", {"Mg": "Ca"}, "Ca O4 W", "cawo4"),
    ("1520641", {"Zn": "Ca"}, "Ca O4 W", "cawo4"),
]


def source_path(cod_id: str) -> Path:
    return SOURCE_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def symbol(value: object) -> str:
    match = re.match(r"([A-Z][a-z]?)", str(value))
    return match.group(1) if match else ""


def minimum_distances(structure: Structure) -> dict[str, float]:
    minima = {"Ca-O": 99.0, "W-O": 99.0, "O-O": 99.0, "all": 99.0}
    for i, site_a in enumerate(structure):
        for j in range(i + 1, len(structure)):
            site_b = structure[j]
            distance = structure.get_distance(i, j)
            minima["all"] = min(minima["all"], distance)
            element_a = max(site_a.species.items(), key=lambda item: item[1])[0].symbol
            element_b = max(site_b.species.items(), key=lambda item: item[1])[0].symbol
            pair = "-".join(sorted((element_a, element_b)))
            if pair == "Ca-O":
                minima["Ca-O"] = min(minima["Ca-O"], distance)
            elif pair == "O-W":
                minima["W-O"] = min(minima["W-O"], distance)
            elif pair == "O-O":
                minima["O-O"] = min(minima["O-O"], distance)
    return {key: round(value, 5) for key, value in minima.items()}


def write_mapped_cif(
    source: Path,
    target: Path,
    cod_id: str,
    substitutions: dict[str, str],
    formula: str,
) -> None:
    parser = CifParser(source)
    blocks = copy.deepcopy(parser._cif.data)
    for key, block in blocks.items():
        data = copy.deepcopy(block.data)
        loops = copy.deepcopy(block.loops)
        counters: dict[str, int] = {}
        mapped_labels = []
        for label in data["_atom_site_label"]:
            old = symbol(label)
            new = substitutions.get(old, old)
            if new != old:
                counters[new] = counters.get(new, 0) + 1
                mapped_labels.append(f"{new}{counters[new]}")
            else:
                mapped_labels.append(str(label))
        data["_atom_site_label"] = mapped_labels
        if "_atom_site_type_symbol" in data:
            data["_atom_site_type_symbol"] = [
                substitutions.get(symbol(item), symbol(item))
                for item in data["_atom_site_type_symbol"]
            ]
        for tag in list(data):
            if tag in {
                "_chemical_formula_weight",
                "_exptl_crystal_density_diffrn",
                "_cod_database_code",
            }:
                del data[tag]
            elif tag.startswith("_chemical_formula_"):
                data[tag] = formula
            elif tag.startswith("_geom_") or tag.startswith("_atom_type_"):
                del data[tag]
        loops = [[tag for tag in loop if tag in data] for loop in loops]
        loops = [loop for loop in loops if loop]
        mapping = ", ".join(f"{old}->{new}" for old, new in substitutions.items())
        data["_audit_creation_method"] = (
            f"Analogue-derived model from COD {cod_id}; {mapping}; "
            "source coordinates, cell, symmetry and setting retained"
        )
        blocks[key] = CifBlock(data, loops, f"mapped_from_COD_{cod_id}")
    target.write_text(
        str(
            CifFile(
                blocks,
                comment=(
                    f"# Analogue-derived model from COD {cod_id}; "
                    "coordinates and source setting retained."
                ),
            )
        )
    )


def main() -> None:
    outdir = Path(__file__).resolve().parent / "missing_analogues"
    outdir.mkdir(parents=True, exist_ok=True)
    records = []
    for cod_id, substitutions, formula, stem in SPECS:
        source = source_path(cod_id)
        target = outdir / f"{stem}_from_{cod_id}.cif"
        parent = Structure.from_file(source, primitive=False)
        write_mapped_cif(source, target, cod_id, substitutions, formula)
        mapped = Structure.from_file(target, primitive=False)
        record = {
            "candidate": str(target.relative_to(Path(__file__).resolve().parents[1])),
            "model_basis": "analogue_derived",
            "parent_cod_id": cod_id,
            "parent_path": str(source),
            "parent_formula": parent.composition.formula,
            "substitutions": substitutions,
            "mapped_formula": mapped.composition.formula,
            "space_group": mapped.get_space_group_info(),
            "cell": {
                "a": mapped.lattice.a,
                "b": mapped.lattice.b,
                "c": mapped.lattice.c,
                "alpha": mapped.lattice.alpha,
                "beta": mapped.lattice.beta,
                "gamma": mapped.lattice.gamma,
                "volume": mapped.volume,
            },
            "density_g_cm3": mapped.density,
            "minimum_distances_A": minimum_distances(mapped),
        }
        records.append(record)
        print(json.dumps(record, sort_keys=True))
    with (outdir / "provenance.json").open("w") as stream:
        json.dump({"schema_version": 1, "records": records}, stream, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    main()
