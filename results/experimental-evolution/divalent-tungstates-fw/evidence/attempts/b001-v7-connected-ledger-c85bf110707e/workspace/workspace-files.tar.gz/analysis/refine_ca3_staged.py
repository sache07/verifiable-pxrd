#!/usr/bin/env python3
"""Restage a Ca3WO6 A-site coordinate trial at low flexibility, then replay."""

from __future__ import annotations

import argparse
import copy
import json

from GSASII import GSASIIscriptable as G2sc

from build_inventory import clear_flags


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--phase", default="Ca3WO6")
    parser.add_argument("--a-site", default="Ca1")
    parser.add_argument("--b-site", default="Ca2")
    parser.add_argument("--w-site", default="W")
    parser.add_argument("--start", nargs=3, type=float)
    parser.add_argument("--weight", type=float, default=100.0)
    parser.add_argument(
        "--oxygen-block", action="store_true",
        help="After the A-site stage, refine the connected oxygen orbits at low flexibility",
    )
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.input, newgpx=args.out)
    hist = gpx.histogram(0)
    phase = gpx.phase(args.phase)
    controls = gpx.data["Controls"]["data"]
    controls["min dM/M"] = 1e-5

    state = {
        "background": hist.data["Background"][0][1],
        "instrument": {
            k: v[2] for k, v in hist.data["Instrument Parameters"][0].items()
            if isinstance(v, list) and len(v) >= 3 and isinstance(v[2], bool)
        },
        "sample": {
            k: v[1] for k, v in hist.data["Sample Parameters"].items()
            if isinstance(v, list) and len(v) >= 2 and isinstance(v[1], bool)
        },
        "phases": {},
    }
    for p in gpx.phases():
        hap = p.data["Histograms"][hist.name]
        state["phases"][p.name] = {
            "cell": p.data["General"]["Cell"][0],
            "atoms": {a.label: a.refinement_flags for a in p.atoms()},
            "scale": hap["Scale"][1],
            "po": hap["Pref.Ori."][2],
            "size2": copy.deepcopy(hap["Size"][2]),
            "size5": copy.deepcopy(hap["Size"][5]),
            "strain2": copy.deepcopy(hap["Mustrain"][2]),
            "strain5": copy.deepcopy(hap["Mustrain"][5]),
        }

    oxygens = [a.label for a in phase.atoms() if a.element == "O"]
    restraints = gpx.data.setdefault("Restraints", {"data": {}})["data"]
    restraints.setdefault(phase.name, {})
    restraints[phase.name]["Bond"] = {
        "wtFactor": args.weight, "Range": 1.1, "Bonds": [], "Use": True
    }
    phase.addDistRestraint([args.w_site], oxygens, 1.92, factor=1.35, ESD=0.08)
    phase.addDistRestraint([args.b_site], oxygens, 2.30, factor=1.30, ESD=0.12)
    phase.addDistRestraint([args.a_site], oxygens, 2.55, factor=1.30, ESD=0.20)
    phase.addDistRestraint(oxygens, oxygens, 2.70, factor=1.22, ESD=0.15)
    phase.addDistRestraint([args.a_site], [args.b_site], 3.30, factor=1.25, ESD=0.15)
    phase.addDistRestraint([args.a_site], [args.w_site], 3.35, factor=1.25, ESD=0.15)
    phase.addDistRestraint([args.b_site], [args.w_site], 3.30, factor=1.25, ESD=0.12)
    phase.setDistRestraintWeight(args.weight)

    clear_flags(gpx)
    if args.start:
        phase.atom(args.a_site).coordinates = args.start
    phase.set_refinements({"Atoms": {args.a_site: "X"}})
    phase.set_HAP_refinements({"Scale": True}, [hist])
    controls["max cyc"] = 25
    gpx.save()
    gpx.refine(makeBack=False)
    low = {
        "Rwp_percent": hist.get_wR(),
        "coordinates": list(phase.atom(args.a_site).coordinates),
        "Rvals": gpx.data["Covariance"]["data"]["Rvals"],
    }

    oxygen_stage = None
    if args.oxygen_block:
        phase.set_refinements({"Atoms": {label: "X" for label in oxygens}})
        controls["max cyc"] = 35
        gpx.save()
        gpx.refine(makeBack=False)
        oxygen_stage = {
            "Rwp_percent": hist.get_wR(),
            "coordinates": {
                label: list(phase.atom(label).coordinates) for label in oxygens
            },
            "Rvals": dict(gpx.data["Covariance"]["data"]["Rvals"]),
        }

    hist.data["Background"][0][1] = state["background"]
    for k, flag in state["instrument"].items():
        hist.data["Instrument Parameters"][0][k][2] = flag
    for k, flag in state["sample"].items():
        hist.data["Sample Parameters"][k][1] = flag
    for p in gpx.phases():
        saved = state["phases"][p.name]
        p.data["General"]["Cell"][0] = saved["cell"]
        for atom in p.atoms():
            atom.refinement_flags = saved["atoms"][atom.label]
        hap = p.data["Histograms"][hist.name]
        hap["Scale"][1] = saved["scale"]
        hap["Pref.Ori."][2] = saved["po"]
        hap["Size"][2] = saved["size2"]
        hap["Size"][5] = saved["size5"]
        hap["Mustrain"][2] = saved["strain2"]
        hap["Mustrain"][5] = saved["strain5"]
    phase.atom(args.a_site).refinement_flags = "X"
    if args.oxygen_block:
        for label in oxygens:
            phase.atom(label).refinement_flags = "X"
    controls["max cyc"] = 30
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    full = {
        "Rwp_percent": hist.get_wR(),
        "fractions": hist.ComputeMassFracs(),
        "coordinates": list(phase.atom(args.a_site).coordinates),
        "Rvals": gpx.data["Covariance"]["data"]["Rvals"],
    }
    print(json.dumps({
        "low_flex": low,
        "oxygen_stage": oxygen_stage,
        "full_replay": full,
    }, default=float, sort_keys=True))


if __name__ == "__main__":
    main()
