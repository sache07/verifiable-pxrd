#!/usr/bin/env python3
"""Remove coordinate-test restraints, freeze selected atoms, and replay a GPX."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--freeze-phase", action="append", default=[])
    parser.add_argument("--zero-inactive-hap", action="store_true")
    parser.add_argument("--cycles", type=int, default=30)
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.input, newgpx=args.out)
    hist = gpx.histogram(0)
    restraints = gpx.data.get("Restraints", {}).get("data", {})
    for phase_data in restraints.values():
        if isinstance(phase_data, dict):
            for restraint_data in phase_data.values():
                if isinstance(restraint_data, dict) and "Use" in restraint_data:
                    restraint_data["Use"] = False
    for name in args.freeze_phase:
        for atom in gpx.phase(name).atoms():
            atom.refinement_flags = " "
    if args.zero_inactive_hap:
        for phase in gpx.phases():
            hap = phase.data["Histograms"][hist.name]
            for key in ("Mustrain", "Size"):
                term = hap[key]
                if term[0] == "isotropic":
                    # Only the first scalar is used in this model. Remove stale
                    # values/refinement flags inherited from earlier trials.
                    term[1][1] = 0.0
                    term[2][1:] = [False] * (len(term[2]) - 1)
                    term[5] = [False] * len(term[5])
                elif term[0] == "uniaxial":
                    term[2][2:] = [False] * (len(term[2]) - 2)
                    term[5] = [False] * len(term[5])

    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = args.cycles
    controls["min dM/M"] = 1e-5
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    print(json.dumps({
        "Rwp_percent": hist.get_wR(),
        "GOF": gpx.data["Covariance"]["data"]["Rvals"].get("GOF"),
        "Rvals": gpx.data["Covariance"]["data"]["Rvals"],
        "fractions": hist.ComputeMassFracs(),
    }, default=float, sort_keys=True))


if __name__ == "__main__":
    main()
