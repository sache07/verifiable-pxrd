#!/usr/bin/env python3
"""Apply one controlled mechanism trial to an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json

import numpy as np

from GSASII import GSASIIscriptable as G2sc


def profile_screen(hist):
    inst = hist.data["Instrument Parameters"][0]
    t = np.tan(np.radians(np.linspace(5.0, 50.0, 181)))
    sig = inst["U"][1] * t**2 + inst["V"][1] * t + inst["W"][1]
    gam = inst["X"][1] / np.cos(np.arctan(t)) + inst["Y"][1] * t + inst["Z"][1]
    return {
        "sig_min": float(sig.min()),
        "sig_max": float(sig.max()),
        "gam_min": float(gam.min()),
        "gam_max": float(gam.max()),
        "passing": bool(np.all(sig > 0) and np.all(gam >= 0) and inst["SH/L"][1] > 0),
    }


def report(gpx, label):
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    try:
        fractions = hist.ComputeMassFracs()
    except Exception:
        fractions = {}
    out = {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": gpx.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "profile": profile_screen(hist),
        "instrument": {k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")},
        "sample": {k: sample[k][0] for k in ("Shift", "SurfRoughA", "SurfRoughB")},
        "fractions": fractions,
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    print("TRIAL", json.dumps(out, default=float, sort_keys=True))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--phase")
    parser.add_argument("--operation", required=True, choices=(
        "po", "size", "uniaxial-size", "strain", "uniaxial-strain",
        "cell", "coords", "uiso", "roughness", "polarization",
        "zero", "shift", "joint-angle", "instrument", "background", "reoptimize",
    ))
    parser.add_argument("--axis", nargs=3, type=int, default=[0, 0, 1])
    parser.add_argument("--parameters", nargs="*", default=[])
    parser.add_argument("--atoms", nargs="*", default=[])
    parser.add_argument("--background-type")
    parser.add_argument("--background-terms", type=int)
    parser.add_argument("--po-start", type=float, default=1.0)
    parser.add_argument("--hap-start", nargs=2, type=float)
    parser.add_argument(
        "--hap-refine", choices=("both", "equatorial", "axial"), default="both"
    )
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--clear-instrument", nargs="*", default=[])
    parser.add_argument("--clear-phase-size", action="store_true")
    parser.add_argument("--set", nargs="*", default=[], metavar="KEY=VALUE")
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.input, newgpx=args.out)
    hist = gpx.histogram(0)
    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = args.cycles
    controls["min dM/M"] = 1e-5
    inst = hist.data["Instrument Parameters"][0]
    for key in args.clear_instrument:
        inst[key][2] = False
    for item in args.set:
        key, raw = item.split("=", 1)
        value = float(raw)
        if key in inst:
            inst[key][1] = value
        elif key in hist.data["Sample Parameters"]:
            hist.data["Sample Parameters"][key][0] = value
        else:
            raise KeyError(key)

    phase = gpx.phase(args.phase) if args.phase else None
    if phase is not None and args.clear_phase_size:
        size = phase.data["Histograms"][hist.name]["Size"]
        size[0] = "isotropic"
        size[1][0] = 100.0
        size[2] = [False] * len(size[2])
        size[5] = [False] * len(size[5])
    if args.operation == "po":
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = args.po_start
        hap["Pref.Ori."][3] = list(args.axis)
        phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])
    elif args.operation == "size":
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 1.0, "refine": True}
        }, [hist])
    elif args.operation == "uniaxial-size":
        hap = phase.data["Histograms"][hist.name]
        size = hap["Size"]
        start = float(size[1][0])
        size[0] = "uniaxial"
        size[1][0], size[1][1] = args.hap_start or (start, start)
        size[2][0] = args.hap_refine in ("both", "equatorial")
        size[2][1] = args.hap_refine in ("both", "axial")
        size[3] = list(args.axis)
    elif args.operation == "strain":
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 1000.0
        phase.set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "refine": True}
        }, [hist])
    elif args.operation == "uniaxial-strain":
        hap = phase.data["Histograms"][hist.name]
        mustrain = hap["Mustrain"]
        mustrain[0] = "uniaxial"
        mustrain[1][0], mustrain[1][1] = args.hap_start or (1000.0, 1000.0)
        mustrain[2][0] = args.hap_refine in ("both", "equatorial")
        mustrain[2][1] = args.hap_refine in ("both", "axial")
        mustrain[3] = list(args.axis)
    elif args.operation == "cell":
        phase.set_refinements({"Cell": True})
    elif args.operation == "coords":
        if not args.atoms:
            raise ValueError("--atoms is required for coordinate refinement")
        phase.set_refinements({"Atoms": {label: "X" for label in args.atoms}})
    elif args.operation == "uiso":
        if not args.atoms:
            raise ValueError("--atoms is required for Uiso refinement")
        phase.set_refinements({"Atoms": {label: "U" for label in args.atoms}})
    elif args.operation == "roughness":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"][0] = 0.1
        sample["SurfRoughB"][0] = 0.1
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    elif args.operation == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif args.operation == "zero":
        hist.data["Sample Parameters"]["Shift"][1] = False
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    elif args.operation == "shift":
        inst["Zero"][2] = False
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    elif args.operation == "joint-angle":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    elif args.operation == "instrument":
        hist.set_refinements({"Instrument Parameters": args.parameters})
    elif args.operation == "background":
        current = hist.data["Background"][0]
        btype = args.background_type or current[0]
        nterms = args.background_terms or current[2]
        hist.set_refinements({"Background": {
            "type": btype,
            "refine": True,
            "no. coeffs": nterms,
            "coeffs": [current[3] if len(current) > 3 else 900.0] + [0.0] * (nterms - 1),
        }})
    elif args.operation == "reoptimize":
        pass

    gpx.save()
    gpx.refine(makeBack=False)
    report(gpx, f"{args.operation}:{args.phase or ''}:{args.axis}")
    gpx.save()


if __name__ == "__main__":
    main()
