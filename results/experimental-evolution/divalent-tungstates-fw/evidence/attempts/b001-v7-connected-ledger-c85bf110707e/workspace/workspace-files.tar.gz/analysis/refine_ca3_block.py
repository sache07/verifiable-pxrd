#!/usr/bin/env python3
"""Give a mapped double-perovskite finalist equal, restrained site blocks."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--phase", default="Ca3WO6")
    parser.add_argument("--a-site", required=True)
    parser.add_argument("--b-site", required=True)
    parser.add_argument("--w-site", required=True)
    parser.add_argument("--weight", type=float, default=100.0)
    parser.add_argument("--a-only", action="store_true")
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.input, newgpx=args.out)
    hist = gpx.histogram(0)
    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = 14
    controls["min dM/M"] = 1e-5

    phase = gpx.phase(args.phase)
    oxygens = [a.label for a in phase.atoms() if a.element == "O"]
    restraints = gpx.data.setdefault("Restraints", {"data": {}})["data"]
    restraints.setdefault(phase.name, {})
    restraints[phase.name]["Bond"] = {
        "wtFactor": args.weight, "Range": 1.1, "Bonds": [], "Use": True
    }
    counts = {}
    counts["W-O"] = phase.addDistRestraint(
        [args.w_site], oxygens, 1.92, factor=1.35, ESD=0.08
    )
    counts["B-Ca-O"] = phase.addDistRestraint(
        [args.b_site], oxygens, 2.30, factor=1.30, ESD=0.12
    )
    counts["A-Ca-O"] = phase.addDistRestraint(
        [args.a_site], oxygens, 2.55, factor=1.30, ESD=0.20
    )
    counts["O-O"] = phase.addDistRestraint(
        oxygens, oxygens, 2.70, factor=1.22, ESD=0.15
    )
    counts["A-B"] = phase.addDistRestraint(
        [args.a_site], [args.b_site], 3.30, factor=1.25, ESD=0.15
    )
    counts["A-W"] = phase.addDistRestraint(
        [args.a_site], [args.w_site], 3.35, factor=1.25, ESD=0.15
    )
    counts["B-W"] = phase.addDistRestraint(
        [args.b_site], [args.w_site], 3.30, factor=1.25, ESD=0.12
    )
    phase.setDistRestraintWeight(args.weight)

    phase.set_refinements({"Atoms": {args.a_site: "X"}})
    gpx.save()
    gpx.refine(makeBack=False)
    first = {"Rwp_percent": hist.get_wR(), "fractions": hist.ComputeMassFracs()}
    if args.a_only:
        gpx.save()
        print(json.dumps({
            "restraints": counts,
            "weight": args.weight,
            "a_site_stage": first,
            "coordinates": {a.label: list(a.coordinates) for a in phase.atoms()},
        }, default=float, sort_keys=True))
        return

    phase.set_refinements({"Atoms": {label: "X" for label in oxygens}})
    controls["max cyc"] = 18
    gpx.save()
    gpx.refine(makeBack=False)
    second = {"Rwp_percent": hist.get_wR(), "fractions": hist.ComputeMassFracs()}
    gpx.save()

    print(json.dumps({
        "restraints": counts,
        "weight": args.weight,
        "a_site_stage": first,
        "connected_oxygen_stage": second,
        "coordinates": {a.label: list(a.coordinates) for a in phase.atoms()},
    }, default=float, sort_keys=True))


if __name__ == "__main__":
    main()
