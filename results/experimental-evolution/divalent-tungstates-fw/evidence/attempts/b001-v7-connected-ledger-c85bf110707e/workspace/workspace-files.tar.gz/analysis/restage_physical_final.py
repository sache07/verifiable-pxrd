#!/usr/bin/env python3
"""Restage the four-phase model after replacing an extreme strain mechanism.

Accepted coordinates are retained at their current values but fixed. Profile,
cell and abundance terms are then added cumulatively from a low-flexibility
start so a failed all-at-once branch is not mistaken for a mechanism test.
"""

from __future__ import annotations

import argparse
import copy
import json

import numpy as np

from GSASII import GSASIIscriptable as G2sc

from build_inventory import clear_flags, profile_screen


def snapshot(gpx, stage):
    hist = gpx.histogram(0)
    return {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "Rvals": dict(gpx.data.get("Covariance", {}).get("data", {}).get("Rvals", {})),
        "fractions": hist.ComputeMassFracs(),
        "profile": profile_screen(hist),
        "phases": {
            p.name: {
                "cell": p.get_cell(),
                "scale": p.data["Histograms"][hist.name]["Scale"][0],
                "po": copy.deepcopy(p.data["Histograms"][hist.name]["Pref.Ori."]),
                "size": copy.deepcopy(p.data["Histograms"][hist.name]["Size"]),
                "strain": copy.deepcopy(p.data["Histograms"][hist.name]["Mustrain"]),
            }
            for p in gpx.phases()
        },
    }


def run(gpx, label, cycles=25):
    gpx.data["Controls"]["data"]["max cyc"] = cycles
    gpx.save()
    gpx.refine(makeBack=False)
    out = snapshot(gpx, label)
    print("STAGE", json.dumps(out, default=float, sort_keys=True))
    gpx.save()
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--phase-a", default="Ca3WO6")
    parser.add_argument("--phase-b", default="Ca3WO6_B")
    parser.add_argument("--a-strain", type=float, default=3300.0)
    parser.add_argument("--b-strain", type=float, default=None)
    parser.add_argument("--background-terms", type=int, default=None)
    parser.add_argument("--cycles", type=int, default=25)
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.input, newgpx=args.out)
    hist = gpx.histogram(0)
    phases = gpx.phases()
    controls = gpx.data["Controls"]["data"]
    controls["min dM/M"] = 1e-5
    controls["SVDtol"] = 1e-6

    if args.background_terms is not None:
        bg = hist.data["Background"][0]
        if args.background_terms < 1:
            raise ValueError("background order must be positive")
        old_coeffs = list(bg[3:])
        bg[2] = args.background_terms
        bg[3:] = (old_coeffs + [0.0] * args.background_terms)[:args.background_terms]

    # Preserve which mature model terms were supported before clearing flags.
    state = {
        "background": bool(hist.data["Background"][0][1]),
        "instrument": {
            key: bool(value[2])
            for key, value in hist.data["Instrument Parameters"][0].items()
            if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool)
        },
        "sample": {
            key: bool(value[1])
            for key, value in hist.data["Sample Parameters"].items()
            if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool)
        },
        "phases": {},
    }
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        state["phases"][phase.name] = {
            "cell": bool(phase.data["General"]["Cell"][0]),
            "po": bool(hap["Pref.Ori."][2]),
            "size2": copy.deepcopy(hap["Size"][2]),
            "size5": copy.deepcopy(hap["Size"][5]),
            "strain2": copy.deepcopy(hap["Mustrain"][2]),
            "strain5": copy.deepcopy(hap["Mustrain"][5]),
        }

    # Replace the extreme inherited A-population axial strain with isotropic
    # microstrain. The unused legacy slots are zeroed to make the project audit
    # unambiguous. B retains its already-supported isotropic mechanism.
    phase_a = gpx.phase(args.phase_a)
    phase_b = gpx.phase(args.phase_b)
    a_hap = phase_a.data["Histograms"][hist.name]
    a_hap["Mustrain"][0] = "isotropic"
    a_hap["Mustrain"][1] = [float(args.a_strain), 0.0, 1.0]
    a_hap["Mustrain"][2] = [True, False, False]
    a_hap["Mustrain"][5] = [False] * len(a_hap["Mustrain"][5])
    b_hap = phase_b.data["Histograms"][hist.name]
    b_hap["Mustrain"][0] = "isotropic"
    if args.b_strain is not None:
        b_hap["Mustrain"][1][0] = float(args.b_strain)
    b_hap["Mustrain"][1][1] = 0.0
    b_hap["Mustrain"][2] = [True, False, False]
    b_hap["Mustrain"][5] = [False] * len(b_hap["Mustrain"][5])

    clear_flags(gpx)
    # Stage 1: abundance and the replacement broadening terms only.
    for phase in phases:
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    a_hap["Mustrain"][2][0] = True
    b_hap["Mustrain"][2][0] = True
    stages = [run(gpx, "scales_and_ca3_strain", args.cycles)]

    # Stage 2: lattice metrics and all previously supported phase-specific
    # texture/size/strain mechanisms. Atom coordinates stay fixed here.
    for phase in phases:
        saved = state["phases"][phase.name]
        phase.data["General"]["Cell"][0] = saved["cell"]
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][2] = saved["po"]
        hap["Size"][2] = saved["size2"]
        hap["Size"][5] = saved["size5"]
        if phase.name not in (args.phase_a, args.phase_b):
            hap["Mustrain"][2] = saved["strain2"]
            hap["Mustrain"][5] = saved["strain5"]
    stages.append(run(gpx, "phase_profile_and_cells", args.cycles))

    # Stages 3-5 add the potentially correlated global mechanisms separately.
    hist.data["Background"][0][1] = state["background"]
    stages.append(run(gpx, "add_background", args.cycles))
    for key, flag in state["instrument"].items():
        hist.data["Instrument Parameters"][0][key][2] = flag
    stages.append(run(gpx, "add_instrument", args.cycles))
    for key, flag in state["sample"].items():
        hist.data["Sample Parameters"][key][1] = flag
    stages.append(run(gpx, "add_sample", max(args.cycles, 30)))

    # One independent replay from the saved endpoint checks that calculation,
    # fractions and active mechanism remain stationary.
    stages.append(run(gpx, "independent_replay", max(args.cycles, 20)))
    print("FINAL", json.dumps(stages[-1], default=float, sort_keys=True))


if __name__ == "__main__":
    main()
