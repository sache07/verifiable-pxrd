#!/usr/bin/env python3
"""Build a stable, coordinate-fixed three-phase GSAS-II inventory model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]
COD = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/"
    "resources/b001-c05/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def normalize_uiso(phase, value=0.01):
    """Set a common physical isotropic displacement model for source fairness."""
    cia = phase.data["General"]["AtomPtrs"][3]
    for atom in phase.data["Atoms"]:
        atom[cia] = "I"
        atom[cia + 1] = float(value)
        for idx in range(cia + 2, min(cia + 8, len(atom) - 1)):
            atom[idx] = 0.0


def set_cell(phase, cell):
    phase.data["General"]["Cell"][1:7] = [float(v) for v in cell]
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def clear_flags(gpx):
    hist = gpx.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def profile_screen(hist):
    inst = hist.data["Instrument Parameters"][0]
    theta = np.radians(np.linspace(5.0, 50.0, 181))
    tan = np.tan(theta)
    sig = inst["U"][1] * tan**2 + inst["V"][1] * tan + inst["W"][1]
    gam = inst["X"][1] / np.cos(theta) + inst["Y"][1] * tan + inst["Z"][1]
    return {
        "gaussian_term_min": float(sig.min()),
        "gaussian_term_max": float(sig.max()),
        "lorentzian_term_min": float(gam.min()),
        "lorentzian_term_max": float(gam.max()),
        "passing": bool(np.all(sig > 0.0) and np.all(gam >= 0.0) and inst["SH/L"][1] > 0.0),
    }


def snapshot(gpx, label):
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    try:
        fractions = hist.ComputeMassFracs()
    except Exception:
        fractions = {}
    data = {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": gpx.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "profile_screen": profile_screen(hist),
        "instrument": {key: inst[key][1] for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")},
        "sample": {key: sample[key][0] for key in ("Shift", "SurfRoughA", "SurfRoughB")},
        "phases": {},
        "mass_fractions": fractions,
    }
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        data["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
        }
    print("SNAPSHOT", json.dumps(data, default=float, sort_keys=True))
    return data


def refine(gpx, label):
    gpx.refine(makeBack=False)
    snapshot(gpx, label)
    gpx.save()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    parser.add_argument("--wo3-id", default="1528915")
    parser.add_argument("--ca3-id", required=True)
    parser.add_argument("--background-type", default="chebyschev-1")
    parser.add_argument("--background-terms", type=int, default=12)
    parser.add_argument("--angular", choices=("zero", "shift", "joint"), default="zero")
    parser.add_argument("--profile-start", choices=("A", "B", "C"), default="A")
    parser.add_argument("--ca3-cell-mode", choices=("fixed", "full"), default="full")
    parser.add_argument("--common-u", action="store_true")
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()

    starts = {
        "A": {"U": 80.0, "V": 0.0, "W": 20.0, "X": 4.0, "Y": 0.0, "SH/L": 0.02},
        "B": {"U": 180.0, "V": -20.0, "W": 30.0, "X": 2.0, "Y": 0.0, "SH/L": 0.01},
        "C": {"U": 30.0, "V": 20.0, "W": 15.0, "X": 8.0, "Y": 0.0, "SH/L": 0.04},
    }

    out = Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(Path(__file__).resolve().parent / "cu_ka.instprm"),
        fmthint="comma",
    )
    phases = [
        gpx.add_phase(str(cod_path("7219229")), phasename="CaWO4", histograms=[hist]),
        gpx.add_phase(str(cod_path(args.wo3_id)), phasename="WO3", histograms=[hist]),
        gpx.add_phase(
            str(ROOT / "analysis" / "analogues" / f"ca3wo6_from_{args.ca3_id}.cif"),
            phasename="Ca3WO6",
            histograms=[hist],
        ),
    ]
    clear_flags(gpx)
    for phase in phases:
        normalize_uiso(phase, 0.01)

    # Adapt only the missing-composition analogue cell from indexed residuals;
    # retain all inherited coordinates for this inventory-stage comparison.
    ca3 = phases[2]
    sg = ca3.data["General"]["SGData"]["SGSys"]
    if sg == "cubic":
        set_cell(ca3, [8.00, 8.00, 8.00, 90.0, 90.0, 90.0])
    elif sg == "tetragonal":
        set_cell(ca3, [5.66, 5.66, 8.00, 90.0, 90.0, 90.0])
    else:
        set_cell(ca3, [5.68, 5.65, 7.90, 90.0, 90.0, 90.0])

    hist.data["Sample Parameters"]["Scale"][1] = False
    for key, value in starts[args.profile_start].items():
        hist.data["Instrument Parameters"][0][key][1] = value
    hist.set_refinements({
        "Background": {
            "type": args.background_type,
            "refine": True,
            "no. coeffs": args.background_terms,
            "coeffs": [900.0] + [0.0] * (args.background_terms - 1),
        }
    })
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])

    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = args.cycles
    controls["min dM/M"] = 1e-5
    controls["SVDtol"] = 1e-6
    gpx.save()

    refine(gpx, "background_scales")
    cell_phases = phases if args.ca3_cell_mode == "full" else phases[:2]
    for phase in cell_phases:
        phase.set_refinements({"Cell": True})
        refine(gpx, f"add_cell_{phase.name}")
    
    if args.angular in {"zero", "joint"}:
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        refine(gpx, "add_zero")
    if args.angular in {"shift", "joint"}:
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        refine(gpx, "add_specimen_shift")

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine(gpx, "add_common_WX")
    if args.common_u:
        hist.set_refinements({"Instrument Parameters": ["U"]})
        refine(gpx, "add_common_U")
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    refine(gpx, "add_axial_divergence")
    gpx.save()


if __name__ == "__main__":
    main()
