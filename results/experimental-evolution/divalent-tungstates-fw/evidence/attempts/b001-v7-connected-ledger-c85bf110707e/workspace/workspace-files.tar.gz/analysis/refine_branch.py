#!/usr/bin/env python3
"""Create and stage a conservative GSAS-II refinement for candidate phases.

This is an exploratory helper. It keeps coordinates fixed and supports only
public inputs plus explicitly supplied CIF files.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


def set_controls(gpx, cycles=8):
    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = cycles
    controls["min dM/M"] = 1e-5
    controls["SVDtol"] = 1e-6


def summary(gpx, label):
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    samp = hist.data["Sample Parameters"]
    out = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "GOF": gpx.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "instrument": {k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.") if k in inst},
        "sample": {k: samp[k][0] for k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB") if k in samp},
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    print("STAGE", json.dumps(out, default=float, sort_keys=True))
    return out


def run_stage(gpx, label):
    try:
        gpx.refine(makeBack=False)
    except Exception as exc:
        print(f"FAILED_STAGE {label}: {type(exc).__name__}: {exc}")
        raise
    summary(gpx, label)
    gpx.save()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    parser.add_argument("--phase", action="append", nargs=2, metavar=("NAME", "CIF"), required=True)
    parser.add_argument("--background-terms", type=int, default=12)
    parser.add_argument("--background-type", default="chebyschev-1")
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--profile", action="store_true", help="refine U,V,W,X and SH/L after scales/cells/zero")
    parser.add_argument("--size", action="store_true", help="refine isotropic size for each phase")
    parser.add_argument("--strain", action="store_true", help="refine isotropic microstrain for each phase")
    args = parser.parse_args()

    out = Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    root = Path(__file__).resolve().parents[1]
    pattern = root / "inputs" / "pattern.csv"
    instprm = Path(__file__).resolve().parent / "cu_ka.instprm"

    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(str(pattern), str(instprm), fmthint="comma")
    hist.data["Sample Parameters"]["Scale"][1] = False
    hist.set_refinements({
        "Background": {
            "type": args.background_type,
            "refine": True,
            "no. coeffs": args.background_terms,
            "coeffs": [900.0] + [0.0] * (args.background_terms - 1),
        }
    })
    for name, cif in args.phase:
        phase = gpx.add_phase(str(Path(cif).resolve()), phasename=name, histograms=[hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
    set_controls(gpx, cycles=args.cycles)
    gpx.save()

    run_stage(gpx, "background_scales")

    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    run_stage(gpx, "cells")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_stage(gpx, "zero")

    if args.profile:
        hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X"]})
        run_stage(gpx, "profile_UVWX")
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        run_stage(gpx, "profile_axial")

    if args.size:
        for phase in gpx.phases():
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
        run_stage(gpx, "isotropic_size")

    if args.strain:
        for phase in gpx.phases():
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
        run_stage(gpx, "isotropic_strain")

    gpx.save()


if __name__ == "__main__":
    main()
