#!/usr/bin/env python3
"""Refine a connected coordinate block with soft distance restraints."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--origins", nargs="+", required=True)
    parser.add_argument("--targets", nargs="+", required=True)
    parser.add_argument("--atoms", nargs="+", required=True)
    parser.add_argument("--bond", type=float, required=True)
    parser.add_argument("--factor", type=float, default=1.3)
    parser.add_argument("--esd", type=float, default=0.12)
    parser.add_argument("--weight", type=float, default=1.0)
    parser.add_argument("--cycles", type=int, default=16)
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.input, newgpx=args.out)
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for key, value in (("U", 0.0), ("V", 0.0), ("SH/L", 0.02)):
        inst[key][1] = value
        inst[key][2] = False

    phase = gpx.phase(args.phase)
    restraints = gpx.data.setdefault("Restraints", {"data": {}})["data"]
    restraints.setdefault(phase.name, {})
    restraints[phase.name].setdefault(
        "Bond", {"wtFactor": 1.0, "Range": 1.1, "Bonds": [], "Use": True}
    )
    phase.clearDistRestraint()
    count = phase.addDistRestraint(
        args.origins,
        args.targets,
        args.bond,
        factor=args.factor,
        ESD=args.esd,
    )
    phase.setDistRestraintWeight(args.weight)
    phase.set_refinements({"Atoms": {label: "X" for label in args.atoms}})

    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = args.cycles
    controls["min dM/M"] = 1e-5
    gpx.save()
    gpx.refine(makeBack=False)
    fractions = hist.ComputeMassFracs()
    print(json.dumps({
        "restraints_added": count,
        "Rwp_percent": hist.get_wR(),
        "fractions": fractions,
        "coordinates": {
            atom.label: list(atom.coordinates)
            for atom in phase.atoms()
            if atom.label in args.atoms or atom.label in args.origins
        },
    }, default=float, sort_keys=True))
    gpx.save()


if __name__ == "__main__":
    main()
