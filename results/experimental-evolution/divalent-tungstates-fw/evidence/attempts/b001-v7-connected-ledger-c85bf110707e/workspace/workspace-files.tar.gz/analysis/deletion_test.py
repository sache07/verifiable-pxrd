#!/usr/bin/env python3
"""Disable one phase, re-equilibrate the remaining model, and report the loss."""

from __future__ import annotations

import argparse
import json

import numpy as np
from scipy.signal import find_peaks

from GSASII import GSASIIscriptable as G2sc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--cycles", type=int, default=50)
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.input, newgpx=args.out)
    hist = gpx.histogram(0)
    hap = gpx.phase(args.phase).data["Histograms"][hist.name]
    hap["Use"] = False
    hap["Scale"][1] = False
    if args.prepare_only:
        gpx.save()
        print(json.dumps({"deleted": args.phase, "prepared": True}))
        return
    gpx.data["Controls"]["data"]["max cyc"] = args.cycles
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-5
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()

    data = hist.data["data"][1]
    x, obs, calc = data[0], data[1], data[3]
    z = (obs - calc) / np.sqrt(np.maximum(obs, 1.0))
    idx, _ = find_peaks(z, prominence=2.5, distance=8)
    idx = idx[np.argsort(z[idx])[-12:]][::-1]
    print(json.dumps({
        "deleted": args.phase,
        "Rwp_percent": hist.get_wR(),
        "Rvals": gpx.data["Covariance"]["data"]["Rvals"],
        "fractions": hist.ComputeMassFracs(),
        "largest_positive_residuals": [
            {"two_theta": float(x[i]), "sigma": float(z[i])} for i in idx
        ],
    }, default=float, sort_keys=True))


if __name__ == "__main__":
    main()
