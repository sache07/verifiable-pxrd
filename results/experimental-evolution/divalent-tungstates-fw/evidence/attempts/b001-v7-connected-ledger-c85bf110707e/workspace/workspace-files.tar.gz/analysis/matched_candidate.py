#!/usr/bin/env python3
"""Run an equal-flexibility cumulative refinement for a Ca3WO6 analogue."""

from __future__ import annotations

import argparse
import contextlib
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from build_inventory import ROOT, clear_flags, cod_path, normalize_uiso, profile_screen, set_cell


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--cycles", type=int, default=9)
    parser.add_argument("--wo3-id", default="2311041")
    parser.add_argument("--wo3-axis", nargs=3, type=int)
    parser.add_argument("--skip-wo3-coords", action="store_true")
    parser.add_argument("--skip-ca3-po", action="store_true")
    parser.add_argument("--skip-ca3-size", action="store_true")
    parser.add_argument("--angular", choices=("shift", "zero", "joint"), default="shift")
    parser.add_argument("--zero-start", type=float)
    parser.add_argument("--background-terms", type=int, default=16)
    parser.add_argument("--refine-ca3-cell", action="store_true")
    parser.add_argument("--refine-shl", action="store_true")
    parser.add_argument("--cawo4-strain", action="store_true")
    args = parser.parse_args()

    out = Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    log_path = out.with_suffix(".run.log")
    stages = []

    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "analysis" / "cu_ka.instprm"),
        fmthint="comma",
    )
    cawo4 = gpx.add_phase(str(cod_path("7219229")), phasename="CaWO4", histograms=[hist])
    wo3 = gpx.add_phase(str(cod_path(args.wo3_id)), phasename="WO3", histograms=[hist])
    ca3 = gpx.add_phase(
        str(ROOT / "analysis" / "analogues" / f"ca3wo6_from_{args.candidate}.cif"),
        phasename="Ca3WO6",
        histograms=[hist],
    )
    clear_flags(gpx)
    for phase in gpx.phases():
        normalize_uiso(phase, 0.01)

    system = ca3.data["General"]["SGData"]["SGSys"]
    if system == "cubic":
        set_cell(ca3, [8.00, 8.00, 8.00, 90.0, 90.0, 90.0])
    elif system == "tetragonal":
        set_cell(ca3, [5.66, 5.66, 8.00, 90.0, 90.0, 90.0])
    else:
        set_cell(ca3, [5.68, 5.65, 7.90, 90.0, 90.0, 90.0])

    inst = hist.data["Instrument Parameters"][0]
    for key, value in (("U", 0.0), ("V", 0.0), ("W", 12.0), ("X", 8.0),
                       ("Y", 0.0), ("SH/L", 0.02), ("Zero", 0.0)):
        inst[key][1] = value
        inst[key][2] = False
    sample = hist.data["Sample Parameters"]
    sample["Shift"] = [200.0 if args.angular == "shift" else (150.0 if args.angular == "joint" else 0.0), False]
    if args.zero_start is not None:
        inst["Zero"][1] = args.zero_start
    else:
        inst["Zero"][1] = 0.05 if args.angular == "joint" else (0.1 if args.angular == "zero" else 0.0)
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    hist.set_refinements({"Background": {
        "type": "chebyschev-1",
        "refine": True,
        "no. coeffs": args.background_terms,
        "coeffs": [900.0] + [0.0] * (args.background_terms - 1),
    }})
    for phase in gpx.phases():
        phase.set_HAP_refinements({"Scale": True}, [hist])
    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = args.cycles
    controls["min dM/M"] = 1e-5
    controls["SVDtol"] = 1e-6

    def refine(label):
        gpx.save()
        gpx.refine(makeBack=False)
        stages.append({"stage": label, "Rwp_percent": hist.get_wR()})

    with log_path.open("w") as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        refine("background_scales")
        cawo4.set_refinements({"Cell": True})
        wo3.set_refinements({"Cell": True})
        if args.refine_ca3_cell:
            ca3.set_refinements({"Cell": True})
        refine("major_cells")
        if args.angular in {"zero", "joint"}:
            hist.set_refinements({"Instrument Parameters": ["Zero"]})
        if args.angular in {"shift", "joint"}:
            hist.set_refinements({"Sample Parameters": ["Shift"]})
        refine(f"angular_{args.angular}")
        hist.set_refinements({"Instrument Parameters": ["W", "X"]})
        refine("common_WX")
        if args.refine_shl:
            inst["SH/L"][1] = 0.05
            hist.set_refinements({"Instrument Parameters": ["SH/L"]})
            refine("axial_divergence")

        if args.wo3_axis is not None:
            wo3_axis = args.wo3_axis
        elif args.wo3_id == "2311041":
            wo3_axis = [1, 0, -1]
        else:
            wo3_axis = [0, 0, 1]
        po_trials = [(wo3, wo3_axis)]
        if not args.skip_ca3_po:
            po_trials.append((ca3, [0, 0, 1]))
        po_trials.append((cawo4, [1, 1, 0]))
        for phase, axis in po_trials:
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][3] = axis
            phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])
            refine(f"po_{phase.name}")

        size_trials = [wo3]
        if not args.skip_ca3_size:
            size_trials.append(ca3)
        for phase in size_trials:
            phase.set_HAP_refinements({
                "Size": {"type": "isotropic", "value": 1.0, "refine": True}
            }, [hist])
            refine(f"size_{phase.name}")

        if args.cawo4_strain:
            mustrain = cawo4.data["Histograms"][hist.name]["Mustrain"]
            mustrain[0] = "uniaxial"
            mustrain[1][0] = 650.0
            mustrain[1][1] = 780.0
            mustrain[2][0] = True
            mustrain[2][1] = True
            mustrain[3] = [0, 0, 1]
            refine("strain_CaWO4")

        sample["SurfRoughA"][0] = 0.35
        sample["SurfRoughB"][0] = 0.30
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        refine("roughness")

        cawo4.set_refinements({"Atoms": {"O1": "X"}})
        refine("coord_CaWO4_O")
        if not args.skip_wo3_coords:
            wlabels = [atom.label for atom in wo3.atoms() if atom.element == "W"]
            wo3.set_refinements({"Atoms": {label: "X" for label in wlabels}})
            refine("coord_WO3_W")

    gpx.save()
    fractions = hist.ComputeMassFracs()
    result = {
        "candidate": args.candidate,
        "space_group": ca3.data["General"]["SGData"]["SpGrp"],
        "Rwp_percent": hist.get_wR(),
        "GOF": gpx.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "profile": profile_screen(hist),
        "fractions": fractions,
        "ca3_cell": ca3.get_cell(),
        "ca3_po": ca3.data["Histograms"][hist.name]["Pref.Ori."],
        "ca3_size": ca3.data["Histograms"][hist.name]["Size"],
        "stages": stages,
        "log": str(log_path),
    }
    print(json.dumps(result, default=float, sort_keys=True))


if __name__ == "__main__":
    main()
