#!/usr/bin/env python3
"""Compare angular and common-profile nuisance branches with physical checks."""

from __future__ import annotations

import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
OUT = ANALYSIS / "nuisance_branches"


def caglioti_min(inst):
    theta = np.linspace(5.0, 50.0, 1000)
    tanth = np.tan(np.deg2rad(theta))
    return float(
        np.min(inst["U"][1] * tanth**2 + inst["V"][1] * tanth + inst["W"][1])
    )


def state(project, hist, label):
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size_um": float(hap["Size"][1][0]),
            "mustrain_ppm": float(hap["Mustrain"][1][0]),
        }
    physical = {
        "caglioti_variance_min": caglioti_min(inst),
        "SH_L_nonnegative": bool(inst["SH/L"][1] >= 0),
        "U_nonnegative": bool(inst["U"][1] >= 0),
        "W_nonnegative": bool(inst["W"][1] >= 0),
        "X_nonnegative": bool(inst["X"][1] >= 0),
        "polarization_in_unit_interval": bool(0 <= inst["Polariz."][1] <= 1),
        "roughness_A_in_unit_interval": bool(0 <= sample["SurfRoughA"][0] <= 1),
        "roughness_B_nonnegative": bool(sample["SurfRoughB"][0] >= 0),
    }
    return copy.deepcopy(
        {
            "label": label,
            "Rwp_percent": hist.get_wR(),
            "residuals": hist.residuals,
            "instrument": {
                key: value[1]
                for key, value in inst.items()
                if isinstance(value, list)
            },
            "sample": {
                key: value[0]
                for key, value in sample.items()
                if isinstance(value, list) and len(value) == 2
            },
            "phases": phases,
            "physical": physical,
        }
    )


def refine(project, listing):
    project.refine(printFile=str(listing))


def run(mode):
    OUT.mkdir(parents=True, exist_ok=True)
    gpx = OUT / f"{mode}.gpx"
    listing = OUT / f"{mode}.lst"
    project = G2sc.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(
        str(ANALYSIS / "pattern.xye"),
        str(ANALYSIS / "cu_ka.instprm"),
        fmthint="xye",
    )
    cawo4 = project.add_phase(
        str(ANALYSIS / "models" / "cawo4_scheelite_7219229.cif"),
        phasename="CaWO4_scheelite",
        histograms=[hist],
        fmthint="CIF",
    )
    wo3 = project.add_phase(
        str(ANALYSIS / "models" / "wo3_monoclinic_1528915.cif"),
        phasename="WO3_monoclinic",
        histograms=[hist],
        fmthint="CIF",
    )
    project.data["Controls"]["data"].update(
        {"max cyc": 12, "min dM/M": 1e-5, "shift factor": 0.35}
    )
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {
        "U": 20.0,
        "V": -2.0,
        "W": 20.0,
        "X": 2.0,
        "SH/L": 0.02,
    }.items():
        inst[key][1] = value
    for phase, scale in ((cawo4, 1.0), (wo3, 0.3)):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][0] = scale
        hap["Size"][1][0] = 0.2
        hap["Mustrain"][1][0] = 1000.0

    project.set_refinement(
        {
            "set": {
                "Background": {
                    "type": "chebyschev-1",
                    "no. coeffs": 8,
                    "coeffs": [1100.0, -550.0, 150.0, -50.0, 0.0, 0.0, 0.0, 0.0],
                    "refine": True,
                },
                "Scale": True,
            }
        }
    )
    refine(project, listing)
    states = [state(project, hist, "background_scales")]

    if mode == "zero":
        inst["Zero"][1] = -0.12
        angular = {"Instrument Parameters": ["Zero"]}
    elif mode == "shift":
        hist.data["Sample Parameters"]["Shift"][0] = 220.0
        angular = {"Sample Parameters": ["Shift"]}
    elif mode == "joint":
        inst["Zero"][1] = -0.02
        hist.data["Sample Parameters"]["Shift"][0] = 180.0
        angular = {
            "Instrument Parameters": ["Zero"],
            "Sample Parameters": ["Shift"],
        }
    else:
        raise ValueError(mode)
    angular["Cell"] = True
    project.set_refinement({"set": angular})
    refine(project, listing)
    states.append(state(project, hist, "angular_cells"))

    # V is held at a modest value to keep the Caglioti function positive;
    # phase-specific broadening is introduced only after this branch screen.
    project.set_refinement(
        {"set": {"Instrument Parameters": ["U", "W", "X", "SH/L"]}}
    )
    refine(project, listing)
    states.append(state(project, hist, "common_profile"))

    # Mechanism-complete intensity nuisance pass.
    hist.data["Sample Parameters"]["SurfRoughA"][0] = 0.15
    hist.data["Sample Parameters"]["SurfRoughB"][0] = 0.08
    project.set_refinement(
        {
            "set": {
                "Sample Parameters": ["SurfRoughA", "SurfRoughB"],
                "Instrument Parameters": ["Polariz."],
            }
        }
    )
    refine(project, listing)
    states.append(state(project, hist, "roughness_polarization"))
    project.save()
    try:
        fractions = hist.ComputeMassFracs()
    except Exception as exc:
        fractions = {"error": repr(exc)}
    result = {
        "mode": mode,
        "project": str(gpx),
        "states": states,
        "mass_fractions": fractions,
    }
    with (OUT / f"{mode}.json").open("w") as handle:
        json.dump(result, handle, indent=2)
    return result


def main():
    results = [run(mode) for mode in ("zero", "shift", "joint")]
    summary = {
        item["mode"]: {
            "Rwp_percent": item["states"][-1]["Rwp_percent"],
            "physical": item["states"][-1]["physical"],
            "instrument": item["states"][-1]["instrument"],
            "sample": item["states"][-1]["sample"],
            "fractions": item["mass_fractions"],
        }
        for item in results
    }
    with (OUT / "summary.json").open("w") as handle:
        json.dump(summary, handle, indent=2)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
