#!/usr/bin/env python3
"""Matched profile-mechanism screens for the selected two-phase model.

Each trial starts from the same re-equilibrated physical project.  The purpose
is model selection, so trial projects are retained for inspection rather than
automatically folded into the final model.
"""

from __future__ import annotations

import json
import math
import re
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
OUT = ANALYSIS / "final_mechanism_screen"
SOURCE = (
    ANALYSIS
    / "coordinate_parent_compare"
    / "monoclinic_2311041"
    / "refined.gpx"
)


def safe_tag(text):
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", text).strip("_")


def configure_supported_flags(project):
    """Set the final supported nuisance flags and no coordinate variables."""
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True

    inst = hist.data["Instrument Parameters"][0]
    for key, item in inst.items():
        if isinstance(item, list) and len(item) >= 3:
            item[2] = False
    # Keep the physically selected profile branch fixed where required.
    inst["U"][1], inst["U"][2] = 10.0, False
    inst["V"][1], inst["V"][2] = 0.0, False
    inst["Zero"][1], inst["Zero"][2] = 0.0, False

    sample = hist.data["Sample Parameters"]
    for key, item in sample.items():
        if isinstance(item, list) and len(item) == 2 and isinstance(item[1], bool):
            item[1] = key == "Shift"
    sample["Scale"] = [1.0, False]
    sample["SurfRoughA"] = [0.10, False]

    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [False, False, False]
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2] = [True, False, False]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])

    project.data["Controls"]["data"].update(
        {"max cyc": 15, "min dM/M": 1e-5, "shift factor": 0.15}
    )


def state(project, label):
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    theta = np.linspace(5.0, 50.0, 1000)
    tanth = np.tan(np.deg2rad(theta))
    caglioti = (
        inst["U"][1] * tanth**2 + inst["V"][1] * tanth + inst["W"][1]
    )
    phases = {}
    broadening_ok = True
    po_ok = True
    uiso_ok = True
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        size = list(map(float, hap["Size"][1]))
        strain = list(map(float, hap["Mustrain"][1]))
        if hap["Size"][0] == "uniaxial":
            broadening_ok &= size[0] > 0 and size[1] > 0
        else:
            broadening_ok &= size[0] > 0
        if hap["Mustrain"][0] == "uniaxial":
            broadening_ok &= strain[0] >= 0 and strain[1] >= 0
        else:
            broadening_ok &= strain[0] >= 0
        po = hap["Pref.Ori."]
        po_ok &= (not po[2]) or (0.2 <= float(po[1]) <= 5.0)
        atom_data = {}
        for atom in phase.atoms():
            atom_data[atom.label] = {
                "element": atom.element,
                "uiso": float(atom.uiso),
                "flags": atom.refinement_flags,
            }
            uiso_ok &= 0.0 <= float(atom.uiso) <= 0.10
        phases[phase.name] = {
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size": {"type": hap["Size"][0], "values": size, "axis": hap["Size"][3]},
            "mustrain": {
                "type": hap["Mustrain"][0],
                "values": strain,
                "axis": hap["Mustrain"][3],
            },
            "preferred_orientation": {
                "model": po[0],
                "ratio": float(po[1]),
                "refine": bool(po[2]),
                "axis": list(po[3]),
            },
            "atoms": atom_data,
        }
    data = hist.data["data"][1]
    background_min = float(np.nanmin(np.asarray(data[4], dtype=float)))
    fractions = {
        key: [float(value[0]), float(value[1])]
        for key, value in hist.ComputeMassFracs().items()
    }
    physical = {
        "common_profile": bool(
            np.min(caglioti) > 0
            and inst["X"][1] >= 0
            and inst["SH/L"][1] >= 0
        ),
        "polarization": bool(0 <= inst["Polariz."][1] <= 1),
        "roughness": bool(
            0 <= sample["SurfRoughA"][0] <= 1
            and sample["SurfRoughB"][0] >= 0
        ),
        "broadening": bool(broadening_ok),
        "preferred_orientation": bool(po_ok),
        "uiso": bool(uiso_ok),
        "background_nonnegative": bool(background_min >= 0),
        "nonsingular": bool(rvals.get("SVD0", 0) == 0),
    }
    physical["all"] = all(physical.values())
    return {
        "label": label,
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": float(hist.residuals.get("R", math.nan)),
        "wRmin_percent": float(hist.residuals.get("wRmin", math.nan)),
        "GOF": float(rvals.get("GOF", math.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "Nvars": rvals.get("Nvars"),
        "fractions": fractions,
        "background": {
            "type": hist.data["Background"][0][0],
            "ncoeff": int(hist.data["Background"][0][2]),
            "coefficients": list(map(float, hist.data["Background"][0][3:])),
            "minimum_calculated": background_min,
        },
        "instrument": {
            key: float(value[1])
            for key, value in inst.items()
            if isinstance(value, list) and isinstance(value[1], (int, float))
        },
        "sample": {
            key: float(value[0])
            for key, value in sample.items()
            if isinstance(value, list)
            and len(value) == 2
            and isinstance(value[0], (int, float))
        },
        "phases": phases,
        "physical": physical,
    }


def refine(project, listing):
    project.refine(printFile=str(listing))


def make_baseline():
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / "baseline.gpx"
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(target))
    configure_supported_flags(project)
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    stages = []

    # Re-equilibrate common profile/intensity terms with phase broadening fixed.
    for key in ("W", "X", "SH/L", "Polariz."):
        inst[key][2] = True
    sample["SurfRoughB"][1] = True
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][2] = [False, False, False]
    refine(project, OUT / "baseline_profile.lst")
    stages.append(state(project, "profile_re_equilibration"))

    # Phase size and strain overlap common profile width if all are floated at
    # once. Alternate physically distinct blocks and finish with strain active.
    for key in ("W", "X", "SH/L", "Polariz."):
        inst[key][2] = False
    sample["SurfRoughB"][1] = False
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [True, False, False]
    refine(project, OUT / "baseline_size.lst")
    stages.append(state(project, "size_re_equilibration"))

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [True, False, False]
    refine(project, OUT / "baseline_strain.lst")
    stages.append(state(project, "strain_re_equilibration"))

    # One alternating repeat tests that the calculated profile is stable.
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Mustrain"][2] = [False, False, False]
    for key in ("W", "X", "SH/L", "Polariz."):
        inst[key][2] = True
    sample["SurfRoughB"][1] = True
    refine(project, OUT / "baseline_profile_repeat.lst")
    stages.append(state(project, "profile_repeat"))

    for key in ("W", "X", "SH/L", "Polariz."):
        inst[key][2] = False
    sample["SurfRoughB"][1] = False
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Mustrain"][2] = [True, False, False]
    refine(project, OUT / "baseline_strain_repeat.lst")
    stages.append(state(project, "strain_repeat"))
    project.save(str(target))
    answer = state(project, "baseline")
    answer["stages"] = stages
    return answer


def branch(name, mutate):
    tag = safe_tag(name)
    target = OUT / f"{tag}.gpx"
    try:
        project = G2sc.G2Project(str(OUT / "baseline.gpx"))
        project.save(str(target))
        mutate(project)
        refine(project, OUT / f"{tag}.lst")
        project.save(str(target))
        ans = state(project, name)
        ans["project"] = str(target)
        return ans
    except Exception as exc:
        return {"label": name, "project": str(target), "error": repr(exc)}


def set_background(family, ncoeff):
    def mutate(project):
        hist = project.histograms()[0]
        old = list(hist.data["Background"][0][3:])
        if family == "chebyschev-1":
            coeff = old[:ncoeff] + [0.0] * max(0, ncoeff - len(old))
        else:
            # A flat start avoids transferring coefficients between unlike bases.
            coeff = [max(old[0], 1.0)] + [0.0] * (ncoeff - 1)
        hist.data["Background"][0] = [family, True, ncoeff] + coeff
    return mutate


def set_po(phase_name, axis):
    def mutate(project):
        hist = project.histograms()[0]
        hap = project.phase(phase_name).data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
    return mutate


def set_uniaxial(phase_name, key, axis):
    def mutate(project):
        hist = project.histograms()[0]
        hap = project.phase(phase_name).data["Histograms"][hist.name]
        term = hap[key]
        term[0] = "uniaxial"
        term[1][1] = term[1][0]
        term[2] = [True, True, False]
        term[3] = list(axis)
    return mutate


def set_uiso(phase_name, selector):
    def mutate(project):
        phase = project.phase(phase_name)
        for atom in phase.atoms():
            if selector(atom):
                atom.refinement_flags = "U"
    return mutate


def main():
    baseline = make_baseline()
    trials = []

    for ncoeff in (6, 8, 10, 12):
        trials.append(
            branch(
                f"background_chebyschev-1_{ncoeff}",
                set_background("chebyschev-1", ncoeff),
            )
        )
    for family in ("chebyschev", "cosine", "Q^2 power series", "Q^-2 power series"):
        trials.append(branch(f"background_{family}_8", set_background(family, 8)))

    axes = {
        "CaWO4_scheelite": ([0, 0, 1], [1, 0, 0], [1, 1, 0]),
        "WO3_candidate": ([0, 0, 1], [0, 1, 0], [1, 0, 0]),
    }
    for phase_name, phase_axes in axes.items():
        for axis in phase_axes:
            suffix = "".join(map(str, axis))
            trials.append(
                branch(f"texture_{phase_name}_{suffix}", set_po(phase_name, axis))
            )

    for key in ("Size", "Mustrain"):
        for phase_name, phase_axes in axes.items():
            for axis in phase_axes:
                suffix = "".join(map(str, axis))
                trials.append(
                    branch(
                        f"uniaxial_{key}_{phase_name}_{suffix}",
                        set_uniaxial(phase_name, key, axis),
                    )
                )

    trials.extend(
        [
            branch(
                "uiso_CaWO4_O",
                set_uiso("CaWO4_scheelite", lambda atom: atom.element == "O"),
            ),
            branch(
                "uiso_CaWO4_cations",
                set_uiso("CaWO4_scheelite", lambda atom: atom.element != "O"),
            ),
            branch(
                "uiso_WO3_W",
                set_uiso("WO3_candidate", lambda atom: atom.element == "W"),
            ),
            branch(
                "uiso_WO3_O",
                set_uiso("WO3_candidate", lambda atom: atom.element == "O"),
            ),
        ]
    )

    result = {"source": str(SOURCE), "baseline": baseline, "trials": trials}
    (OUT / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    compact = [
        {
            "label": item.get("label"),
            "Rwp_percent": item.get("Rwp_percent"),
            "delta_Rwp": (
                item.get("Rwp_percent", baseline["Rwp_percent"])
                - baseline["Rwp_percent"]
            ),
            "converged": item.get("converged"),
            "physical": item.get("physical", {}).get("all"),
            "fractions": item.get("fractions"),
            "error": item.get("error"),
        }
        for item in trials
    ]
    print(json.dumps({"baseline": baseline, "trials": compact}, indent=2))


if __name__ == "__main__":
    main()
