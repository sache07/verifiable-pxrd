#!/usr/bin/env python3
"""Matched combinations of the repeatable weak CaWO4 mechanisms."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import final_mechanism_screen as fms


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
OUT = ANALYSIS / "weak_mechanism_combinations"
SOURCES = {
    tag: ANALYSIS / "postcoordinate_mechanism_restarts" / tag / "baseline.gpx"
    for tag in ("U10", "U2", "U20")
}

COMBINATIONS = {
    "texture_size": ("texture", "size"),
    "texture_uiso": ("texture", "uiso"),
    "size_uiso": ("size", "uiso"),
    "texture_size_uiso": ("texture", "size", "uiso"),
}


def apply_terms(project, terms):
    if "texture" in terms:
        fms.set_po("CaWO4_scheelite", [1, 0, 0])(project)
    if "size" in terms:
        fms.set_uniaxial("CaWO4_scheelite", "Size", [1, 0, 0])(project)
    if "uiso" in terms:
        fms.set_uiso("CaWO4_scheelite", lambda atom: atom.element == "O")(project)


def run(tag, source):
    branch = OUT / tag
    branch.mkdir(parents=True, exist_ok=True)
    results = []
    for name, terms in COMBINATIONS.items():
        target = branch / f"{name}.gpx"
        project = G2sc.G2Project(str(source))
        project.save(str(target))
        apply_terms(project, terms)
        fms.refine(project, branch / f"{name}.lst")
        first = fms.state(project, f"{name}_first")
        # A second pass from the converged solution checks that no large first
        # cycle shift is being mistaken for a stable combined minimum.
        fms.refine(project, branch / f"{name}_repeat.lst")
        final = fms.state(project, name)
        project.save(str(target))
        results.append(
            {
                "name": name,
                "terms": terms,
                "first": first,
                "final": final,
                "project": str(target),
            }
        )
    answer = {"tag": tag, "source": str(source), "results": results}
    (branch / "result.json").write_text(json.dumps(answer, indent=2) + "\n")
    return answer


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    results = [run(tag, source) for tag, source in SOURCES.items()]
    (OUT / "summary.json").write_text(json.dumps(results, indent=2) + "\n")
    compact = []
    for item in results:
        compact.append(
            {
                "tag": item["tag"],
                "results": [
                    {
                        "name": result["name"],
                        "first_Rwp": result["first"]["Rwp_percent"],
                        "final_Rwp": result["final"]["Rwp_percent"],
                        "converged": result["final"]["converged"],
                        "max_shift_esd": result["final"]["max_shift_esd"],
                        "physical": result["final"]["physical"]["all"],
                        "fractions": result["final"]["fractions"],
                    }
                    for result in item["results"]
                ],
            }
        )
    print(json.dumps(compact, indent=2))


if __name__ == "__main__":
    main()
