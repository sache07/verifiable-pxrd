#!/usr/bin/env python3
"""Repeat credible WO3 parent and nuisance-start comparisons with texture."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import final_mechanism_screen as fms


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
OUT = ANALYSIS / "texture_parent_restarts"

SOURCES = {
    "monoclinic_1528915_U10": ANALYSIS / "coordinate_parent_compare" / "monoclinic_1528915" / "refined.gpx",
    "monoclinic_2311041_U10": ANALYSIS / "coordinate_parent_compare" / "monoclinic_2311041" / "refined.gpx",
    "triclinic_2106293_U10": ANALYSIS / "triclinic_restage" / "U10" / "refined.gpx",
    "monoclinic_2311041_U2": ANALYSIS / "lineage_restarts" / "monoclinic_2311041_U2" / "refined.gpx",
    "monoclinic_2311041_U20": ANALYSIS / "lineage_restarts" / "monoclinic_2311041_U20" / "refined.gpx",
}


def set_profile_flags(project, enabled):
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    for key in ("W", "X", "SH/L", "Polariz."):
        inst[key][2] = bool(enabled)
    hist.data["Sample Parameters"]["SurfRoughB"][1] = bool(enabled)


def set_size_flags(project, enabled):
    hist = project.histograms()[0]
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Size"][2] = [bool(enabled), False, False]


def set_strain_flags(project, enabled):
    hist = project.histograms()[0]
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Mustrain"][2] = [bool(enabled), False, False]


def stabilize(tag, source):
    branch = OUT / tag
    branch.mkdir(parents=True, exist_ok=True)
    target = branch / "stabilized.gpx"
    project = G2sc.G2Project(str(source))
    project.save(str(target))
    fms.configure_supported_flags(project)
    stages = []

    set_strain_flags(project, False)
    set_profile_flags(project, True)
    fms.refine(project, branch / "profile.lst")
    stages.append(fms.state(project, "profile"))

    set_profile_flags(project, False)
    set_size_flags(project, True)
    fms.refine(project, branch / "size.lst")
    stages.append(fms.state(project, "size"))

    set_size_flags(project, False)
    set_strain_flags(project, True)
    fms.refine(project, branch / "strain.lst")
    stages.append(fms.state(project, "strain"))

    set_strain_flags(project, False)
    set_profile_flags(project, True)
    fms.refine(project, branch / "profile_repeat.lst")
    stages.append(fms.state(project, "profile_repeat"))

    set_profile_flags(project, False)
    set_strain_flags(project, True)
    fms.refine(project, branch / "strain_repeat.lst")
    stages.append(fms.state(project, "strain_repeat"))
    project.save(str(target))
    return stages


def texture_trial(tag, axis):
    branch = OUT / tag
    source = branch / "stabilized.gpx"
    suffix = "".join(map(str, axis))
    target = branch / f"texture_{suffix}.gpx"
    project = G2sc.G2Project(str(source))
    project.save(str(target))
    fms.set_po("WO3_candidate", axis)(project)
    fms.refine(project, branch / f"texture_{suffix}.lst")
    project.save(str(target))
    result = fms.state(project, f"{tag}_texture_{suffix}")
    result["project"] = str(target)
    return result


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for tag, source in SOURCES.items():
        stages = stabilize(tag, source)
        trials = [texture_trial(tag, axis) for axis in ([0, 0, 1], [0, 1, 0], [1, 0, 0])]
        item = {
            "tag": tag,
            "source": str(source),
            "stages": stages,
            "texture_trials": trials,
        }
        (OUT / tag / "result.json").write_text(json.dumps(item, indent=2) + "\n")
        results.append(item)
    (OUT / "summary.json").write_text(json.dumps(results, indent=2) + "\n")
    compact = []
    for item in results:
        compact.append(
            {
                "tag": item["tag"],
                "base_Rwp": item["stages"][-1]["Rwp_percent"],
                "base_fractions": item["stages"][-1]["fractions"],
                "texture": [
                    {
                        "label": trial["label"],
                        "Rwp_percent": trial["Rwp_percent"],
                        "converged": trial["converged"],
                        "physical": trial["physical"]["all"],
                        "ratio": trial["phases"]["WO3_candidate"]["preferred_orientation"]["ratio"],
                        "fractions": trial["fractions"],
                    }
                    for trial in item["texture_trials"]
                ],
            }
        )
    print(json.dumps(compact, indent=2))


if __name__ == "__main__":
    main()
