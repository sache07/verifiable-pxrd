#!/usr/bin/env python3
"""Matched fixed-coordinate GSAS-II comparisons for serious parent models."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"

WO3_MODELS = {
    "monoclinic_1528915": ANALYSIS / "models" / "wo3_monoclinic_1528915.cif",
    "monoclinic_2311041": ANALYSIS / "models" / "wo3_monoclinic_alt_2311041.cif",
    "triclinic_2106293": ANALYSIS / "models" / "wo3_triclinic_2106293.cif",
    "orthorhombic_2107312": ANALYSIS / "models" / "wo3_orthorhombic_2107312.cif",
}


def snapshot(project, histogram, stage):
    inst = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    return {
        "stage": stage,
        "Rwp_percent": histogram.get_wR(),
        "residuals": histogram.residuals,
        "instrument": {key: value[1] for key, value in inst.items() if isinstance(value, list)},
        "sample": {
            key: value[0]
            for key, value in sample.items()
            if isinstance(value, list) and len(value) == 2
        },
        "phases": phases,
    }


def run_model(model_name: str, model_path: Path, output_dir: Path):
    output_dir.mkdir(parents=True, exist_ok=True)
    gpx = output_dir / f"{model_name}.gpx"
    project = G2sc.G2Project(newgpx=str(gpx))
    histogram = project.add_powder_histogram(
        str(ANALYSIS / "pattern.xye"),
        str(ANALYSIS / "cu_ka.instprm"),
        fmthint="xye",
    )
    cawo4 = project.add_phase(
        str(ANALYSIS / "models" / "cawo4_scheelite_7219229.cif"),
        phasename="CaWO4_scheelite",
        histograms=[histogram],
        fmthint="CIF",
    )
    wo3 = project.add_phase(
        str(model_path),
        phasename=f"WO3_{model_name}",
        histograms=[histogram],
        fmthint="CIF",
    )

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 10
    controls["min dM/M"] = 1e-5
    controls["shift factor"] = 0.5

    # Remove the exact scale degeneracy: histogram scale fixed, all HAP scales refined.
    histogram.data["Sample Parameters"]["Scale"] = [1.0, False]
    inst = histogram.data["Instrument Parameters"][0]
    inst["Zero"][1] = -0.12
    for key, value in {"U": 10.0, "V": -2.0, "W": 10.0, "X": 1.0, "SH/L": 0.02}.items():
        inst[key][1] = value

    for index, phase in enumerate((cawo4, wo3)):
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][0] = (1.0, 0.30)[index]
        hap["Size"][1][0] = 0.20
        hap["Mustrain"][1][0] = 1000.0

    stages = []
    project.set_refinement(
        {
            "set": {
                "Background": {
                    "type": "chebyschev-1",
                    "no. coeffs": 8,
                    "coeffs": [1100.0, -550.0, 150.0, -50.0, 0.0, 0.0, 0.0, 0.0],
                    "refine": True,
                },
                "Scale": True,
            }
        }
    )
    project.refine(printFile=str(output_dir / f"{model_name}.lst"))
    stages.append(snapshot(project, histogram, "background_scales"))

    project.set_refinement(
        {"set": {"Instrument Parameters": ["Zero"], "Cell": True}}
    )
    project.refine(printFile=str(output_dir / f"{model_name}.lst"))
    stages.append(snapshot(project, histogram, "zero_cells"))

    project.set_refinement(
        {"set": {"Instrument Parameters": ["U", "V", "W", "X", "SH/L"]}}
    )
    project.refine(printFile=str(output_dir / f"{model_name}.lst"))
    stages.append(snapshot(project, histogram, "common_profile"))

    project.set_refinement(
        {"set": {"Size": {"type": "isotropic", "refine": True}}}
    )
    project.refine(printFile=str(output_dir / f"{model_name}.lst"))
    stages.append(snapshot(project, histogram, "isotropic_size"))

    project.set_refinement(
        {"set": {"Mustrain": {"type": "isotropic", "refine": True}}}
    )
    project.refine(printFile=str(output_dir / f"{model_name}.lst"))
    stages.append(snapshot(project, histogram, "isotropic_size_strain"))

    project.save()
    try:
        mass_fractions = histogram.ComputeMassFracs()
    except Exception as exc:
        mass_fractions = {"error": repr(exc)}
    result = {
        "model": model_name,
        "parent_cif": str(model_path),
        "project": str(gpx),
        "stages": stages,
        "mass_fractions": mass_fractions,
    }
    with (output_dir / f"{model_name}.json").open("w") as handle:
        json.dump(result, handle, indent=2)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("models", nargs="*")
    args = parser.parse_args()
    selected = args.models or list(WO3_MODELS)
    unknown = sorted(set(selected) - set(WO3_MODELS))
    if unknown:
        parser.error(f"unknown model(s): {', '.join(unknown)}")
    output_dir = ANALYSIS / "fixed_parent_compare"
    results = [run_model(name, WO3_MODELS[name], output_dir) for name in selected]
    summary = {
        item["model"]: {
            "Rwp_percent": item["stages"][-1]["Rwp_percent"],
            "mass_fractions": item["mass_fractions"],
            "cells": item["stages"][-1]["phases"],
        }
        for item in results
    }
    with (output_dir / "summary.json").open("w") as handle:
        json.dump(summary, handle, indent=2)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
