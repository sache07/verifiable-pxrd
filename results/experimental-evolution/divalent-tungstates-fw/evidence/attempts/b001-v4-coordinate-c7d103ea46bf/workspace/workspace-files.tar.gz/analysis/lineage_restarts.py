#!/usr/bin/env python3
"""Independent nuisance-profile restarts for the two credible WO3 finalists."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import coordinate_parent_compare as cpc


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
OUT = ANALYSIS / "lineage_restarts"

PARENTS = {
    "monoclinic_2311041": ANALYSIS / "models" / "wo3_monoclinic_alt_2311041.cif",
    "triclinic_2106293": ANALYSIS / "models" / "wo3_triclinic_2106293.cif",
}


def run(name, parent_cif, fixed_u):
    tag = f"{name}_U{fixed_u:g}"
    branch = OUT / tag
    branch.mkdir(parents=True, exist_ok=True)
    gpx = branch / "refined.gpx"
    listing = branch / "refined.lst"
    p = G2sc.G2Project(newgpx=str(gpx))
    h = p.add_powder_histogram(
        str(ANALYSIS / "pattern.xye"),
        str(ANALYSIS / "cu_ka.instprm"),
        fmthint="xye",
    )
    ca = p.add_phase(
        str(ANALYSIS / "models" / "cawo4_scheelite_7219229.cif"),
        phasename="CaWO4_scheelite",
        histograms=[h],
        fmthint="CIF",
    )
    wo = p.add_phase(
        str(parent_cif),
        phasename="WO3_candidate",
        histograms=[h],
        fmthint="CIF",
    )
    cpc.initialize_restraints(p, ca, wo)
    p.data["Controls"]["data"].update(
        {"max cyc": 12, "min dM/M": 1e-5, "shift factor": 0.25}
    )
    sample = h.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [210.0, False]
    sample["SurfRoughA"] = [0.10, False]
    sample["SurfRoughB"] = [0.08, False]
    inst = h.data["Instrument Parameters"][0]
    for key, value in {
        "U": fixed_u,
        "V": 0.0,
        "W": 15.0,
        "X": 2.0,
        "SH/L": 0.01,
        "Polariz.": 0.85,
    }.items():
        inst[key][1] = value
    for phase, scale in ((ca, 1.0), (wo, 0.3)):
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][0] = scale
        hap["Size"][1][0] = 0.15
        hap["Mustrain"][1][0] = 800.0

    p.set_refinement(
        {
            "set": {
                "Background": {
                    "type": "chebyschev-1",
                    "no. coeffs": 8,
                    "coeffs": [1100.0, -550.0, 150.0, -50.0, 0.0, 0.0, 0.0, 0.0],
                    "refine": True,
                },
                "Scale": True,
            }
        }
    )
    cpc.refine(p, listing)
    p.set_refinement({"set": {"Sample Parameters": ["Shift"], "Cell": True}})
    cpc.refine(p, listing)
    p.set_refinement(
        {"set": {"Instrument Parameters": ["W", "X", "SH/L"]}}
    )
    cpc.refine(p, listing)
    if inst["SH/L"][1] < 0:
        inst["SH/L"][1] = 0.01
        p.set_refinement({"clear": {"Instrument Parameters": ["SH/L"]}})
        cpc.refine(p, listing)
    p.set_refinement(
        {
            "set": {
                "Sample Parameters": ["SurfRoughB"],
                "Instrument Parameters": ["Polariz."],
            }
        }
    )
    cpc.refine(p, listing)
    p.set_refinement(
        {
            "clear": {
                "Instrument Parameters": ["W", "X", "SH/L", "Polariz."],
                "Sample Parameters": ["SurfRoughB"],
            }
        }
    )
    p.set_refinement(
        {"set": {"Size": {"type": "isotropic", "refine": True}}}
    )
    cpc.refine(p, listing)
    p.set_refinement({"clear": {"Size": True}})
    p.set_refinement(
        {"set": {"Mustrain": {"type": "isotropic", "refine": True}}}
    )
    cpc.refine(p, listing)
    base = cpc.state(p, h, "base")
    p.save(str(gpx))
    p.data["Controls"]["data"]["max cyc"] = 8

    trials = []
    p, h, trial = cpc.try_coordinate_block(
        p, h, "CaWO4_scheelite", ["O2"], "cawo4_O", listing, gpx
    )
    trials.append(trial)
    wo = p.phase("WO3_candidate")
    wlabels = [atom.label for atom in wo.atoms() if atom.element == "W"]
    p, h, trial = cpc.try_coordinate_block(
        p, h, "WO3_candidate", wlabels, "wo3_W", listing, gpx
    )
    trials.append(trial)
    final = cpc.state(p, h, "final")
    p.save(str(gpx))
    p.phase("CaWO4_scheelite").export_CIF(str(branch / "CaWO4_refined.cif"))
    p.phase("WO3_candidate").export_CIF(str(branch / "WO3_refined.cif"))
    result = {
        "parent": name,
        "fixed_U": fixed_u,
        "base": base,
        "final": final,
        "coordinate_trials": trials,
        "mass_fractions": h.ComputeMassFracs(),
        "project": str(gpx),
    }
    with (branch / "result.json").open("w") as handle:
        json.dump(result, handle, indent=2)
    return result


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    results = [
        run(name, path, fixed_u)
        for name, path in PARENTS.items()
        for fixed_u in (2.0, 20.0)
    ]
    summary = [
        {
            "parent": item["parent"],
            "fixed_U": item["fixed_U"],
            "base_Rwp": item["base"]["Rwp_percent"],
            "final_Rwp": item["final"]["Rwp_percent"],
            "fractions": item["mass_fractions"],
            "trials": item["coordinate_trials"],
            "project": item["project"],
        }
        for item in results
    ]
    with (OUT / "summary.json").open("w") as handle:
        json.dump(summary, handle, indent=2)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
