#!/usr/bin/env python3
"""Cumulative phase addition and deletion tests from the physical parent model."""

from __future__ import annotations

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
SOURCE = ANALYSIS / "roughness_grid" / "A0.10.gpx"
OUT = ANALYSIS / "inventory_tests"

ADDITIONS = {
    "CaO_rocksalt": ANALYSIS / "models" / "cao_rocksalt_1563196.cif",
    "Ca4.26W10O30_TTB": ANALYSIS / "models" / "ca_w_oxide_ttb_4030741.cif",
}


def project_state(project, hist):
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if not hap:
            continue
        phases[phase.name] = {
            "use": bool(hap["Use"]),
            "scale": float(hap["Scale"][0]),
            "cell": phase.get_cell(),
            "size_um": float(hap["Size"][1][0]),
        }
    try:
        fractions = hist.ComputeMassFracs()
    except Exception as exc:
        fractions = {"error": repr(exc)}
    return copy.deepcopy(
        {
            "Rwp_percent": float(hist.get_wR()),
            "residuals": hist.residuals,
            "phases": phases,
            "mass_fractions": fractions,
        }
    )


def deletion(phase_name):
    tag = f"delete_{phase_name}"
    target = OUT / f"{tag}.gpx"
    p = G2sc.G2Project(str(SOURCE))
    p.save(str(target))
    h = p.histograms()[0]
    phase = p.phase(phase_name)
    phase.set_HAP_refinements({"Use": False}, [h])
    p.refine(printFile=str(OUT / f"{tag}.lst"))
    p.save()
    result = {"test": tag, **project_state(p, h), "project": str(target)}
    with (OUT / f"{tag}.json").open("w") as handle:
        json.dump(result, handle, indent=2)
    return result


def addition(name, cif):
    tag = f"add_{name}"
    target = OUT / f"{tag}.gpx"
    p = G2sc.G2Project(str(SOURCE))
    p.save(str(target))
    h = p.histograms()[0]
    phase = p.add_phase(
        str(cif), phasename=name, histograms=[h], fmthint="CIF"
    )
    hap = phase.data["Histograms"][h.name]
    hap["Scale"][0] = 0.10
    hap["Size"][1][0] = 0.15
    hap["Mustrain"][1][0] = 800.0
    phase.set_HAP_refinements({"Scale": True}, [h])
    phase.set_refinements({"Cell": True})
    p.refine(printFile=str(OUT / f"{tag}.lst"))
    first = project_state(p, h)
    # Only offer a phase-specific size term to a positive-scale candidate.
    if hap["Scale"][0] > 0:
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [h]
        )
        p.refine(printFile=str(OUT / f"{tag}.lst"))
    p.save()
    result = {
        "test": tag,
        "after_scale_cell": first,
        "final": project_state(p, h),
        "project": str(target),
        "candidate_cif": str(cif),
    }
    with (OUT / f"{tag}.json").open("w") as handle:
        json.dump(result, handle, indent=2)
    return result


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    parent = G2sc.G2Project(str(SOURCE))
    parent_state = project_state(parent, parent.histograms()[0])
    results = {
        "parent": parent_state,
        "deletions": [
            deletion("CaWO4_scheelite"),
            deletion("WO3_monoclinic"),
        ],
        "additions": [addition(name, cif) for name, cif in ADDITIONS.items()],
    }
    with (OUT / "summary.json").open("w") as handle:
        json.dump(results, handle, indent=2)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
