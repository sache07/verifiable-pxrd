#!/usr/bin/env python3
"""Check weaker CaWO4 mechanisms after final texture-aware coordinates."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import final_mechanism_screen as fms
import texture_parent_restarts as tpr


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
OUT = ANALYSIS / "postcoordinate_mechanism_restarts"
SOURCES = {
    "U10": ANALYSIS / "cumulative_model_tests" / "coordinate_retest.gpx",
    "U2": ANALYSIS / "texture_coordinate_parent_retests" / "monoclinic_2311041_U2" / "refined.gpx",
    "U20": ANALYSIS / "texture_coordinate_parent_retests" / "monoclinic_2311041_U20" / "refined.gpx",
}


def stabilize(tag, source):
    branch = OUT / tag
    branch.mkdir(parents=True, exist_ok=True)
    target = branch / "baseline.gpx"
    project = G2sc.G2Project(str(source))
    project.save(str(target))
    fms.configure_supported_flags(project)
    hist = project.histograms()[0]
    po = project.phase("WO3_candidate").data["Histograms"][hist.name]["Pref.Ori."]
    po[0], po[2], po[3] = "MD", True, [0, 0, 1]
    stages = []

    tpr.set_strain_flags(project, False)
    tpr.set_profile_flags(project, True)
    fms.refine(project, branch / "profile.lst")
    stages.append(fms.state(project, "profile"))

    tpr.set_profile_flags(project, False)
    tpr.set_size_flags(project, True)
    fms.refine(project, branch / "size.lst")
    stages.append(fms.state(project, "size"))

    tpr.set_size_flags(project, False)
    tpr.set_strain_flags(project, True)
    fms.refine(project, branch / "strain.lst")
    stages.append(fms.state(project, "strain"))

    tpr.set_strain_flags(project, False)
    tpr.set_profile_flags(project, True)
    fms.refine(project, branch / "profile_repeat.lst")
    stages.append(fms.state(project, "profile_repeat"))

    tpr.set_profile_flags(project, False)
    tpr.set_strain_flags(project, True)
    fms.refine(project, branch / "strain_repeat.lst")
    stages.append(fms.state(project, "strain_repeat"))
    project.save(str(target))
    return stages


def trial(tag, name, mutate):
    branch = OUT / tag
    target = branch / f"{fms.safe_tag(name)}.gpx"
    project = G2sc.G2Project(str(branch / "baseline.gpx"))
    project.save(str(target))
    mutate(project)
    fms.refine(project, branch / f"{fms.safe_tag(name)}.lst")
    project.save(str(target))
    result = fms.state(project, name)
    result["project"] = str(target)
    return result


def run(tag, source):
    stages = stabilize(tag, source)
    trials = []
    for axis in ([0, 0, 1], [1, 0, 0], [1, 1, 0]):
        suffix = "".join(map(str, axis))
        trials.append(
            trial(
                tag,
                f"CaWO4_texture_{suffix}",
                fms.set_po("CaWO4_scheelite", axis),
            )
        )
        trials.append(
            trial(
                tag,
                f"CaWO4_uniaxial_size_{suffix}",
                fms.set_uniaxial("CaWO4_scheelite", "Size", axis),
            )
        )
    trials.append(
        trial(
            tag,
            "CaWO4_O_uiso",
            fms.set_uiso("CaWO4_scheelite", lambda atom: atom.element == "O"),
        )
    )
    answer = {"tag": tag, "source": str(source), "stages": stages, "trials": trials}
    (OUT / tag / "result.json").write_text(json.dumps(answer, indent=2) + "\n")
    return answer


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    results = [run(tag, source) for tag, source in SOURCES.items()]
    (OUT / "summary.json").write_text(json.dumps(results, indent=2) + "\n")
    compact = []
    for item in results:
        base = item["stages"][-1]
        compact.append(
            {
                "tag": item["tag"],
                "base_Rwp": base["Rwp_percent"],
                "base_fractions": base["fractions"],
                "trials": [
                    {
                        "label": trial["label"],
                        "Rwp_percent": trial["Rwp_percent"],
                        "delta_Rwp": trial["Rwp_percent"] - base["Rwp_percent"],
                        "converged": trial["converged"],
                        "physical": trial["physical"]["all"],
                        "fractions": trial["fractions"],
                    }
                    for trial in item["trials"]
                ],
            }
        )
    print(json.dumps(compact, indent=2))


if __name__ == "__main__":
    main()
