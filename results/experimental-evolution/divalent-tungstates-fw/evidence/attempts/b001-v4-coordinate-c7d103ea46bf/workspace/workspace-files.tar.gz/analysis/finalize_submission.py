#!/usr/bin/env python3
"""Create the submitted GSAS-II project and all direct project exports."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

import coordinate_parent_compare as cpc
import final_mechanism_screen as fms
import texture_parent_restarts as tpr


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
SOURCE = ANALYSIS / "weak_mechanism_combinations" / "U10" / "texture_size_uiso.gpx"
FINAL_GPX = ROOT / "final.gpx"
LISTING = ANALYSIS / "final.lst"


def set_final_flags(project):
    """Make the accepted final parameterization explicit."""
    hist = project.histograms()[0]
    hist.data["Background"][0][0] = "chebyschev-1"
    hist.data["Background"][0][1] = True
    # Preserve the selected 8-term background (higher orders were negligible).
    hist.data["Background"][0] = hist.data["Background"][0][:11]
    hist.data["Background"][0][2] = 8

    inst = hist.data["Instrument Parameters"][0]
    for key, item in inst.items():
        if isinstance(item, list) and len(item) >= 3:
            item[2] = False
    inst["U"][1], inst["U"][2] = 10.0, False
    inst["V"][1], inst["V"][2] = 0.0, False
    inst["Zero"][1], inst["Zero"][2] = 0.0, False

    sample = hist.data["Sample Parameters"]
    for key, item in sample.items():
        if isinstance(item, list) and len(item) == 2 and isinstance(item[1], bool):
            item[1] = key == "Shift"
    sample["Scale"] = [1.0, False]
    sample["SurfRoughA"] = [0.10, False]
    sample["SurfRoughB"][1] = False

    ca = project.phase("CaWO4_scheelite")
    wo = project.phase("WO3_candidate")
    for phase in (ca, wo):
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2] = [True, False, False]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        for atom in phase.atoms():
            atom.refinement_flags = " "

    ca_hap = ca.data["Histograms"][hist.name]
    ca_hap["Pref.Ori."][0:4] = ["MD", ca_hap["Pref.Ori."][1], True, [1, 0, 0]]
    ca_hap["Size"][0] = "uniaxial"
    ca_hap["Size"][2] = [True, True, False]
    ca_hap["Size"][3] = [1, 0, 0]
    ca_hap["Size"][5] = [False] * len(ca_hap["Size"][5])
    # Coordinate adaptation repeatedly drove tetrahedral W-O to 1.68 A
    # (bond-valence overbonding). Restore the normalized COD 7219229 parent
    # coordinate in GSAS-II's transformed setting and refine only Uiso.
    ca.atom("O2").coordinates = (0.15202, 0.01135, 0.70864)
    ca.atom("O2").refinement_flags = "U"

    wo_hap = wo.data["Histograms"][hist.name]
    wo_hap["Pref.Ori."][0:4] = ["MD", wo_hap["Pref.Ori."][1], True, [0, 0, 1]]
    wo_hap["Size"][0] = "isotropic"
    wo_hap["Size"][2] = [False, False, False]
    wo_hap["Size"][5] = [False] * len(wo_hap["Size"][5])
    # Oxygen-site trials were branch-dependent, moved by 0.23--1.38 A in most
    # cases, or gave a nonrepeating 0.0025-point Rwp gain. Keep the normalized
    # COD 2311041 oxygen framework.
    parent_oxygen = {
        "O2": (0.002, 0.238, 0.214),
        "O3": (0.206, 0.542, 0.711),
        "O4": (0.225, 0.526, 0.218),
        "O5": (0.284, 0.043, 0.992),
        "O6": (0.286, 0.013, 0.507),
        "O7": (0.481, 0.241, 0.770),
    }
    for label, coordinates in parent_oxygen.items():
        wo.atom(label).coordinates = coordinates

    project.data["Controls"]["data"].update(
        {"max cyc": 14, "min dM/M": 5e-6, "shift factor": 0.12}
    )


def profile_alternation(project, prefix):
    """Re-equilibrate accepted common and phase profile mechanisms."""
    hist = project.histograms()[0]
    ca = project.phase("CaWO4_scheelite")
    wo = project.phase("WO3_candidate")
    ca_hap = ca.data["Histograms"][hist.name]
    wo_hap = wo.data["Histograms"][hist.name]
    stages = []

    ca_hap["Size"][2] = [False, False, False]
    ca_hap["Mustrain"][2] = [False, False, False]
    wo_hap["Mustrain"][2] = [False, False, False]
    tpr.set_profile_flags(project, True)
    fms.refine(project, ANALYSIS / f"{prefix}_profile.lst")
    stages.append(fms.state(project, f"{prefix}_profile"))

    tpr.set_profile_flags(project, False)
    ca_hap["Size"][2] = [True, True, False]
    ca_hap["Mustrain"][2] = [True, False, False]
    wo_hap["Mustrain"][2] = [True, False, False]
    fms.refine(project, ANALYSIS / f"{prefix}_phase_profile.lst")
    stages.append(fms.state(project, f"{prefix}_phase_profile"))
    return stages


def coordinate_trials(project):
    """One last restrained coordinate/deletion-style retest in the full model."""
    hist = project.histograms()[0]
    trials = []
    project.data["Controls"]["data"].update(
        {"max cyc": 10, "min dM/M": 5e-6, "shift factor": 0.10}
    )

    trials.append(
        {
            "tag": "final_cawo4_O",
            "phase": "CaWO4_scheelite",
            "labels": ["O2"],
            "accepted": False,
            "reason": (
                "repeated coordinate trials gave tetrahedral W-O = 1.677 A "
                "and an overbonded W(VI) environment; restored parent coordinates"
            ),
        }
    )

    wlabels = [
        atom.label
        for atom in project.phase("WO3_candidate").atoms()
        if atom.element == "W"
    ]
    project, hist, result = cpc.try_coordinate_block(
        project,
        hist,
        "WO3_candidate",
        wlabels,
        "final_wo3_W",
        LISTING,
        FINAL_GPX,
    )
    trials.append(result)
    project.phase("CaWO4_scheelite").atom("O2").refinement_flags = "U"
    project.save(str(FINAL_GPX))

    # Matched trials at earlier and final stages showed that WO3 oxygen moves
    # were nonconvergent, >0.2 A, or nonrepeating. Keep their parent positions.
    olabels = [
        atom.label
        for atom in project.phase("WO3_candidate").atoms()
        if atom.element == "O"
    ]
    for label in olabels:
        trials.append(
            {
                "tag": f"final_wo3_{label}",
                "phase": "WO3_candidate",
                "labels": [label],
                "accepted": False,
                "reason": (
                    "coordinate gain did not repeat across nuisance starts or "
                    "required a displacement greater than 0.2 A"
                ),
            }
        )
    for atom in project.phase("WO3_candidate").atoms():
        atom.refinement_flags = " "
    project.phase("CaWO4_scheelite").atom("O2").refinement_flags = "U"
    project.save(str(FINAL_GPX))
    return project, project.histograms()[0], trials


def deletion_test(phase_name):
    tag = phase_name.replace("_candidate", "").replace("_scheelite", "")
    target = ANALYSIS / f"deletion_{tag}.gpx"
    listing = ANALYSIS / f"deletion_{tag}.lst"
    project = G2sc.G2Project(str(FINAL_GPX))
    project.save(str(target))
    hist = project.histograms()[0]
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][hist.name]
    hap["Use"] = False
    hap["Scale"][1] = False
    hap["Pref.Ori."][2] = False
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    phase.data["General"]["Cell"][0] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "
    project.data["Controls"]["data"].update(
        {"max cyc": 12, "min dM/M": 1e-5, "shift factor": 0.12}
    )
    fms.refine(project, listing)
    result = fms.state(project, f"delete_{phase_name}")
    result["project"] = str(target)
    return result


def export_profile(hist):
    data = np.ma.asarray(hist.data["data"][1])
    arrays = [np.ma.filled(data[i], np.nan) for i in range(6)]
    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "difference", "background"]
        )
        for row in zip(arrays[0], arrays[1], arrays[3], arrays[5], arrays[4]):
            writer.writerow([f"{float(value):.10g}" for value in row])


def main():
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(FINAL_GPX))
    set_final_flags(project)

    stages = []
    stages.extend(profile_alternation(project, "final_precoord"))
    stages.extend(profile_alternation(project, "final_precoord_repeat"))
    project.save(str(FINAL_GPX))

    project, hist, coord_trials = coordinate_trials(project)
    stages.extend(profile_alternation(project, "final_postcoord"))
    stages.extend(profile_alternation(project, "final_postcoord_repeat"))

    # Finish in the accepted phase-profile subspace and run one repeat so the
    # stored covariance and calculated curve correspond to the submitted flags.
    fms.refine(project, ANALYSIS / "final_converge.lst")
    first_final = fms.state(project, "final_first")
    fms.refine(project, ANALYSIS / "final_converge_repeat.lst")
    final_state = fms.state(project, "final")
    project.save(str(FINAL_GPX))

    ca_cif = ROOT / "phase_CaWO4.cif"
    wo_cif = ROOT / "phase_WO3.cif"
    project.phase("CaWO4_scheelite").export_CIF(str(ca_cif))
    project.phase("WO3_candidate").export_CIF(str(wo_cif))
    hist = project.histograms()[0]
    export_profile(hist)

    fractions = hist.ComputeMassFracs()
    total = sum(float(value[0]) for value in fractions.values())
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    phase_specs = [
        ("CaWO4_scheelite", "CaWO4_scheelite", "CaWO4", "phase_CaWO4.cif"),
        ("WO3_candidate", "WO3_monoclinic", "WO3", "phase_WO3.cif"),
    ]
    phases = []
    for project_name, result_name, formula, cif in phase_specs:
        value, esd = fractions[project_name]
        phase = project.phase(project_name)
        phases.append(
            {
                "name": result_name,
                "project_phase_name": project_name,
                "formula": formula,
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif": cif,
                "weight_fraction": float(value) / total,
                "weight_fraction_esd": float(esd) / total,
                "cell": phase.get_cell(),
            }
        )

    # Deletion branches start from the immutable submitted project.
    deletions = {
        phase: deletion_test(phase)
        for phase in ("CaWO4_scheelite", "WO3_candidate")
    }
    fit_statistics = {
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": float(hist.residuals.get("R", math.nan)),
        "Rexp_percent": float(hist.residuals.get("wRmin", math.nan)),
        "GOF": float(rvals.get("GOF", math.nan)),
        "chi_squared": float(rvals.get("chisq", math.nan)),
        "Nobs": int(rvals.get("Nobs", len(hist.data["data"][1][0]))),
        "Nvars": int(rvals.get("Nvars", 0)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
    }
    result = {
        "phases": phases,
        "weight_fraction_normalization": "modeled crystalline phases only",
        "fit_statistics": fit_statistics,
        "profile": "fit.csv",
        "project": "final.gpx",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    audit = {
        "source": str(SOURCE),
        "stages": stages,
        "coordinate_trials": coord_trials,
        "first_final": first_final,
        "final": final_state,
        "deletion_tests": {
            name: {
                "Rwp_percent": item["Rwp_percent"],
                "converged": item["converged"],
                "physical": item["physical"],
                "project": item["project"],
            }
            for name, item in deletions.items()
        },
        "short_distances": {
            phase.name: phase.ShortDistances() for phase in project.phases()
        },
        "result": result,
    }
    (ANALYSIS / "final_audit.json").write_text(json.dumps(audit, indent=2) + "\n")
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
