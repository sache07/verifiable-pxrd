#!/usr/bin/env python3
"""Profile the correlated Suortti roughness subspace over physical A values."""

from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
SOURCE = ANALYSIS / "stable_profile_compare" / "U10.gpx"
OUT = ANALYSIS / "roughness_grid"


def curve_hash(hist):
    calc = np.asarray(hist.data["data"][1][3], dtype=np.float64)
    return hashlib.sha256(calc.tobytes()).hexdigest()


def run(a_value):
    tag = f"A{a_value:.2f}"
    gpx = OUT / f"{tag}.gpx"
    listing = OUT / f"{tag}.lst"
    p = G2sc.G2Project(str(SOURCE))
    h = p.histograms()[0]
    p.data["Controls"]["data"].update(
        {"max cyc": 16, "min dM/M": 1e-5, "shift factor": 0.25}
    )
    sample = h.data["Sample Parameters"]
    inst = h.data["Instrument Parameters"][0]
    # A is profiled on a physical grid; B and polarization are data-refined.
    sample["SurfRoughA"] = [a_value, False]
    sample["SurfRoughB"] = [0.08, False]
    inst["Polariz."][1] = 0.88
    p.set_refinement(
        {"clear": {"Sample Parameters": ["SurfRoughA", "SurfRoughB"]}}
    )
    p.set_refinement(
        {
            "set": {
                "Sample Parameters": ["SurfRoughB"],
                "Instrument Parameters": ["Polariz."],
            }
        }
    )
    p.refine(printFile=str(listing))
    p.save(str(gpx))
    fractions = h.ComputeMassFracs()
    phases = {}
    for phase in p.phases():
        hap = phase.data["Histograms"][h.name]
        phases[phase.name] = {
            "scale": float(hap["Scale"][0]),
            "cell": phase.get_cell(),
            "size_um": float(hap["Size"][1][0]),
            "mustrain_ppm": float(hap["Mustrain"][1][0]),
        }
    result = copy.deepcopy(
        {
            "A_fixed": a_value,
            "B_refined": float(sample["SurfRoughB"][0]),
            "polarization_refined": float(inst["Polariz."][1]),
            "Rwp_percent": float(h.get_wR()),
            "physical": bool(
                0 <= a_value <= 1
                and sample["SurfRoughB"][0] >= 0
                and 0 <= inst["Polariz."][1] <= 1
            ),
            "mass_fractions": fractions,
            "phases": phases,
            "curve_sha256": curve_hash(h),
            "project": str(gpx),
        }
    )
    with (OUT / f"{tag}.json").open("w") as handle:
        json.dump(result, handle, indent=2)
    return result


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    results = [run(value) for value in (0.05, 0.10, 0.20, 0.40, 0.60, 0.80)]
    # Quantify predictive equivalence of the fitted roughness branches.
    curves = {}
    for item in results:
        project = G2sc.G2Project(item["project"])
        curves[f"A{item['A_fixed']:.2f}"] = np.asarray(
            project.histograms()[0].data["data"][1][3], dtype=float
        )
    reference = curves["A0.20"]
    for item in results:
        curve = curves[f"A{item['A_fixed']:.2f}"]
        item["curve_rms_vs_A0.20_counts"] = float(np.sqrt(np.mean((curve - reference) ** 2)))
        item["curve_max_abs_vs_A0.20_counts"] = float(np.max(np.abs(curve - reference)))
    with (OUT / "summary.json").open("w") as handle:
        json.dump(results, handle, indent=2)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
