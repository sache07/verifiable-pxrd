#!/usr/bin/env python3
"""Matched texture-aware coordinate retests for credible parents/restarts."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import coordinate_parent_compare as cpc
import final_mechanism_screen as fms
import texture_parent_restarts as tpr


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
OUT = ANALYSIS / "texture_coordinate_parent_retests"

SOURCES = {
    "monoclinic_1528915_U10": ANALYSIS / "texture_parent_restarts" / "monoclinic_1528915_U10" / "texture_001.gpx",
    "triclinic_2106293_U10": ANALYSIS / "texture_parent_restarts" / "triclinic_2106293_U10" / "texture_001.gpx",
    "monoclinic_2311041_U2": ANALYSIS / "texture_parent_restarts" / "monoclinic_2311041_U2" / "texture_001.gpx",
    "monoclinic_2311041_U20": ANALYSIS / "texture_parent_restarts" / "monoclinic_2311041_U20" / "texture_001.gpx",
}


def stabilize(project, branch):
    stages = []
    tpr.set_strain_flags(project, False)
    tpr.set_profile_flags(project, True)
    fms.refine(project, branch / "profile.lst")
    stages.append(fms.state(project, "profile"))

    tpr.set_profile_flags(project, False)
    tpr.set_size_flags(project, True)
    fms.refine(project, branch / "size.lst")
    stages.append(fms.state(project, "size"))

    tpr.set_size_flags(project, False)
    tpr.set_strain_flags(project, True)
    fms.refine(project, branch / "strain.lst")
    stages.append(fms.state(project, "strain"))

    tpr.set_strain_flags(project, False)
    tpr.set_profile_flags(project, True)
    fms.refine(project, branch / "profile_repeat.lst")
    stages.append(fms.state(project, "profile_repeat"))

    tpr.set_profile_flags(project, False)
    tpr.set_strain_flags(project, True)
    fms.refine(project, branch / "strain_repeat.lst")
    stages.append(fms.state(project, "strain_repeat"))
    return stages


def run(tag, source):
    branch = OUT / tag
    branch.mkdir(parents=True, exist_ok=True)
    target = branch / "refined.gpx"
    listing = branch / "coordinates.lst"
    project = G2sc.G2Project(str(source))
    project.save(str(target))
    fms.configure_supported_flags(project)
    hist = project.histograms()[0]
    po = project.phase("WO3_candidate").data["Histograms"][hist.name]["Pref.Ori."]
    po[0], po[2], po[3] = "MD", True, [0, 0, 1]
    stages = stabilize(project, branch)
    project.save(str(target))

    project.data["Controls"]["data"].update(
        {"max cyc": 10, "min dM/M": 1e-5, "shift factor": 0.12}
    )
    trials = []
    project, hist, result = cpc.try_coordinate_block(
        project, hist, "CaWO4_scheelite", ["O2"], "cawo4_O_retest", listing, target
    )
    trials.append(result)
    wlabels = [
        atom.label
        for atom in project.phase("WO3_candidate").atoms()
        if atom.element == "W"
    ]
    project, hist, result = cpc.try_coordinate_block(
        project, hist, "WO3_candidate", wlabels, "wo3_W_retest", listing, target
    )
    trials.append(result)
    project.save(str(target))
    project.phase("CaWO4_scheelite").export_CIF(str(branch / "CaWO4.cif"))
    project.phase("WO3_candidate").export_CIF(str(branch / "WO3.cif"))
    answer = {
        "tag": tag,
        "source": str(source),
        "stages": stages,
        "trials": trials,
        "final": fms.state(project, "final"),
        "project": str(target),
    }
    (branch / "result.json").write_text(json.dumps(answer, indent=2) + "\n")
    return answer


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    results = [run(tag, source) for tag, source in SOURCES.items()]
    (OUT / "summary.json").write_text(json.dumps(results, indent=2) + "\n")
    compact = [
        {
            "tag": item["tag"],
            "base_Rwp": item["stages"][-1]["Rwp_percent"],
            "final_Rwp": item["final"]["Rwp_percent"],
            "converged": item["final"]["converged"],
            "physical": item["final"]["physical"]["all"],
            "fractions": item["final"]["fractions"],
            "trials": item["trials"],
            "project": item["project"],
        }
        for item in results
    ]
    print(json.dumps(compact, indent=2))


if __name__ == "__main__":
    main()
