#!/usr/bin/env python3
"""Retest profile and structural blocks after accepting WO3 [001] texture."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import coordinate_parent_compare as cpc
import final_mechanism_screen as fms
import texture_parent_restarts as tpr


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
OUT = ANALYSIS / "cumulative_model_tests"
SOURCE = (
    ANALYSIS
    / "texture_parent_restarts"
    / "monoclinic_2311041_U10"
    / "texture_001.gpx"
)


def stabilize():
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / "cumulative.gpx"
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(target))
    fms.configure_supported_flags(project)
    hist = project.histograms()[0]
    po = project.phase("WO3_candidate").data["Histograms"][hist.name]["Pref.Ori."]
    po[0], po[2], po[3] = "MD", True, [0, 0, 1]
    stages = []

    tpr.set_strain_flags(project, False)
    tpr.set_profile_flags(project, True)
    fms.refine(project, OUT / "profile.lst")
    stages.append(fms.state(project, "profile"))

    tpr.set_profile_flags(project, False)
    tpr.set_size_flags(project, True)
    fms.refine(project, OUT / "size.lst")
    stages.append(fms.state(project, "size"))

    tpr.set_size_flags(project, False)
    tpr.set_strain_flags(project, True)
    fms.refine(project, OUT / "strain.lst")
    stages.append(fms.state(project, "strain"))

    tpr.set_strain_flags(project, False)
    tpr.set_profile_flags(project, True)
    fms.refine(project, OUT / "profile_repeat.lst")
    stages.append(fms.state(project, "profile_repeat"))

    tpr.set_profile_flags(project, False)
    tpr.set_strain_flags(project, True)
    fms.refine(project, OUT / "strain_repeat.lst")
    stages.append(fms.state(project, "strain_repeat"))
    project.save(str(target))
    return stages


def trial(name, mutate):
    target = OUT / f"{fms.safe_tag(name)}.gpx"
    try:
        project = G2sc.G2Project(str(OUT / "cumulative.gpx"))
        project.save(str(target))
        mutate(project)
        fms.refine(project, OUT / f"{fms.safe_tag(name)}.lst")
        project.save(str(target))
        result = fms.state(project, name)
        result["project"] = str(target)
        return result
    except Exception as exc:
        return {"label": name, "project": str(target), "error": repr(exc)}


def coordinate_retest():
    target = OUT / "coordinate_retest.gpx"
    listing = OUT / "coordinate_retest.lst"
    project = G2sc.G2Project(str(OUT / "cumulative.gpx"))
    project.save(str(target))
    project.data["Controls"]["data"].update(
        {"max cyc": 10, "min dM/M": 1e-5, "shift factor": 0.12}
    )
    hist = project.histograms()[0]
    trials = []
    accepted = []

    blocks = [
        ("CaWO4_scheelite", ["O2"], "cawo4_O_retest"),
        ("WO3_candidate", ["W0", "W1"], "wo3_W_retest"),
    ]
    blocks.extend(
        ("WO3_candidate", [label], f"wo3_{label}_retest")
        for label in ("O2", "O3", "O4", "O5", "O6", "O7")
    )
    for phase_name, labels, tag in blocks:
        project, hist, result = cpc.try_coordinate_block(
            project, hist, phase_name, labels, tag, listing, target
        )
        trials.append(result)
        if result["accepted"]:
            accepted.extend((phase_name, label) for label in labels)

    # Give accepted WO3 blocks one matched joint opportunity.
    wo_labels = [label for phase, label in accepted if phase == "WO3_candidate"]
    if wo_labels:
        project, hist, result = cpc.try_coordinate_block(
            project,
            hist,
            "WO3_candidate",
            wo_labels,
            "wo3_supported_joint_retest",
            listing,
            target,
        )
        trials.append(result)
    project.save(str(target))
    return {
        "trials": trials,
        "final": fms.state(project, "coordinate_retest_final"),
        "project": str(target),
    }


def main():
    stages = stabilize()
    base = stages[-1]
    tests = []

    for ncoeff in (6, 8, 10, 12):
        tests.append(
            trial(
                f"background_chebyschev-1_{ncoeff}",
                fms.set_background("chebyschev-1", ncoeff),
            )
        )
    tests.append(trial("background_cosine_8", fms.set_background("cosine", 8)))

    for axis in ([0, 0, 1], [1, 0, 0], [1, 1, 0]):
        suffix = "".join(map(str, axis))
        tests.append(
            trial(
                f"additional_texture_CaWO4_{suffix}",
                fms.set_po("CaWO4_scheelite", axis),
            )
        )

    axes = {
        "CaWO4_scheelite": ([0, 0, 1], [1, 0, 0], [1, 1, 0]),
        "WO3_candidate": ([0, 0, 1], [0, 1, 0], [1, 0, 0]),
    }
    for key in ("Size", "Mustrain"):
        for phase_name, phase_axes in axes.items():
            for axis in phase_axes:
                suffix = "".join(map(str, axis))
                tests.append(
                    trial(
                        f"uniaxial_{key}_{phase_name}_{suffix}",
                        fms.set_uniaxial(phase_name, key, axis),
                    )
                )

    tests.extend(
        [
            trial(
                "uiso_CaWO4_O",
                fms.set_uiso("CaWO4_scheelite", lambda atom: atom.element == "O"),
            ),
            trial(
                "uiso_CaWO4_cations",
                fms.set_uiso("CaWO4_scheelite", lambda atom: atom.element != "O"),
            ),
            trial(
                "uiso_WO3_W",
                fms.set_uiso("WO3_candidate", lambda atom: atom.element == "W"),
            ),
            trial(
                "uiso_WO3_O",
                fms.set_uiso("WO3_candidate", lambda atom: atom.element == "O"),
            ),
        ]
    )
    coords = coordinate_retest()
    result = {
        "source": str(SOURCE),
        "stages": stages,
        "baseline": base,
        "tests": tests,
        "coordinate_retest": coords,
    }
    (OUT / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    compact = [
        {
            "label": item.get("label"),
            "Rwp_percent": item.get("Rwp_percent"),
            "delta_Rwp": item.get("Rwp_percent", base["Rwp_percent"]) - base["Rwp_percent"],
            "converged": item.get("converged"),
            "physical": item.get("physical", {}).get("all"),
            "fractions": item.get("fractions"),
            "error": item.get("error"),
        }
        for item in tests
    ]
    print(json.dumps({"stages": stages, "tests": compact, "coordinates": coords}, indent=2))


if __name__ == "__main__":
    main()
