#!/usr/bin/env python3
"""Restage nonconvergent triclinic WO3 movement as one W site at a time."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import coordinate_parent_compare as cpc


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
OUT = ANALYSIS / "triclinic_restage"

SOURCES = {
    "U10": ANALYSIS / "coordinate_parent_compare" / "triclinic_2106293" / "refined_wo3_W_checkpoint.gpx",
    "U2": ANALYSIS / "lineage_restarts" / "triclinic_2106293_U2" / "refined_wo3_W_checkpoint.gpx",
    "U20": ANALYSIS / "lineage_restarts" / "triclinic_2106293_U20" / "refined_wo3_W_checkpoint.gpx",
}


def run(tag, source):
    branch = OUT / tag
    branch.mkdir(parents=True, exist_ok=True)
    target = branch / "refined.gpx"
    listing = branch / "refined.lst"
    p = G2sc.G2Project(str(source))
    p.save(str(target))
    p.data["Controls"]["data"].update(
        {"max cyc": 12, "min dM/M": 1e-5, "shift factor": 0.15}
    )
    h = p.histograms()[0]
    wo = p.phase("WO3_candidate")
    wlabels = [atom.label for atom in wo.atoms() if atom.element == "W"]
    trials = []
    accepted = []
    for label in wlabels:
        p, h, trial = cpc.try_coordinate_block(
            p, h, "WO3_candidate", [label], f"wo3_{label}", listing, target
        )
        trials.append(trial)
        if trial["accepted"]:
            accepted.append(label)
    sequential = cpc.state(p, h, "sequential_W")
    if accepted:
        p, h, trial = cpc.try_coordinate_block(
            p, h, "WO3_candidate", accepted, "wo3_supported_joint", listing, target
        )
        trials.append(trial)
    final = cpc.state(p, h, "final")
    p.save(str(target))
    p.phase("CaWO4_scheelite").export_CIF(str(branch / "CaWO4_refined.cif"))
    p.phase("WO3_candidate").export_CIF(str(branch / "WO3_refined.cif"))
    rvals = p.data["Covariance"]["data"].get("Rvals", {})
    result = {
        "restart": tag,
        "source": str(source),
        "trials": trials,
        "sequential": sequential,
        "final": final,
        "mass_fractions": h.ComputeMassFracs(),
        "final_converged": bool(rvals.get("converged", False)),
        "final_max_shift_esd": rvals.get("Max shft/sig"),
        "project": str(target),
    }
    with (branch / "result.json").open("w") as handle:
        json.dump(result, handle, indent=2)
    return result


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    results = [run(tag, source) for tag, source in SOURCES.items()]
    summary = [
        {
            "restart": item["restart"],
            "Rwp_percent": item["final"]["Rwp_percent"],
            "fractions": item["mass_fractions"],
            "converged": item["final_converged"],
            "max_shift_esd": item["final_max_shift_esd"],
            "trials": item["trials"],
            "project": item["project"],
        }
        for item in results
    ]
    with (OUT / "summary.json").open("w") as handle:
        json.dump(summary, handle, indent=2)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
