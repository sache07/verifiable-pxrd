#!/usr/bin/env python3
"""Matched restrained coordinate adaptation for credible WO3 parent lineages."""

from __future__ import annotations

import copy
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
OUT = ANALYSIS / "coordinate_parent_compare"

PARENTS = {
    "monoclinic_1528915": ANALYSIS / "models" / "wo3_monoclinic_1528915.cif",
    "monoclinic_2311041": ANALYSIS / "models" / "wo3_monoclinic_alt_2311041.cif",
    "triclinic_2106293": ANALYSIS / "models" / "wo3_triclinic_2106293.cif",
}


def state(project, hist, label):
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size_um": float(hap["Size"][1][0]),
            "mustrain_ppm": float(hap["Mustrain"][1][0]),
            "atoms": {
                atom.label: {
                    "element": atom.element,
                    "coordinates": list(atom.coordinates),
                    "uiso": float(atom.uiso),
                    "refinement_flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            },
        }
    return copy.deepcopy(
        {
            "label": label,
            "Rwp_percent": float(hist.get_wR()),
            "residuals": hist.residuals,
            "instrument": {
                key: value[1]
                for key, value in inst.items()
                if isinstance(value, list)
            },
            "sample": {
                key: value[0]
                for key, value in sample.items()
                if isinstance(value, list) and len(value) == 2
            },
            "phases": phases,
        }
    )


def lattice_matrix(cell):
    a, b, c = cell["length_a"], cell["length_b"], cell["length_c"]
    alpha = math.radians(cell["angle_alpha"])
    beta = math.radians(cell["angle_beta"])
    gamma = math.radians(cell["angle_gamma"])
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * math.cos(gamma), b * math.sin(gamma), 0.0])
    cx = c * math.cos(beta)
    cy = c * (math.cos(alpha) - math.cos(beta) * math.cos(gamma)) / math.sin(gamma)
    cz = math.sqrt(max(c * c - cx * cx - cy * cy, 0.0))
    return np.vstack((va, vb, np.array([cx, cy, cz])))


def coordinate_moves(phase, before):
    matrix = lattice_matrix(phase.get_cell())
    moves = {}
    for atom in phase.atoms():
        if atom.label not in before:
            continue
        delta = np.asarray(atom.coordinates) - np.asarray(before[atom.label])
        delta -= np.round(delta)
        moves[atom.label] = float(np.linalg.norm(delta @ matrix))
    return moves


def atom_coordinates(phase):
    return {atom.label: list(atom.coordinates) for atom in phase.atoms()}


def set_atom_flags(phase, labels, flags):
    for label in labels:
        phase.atom(label).refinement_flags = flags


def initialize_restraints(project, cawo4, wo3):
    rest = project.data["Restraints"]["data"]
    for phase in (cawo4, wo3):
        rest[phase.name] = {
            "Bond": {"wtFactor": 1.0, "Range": 1.1, "Bonds": [], "Use": True}
        }
    # Scheelite tetrahedral W-O and eightfold Ca-O environments.
    cawo4.addDistRestraint(["W1"], ["O2"], 1.76, factor=1.20, ESD=0.05)
    cawo4.addDistRestraint(["Ca0"], ["O2"], 2.47, factor=1.12, ESD=0.08)
    cawo4.setDistRestraintWeight(10.0)
    # Weak octahedral envelope: allows the known WO3 distortion while preventing drift.
    wlabels = [atom.label for atom in wo3.atoms() if atom.element == "W"]
    olabels = [atom.label for atom in wo3.atoms() if atom.element == "O"]
    wo3.addDistRestraint(wlabels, olabels, 1.95, factor=1.30, ESD=0.15)
    wo3.setDistRestraintWeight(10.0)


def refine(project, listing):
    project.refine(printFile=str(listing))


def try_coordinate_block(project, hist, phase_name, labels, tag, listing, workgpx):
    phase = project.phase(phase_name)
    checkpoint = workgpx.with_name(f"{workgpx.stem}_{tag}_checkpoint.gpx")
    # Preserve an immutable pre-trial checkpoint. GSAS-II always writes a
    # refinement into the project's current filename, so switch back to the
    # working GPX before invoking refine.
    project.save(str(checkpoint))
    project.save(str(workgpx))
    before_rwp = float(hist.get_wR())
    before_coords = atom_coordinates(phase)
    set_atom_flags(phase, labels, "X")
    refine(project, listing)
    set_atom_flags(phase, labels, " ")
    after_rwp = float(hist.get_wR())
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    converged = bool(rvals.get("converged", False))
    max_shift_esd = rvals.get("Max shft/sig")
    moves = coordinate_moves(phase, before_coords)
    selected_moves = {label: moves[label] for label in labels}
    max_move = max(selected_moves.values(), default=0.0)
    short = phase.ShortDistances()
    accepted = bool(
        np.isfinite(after_rwp)
        and converged
        and after_rwp < before_rwp - 0.001
        and max_move <= 0.20
        and not short
    )
    trial = {
        "tag": tag,
        "phase": phase_name,
        "labels": labels,
        "Rwp_before": before_rwp,
        "Rwp_after_trial": after_rwp,
        "converged": converged,
        "max_shift_esd": max_shift_esd,
        "coordinate_moves_A": selected_moves,
        "max_coordinate_move_A": max_move,
        "short_distances": short,
        "accepted": accepted,
    }
    if accepted:
        project.save(str(workgpx))
        return project, project.histograms()[0], trial
    project = G2sc.G2Project(str(checkpoint))
    project.save(str(workgpx))
    return project, project.histograms()[0], trial


def run(name, parent_cif):
    branch = OUT / name
    branch.mkdir(parents=True, exist_ok=True)
    gpx = branch / "refined.gpx"
    listing = branch / "refined.lst"
    p = G2sc.G2Project(newgpx=str(gpx))
    h = p.add_powder_histogram(
        str(ANALYSIS / "pattern.xye"),
        str(ANALYSIS / "cu_ka.instprm"),
        fmthint="xye",
    )
    ca = p.add_phase(
        str(ANALYSIS / "models" / "cawo4_scheelite_7219229.cif"),
        phasename="CaWO4_scheelite",
        histograms=[h],
        fmthint="CIF",
    )
    wo = p.add_phase(
        str(parent_cif),
        phasename="WO3_candidate",
        histograms=[h],
        fmthint="CIF",
    )
    initialize_restraints(p, ca, wo)
    p.data["Controls"]["data"].update(
        {"max cyc": 14, "min dM/M": 1e-5, "shift factor": 0.25}
    )
    h.data["Sample Parameters"]["Scale"] = [1.0, False]
    h.data["Sample Parameters"]["Shift"] = [210.0, False]
    h.data["Sample Parameters"]["SurfRoughA"] = [0.10, False]
    h.data["Sample Parameters"]["SurfRoughB"] = [0.08, False]
    inst = h.data["Instrument Parameters"][0]
    for key, value in {
        "U": 10.0,
        "V": 0.0,
        "W": 15.0,
        "X": 2.0,
        "SH/L": 0.01,
        "Polariz.": 0.85,
    }.items():
        inst[key][1] = value
    for phase, scale in ((ca, 1.0), (wo, 0.3)):
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][0] = scale
        hap["Size"][1][0] = 0.15
        hap["Mustrain"][1][0] = 800.0

    stages = []
    p.set_refinement(
        {
            "set": {
                "Background": {
                    "type": "chebyschev-1",
                    "no. coeffs": 8,
                    "coeffs": [1100.0, -550.0, 150.0, -50.0, 0.0, 0.0, 0.0, 0.0],
                    "refine": True,
                },
                "Scale": True,
            }
        }
    )
    refine(p, listing)
    p.set_refinement(
        {"set": {"Sample Parameters": ["Shift"], "Cell": True}}
    )
    refine(p, listing)
    p.set_refinement(
        {"set": {"Instrument Parameters": ["W", "X", "SH/L"]}}
    )
    refine(p, listing)
    if inst["SH/L"][1] < 0:
        inst["SH/L"][1] = 0.01
        p.set_refinement({"clear": {"Instrument Parameters": ["SH/L"]}})
        refine(p, listing)
    stages.append(state(p, h, "common_profile"))

    p.set_refinement(
        {
            "set": {
                "Sample Parameters": ["SurfRoughB"],
                "Instrument Parameters": ["Polariz."],
            }
        }
    )
    refine(p, listing)
    stages.append(state(p, h, "roughness_polarization"))

    p.set_refinement(
        {"clear": {"Instrument Parameters": ["W", "X", "SH/L", "Polariz."],
                   "Sample Parameters": ["SurfRoughB"]}}
    )
    p.set_refinement(
        {"set": {"Size": {"type": "isotropic", "refine": True}}}
    )
    refine(p, listing)
    p.set_refinement({"clear": {"Size": True}})
    p.set_refinement(
        {"set": {"Mustrain": {"type": "isotropic", "refine": True}}}
    )
    refine(p, listing)
    stages.append(state(p, h, "size_strain"))
    p.save(str(gpx))

    trials = []
    p.data["Controls"]["data"]["max cyc"] = 8
    p, h, trial = try_coordinate_block(
        p, h, "CaWO4_scheelite", ["O2"], "cawo4_O", listing, gpx
    )
    trials.append(trial)
    stages.append(state(p, h, "after_cawo4_O"))

    wo = p.phase("WO3_candidate")
    wlabels = [atom.label for atom in wo.atoms() if atom.element == "W"]
    p, h, trial = try_coordinate_block(
        p, h, "WO3_candidate", wlabels, "wo3_W", listing, gpx
    )
    trials.append(trial)
    stages.append(state(p, h, "after_wo3_W"))

    wo = p.phase("WO3_candidate")
    olabels = [atom.label for atom in wo.atoms() if atom.element == "O"]
    accepted_oxygen = []
    for label in olabels:
        p, h, trial = try_coordinate_block(
            p, h, "WO3_candidate", [label], f"wo3_{label}", listing, gpx
        )
        trials.append(trial)
        if trial["accepted"]:
            accepted_oxygen.append(label)
    stages.append(state(p, h, "after_sequential_wo3_O"))

    # Jointly re-equilibrate only blocks that were individually supported.
    wo = p.phase("WO3_candidate")
    supported = wlabels + accepted_oxygen
    if supported:
        p, h, trial = try_coordinate_block(
            p, h, "WO3_candidate", supported, "wo3_supported_joint", listing, gpx
        )
        trials.append(trial)
    stages.append(state(p, h, "final_coordinates"))
    p.save(str(gpx))
    p.phase("CaWO4_scheelite").export_CIF(str(branch / "CaWO4_refined.cif"))
    p.phase("WO3_candidate").export_CIF(str(branch / "WO3_refined.cif"))
    fractions = h.ComputeMassFracs()
    result = {
        "parent": name,
        "parent_cif": str(parent_cif),
        "project": str(gpx),
        "stages": stages,
        "coordinate_trials": trials,
        "mass_fractions": fractions,
        "exports": {
            "CaWO4": str(branch / "CaWO4_refined.cif"),
            "WO3": str(branch / "WO3_refined.cif"),
        },
    }
    with (branch / "result.json").open("w") as handle:
        json.dump(result, handle, indent=2)
    return result


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    results = [run(name, path) for name, path in PARENTS.items()]
    summary = {
        item["parent"]: {
            "Rwp_percent": item["stages"][-1]["Rwp_percent"],
            "mass_fractions": item["mass_fractions"],
            "accepted_trials": [
                trial["tag"] for trial in item["coordinate_trials"] if trial["accepted"]
            ],
            "exports": item["exports"],
        }
        for item in results
    }
    with (OUT / "summary.json").open("w") as handle:
        json.dump(summary, handle, indent=2)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
