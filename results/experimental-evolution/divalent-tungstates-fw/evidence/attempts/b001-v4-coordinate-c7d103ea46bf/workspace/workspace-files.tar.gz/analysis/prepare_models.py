#!/usr/bin/env python3
"""Prepare public-pattern data and normalized candidate CIFs for GSAS-II."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from pymatgen.io.cif import CifParser, CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path(__file__).resolve().parents[1]
LIBRARY = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/"
    "resources/b001-c05/cif"
)

CANDIDATES = {
    "cawo4_scheelite_7219229": "7219229",
    "cawo4_monoclinic_1546035": "1546035",
    "wo3_monoclinic_1528915": "1528915",
    "wo3_monoclinic_alt_2311041": "2311041",
    "wo3_triclinic_2106293": "2106293",
    "wo3_orthorhombic_2107312": "2107312",
    "cao_rocksalt_1563196": "1563196",
    "ca_w_oxide_ttb_4030741": "4030741",
}


def cod_path(cod_id: str) -> Path:
    return LIBRARY / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def minimum_distance(structure) -> float:
    distances = [
        structure.get_distance(i, j)
        for i in range(len(structure))
        for j in range(i + 1, len(structure))
    ]
    return float(min(distances))


def main() -> None:
    out = ROOT / "analysis" / "models"
    out.mkdir(parents=True, exist_ok=True)

    pattern = pd.read_csv(ROOT / "inputs" / "pattern.csv")
    x = pattern["two_theta_deg"].to_numpy(float)
    y = pattern["intensity"].to_numpy(float)
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(
        ROOT / "analysis" / "pattern.xye",
        np.column_stack((x, y, sigma)),
        fmt=("%.8f", "%.8f", "%.8f"),
        header="two_theta_deg intensity sigma_poisson",
    )

    records = []
    for label, cod_id in CANDIDATES.items():
        source = cod_path(cod_id)
        parser = CifParser(source, occupancy_tolerance=1.05)
        structures = parser.parse_structures(primitive=False)
        if len(structures) != 1:
            raise RuntimeError(f"Expected one structure in {source}, found {len(structures)}")
        structure = structures[0]
        analyzer = SpacegroupAnalyzer(structure, symprec=0.02, angle_tolerance=2.0)
        # Re-express each parent in a symmetry-refined conventional setting.
        # This is an exact basis/origin normalization, not a coordinate fit.
        normalized_structure = analyzer.get_refined_structure()
        normalized_analyzer = SpacegroupAnalyzer(
            normalized_structure, symprec=0.02, angle_tolerance=2.0
        )
        normalized = out / f"{label}.cif"
        CifWriter(
            normalized_structure, symprec=0.01, refine_struct=False
        ).write_file(normalized)
        occupancies = [
            float(sum(site.species.values())) for site in normalized_structure
        ]
        records.append(
            {
                "label": label,
                "cod_id": cod_id,
                "source_cif": str(source),
                "normalized_cif": str(normalized.relative_to(ROOT)),
                "formula": structure.composition.reduced_formula,
                "normalization": "pymatgen SpacegroupAnalyzer.get_refined_structure; exact basis/origin transformation",
                "n_sites_conventional": len(normalized_structure),
                "space_group_symbol": normalized_analyzer.get_space_group_symbol(),
                "space_group_number": normalized_analyzer.get_space_group_number(),
                "source_cell": {
                    "a": structure.lattice.a,
                    "b": structure.lattice.b,
                    "c": structure.lattice.c,
                    "alpha": structure.lattice.alpha,
                    "beta": structure.lattice.beta,
                    "gamma": structure.lattice.gamma,
                    "volume": structure.volume,
                },
                "cell": {
                    "a": normalized_structure.lattice.a,
                    "b": normalized_structure.lattice.b,
                    "c": normalized_structure.lattice.c,
                    "alpha": normalized_structure.lattice.alpha,
                    "beta": normalized_structure.lattice.beta,
                    "gamma": normalized_structure.lattice.gamma,
                    "volume": normalized_structure.volume,
                },
                "minimum_interatomic_distance_A": minimum_distance(normalized_structure),
                "site_occupancy_min": min(occupancies),
                "site_occupancy_max": max(occupancies),
                "parser_warnings": parser.warnings,
            }
        )

    with (ROOT / "analysis" / "model_screen.json").open("w") as handle:
        json.dump({"records": records}, handle, indent=2)


if __name__ == "__main__":
    main()
