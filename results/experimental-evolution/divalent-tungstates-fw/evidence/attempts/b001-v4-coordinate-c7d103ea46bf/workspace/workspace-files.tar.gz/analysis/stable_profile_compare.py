#!/usr/bin/env python3
"""Restaged physically constrained profile/broadening comparisons."""

from __future__ import annotations

import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
OUT = ANALYSIS / "stable_profile_compare"


def state(project, hist, label):
    inst = hist.data["Instrument Parameters"][0]
    samp = hist.data["Sample Parameters"]
    theta = np.linspace(5.0, 50.0, 1000)
    tanth = np.tan(np.deg2rad(theta))
    caglioti = inst["U"][1] * tanth**2 + inst["V"][1] * tanth + inst["W"][1]
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size_um": float(hap["Size"][1][0]),
            "mustrain_ppm": float(hap["Mustrain"][1][0]),
        }
    return copy.deepcopy(
        {
            "label": label,
            "Rwp_percent": float(hist.get_wR()),
            "instrument": {
                key: value[1]
                for key, value in inst.items()
                if isinstance(value, list)
            },
            "sample": {
                key: value[0]
                for key, value in samp.items()
                if isinstance(value, list) and len(value) == 2
            },
            "phases": phases,
            "physical": {
                "caglioti_variance_min": float(np.min(caglioti)),
                "profile_nonnegative": bool(
                    np.min(caglioti) > 0
                    and inst["X"][1] >= 0
                    and inst["SH/L"][1] >= 0
                ),
                "roughness_physical": bool(
                    0 <= samp["SurfRoughA"][0] <= 1
                    and samp["SurfRoughB"][0] >= 0
                ),
                "polarization_physical": bool(0 <= inst["Polariz."][1] <= 1),
                "phase_broadening_physical": bool(
                    all(
                        item["size_um"] > 0 and item["mustrain_ppm"] >= 0
                        for item in phases.values()
                    )
                ),
            },
        }
    )


def refine(project, listing):
    project.refine(printFile=str(listing))


def run(fixed_u):
    tag = f"U{fixed_u:g}"
    OUT.mkdir(parents=True, exist_ok=True)
    gpx = OUT / f"{tag}.gpx"
    listing = OUT / f"{tag}.lst"
    p = G2sc.G2Project(newgpx=str(gpx))
    h = p.add_powder_histogram(
        str(ANALYSIS / "pattern.xye"),
        str(ANALYSIS / "cu_ka.instprm"),
        fmthint="xye",
    )
    ca = p.add_phase(
        str(ANALYSIS / "models" / "cawo4_scheelite_7219229.cif"),
        phasename="CaWO4_scheelite",
        histograms=[h],
        fmthint="CIF",
    )
    wo = p.add_phase(
        str(ANALYSIS / "models" / "wo3_monoclinic_1528915.cif"),
        phasename="WO3_monoclinic",
        histograms=[h],
        fmthint="CIF",
    )
    p.data["Controls"]["data"].update(
        {"max cyc": 12, "min dM/M": 1e-5, "shift factor": 0.35}
    )
    h.data["Sample Parameters"]["Scale"] = [1.0, False]
    h.data["Sample Parameters"]["Shift"][0] = 210.0
    inst = h.data["Instrument Parameters"][0]
    for key, value in {
        "U": fixed_u,
        "V": 0.0,
        "W": 15.0,
        "X": 2.0,
        "SH/L": 0.015,
    }.items():
        inst[key][1] = value
    for phase, scale in ((ca, 1.0), (wo, 0.3)):
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][0] = scale
        hap["Size"][1][0] = 0.15
        hap["Mustrain"][1][0] = 800.0

    states = []
    p.set_refinement(
        {
            "set": {
                "Background": {
                    "type": "chebyschev-1",
                    "no. coeffs": 8,
                    "coeffs": [1100.0, -550.0, 150.0, -50.0, 0.0, 0.0, 0.0, 0.0],
                    "refine": True,
                },
                "Scale": True,
            }
        }
    )
    refine(p, listing)
    p.set_refinement(
        {"set": {"Sample Parameters": ["Shift"], "Cell": True}}
    )
    refine(p, listing)
    states.append(state(p, h, "shift_cells"))

    p.set_refinement(
        {"set": {"Instrument Parameters": ["W", "X", "SH/L"]}}
    )
    refine(p, listing)
    # If axial divergence leaves its physical domain, restage it as fixed.
    if inst["SH/L"][1] < 0:
        inst["SH/L"][1] = 0.01
        p.set_refinement({"clear": {"Instrument Parameters": ["SH/L"]}})
        refine(p, listing)
    states.append(state(p, h, "common_profile"))

    p.set_refinement({"set": {"Instrument Parameters": ["Polariz."]}})
    refine(p, listing)
    states.append(state(p, h, "polarization"))
    p.set_refinement({"clear": {"Instrument Parameters": ["Polariz."]}})

    h.data["Sample Parameters"]["SurfRoughA"][0] = 0.25
    h.data["Sample Parameters"]["SurfRoughB"][0] = 0.10
    p.set_refinement(
        {"set": {"Sample Parameters": ["SurfRoughA", "SurfRoughB"]}}
    )
    refine(p, listing)
    states.append(state(p, h, "roughness"))

    # Re-equilibrate the supported intensity nuisances as a combination.
    p.set_refinement({"set": {"Instrument Parameters": ["Polariz."]}})
    refine(p, listing)
    states.append(state(p, h, "roughness_polarization"))

    # Freeze common and intensity nuisance terms before phase broadening.
    p.set_refinement(
        {
            "clear": {
                "Instrument Parameters": ["W", "X", "SH/L", "Polariz."],
                "Sample Parameters": ["SurfRoughA", "SurfRoughB"],
            }
        }
    )
    p.set_refinement(
        {"set": {"Size": {"type": "isotropic", "refine": True}}}
    )
    refine(p, listing)
    states.append(state(p, h, "isotropic_size"))

    # Save a valid pre-strain branch so a negative strain solution is rejected.
    p.save(str(OUT / f"{tag}_prestrain.gpx"))
    p.set_refinement({"clear": {"Size": True}})
    p.set_refinement(
        {"set": {"Mustrain": {"type": "isotropic", "refine": True}}}
    )
    refine(p, listing)
    strain_state = state(p, h, "isotropic_size_strain")
    states.append(strain_state)
    if not strain_state["physical"]["phase_broadening_physical"]:
        # Continue from the last fully physical project.
        p = G2sc.G2Project(str(OUT / f"{tag}_prestrain.gpx"))
        h = p.histograms()[0]
        states.append(state(p, h, "strain_rejected_restore_size"))
    p.save(str(gpx))
    fractions = h.ComputeMassFracs()
    result = {
        "fixed_U": fixed_u,
        "project": str(gpx),
        "states": states,
        "mass_fractions": fractions,
    }
    with (OUT / f"{tag}.json").open("w") as handle:
        json.dump(result, handle, indent=2)
    return result


def main():
    results = [run(value) for value in (2.0, 10.0, 20.0, 40.0)]
    summary = {
        f"U{item['fixed_U']:g}": {
            "Rwp_percent": item["states"][-1]["Rwp_percent"],
            "physical": item["states"][-1]["physical"],
            "instrument": item["states"][-1]["instrument"],
            "sample": item["states"][-1]["sample"],
            "phases": item["states"][-1]["phases"],
            "fractions": item["mass_fractions"],
        }
        for item in results
    }
    with (OUT / "summary.json").open("w") as handle:
        json.dump(summary, handle, indent=2)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
