#!/usr/bin/env python3
"""Independently reload and refine final.gpx, then compare submitted outputs."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "analysis" / "replay"


def snapshot(project):
    hist = project.histograms()[0]
    arr = np.ma.asarray(hist.data["data"][1])
    fractions = {
        key: [float(value[0]), float(value[1])]
        for key, value in hist.ComputeMassFracs().items()
    }
    phases = {}
    for phase in project.phases():
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "atoms": {
                atom.label: {
                    "element": atom.element,
                    "coordinates": list(map(float, atom.coordinates)),
                    "uiso": float(atom.uiso),
                }
                for atom in phase.atoms()
            },
            "use": bool(phase.data["Histograms"][hist.name]["Use"]),
        }
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "Rwp_percent": float(hist.get_wR()),
        "GOF": float(rvals.get("GOF", math.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "fractions": fractions,
        "phases": phases,
        "x": np.ma.filled(arr[0], np.nan),
        "ycalc": np.ma.filled(arr[3], np.nan),
        "ydiff": np.ma.filled(arr[5], np.nan),
    }


def serializable(snapshot):
    return {key: value for key, value in snapshot.items() if key not in {"x", "ycalc", "ydiff"}}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    submitted = G2sc.G2Project(str(ROOT / "final.gpx"))
    before = snapshot(submitted)

    replay_gpx = OUT / "final_replay.gpx"
    submitted.save(str(replay_gpx))
    submitted.refine(printFile=str(OUT / "final_replay.lst"))
    submitted.save(str(replay_gpx))
    after = snapshot(submitted)
    submitted.phase("CaWO4_scheelite").export_CIF(str(OUT / "phase_CaWO4_replay.cif"))
    submitted.phase("WO3_candidate").export_CIF(str(OUT / "phase_WO3_replay.cif"))

    ydelta = after["ycalc"] - before["ycalc"]
    fraction_delta = {
        key: after["fractions"][key][0] - before["fractions"][key][0]
        for key in before["fractions"]
    }
    coordinate_delta = {}
    max_fractional_coordinate_delta = 0.0
    max_cell_delta = 0.0
    for phase_name, phase in before["phases"].items():
        coordinate_delta[phase_name] = {}
        for label, atom in phase["atoms"].items():
            delta = np.asarray(after["phases"][phase_name]["atoms"][label]["coordinates"]) - np.asarray(atom["coordinates"])
            delta -= np.round(delta)
            value = float(np.linalg.norm(delta))
            coordinate_delta[phase_name][label] = value
            max_fractional_coordinate_delta = max(max_fractional_coordinate_delta, value)
        for key, value in phase["cell"].items():
            max_cell_delta = max(
                max_cell_delta,
                abs(float(after["phases"][phase_name]["cell"][key]) - float(value)),
            )

    comparison = {
        "Rwp_delta_percent": after["Rwp_percent"] - before["Rwp_percent"],
        "curve_rms_counts": float(np.sqrt(np.nanmean(ydelta**2))),
        "curve_max_abs_counts": float(np.nanmax(np.abs(ydelta))),
        "fraction_deltas": fraction_delta,
        "max_abs_fraction_delta": max(abs(value) for value in fraction_delta.values()),
        "max_cell_parameter_delta": max_cell_delta,
        "max_fractional_coordinate_delta": max_fractional_coordinate_delta,
        "coordinate_deltas": coordinate_delta,
        "positive_phase_inventory_identical": (
            set(before["phases"]) == set(after["phases"])
            and all(item["use"] for item in before["phases"].values())
            and all(item["use"] for item in after["phases"].values())
        ),
    }
    tolerances = {
        "Rwp_delta_percent": 0.001,
        "curve_rms_counts": 0.25,
        "max_abs_fraction_delta": 1e-4,
        "max_cell_parameter_delta": 1e-4,
        "max_fractional_coordinate_delta": 1e-6,
    }
    passed = bool(
        abs(comparison["Rwp_delta_percent"]) <= tolerances["Rwp_delta_percent"]
        and comparison["curve_rms_counts"] <= tolerances["curve_rms_counts"]
        and comparison["max_abs_fraction_delta"] <= tolerances["max_abs_fraction_delta"]
        and comparison["max_cell_parameter_delta"] <= tolerances["max_cell_parameter_delta"]
        and comparison["max_fractional_coordinate_delta"] <= tolerances["max_fractional_coordinate_delta"]
        and comparison["positive_phase_inventory_identical"]
        and after["converged"]
    )
    result = {
        "submitted": serializable(before),
        "replayed": serializable(after),
        "comparison": comparison,
        "tolerances": tolerances,
        "passed": passed,
        "replay_project": str(replay_gpx),
    }
    (OUT / "replay.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    if not passed:
        raise SystemExit("independent replay exceeded one or more tolerances")


if __name__ == "__main__":
    main()
