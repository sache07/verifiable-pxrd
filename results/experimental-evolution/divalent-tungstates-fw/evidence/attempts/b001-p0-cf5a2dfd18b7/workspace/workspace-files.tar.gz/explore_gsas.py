#!/usr/bin/env python3
"""Branching GSAS-II refinement experiments used to select profile models."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / ".tmp" / "refinement"


def copy_project(source: Path, target: Path):
    shutil.copy2(source, target)
    return G2.G2Project(str(target))


def po_search(source: Path, phase_index: int) -> None:
    axes = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])
    results = []
    for axis in axes:
        tag = "".join(map(str, axis))
        target = WORK / f"po-p{phase_index}-{tag}.gpx"
        project = copy_project(source, target)
        project.set_Controls("cycles", 8)
        phase = project.phases()[phase_index]
        hist = project.histograms()[0]
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = list(axis)
        project.set_Controls("parmMin", 0.7, f"{phase_index}:0:MD")
        project.set_Controls("parmMax", 1.4, f"{phase_index}:0:MD")
        project.refine()
        ratio = phase.data["Histograms"][hist.name]["Pref.Ori."][1]
        results.append({"axis": axis, "ratio": ratio, "rwp": hist.get_wR(), "gpx": str(target)})
        print(json.dumps(results[-1]), flush=True)
    print(json.dumps(sorted(results, key=lambda item: item["rwp"]), indent=2), flush=True)


def heavy_atom_refine(source: Path) -> None:
    target = WORK / "heavy-atoms.gpx"
    project = copy_project(source, target)
    project.set_Controls("cycles", 12)
    selections = {
        0: ("Zn0", "W1"),
        1: ("W0", "W1"),
        2: ("O1",),
    }
    for pidx, labels in selections.items():
        phase = project.phases()[pidx]
        phase.set_refinements({"Atoms": {label: "X" for label in labels}})
    project.refine()
    print("Rwp", project.histograms()[0].get_wR())
    for phase in project.phases():
        print(phase.name)
        for atom in phase.data["Atoms"]:
            print(atom[:11])


def all_atom_refine(source: Path) -> None:
    target = WORK / "all-atoms.gpx"
    project = copy_project(source, target)
    project.set_Controls("cycles", 15)
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": "X"}})
    project.refine()
    print("Rwp", project.histograms()[0].get_wR())
    for phase in project.phases():
        print(phase.name)
        for atom in phase.data["Atoms"]:
            print(atom[:11])


def targeted_atom_refine(source: Path) -> None:
    target = WORK / "targeted-atoms.gpx"
    project = copy_project(source, target)
    project.set_Controls("cycles", 15)
    project.phases()[0].set_refinements({"Atoms": {"all": "X"}})
    project.phases()[2].set_refinements({"Atoms": {"O1": "X"}})
    project.refine()
    print("Rwp", project.histograms()[0].get_wR())
    for phase in project.phases():
        print(phase.name)
        for atom in phase.data["Atoms"]:
            print(atom[:11])


def uiso_refine(source: Path) -> None:
    target = WORK / "uiso.gpx"
    project = copy_project(source, target)
    project.set_Controls("cycles", 12)
    for pidx, phase in enumerate(project.phases()):
        labels = []
        for atom in phase.data["Atoms"]:
            label = atom[0]
            labels.append(label)
            flags = atom[2]
            phase.set_refinements({"Atoms": {label: "XU" if "X" in flags else "U"}})
        variables = tuple(f"{pidx}::AUiso:{idx}" for idx in range(len(labels)))
        if len(variables) > 1:
            project.add_EquivConstr(variables)
        for variable in variables:
            project.set_Controls("parmMin", 0.003, variable)
            project.set_Controls("parmMax", 0.020, variable)
    project.refine()
    print("Rwp", project.histograms()[0].get_wR())
    for phase in project.phases():
        print(phase.name, [(atom[0], atom[10], atom[2]) for atom in phase.data["Atoms"]])


def full_grid_refine(source: Path) -> None:
    target = WORK / "full-grid.gpx"
    project = copy_project(source, target)
    hist = project.histograms()[0]
    x = hist.data["data"][1][0]
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    project.set_Controls("cycles", 8)
    project.refine()
    print("Rwp", hist.get_wR(), "limits", hist.data["Limits"])
    project.save(str(target))


def strain_search(source: Path, phase_index: int) -> None:
    axes = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])
    results = []
    for axis in axes:
        tag = "".join(map(str, axis))
        target = WORK / f"strain-p{phase_index}-{tag}.gpx"
        project = copy_project(source, target)
        project.set_Controls("cycles", 10)
        phase = project.phases()[phase_index]
        hist = project.histograms()[0]
        profile = phase.data["Histograms"][hist.name]["Mustrain"]
        value = float(profile[1][0])
        phase.setSampleProfile(hist.name, "microstrain", "uniaxial", value, value, axis, 1.0)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "uniaxial", "direction": axis, "refine": True,
                           "LGmix": {"value": 1.0, "refine": False}}}
        )
        for name in ("Mustrain;i", "Mustrain;a"):
            project.set_Controls("parmMin", 0.0, f"{phase_index}:0:{name}")
            project.set_Controls("parmMax", 8000.0, f"{phase_index}:0:{name}")
        project.refine()
        profile = phase.data["Histograms"][hist.name]["Mustrain"]
        results.append(
            {"axis": axis, "equatorial": profile[1][0], "axial": profile[1][1],
             "rwp": hist.get_wR(), "gpx": str(target)}
        )
        print(json.dumps(results[-1]), flush=True)
    print(json.dumps(sorted(results, key=lambda item: item["rwp"]), indent=2), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("po", "heavy", "allatoms", "targeted", "uiso", "fullgrid", "strain"))
    parser.add_argument("--source", type=Path, default=WORK / "trial.gpx")
    parser.add_argument("--phase", type=int, default=1)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    if args.mode == "po":
        po_search(args.source, args.phase)
    elif args.mode == "heavy":
        heavy_atom_refine(args.source)
    elif args.mode == "allatoms":
        all_atom_refine(args.source)
    elif args.mode == "targeted":
        targeted_atom_refine(args.source)
    elif args.mode == "uiso":
        uiso_refine(args.source)
    elif args.mode == "fullgrid":
        full_grid_refine(args.source)
    else:
        strain_search(args.source, args.phase)


if __name__ == "__main__":
    main()
