#!/usr/bin/env python3
"""Build and refine a three-phase GSAS-II model for the supplied PXRD scan."""

from __future__ import annotations

import csv
import json
import math
import os
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / "inputs"
WORK = ROOT / ".tmp" / "refinement"
RESOURCE_CIFS = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/"
    "resources/b001-c04/cif"
)


def cod_cif(cod_id: str) -> Path:
    return RESOURCE_CIFS / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_inputs() -> None:
    """Create normalized starting CIFs and GSAS-readable data/instrument files."""
    from pymatgen.core import Lattice, Structure

    runtime = ROOT / "learned" / "divalent-tungstates" / "runtime"
    sys.path.insert(0, str(runtime))
    from models import write_synthetic_model

    WORK.mkdir(parents=True, exist_ok=True)

    # The exact ZnWO4 composition is withheld from the supplied COD subset.
    # MgWO4 (COD 9013902) is the closest same-framework wolframite analogue;
    # replace Mg by Zn and begin from the established ZnWO4 metric.
    wolframite = Structure.from_file(cod_cif("9013902"), primitive=False)
    wolframite.remove_oxidation_states()
    for idx, site in enumerate(wolframite):
        if site.species_string == "Mg":
            wolframite.replace(idx, "Zn")
    wolframite = Structure(
        Lattice.monoclinic(4.703, 5.720, 4.923, 90.62),
        wolframite.species,
        wolframite.frac_coords,
    )
    write_synthetic_model(wolframite, WORK / "start_znwo4.cif")

    # The observed WO3 triplet and ZnO line series select these library phases.
    for cod_id, name in [("2311041", "wo3"), ("9004178", "zno")]:
        structure = Structure.from_file(cod_cif(cod_id), primitive=False)
        structure.remove_oxidation_states()
        write_synthetic_model(structure, WORK / f"start_{name}.cif")

    with (INPUTS / "pattern.csv").open(newline="") as fp:
        rows = list(csv.DictReader(fp))
    x = np.array([float(row["two_theta_deg"]) for row in rows])
    y = np.array([float(row["intensity"]) for row in rows])
    sig = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(WORK / "pattern.xye", np.column_stack((x, y, sig)), fmt="%.8f %.8f %.8f")

    # Broad but physically plausible starting profile; every value is later
    # estimated from the observed scan.
    (WORK / "instrument.instprm").write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.10;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def summarize(project, label: str) -> None:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    print(f"\n--- {label}: Rwp={hist.get_wR()} ---", flush=True)
    print(
        "instrument",
        {k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "SH/L", "Polariz.")},
        flush=True,
    )
    print(
        "sample",
        {k: sample[k][0] if isinstance(sample[k], list) else sample[k]
         for k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
        flush=True,
    )
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(
            phase.name,
            "cell", phase.data["General"]["Cell"][1:8],
            "scale", hap["Scale"][0],
            "size", hap["Size"][:4],
            "mustrain", hap["Mustrain"][:4],
            "PO", hap["Pref.Ori."][:4],
            flush=True,
        )


def run_gsas() -> None:
    from GSASII import GSASIIscriptable as G2

    G2.SetPrintLevel("all")
    gpx = WORK / "trial.gpx"
    if gpx.exists():
        gpx.unlink()
    project = G2.G2Project(newgpx=str(gpx))
    phases = [
        project.add_phase(str(WORK / "start_znwo4.cif"), phasename="ZnWO4_wolframite", fmthint="CIF"),
        project.add_phase(str(WORK / "start_wo3.cif"), phasename="WO3_monoclinic", fmthint="CIF"),
        project.add_phase(str(WORK / "start_zno.cif"), phasename="ZnO_wurtzite", fmthint="CIF"),
    ]
    hist = project.add_powder_histogram(
        str(WORK / "pattern.xye"),
        str(WORK / "instrument.instprm"),
        phases=phases,
        fmthint="xye",
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [-350.0, False]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [1000.0] + [0.0] * 9,
                "refine": True,
            },
        }
    )
    for phase in phases:
        phase.setSampleProfile(hist.name, "size", "isotropic", 0.3, LGmix=1.0)
        phase.setSampleProfile(hist.name, "microstrain", "isotropic", 1000.0, LGmix=1.0)
        phase.set_HAP_refinements({"Scale": True})

    # Bounds are the frozen laboratory envelope. They also prevent profile
    # correlations from producing mathematically useful but nonphysical widths.
    bounds = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
    }
    for pidx in range(len(phases)):
        bounds[f"{pidx}:0:Scale"] = (0.0, 1.0e4)
        bounds[f"{pidx}:0:Size;i"] = (0.04, 1.5)
        bounds[f"{pidx}:0:Mustrain;i"] = (0.0, 8000.0)
    for variable, (lower, upper) in bounds.items():
        project.set_Controls("parmMin", lower, variable)
        project.set_Controls("parmMax", upper, variable)

    project.set_Controls("cycles", 8)
    project.refine()
    summarize(project, "background and scales")

    # Peak positions: all three cells, a constant zero, and the shared
    # Bragg-Brentano specimen displacement.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements(
        {
            "Instrument Parameters": ["Zero"],
            "Sample Parameters": ["Shift"],
        }
    )
    project.refine()
    summarize(project, "cells, zero, and specimen displacement")

    # Phase-specific coherent size and strain are estimated before the common
    # instrument profile so phase width is not incorrectly absorbed by U/W/X.
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": 0.3,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                },
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                },
            }
        )
    project.refine()
    summarize(project, "phase size and microstrain")

    # Refine the common profile only after phase broadening is represented.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    project.refine()
    summarize(project, "bounded instrument profile")
    project.save(str(gpx))


if __name__ == "__main__":
    if "--gsas" in sys.argv:
        run_gsas()
    else:
        prepare_inputs()
        gsas_python = os.environ.get("GSAS2_PYTHON")
        if not gsas_python:
            raise RuntimeError("GSAS2_PYTHON is not set")
        subprocess.run([gsas_python, str(Path(__file__).resolve()), "--gsas"], check=True)
