#!/usr/bin/env python3
"""Apply a fractional step from one project's coordinates toward another's."""

import argparse
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("target", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("phase")
    ap.add_argument("elements")
    ap.add_argument("factor", type=float)
    a = ap.parse_args()
    shutil.copy2(a.base, a.output)
    base = G2.G2Project(gpxfile=str(a.output))
    target = G2.G2Project(gpxfile=str(a.target))
    elements = set(a.elements.split(","))
    p0, p1 = base.phase(a.phase), target.phase(a.phase)
    for atom0, atom1 in zip(p0.atoms(), p1.atoms()):
        atom0.refinement_flags = " "
        if atom0.element not in elements:
            continue
        x0 = np.asarray(atom0.coordinates, float)
        delta = np.asarray(atom1.coordinates, float) - x0
        delta -= np.round(delta)
        atom0.coordinates = tuple(x0 + a.factor * delta)
    base.save()
    print(f"saved {a.output}")


if __name__ == "__main__":
    main()
