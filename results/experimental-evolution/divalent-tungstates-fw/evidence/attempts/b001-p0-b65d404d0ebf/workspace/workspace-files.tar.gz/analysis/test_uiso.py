#!/usr/bin/env python3
"""Set one phase-wide isotropic ADP and re-optimize scales/background."""

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(h):
    x, y, w, yc = (np.asarray(v, float) for v in h.data["data"][1][:4])
    use = (x >= 10) & (x <= 100)
    return 100 * math.sqrt(np.sum(w[use] * (y[use] - yc[use]) ** 2) / np.sum(w[use] * y[use] ** 2))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("phase")
    ap.add_argument("uiso", type=float)
    ap.add_argument("--cycles", type=int, default=6)
    a = ap.parse_args()
    shutil.copy2(a.source, a.output)
    G2.SetPrintLevel("warn")
    p = G2.G2Project(gpxfile=str(a.output))
    h = p.histogram(0)
    h.data["Background"][0][1] = True
    for item in h.InstrumentParameters.values():
        if isinstance(item, list) and len(item) >= 3:
            item[2] = False
    for item in h.SampleParameters.values():
        if isinstance(item, list) and len(item) >= 2 and isinstance(item[1], bool):
            item[1] = False
    for ph in p.phases():
        ph.data["General"]["Cell"][0] = False
        hap = ph.data["Histograms"][h.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        for atom in ph.atoms():
            atom.refinement_flags = " "
    for atom in p.phase(a.phase).atoms():
        atom.uiso = a.uiso
    p.set_Controls("cycles", a.cycles)
    start = rwp(h)
    p.save()
    p.refine()
    p.save()
    vals = {
        ph.name: max(0, ph.data["Histograms"][h.name]["Scale"][0]) * ph.data["General"]["Mass"]
        for ph in p.phases()
    }
    total = sum(vals.values())
    print(json.dumps({"start": start, "end": rwp(h), "uiso": a.uiso,
                      "fractions": {k: v / total for k, v in vals.items()}}))


if __name__ == "__main__":
    main()
