#!/usr/bin/env python3
"""Add each analogue candidate to the current model and rank by GSAS-II fit."""

from __future__ import annotations

import json
import math
import shutil
import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]


def rwp(hist) -> float:
    x, y, w, yc = (np.asarray(a, float) for a in hist.data["data"][1][:4])
    use = (x >= 10.0) & (x <= 100.0)
    return 100 * math.sqrt(np.sum(w[use] * (y[use] - yc[use]) ** 2) / np.sum(w[use] * y[use] ** 2))


def fractions(project, hist) -> dict[str, float]:
    vals = {}
    for ph in project.phases():
        hap = ph.data["Histograms"][hist.name]
        vals[ph.name] = max(0.0, float(hap["Scale"][0])) * float(ph.data["General"]["Mass"])
    total = sum(vals.values())
    return {k: v / total for k, v in vals.items()} if total else vals


def clear_and_prepare(project, hist) -> None:
    # Keep only background and phase scales active in the parent model.
    hist.data["Background"][0][1] = True
    for item in hist.InstrumentParameters.values():
        if isinstance(item, list) and len(item) >= 3:
            item[2] = False
    for key, item in hist.SampleParameters.items():
        if isinstance(item, list) and len(item) >= 2 and isinstance(item[1], bool):
            item[1] = False
    for ph in project.phases():
        ph.data["General"]["Cell"][0] = False
        for atom in ph.atoms():
            atom.refinement_flags = " "
        hap = ph.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False


def run_one(row: dict, outdir: Path, cycles: int = 8) -> dict:
    cid = row["id"]
    dest = outdir / f"{cid}.gpx"
    shutil.copy2(ROOT / "analysis/model_md_all.gpx", dest)
    project = G2.G2Project(gpxfile=str(dest))
    hist = project.histogram(0)
    clear_and_prepare(project, hist)
    ph = project.add_phase(
        str(ROOT / row["candidate_cif"]),
        phasename=f"candidate_{cid}",
        histograms=[hist],
        fmthint="CIF",
    )
    for atom in ph.atoms():
        atom.uiso = 0.003
        atom.refinement_flags = " "
    hap = ph.data["Histograms"][hist.name]
    hap["Scale"] = [0.2, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.10
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    project.update_ids()
    project.set_Controls("cycles", cycles)
    pfx = f"{ph.id}:{hist.id}:"
    project.set_Controls("parmMin", 1e-8, variable=pfx + "Scale")
    project.set_Controls("parmMax", 1e5, variable=pfx + "Scale")
    project.set_Controls("parmMin", 0.04, variable=pfx + "Size;i")
    project.set_Controls("parmMax", 1.5, variable=pfx + "Size;i")
    project.save()

    stages = {}
    project.refine()
    stages["scale"] = rwp(hist)

    ph.data["General"]["Cell"][0] = True
    project.refine()
    stages["cell"] = rwp(hist)
    ph.data["General"]["Cell"][0] = False

    hap["Size"][2][0] = True
    project.refine()
    stages["size"] = rwp(hist)
    hap["Size"][2][0] = False
    project.save()
    result = {
        **row,
        "gpx": str(dest.relative_to(ROOT)),
        "rwp_stages": stages,
        "final_cell": ph.data["General"]["Cell"][1:8],
        "final_size_um": hap["Size"][1][0],
        "hap_scale": hap["Scale"][0],
        "fractions": fractions(project, hist),
    }
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ids", default="", help="comma-separated candidate IDs")
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--output", default="analysis/gsas_analogue_results.json")
    parser.add_argument("--cif", help="custom candidate CIF, relative to workspace")
    parser.add_argument("--custom-id", default="custom")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    rows = json.loads((ROOT / "analysis/analogue_candidates/manifest.json").read_text())
    if args.cif:
        rows = [{"id": args.custom_id, "formula": args.custom_id, "candidate_cif": args.cif}]
    wanted = {x.strip() for x in args.ids.split(",") if x.strip()}
    if wanted:
        rows = [row for row in rows if row["id"] in wanted]
    outdir = ROOT / "analysis/analogue_gsas"
    outdir.mkdir(exist_ok=True)
    results = []
    for i, row in enumerate(rows, 1):
        try:
            result = run_one(row, outdir, cycles=args.cycles)
            results.append(result)
            print(
                f"{i:2d}/{len(rows)} {row['id']} {row['formula']} "
                f"Rwp {result['rwp_stages']['size']:.4f} "
                f"fraction {result['fractions'].get('candidate_' + row['id'], 0):.4f}",
                flush=True,
            )
        except Exception as exc:
            print(f"{i:2d}/{len(rows)} {row['id']} FAILED {exc}", flush=True)
    results.sort(key=lambda r: r["rwp_stages"]["size"])
    dest = ROOT / args.output
    dest.write_text(json.dumps(results, indent=2) + "\n")
    print("\nBEST")
    for r in results[:20]:
        print(
            r["id"], r["formula"], r.get("mapped_formula", r["formula"]),
            r["rwp_stages"], r["fractions"].get("candidate_" + r["id"]),
            r["final_cell"],
        )


if __name__ == "__main__":
    main()
