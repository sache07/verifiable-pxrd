#!/usr/bin/env python3
"""Screen March-Dollase variants with the same GSAS-II forward model as the lab."""

from __future__ import annotations

import argparse
import json
import sys
from itertools import product
from pathlib import Path

import numpy as np
from scipy.optimize import nnls
from GSASII import GSASIIscriptable as G2


RUNTIME = Path("learned/divalent-tungstates/runtime").resolve()
sys.path.insert(0, str(RUNTIME))
from gsas_worker import run as run_worker  # noqa: E402


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])
RATIOS = (0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.4)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    out = args.outdir.resolve()
    out.mkdir(parents=True, exist_ok=True)

    project = G2.G2Project(gpxfile=str(args.gpx.resolve()))
    hist = project.histogram(0)
    cifs = []
    for phase in project.phases():
        path = out / f"{phase.name}.cif"
        phase.export_CIF(str(path))
        cifs.append(str(path))

    inst = hist.InstrumentParameters
    instrument = {
        "wavelength_ka1_A": float(inst["Lam1"][1]),
        "wavelength_ka2_A": float(inst["Lam2"][1]),
        "ka2_ka1_ratio": float(inst["I(L2)/I(L1)"][1]),
        "zero_deg": float(inst["Zero"][1]),
        "polarization": float(inst["Polariz."][1]),
        "U": float(inst["U"][1]),
        "V": float(inst["V"][1]),
        "W": float(inst["W"][1]),
        "X": float(inst["X"][1]),
        "SH_L": float(inst["SH/L"][1]),
    }
    sample = hist.SampleParameters
    sample_parameters = {
        "goniometer_radius_mm": float(sample["Gonio. radius"]),
        "shift_um": float(sample["Shift"][0]),
        "transparency": float(sample["Transparency"][0]),
        "surf_rough_A": float(sample["SurfRoughA"][0]),
        "surf_rough_B": float(sample["SurfRoughB"][0]),
    }

    options = []
    option_meta = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        base = {
            "size_um": float(hap["Size"][1][0]),
            "microstrain_ppm": float(hap["Mustrain"][1][0]),
        }
        phase_options = []
        phase_meta = []
        for ratio in RATIOS:
            axes = ([0, 0, 1],) if ratio == 1 else AXES
            for axis in axes:
                phase_options.append({**base, "md_ratio": ratio, "md_axis": list(axis)})
                phase_meta.append({"ratio": ratio, "axis": list(axis)})
        options.append(phase_options)
        option_meta.append(phase_meta)

    request = {
        "instrument": instrument,
        "grid": {
            "min": float(hist.data["data"][1][0][0]),
            "max": float(hist.data["data"][1][0][-1]),
            "step": float(np.median(np.diff(hist.data["data"][1][0]))),
        },
        "domain_size_um": 0.3,
        "cifs": cifs,
        "profile_variants": options,
        "sample_parameters": sample_parameters,
    }
    (out / "request.json").write_text(json.dumps(request, indent=2) + "\n")
    run_worker(request, out / "profiles.npz")

    with np.load(out / "profiles.npz") as archive:
        x = archive["x"].copy()
        profiles = archive["profiles"].copy()
    observed = np.asarray(hist.data["data"][1][1], float)
    if len(x) != len(observed) or np.max(np.abs(x - hist.data["data"][1][0])) > 1e-6:
        raise ValueError("profile grid differs from observations")

    # Smooth, positive basis that spans each disclosed background family.
    t = (x - x[0]) / (x[-1] - x[0])
    background = [(1 - t) ** 2, 2 * t * (1 - t), t**2]
    for scale in (5.0, 7.5, 10.0, 15.0, 20.0):
        background.append(np.exp(-(x - x[0]) / scale))
    for scale in (5.0, 10.0, 20.0):
        for power_value in (1.0, 1.5, 2.0, 2.5, 3.0):
            background.append((1 + (x - x[0]) / scale) ** (-power_value))
    background = np.column_stack(background)
    root_weight = np.sqrt(1 / np.maximum(observed, 1.0))
    denominator = float(np.sum(observed))

    offsets = np.cumsum([0] + [len(v) for v in options])

    def solve(indices):
        phase_bank = np.column_stack(
            [profiles[offsets[p] + idx] for p, idx in enumerate(indices)]
        )
        design = np.column_stack([phase_bank, background])
        coef, _ = nnls(design * root_weight[:, None], observed * root_weight, maxiter=10000)
        calculated = design @ coef
        chi = float(np.sum((observed - calculated) ** 2 / np.maximum(observed, 1.0)))
        return chi, coef, calculated

    selected = [next(i for i, row in enumerate(v) if row["ratio"] == 1.0) for v in option_meta]
    history = []
    for pass_index in range(5):
        changed = False
        for phase_index in range(len(options)):
            trials = []
            for option_index in range(len(options[phase_index])):
                indices = selected.copy()
                indices[phase_index] = option_index
                chi, coef, _ = solve(indices)
                trials.append((chi, option_index, coef[: len(options)]))
            trials.sort(key=lambda row: row[0])
            history.append(
                {
                    "pass": pass_index,
                    "phase": project.phases()[phase_index].name,
                    "top": [
                        {
                            "chi_square": row[0],
                            "option": option_meta[phase_index][row[1]],
                            "phase_coefficients": row[2].tolist(),
                        }
                        for row in trials[:8]
                    ],
                }
            )
            if selected[phase_index] != trials[0][1]:
                selected[phase_index] = trials[0][1]
                changed = True
        if not changed:
            break

    # Exhaust the strongest options retained by the coordinate screens.
    shortlist = []
    for phase_index in range(len(options)):
        trials = []
        for option_index in range(len(options[phase_index])):
            indices = selected.copy()
            indices[phase_index] = option_index
            trials.append((solve(indices)[0], option_index))
        shortlist.append([row[1] for row in sorted(trials)[:10]])
    best = None
    for indices in product(*shortlist):
        chi, coef, calculated = solve(indices)
        if best is None or chi < best[0]:
            best = (chi, list(indices), coef, calculated)
    chi, selected, coef, calculated = best
    phase_coef = coef[: len(options)]
    fractions = phase_coef / phase_coef.sum()
    result = {
        "chi_square": chi,
        "rwp_percent": 100 * np.sqrt(chi / denominator),
        "selection": [
            {
                "phase": phase.name,
                "option_index": idx,
                **option_meta[p][idx],
                "coefficient": float(phase_coef[p]),
                "weight_fraction": float(fractions[p]),
            }
            for p, (phase, idx) in enumerate(zip(project.phases(), selected))
        ],
        "history": history,
    }
    (out / "grid_result.json").write_text(json.dumps(result, indent=2) + "\n")
    np.savetxt(
        out / "grid_fit.csv",
        np.column_stack([x, observed, calculated, observed - calculated]),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
    )
    print(json.dumps({key: value for key, value in result.items() if key != "history"}, indent=2))


if __name__ == "__main__":
    main()
