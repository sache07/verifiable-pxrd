#!/usr/bin/env python3
"""Build and stage a small GSAS-II Rietveld refinement for candidate phases."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


LIBRARY = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/"
    "resources/b001-c05/cif"
)


def cif_for(cod_id: str) -> Path:
    return LIBRARY / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def instrument_text() -> str:
    # Midpoints of the disclosed laboratory ranges. Values are refined below.
    return (
        "#GSAS-II instrument parameter file; initial Cu Kalpha profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.10;Polariz.:0.75;Azimuth:0.0\n"
        "U:20.0;V:0.0;W:20.0;X:0.7745966692;Y:0.0;Z:0.0;SH/L:0.0223606798\n"
    )


def weighted_rwp(hist) -> float:
    x, y, w, yc = (np.asarray(a, float) for a in hist.data["data"][1][:4])
    return 100.0 * math.sqrt(float(np.sum(w * (y - yc) ** 2) / np.sum(w * y**2)))


def report(project, label: str) -> None:
    hist = project.histogram(0)
    print(
        json.dumps(
            {
                "stage": label,
                "residuals": hist.residuals,
                "recomputed_Rwp": weighted_rwp(hist),
                "instrument": {
                    key: value[1]
                    for key, value in hist.InstrumentParameters.items()
                    if key in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."}
                },
                "sample": {
                    key: (value[0] if isinstance(value, list) else value)
                    for key, value in hist.SampleParameters.items()
                    if key in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"}
                },
                "phases": {
                    phase.name: {
                        "cell": phase.get_cell(),
                        "hap_scale": phase.data["Histograms"][hist.name]["Scale"][0],
                        "size": phase.data["Histograms"][hist.name]["Size"],
                        "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
                        "preferred_orientation": phase.data["Histograms"][hist.name]["Pref.Ori."],
                    }
                    for phase in project.phases()
                },
            },
            default=str,
        ),
        flush=True,
    )


def run_refinement(project, label: str, cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    report(project, label)


def set_bounds(project, phases, hist) -> None:
    bounds = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.5, 1.0),
        ":0:SurfRoughA": (0.0, 0.6),
        ":0:SurfRoughB": (0.0, 0.5),
    }
    for phase in phases:
        pfx = f"{phase.id}:{hist.id}:"
        bounds[pfx + "Scale"] = (1e-8, 1e6)
        bounds[pfx + "Size;i"] = (0.04, 1.5)
        bounds[pfx + "Mustrain;i"] = (0.0, 8000.0)
        bounds[pfx + "Mustrain;a"] = (0.0, 32000.0)
        bounds[pfx + "MD"] = (0.7, 1.4)
    for variable, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("outdir", type=Path)
    parser.add_argument("ids", nargs="+", help="COD identifiers")
    parser.add_argument("--names", nargs="*")
    args = parser.parse_args()

    outdir = args.outdir.resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    names = args.names or [f"phase_{cod_id}" for cod_id in args.ids]
    if len(names) != len(args.ids):
        raise ValueError("--names must have one name per COD id")

    inst = outdir / "initial.instprm"
    inst.write_text(instrument_text())
    pattern = outdir / "pattern.csv"
    shutil.copy2(Path("inputs/pattern.csv").resolve(), pattern)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(outdir / "trial.gpx"))
    phases = [
        project.add_phase(str(cif_for(cod_id)), phasename=name, fmthint="CIF")
        for cod_id, name in zip(args.ids, names)
    ]
    hist = project.add_powder_histogram(
        str(pattern), str(inst), phases=phases, fmthint="comma"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [900.0] + [0.0] * 9,
                "refine": True,
            },
        }
    )
    for phase in phases:
        # The synthetic protocol assigns one scalar Uiso to all atoms in a phase.
        for atom in phase.atoms():
            atom.uiso = 0.01
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][1] = 500.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]

    project.update_ids()
    set_bounds(project, phases, hist)

    project.save()
    run_refinement(project, "background_scales")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    run_refinement(project, "cells")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_refinement(project, "zero_shift")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "SH/L"]})
    run_refinement(project, "instrument_profile")

    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    run_refinement(project, "phase_size", cycles=10)

    hist.set_refinements({"Instrument Parameters": ["X"]})
    run_refinement(project, "phase_broadening", cycles=12)

    for phase in phases:
        phase.set_HAP_refinements({"Pref.Ori.": True})
    run_refinement(project, "preferred_orientation", cycles=10)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    run_refinement(project, "polarization", cycles=8)

    project.save()


if __name__ == "__main__":
    main()
