#!/usr/bin/env python3
"""Materialize the leading analogue-screen structures as Ca-W-O CIFs."""

from pathlib import Path
import json
import warnings

from pymatgen.core import Element, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parents[1]
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/"
    "resources/b001-c05/cif"
)


def path_for(cid: str) -> Path:
    return LIB / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


def main() -> None:
    rows = json.loads((ROOT / "analysis/analogue_screen_results.json").read_text())
    out = ROOT / "analysis/analogue_candidates"
    out.mkdir(exist_ok=True)
    manifest = []
    for row in rows[:50]:
        cid = row["id"]
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            st = Structure.from_file(path_for(cid), primitive=False)
        st.remove_oxidation_states()
        symbols = {e.symbol for e in st.composition.elements}
        other = sorted(symbols - {"O", "W", "Mo"})
        if len(other) != 1:
            continue
        repl = {Element(other[0]): Element("Ca")}
        if "Mo" in symbols:
            repl[Element("Mo")] = Element("W")
        st.replace_species(repl)
        mult = float(row["lattice_multiplier"])
        st.scale_lattice(st.volume * mult**3)
        dest = out / f"{cid}.cif"
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            CifWriter(st, symprec=1e-3, significant_figures=10).write_file(dest)
        manifest.append(
            {
                **{k: v for k, v in row.items() if k != "strong_lines_deg"},
                "candidate_cif": str(dest.relative_to(ROOT)),
                "scaled_cell": list(st.lattice.parameters),
                "mapped_composition": st.composition.formula,
            }
        )
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"wrote {len(manifest)} candidates to {out}")


if __name__ == "__main__":
    main()
