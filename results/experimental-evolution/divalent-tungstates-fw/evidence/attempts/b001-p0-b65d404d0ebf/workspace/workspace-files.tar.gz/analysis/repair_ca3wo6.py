#!/usr/bin/env python3
"""Merge the two split, half-occupied Ca pairs in the Ba3WO6 analogue."""

from pathlib import Path
import warnings

import numpy as np
from pymatgen.core import Element, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parents[1]


def periodic_average(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    delta = b - a
    delta -= np.round(delta)
    return (a + 0.5 * delta) % 1.0


def main() -> None:
    source = ROOT / "analysis/candidate_1534803_polished.cif"
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        st = Structure.from_file(source, primitive=False)
    partial = [
        i
        for i, site in enumerate(st)
        if site.is_ordered is False
        or abs(float(site.species.num_atoms) - 1.0) > 1e-8
    ]
    used = set()
    merged = []
    for i in partial:
        if i in used:
            continue
        choices = [j for j in partial if j != i and j not in used]
        if not choices:
            raise ValueError(f"unpaired partial site {i}")
        j = min(choices, key=lambda k: st.get_distance(i, k))
        if st.get_distance(i, j) > 1.0:
            raise ValueError(f"partial sites {i},{j} are too far apart")
        used.update({i, j})
        merged.append(periodic_average(st[i].frac_coords, st[j].frac_coords))

    species = []
    coords = []
    for i, site in enumerate(st):
        if i in used:
            continue
        species.append(site.species)
        coords.append(site.frac_coords)
    for fc in merged:
        species.append(Element("Ca"))
        coords.append(fc)
    repaired = Structure(st.lattice, species, coords, coords_are_cartesian=False)
    out = ROOT / "analysis/Ca3WO6_repaired.cif"
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        CifWriter(repaired, symprec=None, significant_figures=10).write_file(out)
    dist = repaired.distance_matrix.copy()
    np.fill_diagonal(dist, np.inf)
    print(
        f"wrote {out}: {st.composition} ({len(st)} sites) -> "
        f"{repaired.composition} ({len(repaired)} sites), min distance {dist.min():.4f} A"
    )


if __name__ == "__main__":
    main()
