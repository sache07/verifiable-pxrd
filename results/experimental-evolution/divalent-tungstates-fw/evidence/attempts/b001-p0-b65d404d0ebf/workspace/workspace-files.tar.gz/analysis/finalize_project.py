#!/usr/bin/env python3
"""Freeze the selected refinement and export its phase CIFs."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis/model_final_pol.gpx"
FINAL = ROOT / "final.gpx"
EXPORTS = {
    "CaWO4": ROOT / "phases/CaWO4.cif",
    "WO3": ROOT / "phases/WO3.cif",
    "CaO": ROOT / "phases/CaO.cif",
    "candidate_ca3wo6_repaired": ROOT / "phases/Ca3WO6.cif",
}


def main() -> None:
    EXPORTS["CaWO4"].parent.mkdir(exist_ok=True)
    p = G2.G2Project(gpxfile=str(SOURCE))
    h = p.histogram(0)
    # The final file is a frozen forward model. No refinement is requested by
    # the evaluator, but clearing flags makes that intent explicit.
    h.data["Background"][0][1] = False
    for item in h.InstrumentParameters.values():
        if isinstance(item, list) and len(item) >= 3:
            item[2] = False
    for item in h.SampleParameters.values():
        if isinstance(item, list) and len(item) >= 2 and isinstance(item[1], bool):
            item[1] = False
    for ph in p.phases():
        ph.data["General"]["Cell"][0] = False
        hap = ph.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        for atom in ph.atoms():
            atom.refinement_flags = " "
    p.save(str(FINAL))

    # Reload exactly what was serialized before exporting, ensuring the CIFs
    # and project share the same full-precision cell, sites, occupancy and ADP.
    p = G2.G2Project(gpxfile=str(FINAL))
    h = p.histogram(0)
    amounts = {}
    report = []
    for ph in p.phases():
        path = EXPORTS[ph.name]
        ph.export_CIF(str(path))
        scale = float(ph.data["Histograms"][h.name]["Scale"][0])
        mass = float(ph.data["General"]["Mass"])
        amounts[ph.name] = scale * mass
        report.append(
            {
                "project_name": ph.name,
                "cif": str(path.relative_to(ROOT)),
                "scale": scale,
                "cell_mass": mass,
                "cell": ph.data["General"]["Cell"][1:8],
            }
        )
    total = sum(amounts.values())
    for row in report:
        row["weight_fraction"] = amounts[row["project_name"]] / total
    print(json.dumps({"histogram": h.name, "phases": report}, indent=2))


if __name__ == "__main__":
    main()
