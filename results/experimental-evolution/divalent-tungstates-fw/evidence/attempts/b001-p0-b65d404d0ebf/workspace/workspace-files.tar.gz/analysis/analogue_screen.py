#!/usr/bin/env python3
"""Screen ternary W/Mo oxide structure types as possible Ca-W-O intermediates.

Each source structure is stripped of oxidation states, Mo is changed to W and
the remaining cation is changed to Ca.  A coarse isotropic lattice multiplier
is optimized against the positive residual of the current three-phase model.
This is a fingerprint screen only; promising structures must subsequently be
tested and refined in GSAS-II.
"""

from __future__ import annotations

import gzip
import json
import math
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Element, Structure
from scipy.ndimage import gaussian_filter1d


ROOT = Path(__file__).resolve().parents[1]
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-fw/"
    "resources/b001-c05"
)


def cif_path(cid: str) -> Path:
    return LIB / "cif" / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


def mapped_structure(path: Path) -> tuple[Structure, str] | None:
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            st = Structure.from_file(path, primitive=False)
        st.remove_oxidation_states()
        elements = {el.symbol for el in st.composition.elements}
        heavy = "W" if "W" in elements else "Mo" if "Mo" in elements else None
        other = sorted(elements - {"O", "W", "Mo"})
        if heavy is None or len(other) != 1:
            return None
        repl = {Element(other[0]): Element("Ca")}
        if heavy == "Mo":
            repl[Element("Mo")] = Element("W")
        st.replace_species(repl)
        return st, other[0]
    except Exception:
        return None


def pattern_lines(st: Structure) -> tuple[np.ndarray, np.ndarray]:
    calc = XRDCalculator(wavelength=1.540598, symprec=0)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        pat = calc.get_pattern(st, two_theta_range=(7.0, 130.0), scaled=False)
    return np.asarray(pat.x), np.asarray(pat.y)


def move_lines(pos: np.ndarray, multiplier: float, wavelength: float) -> np.ndarray:
    # Isotropically scaling the lattice scales all d spacings by multiplier.
    theta = np.radians(pos / 2.0)
    arg = np.sin(theta) / multiplier
    out = np.full_like(pos, np.nan)
    ok = np.abs(arg) < 1.0
    out[ok] = np.degrees(2.0 * np.arcsin(arg[ok]))
    return out


def profile_from_lines(
    x: np.ndarray, pos: np.ndarray, inten: np.ndarray, sigma_points: float
) -> np.ndarray:
    q = np.zeros_like(x)
    dx = float(np.median(np.diff(x)))
    ii = np.rint((pos - x[0]) / dx).astype(int)
    ok = np.isfinite(pos) & (ii >= 0) & (ii < len(x))
    np.add.at(q, ii[ok], inten[ok])
    return gaussian_filter1d(q, sigma_points, mode="constant")


def candidate_rows() -> list[dict]:
    with gzip.open(LIB / "index.json.gz", "rt") as fh:
        idx = json.load(fh)
    rows = []
    seen = set()
    for key, vals in idx.items():
        els = set(key.split("-"))
        if "O" not in els or not ({"W", "Mo"} & els) or len(els) != 3:
            continue
        for formula, cid, sg, r_factor in vals:
            if cid in seen:
                continue
            seen.add(cid)
            try:
                comp = Composition(formula)
                amounts = comp.get_el_amt_dict()
                b = "W" if amounts.get("W", 0) else "Mo"
                other = [e for e in amounts if e not in {"O", "W", "Mo"}]
                if len(other) != 1 or amounts.get("O", 0) == 0:
                    continue
                b_amt = amounts[b]
                ca_b = amounts[other[0]] / b_amt
                o_b = amounts["O"] / b_amt
                # Includes Ca-rich tungstates through polytungstates while
                # dropping obvious oxygen-poor metallic structure types.
                if not (0.20 <= ca_b <= 4.2 and 2.5 <= o_b <= 8.2):
                    continue
                rows.append(
                    {
                        "id": cid,
                        "formula": formula,
                        "space_group_number": sg,
                        "r_factor": r_factor,
                        "source_cation": other[0],
                        "source_b": b,
                        "ca_per_w": ca_b,
                        "o_per_w": o_b,
                    }
                )
            except Exception:
                continue
    return rows


def main() -> None:
    prof = np.load(ROOT / "analysis/model_md_all_profile.npz")
    x = prof["two_theta"]
    obs = prof["observed"]
    residual = obs - prof["calculated"]
    weights = 1.0 / np.maximum(obs, 1.0)
    use = (x >= 10.0) & (x <= 100.0)

    # Mask regions where the residual is visibly dominated by imperfect
    # profiles of the three already assigned phases. The remaining strongest
    # lines form a coherent minor-phase fingerprint.
    known_windows = [
        (18.25, 19.02),
        (22.72, 24.62),
        (28.22, 29.18),
        (31.08, 31.72),
        (31.96, 32.34),
        (33.76, 34.31),
        (37.18, 37.72),
        (38.78, 39.34),
        (46.65, 47.29),
        (48.66, 49.30),
        (57.43, 58.16),
        (59.03, 59.70),
        (75.78, 76.55),
    ]
    for lo, hi in known_windows:
        use &= ~((x >= lo) & (x <= hi))
    wr = weights * residual * use

    # Correlating sticks with a smoothed weighted residual is a fast coarse
    # proxy for a full profile fit. Negative residuals penalize absent lines.
    smooth = gaussian_filter1d(wr, 7.0, mode="constant")
    smooth2 = gaussian_filter1d(weights * use, 7.0, mode="constant")
    multipliers = np.linspace(0.72, 1.30, 117)
    rows = candidate_rows()
    coarse = []
    for n, row in enumerate(rows, 1):
        mapped = mapped_structure(cif_path(row["id"]))
        if mapped is None:
            continue
        st, actual_other = mapped
        if len(st) > 300:
            continue
        try:
            pos, inten = pattern_lines(st)
        except Exception:
            continue
        if len(pos) == 0 or not np.isfinite(inten).all():
            continue
        # Keep all meaningful lines; normalize to avoid cell-size bias.
        keep = inten >= max(float(inten.max()) * 2e-4, 1e-12)
        pos, inten = pos[keep], inten[keep]
        inten = inten / np.linalg.norm(inten)
        best = (-math.inf, None)
        for mult in multipliers:
            pp = move_lines(pos, float(mult), 1.540598)
            ok = np.isfinite(pp) & (pp >= 10.0) & (pp <= 100.0)
            if not np.any(ok):
                continue
            rr = np.interp(pp[ok], x, smooth)
            ww = np.interp(pp[ok], x, smooth2)
            score = float(np.dot(inten[ok], rr) / math.sqrt(np.dot(inten[ok] ** 2, ww) + 1e-30))
            if score > best[0]:
                best = (score, float(mult))
        out = dict(row)
        out.update(
            {
                "coarse_score": best[0],
                "lattice_multiplier": best[1],
                "n_sites": len(st),
                "mapped_formula": st.composition.reduced_formula,
                "actual_source_cation": actual_other,
            }
        )
        coarse.append((out, pos, inten))
        if n % 100 == 0:
            print(f"screened {n}/{len(rows)}", flush=True)

    coarse.sort(key=lambda item: item[0]["coarse_score"], reverse=True)

    # Full weighted profile regression for the best coarse candidates. Include
    # the K-alpha2 component and optimize lattice multiplier and line width.
    refined = []
    dx = float(np.median(np.diff(x)))
    for row, pos, inten in coarse[:100]:
        m0 = row["lattice_multiplier"]
        best = (-math.inf, None, None, None, None)
        for mult in np.linspace(max(0.68, m0 - 0.018), min(1.34, m0 + 0.018), 37):
            p1 = move_lines(pos, float(mult), 1.540598)
            # Convert K-alpha1 d spacings to K-alpha2 positions.
            theta1 = np.radians(p1 / 2.0)
            arg2 = np.sin(theta1) * (1.544426 / 1.540598)
            p2 = np.where(np.abs(arg2) < 1, np.degrees(2 * np.arcsin(arg2)), np.nan)
            pp = np.concatenate([p1, p2])
            jj = np.concatenate([inten, 0.5 * inten])
            for sigma_deg in (0.055, 0.085, 0.125, 0.18, 0.26):
                q = profile_from_lines(x, pp, jj, sigma_deg / dx)
                q *= use
                den = float(np.dot(weights, q * q))
                num = float(np.dot(weights * residual, q))
                amp = max(0.0, num / max(den, 1e-30))
                improve = amp * amp * den
                if improve > best[0]:
                    best = (improve, float(mult), sigma_deg, amp, q)
        out = dict(row)
        out.update(
            {
                "delta_chi2_masked": best[0],
                "lattice_multiplier": best[1],
                "sigma_deg": best[2],
                "profile_amplitude": best[3],
            }
        )
        # Report the strongest transformed K-alpha1 positions for inspection.
        pp = move_lines(pos, best[1], 1.540598)
        order = np.argsort(inten)[::-1]
        out["strong_lines_deg"] = [
            [round(float(pp[i]), 4), round(float(inten[i] / inten.max()), 4)]
            for i in order
            if np.isfinite(pp[i]) and 10 <= pp[i] <= 100
        ][:20]
        refined.append(out)

    refined.sort(key=lambda row: row["delta_chi2_masked"], reverse=True)
    out_path = ROOT / "analysis/analogue_screen_results.json"
    out_path.write_text(json.dumps(refined, indent=2) + "\n")
    print(f"wrote {out_path}")
    for row in refined[:30]:
        print(
            row["id"], row["formula"], "=>", row["mapped_formula"],
            "SG", row["space_group_number"],
            "mult", f"{row['lattice_multiplier']:.4f}",
            "dchi", f"{row['delta_chi2_masked']:.1f}",
            "lines", row["strong_lines_deg"][:8],
        )


if __name__ == "__main__":
    main()
