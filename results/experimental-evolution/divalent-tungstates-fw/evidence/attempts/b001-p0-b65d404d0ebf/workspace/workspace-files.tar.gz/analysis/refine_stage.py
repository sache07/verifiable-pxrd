#!/usr/bin/env python3
"""Run one controlled GSAS-II refinement stage on an existing project."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(h):
    x, y, w, yc = (np.asarray(v, float) for v in h.data["data"][1][:4])
    use = (x >= 10) & (x <= 100)
    return 100 * math.sqrt(np.sum(w[use] * (y[use] - yc[use]) ** 2) / np.sum(w[use] * y[use] ** 2))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--instrument", default="", help="comma-separated instrument parameters")
    ap.add_argument("--sample", default="", help="comma-separated sample parameters")
    ap.add_argument("--cells", default="", help="comma-separated phase names")
    ap.add_argument("--sizes", default="", help="comma-separated phase names")
    ap.add_argument("--strains", default="", help="comma-separated phase names")
    ap.add_argument("--cycles", type=int, default=8)
    a = ap.parse_args()
    shutil.copy2(a.source, a.output)
    G2.SetPrintLevel("warn")
    p = G2.G2Project(gpxfile=str(a.output))
    h = p.histogram(0)
    h.data["Background"][0][1] = True
    for item in h.InstrumentParameters.values():
        if isinstance(item, list) and len(item) >= 3:
            item[2] = False
    for item in h.SampleParameters.values():
        if isinstance(item, list) and len(item) >= 2 and isinstance(item[1], bool):
            item[1] = False
    for ph in p.phases():
        ph.data["General"]["Cell"][0] = False
        hap = ph.data["Histograms"][h.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        for atom in ph.atoms():
            atom.refinement_flags = " "
    inst_names = [x for x in a.instrument.split(",") if x]
    sample_names = [x for x in a.sample.split(",") if x]
    for name in inst_names:
        h.InstrumentParameters[name][2] = True
    for name in sample_names:
        h.SampleParameters[name][1] = True
    for name in [x for x in a.cells.split(",") if x]:
        p.phase(name).data["General"]["Cell"][0] = True
    for name in [x for x in a.sizes.split(",") if x]:
        p.phase(name).data["Histograms"][h.name]["Size"][2][0] = True
    for name in [x for x in a.strains.split(",") if x]:
        p.phase(name).data["Histograms"][h.name]["Mustrain"][2][0] = True
    p.update_ids()
    bounds = {
        ":0:Zero": (-0.25, 0.25), ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0), ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0), ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.5, 1.0), ":0:SurfRoughA": (0.0, 0.6),
        ":0:SurfRoughB": (0.0, 0.5),
    }
    for var, (lo, hi) in bounds.items():
        p.set_Controls("parmMin", lo, variable=var)
        p.set_Controls("parmMax", hi, variable=var)
    for ph in p.phases():
        pfx = f"{ph.id}:{h.id}:"
        p.set_Controls("parmMin", 0.04, variable=pfx + "Size;i")
        p.set_Controls("parmMax", 1.5, variable=pfx + "Size;i")
        p.set_Controls("parmMin", 0.0, variable=pfx + "Mustrain;i")
        p.set_Controls("parmMax", 8000.0, variable=pfx + "Mustrain;i")
    p.set_Controls("cycles", a.cycles)
    start = rwp(h)
    p.save()
    p.refine()
    # Freeze the stage before saving the handoff project.
    for name in inst_names:
        h.InstrumentParameters[name][2] = False
    for name in sample_names:
        h.SampleParameters[name][1] = False
    for ph in p.phases():
        ph.data["General"]["Cell"][0] = False
        ph.data["Histograms"][h.name]["Size"][2] = [False, False, False]
        ph.data["Histograms"][h.name]["Mustrain"][2] = [False, False, False]
    p.save()
    print(json.dumps({
        "start": start,
        "end": rwp(h),
        "instrument": {k: h.InstrumentParameters[k][1] for k in inst_names},
        "sample": {k: h.SampleParameters[k][0] for k in sample_names},
        "phases": {
            ph.name: {
                "cell": ph.data["General"]["Cell"][1:8],
                "size": ph.data["Histograms"][h.name]["Size"][1][0],
                "strain": ph.data["Histograms"][h.name]["Mustrain"][1][0],
            }
            for ph in p.phases()
        },
    }, indent=2))


if __name__ == "__main__":
    main()
