#!/usr/bin/env python3
"""Test a tightly scoped coordinate refinement and report its displacement."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def rwp(hist) -> float:
    x, y, w, yc = (np.asarray(a, float) for a in hist.data["data"][1][:4])
    use = (x >= 10) & (x <= 100)
    return 100 * math.sqrt(np.sum(w[use] * (y[use] - yc[use]) ** 2) / np.sum(w[use] * y[use] ** 2))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("phase")
    ap.add_argument("elements", help="comma-separated symbols, or all")
    ap.add_argument("--cycles", type=int, default=6)
    args = ap.parse_args()
    shutil.copy2(args.source, args.output)
    G2.SetPrintLevel("warn")
    p = G2.G2Project(gpxfile=str(args.output))
    h = p.histogram(0)
    # Background and all phase scales remain active; clear everything else.
    h.data["Background"][0][1] = True
    for item in h.InstrumentParameters.values():
        if isinstance(item, list) and len(item) >= 3:
            item[2] = False
    for item in h.SampleParameters.values():
        if isinstance(item, list) and len(item) >= 2 and isinstance(item[1], bool):
            item[1] = False
    for phase in p.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
    target = p.phase(args.phase)
    selected = None if args.elements == "all" else set(args.elements.split(","))
    before = {}
    for atom in target.atoms():
        if selected is None or atom.element in selected:
            before[atom.label] = np.asarray(atom.coordinates, float)
            atom.refinement_flags = "X"
    p.set_Controls("cycles", args.cycles)
    p.save()
    start_rwp = rwp(h)
    p.refine()
    end_rwp = rwp(h)
    cell = target.data["General"]["Cell"][1:7]
    moves = []
    for atom in target.atoms():
        if atom.label not in before:
            continue
        delta = np.asarray(atom.coordinates) - before[atom.label]
        delta -= np.round(delta)
        # GSAS A matrix maps reciprocal conventions; direct Cartesian metric
        # is obtained robustly from the cell metric tensor here.
        metric = G2lat.cell2Gmat(cell)[1]
        distance = float(np.sqrt(delta @ metric @ delta))
        moves.append({
            "label": atom.label,
            "element": atom.element,
            "before": before[atom.label].tolist(),
            "after": list(atom.coordinates),
            "move_A": distance,
        })
        atom.refinement_flags = " "
    p.save()
    print(json.dumps({
        "start_rwp": start_rwp,
        "end_rwp": end_rwp,
        "rms_move_A": float(np.sqrt(np.mean([m["move_A"] ** 2 for m in moves]))),
        "max_move_A": max(m["move_A"] for m in moves),
        "moves": moves,
    }, indent=2))


if __name__ == "__main__":
    main()
