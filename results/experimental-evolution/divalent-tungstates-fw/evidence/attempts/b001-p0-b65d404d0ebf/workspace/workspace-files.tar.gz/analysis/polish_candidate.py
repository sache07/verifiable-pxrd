#!/usr/bin/env python3
"""Apply chosen texture settings and polish a four-phase candidate project."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist) -> float:
    x, y, w, yc = (np.asarray(a, float) for a in hist.data["data"][1][:4])
    use = (x >= 10) & (x <= 100)
    return 100 * math.sqrt(np.sum(w[use] * (y[use] - yc[use]) ** 2) / np.sum(w[use] * y[use] ** 2))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("textures", help="JSON: phase -> [ratio,[h,k,l]]")
    ap.add_argument("--candidate", required=True)
    ap.add_argument("--cycles", type=int, default=8)
    args = ap.parse_args()
    shutil.copy2(args.source, args.output)
    G2.SetPrintLevel("warn")
    p = G2.G2Project(gpxfile=str(args.output))
    h = p.histogram(0)
    textures = json.loads(args.textures)
    # Clear every old flag, retaining background and scales.
    h.data["Background"][0][1] = True
    for item in h.InstrumentParameters.values():
        if isinstance(item, list) and len(item) >= 3:
            item[2] = False
    for item in h.SampleParameters.values():
        if isinstance(item, list) and len(item) >= 2 and isinstance(item[1], bool):
            item[1] = False
    for ph in p.phases():
        ph.data["General"]["Cell"][0] = False
        hap = ph.data["Histograms"][h.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        if ph.name in textures:
            ratio, axis = textures[ph.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = float(ratio)
            hap["Pref.Ori."][3] = list(axis)
    p.update_ids()
    p.set_Controls("cycles", args.cycles)
    cand = p.phase(args.candidate)
    ch = cand.data["Histograms"][h.name]
    p.set_Controls("parmMin", 0.7, variable=f"{cand.id}:{h.id}:MD")
    p.set_Controls("parmMax", 1.4, variable=f"{cand.id}:{h.id}:MD")
    p.set_Controls("parmMin", 0.04, variable=f"{cand.id}:{h.id}:Size;i")
    p.set_Controls("parmMax", 1.5, variable=f"{cand.id}:{h.id}:Size;i")
    p.save()

    stages = {}
    p.refine()
    stages["texture_fixed"] = rwp(h)

    cand.data["General"]["Cell"][0] = True
    p.refine()
    cand.data["General"]["Cell"][0] = False
    stages["cell"] = rwp(h)

    ch["Size"][2][0] = True
    p.refine()
    ch["Size"][2][0] = False
    stages["size"] = rwp(h)

    # Refine the candidate's MD magnitude last, with its selected axis fixed.
    ch["Pref.Ori."][2] = True
    p.refine()
    ch["Pref.Ori."][2] = False
    stages["md"] = rwp(h)
    p.save()
    vals = {}
    for ph in p.phases():
        hap = ph.data["Histograms"][h.name]
        vals[ph.name] = max(0.0, hap["Scale"][0]) * ph.data["General"]["Mass"]
    total = sum(vals.values())
    print(json.dumps({
        "stages": stages,
        "fractions": {k: v / total for k, v in vals.items()},
        "candidate_cell": cand.data["General"]["Cell"][1:8],
        "candidate_size": ch["Size"][1][0],
        "candidate_texture": ch["Pref.Ori."][:4],
    }, indent=2))


if __name__ == "__main__":
    main()
