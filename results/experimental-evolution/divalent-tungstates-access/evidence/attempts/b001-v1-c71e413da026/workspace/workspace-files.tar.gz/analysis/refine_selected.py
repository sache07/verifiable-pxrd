"""Staged refinement of the selected scheelite + monoclinic-WO3 model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2

from gsas_branch import snapshot


def save_state(project, histogram, output: Path, label: str, records: list[dict]) -> None:
    project.save(str(output.with_name(f"{output.stem}-{label}.gpx")))
    records.append(snapshot(project, histogram, label))


def refine(project, repeats: int = 2) -> None:
    for _ in range(repeats):
        project.refine(makeBack=False)


def atom_shifts(phase, reference: dict[str, np.ndarray]) -> dict[str, float]:
    shifts = {}
    from GSASII import GSASIIlattice as G2lat
    cell = phase.get_cell()
    amat, _ = G2lat.cell2AB([
        cell["length_a"], cell["length_b"], cell["length_c"],
        cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
    ])
    lattice = np.asarray(amat).T
    for atom in phase.atoms():
        delta = np.asarray(atom.coordinates) - reference[atom.label]
        delta -= np.rint(delta)
        shifts[atom.label] = float(np.linalg.norm(delta @ lattice))
    return shifts


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cycles", type=int, default=15)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.input, args.output)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.output))
    project.set_Controls("cycles", args.cycles)
    histogram = project.histograms()[0]
    phases = {phase.name: phase for phase in project.phases()}
    scheelite = phases["CaWO4_scheelite"]
    wo3 = phases["WO3_2311041sb"]
    records: list[dict] = []

    reference_coords = {
        phase.name: {atom.label: np.asarray(atom.coordinates, float) for atom in phase.atoms()}
        for phase in project.phases()
    }

    # The trial screen demonstrated an almost exact Zero/Shift correlation and
    # drove Zero to the artificial -0.30 screen bound. Fix it inside the stated
    # laboratory interval and let specimen shift/cells carry the equivalent fit.
    histogram.data["Instrument Parameters"][0]["Zero"][1] = -0.25
    histogram.data["Instrument Parameters"][0]["Zero"][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {}
    refine(project, 3)
    save_state(project, histogram, args.output, "physical_calibration", records)

    # Limited coordinate stage: the sole scheelite oxygen site and the two
    # strongly scattering independent W sites in the 15 wt% WO3 phase.
    scheelite.atom("O1").refinement_flags = "X"
    refine(project, 2)
    save_state(project, histogram, args.output, "scheelite_O", records)

    wo3.atom("W1").refinement_flags = "X"
    wo3.atom("W2").refinement_flags = "X"
    refine(project, 3)
    save_state(project, histogram, args.output, "wo3_W", records)

    # Refine one common isotropic displacement value per phase, matching the
    # synthetic-lab model while avoiding atom-by-atom ADP overparameterization.
    project.index_ids()
    for phase in (scheelite, wo3):
        p_id = phase.data["pId"]
        variables = []
        for index, atom in enumerate(phase.atoms()):
            atom.uiso = 0.01
            atom.refinement_flags = "".join(sorted(set(atom.refinement_flags + "U")))
            variable = f"{p_id}::AUiso:{index}"
            variables.append(variable)
            project.set_Controls("parmMin", 0.001, variable)
            project.set_Controls("parmMax", 0.05, variable)
        project.add_EquivConstr(tuple(variables), override=True)
    refine(project, 3)
    save_state(project, histogram, args.output, "common_uiso", records)

    # Polarization is uncalibrated in metadata and is a single supported
    # instrument nuisance parameter, not a phase-specific intensity correction.
    h_id = histogram.data["data"][0]["hId"]
    histogram.data["Instrument Parameters"][0]["Polariz."][2] = True
    project.set_Controls("parmMin", 0.5, f":{h_id}:Polariz.")
    project.set_Controls("parmMax", 1.0, f":{h_id}:Polariz.")
    refine(project, 3)
    save_state(project, histogram, args.output, "polarization", records)

    project.save(str(args.output))
    result = {
        "input": str(args.input),
        "output": str(args.output),
        "stages": records,
        "coordinate_shifts_A": {
            phase.name: atom_shifts(phase, reference_coords[phase.name])
            for phase in project.phases()
        },
        "final": snapshot(project, histogram, "selected_simple"),
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
