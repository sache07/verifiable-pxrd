"""Test one common isotropic displacement parameter for a named phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2

from gsas_branch import snapshot


parser = argparse.ArgumentParser()
parser.add_argument("--input", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--phase", required=True)
parser.add_argument("--cycles", type=int, default=15)
args = parser.parse_args()
args.output.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(args.input, args.output)

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.output))
project.set_Controls("cycles", args.cycles)
project.data["Controls"]["data"]["parmFrozen"] = {}
histogram = project.histograms()[0]
phase = project.phase(args.phase)
project.index_ids()
p_id = phase.data["pId"]

# Keep polarization fixed while the common phase ADP is established, since
# both primarily alter the high-angle intensity envelope.
instrument = histogram.data["Instrument Parameters"][0]
polarization_was_refined = bool(instrument["Polariz."][2])
instrument["Polariz."][2] = False
variables = []
for index, atom in enumerate(phase.atoms()):
    atom.refinement_flags = "".join(sorted(set(atom.refinement_flags + "U")))
    variable = f"{p_id}::AUiso:{index}"
    variables.append(variable)
    project.set_Controls("parmMin", 0.003, variable)
    project.set_Controls("parmMax", 0.02, variable)
project.add_EquivConstr(tuple(variables), override=True)
for _ in range(4):
    project.refine(makeBack=False)
refined_uiso = {atom.label: atom.uiso for atom in phase.atoms()}

for atom in phase.atoms():
    atom.refinement_flags = atom.refinement_flags.replace("U", "")
instrument["Polariz."][2] = polarization_was_refined
# Equality constraints on fixed variables are unnecessary in a submitted GPX.
project.data["Constraints"]["data"]["Phase"] = []
for _ in range(3):
    project.refine(makeBack=False)
project.data["Controls"]["data"]["parmFrozen"] = {}
project.save(str(args.output))
state = snapshot(project, histogram, "common_uiso")
result = {"phase": args.phase, "uiso_A2": refined_uiso, "state": state}
args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(json.dumps({"phase": args.phase, "uiso_A2": refined_uiso,
                  "rwp_percent": state["rwp_percent"]}, indent=2))
