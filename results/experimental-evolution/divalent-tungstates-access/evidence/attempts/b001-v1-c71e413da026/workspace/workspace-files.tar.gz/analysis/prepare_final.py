"""Freeze the selected GSAS-II model and export project-consistent phase CIFs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


FILENAMES = {
    "CaWO4_scheelite": "phase_CaWO4_scheelite.cif",
    "WO3_2311041sb": "phase_WO3_monoclinic.cif",
    "CaCO3 calcite": "phase_CaCO3_calcite.cif",
}


parser = argparse.ArgumentParser()
parser.add_argument("--input", type=Path, required=True)
parser.add_argument("--workspace", type=Path, required=True)
args = parser.parse_args()
workspace = args.workspace.resolve()
destination = workspace / "final.gpx"
shutil.copy2(args.input.resolve(), destination)

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(destination))
histogram = project.histograms()[0]
covariance = project.data.get("Covariance", {}).get("data", {})
vary_count = len(covariance.get("varyList", []))

# Coordinate trials leave covariance entries from the preceding least-squares
# step. Clearing them ensures CIF export uses the saved, regularized atoms.
project.data["Covariance"]["data"] = {}
project.data["Constraints"]["data"]["Phase"] = []
project.data["Controls"]["data"]["parmFrozen"] = {}
project.save(str(destination))

mass_scales = []
exports = []
for phase in project.phases():
    filename = FILENAMES[phase.name]
    path = workspace / filename
    phase.export_CIF(str(path))
    hap = phase.data["Histograms"][histogram.name]
    mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
    mass_scales.append(mass_scale)
    exports.append({
        "name": phase.name,
        "cif_path": filename,
        "scale": float(hap["Scale"][0]),
        "cell_mass": float(phase.data["General"]["Mass"]),
    })
total = sum(mass_scales)
for row, mass_scale in zip(exports, mass_scales):
    row["weight_fraction"] = mass_scale / total

manifest = {
    "project": str(destination),
    "histogram": histogram.name,
    "vary_count_before_covariance_clear": vary_count,
    "phases": exports,
}
(workspace / "analysis" / "final_manifest.json").write_text(
    json.dumps(manifest, indent=2, allow_nan=False) + "\n"
)
print(json.dumps(manifest, indent=2, allow_nan=False))
