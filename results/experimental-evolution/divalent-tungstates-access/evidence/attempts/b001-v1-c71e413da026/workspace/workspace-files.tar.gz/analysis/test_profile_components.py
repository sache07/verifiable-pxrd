"""Compare isotropic size/strain components for one phase from a common GPX."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2

from gsas_branch import snapshot


parser = argparse.ArgumentParser()
parser.add_argument("--input", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--phase", required=True)
parser.add_argument("--mode", choices=["both", "both-capped", "size-only", "strain-only"], required=True)
parser.add_argument("--cycles", type=int, default=15)
args = parser.parse_args()
args.output.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(args.input, args.output)

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.output))
project.set_Controls("cycles", args.cycles)
project.data["Controls"]["data"]["parmFrozen"] = {}
histogram = project.histograms()[0]
phase = project.phase(args.phase)
hap = phase.data["Histograms"][histogram.name]
project.index_ids()
p_id = phase.data["pId"]
h_id = histogram.data["data"][0]["hId"]

hap["Size"][0] = "isotropic"
hap["Mustrain"][0] = "isotropic"
hap["Size"][2][0] = args.mode != "strain-only"
hap["Mustrain"][2][0] = args.mode not in {"size-only"}
if args.mode == "size-only":
    hap["Mustrain"][1][0] = 0.0
if args.mode == "strain-only":
    hap["Size"][1][0] = 10.0
if args.mode == "both-capped":
    hap["Mustrain"][1][0] = min(float(hap["Mustrain"][1][0]), 8000.0)

project.set_Controls("parmMin", 0.04, f"{p_id}:{h_id}:Size;i")
project.set_Controls("parmMax", 1.50 if args.mode != "strain-only" else 10.0, f"{p_id}:{h_id}:Size;i")
project.set_Controls("parmMin", 0.0, f"{p_id}:{h_id}:Mustrain;i")
project.set_Controls("parmMax", 8000.0 if args.mode == "both-capped" else 20000.0,
                     f"{p_id}:{h_id}:Mustrain;i")

for _ in range(4):
    project.refine(makeBack=False)
project.data["Controls"]["data"]["parmFrozen"] = {}
project.save(str(args.output))
state = snapshot(project, histogram, args.mode)
result = {"phase": args.phase, "mode": args.mode, "state": state}
args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(json.dumps({"phase": args.phase, "mode": args.mode,
                  "rwp_percent": state["rwp_percent"], "profile": state["hap"][args.phase]}, indent=2))
