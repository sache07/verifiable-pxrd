"""Apply the laboratory mismatch bounds and finish the simple selected model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

from gsas_branch import snapshot


SOURCE = {
    "CaWO4_scheelite": {"O1": np.array([0.15202, 0.01135, 0.20864])},
    "WO3_2311041sb": {
        "W1": np.array([0.254, 0.037, 0.282]),
        "W2": np.array([0.250, 0.023, 0.784]),
    },
}


def orthogonalization(phase):
    cell = phase.get_cell()
    matrix, _ = G2lat.cell2AB([cell[k] for k in [
        "length_a", "length_b", "length_c", "angle_alpha", "angle_beta", "angle_gamma"
    ]])
    return matrix


def cap_group(phase, labels: list[str], cap_rms_A: float) -> dict:
    matrix = orthogonalization(phase)
    deltas = []
    for label in labels:
        delta = np.asarray(phase.atom(label).coordinates) - SOURCE[phase.name][label]
        delta -= np.rint(delta)
        deltas.append(delta)
    distances = np.array([np.linalg.norm(matrix @ delta) for delta in deltas])
    rms = float(np.sqrt(np.mean(distances**2)))
    factor = min(1.0, cap_rms_A / max(rms, 1e-12))
    for label, delta in zip(labels, deltas):
        phase.atom(label).coordinates = tuple((SOURCE[phase.name][label] + factor * delta) % 1)
        phase.atom(label).refinement_flags = phase.atom(label).refinement_flags.replace("X", "")
    return {"before_rms_A": rms, "cap_rms_A": cap_rms_A, "scale_factor": factor,
            "after_distances_A": {label: float(distance * factor) for label, distance in zip(labels, distances)}}


parser = argparse.ArgumentParser()
parser.add_argument("--input", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--cycles", type=int, default=15)
args = parser.parse_args()
args.output.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(args.input, args.output)
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.output))
project.set_Controls("cycles", args.cycles)
project.data["Controls"]["data"]["parmFrozen"] = {}
histogram = project.histograms()[0]
ca = project.phase("CaWO4_scheelite")
wo3 = project.phase("WO3_2311041sb")

regularization = {
    "CaWO4_scheelite": cap_group(ca, ["O1"], 0.05),
    "WO3_2311041sb": cap_group(wo3, ["W1", "W2"], 0.04),
}

# Refine the common CaWO4 Uiso with polarization temporarily fixed to break
# their strong high-angle intensity correlation. WO3 remains at 0.005 A^2.
instrument = histogram.data["Instrument Parameters"][0]
instrument["Polariz."][2] = False
project.index_ids()
p_id = ca.data["pId"]
uiso_variables = []
for index, atom in enumerate(ca.atoms()):
    atom.uiso = 0.01
    atom.refinement_flags = "".join(sorted(set(atom.refinement_flags + "U")))
    variable = f"{p_id}::AUiso:{index}"
    uiso_variables.append(variable)
    project.set_Controls("parmMin", 0.003, variable)
    project.set_Controls("parmMax", 0.02, variable)
project.add_EquivConstr(tuple(uiso_variables), override=True)
for _ in range(3):
    project.refine(makeBack=False)

# Freeze that physically bounded value, then finish polarization and the
# already-supported scale/background/cell/isotropic-profile parameters.
for atom in ca.atoms():
    atom.refinement_flags = atom.refinement_flags.replace("U", "")
instrument["Polariz."][2] = True
h_id = histogram.data["data"][0]["hId"]
project.set_Controls("parmMin", 0.5, f":{h_id}:Polariz.")
project.set_Controls("parmMax", 1.0, f":{h_id}:Polariz.")
for _ in range(4):
    project.refine(makeBack=False)
project.data["Controls"]["data"]["parmFrozen"] = {}
project.save(str(args.output))
state = snapshot(project, histogram, "regularized_selected")
result = {"regularization": regularization, "state": state,
          "uiso_A2": {phase.name: {atom.label: atom.uiso for atom in phase.atoms()} for phase in project.phases()}}
args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(json.dumps({"rwp_percent": state["rwp_percent"], "fractions": {k: v["weight_fraction"] for k, v in state["hap"].items()},
                  "regularization": regularization, "uiso_A2": result["uiso_A2"]}, indent=2))
