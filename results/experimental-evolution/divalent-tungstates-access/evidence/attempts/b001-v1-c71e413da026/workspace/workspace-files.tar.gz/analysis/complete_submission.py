"""Write fit.csv and result.json from the verified read-only project replay."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


DISPLAY = {
    "CaWO4_scheelite": ("CaWO4 scheelite", "CaWO4", "I41/a", "phase_CaWO4_scheelite.cif"),
    "WO3_2311041sb": ("WO3 monoclinic", "WO3", "P21/n", "phase_WO3_monoclinic.cif"),
    "CaCO3 calcite": ("CaCO3 calcite", "CaCO3", "R-3c", "phase_CaCO3_calcite.cif"),
}


parser = argparse.ArgumentParser()
parser.add_argument("--workspace", type=Path, required=True)
args = parser.parse_args()
workspace = args.workspace.resolve()
replay_dir = workspace / "analysis" / "replay"
replay = json.loads((replay_dir / "replay.json").read_text())
manifest = json.loads((workspace / "analysis" / "final_manifest.json").read_text())
if replay.get("status") != "replayed" or replay.get("profile_review_flags"):
    raise RuntimeError(f"final project replay was not clean: {replay}")

with np.load(replay_dir / "prediction.npz", allow_pickle=False) as archive:
    x = archive["x"].copy()
    observed = archive["observed"].copy()
    calculated = archive["predicted"].copy()
difference = observed - calculated
weights = 1.0 / np.maximum(observed, 1.0)
chi_square = float(np.sum(weights * difference**2))
denominator = float(np.sum(weights * observed**2))
n_points = len(x)
n_parameters = int(manifest["vary_count_before_covariance_clear"])
degrees_of_freedom = n_points - n_parameters
rwp = float(100.0 * np.sqrt(chi_square / denominator))
rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
rexp = float(100.0 * np.sqrt(degrees_of_freedom / denominator))
reduced_chi_square = float(chi_square / degrees_of_freedom)
goodness_of_fit = float(np.sqrt(reduced_chi_square))

np.savetxt(
    workspace / "fit.csv",
    np.column_stack((x, observed, calculated, difference)),
    delimiter=",",
    header="two_theta,observed,calculated,difference",
    comments="",
    fmt=["%.8f", "%.10g", "%.10g", "%.10g"],
)

phases = []
for phase in replay["phases"]:
    display_name, formula, space_group, cif_path = DISPLAY[phase["name"]]
    phases.append({
        "name": display_name,
        "formula": formula,
        "space_group": space_group,
        "cif_path": cif_path,
        "weight_fraction": float(phase["weight_fraction"]),
        "weight_percent": float(100.0 * phase["weight_fraction"]),
    })

result = {
    "phases": phases,
    "fraction_basis": "normalized over the modeled crystalline phases",
    "refinement_histogram": replay["histogram"],
    "fit_csv": "fit.csv",
    "final_project": "final.gpx",
    "fit_statistics": {
        "rwp_percent": rwp,
        "rp_percent": rp,
        "rexp_percent": rexp,
        "goodness_of_fit": goodness_of_fit,
        "chi_square": chi_square,
        "reduced_chi_square": reduced_chi_square,
        "degrees_of_freedom": degrees_of_freedom,
        "number_of_points": n_points,
        "number_of_refined_parameters": n_parameters,
        "weighting": "1/max(observed_counts,1)",
    },
    "verification": {
        "status": replay["status"],
        "project_sha256": replay["project_sha256"],
        "project_unchanged_during_replay": replay["project_unchanged"],
        "parameters_optimized_during_replay": replay["parameters_optimized"],
        "profile_review_flags": replay["profile_review_flags"],
    },
}
(workspace / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(json.dumps(result, indent=2, allow_nan=False))
