import numpy as np
import matplotlib.pyplot as plt


data = np.loadtxt("analysis/optional2/clean-none.csv", delimiter=",", skiprows=1)
x, observed, calculated, background, difference = data.T
fig, axes = plt.subplots(2, 2, figsize=(13, 7), constrained_layout=True)
for ax, bounds in zip(axes.ravel(), [(17.5, 19.1), (27.6, 29.6), (32.4, 34.3), (56.8, 58.4)]):
    m = (x >= bounds[0]) & (x <= bounds[1])
    ax.plot(x[m], observed[m], color="black", lw=0.9, label="observed")
    ax.plot(x[m], calculated[m], color="tab:red", lw=0.9, label="calculated")
    ax.plot(x[m], difference[m] + background[m], color="tab:blue", lw=0.7, label="difference + background")
    ax.plot(x[m], background[m], color="gray", lw=0.6)
    ax.set_xlim(bounds)
axes[0, 0].legend(fontsize=8)
fig.savefig("analysis/local_residuals.png", dpi=180)
