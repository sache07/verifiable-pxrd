"""Test one optional nuisance term from a common selected-model checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2

from gsas_branch import snapshot


def axis(value: str) -> list[int]:
    values = [int(v) for v in value.split(",")]
    if len(values) != 3 or not any(values):
        raise argparse.ArgumentTypeError("axis must be h,k,l")
    return values


parser = argparse.ArgumentParser()
parser.add_argument("--input", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--term", choices=["none", "roughness", "po-ca", "po-wo3", "po-calcite",
                                                "strain-ca", "strain-wo3", "strain-calcite"], required=True)
parser.add_argument("--axis", type=axis, default=[0, 0, 1])
parser.add_argument("--cycles", type=int, default=15)
args = parser.parse_args()
args.output.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(args.input, args.output)

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.output))
project.set_Controls("cycles", args.cycles)
project.data["Controls"]["data"]["parmFrozen"] = {}
histogram = project.histograms()[0]
phases = {phase.name: phase for phase in project.phases()}
h_id = histogram.data["data"][0]["hId"]

# Common uncalibrated intensity nuisance for every branch.
histogram.data["Instrument Parameters"][0]["Polariz."][2] = True
project.set_Controls("parmMin", 0.5, f":{h_id}:Polariz.")
project.set_Controls("parmMax", 1.0, f":{h_id}:Polariz.")

if args.term == "roughness":
    sample = histogram.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.30, True]
    sample["SurfRoughB"] = [0.10, True]
    project.set_Controls("parmMin", 0.05, f":{h_id}:SurfRoughA")
    project.set_Controls("parmMax", 0.60, f":{h_id}:SurfRoughA")
    project.set_Controls("parmMin", 0.02, f":{h_id}:SurfRoughB")
    project.set_Controls("parmMax", 0.50, f":{h_id}:SurfRoughB")
elif args.term.startswith("po-"):
    phase_name = {"po-ca": "CaWO4_scheelite", "po-wo3": "WO3_2311041sb",
                  "po-calcite": "CaCO3 calcite"}[args.term]
    phase = phases[phase_name]
    hap = phase.data["Histograms"][histogram.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = args.axis
    project.index_ids()
    p_id = phase.data["pId"]
    project.set_Controls("parmMin", 0.70, f"{p_id}:{h_id}:MD")
    project.set_Controls("parmMax", 1.40, f"{p_id}:{h_id}:MD")
elif args.term.startswith("strain-"):
    phase_name = {"strain-ca": "CaWO4_scheelite", "strain-wo3": "WO3_2311041sb",
                  "strain-calcite": "CaCO3 calcite"}[args.term]
    phase = phases[phase_name]
    hap = phase.data["Histograms"][histogram.name]
    current = float(hap["Mustrain"][1][0])
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = current
    hap["Mustrain"][1][1] = current * 1.05
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    hap["Mustrain"][3] = args.axis
    project.index_ids()
    p_id = phase.data["pId"]
    for name in ("Mustrain;i", "Mustrain;a"):
        project.set_Controls("parmMin", 0.0, f"{p_id}:{h_id}:{name}")
        project.set_Controls("parmMax", 20000.0, f"{p_id}:{h_id}:{name}")

for _ in range(4):
    project.refine(makeBack=False)
project.save(str(args.output))
state = snapshot(project, histogram, args.term)
result = {"term": args.term, "axis": args.axis, "state": state}
args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(json.dumps({"term": args.term, "axis": args.axis, "rwp_percent": state["rwp_percent"],
                  "sample": state["sample"], "hap": state["hap"]}, indent=2))
