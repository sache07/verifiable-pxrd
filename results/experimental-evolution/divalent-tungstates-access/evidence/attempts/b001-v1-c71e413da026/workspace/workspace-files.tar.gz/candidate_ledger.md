# Candidate ledger

All comparisons used the same observed histogram and the same common background, calibration, scale, cell, and isotropic-profile strategy. A candidate that was not successfully imported and stably refined is marked **unknown**, not rejected. No branch remains pending.

## Phase inventory

| Composition / role | Candidate and source | Status | Common-project outcome |
|---|---|---:|---|
| CaWO4 | Scheelite, COD 7219229, I41/a | tested — selected | Accounts for the broad dominant family; refined cell `a=5.23729`, `c=11.33335` Å. |
| CaWO4 | Scheelite, COD 5910088, I41/a | unknown | Same-formula entry enumerated; the CIF did not import as a valid independent model. |
| CaWO4 | Fergusonite, COD 1546035, C2/c | rejected | Stable addition trial; scale collapsed to zero. |
| WO3 | Hexagonal, COD 1004057, P6/mmm | unknown | Calculated pattern inspected but not retained in a stable GSAS-II branch; its peak family is incompatible with the sharp residual family. |
| WO3 | Monoclinic, COD 1010618, P21/m | rejected | Stable common screen gave Rwp 24.126%, versus 3.840% for the selected shortlist member. |
| WO3 | Tetragonal, COD 1521532, P4/ncc | rejected | Rwp 10.419%; size and strain reached the screening bounds (0.01 µm and 20,000 ppm). |
| WO3 | Tetragonal, COD 1521533, P4/nmm | unknown | Calculated pattern inspected but not imported into the final common-project shortlist. |
| WO3 | Monoclinic, COD 1528915, P21/c | rejected | Stable and chemically plausible, but common-setting Rwp was 4.218%, clearly worse than COD 2311041. |
| WO3 | High-pressure monoclinic, COD 1563541, P21/c | unknown | Calculated pattern inspected; no stable common-project refinement was retained. |
| WO3 | Monoclinic, COD 2311041, P21/c parent | tested — selected | A unimodular basis change `a'=-(a+c), b'=b, c'=a` gives the equivalent P21/n small-beta setting. Common-setting Rwp was 3.840%, with modest cell adjustment and no topology change. |
| WO3 | Triclinic, COD 2106293, P-1 | rejected | Rwp 3.916%, but the source angles sheared from about 88.81/90.93° to 89.99/89.95°, effectively imitating the monoclinic metric beyond the allowed analogue mismatch. |
| WO3 | Orthorhombic, COD 2107312, Pnma | rejected | Rwp 6.777%; size reached 10 µm and strain rose to 9,123 ppm. |
| CaCO3 | Calcite, COD 1547347, R-3c, 294 K | tested — selected | Stable positive addition; two-phase Rwp 3.4166% fell to 3.2010% before the bounded coordinate finish. Final fraction is 5.40 wt%. |
| CaCO3 | High-temperature calcites COD 1547370–1547380, R-3c; COD 1547381, R-3m | unknown | Every same-formula entry was enumerated and its source conditions/pattern inspected; these 995–1254 K models were not imported as separate stable branches. |
| CaCO3 | COD 1508970 (C2/c), 2103119/5000085/9016215 (SG 62 entries), and 2106394 (P21/c) | unknown | Same-formula entries inspected; not imported into the common-project shortlist. |
| CaCO3 | Aragonite, COD 3000000, Ama2 | rejected | Stable addition trial; scale collapsed to numerical zero. |
| CaCO3 | Related aragonite entry COD 9017410 and orthorhombic COD 9017411 | unknown | Enumerated and inspected; the representative imported aragonite branch collapsed, but these entries were not separately refined. |
| CaCO3 | Vaterite, COD 9013565, P6522 | rejected | Stable addition trial; scale collapsed to numerical zero. |
| CaCO3 | Other same-formula entries COD 9017408, 9017409, 9017414, 9017415 | unknown | Enumerated and inspected; not separately imported. |
| Residual precursor/decomposition | CaO, COD 1563196 | rejected | Stable addition trial; scale collapsed. |
| Ca-W-O intermediate | Ca3WO6, COD 1563081 | rejected | Stable addition trial; scale collapsed. |
| Ca-W-O bronze | Ca4.26W10O30, COD 4030741 | rejected | Stable fractional-composition addition trial; scale collapsed. |

## Structural and nuisance branches

| Branch | Status | Outcome |
|---|---:|---|
| CaWO4 O coordinate | tested — selected | Unconstrained shift exceeded the known reference-mismatch range; retained along the refined direction at the 0.050 Å oxygen-RMS cap. |
| WO3 W coordinates | tested — selected | Two-site aggregate shift retained at the 0.040 Å general-atom RMS cap. |
| WO3 O coordinates | rejected | Single-site and six-site trials gave small fit gains only through 0.11–0.80 Å shifts; oxygen positions remain at the parent values. |
| Calcite O coordinate | tested — selected | One symmetry-allowed coordinate improved the fit; unconstrained 0.061 Å shift was capped and fixed at 0.050 Å. |
| CaWO4 common Uiso | tested — selected | A bounded common value of 0.01090 Å² was stable and supported by the dominant phase. |
| WO3 common Uiso | rejected | A bounded branch converged near 0.0037 Å², but improved Rwp by less than 0.001 percentage point and was weakly determined; the 0.005 Å² registered value was retained. |
| Calcite common Uiso | rejected | The unconstrained equality refinement crossed the 0.020 Å² bound; a fixed 0.003–0.020 Å² profile changed Rwp by only about 0.0003 percentage point. It is not determined reliably, so the registered 0.005 Å² value was retained. |
| Surface roughness | rejected | Negligible Rwp change; `SurfRoughB` hit 0.02 and A/B were 99.9% correlated. |
| Preferred orientation | rejected | CaWO4, WO3 and calcite axis screens produced ratios close to one and negligible gains. |
| Uniaxial microstrain | rejected | CaWO4, WO3 and calcite screens produced only negligible gains and/or strong profile correlation. |
| Isotropic calcite size + strain | tested — selected | Better than size-only; both stay in the laboratory ranges, but are 95.8% correlated, so their individual values are not interpreted. |
