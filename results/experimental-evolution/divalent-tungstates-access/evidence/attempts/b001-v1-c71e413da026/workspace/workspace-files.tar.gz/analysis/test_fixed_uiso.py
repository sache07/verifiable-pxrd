"""Profile a phase-common isotropic Uiso on a fixed grid."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2

from gsas_branch import snapshot


parser = argparse.ArgumentParser()
parser.add_argument("--input", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--phase", required=True)
parser.add_argument("--uiso", type=float, required=True)
parser.add_argument("--cycles", type=int, default=15)
args = parser.parse_args()
args.output.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(args.input, args.output)
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.output))
project.set_Controls("cycles", args.cycles)
project.data["Controls"]["data"]["parmFrozen"] = {}
project.data["Constraints"]["data"]["Phase"] = []
histogram = project.histograms()[0]
phase = project.phase(args.phase)
for atom in phase.atoms():
    atom.uiso = args.uiso
    atom.refinement_flags = atom.refinement_flags.replace("U", "")
for _ in range(4):
    project.refine(makeBack=False)
project.data["Controls"]["data"]["parmFrozen"] = {}
project.save(str(args.output))
state = snapshot(project, histogram, "fixed_uiso")
result = {"phase": args.phase, "uiso_A2": args.uiso, "state": state}
args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(json.dumps({"phase": args.phase, "uiso_A2": args.uiso,
                  "rwp_percent": state["rwp_percent"],
                  "fraction": state["hap"][args.phase]["weight_fraction"]}, indent=2))
