import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import percentile_filter, gaussian_filter1d
from scipy.signal import find_peaks


data = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
x, y = data.T
step = np.median(np.diff(x))
window = int(3.0 / step) // 2 * 2 + 1
background = percentile_filter(y, percentile=20, size=window, mode="nearest")
background = gaussian_filter1d(background, window / 10)
net = y - background
peaks, properties = find_peaks(net, prominence=250, distance=int(0.08 / step))

fig, axes = plt.subplots(2, 1, figsize=(15, 8), constrained_layout=True)
axes[0].plot(x, y, color="black", lw=0.55)
axes[0].plot(x, background, color="tab:orange", lw=1)
axes[0].set(xlim=(x[0], x[-1]), ylabel="counts", title="Observed scan and provisional baseline")
axes[1].plot(x, net, color="black", lw=0.55)
axes[1].scatter(x[peaks], net[peaks], s=12, color="tab:red")
for i in peaks:
    if net[i] > 450:
        axes[1].text(x[i], net[i], f"{x[i]:.2f}", rotation=90, va="bottom", ha="center", fontsize=7)
axes[1].set(xlim=(x[0], x[-1]), xlabel=r"$2\theta$ (deg)", ylabel="baseline-subtracted counts")
fig.savefig("analysis/pattern_overview.png", dpi=160)

fig, axes = plt.subplots(3, 1, figsize=(15, 9), constrained_layout=True)
for ax, limits in zip(axes, [(10, 40), (40, 70), (70, 100)]):
    mask = (x >= limits[0]) & (x <= limits[1])
    ax.plot(x[mask], net[mask], color="black", lw=0.7)
    selected = peaks[(x[peaks] >= limits[0]) & (x[peaks] <= limits[1])]
    ax.scatter(x[selected], net[selected], s=12, color="tab:red")
    for i in selected:
        if net[i] > 250:
            ax.text(x[i], net[i], f"{x[i]:.3f}", rotation=90, va="bottom", ha="center", fontsize=7)
    ax.set(xlim=limits, ylabel="net counts")
axes[-1].set_xlabel(r"$2\theta$ (deg)")
fig.savefig("analysis/pattern_segments.png", dpi=160)
