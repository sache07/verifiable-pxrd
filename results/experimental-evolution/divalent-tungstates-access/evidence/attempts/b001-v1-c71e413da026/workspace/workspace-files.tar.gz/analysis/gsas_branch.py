"""Create and refine controlled GSAS-II candidate branches for this scan.

Run with the GSAS-II Python interpreter. The script deliberately keeps the
candidate-screen model simple: common background/calibration settings,
symmetry-allowed cells, and isotropic phase broadening only.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import shutil
import sys
import traceback

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_input_files(folder: Path) -> tuple[Path, Path]:
    folder.mkdir(parents=True, exist_ok=True)
    x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1).T
    sigma = np.sqrt(np.maximum(y, 1.0))
    xye = folder / "observed.xye"
    np.savetxt(xye, np.column_stack((x, y, sigma)), fmt=("%.8f", "%.8f", "%.8f"))
    inst = folder / "instrument.instprm"
    inst.write_text(
        "# GSAS-II initial uncalibrated Cu Kalpha laboratory profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:0.0;V:0.0;W:8.0;X:0.1;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def initial_background(x: np.ndarray, y: np.ndarray, terms: int) -> list[float]:
    step = float(np.median(np.diff(x)))
    window = int(3.0 / step) // 2 * 2 + 1
    baseline = percentile_filter(y, percentile=18, size=window, mode="nearest")
    baseline = gaussian_filter1d(baseline, window / 10)
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(t, baseline, terms - 1).tolist()


def phase_active(phase, histogram_name: str) -> bool:
    hap = phase.data["Histograms"][histogram_name]
    return bool(hap.get("Use", True) and np.isfinite(hap["Scale"][0]) and hap["Scale"][0] > 0)


def snapshot(project, histogram, label: str) -> dict:
    arrays = histogram.data["data"][1]
    result = {
        "stage": label,
        "rwp_percent": float(histogram.get_wR()) if histogram.get_wR() is not None else None,
        "cells": {},
        "hap": {},
        "instrument": {},
        "sample": {},
    }
    for phase in project.phases():
        result["cells"][phase.name] = {k: float(v) for k, v in phase.get_cell().items()}
        hap = phase.data["Histograms"][histogram.name]
        result["hap"][phase.name] = {
            "active": phase_active(phase, histogram.name),
            "scale": float(hap["Scale"][0]),
            "mass": float(phase.data["General"]["Mass"]),
            "size": [hap["Size"][0], *[float(v) for v in hap["Size"][1][:3]]],
            "mustrain": [hap["Mustrain"][0], *[float(v) for v in hap["Mustrain"][1][:3]]],
            "preferred_orientation": [hap["Pref.Ori."][0], float(hap["Pref.Ori."][1]), list(hap["Pref.Ori."][3])],
        }
    for key, value in histogram.data["Instrument Parameters"][0].items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], (int, float)):
            result["instrument"][key] = float(value[1])
    for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"):
        value = histogram.data["Sample Parameters"].get(key)
        if isinstance(value, list):
            result["sample"][key] = float(value[0])
        elif isinstance(value, (int, float)):
            result["sample"][key] = float(value)
    yobs, ycalc, bkg, diff = arrays[1], arrays[3], arrays[4], arrays[5]
    result["curve"] = {
        "calculated_min": float(np.min(ycalc)),
        "calculated_max": float(np.max(ycalc)),
        "background_min": float(np.min(bkg)),
        "background_max": float(np.max(bkg)),
        "difference_rms_counts": float(np.sqrt(np.mean(diff**2))),
    }
    masses = np.array([v["scale"] * v["mass"] for v in result["hap"].values()])
    fractions = masses / masses.sum()
    for name, fraction in zip(result["hap"], fractions):
        result["hap"][name]["weight_fraction"] = float(fraction)
    cov = project.data.get("Covariance", {}).get("data", {})
    result["vary_list"] = [str(v) for v in cov.get("varyList", [])]
    result["variables"] = [float(v) for v in cov.get("variables", [])]
    result["sigmas"] = [float(v) for v in cov.get("sig", [])]
    return result


def validate(project, histogram, expected_names: set[str]) -> None:
    actual = {p.name for p in project.phases()}
    if actual != expected_names:
        raise RuntimeError(f"unexpected phases: {actual} != {expected_names}")
    for phase in project.phases():
        if not phase_active(phase, histogram.name):
            raise RuntimeError(f"inactive or nonpositive phase before refinement: {phase.name}")
        cell = phase.get_cell()
        if min(cell[k] for k in ("length_a", "length_b", "length_c", "volume")) <= 0:
            raise RuntimeError(f"invalid cell for {phase.name}")


def checkpoint(project, out: Path, label: str) -> Path:
    path = out.with_name(f"{out.stem}-{label}.gpx")
    project.save(str(path))
    return path


def refine_stage(project, histogram, names: set[str], out: Path, label: str, log: list[dict], repeats: int) -> None:
    validate(project, histogram, names)
    before = checkpoint(project, out, f"{label}-before")
    try:
        for _ in range(repeats):
            project.refine(makeBack=False)
        validate(project, histogram, names)
        state = snapshot(project, histogram, label)
        if state["curve"]["background_min"] < -1e-5:
            raise RuntimeError("negative refined background")
        log.append(state)
        checkpoint(project, out, label)
    except Exception:
        # Keep the last valid checkpoint and classify the trial as unknown.
        shutil.copy2(before, out.with_name(f"{out.stem}-{label}-unknown.gpx"))
        raise


def run(args: argparse.Namespace) -> dict:
    G2.SetPrintLevel("warn")
    out = Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    xye, inst = prepare_input_files(out.parent / "support")
    x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1).T

    project = G2.G2Project(newgpx=str(out))
    histogram = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    histogram.data["Instrument Parameters"][0]["Zero"][1] = float(args.initial_zero)
    histogram.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    histogram.data["Sample Parameters"]["Scale"] = [1.0, False]
    histogram.data["Sample Parameters"]["Gonio. radius"] = 200.0
    histogram.data["Sample Parameters"]["Shift"] = [0.0, False]
    histogram.set_refinements({
        "Limits": [float(x[0]), float(x[-1])],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": args.background_terms,
            "coeffs": initial_background(x, y, args.background_terms),
            "refine": True,
        },
    })

    specifications = [("CaWO4_scheelite", cod_path(args.cawo4_id), 0.25, 1200.0, args.cawo4_fraction)]
    if args.wo3_id:
        source = Path(args.wo3_path).resolve() if args.wo3_path else cod_path(args.wo3_id)
        specifications.append((f"WO3_{args.wo3_id}", source, 1.0, 300.0, 1.0 - args.cawo4_fraction))
    phases = {}
    for name, source, size, strain, fraction in specifications:
        if not source.is_file():
            raise FileNotFoundError(source)
        phase = project.add_phase(str(source), phasename=name, histograms=[histogram], fmthint="CIF")
        phases[name] = phase
        hap = phase.data["Histograms"][histogram.name]
        # Positive mass-scaled initialization; overall magnitude is subsequently refined.
        hap["Scale"] = [max(0.001, 100.0 * fraction / phase.data["General"]["Mass"]), True]
        phase.setSampleProfile(histogram, "size", "isotropic", size, LGmix=1.0)
        phase.setSampleProfile(histogram, "microstrain", "isotropic", strain, LGmix=1.0)
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Extinction"] = [0.0, False]
        phase.set_refinements({"Cell": False})

    project.set_Controls("cycles", args.cycles)
    project.index_ids()
    h_id = histogram.data["data"][0]["hId"]
    for phase in phases.values():
        p_id = phase.data["pId"]
        project.set_Controls("parmMin", 0.0, f"{p_id}:{h_id}:Scale")
        project.set_Controls("parmMin", 0.01, f"{p_id}:{h_id}:Size;i")
        project.set_Controls("parmMax", 10.0, f"{p_id}:{h_id}:Size;i")
        project.set_Controls("parmMin", 0.0, f"{p_id}:{h_id}:Mustrain;i")
        project.set_Controls("parmMax", 20000.0, f"{p_id}:{h_id}:Mustrain;i")
    project.set_Controls("parmMin", -0.30, f":{h_id}:Zero")
    project.set_Controls("parmMax", 0.30, f":{h_id}:Zero")
    project.set_Controls("parmMin", -800.0, f":{h_id}:Shift")
    project.set_Controls("parmMax", 800.0, f":{h_id}:Shift")
    project.set_Controls("parmMin", 0.1, f":{h_id}:W")
    project.set_Controls("parmMax", 100.0, f":{h_id}:W")
    project.set_Controls("parmMin", 0.001, f":{h_id}:SH/L")
    project.set_Controls("parmMax", 0.2, f":{h_id}:SH/L")

    names = set(phases)
    log: list[dict] = []

    # 1: scale and background only.
    refine_stage(project, histogram, names, out, "scale_background", log, args.repeats)

    # 2: common angular zero, then symmetry-independent phase cells.
    histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_stage(project, histogram, names, out, "zero", log, args.repeats)
    for phase in phases.values():
        phase.set_refinements({"Cell": True})
    refine_stage(project, histogram, names, out, "cells", log, args.repeats)

    # 3: specimen shift together with zero and cells (the two physical angular terms).
    histogram.set_refinements({"Sample Parameters": ["Shift"]})
    refine_stage(project, histogram, names, out, "shift_cells", log, args.repeats)

    # 4: common isotropic instrument and phase-broadening terms.
    # U versus phase microstrain and X versus phase size are exact/near-exact
    # profile correlations. Keep U=0 and X at the allowed lower edge while
    # fitting the equivalent broadening through each phase's sample terms.
    histogram.set_refinements({"Instrument Parameters": ["W", "SH/L"]})
    for phase in phases.values():
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }, [histogram])
    refine_stage(project, histogram, names, out, "isotropic_profile", log, args.repeats)

    project.save(str(out))
    report = {
        "status": "tested",
        "project": str(out),
        "cawo4_id": args.cawo4_id,
        "wo3_id": args.wo3_id,
        "stages": log,
        "final": snapshot(project, histogram, "final"),
    }
    Path(str(out) + ".json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    parser.add_argument("--cawo4-id", default="7219229")
    parser.add_argument("--wo3-id", default=None)
    parser.add_argument("--wo3-path", default=None)
    parser.add_argument("--cawo4-fraction", type=float, default=0.8)
    parser.add_argument("--background-terms", type=int, default=12)
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--repeats", type=int, default=2)
    parser.add_argument("--initial-zero", type=float, default=-0.25)
    args = parser.parse_args()
    try:
        report = run(args)
        print(json.dumps({"status": report["status"], "final": report["final"]}, indent=2))
    except Exception as exc:
        failure = {
            "status": "unknown",
            "error": str(exc),
            "traceback": traceback.format_exc(),
        }
        Path(args.out + ".json").write_text(json.dumps(failure, indent=2) + "\n")
        print(json.dumps(failure, indent=2), file=sys.stderr)
        raise


if __name__ == "__main__":
    main()
