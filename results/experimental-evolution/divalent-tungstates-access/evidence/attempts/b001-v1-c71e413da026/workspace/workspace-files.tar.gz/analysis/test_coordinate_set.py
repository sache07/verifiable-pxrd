"""Test a limited additional coordinate set from a common project."""

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

from gsas_branch import snapshot


parser = argparse.ArgumentParser()
parser.add_argument("--input", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--phase", required=True)
parser.add_argument("--labels", required=True)
parser.add_argument("--cycles", type=int, default=15)
args = parser.parse_args()
args.output.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(args.input, args.output)
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.output))
project.set_Controls("cycles", args.cycles)
project.data["Controls"]["data"]["parmFrozen"] = {}
histogram = project.histograms()[0]
phase = project.phase(args.phase)
labels = args.labels.split(",")
before = {label: np.asarray(phase.atom(label).coordinates, float) for label in labels}
for label in labels:
    phase.atom(label).refinement_flags = "X"
for _ in range(4):
    project.refine(makeBack=False)
project.save(str(args.output))
cell = phase.get_cell()
amat, _ = G2lat.cell2AB([cell[k] for k in ["length_a", "length_b", "length_c", "angle_alpha", "angle_beta", "angle_gamma"]])
shifts = {}
for label in labels:
    delta = np.asarray(phase.atom(label).coordinates) - before[label]
    delta -= np.rint(delta)
    shifts[label] = float(np.linalg.norm(amat @ delta))
state = snapshot(project, histogram, "coordinates")
result = {"phase": args.phase, "labels": labels, "coordinate_shifts_A": shifts, "state": state}
args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(json.dumps({"labels": labels, "rwp_percent": state["rwp_percent"], "coordinate_shifts_A": shifts}, indent=2))
