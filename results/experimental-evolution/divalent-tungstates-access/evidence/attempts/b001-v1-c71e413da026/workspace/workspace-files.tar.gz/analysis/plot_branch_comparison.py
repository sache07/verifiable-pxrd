import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path


files = {
    "monoclinic WO3 (COD 1528915)": Path("analysis/branches/wo3-1528915b.csv"),
    "triclinic WO3 (COD 2106293)": Path("analysis/branches/screen-2106293.csv"),
}
fig, axes = plt.subplots(3, 1, figsize=(15, 9), constrained_layout=True)
limits = [(10, 40), (40, 70), (70, 100)]
colors = ["tab:blue", "tab:orange"]
for ax, bounds in zip(axes, limits):
    first = np.loadtxt(next(iter(files.values())), delimiter=",", skiprows=1)
    mask = (first[:, 0] >= bounds[0]) & (first[:, 0] <= bounds[1])
    ax.plot(first[mask, 0], first[mask, 1], color="black", lw=0.55, label="observed")
    for (label, path), color in zip(files.items(), colors):
        data = np.loadtxt(path, delimiter=",", skiprows=1)
        mask = (data[:, 0] >= bounds[0]) & (data[:, 0] <= bounds[1])
        ax.plot(data[mask, 0], data[mask, 4], lw=0.65, color=color, label=f"residual: {label}")
    ax.axhline(0, color="gray", lw=0.5)
    ax.set_xlim(bounds)
    ax.set_ylabel("counts")
axes[0].legend(loc="upper right", fontsize=8)
axes[-1].set_xlabel(r"$2\theta$ (deg)")
fig.savefig("analysis/branch_residual_comparison.png", dpi=170)
