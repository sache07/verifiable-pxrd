"""Add one phase to the stable selected project and refine it in stages."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2

from gsas_branch import cod_path, snapshot


parser = argparse.ArgumentParser()
parser.add_argument("--input", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--cod-id")
parser.add_argument("--cif", type=Path)
parser.add_argument("--name", required=True)
parser.add_argument("--initial-fraction", type=float, default=0.02)
parser.add_argument("--cycles", type=int, default=15)
args = parser.parse_args()
if bool(args.cod_id) == bool(args.cif):
    parser.error("supply exactly one of --cod-id or --cif")
args.output.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(args.input, args.output)
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.output))
project.set_Controls("cycles", args.cycles)
project.data["Controls"]["data"]["parmFrozen"] = {}
# Existing Uiso values are fixed; remove their now-unused equality constraint.
project.data["Constraints"]["data"]["Phase"] = []
histogram = project.histograms()[0]

source_cif = cod_path(args.cod_id) if args.cod_id else args.cif.resolve()
phase = project.add_phase(str(source_cif), phasename=args.name, histograms=[histogram], fmthint="CIF")
hap = phase.data["Histograms"][histogram.name]
existing_mass_scale = sum(
    p.data["General"]["Mass"] * p.data["Histograms"][histogram.name]["Scale"][0]
    for p in project.phases() if p.name != phase.name
)
hap["Scale"] = [args.initial_fraction / (1 - args.initial_fraction) * existing_mass_scale / phase.data["General"]["Mass"], True]
phase.setSampleProfile(histogram, "size", "isotropic", 0.20, LGmix=1.0)
phase.setSampleProfile(histogram, "microstrain", "isotropic", 1000.0, LGmix=1.0)
hap["Size"][2] = [False, False, False]
hap["Mustrain"][2] = [False, False, False]
hap["Pref.Ori."][0] = "MD"
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = False
hap["Pref.Ori."][3] = [0, 0, 1]
phase.set_refinements({"Cell": False})
project.index_ids()
p_id = phase.data["pId"]
h_id = histogram.data["data"][0]["hId"]
project.set_Controls("parmMin", 0.0, f"{p_id}:{h_id}:Scale")
project.set_Controls("parmMin", 0.01, f"{p_id}:{h_id}:Size;i")
project.set_Controls("parmMax", 10.0, f"{p_id}:{h_id}:Size;i")
project.set_Controls("parmMin", 0.0, f"{p_id}:{h_id}:Mustrain;i")
project.set_Controls("parmMax", 20000.0, f"{p_id}:{h_id}:Mustrain;i")

stages = []
for _ in range(3):
    project.refine(makeBack=False)
stages.append(snapshot(project, histogram, "addition_scale"))

fraction = stages[-1]["hap"][phase.name]["weight_fraction"]
if fraction > 0.0005:
    phase.set_refinements({"Cell": True})
    for _ in range(3):
        project.refine(makeBack=False)
    stages.append(snapshot(project, histogram, "addition_cell"))
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    }, [histogram])
    for _ in range(3):
        project.refine(makeBack=False)
    stages.append(snapshot(project, histogram, "addition_profile"))

project.save(str(args.output))
final = snapshot(project, histogram, "final")
result = {"cod_id": args.cod_id, "cif_source": str(source_cif), "name": args.name,
          "status": "stable_positive" if final["hap"][phase.name]["weight_fraction"] > 0.0005 else "scale_collapsed",
          "stages": stages, "final": final}
args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(json.dumps({"cod_id": args.cod_id, "name": args.name, "status": result["status"],
                  "rwp_percent": final["rwp_percent"], "fractions": {k: v["weight_fraction"] for k, v in final["hap"].items()}}, indent=2))
