"""Cap the calcite oxygen shift at the laboratory mismatch bound and finish the model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

from gsas_branch import snapshot


parser = argparse.ArgumentParser()
parser.add_argument("--input", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--cycles", type=int, default=15)
args = parser.parse_args()
args.output.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(args.input, args.output)

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.output))
project.set_Controls("cycles", args.cycles)
project.data["Controls"]["data"]["parmFrozen"] = {}
project.data["Constraints"]["data"]["Phase"] = []
histogram = project.histograms()[0]
phase = project.phase("CaCO3 calcite")
atom = phase.atom("O2")
source = np.array([0.0, 0.2553, 0.25])
delta = np.asarray(atom.coordinates, float) - source
delta -= np.rint(delta)
cell = phase.get_cell()
amat, _ = G2lat.cell2AB([cell[k] for k in [
    "length_a", "length_b", "length_c", "angle_alpha", "angle_beta", "angle_gamma"
]])
distance = float(np.linalg.norm(amat @ delta))
factor = min(1.0, 0.05 / max(distance, 1e-12))
atom.coordinates = tuple((source + factor * delta) % 1)
atom.refinement_flags = atom.refinement_flags.replace("X", "")

# The profile screen supports both isotropic size and strain but not their
# individual partition; keep both inside the actual laboratory ranges.
hap = phase.data["Histograms"][histogram.name]
hap["Size"][2][0] = True
hap["Mustrain"][2][0] = True
project.index_ids()
p_id = phase.data["pId"]
h_id = histogram.data["data"][0]["hId"]
project.set_Controls("parmMin", 0.04, f"{p_id}:{h_id}:Size;i")
project.set_Controls("parmMax", 1.50, f"{p_id}:{h_id}:Size;i")
project.set_Controls("parmMin", 0.0, f"{p_id}:{h_id}:Mustrain;i")
project.set_Controls("parmMax", 8000.0, f"{p_id}:{h_id}:Mustrain;i")

for _ in range(5):
    project.refine(makeBack=False)
project.data["Controls"]["data"]["parmFrozen"] = {}
project.save(str(args.output))
state = snapshot(project, histogram, "regularized_three_phase")
result = {
    "calcite_oxygen_regularization": {
        "source_coordinates": source.tolist(),
        "unconstrained_shift_A": distance,
        "cap_A": 0.05,
        "scale_factor": factor,
        "fixed_coordinates": list(atom.coordinates),
    },
    "state": state,
}
args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(json.dumps({"rwp_percent": state["rwp_percent"],
                  "fractions": {k: v["weight_fraction"] for k, v in state["hap"].items()},
                  "calcite_oxygen": result["calcite_oxygen_regularization"],
                  "calcite_profile": state["hap"][phase.name]}, indent=2))
