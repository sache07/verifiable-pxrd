"""Put COD 2311041 in a numerically stable small-beta unimodular setting."""

import hashlib
import json
from pathlib import Path
import warnings

import numpy as np
from pymatgen.io.cif import CifParser
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


root = Path(__file__).resolve().parents[1]
source = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif")
destination = root / "analysis/candidates/2311041_small_beta.cif"
destination.parent.mkdir(parents=True, exist_ok=True)
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    structure = CifParser(source, frac_tolerance=0).parse_structures(primitive=False)[0]

# new a = -(old a + old c), new b = old b, new c = old a; |det| = 1.
transform = np.array([[-1, 0, -1], [0, 1, 0], [1, 0, 0]], dtype=int)
structure.make_supercell(transform)
analyzer = SpacegroupAnalyzer(structure, symprec=0.001)
symmetrized = analyzer.get_symmetrized_structure()
operations = analyzer.get_symmetry_operations(cartesian=False)
a, b, c = structure.lattice.abc
alpha, beta, gamma = structure.lattice.angles
lines = [
    "data_2311041_small_beta",
    "_chemical_formula_sum 'O3 W'",
    "_space_group_IT_number 14",
    "_space_group_name_H-M_alt 'P 1 21/n 1'",
    f"_cell_length_a {a:.10f}",
    f"_cell_length_b {b:.10f}",
    f"_cell_length_c {c:.10f}",
    f"_cell_angle_alpha {alpha:.10f}",
    f"_cell_angle_beta {beta:.10f}",
    f"_cell_angle_gamma {gamma:.10f}",
    "_cell_formula_units_Z 8",
    "loop_",
    "_space_group_symop_id",
    "_space_group_symop_operation_xyz",
]
for index, operation in enumerate(operations, 1):
    lines.append(f"{index} '{operation.as_xyz_str()}'")
lines.extend([
    "loop_",
    "_atom_site_label",
    "_atom_site_type_symbol",
    "_atom_site_fract_x",
    "_atom_site_fract_y",
    "_atom_site_fract_z",
    "_atom_site_occupancy",
    "_atom_site_U_iso_or_equiv",
])
counts = {"W": 0, "O": 0}
for group in symmetrized.equivalent_indices:
    site = structure[group[0]]
    symbol = site.specie.symbol
    counts[symbol] += 1
    x, y, z = site.frac_coords % 1
    lines.append(f"{symbol}{counts[symbol]} {symbol} {x:.10f} {y:.10f} {z:.10f} 1.0 0.005")
destination.write_text("\n".join(lines) + "\n")
record = {
    "source": str(source),
    "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "destination": str(destination),
    "destination_sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
    "transformation": "Unimodular basis change: a'=-(a+c), b'=b, c'=a; no atom, occupancy, or topology change.",
    "matrix": transform.tolist(),
    "cell": {
        "lengths_A": list(map(float, structure.lattice.abc)),
        "angles_deg": list(map(float, structure.lattice.angles)),
    },
}
destination.with_suffix(".provenance.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
