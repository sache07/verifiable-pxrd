"""Export cached GSAS-II branch curves and diagnostics for comparison plots."""

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("project", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
project = G2.G2Project(gpxfile=str(args.project))
histogram = project.histograms()[0]
data = histogram.data["data"][1]
curve = np.column_stack((data[0], data[1], data[3], data[4], data[5]))
np.savetxt(args.output, curve, delimiter=",", header="two_theta,observed,calculated,background,difference", comments="")
result = {
    "project": str(args.project),
    "histogram": histogram.name,
    "rwp_percent": histogram.get_wR(),
    "phases": [phase.name for phase in project.phases()],
}
args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
