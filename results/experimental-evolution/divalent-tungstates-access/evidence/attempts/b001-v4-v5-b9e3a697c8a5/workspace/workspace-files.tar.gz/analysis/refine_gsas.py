#!/usr/bin/env python3
"""Build and stage a conservative GSAS-II Rietveld refinement.

This helper is intentionally specimen-local. It imports the original CSV so
that the saved histogram has exactly the submitted observation grid and counts.
"""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
PATTERN = ROOT / "inputs" / "pattern.csv"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def instrument_text() -> str:
    return (
        "#GSAS-II Cu Kalpha Bragg-Brentano starting model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.46;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:20.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )


def initial_background(x: np.ndarray, y: np.ndarray, degree: int = 11) -> list[float]:
    # A low running percentile suppresses Bragg peaks. The smooth curve is only
    # a starting point; all coefficients are refined against the raw counts.
    baseline = percentile_filter(y, size=301, percentile=12, mode="nearest")
    baseline = gaussian_filter1d(baseline, 75)
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(t, baseline, degree).tolist()


def atom_table(phase) -> list[dict]:
    out = []
    for atom in phase.atoms():
        try:
            uiso = float(atom.uiso)
        except Exception:
            uiso = None
        out.append(
            {
                "label": atom.label,
                "type": atom.element,
                "xyz": [float(v) for v in atom.coordinates],
                "uiso": uiso,
                "flags": atom.refinement_flags,
            }
        )
    return out


def physical_state(gpx: G2.G2Project, hist) -> tuple[bool, list[str]]:
    issues: list[str] = []
    inst = hist.InstrumentParameters
    for key in ("U", "W", "X", "SH/L"):
        if key in inst and (not np.isfinite(inst[key][1]) or inst[key][1] < 0):
            issues.append(f"instrument {key}={inst[key][1]}")
    if not 0 <= inst["Polariz."][1] <= 1:
        issues.append(f"polarization={inst['Polariz.'][1]}")
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        if not np.isfinite(hap["Scale"][0]) or hap["Scale"][0] <= 0:
            issues.append(f"{phase.name} scale={hap['Scale'][0]}")
        if hap["Size"][1][0] <= 0:
            issues.append(f"{phase.name} size={hap['Size'][1][0]}")
        if hap["Mustrain"][1][0] < 0:
            issues.append(f"{phase.name} mustrain={hap['Mustrain'][1][0]}")
    calc = np.asarray(hist.getdata("Ycalc"), float)
    bg = np.asarray(hist.getdata("Background"), float)
    if not np.all(np.isfinite(calc)):
        issues.append("nonfinite calculated profile")
    if np.min(bg) < -1e-6:
        issues.append(f"negative background minimum={np.min(bg):.3f}")
    return not issues, issues


def summary(gpx: G2.G2Project, hist, stage: str) -> dict:
    masses = []
    phases = []
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(mass_scale)
        phases.append(
            {
                "name": phase.name,
                "mass_scale": mass_scale,
                "scale": float(hap["Scale"][0]),
                "cell": phase.get_cell(),
                "size": list(hap["Size"][1]),
                "mustrain": list(hap["Mustrain"][1]),
                "pref_ori": list(hap["Pref.Ori."][:4]),
            }
        )
    total = sum(masses)
    for phase, value in zip(phases, masses):
        phase["weight_fraction"] = value / total if total > 0 else math.nan
    ok, issues = physical_state(gpx, hist)
    inst = hist.InstrumentParameters
    return {
        "stage": stage,
        "residuals": {
            k: float(v)
            for k, v in hist.residuals.items()
            if isinstance(v, (int, float, np.integer, np.floating))
        },
        "physical": ok,
        "issues": issues,
        "instrument": {
            k: float(inst[k][1])
            for k in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
            if k in inst
        },
        "sample": {
            k: (float(v[0]) if isinstance(v, list) else v)
            for k, v in hist.SampleParameters.items()
            if k in ("Type", "Gonio. radius", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "phases": phases,
    }


def set_bounds(gpx: G2.G2Project, hist) -> None:
    # Bounds prevent exploratory branches from wandering into analytically
    # invalid peak profiles or negative crystalline abundances.
    hid = hist.id
    for key, lo, hi in (
        ("U", 0.0, 100.0),
        ("W", 0.01, 100.0),
        ("X", 0.001, 20.0),
        ("SH/L", 0.001, 0.2),
        ("Polariz.", 0.0, 1.0),
        ("Zero", -1.0, 1.0),
    ):
        var = f":{hid}:{key}"
        gpx.set_Controls("parmMin", lo, variable=var)
        gpx.set_Controls("parmMax", hi, variable=var)
    gpx.set_Controls("parmMin", -1500.0, variable=f":{hid}:Shift")
    gpx.set_Controls("parmMax", 1500.0, variable=f":{hid}:Shift")
    for phase in gpx.phases():
        pid = phase.id
        for key, lo, hi in (
            ("Scale", 1e-12, 1e12),
            ("Size;i", 0.02, 2.0),
            ("Mustrain;i", 0.0, 20000.0),
        ):
            var = f"{pid}:{hid}:{key}"
            gpx.set_Controls("parmMin", lo, variable=var)
            gpx.set_Controls("parmMax", hi, variable=var)


def checkpoint(gpx: G2.G2Project, hist, outdir: Path, tag: str, log: list[dict]) -> None:
    gpx.save()
    state = summary(gpx, hist, tag)
    log.append(state)
    shutil.copy2(gpx.filename, outdir / f"{tag}.gpx")
    print(json.dumps(state, indent=2))


def refine_once(gpx: G2.G2Project, hist, outdir: Path, tag: str, log: list[dict], cycles: int = 6) -> None:
    gpx.set_Controls("cycles", cycles)
    gpx.refine(makeBack=False)
    checkpoint(gpx, hist, outdir, tag, log)


def build(ids: list[str], names: list[str], out: Path, mode: str) -> None:
    out = out.resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    branch_dir = out.parent / (out.stem + "_checkpoints")
    branch_dir.mkdir(parents=True, exist_ok=True)
    inst_file = out.parent / (out.stem + ".instprm")
    inst_file.write_text(instrument_text())

    G2.SetPrintLevel("warn")
    gpx = G2.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(str(PATTERN), str(inst_file), fmthint="comma")
    x = np.asarray(hist.getdata("X"), float)
    y = np.asarray(hist.getdata("Yobs"), float)
    raw = np.loadtxt(PATTERN, delimiter=",", skiprows=1)
    if not (np.array_equal(x, raw[:, 0]) and np.array_equal(y, raw[:, 1])):
        raise RuntimeError("GSAS-II import does not exactly match the supplied scan")

    phases = []
    for cod_id, name in zip(ids, names):
        path = cod_path(cod_id)
        if not path.exists():
            raise FileNotFoundError(path)
        phases.append(gpx.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF"))

    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    coeffs = initial_background(x, y)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(coeffs),
                "coeffs": coeffs,
                "refine": False,
            }
        }
    )

    # Chemically plausible starting fractions; scales are subsequently free.
    if len(phases) == 3:
        fractions = np.array([0.65, 0.26, 0.09])
    elif len(phases) == 4:
        fractions = np.array([0.64, 0.20, 0.02, 0.14])
    else:
        fractions = np.full(len(phases), 1.0 / len(phases))
    for phase, frac in zip(phases, fractions):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10000.0 * float(frac) / float(phase.data["General"]["Mass"]), False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.5
        hap["Size"][1][1] = 0.5
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    # Calculate once and rescale the common crystalline amplitude to the data.
    gpx.set_Controls("cycles", 0)
    gpx.refine(makeBack=False)
    signal = np.asarray(hist.getdata("Ycalc"), float) - np.asarray(hist.getdata("Background"), float)
    target = np.percentile(y, 99.95) - np.median(coeffs[0:1])
    factor = max(target, 1.0) / max(float(np.max(signal)), 1e-9)
    for phase in phases:
        phase.data["Histograms"][hist.name]["Scale"][0] *= factor

    set_bounds(gpx, hist)
    gpx.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
    log: list[dict] = []
    checkpoint(gpx, hist, branch_dir, "00_start", log)

    # Background's bool shortcut returns early in GSASIIscriptable, so set the
    # instrument flag in a separate call.
    hist.set_refinements({"Background": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    refine_once(gpx, hist, branch_dir, "01_scale_background_zero", log)

    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine_once(gpx, hist, branch_dir, "02_cells", log)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine_once(gpx, hist, branch_dir, "03_instrument_profile", log)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine_once(gpx, hist, branch_dir, "04_sample_shift", log)

    if mode == "screen":
        final = summary(gpx, hist, "final")
        final["source_ids"] = ids
        final["atoms"] = {phase.name: atom_table(phase) for phase in phases}
        (out.with_suffix(".summary.json")).write_text(json.dumps({"stages": log, "final": final}, indent=2) + "\n")
        gpx.save(str(out))
        return

    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True, "value": 0.5}})
    refine_once(gpx, hist, branch_dir, "05_sizes", log)

    for phase in phases:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine_once(gpx, hist, branch_dir, "06_microstrain", log)

    if mode == "full":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        refine_once(gpx, hist, branch_dir, "07_polarization", log)

    final = summary(gpx, hist, "final")
    final["source_ids"] = ids
    final["atoms"] = {phase.name: atom_table(phase) for phase in phases}
    (out.with_suffix(".summary.json")).write_text(json.dumps({"stages": log, "final": final}, indent=2) + "\n")
    gpx.save(str(out))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ids", required=True, help="comma-separated COD IDs")
    parser.add_argument("--names", default="CuWO4,WO3,CuO", help="comma-separated phase names")
    parser.add_argument("--out", required=True)
    parser.add_argument("--mode", choices=("screen", "full"), default="screen")
    args = parser.parse_args()
    ids = [v.strip() for v in args.ids.split(",") if v.strip()]
    names = [v.strip() for v in args.names.split(",") if v.strip()]
    if len(ids) != len(names):
        raise SystemExit("--ids and --names must have the same number of entries")
    build(ids, names, Path(args.out), args.mode)


if __name__ == "__main__":
    main()
