#!/usr/bin/env python3
"""Freeze a chosen GSAS-II checkpoint and export the requested deliverables."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_branch import clear_flags


ROOT = Path(__file__).resolve().parents[1]


def safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", value).strip("_")


def main() -> None:
    source = Path(sys.argv[1]).resolve()
    output = ROOT / "final.gpx"
    G2.SetPrintLevel("warn")
    gpx = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = gpx.histogram(0)
    clear_flags(gpx, hist)
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    gpx.set_Controls("cycles", 0)
    gpx.refine(makeBack=False)

    # Freeze the actual saved phase/atom values rather than retaining stale
    # least-squares delta variables in CIF formatting.
    gpx.data["Covariance"]["data"] = {}
    gpx.save(str(output))

    hist = gpx.histogram(0)
    x = np.asarray(hist.getdata("X"), float)
    obs = np.asarray(hist.getdata("Yobs"), float)
    calc = np.asarray(hist.getdata("Ycalc"), float)
    background = np.asarray(hist.getdata("Background"), float)
    difference = obs - calc
    public = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    if not (np.array_equal(x, public[:, 0]) and np.array_equal(obs, public[:, 1])):
        raise RuntimeError("Final histogram does not preserve the supplied observation grid")
    if not np.all(np.isfinite(calc)) or np.any(calc < 0):
        raise RuntimeError("Final calculated profile is nonfinite or negative")

    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, obs, calc, difference, background)),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f", "%.10f"],
    )

    masses = []
    rows = []
    for i, phase in enumerate(gpx.phases(), start=1):
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
        filename = f"phase_{i}_{safe_name(phase.name)}.cif"
        phase.export_CIF(str(ROOT / filename))
        rows.append(
            {
                "name": phase.name,
                "cif_path": filename,
                "weight_fraction": None,
            }
        )
    total = sum(masses)
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = mass / total

    weights = 1.0 / np.maximum(obs, 1.0)
    numerator = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * obs**2))
    rwp = float(100.0 * np.sqrt(numerator / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(obs))
    expected = float(hist.residuals.get("wRmin", np.nan))
    result = {
        "phases": rows,
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "expected_rwp_percent": expected,
            "goodness_of_fit": rwp / expected,
            "chi_square": numerator,
            "n_points": int(len(x)),
            "difference_convention": "observed_minus_calculated",
        },
        "refinement_histogram": hist.name,
        "calibration": {
            "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
            "specimen_shift_um": float(hist.SampleParameters["Shift"][0]),
            "goniometer_radius_mm": float(hist.SampleParameters["Gonio. radius"]),
        },
        "fraction_basis": "normalized over modeled crystalline phases",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
