#!/usr/bin/env python3
"""Apply one bounded refinement branch to an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def clear_flags(gpx, hist) -> None:
    hist.clear_refinements({"Background": True})
    ikeys = [k for k, v in hist.InstrumentParameters.items() if isinstance(v, list) and len(v) > 2]
    hist.clear_refinements({"Instrument Parameters": ikeys})
    hist.clear_refinements(
        {"Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]}
    )
    for phase in gpx.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
            }
        )
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    for key in ("Hist", "HAP", "Phase", "Global"):
        gpx.data["Constraints"]["data"][key] = []


def enable_core(gpx, hist) -> None:
    hist.set_refinements({"Background": True})
    hist.set_refinements({"Instrument Parameters": ["W", "X", "Polariz."]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})


def set_coordinate_flags(gpx, include_oxygen: bool, oxygen_phases: set[int] | None = None) -> None:
    for i, phase in enumerate(gpx.phases()):
        for atom in phase.atoms():
            is_oxygen = atom.element.split("+")[0].split("-")[0] == "O"
            allow_oxygen = include_oxygen and (oxygen_phases is None or i in oxygen_phases)
            if allow_oxygen or not is_oxygen:
                atom.refinement_flags = "X"


def enable_saved_profiles(gpx, phases: list[int] | None = None) -> None:
    selected = set(phases if phases is not None else range(len(gpx.phases())))
    for i, phase in enumerate(gpx.phases()):
        if i not in selected:
            continue
        hap = next(iter(phase.data["Histograms"].values()))
        # Refine only terms that are not parked at a physical boundary.
        size = float(hap["Size"][1][0])
        strain = float(hap["Mustrain"][1][0])
        if 0.021 < size < 1.99:
            phase.set_HAP_refinements({"Size": {"type": hap["Size"][0], "refine": True}})
        if 1.0 < strain < 19999.0:
            phase.set_HAP_refinements({"Mustrain": {"type": hap["Mustrain"][0], "refine": True}})


def atom_state(gpx) -> dict:
    result = {}
    for phase in gpx.phases():
        rows = []
        for atom in phase.atoms():
            try:
                uiso = float(atom.uiso)
            except Exception:
                uiso = None
            rows.append(
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": [float(v) for v in atom.coordinates],
                    "uiso": uiso,
                    "flags": atom.refinement_flags,
                }
            )
        result[phase.name] = rows
    return result


def summarize(gpx, hist, label: str) -> dict:
    masses = []
    phases = []
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        value = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(value)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(hap["Scale"][0]),
                "size_type": hap["Size"][0],
                "size": [float(v) for v in hap["Size"][1]],
                "mustrain_type": hap["Mustrain"][0],
                "mustrain": [float(v) for v in hap["Mustrain"][1]],
                "mustrain_axis": list(hap["Mustrain"][3]),
                "pref_ori": [hap["Pref.Ori."][0], float(hap["Pref.Ori."][1]), bool(hap["Pref.Ori."][2]), list(hap["Pref.Ori."][3])],
            }
        )
    total = sum(masses)
    for row, mass in zip(phases, masses):
        row["weight_fraction"] = mass / total
    inst = hist.InstrumentParameters
    return {
        "label": label,
        "residuals": {
            k: float(v)
            for k, v in hist.residuals.items()
            if isinstance(v, (int, float, np.integer, np.floating))
        },
        "instrument": {
            k: float(inst[k][1])
            for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
            if k in inst
        },
        "sample": {
            k: (float(v[0]) if isinstance(v, list) else v)
            for k, v in hist.SampleParameters.items()
            if k in ("Type", "Gonio. radius", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "phases": phases,
        "atoms": atom_state(gpx),
        "vary_list": [str(v) for v in gpx.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
        "frozen": [str(v) for v in gpx.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument(
        "--action",
        choices=("core", "calibration", "shl", "heavy", "light", "uiso", "profiles", "size", "uniaxial", "md", "rough", "transfer"),
        required=True,
    )
    ap.add_argument("--phase", type=int)
    ap.add_argument("--phases", help="comma-separated phase indices for selected light-atom/profile work")
    ap.add_argument("--axis", default="0,0,1")
    ap.add_argument("--cycles", type=int, default=8)
    ap.add_argument("--rough-start", default="0.1,0.1")
    ap.add_argument("--coord-limit", type=float, help="symmetric per-refinement fractional-coordinate delta bound")
    ap.add_argument("--target", help="target GPX for a capped coordinate transfer")
    ap.add_argument("--fraction", type=float, default=0.5, help="oxygen fraction for coordinate transfer")
    ap.add_argument("--heavy-fraction", type=float, default=1.0, help="non-oxygen fraction for coordinate transfer")
    ap.add_argument("--start", type=float, help="starting scalar value for a selected profile term")
    ap.add_argument("--set-sizes", help="comma-separated fixed isotropic sizes, one per phase")
    ap.add_argument("--zero-start", type=float)
    ap.add_argument("--shift-start", type=float)
    args = ap.parse_args()

    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    gpx = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    hist = gpx.histogram(0)
    clear_flags(gpx, hist)
    enable_core(gpx, hist)

    if args.set_sizes:
        values = [float(v) for v in args.set_sizes.split(",")]
        if len(values) != len(gpx.phases()):
            raise SystemExit("--set-sizes requires one value per phase")
        for phase, value in zip(gpx.phases(), values):
            hap = phase.data["Histograms"][hist.name]
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = value
            hap["Size"][1][1] = value
            hap["Size"][2] = [False for _ in hap["Size"][2]]

    if args.action == "heavy":
        set_coordinate_flags(gpx, include_oxygen=False)
    elif args.action == "calibration":
        if args.zero_start is not None:
            hist.InstrumentParameters["Zero"][1] = float(args.zero_start)
        if args.shift_start is not None:
            hist.SampleParameters["Shift"][0] = float(args.shift_start)
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        hid = hist.id
        gpx.set_Controls("parmMin", -0.25, variable=f":{hid}:Zero")
        gpx.set_Controls("parmMax", 0.25, variable=f":{hid}:Zero")
        gpx.set_Controls("parmMin", -800.0, variable=f":{hid}:Shift")
        gpx.set_Controls("parmMax", 800.0, variable=f":{hid}:Shift")
    elif args.action == "shl":
        value = float(args.start) if args.start is not None else max(float(hist.InstrumentParameters["SH/L"][1]), 0.005)
        hist.InstrumentParameters["SH/L"][1] = value
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        hid = hist.id
        gpx.set_Controls("parmMin", 0.005, variable=f":{hid}:SH/L")
        gpx.set_Controls("parmMax", 0.10, variable=f":{hid}:SH/L")
    elif args.action == "light":
        selected = None if not args.phases else {int(v) for v in args.phases.split(",")}
        set_coordinate_flags(gpx, include_oxygen=True, oxygen_phases=selected)
    elif args.action == "uiso":
        # Synthetic registered references use neutral scattering factors and a
        # single isotropic U value per phase. Recreate that physically compact
        # parameterization with equality constraints.
        for phase in gpx.phases():
            old_u = [float(atom.uiso) for atom in phase.atoms()]
            start_u = float(np.mean(old_u)) if max(old_u) - min(old_u) < 1e-8 and 0.001 <= np.mean(old_u) <= 0.04 else 0.005
            for atom in phase.atoms():
                atom.type = atom.element
                atom.uiso = start_u
                atom.refinement_flags = "U"
            G2.SetupGeneral(phase.data, None)
        gpx.update_ids()
        gpx.index_ids()
        for phase in gpx.phases():
            pid = phase.id
            variables = [f"{pid}::AUiso:{j}" for j, _ in enumerate(phase.atoms())]
            if len(variables) > 1:
                gpx.add_EquivConstr(variables, reloadIdx=False)
            for variable in variables:
                gpx.set_Controls("parmMin", 0.001, variable=variable)
                gpx.set_Controls("parmMax", 0.04, variable=variable)
    elif args.action == "profiles":
        enable_saved_profiles(gpx)
    elif args.action == "size":
        if args.phase is None:
            raise SystemExit("--phase is required for size")
        phase = gpx.phases()[args.phase]
        hap = phase.data["Histograms"][hist.name]
        value = float(args.start) if args.start is not None else min(float(hap["Size"][1][0]), 1.5)
        hap["Size"][1][0] = value
        hap["Size"][1][1] = value
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True, "value": value}})
        variable = f"{phase.id}:{hist.id}:Size;i"
        gpx.set_Controls("parmMin", 0.04, variable=variable)
        gpx.set_Controls("parmMax", 1.5, variable=variable)
    elif args.action == "uniaxial":
        if args.phase is None:
            raise SystemExit("--phase is required for uniaxial")
        axis = [int(v) for v in args.axis.split(",")]
        phase = gpx.phases()[args.phase]
        hap = phase.data["Histograms"][hist.name]
        base = float(hap["Mustrain"][1][0])
        if hap["Mustrain"][0] != "uniaxial" or float(hap["Mustrain"][1][1]) <= 0:
            hap["Mustrain"][1][1] = max(base, 1.0)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}}
        )
    elif args.action == "md":
        if args.phase is None:
            raise SystemExit("--phase is required for md")
        axis = [int(v) for v in args.axis.split(",")]
        phase = gpx.phases()[args.phase]
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = axis
        phase.set_HAP_refinements({"Pref.Ori.": True})
    elif args.action == "rough":
        a, b = [float(v) for v in args.rough_start.split(",")]
        hist.SampleParameters["SurfRoughA"] = [a, False]
        hist.SampleParameters["SurfRoughB"] = [b, False]
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        hid = hist.id
        for key in ("SurfRoughA", "SurfRoughB"):
            gpx.set_Controls("parmMin", 0.001, variable=f":{hid}:{key}")
            gpx.set_Controls("parmMax", 1.0, variable=f":{hid}:{key}")
    elif args.action == "transfer":
        if args.phase is None or not args.target:
            raise SystemExit("--phase and --target are required for transfer")
        target = G2.G2Project(gpxfile=str(Path(args.target).resolve()))
        phase = gpx.phases()[args.phase]
        target_phase = target.phases()[args.phase]
        for atom, target_atom in zip(phase.atoms(), target_phase.atoms()):
            start = np.asarray(atom.coordinates, float)
            delta = np.asarray(target_atom.coordinates, float) - start
            delta -= np.round(delta)
            frac = args.fraction if atom.element == "O" else args.heavy_fraction
            atom.coordinates = (start + frac * delta) % 1.0

    if args.coord_limit is not None and args.action in ("heavy", "light"):
        gpx.update_ids()
        for phase in gpx.phases():
            for j, atom in enumerate(phase.atoms()):
                if "X" not in atom.refinement_flags:
                    continue
                for axis in ("x", "y", "z"):
                    variable = f"{phase.id}::dA{axis}:{j}"
                    gpx.set_Controls("parmMin", -args.coord_limit, variable=variable)
                    gpx.set_Controls("parmMax", args.coord_limit, variable=variable)

    before = summarize(gpx, hist, "before")
    gpx.set_Controls("cycles", args.cycles)
    gpx.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
    gpx.refine(makeBack=False)
    after = summarize(gpx, hist, "after")
    gpx.save(str(output))
    output.with_suffix(".summary.json").write_text(
        json.dumps({"before": before, "after": after}, indent=2) + "\n"
    )
    print(json.dumps({"before_wR": before["residuals"].get("wR"), "after": after}, indent=2))


if __name__ == "__main__":
    main()
