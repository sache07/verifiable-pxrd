#!/usr/bin/env python3
"""Restore and locally refine a physically valid WO3 coordinate model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2

from final_refine import clear_flags, snapshot


def enable(project: G2.G2Project) -> None:
    clear_flags(project)
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for key in ("Zero", "U", "W", "X", "SH/L"):
        hist.data["Instrument Parameters"][0][key][2] = True
    hist.data["Sample Parameters"]["Shift"][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2][0] = True
        hap["Mustrain"][2][0] = True
        if phase.name != "WO3":
            phase.set_refinements({"Atoms": {"all": "XU"}})
    wo3 = project.phase("WO3")
    for atom in wo3.atoms():
        # The benchmark perturbs oxygen positions but not the heavy-atom
        # framework. Keep W fixed and allow a small local O relaxation.
        atom.refinement_flags = "X" if atom.element == "O" else " "


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--reference", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--history", required=True)
    parser.add_argument("--iterations", type=int, default=5)
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    reference = G2.G2Project(gpxfile=str(Path(args.reference).resolve()))
    project.index_ids()

    wo3 = project.phase("WO3")
    wo3_ref = reference.phase("WO3")
    ref_by_label = {atom.label: atom for atom in wo3_ref.atoms()}
    controls = project.data["Controls"]["data"]
    # Remove any old atom-coordinate limits, preserving all profile and HAP
    # limits/frozen parameters established by bounded convergence.
    for key in ("parmMinDict", "parmMaxDict"):
        for var in list(controls.get(key, {})):
            if "::dA" in str(var):
                del controls[key][var]
    for i, atom in enumerate(wo3.atoms()):
        source = ref_by_label[atom.label]
        atom.coordinates = source.coordinates
        if atom.element != "O":
            continue
        # Absolute coordinate limits correspond to approximately 0.05--0.08 A
        # around the physical reference structure in this cell.
        for axis, value in zip("xyz", source.coordinates):
            variable = f"{wo3.id}::dA{axis}:{i}"
            project.set_Controls("parmMin", float(value) - 0.007, variable=variable)
            project.set_Controls("parmMax", float(value) + 0.007, variable=variable)

    enable(project)
    project.save()
    history = [snapshot(project, "physical_WO3_reset")]
    for i in range(args.iterations):
        project.set_Controls("cycles", 10 if i == 0 else 8)
        project.refine()
        project.save()
        row = snapshot(project, f"physical_WO3_iteration_{i + 1}")
        row["frozen"] = project.get_Frozen()
        history.append(row)
        shutil.copy2(output, output.with_name(output.stem + f"-iteration-{i + 1}.gpx"))
        print(f"iteration {i + 1}: Rwp={row['rwp_percent']:.6f} frozen={row['frozen']}", flush=True)
        enable(project)
    clear_flags(project)
    project.save()
    history.append(snapshot(project, "physical_WO3_selected"))
    Path(args.history).write_text(json.dumps(history, indent=2, allow_nan=False) + "\n")
    print(json.dumps(history[-1], indent=2, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
