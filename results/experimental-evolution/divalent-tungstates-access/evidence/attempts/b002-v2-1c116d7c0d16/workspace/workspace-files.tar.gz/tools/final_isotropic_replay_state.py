#!/usr/bin/env python3
"""Return the combined model to its supported isotropic WO3 state and converge."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2

from final_refine import clear_flags, snapshot


def set_flags(project: G2.G2Project) -> None:
    clear_flags(project)
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    inst = hist.data["Instrument Parameters"][0]
    for key in ("Zero", "U", "W", "X", "SH/L", "Polariz."):
        inst[key][2] = True
    sample = hist.data["Sample Parameters"]
    sample["Shift"][1] = True
    sample["SurfRoughB"][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2][0] = True
        hap["Mustrain"][2][0] = True
        if phase.name == "WO3":
            hap["Pref.Ori."][2] = True
            for atom in phase.atoms():
                atom.refinement_flags = "X" if atom.element == "O" else " "
        else:
            phase.set_refinements({"Atoms": {"all": "XU"}})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--history", required=True)
    parser.add_argument("--iterations", type=int, default=5)
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    project.index_ids()
    hist = project.histogram(0)
    wo3 = project.phase("WO3")
    hap = wo3.data["Histograms"][hist.name]
    strain = 0.5 * (float(hap["Mustrain"][1][0]) + float(hap["Mustrain"][1][1]))
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = strain
    hap["Mustrain"][1][1] = strain
    hap["Mustrain"][2] = [True, False, False]
    project.set_Frozen(f"{wo3.id}:0:Mustrain;i", mode="remove")
    project.set_Frozen(f"{wo3.id}:0:Mustrain;a", mode="remove")
    set_flags(project)
    project.save()
    history = [snapshot(project, "isotropic_start")]
    for i in range(args.iterations):
        project.set_Controls("cycles", 8)
        project.refine()
        project.save()
        row = snapshot(project, f"isotropic_iteration_{i + 1}")
        row["polarization"] = float(hist.data["Instrument Parameters"][0]["Polariz."][1])
        row["surface_roughness"] = {
            "A": float(hist.data["Sample Parameters"]["SurfRoughA"][0]),
            "B": float(hist.data["Sample Parameters"]["SurfRoughB"][0]),
        }
        row["wo3_md_ratio"] = float(hap["Pref.Ori."][1])
        row["frozen"] = project.get_Frozen()
        history.append(row)
        shutil.copy2(output, output.with_name(output.stem + f"-iteration-{i + 1}.gpx"))
        print(f"iteration {i + 1}: Rwp={row['rwp_percent']:.6f}", flush=True)
        set_flags(project)
    clear_flags(project)
    project.save()
    history.append(snapshot(project, "final_physical_state"))
    Path(args.history).write_text(json.dumps(history, indent=2, allow_nan=False) + "\n")
    print(json.dumps(history[-1], indent=2, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
