#!/usr/bin/env python3
"""Build and refine a reproducible GSAS-II trial against the supplied scan.

This is an exploratory driver: every invocation writes a separate directory so
that candidate additions can be compared from a common refinement protocol.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
import shutil
import sys
import traceback

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIpath


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument(
        "--phase",
        action="append",
        required=True,
        help="Phase as NAME=/absolute/or/relative/path.cif (repeatable)",
    )
    parser.add_argument("--coordinates", action="store_true")
    parser.add_argument("--uiso", action="store_true")
    parser.add_argument("--background-terms", type=int, default=10)
    return parser.parse_args()


def write_xye(pattern: Path, target: Path) -> tuple[np.ndarray, np.ndarray]:
    data = np.loadtxt(pattern, delimiter=",", skiprows=1)
    x, y = data.T
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(target, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")
    return x, y


def write_instprm(target: Path) -> None:
    target.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:15.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def snapshot(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(hap["Scale"][0]),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    return {
        "stage": stage,
        "rwp_percent": hist.get_wR(),
        "instrument": {
            key: value[1] if isinstance(value, list) and len(value) > 1 else value
            for key, value in inst.items()
            if key in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}
        },
        "sample": {
            key: value[0] if isinstance(value, list) else value
            for key, value in sample.items()
            if key in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"}
        },
        "phases": phases,
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "gsasii_revision": GSASIIpath.GetVersionNumber(),
    }


def run_refinement(project: G2.G2Project, stage: str, log: list[dict]) -> None:
    project.set_Controls("cycles", 5)
    project.refine()
    project.save()
    state = snapshot(project, stage)
    log.append(state)
    print(f"{stage:24s} Rwp={state['rwp_percent']!s}")


def main() -> None:
    args = parse_args()
    pattern = Path(args.pattern).resolve()
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    xye = out / "pattern.xye"
    instprm = out / "instrument.instprm"
    x, y = write_xye(pattern, xye)
    write_instprm(instprm)

    phase_specs = []
    for spec in args.phase:
        if "=" not in spec:
            raise ValueError("--phase must be NAME=PATH")
        name, filename = spec.split("=", 1)
        phase_specs.append((name, Path(filename).resolve()))

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(out / "trial.gpx"))
    phases = [
        project.add_phase(str(filename), phasename=name, fmthint="CIF")
        for name, filename in phase_specs
    ]
    hist = project.add_powder_histogram(
        str(xye), str(instprm), phases=phases, fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_terms,
                "coeffs": [float(np.percentile(y, 15))]
                + [0.0] * (args.background_terms - 1),
                "refine": True,
            },
        }
    )
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 100.0
        hap["Mustrain"][1][1] = 100.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]

    project.save()
    log: list[dict] = []
    run_refinement(project, "scale_background", log)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(project, "zero", log)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    run_refinement(project, "cells", log)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_refinement(project, "zero_shift_cells", log)

    hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    run_refinement(project, "profile_W_X_SHL", log)

    hist.set_refinements({"Instrument Parameters": ["U"]})
    run_refinement(project, "profile_U", log)

    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 1.0, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    run_refinement(project, "phase_broadening", log)

    # Refine the two Suortti terms only from positive, non-singular starts.
    hist.SampleParameters["SurfRoughA"] = [0.15, False]
    hist.SampleParameters["SurfRoughB"] = [0.08, False]
    hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    try:
        run_refinement(project, "surface_roughness", log)
    except Exception:
        hist.SampleParameters["SurfRoughA"] = [0.0, False]
        hist.SampleParameters["SurfRoughB"] = [0.0, False]
        project.save()
        log.append({"stage": "surface_roughness", "failed": traceback.format_exc()})

    if args.coordinates:
        for phase in phases:
            phase.set_refinements({"Atoms": {"all": "X"}})
        run_refinement(project, "coordinates", log)

    if args.uiso:
        for phase in phases:
            phase.set_refinements({"Atoms": {"all": "XU" if args.coordinates else "U"}})
        run_refinement(project, "uiso", log)

    project.save()
    arrays = hist.data["data"][1]
    calc = np.asarray(arrays[3], float)
    diff = np.asarray(arrays[5], float)
    fit = np.column_stack((arrays[0], arrays[1], calc, diff, arrays[4]))
    np.savetxt(
        out / "fit.csv",
        fit,
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
        fmt="%.8g",
    )
    (out / "history.json").write_text(json.dumps(log, indent=2, allow_nan=False) + "\n")
    print(json.dumps(snapshot(project, "final"), indent=2, allow_nan=False))


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        sys.exit(1)
