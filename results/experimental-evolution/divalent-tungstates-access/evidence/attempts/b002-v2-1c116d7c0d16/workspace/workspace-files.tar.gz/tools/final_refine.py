#!/usr/bin/env python3
"""Physically constrained staged refinement of the selected three-phase model.

The input is the best phase-selection project.  Exploratory nuisance/profile
parameters are reset into the ranges used to synthesize this benchmark, while
the selected phases, cells and scales are retained.  Every stage is checkpointed
and rejected if it leaves the stated physical domain or becomes numerically
unstable.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import shutil
import traceback

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIpath


PHASE_BOUNDS = {
    "size": (0.04, 1.50),
    "mustrain": (0.0, 8000.0),
    "uiso": (0.003, 0.020),
    "md": (0.70, 1.40),
}
INST_BOUNDS = {
    "Zero": (-0.25, 0.25),
    "U": (0.0, 40.0),
    "W": (2.0, 40.0),
    "X": (0.10, 6.0),
    "SH/L": (0.005, 0.10),
}


def clear_flags(project: G2.G2Project) -> None:
    """Clear every refinement flag, without changing values or constraints."""
    for hist in project.histograms():
        hist.data["Background"][0][1] = False
        for value in hist.data["Instrument Parameters"][0].values():
            if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
                value[2] = False
        for value in hist.data["Sample Parameters"].values():
            if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
                value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        for hap in phase.data.get("Histograms", {}).values():
            hap["Scale"][1] = False
            hap["Size"][2] = [False] * len(hap["Size"][2])
            hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
            if len(hap["Size"]) > 5:
                hap["Size"][5] = [False] * len(hap["Size"][5])
            if len(hap["Mustrain"]) > 5:
                hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
            hap["Pref.Ori."][2] = False
            hap["Extinction"][1] = False


def set_base_flags(project: G2.G2Project, background: bool = True) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = background
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def make_isotropic_atoms(project: G2.G2Project, uiso: float = 0.008) -> None:
    """Normalize all atoms to the benchmark's one-isotropic-U-per-phase model."""
    project.data["Constraints"]["data"]["Phase"] = []
    for phase in project.phases():
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = float(uiso)
            atom.data[atom.cia + 2 : atom.cia + 8] = [0.0] * 6
    project.save()
    project.index_ids()
    for phase in project.phases():
        vars_ = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(vars_) > 1:
            project.add_EquivConstr(vars_, reloadIdx=False)


def normalize_start(project: G2.G2Project) -> None:
    """Replace only values known to be nonphysical in the exploratory state."""
    clear_flags(project)
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    # Keep the fitted common Gaussian terms where already physical; reset the
    # negative Lorentzian term and the slightly over-bound zero.
    inst["Zero"][1] = 0.20
    inst["U"][1] = min(max(float(inst["U"][1]), 0.5), 35.0)
    inst["W"][1] = min(max(float(inst["W"][1]), 3.0), 38.0)
    inst["X"][1] = 0.60
    inst["SH/L"][1] = min(max(float(inst["SH/L"][1]), 0.008), 0.09)
    sample = hist.data["Sample Parameters"]
    sample["Shift"][0] = min(max(float(sample["Shift"][0]), -750.0), 750.0)
    # Both Suortti terms are finite and physical in the selected project.
    sample["SurfRoughA"][0] = min(max(float(sample["SurfRoughA"][0]), 0.0), 1.0)
    sample["SurfRoughB"][0] = min(max(float(sample["SurfRoughB"][0]), 0.0), 1.0)

    starts = {
        "MnWO4": (0.18, 900.0),
        "WO3": (0.35, 4500.0),
        "Mn3WO6_R-3": (0.125, 2500.0),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        size, strain = starts.get(phase.name, (0.25, 2000.0))
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
    make_isotropic_atoms(project)
    clear_flags(project)
    project.save()


def snapshot(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": {key: float(value) for key, value in phase.get_cell().items()},
                "scale": float(hap["Scale"][0]),
                "size_um": float(hap["Size"][1][0]),
                "mustrain_ppm": float(hap["Mustrain"][1][0]),
                "preferred_orientation": {
                    "model": hap["Pref.Ori."][0],
                    "ratio": float(hap["Pref.Ori."][1]),
                    "axis": list(hap["Pref.Ori."][3]),
                },
                "uiso": [float(atom.data[atom.cia + 1]) for atom in phase.atoms()],
            }
        )
    return {
        "stage": stage,
        "rwp_percent": float(hist.get_wR()),
        "instrument": {key: float(inst[key][1]) for key in INST_BOUNDS},
        "sample": {
            "Shift": float(sample["Shift"][0]),
            "SurfRoughA": float(sample["SurfRoughA"][0]),
            "SurfRoughB": float(sample["SurfRoughB"][0]),
        },
        "phases": phases,
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "gsasii_revision": GSASIIpath.GetVersionNumber(),
    }


def physical(project: G2.G2Project, check_uiso: bool = True) -> tuple[bool, str]:
    state = snapshot(project, "check")
    if not math.isfinite(state["rwp_percent"]):
        return False, "nonfinite Rwp"
    for key, bounds in INST_BOUNDS.items():
        val = state["instrument"][key]
        if not bounds[0] <= val <= bounds[1]:
            return False, f"instrument {key}={val:g} outside {bounds}"
    if not -800.0 <= state["sample"]["Shift"] <= 800.0:
        return False, f"sample shift={state['sample']['Shift']:g} outside range"
    if not (0.0 <= state["sample"]["SurfRoughA"] <= 1.5 and 0.0 <= state["sample"]["SurfRoughB"] <= 1.5):
        return False, "surface roughness outside finite physical range"
    for phase in state["phases"]:
        if phase["scale"] <= 0:
            return False, f"{phase['name']} scale is not positive"
        if not PHASE_BOUNDS["size"][0] <= phase["size_um"] <= PHASE_BOUNDS["size"][1]:
            return False, f"{phase['name']} size={phase['size_um']:g} outside range"
        strain = phase["mustrain_ppm"]
        if not (abs(strain) < 1e-8 or 300.0 <= strain <= PHASE_BOUNDS["mustrain"][1]):
            return False, f"{phase['name']} strain={strain:g} outside range"
        ratio = phase["preferred_orientation"]["ratio"]
        if not PHASE_BOUNDS["md"][0] <= ratio <= PHASE_BOUNDS["md"][1]:
            return False, f"{phase['name']} MD ratio={ratio:g} outside range"
        if check_uiso:
            for uiso in phase["uiso"]:
                if not PHASE_BOUNDS["uiso"][0] <= uiso <= PHASE_BOUNDS["uiso"][1]:
                    return False, f"{phase['name']} Uiso={uiso:g} outside range"
    return True, "ok"


def reload_project(checkpoint: Path, output: Path) -> G2.G2Project:
    project = G2.G2Project(gpxfile=str(checkpoint), newgpx=str(output))
    clear_flags(project)
    return project


def refine_checked(
    project: G2.G2Project,
    output: Path,
    stage: str,
    history: list[dict],
    cycles: int = 8,
    check_uiso: bool = True,
    max_degradation: float = 0.05,
) -> G2.G2Project:
    checkpoint = output.with_name(output.stem + f"-{stage}-before.gpx")
    project.save()
    shutil.copy2(output, checkpoint)
    before = float(project.histogram(0).get_wR())
    try:
        project.set_Controls("cycles", cycles)
        project.refine()
        project.save()
        row = snapshot(project, stage)
        ok, reason = physical(project, check_uiso=check_uiso)
        if row["rwp_percent"] > before + max_degradation:
            ok, reason = False, f"Rwp degraded from {before:.5f} to {row['rwp_percent']:.5f}"
        row["accepted"] = ok
        row["decision"] = reason
        history.append(row)
        print(f"{stage:30s} Rwp={row['rwp_percent']:.6f} accepted={ok} {reason}", flush=True)
        if ok:
            clear_flags(project)
            project.save()
            return project
    except Exception as exc:
        history.append({"stage": stage, "accepted": False, "decision": str(exc), "traceback": traceback.format_exc()})
        print(f"{stage:30s} rejected: {exc}", flush=True)
    return reload_project(checkpoint, output)


def enable_phase_base(project: G2.G2Project, phase_names: list[str] | None = None) -> None:
    set_base_flags(project)
    if phase_names is None:
        phase_names = [phase.name for phase in project.phases()]
    for name in phase_names:
        project.phase(name).data["General"]["Cell"][0] = True


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--history", required=True)
    args = parser.parse_args()
    source = Path(args.input).resolve()
    output = Path(args.output).resolve()
    history_file = Path(args.history).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    normalize_start(project)
    history: list[dict] = [snapshot(project, "normalized_start")]

    # Re-establish scales/background and cells after profile normalization.
    enable_phase_base(project)
    project = refine_checked(
        project, output, "background_scales_cells", history, cycles=10,
        max_degradation=100.0,
    )

    # Position correction. Zero and specimen displacement are nearly collinear
    # in this geometry, so refine them sequentially and retain only physical
    # improving steps.
    enable_phase_base(project)
    hist = project.histogram(0)
    hist.data["Instrument Parameters"][0]["Zero"][2] = True
    project = refine_checked(project, output, "zero", history, cycles=8)

    enable_phase_base(project)
    project.histogram(0).data["Sample Parameters"]["Shift"][1] = True
    project = refine_checked(project, output, "sample_shift", history, cycles=8)

    # Common instrument profile, first the stable Gaussian/Lorentzian widths,
    # then asymmetry. Phase widths remain fixed in these stages.
    enable_phase_base(project)
    inst = project.histogram(0).data["Instrument Parameters"][0]
    for key in ("U", "W", "X"):
        inst[key][2] = True
    project = refine_checked(project, output, "instrument_U_W_X", history, cycles=10)

    enable_phase_base(project)
    project.histogram(0).data["Instrument Parameters"][0]["SH/L"][2] = True
    project = refine_checked(project, output, "axial_divergence", history, cycles=8)

    # Phase-specific broadening is added independently, always in the common
    # three-phase state. This makes an unstable phase parameter easy to reject.
    for name in [phase.name for phase in project.phases()]:
        enable_phase_base(project)
        hap = project.phase(name).data["Histograms"][project.histogram(0).name]
        hap["Size"][2][0] = True
        project = refine_checked(project, output, f"size_{name}", history, cycles=8)
    for name in [phase.name for phase in project.phases()]:
        enable_phase_base(project)
        hap = project.phase(name).data["Histograms"][project.histogram(0).name]
        hap["Mustrain"][2][0] = True
        project = refine_checked(project, output, f"mustrain_{name}", history, cycles=8)

    # Coordinates are the main expected source-model mismatch. Introduce them
    # one phase at a time before a common coordinate/cell convergence stage.
    for name in ["Mn3WO6_R-3", "MnWO4", "WO3"]:
        enable_phase_base(project)
        project.phase(name).set_refinements({"Atoms": {"all": "X"}})
        project = refine_checked(project, output, f"coordinates_{name}", history, cycles=10)

    # One common isotropic displacement parameter per phase, matching the
    # benchmark's physical model. Equivalence constraints were installed above.
    for name in [phase.name for phase in project.phases()]:
        enable_phase_base(project)
        project.phase(name).set_refinements({"Atoms": {"all": "U"}})
        project = refine_checked(project, output, f"uiso_{name}", history, cycles=8)

    # Final ordinary convergence with all accepted physical isotropic terms.
    clear_flags(project)
    set_base_flags(project)
    hist = project.histogram(0)
    hist.data["Instrument Parameters"][0]["Zero"][2] = True
    hist.data["Sample Parameters"]["Shift"][1] = True
    for key in ("U", "W", "X", "SH/L"):
        hist.data["Instrument Parameters"][0][key][2] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.set_refinements({"Atoms": {"all": "XU"}})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
        hap["Mustrain"][2][0] = True
    project = refine_checked(project, output, "full_physical_convergence", history, cycles=12)

    clear_flags(project)
    project.save()
    history.append(snapshot(project, "selected_final"))
    history_file.write_text(json.dumps(history, indent=2, allow_nan=False) + "\n")
    print(json.dumps(history[-1], indent=2, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
