#!/usr/bin/env python3
"""Common-state tests for roughness, texture and uniaxial microstrain."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from final_refine import clear_flags


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])
STRAIN_AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def new_project(base: Path, target: Path) -> G2.G2Project:
    target.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(base), newgpx=str(target))
    project.index_ids()
    clear_flags(project)
    return project


def refine_twice(project: G2.G2Project, cycles: int = 7) -> None:
    """A second pass recalculates after any limit-clamping in the first."""
    for _ in range(2):
        project.set_Controls("cycles", cycles)
        project.refine()
        project.save()


def surface_trial(base: Path, target: Path, enabled: bool) -> dict:
    project = new_project(base, target)
    hist = project.histogram(0)
    sample = hist.data["Sample Parameters"]
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    if enabled:
        project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
        sample["SurfRoughA"][1] = True
        sample["SurfRoughB"][1] = True
    else:
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.0, False]
    refine_twice(project)
    return {
        "kind": "surface_roughness",
        "enabled": enabled,
        "rwp_percent": float(hist.get_wR()),
        "A": float(sample["SurfRoughA"][0]),
        "B": float(sample["SurfRoughB"][0]),
        "frozen": project.get_Frozen(),
        "project": str(target),
    }


def texture_trial(base: Path, target: Path, phase_name: str, axis: list[int]) -> dict:
    project = new_project(base, target)
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = True
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    project.set_Controls("parmMin", 0.70, variable=f"{phase.id}:0:MD")
    project.set_Controls("parmMax", 1.40, variable=f"{phase.id}:0:MD")
    refine_twice(project, cycles=6)
    return {
        "kind": "preferred_orientation",
        "phase": phase_name,
        "axis": list(axis),
        "rwp_percent": float(hist.get_wR()),
        "ratio": float(hap["Pref.Ori."][1]),
        "scale": float(hap["Scale"][0]),
        "frozen": project.get_Frozen(),
        "project": str(target),
    }


def strain_trial(base: Path, target: Path, phase_name: str, axis: list[int]) -> dict:
    project = new_project(base, target)
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][hist.name]
    # Release only this candidate's isotropic strain from a prior bound, then
    # replace it by the GSAS-II uniaxial model.
    project.set_Frozen(f"{phase.id}:0:Mustrain;i", mode="remove")
    hap["Mustrain"][0] = "uniaxial"
    start = max(300.0, min(8000.0, float(hap["Mustrain"][1][0])))
    hap["Mustrain"][1][0] = start
    hap["Mustrain"][1][1] = start
    hap["Mustrain"][2] = [True, True, False]
    hap["Mustrain"][3] = list(axis)
    hap["Scale"][1] = True
    project.set_Controls("parmMin", 300.0, variable=f"{phase.id}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;i")
    project.set_Controls("parmMin", 75.0, variable=f"{phase.id}:0:Mustrain;a")
    project.set_Controls("parmMax", 32000.0, variable=f"{phase.id}:0:Mustrain;a")
    refine_twice(project, cycles=7)
    equatorial = float(hap["Mustrain"][1][0])
    axial = float(hap["Mustrain"][1][1])
    return {
        "kind": "uniaxial_microstrain",
        "phase": phase_name,
        "axis": list(axis),
        "rwp_percent": float(hist.get_wR()),
        "equatorial_ppm": equatorial,
        "axial_ppm": axial,
        "axial_ratio": axial / equatorial if equatorial else None,
        "scale": float(hap["Scale"][0]),
        "frozen": project.get_Frozen(),
        "project": str(target),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    base = Path(args.base).resolve()
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    rows: list[dict] = []

    for enabled in (True, False):
        row = surface_trial(base, out / f"surface-{'on' if enabled else 'off'}.gpx", enabled)
        rows.append(row)
        print(json.dumps(row, allow_nan=False), flush=True)

    probe = G2.G2Project(gpxfile=str(base))
    phase_names = [phase.name for phase in probe.phases()]
    for phase_name in phase_names:
        for axis in AXES:
            tag = "".join(map(str, axis))
            row = texture_trial(base, out / f"texture-{phase_name}-{tag}.gpx", phase_name, list(axis))
            rows.append(row)
            print(json.dumps(row, allow_nan=False), flush=True)

    for phase_name in ("WO3", "Mn3WO6_R-3"):
        for axis in STRAIN_AXES:
            tag = "".join(map(str, axis))
            row = strain_trial(base, out / f"strain-{phase_name}-{tag}.gpx", phase_name, list(axis))
            rows.append(row)
            print(json.dumps(row, allow_nan=False), flush=True)

    (out / "results.json").write_text(json.dumps(rows, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
