#!/usr/bin/env python3
"""Common-state competition tests for alternate physical WO3 references."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from final_refine import clear_flags


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--cif-root", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--cod", action="append", required=True)
    args = parser.parse_args()
    base = Path(args.base).resolve()
    root = Path(args.cif_root).resolve()
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    rows = []
    for cod in args.cod:
        cif = root / cod[0] / cod[1:3] / cod[3:5] / f"{cod}.cif"
        target = out / f"WO3-{cod}.gpx"
        project = G2.G2Project(gpxfile=str(base), newgpx=str(target))
        project.index_ids()
        clear_flags(project)
        hist = project.histogram(0)
        old = project.phase("WO3")
        old_hap = old.data["Histograms"][hist.name]
        old_hap["Scale"][1] = True
        candidate = project.add_phase(
            str(cif), phasename=f"WO3_COD_{cod}", histograms=[hist], fmthint="CIF"
        )
        project.index_ids()
        clear_flags(project)
        old_hap = old.data["Histograms"][hist.name]
        old_hap["Scale"][1] = True
        hap = candidate.data["Histograms"][hist.name]
        hap["Scale"] = [float(old_hap["Scale"][0]) * 0.5, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.5
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 8000.0
        candidate.data["General"]["Cell"][0] = True
        for atom in candidate.atoms():
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = 0.003
            atom.data[atom.cia + 2 : atom.cia + 8] = [0.0] * 6
            atom.refinement_flags = " "
        project.set_Controls("parmMin", 1e-10, variable=f"{old.id}:0:Scale")
        project.set_Controls("parmMin", 1e-10, variable=f"{candidate.id}:0:Scale")
        project.save()
        for _ in range(3):
            project.set_Controls("cycles", 8)
            project.refine()
            project.save()
        row = {
            "cod": cod,
            "rwp_percent": float(hist.get_wR()),
            "existing_scale": float(old_hap["Scale"][0]),
            "candidate_scale": float(hap["Scale"][0]),
            "candidate_cell": candidate.get_cell(),
            "frozen": project.get_Frozen(),
            "project": str(target),
        }
        rows.append(row)
        print(json.dumps(row, allow_nan=False), flush=True)
    (out / "results.json").write_text(json.dumps(rows, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
