#!/usr/bin/env python3
"""Insert one candidate into a saved multiphase GPX with all other state fixed."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
import shutil
import sys
import traceback

from GSASII import GSASIIscriptable as G2


def clear_other_flags(project: G2.G2Project) -> None:
    for hist in project.histograms():
        hist.data["Background"][0][1] = False
        for value in hist.data["Instrument Parameters"][0].values():
            if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
                value[2] = False
        for value in hist.data["Sample Parameters"].values():
            if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
                value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        for hap in phase.data.get("Histograms", {}).values():
            hap["Scale"][1] = False
            hap["Size"][2] = [False for _ in hap["Size"][2]]
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
            if len(hap["Mustrain"]) > 5:
                hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
            hap["Pref.Ori."][2] = False
            hap["Extinction"][1] = False


def state(project: G2.G2Project, candidate_name: str, stage: str) -> dict:
    hist = project.histogram(0)
    phase = project.phase(candidate_name)
    hap = phase.data["Histograms"][hist.name]
    return {
        "stage": stage,
        "rwp_percent": hist.get_wR(),
        "candidate_scale": float(hap["Scale"][0]),
        "candidate_cell": phase.get_cell(),
        "candidate_size_um": float(hap["Size"][1][0]),
        "candidate_mustrain_ppm": float(hap["Mustrain"][1][0]),
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }


def refine(project: G2.G2Project, candidate_name: str, stage: str, history: list[dict]) -> None:
    project.set_Controls("cycles", 6)
    project.refine()
    project.save()
    row = state(project, candidate_name, stage)
    history.append(row)
    print(json.dumps(row, allow_nan=False), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--candidate", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--skip-size", action="store_true")
    parser.add_argument("--scale-only", action="store_true")
    parser.add_argument("--initial-scale", type=float, default=3.0)
    args = parser.parse_args()

    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.base).resolve()), newgpx=str(out / "trial.gpx"))
    clear_other_flags(project)
    hist = project.histogram(0)
    candidate = project.add_phase(
        str(Path(args.candidate).resolve()),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    clear_other_flags(project)
    hap = candidate.data["Histograms"][hist.name]
    hap["Scale"] = [args.initial_scale, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.20
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 2500.0
    hap["Mustrain"][1][1] = 2500.0
    hap["Mustrain"][2] = [False, False, False]
    history: list[dict] = []
    project.save()

    refine(project, args.name, "candidate_scale", history)
    if not args.scale_only:
        candidate.set_refinements({"Cell": True})
        refine(project, args.name, "candidate_scale_cell", history)

    # Candidate-specific width only; all established phases and common nuisance
    # parameters remain exactly fixed. Revert if GSAS leaves physical bounds.
    if not args.skip_size and not args.scale_only:
        checkpoint = out / "cell_checkpoint.gpx"
        project.save()
        shutil.copy2(out / "trial.gpx", checkpoint)
        candidate.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": hap["Size"][1][0], "refine": True}},
            [hist],
        )
        try:
            refine(project, args.name, "candidate_size", history)
            size = state(project, args.name, "candidate_size_check")["candidate_size_um"]
            if not 0.02 <= size <= 10.0:
                raise ValueError(f"nonphysical candidate size {size}")
        except Exception as exc:
            history.append({"stage": "candidate_size_rejected", "error": str(exc)})
            project = G2.G2Project(gpxfile=str(checkpoint), newgpx=str(out / "trial.gpx"))
            project.save()

    final = state(project, args.name, "final")
    history.append(final)
    (out / "result.json").write_text(json.dumps({"history": history, "final": final}, indent=2, allow_nan=False) + "\n")
    print(json.dumps(final, indent=2, allow_nan=False), flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        sys.exit(1)
