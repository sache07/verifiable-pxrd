#!/usr/bin/env python3
"""Converge the selected GSAS-II model using explicit physical parameter limits."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2

from final_refine import clear_flags, snapshot


def set_limit(project: G2.G2Project, variable: str, lower: float, upper: float) -> None:
    project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", upper, variable=variable)


def install_limits(project: G2.G2Project) -> None:
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    for variable, lo, hi in (
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.10, 6.0),
        (":0:SH/L", 0.005, 0.10),
    ):
        set_limit(project, variable, lo, hi)
    hist = project.histogram(0)
    for phase in project.phases():
        pid = phase.id
        set_limit(project, f"{pid}:0:Scale", 1.0e-8, 1.0e6)
        set_limit(project, f"{pid}:0:Size;i", 0.04, 1.50)
        set_limit(project, f"{pid}:0:Mustrain;i", 0.0, 8000.0)
        for i, _atom in enumerate(phase.atoms()):
            set_limit(project, f"{pid}::AUiso:{i}", 0.003, 0.020)
        hap = phase.data["Histograms"][hist.name]
        # If preferred orientation is introduced later, these limits remain.
        set_limit(project, f"{pid}:0:MD", 0.70, 1.40)


def set_full_flags(project: G2.G2Project, refine_surface: bool = False) -> None:
    clear_flags(project)
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    inst = hist.data["Instrument Parameters"][0]
    for key in ("Zero", "U", "W", "X", "SH/L"):
        inst[key][2] = True
    hist.data["Sample Parameters"]["Shift"][1] = True
    if refine_surface:
        hist.data["Sample Parameters"]["SurfRoughA"][1] = True
        hist.data["Sample Parameters"]["SurfRoughB"][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.set_refinements({"Atoms": {"all": "XU"}})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2][0] = True
        hap["Mustrain"][2][0] = True


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--history", required=True)
    parser.add_argument("--iterations", type=int, default=5)
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    project.index_ids()
    install_limits(project)
    set_full_flags(project)
    project.save()
    history = []
    for i in range(args.iterations):
        project.set_Controls("cycles", 10 if i == 0 else 8)
        project.refine()
        project.save()
        row = snapshot(project, f"bounded_iteration_{i + 1}")
        row["frozen"] = project.get_Frozen()
        history.append(row)
        shutil.copy2(output, output.with_name(output.stem + f"-iteration-{i + 1}.gpx"))
        print(
            f"iteration {i + 1}: Rwp={row['rwp_percent']:.6f} "
            f"frozen={row['frozen']}",
            flush=True,
        )
        # Keep the limit-frozen parameters frozen. Reassert all other flags,
        # since GSAS-II preserves the frozen list separately from refine flags.
        set_full_flags(project)
    clear_flags(project)
    project.save()
    history.append(snapshot(project, "bounded_selected"))
    Path(args.history).write_text(json.dumps(history, indent=2, allow_nan=False) + "\n")
    print(json.dumps(history[-1], indent=2, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
