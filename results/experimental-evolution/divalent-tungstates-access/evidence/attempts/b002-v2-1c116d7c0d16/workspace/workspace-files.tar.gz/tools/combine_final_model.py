#!/usr/bin/env python3
"""Combine supported nuisance models and converge the physical final state."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2

from final_refine import clear_flags, snapshot


def remove_frozen(project: G2.G2Project, variable: str) -> None:
    project.set_Frozen(variable, mode="remove")


def set_flags(project: G2.G2Project) -> None:
    clear_flags(project)
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    inst = hist.data["Instrument Parameters"][0]
    for key in ("Zero", "U", "W", "X", "SH/L", "Polariz."):
        inst[key][2] = True
    sample = hist.data["Sample Parameters"]
    sample["Shift"][1] = True
    sample["SurfRoughB"][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2][0] = True
        if phase.name == "WO3":
            hap["Mustrain"][2] = [True, True, False]
            hap["Pref.Ori."][2] = True
            for atom in phase.atoms():
                atom.refinement_flags = "X" if atom.element == "O" else " "
        else:
            hap["Mustrain"][2][0] = True
            phase.set_refinements({"Atoms": {"all": "XU"}})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--surface", required=True)
    parser.add_argument("--texture", required=True)
    parser.add_argument("--strain", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--history", required=True)
    parser.add_argument("--iterations", type=int, default=6)
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.base).resolve()), newgpx=str(output))
    project.index_ids()
    surface = G2.G2Project(gpxfile=str(Path(args.surface).resolve()))
    texture = G2.G2Project(gpxfile=str(Path(args.texture).resolve()))
    strain = G2.G2Project(gpxfile=str(Path(args.strain).resolve()))
    hist = project.histogram(0)

    # Transfer only the independently supported model terms into the common
    # physical state; structures, cells, scales and all other nuisance values
    # remain those of the screened base project.
    surface_sample = surface.histogram(0).data["Sample Parameters"]
    hist.data["Sample Parameters"]["SurfRoughA"] = [float(surface_sample["SurfRoughA"][0]), False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [float(surface_sample["SurfRoughB"][0]), True]
    wo3 = project.phase("WO3")
    tex_hap = texture.phase("WO3").data["Histograms"][texture.histogram(0).name]
    hap = wo3.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = float(tex_hap["Pref.Ori."][1])
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = [1, 0, 0]
    strain_hap = strain.phase("WO3").data["Histograms"][strain.histogram(0).name]
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = float(strain_hap["Mustrain"][1][0])
    hap["Mustrain"][1][1] = float(strain_hap["Mustrain"][1][1])
    hap["Mustrain"][2] = [True, True, False]
    hap["Mustrain"][3] = [0, 1, 0]
    remove_frozen(project, f"{wo3.id}:0:Mustrain;i")
    remove_frozen(project, f"{wo3.id}:0:Mustrain;a")

    # Bounds for the newly combined terms and the previously fixed but unknown
    # Cu K-alpha polarization factor.
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    project.set_Controls("parmMin", 0.50, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.00, variable=":0:Polariz.")
    project.set_Controls("parmMin", 300.0, variable=f"{wo3.id}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{wo3.id}:0:Mustrain;i")
    project.set_Controls("parmMin", 75.0, variable=f"{wo3.id}:0:Mustrain;a")
    project.set_Controls("parmMax", 32000.0, variable=f"{wo3.id}:0:Mustrain;a")
    project.set_Controls("parmMin", 0.70, variable=f"{wo3.id}:0:MD")
    project.set_Controls("parmMax", 1.40, variable=f"{wo3.id}:0:MD")

    set_flags(project)
    project.save()
    history = [snapshot(project, "combined_start")]
    for i in range(args.iterations):
        project.set_Controls("cycles", 10 if i == 0 else 8)
        project.refine()
        project.save()
        row = snapshot(project, f"combined_iteration_{i + 1}")
        row["polarization"] = float(project.histogram(0).data["Instrument Parameters"][0]["Polariz."][1])
        row["surface_roughness"] = {
            "A": float(project.histogram(0).data["Sample Parameters"]["SurfRoughA"][0]),
            "B": float(project.histogram(0).data["Sample Parameters"]["SurfRoughB"][0]),
        }
        whap = project.phase("WO3").data["Histograms"][project.histogram(0).name]
        row["wo3_nuisance"] = {
            "md_ratio": float(whap["Pref.Ori."][1]),
            "md_axis": list(whap["Pref.Ori."][3]),
            "mustrain_equatorial_ppm": float(whap["Mustrain"][1][0]),
            "mustrain_axial_ppm": float(whap["Mustrain"][1][1]),
            "mustrain_axis": list(whap["Mustrain"][3]),
        }
        row["frozen"] = project.get_Frozen()
        history.append(row)
        shutil.copy2(output, output.with_name(output.stem + f"-iteration-{i + 1}.gpx"))
        print(
            f"iteration {i + 1}: Rwp={row['rwp_percent']:.6f} "
            f"polariz={row['polarization']:.5f} frozen={row['frozen']}",
            flush=True,
        )
        set_flags(project)
    clear_flags(project)
    project.save()
    history.append(snapshot(project, "combined_selected"))
    Path(args.history).write_text(json.dumps(history, indent=2, allow_nan=False) + "\n")
    print(json.dumps(history[-1], indent=2, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
