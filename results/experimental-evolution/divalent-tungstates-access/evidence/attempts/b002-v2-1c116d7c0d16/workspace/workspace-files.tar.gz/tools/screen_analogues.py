#!/usr/bin/env python3
"""Residual-directed screen of same-stoichiometry oxide frameworks.

Parent structures are drawn from the supplied frozen COD snapshot. Their two
cation species are replaced by Mn and W according to a requested target
stoichiometry. A coarse isotropic cell rescaling is optimized only to rank
frameworks against the positive/negative residual of a common multiphase fit.
Top hits still require a full common-state GSAS-II trial.
"""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
import warnings

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Element
from pymatgen.io.cif import CifParser
from scipy.ndimage import gaussian_filter1d


TARGETS = [
    (2, 1, 5),
    (3, 1, 6),
    (3, 2, 9),
    (4, 1, 7),
    (2, 3, 11),
    (5, 1, 8),
    (1, 2, 7),
    (2, 1, 6),  # mixed-valence/oxidized Mn possibility
    (1, 1, 5),
    (2, 2, 9),
]


def reduced_amounts(comp: Composition) -> tuple[dict[str, float], float]:
    reduced = comp.get_reduced_composition_and_factor()[0]
    return reduced.get_el_amt_dict(), float(reduced["O"])


def gaussian_profile(x: np.ndarray, positions: np.ndarray, intensities: np.ndarray, fwhm: float = 0.38) -> np.ndarray:
    result = np.zeros_like(x)
    sigma = fwhm / 2.354820045
    step = x[1] - x[0]
    half = int(np.ceil(4.0 * sigma / step))
    for pos, inten in zip(positions, intensities):
        center = int(round((pos - x[0]) / step))
        lo, hi = max(0, center - half), min(len(x), center + half + 1)
        if lo >= hi:
            continue
        dx = x[lo:hi] - pos
        result[lo:hi] += inten * np.exp(-0.5 * (dx / sigma) ** 2)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--index", required=True)
    parser.add_argument("--cifs", required=True)
    parser.add_argument("--fit", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--top", type=int, default=100)
    args = parser.parse_args()

    fit = np.loadtxt(args.fit, delimiter=",", skiprows=1)
    x, observed, calculated, residual = fit[:, :4].T
    # Broad smoothing targets the coherent unmodeled component, while retaining
    # negative residuals as a penalty for unsupported candidate reflections.
    smooth = gaussian_filter1d(residual, 10.0)
    weights = 1.0 / np.maximum(observed, 1.0)
    with gzip.open(args.index, "rt") as stream:
        index = json.load(stream)
    cif_root = Path(args.cifs)
    calculator = XRDCalculator(wavelength=1.540598, symprec=0)
    scale_grid = np.linspace(0.78, 1.25, 142)
    rows = []

    target_sets = {(tuple(sorted((m, n))), o): (m, n, o) for m, n, o in TARGETS}
    for key, records in index.items():
        elements = key.split("-")
        if len(elements) != 3 or "O" not in elements:
            continue
        for formula, cod_id, space_group, r_value in records:
            try:
                amounts, oxygen = reduced_amounts(Composition(formula))
                cations = [(el, val) for el, val in amounts.items() if el != "O"]
                if len(cations) != 2:
                    continue
                signature = (tuple(sorted(round(v, 6) for _, v in cations)), round(oxygen, 6))
                target = target_sets.get(signature)
                if target is None:
                    continue
                m, n, o = target
                # Assign by stoichiometric multiplicity. Equal cation counts are
                # ambiguous and are screened in both permutations.
                mappings = []
                for first_mn in (True, False):
                    a, b = cations
                    mapping = {a[0]: "Mn" if first_mn else "W", b[0]: "W" if first_mn else "Mn"}
                    mapped = {mapping[el]: val for el, val in cations}
                    if abs(mapped.get("Mn", 0) - m) < 1e-5 and abs(mapped.get("W", 0) - n) < 1e-5:
                        mappings.append(mapping)
                if not mappings:
                    continue

                cif = cif_root / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    structure = CifParser(cif, occupancy_tolerance=1.2).parse_structures(primitive=False)[0]
                actual, actual_o = reduced_amounts(structure.composition)
                actual_cations = [(el, val) for el, val in actual.items() if el != "O"]
                if len(actual_cations) != 2:
                    continue
                actual_signature = (tuple(sorted(round(v, 4) for _, v in actual_cations)), round(actual_o, 4))
                if actual_signature != signature:
                    continue

                for mapping in mappings:
                    candidate = structure.copy()
                    candidate.remove_oxidation_states()
                    candidate.replace_species({Element(src): Element(dst) for src, dst in mapping.items()})
                    pattern = calculator.get_pattern(candidate, two_theta_range=(7.0, 125.0), scaled=False)
                    source_pos = np.asarray(pattern.x)
                    source_int = np.asarray(pattern.y)
                    if not len(source_pos) or np.max(source_int) <= 0:
                        continue
                    source_int = source_int / np.max(source_int)
                    best = None
                    for scale in scale_grid:
                        arg = np.sin(np.deg2rad(source_pos / 2.0)) / scale
                        valid = (arg > 0) & (arg < 1)
                        pos = 2.0 * np.rad2deg(np.arcsin(arg[valid]))
                        inten = source_int[valid]
                        inside = (pos >= x[0]) & (pos <= x[-1]) & (inten >= 0.002)
                        if not np.any(inside):
                            continue
                        # Fast stick-to-smoothed-residual score for the scale search.
                        sampled = np.interp(pos[inside], x, smooth)
                        score = float(np.sum(inten[inside] * sampled) / np.sqrt(np.sum(inten[inside] ** 2)))
                        if best is None or score > best[0]:
                            best = (score, float(scale), pos, inten)
                    if best is None:
                        continue
                    _, scale, pos, inten = best
                    inside = (pos >= x[0]) & (pos <= x[-1]) & (inten >= 0.001)
                    profile = gaussian_profile(x, pos[inside], inten[inside])
                    denom = float(np.sum(weights * profile * profile))
                    amplitude = max(0.0, float(np.sum(weights * profile * residual)) / denom) if denom > 0 else 0.0
                    improvement = float(np.sum(weights * residual * residual) - np.sum(weights * (residual - amplitude * profile) ** 2))
                    rows.append(
                        {
                            "target": f"Mn{m if m != 1 else ''}W{n if n != 1 else ''}O{o}",
                            "parent_formula": formula,
                            "cod_id": cod_id,
                            "space_group_number": space_group,
                            "mapping": mapping,
                            "substitutions": sum(src != dst for src, dst in mapping.items()),
                            "isotropic_length_scale": scale,
                            "profile_amplitude": amplitude,
                            "weighted_sse_improvement": improvement,
                            "stick_score": best[0],
                            "source_cif": str(cif),
                            "parent_cell": list(structure.lattice.parameters),
                            "sites": len(structure),
                        }
                    )
            except Exception:
                continue

    rows.sort(key=lambda row: row["weighted_sse_improvement"], reverse=True)
    result = {"targets": TARGETS, "screened_models": len(rows), "ranking": rows[: args.top]}
    Path(args.out).write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    for i, row in enumerate(rows[: min(50, args.top)], 1):
        print(
            f"{i:3d} {row['target']:10s} COD {row['cod_id']} {row['parent_formula']:18s} "
            f"SG {row['space_group_number']:3d} subst={row['substitutions']} "
            f"scale={row['isotropic_length_scale']:.4f} improve={row['weighted_sse_improvement']:.2f}"
        )


if __name__ == "__main__":
    main()
