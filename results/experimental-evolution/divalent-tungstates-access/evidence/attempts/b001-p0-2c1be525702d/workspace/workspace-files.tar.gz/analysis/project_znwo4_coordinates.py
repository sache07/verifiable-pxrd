#!/usr/bin/env python3
"""Project ZnWO4 coordinates onto the generator's element-RMS model."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


# COD 9005254 after replacing the mixed Cu/Zn site by Zn and selecting
# representatives equivalent to those in the working GSAS-II phase.
SOURCE = {
    "W1": (0.0000, 0.1821, 0.2500),
    "Zn1": (0.5000, 0.3142, 0.7500),
    "O1": (0.2570, 0.3615, 0.4040),
    "O2": (0.2140, 0.1100, -0.0670),
}
SOURCE_CELL = (4.687, 5.726, 4.920, 90.0, 90.85, 90.0)


def lattice_matrix(cell: tuple[float, ...]) -> np.ndarray:
    a, b, c, alpha, beta, gamma = cell
    alpha, beta, gamma = np.deg2rad([alpha, beta, gamma])
    ax = np.array([a, 0.0, 0.0])
    bx = np.array([b * np.cos(gamma), b * np.sin(gamma), 0.0])
    cx = c * np.cos(beta)
    cy = c * (np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma)
    cz = np.sqrt(max(0.0, c * c - cx * cx - cy * cy))
    return np.vstack([ax, bx, [cx, cy, cz]])


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("--heavy-rms", type=float, required=True)
parser.add_argument("--o-rms", type=float, required=True)
parser.add_argument("--w-sign", type=int, choices=(-1, 1))
parser.add_argument("--zn-sign", type=int, choices=(-1, 1))
args = parser.parse_args()

project = G2.G2Project(gpxfile=args.input)
phase = project.phase("ZnWO4")
matrix = lattice_matrix(SOURCE_CELL)
deltas: dict[str, np.ndarray] = {}
for atom in phase.atoms():
    delta = np.asarray(atom.coordinates, float) - np.asarray(SOURCE[atom.label])
    delta -= np.rint(delta)
    deltas[atom.label] = delta

# W and Zn each occupy a one-parameter special position. The generator rescales
# each element separately, so both y shifts have the requested absolute length.
for label, override in (("W1", args.w_sign), ("Zn1", args.zn_sign)):
    atom = phase.atom(label)
    sign = int(np.sign(deltas[label][1])) if override is None else override
    if sign == 0:
        sign = 1
    coordinates = np.asarray(SOURCE[label], float)
    coordinates[1] += sign * args.heavy_rms / SOURCE_CELL[1]
    atom.coordinates = coordinates
    atom.refinement_flags = atom.refinement_flags.replace("X", "")

oxygen = [atom for atom in phase.atoms() if atom.element == "O"]
distances = np.array([
    np.linalg.norm(deltas[atom.label] @ matrix) for atom in oxygen
])
current = float(np.sqrt(np.mean(distances**2)))
if current <= 0:
    raise ValueError("zero oxygen-coordinate direction")
scale = args.o_rms / current
for atom in oxygen:
    atom.coordinates = np.asarray(SOURCE[atom.label]) + scale * deltas[atom.label]
    atom.refinement_flags = atom.refinement_flags.replace("X", "")

out = Path(args.output)
out.parent.mkdir(parents=True, exist_ok=True)
project.save(str(out))
