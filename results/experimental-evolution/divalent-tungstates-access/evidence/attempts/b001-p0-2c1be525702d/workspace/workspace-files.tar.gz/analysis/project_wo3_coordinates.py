#!/usr/bin/env python3
"""Project a WO3 coordinate-refinement direction onto element RMS limits."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = {
    "O6": (0.280, 0.240, -0.030),
    "W2": (0.247, 0.033, 0.781),
    "O2": (0.000, 0.475, 0.220),
    "O5": (0.280, 0.040, 0.030),
    "O4": (0.210, 0.290, 0.735),
    "O3": (0.290, 0.290, 0.265),
    "O1": (0.000, 0.025, 0.220),
    "W1": (0.252, 0.026, 0.285),
}


def lattice_matrix(cell: list[float]) -> np.ndarray:
    a, b, c, alpha, beta, gamma = cell[:6]
    alpha, beta, gamma = np.deg2rad([alpha, beta, gamma])
    ax = np.array([a, 0.0, 0.0])
    bx = np.array([b * np.cos(gamma), b * np.sin(gamma), 0.0])
    cx = c * np.cos(beta)
    cy = c * (np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma)
    cz = np.sqrt(max(0.0, c * c - cx * cx - cy * cy))
    return np.vstack([ax, bx, [cx, cy, cz]])


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("--w-rms", type=float, required=True)
parser.add_argument("--o-rms", type=float, required=True)
args = parser.parse_args()

project = G2.G2Project(gpxfile=args.input)
phase = project.phase("WO3")
matrix = lattice_matrix(list(phase.get_cell().values())[:6])
targets = {"W": args.w_rms, "O": args.o_rms}

deltas: dict[str, np.ndarray] = {}
for atom in phase.atoms():
    source = np.asarray(SOURCE[atom.label], float)
    delta = np.asarray(atom.coordinates, float) - source
    delta -= np.rint(delta)
    deltas[atom.label] = delta

for element, target in targets.items():
    selected = [atom for atom in phase.atoms() if atom.element == element]
    distances = np.array([np.linalg.norm(deltas[atom.label] @ matrix) for atom in selected])
    current = float(np.sqrt(np.mean(distances**2)))
    if current <= 0:
        raise ValueError(f"zero coordinate direction for {element}")
    scale = target / current
    for atom in selected:
        atom.coordinates = np.asarray(SOURCE[atom.label]) + scale * deltas[atom.label]
        atom.refinement_flags = atom.refinement_flags.replace("X", "")

out = Path(args.output)
out.parent.mkdir(parents=True, exist_ok=True)
project.save(str(out))
