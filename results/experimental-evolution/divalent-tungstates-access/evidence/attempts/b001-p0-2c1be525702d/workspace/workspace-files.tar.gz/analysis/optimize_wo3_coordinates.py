#!/usr/bin/env python3
"""Optimize WO3 coordinates inside the generator's element-RMS bounds."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.optimize import minimize
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIstrIO as IO
from GSASII import GSASIIstrMath as M


SOURCE = {
    "O6": np.array((0.280, 0.240, -0.030)),
    "W2": np.array((0.247, 0.033, 0.781)),
    "O2": np.array((0.000, 0.475, 0.220)),
    "O5": np.array((0.280, 0.040, 0.030)),
    "O4": np.array((0.210, 0.290, 0.735)),
    "O3": np.array((0.290, 0.290, 0.265)),
    "O1": np.array((0.000, 0.025, 0.220)),
    "W1": np.array((0.252, 0.026, 0.285)),
}
SOURCE_CELL = (7.30, 7.53, 7.68, 90.0, 90.9, 90.0)


def lattice_matrix(cell: tuple[float, ...]) -> np.ndarray:
    a, b, c, alpha, beta, gamma = cell
    alpha, beta, gamma = np.deg2rad([alpha, beta, gamma])
    ax = np.array([a, 0.0, 0.0])
    bx = np.array([b * np.cos(gamma), b * np.sin(gamma), 0.0])
    cx = c * np.cos(beta)
    cy = c * (np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma)
    cz = np.sqrt(max(0.0, c * c - cx * cx - cy * cy))
    return np.vstack([ax, bx, [cx, cy, cz]])


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("--maxiter", type=int, default=8)
args = parser.parse_args()

gpx = str(Path(args.input).resolve())
histograms, phases = IO.GetUsedHistogramsAndPhases(gpx)
name, histogram = next(iter(histograms.items()))
controls = dict(IO.GetControls(gpx))
controls.pop("PhasePartials", None)
rigid = IO.GetRigidBodies(gpx)
ids = rigid.get("RBIds", {"Vector": [], "Residue": []})
_, rigid_parameters = IO.GetRigidBodyModels(rigid, Print=False)
natoms, atom_index, _, phase_parameters, pawley, ff, ef, orb, bl, mf, maxss = IO.GetPhaseData(
    phases, {}, ids, Print=False
)
controls.update(atomIndx=atom_index, Natoms=natoms, FFtables=ff, EFtables=ef,
                ORBtables=orb, BLtables=bl, MFtables=mf, maxSSwave=maxss)
_, hap_parameters, extra = IO.GetHistogramPhaseData(phases, histograms, Controls=controls, Print=False)
controls.update(extra)
_, histogram_parameters, histogram_data, extra = IO.GetHistogramData(histograms, Print=False)
controls.update(extra)
parameters = {**rigid_parameters, **phase_parameters, **hap_parameters, **histogram_parameters}
IO.GetFprime(controls, histograms)

x = np.asarray(histogram["Data"][0], float)
observed = np.asarray(histogram["Data"][1], float)
weights = 1.0 / np.maximum(observed, 1.0)
denominator = float(np.sum(weights * observed**2))
matrix = lattice_matrix(SOURCE_CELL)
inverse_matrix = np.linalg.inv(matrix)

project = G2.G2Project(gpxfile=gpx)
phase = project.phase("WO3")
groups = {
    "W": [(index, atom) for index, atom in enumerate(phase.atoms()) if atom.element == "W"],
    "O": [(index, atom) for index, atom in enumerate(phase.atoms()) if atom.element == "O"],
}
directions = []
radii = []
for element, maximum in (("W", 0.04), ("O", 0.05)):
    cartesian = []
    for _, atom in groups[element]:
        delta = np.asarray(atom.coordinates, float) - SOURCE[atom.label]
        delta -= np.rint(delta)
        cartesian.extend(delta @ matrix)
    cartesian = np.asarray(cartesian)
    norm = np.linalg.norm(cartesian)
    radius = float(np.clip(norm / np.sqrt(len(groups[element])), 0.01, maximum))
    if norm == 0:
        cartesian[::3] = 1.0
        norm = np.linalg.norm(cartesian)
    directions.extend(cartesian / norm)
    radii.append(radius)
split = 3 * len(groups["W"])
initial = np.r_[directions, radii]


def decode(values: np.ndarray, element: str) -> np.ndarray:
    if element == "W":
        raw = values[:split]
        radius = values[-2]
    else:
        raw = values[split:-2]
        radius = values[-1]
    norm = np.linalg.norm(raw)
    if norm < 1e-12:
        raw = initial[:split] if element == "W" else initial[split:-2]
        norm = np.linalg.norm(raw)
    return raw.reshape(-1, 3) * (np.sqrt(len(groups[element])) * radius / norm)


def update_parameters(values: np.ndarray) -> None:
    for element in ("W", "O"):
        for (index, atom), displacement in zip(groups[element], decode(values, element)):
            coordinates = SOURCE[atom.label] + displacement @ inverse_matrix
            for axis, value in zip("xyz", coordinates):
                parameters[f"1::A{axis}:{index}"] = float(value)


calls = 0
best = [np.inf, None]


def objective(values: np.ndarray) -> float:
    global calls
    calls += 1
    update_parameters(values)
    signal, background = M.getPowderProfile(
        parameters, histogram_data, x, [], histogram, phases, controls, pawley, name
    )
    chi = float(np.sum(weights * (observed - signal - background) ** 2))
    if chi < best[0]:
        best[:] = [chi, values.copy()]
    if calls == 1 or calls % 30 == 0:
        print(f"call={calls} Rwp={100*np.sqrt(chi/denominator):.6f}% "
              f"W_RMS={values[-2]:.5f} O_RMS={values[-1]:.5f}", flush=True)
    return chi / denominator


bounds = [(-2.0, 2.0)] * (len(initial) - 2) + [(0.01, 0.04), (0.01, 0.05)]
result = minimize(objective, initial, method="L-BFGS-B", bounds=bounds,
                  options={"maxiter": args.maxiter, "ftol": 1e-13, "gtol": 1e-8,
                           "eps": 1e-5, "maxls": 20, "disp": True})
values = best[1] if best[1] is not None else result.x
for element in ("W", "O"):
    for (_, atom), displacement in zip(groups[element], decode(values, element)):
        atom.coordinates = SOURCE[atom.label] + displacement @ inverse_matrix
        atom.refinement_flags = atom.refinement_flags.replace("X", "")

output = Path(args.output)
output.parent.mkdir(parents=True, exist_ok=True)
project.save(str(output))
summary = {
    "success": bool(result.success), "message": str(result.message), "calls": calls,
    "best_chi_square": float(best[0]),
    "best_rwp_percent": float(100 * np.sqrt(best[0] / denominator)),
    "w_rms_A": float(values[-2]), "oxygen_rms_A": float(values[-1]),
    "w_cartesian_displacements_A": decode(values, "W").tolist(),
    "oxygen_cartesian_displacements_A": decode(values, "O").tolist(),
}
output.with_suffix(".json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
