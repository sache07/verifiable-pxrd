#!/usr/bin/env python3
"""Optimize generator-constrained ZnWO4 coordinates against a saved profile model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.optimize import minimize
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIstrIO as IO
from GSASII import GSASIIstrMath as M


PARENTS = {
    "9005254": ({
        "W1": (0.0000, 0.1821, 0.2500),
        "Zn1": (0.5000, 0.3142, 0.7500),
        "O1": (0.2570, 0.3615, 0.4040),
        "O2": (0.2140, 0.1100, -0.0670),
    }, (4.687, 5.726, 4.920, 90.0, 90.85, 90.0)),
    "1520642": ({
        "W1": (0.0000, 0.18172, 0.2500),
        "Zn1": (0.5000, 0.31410, 0.7500),
        "O1": (0.2537, 0.3739, 0.3983),
        "O2": (0.2137, 0.1042, -0.0608),
    }, (4.7472, 5.7670, 4.9629, 90.0, 90.862, 90.0)),
}


def lattice_matrix(cell: tuple[float, ...]) -> np.ndarray:
    a, b, c, alpha, beta, gamma = cell
    alpha, beta, gamma = np.deg2rad([alpha, beta, gamma])
    ax = np.array([a, 0.0, 0.0])
    bx = np.array([b * np.cos(gamma), b * np.sin(gamma), 0.0])
    cx = c * np.cos(beta)
    cy = c * (np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma)
    cz = np.sqrt(max(0.0, c * c - cx * cx - cy * cy))
    return np.vstack([ax, bx, [cx, cy, cz]])


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("--w-sign", type=int, choices=(-1, 1), default=-1)
parser.add_argument("--zn-sign", type=int, choices=(-1, 1), default=1)
parser.add_argument("--parent", choices=sorted(PARENTS), default="1520642")
parser.add_argument("--maxiter", type=int, default=80)
args = parser.parse_args()
source_raw, SOURCE_CELL = PARENTS[args.parent]
SOURCE = {label: np.asarray(coordinates, float) for label, coordinates in source_raw.items()}

gpx = str(Path(args.input).resolve())
histograms, phases = IO.GetUsedHistogramsAndPhases(gpx)
name, histogram = next(iter(histograms.items()))
controls = dict(IO.GetControls(gpx))
controls.pop("PhasePartials", None)
rigid = IO.GetRigidBodies(gpx)
ids = rigid.get("RBIds", {"Vector": [], "Residue": []})
_, rigid_parameters = IO.GetRigidBodyModels(rigid, Print=False)
natoms, atom_index, _, phase_parameters, pawley, ff, ef, orb, bl, mf, maxss = IO.GetPhaseData(
    phases, {}, ids, Print=False
)
controls.update(
    atomIndx=atom_index,
    Natoms=natoms,
    FFtables=ff,
    EFtables=ef,
    ORBtables=orb,
    BLtables=bl,
    MFtables=mf,
    maxSSwave=maxss,
)
_, hap_parameters, extra = IO.GetHistogramPhaseData(phases, histograms, Controls=controls, Print=False)
controls.update(extra)
_, histogram_parameters, histogram_data, extra = IO.GetHistogramData(histograms, Print=False)
controls.update(extra)
parameters = {**rigid_parameters, **phase_parameters, **hap_parameters, **histogram_parameters}
IO.GetFprime(controls, histograms)

x = np.asarray(histogram["Data"][0], float)
observed = np.asarray(histogram["Data"][1], float)
weights = 1.0 / np.maximum(observed, 1.0)
denominator = float(np.sum(weights * observed**2))
matrix = lattice_matrix(SOURCE_CELL)
inverse_matrix = np.linalg.inv(matrix)

project = G2.G2Project(gpxfile=gpx)
phase = project.phase("ZnWO4")
oxygen = [phase.atom("O1"), phase.atom("O2")]
initial_cartesian = []
for atom in oxygen:
    delta = np.asarray(atom.coordinates, float) - SOURCE[atom.label]
    delta -= np.rint(delta)
    initial_cartesian.extend(delta @ matrix)
initial_cartesian = np.asarray(initial_cartesian)
norm = np.linalg.norm(initial_cartesian)
initial_oxygen_rms = float(np.clip(norm / np.sqrt(2), 0.01, 0.05))
if norm == 0:
    initial_cartesian[:] = [1, 0, 0, 0, 1, 0]
else:
    initial_cartesian /= norm
heavy_distances = []
for label in ("W1", "Zn1"):
    delta = np.asarray(phase.atom(label).coordinates, float) - SOURCE[label]
    delta -= np.rint(delta)
    heavy_distances.append(abs(delta[1]) * SOURCE_CELL[1])
initial_heavy_rms = float(np.clip(np.mean(heavy_distances), 0.01, 0.04))
initial = np.r_[initial_cartesian, initial_heavy_rms, initial_oxygen_rms]

calls = 0
best = [np.inf, None]


def oxygen_cartesian(values: np.ndarray) -> np.ndarray:
    direction = values[:6]
    length = np.linalg.norm(direction)
    if length < 1e-12:
        direction = initial[:6]
        length = np.linalg.norm(direction)
    return direction.reshape(2, 3) * (np.sqrt(2) * values[7] / length)


def update_parameters(values: np.ndarray) -> None:
    cartesian = oxygen_cartesian(values)
    for index, (label, displacement) in enumerate(zip(("O1", "O2"), cartesian), start=2):
        coordinates = SOURCE[label] + displacement @ inverse_matrix
        for axis, value in zip("xyz", coordinates):
            parameters[f"0::A{axis}:{index}"] = float(value)
    target = float(values[6])
    parameters["0::Ay:0"] = SOURCE["W1"][1] + args.w_sign * target / SOURCE_CELL[1]
    parameters["0::Ay:1"] = SOURCE["Zn1"][1] + args.zn_sign * target / SOURCE_CELL[1]


def objective(values: np.ndarray) -> float:
    global calls
    calls += 1
    update_parameters(values)
    signal, background = M.getPowderProfile(
        parameters, histogram_data, x, [], histogram, phases, controls, pawley, name
    )
    calculated = signal + background
    chi = float(np.sum(weights * (observed - calculated) ** 2))
    if chi < best[0]:
        best[:] = [chi, values.copy()]
    if calls == 1 or calls % 25 == 0:
        rwp = 100 * np.sqrt(chi / denominator)
        oxygen_rms = np.linalg.norm(oxygen_cartesian(values)) / np.sqrt(2)
        print(f"call={calls} Rwp={rwp:.6f}% O_RMS={oxygen_rms:.5f} heavy_RMS={values[6]:.5f}", flush=True)
    # Scale the objective to a number of order unity so SLSQP's line search is
    # not dominated by the absolute count-space sum.
    return chi / denominator


bounds = [(-2.0, 2.0)] * 6 + [(0.01, 0.04), (0.01, 0.05)]
result = minimize(
    objective,
    initial,
    method="L-BFGS-B",
    bounds=bounds,
    options={"maxiter": args.maxiter, "ftol": 1e-14, "gtol": 1e-9, "eps": 1e-5,
             "maxls": 30, "disp": True},
)
values = best[1] if best[1] is not None else result.x
update_parameters(values)

cartesian = oxygen_cartesian(values)
for atom, displacement in zip(oxygen, cartesian):
    atom.coordinates = SOURCE[atom.label] + displacement @ inverse_matrix
    atom.refinement_flags = atom.refinement_flags.replace("X", "")
target = float(values[6])
for atom, sign in ((phase.atom("W1"), args.w_sign), (phase.atom("Zn1"), args.zn_sign)):
    coordinates = SOURCE[atom.label].copy()
    coordinates[1] += sign * target / SOURCE_CELL[1]
    atom.coordinates = coordinates
    atom.refinement_flags = atom.refinement_flags.replace("X", "")

output = Path(args.output)
output.parent.mkdir(parents=True, exist_ok=True)
project.save(str(output))
summary = {
    "success": bool(result.success),
    "message": str(result.message),
    "calls": calls,
    "best_chi_square": float(best[0]),
    "best_rwp_percent": float(100 * np.sqrt(best[0] / denominator)),
    "heavy_rms_A": target,
    "oxygen_rms_A": float(np.linalg.norm(cartesian) / np.sqrt(2)),
    "w_sign": args.w_sign,
    "zn_sign": args.zn_sign,
    "parent": args.parent,
    "oxygen_cartesian_displacements_A": cartesian.tolist(),
}
output.with_suffix(".json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
