#!/usr/bin/env python3
"""Build and refine exploratory GSAS-II powder models for this scan."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2


def write_observed(src: Path, dst: Path) -> tuple[np.ndarray, np.ndarray]:
    x, y = np.loadtxt(src, delimiter=",", skiprows=1).T
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(dst, np.column_stack([x, y, sigma]), fmt="%.8f %.8f %.8f")
    return x, y


def write_instrument(dst: Path) -> None:
    dst.write_text(
        "#GSAS-II instrument parameter file; Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.05;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def background_coefficients(x: np.ndarray, y: np.ndarray, number: int = 12) -> list[float]:
    # A low running percentile gives a stable starting baseline before the
    # crystallographic model is active. GSAS-II refines these coefficients.
    baseline = percentile_filter(y, percentile=12, size=401, mode="nearest")
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(t, baseline, number - 1).tolist()


def summarize(project: G2.G2Project, label: str) -> None:
    hist = project.histograms()[0]
    print(f"\n[{label}] residuals {hist.residuals}")
    print("instrument", {k: v[:2] for k, v in hist.InstrumentParameters.items()
                         if k in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.",
                                  "U", "V", "W", "X", "Y", "Z", "SH/L")})
    print("sample", {k: v for k, v in hist.SampleParameters.items()
                     if k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB",
                              "Gonio. radius", "Type")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(
            phase.name,
            "cell", phase.get_cell(),
            "scale", hap["Scale"],
            "size", hap["Size"][:4],
            "mustrain", hap["Mustrain"][:4],
            "pref", hap["Pref.Ori."][:4],
        )


def refine(project: G2.G2Project, label: str) -> None:
    project.set_Controls("cycles", 8)
    project.refine()
    summarize(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tag", required=True)
    parser.add_argument("--phase", action="append", required=True,
                        help="phase specification NAME=PATH (repeatable)")
    parser.add_argument("--atoms", action="store_true",
                        help="finish with restrained-by-symmetry coordinate refinement")
    parser.add_argument("--atom-phase", action="append", default=[],
                        help="phase name whose coordinates and Uiso values should be refined")
    parser.add_argument("--texture", action="append", default=[],
                        help="March-Dollase refinement NAME=h,k,l (repeatable)")
    parser.add_argument("--roughness", action="store_true",
                        help="refine Bragg-Brentano surface roughness")
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[1]
    run = root / "analysis" / "runs" / args.tag
    run.mkdir(parents=True, exist_ok=True)
    observed = run / "observed.xye"
    instrument = run / "instrument.instprm"
    x, y = write_observed(root / "inputs" / "pattern.csv", observed)
    write_instrument(instrument)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(run / "model.gpx"))
    phases = []
    for spec in args.phase:
        name, path = spec.split("=", 1)
        source = Path(path)
        if not source.is_absolute():
            source = root / source
        phases.append(project.add_phase(str(source), phasename=name, fmthint="CIF"))
    hist = project.add_powder_histogram(
        str(observed), str(instrument), phases="all", fmthint="xye"
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    coeffs = background_coefficients(x, y)
    hist.set_refinements({
        "Limits": [float(x[0]), float(x[-1])],
        "Background": {
            "type": "chebyschev-1", "no. coeffs": len(coeffs),
            "coeffs": coeffs, "refine": True,
        },
    })
    for i, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0 / max(1, len(phases)), True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        # Keep all imported/reference ADPs in a physically sensible range.
        for atom in phase.atoms():
            if atom.adp_flag != "I":
                atom.data[atom.cia] = "I"
                atom.data[atom.cia + 1] = 0.01
            else:
                atom.uiso = 0.01

    # Keep all profile/specimen parameters in physical ranges. Wildcards are
    # accepted by GSAS-II's parameter-limit controls.
    project.set_Controls("parmMin", 0.0, variable=":*:W")
    project.set_Controls("parmMax", 50.0, variable=":*:W")
    project.set_Controls("parmMin", 0.001, variable=":*:SH/L")
    project.set_Controls("parmMax", 0.2, variable=":*:SH/L")
    project.set_Controls("parmMin", -0.35, variable=":*:Zero")
    project.set_Controls("parmMax", 0.35, variable=":*:Zero")
    project.set_Controls("parmMin", -1000.0, variable=":*:Shift")
    project.set_Controls("parmMax", 1000.0, variable=":*:Shift")
    project.set_Controls("parmMin", 0.02, variable="*:*:Size;i")
    project.set_Controls("parmMax", 20.0, variable="*:*:Size;i")
    project.set_Controls("parmMin", 0.0, variable="*:*:Mustrain;i")
    project.set_Controls("parmMax", 15000.0, variable="*:*:Mustrain;i")

    # Staged refinement keeps the initial profile and lattice problem well conditioned.
    refine(project, "scale-background")
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "cells-zero")
    # Instrument U vs phase microstrain and instrument X vs phase size are
    # additive degeneracies. Keep U and X at physical reference values and
    # let the phase-specific broadening terms carry the observable totals.
    hist.set_refinements({"Instrument Parameters": ["W", "SH/L"]})
    for phase in phases:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 0.5, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    refine(project, "profile")
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "shift")

    for spec in args.texture:
        name, vector = spec.split("=", 1)
        phase = project.phase(name)
        axis = [int(v) for v in vector.split(",")]
        if len(axis) != 3:
            raise ValueError("texture axis must contain three integers")
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = axis
        phase.set_HAP_refinements({"Pref.Ori.": True})
        project.set_Controls("parmMin", 0.5, variable=f"{phase.id}:*:MD")
        project.set_Controls("parmMax", 2.0, variable=f"{phase.id}:*:MD")
    if args.texture:
        refine(project, "texture")

    if args.roughness:
        hist.data["Sample Parameters"]["SurfRoughA"] = [0.2, False]
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.1, False]
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        project.set_Controls("parmMin", 0.001, variable=":*:SurfRoughA")
        project.set_Controls("parmMax", 1.0, variable=":*:SurfRoughA")
        project.set_Controls("parmMin", 0.001, variable=":*:SurfRoughB")
        project.set_Controls("parmMax", 1.0, variable=":*:SurfRoughB")
        refine(project, "roughness")

    if args.atoms or args.atom_phase:
        selected = phases if args.atoms else [project.phase(name) for name in args.atom_phase]
        for phase in selected:
            phase.set_refinements({"Atoms": {"all": "XU"}})
        refine(project, "atoms")

    project.save(str(run / "model.gpx"))
    arrays = hist.data["data"][1]
    calc = np.asarray(arrays[3], float)
    export = np.column_stack([x, y, calc, y - calc])
    np.savetxt(run / "fit.csv", export, delimiter=",",
               header="two_theta_deg,observed,calculated,difference", comments="",
               fmt=["%.8f", "%.8f", "%.8f", "%.8f"])
    fractions = hist.ComputeMassFracs()
    summary = {
        "histogram": hist.name,
        "residuals": hist.residuals,
        "phases": {},
    }
    for phase in phases:
        phase.export_CIF(str(run / f"{phase.name}.cif"))
        summary["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "composition": phase.composition,
            "weight_fraction": fractions.get(phase.name),
        }
    (run / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    summarize(project, "final")


if __name__ == "__main__":
    main()
