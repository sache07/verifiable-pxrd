#!/usr/bin/env python3
"""Export the currently stored GSAS-II profile arrays for diagnosis."""

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("project")
parser.add_argument("output")
args = parser.parse_args()

project = G2.G2Project(gpxfile=args.project)
hist = project.histograms()[0]
x, obs, _weight, calc, background, diff = hist.data["data"][1][:6]
np.savetxt(
    Path(args.output),
    np.column_stack([x, obs, calc, background, obs - calc]),
    delimiter=",",
    header="two_theta_deg,observed,calculated,background,difference",
    comments="",
    fmt="%.8f",
)
