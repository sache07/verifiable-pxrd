#!/usr/bin/env python3
"""Continue a staged GSAS-II refinement from an existing project."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def show(project: G2.G2Project, label: str) -> None:
    hist = project.histograms()[0]
    print(f"[{label}]", hist.residuals)
    print("instrument", {k: v[:2] for k, v in hist.InstrumentParameters.items()
                         if k in ("Zero", "Polariz.", "U", "W", "X", "SH/L")})
    print("sample", {k: v for k, v in hist.SampleParameters.items()
                     if k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"][:4], "strain", hap["Mustrain"][:4],
              "texture", hap["Pref.Ori."][:4])


def run_refinement(project: G2.G2Project, label: str, cycles: int) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    show(project, label)


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("--atom-phase", action="append", default=[])
parser.add_argument("--atom-flags", default="X")
parser.add_argument("--atom-element", action="append", default=[], help="PHASE=ELEMENT")
parser.add_argument("--fix-coordinate-phase", action="append", default=[])
parser.add_argument("--set-atom", action="append", default=[],
                    help="PHASE:LABEL=x,y,z before refinement")
parser.add_argument("--coordinate-limit", type=float,
                    help="absolute limit on each refined fractional-coordinate shift")
parser.add_argument("--coordinate-passes", type=int, default=1,
                    help="repeat coordinate refinement with bounds recentered after each pass")
parser.add_argument("--coordinate-cycles", type=int, default=4)
parser.add_argument("--uiso-phase", action="append", default=[],
                    help="phase with one constrained isotropic U value")
parser.add_argument("--set-uiso", action="append", default=[], help="PHASE=value in A^2")
parser.add_argument("--fix-uiso-phase", action="append", default=[])
parser.add_argument("--add-phase", action="append", default=[], help="NAME=PATH")
parser.add_argument("--uniaxial", action="append", default=[], help="NAME=h,k,l")
parser.add_argument("--texture", action="append", default=[], help="NAME=h,k,l")
parser.add_argument("--roughness", action="store_true")
parser.add_argument("--set-roughness", help="A,B")
parser.add_argument("--fix-roughness", action="store_true")
parser.add_argument("--roughness-min-a", type=float, default=0.001)
parser.add_argument("--roughness-min-b", type=float, default=0.001)
parser.add_argument("--polarization", action="store_true")
parser.add_argument("--set-polarization", type=float)
parser.add_argument("--fix-polarization", action="store_true")
parser.add_argument("--set-zero", type=float)
parser.add_argument("--fix-zero", action="store_true")
parser.add_argument("--reset-wo3-size", type=float)
parser.add_argument("--set-size", action="append", default=[], help="NAME=micrometres")
parser.add_argument("--fix-size-phase", action="append", default=[])
parser.add_argument("--refine-size-phase", action="append", default=[])
parser.add_argument("--set-strain", action="append", default=[], help="NAME=ppm")
parser.add_argument("--fix-strain-phase", action="append", default=[])
parser.add_argument("--refine-strain-phase", action="append", default=[])
parser.add_argument("--set-shl", type=float)
parser.add_argument("--fix-shl", action="store_true")
parser.add_argument("--cycles", type=int, default=12)
args = parser.parse_args()

out = Path(args.output)
out.mkdir(parents=True, exist_ok=True)
source = G2.G2Project(gpxfile=args.input)
source.save(str(out / "model.gpx"))
project = G2.G2Project(gpxfile=str(out / "model.gpx"))
hist = project.histograms()[0]
for spec in args.add_phase:
    name, filename = spec.split("=", 1)
    phase = project.add_phase(filename, phasename=name, histograms=[hist], fmthint="CIF")
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.3
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 500.0
    phase.set_refinements({"Cell": True})
    phase.set_HAP_refinements({
        "Scale": True,
        "Size": {"type": "isotropic", "value": 0.3, "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    })
    for atom in phase.atoms():
        if atom.adp_flag == "I":
            atom.uiso = 0.01
project.update_ids()
hid = hist.id
hist.data["Sample Parameters"]["Scale"] = [1.0, False]

for spec in args.set_atom:
    target, values = spec.split("=", 1)
    phase_name, label = target.split(":", 1)
    atom = project.phase(phase_name).atom(label)
    if atom is None:
        raise ValueError(f"atom not found: {phase_name}:{label}")
    atom.coordinates = [float(value) for value in values.split(",")]

for phase in project.phases():
    pid = phase.id
    project.set_Controls("parmMin", 0.04, variable=f"{pid}:{hid}:Size;i")
    project.set_Controls("parmMax", 20.0, variable=f"{pid}:{hid}:Size;i")
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;i")
    project.set_Controls("parmMax", 15000.0, variable=f"{pid}:{hid}:Mustrain;i")
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;a")
    project.set_Controls("parmMax", 15000.0, variable=f"{pid}:{hid}:Mustrain;a")
    project.set_Controls("parmMin", 0.5, variable=f"{pid}:{hid}:MD")
    project.set_Controls("parmMax", 2.0, variable=f"{pid}:{hid}:MD")

if args.reset_wo3_size is not None:
    phase = project.phase("WO3")
    phase.data["Histograms"][hist.name]["Size"][1][0] = args.reset_wo3_size
for spec in args.set_size:
    name, value = spec.split("=", 1)
    phase = project.phase(name)
    phase.data["Histograms"][hist.name]["Size"][1][0] = float(value)
    project.set_Frozen(variable=f"{phase.id}:{hid}:Size;i", mode="remove")
for name in args.fix_size_phase:
    project.phase(name).clear_HAP_refinements({"Size": True})
for name in args.refine_size_phase:
    project.phase(name).set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True}
    })
for spec in args.set_strain:
    name, value = spec.split("=", 1)
    phase = project.phase(name)
    phase.data["Histograms"][hist.name]["Mustrain"][1][0] = float(value)
    project.set_Frozen(variable=f"{phase.id}:{hid}:Mustrain;i", mode="remove")
for name in args.fix_strain_phase:
    project.phase(name).clear_HAP_refinements({"Mustrain": True})
for name in args.refine_strain_phase:
    project.phase(name).set_HAP_refinements({
        "Mustrain": {"type": "isotropic", "refine": True}
    })
if args.set_shl is not None:
    hist.InstrumentParameters["SH/L"][1] = float(args.set_shl)
    project.set_Frozen(variable=f":{hid}:SH/L", mode="remove")
if args.fix_shl:
    hist.clear_refinements({"Instrument Parameters": ["SH/L"]})

for spec in args.uniaxial:
    name, vector = spec.split("=", 1)
    phase = project.phase(name)
    axis = [int(v) for v in vector.split(",")]
    hap = phase.data["Histograms"][hist.name]
    old = float(hap["Mustrain"][1][0])
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = old
    hap["Mustrain"][1][1] = old
    hap["Mustrain"][3] = axis
    phase.set_HAP_refinements({
        "Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}
    })

for spec in args.texture:
    name, vector = spec.split("=", 1)
    phase = project.phase(name)
    axis = [int(v) for v in vector.split(",")]
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][3] = axis
    phase.set_HAP_refinements({"Pref.Ori.": True})

limited_atoms = []
for name in args.fix_coordinate_phase:
    for atom in project.phase(name).atoms():
        atom.refinement_flags = atom.refinement_flags.replace("X", "")
for name in args.atom_phase:
    phase = project.phase(name)
    phase.set_refinements({"Atoms": {"all": args.atom_flags}})
    limited_atoms.extend((phase, i) for i, _atom in enumerate(phase.atoms()))
for spec in args.atom_element:
    name, element = spec.split("=", 1)
    phase = project.phase(name)
    selected = {atom.label: args.atom_flags for atom in phase.atoms()
                if atom.element == element}
    phase.set_refinements({"Atoms": selected})
    limited_atoms.extend((phase, i) for i, atom in enumerate(phase.atoms())
                         if atom.element == element)
if args.coordinate_limit is not None:
    limit = abs(args.coordinate_limit)
    for phase, index in limited_atoms:
        coordinates = phase.atoms()[index].coordinates
        for axis, center in zip("xyz", coordinates):
            variable = f"{phase.id}::dA{axis}:{index}"
            project.set_Frozen(variable=variable, mode="remove")
            project.set_Controls("parmMin", float(center) - limit, variable=variable)
            project.set_Controls("parmMax", float(center) + limit, variable=variable)
for name in args.uiso_phase:
    phase = project.phase(name)
    variables = []
    for index, atom in enumerate(phase.atoms()):
        if atom.adp_flag != "I":
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = 0.01
        atom.refinement_flags = "".join(sorted(set(atom.refinement_flags + "U")))
        variable = f"{phase.id}::AUiso:{index}"
        variables.append(variable)
        project.set_Controls("parmMin", 0.001, variable=variable)
        project.set_Controls("parmMax", 0.03, variable=variable)
    if len(variables) > 1:
        project.add_EquivConstr(tuple(variables), override=True)

for spec in args.set_uiso:
    name, value = spec.split("=", 1)
    phase = project.phase(name)
    for index, atom in enumerate(phase.atoms()):
        atom.uiso = float(value)
        project.set_Frozen(variable=f"{phase.id}::AUiso:{index}", mode="remove")
for name in args.fix_uiso_phase:
    for atom in project.phase(name).atoms():
        atom.refinement_flags = atom.refinement_flags.replace("U", "")

if args.roughness:
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.2, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.1, False]
    hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    project.set_Controls("parmMin", args.roughness_min_a, variable=f":{hid}:SurfRoughA")
    project.set_Controls("parmMax", 1.0, variable=f":{hid}:SurfRoughA")
    project.set_Controls("parmMin", args.roughness_min_b, variable=f":{hid}:SurfRoughB")
    project.set_Controls("parmMax", 1.0, variable=f":{hid}:SurfRoughB")

if args.set_roughness:
    rough_a, rough_b = (float(value) for value in args.set_roughness.split(","))
    hist.data["Sample Parameters"]["SurfRoughA"][0] = rough_a
    hist.data["Sample Parameters"]["SurfRoughB"][0] = rough_b
    project.set_Frozen(variable=f":{hid}:SurfRoughA", mode="remove")
    project.set_Frozen(variable=f":{hid}:SurfRoughB", mode="remove")
if args.fix_roughness:
    hist.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})

if args.polarization:
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Controls("parmMin", 0.5, variable=f":{hid}:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=f":{hid}:Polariz.")

if args.set_polarization is not None:
    hist.InstrumentParameters["Polariz."][1] = args.set_polarization
    project.set_Frozen(variable=f":{hid}:Polariz.", mode="remove")
if args.fix_polarization:
    hist.clear_refinements({"Instrument Parameters": ["Polariz."]})
if args.set_zero is not None:
    hist.InstrumentParameters["Zero"][1] = args.set_zero
    project.set_Frozen(variable=f":{hid}:Zero", mode="remove")
if args.fix_zero:
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})

if args.coordinate_passes > 1:
    if args.coordinate_limit is None or not limited_atoms:
        raise ValueError("coordinate passes require coordinate-limited atoms")
    for pass_index in range(args.coordinate_passes):
        limit = abs(args.coordinate_limit)
        for phase, index in limited_atoms:
            coordinates = phase.atoms()[index].coordinates
            for axis, center in zip("xyz", coordinates):
                variable = f"{phase.id}::dA{axis}:{index}"
                project.set_Frozen(variable=variable, mode="remove")
                project.set_Controls("parmMin", float(center) - limit, variable=variable)
                project.set_Controls("parmMax", float(center) + limit, variable=variable)
        run_refinement(project, f"coordinate-pass-{pass_index + 1}", args.coordinate_cycles)
        shutil.copy2(out / "model.gpx", out / f"model_pass_{pass_index + 1:02d}.gpx")
else:
    run_refinement(project, "continued", args.cycles)
project.save(str(out / "model.gpx"))

x, obs, _weight, calc, background, _diff = hist.data["data"][1][:6]
np.savetxt(out / "fit.csv", np.column_stack([x, obs, calc, background, obs - calc]),
           delimiter=",", header="two_theta_deg,observed,calculated,background,difference",
           comments="", fmt="%.8f")
try:
    fractions = hist.ComputeMassFracs()
except Exception as exc:
    fractions = {"error": str(exc)}
summary = {"histogram": hist.name, "residuals": hist.residuals, "fractions": fractions,
           "phases": {}}
for phase in project.phases():
    phase.export_CIF(str(out / f"{phase.name}.cif"))
    summary["phases"][phase.name] = {
        "cell": phase.get_cell(), "composition": phase.composition,
        "atoms": [{"label": a.label, "element": a.element, "coordinates": list(a.coordinates),
                   "occupancy": a.occupancy, "adp": a.ADP}
                  for a in phase.atoms()],
    }
(out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
