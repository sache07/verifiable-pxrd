#!/usr/bin/env python3
"""Export CIFs and the replayed full-grid profile from the frozen final GPX."""

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


root = Path(__file__).resolve().parents[1]
project = G2.G2Project(gpxfile=str(root / "final.gpx"))
histogram = project.histograms()[0]
fractions = histogram.ComputeMassFracs()
residuals = histogram.residuals
# Export the saved phase records, without applying any possibly stale values
# retained in the post-refinement covariance block.
project.data["Covariance"]["data"] = {}
for phase in project.phases():
    phase.export_CIF(str(root / f"{phase.name}.cif"))

profile = np.load(root / "analysis/replay_final/prediction.npz")
x = profile["x"]
observed = profile["observed"]
calculated = profile["predicted"]
background = profile["background"]
np.savetxt(
    root / "fit.csv",
    np.column_stack([x, observed, calculated, background, observed - calculated]),
    delimiter=",",
    header="two_theta,observed,calculated,background,difference",
    comments="",
    fmt="%.8f",
)

print("histogram", histogram.name)
print("fractions", fractions)
print("residuals", residuals)
