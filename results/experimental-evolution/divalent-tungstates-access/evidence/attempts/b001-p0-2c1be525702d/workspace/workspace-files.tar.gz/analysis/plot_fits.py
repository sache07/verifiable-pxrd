#!/usr/bin/env python3
"""Plot observed, calculated and difference curves from exported fits."""

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


parser = argparse.ArgumentParser()
parser.add_argument("output")
parser.add_argument("fits", nargs="+")
parser.add_argument("--xmin", type=float)
parser.add_argument("--xmax", type=float)
args = parser.parse_args()

fig, axes = plt.subplots(len(args.fits), 1, figsize=(14, 4.1 * len(args.fits)), sharex=True)
axes = np.atleast_1d(axes)
for ax, filename in zip(axes, args.fits):
    data = np.genfromtxt(filename, delimiter=",", names=True)
    names = data.dtype.names
    x = data[names[0]]
    obs = data[names[1]]
    calc = data[names[2]]
    diff = data[names[-1]]
    ax.plot(x, obs, color="black", lw=0.55, label="observed")
    ax.plot(x, calc, color="crimson", lw=0.75, label="calculated")
    ax.plot(x, diff - 0.12 * np.nanmax(obs), color="royalblue", lw=0.55, label="difference (offset)")
    ax.set_ylabel("Counts")
    ax.set_title(Path(filename).parent.name)
    ax.legend(loc="upper right", ncol=3, frameon=False)
    if args.xmin is not None or args.xmax is not None:
        ax.set_xlim(args.xmin, args.xmax)
axes[-1].set_xlabel(r"$2\theta$ (deg)")
fig.tight_layout()
fig.savefig(args.output, dpi=170)
