#!/usr/bin/env python3
"""Add one candidate to a fixed GSAS-II checkpoint and refine its scale only."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("name")
    parser.add_argument("cif", type=Path)
    args = parser.parse_args()

    project = G2.G2Project(
        gpxfile=str(args.base.resolve()), newgpx=str(args.output.resolve())
    )
    hist = project.histogram(0)
    before = hist.get_wR()

    hist.clear_refinements({"Background": True})
    hist.clear_refinements(
        {"Instrument Parameters": list(hist.InstrumentParameters.keys())}
    )
    sample_flags = [
        key
        for key, value in hist.SampleParameters.items()
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool)
    ]
    hist.clear_refinements({"Sample Parameters": sample_flags})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "HStrain": True,
                "Pref.Ori.": True,
                "Extinction": True,
            }
        )

    phase = project.add_phase(
        str(args.cif.resolve()),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    project.index_ids()
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.3
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
    project.set_Controls("parmMax", 2000.0, variable=f"{phase.id}:0:Scale")
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 8)
    project.save()
    project.refine(makeBack=False)

    hist = project.histogram(0)
    phase = project.phase(args.name)
    hap = phase.data["Histograms"][hist.name]
    record = {
        "candidate": args.name,
        "cif": str(args.cif.resolve()),
        "rwp_before_percent": None if before is None else float(before),
        "rwp_scale_only_percent": float(hist.get_wR()),
        "scale": float(hap["Scale"][0]),
        "cell_mass": float(phase.data["General"]["Mass"]),
        "cell": phase.get_cell(),
        "convergence": project.data.get("Covariance", {}).get("data", {}).get(
            "Rvals", {}
        ),
    }
    args.output.with_suffix(".screen.json").write_text(
        json.dumps(record, indent=2, default=str) + "\n"
    )
    project.save()
    print(json.dumps(record, indent=2, default=str))


if __name__ == "__main__":
    main()
