#!/usr/bin/env python3
"""Export all requested deliverables from the independently replayed final GPX."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PROJECT_PATH = ROOT / "final.gpx"
REPLAY_DIR = ROOT / ".tmp" / "replay_audit" / "final"
REPLAY_REPORT = REPLAY_DIR / "replay.json"
REPLAY_PROFILE = REPLAY_DIR / "prediction.npz"

FORMULAS = {
    "MnWO4": "MnWO4",
    "WO3": "WO3",
    "Mn3WO6": "Mn3WO6",
}

MODEL_BASIS = {
    "MnWO4": "published reference (COD 1520200)",
    "WO3": "published reference (COD 2311041)",
    "Mn3WO6": "analogue-derived R-3 model from Mn3TeO6 (COD 2211528; Te6+ -> W6+)",
}


def project_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def safe_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", name)


def main() -> None:
    replay = json.loads(REPLAY_REPORT.read_text())
    if replay.get("status") != "replayed":
        raise RuntimeError("final project has not passed independent replay")
    digest = project_sha256(PROJECT_PATH)
    if replay.get("project_sha256") != digest:
        raise RuntimeError("independent replay does not match the current final.gpx")

    profile = np.load(REPLAY_PROFILE)
    x = np.asarray(profile["x"], dtype=float)
    observed = np.asarray(profile["observed"], dtype=float)
    calculated = np.asarray(profile["predicted"], dtype=float)
    background = np.asarray(profile["background"], dtype=float)
    difference = observed - calculated
    weights = 1.0 / np.maximum(observed, 1.0)
    weighted_residual = float(np.sum(weights * difference**2))
    weighted_denominator = float(np.sum(weights * observed**2))
    rwp = 100.0 * np.sqrt(weighted_residual / weighted_denominator)
    rp = 100.0 * float(np.sum(np.abs(difference)) / np.sum(np.abs(observed)))

    project = G2.G2Project(gpxfile=str(PROJECT_PATH))
    histograms = project.histograms()
    if len(histograms) != 1 or histograms[0].name != replay["histogram"]:
        raise RuntimeError("unexpected refinement histogram")
    histogram = histograms[0]
    phases = project.phases()
    replay_phases = replay["phases"]
    if [phase.name for phase in phases] != [phase["name"] for phase in replay_phases]:
        raise RuntimeError("phase order differs between project and replay")

    # Export the full-precision saved phase objects. Clearing covariance only in
    # memory prevents the CIF writer from substituting stale least-squares values.
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = dict(covariance.get("Rvals", {}))
    project.data["Covariance"]["data"] = {}

    phase_rows = []
    for phase, replay_phase in zip(phases, replay_phases):
        filename = f"phase_{safe_name(phase.name)}.cif"
        phase.export_CIF(str(ROOT / filename), quickmode=True)
        cell = phase.get_cell()
        phase_rows.append(
            {
                "name": phase.name,
                "formula": FORMULAS.get(phase.name, phase.name),
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": filename,
                "weight_fraction": float(replay_phase["weight_fraction"]),
                "model_basis": MODEL_BASIS.get(phase.name, "refined atomic model"),
                "cell": {
                    "a_A": float(cell["length_a"]),
                    "b_A": float(cell["length_b"]),
                    "c_A": float(cell["length_c"]),
                    "alpha_deg": float(cell["angle_alpha"]),
                    "beta_deg": float(cell["angle_beta"]),
                    "gamma_deg": float(cell["angle_gamma"]),
                    "volume_A3": float(cell["volume"]),
                },
            }
        )

    fraction_sum = sum(row["weight_fraction"] for row in phase_rows)
    if abs(fraction_sum - 1.0) > 1e-10:
        raise RuntimeError("replayed crystalline phase fractions are not normalized")

    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, observed, calculated, difference, background]),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt="%.10f",
    )

    instrument = histogram.InstrumentParameters
    sample = histogram.SampleParameters
    result = {
        "project_path": "final.gpx",
        "project_sha256": digest,
        "refinement_histogram": histogram.name,
        "fraction_basis": "normalized over the modeled crystalline phases; no amorphous fraction determined",
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": float(rwp),
            "Rp_percent": float(rp),
            "weighted_chi_square": weighted_residual,
            "GSAS_goodness_of_fit": float(rvals["GOF"]) if "GOF" in rvals else None,
            "data_points": int(len(x)),
            "weighting": "1/max(observed_count, 1)",
            "calculated_profile_source": "independent native-GSAS replay of final.gpx on the full original grid",
        },
        "calibration": {
            "zero_deg": float(instrument["Zero"][1]),
            "sample_displacement_micrometers": float(sample["Shift"][0]),
            "goniometer_radius_mm": float(sample["Gonio. radius"]),
            "polarization": float(instrument["Polariz."][1]),
        },
        "measurement": {
            "radiation": "Cu K-alpha doublet",
            "wavelength_Kalpha1_A": float(instrument["Lam1"][1]),
            "wavelength_Kalpha2_A": float(instrument["Lam2"][1]),
            "Kalpha2_to_Kalpha1_ratio": float(instrument["I(L2)/I(L1)"][1]),
        },
        "verification": {
            "status": replay["status"],
            "parameters_optimized_during_replay": int(replay["parameters_optimized"]),
            "project_unchanged_during_replay": bool(replay["project_unchanged"]),
            "profile_review_flags": replay["profile_review_flags"],
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
