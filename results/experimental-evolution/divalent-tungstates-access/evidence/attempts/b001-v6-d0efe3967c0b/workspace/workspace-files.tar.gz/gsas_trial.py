#!/usr/bin/env python3
"""Build and stage a trial Rietveld fit for candidate phase inventories."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def phase_spec(text: str) -> tuple[str, Path]:
    name, sep, path = text.partition("=")
    if not sep:
        path = text
        name = Path(text).stem
    return name, Path(path).resolve()


def rwp(project: G2.G2Project) -> float | None:
    value = project.histogram(0).get_wR()
    return None if value is None else float(value)


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    result = {
        "label": label,
        "rwp_percent": rwp(project),
        "instrument": {
            key: float(value[1])
            for key, value in hist.InstrumentParameters.items()
            if isinstance(value, list)
            and len(value) > 1
            and isinstance(value[1], (int, float))
        },
        "sample": {
            key: float(value[0])
            for key, value in hist.SampleParameters.items()
            if isinstance(value, list)
            and value
            and isinstance(value[0], (int, float))
        },
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "mass": float(phase.data["General"]["Mass"]),
                "scale": float(hap["Scale"][0]),
                "size": copy.deepcopy(hap["Size"]),
                "mustrain": copy.deepcopy(hap["Mustrain"]),
                "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
            }
        )
    return result


def refine(project: G2.G2Project, label: str, history: list[dict]) -> None:
    project.refine(makeBack=False)
    record = state(project, label)
    history.append(record)
    print(label, "Rwp", record["rwp_percent"])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phases", nargs="+", type=phase_spec)
    parser.add_argument("--full", action="store_true")
    parser.add_argument("--no-phase-profile", action="store_true")
    args = parser.parse_args()

    output = args.output.resolve()
    project = G2.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(Path("inputs/pattern.csv").resolve()),
        str(Path("instrument.instprm").resolve()),
        fmthint="comma",
    )
    phases = [
        project.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
        for name, path in args.phases
    ]
    project.index_ids()

    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"][1] = False
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [1450.0, -100.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": False,
            }
        }
    )
    total_mass_scale = 10000.0
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"])
        hap["Scale"] = [total_mass_scale / len(phases) / mass, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
        project.set_Controls("parmMax", 2000.0, variable=f"{phase.id}:0:Scale")
        project.set_Controls("parmMin", 0.02, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 5.0, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 20000.0, variable=f"{phase.id}:0:Mustrain;i")
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A(
            [
                cell["length_a"],
                cell["length_b"],
                cell["length_c"],
                cell["angle_alpha"],
                cell["angle_beta"],
                cell["angle_gamma"],
            ]
        )
        for index, value in enumerate(reciprocal):
            span = max(0.03 * abs(float(value)), 0.0005)
            project.set_Controls(
                "parmMin", float(value) - span, variable=f"{phase.id}::A{index}"
            )
            project.set_Controls(
                "parmMax", float(value) + span, variable=f"{phase.id}::A{index}"
            )

    for variable, lower, upper in [
        (":0:Zero", -1.0, 1.0),
        (":0:U", 0.0, 80.0),
        (":0:W", 0.1, 80.0),
        (":0:X", 0.01, 12.0),
        (":0:SH/L", 0.001, 0.2),
        (":0:Polariz.", 0.0, 1.0),
        (":0:Shift", -1000.0, 1000.0),
    ]:
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    project.set_Controls("cycles", 8)
    project.save()

    history: list[dict] = []
    project.set_Controls("cycles", 0)
    refine(project, "calculation", history)
    project.set_Controls("cycles", 8)

    hist.set_refinements({"Background": True})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    refine(project, "background_scales", history)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "zero", history)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "cells", history)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, "instrument_profile", history)

    if not args.no_phase_profile:
        for phase in phases:
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True},
                }
            )
        refine(project, "phase_profiles", history)

    if args.full:
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        refine(project, "sample_shift", history)
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        refine(project, "polarization", history)

    project.save()
    output.with_suffix(".trial.json").write_text(
        json.dumps(history, indent=2, default=str) + "\n"
    )
    arrays = np.column_stack(
        [
            hist.getdata("X"),
            hist.getdata("Yobs"),
            hist.getdata("Ycalc"),
            hist.getdata("Background"),
            hist.getdata("Residual"),
        ]
    )
    np.savetxt(
        output.with_suffix(".trial.csv"),
        arrays,
        delimiter=",",
        header="two_theta,observed,calculated,background,difference",
        comments="",
    )


if __name__ == "__main__":
    main()
