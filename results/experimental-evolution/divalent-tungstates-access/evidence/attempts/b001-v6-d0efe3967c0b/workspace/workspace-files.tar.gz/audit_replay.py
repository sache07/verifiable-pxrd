#!/usr/bin/env python3
"""Independently replay candidate GSAS-II projects on the original grid."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
import json
from pathlib import Path
import subprocess
import sys

import numpy as np


ROOT = Path(__file__).resolve().parent
OBSERVED = ROOT / "inputs" / "pattern.csv"
WORKER = ROOT / "learned" / "divalent-tungstates" / "scorer" / "runtime" / "replay_worker.py"
AUDIT_ROOT = ROOT / ".tmp" / "replay_audit"


def replay(project: Path) -> dict:
    work = AUDIT_ROOT / project.stem
    work.mkdir(parents=True, exist_ok=True)
    request = {
        "project": str(project.resolve()),
        "observed": str(OBSERVED.resolve()),
    }
    request_path = work / "request.json"
    request_path.write_text(json.dumps(request) + "\n")
    completed = subprocess.run(
        [sys.executable, str(WORKER), str(request_path)],
        cwd=work,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=90,
        check=False,
    )
    report_path = work / "replay.json"
    if not report_path.exists():
        return {
            "project": project.name,
            "status": "worker_failed",
            "returncode": completed.returncode,
            "log": completed.stdout[-2000:],
        }
    report = json.loads(report_path.read_text())
    result = {
        "project": project.name,
        "status": report.get("status"),
        "phases": report.get("phases", []),
        "profile_review_flags": report.get("profile_review_flags", []),
    }
    prediction_path = work / "prediction.npz"
    if report.get("status") == "replayed" and prediction_path.exists():
        data = np.load(prediction_path)
        observed = data["observed"]
        calculated = data["predicted"]
        weights = 1.0 / np.maximum(observed, 1.0)
        result["replay_Rwp_percent"] = float(
            100.0
            * np.sqrt(
                np.sum(weights * (observed - calculated) ** 2)
                / np.sum(weights * observed**2)
            )
        )
    else:
        result["error"] = report.get("error")
    return result


def main() -> None:
    excluded_prefixes = ("branch_",)
    excluded_names = {"final.gpx", "polished.gpx"}
    if len(sys.argv) > 1:
        projects = [Path(name).resolve() for name in sys.argv[1:]]
    else:
        projects = sorted(
            path
            for path in ROOT.glob("*.gpx")
            if path.name not in excluded_names
            and not path.name.startswith(excluded_prefixes)
        )
    AUDIT_ROOT.mkdir(parents=True, exist_ok=True)
    results = []
    with ThreadPoolExecutor(max_workers=6) as pool:
        futures = {pool.submit(replay, path): path for path in projects}
        for future in as_completed(futures):
            result = future.result()
            results.append(result)
            print(
                result["project"],
                result["status"],
                result.get("replay_Rwp_percent"),
                flush=True,
            )
    results.sort(key=lambda row: (row.get("replay_Rwp_percent", 1e99), row["project"]))
    (AUDIT_ROOT / "audit.json").write_text(json.dumps(results, indent=2) + "\n")
    print("\nRanked replayable projects")
    for result in results:
        if result["status"] == "replayed":
            fractions = ", ".join(
                f"{phase['name']}={phase['weight_fraction']:.4f}"
                for phase in result["phases"]
            )
            print(
                f"{result['replay_Rwp_percent']:9.4f}  {result['project']}  {fractions}"
            )
        else:
            print(f"invalid    {result['project']}  {result.get('error')}")


if __name__ == "__main__":
    main()
