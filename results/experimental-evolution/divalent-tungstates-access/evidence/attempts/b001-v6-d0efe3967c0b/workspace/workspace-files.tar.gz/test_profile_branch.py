#!/usr/bin/env python3
"""Test one bounded profile/texture branch from a fixed physical checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def freeze_all(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements({"Background": True})
    hist.clear_refinements(
        {"Instrument Parameters": list(hist.InstrumentParameters.keys())}
    )
    sample = [
        key
        for key, value in hist.SampleParameters.items()
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool)
    ]
    hist.clear_refinements({"Sample Parameters": sample})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "HStrain": True,
                "Pref.Ori.": True,
                "Extinction": True,
            }
        )


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    values = {
        phase.name: float(phase.data["General"]["Mass"])
        * float(phase.data["Histograms"][hist.name]["Scale"][0])
        for phase in project.phases()
    }
    total = sum(values.values())
    return {key: value / total for key, value in values.items()}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("mode", choices=["uniaxial_strain", "texture"])
    parser.add_argument("axis", help="comma-separated h,k,l")
    args = parser.parse_args()
    axis = [int(value) for value in args.axis.split(",")]
    if len(axis) != 3:
        raise ValueError("axis must have three values")

    G2.SetPrintLevel("error")
    project = G2.G2Project(
        gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve())
    )
    project.index_ids()
    freeze_all(project)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        scale = float(phase.data["Histograms"][hist.name]["Scale"][0])
        project.set_Controls("parmMin", 0.5 * scale, variable=f"{phase.id}:0:Scale")
        project.set_Controls("parmMax", 2.0 * scale, variable=f"{phase.id}:0:Scale")

    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    if args.mode == "uniaxial_strain":
        value = float(hap["Mustrain"][1][0])
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = value
        hap["Mustrain"][1][1] = max(value, 100.0)
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        hap["Mustrain"][3] = axis
        for suffix in ("i", "a"):
            project.set_Controls(
                "parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;{suffix}"
            )
            project.set_Controls(
                "parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;{suffix}"
            )
    else:
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
        project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")

    project.set_Controls("cycles", 12)
    project.save()
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "phase": args.phase,
        "mode": args.mode,
        "axis": axis,
        "rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "fractions": fractions(project),
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
    }
    args.output.with_suffix(".branch.json").write_text(
        json.dumps(record, indent=2, default=str) + "\n"
    )
    print(json.dumps(record, default=str))


if __name__ == "__main__":
    main()
