#!/usr/bin/env python3
"""Convert the accepted inventory fit into a bounded physical checkpoint."""

from __future__ import annotations

import copy
import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def clear_frozen(project: G2.G2Project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def mass_fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted[phase.name] = max(
            0.0, float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        )
    total = sum(weighted.values())
    return {name: value / total for name, value in weighted.items()}


def snapshot(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(hap["Scale"][0]),
                "size": copy.deepcopy(hap["Size"]),
                "mustrain": copy.deepcopy(hap["Mustrain"]),
                "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
            }
        )
    return {
        "stage": stage,
        "rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "fractions": mass_fractions(project),
        "instrument": copy.deepcopy(hist.InstrumentParameters),
        "sample": copy.deepcopy(hist.SampleParameters),
        "background": copy.deepcopy(hist.Background),
        "phases": phases,
    }


def run(project: G2.G2Project, stage: str, history: list[dict], cycles: int) -> None:
    clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = snapshot(project, stage)
    history.append(record)
    print(
        json.dumps(
            {
                "stage": stage,
                "Rwp": record["rwp_percent"],
                "converged": record["converged"],
                "max_shift_esd": record["max_shift_esd"],
                "frozen": record["frozen"],
                "fractions": record["fractions"],
            }
        ),
        flush=True,
    )


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: prepare_physical.py INPUT.gpx OUTPUT.gpx")
    source, output = map(Path, sys.argv[1:])
    project = G2.G2Project(
        gpxfile=str(source.resolve()), newgpx=str(output.resolve())
    )
    project.index_ids()
    hist = project.histogram(0)

    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}

    # Freeze everything, then explicitly activate each supported block below.
    hist.clear_refinements({"Background": True})
    hist.clear_refinements(
        {"Instrument Parameters": list(hist.InstrumentParameters.keys())}
    )
    sample_keys = [
        key
        for key, value in hist.SampleParameters.items()
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool)
    ]
    hist.clear_refinements({"Sample Parameters": sample_keys})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "HStrain": True,
                "Pref.Ori.": True,
                "Extinction": True,
            }
        )

    # Restore the known laboratory parameter domain. The earlier broad search
    # was intentionally looser and placed several profile terms on nonphysical
    # boundaries.
    inst = hist.InstrumentParameters
    inst["U"][1] = min(max(float(inst["U"][1]), 0.0), 40.0)
    inst["W"][1] = min(max(float(inst["W"][1]), 2.0), 40.0)
    inst["X"][1] = min(max(float(inst["X"][1]), 0.1), 6.0)
    inst["SH/L"][1] = min(max(float(inst["SH/L"][1]), 0.005), 0.1)
    inst["Polariz."][1] = min(max(float(inst["Polariz."][1]), 0.5), 1.0)
    inst["Zero"][1] = 0.20
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [-390.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    for variable, lower, upper in [
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.1),
        (":0:Polariz.", 0.5, 1.0),
    ]:
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = min(max(float(hap["Size"][1][0]), 0.04), 1.5)
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = min(
            max(float(hap["Mustrain"][1][0]), 0.0), 8000.0
        )
        scale = max(float(hap["Scale"][0]), 1.0e-8)
        project.set_Controls("parmMin", 0.05 * scale, variable=f"{phase.id}:0:Scale")
        project.set_Controls("parmMax", 5.0 * scale, variable=f"{phase.id}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;i")

        cell = phase.get_cell()
        reciprocal = G2lat.cell2A(
            [
                cell["length_a"],
                cell["length_b"],
                cell["length_c"],
                cell["angle_alpha"],
                cell["angle_beta"],
                cell["angle_gamma"],
            ]
        )
        for index, value in enumerate(reciprocal):
            span = max(0.01 * abs(float(value)), 0.0003)
            project.set_Controls(
                "parmMin", float(value) - span, variable=f"{phase.id}::A{index}"
            )
            project.set_Controls(
                "parmMax", float(value) + span, variable=f"{phase.id}::A{index}"
            )

    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "no. coeffs": 8, "refine": True}}
    )
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})

    history: list[dict] = []
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run(project, "angular_background_scales", history, 10)

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run(project, "cells", history, 10)

    hist.set_refinements(
        {"Instrument Parameters": ["U", "W", "X", "SH/L"]}
    )
    run(project, "instrument_profile", history, 10)

    for phase in project.phases():
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    run(project, "isotropic_phase_profiles", history, 12)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    run(project, "polarization", history, 8)
    run(project, "physical_settle", history, 12)

    project.save()
    output.with_suffix(".physical.json").write_text(
        json.dumps(history, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
