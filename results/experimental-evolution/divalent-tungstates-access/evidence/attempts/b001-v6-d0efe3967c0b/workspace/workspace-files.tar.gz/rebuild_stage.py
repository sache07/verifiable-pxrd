#!/usr/bin/env python3
"""Run one bounded GSAS-II refinement block from a fresh project load."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


INSTRUMENT_BOUNDS = {
    "Zero": (-0.25, 0.25),
    "U": (0.0, 40.0),
    "W": (2.0, 40.0),
    "X": (0.1, 6.0),
    "SH/L": (0.005, 0.1),
    "Polariz.": (0.5, 1.0),
}


def histogram(project: G2.G2Project):
    histograms = project.histograms()
    if len(histograms) != 1:
        raise RuntimeError("expected exactly one powder histogram")
    return histograms[0]


def clear_all(project: G2.G2Project) -> None:
    hist = histogram(project)
    hist.clear_refinements({"Background": True})
    hist.clear_refinements(
        {"Instrument Parameters": list(hist.InstrumentParameters.keys())}
    )
    sample_keys = [
        key
        for key, value in hist.SampleParameters.items()
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool)
    ]
    hist.clear_refinements({"Sample Parameters": sample_keys})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "HStrain": True,
                "Pref.Ori.": True,
                "Extinction": True,
            }
        )
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}


def install_bounds(project: G2.G2Project) -> None:
    hist = histogram(project)
    for name, (lower, upper) in INSTRUMENT_BOUNDS.items():
        project.set_Controls("parmMin", lower, variable=f":0:{name}")
        project.set_Controls("parmMax", upper, variable=f":0:{name}")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        scale = max(float(hap["Scale"][0]), 1e-8)
        project.set_Controls(
            "parmMin", max(scale * 0.2, 1e-10), variable=f"{phase.id}:0:Scale"
        )
        project.set_Controls(
            "parmMax", scale * 5.0, variable=f"{phase.id}:0:Scale"
        )
        project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:0:Size;i")
        project.set_Controls(
            "parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i"
        )
        project.set_Controls(
            "parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;i"
        )
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A(
            [
                cell["length_a"],
                cell["length_b"],
                cell["length_c"],
                cell["angle_alpha"],
                cell["angle_beta"],
                cell["angle_gamma"],
            ]
        )
        for index, value in enumerate(reciprocal):
            span = max(0.01 * abs(float(value)), 0.0003)
            project.set_Controls(
                "parmMin", float(value) - span, variable=f"{phase.id}::A{index}"
            )
            project.set_Controls(
                "parmMax", float(value) + span, variable=f"{phase.id}::A{index}"
            )


def initialize_physical_values(project: G2.G2Project, preserve_calibration: bool) -> None:
    hist = histogram(project)
    inst = hist.InstrumentParameters
    inst["U"][1] = min(max(float(inst["U"][1]), 0.0), 40.0)
    inst["W"][1] = min(max(float(inst["W"][1]), 2.0), 40.0)
    inst["X"][1] = min(max(float(inst["X"][1]), 0.1), 6.0)
    inst["SH/L"][1] = min(max(float(inst["SH/L"][1]), 0.005), 0.1)
    inst["Polariz."][1] = min(max(float(inst["Polariz."][1]), 0.5), 1.0)
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    if not preserve_calibration:
        inst["Zero"][1] = 0.25
        hist.SampleParameters["Shift"] = [-320.0, False]
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = min(max(float(hap["Size"][1][0]), 0.04), 1.5)
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = min(
            max(float(hap["Mustrain"][1][0]), 0.0), 8000.0
        )


def enable_common(project: G2.G2Project) -> None:
    hist = histogram(project)
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})


def enable_stage(project: G2.G2Project, stage: str) -> None:
    hist = histogram(project)
    if stage == "calculate":
        return
    enable_common(project)
    if stage in {"cells", "calibration_cells", "shift_cells", "settle"}:
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
    if stage in {"calibration", "calibration_cells", "settle"}:
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    if stage == "zero":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    if stage in {"shift", "shift_cells"}:
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    if stage in {"instrument", "settle"}:
        hist.set_refinements(
            {"Instrument Parameters": ["U", "W", "X", "SH/L"]}
        )
    if stage.startswith("instrument_"):
        key = {
            "instrument_u": "U",
            "instrument_w": "W",
            "instrument_x": "X",
            "instrument_shl": "SH/L",
        }[stage]
        hist.set_refinements({"Instrument Parameters": [key]})
    if stage in {"phase_profile", "settle"}:
        for phase in project.phases():
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True},
                }
            )
    if stage == "phase_strain":
        for phase in project.phases():
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )
    if stage == "phase_size":
        for phase in project.phases():
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "refine": True}}
            )
    if stage.startswith("phase_") and stage.count("_") == 2:
        _, index_text, term = stage.split("_")
        if index_text.isdigit() and term in {"strain", "size"}:
            phase = project.phases()[int(index_text)]
            if term == "strain":
                phase.set_HAP_refinements(
                    {"Mustrain": {"type": "isotropic", "refine": True}}
                )
            else:
                phase.set_HAP_refinements(
                    {"Size": {"type": "isotropic", "refine": True}}
                )
    if stage in {"polarization", "settle"}:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = histogram(project)
    masses = {
        phase.name: float(phase.data["General"]["Mass"])
        * float(phase.data["Histograms"][hist.name]["Scale"][0])
        for phase in project.phases()
    }
    total = sum(masses.values())
    return {name: value / total for name, value in masses.items()}


def snapshot(project: G2.G2Project, stage: str) -> dict:
    hist = histogram(project)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": stage,
        "stored_Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "fractions": fractions(project),
        "instrument": copy.deepcopy(hist.InstrumentParameters),
        "sample": copy.deepcopy(hist.SampleParameters),
        "phases": [
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "size": copy.deepcopy(phase.data["Histograms"][hist.name]["Size"]),
                "mustrain": copy.deepcopy(
                    phase.data["Histograms"][hist.name]["Mustrain"]
                ),
            }
            for phase in project.phases()
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "stage",
        choices=[
            "calculate",
            "scales_background",
            "cells",
            "calibration",
            "calibration_cells",
            "zero",
            "shift",
            "shift_cells",
            "instrument",
            "instrument_u",
            "instrument_w",
            "instrument_x",
            "instrument_shl",
            "phase_profile",
            "phase_strain",
            "phase_size",
            "phase_0_strain",
            "phase_1_strain",
            "phase_2_strain",
            "phase_0_size",
            "phase_1_size",
            "phase_2_size",
            "polarization",
            "settle",
        ],
    )
    parser.add_argument("--initialize", action="store_true")
    parser.add_argument("--preserve-calibration", action="store_true")
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()

    project = G2.G2Project(
        gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve())
    )
    project.index_ids()
    clear_all(project)
    if args.initialize:
        initialize_physical_values(project, args.preserve_calibration)
    install_bounds(project)
    enable_stage(project, args.stage)
    project.set_Controls("cycles", 0 if args.stage == "calculate" else args.cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = snapshot(project, args.stage)
    args.output.with_suffix(".stage.json").write_text(
        json.dumps(record, indent=2, default=str) + "\n"
    )
    print(json.dumps(record, default=str))


if __name__ == "__main__":
    main()
