#!/usr/bin/env python3
"""Test bounded Suortti surface-roughness branches from a complete checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
STARTS = ((0.10, 0.03), (0.30, 0.10), (0.55, 0.40))


def clear_flags(project):
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(project):
    hist = project.histograms()[0]
    weighted = {
        phase.name: phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    }
    total = sum(weighted.values())
    return {name: value / total for name, value in weighted.items()}


def run_branch(source, output_dir, start_a, start_b):
    label = f"start_A{start_a:.2f}_B{start_b:.2f}".replace(".", "p")
    destination = output_dir / f"{label}.gpx"
    project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
    clear_flags(project)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    hist = project.histograms()[0]
    hist.SampleParameters["SurfRoughA"] = [start_a, True]
    hist.SampleParameters["SurfRoughB"] = [start_b, True]
    project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    project.set_Controls("cycles", 12)
    project.save()
    project.refine(makeBack=False)
    project.save()
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "start": [start_a, start_b],
        "A": hist.SampleParameters["SurfRoughA"][0],
        "B": hist.SampleParameters["SurfRoughB"][0],
        "Rwp_percent": float(hist.get_wR()),
        "fractions": fractions(project),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "path": str(destination),
    }
    print(json.dumps(record), flush=True)
    return record


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    output_dir = ROOT / "analysis" / "roughness_tests"
    output_dir.mkdir(parents=True, exist_ok=True)
    source = args.source.resolve()
    records = [run_branch(source, output_dir, *start) for start in STARTS]
    (output_dir / "summary.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
