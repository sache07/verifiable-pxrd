#!/usr/bin/env python3
"""Refine supported specimen/intensity terms on the textured inventory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SOURCE = ROOT / "analysis" / "refinement" / "zn_texture" / "inventory_settle.gpx"


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def set_bound(project, variable, lower, upper):
    project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", upper, variable=variable)


def reset_bounds(project: G2.G2Project) -> None:
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    set_bound(project, ":0:Shift", -800.0, 800.0)
    set_bound(project, ":0:Polariz.", 0.5, 1.0)
    set_bound(project, ":0:SH/L", 0.005, 0.1)
    for phase in project.phases():
        pid = phase.data["pId"]
        hist = project.histograms()[0]
        hap = phase.data["Histograms"][hist.name]
        set_bound(project, f"{pid}:0:Scale", 0.0, max(5.0 * hap["Scale"][0], 1.0))
        set_bound(project, f"{pid}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{pid}:0:MD", 0.7, 1.4)
        for index in range(len(phase.atoms())):
            set_bound(project, f"{pid}::AUiso:{index}", 0.003, 0.02)
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(reciprocal):
            span = max(0.01 * abs(float(value)), 0.0003)
            set_bound(project, f"{pid}::A{index}", float(value) - span, float(value) + span)


def enable_scales_background(project):
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def fractions(project):
    hist = project.histograms()[0]
    values = {
        phase.name: max(0.0, phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0])
        for phase in project.phases()
    }
    total = sum(values.values())
    return {name: value / total for name, value in values.items()}


def snapshot(project, stage):
    hist = project.histograms()[0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": project.get_Frozen(),
        "fractions": fractions(project),
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "shift_um": hist.SampleParameters["Shift"][0],
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "uiso": [atom.uiso for atom in phase.atoms()],
                "size_um": phase.data["Histograms"][hist.name]["Size"][1][0],
                "texture": phase.data["Histograms"][hist.name]["Pref.Ori."][:4],
            }
            for phase in project.phases()
        },
    }
    print(json.dumps(record), flush=True)
    return record


def run(project, outdir, stage, records, cycles=10):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    shutil.copy2(project.filename, outdir / f"{stage}.gpx")
    records.append(snapshot(project, stage))


def install_equal_uiso_constraints(project):
    for key in ("Hist", "HAP", "Phase", "Global"):
        project.data["Constraints"]["data"].setdefault(key, [])
    project.data["Constraints"]["data"]["Phase"] = []
    project.save()
    project.index_ids()
    for phase in project.phases():
        pid = phase.data["pId"]
        variables = [f"{pid}::AUiso:{index}" for index in range(len(phase.atoms()))]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--tag", default="base")
    parser.add_argument("--skip-uiso", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    outdir = ROOT / "analysis" / "nuisance" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(outdir / "developing.gpx"))
    clear_flags(project)
    reset_bounds(project)
    if not args.skip_uiso:
        install_equal_uiso_constraints(project)
    records = []

    enable_scales_background(project)
    hist = project.histograms()[0]
    hist.InstrumentParameters["Polariz."][2] = True
    # Keep only supported, already selected texture terms active.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if abs(hap["Pref.Ori."][1] - 1.0) > 1e-5:
            hap["Pref.Ori."][2] = True
        if not args.skip_uiso:
            for atom in phase.atoms():
                atom.refinement_flags = "U"
    first_stage = "polarization_texture" if args.skip_uiso else "uiso_polarization_texture"
    run(project, outdir, first_stage, records, 12)

    clear_flags(project)
    enable_scales_background(project)
    hist.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.data["Histograms"][hist.name]["Size"][2][0] = True
        hap = phase.data["Histograms"][hist.name]
        if abs(hap["Pref.Ori."][1] - 1.0) > 1e-5:
            hap["Pref.Ori."][2] = True
    run(project, outdir, "cell_size_calibration_settle", records, 12)

    clear_flags(project)
    project.save(outdir / "nuisance_checkpoint.gpx")
    (outdir / "stages.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
