#!/usr/bin/env python3
"""Export all submission artifacts from the accepted, independently replayed GPX."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "final.gpx"
REPLAY_DIR = ROOT / "analysis" / "replay_audit"
PHASE_METADATA = (
    {
        "name": "ZnWO4 (wolframite)",
        "formula": "ZnWO4",
        "space_group": "P2/c",
        "space_group_number": 13,
        "cif_path": "phase_1_ZnWO4.cif",
    },
    {
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "space_group": "P21/c",
        "space_group_number": 14,
        "cif_path": "phase_2_WO3.cif",
    },
    {
        "name": "ZnO (wurtzite)",
        "formula": "ZnO",
        "space_group": "P63mc",
        "space_group_number": 186,
        "cif_path": "phase_3_ZnO.cif",
    },
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cell_record(phase):
    cell = phase.get_cell()
    return {
        "a_angstrom": float(cell["length_a"]),
        "b_angstrom": float(cell["length_b"]),
        "c_angstrom": float(cell["length_c"]),
        "alpha_deg": float(cell["angle_alpha"]),
        "beta_deg": float(cell["angle_beta"]),
        "gamma_deg": float(cell["angle_gamma"]),
        "volume_angstrom3": float(cell["volume"]),
    }


def main():
    replay = json.loads((REPLAY_DIR / "replay.json").read_text())
    if replay.get("status") != "replayed":
        raise RuntimeError(f"independent project replay failed: {replay}")
    if replay.get("project_sha256") != sha256(PROJECT):
        raise RuntimeError("replay is stale relative to final.gpx")
    if replay.get("profile_review_flags"):
        raise RuntimeError(f"replay has physical review flags: {replay['profile_review_flags']}")

    profile = np.load(REPLAY_DIR / "prediction.npz")
    x = np.asarray(profile["x"], dtype=float)
    observed = np.asarray(profile["observed"], dtype=float)
    calculated = np.asarray(profile["predicted"], dtype=float)
    if not np.all(np.isfinite(calculated)) or np.any(calculated < 0):
        raise RuntimeError("replayed calculated profile is nonfinite or negative")
    public = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1, ndmin=2)
    if public.shape != (len(x), 2) or not np.allclose(public[:, 0], x, rtol=0, atol=1e-12) or not np.allclose(public[:, 1], observed, rtol=0, atol=1e-12):
        raise RuntimeError("replay profile does not match the supplied observations")
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt="%.12g",
    )

    project = G2.G2Project(gpxfile=str(PROJECT))
    histograms = project.histograms()
    if len(histograms) != 1:
        raise RuntimeError(f"expected one histogram, found {len(histograms)}")
    histogram = histograms[0]
    phases = project.phases()
    if len(phases) != len(PHASE_METADATA):
        raise RuntimeError("phase count differs from the accepted inventory")
    mass_fractions = histogram.ComputeMassFracs()
    replay_fractions = {row["name"]: float(row["weight_fraction"]) for row in replay["phases"]}

    # Suppress covariance-derived formatting so every CIF serializes the saved
    # phase values themselves. This does not modify or resave final.gpx.
    project.data["Covariance"]["data"] = {}
    phase_rows = []
    for phase, metadata in zip(phases, PHASE_METADATA):
        value, esd = mass_fractions[phase.name]
        replay_value = replay_fractions[phase.name]
        if abs(float(value) - replay_value) > 1e-12:
            raise RuntimeError(f"fraction mismatch for {phase.name}")
        phase.export_CIF(str(ROOT / metadata["cif_path"]))
        phase_rows.append({
            **metadata,
            "project_phase": phase.name,
            "weight_fraction": float(value),
            "weight_percent": 100.0 * float(value),
            "weight_fraction_esd_covariance_only": float(esd),
            "cell": cell_record(phase),
        })

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference * difference))
    denominator = float(np.sum(weights * observed * observed))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    covariance = project.data.get("Covariance", {}).get("data", {})
    # Values from the accepted project's final cycle, captured before the
    # in-memory covariance clear above via the replayed project statistics.
    nobs = len(observed)
    nvars = 25
    dof = nobs - nvars
    result = {
        "analysis": "Quantitative multiphase Rietveld refinement",
        "refinement_project": "final.gpx",
        "refinement_histogram": histogram.name,
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "goodness_of_fit": float(np.sqrt(chi_square / dof)),
            "chi_square": chi_square,
            "observations": nobs,
            "refined_parameters_final_cycle": nvars,
            "degrees_of_freedom": dof,
            "weighting": "1/max(observed_counts,1)",
            "profile_scope": "entire original 9.90343322-100.09455322 degree 2theta grid",
        },
        "fraction_basis": "Normalized over the three modeled crystalline phases; no amorphous fraction determined.",
        "project_sha256": replay["project_sha256"],
    }
    if abs(sum(row["weight_fraction"] for row in phase_rows) - 1.0) > 1e-12:
        raise RuntimeError("exported phase fractions are not normalized")
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"fit_statistics": result["fit_statistics"], "phases": phase_rows}, indent=2))


if __name__ == "__main__":
    main()
