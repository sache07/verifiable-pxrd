#!/usr/bin/env python3
"""Screen isotropic and allowed uniaxial microstrain terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SOURCE = ROOT / "analysis" / "profile" / "main" / "profile_checkpoint.gpx"
WORK = ROOT / "analysis" / "microstrain_tests"
AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0)]


def clear_flags(project):
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(project):
    h = project.histograms()[0]
    vals = {p.name: p.data["General"]["Mass"] * p.data["Histograms"][h.name]["Scale"][0] for p in project.phases()}
    total = sum(vals.values())
    return {k: v / total for k, v in vals.items()}


def test(source, phase_index, kind, axis=None):
    suffix = "iso" if kind == "isotropic" else "uni" + "".join(map(str, axis))
    label = f"{source.stem}__phase{phase_index}_{suffix}"
    path = WORK / f"{label}.gpx"
    project = G2.G2Project(gpxfile=str(source), newgpx=str(path))
    clear_flags(project)
    hist = project.histograms()[0]
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    hist.Background[0][1] = True
    phase = project.phases()[phase_index]
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][0] = kind
    hap["Mustrain"][1][0] = 500.0
    hap["Mustrain"][1][1] = 500.0
    if kind == "isotropic":
        hap["Mustrain"][2][0] = True
        variables = [(f"{phase.data['pId']}:0:Mustrain;i", 0.0, 8000.0)]
    else:
        hap["Mustrain"][3] = list(axis)
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        variables = [
            (f"{phase.data['pId']}:0:Mustrain;i", 0.0, 8000.0),
            (f"{phase.data['pId']}:0:Mustrain;a", 0.0, 8000.0),
        ]
    for variable, low, high in variables:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    project.set_Controls("cycles", 12)
    project.save()
    project.refine(makeBack=False)
    project.save()
    rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    rec = {
        "label": label,
        "phase": phase.name,
        "kind": kind,
        "axis": axis,
        "Rwp_percent": float(hist.get_wR()),
        "mustrain": hap["Mustrain"],
        "fractions": fractions(project),
        "converged": rv.get("converged"),
        "max_shift_esd": rv.get("Max shft/sig"),
        "frozen": project.get_Frozen(),
        "path": str(path),
    }
    print(json.dumps(rec), flush=True)
    return rec


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--uniaxial", action="store_true")
    parser.add_argument("--phases", type=int, nargs="+", default=[0, 1, 2])
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    WORK.mkdir(parents=True, exist_ok=True)
    source = args.source.resolve()
    if args.uniaxial:
        records = [test(source, phase, "uniaxial", axis) for phase in args.phases for axis in AXES]
    else:
        records = [test(source, phase, "isotropic") for phase in args.phases]
    (WORK / "summary.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
