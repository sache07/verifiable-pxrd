#!/usr/bin/env python3
"""Refine one shared isotropic ADP per phase in separated stages."""

from __future__ import annotations

import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "refinement" / "zn_texture" / "inventory_settle.gpx"
WORK = ROOT / "analysis" / "uiso_tests"


def clear_flags(project):
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def enable_linear(project):
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def reset_constraints(project):
    for key in ("Hist", "HAP", "Phase", "Global"):
        project.data["Constraints"]["data"][key] = []


def install_equivalences(project):
    project.save()
    project.index_ids()
    for phase in project.phases():
        pid = phase.data["pId"]
        variables = [f"{pid}::AUiso:{index}" for index in range(len(phase.atoms()))]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)


def fractions(project):
    hist = project.histograms()[0]
    vals = {p.name: p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()}
    total = sum(vals.values())
    return {k: v / total for k, v in vals.items()}


def run(project, label, records, cycles=10):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    shutil.copy2(project.filename, WORK / f"{label}.gpx")
    hist = project.histograms()[0]
    rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    rec = {
        "stage": label,
        "Rwp_percent": float(hist.get_wR()),
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "uiso": {p.name: [a.uiso for a in p.atoms()] for p in project.phases()},
        "fractions": fractions(project),
        "converged": rv.get("converged"),
        "max_shift_esd": rv.get("Max shft/sig"),
        "frozen": project.get_Frozen(),
        "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    }
    print(json.dumps(rec), flush=True)
    records.append(rec)


def main():
    G2.SetPrintLevel("warn")
    WORK.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(WORK / "developing.gpx"))
    clear_flags(project)
    reset_constraints(project)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    install_equivalences(project)
    for phase in project.phases():
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 0.003, variable=f"{pid}::AUiso:0")
        project.set_Controls("parmMax", 0.020, variable=f"{pid}::AUiso:0")
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    records = []

    for index, phase in enumerate(project.phases()):
        clear_flags(project)
        enable_linear(project)
        phase.atoms()[0].refinement_flags = "U"
        run(project, f"phase{index}_shared_uiso", records, 10)

    clear_flags(project)
    enable_linear(project)
    project.histograms()[0].InstrumentParameters["Polariz."][2] = True
    run(project, "polarization", records, 10)

    clear_flags(project)
    project.save(WORK / "uiso_checkpoint.gpx")
    (WORK / "stages.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
