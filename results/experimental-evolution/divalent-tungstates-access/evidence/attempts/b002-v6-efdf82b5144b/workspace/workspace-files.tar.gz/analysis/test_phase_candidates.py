#!/usr/bin/env python3
"""Test residual precursor candidates from a fixed ZnWO4 checkpoint."""

from __future__ import annotations

import json
from pathlib import Path
import shutil
import sys
import argparse

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "analysis" / "candidate_tests"
SOURCE = ROOT / "analysis" / "work" / "sample_profile.gpx"
CIF_ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c01/cif")

CANDIDATES = {
    "wo3_1528915_monoclinic": "1528915",
    "wo3_2311041_monoclinic": "2311041",
    "wo3_2106293_triclinic": "2106293",
    "wo3_2107312_orthorhombic": "2107312",
    "zno_9004178_wurtzite": "9004178",
}


def cif_path(cod_id: str) -> Path:
    normalized = ROOT / "analysis" / f"cod_{cod_id}_normalized.cif"
    if normalized.is_file():
        return normalized
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"].get(hist.name)
        if not hap:
            continue
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def set_bound(project: G2.G2Project, variable: str, lower: float, upper: float) -> None:
    project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", upper, variable=variable)


def bound_cell(project: G2.G2Project, phase) -> None:
    cell = phase.get_cell()
    reciprocal = G2lat.cell2A([
        cell["length_a"], cell["length_b"], cell["length_c"],
        cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
    ])
    pid = phase.data["pId"]
    for index, value in enumerate(reciprocal):
        span = max(abs(float(value)) * 0.015, 0.0003)
        set_bound(project, f"{pid}::A{index}", float(value) - span, float(value) + span)


def mass_fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histograms()[0]
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted[phase.name] = max(0.0, float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
    total = sum(weighted.values())
    return {key: value / total for key, value in weighted.items()}


def run(project: G2.G2Project, cycles: int = 8) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()


def test(name: str, cod_id: str, source: Path = SOURCE) -> dict:
    destination = WORK / f"{source.stem}__{name}.gpx"
    project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
    clear_flags(project)
    hist = project.histograms()[0]
    candidate = project.add_phase(
        str(cif_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
    )
    project.save()
    project.index_ids()
    for atom in candidate.atoms():
        atom.uiso = 0.01
    hap = candidate.data["Histograms"][hist.name]
    hap["Scale"] = [10.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.10
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    hist.Background[0][1] = True
    set_bound(project, f"{candidate.data['pId']}:0:Scale", 0.0, 1000.0)
    set_bound(project, f"{candidate.data['pId']}:0:Size;i", 0.04, 1.5)
    bound_cell(project, candidate)
    run(project, 8)
    scale_rwp = float(hist.get_wR())

    candidate.data["General"]["Cell"][0] = True
    run(project, 10)
    cell_rwp = float(hist.get_wR())

    hap["Size"][2][0] = True
    run(project, 10)
    final_rwp = float(hist.get_wR())
    record = {
        "name": name,
        "cod_id": cod_id,
        "source": str(source),
        "Rwp_scale": scale_rwp,
        "Rwp_cell": cell_rwp,
        "Rwp_size": final_rwp,
        "fractions": mass_fractions(project),
        "candidate_cell": candidate.get_cell(),
        "candidate_scale": hap["Scale"][0],
        "candidate_size_um": hap["Size"][1][0],
        "frozen": project.get_Frozen(),
        "converged": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("converged"),
        "max_shift_esd": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("Max shft/sig"),
    }
    print(json.dumps(record), flush=True)
    return record


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidates", nargs="*")
    parser.add_argument("--source", type=Path, default=SOURCE)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    WORK.mkdir(parents=True, exist_ok=True)
    selected = dict(CANDIDATES)
    if args.candidates:
        selected = {name: CANDIDATES[name] for name in args.candidates}
    records = [test(name, cod_id, args.source.resolve()) for name, cod_id in selected.items()]
    (WORK / "summary.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
