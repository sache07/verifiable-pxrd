#!/usr/bin/env python3
"""Develop the complete physical three-phase refinement checkpoint."""

from __future__ import annotations

import json
from pathlib import Path
import shutil
import argparse

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "candidate_tests" / "wo3_2311041_monoclinic__zno_9004178_wurtzite.gpx"
WORK = ROOT / "analysis" / "refinement"


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"].get(hist.name)
        if not hap:
            continue
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def set_bound(project: G2.G2Project, variable: str, lower: float, upper: float) -> None:
    project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", upper, variable=variable)


def install_bounds(project: G2.G2Project) -> None:
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    hist = project.histograms()[0]
    set_bound(project, ":0:Shift", -800.0, 800.0)
    set_bound(project, ":0:Zero", -0.25, 0.25)
    set_bound(project, ":0:U", 0.0, 40.0)
    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:X", 0.1, 6.0)
    set_bound(project, ":0:SH/L", 0.005, 0.1)
    set_bound(project, ":0:Polariz.", 0.0, 1.0)
    for phase in project.phases():
        pid = phase.data["pId"]
        hap = phase.data["Histograms"][hist.name]
        scale = max(float(hap["Scale"][0]), 1e-6)
        set_bound(project, f"{pid}:0:Scale", 0.0, max(5.0 * scale, 1.0))
        set_bound(project, f"{pid}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{pid}:0:Mustrain;i", 0.0, 8000.0)
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(reciprocal):
            span = max(0.01 * abs(float(value)), 0.0003)
            set_bound(project, f"{pid}::A{index}", float(value) - span, float(value) + span)
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        for index, atom in enumerate(phase.atoms()):
            for axis, value, length in zip("xyz", atom.coordinates, lengths):
                half_width = 0.10 / float(length)
                set_bound(project, f"{pid}::dA{axis}:{index}", float(value) - half_width, float(value) + half_width)
            set_bound(project, f"{pid}::AUiso:{index}", 0.001, 0.04)


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histograms()[0]
    weighted = {
        phase.name: max(0.0, float(phase.data["General"]["Mass"]) * float(phase.data["Histograms"][hist.name]["Scale"][0]))
        for phase in project.phases()
    }
    total = sum(weighted.values())
    return {key: value / total for key, value in weighted.items()}


def snapshot(project: G2.G2Project, stage: str) -> dict:
    hist = project.histograms()[0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": project.get_Frozen(),
        "fractions": fractions(project),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "coordinates": {
            phase.name: [
                {"label": atom.label, "element": atom.element, "xyz": list(atom.coordinates), "uiso": atom.uiso}
                for atom in phase.atoms()
            ]
            for phase in project.phases()
        },
    }
    print(json.dumps(record), flush=True)
    return record


def run(project: G2.G2Project, stage: str, records: list[dict], outdir: Path, cycles: int = 10) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    shutil.copy2(project.filename, outdir / f"{stage}.gpx")
    records.append(snapshot(project, stage))


def enable_scales_background(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def set_phase_atoms(project: G2.G2Project, phase_index: int, selection: str) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    phase = project.phases()[phase_index]
    for atom in phase.atoms():
        oxygen = atom.element.strip().upper().startswith("O")
        if selection == "all" or (selection == "oxygen" and oxygen) or (selection == "heavy" and not oxygen):
            atom.refinement_flags = "X"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=SOURCE)
    parser.add_argument("--tag", default="default")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    outdir = WORK / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    destination = outdir / "developing.gpx"
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(destination))
    clear_flags(project)
    install_bounds(project)
    records: list[dict] = []

    # Settle all accepted phases with the common specimen displacement and
    # their isotropic coherent sizes before changing any atomic coordinates.
    enable_scales_background(project)
    hist = project.histograms()[0]
    hist.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.data["Histograms"][hist.name]["Size"][2][0] = True
    run(project, "inventory_settle", records, outdir, 12)

    # The ZnWO4 analogue coordinates dominate the remaining split-reflection
    # intensity errors. Refine heavy and oxygen sublattices in separate bounded
    # steps, followed by a short joint coordinate pass.
    clear_flags(project)
    enable_scales_background(project)
    set_phase_atoms(project, 0, "heavy")
    run(project, "znwo4_heavy_coordinates", records, outdir, 10)

    clear_flags(project)
    enable_scales_background(project)
    set_phase_atoms(project, 0, "oxygen")
    run(project, "znwo4_oxygen_coordinates", records, outdir, 12)

    clear_flags(project)
    enable_scales_background(project)
    set_phase_atoms(project, 0, "all")
    run(project, "znwo4_joint_coordinates", records, outdir, 10)

    # Reconcile cells and specimen displacement after the structural change.
    clear_flags(project)
    enable_scales_background(project)
    hist.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    run(project, "post_coordinate_settle", records, outdir, 10)

    clear_flags(project)
    project.save(outdir / "coordinate_checkpoint.gpx")
    (outdir / "coordinate_stages.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
