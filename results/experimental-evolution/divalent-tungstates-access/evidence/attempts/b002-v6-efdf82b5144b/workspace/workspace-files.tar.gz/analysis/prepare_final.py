#!/usr/bin/env python3
"""Prepare the complete physical checkpoint immediately before staged polish."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ZNWO4_UISO = 0.00803


def clear_flags(project):
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def enable_linear(project):
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def bound(project, variable, lower, upper):
    project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", upper, variable=variable)


def install_bounds(project):
    hist = project.histograms()[0]
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    bound(project, ":0:Shift", -800.0, 800.0)
    for name, limits in {
        "U": (0.0, 40.0), "W": (2.0, 40.0),
        "X": (0.1, 6.0), "SH/L": (0.005, 0.10),
    }.items():
        bound(project, f":0:{name}", *limits)
    for phase in project.phases():
        pid = phase.data["pId"]
        hap = phase.data["Histograms"][hist.name]
        bound(project, f"{pid}:0:Scale", 0.0, max(5.0 * float(hap["Scale"][0]), 1.0))
        bound(project, f"{pid}:0:Size;i", 0.04, 1.5)
        bound(project, f"{pid}:0:MD", 0.70, 1.40)
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(reciprocal):
            span = max(0.005 * abs(float(value)), 0.0002)
            bound(project, f"{pid}::A{index}", float(value) - span, float(value) + span)


def fractions(project):
    hist = project.histograms()[0]
    weighted = {
        phase.name: phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    }
    total = sum(weighted.values())
    return {name: value / total for name, value in weighted.items()}


def run(project, stage, records, cycles=10):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    hist = project.histograms()[0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "GOF": rvals.get("GOF"),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "fractions": fractions(project),
        "textures": {
            phase.name: phase.data["Histograms"][hist.name]["Pref.Ori."][1:4]
            for phase in project.phases()
        },
        "uiso": {phase.name: [atom.uiso for atom in phase.atoms()] for phase in project.phases()},
    }
    print(json.dumps(record), flush=True)
    records.append(record)


def settled(record):
    maximum = record.get("max_shift_esd")
    return record.get("converged") and maximum is not None and maximum <= 1.0 and not record.get("frozen")


def repeat(project, label, records, setup, maximum_passes=3, cycles=10):
    for index in range(maximum_passes):
        clear_flags(project)
        enable_linear(project)
        setup()
        run(project, f"{label}_{index + 1}", records, cycles)
        if settled(records[-1]):
            break


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--log", type=Path, default=Path("analysis/prepolish_stages.json"))
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve()))
    if len(project.phases()) != 3:
        raise RuntimeError("the accepted three-phase inventory is required")
    clear_flags(project)
    install_bounds(project)
    hist = project.histograms()[0]
    phases = project.phases()
    for atom in phases[0].atoms():
        atom.uiso = ZNWO4_UISO
    records = []

    def texture_setup():
        phases[1].data["Histograms"][hist.name]["Pref.Ori."][2] = True
        phases[2].data["Histograms"][hist.name]["Pref.Ori."][2] = True

    repeat(project, "texture_scale_background", records, texture_setup, cycles=10)

    def cell_setup():
        hist.SampleParameters["Shift"][1] = True
        for phase in phases:
            phase.data["General"]["Cell"][0] = True

    repeat(project, "cell_shift_scale_background", records, cell_setup, cycles=8)

    def profile_setup():
        for key in ("U", "W", "X", "SH/L"):
            hist.InstrumentParameters[key][2] = True

    repeat(project, "instrument_scale_background", records, profile_setup, cycles=10)

    def size_setup():
        for phase in phases:
            phase.data["Histograms"][hist.name]["Size"][2][0] = True

    repeat(project, "size_scale_background", records, size_setup, cycles=10)

    repeat(project, "final_scale_background", records, lambda: None, maximum_passes=2, cycles=8)
    clear_flags(project)
    project.save(args.output.resolve())
    args.log.resolve().write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
