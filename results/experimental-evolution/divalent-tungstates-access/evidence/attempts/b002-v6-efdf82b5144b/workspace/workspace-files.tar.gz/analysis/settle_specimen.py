#!/usr/bin/env python3
"""Settle the accepted phase-specific texture and ordinary profile terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]


def histogram(project):
    return max(project.histograms(), key=lambda item: len(item.data.get("data", [[], []])[1]))


def clear_flags(project):
    hist = histogram(project)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def enable_linear(project):
    hist = histogram(project)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def set_bound(project, variable, lower, upper):
    project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", upper, variable=variable)


def install_bounds(project):
    hist = histogram(project)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    set_bound(project, ":0:Shift", -800.0, 800.0)
    for key, bounds in {
        "U": (0.0, 40.0),
        "W": (2.0, 40.0),
        "X": (0.1, 6.0),
        "SH/L": (0.005, 0.10),
    }.items():
        set_bound(project, f":0:{key}", *bounds)
    for phase in project.phases():
        pid = phase.data["pId"]
        hap = phase.data["Histograms"][hist.name]
        set_bound(project, f"{pid}:0:Scale", 0.0, max(5.0 * float(hap["Scale"][0]), 1.0))
        set_bound(project, f"{pid}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{pid}:0:MD", 0.70, 1.40)
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(reciprocal):
            span = max(0.005 * abs(float(value)), 0.0002)
            set_bound(project, f"{pid}::A{index}", float(value) - span, float(value) + span)


def fractions(project):
    hist = histogram(project)
    weighted = {
        phase.name: float(phase.data["General"]["Mass"]) * float(phase.data["Histograms"][hist.name]["Scale"][0])
        for phase in project.phases()
    }
    total = sum(weighted.values())
    return {name: value / total for name, value in weighted.items()}


def snapshot(project, stage):
    hist = histogram(project)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "fractions": fractions(project),
        "textures": {
            phase.name: {
                "axis": phase.data["Histograms"][hist.name]["Pref.Ori."][3],
                "ratio": phase.data["Histograms"][hist.name]["Pref.Ori."][1],
            }
            for phase in project.phases()
        },
        "sizes_um": {
            phase.name: phase.data["Histograms"][hist.name]["Size"][1][0]
            for phase in project.phases()
        },
    }
    print(json.dumps(record), flush=True)
    return record


def run(project, output_dir, stage, records, cycles=10):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    shutil.copy2(project.filename, output_dir / f"{stage}.gpx")
    records.append(snapshot(project, stage))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--tag", default="accepted_textures")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    output_dir = ROOT / "analysis" / "specimen" / args.tag
    output_dir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(args.source.resolve()),
        newgpx=str(output_dir / "developing.gpx"),
    )
    clear_flags(project)
    install_bounds(project)
    hist = histogram(project)
    phases = project.phases()
    if len(phases) != 3:
        raise RuntimeError(f"expected the accepted three-phase inventory, found {len(phases)}")

    # The principal ZnWO4 texture is retained from the prior checkpoint.
    # Independent screens selected [110] for WO3 and [001] for ZnO.
    texture_specs = {
        1: ([1, 1, 0], 1.375),
        2: ([0, 0, 1], 0.885),
    }
    for phase_index, (axis, ratio) in texture_specs.items():
        po = phases[phase_index].data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = ratio
        po[3] = axis

    records = []
    for pass_index in range(3):
        clear_flags(project)
        enable_linear(project)
        for phase_index in texture_specs:
            phases[phase_index].data["Histograms"][hist.name]["Pref.Ori."][2] = True
        run(project, output_dir, f"texture_settle_{pass_index + 1}", records, 10)
        last = records[-1]
        if last["converged"] and (last["max_shift_esd"] is not None and last["max_shift_esd"] <= 1.0) and not last["frozen"]:
            break

    # Re-settle coupled cell/displacement terms after the intensity correction.
    for pass_index in range(2):
        clear_flags(project)
        enable_linear(project)
        hist.SampleParameters["Shift"][1] = True
        for phase in phases:
            phase.data["General"]["Cell"][0] = True
        run(project, output_dir, f"cell_shift_settle_{pass_index + 1}", records, 8)

    clear_flags(project)
    enable_linear(project)
    for key in ("U", "W", "X", "SH/L"):
        hist.InstrumentParameters[key][2] = True
    run(project, output_dir, "instrument_profile_settle", records, 10)

    for pass_index in range(3):
        clear_flags(project)
        enable_linear(project)
        for phase in phases:
            phase.data["Histograms"][hist.name]["Size"][2][0] = True
        run(project, output_dir, f"size_settle_{pass_index + 1}", records, 10)
        last = records[-1]
        if last["converged"] and (last["max_shift_esd"] is not None and last["max_shift_esd"] <= 1.0) and not last["frozen"]:
            break

    clear_flags(project)
    project.save(output_dir / "complete_checkpoint.gpx")
    (output_dir / "stages.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
