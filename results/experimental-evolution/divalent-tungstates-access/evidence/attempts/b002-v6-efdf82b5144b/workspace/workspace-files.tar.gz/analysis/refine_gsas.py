#!/usr/bin/env python3
"""Build and refine the initial ZnWO4 GSAS-II checkpoint."""

from __future__ import annotations

import csv
import json
from pathlib import Path
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
INPUTS = ROOT / "inputs"
WORK = ROOT / "analysis" / "work"
MODEL = ROOT / "analysis" / "znwo4_start.cif"


def prepare_inputs() -> tuple[Path, Path]:
    WORK.mkdir(parents=True, exist_ok=True)
    pattern = np.loadtxt(INPUTS / "pattern.csv", delimiter=",", skiprows=1)
    xye = WORK / "pattern.xye"
    np.savetxt(
        xye,
        np.column_stack((pattern[:, 0], pattern[:, 1], np.sqrt(np.maximum(pattern[:, 1], 1.0)))),
        fmt=["%.8f", "%.1f", "%.10f"],
    )
    inst = WORK / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def clear_frozen(project: G2.G2Project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    phase = project.phases()[0]
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    hap = phase.data["Histograms"][hist.name]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "stage": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "cell": phase.get_cell(),
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
            if key in inst and isinstance(inst[key], list) and len(inst[key]) > 1
        },
        "sample": {
            key: sample[key][0]
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
            if key in sample and isinstance(sample[key], list)
        },
        "hap": {
            "Scale": hap["Scale"][0],
            "Size": hap["Size"],
            "Mustrain": hap["Mustrain"],
            "Pref.Ori.": hap["Pref.Ori."],
        },
        "background": hist.Background[0],
        "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(record, default=lambda value: value.tolist() if hasattr(value, "tolist") else value), flush=True)
    return record


def run(project: G2.G2Project, label: str, cycles: int = 8) -> dict:
    clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    shutil.copy2(project.filename, WORK / f"{label}.gpx")
    return snapshot(project, label)


def set_bound(project: G2.G2Project, variable: str, lower: float, upper: float) -> None:
    project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", upper, variable=variable)


def main() -> None:
    G2.SetPrintLevel("warn")
    xye, inst = prepare_inputs()
    path = WORK / "initial.gpx"
    path.unlink(missing_ok=True)
    project = G2.G2Project(newgpx=str(path))
    phase = project.add_phase(str(MODEL), phasename="ZnWO4_wolframite", fmthint="CIF")
    hist = project.add_powder_histogram(str(xye), str(inst), phases=[phase], fmthint="xye")
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    # Peak matching gives about +0.31 degrees at low angle, almost entirely
    # consistent with a negative specimen-height Shift in GSAS-II convention.
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-596.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({
        "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 12,
            "coeffs": [900.0] + [0.0] * 11,
            "refine": False,
        },
    })
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.25
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    project.save()
    project.index_ids()

    # Conservative physical bounds for the known generator/instrument scope.
    set_bound(project, ":0:Zero", -0.25, 0.25)
    set_bound(project, ":0:Shift", -800.0, 800.0)
    set_bound(project, ":0:U", 0.0, 40.0)
    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:X", 0.1, 6.0)
    set_bound(project, ":0:SH/L", 0.005, 0.1)
    set_bound(project, ":0:Polariz.", 0.0, 1.0)
    set_bound(project, "0:0:Scale", 0.0, 1000.0)
    set_bound(project, "0:0:Size;i", 0.04, 1.5)
    set_bound(project, "0:0:Mustrain;i", 0.0, 8000.0)

    records = []
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    records.append(snapshot(project, "calculation"))

    hist.set_refinements({"Background": True})
    phase.set_HAP_refinements({"Scale": True})
    records.append(run(project, "scale_background", 8))

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    records.append(run(project, "cell_calibration", 10))

    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    })
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    records.append(run(project, "sample_profile", 10))

    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    records.append(run(project, "effective_instrument_profile", 10))

    (WORK / "initial_stages.json").write_text(json.dumps(records, indent=2, default=lambda value: value.tolist() if hasattr(value, "tolist") else value) + "\n")
    project.save(WORK / "basic_checkpoint.gpx")


if __name__ == "__main__":
    main()
