#!/usr/bin/env python3
"""Profile common isotropic displacement parameters by phase on a fixed grid."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
VALUES = (0.003, 0.005, 0.0075, 0.010, 0.0125, 0.016, 0.020)


def clear_flags(project):
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(project):
    hist = project.histograms()[0]
    weighted = {
        phase.name: phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    }
    total = sum(weighted.values())
    return {name: value / total for name, value in weighted.items()}


def evaluate(source, output_dir, phase_index, uiso):
    destination = output_dir / f"phase{phase_index}_uiso_{uiso:.4f}".replace(".", "p")
    destination = destination.with_suffix(".gpx")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
    clear_flags(project)
    hist = project.histograms()[0]
    phase = project.phases()[phase_index]
    for atom in phase.atoms():
        atom.uiso = uiso
    hist.Background[0][1] = True
    for item in project.phases():
        item.data["Histograms"][hist.name]["Scale"][1] = True
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    project.set_Controls("cycles", 8)
    project.save()
    project.refine(makeBack=False)
    project.save()
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "phase_index": phase_index,
        "phase": phase.name,
        "Uiso_A2": uiso,
        "Rwp_percent": float(hist.get_wR()),
        "fractions": fractions(project),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "path": str(destination),
    }
    print(json.dumps(record), flush=True)
    return record


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    output_dir = ROOT / "analysis" / "uiso_grid"
    output_dir.mkdir(parents=True, exist_ok=True)
    source = args.source.resolve()
    probe = G2.G2Project(gpxfile=str(source))
    phase_count = len(probe.phases())
    records = [
        evaluate(source, output_dir, phase_index, uiso)
        for phase_index in range(phase_count)
        for uiso in VALUES
    ]
    (output_dir / "summary.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
