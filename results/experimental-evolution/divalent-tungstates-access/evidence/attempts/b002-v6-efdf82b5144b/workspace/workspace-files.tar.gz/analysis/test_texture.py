#!/usr/bin/env python3
"""Screen the laboratory's allowed March-Dollase axes by physical branches."""

from __future__ import annotations

import json
from pathlib import Path
import argparse

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "refinement" / "inventory_settle.gpx"
WORK = ROOT / "analysis" / "texture_tests"
AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histograms()[0]
    values = {
        phase.name: max(0.0, phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0])
        for phase in project.phases()
    }
    total = sum(values.values())
    return {key: value / total for key, value in values.items()}


def test(source: Path, phase_index: int, axis: tuple[int, int, int]) -> dict:
    label = f"{source.stem}__phase{phase_index}_axis{axis[0]}{axis[1]}{axis[2]}"
    path = WORK / f"{label}.gpx"
    project = G2.G2Project(gpxfile=str(source), newgpx=str(path))
    clear_flags(project)
    hist = project.histograms()[0]
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    hist.Background[0][1] = True
    phase = project.phases()[phase_index]
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    project.set_Controls("parmMin", 0.70, variable=f"{phase.data['pId']}:0:MD")
    project.set_Controls("parmMax", 1.40, variable=f"{phase.data['pId']}:0:MD")
    project.set_Controls("cycles", 10)
    project.save()
    project.refine(makeBack=False)
    project.save()
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "label": label,
        "phase": phase.name,
        "axis": axis,
        "ratio": hap["Pref.Ori."][1],
        "Rwp_percent": float(hist.get_wR()),
        "fractions": fractions(project),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": project.get_Frozen(),
        "path": str(path),
    }
    print(json.dumps(record), flush=True)
    return record


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=SOURCE)
    parser.add_argument("--phases", type=int, nargs="+", default=[0, 1, 2])
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    WORK.mkdir(parents=True, exist_ok=True)
    source = args.source.resolve()
    records = [test(source, phase_index, axis) for phase_index in args.phases for axis in AXES]
    (WORK / "summary.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
