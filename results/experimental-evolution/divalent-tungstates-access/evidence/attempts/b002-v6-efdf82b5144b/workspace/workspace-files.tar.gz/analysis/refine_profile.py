#!/usr/bin/env python3
"""Settle cells/calibration and refine the shared/phase profile terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SOURCE = ROOT / "analysis" / "refinement" / "zn_texture_pol_coords" / "coordinate_checkpoint.gpx"


def clear_flags(project):
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def enable_linear(project):
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def set_bound(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def install_bounds(project):
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    set_bound(project, ":0:Shift", -800.0, 800.0)
    set_bound(project, ":0:U", 0.0, 40.0)
    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:X", 0.1, 6.0)
    set_bound(project, ":0:SH/L", 0.005, 0.1)
    for phase in project.phases():
        pid = phase.data["pId"]
        hist = project.histograms()[0]
        hap = phase.data["Histograms"][hist.name]
        set_bound(project, f"{pid}:0:Scale", 0.0, max(5.0 * hap["Scale"][0], 1.0))
        set_bound(project, f"{pid}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{pid}:0:Mustrain;i", 0.0, 8000.0)
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(reciprocal):
            span = max(0.005 * abs(float(value)), 0.0002)
            set_bound(project, f"{pid}::A{index}", float(value) - span, float(value) + span)


def fractions(project):
    hist = project.histograms()[0]
    vals = {p.name: p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()}
    total = sum(vals.values())
    return {k: v / total for k, v in vals.items()}


def snapshot(project, stage):
    hist = project.histograms()[0]
    rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    rec = {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "converged": rv.get("converged"),
        "max_shift_esd": rv.get("Max shft/sig"),
        "frozen": project.get_Frozen(),
        "fractions": fractions(project),
        "instrument": {key: hist.InstrumentParameters[key][1] for key in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.")},
        "shift_um": hist.SampleParameters["Shift"][0],
        "phases": {
            p.name: {
                "cell": p.get_cell(),
                "size": p.data["Histograms"][hist.name]["Size"],
                "mustrain": p.data["Histograms"][hist.name]["Mustrain"],
            }
            for p in project.phases()
        },
    }
    print(json.dumps(rec), flush=True)
    return rec


def run(project, outdir, stage, records, cycles=10):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    shutil.copy2(project.filename, outdir / f"{stage}.gpx")
    records.append(snapshot(project, stage))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--tag", default="base")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    outdir = ROOT / "analysis" / "profile" / args.tag
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(outdir / "developing.gpx"))
    clear_flags(project)
    install_bounds(project)
    records = []
    hist = project.histograms()[0]

    # Iterate cell/specimen displacement because they are correlated but
    # distinguishable over the full 10--100 degree range.
    for pass_index in range(3):
        clear_flags(project)
        enable_linear(project)
        hist.SampleParameters["Shift"][1] = True
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = True
        run(project, outdir, f"cell_shift_settle_{pass_index + 1}", records, 8)

    clear_flags(project)
    enable_linear(project)
    for key in ("U", "W", "X", "SH/L"):
        hist.InstrumentParameters[key][2] = True
    run(project, outdir, "shared_instrument_profile", records, 12)

    clear_flags(project)
    enable_linear(project)
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Size"][2][0] = True
    run(project, outdir, "phase_size_settle", records, 12)

    clear_flags(project)
    project.save(outdir / "profile_checkpoint.gpx")
    (outdir / "stages.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
