#!/usr/bin/env python3
"""Create case-specific Mn-W-O analogue models with recorded lineage."""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)


MODELS = {
    "Mn3WO6_from_Cu3WO6_1527404": ("1527404", {"Cu": "Mn"}, 1.0),
    "Mn3WO6_from_Ca3WO6_1563081": ("1563081", {"Ca": "Mn"}, 1.0),
    "Mn2WO6_from_Fe2WO6_2310464": ("2310464", {"Fe": "Mn"}, 1.0),
    "Mn2WO6_from_Cr2WO6_1530909": ("1530909", {"Cr": "Mn"}, 1.0),
    # Whole-profile residual matching selects the P212121 Y2WO6 framework.
    # The initial contraction only puts its peaks into the refinement basin;
    # all three cell lengths are subsequently refined independently.
    "Mn2WO6_from_Y2WO6_1541070": ("1541070", {"Y": "Mn"}, 0.964),
}


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    out = Path("analogues")
    out.mkdir(exist_ok=True)
    provenance = []
    for name, (cod_id, substitutions, linear_scale) in MODELS.items():
        source = cod_path(cod_id)
        structure = Structure.from_file(source)
        structure.replace_species(substitutions)
        if linear_scale != 1.0:
            structure.scale_lattice(structure.volume * linear_scale**3)
        destination = out / f"{name}.cif"
        CifWriter(structure, symprec=0.01, refine_struct=False).write_file(destination)
        provenance.append(
            {
                "model": name,
                "path": str(destination),
                "model_basis": "analogue_derived",
                "parent_cod_id": cod_id,
                "parent_path": str(source),
                "transformation": {
                    "species_substitution": substitutions,
                    "cell": (
                        "parent cell retained for subsequent refinement"
                        if linear_scale == 1.0
                        else f"uniform parent-cell scale {linear_scale}; subsequent independent cell refinement"
                    ),
                    "coordinates": "parent fractional coordinates retained",
                },
            }
        )
    (out / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")


if __name__ == "__main__":
    main()
