#!/usr/bin/env python3
"""Test the remaining low-dimensional specimen/profile corrections."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

from settle_physical import clear_flags, fractions


def configure(project: G2.G2Project, mode: str) -> None:
    clear_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    if mode in {"shift", "shift_shl"}:
        hist.SampleParameters["Shift"][1] = True
        project.set_Controls("parmMin", -100.0, variable=":0:Shift")
        project.set_Controls("parmMax", 100.0, variable=":0:Shift")
    if mode in {"shl", "shift_shl"}:
        hist.InstrumentParameters["SH/L"][2] = True
        project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
        project.set_Controls("parmMax", 0.1, variable=":0:SH/L")


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: test_specimen.py INPUT.gpx OUTPUT_DIR")
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    output.mkdir(exist_ok=True)
    G2.SetPrintLevel("warn")
    baseline = G2.G2Project(gpxfile=str(source))
    summary = {"source": str(source), "baseline_Rwp_percent": baseline.histograms()[0].get_wR(), "branches": []}
    for mode in ("shift", "shl", "shift_shl"):
        path = output / f"{mode}.gpx"
        project = G2.G2Project(gpxfile=str(source), newgpx=str(path))
        hist = project.histograms()[0]
        passes = []
        for pass_index in range(1, 4):
            configure(project, mode)
            project.set_Controls("cycles", 6)
            project.save()
            project.refine(makeBack=False)
            rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
            item = {
                "pass": pass_index,
                "Rwp_percent": float(hist.get_wR()),
                "shift_um": float(hist.SampleParameters["Shift"][0]),
                "SH_over_L": float(hist.InstrumentParameters["SH/L"][1]),
                "max_shift_esd": rvals.get("Max shft/sig"),
                "converged": bool(rvals.get("converged", False)),
                "frozen": list(project.get_Frozen()),
                "fractions": fractions(project),
            }
            passes.append(item)
            maximum = item["max_shift_esd"]
            if item["converged"] and maximum is not None and float(maximum) <= 1.0 and not item["frozen"]:
                break
        clear_flags(project)
        project.save(str(path))
        branch = {"mode": mode, "path": str(path), "passes": passes, **passes[-1]}
        summary["branches"].append(branch)
        print(json.dumps(branch), flush=True)
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
