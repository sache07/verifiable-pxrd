#!/usr/bin/env python3
"""Report cell and coordinate changes between two GSAS-II projects."""

from __future__ import annotations

import math
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


def lattice_matrix(cell: dict) -> np.ndarray:
    a, b, c = (cell[f"length_{axis}"] for axis in "abc")
    alpha, beta, gamma = (
        math.radians(cell[f"angle_{name}"])
        for name in ("alpha", "beta", "gamma")
    )
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * math.cos(gamma), b * math.sin(gamma), 0.0])
    cx = c * math.cos(beta)
    cy = c * (math.cos(alpha) - math.cos(beta) * math.cos(gamma)) / math.sin(gamma)
    cz = math.sqrt(max(0.0, c * c - cx * cx - cy * cy))
    return np.vstack((va, vb, np.array([cx, cy, cz])))


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: compare_gpx.py BEFORE.gpx AFTER.gpx")
    before = G2.G2Project(gpxfile=sys.argv[1])
    after = G2.G2Project(gpxfile=sys.argv[2])
    for source, target in zip(before.phases(), after.phases()):
        matrix = lattice_matrix(source.get_cell())
        shifts = []
        for old, new in zip(source.atoms(), target.atoms()):
            delta = np.asarray(new.coordinates) - np.asarray(old.coordinates)
            delta -= np.round(delta)
            shifts.append(float(np.linalg.norm(delta @ matrix)))
        print(
            source.name,
            "max_coordinate_displacement_A=", max(shifts),
            "coordinate_displacements_A=", shifts,
            "short_contacts=", target.ShortDistances(useAll=False),
            "cell=", target.get_cell(),
        )


if __name__ == "__main__":
    main()
