#!/usr/bin/env python3
"""Plot a saved GSAS-II profile and map prominent residuals to phase reflections."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks, peak_prominences
from GSASII import GSASIIscriptable as G2


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: audit_model.py PROJECT.gpx OUTPUT_PREFIX")
    project = G2.G2Project(gpxfile=sys.argv[1])
    hist = project.histograms()[0]
    x, observed, weights, calculated, background, difference = [
        np.asarray(v, dtype=float) for v in hist.data["data"][1]
    ]
    smooth = gaussian_filter1d(difference, 3)
    # Locate broad systematic features, not individual counting-noise spikes.
    peaks, properties = find_peaks(smooth, distance=5, prominence=100.0)
    prominences = properties["prominences"]

    reflections = []
    for phase_name, values in hist.data["Reflection Lists"].items():
        for row in np.asarray(values["RefList"]):
            reflections.append(
                {
                    "phase": phase_name,
                    "hkl": [int(round(v)) for v in row[:3]],
                    "position_deg": float(row[5]),
                    "sigma_cdeg2": float(row[6]),
                    "gamma_cdeg": float(row[7]),
                    "fcalc2": float(row[9]),
                }
            )

    mapped = []
    for index, prominence in zip(peaks, prominences):
        nearby = sorted(
            reflections,
            key=lambda item: abs(item["position_deg"] - x[index]),
        )[:8]
        mapped.append(
            {
                "position_deg": float(x[index]),
                "difference_counts": float(smooth[index]),
                "prominence_counts": float(prominence),
                "nearest_reflections": nearby,
            }
        )
    mapped.sort(key=lambda item: item["prominence_counts"], reverse=True)

    prefix = Path(sys.argv[2])
    np.savez_compressed(
        prefix.with_suffix(".npz"),
        two_theta=x,
        observed=observed,
        calculated=calculated,
        background=background,
        difference=difference,
    )
    summary = {
        "project": str(Path(sys.argv[1]).resolve()),
        "histogram": hist.name,
        "Rwp_percent": float(hist.get_wR()),
        "residual_percentiles": {
            str(percent): float(value)
            for percent, value in zip(
                (0, 1, 5, 50, 95, 99, 100),
                np.percentile(smooth, (0, 1, 5, 50, 95, 99, 100)),
            )
        },
        "positive_residual_peaks": mapped[:80],
    }
    prefix.with_suffix(".json").write_text(json.dumps(summary, indent=2) + "\n")

if __name__ == "__main__":
    main()
