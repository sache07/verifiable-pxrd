#!/usr/bin/env python3
"""Compare bounded, physical profile-settlement branches for this specimen."""

from __future__ import annotations

import json
import math
from pathlib import Path
import shutil
import sys

from GSASII import GSASIIscriptable as G2


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def install_bounds(project: G2.G2Project) -> None:
    project.index_ids()
    hist = project.histograms()[0]
    project.data["Controls"]["data"]["parmMinDict"] = {}
    project.data["Controls"]["data"]["parmMaxDict"] = {}
    for key, lower, upper in (
        ("Zero", -0.25, 0.25),
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.1),
    ):
        project.set_Controls("parmMin", lower, variable=f":0:{key}")
        project.set_Controls("parmMax", upper, variable=f":0:{key}")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    for phase in project.phases():
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 1000.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histograms()[0]
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted[phase.name] = max(
            0.0, float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        )
    total = sum(weighted.values())
    return {key: value / total for key, value in weighted.items()}


def record(project: G2.G2Project, branch: str, pass_index: int) -> dict:
    hist = project.histograms()[0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "branch": branch,
        "pass": pass_index,
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "fractions": fractions(project),
        "instrument": {
            key: float(hist.InstrumentParameters[key][1])
            for key in ("Zero", "U", "V", "W", "X", "SH/L")
        },
        "profiles": {
            phase.name: {
                "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "mustrain_ppm": float(
                    phase.data["Histograms"][hist.name]["Mustrain"][1][0]
                ),
            }
            for phase in project.phases()
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }


def configure(project: G2.G2Project, mode: str) -> None:
    clear_flags(project)
    install_bounds(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for key in ("U", "W", "X"):
        hist.InstrumentParameters[key][2] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        if mode in {"size", "both"}:
            hap["Size"][2][0] = True
        if mode in {"strain", "both"}:
            hap["Mustrain"][2][0] = True


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: refine_complete.py INPUT.gpx OUTPUT.gpx")
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    work = output.parent / f".{output.stem}_complete_branches"
    work.mkdir(exist_ok=True)
    G2.SetPrintLevel("warn")
    summary = {"source": str(source), "branches": []}
    candidates = []
    for mode in ("strain", "size", "both"):
        path = work / f"{mode}_0.gpx"
        project = G2.G2Project(gpxfile=str(source), newgpx=str(path))
        for pass_index in range(1, 4):
            configure(project, mode)
            project.set_Controls("cycles", 8)
            project.save()
            project.refine(makeBack=False)
            path = work / f"{mode}_{pass_index}.gpx"
            project.save(str(path))
            item = record(project, mode, pass_index)
            item["path"] = str(path)
            summary["branches"].append(item)
            print(json.dumps(item, default=str), flush=True)
            values = [item["Rwp_percent"]]
            values.extend(item["instrument"].values())
            for profile in item["profiles"].values():
                values.extend(profile.values())
            physical = all(math.isfinite(float(value)) for value in values)
            if physical:
                candidates.append((item["Rwp_percent"], path, mode, pass_index))
            maximum = item["max_shift_esd"]
            if item["converged"] and maximum is not None and float(maximum) <= 1.0:
                break
    if not candidates:
        raise RuntimeError("no physical refinement branch")
    best = min(candidates, key=lambda item: item[0])
    shutil.copy2(best[1], output)
    summary["selected"] = {
        "Rwp_percent": best[0],
        "path": str(best[1]),
        "branch": best[2],
        "pass": best[3],
        "output": str(output),
    }
    output.with_suffix(".complete.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary["selected"]), flush=True)


if __name__ == "__main__":
    main()
