#!/usr/bin/env python3
"""Settle the accepted phase model without refining clipped profile terms."""

from __future__ import annotations

import json
import math
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def install_bounds(project: G2.G2Project) -> None:
    project.index_ids()
    project.data["Controls"]["data"]["parmMinDict"] = {}
    project.data["Controls"]["data"]["parmMaxDict"] = {}
    for key, lower, upper in (
        ("Zero", -0.25, 0.25),
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.1),
    ):
        project.set_Controls("parmMin", lower, variable=f":0:{key}")
        project.set_Controls("parmMax", upper, variable=f":0:{key}")
    for phase in project.phases():
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 1000.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")


def configure(project: G2.G2Project) -> None:
    clear_flags(project)
    install_bounds(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for key in ("U", "W", "X"):
        hist.InstrumentParameters[key][2] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        # MnWO4 repeatedly requested a negative microstrain and Mn2WO6 a
        # sub-40 nm size. Keep those physical boundaries fixed, rather than
        # allowing GSAS to evaluate a clipped, non-replayable trial profile.
        if phase.name in {"WO3", "Mn2WO6"}:
            hap["Mustrain"][2][0] = True


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histograms()[0]
    values = {
        phase.name: max(
            0.0,
            float(phase.data["General"]["Mass"])
            * float(phase.data["Histograms"][hist.name]["Scale"][0]),
        )
        for phase in project.phases()
    }
    total = sum(values.values())
    return {name: value / total for name, value in values.items()}


def record(project: G2.G2Project, pass_index: int) -> dict:
    hist = project.histograms()[0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "pass": pass_index,
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "fractions": fractions(project),
        "instrument": {
            key: float(hist.InstrumentParameters[key][1])
            for key in ("Zero", "U", "V", "W", "X", "SH/L")
        },
        "sample": {
            key: value[0]
            for key, value in hist.SampleParameters.items()
            if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool)
        },
        "profiles": {
            phase.name: {
                "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "mustrain_ppm": float(
                    phase.data["Histograms"][hist.name]["Mustrain"][1][0]
                ),
            }
            for phase in project.phases()
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: settle_physical.py INPUT.gpx OUTPUT.gpx")
    source, output = map(Path, sys.argv[1:])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    summary = {"source": str(source.resolve()), "passes": []}
    for pass_index in range(1, 5):
        configure(project)
        project.set_Controls("cycles", 8)
        project.save()
        project.refine(makeBack=False)
        item = record(project, pass_index)
        summary["passes"].append(item)
        print(json.dumps(item, default=str), flush=True)
        if item["frozen"]:
            raise RuntimeError(f"clipped variables remain: {item['frozen']}")
        maximum = item["max_shift_esd"]
        if (
            item["converged"]
            and maximum is not None
            and math.isfinite(float(maximum))
            and float(maximum) <= 1.0
        ):
            break
    project.save(str(output))
    output.with_suffix(".settle.json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
