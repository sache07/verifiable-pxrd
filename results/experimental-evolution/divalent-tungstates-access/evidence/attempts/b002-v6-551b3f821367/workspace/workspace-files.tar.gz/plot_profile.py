#!/usr/bin/env python3
"""Render a profile saved by audit_model.py outside the GSAS environment."""

from __future__ import annotations

import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: plot_profile.py PROFILE.npz OUTPUT.png")
    values = np.load(sys.argv[1])
    x = values["two_theta"]
    fig, axes = plt.subplots(
        2, 1, figsize=(14, 8), sharex=True,
        gridspec_kw={"height_ratios": [3, 1]},
    )
    axes[0].plot(x, values["observed"], color="black", linewidth=0.55, label="Observed")
    axes[0].plot(x, values["calculated"], color="#c51b7d", linewidth=0.7, label="Calculated")
    axes[0].plot(x, values["background"], color="#4d9221", linewidth=0.5, label="Background")
    axes[0].set_ylabel("Counts")
    axes[0].legend(loc="upper right", frameon=False, ncol=3)
    axes[1].axhline(0, color="0.5", linewidth=0.5)
    axes[1].plot(x, values["difference"], color="#2166ac", linewidth=0.55)
    axes[1].set_ylabel("Obs. - calc.")
    axes[1].set_xlabel(r"$2\theta$ (degrees)")
    fig.tight_layout()
    fig.savefig(Path(sys.argv[2]), dpi=160)


if __name__ == "__main__":
    main()
