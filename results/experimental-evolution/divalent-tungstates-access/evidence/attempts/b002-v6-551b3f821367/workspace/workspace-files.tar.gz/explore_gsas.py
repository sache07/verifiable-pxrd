#!/usr/bin/env python3
"""Build an exploratory multiphase GSAS-II refinement.

Run only with the supplied GSAS-II Python. Arguments after the output project
are NAME=CIF phase specifications.
"""

from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


def fractions(project: G2.G2Project, hist: G2.G2PwdrData) -> dict[str, float]:
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted[phase.name] = max(
            0.0,
            float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]),
        )
    total = sum(weighted.values())
    return {key: value / total for key, value in weighted.items()} if total else weighted


def state(project: G2.G2Project, label: str) -> None:
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    print(
        json.dumps(
            {
                "stage": label,
                "Rwp_percent": float(hist.get_wR()),
                "fractions": fractions(project, hist),
                "cells": {p.name: p.get_cell() for p in project.phases()},
                "instrument": {
                    key: value[1]
                    for key, value in hist.InstrumentParameters.items()
                    if key in {"Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."}
                },
                "sample": {
                    key: value
                    for key, value in hist.SampleParameters.items()
                    if key in {"Shift", "SurfRoughA", "SurfRoughB"}
                },
                "converged": cov.get("Rvals", {}).get("converged"),
                "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
                "frozen": project.get_Frozen(),
            },
            default=str,
        ),
        flush=True,
    )


def refine(project: G2.G2Project, label: str, cycles: int = 8) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    state(project, label)


def main() -> None:
    if len(sys.argv) < 4:
        raise SystemExit("usage: explore_gsas.py OUTPUT.gpx NAME=CIF [NAME=CIF ...]")
    output = Path(sys.argv[1]).resolve()
    specs = []
    for token in sys.argv[2:]:
        name, source = token.split("=", 1)
        specs.append((name, Path(source).resolve()))

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(output))
    phases = [
        project.add_phase(str(source), phasename=name, fmthint="CIF")
        for name, source in specs
    ]
    hist = project.add_powder_histogram(
        str(Path("inputs/pattern.csv").resolve()),
        str(Path("instrument.instprm").resolve()),
        phases=phases,
        fmthint="comma/tab/semicolon",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    # The public scan has no supplied sigmas. Use the counting-statistics
    # weights employed by the independent profile check.
    arrays = hist.data["data"][1]
    arrays[2][:] = 1.0 / np.maximum(arrays[1], 1.0)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1200.0] + [0.0] * 11,
                "refine": False,
            }
        }
    )
    project.index_ids()
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        # GSAS-II's crystalline mass fractions are proportional to unit-cell
        # mass times HAP scale. A common 10,000 multiplier gives a sensible
        # starting intensity for these count data.
        hap["Scale"] = [
            10000.0 / len(phases) / max(float(phase.data["General"]["Mass"]), 1.0),
            False,
        ]
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 1000.0, variable=f"{pid}:0:Scale")
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")

    project.set_Controls("parmMin", -0.25, variable=":0:Zero")
    project.set_Controls("parmMax", 0.25, variable=":0:Zero")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    for key, lower, upper in (
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.1),
    ):
        project.set_Controls("parmMin", lower, variable=f":0:{key}")
        project.set_Controls("parmMax", upper, variable=f":0:{key}")

    project.set_Controls("cycles", 0)
    project.save()
    project.refine(makeBack=False)
    state(project, "initial")

    hist.Background[0][1] = True
    for phase in phases:
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    refine(project, "scale_background", 10)

    hist.InstrumentParameters["Zero"][2] = True
    refine(project, "zero", 8)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "cells", 10)

    for key in ("U", "W", "X"):
        hist.InstrumentParameters[key][2] = True
    refine(project, "instrument_profile", 10)

    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
    refine(project, "phase_size", 10)

    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = False
        hap["Mustrain"][2][0] = True
    refine(project, "phase_mustrain", 10)

    hist.InstrumentParameters["Zero"][2] = False
    for key in ("U", "W", "X"):
        hist.InstrumentParameters[key][2] = False
    for phase in phases:
        phase.data["Histograms"][hist.name]["Mustrain"][2] = [False, False, False]
    hist.SampleParameters["Shift"][1] = True
    refine(project, "shift_cells", 10)

    hist.SampleParameters["Shift"][1] = False
    hist.InstrumentParameters["SH/L"][2] = True
    refine(project, "axial_divergence", 8)

    # Return to a stable scale/background/cell state while retaining all
    # values. This project is exploratory and intentionally has no atom shifts.
    for phase in phases:
        phase.data["Histograms"][hist.name]["Size"][2] = [False, False, False]
        phase.data["Histograms"][hist.name]["Mustrain"][2] = [False, False, False]
    for key in ("U", "W", "X", "SH/L"):
        hist.InstrumentParameters[key][2] = False
    refine(project, "settle", 10)


if __name__ == "__main__":
    main()
