#!/usr/bin/env python3
"""Create all final deliverables from an independently replayed final.gpx."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"
REPLAY = ROOT / ".replay_final"


def main() -> None:
    replay = json.loads((REPLAY / "replay.json").read_text())
    if replay.get("status") != "replayed":
        raise RuntimeError(f"final project did not replay: {replay}")
    project_hash = hashlib.sha256(PROJECT.read_bytes()).hexdigest()
    if project_hash != replay["project_sha256"]:
        raise RuntimeError("final.gpx changed after independent replay")
    if replay.get("profile_review_flags"):
        raise RuntimeError(f"replay profile warnings: {replay['profile_review_flags']}")

    project = G2.G2Project(gpxfile=str(PROJECT))
    hist = project.histograms()[0]
    phase_objects = project.phases()
    if [phase.name for phase in phase_objects] != [phase["name"] for phase in replay["phases"]]:
        raise RuntimeError("project/replay phase ordering mismatch")

    names = {"MnWO4": "MnWO4.cif", "WO3": "WO3.cif", "Mn2WO6": "Mn2WO6.cif"}
    for index, phase in enumerate(replay["phases"]):
        shutil.copy2(REPLAY / phase["cif"], ROOT / names[phase["name"]])

    profile = np.load(REPLAY / "prediction.npz")
    x = np.asarray(profile["x"], dtype=float)
    observed = np.asarray(profile["observed"], dtype=float)
    calculated = np.asarray(profile["predicted"], dtype=float)
    difference = observed - calculated
    if np.any(calculated < 0) or not np.all(np.isfinite(calculated)):
        raise RuntimeError("invalid replayed profile")
    with (ROOT / "fit.csv").open("w") as stream:
        stream.write("two_theta_deg,observed,calculated,difference\n")
        for row in zip(x, observed, calculated, difference):
            stream.write(f"{row[0]:.8f},{row[1]:.10g},{row[2]:.12g},{row[3]:.12g}\n")

    weights = 1.0 / np.maximum(observed, 1.0)
    denominator = float(np.sum(weights * observed * observed))
    chi_square = float(np.sum(weights * difference * difference))
    covariance = project.data["Covariance"]["data"]["Rvals"]
    n_variables = int(covariance["Nvars"])
    degrees_of_freedom = len(x) - n_variables
    rwp = 100.0 * np.sqrt(chi_square / denominator)
    rp = 100.0 * np.sum(np.abs(difference)) / np.sum(observed)
    rexp = 100.0 * np.sqrt(degrees_of_freedom / denominator)
    gof = rwp / rexp

    formal = hist.ComputeMassFracs()
    source_info = {
        "MnWO4": {
            "formula": "MnWO4",
            "space_group": "P 2/c",
            "reference": "COD 1520200",
            "model_status": "exact-composition wolframite reference; cell and supported coordinates refined",
        },
        "WO3": {
            "formula": "WO3",
            "space_group": "P 21/c",
            "reference": "COD 2311041",
            "model_status": "exact-composition neutron-diffraction reference; cell refined",
        },
        "Mn2WO6": {
            "formula": "Mn2WO6",
            "space_group": "P 21 21 21",
            "reference": "Mn-substituted Y2WO6 analogue from COD 1541070",
            "model_status": "provisional analogue-derived atomic model; coordinates not independently determined",
        },
    }
    phases = []
    for phase, phase_object in zip(replay["phases"], phase_objects):
        name = phase["name"]
        fraction, sigma = formal[name]
        if abs(float(fraction) - float(phase["weight_fraction"])) > 1.0e-10:
            raise RuntimeError(f"fraction mismatch for {name}")
        cell = phase_object.get_cell()
        hap = phase_object.data["Histograms"][hist.name]
        phases.append(
            {
                "name": name,
                **source_info[name],
                "cif_path": names[name],
                "weight_fraction": float(phase["weight_fraction"]),
                "weight_fraction_formal_sigma": float(sigma),
                "refined_cell": {
                    "a_angstrom": float(cell["length_a"]),
                    "b_angstrom": float(cell["length_b"]),
                    "c_angstrom": float(cell["length_c"]),
                    "alpha_deg": float(cell["angle_alpha"]),
                    "beta_deg": float(cell["angle_beta"]),
                    "gamma_deg": float(cell["angle_gamma"]),
                    "volume_angstrom3": float(cell["volume"]),
                },
                "profile": {
                    "isotropic_size_micrometre": float(hap["Size"][1][0]),
                    "isotropic_microstrain_ppm": float(hap["Mustrain"][1][0]),
                },
            }
        )
    if abs(sum(phase["weight_fraction"] for phase in phases) - 1.0) > 1.0e-12:
        raise RuntimeError("phase fractions are not normalized")

    result = {
        "project_path": "final.gpx",
        "project_sha256": project_hash,
        "refinement_histogram": replay["histogram"],
        "fraction_basis": "normalized over the three modeled crystalline phases; amorphous material is not quantified",
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": float(rwp),
            "Rp_percent": float(rp),
            "Rexp_percent": float(rexp),
            "goodness_of_fit": float(gof),
            "chi_square": float(chi_square),
            "observations": int(len(x)),
            "refined_variables": n_variables,
            "degrees_of_freedom": int(degrees_of_freedom),
            "weighting": "1/max(observed_counts, 1)",
            "profile_source": "fresh native GSAS-II atomic forward replay of final.gpx on the complete observed grid",
        },
        "calibration": {
            "zero_offset_deg": float(hist.InstrumentParameters["Zero"][1]),
            "sample_displacement_micrometre": float(hist.SampleParameters["Shift"][0]),
            "wavelength_Kalpha1_angstrom": float(hist.InstrumentParameters["Lam1"][1]),
            "wavelength_Kalpha2_angstrom": float(hist.InstrumentParameters["Lam2"][1]),
            "Kalpha2_to_Kalpha1_ratio": float(hist.InstrumentParameters["I(L2)/I(L1)"][1]),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    by_name = {phase["name"]: phase for phase in phases}
    report = f"""# Powder XRD phase analysis

## Result

The crystalline pattern is modeled with three phases. Fractions are normalized only over these modeled crystalline phases.

| Phase | Structural model | Refined cell (Å, °) | Weight fraction |
|---|---|---|---:|
| MnWO4 | wolframite, P 2/c, COD 1520200 | a={by_name['MnWO4']['refined_cell']['a_angstrom']:.5f}, b={by_name['MnWO4']['refined_cell']['b_angstrom']:.5f}, c={by_name['MnWO4']['refined_cell']['c_angstrom']:.5f}, beta={by_name['MnWO4']['refined_cell']['beta_deg']:.4f} | {100*by_name['MnWO4']['weight_fraction']:.2f}% |
| WO3 | monoclinic, P 21/c, neutron model COD 2311041 | a={by_name['WO3']['refined_cell']['a_angstrom']:.5f}, b={by_name['WO3']['refined_cell']['b_angstrom']:.5f}, c={by_name['WO3']['refined_cell']['c_angstrom']:.5f}, beta={by_name['WO3']['refined_cell']['beta_deg']:.4f} | {100*by_name['WO3']['weight_fraction']:.2f}% |
| Mn2WO6 | orthorhombic, P 21 21 21, Mn-substituted Y2WO6 analogue (COD 1541070 parent) | a={by_name['Mn2WO6']['refined_cell']['a_angstrom']:.5f}, b={by_name['Mn2WO6']['refined_cell']['b_angstrom']:.5f}, c={by_name['Mn2WO6']['refined_cell']['c_angstrom']:.5f} | {100*by_name['Mn2WO6']['weight_fraction']:.2f}% |

Fresh forward replay of `final.gpx` over all 8301 points gives Rwp={rwp:.3f}%, Rp={rp:.3f}%, Rexp={rexp:.3f}%, and goodness-of-fit={gof:.3f}. The relatively high goodness-of-fit reflects systematic profile/intensity mismatch and the absence of supplied pointwise uncertainties; counting-statistics weights, 1/max(Iobs,1), were used.

## Evidence

- The precursor context (Mn3O4 + WO3, heated at 800 °C in reflection geometry with Cu Kalpha radiation) restricts the ordinary chemistry to Mn-W-O. Wolframite MnWO4 indexes the dominant sharp reflection family and refines to a conventional wolframite cell.
- Residual peaks at approximately 23.1, 23.6, 26.5, 28.6-28.9, 33.5, and 34.1° are accounted for by monoclinic WO3. The submitted neutron-derived COD 2311041 model was chosen over a coarse older coordinate set that produced an implausible 1.58 Å fully occupied O-O contact; all submitted CIFs pass the contact and occupancy screen.
- A broad, coherent family at approximately 19.86, 20.41, 28.64, 35.11, 46.49, 54.45, 55.30, 56.49, 59.35, and 66.41° requires the third phase. It is indexed by an orthorhombic P 21 21 21 Mn2WO6 cell obtained by chemically supported Mn-for-Y transfer from Y2WO6 (COD 1541070). Exact Mn oxides/precursors tested against this family did not retain a stable, broadly supported positive contribution.
- The remaining major difference features are centered on accepted reflections or fall inside the broad Mn2WO6 profiles; no additional coherent reflection family remains. Preferred-orientation trials were non-unique or bound-limited and were not retained.

## Uncertainty and model limits

The MnWO4 and WO3 identifications and cells are reliable. The formal one-sigma mass-fraction uncertainties from the least-squares covariance matrix are {100*by_name['MnWO4']['weight_fraction_formal_sigma']:.2f}, {100*by_name['WO3']['weight_fraction_formal_sigma']:.2f}, and {100*by_name['Mn2WO6']['weight_fraction_formal_sigma']:.2f} percentage points, respectively, but they omit phase-model and profile-systematic error.

The detailed Mn2WO6 atomic coordinates cannot be determined reliably from this pattern. Its isotropic size is at the imposed 0.040 micrometre floor and its microstrain is about {by_name['Mn2WO6']['profile']['isotropic_microstrain_ppm']:.0f} ppm; coordinate and texture trials were bound-limited. Thus the P 21 21 21 indexing and an approximately 14% crystalline contribution are supported, while the submitted analogue-derived coordinates are provisional and the fraction should be regarded as semiquantitative (systematic uncertainty of several absolute percentage points is plausible).

The supplied staged polish was run once. Its valid branches agreed after rollback of clipped atoms; small physical MnWO4 coordinate shifts were retained. A polished branch using the coarse WO3 reference was rejected on geometry, and the final project was re-settled with the physical neutron WO3 model without repeating the staged polish. No amorphous fraction can be obtained without an internal standard, so the reported fractions sum to 100% only over modeled crystalline material.
"""
    (ROOT / "report.md").write_text(report)


if __name__ == "__main__":
    main()
