#!/usr/bin/env python3
"""Screen bounded single-phase March-Dollase corrections on an accepted model."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

from settle_physical import clear_flags, fractions


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def configure(project: G2.G2Project, target_name: str, axis: list[int]) -> None:
    clear_flags(project)
    project.index_ids()
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        if phase.name == target_name:
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(axis)
            variable = f"{phase.data['pId']}:0:MD"
            project.set_Controls("parmMin", 0.7, variable=variable)
            project.set_Controls("parmMax", 1.4, variable=variable)


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: test_texture.py INPUT.gpx OUTPUT_DIR")
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    output.mkdir(exist_ok=True)
    G2.SetPrintLevel("warn")
    baseline = G2.G2Project(gpxfile=str(source))
    summary = {"source": str(source), "baseline_Rwp_percent": baseline.histograms()[0].get_wR(), "branches": []}
    phase_names = [phase.name for phase in baseline.phases()]
    for phase_name in phase_names:
        for axis in AXES:
            label = phase_name + "_" + "".join(str(v) for v in axis)
            path = output / f"{label}.gpx"
            project = G2.G2Project(gpxfile=str(source), newgpx=str(path))
            hist = project.histograms()[0]
            target = project.phase(phase_name)
            target.data["Histograms"][hist.name]["Pref.Ori."][1] = 1.0
            passes = []
            for pass_index in range(1, 3):
                configure(project, phase_name, list(axis))
                project.set_Controls("cycles", 6)
                project.save()
                project.refine(makeBack=False)
                rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
                item = {
                    "pass": pass_index,
                    "Rwp_percent": float(hist.get_wR()),
                    "MD_ratio": float(target.data["Histograms"][hist.name]["Pref.Ori."][1]),
                    "max_shift_esd": rvals.get("Max shft/sig"),
                    "converged": bool(rvals.get("converged", False)),
                    "frozen": list(project.get_Frozen()),
                    "fractions": fractions(project),
                }
                passes.append(item)
                maximum = item["max_shift_esd"]
                if item["converged"] and maximum is not None and float(maximum) <= 1.0:
                    break
            project.save(str(path))
            branch = {
                "phase": phase_name,
                "axis": list(axis),
                "path": str(path),
                "passes": passes,
                **passes[-1],
            }
            summary["branches"].append(branch)
            print(json.dumps(branch), flush=True)
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
