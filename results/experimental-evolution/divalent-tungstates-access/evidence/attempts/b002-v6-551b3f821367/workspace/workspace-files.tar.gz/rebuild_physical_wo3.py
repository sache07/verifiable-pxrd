#!/usr/bin/env python3
"""Replace the coarse 1960 WO3 coordinates with a physical neutron model."""

from __future__ import annotations

import copy
import json
import math
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

from settle_physical import clear_flags, fractions, install_bounds


ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif")
PHASES = (
    ("MnWO4", ROOT / "1/52/02/1520200.cif"),
    ("WO3", ROOT / "2/31/10/2311041.cif"),
    ("Mn2WO6", Path("analogues/Mn2WO6_from_Y2WO6_1541070.cif")),
)


def configure(project: G2.G2Project) -> None:
    clear_flags(project)
    install_bounds(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for key in ("U", "W", "X"):
        hist.InstrumentParameters[key][2] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        if phase.name in {"WO3", "Mn2WO6"}:
            hap["Mustrain"][2][0] = True


def state(project: G2.G2Project, stage: str) -> dict:
    hist = project.histograms()[0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "fractions": fractions(project),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "profiles": {
            phase.name: {
                "size_um": phase.data["Histograms"][hist.name]["Size"][1][0],
                "mustrain_ppm": phase.data["Histograms"][hist.name]["Mustrain"][1][0],
            }
            for phase in project.phases()
        },
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
    }


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: rebuild_physical_wo3.py SOURCE_POLISHED.gpx OUTPUT.gpx")
    source_path, output_path = map(Path, sys.argv[1:])
    G2.SetPrintLevel("warn")
    source = G2.G2Project(gpxfile=str(source_path))
    old_hist = source.histograms()[0]
    old_phases = {phase.name: phase for phase in source.phases()}

    project = G2.G2Project(newgpx=str(output_path))
    phases = [
        project.add_phase(str(path.resolve()), phasename=name, fmthint="CIF")
        for name, path in PHASES
    ]
    hist = project.add_powder_histogram(
        str(Path("inputs/pattern.csv").resolve()),
        str(Path("instrument.instprm").resolve()),
        phases=phases,
        fmthint="comma/tab/semicolon",
    )
    # Carry over the independently replayed nuisance model and exact weights.
    for key in ("Background", "Instrument Parameters", "Sample Parameters", "Limits"):
        hist.data[key] = copy.deepcopy(old_hist.data[key])
    arrays = hist.data["data"][1]
    arrays[2][:] = 1.0 / np.maximum(arrays[1], 1.0)

    for phase in phases:
        old_phase = old_phases[phase.name]
        old_hap = old_phase.data["Histograms"][old_hist.name]
        new_hap = phase.data["Histograms"][hist.name]
        for key in (
            "Scale", "Size", "Mustrain", "Pref.Ori.", "HStrain",
            "Extinction", "Babinet", "Use", "LeBail",
        ):
            if key in old_hap:
                new_hap[key] = copy.deepcopy(old_hap[key])
        # Retain the accepted polished MnWO4 coordinates and the unchanged
        # analogue Mn2WO6 coordinates. WO3 instead uses COD 2311041 exactly.
        if phase.name != "WO3":
            phase.data["General"]["Cell"] = copy.deepcopy(old_phase.data["General"]["Cell"])
            old_atoms = {atom.label: atom for atom in old_phase.atoms()}
            for atom in phase.atoms():
                atom.coordinates = old_atoms[atom.label].coordinates
                atom.refinement_flags = " "

    records = []
    for pass_index in range(1, 5):
        configure(project)
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        item = state(project, f"settle_{pass_index}")
        records.append(item)
        print(json.dumps(item, default=str), flush=True)
        if item["frozen"]:
            raise RuntimeError(f"clipped variables in physical WO3 rebuild: {item['frozen']}")
        maximum = item["max_shift_esd"]
        if (
            item["converged"]
            and maximum is not None
            and math.isfinite(float(maximum))
            and float(maximum) <= 1.0
        ):
            break
    clear_flags(project)
    project.save(str(output_path))
    output_path.with_suffix(".rebuild.json").write_text(
        json.dumps({"source": str(source_path.resolve()), "passes": records}, indent=2)
        + "\n"
    )


if __name__ == "__main__":
    main()
