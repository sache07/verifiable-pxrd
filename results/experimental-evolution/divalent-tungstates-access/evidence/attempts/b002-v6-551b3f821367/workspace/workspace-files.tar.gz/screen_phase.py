#!/usr/bin/env python3
"""Add one phase to a converged checkpoint and screen its stable scale/cell."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"].get(hist.name)
        if not hap:
            continue
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histograms()[0]
    values = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        values[phase.name] = max(
            0.0, float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        )
    total = sum(values.values())
    return {key: value / total for key, value in values.items()}


def main() -> None:
    if len(sys.argv) != 6:
        raise SystemExit(
            "usage: screen_phase.py BASE.gpx OUT.gpx NAME CIF REFINE_ALL_CELLS[0|1]"
        )
    base, output, name, cif, all_cells = sys.argv[1:]
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=base, newgpx=output)
    clear_flags(project)
    hist = project.histograms()[0]
    phase = project.add_phase(
        str(Path(cif).resolve()), phasename=name, histograms=[hist], fmthint="CIF"
    )
    project.index_ids()
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [500.0 / max(float(phase.data["General"]["Mass"]), 1.0), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.3
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    project.set_Controls("parmMin", 0.0, variable=f"{phase.data['pId']}:0:Scale")
    project.set_Controls("parmMax", 1000.0, variable=f"{phase.data['pId']}:0:Scale")
    project.set_Controls("parmMin", 0.04, variable=f"{phase.data['pId']}:0:Size;i")
    project.set_Controls("parmMax", 1.5, variable=f"{phase.data['pId']}:0:Size;i")
    project.set_Controls("parmMin", 0.0, variable=f"{phase.data['pId']}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{phase.data['pId']}:0:Mustrain;i")
    hist.Background[0][1] = True
    for item in project.phases():
        item.data["Histograms"][hist.name]["Scale"][1] = True
        if bool(int(all_cells)) or item.name == phase.name:
            item.set_refinements({"Cell": True})
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 12)
    project.save()
    project.refine(makeBack=False)

    # Bounded profile passes for the added phase, followed by a cell/scale settle.
    hap["Size"][2][0] = True
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2][0] = True
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    hap["Mustrain"][2] = [False, False, False]
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.save()
    print(
        json.dumps(
            {
                "name": name,
                "Rwp_percent": float(hist.get_wR()),
                "fractions": fractions(project),
                "cell": phase.get_cell(),
                "size": hap["Size"][1],
                "mustrain": hap["Mustrain"][1],
                "frozen": project.get_Frozen(),
                "convergence": project.data.get("Covariance", {})
                .get("data", {})
                .get("Rvals", {}),
            },
            default=str,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
