#!/usr/bin/env python3
"""Export the accepted, immutable GSAS-II project into submission artifacts."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"
REPLAY = ROOT / "work_branches" / "replay_final"
EXPORTS = {
    "CuWO4": ("CuWO4", "CuWO4.cif", "4000806"),
    "Cu3WO6": ("Cu3WO6", "Cu3WO6.cif", "1527404"),
    "WO3_2311041": ("WO3", "WO3.cif", "2311041"),
    "CuO_1011194": ("CuO", "CuO.cif", "1011194"),
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    before = sha256(PROJECT)
    replay = json.loads((REPLAY / "replay.json").read_text())
    if replay.get("status") != "replayed" or replay.get("project_sha256") != before:
        raise RuntimeError("independent replay does not match final.gpx")

    project = G2.G2Project(gpxfile=str(PROJECT))
    histogram = project.histogram(0)
    fractions = histogram.ComputeMassFracs()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    summary = histogram.data["data"][0]

    rows = []
    for phase in project.phases():
        formula, filename, cod_id = EXPORTS[phase.name]
        phase.export_CIF(str(ROOT / filename))
        fraction, esd = fractions[phase.name]
        rows.append({
            "name": formula,
            "project_phase": phase.name,
            "formula": formula,
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": filename,
            "weight_fraction": float(fraction),
            "weight_fraction_esd": float(esd),
            "reference": {"database": "COD", "id": cod_id},
        })

    profile = np.load(REPLAY / "prediction.npz")
    x = np.asarray(profile["x"], float)
    observed = np.asarray(profile["observed"], float)
    calculated = np.asarray(profile["predicted"], float)
    difference = observed - calculated
    public = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1, ndmin=2)
    if not (np.allclose(x, public[:, 0], rtol=0, atol=1e-9) and np.allclose(observed, public[:, 1], rtol=0, atol=1e-9)):
        raise RuntimeError("replayed profile does not cover the original observations")
    if np.any(~np.isfinite(calculated)) or np.any(calculated < 0):
        raise RuntimeError("invalid calculated profile")
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(["two_theta", "observed", "calculated", "difference"])
        for values in zip(x, observed, calculated, difference):
            writer.writerow([f"{value:.8f}" for value in values])

    weights = 1.0 / np.maximum(observed, 1.0)
    rwp = 100.0 * np.sqrt(np.sum(weights * difference**2) / np.sum(weights * observed**2))
    rp = 100.0 * np.sum(np.abs(difference)) / np.sum(observed)
    result = {
        "project_path": "final.gpx",
        "project_sha256": before,
        "refinement_histogram": histogram.name,
        "fraction_basis": "normalized over the four modeled crystalline phases",
        "phases": rows,
        "unresolved_components": [],
        "fit_statistics": {
            "Rwp_percent": float(rwp),
            "Rp_percent": float(rp),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "noise_floor_Rwp_percent": float(summary["wRmin"]),
            "Durbin_Watson": float(summary["Durbin-Watson"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_variables": int(rvals["Nvars"]),
        },
        "calibration": {
            "zero_deg": float(histogram.InstrumentParameters["Zero"][1]),
            "specimen_displacement_um": float(histogram.SampleParameters["Shift"][0]),
        },
        "polish": {
            "procedure": "learned/staged_polish.py",
            "selected_branch": "phasewise",
            "audit_path": "polished.staged_polish.json",
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    after = sha256(PROJECT)
    if after != before:
        raise RuntimeError("final.gpx changed during export")
    print(json.dumps({"project_sha256": after, "phases": rows, "fit_statistics": result["fit_statistics"]}, indent=2))


if __name__ == "__main__":
    main()
