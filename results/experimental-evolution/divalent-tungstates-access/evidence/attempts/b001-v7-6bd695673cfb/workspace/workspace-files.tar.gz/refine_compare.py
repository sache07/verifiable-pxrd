#!/usr/bin/env python3
"""Build equally developed exploratory GSAS-II branches for WO3 references."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
INSTRUMENT = ROOT / "instrument.instprm"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "stage": label,
        "Rwp_percent": hist.get_wR(),
        "converged": cov.get("Rvals", {}).get("converged"),
        "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "instrument": {
            k: v[1] for k, v in hist.InstrumentParameters.items()
            if isinstance(v, list) and len(v) > 1 and k in {"Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."}
        },
        "sample": {
            k: v[0] for k, v in hist.SampleParameters.items()
            if isinstance(v, list) and k in {"Shift", "SurfRoughA", "SurfRoughB"}
        },
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "scales": {
            p.name: p.data["Histograms"][hist.name]["Scale"][0]
            for p in project.phases()
        },
    }


def refine(project: G2.G2Project, label: str, records: list[dict], cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    row = state(project, label)
    records.append(row)
    print(json.dumps(row), flush=True)


def configure_project(wo3_id: str, out: Path) -> G2.G2Project:
    project = G2.G2Project(newgpx=str(out))
    phases = [
        project.add_phase(str(cif_path("4000806")), phasename="CuWO4", fmthint="CIF"),
        project.add_phase(str(cif_path("1527404")), phasename="Cu3WO6", fmthint="CIF"),
        project.add_phase(str(cif_path(wo3_id)), phasename=f"WO3_{wo3_id}", fmthint="CIF"),
    ]
    hist = project.add_powder_histogram(
        str(PATTERN), str(INSTRUMENT), phases=phases,
        fmthint="comma/tab/semicolon separated",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [750.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 8,
            "coeffs": [2500.0, -1500.0, 300.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            "refine": True,
        }
    })
    # Put all phases in a comparable intensity basin before scale refinement.
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1000.0 / phase.data["General"]["Mass"], True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    project.save()
    return project


def run_branch(wo3_id: str) -> dict:
    outdir = ROOT / "work_branches"
    outdir.mkdir(exist_ok=True)
    out = outdir / f"wo3_{wo3_id}.gpx"
    project = configure_project(wo3_id, out)
    hist = project.histogram(0)
    records: list[dict] = []

    # Intensity/background first at a physically close fixed calibration.
    refine(project, "scale_background", records)

    # Refine all phase cells against the common peak-position correction.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, "cells", records)

    # Common zero and specimen displacement are the only position corrections.
    hist.set_refinements({
        "Instrument Parameters": ["Zero"],
        "Sample Parameters": ["Shift"],
    })
    project.set_Controls("parmMin", -0.25, variable=":0:Zero")
    project.set_Controls("parmMax", 0.25, variable=":0:Zero")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    refine(project, "cells_calibration", records, cycles=12)

    summary = {"wo3_id": wo3_id, "project": str(out), "stages": records}
    (outdir / f"wo3_{wo3_id}.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


def main() -> None:
    ids = sys.argv[1:] or ["2311041"]
    G2.SetPrintLevel("error")
    summaries = [run_branch(i) for i in ids]
    print(json.dumps({"completed": [s["wo3_id"] for s in summaries]}))


if __name__ == "__main__":
    main()
