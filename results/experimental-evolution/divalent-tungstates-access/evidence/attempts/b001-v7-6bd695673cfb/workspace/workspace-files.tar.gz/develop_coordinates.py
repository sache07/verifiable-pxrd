#!/usr/bin/env python3
"""Apply the same bounded structural checkpoint to candidate WO3 branches."""

from __future__ import annotations

import json
from pathlib import Path
import re
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BOUND_A = 0.10
COORD_RE = re.compile(r"^(\d+)::dA[xyz]:(\d+)$")


def clear_frozen(project: G2.G2Project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def freeze_all(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def enable_intensity_baseline(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def install_coordinate_bounds(project: G2.G2Project) -> dict[tuple[int, int], tuple[float, float, float]]:
    project.index_ids()
    source = {}
    for phase in project.phases():
        pid = int(phase.data["pId"])
        cell = phase.get_cell()
        lengths = [float(cell[f"length_{axis}"]) for axis in "abc"]
        for index, atom in enumerate(phase.atoms()):
            source[(pid, index)] = tuple(float(v) for v in atom.coordinates)
            for axis, value, length in zip("xyz", atom.coordinates, lengths):
                half = BOUND_A / length
                var = f"{pid}::dA{axis}:{index}"
                project.set_Controls("parmMin", float(value) - half, variable=var)
                project.set_Controls("parmMax", float(value) + half, variable=var)
    return source


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    try:
        values = hist.ComputeMassFracs()
        if values:
            return {str(k): float(v[0]) for k, v in values.items()}
    except Exception:
        pass
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted[phase.name] = max(0.0, float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]))
    total = sum(weighted.values())
    return {k: v / total for k, v in weighted.items()}


def record(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "fractions": fractions(project),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }


def run(project: G2.G2Project, stage: str, records: list[dict], cycles: int) -> None:
    clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    row = record(project, stage)
    records.append(row)
    print(json.dumps(row), flush=True)


def set_coordinate_flags(project: G2.G2Project, mode: str) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            oxygen = atom.element.strip().upper().startswith("O")
            active = mode == "all" or (mode == "oxygen" and oxygen) or (mode == "heavy" and not oxygen)
            atom.refinement_flags = "X" if active else " "


def develop(cod_id: str) -> None:
    source_path = ROOT / "work_branches" / f"wo3_{cod_id}.gpx"
    output_path = ROOT / "work_branches" / f"wo3_{cod_id}_coords.gpx"
    project = G2.G2Project(gpxfile=str(source_path), newgpx=str(output_path))
    records: list[dict] = []

    freeze_all(project)
    enable_intensity_baseline(project)
    # The generator uses one isotropic Uiso per phase; use the midpoint for an
    # unbiased fixed checkpoint during coordinate comparison.
    for phase in project.phases():
        for atom in phase.atoms():
            if atom.adp_flag == "I":
                atom.uiso = 0.010
    install_coordinate_bounds(project)

    set_coordinate_flags(project, "heavy")
    run(project, "heavy_coordinates", records, 10)
    set_coordinate_flags(project, "oxygen")
    run(project, "oxygen_coordinates", records, 12)
    set_coordinate_flags(project, "all")
    run(project, "joint_coordinates", records, 10)

    # Compare candidates after the same complete structural adaptation and a
    # common cell/calibration settle, with all coordinates fixed at that point.
    freeze_all(project)
    enable_intensity_baseline(project)
    hist = project.histogram(0)
    hist.InstrumentParameters["Zero"][2] = True
    hist.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run(project, "cell_calibration_settle", records, 12)

    summary = {"wo3_id": cod_id, "source": str(source_path), "project": str(output_path), "stages": records}
    output_path.with_suffix(".json").write_text(json.dumps(summary, indent=2) + "\n")


def main() -> None:
    if len(sys.argv) < 2:
        raise SystemExit("usage: develop_coordinates.py COD_ID [COD_ID ...]")
    G2.SetPrintLevel("error")
    for cod_id in sys.argv[1:]:
        develop(cod_id)


if __name__ == "__main__":
    main()
