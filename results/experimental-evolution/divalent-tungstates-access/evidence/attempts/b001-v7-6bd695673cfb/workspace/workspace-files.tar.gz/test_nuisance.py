#!/usr/bin/env python3
"""Run one bounded nuisance-term branch from the accepted structural base."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def freeze(p):
    h = p.histogram(0)
    h.Background[0][1] = False
    for v in h.InstrumentParameters.values():
        if isinstance(v, list) and len(v) > 2:
            v[2] = False
    for v in h.SampleParameters.values():
        if isinstance(v, list) and len(v) > 1 and isinstance(v[1], bool):
            v[1] = False
    for ph in p.phases():
        ph.set_refinements({"Cell": False})
        for atom in ph.atoms():
            atom.refinement_flags = " "
        hap = ph.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def baseline(p):
    h = p.histogram(0)
    h.Background[0][1] = True
    for ph in p.phases():
        ph.data["Histograms"][h.name]["Scale"][1] = True


def main():
    if len(sys.argv) < 5:
        raise SystemExit("usage: test_nuisance.py INPUT.gpx OUTPUT.gpx MODE ARGS...")
    src, out, mode = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
    G2.SetPrintLevel("error")
    p = G2.G2Project(gpxfile=str(src.resolve()), newgpx=str(out.resolve()))
    h = p.histogram(0)
    h.InstrumentParameters["Polariz."][1] = 0.75
    freeze(p)
    baseline(p)

    detail = {"mode": mode}
    if mode == "roughness":
        a0, b0 = map(float, sys.argv[4:6])
        h.SampleParameters["SurfRoughA"] = [a0, True]
        h.SampleParameters["SurfRoughB"] = [b0, True]
        p.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
        p.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
        p.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        p.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
        detail.update(start_A=a0, start_B=b0)
    elif mode == "texture":
        phase_index = int(sys.argv[4])
        axis = [int(v) for v in sys.argv[5].split(",")]
        start = float(sys.argv[6])
        ph = p.phases()[phase_index]
        hap = ph.data["Histograms"][h.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = start
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
        p.index_ids()
        pid = int(ph.data["pId"])
        p.set_Controls("parmMin", 0.70, variable=f"{pid}:0:MD")
        p.set_Controls("parmMax", 1.40, variable=f"{pid}:0:MD")
        detail.update(phase_index=phase_index, phase=ph.name, axis=axis, start=start)
    elif mode == "strain":
        phase_index = int(sys.argv[4])
        axis = [int(v) for v in sys.argv[5].split(",")]
        ratio = float(sys.argv[6])
        ph = p.phases()[phase_index]
        hap = ph.data["Histograms"][h.name]
        base = float(hap["Mustrain"][1][0])
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][1] = base * ratio
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        hap["Mustrain"][3] = axis
        p.index_ids()
        pid = int(ph.data["pId"])
        p.set_Controls("parmMin", 300.0, variable=f"{pid}:0:Mustrain;i")
        p.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
        p.set_Controls("parmMin", 75.0, variable=f"{pid}:0:Mustrain;a")
        p.set_Controls("parmMax", 32000.0, variable=f"{pid}:0:Mustrain;a")
        detail.update(phase_index=phase_index, phase=ph.name, axis=axis, start_ratio=ratio)
    else:
        raise SystemExit(f"unknown mode {mode}")

    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    p.set_Controls("cycles", 15)
    p.save()
    p.refine(makeBack=False)
    p.save()
    rv = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    result = {
        **detail,
        "Rwp_percent": float(h.get_wR()),
        "converged": bool(rv.get("converged", False)),
        "max_shift_esd": rv.get("Max shft/sig"),
        "frozen": [str(v) for v in p.get_Frozen()],
    }
    if mode == "roughness":
        result.update(A=float(h.SampleParameters["SurfRoughA"][0]), B=float(h.SampleParameters["SurfRoughB"][0]))
    elif mode == "texture":
        hap = p.phases()[detail["phase_index"]].data["Histograms"][h.name]
        result.update(ratio=float(hap["Pref.Ori."][1]))
    else:
        hap = p.phases()[detail["phase_index"]].data["Histograms"][h.name]
        equatorial = float(hap["Mustrain"][1][0])
        axial = float(hap["Mustrain"][1][1])
        result.update(equatorial_ppm=equatorial, axial_ppm=axial, ratio=axial/equatorial)
    out.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
