#!/usr/bin/env python3
"""Settle the supported four-phase profile (WO3 [001] strain only)."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def freeze(project):
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def flags(project):
    hist = project.histogram(0)
    hist.Background[0][1] = True
    project.index_ids()
    for index, phase in enumerate(project.phases()):
        pid = int(phase.data["pId"])
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        if index < 3:
            hap["Size"][2][0] = True
            project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
            project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 300.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
        if index == 2:
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][3] = [0, 0, 1]
            hap["Mustrain"][2][1] = True
            project.set_Controls("parmMin", 75.0, variable=f"{pid}:0:Mustrain;a")
            project.set_Controls("parmMax", 32000.0, variable=f"{pid}:0:Mustrain;a")
        else:
            hap["Mustrain"][0] = "isotropic"
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["SH/L"][2] = True
    project.set_Controls("parmMin", 2.0, variable=":0:W")
    project.set_Controls("parmMax", 40.0, variable=":0:W")
    project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.10, variable=":0:SH/L")


def fractions(project):
    hist = project.histogram(0)
    raw = [
        max(0.0, float(phase.data["General"]["Mass"]) * float(phase.data["Histograms"][hist.name]["Scale"][0]))
        for phase in project.phases()
    ]
    total = sum(raw)
    return {phase.name: value / total for phase, value in zip(project.phases(), raw)}


def values(project):
    hist = project.histogram(0)
    rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rv.get("converged", False)),
        "max_shift_esd": rv.get("Max shft/sig"),
        "frozen": [str(item) for item in project.get_Frozen()],
        "fractions": fractions(project),
        "W": float(hist.InstrumentParameters["W"][1]),
        "SH_L": float(hist.InstrumentParameters["SH/L"][1]),
        "profiles": {
            phase.name: {
                "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "strain_type": phase.data["Histograms"][hist.name]["Mustrain"][0],
                "strain_ppm": [float(v) for v in phase.data["Histograms"][hist.name]["Mustrain"][1][:2]],
            }
            for phase in project.phases()
        },
    }


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: settle_supported_profile.py INPUT.gpx OUTPUT.gpx")
    G2.SetPrintLevel("error")
    output = Path(sys.argv[2]).resolve()
    project = G2.G2Project(gpxfile=str(Path(sys.argv[1]).resolve()), newgpx=str(output))
    records = []
    freeze(project); flags(project)
    for cycle in range(1, 5):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 15)
        project.save(); project.refine(makeBack=False); project.save()
        row = {"stage": f"supported_profile_{cycle}", **values(project)}
        records.append(row); print(json.dumps(row), flush=True)
        if row["converged"] and row["max_shift_esd"] is not None and float(row["max_shift_esd"]) <= 1 and not row["frozen"]:
            break
    freeze(project); project.save()
    output.with_suffix(".json").write_text(json.dumps({"records": records, "final": values(project)}, indent=2) + "\n")


if __name__ == "__main__":
    main()
