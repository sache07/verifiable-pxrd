#!/usr/bin/env python3
"""Profile branch with confounded X fixed at its physical lower anchor."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def clear_frozen(p):
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def freeze(p):
    h = p.histogram(0)
    h.Background[0][1] = False
    for v in h.InstrumentParameters.values():
        if isinstance(v, list) and len(v) > 2:
            v[2] = False
    for v in h.SampleParameters.values():
        if isinstance(v, list) and len(v) > 1 and isinstance(v[1], bool):
            v[1] = False
    for ph in p.phases():
        ph.set_refinements({"Cell": False})
        for a in ph.atoms():
            a.refinement_flags = " "
        hap = ph.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def baseline(p):
    h = p.histogram(0)
    h.Background[0][1] = True
    for ph in p.phases():
        ph.data["Histograms"][h.name]["Scale"][1] = True


def absorb_scale(p):
    h = p.histogram(0)
    s = float(h.SampleParameters["Scale"][0])
    for ph in p.phases():
        ph.data["Histograms"][h.name]["Scale"][0] *= s
    h.SampleParameters["Scale"] = [1.0, False]


def add_profile_flags(p):
    h = p.histogram(0)
    p.index_ids()
    for ph in p.phases():
        pid = int(ph.data["pId"])
        hap = ph.data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][2][0] = True
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2][0] = True
        p.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        p.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        p.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        p.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")


def values(p):
    h = p.histogram(0)
    weights = {ph.name: max(0.0, float(ph.data["General"]["Mass"]) * float(ph.data["Histograms"][h.name]["Scale"][0])) for ph in p.phases()}
    total = sum(weights.values())
    return {
        "fractions": {k: v / total for k, v in weights.items()},
        "instrument": {k: float(h.InstrumentParameters[k][1]) for k in ("U", "W", "X", "SH/L")},
        "phases": {ph.name: {
            "size_um": float(ph.data["Histograms"][h.name]["Size"][1][0]),
            "microstrain_ppm": float(ph.data["Histograms"][h.name]["Mustrain"][1][0]),
        } for ph in p.phases()},
    }


def run(p, stage, records, cycles):
    clear_frozen(p)
    p.set_Controls("cycles", cycles)
    p.save()
    p.refine(makeBack=False)
    p.save()
    rv = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    row = {"stage": stage, "Rwp_percent": float(p.histogram(0).get_wR()),
           "converged": bool(rv.get("converged", False)), "max_shift_esd": rv.get("Max shft/sig"),
           "frozen": [str(x) for x in p.get_Frozen()], **values(p)}
    records.append(row)
    print(json.dumps(row), flush=True)


def develop(cid):
    src = ROOT / "work_branches" / f"wo3_{cid}.gpx"
    out = ROOT / "work_branches" / f"wo3_{cid}_profile_joint.gpx"
    p = G2.G2Project(gpxfile=str(src), newgpx=str(out))
    h = p.histogram(0)
    absorb_scale(p)
    freeze(p)
    baseline(p)
    for ph in p.phases():
        for a in ph.atoms():
            if a.adp_flag == "I":
                a.uiso = 0.010
        hap = ph.data["Histograms"][h.name]
        hap["Size"][1][0] = 0.30
        hap["Mustrain"][1][0] = 500.0

    # X and isotropic size have the same 1/cos(theta) dependence. Anchor X at
    # the supplied lower physical value and let bounded phase sizes represent
    # the observable total; do not refine both correlated alternatives.
    h.InstrumentParameters["U"][1] = 0.0
    h.InstrumentParameters["W"][1] = 2.0
    h.InstrumentParameters["X"][1] = 0.1
    h.InstrumentParameters["SH/L"][1] = 0.03
    add_profile_flags(p)
    run(p, "phase_profile_from_minimum_instrument", [], 15)

    records = []
    freeze(p)
    baseline(p)
    add_profile_flags(p)
    h.InstrumentParameters["U"][2] = True
    h.InstrumentParameters["W"][2] = True
    h.InstrumentParameters["SH/L"][2] = True
    p.set_Controls("parmMin", 0.0, variable=":0:U")
    p.set_Controls("parmMax", 40.0, variable=":0:U")
    p.set_Controls("parmMin", 2.0, variable=":0:W")
    p.set_Controls("parmMax", 40.0, variable=":0:W")
    p.set_Controls("parmMin", 0.005, variable=":0:SH/L")
    p.set_Controls("parmMax", 0.10, variable=":0:SH/L")
    run(p, "joint_identifiable_profile", records, 20)

    freeze(p)
    baseline(p)
    add_profile_flags(p)
    h.InstrumentParameters["Zero"][2] = True
    h.SampleParameters["Shift"][1] = True
    for ph in p.phases():
        ph.set_refinements({"Cell": True})
    run(p, "profile_cell_calibration_settle", records, 15)
    out.with_suffix(".json").write_text(json.dumps({"wo3_id": cid, "source": str(src), "project": str(out), "stages": records}, indent=2) + "\n")


def main():
    if len(sys.argv) < 2:
        raise SystemExit("usage: refine_profiles_joint.py COD_ID [COD_ID ...]")
    G2.SetPrintLevel("error")
    for cid in sys.argv[1:]:
        develop(cid)


if __name__ == "__main__":
    main()
