#!/usr/bin/env python3
"""Refine only coordinate shifts that remain interior and replay-stable."""

from __future__ import annotations

import json
from pathlib import Path
import re
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COORD_RE = re.compile(r"^(\d+)::dA[xyz]:(\d+)$")
BOUND_A = 0.10


def clear_frozen(p):
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def freeze(p):
    h = p.histogram(0)
    h.Background[0][1] = False
    for v in h.InstrumentParameters.values():
        if isinstance(v, list) and len(v) > 2:
            v[2] = False
    for v in h.SampleParameters.values():
        if isinstance(v, list) and len(v) > 1 and isinstance(v[1], bool):
            v[1] = False
    for ph in p.phases():
        ph.set_refinements({"Cell": False})
        for a in ph.atoms():
            a.refinement_flags = " "
        hap = ph.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def baseline(p):
    h = p.histogram(0)
    h.Background[0][1] = True
    for ph in p.phases():
        ph.data["Histograms"][h.name]["Scale"][1] = True


def mass_fractions(p):
    h = p.histogram(0)
    w = {ph.name: max(0.0, float(ph.data["General"]["Mass"]) * float(ph.data["Histograms"][h.name]["Scale"][0])) for ph in p.phases()}
    total = sum(w.values())
    return {k: v / total for k, v in w.items()}


def geometry(p):
    return {ph.name: [[str(a), str(b), float(d)] for a, b, d in ph.ShortDistances(useAll=False)] for ph in p.phases()}


def state(p, stage):
    rv = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": stage,
        "Rwp_percent": float(p.histogram(0).get_wR()),
        "converged": bool(rv.get("converged", False)),
        "max_shift_esd": rv.get("Max shft/sig"),
        "frozen": [str(v) for v in p.get_Frozen()],
        "fractions": mass_fractions(p),
        "short_contacts": geometry(p),
    }


def run(p, stage, records, cycles=10):
    clear_frozen(p)
    p.set_Controls("cycles", cycles)
    p.save()
    p.refine(makeBack=False)
    p.save()
    row = state(p, stage)
    records.append(row)
    print(json.dumps(row), flush=True)
    return row


def source_coordinates(p):
    p.index_ids()
    result = {}
    for ph in p.phases():
        pid = int(ph.data["pId"])
        for i, atom in enumerate(ph.atoms()):
            result[(pid, i)] = tuple(float(x) for x in atom.coordinates)
    return result


def install_bounds(p, source):
    for ph in p.phases():
        pid = int(ph.data["pId"])
        cell = ph.get_cell()
        lengths = [float(cell[f"length_{x}"]) for x in "abc"]
        for i, atom in enumerate(ph.atoms()):
            for axis, value, length in zip("xyz", source[(pid, i)], lengths):
                half = BOUND_A / length
                p.set_Controls("parmMin", value - half, variable=f"{pid}::dA{axis}:{i}")
                p.set_Controls("parmMax", value + half, variable=f"{pid}::dA{axis}:{i}")


def frozen_atoms(row):
    result = set()
    for name in row["frozen"]:
        m = COORD_RE.match(name)
        if m:
            result.add((int(m.group(1)), int(m.group(2))))
    return result


def select(p, predicate, excluded):
    active = 0
    for ph in p.phases():
        pid = int(ph.data["pId"])
        for i, atom in enumerate(ph.atoms()):
            use = (pid, i) not in excluded and predicate(pid, i, atom)
            atom.refinement_flags = "X" if use else " "
            active += int(use)
    return active


def reset_atoms(p, keys, source):
    for ph in p.phases():
        pid = int(ph.data["pId"])
        for i, atom in enumerate(ph.atoms()):
            if (pid, i) in keys:
                atom.coordinates = source[(pid, i)]


def stabilize(p, label, predicate, excluded, source, records):
    for attempt in range(1, 5):
        freeze(p)
        baseline(p)
        if not select(p, predicate, excluded):
            return
        row = run(p, f"{label}_{attempt}", records, cycles=12)
        hit = frozen_atoms(row)
        if hit:
            reset_atoms(p, hit, source)
            excluded.update(hit)
            continue
        maximum = row.get("max_shift_esd")
        if row.get("converged") and maximum is not None and float(maximum) <= 1.0:
            return


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: refine_supported_coordinates.py INPUT.gpx OUTPUT.gpx")
    src = Path(sys.argv[1]).resolve()
    out = Path(sys.argv[2]).resolve()
    G2.SetPrintLevel("error")
    p = G2.G2Project(gpxfile=str(src), newgpx=str(out))
    records = []
    source = source_coordinates(p)
    install_bounds(p, source)
    excluded = set()

    for ph in p.phases():
        pid = int(ph.data["pId"])
        stabilize(p, f"{ph.name}_heavy", lambda q, i, a, pid=pid: q == pid and not a.element.strip().upper().startswith("O"), excluded, source, records)
        stabilize(p, f"{ph.name}_oxygen", lambda q, i, a, pid=pid: q == pid and a.element.strip().upper().startswith("O"), excluded, source, records)

    stabilize(p, "joint_supported_coordinates", lambda q, i, a: True, excluded, source, records)

    # Settle cells against one retained calibration representation. Zero is
    # fixed because the previous joint fit reported 99.98% Zero/Shift
    # correlation; specimen displacement carries the observable correction.
    freeze(p)
    baseline(p)
    h = p.histogram(0)
    h.SampleParameters["Shift"][1] = True
    for ph in p.phases():
        ph.set_refinements({"Cell": True})
    for attempt in range(1, 4):
        row = run(p, f"cell_shift_settle_{attempt}", records, cycles=12)
        maximum = row.get("max_shift_esd")
        if row.get("converged") and maximum is not None and float(maximum) <= 1.0 and not row["frozen"]:
            break

    freeze(p)
    p.save()
    out.with_suffix(".json").write_text(json.dumps({
        "source": str(src), "output": str(out), "coordinate_bound_A": BOUND_A,
        "excluded_atoms": [list(k) for k in sorted(excluded)], "records": records,
        "final": state(p, "final"),
    }, indent=2) + "\n")


if __name__ == "__main__":
    main()
