#!/usr/bin/env python3
"""Rebuild isotropic broadening after the complete phase inventory is known."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


START_STRAIN = (700.0, 800.0, 2200.0, 1200.0)


def freeze(p):
    h=p.histogram(0);h.Background[0][1]=False
    for v in h.InstrumentParameters.values():
        if isinstance(v,list) and len(v)>2:v[2]=False
    for v in h.SampleParameters.values():
        if isinstance(v,list) and len(v)>1 and isinstance(v[1],bool):v[1]=False
    for ph in p.phases():
        ph.set_refinements({'Cell':False})
        for a in ph.atoms():a.refinement_flags=' '
        hap=ph.data['Histograms'][h.name];hap['Scale'][1]=False;hap['Size'][2]=[False]*len(hap['Size'][2]);hap['Mustrain'][2]=[False]*len(hap['Mustrain'][2]);hap['Mustrain'][5]=[False]*len(hap['Mustrain'][5]);hap['Pref.Ori.'][2]=False


def baseline(p):
    h=p.histogram(0);h.Background[0][1]=True
    for ph in p.phases():ph.data['Histograms'][h.name]['Scale'][1]=True


def profile_flags(p,common=False):
    h=p.histogram(0);p.index_ids()
    for ph in p.phases():
        pid=int(ph.data['pId']);hap=ph.data['Histograms'][h.name];hap['Size'][2][0]=True;hap['Mustrain'][2][0]=True
        p.set_Controls('parmMin',0.04,variable=f'{pid}:0:Size;i');p.set_Controls('parmMax',1.5,variable=f'{pid}:0:Size;i');p.set_Controls('parmMin',0.,variable=f'{pid}:0:Mustrain;i');p.set_Controls('parmMax',8000.,variable=f'{pid}:0:Mustrain;i')
    if common:
        h.InstrumentParameters['W'][2]=True;h.InstrumentParameters['SH/L'][2]=True;p.set_Controls('parmMin',2.,variable=':0:W');p.set_Controls('parmMax',40.,variable=':0:W');p.set_Controls('parmMin',.005,variable=':0:SH/L');p.set_Controls('parmMax',.10,variable=':0:SH/L')


def fractions(p):
    h=p.histogram(0);w={ph.name:max(0.,float(ph.data['General']['Mass'])*float(ph.data['Histograms'][h.name]['Scale'][0])) for ph in p.phases()};s=sum(w.values());return{k:v/s for k,v in w.items()}


def values(p):
    h=p.histogram(0);return{'Rwp_percent':float(h.get_wR()),'fractions':fractions(p),'W':float(h.InstrumentParameters['W'][1]),'SH_L':float(h.InstrumentParameters['SH/L'][1]),'Zero':float(h.InstrumentParameters['Zero'][1]),'Shift_um':float(h.SampleParameters['Shift'][0]),'phases':{ph.name:{'cell':ph.get_cell(),'size_um':float(ph.data['Histograms'][h.name]['Size'][1][0]),'strain_ppm':float(ph.data['Histograms'][h.name]['Mustrain'][1][0])}for ph in p.phases()}}


def run(p,stage,records,cycles=15):
    p.data['Controls']['data']['parmFrozen']={'FrozenList':[]};p.set_Controls('cycles',cycles);p.save();p.refine(makeBack=False);p.save();rv=p.data.get('Covariance',{}).get('data',{}).get('Rvals',{});row={'stage':stage,'converged':bool(rv.get('converged',False)),'max_shift_esd':rv.get('Max shft/sig'),'frozen':[str(v)for v in p.get_Frozen()],**values(p)};records.append(row);print(json.dumps(row),flush=True);return row


def repeat(p,label,records,limit=4):
    for i in range(1,limit+1):
        row=run(p,f'{label}_{i}',records)
        if row['converged'] and row['max_shift_esd'] is not None and float(row['max_shift_esd'])<=1 and not row['frozen']:break


def main():
    if len(sys.argv)!=3:raise SystemExit('usage: rebuild_closed_profile.py INPUT.gpx OUTPUT.gpx')
    G2.SetPrintLevel('error');p=G2.G2Project(gpxfile=str(Path(sys.argv[1]).resolve()),newgpx=str(Path(sys.argv[2]).resolve()));h=p.histogram(0);h.InstrumentParameters['Polariz.'][1]=.75;h.InstrumentParameters['U'][1]=0.;h.InstrumentParameters['X'][1]=.1;h.InstrumentParameters['W'][1]=2.;records=[]
    for i,ph in enumerate(p.phases()):
        hap=ph.data['Histograms'][h.name];hap['Mustrain'][0]='isotropic';hap['Mustrain'][1][0]=START_STRAIN[i];hap['Size'][0]='isotropic'
        if i==3:hap['Size'][1][0]=1.0
    freeze(p);baseline(p);profile_flags(p,False);repeat(p,'phase_profiles_minimum_instrument',records)
    freeze(p);baseline(p);profile_flags(p,True);repeat(p,'joint_profile',records)
    freeze(p);baseline(p);h.SampleParameters['Shift'][1]=True
    for ph in p.phases():ph.set_refinements({'Cell':True})
    repeat(p,'cell_shift',records)
    freeze(p);p.save();out=Path(sys.argv[2]).resolve();out.with_suffix('.json').write_text(json.dumps({'records':records,'final':values(p)},indent=2)+'\n')


if __name__=='__main__':main()
