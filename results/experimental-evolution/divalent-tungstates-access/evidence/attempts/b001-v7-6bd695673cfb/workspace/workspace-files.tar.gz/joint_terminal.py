#!/usr/bin/env python3
"""Jointly settle only supported, interior terminal-model parameters."""

from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


def freeze(project):
    hist = project.histogram(0); hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2: value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool): value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms(): atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]; hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2]); hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2]); hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5]); hap["Pref.Ori."][2] = False


def correlations(project, cutoff=0.95):
    cov = project.data.get("Covariance", {}).get("data", {}); matrix = cov.get("covMatrix"); names = cov.get("varyList", [])
    if matrix is None or len(names) != len(matrix): return []
    matrix = np.asarray(matrix, float); sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0)); rows = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            denominator = sigma[i] * sigma[j]
            if denominator:
                value = float(matrix[i, j] / denominator)
                if abs(value) >= cutoff: rows.append([str(names[i]), str(names[j]), value])
    return sorted(rows, key=lambda row: abs(row[2]), reverse=True)


def fractions(project):
    hist = project.histogram(0); raw = [max(0.0, float(p.data["General"]["Mass"]) * float(p.data["Histograms"][hist.name]["Scale"][0])) for p in project.phases()]; total = sum(raw)
    return {p.name: value / total for p, value in zip(project.phases(), raw)}


def state(project):
    hist = project.histogram(0); rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "Rwp_percent": float(hist.get_wR()), "GOF": float(rv.get("GOF", float("nan"))), "converged": bool(rv.get("converged", False)), "max_shift_esd": rv.get("Max shft/sig"), "frozen": [str(v) for v in project.get_Frozen()], "high_correlations": correlations(project), "fractions": fractions(project),
        "instrument": {key: float(hist.InstrumentParameters[key][1]) for key in ("W", "SH/L", "U", "X", "Zero")}, "shift_um": float(hist.SampleParameters["Shift"][0]),
        "phases": {phase.name: {"Uiso_A2": sorted({float(a.uiso) for a in phase.atoms() if a.adp_flag == "I"}), "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]), "strain_type": phase.data["Histograms"][hist.name]["Mustrain"][0], "strain_ppm": [float(v) for v in phase.data["Histograms"][hist.name]["Mustrain"][1][:2]]} for phase in project.phases()},
    }


def main():
    if len(sys.argv) not in (3, 4, 5): raise SystemExit("usage: joint_terminal.py INPUT.gpx OUTPUT.gpx [INCLUDE_CELLS] [FIXED_TERM]")
    include_cells = len(sys.argv) == 4 and sys.argv[3].lower() in {"1", "true", "yes"}
    if len(sys.argv) == 5:
        include_cells = sys.argv[3].lower() in {"1", "true", "yes"}
    fixed_term = sys.argv[4].lower() if len(sys.argv) == 5 else "none"
    G2.SetPrintLevel("error"); output = Path(sys.argv[2]).resolve(); project = G2.G2Project(gpxfile=str(Path(sys.argv[1]).resolve()), newgpx=str(output)); hist = project.histogram(0)
    freeze(project); hist.Background[0][1] = True; project.data["Constraints"]["data"]["Phase"] = []; project.index_ids()
    for index, phase in enumerate(project.phases()):
        pid = int(phase.data["pId"]); hap = phase.data["Histograms"][hist.name]; hap["Scale"][1] = True
        if index < 3:
            hap["Size"][2][0] = True; project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i"); project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        hap["Mustrain"][2][0] = True; project.set_Controls("parmMin", 300.0, variable=f"{pid}:0:Mustrain;i"); project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
        if index == 2:
            hap["Mustrain"][0] = "uniaxial"; hap["Mustrain"][3] = [0, 0, 1]; hap["Mustrain"][2][1] = True; project.set_Controls("parmMin", 75.0, variable=f"{pid}:0:Mustrain;a"); project.set_Controls("parmMax", 32000.0, variable=f"{pid}:0:Mustrain;a")
        else: hap["Mustrain"][0] = "isotropic"
        if index != 2:
            variables = []
            for atom_index, atom in enumerate(phase.atoms()):
                if atom.adp_flag == "I": atom.refinement_flags = "U"; variables.append(f"{pid}::AUiso:{atom_index}")
            if len(variables) > 1: project.add_EquivConstr(variables, reloadIdx=False)
            if variables: project.set_Controls("parmMin", 0.003, variable=variables[0]); project.set_Controls("parmMax", 0.020, variable=variables[0])
    hist.InstrumentParameters["W"][2] = True; hist.InstrumentParameters["SH/L"][2] = fixed_term != "shl"
    project.set_Controls("parmMin", 2.0, variable=":0:W"); project.set_Controls("parmMax", 40.0, variable=":0:W"); project.set_Controls("parmMin", 0.005, variable=":0:SH/L"); project.set_Controls("parmMax", 0.10, variable=":0:SH/L")
    if include_cells:
        for phase in project.phases(): phase.set_refinements({"Cell": True})
        hist.SampleParameters["Shift"][1] = fixed_term != "shift"
        project.set_Controls("parmMin", -800.0, variable=":0:Shift"); project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    records = []
    for attempt in range(1, 5):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}; project.set_Controls("cycles", 20)
        project.save(); project.refine(makeBack=False); project.save(); row = {"stage": f"joint_terminal_cells_{include_cells}_{attempt}", **state(project)}; records.append(row); print(json.dumps(row), flush=True)
        maximum = row["max_shift_esd"]
        if row["converged"] and maximum is not None and float(maximum) <= 1 and not row["frozen"]: break
    freeze(project); project.save(); output.with_suffix(".json").write_text(json.dumps({"records": records, "final": state(project)}, indent=2) + "\n")


if __name__ == "__main__": main()
