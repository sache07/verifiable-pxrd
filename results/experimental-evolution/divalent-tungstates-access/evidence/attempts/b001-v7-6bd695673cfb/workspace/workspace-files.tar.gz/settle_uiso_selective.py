#!/usr/bin/env python3
"""Settle phase-common Uiso values while holding supplied phase indices fixed."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def freeze(project):
    hist = project.histogram(0); hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2: value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool): value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms(): atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]; hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2]); hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2]); hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5]); hap["Pref.Ori."][2] = False


def state(project):
    hist = project.histogram(0); rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {"Rwp_percent": float(hist.get_wR()), "converged": bool(rv.get("converged", False)), "max_shift_esd": rv.get("Max shft/sig"), "frozen": [str(v) for v in project.get_Frozen()], "Uiso_A2": {phase.name: sorted({round(float(atom.uiso), 12) for atom in phase.atoms() if atom.adp_flag == "I"}) for phase in project.phases()}}


def main():
    if len(sys.argv) != 5: raise SystemExit("usage: settle_uiso_selective.py INPUT OUTPUT EXCLUDED RESET_VALUE")
    G2.SetPrintLevel("error")
    source, output = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
    excluded = {int(v) for v in sys.argv[3].split(",") if v}
    reset = float(sys.argv[4])
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output)); hist = project.histogram(0)
    freeze(project); hist.Background[0][1] = True; project.data["Constraints"]["data"]["Phase"] = []; project.index_ids()
    for phase_index, phase in enumerate(project.phases()):
        pid = int(phase.data["pId"]); variables = []
        for atom_index, atom in enumerate(phase.atoms()):
            if atom.adp_flag != "I": continue
            if phase_index in excluded: atom.uiso = reset
            else:
                atom.refinement_flags = "U"; variables.append(f"{pid}::AUiso:{atom_index}")
        if len(variables) > 1: project.add_EquivConstr(variables, reloadIdx=False)
        if variables:
            project.set_Controls("parmMin", 0.003, variable=variables[0]); project.set_Controls("parmMax", 0.020, variable=variables[0])
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    records = []
    for attempt in range(1, 4):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}; project.set_Controls("cycles", 12)
        project.save(); project.refine(makeBack=False); project.save()
        row = {"stage": f"selective_Uiso_{attempt}", **state(project)}; records.append(row); print(json.dumps(row), flush=True)
        maximum = row["max_shift_esd"]
        if row["converged"] and maximum is not None and float(maximum) <= 1 and not row["frozen"]: break
    freeze(project); project.save(); output.with_suffix(".json").write_text(json.dumps({"excluded": sorted(excluded), "records": records, "final": state(project)}, indent=2) + "\n")


if __name__ == "__main__": main()
