#!/usr/bin/env python3
"""Jointly settle the complete four-phase profile and peak positions."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def freeze(p):
    h = p.histogram(0)
    h.Background[0][1] = False
    for v in h.InstrumentParameters.values():
        if isinstance(v, list) and len(v) > 2: v[2] = False
    for v in h.SampleParameters.values():
        if isinstance(v, list) and len(v) > 1 and isinstance(v[1], bool): v[1] = False
    for ph in p.phases():
        ph.set_refinements({"Cell": False})
        for a in ph.atoms(): a.refinement_flags = " "
        hap = ph.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def baseline(p):
    h = p.histogram(0); h.Background[0][1] = True
    for ph in p.phases(): ph.data["Histograms"][h.name]["Scale"][1] = True


def profile_flags(p):
    h = p.histogram(0); p.index_ids()
    for ph in p.phases():
        pid = int(ph.data["pId"]); hap = ph.data["Histograms"][h.name]
        hap["Size"][2][0] = True
        p.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i"); p.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        if hap["Mustrain"][0] == "uniaxial":
            hap["Mustrain"][2][0] = True; hap["Mustrain"][2][1] = True
            p.set_Controls("parmMin", 300.0, variable=f"{pid}:0:Mustrain;i"); p.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
            p.set_Controls("parmMin", 75.0, variable=f"{pid}:0:Mustrain;a"); p.set_Controls("parmMax", 32000.0, variable=f"{pid}:0:Mustrain;a")
        else:
            hap["Mustrain"][2][0] = True
            p.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i"); p.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
    h.InstrumentParameters["W"][2] = True; h.InstrumentParameters["SH/L"][2] = True
    p.set_Controls("parmMin", 2.0, variable=":0:W"); p.set_Controls("parmMax", 40.0, variable=":0:W")
    p.set_Controls("parmMin", 0.005, variable=":0:SH/L"); p.set_Controls("parmMax", 0.10, variable=":0:SH/L")


def fractions(p):
    h=p.histogram(0); w={ph.name:max(0.,float(ph.data['General']['Mass'])*float(ph.data['Histograms'][h.name]['Scale'][0])) for ph in p.phases()}; s=sum(w.values()); return {k:v/s for k,v in w.items()}


def values(p):
    h=p.histogram(0)
    return {"Rwp_percent":float(h.get_wR()),"fractions":fractions(p),"W":float(h.InstrumentParameters['W'][1]),"SH_L":float(h.InstrumentParameters['SH/L'][1]),"Zero":float(h.InstrumentParameters['Zero'][1]),"Shift_um":float(h.SampleParameters['Shift'][0]),
            "phases":{ph.name:{"cell":ph.get_cell(),"size_um":float(ph.data['Histograms'][h.name]['Size'][1][0]),"mustrain_type":ph.data['Histograms'][h.name]['Mustrain'][0],"mustrain":list(map(float,ph.data['Histograms'][h.name]['Mustrain'][1][:2]))} for ph in p.phases()}}


def run(p,stage,records,cycles=15):
    p.data['Controls']['data']['parmFrozen']={'FrozenList':[]};p.set_Controls('cycles',cycles);p.save();p.refine(makeBack=False);p.save()
    rv=p.data.get('Covariance',{}).get('data',{}).get('Rvals',{});row={"stage":stage,"converged":bool(rv.get('converged',False)),"max_shift_esd":rv.get('Max shft/sig'),"frozen":[str(v) for v in p.get_Frozen()],**values(p)};records.append(row);print(json.dumps(row),flush=True);return row


def main():
    if len(sys.argv)!=3: raise SystemExit('usage: settle_four_phase.py INPUT.gpx OUTPUT.gpx')
    G2.SetPrintLevel('error');p=G2.G2Project(gpxfile=str(Path(sys.argv[1]).resolve()),newgpx=str(Path(sys.argv[2]).resolve()));h=p.histogram(0);h.InstrumentParameters['Polariz.'][1]=0.75;records=[]
    freeze(p);baseline(p);profile_flags(p)
    for i in range(1,5):
        row=run(p,f'joint_profile_{i}',records)
        if row['converged'] and row['max_shift_esd'] is not None and float(row['max_shift_esd'])<=1 and not row['frozen']:break
    freeze(p);baseline(p);h.SampleParameters['Shift'][1]=True
    for ph in p.phases():ph.set_refinements({'Cell':True})
    for i in range(1,5):
        row=run(p,f'cell_shift_{i}',records)
        if row['converged'] and row['max_shift_esd'] is not None and float(row['max_shift_esd'])<=1 and not row['frozen']:break
    freeze(p);p.save();out=Path(sys.argv[2]).resolve();out.with_suffix('.json').write_text(json.dumps({'records':records,'final':values(p)},indent=2)+'\n')


if __name__=='__main__':main()
