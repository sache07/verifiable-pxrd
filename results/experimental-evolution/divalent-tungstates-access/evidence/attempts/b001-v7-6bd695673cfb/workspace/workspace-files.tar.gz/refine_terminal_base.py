#!/usr/bin/env python3
"""Finish accepted profile and phase-common displacement parameters."""

from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


def clear_frozen(p):
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def freeze(p):
    h = p.histogram(0)
    h.Background[0][1] = False
    for v in h.InstrumentParameters.values():
        if isinstance(v, list) and len(v) > 2:
            v[2] = False
    for v in h.SampleParameters.values():
        if isinstance(v, list) and len(v) > 1 and isinstance(v[1], bool):
            v[1] = False
    for ph in p.phases():
        ph.set_refinements({"Cell": False})
        for atom in ph.atoms():
            atom.refinement_flags = " "
        hap = ph.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def baseline(p):
    h = p.histogram(0)
    h.Background[0][1] = True
    for ph in p.phases():
        ph.data["Histograms"][h.name]["Scale"][1] = True


def profile_flags(p):
    h = p.histogram(0)
    p.index_ids()
    for ph in p.phases():
        pid = int(ph.data["pId"])
        hap = ph.data["Histograms"][h.name]
        hap["Size"][2][0] = True
        hap["Mustrain"][2][0] = True
        p.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        p.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        p.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        p.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")


def fractions(p):
    h = p.histogram(0)
    w = {ph.name: max(0.0, float(ph.data["General"]["Mass"]) * float(ph.data["Histograms"][h.name]["Scale"][0])) for ph in p.phases()}
    total = sum(w.values())
    return {k: v / total for k, v in w.items()}


def high_correlations(p, cutoff=0.95):
    cov = p.data.get("Covariance", {}).get("data", {})
    matrix = cov.get("covMatrix")
    names = cov.get("varyList", [])
    if matrix is None or len(names) != len(matrix):
        return []
    matrix = np.asarray(matrix, float)
    diag = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    result = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            den = diag[i] * diag[j]
            if den <= 0:
                continue
            value = float(matrix[i, j] / den)
            if abs(value) >= cutoff:
                result.append([str(names[i]), str(names[j]), value])
    return sorted(result, key=lambda row: abs(row[2]), reverse=True)


def values(p):
    h = p.histogram(0)
    return {
        "fractions": fractions(p),
        "instrument": {k: float(h.InstrumentParameters[k][1]) for k in ("Polariz.", "U", "W", "X", "SH/L", "Zero")},
        "shift_um": float(h.SampleParameters["Shift"][0]),
        "phases": {ph.name: {
            "Uiso_A2": [float(a.uiso) for a in ph.atoms() if a.adp_flag == "I"],
            "size_um": float(ph.data["Histograms"][h.name]["Size"][1][0]),
            "microstrain_ppm": float(ph.data["Histograms"][h.name]["Mustrain"][1][0]),
        } for ph in p.phases()},
    }


def run(p, stage, records, cycles=12):
    clear_frozen(p)
    p.set_Controls("cycles", cycles)
    p.save()
    p.refine(makeBack=False)
    p.save()
    rv = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    row = {
        "stage": stage, "Rwp_percent": float(p.histogram(0).get_wR()),
        "converged": bool(rv.get("converged", False)), "max_shift_esd": rv.get("Max shft/sig"),
        "frozen": [str(v) for v in p.get_Frozen()], "high_correlations": high_correlations(p),
        **values(p),
    }
    records.append(row)
    print(json.dumps(row), flush=True)
    return row


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: refine_terminal_base.py INPUT.gpx OUTPUT.gpx")
    G2.SetPrintLevel("error")
    p = G2.G2Project(gpxfile=str(Path(sys.argv[1]).resolve()), newgpx=str(Path(sys.argv[2]).resolve()))
    h = p.histogram(0)
    records = []

    freeze(p)
    baseline(p)
    profile_flags(p)
    h.InstrumentParameters["W"][2] = True
    h.InstrumentParameters["SH/L"][2] = True
    p.set_Controls("parmMin", 2.0, variable=":0:W")
    p.set_Controls("parmMax", 40.0, variable=":0:W")
    p.set_Controls("parmMin", 0.005, variable=":0:SH/L")
    p.set_Controls("parmMax", 0.10, variable=":0:SH/L")
    for attempt in range(1, 4):
        row = run(p, f"profile_replay_{attempt}", records, 12)
        if row["converged"] and row["max_shift_esd"] is not None and float(row["max_shift_esd"]) <= 1.0 and not row["frozen"]:
            break

    freeze(p)
    baseline(p)
    p.data["Constraints"]["data"]["Phase"] = []
    p.index_ids()
    for ph in p.phases():
        pid = int(ph.data["pId"])
        atoms = ph.atoms()
        variables = [f"{pid}::AUiso:{i}" for i, atom in enumerate(atoms) if atom.adp_flag == "I"]
        for atom in atoms:
            if atom.adp_flag == "I":
                atom.refinement_flags = "U"
        if len(variables) > 1:
            p.add_EquivConstr(variables, reloadIdx=False)
        if variables:
            p.set_Controls("parmMin", 0.003, variable=variables[0])
            p.set_Controls("parmMax", 0.020, variable=variables[0])
    for attempt in range(1, 4):
        row = run(p, f"phase_common_Uiso_{attempt}", records, 12)
        if row["converged"] and row["max_shift_esd"] is not None and float(row["max_shift_esd"]) <= 1.0 and not row["frozen"]:
            break

    freeze(p)
    baseline(p)
    h.InstrumentParameters["Polariz."][2] = True
    p.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    p.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    for attempt in range(1, 4):
        row = run(p, f"polarization_{attempt}", records, 12)
        if row["converged"] and row["max_shift_esd"] is not None and float(row["max_shift_esd"]) <= 1.0 and not row["frozen"]:
            break

    freeze(p)
    p.save()
    output = Path(sys.argv[2]).resolve()
    output.with_suffix(".json").write_text(json.dumps({"records": records, "final": values(p)}, indent=2) + "\n")


if __name__ == "__main__":
    main()
