#!/usr/bin/env python3
"""Settle the complete four-phase model without bound-pinned profile terms."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


# Values from the converged four-phase isotropic checkpoint.  They are used as
# starts only; the CuO size is deliberately fixed because it previously reached
# the laboratory upper bound and is not independently identifiable.
START_STRAIN = (636.0, 611.0, 2251.0, 2171.0)
START_SIZE = (0.1062, 0.2812, 0.2634, 1.5)


def freeze(project):
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for item in hist.InstrumentParameters.values():
        if isinstance(item, list) and len(item) > 2:
            item[2] = False
    for item in hist.SampleParameters.values():
        if isinstance(item, list) and len(item) > 1 and isinstance(item[1], bool):
            item[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def baseline(project):
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def profile_flags(project, instrument=False):
    hist = project.histogram(0)
    project.index_ids()
    for index, phase in enumerate(project.phases()):
        pid = int(phase.data["pId"])
        hap = phase.data["Histograms"][hist.name]
        # Size is estimable for the three major phases. CuO size was bound-
        # pinned and stays fixed at the tested limit, so it is not a model term.
        if index < 3:
            hap["Size"][2][0] = True
            project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
            project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 300.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
    if instrument:
        hist.InstrumentParameters["W"][2] = True
        hist.InstrumentParameters["SH/L"][2] = True
        project.set_Controls("parmMin", 2.0, variable=":0:W")
        project.set_Controls("parmMax", 40.0, variable=":0:W")
        project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
        project.set_Controls("parmMax", 0.10, variable=":0:SH/L")


def fractions(project):
    hist = project.histogram(0)
    raw = {
        phase.name: max(
            0.0,
            float(phase.data["General"]["Mass"])
            * float(phase.data["Histograms"][hist.name]["Scale"][0]),
        )
        for phase in project.phases()
    }
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def snapshot(project):
    hist = project.histogram(0)
    values = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(values.get("converged", False)),
        "max_shift_esd": values.get("Max shft/sig"),
        "frozen": [str(item) for item in project.get_Frozen()],
        "fractions": fractions(project),
        "W": float(hist.InstrumentParameters["W"][1]),
        "SH_L": float(hist.InstrumentParameters["SH/L"][1]),
        "Shift_um": float(hist.SampleParameters["Shift"][0]),
        "profiles": {
            phase.name: {
                "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "strain_ppm": float(phase.data["Histograms"][hist.name]["Mustrain"][1][0]),
            }
            for phase in project.phases()
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }


def run(project, stage, records, cycles=12):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    row = {"stage": stage, **snapshot(project)}
    records.append(row)
    print(json.dumps(row), flush=True)
    return row


def repeat(project, stage, records, limit=4):
    row = None
    for attempt in range(1, limit + 1):
        row = run(project, f"{stage}_{attempt}", records)
        shift = row["max_shift_esd"]
        if row["converged"] and shift is not None and float(shift) <= 1 and not row["frozen"]:
            break
    return row


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: settle_closed_safe.py INPUT.gpx OUTPUT.gpx")
    G2.SetPrintLevel("error")
    output = Path(sys.argv[2]).resolve()
    project = G2.G2Project(gpxfile=str(Path(sys.argv[1]).resolve()), newgpx=str(output))
    hist = project.histogram(0)
    hist.InstrumentParameters["Polariz."][1] = 0.75
    hist.InstrumentParameters["U"][1] = 0.0
    hist.InstrumentParameters["X"][1] = 0.1
    for phase, strain, size in zip(project.phases(), START_STRAIN, START_SIZE):
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size

    records = []
    freeze(project); baseline(project)
    repeat(project, "scales_background", records, limit=2)

    freeze(project); baseline(project); profile_flags(project, instrument=False)
    repeat(project, "phase_profiles", records)

    freeze(project); baseline(project); profile_flags(project, instrument=True)
    repeat(project, "common_profile", records)

    freeze(project)
    project.save()
    output.with_suffix(".json").write_text(
        json.dumps({"records": records, "final": snapshot(project)}, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
