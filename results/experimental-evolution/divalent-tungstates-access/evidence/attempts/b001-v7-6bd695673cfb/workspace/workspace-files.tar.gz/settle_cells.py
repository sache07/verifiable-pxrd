#!/usr/bin/env python3
"""Settle selected phase cells, optionally with the specimen displacement."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def freeze(project):
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2: value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool): value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms(): atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def state(project):
    hist = project.histogram(0)
    rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "Rwp_percent": float(hist.get_wR()), "converged": bool(rv.get("converged", False)),
        "max_shift_esd": rv.get("Max shft/sig"), "frozen": [str(v) for v in project.get_Frozen()],
        "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }


def main():
    if len(sys.argv) != 5:
        raise SystemExit("usage: settle_cells.py INPUT.gpx OUTPUT.gpx PHASES SHIFT")
    source, output = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
    selection = sys.argv[3]
    use_shift = sys.argv[4].lower() in {"1", "true", "yes"}
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = project.histogram(0)
    freeze(project)
    hist.Background[0][1] = True
    for phase in project.phases(): phase.data["Histograms"][hist.name]["Scale"][1] = True
    indices = range(len(project.phases())) if selection == "all" else [int(v) for v in selection.split(",")]
    for index in indices: project.phases()[index].set_refinements({"Cell": True})
    if use_shift:
        hist.SampleParameters["Shift"][1] = True
        project.set_Controls("parmMin", -800.0, variable=":0:Shift")
        project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    records = []
    for attempt in range(1, 5):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 12)
        project.save(); project.refine(makeBack=False); project.save()
        row = {"stage": f"cells_{selection}_shift_{use_shift}_{attempt}", **state(project)}
        records.append(row); print(json.dumps(row), flush=True)
        shift = row["max_shift_esd"]
        if row["converged"] and shift is not None and float(shift) <= 1 and not row["frozen"]: break
    freeze(project); project.save()
    output.with_suffix(".json").write_text(json.dumps({"records": records, "final": state(project)}, indent=2) + "\n")


if __name__ == "__main__":
    main()
