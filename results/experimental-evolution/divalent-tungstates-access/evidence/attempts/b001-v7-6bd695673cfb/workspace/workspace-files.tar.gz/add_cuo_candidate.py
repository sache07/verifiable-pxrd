#!/usr/bin/env python3
"""Add and equally develop a residual CuO phase candidate."""

from __future__ import annotations

import json
from pathlib import Path
import re
import sys

from GSASII import GSASIIscriptable as G2


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
COORD_RE = re.compile(r"^(\d+)::dA[xyz]:(\d+)$")


def cif_path(cid):
    return COD / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


def clear_frozen(p):
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def freeze(p):
    h = p.histogram(0)
    h.Background[0][1] = False
    for v in h.InstrumentParameters.values():
        if isinstance(v, list) and len(v) > 2:
            v[2] = False
    for v in h.SampleParameters.values():
        if isinstance(v, list) and len(v) > 1 and isinstance(v[1], bool):
            v[1] = False
    for ph in p.phases():
        ph.set_refinements({"Cell": False})
        for atom in ph.atoms():
            atom.refinement_flags = " "
        hap = ph.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def baseline(p):
    h = p.histogram(0)
    h.Background[0][1] = True
    for ph in p.phases():
        ph.data["Histograms"][h.name]["Scale"][1] = True


def fractions(p):
    h = p.histogram(0)
    weights = {ph.name: max(0.0, float(ph.data["General"]["Mass"]) * float(ph.data["Histograms"][h.name]["Scale"][0])) for ph in p.phases()}
    total = sum(weights.values())
    return {k: v / total for k, v in weights.items()}


def record(p, stage):
    rv = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {"stage": stage, "Rwp_percent": float(p.histogram(0).get_wR()),
            "converged": bool(rv.get("converged", False)), "max_shift_esd": rv.get("Max shft/sig"),
            "frozen": [str(v) for v in p.get_Frozen()], "fractions": fractions(p),
            "cells": {ph.name: ph.get_cell() for ph in p.phases()}}


def run(p, stage, records, cycles=12):
    clear_frozen(p)
    p.set_Controls("cycles", cycles)
    p.save(); p.refine(makeBack=False); p.save()
    row = record(p, stage); records.append(row); print(json.dumps(row), flush=True)
    return row


def main():
    if len(sys.argv) != 4:
        raise SystemExit("usage: add_cuo_candidate.py INPUT.gpx COD_ID OUTPUT.gpx")
    G2.SetPrintLevel("error")
    src, cid, out = Path(sys.argv[1]).resolve(), sys.argv[2], Path(sys.argv[3]).resolve()
    p = G2.G2Project(gpxfile=str(src), newgpx=str(out))
    h = p.histogram(0)
    cuo = p.add_phase(str(cif_path(cid)), phasename=f"CuO_{cid}", histograms=[h], fmthint="CIF")
    p.index_ids()
    pid = int(cuo.data["pId"])
    hap = cuo.data["Histograms"][h.name]
    old_weight = sum(float(ph.data["General"]["Mass"]) * float(ph.data["Histograms"][h.name]["Scale"][0]) for ph in p.phases()[:-1])
    hap["Scale"] = [0.02 / 0.98 * old_weight / float(cuo.data["General"]["Mass"]), True]
    hap["Size"][0] = "isotropic"; hap["Size"][1][0] = 0.2; hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][0] = "isotropic"; hap["Mustrain"][1][0] = 1000.0; hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][0] = "MD"; hap["Pref.Ori."][1] = 1.0; hap["Pref.Ori."][2] = False
    for atom in cuo.atoms():
        if atom.adp_flag == "I": atom.uiso = 0.01
    records = []

    freeze(p); baseline(p)
    run(p, "add_scale", records)

    freeze(p); baseline(p); cuo.set_refinements({"Cell": True})
    run(p, "cell", records, 15)

    freeze(p); baseline(p)
    hap["Size"][2][0] = True; hap["Mustrain"][2][0] = True
    p.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i"); p.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
    p.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i"); p.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
    run(p, "profile", records, 15)

    source_coords = {i: tuple(float(x) for x in atom.coordinates) for i, atom in enumerate(cuo.atoms())}
    cell = cuo.get_cell(); lengths = [float(cell[f"length_{x}"]) for x in "abc"]
    for i, atom in enumerate(cuo.atoms()):
        for axis, value, length in zip("xyz", source_coords[i], lengths):
            p.set_Controls("parmMin", value - 0.10 / length, variable=f"{pid}::dA{axis}:{i}")
            p.set_Controls("parmMax", value + 0.10 / length, variable=f"{pid}::dA{axis}:{i}")
    freeze(p); baseline(p)
    for atom in cuo.atoms(): atom.refinement_flags = "X"
    row = run(p, "coordinates", records, 15)
    bound_atoms = set()
    for var in row["frozen"]:
        match = COORD_RE.match(var)
        if match and int(match.group(1)) == pid: bound_atoms.add(int(match.group(2)))
    if bound_atoms:
        for i in bound_atoms: cuo.atoms()[i].coordinates = source_coords[i]
        freeze(p); baseline(p)
        for i, atom in enumerate(cuo.atoms()): atom.refinement_flags = " " if i in bound_atoms else "X"
        run(p, "interior_coordinates", records, 15)

    freeze(p); baseline(p)
    vars_u = []
    for i, atom in enumerate(cuo.atoms()):
        if atom.adp_flag == "I": atom.refinement_flags = "U"; vars_u.append(f"{pid}::AUiso:{i}")
    if len(vars_u) > 1: p.add_EquivConstr(vars_u, reloadIdx=False)
    if vars_u:
        p.set_Controls("parmMin", 0.003, variable=vars_u[0]); p.set_Controls("parmMax", 0.020, variable=vars_u[0])
    run(p, "common_Uiso", records, 15)

    freeze(p); p.save()
    out.with_suffix(".json").write_text(json.dumps({"COD_id": cid, "records": records, "final": record(p, "final")}, indent=2) + "\n")


if __name__ == "__main__":
    main()
