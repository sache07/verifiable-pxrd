#!/usr/bin/env python3
"""Combine supported uniaxial-strain branches and settle the profile."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 0, 1])
STARTS = ((1154.3, 958.6), (1008.3, 682.8), (3057.0, 3513.4))


def freeze(p):
    h = p.histogram(0)
    h.Background[0][1] = False
    for v in h.InstrumentParameters.values():
        if isinstance(v, list) and len(v) > 2:
            v[2] = False
    for v in h.SampleParameters.values():
        if isinstance(v, list) and len(v) > 1 and isinstance(v[1], bool):
            v[1] = False
    for ph in p.phases():
        ph.set_refinements({"Cell": False})
        for atom in ph.atoms():
            atom.refinement_flags = " "
        hap = ph.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def baseline(p):
    h = p.histogram(0)
    h.Background[0][1] = True
    for ph in p.phases():
        ph.data["Histograms"][h.name]["Scale"][1] = True


def strain_flags(p):
    h = p.histogram(0)
    p.index_ids()
    for index, ph in enumerate(p.phases()):
        pid = int(ph.data["pId"])
        hap = ph.data["Histograms"][h.name]
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        hap["Mustrain"][3] = list(AXES[index])
        p.set_Controls("parmMin", 300.0, variable=f"{pid}:0:Mustrain;i")
        p.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
        p.set_Controls("parmMin", 75.0, variable=f"{pid}:0:Mustrain;a")
        p.set_Controls("parmMax", 32000.0, variable=f"{pid}:0:Mustrain;a")


def profile_flags(p):
    h = p.histogram(0)
    strain_flags(p)
    for ph in p.phases():
        pid = int(ph.data["pId"])
        hap = ph.data["Histograms"][h.name]
        hap["Size"][2][0] = True
        p.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        p.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
    h.InstrumentParameters["W"][2] = True
    h.InstrumentParameters["SH/L"][2] = True
    p.set_Controls("parmMin", 2.0, variable=":0:W")
    p.set_Controls("parmMax", 40.0, variable=":0:W")
    p.set_Controls("parmMin", 0.005, variable=":0:SH/L")
    p.set_Controls("parmMax", 0.10, variable=":0:SH/L")


def values(p):
    h = p.histogram(0)
    return {
        "Rwp_percent": float(h.get_wR()),
        "W": float(h.InstrumentParameters["W"][1]),
        "SH_L": float(h.InstrumentParameters["SH/L"][1]),
        "phases": {ph.name: {
            "size_um": float(ph.data["Histograms"][h.name]["Size"][1][0]),
            "equatorial_ppm": float(ph.data["Histograms"][h.name]["Mustrain"][1][0]),
            "axial_ppm": float(ph.data["Histograms"][h.name]["Mustrain"][1][1]),
            "axis": list(ph.data["Histograms"][h.name]["Mustrain"][3]),
        } for ph in p.phases()},
    }


def run(p, stage, records, cycles=15):
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    p.set_Controls("cycles", cycles)
    p.save()
    p.refine(makeBack=False)
    p.save()
    rv = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    row = {"stage": stage, "converged": bool(rv.get("converged", False)),
           "max_shift_esd": rv.get("Max shft/sig"), "frozen": [str(v) for v in p.get_Frozen()], **values(p)}
    records.append(row)
    print(json.dumps(row), flush=True)
    return row


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: combine_strain.py INPUT.gpx OUTPUT.gpx")
    G2.SetPrintLevel("error")
    p = G2.G2Project(gpxfile=str(Path(sys.argv[1]).resolve()), newgpx=str(Path(sys.argv[2]).resolve()))
    h = p.histogram(0)
    h.InstrumentParameters["Polariz."][1] = 0.75
    for index, ph in enumerate(p.phases()):
        hap = ph.data["Histograms"][h.name]
        hap["Mustrain"][1][0], hap["Mustrain"][1][1] = STARTS[index]

    records = []
    freeze(p); baseline(p); strain_flags(p)
    for attempt in range(1, 4):
        row = run(p, f"combined_strain_{attempt}", records)
        if row["converged"] and row["max_shift_esd"] is not None and float(row["max_shift_esd"]) <= 1 and not row["frozen"]:
            break

    freeze(p); baseline(p); profile_flags(p)
    for attempt in range(1, 4):
        row = run(p, f"joint_profile_{attempt}", records)
        if row["converged"] and row["max_shift_esd"] is not None and float(row["max_shift_esd"]) <= 1 and not row["frozen"]:
            break

    freeze(p)
    p.save()
    out = Path(sys.argv[2]).resolve()
    out.with_suffix(".json").write_text(json.dumps({"records": records, "final": values(p)}, indent=2) + "\n")


if __name__ == "__main__":
    main()
