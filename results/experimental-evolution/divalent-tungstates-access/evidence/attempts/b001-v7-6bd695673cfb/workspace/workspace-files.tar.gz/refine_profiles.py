#!/usr/bin/env python3
"""Refine bounded, identifiable peak-profile terms for structural branches."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def clear_frozen(project: G2.G2Project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def freeze_all(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def enable_baseline(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def absorb_sample_scale(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    sample_scale = float(hist.SampleParameters["Scale"][0])
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][0] *= sample_scale
    hist.SampleParameters["Scale"] = [1.0, False]


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    weighted = {
        phase.name: max(0.0, float(phase.data["General"]["Mass"]) * float(phase.data["Histograms"][hist.name]["Scale"][0]))
        for phase in project.phases()
    }
    total = sum(weighted.values())
    return {k: v / total for k, v in weighted.items()}


def profile_values(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    return {
        "instrument": {k: float(hist.InstrumentParameters[k][1]) for k in ("U", "W", "X", "SH/L")},
        "phases": {
            phase.name: {
                "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "microstrain_ppm": float(phase.data["Histograms"][hist.name]["Mustrain"][1][0]),
            }
            for phase in project.phases()
        },
    }


def record(project: G2.G2Project, stage: str) -> dict:
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": stage,
        "Rwp_percent": float(project.histogram(0).get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "fractions": fractions(project),
        "profile": profile_values(project),
    }


def run(project: G2.G2Project, stage: str, records: list[dict], cycles: int = 10) -> None:
    clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    row = record(project, stage)
    records.append(row)
    print(json.dumps(row), flush=True)


def develop(cod_id: str) -> None:
    source = ROOT / "work_branches" / f"wo3_{cod_id}.gpx"
    output = ROOT / "work_branches" / f"wo3_{cod_id}_profile.gpx"
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = project.histogram(0)
    records: list[dict] = []

    absorb_sample_scale(project)
    freeze_all(project)
    enable_baseline(project)
    for phase in project.phases():
        for atom in phase.atoms():
            if atom.adp_flag == "I":
                atom.uiso = 0.010

    # X is fixed because it is exactly confounded with isotropic crystallite
    # size in this CW profile. U and W are Gaussian and identifiable from the
    # sample's Lorentzian size/strain terms.
    hist.InstrumentParameters["U"][2] = True
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["SH/L"][2] = True
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMax", 40.0, variable=":0:U")
    project.set_Controls("parmMin", 2.0, variable=":0:W")
    project.set_Controls("parmMax", 40.0, variable=":0:W")
    project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.10, variable=":0:SH/L")
    run(project, "common_gaussian_asymmetry", records, 12)

    freeze_all(project)
    enable_baseline(project)
    project.index_ids()
    for phase in project.phases():
        pid = int(phase.data["pId"])
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][2][0] = True
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
    run(project, "phase_sizes", records, 12)

    freeze_all(project)
    enable_baseline(project)
    for phase in project.phases():
        pid = int(phase.data["pId"])
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
    run(project, "phase_sizes_microstrain", records, 15)

    # Final profile checkpoint includes cell/calibration but keeps the common
    # Gaussian and asymmetry values fixed, avoiding a correlated re-fit.
    freeze_all(project)
    enable_baseline(project)
    hist.InstrumentParameters["Zero"][2] = True
    hist.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
        hap["Mustrain"][2][0] = True
    run(project, "profile_cell_calibration_settle", records, 15)

    output.with_suffix(".json").write_text(json.dumps({
        "wo3_id": cod_id, "source": str(source), "project": str(output), "stages": records,
    }, indent=2) + "\n")


def main() -> None:
    if len(sys.argv) < 2:
        raise SystemExit("usage: refine_profiles.py COD_ID [COD_ID ...]")
    G2.SetPrintLevel("error")
    for cod_id in sys.argv[1:]:
        develop(cod_id)


if __name__ == "__main__":
    main()
