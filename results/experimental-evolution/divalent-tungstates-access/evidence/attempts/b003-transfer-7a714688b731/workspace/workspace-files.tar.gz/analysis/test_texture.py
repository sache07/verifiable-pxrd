#!/usr/bin/env python3
"""Refine one March-Dollase texture candidate from a common GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("axis", nargs=3, type=int)
    parser.add_argument("--start-current", action="store_true")
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve()))
    project.set_Frozen()
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": list(hist.data["Instrument Parameters"][0])})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])

    target = project.phase(args.phase)
    hap = target.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    if not args.start_current:
        hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(args.axis)
    project.set_Controls("parmMin", 0.7, variable=f"{target.id}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{target.id}:0:MD")
    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)
    project.save()
    record = {
        "phase": args.phase,
        "axis": args.axis,
        "ratio": hap["Pref.Ori."][1],
        "rwp_percent": hist.get_wR(),
        "gof": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "frozen": project.get_Frozen(),
    }
    args.output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record))


if __name__ == "__main__":
    main()
