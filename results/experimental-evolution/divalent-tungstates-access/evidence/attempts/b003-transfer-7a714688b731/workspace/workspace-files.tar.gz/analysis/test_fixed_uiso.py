#!/usr/bin/env python3
"""Set fixed phase-common isotropic displacement factors and refit linear terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--mnwo4", type=float, required=True)
    parser.add_argument("--mn3wo6", type=float, required=True)
    parser.add_argument("--wo3", type=float, required=True)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    values = {"MnWO4": args.mnwo4, "Mn3WO6": args.mn3wo6, "WO3": args.wo3}
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve()))
    project.set_Frozen()
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": list(hist.data["Instrument Parameters"][0])})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        for atom in phase.atoms():
            atom.uiso = values[phase.name]
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.save()
    result = {"rwp_percent": hist.get_wR(), "uiso_A2": values}
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
