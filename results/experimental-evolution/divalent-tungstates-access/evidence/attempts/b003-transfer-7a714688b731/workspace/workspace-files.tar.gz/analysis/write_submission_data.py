#!/usr/bin/env python3
"""Write the replayed profile and machine-readable final refinement result."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


REPLAY = Path("analysis/replay/submission")
PHASE_INFO = {
    "MnWO4": {
        "formula": "MnWO4",
        "description": "wolframite-type manganese(II) tungstate",
        "cif_path": "phase_mnwo4.cif",
        "structure_reference": "COD 1520200",
    },
    "Mn3WO6": {
        "formula": "Mn3WO6",
        "description": "rhombohedral manganese tungsten oxide",
        "cif_path": "phase_mn3wo6.cif",
        "structure_reference": "COD 2002703",
    },
    "WO3": {
        "formula": "WO3",
        "description": "monoclinic tungsten trioxide",
        "cif_path": "phase_wo3.cif",
        "structure_reference": "COD 2311041",
    },
}


def main() -> None:
    with np.load(REPLAY / "prediction.npz", allow_pickle=False) as profile:
        x = profile["x"].copy()
        observed = profile["observed"].copy()
        calculated = profile["predicted"].copy()
    difference = observed - calculated
    np.savetxt(
        "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )

    replay = json.loads((REPLAY / "replay.json").read_text())
    project = G2.G2Project(gpxfile=str(Path("final.gpx").resolve()))
    histogram = project.histogram(0)
    covariance = project.data["Covariance"]["data"]

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
    gof = float(covariance["Rvals"]["GOF"])

    replay_by_name = {row["name"]: row for row in replay["phases"]}
    phase_names = [phase.name for phase in project.phases()]
    scales = np.array(
        [project.phase(name).data["Histograms"][histogram.name]["Scale"][0] for name in phase_names]
    )
    masses = np.array([replay_by_name[name]["cell_mass"] for name in phase_names])
    weighted_scales = scales * masses
    fractions = weighted_scales / weighted_scales.sum()

    vary = [str(item) for item in covariance["varyList"]]
    scale_indices = [vary.index(f"{project.phase(name).id}:0:Scale") for name in phase_names]
    scale_covariance = np.asarray(covariance["covMatrix"])[np.ix_(scale_indices, scale_indices)]
    total = weighted_scales.sum()
    jacobian = np.empty((len(phase_names), len(phase_names)))
    for i in range(len(phase_names)):
        for j in range(len(phase_names)):
            jacobian[i, j] = masses[j] * (
                (1.0 if i == j else 0.0) * total - weighted_scales[i]
            ) / total**2
    fraction_covariance = jacobian @ scale_covariance @ jacobian.T
    fraction_esd = np.sqrt(np.maximum(np.diag(fraction_covariance), 0.0))

    phase_rows = []
    for index, name in enumerate(phase_names):
        phase = project.phase(name)
        sg = phase.data["General"]["SGData"]["SpGrp"].strip()
        phase_rows.append(
            {
                "name": name,
                **PHASE_INFO[name],
                "space_group": sg,
                "cell": phase.get_cell(),
                "weight_fraction": float(fractions[index]),
                "weight_fraction_esd_statistical": float(fraction_esd[index]),
            }
        )

    instrument = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]
    result = {
        "method": "GSAS-II Rietveld refinement; final profile independently regenerated from final.gpx",
        "project_path": "final.gpx",
        "refinement_histogram": histogram.name,
        "phases": phase_rows,
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "r_exp_percent": rwp / gof,
            "goodness_of_fit": gof,
            "chi_square": chi_square,
            "n_points": int(len(x)),
            "weighting": "1/max(observed_counts,1)",
        },
        "calibration": {
            "zero_deg": float(instrument["Zero"][1]),
            "specimen_shift_um": float(sample["Shift"][0]),
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelengths_A": [float(instrument["Lam1"][1]), float(instrument["Lam2"][1])],
            "kalpha2_to_kalpha1_ratio": float(instrument["I(L2)/I(L1)"][1]),
        },
        "uncertainty_note": (
            "Weight-fraction ESDs are local counting-statistical values from the final scale covariance; "
            "model/texture/ADP uncertainty is larger and is discussed in report.md."
        ),
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
