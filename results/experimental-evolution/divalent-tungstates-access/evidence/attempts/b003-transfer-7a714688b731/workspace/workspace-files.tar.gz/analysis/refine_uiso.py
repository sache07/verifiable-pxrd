#!/usr/bin/env python3
"""Refine one common isotropic displacement parameter per phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve()))
    project.set_Frozen()
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": list(hist.data["Instrument Parameters"][0])})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": "U"}})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
        variables = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=True)
        for variable in variables:
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)

    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)
    project.save()
    rows = []
    for phase in project.phases():
        cia = phase.data["General"]["AtomPtrs"][3]
        rows.append(
            {
                "name": phase.name,
                "uiso_A2": [atom.data[cia + 1] for atom in phase.atoms()],
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
            }
        )
    result = {
        "rwp_percent": hist.get_wR(),
        "gof": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "frozen": project.get_Frozen(),
        "phases": rows,
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
