#!/usr/bin/env python3
"""Reset to registered coordinates, then refine a physically bounded subset."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path, help="project supplying the nonstructural fit")
    parser.add_argument("parent", type=Path, help="project supplying registered parent coordinates")
    parser.add_argument("output", type=Path)
    parser.add_argument("--mode", choices=["all", "heavy", "main_all", "main_all_minor_heavy"], default="all")
    parser.add_argument("--oxygen-move", type=float, default=0.035, help="per-coordinate Cartesian proxy bound in A")
    parser.add_argument("--heavy-move", type=float, default=0.040, help="per-coordinate Cartesian proxy bound in A")
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve()))
    parent = G2.G2Project(gpxfile=str(args.parent.resolve()))
    project.set_Frozen()
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": list(hist.data["Instrument Parameters"][0])})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    hist.set_refinements({"Background": True})

    starts = {}
    selected = []
    for phase in project.phases():
        parent_phase = parent.phase(phase.name)
        parent_atoms = {atom.label: atom for atom in parent_phase.atoms()}
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
        cell = phase.get_cell()
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        flags = {}
        for index, atom in enumerate(phase.atoms()):
            atom.coordinates = parent_atoms[atom.label].coordinates
            starts[(phase.name, atom.label)] = atom.coordinates
            is_main = phase.name == "MnWO4"
            use = (
                args.mode == "all"
                or (args.mode == "heavy" and atom.element != "O")
                or (args.mode == "main_all" and is_main)
                or (args.mode == "main_all_minor_heavy" and (is_main or atom.element != "O"))
            )
            flags[atom.label] = "X" if use else " "
            if use:
                selected.append((phase.name, atom.label))
                max_move = args.oxygen_move if atom.element == "O" else args.heavy_move
                for axis, length, coordinate in zip("xyz", lengths, atom.coordinates):
                    variable = f"{phase.id}::dA{axis}:{index}"
                    bound = max_move / length
                    project.set_Controls("parmMin", coordinate - bound, variable=variable)
                    project.set_Controls("parmMax", coordinate + bound, variable=variable)
        phase.set_refinements({"Atoms": flags})

    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    project.save()
    rows = []
    for phase in project.phases():
        cell = phase.get_cell()
        lengths = np.array([cell["length_a"], cell["length_b"], cell["length_c"]])
        atoms = []
        for atom in phase.atoms():
            start = np.asarray(starts[(phase.name, atom.label)])
            delta = np.asarray(atom.coordinates) - start
            delta -= np.rint(delta)
            atoms.append(
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": atom.coordinates,
                    "move_proxy_A": float(np.linalg.norm(delta * lengths)),
                }
            )
        rows.append({"name": phase.name, "atoms": atoms})
    result = {
        "mode": args.mode,
        "oxygen_move_component_A": args.oxygen_move,
        "heavy_move_component_A": args.heavy_move,
        "selected": selected,
        "rwp_percent": hist.get_wR(),
        "frozen": project.get_Frozen(),
        "phases": rows,
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
