#!/usr/bin/env python3
"""Refine phase cells and angular calibration in stable alternating stages."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def record(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    return {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "zero_deg": inst["Zero"][1],
        "shift_um": hist.data["Sample Parameters"]["Shift"][0],
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }


def refine(project: G2.G2Project, log: list, label: str) -> None:
    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)
    log.append(record(project, label))
    print(json.dumps(log[-1]), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve()))
    project.set_Frozen()
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": list(hist.data["Instrument Parameters"][0])})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_refinements({"Cell": True, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
    project.set_Controls("parmMin", -0.6, variable=":0:Zero")
    project.set_Controls("parmMax", 0.6, variable=":0:Zero")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    project.save()
    log = [record(project, "start")]

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, log, "cells_zero")
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, log, "cells_shift")
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, log, "cells_zero_shift")
    project.save()
    args.output.with_suffix(".json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
