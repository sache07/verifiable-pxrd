#!/usr/bin/env python3
"""Shrink refined atom displacements toward registered parent coordinates."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("parent", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--oxygen-factor", type=float, required=True)
    parser.add_argument("--heavy-factor", type=float, default=1.0)
    parser.add_argument("--mnwo4-o", type=float)
    parser.add_argument("--mn3wo6-o", type=float)
    parser.add_argument("--wo3-o", type=float)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve()))
    parent = G2.G2Project(gpxfile=str(args.parent.resolve()))
    project.set_Frozen()
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": list(hist.data["Instrument Parameters"][0])})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    hist.set_refinements({"Background": True})
    rows = []
    for phase in project.phases():
        pphase = parent.phase(phase.name)
        patoms = {atom.label: atom for atom in pphase.atoms()}
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
        atoms = []
        for atom in phase.atoms():
            start = np.asarray(patoms[atom.label].coordinates)
            delta = np.asarray(atom.coordinates) - start
            delta -= np.rint(delta)
            phase_factor = {
                "MnWO4": args.mnwo4_o,
                "Mn3WO6": args.mn3wo6_o,
                "WO3": args.wo3_o,
            }.get(phase.name)
            factor = (args.oxygen_factor if phase_factor is None else phase_factor) if atom.element == "O" else args.heavy_factor
            atom.coordinates = (start + factor * delta).tolist()
            atoms.append({"label": atom.label, "element": atom.element, "factor": factor})
        rows.append({"name": phase.name, "atoms": atoms})
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.save()
    result = {
        "oxygen_factor": args.oxygen_factor,
        "heavy_factor": args.heavy_factor,
        "phase_oxygen_factors": {
            "MnWO4": args.mnwo4_o,
            "Mn3WO6": args.mn3wo6_o,
            "WO3": args.wo3_o,
        },
        "rwp_percent": hist.get_wR(),
        "phases": rows,
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
