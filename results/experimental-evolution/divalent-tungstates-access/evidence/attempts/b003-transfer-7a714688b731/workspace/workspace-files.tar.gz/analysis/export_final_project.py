#!/usr/bin/env python3
"""Copy the selected refinement into the submission project and export its phases."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path("analysis/valid/wo3-2311041/broad-t4.gpx")
PROJECT = Path("final.gpx")
EXPORTS = {
    "MnWO4": Path("phase_mnwo4.cif"),
    "Mn3WO6": Path("phase_mn3wo6.cif"),
    "WO3": Path("phase_wo3.cif"),
}


def main() -> None:
    G2.SetPrintLevel("error")
    project = G2.G2Project(
        gpxfile=str(SOURCE.resolve()),
        newgpx=str(PROJECT.resolve()),
    )
    project.save()
    rows = []
    for phase in project.phases():
        output = EXPORTS[phase.name]
        phase.export_CIF(str(output.resolve()))
        rows.append(
            {
                "phase": phase.name,
                "cif": str(output),
                "cell": phase.get_cell(),
            }
        )
    print(json.dumps({"project": str(PROJECT), "phases": rows}, indent=2))


if __name__ == "__main__":
    main()
