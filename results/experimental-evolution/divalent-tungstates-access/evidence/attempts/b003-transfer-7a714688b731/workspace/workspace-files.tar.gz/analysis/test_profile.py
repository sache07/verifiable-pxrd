#!/usr/bin/env python3
"""Multi-start refinement of instrumental and phase broadening parameters."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def log_uniform(rng: np.random.Generator, lo: float, hi: float) -> float:
    return float(np.exp(rng.uniform(np.log(lo), np.log(hi))))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("seed", type=int)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve()))
    project.set_Frozen()
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": list(hist.data["Instrument Parameters"][0])})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    hist.set_refinements({"Background": True})
    inst = hist.data["Instrument Parameters"][0]
    starts = {
        "U": float(rng.uniform(1.0, 39.0)),
        "W": float(rng.uniform(3.0, 39.0)),
        "X": log_uniform(rng, 0.12, 5.8),
        "SH/L": log_uniform(rng, 0.006, 0.095),
    }
    for key, value in starts.items():
        inst[key][1] = value
    hist.set_refinements({"Instrument Parameters": list(starts)})
    bounds = {
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
    }

    phase_starts = {}
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        hap = phase.data["Histograms"][hist.name]
        size = log_uniform(rng, 0.045, 1.4)
        strain = log_uniform(rng, 350.0, 7500.0)
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        phase.set_HAP_refinements(
            {
                "Scale": True,
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
        phase_starts[phase.name] = {"size_um": size, "microstrain_ppm": strain}
        bounds[f"{phase.id}:0:Scale"] = (0.0, 1.0e6)
        bounds[f"{phase.id}:0:Size;i"] = (0.04, 1.5)
        bounds[f"{phase.id}:0:Mustrain;i"] = (0.0, 8000.0)
    for variable, (lo, hi) in bounds.items():
        project.set_Controls("parmMin", lo, variable=variable)
        project.set_Controls("parmMax", hi, variable=variable)

    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    project.save()
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "size_um": hap["Size"][1][0],
                "microstrain_ppm": hap["Mustrain"][1][0],
                "scale": hap["Scale"][0],
            }
        )
    result = {
        "seed": args.seed,
        "starts": {"instrument": starts, "phases": phase_starts},
        "rwp_percent": hist.get_wR(),
        "instrument": {key: inst[key][1] for key in starts},
        "phases": phases,
        "frozen": project.get_Frozen(),
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
