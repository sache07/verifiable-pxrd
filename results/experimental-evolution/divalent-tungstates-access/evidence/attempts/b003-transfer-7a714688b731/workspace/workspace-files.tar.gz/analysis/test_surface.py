#!/usr/bin/env python3
"""Test surface roughness and polarization from a common refined project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--A", type=float, default=0.0)
    parser.add_argument("--B", type=float, default=0.0)
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--polarization", action="store_true")
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve()))
    project.set_Frozen()
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": list(hist.data["Instrument Parameters"][0])})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])

    sample = hist.data["Sample Parameters"]
    if args.roughness:
        sample["SurfRoughA"] = [args.A, True]
        sample["SurfRoughB"] = [args.B, True]
        project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 0.6, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.5, variable=":0:SurfRoughB")
    else:
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.0, False]
    if args.polarization:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")

    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)
    project.save()
    result = {
        "rwp_percent": hist.get_wR(),
        "surf_rough_A": sample["SurfRoughA"][0],
        "surf_rough_B": sample["SurfRoughB"][0],
        "polarization": hist.data["Instrument Parameters"][0]["Polariz."][1],
        "frozen": project.get_Frozen(),
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
