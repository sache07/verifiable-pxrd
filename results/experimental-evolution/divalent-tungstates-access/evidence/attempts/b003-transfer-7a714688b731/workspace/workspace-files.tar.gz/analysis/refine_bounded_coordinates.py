#!/usr/bin/env python3
"""Refine coordinates once per phase with bounds from the synthetic mismatch model."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def snapshot(project: G2.G2Project, label: str, starts: dict) -> dict:
    hist = project.histogram(0)
    rows = []
    for phase in project.phases():
        cell = phase.get_cell()
        lengths = np.array([cell["length_a"], cell["length_b"], cell["length_c"]])
        atoms = []
        for atom in phase.atoms():
            start = np.asarray(starts[(phase.name, atom.label)])
            delta = np.asarray(atom.coordinates) - start
            delta -= np.rint(delta)
            atoms.append(
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": atom.coordinates,
                    "fractional_delta": delta.tolist(),
                    "orthogonal_length_estimate_A": float(np.linalg.norm(delta * lengths)),
                }
            )
        hap = phase.data["Histograms"][hist.name]
        rows.append(
            {
                "name": phase.name,
                "cell": cell,
                "scale": hap["Scale"][0],
                "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
                "atoms": atoms,
            }
        )
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "frozen": project.get_Frozen(),
        "phases": rows,
    }


def refine(project: G2.G2Project, log: list, label: str, starts: dict) -> None:
    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)
    log.append(snapshot(project, label, starts))
    print(label, log[-1]["rwp_percent"], "frozen", log[-1]["frozen"], flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve()))
    project.set_Frozen()
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": list(hist.data["Instrument Parameters"][0])})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    hist.set_refinements({"Background": True})

    starts = {}
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
        cell = phase.get_cell()
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        for index, atom in enumerate(phase.atoms()):
            starts[(phase.name, atom.label)] = atom.coordinates
            max_move = 0.125 if atom.element == "O" else 0.10
            for axis, length, coordinate in zip("xyz", lengths, atom.coordinates):
                variable = f"{phase.id}::dA{axis}:{index}"
                bound = max_move / length
                project.set_Controls("parmMin", coordinate - bound, variable=variable)
                project.set_Controls("parmMax", coordinate + bound, variable=variable)

    project.save()
    log = [snapshot(project, "start", starts)]
    for name in ["MnWO4", "Mn3WO6", "WO3"]:
        project.phase(name).set_refinements({"Atoms": {"all": "X"}})
        refine(project, log, name + "_bounded_coordinates", starts)

    project.save()
    args.output.with_suffix(".json").write_text(json.dumps(log, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
