#!/usr/bin/env python3
"""Build and stage a GSAS-II trial refinement for candidate Mn/W oxide phases."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def phase_path(identifier: str) -> Path:
    candidate = Path(identifier)
    if candidate.is_file():
        return candidate.resolve()
    return COD_ROOT / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


def write_xye(source: Path, destination: Path) -> None:
    data = np.loadtxt(source, delimiter=",", skiprows=1)
    sigma = np.sqrt(np.maximum(data[:, 1], 1.0))
    np.savetxt(destination, np.column_stack((data, sigma)), fmt="%.8f %.8f %.8f")


def write_instrument(destination: Path) -> None:
    destination.write_text(
        "# GSAS-II Cu Kalpha starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.24;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": copy.deepcopy(hap["Size"]),
                "mustrain": copy.deepcopy(hap["Mustrain"]),
                "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
            }
        )
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
        "sample": copy.deepcopy(sample),
        "phases": phases,
        "vary_list": [str(v) for v in cov.get("varyList", [])],
    }


def refine(project: G2.G2Project, log: list[dict], label: str) -> None:
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    log.append(snapshot(project, label))
    print(label, "Rwp", log[-1]["rwp_percent"], "GOF", log[-1]["gof"], flush=True)


def build_trial(pattern: Path, outdir: Path, phase_ids: list[str], names: list[str]) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    xye = outdir / "pattern.xye"
    instfile = outdir / "instrument.instprm"
    gpx = outdir / "trial.gpx"
    write_xye(pattern, xye)
    write_instrument(instfile)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(str(xye), str(instfile), fmthint="xye")
    phases = [
        project.add_phase(str(phase_path(cid)), phasename=name, histograms=[hist], fmthint="CIF")
        for cid, name in zip(phase_ids, names)
    ]

    # Use the full measured range and the exact Bragg-Brentano geometry used by
    # the measurement/generator. Start from a smooth, high-floor background.
    hist.data["Limits"][1] = [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])]
    sample = hist.data["Sample Parameters"]
    sample["Type"] = "Bragg-Brentano"
    sample["Scale"] = [1.0, False]
    sample["Gonio. radius"] = 200.0
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [3600.0, 100.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": True,
            }
        }
    )

    for i, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0 / len(phases), True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Size"][1][1] = 0.30
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Extinction"] = [0.0, False]

    # Bound the profile variables to the stated laboratory ranges. GSAS-II
    # freezes a variable if a least-squares step reaches one of these limits.
    limits = {
        ":0:Zero": (-0.6, 0.6),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
    }
    for i in range(len(phases)):
        limits.update(
            {
                f"{i}:0:Scale": (0.0, 1.0e6),
                f"{i}:0:Size;i": (0.04, 1.5),
                f"{i}:0:Mustrain;i": (0.0, 8000.0),
            }
        )
    for variable, (lower, upper) in limits.items():
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)

    project.save()
    log = [snapshot(project, "initial")]

    # Stage 1: background and phase scales establish whether each candidate is present.
    refine(project, log, "background_scales")

    # Stage 2: refine independent cells and the common angular zero.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, log, "cells_zero")

    # Stage 3: include specimen displacement, then instrumental peak shape.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, log, "shift")
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, log, "instrument_profile")

    # Stage 4: phase-specific isotropic broadening.
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
                "Scale": True,
            },
            [hist],
        )
    refine(project, log, "phase_profiles")

    project.save()
    (outdir / "log.json").write_text(json.dumps(log, indent=2, default=str) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument(
        "--phases",
        nargs="+",
        default=["1520200", "2002703", "1528915"],
        help="COD ids in phase order",
    )
    parser.add_argument("--names", nargs="+", default=["MnWO4", "Mn3WO6", "WO3"])
    args = parser.parse_args()
    if len(args.phases) != len(args.names):
        raise SystemExit("--phases and --names must have equal lengths")
    build_trial(args.pattern.resolve(), args.out.resolve(), args.phases, args.names)


if __name__ == "__main__":
    main()
