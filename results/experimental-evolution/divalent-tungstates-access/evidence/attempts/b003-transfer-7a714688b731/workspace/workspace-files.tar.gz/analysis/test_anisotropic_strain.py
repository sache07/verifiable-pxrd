#!/usr/bin/env python3
"""Test the generator-supported uniaxial microstrain axes for one phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("axis", nargs=3, type=int)
    parser.add_argument("--ratio", type=float)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve()))
    project.set_Frozen()
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": list(hist.data["Instrument Parameters"][0])})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])

    target = project.phase(args.phase)
    hap = target.data["Histograms"][hist.name]
    initial = max(300.0, float(hap["Mustrain"][1][0]))
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = initial
    hap["Mustrain"][1][1] = initial if args.ratio is None else initial * args.ratio
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    hap["Mustrain"][3] = list(args.axis)
    project.set_Controls("parmMin", 0.0, variable=f"{target.id}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{target.id}:0:Mustrain;i")
    project.set_Controls("parmMin", 0.0, variable=f"{target.id}:0:Mustrain;a")
    project.set_Controls("parmMax", 32000.0, variable=f"{target.id}:0:Mustrain;a")
    if args.ratio is not None:
        project.add_EquivConstr(
            [f"{target.id}:0:Mustrain;i", f"{target.id}:0:Mustrain;a"],
            [args.ratio, 1.0],
            reloadIdx=True,
        )
    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)
    project.save()
    result = {
        "phase": args.phase,
        "axis": args.axis,
        "equatorial_ppm": hap["Mustrain"][1][0],
        "axial_ppm": hap["Mustrain"][1][1],
        "fixed_ratio": args.ratio,
        "rwp_percent": hist.get_wR(),
        "frozen": project.get_Frozen(),
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
