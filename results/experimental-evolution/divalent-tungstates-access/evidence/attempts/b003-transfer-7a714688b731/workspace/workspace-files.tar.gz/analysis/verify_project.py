#!/usr/bin/env python3
"""Regenerate a saved GSAS-II project's profile with the scorer replay code."""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--observed", type=Path, default=Path("inputs/pattern.csv"))
    args = parser.parse_args()
    project = args.project.resolve()
    observed = args.observed.resolve()
    outdir = args.outdir.resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    runtime = Path("learned/divalent-tungstates/scorer/runtime").resolve()
    sys.path.insert(0, str(runtime))
    import replay_worker

    os.chdir(outdir)
    report = replay_worker.replay({"project": str(project), "observed": str(observed), "histogram": None})
    Path("replay.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(json.dumps(report, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
