#!/usr/bin/env python3
"""Continue a trial project with staged symmetry-constrained coordinate refinement."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    result = {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "gof": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": atom.coordinates,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    return copy.deepcopy(result)


def run_refinement(project: G2.G2Project, log: list[dict], label: str, cycles: int = 12) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    log.append(state(project, label))
    print(label, "Rwp", log[-1]["rwp_percent"], "GOF", log[-1]["gof"], flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve()))
    project.set_Frozen()
    hist = project.histogram(0)

    # Hold the provisional calibration/profile fixed while structure factors are
    # adjusted. Retain only background and nonnegative phase scales.
    hist.clear_refinements({"Instrument Parameters": list(hist.data["Instrument Parameters"][0])})
    for key, value in hist.data["Sample Parameters"].items():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])

    project.save()
    log = [state(project, "start")]
    run_refinement(project, log, "scales_background", 6)

    # The dominant phase controls most of the intensity information.
    project.phase("MnWO4").set_refinements({"Atoms": {"all": "X"}})
    run_refinement(project, log, "mnwo4_coordinates")

    project.phase("Mn3WO6").set_refinements({"Atoms": {"all": "X"}})
    run_refinement(project, log, "mn3wo6_coordinates")

    wo3 = project.phase("WO3")
    wo3.set_refinements(
        {"Atoms": {atom.label: ("X" if atom.element == "W" else " ") for atom in wo3.atoms()}}
    )
    run_refinement(project, log, "wo3_tungsten_coordinates")
    wo3.set_refinements({"Atoms": {"all": "X"}})
    run_refinement(project, log, "wo3_all_coordinates")

    # Reconcile coordinates and cell metrics after the intensity stages.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(project, log, "coordinates_cells_zero")

    project.save()
    args.output.with_suffix(".json").write_text(json.dumps(log, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
