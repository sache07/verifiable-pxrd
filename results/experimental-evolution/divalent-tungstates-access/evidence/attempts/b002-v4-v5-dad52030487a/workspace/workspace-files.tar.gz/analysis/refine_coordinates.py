"""Bounded coordinate refinement for the two serious WO3 symmetry branches."""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"


def checkpoint(project: G2.G2Project, out: Path, name: str) -> None:
    project.save()
    shutil.copyfile(project.filename, out / f"{name}.gpx")


def get_state(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size": float(hap["Size"][1][0]),
            "mustrain": float(hap["Mustrain"][1][0]),
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": [float(v) for v in atom.coordinates],
                    "uiso": float(atom.uiso),
                }
                for atom in phase.atoms()
            ],
        }
    return {
        "stage": stage,
        "rwp": float(hist.residuals["wR"]),
        "rp": float(hist.residuals["R"]),
        "zero": float(hist.InstrumentParameters["Zero"][1]),
        "fractions": {
            k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()
        },
        "phases": phases,
        "vary_list": list(project.data["Covariance"]["data"].get("varyList", [])),
    }


def refine(project: G2.G2Project, out: Path, rows: list[dict], name: str) -> None:
    project.refine()
    row = get_state(project, name)
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)
    checkpoint(project, out, name)


def bound_atom_shifts(
    project: G2.G2Project, phase: G2.G2Phase, atom_indices: list[int], limit: float
) -> None:
    atoms = phase.atoms()
    for index in atom_indices:
        for axis, coordinate in zip("xyz", atoms[index].coordinates):
            variable = f"{phase.id}::dA{axis}:{index}"
            # Despite the historical dA name, these refinement variables carry
            # the absolute fractional coordinate, not a coordinate increment.
            project.set_Controls("parmMin", coordinate - limit, variable=variable)
            project.set_Controls("parmMax", coordinate + limit, variable=variable)


def select_atoms(phase: G2.G2Phase, elements: set[str]) -> tuple[dict, list[int]]:
    labels = {}
    indices = []
    for index, atom in enumerate(phase.atoms()):
        if atom.element in elements:
            labels[atom.label] = "X"
            indices.append(index)
    return labels, indices


def clear_atoms(phase: G2.G2Phase, labels: dict) -> None:
    phase.clear_refinements({"Atoms": list(labels)})


def run(wo3_name: str) -> None:
    G2.SetPrintLevel("warn")
    source = (
        ANALYSIS
        / "multiphase"
        / f"zno_wurtzite__{wo3_name}"
        / "05_mustrain.gpx"
    )
    out = ANALYSIS / "refined" / wo3_name
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source), newgpx=str(out / "working.gpx"))
    hist = project.histogram(0)
    project.set_Controls("cycles", 20)
    # Coordinate stages: retain only scales and background as active nuisance terms.
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": False})
        phase.clear_HAP_refinements({"Size": False, "Mustrain": False}, [hist])
    project.save()
    rows: list[dict] = []

    znwo4 = project.phase("znwo4_wolframite")
    labels, indices = select_atoms(znwo4, {"Zn", "W"})
    znwo4.set_refinements({"Atoms": labels})
    bound_atom_shifts(project, znwo4, indices, 0.025)
    refine(project, out, rows, "01_znwo4_heavy")
    clear_atoms(znwo4, labels)

    labels, indices = select_atoms(znwo4, {"O"})
    znwo4.set_refinements({"Atoms": labels})
    bound_atom_shifts(project, znwo4, indices, 0.035)
    refine(project, out, rows, "02_znwo4_oxygen")
    clear_atoms(znwo4, labels)

    wo3 = project.phase(wo3_name)
    labels, indices = select_atoms(wo3, {"W"})
    wo3.set_refinements({"Atoms": labels})
    bound_atom_shifts(project, wo3, indices, 0.02)
    refine(project, out, rows, "03_wo3_heavy")
    clear_atoms(wo3, labels)

    zno = project.phase("zno_wurtzite")
    labels, indices = select_atoms(zno, {"O"})
    zno.set_refinements({"Atoms": labels})
    bound_atom_shifts(project, zno, indices, 0.025)
    refine(project, out, rows, "04_zno_oxygen")
    clear_atoms(zno, labels)

    # Re-relax peak positions and one supported isotropic size term per phase.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
    refine(project, out, rows, "05_combined")

    (out / "stages.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    run(sys.argv[1])
