"""Export the selected full-grid GSAS-II checkpoint and submission files."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "physical" / "full_grid" / "iteration_04.gpx"
FINAL_GPX = ROOT / "final.gpx"

PHASE_METADATA = {
    "znwo4_wolframite": {
        "name": "ZnWO4 (wolframite)",
        "formula": "ZnWO4",
        "structure_type": "wolframite",
        "cif": "phase_1_ZnWO4_wolframite.cif",
    },
    "zno_wurtzite": {
        "name": "ZnO (wurtzite)",
        "formula": "ZnO",
        "structure_type": "wurtzite",
        "cif": "phase_2_ZnO_wurtzite.cif",
    },
    "wo3_p1": {
        "name": "WO3 (triclinic model)",
        "formula": "WO3",
        "structure_type": "triclinic WO3; polymorph assignment uncertain",
        "cif": "phase_3_WO3_triclinic.cif",
    },
}


def serial_cell(phase: G2.G2Phase) -> dict[str, float]:
    return {key: float(value) for key, value in phase.get_cell().items()}


def main() -> None:
    G2.SetPrintLevel("warn")
    shutil.copyfile(SOURCE, FINAL_GPX)
    project = G2.G2Project(gpxfile=str(FINAL_GPX))
    hist = project.histogram(0)

    raw_fractions = hist.ComputeMassFracs()
    total = sum(float(value[0]) for value in raw_fractions.values())
    phases = []
    for phase in project.phases():
        metadata = PHASE_METADATA[phase.name]
        cif_path = ROOT / metadata["cif"]
        phase.export_CIF(str(cif_path))
        fraction, esd = raw_fractions[phase.name]
        fraction = float(fraction) / total
        esd = float(esd) / total
        phases.append(
            {
                "name": metadata["name"],
                "formula": metadata["formula"],
                "structure_type": metadata["structure_type"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": metadata["cif"],
                "weight_fraction": fraction,
                "weight_percent": 100.0 * fraction,
                "weight_fraction_formal_esd": esd,
                "weight_percent_formal_esd": 100.0 * esd,
                "unit_cell": serial_cell(phase),
            }
        )

    x = np.asarray(hist.getdata("x"), dtype=float)
    observed = np.asarray(hist.getdata("yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("ycalc"), dtype=float)
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt=("%.8f", "%.8f", "%.8f", "%.8f"),
    )

    residuals = hist.residuals
    covariance_stats = project.data["Covariance"]["data"].get("Rvals", {})
    rwp = float(residuals["wR"])
    rexp = float(residuals["wRmin"])
    result = {
        "phases": phases,
        "modeled_crystalline_weight_fraction_sum": sum(
            phase["weight_fraction"] for phase in phases
        ),
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": rexp,
            "goodness_of_fit": float(
                covariance_stats.get("GOF", rwp / rexp)
            ),
            "Rwp_over_Rexp": rwp / rexp,
            "background_subtracted_Rp_percent": float(residuals["Rb"]),
            "background_subtracted_Rwp_percent": float(residuals["wRb"]),
            "number_of_observations": int(covariance_stats.get("Nobs", len(x))),
            "number_of_refined_parameters": int(covariance_stats.get("Nvars", 0)),
            "fit_range_two_theta_deg": [
                float(hist.data["Limits"][1][0]),
                float(hist.data["Limits"][1][1]),
            ],
        },
        "measurement_model": {
            "radiation": "Cu K-alpha doublet",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
        },
        "profile_path": "fit.csv",
        "gsas_project_path": "final.gpx",
        "fraction_basis": "normalized over the three modeled crystalline phases",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
