"""Compare exact-composition residual-phase candidates in one GSAS-II state."""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
MODEL_DIR = ANALYSIS / "models"


def copy_checkpoint(project: G2.G2Project, branch_dir: Path, name: str) -> None:
    project.save()
    shutil.copyfile(project.filename, branch_dir / f"{name}.gpx")


def number(value):
    return isinstance(value, (int, float))


def state(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "scale": float(hap["Scale"][0]),
            "mass": float(phase.data["General"]["Mass"]),
            "cell": phase.get_cell(),
            "size": float(hap["Size"][1][0]),
            "mustrain": float(hap["Mustrain"][1][0]),
        }
    try:
        fractions = {
            k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()
        }
    except Exception:
        total = sum(v["scale"] * v["mass"] for v in phases.values())
        fractions = {
            k: [v["scale"] * v["mass"] / total, float("nan")]
            for k, v in phases.items()
        }
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "stage": stage,
        "residuals": {
            k: float(v) for k, v in hist.residuals.items() if number(v)
        },
        "zero": float(hist.InstrumentParameters["Zero"][1]),
        "phases": phases,
        "mass_fractions": fractions,
        "vary_list": list(cov.get("varyList", [])),
    }


def refine(
    project: G2.G2Project,
    branch_dir: Path,
    rows: list[dict],
    stage: str,
    repeats: int = 2,
) -> None:
    for _ in range(repeats):
        project.refine()
    row = state(project, stage)
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)
    copy_checkpoint(project, branch_dir, stage)


def set_cell(phase: G2.G2Phase, cell: list[float]) -> None:
    phase.data["General"]["Cell"][1:7] = cell
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def run(extra_names: list[str]) -> None:
    G2.SetPrintLevel("warn")
    branch_name = "__".join(extra_names) if extra_names else "wolframite_only"
    branch_dir = ANALYSIS / "multiphase" / branch_name
    branch_dir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(branch_dir / "working.gpx"))
    hist = project.add_powder_histogram(
        str(ANALYSIS / "pattern.xye"),
        str(ANALYSIS / "instrument.instprm"),
        fmthint="xye",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"][1] = False
    hist.InstrumentParameters["Zero"][1] = 0.34
    hist.InstrumentParameters["Zero"][2] = False
    background = [
        780.0,
        -325.0,
        276.0,
        -148.0,
        104.0,
        -28.0,
        36.0,
        -17.0,
        38.0,
        53.0,
        1.0,
        20.0,
    ]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(background),
                "coeffs": background,
                "refine": True,
            },
        }
    )

    names = ["znwo4_wolframite", *extra_names]
    phases = []
    for name in names:
        phases.append(
            project.add_phase(
                str(MODEL_DIR / f"{name}.cif"),
                phasename=name,
                histograms=[hist],
                fmthint="CIF",
            )
        )
    # Peak positions from the physical one-phase checkpoint; coordinates remain
    # those of the unmodified wolframite analogue parent.
    set_cell(phases[0], [4.7045, 5.7378, 4.9353, 90.0, 90.6203, 90.0])

    target_weights = [0.90] + ([0.10 / len(extra_names)] * len(extra_names) if extra_names else [])
    if not extra_names:
        target_weights = [1.0]
    for phase, weight in zip(phases, target_weights):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [72000.0 * weight / phase.data["General"]["Mass"], True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.05
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 800.0
        hap["Mustrain"][2] = [False, False, False]

    project.set_Controls("cycles", 12)
    project.save()
    rows: list[dict] = []
    refine(project, branch_dir, rows, "01_scales_background")

    active = []
    for phase in phases:
        scale = phase.data["Histograms"][hist.name]["Scale"][0]
        if scale > 1e-8:
            active.append(phase)
            phase.set_refinements({"Cell": True})
        else:
            phase.set_HAP_refinements({"Scale": False}, [hist])
    refine(project, branch_dir, rows, "02_cells")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Controls("parmMin", -0.2, variable=":0:Zero")
    project.set_Controls("parmMax", 0.7, variable=":0:Zero")
    refine(project, branch_dir, rows, "03_zero")

    for phase in active:
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
        project.set_Controls(
            "parmMin", 0.005, variable=f"{phase.id}:{hist.id}:Size;i"
        )
        project.set_Controls(
            "parmMax", 10.0, variable=f"{phase.id}:{hist.id}:Size;i"
        )
    refine(project, branch_dir, rows, "04_size")

    for phase in active:
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
        project.set_Controls(
            "parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Mustrain;i"
        )
        project.set_Controls(
            "parmMax", 10000.0, variable=f"{phase.id}:{hist.id}:Mustrain;i"
        )
    refine(project, branch_dir, rows, "05_mustrain")

    (branch_dir / "stages.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    run(sys.argv[1:])
