"""Summarize residual distribution and map maxima to accepted reflections."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from scipy.signal import find_peaks

from GSASII import GSASIIscriptable as G2


def main(path: Path) -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(path))
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("x"), dtype=float)
    observed = np.asarray(hist.getdata("yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("ycalc"), dtype=float)
    weight = np.asarray(hist.getdata("yweight"), dtype=float)
    difference = observed - calculated
    fit_low, fit_high = hist.data["Limits"][1]
    use = (x >= fit_low) & (x <= fit_high)

    bins = []
    for low in np.arange(10.0, 100.0, 10.0):
        select = use & (x >= low) & (x < low + 10.0)
        bins.append(
            {
                "range": [low, low + 10.0],
                "rwp": 100.0
                * np.sqrt(
                    np.sum(weight[select] * difference[select] ** 2)
                    / np.sum(weight[select] * observed[select] ** 2)
                ),
                "mean_difference": float(np.mean(difference[select])),
            }
        )

    reflections = []
    for phase_name, data in hist.data["Reflection Lists"].items():
        for ref in data["RefList"]:
            reflections.append(
                {
                    "phase": phase_name,
                    "hkl": [int(ref[0]), int(ref[1]), int(ref[2])],
                    "position": float(ref[5]),
                    "sigma": float(ref[6]),
                    "gamma": float(ref[7]),
                    "fcalc": float(ref[9]),
                }
            )

    indices, properties = find_peaks(
        difference * use, prominence=150.0, distance=4
    )
    order = indices[np.argsort(difference[indices])[::-1]]
    maxima = []
    for index in order[:30]:
        nearest = min(
            reflections, key=lambda item: abs(item["position"] - x[index])
        )
        maxima.append(
            {
                "position": float(x[index]),
                "difference": float(difference[index]),
                "nearest": nearest,
                "delta_two_theta": abs(nearest["position"] - float(x[index])),
            }
        )

    print(
        json.dumps(
            {
                "fit_limits": [float(fit_low), float(fit_high)],
                "residuals": hist.residuals,
                "bins": bins,
                "positive_residual_maxima": maxima,
            },
            indent=2,
            default=float,
        )
    )


if __name__ == "__main__":
    main(Path(sys.argv[1]))
