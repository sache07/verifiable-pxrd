"""Physically bounded atomic and specimen refinements for the selected model."""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
SOURCE = ANALYSIS / "refined" / "wo3_p1" / "02_znwo4_oxygen.gpx"
TEXTURE_SOURCE = (
    ANALYSIS / "physical" / "texture" / "101" / "texture_101.gpx"
)
ACCEPTED_PROFILE_SOURCE = (
    ANALYSIS / "physical" / "final_refine" / "02_isotropic_size.gpx"
)
BEST_REPLAY_SOURCE = ANALYSIS / "physical" / "converged" / "iteration_01.gpx"
STABILIZED_SOURCE = ANALYSIS / "physical" / "stabilized" / "iteration_02.gpx"
ANISOTROPIC_SOURCE = (
    ANALYSIS / "physical" / "uniaxial_size_101" / "iteration_02.gpx"
)
OXYGEN_SOURCE = (
    ANALYSIS / "physical" / "oxygen_extension" / "01_oxygen_extension.gpx"
)
FINAL_RELAX_SOURCE = (
    ANALYSIS / "physical" / "final_relax" / "iteration_03.gpx"
)


def clean_flags(project: G2.G2Project) -> None:
    """Remove refinement flags and stale frozen/limit bookkeeping."""
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    # No specimen displacement/transparency term was active in the source.
    for phase in project.phases():
        phase.clear_refinements({"Cell": False})
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements(
            {"Size": False, "Mustrain": False, "Pref.Ori.": False}, [hist]
        )
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}


def state(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "mass_fraction": [
                float(value)
                for value in hist.ComputeMassFracs()[phase.name]
            ],
            "size": list(map(float, hap["Size"][1])),
            "preferred_orientation": [
                hap["Pref.Ori."][0],
                float(hap["Pref.Ori."][1]),
                list(hap["Pref.Ori."][3]),
            ],
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": list(map(float, atom.coordinates)),
                    "uiso": float(atom.uiso),
                }
                for atom in phase.atoms()
            ],
        }
    return {
        "stage": stage,
        "rwp": float(hist.residuals["wR"]),
        "rp": float(hist.residuals["R"]),
        "rexp": float(hist.residuals["wRmin"]),
        "zero": float(hist.InstrumentParameters["Zero"][1]),
        "instrument": {
            key: float(value[1])
            for key, value in hist.InstrumentParameters.items()
            if key in {"U", "V", "W", "X", "Y", "Z", "SH/L"}
        },
        "phases": phases,
        "vary_list": list(project.data["Covariance"]["data"].get("varyList", [])),
    }


def save(project: G2.G2Project, out: Path, stage: str) -> None:
    project.save()
    shutil.copyfile(project.filename, out / f"{stage}.gpx")


def run_uiso() -> None:
    G2.SetPrintLevel("warn")
    out = ANALYSIS / "physical" / "uiso"
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(out / "working.gpx"))
    project.set_Controls("cycles", 20)
    clean_flags(project)

    phase = project.phase("znwo4_wolframite")
    phase.set_refinements(
        {"Atoms": {atom.label: "U" for atom in phase.atoms()}}
    )
    for index, _atom in enumerate(phase.atoms()):
        variable = f"{phase.id}::AUiso:{index}"
        project.set_Controls("parmMin", 0.0001, variable=variable)
        project.set_Controls("parmMax", 0.03, variable=variable)
    project.refine()
    row = state(project, "01_znwo4_uiso")
    print(json.dumps(row, sort_keys=True), flush=True)
    save(project, out, "01_znwo4_uiso")
    (out / "stages.json").write_text(json.dumps([row], indent=2) + "\n")


def run_common_uiso() -> None:
    """Refine one shared Uiso for the dominant phase, avoiding atomwise overfit."""
    G2.SetPrintLevel("warn")
    out = ANALYSIS / "physical" / "common_uiso"
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(out / "working.gpx"))
    project.set_Controls("cycles", 20)
    clean_flags(project)

    phase = project.phase("znwo4_wolframite")
    variables = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
    phase.set_refinements(
        {"Atoms": {atom.label: "U" for atom in phase.atoms()}}
    )
    project.add_EquivConstr(variables)
    project.set_Controls("parmMin", 0.0001, variable=variables[0])
    project.set_Controls("parmMax", 0.03, variable=variables[0])
    project.refine()
    row = state(project, "01_common_znwo4_uiso")
    print(json.dumps(row, sort_keys=True), flush=True)
    save(project, out, "01_common_znwo4_uiso")
    (out / "stages.json").write_text(json.dumps([row], indent=2) + "\n")


def run_texture() -> None:
    """Compare a small set of low-index March-Dollase axes."""
    G2.SetPrintLevel("warn")
    root = ANALYSIS / "physical" / "texture"
    root.mkdir(parents=True, exist_ok=True)
    rows = []
    axes = ([1, 0, 1], [1, 0, 0], [0, 1, 0], [0, 0, 1])
    for axis in axes:
        tag = "".join(str(value) for value in axis)
        out = root / tag
        out.mkdir(parents=True, exist_ok=True)
        project = G2.G2Project(
            gpxfile=str(SOURCE), newgpx=str(out / "working.gpx")
        )
        project.set_Controls("cycles", 20)
        clean_flags(project)
        hist = project.histogram(0)
        phase = project.phase("znwo4_wolframite")
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = list(axis)
        variable = f"{phase.id}:{hist.id}:MD"
        project.set_Controls("parmMin", 0.5, variable=variable)
        project.set_Controls("parmMax", 2.0, variable=variable)
        project.refine()
        row = state(project, f"texture_{tag}")
        rows.append(row)
        print(json.dumps(row, sort_keys=True), flush=True)
        save(project, out, f"texture_{tag}")
    (root / "stages.json").write_text(json.dumps(rows, indent=2) + "\n")


def run_finish() -> None:
    """Re-relax accepted terms, then test global profile terms in stages."""
    G2.SetPrintLevel("warn")
    out = ANALYSIS / "physical" / "final_refine"
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(TEXTURE_SOURCE), newgpx=str(out / "working.gpx")
    )
    project.set_Controls("cycles", 30)
    clean_flags(project)
    hist = project.histogram(0)
    rows = []

    def refine_stage(name: str, repeats: int = 2) -> None:
        for _ in range(repeats):
            project.refine()
        row = state(project, name)
        rows.append(row)
        summary = {
            "stage": name,
            "rwp": row["rwp"],
            "rp": row["rp"],
            "rexp": row["rexp"],
            "zero": row["zero"],
            "instrument": row["instrument"],
            "fractions": {
                name: values["mass_fraction"]
                for name, values in row["phases"].items()
            },
            "texture": row["phases"]["znwo4_wolframite"][
                "preferred_orientation"
            ],
            "sizes": {
                name: values["size"] for name, values in row["phases"].items()
            },
            "vary_list": row["vary_list"],
        }
        print(json.dumps(summary, sort_keys=True), flush=True)
        save(project, out, name)

    # Re-relax peak positions with the supported [101] texture term.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Controls("parmMin", -0.2, variable=":0:Zero")
    project.set_Controls("parmMax", 0.7, variable=":0:Zero")
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    main = project.phase("znwo4_wolframite")
    main.set_HAP_refinements({"Pref.Ori.": True}, [hist])
    project.set_Controls("parmMin", 0.5, variable=f"{main.id}:{hist.id}:MD")
    project.set_Controls("parmMax", 2.0, variable=f"{main.id}:{hist.id}:MD")
    refine_stage("01_positions_texture")

    # Retain one isotropic coherent-domain size per phase.
    for phase in project.phases():
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
        project.set_Controls(
            "parmMin", 0.005, variable=f"{phase.id}:{hist.id}:Size;i"
        )
        project.set_Controls(
            "parmMax", 10.0, variable=f"{phase.id}:{hist.id}:Size;i"
        )
    refine_stage("02_isotropic_size")

    # Global Gaussian Caglioti profile terms; these are shared by all phases.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
    for key, low, high in (("U", 0.0, 20.0), ("V", -20.0, 20.0), ("W", 0.001, 30.0)):
        project.set_Controls("parmMin", low, variable=f":0:{key}")
        project.set_Controls("parmMax", high, variable=f":0:{key}")
    refine_stage("03_caglioti")

    # Axial-divergence asymmetry is a single global profile family.
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    project.set_Controls("parmMin", 0.0001, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.1, variable=":0:SH/L")
    refine_stage("04_axial_divergence")

    (out / "stages.json").write_text(json.dumps(rows, indent=2) + "\n")


def run_converge() -> None:
    """Converge the accepted full model after rolling back rejected profiles."""
    G2.SetPrintLevel("warn")
    out = ANALYSIS / "physical" / "converged"
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(ACCEPTED_PROFILE_SOURCE), newgpx=str(out / "working.gpx")
    )
    project.set_Controls("cycles", 50)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    hist = project.histogram(0)
    project.set_Controls("parmMin", -0.2, variable=":0:Zero")
    project.set_Controls("parmMax", 0.7, variable=":0:Zero")
    main = project.phase("znwo4_wolframite")
    project.set_Controls("parmMin", 0.5, variable=f"{main.id}:{hist.id}:MD")
    project.set_Controls("parmMax", 2.0, variable=f"{main.id}:{hist.id}:MD")
    for phase in project.phases():
        project.set_Controls(
            "parmMin", 0.005, variable=f"{phase.id}:{hist.id}:Size;i"
        )
        project.set_Controls(
            "parmMax", 10.0, variable=f"{phase.id}:{hist.id}:Size;i"
        )

    rows = []
    previous = None
    for iteration in range(1, 7):
        project.refine()
        row = state(project, f"iteration_{iteration:02d}")
        rows.append(row)
        print(
            json.dumps(
                {
                    "iteration": iteration,
                    "rwp": row["rwp"],
                    "rp": row["rp"],
                    "zero": row["zero"],
                    "fractions": {
                        name: values["mass_fraction"]
                        for name, values in row["phases"].items()
                    },
                    "texture": row["phases"]["znwo4_wolframite"][
                        "preferred_orientation"
                    ],
                    "sizes": {
                        name: values["size"][0]
                        for name, values in row["phases"].items()
                    },
                },
                sort_keys=True,
            ),
            flush=True,
        )
        save(project, out, f"iteration_{iteration:02d}")
        if previous is not None and abs(previous - row["rwp"]) < 1e-5:
            break
        previous = row["rwp"]
    (out / "stages.json").write_text(json.dumps(rows, indent=2) + "\n")


def run_stabilize() -> None:
    """Stabilize the best replay by fixing the weak WO3 cell at its checkpoint."""
    G2.SetPrintLevel("warn")
    out = ANALYSIS / "physical" / "stabilized"
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(BEST_REPLAY_SOURCE), newgpx=str(out / "working.gpx")
    )
    project.set_Controls("cycles", 50)
    project.phase("wo3_p1").clear_refinements({"Cell": False})
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    hist = project.histogram(0)
    project.set_Controls("parmMin", -0.2, variable=":0:Zero")
    project.set_Controls("parmMax", 0.7, variable=":0:Zero")
    main = project.phase("znwo4_wolframite")
    project.set_Controls("parmMin", 0.5, variable=f"{main.id}:{hist.id}:MD")
    project.set_Controls("parmMax", 2.0, variable=f"{main.id}:{hist.id}:MD")
    for phase in project.phases():
        project.set_Controls(
            "parmMin", 0.005, variable=f"{phase.id}:{hist.id}:Size;i"
        )
        project.set_Controls(
            "parmMax", 10.0, variable=f"{phase.id}:{hist.id}:Size;i"
        )
    rows = []
    for iteration in range(1, 5):
        project.refine()
        row = state(project, f"iteration_{iteration:02d}")
        rows.append(row)
        print(
            json.dumps(
                {
                    "iteration": iteration,
                    "rwp": row["rwp"],
                    "rp": row["rp"],
                    "max_shift_esd": project.data["Covariance"]["data"]
                    .get("Rvals", {})
                    .get("Max shft/sig"),
                    "fractions": {
                        name: values["mass_fraction"]
                        for name, values in row["phases"].items()
                    },
                },
                sort_keys=True,
            ),
            flush=True,
        )
        save(project, out, f"iteration_{iteration:02d}")
    (out / "stages.json").write_text(json.dumps(rows, indent=2) + "\n")


def run_uniaxial_size() -> None:
    """Test one morphology-matched uniaxial size family on ZnWO4."""
    G2.SetPrintLevel("warn")
    out = ANALYSIS / "physical" / "uniaxial_size_101"
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(STABILIZED_SOURCE), newgpx=str(out / "working.gpx")
    )
    project.set_Controls("cycles", 50)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    hist = project.histogram(0)
    main = project.phase("znwo4_wolframite")
    initial = float(main.data["Histograms"][hist.name]["Size"][1][0])
    main.setSampleProfile(hist, "size", "uniaxial", initial, initial, [1, 0, 1])
    main.set_HAP_refinements(
        {"Size": {"type": "uniaxial", "refine": True, "direction": [1, 0, 1]}},
        [hist],
    )
    for suffix in ("i", "a"):
        project.set_Controls(
            "parmMin", 0.005, variable=f"{main.id}:{hist.id}:Size;{suffix}"
        )
        project.set_Controls(
            "parmMax", 10.0, variable=f"{main.id}:{hist.id}:Size;{suffix}"
        )
    rows = []
    for iteration in range(1, 4):
        project.refine()
        row = state(project, f"iteration_{iteration:02d}")
        rows.append(row)
        print(
            json.dumps(
                {
                    "iteration": iteration,
                    "rwp": row["rwp"],
                    "rp": row["rp"],
                    "max_shift_esd": project.data["Covariance"]["data"]
                    .get("Rvals", {})
                    .get("Max shft/sig"),
                    "main_size": row["phases"]["znwo4_wolframite"]["size"],
                    "fractions": {
                        name: values["mass_fraction"]
                        for name, values in row["phases"].items()
                    },
                },
                sort_keys=True,
            ),
            flush=True,
        )
        save(project, out, f"iteration_{iteration:02d}")
    (out / "stages.json").write_text(json.dumps(rows, indent=2) + "\n")


def run_oxygen_extension() -> None:
    """Second bounded oxygen-coordinate start prompted by intensity residuals."""
    G2.SetPrintLevel("warn")
    out = ANALYSIS / "physical" / "oxygen_extension"
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(ANISOTROPIC_SOURCE), newgpx=str(out / "working.gpx")
    )
    project.set_Controls("cycles", 50)
    clean_flags(project)
    phase = project.phase("znwo4_wolframite")
    labels = {
        atom.label: "X" for atom in phase.atoms() if atom.element == "O"
    }
    phase.set_refinements({"Atoms": labels})
    for index, atom in enumerate(phase.atoms()):
        if atom.element != "O":
            continue
        for axis, coordinate in zip("xyz", atom.coordinates):
            variable = f"{phase.id}::dA{axis}:{index}"
            project.set_Controls("parmMin", coordinate - 0.015, variable=variable)
            project.set_Controls("parmMax", coordinate + 0.015, variable=variable)
    project.refine()
    row = state(project, "01_oxygen_extension")
    print(
        json.dumps(
            {
                "rwp": row["rwp"],
                "rp": row["rp"],
                "fractions": {
                    name: values["mass_fraction"]
                    for name, values in row["phases"].items()
                },
                "atoms": row["phases"]["znwo4_wolframite"]["atoms"],
                "max_shift_esd": project.data["Covariance"]["data"]
                .get("Rvals", {})
                .get("Max shft/sig"),
            },
            sort_keys=True,
        ),
        flush=True,
    )
    save(project, out, "01_oxygen_extension")
    (out / "stages.json").write_text(json.dumps([row], indent=2) + "\n")


def run_final_relax() -> None:
    """Re-enable only accepted specimen terms after the oxygen checkpoint."""
    G2.SetPrintLevel("warn")
    out = ANALYSIS / "physical" / "final_relax"
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(OXYGEN_SOURCE), newgpx=str(out / "working.gpx")
    )
    project.set_Controls("cycles", 50)
    clean_flags(project)
    hist = project.histogram(0)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Controls("parmMin", -0.2, variable=":0:Zero")
    project.set_Controls("parmMax", 0.7, variable=":0:Zero")

    main = project.phase("znwo4_wolframite")
    zno = project.phase("zno_wurtzite")
    main.set_refinements({"Cell": True})
    zno.set_refinements({"Cell": True})
    main.set_HAP_refinements({"Pref.Ori.": True}, [hist])
    project.set_Controls("parmMin", 0.5, variable=f"{main.id}:{hist.id}:MD")
    project.set_Controls("parmMax", 2.0, variable=f"{main.id}:{hist.id}:MD")

    main.set_HAP_refinements(
        {"Size": {"type": "uniaxial", "refine": True, "direction": [1, 0, 1]}},
        [hist],
    )
    for suffix in ("i", "a"):
        project.set_Controls(
            "parmMin", 0.005, variable=f"{main.id}:{hist.id}:Size;{suffix}"
        )
        project.set_Controls(
            "parmMax", 10.0, variable=f"{main.id}:{hist.id}:Size;{suffix}"
        )
    for phase in (zno, project.phase("wo3_p1")):
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
        project.set_Controls(
            "parmMin", 0.005, variable=f"{phase.id}:{hist.id}:Size;i"
        )
        project.set_Controls(
            "parmMax", 10.0, variable=f"{phase.id}:{hist.id}:Size;i"
        )

    rows = []
    for iteration in range(1, 6):
        project.refine()
        row = state(project, f"iteration_{iteration:02d}")
        rows.append(row)
        print(
            json.dumps(
                {
                    "iteration": iteration,
                    "rwp": row["rwp"],
                    "rp": row["rp"],
                    "max_shift_esd": project.data["Covariance"]["data"]
                    .get("Rvals", {})
                    .get("Max shft/sig"),
                    "zero": row["zero"],
                    "texture": row["phases"]["znwo4_wolframite"][
                        "preferred_orientation"
                    ],
                    "sizes": {
                        name: values["size"]
                        for name, values in row["phases"].items()
                    },
                    "fractions": {
                        name: values["mass_fraction"]
                        for name, values in row["phases"].items()
                    },
                },
                sort_keys=True,
            ),
            flush=True,
        )
        save(project, out, f"iteration_{iteration:02d}")
    (out / "stages.json").write_text(json.dumps(rows, indent=2) + "\n")


def run_full_grid() -> None:
    """Finalize the accepted model over every measured data point."""
    G2.SetPrintLevel("warn")
    out = ANALYSIS / "physical" / "full_grid"
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(FINAL_RELAX_SOURCE), newgpx=str(out / "working.gpx")
    )
    project.set_Controls("cycles", 50)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    x = hist.getdata("x")
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    rows = []
    for iteration in range(1, 5):
        project.refine()
        row = state(project, f"iteration_{iteration:02d}")
        rows.append(row)
        print(
            json.dumps(
                {
                    "iteration": iteration,
                    "rwp": row["rwp"],
                    "rp": row["rp"],
                    "rexp": row["rexp"],
                    "max_shift_esd": project.data["Covariance"]["data"]
                    .get("Rvals", {})
                    .get("Max shft/sig"),
                    "limits": list(map(float, hist.data["Limits"][1])),
                    "fractions": {
                        name: values["mass_fraction"]
                        for name, values in row["phases"].items()
                    },
                },
                sort_keys=True,
            ),
            flush=True,
        )
        save(project, out, f"iteration_{iteration:02d}")
    (out / "stages.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    if sys.argv[1] == "uiso":
        run_uiso()
    elif sys.argv[1] == "common_uiso":
        run_common_uiso()
    elif sys.argv[1] == "texture":
        run_texture()
    elif sys.argv[1] == "finish":
        run_finish()
    elif sys.argv[1] == "converge":
        run_converge()
    elif sys.argv[1] == "stabilize":
        run_stabilize()
    elif sys.argv[1] == "uniaxial_size":
        run_uniaxial_size()
    elif sys.argv[1] == "oxygen_extension":
        run_oxygen_extension()
    elif sys.argv[1] == "final_relax":
        run_final_relax()
    elif sys.argv[1] == "full_grid":
        run_full_grid()
    else:
        raise SystemExit(f"unknown mode: {sys.argv[1]}")
