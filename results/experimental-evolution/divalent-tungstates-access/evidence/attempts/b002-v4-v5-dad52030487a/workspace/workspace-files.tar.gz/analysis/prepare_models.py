from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parents[1]
COD = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)
OUT = ROOT / "analysis" / "models"
OUT.mkdir(parents=True, exist_ok=True)


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def adapted(cod_id: str, replacements: dict[str, str]) -> Structure:
    structure = Structure.from_file(cod_path(cod_id))
    structure.replace_species(replacements)
    return structure


models = {
    # Stable ambient-pressure wolframite topology, transferred from CoMoO4.
    "znwo4_wolframite": adapted("7205001", {"Co": "Zn", "Mo": "W"}),
    # Distinct ABX4 topology controls retained for explicit comparison.
    "znwo4_scheelite": adapted("7219229", {"Ca": "Zn"}),
    "znwo4_fergusonite": adapted("1546035", {"Ca": "Zn"}),
    "znwo4_triclinic": adapted("1528282", {"Mo": "W"}),
    "znwo4_c2m": adapted("2300504", {"Mg": "Zn", "Mo": "W"}),
    "znwo4_hg_c2c": adapted("2012578", {"Hg": "Zn"}),
    # Exact-composition precursor/reference candidates.
    "zno_wurtzite": Structure.from_file(cod_path("9004178")),
    "wo3_p21c": Structure.from_file(cod_path("1528915")),
    "wo3_p21m": Structure.from_file(cod_path("1010618")),
    "wo3_p4ncc": Structure.from_file(cod_path("1521532")),
    "wo3_p4nmm": Structure.from_file(cod_path("1521533")),
    "wo3_p21c_small": Structure.from_file(cod_path("1563541")),
    "wo3_p1": Structure.from_file(cod_path("2106293")),
    "wo3_pnma": Structure.from_file(cod_path("2107312")),
}

for name, structure in models.items():
    CifWriter(structure, symprec=0.01, significant_figures=8).write_file(
        OUT / f"{name}.cif"
    )

# GSAS-II's generic xye importer accepts sigma as the third column.
pattern = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
x = pattern["two_theta_deg"]
y = pattern["intensity"]
sigma = np.sqrt(np.maximum(y, 1.0))
np.savetxt(
    ROOT / "analysis" / "pattern.xye",
    np.column_stack((x, y, sigma)),
    fmt=("%.8f", "%.8f", "%.8f"),
    header="2theta intensity sigma",
    comments="# ",
)

# Starting profile only. Instrument terms are refined against the specimen.
(ROOT / "analysis" / "instrument.instprm").write_text(
    "#GSAS-II instrument parameter file for Cu Kalpha Bragg-Brentano data\n"
    "Type:PXC;Bank:1\n"
    "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
    "Zero:0.0;Polariz.:0.5;Azimuth:0.0\n"
    "U:2.0;V:-2.0;W:5.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
)
