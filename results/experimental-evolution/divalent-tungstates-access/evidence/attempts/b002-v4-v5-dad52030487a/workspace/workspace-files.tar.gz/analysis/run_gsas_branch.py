"""Create and stage a GSAS-II refinement branch for one structural model."""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"


def snapshot(project: G2.G2Project, branch_dir: Path, name: str) -> None:
    project.save(str(branch_dir / f"{name}.gpx"))


def record(project: G2.G2Project, stage: str, rows: list[dict]) -> None:
    hist = project.histogram(0)
    row = {
        "stage": stage,
        "residuals": {
            k: float(v)
            for k, v in hist.residuals.items()
            if isinstance(v, (int, float))
        },
        "cell": project.phase(0).get_cell(),
        "instrument": {
            k: float(v[1])
            for k, v in hist.InstrumentParameters.items()
            if isinstance(v, list) and len(v) > 1 and isinstance(v[1], (int, float))
        },
        "scale": float(
            project.phase(0).data["Histograms"][hist.name]["Scale"][0]
        ),
    }
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)


def refine(project: G2.G2Project, stage: str, branch_dir: Path, rows: list[dict]) -> None:
    project.refine()
    record(project, stage, rows)
    snapshot(project, branch_dir, stage)


def run(model_name: str) -> None:
    G2.SetPrintLevel("warn")
    branch_dir = ANALYSIS / "branches" / model_name
    branch_dir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(branch_dir / "initial.gpx"))
    hist = project.add_powder_histogram(
        str(ANALYSIS / "pattern.xye"),
        str(ANALYSIS / "instrument.instprm"),
        fmthint="xye",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"][1] = False
    phase = project.add_phase(
        str(ANALYSIS / "models" / f"{model_name}.cif"),
        phasename=model_name,
        histograms=[hist],
        fmthint="CIF",
    )
    project.set_Controls("cycles", 8)
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [900.0] + [0.0] * 11,
                "refine": True,
            },
        }
    )
    phase.set_HAP_refinements({"Scale": True}, [hist])
    snapshot(project, branch_dir, "initial")

    rows: list[dict] = []
    refine(project, "01_scale_background", branch_dir, rows)

    phase.set_refinements({"Cell": True})
    refine(project, "02_cell", branch_dir, rows)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "03_zero", branch_dir, rows)

    heavy = {
        atom.label: "X"
        for atom in phase.atoms()
        if atom.element in {"Zn", "W"}
    }
    if heavy:
        phase.set_refinements({"Atoms": heavy})
        refine(project, "04_heavy", branch_dir, rows)

    oxygen = {
        atom.label: "X" for atom in phase.atoms() if atom.element == "O"
    }
    if oxygen:
        phase.set_refinements({"Atoms": oxygen})
        refine(project, "05_oxygen", branch_dir, rows)

    phase.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 1.0, "refine": True}},
        [hist],
    )
    refine(project, "06_size", branch_dir, rows)

    phase.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
    )
    refine(project, "07_mustrain", branch_dir, rows)

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X"]})
    refine(project, "08_profile", branch_dir, rows)

    (branch_dir / "stages.json").write_text(json.dumps(rows, indent=2) + "\n")
    shutil.copyfile(project.filename, branch_dir / "latest.gpx")


if __name__ == "__main__":
    run(sys.argv[1])
