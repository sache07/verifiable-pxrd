"""Screen refined crystallographic models for implausible short contacts.

The stage JSON files contain the asymmetric-unit coordinates recorded directly
from GSAS-II.  Reconstruct the full structures with pymatgen and summarize the
first coordination shell around each cation.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from pymatgen.core import Lattice, Structure


SPACE_GROUPS = {
    "znwo4_wolframite": 13,
    "zno_wurtzite": 186,
    "wo3_p21c": 14,
    "wo3_p1": 2,
}


def make_structure(name: str, phase: dict) -> Structure:
    cell = phase["cell"]
    lattice = Lattice.from_parameters(
        cell["length_a"],
        cell["length_b"],
        cell["length_c"],
        cell["angle_alpha"],
        cell["angle_beta"],
        cell["angle_gamma"],
    )
    atoms = phase["atoms"]
    return Structure.from_spacegroup(
        SPACE_GROUPS[name],
        lattice,
        [atom["element"] for atom in atoms],
        [atom["coordinates"] for atom in atoms],
        labels=[atom["label"] for atom in atoms],
    )


def shell_summary(structure: Structure, phase_name: str) -> dict:
    expected = {"Zn": 4 if phase_name == "zno_wurtzite" else 6, "W": 6}
    shells: dict[str, list[list[float]]] = {}
    for site in structure:
        symbol = site.specie.symbol
        if symbol not in expected:
            continue
        oxygen_distances = sorted(
            float(neighbor.nn_distance)
            for neighbor in structure.get_neighbors(site, 3.2)
            if neighbor.specie.symbol == "O"
        )
        shell = oxygen_distances[: expected[symbol]]
        shells.setdefault(symbol, []).append(shell)

    result = {}
    for symbol, all_shells in shells.items():
        distances = [distance for shell in all_shells for distance in shell]
        result[f"{symbol}-O"] = {
            "coordination": expected[symbol],
            "minimum": min(distances),
            "maximum": max(distances),
            "mean": sum(distances) / len(distances),
            "representative": all_shells[0],
        }

    pair_distances = []
    for i, site in enumerate(structure):
        for neighbor in structure.get_neighbors(site, 2.5):
            j = int(neighbor.index)
            if i < j:
                pair_distances.append(
                    (float(neighbor.nn_distance), site.specie.symbol, neighbor.specie.symbol)
                )
    if pair_distances:
        distance, first, second = min(pair_distances)
        result["shortest_contact"] = {
            "pair": f"{first}-{second}",
            "distance": distance,
        }
    return result


def main(path: Path) -> None:
    rows = json.loads(path.read_text())
    output = []
    for row in rows:
        phases = {}
        for name, phase in row["phases"].items():
            structure = make_structure(name, phase)
            phases[name] = shell_summary(structure, name)
        output.append(
            {
                "stage": row["stage"],
                "rwp": row["rwp"],
                "phases": phases,
            }
        )
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main(Path(sys.argv[1]))
