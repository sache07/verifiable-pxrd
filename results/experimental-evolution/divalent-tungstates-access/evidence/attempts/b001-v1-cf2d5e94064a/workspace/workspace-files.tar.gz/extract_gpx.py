"""Extract saved GSAS-II profile arrays and model metadata for diagnostics."""

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


p = argparse.ArgumentParser()
p.add_argument("project", type=Path)
p.add_argument("output", type=Path)
a = p.parse_args()
a.output.mkdir(parents=True, exist_ok=True)

project = G2.G2Project(gpxfile=str(a.project.resolve()))
hist = project.histograms()[0]
arrays = [np.asarray(v) for v in hist.data["data"][1]]
np.savez_compressed(
    a.output / "profile.npz",
    x=arrays[0],
    observed=arrays[1],
    weight=arrays[2],
    calculated=arrays[3],
    background=arrays[4],
    residual=arrays[5],
)

rows = []
mass_scale = []
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    mass = float(phase.data["General"]["Mass"])
    scale = float(hap["Scale"][0])
    mass_scale.append(mass * scale)
    rows.append(
        {
            "name": phase.name,
            "mass": mass,
            "scale": scale,
            "cell": {k: float(v) for k, v in phase.get_cell().items()},
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    )
for row, value in zip(rows, mass_scale):
    row["weight_fraction"] = value / sum(mass_scale)

meta = {
    "histogram": hist.name,
    "residuals": {k: (float(v) if isinstance(v, (float, int, np.number)) else str(v)) for k, v in hist.residuals.items()},
    "instrument": {k: v for k, v in hist.InstrumentParameters.items()},
    "sample": hist.SampleParameters,
    "background": hist.Background,
    "phases": rows,
    "vary_list": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
}
(a.output / "model.json").write_text(json.dumps(meta, indent=2, default=str) + "\n")
