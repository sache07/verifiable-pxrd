"""Run the scorer's read-only GSAS atomic replay without bubblewrap.

The production scorer adds an OS namespace around the same worker. Some CI
kernels disable unprivileged namespaces, so this helper calls the worker in
process while retaining all of its project validation and fresh-profile logic.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path

import numpy as np


parser = argparse.ArgumentParser()
parser.add_argument("project", type=Path)
parser.add_argument("observed", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--histogram")
args = parser.parse_args()

project = args.project.resolve()
observed = args.observed.resolve()
output = args.output.resolve()
output.mkdir(parents=True, exist_ok=True)

worker_path = (
    Path(__file__).resolve().parent
    / "learned/divalent-tungstates/scorer/runtime/replay_worker.py"
)
spec = importlib.util.spec_from_file_location("native_replay_worker", worker_path)
worker = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(worker)

os.chdir(output)
report = worker.replay(
    {
        "project": str(project),
        "observed": str(observed),
        "histogram": args.histogram,
    }
)
with Path("prediction.npz").open("rb") as stream:
    z = np.load(stream)
    y = z["observed"]
    calculated = z["predicted"]
    weights = 1.0 / np.maximum(y, 1.0)
    loss = float(np.sum(weights * (y - calculated) ** 2))
    denominator = float(np.sum(weights * y**2))
report["fit_statistics"] = {
    "rwp_percent": float(100.0 * np.sqrt(loss / denominator)),
    "chi_square": loss,
}
Path("replay.json").write_text(json.dumps(report, indent=2) + "\n")
print(
    json.dumps(
        {
            "status": report["status"],
            "rwp_percent": report["fit_statistics"]["rwp_percent"],
            "chi_square": loss,
            "fractions": {
                phase["name"]: phase["weight_fraction"]
                for phase in report["phases"]
            },
            "review_flags": report["profile_review_flags"],
        },
        indent=2,
    )
)
