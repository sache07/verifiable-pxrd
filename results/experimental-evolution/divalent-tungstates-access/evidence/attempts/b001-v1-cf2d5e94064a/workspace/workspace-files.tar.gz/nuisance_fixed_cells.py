"""Refine nuisance terms while holding a physically nominated cell set fixed.

This is a rollback branch for testing whether a weak phase requires a
distorted metric. Cells and starting isotropic phase profiles are copied by
phase name from a template GPX. Background/scales accompany every block;
shared position terms, phase profiles and instrument widths are alternated.
"""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_trial import check_state, state


parser = argparse.ArgumentParser()
parser.add_argument("input", type=Path)
parser.add_argument("template", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
args.output.parent.mkdir(parents=True, exist_ok=True)

G2.SetPrintLevel("error")
project = G2.G2Project(
    gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve())
)
template = G2.G2Project(gpxfile=str(args.template.resolve()))
hist = project.histograms()[0]
template_hist = template.histograms()[0]

# Copy the topology-preserving, close-to-reference cells and corresponding
# isotropic profile starts from the nominated stable template.
for phase in project.phases():
    source = template.phase(phase.name)
    phase.data["General"]["Cell"] = copy.deepcopy(source.data["General"]["Cell"])
    hap = phase.data["Histograms"][hist.name]
    source_hap = source.data["Histograms"][template_hist.name]
    for key in ["Size", "Mustrain"]:
        hap[key] = copy.deepcopy(source_hap[key])

# Start shared/instrument nuisance values from the valid interior model.
inst = hist.InstrumentParameters
inst["Zero"][1] = min(0.245, max(-0.245, float(inst["Zero"][1])))

project.index_ids()
for key, low, high in [
    ("Zero", -0.25, 0.25),
    ("U", 0.0, 40.0),
    ("W", 2.0, 40.0),
    ("X", 0.1, 6.0),
    ("SH/L", 0.005, 0.10),
    ("Polariz.", 0.5, 1.0),
]:
    project.set_Controls("parmMin", low, variable=f":{hist.id}:{key}")
    project.set_Controls("parmMax", high, variable=f":{hist.id}:{key}")
project.set_Controls("parmMin", -800.0, variable=f":{hist.id}:Shift")
project.set_Controls("parmMax", 800.0, variable=f":{hist.id}:Shift")
for phase in project.phases():
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:{hist.id}:Size;i")
    project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:{hist.id}:Size;i")
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:{hist.id}:Mustrain;i")


def clear_flags() -> None:
    global hist
    project.data["Controls"]["data"]["parmFrozen"] = {}
    hist.clear_refinements(
        {
            "Instrument Parameters": [
                "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."
            ],
            "Sample Parameters": [
                "Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"
            ],
        }
    )
    hist.clear_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
            },
            [hist],
        )
        phase.set_refinements({"Atoms": {"all": " "}})


stages = []


def refine(name, setup, cycles=14) -> None:
    global hist
    clear_flags()
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, [hist])
    setup()
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    hist = project.histogram(hist.name)
    snapshot = state(project, hist, name)
    check_state(snapshot)
    stages.append(snapshot)


refine("scale_background", lambda: None, cycles=16)
refine(
    "shared_position_1",
    lambda: hist.set_refinements(
        {"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]}
    ),
    cycles=18,
)


def phase_profiles() -> None:
    for phase in project.phases():
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )


refine("phase_profiles_1", phase_profiles, cycles=18)
for parameter in ["W", "X", "U"]:
    refine(
        "instrument_" + parameter,
        lambda parameter=parameter: hist.set_refinements(
            {"Instrument Parameters": [parameter]}
        ),
        cycles=12,
    )
refine("phase_profiles_2", phase_profiles, cycles=18)
refine(
    "shared_position_2",
    lambda: hist.set_refinements(
        {"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]}
    ),
    cycles=18,
)

clear_flags()
project.save()
record = {
    "input": str(args.input.resolve()),
    "template": str(args.template.resolve()),
    "output": str(args.output.resolve()),
    "cells_fixed": True,
    "stages": stages,
}
args.output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"output": str(args.output), "final": stages[-1]}, indent=2))
