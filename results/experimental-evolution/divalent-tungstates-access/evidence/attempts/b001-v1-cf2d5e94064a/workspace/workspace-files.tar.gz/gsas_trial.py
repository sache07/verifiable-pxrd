"""Build and run a staged GSAS-II candidate trial.

Invoke with the GSAS-II interpreter, for example::

  $GSAS2_PYTHON gsas_trial.py --out work/trials/example \
      --phase CaWO4=/path/to/model.cif --phase WO3=/path/to/model.cif

Discovery trials intentionally stop before coordinate, texture, anisotropy or
roughness terms are introduced. Every candidate therefore sees the same
nuisance model.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import sys
import traceback

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from GSASII import GSASIIscriptable as G2


def instrument_text():
    return (
        "# Cu Kalpha Bragg-Brentano instrument; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.10;Polariz.:0.8;Azimuth:0.0\n"
        "U:12.0;V:0.0;W:12.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def independent_stats(hist):
    arrays = hist.data["data"][1]
    x = np.asarray(arrays[0], float)
    obs = np.asarray(arrays[1], float)
    calc = np.asarray(arrays[3], float)
    w = 1.0 / np.maximum(obs, 1.0)
    chi2 = float(np.sum(w * (obs - calc) ** 2))
    denom = float(np.sum(w * obs**2))
    residuals = {}
    for key, value in hist.residuals.items():
        try:
            residuals[key] = float(value)
        except (TypeError, ValueError):
            residuals[key] = str(value)
    return {
        "rwp_percent": float(100.0 * np.sqrt(chi2 / denom)),
        "chi_square": chi2,
        "min_calculated": float(np.min(calc)),
        "max_calculated": float(np.max(calc)),
        "gsas_residuals": residuals,
    }


def state(project, hist, stage):
    result = {"stage": stage, **independent_stats(hist)}
    inst = hist.InstrumentParameters
    result["instrument"] = {
        key: float(inst[key][1])
        for key in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]
        if key in inst
    }
    sample = hist.SampleParameters
    result["sample"] = {
        key: float(sample[key][0]) if isinstance(sample[key], list) else float(sample[key])
        for key in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"]
        if key in sample
    }
    result["background"] = {
        "type": hist.Background[0][0],
        "coefficients": [float(v) for v in hist.Background[0][3:]],
    }
    result["phases"] = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": {k: float(v) for k, v in phase.get_cell().items()},
                "mass": float(phase.data["General"]["Mass"]),
                "scale": float(hap["Scale"][0]),
                "size": [hap["Size"][0], *[float(v) for v in hap["Size"][1]]],
                "mustrain": [hap["Mustrain"][0], *[float(v) for v in hap["Mustrain"][1]]],
            }
        )
    return result


def check_state(s):
    if not np.isfinite(s["rwp_percent"]):
        raise RuntimeError("nonfinite Rwp")
    if s["min_calculated"] < -1e-5:
        raise RuntimeError("negative calculated profile")
    for phase in s["phases"]:
        if phase["scale"] <= 0:
            raise RuntimeError(f"nonpositive scale for {phase['name']}")
        lengths = [phase["cell"][f"length_{axis}"] for axis in "abc"]
        angles = [phase["cell"][f"angle_{axis}"] for axis in ["alpha", "beta", "gamma"]]
        if min(lengths) <= 1 or max(lengths) >= 50 or min(angles) <= 30 or max(angles) >= 150:
            raise RuntimeError(f"invalid cell for {phase['name']}")
        if phase["size"][1] <= 0 or phase["mustrain"][1] < 0:
            raise RuntimeError(f"invalid isotropic profile for {phase['name']}")
    inst = s["instrument"]
    if not (0 <= inst["U"] <= 40 and 2 <= inst["W"] <= 40 and 0.1 <= inst["X"] <= 6):
        raise RuntimeError("instrument profile left the laboratory bounds")
    if not (0.005 <= inst["SH/L"] <= 0.10):
        raise RuntimeError("axial divergence left the laboratory bounds")
    if not (-0.3 <= inst["Zero"] <= 0.3 and -800 <= s["sample"]["Shift"] <= 800):
        raise RuntimeError("angular correction left the laboratory bounds")


def run_refinement(project, hist, stages, name, setup):
    setup()
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    hist = project.histogram(hist.name)
    s = state(project, hist, name)
    check_state(s)
    stages.append(s)
    project.save()
    return hist


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--phase", action="append", required=True, help="NAME=PATH")
    parser.add_argument("--profile", action="store_true", help="include common isotropic profile stage")
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)

    source = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
    x, y = source.T
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(out / "observed.xye", np.column_stack([x, y, sigma]), fmt=["%.8f", "%.1f", "%.10f"])
    (out / "instrument.instprm").write_text(instrument_text())

    # The rolling percentile is used only to initialize the exact Chebyshev
    # coefficients that GSAS-II subsequently refines.
    bg = gaussian_filter1d(percentile_filter(y, 15, size=401, mode="nearest"), 80)
    tx = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    bg_coeff = np.polynomial.chebyshev.chebfit(tx, bg, 11).tolist()

    G2.SetPrintLevel("error")
    project = G2.G2Project(newgpx=str(out / "trial.gpx"))
    hist = project.add_powder_histogram(
        str(out / "observed.xye"), str(out / "instrument.instprm"), fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [300.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(bg_coeff),
                "coeffs": bg_coeff,
                "refine": False,
            },
        }
    )

    specs = []
    for phase_index, item in enumerate(args.phase):
        name, path = item.split("=", 1)
        phase = project.add_phase(str(Path(path).resolve()), phasename=name, histograms=[hist], fmthint="CIF")
        specs.append((phase, Path(path).resolve()))
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        initial_size = 1.0 if phase_index == 0 else 0.5
        hap["Size"][1][0] = initial_size
        hap["Size"][1][1] = initial_size
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        initial_strain = 2500.0 if phase_index == 0 else 300.0
        hap["Mustrain"][1][0] = initial_strain
        hap["Mustrain"][1][1] = initial_strain
        hap["Mustrain"][2] = [False, False, False]

    # Hard bounds are the frozen laboratory ranges, with only the scale lower
    # bound added to prevent a mathematically useful negative phase.
    project.index_ids()
    hid = hist.id
    for key, low, high in [
        ("Zero", -0.3, 0.3),
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10),
        ("Polariz.", 0.5, 1.0),
    ]:
        project.set_Controls("parmMin", low, variable=f":{hid}:{key}")
        project.set_Controls("parmMax", high, variable=f":{hid}:{key}")
    project.set_Controls("parmMin", -800.0, variable=f":{hid}:Shift")
    project.set_Controls("parmMax", 800.0, variable=f":{hid}:Shift")
    for phase, _ in specs:
        pid = project.phase(phase.name).id
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:{hid}:Mustrain;i")

    stages = []
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    hist = project.histogram(hist.name)
    stages.append(state(project, hist, "initial"))

    def setup_scale_background():
        hist.set_refinements({"Background": {"refine": True}})
        for phase, _ in specs:
            project.phase(phase.name).set_HAP_refinements({"Scale": True}, [hist])

    hist = run_refinement(project, hist, stages, "scale_background", setup_scale_background)

    def setup_zero():
        hist.set_refinements({"Instrument Parameters": ["Zero"]})

    hist = run_refinement(project, hist, stages, "zero", setup_zero)

    def setup_cells():
        for phase, _ in specs:
            project.phase(phase.name).set_refinements({"Cell": True})

    hist = run_refinement(project, hist, stages, "cells", setup_cells)

    def setup_shift():
        hist.set_refinements({"Sample Parameters": ["Shift"]})

    hist = run_refinement(project, hist, stages, "shift_cells", setup_shift)

    if args.profile:
        def setup_instrument_profile():
            hist.clear_refinements(
                {"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]}
            )
            for phase, _ in specs:
                project.phase(phase.name).clear_refinements({"Cell": True})
            hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})

        hist = run_refinement(project, hist, stages, "instrument_profile", setup_instrument_profile)

        def setup_phase_size():
            for phase, _ in specs:
                p = project.phase(phase.name)
                p.set_HAP_refinements(
                    {
                        "Size": {"type": "isotropic", "refine": True},
                    },
                    [hist],
                )

        hist = run_refinement(project, hist, stages, "phase_size", setup_phase_size)

        def setup_phase_strain():
            for phase, _ in specs:
                project.phase(phase.name).set_HAP_refinements(
                    {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
                )

        hist = run_refinement(project, hist, stages, "phase_strain", setup_phase_strain)

        def setup_axial_divergence():
            hist.set_refinements({"Instrument Parameters": ["SH/L"]})

        hist = run_refinement(project, hist, stages, "axial_divergence", setup_axial_divergence)

        def setup_position_polish():
            hist.set_refinements(
                {"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]}
            )
            for phase, _ in specs:
                project.phase(phase.name).set_refinements({"Cell": True})

        hist = run_refinement(project, hist, stages, "position_polish", setup_position_polish)

    project.save()
    result = {
        "status": "tested",
        "project": str(project.filename),
        "models": [{"name": p.name, "path": str(path)} for p, path in specs],
        "stages": stages,
    }
    (out / "trial.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(json.dumps({"status": "unknown", "error": str(exc), "traceback": traceback.format_exc()}, indent=2))
        raise
