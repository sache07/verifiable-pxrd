from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import gaussian_filter1d, minimum_filter1d, percentile_filter
from scipy.signal import find_peaks, peak_widths


data = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
x, y = data.T

# A wide rolling percentile tracks the smooth sampled background without
# following Bragg peaks. This is for phase discovery only, not refinement.
background = percentile_filter(y, percentile=15, size=401, mode="nearest")
background = gaussian_filter1d(background, 80)
signal = y - background
smooth = gaussian_filter1d(signal, 2.0)

peaks, props = find_peaks(smooth, prominence=80, distance=5, width=1)
width = peak_widths(smooth, peaks, rel_height=0.5)[0] * np.median(np.diff(x))
rows = []
for i, p in enumerate(peaks):
    rows.append((x[p], y[p], signal[p], props["prominences"][i], width[i]))
rows.sort(key=lambda r: r[3], reverse=True)

print(f"grid: {x[0]:.8f} to {x[-1]:.8f} deg; step {np.median(np.diff(x)):.8f}; points {len(x)}")
print(f"counts: min {y.min():.1f}, median {np.median(y):.1f}, max {y.max():.1f}")
print("two_theta  counts  net_est  prominence  fwhm_deg")
for row in rows[:120]:
    print("%9.4f %8.1f %9.1f %10.1f %9.4f" % row)

Path("work").mkdir(exist_ok=True)
np.savetxt(
    "work/discovery_peaks.csv",
    np.asarray(rows),
    delimiter=",",
    header="two_theta_deg,intensity,net_estimate,prominence,fwhm_deg",
    comments="",
)

fig, axes = plt.subplots(3, 1, figsize=(14, 10), constrained_layout=True)
for ax, lo, hi in zip(axes, [9.9, 40, 70], [40, 70, 100.1]):
    m = (x >= lo) & (x <= hi)
    ax.plot(x[m], y[m], lw=0.65, color="black")
    ax.plot(x[m], background[m], lw=1.0, color="tab:orange")
    ax.set_xlim(lo, hi)
    ax.set_ylabel("counts")
axes[-1].set_xlabel(r"$2\theta$ (deg, Cu K$\alpha$)")
fig.savefig("work/pattern_overview.png", dpi=160)
