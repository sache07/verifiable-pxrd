"""Fix one phase profile at nominated interior values and refit scales/background."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_trial import check_state, state


parser = argparse.ArgumentParser()
parser.add_argument("input", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--phase", required=True)
parser.add_argument("--size-um", type=float, required=True)
parser.add_argument("--microstrain-ppm", type=float, required=True)
parser.add_argument("--cycles", type=int, default=16)
args = parser.parse_args()
args.output.parent.mkdir(parents=True, exist_ok=True)

if not 0.04 <= args.size_um <= 1.5:
    raise ValueError("size outside laboratory range")
if not 0 <= args.microstrain_ppm <= 8000:
    raise ValueError("microstrain outside laboratory range")

G2.SetPrintLevel("error")
project = G2.G2Project(
    gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve())
)
hist = project.histograms()[0]
project.data["Controls"]["data"]["parmFrozen"] = {}
hist.clear_refinements(
    {
        "Instrument Parameters": [
            "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."
        ],
        "Sample Parameters": [
            "Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"
        ],
    }
)
hist.clear_refinements({"Background": True})
for phase in project.phases():
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements(
        {
            "Scale": True,
            "Size": True,
            "Mustrain": True,
            "Pref.Ori.": True,
            "HStrain": True,
        },
        [hist],
    )
    phase.set_refinements({"Atoms": {"all": " "}})

target = project.phase(args.phase)
hap = target.data["Histograms"][hist.name]
hap["Size"][0] = "isotropic"
hap["Size"][1][0] = args.size_um
hap["Size"][1][1] = args.size_um
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][0] = args.microstrain_ppm
hap["Mustrain"][1][1] = args.microstrain_ppm
hap["Mustrain"][2] = [False, False, False]

hist.set_refinements({"Background": {"refine": True}})
for phase in project.phases():
    phase.set_HAP_refinements({"Scale": True}, [hist])
project.set_Controls("cycles", args.cycles)
project.refine(makeBack=False)
hist = project.histogram(hist.name)
snapshot = state(project, hist, "fixed_profile")
check_state(snapshot)
project.save()
record = {
    "phase": args.phase,
    "fixed_size_um": args.size_um,
    "fixed_microstrain_ppm": args.microstrain_ppm,
    "state": snapshot,
}
args.output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
