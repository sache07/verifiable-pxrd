"""Enumerate chemically plausible COD structures and compare peak positions.

This is a discovery screen. Quantitative acceptance/rejection is done later in
one GSAS-II project with shared nuisance parameters.
"""

from __future__ import annotations

import gzip
import json
from pathlib import Path
import warnings

import numpy as np
from pymatgen.core import Composition, Structure
from pymatgen.io.cif import CifParser
from pymatgen.analysis.diffraction.xrd import XRDCalculator


INDEX = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/venv/"
    "lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz"
)
CIFS = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
TARGETS = {
    "CaWO4",
    "WO3",
    "CaCO3",
    "CaO",
    "CaO2",
    "Ca(OH)2",
    "Ca3WO6",
    "Ca4.26W10O30",
    "Ca2WO",
}


def cif_path(record_id: str) -> Path:
    i = str(record_id)
    return CIFS / i[0] / i[1:3] / i[3:5] / f"{i}.cif"


def reduced(formula: str) -> str:
    try:
        return Composition(formula).reduced_formula
    except Exception:
        return formula


peak_table = np.loadtxt("work/discovery_peaks.csv", delimiter=",", skiprows=1)
obs_pos = peak_table[:, 0]
obs_prom = peak_table[:, 3]
obs_strength = np.sqrt(np.clip(obs_prom / obs_prom.max(), 0, 1))


def position_score(two_theta: np.ndarray, intensity: np.ndarray):
    keep = (two_theta >= 10) & (two_theta <= 100) & (intensity >= 0.5)
    tt = two_theta[keep]
    ii = intensity[keep] / 100.0
    best = None
    for shift in np.linspace(-0.60, 0.30, 181):
        d = np.abs((tt + shift)[:, None] - obs_pos[None, :])
        nearest = d.argmin(axis=1)
        # A 0.16 degree tolerance admits broad major-phase lines but still
        # distinguishes polymorph peak families. Observed prominence prevents
        # chance matches to noise maxima from receiving full credit.
        match = np.exp(-0.5 * (d[np.arange(len(tt)), nearest] / 0.16) ** 2)
        value = float(np.sum(ii * match * obs_strength[nearest]) / np.sum(ii))
        if best is None or value > best[0]:
            best = (value, shift)
    return best


with gzip.open(INDEX, "rt") as stream:
    index = json.load(stream)

records = []
for system, entries in index.items():
    if not set(system.split("-")) <= {"Ca", "W", "O", "C", "H"}:
        continue
    for formula, record_id, indexed_sg, quality in entries:
        if formula not in TARGETS and reduced(formula) not in {reduced(t) for t in TARGETS}:
            continue
        path = cif_path(record_id)
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                parser = CifParser(path, occupancy_tolerance=1.0, frac_tolerance=0)
                structure = parser.parse_structures(primitive=False, on_error="raise")[0]
            block = next(iter(parser.as_dict().values()))
            sg_symbol, sg_number = structure.get_space_group_info(symprec=1e-3)
            pattern = XRDCalculator(wavelength=1.540598, symprec=1e-3).get_pattern(
                structure, two_theta_range=(9.9, 100.1)
            )
            score, shift = position_score(np.asarray(pattern.x), np.asarray(pattern.y))
            title = str(block.get("_publ_section_title", "")).replace("\n", " ")[:160]
            records.append(
                {
                    "cod_id": str(record_id),
                    "formula_index": formula,
                    "formula_parsed": structure.composition.reduced_formula,
                    "system": system,
                    "space_group": sg_symbol,
                    "space_group_number": sg_number,
                    "indexed_space_group_number": indexed_sg,
                    "cell": [round(v, 6) for v in (*structure.lattice.abc, *structure.lattice.angles)],
                    "sites": len(structure),
                    "density": round(float(structure.density), 5),
                    "rough_peak_score": round(score, 5),
                    "rough_shift_deg": round(shift, 4),
                    "quality_r": quality,
                    "title": title,
                    "warnings": [str(w.message) for w in caught],
                    "path": str(path),
                }
            )
        except Exception as exc:
            records.append(
                {
                    "cod_id": str(record_id),
                    "formula_index": formula,
                    "system": system,
                    "indexed_space_group_number": indexed_sg,
                    "quality_r": quality,
                    "path": str(path),
                    "parse_error": str(exc),
                }
            )

records.sort(key=lambda r: (r["formula_index"], -r.get("rough_peak_score", -1), r["cod_id"]))
Path("work/candidate_enumeration.json").write_text(json.dumps(records, indent=2) + "\n")
for row in records:
    if "parse_error" in row:
        print(row["formula_index"], row["cod_id"], "ERROR", row["parse_error"])
        continue
    print(
        f"{row['formula_index']:14s} {row['cod_id']} SG {row['space_group_number']:3d} "
        f"{row['space_group']:10s} score={row['rough_peak_score']:.3f} "
        f"shift={row['rough_shift_deg']:+.3f} sites={row['sites']:3d} "
        f"cell={row['cell'][:3]} title={row['title']}"
    )
