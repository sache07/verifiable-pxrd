"""Run one deliberately limited structural refinement from a stable GPX.

The two supported branches are (1) one constrained isotropic U value per
phase and (2) coordinates for a named subset of atoms.  All specimen,
instrument, cell and profile parameters remain fixed; only background and
positive phase scales accompany the requested structural variables.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_trial import check_state, state


parser = argparse.ArgumentParser()
parser.add_argument("input", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument(
    "--mode", choices=["uiso", "set_uiso", "coordinates"], required=True
)
parser.add_argument("--phase")
parser.add_argument("--atoms", help="comma-separated atom labels; default all atoms")
parser.add_argument("--reset-uiso", type=float)
parser.add_argument("--cycles", type=int, default=18)
args = parser.parse_args()
args.output.parent.mkdir(parents=True, exist_ok=True)

G2.SetPrintLevel("error")
project = G2.G2Project(
    gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve())
)
hist = project.histograms()[0]
project.data["Controls"]["data"]["parmFrozen"] = {}


def clear_flags() -> None:
    """Clear every refinement mask before enabling the requested block."""
    project.data["Controls"]["data"]["parmFrozen"] = {}
    hist.clear_refinements(
        {
            "Instrument Parameters": [
                "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."
            ],
            "Sample Parameters": [
                "Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"
            ],
        }
    )
    # GSAS-II returns immediately after handling Background, so this must be
    # a separate call.
    hist.clear_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
            },
            [hist],
        )
        phase.set_refinements({"Atoms": {"all": " "}})


clear_flags()
hist.set_refinements({"Background": {"refine": True}})
for phase in project.phases():
    phase.set_HAP_refinements({"Scale": True}, [hist])
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")

if args.mode == "uiso":
    # This sample generator uses one isotropic displacement value per phase.
    # Convert source-CIF anisotropic records and constrain all sites in each
    # phase to exactly that parsimonious model.
    project.get_Constraints("Phase")[:] = []
    for phase in project.phases():
        _, _, _, cia = phase.data["General"]["AtomPtrs"]
        atoms = list(phase.atoms())
        if args.reset_uiso is None:
            start = sum(float(atom.data[cia + 1]) for atom in atoms) / len(atoms)
            start = min(0.02, max(0.003, start))
        else:
            start = float(args.reset_uiso)
        for index, atom in enumerate(atoms):
            atom.data[cia] = "I"
            atom.data[cia + 1] = start
            atom.data[cia + 2 : cia + 8] = [0.0] * 6
            atom.refinement_flags = "U"
            variable = f"{phase.id}::AUiso:{index}"
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.02, variable=variable)
        if len(atoms) > 1:
            project.add_EquivConstr(
                [f"{phase.id}::AUiso:{i}" for i in range(len(atoms))],
                reloadIdx=True,
            )
elif args.mode == "set_uiso":
    if not args.phase or args.reset_uiso is None:
        raise ValueError("--phase and --reset-uiso are required for set_uiso")
    if not 0.003 <= args.reset_uiso <= 0.02:
        raise ValueError("fixed Uiso must be in the laboratory range")
    target = project.phase(args.phase)
    _, _, _, cia = target.data["General"]["AtomPtrs"]
    for atom in target.atoms():
        atom.data[cia] = "I"
        atom.data[cia + 1] = float(args.reset_uiso)
        atom.data[cia + 2 : cia + 8] = [0.0] * 6
        atom.refinement_flags = " "
elif args.mode == "coordinates":
    if not args.phase:
        raise ValueError("--phase is required for coordinate refinement")
    target = project.phase(args.phase)
    labels = (
        [label.strip() for label in args.atoms.split(",") if label.strip()]
        if args.atoms
        else [atom.label for atom in target.atoms()]
    )
    for label in labels:
        atom = target.atom(label)
        if atom is None:
            raise ValueError(f"No atom {label!r} in phase {target.name}")
        atom.refinement_flags = "X"
else:  # pragma: no cover - argparse guarantees this
    raise AssertionError(args.mode)

project.set_Controls("cycles", args.cycles)
project.refine(makeBack=False)
hist = project.histogram(hist.name)

if args.mode == "uiso":
    # GSAS clips the independent member of an equivalence at a parameter
    # bound, but in some releases does not propagate that clipped value back
    # to the dependent atom records. Explicitly synchronize the records and
    # then regenerate a consistent scale/background fit with U fixed.
    for phase in project.phases():
        _, _, _, cia = phase.data["General"]["AtomPtrs"]
        atoms = list(phase.atoms())
        common = min(0.02, max(0.003, float(atoms[0].data[cia + 1])))
        for atom in atoms:
            atom.data[cia + 1] = common
            atom.refinement_flags = " "
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    hist = project.histogram(hist.name)

snapshot = state(project, hist, args.mode)
check_state(snapshot)

atoms_out = {}
for phase in project.phases():
    _, _, _, cia = phase.data["General"]["AtomPtrs"]
    atoms_out[phase.name] = [
        {
            "label": atom.label,
            "element": atom.element,
            "coordinates": list(map(float, atom.coordinates)),
            "uiso_A2": float(atom.data[cia + 1]),
            "displacement_type": atom.data[cia],
            "refinement_flags": atom.refinement_flags,
        }
        for atom in phase.atoms()
    ]

project.save()
record = {
    "mode": args.mode,
    "phase": args.phase,
    "atoms": args.atoms,
    "state": snapshot,
    "atomic_model": atoms_out,
}
args.output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
