"""Coordinate-descent refinement of a converged GSAS-II project.

This deliberately alternates phase and instrument profile blocks so a broad
major phase cannot force the common instrument profile to a boundary before
phase-specific broadening has been fitted.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_trial import check_state, state


parser = argparse.ArgumentParser()
parser.add_argument("input", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--u", type=float, required=True)
parser.add_argument("--w", type=float, required=True)
parser.add_argument("--x", type=float, required=True)
args = parser.parse_args()
args.output.parent.mkdir(parents=True, exist_ok=True)

G2.SetPrintLevel("error")
project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
hist = project.histograms()[0]
phases = project.phases()
project.data["Controls"]["data"]["parmFrozen"] = {}

def clear_all_flags():
    """Start each block from an explicit, reproducible refinement mask."""
    global hist
    project.data["Controls"]["data"]["parmFrozen"] = {}
    # G2PwdrData.clear_refinements returns immediately for Background, so it
    # must be a separate call after instrument/sample flags are cleared.
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
            "Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        }
    )
    hist.clear_refinements({"Background": True})
    for old_phase in phases:
        phase = project.phase(old_phase.name)
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True, "HStrain": True}, [hist]
        )
        phase.set_refinements({"Atoms": {"all": " "}})


clear_all_flags()

inst = hist.InstrumentParameters
inst["U"][1] = args.u
inst["W"][1] = args.w
inst["X"][1] = args.x
if inst["Zero"][1] < -0.25:
    inst["Zero"][1] = -0.245
elif inst["Zero"][1] > 0.25:
    inst["Zero"][1] = 0.245
project.set_Controls("parmMin", -0.25, variable=f":{hist.id}:Zero")
project.set_Controls("parmMax", 0.25, variable=f":{hist.id}:Zero")

project.set_Controls("cycles", 0)
project.refine(makeBack=False)
hist = project.histogram(hist.name)
stages = [state(project, hist, "rebase")]


def refine(name, setup, cycles=10):
    global hist
    clear_all_flags()
    # Scale/background are nuisance terms in every coordinate block.
    hist.set_refinements({"Background": {"refine": True}})
    for old_phase in phases:
        project.phase(old_phase.name).set_HAP_refinements({"Scale": True}, [hist])
    setup()
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    hist = project.histogram(hist.name)
    snapshot = state(project, hist, name)
    check_state(snapshot)
    stages.append(snapshot)


def scales_background():
    pass


def position_initial():
    for phase in phases:
        project.phase(phase.name).set_refinements({"Cell": True})
    # Hold the rebased zero fixed while displacement and independent cells
    # recover peak positions; this prevents a bad scale-only local minimum.
    hist.set_refinements({"Sample Parameters": ["Shift"]})


refine("position_initial", position_initial, cycles=16)


def phase_profiles_on():
    for phase in phases:
        project.phase(phase.name).set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )


refine("phase_profile_1", phase_profiles_on, cycles=14)


def one_instrument(name):
    def setup():
        hist.set_refinements({"Instrument Parameters": [name]})

    return setup


for parameter in ["W", "X", "U"]:
    refine("instrument_" + parameter, one_instrument(parameter), cycles=10)

refine("phase_profile_2", phase_profiles_on, cycles=14)


def position_block():
    for phase in phases:
        project.phase(phase.name).set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]})


refine("position", position_block, cycles=14)
project.save()
(args.output.with_suffix(".json")).write_text(
    json.dumps(
        {
            "input": str(args.input.resolve()),
            "output": str(args.output.resolve()),
            "instrument_start": {"U": args.u, "W": args.w, "X": args.x},
            "stages": stages,
        },
        indent=2,
    )
    + "\n"
)
print(json.dumps({"output": str(args.output), "final": stages[-1]}, indent=2))
