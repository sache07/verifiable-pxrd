"""Test one bounded specimen/profile effect from a stable GSAS-II rollback."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_trial import check_state, state


p = argparse.ArgumentParser()
p.add_argument("input", type=Path)
p.add_argument("output", type=Path)
p.add_argument(
    "--effect", choices=["texture", "isotropic", "uniaxial", "roughness"], required=True
)
p.add_argument("--phase", default="CaWO4_7219229")
p.add_argument("--axis", default="0,0,1")
a = p.parse_args()
a.output.parent.mkdir(parents=True, exist_ok=True)
axis = [int(v) for v in a.axis.split(",")]

G2.SetPrintLevel("error")
project = G2.G2Project(gpxfile=str(a.input.resolve()), newgpx=str(a.output.resolve()))
hist = project.histograms()[0]
project.data["Controls"]["data"]["parmFrozen"] = {}

# Explicitly clear all masks. Background must be cleared in its own call
# because GSAS-II returns immediately for that key.
hist.clear_refinements(
    {
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
    }
)
hist.clear_refinements({"Background": True})
for old in project.phases():
    old.clear_refinements({"Cell": True})
    old.clear_HAP_refinements(
        {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True, "HStrain": True}, [hist]
    )
    old.set_refinements({"Atoms": {"all": " "}})

hist.set_refinements({"Background": {"refine": True}})
for old in project.phases():
    old.set_HAP_refinements({"Scale": True}, [hist])

target = project.phase(a.phase)
hap = target.data["Histograms"][hist.name]
if a.effect == "texture":
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = axis
    project.set_Controls("parmMin", 0.7, variable=f"{target.id}:{hist.id}:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{target.id}:{hist.id}:MD")
elif a.effect == "isotropic":
    value = float(hap["Mustrain"][1][0])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = value
    hap["Mustrain"][2][0] = True
    project.set_Controls("parmMin", 0.0, variable=f"{target.id}:{hist.id}:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{target.id}:{hist.id}:Mustrain;i")
elif a.effect == "uniaxial":
    value = float(hap["Mustrain"][1][0])
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = value
    hap["Mustrain"][1][1] = value
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    hap["Mustrain"][3] = axis
    for label in ["Mustrain;i", "Mustrain;a"]:
        project.set_Controls("parmMin", 0.0, variable=f"{target.id}:{hist.id}:{label}")
        project.set_Controls("parmMax", 8000.0, variable=f"{target.id}:{hist.id}:{label}")
else:
    hist.SampleParameters["SurfRoughA"] = [0.3, True]
    hist.SampleParameters["SurfRoughB"] = [0.1, True]
    project.set_Controls("parmMin", 0.05, variable=f":{hist.id}:SurfRoughA")
    project.set_Controls("parmMax", 0.6, variable=f":{hist.id}:SurfRoughA")
    project.set_Controls("parmMin", 0.02, variable=f":{hist.id}:SurfRoughB")
    project.set_Controls("parmMax", 0.5, variable=f":{hist.id}:SurfRoughB")

project.set_Controls("cycles", 16)
project.refine(makeBack=False)
hist = project.histogram(hist.name)
snapshot = state(project, hist, a.effect)
check_state(snapshot)
project.save()
record = {"effect": a.effect, "axis": axis, "phase": a.phase, "state": snapshot}
a.output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
