from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


p = argparse.ArgumentParser()
p.add_argument("source", type=Path)
p.add_argument("output", type=Path)
p.add_argument("--cycles", type=int, default=30)
p.add_argument("--fix-uiso", action="store_true")
p.add_argument("--fix-shift", action="store_true")
p.add_argument("--fix-x", action="store_true")
args = p.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.source.resolve()))
project.save(str(args.output.resolve()))
hist = project.histogram(0)
if args.fix_shift:
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
if args.fix_x:
    hist.clear_refinements({"Instrument Parameters": ["X"]})
if args.fix_uiso:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "X"
project.set_Controls("cycles", args.cycles)
project.refine()
project.save()
print(json.dumps({
    "output": args.output.name,
    "wR_percent": hist.get_wR(),
    "fractions": hist.ComputeMassFracs(),
    "zero": hist.InstrumentParameters["Zero"],
    "shift": hist.SampleParameters["Shift"],
    "X": hist.InstrumentParameters["X"],
    "uiso": {phase.name: [atom.uiso for atom in phase.atoms()] for phase in project.phases()},
}, indent=2))
