from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


path = Path(sys.argv[1] if len(sys.argv) > 1 else "working.gpx").resolve()
project = G2.G2Project(gpxfile=str(path))
hist = project.histogram(0)
x = np.asarray(hist.getdata("X"), float)
obs = np.asarray(hist.getdata("Yobs"), float)
calc = np.asarray(hist.getdata("Ycalc"), float)
bkg = np.asarray(hist.getdata("Background"), float)
diff = obs - calc
weight = 1 / np.maximum(obs, 1)
np.savetxt("diagnostic_fit.csv", np.column_stack([x, obs, calc, diff, bkg]), delimiter=",",
           header="two_theta_deg,observed,calculated,difference,background", comments="")

print(f"project={path.name} histogram={hist.name} wR={hist.get_wR():.8f}")
print("range weighted_R_percent mean_diff rms_std_resid")
for lo, hi in [(10, 20), (20, 30), (30, 40), (40, 50), (50, 60), (60, 70), (70, 80), (80, 90), (90, 100.1)]:
    sel = (x >= lo) & (x < hi)
    wr = 100 * np.sqrt(np.sum(weight[sel] * diff[sel] ** 2) / np.sum(weight[sel] * obs[sel] ** 2))
    print(f"{lo:4.0f}-{hi:5.1f} {wr:12.6f} {diff[sel].mean():12.4f} {np.sqrt(np.mean(weight[sel]*diff[sel]**2)):12.4f}")

order = np.argsort(np.abs(diff) / np.sqrt(np.maximum(obs, 1)))[::-1]
print("largest standardized residuals: angle obs calc diff stdres")
for i in order[:40]:
    print(f"{x[i]:11.6f} {obs[i]:9.2f} {calc[i]:11.3f} {diff[i]:11.3f} {diff[i]/np.sqrt(max(obs[i],1)):10.3f}")

summary = {
    "wR_percent": hist.get_wR(),
    "residuals": hist.residuals,
    "mass_fractions": hist.ComputeMassFracs(),
    "vary_list": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    "variables": project.data.get("Covariance", {}).get("data", {}).get("variables", []).tolist(),
    "sig": project.data.get("Covariance", {}).get("data", {}).get("sig", []).tolist(),
}
Path("diagnostic_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
