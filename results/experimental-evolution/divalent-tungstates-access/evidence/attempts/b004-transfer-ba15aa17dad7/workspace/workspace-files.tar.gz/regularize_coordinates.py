from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


PARENTS = {
    "Ba3W2O9": {
        "O2": [0.5, 0.3333, 0.4167], "O1": [0.1667, 0.0, 0.25],
        "W1": [0.0, 0.0, 0.646], "Ba1": [0.6667, 0.0, 0.25],
    },
    "WO3": {
        "O6": [0.714, 0.487, 0.721], "O2": [0.225, 0.474, 0.007],
        "W1": [0.028, 0.037, 0.746], "O5": [0.716, 0.043, 0.708],
        "O3": [0.998, 0.262, 0.712], "O1": [0.206, 0.042, 0.995],
        "W2": [0.534, 0.023, 0.75], "O4": [0.519, 0.259, 0.789],
    },
    "BaCO3": {
        "Ba": [0.25, 0.4162, 0.7556], "C": [0.25, 0.7434, -0.0711],
        "O1": [0.25, 0.9011, -0.0775], "O2": [0.4654, 0.6805, -0.0788],
    },
}

p = argparse.ArgumentParser()
p.add_argument("source", type=Path)
p.add_argument("output", type=Path)
p.add_argument("--scale", type=float, default=1.0, help="multiplier on prior-limited light-atom displacement")
p.add_argument("--refine-uiso", action="store_true")
args = p.parse_args()

# Factors put the fitted element RMS approximately at the generator's maximum
# prior displacement (0.04 A for non-O and 0.05 A for O); --scale probes within it.
factors = {
    ("Ba3W2O9", "O"): 0.90 * args.scale,
    ("WO3", "O"): 0.46 * args.scale,
    ("BaCO3", "C"): 0.48 * args.scale,
    ("BaCO3", "O"): 0.74 * args.scale,
}

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.source.resolve()))
project.save(str(args.output.resolve()))
hist = project.histogram(0)
for phase in project.phases():
    parent = PARENTS[phase.name]
    for atom in phase.atoms():
        if (phase.name, atom.element) in factors:
            old = np.asarray(atom.coordinates, float)
            origin = np.asarray(parent[atom.label], float)
            delta = old - origin
            delta -= np.rint(delta)
            atom.coordinates = ((origin + factors[(phase.name, atom.element)] * delta + 0.5) % 1 - 0.5).tolist()
            atom.refinement_flags = "U" if args.refine_uiso else " "
        else:
            atom.refinement_flags = "XU" if args.refine_uiso else "X"
project.set_Controls("cycles", 35)
project.refine()
project.save()
print(json.dumps({
    "output": args.output.name,
    "scale": args.scale,
    "refine_uiso": args.refine_uiso,
    "wR_percent": hist.get_wR(),
    "fractions": hist.ComputeMassFracs(),
    "uiso": {phase.name: [atom.uiso for atom in phase.atoms()] for phase in project.phases()},
}, indent=2))
