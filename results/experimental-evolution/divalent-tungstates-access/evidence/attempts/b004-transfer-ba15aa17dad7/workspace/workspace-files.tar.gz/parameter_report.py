from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


project = G2.G2Project(gpxfile=str(Path(sys.argv[1]).resolve()))
hist = project.histogram(0)
report = {
    "project": Path(sys.argv[1]).name,
    "wR_percent": hist.get_wR(),
    "mass_fractions": hist.ComputeMassFracs(),
    "instrument": {k: v for k, v in hist.InstrumentParameters.items()
                   if k in ["Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]},
    "sample": {k: v for k, v in hist.SampleParameters.items()
               if k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"]},
    "background": hist.Background,
    "phases": {},
}
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    cia = phase.data["General"]["AtomPtrs"][3]
    report["phases"][phase.name] = {
        "cell": phase.get_cell(),
        "scale": hap["Scale"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "pref_ori": hap["Pref.Ori."],
        "atoms": [{"label": atom.label, "type": atom.element, "xyz": atom.coordinates,
                   "uiso": atom.uiso, "refinement_flags": atom.refinement_flags}
                  for atom in phase.atoms()],
    }
print(json.dumps(report, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x)))
