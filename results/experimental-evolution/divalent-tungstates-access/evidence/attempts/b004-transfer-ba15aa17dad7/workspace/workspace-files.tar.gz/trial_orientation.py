from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


source = Path(sys.argv[1] if len(sys.argv) > 1 else "working.gpx").resolve()
phase_name = sys.argv[2] if len(sys.argv) > 2 else "Ba3W2O9"
axes = [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]

G2.SetPrintLevel("warn")
results = []
for axis in axes:
    tag = "".join(map(str, axis))
    output = source.parent / f"trial_po_{phase_name}_{tag}.gpx"
    project = G2.G2Project(gpxfile=str(source))
    project.save(str(output))
    phase = project.phase(phase_name)
    hist = project.histogram(0)
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = axis
    project.set_Controls("cycles", 10)
    project.refine()
    project.save()
    row = {
        "axis": axis,
        "project": output.name,
        "wR_percent": hist.get_wR(),
        "ratio": hap["Pref.Ori."][1],
        "mass_fractions": hist.ComputeMassFracs(),
    }
    results.append(row)
    print(json.dumps(row))
Path(f"trial_po_{phase_name}.json").write_text(json.dumps(results, indent=2) + "\n")
