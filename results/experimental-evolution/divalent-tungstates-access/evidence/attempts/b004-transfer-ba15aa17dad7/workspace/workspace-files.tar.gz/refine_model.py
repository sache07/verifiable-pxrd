from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, minimum_filter1d

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIpath


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
INSTRUMENT = ROOT / "instrument.instprm"
BA3WO = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/53/38/1533878.cif")
WO3 = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif")
BACO3 = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/01/09/9010928.cif")


def snapshot(project, label):
    hist = project.histogram(0)
    values = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "instrument": {k: v for k, v in hist.InstrumentParameters.items() if k in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]},
        "sample": {k: v for k, v in hist.SampleParameters.items() if k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"]},
        "background": hist.Background,
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        values["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    try:
        values["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        values["mass_fractions_error"] = str(exc)
    print(json.dumps(values, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x)))
    with (ROOT / "refinement_history.jsonl").open("a") as stream:
        stream.write(json.dumps(values, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x)) + "\n")


def run_step(project, label, cycles=8):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    snapshot(project, label)


def initialize():
    for name in ["initial.gpx", "refinement_history.jsonl"]:
        (ROOT / name).unlink(missing_ok=True)
    project = G2.G2Project(newgpx=str(ROOT / "initial.gpx"))
    p1 = project.add_phase(str(BA3WO), phasename="Ba3W2O9", fmthint="CIF")
    p2 = project.add_phase(str(WO3), phasename="WO3", fmthint="CIF")
    p3 = project.add_phase(str(BACO3), phasename="BaCO3", fmthint="CIF")
    hist = project.add_powder_histogram(str(PATTERN), str(INSTRUMENT), phases=[p1, p2, p3], fmthint="comma")
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    # Initialize a smooth positive empirical background from a morphological
    # estimate, expressed in the same Chebyshev convention GSAS-II evaluates.
    x = np.asarray(hist.getdata("X"), float)
    y = np.asarray(hist.getdata("Yobs"), float)
    floor = gaussian_filter1d(minimum_filter1d(y, size=401, mode="nearest"), 100)
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    coeffs = np.polynomial.chebyshev.chebfit(t, floor, 11).tolist()
    hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": len(coeffs), "coeffs": coeffs, "refine": False}})

    for phase, initial_scale, initial_size, initial_strain in [
        (p1, 0.70, 0.10, 1500.0),
        (p2, 0.25, 0.50, 300.0),
        (p3, 0.05, 0.50, 300.0),
    ]:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [initial_scale / phase.data["General"]["Mass"], False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = initial_size
        hap["Size"][1][1] = initial_size
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = initial_strain
        hap["Mustrain"][1][1] = hap["Mustrain"][1][0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        # Registered models carry Uiso=0; use a physical starting value.
        cia = phase.data["General"]["AtomPtrs"][3]
        for atom in phase.data["Atoms"]:
            atom[cia] = "I"
            atom[cia + 1] = 0.008

    project.save()
    return project


def main():
    G2.SetPrintLevel("warn")
    project = initialize()
    hist = project.histogram(0)
    phases = project.phases()

    # Establish scale/background with fixed structural and profile parameters.
    hist.set_refinements({"Background": True})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    run_step(project, "scale_background", 5)

    # Cell metrics and the two distinguishable angular displacement terms.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]})
    run_step(project, "cells_zero_shift", 8)

    # Instrument width from the sharp WO3 lines, plus phase-specific size/strain.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in phases:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    run_step(project, "profile", 12)

    # Reference mismatch is symmetry-preserving, so refine coordinates in the
    # published space groups. Keep ADPs fixed until coordinates stabilize.
    for phase in phases:
        phase.set_refinements({"Atoms": {"all": "X"}})
    run_step(project, "coordinates", 12)

    # Polarization and phase Uiso are the remaining broad intensity terms.
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    for phase in phases:
        phase.set_refinements({"Atoms": {"all": "XU"}})
    run_step(project, "uiso_polarization", 12)

    project.save(str(ROOT / "working.gpx"))
    print(f"GSAS-II revision {GSASIIpath.GetVersionNumber()}")


if __name__ == "__main__":
    main()
