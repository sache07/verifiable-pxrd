from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


p = argparse.ArgumentParser()
p.add_argument("source", type=Path)
p.add_argument("output", type=Path)
p.add_argument("--estimate", choices=["linear", "robust"], default="robust")
args = p.parse_args()
params = {
    "linear": np.array([483.049775, 495.489594, 669.155314, 1963.61362, 10.4728329, 1.59493091]),
    "robust": np.array([490.555186, 494.282972, 669.477916, 1959.68163, 10.2164946, 1.57718068]),
}[args.estimate]

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.source.resolve()))
project.save(str(args.output.resolve()))
hist = project.histogram(0)
x = np.asarray(hist.getdata("X"), float)
t01 = (x-x[0])/(x[-1]-x[0])
background = (params[0]*(1-t01)**2 + params[1]*2*t01*(1-t01) + params[2]*t01**2
              + params[3]*(1+(x-x[0])/params[4])**(-params[5]))
coeffs = np.polynomial.chebyshev.chebfit(2*t01-1, background, 17).tolist()
hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 18,
                                      "coeffs": coeffs, "refine": False}})
# Remove the two numerical near-degeneracies; their current combined profiles
# are retained exactly while the physically meaningful parameters converge.
hist.clear_refinements({"Instrument Parameters": ["X"]})
hist.clear_refinements({"Sample Parameters": ["Shift"]})
project.set_Controls("cycles", 40)
project.refine()
project.save()
print(json.dumps({
    "output": args.output.name,
    "estimate": args.estimate,
    "background_parameters": params.tolist(),
    "wR_percent": hist.get_wR(),
    "fractions": hist.ComputeMassFracs(),
    "uiso": {phase.name: [atom.uiso for atom in phase.atoms()] for phase in project.phases()},
}, indent=2))
