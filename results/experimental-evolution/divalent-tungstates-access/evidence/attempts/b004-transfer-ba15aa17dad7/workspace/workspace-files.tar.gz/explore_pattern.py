from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import minimum_filter1d, gaussian_filter1d
from scipy.signal import find_peaks, peak_widths


x, y = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1).T

# A broad morphological floor is sufficient for peak discovery only; all later
# fitting uses the untouched counts.
floor = minimum_filter1d(y, size=401, mode="nearest")
background = gaussian_filter1d(floor, sigma=100)
signal = y - background
peaks, props = find_peaks(signal, prominence=80, distance=10)
order = peaks[np.argsort(props["prominences"])[::-1]]
widths = peak_widths(signal, order, rel_height=0.5)[0] * np.median(np.diff(x))

print(f"points={len(x)} range={x[0]:.8f}..{x[-1]:.8f} step={np.median(np.diff(x)):.7f}")
print(f"intensity min/median/max={y.min():.1f}/{np.median(y):.1f}/{y.max():.1f}")
print("rank two_theta intensity prominence approx_fwhm_deg")
for rank, (idx, width) in enumerate(zip(order[:100], widths[:100]), 1):
    prominence = signal[idx] - max(signal[max(0, idx - 150):idx].min(initial=signal[idx]),
                                   signal[idx + 1:min(len(signal), idx + 151)].min(initial=signal[idx]))
    print(f"{rank:3d} {x[idx]:11.6f} {y[idx]:10.1f} {prominence:10.1f} {width:10.4f}")

fig, axes = plt.subplots(3, 1, figsize=(16, 10), constrained_layout=True)
for ax, (lo, hi) in zip(axes, [(9.9, 40), (40, 70), (70, 100.1)]):
    sel = (x >= lo) & (x <= hi)
    ax.plot(x[sel], y[sel], lw=0.65, color="black")
    ax.set_xlim(lo, hi)
    ax.set_ylabel("counts")
    ax.grid(alpha=0.15)
axes[-1].set_xlabel(r"$2\theta$ (deg, Cu K$\alpha$)")
fig.savefig("pattern_overview.png", dpi=160)
