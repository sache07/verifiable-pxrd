import matplotlib.pyplot as plt
import numpy as np


x, obs, calc, diff, bkg = np.loadtxt("diagnostic_fit.csv", delimiter=",", skiprows=1).T
fig, axes = plt.subplots(4, 1, figsize=(17, 13), constrained_layout=True)
regions = [(9.9, 35), (35, 60), (60, 80), (80, 100.1)]
for ax, (lo, hi) in zip(axes, regions):
    sel = (x >= lo) & (x <= hi)
    offset = -0.12 * max(obs[sel].max(), 1)
    ax.plot(x[sel], obs[sel], color="black", lw=0.6, label="observed")
    ax.plot(x[sel], calc[sel], color="red", lw=0.7, label="calculated")
    ax.plot(x[sel], diff[sel] + offset, color="blue", lw=0.55, label="difference + offset")
    ax.plot(x[sel], bkg[sel], color="green", lw=0.6, label="background")
    ax.axhline(offset, color="gray", lw=0.4)
    ax.set_xlim(lo, hi)
    ax.set_ylabel("counts")
axes[0].legend(ncol=4, fontsize=8)
axes[-1].set_xlabel(r"$2\theta$ (deg)")
fig.savefig("diagnostic_fit.png", dpi=160)
