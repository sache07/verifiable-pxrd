from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


source = Path("stable_u.gpx").resolve()
G2.SetPrintLevel("warn")
rng = np.random.default_rng(34119)
rows = []
for trial in range(8):
    project = G2.G2Project(gpxfile=str(source))
    output = source.parent / f"trial_ba3_restart_{trial}.gpx"
    project.save(str(output))
    hist = project.histogram(0)
    hist.clear_refinements({"Background": False})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]})
    hist.clear_refinements({"Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
    phase = project.phase("Ba3W2O9")
    atoms = {atom.label: atom for atom in phase.atoms()}
    # Random symmetry-allowed restart around the converged coordinates.
    for label, indices in {"O2": [0, 1, 2], "O1": [0], "W1": [2], "Ba1": [0]}.items():
        xyz = list(atoms[label].coordinates)
        for i in indices:
            xyz[i] += rng.normal(scale=0.004)
        atoms[label].coordinates = xyz
    phase.set_refinements({"Atoms": {"all": "X"}})
    phase.set_HAP_refinements({"Pref.Ori.": True})
    project.set_Controls("cycles", 35)
    project.refine()
    project.save()
    row = {"trial": trial, "project": output.name, "wR_percent": hist.get_wR(),
           "ratio": phase.data["Histograms"][hist.name]["Pref.Ori."][1],
           "coordinates": {atom.label: atom.coordinates for atom in phase.atoms()}}
    rows.append(row)
    print(json.dumps(row), flush=True)
Path("trial_ba3_restarts.json").write_text(json.dumps(rows, indent=2) + "\n")
