from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


project = G2.G2Project(gpxfile=str(Path(sys.argv[1]).resolve()))
hist = project.histogram(0)
targets = [17.71, 23.82, 27.71, 30.77, 33.50, 33.82, 34.33, 38.89, 40.72,
           42.96, 45.71, 62.99, 71.52, 83.65]
for target in targets:
    print(f"\nTARGET {target:.3f}")
    for phase, block in hist.data["Reflection Lists"].items():
        for refl in block["RefList"]:
            if abs(float(refl[5]) - target) <= 0.18:
                print(phase, "hkl", [int(v) for v in refl[:3]], "mult", refl[3],
                      "d", f"{refl[4]:.6f}", "pos", f"{refl[5]:.6f}",
                      "Fobs", f"{refl[9]:.2f}", "Fcalc", f"{refl[10]:.2f}")
