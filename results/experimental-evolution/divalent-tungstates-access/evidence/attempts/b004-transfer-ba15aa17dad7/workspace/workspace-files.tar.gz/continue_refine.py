from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--cycles", type=int, default=16)
parser.add_argument("--reset-uiso", action="store_true")
parser.add_argument("--wo3-po", default="keep", choices=["keep", "none", "001", "100", "010", "110", "111"])
parser.add_argument("--baco3-po", default="keep", choices=["keep", "none", "001", "100", "010", "110", "111"])
parser.add_argument("--roughness", action="store_true")
args = parser.parse_args()


def set_po(project, phase_name, value):
    if value == "keep":
        return
    hist = project.histogram(0)
    hap = project.phase(phase_name).data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = value != "none"
    if value != "none":
        hap["Pref.Ori."][3] = [int(v) for v in value]


G2.SetPrintLevel("warn")
source = args.source.resolve()
output = args.output.resolve()
project = G2.G2Project(gpxfile=str(source))
project.save(str(output))
project.update_ids()
hist = project.histogram(0)

set_po(project, "WO3", args.wo3_po)
set_po(project, "BaCO3", args.baco3_po)

if args.reset_uiso:
    # The forward experiment applies one physical scalar Uiso per phase. Tie
    # all symmetry-unique sites accordingly rather than allowing negative,
    # noise-fitting site ADPs.
    starts = {"Ba3W2O9": 0.008, "WO3": 0.008, "BaCO3": 0.008}
    for phase in project.phases():
        for atom in phase.atoms():
            atom.uiso = starts[phase.name]
            atom.refinement_flags = "XU"
        variables = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables)

if args.roughness:
    hist.SampleParameters["SurfRoughA"] = [0.3, True]
    hist.SampleParameters["SurfRoughB"] = [0.1, True]

project.set_Controls("cycles", args.cycles)
project.refine()
project.save()

row = {
    "source": source.name,
    "output": output.name,
    "wR_percent": hist.get_wR(),
    "mass_fractions": hist.ComputeMassFracs(),
    "instrument": {k: hist.InstrumentParameters[k] for k in ["Zero", "Polariz.", "U", "W", "X", "SH/L"]},
    "sample": {k: hist.SampleParameters[k] for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
    "phases": {},
}
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    row["phases"][phase.name] = {
        "uiso": [atom.uiso for atom in phase.atoms()],
        "pref_ori": hap["Pref.Ori."],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
    }
print(json.dumps(row, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x)))
