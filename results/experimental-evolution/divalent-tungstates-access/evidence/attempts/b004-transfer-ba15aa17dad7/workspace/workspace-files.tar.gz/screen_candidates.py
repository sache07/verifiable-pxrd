from __future__ import annotations

import gzip
import json
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.io.cif import CifParser


INDEX = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(ident: str) -> Path:
    return COD / ident[0] / ident[1:3] / ident[3:5] / f"{ident}.cif"


with gzip.open(INDEX, "rt") as stream:
    index = json.load(stream)

systems = [
    "Ba-O-W",
    "Ba-C-O",
    "O-W",
    "Ba-O",
    "Ba-H-O",
    "H-O-W",
    "C-O-W",
    "Ba-C-H-O",
    "Ba-C-O-W",
]
rows = []
for system in systems:
    for formula, ident, number, quality in index.get(system, []):
        rows.append((system, formula, ident, number, quality))

calc = XRDCalculator(wavelength=1.540598, symprec=0)
for system, formula, ident, number, quality in rows:
    path = cod_path(ident)
    if not path.is_file():
        print("MISSING", path)
        continue
    try:
        structures = CifParser(path, occupancy_tolerance=1.05).parse_structures(primitive=False)
        if len(structures) != 1:
            raise ValueError(f"{len(structures)} structures")
        st = structures[0]
        pattern = calc.get_pattern(st, two_theta_range=(9.8, 100.2), scaled=True)
        peaks = sorted(zip(pattern.y, pattern.x), reverse=True)[:16]
        peak_text = " ".join(f"{angle:.2f}:{intensity:.0f}" for intensity, angle in peaks)
        print(
            f"{ident} {system:10s} idx={formula:16s} parsed={st.composition.reduced_formula:16s} "
            f"SG={st.get_space_group_info()[0]}({st.get_space_group_info()[1]}) "
            f"cell={st.lattice.a:.4f},{st.lattice.b:.4f},{st.lattice.c:.4f},"
            f"{st.lattice.alpha:.2f},{st.lattice.beta:.2f},{st.lattice.gamma:.2f} "
            f"rho={st.density:.3f} peaks={peak_text}"
        )
    except Exception as exc:
        print(f"ERROR {ident} {system} {formula}: {type(exc).__name__}: {exc}")
