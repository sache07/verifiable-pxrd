from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


source = Path(sys.argv[1]).resolve()
base = G2.G2Project(gpxfile=str(source))
hist0 = base.histogram(0)
x = np.asarray(hist0.getdata("X"), float)
profiles = {}
for wanted in [phase.name for phase in base.phases()]:
    project = G2.G2Project(gpxfile=str(source))
    hist = project.histogram(0)
    hist.Background[0][3:] = [0.0] * hist.Background[0][2]
    hist.Background[0][1] = False
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if phase.name != wanted:
            hap["Scale"][0] = 0.0
        hap["Scale"][1] = False
    project.set_Controls("cycles", 0)
    project.refine()
    profiles[wanted] = np.asarray(hist.getdata("Ycalc"), float)

np.savetxt("phase_profiles.csv", np.column_stack([x] + [profiles[k] for k in profiles]), delimiter=",",
           header="two_theta_deg," + ",".join(profiles), comments="")
for target, width in [(17.71,.3),(30.77,.5),(38.89,.3),(40.75,.5),(42.96,.5),(63.02,.6)]:
    sel = abs(x-target) < width
    print(target, {name: round(float(profile[sel].sum()), 1) for name, profile in profiles.items()})
