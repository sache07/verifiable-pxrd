from __future__ import annotations

import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


project = G2.G2Project(gpxfile=str(Path(sys.argv[1]).resolve()))
prefix = sys.argv[2] if len(sys.argv) > 2 else "export"
# Export current full-precision phase state rather than stale covariance values.
project.data["Covariance"]["data"] = {}
for phase in project.phases():
    path = Path(f"{prefix}_{phase.name}.cif")
    phase.export_CIF(str(path))
    print(path)
