from pathlib import Path

from GSASII import GSASIIscriptable as G2


root = Path(__file__).resolve().parent
source = root / "physical_bg_linear.gpx"
project = G2.G2Project(gpxfile=str(source))
project.save(str(root / "final.gpx"))

# Export the exact saved phase state. Dropping covariance only in memory avoids
# an exporter substituting rounded/stale covariance values; final.gpx itself is
# already saved and remains the complete refinement project.
project.data["Covariance"]["data"] = {}
paths = {
    "Ba3W2O9": root / "phase_Ba3W2O9.cif",
    "WO3": root / "phase_WO3.cif",
    "BaCO3": root / "phase_BaCO3.cif",
}
for phase in project.phases():
    phase.export_CIF(str(paths[phase.name]))
    print(paths[phase.name])
