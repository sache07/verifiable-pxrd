from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


source = Path(sys.argv[1]).resolve()
phase_name = sys.argv[2]
axes = [[0, 0, 1], [1, 0, 0], [0, 1, 0]]
G2.SetPrintLevel("warn")
results = []
for axis in axes:
    tag = "".join(map(str, axis))
    output = source.parent / f"trial_ms_{phase_name}_{tag}.gpx"
    project = G2.G2Project(gpxfile=str(source))
    project.save(str(output))
    phase = project.phase(phase_name)
    hist = project.histogram(0)
    hap = phase.data["Histograms"][hist.name]
    current = float(hap["Mustrain"][1][0])
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = current
    hap["Mustrain"][1][1] = current
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    hap["Mustrain"][3] = axis
    project.set_Controls("cycles", 12)
    project.refine()
    project.save()
    row = {
        "axis": axis,
        "project": output.name,
        "wR_percent": hist.get_wR(),
        "mustrain": hap["Mustrain"],
        "mass_fractions": hist.ComputeMassFracs(),
    }
    results.append(row)
    print(json.dumps(row))
Path(f"trial_ms_{phase_name}.json").write_text(json.dumps(results, indent=2) + "\n")
