from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, minimum_filter1d
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCES = [
    ("Ba3W2O9", "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/53/38/1533878.cif", 0.70, 0.10, 1500.0),
    ("WO3", "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif", 0.25, 0.50, 300.0),
    ("BaCO3", "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/01/09/9010928.cif", 0.05, 0.50, 300.0),
]

parser = argparse.ArgumentParser()
parser.add_argument("output", type=Path)
parser.add_argument("--wo3-po", action="store_true")
args = parser.parse_args()
output = args.output.resolve()
output.unlink(missing_ok=True)


def refine(project, label, cycles):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    hist = project.histogram(0)
    print(json.dumps({"stage": label, "wR_percent": hist.get_wR(), "fractions": hist.ComputeMassFracs()}), flush=True)


G2.SetPrintLevel("warn")
project = G2.G2Project(newgpx=str(output))
phases = [project.add_phase(path, phasename=name, fmthint="CIF") for name, path, *_ in SOURCES]
hist = project.add_powder_histogram(str(ROOT / "inputs" / "pattern.csv"), str(ROOT / "instrument.instprm"), phases=phases, fmthint="comma")
hist.SampleParameters["Type"] = "Bragg-Brentano"
hist.SampleParameters["Gonio. radius"] = 200.0
hist.SampleParameters["Scale"] = [1.0, False]
hist.SampleParameters["Shift"] = [0.0, False]
hist.SampleParameters["Transparency"] = [0.0, False]
hist.SampleParameters["SurfRoughA"] = [0.0, False]
hist.SampleParameters["SurfRoughB"] = [0.0, False]

x = np.asarray(hist.getdata("X"), float)
y = np.asarray(hist.getdata("Yobs"), float)
floor = gaussian_filter1d(minimum_filter1d(y, size=401, mode="nearest"), 100)
t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
coeffs = np.polynomial.chebyshev.chebfit(t, floor, 11).tolist()
hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 12, "coeffs": coeffs, "refine": True}})

project.update_ids()
for phase, (_, _, initial_fraction, initial_size, initial_strain) in zip(phases, SOURCES):
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [initial_fraction / phase.data["General"]["Mass"], True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = initial_size
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = initial_strain
    hap["Mustrain"][1][1] = initial_strain
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    for atom in phase.atoms():
        atom.uiso = 0.008
        atom.refinement_flags = " "
    variables = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
    if len(variables) > 1:
        project.add_EquivConstr(variables)

project.save()
refine(project, "scale_background", 8)

for phase in phases:
    phase.set_refinements({"Cell": True})
hist.set_refinements({"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]})
refine(project, "cells_zero_shift", 12)

hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
for phase in phases:
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    })
refine(project, "profile", 16)

ba = project.phase("Ba3W2O9")
ba_hap = ba.data["Histograms"][hist.name]
ba_hap["Pref.Ori."][1] = 1.30
ba_hap["Pref.Ori."][2] = True
ba_hap["Pref.Ori."][3] = [1, 1, 0]
if args.wo3_po:
    wo = project.phase("WO3")
    wo_hap = wo.data["Histograms"][hist.name]
    wo_hap["Pref.Ori."][1] = 1.03
    wo_hap["Pref.Ori."][2] = True
    wo_hap["Pref.Ori."][3] = [1, 0, 0]
refine(project, "preferred_orientation", 12)

for phase in phases:
    phase.set_refinements({"Atoms": {"all": "X"}})
refine(project, "coordinates", 18)

hist.set_refinements({"Instrument Parameters": ["Polariz."]})
for phase in phases:
    phase.set_refinements({"Atoms": {"all": "XU"}})
refine(project, "common_uiso_polarization", 20)
refine(project, "converge", 24)

summary = {
    "output": output.name,
    "wo3_preferred_orientation": args.wo3_po,
    "wR_percent": hist.get_wR(),
    "fractions": hist.ComputeMassFracs(),
    "uiso": {phase.name: [atom.uiso for atom in phase.atoms()] for phase in phases},
    "pref_ori": {phase.name: phase.data["Histograms"][hist.name]["Pref.Ori."] for phase in phases},
}
print(json.dumps(summary, indent=2), flush=True)
