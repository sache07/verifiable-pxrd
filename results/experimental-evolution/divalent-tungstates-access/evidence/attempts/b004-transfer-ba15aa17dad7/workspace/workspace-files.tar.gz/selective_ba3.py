from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


source = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(source))
project.save(str(output))
hist = project.histogram(0)

hist.clear_refinements({"Background": False})
hist.clear_refinements({"Instrument Parameters": ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]})
hist.clear_refinements({"Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
for phase in project.phases():
    phase.clear_refinements({"Cell": True})
    for atom in phase.atoms():
        atom.refinement_flags = " "
    phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
    phase.set_HAP_refinements({"Scale": True})

phase = project.phase("Ba3W2O9")
phase.set_refinements({"Atoms": {"all": "X"}})
phase.set_HAP_refinements({"Pref.Ori.": True})
project.set_Controls("cycles", 30)
project.refine()
project.save()
hap = phase.data["Histograms"][hist.name]
print(json.dumps({
    "wR_percent": hist.get_wR(),
    "fractions": hist.ComputeMassFracs(),
    "pref_ori": hap["Pref.Ori."],
    "atoms": {atom.label: atom.coordinates for atom in phase.atoms()},
}, indent=2))
