import numpy as np
from scipy.optimize import least_squares


x, obs, calc, diff, bkg = np.loadtxt("diagnostic_fit.csv", delimiter=",", skiprows=1).T
t = (x - x[0]) / (x[-1] - x[0])
floor_basis = np.column_stack([(1-t)**2, 2*t*(1-t), t**2])


def solve(family):
    if family == "exponential":
        def model(q):
            return floor_basis @ q[:3] + q[3] * np.exp(-(x-x[0])/np.exp(q[4]))
        q0 = [800, 800, 800, 1500, np.log(10)]
        bounds = ([-5000]*4 + [np.log(1)], [5000]*4 + [np.log(100)])
    else:
        def model(q):
            return floor_basis @ q[:3] + q[3] * (1+(x-x[0])/np.exp(q[4]))**(-np.exp(q[5]))
        q0 = [800, 800, 800, 1500, np.log(10), np.log(2)]
        bounds = ([-5000]*4 + [np.log(1), np.log(.1)], [5000]*4 + [np.log(100), np.log(10)])
    result = least_squares(lambda q: model(q)-bkg, q0, bounds=bounds, max_nfev=10000)
    pred = model(result.x)
    print(family, "rms", np.sqrt(np.mean((pred-bkg)**2)), "max", np.max(abs(pred-bkg)), "params", result.x)


solve("exponential")
solve("power_law")

# Jointly estimate the physically sampled power-law family from the observed
# counts after subtracting the current crystalline signal. Robust and Poisson-
# weighted variants bracket the small bias from imperfect peak intensities.
signal = calc - bkg
target = obs - signal
def physical_model(q):
    return floor_basis @ q[:3] + q[3] * (1+(x-x[0])/q[4])**(-q[5])
q0 = [550, 520, 690, 1900, 12, 1.8]
bounds = ([0, 0, 0, 0, 5, 1], [3500, 3500, 3500, 3500, 20, 3])
for loss in ["linear", "soft_l1"]:
    result = least_squares(lambda q: (physical_model(q)-target)/np.sqrt(np.maximum(obs, 1)),
                           q0, bounds=bounds, loss=loss, f_scale=1, max_nfev=20000)
    pred = physical_model(result.x)
    print("observed_minus_signal", loss, "params", result.x,
          "weighted_rms", np.sqrt(np.mean((pred-target)**2/np.maximum(obs,1))),
          "unweighted_bg_delta", np.sqrt(np.mean((pred-bkg)**2)))

for cutoff in [5, 10, 20, 50, 100]:
    sel = signal < cutoff
    result = least_squares(lambda q: (physical_model(q)[sel]-target[sel])/np.sqrt(np.maximum(obs[sel], 1)),
                           q0, bounds=bounds, loss="soft_l1", f_scale=1, max_nfev=20000)
    print("peak_free", cutoff, "bins", int(sel.sum()), "params", result.x,
          "full_bg_delta", np.sqrt(np.mean((physical_model(result.x)-bkg)**2)))
