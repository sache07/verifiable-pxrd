#!/usr/bin/env python3
"""Compare geometry-clean monoclinic WO3 parents in one fixed multiphase state."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "final.gpx"
OUT = ROOT / "refinement" / "wo3_clean"
COD = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif")
CANDIDATES = ("2311041", "1563541")
AXES = ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (1, 0, -1), (0, 1, 1))


def cod_path(identifier: str) -> Path:
    return COD / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


def active_fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if not hap.get("Use", True):
            continue
        raw[phase.name] = max(0.0, hap["Scale"][0]) * phase.data["General"]["Mass"]
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def describe(project: G2.G2Project, phase_index: int, label: str) -> dict:
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.data["Histograms"][hist.name]
    return {
        "label": label,
        "project": project.filename,
        "Rwp_stored": hist.residuals.get("wR"),
        "Rp_stored": hist.residuals.get("R"),
        "cell": phase.get_cell(),
        "scale": hap["Scale"][0],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "fractions": active_fractions(project),
        "frozen": project.get_Frozen(),
    }


def prepare(identifier: str) -> tuple[G2.G2Project, int]:
    target = OUT / identifier / "01_cell_scale.gpx"
    target.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(target))
    project.set_Frozen()
    project.set_Controls("cycles", 18)
    hist = project.histogram(0)

    old = project.phase(1)
    old_hap = old.data["Histograms"][hist.name]
    old_hap["Scale"] = [0.0, False]
    old_hap["Use"] = False
    old.clear_refinements({"Cell": True})
    old.set_refinements({"Atoms": {"all": " "}})

    phase = project.add_phase(
        str(cod_path(identifier)),
        phasename=f"WO3_clean_{identifier}",
        histograms=[hist],
        fmthint="CIF",
    )
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = 0.003
        atom.refinement_flags = " "
    phase.set_refinements({"Cell": True})
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [15.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.5
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 8000.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."] = ["MD", 1.0, False, [0, 0, 1], 0, {}, [], 0.1]
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
    project.set_Controls("parmMax", 1000.0, variable=f"{phase.id}:0:Scale")
    project.refine()
    project.save()
    return project, phase.id


def texture_branch(identifier: str, phase_id: int, axis: tuple[int, int, int]) -> dict:
    label = "_".join(str(value).replace("-", "m") for value in axis)
    source = OUT / identifier / "01_cell_scale.gpx"
    target = OUT / identifier / f"02_texture_{label}.gpx"
    project = G2.G2Project(gpxfile=str(source), newgpx=str(target))
    project.set_Frozen()
    project.set_Controls("cycles", 18)
    phase = project.phase(phase_id)
    hist = project.histogram(0)
    phase.clear_refinements({"Cell": True})
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."] = ["MD", 1.0, True, list(axis), 0, {}, [], 0.1]
    project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")
    project.refine()
    project.save()
    return describe(project, phase.id, f"texture_{label}")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    rows = []
    for identifier in CANDIDATES:
        project, phase_id = prepare(identifier)
        row = describe(project, phase_id, "cell_scale")
        row["cod_id"] = identifier
        row["textures"] = []
        print(json.dumps(row), flush=True)
        for axis in AXES:
            branch = texture_branch(identifier, phase_id, axis)
            row["textures"].append(branch)
            print(json.dumps({"cod_id": identifier, **branch}), flush=True)
        rows.append(row)
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
