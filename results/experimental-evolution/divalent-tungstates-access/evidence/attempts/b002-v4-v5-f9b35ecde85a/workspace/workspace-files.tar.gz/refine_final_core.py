#!/usr/bin/env python3
"""Continue the accepted physical three-phase model through core specimen terms."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "refinement/restrained_unknown/w1000d010/01_heavy.gpx"
OUT = ROOT / "refinement/final_core"


def limit(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def fractions(project: G2.G2Project) -> list[float]:
    hist = project.histogram(0)
    raw = [
        max(0.0, float(phase.data["Histograms"][hist.name]["Scale"][0]))
        * float(phase.data["General"]["Mass"])
        for phase in project.phases()
    ]
    return [value / sum(raw) for value in raw]


def record(project: G2.G2Project, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, OUT / f"{label}.gpx")
    hist = project.histogram(0)
    row = {
        "stage": label,
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "fractions": fractions(project),
        "instrument": {
            key: value[1] for key, value in hist.InstrumentParameters.items()
            if key in {"Zero", "U", "V", "W", "X", "SH/L", "Polariz."}
        },
        "sample": {
            key: value[0] for key, value in hist.SampleParameters.items()
            if key in {"Shift", "SurfRoughA", "SurfRoughB"}
        },
        "profiles": {
            phase.name: {
                "size": phase.data["Histograms"][hist.name]["Size"][1][0],
                "strain": phase.data["Histograms"][hist.name]["Mustrain"][1][0],
            }
            for phase in project.phases()
        },
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(row))
    with (OUT / "history.jsonl").open("a") as stream:
        stream.write(json.dumps(row) + "\n")


def refine(project: G2.G2Project, label: str) -> None:
    project.refine()
    record(project, label)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    history = OUT / "history.jsonl"
    if history.exists():
        history.unlink()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUT / "working.gpx"))
    hist = project.histogram(0)
    project.set_Frozen()
    project.set_Controls("cycles", 15)

    # Atomic model selected in the preceding geometry-screened checkpoint.
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}, "Cell": True})
    project.data["Restraints"]["data"] = {}

    for variable, low, high in [
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
    ]:
        limit(project, variable, low, high)
    hist.set_refinements({
        "Instrument Parameters": ["U", "W", "X"],
        "Sample Parameters": ["Shift"],
    })
    for phase in project.phases():
        limit(project, f"{phase.id}:0:Size;i", 0.04, 1.50)
        limit(project, f"{phase.id}:0:Mustrain;i", 300.0, 8000.0)
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }, [hist])
    refine(project, "01_profile_cells")

    # Test the whole-specimen low-angle attenuation family.
    project.set_Frozen()
    hist.SampleParameters["SurfRoughA"] = [0.15, True]
    hist.SampleParameters["SurfRoughB"] = [0.10, True]
    limit(project, ":0:SurfRoughA", 0.001, 0.80)
    limit(project, ":0:SurfRoughB", 0.001, 0.80)
    refine(project, "02_surface_roughness")

    # Detector polarization and axial-divergence asymmetry are shared terms.
    project.set_Frozen()
    hist.set_refinements({"Instrument Parameters": ["Polariz.", "SH/L"]})
    refine(project, "03_polarization_axial")


if __name__ == "__main__":
    main()
