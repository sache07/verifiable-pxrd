#!/usr/bin/env python3
"""Build and stage a GSAS-II Rietveld refinement for the specimen pattern.

Run with the GSAS-II Python interpreter. This script intentionally saves a
checkpoint after every refinement stage so that later profile/structure tests
can always return to the last physical model.
"""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
REFERENCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif/1/52/02/1520200.cif"
)


def prepare_inputs(work: Path) -> tuple[Path, Path, np.ndarray, np.ndarray]:
    data = np.loadtxt(PATTERN, delimiter=",", skiprows=1)
    x, y = data.T
    xye = work / "pattern.xye"
    with xye.open("w") as stream:
        stream.write("# pattern\n")
        for xx, yy in zip(x, y):
            stream.write(f"{xx:.8f} {yy:.8f} {math.sqrt(max(yy, 1.0)):.10f}\n")

    inst = work / "instrument.instprm"
    inst.write_text(
        "# GSAS-II initial laboratory Cu Kalpha instrument model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst, x, y


def background_coefficients(x: np.ndarray, y: np.ndarray, degree: int) -> list[float]:
    # A low rolling percentile is a stable initial lower-envelope estimate;
    # all coefficients remain refinable in GSAS-II.
    envelope = percentile_filter(y, percentile=12, size=401, mode="nearest")
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(t, envelope, degree).tolist()


def snapshot(project: G2.G2Project, work: Path, label: str) -> dict:
    project.save()
    target = work / f"checkpoint_{label}.gpx"
    shutil.copy2(project.filename, target)
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.InstrumentParameters
    hap = phase.data["Histograms"][hist.name]
    atoms = []
    for atom in phase.atoms():
        atoms.append(
            {
                "label": atom.label,
                "element": atom.element,
                "xyz": list(map(float, atom.coordinates)),
                "occupancy": float(atom.occupancy),
                "adp_flag": atom.adp_flag,
                "uiso": float(atom.uiso) if atom.adp_flag == "I" else None,
                "refinement_flags": atom.refinement_flags,
            }
        )
    rec = {
        "label": label,
        "checkpoint": str(target),
        "residuals": {
            k: (float(v) if isinstance(v, (int, float, np.number)) else v)
            for k, v in hist.residuals.items()
        },
        "cell": phase.get_cell(),
        "instrument": {
            k: float(v[1])
            for k, v in inst.items()
            if isinstance(v, list) and len(v) >= 2 and isinstance(v[1], (int, float))
        },
        "sample": {
            k: (float(v[0]) if isinstance(v, list) else v)
            for k, v in hist.SampleParameters.items()
            if k in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"}
        },
        "hap": {
            "Scale": float(hap["Scale"][0]),
            "Size": hap["Size"],
            "Mustrain": hap["Mustrain"],
            "Pref.Ori.": hap["Pref.Ori."],
        },
        "atoms": atoms,
        "background": hist.Background,
    }
    print(json.dumps(rec, indent=2, default=lambda o: o.tolist() if hasattr(o, "tolist") else str(o)))
    return rec


def refine_stage(project: G2.G2Project, work: Path, label: str, history: list[dict]) -> None:
    project.refine()
    history.append(snapshot(project, work, label))
    (work / "history.json").write_text(json.dumps(history, indent=2, default=lambda o: o.tolist() if hasattr(o, "tolist") else str(o)) + "\n")


def build(work: Path) -> None:
    work.mkdir(parents=True, exist_ok=True)
    xye, instfile, x, y = prepare_inputs(work)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(work / "one_phase.gpx"))
    phase = project.add_phase(str(REFERENCE), phasename="MnWO4_wolframite", fmthint="CIF")
    hist = project.add_powder_histogram(
        str(xye), str(instfile), phases=[phase], fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    coeffs = background_coefficients(x, y, degree=12)
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(coeffs),
                "coeffs": coeffs,
                "refine": True,
            },
        }
    )
    phase.set_HAP_refinements({"Scale": True}, [hist])
    # Start with broad but physical specimen terms; they are introduced only
    # after the instrument and cell have stabilized.
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 300.0
    hap["Mustrain"][2] = [False, False, False]

    project.set_Controls("cycles", 12)
    history: list[dict] = []

    refine_stage(project, work, "01_scale_background", history)

    phase.set_refinements({"Cell": True})
    refine_stage(project, work, "02_cell", history)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_stage(project, work, "03_zero", history)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine_stage(project, work, "04_shift", history)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine_stage(project, work, "05_instrument_profile", history)

    phase.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}, [hist]
    )
    refine_stage(project, work, "06_size", history)

    phase.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
    )
    refine_stage(project, work, "07_mustrain", history)

    # Heavy-atom coordinates first; positions on special sites are constrained
    # automatically by the imported P2/c symmetry.
    phase.set_refinements({"Atoms": {"Mn1": "X", "W1": "X"}})
    refine_stage(project, work, "08_heavy_coordinates", history)

    phase.set_refinements({"Atoms": {"O1": "X", "O2": "X"}})
    refine_stage(project, work, "09_oxygen_coordinates", history)

    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--work", type=Path, default=ROOT / "refinement" / "one_phase")
    args = parser.parse_args()
    build(args.work.resolve())


if __name__ == "__main__":
    main()
