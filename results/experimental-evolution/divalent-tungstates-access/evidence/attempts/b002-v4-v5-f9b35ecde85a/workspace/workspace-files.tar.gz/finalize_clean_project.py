#!/usr/bin/env python3
"""Remove the superseded disabled phase and finish the physical four-phase GPX."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "refinement/wo3_clean/2311041/heavy_bounds/d0p003.gpx"
OUT = ROOT / "refinement/final_clean"
OLD = "WO3_P21c"
SOURCE = "WO3_clean_2311041"
FINAL = "WO3_gamma_P21c"


def clean_tree() -> Path:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / "01_clean.gpx"
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(target))
    hist = project.histogram(0)
    phases = project.data["Phases"]
    clean = phases.pop(SOURCE)
    phases.pop(OLD)
    clean["General"]["Name"] = FINAL
    project.data["Phases"] = {
        "data": phases["data"],
        "MnWO4_wolframite": phases["MnWO4_wolframite"],
        FINAL: clean,
        "Mn2WO6_P212121": phases["Mn2WO6_P212121"],
        "MnO_rocksalt": phases["MnO_rocksalt"],
    }
    for index, names in enumerate(project.names):
        if names and names[0] == "Phases":
            project.names[index] = [
                "Phases", "MnWO4_wolframite", FINAL,
                "Mn2WO6_P212121", "MnO_rocksalt",
            ]
            break
    reflections = hist.data["Reflection Lists"]
    reflections.pop(OLD, None)
    reflections[FINAL] = reflections.pop(SOURCE)
    project.data["Restraints"]["data"] = {}
    project.data["Constraints"]["data"] = {"Hist": [], "HAP": [], "Phase": [], "Global": []}
    project.set_Frozen()
    project.save()
    return target


def finish(source: Path) -> dict:
    target = OUT / "02_scale_background.gpx"
    project = G2.G2Project(gpxfile=str(source), newgpx=str(target))
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    hist = project.histogram(0)
    hist.Background[0][1] = True
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "Polariz.", "SH/L"],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
    })
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    project.refine()
    project.save()
    return {
        "project": project.filename,
        "Rwp_stored": hist.residuals.get("wR"),
        "Rp_stored": hist.residuals.get("R"),
        "frozen": project.get_Frozen(),
        "phase_names": [phase.name for phase in project.phases()],
        "phase_ids": [phase.id for phase in project.phases()],
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }


def main() -> None:
    G2.SetPrintLevel("warn")
    source = clean_tree()
    print(json.dumps(finish(source), indent=2))


if __name__ == "__main__":
    main()
