#!/usr/bin/env python3
"""Screen one bounded March-Dollase family at a time on the physical model."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "refinement/specimen_fixed/01_roughness.gpx"
OUT = ROOT / "refinement/texture_screen"
AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    rows = []
    for phase_index in range(3):
        for axis in AXES:
            label = f"p{phase_index}_{axis[0]}{axis[1]}{axis[2]}"
            output = OUT / f"{label}.gpx"
            project = G2.G2Project(gpxfile=str(BASE), newgpx=str(output))
            project.set_Frozen()
            project.set_Controls("cycles", 15)
            hist = project.histogram(0)
            for phase in project.phases():
                phase.set_refinements({"Atoms": {"all": " "}})
                phase.clear_refinements({"Cell": True})
                phase.clear_HAP_refinements({
                    "Size": True, "Mustrain": True, "Pref.Ori.": True
                }, [hist])
            project.data["Restraints"]["data"] = {}
            hist.clear_refinements({
                "Instrument Parameters": ["Zero", "U", "W", "X", "Polariz.", "SH/L"],
                "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
            })
            phase = project.phase(phase_index)
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(axis)
            project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")
            try:
                project.refine()
                error = None
            except Exception as exc:
                error = repr(exc)
            project.save()
            row = {
                "label": label,
                "phase": phase.name,
                "axis": axis,
                "MD": hap["Pref.Ori."][1],
                "Rwp_stored": hist.residuals.get("wR"),
                "error": error,
                "frozen": project.get_Frozen(),
            }
            rows.append(row)
            print(json.dumps(row), flush=True)
    (OUT / "stored_results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
