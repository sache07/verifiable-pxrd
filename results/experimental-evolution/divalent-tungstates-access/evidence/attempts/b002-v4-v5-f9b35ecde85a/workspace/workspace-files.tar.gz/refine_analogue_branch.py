#!/usr/bin/env python3
"""Comparable staged GSAS-II refinement for a custom analogue phase."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def phase_fractions(project: G2.G2Project) -> list[dict]:
    hist = project.histogram(0)
    rows, weighted = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        scale = max(0.0, float(hap["Scale"][0]))
        mass = float(phase.data["General"]["Mass"])
        weighted.append(scale * mass)
        rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell_mass": mass,
                "cell": phase.get_cell(),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    total = sum(weighted)
    for row, value in zip(rows, weighted):
        row["weight_fraction"] = value / total if total else 0.0
    return rows


def stage(project: G2.G2Project, out: Path, label: str, history: list[dict]) -> None:
    before = float(project.histogram(0).residuals.get("wR", np.inf))
    error = None
    try:
        project.refine()
    except Exception as exc:
        error = repr(exc)
    hist = project.histogram(0)
    rec = {
        "stage": label,
        "wR_before": before,
        "wR": float(hist.residuals.get("wR", np.inf)),
        "R": float(hist.residuals.get("R", np.inf)),
        "error": error,
        "fractions": phase_fractions(project),
        "instrument": {
            k: float(v[1])
            for k, v in hist.InstrumentParameters.items()
            if k in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."}
        },
        "sample": {
            k: float(v[0])
            for k, v in hist.SampleParameters.items()
            if k in {"Shift", "SurfRoughA", "SurfRoughB"}
        },
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }
    history.append(rec)
    project.save(str(out / f"checkpoint_{label}.gpx"))
    (out / "history.json").write_text(json.dumps(history, indent=2, default=str) + "\n")
    print(json.dumps(rec, indent=2, default=str))


def set_limit(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--cif", type=Path, required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--profile", action="store_true")
    parser.add_argument("--initial-scale", type=float, default=2.0)
    args = parser.parse_args()

    args.output.mkdir(parents=True, exist_ok=True)
    output_gpx = args.output / "branch.gpx"
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()), newgpx=str(output_gpx.resolve())
    )
    hist = project.histogram(0)
    # Reconsider bounded variables in each independent branch, while retaining
    # the common physical limits from the accepted checkpoint.
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    phase = project.add_phase(
        str(args.cif.resolve()),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [float(args.initial_scale), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.20
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    project.set_Controls("cycles", 10)

    for variable, low, high in [
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
        (f"{phase.id}:0:Scale", 0.0, 1000.0),
    ]:
        set_limit(project, variable, low, high)

    history: list[dict] = []
    stage(project, args.output, "01_scale", history)

    phase.set_refinements({"Cell": True})
    stage(project, args.output, "02_cell", history)

    heavy = {
        atom.label: "X"
        for atom in phase.atoms()
        if atom.element not in {"O", "H", "C", "N", "F"}
    }
    if heavy:
        phase.set_refinements({"Atoms": heavy})
        stage(project, args.output, "03_heavy", history)

    oxygen = {atom.label: "X" for atom in phase.atoms() if atom.element == "O"}
    if oxygen:
        phase.set_refinements({"Atoms": oxygen})
        stage(project, args.output, "04_oxygen", history)

    if args.profile:
        # Profile relaxation is staged identically for each serious branch.
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
        stage(project, args.output, "05_instrument_profile", history)

        for item in project.phases():
            set_limit(project, f"{item.id}:0:Size;i", 0.04, 1.50)
            item.set_HAP_refinements(
                {"Size": {"type": "isotropic", "refine": True}}, [hist]
            )
        stage(project, args.output, "06_sizes", history)

        for item in project.phases():
            set_limit(project, f"{item.id}:0:Mustrain;i", 0.0, 8000.0)
            item.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
            )
        stage(project, args.output, "07_mustrain", history)

    project.save(str(output_gpx))
    for item in project.phases():
        item.export_CIF(str(args.output / f"{item.name}.cif"))
    shutil.copy2(output_gpx, args.output / "final_branch.gpx")


if __name__ == "__main__":
    main()
