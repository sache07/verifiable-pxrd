#!/usr/bin/env python3
"""Add one reference phase to a common GSAS-II checkpoint and refine it."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def fractions(project: G2.G2Project) -> list[dict]:
    hist = project.histogram(0)
    rows = []
    masses = []
    for phase in project.phases():
        scale = float(phase.data["Histograms"][hist.name]["Scale"][0])
        cell_mass = float(phase.data["General"]["Mass"])
        masses.append(max(0.0, scale * cell_mass))
        rows.append(
            {
                "name": phase.name,
                "scale": scale,
                "cell_mass": cell_mass,
                "cell": phase.get_cell(),
            }
        )
    total = sum(masses)
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = mass / total if total else 0.0
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--cod-id", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--coordinates", action="store_true")
    parser.add_argument("--initial-scale", type=float, default=10.0)
    parser.add_argument("--fixed-cell", action="store_true")
    args = parser.parse_args()

    args.output.mkdir(parents=True, exist_ok=True)
    outgpx = args.output / "branch.gpx"
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.base.resolve()), newgpx=str(outgpx.resolve()))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cod_path(args.cod_id)),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [args.initial_scale, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 300.0
    hap["Mustrain"][2] = [False, False, False]
    if not args.fixed_cell:
        phase.set_refinements({"Cell": True})

    project.set_Controls("cycles", 12)
    for var, low, high in [
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
    ]:
        project.set_Controls("parmMin", low, variable=var)
        project.set_Controls("parmMax", high, variable=var)

    project.refine()
    stages = [
        {
            "stage": "scale_cell",
            "wR": float(project.histogram(0).residuals["wR"]),
            "R": float(project.histogram(0).residuals["R"]),
            "fractions": fractions(project),
        }
    ]
    project.save(str(args.output / "checkpoint_scale_cell.gpx"))

    if args.coordinates:
        heavy = {
            atom.label: "X"
            for atom in phase.atoms()
            if atom.element not in {"O", "H", "C", "N", "F"}
        }
        if heavy:
            phase.set_refinements({"Atoms": heavy})
            project.refine()
            stages.append(
                {
                    "stage": "heavy_coordinates",
                    "wR": float(project.histogram(0).residuals["wR"]),
                    "R": float(project.histogram(0).residuals["R"]),
                    "fractions": fractions(project),
                }
            )
            project.save(str(args.output / "checkpoint_heavy.gpx"))
        light = {atom.label: "X" for atom in phase.atoms() if atom.element == "O"}
        if light:
            phase.set_refinements({"Atoms": light})
            project.refine()
            stages.append(
                {
                    "stage": "oxygen_coordinates",
                    "wR": float(project.histogram(0).residuals["wR"]),
                    "R": float(project.histogram(0).residuals["R"]),
                    "fractions": fractions(project),
                }
            )
            project.save(str(args.output / "checkpoint_oxygen.gpx"))

    project.save(str(outgpx))
    result = {
        "cod_id": args.cod_id,
        "name": args.name,
        "space_group": phase.data["General"]["SGData"]["SpGrp"],
        "composition": phase.composition,
        "stages": stages,
        "instrument": {
            k: float(v[1])
            for k, v in hist.InstrumentParameters.items()
            if k in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."}
        },
        "sample": {
            k: float(v[0])
            for k, v in hist.SampleParameters.items()
            if k in {"Shift", "SurfRoughA", "SurfRoughB"}
        },
    }
    (args.output / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
