#!/usr/bin/env python3
"""Freshly replay selected GPX checkpoints and report profile statistics."""

from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
WORKER = ROOT / "learned/divalent-tungstates/scorer/runtime/replay_worker.py"
OBSERVED = ROOT / "inputs/pattern.csv"
PROJECTS = {
    "physical_parent": ROOT / "refinement/physical/mn2wo6_p212121/checkpoint_05_strain_test.gpx",
    "restrained_heavy": ROOT / "refinement/restrained_unknown/w1000d010/01_heavy.gpx",
    "fixed_roughness": ROOT / "refinement/specimen_fixed/01_roughness.gpx",
    "fixed_polar_axial": ROOT / "refinement/specimen_fixed/02_polarization_axial.gpx",
    "core_profile": ROOT / "refinement/final_core/01_profile_cells.gpx",
    "core_roughness": ROOT / "refinement/final_core/02_surface_roughness.gpx",
    "core_polar_axial": ROOT / "refinement/final_core/03_polarization_axial.gpx",
    "texture_wo3_001": ROOT / "refinement/texture_screen/p1_001.gpx",
    "texture_wo3_110": ROOT / "refinement/texture_screen/p1_110.gpx",
    "texture_mn2wo6_001": ROOT / "refinement/texture_screen/p2_001.gpx",
    "texture_mn2wo6_100": ROOT / "refinement/texture_screen/p2_100.gpx",
    "texture_second_mnwo4_100": ROOT / "refinement/texture_second/p0_100.gpx",
    "texture_second_wo3_001": ROOT / "refinement/texture_second/p1_001.gpx",
    "texture_second_wo3_110": ROOT / "refinement/texture_second/p1_110.gpx",
    "coord_mnwo4_heavy": ROOT / "refinement/known_coordinates/phase_0/01_heavy.gpx",
    "coord_mnwo4_all": ROOT / "refinement/known_coordinates/phase_0/02_all.gpx",
    "coord_wo3_heavy": ROOT / "refinement/known_coordinates/phase_1/01_heavy.gpx",
    "coord_wo3_all": ROOT / "refinement/known_coordinates/phase_1/02_all.gpx",
    "coord_combined_wo3_heavy": ROOT / "refinement/combined_coordinates/01_wo3_heavy.gpx",
    "coord_combined_wo3_all": ROOT / "refinement/combined_coordinates/02_wo3_all.gpx",
    "selected_uiso": ROOT / "refinement/selected_uiso/01_selected_uiso.gpx",
    "strain_wo3_001": ROOT / "refinement/strain_screen/p1_001.gpx",
    "strain_mn2wo6_001": ROOT / "refinement/strain_screen/p2_001.gpx",
    "strain_mn2wo6_100": ROOT / "refinement/strain_screen/p2_100.gpx",
    "strain_mn2wo6_010": ROOT / "refinement/strain_screen/p2_010.gpx",
    "oxygen_mn2wo6_d003": ROOT / "refinement/unknown_oxygen/d0p003.gpx",
    "oxygen_mn2wo6_d005": ROOT / "refinement/unknown_oxygen/d0p005.gpx",
    "closure_mno": ROOT / "refinement/closure_mnoxides/1514108.gpx",
    "closure_mn2o3": ROOT / "refinement/closure_mnoxides/1514230.gpx",
    "closure_mn3o4": ROOT / "refinement/closure_mnoxides/9001963.gpx",
    "mno_size_004": ROOT / "refinement/mno_size/s0p04.gpx",
    "mno_size_008": ROOT / "refinement/mno_size/s0p08.gpx",
    "mno_size_012": ROOT / "refinement/mno_size/s0p12.gpx",
    "mno_size_020": ROOT / "refinement/mno_size/s0p20.gpx",
    "mno_cell_registered": ROOT / "refinement/mno_cell/a4p41000.gpx",
    "mno_cell_bound": ROOT / "refinement/mno_cell/a4p43205.gpx",
    "mno_cell_free": ROOT / "refinement/mno_cell/a4p45400.gpx",
}


spec = importlib.util.spec_from_file_location("replay_worker", WORKER)
module = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(module)

original = Path.cwd()
rows = []
for name, project in PROJECTS.items():
    output = ROOT / "refinement/replays" / name
    output.mkdir(parents=True, exist_ok=True)
    os.chdir(output)
    try:
        report = module.replay({"project": str(project), "observed": str(OBSERVED)})
        arrays = np.load("prediction.npz")
        observed = arrays["observed"]
        calculated = arrays["predicted"]
        weights = 1.0 / np.maximum(observed, 1.0)
        rwp = 100.0 * np.sqrt(
            np.sum(weights * (observed - calculated) ** 2)
            / np.sum(weights * observed**2)
        )
        rp = 100.0 * np.sum(np.abs(observed - calculated)) / np.sum(observed)
        row = {
            "name": name,
            "project": str(project.relative_to(ROOT)),
            "Rwp_fresh": float(rwp),
            "Rp_fresh": float(rp),
            "fractions": [p["weight_fraction"] for p in report["phases"]],
            "flags": report["profile_review_flags"],
        }
    except Exception as exc:
        row = {"name": name, "project": str(project), "error": repr(exc)}
    rows.append(row)
    print(json.dumps(row))
    os.chdir(original)

(ROOT / "refinement/replays/summary.json").write_text(json.dumps(rows, indent=2) + "\n")
