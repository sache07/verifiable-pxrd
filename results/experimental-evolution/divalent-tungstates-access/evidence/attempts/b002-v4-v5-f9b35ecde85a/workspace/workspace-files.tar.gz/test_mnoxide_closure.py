#!/usr/bin/env python3
"""Stable-scale closure tests for exact Mn-oxide precursor/intermediates."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif")
BASE = ROOT / "refinement/strain_screen/p2_100.gpx"
OUT = ROOT / "refinement/closure_mnoxides"
CANDIDATES = [
    ("1514108", "MnO_rocksalt"),
    ("1514230", "Mn2O3_bixbyite"),
    ("9001963", "Mn3O4_spinel"),
]


def cod_path(identifier: str) -> Path:
    return COD / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


def fractions(project: G2.G2Project) -> list[float]:
    hist = project.histogram(0)
    raw = [max(0.0, p.data["Histograms"][hist.name]["Scale"][0]) * p.data["General"]["Mass"] for p in project.phases()]
    return [x / sum(raw) for x in raw]


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    rows = []
    for identifier, name in CANDIDATES:
        project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUT / f"{identifier}.gpx"))
        project.set_Frozen()
        project.set_Controls("cycles", 18)
        hist = project.histogram(0)
        for old in project.phases():
            old.set_refinements({"Atoms": {"all": " "}})
            old.clear_refinements({"Cell": True})
            old.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        project.data["Restraints"]["data"] = {}
        project.data["Constraints"]["data"] = {"Hist": [], "HAP": [], "Phase": [], "Global": []}
        hist.clear_refinements({
            "Instrument Parameters": ["Zero", "U", "W", "X", "Polariz.", "SH/L"],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        })
        phase = project.add_phase(str(cod_path(identifier)), phasename=name, histograms=[hist], fmthint="CIF")
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = 0.005
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.20
        hap["Size"][2] = [False, False, False]
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
        project.refine()
        first = {"Rwp": hist.residuals.get("wR"), "scale": hap["Scale"][0], "fractions": fractions(project)}

        project.set_Frozen()
        project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 1.50, variable=f"{phase.id}:0:Size;i")
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
        project.refine()
        project.save()
        row = {
            "cod_id": identifier, "name": name, "scale_cell": first,
            "Rwp_stored": hist.residuals.get("wR"), "scale": hap["Scale"][0],
            "size_um": hap["Size"][1][0], "fractions": fractions(project),
            "frozen": project.get_Frozen(),
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
