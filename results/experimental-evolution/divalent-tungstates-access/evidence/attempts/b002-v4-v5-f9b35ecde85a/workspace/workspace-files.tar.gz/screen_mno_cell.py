#!/usr/bin/env python3
"""Compare the weak MnO cell at the registered value and +0.5% bound."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "refinement/mno_size/s0p08.gpx"
OUT = ROOT / "refinement/mno_cell"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    for lattice in (4.4100, 4.43205, 4.453995853857268):
        label = f"a{lattice:.5f}".replace(".", "p")
        project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUT / f"{label}.gpx"))
        project.set_Frozen()
        project.set_Controls("cycles", 15)
        hist = project.histogram(0)
        for phase in project.phases():
            phase.set_refinements({"Atoms": {"all": " "}})
            phase.clear_refinements({"Cell": True})
            phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        project.data["Restraints"]["data"] = {}
        project.data["Constraints"]["data"] = {"Hist": [], "HAP": [], "Phase": [], "Global": []}
        hist.clear_refinements({
            "Instrument Parameters": ["Zero", "U", "W", "X", "Polariz.", "SH/L"],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        })
        phase = project.phase(3)
        phase.data["General"]["Cell"] = [False, lattice, lattice, lattice, 90.0, 90.0, 90.0, lattice**3]
        project.refine()
        project.save()
        raw = [p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"] for p in project.phases()]
        print(json.dumps({
            "label": label, "a": lattice, "Rwp_stored": hist.residuals.get("wR"),
            "fractions": [x/sum(raw) for x in raw],
        }), flush=True)


if __name__ == "__main__":
    main()
