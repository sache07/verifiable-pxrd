#!/usr/bin/env python3
"""Refine shared specimen terms with the accepted profile and structure fixed."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "refinement/restrained_unknown/w1000d010/01_heavy.gpx"
OUT = ROOT / "refinement/specimen_fixed"


def limit(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def report(project, label):
    project.save()
    shutil.copy2(project.filename, OUT / f"{label}.gpx")
    hist = project.histogram(0)
    raw = [max(0.0, p.data["Histograms"][hist.name]["Scale"][0]) * p.data["General"]["Mass"] for p in project.phases()]
    print(json.dumps({
        "stage": label, "Rwp": hist.residuals.get("wR"),
        "fractions": [x/sum(raw) for x in raw],
        "sample": {k: v[0] for k,v in hist.SampleParameters.items() if k in {"Shift","SurfRoughA","SurfRoughB"}},
        "instrument": {k: v[1] for k,v in hist.InstrumentParameters.items() if k in {"Zero","Polariz.","SH/L","U","W","X"}},
        "frozen": project.get_Frozen(),
    }))


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUT / "working.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 20)
    hist = project.histogram(0)
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})
        phase.clear_refinements({"Cell": True})
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": False},
            "Mustrain": {"type": "isotropic", "refine": False},
        }, [hist])
    project.data["Restraints"]["data"] = {}
    hist.clear_refinements({
        "Instrument Parameters": ["Zero","U","W","X","Polariz.","SH/L"],
        "Sample Parameters": ["Shift","SurfRoughA","SurfRoughB"],
    })

    hist.SampleParameters["SurfRoughA"] = [0.15, True]
    hist.SampleParameters["SurfRoughB"] = [0.10, True]
    limit(project, ":0:SurfRoughA", 0.001, 0.80)
    limit(project, ":0:SurfRoughB", 0.001, 0.80)
    project.refine()
    report(project, "01_roughness")

    project.set_Frozen()
    hist.set_refinements({"Instrument Parameters": ["Polariz.", "SH/L"]})
    limit(project, ":0:Polariz.", 0.5, 1.0)
    limit(project, ":0:SH/L", 0.005, 0.10)
    project.refine()
    report(project, "02_polarization_axial")


if __name__ == "__main__":
    main()
