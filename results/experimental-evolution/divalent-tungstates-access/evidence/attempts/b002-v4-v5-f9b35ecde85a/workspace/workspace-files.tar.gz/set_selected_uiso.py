#!/usr/bin/env python3
"""Apply the selected physical common-Uiso values and refit scales/background."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "refinement/combined_coordinates/02_wo3_all.gpx"
OUT = ROOT / "refinement/selected_uiso"
VALUES = (0.003, 0.003, 0.020)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUT / "working.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 20)
    hist = project.histogram(0)
    for phase, value in zip(project.phases(), VALUES):
        phase.set_refinements({"Atoms": {"all": " "}})
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = value
    project.data["Restraints"]["data"] = {}
    project.data["Constraints"]["data"] = {"Hist": [], "HAP": [], "Phase": [], "Global": []}
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "W", "X", "Polariz.", "SH/L"],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
    })
    project.refine()
    project.save()
    shutil.copy2(project.filename, OUT / "01_selected_uiso.gpx")
    raw = [p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"] for p in project.phases()]
    print(json.dumps({
        "Rwp_stored": hist.residuals.get("wR"),
        "fractions": [x / sum(raw) for x in raw],
        "Uiso": {p.name: p.atoms()[0].uiso for p in project.phases()},
    }))


if __name__ == "__main__":
    main()
