#!/usr/bin/env python3
"""Test a second texture family after accepting Mn2WO6 [001] texture."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "refinement/texture_screen/p2_001.gpx"
OUT = ROOT / "refinement/texture_second"
AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    rows = []
    for phase_index in (0, 1):
        for axis in AXES:
            label = f"p{phase_index}_{axis[0]}{axis[1]}{axis[2]}"
            project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUT / f"{label}.gpx"))
            project.set_Frozen()
            project.set_Controls("cycles", 15)
            hist = project.histogram(0)
            for phase in project.phases():
                phase.set_refinements({"Atoms": {"all": " "}})
                phase.clear_refinements({"Cell": True})
                phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
            project.data["Restraints"]["data"] = {}
            hist.clear_refinements({
                "Instrument Parameters": ["Zero", "U", "W", "X", "Polariz.", "SH/L"],
                "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
            })
            phase = project.phase(phase_index)
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][:4] = ["MD", 1.0, True, list(axis)]
            project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")
            project.refine()
            project.save()
            row = {
                "label": label, "phase": phase.name, "axis": axis,
                "MD": hap["Pref.Ori."][1], "Rwp_stored": hist.residuals.get("wR"),
                "fractions": [p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"] for p in project.phases()],
            }
            rows.append(row)
            print(json.dumps(row), flush=True)
    (OUT / "stored_results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
