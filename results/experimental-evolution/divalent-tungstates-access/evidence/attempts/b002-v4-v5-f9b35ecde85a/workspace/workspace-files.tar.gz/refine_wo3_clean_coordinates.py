#!/usr/bin/env python3
"""Tightly bounded heavy-then-light coordinate test for clean ambient WO3."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "refinement/wo3_clean/2311041/02_texture_1_0_m1.gpx"
OUT = ROOT / "refinement/wo3_clean/2311041/coordinates"


def snapshot(project: G2.G2Project, name: str) -> None:
    project.save()
    shutil.copy2(project.filename, OUT / f"{name}.gpx")
    hist = project.histogram(0)
    phase = project.phase(4)
    print(json.dumps({
        "stage": name,
        "Rwp_stored": hist.residuals.get("wR"),
        "Rp_stored": hist.residuals.get("R"),
        "cell": phase.get_cell(),
        "frozen": project.get_Frozen(),
        "atoms": [
            {"label": atom.label, "element": atom.element, "xyz": list(atom.coordinates)}
            for atom in phase.atoms()
        ],
    }), flush=True)


def limits(project: G2.G2Project, phase, elements: set[str], delta: float) -> None:
    project.index_ids()
    for index, atom in enumerate(phase.atoms()):
        if atom.element not in elements:
            continue
        for axis, value in zip(("x", "y", "z"), atom.coordinates):
            variable = f"{phase.id}::dA{axis}:{index}"
            project.set_Controls("parmMin", value - delta, variable=variable)
            project.set_Controls("parmMax", value + delta, variable=variable)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUT / "working.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    hist = project.histogram(0)
    project.data["Restraints"]["data"] = {}
    project.data["Constraints"]["data"] = {"Hist": [], "HAP": [], "Phase": [], "Global": []}
    for candidate in project.phases():
        candidate.set_refinements({"Atoms": {"all": " "}})
        candidate.clear_refinements({"Cell": True})
        candidate.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])

    phase = project.phase(4)
    limits(project, phase, {"W"}, 0.002)
    phase.set_refinements({"Atoms": {atom.label: "X" for atom in phase.atoms() if atom.element == "W"}})
    project.refine()
    snapshot(project, "01_heavy")

    project.set_Frozen()
    limits(project, phase, {"O"}, 0.003)
    phase.set_refinements({"Atoms": {atom.label: "X" for atom in phase.atoms() if atom.element == "O"}})
    project.refine()
    snapshot(project, "02_all")


if __name__ == "__main__":
    main()
