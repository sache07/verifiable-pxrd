#!/usr/bin/env python3
"""Convert a P21/n analogue to the conventional P21/c setting GSAS-II accepts."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


source = Path("refinement/analogues/mn3wo6_p21c_ranked.cif")
target = Path("refinement/analogues/mn3wo6_p21c_ranked_gsas.cif")
structure = Structure.from_file(source)
standard = SpacegroupAnalyzer(structure, symprec=1e-3).get_conventional_standard_structure()
CifWriter(standard, symprec=1e-3, refine_struct=False).write_file(target)
print(target)
print(standard.composition.reduced_formula, standard.get_space_group_info(symprec=1e-3))
print(standard.lattice)
