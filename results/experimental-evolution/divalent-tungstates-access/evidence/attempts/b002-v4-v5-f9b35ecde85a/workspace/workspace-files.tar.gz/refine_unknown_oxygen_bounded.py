#!/usr/bin/env python3
"""Two tightly bounded, bond-restrained oxygen tests for accepted Mn2WO6."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "refinement/strain_screen/p2_100.gpx"
OUT = ROOT / "refinement/unknown_oxygen"


def run(delta: float) -> None:
    label = f"d{delta:.3f}".replace(".", "p")
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUT / f"{label}.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    hist = project.histogram(0)
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
    project.data["Restraints"]["data"] = {}
    project.data["Constraints"]["data"] = {"Hist": [], "HAP": [], "Phase": [], "Global": []}
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "W", "X", "Polariz.", "SH/L"],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
    })

    phase = project.phase(2)
    atoms = phase.atoms()
    oxygen = [a for a in atoms if a.element == "O"]
    manganese = [a for a in atoms if a.element == "Mn"]
    tungsten = [a for a in atoms if a.element == "W"]
    project.data["Restraints"]["data"][phase.name] = {
        "Bond": {"wtFactor": 1000.0, "Range": 1.2, "Bonds": [], "Use": True}
    }
    phase.addDistRestraint(tungsten, oxygen, 1.87, factor=1.20, ESD=0.05)
    phase.addDistRestraint(manganese, oxygen, 2.23, factor=1.16, ESD=0.07)
    project.index_ids()
    for index, atom in enumerate(atoms):
        if atom.element != "O":
            continue
        for axis, value in zip(("x", "y", "z"), atom.coordinates):
            variable = f"{phase.id}::dA{axis}:{index}"
            project.set_Controls("parmMin", value - delta, variable=variable)
            project.set_Controls("parmMax", value + delta, variable=variable)
    phase.set_refinements({"Atoms": {a.label: "X" for a in oxygen}})
    project.refine()
    project.save()
    phase.export_CIF(str(OUT / f"{label}.cif"))
    print(json.dumps({
        "label": label, "Rwp_stored": hist.residuals.get("wR"),
        "frozen": project.get_Frozen(),
    }), flush=True)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    for delta in (0.003, 0.005):
        run(delta)


if __name__ == "__main__":
    main()
