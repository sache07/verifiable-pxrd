#!/usr/bin/env python3
"""Combine the geometry-valid bounded coordinate refinements sequentially."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "refinement/known_coordinates/phase_0/02_all.gpx"
OUT = ROOT / "refinement/combined_coordinates"


def snapshot(project: G2.G2Project, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, OUT / f"{label}.gpx")
    hist = project.histogram(0)
    print(json.dumps({"stage": label, "Rwp_stored": hist.residuals.get("wR"), "frozen": project.get_Frozen()}), flush=True)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUT / "working.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 20)
    hist = project.histogram(0)
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
    project.data["Restraints"]["data"] = {}
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "W", "X", "Polariz.", "SH/L"],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
    })

    phase = project.phase(1)
    project.index_ids()
    for index, atom in enumerate(phase.atoms()):
        for axis, value in zip(("x", "y", "z"), atom.coordinates):
            variable = f"{phase.id}::dA{axis}:{index}"
            project.set_Controls("parmMin", value - 0.004, variable=variable)
            project.set_Controls("parmMax", value + 0.004, variable=variable)

    phase.set_refinements({"Atoms": {a.label: "X" for a in phase.atoms() if a.element != "O"}})
    project.refine()
    snapshot(project, "01_wo3_heavy")

    project.set_Frozen()
    phase.set_refinements({"Atoms": {a.label: "X" for a in phase.atoms() if a.element == "O"}})
    project.refine()
    snapshot(project, "02_wo3_all")


if __name__ == "__main__":
    main()
