#!/usr/bin/env python3
"""Rank a small analogue set against the unassigned residual family."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
ANALOGUES = ROOT / "refinement" / "analogues"
PROFILE = ROOT / "refinement" / "screens" / "wo3_1528915" / "profile.npz"


def scaled_structure(structure: Structure, linear_scale: float) -> Structure:
    return Structure(
        Lattice(structure.lattice.matrix * linear_scale),
        [site.species for site in structure],
        structure.frac_coords,
        site_properties=structure.site_properties,
    )


def reference_sticks(structure: Structure, x: np.ndarray) -> list[tuple[float, float, float]]:
    sticks = []
    for wavelength, ratio in [(1.540598, 1.0), (1.544426, 0.5)]:
        pattern = XRDCalculator(wavelength=wavelength).get_pattern(
            structure, two_theta_range=(5.0, min(170.0, float(x[-1]) + 15.0)), scaled=False
        )
        for position, intensity in zip(pattern.x, pattern.y):
            d = wavelength / (2.0 * np.sin(np.deg2rad(position / 2.0)))
            sticks.append((wavelength, d, ratio * intensity))
    return sticks


def stick_profile(sticks: list[tuple[float, float, float]], linear_scale: float, x: np.ndarray, fwhm: float) -> np.ndarray:
    sigma = fwhm / (2.0 * np.sqrt(2.0 * np.log(2.0)))
    out = np.zeros_like(x)
    for wavelength, d, intensity in sticks:
        arg = wavelength / (2.0 * linear_scale * d)
        if intensity <= 0 or arg >= 1:
            continue
        position = 2.0 * np.rad2deg(np.arcsin(arg))
        if position < x[0] - 2.0 or position > x[-1] + 2.0:
            continue
        lo = np.searchsorted(x, position - 4.5 * sigma)
        hi = np.searchsorted(x, position + 4.5 * sigma)
        if hi <= lo:
            continue
        z = (x[lo:hi] - position) / sigma
        out[lo:hi] += intensity * np.exp(-0.5 * z * z)
    norm = np.sqrt(np.dot(out, out))
    return out / norm if norm else out


def main() -> None:
    with np.load(PROFILE) as profile:
        x, observed, current = (profile[k].copy() for k in ("x", "yo", "yc"))
    weight = 1.0 / np.maximum(observed, 1.0)
    residual = observed - current
    denominator = float(np.sum(weight * observed * observed))
    base_loss = float(np.sum(weight * residual * residual))
    rows = []
    for record in json.loads((ANALOGUES / "catalog.json").read_text()):
        structure = Structure.from_file(record["cif"])
        sticks = reference_sticks(structure, x)
        best = None
        for scale in np.linspace(0.88, 1.12, 97):
            for fwhm in [0.12, 0.18, 0.25, 0.35, 0.50, 0.70]:
                basis = stick_profile(sticks, float(scale), x, fwhm)
                denom = float(np.sum(weight * basis * basis))
                amplitude = max(0.0, float(np.sum(weight * basis * residual)) / denom) if denom else 0.0
                loss = float(np.sum(weight * (residual - amplitude * basis) ** 2))
                trial = (loss, float(scale), float(fwhm), amplitude)
                if best is None or trial < best:
                    best = trial
        loss, scale, fwhm, amplitude = best
        scaled = scaled_structure(structure, scale)
        scaled_path = ANALOGUES / f"{record['name']}_ranked.cif"
        CifWriter(scaled, symprec=1e-3, refine_struct=False).write_file(scaled_path)
        rows.append(
            {
                **record,
                "ranked_cif": str(scaled_path),
                "linear_cell_scale": scale,
                "screen_fwhm_deg": fwhm,
                "screen_amplitude": amplitude,
                "screen_rwp_percent": 100.0 * np.sqrt(loss / denominator),
                "delta_chi_square": base_loss - loss,
                "base_rwp_percent": 100.0 * np.sqrt(base_loss / denominator),
            }
        )
    rows.sort(key=lambda row: row["screen_rwp_percent"])
    (ANALOGUES / "ranking.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
