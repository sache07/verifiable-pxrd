#!/usr/bin/env python3
"""Test restrained coordinate relaxation for the weak P212121 Mn2WO6 phase."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fractions(project: G2.G2Project) -> list[float]:
    hist = project.histogram(0)
    raw = [
        max(0.0, float(phase.data["Histograms"][hist.name]["Scale"][0]))
        * float(phase.data["General"]["Mass"])
        for phase in project.phases()
    ]
    return [value / sum(raw) for value in raw]


def save(project: G2.G2Project, out: Path, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, out / f"{label}.gpx")
    project.phase(2).export_CIF(str(out / f"{label}.cif"))
    hist = project.histogram(0)
    print(json.dumps({
        "stage": label,
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "fractions": fractions(project),
        "frozen": project.get_Frozen(),
    }))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--weight", type=float, required=True)
    parser.add_argument("--delta", type=float, default=0.025)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    working = args.output / "working.gpx"
    project = G2.G2Project(gpxfile=str(args.base.resolve()), newgpx=str(working.resolve()))
    project.set_Frozen()
    project.set_Controls("cycles", 20)
    phase = project.phase(2)
    atoms = phase.atoms()
    oxygen = [atom for atom in atoms if atom.element == "O"]
    manganese = [atom for atom in atoms if atom.element == "Mn"]
    tungsten = [atom for atom in atoms if atom.element == "W"]

    # Preserve octahedral chemistry while allowing enough motion to alter the
    # problematic low-angle structure factors.
    project.data["Restraints"]["data"][phase.name] = {
        "Bond": {"wtFactor": args.weight, "Range": 1.2, "Bonds": [], "Use": True}
    }
    n_w = phase.addDistRestraint(tungsten, oxygen, 1.87, factor=1.15, ESD=0.04)
    n_mn = phase.addDistRestraint(manganese, oxygen, 2.23, factor=1.16, ESD=0.06)
    print(json.dumps({"W-O_restraints": n_w, "Mn-O_restraints": n_mn}))

    # Keep already-established peak positions and widths fixed during the
    # coordinate test; scales and background remain active.
    for item in project.phases():
        item.clear_refinements({"Cell": True})
        item.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": False},
            "Mustrain": {"type": "isotropic", "refine": False},
        }, [project.histogram(0)])
    project.histogram(0).clear_refinements({
        "Instrument Parameters": ["U", "W", "X"],
        "Sample Parameters": ["Shift"],
    })

    project.index_ids()
    for i, atom in enumerate(atoms):
        for axis, value in zip(("x", "y", "z"), atom.coordinates):
            variable = f"{phase.id}::dA{axis}:{i}"
            # Coordinate refinements are represented as dA variables, but GSAS-II
            # applies their limits to the resulting absolute fractional coordinate.
            project.set_Controls("parmMin", value - args.delta, variable=variable)
            project.set_Controls("parmMax", value + args.delta, variable=variable)

    phase.set_refinements({
        "Atoms": {atom.label: "X" for atom in tungsten + manganese}
    })
    project.refine()
    save(project, args.output, "01_heavy")

    phase.set_refinements({"Atoms": {atom.label: "X" for atom in oxygen}})
    project.set_Frozen()
    project.refine()
    save(project, args.output, "02_all_atoms")


if __name__ == "__main__":
    main()
