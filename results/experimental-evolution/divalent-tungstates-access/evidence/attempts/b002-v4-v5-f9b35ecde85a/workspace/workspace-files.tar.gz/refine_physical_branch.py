#!/usr/bin/env python3
"""Refine a three-phase branch while keeping all atomic coordinates physical."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def set_limit(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def fractions(project: G2.G2Project) -> list[float]:
    hist = project.histogram(0)
    weights = [
        max(0.0, float(phase.data["Histograms"][hist.name]["Scale"][0]))
        * float(phase.data["General"]["Mass"])
        for phase in project.phases()
    ]
    total = sum(weights)
    return [value / total for value in weights]


def snapshot(project: G2.G2Project, out: Path, label: str, history: list[dict]) -> None:
    hist = project.histogram(0)
    rec = {
        "stage": label,
        "Rwp": float(hist.residuals.get("wR", np.inf)),
        "Rp": float(hist.residuals.get("R", np.inf)),
        "fractions": fractions(project),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "sizes_um": {
            phase.name: float(phase.data["Histograms"][hist.name]["Size"][1][0])
            for phase in project.phases()
        },
        "strains_ppm": {
            phase.name: float(phase.data["Histograms"][hist.name]["Mustrain"][1][0])
            for phase in project.phases()
        },
        "instrument": {
            key: float(value[1])
            for key, value in hist.InstrumentParameters.items()
            if key in {"Zero", "U", "V", "W", "X", "SH/L", "Polariz."}
        },
        "sample": {
            key: float(value[0])
            for key, value in hist.SampleParameters.items()
            if key in {"Shift", "SurfRoughA", "SurfRoughB"}
        },
        "frozen": [
            str(value)
            for value in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])
        ],
    }
    history.append(rec)
    project.save()
    shutil.copy2(project.filename, out / f"checkpoint_{label}.gpx")
    (out / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    print(json.dumps(rec))


def refine(project: G2.G2Project, out: Path, label: str, history: list[dict]) -> None:
    before = float(project.histogram(0).residuals.get("wR", np.inf))
    try:
        project.refine()
    except Exception as exc:
        print(f"{label}: {exc!r}")
    after = float(project.histogram(0).residuals.get("wR", np.inf))
    if after > before + 0.02:
        print(f"warning: {label} increased Rwp from {before:.5f} to {after:.5f}")
    snapshot(project, out, label, history)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--cif", type=Path, required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--initial-scale", type=float, default=2.0)
    args = parser.parse_args()

    args.output.mkdir(parents=True, exist_ok=True)
    working = args.output / "working.gpx"
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.base.resolve()), newgpx=str(working.resolve()))
    hist = project.histogram(0)
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    project.set_Controls("cycles", 12)
    phase = project.add_phase(
        str(args.cif.resolve()), phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [float(args.initial_scale), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.20
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False, False, False]

    for variable, low, high in [
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
        (f"{phase.id}:0:Scale", 0.0, 1000.0),
    ]:
        set_limit(project, variable, low, high)

    # Coordinates and ADPs are intentionally fixed for topology comparison.
    for item in project.phases():
        item.set_refinements({"Atoms": {"all": " "}})

    history: list[dict] = []
    refine(project, args.output, "01_scale", history)
    phase.set_refinements({"Cell": True})
    refine(project, args.output, "02_cell", history)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(project, args.output, "03_instrument", history)

    for item in project.phases():
        set_limit(project, f"{item.id}:0:Size;i", 0.04, 1.50)
        item.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    refine(project, args.output, "04_size", history)

    # Save the size-only state before testing the optional strain family.
    shutil.copy2(project.filename, args.output / "best_size_only.gpx")
    for item in project.phases():
        set_limit(project, f"{item.id}:0:Mustrain;i", 300.0, 8000.0)
        item.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    refine(project, args.output, "05_strain_test", history)


if __name__ == "__main__":
    main()
