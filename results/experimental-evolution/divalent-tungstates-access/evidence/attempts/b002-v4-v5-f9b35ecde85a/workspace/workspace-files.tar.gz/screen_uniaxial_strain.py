#!/usr/bin/env python3
"""Screen one supported uniaxial microstrain family at a time."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "refinement/selected_uiso/01_selected_uiso.gpx"
OUT = ROOT / "refinement/strain_screen"
AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0)]


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    rows = []
    for phase_index in range(3):
        for axis in AXES:
            label = f"p{phase_index}_{axis[0]}{axis[1]}{axis[2]}"
            project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUT / f"{label}.gpx"))
            project.set_Frozen()
            project.set_Controls("cycles", 18)
            hist = project.histogram(0)
            for phase in project.phases():
                phase.set_refinements({"Atoms": {"all": " "}})
                phase.clear_refinements({"Cell": True})
                phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
            project.data["Restraints"]["data"] = {}
            project.data["Constraints"]["data"] = {"Hist": [], "HAP": [], "Phase": [], "Global": []}
            hist.clear_refinements({
                "Instrument Parameters": ["Zero", "U", "W", "X", "Polariz.", "SH/L"],
                "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
            })
            phase = project.phase(phase_index)
            hap = phase.data["Histograms"][hist.name]
            start = float(hap["Mustrain"][1][0])
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1][0] = start
            hap["Mustrain"][1][1] = start
            hap["Mustrain"][2][0] = True
            hap["Mustrain"][2][1] = True
            hap["Mustrain"][3] = list(axis)
            for suffix in ("i", "a"):
                project.set_Controls("parmMin", 300.0, variable=f"{phase.id}:0:Mustrain;{suffix}")
                project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;{suffix}")
            project.refine()
            project.save()
            row = {
                "label": label, "phase": phase.name, "axis": axis,
                "equatorial": hap["Mustrain"][1][0], "axial": hap["Mustrain"][1][1],
                "Rwp_stored": hist.residuals.get("wR"), "frozen": project.get_Frozen(),
            }
            rows.append(row)
            print(json.dumps(row), flush=True)
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
