#!/usr/bin/env python3
"""Normalize and refine one physically constrained isotropic Uiso per phase."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "refinement/combined_coordinates/02_wo3_all.gpx"
OUT = ROOT / "refinement/common_uiso"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUT / "working.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    hist = project.histogram(0)
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
    project.data["Restraints"]["data"] = {}
    project.data["Constraints"]["data"] = {"Hist": [], "HAP": [], "Phase": [], "Global": []}
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "W", "X", "Polariz.", "SH/L"],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
    })

    project.index_ids()
    for phase in project.phases():
        variables = []
        for index, atom in enumerate(phase.atoms()):
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = 0.005
            atom.refinement_flags = "U"
            variable = f"{phase.id}::AUiso:{index}"
            variables.append(variable)
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)

    project.refine()
    project.save()
    shutil.copy2(project.filename, OUT / "01_common_uiso.gpx")
    row = {
        "Rwp_stored": hist.residuals.get("wR"),
        "Uiso": {phase.name: [atom.uiso for atom in phase.atoms()] for phase in project.phases()},
        "frozen": project.get_Frozen(),
        "vary": project.get_VaryList(),
    }
    print(json.dumps(row))


if __name__ == "__main__":
    main()
