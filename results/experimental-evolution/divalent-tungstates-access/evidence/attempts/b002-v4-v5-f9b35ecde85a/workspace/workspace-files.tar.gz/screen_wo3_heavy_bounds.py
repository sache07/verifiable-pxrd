#!/usr/bin/env python3
"""Compare small physical W-coordinate bounds and finish with scale/background only."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "refinement/wo3_clean/2311041/02_texture_1_0_m1.gpx"
OUT = ROOT / "refinement/wo3_clean/2311041/heavy_bounds"


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if hap.get("Use", True):
            raw[phase.name] = max(0.0, hap["Scale"][0]) * phase.data["General"]["Mass"]
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def run(delta: float) -> dict:
    label = f"d{delta:.3f}".replace(".", "p")
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUT / f"{label}.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    hist = project.histogram(0)
    project.data["Restraints"]["data"] = {}
    project.data["Constraints"]["data"] = {"Hist": [], "HAP": [], "Phase": [], "Global": []}
    for candidate in project.phases():
        candidate.set_refinements({"Atoms": {"all": " "}})
        candidate.clear_refinements({"Cell": True})
        candidate.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
    phase = project.phase(4)
    project.index_ids()
    start = {}
    for index, atom in enumerate(phase.atoms()):
        if atom.element != "W":
            continue
        start[atom.label] = list(atom.coordinates)
        for axis, value in zip(("x", "y", "z"), atom.coordinates):
            variable = f"{phase.id}::dA{axis}:{index}"
            project.set_Controls("parmMin", value - delta, variable=variable)
            project.set_Controls("parmMax", value + delta, variable=variable)
    phase.set_refinements({"Atoms": {atom.label: "X" for atom in phase.atoms() if atom.element == "W"}})
    project.refine()
    coordinate_rwp = hist.residuals.get("wR")
    coordinate_frozen = project.get_Frozen()
    coordinates = {atom.label: list(atom.coordinates) for atom in phase.atoms() if atom.element == "W"}

    # Commit the bounded coordinates and finish from a replayable state with
    # only phase scales and the polynomial background active.
    phase.set_refinements({"Atoms": {"all": " "}})
    project.set_Frozen()
    project.refine()
    project.save()
    phase.export_CIF(str(OUT / f"{label}.cif"))
    return {
        "label": label,
        "delta_fractional": delta,
        "coordinate_Rwp_stored": coordinate_rwp,
        "coordinate_frozen": coordinate_frozen,
        "final_Rwp_stored": hist.residuals.get("wR"),
        "final_Rp_stored": hist.residuals.get("R"),
        "final_frozen": project.get_Frozen(),
        "start": start,
        "coordinates": coordinates,
        "fractions": fractions(project),
        "project": project.filename,
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    rows = []
    for delta in (0.001, 0.002, 0.003):
        row = run(delta)
        rows.append(row)
        print(json.dumps(row), flush=True)
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
