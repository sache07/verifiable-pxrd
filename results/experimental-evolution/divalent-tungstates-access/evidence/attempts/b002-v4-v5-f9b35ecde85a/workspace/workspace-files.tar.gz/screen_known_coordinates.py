#!/usr/bin/env python3
"""Bounded heavy/light coordinate tests for the two reference-backed phases."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "refinement/texture_second/p1_001.gpx"
OUT = ROOT / "refinement/known_coordinates"


def prepare(project: G2.G2Project) -> None:
    project.set_Frozen()
    project.set_Controls("cycles", 20)
    hist = project.histogram(0)
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
    project.data["Restraints"]["data"] = {}
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "W", "X", "Polariz.", "SH/L"],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
    })


def apply_limits(project: G2.G2Project, phase, delta: float) -> None:
    project.index_ids()
    for index, atom in enumerate(phase.atoms()):
        for axis, value in zip(("x", "y", "z"), atom.coordinates):
            variable = f"{phase.id}::dA{axis}:{index}"
            project.set_Controls("parmMin", value - delta, variable=variable)
            project.set_Controls("parmMax", value + delta, variable=variable)


def save(project: G2.G2Project, path: Path, stage: str) -> None:
    project.save()
    hist = project.histogram(0)
    row = {
        "stage": stage, "Rwp_stored": hist.residuals.get("wR"),
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(row), flush=True)


def branch(phase_index: int, delta: float) -> None:
    directory = OUT / f"phase_{phase_index}"
    directory.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(directory / "working.gpx"))
    prepare(project)
    phase = project.phase(phase_index)
    apply_limits(project, phase, delta)
    heavy = {a.label: "X" for a in phase.atoms() if a.element != "O"}
    phase.set_refinements({"Atoms": heavy})
    project.refine()
    project.save(str(directory / "01_heavy.gpx"))
    save(project, directory / "01_heavy.gpx", f"p{phase_index}_heavy")

    project.set_Frozen()
    oxygen = {a.label: "X" for a in phase.atoms() if a.element == "O"}
    phase.set_refinements({"Atoms": oxygen})
    project.refine()
    project.save(str(directory / "02_all.gpx"))
    save(project, directory / "02_all.gpx", f"p{phase_index}_all")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    branch(0, 0.006)
    branch(1, 0.004)


if __name__ == "__main__":
    main()
