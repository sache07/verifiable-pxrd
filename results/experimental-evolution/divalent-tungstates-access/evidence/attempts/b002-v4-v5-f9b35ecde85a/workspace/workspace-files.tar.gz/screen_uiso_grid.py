#!/usr/bin/env python3
"""Grid-screen common per-phase Uiso values without unstable ADP constraints."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "refinement/combined_coordinates/02_wo3_all.gpx"
OUT = ROOT / "refinement/uiso_grid"
VALUES = (0.003, 0.005, 0.008, 0.012, 0.016, 0.020)


def prepare(project: G2.G2Project) -> None:
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = 0.005
    project.data["Restraints"]["data"] = {}
    project.data["Constraints"]["data"] = {"Hist": [], "HAP": [], "Phase": [], "Global": []}
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "W", "X", "Polariz.", "SH/L"],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
    })


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    rows = []
    for phase_index in range(3):
        for value in VALUES:
            label = f"p{phase_index}_{value:.3f}".replace(".", "p")
            project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUT / f"{label}.gpx"))
            prepare(project)
            for atom in project.phase(phase_index).atoms():
                atom.data[atom.cia + 1] = value
            project.refine()
            project.save()
            row = {
                "label": label, "phase": project.phase(phase_index).name,
                "Uiso": value, "Rwp_stored": project.histogram(0).residuals.get("wR"),
            }
            rows.append(row)
            print(json.dumps(row), flush=True)
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
