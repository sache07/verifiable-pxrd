#!/usr/bin/env python3
"""Stabilize the weak MnO scale with a fixed crystallite-size grid."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "refinement/strain_screen/p2_100.gpx"
SOURCE = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif/1/51/41/1514108.cif")
OUT = ROOT / "refinement/mno_size"
SIZES = (0.04, 0.08, 0.12, 0.20, 0.40, 0.80, 1.50)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    rows = []
    for size in SIZES:
        label = f"s{size:.2f}".replace(".", "p")
        project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUT / f"{label}.gpx"))
        project.set_Frozen()
        project.set_Controls("cycles", 18)
        hist = project.histogram(0)
        for old in project.phases():
            old.set_refinements({"Atoms": {"all": " "}})
            old.clear_refinements({"Cell": True})
            old.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        project.data["Restraints"]["data"] = {}
        project.data["Constraints"]["data"] = {"Hist": [], "HAP": [], "Phase": [], "Global": []}
        hist.clear_refinements({
            "Instrument Parameters": ["Zero", "U", "W", "X", "Polariz.", "SH/L"],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        })
        phase = project.add_phase(str(SOURCE), phasename="MnO_rocksalt", histograms=[hist], fmthint="CIF")
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = 0.005
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][2] = [False, False, False]
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
        project.refine()
        project.save()
        raw = [p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"] for p in project.phases()]
        row = {
            "label": label, "size_um": size, "Rwp_stored": hist.residuals.get("wR"),
            "mno_cell": phase.get_cell(), "fractions": [x / sum(raw) for x in raw],
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
