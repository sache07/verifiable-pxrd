#!/usr/bin/env python3
"""Assemble the replay-verified final PXRD submission artifacts."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / "refinement/final_clean/replay"

report = json.loads((REPLAY / "replay.json").read_text())
if report.get("status") != "replayed":
    raise RuntimeError(f"Final project did not replay: {report}")

with np.load(REPLAY / "prediction.npz") as arrays:
    x = arrays["x"].copy()
    observed = arrays["observed"].copy()
    calculated = arrays["predicted"].copy()

difference = observed - calculated
weights = 1.0 / np.maximum(observed, 1.0)
weighted_ss = float(np.sum(weights * difference**2))
denominator = float(np.sum(weights * observed**2))
rwp = float(100.0 * np.sqrt(weighted_ss / denominator))
rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
rexp = float(100.0 * np.sqrt(len(observed) / denominator))

np.savetxt(
    ROOT / "fit.csv",
    np.column_stack([x, observed, calculated, difference]),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference",
    comments="",
    fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
)

fractions = [float(phase["weight_fraction"]) for phase in report["phases"]]
if not np.isclose(sum(fractions), 1.0, atol=1e-12):
    raise RuntimeError("Final crystalline fractions are not normalized")
expected_names = ["MnWO4_wolframite", "WO3_gamma_P21c", "Mn2WO6_P212121", "MnO_rocksalt"]
if [phase["name"] for phase in report["phases"]] != expected_names:
    raise RuntimeError("Unexpected phase order in the final replay")

phase_rows = [
    {
        "name": "MnWO4 wolframite",
        "formula": "MnWO4",
        "space_group": "P 2/c",
        "cif_path": "MnWO4.cif",
        "weight_fraction": fractions[0],
        "weight_percent": 100.0 * fractions[0],
        "identification_confidence": "high",
    },
    {
        "name": "monoclinic WO3",
        "formula": "WO3",
        "space_group": "P 21/c",
        "cif_path": "WO3.cif",
        "weight_fraction": fractions[1],
        "weight_percent": 100.0 * fractions[1],
        "identification_confidence": "high",
    },
    {
        "name": "Mn2WO6, Y2WO6-type model",
        "formula": "Mn2WO6",
        "space_group": "P 21 21 21",
        "cif_path": "Mn2WO6.cif",
        "weight_fraction": fractions[2],
        "weight_percent": 100.0 * fractions[2],
        "identification_confidence": "moderate",
    },
    {
        "name": "MnO rocksalt",
        "formula": "MnO",
        "space_group": "F m -3 m",
        "cif_path": "MnO.cif",
        "weight_fraction": fractions[3],
        "weight_percent": 100.0 * fractions[3],
        "identification_confidence": "low",
    },
]

result = {
    "schema_version": 1,
    "refinement_histogram": report["histogram"],
    "fraction_basis": "normalized over the modeled crystalline phases; no amorphous fraction determined",
    "phases": phase_rows,
    "fit_statistics": {
        "Rwp_percent": rwp,
        "Rp_percent": rp,
        "Rexp_percent": rexp,
        "goodness_of_fit": rwp / rexp,
        "weighted_sum_of_squares": weighted_ss,
        "n_points": int(len(observed)),
        "weighting": "1/max(observed_counts,1)",
        "grid": "entire original observed grid",
        "calculated_profile": "fresh GSAS-II atomic replay including fitted background",
    },
    "calibration": {
        "zero_offset_deg": 0.25,
        "sample_displacement_um": 519.4130071632827,
    },
    "project": "final.gpx",
    "project_sha256": report["project_sha256"],
}
(ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

text = f"""# Powder XRD phase analysis

## Result

| Phase | Space group | Crystalline wt.% |
|---|---:|---:|
| MnWO4, wolframite | P 2/c | {100*fractions[0]:.2f} |
| WO3, monoclinic | P 21/c | {100*fractions[1]:.2f} |
| Mn2WO6, Y2WO6-type model | P 21 21 21 | {100*fractions[2]:.2f} |
| MnO, rocksalt | F m -3 m | {100*fractions[3]:.2f} |

Fractions are normalized over the four modeled crystalline phases; amorphous material was not quantified. The full-grid fresh GSAS-II replay gives Rwp = {rwp:.3f}%, Rp = {rp:.3f}%, and Rexp = {rexp:.3f}% ({len(observed)} points).

## Evidence

MnWO4 matches the dominant line set and refines as the expected P 2/c wolframite. The other strong family requires ambient monoclinic gamma-WO3. A geometry-clean P 21/c neutron model (COD 2311041) fits better than the initially screened historical model and passes the contact screen; triclinic, orthorhombic, tetragonal, hexagonal, and high-pressure monoclinic alternatives were poorer. The WO3 cell was refined, followed by a bounded W-only coordinate adjustment of about 0.03 A; the neutron oxygen framework was retained because oxygen refinement worsened the fit and ran to its bounds.

After those phases, coherent peaks at approximately 19.90, 20.37, 28.63, 34.82, 35.61, 45.90, 53.85, and 56.67 degrees index to the P 21 21 21 Y2WO6 topology after Y-to-Mn transfer. Competing Mn2WO6 Pbcn/trirutile/P4/nmm/P2/c and Mn3WO6 P21/c/Pa-3/P1 branches were compared in the same multiphase state and were poorer or failed geometry screening. The submitted Mn2WO6 model has no sub-1.5-A contacts; representative Mn-O and W-O ranges are about 2.10-2.38 and 1.68-2.01 A. Weak residuals near the MnO 111/220/311/222 positions support a small rocksalt MnO contribution; Mn2O3 and Mn3O4 closure tests were poorer. All coherent residual families are assigned by the four accepted phases.

## Remaining uncertainty

The Mn2WO6 assignment uses a substituted Y2WO6 prototype because the frozen reference index has no exact-composition Mn2WO6 structure. Its topology is supported by a coherent set of peak positions and by the 1:1 precursor metal balance, but its detailed Mn/O coordinates cannot be determined reliably from this pattern. Relative intensities remain imperfect, so its {100*fractions[2]:.2f} wt.% fraction is model-dependent; uncertainty of several wt.% is plausible. Unconstrained coordinate fits were rejected for impossible bond geometry.

MnO is a weak, profile-sensitive phase. Constrained size/cell trials placed it at roughly 0.6-1.4 wt.%; the submitted {100*fractions[3]:.2f} wt.% value is tentative and cannot be determined reliably to better than about 0.4 wt.%. Its cell was held at the +0.5% registered-reference mismatch bound. The modeled crystalline inventory gives an approximate Mn:W molar ratio of 0.90 rather than the nominal precursor ratio of 1.00, reinforcing systematic uncertainty in the transferred-phase scale factors. The zero offset also reached its allowed +0.25-degree bound, and Rwp remains well above the counting-statistics Rexp, so the numerical fractions should not be read as accuracy implied by their printed digits. No amorphous fraction was determined.
"""
(ROOT / "report.md").write_text(text)

print(json.dumps({
    "Rwp_percent": rwp,
    "Rp_percent": rp,
    "fractions": fractions,
    "points": len(observed),
}, indent=2))
