#!/usr/bin/env python3
"""Create explicitly provenance-tracked Mn/W/O analogue CIFs for screening."""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.core import Element, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
COD_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)
OUT = ROOT / "refinement" / "analogues"


MODELS = [
    # Mn2WO6 candidates: one chemically nearest parent per distinct topology.
    ("mn2wo6_trirutile", "1530909", "Cr"),       # P42/mnm, Cr(III)
    ("mn2wo6_pbcn", "2310464", "Fe"),            # Pbcn, Fe(III)
    ("mn2wo6_p212121", "1541070", "Y"),          # P212121
    ("mn2wo6_p4nmm", "1563285", "Y"),            # P4/nmm
    ("mn2wo6_p2c", "7712111", "Lu"),             # P2/c
    # Mn3WO6 candidates from divalent-A3WO6 parents.
    ("mn3wo6_pa3", "1527404", "Cu"),             # Pa-3
    ("mn3wo6_p21c", "1563081", "Ca"),            # P21/c
    ("mn3wo6_p1", "1534803", "Ba"),              # P-1
]


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    catalog = []
    for name, cod_id, replaced in MODELS:
        parent = cod_path(cod_id)
        structure = Structure.from_file(parent)
        parent_formula = structure.composition.reduced_formula
        substitutions = {
            specie: Element("Mn")
            for specie in structure.composition
            if getattr(specie, "symbol", str(specie)) == replaced
        }
        structure.replace_species(substitutions)
        target_formula = structure.composition.reduced_formula
        target = OUT / f"{name}.cif"
        CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(target)
        reloaded = Structure.from_file(target)
        row = {
            "name": name,
            "cif": str(target),
            "parent_cod_id": cod_id,
            "parent_cif": str(parent),
            "parent_formula": parent_formula,
            "target_formula": target_formula,
            "transformation": f"element substitution {replaced}->Mn; parent lattice and fractional coordinates retained",
            "space_group": reloaded.get_space_group_info(symprec=1e-3)[0],
            "cell": list(reloaded.lattice.abc) + list(reloaded.lattice.angles),
            "sites": len(reloaded),
        }
        catalog.append(row)
        (OUT / f"{name}.json").write_text(json.dumps(row, indent=2) + "\n")
    (OUT / "catalog.json").write_text(json.dumps(catalog, indent=2) + "\n")
    print(json.dumps(catalog, indent=2))


if __name__ == "__main__":
    main()
