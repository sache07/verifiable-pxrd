#!/usr/bin/env python3
"""Stable scale-first check for the corrected high-pressure WO3 CIF import."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "refinement/wo3_clean/1563541_fixed"
SOURCE = ROOT / "refinement/wo3_clean/1563541_fixed.cif"


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if hap.get("Use", True):
            raw[phase.name] = max(0.0, hap["Scale"][0]) * phase.data["General"]["Mass"]
    total = sum(raw.values())
    return {key: value / total for key, value in raw.items()}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(ROOT / "final.gpx"), newgpx=str(OUT / "01_scale.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 18)
    hist = project.histogram(0)
    old = project.phase(1)
    old.data["Histograms"][hist.name]["Use"] = False
    old.data["Histograms"][hist.name]["Scale"] = [0.0, False]
    phase = project.add_phase(str(SOURCE), phasename="WO3_HP_1563541", histograms=[hist], fmthint="CIF")
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = 0.003
        atom.refinement_flags = " "
    phase.clear_refinements({"Cell": True})
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [15.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.5
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 8000.0
    hap["Mustrain"][2] = [False, False, False]
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
    project.set_Controls("parmMax", 1000.0, variable=f"{phase.id}:0:Scale")
    # Establish the candidate scale against the accepted fixed state before
    # restoring the correlated background and all-phase scale relaxation.
    hist.Background[0][1] = False
    for accepted in (project.phase(0), project.phase(2), project.phase(3)):
        accepted.data["Histograms"][hist.name]["Scale"][1] = False
    project.refine()
    stage_one = {
        "Rwp_stored": hist.residuals.get("wR"),
        "scale": hap["Scale"][0],
        "fractions": fractions(project),
    }
    project.set_Frozen()
    hist.Background[0][1] = True
    for accepted in (project.phase(0), project.phase(2), project.phase(3)):
        accepted.data["Histograms"][hist.name]["Scale"][1] = True
    project.refine()
    project.save()
    print(json.dumps({
        "scale_only_stage": stage_one,
        "Rwp_stored": hist.residuals.get("wR"),
        "Rp_stored": hist.residuals.get("R"),
        "scale": hap["Scale"][0],
        "cell": phase.get_cell(),
        "fractions": fractions(project),
    }, indent=2))


if __name__ == "__main__":
    main()
