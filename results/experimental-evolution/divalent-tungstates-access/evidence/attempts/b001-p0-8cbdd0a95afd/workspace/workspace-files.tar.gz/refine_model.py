#!/usr/bin/env python3
"""Build and progressively refine a two-phase GSAS-II Rietveld project."""

from pathlib import Path
import json
import math
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
WORK = ROOT / "refinement"
GPX = WORK / "trial.gpx"
WO3 = ROOT / "models" / "WO3_parent.cif"
ZNO = ROOT / "models" / "ZnO_parent.cif"


def make_inputs():
    WORK.mkdir(parents=True, exist_ok=True)
    data = np.loadtxt(PATTERN, delimiter=",", skiprows=1)
    np.savetxt(WORK / "pattern.xye", data, fmt="%.8f %.8f")
    (WORK / "instrument.instprm").write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def describe(project, label):
    hist = project.histograms()[0]
    print(f"\n--- {label} ---")
    print("residuals", json.dumps(hist.residuals, default=float, sort_keys=True))
    print("instrument", {
        k: v for k, v in hist.InstrumentParameters.items()
        if k in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}
    })
    print("sample", hist.SampleParameters)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(
            phase.name,
            "cell", [round(float(v), 8) for v in phase.data["General"]["Cell"][1:]],
            "scale", hap["Scale"],
            "size", hap["Size"],
            "mustrain", hap["Mustrain"],
            "pref", hap["Pref.Ori."],
        )
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass fractions unavailable", repr(exc))


def run_stage(project, label):
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    describe(project, label)
    project.save(WORK / f"{label}.gpx")


def main():
    make_inputs()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(GPX))
    hist = project.add_powder_histogram(
        str(WORK / "pattern.xye"),
        str(WORK / "instrument.instprm"),
        fmthint="xye",
    )
    wo3 = project.add_phase(str(WO3), phasename="WO3_monoclinic", histograms=[hist], fmthint="CIF")
    zno = project.add_phase(str(ZNO), phasename="ZnO_wurtzite", histograms=[hist], fmthint="CIF")

    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    # Start near the mass-ratio scale convention to avoid the first cycle being ill-conditioned.
    wo3.data["Histograms"][hist.name]["Scale"] = [0.25, False]
    zno.data["Histograms"][hist.name]["Scale"] = [1.0, False]
    hist.set_refinements({
        "Limits": [10.0, 100.05],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 12,
            "coeffs": [800.0] + [0.0] * 11,
            "refine": True,
        },
    })
    project.save()
    # First solve only linear-like intensity terms.
    wo3.set_HAP_refinements({"Scale": True})
    zno.set_HAP_refinements({"Scale": True})
    run_stage(project, "stage1_scale_background")

    # Peak locations: common zero and each crystal metric.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    wo3.set_refinements({"Cell": True})
    zno.set_refinements({"Cell": True})
    run_stage(project, "stage2_cells_zero")

    # Instrumental width and asymmetry.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run_stage(project, "stage3_instrument")

    # Phase-specific broadening.
    for phase in (wo3, zno):
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 0.5, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    run_stage(project, "stage4_phase_profiles")

    # Separate the specimen-displacement angular trend from common zero.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_stage(project, "stage5_displacement")

    # Atomic parameters are introduced only after the peak/profile model is stable.
    for phase in (wo3, zno):
        phase.set_refinements({"Atoms": {"all": "XU"}})
    run_stage(project, "stage6_atoms")

    project.save(GPX)
    describe(project, "final trial")


if __name__ == "__main__":
    main()
