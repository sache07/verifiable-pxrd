#!/usr/bin/env python3
"""Summarize and plot the independently replayed GSAS-II profile."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks


ROOT = Path(__file__).resolve().parent
with np.load(ROOT / "refinement" / "prediction.npz") as archive:
    x = archive["x"]
    observed = archive["observed"]
    calculated = archive["predicted"]
    background = archive["background"]
    signal = archive["signal"]

difference = observed - calculated
weights = 1.0 / np.maximum(observed, 1.0)
rwp = 100.0 * np.sqrt(np.sum(weights * difference**2) / np.sum(weights * observed**2))
standardized = difference / np.sqrt(np.maximum(calculated, 1.0))
poisson = 2.0 * np.sum(
    np.where(observed > 0, calculated - observed + observed * np.log(observed / calculated), calculated)
) / len(x)

smooth = gaussian_filter1d(difference, 2.0)
indices, properties = find_peaks(np.abs(smooth), prominence=20.0, distance=5)
order = np.argsort(properties["prominences"])[::-1]
print(f"all-grid Rwp_percent={rwp:.8f}")
print(f"mean_standardized_squared_residual={np.mean(standardized**2):.8f}")
print(f"Poisson_deviance_per_bin_against_observations={poisson:.8f}")
print(f"residual_mean={difference.mean():.6f} residual_std={difference.std():.6f}")
print("largest smoothed residual features: two_theta,difference,prominence")
for j in order[:30]:
    i = indices[j]
    print(f"{x[i]:.6f},{smooth[i]:.6f},{properties['prominences'][j]:.6f}")

pd.DataFrame(
    {
        "two_theta_deg": x,
        "observed": observed,
        "calculated": calculated,
        "difference": difference,
        "background": background,
    }
).to_csv(ROOT / "refinement" / "diagnostic_fit.csv", index=False)

fig, axes = plt.subplots(3, 1, figsize=(15, 10), sharex=True, gridspec_kw={"height_ratios": [3, 1, 1]})
axes[0].plot(x, observed, color="black", linewidth=0.45, label="Observed")
axes[0].plot(x, calculated, color="tab:red", linewidth=0.55, label="Calculated")
axes[0].plot(x, background, color="tab:blue", linewidth=0.5, label="Background")
axes[0].legend(loc="upper right")
axes[0].set_ylabel("Counts")
axes[1].plot(x, difference, color="tab:blue", linewidth=0.45)
axes[1].axhline(0, color="black", linewidth=0.5)
axes[1].set_ylabel("Obs − calc")
axes[2].plot(x, standardized, color="tab:green", linewidth=0.4)
axes[2].axhline(0, color="black", linewidth=0.5)
axes[2].set_ylabel("Standardized residual")
axes[2].set_xlabel(r"$2\theta$ (degrees)")
fig.tight_layout()
fig.savefig(ROOT / "refinement" / "diagnostic_fit.png", dpi=160)
