#!/usr/bin/env python3
"""Test only nuisance models that are present in the stated synthetic lab prior."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "refinement" / "explore"
BASE = ROOT / "refinement" / "polished.gpx"
AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def run(source, name, setup):
    target = WORK / f"{name}.gpx"
    project = G2.G2Project(gpxfile=str(source), newgpx=str(target))
    hist = project.histograms()[0]
    hist.SampleParameters["Shift"][1] = False
    setup(project, hist)
    project.set_Controls("cycles", 30)
    project.refine(makeBack=False)
    project.save()
    row = {
        "name": name,
        "project": str(target.relative_to(ROOT)),
        "wR_percent": float(hist.residuals["wR"]),
        "R_percent": float(hist.residuals["R"]),
        "mass_fractions": {k: float(v[0]) for k, v in hist.ComputeMassFracs().items()},
        "polarization": float(hist.InstrumentParameters["Polariz."][1]),
        "zero": float(hist.InstrumentParameters["Zero"][1]),
        "roughness": [float(hist.SampleParameters["SurfRoughA"][0]), float(hist.SampleParameters["SurfRoughB"][0])],
        "texture": {
            phase.name: {
                "ratio": float(phase.data["Histograms"][hist.name]["Pref.Ori."][1]),
                "axis": phase.data["Histograms"][hist.name]["Pref.Ori."][3],
                "refine": bool(phase.data["Histograms"][hist.name]["Pref.Ori."][2]),
            }
            for phase in project.phases()
        },
    }
    print(json.dumps(row, sort_keys=True))
    return target, row


def main():
    WORK.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    results = []

    polar, row = run(
        BASE,
        "polarization",
        lambda project, hist: hist.set_refinements({"Instrument Parameters": ["Polariz."]}),
    )
    results.append(row)

    def setup_rough(project, hist):
        hist.SampleParameters["SurfRoughA"][0] = 0.3
        hist.SampleParameters["SurfRoughB"][0] = 0.1
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})

    _, row = run(polar, "polarization_roughness", setup_rough)
    results.append(row)

    for phase_name in ["WO3_monoclinic", "ZnO_wurtzite"]:
        for axis in AXES:
            tag = "".join(str(v) for v in axis)

            def setup_texture(project, hist, phase_name=phase_name, axis=axis):
                hap = project.phase(phase_name).data["Histograms"][hist.name]
                hap["Pref.Ori."][0] = "MD"
                hap["Pref.Ori."][1] = 1.0
                hap["Pref.Ori."][2] = True
                hap["Pref.Ori."][3] = list(axis)

            _, row = run(polar, f"texture_{phase_name}_{tag}", setup_texture)
            results.append(row)

    (WORK / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
