#!/usr/bin/env python3
"""Regularize the fitted background to the identified generator family."""

from pathlib import Path
import json

import numpy as np
from scipy.optimize import least_squares
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "refinement" / "explore" / "control_zero.gpx"
OUTPUT = ROOT / "refinement" / "explore" / "exp_background.gpx"


def family(x, q):
    t = (x - x[0]) / (x[-1] - x[0])
    floor = q[0] * (1 - t) ** 2 + q[1] * 2 * t * (1 - t) + q[2] * t**2
    return floor + q[3] * np.exp(-(x - x[0]) / q[4])


def fit_family(x, observed, signal, q0, mask):
    root_weight = 1.0 / np.sqrt(np.maximum(observed, 1.0))
    result = least_squares(
        lambda q: ((family(x, q) + signal - observed) * root_weight)[mask],
        q0,
        bounds=([0, 0, 0, 0, 5], [4000, 4000, 4000, 4000, 20]),
        xtol=1e-13,
        ftol=1e-13,
        gtol=1e-13,
        max_nfev=10000,
    )
    return result.x


def install_background(hist, x, q, mask, count=16):
    low, high = hist.data["Limits"][1]
    reduced = 2 * (x - low) / (high - low) - 1
    coeffs = np.polynomial.chebyshev.chebfit(reduced[mask], family(x, q)[mask], count - 1)
    hist.data["Background"][0] = ["chebyschev-1", False, count, *map(float, coeffs)]


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUTPUT))
    hist = project.histograms()[0]
    x, observed = (np.asarray(v, float) for v in hist.data["data"][1][:2])
    low, high = hist.data["Limits"][1]
    mask = (x >= low) & (x <= high)
    q = np.array([406.3, 325.4, 453.4, 2266.1, 7.259], float)

    history = []
    for iteration in range(4):
        calculated = np.asarray(hist.data["data"][1][3], float)
        background = np.asarray(hist.data["data"][1][4], float)
        signal = calculated - background
        q = fit_family(x, observed, signal, q, mask)
        install_background(hist, x, q, mask)
        project.set_Controls("cycles", 50)
        project.refine(makeBack=False)
        history.append({
            "iteration": iteration + 1,
            "parameters": q.tolist(),
            "wR_percent": float(hist.residuals["wR"]),
        })
        print(json.dumps(history[-1]))

    project.save()
    print("history", json.dumps(history, indent=2))
    print("residuals", json.dumps(hist.residuals, default=float, sort_keys=True))
    print("mass_fractions", hist.ComputeMassFracs())
    print("background", hist.data["Background"][0])


if __name__ == "__main__":
    main()
