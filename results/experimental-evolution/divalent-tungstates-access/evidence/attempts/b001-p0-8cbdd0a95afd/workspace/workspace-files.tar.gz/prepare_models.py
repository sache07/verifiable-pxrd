#!/usr/bin/env python3
"""Recreate the benchmark's neutral, isotropic parent-model convention."""

from pathlib import Path
import sys

from pymatgen.core import Structure


ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / "learned" / "divalent-tungstates" / "runtime"
sys.path.insert(0, str(RUNTIME))
from models import write_synthetic_model  # noqa: E402


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
SOURCES = {
    "WO3_parent.cif": COD / "2/31/10/2311041.cif",
    "ZnO_parent.cif": COD / "9/00/41/9004178.cif",
    "ZnWO4_diagnostic_parent.cif": COD / "1/52/06/1520641.cif",
}

for name, source in SOURCES.items():
    structure = Structure.from_file(source, primitive=False)
    target = ROOT / "models" / name
    write_synthetic_model(structure, target)
    print(f"{name}: {structure.composition.reduced_formula}, {len(structure)} atoms -> {target}")
