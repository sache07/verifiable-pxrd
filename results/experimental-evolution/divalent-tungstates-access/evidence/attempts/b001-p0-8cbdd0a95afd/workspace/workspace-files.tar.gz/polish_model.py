#!/usr/bin/env python3
"""Remove exact Rietveld degeneracies and converge the selected model."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "refinement" / "trial.gpx"
OUTPUT = ROOT / "refinement" / "polished.gpx"


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUTPUT))
    hist = project.histograms()[0]

    # Histogram scale and all HAP scales are multiplicatively redundant. Absorb
    # the histogram scale into each HAP scale and then hold it fixed at unity.
    common_scale = float(hist.SampleParameters["Scale"][0])
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][0] *= common_scale
    hist.SampleParameters["Scale"] = [1.0, False]

    # Instrument X and an isotropic phase-size term have the same 1/cos(theta)
    # dependence. Select a physically plausible X inside the stated prior and
    # let the two phase sizes carry the independently observable differences.
    hist.InstrumentParameters["X"][1] = 0.8
    hist.InstrumentParameters["X"][2] = False

    # In P63mc only the Zn-O relative z coordinate is observable. Shift the
    # origin to Zn z=0 and keep Zn fixed to remove the exact origin null mode.
    zno = project.phase("ZnO_wurtzite")
    zn = zno.atom("Zn0")
    oxygen = zno.atom("O1")
    origin = float(zn.coordinates[2])
    zn.coordinates = (zn.coordinates[0], zn.coordinates[1], 0.0)
    oxygen.coordinates = (oxygen.coordinates[0], oxygen.coordinates[1], (oxygen.coordinates[2] - origin) % 1.0)
    zn.refinement_flags = "U"
    oxygen.refinement_flags = "XU"

    project.set_Controls("cycles", 24)
    project.refine(makeBack=False)
    project.save()

    print("residuals", json.dumps(hist.residuals, default=float, sort_keys=True))
    print("mass_fractions", hist.ComputeMassFracs())
    print("instrument", {k: hist.InstrumentParameters[k] for k in ["Zero", "Polariz.", "U", "W", "X", "SH/L"]})
    print("sample", {k: hist.SampleParameters[k] for k in ["Scale", "Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, "cell", phase.data["General"]["Cell"], "scale", hap["Scale"], "size", hap["Size"], "strain", hap["Mustrain"])
        for atom in phase.atoms():
            print(" ", atom.label, atom.element, atom.coordinates, atom.ADP, atom.refinement_flags)


if __name__ == "__main__":
    main()
