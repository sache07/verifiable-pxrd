#!/usr/bin/env python3
"""Export the independently regenerated full-grid profile from final.gpx."""

from pathlib import Path
import json

import numpy as np


ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / "refinement" / "final_replay"

with np.load(REPLAY / "prediction.npz") as data:
    x = data["x"]
    observed = data["observed"]
    calculated = data["predicted"]

difference = observed - calculated
weights = 1.0 / np.maximum(observed, 1.0)
chi_square = float(np.sum(weights * difference**2))
denominator = float(np.sum(weights * observed**2))
rwp = float(100.0 * np.sqrt(chi_square / denominator))
rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
poisson_deviance = float(
    2.0
    * np.sum(
        np.where(
            observed > 0,
            calculated - observed + observed * np.log(observed / calculated),
            calculated,
        )
    )
)

matrix = np.column_stack((x, observed, calculated, difference))
np.savetxt(
    ROOT / "fit.csv",
    matrix,
    delimiter=",",
    header="two_theta,observed,calculated,difference",
    comments="",
    fmt=["%.8f", "%.8f", "%.10f", "%.10f"],
)

metrics = {
    "rwp_percent_full_grid": rwp,
    "rp_percent_full_grid": rp,
    "chi_square_full_grid": chi_square,
    "poisson_deviance_against_observations": poisson_deviance,
    "poisson_deviance_per_bin_against_observations": poisson_deviance / len(x),
    "n_points": int(len(x)),
}
(REPLAY / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
print(json.dumps(metrics, indent=2))
