#!/usr/bin/env python3
"""Save and export the selected, converged GSAS-II project."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "refinement" / "explore" / "exp_background.gpx"
FINAL = ROOT / "final.gpx"
EXPORTS = {
    "WO3_monoclinic": ROOT / "phase_WO3_monoclinic.cif",
    "ZnO_wurtzite": ROOT / "phase_ZnO_wurtzite.cif",
}


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    project.save()
    # Reload what was actually serialized, so every export comes from final.gpx.
    project = G2.G2Project(gpxfile=str(FINAL))
    hist = project.histograms()[0]
    fractions = hist.ComputeMassFracs()
    for phase in project.phases():
        phase.export_CIF(str(EXPORTS[phase.name]))
    print(json.dumps({
        "histogram": hist.name,
        "residuals": hist.residuals,
        "fractions": {name: {"value": value, "esd": esd} for name, (value, esd) in fractions.items()},
        "exports": {name: str(path) for name, path in EXPORTS.items()},
    }, indent=2, default=float))


if __name__ == "__main__":
    main()
