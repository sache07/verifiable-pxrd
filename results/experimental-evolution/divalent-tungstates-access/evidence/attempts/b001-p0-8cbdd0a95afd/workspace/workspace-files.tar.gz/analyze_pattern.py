#!/usr/bin/env python3
"""Initial peak extraction and visualization for the supplied PXRD scan."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.ndimage import minimum_filter1d, gaussian_filter1d
from scipy.signal import find_peaks, peak_widths


ROOT = Path(__file__).resolve().parent
data = pd.read_csv(ROOT / "inputs" / "pattern.csv")
x = data["two_theta_deg"].to_numpy(float)
y = data["intensity"].to_numpy(float)

# A broad morphological opening is sufficient for candidate-search peak picking.
floor = minimum_filter1d(y, size=181, mode="nearest")
background = gaussian_filter1d(floor, sigma=50)
signal = y - background
noise = np.sqrt(np.maximum(y, 1.0))
snr = gaussian_filter1d(signal, sigma=1.2) / noise

indices, props = find_peaks(
    gaussian_filter1d(signal, sigma=1.2),
    prominence=5.0 * np.median(noise),
    height=4.0 * np.median(noise),
    distance=4,
)
width_result = peak_widths(signal, indices, rel_height=0.5)
rows = []
for i, idx in enumerate(indices):
    rows.append(
        (
            x[idx],
            y[idx],
            signal[idx],
            props["prominences"][i],
            width_result[0][i] * np.median(np.diff(x)),
            snr[idx],
        )
    )
rows.sort(key=lambda row: row[3], reverse=True)

print(f"points={len(x)} range={x[0]:.8f}..{x[-1]:.8f} step={np.median(np.diff(x)):.8f}")
print(f"intensity min/median/max={y.min():.1f}/{np.median(y):.1f}/{y.max():.1f}")
print("two_theta,intensity,net,prominence,fwhm_deg,snr")
for row in rows[:100]:
    print(",".join(f"{value:.6g}" for value in row))

fig, axes = plt.subplots(2, 1, figsize=(15, 8), sharey=False)
axes[0].plot(x, y, color="black", linewidth=0.5)
axes[0].plot(x, background, color="tab:red", linewidth=1.0)
axes[0].set_ylabel("Counts")
axes[0].set_title("Observed PXRD and peak-picking background")
axes[1].plot(x, signal, color="black", linewidth=0.5)
axes[1].scatter(x[indices], signal[indices], s=7, color="tab:blue")
axes[1].set_xlabel(r"$2\theta$ (degrees, Cu K$\alpha$)")
axes[1].set_ylabel("Background-subtracted counts")
fig.tight_layout()
fig.savefig(ROOT / "pattern_overview.png", dpi=160)
