from GSASII import GSASIIscriptable as G2sc


project = G2sc.G2Project(
    "branch_joint_cells.gpx", newgpx="branch_joint_cells_replay.gpx"
)
project.refine()
project.save()

histogram = project.histograms()[0]
print("Rwp", histogram.get_wR())
print("Rvals", {key: histogram.data["data"][0].get(key) for key in ("R", "wR", "Rb", "wRb", "wRmin")})
print("mass_fractions", histogram.ComputeMassFracs())
print("sample", histogram.data["Sample Parameters"])
print("instrument", histogram.data["Instrument Parameters"][0])
for phase in project.phases():
    print(phase.name, phase.get_cell())
