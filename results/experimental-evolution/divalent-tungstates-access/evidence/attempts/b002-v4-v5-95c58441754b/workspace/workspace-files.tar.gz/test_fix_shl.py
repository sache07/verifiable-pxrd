from GSASII import GSASIIscriptable as G2sc


project = G2sc.G2Project(
    "branch_joint_cells.gpx", newgpx="branch_joint_cells_shl_fixed.gpx"
)
histogram = project.histograms()[0]
histogram.data["Instrument Parameters"][0]["SH/L"][2] = False
project.save()
project.refine()
project.save()

print("Rwp", histogram.get_wR())
print("mass_fractions", histogram.ComputeMassFracs())
print("shift", histogram.data["Sample Parameters"]["Shift"])
print("shl", histogram.data["Instrument Parameters"][0]["SH/L"])
for phase in project.phases():
    print(phase.name, phase.get_cell())
