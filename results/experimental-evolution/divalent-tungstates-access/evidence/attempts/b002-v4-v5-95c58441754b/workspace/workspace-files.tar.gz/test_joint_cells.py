from GSASII import GSASIIscriptable as G2sc


project = G2sc.G2Project(
    "checkpoint_17_clean_three_phase.gpx", newgpx="branch_joint_cells.gpx"
)
for phase in project.phases():
    phase.set_refinements({"Cell": True})
project.save()
project.refine()
project.save()

histogram = project.histograms()[0]
print("Rwp", histogram.get_wR())
print("mass_fractions", histogram.ComputeMassFracs())
for phase in project.phases():
    print(phase.name, phase.get_cell())
