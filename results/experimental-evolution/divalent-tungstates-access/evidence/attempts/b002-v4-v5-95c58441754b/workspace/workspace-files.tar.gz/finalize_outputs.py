import csv

from GSASII import GSASIIscriptable as G2sc


SOURCE_PROJECT = "branch_joint_cells_shl_fixed.gpx"
FINAL_PROJECT = "final.gpx"
CIF_PATHS = {
    "ZnWO4_wolframite": "znwo4_wolframite.cif",
    "ZnO_wurtzite": "zno_wurtzite.cif",
    "WO3_triclinic": "wo3_triclinic.cif",
}


project = G2sc.G2Project(SOURCE_PROJECT, newgpx=FINAL_PROJECT)
histogram = project.histograms()[0]

# A deleted comparison phase left only obsolete R-factor cache entries. Remove
# those entries so the submitted project contains exactly the three phases used.
residual_cache = histogram.data["data"][0]
for key in list(residual_cache):
    if isinstance(key, str) and key.startswith("3:"):
        del residual_cache[key]

project.save()

for phase in project.phases():
    phase.export_CIF(CIF_PATHS[phase.name])

x, observed, weight, calculated, background, difference = histogram.data["data"][1]
with open("fit.csv", "w", newline="", encoding="utf-8") as stream:
    writer = csv.writer(stream)
    writer.writerow(
        [
            "two_theta_deg",
            "observed",
            "calculated",
            "background",
            "difference",
        ]
    )
    for values in zip(x, observed, calculated, background, difference):
        writer.writerow(f"{float(value):.10g}" for value in values)

print("phases", [phase.name for phase in project.phases()])
print("mass_fractions", histogram.ComputeMassFracs())
print(
    "fit_statistics",
    {
        key: residual_cache[key]
        for key in ("R", "wR", "wRmin", "Durbin-Watson", "Nobs")
    },
)
