from GSASII import GSASIIscriptable as G2sc


project = G2sc.G2Project(
    "checkpoint_17_clean_three_phase.gpx", newgpx="branch_zno_oxygen.gpx"
)
phase = project.phase("ZnO_wurtzite")
phase.set_refinements({"Atoms": {"O": "X"}})
project.save()
project.refine()
project.save()

histogram = project.histograms()[0]
print("Rwp", histogram.get_wR())
print("mass_fractions", histogram.ComputeMassFracs())
for atom in phase.atoms():
    print(atom.label, atom.coordinates, repr(atom.refinement_flags))
