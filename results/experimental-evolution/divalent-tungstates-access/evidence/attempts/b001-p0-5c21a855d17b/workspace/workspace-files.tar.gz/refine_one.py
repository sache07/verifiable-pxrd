#!/usr/bin/env python3
"""Run one tightly scoped GSAS-II refinement experiment."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_flags(project, hist):
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1:
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""


def fractions(project, histname):
    vals = [
        max(0.0, float(p.data["General"]["Mass"]) * float(p.data["Histograms"][histname]["Scale"][0]))
        for p in project.phases()
    ]
    return {p.name: v / sum(vals) for p, v in zip(project.phases(), vals)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--phase", required=True)
    ap.add_argument(
        "--mode",
        choices=["coords", "uiso", "texture", "texture_fixed", "size", "strain", "surface_a", "surface_b", "polarization", "instrument", "shift", "zero", "cell"],
        default="coords",
    )
    ap.add_argument("--axis", default="0,0,1")
    ap.add_argument("--md-ratio", type=float, default=1.0)
    ap.add_argument("--cycles", type=int, default=12)
    ap.add_argument("--coord-bound", type=float, default=0.008)
    ap.add_argument("--elements", default=None)
    ap.add_argument("--background", action="store_true")
    ap.add_argument("--surface-a-start", type=float, default=None)
    ap.add_argument("--surface-b-start", type=float, default=None)
    ap.add_argument("--size-start", type=float, default=None)
    ap.add_argument("--strain-start", type=float, default=None)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    root = Path(__file__).resolve().parent
    src = (root / args.input).resolve()
    dst = (root / args.output).resolve()
    dst.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(src), newgpx=str(dst))
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.data["Controls"]["data"]["parmMinDict"] = {}
    project.data["Controls"]["data"]["parmMaxDict"] = {}
    clear_flags(project, hist)
    if args.surface_a_start is not None:
        hist.SampleParameters["SurfRoughA"][0] = args.surface_a_start
    if args.surface_b_start is not None:
        hist.SampleParameters["SurfRoughB"][0] = args.surface_b_start
    if args.background:
        hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    phase = project.phase(args.phase)
    selected_hap = phase.data["Histograms"][hist.name]
    if args.size_start is not None:
        selected_hap["Size"][1][0] = args.size_start
    if args.strain_start is not None:
        selected_hap["Mustrain"][1][0] = args.strain_start

    if args.mode == "coords":
        selected = None if args.elements is None else set(args.elements.split(","))
        for i, atom in enumerate(phase.atoms()):
            if selected is not None and atom.element not in selected:
                continue
            atom.refinement_flags = "X"
            if args.coord_bound > 0:
                for axis in "xyz":
                    var = f"{phase.id}::dA{axis}:{i}"
                    project.set_Controls("parmMin", -args.coord_bound, var)
                    project.set_Controls("parmMax", args.coord_bound, var)
    elif args.mode == "uiso":
        variables = []
        for i, atom in enumerate(phase.atoms()):
            if atom.adp_flag == "I":
                atom.refinement_flags = "U"
                variables.append(f"{phase.id}::AUiso:{i}")
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=True)
        project.set_Controls("parmMin", 0.003, variables[0])
        project.set_Controls("parmMax", 0.02, variables[0])
    elif args.mode in {"texture", "texture_fixed"}:
        axis = [int(v) for v in args.axis.split(",")]
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = args.md_ratio
        hap["Pref.Ori."][2] = args.mode == "texture"
        hap["Pref.Ori."][3] = axis
        if args.mode == "texture":
            project.set_Controls("parmMin", 0.7, f"{phase.id}:0:MD")
            project.set_Controls("parmMax", 1.4, f"{phase.id}:0:MD")
    elif args.mode == "size":
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    elif args.mode == "strain":
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    elif args.mode == "surface_a":
        hist.SampleParameters["SurfRoughA"][1] = True
    elif args.mode == "surface_b":
        hist.SampleParameters["SurfRoughB"][1] = True
    elif args.mode == "polarization":
        hist.InstrumentParameters["Polariz."][2] = True
    elif args.mode == "instrument":
        for key in ["U", "W", "X", "SH/L"]:
            hist.InstrumentParameters[key][2] = True
    elif args.mode == "shift":
        hist.SampleParameters["Shift"][1] = True
    elif args.mode == "zero":
        hist.InstrumentParameters["Zero"][2] = True
    elif args.mode == "cell":
        phase.data["General"]["Cell"][0] = True

    project.set_Controls("cycles", args.cycles)
    project.save()
    before = float(hist.residuals.get("wR", float("nan")))
    project.refine()
    project.save()
    result = {
        "mode": args.mode,
        "phase": phase.name,
        "axis": args.axis if args.mode in {"texture", "texture_fixed"} else None,
        "before_rwp": before,
        "after_rwp": float(hist.residuals.get("wR", float("nan"))),
        "fractions": fractions(project, hist.name),
        "covariance": project.data["Covariance"]["data"].get("Rvals", {}),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }
    if args.mode in {"texture", "texture_fixed"}:
        result["ratio"] = float(phase.data["Histograms"][hist.name]["Pref.Ori."][1])
    if args.mode == "uiso":
        result["uiso"] = [float(a.uiso) for a in phase.atoms() if a.adp_flag == "I"]
    if args.mode in {"size", "strain"}:
        hap = phase.data["Histograms"][hist.name]
        result[args.mode] = float(hap["Size" if args.mode == "size" else "Mustrain"][1][0])
    if args.mode in {"surface_a", "surface_b"}:
        key = "SurfRoughA" if args.mode == "surface_a" else "SurfRoughB"
        result[key] = float(hist.SampleParameters[key][0])
    if args.mode == "polarization":
        result["polarization"] = float(hist.InstrumentParameters["Polariz."][1])
    if args.mode == "instrument":
        result["instrument"] = {k: float(hist.InstrumentParameters[k][1]) for k in ["U", "W", "X", "SH/L"]}
    dst.with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
