#!/usr/bin/env python3
"""Run the scorer's native no-refinement GPX replay and report observed-data Rwp."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys

import numpy as np


ROOT = Path(__file__).resolve().parent
WORKER = ROOT / "learned" / "divalent-tungstates" / "scorer" / "runtime"
sys.path.insert(0, str(WORKER))
from replay_worker import replay  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("project")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    project = (ROOT / args.project).resolve()
    observed = (ROOT / "inputs" / "pattern.csv").resolve()
    out = (ROOT / args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    old = Path.cwd()
    os.chdir(out)
    try:
        report = replay({"project": str(project), "observed": str(observed)})
    finally:
        os.chdir(old)
    with np.load(out / "prediction.npz", allow_pickle=False) as z:
        y = z["observed"]
        calc = z["predicted"]
        q = 1 / np.maximum(y, 1.0)
        rwp = float(100 * np.sqrt(np.sum(q * (y - calc) ** 2) / np.sum(q * y * y)))
    report["observed_rwp_percent"] = rwp
    (out / "report.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(json.dumps(report, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
