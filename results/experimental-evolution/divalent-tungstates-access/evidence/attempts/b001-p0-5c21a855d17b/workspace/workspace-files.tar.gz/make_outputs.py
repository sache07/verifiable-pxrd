#!/usr/bin/env python3
"""Create fit.csv and result.json from the independently replayed final project."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / "replay" / "final"


def main() -> None:
    arrays = np.load(REPLAY / "prediction.npz")
    x = arrays["x"]
    observed = arrays["observed"]
    calculated = arrays["predicted"]
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference_observed_minus_calculated",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )

    replay = json.loads((REPLAY / "report.json").read_text())
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    rwp = 100.0 * float(np.sqrt(chi_square / np.sum(weights * observed**2)))
    rp = 100.0 * float(np.sum(np.abs(difference)) / np.sum(observed))
    n_points = int(observed.size)
    n_parameters = 22
    reduced_chi_square = chi_square / (n_points - n_parameters)
    goodness_of_fit = float(np.sqrt(reduced_chi_square))
    rexp = rwp / goodness_of_fit

    phase_meta = {
        "CuWO4": ("copper(II) tungstate", "P -1", "phase_CuWO4.cif", "4000806"),
        "WO3": ("tungsten(VI) oxide", "P 21/c", "phase_WO3.cif", "2311041"),
        "Cu3WO6": ("copper tungsten oxide", "P a -3", "phase_Cu3WO6.cif", "1527404"),
        "CuO": ("tenorite", "C 2/c", "phase_CuO.cif", "1011194"),
    }
    phases = []
    for phase in replay["phases"]:
        formula = phase["name"]
        name, space_group, cif, reference = phase_meta[formula]
        phases.append(
            {
                "name": name,
                "formula": formula,
                "space_group": space_group,
                "cif": cif,
                "weight_fraction": float(phase["weight_fraction"]),
                "reference_cod_id": reference,
            }
        )

    result = {
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "phases": phases,
        "fit_statistics": {
            "r_wp_percent": rwp,
            "r_p_percent": rp,
            "r_exp_percent": rexp,
            "chi_square": chi_square,
            "reduced_chi_square": reduced_chi_square,
            "goodness_of_fit": goodness_of_fit,
            "number_of_points": n_points,
            "number_of_refined_parameters_in_last_cycle": n_parameters,
        },
        "profile": "fit.csv",
        "gsasii_project": "final.gpx",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
