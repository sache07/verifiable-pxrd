#!/usr/bin/env python3
"""Build and run a staged GSAS-II screening refinement for Cu-W-O phases."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_inputs(work: Path) -> tuple[Path, Path, np.ndarray, np.ndarray]:
    work.mkdir(parents=True, exist_ok=True)
    x, y = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1).T
    xye = work / "pattern.xye"
    with xye.open("w") as stream:
        stream.write("# two_theta intensity sigma\n")
        for xx, yy in zip(x, y):
            stream.write(f"{xx:.8f} {yy:.8f} {np.sqrt(max(yy, 1.0)):.8f}\n")
    inst = work / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha laboratory starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:15.0;V:0.0;W:15.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst, x, y


def initial_background(x: np.ndarray, y: np.ndarray, ncoef: int = 12) -> list[float]:
    step = float(np.median(np.diff(x)))
    width = max(11, int(round(3.0 / step)))
    if width % 2 == 0:
        width += 1
    base = percentile_filter(y, 8, size=width, mode="nearest")
    base = gaussian_filter1d(base, 30)
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(t, base, ncoef - 1).tolist()


def phase_summary(project: G2.G2Project, histname: str) -> list[dict]:
    rows = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histname]
        mass = float(phase.data["General"]["Mass"])
        scale = float(hap["Scale"][0])
        masses.append(max(0.0, mass * scale))
        rows.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": scale,
                "cell_mass": mass,
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    total = sum(masses)
    for row, value in zip(rows, masses):
        row["weight_fraction"] = value / total if total else 0.0
    return rows


def snapshot(project: G2.G2Project, hist, stage: str) -> dict:
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    return {
        "stage": stage,
        "residuals": hist.residuals,
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
        "sample": {
            k: (v[0] if isinstance(v, list) else v)
            for k, v in sample.items()
            if k in {"Type", "Gonio. radius", "Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"}
        },
        "background": hist.Background[0],
        "phases": phase_summary(project, hist.name),
    }


def run_stage(project: G2.G2Project, hist, label: str, log: list[dict]) -> None:
    project.refine()
    project.save()
    state = snapshot(project, hist, label)
    log.append(state)
    print(label, json.dumps({"residuals": state["residuals"], "phases": [(p["name"], p["weight_fraction"]) for p in state["phases"]]}))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", default="2106293")
    parser.add_argument("--cuwo4", default="4000806")
    parser.add_argument("--extra", default=None)
    parser.add_argument("--extra-name", default="extra")
    parser.add_argument("--cuo", default=None)
    parser.add_argument("--out", required=True)
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--quick", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    work = (ROOT / args.out).resolve()
    xye, instfile, x, y = write_inputs(work)
    project = G2.G2Project(newgpx=str(work / "screen.gpx"))
    hist = project.add_powder_histogram(str(xye), str(instfile), fmthint="xye")
    phase_specs = [(args.cuwo4, "CuWO4"), (args.wo3, "WO3")]
    if args.extra:
        phase_specs.append((args.extra, args.extra_name))
    if args.cuo:
        phase_specs.append((args.cuo, "CuO"))
    phases = [
        project.add_phase(str(cod_path(cid)), phasename=name, histograms=[hist], fmthint="CIF")
        for cid, name in phase_specs
    ]

    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [700.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.1, False]
    hist.SampleParameters["SurfRoughB"] = [0.1, False]
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": initial_background(x, y, 12),
                "refine": False,
            },
        }
    )

    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][1] = 500.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        for atom in phase.atoms():
            if atom.adp_flag == "I":
                atom.uiso = 0.01

    project.set_Controls("cycles", args.cycles)
    # The generator's physically allowed nuisance ranges are known from LAB.md.
    # Bounds prevent profile terms from compensating for a wrong phase model.
    bounds = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Polariz.": (0.5, 1.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.1),
        ":0:Shift": (-800.0, 800.0),
        ":0:SurfRoughA": (0.05, 0.6),
        ":0:SurfRoughB": (0.02, 0.5),
    }
    for phase in phases:
        bounds[f"{phase.id}:0:Scale"] = (0.0, 1.0e6)
        bounds[f"{phase.id}:0:Size;i"] = (0.04, 1.5)
        bounds[f"{phase.id}:0:Mustrain;i"] = (0.0, 8000.0)
    for variable, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable)
        project.set_Controls("parmMax", high, variable)
    project.save()
    log: list[dict] = [snapshot(project, hist, "initial")]

    hist.set_refinements({"Background": True})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    run_stage(project, hist, "scale_background", log)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    run_stage(project, hist, "cells_shift", log)

    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_stage(project, hist, "zero", log)

    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run_stage(project, hist, "instrument_profile", log)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_stage(project, hist, "position_revisit", log)
    hist.clear_refinements({"Sample Parameters": ["Shift"]})

    if args.quick:
        (work / "diagnostic.json").write_text(json.dumps(log, indent=2, allow_nan=False) + "\n")
        print(json.dumps(log[-1], indent=2, allow_nan=False))
        return

    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    run_stage(project, hist, "phase_profiles", log)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    run_stage(project, hist, "intensity_nuisance", log)

    (work / "diagnostic.json").write_text(json.dumps(log, indent=2, allow_nan=False) + "\n")
    print(json.dumps(log[-1], indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
