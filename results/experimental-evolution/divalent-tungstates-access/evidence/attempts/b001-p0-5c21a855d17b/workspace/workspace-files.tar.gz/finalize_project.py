#!/usr/bin/env python3
"""Freeze the selected model and export one CIF for each phase."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_one import clear_flags


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "final_refine" / "converged.gpx"
FINAL = ROOT / "final.gpx"


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    hist = project.histogram(0)
    clear_flags(project, hist)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.data["Controls"]["data"]["parmMinDict"] = {}
    project.data["Controls"]["data"]["parmMaxDict"] = {}

    # Retain the physically allowed edge values used in the converged model.
    hist.SampleParameters["Shift"][0] = 800.0
    hist.SampleParameters["SurfRoughA"][0] = 0.6
    hist.SampleParameters["SurfRoughB"][0] = 0.02
    for name in ["Cu3WO6", "CuO"]:
        hap = project.phase(name).data["Histograms"][hist.name]
        hap["Size"][1][0] = 1.5
        hap["Mustrain"][1][0] = 0.0
    project.phase("CuWO4").data["Histograms"][hist.name]["Mustrain"][1][0] = 300.0

    project.save()
    for phase in project.phases():
        phase.export_CIF(str(ROOT / f"phase_{phase.name}.cif"))
    project.save()


if __name__ == "__main__":
    main()
