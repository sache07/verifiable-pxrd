#!/usr/bin/env python3
"""Controlled later-stage refinements starting from a screened GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fractions(project, histname):
    terms = []
    for phase in project.phases():
        scale = float(phase.data["Histograms"][histname]["Scale"][0])
        terms.append(max(0.0, scale * float(phase.data["General"]["Mass"])))
    total = sum(terms)
    return [v / total for v in terms]


def state(project, hist, label):
    return {
        "stage": label,
        "residuals": hist.residuals,
        "fractions": dict(zip([p.name for p in project.phases()], fractions(project, hist.name))),
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "coordinates": {
            p.name: {a.label: list(map(float, a.coordinates)) for a in p.atoms()}
            for p in project.phases()
        },
    }


def run(project, hist, label, log):
    project.refine()
    project.save()
    row = state(project, hist, label)
    log.append(row)
    print(label, row["residuals"].get("wR"), row["fractions"])


def clear_flags(project, hist):
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for key, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1:
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--cycles", type=int, default=12)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    root = Path(__file__).resolve().parent
    src = (root / args.input).resolve()
    dst = (root / args.output).resolve()
    dst.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(src), newgpx=str(dst))
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", args.cycles)
    clear_flags(project, hist)
    project.save()
    log = [state(project, hist, "initial")]

    # Keep smooth background and phase scales active in each coordinate stage.
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True

    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "X"
        run(project, hist, f"coordinates_{phase.name}", log)
        for atom in phase.atoms():
            atom.refinement_flags = ""

    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "X"
    run(project, hist, "coordinates_all", log)

    (dst.with_suffix(".json")).write_text(json.dumps(log, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
