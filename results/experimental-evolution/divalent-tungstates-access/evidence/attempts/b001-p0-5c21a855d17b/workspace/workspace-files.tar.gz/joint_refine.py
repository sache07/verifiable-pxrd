#!/usr/bin/env python3
"""Run a controlled joint GSAS-II convergence stage."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_one import clear_flags, fractions


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--stage", choices=["position", "profile", "intensity", "all"], required=True)
    ap.add_argument("--cycles", type=int, default=24)
    ap.add_argument("--hold-cuo-size", action="store_true")
    ap.add_argument("--hold-surface-b", action="store_true")
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    root = Path(__file__).resolve().parent
    dst = (root / args.output).resolve()
    dst.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str((root / args.input).resolve()), newgpx=str(dst))
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.data["Controls"]["data"]["parmMinDict"] = {}
    project.data["Controls"]["data"]["parmMaxDict"] = {}
    clear_flags(project, hist)
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True

    if args.stage in {"position", "all"}:
        hist.SampleParameters["Shift"][1] = True
        hist.InstrumentParameters["Zero"][2] = True
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = True

    if args.stage in {"profile", "all"}:
        for key in ["U", "W", "X", "SH/L"]:
            hist.InstrumentParameters[key][2] = True
        for name in ["CuWO4", "WO3"]:
            phase = project.phase(name)
            phase.set_HAP_refinements({
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            })
        if not args.hold_cuo_size:
            project.phase("CuO").set_HAP_refinements(
                {"Size": {"type": "isotropic", "refine": True}}
            )

    if args.stage in {"intensity", "all"}:
        hist.Background[0][1] = True
        hist.InstrumentParameters["Polariz."][2] = True
        if not args.hold_surface_b:
            hist.SampleParameters["SurfRoughB"][1] = True
        project.phase("Cu3WO6").data["Histograms"][hist.name]["Pref.Ori."][2] = True
        for phase in project.phases():
            for atom in phase.atoms():
                if atom.adp_flag == "I":
                    atom.refinement_flags = "U"

    project.set_Controls("cycles", args.cycles)
    project.save()
    before = float(hist.residuals.get("wR", float("nan")))
    project.refine()
    project.save()
    result = {
        "stage": args.stage,
        "before_rwp": before,
        "after_rwp": float(hist.residuals.get("wR", float("nan"))),
        "fractions": fractions(project, hist.name),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
        "covariance": project.data["Covariance"]["data"].get("Rvals", {}),
        "instrument": {k: float(hist.InstrumentParameters[k][1]) for k in ["Zero", "Polariz.", "U", "W", "X", "SH/L"]},
        "sample": {k: float(hist.SampleParameters[k][0]) for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": [float(v) for v in phase.data["General"]["Cell"][1:7]],
            "size": float(hap["Size"][1][0]),
            "strain": float(hap["Mustrain"][1][0]),
            "md_ratio": float(hap["Pref.Ori."][1]),
            "uiso": [float(a.uiso) for a in phase.atoms()],
        }
    dst.with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
