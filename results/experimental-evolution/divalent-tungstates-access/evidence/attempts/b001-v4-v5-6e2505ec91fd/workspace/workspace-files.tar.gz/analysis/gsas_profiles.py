#!/usr/bin/env python3
"""Add isotropic phase broadening terms to a refined GSAS-II project."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def numeric(values):
    return {k: float(v) for k, v in values.items()
            if np.isscalar(v) and isinstance(v, (int, float, np.number))}


def profile_state(project, label):
    hist = project.histogram(0)
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "scale": float(hap["Scale"][0]),
            "size_type": hap["Size"][0],
            "size_um": [float(v) for v in hap["Size"][1]],
            "size_refine": [bool(v) for v in hap["Size"][2]],
            "mustrain_type": hap["Mustrain"][0],
            "mustrain_ppm": [float(v) for v in hap["Mustrain"][1]],
            "mustrain_refine": [bool(v) for v in hap["Mustrain"][2]],
        }
    return {
        "label": label,
        "residuals": numeric(hist.residuals),
        "Rvals": numeric(project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})),
        "instrument": {k: float(hist.InstrumentParameters[k][1])
                       for k in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
        "phases": phases,
    }


def checkpoint(project, outdir, label, history):
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    info = profile_state(project, label)
    history.append(info)
    print(json.dumps({"step": label, "Rwp": info["residuals"].get("wR"),
                      "instrument": info["instrument"],
                      "profiles": {k: {"size": v["size_um"], "strain": v["mustrain_ppm"]}
                                   for k, v in info["phases"].items()}}, sort_keys=True))


def refine(project, outdir, label, history):
    project.refine()
    checkpoint(project, outdir, label, history)


def set_profile_bounds(project, phase):
    p = phase.id
    project.set_Controls("parmMin", 0.02, f"{p}:0:Size;i")
    project.set_Controls("parmMax", 20.0, f"{p}:0:Size;i")
    project.set_Controls("parmMin", 0.0, f"{p}:0:Mustrain;i")
    project.set_Controls("parmMax", 12000.0, f"{p}:0:Mustrain;i")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("--outdir", required=True, type=Path)
    ap.add_argument("--cycles", type=int, default=8)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input))
    project.save(str(args.outdir / "working.gpx"))
    project.set_Controls("cycles", args.cycles)
    hist = project.histogram(0)
    history = []

    # Keep coordinates and peak positions fixed while broadening is introduced.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])
        set_profile_bounds(project, phase)
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "Polariz.", "U", "W", "X", "SH/L"],
        "Sample Parameters": ["Shift"],
    })
    checkpoint(project, args.outdir, "00_input", history)

    # Introduce crystallite size phase-by-phase, preserving each accepted value.
    for index, phase in enumerate(project.phases(), start=1):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
        refine(project, args.outdir, f"1{index}_size_{phase.name}", history)
        phase.clear_HAP_refinements({"Size": True}, [hist])

    # Let all accepted size values settle together once.
    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    refine(project, args.outdir, "20_sizes_joint", history)
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True}, [hist])

    # Add isotropic microstrain one phase at a time.
    for index, phase in enumerate(project.phases(), start=1):
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
        refine(project, args.outdir, f"3{index}_strain_{phase.name}", history)
        phase.clear_HAP_refinements({"Mustrain": True}, [hist])

    # Settle both phase-specific terms, then recalibrate the common profile.
    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True},
                                  "Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    refine(project, args.outdir, "40_phase_profiles_joint", history)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, args.outdir, "50_common_profile", history)
    refine(project, args.outdir, "51_common_profile_converged", history)

    project.save(str(args.outdir / "profiles.gpx"))
    (args.outdir / "history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
