#!/usr/bin/env python3
"""Refine calibration/polarization and symmetry-constrained atom coordinates.

This starts from an accepted multiphase inventory. Profile and specimen-shape
terms are frozen while coordinates are introduced phase-by-phase so that each
checkpoint can be screened for geometry before later profile refinement.
"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def numeric_dict(values):
    return {
        k: float(v) for k, v in values.items()
        if np.isscalar(v) and isinstance(v, (int, float, np.number))
    }


def state(project, label):
    hist = project.histogram(0)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "label": label,
        "residuals": numeric_dict(hist.residuals),
        "Rvals": numeric_dict(rvals),
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
        "polarization": float(hist.InstrumentParameters["Polariz."][1]),
        "cells": {
            ph.name: [float(v) for v in ph.data["General"]["Cell"][1:]]
            for ph in project.phases()
        },
        "scales": {
            ph.name: float(ph.data["Histograms"][hist.name]["Scale"][0])
            for ph in project.phases()
        },
    }


def export_phases(project, outdir, label):
    target = outdir / f"cifs_{label}"
    target.mkdir(exist_ok=True)
    for phase in project.phases():
        phase.export_CIF(str(target / f"{phase.name}.cif"))


def checkpoint(project, outdir, label, history):
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    export_phases(project, outdir, label)
    info = state(project, label)
    history.append(info)
    print(json.dumps({
        "step": label,
        "Rwp": info["residuals"].get("wR"),
        "GOF": info["Rvals"].get("GOF"),
        "shift_um": info["shift_um"],
        "zero_deg": info["zero_deg"],
        "polarization": info["polarization"],
    }, sort_keys=True))


def run_refinement(project, outdir, label, history):
    project.refine()
    checkpoint(project, outdir, label, history)


def set_element_flags(phase, selected, flag):
    refs = {}
    for atom in phase.atoms():
        if atom.element in selected:
            refs[atom.label] = flag
    if refs:
        phase.set_refinements({"Atoms": refs})


def clear_all_atom_flags(project):
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--outdir", required=True, type=Path)
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input))
    project.save(str(args.outdir / "working.gpx"))
    project.set_Controls("cycles", args.cycles)
    hist = project.histogram(0)
    history = []
    checkpoint(project, args.outdir, "00_input", history)

    # Freeze the common profile while calibration and intensities are adjusted.
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    hist.set_refinements({"Instrument Parameters": ["Zero", "Polariz."]})
    project.set_Controls("parmMin", -0.35, ":0:Zero")
    project.set_Controls("parmMax", 0.35, ":0:Zero")
    project.set_Controls("parmMin", 0.5, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    project.set_Controls("parmMin", -1200.0, ":0:Shift")
    project.set_Controls("parmMax", 1200.0, ":0:Shift")
    run_refinement(project, args.outdir, "01_calibration", history)
    run_refinement(project, args.outdir, "02_calibration_converged", history)

    # Hold peak positions fixed during coordinate optimization. Background and
    # positive phase scales remain active to absorb the linear intensity change.
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "Polariz."],
        "Sample Parameters": ["Shift"],
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    clear_all_atom_flags(project)

    for index, phase in enumerate(project.phases(), start=1):
        set_element_flags(phase, {"Cu", "W"}, "X")
        run_refinement(project, args.outdir, f"1{index}_heavy_{phase.name}", history)
        set_element_flags(phase, {"Cu", "W"}, " ")

    for index, phase in enumerate(project.phases(), start=1):
        set_element_flags(phase, {"O"}, "X")
        run_refinement(project, args.outdir, f"2{index}_oxygen_{phase.name}", history)
        set_element_flags(phase, {"O"}, " ")

    project.save(str(args.outdir / "atoms.gpx"))
    (args.outdir / "history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
