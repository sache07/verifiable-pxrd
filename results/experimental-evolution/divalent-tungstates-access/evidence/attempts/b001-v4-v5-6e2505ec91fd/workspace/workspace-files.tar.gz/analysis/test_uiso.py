#!/usr/bin/env python3
"""Test one symmetry-independent, phase-wide isotropic U value per phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_frozen(project):
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("--outdir", required=True, type=Path)
    ap.add_argument("--cycles", type=int, default=8)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    probe = G2.G2Project(gpxfile=str(args.input))
    names = [p.name for p in probe.phases()]
    results = []

    for phase_name in names:
        project = G2.G2Project(gpxfile=str(args.input))
        outfile = args.outdir / f"uiso_{phase_name}.gpx"
        project.save(str(outfile))
        # Populate GSAS-II's ranId lookups before atom records are edited.
        project.index_ids()
        project.set_Controls("cycles", args.cycles)
        clear_frozen(project)
        hist = project.histogram(0)
        hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
        for phase in project.phases():
            phase.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])
            for atom in phase.atoms():
                atom.refinement_flags = " "

        phase = project.phase(phase_name)
        atom_vars = []
        for atom_index, atom in enumerate(phase.atoms()):
            atom.uiso = 0.008
            atom.refinement_flags = "U"
            var = f"{phase.id}::AUiso:{atom_index}"
            atom_vars.append(var)
            project.set_Controls("parmMin", 0.0, var)
            project.set_Controls("parmMax", 0.05, var)
        if len(atom_vars) > 1:
            project.add_EquivConstr(atom_vars, reloadIdx=False)
        project.save()
        project.refine()
        project.refine()
        project.save()
        values = [float(atom.uiso) for atom in phase.atoms()]
        frozen = project.get_Frozen()
        result = {
            "phase": phase_name,
            "Rwp": float(hist.residuals["wR"]),
            "uiso_A2": values,
            "frozen": frozen,
            "project": str(outfile),
        }
        results.append(result)
        print(json.dumps(result, sort_keys=True))
    (args.outdir / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
