#!/usr/bin/env python3
"""Screen bounded March-Dollase axes one phase at a time."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = {
    "CuWO4": [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]],
    "Cu3WO6": [[1, 0, 0], [1, 1, 0], [1, 1, 1]],
    "WO3": [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]],
    "CuO": [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]],
}


def clear_frozen(project):
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("--outdir", required=True, type=Path)
    ap.add_argument("--cycles", default=6, type=int)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    probe = G2.G2Project(gpxfile=str(args.input))
    results = []

    for phase_name in [p.name for p in probe.phases()]:
        for axis in AXES[phase_name]:
            tag = "".join(str(v) for v in axis)
            project = G2.G2Project(gpxfile=str(args.input))
            outfile = args.outdir / f"texture_{phase_name}_{tag}.gpx"
            project.save(str(outfile))
            project.index_ids()
            project.set_Controls("cycles", args.cycles)
            clear_frozen(project)
            hist = project.histogram(0)
            hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Zero", "Polariz."],
                                    "Sample Parameters": ["Shift"]})
            for phase in project.phases():
                phase.clear_refinements({"Cell": True})
                phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
                for atom in phase.atoms():
                    atom.refinement_flags = " "
            phase = project.phase(phase_name)
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][3] = list(axis)
            phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])
            var = f"{phase.id}:0:MD"
            project.set_Controls("parmMin", 0.5, var)
            project.set_Controls("parmMax", 2.0, var)
            project.refine()
            project.refine()
            project.save()
            result = {
                "phase": phase_name,
                "axis": axis,
                "ratio": float(hap["Pref.Ori."][1]),
                "Rwp": float(hist.residuals["wR"]),
                "frozen": project.get_Frozen(),
                "project": str(outfile),
            }
            results.append(result)
            print(json.dumps(result, sort_keys=True))
    (args.outdir / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
