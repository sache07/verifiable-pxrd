#!/usr/bin/env python3
"""One final bounded WO3 oxygen-coordinate convergence check."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--cycles", type=int, default=8)
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    p = G2.G2Project(gpxfile=str(args.input))
    p.save(str(args.output))
    p.index_ids()
    p.set_Controls("cycles", args.cycles)
    p.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    h = p.histogram(0)
    h.clear_refinements({
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "Z", "SH/L", "Zero", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
    })
    for ph in p.phases():
        ph.clear_refinements({"Cell": True})
        ph.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [h])
        for atom in ph.atoms():
            atom.refinement_flags = " "

    wo3 = p.phase("WO3")
    for i, atom in enumerate(wo3.atoms()):
        if atom.element != "O":
            continue
        atom.refinement_flags = "X"
        for axis, value in zip("xyz", atom.coordinates):
            p.set_Controls("parmMin", float(value) - 0.010, f"{wo3.id}::dA{axis}:{i}")
            p.set_Controls("parmMax", float(value) + 0.010, f"{wo3.id}::dA{axis}:{i}")
    p.refine()
    p.refine()
    coord_rwp = float(h.residuals["wR"])
    coord_shift = float(p.data["Covariance"]["data"]["Rvals"]["Max shft/sig"])
    for atom in wo3.atoms():
        atom.refinement_flags = " "

    p.phase("CuWO4").set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [h])
    wo3.set_HAP_refinements({
        "Mustrain": {"type": "uniaxial", "direction": [0, 0, 1], "refine": True}
    }, [h])
    for ph in p.phases():
        for atom in ph.atoms():
            atom.refinement_flags = "U"
    h.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    p.refine()
    p.refine()
    p.save()
    print(json.dumps({
        "coordinate_Rwp": coord_rwp,
        "coordinate_max_shift_esd": coord_shift,
        "final_Rwp": float(h.residuals["wR"]),
        "final_GOF": float(p.data["Covariance"]["data"]["Rvals"]["GOF"]),
        "final_max_shift_esd": float(p.data["Covariance"]["data"]["Rvals"]["Max shft/sig"]),
        "frozen": p.get_Frozen(),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
