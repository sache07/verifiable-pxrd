#!/usr/bin/env python3
"""Test bounded Suortti surface-roughness starts from one fixed checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


STARTS = [(0.10, 0.04), (0.30, 0.10), (0.50, 0.30)]


def clear_frozen(project):
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("--outdir", required=True, type=Path)
    ap.add_argument("--cycles", type=int, default=8)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    results = []

    for index, (start_a, start_b) in enumerate(STARTS):
        project = G2.G2Project(gpxfile=str(args.input))
        outfile = args.outdir / f"surface_{index}.gpx"
        project.save(str(outfile))
        project.index_ids()
        project.set_Controls("cycles", args.cycles)
        clear_frozen(project)
        hist = project.histogram(0)

        # Isolate this intensity correction while allowing phase scales and the
        # smooth background to readjust to it.
        hist.clear_refinements({
            "Instrument Parameters": ["U", "V", "W", "X", "Y", "Z", "SH/L", "Zero", "Polariz."],
            "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        })
        for phase in project.phases():
            phase.clear_refinements({"Cell": True})
            phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
            for atom in phase.atoms():
                atom.refinement_flags = " "

        hist.SampleParameters["SurfRoughA"][0] = start_a
        hist.SampleParameters["SurfRoughB"][0] = start_b
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        project.set_Controls("parmMin", 0.05, ":0:SurfRoughA")
        project.set_Controls("parmMax", 0.60, ":0:SurfRoughA")
        project.set_Controls("parmMin", 0.02, ":0:SurfRoughB")
        project.set_Controls("parmMax", 0.50, ":0:SurfRoughB")

        project.refine()
        project.refine()
        project.save()
        result = {
            "start": [start_a, start_b],
            "A": float(hist.SampleParameters["SurfRoughA"][0]),
            "B": float(hist.SampleParameters["SurfRoughB"][0]),
            "Rwp": float(hist.residuals["wR"]),
            "GOF": float(project.data["Covariance"]["data"]["Rvals"]["GOF"]),
            "frozen": project.get_Frozen(),
            "project": str(outfile),
        }
        results.append(result)
        print(json.dumps(result, sort_keys=True))

    (args.outdir / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
