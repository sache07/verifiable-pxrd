#!/usr/bin/env python3
"""Refine the accepted four-phase model and preserve physical checkpoints."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def clear_frozen(project):
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []


def numeric(values):
    return {k: float(v) for k, v in values.items()
            if isinstance(v, (int, float, np.number))}


def state(project, label):
    hist = project.histogram(0)
    return {
        "label": label,
        "Rwp": float(hist.residuals["wR"]),
        "Rp": float(hist.residuals["R"]),
        "GOF": float(project.data["Covariance"]["data"]["Rvals"]["GOF"]),
        "frozen": project.get_Frozen(),
        "instrument": {k: float(hist.InstrumentParameters[k][1])
                       for k in ("U", "W", "X", "SH/L", "Zero", "Polariz.")},
        "sample": {k: float(hist.SampleParameters[k][0])
                   for k in ("Shift", "SurfRoughA", "SurfRoughB")},
        "phases": {
            phase.name: {
                "scale": float(phase.data["Histograms"][hist.name]["Scale"][0]),
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
                "size": [float(v) for v in phase.data["Histograms"][hist.name]["Size"][1]],
                "mustrain": [float(v) for v in phase.data["Histograms"][hist.name]["Mustrain"][1]],
                "uiso": [float(a.uiso) for a in phase.atoms()],
            } for phase in project.phases()
        },
    }


def checkpoint(project, outdir, label, history):
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    item = state(project, label)
    history.append(item)
    print(json.dumps({"step": label, "Rwp": item["Rwp"], "GOF": item["GOF"],
                      "frozen": item["frozen"]}, sort_keys=True), flush=True)


def run(project, outdir, label, history, twice=False):
    project.refine()
    if twice:
        project.refine()
    checkpoint(project, outdir, label, history)


def clear_all(project, hist):
    hist.clear_refinements({
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "Z", "SH/L", "Zero", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        for atom in phase.atoms():
            atom.refinement_flags = " "


def set_coordinate_bounds(project, phase, width=0.02):
    for i, atom in enumerate(phase.atoms()):
        for axis, value in zip("xyz", atom.coordinates):
            project.set_Controls("parmMin", float(value) - width,
                                 f"{phase.id}::A{axis}:{i}")
            project.set_Controls("parmMax", float(value) + width,
                                 f"{phase.id}::A{axis}:{i}")


def set_element_flags(phase, elements, flag):
    for atom in phase.atoms():
        if atom.element in elements:
            atom.refinement_flags = flag


def activate_supported_terms(project, hist):
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        hap = phase.data["Histograms"][hist.name]
        if phase.name != "CuWO4":
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 10.0
        if phase.name != "WO3":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0

    cuwo4 = project.phase("CuWO4")
    cuwo4.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    project.set_Controls("parmMin", 0.04, f"{cuwo4.id}:0:Size;i")
    project.set_Controls("parmMax", 1.50, f"{cuwo4.id}:0:Size;i")

    wo3 = project.phase("WO3")
    hap = wo3.data["Histograms"][hist.name]
    eq, ax = float(hap["Mustrain"][1][0]), float(hap["Mustrain"][1][1])
    wo3.setSampleProfile(hist, "microstrain", "uniaxial", eq, ax, [0, 0, 1])
    wo3.set_HAP_refinements({
        "Mustrain": {"type": "uniaxial", "direction": [0, 0, 1], "refine": True}
    }, [hist])
    for suffix in ("i", "a"):
        project.set_Controls("parmMin", 300.0, f"{wo3.id}:0:Mustrain;{suffix}")
        project.set_Controls("parmMax", 8000.0, f"{wo3.id}:0:Mustrain;{suffix}")

    # One positive isotropic displacement value per phase; equivalence
    # constraints already present in the accepted checkpoint tie each phase's sites.
    for phase in project.phases():
        for i, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "U"
            project.set_Controls("parmMin", 0.001, f"{phase.id}::AUiso:{i}")
            project.set_Controls("parmMax", 0.030, f"{phase.id}::AUiso:{i}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("--outdir", required=True, type=Path)
    ap.add_argument("--cycles", type=int, default=8)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    project = G2.G2Project(gpxfile=str(args.input))
    project.save(str(args.outdir / "working.gpx"))
    project.index_ids()
    project.set_Controls("cycles", args.cycles)
    clear_frozen(project)
    hist = project.histogram(0)
    clear_all(project, hist)
    hist.SampleParameters["SurfRoughA"][0] = 0.0
    hist.SampleParameters["SurfRoughB"][0] = 0.0
    history = []
    checkpoint(project, args.outdir, "00_input", history)

    # Revisit coordinates in the prescribed heavy-then-light order. Bounds are
    # local to the already physical checkpoint and are wider than expected
    # reference-to-specimen displacements.
    for phase in project.phases():
        set_coordinate_bounds(project, phase)
        set_element_flags(phase, {"Cu", "W"}, "X")
        run(project, args.outdir, f"1_heavy_{phase.name}", history)
        set_element_flags(phase, {"Cu", "W"}, " ")

    for phase in project.phases():
        set_coordinate_bounds(project, phase)
        set_element_flags(phase, {"O"}, "X")
        run(project, args.outdir, f"2_oxygen_{phase.name}", history)
        set_element_flags(phase, {"O"}, " ")

    # Settle the independently supported phase terms and Uiso values.
    activate_supported_terms(project, hist)
    run(project, args.outdir, "3_supported_terms", history, twice=True)

    # Reconcile the common instrument profile with the accepted phase profiles.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for name, lo, hi in (("U", 2.0, 40.0), ("W", 2.0, 40.0),
                         ("X", 0.1, 6.0), ("SH/L", 0.005, 0.10)):
        project.set_Controls("parmMin", lo, f":0:{name}")
        project.set_Controls("parmMax", hi, f":0:{name}")
    run(project, args.outdir, "4_common_profile", history, twice=True)
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})

    # Settle peak positions once after the line-shape update.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run(project, args.outdir, "5_cells", history, twice=True)
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})

    # Final full-grid intensity/profile convergence with cells and calibration fixed.
    run(project, args.outdir, "6_final", history, twice=True)
    project.save(str(args.outdir / "refined.gpx"))
    (args.outdir / "history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
