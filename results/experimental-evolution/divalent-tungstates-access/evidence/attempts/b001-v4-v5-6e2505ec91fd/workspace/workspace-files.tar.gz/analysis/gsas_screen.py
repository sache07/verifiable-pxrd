#!/usr/bin/env python3
"""Build and perform a conservative GSAS-II screening refinement.

Run this only with the GSAS-II Python interpreter.  It is intentionally
limited to background, scales, specimen shift, unit cells and a common
instrument profile so that alternative phase/reference inventories can be
compared before atomic or phase-specific profile parameters are introduced.
"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_inputs(pattern: Path, outdir: Path) -> tuple[Path, Path, np.ndarray, np.ndarray]:
    data = np.loadtxt(pattern, delimiter=",", skiprows=1)
    x, y = data.T
    xye = outdir / "observed.xye"
    np.savetxt(xye, np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))), fmt="%.8f %.8f %.8f")
    inst = outdir / "instrument.instprm"
    inst.write_text(
        "# GSAS-II laboratory Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return xye, inst, x, y


def initial_background(x: np.ndarray, y: np.ndarray, degree: int = 12) -> list[float]:
    # A low running percentile follows the smooth floor while rejecting Bragg peaks.
    baseline = percentile_filter(y, percentile=12, size=401, mode="nearest")
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(t, baseline, degree - 1).tolist()


def snapshot(project: G2.G2Project, outdir: Path, label: str) -> dict:
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    hist = project.histogram(0)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    cells = {}
    scales = {}
    for phase in project.phases():
        cells[phase.name] = [float(v) for v in phase.data["General"]["Cell"][1:]]
        scales[phase.name] = float(phase.data["Histograms"][hist.name]["Scale"][0])
    return {
        "label": label,
        "residuals": {
            k: float(v) for k, v in hist.residuals.items()
            if np.isscalar(v) and isinstance(v, (int, float, np.number))
        },
        "Rvals": {
            k: float(v) for k, v in rvals.items()
            if np.isscalar(v) and isinstance(v, (int, float, np.number))
        },
        "cells": cells,
        "scales": scales,
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
        "instrument": {
            k: float(hist.InstrumentParameters[k][1])
            for k in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
        },
    }


def refine(project: G2.G2Project, outdir: Path, label: str, history: list[dict]) -> None:
    project.refine()
    info = snapshot(project, outdir, label)
    history.append(info)
    print(json.dumps({"step": label, "residuals": info["residuals"], "shift_um": info["shift_um"],
                      "zero_deg": info["zero_deg"], "instrument": info["instrument"]}, sort_keys=True))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", required=True, type=Path)
    parser.add_argument("--pattern", default=Path("inputs/pattern.csv"), type=Path)
    parser.add_argument("--phases", nargs="+", required=True, help="COD IDs")
    parser.add_argument("--names", nargs="+", required=True)
    parser.add_argument("--shift", type=float, default=750.0, help="initial specimen shift in micrometres")
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()
    if len(args.phases) != len(args.names):
        raise SystemExit("--phases and --names must have the same length")

    args.outdir.mkdir(parents=True, exist_ok=True)
    xye, instfile, x, y = write_inputs(args.pattern, args.outdir)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(args.outdir / "model.gpx"))
    phases = []
    for cod_id, name in zip(args.phases, args.names):
        source = cod_path(cod_id)
        if not source.exists():
            raise FileNotFoundError(source)
        phases.append(project.add_phase(str(source), phasename=name, fmthint="CIF"))
    hist = project.add_powder_histogram(str(xye), str(instfile), phases=phases, fmthint="xye")
    hist.data["data"][0]["wtFactor"] = 1.0
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"][1] = False
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [float(args.shift), False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({
        "Limits": [float(x[0]), float(x[-1])],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 12,
            "coeffs": initial_background(x, y, 12),
            "refine": False,
        },
    })
    # Equal initial crystalline mass fractions; a common multiplier is estimated below.
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0 / float(phase.data["General"]["Mass"]), False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]

    project.set_Controls("cycles", 0)
    project.save()
    project.refine()
    signal = np.asarray(hist.getdata("Ycalc")) - np.asarray(hist.getdata("Background"))
    observed_net = y - percentile_filter(y, percentile=12, size=401, mode="nearest")
    denom = max(float(np.percentile(signal, 99.95)), 1e-9)
    multiplier = max(float(np.percentile(observed_net, 99.95)), 100.0) / denom
    for phase in phases:
        phase.data["Histograms"][hist.name]["Scale"][0] *= multiplier

    history: list[dict] = [snapshot(project, args.outdir, "00_initial")]
    project.set_Controls("cycles", args.cycles)

    # Stage 1: only the linear intensity problem.
    hist.set_refinements({"Background": True})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    refine(project, args.outdir, "01_scale_background", history)

    # Stage 2: whole-specimen peak displacement.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, args.outdir, "02_shift", history)

    # Stage 3: symmetry-allowed cell metrics. This also separates cell mismatch
    # from the common specimen displacement.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, args.outdir, "03_cells", history)
    refine(project, args.outdir, "04_cells_converged", history)

    # Stage 4: common instrumental broadening only. V, Y and Z stay at zero to
    # avoid an underdetermined profile during inventory screening.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, args.outdir, "05_instrument", history)
    refine(project, args.outdir, "06_instrument_converged", history)

    project.save(str(args.outdir / "screen.gpx"))
    (args.outdir / "history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
