#!/usr/bin/env python3
"""Test the three supported uniaxial WO3 microstrain directions."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = [[0, 0, 1], [1, 0, 0], [0, 1, 0]]


def clear_frozen(project):
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("--outdir", required=True, type=Path)
    ap.add_argument("--cycles", type=int, default=8)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    results = []

    for axis in AXES:
        tag = "".join(str(v) for v in axis)
        project = G2.G2Project(gpxfile=str(args.input))
        outfile = args.outdir / f"wo3_strain_{tag}.gpx"
        project.save(str(outfile))
        project.index_ids()
        project.set_Controls("cycles", args.cycles)
        clear_frozen(project)
        hist = project.histogram(0)
        hist.clear_refinements({
            "Instrument Parameters": ["U", "V", "W", "X", "Y", "Z", "SH/L", "Zero", "Polariz."],
            "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        })
        for phase in project.phases():
            phase.clear_refinements({"Cell": True})
            phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
            for atom in phase.atoms():
                atom.refinement_flags = " "

        phase = project.phase("WO3")
        hap = phase.data["Histograms"][hist.name]
        start = float(hap["Mustrain"][1][0])
        phase.setSampleProfile(hist, "microstrain", "uniaxial", start, start, axis)
        phase.set_HAP_refinements({
            "Mustrain": {"type": "uniaxial", "direction": axis,
                          "refine": True}
        }, [hist])
        for suffix in ("i", "a"):
            var = f"{phase.id}:0:Mustrain;{suffix}"
            project.set_Controls("parmMin", 300.0, var)
            project.set_Controls("parmMax", 8000.0, var)

        project.refine()
        project.refine()
        project.save()
        result = {
            "axis": axis,
            "equatorial_ppm": float(hap["Mustrain"][1][0]),
            "axial_ppm": float(hap["Mustrain"][1][1]),
            "Rwp": float(hist.residuals["wR"]),
            "GOF": float(project.data["Covariance"]["data"]["Rvals"]["GOF"]),
            "frozen": project.get_Frozen(),
            "project": str(outfile),
        }
        results.append(result)
        print(json.dumps(result, sort_keys=True))

    (args.outdir / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
