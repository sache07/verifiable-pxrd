#!/usr/bin/env python3
"""Test one bounded isotropic microstrain term at a time from one checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_frozen(project):
    controls = project.data["Controls"]["data"]
    controls.setdefault("parmFrozen", {})["FrozenList"] = []


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("--outdir", required=True, type=Path)
    ap.add_argument("--cycles", type=int, default=8)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    probe = G2.G2Project(gpxfile=str(args.input))
    names = [p.name for p in probe.phases()]
    results = []
    for index, name in enumerate(names):
        project = G2.G2Project(gpxfile=str(args.input))
        outfile = args.outdir / f"strain_{index}_{name}.gpx"
        project.save(str(outfile))
        project.set_Controls("cycles", args.cycles)
        clear_frozen(project)
        hist = project.histogram(0)
        hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
        for phase in project.phases():
            phase.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
        var = f"{phase.id}:0:Mustrain;i"
        project.set_Controls("parmMin", 0.0, var)
        project.set_Controls("parmMax", 12000.0, var)
        project.refine()
        project.refine()
        project.save()
        frozen = project.get_Frozen()
        value = float(hap["Mustrain"][1][0])
        result = {
            "phase": name,
            "Rwp": float(hist.residuals["wR"]),
            "value_ppm": value,
            "frozen": frozen,
            "supported": var not in frozen and value > 1.0,
            "project": str(outfile),
        }
        results.append(result)
        print(json.dumps(result, sort_keys=True))
    (args.outdir / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
