#!/usr/bin/env python3
"""Assemble the supported isotropic profile and phase-wide Uiso terms."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


UISO_START = {
    "CuWO4": 0.00377,
    "Cu3WO6": 0.00128,
    "WO3": 0.00727,
    "CuO": 0.00273,
}


def clear_frozen(project):
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []


def info(project, label):
    hist = project.histogram(0)
    return {
        "label": label,
        "Rwp": float(hist.residuals["wR"]),
        "GOF": float(project.data["Covariance"]["data"]["Rvals"]["GOF"]),
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
        "instrument": {k: float(hist.InstrumentParameters[k][1])
                       for k in ("U", "W", "X", "SH/L", "Polariz.")},
        "phases": {
            phase.name: {
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
                "scale": float(phase.data["Histograms"][hist.name]["Scale"][0]),
                "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "mustrain_ppm": float(phase.data["Histograms"][hist.name]["Mustrain"][1][0]),
                "uiso_A2": [float(atom.uiso) for atom in phase.atoms()],
            } for phase in project.phases()
        },
        "frozen": project.get_Frozen(),
    }


def checkpoint(project, outdir, label, history):
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    x = info(project, label)
    history.append(x)
    print(json.dumps({"step": label, "Rwp": x["Rwp"], "GOF": x["GOF"],
                      "instrument": x["instrument"], "frozen": x["frozen"]}, sort_keys=True))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("--outdir", required=True, type=Path)
    ap.add_argument("--cycles", default=8, type=int)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input))
    project.save(str(args.outdir / "working.gpx"))
    project.index_ids()
    project.set_Controls("cycles", args.cycles)
    clear_frozen(project)
    hist = project.histogram(0)
    history = []

    # Remove stale/unsupported profile flags, then activate only terms supported
    # by independent one-at-a-time branches.
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])
        for atom in phase.atoms():
            atom.refinement_flags = " "
    cuwo4 = project.phase("CuWO4")
    wo3 = project.phase("WO3")
    cuwo4.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    wo3.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    project.set_Controls("parmMin", 0.02, f"{cuwo4.id}:0:Size;i")
    project.set_Controls("parmMax", 5.0, f"{cuwo4.id}:0:Size;i")
    project.set_Controls("parmMin", 0.0, f"{wo3.id}:0:Mustrain;i")
    project.set_Controls("parmMax", 12000.0, f"{wo3.id}:0:Mustrain;i")

    # One isotropic displacement parameter per phase, shared by all sites.
    for phase in project.phases():
        vars_ = []
        start = UISO_START[phase.name]
        for atom_index, atom in enumerate(phase.atoms()):
            atom.uiso = start
            atom.refinement_flags = "U"
            var = f"{phase.id}::AUiso:{atom_index}"
            vars_.append(var)
            project.set_Controls("parmMin", 0.0, var)
            project.set_Controls("parmMax", 0.05, var)
        if len(vars_) > 1:
            project.add_EquivConstr(vars_, reloadIdx=False)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    checkpoint(project, args.outdir, "00_assembled", history)
    project.refine()
    checkpoint(project, args.outdir, "01_terms", history)
    project.refine()
    checkpoint(project, args.outdir, "02_terms_converged", history)

    # Settle unit cells once more against the now-correct peak shapes, with the
    # strongly correlated zero/height calibration held at its physical checkpoint.
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine()
    checkpoint(project, args.outdir, "03_cells", history)
    project.refine()
    checkpoint(project, args.outdir, "04_cells_converged", history)
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})

    project.save(str(args.outdir / "assembled.gpx"))
    (args.outdir / "history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
