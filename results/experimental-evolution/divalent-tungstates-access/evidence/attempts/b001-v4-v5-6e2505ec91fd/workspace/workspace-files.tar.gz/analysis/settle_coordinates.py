#!/usr/bin/env python3
"""Converge local coordinate shifts from the physical final checkpoint."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_frozen(project):
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []


def state(project, label):
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    return {
        "label": label,
        "Rwp": float(hist.residuals["wR"]),
        "Rp": float(hist.residuals["R"]),
        "GOF": float(cov["Rvals"]["GOF"]),
        "max_shift_esd": float(cov["Rvals"].get("Max shft/sig", 0.0)),
        "frozen": project.get_Frozen(),
        "coordinates": {
            p.name: {a.label: [float(v) for v in a.coordinates] for a in p.atoms()}
            for p in project.phases()
        },
    }


def checkpoint(project, outdir, label, history):
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    item = state(project, label)
    history.append(item)
    print(json.dumps({k: item[k] for k in ("label", "Rwp", "GOF", "max_shift_esd", "frozen")},
                     sort_keys=True), flush=True)


def run(project, outdir, label, history):
    project.refine()
    project.refine()
    checkpoint(project, outdir, label, history)


def clear_nonlinear_flags(project, hist):
    hist.clear_refinements({
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "Z", "SH/L", "Zero", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        for atom in phase.atoms():
            atom.refinement_flags = " "


def coordinate_delta_bounds(project, phase, width=0.015):
    # Despite the ``dA`` variable names, GSAS-II applies these limits to the
    # absolute fractional coordinates, not to a zero-centered increment.
    for i, atom in enumerate(phase.atoms()):
        for axis, value in zip("xyz", atom.coordinates):
            project.set_Controls("parmMin", float(value) - width,
                                 f"{phase.id}::dA{axis}:{i}")
            project.set_Controls("parmMax", float(value) + width,
                                 f"{phase.id}::dA{axis}:{i}")


def set_elements(phase, elements, flag):
    for atom in phase.atoms():
        if atom.element in elements:
            atom.refinement_flags = flag


def reactivate_final_terms(project, hist):
    cuwo4 = project.phase("CuWO4")
    cuwo4.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    wo3 = project.phase("WO3")
    wo3.set_HAP_refinements({
        "Mustrain": {"type": "uniaxial", "direction": [0, 0, 1], "refine": True}
    }, [hist])
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "U"
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("--outdir", required=True, type=Path)
    ap.add_argument("--cycles", type=int, default=8)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input))
    project.save(str(args.outdir / "working.gpx"))
    project.index_ids()
    project.set_Controls("cycles", args.cycles)
    clear_frozen(project)
    hist = project.histogram(0)
    clear_nonlinear_flags(project, hist)
    history = []
    checkpoint(project, args.outdir, "00_input", history)

    for phase in project.phases():
        coordinate_delta_bounds(project, phase)
        set_elements(phase, {"Cu", "W"}, "X")
        run(project, args.outdir, f"1_heavy_{phase.name}", history)
        set_elements(phase, {"Cu", "W"}, " ")

    for phase in project.phases():
        coordinate_delta_bounds(project, phase)
        set_elements(phase, {"O"}, "X")
        run(project, args.outdir, f"2_oxygen_{phase.name}", history)
        set_elements(phase, {"O"}, " ")

    reactivate_final_terms(project, hist)
    run(project, args.outdir, "3_final_settle", history)
    project.save(str(args.outdir / "settled.gpx"))
    (args.outdir / "history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
