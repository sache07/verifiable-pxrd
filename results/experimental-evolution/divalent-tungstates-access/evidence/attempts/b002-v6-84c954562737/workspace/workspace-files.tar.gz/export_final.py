#!/usr/bin/env python3
"""Export all submission artifacts from the exact final GSAS-II project."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"
REPLAY = ROOT / ".tmp" / "final_replay"

PHASES = [
    {
        "project_name": "MnWO4_wolframite_1520200",
        "name": "MnWO4 (wolframite)",
        "formula": "MnWO4",
        "space_group": "P 2/c",
        "cif_path": "MnWO4_wolframite.cif",
    },
    {
        "project_name": "WO3_physical_2311041",
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "space_group": "P 21/c",
        "cif_path": "WO3_monoclinic.cif",
    },
    {
        "project_name": "Mn3O4_tetragonal_1011262",
        "name": "Mn3O4 (tetragonal hausmannite)",
        "formula": "Mn3O4",
        "space_group": "I 41/amd",
        "cif_path": "Mn3O4_tetragonal.cif",
    },
    {
        "project_name": "MnO_rocksalt_1514231",
        "name": "MnO (rocksalt)",
        "formula": "MnO",
        "space_group": "F m -3 m",
        "cif_path": "MnO_rocksalt.cif",
    },
    {
        "project_name": "Mn3O4_orthorhombic_Mn3O4_Pbcm_indexed",
        "name": "Mn3O4 (orthorhombic post-spinel model)",
        "formula": "Mn3O4",
        "space_group": "P b c m",
        "cif_path": "Mn3O4_orthorhombic.cif",
    },
]


def main():
    project = G2.G2Project(gpxfile=str(PROJECT))
    hist = project.histograms()[0]
    if hist.name != "PWDR pattern.csv":
        raise RuntimeError(f"unexpected refinement histogram: {hist.name}")

    fractions = hist.ComputeMassFracs()
    project_names = {phase.name for phase in project.phases()}
    expected_names = {row["project_name"] for row in PHASES}
    if project_names != expected_names:
        raise RuntimeError(f"phase inventory mismatch: {project_names ^ expected_names}")
    for row in PHASES:
        project.phase(row["project_name"]).export_CIF(str(ROOT / row["cif_path"]))

    replay_report = json.loads((REPLAY / "replay.json").read_text())
    if replay_report.get("status") != "replayed" or replay_report.get("profile_review_flags"):
        raise RuntimeError(f"final replay did not pass: {replay_report}")
    project_sha = hashlib.sha256(PROJECT.read_bytes()).hexdigest()
    if replay_report["project_sha256"] != project_sha:
        raise RuntimeError("replay was not generated from the submitted final.gpx")

    arrays = np.load(REPLAY / "prediction.npz")
    x = np.asarray(arrays["x"], float)
    observed = np.asarray(arrays["observed"], float)
    calculated = np.asarray(arrays["predicted"], float)
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.6f", "%.10f", "%.10f"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    full_rwp = 100.0 * np.sqrt(
        np.sum(weights * (observed - calculated) ** 2)
        / np.sum(weights * observed ** 2)
    )
    full_rp = 100.0 * np.sum(np.abs(observed - calculated)) / np.sum(observed)
    mask = (x >= 10.0) & (x <= 100.0)
    range_rwp = 100.0 * np.sqrt(
        np.sum(weights[mask] * (observed[mask] - calculated[mask]) ** 2)
        / np.sum(weights[mask] * observed[mask] ** 2)
    )
    rvals = project.data["Covariance"]["data"]["Rvals"]
    result_phases = []
    for row in PHASES:
        fraction, sigma = fractions[row["project_name"]]
        result_phases.append({
            "name": row["name"],
            "formula": row["formula"],
            "space_group": row["space_group"],
            "project_phase_name": row["project_name"],
            "cif_path": row["cif_path"],
            "weight_fraction": float(fraction),
            "weight_fraction_esd": float(sigma),
        })

    result = {
        "schema_version": 1,
        "refinement_histogram": hist.name,
        "gsas_project": "final.gpx",
        "fit_csv": "fit.csv",
        "fraction_basis": (
            "Normalized over the modeled crystalline phases; no amorphous fraction was determined."
        ),
        "phases": result_phases,
        "fit_statistics": {
            "Rwp_percent_full_grid_fresh_replay": float(full_rwp),
            "Rwp_percent_10_to_100_deg_fresh_replay": float(range_rwp),
            "Rwp_percent_GSASII_last_refinement": float(rvals["Rwp"]),
            "Rp_percent_full_grid": float(full_rp),
            "goodness_of_fit_GSASII": float(rvals["GOF"]),
            "chi_squared_GSASII": float(rvals["chisq"]),
            "n_observations_GSASII": int(rvals["Nobs"]),
            "n_variables_last_cycle": int(rvals["Nvars"]),
            "max_shift_over_esd_last_cycle": float(rvals["Max shft/sig"]),
            "project_sha256": project_sha,
            "profile_replay_review_flags": replay_report["profile_review_flags"],
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
