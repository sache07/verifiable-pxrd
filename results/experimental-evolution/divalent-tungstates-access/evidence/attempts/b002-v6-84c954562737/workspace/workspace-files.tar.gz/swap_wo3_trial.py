#!/usr/bin/env python3
"""Replace the nonphysical WO3 reference with one exact-composition trial."""

from __future__ import annotations

import copy
import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


CIF_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)


def cif_path(identifier):
    return CIF_ROOT / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


def histogram(project):
    return max(project.histograms(), key=lambda h: len(h.data["data"][1][0]))


def freeze(project):
    h = histogram(project)
    h.Background[0][1] = False
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in h.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        try:
            phase.clear_refinements({"Cell": True})
        except Exception:
            pass
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        if len(hap["Size"]) > 5:
            hap["Size"][5] = [False] * len(hap["Size"][5])
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def snapshot(project, label, new_name):
    h = histogram(project)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    phase = project.phase(new_name)
    return {
        "stage": label,
        "Rwp_percent": float(h.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "cell": phase.get_cell(),
        "fractions": {k: float(v[0]) for k, v in h.ComputeMassFracs().items()},
    }


def main():
    if len(sys.argv) != 4:
        raise SystemExit("usage: swap_wo3_trial.py SOURCE.gpx OUTPUT.gpx COD_ID")
    source, output, identifier = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    freeze(project)
    h = histogram(project)
    old = project.phase("WO3_1528915")
    old_hap = copy.deepcopy(old.data["Histograms"][h.name])
    old_uiso = 0.003696

    # Constraints referred to the old phase's atom IDs and are unnecessary
    # once all Uiso values are materialized and frozen.
    for scope in ("Hist", "HAP", "Phase", "Global"):
        project.get_Constraints(scope).clear()
    name = f"WO3_physical_{identifier}"
    phase = project.add_phase(
        str(cif_path(identifier)), phasename=name, histograms=[h], fmthint="CIF"
    )
    # Add first so GSAS-II's internal tree-name list remains valid while the
    # importer checks existing names, then remove the superseded phase.
    del project.data["Phases"][old.name]
    next(row for row in project.names if row and row[0] == "Phases").remove(old.name)
    h.data["Reflection Lists"].pop(old.name, None)
    hap = phase.data["Histograms"][h.name]
    hap["Scale"] = [float(old_hap["Scale"][0]), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.5
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 8000.0
    hap["Mustrain"][1][1] = 8000.0
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = old_uiso
        atom.refinement_flags = " "

    project.index_ids()
    pid = int(phase.data["pId"])
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
    cell = phase.get_cell()
    reciprocal = G2lat.cell2A([
        cell["length_a"], cell["length_b"], cell["length_c"],
        cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
    ])
    for index, value in enumerate(reciprocal):
        span = max(0.01 * abs(float(value)), 0.0003)
        project.set_Controls("parmMin", float(value) - span, variable=f"{pid}::A{index}")
        project.set_Controls("parmMax", float(value) + span, variable=f"{pid}::A{index}")

    # Refine only the replacement cell plus common linear terms and shift.
    freeze(project)
    h.Background[0][1] = True
    h.SampleParameters["Shift"][1] = True
    for item in project.phases():
        item.data["Histograms"][h.name]["Scale"][1] = True
    phase.set_refinements({"Cell": True, "LeBail": False})
    rows = []
    for pass_index in range(4):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 12)
        project.save()
        project.refine(makeBack=False)
        project.save()
        row = snapshot(project, f"pass_{pass_index + 1}", name)
        rows.append(row)
        print(json.dumps(row), flush=True)
        maximum = row["max_shift_esd"]
        if row["converged"] and maximum is not None and maximum <= 1.0 and not row["frozen"]:
            break
    freeze(project)
    project.save()
    result = {
        "source": str(source.resolve()),
        "output": str(output.resolve()),
        "reference_id": identifier,
        "stages": rows,
        "final": snapshot(project, "final", name),
    }
    output.with_suffix(".swap.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result["final"]), flush=True)


if __name__ == "__main__":
    main()
