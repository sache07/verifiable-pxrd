#!/usr/bin/env python3
"""Recalculate and settle the accepted five-phase checkpoint.

The script deliberately leaves coordinates and phase-specific line-profile
terms fixed.  It refines only the ordinary linear/background, phase-scale,
cell and specimen-displacement terms and repeats each block until shifts are
small or three passes have completed.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def histogram(project):
    return max(project.histograms(), key=lambda h: len(h.data["data"][1][0]))


def clear_all(project):
    h = histogram(project)
    h.Background[0][1] = False
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in h.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        try:
            phase.clear_refinements({"Cell": True})
        except Exception:
            pass
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        if len(hap["Size"]) > 5:
            hap["Size"][5] = [False] * len(hap["Size"][5])
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def enable_common(project, cells=False, shift=False):
    h = histogram(project)
    h.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][h.name]["Scale"][1] = True
        if cells:
            phase.set_refinements({"Cell": True})
    if shift:
        h.SampleParameters["Shift"][1] = True


def record(project, stage):
    h = histogram(project)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": stage,
        "Rwp_percent": float(h.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "shift_um": float(h.SampleParameters["Shift"][0]),
        "fractions": {k: float(v[0]) for k, v in h.ComputeMassFracs().items()},
    }


def run_passes(project, label, rows, passes=3, cycles=10):
    for index in range(passes):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", cycles)
        project.save()
        project.refine(makeBack=False)
        project.save()
        row = record(project, f"{label}_{index + 1}")
        rows.append(row)
        print(json.dumps(row), flush=True)
        maximum = row["max_shift_esd"]
        if row["converged"] and maximum is not None and maximum <= 1.0 and not row["frozen"]:
            break


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: settle_physical_checkpoint.py SOURCE.gpx OUTPUT.gpx")
    source, output = map(Path, sys.argv[1:])
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    project.index_ids()
    h = histogram(project)
    # Physical bounds fixed by the laboratory protocol.
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    for phase in project.phases():
        project.set_Controls("parmMin", 0.0, variable=f"{phase.data['pId']}:0:Scale")

    rows = []
    clear_all(project)
    enable_common(project)
    run_passes(project, "scale_background", rows)

    clear_all(project)
    enable_common(project, cells=True)
    run_passes(project, "cell_scale_background", rows)

    clear_all(project)
    enable_common(project, cells=True, shift=True)
    run_passes(project, "cell_scale_background_shift", rows)

    clear_all(project)
    project.save()
    summary = {
        "source": str(source.resolve()),
        "output": str(output.resolve()),
        "stages": rows,
        "final": record(project, "final"),
    }
    output.with_suffix(".settle.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary["final"]), flush=True)


if __name__ == "__main__":
    main()
