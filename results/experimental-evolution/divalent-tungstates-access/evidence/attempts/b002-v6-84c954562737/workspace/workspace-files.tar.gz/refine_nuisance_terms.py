#!/usr/bin/env python3
"""Fit small bounded instrument/sample nuisance branches without cell motion."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


BOUNDS = {
    ":0:Polariz.": (0.5, 1.0),
    ":0:SH/L": (0.005, 0.10),
    ":0:SurfRoughA": (0.05, 0.60),
    ":0:SurfRoughB": (0.02, 0.50),
    ":0:Shift": (-800.0, 800.0),
}


def histogram(project):
    return max(project.histograms(), key=lambda h: len(h.data["data"][1][0]))


def freeze(project):
    h = histogram(project)
    h.Background[0][1] = False
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in h.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        try:
            phase.clear_refinements({"Cell": True})
        except Exception:
            pass
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        if len(hap["Size"]) > 5:
            hap["Size"][5] = [False] * len(hap["Size"][5])
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def snapshot(project, label):
    h = histogram(project)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": label,
        "Rwp_percent": float(h.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "polarization": float(h.InstrumentParameters["Polariz."][1]),
        "SH_L": float(h.InstrumentParameters["SH/L"][1]),
        "surface_roughness": [
            float(h.SampleParameters["SurfRoughA"][0]),
            float(h.SampleParameters["SurfRoughB"][0]),
        ],
        "shift_um": float(h.SampleParameters["Shift"][0]),
        "fractions": {k: float(v[0]) for k, v in h.ComputeMassFracs().items()},
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--mode", choices=("polar", "shl", "both", "roughness"), required=True)
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    freeze(project)
    project.index_ids()
    for variable, (lower, upper) in BOUNDS.items():
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    h = histogram(project)
    h.Background[0][1] = True
    h.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.data["Histograms"][h.name]["Scale"][1] = True
    if args.mode in {"polar", "both"}:
        h.set_refinements({"Instrument Parameters": ["Polariz."]})
    if args.mode in {"shl", "both"}:
        h.set_refinements({"Instrument Parameters": ["SH/L"]})
    if args.mode == "roughness":
        h.SampleParameters["SurfRoughA"][0] = 0.30
        h.SampleParameters["SurfRoughB"][0] = 0.10
        h.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})

    rows = []
    for pass_index in range(3):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        row = snapshot(project, f"pass_{pass_index + 1}")
        rows.append(row)
        print(json.dumps(row), flush=True)
        maximum = row["max_shift_esd"]
        if row["converged"] and maximum is not None and maximum <= 1.0 and not row["frozen"]:
            break
    freeze(project)
    project.save()
    result = {
        "source": str(args.source.resolve()),
        "output": str(args.output.resolve()),
        "mode": args.mode,
        "stages": rows,
        "final": snapshot(project, "final"),
    }
    args.output.with_suffix(".nuisance.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result["final"]), flush=True)


if __name__ == "__main__":
    main()
