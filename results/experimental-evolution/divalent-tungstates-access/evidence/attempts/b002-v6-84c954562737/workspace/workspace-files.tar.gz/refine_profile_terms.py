#!/usr/bin/env python3
"""Refine bounded instrument and phase broadening terms for trial branches."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from GSASII import GSASIIscriptable as G2


LAB_BOUNDS = {
    ":0:U": (0.0, 40.0),
    ":0:W": (2.0, 40.0),
    ":0:X": (0.1, 6.0),
    ":0:SH/L": (0.005, 0.10),
    ":0:Polariz.": (0.5, 1.0),
    ":0:Shift": (-800.0, 800.0),
}


def histogram(project):
    return max(project.histograms(), key=lambda h: len(h.data["data"][1][0]))


def clear_flags(project):
    h = histogram(project)
    h.Background[0][1] = False
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in h.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        try:
            phase.clear_refinements({"Cell": True})
        except Exception:
            pass
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        if len(hap["Size"]) > 5:
            hap["Size"][5] = [False] * len(hap["Size"][5])
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def install_bounds(project):
    project.index_ids()
    for variable, (lower, upper) in LAB_BOUNDS.items():
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    h = histogram(project)
    inst = h.InstrumentParameters
    # Bring a value left outside the protocol by an earlier unconstrained trial
    # onto the nearest physical boundary before activating it.
    for key in ("U", "W", "X"):
        lo, hi = LAB_BOUNDS[f":0:{key}"]
        inst[key][1] = min(max(float(inst[key][1]), lo), hi)
    for phase in project.phases():
        pid = int(phase.data["pId"])
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")


def enable(project, profile_indices, instrument=True, cells=False):
    h = histogram(project)
    h.Background[0][1] = True
    h.set_refinements({"Sample Parameters": ["Shift"]})
    if instrument:
        h.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    for index, phase in enumerate(project.phases()):
        phase.data["Histograms"][h.name]["Scale"][1] = True
        phase.set_refinements({"LeBail": False})
        if cells:
            phase.set_refinements({"Cell": True})
        if index in profile_indices:
            phase.set_HAP_refinements({
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }, [h])


def snapshot(project, label):
    h = histogram(project)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": label,
        "Rwp_percent": float(h.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "instrument": {k: float(h.InstrumentParameters[k][1]) for k in ("U", "W", "X", "SH/L", "Polariz.")},
        "shift_um": float(h.SampleParameters["Shift"][0]),
        "profiles": {
            p.name: {
                "size_um": float(p.data["Histograms"][h.name]["Size"][1][0]),
                "microstrain_ppm": float(p.data["Histograms"][h.name]["Mustrain"][1][0]),
            }
            for p in project.phases()
        },
        "fractions": {k: float(v[0]) for k, v in h.ComputeMassFracs().items()},
    }


def disable_frozen_parameters(project, frozen):
    """Keep a physical bound hit fixed for the remaining settle passes."""
    h = histogram(project)
    for variable in map(str, frozen):
        match = re.fullmatch(r":0:(U|W|X)", variable)
        if match:
            h.InstrumentParameters[match.group(1)][2] = False
            continue
        match = re.fullmatch(r"(\d+):0:(Size|Mustrain);i", variable)
        if match:
            phase = next(p for p in project.phases() if int(p.data["pId"]) == int(match.group(1)))
            hap = phase.data["Histograms"][h.name]
            hap[match.group(2)][2][0] = False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--mode", choices=("instrument", "dominant", "all"), default="dominant")
    parser.add_argument("--phases", help="comma-separated zero-based phase indices")
    parser.add_argument("--fixed-instrument", action="store_true")
    parser.add_argument("--cells", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    clear_flags(project)
    install_bounds(project)
    indices = {"instrument": [], "dominant": [0, 1], "all": list(range(len(project.phases())))}[args.mode]
    if args.phases is not None:
        indices = [int(item) for item in args.phases.split(",") if item.strip()]
    enable(project, indices, instrument=not args.fixed_instrument, cells=args.cells)

    rows = []
    for pass_index in range(4):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 12)
        project.save()
        project.refine(makeBack=False)
        project.save()
        row = snapshot(project, f"pass_{pass_index + 1}")
        rows.append(row)
        print(json.dumps(row), flush=True)
        disable_frozen_parameters(project, row["frozen"])
        maximum = row["max_shift_esd"]
        if row["converged"] and maximum is not None and maximum <= 1.0 and not row["frozen"]:
            break

    clear_flags(project)
    project.save()
    summary = {
        "source": str(args.source.resolve()),
        "output": str(args.output.resolve()),
        "mode": args.mode,
        "stages": rows,
        "final": snapshot(project, "final"),
    }
    args.output.with_suffix(".profile.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary["final"]), flush=True)


if __name__ == "__main__":
    main()
