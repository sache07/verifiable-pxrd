#!/usr/bin/env python3
"""Normalize and refine one bounded isotropic displacement value per phase."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def histogram(project):
    return max(project.histograms(), key=lambda h: len(h.data["data"][1][0]))


def clear_flags(project):
    h = histogram(project)
    h.Background[0][1] = False
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in h.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        try:
            phase.clear_refinements({"Cell": True})
        except Exception:
            pass
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        if len(hap["Size"]) > 5:
            hap["Size"][5] = [False] * len(hap["Size"][5])
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def normalize_uiso(project, value=0.005):
    """Match the registered-model convention used for case generation."""
    project.index_ids()
    for phase in project.phases():
        pid = int(phase.data["pId"])
        variables = []
        for index, atom in enumerate(phase.atoms()):
            # GSAS-II offers no setter for I/A; edit the documented atom record.
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = float(value)
            variables.append(f"{pid}::AUiso:{index}")
            project.set_Controls("parmMin", 0.003, variable=variables[-1])
            project.set_Controls("parmMax", 0.020, variable=variables[-1])
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)


def snapshot(project, label):
    h = histogram(project)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": label,
        "Rwp_percent": float(h.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "uiso_A2": {p.name: float(p.atoms()[0].uiso) for p in project.phases()},
        "fractions": {k: float(v[0]) for k, v in h.ComputeMassFracs().items()},
    }


def synchronize_uiso(project):
    """Materialize equivalent dependent values in the saved atom records.

    GSAS-II can leave dependent atom records at the unconstrained trial value
    when the independent Uiso is clipped at a bound.  Replay reads saved atoms,
    so copy the bounded master value explicitly.
    """
    changed = False
    for phase in project.phases():
        value = min(max(float(phase.atoms()[0].uiso), 0.003), 0.020)
        for atom in phase.atoms():
            if float(atom.uiso) != value:
                changed = True
            atom.uiso = value
    return changed


def deactivate_bound_uiso(project, frozen):
    pids = set()
    for variable in map(str, frozen):
        match = re.fullmatch(r"(\d+)::AUiso:\d+", variable)
        if match:
            pids.add(int(match.group(1)))
    for phase in project.phases():
        if int(phase.data["pId"]) in pids:
            for atom in phase.atoms():
                atom.refinement_flags = " "


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phases", default="0,1")
    args = parser.parse_args()
    active = {int(item) for item in args.phases.split(",") if item.strip()}
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    clear_flags(project)
    # Remove only stale user constraints; the source checkpoint has none.
    for scope in ("Hist", "HAP", "Phase", "Global"):
        project.get_Constraints(scope).clear()
    normalize_uiso(project)
    h = histogram(project)
    h.Background[0][1] = True
    h.SampleParameters["Shift"][1] = True
    for index, phase in enumerate(project.phases()):
        phase.data["Histograms"][h.name]["Scale"][1] = True
        if index in active:
            for atom in phase.atoms():
                atom.refinement_flags = "U"

    rows = []
    for pass_index in range(4):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        frozen = list(project.get_Frozen())
        synchronize_uiso(project)
        deactivate_bound_uiso(project, frozen)
        project.save()
        row = snapshot(project, f"pass_{pass_index + 1}")
        rows.append(row)
        print(json.dumps(row), flush=True)
        maximum = row["max_shift_esd"]
        if row["converged"] and maximum is not None and maximum <= 1.0 and not row["frozen"]:
            break

    # Recompute scales/background after materializing all dependent Uiso values.
    clear_flags(project)
    h = histogram(project)
    h.Background[0][1] = True
    h.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.data["Histograms"][h.name]["Scale"][1] = True
    project.set_Controls("cycles", 10)
    project.save()
    project.refine(makeBack=False)
    synchronize_uiso(project)
    rows.append(snapshot(project, "synchronized_settle"))
    print(json.dumps(rows[-1]), flush=True)
    clear_flags(project)
    project.save()
    result = {
        "source": str(args.source.resolve()),
        "output": str(args.output.resolve()),
        "active_phases": sorted(active),
        "stages": rows,
        "final": snapshot(project, "final"),
    }
    args.output.with_suffix(".uiso.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result["final"]), flush=True)


if __name__ == "__main__":
    main()
