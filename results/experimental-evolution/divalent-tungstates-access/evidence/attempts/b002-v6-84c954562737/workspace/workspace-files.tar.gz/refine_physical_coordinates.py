#!/usr/bin/env python3
"""Conservative phasewise coordinate refinement after a rejected polish branch."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIIstrMain as G2st


WINDOW_A = 0.10
COORD_RE = re.compile(r"^(\d+)::dA[xyz]:(\d+)$")


def histogram(project):
    return max(project.histograms(), key=lambda h: len(h.data["data"][1][0]))


def freeze(project):
    h = histogram(project)
    h.Background[0][1] = False
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in h.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        try:
            phase.clear_refinements({"Cell": True})
        except Exception:
            pass
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        if len(hap["Size"]) > 5:
            hap["Size"][5] = [False] * len(hap["Size"][5])
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def enable_common(project):
    h = histogram(project)
    h.Background[0][1] = True
    h.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.data["Histograms"][h.name]["Scale"][1] = True


def install_bounds(project, source_coordinates):
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    project.index_ids()
    h = histogram(project)
    for phase in project.phases():
        pid = int(phase.data["pId"])
        scale = float(phase.data["Histograms"][h.name]["Scale"][0])
        project.set_Controls("parmMin", max(0.0, 0.25 * scale), variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", max(1.0, 5.0 * scale), variable=f"{pid}:0:Scale")
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(reciprocal):
            span = max(0.01 * abs(float(value)), 0.0003)
            project.set_Controls("parmMin", float(value) - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", float(value) + span, variable=f"{pid}::A{index}")
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        for index, atom in enumerate(phase.atoms()):
            for axis, value, length in zip("xyz", source_coordinates[(pid, index)], lengths):
                half = WINDOW_A / float(length)
                variable = f"{pid}::dA{axis}:{index}"
                project.set_Controls("parmMin", float(value) - half, variable=variable)
                project.set_Controls("parmMax", float(value) + half, variable=variable)


def state(project, label, kind):
    h = histogram(project)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": label,
        "kind": kind,
        "Rwp_percent": float(h.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "fractions": {k: float(v[0]) for k, v in h.ComputeMassFracs().items()},
    }


def run(project, label, kind, rows, cycles):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    row = state(project, label, kind)
    rows.append(row)
    print(json.dumps(row), flush=True)


def geometry(project):
    result = {}
    for phase in project.phases():
        controls, data = phase.InitDisAgl(False)
        controls["Factors"] = [1.25, 0.0]
        _, distances, _ = G2st.RetDistAngle(controls, data, dmin=0.01)
        atoms = phase.atoms()
        minima = {}
        for center, entries in distances.items():
            for row in entries:
                other = int(row[0])
                pair = "-".join(sorted((atoms[center].element, atoms[other].element)))
                distance = float(row[-2])
                minima[pair] = min(minima.get(pair, distance), distance)
        result[phase.name] = {
            "pair_min_A": minima,
            "catastrophic_contacts": [
                [str(a), str(b), float(d)] for a, b, d in phase.ShortDistances(useAll=False)
            ],
        }
    return result


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: refine_physical_coordinates.py SOURCE.gpx OUTPUT.gpx")
    source, output = map(Path, sys.argv[1:])
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    project.index_ids()
    selected_names = {"MnWO4_wolframite_1520200", "WO3_physical_2311041"}
    source_coordinates = {
        (int(phase.data["pId"]), index): tuple(map(float, atom.coordinates))
        for phase in project.phases() for index, atom in enumerate(phase.atoms())
    }
    baseline_geometry = geometry(project)
    freeze(project)
    install_bounds(project, source_coordinates)
    rows = []

    for phase in project.phases():
        if phase.name not in selected_names:
            continue
        for oxygen, label in ((False, "heavy"), (True, "oxygen")):
            freeze(project)
            enable_common(project)
            for atom in phase.atoms():
                is_o = atom.element.strip().upper() == "O"
                atom.refinement_flags = "X" if is_o == oxygen else " "
            run(project, f"{phase.name}_{label}", "coordinates", rows, 8)

    # Record every atom that touched a coordinate bound, restore it exactly,
    # and exclude it from the joint interior settle.
    excluded = set()
    for row in rows:
        for variable in row["frozen"]:
            match = COORD_RE.match(variable)
            if match:
                excluded.add((int(match.group(1)), int(match.group(2))))
    for phase in project.phases():
        pid = int(phase.data["pId"])
        for index, atom in enumerate(phase.atoms()):
            if (pid, index) in excluded:
                atom.coordinates = source_coordinates[(pid, index)]

    for pass_index in range(3):
        freeze(project)
        enable_common(project)
        active = 0
        for phase in project.phases():
            pid = int(phase.data["pId"])
            if phase.name not in selected_names:
                continue
            for index, atom in enumerate(phase.atoms()):
                if (pid, index) not in excluded:
                    atom.refinement_flags = "X"
                    active += 1
        if not active:
            break
        run(project, f"interior_joint_{pass_index + 1}", "coordinates", rows, 8)
        new_hits = set()
        for variable in rows[-1]["frozen"]:
            match = COORD_RE.match(variable)
            if match:
                new_hits.add((int(match.group(1)), int(match.group(2))))
        if new_hits:
            excluded.update(new_hits)
            for phase in project.phases():
                pid = int(phase.data["pId"])
                for index, atom in enumerate(phase.atoms()):
                    if (pid, index) in new_hits:
                        atom.coordinates = source_coordinates[(pid, index)]
        maximum = rows[-1]["max_shift_esd"]
        if rows[-1]["converged"] and maximum is not None and maximum <= 1 and not new_hits:
            break

    for pass_index in range(3):
        freeze(project)
        enable_common(project)
        for phase in project.phases():
            if phase.name in selected_names:
                phase.set_refinements({"Cell": True})
        run(project, f"cell_scale_background_{pass_index + 1}", "settle", rows, 8)
        maximum = rows[-1]["max_shift_esd"]
        if rows[-1]["converged"] and maximum is not None and maximum <= 1 and not rows[-1]["frozen"]:
            break

    freeze(project)
    project.save()
    result = {
        "source": str(source.resolve()),
        "output": str(output.resolve()),
        "selected_phases": sorted(selected_names),
        "excluded_bound_hit_atoms": [list(item) for item in sorted(excluded)],
        "stages": rows,
        "baseline_geometry": baseline_geometry,
        "final_geometry": geometry(project),
        "final": state(project, "final", "complete"),
    }
    output.with_suffix(".physical_coordinates.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result["final"]), flush=True)


if __name__ == "__main__":
    main()
