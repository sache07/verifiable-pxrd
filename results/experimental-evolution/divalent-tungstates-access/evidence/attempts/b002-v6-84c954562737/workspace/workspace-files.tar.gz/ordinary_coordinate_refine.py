#!/usr/bin/env python3
"""Conservative coordinate refinement for the two abundant phases.

This is the ordinary refinement step before the supplied final-stage branch
polisher.  Coordinates are bounded to 0.10 A per Cartesian component around
the accepted reference structures.  Nuisance/profile parameters are frozen;
only coordinates, phase scales and the smooth background are varied, followed
by a cell/scale/background settle.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


WINDOW_A = 0.10


def hist(project):
    return max(project.histograms(), key=lambda h: len(h.data["data"][1][0]))


def clear_flags(project):
    h = hist(project)
    h.Background[0][1] = False
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in h.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        try:
            phase.clear_refinements({"Cell": True})
        except Exception:
            pass
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"].get(h.name)
        if not hap:
            continue
        if isinstance(hap.get("Scale"), list):
            hap["Scale"][1] = False
        for key in ("Size", "Mustrain"):
            value = hap.get(key)
            if isinstance(value, list) and len(value) > 2 and isinstance(value[2], list):
                value[2] = [False] * len(value[2])
            if isinstance(value, list) and len(value) > 5 and isinstance(value[5], list):
                value[5] = [False] * len(value[5])
        if isinstance(hap.get("Pref.Ori."), list):
            hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def enable_scale_background(project):
    h = hist(project)
    h.Background[0][1] = True
    for phase in project.phases():
        hap = phase.data["Histograms"].get(h.name)
        if hap and isinstance(hap.get("Scale"), list):
            hap["Scale"][1] = True


def add_coordinate_bounds(project):
    project.index_ids()
    for phase in project.phases():
        pid = int(phase.data["pId"])
        cell = phase.get_cell()
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        for index, atom in enumerate(phase.atoms()):
            for axis, value, length in zip("xyz", atom.coordinates, lengths):
                half = WINDOW_A / float(length)
                var = f"{pid}::dA{axis}:{index}"
                project.set_Controls("parmMin", float(value) - half, variable=var)
                project.set_Controls("parmMax", float(value) + half, variable=var)


def state(project):
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "Rwp_percent": float(hist(project).get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
    }


def run(project, label, records, cycles=8):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    row = {"stage": label, **state(project)}
    records.append(row)
    print(json.dumps(row), flush=True)


def activate(project, phase_index, oxygen):
    clear_flags(project)
    enable_scale_background(project)
    phase = project.phases()[phase_index]
    for atom in phase.atoms():
        is_o = atom.element.strip().upper() in {"O", "O-2"}
        atom.refinement_flags = "X" if is_o == oxygen else " "


def activate_all_in(project, indices):
    clear_flags(project)
    enable_scale_background(project)
    for index in indices:
        for atom in project.phases()[index].atoms():
            atom.refinement_flags = "X"


def fractions(project):
    return {k: float(v[0]) for k, v in hist(project).ComputeMassFracs().items()}


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: ordinary_coordinate_refine.py SOURCE.gpx OUTPUT.gpx")
    source, output = map(Path, sys.argv[1:])
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    clear_flags(project)
    add_coordinate_bounds(project)
    records = []

    # The first two phases are the abundant MnWO4 product and WO3 precursor.
    for index in (0, 1):
        activate(project, index, oxygen=False)
        run(project, f"phase_{index}_heavy", records, 8)
        activate(project, index, oxygen=True)
        run(project, f"phase_{index}_oxygen", records, 8)
        activate_all_in(project, [index])
        run(project, f"phase_{index}_joint", records, 6)

    activate_all_in(project, [0, 1])
    run(project, "dominant_phases_joint", records, 8)

    clear_flags(project)
    enable_scale_background(project)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run(project, "cell_scale_background_settle", records, 8)
    clear_flags(project)
    project.save()

    report = {
        "source": str(source.resolve()),
        "output": str(output.resolve()),
        "stages": records,
        "final": state(project),
        "fractions": fractions(project),
    }
    output.with_suffix(".ordinary_coordinates.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )
    print(json.dumps(report["final"]), flush=True)


if __name__ == "__main__":
    main()
