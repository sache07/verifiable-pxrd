#!/usr/bin/env python3
"""Build comparable exploratory GSAS-II refinements for candidate inventories."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)


def cif_path(record_id: str) -> Path:
    supplied = Path(record_id)
    if supplied.suffix.lower() == ".cif":
        return supplied.resolve()
    return ROOT / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def clear_frozen(project: G2.G2Project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": label,
        "Rwp_percent": hist.get_wR(),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "scales": {
            phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
            for phase in project.phases()
        },
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "shift_um": hist.SampleParameters["Shift"][0],
    }


def run(project: G2.G2Project, label: str, records: list[dict], cycles: int = 8) -> None:
    clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = state(project, label)
    records.append(record)
    print(json.dumps(record), flush=True)


def set_bounds(project: G2.G2Project) -> None:
    project.save()
    bounds = {
        ":0:U": (0.0, 120.0),
        ":0:W": (0.05, 120.0),
        ":0:X": (0.01, 12.0),
        ":0:SH/L": (0.001, 0.25),
        ":0:Polariz.": (0.0, 1.0),
        ":0:Shift": (-2000.0, 2000.0),
        ":0:Zero": (-0.5, 0.5),
    }
    for variable, (lower, upper) in bounds.items():
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    for phase in project.phases():
        variable = f"{phase.data['pId']}:0:Scale"
        project.set_Controls("parmMin", 0.0, variable=variable)


def build(output: Path, ids: list[str], names: list[str]) -> list[dict]:
    project = G2.G2Project(newgpx=str(output))
    phases = [
        project.add_phase(str(cif_path(record_id)), phasename=name, fmthint="CIF")
        for record_id, name in zip(ids, names)
    ]
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", phases=phases
    )
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [1500.0] + [0.0] * 9,
                "refine": True,
            },
        }
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    starts = [110.0, 25.0, 12.0, 8.0, 8.0, 5.0]
    for phase, scale in zip(phases, starts):
        phase.data["Histograms"][hist.name]["Scale"] = [scale, True]
    set_bounds(project)
    project.save()

    records: list[dict] = []
    run(project, "background_scales", records, 8)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    run(project, "cells", records, 10)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    run(project, "profile_UWX", records, 10)

    # Determine common displacement after individual cells are close, then settle cells.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run(project, "shift", records, 10)
    run(project, "cells_shift_settle", records, 10)

    output.with_suffix(".summary.json").write_text(json.dumps(records, indent=2) + "\n")
    return records


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("ids", nargs="+")
    args = parser.parse_args()
    default_names = [
        "MnWO4_wolframite", "WO3", "Mn3O4_tetragonal", "MnO_rocksalt",
        "Mn3O4_orthorhombic", "phase6",
    ]
    names = [
        f"{name}_{Path(record_id).stem if record_id.endswith('.cif') else record_id}"
        for name, record_id in zip(default_names, args.ids)
    ]
    G2.SetPrintLevel("error")
    build(args.output, args.ids, names)


if __name__ == "__main__":
    main()
