#!/usr/bin/env python3
"""Test one bounded uniaxial microstrain axis for a selected phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def histogram(project):
    return max(project.histograms(), key=lambda h: len(h.data["data"][1][0]))


def freeze(project):
    h = histogram(project)
    h.Background[0][1] = False
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in h.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        try:
            phase.clear_refinements({"Cell": True})
        except Exception:
            pass
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        if len(hap["Size"]) > 5:
            hap["Size"][5] = [False] * len(hap["Size"][5])
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def snapshot(project, label, phase_index):
    h = histogram(project)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    ms = project.phases()[phase_index].data["Histograms"][h.name]["Mustrain"]
    eq, axial = map(float, ms[1][:2])
    return {
        "stage": label,
        "Rwp_percent": float(h.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "phase": project.phases()[phase_index].name,
        "equatorial_ppm": eq,
        "axial_ppm": axial,
        "axial_ratio": axial / eq if eq > 0 else None,
        "axis": list(ms[3]),
        "fractions": {k: float(v[0]) for k, v in h.ComputeMassFracs().items()},
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--axis", required=True)
    args = parser.parse_args()
    axis = [int(item) for item in args.axis.split(",")]
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    freeze(project)
    project.index_ids()
    h = histogram(project)
    h.Background[0][1] = True
    h.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.data["Histograms"][h.name]["Scale"][1] = True
    phase = project.phases()[args.phase]
    ms = phase.data["Histograms"][h.name]["Mustrain"]
    start = min(max(float(ms[1][0]), 300.0), 8000.0)
    ms[0] = "uniaxial"
    ms[1][0] = start
    ms[1][1] = start
    ms[2][0] = True
    ms[2][1] = True
    ms[2][2] = False
    ms[3] = axis
    pid = int(phase.data["pId"])
    for suffix, upper in (("i", 8000.0), ("a", 32000.0)):
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;{suffix}")
        project.set_Controls("parmMax", upper, variable=f"{pid}:0:Mustrain;{suffix}")

    rows = []
    for pass_index in range(3):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        row = snapshot(project, f"pass_{pass_index + 1}", args.phase)
        rows.append(row)
        print(json.dumps(row), flush=True)
        maximum = row["max_shift_esd"]
        if row["converged"] and maximum is not None and maximum <= 1.0 and not row["frozen"]:
            break
    freeze(project)
    project.save()
    result = {
        "source": str(args.source.resolve()),
        "output": str(args.output.resolve()),
        "phase_index": args.phase,
        "axis": axis,
        "stages": rows,
        "final": snapshot(project, "final", args.phase),
    }
    args.output.with_suffix(".uniaxial.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result["final"]), flush=True)


if __name__ == "__main__":
    main()
