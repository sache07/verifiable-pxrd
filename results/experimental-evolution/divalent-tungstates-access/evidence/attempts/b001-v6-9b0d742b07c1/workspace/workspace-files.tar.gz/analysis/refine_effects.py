#!/usr/bin/env python3
"""Refine physically supported specimen/structure effects from a GSAS checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


AXES = {
    "001": [0, 0, 1],
    "100": [1, 0, 0],
    "010": [0, 1, 0],
    "110": [1, 1, 0],
    "111": [1, 1, 1],
}


def histogram(project: G2.G2Project):
    return max(project.histograms(), key=lambda item: len(item.data["data"][1][0]))


def clear_flags(project: G2.G2Project) -> None:
    hist = histogram(project)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"].get(hist.name)
        if not hap:
            continue
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][1] = False
        for value in hap["Babinet"].values():
            value[1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def normalize_histogram_scale(project: G2.G2Project) -> None:
    """Remove exact correlation between histogram scale and all phase scales."""
    hist = histogram(project)
    value = float(hist.SampleParameters["Scale"][0])
    if value <= 0:
        raise ValueError("histogram scale must be positive")
    if abs(value - 1.0) > 1e-12:
        for phase in project.phases():
            hap = phase.data["Histograms"].get(hist.name)
            if hap and hap.get("Use", True):
                hap["Scale"][0] *= value
        hist.SampleParameters["Scale"] = [1.0, False]


def set_bound(project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def configure_common(
    project: G2.G2Project, refine_polarization: bool, fixed_zero: float | None = None
) -> None:
    hist = histogram(project)
    old_zero = float(hist.InstrumentParameters["Zero"][1])
    bounded_zero = float(
        np.clip(old_zero if fixed_zero is None else fixed_zero, -0.25, 0.25)
    )
    old_shift = float(hist.SampleParameters["Shift"][0])
    # If an inherited exploratory zero lies outside the known laboratory range,
    # transfer its mean angular effect to specimen displacement before fitting.
    # The coefficient is the GSAS-II Bragg-Brentano shift at 40 deg 2theta.
    displacement_coefficient = 9e-2 / (np.pi * 200.0) * 4.0 * np.cos(np.deg2rad(20.0))
    adjusted_shift = old_shift + (bounded_zero - old_zero) / displacement_coefficient
    hist.InstrumentParameters["Zero"][1] = bounded_zero
    hist.SampleParameters["Shift"][0] = float(np.clip(adjusted_shift, -900.0, 900.0))
    hist.Background[0][1] = True
    for name in ["W", "X", "SH/L"]:
        hist.InstrumentParameters[name][2] = True
    hist.InstrumentParameters["Zero"][2] = fixed_zero is None
    # The preliminary fit drove U to its physical lower limit; keep it fixed
    # there while the phase microstrains carry sample broadening.
    hist.InstrumentParameters["U"][1] = max(0.0, float(hist.InstrumentParameters["U"][1]))
    hist.InstrumentParameters["U"][2] = False
    hist.InstrumentParameters["Polariz."][2] = bool(refine_polarization)
    hist.SampleParameters["Shift"][1] = True
    # Metadata/lab prior: the unknown angular offset is bounded to +/-0.25 deg.
    set_bound(project, ":0:Zero", -0.25, 0.25)
    set_bound(project, ":0:Shift", -900.0, 900.0)
    set_bound(project, ":0:W", 0.05, 50.0)
    set_bound(project, ":0:X", 0.01, 10.0)
    set_bound(project, ":0:SH/L", 0.002, 0.15)
    set_bound(project, ":0:Polariz.", 0.5, 1.0)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][hist.name]
        # Preserve the selected profile type, refining its active terms.
        if hap["Size"][0] == "isotropic":
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        if hap["Mustrain"][0] == "uniaxial":
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "uniaxial", "refine": True,
                                "direction": hap["Mustrain"][3]}}
            )
        else:
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})


def configure_uiso(project: G2.G2Project, reset: bool) -> None:
    project.index_ids()
    for phase in project.phases():
        pid = int(phase.data["pId"])
        atoms = list(phase.atoms())
        if reset:
            for atom in atoms:
                atom.uiso = 0.010
        for atom in atoms:
            atom.refinement_flags = "U"
        variables = [f"{pid}::AUiso:{index}" for index in range(len(atoms))]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=True)
        for variable in variables:
            set_bound(project, variable, 0.002, 0.030)


def configure_texture(project: G2.G2Project, phase_index: int, axis: list[int]) -> None:
    hist = histogram(project)
    phase = project.phases()[phase_index]
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    set_bound(project, f"{phase.data['pId']}:0:MD", 0.6, 1.6)


def configure_strain(project: G2.G2Project, phase_index: int, axis: list[int]) -> None:
    hist = histogram(project)
    phase = project.phases()[phase_index]
    hap = phase.data["Histograms"][hist.name]
    current = float(hap["Mustrain"][1][0])
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = current
    hap["Mustrain"][1][1] = current
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    hap["Mustrain"][3] = list(axis)
    pid = phase.data["pId"]
    set_bound(project, f"{pid}:0:Mustrain;i", 0.0, 12000.0)
    set_bound(project, f"{pid}:0:Mustrain;a", 0.0, 24000.0)


def configure_roughness(project: G2.G2Project) -> None:
    hist = histogram(project)
    hist.SampleParameters["SurfRoughA"] = [0.30, True]
    hist.SampleParameters["SurfRoughB"] = [0.10, True]
    set_bound(project, ":0:SurfRoughA", 0.05, 0.60)
    set_bound(project, ":0:SurfRoughB", 0.02, 0.50)


def configure_existing_roughness(project: G2.G2Project, fix_a: bool) -> None:
    hist = histogram(project)
    hist.SampleParameters["SurfRoughA"][1] = not fix_a
    hist.SampleParameters["SurfRoughB"][1] = True
    set_bound(project, ":0:SurfRoughA", 0.05, 0.60)
    set_bound(project, ":0:SurfRoughB", 0.02, 0.50)


def run(project: G2.G2Project, label: str, cycles: int = 10) -> dict:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    hist = histogram(project)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "stage": label,
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": None if rvals.get("Max shft/sig") is None else float(rvals["Max shft/sig"]),
        "frozen": [str(item) for item in project.get_Frozen()],
    }
    print(json.dumps(record), flush=True)
    return record


def mass_fractions(project: G2.G2Project) -> dict[str, float]:
    values = histogram(project).ComputeMassFracs()
    return {str(name): float(value[0]) for name, value in values.items()}


def summary(project: G2.G2Project, records: list[dict]) -> dict:
    hist = histogram(project)
    result = {
        "Rwp_percent": float(hist.get_wR()),
        "fractions": mass_fractions(project),
        "records": records,
        "instrument": {key: value for key, value in hist.InstrumentParameters.items()
                       if key in {"Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"}},
        "sample": {key: hist.SampleParameters[key]
                   for key in ["Scale", "Shift", "SurfRoughA", "SurfRoughB"]},
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "atoms": [{"label": atom.label, "element": atom.element,
                       "coordinates": list(atom.coordinates), "uiso": float(atom.uiso),
                       "flags": atom.refinement_flags} for atom in phase.atoms()],
        })
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--fixed-zero", type=float)
    parser.add_argument("--uiso", action="store_true")
    parser.add_argument("--keep-uiso", action="store_true",
                        help="refine current equal Uiso values without resetting or adding constraints")
    parser.add_argument("--texture-ca", choices=AXES)
    parser.add_argument("--texture-wo", choices=AXES)
    parser.add_argument("--strain-ca", choices={"001", "100", "010"})
    parser.add_argument("--strain-wo", choices={"001", "100", "010"})
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--keep-roughness", action="store_true")
    parser.add_argument("--fix-roughness-a", action="store_true")
    parser.add_argument("--passes", type=int, default=3)
    args = parser.parse_args()

    G2.SetPrintLevel("error")
    args.destination.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.source.resolve()),
                           newgpx=str(args.destination.resolve()))
    clear_flags(project)
    normalize_histogram_scale(project)
    configure_common(project, args.polarization, args.fixed_zero)
    if args.uiso:
        configure_uiso(project, reset=True)
    elif args.keep_uiso:
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = "U"
    if args.texture_ca:
        configure_texture(project, 0, AXES[args.texture_ca])
    if args.texture_wo:
        configure_texture(project, 1, AXES[args.texture_wo])
    if args.strain_ca:
        configure_strain(project, 0, AXES[args.strain_ca])
    if args.strain_wo:
        configure_strain(project, 1, AXES[args.strain_wo])
    if args.roughness and args.keep_roughness:
        parser.error("choose either --roughness or --keep-roughness")
    if args.roughness:
        configure_roughness(project)
    elif args.keep_roughness:
        configure_existing_roughness(project, args.fix_roughness_a)

    records = [run(project, f"settle_{index + 1}") for index in range(args.passes)]
    result = summary(project, records)
    args.destination.with_suffix(".json").write_text(
        json.dumps(result, indent=2, default=str) + "\n"
    )
    print(json.dumps({"project": str(args.destination), "Rwp_percent": result["Rwp_percent"]}))


if __name__ == "__main__":
    main()
