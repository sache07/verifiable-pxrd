#!/usr/bin/env python3
"""Screen CaWO4 + WO3 reference combinations with a restrained GSAS-II fit.

This is exploratory analysis code. It creates one independent project per WO3
reference and reports profile statistics and refined specimen/profile values.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(record_id: str) -> Path:
    return COD_ROOT / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def read_pattern(path: Path) -> tuple[np.ndarray, np.ndarray]:
    with path.open(newline="") as stream:
        rows = list(csv.DictReader(stream))
    x = np.array([float(row["two_theta_deg"]) for row in rows])
    y = np.array([float(row["intensity"]) for row in rows])
    return x, y


def baseline_points(x: np.ndarray, y: np.ndarray) -> list[tuple[float, float]]:
    """Estimate smooth background anchors from local lower quantiles."""
    points = []
    centers = np.linspace(float(x[0]), float(x[-1]), 55)
    for center in centers:
        sel = np.abs(x - center) <= 0.42
        if np.count_nonzero(sel) >= 10:
            points.append((float(center), float(np.quantile(y[sel], 0.12))))
    return points


def instrument_text() -> str:
    return (
        "# GSAS-II initial Cu K-alpha laboratory profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.8;Azimuth:0.0\n"
        "U:8.0;V:0.0;W:6.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def controls(project: G2.G2Project, cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)


def run_step(project: G2.G2Project, label: str, cycles: int = 8) -> dict:
    controls(project, cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    hist = project.histograms()[0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "stage": label,
        "Rwp": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(item) for item in project.get_Frozen()],
    }
    print(json.dumps(record), flush=True)
    return record


def setup_project(root: Path, ca_id: str, wo_id: str, pattern: Path) -> G2.G2Project:
    root.mkdir(parents=True, exist_ok=True)
    x, y = read_pattern(pattern)
    xye = root / "pattern.xye"
    with xye.open("w") as stream:
        for xv, yv in zip(x, y):
            stream.write(f"{xv:.8f} {yv:.8f} {math.sqrt(max(yv, 1.0)):.8f}\n")
    inst = root / "instrument.instprm"
    inst.write_text(instrument_text())

    project = G2.G2Project(newgpx=str(root / "screen.gpx"))
    ca = project.add_phase(str(cod_path(ca_id)), phasename=f"CaWO4_{ca_id}", fmthint="CIF")
    wo = project.add_phase(str(cod_path(wo_id)), phasename=f"WO3_{wo_id}", fmthint="CIF")
    hist = project.add_powder_histogram(
        str(xye), str(inst), phases=[ca, wo], fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [600.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({"Limits": {"low": float(x[0]), "high": float(x[-1])}})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 14,
                "coeffs": [float(np.median(y))] + [0.0] * 13,
                "FixedPoints": baseline_points(x, y),
                "fit fixed points": True,
                "refine": False,
            }
        }
    )

    # Broad product and sharper precursor are evident directly in the pattern.
    ca_hap = ca.data["Histograms"][hist.name]
    ca_hap["Scale"] = [5.0, False]
    ca_hap["Size"][0] = "isotropic"
    ca_hap["Size"][1][0] = 0.20
    ca_hap["Mustrain"][0] = "isotropic"
    ca_hap["Mustrain"][1][0] = 3000.0
    wo_hap = wo.data["Histograms"][hist.name]
    wo_hap["Scale"] = [1.0, False]
    wo_hap["Size"][0] = "isotropic"
    wo_hap["Size"][1][0] = 1.0
    wo_hap["Mustrain"][0] = "isotropic"
    wo_hap["Mustrain"][1][0] = 300.0
    project.index_ids()
    # Keep screening branches in a physically local neighborhood.
    for phase in (ca, wo):
        pid = phase.data["pId"]
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A(
            [cell["length_a"], cell["length_b"], cell["length_c"],
             cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]]
        )
        for index, value in enumerate(reciprocal):
            span = max(0.02 * abs(float(value)), 0.0005)
            project.set_Controls("parmMin", float(value) - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", float(value) + span, variable=f"{pid}::A{index}")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 30.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.02, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 5.0, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 12000.0, variable=f"{pid}:0:Mustrain;i")
    for name, low, high in (
        ("Shift", -900.0, 900.0), ("Zero", -0.4, 0.4),
        ("U", 0.0, 50.0), ("W", 0.05, 50.0), ("X", 0.01, 10.0),
        ("SH/L", 0.002, 0.15),
    ):
        project.set_Controls("parmMin", low, variable=f":0:{name}")
        project.set_Controls("parmMax", high, variable=f":0:{name}")
    project.save()
    return project


def screen(root: Path, ca_id: str, wo_id: str, pattern: Path) -> dict:
    project = setup_project(root, ca_id, wo_id, pattern)
    hist = project.histograms()[0]
    phases = project.phases()
    records = []

    # Establish the smooth background while keeping chemically sensible positive
    # starting scales, then align each phase before releasing those scales.
    hist.set_refinements({"Background": True})
    records.append(run_step(project, "background", 8))

    phases[0].set_refinements({"Cell": True})
    records.append(run_step(project, "cawo4_cell", 10))
    phases[0].clear_refinements({"Cell": True})
    phases[1].set_refinements({"Cell": True})
    records.append(run_step(project, "wo3_cell", 10))
    phases[0].set_refinements({"Cell": True})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    records.append(run_step(project, "scales_cells", 10))
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    records.append(run_step(project, "cells_zero", 10))
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    records.append(run_step(project, "cells_shift_zero", 12))

    # Instrument and phase-specific broadening.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    phases[0].set_HAP_refinements(
        {"Size": {"type": "isotropic", "refine": True},
         "Mustrain": {"type": "isotropic", "refine": True}}
    )
    phases[1].set_HAP_refinements(
        {"Size": {"type": "isotropic", "refine": True},
         "Mustrain": {"type": "isotropic", "refine": True}}
    )
    records.append(run_step(project, "profile", 12))
    records.append(run_step(project, "profile_settle", 12))

    fractions = hist.ComputeMassFracs()
    summary = {
        "ca_id": ca_id,
        "wo_id": wo_id,
        "Rwp": float(hist.get_wR()),
        "records": records,
        "fractions": {name: [float(v) for v in vals] for name, vals in fractions.items()},
        "instrument": {
            key: value
            for key, value in hist.InstrumentParameters.items()
            if key in {"Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."}
        },
        "sample": {
            key: hist.SampleParameters[key]
            for key in ["Shift", "SurfRoughA", "SurfRoughB"]
        },
        "phases": [],
    }
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        summary["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    (root / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps({"summary": str(root / "summary.json"), "Rwp": summary["Rwp"]}))
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo", required=True)
    parser.add_argument("--ca", default="7219229")
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    screen(args.out.resolve(), args.ca, args.wo, args.pattern.resolve())


if __name__ == "__main__":
    main()
