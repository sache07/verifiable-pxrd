#!/usr/bin/env python3
"""Export CIFs, profile, and machine-readable results from final.gpx."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(ROOT / "final.gpx"))
    histograms = project.histograms()
    if len(histograms) != 1:
        raise RuntimeError("expected exactly one powder histogram")
    hist = histograms[0]
    arrays = [np.asarray(item, dtype=float) for item in hist.data["data"][1]]
    x, observed, weights, calculated = arrays[:4]
    difference = observed - calculated
    source = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    if not (np.allclose(x, source[:, 0], atol=1e-7, rtol=0)
            and np.allclose(observed, source[:, 1], atol=1e-5, rtol=0)):
        raise RuntimeError("final project histogram does not match the supplied observations")

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta", "observed", "calculated", "difference"])
        for row in zip(x, observed, calculated, difference):
            writer.writerow([f"{row[0]:.8f}", f"{row[1]:.8f}",
                             f"{row[2]:.8f}", f"{row[3]:.8f}"])

    fractions = hist.ComputeMassFracs()
    phase_specs = [
        ("CaWO4 (scheelite)", "phase_1_CaWO4.cif", "CaWO4"),
        ("WO3 (monoclinic)", "phase_2_WO3.cif", "WO3"),
    ]
    if len(project.phases()) != len(phase_specs):
        raise RuntimeError("unexpected phase count in final project")
    phase_rows = []
    for phase, (name, filename, formula) in zip(project.phases(), phase_specs):
        phase.export_CIF(str(ROOT / filename))
        fraction, esd = fractions[phase.name]
        cell = phase.get_cell()
        phase_rows.append({
            "name": name,
            "formula": formula,
            "project_phase": phase.name,
            "cif_path": filename,
            "weight_fraction": float(fraction),
            "weight_fraction_esd": float(esd),
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cell": {key: float(value) for key, value in cell.items()},
        })

    rwp = float(100 * np.sqrt(np.sum(weights * difference**2)
                              / np.sum(weights * observed**2)))
    rp = float(100 * np.sum(np.abs(difference)) / np.sum(observed))
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    stats = {
        "Rwp_percent": rwp,
        "Rp_percent": rp,
        "Rexp_percent": float(hist.data["data"][0].get("wRmin")),
        "goodness_of_fit": float(rvals.get("GOF")),
        "chi_squared": float(rvals.get("chisq")),
        "n_observations": int(rvals.get("Nobs", len(x))),
        "n_variables_last_stage": int(rvals.get("Nvars", 0)),
        "durbin_watson": float(hist.data["data"][0].get("Durbin-Watson")),
    }
    result = {
        "phases": phase_rows,
        "fit_statistics": stats,
        "refinement_histogram": hist.name,
        "fraction_basis": "normalized over modeled crystalline phases",
        "profile_file": "fit.csv",
        "project_file": "final.gpx",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
