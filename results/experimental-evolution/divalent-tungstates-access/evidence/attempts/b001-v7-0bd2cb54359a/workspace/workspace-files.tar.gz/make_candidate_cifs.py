#!/usr/bin/env python3
"""Create provenance-preserving substituted structural starts for residual tests."""

from pathlib import Path
import json
import warnings

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)
OUT = Path("candidates")
OUT.mkdir(exist_ok=True)

SPECS = [
    ("mn2wo5_pnnm_mn2aso5", "9000178", {"Mn": "Mn", "As": "W"}, 1.0079019621),
    ("mn2wo5_pnnm_zn2aso5", "9015147", {"Zn": "Mn", "As": "W"}, 1.0423967333),
    ("mn2wo5_pnnm_co2aso5", "1524664", {"Co": "Mn", "As": "W"}, 1.0325597102),
    ("mn2wo5_p21c_cu2aso5", "9011171", {"Cu": "Mn", "As": "W"}, 1.0366772041),
    ("mn2wo5_c2m_pb2moo5", "7220560", {"Pb": "Mn", "Mo": "W"}, 1.2554720573),
    ("mn3wo6_c2c_zn3teo6", "2211529", {"Zn": "Mn", "Te": "W"}, 1.0067341385),
    ("mn3wo6_c2c_co3teo6", "2015468", {"Co": "Mn", "Te": "W"}, 1.0298641878),
    ("mnw2o7_p1_mnv2o7", "4030807", {"Mn": "Mn", "V": "W"}, 1.2240835164),
    ("mnw2o7_p1_case2o7", "1530940", {"Ca": "Mn", "Se": "W"}, 1.2062074688),
]


def cod_path(cod_id):
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


records = []
for name, cod_id, mapping, length_scale in SPECS:
    source = cod_path(cod_id)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        structure = Structure.from_file(source, primitive=False)
    structure.remove_oxidation_states()
    structure.replace_species(mapping)
    structure.scale_lattice(structure.volume * length_scale**3)
    output = OUT / f"{name}.cif"
    CifWriter(structure, symprec=0.01, refine_struct=False, significant_figures=10).write_file(output)
    records.append(
        {
            "name": name,
            "cif": str(output),
            "parent_cod_id": cod_id,
            "parent_cif": str(source),
            "transformation": {
                "species_mapping": mapping,
                "isotropic_length_scale": length_scale,
                "coordinate_change": "none",
            },
            "formula": structure.composition.reduced_formula,
            "space_group": structure.get_space_group_info(),
            "cell": structure.lattice.parameters,
            "minimum_distance_A": min(
                structure.get_distance(i, j)
                for i in range(len(structure))
                for j in range(i)
            ),
        }
    )

(OUT / "provenance.json").write_text(json.dumps(records, indent=2) + "\n")
for record in records:
    print(json.dumps(record))
