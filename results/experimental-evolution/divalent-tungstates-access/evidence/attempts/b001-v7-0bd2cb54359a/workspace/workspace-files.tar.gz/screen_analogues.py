#!/usr/bin/env python3
"""Screen frozen-library oxide topologies against the coherent residual family."""

from __future__ import annotations

import gzip
import json
from pathlib import Path
import warnings

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Element, Structure
from scipy.optimize import differential_evolution, minimize


INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/index.json.gz"
)
CIF_ROOT = INDEX.with_name("cif")
WAVELENGTH = 1.540598

# Peaks that remain positive and coherent after the first MnWO4 refinement.
# Peaks dominated by a known MnWO4 reflection were omitted from this screening list.
OBS_POS = np.array(
    [
        20.32431, 20.87850, 23.48643, 29.14783, 32.25562, 33.65738,
        34.51583, 42.19837, 43.94786, 46.19721, 47.01219, 50.31557,
        54.91206, 55.84657, 56.99841, 62.51854, 66.96290, 70.64661,
        77.26425, 79.37233, 86.27249, 91.64049, 96.18265,
    ]
)
OBS_WEIGHT = np.sqrt(
    np.array(
        [
            7412, 8290, 7899, 8711, 2990, 3271, 5142, 1113, 1735, 2739,
            3946, 1836, 3414, 2776, 1207, 934, 1099, 917, 848, 514, 411,
            264, 341,
        ],
        dtype=float,
    )
)
OBS_WEIGHT /= OBS_WEIGHT.sum()

TARGETS = {
    "Mn2WO5": (2, 1, 5),
    "Mn3WO6": (3, 1, 6),
    "MnW2O7": (1, 2, 7),
}


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def target_mapping(composition: Composition, target: tuple[int, int, int]):
    reduced = composition.reduced_composition
    nonoxygen = [el for el in reduced.elements if el.symbol != "O"]
    if len(nonoxygen) != 2:
        return None
    oxygen = float(reduced[Element("O")])
    amounts = [float(reduced[el]) for el in nonoxygen]
    # Compare ratios after allowing the two cation labels to swap.
    for order in [(0, 1), (1, 0)]:
        scale = amounts[order[0]] / target[0]
        if scale <= 0:
            continue
        expected = np.array(target, float) * scale
        actual = np.array([amounts[order[0]], amounts[order[1]], oxygen])
        if np.allclose(actual, expected, rtol=0, atol=2e-3):
            return {
                nonoxygen[order[0]].symbol: "Mn",
                nonoxygen[order[1]].symbol: "W",
            }
    return None


def substituted_structure(path: Path, mapping: dict[str, str]) -> Structure:
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        structure = Structure.from_file(path, primitive=False)
    structure.remove_oxidation_states()
    for old, new in mapping.items():
        structure.replace_species({old: new})
    if not structure.is_ordered:
        raise ValueError("disordered parent")
    return structure


def screen_pattern(structure: Structure):
    calc = XRDCalculator(wavelength=WAVELENGTH, symprec=0)
    pattern = calc.get_pattern(structure, two_theta_range=(8, 115), scaled=True)
    parent_pos = np.asarray(pattern.x, float)
    intensity = np.asarray(pattern.y, float)
    # Keep all meaningful lines, but prevent a huge tail of numerical lines from
    # rewarding dense low-symmetry patterns by chance.
    use = intensity >= 0.4
    parent_pos = parent_pos[use]
    intensity = intensity[use]
    intensity = intensity / intensity.sum()
    parent_d = WAVELENGTH / (2 * np.sin(np.deg2rad(parent_pos / 2)))

    def objective(params):
        length_scale, zero = params
        arg = WAVELENGTH / (2 * parent_d * length_scale)
        valid = arg < 0.999999
        pred = np.rad2deg(2 * np.arcsin(arg[valid])) + zero
        pred_i = intensity[valid]
        inrange = (pred >= 10) & (pred <= 100.1)
        pred = pred[inrange]
        pred_i = pred_i[inrange]
        if len(pred) < 3:
            return 10.0
        distances = np.abs(OBS_POS[:, None] - pred[None, :])
        tolerance_obs = 0.13 + 0.0022 * np.maximum(OBS_POS - 20, 0)
        # Each observed family member needs a nearby line; intensity enters only
        # weakly because texture and overlap can change it substantially.
        obs_match = np.max(
            np.exp(-0.5 * (distances / tolerance_obs[:, None]) ** 2)
            * np.power(pred_i[None, :] / max(pred_i.max(), 1e-12), 0.20),
            axis=1,
        )
        obs_coverage = float(np.sum(OBS_WEIGHT * obs_match))

        # Strong calculated lines should also land on a residual-family line.
        tolerance_pred = 0.13 + 0.0022 * np.maximum(pred - 20, 0)
        pred_match = np.max(
            np.exp(-0.5 * (distances / tolerance_pred[None, :]) ** 2), axis=0
        )
        strong = pred_i >= 0.01 * pred_i.max()
        pred_coverage = float(np.sum(pred_i[strong] * pred_match[strong]) / np.sum(pred_i[strong]))
        score = 0.65 * obs_coverage + 0.35 * pred_coverage
        return -score

    result = differential_evolution(
        objective,
        bounds=[(0.72, 1.38), (-0.4, 0.8)],
        seed=17,
        popsize=7,
        maxiter=30,
        polish=False,
        workers=1,
        updating="immediate",
    )
    local = minimize(
        objective,
        result.x,
        method="Nelder-Mead",
        options={"maxiter": 100, "xatol": 1e-5, "fatol": 1e-7},
    )
    scale, zero = local.x
    return float(-local.fun), float(scale), float(zero), len(parent_pos)


def main():
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)

    records = []
    seen = set()
    for key, rows in index.items():
        elements = set(key.split("-"))
        if "O" not in elements or len(elements) != 3:
            continue
        for formula, cod_id, space_group, r_value in rows:
            if cod_id in seen:
                continue
            seen.add(cod_id)
            try:
                composition = Composition(formula)
            except Exception:
                continue
            for target_name, target in TARGETS.items():
                mapping = target_mapping(composition, target)
                if mapping is None:
                    continue
                path = cif_path(cod_id)
                try:
                    structure = substituted_structure(path, mapping)
                    score, scale, zero, npeaks = screen_pattern(structure)
                    records.append(
                        {
                            "target": target_name,
                            "parent_formula": formula,
                            "cod_id": cod_id,
                            "space_group_index": space_group,
                            "reported_r": r_value,
                            "mapping": mapping,
                            "score": score,
                            "isotropic_length_scale": scale,
                            "zero_deg": zero,
                            "parent_cell": structure.lattice.parameters,
                            "n_calculated_lines": npeaks,
                            "cif": str(path),
                        }
                    )
                except Exception as exc:
                    records.append(
                        {
                            "target": target_name,
                            "parent_formula": formula,
                            "cod_id": cod_id,
                            "space_group_index": space_group,
                            "mapping": mapping,
                            "error": str(exc),
                            "cif": str(path),
                        }
                    )

    good = [record for record in records if "score" in record]
    good.sort(key=lambda record: record["score"], reverse=True)
    Path("analogue_screen.json").write_text(json.dumps(good, indent=2) + "\n")
    for target_name in TARGETS:
        print(f"\n{target_name}")
        selected = [record for record in good if record["target"] == target_name]
        for record in selected[:25]:
            print(
                f"{record['score']:.4f}  scale={record['isotropic_length_scale']:.4f} "
                f"zero={record['zero_deg']:.4f}  SG={record['space_group_index']:3d} "
                f"{record['parent_formula']:16s} COD {record['cod_id']} {record['mapping']}"
            )


if __name__ == "__main__":
    main()
