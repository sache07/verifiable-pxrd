#!/usr/bin/env python3
"""Jointly settle the accepted physical model and write final.gpx."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

import calibration_branches as cb
import profile_branches as pb
import texture_branches as tb
import thermal_polarization_branches as tp


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "terminal_branches" / "final_profile_010.gpx"
OUTPUT = ROOT / "final.gpx"


def add_bound(project, variable, low, high):
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def install_all_bounds(project):
    project.index_ids()
    hist = cb.histogram(project)
    hid = hist.data["data"][0]["hId"]
    add_bound(project, f":{hid}:Shift", -800.0, 800.0)
    add_bound(project, f":{hid}:W", 2.0, 40.0)
    add_bound(project, f":{hid}:SH/L", 0.005, 0.10)
    add_bound(project, f":{hid}:Polariz.", 0.5, 1.0)
    for phase in project.phases():
        pid = phase.data["pId"]
        add_bound(project, f"{pid}:{hid}:Scale", 1.0e-8, 1000.0)
        add_bound(project, f"{pid}:{hid}:Size;i", 0.04, 1.5)
    main_pid = project.phases()[0].data["pId"]
    add_bound(project, f"{main_pid}:{hid}:Mustrain;i", 300.0, 8000.0)
    add_bound(project, f"{main_pid}:{hid}:Mustrain;a", 300.0, 8000.0)
    candidate_pid = project.phases()[1].data["pId"]
    add_bound(project, f"{candidate_pid}:{hid}:MD", 0.7, 1.4)


def configure_thermal(project):
    tp.reset_constraints(project)
    project.index_ids()
    for phase_index, phase in enumerate(project.phases()):
        pid = phase.data["pId"]
        _, _, _, cia = phase.data["General"]["AtomPtrs"]
        variables = []
        for atom_index, atom in enumerate(phase.atoms()):
            row = phase.data["Atoms"][atom_index]
            row[cia] = "I"
            if phase_index == 1:
                row[cia + 1] = 0.005
            for offset in range(2, 8):
                if cia + offset < len(row) - 1:
                    row[cia + offset] = 0.0
            atom.refinement_flags = "U" if phase_index == 0 else " "
            variable = f"{pid}::AUiso:{atom_index}"
            add_bound(project, variable, 0.003, 0.020)
            variables.append(variable)
        if phase_index == 0:
            project.add_EquivConstr(variables, reloadIdx=False)


def fractions(project):
    hist = cb.histogram(project)
    weights = {
        phase.name: float(phase.data["General"]["Mass"])
        * float(phase.data["Histograms"][hist.name]["Scale"][0])
        for phase in project.phases()
    }
    total = sum(weights.values())
    return {name: value / total for name, value in weights.items()}


def correlations(project, threshold=0.85):
    covariance = project.data.get("Covariance", {}).get("data", {})
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    variables = list(covariance.get("varyList", []))
    if matrix.ndim != 2 or matrix.shape != (len(variables), len(variables)):
        return []
    sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    denom = np.outer(sigma, sigma)
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
    rows = []
    for i in range(len(variables)):
        for j in range(i + 1, len(variables)):
            value = float(corr[i, j])
            if abs(value) >= threshold:
                rows.append([variables[i], variables[j], value])
    rows.sort(key=lambda row: abs(row[2]), reverse=True)
    return rows


def main():
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUTPUT))
    hist = cb.histogram(project)
    cb.clear_flags(project)
    cb.clear_limits(project)
    install_all_bounds(project)
    cb.enable_common(project)

    # Retained calibration and common instrument terms.
    hist.SampleParameters["Shift"][1] = True
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.InstrumentParameters["Zero"][1] = 0.0
    hist.InstrumentParameters["Zero"][2] = False
    hist.InstrumentParameters["U"][2] = False
    hist.InstrumentParameters["X"][2] = False
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["SH/L"][2] = True
    hist.InstrumentParameters["Polariz."][2] = True

    main_hap = project.phases()[0].data["Histograms"][hist.name]
    candidate_hap = project.phases()[1].data["Histograms"][hist.name]
    for hap in (main_hap, candidate_hap):
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [True, False, False]
    main_hap["Mustrain"][0] = "uniaxial"
    main_hap["Mustrain"][2] = [True, True, False]
    main_hap["Mustrain"][3] = [0, 1, 0]
    pb.configure_strain(candidate_hap, "none")

    main_hap["Pref.Ori."][1] = 1.0
    main_hap["Pref.Ori."][2] = False
    candidate_hap["Pref.Ori."][0] = "MD"
    candidate_hap["Pref.Ori."][2] = True
    candidate_hap["Pref.Ori."][3] = [0, 0, 1]
    configure_thermal(project)

    records = []
    for repeat in range(6):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 12)
        project.save()
        project.refine(makeBack=False)
        project.save()
        record = tb.snapshot(project, f"terminal_pass_{repeat + 1}")
        record["fractions"] = fractions(project)
        record["shift_um"] = float(hist.SampleParameters["Shift"][0])
        record["uiso_A2"] = {
            phase.name: [float(row[10]) for row in phase.data["Atoms"]]
            for phase in project.phases()
        }
        x = np.asarray(hist.getdata("X"), dtype=float)
        bg = np.asarray(hist.getdata("Background"), dtype=float)
        mask = (x >= 10.0) & (x <= 100.05)
        record["background_minimum_in_fit"] = float(np.min(bg[mask]))
        records.append(record)
        if (
            record["converged"]
            and record["max_shift_esd"] is not None
            and record["max_shift_esd"] <= 1.0
            and not record["frozen"]
        ):
            break

    project.save()
    result = {
        "source": str(SOURCE.relative_to(ROOT)),
        "output": str(OUTPUT.relative_to(ROOT)),
        "records": records,
        "correlations_abs_ge_0.85": correlations(project),
        "short_distances": {
            phase.name: [list(row) for row in phase.ShortDistances(useAll=False)]
            for phase in project.phases()
        },
    }
    (ROOT / "prepolish_terminal.json").write_text(
        json.dumps(result, indent=2, default=float) + "\n"
    )
    print(json.dumps({
        **records[-1],
        "correlations_abs_ge_0.85": result["correlations_abs_ge_0.85"],
        "short_distances": result["short_distances"],
    }))


if __name__ == "__main__":
    main()
