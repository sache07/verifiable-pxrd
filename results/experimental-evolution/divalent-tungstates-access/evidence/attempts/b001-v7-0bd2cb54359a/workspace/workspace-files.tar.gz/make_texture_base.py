#!/usr/bin/env python3
"""Create a clean pre-texture checkpoint with only supported thermal terms."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import calibration_branches as cb
import profile_branches as pb
import thermal_polarization_branches as tp


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "terminal_branches" / "thermal_fixed_uiso_refined_pol.gpx"
OUTPUT = ROOT / "terminal_branches" / "texture_base.gpx"


def main():
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUTPUT))
    hist = cb.histogram(project)
    cb.clear_flags(project)
    cb.clear_limits(project)
    cb.install_limits(project)
    pb.install_profile_limits(project)
    project.index_ids()
    hid = hist.data["data"][0]["hId"]
    project.set_Controls("parmMin", 0.5, variable=f":{hid}:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=f":{hid}:Polariz.")
    cb.enable_common(project)
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["SH/L"][2] = True
    hist.InstrumentParameters["Polariz."][2] = True

    main_hap = project.phases()[0].data["Histograms"][hist.name]
    candidate_hap = project.phases()[1].data["Histograms"][hist.name]
    for hap in (main_hap, candidate_hap):
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [True, False, False]
    pb.configure_strain(main_hap, "isotropic")
    pb.configure_strain(candidate_hap, "none")

    # Rebuild the normalized isotropic ADPs. Only MnWO4 is refined; the
    # residual phase hit the physical lower limit in the equal branch.
    tp.reset_constraints(project)
    project.index_ids()
    for phase_index, phase in enumerate(project.phases()):
        pid = phase.data["pId"]
        _, _, _, cia = phase.data["General"]["AtomPtrs"]
        variables = []
        for atom_index, atom in enumerate(phase.atoms()):
            row = phase.data["Atoms"][atom_index]
            row[cia] = "I"
            row[cia + 1] = 0.005
            for offset in range(2, 8):
                if cia + offset < len(row) - 1:
                    row[cia + offset] = 0.0
            atom.refinement_flags = "U" if phase_index == 0 else " "
            variable = f"{pid}::AUiso:{atom_index}"
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)
            variables.append(variable)
        if phase_index == 0:
            project.add_EquivConstr(variables, reloadIdx=False)

    records = []
    for repeat in range(5):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        record = tp.snapshot(project, f"pass_{repeat + 1}")
        records.append(record)
        if (
            record["converged"]
            and record["max_shift_esd"] is not None
            and record["max_shift_esd"] <= 1.0
            and not record["frozen"]
        ):
            break
    (OUTPUT.with_suffix(".json")).write_text(
        json.dumps(records, indent=2, default=float) + "\n"
    )
    print(json.dumps(records[-1]))


if __name__ == "__main__":
    main()
