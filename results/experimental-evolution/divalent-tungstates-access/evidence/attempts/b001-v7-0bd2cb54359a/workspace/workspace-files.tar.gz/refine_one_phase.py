#!/usr/bin/env python3
"""Exploratory one-phase GSAS-II refinement for the Mn-W-O pattern."""

from pathlib import Path
import json
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
CSV = ROOT / "inputs" / "pattern.csv"
CIF = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif/1/52/02/1520200.cif"
)


def prepare_inputs():
    arr = np.loadtxt(CSV, delimiter=",", skiprows=1)
    # Explicit Poisson counting uncertainties; GSAS-II stores weights as 1/sigma^2.
    np.savetxt(ROOT / "pattern.xye", np.column_stack((arr, np.sqrt(np.maximum(arr[:, 1], 1.0)))))
    (ROOT / "trial.instprm").write_text(
        "#GSAS-II instrument parameter file; Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.35;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:15.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def state(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    hap = phase.data["Histograms"][hist.name]
    result = {
        "stage": label,
        "Rwp_percent": hist.get_wR(),
        "converged": cov.get("Rvals", {}).get("converged"),
        "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "cell": phase.get_cell(),
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if isinstance(value, list) and len(value) > 1
        },
        "sample": {
            key: value[0] if isinstance(value, list) else value
            for key, value in hist.SampleParameters.items()
            if key in {"Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"}
        },
        "scale": hap["Scale"][0],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "background": hist.Background[0],
        "varyList": cov.get("varyList", []),
        "variables": cov.get("variables", []).tolist() if hasattr(cov.get("variables"), "tolist") else cov.get("variables", []),
        "sig": cov.get("sig", []).tolist() if hasattr(cov.get("sig"), "tolist") else cov.get("sig", []),
    }
    print(json.dumps(result, default=float), flush=True)
    return result


def run(project, label, records, cycles=8):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    records.append(state(project, label))
    shutil.copy2(project.filename, ROOT / f"trial_{len(records):02d}_{label}.gpx")


def main():
    prepare_inputs()
    G2.SetPrintLevel("warn")
    gpx = ROOT / "one_phase_trial.gpx"
    if gpx.exists():
        gpx.unlink()
    project = G2.G2Project(newgpx=str(gpx))
    phase = project.add_phase(str(CIF), phasename="MnWO4_wolframite", fmthint="CIF")
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "trial.instprm"), phases=[phase], fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.05],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [1500.0] + [0.0] * 9,
                "refine": True,
            },
        }
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.25
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    for atom in phase.atoms():
        atom.refinement_flags = " "
    project.save()

    records = []
    run(project, "scale_background", records)

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run(project, "cell_zero", records)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run(project, "instrument_profile", records)

    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }
    )
    run(project, "size_strain", records, cycles=12)

    # Test whether a Bragg-Brentano displacement term is supported in addition to zero.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run(project, "shift", records, cycles=12)

    (ROOT / "one_phase_trial.json").write_text(json.dumps(records, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
