#!/usr/bin/env python3
"""Compare smooth background orders on the accepted two-phase model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

import calibration_branches as cb
import profile_branches as pb
import texture_branches as tb


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "terminal_branches" / "texture_phase1_001.gpx"
OUT = ROOT / "terminal_branches"


def run_order(order):
    output = OUT / f"background_{order}.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(output))
    hist = cb.histogram(project)
    cb.clear_flags(project)
    cb.clear_limits(project)
    cb.install_limits(project)
    pb.install_profile_limits(project)
    project.index_ids()
    hid = hist.data["data"][0]["hId"]
    project.set_Controls("parmMin", 0.5, variable=f":{hid}:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=f":{hid}:Polariz.")
    cb.enable_common(project)
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["SH/L"][2] = True
    hist.InstrumentParameters["Polariz."][2] = True

    background = hist.Background[0]
    coeffs = list(background[3:])
    coeffs = (coeffs + [0.0] * order)[:order]
    hist.Background[0] = ["chebyschev-1", True, order, *coeffs]

    main_hap = project.phases()[0].data["Histograms"][hist.name]
    candidate_hap = project.phases()[1].data["Histograms"][hist.name]
    for hap in (main_hap, candidate_hap):
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [True, False, False]
    pb.configure_strain(main_hap, "isotropic")
    pb.configure_strain(candidate_hap, "none")
    main_hap["Pref.Ori."][1] = 1.0
    main_hap["Pref.Ori."][2] = False
    candidate_hap["Pref.Ori."][0] = "MD"
    candidate_hap["Pref.Ori."][2] = True
    candidate_hap["Pref.Ori."][3] = [0, 0, 1]
    candidate_pid = project.phases()[1].data["pId"]
    project.set_Controls("parmMin", 0.7, variable=f"{candidate_pid}:{hid}:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{candidate_pid}:{hid}:MD")

    records = []
    for repeat in range(5):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        record = tb.snapshot(project, f"pass_{repeat + 1}")
        bg = np.asarray(hist.getdata("Background"), dtype=float)
        record["background"] = {
            "order": order,
            "minimum": float(np.min(bg)),
            "maximum": float(np.max(bg)),
            "coefficients": [float(value) for value in hist.Background[0][3:]],
        }
        records.append(record)
        if (
            record["converged"]
            and record["max_shift_esd"] is not None
            and record["max_shift_esd"] <= 1.0
            and not record["frozen"]
        ):
            break
    return {
        "order": order,
        "output": str(output.relative_to(ROOT)),
        "records": records,
    }


def main():
    G2.SetPrintLevel("error")
    results = [run_order(order) for order in (8, 10, 12, 15, 20)]
    (OUT / "background_comparison.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )
    for result in results:
        final = result["records"][-1]
        print(json.dumps({
            "order": result["order"],
            "Rwp_percent": final["Rwp_percent"],
            "converged": final["converged"],
            "max_shift_esd": final["max_shift_esd"],
            "frozen": final["frozen"],
            "background": final["background"],
        }))


if __name__ == "__main__":
    main()
