#!/usr/bin/env python3
"""Create submission files from the accepted read-only project replay."""

from __future__ import annotations

import json
from pathlib import Path
import shutil

import numpy as np


ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / "final_replay"


def main():
    replay = json.loads((REPLAY / "replay.json").read_text())
    if replay.get("status") != "replayed" or replay.get("profile_review_flags"):
        raise RuntimeError("accepted project did not pass the read-only replay audit")

    destinations = [ROOT / "phase_1_MnWO4.cif", ROOT / "phase_2_Mn2WO5.cif"]
    for source, destination in zip(
        (REPLAY / "phase_0.cif", REPLAY / "phase_1.cif"), destinations
    ):
        shutil.copy2(source, destination)

    with np.load(REPLAY / "prediction.npz", allow_pickle=False) as archive:
        x = archive["x"].copy()
        observed = archive["observed"].copy()
        calculated = archive["predicted"].copy()
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    weighted_chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(weighted_chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))

    phases = replay["phases"]
    result = {
        "schema_version": 1,
        "number_of_modeled_crystalline_phases": 2,
        "fraction_basis": "normalized over the modeled crystalline phases",
        "refinement_histogram": replay["histogram"],
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "phases": [
            {
                "name": "MnWO4 wolframite",
                "formula": "MnWO4",
                "space_group": "P 2/c (No. 13)",
                "cif_path": destinations[0].name,
                "weight_fraction": float(phases[0]["weight_fraction"]),
                "identification_status": "reliable",
            },
            {
                "name": "Mn2WO5 analogue-derived monoclinic phase",
                "formula": "Mn2WO5",
                "space_group": "P 21/n 1 1 (No. 14, unique-a setting)",
                "cif_path": destinations[1].name,
                "weight_fraction": float(phases[1]["weight_fraction"]),
                "identification_status": "probable topology; atomic coordinates less certain",
            },
        ],
        "fit_statistics": {
            "Rwp_percent_full_grid_replay": rwp,
            "Rp_percent_full_grid_replay": rp,
            "weighted_chi_square_full_grid": weighted_chi_square,
            "mean_weighted_square_residual": weighted_chi_square / len(x),
            "points_full_grid": int(len(x)),
            "Rwp_percent_GSASII_fit_range": 19.036718232192776,
            "Rp_percent_GSASII_fit_range": 12.429390729064023,
            "goodness_of_fit_GSASII": 10.749711942971148,
            "chi_square_GSASII_fit_range": 955188.432478776,
            "points_GSASII_fit_range": 8288,
            "variables_in_final_settle": 22,
        },
        "replay_audit": {
            "status": replay["status"],
            "project_sha256": replay["project_sha256"],
            "parameters_optimized": replay["parameters_optimized"],
            "project_unchanged": replay["project_unchanged"],
            "profile_review_flags": replay["profile_review_flags"],
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    report = f"""# Powder XRD phase analysis

The modeled crystalline assemblage is **MnWO4 wolframite (85.63 wt%)** plus an **analogue-derived monoclinic Mn2WO5 phase (14.37 wt%)**. Fractions are normalized only over these two modeled crystalline phases; they do not quantify any amorphous material.

## Evidence

The P2/c MnWO4 reference accounts for the dominant peak family across the full 10–100 degree scan. After its cell and profile were refined, a coherent residual family (including reflections near 20.3, 20.9, 23.5, 29.1, 32.3, 33.7, 34.5, 42.2, 46.2, 47.0, 54.9 and 55.8 degrees 2theta) remained. That family is jointly indexed by a Mn2WO5 model adapted from the Cu2AsO5 P21/c topology and refined in the equivalent P21/n unique-a setting. At equal cell/profile development this topology gave Rwp 22.04%, compared with 24.52–24.64% for three Pnnm Mn2WO5 starts and 26.14% for a C2/m start. Tested Mn3WO6 and MnW2O7 alternatives either required profile values at/outside the supplied laboratory bounds or fit materially worse, so they were discarded.

The final cells are MnWO4: a = 4.79533 A, b = 5.71160 A, c = 4.98146 A, beta = 91.1171 degrees; and Mn2WO5: a = 8.88910 A, b = 8.66508 A, c = 6.20951 A, alpha = 92.2146 degrees. Read-only geometry checks found no catastrophic contacts. MnWO4 has W–O = 1.776–2.131 A and Mn–O = 2.121–2.215 A; Mn2WO5 has tetrahedral W–O = 1.661–1.837 A and Mn–O contacts beginning at 2.006 A.

## Refinement and uncertainty

The accepted GSAS-II fit has Rwp = 19.0367% over its refinement range; independent full-grid atomic replay gives Rwp = {rwp:.4f}% and Rp = {rp:.4f}%. The required bounded polish selected a converged heavy/light branch with no frozen variables, fraction collapse, coordinate-bound violations in the accepted checkpoint, or geometry violations. The replay also reports no negative background, invalid ADP, polarization, or peak-width flags.

MnWO4 is identified reliably. Mn2WO5 is strongly supported as a phase formula/topology by an entire reflection family, but no exact-composition library reference was available. Most attempted Mn2WO5 coordinate shifts reached bounds and were rolled back, so its detailed atomic coordinates are not reliably determined beyond the adapted parent geometry. The 14.37 wt% value is therefore an approximate model-normalized crystalline fraction; sub-percent precision is not justified because no pointwise uncertainties were supplied and residual intensity/profile mismatch remains. No coherent unassigned peak family remains, but the 1:1 precursor metal balance means an unquantified amorphous or very poorly crystalline W-rich component cannot be excluded.
"""
    (ROOT / "report.md").write_text(report)


if __name__ == "__main__":
    main()
