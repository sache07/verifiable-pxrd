#!/usr/bin/env python3
"""Compare the permitted uniaxial microstrain directions for MnWO4."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import calibration_branches as cb
import profile_branches as pb


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "terminal_branches" / "profile_iso_candidate_null.gpx"
OUT = ROOT / "terminal_branches"


def run_axis(axis):
    label = "".join(str(item) for item in axis)
    output = OUT / f"mustrain_main_{label}.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(output))
    hist = cb.histogram(project)
    cb.clear_flags(project)
    cb.clear_limits(project)
    cb.install_limits(project)
    pb.install_profile_limits(project)
    cb.enable_common(project)
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["SH/L"][2] = True

    main_hap = project.phases()[0].data["Histograms"][hist.name]
    candidate_hap = project.phases()[1].data["Histograms"][hist.name]
    for hap in (main_hap, candidate_hap):
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [True, False, False]
    start = float(main_hap["Mustrain"][1][0])
    pb.configure_strain(main_hap, "uniaxial", axis=axis, start=start)
    pb.configure_strain(candidate_hap, "none")

    records = []
    for repeat in range(5):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        record = pb.snapshot(project, f"pass_{repeat + 1}")
        records.append(record)
        if (
            record["converged"]
            and record["max_shift_esd"] is not None
            and record["max_shift_esd"] <= 1.0
            and not record["frozen"]
        ):
            break
    return {
        "axis": axis,
        "output": str(output.relative_to(ROOT)),
        "records": records,
    }


def main():
    G2.SetPrintLevel("error")
    results = [run_axis(axis) for axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0])]
    (OUT / "mustrain_main_comparison.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )
    for result in results:
        print(json.dumps({"axis": result["axis"], **result["records"][-1]}))


if __name__ == "__main__":
    main()
