#!/usr/bin/env python3
"""Screen all laboratory-supported March-Dollase axes phase by phase."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import calibration_branches as cb
import profile_branches as pb


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "terminal_branches" / "texture_base.gpx"
OUT = ROOT / "terminal_branches"
AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def snapshot(project, label):
    result = pb.snapshot(project, label)
    hist = cb.histogram(project)
    result["texture"] = {
        phase.name: {
            "ratio": float(phase.data["Histograms"][hist.name]["Pref.Ori."][1]),
            "axis": list(phase.data["Histograms"][hist.name]["Pref.Ori."][3]),
        }
        for phase in project.phases()
    }
    return result


def run_branch(phase_index, axis):
    axis_label = "".join(str(item) for item in axis)
    output = OUT / f"texture_phase{phase_index}_{axis_label}.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(output))
    hist = cb.histogram(project)
    cb.clear_flags(project)
    cb.clear_limits(project)
    cb.install_limits(project)
    pb.install_profile_limits(project)
    project.index_ids()
    hid = hist.data["data"][0]["hId"]
    project.set_Controls("parmMin", 0.5, variable=f":{hid}:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=f":{hid}:Polariz.")
    cb.enable_common(project)
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["SH/L"][2] = True
    hist.InstrumentParameters["Polariz."][2] = True

    main_hap = project.phases()[0].data["Histograms"][hist.name]
    candidate_hap = project.phases()[1].data["Histograms"][hist.name]
    for hap in (main_hap, candidate_hap):
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [True, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    pb.configure_strain(main_hap, "isotropic")
    pb.configure_strain(candidate_hap, "none")

    phase = project.phases()[phase_index]
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    pid = phase.data["pId"]
    project.set_Controls("parmMin", 0.7, variable=f"{pid}:{hid}:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{pid}:{hid}:MD")

    records = []
    for repeat in range(4):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        record = snapshot(project, f"pass_{repeat + 1}")
        records.append(record)
        if (
            record["converged"]
            and record["max_shift_esd"] is not None
            and record["max_shift_esd"] <= 1.0
            and not record["frozen"]
        ):
            break
    return {
        "phase_index": phase_index,
        "phase": phase.name,
        "axis": list(axis),
        "output": str(output.relative_to(ROOT)),
        "records": records,
    }


def main():
    G2.SetPrintLevel("error")
    results = [
        run_branch(phase_index, axis)
        for phase_index in range(2)
        for axis in AXES
    ]
    (OUT / "texture_comparison.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )
    for result in results:
        final = result["records"][-1]
        print(json.dumps({
            "phase": result["phase"],
            "axis": result["axis"],
            "Rwp_percent": final["Rwp_percent"],
            "converged": final["converged"],
            "max_shift_esd": final["max_shift_esd"],
            "frozen": final["frozen"],
            "texture": final["texture"],
        }))


if __name__ == "__main__":
    main()
