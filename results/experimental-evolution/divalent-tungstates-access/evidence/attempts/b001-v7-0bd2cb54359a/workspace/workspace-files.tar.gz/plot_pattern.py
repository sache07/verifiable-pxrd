import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv("inputs/pattern.csv")
x = data.iloc[:, 0].to_numpy()
y = data.iloc[:, 1].to_numpy()

fig, axes = plt.subplots(3, 1, figsize=(14, 10), constrained_layout=True)
for ax, (lo, hi) in zip(axes, [(9.9, 40), (40, 70), (70, 100.1)]):
    use = (x >= lo) & (x <= hi)
    ax.plot(x[use], y[use], color="black", lw=0.7)
    ax.set_xlim(lo, hi)
    ax.set_ylabel("Counts")
    ax.grid(alpha=0.15)
axes[-1].set_xlabel(r"$2\theta$ (deg, Cu K$\alpha$)")
fig.savefig("pattern_overview.png", dpi=160)
