#!/usr/bin/env python3
"""Bounded, equal coordinate development of the accepted Mn2WO5 topology starts."""

import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2

import compare_candidates as cc


NAMES = [
    "mn2wo5_pnnm_mn2aso5",
    "mn2wo5_pnnm_zn2aso5",
    "mn2wo5_pnnm_co2aso5",
    "mn2wo5_p21c_cu2aso5",
]


def freeze_profiles(project):
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        if len(hap["Size"]) > 5:
            hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def main():
    G2.SetPrintLevel("error")
    summaries = []
    for name in NAMES:
        source = cc.OUT / f"{name}.gpx"
        destination = cc.OUT / f"developed_{name}.gpx"
        project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
        project.data["Controls"]["data"]["parmMinDict"] = {}
        project.data["Controls"]["data"]["parmMaxDict"] = {}
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        cc.install_bounds(project)

        # The P21/c residual-phase microstrain was pinned at zero. Remove that
        # unsupported term and retain the physically valid zero-strain model.
        if "p21c" in name:
            hap = project.phase(1).data["Histograms"][project.histogram(0).name]
            hap["Mustrain"][1][0] = 0.0
        freeze_profiles(project)
        cc.set_coordinate_bounds(project, half_width_A=0.15)
        stages = []

        cc.set_coordinate_flags(
            project, lambda atom: atom.element.strip().upper() != "O"
        )
        cc.refine(project, "heavy_coordinates", stages, cycles=8, repeats=1)

        cc.set_coordinate_flags(
            project, lambda atom: atom.element.strip().upper() == "O"
        )
        cc.refine(project, "oxygen_coordinates", stages, cycles=8, repeats=1)

        cc.set_coordinate_flags(project, lambda atom: True)
        cc.refine(project, "joint_coordinates", stages, cycles=8, repeats=2)
        cc.clear_coordinate_flags(project)
        project.save()
        checkpoint = cc.snapshot(project, "developed_coordinate_checkpoint")
        record = {"candidate": name, "checkpoint": checkpoint, "stages": stages}
        (cc.OUT / f"developed_{name}.json").write_text(
            json.dumps(record, indent=2, default=float) + "\n"
        )
        compact = {
            "candidate": name,
            "Rwp_percent": checkpoint["Rwp_percent"],
            "fractions": checkpoint["fractions"],
            "cell": checkpoint["cell"],
            "profile": checkpoint["profile"],
            "frozen": checkpoint["frozen"],
            "short_distances": checkpoint["short_distances"],
            "stage_states": [
                {
                    "stage": stage["stage"],
                    "Rwp_percent": stage["Rwp_percent"],
                    "max_shift_esd": stage["max_shift_esd"],
                    "frozen": stage["frozen"],
                }
                for stage in stages
            ],
        }
        summaries.append(compact)
        print(json.dumps(compact), flush=True)
    summaries.sort(key=lambda item: item["Rwp_percent"])
    (cc.OUT / "developed_comparison.json").write_text(
        json.dumps(summaries, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
