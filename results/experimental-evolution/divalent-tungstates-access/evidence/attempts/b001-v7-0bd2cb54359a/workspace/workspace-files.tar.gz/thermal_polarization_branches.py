#!/usr/bin/env python3
"""Test phase-wide isotropic displacement parameters and polarization."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import calibration_branches as cb
import profile_branches as pb


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "terminal_branches" / "profile_iso_candidate_null.gpx"
OUT = ROOT / "terminal_branches"


def reset_constraints(project):
    data = project.data["Constraints"]["data"]
    for key in ("Hist", "HAP", "Phase", "Global"):
        data[key] = []


def normalize_phase_uiso(project, refine):
    reset_constraints(project)
    project.index_ids()
    for phase in project.phases():
        pid = phase.data["pId"]
        atom_rows = phase.data["Atoms"]
        _, _, _, cia = phase.data["General"]["AtomPtrs"]
        variables = []
        for index, atom in enumerate(phase.atoms()):
            row = atom_rows[index]
            row[cia] = "I"
            row[cia + 1] = 0.005
            for offset in range(2, 8):
                if cia + offset < len(row) - 1:
                    row[cia + offset] = 0.0
            atom.refinement_flags = "U" if refine else " "
            variable = f"{pid}::AUiso:{index}"
            variables.append(variable)
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)
        if refine and len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)


def snapshot(project, label):
    result = pb.snapshot(project, label)
    result["uiso_A2"] = {
        phase.name: [float(row[10]) for row in phase.data["Atoms"]]
        for phase in project.phases()
    }
    return result


def run_branch(name, refine_uiso, refine_polarization):
    output = OUT / f"thermal_{name}.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(output))
    hist = cb.histogram(project)
    cb.clear_flags(project)
    cb.clear_limits(project)
    cb.install_limits(project)
    pb.install_profile_limits(project)
    project.index_ids()
    hid = hist.data["data"][0]["hId"]
    project.set_Controls("parmMin", 0.5, variable=f":{hid}:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=f":{hid}:Polariz.")
    cb.enable_common(project)
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["SH/L"][2] = True
    hist.InstrumentParameters["Polariz."][2] = bool(refine_polarization)

    main_hap = project.phases()[0].data["Histograms"][hist.name]
    candidate_hap = project.phases()[1].data["Histograms"][hist.name]
    for hap in (main_hap, candidate_hap):
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [True, False, False]
    pb.configure_strain(main_hap, "isotropic")
    pb.configure_strain(candidate_hap, "none")
    normalize_phase_uiso(project, refine_uiso)

    records = []
    for repeat in range(5):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        record = snapshot(project, f"pass_{repeat + 1}")
        records.append(record)
        if (
            record["converged"]
            and record["max_shift_esd"] is not None
            and record["max_shift_esd"] <= 1.0
            and not record["frozen"]
        ):
            break
    return {
        "name": name,
        "refine_uiso": refine_uiso,
        "refine_polarization": refine_polarization,
        "output": str(output.relative_to(ROOT)),
        "records": records,
    }


def main():
    G2.SetPrintLevel("error")
    results = [
        run_branch("fixed_uiso_fixed_pol", False, False),
        run_branch("refined_uiso_fixed_pol", True, False),
        run_branch("fixed_uiso_refined_pol", False, True),
        run_branch("refined_uiso_refined_pol", True, True),
    ]
    (OUT / "thermal_polarization_comparison.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )
    for result in results:
        print(json.dumps({"name": result["name"], **result["records"][-1]}))


if __name__ == "__main__":
    main()
