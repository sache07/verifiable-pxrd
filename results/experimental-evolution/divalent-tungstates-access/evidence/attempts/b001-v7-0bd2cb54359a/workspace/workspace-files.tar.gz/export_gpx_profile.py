#!/usr/bin/env python3
"""Export a GSAS-II powder profile and compact model diagnostics."""

import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


def atom_uiso(atom):
    try:
        return atom.uiso
    except Exception:
        return None


project = G2.G2Project(gpxfile=sys.argv[1])
hist = max(project.histograms(), key=lambda h: len(h.getdata("X")))
out = Path(sys.argv[2])
arr = np.column_stack(
    [hist.getdata("X"), hist.getdata("Yobs"), hist.getdata("Ycalc"), hist.getdata("Residual"), hist.getdata("Background")]
)
np.savetxt(out, arr, delimiter=",", header="two_theta_deg,observed,calculated,difference,background", comments="")
payload = {
    "histogram": hist.name,
    "Rwp_percent": hist.get_wR(),
    "residuals": hist.residuals,
    "instrument": hist.InstrumentParameters,
    "sample": hist.SampleParameters,
    "background": hist.Background,
    "phases": [],
    "covariance": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    "frozen": list(project.get_Frozen()),
}
for phase in project.phases():
    payload["phases"].append(
        {
            "name": phase.name,
            "composition": phase.composition,
            "cell": phase.get_cell(),
            "hap": phase.data["Histograms"].get(hist.name),
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": list(atom.coordinates),
                    "occupancy": atom.occupancy,
                    "uiso": atom_uiso(atom),
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    )
out.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=float) + "\n")
