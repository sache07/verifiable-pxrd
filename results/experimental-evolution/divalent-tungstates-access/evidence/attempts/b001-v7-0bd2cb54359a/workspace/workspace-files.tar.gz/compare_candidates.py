#!/usr/bin/env python3
"""Equally develop Mn-W-O residual-phase starts in two-phase GSAS-II models."""

from __future__ import annotations

import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
MAIN_CIF = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif/1/52/02/1520200.cif"
)
PROVENANCE = json.loads((ROOT / "candidates" / "provenance.json").read_text())
OUT = ROOT / "candidate_fits"
OUT.mkdir(exist_ok=True)


def prepare_inputs():
    arr = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    np.savetxt(
        ROOT / "pattern.xye",
        np.column_stack((arr, np.sqrt(np.maximum(arr[:, 1], 1.0)))),
    )
    (ROOT / "compare.instprm").write_text(
        "#GSAS-II instrument parameter file; Cu Kalpha comparison profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:15.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def clear_frozen(project):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def convergence(project):
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": None
        if rvals.get("Max shft/sig") is None
        else float(rvals["Max shft/sig"]),
        "frozen": list(project.get_Frozen()),
    }


def mass_fractions(project, hist):
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted[phase.name] = max(
            0.0, float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        )
    total = sum(weighted.values())
    return {name: value / total for name, value in weighted.items()} if total else weighted


def snapshot(project, stage):
    hist = project.histogram(0)
    return {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        **convergence(project),
        "fractions": mass_fractions(project, hist),
        "cell": {phase.name: phase.get_cell() for phase in project.phases()},
        "instrument": {
            key: float(value[1])
            for key, value in hist.InstrumentParameters.items()
            if isinstance(value, list)
            and len(value) > 1
            and key in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."}
        },
        "sample": {
            key: float(value[0]) if isinstance(value, list) else value
            for key, value in hist.SampleParameters.items()
            if key in {"Shift", "SurfRoughA", "SurfRoughB", "Gonio. radius"}
        },
        "profile": {
            phase.name: {
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in project.phases()
        },
        "short_distances": {
            phase.name: [list(row) for row in phase.ShortDistances(useAll=False)]
            for phase in project.phases()
        },
    }


def refine(project, stage, records, cycles=8, repeats=2):
    for repeat in range(repeats):
        clear_frozen(project)
        project.set_Controls("cycles", cycles)
        project.save()
        project.refine(makeBack=False)
        project.save()
        item = snapshot(project, f"{stage}_{repeat + 1}")
        records.append(item)
        if (
            item["converged"]
            and item["max_shift_esd"] is not None
            and item["max_shift_esd"] <= 1.0
            and not item["frozen"]
        ):
            break


def set_coordinate_bounds(project, half_width_A=0.15):
    project.index_ids()
    for phase in project.phases():
        cell = phase.get_cell()
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        pid = phase.data["pId"]
        for index, atom in enumerate(phase.atoms()):
            for axis, value, length in zip("xyz", atom.coordinates, lengths):
                half_width = half_width_A / max(float(length), 1e-6)
                variable = f"{pid}::dA{axis}:{index}"
                project.set_Controls("parmMin", float(value) - half_width, variable=variable)
                project.set_Controls("parmMax", float(value) + half_width, variable=variable)


def install_bounds(project):
    project.index_ids()
    hist = project.histogram(0)
    hid = hist.data["data"][0]["hId"]
    project.set_Controls("parmMin", -800.0, variable=f":{hid}:Shift")
    project.set_Controls("parmMax", 800.0, variable=f":{hid}:Shift")
    for phase in project.phases():
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 1e-8, variable=f"{pid}:{hid}:Scale")
        # HAP scales are on an arbitrary count scale; only positivity matters.
        project.set_Controls("parmMax", 1000.0, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMin", 0.03, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 2.0, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, variable=f"{pid}:{hid}:Mustrain;i")


def clear_coordinate_flags(project):
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def set_coordinate_flags(project, selector):
    clear_coordinate_flags(project)
    for phase in project.phases():
        for atom in phase.atoms():
            if selector(atom):
                atom.refinement_flags = "X"


def build_project(record):
    name = record["name"]
    path = OUT / f"{name}.gpx"
    if path.exists():
        path.unlink()
    project = G2.G2Project(newgpx=str(path))
    main = project.add_phase(
        str(MAIN_CIF), phasename="MnWO4_wolframite", fmthint="CIF"
    )
    candidate = project.add_phase(
        str(ROOT / record["cif"]), phasename=name, fmthint="CIF"
    )
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"),
        str(ROOT / "compare.instprm"),
        phases=[main, candidate],
        fmthint="xye",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-550.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.05],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [1500.0] + [0.0] * 9,
                "refine": True,
            },
        }
    )
    for phase, initial_scale in [(main, 10.0), (candidate, 3.0)]:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [initial_scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.25
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1500.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        phase.set_refinements({"Cell": False})
    clear_coordinate_flags(project)
    install_bounds(project)
    project.save()
    return project


def develop(record):
    project = build_project(record)
    records = []
    refine(project, "scale_background", records, cycles=8, repeats=2)

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, "cells", records, cycles=10, repeats=3)

    for phase in project.phases():
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    refine(project, "phase_profiles", records, cycles=10, repeats=3)

    project.histogram(0).set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "common_shift", records, cycles=10, repeats=3)

    set_coordinate_bounds(project, half_width_A=0.15)
    set_coordinate_flags(project, lambda atom: atom.element.strip().upper() != "O")
    refine(project, "heavy_coordinates", records, cycles=10, repeats=3)

    set_coordinate_flags(project, lambda atom: atom.element.strip().upper() == "O")
    refine(project, "oxygen_coordinates", records, cycles=10, repeats=3)

    set_coordinate_flags(project, lambda atom: True)
    refine(project, "joint_coordinates", records, cycles=10, repeats=3)
    clear_coordinate_flags(project)
    project.save()

    summary = {
        "candidate": record,
        "checkpoint": snapshot(project, "final_equal_development"),
        "stages": records,
    }
    (OUT / f"{record['name']}.json").write_text(
        json.dumps(summary, indent=2, default=float) + "\n"
    )
    print(
        json.dumps(
            {
                "candidate": record["name"],
                "Rwp_percent": summary["checkpoint"]["Rwp_percent"],
                "fractions": summary["checkpoint"]["fractions"],
                "cell": summary["checkpoint"]["cell"],
                "sample": summary["checkpoint"]["sample"],
                "frozen": summary["checkpoint"]["frozen"],
                "short_distances": summary["checkpoint"]["short_distances"],
            }
        ),
        flush=True,
    )
    return summary


def main():
    prepare_inputs()
    G2.SetPrintLevel("error")
    summaries = []
    for record in PROVENANCE:
        try:
            summaries.append(develop(record))
        except Exception as exc:
            failure = {"candidate": record, "error": repr(exc)}
            (OUT / f"{record['name']}.json").write_text(
                json.dumps(failure, indent=2) + "\n"
            )
            print(json.dumps(failure), flush=True)
    compact = [
        {
            "candidate": item["candidate"]["name"],
            "Rwp_percent": item["checkpoint"]["Rwp_percent"],
            "fractions": item["checkpoint"]["fractions"],
            "cell": item["checkpoint"]["cell"],
            "sample": item["checkpoint"]["sample"],
            "frozen": item["checkpoint"]["frozen"],
            "short_distances": item["checkpoint"]["short_distances"],
        }
        for item in summaries
    ]
    compact.sort(key=lambda item: item["Rwp_percent"])
    (OUT / "comparison.json").write_text(json.dumps(compact, indent=2) + "\n")


if __name__ == "__main__":
    main()
