import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

path = sys.argv[1]
out = sys.argv[2]
d = pd.read_csv(path)
x = d.iloc[:, 0].to_numpy()
yo = d.iloc[:, 1].to_numpy()
yc = d.iloc[:, 2].to_numpy()
diff = d.iloc[:, 3].to_numpy()

fig, axes = plt.subplots(3, 1, figsize=(15, 10), constrained_layout=True)
for ax, (lo, hi) in zip(axes, [(9.9, 40), (40, 70), (70, 100.1)]):
    use = (x >= lo) & (x <= hi)
    ax.plot(x[use], yo[use], color="black", lw=0.65, label="observed")
    ax.plot(x[use], yc[use], color="tab:red", lw=0.75, label="calculated")
    ax.plot(x[use], diff[use], color="tab:blue", lw=0.55, label="difference")
    ax.axhline(0, color="gray", lw=0.4)
    ax.set_xlim(lo, hi)
    ax.set_ylabel("Counts")
    ax.grid(alpha=0.12)
axes[0].legend(ncol=3, fontsize=8)
axes[-1].set_xlabel(r"$2\theta$ (deg)")
fig.savefig(out, dpi=160)
