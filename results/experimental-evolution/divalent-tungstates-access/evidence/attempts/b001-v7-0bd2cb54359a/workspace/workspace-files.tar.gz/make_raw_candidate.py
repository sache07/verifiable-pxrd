#!/usr/bin/env python3
"""Preserve a parent CIF setting while applying a simple species/cell transform."""

from pathlib import Path
import re


source = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif/9/01/11/9011171.cif"
)
destination = Path("candidates/mn2wo5_p21c_cu2aso5.cif")
scale = 1.0366772041
text = source.read_text()
for axis in "abc":
    pattern = rf"(_cell_length_{axis}\s+)([^\s]+)"
    match = re.search(pattern, text)
    if match is None:
        raise RuntimeError(f"missing cell length {axis}")
    number = float(re.match(r"[-+0-9.]+", match.group(2)).group())
    text = re.sub(pattern, rf"\g<1>{number * scale:.10f}", text, count=1)
text = re.sub(r"\bCu\b", "Mn", text)
text = re.sub(r"\bAs\b", "W", text)
text = text.replace("Cu2AsO5", "Mn2WO5").replace("Cu2 As O5", "Mn2 W O5")
destination.write_text(text)
print(destination)
