#!/usr/bin/env python3
"""Compare mutually exclusive angular-calibration branches from one checkpoint."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def histogram(project):
    return max(project.histograms(), key=lambda item: len(item.getdata("X")))


def clear_flags(project):
    hist = histogram(project)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if (
            isinstance(value, list)
            and len(value) > 1
            and isinstance(value[1], bool)
        ):
            value[1] = False
    for phase in project.phases():
        try:
            phase.clear_refinements({"Cell": True})
        except Exception:
            pass
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        for key in ("Size", "Mustrain"):
            value = hap[key]
            value[2] = [False] * len(value[2])
            if len(value) > 5:
                value[5] = [False] * len(value[5])
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][1] = False
        for value in hap["Babinet"].values():
            value[1] = False


def clear_limits(project):
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}


def install_limits(project):
    project.index_ids()
    hist = histogram(project)
    hid = hist.data["data"][0]["hId"]
    project.set_Controls("parmMin", -0.25, variable=f":{hid}:Zero")
    project.set_Controls("parmMax", 0.25, variable=f":{hid}:Zero")
    project.set_Controls("parmMin", -800.0, variable=f":{hid}:Shift")
    project.set_Controls("parmMax", 800.0, variable=f":{hid}:Shift")
    for phase in project.phases():
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 1.0e-8, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMax", 1000.0, variable=f"{pid}:{hid}:Scale")


def enable_common(project):
    hist = histogram(project)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def state(project, label):
    hist = histogram(project)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": label,
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": (
            None
            if rvals.get("Max shft/sig") is None
            else float(rvals["Max shft/sig"])
        ),
        "frozen": list(project.get_Frozen()),
        "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "scales": {
            phase.name: float(
                phase.data["Histograms"][hist.name]["Scale"][0]
            )
            for phase in project.phases()
        },
    }


def run_branch(source, name, mode):
    output = ROOT / "terminal_branches" / f"calibration_{name}.gpx"
    output.parent.mkdir(exist_ok=True)
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = histogram(project)
    clear_flags(project)
    clear_limits(project)
    install_limits(project)

    # A prior candidate refinement pinned this at zero. Preserve the physical
    # zero value, but do not retain the unsupported variable.
    candidate_hap = project.phases()[1].data["Histograms"][hist.name]
    candidate_hap["Mustrain"][0] = "isotropic"
    candidate_hap["Mustrain"][1][0] = 0.0
    candidate_hap["Mustrain"][2] = [False] * len(candidate_hap["Mustrain"][2])

    if mode == "shift":
        hist.SampleParameters["Shift"][0] = -550.0
        hist.InstrumentParameters["Zero"][1] = 0.0
    elif mode == "zero":
        hist.SampleParameters["Shift"][0] = 0.0
        hist.InstrumentParameters["Zero"][1] = 0.0
    elif mode == "both":
        hist.SampleParameters["Shift"][0] = -550.0
        hist.InstrumentParameters["Zero"][1] = 0.0
    elif mode == "none":
        hist.SampleParameters["Shift"][0] = -550.0
        hist.InstrumentParameters["Zero"][1] = 0.0
    else:
        raise ValueError(mode)

    enable_common(project)
    if mode in {"shift", "both"}:
        hist.SampleParameters["Shift"][1] = True
    if mode in {"zero", "both"}:
        hist.InstrumentParameters["Zero"][2] = True

    records = []
    for repeat in range(4):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        record = state(project, f"pass_{repeat + 1}")
        records.append(record)
        if (
            record["converged"]
            and record["max_shift_esd"] is not None
            and record["max_shift_esd"] <= 1.0
            and not record["frozen"]
        ):
            break

    covariance = project.data.get("Covariance", {}).get("data", {})
    result = {
        "name": name,
        "mode": mode,
        "output": str(output.relative_to(ROOT)),
        "records": records,
        "varyList": list(covariance.get("varyList", [])),
        "covMatrix": covariance.get("covMatrix", []).tolist()
        if hasattr(covariance.get("covMatrix", []), "tolist")
        else covariance.get("covMatrix", []),
    }
    return result


def main():
    source = Path(sys.argv[1] if len(sys.argv) > 1 else "candidate_fits/mn2wo5_p21c_cu2aso5.gpx")
    if not source.is_absolute():
        source = ROOT / source
    G2.SetPrintLevel("error")
    results = [
        run_branch(source, "fixed", "none"),
        run_branch(source, "shift", "shift"),
        run_branch(source, "zero", "zero"),
        # Diagnostic only: retained solely to quantify the zero/shift
        # covariance and never selected as a terminal branch.
        run_branch(source, "both_diagnostic", "both"),
    ]
    destination = ROOT / "terminal_branches" / "calibration_comparison.json"
    destination.write_text(json.dumps(results, indent=2, default=float) + "\n")
    for result in results:
        print(json.dumps({
            "name": result["name"],
            **result["records"][-1],
        }), flush=True)


if __name__ == "__main__":
    main()
