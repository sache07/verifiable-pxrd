#!/usr/bin/env python3
"""Develop bounded instrument and phase-profile branches."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import calibration_branches as cb


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "terminal_branches" / "calibration_shift.gpx"
OUT = ROOT / "terminal_branches"


def install_profile_limits(project):
    project.index_ids()
    hist = cb.histogram(project)
    hid = hist.data["data"][0]["hId"]
    project.set_Controls("parmMin", 2.0, variable=f":{hid}:W")
    project.set_Controls("parmMax", 40.0, variable=f":{hid}:W")
    project.set_Controls("parmMin", 0.005, variable=f":{hid}:SH/L")
    project.set_Controls("parmMax", 0.10, variable=f":{hid}:SH/L")
    for phase in project.phases():
        pid = phase.data["pId"]
        for suffix in ("Size;i", "Size;a"):
            project.set_Controls("parmMin", 0.04, variable=f"{pid}:{hid}:{suffix}")
            project.set_Controls("parmMax", 1.5, variable=f"{pid}:{hid}:{suffix}")
        for suffix in ("Mustrain;i", "Mustrain;a"):
            project.set_Controls("parmMin", 300.0, variable=f"{pid}:{hid}:{suffix}")
            project.set_Controls("parmMax", 8000.0, variable=f"{pid}:{hid}:{suffix}")


def configure_strain(hap, kind, axis=None, start=None):
    if kind == "none":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        return
    if kind == "isotropic":
        hap["Mustrain"][0] = "isotropic"
        if start is not None:
            hap["Mustrain"][1][0] = float(start)
            hap["Mustrain"][1][1] = float(start)
        hap["Mustrain"][2] = [True, False, False]
        return
    if kind == "uniaxial":
        hap["Mustrain"][0] = "uniaxial"
        if start is not None:
            hap["Mustrain"][1][0] = float(start)
            hap["Mustrain"][1][1] = float(start)
        hap["Mustrain"][2] = [True, True, False]
        hap["Mustrain"][3] = list(axis)
        return
    raise ValueError(kind)


def snapshot(project, label):
    result = cb.state(project, label)
    hist = cb.histogram(project)
    result["instrument"] = {
        key: float(hist.InstrumentParameters[key][1])
        for key in ("U", "W", "X", "SH/L", "Polariz.")
    }
    result["profiles"] = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["profiles"][phase.name] = {
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    return result


def run_branch(name, candidate_strain, main_kind="isotropic", main_axis=None):
    output = OUT / f"profile_{name}.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(output))
    hist = cb.histogram(project)
    cb.clear_flags(project)
    cb.clear_limits(project)
    cb.install_limits(project)
    install_profile_limits(project)
    cb.enable_common(project)

    # Calibration is now a fixed, tested checkpoint value.
    hist.SampleParameters["Shift"][1] = False
    hist.InstrumentParameters["Zero"][2] = False

    # W controls the common low-angle Gaussian width and SH/L the asymmetric
    # axial-divergence tail. U and X stay fixed because they are exactly or
    # nearly inseparable from phase strain and size, respectively.
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["SH/L"][2] = True

    main_hap = project.phases()[0].data["Histograms"][hist.name]
    candidate_hap = project.phases()[1].data["Histograms"][hist.name]
    for hap in (main_hap, candidate_hap):
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [True, False, False]
    configure_strain(
        main_hap,
        main_kind,
        axis=main_axis,
        start=max(float(main_hap["Mustrain"][1][0]), 1200.0),
    )
    configure_strain(
        candidate_hap,
        "isotropic" if candidate_strain else "none",
        start=1200.0,
    )

    records = []
    for repeat in range(5):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        record = snapshot(project, f"pass_{repeat + 1}")
        records.append(record)
        if (
            record["converged"]
            and record["max_shift_esd"] is not None
            and record["max_shift_esd"] <= 1.0
            and not record["frozen"]
        ):
            break
    return {
        "name": name,
        "output": str(output.relative_to(ROOT)),
        "candidate_strain": candidate_strain,
        "main_kind": main_kind,
        "main_axis": main_axis,
        "records": records,
    }


def main():
    G2.SetPrintLevel("error")
    results = [
        run_branch("iso_candidate_null", False),
        run_branch("iso_candidate_present", True),
    ]
    (OUT / "profile_comparison.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )
    for result in results:
        print(json.dumps({"name": result["name"], **result["records"][-1]}))


if __name__ == "__main__":
    main()
