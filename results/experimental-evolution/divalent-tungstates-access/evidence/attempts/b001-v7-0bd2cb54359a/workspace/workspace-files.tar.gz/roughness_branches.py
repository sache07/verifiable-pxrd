#!/usr/bin/env python3
"""Test Suortti surface roughness from several physical starts."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import calibration_branches as cb
import profile_branches as pb
import texture_branches as tb


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "terminal_branches" / "texture_phase1_001.gpx"
OUT = ROOT / "terminal_branches"


def run_branch(label, start):
    output = OUT / f"roughness_{label}.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(output))
    hist = cb.histogram(project)
    cb.clear_flags(project)
    cb.clear_limits(project)
    cb.install_limits(project)
    pb.install_profile_limits(project)
    project.index_ids()
    hid = hist.data["data"][0]["hId"]
    for key, low, high in (
        ("Polariz.", 0.5, 1.0),
        ("SurfRoughA", 0.05, 0.6),
        ("SurfRoughB", 0.02, 0.5),
    ):
        project.set_Controls("parmMin", low, variable=f":{hid}:{key}")
        project.set_Controls("parmMax", high, variable=f":{hid}:{key}")
    cb.enable_common(project)
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["SH/L"][2] = True
    hist.InstrumentParameters["Polariz."][2] = True

    main_hap = project.phases()[0].data["Histograms"][hist.name]
    candidate_hap = project.phases()[1].data["Histograms"][hist.name]
    for hap in (main_hap, candidate_hap):
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [True, False, False]
    pb.configure_strain(main_hap, "isotropic")
    pb.configure_strain(candidate_hap, "none")
    main_hap["Pref.Ori."][1] = 1.0
    main_hap["Pref.Ori."][2] = False
    candidate_hap["Pref.Ori."][0] = "MD"
    candidate_hap["Pref.Ori."][2] = True
    candidate_hap["Pref.Ori."][3] = [0, 0, 1]
    candidate_pid = project.phases()[1].data["pId"]
    project.set_Controls("parmMin", 0.7, variable=f"{candidate_pid}:{hid}:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{candidate_pid}:{hid}:MD")

    hist.SampleParameters["SurfRoughA"] = [float(start[0]), True]
    hist.SampleParameters["SurfRoughB"] = [float(start[1]), True]

    records = []
    for repeat in range(5):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        record = tb.snapshot(project, f"pass_{repeat + 1}")
        record["roughness"] = {
            "A": float(hist.SampleParameters["SurfRoughA"][0]),
            "B": float(hist.SampleParameters["SurfRoughB"][0]),
        }
        records.append(record)
        if (
            record["converged"]
            and record["max_shift_esd"] is not None
            and record["max_shift_esd"] <= 1.0
            and not record["frozen"]
        ):
            break
    return {
        "label": label,
        "start": start,
        "output": str(output.relative_to(ROOT)),
        "records": records,
    }


def main():
    G2.SetPrintLevel("error")
    starts = (("low", [0.10, 0.03]), ("middle", [0.30, 0.10]), ("high", [0.50, 0.30]))
    results = [run_branch(label, start) for label, start in starts]
    (OUT / "roughness_comparison.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )
    for result in results:
        final = result["records"][-1]
        print(json.dumps({
            "label": result["label"],
            "Rwp_percent": final["Rwp_percent"],
            "converged": final["converged"],
            "max_shift_esd": final["max_shift_esd"],
            "frozen": final["frozen"],
            "roughness": final["roughness"],
        }))


if __name__ == "__main__":
    main()
