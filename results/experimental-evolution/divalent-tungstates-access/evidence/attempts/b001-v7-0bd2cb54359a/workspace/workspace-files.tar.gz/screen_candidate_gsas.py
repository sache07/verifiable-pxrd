#!/usr/bin/env python3
"""Cell/profile checkpoint for all residual-phase topology controls."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import compare_candidates as cc


def main():
    cc.prepare_inputs()
    G2.SetPrintLevel("error")
    out = []
    for source in cc.PROVENANCE:
        path = cc.OUT / f"screen_{source['name']}.json"
        if path.exists():
            record = json.loads(path.read_text())
            checkpoint = record["checkpoint"]
        else:
            try:
                project = cc.build_project(source)
                stages = []
                cc.refine(project, "scale_background", stages, cycles=7, repeats=1)
                for phase in project.phases():
                    phase.set_refinements({"Cell": True})
                cc.refine(project, "cells", stages, cycles=8, repeats=2)
                for phase in project.phases():
                    phase.set_HAP_refinements(
                        {
                            "Size": {"type": "isotropic", "refine": True},
                            "Mustrain": {"type": "isotropic", "refine": True},
                        }
                    )
                cc.refine(project, "phase_profiles", stages, cycles=8, repeats=2)
                project.save()
                checkpoint = cc.snapshot(project, "cell_profile_checkpoint")
                record = {"candidate": source, "checkpoint": checkpoint, "stages": stages}
                path.write_text(json.dumps(record, indent=2, default=float) + "\n")
            except Exception as exc:
                print(json.dumps({"candidate": source["name"], "error": repr(exc)}), flush=True)
                continue
        compact = {
            "candidate": source["name"],
            "Rwp_percent": checkpoint["Rwp_percent"],
            "fractions": checkpoint["fractions"],
            "cell": checkpoint["cell"],
            "profile": checkpoint["profile"],
            "frozen": checkpoint["frozen"],
            "short_distances": checkpoint["short_distances"],
        }
        out.append(compact)
        print(json.dumps(compact), flush=True)
    out.sort(key=lambda item: item["Rwp_percent"])
    (cc.OUT / "screen_comparison.json").write_text(json.dumps(out, indent=2) + "\n")


if __name__ == "__main__":
    main()
