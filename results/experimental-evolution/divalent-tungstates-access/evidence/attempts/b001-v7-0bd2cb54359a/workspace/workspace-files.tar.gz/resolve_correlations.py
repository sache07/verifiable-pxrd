#!/usr/bin/env python3
"""Resolve strongly correlated terminal terms with equal physical branches."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import calibration_branches as cb
import profile_branches as pb
import prepare_final as pf
import texture_branches as tb
import thermal_polarization_branches as tp


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "final.gpx"
OUT = ROOT / "terminal_branches"


def configure_uiso(project, refine_main):
    tp.reset_constraints(project)
    project.index_ids()
    for phase_index, phase in enumerate(project.phases()):
        pid = phase.data["pId"]
        _, _, _, cia = phase.data["General"]["AtomPtrs"]
        variables = []
        for atom_index, atom in enumerate(phase.atoms()):
            row = phase.data["Atoms"][atom_index]
            row[cia] = "I"
            if phase_index == 1 or not refine_main:
                row[cia + 1] = 0.005
            for offset in range(2, 8):
                if cia + offset < len(row) - 1:
                    row[cia + offset] = 0.0
            atom.refinement_flags = "U" if phase_index == 0 and refine_main else " "
            variable = f"{pid}::AUiso:{atom_index}"
            pf.add_bound(project, variable, 0.003, 0.020)
            variables.append(variable)
        if phase_index == 0 and refine_main:
            project.add_EquivConstr(variables, reloadIdx=False)


def run_branch(name, refine_main_uiso, refine_polarization):
    output = OUT / f"decorrelated_{name}.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(output))
    hist = cb.histogram(project)
    cb.clear_flags(project)
    cb.clear_limits(project)
    pf.install_all_bounds(project)
    cb.enable_common(project)

    hist.SampleParameters["Shift"][1] = True
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.InstrumentParameters["Zero"][2] = False
    hist.InstrumentParameters["U"][2] = False
    hist.InstrumentParameters["X"][2] = False
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["SH/L"][1] = 0.03
    hist.InstrumentParameters["SH/L"][2] = False
    if refine_polarization:
        hist.InstrumentParameters["Polariz."][2] = True
    else:
        hist.InstrumentParameters["Polariz."][1] = 0.70
        hist.InstrumentParameters["Polariz."][2] = False

    main_hap = project.phases()[0].data["Histograms"][hist.name]
    candidate_hap = project.phases()[1].data["Histograms"][hist.name]
    for hap in (main_hap, candidate_hap):
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [True, False, False]
    main_hap["Mustrain"][0] = "uniaxial"
    main_hap["Mustrain"][2] = [True, True, False]
    main_hap["Mustrain"][3] = [0, 1, 0]
    pb.configure_strain(candidate_hap, "none")
    main_hap["Pref.Ori."][1] = 1.0
    main_hap["Pref.Ori."][2] = False
    candidate_hap["Pref.Ori."][0] = "MD"
    candidate_hap["Pref.Ori."][2] = True
    candidate_hap["Pref.Ori."][3] = [0, 0, 1]
    configure_uiso(project, refine_main_uiso)

    records = []
    for repeat in range(6):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 12)
        project.save()
        project.refine(makeBack=False)
        project.save()
        record = tb.snapshot(project, f"pass_{repeat + 1}")
        record["fractions"] = pf.fractions(project)
        record["uiso_A2"] = {
            phase.name: [float(row[10]) for row in phase.data["Atoms"]]
            for phase in project.phases()
        }
        records.append(record)
        if (
            record["converged"]
            and record["max_shift_esd"] is not None
            and record["max_shift_esd"] <= 1.0
            and not record["frozen"]
        ):
            break
    return {
        "name": name,
        "refine_main_uiso": refine_main_uiso,
        "refine_polarization": refine_polarization,
        "output": str(output.relative_to(ROOT)),
        "records": records,
        "correlations_abs_ge_0.85": pf.correlations(project),
    }


def main():
    G2.SetPrintLevel("error")
    results = [
        run_branch("uiso", True, False),
        run_branch("polarization", False, True),
        run_branch("fixed", False, False),
    ]
    (OUT / "decorrelated_comparison.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )
    for result in results:
        final = result["records"][-1]
        print(json.dumps({
            "name": result["name"],
            "Rwp_percent": final["Rwp_percent"],
            "converged": final["converged"],
            "max_shift_esd": final["max_shift_esd"],
            "frozen": final["frozen"],
            "shift_um": final["shift_um"],
            "polarization": final["instrument"]["Polariz."],
            "uiso_A2": final["uiso_A2"],
            "correlations_abs_ge_0.85": result["correlations_abs_ge_0.85"],
        }))


if __name__ == "__main__":
    main()
