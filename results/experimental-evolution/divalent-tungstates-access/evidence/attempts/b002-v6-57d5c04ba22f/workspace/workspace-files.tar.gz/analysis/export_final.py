#!/usr/bin/env python3
"""Export all submitted products from the exact final GSAS-II project."""

from __future__ import annotations

import csv
import json
from pathlib import Path
import re

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "final.gpx"


def safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("_")


def main() -> None:
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(PROJECT))
    histogram = project.histogram(0)
    fractions = histogram.ComputeMassFracs()

    phases = []
    for phase in project.phases():
        filename = f"phase_{safe_name(phase.name)}.cif"
        phase.export_CIF(str(ROOT / filename))
        fraction, esd = fractions[phase.name]
        phases.append(
            {
                "name": phase.name,
                "formula": phase.data["General"].get("Name", phase.name),
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": filename,
                "weight_fraction": float(fraction),
                "weight_fraction_esd": float(esd),
            }
        )

    public = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    x_public, y_public = public.T
    x_gsas, y_gsas, weights, y_calc, y_background, y_difference = [
        np.asarray(value, dtype=float) for value in histogram.data["data"][1]
    ]
    if len(x_gsas) != len(x_public) or not np.allclose(x_gsas, x_public, atol=1e-7, rtol=0):
        raise RuntimeError("final project grid does not match inputs/pattern.csv")
    if not np.allclose(y_gsas, y_public, atol=1e-5, rtol=0):
        raise RuntimeError("final project observations do not match inputs/pattern.csv")
    if not np.isfinite(y_calc).all() or np.min(y_calc) < 0:
        raise RuntimeError("final calculated profile is nonfinite or negative")

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(["two_theta", "observed", "calculated", "difference"])
        for values in zip(x_public, y_public, y_calc, y_public - y_calc):
            writer.writerow([f"{values[0]:.8f}", f"{values[1]:.8f}", f"{values[2]:.8f}", f"{values[3]:.8f}"])

    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    fit_statistics = {
        "Rwp_percent": float(histogram.get_wR()),
        "Rp_percent": float(histogram.residuals["R"]),
        "Rexp_percent": float(histogram.residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_square": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_variables": int(rvals["Nvars"]),
        "max_shift_over_esd": float(rvals["Max shft/sig"]),
        "converged": bool(rvals["converged"]),
    }
    result = {
        "schema_version": 1,
        "refinement_histogram": histogram.name,
        "fraction_basis": "normalized over the modeled crystalline phases",
        "phases": phases,
        "fit_statistics": fit_statistics,
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
