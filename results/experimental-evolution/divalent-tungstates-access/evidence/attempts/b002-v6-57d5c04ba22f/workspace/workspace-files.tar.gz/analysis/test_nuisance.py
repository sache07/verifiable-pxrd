#!/usr/bin/env python3
"""Branch-test bounded specimen/intensity terms from a closed inventory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


AXES = ((0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1))


def args():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("outdir")
    return parser.parse_args()


def hist(project):
    return project.histogram(0)


def clear(project):
    h = hist(project)
    h.Background[0][1] = False
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in h.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def ordinary(project, shift=True):
    h = hist(project)
    h.Background[0][1] = True
    if "Scale" in h.SampleParameters:
        h.SampleParameters["Scale"] = [1.0, False]
    h.SampleParameters["Shift"][1] = bool(shift)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.data["Histograms"][h.name]["Scale"][1] = True


def fractions(project):
    values = hist(project).ComputeMassFracs()
    return {key: float(value[0]) for key, value in values.items()}


def state(project, name):
    h = hist(project)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "name": name,
        "Rwp_percent": float(h.get_wR()),
        "Rp_percent": float(h.residuals.get("R")),
        "GOF": float(rvals.get("GOF", 0.0)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(value) for value in project.get_Frozen()],
        "fractions": fractions(project),
        "instrument": {
            key: value for key, value in h.InstrumentParameters.items()
            if key in {"Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}
        },
        "sample": {
            key: value for key, value in h.SampleParameters.items()
            if key in {"Shift", "SurfRoughA", "SurfRoughB"}
        },
        "preferred_orientation": {
            phase.name: phase.data["Histograms"][h.name]["Pref.Ori."][:4]
            for phase in project.phases()
        },
        "uiso": {
            phase.name: [float(atom.data[phase.data["General"]["AtomPtrs"][3] + 1]) for atom in phase.atoms()]
            for phase in project.phases()
        },
    }


def install_common_bounds(project):
    project.index_ids()
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    for phase in project.phases():
        pid = int(phase.data["pId"])
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(reciprocal):
            value = float(value)
            span = max(abs(value) * 0.01, 0.0003)
            project.set_Controls("parmMin", value - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", value + span, variable=f"{pid}::A{index}")
        scale = float(phase.data["Histograms"][hist(project).name]["Scale"][0])
        project.set_Controls("parmMin", max(scale * 0.25, 1e-9), variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", max(scale * 4.0, 1.0), variable=f"{pid}:0:Scale")


def run(project, cycles=8):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()


def load(source, destination):
    project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
    clear(project)
    install_common_bounds(project)
    ordinary(project)
    return project


def prepare_uiso(project, active_phase=None):
    project.index_ids()
    for phase in project.phases():
        _, _, _, cia = phase.data["General"]["AtomPtrs"]
        for raw in phase.data["Atoms"]:
            raw[cia] = "I"
            raw[cia + 1] = 0.008
            for index in range(cia + 2, min(cia + 8, len(raw) - 1)):
                raw[index] = 0.0
    project.save()
    project.index_ids()
    for phase in project.phases():
        pid = int(phase.data["pId"])
        variables = [f"{pid}::AUiso:{index}" for index, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
        if active_phase is None or phase.name == active_phase:
            for atom in phase.atoms():
                atom.refinement_flags = "U"
        for index, _ in enumerate(phase.atoms()):
            project.set_Controls("parmMin", 0.003, variable=f"{pid}::AUiso:{index}")
            project.set_Controls("parmMax", 0.020, variable=f"{pid}::AUiso:{index}")


def branch(source, output, name, setup, post=None):
    project = load(source, output)
    setup(project)
    run(project)
    if post is not None:
        post(project)
        run(project)
    record = state(project, name)
    print(json.dumps(record), flush=True)
    return record


def main():
    parsed = args()
    source = Path(parsed.input).resolve()
    outdir = Path(parsed.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    records = []

    records.append(branch(source, outdir / "baseline.gpx", "baseline", lambda p: None))

    def polarization(project):
        h = hist(project)
        h.InstrumentParameters["Polariz."][2] = True
        project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")

    records.append(branch(source, outdir / "polarization.gpx", "polarization", polarization))

    for start_a, start_b in ((0.10, 0.05), (0.30, 0.10), (0.50, 0.30)):
        def roughness(project, a=start_a, b=start_b):
            h = hist(project)
            h.SampleParameters["SurfRoughA"] = [a, True]
            h.SampleParameters["SurfRoughB"] = [b, True]
            project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
            project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
            project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
            project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
        label = f"roughness_{start_a:.2f}_{start_b:.2f}"
        records.append(branch(source, outdir / f"{label}.gpx", label, roughness))

    def zero(project):
        h = hist(project)
        h.SampleParameters["Shift"][1] = False
        h.InstrumentParameters["Zero"][2] = True
        project.set_Controls("parmMin", -0.25, variable=":0:Zero")
        project.set_Controls("parmMax", 0.25, variable=":0:Zero")

    def shift_after_zero(project):
        h = hist(project)
        h.InstrumentParameters["Zero"][2] = False
        h.SampleParameters["Shift"][1] = True

    records.append(branch(source, outdir / "zero_shift.gpx", "zero_shift", zero, shift_after_zero))

    for phase in ("ZnWO4", "WO3", "ZnO"):
        records.append(branch(
            source, outdir / f"uiso_{phase}.gpx", f"uiso_{phase}",
            lambda project, selected=phase: prepare_uiso(project, selected),
        ))
    records.append(branch(
        source, outdir / "uiso_all.gpx", "uiso_all",
        lambda project: prepare_uiso(project, None),
    ))

    probe = G2.G2Project(gpxfile=str(source))
    phase_names = [phase.name for phase in probe.phases()]
    for phase_name in phase_names:
        for axis in AXES:
            axis_name = "".join(str(value) for value in axis)
            def orientation(project, selected=phase_name, selected_axis=axis):
                phase = project.phase(selected)
                pref = phase.data["Histograms"][hist(project).name]["Pref.Ori."]
                pref[0] = "MD"
                pref[1] = 1.0
                pref[2] = True
                pref[3] = list(selected_axis)
                pid = int(phase.data["pId"])
                project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
                project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
            label = f"po_{phase_name}_{axis_name}"
            records.append(branch(source, outdir / f"{label}.gpx", label, orientation))

    (outdir / "summary.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
