#!/usr/bin/env python3
"""Create chemically motivated starting CIFs for the ZnO--WO3 specimen.

The frozen case index intentionally contains no O-W-Zn references.  The
wolframite model below repairs the duplicated full-cell rows in COD 5910277
(NiWO4, P 2/c) to its four independent sites and substitutes Zn for Ni.
The scheelite model is a topology control made by substituting Zn into the
frozen CaWO4 reference (COD 7219229).  These are starting models only; cells
and coordinates are to be tested/refined against the specimen pattern.
"""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "analysis" / "candidates"
COD = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)


def cod_path(identifier: str) -> Path:
    return COD / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)

    # Four independent sites from the physically ordinary wolframite model.
    # The slightly enlarged cell is a conservative Zn-for-Ni starting guess.
    wolframite = Structure.from_spacegroup(
        "P 1 2/c 1",
        Lattice.monoclinic(4.69, 5.72, 4.93, 90.6),
        ["Zn", "W", "O", "O"],
        [
            [0.5000, 0.6530, 0.2500],
            [0.0000, 0.1800, 0.2500],
            [0.2200, 0.1100, -0.0400],
            [0.2600, 0.3800, 0.3900],
        ],
    )
    CifWriter(wolframite, symprec=1e-5).write_file(OUT / "znwo4_wolframite.cif")

    # Later, fully refined wolframite relatives provide substantially better
    # coordinates than the duplicated-row 1951 NiWO4 entry. Keep both W-bearing
    # hubnerite and room-temperature CoMoO4-II transfers for profile testing.
    hubnerite = Structure.from_file(cod_path("9008131"), primitive=False)
    hubnerite.replace_species({"Mn": "Zn", "Fe": "Zn"})
    hubnerite = Structure(
        Lattice.monoclinic(4.69, 5.72, 4.93, 90.6),
        [site.species for site in hubnerite],
        hubnerite.frac_coords,
    )
    CifWriter(hubnerite, symprec=1e-3).write_file(
        OUT / "znwo4_hubnerite_analogue.cif"
    )

    comolybdate = Structure.from_file(cod_path("7205001"), primitive=False)
    comolybdate.replace_species({"Co": "Zn", "Mo": "W"})
    comolybdate = Structure(
        Lattice.monoclinic(4.69, 5.72, 4.93, 90.6),
        [site.species for site in comolybdate],
        comolybdate.frac_coords,
    )
    CifWriter(comolybdate, symprec=1e-3).write_file(
        OUT / "znwo4_comoo4_analogue.cif"
    )

    scheelite = Structure.from_file(cod_path("7219229"), primitive=False)
    scheelite.replace_species({"Ca": "Zn"})
    CifWriter(scheelite, symprec=1e-5).write_file(OUT / "znwo4_scheelite.cif")

    # COD 2311041 is the physically sound coordinate determination of the
    # room-temperature monoclinic WO3 structure. Its deposited cell is a very
    # oblique equivalent setting; Niggli reduction gives the ordinary
    # near-orthogonal P21/c cell without changing the structure.
    wo3 = Structure.from_file(cod_path("2311041"), primitive=False)
    wo3 = wo3.get_reduced_structure("niggli")
    wo3_path = OUT / "wo3_p21c_physical.cif"
    CifWriter(wo3, symprec=1e-3, refine_struct=False).write_file(wo3_path)
    # The reduced near-orthogonal cell uses the P21/n origin/setting (the
    # generated operations already contain the n glide). Label that setting
    # explicitly so GSAS-II does not reinterpret the operations as its P21/c
    # setting.
    wo3_text = wo3_path.read_text().replace(
            "_symmetry_space_group_name_H-M   P2_1/c",
            "_symmetry_space_group_name_H-M   'P 1 21/n 1'\n"
            "_symmetry_space_group_name_Hall   '-P 2yn'",
        )
    # Let importers generate this standard setting from the explicit symbol;
    # some GSAS-II releases compare equivalent translated symmetry operators
    # too literally when a CIF also supplies the operation loop.
    sym_start = wo3_text.index("loop_\n _symmetry_equiv_pos_site_id")
    atom_start = wo3_text.index("loop_\n _atom_site_type_symbol")
    wo3_path.write_text(wo3_text[:sym_start] + wo3_text[atom_start:])

    provenance = {
        "znwo4_wolframite.cif": {
            "model_basis": "analogue_derived",
            "parent": "COD 5910277 NiWO4",
            "transformation": (
                "Removed symmetry-duplicate full-cell rows to the four-site P 2/c "
                "asymmetric unit; substituted Zn for Ni; used a modestly enlarged "
                "starting cell."
            ),
        },
        "znwo4_scheelite.cif": {
            "model_basis": "analogue_derived_topology_control",
            "parent": "COD 7219229 CaWO4",
            "transformation": "Substituted Zn for Ca without changing topology.",
        },
        "znwo4_hubnerite_analogue.cif": {
            "model_basis": "analogue_derived",
            "parent": "COD 9008131 Mn0.97Fe0.03WO4",
            "transformation": (
                "Collapsed the Mn/Fe site to full Zn occupancy and used the "
                "conservative ZnWO4 starting cell; P2/c topology retained."
            ),
        },
        "znwo4_comoo4_analogue.cif": {
            "model_basis": "analogue_derived",
            "parent": "COD 7205001 CoMoO4-II",
            "transformation": (
                "Substituted Zn for Co and W for Mo and used the conservative "
                "ZnWO4 starting cell; P2/c topology retained."
            ),
        },
        "wo3_p21c_physical.cif": {
            "model_basis": "published_reindexed",
            "parent": "COD 2311041 WO3",
            "transformation": (
                "Niggli-reduced the deposited equivalent P21/c cell to the "
                "ordinary near-orthogonal setting; coordinates and topology retained."
            ),
            "selection_note": (
                "Preferred over COD 1528915 because 2311041 has ordinary WO6 "
                "geometry (minimum O-O 2.54 A rather than 1.57 A)."
            ),
        },
    }
    (OUT / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")


if __name__ == "__main__":
    main()
