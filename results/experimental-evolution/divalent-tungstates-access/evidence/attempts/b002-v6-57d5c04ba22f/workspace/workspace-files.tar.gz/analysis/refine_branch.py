#!/usr/bin/env python3
"""Refine a selected bounded nuisance-term branch on a closed GSAS-II model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--po", action="append", default=[], help="PHASE:h,k,l")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--zero", action="store_true")
    parser.add_argument("--uniaxial", action="append", default=[], help="PHASE:h,k,l")
    parser.add_argument("--strain-min", type=float, default=0.0)
    parser.add_argument("--uiso", action="append", default=[], help="PHASE:value (fixed)")
    parser.add_argument("--passes", type=int, default=3)
    parser.add_argument("--cycles", type=int, default=8)
    return parser.parse_args()


def hist(project):
    return project.histogram(0)


def clear_flags(project):
    h = hist(project)
    h.Background[0][1] = False
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in h.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def enable_ordinary(project, refine_shift=True):
    h = hist(project)
    h.Background[0][1] = True
    h.SampleParameters["Scale"] = [1.0, False]
    h.SampleParameters["Shift"][1] = bool(refine_shift)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.data["Histograms"][h.name]["Scale"][1] = True


def set_uiso(project, specifications):
    values = {}
    for item in specifications:
        name, sep, value = item.partition(":")
        if not sep:
            raise ValueError(f"invalid --uiso {item!r}")
        values[name] = float(value)
    for phase in project.phases():
        if phase.name not in values:
            continue
        _, _, _, cia = phase.data["General"]["AtomPtrs"]
        for raw in phase.data["Atoms"]:
            raw[cia] = "I"
            raw[cia + 1] = values[phase.name]
            for index in range(cia + 2, min(cia + 8, len(raw) - 1)):
                raw[index] = 0.0


def enable_terms(project, parsed):
    h = hist(project)
    controls = project.data["Controls"]["data"]
    if parsed.polarization:
        h.InstrumentParameters["Polariz."][2] = True
        project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    if parsed.roughness:
        if float(h.SampleParameters["SurfRoughA"][0]) <= 0.0:
            h.SampleParameters["SurfRoughA"][0] = 0.30
        if float(h.SampleParameters["SurfRoughB"][0]) <= 0.0:
            h.SampleParameters["SurfRoughB"][0] = 0.10
        h.SampleParameters["SurfRoughA"][1] = True
        h.SampleParameters["SurfRoughB"][1] = True
        project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    if parsed.zero:
        h.InstrumentParameters["Zero"][2] = True
        project.set_Controls("parmMin", -0.25, variable=":0:Zero")
        project.set_Controls("parmMax", 0.25, variable=":0:Zero")
    for item in parsed.po:
        name, sep, axis_text = item.partition(":")
        if not sep:
            raise ValueError(f"invalid --po {item!r}")
        axis = [int(value) for value in axis_text.split(",")]
        if len(axis) != 3:
            raise ValueError(f"invalid --po axis {axis_text!r}")
        phase = project.phase(name)
        pref = phase.data["Histograms"][h.name]["Pref.Ori."]
        pref[0] = "MD"
        pref[2] = True
        pref[3] = axis
        pid = int(phase.data["pId"])
        project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
    for item in parsed.uniaxial:
        name, sep, axis_text = item.partition(":")
        if not sep:
            raise ValueError(f"invalid --uniaxial {item!r}")
        axis = [int(value) for value in axis_text.split(",")]
        if len(axis) != 3:
            raise ValueError(f"invalid --uniaxial axis {axis_text!r}")
        phase = project.phase(name)
        hap = phase.data["Histograms"][h.name]
        strain = hap["Mustrain"]
        start = max(float(strain[1][0]), 300.0)
        strain[0] = "uniaxial"
        strain[1][0] = start
        strain[1][1] = start
        strain[2] = [True, True, False]
        strain[3] = axis
        pid = int(phase.data["pId"])
        project.set_Controls("parmMin", parsed.strain_min, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMin", parsed.strain_min, variable=f"{pid}:0:Mustrain;a")
        project.set_Controls("parmMax", 32000.0, variable=f"{pid}:0:Mustrain;a")


def mass_fractions(project):
    return {key: float(value[0]) for key, value in hist(project).ComputeMassFracs().items()}


def record(project, index):
    h = hist(project)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "pass": index,
        "Rwp_percent": float(h.get_wR()),
        "Rp_percent": float(h.residuals.get("R")),
        "GOF": rvals.get("GOF"),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(value) for value in project.get_Frozen()],
        "fractions": mass_fractions(project),
        "instrument": {
            key: h.InstrumentParameters[key]
            for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample": {
            key: h.SampleParameters[key]
            for key in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "preferred_orientation": {
            phase.name: phase.data["Histograms"][h.name]["Pref.Ori."][:4]
            for phase in project.phases()
        },
        "profile": {
            phase.name: {
                "size": phase.data["Histograms"][h.name]["Size"],
                "microstrain": phase.data["Histograms"][h.name]["Mustrain"],
            }
            for phase in project.phases()
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }


def main():
    parsed = arguments()
    source = Path(parsed.input).resolve()
    output = Path(parsed.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    clear_flags(project)
    set_uiso(project, parsed.uiso)
    project.save()
    project.index_ids()
    enable_ordinary(project, refine_shift=not parsed.zero)
    enable_terms(project, parsed)
    records = []
    for index in range(1, parsed.passes + 1):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", parsed.cycles)
        project.save()
        project.refine(makeBack=False)
        project.save()
        current = record(project, index)
        records.append(current)
        print(json.dumps(current), flush=True)
        # A bound hit is evidence about this branch; do not repeatedly push it.
        if current["converged"] and current["max_shift_esd"] is not None and current["max_shift_esd"] <= 1.0:
            break
    output.with_suffix(".json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
