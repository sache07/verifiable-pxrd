#!/usr/bin/env python3
"""Build and refine a physical GSAS-II checkpoint for a proposed inventory.

Run with the GSAS-II Python interpreter.  The script intentionally stops
before atomic-coordinate refinement; learned/staged_polish.py is reserved for
that bounded final-stage operation once the inventory is closed.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import shutil
import traceback

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", required=True, help="output stem under analysis/fits")
    parser.add_argument(
        "--phase",
        action="append",
        required=True,
        metavar="NAME=PATH",
        help="phase name and CIF path; repeat for multiphase fits",
    )
    parser.add_argument("--background-coeffs", type=int, default=10)
    parser.add_argument("--start-shift-um", type=float, default=-500.0)
    parser.add_argument("--refine-zero", action="store_true")
    parser.add_argument("--no-profile", action="store_true")
    return parser.parse_args()


def write_xye(source: Path, destination: Path) -> None:
    rows = np.loadtxt(source, delimiter=",", skiprows=1)
    sigma = np.sqrt(np.maximum(rows[:, 1], 1.0))
    np.savetxt(destination, np.column_stack((rows, sigma)), fmt="%.8f %.8f %.8f")


def write_instrument(destination: Path) -> None:
    destination.write_text(
        "#GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def mass_fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    try:
        values = hist.ComputeMassFracs()
        if values:
            return {name: float(item[0]) for name, item in values.items()}
    except Exception:
        pass
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted[phase.name] = max(
            0.0,
            float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]),
        )
    total = sum(weighted.values())
    return {name: value / total for name, value in weighted.items()} if total else {}


def clear_frozen(project: G2.G2Project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def convergence(project: G2.G2Project) -> dict:
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "GOF": rvals.get("GOF"),
        "frozen": [str(value) for value in project.get_Frozen()],
    }


def snapshot(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": {key: float(value) for key, value in phase.get_cell().items()},
            "scale": float(hap["Scale"][0]),
            "size": hap["Size"],
            "microstrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "short_contacts": phase.ShortDistances(useAll=False),
        }
    instrument = {}
    for key, value in hist.InstrumentParameters.items():
        if isinstance(value, list):
            instrument[key] = value
    sample = {
        key: value
        for key, value in hist.SampleParameters.items()
        if key in {"Type", "Gonio. radius", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"}
    }
    return {
        "stage": stage,
        "Rwp_percent": hist.residuals.get("wR"),
        "Rp_percent": hist.residuals.get("R"),
        "background": hist.Background,
        "instrument": instrument,
        "sample": sample,
        "fractions": mass_fractions(project),
        "phases": phases,
        **convergence(project),
    }


def run_stage(
    project: G2.G2Project,
    outdir: Path,
    records: list[dict],
    name: str,
    cycles: int,
) -> None:
    clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = snapshot(project, name)
    records.append(record)
    shutil.copy2(project.filename, outdir / f"{len(records):02d}_{name}.gpx")
    print(json.dumps(record, default=str), flush=True)


def main() -> None:
    args = parse_args()
    root = Path(__file__).resolve().parents[1]
    outdir = root / "analysis" / "fits" / args.name
    outdir.mkdir(parents=True, exist_ok=True)
    xye = outdir / "pattern.xye"
    inst = outdir / "instrument.instprm"
    write_xye(root / "inputs" / "pattern.csv", xye)
    write_instrument(inst)

    phase_specs = []
    for item in args.phase:
        name, sep, path = item.partition("=")
        if not sep:
            raise ValueError(f"phase specification must be NAME=PATH: {item}")
        phase_specs.append((name, (root / path).resolve() if not Path(path).is_absolute() else Path(path)))

    G2.SetPrintLevel("error")
    project = G2.G2Project(newgpx=str(outdir / "checkpoint.gpx"))
    hist = project.add_powder_histogram(
        str(xye), str(inst), fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    # The overall sample scale is exactly degenerate with all HAP scales.
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [float(args.start_shift_um), False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_coeffs,
                "coeffs": [900.0] + [0.0] * (args.background_coeffs - 1),
                "refine": False,
            }
        }
    )

    phases = []
    for index, (name, path) in enumerate(phase_specs):
        phase = project.add_phase(
            str(path), phasename=name, histograms=[hist], fmthint="CIF"
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10.0 / max(len(phase_specs), 1), False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        phase.set_refinements({"LeBail": False})
        phase.set_refinements({"Atoms": {"all": " "}})
        phases.append(phase)

    project.save()
    project.index_ids()
    # Broad physical bounds for the potentially unstable parameters.
    project.set_Controls("parmMin", -0.25, variable=":0:Zero")
    project.set_Controls("parmMax", 0.25, variable=":0:Zero")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    for variable, lower, upper in (
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    for phase in phases:
        pid = int(phase.data["pId"])
        cell = phase.data["General"]["Cell"][1:7]
        for index, value in enumerate(G2lat.cell2A(cell)):
            value = float(value)
            span = max(0.01 * abs(value), 0.0003)
            project.set_Controls("parmMin", value - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", value + span, variable=f"{pid}::A{index}")
        project.set_Controls("parmMin", 1.0e-8, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 1000.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.50, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")

    records: list[dict] = []
    records.append(snapshot(project, "initial"))

    # Close the ordinary structural model first: scale/background, metric and
    # specimen/calibration. Instrument and specimen broadening are added only
    # after the reflection positions are stable.
    hist.set_refinements({"Background": True})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    run_stage(project, outdir, records, "scale_background", 5)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_stage(project, outdir, records, "cell_shift", 8)

    if args.refine_zero:
        # Keep specimen shift fixed while introducing zero; refining both at
        # once is nearly singular in Bragg--Brentano geometry.
        hist.clear_refinements({"Sample Parameters": ["Shift"]})
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        run_stage(project, outdir, records, "zero", 8)
        hist.clear_refinements({"Instrument Parameters": ["Zero"]})
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        run_stage(project, outdir, records, "shift_after_zero", 8)

    if not args.no_profile:
        # Determine a common instrumental envelope first. Phase-specific
        # size/strain are introduced only after these terms are fixed, avoiding
        # the exact X/size and near U/strain degeneracies.
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
        run_stage(project, outdir, records, "instrument_profile", 10)
        hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
        for phase in phases:
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "value": 0.30, "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True},
                }
            )
        run_stage(project, outdir, records, "phase_profile", 10)
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        run_stage(project, outdir, records, "polarization_settle", 8)

    project.save()
    (outdir / "refinement.json").write_text(json.dumps(records, indent=2, default=str) + "\n")
    print(json.dumps({"output": str(project.filename), "final": records[-1]}, default=str))


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        raise
