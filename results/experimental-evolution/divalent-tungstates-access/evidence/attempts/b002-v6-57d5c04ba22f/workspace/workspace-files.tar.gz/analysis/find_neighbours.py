#!/usr/bin/env python3
"""Run the frozen framework-neighbour helper against this case's library."""

from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / "learned" / "divalent-tungstates" / "runtime"
sys.path.insert(0, str(RUNTIME))

import library_neighbours as neighbours  # noqa: E402


RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01"
)
neighbours.INDEX = RESOURCE / "index.json.gz"
neighbours.CIFS = RESOURCE / "cif"


if __name__ == "__main__":
    neighbours.main()
