#!/usr/bin/env python3
"""Bounded ZnWO4-only coordinate adaptation with selected nuisance terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIstrMain as G2st


def arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    return parser.parse_args()


def hist(project):
    return project.histogram(0)


def clear(project):
    h = hist(project)
    h.Background[0][1] = False
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in h.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def ordinary(project):
    h = hist(project)
    h.Background[0][1] = True
    h.SampleParameters["Scale"] = [1.0, False]
    h.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.data["Histograms"][h.name]["Scale"][1] = True


def geometry(phase):
    controls, data = phase.InitDisAgl(False)
    controls["Factors"] = [1.25, 0.0]
    _, distances, _ = G2st.RetDistAngle(controls, data, dmin=0.01)
    atoms = phase.atoms()
    pairs = {}
    for center, rows in distances.items():
        for row in rows:
            other = int(row[0])
            key = "-".join(sorted((atoms[center].element, atoms[other].element)))
            distance = float(row[-2])
            pairs[key] = min(pairs.get(key, distance), distance)
    return {"pair_min_A": pairs, "short_contacts": phase.ShortDistances(useAll=False)}


def fractions(project):
    return {key: float(value[0]) for key, value in hist(project).ComputeMassFracs().items()}


def state(project, stage):
    h = hist(project)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": stage,
        "Rwp_percent": float(h.get_wR()),
        "Rp_percent": float(h.residuals.get("R")),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(value) for value in project.get_Frozen()],
        "fractions": fractions(project),
        "polarization": h.InstrumentParameters["Polariz."],
        "roughness": [h.SampleParameters["SurfRoughA"], h.SampleParameters["SurfRoughB"]],
        "preferred_orientation": {
            phase.name: phase.data["Histograms"][h.name]["Pref.Ori."][:4]
            for phase in project.phases()
        },
        "geometry": {phase.name: geometry(phase) for phase in project.phases()},
        "coordinates": {
            phase.name: [list(atom.coordinates) for atom in phase.atoms()]
            for phase in project.phases()
        },
    }


def run(project, records, stage, cycles=8):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    current = state(project, stage)
    records.append(current)
    print(json.dumps(current), flush=True)


def select_coordinates(project, group):
    for phase in project.phases():
        for atom in phase.atoms():
            oxygen = atom.element.strip().upper() in {"O", "O-2"}
            selected = phase.name == "ZnWO4" and (
                group == "all" or (group == "oxygen" and oxygen) or (group == "heavy" and not oxygen)
            )
            atom.refinement_flags = "X" if selected else " "


def enable_nuisance(project, parsed):
    h = hist(project)
    principal = project.phase("ZnWO4")
    pref = principal.data["Histograms"][h.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[2] = True
    pref[3] = [1, 1, 1]
    pid = int(principal.data["pId"])
    project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
    if parsed.polarization:
        h.InstrumentParameters["Polariz."][2] = True
        project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    if parsed.roughness:
        h.SampleParameters["SurfRoughA"][1] = True
        h.SampleParameters["SurfRoughB"][1] = True
        project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")


def main():
    parsed = arguments()
    source = Path(parsed.input).resolve()
    output = Path(parsed.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    clear(project)
    ordinary(project)
    project.index_ids()
    principal = project.phase("ZnWO4")
    pid = int(principal.data["pId"])
    cell = principal.get_cell()
    lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
    for index, atom in enumerate(principal.atoms()):
        for axis, value, length in zip("xyz", atom.coordinates, lengths):
            half_width = 0.10 / float(length)
            project.set_Controls("parmMin", float(value) - half_width, variable=f"{pid}::dA{axis}:{index}")
            project.set_Controls("parmMax", float(value) + half_width, variable=f"{pid}::dA{axis}:{index}")
    records = []
    for group in ("heavy", "oxygen", "all"):
        select_coordinates(project, group)
        run(project, records, f"ZnWO4_{group}", 10 if group == "all" else 8)
    select_coordinates(project, "none")
    clear(project)
    ordinary(project)
    enable_nuisance(project, parsed)
    for index in range(1, 4):
        run(project, records, f"nuisance_settle_{index}", 8)
        if records[-1]["converged"] and records[-1]["max_shift_esd"] is not None and records[-1]["max_shift_esd"] <= 1.0:
            break
    output.with_suffix(".json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
