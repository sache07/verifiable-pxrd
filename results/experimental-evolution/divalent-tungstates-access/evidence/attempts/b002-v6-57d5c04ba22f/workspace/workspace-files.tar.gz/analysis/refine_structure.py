#!/usr/bin/env python3
"""Refine complete structural coordinates from a closed phase inventory.

This is the ordinary, bounded structural refinement that precedes the single
final call to learned/staged_polish.py.  It does not alter the phase inventory
or topology and records geometry after every coordinate group.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIIstrMain as G2st


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    return parser.parse_args()


def hist(project):
    return project.histogram(0)


def clear_flags(project) -> None:
    h = hist(project)
    h.Background[0][1] = False
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for key, value in h.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False


def enable_ordinary(project) -> None:
    h = hist(project)
    h.Background[0][1] = True
    h.SampleParameters["Scale"] = [1.0, False]
    h.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.data["Histograms"][h.name]["Scale"][1] = True


def mass_fractions(project) -> dict[str, float]:
    h = hist(project)
    try:
        return {name: float(value[0]) for name, value in h.ComputeMassFracs().items()}
    except Exception:
        values = {
            phase.name: max(
                0.0,
                float(phase.data["General"]["Mass"])
                * float(phase.data["Histograms"][h.name]["Scale"][0]),
            )
            for phase in project.phases()
        }
        total = sum(values.values())
        return {key: value / total for key, value in values.items()}


def geometry(project) -> dict:
    result = {}
    for phase in project.phases():
        controls, data = phase.InitDisAgl(False)
        controls["Factors"] = [1.25, 0.0]
        _, distances, _ = G2st.RetDistAngle(controls, data, dmin=0.01)
        atoms = phase.atoms()
        pairs = {}
        for center, rows in distances.items():
            for row in rows:
                other = int(row[0])
                pair = "-".join(sorted((atoms[center].element, atoms[other].element)))
                value = float(row[-2])
                pairs[pair] = min(pairs.get(pair, value), value)
        result[phase.name] = {
            "pair_min_A": pairs,
            "short_contacts": phase.ShortDistances(useAll=False),
        }
    return result


def state(project, stage: str) -> dict:
    h = hist(project)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": stage,
        "Rwp_percent": h.get_wR(),
        "Rp_percent": h.residuals.get("R"),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(value) for value in project.get_Frozen()],
        "fractions": mass_fractions(project),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "geometry": geometry(project),
        "coordinates": {
            phase.name: [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": list(atom.coordinates),
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ]
            for phase in project.phases()
        },
    }


def run(project, outdir: Path, records: list[dict], stage: str, cycles=8) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = state(project, stage)
    records.append(record)
    shutil.copy2(project.filename, outdir / f"{len(records):02d}_{stage}.gpx")
    print(json.dumps(record, default=str), flush=True)


def set_coordinate_group(project, phase_name: str | None, element_group: str) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            selected_phase = phase_name is None or phase.name == phase_name
            is_oxygen = atom.element.strip().upper() in {"O", "O-2"}
            selected_element = (
                element_group == "all"
                or (element_group == "oxygen" and is_oxygen)
                or (element_group == "heavy" and not is_oxygen)
            )
            atom.refinement_flags = "X" if selected_phase and selected_element else " "


def install_bounds(project, source_coordinates) -> None:
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    project.index_ids()
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    for phase in project.phases():
        pid = int(phase.data["pId"])
        cell = phase.get_cell()
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        reciprocal = G2lat.cell2A(
            [
                cell["length_a"], cell["length_b"], cell["length_c"],
                cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
            ]
        )
        for index, value in enumerate(reciprocal):
            value = float(value)
            span = max(0.01 * abs(value), 0.0003)
            project.set_Controls("parmMin", value - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", value + span, variable=f"{pid}::A{index}")
        scale = float(phase.data["Histograms"][hist(project).name]["Scale"][0])
        project.set_Controls("parmMin", max(0.25 * scale, 1e-8), variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 4.0 * scale, variable=f"{pid}:0:Scale")
        for index, atom in enumerate(phase.atoms()):
            xyz = source_coordinates[(pid, index)]
            # ZnWO4 is an analogue-derived Ni->Zn model and needs a modestly
            # wider adaptation window than the exact-composition precursor
            # references. The final staged polish will use its own ±0.10 A
            # neighborhood around the accepted adapted checkpoint.
            cartesian_window = 0.12 if phase.name == "ZnWO4" else 0.10
            for axis, value, length in zip("xyz", xyz, lengths):
                half_width = cartesian_window / max(float(length), 1e-6)
                variable = f"{pid}::dA{axis}:{index}"
                project.set_Controls("parmMin", value - half_width, variable=variable)
                project.set_Controls("parmMax", value + half_width, variable=variable)
            project.set_Controls("parmMin", 0.001, variable=f"{pid}::AUiso:{index}")
            project.set_Controls("parmMax", 0.03, variable=f"{pid}::AUiso:{index}")


def prepare_isotropic_uiso(project, value=0.008) -> None:
    project.index_ids()
    for phase in project.phases():
        _, _, _, cia = phase.data["General"]["AtomPtrs"]
        for raw in phase.data["Atoms"]:
            raw[cia] = "I"
            raw[cia + 1] = float(value)
            for index in range(cia + 2, min(cia + 8, len(raw) - 1)):
                raw[index] = 0.0
    project.save()
    project.index_ids()
    for phase in project.phases():
        pid = int(phase.data["pId"])
        variables = [f"{pid}::AUiso:{index}" for index, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)


def main() -> None:
    args = arguments()
    source = Path(args.input).resolve()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    outdir = output.parent / f".{output.stem}_structure"
    outdir.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    clear_flags(project)
    prepare_isotropic_uiso(project)
    source_coordinates = {
        (int(phase.data["pId"]), index): tuple(float(v) for v in atom.coordinates)
        for phase in project.phases()
        for index, atom in enumerate(phase.atoms())
    }
    install_bounds(project, source_coordinates)
    enable_ordinary(project)
    project.save()

    records = [state(project, "prepared")]
    run(project, outdir, records, "ordinary_settle", 8)

    # Principal phase first, then the two supported residual precursors.
    for phase_name in [phase.name for phase in project.phases()]:
        set_coordinate_group(project, phase_name, "heavy")
        run(project, outdir, records, f"{phase_name}_heavy", 8)
        set_coordinate_group(project, phase_name, "oxygen")
        run(project, outdir, records, f"{phase_name}_oxygen", 8)
        set_coordinate_group(project, phase_name, "all")
        run(project, outdir, records, f"{phase_name}_joint", 8)

    set_coordinate_group(project, None, "all")
    run(project, outdir, records, "all_coordinates_joint", 10)
    # Thermal factors are fitted only after the analogue coordinates have
    # stabilized; otherwise scale/Uiso compensation can suppress minor phases.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "U"
    run(project, outdir, records, "phase_tied_uiso", 8)
    set_coordinate_group(project, None, "none")
    run(project, outdir, records, "final_ordinary_settle", 8)

    (outdir / "refinement.json").write_text(json.dumps(records, indent=2, default=str) + "\n")
    project.save()


if __name__ == "__main__":
    main()
