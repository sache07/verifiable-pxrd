from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


def main():
    source = Path(sys.argv[1])
    phase_index = int(sys.argv[2])
    limit = float(sys.argv[3])
    output = Path(sys.argv[4])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    phase = project.phase(phase_index)
    phase.set_refinements({"Atoms": {"all": "X"}})
    project.index_ids()
    for i, atom in enumerate(phase.atoms()):
        for axis, center in zip("xyz", atom.coordinates):
            variable = f"{phase.id}::dA{axis}:{i}"
            # Despite the historical dA variable name, GSAS-II applies limits
            # to the absolute fractional coordinate, not to a zero-centered
            # increment.
            project.set_Controls("parmMin", center - limit, variable=variable)
            project.set_Controls("parmMax", center + limit, variable=variable)
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.refine(printFile=str(output.with_suffix(".lst")))
    project.save(str(output))
    h = project.histogram(0)
    result = {
        "phase": phase.name,
        "coordinate_delta_limit_fractional": limit,
        "Rwp": h.residuals.get("wR"),
        "mass_fractions": {k: v[0] for k, v in h.ComputeMassFracs().items()},
        "frozen": project.get_Frozen(),
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
