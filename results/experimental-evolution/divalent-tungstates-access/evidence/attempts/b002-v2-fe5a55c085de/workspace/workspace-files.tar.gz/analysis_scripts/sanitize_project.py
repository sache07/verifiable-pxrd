from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


def main():
    source, output = map(Path, sys.argv[1:3])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    # Remove the experimental Uiso equivalences. Fixed positive per-phase Uiso
    # values are safer than a poorly conditioned ADP/polarization tradeoff.
    project.get_Constraints("Phase")[:] = []
    for phase, value in zip(project.phases(), [0.006, 0.010]):
        for atom in phase.atoms():
            atom.uiso = value
            atom.refinement_flags = "X"
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.refine(printFile=str(output.with_suffix(".lst")))
    project.save(str(output))
    h = project.histogram(0)
    result = {
        "Rwp": h.residuals.get("wR"),
        "mass_fractions": {k: v[0] for k, v in h.ComputeMassFracs().items()},
        "frozen": project.get_Frozen(),
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
