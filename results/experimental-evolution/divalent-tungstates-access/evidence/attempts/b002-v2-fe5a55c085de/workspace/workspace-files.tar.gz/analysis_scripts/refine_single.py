from pathlib import Path
import json
import sys
import traceback

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "working"
GPX = WORK / "single_znwo4.gpx"


def background_coefficients(x, y, degree=11):
    """A conservative lower-envelope start for a Chebyshev background."""
    edges = np.linspace(0, len(x), 91, dtype=int)
    xb, yb = [], []
    for lo, hi in zip(edges[:-1], edges[1:]):
        if hi <= lo:
            continue
        xb.append(np.median(x[lo:hi]))
        yb.append(np.percentile(y[lo:hi], 10))
    xb, yb = np.asarray(xb), np.asarray(yb)
    t = 2 * (xb - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(t, yb, degree).tolist()


def report(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    hap = phase.data["Histograms"][hist.name]
    cov = project.data.get("Covariance", {}).get("data", {})
    cell = phase.get_cell()
    values = {
        "step": label,
        "Rwp": hist.residuals.get("wR"),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "cell": [
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ],
        "zero": inst["Zero"][1],
        "U": inst["U"][1],
        "W": inst["W"][1],
        "X": inst["X"][1],
        "SH_L": inst["SH/L"][1],
        "polarization": inst["Polariz."][1],
        "shift_um": sample["Shift"][0],
        "rough_A": sample["SurfRoughA"][0],
        "rough_B": sample["SurfRoughB"][0],
        "phase_scale": hap["Scale"][0],
        "size": hap["Size"][1],
        "mustrain": hap["Mustrain"][1],
        "MD": hap["Pref.Ori."],
        "nvar": len(cov.get("varyList", [])),
    }
    print(json.dumps(values, default=float))


def refine(project, label, cycles=8):
    project.set_Controls("cycles", cycles)
    project.refine(printFile=str(WORK / f"single_{label}.lst"))
    report(project, label)


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(GPX))
    hist = project.add_powder_histogram(
        str(WORK / "pattern.xye"),
        str(WORK / "instrument.instprm"),
        fmthint="xye",
    )
    phase = project.add_phase(
        str(WORK / "znwo4_wolframite_initial.cif"),
        phasename="ZnWO4_wolframite",
        histograms=[hist],
        fmthint="CIF",
    )

    # Ensure the histogram is exactly the submitted observation and use the
    # generator's Bragg-Brentano sample convention.
    public = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    data = hist.data["data"][1]
    if not np.allclose(data[0], public[:, 0], rtol=0, atol=1e-9):
        raise RuntimeError("GSAS-II import changed the 2theta grid")
    if not np.allclose(data[1], public[:, 1], rtol=0, atol=1e-9):
        raise RuntimeError("GSAS-II import changed observed intensities")
    data[2][:] = 1.0 / np.maximum(data[1], 1.0)

    sp = hist.SampleParameters
    sp["Type"] = "Bragg-Brentano"
    sp["Scale"] = [1.0, False]
    sp["Gonio. radius"] = 200.0
    sp["Shift"] = [0.0, False]
    sp["Transparency"] = [0.0, False]
    sp["SurfRoughA"] = [0.0, False]
    sp["SurfRoughB"] = [0.0, False]

    x, y = data[0], data[1]
    bkg = background_coefficients(x, y, degree=11)
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(bkg),
                "coeffs": bkg,
                "refine": True,
            },
        }
    )

    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 100.0
    for atom in phase.atoms():
        atom.uiso = 0.01

    refine(project, "scale_background", 6)

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "cell_zero", 10)

    # Peak-shape terms first, then specimen displacement. V, Y and Z are zero
    # in the generating family and remain fixed.
    hist.set_refinements(
        {"Instrument Parameters": ["U", "W", "X", "SH/L"]}
    )
    refine(project, "instrument_profile", 10)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "sample_shift", 10)

    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        [hist],
    )
    refine(project, "sample_broadening", 12)

    # Coordinates can legitimately differ from the transferred prototype.
    phase.set_refinements({"Atoms": {"all": "X"}})
    refine(project, "coordinates", 12)

    # The synthetic specimen applies one isotropic Uiso to the complete phase.
    # Enforce that physically meaningful common parameter during refinement.
    phase.set_refinements({"Atoms": {"all": "XU"}})
    project.add_EquivConstr(
        [f"0::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
    )
    refine(project, "common_uiso", 12)

    # Polarization is uncalibrated; allow it to adjust only after the atomic
    # model and profile are stable.
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "polarization", 12)
    project.save(str(GPX))


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        sys.exit(1)
