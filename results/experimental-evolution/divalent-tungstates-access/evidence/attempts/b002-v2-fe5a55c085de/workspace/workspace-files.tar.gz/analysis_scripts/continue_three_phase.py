from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


def main():
    source, output = map(Path, sys.argv[1:3])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    zno = project.phase(2)
    hap = zno.data["Histograms"][hist.name]
    # The first three-phase pass drove this small-domain phase's isotropic
    # microstrain through zero. Keep the physical boundary value fixed rather
    # than letting a frozen, negative least-squares value spoil convergence.
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2][0] = False
    project.set_Controls("cycles", 30)
    project.refine(printFile=str(output.with_suffix(".lst")))
    project.save(str(output))
    cov = project.data["Covariance"]["data"]
    result = {
        "Rwp": hist.residuals.get("wR"),
        "mass_fractions": {k: v[0] for k, v in hist.ComputeMassFracs().items()},
        "converged": cov.get("Rvals", {}).get("converged"),
        "max_shift_over_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "message": cov.get("Rvals", {}).get("msg"),
        "frozen": project.get_Frozen(),
        "zno_cell": zno.get_cell(),
        "zno_size_um": hap["Size"][1][0],
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
