from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


def main():
    source = Path(sys.argv[1])
    phase_index = int(sys.argv[2])
    axis = [int(v) for v in sys.argv[3].split(",")]
    output = Path(sys.argv[4])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = axis
    project.index_ids()
    project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:{hist.id}:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:{hist.id}:MD")
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.refine(printFile=str(output.with_suffix(".lst")))
    hap = project.phase(phase_index).data["Histograms"][hist.name]
    result = {
        "phase": phase.name,
        "axis": axis,
        "Rwp": project.histogram(0).residuals.get("wR"),
        "MD": hap["Pref.Ori."],
        "frozen": project.get_Frozen(),
        "output": str(output),
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    project.save(str(output))
    print(json.dumps(result))


if __name__ == "__main__":
    main()
