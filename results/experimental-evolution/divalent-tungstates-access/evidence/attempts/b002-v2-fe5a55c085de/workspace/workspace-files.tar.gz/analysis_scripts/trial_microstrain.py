from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


def bound(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def main():
    source = Path(sys.argv[1])
    phase_index = int(sys.argv[2])
    axis_text = sys.argv[3]
    output = Path(sys.argv[4])
    axis = [int(v) for v in axis_text.split(",")]
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.data["Histograms"][hist.name]
    start = float(hap["Mustrain"][1][0])
    phase.setSampleProfile(hist, "microstrain", "uniaxial", start, start, axis)
    phase.set_HAP_refinements(
        {"Mustrain": {"type": "uniaxial", "refine": True, "direction": axis}},
        [hist],
    )
    project.index_ids()
    bound(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 8000.0)
    bound(project, f"{phase.id}:{hist.id}:Mustrain;a", 0.0, 8000.0)
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.refine(printFile=str(output.with_suffix(".lst")))
    hap = project.phase(phase_index).data["Histograms"][hist.name]
    result = {
        "phase": phase.name,
        "axis": axis,
        "Rwp": project.histogram(0).residuals.get("wR"),
        "mustrain": hap["Mustrain"],
        "frozen": project.get_Frozen(),
        "output": str(output),
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    project.save(str(output))
    print(json.dumps(result))


if __name__ == "__main__":
    main()
