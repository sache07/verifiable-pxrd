from pathlib import Path
import copy
import json
import sys

from GSASII import GSASIIscriptable as G2


def freeze_histogram(hist):
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False


def freeze_phase(phase, hist):
    phase.data["General"]["Cell"][0] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = False
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False


def main():
    source, cif, label, output = map(Path, sys.argv[1:5])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    project.get_Constraints("Phase")[:] = []
    project.set_Frozen()
    hist = project.histogram(0)
    freeze_histogram(hist)
    for phase in project.phases():
        freeze_phase(phase, hist)

    old = project.phase(1)
    old_hap = old.data["Histograms"][hist.name]
    old_hap["Scale"] = [0.0, False]
    candidate = project.add_phase(
        str(cif), phasename=label.name, histograms=[hist], fmthint="CIF"
    )
    hap = candidate.data["Histograms"][hist.name]
    hap["Scale"] = [4.5, True]
    hap["Size"] = copy.deepcopy(old_hap["Size"])
    hap["Mustrain"] = copy.deepcopy(old_hap["Mustrain"])
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    for atom in candidate.atoms():
        atom.uiso = 0.010
        atom.refinement_flags = " "
    candidate.set_refinements({"Cell": True})
    project.index_ids()
    project.set_Controls("parmMin", 0.0, variable=f"{candidate.id}:{hist.id}:Scale")
    project.set_Controls("cycles", 12)
    project.refine(printFile=str(output.with_suffix(".lst")))
    candidate = project.phase(label.name)
    hap = candidate.data["Histograms"][hist.name]
    cell = candidate.get_cell()
    result = {
        "candidate": label.name,
        "Rwp": project.histogram(0).residuals.get("wR"),
        "scale": hap["Scale"][0],
        "cell": [
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ],
        "frozen": project.get_Frozen(),
        "output": str(output),
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    project.save(str(output))
    print(json.dumps(result))


if __name__ == "__main__":
    main()
