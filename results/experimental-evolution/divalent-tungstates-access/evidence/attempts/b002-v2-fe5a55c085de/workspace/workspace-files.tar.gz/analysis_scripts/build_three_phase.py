from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def set_bound(project, variable, low, high):
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def main():
    source, output = map(Path, sys.argv[1:3])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    project.get_Constraints("Phase")[:] = []
    project.set_Frozen()
    hist = project.histogram(0)
    hist.Background[0][1] = True
    inst = hist.InstrumentParameters
    for name in ["Zero", "W", "SH/L", "Polariz."]:
        inst[name][2] = True
    inst["U"][1:3] = [0.0, False]
    inst["X"][1:3] = [0.1, False]
    sample = hist.SampleParameters
    sample["Shift"] = [-500.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    p0, p1, p2 = project.phases()
    for phase in (p0, p1, p2):
        phase.set_HAP_refinements(
            {
                "Scale": True,
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }, [hist]
        )
    p0.set_refinements({"Cell": True, "Atoms": {"all": "X"}})
    p1.set_refinements({"Cell": True})
    p2.set_refinements({"Cell": True})
    for atom in p0.atoms():
        atom.uiso = 0.006
        atom.refinement_flags = "X"
    for atom in p1.atoms():
        atom.uiso = 0.010
        atom.refinement_flags = " "
    for atom in p2.atoms():
        # The reference ZnO model carries physically positive anisotropic
        # displacement tensors; retain them rather than coercing to Uiso.
        atom.refinement_flags = " "

    h0 = p0.data["Histograms"][hist.name]
    h1 = p1.data["Histograms"][hist.name]
    h2 = p2.data["Histograms"][hist.name]
    h0["Pref.Ori."][2] = True
    h1["Pref.Ori."][2] = True
    h2["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    # Start the low-level residual precursor with a moderate independent profile.
    p2.setSampleProfile(hist, "size", "isotropic", 0.15)
    p2.setSampleProfile(hist, "microstrain", "isotropic", 1000.0)
    p2.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }, [hist]
    )

    project.index_ids()
    set_bound(project, ":0:Zero", -0.25, 0.25)
    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:SH/L", 0.005, 0.10)
    set_bound(project, ":0:Polariz.", 0.5, 1.0)
    for phase in (p0, p1, p2):
        set_bound(project, f"{phase.id}:{hist.id}:Scale", 0.0, 1e6)
        set_bound(project, f"{phase.id}:{hist.id}:Size;i", 0.04, 1.5)
        set_bound(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 8000.0)
    set_bound(project, f"{p0.id}:{hist.id}:MD", 0.7, 1.4)
    set_bound(project, f"{p1.id}:{hist.id}:MD", 0.7, 1.4)

    # For ZnO, permit only the generator's +/-0.5% linear reference mismatch.
    cell = p2.data["General"]["Cell"][1:7]
    avec = G2lat.cell2A(cell)
    for index in [0, 2]:
        set_bound(
            project, f"{p2.id}::A{index}",
            avec[index] * 0.990, avec[index] * 1.010,
        )

    project.set_Controls("cycles", 22)
    project.refine(printFile=str(output.with_suffix(".lst")))
    project.save(str(output))
    h = project.histogram(0)
    result = {
        "Rwp": h.residuals.get("wR"),
        "mass_fractions": {k: v[0] for k, v in h.ComputeMassFracs().items()},
        "frozen": project.get_Frozen(),
        "zno_cell": p2.get_cell(),
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
