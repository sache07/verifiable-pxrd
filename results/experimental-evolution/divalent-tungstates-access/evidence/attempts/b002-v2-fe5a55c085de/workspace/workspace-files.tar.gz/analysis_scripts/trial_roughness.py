from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


def main():
    source, output = map(Path, sys.argv[1:3])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = project.histogram(0)
    hist.SampleParameters["SurfRoughA"] = [0.25, True]
    hist.SampleParameters["SurfRoughB"] = [0.08, True]
    project.index_ids()
    for var, low, high in [
        (":0:SurfRoughA", 0.05, 0.60),
        (":0:SurfRoughB", 0.02, 0.50),
    ]:
        project.set_Controls("parmMin", low, variable=var)
        project.set_Controls("parmMax", high, variable=var)
    project.set_Frozen()
    project.set_Controls("cycles", 15)
    project.refine(printFile=str(output.with_suffix(".lst")))
    hist = project.histogram(0)
    result = {
        "Rwp": hist.residuals.get("wR"),
        "SurfRoughA": hist.SampleParameters["SurfRoughA"],
        "SurfRoughB": hist.SampleParameters["SurfRoughB"],
        "frozen": project.get_Frozen(),
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    project.save(str(output))
    print(json.dumps(result))


if __name__ == "__main__":
    main()
