from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


def main():
    source = Path(sys.argv[1])
    shift = float(sys.argv[2])
    output = Path(sys.argv[3])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = project.histogram(0)
    hist.SampleParameters["Shift"] = [shift, False]
    # Restart variables that previously touched a bound; each trial is a fresh
    # conditional refinement at fixed specimen displacement.
    hist.InstrumentParameters["Zero"][1] = 0.15
    hist.InstrumentParameters["Zero"][2] = True
    hist.InstrumentParameters["SH/L"][1] = 0.02
    hist.InstrumentParameters["SH/L"][2] = True
    wo3_hap = project.phase(1).data["Histograms"][hist.name]
    wo3_hap["Size"][1][0] = 0.06
    wo3_hap["Size"][2][0] = True
    wo3_hap["Mustrain"][1][0] = 500.0
    wo3_hap["Mustrain"][2][0] = True
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.refine(printFile=str(output.with_suffix(".lst")))
    result = {
        "shift_um": shift,
        "Rwp": project.histogram(0).residuals.get("wR"),
        "zero": project.histogram(0).InstrumentParameters["Zero"][1],
        "frozen": project.get_Frozen(),
        "output": str(output),
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    project.save(str(output))
    print(json.dumps(result))


if __name__ == "__main__":
    main()
