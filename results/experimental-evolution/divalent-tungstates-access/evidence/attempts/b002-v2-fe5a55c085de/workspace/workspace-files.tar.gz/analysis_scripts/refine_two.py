from pathlib import Path
import json
import sys
import traceback

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "working"
GPX = WORK / "two_phase_base.gpx"


def initial_background(x, y, degree=15):
    edges = np.linspace(0, len(x), 121, dtype=int)
    xb, yb = [], []
    for lo, hi in zip(edges[:-1], edges[1:]):
        if hi > lo:
            xb.append(np.median(x[lo:hi]))
            yb.append(np.percentile(y[lo:hi], 8))
    t = 2 * (np.asarray(xb) - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(t, yb, degree).tolist()


def set_bound(project, variable, low, high):
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def report(project, label):
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        c = phase.get_cell()
        rows.append(
            {
                "name": phase.name,
                "scale": hap["Scale"][0],
                "cell": [
                    c["length_a"], c["length_b"], c["length_c"],
                    c["angle_alpha"], c["angle_beta"], c["angle_gamma"],
                ],
                "size": hap["Size"][1],
                "mustrain": hap["Mustrain"][1],
                "MD": hap["Pref.Ori."],
                "uiso": [a.uiso for a in phase.atoms()],
            }
        )
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "stage": label,
        "Rwp": hist.residuals.get("wR"),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "instrument": {k: inst[k][1] for k in ["Zero", "U", "W", "X", "SH/L", "Polariz."]},
        "sample": {k: sample[k][0] for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "phases": rows,
        "frozen": project.get_Frozen(),
        "nvar": len(cov.get("varyList", [])),
    }
    print(json.dumps(result, default=float))
    (WORK / f"two_{label}.json").write_text(json.dumps(result, indent=2, default=float) + "\n")


def refine(project, label, cycles=10):
    project.set_Controls("cycles", cycles)
    project.refine(printFile=str(WORK / f"two_{label}.lst"))
    report(project, label)
    project.save(str(WORK / f"two_{label}.gpx"))


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(GPX))
    hist = project.add_powder_histogram(
        str(WORK / "pattern.xye"), str(WORK / "instrument.instprm"), fmthint="xye"
    )
    phases = [
        project.add_phase(
            str(WORK / "znwo4_wolframite_initial.cif"),
            phasename="ZnWO4_wolframite", histograms=[hist], fmthint="CIF"
        ),
        project.add_phase(
            str(WORK / "wo3_2311041_initial.cif"),
            phasename="WO3_monoclinic", histograms=[hist], fmthint="CIF"
        ),
    ]
    public = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    data = hist.data["data"][1]
    if not np.allclose(data[0], public[:, 0], rtol=0, atol=1e-9) or not np.allclose(
        data[1], public[:, 1], rtol=0, atol=1e-9
    ):
        raise RuntimeError("GSAS-II import changed the public observation")
    data[2][:] = 1.0 / np.maximum(data[1], 1.0)

    sample = hist.SampleParameters
    sample["Scale"] = [1.0, False]
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    # Remove exact profile degeneracies by putting common sec(theta) and
    # tan(theta)^2 broadening into phase size/strain. This leaves a fully
    # physical positive profile while retaining the same observable family.
    inst = hist.InstrumentParameters
    inst["U"][1:3] = [0.0, False]
    inst["X"][1:3] = [0.1, False]
    inst["W"][1] = 10.0
    inst["SH/L"][1] = 0.03

    x, y = data[0], data[1]
    bkg = initial_background(x, y)
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1", "no. coeffs": len(bkg),
                "coeffs": bkg, "refine": True,
            },
        }
    )
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [5.0, True]
        phase.setSampleProfile(hist, "size", "isotropic", 0.20)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0)
        for atom in phase.atoms():
            atom.uiso = 0.01

    project.index_ids()
    set_bound(project, ":0:Zero", -0.25, 0.25)
    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:SH/L", 0.005, 0.10)
    set_bound(project, ":0:Polariz.", 0.5, 1.0)
    set_bound(project, ":0:Shift", -800.0, 800.0)
    for phase in phases:
        set_bound(project, f"{phase.id}:{hist.id}:Scale", 0.0, 1e6)
        set_bound(project, f"{phase.id}:{hist.id}:Size;i", 0.04, 1.5)
        set_bound(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 8000.0)
        for i, _ in enumerate(phase.atoms()):
            set_bound(project, f"{phase.id}::AUiso:{i}", 0.003, 0.020)

    refine(project, "scales_background", 8)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "cells_zero", 12)

    hist.set_refinements({"Instrument Parameters": ["W", "SH/L"]})
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }, [hist]
        )
    refine(project, "profiles", 15)

    phases[0].set_refinements({"Atoms": {"all": "X"}})
    refine(project, "znwo4_coordinates", 15)

    phases[1].set_refinements({"Atoms": {"all": "X"}})
    refine(project, "all_coordinates", 18)

    # One common isotropic displacement parameter per synthetic phase.
    for phase in phases:
        phase.set_refinements({"Atoms": {"all": "XU"}})
        vars_ = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(vars_) > 1:
            project.add_EquivConstr(vars_)
    refine(project, "uiso", 15)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "polarization", 15)
    project.save(str(GPX))


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        sys.exit(1)
