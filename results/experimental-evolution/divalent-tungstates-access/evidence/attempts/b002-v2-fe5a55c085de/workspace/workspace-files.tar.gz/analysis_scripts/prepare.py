from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "working"
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)


def cod_path(record_id: str) -> Path:
    return LIB / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


WORK.mkdir(exist_ok=True)

# Preserve the exact public grid and observed counts in a generic GSAS-II xye file.
xy = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
sigma = np.sqrt(np.maximum(xy[:, 1], 1.0))
np.savetxt(
    WORK / "pattern.xye",
    np.column_stack((xy, sigma)),
    fmt=["%.8f", "%.8f", "%.10f"],
)

# Wolframite prototype transfer: CoMoO4-II (COD 7205001, P2/c) -> ZnWO4.
structure = Structure.from_file(cod_path("7205001"), primitive=False)
structure.replace_species({"Co": "Zn", "Mo": "W"})
structure.remove_oxidation_states()
CifWriter(structure, symprec=1e-5, significant_figures=10).write_file(
    WORK / "znwo4_wolframite_initial.cif"
)

# The best-matching ordinary reference for the residual is monoclinic WO3
# (COD 2311041). Normalize the source through pymatgen so oxidation-state
# decorations and source-specific ADP conventions do not enter GSAS-II.
wo3 = Structure.from_file(cod_path("2311041"), primitive=False)
wo3.remove_oxidation_states()
CifWriter(wo3, symprec=1e-5, significant_figures=10).write_file(
    WORK / "wo3_2311041_initial.cif"
)

for record_id in [
    "1004057", "1010618", "1521532", "1521533", "1528915",
    "1563541", "2106293", "2107312", "2311041",
]:
    candidate = Structure.from_file(cod_path(record_id), primitive=False)
    candidate.remove_oxidation_states()
    CifWriter(candidate, symprec=1e-5, significant_figures=10).write_file(
        WORK / f"wo3_{record_id}_normalized.cif"
    )

# Nominal dual-wavelength Cu K-alpha profile. All uncertain profile terms are
# initialized inside the middle of the laboratory ranges and then refined.
(WORK / "instrument.instprm").write_text(
    "# GSAS-II instrument parameter file\n"
    "Type:PXC;Bank:1\n"
    "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
    "Zero:0.0;Polariz.:0.8;Azimuth:0.0\n"
    "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
)

print(WORK / "znwo4_wolframite_initial.cif")
