from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


def set_bound(project, variable, low, high):
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def main():
    source, output = map(Path, sys.argv[1:3])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    project.get_Constraints("Phase")[:] = []
    project.set_Frozen()
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    sample["Shift"] = [-500.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    inst["Zero"][1:3] = [0.06, True]
    inst["U"][1:3] = [0.0, False]
    inst["X"][1:3] = [0.1, False]
    inst["W"][1:3] = [7.5, True]
    inst["SH/L"][1:3] = [0.015, True]
    inst["Polariz."][1:3] = [0.94, True]

    p0, p1 = project.phases()
    h0 = p0.data["Histograms"][hist.name]
    h1 = p1.data["Histograms"][hist.name]
    p0.setSampleProfile(hist, "size", "isotropic", 0.072)
    p0.setSampleProfile(hist, "microstrain", "isotropic", 1200.0)
    p1.setSampleProfile(hist, "size", "isotropic", 0.095)
    p1.setSampleProfile(hist, "microstrain", "isotropic", 1550.0)
    for phase in (p0, p1):
        phase.set_HAP_refinements(
            {
                "Scale": True,
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }, [hist]
        )
        phase.set_refinements({"Cell": True})
    h0["Pref.Ori."][0:4] = ["MD", 0.72, True, [1, 1, 1]]
    h1["Pref.Ori."][0:4] = ["MD", 1.06, True, [1, 0, 0]]

    for atom in p0.atoms():
        atom.uiso = 0.006
        atom.refinement_flags = "X"
    for atom in p1.atoms():
        atom.uiso = 0.010
        atom.refinement_flags = " "

    project.index_ids()
    set_bound(project, ":0:Zero", -0.25, 0.25)
    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:SH/L", 0.005, 0.10)
    set_bound(project, ":0:Polariz.", 0.5, 1.0)
    for phase in (p0, p1):
        set_bound(project, f"{phase.id}:{hist.id}:Scale", 0.0, 1e6)
        set_bound(project, f"{phase.id}:{hist.id}:Size;i", 0.04, 1.5)
        set_bound(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 8000.0)
        set_bound(project, f"{phase.id}:{hist.id}:MD", 0.7, 1.4)

    project.set_Controls("cycles", 20)
    project.refine(printFile=str(output.with_suffix(".lst")))
    project.save(str(output))
    result = {
        "Rwp": project.histogram(0).residuals.get("wR"),
        "mass_fractions": {
            k: v[0] for k, v in project.histogram(0).ComputeMassFracs().items()
        },
        "frozen": project.get_Frozen(),
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
