from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


def main():
    source, cif, output = map(Path, sys.argv[1:4])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    temporary = G2.G2Project(newgpx=str(output.with_name("coordinate_source_tmp.gpx")))
    reference = temporary.add_phase(
        str(cif), phasename="WO3_coordinate_source", fmthint="CIF"
    )
    phase = project.phase(1)
    old_atoms = list(phase.atoms())
    ref_atoms = list(reference.atoms())
    if len(old_atoms) != len(ref_atoms):
        raise RuntimeError("WO3 source and project have different asymmetric-unit sizes")
    for old, ref in zip(old_atoms, ref_atoms):
        if old.element != ref.element:
            raise RuntimeError("WO3 atom ordering differs from the normalized source")
        old.coordinates = ref.coordinates
        old.uiso = 0.010
        old.refinement_flags = " "
    project.get_Constraints("Phase")[:] = []
    project.set_Frozen()
    project.set_Controls("cycles", 18)
    project.refine(printFile=str(output.with_suffix(".lst")))
    project.save(str(output))
    h = project.histogram(0)
    result = {
        "Rwp": h.residuals.get("wR"),
        "mass_fractions": {k: v[0] for k, v in h.ComputeMassFracs().items()},
        "frozen": project.get_Frozen(),
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
