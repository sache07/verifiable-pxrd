from pathlib import Path
import copy
import json
import sys

from GSASII import GSASIIscriptable as G2


def freeze_project(project):
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False


def main():
    source, cif, name, output = map(Path, sys.argv[1:5])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    freeze_project(project)
    hist = project.histogram(0)
    reference_hap = project.phase(0).data["Histograms"][hist.name]
    phase = project.add_phase(
        str(cif), phasename=name.name, histograms=[hist], fmthint="CIF"
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    hap["Size"] = copy.deepcopy(reference_hap["Size"])
    hap["Mustrain"] = copy.deepcopy(reference_hap["Mustrain"])
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    phase.set_refinements({"Cell": True})
    project.index_ids()
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    project.set_Controls("cycles", 10)
    project.refine(printFile=str(output.with_suffix(".lst")))
    phase = project.phase(name.name)
    hap = phase.data["Histograms"][hist.name]
    cell = phase.get_cell()
    result = {
        "phase": name.name,
        "Rwp": project.histogram(0).residuals.get("wR"),
        "scale": hap["Scale"][0],
        "cell": [
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ],
        "frozen": project.get_Frozen(),
        "output": str(output),
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    project.save(str(output))
    print(json.dumps(result))


if __name__ == "__main__":
    main()
