from pathlib import Path
import copy
import json
import sys

from GSASII import GSASIIscriptable as G2


def freeze(project):
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    return hist


def main():
    source, cif, label, output = map(Path, sys.argv[1:5])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    project.get_Constraints("Phase")[:] = []
    project.set_Frozen()
    hist = freeze(project)
    reference = project.phase(0).data["Histograms"][hist.name]
    phase = project.add_phase(
        str(cif), phasename=label.name, histograms=[hist], fmthint="CIF"
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.5, True]
    hap["Size"] = copy.deepcopy(reference["Size"])
    hap["Mustrain"] = copy.deepcopy(reference["Mustrain"])
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    phase.data["General"]["Cell"][0] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "
    project.index_ids()
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    project.set_Controls("cycles", 6)
    project.refine(printFile=str(output.with_suffix(".lst")))
    phase = project.phase(label.name)
    scale = phase.data["Histograms"][hist.name]["Scale"][0]
    result = {
        "phase": label.name,
        "Rwp": project.histogram(0).residuals.get("wR"),
        "scale": scale,
        "frozen": project.get_Frozen(),
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    project.save(str(output))
    print(json.dumps(result))


if __name__ == "__main__":
    main()
