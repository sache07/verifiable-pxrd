from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "working"
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)


def cod_path(record_id):
    return LIB / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


records = {
    "triclinic_from_znmoo4_1528282": ("1528282", {"Mo": "W"}),
    "scheelite_from_cdw04_1549132": ("1549132", {"Cd": "Zn"}),
    "c2c_from_hgwo4_2012578": ("2012578", {"Hg": "Zn"}),
    "c2c_from_cawo4_1546035": ("1546035", {"Ca": "Zn"}),
    "p21c_from_pbwo4_9007617": ("9007617", {"Pb": "Zn"}),
}
target_volume_per_formula = 66.55
for name, (record_id, substitutions) in records.items():
    structure = Structure.from_file(cod_path(record_id), primitive=False)
    structure.remove_oxidation_states()
    structure.replace_species(substitutions)
    n_formula = len(structure) / 6.0
    structure.scale_lattice(target_volume_per_formula * n_formula)
    CifWriter(structure, symprec=1e-5, significant_figures=10).write_file(
        WORK / f"znwo4_distinct_{name}.cif"
    )
    distances = structure.distance_matrix.copy()
    np.fill_diagonal(distances, np.inf)
    print(
        name,
        structure.get_space_group_info(symprec=1e-3),
        "min_distance_A",
        float(distances.min()),
    )
