from pathlib import Path

import numpy as np
from pymatgen.analysis.structure_matcher import FrameworkComparator, StructureMatcher
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "working"
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)


def cod_path(record_id):
    return LIB / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


parent = Structure.from_file(cod_path("7205001"), primitive=False)
aligner = StructureMatcher(
    ltol=0.2,
    stol=0.3,
    angle_tol=5,
    primitive_cell=False,
    scale=True,
    attempt_supercell=True,
    allow_subset=False,
    comparator=FrameworkComparator(),
)

# A common target lattice keeps peak-position starting quality identical; only
# the distinct analogue fractional coordinates differ between trials.
lattice = Lattice.from_parameters(4.7037, 5.7350, 4.9346, 90.0, 90.62, 90.0)
target_species = []
for site in parent:
    symbol = site.specie.symbol
    target_species.append({"Co": "Zn", "Mo": "W"}.get(symbol, symbol))

records = {
    "como_7205001": "7205001",
    "inta_4329321": "4329321",
    "innb_1524100": "1524100",
    "mnre_2100243": "2100243",
    "fenb_2002235": "2002235",
    "invo_4336636": "4336636",
}
for name, record_id in records.items():
    candidate = Structure.from_file(cod_path(record_id), primitive=False)
    candidate.remove_oxidation_states()
    aligned = aligner.get_s2_like_s1(parent, candidate)
    if aligned is None or len(aligned) != len(parent):
        raise RuntimeError(f"Could not align wolframite analogue {record_id}")
    # get_s2_like_s1 orders aligned sites consistently with parent sites for
    # this 12-site family. Verify that the one-to-one distances are also the
    # nearest assignment before transferring the target chemistry.
    distances = parent.lattice.get_all_distances(parent.frac_coords, aligned.frac_coords)
    if not np.array_equal(np.argmin(distances, axis=1), np.arange(len(parent))):
        raise RuntimeError(f"Unexpected site ordering for analogue {record_id}")
    model = Structure(lattice, target_species, aligned.frac_coords)
    CifWriter(model, symprec=1e-5, significant_figures=10).write_file(
        WORK / f"znwo4_variant_{name}.cif"
    )
    print(name, record_id, model.get_space_group_info(symprec=1e-3))
