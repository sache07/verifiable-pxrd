"""Evaluate one aligned wolframite coordinate prototype in a fixed common state."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--candidate", required=True)
    parser.add_argument("--refine-coordinates", action="store_true")
    args = parser.parse_args()

    candidates = json.loads(Path("working/prototypes/wolframite_candidates.json").read_text())
    coordinates = candidates[args.candidate]
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.base, newgpx=str(out / "trial.gpx"))
    hist = project.histogram(0)
    phase = project.phase(0)
    for atom in phase.atoms():
        atom.coordinates = coordinates[atom.label]
        atom.refinement_flags = "X" if args.refine_coordinates else " "

    # The base already has every non-phase setting fixed. Refit only phase
    # scales, the established [111] texture ratio and optionally coordinates.
    project.set_Frozen()
    project.set_Controls("cycles", 16 if args.refine_coordinates else 12)
    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.refine()
    project.save()
    payload = {
        "candidate": args.candidate,
        "coordinate_refinement": args.refine_coordinates,
        "rwp": float(hist.residuals["wR"]),
        "ratio": float(phase.data["Histograms"][hist.name]["Pref.Ori."][1]),
        "scales": [float(p.data["Histograms"][hist.name]["Scale"][0]) for p in project.phases()],
        "coordinates": {a.label: list(map(float, a.coordinates)) for a in phase.atoms()},
        "vary_list": project.data["Covariance"]["data"].get("varyList", []),
    }
    (out / "summary.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload))


if __name__ == "__main__":
    main()
