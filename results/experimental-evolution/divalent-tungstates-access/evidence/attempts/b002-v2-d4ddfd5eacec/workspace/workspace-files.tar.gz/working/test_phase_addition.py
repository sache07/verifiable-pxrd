"""Add one candidate phase to a fixed common multiphase state and refine scales only."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIstrIO as G2stIO


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--cif", required=True)
    parser.add_argument("--size", type=float, required=True)
    parser.add_argument("--strain", type=float, required=True)
    parser.add_argument("--start-scale", type=float, default=2.0)
    args = parser.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.base, newgpx=str(out / "trial.gpx"))
    hist = project.histogram(0)

    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])

    candidate = project.add_phase(args.cif, phasename=args.name, histograms=[hist], fmthint="CIF")
    hap = candidate.data["Histograms"][hist.name]
    hap["Scale"] = [args.start_scale, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = args.size
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = args.strain
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    index = len(project.phases()) - 1
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.save()
    G2stIO.gpxSize = -1
    G2stIO.gpxIndex.clear()
    project.index_ids()
    project.set_Controls("parmMin", 0.0, variable=f"{index}:0:Scale")
    project.set_Controls("parmMax", 1e5, variable=f"{index}:0:Scale")
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.data["Controls"]["data"]["max cyc"] = 16
    project.data["Controls"]["data"]["min dM/M"] = 1e-8
    G2stIO.gpxSize = -1
    G2stIO.gpxIndex.clear()
    project.refine()
    project.save()

    mass_weights = [
        max(0.0, float(p.data["Histograms"][hist.name]["Scale"][0])) * float(p.data["General"]["Mass"])
        for p in project.phases()
    ]
    total = sum(mass_weights)
    payload = {
        "name": args.name,
        "size": args.size,
        "strain": args.strain,
        "rwp": float(hist.residuals["wR"]),
        "scales": [float(p.data["Histograms"][hist.name]["Scale"][0]) for p in project.phases()],
        "weight_fractions": [value / total for value in mass_weights],
        "candidate_cell": candidate.get_cell(),
        "frozen": project.data["Controls"]["data"].get("parmFrozen", {}),
    }
    (out / "summary.json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    print(json.dumps(payload, default=str))


if __name__ == "__main__":
    main()
