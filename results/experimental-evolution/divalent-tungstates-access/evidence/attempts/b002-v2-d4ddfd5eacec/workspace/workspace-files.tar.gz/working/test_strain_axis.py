"""Test one phase's uniaxial microstrain axis in a fixed common GSAS-II state."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--axis", required=True)
    args = parser.parse_args()
    axis = [int(value) for value in args.axis.split(",")]
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.base, newgpx=str(out / "trial.gpx"))
    hist = project.histogram(0)

    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])

    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    initial = float(hap["Mustrain"][1][0])
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = initial
    hap["Mustrain"][1][1] = initial
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    hap["Mustrain"][3] = axis
    hap["Size"][2][0] = True
    project.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{args.phase}:0:Mustrain;i")
    project.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;a")
    project.set_Controls("parmMax", 8000.0, variable=f"{args.phase}:0:Mustrain;a")
    project.set_Frozen()
    project.set_Controls("cycles", 16)
    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.refine()
    project.save()
    payload = {
        "phase": args.phase,
        "axis": axis,
        "rwp": float(hist.residuals["wR"]),
        "mustrain": hap["Mustrain"],
        "size": hap["Size"],
        "scales": [float(p.data["Histograms"][hist.name]["Scale"][0]) for p in project.phases()],
        "frozen": project.get_Frozen(),
    }
    (out / "summary.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload))


if __name__ == "__main__":
    main()
