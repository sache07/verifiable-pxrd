"""Reoptimize the supported ZnWO4 + WO3 + ZnO model in one common state."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def set_limit(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def freeze_all(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def enable_hap(phase, hist, *, scale=True, profile=False, texture=False) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = scale
    hap["Pref.Ori."][2] = texture
    if profile:
        hap["Size"][0] = "isotropic"
        hap["Size"][2][0] = True
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2][0] = True


def snapshot(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    return {
        "stage": stage,
        "rwp": float(hist.residuals["wR"]),
        "rp": float(hist.residuals["R"]),
        "profile_min": float(np.min(arrays[3])),
        "background_min": float(np.min(arrays[4])),
        "frozen": project.get_Frozen(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.base, newgpx=str(out / "trial.gpx"))
    hist = project.histogram(0)
    phases = project.phases()
    if len(phases) != 3:
        raise ValueError(f"Expected three phases, found {len(phases)}")
    freeze_all(project)

    # Laboratory and physical bounds.
    for variable, low, high in [
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
        ("0:0:MD", 0.7, 1.4),
    ]:
        set_limit(project, variable, low, high)
    for index, phase in enumerate(phases):
        set_limit(project, f"{index}:0:Scale", 0.0, 1e5)
        set_limit(project, f"{index}:0:Size;i", 0.04, 1.5)
        set_limit(project, f"{index}:0:Mustrain;i", 0.0, 8000.0)
        reciprocal = G2lat.cell2A(phase.data["General"]["Cell"][1:7])
        for term, value in enumerate(reciprocal):
            # Current states are already indexed/refined; this still permits
            # considerably more than the generator's <=0.5% mismatch.
            span = max(0.03 * abs(float(value)), 0.0005)
            set_limit(project, f"{index}::A{term}", float(value) - span, float(value) + span)

    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.set_Controls("cycles", 16)
    stages = []

    # First let only the newly introduced ZnO adapt, so it cannot be propped up
    # by wholesale changes elsewhere in the fit.
    for phase in phases:
        enable_hap(phase, hist, scale=True)
    phases[2].set_refinements({"Cell": True})
    project.set_Frozen()
    project.refine()
    project.save()
    stages.append(snapshot(project, "zno_cell"))

    enable_hap(phases[2], hist, scale=True, profile=True)
    project.set_Frozen()
    project.refine()
    project.save()
    stages.append(snapshot(project, "zno_profile"))

    # Ordinary full common-state refinement from the supported state.
    hist.data["Background"][0][1] = True
    for key in ["Zero", "U", "W", "SH/L", "Polariz."]:
        hist.data["Instrument Parameters"][0][key][2] = True
    hist.SampleParameters["Shift"][1] = True
    for index, phase in enumerate(phases):
        phase.set_refinements({"Cell": True})
        enable_hap(phase, hist, scale=True, profile=True, texture=index == 0)
    project.set_Frozen()
    project.refine()
    project.save()
    stages.append(snapshot(project, "common_full"))

    # Fresh pass after removing any parameters frozen while the project was
    # approaching a physical bound.
    project.set_Frozen()
    project.refine()
    project.save()
    stages.append(snapshot(project, "common_replay"))

    weights = []
    phase_rows = []
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        weight = max(0.0, float(hap["Scale"][0])) * float(phase.data["General"]["Mass"])
        weights.append(weight)
        phase_rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "mass": float(phase.data["General"]["Mass"]),
                "cell": {key: float(value) for key, value in phase.get_cell().items()},
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "uiso": [float(atom.uiso) for atom in phase.atoms()],
            }
        )
    total = sum(weights)
    for row, weight in zip(phase_rows, weights):
        row["weight_fraction"] = weight / total
    payload = {
        "stages": stages,
        "rwp": float(hist.residuals["wR"]),
        "rp": float(hist.residuals["R"]),
        "phases": phase_rows,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": {key: hist.SampleParameters[key] for key in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "background": hist.data["Background"],
        "frozen": project.get_Frozen(),
    }
    (out / "summary.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({"out": str(out), "rwp": payload["rwp"], "phases": phase_rows}, indent=2))


if __name__ == "__main__":
    main()
