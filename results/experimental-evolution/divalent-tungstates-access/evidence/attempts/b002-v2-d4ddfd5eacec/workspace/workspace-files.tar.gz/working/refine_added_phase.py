"""Refine only a newly added candidate phase within a fixed common project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def limit(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--cell-span", type=float, required=True)
    args = parser.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.base, newgpx=str(out / "trial.gpx"))
    hist = project.histogram(0)
    phases = project.phases()
    candidate_index = len(phases) - 1

    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for index, phase in enumerate(phases):
        phase.set_refinements({"Cell": index == candidate_index})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])

    candidate = phases[-1]
    hap = candidate.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][2][0] = True
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][2][0] = True
    limit(project, f"{candidate_index}:0:Scale", 0.0, 1e5)
    limit(project, f"{candidate_index}:0:Size;i", 0.04, 1.5)
    limit(project, f"{candidate_index}:0:Mustrain;i", 0.0, 8000.0)
    reciprocal = G2lat.cell2A(candidate.data["General"]["Cell"][1:7])
    for term, value in enumerate(reciprocal):
        span = max(args.cell_span * abs(float(value)), 0.0005)
        limit(project, f"{candidate_index}::A{term}", float(value) - span, float(value) + span)

    project.data["Controls"]["data"]["min dM/M"] = 1e-8
    project.set_Controls("cycles", 20)
    project.set_Frozen()
    status = "ok"
    try:
        project.refine()
    except Exception as exc:
        status = f"failed: {type(exc).__name__}: {exc}"
    project.save()

    weights = [
        max(0.0, float(phase.data["Histograms"][hist.name]["Scale"][0]))
        * float(phase.data["General"]["Mass"])
        for phase in phases
    ]
    total = sum(weights)
    payload = {
        "status": status,
        "rwp": float(hist.residuals.get("wR", float("nan"))),
        "scales": [float(p.data["Histograms"][hist.name]["Scale"][0]) for p in phases],
        "weight_fractions": [value / total for value in weights],
        "candidate_cell": candidate.get_cell(),
        "candidate_size": hap["Size"],
        "candidate_mustrain": hap["Mustrain"],
        "frozen": project.get_Frozen(),
    }
    (out / "summary.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload))


if __name__ == "__main__":
    main()
