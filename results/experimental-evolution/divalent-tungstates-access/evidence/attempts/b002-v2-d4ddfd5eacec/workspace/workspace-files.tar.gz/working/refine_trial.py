"""Staged, physically bounded GSAS-II refinement for phase-identification trials."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def parse_phase(value: str) -> tuple[str, str]:
    name, path = value.split("=", 1)
    return name, path


def set_limit(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def summarize(project: G2.G2Project, labels: list[str], stages: list[dict]) -> dict:
    hist = project.histogram(0)
    weighted = []
    phases = []
    for label, phase in zip(labels, project.phases()):
        hap = phase.data["Histograms"][hist.name]
        mass_weight = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        weighted.append(max(0.0, mass_weight))
        phases.append(
            {
                "name": label,
                "scale": float(hap["Scale"][0]),
                "mass": float(phase.data["General"]["Mass"]),
                "cell": {key: float(val) for key, val in phase.get_cell().items()},
                "size": [hap["Size"][0], *map(float, hap["Size"][1][:3])],
                "mustrain": [hap["Mustrain"][0], *map(float, hap["Mustrain"][1][:3])],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    total = sum(weighted)
    for phase, value in zip(phases, weighted):
        phase["weight_fraction"] = value / total if total else None
    inst = hist.data["Instrument Parameters"][0]
    arrays = hist.data["data"][1]
    return {
        "residuals": {key: (float(val) if isinstance(val, (int, float, np.number)) else val) for key, val in hist.residuals.items()},
        "phases": phases,
        "instrument": {key: list(val) for key, val in inst.items()},
        "sample": {key: hist.SampleParameters[key] for key in ["Scale", "Shift", "SurfRoughA", "SurfRoughB"]},
        "background": hist.data["Background"],
        "profile_min": float(np.min(arrays[3])),
        "background_min": float(np.min(arrays[4])),
        "frozen": project.get_Frozen(),
        "stages": stages,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    parser.add_argument("--phase", action="append", required=True, type=parse_phase)
    parser.add_argument("--cycles", type=int, default=10)
    args = parser.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(out / "trial.gpx"))
    G2.SetPrintLevel("warn")

    phases = []
    labels = []
    for label, path in args.phase:
        labels.append(label)
        phases.append(project.add_phase(path, phasename=label, fmthint="CIF"))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "working/instrument.instprm", phases=phases, fmthint="comma"
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 14,
                "coeffs": [900.0] + [0.0] * 13,
                "refine": True,
            }
        }
    )

    # Approximate absolute starting scales, with smaller starts for secondary phases.
    starts = [80.0, 8.0, 12.0, 5.0, 5.0]
    for index, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [starts[min(index, len(starts) - 1)], True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0

    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    project.set_Controls("cycles", args.cycles)
    project.save()

    # Bounds follow the supplied laboratory ranges. X is fixed because it is
    # exactly confounded with a common Lorentzian crystallite-size contribution.
    set_limit(project, ":0:Zero", -0.25, 0.25)
    set_limit(project, ":0:Shift", -800.0, 800.0)
    set_limit(project, ":0:U", 0.0, 40.0)
    set_limit(project, ":0:W", 2.0, 40.0)
    set_limit(project, ":0:SH/L", 0.005, 0.10)
    set_limit(project, ":0:Polariz.", 0.5, 1.0)
    for index in range(len(phases)):
        set_limit(project, f"{index}:0:Scale", 0.0, 1e5)
        set_limit(project, f"{index}:0:Size;i", 0.04, 1.5)
        set_limit(project, f"{index}:0:Mustrain;i", 0.0, 8000.0)
        # The first phase is an analogue-derived target and is allowed a wider
        # chemical cell change. Exact-composition references should need only
        # the stated <=0.5% synthetic reference mismatch.
        initial_a = G2lat.cell2A(phases[index].data["General"]["Cell"][1:7])
        relative_span = 0.15 if index == 0 else 0.03
        absolute_floor = 0.002 if index == 0 else 0.0005
        for term, value in enumerate(initial_a):
            span = max(abs(float(value)) * relative_span, absolute_floor)
            set_limit(project, f"{index}::A{term}", float(value) - span, float(value) + span)

    stages: list[dict] = []

    def refine(label: str) -> None:
        try:
            project.refine()
            status = "ok"
        except Exception as exc:  # retain failed trials as unknown, with diagnostics
            status = f"failed: {type(exc).__name__}: {exc}"
        project.save()
        stages.append(
            {
                "stage": label,
                "status": status,
                "rwp": float(hist.residuals.get("wR", np.nan)),
                "frozen": project.get_Frozen(),
            }
        )

    refine("background_scales")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine("cells_zero")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "SH/L"]})
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    refine("profiles")

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine("shift")

    # One final common-state pass after releasing parameters that may have
    # touched bounds in an earlier, less complete stage.
    project.set_Frozen()
    refine("common_replay")

    (out / "summary.json").write_text(json.dumps(summarize(project, labels, stages), indent=2) + "\n")
    print(json.dumps({"out": str(out), "stages": stages, "rwp": hist.residuals.get("wR")}, indent=2))


if __name__ == "__main__":
    main()
