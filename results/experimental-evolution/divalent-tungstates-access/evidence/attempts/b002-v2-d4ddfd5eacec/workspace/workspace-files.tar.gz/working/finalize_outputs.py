"""Materialize the selected fresh-replay GPX and submission artifacts."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp" / "final_texture_replay" / "trial.gpx"
FINAL = ROOT / "final.gpx"
CIF_NAMES = [
    "phase_1_ZnWO4_wolframite.cif",
    "phase_2_ZnO_wurtzite.cif",
    "phase_3_WO3_monoclinic.cif",
]
IDENTIFICATIONS = [
    "ZnWO4, wolframite type",
    "ZnO, wurtzite type",
    "WO3, monoclinic",
]
FORMULAS = ["ZnWO4", "ZnO", "WO3"]


def main() -> None:
    project = G2.G2Project(str(SOURCE), newgpx=str(FINAL))
    hist = project.histogram(0)
    phases = project.phases()
    if len(phases) != 3:
        raise ValueError(f"Expected three final phases, found {len(phases)}")

    # Remove metadata left by an earlier deleted trial phase. It does not
    # affect the profile, but keeping the final project internally tidy avoids
    # ambiguity for downstream readers.
    for key in list(hist.residuals):
        if key.startswith("3:"):
            del hist.residuals[key]
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.save()

    weights = []
    phase_rows = []
    for phase, cif_name, identification, formula in zip(phases, CIF_NAMES, IDENTIFICATIONS, FORMULAS):
        hap = phase.data["Histograms"][hist.name]
        weight = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        weights.append(weight)
        cell = phase.get_cell()
        phase_rows.append(
            {
                "name": phase.name,
                "identification": identification,
                "formula": formula,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": cif_name,
                "cell": {key: float(value) for key, value in cell.items()},
            }
        )
    total = sum(weights)
    for row, weight in zip(phase_rows, weights):
        row["weight_fraction"] = weight / total
        row["weight_percent"] = 100.0 * weight / total

    # Export exactly the saved atom/cell state. A scale-only covariance matrix
    # contains no structural variables and is removed in memory so the CIF
    # writer cannot substitute stale values from any earlier refinement block.
    project.data["Covariance"]["data"] = {}
    for phase, cif_name in zip(phases, CIF_NAMES):
        phase.export_CIF(str(ROOT / cif_name))

    x, observed, _weight, calculated, background, difference = hist.data["data"][1][:6]
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        writer.writerows(
            zip(
                map(float, x),
                map(float, observed),
                map(float, calculated),
                map(float, difference),
                map(float, background),
            )
        )

    rwp = float(hist.residuals["wR"])
    rp = float(hist.residuals["R"])
    rexp = float(hist.residuals["wRmin"])
    result = {
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "Rexp_percent": rexp,
            "goodness_of_fit": rwp / rexp,
            "reduced_chi_squared": (rwp / rexp) ** 2,
            "points": int(len(x)),
        },
        "refinement_histogram": hist.name,
        "profile_path": "fit.csv",
        "project_path": "final.gpx",
        "fraction_basis": "normalized over modeled crystalline phases",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
