"""Refine the wolframite coordinates from one reproducible random start."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


PARENT = {
    "W1": np.array([0.0, 0.18500, 0.25]),
    "Zn1": np.array([0.5, 0.67338, 0.25]),
    "O1": np.array([0.21790, 0.89280, 0.06460]),
    "O2": np.array([0.25510, 0.37720, 0.10210]),
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--amplitude", type=float, default=0.05)
    args = parser.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.base, newgpx=str(out / "trial.gpx"))
    hist = project.histogram(0)

    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for index, phase in enumerate(project.phases()):
        phase.set_refinements({"Cell": False})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = index == 0
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        for atom in phase.atoms():
            atom.refinement_flags = " "

    starts = {}
    for atom in project.phase(0).atoms():
        start = PARENT[atom.label].copy()
        if atom.label in {"W1", "Zn1"}:
            start[1] += rng.uniform(-args.amplitude, args.amplitude)
        else:
            start += rng.uniform(-args.amplitude, args.amplitude, 3)
        start %= 1.0
        atom.coordinates = start.tolist()
        atom.refinement_flags = "X"
        starts[atom.label] = start.tolist()

    project.set_Controls("parmMin", 0.7, variable="0:0:MD")
    project.set_Controls("parmMax", 1.4, variable="0:0:MD")
    project.set_Frozen()
    project.set_Controls("cycles", 24)
    project.data["Controls"]["data"]["min dM/M"] = 1e-8
    status = "ok"
    try:
        project.refine()
    except Exception as exc:
        status = f"failed: {type(exc).__name__}: {exc}"
    project.save()
    payload = {
        "seed": args.seed,
        "amplitude": args.amplitude,
        "status": status,
        "rwp": float(hist.residuals.get("wR", float("nan"))),
        "starts": starts,
        "coordinates": {atom.label: list(map(float, atom.coordinates)) for atom in project.phase(0).atoms()},
        "scales": [float(p.data["Histograms"][hist.name]["Scale"][0]) for p in project.phases()],
        "ratio": float(project.phase(0).data["Histograms"][hist.name]["Pref.Ori."][1]),
        "frozen": project.get_Frozen(),
    }
    (out / "summary.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload))


if __name__ == "__main__":
    main()
