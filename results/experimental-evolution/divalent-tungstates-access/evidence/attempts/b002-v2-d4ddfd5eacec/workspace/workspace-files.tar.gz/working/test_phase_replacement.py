"""Replace one active phase by an already-added candidate in a common project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIIstrIO as G2stIO


def limit(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--old-phase", type=int, required=True)
    parser.add_argument("--candidate-phase", type=int, required=True)
    parser.add_argument("--start-scale", type=float, required=True)
    parser.add_argument("--size", type=float, required=True)
    parser.add_argument("--strain", type=float, required=True)
    parser.add_argument("--cell-span", type=float, default=0.03)
    args = parser.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.base, newgpx=str(out / "trial.gpx"))
    hist = project.histogram(0)
    phases = project.phases()

    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for index, phase in enumerate(phases):
        phase.set_refinements({"Cell": index == args.candidate_phase})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = index != args.old_phase
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])

    old_hap = phases[args.old_phase].data["Histograms"][hist.name]
    old_hap["Scale"] = [1e-12, False]
    old_hap["Use"] = False
    candidate = phases[args.candidate_phase]
    hap = candidate.data["Histograms"][hist.name]
    hap["Use"] = True
    hap["Scale"] = [args.start_scale, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = args.size
    hap["Size"][2][0] = True
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = args.strain
    hap["Mustrain"][2][0] = True

    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.save()
    G2stIO.gpxSize = -1
    G2stIO.gpxIndex.clear()
    project.index_ids()
    limit(project, f"{args.candidate_phase}:0:Scale", 0.0, 1e5)
    limit(project, f"{args.candidate_phase}:0:Size;i", 0.04, 1.5)
    limit(project, f"{args.candidate_phase}:0:Mustrain;i", 0.0, 8000.0)
    limit(project, "0:0:MD", 0.7, 1.4)
    reciprocal = G2lat.cell2A(candidate.data["General"]["Cell"][1:7])
    for term, value in enumerate(reciprocal):
        span = max(args.cell_span * abs(float(value)), 0.0005)
        limit(project, f"{args.candidate_phase}::A{term}", float(value) - span, float(value) + span)

    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.data["Controls"]["data"]["max cyc"] = 24
    project.data["Controls"]["data"]["min dM/M"] = 1e-8
    G2stIO.gpxSize = -1
    G2stIO.gpxIndex.clear()
    status = "ok"
    try:
        project.refine()
    except Exception as exc:
        status = f"failed: {type(exc).__name__}: {exc}"
    project.save()
    weights = [
        (0.0 if not phase.data["Histograms"][hist.name].get("Use", True) else
         max(0.0, float(phase.data["Histograms"][hist.name]["Scale"][0])) * float(phase.data["General"]["Mass"]))
        for phase in phases
    ]
    total = sum(weights)
    payload = {
        "status": status,
        "rwp": float(hist.residuals.get("wR", float("nan"))),
        "scales": [float(p.data["Histograms"][hist.name]["Scale"][0]) for p in phases],
        "uses": [bool(p.data["Histograms"][hist.name].get("Use", True)) for p in phases],
        "weight_fractions": [value / total for value in weights],
        "candidate_cell": candidate.get_cell(),
        "candidate_size": hap["Size"],
        "candidate_mustrain": hap["Mustrain"],
        "frozen": project.data["Controls"]["data"].get("parmFrozen", {}),
    }
    (out / "summary.json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    print(json.dumps(payload, default=str))


if __name__ == "__main__":
    main()
