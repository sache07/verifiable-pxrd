"""Stable alternating refinement of an existing multiphase GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def set_limit(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def freeze_all(project):
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def enable_scales(project, texture=True):
    hist = project.histogram(0)
    for index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        if texture and index == 0:
            hap["Pref.Ori."][2] = True


def enable_profiles(project, include_last=False):
    hist = project.histogram(0)
    phases = project.phases()
    for index, phase in enumerate(phases):
        if index == len(phases) - 1 and not include_last:
            continue
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
        if hap["Size"][0] == "uniaxial":
            hap["Size"][2][1] = True
        hap["Mustrain"][2][0] = True
        if hap["Mustrain"][0] == "uniaxial":
            hap["Mustrain"][2][1] = True


def state(project, label):
    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    return {
        "stage": label,
        "rwp": float(hist.residuals["wR"]),
        "rp": float(hist.residuals["R"]),
        "background_min": float(np.min(arrays[4])),
        "frozen": project.get_Frozen(),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--include-last-profile", action="store_true")
    args = parser.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.base, newgpx=str(out / "trial.gpx"))
    hist = project.histogram(0)
    phases = project.phases()
    freeze_all(project)
    project.data["Controls"]["data"]["min dM/M"] = 1e-8
    project.set_Controls("cycles", args.cycles)

    for variable, low, high in [
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
        ("0:0:MD", 0.7, 1.4),
    ]:
        set_limit(project, variable, low, high)
    for index, phase in enumerate(phases):
        set_limit(project, f"{index}:0:Scale", 0.0, 1e5)
        set_limit(project, f"{index}:0:Size;i", 0.04, 1.5)
        set_limit(project, f"{index}:0:Mustrain;i", 0.0, 8000.0)
        reciprocal = G2lat.cell2A(phase.data["General"]["Cell"][1:7])
        for term, value in enumerate(reciprocal):
            span = max(0.02 * abs(float(value)), 0.0003)
            set_limit(project, f"{index}::A{term}", float(value) - span, float(value) + span)

    stages = []

    def run(label, setup):
        freeze_all(project)
        setup()
        project.set_Frozen()
        project.refine()
        project.save()
        stages.append(state(project, label))

    def scales_background():
        enable_scales(project)
        hist.data["Background"][0][1] = True

    def cells():
        enable_scales(project)
        for phase in phases:
            phase.set_refinements({"Cell": True})

    def zero():
        enable_scales(project)
        hist.data["Instrument Parameters"][0]["Zero"][2] = True

    def shift():
        enable_scales(project)
        hist.SampleParameters["Shift"][1] = True

    def profiles():
        enable_scales(project)
        enable_profiles(project, args.include_last_profile)
        for key in ["W", "SH/L", "Polariz."]:
            hist.data["Instrument Parameters"][0][key][2] = True

    # Alternate strongly correlated blocks; each stage is evaluated in the
    # same multiphase state, but zero, displacement and cells never co-refine.
    for label, setup in [
        ("background_scales_1", scales_background),
        ("cells_1", cells),
        ("zero_1", zero),
        ("shift_1", shift),
        ("profiles_1", profiles),
        ("background_scales_2", scales_background),
        ("cells_2", cells),
        ("zero_2", zero),
        ("shift_2", shift),
        ("profiles_2", profiles),
        ("scales_final", lambda: enable_scales(project)),
    ]:
        run(label, setup)

    weights = []
    rows = []
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        weight = max(0.0, float(hap["Scale"][0])) * float(phase.data["General"]["Mass"])
        weights.append(weight)
        rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "mass": float(phase.data["General"]["Mass"]),
                "cell": {key: float(value) for key, value in phase.get_cell().items()},
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "uiso": [float(atom.uiso) for atom in phase.atoms()],
            }
        )
    total = sum(weights)
    for row, weight in zip(rows, weights):
        row["weight_fraction"] = weight / total
    payload = {
        "stages": stages,
        "rwp": float(hist.residuals["wR"]),
        "rp": float(hist.residuals["R"]),
        "phases": rows,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": {key: hist.SampleParameters[key] for key in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "background": hist.data["Background"],
        "frozen": project.get_Frozen(),
    }
    (out / "summary.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({"rwp": payload["rwp"], "stages": stages, "phases": rows}, indent=2))


if __name__ == "__main__":
    main()
