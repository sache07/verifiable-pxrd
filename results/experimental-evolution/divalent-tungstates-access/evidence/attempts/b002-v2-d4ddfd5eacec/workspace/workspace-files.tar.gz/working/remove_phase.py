"""Remove one phase cleanly from a GSAS-II project by name."""

import argparse
from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--name", required=True)
    args = parser.parse_args()
    project = G2.G2Project(args.base, newgpx=args.out)
    if args.name not in project.data["Phases"]:
        raise KeyError(args.name)
    del project.data["Phases"][args.name]
    project.names[-1] = [value for value in project.names[-1] if value != args.name]
    for hist in project.histograms():
        hist.data.get("Reflection Lists", {}).pop(args.name, None)
    restraints = project.data.get("Restraints", {})
    if isinstance(restraints, dict):
        restraints.pop(args.name, None)
    project.update_ids()
    project.save()
    print([(phase.name, phase.id) for phase in project.phases()])


if __name__ == "__main__":
    main()
