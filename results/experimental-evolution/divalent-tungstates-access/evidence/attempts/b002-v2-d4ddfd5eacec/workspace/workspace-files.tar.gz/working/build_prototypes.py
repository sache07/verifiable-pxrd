"""Create symmetry-distinct ZnWO4 prototype-transfer models from visible COD entries."""

from pathlib import Path

import numpy as np
from pymatgen.analysis.structure_matcher import FrameworkComparator, StructureMatcher
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


COD = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c01/cif")
OUT = Path("working/prototypes")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def transfer(cod_id: str, substitutions: dict[str, str], output: str) -> None:
    structure = Structure.from_file(cod_path(cod_id))
    structure.replace_species(substitutions)
    CifWriter(structure, symprec=0.01, refine_struct=False, write_site_properties=True).write_file(OUT / output)


def normalize(cod_id: str, output: str, uiso: float = 0.005) -> None:
    """Remove oxidation-state labels unsupported by GSAS-II scattering tables."""
    structure = Structure.from_file(cod_path(cod_id))
    structure.remove_oxidation_states()
    structure.add_site_property("Uiso", [uiso] * len(structure))
    CifWriter(structure, symprec=0.01, refine_struct=False, write_site_properties=True).write_file(OUT / output)


def aligned_wolframite_transfer(cod_id: str, output: str) -> None:
    """Map an ABO4 framework into the target wolframite setting and chemistry."""
    target = Structure.from_file(OUT / "znwo4_wolframite_from_como4.cif")
    candidate = Structure.from_file(cod_path(cod_id))
    target.remove_oxidation_states()
    candidate.remove_oxidation_states()
    matcher = StructureMatcher(
        ltol=0.2,
        stol=0.3,
        angle_tol=5,
        primitive_cell=False,
        scale=True,
        attempt_supercell=True,
        allow_subset=False,
        comparator=FrameworkComparator(),
    )
    aligned = matcher.get_s2_like_s1(target, candidate)
    if aligned is None:
        raise ValueError(f"COD {cod_id} did not align to the wolframite framework")
    distances = target.lattice.get_all_distances(target.frac_coords, aligned.frac_coords)
    selected = [int(np.argmin(distances[index])) for index in range(len(target))]
    if len(set(selected)) != len(target):
        raise ValueError(f"COD {cod_id} did not provide a one-to-one site mapping")

    # Put every candidate on one common fitted metric so intensity differences
    # test the framework coordinates, not peak-position or nuisance changes.
    a, b, c, beta = 4.705533, 5.740358, 4.938665, 90.600679
    if aligned.lattice.beta < 90:
        beta = 180.0 - beta
    lattice = Lattice.from_parameters(a, b, c, 90.0, beta, 90.0)
    derived = Structure(
        lattice,
        [target[index].species for index in range(len(target))],
        [aligned[index].frac_coords for index in selected],
        site_properties={"Uiso": [0.01] * len(target)},
    )
    CifWriter(derived, symprec=0.01, refine_struct=False, write_site_properties=True).write_file(OUT / output)


OUT.mkdir(parents=True, exist_ok=True)

# Same Zn site chemistry with W substituted for Mo; triclinic alpha-ZnMoO4 framework.
transfer("1528282", {"Mo": "W"}, "znwo4_triclinic_from_znmoo4.cif")

# Same tungstate chemistry with Zn substituted for Ca; tetragonal scheelite framework.
transfer("7219229", {"Ca": "Zn"}, "znwo4_scheelite_from_cawo4.cif")

# A denser monoclinic alternative retained as a distinct high-pressure-type framework.
transfer("2012578", {"Hg": "Zn"}, "znwo4_c2c_from_hgwo4.cif")

# Additional two-substitution wolframites found by the framework matcher.
aligned_wolframite_transfer("4329321", "znwo4_wolframite_from_taino4.cif")
aligned_wolframite_transfer("1524100", "znwo4_wolframite_from_innbo4.cif")
aligned_wolframite_transfer("2100243", "znwo4_wolframite_from_mnreo4.cif")
aligned_wolframite_transfer("2002235", "znwo4_wolframite_from_fenbo4.cif")
aligned_wolframite_transfer("4336636", "znwo4_wolframite_from_invo4.cif")

# Precursor control: the source mixes W+5/W+6 labels that GSAS-II cannot use
# as X-ray scattering-factor keys. This preserves the W18O49 framework while
# giving all W sites the neutral elemental scattering label.
normalize("1528166", "w18o49_isotropic.cif")
