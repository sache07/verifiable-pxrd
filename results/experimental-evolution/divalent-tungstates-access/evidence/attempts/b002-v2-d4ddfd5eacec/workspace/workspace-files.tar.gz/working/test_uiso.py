"""Grid-test phase-common isotropic displacement values in a fixed nuisance state."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--values", required=True, help="comma-separated Uiso by phase")
    parser.add_argument("--refine-main-coordinates", action="store_true")
    args = parser.parse_args()
    values = [float(value) for value in args.values.split(",")]
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.base, newgpx=str(out / "trial.gpx"))
    hist = project.histogram(0)
    for phase, value in zip(project.phases(), values):
        for atom in phase.atoms():
            atom.uiso = value
            atom.refinement_flags = "X" if args.refine_main_coordinates and phase.id == 0 else " "
    project.set_Frozen()
    project.set_Controls("cycles", 14)
    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.refine()
    project.save()
    payload = {
        "values": values,
        "rwp": float(hist.residuals["wR"]),
        "ratio": float(project.phase(0).data["Histograms"][hist.name]["Pref.Ori."][1]),
        "scales": [float(p.data["Histograms"][hist.name]["Scale"][0]) for p in project.phases()],
    }
    (out / "summary.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload))


if __name__ == "__main__":
    main()
