"""Test one March-Dollase axis in a fixed common multiphase GSAS-II state."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIstrIO as G2stIO


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--phase", type=int, default=0)
    parser.add_argument("--axis", required=True, help="comma-separated h,k,l")
    args = parser.parse_args()
    axis = [int(value) for value in args.axis.split(",")]
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.base, newgpx=str(out / "trial.gpx"))
    hist = project.histogram(0)

    # Hold the established instrument, background, specimen, cells and profile.
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False

    main_hap = project.phase(args.phase).data["Histograms"][hist.name]
    main_hap["Pref.Ori."][0] = "MD"
    main_hap["Pref.Ori."][1] = 1.0
    main_hap["Pref.Ori."][2] = True
    main_hap["Pref.Ori."][3] = axis
    # Clear bound-frozen variables directly. Calling set_Frozen here forces a
    # redundant on-disk reindex of the newly cloned project in this GSAS-II
    # build and can fail before the first refinement.
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.data["Controls"]["data"]["max cyc"] = 12
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    # The GSAS-II GPX index cache is keyed only by file size. A clone can have
    # the same byte count but shifted record offsets after changing an axis.
    G2stIO.gpxSize = -1
    G2stIO.gpxIndex.clear()
    project.refine()
    project.save()

    payload = {
        "axis": axis,
        "phase": args.phase,
        "ratio": float(main_hap["Pref.Ori."][1]),
        "rwp": float(hist.residuals["wR"]),
        "scales": [float(p.data["Histograms"][hist.name]["Scale"][0]) for p in project.phases()],
        "frozen": project.data["Controls"]["data"].get("parmFrozen", {}),
        "vary_list": project.data["Covariance"]["data"].get("varyList", []),
    }
    (out / "summary.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload))


if __name__ == "__main__":
    main()
