"""Refine one phase's atomic coordinates with all nuisance terms fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--elements", default="", help="optional comma-separated elements")
    parser.add_argument("--cycles", type=int, default=24)
    args = parser.parse_args()
    selected = {x.strip() for x in args.elements.split(",") if x.strip()}
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.base, newgpx=str(out / "trial.gpx"))
    hist = project.histogram(0)

    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for index, phase in enumerate(project.phases()):
        phase.set_refinements({"Cell": False})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = index == 0
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        for atom in phase.atoms():
            atom.refinement_flags = "X" if index == args.phase and (not selected or atom.element in selected) else " "

    project.set_Controls("parmMin", 0.7, variable="0:0:MD")
    project.set_Controls("parmMax", 1.4, variable="0:0:MD")
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-8
    status = "ok"
    try:
        project.refine()
    except Exception as exc:
        status = f"failed: {type(exc).__name__}: {exc}"
    project.save()
    phase = project.phase(args.phase)
    payload = {
        "phase": args.phase,
        "elements": sorted(selected),
        "status": status,
        "rwp": float(hist.residuals.get("wR", float("nan"))),
        "coordinates": {atom.label: list(map(float, atom.coordinates)) for atom in phase.atoms()},
        "scales": [float(p.data["Histograms"][hist.name]["Scale"][0]) for p in project.phases()],
        "frozen": project.get_Frozen(),
        "vary_list": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    }
    (out / "summary.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload))


if __name__ == "__main__":
    main()
