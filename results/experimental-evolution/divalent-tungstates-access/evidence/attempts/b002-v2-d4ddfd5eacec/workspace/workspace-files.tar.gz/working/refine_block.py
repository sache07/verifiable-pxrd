"""Refine a controlled parameter block in an existing common multiphase GPX."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIstrIO as G2stIO


def freeze_all(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument(
        "--vary",
        default="scales",
        help="comma-separated: scales,texture,cells,background,instrument,profile,zero,shift,positions",
    )
    parser.add_argument("--phases", default="", help="phase indices for phase-local terms; default all")
    parser.add_argument("--elements", default="", help="elements selected for position refinement")
    parser.add_argument(
        "--set-uiso",
        default="",
        help="comma-separated phase:value pairs setting phase-common fixed Uiso values",
    )
    parser.add_argument("--cycles", type=int, default=20)
    args = parser.parse_args()

    vary = {item.strip() for item in args.vary.split(",") if item.strip()}
    allowed = {"scales", "texture", "cells", "background", "instrument", "profile", "zero", "shift", "positions"}
    unknown = vary - allowed
    if unknown:
        raise ValueError(f"Unknown refinement blocks: {sorted(unknown)}")
    selected_elements = {item.strip() for item in args.elements.split(",") if item.strip()}

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.base, newgpx=str(out / "trial.gpx"))
    hist = project.histogram(0)
    phases = project.phases()
    for assignment in args.set_uiso.split(","):
        if not assignment.strip():
            continue
        phase_text, value_text = assignment.split(":", 1)
        for atom in phases[int(phase_text)].atoms():
            atom.uiso = float(value_text)
    selected_phases = (
        {int(item) for item in args.phases.split(",") if item.strip()}
        if args.phases
        else set(range(len(phases)))
    )
    freeze_all(project)

    # Scales are included in every block so phase additions and intensity
    # corrections are always judged in the full common state.
    for index, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        if "texture" in vary and index in selected_phases:
            hap["Pref.Ori."][2] = True
        if "cells" in vary and index in selected_phases:
            phase.set_refinements({"Cell": True})
        if "profile" in vary and index in selected_phases:
            hap["Size"][2][0] = True
            if hap["Size"][0] == "uniaxial":
                hap["Size"][2][1] = True
            hap["Mustrain"][2][0] = True
            if hap["Mustrain"][0] == "uniaxial":
                hap["Mustrain"][2][1] = True
        if "positions" in vary and index in selected_phases:
            for atom in phase.atoms():
                if not selected_elements or atom.element in selected_elements:
                    atom.refinement_flags = "X"

    if "background" in vary:
        hist.data["Background"][0][1] = True
    if "instrument" in vary:
        for key in ("U", "W", "X", "SH/L", "Polariz."):
            hist.data["Instrument Parameters"][0][key][2] = True
    if "zero" in vary:
        hist.data["Instrument Parameters"][0]["Zero"][2] = True
    if "shift" in vary:
        hist.SampleParameters["Shift"][1] = True

    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    controls["max cyc"] = args.cycles
    controls["min dM/M"] = 1e-8

    # Materialize and explicitly reindex the clone. GSAS-II's GPX offset
    # cache uses file size only, and same-sized clones can otherwise be read
    # using stale offsets after a refinement flag changes.
    project.save()
    G2stIO.gpxSize = -1
    G2stIO.gpxIndex.clear()
    project.index_ids()

    limits = [
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
    ]
    for index in range(len(phases)):
        limits.extend(
            [
                (f"{index}:0:Scale", 0.0, 1e5),
                (f"{index}:0:Size;i", 0.04, 1.5),
                (f"{index}:0:Mustrain;i", 0.0, 8000.0),
                (f"{index}:0:Mustrain;a", 0.0, 8000.0),
                (f"{index}:0:MD", 0.7, 1.4),
            ]
        )
    for variable, low, high in limits:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)

    controls["parmFrozen"] = {}
    G2stIO.gpxSize = -1
    G2stIO.gpxIndex.clear()
    status = "ok"
    try:
        project.refine()
    except Exception as exc:
        status = f"failed: {type(exc).__name__}: {exc}"
    project.save()

    weights = []
    phase_rows = []
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        weight = max(0.0, float(hap["Scale"][0])) * float(phase.data["General"]["Mass"])
        weights.append(weight)
        phase_rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell": {key: float(value) for key, value in phase.get_cell().items()},
                "texture": hap["Pref.Ori."],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "uiso": [float(atom.uiso) for atom in phase.atoms()],
            }
        )
    total = sum(weights)
    for row, weight in zip(phase_rows, weights):
        row["weight_fraction"] = weight / total
    payload = {
        "status": status,
        "vary": sorted(vary),
        "selected_phases": sorted(selected_phases),
        "rwp": float(hist.residuals.get("wR", float("nan"))),
        "rp": float(hist.residuals.get("R", float("nan"))),
        "phases": phase_rows,
        "instrument": hist.data["Instrument Parameters"][0],
        "shift": hist.SampleParameters["Shift"],
        "vary_list": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
        "frozen": controls.get("parmFrozen", {}),
    }
    (out / "summary.json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    print(json.dumps(payload, default=str))


if __name__ == "__main__":
    main()
