#!/usr/bin/env python3
"""Run one controlled GSAS-II model extension from a physical checkpoint."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fractions(project, hist):
    values = [p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"]
              for p in project.phases()]
    total = sum(values)
    return {p.name: v / total for p, v in zip(project.phases(), values)}


def set_limit(project, name, low, high):
    project.set_Controls("parmMin", float(low), variable=name)
    project.set_Controls("parmMax", float(high), variable=name)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("mode", choices=["polarization", "surface", "texture", "uniaxial_strain", "uiso", "background20"])
    parser.add_argument("--phase", type=int, default=0)
    parser.add_argument("--axis", default="0,0,1")
    parser.add_argument("--value", type=float, default=0.01)
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.input_gpx.resolve()))
    project.save(str((args.output_dir / "variant.gpx").resolve()))
    hist = project.histogram(0)
    before = float(hist.residuals["wR"])
    # Optional terms are compared with the accepted checkpoint frozen. Only
    # scales and the smooth background are re-equilibrated with each term.
    hist.clear_refinements({"Background": True})
    hist.clear_refinements({"Instrument Parameters": list(hist.InstrumentParameters)})
    hist.clear_refinements({
        "Sample Parameters": [
            key for key, value in hist.SampleParameters.items()
            if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool)
        ]
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True,
            "Pref.Ori.": True, "HStrain": True, "Extinction": True,
        })
        phase.set_HAP_refinements({"Scale": True})
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist.set_refinements({"Background": True})

    detail = {}
    if args.mode == "polarization":
        hist.InstrumentParameters["Polariz."][1] = 0.7
        hist.InstrumentParameters["Polariz."][2] = True
        set_limit(project, ":0:Polariz.", 0.5, 1.0)
    elif args.mode == "surface":
        hist.SampleParameters["SurfRoughA"] = [0.10, True]
        hist.SampleParameters["SurfRoughB"] = [0.05, True]
        set_limit(project, ":0:SurfRoughA", 0.0, 0.6)
        set_limit(project, ":0:SurfRoughB", 0.0, 0.5)
    elif args.mode == "texture":
        axis = [int(v) for v in args.axis.split(",")]
        phase = project.phases()[args.phase]
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
        set_limit(project, f"{args.phase}:0:MD", 0.7, 1.4)
        detail = {"phase_name": phase.name, "axis": axis}
    elif args.mode == "uniaxial_strain":
        axis = [int(v) for v in args.axis.split(",")]
        phase = project.phases()[args.phase]
        hap = phase.data["Histograms"][hist.name]
        current = float(hap["Mustrain"][1][0])
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = current
        hap["Mustrain"][1][1] = current
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        hap["Mustrain"][3] = axis
        detail = {"phase_name": phase.name, "axis": axis}
    elif args.mode == "uiso":
        phase = project.phases()[args.phase]
        for atom in phase.atoms():
            atom.uiso = args.value
        detail = {"phase_name": phase.name, "uiso_A2": args.value}
    elif args.mode == "background20":
        old = list(hist.Background[0][3:])
        hist.set_refinements({"Background": {
            "type": "chebyschev-1", "no. coeffs": 20,
            "coeffs": old + [0.0] * (20 - len(old)), "refine": True,
        }})

    project.set_Controls("cycles", args.cycles)
    project.refine()
    after = float(hist.residuals["wR"])
    project.save(str((args.output_dir / "checkpoint.gpx").resolve()))
    result = {
        "mode": args.mode,
        **detail,
        "Rwp_before_percent": before,
        "Rwp_after_percent": after,
        "fractions": fractions(project, hist),
        "polarization": float(hist.InstrumentParameters["Polariz."][1]),
        "surface_roughness": [float(hist.SampleParameters["SurfRoughA"][0]),
                              float(hist.SampleParameters["SurfRoughB"][0])],
    }
    if args.mode == "texture":
        hap = project.phases()[args.phase].data["Histograms"][hist.name]
        result["march_dollase_ratio"] = float(hap["Pref.Ori."][1])
    if args.mode == "uniaxial_strain":
        hap = project.phases()[args.phase].data["Histograms"][hist.name]
        result["microstrain_equatorial_axial_ppm"] = [
            float(hap["Mustrain"][1][0]), float(hap["Mustrain"][1][1])
        ]
    (args.output_dir / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
