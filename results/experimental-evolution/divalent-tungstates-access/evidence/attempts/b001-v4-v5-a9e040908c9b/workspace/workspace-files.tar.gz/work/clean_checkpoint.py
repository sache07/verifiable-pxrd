#!/usr/bin/env python3
"""Freeze a GSAS-II checkpoint so optional model terms can be tested stably."""

from GSASII import GSASIIscriptable as G2


SOURCE = "work/final_refine/physical_checkpoint.gpx"
OUTPUT = "work/final_refine/clean_checkpoint.gpx"


G2.SetPrintLevel("warn")
project = G2.G2Project(SOURCE)
hist = project.histogram(0)
hist.clear_refinements({"Background": True})
hist.clear_refinements({"Instrument Parameters": list(hist.InstrumentParameters)})
hist.clear_refinements({
    "Sample Parameters": [
        key for key, value in hist.SampleParameters.items()
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool)
    ]
})
for phase in project.phases():
    phase.clear_refinements({"Cell": True})
    phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
    phase.clear_HAP_refinements({
        "Scale": True,
        "Size": True,
        "Mustrain": True,
        "Pref.Ori.": True,
        "HStrain": True,
        "Extinction": True,
    })
project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
project.set_Controls("cycles", 0)
project.save(OUTPUT)
project.refine()
project.save(OUTPUT)
print("Rwp", hist.residuals["wR"])
