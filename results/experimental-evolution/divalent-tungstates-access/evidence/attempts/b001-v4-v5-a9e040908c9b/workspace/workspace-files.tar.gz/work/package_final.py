#!/usr/bin/env python3
"""Package the accepted, replay-tested GSAS-II checkpoint for submission."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
REPLAY = ROOT / "work/combined/p01/replay.gpx"
REFINED = ROOT / "work/combined/p01/refined.gpx"
FINAL = ROOT / "final.gpx"
PATTERN = ROOT / "inputs/pattern.csv"

CIF_NAMES = {
    "CuWO4_P-1_4000806": "phase_CuWO4.cif",
    "WO3_P-1_2106293": "phase_WO3.cif",
    "CuO_C2c_1011194": "phase_CuO.cif",
    "Cu3WO6_Pa-3_1527404": "phase_Cu3WO6.cif",
}


def phase_fractions(project, histogram):
    masses = np.array(
        [
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][histogram.name]["Scale"][0]
            for phase in project.phases()
        ],
        dtype=float,
    )
    return masses / masses.sum()


def fraction_standard_uncertainties(project, histogram):
    """Propagate the terminal scale covariance into normalized mass fractions."""
    covariance = project.data["Covariance"]["data"]
    variables = covariance["varyList"]
    matrix = np.asarray(covariance["covMatrix"], dtype=float)
    indices = [variables.index(f"{i}:0:Scale") for i in range(len(project.phases()))]
    scale_covariance = matrix[np.ix_(indices, indices)]

    scales = np.array(
        [phase.data["Histograms"][histogram.name]["Scale"][0] for phase in project.phases()],
        dtype=float,
    )
    cell_masses = np.array(
        [phase.data["General"]["Mass"] for phase in project.phases()], dtype=float
    )
    weighted = scales * cell_masses
    fractions = weighted / weighted.sum()
    jacobian = np.empty((len(fractions), len(fractions)), dtype=float)
    for i in range(len(fractions)):
        for j in range(len(fractions)):
            jacobian[i, j] = (
                cell_masses[j]
                * ((1.0 if i == j else 0.0) - fractions[i])
                / weighted.sum()
            )
    fraction_covariance = jacobian @ scale_covariance @ jacobian.T
    return np.sqrt(np.maximum(np.diag(fraction_covariance), 0.0))


def main():
    G2.SetPrintLevel("warn")

    # This checkpoint was already recalculated over the complete grid with zero
    # refinement cycles, so it is the exact physical forward model submitted.
    shutil.copy2(REPLAY, FINAL)
    project = G2.G2Project(str(FINAL))
    histogram = project.histogram(0)

    names = [phase.name for phase in project.phases()]
    if set(names) != set(CIF_NAMES):
        raise RuntimeError(f"Unexpected final phase inventory: {names}")

    for phase in project.phases():
        phase.export_CIF(str(ROOT / CIF_NAMES[phase.name]))

    public = np.loadtxt(PATTERN, delimiter=",", skiprows=1, ndmin=2)
    x = np.asarray(histogram.getdata("x"), dtype=float)
    observed = np.asarray(histogram.getdata("yobs"), dtype=float)
    calculated = np.asarray(histogram.getdata("ycalc"), dtype=float)
    weights = np.asarray(histogram.getdata("yweight"), dtype=float)
    if not np.allclose(x, public[:, 0], atol=1e-7, rtol=0):
        raise RuntimeError("Final project grid differs from inputs/pattern.csv")
    if not np.allclose(observed, public[:, 1], atol=1e-5, rtol=0):
        raise RuntimeError("Final project observations differ from inputs/pattern.csv")
    if np.any(~np.isfinite(calculated)) or np.any(calculated < 0):
        raise RuntimeError("Final calculated profile is nonfinite or negative")

    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f"],
    )

    denominator = float(np.sum(weights * observed * observed))
    weighted_residual = float(np.sum(weights * difference * difference))
    rwp = 100.0 * np.sqrt(weighted_residual / denominator)
    rp = 100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed))
    replay_gof = np.sqrt(weighted_residual / len(observed))

    fractions = phase_fractions(project, histogram)
    refined = G2.G2Project(str(REFINED))
    fraction_su = fraction_standard_uncertainties(refined, refined.histogram(0))
    diagnostics = {
        "histogram": histogram.name,
        "points": len(x),
        "rwp_percent": float(rwp),
        "rp_percent": float(rp),
        "weighted_residual_sum": weighted_residual,
        "goodness_of_fit_frozen_replay": float(replay_gof),
        "fractions": {
            phase.name: {
                "weight_fraction": float(value),
                "scale_covariance_standard_uncertainty": float(su),
                "cif": CIF_NAMES[phase.name],
                "cell": phase.get_cell(),
            }
            for phase, value, su in zip(project.phases(), fractions, fraction_su)
        },
    }
    print(json.dumps(diagnostics, indent=2))


if __name__ == "__main__":
    main()
