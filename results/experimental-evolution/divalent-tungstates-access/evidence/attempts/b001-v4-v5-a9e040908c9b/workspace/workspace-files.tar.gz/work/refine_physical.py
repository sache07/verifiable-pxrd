#!/usr/bin/env python3
"""Regularize the accepted four-phase checkpoint to physical profile ranges."""

from pathlib import Path
import json
import math

from GSASII import GSASIIscriptable as G2


SOURCE = Path("work/branches/triclinic4/05_heavy_atoms.gpx")
OUTDIR = Path("work/final_refine")


def fractions(project, hist):
    vals = [p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"]
            for p in project.phases()]
    total = sum(vals)
    return {p.name: v / total for p, v in zip(project.phases(), vals)}


def state(project, hist, label):
    out = {
        "label": label,
        "Rwp_percent": float(hist.residuals["wR"]),
        "fractions": fractions(project, hist),
        "instrument": {k: v for k, v in hist.InstrumentParameters.items()},
        "sample": hist.SampleParameters,
        "phases": {},
    }
    for p in project.phases():
        hap = p.data["Histograms"][hist.name]
        out["phases"][p.name] = {
            "cell": p.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "scale": hap["Scale"],
        }
    print(label, "Rwp", hist.residuals["wR"], "fractions", out["fractions"], flush=True)
    return out


def set_limit(project, var, low, high):
    project.set_Controls("parmMin", float(low), variable=var)
    project.set_Controls("parmMax", float(high), variable=var)


def main():
    OUTDIR.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE))
    project.save(str(OUTDIR / "physical.gpx"))
    hist = project.histogram(0)

    # Retain the fitted net angular correction at 30 degrees while selecting
    # an identifiable, in-range decomposition. Zero is then fixed because it
    # is almost perfectly correlated with specimen displacement.
    radius = float(hist.SampleParameters["Gonio. radius"])
    factor = 4.0 * 0.09 / (math.pi * radius) * math.cos(math.radians(15.0))
    old_zero = float(hist.InstrumentParameters["Zero"][1])
    old_shift = float(hist.SampleParameters["Shift"][0])
    target_correction = old_zero - factor * old_shift
    new_zero = -0.15
    new_shift = (new_zero - target_correction) / factor
    hist.InstrumentParameters["Zero"][1] = new_zero
    hist.InstrumentParameters["Zero"][2] = False
    hist.SampleParameters["Shift"] = [new_shift, True]

    # Restore the profile to the physically sampled ranges. Negative U and
    # SH/L in the unconstrained branch were covariance artifacts.
    hist.InstrumentParameters["U"][1] = 0.1
    hist.InstrumentParameters["W"][1] = max(2.0, float(hist.InstrumentParameters["W"][1]))
    hist.InstrumentParameters["X"][1] = min(6.0, max(0.1, float(hist.InstrumentParameters["X"][1])))
    hist.InstrumentParameters["SH/L"][1] = 0.01
    for key in ["U", "W", "X", "SH/L"]:
        hist.InstrumentParameters[key][2] = True

    set_limit(project, ":0:U", 0.0, 40.0)
    set_limit(project, ":0:W", 2.0, 40.0)
    set_limit(project, ":0:X", 0.1, 6.0)
    set_limit(project, ":0:SH/L", 0.005, 0.1)
    set_limit(project, ":0:Shift", -800.0, 800.0)

    for i, phase in enumerate(project.phases()):
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = min(1.5, max(0.04, float(hap["Size"][1][0])))
        hap["Size"][2][0] = True
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = min(8000.0, max(0.0, float(hap["Mustrain"][1][0])))
        hap["Mustrain"][2][0] = True
        set_limit(project, f"{i}:0:Size;i", 0.04, 1.5)
        set_limit(project, f"{i}:0:Mustrain;i", 0.0, 8000.0)

    history = [state(project, hist, "regularized_start")]
    project.set_Controls("cycles", 10)
    project.refine()
    history.append(state(project, hist, "regularized_refined"))
    project.save(str(OUTDIR / "physical_checkpoint.gpx"))
    (OUTDIR / "physical_history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
