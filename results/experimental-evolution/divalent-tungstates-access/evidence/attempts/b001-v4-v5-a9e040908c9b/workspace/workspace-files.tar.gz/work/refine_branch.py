#!/usr/bin/env python3
"""Build and comparably refine a three-phase GSAS-II branch."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def phase_fractions(project: G2.G2Project, hist: G2.G2PwdrData) -> dict[str, float]:
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        raw[phase.name] = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
    total = sum(max(v, 0.0) for v in raw.values())
    if total <= 0:
        return {k: float("nan") for k in raw}
    return {k: max(v, 0.0) / total for k, v in raw.items()}


def snapshot(project: G2.G2Project, hist: G2.G2PwdrData, label: str, outdir: Path) -> dict:
    project.save(str(outdir / f"{label}.gpx"))
    residuals = {}
    for key, value in hist.residuals.items():
        if isinstance(value, (int, float, np.number)):
            residuals[key] = float(value)
        else:
            residuals[key] = str(value)
    result = {
        "label": label,
        "residuals": residuals,
        "fractions": phase_fractions(project, hist),
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "instrument": {
            k: float(v[1])
            for k, v in hist.InstrumentParameters.items()
            if isinstance(v, list) and len(v) >= 2 and isinstance(v[1], (int, float))
        },
        "sample": {
            k: float(v[0])
            for k, v in hist.SampleParameters.items()
            if isinstance(v, list) and len(v) >= 2 and isinstance(v[0], (int, float))
        },
        "hap": {},
    }
    for p in project.phases():
        h = p.data["Histograms"][hist.name]
        result["hap"][p.name] = {
            "scale": float(h["Scale"][0]),
            "size_type": h["Size"][0],
            "size": [float(x) for x in h["Size"][1]],
            "mustrain_type": h["Mustrain"][0],
            "mustrain": [float(x) for x in h["Mustrain"][1]],
            "preferred_orientation": [h["Pref.Ori."][0], float(h["Pref.Ori."][1]), list(h["Pref.Ori."][3])],
        }
    print(
        f"{label:18s} Rwp={hist.residuals.get('wR', float('nan')):9.4f} "
        f"fractions={result['fractions']}",
        flush=True,
    )
    return result


def refine(project: G2.G2Project, hist: G2.G2PwdrData, label: str, outdir: Path,
           stages: list[dict], log: list[dict], cycles: int = 5) -> None:
    project.set_Controls("cycles", cycles)
    for stage in stages:
        project.set_refinement(stage)
    project.refine()
    log.append(snapshot(project, hist, label, outdir))


def set_atom_flags(phase: G2.G2Phase, elements: set[str], flags: str) -> None:
    selected = {a.label: flags for a in phase.atoms() if a.element in elements}
    if selected:
        phase.set_refinements({"Atoms": selected})


def clear_atom_flags(project: G2.G2Project) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("outdir", type=Path)
    parser.add_argument("cifs", nargs="+")
    parser.add_argument("--oxygen", action="store_true", help="include a limited oxygen-coordinate stage")
    args = parser.parse_args()
    if len(args.cifs) < 2:
        raise SystemExit("at least two CIFs are required")

    outdir = args.outdir.resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / "instrument.instprm", outdir / "instrument.instprm")
    shutil.copy2(ROOT / "pattern.xye", outdir / "pattern.xye")

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(outdir / "branch.gpx"))
    phases = []
    for cif in args.cifs:
        path = Path(cif).resolve()
        phases.append(project.add_phase(str(path), phasename=path.stem, fmthint="CIF"))
    hist = project.add_powder_histogram(
        str(outdir / "pattern.xye"), str(outdir / "instrument.instprm"),
        phases="all", fmthint="xye",
    )

    # The absolute histogram scale is fixed so phase scales remain identifiable.
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 15,
            "coeffs": [2600.0, -900.0, 300.0] + [0.0] * 12,
            "refine": True,
        }
    })
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0

    log: list[dict] = []
    refine(project, hist, "01_scale_background", outdir,
           [{"set": {"Background": True, "Scale": True}}], log, cycles=5)
    refine(project, hist, "02_cells_zero", outdir,
           [{"set": {"Cell": True, "Instrument Parameters": ["Zero"]}}], log, cycles=6)
    refine(project, hist, "03_shift", outdir,
           [{"set": {"Sample Parameters": ["Shift"]}}], log, cycles=6)
    refine(project, hist, "04_profile", outdir,
           [{"set": {"Instrument Parameters": ["U", "W", "X", "SH/L"]}}], log, cycles=6)

    # Heavy-atom positional adjustment is small and is evaluated before O atoms.
    for phase in project.phases():
        set_atom_flags(phase, {"W", "Cu"}, "X")
    refine(project, hist, "05_heavy_atoms", outdir, [], log, cycles=6)
    clear_atom_flags(project)

    # Phase-specific broadening is present in the experiment family; use the
    # minimal isotropic model for topology comparisons.
    refine(project, hist, "06_phase_profile", outdir,
           [{"set": {
               "Size": {"type": "isotropic", "value": 1.0, "refine": True},
               "Mustrain": {"type": "isotropic", "refine": True},
           }}], log, cycles=8)

    if args.oxygen:
        for phase in project.phases():
            set_atom_flags(phase, {"O"}, "X")
        refine(project, hist, "07_oxygen", outdir, [], log, cycles=6)
        clear_atom_flags(project)

    project.save(str(outdir / "checkpoint.gpx"))
    (outdir / "summary.json").write_text(json.dumps(log, indent=2, allow_nan=True) + "\n")


if __name__ == "__main__":
    main()
