#!/usr/bin/env python3
"""Test a bounded oxygen-coordinate refinement for one phase."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fractions(project, hist):
    vals = [p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"]
            for p in project.phases()]
    total = sum(vals)
    return {p.name: v / total for p, v in zip(project.phases(), vals)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("phase_index", type=int)
    parser.add_argument("--bound", type=float, default=0.007)
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.input_gpx.resolve()))
    project.save(str((args.output_dir / "coordinate_test.gpx").resolve()))
    hist = project.histogram(0)
    before = float(hist.residuals["wR"])

    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "

    phase = project.phases()[args.phase_index]
    selected = {}
    for atom_index, atom in enumerate(phase.atoms()):
        if atom.element != "O":
            continue
        selected[atom.label] = "X"
        for axis in "xyz":
            variable = f"{args.phase_index}::dA{axis}:{atom_index}"
            project.set_Controls("parmMin", -args.bound, variable=variable)
            project.set_Controls("parmMax", args.bound, variable=variable)
    phase.set_refinements({"Atoms": selected})

    project.set_Controls("cycles", args.cycles)
    project.refine()
    after = float(hist.residuals["wR"])
    project.save(str((args.output_dir / "checkpoint.gpx").resolve()))
    cif_dir = args.output_dir / "cifs"
    cif_dir.mkdir(exist_ok=True)
    for i, item in enumerate(project.phases()):
        item.export_CIF(str((cif_dir / f"{i}_{item.name}.cif").resolve()))
    result = {
        "phase_index": args.phase_index,
        "phase_name": phase.name,
        "coordinate_bound_fractional": args.bound,
        "Rwp_before_percent": before,
        "Rwp_after_percent": after,
        "fractions": fractions(project, hist),
    }
    (args.output_dir / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
