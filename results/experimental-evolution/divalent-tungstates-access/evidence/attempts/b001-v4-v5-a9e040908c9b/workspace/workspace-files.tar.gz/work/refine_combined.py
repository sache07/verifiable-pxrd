#!/usr/bin/env python3
"""Combine only individually supported, physical model terms and replay."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path("work/stable2/tests/polarization2/checkpoint.gpx")


def fractions(project, hist):
    values = [p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"]
              for p in project.phases()]
    total = sum(values)
    return {p.name: v / total for p, v in zip(project.phases(), values)}


def clear_all(project, hist):
    hist.data["Background"][0][1] = False
    for item in hist.InstrumentParameters.values():
        if isinstance(item, list) and len(item) > 2:
            item[2] = False
    for item in hist.SampleParameters.values():
        if isinstance(item, list) and len(item) > 1 and isinstance(item[1], bool):
            item[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--strain-phases", default="")
    parser.add_argument("--p3-uiso", action="store_true")
    parser.add_argument("--background20", action="store_true")
    args = parser.parse_args()
    strain_phases = {int(v) for v in args.strain_phases.split(",") if v.strip()}

    args.output_dir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE))
    project.save(str(args.output_dir / "combined.gpx"))
    hist = project.histogram(0)
    clear_all(project, hist)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.data["Controls"]["data"]["parmMinDict"] = {}
    project.data["Controls"]["data"]["parmMaxDict"] = {}

    # Nonzero, physically minimal thermal motion for phases whose historical
    # source CIFs report Uiso=0. The grid test selected the lower physical end.
    for atom in project.phases()[1].atoms():
        atom.uiso = 0.003
    if args.p3_uiso:
        for atom in project.phases()[3].atoms():
            atom.uiso = 0.003

    if args.background20:
        old = list(hist.Background[0][3:])
        hist.set_refinements({"Background": {
            "type": "chebyschev-1", "no. coeffs": 20,
            "coeffs": old + [0.0] * (20 - len(old)), "refine": True,
        }})
    else:
        hist.data["Background"][0][1] = True
    hist.InstrumentParameters["Polariz."][2] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True

    starts = {
        0: ([1, 0, 0], [1299.320989051743, 1553.7398639450505]),
        1: ([0, 0, 1], [3892.0396476876363, 3222.8358689600036]),
    }
    for index in strain_phases:
        axis, values = starts[index]
        hap = project.phases()[index].data["Histograms"][hist.name]
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = values[0]
        hap["Mustrain"][1][1] = values[1]
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        hap["Mustrain"][3] = axis

    project.set_Controls("cycles", 10)
    project.refine()
    refined = float(hist.residuals["wR"])
    project.save(str(args.output_dir / "refined.gpx"))

    clear_all(project, hist)
    project.set_Controls("cycles", 0)
    project.save(str(args.output_dir / "replay.gpx"))
    project.refine()
    replay = float(hist.residuals["wR"])
    project.save(str(args.output_dir / "replay.gpx"))
    result = {
        "strain_phases": sorted(strain_phases),
        "p3_uiso": args.p3_uiso,
        "background20": args.background20,
        "refined_Rwp_percent": refined,
        "replay_Rwp_percent": replay,
        "fractions": fractions(project, hist),
        "polarization": float(hist.InstrumentParameters["Polariz."][1]),
        "strains": {
            str(i): project.phases()[i].data["Histograms"][hist.name]["Mustrain"]
            for i in strain_phases
        },
    }
    (args.output_dir / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
