#!/usr/bin/env python3
"""Produce a replay-stable physical profile from the accepted structure model."""

import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path("work/branches/triclinic4/05_heavy_atoms.gpx")
OUTDIR = Path("work/stable2")


def fractions(project, hist):
    vals = [p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"]
            for p in project.phases()]
    total = sum(vals)
    return {p.name: v / total for p, v in zip(project.phases(), vals)}


def main():
    OUTDIR.mkdir(exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE))
    project.save(str(OUTDIR / "stable.gpx"))
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.data["Controls"]["data"]["parmMinDict"] = {}
    project.data["Controls"]["data"]["parmMaxDict"] = {}

    # Choose a physical, identifiable angular correction with the same net
    # correction at 30 degrees as the accepted checkpoint.
    radius = float(hist.SampleParameters["Gonio. radius"])
    factor = 4.0 * 0.09 / (math.pi * radius) * math.cos(math.radians(15.0))
    old_zero = float(hist.InstrumentParameters["Zero"][1])
    old_shift = float(hist.SampleParameters["Shift"][0])
    target = old_zero - factor * old_shift
    hist.InstrumentParameters["Zero"][1] = -0.15
    hist.SampleParameters["Shift"][0] = (-0.15 - target) / factor

    # Clear all histogram flags, then refine only stable physical terms.
    hist.data["Background"][0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.InstrumentParameters["U"][1] = 0.0
    hist.InstrumentParameters["W"][1] = 12.0
    hist.InstrumentParameters["X"][1] = 2.5
    hist.InstrumentParameters["SH/L"][1] = 0.005
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["X"][2] = True
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Shift"][1] = True
    hist.SampleParameters["Scale"] = [1.0, False]

    for i, phase in enumerate(project.phases()):
        phase.data["General"]["Cell"][0] = True
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = False
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        if i == 0:
            hap["Size"][1][0] = 0.22
            hap["Size"][2][0] = True
        elif i in (1, 2):
            hap["Size"][1][0] = 1.5
        else:
            hap["Size"][1][0] = 1.5
        hap["Mustrain"][1][0] = max(0.0, float(hap["Mustrain"][1][0]))
        hap["Mustrain"][2][0] = True

    project.set_Controls("cycles", 12)
    project.refine()
    refined_rwp = float(hist.residuals["wR"])
    project.save(str(OUTDIR / "stable_refined.gpx"))

    # Freeze and explicitly replay once; submitted projects are evaluated this way.
    hist.data["Background"][0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    project.set_Controls("cycles", 0)
    project.save(str(OUTDIR / "stable_replay.gpx"))
    project.refine()
    replay_rwp = float(hist.residuals["wR"])
    project.save(str(OUTDIR / "stable_replay.gpx"))
    result = {
        "refined_Rwp_percent": refined_rwp,
        "replay_Rwp_percent": replay_rwp,
        "fractions": fractions(project, hist),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
    }
    (OUTDIR / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
