#!/usr/bin/env python3
"""Export all submission artifacts from the accepted final GSAS-II project."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"


def main() -> None:
    project = G2.G2Project(gpxfile=str(PROJECT))
    histograms = project.histograms()
    if len(histograms) != 1:
        raise RuntimeError("final project must contain exactly one powder histogram")
    hist = histograms[0]

    input_pattern = np.genfromtxt(
        ROOT / "inputs" / "pattern.csv", delimiter=",", names=True
    )
    x = np.asarray(hist.getdata("X"), float)
    observed = np.asarray(hist.getdata("Yobs"), float)
    calculated = np.asarray(hist.getdata("Ycalc"), float)
    difference = observed - calculated
    if not np.allclose(x, input_pattern["two_theta_deg"], atol=1.0e-7, rtol=0):
        raise RuntimeError("final project grid differs from pattern.csv")
    if not np.allclose(observed, input_pattern["intensity"], atol=1.0e-5, rtol=0):
        raise RuntimeError("final project observations differ from pattern.csv")
    if not np.all(np.isfinite(calculated)) or np.any(calculated < 0):
        raise RuntimeError("final project has an invalid calculated profile")
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f"],
    )

    phases = project.phases()
    if [phase.name for phase in phases] != ["CaWO4_scheelite", "WO3_2311041"]:
        raise RuntimeError("unexpected phase inventory in final project")
    filenames = ["CaWO4_scheelite.cif", "WO3_monoclinic.cif"]
    formulas = ["CaWO4", "WO3"]
    display_names = [
        "calcium tungstate (scheelite, I41/a)",
        "tungsten trioxide (monoclinic, P21/c)",
    ]
    for phase, filename in zip(phases, filenames):
        phase.export_CIF(str(ROOT / filename))

    fractions = hist.ComputeMassFracs()
    rows = []
    for phase, filename, formula, display_name in zip(
        phases, filenames, formulas, display_names
    ):
        value, esd = fractions[phase.name]
        rows.append(
            {
                "name": display_name,
                "formula": formula,
                "cif_path": filename,
                "weight_fraction": float(value),
                "weight_fraction_esd": float(esd),
            }
        )

    residuals = hist.residuals
    rvalues = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "phases": rows,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvalues["GOF"]),
            "chi_square": float(rvalues["chisq"]),
            "observations": int(rvalues["Nobs"]),
            "variables_in_final_settle": int(rvalues["Nvars"]),
        },
        "calibration": {
            "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
        },
        "refinement_histogram": hist.name,
        "profile_path": "fit.csv",
        "project_path": "final.gpx",
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
