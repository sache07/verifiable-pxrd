#!/usr/bin/env python3
"""Apply the frozen generator's documented CIF registration normalization."""

from pathlib import Path
import sys
import warnings

from pymatgen.io.cif import CifParser


ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
RUNTIME = Path("learned/divalent-tungstates/runtime").resolve()
sys.path.insert(0, str(RUNTIME))
from models import write_synthetic_model  # noqa: E402


def source(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    output = Path(".tmp/registered_refs")
    output.mkdir(parents=True, exist_ok=True)
    ids = [
        "7219229", "1546035", "2311041", "1528915", "2106293",
        "2107312", "1521532", "1521533", "1563541", "1004057",
    ]
    for cod_id in ids:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            parser = CifParser(
                source(cod_id), occupancy_tolerance=1.0,
                site_tolerance=1.0e-5, frac_tolerance=0,
            )
            structures = parser.parse_structures(primitive=False, on_error="raise")
        if len(structures) != 1:
            raise RuntimeError(f"{cod_id}: expected one structure")
        structure = structures[0]
        structure.remove_oxidation_states()
        write_synthetic_model(structure, output / f"{cod_id}.cif")
        print(cod_id, structure.composition.reduced_formula, len(structure))


if __name__ == "__main__":
    main()
