#!/usr/bin/env python3
"""Run bounded GSAS-II refinement branches from a complete checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def axis(value: str | None):
    if value is None:
        return None
    result = [int(item) for item in value.split(",")]
    if len(result) != 3 or not any(result):
        raise argparse.ArgumentTypeError("axis must be h,k,l")
    return result


def clear_flags(project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def install_bounds(project) -> None:
    project.index_ids()
    bounds = (
        (":0:Zero", -0.8, 0.3),
        (":0:Shift", -800.0, 800.0),
        (":0:Polariz.", 0.5, 1.0),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:SurfRoughA", 0.05, 0.60),
        (":0:SurfRoughB", 0.02, 0.50),
    )
    for name, lower, upper in bounds:
        project.set_Controls("parmMin", lower, variable=name)
        project.set_Controls("parmMax", upper, variable=name)
    for phase in project.phases():
        pid = phase.data["pId"]
        for name, lower, upper in (
            (f"{pid}:0:Scale", 0.0, 1000.0),
            (f"{pid}:0:Size;i", 0.04, 1.5),
            (f"{pid}:0:Size;a", 0.04, 1.5),
            (f"{pid}:0:Mustrain;i", 0.0, 8000.0),
            (f"{pid}:0:Mustrain;a", 0.0, 32000.0),
            (f"{pid}:0:MD", 0.7, 1.4),
        ):
            project.set_Controls("parmMin", lower, variable=name)
            project.set_Controls("parmMax", upper, variable=name)
        for index, _ in enumerate(phase.atoms()):
            project.set_Controls("parmMin", 0.003, variable=f"{pid}::AUiso:{index}")
            project.set_Controls("parmMax", 0.020, variable=f"{pid}::AUiso:{index}")


def configure_common_uiso(project) -> None:
    # The frozen generator assigns one isotropic U value to every atom in a phase.
    if any(project.get_Constraints(scope) for scope in ("Hist", "HAP", "Phase", "Global")):
        return
    for phase in project.phases():
        pid = phase.data["pId"]
        variables = [f"{pid}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)


def configure(project, args) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        if args.cells:
            phase.set_refinements({"Cell": True})

    if args.zero:
        hist.InstrumentParameters["Zero"][2] = True
    if args.shift:
        hist.SampleParameters["Shift"][1] = True
    if args.polarization:
        hist.InstrumentParameters["Polariz."][2] = True
    if args.instrument or args.instrument_no_x:
        for key in (("U", "W", "SH/L") if args.instrument_no_x else ("U", "W", "X", "SH/L")):
            hist.InstrumentParameters[key][2] = True
    if args.roughness:
        if hist.SampleParameters["SurfRoughA"][0] <= 0:
            hist.SampleParameters["SurfRoughA"][0] = 0.30
        if hist.SampleParameters["SurfRoughB"][0] <= 0:
            hist.SampleParameters["SurfRoughB"][0] = 0.10
        hist.SampleParameters["SurfRoughA"][1] = True
        hist.SampleParameters["SurfRoughB"][1] = True

    if args.uiso:
        configure_common_uiso(project)
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = "U"

    strain_axes = [args.strain0, args.strain1]
    po_axes = [args.po0, args.po1]
    for phase_index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        if args.profiles:
            hap["Size"][2][0] = True
            hap["Mustrain"][2][0] = True
        if strain_axes[phase_index] is not None:
            old = float(hap["Mustrain"][1][0])
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1][0] = old
            if not (0.0 < float(hap["Mustrain"][1][1]) <= 32000.0):
                hap["Mustrain"][1][1] = old
            else:
                hap["Mustrain"][1][1] = old
            hap["Mustrain"][2][0] = True
            hap["Mustrain"][2][1] = True
            hap["Mustrain"][3] = strain_axes[phase_index]
        if po_axes[phase_index] is not None:
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = po_axes[phase_index]


def state(project, stage: str) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    try:
        fractions = {
            key: [float(value[0]), float(value[1])]
            for key, value in hist.ComputeMassFracs().items()
        }
    except Exception:
        fractions = {}
    return {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "fractions": fractions,
        "vary": list(cov.get("varyList", [])),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=10)
    parser.add_argument("--passes", type=int, default=2)
    parser.add_argument("--cells", action="store_true")
    parser.add_argument("--zero", action="store_true")
    parser.add_argument("--shift", action="store_true")
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--instrument", action="store_true")
    parser.add_argument("--instrument-no-x", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--uiso", action="store_true")
    parser.add_argument("--profiles", action="store_true")
    parser.add_argument("--strain0", type=axis)
    parser.add_argument("--strain1", type=axis)
    parser.add_argument("--po0", type=axis)
    parser.add_argument("--po1", type=axis)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    clear_flags(project)
    install_bounds(project)
    records = []
    for pass_index in range(args.passes):
        project.set_Frozen()
        clear_flags(project)
        configure(project, args)
        project.set_Controls("cycles", args.cycles)
        project.save()
        project.refine(makeBack=False)
        project.save()
        record = state(project, f"pass_{pass_index + 1}")
        records.append(record)
        print(json.dumps(record), flush=True)
    clear_flags(project)
    project.save()

    hist = project.histogram(0)
    summary = {
        "input": str(args.input),
        "output": str(args.output),
        "options": vars(args),
        "records": records,
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "phases": [],
    }
    for phase in project.phases():
        summary["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": list(atom.coordinates),
                        "uiso": float(atom.uiso),
                    }
                    for atom in phase.atoms()
                ],
                "hap": phase.data["Histograms"][hist.name],
            }
        )
    args.output.with_suffix(".branch.json").write_text(
        json.dumps(summary, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
