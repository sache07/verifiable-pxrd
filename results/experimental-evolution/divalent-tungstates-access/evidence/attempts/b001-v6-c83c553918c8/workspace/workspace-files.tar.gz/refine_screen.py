#!/usr/bin/env python3
"""Build and refine a two-phase CaWO4 + WO3 GSAS-II screening model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    normalized = Path(".tmp/registered_refs") / f"{cod_id}.cif"
    if normalized.exists():
        return normalized.resolve()
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_inputs(root: Path, pattern_csv: Path) -> tuple[Path, Path]:
    values = np.genfromtxt(pattern_csv, delimiter=",", names=True)
    x = np.asarray(values["two_theta_deg"], float)
    y = np.asarray(values["intensity"], float)
    sigma = np.sqrt(np.maximum(y, 1.0))
    xye = root / "observed.xye"
    np.savetxt(xye, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")
    inst = root / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha laboratory Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.350;Polariz.:0.75;Azimuth:0.0\n"
        "U:15.0;V:0.0;W:20.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.025\n"
    )
    return xye, inst


def set_background(hist, x: np.ndarray, y: np.ndarray) -> None:
    step = float(np.median(np.diff(x)))
    window = int(2.5 / step) | 1
    estimate = percentile_filter(y, percentile=12, size=window, mode="nearest")
    estimate = gaussian_filter1d(estimate, 50)
    scaled_x = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    coeffs = np.polynomial.chebyshev.chebfit(scaled_x, estimate, deg=11)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(coeffs),
                "coeffs": coeffs.tolist(),
                "refine": False,
            }
        }
    )


def clear_flags(project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def run_stage(project, name: str, cycles: int = 8) -> dict:
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    record = {
        "stage": name,
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(cov.get("Rvals", {}).get("converged", False)),
        "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "vary": list(cov.get("varyList", [])),
    }
    print(json.dumps(record), flush=True)
    return record


def configure_hap(phase, hist, *, size: float, strain: float) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = size
    hap["Size"][1][1] = size
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = strain
    hap["Mustrain"][1][1] = strain
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", required=True)
    parser.add_argument("--cawo4", default="7219229")
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--pattern", default=Path("inputs/pattern.csv"), type=Path)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    work = args.output.parent / f".{args.output.stem}_work"
    work.mkdir(parents=True, exist_ok=True)
    xye, inst = write_inputs(work, args.pattern.resolve())
    raw = np.genfromtxt(args.pattern, delimiter=",", names=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(args.output))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    set_background(hist, raw["two_theta_deg"], raw["intensity"])

    cawo4 = project.add_phase(
        str(cod_path(args.cawo4)), phasename="CaWO4_scheelite",
        histograms=[hist], fmthint="CIF",
    )
    wo3 = project.add_phase(
        str(cod_path(args.wo3)), phasename=f"WO3_{args.wo3}",
        histograms=[hist], fmthint="CIF",
    )
    configure_hap(cawo4, hist, size=0.30, strain=3500.0)
    configure_hap(wo3, hist, size=0.60, strain=300.0)

    # Keep the physically meaningful ranges used by the synthetic-lab protocol.
    project.save()
    project.index_ids()
    project.set_Controls("parmMin", -0.8, variable=":0:Zero")
    project.set_Controls("parmMax", 0.3, variable=":0:Zero")
    for key, lower, upper in (
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10),
    ):
        project.set_Controls("parmMin", lower, variable=f":0:{key}")
        project.set_Controls("parmMax", upper, variable=f":0:{key}")
    for phase in project.phases():
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")

    records = []
    # Initial calculation.
    clear_flags(project)
    records.append(run_stage(project, "initial", cycles=0))

    # Obtain positive phase scales against a flexible but smooth background.
    clear_flags(project)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    records.append(run_stage(project, "scale_background", cycles=10))

    # Align each crystal metric while retaining the common starting zero.
    clear_flags(project)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        phase.set_refinements({"Cell": True})
    records.append(run_stage(project, "cells_scales_background", cycles=12))

    # Refine the common angular zero, then the audited instrument family.
    clear_flags(project)
    hist.Background[0][1] = True
    hist.InstrumentParameters["Zero"][2] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        phase.set_refinements({"Cell": True})
    records.append(run_stage(project, "zero_cells_scales_background", cycles=12))

    clear_flags(project)
    hist.Background[0][1] = True
    for key in ("U", "W", "X", "SH/L"):
        hist.InstrumentParameters[key][2] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        phase.set_refinements({"Cell": True})
    records.append(run_stage(project, "instrument_cells_scales_background", cycles=12))

    # Isotropic per-phase size and strain are enough for reference screening.
    clear_flags(project)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
        hap["Mustrain"][2][0] = True
    records.append(run_stage(project, "phase_profiles", cycles=15))

    # One bounded alternating pass removes profile/instrument start-value bias.
    clear_flags(project)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist.Background[0][1] = True
    for key in ("U", "W", "X", "SH/L"):
        hist.InstrumentParameters[key][2] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        phase.set_refinements({"Cell": True})
    records.append(run_stage(project, "instrument_settle", cycles=12))

    clear_flags(project)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
        hap["Mustrain"][2][0] = True
    records.append(run_stage(project, "phase_profile_settle", cycles=12))

    clear_flags(project)
    project.save()
    summary = {
        "cawo4": args.cawo4,
        "wo3": args.wo3,
        "records": records,
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "instrument": {
            key: value[1] if isinstance(value, list) and len(value) > 1 else value
            for key, value in hist.InstrumentParameters.items()
        },
        "sample": hist.SampleParameters,
        "hap": {
            phase.name: phase.data["Histograms"][hist.name]
            for phase in project.phases()
        },
    }
    args.output.with_suffix(".screen.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps({"output": str(args.output), "Rwp_percent": records[-1]["Rwp_percent"]}))


if __name__ == "__main__":
    main()
