#!/usr/bin/env python3
"""Line-search a bounded fraction of a coordinate-refinement direction."""

from __future__ import annotations

import argparse
import numpy as np
from GSASII import GSASIIscriptable as G2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base")
    ap.add_argument("target")
    ap.add_argument("output")
    ap.add_argument("phase")
    ap.add_argument("element")
    ap.add_argument("--fraction", type=float, required=True)
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=args.base, newgpx=args.output)
    target = G2.G2Project(gpxfile=args.target)
    phase = project.phase(args.phase)
    target_phase = target.phase(args.phase)
    moved = []
    for atom, endpoint in zip(phase.atoms(), target_phase.atoms()):
        atom.refinement_flags = " "
        if atom.element != args.element:
            continue
        start = np.asarray(atom.coordinates, float)
        delta = np.asarray(endpoint.coordinates, float) - start
        delta -= np.round(delta)
        atom.coordinates = tuple(start + args.fraction * delta)
        moved.append(atom.label)
    for other in project.phases():
        for atom in other.atoms():
            atom.refinement_flags = " "
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.save()
    print({"output": project.filename, "phase": phase.name,
           "atoms": moved, "fraction": args.fraction,
           "rwp_percent": project.histograms()[0].get_wR()})


if __name__ == "__main__":
    main()
