#!/usr/bin/env python3
"""Refine one common isotropic displacement parameter per phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


def clear_flags(project):
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=args.input, newgpx=args.output)
    project.index_ids()
    records = []
    for phase in project.phases():
        clear_flags(project)
        variables = []
        for i, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "U"
            variable = f"{phase.id}::AUiso:{i}"
            variables.append(variable)
            project.set_Controls("parmMin", 0.0001, variable=variable)
            project.set_Controls("parmMax", 0.05, variable=variable)
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=True)
        project.set_Controls("cycles", 8)
        project.refine(makeBack=False)
        clear_flags(project)
        project.save()
        stage = f"uiso_{phase.name}"
        checkpoint = Path(project.filename).with_name(Path(project.filename).stem + f"_{stage}.gpx")
        shutil.copy2(project.filename, checkpoint)
        row = {"phase": phase.name, "rwp_percent": project.histograms()[0].get_wR(),
               "uiso_A2": [float(a.uiso) for a in phase.atoms()]}
        records.append(row)
        print(row)
    clear_flags(project)
    project.save()
    Path(project.filename).with_suffix(".uiso.json").write_text(
        json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
