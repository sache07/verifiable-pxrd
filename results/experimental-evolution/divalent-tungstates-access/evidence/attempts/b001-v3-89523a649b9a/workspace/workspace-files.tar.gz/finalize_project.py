#!/usr/bin/env python3
"""Create the clean, converged final GSAS-II project and export its phases."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path("refinements/recoord_wo3O_repeat.gpx")
OUTPUT = Path("final.gpx")
PHASE_CIFS = {
    "CuWO4": Path("phase_CuWO4.cif"),
    "Cu3WO6": Path("phase_Cu3WO6.cif"),
    "WO3": Path("phase_WO3.cif"),
    "CuO": Path("phase_CuO.cif"),
}


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUTPUT))
    hist = project.histograms()[0]

    # All structural coordinates have already been accepted in staged,
    # phase-by-phase refinements. The final pass is profile/nuisance-only.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "

    # Values that converged to a physically featureless bound are fixed there:
    # U=0, the minimum axial-divergence term, resolution-limited 10 um sizes,
    # and zero CuO microstrain. This removes repeated bound-freeze warnings
    # without altering the calculated profile.
    instrument = hist.data["Instrument Parameters"][0]
    for key in ("U", "SH/L"):
        instrument[key][2] = False
    hname = hist.name
    for phase in project.phases():
        hap = phase.data["Histograms"][hname]
        if hap["Size"][1][0] >= 9.999:
            hap["Size"][2][0] = False
        if hap["Mustrain"][1][0] <= 1e-12:
            hap["Mustrain"][2][0] = False

    # Uiso equality constraints were used only during their dedicated stage.
    # The accepted Uiso values are now fixed, so remove those unused constraints.
    constraints = project.data["Constraints"]["data"]
    for key in ("Global", "HAP", "Hist", "Phase"):
        constraints[key] = []
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}

    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    project.save()

    for phase in project.phases():
        phase.export_CIF(str(PHASE_CIFS[phase.name].resolve()))

    masses = [
        phase.data["General"]["Mass"]
        * phase.data["Histograms"][hname]["Scale"][0]
        for phase in project.phases()
    ]
    total = sum(masses)
    rvals = project.data["Covariance"]["data"]["Rvals"]
    summary = {
        "histogram": hname,
        "rwp_percent": float(hist.get_wR()),
        "gof": float(rvals["GOF"]),
        "chi_square": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_parameters": int(rvals["Nvars"]),
        "max_shift_over_esd": float(rvals["Max shft/sig"]),
        "phases": [
            {
                "name": phase.name,
                "weight_fraction": float(mass / total),
                "cif": str(PHASE_CIFS[phase.name]),
            }
            for phase, mass in zip(project.phases(), masses)
        ],
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
