#!/usr/bin/env python3
"""Quick reference-pattern diagnostics for the Cu-W-O PXRD case."""

from pathlib import Path
import json
import gzip

import numpy as np
import pandas as pd
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from scipy.ndimage import gaussian_filter1d, minimum_filter1d
from scipy.signal import find_peaks


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def observed_peaks():
    frame = pd.read_csv("inputs/pattern.csv")
    x = frame.iloc[:, 0].to_numpy(float)
    y = frame.iloc[:, 1].to_numpy(float)
    # A broad rolling minimum is adequate for peak-position diagnostics.
    baseline = gaussian_filter1d(minimum_filter1d(y, size=151), 60)
    signal = y - baseline
    idx, props = find_peaks(signal, prominence=350, distance=4, width=2)
    return x, y, baseline, x[idx], signal[idx], props["prominences"]


def score_reference(cod_id, obs_x, obs_height, obs_prom, show=20):
    structure = Structure.from_file(cif_path(cod_id))
    calc = XRDCalculator(wavelength="CuKa")
    patt = calc.get_pattern(structure, two_theta_range=(9, 101), scaled=True)
    px = np.asarray(patt.x)
    py = np.asarray(patt.y)
    # Optimize a simple global shift while tolerating modest cell mismatch.
    shifts = np.linspace(-0.8, 0.8, 641)
    best = None
    strong = py >= 1.0
    for shift in shifts:
        d = np.min(abs((px[strong, None] + shift) - obs_x[None, :]), axis=1)
        # Intensity-weighted robust position loss, with unmatched-line penalty.
        w = np.sqrt(py[strong])
        loss = np.sum(w * np.minimum(d, 0.45) ** 2) / np.sum(w)
        if best is None or loss < best[0]:
            best = (loss, shift, d)
    loss, shift, _ = best
    nearest = np.argmin(abs((px[:, None] + shift) - obs_x[None, :]), axis=1)
    delta = obs_x[nearest] - (px + shift)
    order = np.argsort(py)[::-1]
    print(f"\n{cod_id} {structure.composition.reduced_formula}: shift={shift:+.4f}, loss={loss:.5f}")
    print(" calc+shift   Irel   obs-near   delta  obs-prom")
    for i in order[:show]:
        j = nearest[i]
        print(f" {px[i]+shift:10.4f} {py[i]:6.1f} {obs_x[j]:10.4f} {delta[i]:+7.4f} {obs_prom[j]:9.0f}")


if __name__ == "__main__":
    _, _, _, ox, oh, op = observed_peaks()
    candidates = [
        "4000806", "4000807", "1527404", "2002403",
        "1011194", "9016057",
        "1004057", "1010618", "1521532", "1521533", "1528915",
        "1563541", "2311041", "2106293", "2107312",
    ]
    for candidate in candidates:
        score_reference(candidate, ox, oh, op)
