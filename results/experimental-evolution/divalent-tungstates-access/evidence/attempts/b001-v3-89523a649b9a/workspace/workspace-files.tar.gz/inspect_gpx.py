#!/usr/bin/env python3
"""Print compact fit and residual diagnostics for a GSAS-II project."""

import argparse
import json
import numpy as np
from scipy.signal import find_peaks, peak_widths
from GSASII import GSASIIscriptable as G2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("gpx")
    ap.add_argument("--n", type=int, default=40)
    args = ap.parse_args()
    project = G2.G2Project(gpxfile=args.gpx)
    hist = project.histograms()[0]
    x, obs, wt, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    step = float(np.median(np.diff(x)))
    # Smooth only for ranking coherent residuals, never for statistics.
    kernel = np.ones(5) / 5
    smooth = np.convolve(obs - calc, kernel, mode="same")
    pos, pp = find_peaks(smooth, prominence=120, distance=5, width=2)
    neg, nprom = find_peaks(-smooth, prominence=120, distance=5, width=2)
    po = np.argsort(pp["prominences"])[::-1][:args.n]
    no = np.argsort(nprom["prominences"])[::-1][:args.n]
    print(json.dumps({
        "histogram": hist.name,
        "rwp_percent": hist.get_wR(),
        "mean_observed": float(obs.mean()),
        "weighted_rms_noise_units": float(np.sqrt(np.mean((obs-calc)**2 / np.maximum(obs, 1)))),
        "instrument": {k: v[1] for k, v in hist.data["Instrument Parameters"][0].items()
                       if isinstance(v, list) and len(v) > 1},
    }, indent=2))
    print("positive residual peaks")
    for q in po:
        i = pos[q]
        print(f"{x[i]:9.4f} residual={smooth[i]:9.1f} prominence={pp['prominences'][q]:9.1f} width={pp['widths'][q]*step:.4f}")
    print("negative residual peaks")
    for q in no:
        i = neg[q]
        print(f"{x[i]:9.4f} residual={smooth[i]:9.1f} prominence={nprom['prominences'][q]:9.1f} width={nprom['widths'][q]*step:.4f}")


if __name__ == "__main__":
    main()
