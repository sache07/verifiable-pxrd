#!/usr/bin/env python3
"""Refine WO3 oxygen coordinates with parent-geometry W--O restraints."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIImath as G2mth
from GSASII import GSASIIlattice as G2lat


def initialize_restraints(project, phase, weight, esd):
    project.data["Restraints"]["data"][phase.name] = {
        "Bond": {"wtFactor": float(weight), "Range": 1.25,
                 "Bonds": [], "Use": True},
        "Angle": {"wtFactor": 1.0, "Range": 0.85, "Angles": [], "Use": False},
        "Plane": {"wtFactor": 1.0, "Planes": [], "Use": False},
        "Chiral": {"wtFactor": 1.0, "Volumes": [], "Use": False},
        "Torsion": {"wtFactor": 1.0, "Coeff": {}, "Torsions": [], "Use": False},
        "Rama": {"wtFactor": 1.0, "Coeff": {}, "Ramas": [], "Use": False},
        "Texture": {"wtFactor": 1.0, "HKLs": [], "Use": False},
        "ChemComp": {"wtFactor": 1.0, "Sites": [], "Use": False},
        "General": {"wtFactor": 1.0, "General": [], "Use": False},
    }
    tungsten = [a for a in phase.atoms() if a.element == "W"]
    oxygen = [a for a in phase.atoms() if a.element == "O"]
    phase.addDistRestraint(tungsten, oxygen, 2.0, factor=1.25, ESD=esd)

    # Replace the common search target by each bond's actual parent distance.
    bond_data = project.data["Restraints"]["data"][phase.name]["Bond"]
    atoms = phase.data["Atoms"]
    lookup = {a.ranId: i for i, a in enumerate(phase.atoms())}
    cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
    sg = phase.data["General"]["SGData"]
    amat, _ = G2lat.cell2AB(phase.data["General"]["Cell"][1:7])
    for row in bond_data["Bonds"]:
        ids, ops, _, _ = row
        xyz = np.array(G2mth.GetAtomItemsById(atoms, lookup, ids, cx, 3))
        xyz = G2mth.getSyXYZ(xyz, ops, sg)
        row[2] = float(G2mth.getRestDist(xyz, amat))
        row[3] = float(esd)
    return [row[2] for row in bond_data["Bonds"]]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--weight", type=float, required=True)
    ap.add_argument("--esd", type=float, default=0.04)
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=args.input, newgpx=args.output)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    phase = project.phase("WO3")
    targets = initialize_restraints(project, phase, args.weight, args.esd)
    for atom in phase.atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)
    for atom in phase.atoms():
        atom.refinement_flags = " "
    project.save()
    print({"output": project.filename, "weight": args.weight, "esd": args.esd,
           "restraint_targets_A": targets,
           "rwp_percent": project.histograms()[0].get_wR()})


if __name__ == "__main__":
    main()
