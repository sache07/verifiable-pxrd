#!/usr/bin/env python3
"""Refine one sublattice with bounded coordinate shifts from its input model."""

from __future__ import annotations

import argparse
import numpy as np
from GSASII import GSASIIscriptable as G2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("phase")
    ap.add_argument("element")
    ap.add_argument("--max-shift-A", type=float, default=0.08)
    ap.add_argument("--cycles", type=int, default=8)
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=args.input, newgpx=args.output)
    project.index_ids()
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    phase = project.phase(args.phase)
    lengths = np.asarray(phase.data["General"]["Cell"][1:4], float)
    bounds = args.max_shift_A / lengths
    selected = []
    for i, atom in enumerate(phase.atoms()):
        if atom.element != args.element:
            continue
        atom.refinement_flags = "X"
        selected.append(atom.label)
        for axis, bound in zip("xyz", bounds):
            variable = f"{phase.id}::dA{axis}:{i}"
            project.set_Controls("parmMin", -float(bound), variable=variable)
            project.set_Controls("parmMax", float(bound), variable=variable)
    project.set_Controls("cycles", args.cycles)
    project.refine(makeBack=False)
    for atom in phase.atoms():
        atom.refinement_flags = " "
    project.save()
    print({"output": project.filename, "phase": phase.name, "atoms": selected,
           "max_shift_A": args.max_shift_A,
           "rwp_percent": project.histograms()[0].get_wR()})


if __name__ == "__main__":
    main()
