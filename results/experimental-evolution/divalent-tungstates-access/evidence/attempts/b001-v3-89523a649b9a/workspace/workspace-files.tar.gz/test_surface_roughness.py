#!/usr/bin/env python3
"""Test Bragg-Brentano surface-roughness terms against a matched control."""

from __future__ import annotations

import argparse
from pathlib import Path
from GSASII import GSASIIscriptable as G2


def fit(source, output, rough):
    project = G2.G2Project(gpxfile=source, newgpx=output)
    hist = project.histograms()[0]
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    sample = hist.data["Sample Parameters"]
    if rough:
        sample["SurfRoughA"] = [0.1, True]
        sample["SurfRoughB"] = [0.1, True]
        for name in ["SurfRoughA", "SurfRoughB"]:
            project.set_Controls("parmMin", 0.0, variable=f":0:{name}")
            project.set_Controls("parmMax", 2.0, variable=f":0:{name}")
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.save()
    return {"rwp_percent": project.histograms()[0].get_wR(),
            "A": sample["SurfRoughA"][0], "B": sample["SurfRoughB"][0]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("outdir")
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    out = Path(args.outdir)
    out.mkdir(parents=True, exist_ok=True)
    print("control", fit(args.input, str(out / "control.gpx"), False))
    print("roughness", fit(args.input, str(out / "roughness.gpx"), True))


if __name__ == "__main__":
    main()
