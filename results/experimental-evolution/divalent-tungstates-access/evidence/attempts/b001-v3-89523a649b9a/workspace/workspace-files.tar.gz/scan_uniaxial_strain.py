#!/usr/bin/env python3
"""Compare phase-specific uniaxial microstrain axes from a common project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0)]


def run(base, output, phase_name=None, axis=None):
    project = G2.G2Project(gpxfile=base, newgpx=str(output))
    hist = project.histograms()[0]
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    if phase_name is not None:
        phase = project.phase(phase_name)
        strain = phase.data["Histograms"][hist.name]["Mustrain"]
        initial = max(1.0, float(strain[1][0]))
        strain[0] = "uniaxial"
        strain[1][0] = initial
        strain[1][1] = initial
        strain[2][0] = True
        strain[2][1] = True
        strain[3] = list(axis)
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;a")
        project.set_Controls("parmMax", 50000.0, variable=f"{phase.id}:0:Mustrain;a")
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.save()
    row = {"phase": phase_name or "control", "axis": list(axis) if axis else None,
           "rwp_percent": float(project.histograms()[0].get_wR())}
    if phase_name is not None:
        strain = project.phase(phase_name).data["Histograms"][hist.name]["Mustrain"]
        row.update(equatorial_ppm=float(strain[1][0]), axial_ppm=float(strain[1][1]))
    return row


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base")
    ap.add_argument("outdir")
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    out = Path(args.outdir)
    out.mkdir(parents=True, exist_ok=True)
    phases = [p.name for p in G2.G2Project(gpxfile=args.base).phases()]
    rows = [run(args.base, out / "control.gpx")]
    print(rows[-1])
    for phase in phases:
        for axis in AXES:
            token = "".join(map(str, axis))
            row = run(args.base, out / f"{phase}_{token}.gpx", phase, axis)
            rows.append(row)
            print(row)
    (out / "scan.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
