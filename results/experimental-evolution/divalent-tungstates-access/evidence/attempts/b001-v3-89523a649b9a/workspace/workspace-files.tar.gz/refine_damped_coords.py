#!/usr/bin/env python3
"""Take a damped coordinate step, then re-equilibrate nuisance parameters."""

from __future__ import annotations

import argparse
from GSASII import GSASIIscriptable as G2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("phase")
    ap.add_argument("element")
    ap.add_argument("--factor", type=float, default=0.1)
    ap.add_argument("--marquardt", type=int)
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=args.input, newgpx=args.output)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    phase = project.phase(args.phase)
    selected = []
    for atom in phase.atoms():
        if atom.element == args.element:
            atom.refinement_flags = "X"
            selected.append(atom.label)
    controls = project.data["Controls"]["data"]
    controls["shift factor"] = float(args.factor)
    if args.marquardt is not None:
        controls["Marquardt"] = int(args.marquardt)
    project.set_Controls("cycles", 1)
    project.refine(makeBack=False)
    for atom in phase.atoms():
        atom.refinement_flags = " "
    controls = project.data["Controls"]["data"]
    controls["shift factor"] = 1.0
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.save()
    print({"output": project.filename, "phase": phase.name, "atoms": selected,
           "damping_factor": args.factor,
           "marquardt": args.marquardt,
           "rwp_percent": project.histograms()[0].get_wR()})


if __name__ == "__main__":
    main()
