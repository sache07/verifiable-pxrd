#!/usr/bin/env python3
"""Refine selected coordinates for one phase from an existing project."""

from __future__ import annotations

import argparse
from GSASII import GSASIIscriptable as G2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("phase")
    ap.add_argument("elements", help="comma-separated element symbols")
    ap.add_argument("--cycles", type=int, default=8)
    args = ap.parse_args()
    selected_elements = set(args.elements.split(","))
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=args.input, newgpx=args.output)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    phase = project.phase(args.phase)
    selected = []
    for atom in phase.atoms():
        if atom.element in selected_elements:
            atom.refinement_flags = "X"
            selected.append(atom.label)
    project.set_Controls("cycles", args.cycles)
    project.refine(makeBack=False)
    for atom in phase.atoms():
        atom.refinement_flags = " "
    project.save()
    print({"phase": phase.name, "atoms": selected,
           "rwp_percent": project.histograms()[0].get_wR(),
           "output": project.filename})


if __name__ == "__main__":
    main()
