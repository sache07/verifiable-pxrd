#!/usr/bin/env python3
"""Add the coherent tenorite residual family and refine it in stages."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def fractions(project, histname):
    products = np.array([
        p.data["General"]["Mass"] * p.data["Histograms"][histname]["Scale"][0]
        for p in project.phases()
    ], float)
    return products / products.sum()


def snapshot(project, stage, records):
    project.save()
    target = Path(project.filename).with_name(Path(project.filename).stem + f"_{stage}.gpx")
    shutil.copy2(project.filename, target)
    hist = project.histograms()[0]
    row = {
        "stage": stage,
        "rwp_percent": hist.get_wR(),
        "weight_fractions": dict(zip(
            [p.name for p in project.phases()],
            map(float, fractions(project, hist.name)))),
    }
    records.append(row)
    Path(project.filename).with_suffix(".cuo.json").write_text(
        json.dumps(records, indent=2) + "\n"
    )
    print(row)


def clear_atoms(project):
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def refine(project, stage, records, cycles=8):
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    snapshot(project, stage, records)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--cod", default="1011194", choices=["1011194", "9016057"])
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=args.input, newgpx=args.output)
    hist = project.histograms()[0]
    clear_atoms(project)
    phase = project.add_phase(
        str(ROOT / "models" / f"cod_{args.cod}.cif"), phasename="CuO",
        histograms=[hist], fmthint="CIF")
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [10.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.3
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    phase.set_refinements({"Cell": True})
    project.index_ids()
    pid = phase.id
    for variable, lo, hi in [
        (f"{pid}:0:Scale", 0.0, 1e6),
        (f"{pid}:0:Size;i", 0.005, 100.0),
        (f"{pid}:0:Mustrain;i", 0.0, 50000.0),
    ]:
        project.set_Controls("parmMin", lo, variable=variable)
        project.set_Controls("parmMax", hi, variable=variable)
    records = []
    refine(project, "14_cuo_scale_cell", records, 10)
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": 0.3, "refine": True},
    })
    refine(project, "15_cuo_size", records)
    phase.set_HAP_refinements({
        "Mustrain": {"type": "isotropic", "refine": True},
    })
    refine(project, "16_cuo_strain", records)

    # Heavy and light coordinates are tested separately.
    clear_atoms(project)
    for atom in phase.atoms():
        if atom.element == "Cu":
            atom.refinement_flags = "X"
    refine(project, "17_cuo_copper", records)
    clear_atoms(project)
    for atom in phase.atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    refine(project, "18_cuo_oxygen", records)
    clear_atoms(project)
    project.save()
    print(f"Saved {project.filename}")


if __name__ == "__main__":
    main()
