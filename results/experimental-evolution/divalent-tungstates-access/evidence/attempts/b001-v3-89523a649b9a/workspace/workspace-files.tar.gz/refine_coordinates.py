#!/usr/bin/env python3
"""Refine accepted phase coordinates one phase and sublattice at a time."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


def phase_state(project):
    state = []
    for phase in project.phases():
        state.append({
            "name": phase.name,
            "atoms": [{
                "label": a.label, "element": a.element,
                "xyz": list(a.coordinates), "uiso": a.uiso,
                "flags": a.refinement_flags,
            } for a in phase.atoms()],
        })
    return state


def clear_coordinate_flags(project):
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def set_coordinate_flags(project, phase_name, elements):
    clear_coordinate_flags(project)
    phase = project.phase(phase_name)
    for atom in phase.atoms():
        if atom.element in elements:
            atom.refinement_flags = "X"


def snapshot(project, stage, records):
    project.save()
    copy = Path(project.filename).with_name(Path(project.filename).stem + f"_{stage}.gpx")
    shutil.copy2(project.filename, copy)
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    row = {
        "stage": stage,
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "vary_list": cov.get("varyList", []),
        "phases": phase_state(project),
    }
    records.append(row)
    Path(project.filename).with_suffix(".coordinates.json").write_text(
        json.dumps(records, indent=2, default=float) + "\n"
    )
    print(json.dumps({k: v for k, v in row.items() if k != "phases"}, indent=2, default=float))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=args.input, newgpx=args.output)
    records = []
    stages = [
        ("08_cuwo4_heavy", "CuWO4", {"Cu", "W"}),
        ("09_cu3wo6_heavy", "Cu3WO6", {"Cu", "W"}),
        ("10_wo3_heavy", "WO3", {"W"}),
        ("11_cuwo4_oxygen", "CuWO4", {"O"}),
        ("12_cu3wo6_oxygen", "Cu3WO6", {"O"}),
        ("13_wo3_oxygen", "WO3", {"O"}),
    ]
    for stage, phase, elements in stages:
        set_coordinate_flags(project, phase, elements)
        project.set_Controls("cycles", 8)
        project.refine(makeBack=False)
        snapshot(project, stage, records)
    clear_coordinate_flags(project)
    project.save()
    print(f"Saved {project.filename}")


if __name__ == "__main__":
    main()
