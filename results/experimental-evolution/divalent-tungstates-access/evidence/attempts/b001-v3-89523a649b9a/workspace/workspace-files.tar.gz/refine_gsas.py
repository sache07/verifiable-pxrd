#!/usr/bin/env python3
"""Build and stage a multiphase GSAS-II refinement for the Cu-W-O pattern.

Run with the GSAS-II Python interpreter. This first-pass script intentionally
stops before atom-coordinate and anisotropic profile experiments so candidate
phase sets and WO3 references can be compared on equal footing.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def read_pattern(path: Path):
    data = np.loadtxt(path, delimiter=",", skiprows=1)
    return data[:, 0], data[:, 1]


def write_xye(path: Path, x, y):
    with path.open("w") as stream:
        stream.write("# two_theta intensity; Poisson weights inferred by GSAS-II\n")
        for xx, yy in zip(x, y):
            stream.write(f"{xx:.8f} {yy:.8f}\n")


def write_inst(path: Path):
    path.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.03;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:12.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def initial_background(x, y, degree=12):
    """Estimate a smooth lower envelope and return Chebyshev coefficients."""
    edges = np.linspace(x[0], x[-1], 92)
    centers, values = [], []
    for lo, hi in zip(edges[:-1], edges[1:]):
        sel = (x >= lo) & (x < hi)
        if np.any(sel):
            centers.append((lo + hi) / 2)
            values.append(float(np.quantile(y[sel], 0.12)))
    baseline = np.interp(x, centers, values)
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(t, baseline, degree - 1).tolist()


def phase_summary(project, histname):
    masses, scales = [], []
    rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histname]
        mass = float(phase.data["General"]["Mass"])
        scale = float(hap["Scale"][0])
        masses.append(mass)
        scales.append(scale)
    products = np.asarray(masses) * np.asarray(scales)
    fractions = products / products.sum()
    for phase, scale, fraction in zip(project.phases(), scales, fractions):
        g = phase.data["General"]
        hap = phase.data["Histograms"][histname]
        rows.append({
            "name": phase.name,
            "scale": scale,
            "weight_fraction": float(fraction),
            "cell": [float(v) for v in g["Cell"][1:]],
            "size": list(hap["Size"][1]),
            "mustrain": list(hap["Mustrain"][1]),
            "pref_ori": list(hap["Pref.Ori."][:4]),
        })
    return rows


def snapshot(project, tag, stage, log):
    project.save()
    target = project.filename.rsplit(".gpx", 1)[0] + f"_{stage}.gpx"
    shutil.copy2(project.filename, target)
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    record = {
        "stage": stage,
        "rwp_percent": float(hist.get_wR()) if hist.get_wR() is not None else None,
        "gof": cov.get("Rvals", {}).get("GOF"),
        "chisq": cov.get("Rvals", {}).get("chisq"),
        "variables": cov.get("varyList", []),
        "instrument": {k: v[1] for k, v in hist.data["Instrument Parameters"][0].items()
                       if isinstance(v, list) and len(v) > 1},
        "sample": {k: (v[0] if isinstance(v, list) else v)
                   for k, v in hist.data["Sample Parameters"].items()
                   if k in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius", "Type"}},
        "phases": phase_summary(project, hist.name),
    }
    log.append(record)
    Path(project.filename).with_suffix(".stages.json").write_text(
        json.dumps(log, indent=2, default=float) + "\n"
    )
    print(json.dumps(record, indent=2, default=float))


def refine(project, stage, log):
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    snapshot(project, "", stage, log)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", default="1528915")
    parser.add_argument("--tag", default="trial")
    parser.add_argument("--omit", action="append", default=[],
                        choices=["CuWO4", "Cu3WO6", "WO3"])
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    out = ROOT / "refinements"
    out.mkdir(exist_ok=True)
    x, y = read_pattern(ROOT / "inputs/pattern.csv")
    xye = out / "pattern.xye"
    instfile = out / "instrument.instprm"
    write_xye(xye, x, y)
    write_inst(instfile)

    gpx = out / f"{args.tag}.gpx"
    project = G2.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(
        str(xye), str(instfile), fmthint="Topas xye"
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [780.0, False]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]

    coeffs = initial_background(x, y, degree=12)
    hist.set_refinements({
        "Limits": [float(x[0]), float(x[-1])],
        "Background": {"type": "chebyschev-1", "no. coeffs": len(coeffs),
                       "coeffs": coeffs, "refine": True},
    })

    candidates = [
        ("CuWO4", "4000806"),
        ("Cu3WO6", "1527404"),
        ("WO3", args.wo3),
    ]
    phases = []
    for name, cod_id in candidates:
        if name in args.omit:
            continue
        phase = project.add_phase(
            str(ROOT / "models" / f"cod_{cod_id}.cif"),
            phasename=name, histograms=[hist], fmthint="CIF"
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        phases.append(phase)

    # Broad physical limits prevent the least-squares path from exploiting
    # negative analytic widths or zero-sized domains.
    project.index_ids()
    bounds = {
        ":0:U": (0.0, 200.0), ":0:W": (0.0, 200.0),
        ":0:X": (0.0, 50.0), ":0:SH/L": (0.002, 0.5),
        ":0:Polariz.": (0.0, 1.0), ":0:Zero": (-1.0, 1.0),
        ":0:Shift": (-2500.0, 2500.0),
    }
    for i, _phase in enumerate(phases):
        bounds[f"{i}:0:Scale"] = (0.0, 1.0e6)
        bounds[f"{i}:0:Size;i"] = (0.005, 100.0)
        bounds[f"{i}:0:Mustrain;i"] = (0.0, 50000.0)
    for variable, (lower, upper) in bounds.items():
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)

    log = []
    # Stage 1: intensities and smooth background at a physically informed shift.
    refine(project, "01_scale_background", log)

    # Stage 2: shared angular corrections, then independently allowed cells.
    hist.set_refinements({
        "Sample Parameters": ["Shift"],
        "Instrument Parameters": ["Zero"],
    })
    refine(project, "02_shift_zero", log)
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "03_cells", log)

    # Stage 3: common instrumental width/asymmetry.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, "04_instrument_profile", log)

    # Stage 4: phase-specific isotropic size, followed by strain. Separating
    # these highly correlated broadening terms gives cleaner convergence.
    for phase in phases:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 0.3, "refine": True},
        })
    refine(project, "05_phase_size", log)
    for phase in phases:
        phase.set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    refine(project, "06_phase_strain", log)

    # Polarization is intensity-sensitive; add it only after profile convergence.
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "07_polarization", log)
    print(f"Saved {gpx}")


if __name__ == "__main__":
    main()
