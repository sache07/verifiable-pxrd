#!/usr/bin/env python3
"""Normalize selected COD models exactly as the synthetic forward model does."""

from pathlib import Path
import sys

from pymatgen.io.cif import CifParser

RUNTIME = Path("learned/divalent-tungstates/runtime").resolve()
sys.path.insert(0, str(RUNTIME))
from models import write_synthetic_model  # noqa: E402

COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def load(cod_id: str):
    parser = CifParser(cod_path(cod_id), occupancy_tolerance=1.0,
                       site_tolerance=1e-5, frac_tolerance=0)
    return parser.parse_structures(primitive=False, on_error="raise")[0]


if __name__ == "__main__":
    out = Path("models")
    out.mkdir(exist_ok=True)
    for cod_id in [
        "4000806", "1527404", "1011194", "9016057",
        "1010618", "1528915", "2311041", "2106293", "2107312",
    ]:
        target = out / f"cod_{cod_id}.cif"
        write_synthetic_model(load(cod_id), target)
        print(target)
