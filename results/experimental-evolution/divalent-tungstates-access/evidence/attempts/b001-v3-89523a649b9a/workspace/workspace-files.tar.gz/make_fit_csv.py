#!/usr/bin/env python3
"""Write the submitted profile from the independent final.gpx replay."""

from pathlib import Path

import numpy as np


def main() -> None:
    with np.load(Path("verification/prediction.npz"), allow_pickle=False) as data:
        x = np.asarray(data["x"], dtype=float)
        observed = np.asarray(data["observed"], dtype=float)
        calculated = np.asarray(data["predicted"], dtype=float)
    table = np.column_stack((x, observed, calculated, observed - calculated))
    np.savetxt(
        "fit.csv",
        table,
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=("%.8f", "%.8f", "%.8f", "%.8f"),
    )


if __name__ == "__main__":
    main()
