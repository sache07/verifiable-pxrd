#!/usr/bin/env python3
"""Compare single-phase March-Dollase texture axes from a common project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def weights(project, histname):
    p = np.array([x.data["General"]["Mass"] * x.data["Histograms"][histname]["Scale"][0]
                  for x in project.phases()], float)
    return p / p.sum()


def run(base, output, phase_name=None, axis=None):
    project = G2.G2Project(gpxfile=base, newgpx=str(output))
    hist = project.histograms()[0]
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.data["Histograms"][hist.name]["Pref.Ori."][2] = False
    if phase_name is not None:
        phase = project.phase(phase_name)
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = list(axis)
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.save()
    row = {
        "phase": phase_name or "control",
        "axis": list(axis) if axis else None,
        "rwp_percent": float(project.histograms()[0].get_wR()),
        "weight_fractions": dict(zip([p.name for p in project.phases()],
                                     map(float, weights(project, hist.name)))),
    }
    if phase_name is not None:
        po = project.phase(phase_name).data["Histograms"][hist.name]["Pref.Ori."]
        row["md_ratio"] = float(po[1])
    return row


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base")
    ap.add_argument("outdir")
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    out = Path(args.outdir)
    out.mkdir(parents=True, exist_ok=True)
    base_project = G2.G2Project(gpxfile=args.base)
    phases = [p.name for p in base_project.phases()]
    rows = [run(args.base, out / "control.gpx")]
    print(rows[-1])
    for phase in phases:
        for axis in AXES:
            token = "".join(map(str, axis))
            row = run(args.base, out / f"{phase}_{token}.gpx", phase, axis)
            rows.append(row)
            print(row)
    (out / "scan.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
