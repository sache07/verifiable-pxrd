#!/usr/bin/env python3
"""Normalize CIF syntax for source files that GSAS-II cannot import directly."""

import json
from pathlib import Path
import sys
import warnings

from pymatgen.core import Structure
from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = Path("analysis/candidates")
OUT.mkdir(parents=True, exist_ok=True)

records = []
for cod_id, label in [("2002403", "Cu2WO4"), ("1563541", "WO3")]:
    source = ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"
    structure = Structure.from_file(source)
    structure.remove_oxidation_states()
    target = OUT / f"{label}_{cod_id}_normalized.cif"
    # The source geometry, species, occupancies and P1-expanded multiplicities are
    # retained. Only CIF serialization is normalized for GSAS-II compatibility.
    CifWriter(structure, symprec=None, write_site_properties=True).write_file(target)
    records.append(
        {
            "id": cod_id,
            "source": str(source),
            "output": str(target),
            "operation": "pymatgen parse, oxidation-decoration removal, and P1 CIF reserialization; no geometric change",
            "composition": str(structure.composition),
            "sites": len(structure),
        }
    )

(OUT / "provenance.json").write_text(json.dumps(records, indent=2) + "\n")

# Recreate the registration normalization used by the supplied synthetic
# laboratory. These are the appropriate starting parents for fine refinement.
runtime = Path("learned/divalent-tungstates/runtime").resolve()
sys.path.insert(0, str(runtime))
from models import write_synthetic_model

registered_ids = ["4000806", "2311041", "2106293", "1527404", "1011194", "9016057", "2002403"]
registered = []
for cod_id in registered_ids:
    source = ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        parser = CifParser(source, occupancy_tolerance=1.0, site_tolerance=1e-5, frac_tolerance=0)
        structure = parser.parse_structures(primitive=False, on_error="raise")[0]
    structure.remove_oxidation_states()
    target = OUT / f"registered_{cod_id}.cif"
    write_synthetic_model(structure, target)
    registered.append(
        {
            "id": cod_id,
            "source": str(source),
            "output": str(target),
            "operation": "synthetic-lab registration normalization: neutral elements, symprec 0.001 A, Uiso 0.005 A2",
            "composition": str(structure.composition),
            "sites": len(structure),
            "warnings": [str(w.message) for w in caught],
        }
    )
(OUT / "registered_provenance.json").write_text(json.dumps(registered, indent=2) + "\n")
