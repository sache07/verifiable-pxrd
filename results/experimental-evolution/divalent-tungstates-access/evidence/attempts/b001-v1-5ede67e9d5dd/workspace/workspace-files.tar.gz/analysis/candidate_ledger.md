# Candidate ledger

All comparisons used the same observed histogram and common nuisance settings at
the stated screening stage. `Tested` means a completed valid trial; the four
entries marked *nominated* are active in `final.gpx`. `Unknown` is retained for
branches that did not reach a valid comparison and is not treated as rejection.

| Candidate | Status | Common-setting result and disposition |
|---|---|---|
| CuWO4 P-1, COD 4000806 | tested — nominated | Dominant family match; stable positive scale and physically small coordinate shifts. |
| CuWO4 P2/c, COD 4000807 | rejected | Replacement trial Rwp 44.42%; addition required implausible cell distortion for a small apparent contribution. |
| WO3 P21/c, COD 2311041 | tested — nominated | Best valid same-formula shift-level screen, Rwp 10.264%; remained best in the common isotropic-profile shortlist. |
| WO3 P21/c, COD 1528915 | rejected | Common screen Rwp about 11.22% and poorer fine-profile fit than COD 2311041. |
| WO3 P-1, COD 2106293 | rejected | Close shift-level alternative (Rwp 10.341%) but poorer common-profile fit; adding it beside the selected WO3 required about 1% metric distortion for only about 1 wt%. |
| WO3 P21/m, COD 1010618 | rejected | Valid common screen, Rwp 30.87%. |
| WO3 Pnma, COD 2107312 | rejected | Valid common screen, Rwp 21.00%. |
| WO3 P4/nmm, COD 1521533 | rejected | Valid common screen, Rwp 22.74%. |
| WO3 P1, COD 1563541 | rejected | Valid normalized screen, Rwp 23.32%. |
| WO3 P4/ncc, COD 1521532 | unknown | Trial did not reach a valid stable comparison. |
| WO3 P6/mmm, COD 1004057 | unknown | Trial did not reach a valid stable comparison. |
| Cu3WO6 Pa-3, COD 1527404 | tested — nominated | Stable contribution explaining the 15.20, 19.80, 32.51, 33.78, 36.24, 49.70, 57.60, 63.29 and 70.23 degree family. |
| CuO C2/c, COD 1011194 | tested — nominated | Stable minor contribution explaining the 35.09, 38.32, 48.45, 53.04, 58.11 and 65.34 degree family. |
| CuO Cc, COD 9016057 | tested | Nearly powder-equivalent to C2/c after registration normalization (Rwp 6.58809% versus 6.58800%); the conventional C2/c model was nominated. |
| Cu2WO4 P1, COD 2002403 | rejected | Small apparent scale required c-axis and beta distortions beyond the analogue-mismatch range. |
| Cu2O Pn-3m, COD 1010941 | rejected | About 0.5 wt% apparent contribution with an implausibly contracted refined cell. |
| Cu4O3 I41/amd, COD 9000603 | rejected | Scale collapsed to 1e-9 in the fixed-cell inventory trial. |

## Refinement-complexity ledger

| Branch | Status | Evidence |
|---|---|---|
| CuWO4 isotropic size; WO3 isotropic microstrain | tested — retained | Large, stable profile improvement; forcing CuWO4 strain to zero worsened Rwp from 2.59% to 2.77%. The correlated CuWO4 size/strain pair was not co-refined. |
| CuWO4 and Cu3WO6 heavy-atom coordinates; CuWO4 oxygen coordinates | tested — retained | Strong/stable heavy-atom gains; CuWO4 O shifts remained about 0.02 A RMS. |
| WO3 common Uiso | tested — retained | Interior value near 0.011 A2 and reproducible improvement. |
| WO3/Cu3WO6 oxygen-coordinate branches | rejected | Required coordinate shifts beyond the allowed reference-mismatch scale. |
| Surface roughness | rejected | Parameters were about 99.98% correlated and boundary-seeking. |
| March-Dollase texture, all allowed axes | rejected | Ratios remained approximately 0.988–1.009 with negligible gains. |
| WO3 uniaxial microstrain, five axes | rejected | Axial/equatorial values converged toward equality and every branch worsened the final fit. |
| SH/L with specimen shift fixed | tested — retained | Stable interior value 0.02897 and lower Rwp without the prior SH/L–shift correlation. |

No coherent positive residual family remained after the four-phase inventory.
Residual extrema were paired positive/negative lobes at already modeled peaks,
so further phase additions were not pursued.
