#!/usr/bin/env python3
"""Create submission tables from the independently replayed final GSAS-II project."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    with np.load(ROOT / "prediction.npz") as arrays:
        x = arrays["x"].astype(float)
        observed = arrays["observed"].astype(float)
        calculated = arrays["predicted"].astype(float)
        background = arrays["background"].astype(float)
    replay = json.loads((ROOT / "replay.json").read_text())
    refinement = json.loads((ROOT / "final.json").read_text())[0]
    if replay["status"] != "replayed":
        raise RuntimeError("final.gpx did not replay")
    if replay["project_sha256"] != sha256(ROOT / "final.gpx"):
        raise RuntimeError("replayed project hash does not match final.gpx")

    difference = observed - calculated
    weights = 1.0 / np.maximum(observed, 1.0)
    weighted_ss = float(np.sum(weights * difference**2))
    weighted_denominator = float(np.sum(weights * observed**2))
    rwp = 100.0 * np.sqrt(weighted_ss / weighted_denominator)
    rp = 100.0 * float(np.sum(np.abs(difference)) / np.sum(np.abs(observed)))

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(["two_theta", "observed", "calculated", "difference", "background"])
        for row in zip(x, observed, calculated, difference, background):
            writer.writerow([f"{row[0]:.8f}", f"{row[1]:.8f}", f"{row[2]:.10f}", f"{row[3]:.10f}", f"{row[4]:.10f}"])

    identity = {
        "CuWO4_P-1": ("CuWO4", "P -1", "triclinic CuWO4"),
        "WO3_P21c": ("WO3", "P 21/c", "monoclinic WO3"),
        "Cu3WO6_Pa-3": ("Cu3WO6", "P a -3", "cubic Cu3WO6"),
        "CuO_C2c": ("CuO", "C 2/c", "tenorite CuO"),
    }
    formal_esd = {
        "CuWO4_P-1": 0.00038,
        "WO3_P21c": 0.00035,
        "Cu3WO6_Pa-3": 0.00022,
        "CuO_C2c": 0.00021,
    }
    phases = []
    for phase in replay["phases"]:
        formula, space_group, label = identity[phase["name"]]
        cif = ROOT / phase["cif"]
        if not cif.is_file():
            raise FileNotFoundError(cif)
        phases.append(
            {
                "name": label,
                "formula": formula,
                "space_group": space_group,
                "cif_path": phase["cif"],
                "weight_fraction": phase["weight_fraction"],
                "formal_weight_fraction_esd": formal_esd[phase["name"]],
            }
        )
    if not np.isclose(sum(p["weight_fraction"] for p in phases), 1.0, atol=1e-12):
        raise RuntimeError("phase fractions are not normalized")

    result = {
        "phases": phases,
        "fraction_basis": "normalized over the four modeled crystalline phases; no amorphous fraction or absolute assay",
        "fit_statistics": {
            "Rwp_percent": float(rwp),
            "Rp_percent": float(rp),
            "Rexp_percent": float(refinement["Rwp_percent"] / refinement["GOF"]),
            "GOF": float(refinement["GOF"]),
            "weighted_sum_of_squares": weighted_ss,
            "observations": int(len(x)),
            "refined_variables": int(refinement["Nvars"]),
            "weighting": "1/max(observed_counts, 1); no pointwise standard uncertainties supplied",
            "profile_source": "read-only native GSAS-II replay of final.gpx on the complete original grid",
        },
        "refinement_histogram": replay["histogram"],
        "project_path": "final.gpx",
        "project_sha256": replay["project_sha256"],
        "profile_review_flags": replay["profile_review_flags"],
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
