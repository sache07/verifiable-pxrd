#!/usr/bin/env python3
"""Run staged, reproducible GSAS-II candidate trials on the supplied scan.

This deliberately keeps atomic coordinates fixed. It is used for phase inventory
screening with common nuisance settings; fine refinement is performed only after
the inventory is selected.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import shutil
import sys

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2


def parse_phase(spec: str) -> tuple[str, Path]:
    try:
        name, path = spec.split("=", 1)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("phase must be NAME=PATH") from exc
    return name, Path(path).resolve()


def background_coefficients(pattern: Path, degree: int = 11) -> list[float]:
    x, y = np.loadtxt(pattern, delimiter=",", skiprows=1).T
    # A broad lower envelope gives a stable initialization without following peaks.
    baseline = percentile_filter(y, percentile=12, size=501, mode="nearest")
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(t, baseline, degree).tolist()


def phase_summary(phase, hist_name: str) -> dict:
    hap = phase.data["Histograms"][hist_name]
    cell = phase.data["General"]["Cell"]
    return {
        "name": phase.name,
        "scale": float(hap["Scale"][0]),
        "cell": [float(v) for v in cell[1:8]],
        "mass": float(phase.data["General"]["Mass"]),
        "size": list(hap["Size"][1]),
        "mustrain": list(hap["Mustrain"][1]),
    }


def valid_project(project, hist) -> tuple[bool, str]:
    vals = np.asarray(hist.data["data"][1][3], dtype=float)
    if not np.all(np.isfinite(vals)):
        return False, "nonfinite calculated profile"
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if not math.isfinite(hap["Scale"][0]) or hap["Scale"][0] <= 0:
            return False, f"nonpositive scale for {phase.name}"
        cell = phase.data["General"]["Cell"]
        if not all(math.isfinite(v) and v > 0 for v in cell[1:4]) or cell[7] <= 0:
            return False, f"invalid cell for {phase.name}"
    return True, "ok"


def log_state(project, hist, stage: str) -> dict:
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    state = {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "shift_um": float(sample["Shift"][0]),
        "instrument": {k: float(inst[k][1]) for k in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."] if k in inst},
        "phases": [phase_summary(p, hist.name) for p in project.phases()],
    }
    ok, reason = valid_project(project, hist)
    state.update(valid=ok, validity_reason=reason)
    return state


def refine_stage(project, hist, stage: str, set_hist=None, set_phase=None, set_hap=None):
    if set_hist:
        hist.set_refinements(set_hist)
    if set_phase:
        for phase in project.phases():
            phase.set_refinements(set_phase)
    if set_hap:
        for phase in project.phases():
            phase.set_HAP_refinements(set_hap, [hist])
    project.refine(makeBack=False)
    return log_state(project, hist, stage)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--instrument", type=Path, default=Path("analysis/instrument.instprm"))
    parser.add_argument("--phase", action="append", type=parse_phase, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--shift", type=float, default=760.0)
    parser.add_argument("--background-terms", type=int, default=12)
    parser.add_argument(
        "--stop-after",
        choices=["scale_background", "cells", "shift", "gaussian_profile", "lorentz_profile", "size", "microstrain"],
        default="microstrain",
    )
    args = parser.parse_args()

    args.out.parent.mkdir(parents=True, exist_ok=True)
    work_gpx = args.out.with_suffix(".working.gpx")
    if work_gpx.exists():
        work_gpx.unlink()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(work_gpx.resolve()))
    phases = []
    seen_names: set[str] = set()
    for name, path in args.phase:
        if not path.exists():
            raise FileNotFoundError(path)
        if name in seen_names:
            raise ValueError(f"duplicate phase name {name}")
        seen_names.add(name)
        phases.append(project.add_phase(str(path), phasename=name, fmthint="CIF"))
    hist = project.add_powder_histogram(
        str(args.pattern.resolve()), str(args.instrument.resolve()), phases=phases,
        fmthint="comma/tab/semicolon separated",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    # Refining the histogram scale together with all HAP scales is exactly singular.
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [float(args.shift), False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    coeffs = background_coefficients(args.pattern, args.background_terms - 1)
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1", "no. coeffs": args.background_terms,
            "coeffs": coeffs, "refine": False,
        }
    })
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        # Positive, comparable initialization addressed through the phase object.
        hap["Scale"] = [1.0 / phase.data["General"]["Mass"], False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    project.set_Controls("cycles", 8)
    project.save()
    # Physical screening bounds. Zero is held at the reported wavelength model
    # during inventory trials to avoid its near-exact correlation with displacement.
    for variable, low, high in [
        (f":{hist.id}:Shift", -1250.0, 1250.0),
        (f":{hist.id}:U", 0.0, 40.0),
        (f":{hist.id}:W", 2.0, 40.0),
        (f":{hist.id}:X", 0.1, 6.0),
    ]:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    for phase in phases:
        for suffix, low, high in [("Scale", 1e-9, 1e6), ("Size;i", 0.04, 1.5), ("Mustrain;i", 0.0, 8000.0)]:
            variable = f"{phase.id}:{hist.id}:{suffix}"
            project.set_Controls("parmMin", low, variable=variable)
            project.set_Controls("parmMax", high, variable=variable)

    states = [log_state(project, hist, "initialized")]
    stages = [
        ("scale_background", {"Background": {"refine": True}}, None, {"Scale": True}),
        ("cells", None, {"Cell": True}, None),
        ("shift", {"Sample Parameters": ["Shift"]}, None, None),
        ("gaussian_profile", {"Instrument Parameters": ["U", "W"]}, None, None),
        ("lorentz_profile", {"Instrument Parameters": ["X"]}, None, None),
        ("size", None, None, {"Size": {"type": "isotropic", "refine": True, "value": 0.3}}),
        ("microstrain", None, None, {"Mustrain": {"type": "isotropic", "refine": True}}),
    ]
    last_good = args.out.with_suffix(".last_good.gpx")
    shutil.copy2(work_gpx, last_good)
    try:
        for stage, hs, ps, haps in stages:
            state = refine_stage(project, hist, stage, hs, ps, haps)
            states.append(state)
            if not state["valid"]:
                raise RuntimeError(state["validity_reason"])
            shutil.copy2(work_gpx, last_good)
            if stage == args.stop_after:
                break
    except Exception as exc:
        states.append({"stage": "failed", "error": repr(exc)})
        shutil.copy2(last_good, args.out)
    else:
        project.save(str(args.out.resolve()))
    finally:
        args.out.with_suffix(".json").write_text(json.dumps(states, indent=2, allow_nan=False) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
