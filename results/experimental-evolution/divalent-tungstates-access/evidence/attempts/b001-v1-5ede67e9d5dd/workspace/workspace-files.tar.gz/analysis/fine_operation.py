#!/usr/bin/env python3
"""Apply one controlled GSAS-II refinement operation to a stable project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def selected_phase(project, name):
    phase = project.phase(name)
    if phase is None:
        raise ValueError(f"phase not found: {name}")
    return phase


def add_bound(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def max_correlations(project, count=12):
    cov = project.data.get("Covariance", {}).get("data", {})
    matrix = cov.get("covMatrix")
    vary = cov.get("varyList", [])
    sig = np.asarray(cov.get("sig", []), dtype=float)
    if matrix is None or len(sig) != len(vary) or not len(vary):
        return []
    matrix = np.asarray(matrix, dtype=float)
    denom = np.outer(sig, sig)
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom != 0)
    rows = []
    for i in range(len(vary)):
        for j in range(i):
            rows.append((abs(float(corr[i, j])), float(corr[i, j]), vary[j], vary[i]))
    rows.sort(reverse=True)
    return [{"absolute": a, "value": v, "first": x, "second": y} for a, v, x, y in rows[:count]]


def snapshot(project, operation, repeat):
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    masses, phases = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        masses.append(mass)
        phases.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell": phase.get_cell(),
                "size": {"type": hap["Size"][0], "values": list(hap["Size"][1]), "flags": list(hap["Size"][2])},
                "mustrain": {"type": hap["Mustrain"][0], "values": list(hap["Mustrain"][1]), "flags": list(hap["Mustrain"][2]), "axis": list(hap["Mustrain"][3])},
                "preferred_orientation": list(hap["Pref.Ori."][:4]),
                "atoms": [
                    {"label": a.label, "element": a.element, "xyz": list(a.coordinates), "uiso": float(a.uiso), "flags": a.refinement_flags}
                    for a in phase.atoms()
                ],
            }
        )
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = mass / sum(masses)
    inst = hist.data["Instrument Parameters"][0]
    return {
        "operation": operation,
        "repeat": repeat,
        "Rwp_percent": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "max_shift_over_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "vary_list": cov.get("varyList", []),
        "instrument": {k: float(inst[k][1]) for k in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."] if k in inst},
        "sample": {k: hist.SampleParameters[k] for k in ["Shift", "SurfRoughA", "SurfRoughB", "Transparency"]},
        "phases": phases,
        "max_correlations": max_correlations(project),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }


def apply_operation(project, operation):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    parts = operation.split(":")
    kind = parts[0]
    if kind == "shl":
        inst["SH/L"][2] = True
        add_bound(project, f":{hist.id}:SH/L", 0.005, 0.10)
    elif kind == "shl-fixedshift":
        hist.SampleParameters["Shift"][1] = False
        inst["SH/L"][2] = True
        add_bound(project, f":{hist.id}:SH/L", 0.005, 0.10)
    elif kind == "zero-fixedshift":
        hist.SampleParameters["Shift"][1] = False
        inst["Zero"][2] = True
        add_bound(project, f":{hist.id}:Zero", -0.25, 0.25)
    elif kind == "polarization":
        inst["Polariz."][2] = True
        add_bound(project, f":{hist.id}:Polariz.", 0.5, 1.0)
    elif kind == "roughness":
        hist.SampleParameters["SurfRoughA"] = [0.25, True]
        hist.SampleParameters["SurfRoughB"] = [0.08, True]
        add_bound(project, f":{hist.id}:SurfRoughA", 0.05, 0.60)
        add_bound(project, f":{hist.id}:SurfRoughB", 0.02, 0.50)
    elif kind == "background":
        terms = int(parts[1])
        hist.set_refinements({"Background": {"no. coeffs": terms, "refine": True}})
    elif kind in {"size", "strain", "coords-heavy", "coords-oxygen", "coords-all", "uiso", "uiso-common"}:
        phase = selected_phase(project, parts[1])
        if kind == "size":
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
            add_bound(project, f"{phase.id}:{hist.id}:Size;i", 0.04, 1.5)
        elif kind == "strain":
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
            add_bound(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 8000.0)
        elif kind != "uiso-common":
            for atom in phase.atoms():
                take = kind in {"coords-all", "uiso"}
                if kind == "coords-heavy": take = atom.element != "O"
                if kind == "coords-oxygen": take = atom.element == "O"
                if take:
                    atom.refinement_flags = "U" if kind == "uiso" else "X"
                    if kind == "uiso":
                        # atom indices, rather than labels, identify GSAS atom variables
                        atom_index = [a.label for a in phase.atoms()].index(atom.label)
                        add_bound(project, f"{phase.id}::AUiso:{atom_index}", 0.003, 0.020)
        else:
            variables = []
            for atom_index, atom in enumerate(phase.atoms()):
                atom.refinement_flags = "U"
                variable = f"{phase.id}::AUiso:{atom_index}"
                variables.append(variable)
                add_bound(project, variable, 0.003, 0.020)
            project.add_EquivConstr(variables, reloadIdx=True)
    elif kind == "preferred":
        phase = selected_phase(project, parts[1])
        axis = [int(v) for v in parts[2].split(",")]
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
        add_bound(project, f"{phase.id}:{hist.id}:MD", 0.7, 1.4)
    elif kind == "anisostrain":
        phase = selected_phase(project, parts[1])
        axis = [int(v) for v in parts[2].split(",")]
        hap = phase.data["Histograms"][hist.name]
        current = float(hap["Mustrain"][1][0])
        phase.set_HAP_refinements({"Mustrain": {"type": "uniaxial", "refine": True, "direction": axis}}, [hist])
        hap["Mustrain"][1][0] = current
        hap["Mustrain"][1][1] = current
        add_bound(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 8000.0)
        add_bound(project, f"{phase.id}:{hist.id}:Mustrain;a", 0.0, 32000.0)
    elif kind == "fixstrain":
        phase = selected_phase(project, parts[1])
        value = float(parts[2])
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = value
        hap["Mustrain"][1][1] = value
        hap["Mustrain"][2] = [False, False, False]
    elif kind == "fixsize":
        phase = selected_phase(project, parts[1])
        value = float(parts[2])
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = value
        hap["Size"][1][1] = value
        hap["Size"][2] = [False, False, False]
    else:
        raise ValueError(f"unknown operation: {operation}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("operation")
    ap.add_argument("--repeats", type=int, default=2)
    ap.add_argument("--cycles", type=int, default=10)
    args = ap.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    project.set_Controls("cycles", args.cycles)
    apply_operation(project, args.operation)
    project.save()
    states = [snapshot(project, args.operation, 0)]
    for repeat in range(1, args.repeats + 1):
        project.refine(makeBack=False)
        states.append(snapshot(project, args.operation, repeat))
    project.save()
    args.output.with_suffix(".json").write_text(json.dumps(states, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
