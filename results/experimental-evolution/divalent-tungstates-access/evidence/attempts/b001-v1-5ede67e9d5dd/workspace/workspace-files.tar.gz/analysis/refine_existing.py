#!/usr/bin/env python3
"""Continue an existing GSAS-II refinement while logging each repeat."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def snapshot(project):
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        masses.append(mass)
        phases.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell": phase.get_cell(),
                "size": list(hap["Size"][1]),
                "mustrain": list(hap["Mustrain"][1]),
                "preferred_orientation": list(hap["Pref.Ori."][:4]),
            }
        )
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = mass / sum(masses)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    return {
        "Rwp_percent": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "max_shift_over_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "Nvars": len(cov.get("varyList", [])),
        "instrument": {k: float(inst[k][1]) for k in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."] if k in inst},
        "sample": {k: sample[k] for k in ["Shift", "SurfRoughA", "SurfRoughB", "Transparency"]},
        "phases": phases,
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--cycles", type=int, default=12)
    args = ap.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    project.set_Controls("cycles", args.cycles)
    project.save()
    states = [{"repeat": 0, **snapshot(project)}]
    for repeat in range(1, args.repeats + 1):
        project.refine(makeBack=False)
        states.append({"repeat": repeat, **snapshot(project)})
    project.save()
    args.output.with_suffix(".json").write_text(json.dumps(states, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
