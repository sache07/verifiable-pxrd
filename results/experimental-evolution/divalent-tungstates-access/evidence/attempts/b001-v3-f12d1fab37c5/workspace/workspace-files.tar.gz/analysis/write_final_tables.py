#!/usr/bin/env python3
"""Write fit.csv and result.json from a verified fresh replay of final.gpx."""

from pathlib import Path
import json
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


PHASE_META = {
    "MnWO4": {
        "name": "wolframite MnWO4",
        "formula": "MnWO4",
        "space_group": "P 2/c",
        "cif_path": "MnWO4.cif",
        "model_basis": "published reference, refined",
    },
    "WO3": {
        "name": "monoclinic WO3",
        "formula": "WO3",
        "space_group": "P 21/c",
        "cif_path": "WO3.cif",
        "model_basis": "published reference, refined",
    },
    "Mn2WO6": {
        "name": "orthorhombic Mn2WO6",
        "formula": "Mn2WO6",
        "space_group": "P 21 21 21",
        "cif_path": "Mn2WO6.cif",
        "model_basis": "analogue-derived topology with physically constrained coordinate refinement",
        "model_status": "provisional",
    },
    "MnO": {
        "name": "rocksalt MnO",
        "formula": "MnO",
        "space_group": "F m -3 m",
        "cif_path": "MnO.cif",
        "model_basis": "published reference, cell refined",
        "model_status": "trace",
    },
}


def fraction_values(project, hist):
    phases = project.phases()
    scales = np.array([p.data["Histograms"][hist.name]["Scale"][0] for p in phases], float)
    masses = np.array([p.data["General"]["Mass"] for p in phases], float)
    contributions = scales * masses
    fractions = contributions / contributions.sum()

    # Formal covariance errors from the final scale/background replay.
    errors = np.full(len(phases), np.nan)
    covariance = project.data.get("Covariance", {}).get("data", {})
    variables = covariance.get("varyList", [])
    matrix = np.asarray(covariance.get("covMatrix", []), float)
    names = [f"{p.id}:{hist.id}:Scale" for p in phases]
    if matrix.ndim == 2 and all(name in variables for name in names):
        indices = [variables.index(name) for name in names]
        scale_cov = matrix[np.ix_(indices, indices)]
        total = contributions.sum()
        jacobian = np.diag(masses) / total - np.outer(contributions, masses) / total**2
        errors = np.sqrt(np.maximum(0.0, np.diag(jacobian @ scale_cov @ jacobian.T)))
    return phases, fractions, errors


def main():
    project_path, replay_path, output_dir = map(Path, sys.argv[1:4])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(project_path))
    hist = project.histograms()[0]
    replay = np.load(replay_path)
    x = np.asarray(replay["x"], float)
    observed = np.asarray(replay["observed"], float)
    calculated = np.asarray(replay["predicted"], float)
    difference = observed - calculated
    np.savetxt(
        output_dir / "fit.csv",
        np.column_stack([x, observed, calculated, difference]),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt="%.10f",
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    full_rwp = 100.0 * np.sqrt(np.sum(weights * difference**2) / np.sum(weights * observed**2))
    rp = 100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed))
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    phases, fractions, errors = fraction_values(project, hist)
    phase_rows = []
    for phase, fraction, error in zip(phases, fractions, errors):
        row = dict(PHASE_META[phase.name])
        row["project_phase"] = phase.name
        row["weight_fraction"] = float(fraction)
        if np.isfinite(error):
            row["weight_fraction_esd"] = float(error)
        phase_rows.append(row)

    result = {
        "schema_version": 1,
        "refinement_histogram": hist.name,
        "fraction_basis": "normalized over modeled crystalline phases",
        "phases": phase_rows,
        "fit_statistics": {
            "rwp_percent_full_grid": float(full_rwp),
            "rwp_percent_gsas_fit_range": float(hist.get_wR()),
            "rp_percent_full_grid": float(rp),
            "goodness_of_fit": float(rvals.get("GOF", np.nan)),
            "chi_square_gsas_fit_range": float(rvals.get("chisq", np.nan)),
            "number_of_profile_points_full_grid": int(len(x)),
            "gsas_fit_range_two_theta_deg": [10.0, 100.0],
        },
        "measurement": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelengths_angstrom": [1.540598, 1.544426],
            "kalpha2_to_kalpha1_ratio": 0.5,
            "zero_shift_deg": float(hist.data["Instrument Parameters"][0]["Zero"][1]),
            "specimen_displacement_micrometre": float(hist.data["Sample Parameters"]["Shift"][0]),
        },
    }
    (output_dir / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print("RESULT", json.dumps({"Rwp_full": full_rwp, "Rp_full": rp,
                                 "fractions": dict(zip([p.name for p in phases], fractions.tolist()))}))


if __name__ == "__main__":
    main()
