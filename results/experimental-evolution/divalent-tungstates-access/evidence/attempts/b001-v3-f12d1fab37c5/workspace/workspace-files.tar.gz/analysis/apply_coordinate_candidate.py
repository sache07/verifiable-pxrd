#!/usr/bin/env python3
"""Apply an external asymmetric-coordinate candidate to an existing GSAS-II project."""

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def main():
    source, candidates, start, output = Path(sys.argv[1]), Path(sys.argv[2]), int(sys.argv[3]), Path(sys.argv[4])
    G2.SetPrintLevel("warn")
    rows = json.loads(candidates.read_text())
    row = next(item for item in rows if item["start"] == start)
    project = G2.G2Project(str(source))
    project.save(str(output))
    phase = project.phase("Mn2WO6")
    phase.set_refinements({"Atoms": {"all": " "}})
    coordinates = row["coordinates"]
    for atom in phase.data["Atoms"]:
        atom[3:6] = [float(v) for v in coordinates[atom[0]]]
    project.set_Controls("cycles", 20)
    project.refine()
    project.refine()
    project.save(str(output))
    phase.export_CIF(str(output.with_suffix(".cif")))
    hist = project.histograms()[0]
    hap = phase.data["Histograms"][hist.name]
    print("start", start, "Rwp", hist.get_wR(), "scale", hap["Scale"][0], "cell", phase.get_cell())


if __name__ == "__main__":
    main()
