#!/usr/bin/env python3
"""Rank chemically plausible analogue prototypes against the positive residual profile."""

from __future__ import annotations

import gzip
import json
import math
import sys
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Element, Structure


ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06")
INDEX = ROOT / "index.json.gz"
CIFS = ROOT / "cif"
WAVELENGTH = 1.540598


def cif_path(cid: str) -> Path:
    return CIFS / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


def analogue_pattern(path: Path) -> tuple[Structure, np.ndarray, np.ndarray]:
    s = Structure.from_file(path)
    mapping = {}
    for site in s:
        for sp in site.species:
            el = sp.element if hasattr(sp, "element") else sp
            if str(el) not in ("O", "W"):
                mapping[sp] = Element("Mn")
    if mapping:
        s.replace_species(mapping)
    pat = XRDCalculator(wavelength=WAVELENGTH).get_pattern(s, two_theta_range=(8, 105), scaled=False)
    return s, np.asarray(pat.x), np.asarray(pat.y)


def shifted_positions(tt: np.ndarray, scale: float) -> np.ndarray:
    theta = np.radians(tt / 2)
    arg = np.sin(theta) / scale
    ok = np.abs(arg) < 1
    pos = np.full(tt.shape, np.nan)
    true_tt = np.degrees(2 * np.arcsin(arg[ok]))
    # Initial physical calibration from the stable pre-profile wolframite fit.
    zero = -0.05591
    shift_mm = -0.74181
    pos[ok] = true_tt + zero - 2 * shift_mm / 200.0 * np.cos(np.radians(true_tt / 2)) * 180 / np.pi
    return pos


def profile(x: np.ndarray, pos: np.ndarray, inten: np.ndarray, fwhm0: float, strain: float) -> np.ndarray:
    out = np.zeros_like(x)
    step = float(np.median(np.diff(x)))
    for p, area in zip(pos, inten):
        if not np.isfinite(p) or p < x[0] - 1 or p > x[-1] + 1 or area <= 0:
            continue
        fwhm = math.sqrt(fwhm0 * fwhm0 + (strain * math.tan(math.radians(p / 2))) ** 2)
        sigma = fwhm / 2.35482
        half = max(3, int(math.ceil(4 * sigma / step)))
        i = int(round((p - x[0]) / step))
        lo, hi = max(0, i - half), min(len(x), i + half + 1)
        if lo < hi:
            q = (x[lo:hi] - p) / sigma
            out[lo:hi] += area * np.exp(-0.5 * q * q) / sigma
    return out


def target_ratio(formula: str, key: str) -> tuple[float, float] | None:
    els = key.split("-")
    if "W" not in els or "O" not in els or len(els) != 3:
        return None
    a = next((e for e in els if e not in ("W", "O")), None)
    if not a:
        return None
    try:
        rc = Composition(formula).reduced_composition
        amt = {str(e): float(v) for e, v in rc.items()}
        if set(amt) != {a, "W", "O"}:
            return None
        return amt[a] / amt["W"], amt["O"] / amt["W"]
    except Exception:
        return None


def main() -> None:
    residual_path = sys.argv[1] if len(sys.argv) > 1 else "analysis/mnwo4_residual.csv"
    dat = np.genfromtxt(residual_path, delimiter=",", names=True)
    # Every third point preserves even the narrowest observed line while making the
    # broad prototype scan inexpensive.
    x = dat["two_theta"][::3]
    d = dat["difference"][::3]
    w = dat["weight"][::3]
    # Avoid rewarding candidates for the smooth positive offset left by an imperfect background.
    dfit = d - np.percentile(d, 20)
    with gzip.open(INDEX, "rt") as fp:
        index = json.load(fp)

    desired = [(2.0, 6.0), (3.0, 6.0), (2 / 3, 4.0), (1.5, 4.5)]
    candidates = []
    for key, rows in index.items():
        for formula, cid, sg, residual in rows:
            ratio = target_ratio(formula, key)
            if ratio and any(abs(ratio[0] - a) < 0.015 and abs(ratio[1] - o) < 0.03 for a, o in desired):
                candidates.append(("analogue", key, formula, cid, sg, ratio))
            elif key == "Mn-O" and formula in {"MnO", "Mn2O3", "Mn3O4", "MnO2"}:
                candidates.append(("direct", key, formula, cid, sg, None))
            elif key == "O-W" and formula in {"WO3", "W3O8", "W18O49", "W10O29", "W17O47"}:
                candidates.append(("direct", key, formula, cid, sg, None))

    seen = set()
    results = []
    for kind, key, formula, cid, sg, ratio in candidates:
        if cid in seen:
            continue
        seen.add(cid)
        path = cif_path(cid)
        try:
            if kind == "analogue":
                s, tt, inten = analogue_pattern(path)
            else:
                s = Structure.from_file(path)
                pat = XRDCalculator(wavelength=WAVELENGTH).get_pattern(s, two_theta_range=(8, 105), scaled=False)
                tt, inten = np.asarray(pat.x), np.asarray(pat.y)
        except Exception as exc:
            print("SKIP", cid, type(exc).__name__, str(exc)[:100])
            continue
        best = None
        for scale in np.linspace(0.78, 1.22, 89):
            pos = shifted_positions(tt, scale)
            for fwhm0 in (0.18, 0.32, 0.48):
                for strain in (0.0,):
                    p = profile(x, pos, inten, fwhm0, strain)
                    den = float(np.dot(w * p, p))
                    if den <= 0:
                        continue
                    amp = max(0.0, float(np.dot(w * p, dfit)) / den)
                    gain = 2 * amp * float(np.dot(w * p, dfit)) - amp * amp * den
                    trial = (gain, scale, fwhm0, strain, amp)
                    if best is None or trial > best:
                        best = trial
        if best:
            results.append((best[0], cid, formula, sg, kind, key, ratio, s.composition.reduced_formula,
                            s.get_space_group_info()[0], *best[1:]))

    results.sort(reverse=True)
    print("gain cid source_formula source_sg kind key ratio substituted_formula substituted_sg scale fwhm strain amp")
    for row in results[:100]:
        print(" ".join(str(v) for v in row))


if __name__ == "__main__":
    main()
