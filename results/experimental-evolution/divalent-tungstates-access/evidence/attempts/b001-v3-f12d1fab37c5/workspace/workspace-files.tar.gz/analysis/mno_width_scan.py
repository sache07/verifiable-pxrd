#!/usr/bin/env python3
"""Replay the rocksalt MnO trial at fixed, physically allowed crystallite sizes."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


SOURCE = Path("analysis/four_mno.gpx")
SIZES = (0.04, 0.06, 0.08, 0.12, 0.20, 0.50, 1.00, 3.00)
STARTS = {
    "MnWO4": ([4.7936753, 5.7090293, 4.9760390, 90, 91.1153244, 90], 0.0825, 4352.0),
    "WO3": ([7.6887556, 7.5363738, 10.5303196, 90, 136.1213957, 90], 0.1230, 8000.0),
    "Mn2WO6": ([5.0457784, 8.6436529, 9.3990748, 90, 90, 90], 0.0804, 7685.0),
    "MnO": ([4.4002090, 4.4002090, 4.4002090, 90, 90, 90], 1.0, 300.0),
}


def set_cell(phase, values):
    phase.data["General"]["Cell"][1:7] = list(values)
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(values))


def run(size):
    output = Path(f"analysis/mno_fixed_{size:.2f}.gpx")
    project = G2.G2Project(str(SOURCE))
    project.save(str(output))
    hist = project.histograms()[0]
    hist.data["Instrument Parameters"][0]["Zero"] = [0.0, -0.05591, False]
    hist.SampleParameters["Shift"] = [-741.81, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.set_refinements({"Background": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        cell, default_size, strain = STARTS[phase.name]
        set_cell(phase, cell)
        phase.set_refinements({"Atoms": {"all": " "}, "Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [5.0 if phase.name == "MnO" else hap["Scale"][0], True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size if phase.name == "MnO" else default_size
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        hap["Mustrain"][2] = [False, False, False]
    project.set_Controls("cycles", 20)
    project.refine()
    project.save(str(output))
    mno = project.phase("MnO")
    hap = mno.data["Histograms"][hist.name]
    print(f"size={size:.2f} Rwp={hist.get_wR():.8f} scale={hap['Scale'][0]:.9g} a={mno.get_cell()['length_a']:.7f}")


def main():
    G2.SetPrintLevel("warn")
    for size in SIZES:
        run(size)


if __name__ == "__main__":
    main()
