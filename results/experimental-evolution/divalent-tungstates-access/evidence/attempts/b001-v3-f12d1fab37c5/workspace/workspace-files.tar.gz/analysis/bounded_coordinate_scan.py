#!/usr/bin/env python3
"""Refine selected Mn2WO6 coordinates within absolute Cartesian-scale bounds."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def main():
    if len(sys.argv) < 5:
        raise SystemExit("usage: bounded_coordinate_scan.py INPUT.gpx STEM ATOM[,ATOM...] RADIUS_A[,RADIUS_A...]")
    source = Path(sys.argv[1])
    stem = Path(sys.argv[2])
    labels = sys.argv[3].split(",")
    radii = [float(v) for v in sys.argv[4].split(",")]
    G2.SetPrintLevel("warn")

    for radius in radii:
        output = stem.with_name(f"{stem.name}_{radius:.3f}A.gpx")
        project = G2.G2Project(str(source))
        project.save(str(output))
        controls = project.data["Controls"]["data"]
        controls["parmFrozen"] = {"FrozenList": []}
        controls["parmMinDict"] = {}
        controls["parmMaxDict"] = {}
        phase = project.phase("Mn2WO6")
        phase.set_refinements({"Atoms": {"all": " "}})
        phase.set_refinements({"Atoms": {label: "X" for label in labels}})
        cell = phase.get_cell()
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        atoms = phase.data["Atoms"]
        atom_index = {atom[0]: i for i, atom in enumerate(atoms)}
        for label in labels:
            i = atom_index[label]
            for axis, coordinate in zip("xyz", atoms[i][3:6]):
                delta = radius / lengths["xyz".index(axis)]
                variable = f"{phase.id}::dA{axis}:{i}"
                project.set_Controls("parmMin", float(coordinate) - delta, variable)
                project.set_Controls("parmMax", float(coordinate) + delta, variable)
        project.set_Controls("cycles", 18)
        project.refine()
        # GSAS-II applies a parameter limit at the end of a refinement and
        # freezes that variable. Recalculate/refine the remaining variables so
        # the stored profile and R factors correspond to the bounded model.
        project.refine()
        project.refine()
        project.save(str(output))
        phase.export_CIF(str(output.with_suffix(".cif")))
        hist = project.histograms()[0]
        frozen = [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])]
        coords = {atom.label: tuple(round(float(v), 8) for v in atom.coordinates)
                  for atom in phase.atoms() if atom.label in labels}
        print(f"radius_A={radius:.3f} Rwp={hist.get_wR():.8f} frozen={frozen} coords={coords}")


if __name__ == "__main__":
    main()
