#!/usr/bin/env python3
"""Assemble the accepted physical branches and perform a final joint replay."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


UISOS = {
    "MnWO4": 0.00586082,
    "WO3": 0.00417040,
    # The free optimum was 0.0236 A^2; LAB.md limits the generated value to 0.020.
    "Mn2WO6": 0.02000000,
    # The trace phase value is inseparable from scale, so retain a neutral value.
    "MnO": 0.01000000,
}


def snapshot(project, label):
    hist = project.histograms()[0]
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append({
            "name": phase.name,
            "scale": float(hap["Scale"][0]),
            "cell": phase.get_cell(),
            "uiso": float(phase.data["Atoms"][0][10]),
            "md": [float(hap["Pref.Ori."][1]), list(hap["Pref.Ori."][3])],
            "strain": [hap["Mustrain"][0], list(map(float, hap["Mustrain"][1][:2])),
                       list(hap["Mustrain"][3])],
        })
    print("STATE", json.dumps({
        "label": label,
        "Rwp": float(hist.get_wR()),
        "phases": phases,
    }))


def replay(project, count):
    for _ in range(count):
        project.refine()


def main():
    source, output = Path(sys.argv[1]), Path(sys.argv[2])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(source))
    project.save(str(output))
    hist = project.histograms()[0]
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["max cyc"] = 20
    controls["deriv type"] = "analytic Hessian"
    project.data["Constraints"]["data"]["Phase"] = []

    # Freeze all atom variables and impose the accepted common Uiso values.
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})
        for atom in phase.data["Atoms"]:
            atom[9] = "I"
            atom[10] = UISOS[phase.name]
        phase.data["General"]["Cell"][0] = False
        project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Scale")

    mn2 = project.phase("Mn2WO6")
    hap = mn2.data["Histograms"][hist.name]
    project.set_Controls("parmMin", 0.7, f"{mn2.id}:0:MD")
    project.set_Controls("parmMax", 1.4, f"{mn2.id}:0:MD")
    equatorial = float(hap["Mustrain"][1][0])
    project.set_Controls("parmMin", 0.25 * equatorial, f"{mn2.id}:0:Mustrain;a")
    project.set_Controls("parmMax", 4.0 * equatorial, f"{mn2.id}:0:Mustrain;a")

    # First recalculate after the fixed displacement-parameter changes.
    replay(project, 2)
    snapshot(project, "uiso_replay")

    # The preferred-orientation and uniaxial-strain effects overlap weakly;
    # allow their accepted parameters to settle together once.
    hap["Pref.Ori."][2] = True
    hap["Mustrain"][2] = [False, True, False]
    replay(project, 3)
    hap["Pref.Ori."][2] = False
    hap["Mustrain"][2] = [False, False, False]
    snapshot(project, "texture_strain_joint")

    # Fresh full-grid cell replay, then scales/background only.
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    replay(project, 2)
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
    replay(project, 2)
    project.save(str(output))
    snapshot(project, "final")


if __name__ == "__main__":
    main()
