#!/usr/bin/env python3
"""Build and stage a small GSAS-II Rietveld trial from the supplied pattern."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def log_state(project: G2.G2Project, label: str) -> None:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    out = {
        "stage": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "zero_deg": inst.get("Zero", [None, None])[1],
        "U": inst.get("U", [None, None])[1],
        "V": inst.get("V", [None, None])[1],
        "W": inst.get("W", [None, None])[1],
        "X": inst.get("X", [None, None])[1],
        "SH_L": inst.get("SH/L", [None, None])[1],
        "polarization": inst.get("Polariz.", [None, None])[1],
        "shift_um": sample.get("Shift", [None])[0],
        "surface_roughness": [sample.get("SurfRoughA", [None])[0], sample.get("SurfRoughB", [None])[0]],
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "mass": phase.data["General"]["Mass"],
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "pref_ori": hap["Pref.Ori."],
            }
        )
    print("STATE " + json.dumps(out, default=float))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("output", type=Path)
    ap.add_argument("cifs", nargs="+", help="phase_name=path")
    ap.add_argument("--cycles", type=int, default=8)
    ap.add_argument("--no-profile", action="store_true")
    ap.add_argument("--fixed-instrument", action="store_true")
    ap.add_argument("--fixed-calibration", action="store_true")
    args = ap.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    inst_path = args.output.with_suffix(".instprm")
    inst_path.write_text(
        "#GSAS-II instrument parameter file; initial Cu K-alpha laboratory profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.33;Polariz.:0.80;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(args.output))
    phases = []
    for spec in args.cifs:
        name, path = spec.split("=", 1)
        phases.append(project.add_phase(str(Path(path).resolve()), phasename=name, fmthint="CIF"))
    hist = project.add_powder_histogram(
        str(Path("inputs/pattern.csv").resolve()), str(inst_path.resolve()), phases=phases,
        fmthint="comma/tab/semicolon separated"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    if args.fixed_calibration:
        hist.data["Instrument Parameters"][0]["Zero"][1] = -0.05591
        hist.SampleParameters["Shift"][0] = -741.81
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "no. coeffs": 10,
                         "coeffs": [1500.0] + [0.0] * 9, "refine": True}}
    )
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][0] = 1.0
        phase.set_HAP_refinements({"Scale": True})

    project.set_Controls("cycles", args.cycles)

    # Locate the pattern and scale/background first with a single common offset.
    if not args.fixed_calibration:
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    log_state(project, "scale_background_zero")

    # Adapt each candidate lattice to the observed reflection positions.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.refine()
    log_state(project, "cells")

    # Split constant and angle-dependent displacement contributions.
    if not args.fixed_calibration:
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        project.refine()
        log_state(project, "shift")

    # Instrumental broadening, then phase broadening.
    if not args.fixed_instrument:
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
        project.refine()
        log_state(project, "instrument_profile")

    if not args.no_profile:
        for phase in phases:
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 0.3, "refine": True},
                 "Mustrain": {"type": "isotropic", "refine": True}}
            )
        project.refine()
        log_state(project, "phase_profile")

    project.save(str(args.output))


if __name__ == "__main__":
    main()
