#!/usr/bin/env python3
"""Refine the transferred Mn2WO6 model with oxide bond restraints and coordinate bounds."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def main():
    if len(sys.argv) < 5:
        raise SystemExit("usage: restrained_coordinate_scan.py INPUT.gpx STEM ATOM[,ATOM...] WEIGHT[,WEIGHT...]")
    source = Path(sys.argv[1])
    stem = Path(sys.argv[2])
    labels = sys.argv[3].split(",")
    weights = [float(v) for v in sys.argv[4].split(",")]
    G2.SetPrintLevel("warn")

    for weight in weights:
        output = stem.with_name(f"{stem.name}_w{weight:g}.gpx")
        project = G2.G2Project(str(source))
        project.save(str(output))
        controls = project.data["Controls"]["data"]
        controls["parmFrozen"] = {"FrozenList": []}
        controls["parmMinDict"] = {}
        controls["parmMaxDict"] = {}
        controls["shift factor"] = 0.15
        # Coordinate and lattice shifts are strongly correlated in this weak
        # phase. Keep the previously adapted cells fixed during this stage.
        hist = project.histograms()[0]
        hist.data["Background"][0][1] = False
        for item in project.phases():
            item.data["General"]["Cell"][0] = False
            item.data["Histograms"][hist.name]["Scale"][1] = item.name == "Mn2WO6"
        phase = project.phase("Mn2WO6")
        project.data["Restraints"]["data"][phase.name] = {
            "Bond": {"wtFactor": weight, "Range": 1.1, "Bonds": [], "Use": True}
        }
        oxygen = [a.label for a in phase.atoms() if a.element == "O"]
        phase.addDistRestraint(["W1"], oxygen, 1.85, factor=1.15, ESD=0.04)
        phase.addDistRestraint(["Mn1", "Mn2"], oxygen, 2.20, factor=1.11, ESD=0.07)

        phase.set_refinements({"Atoms": {"all": " "}})
        phase.set_refinements({"Atoms": {label: "X" for label in labels}})
        cell = phase.get_cell()
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        atoms = phase.data["Atoms"]
        atom_index = {atom[0]: i for i, atom in enumerate(atoms)}
        for label in labels:
            i = atom_index[label]
            radius = 0.16 if atoms[i][1] in {"W", "Mn"} else 0.20
            for j, (axis, coordinate) in enumerate(zip("xyz", atoms[i][3:6])):
                variable = f"{phase.id}::dA{axis}:{i}"
                project.set_Controls("parmMin", float(coordinate) - radius / lengths[j], variable)
                project.set_Controls("parmMax", float(coordinate) + radius / lengths[j], variable)

        project.set_Controls("cycles", 40)
        project.refine()
        project.refine()
        # Freeze the accepted coordinates and replay scales/background.
        phase.set_refinements({"Atoms": {"all": " "}})
        for item in project.phases():
            item.data["Histograms"][hist.name]["Scale"][1] = True
        hist.data["Background"][0][1] = True
        controls["shift factor"] = 1.0
        project.set_Controls("cycles", 20)
        project.refine()
        project.save(str(output))
        phase.export_CIF(str(output.with_suffix(".cif")))
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        frozen = [str(v) for v in controls.get("parmFrozen", {}).get("FrozenList", [])]
        print(f"weight={weight:g} Rwp={hist.get_wR():.8f} restraint_sum={rvals.get('RestraintSum')} frozen={len(frozen)}")
        for atom in phase.atoms():
            if atom.label in labels:
                print(atom.label, tuple(round(float(v), 8) for v in atom.coordinates))


if __name__ == "__main__":
    main()
