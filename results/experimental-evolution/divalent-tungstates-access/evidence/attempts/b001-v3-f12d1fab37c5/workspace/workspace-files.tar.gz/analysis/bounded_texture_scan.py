#!/usr/bin/env python3
"""Test all generator-allowed March-Dollase axes with bounded ratios."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def main():
    source, stem, phase_name = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
    G2.SetPrintLevel("warn")
    for axis in AXES:
        tag = "".join(str(v) for v in axis)
        output = stem.with_name(f"{stem.name}_{tag}.gpx")
        project = G2.G2Project(str(source))
        project.save(str(output))
        controls = project.data["Controls"]["data"]
        controls["parmFrozen"] = {"FrozenList": []}
        controls["parmMinDict"] = {}
        controls["parmMaxDict"] = {}
        phase = project.phase(phase_name)
        hist = project.histograms()[0]
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        project.set_Controls("parmMin", 0.7, f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 1.4, f"{phase.id}:0:MD")
        project.set_Controls("cycles", 20)
        project.refine()
        project.refine()
        project.refine()
        hap["Pref.Ori."][2] = False
        project.save(str(output))
        print("axis", axis, "Rwp", hist.get_wR(), "ratio", hap["Pref.Ori."][1],
              "scale", hap["Scale"][0], "frozen", [str(v) for v in controls.get("parmFrozen", {}).get("FrozenList", [])])


if __name__ == "__main__":
    main()
