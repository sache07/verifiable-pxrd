#!/usr/bin/env python3
"""Refine one common isotropic displacement parameter for a selected phase."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def main():
    source, output, phase_name = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(source))
    project.save(str(output))
    project.data["Constraints"]["data"]["Phase"] = []
    phase = project.phase(phase_name)
    phase.set_refinements({"Atoms": {"all": " "}})
    labels = []
    variables = []
    for i, atom in enumerate(phase.data["Atoms"]):
        atom[9] = "I"
        atom[10] = 0.010
        labels.append(atom[0])
        variables.append(f"{phase.id}::AUiso:{i}")
    phase.set_refinements({"Atoms": {label: "U" for label in labels}})
    project.save(str(output))
    if len(variables) > 1:
        project.add_EquivConstr(variables, reloadIdx=True)
    project.set_Controls("cycles", 20)
    project.refine()
    project.refine()
    project.refine()
    phase.set_refinements({"Atoms": {"all": " "}})
    project.save(str(output))
    phase.export_CIF(str(output.with_suffix(".cif")))
    hist = project.histograms()[0]
    print("phase", phase_name, "Rwp", hist.get_wR(), "Uiso", [float(atom[10]) for atom in phase.data["Atoms"]])


if __name__ == "__main__":
    main()
