#!/usr/bin/env python3
"""Staged, bounded refinement of profile, calibration and specimen parameters."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


def state(project, label):
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.SampleParameters
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append({
            "name": phase.name,
            "scale": hap["Scale"][0],
            "size": hap["Size"][1][:2],
            "strain": hap["Mustrain"][1][:2],
            "cell": phase.get_cell(),
        })
    print("STATE", json.dumps({
        "stage": label, "Rwp": hist.get_wR(),
        "instrument": {k: inst[k][1] for k in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]},
        "sample": {k: sample[k][0] for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "phases": phases,
    }, default=float))


def replay(project, times=2):
    for _ in range(times):
        project.refine()


def main():
    source, output = Path(sys.argv[1]), Path(sys.argv[2])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(source))
    project.save(str(output))
    hist = project.histograms()[0]
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    project.set_Controls("cycles", 18)
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})
        phase.data["General"]["Cell"][0] = False

    # Frozen laboratory ranges from LAB.md.
    limits = {
        ":0:U": (0.0, 40.0), ":0:W": (2.0, 40.0), ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10), ":0:Polariz.": (0.5, 1.0),
        ":0:Zero": (-0.25, 0.25), ":0:Shift": (-800.0, 800.0),
    }
    for variable, (low, high) in limits.items():
        project.set_Controls("parmMin", low, variable)
        project.set_Controls("parmMax", high, variable)
    for phase in project.phases():
        project.set_Controls("parmMin", 0.04, f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 1.50, f"{phase.id}:0:Size;i")
        project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, f"{phase.id}:0:Mustrain;i")

    # Shared instrumental broadening with phase widths held fixed.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    replay(project, 3)
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    state(project, "instrument")

    # Adapt one phase width at a time; do not allow a weak phase to absorb the baseline.
    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        replay(project, 2)
        phase.clear_HAP_refinements({"Size": True})
        state(project, f"{phase.name}_size")
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        replay(project, 2)
        phase.clear_HAP_refinements({"Mustrain": True})
        state(project, f"{phase.name}_strain")

    # Revisit shared profile after phase separation.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    replay(project, 2)
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    state(project, "profile_replay")

    # Peak positions: separate zero and displacement before a joint replay.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    replay(project, 2)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    state(project, "zero")
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    replay(project, 2)
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    state(project, "shift")

    # Angle-dependent intensity correction.
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    replay(project, 2)
    hist.clear_refinements({"Instrument Parameters": ["Polariz."]})
    state(project, "polarization")

    # Final cell/scale/background replay with all profile parameters fixed.
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    replay(project, 3)
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
    project.save(str(output))
    state(project, "final")


if __name__ == "__main__":
    main()
