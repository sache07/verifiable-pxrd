#!/usr/bin/env python3
"""Apply fixed physical phase profiles and replay cells/scales/background."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


PROFILES = {
    "MnWO4": (0.0825, 4352.0),
    "WO3": (0.1230, 8000.0),
    "Mn2WO6": (0.0804, 7685.0),
    "MnO": (0.20, 300.0),
}


def main():
    source, output = Path(sys.argv[1]), Path(sys.argv[2])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(source))
    project.save(str(output))
    hist = project.histograms()[0]
    hist.data["Instrument Parameters"][0]["Zero"] = [0.0, -0.05591, False]
    hist.SampleParameters["Shift"] = [-741.81, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.set_refinements({"Background": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}, "Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        size, strain = PROFILES[phase.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][1][1] = size
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        hap["Mustrain"][1][1] = strain
        hap["Mustrain"][2] = [False, False, False]
    project.set_Controls("cycles", 20)
    project.refine()
    project.refine()
    project.save(str(output))
    print("Rwp", hist.get_wR())
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, phase.get_cell(), "scale", hap["Scale"][0])


if __name__ == "__main__":
    main()
