#!/usr/bin/env python3
"""Fit P212121 Mn2WO6 structure factors to its isolated residual with geometry penalties."""

from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
from pymatgen.analysis.diffraction.xrd import ATOMIC_SCATTERING_PARAMS
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.groups import SpaceGroup
from scipy.optimize import least_squares


ROOT = Path("analysis")
REFLECTIONS = ROOT / "mn2_reflections.npz"
TARGET = ROOT / "mn2_component.npz"
OUT_STEM = ROOT / "Mn2WO6_optimized"
RNG = np.random.default_rng(240613)


def scattering_factor(element: str, s2: np.ndarray) -> np.ndarray:
    from pymatgen.core import Element

    z = Element(element).Z
    coeff = np.asarray(ATOMIC_SCATTERING_PARAMS[element], float)
    return z - 41.78214 * s2 * np.sum(
        coeff[None, :, 0] * np.exp(-coeff[None, :, 1] * s2[:, None]), axis=1
    )


def profile_matrix(x: np.ndarray, positions: np.ndarray, size_um=0.0804, strain_ppm=7685.0) -> np.ndarray:
    """Unit-area Gaussian K-alpha1/K-alpha2 profiles for a fast intensity fit."""
    theta = np.deg2rad(positions / 2)
    size = 0.9 * 1.540598 / (size_um * 1e4 * np.cos(theta)) * 180 / np.pi
    strain = 4 * strain_ppm * 1e-6 * np.tan(theta) * 180 / np.pi
    fwhm = np.sqrt(0.065**2 + size**2 + strain**2)
    sigma = fwhm / 2.354820045
    # Bragg-shift K-alpha2 from each K-alpha1 reflection.
    theta2 = np.arcsin(np.clip(1.544426 / 1.540598 * np.sin(theta), -0.999999, 0.999999))
    positions2 = np.rad2deg(2 * theta2)
    # The same common zero/specimen displacement is already included in positions;
    # adding the wavelength-only separation is sufficient here.
    positions2 += positions - np.rad2deg(2 * theta)
    q1 = (x[:, None] - positions[None, :]) / sigma[None, :]
    q2 = (x[:, None] - positions2[None, :]) / sigma[None, :]
    norm = 1 / (np.sqrt(2 * np.pi) * sigma)
    return norm[None, :] * (np.exp(-0.5 * q1 * q1) + 0.5 * np.exp(-0.5 * q2 * q2))


def expanded_coordinates(asym: np.ndarray, operations) -> np.ndarray:
    return np.vstack([[op.operate(coord) % 1 for op in operations] for coord in asym])


def periodic_distances(lattice: Lattice, a: np.ndarray, b: np.ndarray) -> np.ndarray:
    # pymatgen handles the minimum-image metric for a vectorized pair list.
    return lattice.get_all_distances(a, b)


def geometry(asym: np.ndarray, elements: np.ndarray, operations, lattice: Lattice) -> dict:
    frac = expanded_coordinates(asym, operations)
    expanded_elements = np.repeat(elements, len(operations))
    oxygen = frac[expanded_elements == "O"]
    result: dict[str, list] = {"W_O": [], "Mn_O": []}
    for element in ("W", "Mn"):
        cations = frac[expanded_elements == element]
        distances = periodic_distances(lattice, cations, oxygen)
        nearest = np.sort(distances, axis=1)[:, :6]
        result[f"{element}_O"] = nearest.tolist()
    oo = periodic_distances(lattice, oxygen, oxygen)
    oo[oo < 1e-7] = np.inf
    result["O_O_min"] = float(np.min(oo))
    return result


def main() -> None:
    reflection_path = Path(sys.argv[1]) if len(sys.argv) > 1 else REFLECTIONS
    target_path = Path(sys.argv[2]) if len(sys.argv) > 2 else TARGET
    out_stem = Path(sys.argv[3]) if len(sys.argv) > 3 else OUT_STEM
    fit_all = len(sys.argv) > 4 and sys.argv[4].lower() == "all"
    ref = np.load(reflection_path)
    dat = np.load(target_path)
    hkl = np.rint(ref["hkl"]).astype(int)
    mult = ref["mult"].astype(float)
    d = ref["d"].astype(float)
    pos = ref["pos"].astype(float)
    corr = ref["corr"].astype(float)
    parent = ref["coords"].astype(float)
    elements = ref["elements"].astype(str)
    labels = ref["labels"].astype(str)
    lattice = Lattice.from_parameters(*ref["cell"].astype(float))
    operations = SpaceGroup.from_int_number(19).symmetry_ops

    x_all = dat["x"].astype(float)
    y_all = dat["y"].astype(float)
    target_all = y_all - dat["off"].astype(float)
    use_x = (x_all >= 15) & (x_all <= 80)
    keep_r = (pos >= 14.5) & (pos <= 80.5)
    # Every second point still oversamples the narrowest modeled line and keeps
    # the finite-difference multi-start search tractable.
    selected_points = np.flatnonzero(use_x)[::2]
    x = x_all[selected_points]
    target = target_all[selected_points]
    weights = 1 / np.maximum(y_all[selected_points], 1)
    hkl, mult, d, pos, corr = (v[keep_r] for v in (hkl, mult, d, pos, corr))
    size_um = float(ref["size_um"]) if "size_um" in ref.files else 0.0804
    strain_ppm = float(ref["strain_ppm"]) if "strain_ppm" in ref.files else 7685.0
    kernels = profile_matrix(x, pos, size_um=size_um, strain_ppm=strain_ppm)
    s2 = (1 / (2 * d)) ** 2
    atomic_f = {el: scattering_factor(el, s2) for el in set(elements)}
    expanded_elements = np.repeat(elements, len(operations))

    # Fit W and O; the two Mn sublattices remain at the analogue start for this
    # well-resolved/heavy-first stage.
    selected = np.ones(len(elements), dtype=bool) if fit_all else np.array([el in {"W", "O"} for el in elements])
    selected_indices = np.flatnonzero(selected)
    coordinate_bound = 0.040 if fit_all else 0.055
    lower = (parent[selected] - coordinate_bound).ravel()
    upper = (parent[selected] + coordinate_bound).ravel()

    def line_intensities(asym: np.ndarray) -> np.ndarray:
        frac = expanded_coordinates(asym, operations)
        phase = np.exp(2j * np.pi * (frac @ hkl.T))
        f = np.zeros(len(hkl), dtype=complex)
        for el in set(elements):
            f += atomic_f[el] * np.sum(phase[expanded_elements == el], axis=0)
        return mult * corr * (f.real * f.real + f.imag * f.imag)

    def model_and_scale(asym: np.ndarray):
        profile = kernels @ line_intensities(asym)
        denom = float(np.dot(weights * profile, profile))
        scale = max(0.0, float(np.dot(weights * profile, target)) / denom) if denom else 0.0
        return profile * scale, scale

    def residual(vector: np.ndarray) -> np.ndarray:
        asym = parent.copy()
        asym[selected] = vector.reshape((-1, 3))
        model, _ = model_and_scale(asym)
        data_residual = np.sqrt(weights) * (target - model)
        geom = geometry(asym, elements, operations, lattice)
        wo = np.asarray(geom["W_O"]).ravel()
        mno = np.asarray(geom["Mn_O"]).ravel()
        penalties = []
        # Soft interval restraints: zero inside chemically ordinary oxide ranges.
        penalties.extend(35 * np.maximum(1.68 - wo, 0) / 0.02)
        penalties.extend(35 * np.maximum(wo - 2.12, 0) / 0.02)
        penalties.extend(25 * np.maximum(1.90 - mno, 0) / 0.03)
        penalties.extend(25 * np.maximum(mno - 2.55, 0) / 0.04)
        penalties.append(35 * max(2.15 - geom["O_O_min"], 0) / 0.03)
        # A weak parent regularizer prevents underdetermined oxygen excursions.
        displacement = ((asym[selected] - parent[selected]) @ lattice.matrix)
        penalties.extend((2.0 * displacement.ravel() / 0.20).tolist())
        return np.concatenate([data_residual, np.asarray(penalties, float)])

    starts = [parent[selected].ravel()]
    for _ in range(3):
        starts.append(np.clip(parent[selected].ravel() + RNG.normal(0, 0.012, lower.size), lower, upper))

    records = []
    for i, start in enumerate(starts):
        fit = least_squares(
            residual, start, bounds=(lower, upper), method="trf", x_scale="jac",
            max_nfev=300, ftol=2e-8, xtol=2e-8, gtol=2e-7, verbose=0,
        )
        asym = parent.copy()
        asym[selected] = fit.x.reshape((-1, 3))
        model, scale = model_and_scale(asym)
        chi = float(np.dot(weights, (target - model) ** 2))
        geom = geometry(asym, elements, operations, lattice)
        record = {
            "start": i,
            "cost": float(fit.cost),
            "data_chi_square": chi,
            "scale": scale,
            "nfev": fit.nfev,
            "optimality": float(fit.optimality),
            "success": bool(fit.success),
            "geometry": geom,
            "max_asym_fractional_shift": float(np.max(np.abs(asym - parent))),
            "coordinates": {label: coord.tolist() for label, coord in zip(labels, asym)},
        }
        records.append(record)
        expanded = expanded_coordinates(asym, operations)
        species = np.repeat(elements, len(operations))
        structure = Structure(lattice, species, expanded, coords_are_cartesian=False)
        CifWriter(structure, symprec=1e-3, significant_figures=10).write_file(f"{out_stem}_{i}.cif")
        print(json.dumps({k: record[k] for k in ("start", "cost", "data_chi_square", "scale", "nfev", "success", "max_asym_fractional_shift")}, sort_keys=True))
        print("geometry", "W-O", np.round(np.asarray(geom["W_O"])[0], 4).tolist(),
              "Mn-O(min,max)", round(np.min(geom["Mn_O"]), 4), round(np.max(geom["Mn_O"]), 4),
              "O-O", round(geom["O_O_min"], 4))

    records.sort(key=lambda row: row["cost"])
    (out_stem.with_suffix(".json")).write_text(json.dumps(records, indent=2) + "\n")
    best = records[0]["start"]
    Path(f"{out_stem}_best.txt").write_text(f"{out_stem}_{best}.cif\n")


if __name__ == "__main__":
    main()
