#!/usr/bin/env python3
"""Bounded Bragg-Brentano surface-roughness branch from an accepted project."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def main():
    source, output = Path(sys.argv[1]), Path(sys.argv[2])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(source))
    project.save(str(output))
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    project.set_Controls("cycles", 20)
    hist = project.histograms()[0]
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.30, True]
    sample["SurfRoughB"] = [0.10, True]
    project.set_Controls("parmMin", 0.05, ":0:SurfRoughA")
    project.set_Controls("parmMax", 0.60, ":0:SurfRoughA")
    project.set_Controls("parmMin", 0.02, ":0:SurfRoughB")
    project.set_Controls("parmMax", 0.50, ":0:SurfRoughB")
    for _ in range(4):
        project.refine()
    sample["SurfRoughA"][1] = False
    sample["SurfRoughB"][1] = False
    project.refine()
    project.save(str(output))
    print("RESULT", "Rwp", hist.get_wR(), "A", sample["SurfRoughA"][0],
          "B", sample["SurfRoughB"][0], "frozen",
          [str(v) for v in controls.get("parmFrozen", {}).get("FrozenList", [])])


if __name__ == "__main__":
    main()
