#!/usr/bin/env python3
"""Test one March-Dollase axis for the transferred phase."""

from pathlib import Path
import sys
from GSASII import GSASIIscriptable as G2


def main():
    source, output = Path(sys.argv[1]), Path(sys.argv[2])
    axis = [int(v) for v in sys.argv[3].split(",")]
    G2.SetPrintLevel("warn")
    p = G2.G2Project(str(source))
    p.save(str(output))
    ph = p.phase("Mn2WO6")
    h = p.histograms()[0]
    ph.set_refinements({"Atoms": {"all": " "}})
    hap = ph.data["Histograms"][h.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = axis
    p.set_Controls("cycles", 16)
    p.refine()
    p.save(str(output))
    print("Rwp", h.get_wR(), "axis", axis, "ratio", hap["Pref.Ori."][1], "scale", hap["Scale"][0])


if __name__ == "__main__":
    main()
