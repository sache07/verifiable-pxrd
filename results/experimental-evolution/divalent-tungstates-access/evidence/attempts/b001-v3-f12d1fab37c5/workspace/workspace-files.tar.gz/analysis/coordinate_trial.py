#!/usr/bin/env python3
"""Refine selected Mn2WO6 coordinates from a common physical checkpoint."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def main():
    if len(sys.argv) < 4:
        raise SystemExit("usage: coordinate_trial.py INPUT.gpx OUTPUT.gpx ATOM[,ATOM...]")
    source, output = Path(sys.argv[1]), Path(sys.argv[2])
    labels = sys.argv[3].split(",")
    G2.SetPrintLevel("warn")
    p = G2.G2Project(str(source))
    p.save(str(output))
    ph = p.phase("Mn2WO6")
    ph.set_refinements({"Atoms": {"all": " "}})
    ph.set_refinements({"Atoms": {label: "X" for label in labels}})
    p.set_Controls("cycles", 16)
    p.refine()
    p.save(str(output))
    ph.export_CIF(str(output.with_suffix(".cif")))
    h = p.histograms()[0]
    print("Rwp", h.get_wR())
    for atom in ph.atoms():
        print(atom.label, tuple(round(float(v), 8) for v in atom.coordinates), atom.refinement_flags)


if __name__ == "__main__":
    main()
