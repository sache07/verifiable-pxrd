#!/usr/bin/env python3
"""Test the three generator-allowed uniaxial microstrain directions."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def main():
    source, stem, phase_name = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
    G2.SetPrintLevel("warn")
    for axis in AXES:
        tag = "".join(str(v) for v in axis)
        output = stem.with_name(f"{stem.name}_{tag}.gpx")
        project = G2.G2Project(str(source))
        project.save(str(output))
        controls = project.data["Controls"]["data"]
        controls["parmFrozen"] = {"FrozenList": []}
        controls["parmMinDict"] = {}
        controls["parmMaxDict"] = {}
        phase = project.phase(phase_name)
        hist = project.histograms()[0]
        hap = phase.data["Histograms"][hist.name]
        equatorial = float(hap["Mustrain"][1][0])
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][1] = equatorial
        hap["Mustrain"][2] = [False, True, False]
        hap["Mustrain"][3] = list(axis)
        project.set_Controls("parmMin", max(0.0, 0.25 * equatorial), f"{phase.id}:0:Mustrain;a")
        project.set_Controls("parmMax", 4.0 * equatorial, f"{phase.id}:0:Mustrain;a")
        project.set_Controls("cycles", 20)
        project.refine()
        project.refine()
        project.refine()
        hap["Mustrain"][2] = [False, False, False]
        project.save(str(output))
        axial = float(hap["Mustrain"][1][1])
        print("axis", axis, "Rwp", hist.get_wR(), "equatorial", equatorial,
              "axial", axial, "ratio", axial / equatorial if equatorial else None,
              "frozen", [str(v) for v in controls.get("parmFrozen", {}).get("FrozenList", [])])


if __name__ == "__main__":
    main()
