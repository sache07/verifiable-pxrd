#!/usr/bin/env python3
"""Refine MnWO4 + WO3 + transferred Mn2WO6 + rocksalt MnO with bounded widths."""

from pathlib import Path
import sys
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def set_cell(phase, values):
    phase.data["General"]["Cell"][1:7] = list(values)
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(values))


def main():
    source = Path(sys.argv[1] if len(sys.argv) > 1 else "analysis/four_mno.gpx")
    output = Path(sys.argv[2] if len(sys.argv) > 2 else "analysis/physical_four_mno.gpx")
    G2.SetPrintLevel("warn")
    p = G2.G2Project(str(source)); p.save(str(output)); h = p.histograms()[0]
    h.data["Instrument Parameters"][0]["Zero"] = [0.0, -0.05591, False]
    h.SampleParameters["Shift"] = [-741.81, False]
    h.SampleParameters["Gonio. radius"] = 200.0
    starts = {
        "MnWO4": ([4.7936753, 5.7090293, 4.9760390, 90, 91.1153244, 90], .0825, 4352.),
        "WO3": ([7.6887556, 7.5363738, 10.5303196, 90, 136.1213957, 90], .1230, 8000.),
        "Mn2WO6": ([5.0457784, 8.6436529, 9.3990748, 90, 90, 90], .0804, 7685.),
        "MnO": ([4.4002090, 4.4002090, 4.4002090, 90, 90, 90], 1.0, 300.),
    }
    for ph in p.phases():
        cell, size, strain = starts[ph.name]; set_cell(ph, cell)
        ph.set_refinements({"Atoms": {"all": " "}, "Cell": True})
        hap = ph.data["Histograms"][h.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"; hap["Size"][1][0] = size; hap["Size"][2] = [False]*3
        hap["Mustrain"][0] = "isotropic"; hap["Mustrain"][1][0] = strain; hap["Mustrain"][2] = [False]*3
    h.set_refinements({"Background": True})
    h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
    h.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    p.set_Controls("cycles", 16); p.refine()
    # Refine only the MnO crystallite size; retain low physical strain.
    mno = p.phase("MnO")
    mno.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    p.refine()
    mno.clear_HAP_refinements({"Size": True})
    p.save(str(output))
    print("Rwp", h.get_wR())
    for ph in p.phases():
        hap=ph.data["Histograms"][h.name]
        print(ph.name,ph.get_cell(),"scale",hap["Scale"][0],"size",hap["Size"][1][0],"strain",hap["Mustrain"][1][0])


if __name__ == "__main__": main()
