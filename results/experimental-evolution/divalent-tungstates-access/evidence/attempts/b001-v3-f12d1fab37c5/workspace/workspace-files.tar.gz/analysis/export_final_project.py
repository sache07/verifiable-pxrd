#!/usr/bin/env python3
"""Save the accepted GSAS-II project and export one CIF per included phase."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


FILENAMES = {
    "MnWO4": "MnWO4.cif",
    "WO3": "WO3.cif",
    "Mn2WO6": "Mn2WO6.cif",
    "MnO": "MnO.cif",
}


def main():
    source = Path(sys.argv[1])
    destination = Path(sys.argv[2])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(source))
    project.save(str(destination))
    for phase in project.phases():
        phase.export_CIF(str(destination.parent / FILENAMES[phase.name]))
    hist = project.histograms()[0]
    print("RESULT", destination, hist.name, hist.get_wR(),
          [(p.name, p.data["Histograms"][hist.name]["Scale"][0]) for p in project.phases()])


if __name__ == "__main__":
    main()
