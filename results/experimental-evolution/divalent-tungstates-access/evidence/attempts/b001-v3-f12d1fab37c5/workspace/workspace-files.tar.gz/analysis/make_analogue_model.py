#!/usr/bin/env python3
"""Create a Mn2WO6 analogue model from an A2BO6 COD structure."""

from pathlib import Path
import sys

from pymatgen.core import Element, Structure
from pymatgen.io.cif import CifWriter


def cif_path(root: Path, cid: str) -> Path:
    return root / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


def main():
    cid, scale, output = sys.argv[1], float(sys.argv[2]), Path(sys.argv[3])
    root = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06/cif")
    s = Structure.from_file(cif_path(root, cid))
    comp = s.composition.reduced_composition
    mapping = {}
    for site in s:
        for sp in site.species:
            el = sp.element if hasattr(sp, "element") else sp
            if str(el) == "O":
                continue
            mapping[sp] = Element("W") if comp[el] < 1.5 else Element("Mn")
    s.replace_species(mapping)
    s.scale_lattice(s.volume * scale ** 3)
    output.parent.mkdir(parents=True, exist_ok=True)
    CifWriter(s, symprec=1e-3, refine_struct=False).write_file(output)
    print(cid, "->", output, s.composition.reduced_formula, s.get_space_group_info(), s.lattice)


if __name__ == "__main__":
    main()
