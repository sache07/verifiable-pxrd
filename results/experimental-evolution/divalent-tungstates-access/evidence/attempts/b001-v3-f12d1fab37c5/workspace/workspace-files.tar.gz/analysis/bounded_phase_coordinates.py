#!/usr/bin/env python3
"""Bounded heavy-atom coordinate branches for a named phase."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def main():
    if len(sys.argv) < 6:
        raise SystemExit("usage: bounded_phase_coordinates.py INPUT.gpx STEM PHASE ATOM[,ATOM] RADIUS_A[,RADIUS_A]")
    source, stem, phase_name = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
    labels = sys.argv[4].split(",")
    radii = [float(v) for v in sys.argv[5].split(",")]
    G2.SetPrintLevel("warn")
    for radius in radii:
        output = stem.with_name(f"{stem.name}_{radius:.3f}A.gpx")
        project = G2.G2Project(str(source))
        project.save(str(output))
        controls = project.data["Controls"]["data"]
        controls["parmFrozen"] = {"FrozenList": []}
        controls["parmMinDict"] = {}
        controls["parmMaxDict"] = {}
        phase = project.phase(phase_name)
        phase.set_refinements({"Atoms": {"all": " "}})
        phase.set_refinements({"Atoms": {label: "X" for label in labels}})
        cell = phase.get_cell()
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        atoms = phase.data["Atoms"]
        index = {atom[0]: i for i, atom in enumerate(atoms)}
        for label in labels:
            i = index[label]
            for j, (axis, coordinate) in enumerate(zip("xyz", atoms[i][3:6])):
                variable = f"{phase.id}::dA{axis}:{i}"
                project.set_Controls("parmMin", float(coordinate) - radius / lengths[j], variable)
                project.set_Controls("parmMax", float(coordinate) + radius / lengths[j], variable)
        project.set_Controls("cycles", 20)
        project.refine()
        project.refine()
        project.refine()
        phase.set_refinements({"Atoms": {"all": " "}})
        project.save(str(output))
        phase.export_CIF(str(output.with_suffix(".cif")))
        hist = project.histograms()[0]
        frozen = [str(v) for v in controls.get("parmFrozen", {}).get("FrozenList", [])]
        print("radius", radius, "Rwp", hist.get_wR(), "frozen", frozen)
        for atom in phase.atoms():
            if atom.label in labels:
                print(atom.label, tuple(round(float(v), 9) for v in atom.coordinates))


if __name__ == "__main__":
    main()
