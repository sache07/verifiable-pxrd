#!/usr/bin/env python3
"""Small, explicit GSAS-II workflow used for candidate trials and final export.

Run with the GSAS-II Python interpreter. Every refinement writes to a copied
project so a divergent branch cannot corrupt its stable parent.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")


def freeze_all(project):
    """Clear every ordinary refinement flag while preserving parameter values."""
    for hist in project.histograms():
        hist.data["Background"][0][1] = False
        for value in hist.data["Instrument Parameters"][0].values():
            if isinstance(value, list) and len(value) > 2:
                value[2] = False
        for key, value in hist.data["Sample Parameters"].items():
            if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
                value[1] = False
        hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        for hap in phase.data.get("Histograms", {}).values():
            hap["Scale"][1] = False
            hap["Pref.Ori."][2] = False
            hap["Size"][2] = [False] * len(hap["Size"][2])
            hap["Size"][5] = [False] * len(hap["Size"][5])
            hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
            hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
            hap["Extinction"][1] = False
    project.set_Frozen()


def selected_phases(project, names):
    if not names:
        return project.phases()
    result = []
    for name in names:
        phase = project.phase(name)
        if phase is None:
            raise ValueError(f"No phase named {name!r}")
        result.append(phase)
    return result


def set_common_flags(project, *, background=True, scales=True):
    for hist in project.histograms():
        hist.data["Background"][0][1] = bool(background)
    if scales:
        for phase in project.phases():
            phase.set_HAP_refinements({"Scale": True})


def set_bounds(project):
    """Broad physical limits; values reaching them are reviewed, not accepted."""
    for hist in project.histograms():
        h = hist.id
        for var, lo, hi in [
            (f":{h}:Zero", -0.25, 0.25),
            (f":{h}:Shift", -800.0, 800.0),
            (f":{h}:U", 0.0, 40.0),
            (f":{h}:W", 2.0, 40.0),
            (f":{h}:X", 0.1, 6.0),
            (f":{h}:SH/L", 0.005, 0.1),
            (f":{h}:Polariz.", 0.5, 1.0),
            (f":{h}:SurfRoughA", 0.0, 0.6),
            (f":{h}:SurfRoughB", 0.0, 0.5),
        ]:
            project.set_Controls("parmMin", lo, variable=var)
            project.set_Controls("parmMax", hi, variable=var)
    for phase in project.phases():
        for hist in project.histograms():
            if hist.name not in phase.data.get("Histograms", {}):
                continue
            p, h = phase.id, hist.id
            for var, lo, hi in [
                (f"{p}:{h}:Scale", 0.0, 1.0e5),
                (f"{p}:{h}:Size;i", 0.04, 1.5),
                (f"{p}:{h}:Mustrain;i", 0.0, 8000.0),
                (f"{p}:{h}:Mustrain;a", 0.0, 32000.0),
                (f"{p}:{h}:MD", 0.7, 1.4),
            ]:
                project.set_Controls("parmMin", lo, variable=var)
                project.set_Controls("parmMax", hi, variable=var)


def phase_summary(project):
    hist = project.histograms()[0]
    rows = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if not hap or not hap.get("Use", True):
            continue
        mass = float(phase.data["General"]["Mass"])
        scale = float(hap["Scale"][0])
        masses.append(max(0.0, mass * scale))
        rows.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": scale,
                "cell_mass": mass,
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    total = sum(masses)
    for row, value in zip(rows, masses):
        row["weight_fraction"] = value / total if total > 0 else None
    return rows


def project_summary(project):
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "project": str(project.filename),
        "histogram": hist.name,
        "residuals": hist.residuals,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample_parameters": hist.data["Sample Parameters"],
        "background": hist.data["Background"],
        "phases": phase_summary(project),
        "refinement": cov.get("Rvals", {}),
        "vary_list": [str(v) for v in cov.get("varyList", [])],
        "frozen": project.get_Frozen(),
    }


def parse_phase_spec(spec):
    if "=" not in spec:
        raise ValueError("Phase specifications must be NAME=PATH")
    name, path = spec.split("=", 1)
    if not name or not path:
        raise ValueError("Phase specifications must be NAME=PATH")
    return name, Path(path)


def cmd_build(args):
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    phases = [parse_phase_spec(s) for s in args.phase]
    project = G2.G2Project(newgpx=str(output))
    for name, path in phases:
        project.add_phase(str(path.resolve()), phasename=name, fmthint="CIF")
    hist = project.add_powder_histogram(
        str(Path(args.pattern).resolve()),
        str(Path(args.instrument).resolve()),
        phases="all",
        fmthint="xye",
    )
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_terms,
                "coeffs": [args.background] + [0.0] * (args.background_terms - 1),
                "refine": False,
            }
        }
    )
    scales = args.scale or [100.0] + [10.0] * (len(phases) - 1)
    if len(scales) == 1 and len(phases) > 1:
        scales = scales * len(phases)
    if len(scales) != len(phases):
        raise ValueError("Supply one initial scale per phase")
    for phase, scale in zip(project.phases(), scales):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [float(scale), False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = args.size
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = args.mustrain
    freeze_all(project)
    set_bounds(project)
    project.set_Controls("cycles", 0)
    project.refine()
    project.save(str(output))
    print(json.dumps(project_summary(project), indent=2, default=str))


def cmd_add(args):
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.input, output)
    project = G2.G2Project(gpxfile=str(output))
    freeze_all(project)
    hist = project.histograms()[0]
    name, path = parse_phase_spec(args.phase)
    if project.phase(name) is not None:
        raise ValueError(f"Phase {name!r} already exists")
    phase = project.add_phase(
        str(path.resolve()), phasename=name, histograms=[hist], fmthint="CIF"
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [float(args.scale), False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = args.size
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = args.mustrain
    set_bounds(project)
    project.set_Controls("cycles", 0)
    project.refine()
    project.save(str(output))
    print(json.dumps(project_summary(project), indent=2, default=str))


def cmd_refine(args):
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.input, output)
    project = G2.G2Project(gpxfile=str(output))
    freeze_all(project)
    set_bounds(project)
    phases = selected_phases(project, args.phases)
    set_common_flags(project, background=True, scales=True)
    hist = project.histograms()[0]

    if args.stage == "scale_bg":
        pass
    elif args.stage == "cell":
        for phase in phases:
            phase.set_refinements({"Cell": True})
    elif args.stage == "zero":
        hist.data["Instrument Parameters"][0]["Zero"][2] = True
    elif args.stage == "shift":
        hist.data["Sample Parameters"]["Shift"][1] = True
    elif args.stage == "zero_cell":
        hist.data["Instrument Parameters"][0]["Zero"][2] = True
        for phase in phases:
            phase.set_refinements({"Cell": True})
    elif args.stage == "shift_cell":
        hist.data["Instrument Parameters"][0]["Zero"][2] = True
        hist.data["Sample Parameters"]["Shift"][1] = True
        for phase in phases:
            phase.set_refinements({"Cell": True})
    elif args.stage == "phase_profile":
        for phase in phases:
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True},
                }
            )
    elif args.stage == "size":
        for phase in phases:
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "refine": True}}
            )
    elif args.stage == "mustrain":
        for phase in phases:
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )
    elif args.stage == "uniaxial_mustrain":
        axis = [int(v) for v in args.axis.split(",")]
        if len(axis) != 3 or axis == [0, 0, 0]:
            raise ValueError("Uniaxial microstrain axis must be a nonzero h,k,l")
        for phase in phases:
            for hap in phase.data["Histograms"].values():
                value = float(hap["Mustrain"][1][0])
                hap["Mustrain"][0] = "uniaxial"
                hap["Mustrain"][1][1] = value
                # Keep the established equatorial value fixed and test only the
                # single added axial term; refining both together is often singular.
                hap["Mustrain"][2][0] = False
                hap["Mustrain"][2][1] = True
                hap["Mustrain"][3] = axis
    elif args.stage == "instrument_profile":
        for key in args.instrument_terms:
            hist.data["Instrument Parameters"][0][key][2] = True
    elif args.stage == "surface_roughness":
        if float(hist.data["Sample Parameters"]["SurfRoughA"][0]) <= 0:
            hist.data["Sample Parameters"]["SurfRoughA"][0] = 0.2
        if float(hist.data["Sample Parameters"]["SurfRoughB"][0]) <= 0:
            hist.data["Sample Parameters"]["SurfRoughB"][0] = 0.1
        hist.data["Sample Parameters"]["SurfRoughA"][1] = True
        hist.data["Sample Parameters"]["SurfRoughB"][1] = True
    elif args.stage == "coordinates":
        for phase in phases:
            cell = phase.get_cell()
            lengths = [
                float(cell["length_a"]),
                float(cell["length_b"]),
                float(cell["length_c"]),
            ]
            for atom_index, atom in enumerate(phase.atoms()):
                if ((not args.elements or atom.element in args.elements)
                        and (not args.atoms or atom.label in args.atoms)):
                    atom.refinement_flags = "X"
                    if args.max_coordinate_component_A is not None:
                        # Despite the dA prefix, GSAS-II bounds these as the
                        # absolute fractional coordinates stored in the phase.
                        for axis, length, coordinate in zip(
                                "xyz", lengths, atom.coordinates):
                            limit = float(args.max_coordinate_component_A) / length
                            variable = f"{phase.id}::dA{axis}:{atom_index}"
                            project.set_Controls(
                                "parmMin", float(coordinate) - limit, variable=variable)
                            project.set_Controls(
                                "parmMax", float(coordinate) + limit, variable=variable)
    elif args.stage == "uiso":
        for phase in phases:
            for atom in phase.atoms():
                if ((not args.elements or atom.element in args.elements)
                        and (not args.atoms or atom.label in args.atoms)):
                    atom.refinement_flags = "U"
    elif args.stage == "coordinates_uiso":
        for phase in phases:
            for atom in phase.atoms():
                if ((not args.elements or atom.element in args.elements)
                        and (not args.atoms or atom.label in args.atoms)):
                    atom.refinement_flags = "XU"
    elif args.stage == "texture":
        axis = [int(v) for v in args.axis.split(",")]
        if len(axis) != 3:
            raise ValueError("Texture axis must be h,k,l")
        for phase in phases:
            for hap in phase.data["Histograms"].values():
                hap["Pref.Ori."][0] = "MD"
                hap["Pref.Ori."][3] = axis
            phase.set_HAP_refinements({"Pref.Ori.": True})
    else:
        raise ValueError(args.stage)

    if args.keep_zero and args.stage not in ("zero", "zero_cell", "shift_cell"):
        hist.data["Instrument Parameters"][0]["Zero"][2] = True
    if args.keep_cells and args.stage not in ("zero_cell", "shift_cell"):
        for phase in selected_phases(project, args.keep_cells):
            phase.set_refinements({"Cell": True})
    if args.keep_profiles:
        for phase in selected_phases(project, args.keep_profiles):
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True},
                }
            )

    project.set_Controls("cycles", args.cycles)
    project.refine()
    project.save(str(output))
    summary = project_summary(project)
    if args.summary:
        Path(args.summary).write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps(summary, indent=2, default=str))


def cmd_set_profile(args):
    """Set fixed isotropic profile values on named phases without refining."""
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.input, output)
    project = G2.G2Project(gpxfile=str(output))
    freeze_all(project)
    hist = project.histograms()[0]
    for phase in selected_phases(project, args.phases):
        hap = phase.data["Histograms"][hist.name]
        if args.size is not None:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = float(args.size)
        if args.mustrain is not None:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = float(args.mustrain)
    set_bounds(project)
    project.set_Controls("cycles", 0)
    project.refine()
    project.save(str(output))
    summary = project_summary(project)
    if args.summary:
        Path(args.summary).write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps(summary, indent=2, default=str))


def cmd_summary(args):
    project = G2.G2Project(gpxfile=args.input)
    print(json.dumps(project_summary(project), indent=2, default=str))


def cmd_sanitize(args):
    """Copy a project and place retained nuisance values inside lab-supported ranges."""
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.input, output)
    project = G2.G2Project(gpxfile=str(output))
    freeze_all(project)
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    for key, lo, hi in [
        ("Zero", -0.25, 0.25),
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.1),
        ("Polariz.", 0.5, 1.0),
    ]:
        inst[key][1] = min(hi, max(lo, float(inst[key][1])))
    sample = hist.data["Sample Parameters"]
    sample["Shift"][0] = min(800.0, max(-800.0, float(sample["Shift"][0])))
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][1][0] = min(1.5, max(0.04, float(hap["Size"][1][0])))
        hap["Mustrain"][1][0] = min(8000.0, max(0.0, float(hap["Mustrain"][1][0])))
        if not 0.7 <= float(hap["Pref.Ori."][1]) <= 1.4:
            hap["Pref.Ori."][1] = 1.0
        for atom in phase.atoms():
            if atom.adp_flag == "I":
                atom.uiso = min(0.02, max(0.003, float(atom.uiso)))
    set_bounds(project)
    project.set_Controls("cycles", 0)
    project.refine()
    project.save(str(output))
    summary = project_summary(project)
    if args.summary:
        Path(args.summary).write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps(summary, indent=2, default=str))


def cmd_export_profile(args):
    project = G2.G2Project(gpxfile=args.input)
    hist = project.histogram(args.histogram) if args.histogram else project.histograms()[0]
    x, obs, weight, calc, background, diff = hist.data["data"][1]
    with Path(args.output).open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta", "observed", "calculated", "difference", "background"]
        )
        writer.writerows(zip(x, obs, calc, obs - calc, background))


def cmd_export_cifs(args):
    project = G2.G2Project(gpxfile=args.input)
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    for phase in project.phases():
        filename = out / f"{phase.name}.cif"
        phase.export_CIF(str(filename))
        print(filename)


def parser():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="command", required=True)

    b = sub.add_parser("build")
    b.add_argument("output")
    b.add_argument("phase", nargs="+")
    b.add_argument("--pattern", default="pattern.xye")
    b.add_argument("--instrument", default="instrument.instprm")
    b.add_argument("--background", type=float, default=1600.0)
    b.add_argument("--background-terms", type=int, default=10)
    b.add_argument("--scale", type=float, nargs="*")
    b.add_argument("--size", type=float, default=0.3)
    b.add_argument("--mustrain", type=float, default=1000.0)
    b.set_defaults(func=cmd_build)

    a = sub.add_parser("add")
    a.add_argument("input")
    a.add_argument("output")
    a.add_argument("phase")
    a.add_argument("--scale", type=float, default=10.0)
    a.add_argument("--size", type=float, default=0.3)
    a.add_argument("--mustrain", type=float, default=1000.0)
    a.set_defaults(func=cmd_add)

    r = sub.add_parser("refine")
    r.add_argument("input")
    r.add_argument("output")
    r.add_argument(
        "stage",
        choices=[
            "scale_bg",
            "cell",
            "zero",
            "shift",
            "zero_cell",
            "shift_cell",
            "phase_profile",
            "size",
            "mustrain",
            "uniaxial_mustrain",
            "instrument_profile",
            "surface_roughness",
            "coordinates",
            "uiso",
            "coordinates_uiso",
            "texture",
        ],
    )
    r.add_argument("--phases", nargs="*", default=[])
    r.add_argument("--cycles", type=int, default=20)
    r.add_argument("--instrument-terms", nargs="*", default=["U", "W", "X"])
    r.add_argument("--elements", nargs="*", default=[])
    r.add_argument("--atoms", nargs="*", default=[], help="select atom labels")
    r.add_argument("--max-coordinate-component-A", type=float)
    r.add_argument("--axis", default="0,0,1")
    r.add_argument("--keep-zero", action="store_true")
    r.add_argument("--keep-cells", nargs="*", default=[])
    r.add_argument("--keep-profiles", nargs="*", default=[])
    r.add_argument("--summary")
    r.set_defaults(func=cmd_refine)

    sp = sub.add_parser("set-profile")
    sp.add_argument("input")
    sp.add_argument("output")
    sp.add_argument("--phases", nargs="+", required=True)
    sp.add_argument("--size", type=float)
    sp.add_argument("--mustrain", type=float)
    sp.add_argument("--summary")
    sp.set_defaults(func=cmd_set_profile)

    s = sub.add_parser("summary")
    s.add_argument("input")
    s.set_defaults(func=cmd_summary)

    z = sub.add_parser("sanitize")
    z.add_argument("input")
    z.add_argument("output")
    z.add_argument("--summary")
    z.set_defaults(func=cmd_sanitize)

    e = sub.add_parser("export-profile")
    e.add_argument("input")
    e.add_argument("output")
    e.add_argument("--histogram")
    e.set_defaults(func=cmd_export_profile)

    c = sub.add_parser("export-cifs")
    c.add_argument("input")
    c.add_argument("output_dir")
    c.set_defaults(func=cmd_export_cifs)
    return p


if __name__ == "__main__":
    args = parser().parse_args()
    args.func(args)
