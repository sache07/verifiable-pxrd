#!/usr/bin/env python3
"""Create a target Mn-W-O analogue CIF from a COD parent.

All non-W/O framework cations are replaced by Mn. Hydrogen is retained when
present. A uniform lattice factor may be supplied only as a refinement start;
fractional coordinates, occupancies, and topology are preserved.
"""

from __future__ import annotations

import argparse
import json
import warnings
from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)


def cod_path(cid):
    return ROOT / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("cid")
    parser.add_argument("output")
    parser.add_argument("--factor", type=float, default=1.0)
    parser.add_argument("--occupancy-tolerance", type=float, default=2.0)
    args = parser.parse_args()

    source = cod_path(args.cid)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        structure = CifParser(
            source, occupancy_tolerance=args.occupancy_tolerance
        ).parse_structures(primitive=False)[0]
    parent_formula = structure.composition.formula
    substitutions = {}
    for element in structure.composition.elements:
        if str(element) not in ("W", "O", "H"):
            substitutions[element] = "Mn"
    if not substitutions:
        raise ValueError("Parent has no cation to replace")
    structure.replace_species(substitutions)
    if args.factor != 1.0:
        lattice = structure.lattice
        new_lattice = Lattice.from_parameters(
            *(value * args.factor for value in lattice.abc), *lattice.angles
        )
        structure = Structure(
            new_lattice,
            [site.species for site in structure],
            structure.frac_coords,
            site_properties=structure.site_properties,
        )
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    CifWriter(structure, symprec=0.001, refine_struct=False).write_file(output)
    provenance = {
        "model_basis": "analogue_derived",
        "parent_id": args.cid,
        "parent_path": str(source),
        "parent_formula": parent_formula,
        "target_formula": structure.composition.formula,
        "substitutions": {str(k): v for k, v in substitutions.items()},
        "uniform_lattice_start_factor": args.factor,
        "fractional_coordinates_and_occupancies_preserved": True,
        "parser_warnings": [str(item.message) for item in caught],
    }
    output.with_suffix(".provenance.json").write_text(
        json.dumps(provenance, indent=2) + "\n"
    )
    print(json.dumps(provenance, indent=2))


if __name__ == "__main__":
    main()
