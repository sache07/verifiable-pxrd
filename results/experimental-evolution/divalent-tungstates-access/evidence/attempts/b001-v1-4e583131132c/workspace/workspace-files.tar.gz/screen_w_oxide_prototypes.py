#!/usr/bin/env python3
"""Rank one-substitution W-oxide prototypes against the positive GSAS residual.

This is a discovery screen only. Candidates must subsequently be imported,
refined, and physically checked in GSAS-II before acceptance or rejection.
"""

from __future__ import annotations

import csv
import argparse
import gzip
import json
import math
import os
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition
from pymatgen.io.cif import CifParser


ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)
INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/index.json.gz"
)
LAMBDA1 = 1.540598
LAMBDA2 = 1.544426


def cod_path(cid):
    return ROOT / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


def profile(x, peaks, intensities, lattice_factor, width_factor):
    theta = np.deg2rad(np.asarray(peaks) / 2)
    arg = np.clip(np.sin(theta) / lattice_factor, -0.999999, 0.999999)
    p1 = np.rad2deg(2 * np.arcsin(arg))
    arg2 = np.clip((LAMBDA2 / LAMBDA1) * np.sin(np.deg2rad(p1) / 2), -0.999999, 0.999999)
    p2 = np.rad2deg(2 * np.arcsin(arg2))
    result = np.zeros_like(x)
    for positions, ratio in ((p1, 1.0), (p2, 0.5)):
        for pos, inten in zip(positions, intensities):
            fwhm = width_factor * (0.18 + 0.006 * max(0.0, pos - 10.0))
            sigma = fwhm / 2.35482
            lo = np.searchsorted(x, pos - 4 * sigma)
            hi = np.searchsorted(x, pos + 4 * sigma)
            if hi > lo:
                result[lo:hi] += ratio * inten * np.exp(-0.5 * ((x[lo:hi] - pos) / sigma) ** 2)
    maximum = result.max()
    return result / maximum if maximum > 0 else result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fit", default="trials/two_phase_fit.csv")
    parser.add_argument("--output", default="trials/w_oxide_screen.csv")
    args = parser.parse_args()
    fit = np.loadtxt(args.fit, delimiter=",", skiprows=1)
    x, obs, calc = fit[:, 0], fit[:, 1], fit[:, 2]
    residual = obs - calc
    weights = 1 / np.maximum(obs, 1.0)
    base_loss = float(np.sum(weights * residual**2))
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    candidates = []
    for key, records in index.items():
        elements = key.split("-")
        if len(elements) != 3 or "O" not in elements or "W" not in elements:
            continue
        parent_cation = next(e for e in elements if e not in ("O", "W"))
        for formula, cid, sg, quality in records:
            try:
                comp = Composition(formula).element_composition
                aw = float(comp[parent_cation] / comp["W"])
                ow = float(comp["O"] / comp["W"])
            except Exception:
                continue
            if not (0.15 <= aw <= 5.0 and 2.5 <= ow <= 8.0):
                continue
            manganese_valence = (2 * ow - 6) / aw
            if not (1.5 <= manganese_valence <= 4.5):
                continue
            candidates.append((formula, cid, sg, quality, parent_cation, aw, ow))

    rows = []
    calculator = XRDCalculator(wavelength=LAMBDA1)
    for n, (formula, cid, sg, quality, parent_cation, aw, ow) in enumerate(candidates, 1):
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                structure = CifParser(cod_path(cid), occupancy_tolerance=2.0).parse_structures(
                    primitive=False
                )[0]
            for element in list(structure.composition.elements):
                if str(element) not in ("W", "O"):
                    structure.replace_species({element: "Mn"})
            pattern = calculator.get_pattern(structure, two_theta_range=(9.5, 101.0))
            peaks = np.asarray(pattern.x)
            intensities = np.asarray(pattern.y)
            if len(peaks) == 0:
                continue
            best = None
            for factor in np.linspace(0.95, 1.05, 31):
                for width_factor in (0.8, 1.3, 2.0):
                    zero_curve = profile(x, peaks, intensities, factor, width_factor)
                    for offset in np.linspace(-0.1, 0.7, 17):
                        curve = np.interp(x - offset, x, zero_curve, left=0.0, right=0.0)
                        denom = float(np.sum(weights * curve * curve))
                        if denom <= 0:
                            continue
                        amplitude = max(0.0, float(np.sum(weights * curve * residual) / denom))
                        loss = float(np.sum(weights * (residual - amplitude * curve) ** 2))
                        trial = (base_loss - loss, amplitude, factor, offset, width_factor)
                        if best is None or trial[0] > best[0]:
                            best = trial
            if best is None:
                continue
            improvement, amplitude, factor, offset, width_factor = best
            rows.append(
                {
                    "cid": cid,
                    "parent_formula": formula,
                    "parent_cation": parent_cation,
                    "target_formula": structure.composition.reduced_formula,
                    "space_group_index": sg,
                    "detected_space_group": structure.get_space_group_info()[0],
                    "A_per_W": aw,
                    "O_per_W": ow,
                    "quality": quality,
                    "delta_chi2_projection": improvement,
                    "relative_loss_reduction": improvement / base_loss,
                    "projected_amplitude": amplitude,
                    "lattice_factor": factor,
                    "offset_deg": offset,
                    "width_factor": width_factor,
                    "path": str(cod_path(cid)),
                }
            )
        except Exception as exc:
            rows.append(
                {
                    "cid": cid,
                    "parent_formula": formula,
                    "error": str(exc),
                    "path": str(cod_path(cid)),
                }
            )
    good = [row for row in rows if "delta_chi2_projection" in row]
    good.sort(key=lambda row: row["delta_chi2_projection"], reverse=True)
    fields = [
        "rank",
        "cid",
        "parent_formula",
        "parent_cation",
        "target_formula",
        "space_group_index",
        "detected_space_group",
        "A_per_W",
        "O_per_W",
        "quality",
        "delta_chi2_projection",
        "relative_loss_reduction",
        "projected_amplitude",
        "lattice_factor",
        "offset_deg",
        "width_factor",
        "path",
    ]
    with Path(args.output).open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for rank, row in enumerate(good, 1):
            writer.writerow({"rank": rank, **row})
    for rank, row in enumerate(good[:80], 1):
        print(
            f"{rank:3d} {row['cid']} {row['parent_formula']:18s} "
            f"=> {row['target_formula']:12s} SG {row['space_group_index']:3d} "
            f"gain={100*row['relative_loss_reduction']:6.2f}% "
            f"f={row['lattice_factor']:.3f} z={row['offset_deg']:.3f} "
            f"w={row['width_factor']:.1f}"
        )


if __name__ == "__main__":
    main()
