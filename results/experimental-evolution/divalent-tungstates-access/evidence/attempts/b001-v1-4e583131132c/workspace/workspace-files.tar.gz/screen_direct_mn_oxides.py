#!/usr/bin/env python3
"""Residual-projection screen for every direct Mn-O library entry."""

from __future__ import annotations

import argparse
import csv
import gzip
import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.io.cif import CifParser

from screen_w_oxide_prototypes import INDEX, LAMBDA1, cod_path, profile


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fit", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    fit = np.loadtxt(args.fit, delimiter=",", skiprows=1)
    x, obs, calc = fit[:, 0], fit[:, 1], fit[:, 2]
    residual = obs - calc
    weights = 1 / np.maximum(obs, 1.0)
    base_loss = float(np.sum(weights * residual**2))
    with gzip.open(INDEX, "rt") as stream:
        records = json.load(stream)["Mn-O"]
    calculator = XRDCalculator(wavelength=LAMBDA1)
    rows = []
    for formula, cid, sg, quality in records:
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                structure = CifParser(cod_path(cid), occupancy_tolerance=2.0).parse_structures(
                    primitive=False
                )[0]
            pattern = calculator.get_pattern(structure, two_theta_range=(9.5, 101.0))
            peaks = np.asarray(pattern.x)
            intensities = np.asarray(pattern.y)
            best = None
            for factor in np.linspace(0.97, 1.03, 25):
                for width_factor in (0.8, 1.3, 2.0):
                    zero_curve = profile(x, peaks, intensities, factor, width_factor)
                    for offset in np.linspace(-0.25, 0.7, 20):
                        curve = np.interp(x - offset, x, zero_curve, left=0.0, right=0.0)
                        denom = float(np.sum(weights * curve * curve))
                        if denom <= 0:
                            continue
                        amplitude = max(0.0, float(np.sum(weights * curve * residual) / denom))
                        loss = float(np.sum(weights * (residual - amplitude * curve) ** 2))
                        trial = (base_loss - loss, amplitude, factor, offset, width_factor)
                        if best is None or trial[0] > best[0]:
                            best = trial
            improvement, amplitude, factor, offset, width_factor = best
            rows.append(
                {
                    "cid": cid,
                    "formula": formula,
                    "space_group_index": sg,
                    "detected_space_group": structure.get_space_group_info()[0],
                    "quality": quality,
                    "relative_loss_reduction": improvement / base_loss,
                    "projected_amplitude": amplitude,
                    "lattice_factor": factor,
                    "offset_deg": offset,
                    "width_factor": width_factor,
                    "path": str(cod_path(cid)),
                }
            )
        except Exception as exc:
            rows.append({"cid": cid, "formula": formula, "error": str(exc), "path": str(cod_path(cid))})
    rows.sort(key=lambda row: row.get("relative_loss_reduction", -1), reverse=True)
    fields = [
        "rank", "cid", "formula", "space_group_index", "detected_space_group", "quality",
        "relative_loss_reduction", "projected_amplitude", "lattice_factor", "offset_deg",
        "width_factor", "path", "error",
    ]
    with Path(args.output).open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for rank, row in enumerate(rows, 1):
            writer.writerow({"rank": rank, **row})
    for rank, row in enumerate(rows, 1):
        if "relative_loss_reduction" in row:
            print(
                f"{rank:2d} {row['cid']} {row['formula']:12s} SG {row['space_group_index']:3d} "
                f"gain={100 * row['relative_loss_reduction']:6.2f}% "
                f"f={row['lattice_factor']:.4f} z={row['offset_deg']:.3f} w={row['width_factor']:.1f}"
            )
        else:
            print(f"{rank:2d} {row['cid']} {row['formula']:12s} ERROR {row['error']}")


if __name__ == "__main__":
    main()
