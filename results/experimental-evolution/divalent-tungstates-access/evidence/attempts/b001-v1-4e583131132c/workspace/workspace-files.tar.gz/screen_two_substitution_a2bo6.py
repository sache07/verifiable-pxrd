#!/usr/bin/env python3
"""Rank A2BO6 oxide prototypes after A->Mn and B->W substitutions."""

from __future__ import annotations

import argparse
import csv
import gzip
import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition
from pymatgen.io.cif import CifParser

from screen_w_oxide_prototypes import INDEX, LAMBDA1, cod_path, profile


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fit", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    fit = np.loadtxt(args.fit, delimiter=",", skiprows=1)
    x, obs, calc = fit[:, 0], fit[:, 1], fit[:, 2]
    residual = obs - calc
    weights = 1 / np.maximum(obs, 1.0)
    base_loss = float(np.sum(weights * residual**2))
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)

    candidates = []
    for key, records in index.items():
        elements = key.split("-")
        cations = [e for e in elements if e != "O"]
        if len(elements) != 3 or "O" not in elements or len(cations) != 2:
            continue
        for formula, cid, sg, quality in records:
            try:
                comp = Composition(formula).element_composition
                if any(float(comp[e]) <= 0 for e in [*cations, "O"]):
                    continue
                for mn_parent, w_parent in (cations, cations[::-1]):
                    mw = float(comp[mn_parent] / comp[w_parent])
                    ow = float(comp["O"] / comp[w_parent])
                    if abs(mw - 2.0) <= 0.08 and abs(ow - 6.0) <= 0.12:
                        candidates.append(
                            (formula, cid, sg, quality, mn_parent, w_parent, mw, ow)
                        )
            except Exception:
                continue

    calculator = XRDCalculator(wavelength=LAMBDA1)
    rows = []
    for formula, cid, sg, quality, mn_parent, w_parent, mw, ow in candidates:
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                structure = CifParser(cod_path(cid), occupancy_tolerance=2.0).parse_structures(
                    primitive=False
                )[0]
            replacements = {}
            for element in structure.composition.elements:
                symbol = str(element)
                if symbol == mn_parent:
                    replacements[element] = "Mn"
                elif symbol == w_parent:
                    replacements[element] = "W"
            if len(replacements) != 2:
                raise ValueError("parent cations not both represented in parsed structure")
            structure.replace_species(replacements)
            if set(str(e) for e in structure.composition.elements) != {"Mn", "W", "O"}:
                raise ValueError("substitution left an unexpected element")
            pattern = calculator.get_pattern(structure, two_theta_range=(9.5, 101.0))
            peaks = np.asarray(pattern.x)
            intensities = np.asarray(pattern.y)
            best = None
            for factor in np.linspace(0.85, 1.15, 31):
                for width_factor in (0.8, 1.3, 2.0):
                    zero_curve = profile(x, peaks, intensities, factor, width_factor)
                    for offset in np.linspace(-0.25, 0.7, 20):
                        curve = np.interp(x - offset, x, zero_curve, left=0.0, right=0.0)
                        denom = float(np.sum(weights * curve * curve))
                        if denom <= 0:
                            continue
                        amplitude = max(0.0, float(np.sum(weights * curve * residual) / denom))
                        loss = float(np.sum(weights * (residual - amplitude * curve) ** 2))
                        trial = (base_loss - loss, amplitude, factor, offset, width_factor)
                        if best is None or trial[0] > best[0]:
                            best = trial
            improvement, amplitude, factor, offset, width_factor = best
            rows.append(
                {
                    "cid": cid,
                    "parent_formula": formula,
                    "mn_parent": mn_parent,
                    "w_parent": w_parent,
                    "space_group_index": sg,
                    "detected_space_group": structure.get_space_group_info()[0],
                    "quality": quality,
                    "relative_loss_reduction": improvement / base_loss,
                    "projected_amplitude": amplitude,
                    "lattice_factor": factor,
                    "offset_deg": offset,
                    "width_factor": width_factor,
                    "path": str(cod_path(cid)),
                }
            )
        except Exception as exc:
            rows.append(
                {
                    "cid": cid,
                    "parent_formula": formula,
                    "mn_parent": mn_parent,
                    "w_parent": w_parent,
                    "error": str(exc),
                    "path": str(cod_path(cid)),
                }
            )
    rows.sort(key=lambda row: row.get("relative_loss_reduction", -1), reverse=True)
    fields = [
        "rank", "cid", "parent_formula", "mn_parent", "w_parent", "space_group_index",
        "detected_space_group", "quality", "relative_loss_reduction", "projected_amplitude",
        "lattice_factor", "offset_deg", "width_factor", "path", "error",
    ]
    with Path(args.output).open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for rank, row in enumerate(rows, 1):
            writer.writerow({"rank": rank, **row})
    for rank, row in enumerate([r for r in rows if "relative_loss_reduction" in r][:100], 1):
        print(
            f"{rank:3d} {row['cid']} {row['parent_formula']:16s} "
            f"{row['mn_parent']}->Mn {row['w_parent']}->W SG {row['space_group_index']:3d} "
            f"gain={100 * row['relative_loss_reduction']:6.2f}% "
            f"f={row['lattice_factor']:.3f} z={row['offset_deg']:.3f} w={row['width_factor']:.1f}"
        )


if __name__ == "__main__":
    main()
