#!/usr/bin/env python3
"""Create Mn2WO6 from an A2BO6 parent with explicit site substitutions."""

from __future__ import annotations

import argparse
import json
import warnings
from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifParser, CifWriter

from make_analogue_candidate import cod_path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("cid")
    parser.add_argument("output")
    parser.add_argument("--mn-parent", required=True)
    parser.add_argument("--w-parent", required=True)
    parser.add_argument("--factor", type=float, default=1.0)
    parser.add_argument("--occupancy-tolerance", type=float, default=2.0)
    args = parser.parse_args()
    if args.mn_parent == args.w_parent:
        raise ValueError("Mn and W parent species must differ")
    source = cod_path(args.cid)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        structure = CifParser(
            source, occupancy_tolerance=args.occupancy_tolerance
        ).parse_structures(primitive=False)[0]
    parent_formula = structure.composition.formula
    substitutions = {}
    for element in structure.composition.elements:
        if str(element) == args.mn_parent:
            substitutions[element] = "Mn"
        elif str(element) == args.w_parent:
            substitutions[element] = "W"
    if len(substitutions) != 2:
        raise ValueError("Both requested parent elements must occur in the parsed structure")
    structure.replace_species(substitutions)
    if set(str(e) for e in structure.composition.elements) != {"Mn", "W", "O"}:
        raise ValueError("Unexpected element remains after substitution")
    if args.factor != 1.0:
        lattice = structure.lattice
        new_lattice = Lattice.from_parameters(
            *(value * args.factor for value in lattice.abc), *lattice.angles
        )
        structure = Structure(
            new_lattice,
            [site.species for site in structure],
            structure.frac_coords,
            site_properties=structure.site_properties,
        )
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    CifWriter(structure, symprec=0.001, refine_struct=False).write_file(output)
    provenance = {
        "model_basis": "two_substitution_analogue",
        "parent_id": args.cid,
        "parent_path": str(source),
        "parent_formula": parent_formula,
        "target_formula": structure.composition.formula,
        "substitutions": {args.mn_parent: "Mn", args.w_parent: "W"},
        "uniform_lattice_start_factor": args.factor,
        "fractional_coordinates_occupancies_and_topology_preserved": True,
        "parser_warnings": [str(item.message) for item in caught],
    }
    output.with_suffix(".provenance.json").write_text(
        json.dumps(provenance, indent=2) + "\n"
    )
    print(json.dumps(provenance, indent=2))


if __name__ == "__main__":
    main()
