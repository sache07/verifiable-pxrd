# Candidate ledger

All full candidate comparisons used the same observed histogram and common nuisance model. Each branch was imported by phase name with a positive initial scale, then compared by scale/background and cell stages. A failed import or interrupted/unstable refinement is marked unknown, not rejected.

| Branch | Model or source | Status | Outcome |
|---|---|---|---|
| MnWO4 wolframite | direct MnWO4, COD 1520200, P 2/c | tested - accepted | Dominant chemically economical phase; stable cell and positive scale. |
| MnWO4 alternatives | FeWO4 P 2/c analogues; scheelite I41/a; fergusonite C2/c; Cu/ZnWO4 triclinic and other AWO4 prototypes | tested - rejected | Common-setting trials were worse or scales collapsed; no coherent residual family justified replacing wolframite. |
| WO3 exact-formula inventory | all nine available WO3 records | tested | COD 2311041 P 21/c accepted; other monoclinic, triclinic, orthorhombic, tetragonal, and hexagonal records rejected by common-setting comparisons. |
| Mn3O4 precursor | I41/amd COD 9001963 and Pbcm COD 1541183/9001302 | tested - rejected | Stable trials did not close the residual families and were inferior to MnO. |
| Other direct Mn oxides | all 38 Mn-O library records, including MnO, Mn2O3, and MnO2 polymorphs | tested | Wurtzite MnO COD 4117966 accepted; rocksalt MnO and all other Mn-oxide candidates rejected by scale/cell trials. |
| Mn2WO6 P 21 21 21 | Y2WO6 COD 1541070, Y-to-Mn | tested - accepted as analogue | Stable positive contribution. Gd2TeO6, Nd2TeO6, and Y2TeO6 transformations were all worse under identical settings. |
| Mn2WO6 Pbcn, disordered | Fe2.66664W1.33336O8 COD 1565524, Fe-to-Mn | tested - accepted as analogue | Stable about 2.8 wt%; mixed Mn/W site preserved. COD 7243652 variant was inferior. |
| Mn2WO6 Pbcn, ordered | Fe2WO6 COD 2310464 and other ordered Pbcn parents | tested - rejected | Less stable/less economical than the retained disordered topology. |
| Mn2WO6 P -3 1 m | MnSb2O6 COD 4342220; Sb-to-Mn and Mn-to-W | tested - accepted provisionally | Stable 4.3 wt% contribution, interior profile/texture values, and clear gain over the five-phase model. |
| P -3 1 m topology variants | Sb2PbO6 COD 1528711; Ca(SbO3)2 COD 2009656; Hg(AsO3)2 COD 8101392 | tested - rejected | Final fractions were about 0.8, 0.4, and 0 wt%, respectively, with Rwp near the five-phase value. |
| Further P -3 1 m variants | Ba/Sr(SbO3)2 and Cd(AsO3)2 parents | unknown | CIFs constructed and projection-screened, but not admitted to a complete GSAS-II branch after stronger variants failed. |
| Mn2WO6 P4/nmm | Y2WO6 COD 1563285 | tested - rejected | Scale/profile branch collapsed or required boundary profile values. |
| Other A2BO6 substitutions | P213 Ta/Cu, P65 Li/I, Pbcn Zr/Ti, Pna21/Pbca/Aea2 and related one/two-substitution parents | tested - rejected | Topology-diverse shortlist was inferior to the accepted P 21 21 21, Pbcn, and P -3 1 m models under common settings. |
| Mn2WO6 P21/c | Cu2TeO6 COD 9004359 transformation | unknown | Import failed; no fit-based rejection was assigned. |
| Other Mn-W-O stoichiometries | MnW2O8, Mn3W2O9, Mn3WO6, MnWO5 and related W-oxide prototypes | tested - rejected | Added scales collapsed to trace values or gains required invalid/boundary cells or profiles. |
| P 21 21 21 preferred orientation | [100], [010], [001] | tested - rejected | All March-Dollase values reached 0.7 or 1.4 bounds. |
| P -3 1 m preferred orientation | [100], [111], [001] | tested | [100]/[111] reached bounds; [001] retained at MD = 1.1274, stable and interior. |
| P 21 21 21 coordinates | W and O1-O6 site trials | tested - rejected | Unrestrained shifts were 0.4-3.2 Å and generated 0.82-1.38 Å contacts; bounded W refinement drove all components to their limits. |
| P 21 21 21 Mn1 coordinates | bounded Mn1 trial | unknown | Trial was interrupted before a valid summary was produced. |
| P 21 21 21 cell replay | independent a, b, c | tested - rejected/rollback | Alternated between equivalent solutions for a negligible Rwp gain; original stable cell retained. |
| P -3 1 m cell replay | independent a, c | tested - rejected/rollback | Cell and Rwp oscillated on repeat; earlier stable cell retained. |
| P -3 1 m isotropic profile | size and strain separately | tested | Size retained at 0.1605 micrometre; strain-only gain negligible, so fixed 3000 ppm value retained. |
| WO3 and P 21 21 21 profiles | isotropic size/strain | tested - rejected/rollback | Strain exceeded/hit 8000 ppm ceiling; size-only trials hit 0.04 micrometre. Restored pre-profile 0.3 micrometre and 1000 ppm. |
| Surface roughness | Suortti A/B | tested - rejected | Singular/boundary solution. |
| Uniaxial strain | P 21 21 21 axes [001], [010], [100] | tested - rejected | Boundary-hitting or unstable; no anisotropy retained. |
