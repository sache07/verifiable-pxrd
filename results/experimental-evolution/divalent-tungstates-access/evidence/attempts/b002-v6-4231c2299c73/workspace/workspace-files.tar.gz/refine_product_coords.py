#!/usr/bin/env python3
"""Refine the dominant analogue-derived ZnWO4 coordinates with tight bounds."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def clear_flags(project, hist):
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
                "Babinet": ["BabA", "BabU"],
            },
            histograms=[hist],
        )


def fractions(project, hist):
    weights = {
        phase.name: max(
            0.0,
            float(phase.data["General"]["Mass"])
            * float(phase.data["Histograms"][hist.name]["Scale"][0]),
        )
        for phase in project.phases()
    }
    total = sum(weights.values())
    return {key: value / total for key, value in weights.items()}


def run(project, hist, name, cycles):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    row = {
        "stage": name,
        "Rwp_percent": float(hist.get_wR()),
        "fractions": fractions(project, hist),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(value) for value in project.get_Frozen()],
        "atoms": {
            phase.name: {
                atom.label: {"xyz": atom.coordinates, "U": atom.ADP}
                for atom in phase.atoms()
            }
            for phase in project.phases()
        },
    }
    print(json.dumps(row, default=lambda value: value.tolist() if hasattr(value, "tolist") else str(value)), flush=True)
    return row


def install_bounds(project, hist):
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    project.index_ids()
    hid = hist.data["data"][0]["hId"]
    for phase in project.phases():
        pid = phase.data["pId"]
        hap = phase.data["Histograms"][hist.name]
        scale = max(float(hap["Scale"][0]), 0.0)
        project.set_Controls("parmMin", max(scale * 0.25, 0.0), variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMax", max(scale * 4.0, 1.0), variable=f"{pid}:{hid}:Scale")
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A(
            [
                cell["length_a"], cell["length_b"], cell["length_c"],
                cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
            ]
        )
        for index, value in enumerate(reciprocal):
            value = float(value)
            span = max(abs(value) * 0.01, 0.0003)
            project.set_Controls("parmMin", value - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", value + span, variable=f"{pid}::A{index}")
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        for index, atom in enumerate(phase.atoms()):
            for axis, coordinate, length in zip("xyz", atom.coordinates, lengths):
                half_width = 0.10 / float(length)
                project.set_Controls("parmMin", coordinate - half_width, variable=f"{pid}::dA{axis}:{index}")
                project.set_Controls("parmMax", coordinate + half_width, variable=f"{pid}::dA{axis}:{index}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--skip-settle", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=args.input, newgpx=str(Path(args.output).resolve()))
    hist = max(project.histograms(), key=lambda item: len(item.data["data"][1][0]))
    clear_flags(project, hist)
    install_bounds(project, hist)

    # Negative isotropic microstrain is numerically equivalent in the profile
    # expression but not a physical checkpoint; retain its magnitude.
    for phase in project.phases():
        mustrain = phase.data["Histograms"][hist.name]["Mustrain"]
        if mustrain[0] == "isotropic" and float(mustrain[1][0]) < 0:
            mustrain[1][0] = abs(float(mustrain[1][0]))

    hist.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
    product = project.phase("ZnWO4")
    for atom in product.atoms():
        atom.refinement_flags = "X"
    for pass_index in range(3):
        row = run(project, hist, f"ZnWO4_coordinates_{pass_index + 1}", 10)
        maximum = row["max_shift_esd"]
        if row["converged"] and maximum is not None and float(maximum) <= 1.0 and not row["frozen"]:
            break

    if args.skip_settle:
        clear_flags(project, hist)
        project.save()
        return

    clear_flags(project, hist)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
        phase.set_refinements({"Cell": True})
    run(project, hist, "cell_scale_background_settle", 10)
    clear_flags(project, hist)
    project.save()


if __name__ == "__main__":
    main()
