#!/usr/bin/env python3
"""Print Cu Kalpha1 stick patterns from candidate CIFs."""

import argparse
import warnings

from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure


parser = argparse.ArgumentParser()
parser.add_argument("cif", nargs="+")
parser.add_argument("--minimum", type=float, default=0.5)
args = parser.parse_args()

calculator = XRDCalculator(wavelength=1.540598, symprec=0)
for filename in args.cif:
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        structure = Structure.from_file(filename, primitive=False)
    pattern = calculator.get_pattern(structure, two_theta_range=(9.9, 100.1), scaled=True)
    print(f"===== {filename} {structure.composition.reduced_formula} =====")
    print("2theta\trelative_intensity\thkl")
    for angle, intensity, hkls in zip(pattern.x, pattern.y, pattern.hkls):
        if intensity >= args.minimum:
            labels = ",".join(str(item["hkl"]) for item in hkls)
            print(f"{angle:.5f}\t{intensity:.3f}\t{labels}")
