#!/usr/bin/env python3
"""Inspect a GSAS-II checkpoint and map coherent positive residual peaks."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from scipy.signal import find_peaks, peak_widths
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("gpx")
parser.add_argument("--prefix", default="gpx_diagnostic")
parser.add_argument("--top", type=int, default=100)
args = parser.parse_args()

project = G2.G2Project(gpxfile=args.gpx)
hist = max(project.histograms(), key=lambda item: len(item.data["data"][1][0]))
x, observed, weight, calculated, background, difference = [
    np.asarray(v, dtype=float) for v in hist.data["data"][1][:6]
]
if not np.allclose(difference, observed - calculated):
    difference = observed - calculated

prominence_floor = 5.0 * np.sqrt(np.maximum(observed, 1.0))
peaks, props = find_peaks(difference, prominence=prominence_floor, distance=5)
widths = peak_widths(difference, peaks, rel_height=0.5)[0] * np.median(np.diff(x))
order = np.argsort(props["prominences"])[::-1]

reflections = {}
for phase in project.phases():
    block = hist.data["Reflection Lists"].get(phase.name, {})
    rows = np.asarray(block.get("RefList", []), dtype=float)
    if rows.size:
        reflections[phase.name] = rows

print(f"histogram={hist.name} Rwp={hist.get_wR():.6f}% points={len(x)}")
print("rank\t2theta\tresidual\tprominence\tFWHM\tnearest_modeled_reflection")
for rank, j in enumerate(order[: args.top], 1):
    i = peaks[j]
    nearest = []
    for name, rows in reflections.items():
        k = int(np.argmin(np.abs(rows[:, 5] - x[i])))
        row = rows[k]
        nearest.append((abs(row[5] - x[i]), name, row))
    if nearest:
        delta, name, row = min(nearest, key=lambda item: item[0])
        match = f"{name} {tuple(int(v) for v in row[:3])} {row[5]:.4f} (delta={delta:.4f})"
    else:
        match = "none"
    print(
        f"{rank}\t{x[i]:.5f}\t{difference[i]:.1f}\t{props['prominences'][j]:.1f}\t"
        f"{widths[j]:.4f}\t{match}"
    )

out = Path(args.prefix)
np.savetxt(
    out.with_suffix(".csv"),
    np.column_stack([x, observed, calculated, background, difference]),
    delimiter=",",
    header="two_theta_deg,observed,calculated,background,difference",
    comments="",
)
