#!/usr/bin/env python3
"""Recalculate or settle scales/background after fixing selected HAP values."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear(project, hist):
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
                "Babinet": ["BabA", "BabU"],
            },
            histograms=[hist],
        )
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(project, hist):
    weighted = {
        phase.name: max(0.0, float(phase.data["General"]["Mass"]) * float(phase.data["Histograms"][hist.name]["Scale"][0]))
        for phase in project.phases()
    }
    total = sum(weighted.values())
    return {name: value / total for name, value in weighted.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--phase")
    parser.add_argument("--size", type=float)
    parser.add_argument("--strain", type=float)
    parser.add_argument("--uiso", type=float)
    parser.add_argument("--rough-a", type=float)
    parser.add_argument("--rough-b", type=float)
    parser.add_argument("--cycles", type=int, default=10)
    parser.add_argument("--passes", type=int, default=3)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=args.input, newgpx=str(Path(args.output).resolve()))
    hist = max(project.histograms(), key=lambda item: len(item.data["data"][1][0]))
    clear(project, hist)
    if args.rough_a is not None:
        hist.SampleParameters["SurfRoughA"][0] = float(args.rough_a)
    if args.rough_b is not None:
        hist.SampleParameters["SurfRoughB"][0] = float(args.rough_b)
    if args.phase:
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][hist.name]
        if args.size is not None:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = float(args.size)
            hap["Size"][1][1] = float(args.size)
        if args.strain is not None:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = float(args.strain)
            hap["Mustrain"][1][1] = float(args.strain)
        if args.uiso is not None:
            for atom in phase.atoms():
                if atom.adp_flag != "I":
                    # GSAS-II exposes no public iso/aniso setter; update the
                    # atom record in place, as its GUI does for this switch.
                    atom.data[atom.cia] = "I"
                    atom.data[atom.cia + 1] = float(args.uiso)
                else:
                    atom.uiso = float(args.uiso)

    hist.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])

    for pass_index in range(1, args.passes + 1):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", args.cycles)
        project.save()
        project.refine(makeBack=False)
        project.save()
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        row = {
            "pass": pass_index,
            "Rwp_percent": float(hist.get_wR()),
            "fractions": fractions(project, hist),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": [str(value) for value in project.get_Frozen()],
        }
        print(json.dumps(row), flush=True)
        maximum = row["max_shift_esd"]
        if row["converged"] and maximum is not None and abs(float(maximum)) <= 1.0 and not row["frozen"]:
            break
    clear(project, hist)
    project.save()


if __name__ == "__main__":
    main()
