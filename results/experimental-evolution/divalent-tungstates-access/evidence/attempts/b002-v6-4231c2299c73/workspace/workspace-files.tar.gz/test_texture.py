#!/usr/bin/env python3
"""Screen physically ordinary March-Dollase axes on the dominant phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def clear(project, hist):
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True},
            histograms=[hist],
        )


def fractions(project, hist):
    values = {
        phase.name: max(0.0, float(phase.data["General"]["Mass"]) * float(phase.data["Histograms"][hist.name]["Scale"][0]))
        for phase in project.phases()
    }
    total = sum(values.values())
    return {key: value / total for key, value in values.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("outdir")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    for axis in AXES:
        label = "".join(str(value) for value in axis)
        project = G2.G2Project(gpxfile=args.input, newgpx=str(outdir / f"md_{label}.gpx"))
        hist = max(project.histograms(), key=lambda item: len(item.data["data"][1][0]))
        clear(project, hist)
        project.data["Controls"]["data"]["parmMinDict"] = {}
        project.data["Controls"]["data"]["parmMaxDict"] = {}
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.index_ids()
        product = project.phase("ZnWO4")
        hap = product.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        pid, hid = product.data["pId"], hist.data["data"][0]["hId"]
        project.set_Controls("parmMin", 0.5, variable=f"{pid}:{hid}:MD")
        project.set_Controls("parmMax", 2.0, variable=f"{pid}:{hid}:MD")
        hist.Background[0][1] = True
        for phase in project.phases():
            phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        print(
            json.dumps(
                {
                    "axis": axis,
                    "ratio": float(hap["Pref.Ori."][1]),
                    "Rwp_percent": float(hist.get_wR()),
                    "fractions": fractions(project, hist),
                    "converged": bool(rvals.get("converged", False)),
                    "max_shift_esd": rvals.get("Max shft/sig"),
                    "frozen": [str(value) for value in project.get_Frozen()],
                    "path": project.filename,
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
