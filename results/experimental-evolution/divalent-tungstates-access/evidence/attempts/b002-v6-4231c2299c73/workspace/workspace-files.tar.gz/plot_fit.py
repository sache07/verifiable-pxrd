#!/usr/bin/env python3
"""Plot an inspect_gpx CSV with optional zoom panels."""

import argparse

import matplotlib.pyplot as plt
import numpy as np


parser = argparse.ArgumentParser()
parser.add_argument("csv")
parser.add_argument("png")
args = parser.parse_args()

data = np.loadtxt(args.csv, delimiter=",", skiprows=1)
x, obs, calc, bkg, diff = data.T
fig, axes = plt.subplots(4, 1, figsize=(15, 12), constrained_layout=True)
for ax, bounds in zip(axes[:3], [(10, 100), (10, 45), (45, 100)]):
    use = (x >= bounds[0]) & (x <= bounds[1])
    ax.plot(x[use], obs[use], color="black", lw=0.5)
    ax.plot(x[use], calc[use], color="tab:red", lw=0.65)
    ax.plot(x[use], bkg[use], color="tab:orange", lw=0.55)
    ax.set_xlim(*bounds)
    ax.set_ylabel("Counts")
axes[3].axhline(0, color="0.6", lw=0.5)
axes[3].plot(x, diff, color="tab:blue", lw=0.5)
axes[3].set_xlim(10, 100)
axes[3].set_ylabel("Obs - calc")
axes[3].set_xlabel(r"$2\theta$ (degrees)")
fig.savefig(args.png, dpi=180)
