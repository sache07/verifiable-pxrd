#!/usr/bin/env python3
"""Create and stage a replayable GSAS-II Rietveld checkpoint.

Run with the GSAS-II Python interpreter. Phase arguments have the form
``Name=/absolute/or/relative/model.cif``.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


def mass_fractions(project, hist):
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if not hap or not hap.get("Use", True):
            continue
        weighted[phase.name] = max(
            0.0,
            float(phase.data["General"].get("Mass", 0.0))
            * float(hap["Scale"][0]),
        )
    total = sum(weighted.values())
    if total <= 0:
        return {name: 0.0 for name in weighted}
    return {name: value / total for name, value in weighted.items()}


def state(project, hist, stage):
    result = {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "fractions": mass_fractions(project, hist),
        "instrument": {
            key: float(value[1])
            for key, value in hist.InstrumentParameters.items()
            if key in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."}
            and isinstance(value, list)
            and len(value) > 1
        },
        "sample": {
            key: (float(value[0]) if isinstance(value, list) else value)
            for key, value in hist.SampleParameters.items()
            if key in {"Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"}
        },
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size": hap["Size"][:4],
            "mustrain": hap["Mustrain"][:4],
            "preferred_orientation": hap["Pref.Ori."][:4],
        }
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    result["converged"] = bool(rvals.get("converged", False))
    result["max_shift_esd"] = rvals.get("Max shft/sig")
    print(json.dumps(result, default=lambda value: value.tolist() if hasattr(value, "tolist") else str(value)), flush=True)
    return result


def run(project, hist, stage, cycles=6):
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    return state(project, hist, stage)


def parse_phase(text):
    if "=" not in text:
        raise argparse.ArgumentTypeError("phase must be NAME=PATH")
    name, filename = text.split("=", 1)
    path = Path(filename).resolve()
    if not name or not path.is_file():
        raise argparse.ArgumentTypeError(f"invalid phase argument: {text}")
    return name, path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    parser.add_argument("--data", default="inputs/pattern.csv")
    parser.add_argument("--instrument", default="instrument.instprm")
    parser.add_argument("--phase", action="append", type=parse_phase, required=True)
    parser.add_argument("--background-terms", type=int, default=12)
    parser.add_argument("--stop-after", choices=["scale", "cell", "profile", "sample"], default="sample")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(Path(args.data).resolve()),
        str(Path(args.instrument).resolve()),
        fmthint="comma",
    )
    hist.set_refinements({"Limits": {"low": 10.0, "high": 100.0}})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    phases = []
    for name, path in args.phase:
        phase = project.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
        phases.append(phase)
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0 / max(float(phase.data["General"]["Mass"]), 1.0), False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        phase.set_HAP_refinements({"Scale": True})

    first_background = float(np.percentile(hist.data["data"][1][1], 35))
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_terms,
                "coeffs": [first_background] + [0.0] * (args.background_terms - 1),
                "refine": True,
            }
        }
    )
    run(project, hist, "background_scales", 8)
    if args.stop_after == "scale":
        return

    # A common zero correction is fitted before allowing lattice metrics to move.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run(project, hist, "zero", 8)
    for phase in phases:
        phase.set_refinements({"Cell": True})
    run(project, hist, "cells", 10)
    if args.stop_after == "cell":
        return

    # Let phase-specific broadening absorb specimen effects first. Instrument
    # broadening is then adjusted in a separate, better-conditioned step.
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.5, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    run(project, hist, "phase_profile", 10)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run(project, hist, "instrument_profile", 10)
    if args.stop_after == "profile":
        return

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run(project, hist, "sample_shift", 10)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(json.dumps({"status": "failed", "error": str(exc)}), file=sys.stderr)
        raise
