#!/usr/bin/env python3
"""Compare bounded common-profile branches without phase-profile correlation."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear(project, hist):
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True},
            histograms=[hist],
        )


def fracs(project, hist):
    values = {
        p.name: max(0.0, float(p.data["General"]["Mass"]) * float(p.data["Histograms"][hist.name]["Scale"][0]))
        for p in project.phases()
    }
    total = sum(values.values())
    return {key: value / total for key, value in values.items()}


def run(project, hist, stage):
    for pass_index in range(3):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        row = {
            "stage": stage,
            "pass": pass_index + 1,
            "Rwp_percent": float(hist.get_wR()),
            "fractions": fracs(project, hist),
            "instrument": {k: float(v[1]) for k, v in hist.InstrumentParameters.items() if k in {"U", "W", "X", "SH/L", "Polariz."}},
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": [str(value) for value in project.get_Frozen()],
        }
        print(json.dumps(row), flush=True)
        maximum = row["max_shift_esd"]
        if row["converged"] and maximum is not None and abs(float(maximum)) <= 1 and not row["frozen"]:
            break


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("outdir")
args = parser.parse_args()
G2.SetPrintLevel("warn")
outdir = Path(args.outdir).resolve()
outdir.mkdir(parents=True, exist_ok=True)

for label, forced_u in (("U_current", None), ("U_zero", 0.0)):
    project = G2.G2Project(gpxfile=args.input, newgpx=str(outdir / f"{label}.gpx"))
    hist = max(project.histograms(), key=lambda item: len(item.data["data"][1][0]))
    clear(project, hist)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    if forced_u is not None:
        hist.InstrumentParameters["U"][1] = forced_u
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
    hist.set_refinements({"Instrument Parameters": ["W", "SH/L"]})
    run(project, hist, label + "_profile")
    clear(project, hist)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    run(project, hist, label + "_polarization")
    clear(project, hist)
    project.save()
