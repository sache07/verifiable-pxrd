#!/usr/bin/env python3
"""Add one candidate phase to a stable GSAS-II checkpoint and test it safely."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def clear_flags(project, hist):
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
                "Babinet": ["BabA", "BabU"],
            },
            histograms=[hist],
        )


def fractions(project, hist):
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if hap and hap.get("Use", True):
            weighted[phase.name] = max(
                0.0,
                float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]),
            )
    total = sum(weighted.values())
    return {name: value / total for name, value in weighted.items()} if total else weighted


def report(project, hist, stage):
    row = {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "fractions": fractions(project, hist),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "profiles": {
            phase.name: {
                "size": phase.data["Histograms"][hist.name]["Size"][:4],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"][:4],
            }
            for phase in project.phases()
        },
    }
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    row["converged"] = bool(rvals.get("converged", False))
    row["max_shift_esd"] = rvals.get("Max shft/sig")
    print(json.dumps(row, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x)), flush=True)


def run(project, hist, stage, cycles=8):
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    report(project, hist, stage)


def bound_cell(project, phase, span_fraction=0.015):
    project.index_ids()
    cell = phase.get_cell()
    reciprocal = G2lat.cell2A(
        [
            cell["length_a"],
            cell["length_b"],
            cell["length_c"],
            cell["angle_alpha"],
            cell["angle_beta"],
            cell["angle_gamma"],
        ]
    )
    pid = phase.data["pId"]
    for index, value in enumerate(reciprocal):
        value = float(value)
        span = max(abs(value) * span_fraction, 0.0003)
        project.set_Controls("parmMin", value - span, variable=f"{pid}::A{index}")
        project.set_Controls("parmMax", value + span, variable=f"{pid}::A{index}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--cif", required=True)
    parser.add_argument("--fraction", type=float, required=True)
    parser.add_argument("--skip-profile", action="store_true")
    args = parser.parse_args()

    if not 0 < args.fraction < 0.5:
        raise ValueError("starting fraction must be between zero and 0.5")
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=args.base, newgpx=str(Path(args.out).resolve()))
    hist = max(project.histograms(), key=lambda item: len(item.data["data"][1][0]))
    clear_flags(project, hist)

    existing_weight = sum(
        float(phase.data["General"]["Mass"])
        * max(0.0, float(phase.data["Histograms"][hist.name]["Scale"][0]))
        for phase in project.phases()
    )
    phase = project.add_phase(
        str(Path(args.cif).resolve()),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    phase_mass = float(phase.data["General"]["Mass"])
    starting_weight = existing_weight * args.fraction / (1.0 - args.fraction)
    hap["Scale"] = [starting_weight / phase_mass, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.5
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 500.0
    hap["Mustrain"][1][1] = 500.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]

    project.index_ids()
    pid, hid = phase.data["pId"], hist.data["data"][0]["hId"]
    initial_scale = float(hap["Scale"][0])
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Scale")
    project.set_Controls("parmMax", max(initial_scale * 10.0, 1.0), variable=f"{pid}:{hid}:Scale")
    bound_cell(project, phase)
    project.set_Controls("parmMin", 0.02, variable=f"{pid}:{hid}:Size;i")
    project.set_Controls("parmMax", 10.0, variable=f"{pid}:{hid}:Size;i")
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;i")
    project.set_Controls("parmMax", 20000.0, variable=f"{pid}:{hid}:Mustrain;i")

    phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
    run(project, hist, "new_scale", 8)
    phase.set_refinements({"Cell": True})
    run(project, hist, "new_cell_scale", 10)
    hist.set_refinements({"Background": True})
    for item in project.phases():
        item.set_HAP_refinements({"Scale": True}, histograms=[hist])
    run(project, hist, "all_scales_background", 8)
    if args.skip_profile:
        return
    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": 0.5, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        histograms=[hist],
    )
    run(project, hist, "new_profile", 10)


if __name__ == "__main__":
    main()
