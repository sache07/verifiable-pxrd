#!/usr/bin/env python3
"""Repeat the active GSAS-II refinement flags to numerical convergence."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("--cycles", type=int, default=10)
parser.add_argument("--passes", type=int, default=3)
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=args.input, newgpx=str(Path(args.output).resolve()))
hist = max(project.histograms(), key=lambda item: len(item.data["data"][1][0]))
for pass_index in range(args.passes):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", args.cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    row = {
        "pass": pass_index + 1,
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(value) for value in project.get_Frozen()],
    }
    print(json.dumps(row), flush=True)
    maximum = row["max_shift_esd"]
    if row["converged"] and maximum is not None and abs(float(maximum)) <= 1.0 and not row["frozen"]:
        break
