#!/usr/bin/env python3
"""Refine bounded specimen displacement/zero and optional phase profiles."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_flags(project, hist):
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
                "Babinet": ["BabA", "BabU"],
            },
            histograms=[hist],
        )
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def enable_scale_background(project, hist):
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])


def fractions(project, hist):
    weighted = {
        phase.name: max(
            0.0,
            float(phase.data["General"]["Mass"])
            * float(phase.data["Histograms"][hist.name]["Scale"][0]),
        )
        for phase in project.phases()
    }
    total = sum(weighted.values())
    return {name: value / total for name, value in weighted.items()}


def summarize(project, hist, stage, pass_index):
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": stage,
        "pass": pass_index,
        "Rwp_percent": float(hist.get_wR()),
        "fractions": fractions(project, hist),
        "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(value) for value in project.get_Frozen()],
        "profiles": {
            phase.name: {
                "size": phase.data["Histograms"][hist.name]["Size"][:4],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"][:4],
            }
            for phase in project.phases()
        },
    }


def run(project, hist, stage, passes=3):
    row = None
    for pass_index in range(1, passes + 1):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        row = summarize(project, hist, stage, pass_index)
        print(json.dumps(row, default=lambda value: value.tolist() if hasattr(value, "tolist") else str(value)), flush=True)
        maximum = row["max_shift_esd"]
        if row["converged"] and maximum is not None and abs(float(maximum)) <= 1.0 and not row["frozen"]:
            break
        if row["frozen"]:
            break
    return row


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--zero-start", type=float, default=0.0)
    parser.add_argument("--shift-start", type=float, default=-700.0)
    parser.add_argument("--phase-profile", choices=["ZnWO4", "WO3", "ZnO"])
    parser.add_argument("--profile-mode", choices=["both", "size", "strain"], default="both")
    parser.add_argument("--uniaxial-axis", choices=["001", "100", "010"])
    parser.add_argument("--cells", action="store_true")
    parser.add_argument("--shift-only", action="store_true")
    parser.add_argument("--skip-calibration", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    project = G2.G2Project(gpxfile=args.input, newgpx=str(output))
    hist = max(project.histograms(), key=lambda item: len(item.data["data"][1][0]))
    project.index_ids()
    hid = int(hist.data["data"][0]["hId"])
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("parmMin", -0.25, variable=f":{hid}:Zero")
    project.set_Controls("parmMax", 0.25, variable=f":{hid}:Zero")
    project.set_Controls("parmMin", -800.0, variable=f":{hid}:Shift")
    project.set_Controls("parmMax", 800.0, variable=f":{hid}:Shift")

    if not args.skip_calibration:
        clear_flags(project, hist)
        hist.InstrumentParameters["Zero"][1] = float(args.zero_start)
        hist.SampleParameters["Shift"][0] = float(args.shift_start)
        enable_scale_background(project, hist)
        if args.shift_only:
            hist.set_refinements({"Sample Parameters": ["Shift"]})
            run(project, hist, "shift_at_fixed_zero")
        else:
            hist.set_refinements({"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]})
            run(project, hist, "zero_shift")

    if args.phase_profile:
        clear_flags(project, hist)
        enable_scale_background(project, hist)
        phase = project.phase(args.phase_profile)
        refinements = {}
        if args.profile_mode in {"both", "size"}:
            refinements["Size"] = {"type": "isotropic", "refine": True}
        if args.profile_mode in {"both", "strain"}:
            if args.uniaxial_axis:
                refinements["Mustrain"] = {
                    "type": "uniaxial",
                    "direction": [int(value) for value in args.uniaxial_axis],
                    "refine": True,
                }
            else:
                refinements["Mustrain"] = {"type": "isotropic", "refine": True}
        phase.set_HAP_refinements(refinements, histograms=[hist])
        pid = int(phase.data["pId"])
        project.set_Controls("parmMin", 0.02, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 5.0, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 20000.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;a")
        project.set_Controls("parmMax", 20000.0, variable=f"{pid}:{hid}:Mustrain;a")
        run(project, hist, "profile_" + args.phase_profile)

    if args.cells:
        clear_flags(project, hist)
        enable_scale_background(project, hist)
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
        run(project, hist, "cell_settle")

    clear_flags(project, hist)
    project.save()


if __name__ == "__main__":
    main()
