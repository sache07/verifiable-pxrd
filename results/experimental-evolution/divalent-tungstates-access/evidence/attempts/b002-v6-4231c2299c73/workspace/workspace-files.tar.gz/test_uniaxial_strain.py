#!/usr/bin/env python3
"""Compare physically allowed uniaxial microstrain axes for one phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear(project, hist):
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True, "HStrain": True},
            histograms=[hist],
        )
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(project, hist):
    weighted = {
        phase.name: max(0.0, float(phase.data["General"]["Mass"]) * float(phase.data["Histograms"][hist.name]["Scale"][0]))
        for phase in project.phases()
    }
    total = sum(weighted.values())
    return {name: value / total for name, value in weighted.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("outdir")
    parser.add_argument("--phase", default="WO3")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    for axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0]):
        label = "".join(str(item) for item in axis)
        project = G2.G2Project(gpxfile=args.input, newgpx=str(outdir / f"axis_{label}.gpx"))
        hist = max(project.histograms(), key=lambda item: len(item.data["data"][1][0]))
        clear(project, hist)
        project.index_ids()
        hid = int(hist.data["data"][0]["hId"])
        phase = project.phase(args.phase)
        pid = int(phase.data["pId"])
        hap = phase.data["Histograms"][hist.name]
        start = max(0.0, float(hap["Mustrain"][1][0]))
        hap["Mustrain"][1][0] = start
        hap["Mustrain"][1][1] = start
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}},
            histograms=[hist],
        )
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 20000.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;a")
        project.set_Controls("parmMax", 20000.0, variable=f"{pid}:{hid}:Mustrain;a")
        hist.Background[0][1] = True
        for item in project.phases():
            item.set_HAP_refinements({"Scale": True}, histograms=[hist])

        for pass_index in range(1, 4):
            project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
            project.set_Controls("cycles", 10)
            project.save()
            project.refine(makeBack=False)
            project.save()
            rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
            row = {
                "axis": axis,
                "pass": pass_index,
                "Rwp_percent": float(hist.get_wR()),
                "fractions": fractions(project, hist),
                "mustrain": hap["Mustrain"][:4],
                "converged": bool(rvals.get("converged", False)),
                "max_shift_esd": rvals.get("Max shft/sig"),
                "frozen": [str(value) for value in project.get_Frozen()],
            }
            print(json.dumps(row), flush=True)
            maximum = row["max_shift_esd"]
            if row["converged"] and maximum is not None and abs(float(maximum)) <= 1.0 and not row["frozen"]:
                break
            if row["frozen"]:
                break
        clear(project, hist)
        project.save()


if __name__ == "__main__":
    main()
