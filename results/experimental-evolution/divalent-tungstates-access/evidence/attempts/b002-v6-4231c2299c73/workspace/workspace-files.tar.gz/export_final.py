#!/usr/bin/env python3
"""Export all submission artifacts from the accepted final GSAS-II project."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PROJECT_PATH = ROOT / "final.gpx"
REPLAY_DIR = ROOT / "work" / "replay"


def main():
    project_hash = hashlib.sha256(PROJECT_PATH.read_bytes()).hexdigest()
    replay = json.loads((REPLAY_DIR / "replay.json").read_text())
    if replay.get("status") != "replayed":
        raise RuntimeError("final.gpx did not pass the fresh forward replay")
    if replay.get("project_sha256") != project_hash:
        raise RuntimeError("replay was not generated from the current final.gpx")

    project = G2.G2Project(gpxfile=str(PROJECT_PATH))
    hist = project.histogram(replay["histogram"])
    if hist is None:
        raise RuntimeError("replayed histogram is missing from final.gpx")

    weighted = {
        phase.name: float(phase.data["General"]["Mass"])
        * float(phase.data["Histograms"][hist.name]["Scale"][0])
        for phase in project.phases()
    }
    total = sum(weighted.values())
    fractions = {name: value / total for name, value in weighted.items()}
    replay_fractions = {row["name"]: float(row["weight_fraction"]) for row in replay["phases"]}
    if set(fractions) != set(replay_fractions) or any(
        abs(fractions[name] - replay_fractions[name]) > 1e-12 for name in fractions
    ):
        raise RuntimeError("phase fractions disagree with the verified replay")

    fraction_esds = {}
    try:
        computed = hist.ComputeMassFracs()
        fraction_esds = {
            str(name): float(value[1])
            for name, value in computed.items()
            if len(value) > 1 and np.isfinite(value[1]) and value[1] >= 0
        }
    except (KeyError, TypeError, ValueError, IndexError):
        fraction_esds = {}

    filenames = {"ZnWO4": "ZnWO4.cif", "WO3": "WO3.cif", "ZnO": "ZnO.cif"}
    # Export the saved atomic records, not values cached in a covariance block.
    project.data.setdefault("Covariance", {}).setdefault("data", {}).clear()
    phase_rows = []
    for phase in project.phases():
        filename = filenames.get(phase.name, phase.name.replace(" ", "_") + ".cif")
        phase.export_CIF(str(ROOT / filename))
        row = {
            "name": phase.name,
            "cif_path": filename,
            "weight_fraction": fractions[phase.name],
        }
        if phase.name in fraction_esds:
            row["weight_fraction_esd"] = fraction_esds[phase.name]
        general = phase.data["General"]
        row["space_group"] = str(general["SGData"]["SpGrp"])
        phase_rows.append(row)

    with np.load(REPLAY_DIR / "prediction.npz", allow_pickle=False) as archive:
        x = np.asarray(archive["x"], dtype=float)
        observed = np.asarray(archive["observed"], dtype=float)
        calculated = np.asarray(archive["predicted"], dtype=float)
        background = np.asarray(archive["background"], dtype=float)
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, observed, calculated, background, difference]),
        delimiter=",",
        header="two_theta,observed,calculated,background,difference",
        comments="",
        fmt="%.12g",
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    weighted_chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(weighted_chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
    result = {
        "phases": phase_rows,
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "weighted_chi_square": weighted_chi_square,
            "weighted_chi_square_per_point": weighted_chi_square / len(observed),
            "n_points": int(len(observed)),
            "gpx_saved_rwp_percent": float(hist.get_wR()),
            "profile_source": "fresh zero-parameter GSAS-II replay of final.gpx over the full measured grid",
        },
        "refinement_histogram": hist.name,
        "project_path": "final.gpx",
        "project_sha256": project_hash,
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
