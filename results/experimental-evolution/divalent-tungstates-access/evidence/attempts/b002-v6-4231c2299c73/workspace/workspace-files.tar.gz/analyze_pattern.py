#!/usr/bin/env python3
"""Quick peak/background diagnostics for the supplied powder pattern."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import percentile_filter, gaussian_filter1d
from scipy.signal import find_peaks, peak_widths


data = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
x, y = data.T

# A wide lower-percentile filter gives a deliberately conservative local
# background estimate; smooth it only enough to remove filter stair-steps.
background = gaussian_filter1d(percentile_filter(y, percentile=18, size=501), 80)
signal = y - background
noise = np.sqrt(np.maximum(background, 1.0))
peaks, props = find_peaks(signal, prominence=5.0 * noise, distance=8)
widths = peak_widths(signal, peaks, rel_height=0.5)[0] * np.median(np.diff(x))

order = np.argsort(props["prominences"])[::-1]
print(f"points={len(x)} range={x[0]:.6f}..{x[-1]:.6f} step={np.median(np.diff(x)):.7f}")
print(f"counts min/median/max={y.min():.0f}/{np.median(y):.0f}/{y.max():.0f}")
print("rank\t2theta_deg\tcounts\tnet\tprominence\tFWHM_deg")
for rank, j in enumerate(order[:120], 1):
    i = peaks[j]
    print(
        f"{rank}\t{x[i]:.5f}\t{y[i]:.0f}\t{signal[i]:.1f}\t"
        f"{props['prominences'][j]:.1f}\t{widths[j]:.4f}"
    )

fig, axes = plt.subplots(2, 1, figsize=(14, 8), sharex=True)
axes[0].plot(x, y, lw=0.65, color="black")
axes[0].plot(x, background, lw=1.0, color="tab:orange")
axes[0].set_ylabel("Counts")
axes[1].plot(x, signal, lw=0.65, color="tab:blue")
axes[1].scatter(x[peaks], signal[peaks], s=8, color="tab:red")
axes[1].set_ylabel("Counts above background")
axes[1].set_xlabel(r"$2\theta$ (degrees)")
fig.tight_layout()
fig.savefig("pattern_diagnostic.png", dpi=180)
