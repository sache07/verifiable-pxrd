#!/usr/bin/env python3
"""Complete ordinary bounded profile, cell and calibration refinement stages."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def clear_flags(project, hist):
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
                "Babinet": ["BabA", "BabU"],
            },
            histograms=[hist],
        )


def fractions(project, hist):
    weighted = {
        phase.name: max(
            0.0,
            float(phase.data["General"]["Mass"])
            * float(phase.data["Histograms"][hist.name]["Scale"][0]),
        )
        for phase in project.phases()
    }
    total = sum(weighted.values())
    return {name: value / total for name, value in weighted.items()}


def summary(project, hist, stage):
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    row = {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "fractions": fractions(project, hist),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(value) for value in project.get_Frozen()],
        "instrument": {
            key: float(value[1])
            for key, value in hist.InstrumentParameters.items()
            if key in {"Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}
            and isinstance(value, list)
            and len(value) > 1
        },
        "sample": {
            key: (float(value[0]) if isinstance(value, list) else value)
            for key, value in hist.SampleParameters.items()
            if key in {"Shift", "Transparency", "SurfRoughA", "SurfRoughB"}
        },
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        row["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "size": hap["Size"][:4],
            "mustrain": hap["Mustrain"][:4],
            "preferred_orientation": hap["Pref.Ori."][:4],
        }
    return row


def run(project, hist, stage, checkpoint_root, cycles=10, passes=3):
    row = None
    for pass_index in range(passes):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", cycles)
        project.save()
        project.refine(makeBack=False)
        project.save()
        row = summary(project, hist, f"{stage}_{pass_index + 1}")
        print(json.dumps(row, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x)), flush=True)
        maximum = row["max_shift_esd"]
        if row["converged"] and maximum is not None and abs(float(maximum)) <= 1.0 and not row["frozen"]:
            break
        if row["frozen"]:
            break
    shutil.copy2(project.filename, checkpoint_root.with_name(checkpoint_root.name + f".{stage}.gpx"))
    return row


def install_bounds(project, hist):
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    project.index_ids()
    hid = hist.data["data"][0]["hId"]
    for phase in project.phases():
        pid = phase.data["pId"]
        hap = phase.data["Histograms"][hist.name]
        scale = max(float(hap["Scale"][0]), 0.0)
        project.set_Controls("parmMin", max(0.25 * scale, 0.0), variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMax", max(4.0 * scale, 1.0), variable=f"{pid}:{hid}:Scale")
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A(
            [
                cell["length_a"], cell["length_b"], cell["length_c"],
                cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
            ]
        )
        for index, value in enumerate(reciprocal):
            value = float(value)
            span = max(0.01 * abs(value), 0.0003)
            project.set_Controls("parmMin", value - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", value + span, variable=f"{pid}::A{index}")
        project.set_Controls("parmMin", 0.02, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 5.0, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 20000.0, variable=f"{pid}:{hid}:Mustrain;i")
    for name, low, high in (
        ("Zero", -1.0, 1.0),
        ("Polariz.", 0.3, 1.0),
        ("U", 0.0, 100.0),
        ("W", 0.0, 100.0),
        ("X", 0.0, 10.0),
        ("SH/L", 0.001, 0.2),
    ):
        project.set_Controls("parmMin", low, variable=f":{hid}:{name}")
        project.set_Controls("parmMax", high, variable=f":{hid}:{name}")


def enable_scale_background(project, hist):
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    project = G2.G2Project(gpxfile=args.input, newgpx=str(output))
    hist = max(project.histograms(), key=lambda item: len(item.data["data"][1][0]))
    clear_flags(project, hist)
    for phase in project.phases():
        mustrain = phase.data["Histograms"][hist.name]["Mustrain"]
        if mustrain[0] == "isotropic" and float(mustrain[1][0]) < 0:
            mustrain[1][0] = abs(float(mustrain[1][0]))
    install_bounds(project, hist)

    enable_scale_background(project, hist)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run(project, hist, "cells", output)

    clear_flags(project, hist)
    enable_scale_background(project, hist)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run(project, hist, "zero_cells", output)

    for phase_name in ("ZnWO4", "WO3", "ZnO"):
        clear_flags(project, hist)
        enable_scale_background(project, hist)
        phase = project.phase(phase_name)
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            histograms=[hist],
        )
        run(project, hist, f"profile_{phase_name}", output)

    clear_flags(project, hist)
    enable_scale_background(project, hist)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "SH/L"]})
    run(project, hist, "instrument_profile", output)

    clear_flags(project, hist)
    enable_scale_background(project, hist)
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    run(project, hist, "polarization", output)

    clear_flags(project, hist)
    project.save()


if __name__ == "__main__":
    main()
