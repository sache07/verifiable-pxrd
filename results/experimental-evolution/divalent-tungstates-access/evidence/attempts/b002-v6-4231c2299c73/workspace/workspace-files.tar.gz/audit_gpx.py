#!/usr/bin/env python3
"""Report phase composition, atom parameters and broad nearest-neighbor geometry."""

import argparse
import json

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIstrMain as G2st


parser = argparse.ArgumentParser()
parser.add_argument("gpx")
args = parser.parse_args()

project = G2.G2Project(gpxfile=args.gpx)
for phase in project.phases():
    controls, data = phase.InitDisAgl(False)
    controls["Factors"] = [1.25, 0.0]
    _, distances, _ = G2st.RetDistAngle(controls, data, dmin=0.01)
    atoms = phase.atoms()
    pair_minima = {}
    coordination = {}
    for center, rows in distances.items():
        coordination[atoms[center].label] = []
        for row in rows:
            other = int(row[0])
            pair = "-".join(sorted((atoms[center].element, atoms[other].element)))
            distance = float(row[-2])
            pair_minima[pair] = min(pair_minima.get(pair, distance), distance)
            coordination[atoms[center].label].append(
                {"other": atoms[other].label, "distance_A": distance}
            )
    print(
        json.dumps(
            {
                "phase": phase.name,
                "cell": phase.get_cell(),
                "mass": phase.data["General"].get("Mass"),
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": atom.coordinates,
                        "occupancy": atom.occupancy,
                        "adp_flag": atom.adp_flag,
                        "ADP": atom.ADP,
                        "refinement_flags": atom.refinement_flags,
                    }
                    for atom in atoms
                ],
                "pair_min_A": pair_minima,
                "coordination": coordination,
                "catastrophic_contacts": phase.ShortDistances(useAll=False),
            },
            default=lambda value: value.tolist() if hasattr(value, "tolist") else str(value),
        )
    )
