#!/usr/bin/env python3
"""Freeze the selected project and export all requested scientific artifacts."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/calibration_test.gpx")
FINAL = Path("final.gpx")
CIF_NAMES = ["phase_CaWO4.cif", "phase_WO3.cif", "phase_CaCO3.cif"]


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE), newgpx=str(FINAL.resolve()))
    hist = project.histogram(0)

    # Preserve the selected values but leave no accidental next-step flags or
    # stale temporary equivalence constraints in the submitted project.
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    project.data["Constraints"]["data"]["Phase"] = []
    project.set_Frozen()
    project.save()

    for phase, filename in zip(project.phases(), CIF_NAMES):
        phase.export_CIF(filename)

    arrays = [np.asarray(v, float) for v in hist.data["data"][1]]
    x, observed, _, calculated = arrays[:4]
    np.savetxt(
        "fit.csv",
        np.column_stack([x, observed, calculated, observed - calculated]),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )

    fractions = hist.ComputeMassFracs()
    residuals = hist.residuals
    summary = {
        "histogram": hist.name,
        "residuals": residuals,
        "fractions": {k: [float(v[0]), float(v[1])] for k, v in fractions.items()},
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items() if isinstance(v, list) and len(v) > 1},
        "sample": {k: hist.SampleParameters[k] for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "cifs": CIF_NAMES,
    }
    Path(".tmp/final_summary.json").write_text(json.dumps(summary, indent=2, default=float) + "\n")
    print(json.dumps(summary, indent=2, default=float))


if __name__ == "__main__":
    main()
