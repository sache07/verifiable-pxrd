#!/usr/bin/env python3
"""Screen the generator-supported uniaxial microstrain directions."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    G2.SetPrintLevel("warn")
    axes = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])
    rows = []
    for pidx in (0, 1):
        for axis in axes:
            tag = f"strain_p{pidx}_{axis[0]}{axis[1]}{axis[2]}"
            out = Path(f".tmp/{tag}.gpx").resolve()
            project = G2.G2Project(".tmp/ca_coords.gpx", newgpx=str(out))
            hist = project.histogram(0)
            for phase in project.phases():
                phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})
                phase.clear_HAP_refinements({"Mustrain": True})
            phase = project.phases()[pidx]
            hap = phase.data["Histograms"][hist.name]["Mustrain"]
            iso = float(hap[1][0])
            hap[0] = "uniaxial"
            hap[1][0] = iso
            hap[1][1] = iso
            hap[2][0] = True
            hap[2][1] = True
            hap[3] = list(axis)
            for suffix in ("i", "a"):
                project.set_Controls("parmMin", 0.0, f"{pidx}:0:Mustrain;{suffix}")
                project.set_Controls("parmMax", 8000.0, f"{pidx}:0:Mustrain;{suffix}")
            project.set_Frozen()
            project.set_Controls("cycles", 10)
            project.refine(makeBack=False)
            project.save()
            values = phase.data["Histograms"][hist.name]["Mustrain"][1][:2]
            row = (hist.get_wR(), pidx, list(axis), list(values), str(out))
            rows.append(row)
            print(row)
    print("ranking")
    for row in sorted(rows):
        print(row)


if __name__ == "__main__":
    main()
