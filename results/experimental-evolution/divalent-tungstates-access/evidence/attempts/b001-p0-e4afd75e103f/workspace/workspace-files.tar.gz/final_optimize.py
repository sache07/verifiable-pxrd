#!/usr/bin/env python3
"""Final staged three-phase refinement with correlated blocks separated."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2


def lim(project, name, low, high):
    project.set_Controls("parmMin", low, name)
    project.set_Controls("parmMax", high, name)


def report(project, label):
    hist = project.histogram(0)
    print("\n", label, "Rwp", hist.get_wR(), "fractions", hist.ComputeMassFracs())
    print("instrument", {k: v[1] for k, v in hist.InstrumentParameters.items() if k in {"Zero", "Polariz.", "U", "V", "W", "X", "SH/L"}})
    print("shift", hist.SampleParameters["Shift"])
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, phase.get_cell(), "size", hap["Size"], "strain", hap["Mustrain"])


def clear_atoms(project):
    for phase in project.phases():
        phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})


def main():
    G2.SetPrintLevel("warn")
    out = Path(".tmp/final_model.gpx").resolve()
    project = G2.G2Project(".tmp/three_phase.gpx", newgpx=str(out))
    hist = project.histogram(0)
    phases = project.phases()
    clear_atoms(project)
    project.set_Controls("cycles", 12)

    # Re-register peak positions after adding the third phase, while the
    # common zero and specimen shift remain fixed.
    for phase in phases:
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_refinements({"Cell": True})
    project.set_Frozen()
    project.refine(makeBack=False)
    report(project, "cells")

    for phase in phases:
        phase.clear_refinements({"Cell": True})
    # Refine phase widths with the common instrument profile held fixed.
    phases[0].set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "uniaxial", "direction": [1, 0, 0], "refine": True},
    })
    phases[1].set_HAP_refinements({
        "Mustrain": {"type": "uniaxial", "direction": [1, 1, 0], "refine": True},
    })
    phases[2].set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    })
    for pidx in (0, 2):
        lim(project, f"{pidx}:0:Size;i", 0.04, 1.5)
    for pidx, suffixes in ((0, ("i", "a")), (1, ("i", "a")), (2, ("i",))):
        for suffix in suffixes:
            lim(project, f"{pidx}:0:Mustrain;{suffix}", 0.0, 8000.0)
    project.set_Frozen()
    project.refine(makeBack=False)
    report(project, "phase profiles")

    for phase in phases:
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for name, low, high in (("U", 0.0, 40.0), ("W", 2.0, 40.0), ("X", 0.1, 6.0), ("SH/L", 0.005, 0.10)):
        lim(project, f":0:{name}", low, high)
    project.set_Frozen()
    project.refine(makeBack=False)
    report(project, "instrument profile")

    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.set_Frozen()
    project.refine(makeBack=False)
    for phase in phases:
        phase.clear_refinements({"Cell": True})
    report(project, "final cells")
    project.save()


if __name__ == "__main__":
    main()
