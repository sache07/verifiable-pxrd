#!/usr/bin/env python3
"""Decouple strongly correlated calibration, instrument and phase widths."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2


def limit(project, variable, low, high):
    project.set_Controls("parmMin", low, variable)
    project.set_Controls("parmMax", high, variable)


def status(project, label):
    hist = project.histogram(0)
    print("\n", label, "Rwp", hist.get_wR(), "mass", hist.ComputeMassFracs())
    print({k: v[1] for k, v in hist.InstrumentParameters.items() if k in {"Zero", "Polariz.", "U", "V", "W", "X", "SH/L"}})
    print("Shift", hist.SampleParameters["Shift"])
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, phase.get_cell(), "size", hap["Size"][1], "strain", hap["Mustrain"][1], "PO", hap["Pref.Ori."])


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(".tmp/final_work.gpx", newgpx=str(Path(".tmp/stable.gpx").resolve()))
    hist = project.histogram(0)
    phases = project.phases()
    project.set_Controls("cycles", 12)

    # Peak positions are already well determined with plausible source-relative
    # cell shifts. Fix the correlated cell/zero/specimen-displacement block.
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.clear_refinements({"Sample Parameters": ["Shift"]})

    inst = hist.InstrumentParameters
    inst["U"][1], inst["W"][1], inst["X"][1], inst["SH/L"][1] = 15.0, 10.0, 3.0, 0.03
    phases[0].data["Histograms"][hist.name]["Size"][1][0] = 0.10
    phases[1].data["Histograms"][hist.name]["Size"][1][0] = 1.0
    for variable, lo, hi in [
        (":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0), (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10), (":0:Polariz.", 0.5, 1.0),
        ("0:0:Size;i", 0.04, 1.5), ("1:0:Size;i", 0.04, 1.5),
        ("0:0:Mustrain;i", 0.0, 8000.0), ("1:0:Mustrain;i", 0.0, 8000.0),
    ]:
        limit(project, variable, lo, hi)
    project.set_Frozen()
    project.refine(makeBack=False)
    status(project, "instrument only")

    # Hold the common instrument profile while determining phase broadening.
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    project.set_Frozen()
    for phase in phases:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    project.refine(makeBack=False)
    status(project, "phase profiles")

    # Determine polarization after widths. Keep all peak-position and width
    # parameters fixed so this step is intensity-only.
    for phase in phases:
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Frozen()
    project.refine(makeBack=False)
    status(project, "polarization")

    project.save()


if __name__ == "__main__":
    main()
