#!/usr/bin/env python3
"""Build and refine a two-phase GSAS-II candidate project.

Run with the GSAS-II Python interpreter. The script is intentionally kept as a
diagnostic driver: final export is handled separately after model selection.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def initial_background(x: np.ndarray, y: np.ndarray, count: int = 24) -> list[float]:
    """Estimate smooth values at GSAS-II's log-interpolation knots."""
    knots = np.exp(np.linspace(np.log(x[0]), np.log(x[-1]), count))
    values = []
    for i, knot in enumerate(knots):
        left = knots[max(0, i - 1)]
        right = knots[min(count - 1, i + 1)]
        half_width = max(0.28, 0.38 * (right - left))
        local = y[np.abs(x - knot) <= half_width]
        if len(local) < 10:
            local = y[np.argsort(np.abs(x - knot))[:30]]
        # The lower quartile is robust to sharp Bragg peaks; compensate the
        # small negative Poisson bias by adding half a standard deviation.
        q = float(np.quantile(local, 0.22))
        values.append(max(1.0, q + 0.5 * np.sqrt(max(q, 1.0))))
    return values


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    result = {
        "step": label,
        "residuals": hist.residuals,
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items() if isinstance(v, list) and len(v) > 1},
        "sample": {
            k: (v[0] if isinstance(v, list) else v)
            for k, v in hist.SampleParameters.items()
            if k in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"}
        },
        "phases": {},
    }
    try:
        result["mass_fractions"] = {
            k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()
        }
    except Exception as exc:  # covariance may not yet exist after a failed trial
        result["mass_fraction_error"] = str(exc)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"][1],
            "mustrain": hap["Mustrain"][1],
            "preferred_orientation": hap["Pref.Ori."],
        }
    print(json.dumps(result, indent=2, default=float), flush=True)
    return result


def refine(project: G2.G2Project, label: str, history: list[dict]) -> None:
    project.refine(makeBack=False)
    history.append(snapshot(project, label))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_id")
    parser.add_argument("output", type=Path)
    parser.add_argument("--background", type=int, default=24)
    parser.add_argument("--screen", action="store_true")
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(args.output.resolve()))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [450.0, False]

    x, y = (np.asarray(a, float) for a in hist.data["data"][1][:2])
    coeffs = initial_background(x, y, args.background)
    hist.set_refinements(
        {
            "Background": {
                "type": "log interpolate",
                "no. coeffs": args.background,
                "coeffs": coeffs,
                "refine": True,
            }
        }
    )

    phases = [
        project.add_phase(str(cod_path("7219229")), phasename="CaWO4_scheelite", histograms=[hist], fmthint="CIF"),
        project.add_phase(str(cod_path(args.wo3_id)), phasename=f"WO3_{args.wo3_id}", histograms=[hist], fmthint="CIF"),
    ]
    for phase, scale in zip(phases, [1.0, 0.18]):
        for atom in phase.atoms():
            atom.uiso = 0.005
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:2] = [0.3, 0.3]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:2] = [1000.0, 1000.0]

    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    history: list[dict] = []

    refine(project, "background_scales", history)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "cells_zero", history)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, "instrument_profile", history)

    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.3, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    refine(project, "phase_profiles", history)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "sample_shift", history)

    if args.screen:
        project.save()
        args.output.with_suffix(".summary.json").write_text(json.dumps(history, indent=2, default=float) + "\n")
        return

    # Coordinate perturbations are part of the synthetic specimen model. Start
    # with positions only; displacement parameters are evaluated later after
    # candidate selection to avoid phase-ID comparisons being driven by overfit.
    for phase in phases:
        phase.set_refinements({"Atoms": {"all": "X"}})
    refine(project, "atomic_coordinates", history)

    project.save()
    args.output.with_suffix(".summary.json").write_text(json.dumps(history, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
