#!/usr/bin/env python3
"""Evaluate bounded displacement, surface and texture intensity terms."""

from __future__ import annotations

from pathlib import Path

from GSASII import GSASIIscriptable as G2


def lim(project, name, lo, hi):
    project.set_Controls("parmMin", lo, name)
    project.set_Controls("parmMax", hi, name)


def line(project, tag):
    hist = project.histogram(0)
    print(tag, "Rwp", hist.get_wR(), "fractions", hist.ComputeMassFracs())
    print("Uiso", [[a.uiso for a in p.atoms()] for p in project.phases()])
    print("surface", hist.SampleParameters["SurfRoughA"], hist.SampleParameters["SurfRoughB"])
    print("PO", [p.data["Histograms"][hist.name]["Pref.Ori."][:4] for p in project.phases()])


def uiso_project():
    out = Path(".tmp/uiso.gpx").resolve()
    project = G2.G2Project(".tmp/stable.gpx", newgpx=str(out))
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Controls("cycles", 12)
    for pidx, phase in enumerate(project.phases()):
        vars_ = []
        for aidx, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "U"
            name = f"{pidx}::AUiso:{aidx}"
            vars_.append(name)
            lim(project, name, 0.003, 0.020)
        if len(vars_) > 1:
            project.add_EquivConstr(vars_, reloadIdx=True)
    project.set_Frozen()
    project.refine(makeBack=False)
    project.save()
    line(project, "common Uiso")
    return out


def roughness(source):
    out = Path(".tmp/roughness.gpx").resolve()
    project = G2.G2Project(str(source), newgpx=str(out))
    hist = project.histogram(0)
    # Fix Uiso at the previous optimum for a clean two-parameter test.
    for phase in project.phases():
        phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})
    hist.SampleParameters["SurfRoughA"] = [0.5, True]
    hist.SampleParameters["SurfRoughB"] = [0.10, True]
    lim(project, ":0:SurfRoughA", 0.05, 1.0)
    lim(project, ":0:SurfRoughB", 0.001, 0.50)
    project.set_Frozen()
    project.refine(makeBack=False)
    project.save()
    line(project, "surface roughness")
    return out


def texture_screens(source):
    axes = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])
    results = []
    for pidx in (0, 1):
        for axis in axes:
            tag = f"po_p{pidx}_{axis[0]}{axis[1]}{axis[2]}"
            out = Path(f".tmp/{tag}.gpx").resolve()
            project = G2.G2Project(str(source), newgpx=str(out))
            hist = project.histogram(0)
            for phase in project.phases():
                phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})
                phase.clear_HAP_refinements({"Pref.Ori.": True})
            hap = project.phases()[pidx].data["Histograms"][hist.name]["Pref.Ori."]
            hap[0], hap[1], hap[2], hap[3] = "MD", 1.0, True, list(axis)
            lim(project, f"{pidx}:0:MD", 0.7, 1.4)
            project.set_Frozen()
            project.set_Controls("cycles", 10)
            project.refine(makeBack=False)
            project.save()
            ratio = project.phases()[pidx].data["Histograms"][hist.name]["Pref.Ori."][1]
            results.append((hist.get_wR(), pidx, list(axis), ratio, str(out)))
            print("texture", pidx, axis, "Rwp", hist.get_wR(), "ratio", ratio)
    print("texture ranking")
    for row in sorted(results):
        print(row)


def main():
    G2.SetPrintLevel("warn")
    uiso = uiso_project()
    roughness(uiso)
    texture_screens(uiso)


if __name__ == "__main__":
    main()
