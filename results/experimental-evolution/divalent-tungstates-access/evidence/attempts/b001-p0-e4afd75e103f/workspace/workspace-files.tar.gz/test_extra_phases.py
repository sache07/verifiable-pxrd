#!/usr/bin/env python3
"""Scale-only tests for chemically plausible omitted crystalline phases."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif(cod_id):
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main():
    G2.SetPrintLevel("warn")
    candidates = [("calcite_CaCO3", "1547347"), ("CaO", "1563196"), ("Ca3WO6", "1563081")]
    for name, cod_id in candidates:
        out = Path(f".tmp/test_{name}.gpx").resolve()
        project = G2.G2Project(".tmp/strain_both.gpx", newgpx=str(out))
        hist = project.histogram(0)
        for phase in project.phases():
            phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})
            phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase = project.add_phase(str(cif(cod_id)), phasename=name, histograms=[hist], fmthint="CIF")
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [0.01, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        project.set_Controls("parmMin", 0.0, "2:0:Scale")
        project.set_Controls("cycles", 10)
        project.set_Frozen()
        project.refine(makeBack=False)
        print(name, "Rwp", hist.get_wR(), "scale", hap["Scale"][0], "fractions", hist.ComputeMassFracs())


if __name__ == "__main__":
    main()
