#!/usr/bin/env python3
"""Add and refine the weak calcite phase identified in the residual profile."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2


def lim(project, name, lo, hi):
    project.set_Controls("parmMin", lo, name)
    project.set_Controls("parmMax", hi, name)


def status(project, label):
    hist = project.histogram(0)
    print("\n", label, "Rwp", hist.get_wR(), "fractions", hist.ComputeMassFracs())
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, phase.get_cell(), "scale", hap["Scale"], "size", hap["Size"], "strain", hap["Mustrain"])
        print([(a.label, a.coordinates, a.uiso if a.adp_flag == "I" else a.ADP) for a in phase.atoms()])


def main():
    G2.SetPrintLevel("warn")
    out = Path(".tmp/three_phase.gpx").resolve()
    project = G2.G2Project(".tmp/strain_both.gpx", newgpx=str(out))
    hist = project.histogram(0)
    for phase in project.phases():
        phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    calcite = project.add_phase(".tmp/calcite_normalized.cif", phasename="CaCO3_calcite", histograms=[hist], fmthint="CIF")
    hap = calcite.data["Histograms"][hist.name]
    hap["Scale"] = [1.85, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.3
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    lim(project, "2:0:Scale", 0.0, 20.0)
    project.set_Controls("cycles", 12)

    calcite.set_refinements({"Cell": True})
    project.set_Frozen()
    project.refine(makeBack=False)
    status(project, "calcite scale and cell")

    calcite.clear_refinements({"Cell": True})
    calcite.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": 0.3, "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    })
    lim(project, "2:0:Size;i", 0.04, 1.5)
    lim(project, "2:0:Mustrain;i", 0.0, 8000.0)
    project.set_Frozen()
    project.refine(makeBack=False)
    status(project, "calcite profile")

    calcite.clear_HAP_refinements({"Size": True, "Mustrain": True})
    # The weak phase does not independently determine displacement factors;
    # retain the normalized registration value rather than permitting an
    # intensity/scale trade-off.
    for atom in calcite.atoms():
        atom.refinement_flags = ""
        atom.uiso = 0.005
    calcite.clear_refinements({"Atoms": [a.label for a in calcite.atoms()]})
    oxygen_index = next(i for i, atom in enumerate(calcite.atoms()) if atom.element == "O")
    oxygen = calcite.atoms()[oxygen_index]
    start = tuple(oxygen.coordinates)
    oxygen.refinement_flags = "X"
    for axis, value in zip("xyz", start):
        lim(project, f"2::dA{axis}:{oxygen_index}", value - 0.008, value + 0.008)
    project.set_Frozen()
    project.refine(makeBack=False)
    oxygen.refinement_flags = ""
    status(project, "calcite oxygen")

    project.save()


if __name__ == "__main__":
    main()
