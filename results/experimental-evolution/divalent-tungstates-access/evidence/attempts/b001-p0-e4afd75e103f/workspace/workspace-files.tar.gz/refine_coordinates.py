#!/usr/bin/env python3
"""Refine only the coordinate degrees of freedom supported by X-ray contrast."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2


def coordinate_limits(project, phase_index, atom_index, coordinates, bound):
    for axis, value in zip("xyz", coordinates):
        var = f"{phase_index}::dA{axis}:{atom_index}"
        project.set_Controls("parmMin", value - bound, var)
        project.set_Controls("parmMax", value + bound, var)


def show(project, label):
    hist = project.histogram(0)
    print(label, "Rwp", hist.get_wR(), "mass", hist.ComputeMassFracs())
    for phase in project.phases():
        print(phase.name)
        for atom in phase.atoms():
            print(atom.label, atom.element, atom.coordinates, atom.uiso, atom.refinement_flags)


def main():
    G2.SetPrintLevel("warn")
    out = Path(".tmp/coords.gpx").resolve()
    project = G2.G2Project(".tmp/uiso.gpx", newgpx=str(out))
    project.set_Controls("cycles", 10)
    ca, wo = project.phases()
    for phase in (ca, wo):
        phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})

    # Scheelite has one independent oxygen site. Its coordinates are the only
    # positional degrees of freedom; Ca and W remain on fixed special sites.
    ca_start = tuple(ca.atom("O1").coordinates)
    ca.atom("O1").refinement_flags = "X"
    coordinate_limits(project, 0, 2, ca_start, 0.008)
    project.set_Frozen()
    project.refine(makeBack=False)
    show(project, "CaWO4 oxygen")
    project.save(str(Path(".tmp/ca_coords.gpx").resolve()))

    ca.atom("O1").refinement_flags = ""
    # For the 16 wt% WO3 phase, refine only the two W sites. Oxygen positions
    # are not independently supported by this laboratory X-ray pattern.
    w_indices = [i for i, atom in enumerate(wo.atoms()) if atom.element == "W"]
    for index in w_indices:
        start = tuple(wo.atoms()[index].coordinates)
        wo.atoms()[index].refinement_flags = "X"
        coordinate_limits(project, 1, index, start, 0.005)
    project.set_Frozen()
    project.refine(makeBack=False)
    show(project, "WO3 tungsten")

    for atom in wo.atoms():
        atom.refinement_flags = ""
    project.save()


if __name__ == "__main__":
    main()
