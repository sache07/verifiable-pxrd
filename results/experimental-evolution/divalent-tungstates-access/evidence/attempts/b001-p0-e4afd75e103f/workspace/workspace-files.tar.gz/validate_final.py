#!/usr/bin/env python3
"""Replay final.gpx without refinement and synchronize fit.csv to that replay."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import numpy as np


def main():
    root = Path.cwd().resolve()
    replay_dir = root / ".tmp" / "replay_final"
    replay_dir.mkdir(parents=True, exist_ok=True)
    sys.path.insert(0, str(root / "learned" / "divalent-tungstates" / "scorer" / "runtime"))
    import replay_worker

    os.chdir(replay_dir)
    report = replay_worker.replay(
        {
            "project": str(root / "final.gpx"),
            "observed": str(root / "inputs" / "pattern.csv"),
            "histogram": "PWDR pattern.csv",
        }
    )
    (replay_dir / "replay.json").write_text(json.dumps(report, indent=2) + "\n")
    with np.load(replay_dir / "prediction.npz", allow_pickle=False) as data:
        x = data["x"]
        observed = data["observed"]
        calculated = data["predicted"]
    np.savetxt(
        root / "fit.csv",
        np.column_stack([x, observed, calculated, observed - calculated]),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )
    weights = 1.0 / np.maximum(observed, 1.0)
    rwp = 100 * np.sqrt(np.sum(weights * (observed - calculated) ** 2) / np.sum(weights * observed**2))
    print(json.dumps(report, indent=2))
    print("replayed_Rwp_percent", float(rwp))


if __name__ == "__main__":
    main()
