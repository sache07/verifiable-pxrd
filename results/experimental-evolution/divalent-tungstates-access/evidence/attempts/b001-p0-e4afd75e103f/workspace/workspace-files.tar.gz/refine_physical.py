#!/usr/bin/env python3
"""Continue the selected model with physically bounded profile parameters."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/final_work.gpx")
OUTPUT = Path(".tmp/physical.gpx")


def report(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(label, "Rwp", hist.get_wR(), "fractions", hist.ComputeMassFracs())
    print("instrument", {k: v[1] for k, v in hist.InstrumentParameters.items() if k in {"Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"}})
    print("sample", {k: hist.SampleParameters[k] for k in ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, phase.get_cell(), "scale", hap["Scale"], "size", hap["Size"], "strain", hap["Mustrain"], "PO", hap["Pref.Ori."])


def bounds(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable)
    project.set_Controls("parmMax", high, variable)


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE), newgpx=str(OUTPUT.resolve()))
    hist = project.histogram(0)
    inst = hist.InstrumentParameters

    # Restart the correlated width terms inside the documented instrumental
    # family and the specimen profile family used for these measurements.
    inst["U"][1] = 15.0
    inst["W"][1] = 10.0
    inst["X"][1] = 3.0
    inst["SH/L"][1] = 0.03
    inst["Zero"][1] = -0.10
    hist.SampleParameters["Shift"][0] = 435.0

    ca, wo = project.phases()
    ca_hap = ca.data["Histograms"][hist.name]
    wo_hap = wo.data["Histograms"][hist.name]
    ca_hap["Size"][1][0] = 0.12
    wo_hap["Size"][1][0] = 1.0

    for variable, low, high in [
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
        ("0:0:Size;i", 0.04, 1.5),
        ("1:0:Size;i", 0.04, 1.5),
        ("0:0:Mustrain;i", 0.0, 8000.0),
        ("1:0:Mustrain;i", 0.0, 8000.0),
    ]:
        bounds(project, variable, low, high)

    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    report(project, "bounded profile")

    # Polarization is common to the full scan and is bounded by the reflection
    # geometry. It is separated from the first width re-equilibration step.
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    bounds(project, ":0:Polariz.", 0.5, 1.0)
    project.set_Frozen()
    project.refine(makeBack=False)
    report(project, "polarization")

    project.save()
    summary = {
        "Rwp": hist.get_wR(),
        "residuals": hist.residuals,
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items() if isinstance(v, list) and len(v) > 1},
    }
    OUTPUT.with_suffix(".json").write_text(json.dumps(summary, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
