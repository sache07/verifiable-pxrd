#!/usr/bin/env python3
"""Add a ZnO basis phase to the accepted two-phase project for replay testing."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/231-zcoords-mdgrid-best.gpx"
DESTINATION = ROOT / ".tmp/zno-basis.gpx"
ZNO_CIF = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif/9/00/41/9004178.cif"
)


def main() -> None:
    if DESTINATION.exists():
        DESTINATION.unlink()
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(DESTINATION))
    histogram = project.histogram(0)
    for name in ("ZNWO4", "WO3"):
        project.phase(name).data["Histograms"][histogram.name]["Scale"][0] *= 1e-9
    phase = project.add_phase(
        str(ZNO_CIF), phasename="ZNO", histograms=[histogram], fmthint="CIF"
    )
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"] = [1.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.3
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 500.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "
    project.save(str(DESTINATION))


if __name__ == "__main__":
    main()
