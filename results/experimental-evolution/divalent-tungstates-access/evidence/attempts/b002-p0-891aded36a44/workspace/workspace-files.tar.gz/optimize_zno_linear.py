#!/usr/bin/env python3
"""Build the three-phase project from replay-optimized scales/background."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/231-refine-zcoords/trial.gpx"
DESTINATION = ROOT / ".tmp/231-threephase-linear.gpx"
ZNO_CIF = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif/9/00/41/9004178.cif"
)


def main() -> None:
    zn = np.load(ROOT / ".tmp/md-grid-zcoords/znwo4-0.720/prediction.npz")
    wo = np.load(ROOT / ".tmp/md-grid-zcoords/wo3-1.370/prediction.npz")
    zno = np.load(ROOT / ".tmp/replay-zno-basis/prediction.npz")
    replay = json.loads((ROOT / ".tmp/replay-zcoords/replay.json").read_text())
    x, observed = zn["x"], zn["observed"]
    low, high = replay["background_domain"]
    coordinate = 2.0 * (x - low) / (high - low) - 1.0
    background_basis = np.polynomial.chebyshev.chebvander(coordinate, 29)
    design = np.column_stack(
        (zn["signal"], wo["signal"], zno["signal"], background_basis)
    )
    weights = 1.0 / np.maximum(observed, 1.0)
    root_weights = np.sqrt(weights)
    coefficients = np.linalg.lstsq(
        design * root_weights[:, None], observed * root_weights, rcond=None
    )[0]

    if DESTINATION.exists():
        DESTINATION.unlink()
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(DESTINATION))
    histogram = project.histogram(0)
    zn_phase = project.phase("ZNWO4")
    wo_phase = project.phase("WO3")
    zn_hap = zn_phase.data["Histograms"][histogram.name]
    wo_hap = wo_phase.data["Histograms"][histogram.name]
    zn_hap["Pref.Ori."][1] = 0.720
    zn_hap["Scale"][0] *= float(coefficients[0])
    wo_hap["Pref.Ori."][1] = 1.370
    wo_hap["Pref.Ori."][2] = True
    wo_hap["Pref.Ori."][3] = [1, 1, 0]
    wo_hap["Scale"][0] *= float(coefficients[1])

    zno_phase = project.add_phase(
        str(ZNO_CIF), phasename="ZNO", histograms=[histogram], fmthint="CIF"
    )
    zno_hap = zno_phase.data["Histograms"][histogram.name]
    zno_hap["Scale"] = [float(coefficients[2]), False]
    zno_hap["Size"][0] = "isotropic"
    zno_hap["Size"][1][0] = 0.3
    zno_hap["Size"][2] = [False, False, False]
    zno_hap["Mustrain"][0] = "isotropic"
    zno_hap["Mustrain"][1][0] = 500.0
    zno_hap["Mustrain"][2] = [False, False, False]
    zno_hap["Pref.Ori."][1] = 1.0
    zno_hap["Pref.Ori."][2] = False
    for atom in zno_phase.atoms():
        atom.refinement_flags = " "
    histogram.data["Background"][0][3:] = list(map(float, coefficients[3:]))
    project.save(str(DESTINATION))
    calculated = design @ coefficients
    rwp = 100.0 * np.sqrt(
        np.sum(weights * (observed - calculated) ** 2)
        / np.sum(weights * observed**2)
    )
    print(
        json.dumps(
            {
                "scale_coefficients": coefficients[:3].tolist(),
                "rwp_percent": float(rwp),
                "background_min": float(
                    (background_basis @ coefficients[3:]).min()
                ),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
