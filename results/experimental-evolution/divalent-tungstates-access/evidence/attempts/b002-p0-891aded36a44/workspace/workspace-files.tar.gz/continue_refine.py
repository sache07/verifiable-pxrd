#!/usr/bin/env python3
"""Continue a saved GSAS-II trial with selected higher-order model terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def numdict(values):
    return {
        k: float(v)
        for k, v in values.items()
        if isinstance(v, (int, float, np.integer, np.floating))
    }


def summarize(project):
    hist = project.histogram(0)
    masses = {
        p.name: float(p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0])
        for p in project.phases()
    }
    total = sum(max(0.0, value) for value in masses.values())
    return {
        "residuals": numdict(hist.residuals),
        "mass_fractions": {k: max(0.0, v) / total for k, v in masses.items()},
        "instrument": numdict({k: v[1] for k, v in hist.InstrumentParameters.items() if isinstance(v, list) and len(v) > 1}),
        "sample": {
            key: (float(value[0]) if isinstance(value, list) else value)
            for key, value in hist.SampleParameters.items()
            if key in {"Type", "Gonio. radius", "Shift", "SurfRoughA", "SurfRoughB"}
        },
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "hap": {
                    "scale": float(phase.data["Histograms"][hist.name]["Scale"][0]),
                    "size": phase.data["Histograms"][hist.name]["Size"],
                    "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
                    "preferred_orientation": phase.data["Histograms"][hist.name]["Pref.Ori."],
                },
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": list(map(float, atom.coordinates)),
                        "adp_type": atom.adp_flag,
                        "adp": (
                            float(atom.ADP)
                            if atom.adp_flag == "I"
                            else list(map(float, atom.ADP))
                        ),
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
            for phase in project.phases()
        },
        "vary_list": list(map(str, project.get_VaryList() or [])),
        "frozen": project.get_Frozen(),
    }


def refine(project, history, label):
    project.set_Frozen(mode="remove")
    project.refine()
    row = summarize(project)
    row["stage"] = label
    history.append(row)
    print(label, "wR", row["residuals"].get("wR"), "fractions", row["mass_fractions"])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--outdir", required=True, type=Path)
    parser.add_argument("--po-phase")
    parser.add_argument("--po-axis", type=int, nargs=3)
    parser.add_argument("--coords", nargs="*", default=[])
    parser.add_argument(
        "--coords-element",
        nargs=2,
        action="append",
        metavar=("PHASE", "ELEMENT"),
        default=[],
    )
    parser.add_argument(
        "--coords-element-free",
        nargs=2,
        action="append",
        metavar=("PHASE", "ELEMENT"),
        default=[],
    )
    parser.add_argument("--coord-delta-max", type=float, default=0.008)
    parser.add_argument("--clear-coordinate-limits", action="store_true")
    parser.add_argument("--uiso", nargs="*", default=[])
    parser.add_argument(
        "--fix-uiso",
        nargs=2,
        action="append",
        metavar=("PHASE", "VALUE"),
        default=[],
    )
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--uniaxial-phase")
    parser.add_argument("--uniaxial-axis", type=int, nargs=3)
    parser.add_argument("--isotropic-phase", nargs="*", default=[])
    parser.add_argument("--isotropic-strain", type=float, default=0.0)
    parser.add_argument("--background-coeffs", type=int)
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--profile-phase")
    args = parser.parse_args()

    args.outdir.mkdir(parents=True, exist_ok=True)
    output = args.outdir / "trial.gpx"
    if output.exists():
        output.unlink()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(output.resolve()))
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)
    hid = hist.id
    history = []

    if args.clear_coordinate_limits:
        controls = project.data["Controls"]["data"]
        for key in ("parmMinDict", "parmMaxDict"):
            bounds = controls.get(key, {})
            for variable in list(bounds):
                if getattr(variable, "name", "").startswith("dA"):
                    del bounds[variable]

    if args.isotropic_phase:
        for name in args.isotropic_phase:
            phase = project.phase(name)
            if phase is None:
                raise ValueError(f"unknown isotropic-strain phase {name}")
            hap = phase.data["Histograms"][hist.name]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = float(args.isotropic_strain)
            hap["Mustrain"][1][1] = float(args.isotropic_strain)
            hap["Mustrain"][2][0] = True
            hap["Mustrain"][2][1] = False
            project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hid}:Mustrain;i")
            project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:{hid}:Mustrain;i")
        refine(project, history, "isotropic_mustrain")

    if args.background_coeffs:
        if not 3 <= args.background_coeffs <= 40:
            raise ValueError("background coefficient count must be 3..40")
        hist.set_refinements(
            {
                "Background": {
                    "type": "chebyschev-1",
                    "no. coeffs": args.background_coeffs,
                    "refine": True,
                }
            }
        )
        refine(project, history, f"background_{args.background_coeffs}")

    if args.polarization:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.5, variable=f":{hid}:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=f":{hid}:Polariz.")
        refine(project, history, "polarization")

    if args.profile_phase:
        phase = project.phase(args.profile_phase)
        if phase is None:
            raise ValueError(f"unknown profile phase {args.profile_phase}")
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements(
            {
                "Scale": True,
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
        project.set_Controls(
            "parmMin", 0.0, variable=f"{phase.id}:{hid}:Scale"
        )
        project.set_Controls(
            "parmMax", 1.0e6, variable=f"{phase.id}:{hid}:Scale"
        )
        project.set_Controls(
            "parmMin", 0.04, variable=f"{phase.id}:{hid}:Size;i"
        )
        project.set_Controls(
            "parmMax", 1.5, variable=f"{phase.id}:{hid}:Size;i"
        )
        project.set_Controls(
            "parmMin", 0.0, variable=f"{phase.id}:{hid}:Mustrain;i"
        )
        project.set_Controls(
            "parmMax", 8000.0, variable=f"{phase.id}:{hid}:Mustrain;i"
        )
        refine(project, history, f"profile_{args.profile_phase}")

    if args.po_phase:
        phase = project.phase(args.po_phase)
        if phase is None or args.po_axis is None:
            raise ValueError("preferred-orientation phase and axis are both required")
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(args.po_axis)
        project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:{hid}:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:{hid}:MD")
        refine(project, history, "preferred_orientation")

    if args.uniaxial_phase:
        phase = project.phase(args.uniaxial_phase)
        if phase is None or args.uniaxial_axis is None:
            raise ValueError("uniaxial phase and axis are both required")
        hap = phase.data["Histograms"][hist.name]
        iso = max(300.0, float(hap["Mustrain"][1][0]))
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = iso
        hap["Mustrain"][1][1] = iso
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        hap["Mustrain"][3] = list(args.uniaxial_axis)
        for suffix in ("Mustrain;i", "Mustrain;a"):
            project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hid}:{suffix}")
            project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:{hid}:{suffix}")
        refine(project, history, "uniaxial_mustrain")

    if args.roughness:
        hist.SampleParameters["SurfRoughA"] = [0.2, True]
        hist.SampleParameters["SurfRoughB"] = [0.05, True]
        project.set_Controls("parmMin", 0.0, variable=f":{hid}:SurfRoughA")
        project.set_Controls("parmMax", 0.6, variable=f":{hid}:SurfRoughA")
        project.set_Controls("parmMin", 0.0, variable=f":{hid}:SurfRoughB")
        project.set_Controls("parmMax", 0.5, variable=f":{hid}:SurfRoughB")
        refine(project, history, "surface_roughness")

    if args.coords:
        for name in args.coords:
            phase = project.phase(name)
            if phase is None:
                raise ValueError(f"unknown coordinate phase {name}")
            phase.set_refinements({"Atoms": {"all": "X"}})
        refine(project, history, "coordinates")

    if args.coords_element:
        if not 0 < args.coord_delta_max <= 0.05:
            raise ValueError("coordinate delta limit must be in (0, 0.05]")
        selected = []
        for name, element in args.coords_element:
            phase = project.phase(name)
            if phase is None:
                raise ValueError(f"unknown selective-coordinate phase {name}")
            for index, atom in enumerate(phase.atoms()):
                if atom.element != element:
                    continue
                atom.refinement_flags = "X"
                selected.append((phase.id, index, atom.label))
                for axis, coordinate in zip("xyz", atom.coordinates):
                    variable = f"{phase.id}::dA{axis}:{index}"
                    # The least-squares variable is a shift, but GSAS-II's
                    # bounds checker applies dA limits to the resulting
                    # absolute Ax/Ay/Az value.
                    project.set_Controls(
                        "parmMin", float(coordinate) - args.coord_delta_max, variable=variable
                    )
                    project.set_Controls(
                        "parmMax", float(coordinate) + args.coord_delta_max, variable=variable
                    )
        if not selected:
            raise ValueError("selective coordinate request matched no atoms")
        refine(project, history, "selective_coordinates")

    if args.coords_element_free:
        selected = []
        for name, element in args.coords_element_free:
            phase = project.phase(name)
            if phase is None:
                raise ValueError(f"unknown free selective-coordinate phase {name}")
            for index, atom in enumerate(phase.atoms()):
                if atom.element == element:
                    atom.refinement_flags = "X"
                    selected.append((phase.id, index, atom.label))
        if not selected:
            raise ValueError("free selective coordinate request matched no atoms")
        refine(project, history, "free_selective_coordinates")

    if args.uiso:
        for name in args.uiso:
            phase = project.phase(name)
            if phase is None:
                raise ValueError(f"unknown Uiso phase {name}")
            variables = []
            for index, atom in enumerate(phase.atoms()):
                if atom.uiso < 0.003 or atom.uiso > 0.02:
                    atom.uiso = 0.008
                atom.refinement_flags = "U"
                variable = f"{phase.id}::AUiso:{index}"
                variables.append(variable)
                project.set_Controls("parmMin", 0.003, variable=variable)
                project.set_Controls("parmMax", 0.02, variable=variable)
            if len(variables) > 1:
                project.add_EquivConstr(tuple(variables))
        refine(project, history, "uiso")

    if args.fix_uiso:
        for name, value_text in args.fix_uiso:
            phase = project.phase(name)
            if phase is None:
                raise ValueError(f"unknown fixed-Uiso phase {name}")
            value = float(value_text)
            if not 0.0 <= value <= 0.05:
                raise ValueError("fixed Uiso outside 0..0.05 A^2")
            for atom in phase.atoms():
                atom.uiso = value
                atom.refinement_flags = " "
        refine(project, history, "fixed_uiso")

    if not history:
        raise ValueError("no continuation operation was requested")
    project.save(str(output))
    (args.outdir / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    for phase in project.phases():
        phase.export_CIF(str(args.outdir / f"{phase.name.lower()}_trial.cif"))
    arrays = project.histogram(0).data["data"][1]
    np.savetxt(
        args.outdir / "fit.csv",
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[1] - arrays[3], arrays[4])),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
    )


if __name__ == "__main__":
    main()
