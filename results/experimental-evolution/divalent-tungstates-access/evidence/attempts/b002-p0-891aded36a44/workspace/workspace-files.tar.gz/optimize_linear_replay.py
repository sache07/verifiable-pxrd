#!/usr/bin/env python3
"""Optimize phase scales and Chebyshev background against a fresh GPX replay."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/231-po-w110/trial.gpx"
DESTINATION = ROOT / ".tmp/231-po-w110-linear.gpx"
FULL = ROOT / ".tmp/replay-po-w110"
ZN_ONLY = ROOT / ".tmp/replay-po-w110-now"
WO_ONLY = ROOT / ".tmp/replay-po-w110-noz"


def main() -> None:
    full = np.load(FULL / "prediction.npz")
    zn = np.load(ZN_ONLY / "prediction.npz")
    wo = np.load(WO_ONLY / "prediction.npz")
    replay = json.loads((FULL / "replay.json").read_text())
    x, observed = full["x"], full["observed"]
    low, high = replay["background_domain"]
    coordinate = 2.0 * (x - low) / (high - low) - 1.0
    background_basis = np.polynomial.chebyshev.chebvander(coordinate, 29)
    design = np.column_stack((zn["signal"], wo["signal"], background_basis))
    weights = 1.0 / np.maximum(observed, 1.0)
    root_weights = np.sqrt(weights)
    coefficients = np.linalg.lstsq(
        design * root_weights[:, None], observed * root_weights, rcond=None
    )[0]
    calculated = design @ coefficients
    rwp = 100.0 * np.sqrt(
        np.sum(weights * (observed - calculated) ** 2)
        / np.sum(weights * observed**2)
    )

    if DESTINATION.exists():
        DESTINATION.unlink()
    project = G2.G2Project(
        gpxfile=str(SOURCE.resolve()), newgpx=str(DESTINATION.resolve())
    )
    histogram = project.histogram(0)
    for name, factor in zip(("ZNWO4", "WO3"), coefficients[:2]):
        project.phase(name).data["Histograms"][histogram.name]["Scale"][0] *= float(
            factor
        )
    histogram.data["Background"][0][3:] = list(map(float, coefficients[2:]))
    project.save(str(DESTINATION.resolve()))
    print(
        json.dumps(
            {
                "scale_factors": coefficients[:2].tolist(),
                "background_min": float((background_basis @ coefficients[2:]).min()),
                "linear_prediction_rwp_percent": float(rwp),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
