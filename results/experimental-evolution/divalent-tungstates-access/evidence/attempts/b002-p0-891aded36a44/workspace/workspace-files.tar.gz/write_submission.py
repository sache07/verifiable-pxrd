#!/usr/bin/env python3
"""Write fit.csv and result.json from the independently replayed final project."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / ".tmp/final-replay"


def main() -> None:
    replay = json.loads((REPLAY / "replay.json").read_text())
    if replay.get("status") != "replayed" or replay.get("profile_review_flags"):
        raise RuntimeError(f"final project did not replay cleanly: {replay}")

    profile = np.load(REPLAY / "prediction.npz")
    x = profile["x"]
    observed = profile["observed"]
    calculated = profile["predicted"]
    background = profile["background"]
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * (observed - calculated) ** 2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(observed - calculated)) / np.sum(observed))
    rexp = 2.6463543021668845

    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack(
            (x, observed, calculated, observed - calculated, background)
        ),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt="%.10f",
    )

    replay_fractions = {phase["name"]: phase["weight_fraction"] for phase in replay["phases"]}
    result = {
        "refinement_histogram": replay["histogram"],
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "phases": [
            {
                "name": "ZnWO4 (wolframite)",
                "formula": "ZnWO4",
                "space_group": "P 2/c",
                "cif_path": "phase_1_ZnWO4.cif",
                "weight_fraction": replay_fractions["ZNWO4"],
            },
            {
                "name": "WO3 (monoclinic)",
                "formula": "WO3",
                "space_group": "P 21/c",
                "cif_path": "phase_2_WO3.cif",
                "weight_fraction": replay_fractions["WO3"],
            },
            {
                "name": "ZnO (wurtzite)",
                "formula": "ZnO",
                "space_group": "P 63 m c",
                "cif_path": "phase_3_ZnO.cif",
                "weight_fraction": replay_fractions["ZNO"],
            },
        ],
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "rexp_percent": rexp,
            "goodness_of_fit": rwp / rexp,
            "chi_square": chi_square,
            "number_of_points": int(len(x)),
            "profile_source": "fresh atomic forward replay of final.gpx on the complete measured grid",
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
