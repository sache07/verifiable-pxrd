#!/usr/bin/env python3
"""Build and refine GSAS-II candidate models for the supplied PXRD pattern.

Run with the GSAS-II Python interpreter. The script deliberately keeps every
trial separate so that phase-inventory alternatives can be compared using the
same refinement schedule.
"""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)

PHASE_FILES = {
    "znwo4": ROOT / "start_ZnWO4.cif",
    "wo3": RESOURCE / "1/52/89/1528915.cif",
    "zno": RESOURCE / "9/00/41/9004178.cif",
}


def write_inputs(outdir: Path) -> tuple[Path, Path]:
    raw = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    x, y = raw.T
    sigma = np.sqrt(np.maximum(y, 1.0))
    xye = outdir / "pattern.xye"
    np.savetxt(xye, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")
    inst = outdir / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for Cu Kalpha Bragg-Brentano data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def mass_fractions(project: G2.G2Project, histname: str) -> dict[str, float]:
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][histname]
        raw[phase.name] = float(phase.data["General"]["Mass"] * hap["Scale"][0])
    total = sum(max(v, 0.0) for v in raw.values())
    return {k: max(v, 0.0) / total for k, v in raw.items()} if total else raw


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    result = {
        "stage": label,
        "residuals": {
            k: float(v)
            for k, v in hist.residuals.items()
            if isinstance(v, (int, float, np.integer, np.floating))
        },
        "mass_fractions": mass_fractions(project, hist.name),
        "instrument": {
            k: float(v[1])
            for k, v in hist.InstrumentParameters.items()
            if isinstance(v, list) and len(v) > 1 and isinstance(v[1], (int, float))
        },
        "sample": {
            k: (float(v[0]) if isinstance(v, list) else v)
            for k, v in hist.SampleParameters.items()
            if k in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius", "Type"}
        },
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size": copy.deepcopy(hap["Size"]),
            "mustrain": copy.deepcopy(hap["Mustrain"]),
            "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
        }
    print(json.dumps(result, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x)))
    return result


def run_refinement(project: G2.G2Project, label: str, history: list[dict]) -> None:
    project.set_Frozen(mode="remove")
    project.refine()
    history.append(snapshot(project, label))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", required=True, type=Path)
    parser.add_argument("--phases", nargs="+", choices=sorted(PHASE_FILES), required=True)
    parser.add_argument("--wo3-cif", type=Path)
    parser.add_argument("--coords", action="store_true", help="refine atomic coordinates in the last stage")
    parser.add_argument("--roughness", action="store_true", help="refine Suortti surface roughness")
    args = parser.parse_args()

    outdir = args.outdir.resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    xye, inst = write_inputs(outdir)
    gpx_path = outdir / "trial.gpx"
    if gpx_path.exists():
        gpx_path.unlink()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(gpx_path))
    phase_objects = []
    for key in args.phases:
        source = args.wo3_cif.resolve() if key == "wo3" and args.wo3_cif else PHASE_FILES[key]
        phase_objects.append(
            project.add_phase(str(source), phasename=key.upper(), fmthint="CIF")
        )
    hist = project.add_powder_histogram(
        str(xye), str(inst), phases=phase_objects, fmthint="xye"
    )
    hist.data["data"][0]["histTitle"] = "Observed pattern.csv"
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-500.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [float(np.loadtxt(xye, max_rows=1)[0]), 100.08],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [900.0] + [0.0] * 11,
                "refine": True,
            },
        }
    )

    for phase in phase_objects:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [0.01, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][1][1] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][1] = 500.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    project.set_Controls("cycles", 8)
    hid = hist.id
    bounded = {
        f":{hid}:Zero": (-0.25, 0.25),
        f":{hid}:Shift": (-800.0, 800.0),
        f":{hid}:U": (0.0, 40.0),
        f":{hid}:W": (2.0, 40.0),
        f":{hid}:X": (0.1, 6.0),
        f":{hid}:SH/L": (0.005, 0.10),
    }
    for phase in phase_objects:
        bounded.update(
            {
                f"{phase.id}:{hid}:Scale": (0.0, 1.0e6),
                f"{phase.id}:{hid}:Size;i": (0.04, 1.5),
                f"{phase.id}:{hid}:Mustrain;i": (0.0, 8000.0),
            }
        )
    for variable, (lower, upper) in bounded.items():
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    history: list[dict] = []

    run_refinement(project, "background_scales", history)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_refinement(project, "zero_shift", history)

    for phase in phase_objects:
        phase.set_refinements({"Cell": True})
    run_refinement(project, "cells", history)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in phase_objects:
        phase.set_HAP_refinements(
            {
                "Scale": True,
                "Size": {"type": "isotropic", "value": 0.3, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    run_refinement(project, "profile", history)

    if args.roughness:
        hist.SampleParameters["SurfRoughA"] = [0.2, False]
        hist.SampleParameters["SurfRoughB"] = [0.05, False]
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        run_refinement(project, "surface_roughness", history)

    if args.coords:
        for phase in phase_objects:
            phase.set_refinements({"Atoms": {"all": "X"}})
        run_refinement(project, "coordinates", history)

    project.save(str(gpx_path))
    (outdir / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    for phase in project.phases():
        phase.export_CIF(str(outdir / f"{phase.name.lower()}_trial.cif"))
    arrays = hist.data["data"][1]
    np.savetxt(
        outdir / "fit.csv",
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[1] - arrays[3], arrays[4])),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
    )


if __name__ == "__main__":
    main()
