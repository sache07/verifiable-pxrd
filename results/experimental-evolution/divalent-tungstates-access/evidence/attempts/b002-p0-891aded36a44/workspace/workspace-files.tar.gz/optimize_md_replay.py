#!/usr/bin/env python3
"""Grid-optimize both March-Dollase ratios using fresh atomic GPX replays."""

from __future__ import annotations

import itertools
import json
from pathlib import Path
import subprocess
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/231-refine-zcoords/trial.gpx"
WORK = ROOT / ".tmp/md-grid-zcoords"
DESTINATION = ROOT / ".tmp/231-zcoords-mdgrid-best.gpx"
OBSERVED = ROOT / "inputs/pattern.csv"
REPLAY_WORKER = ROOT / "learned/divalent-tungstates/scorer/runtime/replay_worker.py"
ZN_VALUES = [0.700, 0.705, 0.710, 0.715, 0.720, 0.730]
WO_VALUES = [1.300, 1.340, 1.370, 1.390, 1.400]


def phase_signal(active: str, md_value: float) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    label = f"{active.lower()}-{md_value:.3f}"
    folder = WORK / label
    folder.mkdir(parents=True, exist_ok=True)
    gpx = folder / "trial.gpx"
    if gpx.exists():
        gpx.unlink()
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(gpx))
    histogram = project.histogram(0)
    inactive = "WO3" if active == "ZNWO4" else "ZNWO4"
    project.phase(inactive).data["Histograms"][histogram.name]["Scale"][0] *= 1e-9
    preferred = project.phase(active).data["Histograms"][histogram.name]["Pref.Ori."]
    preferred[1] = md_value
    if active == "WO3":
        preferred[2] = True
        preferred[3] = [1, 1, 0]
    project.save(str(gpx))
    request = {"project": str(gpx), "observed": str(OBSERVED)}
    request_path = folder / "request.json"
    request_path.write_text(json.dumps(request) + "\n")
    subprocess.run(
        [sys.executable, str(REPLAY_WORKER), str(request_path)],
        cwd=folder,
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    report = json.loads((folder / "replay.json").read_text())
    if report["status"] != "replayed" or report["profile_review_flags"]:
        raise RuntimeError(report)
    with np.load(folder / "prediction.npz") as replay:
        return replay["x"].copy(), replay["observed"].copy(), replay["signal"].copy()


def main() -> None:
    WORK.mkdir(parents=True, exist_ok=True)
    zn_signals = {value: phase_signal("ZNWO4", value) for value in ZN_VALUES}
    wo_signals = {value: phase_signal("WO3", value) for value in WO_VALUES}
    x, observed, _ = next(iter(zn_signals.values()))
    base_report = json.loads((ROOT / ".tmp/replay-zcoords/replay.json").read_text())
    low, high = base_report["background_domain"]
    coordinate = 2.0 * (x - low) / (high - low) - 1.0
    background_basis = np.polynomial.chebyshev.chebvander(coordinate, 29)
    weights = 1.0 / np.maximum(observed, 1.0)
    root_weights = np.sqrt(weights)
    denominator = np.sum(weights * observed**2)
    trials = []
    for zn_md, wo_md in itertools.product(ZN_VALUES, WO_VALUES):
        design = np.column_stack(
            (zn_signals[zn_md][2], wo_signals[wo_md][2], background_basis)
        )
        coefficients = np.linalg.lstsq(
            design * root_weights[:, None], observed * root_weights, rcond=None
        )[0]
        calculated = design @ coefficients
        rwp = 100.0 * np.sqrt(
            np.sum(weights * (observed - calculated) ** 2) / denominator
        )
        trials.append((float(rwp), zn_md, wo_md, coefficients))
    rwp, zn_md, wo_md, coefficients = min(trials, key=lambda row: row[0])

    if DESTINATION.exists():
        DESTINATION.unlink()
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(DESTINATION))
    histogram = project.histogram(0)
    for name, md, factor in (
        ("ZNWO4", zn_md, coefficients[0]),
        ("WO3", wo_md, coefficients[1]),
    ):
        hap = project.phase(name).data["Histograms"][histogram.name]
        hap["Pref.Ori."][1] = float(md)
        if name == "WO3":
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [1, 1, 0]
        hap["Scale"][0] *= float(factor)
    histogram.data["Background"][0][3:] = list(map(float, coefficients[2:]))
    project.save(str(DESTINATION))
    print(
        json.dumps(
            {
                "best": {
                    "rwp_percent": rwp,
                    "znwo4_md": zn_md,
                    "wo3_md": wo_md,
                    "scale_factors": coefficients[:2].tolist(),
                    "background_min": float(
                        (background_basis @ coefficients[2:]).min()
                    ),
                },
                "ranked": [
                    {"rwp": row[0], "znwo4_md": row[1], "wo3_md": row[2]}
                    for row in sorted(trials, key=lambda row: row[0])[:10]
                ],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
