#!/usr/bin/env python3
"""Make controlled parameter-only copies of a GSAS-II project for replay checks."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--scale-factor", nargs=2, action="append", default=[])
    parser.add_argument("--md", nargs=2, action="append", default=[])
    parser.add_argument("--isotropic-uiso", nargs=2, action="append", default=[])
    args = parser.parse_args()

    if args.output.exists():
        args.output.unlink()
    project = G2.G2Project(
        gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve())
    )
    histogram = project.histogram(0)
    for name, factor in args.scale_factor:
        phase = project.phase(name)
        phase.data["Histograms"][histogram.name]["Scale"][0] *= float(factor)
    for name, value in args.md:
        phase = project.phase(name)
        phase.data["Histograms"][histogram.name]["Pref.Ori."][1] = float(value)
    for name, value in args.isotropic_uiso:
        phase = project.phase(name)
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = float(value)
            atom.refinement_flags = " "
    project.save(str(args.output.resolve()))


if __name__ == "__main__":
    main()
