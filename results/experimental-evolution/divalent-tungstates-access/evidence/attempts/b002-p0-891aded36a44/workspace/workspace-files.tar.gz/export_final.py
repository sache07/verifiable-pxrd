#!/usr/bin/env python3
"""Copy the accepted GSAS-II model to final.gpx and export precise phase CIFs."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/231-threephase-final.gpx"
FINAL = ROOT / "final.gpx"


def main() -> None:
    G2.SetPrintLevel("warn")
    if FINAL.exists():
        FINAL.unlink()
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    project.save(str(FINAL))

    # Clear covariance only in this in-memory copy so CIF precision is not
    # reduced by large coordinate e.s.d.s. The refined project remains intact.
    project.data["Covariance"]["data"] = {}
    filenames = {
        "ZNWO4": "phase_1_ZnWO4.cif",
        "WO3": "phase_2_WO3.cif",
        "ZNO": "phase_3_ZnO.cif",
    }
    histogram = project.histogram(0)
    masses = {}
    cells = {}
    for phase in project.phases():
        phase.export_CIF(str(ROOT / filenames[phase.name]))
        masses[phase.name] = float(
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][histogram.name]["Scale"][0]
        )
        cells[phase.name] = phase.get_cell()
    total = sum(masses.values())
    print(
        json.dumps(
            {
                "histogram": histogram.name,
                "fractions": {name: mass / total for name, mass in masses.items()},
                "cells": cells,
                "project_residuals": histogram.residuals,
                "cifs": filenames,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
