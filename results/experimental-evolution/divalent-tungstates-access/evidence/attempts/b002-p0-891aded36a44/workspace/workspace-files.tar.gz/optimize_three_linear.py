#!/usr/bin/env python3
"""Finalize three phase scales/background using independent phase replays."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/three-u010.gpx"
DESTINATION = ROOT / ".tmp/231-threephase-final.gpx"


def main() -> None:
    folders = [
        ROOT / ".tmp/replay-u010-zn-basis",
        ROOT / ".tmp/replay-u010-wo-basis",
        ROOT / ".tmp/replay-u010-zno-basis",
    ]
    profiles = [np.load(folder / "prediction.npz") for folder in folders]
    report = json.loads((folders[0] / "replay.json").read_text())
    x, observed = profiles[0]["x"], profiles[0]["observed"]
    low, high = report["background_domain"]
    coordinate = 2.0 * (x - low) / (high - low) - 1.0
    background_basis = np.polynomial.chebyshev.chebvander(coordinate, 29)
    design = np.column_stack(
        ([profile["signal"] for profile in profiles] + [background_basis])
    )
    weights = 1.0 / np.maximum(observed, 1.0)
    root_weights = np.sqrt(weights)
    coefficients = np.linalg.lstsq(
        design * root_weights[:, None], observed * root_weights, rcond=None
    )[0]
    calculated = design @ coefficients
    rwp = 100.0 * np.sqrt(
        np.sum(weights * (observed - calculated) ** 2)
        / np.sum(weights * observed**2)
    )

    if DESTINATION.exists():
        DESTINATION.unlink()
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(DESTINATION))
    histogram = project.histogram(0)
    for name, factor in zip(("ZNWO4", "WO3", "ZNO"), coefficients[:3]):
        project.phase(name).data["Histograms"][histogram.name]["Scale"][0] *= float(
            factor
        )
    histogram.data["Background"][0][3:] = list(map(float, coefficients[3:]))
    project.save(str(DESTINATION))
    print(
        json.dumps(
            {
                "scale_factors": coefficients[:3].tolist(),
                "rwp_percent": float(rwp),
                "background_min": float(
                    (background_basis @ coefficients[3:]).min()
                ),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
