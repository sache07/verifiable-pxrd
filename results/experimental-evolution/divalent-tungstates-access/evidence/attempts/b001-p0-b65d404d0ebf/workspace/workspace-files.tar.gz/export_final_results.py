from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "struct_rough005.gpx"
FINAL = ROOT / "final.gpx"


project = G2.G2Project(str(SOURCE), newgpx=str(FINAL))
project.save()
hist = project.histogram("PWDR pattern.xye")

exports = {
    "ZnWO4_wolframite": "phase_ZnWO4_wolframite.cif",
    "WO3_monoclinic_2311041": "phase_WO3_monoclinic.cif",
    "ZnO_wurtzite": "phase_ZnO_wurtzite.cif",
}
for phase_name, filename in exports.items():
    project.phase(phase_name).export_CIF(str(ROOT / filename))

arrays = hist.data["data"][1]
x = np.asarray(arrays[0], float)
observed = np.asarray(arrays[1], float)
calculated = np.asarray(arrays[3], float)
difference = observed - calculated
np.savetxt(
    ROOT / "fit.csv",
    np.column_stack((x, observed, calculated, difference)),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference",
    comments="",
    fmt=("%.8f", "%.8f", "%.8f", "%.8f"),
)

proxies = {
    phase.name: float(
        phase.data["Histograms"][hist.name]["Scale"][0]
        * phase.data["General"]["Mass"]
    )
    for phase in project.phases()
}
total = sum(proxies.values())
fractions = {name: value / total for name, value in proxies.items()}

rvals = project.data["Covariance"]["data"].get("Rvals", {})
rp = 100.0 * float(np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
result = {
    "phases": [
        {
            "name": "ZnWO4 (wolframite)",
            "formula": "ZnWO4",
            "cif_path": exports["ZnWO4_wolframite"],
            "weight_fraction": fractions["ZnWO4_wolframite"],
        },
        {
            "name": "WO3 (monoclinic)",
            "formula": "WO3",
            "cif_path": exports["WO3_monoclinic_2311041"],
            "weight_fraction": fractions["WO3_monoclinic_2311041"],
        },
        {
            "name": "ZnO (wurtzite)",
            "formula": "ZnO",
            "cif_path": exports["ZnO_wurtzite"],
            "weight_fraction": fractions["ZnO_wurtzite"],
        },
    ],
    "fraction_basis": "normalized over the modeled crystalline phases",
    "refinement_histogram": hist.name,
    "fit_statistics": {
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": rp,
        "GOF": float(rvals.get("GOF")),
        "chi_squared": float(rvals.get("chisq")),
        "observations": int(rvals.get("Nobs", len(x))),
        "variables": int(rvals.get("Nvars", 0)),
    },
}
(ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

print(json.dumps(result, indent=2))
