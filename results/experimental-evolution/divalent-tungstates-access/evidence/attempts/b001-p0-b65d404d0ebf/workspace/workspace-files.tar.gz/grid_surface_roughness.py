from pathlib import Path
from itertools import product
import os

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = Path(os.environ.get("ROUGH_GRID_SOURCE", ROOT / "roughbranch_uiso_best.gpx"))


def prepare(project):
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.data["Instrument Parameters"][0]["Polariz."][2] = True
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        phase.set_refinements({"Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = True
    return hist


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    values = [(0.0, 0.0), *product((0.05, 0.10, 0.20, 0.30, 0.40, 0.60), (0.02,))]
    for a, b in values:
        out = ROOT / f"rough_grid_{a:.2f}_{b:.2f}.gpx"
        project = G2.G2Project(str(SOURCE), newgpx=str(out))
        hist = prepare(project)
        hist.data["Sample Parameters"]["SurfRoughA"] = [a, False]
        hist.data["Sample Parameters"]["SurfRoughB"] = [b, False]
        project.set_Controls("cycles", 7)
        project.refine(makeBack=False)
        project.save()
        print(a, b, hist.get_wR(), out, flush=True)
