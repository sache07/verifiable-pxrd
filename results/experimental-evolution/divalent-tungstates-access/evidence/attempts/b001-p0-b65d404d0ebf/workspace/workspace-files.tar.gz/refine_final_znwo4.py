from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
source = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / "joint_scaled.gpx"
output = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else ROOT / "znwo4_final_struct.gpx"
project = G2.G2Project(str(source), newgpx=str(output))
hist = project.histogram(0)
project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
for value in hist.data["Instrument Parameters"][0].values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
hist.data["Instrument Parameters"][0]["Polariz."][2] = True
for value in hist.data["Sample Parameters"].values():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False
hist.data["Background"][0][1] = True
for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    phase.set_refinements({"Atoms": {"all": "X" if phase.name == "ZnWO4_wolframite" else " "}})
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = True
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Pref.Ori."][2] = True
project.set_Controls("cycles", 12)
project.refine(makeBack=False)
project.save()
print(hist.get_wR(), project.data["Covariance"]["data"].get("Rvals", {}).get("GOF"))
for atom in project.phase("ZnWO4_wolframite").atoms():
    print(atom.label, atom.coordinates, atom.refinement_flags)
