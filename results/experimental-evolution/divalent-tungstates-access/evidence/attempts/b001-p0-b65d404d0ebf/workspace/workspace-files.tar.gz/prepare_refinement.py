from pathlib import Path

import numpy as np
import pandas as pd
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
LIB = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c05/cif")


def cod_path(cod_id: str) -> Path:
    return LIB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_cif(structure: Structure, path: Path) -> None:
    structure.remove_oxidation_states()
    CifWriter(structure, symprec=0.001, significant_figures=10).write_file(path)


# Wolframite ZnWO4, derived from the isostructural FeWO4 COD 1567215 model.
# A literature-scale ZnWO4 cell is used only as a close Rietveld starting point.
wolf = Structure.from_file(cod_path("1567215"), primitive=False)
wolf.replace_species({"Fe": "Zn"})
wolf = Structure(
    Lattice.monoclinic(4.6910, 5.7200, 4.9260, 90.63),
    wolf.species,
    wolf.frac_coords,
    site_properties=wolf.site_properties,
)
write_cif(wolf, ROOT / "start_znwo4.cif")

# Room-temperature monoclinic WO3 and wurtzite ZnO reference models.
write_cif(Structure.from_file(cod_path("1528915"), primitive=False), ROOT / "start_wo3.cif")
write_cif(Structure.from_file(cod_path("9004178"), primitive=False), ROOT / "start_zno.cif")

# GSAS-II's xye reader treats the third column as sigma(I).
pattern = pd.read_csv(ROOT / "inputs" / "pattern.csv")
x = pattern["two_theta_deg"].to_numpy(float)
y = pattern["intensity"].to_numpy(float)
sigma = np.sqrt(np.maximum(y, 1.0))
np.savetxt(ROOT / "pattern.xye", np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")

# Broad but physical starting profile within the stated instrument ranges.
(ROOT / "instrument.instprm").write_text(
    "#GSAS-II instrument parameter file for lab CuKa data\n"
    "Type:PXC;Bank:1\n"
    "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.75;Azimuth:0.0;I(L2)/I(L1):0.5\n"
    "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
)

print("Prepared starting CIFs, pattern.xye and instrument.instprm")
