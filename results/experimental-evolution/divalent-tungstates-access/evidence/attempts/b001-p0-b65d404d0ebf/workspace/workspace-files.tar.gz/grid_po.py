from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
AXES = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 1, 1)]


def freeze_except_po(project, target_phase):
    hist = project.histogram(0)
    hist.data["Sample Parameters"]["Scale"][1] = False
    for key, val in hist.data["Sample Parameters"].items():
        if isinstance(val, list) and len(val) > 1 and isinstance(val[1], bool):
            val[1] = False
    for key, val in hist.data["Instrument Parameters"][0].items():
        if isinstance(val, list) and len(val) > 2:
            val[2] = False
    # Keep a modest background and both phase scales adjustable.
    hist.data["Background"][0][1] = True
    for i, phase in enumerate(project.phases()):
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = i == target_phase
    return hist


def test_axes(source, target_phase, prefix):
    results = []
    for axis in AXES:
        for start in (0.8, 1.2):
            tag = "".join(map(str, axis)) + ("lo" if start < 1 else "hi")
            out = ROOT / f"{prefix}_{tag}.gpx"
            project = G2.G2Project(str(source), newgpx=str(out))
            hist = freeze_except_po(project, target_phase)
            phase = project.phases()[target_phase]
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = start
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(axis)
            project.set_Controls("parmMin", 0.7, variable=f"{target_phase}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{target_phase}:0:MD")
            project.set_Controls("cycles", 8)
            project.refine(makeBack=False)
            project.save()
            ratio = hap["Pref.Ori."][1]
            results.append((hist.get_wR(), axis, ratio, out))
            print(prefix, axis, start, "=>", hist.get_wR(), ratio, flush=True)
    results.sort(key=lambda x: x[0])
    print("BEST", prefix, results[0], flush=True)
    return results[0]


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    best_zn = test_axes(ROOT / "physical_base.gpx", 0, "po_zn")
    best_wo = test_axes(best_zn[3], 1, "po_wo")
    shutil.copy2(best_wo[3], ROOT / "po_best.gpx")
    print("FINAL", best_wo, flush=True)
