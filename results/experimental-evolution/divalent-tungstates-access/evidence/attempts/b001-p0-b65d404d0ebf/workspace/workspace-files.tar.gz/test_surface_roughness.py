from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "zno_z_0.3940.gpx"


def prepare(project):
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.data["Instrument Parameters"][0]["Polariz."][2] = True
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        phase.set_refinements({"Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = True
    return hist


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    for i, (a, b) in enumerate(((0.10, 0.03), (0.30, 0.10), (0.50, 0.30))):
        out = ROOT / f"rough_{i}.gpx"
        project = G2.G2Project(str(SOURCE), newgpx=str(out))
        hist = prepare(project)
        hist.data["Sample Parameters"]["SurfRoughA"] = [a, True]
        hist.data["Sample Parameters"]["SurfRoughB"] = [b, True]
        project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
        project.set_Controls("cycles", 12)
        project.refine(makeBack=False)
        project.save()
        sp = hist.data["Sample Parameters"]
        print(i, hist.get_wR(), sp["SurfRoughA"], sp["SurfRoughB"], out, flush=True)
