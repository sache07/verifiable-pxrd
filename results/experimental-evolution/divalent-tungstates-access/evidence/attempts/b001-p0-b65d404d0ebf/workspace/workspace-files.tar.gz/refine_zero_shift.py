from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


if __name__ == "__main__":
    source, output = map(lambda x: Path(x).resolve(), sys.argv[1:3])
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(source), newgpx=str(output))
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.data["Instrument Parameters"][0]["Zero"][2] = True
    hist.data["Instrument Parameters"][0]["Polariz."][2] = True
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.data["Sample Parameters"]["Shift"][1] = True
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.set_refinements({"Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = True
    project.set_Controls("parmMin", -0.25, variable=":0:Zero")
    project.set_Controls("parmMax", 0.25, variable=":0:Zero")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    project.save()
    print(output, hist.get_wR(), hist.data["Instrument Parameters"][0]["Zero"], hist.data["Sample Parameters"]["Shift"])
    for phase in project.phases():
        print(phase.name, phase.get_cell())
