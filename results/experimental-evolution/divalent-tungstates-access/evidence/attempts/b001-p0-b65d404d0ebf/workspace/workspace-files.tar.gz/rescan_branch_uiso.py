from pathlib import Path
import shutil
import sys

from GSASII import GSASIIscriptable as G2


VALUES = (0.003, 0.005, 0.007, 0.009, 0.011, 0.014, 0.017, 0.020)


def prepare(project):
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.data["Instrument Parameters"][0]["Polariz."][2] = True
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        phase.set_refinements({"Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = True
    return hist


def scan(source, phase_name, prefix):
    results = []
    for value in VALUES:
        out = source.parent / f"{prefix}_{phase_name}_{value:.3f}.gpx"
        project = G2.G2Project(str(source), newgpx=str(out))
        hist = prepare(project)
        for atom in project.phase(phase_name).atoms():
            atom.uiso = value
        project.set_Controls("cycles", 7)
        project.refine(makeBack=False)
        project.save()
        results.append((hist.get_wR(), value, out))
        print(phase_name, results[-1], flush=True)
    best = min(results)
    print("BEST", phase_name, best, flush=True)
    return best[2]


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    source = Path(sys.argv[1]).resolve()
    prefix = sys.argv[2]
    for name in ("WO3_monoclinic_2311041", "ZnWO4_wolframite", "ZnO_wurtzite"):
        source = scan(source, name, prefix)
    shutil.copy2(source, source.parent / f"{prefix}_uiso_best.gpx")
