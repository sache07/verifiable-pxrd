from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
project = G2.G2Project(str(ROOT / "joint_weakrough.gpx"), newgpx=str(ROOT / "rough_local.gpx"))
hist = project.histogram(0)
project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
for value in hist.data["Instrument Parameters"][0].values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
hist.data["Instrument Parameters"][0]["Polariz."][2] = True
for value in hist.data["Sample Parameters"].values():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False
hist.data["Sample Parameters"]["SurfRoughA"][1] = True
hist.data["Sample Parameters"]["SurfRoughB"][1] = True
hist.data["Background"][0][1] = True
for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    phase.set_refinements({"Atoms": {"all": " "}})
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = True
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Pref.Ori."][2] = True
project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
project.set_Controls("parmMin", 0.001, variable=":0:SurfRoughB")
project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
project.set_Controls("cycles", 15)
project.refine(makeBack=False)
project.save()
print(hist.get_wR(), hist.data["Sample Parameters"]["SurfRoughA"], hist.data["Sample Parameters"]["SurfRoughB"])
