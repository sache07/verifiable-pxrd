from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def prepare(project):
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.data["Instrument Parameters"][0]["Polariz."][2] = True
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        phase.set_refinements({"Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = True
    return hist


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    for delta in (0.003, 0.005, 0.008, 0.012, 0.018):
        source = ROOT / f"wo3_coord_{delta:.3f}.gpx"
        out = ROOT / f"wo3_coord_eval_{delta:.3f}.gpx"
        project = G2.G2Project(str(source), newgpx=str(out))
        hist = prepare(project)
        project.set_Controls("cycles", 8)
        project.refine(makeBack=False)
        project.save()
        print(delta, hist.get_wR(), out, flush=True)
