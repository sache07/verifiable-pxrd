from copy import deepcopy
import os
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = Path(os.environ.get(
    "WO3_TRIAL_SOURCE",
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c05/cif/2/31/10/2311041.cif",
))


def remove_phase(project, name):
    """Remove one phase from a scriptable project before inserting a trial model."""
    del project.data["Phases"][name]
    for row in project.names:
        if row and row[0] == "Phases":
            row.remove(name)
    for hist in project.histograms():
        hist.data.get("Reflection Lists", {}).pop(name, None)
    project.index_ids()
    project.update_ids()


def build_trial(axis):
    tag = "".join("m" if i < 0 else str(i) for i in axis)
    source_tag = SOURCE.stem.replace("normalized_", "norm_")
    out = ROOT / f"wo3_{source_tag}_{tag}.gpx"
    project = G2.G2Project(str(ROOT / "three_struct.gpx"), newgpx=str(out))
    hist = project.histogram(0)

    remove_phase(project, "WO3_monoclinic")
    phase = project.add_phase(
        str(SOURCE), phasename="WO3_monoclinic_2311041",
        histograms=[hist], fmthint="CIF"
    )

    # Compare the source structures using the already established nuisance
    # model. Keep the other phase coordinates and all instrumental terms fixed.
    for p in project.phases():
        p.set_refinements({"Cell": p.name == phase.name, "Atoms": {"all": " "}})

    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [9.1, True]
    hap["Size"] = [
        "isotropic", [0.398, 0.5, 1.0], [True, False, False], [0, 0, 1],
        [1.0, 1.0, 1.0, 0.0, 0.0, 0.0], [False] * 6,
    ]
    hap["Mustrain"] = [
        "uniaxial", [3142.0, 1548.0, 1.0], [True, True, False], list(axis),
        [0.01] * 9, [False] * 9,
    ]
    hap["Pref.Ori."] = ["MD", 0.90, True, [0, 1, 0], 0, {}, [], 0.1]
    hap["Extinction"] = [0.0, False]

    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
    project.refine(makeBack=False)
    project.save()
    print(axis, hist.get_wR(), project.data["Covariance"]["data"].get("Rvals", {}).get("GOF"))


if __name__ == "__main__":
    axes = [[int(v) for v in item.split(",")] for item in sys.argv[1:]]
    if not axes:
        axes = [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 0, 1], [1, 0, -1]]
    for trial_axis in axes:
        build_trial(trial_axis)
