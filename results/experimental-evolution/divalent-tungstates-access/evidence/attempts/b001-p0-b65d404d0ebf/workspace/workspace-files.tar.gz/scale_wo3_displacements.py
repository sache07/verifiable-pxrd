from pathlib import Path
import numpy as np

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
PHASE = "WO3_monoclinic_2311041"


def prepare(project):
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.data["Instrument Parameters"][0]["Polariz."][2] = True
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        phase.set_refinements({"Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = True
    return hist


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    source_project = G2.G2Project(str(ROOT / "uiso_final_best.gpx"))
    direction_project = G2.G2Project(str(ROOT / "wo3_coord_0.018.gpx"))
    source_phase = source_project.phase(PHASE)
    direction_phase = direction_project.phase(PHASE)
    xyz0 = np.array([a.coordinates for a in source_phase.atoms()], float)
    xyz1 = np.array([a.coordinates for a in direction_phase.atoms()], float)
    dfrac = xyz1 - xyz0
    dfrac -= np.rint(dfrac)
    symbols = np.array([a.element for a in source_phase.atoms()])
    direct, _ = G2lat.cell2AB(source_phase.data["General"]["Cell"][1:7])
    rms0 = {
        el: float(np.sqrt(np.mean(np.sum((dfrac[symbols == el] @ direct.T) ** 2, axis=1))))
        for el in sorted(set(symbols))
    }
    print("direction_rms", rms0, flush=True)

    for w_rms in (0.020, 0.030, 0.040):
        for o_rms in (0.030, 0.040, 0.050):
            out = ROOT / f"wo3_scaled_W{w_rms:.3f}_O{o_rms:.3f}.gpx"
            project = G2.G2Project(str(ROOT / "joint_weakrough.gpx"), newgpx=str(out))
            hist = prepare(project)
            phase = project.phase(PHASE)
            target = xyz0.copy()
            for el, amplitude in (("W", w_rms), ("O", o_rms)):
                mask = symbols == el
                target[mask] += dfrac[mask] * amplitude / rms0[el]
            for atom, xyz in zip(phase.atoms(), target):
                atom.coordinates = tuple(xyz)
            project.set_Controls("cycles", 8)
            project.refine(makeBack=False)
            project.save()
            print(w_rms, o_rms, hist.get_wR(), out, flush=True)
