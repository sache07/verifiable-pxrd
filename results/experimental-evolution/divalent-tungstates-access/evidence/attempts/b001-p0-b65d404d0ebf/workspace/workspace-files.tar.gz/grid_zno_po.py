from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
AXES = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 1, 1)]


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    results = []
    for axis in AXES:
        for start in (0.8, 1.2):
            tag = "".join(map(str, axis)) + ("lo" if start < 1 else "hi")
            out = ROOT / f"po_zno_{tag}.gpx"
            project = G2.G2Project(str(ROOT / "three_zno.gpx"), newgpx=str(out))
            hist = project.histogram(0)
            project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
            for value in hist.data["Instrument Parameters"][0].values():
                if isinstance(value, list) and len(value) > 2:
                    value[2] = False
            hist.data["Instrument Parameters"][0]["Polariz."][2] = True
            for value in hist.data["Sample Parameters"].values():
                if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
                    value[1] = False
            for i, phase in enumerate(project.phases()):
                phase.data["General"]["Cell"][0] = False
                for atom in phase.atoms():
                    atom.refinement_flags = " "
                hap = phase.data["Histograms"][hist.name]
                hap["Scale"][1] = True
                hap["Size"][2] = [False, False, False]
                hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
                hap["Pref.Ori."][2] = i < 2
            hap = project.phases()[2].data["Histograms"][hist.name]
            hap["Pref.Ori."][:4] = ["MD", start, True, list(axis)]
            project.set_Controls("parmMin", 0.7, variable="2:0:MD")
            project.set_Controls("parmMax", 1.4, variable="2:0:MD")
            project.set_Controls("cycles", 8)
            project.refine(makeBack=False)
            project.save()
            result = (hist.get_wR(), axis, hap["Pref.Ori."][1], out)
            results.append(result)
            print(result, flush=True)
    results.sort(key=lambda row: row[0])
    print("BEST", results[0], flush=True)
