from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def configure(project):
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}

    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for key in ("U", "W", "X", "SH/L", "Polariz."):
        hist.data["Instrument Parameters"][0][key][2] = True
    for key, lo, hi in (
        ("U", 0.0, 40.0), ("W", 2.0, 40.0), ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.1), ("Polariz.", 0.5, 1.0),
    ):
        project.set_Controls("parmMin", lo, variable=f":0:{key}")
        project.set_Controls("parmMax", hi, variable=f":0:{key}")

    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.data["Background"][0][1] = True

    for pidx, phase in enumerate(project.phases()):
        phase.data["General"]["Cell"][0] = True
        phase.set_refinements({"Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = True
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        if phase.name == "ZnO_wurtzite":
            hap["Mustrain"][2][0] = True
        elif phase.name == "WO3_monoclinic_2311041":
            hap["Mustrain"][2][0] = True
            hap["Mustrain"][2][1] = True
        for variable, lo, hi in (
            ("Scale", 0.0, 1000.0), ("Size;i", 0.04, 1.5),
            ("Mustrain;i", 0.0, 8000.0), ("Mustrain;a", 0.0, 32000.0),
            ("MD", 0.7, 1.4),
        ):
            project.set_Controls("parmMin", lo, variable=f"{pidx}:0:{variable}")
            project.set_Controls("parmMax", hi, variable=f"{pidx}:0:{variable}")
    return hist


if __name__ == "__main__":
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(source), newgpx=str(output))
    hist = configure(project)
    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    project.save()
    print("FINAL", output, hist.get_wR(), project.data["Covariance"]["data"].get("Rvals", {}).get("GOF"))
    print("instrument", {k: v[1] for k, v in hist.data["Instrument Parameters"][0].items() if k in ("Zero", "U", "W", "X", "SH/L", "Polariz.")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, phase.get_cell(), hap["Scale"], hap["Size"][:4], hap["Mustrain"][:4], hap["Pref.Ori."][:4])
