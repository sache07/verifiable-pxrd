from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
VALUES = (0.003, 0.005, 0.007, 0.009, 0.011, 0.014, 0.017, 0.020)


def prepare(project):
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.data["Instrument Parameters"][0]["Polariz."][2] = True
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        phase.set_refinements({"Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = True
    return hist


def scan(source, phase_name, tag):
    results = []
    for value in VALUES:
        out = ROOT / f"uiso_final_{tag}_{value:.3f}.gpx"
        project = G2.G2Project(str(source), newgpx=str(out))
        hist = prepare(project)
        phase = project.phase(phase_name)
        for atom in phase.atoms():
            atom.uiso = value
        project.set_Controls("cycles", 8)
        project.refine(makeBack=False)
        project.save()
        result = (hist.get_wR(), value, out)
        results.append(result)
        print(tag, result, flush=True)
    result = min(results)
    print("BEST", tag, result, flush=True)
    return result[2]


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    source = ROOT / "wo3_norm_2311041_001.gpx"
    # Keep the minor ZnO internal coordinate within the range reachable from
    # the wurtzite parent under the generator's stated coordinate mismatch.
    p = G2.G2Project(str(source), newgpx=str(ROOT / "uiso_scan_start.gpx"))
    p.phase("ZnO_wurtzite").atom("O1").coordinates = (1 / 3, 2 / 3, 0.3821)
    p.save()
    source = ROOT / "uiso_scan_start.gpx"
    source = scan(source, "WO3_monoclinic_2311041", "wo3")
    source = scan(source, "ZnWO4_wolframite", "znwo4")
    source = scan(source, "ZnO_wurtzite", "zno")
    shutil.copy2(source, ROOT / "uiso_final_best.gpx")
