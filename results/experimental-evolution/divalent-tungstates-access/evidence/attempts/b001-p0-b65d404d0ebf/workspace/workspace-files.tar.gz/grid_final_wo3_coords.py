from pathlib import Path
import numpy as np

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "uiso_final_best.gpx"
DELTAS = (0.003, 0.005, 0.008, 0.012, 0.018)


def prepare(project):
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.data["Instrument Parameters"][0]["Polariz."][2] = True
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        phase.set_refinements({"Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = True
    return hist


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    reference = G2.G2Project(str(SOURCE))
    phase_name = "WO3_monoclinic_2311041"
    ref_phase = reference.phase(phase_name)
    xyz0 = np.array([a.coordinates for a in ref_phase.atoms()], dtype=float)
    symbols = np.array([a.element for a in ref_phase.atoms()])
    pidx = [p.name for p in reference.phases()].index(phase_name)

    for delta in DELTAS:
        out = ROOT / f"wo3_coord_{delta:.3f}.gpx"
        project = G2.G2Project(str(SOURCE), newgpx=str(out))
        hist = prepare(project)
        phase = project.phase(phase_name)
        phase.set_refinements({"Atoms": {"all": "X"}})
        for i, xyz in enumerate(xyz0):
            for axis, value in zip("xyz", xyz):
                variable = f"{pidx}::dA{axis}:{i}"
                project.set_Controls("parmMin", float(value - delta), variable=variable)
                project.set_Controls("parmMax", float(value + delta), variable=variable)
        project.set_Controls("cycles", 12)
        project.refine(makeBack=False)
        project.save()

        xyz = np.array([a.coordinates for a in phase.atoms()], dtype=float)
        dfrac = xyz - xyz0
        dfrac -= np.rint(dfrac)
        direct, _ = G2lat.cell2AB(phase.data["General"]["Cell"][1:7])
        dcart = dfrac @ direct.T
        metrics = {
            element: (float(np.sqrt(np.mean(np.sum(dcart[symbols == element] ** 2, axis=1)))),
                      float(np.max(np.linalg.norm(dcart[symbols == element], axis=1))))
            for element in sorted(set(symbols))
        }
        print(delta, hist.get_wR(), metrics, out, flush=True)
