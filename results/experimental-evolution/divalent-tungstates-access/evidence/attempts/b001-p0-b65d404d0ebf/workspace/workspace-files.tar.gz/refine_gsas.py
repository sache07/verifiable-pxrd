from pathlib import Path
import json
import math
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
TRIAL = ROOT / "trial.gpx"


def controls(project, cycles=8):
    project.set_Controls("cycles", cycles)
    project.data["Controls"]["data"]["deriv type"] = "analytic Hessian"


def summary(project, label):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    print(f"\n--- {label}: wR={hist.get_wR()} GOF={project.data['Covariance']['data'].get('Rvals', {}).get('GOF')}")
    print("instrument", {k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.") if k in inst})
    print("sample", {k: sample[k][0] if isinstance(sample.get(k), list) else sample.get(k) for k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")})
    masses = []
    for p in project.phases():
        hap = p.data["Histograms"][hist.name]
        masses.append(hap["Scale"][0] * p.data["General"]["Mass"])
    total = sum(masses)
    for p, mass in zip(project.phases(), masses):
        hap = p.data["Histograms"][hist.name]
        print(
            p.name,
            "cell", p.get_cell(),
            "scale", hap["Scale"],
            "wt", mass / total if total else math.nan,
            "size", hap["Size"][:4],
            "mustrain", hap["Mustrain"][:4],
            "PO", hap["Pref.Ori."][:4],
        )


def build():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(TRIAL))
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
        fmthint="xye",
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    wo3_source = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c05/cif/1/52/89/1528915.cif")
    phases = [
        project.add_phase(str(ROOT / "start_znwo4.cif"), phasename="ZnWO4_wolframite", histograms=[hist], fmthint="CIF"),
        project.add_phase(str(wo3_source), phasename="WO3_monoclinic", histograms=[hist], fmthint="CIF"),
    ]
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 12,
            "coeffs": [1100.0] + [0.0] * 11,
            "refine": True,
        },
    })
    start_fracs = [0.85, 0.15]
    for phase, frac in zip(phases, start_fracs):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10000.0 * frac / phase.data["General"]["Mass"], True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.5
        hap["Size"][1][1] = 0.5
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][1] = 500.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Extinction"] = [0.0, False]
    controls(project, 8)
    project.save()
    summary(project, "built")
    return project


def do_refine(project):
    hist = project.histogram(0)
    phases = project.phases()

    # Scales and a smooth background.
    controls(project, 10)
    project.refine(makeBack=False)
    summary(project, "scales/background")

    # First align the common angular zero, then refine the phase cells.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine(makeBack=False)
    summary(project, "zero")

    for p in phases:
        p.set_refinements({"Cell": True})
    project.refine(makeBack=False)
    summary(project, "cells/zero")

    # Specimen displacement has a cos(theta) dependence distinct from zero.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.refine(makeBack=False)
    summary(project, "cells/zero/shift")

    # Profile terms. V is kept fixed at zero, matching the generation family.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for p in phases:
        p.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.5, "refine": True}})
        p.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    project.refine(makeBack=False)
    summary(project, "isotropic profiles")

    project.save()


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "all"
    if mode == "build":
        build()
    elif mode == "refine":
        do_refine(G2.G2Project(str(TRIAL)))
    else:
        do_refine(build())
