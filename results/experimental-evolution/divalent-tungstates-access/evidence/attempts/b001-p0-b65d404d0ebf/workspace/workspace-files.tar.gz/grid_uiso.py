from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
VALUES = (0.003, 0.005, 0.008, 0.011, 0.014, 0.017, 0.020)


def prepare(project):
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = True
    hist.data["Background"][0][1] = True
    return hist


def scan(source, phase_index, prefix):
    results = []
    for value in VALUES:
        out = ROOT / f"{prefix}_{value:.3f}.gpx"
        project = G2.G2Project(str(source), newgpx=str(out))
        hist = prepare(project)
        for atom in project.phases()[phase_index].atoms():
            atom.uiso = value
        project.set_Controls("cycles", 7)
        project.refine(makeBack=False)
        project.save()
        result = (hist.get_wR(), value, out)
        results.append(result)
        print(prefix, result, flush=True)
    results.sort(key=lambda row: row[0])
    print("BEST", prefix, results[0], flush=True)
    return results[0]


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    best_zn = scan(ROOT / "struct2.gpx", 0, "uiso_zn")
    best_wo = scan(best_zn[2], 1, "uiso_wo")
    shutil.copy2(best_wo[2], ROOT / "uiso_best.gpx")
