from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
AXES = [(1, 0, 0), (0, 1, 0), (0, 0, 1)]


def freeze_common(project):
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    for val in hist.data["Instrument Parameters"][0].values():
        if isinstance(val, list) and len(val) > 2:
            val[2] = False
    for val in hist.data["Sample Parameters"].values():
        if isinstance(val, list) and len(val) > 1 and isinstance(val[1], bool):
            val[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = False
    hist.data["Background"][0][1] = True
    return hist


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    results = []
    for axis in AXES:
        for axial_ratio in (0.5, 2.0):
            tag = "".join(map(str, axis)) + ("lo" if axial_ratio < 1 else "hi")
            output = ROOT / f"strain_wo_{tag}.gpx"
            project = G2.G2Project(str(ROOT / "profiles3.gpx"), newgpx=str(output))
            hist = freeze_common(project)
            phase = project.phases()[1]
            hap = phase.data["Histograms"][hist.name]
            equatorial = hap["Mustrain"][1][0]
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1][0] = equatorial
            hap["Mustrain"][1][1] = equatorial * axial_ratio
            hap["Mustrain"][2][0] = True
            hap["Mustrain"][2][1] = True
            hap["Mustrain"][3] = list(axis)
            project.set_Controls("parmMin", 0.0, variable="1:0:Mustrain;i")
            project.set_Controls("parmMax", 8000.0, variable="1:0:Mustrain;i")
            project.set_Controls("parmMin", 0.0, variable="1:0:Mustrain;a")
            project.set_Controls("parmMax", 32000.0, variable="1:0:Mustrain;a")
            project.set_Controls("cycles", 10)
            project.refine(makeBack=False)
            project.save()
            values = tuple(hap["Mustrain"][1][:2])
            result = (hist.get_wR(), axis, values, output)
            results.append(result)
            print(result, flush=True)
    results.sort(key=lambda row: row[0])
    print("BEST", results[0], flush=True)
