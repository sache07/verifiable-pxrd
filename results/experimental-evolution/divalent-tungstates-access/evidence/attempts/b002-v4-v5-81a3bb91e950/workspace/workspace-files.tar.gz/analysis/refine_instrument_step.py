from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2sc


BOUNDS = {
    "Zero": (-0.05, 0.05),
    "U": (0.0, 40.0),
    "W": (2.0, 40.0),
    "X": (0.1, 6.0),
    "SH/L": (0.005, 0.10),
    "Polariz.": (0.5, 1.0),
}

parser = argparse.ArgumentParser()
parser.add_argument("input_gpx")
parser.add_argument("output_gpx")
parser.add_argument("parameters", nargs="+")
parser.add_argument("--cycles", type=int, default=12)
args = parser.parse_args()

out = Path(args.output_gpx).resolve()
out.parent.mkdir(parents=True, exist_ok=True)
project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
project.set_Controls("cycles", args.cycles)
project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
hist = project.histogram(0)

# Atomic coordinates are frozen after the accepted structural stages. Keep
# each profile test restricted to the explicitly requested parameter family.
for phase in project.phases():
    phase.set_refinements({"Atoms": {atom.label: " " for atom in phase.atoms()}})
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y",
                               "SH/L", "Polariz."]}
)
hist.set_refinements({"Instrument Parameters": args.parameters})
for parameter in args.parameters:
    lo, hi = BOUNDS[parameter]
    variable = f":{hist.id}:{parameter}"
    project.set_Controls("parmMin", lo, variable=variable)
    project.set_Controls("parmMax", hi, variable=variable)

project.save()
project.refine(printFile=str(out.with_suffix(".lst")))
info = {
    "residuals": hist.residuals,
    "mass_fractions": hist.ComputeMassFracs(),
    "instrument": {
        key: value for key, value in hist.InstrumentParameters.items()
        if key in BOUNDS or key in ("V", "Y")
    },
    "cells": {phase.name: phase.get_cell() for phase in project.phases()},
}
out.with_suffix(".json").write_text(json.dumps(info, indent=2) + "\n")
print(json.dumps(info, sort_keys=True))
