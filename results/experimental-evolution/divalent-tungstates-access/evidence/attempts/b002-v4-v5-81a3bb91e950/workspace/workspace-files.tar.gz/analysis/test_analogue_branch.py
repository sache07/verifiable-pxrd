from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "branches" / "wo3-1528915_mn3o4-none.gpx"

parser = argparse.ArgumentParser()
parser.add_argument("model")
args = parser.parse_args()

source = ROOT / "analysis" / "analogues" / f"{args.model}.cif"
outdir = ROOT / "analysis" / "topology_branches" / args.model
outdir.mkdir(parents=True, exist_ok=True)
gpx = G2sc.G2Project(str(BASE), newgpx=str(outdir / "working.gpx"))
hist = gpx.histogram(0)
gpx.set_Controls("cycles", 8)
candidate = gpx.add_phase(
    str(source), phasename=args.model, histograms=[hist], fmthint="CIF")
candidate.getHAPvalues(hist)["Scale"][:] = [8.0, True]
initial_cell = candidate.get_cell().copy()

for phase in gpx.phases():
    phase.getHAPvalues(hist)["Scale"][1] = True
    gpx.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")


def snapshot(stage):
    gpx.save(str(outdir / f"{stage}.gpx"))
    h = gpx.histogram(0)
    p = gpx.phase(args.model)
    info = {
        "stage": stage,
        "Rwp": h.residuals.get("wR"),
        "residuals": h.residuals,
        "mass_fractions": h.ComputeMassFracs(),
        "candidate_scale": p.getHAPvalues(h)["Scale"][0],
        "candidate_cell": p.get_cell(),
        "shift_um": h.SampleParameters["Shift"][0],
        "atoms": [{
            "label": a.label, "element": a.element,
            "coordinates": list(a.coordinates), "flags": a.refinement_flags,
        } for a in p.atoms()],
    }
    (outdir / f"{stage}.json").write_text(json.dumps(info, indent=2) + "\n")
    p.export_CIF(str(outdir / f"{stage}.cif"))
    print("STAGE", json.dumps(info, sort_keys=True))
    return info


gpx.save()
gpx.refine(printFile=str(outdir / "01_scale.lst"))
snapshot("01_scale")

candidate.set_refinements({"Cell": True})
gpx.refine(printFile=str(outdir / "02_cell.lst"))
snapshot("02_cell")

# Refine candidate cation positions first; accepted-phase coordinates remain
# fixed so every topology receives the same amount of flexibility.
heavy = {a.label: "X" for a in candidate.atoms() if a.element != "O"}
candidate.set_refinements({"Atoms": heavy})
gpx.refine(printFile=str(outdir / "03_heavy.lst"))
snapshot("03_heavy")

oxygen = {a.label: "X" for a in candidate.atoms() if a.element == "O"}
candidate.set_refinements({"Atoms": oxygen})
gpx.refine(printFile=str(outdir / "04_oxygen.lst"))
final = snapshot("04_oxygen")

final["initial_cell"] = initial_cell
print("SUMMARY", json.dumps(final, sort_keys=True))
