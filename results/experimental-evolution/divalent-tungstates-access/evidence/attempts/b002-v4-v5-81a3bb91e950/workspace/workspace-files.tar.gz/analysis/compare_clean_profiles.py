from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "physical_refinement" / "12_shl.gpx"
OUTDIR = ROOT / "analysis" / "physical_refinement" / "clean_profiles"
OUTDIR.mkdir(parents=True, exist_ok=True)

for shl, candidate_strain in ((0.005, 1000.0), (0.005, 0.0),
                              (0.03, 1000.0)):
    tag = f"shl_{shl:.3f}_candidate_strain_{candidate_strain:.0f}"
    out = OUTDIR / f"{tag}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"].setdefault(
        "parmFrozen", {})["FrozenList"] = []
    hist = project.histogram(0)
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y",
                                   "SH/L", "Polariz."]}
    )
    hist.InstrumentParameters["SH/L"][1] = shl
    for phase in project.phases():
        phase.set_refinements(
            {"Atoms": {atom.label: " " for atom in phase.atoms()}}
        )
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
        phase.getHAPvalues(hist)["Pref.Ori."][1] = 1.0
    candidate = project.phase("Mn3WO6_C2c_Co3TeO6")
    candidate.getHAPvalues(hist)["Mustrain"][1][0] = candidate_strain
    project.save()
    project.refine(printFile=str(out.with_suffix(".lst")))
    info = {
        "shl": shl,
        "candidate_strain": candidate_strain,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "shift_um": hist.SampleParameters["Shift"][0],
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "hap": {
            phase.name: {
                "Size": phase.getHAPvalues(hist)["Size"],
                "Mustrain": phase.getHAPvalues(hist)["Mustrain"],
            }
            for phase in project.phases()
        },
    }
    out.with_suffix(".json").write_text(json.dumps(info, indent=2) + "\n")
    print(json.dumps(info, sort_keys=True))
