from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "branches" / "wo3-1528915_mn3o4-none.gpx"

parser = argparse.ArgumentParser()
parser.add_argument("cif_id")
parser.add_argument("--name")
parser.add_argument("--scale", type=float, default=5.0)
args = parser.parse_args()

tag = args.name or args.cif_id
out = ROOT / "analysis" / "additions" / f"{tag}.gpx"
out.parent.mkdir(parents=True, exist_ok=True)
gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
hist = gpx.histogram(0)
gpx.set_Controls("cycles", 8)
phase = gpx.add_phase(
    str(ROOT / "references" / f"{args.cif_id}.cif"),
    phasename=tag, histograms=[hist], fmthint="CIF")
phase.getHAPvalues(hist)["Scale"][:] = [args.scale, True]
for p in gpx.phases():
    p.getHAPvalues(hist)["Scale"][1] = True
    gpx.set_Controls("parmMin", 0.0, variable=f"{p.id}:0:Scale")
gpx.save()
gpx.refine(printFile=str(out.with_suffix(".lst")))
gpx.save()

summary = {
    "tag": tag,
    "residuals": gpx.histogram(0).residuals,
    "mass_fractions": gpx.histogram(0).ComputeMassFracs(),
    "phases": [{
        "name": p.name,
        "scale": p.getHAPvalues(gpx.histogram(0))["Scale"][0],
        "cell": p.get_cell(),
    } for p in gpx.phases()],
}
print("SUMMARY", json.dumps(summary, sort_keys=True))
