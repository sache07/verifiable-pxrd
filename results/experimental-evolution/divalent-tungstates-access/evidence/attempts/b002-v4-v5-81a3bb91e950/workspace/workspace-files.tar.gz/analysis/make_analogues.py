from pathlib import Path
import json

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "analysis" / "analogues"
OUT.mkdir(parents=True, exist_ok=True)

# One chemically nearest parent is retained for each serious coordination/
# symmetry topology. Scale factors are modest ionic-size starting guesses and
# are not treated as observations.
MODELS = {
    "Mn2WO6_Pbcn_Fe2WO6": {
        "parent": "2310464", "replace": {"Fe": "Mn"}, "scale": 1.000,
        "topology": "Pbcn edge-sharing octahedral Fe2WO6 type",
    },
    "Mn2WO6_P42mnm_Cr2WO6": {
        "parent": "1530909", "replace": {"Cr": "Mn"}, "scale": 1.010,
        "topology": "P42/mnm trirutile Cr2WO6 type",
    },
    "Mn3WO6_R3_Ni3TeO6": {
        "parent": "2211031", "replace": {"Ni": "Mn", "Te": "W"}, "scale": 1.035,
        "topology": "R3 corundum-related Ni3TeO6 type",
    },
    "Mn3WO6_C2c_Co3TeO6": {
        "parent": "2015468", "replace": {"Co": "Mn", "Te": "W"}, "scale": 1.020,
        "topology": "C2/c Co3TeO6 type",
    },
    "Mn3WO6_Pa3_Cu3WO6": {
        "parent": "1527404", "replace": {"Cu": "Mn"}, "scale": 1.020,
        "topology": "Pa-3 cubic Cu3WO6 type",
    },
    "Mn3WO6_Ia3_Cu3TeO6": {
        "parent": "1557963", "replace": {"Cu": "Mn", "Te": "W"}, "scale": 1.020,
        "topology": "Ia-3 cubic Cu3TeO6 type",
    },
    "Mn3WO6_P21c_Ca3WO6": {
        "parent": "1563081", "replace": {"Ca": "Mn"}, "scale": 0.965,
        "topology": "P21/c Ca3WO6 type",
    },
}

provenance = {}
for name, spec in MODELS.items():
    source = ROOT / "references" / f"{spec['parent']}.cif"
    structure = Structure.from_file(source, primitive=False)
    structure.replace_species(spec["replace"])
    if spec["scale"] != 1.0:
        structure.scale_lattice(structure.volume * spec["scale"] ** 3)
    target = OUT / f"{name}.cif"
    CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(target)
    check = Structure.from_file(target, primitive=False)
    provenance[name] = {
        **spec,
        "cif": str(target.relative_to(ROOT)),
        "formula": check.composition.reduced_formula,
        "space_group": check.get_space_group_info(),
        "cell": list(check.lattice.abc) + list(check.lattice.angles),
    }

(OUT / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
for name, record in provenance.items():
    print(name, record)

# The Ca3WO6 parent uses the P 21/n setting. pymatgen standardizes it to a
# P 21/c coordinate setting but writes the original n-glide operators, which
# GSAS-II correctly rejects as inconsistent. Preserve the published setting
# for this screening model and make only the explicit chemistry/cell edits.
source_text = (ROOT / "references" / "1563081.cif").read_text()
source_text = source_text.replace("Ca", "Mn")
for old, new in {
    "_cell_length_a                   5.55175(26)": "_cell_length_a                   5.35743875",
    "_cell_length_b                   5.81004(27)": "_cell_length_b                   5.60668860",
    "_cell_length_c                   8.0066(4)": "_cell_length_c                   7.72636900",
    "_cell_volume                     258.26(2)": "_cell_volume                     232.07944",
    "_chemical_formula_weight         400.08": "_chemical_formula_weight         444.66",
}.items():
    source_text = source_text.replace(old, new)
(OUT / "Mn3WO6_P21c_Ca3WO6.cif").write_text(source_text)
