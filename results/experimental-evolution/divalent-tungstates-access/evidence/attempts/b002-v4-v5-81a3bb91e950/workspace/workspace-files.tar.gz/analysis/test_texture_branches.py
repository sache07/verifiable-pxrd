from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("input_gpx")
parser.add_argument("phase")
parser.add_argument("tag")
args = parser.parse_args()

root = Path(__file__).resolve().parents[1]
outdir = root / "analysis" / "physical_refinement" / "texture" / args.tag
outdir.mkdir(parents=True, exist_ok=True)

for axis in ((1, 0, 0), (0, 1, 0), (0, 0, 1)):
    label = "".join(str(value) for value in axis)
    out = outdir / f"axis_{label}.gpx"
    project = G2sc.G2Project(
        str(Path(args.input_gpx).resolve()), newgpx=str(out)
    )
    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"].setdefault(
        "parmFrozen", {}
    )["FrozenList"] = []
    hist = project.histogram(0)
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y",
                                   "SH/L", "Polariz."]}
    )
    for phase in project.phases():
        phase.set_refinements(
            {"Atoms": {atom.label: " " for atom in phase.atoms()}}
        )
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    target = project.phase(args.phase)
    po = target.getHAPvalues(hist)["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(axis)
    variable = f"{target.id}:{hist.id}:MD"
    project.set_Controls("parmMin", 0.7, variable=variable)
    project.set_Controls("parmMax", 1.4, variable=variable)
    project.save()
    project.refine(printFile=str(out.with_suffix(".lst")))
    info = {
        "axis": axis,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "MD": target.getHAPvalues(hist)["Pref.Ori."],
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }
    out.with_suffix(".json").write_text(json.dumps(info, indent=2) + "\n")
    print(json.dumps(info, sort_keys=True))
