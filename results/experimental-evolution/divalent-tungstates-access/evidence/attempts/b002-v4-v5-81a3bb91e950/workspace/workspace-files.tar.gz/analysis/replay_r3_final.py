from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = (
    ROOT / "analysis" / "physical_refinement" / "final_background"
    / "order_36.gpx"
)
R3_CIF = (
    ROOT / "analysis" / "topology_branches" / "Mn3WO6_R3_Ni3TeO6"
    / "export_01_scale" / "02_Mn3WO6_R3_Ni3TeO6.cif"
)
OUTDIR = ROOT / "analysis" / "physical_refinement" / "r3_replay"
OUTDIR.mkdir(parents=True, exist_ok=True)
OLD_NAME = "Mn3WO6_C2c_Co3TeO6"
NEW_NAME = "Mn3WO6_R3_Ni3TeO6"


def clear_flexibility(project):
    hist = project.histogram(0)
    project.data["Controls"]["data"].setdefault(
        "parmFrozen", {})["FrozenList"] = []
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y",
                                   "SH/L", "Polariz."]}
    )
    for phase in project.phases():
        phase.set_refinements(
            {"Atoms": {atom.label: " " for atom in phase.atoms()}}
        )
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )


def summarize(project):
    hist = project.histogram(0)
    phase = project.phase(NEW_NAME)
    return {
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "candidate_cell": phase.get_cell(),
        "candidate_HAP": phase.getHAPvalues(hist),
    }


# Replace only the minority topology, preserving the final shared phases,
# instrument/profile, background and accepted atomic coordinates.
initial_path = OUTDIR / "00_replaced.gpx"
project = G2sc.G2Project(str(BASE), newgpx=str(initial_path))
hist = project.histogram(0)
del project.data["Phases"][OLD_NAME]
for names in project.names:
    if names and names[0] == "Phases":
        names.remove(OLD_NAME)
hist.data["Reflection Lists"].pop(OLD_NAME, None)
candidate = project.add_phase(
    str(R3_CIF), phasename=NEW_NAME, histograms=[hist], fmthint="CIF"
)
clear_flexibility(project)
candidate.getHAPvalues(hist)["Scale"][:] = [4.0, True]
candidate.getHAPvalues(hist)["Mustrain"][1][0] = 0.0
candidate.getHAPvalues(hist)["Size"][1][0] = 0.05
candidate.set_refinements({"Cell": False})
for phase in project.phases():
    phase.getHAPvalues(hist)["Scale"][1] = True
    project.set_Controls(
        "parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale"
    )
project.set_Controls("cycles", 16)
project.save()

scale_path = OUTDIR / "01_scale.gpx"
project = G2sc.G2Project(str(initial_path), newgpx=str(scale_path))
project.refine(printFile=str(scale_path.with_suffix(".lst")))
scale_info = summarize(project)
scale_path.with_suffix(".json").write_text(
    json.dumps(scale_info, indent=2) + "\n"
)
print("SCALE", json.dumps(scale_info, sort_keys=True))

cell_path = OUTDIR / "02_cell.gpx"
project = G2sc.G2Project(str(scale_path), newgpx=str(cell_path))
clear_flexibility(project)
project.phase(NEW_NAME).set_refinements({"Cell": True})
project.set_Controls("cycles", 20)
project.save()
project.refine(printFile=str(cell_path.with_suffix(".lst")))
cell_info = summarize(project)
cell_path.with_suffix(".json").write_text(
    json.dumps(cell_info, indent=2) + "\n"
)
print("CELL", json.dumps(cell_info, sort_keys=True))

size_path = OUTDIR / "03_size.gpx"
project = G2sc.G2Project(str(cell_path), newgpx=str(size_path))
clear_flexibility(project)
hist = project.histogram(0)
candidate = project.phase(NEW_NAME)
candidate.set_HAP_refinements(
    {"Size": {"type": "isotropic", "refine": True}}
)
project.set_Controls(
    "parmMin", 0.04, variable=f"{candidate.id}:{hist.id}:Size;i"
)
project.set_Controls(
    "parmMax", 1.5, variable=f"{candidate.id}:{hist.id}:Size;i"
)
project.set_Controls("cycles", 20)
project.save()
project.refine(printFile=str(size_path.with_suffix(".lst")))
size_info = summarize(project)
size_path.with_suffix(".json").write_text(
    json.dumps(size_info, indent=2) + "\n"
)
print("SIZE", json.dumps(size_info, sort_keys=True))
candidate.export_CIF(str(OUTDIR / "03_size_candidate.cif"))
