import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("gpx")
parser.add_argument("outdir")
args = parser.parse_args()

project = G2sc.G2Project(args.gpx)
outdir = Path(args.outdir)
outdir.mkdir(parents=True, exist_ok=True)
for i, phase in enumerate(project.phases()):
    path = outdir / f"{i:02d}_{phase.name}.cif"
    phase.export_CIF(str(path))
    print(path)
