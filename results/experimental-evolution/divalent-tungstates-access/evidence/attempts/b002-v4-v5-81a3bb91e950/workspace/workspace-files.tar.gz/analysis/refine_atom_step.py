from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("input_gpx")
parser.add_argument("output_gpx")
parser.add_argument("phase")
parser.add_argument("atoms", nargs="+")
parser.add_argument("--cycles", type=int, default=12)
args = parser.parse_args()

out = Path(args.output_gpx).resolve()
out.parent.mkdir(parents=True, exist_ok=True)
project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
project.set_Controls("cycles", args.cycles)

# Keep structural flexibility limited to the requested sites at each stage.
for phase in project.phases():
    phase.set_refinements({"Atoms": {atom.label: " " for atom in phase.atoms()}})
target = project.phase(args.phase)
target.set_refinements({"Atoms": {label: "X" for label in args.atoms}})

before = {
    phase.name: {atom.label: list(atom.coordinates) for atom in phase.atoms()}
    for phase in project.phases()
}
project.save()
project.refine(printFile=str(out.with_suffix(".lst")))

hist = project.histogram(0)
after = {
    phase.name: {atom.label: list(atom.coordinates) for atom in phase.atoms()}
    for phase in project.phases()
}
info = {
    "residuals": hist.residuals,
    "mass_fractions": hist.ComputeMassFracs(),
    "before": before,
    "after": after,
    "cells": {phase.name: phase.get_cell() for phase in project.phases()},
}
out.with_suffix(".json").write_text(json.dumps(info, indent=2) + "\n")
export_dir = out.with_suffix("")
export_dir.mkdir(exist_ok=True)
for index, phase in enumerate(project.phases()):
    phase.export_CIF(str(export_dir / f"{index:02d}_{phase.name}.cif"))
print(json.dumps(info, sort_keys=True))
