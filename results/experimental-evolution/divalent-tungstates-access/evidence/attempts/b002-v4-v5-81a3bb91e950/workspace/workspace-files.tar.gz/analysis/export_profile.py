import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("gpx")
parser.add_argument("csv")
args = parser.parse_args()

project = G2sc.G2Project(args.gpx)
hist = project.histogram(0)
columns = [hist.getdata(k) for k in
           ("X", "Yobs", "Ycalc", "Background", "Residual", "Yweight")]
arr = np.column_stack(columns)
np.savetxt(
    args.csv,
    arr,
    delimiter=",",
    header="two_theta_deg,observed,calculated,background,difference,weight",
    comments="",
    fmt="%.10g",
)
print(hist.residuals)
