from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "checkpoint_01_cell_shift.gpx"

parser = argparse.ArgumentParser()
parser.add_argument("--wo3", choices=["none", "1528915", "2106293", "1010618"])
parser.add_argument("--mn3o4", choices=["none", "9001963", "1541183"])
args = parser.parse_args()

tag = f"wo3-{args.wo3}_mn3o4-{args.mn3o4}"
out = ROOT / "analysis" / "branches" / f"{tag}.gpx"
out.parent.mkdir(parents=True, exist_ok=True)

gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
hist = gpx.histogram(0)
gpx.set_Controls("cycles", 8)

# Keep the physically admissible common instrument profile fixed while phase
# identity is tested. Background, common shift and all scales remain active.
new_phases = []
if args.wo3 != "none":
    p = gpx.add_phase(
        str(ROOT / "references" / f"{args.wo3}.cif"),
        phasename=f"WO3_{args.wo3}", histograms=[hist], fmthint="CIF")
    p.getHAPvalues(hist)["Scale"][:] = [30.0, True]
    new_phases.append(p)
if args.mn3o4 != "none":
    p = gpx.add_phase(
        str(ROOT / "references" / f"{args.mn3o4}.cif"),
        phasename=f"Mn3O4_{args.mn3o4}", histograms=[hist], fmthint="CIF")
    p.getHAPvalues(hist)["Scale"][:] = [8.0, True]
    new_phases.append(p)

for phase in gpx.phases():
    phase.getHAPvalues(hist)["Scale"][1] = True
    gpx.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")

gpx.save()
gpx.refine(printFile=str(out.with_suffix(".scale.lst")))
scale_rwp = gpx.histogram(0).residuals.get("wR")

# Comparable cell relaxation for every phase. Coordinates and profile terms
# are fixed at this screening stage.
for phase in gpx.phases():
    phase.set_refinements({"Cell": True})
gpx.refine(printFile=str(out.with_suffix(".cell.lst")))
gpx.save()

summary = {
    "tag": tag,
    "scale_only_Rwp": scale_rwp,
    "residuals": gpx.histogram(0).residuals,
    "shift_um": gpx.histogram(0).SampleParameters["Shift"][0],
    "phases": [],
}
for phase in gpx.phases():
    summary["phases"].append({
        "name": phase.name,
        "composition": phase.composition,
        "scale": phase.getHAPvalues(gpx.histogram(0))["Scale"][0],
        "cell": phase.get_cell(),
    })
print("SUMMARY", json.dumps(summary, sort_keys=True))
