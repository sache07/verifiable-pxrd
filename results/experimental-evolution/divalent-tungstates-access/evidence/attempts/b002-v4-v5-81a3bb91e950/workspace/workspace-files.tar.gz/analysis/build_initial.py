from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "analysis" / "mnwo4_initial.gpx"

gpx = G2sc.G2Project(newgpx=str(OUT))
hist = gpx.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "analysis" / "cu_ka.instprm"),
    fmthint="comma",
)
phase = gpx.add_phase(
    str(ROOT / "references" / "1520200.cif"),
    phasename="MnWO4_wolframite",
    histograms=[hist],
    fmthint="CIF",
)

hist.Limits("lower", 9.90343322)
hist.Limits("upper", 100.09455322)
hist.data["Background"][0] = ["chebyschev-1", True, 12] + [1100.0] + [0.0] * 11

# Reflection geometry: the specimen displacement parameter is the physically
# relevant common angular correction. The phase scale is refined first.
hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
hist.data["Sample Parameters"]["Scale"] = [1.0, False]
hist.data["Sample Parameters"]["Shift"] = [0.0, False]

gpx.set_Controls("cycles", 8)
gpx.set_refinement(
    {
        "set": {
            "Background": {"refine": True, "no. coeffs": 12},
            "Scale": True,
        }
    },
    histogram=hist,
    phase=phase,
)
gpx.save()

print("histogram", hist.name)
print("phase", phase.name, phase.composition, phase.get_cell())
print("instrument", hist.InstrumentParameters)
print("sample", hist.SampleParameters)
print("background", hist.Background)
print("HAP", phase.getHAPvalues(hist))
for atom in phase.atoms():
    print("atom", atom.label, atom.element, atom.coordinates, atom.occupancy,
          atom.data)

gpx.refine(printFile=str(ROOT / "analysis" / "mnwo4_initial.lst"))
print("residuals", gpx.histogram(0).residuals)
print("cell", gpx.phase(0).get_cell())
print("HAP", gpx.phase(0).getHAPvalues(gpx.histogram(0)))
gpx.save()
