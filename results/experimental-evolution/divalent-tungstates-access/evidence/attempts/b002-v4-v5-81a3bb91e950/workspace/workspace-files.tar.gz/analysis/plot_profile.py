import argparse

import matplotlib.pyplot as plt
import numpy as np


parser = argparse.ArgumentParser()
parser.add_argument("csv")
parser.add_argument("png")
args = parser.parse_args()

d = np.genfromtxt(args.csv, delimiter=",", names=True)
fig, axes = plt.subplots(4, 1, figsize=(14, 11), constrained_layout=True)
windows = [(9.9, 32), (32, 55), (55, 78), (78, 100.1)]
for ax, (lo, hi) in zip(axes, windows):
    use = (d["two_theta_deg"] >= lo) & (d["two_theta_deg"] <= hi)
    ax.plot(d["two_theta_deg"][use], d["observed"][use], lw=0.8, c="black", label="observed")
    ax.plot(d["two_theta_deg"][use], d["calculated"][use], lw=0.8, c="red", label="calculated")
    ax.plot(d["two_theta_deg"][use], d["difference"][use] - 2500, lw=0.6, c="blue", label="difference - 2500")
    ax.set_xlim(lo, hi)
    ax.set_ylabel("counts")
axes[-1].set_xlabel(r"2$\theta$ (deg)")
axes[0].legend(ncol=3, fontsize=8)
fig.savefig(args.png, dpi=160)
