from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "physical_refinement" / "18_polarization_clean.gpx"
OUTDIR = ROOT / "analysis" / "physical_refinement" / "final_background"
OUTDIR.mkdir(parents=True, exist_ok=True)

for order in (24, 30, 36):
    out = OUTDIR / f"order_{order:02d}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    project.set_Controls("cycles", 16)
    project.data["Controls"]["data"].setdefault(
        "parmFrozen", {})["FrozenList"] = []
    hist = project.histogram(0)
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y",
                                   "SH/L", "Polariz."]}
    )
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "no. coeffs": order,
                        "refine": True}}
    )
    for phase in project.phases():
        phase.set_refinements(
            {"Atoms": {atom.label: " " for atom in phase.atoms()}}
        )
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    project.save()
    project.refine(printFile=str(out.with_suffix(".lst")))
    info = {
        "order": order,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "background": hist.Background[0],
    }
    out.with_suffix(".json").write_text(json.dumps(info, indent=2) + "\n")
    print(json.dumps(info, sort_keys=True))
