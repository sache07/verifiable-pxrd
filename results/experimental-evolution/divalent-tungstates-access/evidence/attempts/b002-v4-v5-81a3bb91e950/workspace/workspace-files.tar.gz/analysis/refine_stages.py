from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
gpx = G2sc.G2Project(str(ROOT / "analysis" / "mnwo4_initial.gpx"))
hist = gpx.histogram(0)
phase = gpx.phase(0)
gpx.set_Controls("cycles", 10)


def report(tag):
    h = gpx.histogram(0)
    p = gpx.phase(0)
    print("\nSTAGE", tag)
    print("residuals", h.residuals)
    print("cell", p.get_cell())
    print("instrument", {k: v for k, v in h.InstrumentParameters.items()
                         if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")})
    print("sample", {k: h.SampleParameters[k] for k in
                     ("Shift", "SurfRoughA", "SurfRoughB")})
    print("HAP", {k: p.getHAPvalues(h)[k] for k in
                  ("Scale", "Pref.Ori.", "Size", "Mustrain")})
    for atom in p.atoms():
        print("atom", atom.label, atom.coordinates, atom.refinement_flags,
              atom.adp_flag, atom.ADP)


def run(tag):
    path = ROOT / "analysis" / f"checkpoint_{tag}.gpx"
    gpx.save(str(path))
    gpx.refine(printFile=str(ROOT / "analysis" / f"checkpoint_{tag}.lst"))
    report(tag)
    gpx.save(str(path))


# Peak positions: refine specimen displacement and the symmetry-constrained cell.
hist.set_refinements({"Sample Parameters": ["Shift"]})
phase.set_refinements({"Cell": True})
run("01_cell_shift")

# Peak widths/asymmetry. V and Y remain zero as in the laboratory model.
hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
run("02_profile")

# Heavy cations first, then oxygen coordinates. Site symmetry limits the actual
# coordinate degrees of freedom even though GSAS-II uses the generic X flag.
phase.set_refinements({"Atoms": {"Mn1": "X", "W1": "X"}})
run("03_heavy")
phase.set_refinements({"Atoms": {"O1": "X", "O2": "X"}})
run("04_oxygen")
