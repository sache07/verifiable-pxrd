from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = (
    ROOT
    / "analysis"
    / "topology_branches"
    / "Mn3WO6_C2c_Co3TeO6"
    / "01_scale.gpx"
)
OUTDIR = ROOT / "analysis" / "physical_refinement" / "background"
OUTDIR.mkdir(parents=True, exist_ok=True)


def summarize(project):
    hist = project.histogram(0)
    return {
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "background": hist.Background[0],
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "shift_um": hist.SampleParameters["Shift"][0],
    }


for order in (8, 12, 18, 24):
    out = OUTDIR / f"background_{order:02d}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "no. coeffs": order,
                        "refine": True}}
    )
    project.save()
    project.refine(printFile=str(out.with_suffix(".lst")))
    info = summarize(project)
    out.with_suffix(".json").write_text(json.dumps(info, indent=2) + "\n")
    print(order, json.dumps(info, sort_keys=True))
