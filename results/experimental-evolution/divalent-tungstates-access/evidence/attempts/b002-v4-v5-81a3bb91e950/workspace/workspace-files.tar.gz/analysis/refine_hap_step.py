from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("input_gpx")
parser.add_argument("output_gpx")
parser.add_argument("kind", choices=("Size", "Mustrain"))
parser.add_argument("phases", nargs="+")
parser.add_argument("--cycles", type=int, default=12)
args = parser.parse_args()

out = Path(args.output_gpx).resolve()
out.parent.mkdir(parents=True, exist_ok=True)
project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
project.set_Controls("cycles", args.cycles)
project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
hist = project.histogram(0)

hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y",
                               "SH/L", "Polariz."]}
)
for phase in project.phases():
    phase.set_refinements({"Atoms": {atom.label: " " for atom in phase.atoms()}})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True})

for name in args.phases:
    phase = project.phase(name)
    phase.set_HAP_refinements(
        {args.kind: {"type": "isotropic", "refine": True}}
    )
    suffix = "Size;i" if args.kind == "Size" else "Mustrain;i"
    variable = f"{phase.id}:{hist.id}:{suffix}"
    if args.kind == "Size":
        project.set_Controls("parmMin", 0.04, variable=variable)
        project.set_Controls("parmMax", 1.5, variable=variable)
    else:
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 8000.0, variable=variable)

project.save()
project.refine(printFile=str(out.with_suffix(".lst")))
info = {
    "residuals": hist.residuals,
    "mass_fractions": hist.ComputeMassFracs(),
    "hap": {
        phase.name: {
            "Size": phase.getHAPvalues(hist)["Size"],
            "Mustrain": phase.getHAPvalues(hist)["Mustrain"],
        }
        for phase in project.phases()
    },
    "cells": {phase.name: phase.get_cell() for phase in project.phases()},
}
out.with_suffix(".json").write_text(json.dumps(info, indent=2) + "\n")
print(json.dumps(info, sort_keys=True))
