from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


gpx_path = ROOT / "initial.gpx"
gpx = G2sc.G2Project(newgpx=str(gpx_path))
hist = gpx.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "instrument.instprm"),
    fmthint="comma",
)
ca = gpx.add_phase(
    str(cod_path("7219229")),
    phasename="CaWO4_scheelite",
    histograms=[hist],
    fmthint="CIF",
)
wo = gpx.add_phase(
    str(cod_path("2311041")),
    phasename="WO3_monoclinic",
    histograms=[hist],
    fmthint="CIF",
)
hist.data["Sample Parameters"]["Shift"][0] = 500.0
hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
hist.set_refinements({
    "Background": {
        "type": "chebyschev-1",
        "refine": True,
        "no. coeffs": 15,
        "coeffs": [900.0] + [0.0] * 14,
    }
})
for phase in (ca, wo):
    phase.HAPvalue("Scale", 1.0)
    phase.set_HAP_refinements({"Scale": True})

print("histogram", hist.name)
print("limits", hist.data["Limits"])
print("instrument", hist.data["Instrument Parameters"])
print("sample", hist.data["Sample Parameters"])
print("background", hist.data["Background"])
for phase in gpx.phases():
    print("phase", phase.name)
    print("cell", phase.data["General"]["Cell"])
    print("atom pointers", phase.data["General"]["AtomPtrs"])
    for atom in phase.atoms():
        print("atom", atom.label, atom.element, atom.coordinates, atom.occupancy, atom.uiso, atom.refinement_flags)
    print("HAP", json.dumps(phase.getHAPvalues(hist.name), default=str, indent=2))

gpx.set_Controls("cycles", 3)
gpx.save()
print("saved", gpx_path)
