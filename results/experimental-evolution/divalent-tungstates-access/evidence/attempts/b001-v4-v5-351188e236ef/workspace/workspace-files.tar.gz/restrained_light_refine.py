from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIImath as G2mth
from GSASII import GSASIIlattice as G2lat

from experiment_refine import deactivate


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--weight", type=float, default=10.0)
    parser.add_argument("--esd", type=float, default=0.04)
    parser.add_argument("--cycles", type=int, default=10)
    args = parser.parse_args()

    output = Path(args.output).resolve()
    output.parent.mkdir(exist_ok=True)
    gpx = G2sc.G2Project(gpxfile=args.input, newgpx=str(output))
    deactivate(gpx)
    wo = gpx.phase(1)
    for atom in wo.atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"

    # Preserve each distinct W--O distance from the accepted heavy-atom
    # checkpoint while allowing oxygen positions to respond to the profile.
    gpx.data["Restraints"]["data"][wo.name] = {
        "Bond": {"wtFactor": args.weight, "Range": 1.30, "Bonds": [], "Use": True}
    }
    watoms = [a for a in wo.atoms() if a.element == "W"]
    oatoms = [a for a in wo.atoms() if a.element == "O"]
    wo.addDistRestraint(watoms, oatoms, 1.90, factor=1.30, ESD=args.esd)

    general = wo.data["General"]
    cx, ct, cs, cia = general["AtomPtrs"]
    atoms = wo.data["Atoms"]
    lookup = G2mth.FillAtomLookUp(atoms, cia + 8)
    amat, _ = G2lat.cell2AB(general["Cell"][1:7])
    for bond in wo._getBondRest("set targets")["Bonds"]:
        ids, ops, _, _ = bond
        xyz = np.array(G2mth.GetAtomItemsById(atoms, lookup, ids, cx, 3))
        xyz = G2mth.getSyXYZ(xyz, ops, general["SGData"])
        bond[2] = float(G2mth.getRestDist(xyz, amat))
        bond[3] = args.esd

    gpx.set_Controls("cycles", args.cycles)
    gpx.set_Frozen()
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    hist = gpx.histogram(0)
    print("Rwp", hist.get_wR(), "mass", hist.ComputeMassFracs())
    print("restraints", wo._getBondRest("report"))
    print("atoms", [(a.label, a.element, a.coordinates) for a in wo.atoms()])


if __name__ == "__main__":
    main()
