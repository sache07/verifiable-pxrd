from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from experiment_refine import deactivate, phase_by_token


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("uiso", type=float)
    parser.add_argument("--phase", default="wo")
    parser.add_argument("--cycles", type=int, default=12)
    args = parser.parse_args()

    output = Path(args.output).resolve()
    output.parent.mkdir(exist_ok=True)
    gpx = G2sc.G2Project(gpxfile=args.input, newgpx=str(output))
    deactivate(gpx)
    hist = gpx.histogram(0)
    phase = phase_by_token(gpx, args.phase)
    for atom in phase.atoms():
        atom.uiso = args.uiso
        atom.refinement_flags = " "

    # Reoptimize only intensity terms that correlate with Uiso.
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    gpx.set_Controls("cycles", args.cycles)
    gpx.set_Frozen()
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()

    cov = gpx.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {}) or {}
    print(
        json.dumps(
            {
                "file": str(output),
                "phase": phase.name,
                "uiso_A2": args.uiso,
                "Rwp": hist.get_wR(),
                "GOF": rvals.get("GOF"),
                "converged": rvals.get("converged"),
                "mass_fractions": hist.ComputeMassFracs(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
