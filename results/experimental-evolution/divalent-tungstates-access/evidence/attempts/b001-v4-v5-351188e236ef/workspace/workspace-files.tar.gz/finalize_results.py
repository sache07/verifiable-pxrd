from __future__ import annotations

import csv
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "experiments" / "finalgrid_wo_0.003.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "CaWO4_scheelite": {
        "id": "CaWO4_scheelite",
        "name": "CaWO4 (scheelite)",
        "formula": "CaWO4",
        "space_group_number": 88,
        "cif": "CaWO4_scheelite.cif",
        "reference": "COD 7219229",
    },
    "WO3_2311041": {
        "id": "WO3_monoclinic",
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "space_group_number": 14,
        "cif": "WO3_monoclinic.cif",
        "reference": "COD 2311041",
    },
}


def cell_dict(phase: G2sc.G2Phase) -> dict[str, float]:
    a, b, c, alpha, beta, gamma, volume = phase.data["General"]["Cell"][1:8]
    return {
        "a_angstrom": float(a),
        "b_angstrom": float(b),
        "c_angstrom": float(c),
        "alpha_deg": float(alpha),
        "beta_deg": float(beta),
        "gamma_deg": float(gamma),
        "volume_angstrom3": float(volume),
    }


def main() -> None:
    # Keep the exact, converged checkpoint as the submitted project. All other
    # submitted numerical products below are read back from this copy.
    shutil.copy2(SOURCE, FINAL)
    gpx = G2sc.G2Project(str(FINAL))
    hist = gpx.histogram(0)
    x, yobs, weight, ycalc, ybkg, difference = [
        np.asarray(v, dtype=float) for v in hist.data["data"][1]
    ]

    fit_path = ROOT / "fit.csv"
    with fit_path.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity_counts",
                "calculated_intensity_counts",
                "difference_observed_minus_calculated_counts",
                "background_intensity_counts",
            ]
        )
        writer.writerows(zip(x, yobs, ycalc, difference, ybkg))

    fractions = hist.ComputeMassFracs()
    phase_results = []
    for phase in gpx.phases():
        info = PHASE_INFO[phase.name]
        cif_path = ROOT / info["cif"]
        phase.export_CIF(str(cif_path))
        fraction, fraction_esd = fractions[phase.name]
        result = dict(info)
        result["cif_path"] = result["cif"]
        result["space_group"] = phase.data["General"]["SGData"]["SpGrp"]
        result["weight_fraction"] = float(fraction)
        result["weight_fraction_esd_formal"] = float(fraction_esd)
        result["weight_percent"] = 100.0 * float(fraction)
        result["unit_cell"] = cell_dict(phase)
        phase_results.append(result)

    histogram_stats = hist.data["data"][0]
    rvals = gpx.data["Covariance"]["data"]["Rvals"]
    poisson_weights = bool(np.allclose(weight, 1.0 / yobs, rtol=1e-12, atol=1e-15))
    fit_stats = {
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": float(histogram_stats["R"]),
        "Rexp_percent": float(histogram_stats["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_square": float(rvals["chisq"]),
        "durbin_watson": float(histogram_stats["Durbin-Watson"]),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_variables": int(rvals["Nvars"]),
        "residual_rms_counts": float(np.sqrt(np.mean(difference**2))),
        "mean_difference_counts": float(np.mean(difference)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_esd": float(rvals["Max shft/sig"]),
        "weighting": "Poisson w=1/Iobs" if poisson_weights else "GSAS-II stored weights",
    }

    result = {
        "phase_count": len(phase_results),
        "phases": phase_results,
        "crystalline_weight_fraction_sum": float(
            sum(phase["weight_fraction"] for phase in phase_results)
        ),
        "fractions_normalization": (
            "Normalized over modeled crystalline phases; amorphous content was not determined."
        ),
        "fit_statistics": fit_stats,
        "refinement_histogram": hist.name,
        "profile_path": "fit.csv",
        "project_path": "final.gpx",
    }
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")

    ca, wo = phase_results
    report = f"""# Powder XRD phase analysis

## Result

The pattern is described by two crystalline phases:

| Phase | Space group | Refined cell (Å, °) | Crystalline weight fraction |
|---|---|---|---:|
| CaWO4, scheelite | {ca['space_group']} (No. 88) | a = {ca['unit_cell']['a_angstrom']:.5f}, c = {ca['unit_cell']['c_angstrom']:.5f} | {ca['weight_percent']:.2f} wt% |
| WO3, monoclinic | {wo['space_group']} (No. 14, alternate setting) | a = {wo['unit_cell']['a_angstrom']:.5f}, b = {wo['unit_cell']['b_angstrom']:.5f}, c = {wo['unit_cell']['c_angstrom']:.5f}, beta = {wo['unit_cell']['beta_deg']:.5f} | {wo['weight_percent']:.2f} wt% |

Fractions are normalized over the modeled crystalline phases. No external standard was supplied, so an amorphous fraction cannot be measured from this dataset.

The final full-grid fit has Rwp = {fit_stats['Rwp_percent']:.4f}%, Rp = {fit_stats['Rp_percent']:.4f}%, Rexp = {fit_stats['Rexp_percent']:.4f}%, and goodness-of-fit = {fit_stats['goodness_of_fit']:.4f} over {fit_stats['n_observations']} points. Because pointwise uncertainties were not supplied, raw counts were treated with Poisson weights (w = 1/Iobs). In `fit.csv`, difference is observed minus calculated intensity.

## Evidence and model choice

The dominant family at 18.271, 28.420, 31.223, 33.853, 46.882, and 57.650° 2theta indexes as tetragonal scheelite CaWO4. The diagnostic secondary triplet at 22.758, 23.182, and 23.975° and its higher-angle companions index as room-temperature monoclinic WO3. This is chemically consistent with partial reaction of the reported WO3 and CaCO3 precursors at 650 °C. The characteristic strongest calcite line near 29.4° and the CaO family are absent. Remaining residual extrema coincide with profiles of the two accepted phases or smooth background curvature; they do not form a coherent third reflection family.

Starting structures were the exact-composition frozen COD references 7219229 (CaWO4) and 2311041 (WO3). A physical triclinic WO3 alternative gave a worse complete two-phase fit, while another monoclinic reference was rejected because it contained severely under-coordinated W. The accepted structures retain physical coordination: scheelite W–O is about 1.80 Å and Ca–O is 2.42–2.44 Å; monoclinic WO3 contains distorted WO6 units with W–O about 1.68–2.20 Å.

Cells, calibration, scales, smooth background, peak profile, phase size/microstrain, CaWO4 oxygen position, and WO3 tungsten positions were refined in staged bounded passes. Common isotropic displacement parameters were selected by a bounded physical scan (0.0104 Å² for CaWO4 and 0.0030 Å² for WO3). Free refinement of the weakly constrained WO3 oxygen positions produced nonphysical short bonds and was rolled back to the published oxygen framework. Texture, anisotropic strain, and surface-roughness terms were tested but did not have adequate support.

## Remaining uncertainty

The covariance-only fraction uncertainty is about {100.0 * ca['weight_fraction_esd_formal']:.3f} wt%, but that excludes model and calibration uncertainty. A practical uncertainty of roughly ±1 wt% per phase is more defensible; the phase identities and major/minor assignment are robust. The WO3 oxygen coordinates and its Uiso (which reached the lower physical scan bound) are not independently determined reliably by this W-dominated laboratory pattern. The angular zero reached its allowed boundary and is correlated with specimen displacement and cell dimensions, so the reported cells should not be treated as high-accuracy metrology. Trace crystalline phases below the pattern's detection capability, and any amorphous material, cannot be excluded.
"""
    (ROOT / "report.md").write_text(report)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
