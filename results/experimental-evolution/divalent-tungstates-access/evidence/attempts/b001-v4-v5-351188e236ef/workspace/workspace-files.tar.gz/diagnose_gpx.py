from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks, peak_widths
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx")
    parser.add_argument("--csv")
    parser.add_argument("--prominence", type=float, default=35.0)
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.gpx)
    hist = gpx.histogram(0)
    x, yobs, weight, ycalc, ybkg, diff = [np.asarray(v) for v in hist.data["data"][1]]
    step = float(np.median(np.diff(x)))
    print("project", Path(args.gpx).resolve())
    print("histogram", hist.name, "points", len(x), "range", (x[0], x[-1]), "step", step)
    print("Rwp", hist.get_wR(), "mass_fractions", hist.ComputeMassFracs())
    print("residual RMS", float(np.sqrt(np.mean(diff**2))), "mean", float(np.mean(diff)))

    smooth = gaussian_filter1d(diff, 1.2)
    pos, pprops = find_peaks(smooth, prominence=args.prominence, distance=5)
    neg, nprops = find_peaks(-smooth, prominence=args.prominence, distance=5)
    pwidth = peak_widths(smooth, pos)[0] if len(pos) else np.array([])
    nwidth = peak_widths(-smooth, neg)[0] if len(neg) else np.array([])
    print("\npositive residual maxima: 2theta residual prominence width_deg yobs ycalc")
    for j in np.argsort(pprops["prominences"])[::-1][:80]:
        i = pos[j]
        print(
            f"{x[i]:10.5f} {diff[i]:9.2f} {pprops['prominences'][j]:9.2f} "
            f"{pwidth[j]*step:8.4f} {yobs[i]:9.2f} {ycalc[i]:9.2f}"
        )
    print("\nnegative residual minima: 2theta residual prominence width_deg yobs ycalc")
    for j in np.argsort(nprops["prominences"])[::-1][:50]:
        i = neg[j]
        print(
            f"{x[i]:10.5f} {diff[i]:9.2f} {nprops['prominences'][j]:9.2f} "
            f"{nwidth[j]*step:8.4f} {yobs[i]:9.2f} {ycalc[i]:9.2f}"
        )

    for phase in gpx.phases():
        print("\nphase", phase.name, "cell", phase.data["General"]["Cell"])
        for atom in phase.atoms():
            print(
                "atom",
                atom.label,
                atom.element,
                tuple(round(v, 8) for v in atom.coordinates),
                "occ",
                atom.occupancy,
                "uiso",
                atom.uiso,
                "flags",
                repr(atom.refinement_flags),
            )

    if args.csv:
        with open(args.csv, "w", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(["two_theta_deg", "observed", "calculated", "background", "difference", "weight"])
            writer.writerows(zip(x, yobs, ycalc, ybkg, diff, weight))


if __name__ == "__main__":
    main()
