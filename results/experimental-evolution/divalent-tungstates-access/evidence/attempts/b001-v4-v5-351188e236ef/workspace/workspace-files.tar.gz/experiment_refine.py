from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def deactivate(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]}
    )
    for phase in gpx.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})


def parse_axis(text: str) -> list[int]:
    axis = [int(v) for v in text.replace(",", " ").split()]
    if len(axis) != 3:
        raise ValueError("axis needs three integers")
    return axis


def phase_by_token(gpx: G2sc.G2Project, token: str):
    token = token.lower()
    if token in ("ca", "cawo4", "0"):
        return gpx.phase(0)
    if token in ("wo", "wo3", "1"):
        return gpx.phase(1)
    return gpx.phase(token)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("mode", choices=[
        "joint_position", "profile", "polarization", "surface", "texture",
        "strain", "ca_o", "wo_w", "wo_o", "all_coords", "uiso", "atom_x",
    ])
    parser.add_argument("--phase", default="ca")
    parser.add_argument("--atom")
    parser.add_argument("--axis", default="0 0 1")
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--coord-limit", type=float)
    args = parser.parse_args()

    output = Path(args.output).resolve()
    output.parent.mkdir(exist_ok=True)
    gpx = G2sc.G2Project(gpxfile=args.input, newgpx=str(output))
    deactivate(gpx)
    hist = gpx.histogram(0)
    ca = gpx.phase(0)
    wo = gpx.phase(1)
    axis = parse_axis(args.axis)

    if args.mode == "joint_position":
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        for phase in (ca, wo):
            phase.set_refinements({"Cell": True})
    elif args.mode == "profile":
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
        for phase in (ca, wo):
            phase.set_HAP_refinements({
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            })
    elif args.mode == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif args.mode == "surface":
        sample = hist.data["Sample Parameters"]
        if sample["SurfRoughA"][0] <= 0:
            sample["SurfRoughA"][0] = 0.2
        if sample["SurfRoughB"][0] <= 0:
            sample["SurfRoughB"][0] = 0.1
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    elif args.mode == "texture":
        phase = phase_by_token(gpx, args.phase)
        po = phase.getHAPvalues(hist.name)["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[3] = axis
        phase.set_HAP_refinements({"Pref.Ori.": True})
    elif args.mode == "strain":
        phase = phase_by_token(gpx, args.phase)
        old = phase.getHAPvalues(hist.name)["Mustrain"][1][0]
        phase.setSampleProfile(hist.name, "microstrain", "uniaxial", old, old, axis, LGmix=1.0)
        phase.set_HAP_refinements({
            "Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}
        })
    elif args.mode == "ca_o":
        ca.atom("O1").refinement_flags = "X"
    elif args.mode == "wo_w":
        for atom in wo.atoms():
            if atom.element == "W":
                atom.refinement_flags = "X"
    elif args.mode == "wo_o":
        for atom in wo.atoms():
            if atom.element == "O":
                atom.refinement_flags = "X"
    elif args.mode == "all_coords":
        for phase in (ca, wo):
            for atom in phase.atoms():
                atom.refinement_flags = "X"
    elif args.mode == "uiso":
        phase = phase_by_token(gpx, args.phase)
        for atom in phase.atoms():
            atom.refinement_flags = "U"
    elif args.mode == "atom_x":
        phase = phase_by_token(gpx, args.phase)
        if not args.atom or phase.atom(args.atom) is None:
            raise ValueError("--atom must name an atom in the selected phase")
        phase.atom(args.atom).refinement_flags = "X"

    if args.coord_limit is not None:
        for phase in gpx.phases():
            for atom_index, atom in enumerate(phase.atoms()):
                if "X" not in atom.refinement_flags:
                    continue
                for axis_name in ("x", "y", "z"):
                    var = f"{phase.id}::dA{axis_name}:{atom_index}"
                    gpx.set_Controls("parmMin", -abs(args.coord_limit), variable=var)
                    gpx.set_Controls("parmMax", abs(args.coord_limit), variable=var)

    gpx.set_Controls("cycles", args.cycles)
    gpx.set_Frozen()
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()

    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    cov = gpx.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {}) or {}
    result = {
        "mode": args.mode,
        "Rwp": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "SVD0": rvals.get("SVD0"),
        "message": rvals.get("msg"),
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {k: inst[k][1] for k in ("Zero", "U", "W", "X", "SH/L", "Polariz.")},
        "sample": {k: sample[k][0] for k in ("Shift", "SurfRoughA", "SurfRoughB")},
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist.name)
        result["phases"][phase.name] = {
            "cell": phase.data["General"]["Cell"][1:8],
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "PO": hap["Pref.Ori."],
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": atom.coordinates,
                    "uiso": atom.uiso,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
