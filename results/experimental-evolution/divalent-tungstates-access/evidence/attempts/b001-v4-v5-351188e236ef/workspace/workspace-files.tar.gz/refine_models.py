from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summarize(gpx: G2sc.G2Project, label: str) -> None:
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    print(f"\n===== {label} =====")
    print("wR", hist.get_wR())
    print("instrument", {k: v for k, v in inst.items() if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")})
    print("sample", {k: sample[k] for k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")})
    print("background", hist.data["Background"][0])
    for ph in gpx.phases():
        hap = ph.getHAPvalues(hist.name)
        print(
            "phase",
            ph.name,
            "cell",
            ph.data["General"]["Cell"],
            "scale",
            hap["Scale"],
            "size",
            hap["Size"],
            "mustrain",
            hap["Mustrain"],
            "PO",
            hap["Pref.Ori."],
        )
    cov = gpx.data.get("Covariance", {}).get("data", {})
    print("covariance", {k: cov.get(k) for k in ("Rvals", "GOF", "Nobs", "Nvars")})


def save_checkpoint(gpx: G2sc.G2Project, branch: Path, n: int, label: str) -> None:
    destination = branch / f"{n:02d}_{label}.gpx"
    gpx.save(str(destination))
    summarize(gpx, f"{n:02d}_{label}")


def refine(gpx: G2sc.G2Project, branch: Path, n: int, label: str) -> None:
    gpx.refine(makeBack=False)
    save_checkpoint(gpx, branch, n, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", default="2311041")
    parser.add_argument("--branch", default=None)
    parser.add_argument("--background", type=int, default=15)
    args = parser.parse_args()

    branch = ROOT / (args.branch or f"branch_wo3_{args.wo3}")
    branch.mkdir(exist_ok=True)
    working = branch / "working.gpx"

    gpx = G2sc.G2Project(newgpx=str(working))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    ca = gpx.add_phase(
        str(cod_path("7219229")),
        phasename="CaWO4_scheelite",
        histograms=[hist],
        fmthint="CIF",
    )
    wo = gpx.add_phase(
        str(cod_path(args.wo3)),
        phasename=f"WO3_{args.wo3}",
        histograms=[hist],
        fmthint="CIF",
    )

    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [500.0, False]
    sample["Gonio. radius"] = 200.0
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": args.background,
                "coeffs": [900.0] + [0.0] * (args.background - 1),
            }
        }
    )
    for phase in (ca, wo):
        phase.HAPvalue("Scale", 1.0)
        phase.set_HAP_refinements({"Scale": True})

    gpx.set_Controls("cycles", 8)
    save_checkpoint(gpx, branch, 0, "setup")
    refine(gpx, branch, 1, "scales_background")

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in (ca, wo):
        phase.set_refinements({"Cell": True})
    refine(gpx, branch, 2, "cells_shift")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(gpx, branch, 3, "zero")

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine(gpx, branch, 4, "profile_WX")

    hist.set_refinements({"Instrument Parameters": ["U", "SH/L"]})
    refine(gpx, branch, 5, "profile_U_SHL")

    # Introduce per-phase isotropic specimen broadening only after the common
    # instrument and positional terms have converged.
    ca.setSampleProfile(hist.name, "size", "isotropic", 0.3, LGmix=1.0)
    wo.setSampleProfile(hist.name, "size", "isotropic", 0.3, LGmix=1.0)
    for phase in (ca, wo):
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    refine(gpx, branch, 6, "phase_sizes")

    ca.setSampleProfile(hist.name, "microstrain", "isotropic", 1000.0, LGmix=1.0)
    wo.setSampleProfile(hist.name, "microstrain", "isotropic", 1000.0, LGmix=1.0)
    for phase in (ca, wo):
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(gpx, branch, 7, "phase_microstrain")

    gpx.save(str(branch / "base_complete.gpx"))


if __name__ == "__main__":
    main()
