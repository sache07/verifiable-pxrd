from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def brief(gpx: G2sc.G2Project, label: str) -> None:
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    cov = gpx.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {}) or {}
    print(f"\n===== {label} =====")
    print(
        json.dumps(
            {
                "Rwp": hist.get_wR(),
                "GOF": rvals.get("GOF"),
                "converged": rvals.get("converged"),
                "SVD0": rvals.get("SVD0"),
                "message": rvals.get("msg"),
                "instrument": {k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")},
                "sample": {k: sample[k][0] for k in ("Shift", "SurfRoughA", "SurfRoughB")},
                "phases": {
                    p.name: {
                        "cell": p.data["General"]["Cell"][1:8],
                        "scale": p.getHAPvalues(hist.name)["Scale"][0],
                        "size": p.getHAPvalues(hist.name)["Size"][1][0],
                        "microstrain": p.getHAPvalues(hist.name)["Mustrain"][1][0],
                        "MD": p.getHAPvalues(hist.name)["Pref.Ori."][1],
                    }
                    for p in gpx.phases()
                },
                "frozen": gpx.get_Frozen(),
            },
            indent=2,
        )
    )


def checkpoint(gpx: G2sc.G2Project, outdir: Path, n: int, label: str) -> None:
    path = outdir / f"{n:02d}_{label}.gpx"
    gpx.save(str(path))
    brief(gpx, f"{n:02d}_{label}")


def run_refinement(gpx: G2sc.G2Project, outdir: Path, n: int, label: str, cycles: int = 10) -> None:
    gpx.set_Controls("cycles", cycles)
    gpx.set_Frozen()
    gpx.refine(makeBack=False)
    checkpoint(gpx, outdir, n, label)


def bound(gpx: G2sc.G2Project, var: str, low: float, high: float) -> None:
    gpx.set_Controls("parmMin", low, variable=var)
    gpx.set_Controls("parmMax", high, variable=var)


def set_physical_bounds(gpx: G2sc.G2Project) -> None:
    bounds = {
        ":0:Shift": (-800.0, 800.0),
        ":0:Zero": (-0.25, 0.25),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.5, 1.0),
        ":0:SurfRoughA": (0.05, 0.60),
        ":0:SurfRoughB": (0.02, 0.50),
    }
    for pid in (0, 1):
        bounds[f"{pid}:0:Size;i"] = (0.04, 1.5)
        bounds[f"{pid}:0:Mustrain;i"] = (300.0, 8000.0)
        bounds[f"{pid}:0:MD"] = (0.7, 1.4)
    for var, (low, high) in bounds.items():
        bound(gpx, var, low, high)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", default="2311041")
    parser.add_argument("--outdir", default="physical_2311041")
    args = parser.parse_args()
    outdir = ROOT / args.outdir
    outdir.mkdir(exist_ok=True)

    gpx = G2sc.G2Project(newgpx=str(outdir / "working.gpx"))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    ca = gpx.add_phase(
        str(cod_path("7219229")),
        phasename="CaWO4_scheelite",
        histograms=[hist],
        fmthint="CIF",
    )
    wo = gpx.add_phase(
        str(cod_path(args.wo3)),
        phasename=f"WO3_{args.wo3}",
        histograms=[hist],
        fmthint="CIF",
    )
    phases = (ca, wo)

    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [500.0, False]
    sample["Gonio. radius"] = 200.0
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 15,
                "coeffs": [900.0] + [0.0] * 14,
            }
        }
    )
    for phase in phases:
        phase.HAPvalue("Scale", 1.0)
        phase.set_HAP_refinements({"Scale": True})

    set_physical_bounds(gpx)
    checkpoint(gpx, outdir, 0, "setup")
    run_refinement(gpx, outdir, 1, "scales_background", 6)

    # Positional terms: alternate displacement and zero because they are
    # nearly collinear on a 10--100 degree laboratory scan.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    run_refinement(gpx, outdir, 2, "cells_shift", 12)

    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(gpx, outdir, 3, "cells_zero", 10)

    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_refinement(gpx, outdir, 4, "cells_shift_second", 10)

    # Freeze calibration and cells while resolving broadening. Initial phase
    # sizes are chosen from the visibly broad CaWO4 and sharper WO3 lines.
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    for phase in phases:
        phase.clear_refinements({"Cell": True})
    ca.setSampleProfile(hist.name, "size", "isotropic", 0.18, LGmix=1.0)
    wo.setSampleProfile(hist.name, "size", "isotropic", 1.0, LGmix=1.0)
    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    run_refinement(gpx, outdir, 5, "phase_sizes", 10)

    for phase in phases:
        phase.clear_HAP_refinements({"Size": True})
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    run_refinement(gpx, outdir, 6, "profile_WX", 10)

    hist.clear_refinements({"Instrument Parameters": ["W", "X"]})
    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    run_refinement(gpx, outdir, 7, "phase_sizes_second", 10)

    for phase in phases:
        phase.clear_HAP_refinements({"Size": True})
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    run_refinement(gpx, outdir, 8, "profile_UWX", 10)

    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
    ca.setSampleProfile(hist.name, "microstrain", "isotropic", 1000.0, LGmix=1.0)
    wo.setSampleProfile(hist.name, "microstrain", "isotropic", 1000.0, LGmix=1.0)
    for phase in phases:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    run_refinement(gpx, outdir, 9, "phase_microstrain", 10)

    for phase in phases:
        phase.clear_HAP_refinements({"Mustrain": True})
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run_refinement(gpx, outdir, 10, "profile_SHL", 10)

    # One final bounded alternation of specimen broadening and positional
    # terms, retaining only physical solutions.
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    run_refinement(gpx, outdir, 11, "specimen_broadening", 10)

    for phase in phases:
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_refinement(gpx, outdir, 12, "cells_shift_final", 8)

    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(gpx, outdir, 13, "cells_zero_final", 8)
    gpx.save(str(outdir / "physical_base.gpx"))


if __name__ == "__main__":
    main()
