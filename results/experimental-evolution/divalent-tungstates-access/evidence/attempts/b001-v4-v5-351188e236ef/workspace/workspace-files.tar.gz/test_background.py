from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from experiment_refine import deactivate


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("coefficients", type=int)
    parser.add_argument("--cycles", type=int, default=12)
    args = parser.parse_args()

    output = Path(args.output).resolve()
    output.parent.mkdir(exist_ok=True)
    gpx = G2sc.G2Project(gpxfile=args.input, newgpx=str(output))
    deactivate(gpx)
    hist = gpx.histogram(0)

    old = list(hist.data["Background"][0][3:])
    coeffs = (old + [0.0] * args.coefficients)[: args.coefficients]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": args.coefficients,
                "coeffs": coeffs,
            }
        }
    )
    gpx.set_Controls("cycles", args.cycles)
    gpx.set_Frozen()
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()

    cov = gpx.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {}) or {}
    print(
        json.dumps(
            {
                "file": str(output),
                "coefficients": args.coefficients,
                "Rwp": hist.get_wR(),
                "Rp": hist.data["data"][0].get("R"),
                "GOF": rvals.get("GOF"),
                "Nvars": rvals.get("Nvars"),
                "converged": rvals.get("converged"),
                "mass_fractions": hist.ComputeMassFracs(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
