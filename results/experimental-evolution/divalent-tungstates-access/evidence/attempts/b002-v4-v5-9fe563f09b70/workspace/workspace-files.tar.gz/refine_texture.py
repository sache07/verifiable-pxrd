#!/usr/bin/env python3
"""Screen the laboratory's allowed March-Dollase axes phase by phase."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(h):
    x, yo, w, yc = [np.asarray(v, float) for v in h.data["data"][1][:4]]
    lo, hi = h.data["Limits"][1]
    q = (x >= lo) & (x <= hi) & (w > 0)
    return float(100 * np.sqrt(np.sum(w[q] * (yo[q] - yc[q]) ** 2) /
                               np.sum(w[q] * yo[q] ** 2)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("out", type=Path)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    working = args.out / "working.gpx"
    shutil.copy2(args.input, working)
    G2.SetPrintLevel("warn")
    history = []
    axes = [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]

    for phase_name in ["MnWO4", "WO3", "Mn2WO6", "MnO", "mno2"]:
        base = args.out / "texture_base.gpx"
        shutil.copy2(working, base)
        base_project = G2.G2Project(str(base))
        oldr = rwp(base_project.histogram(0))
        phase_axes = axes if phase_name not in ("MnO", "mno2") else [[1, 0, 0], [1, 1, 0], [1, 1, 1]]
        trials = []
        for axis in phase_axes:
            trial = args.out / "texture_trial.gpx"
            shutil.copy2(base, trial)
            p = G2.G2Project(str(trial))
            p.set_Controls("cycles", 7)
            h = p.histogram(0)
            hap = p.phase(phase_name).data["Histograms"][h.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(axis)
            p.refine()
            rr = rwp(p.histogram(0))
            ratio = float(p.phase(phase_name).data["Histograms"][p.histogram(0).name]["Pref.Ori."][1])
            scales_ok = all(ph.data["Histograms"][p.histogram(0).name]["Scale"][0] > 0 for ph in p.phases())
            valid = bool(np.isfinite(rr) and rr < oldr and 0.7 <= ratio <= 1.4 and scales_ok)
            saved = args.out / f"trial_{phase_name}_{''.join(map(str, axis))}.gpx"
            p.save(str(trial)); shutil.copy2(trial, saved)
            rec = {"phase": phase_name, "axis": axis, "Rwp": rr,
                   "ratio": ratio, "valid": valid, "path": str(saved)}
            trials.append(rec); history.append(rec); print(json.dumps(rec), flush=True)
        valid_trials = [t for t in trials if t["valid"]]
        if valid_trials:
            best = min(valid_trials, key=lambda t: t["Rwp"])
            shutil.copy2(best["path"], working)
            p = G2.G2Project(str(working))
            h = p.histogram(0)
            p.phase(phase_name).data["Histograms"][h.name]["Pref.Ori."][2] = False
            p.save(str(working))
            shutil.copy2(working, args.out / f"accepted_{phase_name}.gpx")
            print(json.dumps({"accepted_phase": phase_name, "best": best}), flush=True)
        else:
            shutil.copy2(base, working)
            print(json.dumps({"accepted_phase": phase_name, "best": None}), flush=True)

    (args.out / "texture_history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
