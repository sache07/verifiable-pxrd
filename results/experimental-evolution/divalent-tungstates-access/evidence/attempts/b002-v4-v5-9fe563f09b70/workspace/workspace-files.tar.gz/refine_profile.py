#!/usr/bin/env python3
"""Continue the physical four-phase refinement with guarded profile steps."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def calc_rwp(hist) -> float:
    x, yo, w, yc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi) & (w > 0)
    return float(100 * np.sqrt(np.sum(w[use] * (yo[use] - yc[use]) ** 2) /
                               np.sum(w[use] * yo[use] ** 2)))


def state(project, label: str) -> dict:
    h = project.histogram(0)
    inst = h.data["Instrument Parameters"][0]
    out = {
        "label": label,
        "Rwp": calc_rwp(h),
        "instrument": {k: float(v[1]) for k, v in inst.items()
                       if isinstance(v, list) and len(v) > 1 and
                       isinstance(v[1], (int, float))},
        "sample": {k: v[0] for k, v in h.data["Sample Parameters"].items()
                   if isinstance(v, list) and len(v) == 2},
        "phases": {},
    }
    for p in project.phases():
        hap = p.data["Histograms"][h.name]
        out["phases"][p.name] = {
            "scale": float(hap["Scale"][0]),
            "cell": [float(v) for v in p.data["General"]["Cell"][1:8]],
            "size": [float(v) for v in hap["Size"][1]],
            "mustrain": [float(v) for v in hap["Mustrain"][1]],
        }
    return out


def all_positive_scales(project) -> bool:
    h = project.histogram(0)
    return all(p.data["Histograms"][h.name]["Scale"][0] > 0
               for p in project.phases())


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("out", type=Path)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    working = args.out / "working.gpx"
    shutil.copy2(args.input, working)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(working))
    hist = project.histogram(0)
    hist.SampleParameters["Scale"] = [1.0, False]
    project.set_Controls("cycles", 8)

    # Normalize displacement parameters to the specimen model used by this lab:
    # one modest isotropic value per phase, fixed during profile screening.
    for phase in project.phases():
        cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
        for atom in phase.data["Atoms"]:
            atom[cia] = "I"
            atom[cia + 1:cia + 7] = [0.01, 0., 0., 0., 0., 0.]
            atom[2] = ""

    # Retain the established scale/background/calibration/cell flags and reset
    # only profile terms to a physical common starting point.
    inst = hist.data["Instrument Parameters"][0]
    for key, val in {"U": 10., "W": 10., "X": 1., "SH/L": 0.02,
                     "Polariz.": 0.70}.items():
        inst[key][1] = val
        inst[key][2] = False
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 300., LGmix=1.0)
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True,
                                     "Pref.Ori.": True}, [hist])
    project.save(str(working))

    records = []

    def checkpoint(label: str) -> None:
        project.save(str(working))
        shutil.copy2(working, args.out / f"{label}.gpx")
        rec = state(project, label)
        records.append(rec)
        print(json.dumps(rec, indent=2), flush=True)

    def run_guarded(label: str, validator) -> bool:
        nonlocal project, hist, inst
        before = args.out / "before.gpx"
        project.save(str(working))
        shutil.copy2(working, before)
        old = calc_rwp(hist)
        project.refine()
        new = calc_rwp(project.histogram(0))
        ok = np.isfinite(new) and new <= old + 1e-5 and all_positive_scales(project) and validator()
        if not ok:
            shutil.copy2(before, working)
            project = G2.G2Project(str(working))
            hist = project.histogram(0)
            inst = hist.data["Instrument Parameters"][0]
            print(f"ROLLBACK {label}: old={old:.6f} attempted={new:.6f}", flush=True)
            return False
        checkpoint(label)
        return True

    # Re-equilibrate scales/background/cells after the Uiso normalization.
    run_guarded("00_rebalance", lambda: True)

    bounds = {
        "W": (2.0, 40.0),
        "U": (0.0, 40.0),
        "X": (0.1, 6.0),
        "SH/L": (0.005, 0.10),
        "Polariz.": (0.5, 1.0),
    }
    for num, key in enumerate(["W", "U", "X", "SH/L", "Polariz."], start=1):
        # Only the newly introduced term is variable in this profile block.
        hist.clear_refinements({"Instrument Parameters": list(bounds)})
        hist.set_refinements({"Instrument Parameters": [key]})
        lo, hi = bounds[key]
        run_guarded(f"{num:02d}_{key.replace('/', '_').replace('.', '')}",
                    lambda key=key, lo=lo, hi=hi: lo <= inst[key][1] <= hi)
        hist.clear_refinements({"Instrument Parameters": [key]})

    project.save(str(working))
    (args.out / "profile_history.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
