#!/usr/bin/env python3
"""Refine phase broadening terms one at a time with physical bounds."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist) -> float:
    x, yo, w, yc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi) & (w > 0)
    return float(100 * np.sqrt(np.sum(w[use] * (yo[use] - yc[use]) ** 2) /
                               np.sum(w[use] * yo[use] ** 2)))


def positive_scales(project) -> bool:
    h = project.histogram(0)
    return all(p.data["Histograms"][h.name]["Scale"][0] > 0 for p in project.phases())


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("out", type=Path)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    working = args.out / "working.gpx"
    shutil.copy2(args.input, working)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(working))
    project.set_Controls("cycles", 7)
    history = []

    for kind in ("Size", "Mustrain"):
        for phase_name in ["MnWO4", "WO3", "Mn2WO6", "MnO", "mno2"]:
            project.save(str(working))
            before = args.out / "before.gpx"
            shutil.copy2(working, before)
            hist = project.histogram(0)
            phase = project.phase(phase_name)
            oldr = rwp(hist)
            if kind == "Size":
                phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
            else:
                phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
            project.refine()
            hist = project.histogram(0)
            phase = project.phase(phase_name)
            hap = phase.data["Histograms"][hist.name]
            value = float(hap[kind][1][0])
            newr = rwp(hist)
            if kind == "Size":
                physical = 0.04 <= value <= 1.5
            else:
                physical = 0.0 <= value <= 8000.0
            ok = bool(np.isfinite(newr) and newr <= oldr + 1e-5 and physical and
                      positive_scales(project))
            label = f"{kind.lower()}_{phase_name}"
            rec = {"label": label, "old_Rwp": oldr, "attempted_Rwp": newr,
                   "value": value, "accepted": ok}
            if ok:
                phase.clear_HAP_refinements({kind: True}, [hist])
                project.save(str(working))
                shutil.copy2(working, args.out / f"{label}.gpx")
            else:
                shutil.copy2(before, working)
                project = G2.G2Project(str(working))
            history.append(rec)
            print(json.dumps(rec), flush=True)

    project.save(str(working))
    (args.out / "phase_profile_history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
