#!/usr/bin/env python3
"""Replace a correlated two-parameter roughness fit by a one-parameter screen."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist) -> float:
    x, yo, w, yc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi) & (w > 0)
    return float(100 * np.sqrt(np.sum(w[use] * (yo[use] - yc[use]) ** 2) /
                               np.sum(w[use] * yo[use] ** 2)))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    trials = []

    for fixed_a in (0.20, 0.35, 0.50, 0.70, 0.90):
        path = args.out / f"fixed_A_{fixed_a:.2f}.gpx"
        shutil.copy2(args.input, path)
        project = G2.G2Project(str(path))
        project.set_Controls("cycles", 9)
        sample = project.histogram(0).data["Sample Parameters"]
        sample["SurfRoughA"] = [fixed_a, False]
        sample["SurfRoughB"] = [0.10, True]
        try:
            project.refine()
            hist = project.histogram(0)
            score = rwp(hist)
            b_value = float(hist.data["Sample Parameters"]["SurfRoughB"][0])
            positive = all(phase.data["Histograms"][hist.name]["Scale"][0] > 0
                           for phase in project.phases())
            valid = bool(np.isfinite(score) and 0.0 <= b_value <= 1.0 and positive)
            project.histogram(0).clear_refinements(
                {"Sample Parameters": ["SurfRoughB"]})
            project.save(str(path))
            error = None
        except Exception as exc:
            score, b_value, valid, error = float("inf"), float("nan"), False, repr(exc)
        record = {"fixed_A": fixed_a, "refined_B": b_value, "Rwp": score,
                  "valid": valid, "path": str(path), "error": error}
        trials.append(record)
        print(json.dumps(record), flush=True)

    valid_trials = [trial for trial in trials if trial["valid"]]
    if not valid_trials:
        raise RuntimeError("No physical one-parameter roughness trial")
    best = min(valid_trials, key=lambda trial: trial["Rwp"])
    working = args.out / "working.gpx"
    shutil.copy2(best["path"], working)
    project = G2.G2Project(str(working))
    project.set_Controls("cycles", 9)
    # Final scales/background/zero with the roughness correction held.
    project.refine()
    project.save(str(working))
    payload = {"best": best, "trials": trials, "final_Rwp": rwp(project.histogram(0)),
               "fractions": project.histogram(0).ComputeMassFracs(),
               "sample": project.histogram(0).data["Sample Parameters"]}
    (args.out / "result.json").write_text(json.dumps(payload, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
