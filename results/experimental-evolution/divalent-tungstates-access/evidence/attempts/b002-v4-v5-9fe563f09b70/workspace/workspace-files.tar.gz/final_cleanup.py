#!/usr/bin/env python3
"""Final guarded joint/calibration/specimen refinement for the six-phase model."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


CELL_BOUNDS = {
    "MnWO4": ((4.70, 4.90), (5.50, 5.90), (4.80, 5.15)),
    "WO3": ((7.40, 7.95), (7.25, 7.85), (10.15, 10.90)),
    "Mn2WO6": ((4.35, 4.85), (17.1, 18.7), (4.70, 5.20)),
    "MnO": ((4.25, 4.55), (4.25, 4.55), (4.25, 4.55)),
    "mno2": ((4.25, 4.55), (4.25, 4.55), (2.70, 3.05)),
    "MnWO4_scheelite": ((4.90, 5.35), (4.90, 5.35), (11.3, 12.5)),
}


def rwp(hist) -> float:
    x, yo, w, yc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi) & (w > 0)
    return float(100 * np.sqrt(np.sum(w[use] * (yo[use] - yc[use]) ** 2) /
                               np.sum(w[use] * yo[use] ** 2)))


def valid(project) -> bool:
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if hap.get("Use", True) and hap["Scale"][0] <= 0:
            return False
        if phase.ShortDistances(True):
            return False
        abc = phase.data["General"]["Cell"][1:4]
        if not all(lo <= value <= hi
                   for value, (lo, hi) in zip(abc, CELL_BOUNDS[phase.name])):
            return False
    inst = hist.data["Instrument Parameters"][0]
    return (0.0 <= inst["U"][1] <= 20.0 and
            0.0 <= inst["W"][1] <= 50.0 and
            0.0 <= inst["X"][1] <= 3.0)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    working = args.out / "working.gpx"
    shutil.copy2(args.input, working)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(working))
    project.set_Controls("cycles", 9)
    history = []

    def run(label, setup, extra_valid=lambda p: True, allow_small_increase=0.0):
        nonlocal project
        project.save(str(working))
        before = args.out / "before.gpx"
        shutil.copy2(working, before)
        old = rwp(project.histogram(0))
        setup(project)
        error = None
        try:
            project.refine()
            new = rwp(project.histogram(0))
            ok = bool(np.isfinite(new) and new <= old + allow_small_increase and
                      valid(project) and extra_valid(project))
        except Exception as exc:
            new, ok, error = float("nan"), False, repr(exc)
        record = {"label": label, "old_Rwp": old, "attempted_Rwp": new,
                  "accepted": ok, "error": error}
        if ok:
            project.save(str(working))
            shutil.copy2(working, args.out / f"{label}.gpx")
        else:
            shutil.copy2(before, working)
            project = G2.G2Project(str(working))
        history.append(record)
        print(json.dumps(record), flush=True)

    # Use the interior 60 nm scheelite size: 40 and 60 nm differed by <0.005 Rwp.
    def scheelite_size(p):
        h = p.histogram(0)
        profile = p.phase("MnWO4_scheelite").data["Histograms"][h.name]["Size"]
        profile[1][0], profile[2][0] = 0.06, False
    run("01_scheelite_size_60nm", scheelite_size, allow_small_increase=0.01)

    def all_cells(p):
        for phase in p.phases():
            phase.set_refinements({"Cell": True})
    run("02_joint_cells", all_cells)
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    project.save(str(working))

    # Recheck only the supported common broadening terms.
    for num, key in enumerate(("U", "W", "X"), start=3):
        def setup(p, key=key):
            hist = p.histogram(0)
            hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
            hist.set_refinements({"Instrument Parameters": [key]})
        run(f"{num:02d}_instrument_{key}", setup)
        project.histogram(0).clear_refinements({"Instrument Parameters": [key]})
        project.save(str(working))

    # Test a Bragg-Brentano specimen displacement with zero held at its calibrated value.
    def specimen_shift(p):
        hist = p.histogram(0)
        hist.clear_refinements({"Instrument Parameters": ["Zero"]})
        hist.data["Sample Parameters"]["Shift"] = [0.0, True]
    run("06_specimen_shift", specimen_shift,
        lambda p: abs(p.histogram(0).data["Sample Parameters"]["Shift"][0]) <= 500.)
    project.histogram(0).clear_refinements({"Sample Parameters": ["Shift"]})
    project.save(str(working))

    # Test one physical Suortti roughness pair; reject boundaries or nonphysical values.
    def roughness(p):
        sample = p.histogram(0).data["Sample Parameters"]
        sample["SurfRoughA"] = [0.90, True]
        sample["SurfRoughB"] = [0.01, True]
    run("07_surface_roughness", roughness,
        lambda p: (0.05 <= p.histogram(0).data["Sample Parameters"]["SurfRoughA"][0] <= 1.0 and
                   0.0 <= p.histogram(0).data["Sample Parameters"]["SurfRoughB"][0] <= 1.0))
    project.histogram(0).clear_refinements(
        {"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    project.save(str(working))

    # Final scale/background/calibration equilibration with all structural terms held.
    def final_equilibrate(p):
        hist = p.histogram(0)
        if hist.data["Sample Parameters"]["Shift"][0] == 0.0:
            hist.set_refinements({"Instrument Parameters": ["Zero"]})
        else:
            hist.set_refinements({"Sample Parameters": ["Shift"]})
    run("08_final_equilibrate", final_equilibrate, allow_small_increase=1e-5)
    project.histogram(0).clear_refinements({"Sample Parameters": ["Shift"]})
    project.save(str(working))

    payload = {
        "Rwp": rwp(project.histogram(0)),
        "fractions": project.histogram(0).ComputeMassFracs(),
        "instrument": project.histogram(0).data["Instrument Parameters"][0],
        "sample": project.histogram(0).data["Sample Parameters"],
        "history": history,
    }
    (args.out / "result.json").write_text(json.dumps(payload, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
