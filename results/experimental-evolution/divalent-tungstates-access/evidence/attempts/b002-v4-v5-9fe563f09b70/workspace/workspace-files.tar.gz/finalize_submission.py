#!/usr/bin/env python3
"""Freeze the accepted GSAS-II model and generate the requested deliverables."""

from __future__ import annotations

import csv
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/roughness-oneparam/working.gpx")
FREEZE_DIR = Path(".tmp/final-freeze")
FINAL_GPX = Path("final.gpx")

PHASE_OUTPUTS = {
    "MnWO4": {
        "name": "MnWO4 (wolframite)",
        "formula": "MnWO4",
        "cif": "phase_1_mnwo4_wolframite.cif",
        "model_basis": "COD 1520200; refined physical wolframite model",
    },
    "WO3": {
        "name": "WO3",
        "formula": "WO3",
        "cif": "phase_2_wo3.cif",
        "model_basis": "COD 2311041; physical monoclinic WO3 model",
    },
    "Mn2WO6": {
        "name": "Mn2WO6 (Pbcn analogue)",
        "formula": "Mn2WO6",
        "cif": "phase_3_mn2wo6_pbcn.cif",
        "model_basis": "Fe2WO6 COD 2310464 topology with Fe replaced by Mn and bounded coordinates",
    },
    "MnO": {
        "name": "MnO",
        "formula": "MnO",
        "cif": "phase_4_mno.cif",
        "model_basis": "COD 1514108 rocksalt model",
    },
    "mno2": {
        "name": "MnO2 (rutile)",
        "formula": "MnO2",
        "cif": "phase_5_mno2_rutile.cif",
        "model_basis": "COD 1514110 rutile model",
    },
    "MnWO4_scheelite": {
        "name": "MnWO4 (scheelite-type analogue)",
        "formula": "MnWO4",
        "cif": "phase_6_mnwo4_scheelite.cif",
        "model_basis": "CaWO4 COD 7219229 topology with Ca replaced by Mn",
    },
}


def profile_stats(project: G2.G2Project) -> dict[str, float | int | bool]:
    hist = project.histogram(0)
    x, yo, w, yc = (np.asarray(v, float) for v in hist.data["data"][1][:4])
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi) & (w > 0)
    residual = yo[use] - yc[use]
    chisq = float(np.sum(w[use] * residual**2))
    rwp = float(100.0 * np.sqrt(chisq / np.sum(w[use] * yo[use] ** 2)))
    rp = float(100.0 * np.sum(np.abs(residual)) / np.sum(np.abs(yo[use])))
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    gof = float(rvals.get("GOF", math.sqrt(chisq / (use.sum() - len(
        project.data["Covariance"]["data"].get("varyList", []))))))
    return {
        "Rwp_percent": rwp,
        "Rp_percent": rp,
        "Rexp_percent": rwp / gof,
        "GOF": gof,
        "chi_square": chisq,
        "Nobs": int(rvals.get("Nobs", use.sum())),
        "Nvars": int(rvals.get("Nvars", len(
            project.data["Covariance"]["data"].get("varyList", [])))),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_esd": float(rvals.get("Max shft/sig", float("nan"))),
    }


def freeze_refinement_flags(project: G2.G2Project) -> None:
    """Leave only scales, background coefficients and zero shift active."""
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for value in inst.values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    inst["Zero"][2] = True
    hist.data["Background"][0][1] = True

    sample = hist.data["Sample Parameters"]
    for key in ("Scale", "Absorption", "DisplaceX", "DisplaceY", "Shift",
                "Transparency", "SurfRoughA", "SurfRoughB"):
        value = sample.get(key)
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False

    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.data.get("Atoms", []):
            atom[2] = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        if "Size" in hap:
            hap["Size"][2] = [False] * len(hap["Size"][2])
            if len(hap["Size"]) > 5:
                hap["Size"][5] = [False] * len(hap["Size"][5])
        if "Mustrain" in hap:
            hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
            if len(hap["Mustrain"]) > 5:
                hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        if "Pref.Ori." in hap:
            hap["Pref.Ori."][2] = False
        if "HStrain" in hap:
            hap["HStrain"][1] = [False] * len(hap["HStrain"][1])


def assert_physical(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    if set(fractions) != set(PHASE_OUTPUTS):
        raise RuntimeError(f"Unexpected phase inventory: {sorted(fractions)}")
    if not math.isclose(sum(value[0] for value in fractions.values()), 1.0,
                        rel_tol=0.0, abs_tol=2e-10):
        raise RuntimeError("Crystalline weight fractions do not sum to one")
    for phase in project.phases():
        if fractions[phase.name][0] <= 0:
            raise RuntimeError(f"Non-positive fraction for {phase.name}")
        if phase.ShortDistances(True):
            raise RuntimeError(f"Short contact in {phase.name}: {phase.ShortDistances(True)}")
    sample = hist.data["Sample Parameters"]
    if not (0.05 < sample["SurfRoughA"][0] < 1.0 and
            0.0 < sample["SurfRoughB"][0] < 1.0):
        raise RuntimeError("Surface correction is on or outside a physical bound")


def export_fit(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    x, yo, _w, yc, yb = (np.asarray(v, float) for v in hist.data["data"][1][:5])
    with Path("fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(("two_theta_deg", "observed", "calculated", "difference", "background"))
        writer.writerows(zip(x, yo, yc, yo - yc, yb))


def export_result(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    phases = []
    for phase in project.phases():
        definition = PHASE_OUTPUTS[phase.name]
        phase.export_CIF(definition["cif"])
        general = phase.data["General"]
        cell = general["Cell"]
        fraction, esd = fractions[phase.name]
        phases.append({
            "name": definition["name"],
            "formula": definition["formula"],
            "space_group": general["SGData"]["SpGrp"].strip(),
            "cif_path": definition["cif"],
            "weight_fraction": float(fraction),
            "weight_fraction_esd": float(esd),
            "cell_angstrom_degrees": {
                "a": float(cell[1]), "b": float(cell[2]), "c": float(cell[3]),
                "alpha": float(cell[4]), "beta": float(cell[5]), "gamma": float(cell[6]),
                "volume_angstrom3": float(cell[7]),
            },
            "model_basis": definition["model_basis"],
        })
    payload = {
        "project_path": str(FINAL_GPX),
        "profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over the six modeled crystalline phases",
        "phases": phases,
        "fit_statistics": profile_stats(project),
    }
    Path("result.json").write_text(json.dumps(payload, indent=2) + "\n")


def main() -> None:
    G2.SetPrintLevel("warn")
    FREEZE_DIR.mkdir(parents=True, exist_ok=True)
    working = FREEZE_DIR / "working.gpx"
    shutil.copy2(SOURCE, working)
    project = G2.G2Project(str(working))
    project.set_Controls("cycles", 12)
    freeze_refinement_flags(project)
    project.save(str(working))

    # Repeat only if needed; this normally converges on the first pass.
    for _ in range(3):
        project.refine()
        stats = profile_stats(project)
        if stats["converged"] and stats["max_shift_over_esd"] < 1.0:
            break
    else:
        raise RuntimeError(f"Final refinement did not stabilize: {stats}")

    assert_physical(project)
    project.save(str(working))
    shutil.copy2(working, FINAL_GPX)

    # Reload the exact submitted project before all exports.
    project = G2.G2Project(str(FINAL_GPX))
    assert_physical(project)
    export_fit(project)
    export_result(project)
    print(json.dumps({
        "fit_statistics": profile_stats(project),
        "fractions": project.histogram(0).ComputeMassFracs(),
        "vary_list": project.data["Covariance"]["data"].get("varyList", []),
    }, indent=2, default=float))


if __name__ == "__main__":
    main()
