#!/usr/bin/env python3
"""Guarded site-by-site coordinate refinement for the accepted inventory."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist) -> float:
    x, yo, w, yc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi) & (w > 0)
    return float(100 * np.sqrt(np.sum(w[use] * (yo[use] - yc[use]) ** 2) /
                               np.sum(w[use] * yo[use] ** 2)))


def lattice_matrix(cell: list[float]) -> np.ndarray:
    a, b, c, alpha, beta, gamma = cell[:6]
    al, be, ga = map(math.radians, (alpha, beta, gamma))
    va = np.array([a, 0., 0.])
    vb = np.array([b * math.cos(ga), b * math.sin(ga), 0.])
    cx = c * math.cos(be)
    cy = c * (math.cos(al) - math.cos(be) * math.cos(ga)) / math.sin(ga)
    cz = math.sqrt(max(c * c - cx * cx - cy * cy, 0.))
    return np.vstack((va, vb, np.array([cx, cy, cz])))


def coords(phase, labels: list[str]) -> dict[str, np.ndarray]:
    out = {}
    for label in labels:
        atom = phase.atom(label)
        if atom is None:
            raise KeyError(f"No atom {label} in {phase.name}")
        out[label] = np.asarray(atom.coordinates, float).copy()
    return out


def max_move(phase, old: dict[str, np.ndarray]) -> float:
    cell = phase.data["General"]["Cell"][1:7]
    mat = lattice_matrix(cell)
    moves = []
    for label, xyz0 in old.items():
        d = np.asarray(phase.atom(label).coordinates, float) - xyz0
        d -= np.round(d)
        moves.append(float(np.linalg.norm(d @ mat)))
    return max(moves, default=0.)


def scales_positive(project) -> bool:
    h = project.histogram(0)
    return all(p.data["Histograms"][h.name]["Scale"][0] > 0
               for p in project.phases())


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--group", choices=("heavy", "oxygen", "all"), default="all")
    ap.add_argument("--only-phase", default=None,
                    help="Restrict the guarded site tests to one phase name")
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    working = args.out / "working.gpx"
    shutil.copy2(args.input, working)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(working))
    project.set_Controls("cycles", 6)

    heavy = [
        ("MnWO4", ["W1"], 0.12),
        ("WO3", ["W1"], 0.15),
        ("WO3", ["W2"], 0.15),
        ("Mn2WO6", ["W1"], 0.15),
        ("MnWO4", ["Mn1"], 0.15),
        ("Mn2WO6", ["Mn1"], 0.18),
        ("Mn2WO6", ["Mn2"], 0.18),
    ]
    oxygen = [
        ("MnWO4", ["O1"], 0.22),
        ("MnWO4", ["O2"], 0.22),
    ] + [("WO3", [f"O{i}"], 0.22) for i in range(1, 7)] + [
        ("Mn2WO6", ["O1"], 0.24),
        ("Mn2WO6", ["O2"], 0.24),
        ("Mn2WO6", ["O3"], 0.24),
        ("mno2", ["O1"], 0.18),
        ("MnWO4_scheelite", ["O1"], 0.18),
    ]
    steps = heavy if args.group == "heavy" else oxygen if args.group == "oxygen" else heavy + oxygen
    if args.only_phase:
        steps = [step for step in steps if step[0] == args.only_phase]
    history = []

    for num, (phase_name, labels, limit) in enumerate(steps, start=1):
        before = args.out / "before.gpx"
        project.save(str(working))
        shutil.copy2(working, before)
        phase = project.phase(phase_name)
        oldxyz = coords(phase, labels)
        oldr = rwp(project.histogram(0))
        phase.set_refinements({"Atoms": {label: "X" for label in labels}})
        project.refine()
        newr = rwp(project.histogram(0))
        move = max_move(project.phase(phase_name), oldxyz)
        short = project.phase(phase_name).ShortDistances(True)
        ok = (np.isfinite(newr) and newr <= oldr + 1e-5 and move <= limit and
              not short and scales_positive(project))
        label = f"{num:02d}_{phase_name}_{'-'.join(labels)}"
        rec = {"label": label, "old_Rwp": oldr, "attempted_Rwp": newr,
               "max_move_A": move, "accepted": bool(ok), "short_distances": short}
        if ok:
            project.phase(phase_name).clear_refinements({"Atoms": labels})
            project.save(str(working))
            shutil.copy2(working, args.out / f"{label}.gpx")
        else:
            shutil.copy2(before, working)
            project = G2.G2Project(str(working))
        history.append(rec)
        print(json.dumps(rec), flush=True)

    project.save(str(working))
    (args.out / "coordinate_history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
