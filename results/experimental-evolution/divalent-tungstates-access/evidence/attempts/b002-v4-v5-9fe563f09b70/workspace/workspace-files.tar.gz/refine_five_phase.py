#!/usr/bin/env python3
"""Guarded joint refinement of the accepted five-phase checkpoint."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist) -> float:
    x, yo, w, yc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi) & (w > 0)
    return float(100 * np.sqrt(np.sum(w[use] * (yo[use] - yc[use]) ** 2) /
                               np.sum(w[use] * yo[use] ** 2)))


def valid(project) -> bool:
    hist = project.histogram(0)
    if not all(ph.data["Histograms"][hist.name]["Scale"][0] > 0
               for ph in project.phases()):
        return False
    expected = {
        "MnWO4": ((4.70, 4.90), (5.55, 5.85), (4.85, 5.10)),
        "WO3": ((7.45, 7.90), (7.30, 7.80), (10.20, 10.85)),
        "Mn2WO6": ((4.40, 4.80), (17.2, 18.5), (4.75, 5.15)),
        "MnO": ((4.30, 4.50), (4.30, 4.50), (4.30, 4.50)),
        "mno2": ((4.30, 4.50), (4.30, 4.50), (2.75, 2.98)),
    }
    for name, bounds in expected.items():
        abc = project.phase(name).data["General"]["Cell"][1:4]
        if not all(lo <= val <= hi for val, (lo, hi) in zip(abc, bounds)):
            return False
        if project.phase(name).ShortDistances(True):
            return False
    return True


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    working = args.out / "working.gpx"
    shutil.copy2(args.input, working)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(working))
    project.set_Controls("cycles", 8)
    history = []

    def run(label, setup):
        nonlocal project
        project.save(str(working))
        checkpoint = args.out / "before.gpx"
        shutil.copy2(working, checkpoint)
        old = rwp(project.histogram(0))
        setup(project)
        try:
            project.refine()
            new = rwp(project.histogram(0))
            ok = bool(np.isfinite(new) and new <= old + 1e-5 and valid(project))
            error = None
        except Exception as exc:
            new, ok, error = float("nan"), False, repr(exc)
        record = {"label": label, "old_Rwp": old,
                  "attempted_Rwp": new, "accepted": ok, "error": error}
        if ok:
            project.save(str(working))
            shutil.copy2(working, args.out / f"{label}.gpx")
        else:
            shutil.copy2(checkpoint, working)
            project = G2.G2Project(str(working))
        history.append(record)
        print(json.dumps(record), flush=True)

    def all_cells(p):
        for phase in p.phases():
            phase.set_refinements({"Cell": True})

    run("01_joint_cells", all_cells)
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    project.save(str(working))

    # Refit only the common instrumental terms that remain physical and useful.
    for num, key in enumerate(("U", "W", "X"), start=2):
        def setup(p, key=key):
            h = p.histogram(0)
            h.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
            h.set_refinements({"Instrument Parameters": [key]})
        run(f"{num:02d}_instrument_{key}", setup)
        project.histogram(0).clear_refinements({"Instrument Parameters": [key]})

    project.save(str(working))
    (args.out / "five_phase_history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
