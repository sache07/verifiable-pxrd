#!/usr/bin/env python3
"""Replace one phase by an analogue and perform guarded scale/cell tests."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist) -> float:
    x, yo, w, yc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi) & (w > 0)
    return float(100 * np.sqrt(np.sum(w[use] * (yo[use] - yc[use]) ** 2) /
                               np.sum(w[use] * yo[use] ** 2)))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("old_name")
    parser.add_argument("candidate", type=Path)
    parser.add_argument("new_name")
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    gpx = args.out / "trial.gpx"
    shutil.copy2(args.input, gpx)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(gpx))
    project.set_Controls("cycles", 8)
    hist = project.histogram(0)
    initial = rwp(hist)
    old_hap = project.phase(args.old_name).data["Histograms"][hist.name]
    old_hap["Use"] = False
    old_hap["Scale"][1] = False
    candidate = project.add_phase(str(args.candidate.resolve()),
                                  phasename=args.new_name,
                                  histograms=[hist], fmthint="CIF")
    cx, ct, cs, cia = candidate.data["General"]["AtomPtrs"]
    for atom in candidate.data["Atoms"]:
        atom[cia] = "I"
        atom[cia + 1:cia + 7] = [0.01, 0., 0., 0., 0., 0.]
    candidate.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=1.0)
    candidate.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    candidate.data["Histograms"][hist.name]["Scale"] = [1.0, True]
    project.save(str(gpx))

    records = []
    try:
        project.refine()
        scale_rwp = rwp(project.histogram(0))
        scale = float(project.phase(args.new_name).data["Histograms"][project.histogram(0).name]["Scale"][0])
        records.append({"step": "scale", "Rwp": scale_rwp, "scale": scale})
        scale_checkpoint = args.out / "scale.gpx"
        project.save(str(gpx))
        shutil.copy2(gpx, scale_checkpoint)
        if scale > 0 and scale_rwp < initial:
            candidate = project.phase(args.new_name)
            candidate.set_refinements({"Cell": True})
            project.refine()
            candidate.clear_refinements({"Cell": True})
            cell_rwp = rwp(project.histogram(0))
            cell = project.phase(args.new_name).data["General"]["Cell"][1:8]
            records.append({"step": "cell", "Rwp": cell_rwp, "cell": cell})
            project.save(str(gpx))
        fractions = project.histogram(0).ComputeMassFracs()
        payload = {"initial_Rwp": initial, "records": records,
                   "fractions": fractions,
                   "short_distances": project.phase(args.new_name).ShortDistances(True)}
    except Exception as exc:
        payload = {"initial_Rwp": initial, "records": records,
                   "error": repr(exc)}
    (args.out / "result.json").write_text(json.dumps(payload, indent=2, default=float) + "\n")
    print(json.dumps(payload, indent=2, default=float))


if __name__ == "__main__":
    main()
