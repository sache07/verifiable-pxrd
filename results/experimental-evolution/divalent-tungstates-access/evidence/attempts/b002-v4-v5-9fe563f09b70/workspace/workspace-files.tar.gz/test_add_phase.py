#!/usr/bin/env python3
"""Test one candidate phase in a fixed best multiphase checkpoint."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(h):
    x, yo, w, yc = [np.asarray(v, float) for v in h.data["data"][1][:4]]
    lo, hi = h.data["Limits"][1]
    q = (x >= lo) & (x <= hi) & (w > 0)
    return float(100 * np.sqrt(np.sum(w[q] * (yo[q] - yc[q]) ** 2) /
                               np.sum(w[q] * yo[q] ** 2)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("candidate", type=Path)
    ap.add_argument("name")
    ap.add_argument("out", type=Path)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    gpx = args.out / "trial.gpx"
    shutil.copy2(args.input, gpx)
    G2.SetPrintLevel("warn")
    p = G2.G2Project(str(gpx))
    h = p.histogram(0)
    old = rwp(h)
    # Hold established cells while the candidate scale is tested.
    for ph in p.phases():
        ph.clear_refinements({"Cell": True})
    cand = p.add_phase(str(args.candidate.resolve()), phasename=args.name,
                       histograms=[h], fmthint="CIF")
    cx, ct, cs, cia = cand.data["General"]["AtomPtrs"]
    for atom in cand.data["Atoms"]:
        atom[cia] = "I"; atom[cia + 1:cia + 7] = [0.01, 0., 0., 0., 0., 0.]
    cand.setSampleProfile(h, "size", "isotropic", 1.0, LGmix=1.0)
    cand.setSampleProfile(h, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap = cand.data["Histograms"][h.name]
    hap["Scale"] = [1.0, True]
    p.set_Controls("cycles", 7)
    p.save(str(gpx))
    try:
        p.refine()
        after_scale = rwp(p.histogram(0))
        scale = float(p.phase(args.name).data["Histograms"][p.histogram(0).name]["Scale"][0])
        scale_ok = np.isfinite(scale) and scale > 0 and after_scale < old
        scale_project = args.out / "scale.gpx"
        p.save(str(gpx)); shutil.copy2(gpx, scale_project)
        after_cell = None
        if scale_ok:
            p.phase(args.name).set_refinements({"Cell": True})
            p.refine()
            after_cell = rwp(p.histogram(0))
            p.phase(args.name).clear_refinements({"Cell": True})
            p.save(str(gpx))
        fractions = p.histogram(0).ComputeMassFracs() if scale_ok else None
        out = {"name": args.name, "candidate": str(args.candidate), "Rwp_before": old,
               "Rwp_scale": after_scale, "Rwp_cell": after_cell, "scale": scale,
               "scale_positive_improves": bool(scale_ok), "fractions": fractions,
               "cell": p.phase(args.name).data["General"]["Cell"][1:8]}
    except Exception as exc:
        out = {"name": args.name, "candidate": str(args.candidate), "Rwp_before": old,
               "error": repr(exc)}
    (args.out / "result.json").write_text(json.dumps(out, indent=2, default=float) + "\n")
    print(json.dumps(out, indent=2, default=float))


if __name__ == "__main__":
    main()
