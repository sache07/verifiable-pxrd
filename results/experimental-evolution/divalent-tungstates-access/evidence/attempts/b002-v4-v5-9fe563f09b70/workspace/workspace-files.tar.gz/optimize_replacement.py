#!/usr/bin/env python3
"""Give a replacement phase a bounded cell/profile/texture optimization."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist) -> float:
    x, yo, w, yc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi) & (w > 0)
    return float(100 * np.sqrt(np.sum(w[use] * (yo[use] - yc[use]) ** 2) /
                               np.sum(w[use] * yo[use] ** 2)))


def valid(project, name) -> bool:
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if hap and hap.get("Use", True) and hap["Scale"][0] <= 0:
            return False
    return not project.phase(name).ShortDistances(True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("phase")
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    working = args.out / "working.gpx"
    shutil.copy2(args.input, working)
    G2.SetPrintLevel("warn")
    history = []

    def trial(label, setup):
        trial_file = args.out / "trial.gpx"
        shutil.copy2(working, trial_file)
        project = G2.G2Project(str(trial_file))
        project.set_Controls("cycles", 7)
        setup(project)
        try:
            project.refine()
            score = rwp(project.histogram(0))
            ok = bool(np.isfinite(score) and valid(project, args.phase))
            err = None
        except Exception as exc:
            score, ok, err = float("inf"), False, repr(exc)
        project.save(str(trial_file))
        record = {"label": label, "Rwp": score, "valid": ok, "error": err,
                  "path": str(trial_file)}
        history.append(record)
        print(json.dumps(record), flush=True)
        return score if ok else float("inf"), trial_file

    def accept_best(candidates, label):
        score, path = min(candidates, key=lambda item: item[0])
        shutil.copy2(path, working)
        shutil.copy2(path, args.out / f"accepted_{label}.gpx")
        return score

    # Candidate cell, with all other accepted cells held.
    candidates = []
    for refine_cell in (False, True):
        def setup(project, refine_cell=refine_cell):
            phase = project.phase(args.phase)
            phase.data["General"]["Cell"][0] = refine_cell
        score, path = trial(f"cell_{refine_cell}", setup)
        saved = args.out / f"cell_{refine_cell}.gpx"
        shutil.copy2(path, saved)
        candidates.append((score, saved))
    accept_best(candidates, "cell")
    project = G2.G2Project(str(working))
    project.phase(args.phase).clear_refinements({"Cell": True})
    project.save(str(working))

    # Constant-volume crystallite-size screen.
    candidates = []
    for size in (0.04, 0.06, 0.10, 0.18, 0.35, 0.70, 1.50):
        def setup(project, size=size):
            hist = project.histogram(0)
            hap = project.phase(args.phase).data["Histograms"][hist.name]
            hap["Size"][1][0] = size
            hap["Size"][2][0] = False
        score, path = trial(f"size_{size:g}", setup)
        saved = args.out / f"size_{size:g}.gpx"
        shutil.copy2(path, saved)
        candidates.append((score, saved))
    accept_best(candidates, "size")

    # Isotropic microstrain screen.
    candidates = []
    for strain in (0., 1000., 2000., 4000., 6000., 8000.):
        def setup(project, strain=strain):
            hist = project.histogram(0)
            hap = project.phase(args.phase).data["Histograms"][hist.name]
            hap["Mustrain"][1][0] = strain
            hap["Mustrain"][2][0] = False
        score, path = trial(f"strain_{strain:g}", setup)
        saved = args.out / f"strain_{strain:g}.gpx"
        shutil.copy2(path, saved)
        candidates.append((score, saved))
    accept_best(candidates, "strain")

    # One March-Dollase term, screened over low-index axes.
    candidates = []
    for axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]):
        def setup(project, axis=axis):
            hist = project.histogram(0)
            po = project.phase(args.phase).data["Histograms"][hist.name]["Pref.Ori."]
            po[0], po[1], po[2], po[3] = "MD", 1.0, True, list(axis)
        score, path = trial("texture_" + "".join(map(str, axis)), setup)
        check = G2.G2Project(str(path))
        hist = check.histogram(0)
        ratio = float(check.phase(args.phase).data["Histograms"][hist.name]["Pref.Ori."][1])
        if not 0.70 <= ratio <= 1.40:
            score = float("inf")
        saved = args.out / ("texture_" + "".join(map(str, axis)) + ".gpx")
        shutil.copy2(path, saved)
        candidates.append((score, saved))
    accept_best(candidates, "texture")
    project = G2.G2Project(str(working))
    hist = project.histogram(0)
    project.phase(args.phase).data["Histograms"][hist.name]["Pref.Ori."][2] = False
    project.save(str(working))

    payload = {"best_Rwp": rwp(project.histogram(0)),
               "fractions": project.histogram(0).ComputeMassFracs(),
               "cell": project.phase(args.phase).data["General"]["Cell"][1:8],
               "profile": {
                   "size": project.phase(args.phase).data["Histograms"][hist.name]["Size"],
                   "microstrain": project.phase(args.phase).data["Histograms"][hist.name]["Mustrain"],
                   "preferred_orientation": project.phase(args.phase).data["Histograms"][hist.name]["Pref.Ori."],
               },
               "history": history}
    (args.out / "result.json").write_text(json.dumps(payload, indent=2, default=float) + "\n")
    print(json.dumps({k: v for k, v in payload.items() if k != "history"}, indent=2, default=float))


if __name__ == "__main__":
    main()
