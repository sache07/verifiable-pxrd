#!/usr/bin/env python3
"""Fit bounded Pbcn Mn2WO6 coordinates to Le Bail extracted intensities."""

from __future__ import annotations

import argparse
import copy
import json
import shutil
from pathlib import Path

import numpy as np
from scipy.optimize import differential_evolution
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIIstrIO as G2stIO
from GSASII import GSASIIstrMath as G2stMth


VARIABLES = [
    ("O2", 0), ("O2", 1), ("O2", 2),
    ("W1", 1), ("Mn2", 1), ("Mn1", 1),
    ("O3", 0), ("O3", 1), ("O3", 2),
    ("O1", 0), ("O1", 1), ("O1", 2),
]


def rwp(hist) -> float:
    x, yo, w, yc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi) & (w > 0)
    return float(100 * np.sqrt(np.sum(w[use] * (yo[use] - yc[use]) ** 2) /
                               np.sum(w[use] * yo[use] ** 2)))


def sf_context(gpx: Path):
    controls = G2stIO.GetControls(str(gpx))
    histograms, phases = G2stIO.GetUsedHistogramsAndPhases(str(gpx))
    rigid = G2stIO.GetRigidBodies(str(gpx))
    rb_ids = rigid.get("RBIds", {"Vector": [], "Residue": []})
    _, rb_dict = G2stIO.GetRigidBodyModels(rigid, Print=False)
    result = G2stIO.GetPhaseData(phases, {}, rb_ids, Print=False)
    (natoms, atom_index, _, phase_dict, _, ff, ef, orb, bl, mf, max_ss) = result
    calc = dict(controls)
    calc.update({"atomIndx": atom_index, "Natoms": natoms, "FFtables": ff,
                 "EFtables": ef, "ORBtables": orb, "BLtables": bl,
                 "MFtables": mf, "maxSSwave": max_ss})
    _, hap_dict, control_dict = G2stIO.GetHistogramPhaseData(
        phases, histograms, Controls=calc, Print=False)
    calc.update(control_dict)
    _, hist_dict, _, control_dict = G2stIO.GetHistogramData(histograms, Print=False)
    calc.update(control_dict)
    G2stIO.GetFprime(calc, histograms)
    parameters = {}
    parameters.update(rb_dict)
    parameters.update(phase_dict)
    parameters.update(hap_dict)
    parameters.update(hist_dict)
    hist_name = next(iter(histograms))
    phase = phases["Mn2WO6"]
    pfx = f"{phase['pId']}::"
    hfx = f":{histograms[hist_name]['hId']}:"
    cell_a = [parameters[pfx + f"A{i}"] for i in range(6)]
    reciprocal, _ = G2lat.A2Gmat(cell_a)
    reflections = copy.deepcopy(histograms[hist_name]["Reflection Lists"]["Mn2WO6"])
    return parameters, calc, reflections, reciprocal, hfx, pfx, phase["General"]["SGData"]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("structural_project", type=Path)
    parser.add_argument("lebail_project", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    parameters, calc, reflections, reciprocal, hfx, pfx, sg_data = sf_context(args.lebail_project)
    target_f2 = reflections["RefList"][:, 8].copy()
    positions = reflections["RefList"][:, 5].copy()
    correction = np.maximum(reflections["RefList"][:, 11] *
                            reflections["RefList"][:, 12], 1e-8)
    selected = (positions >= 18.) & (positions <= 80.) & (target_f2 >= 0.)
    base = {(label, axis): parameters[pfx + "A" + "xyz"[axis] + ":" + str(i)]
            for i, label in enumerate(["O2", "W1", "Mn2", "Mn1", "O3", "O1"])
            for axis in range(3)}
    atom_index = {label: i for i, label in enumerate(["O2", "W1", "Mn2", "Mn1", "O3", "O1"])}

    def calculate_f2(offsets):
        for (label, axis), offset in zip(VARIABLES, offsets):
            key = pfx + "dA" + "xyz"[axis] + ":" + str(atom_index[label])
            parameters[key] = float(offset)
        G2stMth.StructureFactor2(reflections, reciprocal, hfx, pfx,
                                 sg_data, calc, parameters)
        return reflections["RefList"][:, 9].copy()

    runs = [
        ("moderate_a", 5505, 0.015, 0.035, 0.020),
        ("moderate_b", 6606, 0.015, 0.040, 0.010),
    ]
    candidates = []
    for label, seed, y_limit, xz_limit, floor_fraction in runs:
        bounds = []
        for site, axis in VARIABLES:
            limit = y_limit if axis == 1 else xz_limit
            bounds.append((-limit, limit))

        def objective(offsets):
            model_f2 = calculate_f2(offsets)
            target = target_f2[selected] * correction[selected]
            model = model_f2[selected] * correction[selected]
            floor = floor_fraction * max(float(np.max(target)), 1.)
            weight = 1. / (target + floor)
            denom = float(np.sum(weight * model * model))
            scale = max(0., float(np.sum(weight * target * model) / denom)) if denom else 0.
            return float(np.sum(weight * (scale * model - target) ** 2) /
                         max(np.sum(weight * target ** 2), 1.))

        result = differential_evolution(objective, bounds, seed=seed,
                                        maxiter=45, popsize=8, tol=2e-5,
                                        polish=True, workers=1, updating="immediate")
        offsets = [float(value) for value in result.x]
        model_f2 = calculate_f2(offsets)
        record = {"label": label, "sf_objective": float(result.fun),
                  "offsets": offsets, "success": bool(result.success),
                  "nfev": int(result.nfev)}
        candidates.append((record, model_f2))
        print(json.dumps(record), flush=True)

    tested = []
    for record, _ in candidates:
        label = record["label"]
        path = args.out / f"{label}.gpx"
        shutil.copy2(args.structural_project, path)
        project = G2.G2Project(str(path))
        phase = project.phase("Mn2WO6")
        new_coordinates = {atom.label: list(atom.coordinates) for atom in phase.atoms()}
        for (site, axis), offset in zip(VARIABLES, record["offsets"]):
            new_coordinates[site][axis] = base[(site, axis)] + offset
        for site, xyz in new_coordinates.items():
            phase.atom(site).coordinates = xyz
            phase.atom(site).refinement_flags = " "
        project.set_Controls("cycles", 8)
        project.save(str(path))
        error = None
        try:
            project.refine()
            score = rwp(project.histogram(0))
            shorts = project.phase("Mn2WO6").ShortDistances(True)
            hist = project.histogram(0)
            scale = float(project.phase("Mn2WO6").data["Histograms"][hist.name]["Scale"][0])
            valid = bool(np.isfinite(score) and scale > 0 and not shorts)
            fractions = hist.ComputeMassFracs() if valid else None
            project.save(str(path))
        except Exception as exc:
            score, shorts, scale, valid, fractions = float("inf"), [], float("nan"), False, None
            error = repr(exc)
        test = {**record, "Rwp": score, "scale": scale, "valid": valid,
                "short_distances": shorts, "fractions": fractions,
                "coordinates": new_coordinates, "project": str(path), "error": error}
        tested.append(test)
        print(json.dumps({k: v for k, v in test.items() if k != "fractions"}, default=float), flush=True)

    valid_tests = [test for test in tested if test["valid"]]
    best = min(valid_tests, key=lambda item: item["Rwp"]) if valid_tests else None
    if best:
        shutil.copy2(best["project"], args.out / "working.gpx")
    payload = {"variables": [[site, axis] for site, axis in VARIABLES],
               "best": best, "tests": tested}
    (args.out / "results.json").write_text(json.dumps(payload, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
