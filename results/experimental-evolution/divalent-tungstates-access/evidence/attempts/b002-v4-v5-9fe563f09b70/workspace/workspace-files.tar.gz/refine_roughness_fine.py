#!/usr/bin/env python3
"""Fine, guarded screen of a one-parameter Suortti surface correction."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist) -> float:
    x, yo, w, yc = (np.asarray(v, float) for v in hist.data["data"][1][:4])
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi) & (w > 0)
    return float(100.0 * np.sqrt(
        np.sum(w[use] * (yo[use] - yc[use]) ** 2) /
        np.sum(w[use] * yo[use] ** 2)
    ))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    records = []
    a_values = np.arange(0.375, 0.651, 0.025)
    for fixed_a in a_values:
        for initial_b in (0.10, 0.70):
            path = args.out / f"A_{fixed_a:.3f}_B0_{initial_b:.2f}.gpx"
            shutil.copy2(args.input, path)
            project = G2.G2Project(str(path))
            project.set_Controls("cycles", 12)
            sample = project.histogram(0).data["Sample Parameters"]
            sample["SurfRoughA"] = [float(fixed_a), False]
            sample["SurfRoughB"] = [initial_b, True]
            error = None
            try:
                project.refine()
                cov = project.data["Covariance"]["data"]
                rvals = cov.get("Rvals", {})
                b_value = float(sample["SurfRoughB"][0])
                score = rwp(project.histogram(0))
                positive = all(
                    phase.data["Histograms"][project.histogram(0).name]["Scale"][0] > 0
                    for phase in project.phases()
                )
                valid = bool(
                    np.isfinite(score) and 0.0 <= b_value <= 1.0 and positive and
                    rvals.get("converged", False) and rvals.get("Max shft/sig", 1e9) < 1.0
                )
                project.histogram(0).clear_refinements(
                    {"Sample Parameters": ["SurfRoughB"]}
                )
                project.save(str(path))
            except Exception as exc:
                score = float("inf")
                b_value = float("nan")
                valid = False
                rvals = {}
                error = repr(exc)
            record = {
                "fixed_A": float(fixed_a),
                "initial_B": initial_b,
                "refined_B": b_value,
                "Rwp": score,
                "converged": rvals.get("converged", False),
                "max_shift_over_esd": rvals.get("Max shft/sig"),
                "valid": valid,
                "path": str(path),
                "error": error,
            }
            records.append(record)
            print(json.dumps(record), flush=True)

    valid_records = [record for record in records if record["valid"]]
    if not valid_records:
        raise RuntimeError("No converged physical fine-grid trial")
    best = min(valid_records, key=lambda record: record["Rwp"])
    shutil.copy2(best["path"], args.out / "working.gpx")
    (args.out / "result.json").write_text(
        json.dumps({"best": best, "trials": records}, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
