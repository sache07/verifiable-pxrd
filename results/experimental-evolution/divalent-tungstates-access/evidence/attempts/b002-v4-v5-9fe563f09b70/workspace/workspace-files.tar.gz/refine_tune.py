#!/usr/bin/env python3
"""Apply bounded profile checkpoints after single-term screening."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(h):
    x, yo, w, yc = [np.asarray(v, float) for v in h.data["data"][1][:4]]
    lo, hi = h.data["Limits"][1]
    q = (x >= lo) & (x <= hi) & (w > 0)
    return float(100 * np.sqrt(np.sum(w[q] * (yo[q] - yc[q]) ** 2) /
                               np.sum(w[q] * yo[q] ** 2)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("out", type=Path)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    working = args.out / "working.gpx"
    shutil.copy2(args.input, working)
    G2.SetPrintLevel("warn")
    p = G2.G2Project(str(working))
    p.set_Controls("cycles", 7)
    hist = []

    def valid_scales():
        h = p.histogram(0)
        return all(ph.data["Histograms"][h.name]["Scale"][0] > 0 for ph in p.phases())

    def run(label, setup, validate=lambda: True):
        nonlocal p
        p.save(str(working))
        before = args.out / "before.gpx"
        shutil.copy2(working, before)
        old = rwp(p.histogram(0))
        setup(p)
        p.refine()
        new = rwp(p.histogram(0))
        ok = bool(np.isfinite(new) and new <= old + 1e-5 and valid_scales() and validate())
        rec = {"label": label, "old_Rwp": old, "attempted_Rwp": new, "accepted": ok}
        if ok:
            p.save(str(working)); shutil.copy2(working, args.out / f"{label}.gpx")
        else:
            shutil.copy2(before, working); p = G2.G2Project(str(working))
        hist.append(rec); print(json.dumps(rec), flush=True)

    def set_profile(phase, key, value):
        h = p.histogram(0); d = p.phase(phase).data["Histograms"][h.name]
        d[key][1][0] = float(value); d[key][2][0] = False

    run("01_MnWO4_size1p5_strain0",
        lambda _: (set_profile("MnWO4", "Size", 1.5), set_profile("MnWO4", "Mustrain", 0.0)))
    run("02_MnO_strain8000", lambda _: set_profile("MnO", "Mustrain", 8000.0))

    bounds = {"W": (2., 40.), "U": (0., 40.), "X": (0.1, 6.),
              "SH/L": (0.005, 0.10), "Polariz.": (0.5, 1.0)}
    for i, key in enumerate(bounds, start=3):
        def setup(_, key=key):
            h = p.histogram(0)
            h.clear_refinements({"Instrument Parameters": list(bounds)})
            h.set_refinements({"Instrument Parameters": [key]})
        lo, hi = bounds[key]
        run(f"{i:02d}_{key.replace('/', '_').replace('.', '')}", setup,
            lambda key=key, lo=lo, hi=hi: lo <= p.histogram(0).data["Instrument Parameters"][0][key][1] <= hi)
        p.histogram(0).clear_refinements({"Instrument Parameters": [key]})

    p.save(str(working))
    (args.out / "tune_history.json").write_text(json.dumps(hist, indent=2) + "\n")


if __name__ == "__main__":
    main()
