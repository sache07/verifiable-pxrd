#!/usr/bin/env python3
"""Build and refine a GSAS-II screening project from the specimen pattern.

This is intentionally conservative: structures are fixed while background,
phase scales, calibration, cells and simple peak-width terms are introduced in
separate checkpoints. It is used to compare candidate phase inventories before
the final coordinate/profile refinement.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def parse_phase(text: str) -> tuple[str, str]:
    if "=" not in text:
        raise argparse.ArgumentTypeError("phase must be NAME=PATH")
    name, path = text.split("=", 1)
    return name, path


def write_inputs(root: Path, pattern: Path) -> tuple[Path, Path]:
    root.mkdir(parents=True, exist_ok=True)
    data = np.loadtxt(pattern, delimiter=",", skiprows=1)
    xye = root / "pattern.xye"
    # Raw counts have Poisson counting statistics. No point uncertainties were
    # supplied, so sqrt(counts) is the least-assumptive weighting model.
    np.savetxt(xye, np.column_stack((data, np.sqrt(np.maximum(data[:, 1], 1.0)))),
               fmt="%.8f %.8f %.8f")
    inst = root / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file; Cu Kalpha Bragg-Brentano starting model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return xye, inst


def rwp(hist) -> float:
    x, yo, w, yc, bg, yd = [np.asarray(a, dtype=float) for a in hist.data["data"][1][:6]]
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi) & np.isfinite(yo) & np.isfinite(yc) & (w > 0)
    return float(100.0 * np.sqrt(np.sum(w[use] * (yo[use] - yc[use]) ** 2) /
                                 np.sum(w[use] * yo[use] ** 2)))


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "scale": float(hap["Scale"][0]),
            "cell": [float(v) for v in phase.data["General"]["Cell"][1:8]],
            "size": list(hap["Size"][1]),
            "mustrain": list(hap["Mustrain"][1]),
        }
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    out = {
        "label": label,
        "Rwp": rwp(hist),
        "GSAS_wR": hist.get_wR(),
        "phases": phases,
        "instrument": {k: v[1] if isinstance(v, list) and len(v) > 1 else v
                       for k, v in inst.items()},
        "sample": {k: v[0] if isinstance(v, list) and len(v) == 2 else v
                   for k, v in sample.items()},
        "background": hist.data["Background"][0],
    }
    print(json.dumps(out, indent=2, default=str), flush=True)
    return out


def refine(project, root: Path, label: str, records: list[dict]) -> None:
    project.set_Controls("cycles", 6)
    project.refine()
    project.save(str(root / f"{label}.gpx"))
    records.append(snapshot(project, label))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--pattern", default=Path("inputs/pattern.csv"), type=Path)
    ap.add_argument("--phase", action="append", required=True, type=parse_phase)
    ap.add_argument("--quick", action="store_true")
    args = ap.parse_args()

    root = args.out.resolve()
    xye, inst = write_inputs(root, args.pattern.resolve())
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(root / "screen.gpx"))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.set_refinements({
        "Limits": [float(np.loadtxt(args.pattern, delimiter=",", skiprows=1)[0, 0]),
                   float(np.loadtxt(args.pattern, delimiter=",", skiprows=1)[-1, 0])],
        "Background": {"type": "chebyschev-1", "no. coeffs": 12,
                       "coeffs": [1200.0] + [0.0] * 11, "refine": False},
    })
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    # Keep the histogram scale fixed; otherwise it is exactly redundant with
    # refining every HAP phase scale.
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    phases = []
    for name, path in args.phase:
        phase = project.add_phase(str(Path(path).resolve()), phasename=name,
                                  histograms=[hist], fmthint="CIF")
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        phase.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 300.0, LGmix=1.0)
        phases.append(phase)

    project.save()
    records: list[dict] = []
    snapshot(project, "initial")

    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    refine(project, root, "01_scale_background", records)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, root, "02_zero", records)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, root, "03_cells", records)

    if args.quick:
        project.save(str(root / "screen.gpx"))
        (root / "summary.json").write_text(json.dumps(records, indent=2, default=str) + "\n")
        return

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, root, "04_shift", records)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, root, "05_instrument", records)

    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    refine(project, root, "06_size", records)

    for phase in phases:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    refine(project, root, "07_mustrain", records)

    project.save(str(root / "screen.gpx"))
    (root / "summary.json").write_text(json.dumps(records, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
