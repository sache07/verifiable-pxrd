#!/usr/bin/env python3
"""Rank chemically plausible A2WO6 topology transfers against the residual."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from scipy.optimize import differential_evolution
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Element, Lattice, Structure
from GSASII import GSASIIscriptable as G2


COD = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif")
SOURCES = [
    ("Fe2WO6_Pbcn", "2310464"),
    ("Cr2WO6_trirutile", "1530909"),
    ("V2WO6_trirutile", "1008912"),
    ("Y2WO6_P212121", "1541070"),
    ("Y2WO6_P4nmm", "1563285"),
    ("Lu2WO6_P2c", "7712111"),
    ("Nd2WO6_C2c", "1530601"),
    ("Na2WO6_Pbca", "1541344"),
    ("Bi2WO6_Aea2", "1528730"),
    ("Bi2WO6_C2m", "1528731"),
    ("Bi2WO6_Pca21", "1567271"),
    ("La2WO6_Pmn21", "4501292"),
]


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def transfer(cod_id: str) -> Structure:
    structure = Structure.from_file(cod_path(cod_id), primitive=False)
    replacements = {sp: Element("Mn") for sp in structure.composition.elements
                    if sp.symbol not in ("W", "O")}
    structure.replace_species(replacements)
    return structure


def parameterization(structure: Structure):
    crystal = structure.get_space_group_info(symprec=1e-3)[0]
    if crystal.startswith("P4") or crystal.startswith("I4"):
        return "tetragonal", 2
    if abs(structure.lattice.a - structure.lattice.b) < 1e-4 and \
            abs(structure.lattice.b - structure.lattice.c) < 1e-4:
        return "cubic", 1
    return "independent", 3


def scaled_structure(template: Structure, mode: str, factors) -> Structure:
    a, b, c = template.lattice.abc
    alpha, beta, gamma = template.lattice.angles
    if mode == "tetragonal":
        fa, fc = factors
        lengths = (a * fa, b * fa, c * fc)
    elif mode == "cubic":
        lengths = tuple(v * factors[0] for v in (a, b, c))
    else:
        lengths = tuple(v * f for v, f in zip((a, b, c), factors))
    lattice = Lattice.from_parameters(*lengths, alpha, beta, gamma)
    return Structure(lattice, [site.species for site in template], template.frac_coords,
                     site_properties=template.site_properties)


def physical(structure: Structure) -> bool:
    # Fast local checks suitable for rejecting obviously stretched/collapsed transfers.
    for i, site in enumerate(structure):
        distances = []
        for neighbor in structure.get_neighbors(site, 3.0):
            if neighbor.specie.symbol == "O":
                distances.append(float(neighbor.nn_distance))
        if site.specie.symbol == "W":
            if len([d for d in distances if 1.62 <= d <= 2.35]) < 4:
                return False
        elif site.specie.symbol == "Mn":
            if len([d for d in distances if 1.70 <= d <= 2.65]) < 4:
                return False
    oxygen = [i for i, site in enumerate(structure) if site.specie.symbol == "O"]
    for i in oxygen:
        for neighbor in structure.get_neighbors(structure[i], 1.72):
            if neighbor.specie.symbol == "O":
                return False
    return True


def pattern_profile(structure: Structure, x: np.ndarray, fwhm: float,
                    calculator: XRDCalculator) -> np.ndarray:
    pattern = calculator.get_pattern(structure, two_theta_range=(float(x[0]) - 1,
                                                                 float(x[-1]) + 1),
                                     scaled=False)
    positions = list(pattern.x)
    intensities = list(pattern.y)
    # Reproduce the measured K-alpha doublet.
    for pos, intensity in list(zip(pattern.x, pattern.y)):
        theta = math.radians(pos / 2)
        arg = (1.544426 / 1.540598) * math.sin(theta)
        if arg < 1:
            positions.append(2 * math.degrees(math.asin(arg)))
            intensities.append(0.5 * intensity)
    sigma = fwhm / 2.354820045
    profile = np.zeros_like(x)
    radius = max(4, int(math.ceil(4 * sigma / np.median(np.diff(x)))))
    for pos, intensity in zip(positions, intensities):
        mid = int(np.searchsorted(x, pos))
        lo, hi = max(0, mid - radius), min(len(x), mid + radius + 1)
        if lo < hi:
            z = (x[lo:hi] - pos) / sigma
            profile[lo:hi] += intensity * np.exp(-0.5 * z * z) / sigma
    return profile


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--start", type=int, default=0,
                        help="Start at this zero-based entry in SOURCES")
    parser.add_argument("--stop", type=int, default=None,
                        help="Stop before this zero-based entry in SOURCES")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    # Refit the ordinary accepted phases with the questioned analogue disabled.
    scratch = args.out / "without_mn2wo6.gpx"
    shutil.copy2(args.input, scratch)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(scratch))
    hist = project.histogram(0)
    project.phase("Mn2WO6").data["Histograms"][hist.name]["Use"] = False
    project.phase("Mn2WO6").data["Histograms"][hist.name]["Scale"][1] = False
    project.set_Controls("cycles", 7)
    project.save(str(scratch))
    project.refine()
    hist = project.histogram(0)
    x, observed, weights, calculated = [np.asarray(v, float)
                                         for v in hist.data["data"][1][:4]]
    residual = observed - calculated
    use = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1]) & (weights > 0)
    baseline_sse = float(np.sum(weights[use] * residual[use] ** 2))
    denominator = float(np.sum(weights[use] * observed[use] ** 2))
    calculator = XRDCalculator(wavelength=1.540598)
    widths = (0.10, 0.16, 0.24, 0.34, 0.48, 0.68)
    results = []

    for label, cod_id in SOURCES[args.start:args.stop]:
        template = transfer(cod_id)
        mode, dimensions = parameterization(template)

        def objective(factors):
            structure = scaled_structure(template, mode, factors)
            if not physical(structure):
                return 1e30
            best = 0.0
            for width in widths:
                profile = pattern_profile(structure, x, width, calculator)
                denom = float(np.sum(weights[use] * profile[use] ** 2))
                if denom <= 0:
                    continue
                scale = max(0.0, float(np.sum(weights[use] * residual[use] * profile[use]) / denom))
                reduction = 2 * scale * float(np.sum(weights[use] * residual[use] * profile[use])) - scale * scale * denom
                best = max(best, reduction)
            return -best

        bounds = [(0.82, 1.12)] * dimensions
        optimization = differential_evolution(objective, bounds, seed=1729,
                                                maxiter=8, popsize=5, polish=True,
                                                workers=1, updating="immediate")
        factors = [float(v) for v in optimization.x]
        structure = scaled_structure(template, mode, factors)
        best = None
        for width in widths:
            profile = pattern_profile(structure, x, width, calculator)
            denom = float(np.sum(weights[use] * profile[use] ** 2))
            scale = max(0.0, float(np.sum(weights[use] * residual[use] * profile[use]) / denom)) if denom else 0.0
            trial_sse = float(np.sum(weights[use] * (residual[use] - scale * profile[use]) ** 2))
            if best is None or trial_sse < best[0]:
                best = (trial_sse, width, scale)
        trial_sse, width, scale = best
        result = {
            "label": label,
            "source_cod_id": cod_id,
            "source_space_group": template.get_space_group_info(symprec=1e-3)[0],
            "mode": mode,
            "factors": factors,
            "cell": list(structure.lattice.abc) + list(structure.lattice.angles),
            "physical": physical(structure),
            "fwhm_deg": width,
            "profile_scale": scale,
            "delta_chi2": baseline_sse - trial_sse,
            "approx_Rwp": 100 * math.sqrt(trial_sse / denominator),
        }
        results.append(result)
        structure.to(filename=args.out / f"{label}.cif")
        print(json.dumps(result), flush=True)

    results.sort(key=lambda item: item["delta_chi2"], reverse=True)
    payload = {"without_Mn2WO6_Rwp": 100 * math.sqrt(baseline_sse / denominator),
               "ranked_models": results}
    (args.out / "results.json").write_text(json.dumps(payload, indent=2) + "\n")


if __name__ == "__main__":
    main()
