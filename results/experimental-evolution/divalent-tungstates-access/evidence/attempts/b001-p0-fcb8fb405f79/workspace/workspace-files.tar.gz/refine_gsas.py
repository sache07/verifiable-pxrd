#!/usr/bin/env python3
"""Build and refine the three-phase GSAS-II model for the supplied pattern."""

from __future__ import annotations

import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def write_inputs() -> tuple[Path, Path]:
    raw = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    x = np.asarray(raw[raw.dtype.names[0]], dtype=float)
    y = np.asarray(raw[raw.dtype.names[1]], dtype=float)
    xye = ROOT / "pattern.xye"
    np.savetxt(xye, np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))), fmt="%.8f %.8f %.8f")
    inst = ROOT / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.10;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def summarize(project: G2.G2Project, label: str) -> None:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    print(f"\n=== {label} ===")
    print("wR", hist.get_wR())
    print(
        "instrument",
        {k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.") if k in inst},
    )
    print(
        "sample",
        {k: sample[k][0] if isinstance(sample[k], list) else sample[k] for k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB") if k in sample},
    )
    scales = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        scales.append(hap["Scale"][0] * phase.data["General"]["Mass"])
    scales = np.asarray(scales)
    fractions = scales / scales.sum()
    for phase, frac in zip(project.phases(), fractions):
        hap = phase.data["Histograms"][hist.name]
        print(
            phase.name,
            "wt", float(frac),
            "cell", phase.get_cell(),
            "scale", hap["Scale"][0],
            "size", hap["Size"],
            "mustrain", hap["Mustrain"],
            "PO", hap["Pref.Ori."],
        )
    cov = project.data.get("Covariance", {}).get("data", {})
    print("GOF", cov.get("Rvals", {}).get("GOF"), "Nvars", len(cov.get("varyList", [])))


def do_refine(project: G2.G2Project, label: str, cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    summarize(project, label)
    project.save(ROOT / "work.gpx")
    shutil.copy2(ROOT / "work.gpx", ROOT / f"stage_{label}.gpx")


def build_project() -> G2.G2Project:
    G2.SetPrintLevel("warn")
    xye, instfile = write_inputs()
    project = G2.G2Project(newgpx=str(ROOT / "work.gpx"))
    hist = project.add_powder_histogram(str(xye), str(instfile), fmthint="xye")
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    phase_files = [
        ("ZnWO4", ROOT / "models" / "ZnWO4_init.cif"),
        ("WO3", ROOT / "models" / "WO3_init.cif"),
    ]
    phases = [
        project.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
        for name, path in phase_files
    ]

    # Keep broadening and specimen terms inside physically meaningful ranges.
    bounds = {
        ":0:Zero": (-0.25, 0.25),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:Shift": (-800.0, 800.0),
    }
    for pid in range(len(phases)):
        bounds[f"{pid}:0:Size;i"] = (0.04, 1.5)
        bounds[f"{pid}:0:Mustrain;i"] = (0.0, 8000.0)
    for variable, (lower, upper) in bounds.items():
        project.set_Controls("parmMin", lower, variable)
        project.set_Controls("parmMax", upper, variable)

    coordinate_bounds = {
        "0::dAy:0": (0.15, 0.21),
        "0::dAy:1": (0.62, 0.69),
        "0::dAx:2": (0.19, 0.25),
        "0::dAy:2": (0.08, 0.14),
        "0::dAz:2": (-0.07, 0.01),
        "0::dAx:3": (0.23, 0.29),
        "0::dAy:3": (0.35, 0.41),
        "0::dAz:3": (0.36, 0.42),
        "1::dAx:1": (0.237, 0.257),
        "1::dAy:1": (0.023, 0.043),
        "1::dAz:1": (0.771, 0.791),
        "1::dAx:7": (0.242, 0.262),
        "1::dAy:7": (0.016, 0.036),
        "1::dAz:7": (0.275, 0.295),
    }
    for variable, (lower, upper) in coordinate_bounds.items():
        project.set_Controls("parmMin", lower, variable)
        project.set_Controls("parmMax", upper, variable)

    # Fixed-profile nonnegative least squares gives stable starting scales.
    initial_scales = [78.0, 7.9]
    for phase, initial_scale in zip(phases, initial_scales):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [initial_scale, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]

    # A modest polynomial is sufficient to establish scales before more
    # profile and specimen terms are introduced.
    hist.set_refinements(
        {
            "Limits": [10.0, 100.05],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1100.0, -460.0, 400.0, -260.0, 155.0, -120.0, 30.0, -90.0, 45.0, -12.0, 3.0, -18.0],
                "refine": True,
            },
        }
    )
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    project.save()
    summarize(project, "initial")
    return project


def main() -> None:
    project = build_project()
    hist = project.histograms()[0]
    phases = project.phases()

    do_refine(project, "01_scale_background", cycles=4)

    # Refine the common angular calibration, then introduce one lattice at a
    # time so a weak phase cannot destabilize the normal matrix.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    do_refine(project, "02_zero", cycles=4)

    for phase in phases:
        phase.set_refinements({"Cell": False})
    phases[0].set_refinements({"Cell": True})
    do_refine(project, "03_cell_ZnWO4", cycles=5)

    phases[0].set_refinements({"Cell": False})
    phases[1].set_refinements({"Cell": True})
    do_refine(project, "04_cell_WO3", cycles=5)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    do_refine(project, "05_cells_joint", cycles=4)

    # Instrumental and isotropic sample broadening.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.3, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    do_refine(project, "06_profile", cycles=6)

    # Refine the scattering-dominant sites first. Oxygen in the minor WO3
    # phase is held to the published model because it is not independently
    # determined at this abundance and resolution.
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X"]})
    for phase in phases:
        phase.set_refinements({"Cell": False})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    phases[0].set_refinements({"Atoms": {"W1": "X", "Zn1": "X"}})
    do_refine(project, "07_ZnWO4_heavy", cycles=5)

    phases[0].set_refinements({"Atoms": {"O1": "X", "O2": "X"}})
    do_refine(project, "08_ZnWO4_oxygen", cycles=6)

    phases[1].set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
    do_refine(project, "09_WO3_heavy", cycles=5)

    # Re-optimize peak positions and widths around the bounded coordinates.
    hist.set_refinements({"Instrument Parameters": ["Zero", "U", "W", "X"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    do_refine(project, "10_joint", cycles=6)

    project.save(ROOT / "final.gpx")


if __name__ == "__main__":
    main()
