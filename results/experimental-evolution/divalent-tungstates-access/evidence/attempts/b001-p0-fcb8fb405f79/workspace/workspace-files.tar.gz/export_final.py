#!/usr/bin/env python3
"""Export the submitted files from final.gpx."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def main() -> None:
    project = G2.G2Project(gpxfile=str(ROOT / "final.gpx"))
    hist = project.histograms()[0]
    phases = project.phases()
    cif_names = {
        "ZnWO4": "ZnWO4.cif",
        "WO3": "WO3.cif",
        "ZnO": "ZnO.cif",
    }
    for obj in phases:
        obj.export_CIF(str(ROOT / cif_names[obj.name]))

    arrays = [np.asarray(v, dtype=float) for v in hist.data["data"][1]]
    two_theta, observed, weights, calculated, background, difference = arrays
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
        for row in zip(two_theta, observed, calculated, difference):
            writer.writerow([f"{value:.15g}" for value in row])

    residual = observed - calculated
    denominator = float(np.dot(weights, observed * observed))
    rwp = 100.0 * float(np.sqrt(np.dot(weights, residual * residual) / denominator))
    rp = 100.0 * float(np.sum(np.abs(residual)) / np.sum(np.abs(observed)))
    rvals = project.data["Covariance"]["data"]["Rvals"]
    nobs = int(rvals["Nobs"])
    nvars = int(rvals["Nvars"])
    rexp = 100.0 * float(np.sqrt((nobs - nvars) / denominator))
    gof = float(rvals["GOF"])
    amounts = np.asarray([
        float(obj.data["Histograms"][hist.name]["Scale"][0])
        * float(obj.data["General"]["Mass"])
        for obj in phases
    ])
    fractions = amounts / amounts.sum()
    phase_results = [
        {
            "name": obj.name,
            "cif_path": cif_names[obj.name],
            "weight_fraction": float(fraction),
        }
        for obj, fraction in zip(project.phases(), fractions)
    ]
    result = {
        "phases": phase_results,
        "weight_fraction_basis": "normalized over modeled crystalline phases",
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "Rexp_percent": rexp,
            "goodness_of_fit": gof,
            "chi_squared": float(rvals["chisq"]),
            "reduced_chi_squared": gof * gof,
            "data_points": nobs,
            "refined_variables": nvars,
        },
    }
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    main()
