#!/usr/bin/env python3
"""Targeted late-stage GSAS-II trials for the final three-phase model."""

from __future__ import annotations

import shutil
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def clone_project(source: str, target: str) -> G2.G2Project:
    source_path = ROOT / source
    target_path = ROOT / target
    shutil.copy2(source_path, target_path)
    return G2.G2Project(gpxfile=str(target_path))


def rwp(project: G2.G2Project) -> float:
    return float(project.histograms()[0].get_wR())


def report(project: G2.G2Project, label: str) -> None:
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    print(f"{label}: Rwp={rwp(project):.6f}% GOF={rvals.get('GOF')} Nvars={rvals.get('Nvars')}")
    print("  limits", hist.data["Limits"])
    print("  background", hist.data["Background"][0][:3])
    print("  sample", {k: hist.data["Sample Parameters"][k] for k in ("SurfRoughA", "SurfRoughB", "Shift")})
    inst = hist.data["Instrument Parameters"][0]
    print("  instrument", {k: inst[k] for k in ("Zero", "U", "V", "W", "X", "SH/L", "Polariz.")})
    weighted = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted.append(float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]))
    weighted = np.asarray(weighted)
    for pid, (phase, wt) in enumerate(zip(project.phases(), weighted / weighted.sum())):
        hap = phase.data["Histograms"][hist.name]
        atoms = phase.atoms()
        adps = []
        for atom in atoms:
            adps.append(atom.uiso if atom.adp_flag == "I" else tuple(atom.ADP))
        print(
            f"  {pid} {phase.name}: wt={wt:.7f} cell={phase.get_cell()} "
            f"scale={hap['Scale'][0]:.8g} size={hap['Size']} strain={hap['Mustrain']} "
            f"PO={hap['Pref.Ori.']} ADP={adps}"
        )


def refine(project: G2.G2Project, cycles: int = 12) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    project.save()


def common_uiso(source: str, target: str) -> None:
    project = clone_project(source, target)
    hist = project.histograms()[0]
    x = np.asarray(hist.data["data"][1][0], dtype=float)
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]

    # The ZnO literature CIF is anisotropic. The experiment generator uses a
    # single isotropic U for every atom in a phase, so normalize all atoms and
    # then constrain each phase's values to be equal.
    initial = [0.008, 0.008, 0.008]
    for pid, (phase, value) in enumerate(zip(project.phases(), initial)):
        atom_vars = []
        for aid, atom in enumerate(phase.atoms()):
            if atom.adp_flag != "I":
                atom.data[atom.cia] = "I"
            atom.uiso = value
            atom.refinement_flags = "U"
            var = f"{pid}::AUiso:{aid}"
            atom_vars.append(var)
            project.set_Controls("parmMin", 0.001, var)
            project.set_Controls("parmMax", 0.03, var)
        project.add_EquivConstr(tuple(atom_vars), reloadIdx=(pid == 0))

    refine(project, cycles=16)
    report(project, target)


def coordinates(source: str, target: str) -> None:
    project = clone_project(source, target)
    phase = project.phases()[0]
    bounds = {
        "0::dAy:0": (0.13, 0.),
    }


def main() -> None:
    if len(sys.argv) != 4 or sys.argv[1] != "uiso":
        raise SystemExit("usage: optimize_final.py uiso SOURCE.gpx TARGET.gpx")
    common_uiso(sys.argv[2], sys.argv[3])


if __name__ == "__main__":
    main()
