#!/usr/bin/env python3
"""Branch a stable project and test one March-Dollase orientation model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="stage_08_ZnWO4_oxygen.gpx")
    ap.add_argument("--phase", type=int, required=True)
    ap.add_argument("--axis", required=True, help="comma-separated h,k,l")
    ap.add_argument("--start", type=float, default=1.0)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    axis = [int(v) for v in args.axis.split(",")]

    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(Path(args.base).resolve()))
    project.save(str(Path(args.out).resolve()))
    hist = project.histograms()[0]
    for item in hist.data["Instrument Parameters"][0].values():
        if isinstance(item, list) and len(item) > 2 and isinstance(item[2], bool):
            item[2] = False
    for item in hist.data["Sample Parameters"].values():
        if isinstance(item, list) and len(item) > 1 and isinstance(item[1], bool):
            item[1] = False

    for i, phase in enumerate(project.phases()):
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = float(args.start) if i == args.phase else 1.0
        hap["Pref.Ori."][3] = axis
        phase.set_HAP_refinements({"Scale": True})
        if i == args.phase:
            phase.set_HAP_refinements({"Pref.Ori.": True})

    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    phases = project.phases()
    weights = []
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        weights.append(hap["Scale"][0] * phase.data["General"]["Mass"])
    total = sum(weights)
    target_hap = phases[args.phase].data["Histograms"][hist.name]
    print(
        json.dumps(
            {
                "phase": phases[args.phase].name,
                "axis": axis,
                "start": args.start,
                "ratio": target_hap["Pref.Ori."][1],
                "rwp": hist.get_wR(),
                "weights": [v / total for v in weights],
                "out": args.out,
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
