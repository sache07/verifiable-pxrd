#!/usr/bin/env python3
"""Compare one instrumental profile term from the accepted physical model."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

from refine_terminal import activate, clear, prepare, snapshot


def main(source: str, output: str, mode: str) -> None:
    project = G2.G2Project(gpxfile=source, newgpx=output)
    prepare(project)
    hist = project.histograms()[0]
    # X was previously inseparable from phase-size broadening. Compare every
    # branch from the nominal instrument value supplied to the solver.
    hist.InstrumentParameters["X"][1] = 1.5
    rows = []
    for pass_index in range(1, 5):
        activate(project, False)
        if mode in ("W", "X"):
            hist.InstrumentParameters[mode][2] = True
            lower, upper = ((2.0, 40.0) if mode == "W" else (0.1, 6.0))
            project.set_Controls("parmMin", lower, variable=f":0:{mode}")
            project.set_Controls("parmMax", upper, variable=f":0:{mode}")
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        row = snapshot(project, pass_index, False)
        row["mode"] = mode
        row["W"] = float(hist.InstrumentParameters["W"][1])
        row["X"] = float(hist.InstrumentParameters["X"][1])
        rows.append(row)
        print(json.dumps(row), flush=True)
        maximum = row["max_shift_esd"]
        if row["converged"] and maximum is not None and float(maximum) <= 1.0 and not row["frozen"]:
            break
    clear(project)
    project.save()
    Path(output).with_suffix(".json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    if len(sys.argv) != 4 or sys.argv[3] not in ("none", "W", "X"):
        raise SystemExit("usage: test_profile_term.py INPUT.gpx OUTPUT.gpx none|W|X")
    G2.SetPrintLevel("warn")
    main(sys.argv[1], sys.argv[2], sys.argv[3])
