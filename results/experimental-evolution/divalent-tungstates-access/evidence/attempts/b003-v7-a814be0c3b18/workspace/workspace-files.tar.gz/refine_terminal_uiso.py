#!/usr/bin/env python3
"""Test one physical isotropic displacement value per accepted phase."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

from refine_terminal import activate, clear, prepare, snapshot


def install(project: G2.G2Project, supported_only: bool) -> None:
    project.index_ids()
    project.data["Constraints"]["data"] = {"Hist": [], "HAP": [], "Phase": [], "Global": []}
    for phase_index, phase in enumerate(project.phases()):
        pid = int(phase.data["pId"])
        existing = float(phase.atoms()[0].data[phase.atoms()[0].cia + 1])
        value = 0.005 if existing <= 0.0031 or existing >= 0.0199 else existing
        if supported_only and phase_index == 1:
            value = 0.005
        variables = []
        for index, atom in enumerate(phase.atoms()):
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = value
            atom.data[atom.cia + 2:atom.cia + 8] = [0.0] * 6
            variable = f"{pid}::AUiso:{index}"
            variables.append(variable)
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)
        if len(variables) > 1 and not (supported_only and phase_index == 1):
            project.add_EquivConstr(variables, reloadIdx=False)


def main(source: str, output: str, supported_only: bool) -> None:
    project = G2.G2Project(gpxfile=source, newgpx=output)
    prepare(project)
    install(project, supported_only)
    rows = []
    for pass_index in range(1, 6):
        activate(project, False)
        for phase_index, phase in enumerate(project.phases()):
            if not supported_only or phase_index in (0, 2):
                for atom in phase.atoms():
                    atom.refinement_flags = "U"
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        row = snapshot(project, pass_index, False)
        row["uiso_A2"] = {
            phase.name: [float(atom.data[atom.cia + 1]) for atom in phase.atoms()]
            for phase in project.phases()
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
        maximum = row["max_shift_esd"]
        if row["converged"] and maximum is not None and float(maximum) <= 1.0 and not row["frozen"]:
            break
    clear(project)
    project.save()
    Path(output).with_suffix(".json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    if len(sys.argv) not in (3, 4):
        raise SystemExit("usage: refine_terminal_uiso.py INPUT.gpx OUTPUT.gpx [supported]")
    G2.SetPrintLevel("warn")
    main(sys.argv[1], sys.argv[2], len(sys.argv) == 4 and sys.argv[3] == "supported")
