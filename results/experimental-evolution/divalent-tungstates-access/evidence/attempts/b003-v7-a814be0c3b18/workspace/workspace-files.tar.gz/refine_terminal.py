#!/usr/bin/env python3
"""Develop a common three-phase checkpoint with selected physical terms."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


TEXTURES = {
    0: ([1, 1, 1], 1.0),
    1: ([0, 1, 0], 1.0),
    2: ([0, 0, 1], 1.0),
}


def clear(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True,
            "Pref.Ori.": True, "HStrain": True, "Extinction": True,
            "Babinet": ["BabA", "BabU"],
        })
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def prepare(project: G2.G2Project) -> None:
    """Restore physical ADPs and the tested broad-phase size checkpoint."""
    project.index_ids()
    for phase in project.phases():
        values = [float(atom.data[atom.cia + 1]) for atom in phase.atoms()]
        value = min(0.020, max(0.003, values[0]))
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = value
            atom.data[atom.cia + 2:atom.cia + 8] = [0.0] * 6
        hap = phase.data["Histograms"][project.histograms()[0].name]
        if phase.name.startswith("Mn3WO6"):
            hap["Size"][1][0] = 0.045
            hap["Size"][1][1] = 0.045
            hap["Size"][2] = [False, False, False]

    for index, (axis, _) in TEXTURES.items():
        phase = project.phases()[index]
        hap = phase.data["Histograms"][project.histograms()[0].name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][3] = list(axis)
        # Start from an existing screened value when the axis matches.
        if not 0.7 <= float(hap["Pref.Ori."][1]) <= 1.4:
            hap["Pref.Ori."][1] = 1.0
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")


def activate(project: G2.G2Project, roughness: bool) -> None:
    clear(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    hist.SampleParameters["Shift"][1] = True
    if roughness:
        if not 0.05 <= float(hist.SampleParameters["SurfRoughA"][0]) <= 0.60:
            hist.SampleParameters["SurfRoughA"][0] = 0.30
        if not 0.02 <= float(hist.SampleParameters["SurfRoughB"][0]) <= 0.50:
            hist.SampleParameters["SurfRoughB"][0] = 0.10
        hist.SampleParameters["SurfRoughA"][1] = True
        hist.SampleParameters["SurfRoughB"][1] = True
        project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    for index, phase in enumerate(project.phases()):
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][hist.name]
        if not phase.name.startswith("Mn3WO6"):
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        if float(hap["Mustrain"][1][0]) >= 300.0:
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        if index in TEXTURES:
            hap["Pref.Ori."][2] = True


def snapshot(project: G2.G2Project, pass_index: int, roughness: bool) -> dict:
    hist = project.histograms()[0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append({
            "name": phase.name,
            "scale": float(hap["Scale"][0]),
            "size_um": float(hap["Size"][1][0]),
            "microstrain_ppm": float(hap["Mustrain"][1][0]),
            "MD_axis": list(hap["Pref.Ori."][3]),
            "MD_ratio": float(hap["Pref.Ori."][1]),
            "cell": phase.get_cell(),
        })
    return {
        "pass": pass_index,
        "roughness_refined": roughness,
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "roughness_A": float(hist.SampleParameters["SurfRoughA"][0]),
        "roughness_B": float(hist.SampleParameters["SurfRoughB"][0]),
        "phases": phases,
    }


def main(source: str, output: str, roughness: bool) -> None:
    project = G2.G2Project(gpxfile=source, newgpx=output)
    prepare(project)
    rows = []
    for pass_index in range(1, 7):
        activate(project, roughness)
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        row = snapshot(project, pass_index, roughness)
        rows.append(row)
        print(json.dumps(row), flush=True)
        maximum = row["max_shift_esd"]
        if row["converged"] and maximum is not None and float(maximum) <= 1.0 and not row["frozen"]:
            break
    clear(project)
    project.save()
    Path(output).with_suffix(".json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    if len(sys.argv) not in (3, 4):
        raise SystemExit("usage: refine_terminal.py INPUT.gpx OUTPUT.gpx [roughness]")
    G2.SetPrintLevel("warn")
    main(sys.argv[1], sys.argv[2], len(sys.argv) == 4 and sys.argv[3] == "roughness")
