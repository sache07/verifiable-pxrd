#!/usr/bin/env python3
"""Refine bounded coordinates and one isotropic U value per accepted phase."""

from __future__ import annotations

import json
from pathlib import Path
import shutil
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True,
            "Pref.Ori.": True, "HStrain": True, "Extinction": True,
            "Babinet": ["BabA", "BabU"],
        })
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def activate_base(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    hist.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][hist.name]
        # Retain the very broad Mn3WO6 size at an interior tested value rather
        # than repeatedly refining it against the supplied lower bound.
        if phase.name.startswith("Mn3WO6") and float(hap["Size"][1][0]) <= 0.05:
            hap["Size"][1][0] = 0.045
            hap["Size"][1][1] = 0.045
        else:
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        if float(hap["Mustrain"][1][0]) >= 300.0:
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})


def normalize_adps_and_constraints(project: G2.G2Project) -> None:
    project.index_ids()
    project.data["Constraints"]["data"] = {"Hist": [], "HAP": [], "Phase": [], "Global": []}
    for phase in project.phases():
        pid = int(phase.data["pId"])
        variables = []
        for index, atom in enumerate(phase.atoms()):
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = 0.010
            atom.data[atom.cia + 2:atom.cia + 8] = [0.0] * 6
            variables.append(f"{pid}::AUiso:{index}")
            project.set_Controls("parmMin", 0.003, variable=variables[-1])
            project.set_Controls("parmMax", 0.020, variable=variables[-1])
            cell = phase.get_cell()
            for axis, value, length in zip(
                "xyz", atom.coordinates,
                (cell["length_a"], cell["length_b"], cell["length_c"]),
            ):
                half = 0.10 / float(length)
                var = f"{pid}::dA{axis}:{index}"
                project.set_Controls("parmMin", float(value) - half, variable=var)
                project.set_Controls("parmMax", float(value) + half, variable=var)
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)


def record(project: G2.G2Project, stage: str) -> dict:
    hist = project.histograms()[0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size_um": float(hap["Size"][1][0]),
            "microstrain_ppm": float(hap["Mustrain"][1][0]),
            "uiso_A2": [float(atom.data[atom.cia + 1]) for atom in phase.atoms()],
            "coordinates": [list(map(float, atom.coordinates)) for atom in phase.atoms()],
        }
    return {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "phases": phases,
    }


def run(project: G2.G2Project, stage: str, atom_mode: str | None = None,
        selected_phase: int | None = None, passes: int = 2) -> list[dict]:
    rows = []
    for pass_index in range(passes):
        clear_flags(project)
        activate_base(project)
        for phase_index, phase in enumerate(project.phases()):
            active_phase = selected_phase is None or selected_phase == phase_index
            for atom in phase.atoms():
                if not active_phase:
                    atom.refinement_flags = " "
                elif atom_mode == "uiso":
                    atom.refinement_flags = "U"
                elif atom_mode == "heavy":
                    atom.refinement_flags = "X" if atom.element != "O" else " "
                elif atom_mode == "oxygen":
                    atom.refinement_flags = "X" if atom.element == "O" else " "
                elif atom_mode == "all":
                    atom.refinement_flags = "X"
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        row = record(project, f"{stage}_{pass_index + 1}")
        rows.append(row)
        print(json.dumps(row), flush=True)
        folder = ROOT / "work" / "checkpoints"
        folder.mkdir(exist_ok=True)
        shutil.copy2(project.filename, folder / f"{Path(project.filename).stem}_{stage}_{pass_index + 1}.gpx")
        maximum = row["max_shift_esd"]
        if row["converged"] and maximum is not None and float(maximum) <= 1.0 and not row["frozen"]:
            break
    return rows


def main(source: str, output: str) -> None:
    project = G2.G2Project(gpxfile=source, newgpx=output)
    clear_flags(project)
    normalize_adps_and_constraints(project)
    project.save()
    rows: list[dict] = []
    rows += run(project, "phase_uiso", atom_mode="uiso", passes=3)
    for index, phase in enumerate(project.phases()):
        rows += run(project, f"phase_{index}_heavy", atom_mode="heavy", selected_phase=index, passes=2)
        rows += run(project, f"phase_{index}_oxygen", atom_mode="oxygen", selected_phase=index, passes=2)
    rows += run(project, "joint_coordinates", atom_mode="all", passes=3)
    clear_flags(project)
    project.save()
    Path(output).with_suffix(".structure.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: refine_structure.py INPUT.gpx OUTPUT.gpx")
    G2.SetPrintLevel("warn")
    main(sys.argv[1], sys.argv[2])
