#!/usr/bin/env python3
"""Test one bounded March-Dollase phase/axis branch from a common checkpoint."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def clear(project):
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True,
            "Pref.Ori.": True, "HStrain": True, "Extinction": True,
            "Babinet": ["BabA", "BabU"],
        })
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def clamp_uiso(project):
    for phase in project.phases():
        values = []
        for atom in phase.atoms():
            values.append(float(atom.data[atom.cia + 1]))
        value = min(0.020, max(0.003, values[0]))
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = value
            atom.data[atom.cia + 2:atom.cia + 8] = [0.0] * 6


def activate(project, selected, axis):
    clear(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    hist.SampleParameters["Shift"][1] = True
    for index, phase in enumerate(project.phases()):
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][hist.name]
        if not (phase.name.startswith("Mn3WO6") and float(hap["Size"][1][0]) <= 0.05):
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        if float(hap["Mustrain"][1][0]) >= 300.0:
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        if index == selected:
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0 if abs(float(hap["Pref.Ori."][1]) - 1.0) < 0.5 else float(hap["Pref.Ori."][1])
            hap["Pref.Ori."][3] = list(axis)
            hap["Pref.Ori."][2] = True
            pid = phase.data["pId"]
            project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")


def main(source, output, phase_index, axis):
    project = G2.G2Project(gpxfile=source, newgpx=output)
    clamp_uiso(project)
    rows = []
    for pass_index in range(2):
        activate(project, phase_index, axis)
        project.set_Controls("cycles", 8)
        project.save()
        project.refine(makeBack=False)
        project.save()
        hist = project.histograms()[0]
        phase = project.phases()[phase_index]
        hap = phase.data["Histograms"][hist.name]
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        rows.append({
            "pass": pass_index + 1,
            "phase_index": phase_index,
            "phase": phase.name,
            "axis": axis,
            "ratio": float(hap["Pref.Ori."][1]),
            "Rwp_percent": float(hist.get_wR()),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": list(project.get_Frozen()),
        })
        print(json.dumps(rows[-1]), flush=True)
        if rows[-1]["converged"] and rows[-1]["max_shift_esd"] is not None and float(rows[-1]["max_shift_esd"]) <= 1 and not rows[-1]["frozen"]:
            break
    clear(project)
    project.save()
    Path(output).with_suffix(".json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    if len(sys.argv) != 7:
        raise SystemExit("usage: test_texture.py INPUT.gpx OUTPUT.gpx PHASE H K L")
    G2.SetPrintLevel("error")
    main(sys.argv[1], sys.argv[2], int(sys.argv[3]), [int(x) for x in sys.argv[4:7]])
