#!/usr/bin/env python3
"""Develop a bounded two-phase Rietveld checkpoint for the Mn-W-O scan."""

from __future__ import annotations

import json
from pathlib import Path
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

from refine_candidates import ROOT, cod_path, prepare_inputs


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True,
            "Pref.Ori.": True, "HStrain": True, "Extinction": True,
            "Babinet": ["BabA", "BabU"],
        })
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def set_bounds(project: G2.G2Project) -> None:
    project.index_ids()
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    common = (
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
        (":0:SurfRoughA", 0.05, 0.6),
        (":0:SurfRoughB", 0.02, 0.5),
    )
    for name, low, high in common:
        project.set_Controls("parmMin", low, variable=name)
        project.set_Controls("parmMax", high, variable=name)
    for phase in project.phases():
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
        cell = phase.get_cell()
        avec = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for i, value in enumerate(avec):
            span = max(0.02 * abs(float(value)), 0.0005)
            project.set_Controls("parmMin", float(value) - span, variable=f"{pid}::A{i}")
            project.set_Controls("parmMax", float(value) + span, variable=f"{pid}::A{i}")


def activate(
    project: G2.G2Project,
    *, cells: bool = True, calibration: str | None = None,
    size: bool = False, strain: bool = False,
    instrument: tuple[str, ...] = (), polarization: bool = False,
) -> None:
    clear_flags(project)
    hist = project.histograms()[0]
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": cells})
        if size:
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        if strain:
            hap = phase.data["Histograms"][hist.name]
            # A phase that has reproducibly collapsed to zero strain represents
            # the generator's inactive branch; retain zero without a bound hit.
            if float(hap["Mustrain"][1][0]) > 1.0:
                phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    if calibration == "zero":
        hist.InstrumentParameters["Zero"][2] = True
    elif calibration == "shift":
        hist.SampleParameters["Shift"][1] = True
    elif calibration is not None:
        raise ValueError(f"unknown calibration mode: {calibration}")
    for name in instrument:
        hist.InstrumentParameters[name][2] = True
    if polarization:
        hist.InstrumentParameters["Polariz."][2] = True
    hist.Background[0][1] = True


def state(project: G2.G2Project, stage: str) -> dict:
    hist = project.histograms()[0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size_um": float(hap["Size"][1][0]),
            "microstrain_ppm": float(hap["Mustrain"][1][0]),
        }
    return {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": None if rvals.get("Max shft/sig") is None else float(rvals["Max shft/sig"]),
        "frozen": list(project.get_Frozen()),
        "instrument": {k: float(hist.InstrumentParameters[k][1]) for k in
                       ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")},
        "sample": {k: float(hist.SampleParameters[k][0]) for k in
                   ("Shift", "SurfRoughA", "SurfRoughB")},
        "phases": phases,
    }


def refine_stage(project: G2.G2Project, stage: str, passes: int = 3, **settings) -> list[dict]:
    records = []
    for index in range(passes):
        activate(project, **settings)
        project.set_Controls("cycles", 8)
        project.save()
        project.refine(makeBack=False)
        project.save()
        row = state(project, f"{stage}_{index + 1}")
        checkpoint = ROOT / "work" / "checkpoints"
        checkpoint.mkdir(exist_ok=True)
        shutil.copy2(project.filename, checkpoint / f"{Path(project.filename).stem}_{stage}_{index + 1}.gpx")
        records.append(row)
        print(json.dumps(row), flush=True)
        if row["converged"] and row["max_shift_esd"] is not None and row["max_shift_esd"] <= 1.0 and not row["frozen"]:
            break
    return records


def build(wo3_id: str, calibration: str) -> G2.G2Project:
    xye, inst = prepare_inputs()
    out = ROOT / "work" / f"develop_{wo3_id}_{calibration}.gpx"
    project = G2.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    project.add_phase(str(cod_path("1520200")), phasename="MnWO4_wolframite", histograms=[hist])
    project.add_phase(str(cod_path(wo3_id)), phasename=f"WO3_{wo3_id}", histograms=[hist])
    project.add_phase(str(cod_path("2002703")), phasename="Mn3WO6_rhombohedral", histograms=[hist])
    hist.set_refinements({
        "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
        "Background": {"type": "chebyschev-1", "no. coeffs": 20, "refine": False,
                       "coeffs": [3700.0] + [0.0] * 19},
    })
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [420.0 if calibration == "shift" else 0.0, False]
    hist.InstrumentParameters["Zero"][1] = -0.24 if calibration == "zero" else 0.0
    hist.InstrumentParameters["U"][1] = 10.0
    hist.InstrumentParameters["W"][1] = 10.0
    hist.InstrumentParameters["X"][1] = 1.5
    hist.InstrumentParameters["SH/L"][1] = 0.03
    hist.InstrumentParameters["Polariz."][1] = 0.75
    for phase, scale in zip(project.phases(), (105.0, 9.0, 4.5)):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Size"][1][1] = 0.30
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 2000.0
        hap["Mustrain"][1][1] = 2000.0
        hap["Mustrain"][2] = [False, False, False]
    set_bounds(project)
    clear_flags(project)
    project.save()
    return project


def main(wo3_id: str, calibration: str) -> None:
    project = build(wo3_id, calibration)
    log: list[dict] = []
    log += refine_stage(project, "scales_background", passes=4, cells=False)
    log += refine_stage(project, "cells", passes=4, cells=True)
    log += refine_stage(project, "calibration", passes=4, cells=True, calibration=calibration)
    log += refine_stage(project, "size", passes=4, cells=True, calibration=calibration, size=True)
    log += refine_stage(project, "strain", passes=4, cells=True, calibration=calibration, size=True, strain=True)
    log += refine_stage(project, "profile_WX", passes=4, cells=True, calibration=calibration, size=True, strain=True,
                        instrument=("W", "X"))
    clear_flags(project)
    project.save()
    (ROOT / "work" / f"develop_{wo3_id}_{calibration}.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[2] not in {"zero", "shift"}:
        raise SystemExit("usage: develop_model.py WO3_COD_ID {zero|shift}")
    G2.SetPrintLevel("warn")
    main(sys.argv[1], sys.argv[2])
