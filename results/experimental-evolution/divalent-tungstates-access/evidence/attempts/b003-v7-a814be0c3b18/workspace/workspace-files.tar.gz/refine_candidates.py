#!/usr/bin/env python3
"""Build equally developed two-phase GSAS-II trial projects.

Run with the GSAS-II Python interpreter. This is intentionally a conservative
first-stage comparison: background, scales, cells, the bounded angular zero,
and the common instrumental profile are developed identically for each WO3
reference. Phase-specific broadening and coordinates are left for the winning
model.
"""

from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_inputs() -> tuple[Path, Path]:
    work = ROOT / "work"
    work.mkdir(exist_ok=True)
    x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1).T
    xye = work / "pattern.xye"
    np.savetxt(xye, np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))), fmt="%.8f %.8f %.8f")
    inst = work / "lab.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for lab Cu Kalpha data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:-0.240;Polariz.:0.75;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:10.0;V:0.0;W:10.0;X:1.5;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def clear_all(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    # Do this directly: the scriptable clear_refinements method returns early
    # when Background is supplied as a boolean, which can leave later groups on.
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True,
            "Pref.Ori.": True, "HStrain": True, "Extinction": True,
            "Babinet": ["BabA", "BabU"],
        })


def bounds(project: G2.G2Project) -> None:
    project.index_ids()
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    for name, low, high in (
        (":0:Zero", -0.25, 0.25),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
    ):
        project.set_Controls("parmMin", low, variable=name)
        project.set_Controls("parmMax", high, variable=name)
    for phase in project.phases():
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        cell = phase.get_cell()
        avec = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for i, value in enumerate(avec):
            span = max(0.02 * abs(float(value)), 0.0005)
            project.set_Controls("parmMin", float(value) - span, variable=f"{pid}::A{i}")
            project.set_Controls("parmMax", float(value) + span, variable=f"{pid}::A{i}")


def run(project: G2.G2Project, label: str, setup) -> dict:
    clear_all(project)
    setup(project)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 8)
    project.save()
    project.refine(makeBack=False)
    project.save()
    hist = project.histograms()[0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "stage": label,
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
    }
    print(json.dumps(record), flush=True)
    return record


def make_project(wo3_id: str) -> tuple[G2.G2Project, list[dict]]:
    xye, inst = prepare_inputs()
    out = ROOT / "work" / f"trial_{wo3_id}.gpx"
    project = G2.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    project.add_phase(str(cod_path("1520200")), phasename="MnWO4_wolframite", histograms=[hist])
    project.add_phase(str(cod_path(wo3_id)), phasename=f"WO3_{wo3_id}", histograms=[hist])

    hist.set_refinements({
        "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
        "Background": {"type": "chebyschev-1", "no. coeffs": 16, "refine": False,
                       "coeffs": [3800.0] + [0.0] * 15},
    })
    # Put the minor-phase trial on a smaller but non-negligible initial scale.
    project.phases()[0].data["Histograms"][hist.name]["Scale"][0] = 1.0
    project.phases()[1].data["Histograms"][hist.name]["Scale"][0] = 0.25
    bounds(project)
    project.save()

    records: list[dict] = []
    records.append(run(project, "background_scales", lambda p: (
        p.histograms()[0].set_refinements({"Background": True}),
        [ph.set_HAP_refinements({"Scale": True}) for ph in p.phases()],
    )))
    records.append(run(project, "cells", lambda p: (
        p.histograms()[0].set_refinements({"Background": True}),
        [ph.set_HAP_refinements({"Scale": True}) for ph in p.phases()],
        [ph.set_refinements({"Cell": True}) for ph in p.phases()],
    )))
    records.append(run(project, "zero", lambda p: (
        p.histograms()[0].set_refinements({"Instrument Parameters": ["Zero"], "Background": True}),
        [ph.set_HAP_refinements({"Scale": True}) for ph in p.phases()],
        [ph.set_refinements({"Cell": True}) for ph in p.phases()],
    )))
    records.append(run(project, "profile", lambda p: (
        p.histograms()[0].set_refinements({
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L"],
            "Background": True,
        }),
        [ph.set_HAP_refinements({"Scale": True}) for ph in p.phases()],
        [ph.set_refinements({"Cell": True}) for ph in p.phases()],
    )))
    clear_all(project)
    project.save()
    (ROOT / "work" / f"trial_{wo3_id}.json").write_text(json.dumps(records, indent=2) + "\n")
    return project, records


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: refine_candidates.py WO3_COD_ID")
    G2.SetPrintLevel("warn")
    make_project(sys.argv[1])
