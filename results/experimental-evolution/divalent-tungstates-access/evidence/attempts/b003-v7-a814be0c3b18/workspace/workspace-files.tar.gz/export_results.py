#!/usr/bin/env python3
"""Export the accepted read-only replay into the requested submission files."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
import shutil

import numpy as np


ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / ".tmp" / "replay_profile"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    report = json.loads((REPLAY / "replay.json").read_text())
    if report.get("status") != "replayed" or not report.get("project_unchanged"):
        raise RuntimeError("accepted project did not pass read-only replay")
    project = ROOT / "final.gpx"
    digest = sha256(project)
    if digest != report.get("project_sha256"):
        raise RuntimeError("final.gpx differs from the replayed project")

    labels = {
        "MnWO4_wolframite": ("MnWO4", "P 2/c (No. 13)", "phase_MnWO4.cif"),
        "WO3_2311041": ("WO3", "P 21/c (No. 14)", "phase_WO3.cif"),
        "Mn3WO6_rhombohedral": ("Mn3WO6", "R -3 (No. 148)", "phase_Mn3WO6.cif"),
    }
    phases = []
    for row in report["phases"]:
        formula, space_group, destination = labels[row["name"]]
        shutil.copy2(REPLAY / row["cif"], ROOT / destination)
        phases.append({
            "name": row["name"],
            "formula": formula,
            "space_group": space_group,
            "cif_path": destination,
            "weight_fraction": float(row["weight_fraction"]),
        })

    with np.load(REPLAY / "prediction.npz", allow_pickle=False) as data:
        x = data["x"].copy()
        observed = data["observed"].copy()
        calculated = data["predicted"].copy()
    difference = observed - calculated
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta", "observed", "calculated", "difference"])
        for angle, obs, calc, diff in zip(x, observed, calculated, difference):
            writer.writerow([
                f"{angle:.8f}", f"{obs:.8f}", f"{calc:.10f}", f"{diff:.10f}"
            ])

    weights = 1.0 / np.maximum(observed, 1.0)
    residual_sum = float(np.sum(weights * difference * difference))
    denominator = float(np.sum(weights * observed * observed))
    rwp = float(100.0 * np.sqrt(residual_sum / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    rmse = float(np.sqrt(np.mean(difference * difference)))
    polished = json.loads((ROOT / "polished.staged_polish.json").read_text())
    result = {
        "phases": phases,
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "weight_fraction_sum": float(sum(row["weight_fraction"] for row in phases)),
        "fit_statistics": {
            "Rwp_percent": rwp,
            "saved_GSAS_Rwp_percent": float(polished["selected"]["Rwp_percent"]),
            "Rp_percent": rp,
            "weighted_residual_sum": residual_sum,
            "unweighted_RMSE_counts": rmse,
            "n_points": int(len(x)),
            "weighting": "w_i = 1/max(I_obs, 1); pointwise uncertainties were not supplied",
            "evaluation_grid": "entire original observed grid",
        },
        "refinement_histogram": report["histogram"],
        "gsas_project": "final.gpx",
        "project_sha256": digest,
        "forward_replay": {
            "status": report["status"],
            "project_unchanged": bool(report["project_unchanged"]),
            "profile_review_flags": report.get("profile_review_flags", []),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
