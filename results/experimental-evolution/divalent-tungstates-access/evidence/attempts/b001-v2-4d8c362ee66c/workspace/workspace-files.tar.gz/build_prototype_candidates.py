#!/usr/bin/env python3
"""Build symmetry-preserving CuWO4 structures from ABO4 analogues."""

from __future__ import annotations

import json
import warnings
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
OUT = ROOT / ".tmp" / "prototype_transfer"
CANDIDATES = OUT / "candidates"
REFERENCE = ROOT / ".tmp" / "replay_check" / "phase_0.cif"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


SOURCES = [
    ("wolframite_P2c", "4000807", {}, "P2/c"),
    ("scheelite_I41a", "7219229", {"Ca": "Cu"}, "I4_1/a"),
    ("raspite_P21c", "9007617", {"Pb": "Cu"}, "P2_1/c"),
    ("high_pressure_C2c", "1546035", {"Ca": "Cu"}, "C2/c"),
    ("molybdate_C2m", "2300504", {"Mg": "Cu", "Mo": "W"}, "C2/m"),
    ("snwo4_type_Pnna", "9007595", {"Sn": "Cu"}, "Pnna"),
]


def read(path: Path) -> Structure:
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        result = Structure.from_file(str(path), primitive=False)
    result.remove_oxidation_states()
    return result


def clean_labels(structure: Structure) -> Structure:
    props = {
        key: value
        for key, value in structure.site_properties.items()
        if key.lower() not in {"label", "_atom_site_label"}
    }
    return Structure(
        structure.lattice,
        [site.species for site in structure],
        structure.frac_coords,
        site_properties=props,
    )


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    CANDIDATES.mkdir(parents=True, exist_ok=True)
    reference = read(REFERENCE)
    _, ref_factor = reference.composition.get_reduced_composition_and_factor()
    target_volume_per_formula = reference.volume / float(ref_factor)
    records = []
    for label, cod_id, substitutions, expected in SOURCES:
        structure = read(cod(cod_id))
        if substitutions:
            structure.replace_species(substitutions)
        structure = clean_labels(structure)
        reduced, factor = structure.composition.get_reduced_composition_and_factor()
        if reduced.reduced_formula != "CuWO4":
            raise ValueError(f"{label} did not become CuWO4: {structure.composition}")
        structure.scale_lattice(target_volume_per_formula * float(factor))
        target = CANDIDATES / f"{label}.cif"
        CifWriter(structure, symprec=1e-3, significant_figures=9).write_file(target)
        check = read(target)
        sg_symbol, sg_number = check.get_space_group_info(symprec=1e-3)
        _, check_factor = check.composition.get_reduced_composition_and_factor()
        records.append(
            {
                "label": label,
                "source_cod_id": cod_id,
                "source_path": str(cod(cod_id)),
                "substitutions": substitutions,
                "expected_symmetry": expected,
                "written_symmetry": sg_symbol,
                "written_space_group_number": int(sg_number),
                "formula": check.composition.reduced_formula,
                "sites": len(check),
                "volume_per_formula_A3": float(check.volume / float(check_factor)),
                "path": str(target),
            }
        )
        print(label, cod_id, substitutions, sg_symbol, sg_number, len(check))
    (OUT / "candidate_manifest.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
