#!/usr/bin/env python3
"""Converge the regularized four-phase model under lab-physical bounds."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "wo3_regularization" / "factor_0p10" / "final.gpx"
OUT = ROOT / ".tmp" / "physical_polish"


def fractions(project):
    h = project.histograms()[0]
    amounts = [
        p.data["General"]["Mass"] * p.data["Histograms"][h.name]["Scale"][0]
        for p in project.phases()
    ]
    total = sum(amounts)
    return {p.name: float(value / total) for p, value in zip(project.phases(), amounts)}


def prepare(label, physical_bounds):
    folder = OUT / label
    folder.mkdir(parents=True, exist_ok=True)
    branch = folder / "final.gpx"
    shutil.copy2(SOURCE, branch)
    project = G2.G2Project(gpxfile=str(branch))
    h = project.histograms()[0]
    if physical_bounds:
        for phase in project.phases():
            hap = phase.data["Histograms"][h.name]
            # The lab prior bounds coherent size at 0.04--1.5 micrometres.
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = min(1.45, max(0.04, float(hap["Size"][1][0])))
            hap["Size"][2] = [False] * len(hap["Size"][2])
            hap["Size"][2][0] = True
            project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:{h.id}:Size;i")
            project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:{h.id}:Size;i")
            # Generator-supported isotropic displacement range is <=0.02 A2.
            for index, atom in enumerate(phase.atoms()):
                atom.uiso = min(0.0195, max(0.0001, float(atom.uiso)))
                project.set_Controls("parmMin", 0.0001, variable=f"{phase.id}::AUiso:{index}")
                project.set_Controls("parmMax", 0.02, variable=f"{phase.id}::AUiso:{index}")
        # Revisit only profile terms present in the generating model.
        for key in ["U", "W", "X", "SH/L"]:
            h.data["Instrument Parameters"][0][key][2] = True
        h.data["Instrument Parameters"][0]["Zero"][2] = True
        h.data["Instrument Parameters"][0]["Polariz."][2] = True
    project.set_Frozen()
    project.save()
    return project, branch, folder


def run(label, physical_bounds):
    project, branch, folder = prepare(label, physical_bounds)
    project.set_Controls("cycles", 40)
    project.refine(printFile=str(folder / "polish.lst"), makeBack=False)
    project.save()
    h = project.histograms()[0]
    row = {
        "label": label,
        "project": str(branch.relative_to(ROOT)),
        "rwp_percent_cached": float(h.get_wR()),
        "fractions": fractions(project),
        "instrument": {k: v for k, v in h.data["Instrument Parameters"][0].items()},
        "phases": [
            {
                "name": p.name,
                "size": p.data["Histograms"][h.name]["Size"],
                "uiso": [float(a.uiso) for a in p.atoms()],
            }
            for p in project.phases()
        ],
        "frozen": [str(value) for value in project.get_Frozen()],
    }
    print(json.dumps(row, sort_keys=True))
    return row


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    rows = [run("regularized_uncapped", False), run("regularized_physical", True)]
    (OUT / "results.json").write_text(json.dumps(rows, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
