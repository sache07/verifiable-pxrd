#!/usr/bin/env python3
"""Controlled anisotropic-strain and whole-pattern nuisance tests."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "atom_refinement" / "base_atoms.gpx"
OUT = ROOT / ".tmp" / "nuisance_trials"
AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0)]


def freeze(project):
    project.set_Frozen()
    project.get_Constraints("Phase").clear()
    h = project.histograms()[0]
    h.data["Background"][0][1] = False
    for entry in h.data["Instrument Parameters"][0].values():
        if isinstance(entry, list) and len(entry) > 2:
            entry[2] = False
    for entry in h.data["Sample Parameters"].values():
        if isinstance(entry, list) and len(entry) > 1 and isinstance(entry[1], bool):
            entry[1] = False
    for p in project.phases():
        p.data["General"]["Cell"][0] = False
        for atom in p.atoms():
            atom.refinement_flags = " "
        hap = p.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])


def fractions(project):
    h = project.histograms()[0]
    a = [p.data["General"]["Mass"] * p.data["Histograms"][h.name]["Scale"][0] for p in project.phases()]
    total = sum(a)
    return {p.name: float(v / total) for p, v in zip(project.phases(), a)}


def strain_trial(phase_name, axis):
    label = phase_name.replace("_", "-") + "_" + "".join(map(str, axis))
    dest = OUT / ("strain_" + label)
    dest.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(dest / "trial.gpx"))
    freeze(project)
    h = project.histograms()[0]
    p = project.phase(phase_name)
    hap = p.data["Histograms"][h.name]
    initial = max(100.0, float(hap["Mustrain"][1][0]))
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = initial
    hap["Mustrain"][1][1] = initial
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    hap["Mustrain"][3] = list(axis)
    hap["Scale"][1] = True
    for variable in [f"{p.id}:{h.id}:Mustrain;i", f"{p.id}:{h.id}:Mustrain;a"]:
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 30000.0, variable=variable)
    project.set_Controls("cycles", 10)
    project.refine(printFile=str(dest / "trial.lst"), makeBack=False)
    f = fractions(project)
    result = {
        "kind": "uniaxial_strain",
        "phase": phase_name,
        "axis": list(axis),
        "rwp_percent": float(project.histograms()[0].get_wR()),
        "equatorial_ppm": float(hap["Mustrain"][1][0]),
        "axial_ppm": float(hap["Mustrain"][1][1]),
        "weight_fraction": f[phase_name],
        "frozen": project.get_Frozen(),
        "project": str((dest / "trial.gpx").relative_to(ROOT)),
    }
    print(json.dumps(result, sort_keys=True))
    return result


def global_trial(kind):
    dest = OUT / kind
    dest.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(dest / "trial.gpx"))
    freeze(project)
    h = project.histograms()[0]
    for p in project.phases():
        p.data["Histograms"][h.name]["Scale"][1] = True
    if kind in {"surface_roughness", "roughness_polarization"}:
        h.data["Sample Parameters"]["SurfRoughA"] = [0.15, True]
        h.data["Sample Parameters"]["SurfRoughB"] = [0.10, True]
        project.set_Controls("parmMin", 0.0, variable=f":{h.id}:SurfRoughA")
        project.set_Controls("parmMax", 0.95, variable=f":{h.id}:SurfRoughA")
        project.set_Controls("parmMin", 0.001, variable=f":{h.id}:SurfRoughB")
        project.set_Controls("parmMax", 2.0, variable=f":{h.id}:SurfRoughB")
    if kind in {"polarization", "roughness_polarization"}:
        inst = h.data["Instrument Parameters"][0]
        inst["Polariz."][2] = True
        project.set_Controls("parmMin", 0.0, variable=f":{h.id}:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=f":{h.id}:Polariz.")
    project.set_Controls("cycles", 12)
    project.refine(printFile=str(dest / "trial.lst"), makeBack=False)
    f = fractions(project)
    result = {
        "kind": kind,
        "rwp_percent": float(project.histograms()[0].get_wR()),
        "surf_rough_a": float(h.data["Sample Parameters"]["SurfRoughA"][0]),
        "surf_rough_b": float(h.data["Sample Parameters"]["SurfRoughB"][0]),
        "polarization": float(h.data["Instrument Parameters"][0]["Polariz."][1]),
        "fractions": f,
        "frozen": project.get_Frozen(),
        "project": str((dest / "trial.gpx").relative_to(ROOT)),
    }
    print(json.dumps(result, sort_keys=True))
    return result


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    seed = G2.G2Project(gpxfile=str(BASE))
    names = [p.name for p in seed.phases()]
    results = [strain_trial(name, axis) for name in names for axis in AXES]
    results.extend(global_trial(kind) for kind in ["surface_roughness", "polarization", "roughness_polarization"])
    (OUT / "results.json").write_text(json.dumps(results, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
