#!/usr/bin/env python3
"""Common-state CuWO4 prototype-transfer additions and replacements.

The candidate structures span the distinct ABO4 framework symmetries found in
the frozen COD reference library.  One- and two-element analogues are changed
to CuWO4 and volume-scaled to the refined CuWO4 volume per formula before any
GSAS-II work.  Every candidate is tested against the same saved four-phase
state, with all incumbent and instrumental/nuisance parameters fixed.
"""

from __future__ import annotations

import json
import warnings
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "anisotropic_refinement" / "best_anisotropic.gpx"
OUT = ROOT / ".tmp" / "prototype_transfer"
CANDIDATES = OUT / "candidates"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


# label, COD id, substitutions, expected retained framework symmetry
SOURCES = [
    ("wolframite_P2c", "4000807", {}, "P2/c"),
    ("scheelite_I41a", "7219229", {"Ca": "Cu"}, "I4_1/a"),
    ("raspite_P21c", "9007617", {"Pb": "Cu"}, "P2_1/c"),
    ("high_pressure_C2c", "1546035", {"Ca": "Cu"}, "C2/c"),
    ("molybdate_C2m", "2300504", {"Mg": "Cu", "Mo": "W"}, "C2/m"),
    ("snwo4_type_Pnna", "9007595", {"Sn": "Cu"}, "Pnna"),
]


def build_candidates() -> list[dict]:
    from pymatgen.core import Structure
    from pymatgen.io.cif import CifWriter

    CANDIDATES.mkdir(parents=True, exist_ok=True)
    base = G2.G2Project(gpxfile=str(BASE))
    incumbent = base.phase("CuWO4_triclinic")
    cell = incumbent.data["General"]["Cell"]
    target_volume = float(cell[7])
    target_z = float(incumbent.data["General"]["Z"])
    target_volume_per_formula = target_volume / target_z
    records = []
    for label, cod_id, substitutions, expected in SOURCES:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            structure = Structure.from_file(str(cod(cod_id)), primitive=False)
        structure.remove_oxidation_states()
        if substitutions:
            structure.replace_species(substitutions)
        # Remove source atom labels, which can become duplicated after symmetry
        # expansion and are not structural data.
        props = {
            key: value
            for key, value in structure.site_properties.items()
            if key.lower() not in {"label", "_atom_site_label"}
        }
        structure = Structure(
            structure.lattice,
            [site.species for site in structure],
            structure.frac_coords,
            site_properties=props,
        )
        reduced, factor = structure.composition.get_reduced_composition_and_factor()
        if reduced.reduced_formula != "CuWO4":
            raise ValueError(f"{label} did not become CuWO4: {structure.composition}")
        wanted_volume = target_volume_per_formula * float(factor)
        structure.scale_lattice(wanted_volume)
        target = CANDIDATES / f"{label}.cif"
        CifWriter(structure, symprec=1e-3, significant_figures=9).write_file(target)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            check = Structure.from_file(str(target), primitive=False)
        sg_symbol, sg_number = check.get_space_group_info(symprec=1e-3)
        records.append(
            {
                "label": label,
                "source_cod_id": cod_id,
                "source_path": str(cod(cod_id)),
                "substitutions": substitutions,
                "expected_symmetry": expected,
                "written_symmetry": sg_symbol,
                "written_space_group_number": int(sg_number),
                "formula": check.composition.reduced_formula,
                "sites": len(check),
                "volume_per_formula_A3": float(check.volume / factor),
                "path": str(target),
            }
        )
    (OUT / "candidate_manifest.json").write_text(json.dumps(records, indent=2) + "\n")
    return records


def freeze(project: G2.G2Project) -> None:
    project.set_Frozen()
    project.get_Constraints("Phase").clear()
    h = project.histograms()[0]
    h.data["Background"][0][1] = False
    for entry in h.data["Instrument Parameters"][0].values():
        if isinstance(entry, list) and len(entry) > 2:
            entry[2] = False
    for entry in h.data["Sample Parameters"].values():
        if isinstance(entry, list) and len(entry) > 1 and isinstance(entry[1], bool):
            entry[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])


def fraction(project: G2.G2Project, phase_name: str) -> float:
    h = project.histograms()[0]
    amounts = {
        p.name: float(p.data["General"]["Mass"] * p.data["Histograms"][h.name]["Scale"][0])
        for p in project.phases()
    }
    total = sum(max(0.0, value) for value in amounts.values())
    return max(0.0, amounts[phase_name]) / total if total else 0.0


def configure_candidate(project: G2.G2Project, phase, initial_amount: float) -> None:
    h = project.histograms()[0]
    hap = phase.data["Histograms"][h.name]
    hap["Scale"] = [initial_amount / phase.data["General"]["Mass"], True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.30
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1600.0
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False
    project.set_Controls("parmMin", 1e-12, variable=f"{phase.id}:{h.id}:Scale")


def refine_stage(project: G2.G2Project, folder: Path, name: str, cycles: int = 10) -> dict:
    project.save(str(folder / f"{name}.gpx"))
    project.set_Controls("cycles", cycles)
    project.refine(printFile=str(folder / f"{name}.lst"), makeBack=False)
    return {
        "stage": name,
        "rwp_percent_cached": float(project.histograms()[0].get_wR()),
    }


def run_one(record: dict, mode: str) -> dict:
    label = record["label"]
    folder = OUT / mode / label
    folder.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(folder / "00_start.gpx"))
    freeze(project)
    h = project.histograms()[0]
    incumbent = project.phase("CuWO4_triclinic")
    incumbent_amount = float(
        incumbent.data["General"]["Mass"] * incumbent.data["Histograms"][h.name]["Scale"][0]
    )
    total_amount = sum(
        float(p.data["General"]["Mass"] * p.data["Histograms"][h.name]["Scale"][0])
        for p in project.phases()
    )
    if mode == "replacement":
        incumbent.data["Histograms"][h.name]["Scale"] = [0.0, False]
        initial_amount = incumbent_amount
    elif mode == "addition":
        initial_amount = 0.005 * total_amount / 0.995
    else:
        raise ValueError(mode)
    candidate_name = f"transfer_{label}"
    phase = project.add_phase(
        record["path"], phasename=candidate_name, histograms=[h], fmthint="CIF"
    )
    configure_candidate(project, phase, initial_amount)
    stages = []
    stages.append(refine_stage(project, folder, "01_scale", cycles=12))
    scale_fraction = fraction(project, phase.name)
    # A stable candidate receives cell freedom. Candidates above 0.5 wt% also
    # get their own isotropic width terms so a topology is not rejected merely
    # because its source crystallite profile differs from the product.
    if scale_fraction > 0.001:
        phase.data["General"]["Cell"][0] = True
        stages.append(refine_stage(project, folder, "02_cell", cycles=14))
    if fraction(project, phase.name) > 0.005:
        hap = phase.data["Histograms"][h.name]
        hap["Size"][2][0] = True
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 0.01, variable=f"{phase.id}:{h.id}:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{phase.id}:{h.id}:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{h.id}:Mustrain;i")
        project.set_Controls("parmMax", 30000.0, variable=f"{phase.id}:{h.id}:Mustrain;i")
        stages.append(refine_stage(project, folder, "03_profile", cycles=14))
    final = {
        "label": label,
        "mode": mode,
        "candidate_phase": phase.name,
        "candidate_path": record["path"],
        "stages": stages,
        "final_project": str(Path(project.filename).relative_to(ROOT)),
        "rwp_percent_cached": float(h.get_wR()),
        "candidate_weight_fraction": float(fraction(project, phase.name)),
        "candidate_scale": float(phase.data["Histograms"][h.name]["Scale"][0]),
        "candidate_cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
    }
    print(json.dumps(final, sort_keys=True))
    return final


def main() -> None:
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    manifest = OUT / "candidate_manifest.json"
    if not manifest.exists():
        raise FileNotFoundError(
            "Run build_prototype_candidates.py with the materials-analysis environment first"
        )
    candidates = json.loads(manifest.read_text())
    results = []
    for record in candidates:
        for mode in ["addition", "replacement"]:
            try:
                results.append(run_one(record, mode))
            except Exception as exc:
                row = {
                    "label": record["label"],
                    "mode": mode,
                    "status": "failed",
                    "error": f"{type(exc).__name__}: {exc}",
                }
                print(json.dumps(row, sort_keys=True))
                results.append(row)
    (OUT / "results.json").write_text(json.dumps(results, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
