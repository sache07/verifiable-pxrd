#!/usr/bin/env python3
"""Rewrite selected COD candidates without oxidation-state atom labels.

The coordinates, occupancies and cells are retained. P1 output is intentional:
it avoids importer-specific setting/type-symbol failures while preserving the
occupied structure exactly for diagnostic common-state phase tests.
"""

from pathlib import Path
import warnings

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = ROOT / ".tmp" / "candidate_cifs"
IDS = ["2002403", "1528166", "1538317", "2107065", "2101049", "2101050"]


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    for cod_id in IDS:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            structure = Structure.from_file(cod_path(cod_id), primitive=False)
        structure.remove_oxidation_states()
        # Expanded source labels repeat after symmetry generation; rebuild the
        # structure without label-like properties so CifWriter assigns unique
        # labels acceptable to GSAS-II.
        properties = {
            key: value
            for key, value in structure.site_properties.items()
            if key.lower() not in {"label", "_atom_site_label"}
        }
        structure = Structure(
            structure.lattice,
            [site.species for site in structure],
            structure.frac_coords,
            site_properties=properties,
        )
        target = OUT / f"{cod_id}_neutral_p1.cif"
        CifWriter(structure, symprec=None, significant_figures=9).write_file(target)
        print(target, structure.composition, len(structure))


if __name__ == "__main__":
    main()
