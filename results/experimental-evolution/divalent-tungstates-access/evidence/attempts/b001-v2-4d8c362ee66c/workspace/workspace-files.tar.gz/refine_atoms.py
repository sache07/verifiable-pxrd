#!/usr/bin/env python3
"""Refine phase-common Uiso values and symmetry-allowed atomic coordinates."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "refinement4" / "base_four_phase.gpx"
OUT = ROOT / ".tmp" / "atom_refinement"


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histograms()[0]
    values = [
        float(p.data["General"]["Mass"]) * float(p.data["Histograms"][hist.name]["Scale"][0])
        for p in project.phases()
    ]
    total = sum(values)
    return {p.name: v / total for p, v in zip(project.phases(), values)}


def state(project: G2.G2Project, stage: str) -> dict:
    hist = project.histograms()[0]
    arrays = hist.data["data"][1]
    obs, calc = np.asarray(arrays[1], float), np.asarray(arrays[3], float)
    fracs = fractions(project)
    phases = []
    for phase in project.phases():
        phases.append(
            {
                "name": phase.name,
                "weight_fraction": fracs[phase.name],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": list(map(float, atom.coordinates)),
                        "uiso": float(atom.uiso),
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    rec = {
        "stage": stage,
        "rwp_percent": float(hist.get_wR()),
        "weighted_rms_noise_units": float(np.sqrt(np.mean((obs - calc) ** 2 / np.maximum(obs, 1.0)))),
        "phases": phases,
        "vary_list": [str(v) for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
        "frozen": project.get_Frozen(),
    }
    print(
        f"{stage}: Rwp={rec['rwp_percent']:.5f}% wrms={rec['weighted_rms_noise_units']:.4f}; "
        + ", ".join(f"{p['name']}={p['weight_fraction']:.4f}" for p in phases)
    )
    return rec


def run_stage(project: G2.G2Project, stage: str, records: list[dict], cycles: int = 12) -> None:
    project.save(str(OUT / f"{stage}.gpx"))
    project.set_Controls("cycles", cycles)
    project.refine(printFile=str(OUT / f"{stage}.lst"), makeBack=False)
    records.append(state(project, stage))
    (OUT / "stages.json").write_text(json.dumps(records, indent=2, allow_nan=False) + "\n")


def set_only_phase_x(project: G2.G2Project, phase_name: str, elements: set[str]) -> None:
    phase = project.phase(phase_name)
    for atom in phase.atoms():
        atom.refinement_flags = "XU" if atom.element in elements else "U"


def main() -> None:
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(OUT / "00_start.gpx"))
    project.set_Frozen()
    hist = project.histograms()[0]

    # Keep the stable cell/scale/background/shift state active, but hold all
    # line-profile and instrumental parameters while intensities are improved.
    inst = hist.data["Instrument Parameters"][0]
    for entry in inst.values():
        if isinstance(entry, list) and len(entry) > 2:
            entry[2] = False
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False

    # The generation model applies one isotropic U value to all atoms in each
    # phase. Express that physically meaningful grouping as GSAS constraints.
    for phase in project.phases():
        pid = phase.id
        variables = []
        for index, atom in enumerate(phase.atoms()):
            atom.uiso = 0.008
            atom.refinement_flags = "U"
            variable = f"{pid}::AUiso:{index}"
            variables.append(variable)
            project.set_Controls("parmMin", 0.0001, variable=variable)
            project.set_Controls("parmMax", 0.05, variable=variable)
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)

    records = [state(project, "00_start")]
    run_stage(project, "01_common_uiso", records, 12)

    # Oxygen positions dominate the reference mismatch while heavy atoms carry
    # most scattering. Add coordinate freedom one phase at a time so each gain
    # can be audited in the shared four-phase state.
    set_only_phase_x(project, "CuWO4_triclinic", {"O"})
    run_stage(project, "02_cuwo4_oxygen", records, 14)

    set_only_phase_x(project, "WO3_monoclinic", {"O"})
    run_stage(project, "03_wo3_oxygen", records, 14)

    set_only_phase_x(project, "Cu3WO6_cubic", {"O"})
    run_stage(project, "04_cu3wo6_oxygen", records, 14)

    set_only_phase_x(project, "CuO_tenorite", {"O"})
    run_stage(project, "05_cuo_oxygen", records, 12)

    # Refine cation positions where symmetry permits. Keep W1 in triclinic
    # CuWO4 fixed as an origin anchor for P-1.
    cuwo4 = project.phase("CuWO4_triclinic")
    for atom in cuwo4.atoms():
        if atom.element == "Cu":
            atom.refinement_flags = "XU"
    run_stage(project, "06_cuwo4_cation", records, 12)

    set_only_phase_x(project, "WO3_monoclinic", {"O", "W"})
    set_only_phase_x(project, "Cu3WO6_cubic", {"O", "Cu", "W"})
    run_stage(project, "07_remaining_cations", records, 14)

    project.save(str(OUT / "base_atoms.gpx"))


if __name__ == "__main__":
    main()
