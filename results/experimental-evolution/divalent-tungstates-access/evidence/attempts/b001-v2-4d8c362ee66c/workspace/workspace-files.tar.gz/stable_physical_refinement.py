#!/usr/bin/env python3
"""Fresh staged refinement using physical estimates from a failed coupled trial.

The failed trial itself is never selected. Its values are used only as starts;
disjoint blocks are refined from the intact regularized source so singular
size/profile/Uiso correlations are avoided.
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "wo3_regularization" / "factor_0p10" / "final.gpx"
OUT = ROOT / ".tmp" / "stable_physical"
PROJECT = OUT / "working.gpx"

INSTRUMENT_START = {
    "U": 8.096164076466504,
    "W": 14.136288917361073,
    "X": 3.8629768241208677,
    "SH/L": 0.014933652503899933,
    "Zero": -0.0751488219332485,
    "Polariz.": 0.7360223752844883,
}
SIZE_START = {
    "CuWO4_triclinic": 0.16060897809516886,
    "WO3_monoclinic": 1.45,
    "Cu3WO6_cubic": 1.0298388832601586,
    "CuO_tenorite": 1.45,
}
UISO_START = {
    "CuWO4_triclinic": 0.01647139217504667,
    "WO3_monoclinic": 0.0195,
    "Cu3WO6_cubic": 0.014746887503438305,
    "CuO_tenorite": 0.01944276800792776,
}


def freeze_all(project):
    project.set_Frozen()
    h = project.histograms()[0]
    h.data["Background"][0][1] = False
    for entry in h.data["Instrument Parameters"][0].values():
        if isinstance(entry, list) and len(entry) > 2:
            entry[2] = False
    for entry in h.data["Sample Parameters"].values():
        if isinstance(entry, list) and len(entry) > 1 and isinstance(entry[1], bool):
            entry[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])


def enable_structural_profile(project):
    h = project.histograms()[0]
    h.data["Background"][0][1] = True
    h.data["Sample Parameters"]["Shift"][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = True
        if phase.name != "CuO_tenorite":
            hap["Mustrain"][2][0] = True
            hap["Mustrain"][2][1] = True


def enable_instrument(project, keys):
    inst = project.histograms()[0].data["Instrument Parameters"][0]
    for key in keys:
        inst[key][2] = True


def fractions(project):
    h = project.histograms()[0]
    amounts = [
        p.data["General"]["Mass"] * p.data["Histograms"][h.name]["Scale"][0]
        for p in project.phases()
    ]
    total = sum(amounts)
    return {p.name: float(value / total) for p, value in zip(project.phases(), amounts)}


def snapshot(project, stage):
    h = project.histograms()[0]
    path = OUT / f"{stage}.gpx"
    project.save(str(path))
    row = {
        "stage": stage,
        "project": str(path.relative_to(ROOT)),
        "rwp_percent_cached": float(h.get_wR()),
        "fractions": fractions(project),
        "frozen": [str(value) for value in project.get_Frozen()],
        "instrument": {
            key: float(h.data["Instrument Parameters"][0][key][1])
            for key in INSTRUMENT_START
        },
    }
    print(json.dumps(row, sort_keys=True))
    return row


def refine(project, stage, records, cycles=20):
    project.set_Controls("cycles", cycles)
    project.refine(printFile=str(OUT / f"{stage}.lst"), makeBack=False)
    records.append(snapshot(project, stage))


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    shutil.copy2(SOURCE, PROJECT)
    project = G2.G2Project(gpxfile=str(PROJECT))
    h = project.histograms()[0]
    inst = h.data["Instrument Parameters"][0]
    for key, value in INSTRUMENT_START.items():
        inst[key][1] = value
    for phase in project.phases():
        hap = phase.data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = SIZE_START[phase.name]
        for atom in phase.atoms():
            atom.uiso = UISO_START[phase.name]
            atom.refinement_flags = " "
    project.get_Constraints("Phase").clear()
    freeze_all(project)
    project.save()
    records = [snapshot(project, "00_physical_start")]

    # Stage 1: incumbent cells/scales/background/shift/microstrain only.
    freeze_all(project)
    enable_structural_profile(project)
    refine(project, "01_incumbent", records, 24)

    # Stage 2: generating instrument width/asymmetry block only.
    freeze_all(project)
    enable_instrument(project, ["U", "W", "X", "SH/L"])
    refine(project, "02_instrument", records, 18)

    # Stage 3: angular zero and polarization block only.
    freeze_all(project)
    enable_instrument(project, ["Zero", "Polariz."])
    refine(project, "03_zero_polarization", records, 14)

    # Stage 4: final ordinary joint pass, but retain fixed physical sizes,
    # Uiso values and atomic positions to avoid the diagnosed singular block.
    freeze_all(project)
    enable_structural_profile(project)
    enable_instrument(project, ["U", "W", "X", "SH/L", "Zero", "Polariz."])
    refine(project, "04_joint", records, 30)

    final = OUT / "final.gpx"
    project.save(str(final))
    (OUT / "stages.json").write_text(json.dumps(records, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
