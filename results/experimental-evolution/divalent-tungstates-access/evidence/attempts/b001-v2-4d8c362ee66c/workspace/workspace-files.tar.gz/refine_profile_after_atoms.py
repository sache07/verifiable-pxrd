#!/usr/bin/env python3
"""Re-optimize peak-shape parameters after atomic intensities are stabilized."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "atom_refinement" / "base_atoms.gpx"
OUT = ROOT / ".tmp" / "profile_after_atoms"


def fractions(project):
    h = project.histograms()[0]
    v = [p.data["General"]["Mass"] * p.data["Histograms"][h.name]["Scale"][0] for p in project.phases()]
    total = sum(v)
    return {p.name: float(a / total) for p, a in zip(project.phases(), v)}


def describe(project, stage):
    h = project.histograms()[0]
    a = h.data["data"][1]
    obs, calc = np.asarray(a[1], float), np.asarray(a[3], float)
    inst = h.data["Instrument Parameters"][0]
    f = fractions(project)
    rec = {
        "stage": stage,
        "rwp_percent": float(h.get_wR()),
        "weighted_rms_noise_units": float(np.sqrt(np.mean((obs - calc) ** 2 / np.maximum(obs, 1.0)))),
        "instrument": {k: float(inst[k][1]) for k in ["U", "V", "W", "X", "Y", "Z", "SH/L", "Zero"]},
        "shift_um": float(h.data["Sample Parameters"]["Shift"][0]),
        "phases": [],
        "frozen": project.get_Frozen(),
    }
    for p in project.phases():
        hap = p.data["Histograms"][h.name]
        rec["phases"].append(
            {
                "name": p.name,
                "weight_fraction": f[p.name],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    print(
        f"{stage}: Rwp={rec['rwp_percent']:.5f}% wrms={rec['weighted_rms_noise_units']:.4f}; "
        + ", ".join(f"{p['name']}={p['weight_fraction']:.4f}" for p in rec["phases"])
    )
    return rec


def save_refine(project, stage, records, cycles=14):
    project.save(str(OUT / f"{stage}.gpx"))
    project.set_Controls("cycles", cycles)
    project.refine(printFile=str(OUT / f"{stage}.lst"), makeBack=False)
    records.append(describe(project, stage))
    (OUT / "stages.json").write_text(json.dumps(records, indent=2, allow_nan=False) + "\n")


def profile_flags(project, value):
    h = project.histograms()[0]
    for p in project.phases():
        hap = p.data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][2][0] = value
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2][0] = value


def instrument_flags(project, value):
    inst = project.histograms()[0].data["Instrument Parameters"][0]
    for key in ["U", "W", "X", "SH/L"]:
        inst[key][2] = value


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(OUT / "00_start.gpx"))
    project.set_Frozen()
    for p in project.phases():
        for atom in p.atoms():
            atom.refinement_flags = " "
    instrument_flags(project, False)
    profile_flags(project, True)
    records = [describe(project, "00_start")]
    save_refine(project, "01_phase_profiles", records, 16)

    profile_flags(project, False)
    instrument_flags(project, True)
    save_refine(project, "02_instrument", records, 14)

    instrument_flags(project, False)
    profile_flags(project, True)
    project.set_Frozen()
    save_refine(project, "03_phase_profiles", records, 16)

    project.save(str(OUT / "base_profile.gpx"))


if __name__ == "__main__":
    main()
