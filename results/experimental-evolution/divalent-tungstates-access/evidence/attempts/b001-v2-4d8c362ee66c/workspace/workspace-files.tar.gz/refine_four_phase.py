#!/usr/bin/env python3
"""Resume ordinary refinement from the physical three-phase state plus CuO."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "refinement" / "04_profile_wx.gpx"
OUT = ROOT / ".tmp" / "refinement4"
CUO = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/01/11/1011194.cif")


def freeze_all(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = False
    for entry in hist.data["Instrument Parameters"][0].values():
        if isinstance(entry, list) and len(entry) > 2:
            entry[2] = False
    for entry in hist.data["Sample Parameters"].values():
        if isinstance(entry, list) and len(entry) > 1 and isinstance(entry[1], bool):
            entry[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])


def weight_fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histograms()[0]
    amounts = [
        float(p.data["General"]["Mass"]) * float(p.data["Histograms"][hist.name]["Scale"][0])
        for p in project.phases()
    ]
    total = sum(amounts)
    return {p.name: a / total for p, a in zip(project.phases(), amounts)}


def record(project: G2.G2Project, stage: str) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    fracs = weight_fractions(project)
    phases = []
    for p in project.phases():
        hap = p.data["Histograms"][hist.name]
        phases.append(
            {
                "name": p.name,
                "weight_fraction": fracs[p.name],
                "cell": [float(v) for v in p.data["General"]["Cell"][1:]],
                "scale": float(hap["Scale"][0]),
                "size_um": float(hap["Size"][1][0]),
                "microstrain_ppm": float(hap["Mustrain"][1][0]),
                "md_ratio": float(hap["Pref.Ori."][1]),
                "md_axis": list(hap["Pref.Ori."][3]),
            }
        )
    a = hist.data["data"][1]
    obs, calc = np.asarray(a[1], float), np.asarray(a[3], float)
    residual = obs - calc
    result = {
        "stage": stage,
        "rwp_percent": float(hist.get_wR()),
        "weighted_rms_noise_units": float(np.sqrt(np.mean(residual**2 / np.maximum(obs, 1.0)))),
        "instrument": {k: float(inst[k][1]) for k in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]},
        "sample": {k: float(sample[k][0]) for k in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]},
        "phases": phases,
        "vary_list": [str(v) for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
    }
    print(
        f"{stage}: Rwp={result['rwp_percent']:.5f}% wrms={result['weighted_rms_noise_units']:.4f}; "
        + ", ".join(f"{p['name']}={p['weight_fraction']:.4f}" for p in phases)
    )
    return result


def run_stage(project: G2.G2Project, stage: str, records: list[dict], cycles: int = 10) -> None:
    # refine() ignores its newfile argument in this GSAS-II build, so set the
    # destination explicitly before every stage to preserve its predecessor.
    project.save(str(OUT / f"{stage}.gpx"))
    project.set_Controls("cycles", cycles)
    project.refine(printFile=str(OUT / f"{stage}.lst"), makeBack=False)
    records.append(record(project, stage))
    (OUT / "stages.json").write_text(json.dumps(records, indent=2, allow_nan=False) + "\n")


def set_limits(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hid = hist.id
    bounds = {
        f":{hid}:U": (0.0, 100.0),
        f":{hid}:W": (0.0, 100.0),
        f":{hid}:X": (0.0, 20.0),
        f":{hid}:SH/L": (0.001, 0.2),
        f":{hid}:Polariz.": (0.0, 1.0),
        f":{hid}:Shift": (-2000.0, 2000.0),
        f":{hid}:Zero": (-1.0, 1.0),
        f":{hid}:SurfRoughA": (0.0, 0.95),
        f":{hid}:SurfRoughB": (0.0, 2.0),
    }
    for phase in project.phases():
        pid = phase.id
        bounds[f"{pid}:{hid}:Scale"] = (1e-12, 1e6)
        bounds[f"{pid}:{hid}:Size;i"] = (0.01, 10.0)
        bounds[f"{pid}:{hid}:Mustrain;i"] = (0.0, 30000.0)
    for variable, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)


def set_profile_flags(project: G2.G2Project, size: bool, strain: bool) -> None:
    hist = project.histograms()[0]
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][2][0] = size
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2][0] = strain


def main() -> None:
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(OUT / "00_start.gpx"))
    freeze_all(project)
    hist = project.histograms()[0]
    old_amount = sum(
        float(p.data["General"]["Mass"]) * float(p.data["Histograms"][hist.name]["Scale"][0])
        for p in project.phases()
    )
    cuo = project.add_phase(str(CUO), phasename="CuO_tenorite", histograms=[hist], fmthint="CIF")
    hap = cuo.data["Histograms"][hist.name]
    hap["Scale"] = [old_amount * 0.027 / 0.973 / float(cuo.data["General"]["Mass"]), False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.30
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][2] = False

    # Reacquire wrappers after modifying the project tree and set the common
    # structural/intensity refinement state.
    hist = project.histograms()[0]
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    hist.data["Background"][0][1] = True
    set_limits(project)
    records = [record(project, "00_start")]

    run_stage(project, "01_four_phase_common", records, 12)

    # One angular nuisance at a time avoids the near-perfect Zero/Shift
    # correlation while preserving their physically distinct angle dependence.
    hist.data["Sample Parameters"]["Shift"][1] = True
    run_stage(project, "02_shift", records, 10)

    set_profile_flags(project, size=True, strain=False)
    run_stage(project, "03_size", records, 12)

    set_profile_flags(project, size=False, strain=True)
    run_stage(project, "04_strain", records, 12)

    # Refine the common instrumental broadening with phase broadening frozen.
    set_profile_flags(project, size=False, strain=False)
    inst = hist.data["Instrument Parameters"][0]
    for key in ["U", "W", "X", "SH/L"]:
        inst[key][2] = True
    run_stage(project, "05_instrument", records, 12)

    # Revisit phase broadening against the now-updated, positive-bounded
    # instrument profile.
    for key in ["U", "W", "X", "SH/L"]:
        inst[key][2] = False
    set_profile_flags(project, size=True, strain=True)
    run_stage(project, "06_phase_profile", records, 14)

    project.save(str(OUT / "base_four_phase.gpx"))


if __name__ == "__main__":
    main()
