#!/usr/bin/env python3
"""Resume ordinary refinement after residual/prototype closure.

Two branches are polished from saved, replay-valid common states: the physical
four-phase model and the only non-collapsed but sub-quantitative prototype
addition (P2/c CuWO4).  This tests whether that trace survives when incumbent
parameters are again allowed to refine.
"""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
OUT = ROOT / ".tmp" / "final_polish"
BRANCHES = {
    "four_phase": ROOT / ".tmp" / "anisotropic_refinement" / "best_anisotropic.gpx",
    "five_phase_trace": ROOT
    / ".tmp"
    / "prototype_transfer"
    / "addition"
    / "wolframite_P2c"
    / "02_cell.gpx",
}


def fractions(project: G2.G2Project) -> dict[str, float]:
    h = project.histograms()[0]
    amounts = [
        float(p.data["General"]["Mass"] * p.data["Histograms"][h.name]["Scale"][0])
        for p in project.phases()
    ]
    total = sum(amounts)
    return {p.name: value / total for p, value in zip(project.phases(), amounts)}


def configure(project: G2.G2Project) -> None:
    project.set_Frozen()
    h = project.histograms()[0]
    h.data["Background"][0][1] = True
    h.data["Sample Parameters"]["Shift"][1] = True
    for entry in h.data["Instrument Parameters"][0].values():
        if isinstance(entry, list) and len(entry) > 2:
            entry[2] = False
    project.get_Constraints("Phase").clear()
    main_names = {
        "CuWO4_triclinic",
        "WO3_monoclinic",
        "Cu3WO6_cubic",
        "CuO_tenorite",
    }
    for p in project.phases():
        is_main = p.name in main_names
        p.data["General"]["Cell"][0] = True
        hap = p.data["Histograms"][h.name]
        hap["Scale"][1] = True
        project.set_Controls("parmMin", 1e-12, variable=f"{p.id}:{h.id}:Scale")
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        if is_main and p.name != "CuO_tenorite":
            # Preserve the selected uniaxial models and refine both terms.
            hap["Mustrain"][2][0] = True
            hap["Mustrain"][2][1] = True
            for suffix in ["i", "a"]:
                project.set_Controls("parmMin", 0.0, variable=f"{p.id}:{h.id}:Mustrain;{suffix}")
                project.set_Controls("parmMax", 30000.0, variable=f"{p.id}:{h.id}:Mustrain;{suffix}")
        for atom in p.atoms():
            atom.refinement_flags = " "
        if not is_main:
            # The trace prototype has insufficient intensity to support atom
            # or profile refinement; only its scale and cell are challenged.
            continue
        variables = []
        for index, atom in enumerate(p.atoms()):
            atom.refinement_flags = "U"
            variable = f"{p.id}::AUiso:{index}"
            variables.append(variable)
            project.set_Controls("parmMin", 0.0001, variable=variable)
            project.set_Controls("parmMax", 0.05, variable=variable)
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
        for atom in p.atoms():
            if atom.element == "O":
                atom.refinement_flags = "XU"
        if p.name == "CuWO4_triclinic":
            for atom in p.atoms():
                if atom.element == "Cu":
                    atom.refinement_flags = "XU"
        if p.name in {"WO3_monoclinic", "Cu3WO6_cubic"}:
            for atom in p.atoms():
                atom.refinement_flags = "XU"


def run(label: str, source: Path) -> dict:
    folder = OUT / label
    folder.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source))
    configure(project)
    project.save(str(folder / "00_start.gpx"))
    project.set_Controls("cycles", 24)
    project.refine(printFile=str(folder / "01_polish.lst"), makeBack=False)
    project.save(str(folder / "final.gpx"))
    row = {
        "label": label,
        "source": str(source.relative_to(ROOT)),
        "project": str(Path(project.filename).relative_to(ROOT)),
        "rwp_percent_cached": float(project.histograms()[0].get_wR()),
        "fractions": fractions(project),
        "frozen": [str(value) for value in project.get_Frozen()],
    }
    print(json.dumps(row, sort_keys=True))
    return row


def main() -> None:
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for label, source in BRANCHES.items():
        try:
            rows.append(run(label, source))
        except Exception as exc:
            row = {"label": label, "status": "failed", "error": f"{type(exc).__name__}: {exc}"}
            print(json.dumps(row, sort_keys=True))
            rows.append(row)
    (OUT / "results.json").write_text(json.dumps(rows, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
