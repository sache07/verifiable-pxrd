#!/usr/bin/env python3
"""Residual-directed common-state additions from the replay-valid atom model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "atom_refinement" / "base_atoms.gpx"
OUT = ROOT / ".tmp" / "addition_trials_atoms"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
SAN = ROOT / ".tmp" / "candidate_cifs"


def cod(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


TRIALS = [
    ("CuWO4_P2c_4000807", cod("4000807")),
    ("Cu2WO4_2002403", SAN / "2002403_neutral_p1.cif"),
    ("Cu4O3_9000603", cod("9000603")),
    ("Cu2O_1010941", cod("1010941")),
    ("CuO2_1521320", cod("1521320")),
    ("WO3_P21m_1010618", cod("1010618")),
    ("WO3_P21c_1528915", cod("1528915")),
    ("WO3_P1_2106293", cod("2106293")),
    ("WO3_Pnma_2107312", cod("2107312")),
    ("WO3_P21c_1563541", cod("1563541")),
    ("WO3_tetra_1521532", cod("1521532")),
    ("W18O49_1528166", SAN / "1528166_neutral_p1.cif"),
    ("W10O29_1538317", SAN / "1538317_neutral_p1.cif"),
    ("W17O47_2107065", SAN / "2107065_neutral_p1.cif"),
    ("W3O8_2101049", SAN / "2101049_neutral_p1.cif"),
    ("W3O8_2101050", SAN / "2101050_neutral_p1.cif"),
]


def freeze(project):
    project.set_Frozen()
    project.get_Constraints("Phase").clear()
    h = project.histograms()[0]
    h.data["Background"][0][1] = False
    for entry in h.data["Instrument Parameters"][0].values():
        if isinstance(entry, list) and len(entry) > 2:
            entry[2] = False
    for entry in h.data["Sample Parameters"].values():
        if isinstance(entry, list) and len(entry) > 1 and isinstance(entry[1], bool):
            entry[1] = False
    for p in project.phases():
        p.data["General"]["Cell"][0] = False
        for atom in p.atoms():
            atom.refinement_flags = " "
        hap = p.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])


def fractions(project):
    h = project.histograms()[0]
    values = [p.data["General"]["Mass"] * p.data["Histograms"][h.name]["Scale"][0] for p in project.phases()]
    total = sum(values)
    return {p.name: float(v / total) for p, v in zip(project.phases(), values)}


def trial(label: str, path: Path):
    dest = OUT / label
    dest.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(dest / "scale.gpx"))
    freeze(project)
    h = project.histograms()[0]
    old = sum(p.data["General"]["Mass"] * p.data["Histograms"][h.name]["Scale"][0] for p in project.phases())
    p = project.add_phase(str(path), phasename=f"trial_{label}", histograms=[h], fmthint="CIF")
    hap = p.data["Histograms"][h.name]
    hap["Scale"] = [old * 0.01 / 0.99 / p.data["General"]["Mass"], True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.30
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False
    project.set_Controls("parmMin", 1e-12, variable=f"{p.id}:{h.id}:Scale")
    project.set_Controls("cycles", 8)
    project.refine(printFile=str(dest / "scale.lst"), makeBack=False)
    f = fractions(project)
    scale_result = {
        "rwp_percent": float(project.histograms()[0].get_wR()),
        "weight_fraction": f[p.name],
        "scale": float(p.data["Histograms"][h.name]["Scale"][0]),
    }
    cell_status = "not_run"
    if scale_result["weight_fraction"] > 0.001:
        project.save(str(dest / "cell.gpx"))
        p.data["General"]["Cell"][0] = True
        project.set_Controls("cycles", 8)
        try:
            project.refine(printFile=str(dest / "cell.lst"), makeBack=False)
            cell_status = "completed"
        except Exception as exc:
            cell_status = f"failed: {exc}"
    f = fractions(project)
    result = {
        "label": label,
        "path": str(path),
        "scale_only": scale_result,
        "cell_status": cell_status,
        "cell_rwp_percent": float(project.histograms()[0].get_wR()),
        "cell_weight_fraction": f[p.name],
        "cell": [float(v) for v in p.data["General"]["Cell"][1:]],
        "project": str(Path(project.filename).relative_to(ROOT)),
    }
    print(json.dumps(result, sort_keys=True))
    return result


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for label, path in TRIALS:
        try:
            results.append(trial(label, path))
        except Exception as exc:
            row = {"label": label, "path": str(path), "status": "failed", "error": str(exc)}
            print(json.dumps(row, sort_keys=True))
            results.append(row)
    (OUT / "results.json").write_text(json.dumps(results, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
