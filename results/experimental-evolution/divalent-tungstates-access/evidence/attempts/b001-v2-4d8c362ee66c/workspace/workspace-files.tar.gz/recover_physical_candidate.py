#!/usr/bin/env python3
"""Validate physically corrected starts from the singular coupled profile trial.

The singular project is not submitted. Extreme/unequal parameters are first
removed with all variables fixed; only then are safe scale/background/cell and
shift blocks refined in a fresh working copy. Snapshots use binary copies so
later stages cannot overwrite earlier evidence.
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "physical_polish" / "regularized_physical" / "final.gpx"
OUT = ROOT / ".tmp" / "recovered_physical"
WORKING = OUT / "working.gpx"


def freeze_all(project):
    project.set_Frozen()
    h = project.histograms()[0]
    h.data["Background"][0][1] = False
    for entry in h.data["Instrument Parameters"][0].values():
        if isinstance(entry, list) and len(entry) > 2:
            entry[2] = False
    for entry in h.data["Sample Parameters"].values():
        if isinstance(entry, list) and len(entry) > 1 and isinstance(entry[1], bool):
            entry[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])


def fractions(project):
    h = project.histograms()[0]
    amounts = [
        p.data["General"]["Mass"] * p.data["Histograms"][h.name]["Scale"][0]
        for p in project.phases()
    ]
    total = sum(amounts)
    return {p.name: float(value / total) for p, value in zip(project.phases(), amounts)}


def record(project, stage, records):
    h = project.histograms()[0]
    snapshot = OUT / f"{stage}.gpx"
    shutil.copy2(WORKING, snapshot)
    row = {
        "stage": stage,
        "project": str(snapshot.relative_to(ROOT)),
        "rwp_percent_cached": float(h.get_wR()),
        "fractions": fractions(project),
        "frozen": [str(value) for value in project.get_Frozen()],
    }
    print(json.dumps(row, sort_keys=True))
    records.append(row)


def refine(project, stage, records, cycles):
    project.set_Controls("cycles", cycles)
    project.refine(printFile=str(OUT / f"{stage}.lst"), makeBack=False)
    record(project, stage, records)


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    shutil.copy2(SOURCE, WORKING)
    project = G2.G2Project(gpxfile=str(WORKING))
    h = project.histograms()[0]
    freeze_all(project)
    project.get_Constraints("Phase").clear()
    # Restore equal, bounded phase Uiso values and eliminate the cubic
    # [0,30000] uniaxial term that caused the singularity.
    for phase in project.phases():
        values = [float(a.uiso) for a in phase.atoms()]
        uiso = min(0.02, max(0.0001, min(values)))
        for atom in phase.atoms():
            atom.uiso = uiso
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Size"][1][0] = min(1.5, max(0.04, float(hap["Size"][1][0])))
        if phase.name in {"Cu3WO6_cubic", "CuO_tenorite"}:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
        elif phase.name == "CuWO4_triclinic":
            # Keep the finite successful values; they are broadening standard
            # deviations, so exactly zero is not valid in a uniaxial model.
            hap["Mustrain"][1][0] = max(1.0, float(hap["Mustrain"][1][0]))
            hap["Mustrain"][1][1] = max(1.0, float(hap["Mustrain"][1][1]))
    project.save()
    records = []
    record(project, "00_corrected_fixed", records)

    freeze_all(project)
    h.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][h.name]["Scale"][1] = True
    refine(project, "01_scale_background", records, 20)

    freeze_all(project)
    h.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][h.name]["Scale"][1] = True
        phase.data["General"]["Cell"][0] = True
    refine(project, "02_cells", records, 20)

    freeze_all(project)
    h.data["Background"][0][1] = True
    h.data["Sample Parameters"]["Shift"][1] = True
    for phase in project.phases():
        phase.data["Histograms"][h.name]["Scale"][1] = True
        phase.data["General"]["Cell"][0] = True
    refine(project, "03_shift", records, 20)

    final = OUT / "final.gpx"
    shutil.copy2(WORKING, final)
    (OUT / "stages.json").write_text(json.dumps(records, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
