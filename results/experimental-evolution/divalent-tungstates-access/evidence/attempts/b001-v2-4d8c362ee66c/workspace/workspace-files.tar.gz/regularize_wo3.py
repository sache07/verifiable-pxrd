#!/usr/bin/env python3
"""Profile/structure tradeoff for the weakly determined WO3 oxygen sites."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "anisotropic_refinement" / "03_refit_coordinates.gpx"
PARENT = ROOT / ".tmp" / "atom_refinement" / "02_cuwo4_oxygen.gpx"
OUT = ROOT / ".tmp" / "wo3_regularization"
FACTORS = [0.0, 0.05, 0.10, 0.20, 0.40, 0.60, 0.80]


def fractions(project):
    h = project.histograms()[0]
    amounts = [
        p.data["General"]["Mass"] * p.data["Histograms"][h.name]["Scale"][0]
        for p in project.phases()
    ]
    total = sum(amounts)
    return {p.name: float(v / total) for p, v in zip(project.phases(), amounts)}


def interpolate(parent, refined, factor):
    a = np.asarray(parent, float)
    b = np.asarray(refined, float)
    delta = b - a
    delta -= np.round(delta)
    return tuple((a + factor * delta).tolist())


def run(factor, parent_coords):
    label = f"factor_{factor:.2f}".replace(".", "p")
    folder = OUT / label
    folder.mkdir(parents=True, exist_ok=True)
    branch = folder / "00_start.gpx"
    shutil.copy2(BASE, branch)
    project = G2.G2Project(gpxfile=str(branch))
    wo3 = project.phase("WO3_monoclinic")
    displacements = {}
    for atom in wo3.atoms():
        if atom.element == "O":
            refined = tuple(atom.coordinates)
            atom.coordinates = interpolate(parent_coords[atom.label], refined, factor)
            displacements[atom.label] = {
                "parent": list(parent_coords[atom.label]),
                "unregularized": list(refined),
                "start": list(atom.coordinates),
            }
    # Keep all refined atomic positions fixed while nuisance, cells, scales and
    # common phase Uiso values readjust. This isolates the WO3 oxygen prior.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "U"
    project.set_Frozen()
    project.save()
    project.set_Controls("cycles", 16)
    project.refine(printFile=str(folder / "01_readjust.lst"), makeBack=False)
    final = folder / "final.gpx"
    project.save(str(final))
    row = {
        "factor": factor,
        "project": str(final.relative_to(ROOT)),
        "rwp_percent_cached": float(project.histograms()[0].get_wR()),
        "fractions": fractions(project),
        "displacements": displacements,
        "uiso_WO3_A2": [float(a.uiso) for a in wo3.atoms()],
    }
    print(json.dumps(row, sort_keys=True))
    return row


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    parent = G2.G2Project(gpxfile=str(PARENT)).phase("WO3_monoclinic")
    parent_coords = {atom.label: tuple(atom.coordinates) for atom in parent.atoms() if atom.element == "O"}
    rows = [run(factor, parent_coords) for factor in FACTORS]
    (OUT / "results.json").write_text(json.dumps(rows, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
