#!/usr/bin/env python3
"""Build and stage a three-phase GSAS-II refinement for the supplied pattern.

Run with the GSAS-II Python interpreter. Intermediate projects and a compact
JSON summary are written below .tmp/refinement/ so that later candidate-phase
tests can all start from the same refined state.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / ".tmp" / "refinement"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PHASES = [
    ("CuWO4_triclinic", "4000806", 0.52),
    ("WO3_monoclinic", "2311041", 0.30),
    ("Cu3WO6_cubic", "1527404", 0.18),
]


def prepare_inputs() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    WORK.mkdir(parents=True, exist_ok=True)
    arr = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    x, y = arr.T
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(
        WORK / "pattern.xye",
        np.column_stack((x, y, sigma)),
        fmt=["%.8f", "%.8f", "%.8f"],
    )
    (WORK / "instrument.instprm").write_text(
        "#GSAS-II instrument parameter file for Cu Kalpha laboratory data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.05;Polariz.:0.8;Azimuth:0.0\n"
        "U:5.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return x, y, sigma


def initial_background(x: np.ndarray, y: np.ndarray, ncoef: int = 18) -> list[float]:
    step = float(np.median(np.diff(x)))
    width = max(5, int(round(3.0 / step)) | 1)
    baseline = percentile_filter(y, percentile=12, size=width, mode="nearest")
    baseline = gaussian_filter1d(baseline, max(1.0, 0.45 / step))
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(t, baseline, ncoef - 1).tolist()


def weight_fractions(project: G2.G2Project, hist_name: str) -> dict[str, float]:
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist_name]
        masses.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
    total = sum(masses)
    return {
        phase.name: (mass / total if total > 0 else 0.0)
        for phase, mass in zip(project.phases(), masses)
    }


def summary(project: G2.G2Project, stage: str) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    cov = project.data.get("Covariance", {}).get("data", {})
    phases = []
    fractions = weight_fractions(project, hist.name)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
                "scale": float(hap["Scale"][0]),
                "weight_fraction": fractions[phase.name],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "pref_ori": hap["Pref.Ori."],
            }
        )
    arrays = hist.data["data"][1]
    x, obs, calc = (np.asarray(arrays[i], dtype=float) for i in (0, 1, 3))
    resid = obs - calc
    return {
        "stage": stage,
        "histogram": hist.name,
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "n_variables": len(cov.get("varyList", [])),
        "vary_list": [str(v) for v in cov.get("varyList", [])],
        "instrument": {
            key: (float(inst[key][1]) if isinstance(inst.get(key), list) and len(inst[key]) > 1 else inst.get(key))
            for key in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample": {
            key: (float(sample[key][0]) if isinstance(sample.get(key), list) else sample.get(key))
            for key in ("Type", "Scale", "Gonio. radius", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
            if key in sample
        },
        "phases": phases,
        "residual": {
            "rmse_counts": float(np.sqrt(np.mean(resid**2))),
            "weighted_rms_noise_units": float(np.sqrt(np.mean(resid**2 / np.maximum(obs, 1.0)))),
            "max_abs_counts": float(np.max(np.abs(resid))),
            "grid_min": float(x[0]),
            "grid_max": float(x[-1]),
        },
    }


def save_stage(project: G2.G2Project, stage: str, records: list[dict]) -> None:
    project.save(str(WORK / f"{stage}.gpx"))
    rec = summary(project, stage)
    records.append(rec)
    (WORK / "stages.json").write_text(json.dumps(records, indent=2, allow_nan=False) + "\n")
    print(
        f"{stage}: Rwp={rec['rwp_percent']:.4f}% "
        f"wrms={rec['residual']['weighted_rms_noise_units']:.4f} "
        f"fractions="
        + ", ".join(f"{p['name']}={p['weight_fraction']:.4f}" for p in rec["phases"])
    )


def refine(project: G2.G2Project, stage: str, records: list[dict], cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(newfile=str(WORK / f"{stage}.gpx"), printFile=str(WORK / f"{stage}.lst"), makeBack=False)
    save_stage(project, stage, records)


def main() -> None:
    G2.SetPrintLevel("warn")
    x, y, _ = prepare_inputs()
    project = G2.G2Project(newgpx=str(WORK / "initial.gpx"))
    phase_objects = [
        project.add_phase(str(cod_path(cod_id)), phasename=name, fmthint="CIF")
        for name, cod_id, _ in PHASES
    ]
    hist = project.add_powder_histogram(
        str(WORK / "pattern.xye"),
        str(WORK / "instrument.instprm"),
        phases=phase_objects,
        fmthint="xye",
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [700.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 18,
                "coeffs": initial_background(x, y),
                "refine": True,
            },
        }
    )

    # Use the same mass-scale convention as the supplied forward-model code.
    common_intensity = 30.0
    for phase, (_, _, fraction) in zip(phase_objects, PHASES):
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"])
        hap["Scale"] = [10000.0 * common_intensity * fraction / mass, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Size"][2][0] = False
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = False
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]

    records: list[dict] = []
    project.set_Controls("cycles", 0)
    project.refine(newfile=str(WORK / "initial.gpx"), printFile=str(WORK / "initial.lst"), makeBack=False)
    save_stage(project, "initial", records)

    refine(project, "01_scales_background", records, 8)

    hist.set_refinements({"Sample Parameters": ["Shift"], "Instrument Parameters": ["Zero"]})
    refine(project, "02_position_common", records, 8)

    for phase in phase_objects:
        phase.set_refinements({"Cell": True})
    refine(project, "03_cells", records, 10)

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine(project, "04_profile_wx", records, 10)

    hist.set_refinements({"Instrument Parameters": ["U", "SH/L"]})
    refine(project, "05_profile_common", records, 10)

    for phase in phase_objects:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True, "value": 0.30},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    refine(project, "06_phase_broadening", records, 12)

    # Keep this as the common-state project for phase-presence and texture tests.
    project.save(str(WORK / "base_three_phase.gpx"))


if __name__ == "__main__":
    main()
