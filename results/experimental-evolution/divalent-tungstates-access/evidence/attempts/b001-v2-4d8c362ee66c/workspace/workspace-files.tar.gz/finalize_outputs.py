#!/usr/bin/env python3
"""Create final.gpx, exact CIF exports and fit.csv from a fresh replay."""

from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "recovered_physical" / "final.gpx"
FINAL = ROOT / "final.gpx"
REPLAY_DIR = ROOT / ".tmp" / "final_replay"
WORKER = ROOT / "learned" / "divalent-tungstates" / "scorer" / "runtime" / "replay_worker.py"
OBSERVED = ROOT / "inputs" / "pattern.csv"
CIF_NAMES = {
    "CuWO4_triclinic": "phase_CuWO4_triclinic.cif",
    "WO3_monoclinic": "phase_WO3_monoclinic.cif",
    "Cu3WO6_cubic": "phase_Cu3WO6_cubic.cif",
    "CuO_tenorite": "phase_CuO_tenorite.cif",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    shutil.copy2(SOURCE, FINAL)
    project = G2.G2Project(gpxfile=str(FINAL))
    # GSAS CIF export can apply stale covariance deltas; export the exact saved
    # atom arrays as the independent replay worker does.
    covariance = project.data["Covariance"]["data"]
    project.data["Covariance"]["data"] = {}
    try:
        for phase in project.phases():
            phase.export_CIF(str(ROOT / CIF_NAMES[phase.name]))
    finally:
        project.data["Covariance"]["data"] = covariance

    REPLAY_DIR.mkdir(parents=True, exist_ok=True)
    request = {
        "project": str(FINAL),
        "observed": str(OBSERVED),
        "histogram": "PWDR pattern.xye",
    }
    request_path = REPLAY_DIR / "request.json"
    request_path.write_text(json.dumps(request, indent=2) + "\n")
    completed = subprocess.run(
        [sys.executable, str(WORKER), str(request_path)],
        cwd=REPLAY_DIR,
        text=True,
        capture_output=True,
        timeout=180,
    )
    replay = json.loads((REPLAY_DIR / "replay.json").read_text())
    if completed.returncode or replay.get("status") != "replayed":
        raise RuntimeError(f"Final replay failed: {replay}; stderr={completed.stderr}")
    arrays = np.load(REPLAY_DIR / "prediction.npz")
    x = np.asarray(arrays["x"], float)
    observed = np.asarray(arrays["observed"], float)
    calculated = np.asarray(arrays["predicted"], float)
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, observed, calculated, difference]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference_observed_minus_calculated",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    nvars = int(covariance.get("Rvals", {}).get("Nvars", len(covariance.get("varyList", []))))
    npoints = len(x)
    metrics = {
        "project_sha256": sha256(FINAL),
        "replay_status": replay["status"],
        "histogram": replay["histogram"],
        "profile_review_flags": replay.get("profile_review_flags", []),
        "n_points": npoints,
        "n_refined_variables": nvars,
        "rwp_percent": float(100.0 * np.sqrt(chi_square / denominator)),
        "rp_percent": float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed))),
        "weighted_chi_square": chi_square,
        "reduced_chi_square": float(chi_square / (npoints - nvars)),
        "goodness_of_fit": float(np.sqrt(chi_square / (npoints - nvars))),
        "phases": [
            {
                **phase,
                "submitted_cif": CIF_NAMES[phase["name"]],
                "submitted_cif_sha256": sha256(ROOT / CIF_NAMES[phase["name"]]),
            }
            for phase in replay["phases"]
        ],
    }
    (ROOT / ".tmp" / "final_metrics.json").write_text(
        json.dumps(metrics, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps(metrics, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
