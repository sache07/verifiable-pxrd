#!/usr/bin/env python3
"""Create fixed, physically bounded profile variants for fresh replay."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "wo3_regularization" / "factor_0p10" / "final.gpx"
OUT = ROOT / ".tmp" / "profile_variants"

INSTRUMENT = {
    "U": 8.096164076466504,
    "W": 14.136288917361073,
    "X": 3.8629768241208677,
    "SH/L": 0.014933652503899933,
    "Zero": -0.0751488219332485,
    "Polariz.": 0.7360223752844883,
}
SIZES = {
    "CuWO4_triclinic": 0.16060897809516886,
    "WO3_monoclinic": 1.45,
    "Cu3WO6_cubic": 1.0298388832601586,
    "CuO_tenorite": 1.45,
}
UISO = {
    "CuWO4_triclinic": 0.01647139217504667,
    "WO3_monoclinic": 0.0195,
    "Cu3WO6_cubic": 0.014746887503438305,
    "CuO_tenorite": 0.01944276800792776,
}
STRAINS = {
    "bounded_low": {
        "CuWO4_triclinic": ("uniaxial", 300.0, 300.0),
        "WO3_monoclinic": ("uniaxial", 1526.9, 2214.4),
        "Cu3WO6_cubic": ("isotropic", 0.0, 0.0),
        "CuO_tenorite": ("isotropic", 0.0, 0.0),
    },
    "original_strain": {
        "CuWO4_triclinic": ("uniaxial", 1283.4, 1699.3),
        "WO3_monoclinic": ("uniaxial", 2071.0, 2679.3),
        "Cu3WO6_cubic": ("uniaxial", 332.9, 334.7),
        "CuO_tenorite": ("isotropic", 0.0, 0.0),
    },
    "capped_cubic": {
        "CuWO4_triclinic": ("uniaxial", 300.0, 300.0),
        "WO3_monoclinic": ("uniaxial", 1526.9, 2214.4),
        "Cu3WO6_cubic": ("uniaxial", 0.0, 8000.0),
        "CuO_tenorite": ("isotropic", 0.0, 0.0),
    },
}


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for label, strains in STRAINS.items():
        target = OUT / f"{label}.gpx"
        shutil.copy2(SOURCE, target)
        project = G2.G2Project(gpxfile=str(target))
        project.set_Frozen()
        h = project.histograms()[0]
        for key, value in INSTRUMENT.items():
            h.data["Instrument Parameters"][0][key][1] = value
            h.data["Instrument Parameters"][0][key][2] = False
        h.data["Sample Parameters"]["Shift"] = [706.8754629976296, False]
        for phase in project.phases():
            for atom in phase.atoms():
                atom.uiso = UISO[phase.name]
                atom.refinement_flags = " "
            hap = phase.data["Histograms"][h.name]
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = SIZES[phase.name]
            hap["Size"][2] = [False] * len(hap["Size"][2])
            mode, equatorial, axial = strains[phase.name]
            hap["Mustrain"][0] = mode
            hap["Mustrain"][1][0] = equatorial
            hap["Mustrain"][1][1] = axial
            hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        project.save()
        row = {"label": label, "project": str(target.relative_to(ROOT))}
        print(json.dumps(row, sort_keys=True))
        rows.append(row)
    (OUT / "manifest.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
