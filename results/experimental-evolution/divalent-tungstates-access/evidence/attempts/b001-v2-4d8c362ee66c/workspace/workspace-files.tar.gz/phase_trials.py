#!/usr/bin/env python3
"""Common-state candidate phase tests from a fixed three-phase project."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
# This file is the physical common-profile state (Rwp ~8.61%). The subsequent
# scripted stage overwrote its own nominal predecessor because GSAS-II's
# refine(newfile=...) argument is currently ignored, so use this saved state.
BASE = ROOT / ".tmp" / "refinement" / "04_profile_wx.gpx"
OUT = ROOT / ".tmp" / "phase_trials"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


TRIALS = [
    ("CuO_C2c", "1011194"),
    ("CuO_Cc", "9016057"),
    ("Cu2O", "1010941"),
    ("Cu4O3", "9000603"),
    ("Cu2WO4", "2002403"),
    ("W18O49", "1528166"),
    ("W10O29", "1538317"),
    ("W17O47", "2107065"),
]


def freeze_project(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = False
    for entry in hist.data["Instrument Parameters"][0].values():
        if isinstance(entry, list) and len(entry) > 2:
            entry[2] = False
    for entry in hist.data["Sample Parameters"].values():
        if isinstance(entry, list) and len(entry) > 1 and isinstance(entry[1], bool):
            entry[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histograms()[0]
    amounts = [
        float(p.data["General"]["Mass"]) * float(p.data["Histograms"][hist.name]["Scale"][0])
        for p in project.phases()
    ]
    total = sum(amounts)
    return {p.name: a / total for p, a in zip(project.phases(), amounts)}


def run_trial(label: str, cod_id: str) -> dict:
    target = OUT / label
    target.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    # GSAS-II refines self.filename in place; move each branch before fitting.
    project.save(str(target / "start.gpx"))
    freeze_project(project)
    hist = project.histograms()[0]
    base_rwp = float(hist.get_wR())
    old_amount = sum(
        float(p.data["General"]["Mass"]) * float(p.data["Histograms"][hist.name]["Scale"][0])
        for p in project.phases()
    )
    phase = project.add_phase(
        str(cod_path(cod_id)),
        phasename=f"trial_{label}",
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    mass = float(phase.data["General"]["Mass"])
    hap["Scale"] = [old_amount * 0.03 / 0.97 / mass, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.30
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][2] = False
    phase.data["General"]["Cell"][0] = False
    project.set_Controls("cycles", 8)
    project.refine(printFile=str(target / "scale.lst"), makeBack=False)
    project.save(str(target / "scale.gpx"))
    scale_rwp = float(project.histograms()[0].get_wR())
    scale_fraction = fractions(project)[phase.name]
    cell_status = "not_run"
    if scale_fraction > 2e-4:
        phase.data["General"]["Cell"][0] = True
        project.save(str(target / "cell.gpx"))
        project.set_Controls("cycles", 10)
        try:
            project.refine(printFile=str(target / "cell.lst"), makeBack=False)
            cell_status = "completed"
        except Exception as exc:
            cell_status = f"failed: {exc}"
    result = {
        "label": label,
        "cod_id": cod_id,
        "base_rwp_percent": base_rwp,
        "scale_only_rwp_percent": scale_rwp,
        "scale_only_weight_fraction": scale_fraction,
        "cell_status": cell_status,
        "cell_rwp_percent": float(project.histograms()[0].get_wR()),
        "cell_weight_fraction": fractions(project)[phase.name],
        "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
        "scale": float(phase.data["Histograms"][hist.name]["Scale"][0]),
    }
    print(json.dumps(result, sort_keys=True))
    return result


def main() -> None:
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for trial in TRIALS:
        try:
            results.append(run_trial(*trial))
        except Exception as exc:
            result = {"label": trial[0], "cod_id": trial[1], "status": "failed", "error": str(exc)}
            print(json.dumps(result, sort_keys=True))
            results.append(result)
    (OUT / "results.json").write_text(json.dumps(results, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
