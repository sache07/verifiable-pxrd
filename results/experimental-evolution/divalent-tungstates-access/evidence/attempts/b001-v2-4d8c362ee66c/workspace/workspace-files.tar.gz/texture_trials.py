#!/usr/bin/env python3
"""Common-state March-Dollase axis trials for each accepted phase."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "atom_refinement" / "base_atoms.gpx"
OUT = ROOT / ".tmp" / "texture_trials_atoms"
AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def freeze(project):
    project.set_Frozen()
    # Uiso values are already committed equally to every atom. Remove the
    # equivalences when every atomic parameter is fixed, avoiding an inactive
    # constraint path in subsequent forward calculations.
    project.get_Constraints("Phase").clear()
    h = project.histograms()[0]
    h.data["Background"][0][1] = False
    for entry in h.data["Instrument Parameters"][0].values():
        if isinstance(entry, list) and len(entry) > 2:
            entry[2] = False
    for entry in h.data["Sample Parameters"].values():
        if isinstance(entry, list) and len(entry) > 1 and isinstance(entry[1], bool):
            entry[1] = False
    for p in project.phases():
        p.data["General"]["Cell"][0] = False
        for atom in p.atoms():
            atom.refinement_flags = " "
        hap = p.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def fractions(project):
    h = project.histograms()[0]
    a = [p.data["General"]["Mass"] * p.data["Histograms"][h.name]["Scale"][0] for p in project.phases()]
    total = sum(a)
    return {p.name: float(v / total) for p, v in zip(project.phases(), a)}


def trial(phase_name, axis):
    label = phase_name.replace("_", "-") + "_" + "".join(map(str, axis))
    dest = OUT / label
    dest.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(dest / "trial.gpx"))
    freeze(project)
    h = project.histograms()[0]
    p = project.phase(phase_name)
    hap = p.data["Histograms"][h.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    hap["Scale"][1] = True
    project.set_Controls("parmMin", 0.5, variable=f"{p.id}:{h.id}:MD")
    project.set_Controls("parmMax", 2.0, variable=f"{p.id}:{h.id}:MD")
    project.set_Controls("cycles", 10)
    project.refine(printFile=str(dest / "trial.lst"), makeBack=False)
    f = fractions(project)
    result = {
        "phase": phase_name,
        "axis": list(axis),
        "rwp_percent": float(project.histograms()[0].get_wR()),
        "md_ratio": float(p.data["Histograms"][h.name]["Pref.Ori."][1]),
        "weight_fraction": f[phase_name],
        "frozen": project.get_Frozen(),
        "project": str((dest / "trial.gpx").relative_to(ROOT)),
    }
    print(json.dumps(result, sort_keys=True))
    return result


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    seed = G2.G2Project(gpxfile=str(BASE))
    names = [p.name for p in seed.phases()]
    results = [trial(name, axis) for name in names for axis in AXES]
    (OUT / "results.json").write_text(json.dumps(results, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
