#!/usr/bin/env python3
"""Fresh full-grid atomic replay of prototype-transfer trial projects."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
TRIAL_ROOT = ROOT / ".tmp" / "prototype_transfer"
WORKER = ROOT / "learned" / "divalent-tungstates" / "scorer" / "runtime" / "replay_worker.py"
OBSERVED = ROOT / "inputs" / "pattern.csv"


def replay(label: str, project: Path) -> dict:
    out = TRIAL_ROOT / "replay" / label
    out.mkdir(parents=True, exist_ok=True)
    request = {
        "project": str(project.resolve()),
        "observed": str(OBSERVED.resolve()),
        "histogram": "PWDR pattern.xye",
    }
    request_path = out / "request.json"
    request_path.write_text(json.dumps(request, indent=2) + "\n")
    completed = subprocess.run(
        [sys.executable, str(WORKER), str(request_path)],
        cwd=out,
        text=True,
        capture_output=True,
        timeout=180,
    )
    report_path = out / "replay.json"
    report = json.loads(report_path.read_text()) if report_path.exists() else {}
    row = {
        "label": label,
        "project": str(project.relative_to(ROOT)),
        "worker_exit_code": completed.returncode,
        "worker_stdout": completed.stdout[-1000:],
        "worker_stderr": completed.stderr[-1000:],
        "status": report.get("status", "missing_report"),
        "profile_review_flags": report.get("profile_review_flags", []),
    }
    pred_path = out / "prediction.npz"
    if report.get("status") == "replayed" and pred_path.exists():
        p = np.load(pred_path)
        obs = np.asarray(p["observed"], float)
        calc = np.asarray(p["predicted"], float)
        weight = 1.0 / np.maximum(obs, 1.0)
        row["rwp_percent_replay"] = float(
            100.0 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2))
        )
        row["phases"] = report.get("phases", [])
    else:
        row["error"] = report.get("error", "replay did not produce a prediction")
    print(json.dumps(row, sort_keys=True), flush=True)
    return row


def main() -> None:
    trials = json.loads((TRIAL_ROOT / "results.json").read_text())
    targets = [("base", ROOT / ".tmp" / "anisotropic_refinement" / "best_anisotropic.gpx")]
    for row in trials:
        if "final_project" in row:
            targets.append((f"{row['mode']}__{row['label']}", ROOT / row["final_project"]))
    rows = []
    for label, project in targets:
        try:
            rows.append(replay(label, project))
        except Exception as exc:
            row = {
                "label": label,
                "project": str(project),
                "status": "failed",
                "error": f"{type(exc).__name__}: {exc}",
            }
            print(json.dumps(row, sort_keys=True), flush=True)
            rows.append(row)
    (TRIAL_ROOT / "replay_results.json").write_text(
        json.dumps(rows, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
