#!/usr/bin/env python3
"""Combine replay-verified uniaxial-strain gains and resume refinement."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "nuisance_trials" / "strain_WO3-monoclinic_010" / "trial.gpx"
OUT = ROOT / ".tmp" / "anisotropic_refinement"


def fractions(project):
    h = project.histograms()[0]
    a = [p.data["General"]["Mass"] * p.data["Histograms"][h.name]["Scale"][0] for p in project.phases()]
    t = sum(a)
    return {p.name: float(v / t) for p, v in zip(project.phases(), a)}


def state(project, stage):
    h = project.histograms()[0]
    a = h.data["data"][1]
    obs, calc = np.asarray(a[1], float), np.asarray(a[3], float)
    f = fractions(project)
    rec = {
        "stage": stage,
        "rwp_percent": float(h.get_wR()),
        "weighted_rms_noise_units": float(np.sqrt(np.mean((obs - calc) ** 2 / np.maximum(obs, 1.0)))),
        "fractions": f,
        "frozen": project.get_Frozen(),
        "phases": [],
    }
    for p in project.phases():
        hap = p.data["Histograms"][h.name]
        rec["phases"].append(
            {
                "name": p.name,
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "uiso": [float(a.uiso) for a in p.atoms()],
            }
        )
    print(
        f"{stage}: Rwp={rec['rwp_percent']:.5f}% wrms={rec['weighted_rms_noise_units']:.4f}; "
        + ", ".join(f"{k}={v:.4f}" for k, v in f.items())
    )
    return rec


def run(project, stage, records, cycles=14):
    project.save(str(OUT / f"{stage}.gpx"))
    project.set_Controls("cycles", cycles)
    project.refine(printFile=str(OUT / f"{stage}.lst"), makeBack=False)
    records.append(state(project, stage))
    (OUT / "stages.json").write_text(json.dumps(records, indent=2, allow_nan=False) + "\n")


def uniaxial(project, phase_name, axis, equatorial, axial):
    h = project.histograms()[0]
    p = project.phase(phase_name)
    hap = p.data["Histograms"][h.name]
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = equatorial
    hap["Mustrain"][1][1] = axial
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    hap["Mustrain"][3] = list(axis)
    for variable in [f"{p.id}:{h.id}:Mustrain;i", f"{p.id}:{h.id}:Mustrain;a"]:
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 30000.0, variable=variable)


def add_uiso_constraints(project):
    project.get_Constraints("Phase").clear()
    for p in project.phases():
        variables = []
        for i, atom in enumerate(p.atoms()):
            atom.refinement_flags = "U"
            variable = f"{p.id}::AUiso:{i}"
            variables.append(variable)
            project.set_Controls("parmMin", 0.0001, variable=variable)
            project.set_Controls("parmMax", 0.05, variable=variable)
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(OUT / "00_start.gpx"))
    project.set_Frozen()
    h = project.histograms()[0]
    h.data["Background"][0][1] = True
    h.data["Sample Parameters"]["Shift"][1] = True
    for entry in h.data["Instrument Parameters"][0].values():
        if isinstance(entry, list) and len(entry) > 2:
            entry[2] = False
    for p in project.phases():
        p.data["General"]["Cell"][0] = True
        for atom in p.atoms():
            atom.refinement_flags = " "
        hap = p.data["Histograms"][h.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False

    uniaxial(project, "CuWO4_triclinic", (1, 0, 0), 1438.5, 1825.1)
    uniaxial(project, "WO3_monoclinic", (0, 1, 0), 2381.8, 2913.7)
    uniaxial(project, "Cu3WO6_cubic", (0, 1, 0), 454.5, 399.6)
    # CuO showed no stable strain and remains instrument-limited.

    records = [state(project, "00_start")]
    run(project, "01_combined_strain", records, 16)

    add_uiso_constraints(project)
    run(project, "02_refit_uiso", records, 14)

    # Revisit the already physically screened coordinate model with Uiso active.
    for p in project.phases():
        for atom in p.atoms():
            if atom.element == "O":
                atom.refinement_flags = "XU"
    for atom in project.phase("CuWO4_triclinic").atoms():
        if atom.element == "Cu":
            atom.refinement_flags = "XU"
    for name in ["WO3_monoclinic", "Cu3WO6_cubic"]:
        for atom in project.phase(name).atoms():
            atom.refinement_flags = "XU"
    run(project, "03_refit_coordinates", records, 16)

    project.save(str(OUT / "best_anisotropic.gpx"))


if __name__ == "__main__":
    main()
