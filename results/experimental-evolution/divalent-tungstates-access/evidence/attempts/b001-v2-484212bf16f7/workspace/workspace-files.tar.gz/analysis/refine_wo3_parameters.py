from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'trials' / 'final_ordinary.gpx'
DST = ROOT / 'trials' / 'final_wo3_parameters.gpx'
ACTIVE = ['MnWO4_wolframite', 'Mn3WO6_R-3', 'WO3_P21c_physical']

G2.SetPrintLevel('warn')
project = G2.G2Project(gpxfile=str(SRC), newgpx=str(DST))
project.set_Controls('cycles', 18)
h = project.histogram(0)
phase = project.phase('WO3_P21c_physical')
initial = {a.label: np.array(a.coordinates, float) for a in phase.atoms()}

# Keep ordinary variables active while recovering only the heavy-atom positions.
h.data['Background'][0][1] = True
for value in h.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2: value[2] = False
h.InstrumentParameters['Zero'][2] = True
for value in h.SampleParameters.values():
    if isinstance(value, list) and len(value) > 1: value[1] = False
for p in project.phases():
    active = p.name in ACTIVE
    p.data['General']['Cell'][0] = active
    hap = p.data['Histograms'][h.name]
    hap['Scale'][1] = active
    hap['Size'][2] = [False] * len(hap['Size'][2])
    hap['Mustrain'][2] = [False] * len(hap['Mustrain'][2])
    hap['Pref.Ori.'][2] = False
    for atom in p.atoms():
        atom.refinement_flags = 'X' if p.name == phase.name and atom.element == 'W' else ' '

before = h.get_wR()
project.refine()
after_coordinates = project.histogram(0).get_wR()
phase = project.phase('WO3_P21c_physical')
movements = {}
for atom in phase.atoms():
    if atom.element != 'W': continue
    delta = np.array(atom.coordinates) - initial[atom.label]
    delta -= np.rint(delta)
    movements[atom.label] = float(np.linalg.norm(delta @ phase.data['General']['Cell'][1:4]))
    atom.refinement_flags = ' '

# Estimate a common phase Uiso and enforce it, matching the forward model.
for atom in phase.atoms(): atom.refinement_flags = 'U'
project.refine()
phase = project.phase('WO3_P21c_physical')
individual = [float(a.ADP) for a in phase.atoms()]
common = float(np.mean(individual))
for atom in phase.atoms():
    atom.ADP = common
    atom.refinement_flags = ' '
project.refine()
after_uiso = project.histogram(0).get_wR()
project.save(str(DST))

summary = {'before_wR_percent': before, 'coordinate_wR_percent': after_coordinates,
           'final_wR_percent': after_uiso, 'W_coordinate_movements_approx_A': movements,
           'individual_Uiso_trial': individual, 'common_Uiso': common}
print(json.dumps(summary, indent=2))
(ROOT/'trials'/'final_wo3_parameters.json').write_text(json.dumps(summary,indent=2)+'\n')
