from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
CIF = Path('<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06/cif/1/52/02/1520200.cif')

G2.SetPrintLevel('warn')
project = G2.G2Project(newgpx=str(ROOT / 'trials' / 'mnwo4_one.gpx'))
phase = project.add_phase(str(CIF), phasename='MnWO4_wolframite', fmthint='CIF')
hist = project.add_powder_histogram(
    str(ROOT / 'pattern.xye'), str(ROOT / 'instrument.instprm'),
    phases=[phase], fmthint='xye')
hist.SampleParameters['Type'] = 'Bragg-Brentano'
hist.SampleParameters['Gonio. radius'] = 200.0
hist.SampleParameters['Shift'] = [0.0, False]
hist.SampleParameters['Transparency'] = [0.0, False]
hist.SampleParameters['SurfRoughA'] = [0.0, False]
hist.SampleParameters['SurfRoughB'] = [0.0, False]
hist.SampleParameters['Scale'] = [1.0, False]
hist.set_refinements({
    'Limits': [float(hist.data['data'][1][0][0]), float(hist.data['data'][1][0][-1])],
    'Background': {
        'type': 'chebyschev-1', 'no. coeffs': 10,
        'coeffs': [1500.0, -150.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        'refine': True,
    },
})
phase.set_HAP_refinements({'Scale': True})
project.set_Controls('cycles', 12)

records = []
def run(label):
    project.refine()
    h = project.histogram(0)
    p = project.phase(0)
    inst = h.InstrumentParameters
    hap = p.data['Histograms'][h.name]
    rec = {
        'stage': label,
        'wR_percent': h.get_wR(),
        'cell': p.get_cell(),
        'scale': hap['Scale'][0],
        'instrument': {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
        'sample': {k: v[0] for k, v in h.SampleParameters.items() if isinstance(v, list) and len(v) > 1},
        'size': hap['Size'],
        'mustrain': hap['Mustrain'],
    }
    records.append(rec)
    print(json.dumps(rec, default=float))

hist.set_refinements({'Instrument Parameters': ['Zero']})
run('background_scale_zero')
project.phase(0).set_refinements({'Cell': True})
run('cell')
hist.set_refinements({'Instrument Parameters': ['U', 'W', 'X', 'SH/L']})
run('instrument_profile')
project.phase(0).set_HAP_refinements({
    'Size': {'type': 'isotropic', 'value': 0.25, 'refine': True},
    'Mustrain': {'type': 'isotropic', 'refine': True},
})
hap = project.phase(0).data['Histograms'][project.histogram(0).name]
hap['Mustrain'][1][0] = 1200.0
run('phase_broadening')
project.save()

h = project.histogram(0)
x, yobs, w, ycalc, ybkg, ydiff = [np.asarray(a, dtype=float) for a in h.data['data'][1][:6]]
np.savetxt(ROOT / 'trials' / 'mnwo4_one_profile.csv', np.column_stack([x, yobs, ycalc, ydiff, ybkg]),
           delimiter=',', header='two_theta_deg,observed,calculated,difference,background', comments='')
(ROOT / 'trials' / 'mnwo4_one.json').write_text(json.dumps(records, indent=2, default=float) + '\n')
