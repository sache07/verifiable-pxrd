from pathlib import Path
import json,traceback
from GSASII import GSASIIscriptable as G2
ROOT=Path(__file__).resolve().parent;BASE=ROOT/'trials'/'nuisance_polarization.gpx'
PHASES=['MnWO4_wolframite','Mn3WO6_R-3','WO3_P21c_physical'];AXES=[[0,0,1],[1,0,0],[0,1,0]]
G2.SetPrintLevel('warn');results=[]
for phase_name in PHASES:
 for axis in AXES:
  tag=phase_name+'_'+''.join(map(str,axis));out=ROOT/'trials'/f'microstrain_{tag}.gpx';rec={'phase':phase_name,'axis':axis}
  try:
   project=G2.G2Project(gpxfile=str(BASE),newgpx=str(out));project.set_Controls('cycles',16);h=project.histogram(0)
   h.data['Background'][0][1]=False
   for v in h.InstrumentParameters.values():
    if isinstance(v,list) and len(v)>2:v[2]=False
   for v in h.SampleParameters.values():
    if isinstance(v,list) and len(v)>1:v[1]=False
   for p in project.phases():
    p.data['General']['Cell'][0]=False
    for a in p.atoms():a.refinement_flags=' '
    hap=p.data['Histograms'][h.name];hap['Scale'][1]=p.name==phase_name;hap['Size'][2]=[False]*len(hap['Size'][2]);hap['Mustrain'][2]=[False]*len(hap['Mustrain'][2]);hap['Pref.Ori.'][2]=False
   hap=project.phase(phase_name).data['Histograms'][h.name];value=float(hap['Mustrain'][1][0])
   hap['Mustrain'][0]='uniaxial';hap['Mustrain'][1][0]=value;hap['Mustrain'][1][1]=value;hap['Mustrain'][2][0]=True;hap['Mustrain'][2][1]=True;hap['Mustrain'][3]=axis
   project.refine();h=project.histogram(0);hap=project.phase(phase_name).data['Histograms'][h.name]
   rec.update(wR_percent=h.get_wR(),equatorial_ppm=hap['Mustrain'][1][0],axial_ppm=hap['Mustrain'][1][1],ratio=hap['Mustrain'][1][1]/hap['Mustrain'][1][0],scale=hap['Scale'][0]);project.save()
  except Exception as exc:rec['error']=str(exc);rec['traceback_tail']=traceback.format_exc().splitlines()[-8:]
  results.append(rec);print(json.dumps(rec),flush=True)
(ROOT/'trials'/'microstrain_trials.json').write_text(json.dumps(results,indent=2)+'\n')
