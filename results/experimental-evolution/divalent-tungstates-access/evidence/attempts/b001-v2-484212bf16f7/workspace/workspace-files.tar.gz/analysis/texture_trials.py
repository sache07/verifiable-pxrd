from pathlib import Path
import json
import traceback
from GSASII import GSASIIscriptable as G2

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'trials'/'nuisance_polarization.gpx'
PHASES=['MnWO4_wolframite','Mn3WO6_R-3','WO3_P21c_physical']
AXES=[[0,0,1],[1,0,0],[0,1,0],[1,1,0],[1,1,1]]
G2.SetPrintLevel('warn')
results=[]
for phase_name in PHASES:
    for axis in AXES:
        tag=phase_name.replace('/','_')+'_' + ''.join(map(str,axis))
        out=ROOT/'trials'/f'texture_{tag}.gpx';rec={'phase':phase_name,'axis':axis}
        try:
            project=G2.G2Project(gpxfile=str(BASE),newgpx=str(out));project.set_Controls('cycles',14);h=project.histogram(0)
            h.data['Background'][0][1]=False
            for v in h.InstrumentParameters.values():
                if isinstance(v,list) and len(v)>2:v[2]=False
            for v in h.SampleParameters.values():
                if isinstance(v,list) and len(v)>1:v[1]=False
            for p in project.phases():
                p.data['General']['Cell'][0]=False
                for a in p.atoms():a.refinement_flags=' '
                hap=p.data['Histograms'][h.name];hap['Scale'][1]=p.name==phase_name
                hap['Size'][2]=[False]*len(hap['Size'][2]);hap['Mustrain'][2]=[False]*len(hap['Mustrain'][2]);hap['Pref.Ori.'][2]=False
            hap=project.phase(phase_name).data['Histograms'][h.name]
            hap['Pref.Ori.'][0]='MD';hap['Pref.Ori.'][1]=1.0;hap['Pref.Ori.'][2]=True;hap['Pref.Ori.'][3]=axis
            project.refine();h=project.histogram(0);hap=project.phase(phase_name).data['Histograms'][h.name]
            rec.update(wR_percent=h.get_wR(),md_ratio=hap['Pref.Ori.'][1],scale=hap['Scale'][0]);project.save()
        except Exception as exc:
            rec['error']=str(exc);rec['traceback_tail']=traceback.format_exc().splitlines()[-8:]
        results.append(rec);print(json.dumps(rec),flush=True)
(ROOT/'trials'/'texture_trials.json').write_text(json.dumps(results,indent=2)+'\n')
