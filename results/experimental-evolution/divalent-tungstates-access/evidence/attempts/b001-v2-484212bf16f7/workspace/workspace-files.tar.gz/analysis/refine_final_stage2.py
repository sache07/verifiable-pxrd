from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'trials' / 'final_stage1.gpx'
DST = ROOT / 'trials' / 'final_stage2.gpx'
STAGE1_LOG = ROOT / 'trials' / 'final_stage1.json'
ACTIVE = ['MnWO4_wolframite', 'WO3_monoclinic', 'Mn3WO6_R-3']

G2.SetPrintLevel('warn')
project = G2.G2Project(gpxfile=str(SRC), newgpx=str(DST))
project.set_Controls('cycles', 20)
h = project.histogram(0)

# Restore WO3 oxygen coordinates from the stable W-only coordinate stage.
records = json.loads(STAGE1_LOG.read_text())
stable = next(r for r in records if r['stage'] == 'coordinates_WO3_W')
stable_wo3 = next(p for p in stable['phases'] if p['name'] == 'WO3_monoclinic')
stable_xyz = {a['label']: a['xyz'] for a in stable_wo3['atoms'] if a['element'] == 'O'}
for atom in project.phase('WO3_monoclinic').atoms():
    if atom.element == 'O':
        atom.coordinates = stable_xyz[atom.label]
    atom.refinement_flags = ' '

# Enforce the stated instrumental U range and retain the accepted physical
# W/X/SH-L values. Refit phase widths to absorb the small boundary adjustment.
h.InstrumentParameters['U'] = [h.InstrumentParameters['U'][0], 40.0, False]
for key in ['W', 'X', 'SH/L']:
    h.InstrumentParameters[key][2] = False
h.data['Background'][0][1] = True
h.InstrumentParameters['Zero'][2] = True
h.SampleParameters['Shift'] = [-800.0, False]
for p in project.phases():
    hap = p.data['Histograms'][h.name]
    p.data['General']['Cell'][0] = p.name in ACTIVE
    hap['Scale'][1] = p.name in ACTIVE
    hap['Pref.Ori.'][2] = False
    for atom in p.atoms(): atom.refinement_flags = ' '
    if p.name in ACTIVE:
        hap['Size'][2][0] = True
        hap['Mustrain'][2][0] = True
    else:
        hap['Use'], hap['Scale'] = False, [0.0, False]
project.refine()

# With U fixed, retain X at its calibrated lower edge (an unconstrained trial
# drove it negative) and allow W/SH-L to settle, then reconverge phase widths.
h = project.histogram(0)
for p in [project.phase(n) for n in ACTIVE]:
    hap = p.data['Histograms'][h.name]
    hap['Size'][2][0] = False
    hap['Mustrain'][2][0] = False
h.InstrumentParameters['X'][1] = 0.1
h.InstrumentParameters['X'][2] = False
for key in ['W', 'SH/L']:
    h.InstrumentParameters[key][2] = True
project.refine()
h = project.histogram(0)
profile_values = {k: h.InstrumentParameters[k][1] for k in ['U', 'W', 'X', 'SH/L']}
if not (2 <= profile_values['W'] <= 40 and 0.1 <= profile_values['X'] <= 6 and
        0.005 <= profile_values['SH/L'] <= 0.10):
    raise ValueError('common profile left stated ranges: ' + repr(profile_values))
for key in ['W', 'SH/L']:
    h.InstrumentParameters[key][2] = False
for p in [project.phase(n) for n in ACTIVE]:
    hap = p.data['Histograms'][h.name]
    hap['Size'][2][0] = True
    hap['Mustrain'][2][0] = True
project.refine()

# Validate and freeze every phase width, followed by ordinary convergence.
h = project.histogram(0)
for p in [project.phase(n) for n in ACTIVE]:
    hap = p.data['Histograms'][h.name]
    size, strain = hap['Size'][1][0], hap['Mustrain'][1][0]
    if not (0.04 <= size <= 1.5 and 0 <= strain <= 8000):
        raise ValueError(f'nonphysical profile for {p.name}: size={size}, strain={strain}')
    hap['Size'][2][0] = False
    hap['Mustrain'][2][0] = False
project.refine()
project.save(str(DST))

h = project.histogram(0)
masses = [project.phase(n).data['General']['Mass'] *
          project.phase(n).data['Histograms'][h.name]['Scale'][0] for n in ACTIVE]
summary = {
    'wR_percent': h.get_wR(),
    'instrument': {k: v[1] for k, v in h.InstrumentParameters.items()
                   if isinstance(v, list) and len(v) > 1},
    'sample': {k: v[0] for k, v in h.SampleParameters.items()
               if isinstance(v, list) and len(v) > 1},
    'phases': [],
}
for i, name in enumerate(ACTIVE):
    p = project.phase(name); hap = p.data['Histograms'][h.name]
    summary['phases'].append({
        'name': name, 'cell': p.get_cell(), 'weight_fraction': masses[i] / sum(masses),
        'scale': hap['Scale'][0], 'size_um': hap['Size'][1][0],
        'microstrain_ppm': hap['Mustrain'][1][0],
        'atoms': [{'label': a.label, 'element': a.element,
                   'xyz': list(a.coordinates), 'Uiso': a.ADP}
                  for a in p.atoms()],
    })
print(json.dumps(summary, indent=2, default=float))
(ROOT / 'trials' / 'final_stage2.json').write_text(json.dumps(summary, indent=2, default=float) + '\n')
x, yobs, w, ycalc, ybkg, ydiff = [np.asarray(a, dtype=float) for a in h.data['data'][1][:6]]
np.savetxt(ROOT / 'trials' / 'final_stage2_profile.csv',
           np.column_stack([x, yobs, ycalc, ydiff, ybkg]), delimiter=',',
           header='two_theta_deg,observed,calculated,difference,background', comments='')
