from pathlib import Path
import json
import traceback
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'trials' / 'mnwo4_wo3_mno.gpx'
CANDIDATES = [
    ('Mn3WO6_C2c', ROOT / 'candidates' / 'Mn3WO6_C2c.cif'),
    ('Mn3WO6_R-3', ROOT / 'candidates' / 'Mn3WO6_R-3.cif'),
    ('Mn3WO6_P21c', ROOT / 'candidates' / 'Mn3WO6_P21c.cif'),
    ('Mn2WO6_P212121', ROOT / 'candidates' / 'Mn2WO6_P212121.cif'),
    ('Mn2WO6_P-31m', ROOT / 'candidates' / 'Mn2WO6_P-31m.cif'),
]

G2.SetPrintLevel('warn')

def freeze_shared(project):
    hist = project.histogram(0)
    hist.data['Background'][0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1:
            value[1] = False
    for phase in project.phases():
        phase.data['General']['Cell'][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = ' '
        hap = phase.data['Histograms'][hist.name]
        hap['Scale'][1] = False
        hap['Size'][2] = [False] * len(hap['Size'][2])
        hap['Mustrain'][2] = [False] * len(hap['Mustrain'][2])
        hap['Pref.Ori.'][2] = False
    return hist

results = []
for mode in ['replacement', 'addition']:
    for label, path in CANDIDATES:
        out = ROOT / 'trials' / f'analogue_{mode}_{label}.gpx'
        rec = {'mode': mode, 'label': label, 'cif': str(path)}
        try:
            project = G2.G2Project(gpxfile=str(BASE), newgpx=str(out))
            hist = freeze_shared(project)
            if mode == 'replacement':
                old = project.phase('MnO_wurtzite').data['Histograms'][hist.name]
                old['Scale'] = [0.0, False]
                old['Use'] = False
            phase = project.add_phase(str(path), phasename=label,
                                      histograms=[hist], fmthint='CIF')
            hap = phase.data['Histograms'][hist.name]
            hap['Scale'] = [5.0, True]
            hap['Size'][0] = 'isotropic'
            hap['Size'][1][0] = 0.08
            hap['Size'][2] = [False, False, False]
            hap['Mustrain'][0] = 'isotropic'
            hap['Mustrain'][1][0] = 4000.0
            hap['Mustrain'][2] = [False, False, False]
            project.set_Controls('cycles', 12)
            project.refine()
            rec['scale_wR_percent'] = project.histogram(0).get_wR()
            rec['scale_stage'] = project.phase(label).data['Histograms'][hist.name]['Scale'][0]

            project.phase(label).data['General']['Cell'][0] = True
            project.refine()
            hist = project.histogram(0)
            phase = project.phase(label)
            hap = phase.data['Histograms'][hist.name]
            rec.update(cell_wR_percent=hist.get_wR(), scale=hap['Scale'][0], cell=phase.get_cell())

            hap['Size'][2][0] = True
            hap['Mustrain'][2][0] = True
            project.refine()
            hist = project.histogram(0)
            phase = project.phase(label)
            hap = phase.data['Histograms'][hist.name]
            size, strain = hap['Size'][1][0], hap['Mustrain'][1][0]
            if not 0.04 <= size <= 1.5:
                hap['Size'][1][0] = min(1.5, max(0.04, size))
                hap['Size'][2][0] = False
            if not 300.0 <= strain <= 8000.0:
                hap['Mustrain'][1][0] = min(8000.0, max(300.0, strain))
                hap['Mustrain'][2][0] = False
            project.refine()
            hist = project.histogram(0)
            phase = project.phase(label)
            hap = phase.data['Histograms'][hist.name]
            masses = [p.data['General']['Mass'] * p.data['Histograms'][hist.name]['Scale'][0]
                      for p in project.phases()
                      if p.data['Histograms'][hist.name].get('Use', True)
                      and p.data['Histograms'][hist.name]['Scale'][0] > 0]
            rec.update(
                profile_wR_percent=hist.get_wR(),
                final_scale=hap['Scale'][0],
                size_um=hap['Size'][1][0],
                microstrain_ppm=hap['Mustrain'][1][0],
                candidate_weight_fraction=(hap['Scale'][0] * phase.data['General']['Mass'] / sum(masses)),
            )
            project.save()
        except Exception as exc:
            rec['error'] = str(exc)
            rec['traceback_tail'] = traceback.format_exc().splitlines()[-10:]
        results.append(rec)
        print(json.dumps(rec, default=float), flush=True)

(ROOT / 'trials' / 'analogue_common_trials.json').write_text(
    json.dumps(results, indent=2, default=float) + '\n')
