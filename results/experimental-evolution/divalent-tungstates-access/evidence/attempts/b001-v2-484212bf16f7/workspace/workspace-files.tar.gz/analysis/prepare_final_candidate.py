from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'trials' / 'final_wo3_parameters.gpx'
DST = ROOT / 'trials' / 'final_candidate_base.gpx'
ACTIVE = ['MnWO4_wolframite', 'Mn3WO6_R-3', 'WO3_P21c_physical']

G2.SetPrintLevel('warn')
project = G2.G2Project(gpxfile=str(SRC), newgpx=str(DST))
project.set_Controls('cycles', 18)
h = project.histogram(0)
for atom in project.phase('WO3_P21c_physical').atoms():
    atom.ADP = 0.0127
    atom.refinement_flags = ' '
h.data['Background'][0][1] = True
for value in h.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2: value[2] = False
h.InstrumentParameters['Zero'][2] = True
for value in h.SampleParameters.values():
    if isinstance(value, list) and len(value) > 1: value[1] = False
for p in project.phases():
    active = p.name in ACTIVE
    p.data['General']['Cell'][0] = active
    hap = p.data['Histograms'][h.name]
    hap['Scale'][1] = active
    hap['Size'][2] = [False] * len(hap['Size'][2])
    hap['Mustrain'][2] = [False] * len(hap['Mustrain'][2])
    hap['Pref.Ori.'][2] = False
    for atom in p.atoms(): atom.refinement_flags = ' '
    if not active: hap['Use'], hap['Scale'] = False, [0.0, False]
project.refine()
project.save(str(DST))
print(json.dumps({'wR_percent':project.histogram(0).get_wR()},indent=2))
