from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
src = ROOT / 'trials' / 'mnwo4_wo3.gpx'
dst = ROOT / 'trials' / 'common_base.gpx'
G2.SetPrintLevel('warn')
project = G2.G2Project(gpxfile=str(src), newgpx=str(dst))
hist = project.histogram(0)
inst = hist.InstrumentParameters

# Restore a physical common instrument profile. The previous unconstrained
# two-phase run attempted to mimic the missing phase with pathological phase
# widths; this state is used for fair addition tests instead.
for key, value in {'U': 10.0, 'V': 0.0, 'W': 10.0, 'X': 1.0,
                   'Y': 0.0, 'Z': 0.0, 'SH/L': 0.03}.items():
    inst[key][1] = value
for value in inst.values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
inst['Zero'][2] = True
hist.SampleParameters['Shift'][1] = True
hist.data['Background'][0][1] = True

for phase in project.phases():
    phase.data['General']['Cell'][0] = True
    hap = phase.data['Histograms'][hist.name]
    hap['Scale'][1] = True
    hap['Size'][0] = 'isotropic'
    hap['Size'][1][0] = 0.08
    hap['Size'][2] = [False, False, False]
    hap['Mustrain'][0] = 'isotropic'
    hap['Mustrain'][1][0] = 4000.0
    hap['Mustrain'][2] = [False, False, False]

project.set_Controls('cycles', 16)
project.refine()

# Freeze the shared state. Every ordinary candidate addition starts from this
# exact model and changes only that candidate's scale, cell, and width terms.
for value in hist.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for key, value in hist.SampleParameters.items():
    if isinstance(value, list) and len(value) > 1:
        value[1] = False
hist.data['Background'][0][1] = False
for phase in project.phases():
    phase.data['General']['Cell'][0] = False
    hap = phase.data['Histograms'][hist.name]
    hap['Scale'][1] = False
    hap['Size'][2] = [False, False, False]
    hap['Mustrain'][2] = [False, False, False]
project.save()

mass_scales = []
for phase in project.phases():
    hap = phase.data['Histograms'][hist.name]
    mass_scales.append(hap['Scale'][0] * phase.data['General']['Mass'])
summary = {
    'wR_percent': hist.get_wR(),
    'instrument': {k: v[1] for k, v in hist.InstrumentParameters.items()
                   if isinstance(v, list) and len(v) > 1},
    'shift_um': hist.SampleParameters['Shift'][0],
    'phases': [
        {'name': p.name, 'cell': p.get_cell(),
         'scale': p.data['Histograms'][hist.name]['Scale'][0],
         'weight_fraction': mass_scales[i] / sum(mass_scales)}
        for i, p in enumerate(project.phases())
    ],
}
print(json.dumps(summary, indent=2, default=float))
(ROOT / 'trials' / 'common_base.json').write_text(json.dumps(summary, indent=2, default=float) + '\n')
x, yobs, w, ycalc, ybkg, ydiff = [np.asarray(a, dtype=float) for a in hist.data['data'][1][:6]]
np.savetxt(ROOT / 'trials' / 'common_base_profile.csv',
           np.column_stack([x, yobs, ycalc, ydiff, ybkg]), delimiter=',',
           header='two_theta_deg,observed,calculated,difference,background', comments='')
