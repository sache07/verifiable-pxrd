from pathlib import Path
import json
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter

ROOT = Path(__file__).resolve().parent
CIFROOT = Path('<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06/cif')
OUT = ROOT / 'candidates'

MODELS = [
    # Distinct Mn3WO6 frameworks retained from the residual-directed search.
    dict(name='Mn3WO6_C2c', parent='2211529', mapping={'Zn': 'Mn', 'Te': 'W', 'O': 'O'}, scale=1.002,
         basis='Zn3TeO6 C2/c; two-element prototype transfer'),
    dict(name='Mn3WO6_R-3', parent='2211528', mapping={'Mn': 'Mn', 'Te': 'W', 'O': 'O'}, scale=0.994,
         basis='Mn3TeO6 R-3; Te-to-W prototype transfer'),
    dict(name='Mn3WO6_P21c', parent='1563081', mapping={'Ca': 'Mn', 'W': 'W', 'O': 'O'}, scale=1.094,
         basis='Ca3WO6 P21/c; Ca-to-Mn prototype transfer'),
    # Strongest distinct Mn2WO6 alternatives retained for common-state tests.
    dict(name='Mn2WO6_P212121', parent='1541070', mapping={'Y': 'Mn', 'W': 'W', 'O': 'O'}, scale=0.962,
         basis='Y2WO6 P212121; Y-to-Mn prototype transfer'),
    dict(name='Mn2WO6_P-31m', parent='4342220', mapping={'Sb': 'Mn', 'Mn': 'W', 'O': 'O'}, scale=0.956,
         basis='Mn(SbO3)2 P-31m; two-element role-substitution prototype transfer'),
]

def source_path(cod_id):
    return CIFROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'

def remap_structure(parent, mapping, scale):
    species = []
    for site in parent:
        mapped = {}
        for sp, occupancy in site.species.items():
            symbol = sp.symbol
            if symbol not in mapping:
                raise ValueError(f'No mapping for {symbol}')
            out = mapping[symbol]
            mapped[out] = mapped.get(out, 0.0) + float(occupancy)
        species.append(mapped)
    target = Structure(parent.lattice, species, parent.frac_coords,
                       coords_are_cartesian=False)
    target.scale_lattice(target.volume * scale ** 3)
    return target

records = []
for spec in MODELS:
    parent = Structure.from_file(source_path(spec['parent']))
    target = remap_structure(parent, spec['mapping'], spec['scale'])
    path = OUT / f"{spec['name']}.cif"
    CifWriter(target, symprec=1e-3, significant_figures=10,
              refine_struct=True).write_file(path)
    reread = Structure.from_file(path)
    record = {
        **spec,
        'cif': str(path.relative_to(ROOT.parent)),
        'target_formula': reread.composition.reduced_formula,
        'space_group': reread.get_space_group_info(),
        'cell': {
            'a': reread.lattice.a, 'b': reread.lattice.b, 'c': reread.lattice.c,
            'alpha': reread.lattice.alpha, 'beta': reread.lattice.beta,
            'gamma': reread.lattice.gamma, 'volume': reread.volume,
        },
    }
    records.append(record)
    print(json.dumps(record, default=float))

(OUT / 'provenance.json').write_text(json.dumps(records, indent=2, default=float) + '\n')
