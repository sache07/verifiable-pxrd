from pathlib import Path
import json
import traceback
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'trials' / 'final_candidate_base.gpx'
ACTIVE = ['MnWO4_wolframite', 'Mn3WO6_R-3', 'WO3_P21c_physical']
TRIALS = [
    ('polarization', True, False),
    ('surface_roughness', False, True),
    ('polarization_surface', True, True),
]

G2.SetPrintLevel('warn')
results=[]
for label, use_pol, use_surface in TRIALS:
    rec={'label':label}
    out=ROOT/'trials'/f'nuisance_{label}.gpx'
    try:
        project=G2.G2Project(gpxfile=str(BASE),newgpx=str(out));project.set_Controls('cycles',18)
        h=project.histogram(0)
        h.data['Background'][0][1]=True
        for value in h.InstrumentParameters.values():
            if isinstance(value,list) and len(value)>2:value[2]=False
        h.InstrumentParameters['Polariz.'][2]=use_pol
        for value in h.SampleParameters.values():
            if isinstance(value,list) and len(value)>1:value[1]=False
        if use_surface:
            h.SampleParameters['SurfRoughA']=[0.2,True]
            h.SampleParameters['SurfRoughB']=[0.1,True]
        for p in project.phases():
            hap=p.data['Histograms'][h.name];active=p.name in ACTIVE
            p.data['General']['Cell'][0]=False
            hap['Scale'][1]=active
            hap['Size'][2]=[False]*len(hap['Size'][2]);hap['Mustrain'][2]=[False]*len(hap['Mustrain'][2]);hap['Pref.Ori.'][2]=False
            for atom in p.atoms():atom.refinement_flags=' '
        project.refine();h=project.histogram(0)
        rec.update(wR_percent=h.get_wR(),polarization=h.InstrumentParameters['Polariz.'][1],
                   surf_rough_A=h.SampleParameters['SurfRoughA'][0],surf_rough_B=h.SampleParameters['SurfRoughB'][0])
        project.save()
    except Exception as exc:
        rec['error']=str(exc);rec['traceback_tail']=traceback.format_exc().splitlines()[-8:]
    results.append(rec);print(json.dumps(rec),flush=True)
(ROOT/'trials'/'nuisance_trials.json').write_text(json.dumps(results,indent=2)+'\n')
