from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
CIFROOT = Path('<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06/cif')

def cif(cod_id):
    return CIFROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'

G2.SetPrintLevel('warn')
project = G2.G2Project(newgpx=str(ROOT / 'trials' / 'mnwo4_wo3.gpx'))
phases = [
    project.add_phase(str(cif('1520200')), phasename='MnWO4_wolframite', fmthint='CIF'),
    project.add_phase(str(cif('1528915')), phasename='WO3_monoclinic', fmthint='CIF'),
]
hist = project.add_powder_histogram(
    str(ROOT / 'pattern.xye'), str(ROOT / 'instrument.instprm'),
    phases=phases, fmthint='xye')
hist.SampleParameters['Type'] = 'Bragg-Brentano'
hist.SampleParameters['Gonio. radius'] = 200.0
hist.SampleParameters['Shift'] = [0.0, False]
hist.SampleParameters['Transparency'] = [0.0, False]
hist.SampleParameters['SurfRoughA'] = [0.0, False]
hist.SampleParameters['SurfRoughB'] = [0.0, False]
hist.SampleParameters['Scale'] = [1.0, False]
hist.set_refinements({
    'Limits': [float(hist.data['data'][1][0][0]), float(hist.data['data'][1][0][-1])],
    'Background': {
        'type': 'chebyschev-1', 'no. coeffs': 12,
        'coeffs': [1500.0, -150.0] + [0.0] * 10,
        'refine': True,
    },
})
for phase in phases:
    phase.set_HAP_refinements({'Scale': True})
project.set_Controls('cycles', 12)

records = []
def run(label):
    project.refine()
    h = project.histogram(0)
    rec = {
        'stage': label,
        'wR_percent': h.get_wR(),
        'instrument': {k: v[1] for k, v in h.InstrumentParameters.items()
                       if isinstance(v, list) and len(v) > 1},
        'sample': {k: v[0] for k, v in h.SampleParameters.items()
                   if isinstance(v, list) and len(v) > 1},
        'phases': [],
    }
    for p in project.phases():
        hap = p.data['Histograms'][h.name]
        rec['phases'].append({
            'name': p.name, 'cell': p.get_cell(), 'scale': hap['Scale'][0],
            'mass_scale': hap['Scale'][0] * p.data['General']['Mass'],
            'size': hap['Size'], 'mustrain': hap['Mustrain'],
        })
    records.append(rec)
    print(json.dumps(rec, default=float))

hist.set_refinements({'Instrument Parameters': ['Zero']})
run('background_scales_zero')
for p in project.phases():
    p.set_refinements({'Cell': True})
run('cells')
# Separate the common angular zero from specimen displacement using their
# different angular dependences.
hist.set_refinements({'Sample Parameters': ['Shift']})
run('zero_and_displacement')
# Keep the instrumental Gaussian terms in the calibrated-lab range initially;
# phase-specific broadening is introduced before freeing the common profile.
for p, size, strain in zip(project.phases(), [0.35, 0.8], [2500.0, 800.0]):
    p.set_HAP_refinements({
        'Size': {'type': 'isotropic', 'value': size, 'refine': True},
        'Mustrain': {'type': 'isotropic', 'refine': True},
    })
    p.data['Histograms'][project.histogram(0).name]['Mustrain'][1][0] = strain
run('phase_broadening')
hist.set_refinements({'Instrument Parameters': ['U', 'W', 'X', 'SH/L']})
run('common_profile')
project.save()

h = project.histogram(0)
x, yobs, w, ycalc, ybkg, ydiff = [np.asarray(a, dtype=float) for a in h.data['data'][1][:6]]
np.savetxt(ROOT / 'trials' / 'mnwo4_wo3_profile.csv',
           np.column_stack([x, yobs, ycalc, ydiff, ybkg]), delimiter=',',
           header='two_theta_deg,observed,calculated,difference,background', comments='')
(ROOT / 'trials' / 'mnwo4_wo3.json').write_text(json.dumps(records, indent=2, default=float) + '\n')
