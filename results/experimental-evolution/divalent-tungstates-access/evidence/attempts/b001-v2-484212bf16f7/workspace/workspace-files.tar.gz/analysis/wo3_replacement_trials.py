from pathlib import Path
import json
import traceback
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
CIFROOT = Path('<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06/cif')
BASE = ROOT / 'trials' / 'final_stage2.gpx'
CANDIDATES = [
    ('WO3_P21c_physical', '2311041'),
    ('WO3_P-1_physical', '2106293'),
    ('WO3_P21c_alt', '1563541'),
]

def cif(cod_id):
    return CIFROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'

def freeze(project):
    h = project.histogram(0)
    h.data['Background'][0][1] = False
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2: value[2] = False
    for value in h.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1: value[1] = False
    for p in project.phases():
        p.data['General']['Cell'][0] = False
        for atom in p.atoms(): atom.refinement_flags = ' '
        hap = p.data['Histograms'][h.name]
        hap['Scale'][1] = False
        hap['Size'][2] = [False] * len(hap['Size'][2])
        hap['Mustrain'][2] = [False] * len(hap['Mustrain'][2])
        hap['Pref.Ori.'][2] = False
    return h

G2.SetPrintLevel('warn')
results = []
for label, cod_id in CANDIDATES:
    rec = {'label': label, 'cod_id': cod_id}
    out = ROOT / 'trials' / f'wo3_replacement_{cod_id}.gpx'
    try:
        project = G2.G2Project(gpxfile=str(BASE), newgpx=str(out))
        project.set_Controls('cycles', 16)
        h = freeze(project)
        old = project.phase('WO3_monoclinic').data['Histograms'][h.name]
        old['Use'], old['Scale'] = False, [0.0, False]
        p = project.add_phase(str(cif(cod_id)), phasename=label,
                              histograms=[h], fmthint='CIF')
        for atom in p.atoms():
            atom.data[atom.cia] = 'I'
            atom.data[atom.cia + 1] = 0.0127
            atom.refinement_flags = ' '
        hap = p.data['Histograms'][h.name]
        hap['Scale'] = [17.3, True]
        hap['Size'][0] = 'isotropic'
        hap['Size'][1][0] = 0.05
        hap['Size'][2] = [False, False, False]
        hap['Mustrain'][0] = 'isotropic'
        hap['Mustrain'][1][0] = 2900.0
        hap['Mustrain'][2] = [False, False, False]
        project.refine()
        rec['scale_wR_percent'] = project.histogram(0).get_wR()
        project.phase(label).data['General']['Cell'][0] = True
        project.refine()
        rec['cell_wR_percent'] = project.histogram(0).get_wR()
        p = project.phase(label); hap = p.data['Histograms'][project.histogram(0).name]
        hap['Size'][2][0] = True; hap['Mustrain'][2][0] = True
        project.refine()
        p = project.phase(label); hap = p.data['Histograms'][project.histogram(0).name]
        rec.update(profile_wR_percent=project.histogram(0).get_wR(), scale=hap['Scale'][0],
                   cell=p.get_cell(), size_um=hap['Size'][1][0],
                   microstrain_ppm=hap['Mustrain'][1][0])
        project.save()
    except Exception as exc:
        rec['error'] = str(exc)
        rec['traceback_tail'] = traceback.format_exc().splitlines()[-10:]
    results.append(rec)
    print(json.dumps(rec, default=float), flush=True)

(ROOT / 'trials' / 'wo3_replacement_trials.json').write_text(
    json.dumps(results, indent=2, default=float) + '\n')
