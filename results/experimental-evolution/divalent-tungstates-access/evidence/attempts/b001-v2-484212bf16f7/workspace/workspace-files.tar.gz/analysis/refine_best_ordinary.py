from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'trials' / 'wo3_replacement_2311041.gpx'
DST = ROOT / 'trials' / 'final_ordinary.gpx'
ACTIVE = ['MnWO4_wolframite', 'Mn3WO6_R-3', 'WO3_P21c_physical']

G2.SetPrintLevel('warn')
project = G2.G2Project(gpxfile=str(SRC), newgpx=str(DST))
project.set_Controls('cycles', 20)
h = project.histogram(0)
h.data['Background'][0][1] = True
for value in h.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2: value[2] = False
h.InstrumentParameters['Zero'][2] = True
for value in h.SampleParameters.values():
    if isinstance(value, list) and len(value) > 1: value[1] = False
for p in project.phases():
    active = p.name in ACTIVE
    p.data['General']['Cell'][0] = active
    for atom in p.atoms(): atom.refinement_flags = ' '
    hap = p.data['Histograms'][h.name]
    hap['Scale'][1] = active
    hap['Size'][2] = [False] * len(hap['Size'][2])
    hap['Mustrain'][2] = [False] * len(hap['Mustrain'][2])
    hap['Pref.Ori.'][2] = False
    if not active:
        hap['Use'], hap['Scale'] = False, [0.0, False]
project.refine()
project.save(str(DST))

h = project.histogram(0)
masses = [project.phase(n).data['General']['Mass'] *
          project.phase(n).data['Histograms'][h.name]['Scale'][0] for n in ACTIVE]
summary = {'wR_percent': h.get_wR(), 'phases': [],
           'instrument': {k:v[1] for k,v in h.InstrumentParameters.items()
                          if isinstance(v,list) and len(v)>1},
           'sample': {k:v[0] for k,v in h.SampleParameters.items()
                      if isinstance(v,list) and len(v)>1}}
for i,n in enumerate(ACTIVE):
    p=project.phase(n);hap=p.data['Histograms'][h.name]
    summary['phases'].append({'name':n,'weight_fraction':masses[i]/sum(masses),
        'cell':p.get_cell(),'scale':hap['Scale'][0],'size_um':hap['Size'][1][0],
        'microstrain_ppm':hap['Mustrain'][1][0]})
print(json.dumps(summary,indent=2,default=float))
(ROOT/'trials'/'final_ordinary.json').write_text(json.dumps(summary,indent=2,default=float)+'\n')
x,yo,w,yc,yb,yd=[np.asarray(v,float) for v in h.data['data'][1][:6]]
np.savetxt(ROOT/'trials'/'final_ordinary_profile.csv',np.column_stack([x,yo,yc,yd,yb]),
           delimiter=',',header='two_theta_deg,observed,calculated,difference,background',comments='')
