from pathlib import Path
import json
import math
import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'trials' / 'analogue_replacement_Mn3WO6_R-3.gpx'
DST = ROOT / 'trials' / 'final_stage1.gpx'
LOG = ROOT / 'trials' / 'final_stage1.json'
ACTIVE = ['MnWO4_wolframite', 'WO3_monoclinic', 'Mn3WO6_R-3']

G2.SetPrintLevel('warn')
project = G2.G2Project(gpxfile=str(SRC), newgpx=str(DST))
project.set_Controls('cycles', 18)
records = []

def hist():
    return project.histogram(0)

def freeze_all():
    h = hist()
    h.data['Background'][0][1] = False
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in h.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1:
            value[1] = False
    for p in project.phases():
        p.data['General']['Cell'][0] = False
        for atom in p.atoms():
            atom.refinement_flags = ' '
        hap = p.data['Histograms'][h.name]
        hap['Scale'][1] = False
        hap['Size'][2] = [False] * len(hap['Size'][2])
        hap['Mustrain'][2] = [False] * len(hap['Mustrain'][2])
        hap['Pref.Ori.'][2] = False

def active_phases():
    return [project.phase(n) for n in ACTIVE]

def snapshot(stage, accepted=True, note=None):
    h = hist()
    phases = []
    masses = [p.data['General']['Mass'] * p.data['Histograms'][h.name]['Scale'][0]
              for p in active_phases()]
    for i, p in enumerate(active_phases()):
        hap = p.data['Histograms'][h.name]
        phases.append({
            'name': p.name, 'cell': p.get_cell(), 'scale': hap['Scale'][0],
            'weight_fraction': masses[i] / sum(masses),
            'size_um': hap['Size'][1][0],
            'microstrain_ppm': hap['Mustrain'][1][0],
            'preferred_orientation': hap['Pref.Ori.'][:4],
            'atoms': [
                {'label': a.label, 'element': a.element,
                 'xyz': list(a.coordinates), 'adp_flag': a.adp_flag,
                 'adp': a.ADP, 'flags': a.refinement_flags}
                for a in p.atoms()
            ],
        })
    rec = {
        'stage': stage, 'accepted': accepted, 'note': note,
        'wR_percent': h.get_wR(),
        'instrument': {k: v[1] for k, v in h.InstrumentParameters.items()
                       if isinstance(v, list) and len(v) > 1},
        'sample': {k: v[0] for k, v in h.SampleParameters.items()
                   if isinstance(v, list) and len(v) > 1},
        'background': list(h.data['Background'][0]),
        'phases': phases,
    }
    records.append(rec)
    print(json.dumps({k: v for k, v in rec.items() if k not in ['phases', 'background']}, default=float), flush=True)
    return rec

def save_checkpoint(name):
    path = ROOT / 'trials' / f'checkpoint_{name}.gpx'
    project.save(str(path))
    return path

def restore(path):
    global project
    project = G2.G2Project(gpxfile=str(path), newgpx=str(DST))
    project.set_Controls('cycles', 18)

freeze_all()
h = hist()
# Keep the rejected MnO trial explicitly inactive.
old = project.phase('MnO_wurtzite').data['Histograms'][h.name]
old['Use'], old['Scale'] = False, [0.0, False]

# The generator uses one isotropic Uiso for every atom in a phase. Normalize
# raw-COD anisotropic/zero ADPs to a common physical starting value.
for p in active_phases():
    for atom in p.atoms():
        atom.data[atom.cia] = 'I'
        atom.data[atom.cia + 1] = 0.01
        atom.refinement_flags = ' '

# Resolve the near-singular zero/displacement pair inside the stated specimen
# range. At -800 um, a zero near -0.07 deg preserves the observed net shift.
h.SampleParameters['Shift'] = [-800.0, False]
h.InstrumentParameters['Zero'][1] = -0.07
h.InstrumentParameters['Zero'][2] = True
h.data['Background'][0][1] = True
for p in active_phases():
    p.data['General']['Cell'][0] = True
    p.data['Histograms'][h.name]['Scale'][1] = True
project.refine()
snapshot('ordinary_cells_scales_background')

# Determine the common instrumental width with all phase widths fixed.
pre = save_checkpoint('before_instrument')
h = hist()
for key in ['U', 'W', 'X', 'SH/L']:
    h.InstrumentParameters[key][2] = True
project.refine()
h = hist()
inst = h.InstrumentParameters
valid_inst = (0 <= inst['U'][1] <= 40 and 2 <= inst['W'][1] <= 40 and
              0.1 <= inst['X'][1] <= 6 and 0.005 <= inst['SH/L'][1] <= 0.10)
if valid_inst:
    snapshot('common_instrument_profile')
else:
    bad = {k: inst[k][1] for k in ['U', 'W', 'X', 'SH/L']}
    snapshot('common_instrument_profile_rejected', False, f'outside lab range: {bad}')
    restore(pre)

# Freeze the accepted common profile, then recover each phase width.
h = hist()
for key in ['U', 'W', 'X', 'SH/L']:
    h.InstrumentParameters[key][2] = False
for name in ACTIVE:
    pre = save_checkpoint('before_profile_' + name.replace('/', '_'))
    p = project.phase(name)
    hap = p.data['Histograms'][hist().name]
    hap['Size'][2][0] = True
    hap['Mustrain'][2][0] = True
    before = hist().get_wR()
    project.refine()
    p = project.phase(name)
    hap = p.data['Histograms'][hist().name]
    size, strain = hap['Size'][1][0], hap['Mustrain'][1][0]
    valid = 0.04 <= size <= 1.5 and 0 <= strain <= 8000 and hist().get_wR() <= before + 1e-6
    if valid:
        hap['Size'][2][0] = False
        hap['Mustrain'][2][0] = False
        snapshot('isotropic_profile_' + name)
    else:
        bad = {'size_um': size, 'microstrain_ppm': strain, 'wR': hist().get_wR()}
        snapshot('isotropic_profile_rejected_' + name, False, str(bad))
        restore(pre)

# Symmetry-allowed coordinate recovery, one chemically coherent block at a time.
coordinate_blocks = [
    ('MnWO4_all', 'MnWO4_wolframite', {'Mn', 'W', 'O'}),
    ('WO3_W', 'WO3_monoclinic', {'W'}),
    ('WO3_O', 'WO3_monoclinic', {'O'}),
    ('Mn3WO6_Mn', 'Mn3WO6_R-3', {'Mn'}),
    ('Mn3WO6_O', 'Mn3WO6_R-3', {'O'}),
]
for label, phase_name, elements in coordinate_blocks:
    pre = save_checkpoint('before_coordinates_' + label)
    p = project.phase(phase_name)
    for atom in p.atoms():
        atom.refinement_flags = 'X' if atom.element in elements else ' '
    before = hist().get_wR()
    project.refine()
    if math.isfinite(hist().get_wR()) and hist().get_wR() <= before + 1e-6:
        for atom in project.phase(phase_name).atoms():
            atom.refinement_flags = ' '
        snapshot('coordinates_' + label)
    else:
        snapshot('coordinates_rejected_' + label, False, 'fit did not improve')
        restore(pre)

# Estimate each phase's common Uiso: refine individual isotropic values once,
# average them, enforce the generator's common-per-phase value, and refit scales.
for phase_name in ACTIVE:
    pre = save_checkpoint('before_uiso_' + phase_name)
    p = project.phase(phase_name)
    for atom in p.atoms():
        atom.refinement_flags = 'U'
    before = hist().get_wR()
    project.refine()
    values = [float(a.ADP) for a in project.phase(phase_name).atoms()]
    common = float(np.mean(values))
    valid = all(np.isfinite(values)) and 0.003 <= common <= 0.02
    if valid:
        for atom in project.phase(phase_name).atoms():
            atom.ADP = common
            atom.refinement_flags = ' '
        project.refine()
        valid = hist().get_wR() <= before + 0.05
    if valid:
        snapshot('common_uiso_' + phase_name, note=f'Uiso={common:.7g}')
    else:
        snapshot('common_uiso_rejected_' + phase_name, False,
                 f'individual={values}, mean={common}')
        restore(pre)

# Leave only defensible ordinary parameters flagged for a final convergence.
freeze_all()
h = hist()
h.data['Background'][0][1] = True
h.InstrumentParameters['Zero'][2] = True
for p in active_phases():
    p.data['General']['Cell'][0] = True
    p.data['Histograms'][h.name]['Scale'][1] = True
project.refine()
snapshot('stage1_converged')
project.save(str(DST))
LOG.write_text(json.dumps(records, indent=2, default=float) + '\n')

h = hist()
x, yobs, w, ycalc, ybkg, ydiff = [np.asarray(a, dtype=float) for a in h.data['data'][1][:6]]
np.savetxt(ROOT / 'trials' / 'final_stage1_profile.csv',
           np.column_stack([x, yobs, ycalc, ydiff, ybkg]), delimiter=',',
           header='two_theta_deg,observed,calculated,difference,background', comments='')
