"""Export the independently replayed GSAS-II profile in submission format."""

from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
with np.load(ROOT / "analysis/replay_final/prediction.npz", allow_pickle=False) as replay:
    x = replay["x"]
    observed = replay["observed"]
    calculated = replay["predicted"]
    background = replay["background"]

profile = np.column_stack(
    [x, observed, calculated, observed - calculated, background]
)
np.savetxt(
    ROOT / "fit.csv",
    profile,
    delimiter=",",
    header="two_theta,observed,calculated,difference,background",
    comments="",
    fmt=["%.8f", "%.8f", "%.8f", "%.8f", "%.8f"],
)
