from pathlib import Path
import json
import traceback
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
CIFROOT = Path('<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06/cif')
BASE = ROOT / 'trials' / 'common_base.gpx'

CANDIDATES = [
    ('MnO_rocksalt', '1514108'),
    ('MnO_wurtzite', '4117966'),
    ('Mn3O4_hausmannite', '9001963'),
    ('Mn3O4_Pbcm_a', '1541183'),
    ('Mn3O4_Pbcm_b', '9001302'),
    ('Mn2O3_bixbyite', '1514230'),
    ('Mn2O3_chiral_cubic', '1010586'),
    ('MnO2_rutile', '1514110'),
    ('MnO2_trigonal', '9009111'),
    ('W3O8', '2101050'),
    ('W18O49', '1528166'),
    ('W10O29', '1538317'),
]

def cif(cod_id):
    return CIFROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'

G2.SetPrintLevel('warn')
results = []
for label, cod_id in CANDIDATES:
    out = ROOT / 'trials' / f'ordinary_{cod_id}.gpx'
    rec = {'label': label, 'cod_id': cod_id}
    try:
        project = G2.G2Project(gpxfile=str(BASE), newgpx=str(out))
        hist = project.histogram(0)
        phase = project.add_phase(str(cif(cod_id)), phasename=label,
                                  histograms=[hist], fmthint='CIF')
        hap = phase.data['Histograms'][hist.name]
        hap['Scale'] = [2.0, True]
        hap['Size'][0] = 'isotropic'
        hap['Size'][1][0] = 0.08
        hap['Size'][2] = [False, False, False]
        hap['Mustrain'][0] = 'isotropic'
        hap['Mustrain'][1][0] = 4000.0
        hap['Mustrain'][2] = [False, False, False]
        project.set_Controls('cycles', 10)
        project.refine()
        rec['scale_only_wR_percent'] = project.histogram(0).get_wR()
        rec['scale_only_scale'] = project.phase(label).data['Histograms'][hist.name]['Scale'][0]

        project.phase(label).data['General']['Cell'][0] = True
        project.refine()
        hist = project.histogram(0)
        phase = project.phase(label)
        hap = phase.data['Histograms'][hist.name]
        masses = [p.data['General']['Mass'] * p.data['Histograms'][hist.name]['Scale'][0]
                  for p in project.phases()]
        rec.update(
            cell_wR_percent=hist.get_wR(),
            scale=hap['Scale'][0],
            cell=phase.get_cell(),
            starting_cell_volume=phase.data['General']['Cell'][7],
            candidate_weight_fraction=(masses[-1] / sum(masses)) if sum(masses) else None,
        )
        project.save()
    except Exception as exc:
        rec['error'] = str(exc)
        rec['traceback_tail'] = traceback.format_exc().splitlines()[-8:]
    results.append(rec)
    print(json.dumps(rec, default=float), flush=True)

(ROOT / 'trials' / 'ordinary_trials.json').write_text(json.dumps(results, indent=2, default=float) + '\n')
