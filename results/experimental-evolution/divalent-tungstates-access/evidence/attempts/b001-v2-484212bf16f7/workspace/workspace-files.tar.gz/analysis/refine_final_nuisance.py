from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT=Path(__file__).resolve().parent
SRC=ROOT/'trials'/'nuisance_polarization.gpx'
DST=ROOT/'trials'/'final_refined.gpx'
ACTIVE=['MnWO4_wolframite','Mn3WO6_R-3','WO3_P21c_physical']
STRAIN={
 'Mn3WO6_R-3':(648.929713360616,1257.8333957895584,[0,1,0]),
 'WO3_P21c_physical':(1304.5980997956437,2057.0151358575313,[0,1,0]),
}
G2.SetPrintLevel('warn')
project=G2.G2Project(gpxfile=str(SRC),newgpx=str(DST));project.set_Controls('cycles',20);h=project.histogram(0)
h.data['Background'][0][1]=True
for v in h.InstrumentParameters.values():
 if isinstance(v,list) and len(v)>2:v[2]=False
h.InstrumentParameters['Zero'][2]=True;h.InstrumentParameters['Polariz.'][2]=True
for v in h.SampleParameters.values():
 if isinstance(v,list) and len(v)>1:v[1]=False
h.SampleParameters['SurfRoughA']=[0.0,False];h.SampleParameters['SurfRoughB']=[0.0,False]
for p in project.phases():
 active=p.name in ACTIVE;p.data['General']['Cell'][0]=active
 for a in p.atoms():a.refinement_flags=' '
 hap=p.data['Histograms'][h.name];hap['Scale'][1]=active;hap['Size'][2]=[False]*len(hap['Size'][2]);hap['Mustrain'][2]=[False]*len(hap['Mustrain'][2]);hap['Pref.Ori.'][1]=1.0;hap['Pref.Ori.'][2]=False
 if p.name in STRAIN:
  eq,ax,direction=STRAIN[p.name];hap['Mustrain'][0]='uniaxial';hap['Mustrain'][1][0]=eq;hap['Mustrain'][1][1]=ax;hap['Mustrain'][2][0]=True;hap['Mustrain'][2][1]=True;hap['Mustrain'][3]=direction
 elif active:
  hap['Mustrain'][0]='isotropic';hap['Mustrain'][2][0]=True
 if not active:hap['Use'],hap['Scale']=False,[0.0,False]
project.refine()

# Freeze profile/polarization terms and perform a final ordinary convergence.
h=project.histogram(0);h.InstrumentParameters['Polariz.'][2]=False
for p in [project.phase(n) for n in ACTIVE]:
 hap=p.data['Histograms'][h.name];hap['Mustrain'][2]=[False]*len(hap['Mustrain'][2]);hap['Size'][2]=[False]*len(hap['Size'][2])
project.refine();project.save(str(DST));h=project.histogram(0)
masses=[project.phase(n).data['General']['Mass']*project.phase(n).data['Histograms'][h.name]['Scale'][0] for n in ACTIVE]
summary={'wR_percent':h.get_wR(),'instrument':{k:v[1] for k,v in h.InstrumentParameters.items() if isinstance(v,list) and len(v)>1},'sample':{k:v[0] for k,v in h.SampleParameters.items() if isinstance(v,list) and len(v)>1},'phases':[]}
for i,n in enumerate(ACTIVE):
 p=project.phase(n);hap=p.data['Histograms'][h.name]
 summary['phases'].append({'name':n,'weight_fraction':masses[i]/sum(masses),'cell':p.get_cell(),'scale':hap['Scale'][0],'size_um':hap['Size'][1][0],'microstrain_model':hap['Mustrain'][0],'microstrain_values':hap['Mustrain'][1][:2],'microstrain_axis':hap['Mustrain'][3],'preferred_orientation':hap['Pref.Ori.'][:4]})
print(json.dumps(summary,indent=2,default=float));(ROOT/'trials'/'final_refined.json').write_text(json.dumps(summary,indent=2,default=float)+'\n')
x,yo,w,yc,yb,yd=[np.asarray(v,float) for v in h.data['data'][1][:6]]
np.savetxt(ROOT/'trials'/'final_refined_profile.csv',np.column_stack([x,yo,yc,yd,yb]),delimiter=',',header='two_theta_deg,observed,calculated,difference,background',comments='')
