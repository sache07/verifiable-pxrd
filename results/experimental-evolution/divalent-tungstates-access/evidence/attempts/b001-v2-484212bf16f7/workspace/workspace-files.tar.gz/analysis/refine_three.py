from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
src = ROOT / 'trials' / 'ordinary_4117966.gpx'
dst = ROOT / 'trials' / 'mnwo4_wo3_mno.gpx'
G2.SetPrintLevel('warn')
project = G2.G2Project(gpxfile=str(src), newgpx=str(dst))
hist = project.histogram(0)
project.set_Controls('cycles', 16)

records = []
def snapshot(label):
    h = project.histogram(0)
    masses = [p.data['General']['Mass'] * p.data['Histograms'][h.name]['Scale'][0]
              for p in project.phases()]
    rec = {
        'stage': label, 'wR_percent': h.get_wR(),
        'zero': h.InstrumentParameters['Zero'][1],
        'shift_um': h.SampleParameters['Shift'][0],
        'phases': [],
    }
    for i, p in enumerate(project.phases()):
        hap = p.data['Histograms'][h.name]
        rec['phases'].append({
            'name': p.name, 'cell': p.get_cell(), 'scale': hap['Scale'][0],
            'weight_fraction': masses[i] / sum(masses),
            'size_um': hap['Size'][1][0],
            'microstrain_ppm': hap['Mustrain'][1][0],
        })
    records.append(rec)
    print(json.dumps(rec, default=float), flush=True)

# Resume ordinary refinement from the successful common-state addition.
hist.data['Background'][0][1] = True
hist.InstrumentParameters['Zero'][2] = True
hist.SampleParameters['Shift'][1] = True
for p in project.phases():
    p.data['General']['Cell'][0] = True
    hap = p.data['Histograms'][hist.name]
    hap['Scale'][1] = True
    hap['Size'][0] = 'isotropic'
    hap['Size'][1][0] = 0.08
    hap['Size'][2] = [False, False, False]
    hap['Mustrain'][0] = 'isotropic'
    hap['Mustrain'][1][0] = 4000.0
    hap['Mustrain'][2] = [False, False, False]
project.refine()
snapshot('all_scales_cells')

# Refine each phase width in the same complete model. Clamp to the laboratory's
# physically generated range if an unconstrained step attempts to leave it.
for p in project.phases():
    hap = p.data['Histograms'][project.histogram(0).name]
    hap['Size'][2][0] = True
    hap['Mustrain'][2][0] = True
    project.refine()
    hap = project.phase(p.name).data['Histograms'][project.histogram(0).name]
    size = hap['Size'][1][0]
    strain = hap['Mustrain'][1][0]
    if not 0.04 <= size <= 1.5:
        hap['Size'][1][0] = min(1.5, max(0.04, size))
        hap['Size'][2][0] = False
    if not 300.0 <= strain <= 8000.0:
        hap['Mustrain'][1][0] = min(8000.0, max(300.0, strain))
        hap['Mustrain'][2][0] = False
    project.refine()
    snapshot(f'profile_{p.name}')

project.save()
(ROOT / 'trials' / 'mnwo4_wo3_mno.json').write_text(json.dumps(records, indent=2, default=float) + '\n')
h = project.histogram(0)
x, yobs, w, ycalc, ybkg, ydiff = [np.asarray(a, dtype=float) for a in h.data['data'][1][:6]]
np.savetxt(ROOT / 'trials' / 'mnwo4_wo3_mno_profile.csv',
           np.column_stack([x, yobs, ycalc, ydiff, ybkg]), delimiter=',',
           header='two_theta_deg,observed,calculated,difference,background', comments='')
