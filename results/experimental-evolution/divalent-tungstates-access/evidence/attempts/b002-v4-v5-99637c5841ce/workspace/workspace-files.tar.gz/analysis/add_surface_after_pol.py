#!/usr/bin/env python3
"""Test surface roughness after accepting the bounded polarization term."""

import os

from GSASII import GSASIIscriptable as G2sc


outdir = "analysis/branches/pol_then_surface"
os.makedirs(outdir, exist_ok=True)
G2sc.SetPrintLevel("warn")
gpx = G2sc.G2Project(gpxfile="analysis/branches/specimen_pol/fit.gpx")
gpx.set_Frozen()
gpx.set_Controls("cycles", 20)
gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
hist = gpx.histogram(0)
hist.SampleParameters["SurfRoughA"] = [0.20, True]
hist.SampleParameters["SurfRoughB"] = [0.10, True]
for var, lo, hi in (
    (":0:SurfRoughA", 0.05, 0.60),
    (":0:SurfRoughB", 0.02, 0.50),
):
    gpx.set_Controls("parmMin", lo, var)
    gpx.set_Controls("parmMax", hi, var)
gpx.save(os.path.join(outdir, "fit.gpx"))
gpx.do_refinements([{}])
frozen = gpx.get_Frozen()
if ":0:SurfRoughA" in frozen or ":0:SurfRoughB" in frozen:
    if ":0:SurfRoughA" in frozen:
        hist.SampleParameters["SurfRoughA"][1] = False
    if ":0:SurfRoughB" in frozen:
        hist.SampleParameters["SurfRoughB"][1] = False
    gpx.set_Frozen()
    gpx.do_refinements([{}])
print(
    "Rwp", hist.get_wR(),
    "surface", hist.SampleParameters["SurfRoughA"], hist.SampleParameters["SurfRoughB"],
    "polarization", hist.InstrumentParameters["Polariz."],
    "MD", gpx.phase(0).getHAPvalues(hist)["Pref.Ori."],
)
gpx.save(os.path.join(outdir, "fit.gpx"))
