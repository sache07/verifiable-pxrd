#!/usr/bin/env python3
"""Test whether the minor WO3 phase supports bounded oxygen coordinates."""

import os

from GSASII import GSASIIscriptable as G2sc


SOURCE = "analysis/checkpoints/physical_wo3/final_candidate/fit.gpx"
OUTDIR = "analysis/branches/physical_wo3_oxygen"
OUT = os.path.join(OUTDIR, "fit.gpx")


def main():
    os.makedirs(OUTDIR, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    gpx = G2sc.G2Project(gpxfile=SOURCE)
    gpx.set_Controls("cycles", 35)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = gpx.histogram(0)
    phase = gpx.phase("WO3_monoclinic_physical")
    bound = 0.008
    for index, atom in enumerate(phase.atoms()):
        if atom.element != "O":
            continue
        atom.refinement_flags = "X"
        for axis, coordinate in zip("xyz", atom.coordinates):
            var = f"{phase.id}::dA{axis}:{index}"
            gpx.set_Controls("parmMin", coordinate - bound, var)
            gpx.set_Controls("parmMax", coordinate + bound, var)
    gpx.save(OUT)
    gpx.set_Frozen()
    gpx.do_refinements([{}])
    rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
    print(
        "Rwp", hist.get_wR(),
        "GOF", rvals.get("GOF"),
        "converged", rvals.get("converged"),
        "max_shift_sigma", rvals.get("Max shft/sig"),
        "frozen", gpx.get_Frozen(),
        "fractions", hist.ComputeMassFracs(),
        flush=True,
    )
    print(
        [(a.label, a.refinement_flags, a.coordinates) for a in phase.atoms()],
        flush=True,
    )
    for item in gpx.phases():
        item.export_CIF(os.path.join(OUTDIR, item.name + ".cif"))
    gpx.save(OUT)


if __name__ == "__main__":
    main()
