#!/usr/bin/env python3
"""Retest ZnO texture after the physical WO3 model is fixed."""

import os

from GSASII import GSASIIscriptable as G2sc


SOURCE = "analysis/checkpoints/physical_wo3/final_candidate/fit.gpx"
ROOT = "analysis/branches/zno_texture_final"


def trial(axis):
    tag = "".join(map(str, axis))
    outdir = os.path.join(ROOT, tag)
    os.makedirs(outdir, exist_ok=True)
    outpath = os.path.join(outdir, "fit.gpx")
    gpx = G2sc.G2Project(gpxfile=SOURCE)
    gpx.set_Controls("cycles", 35)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = gpx.histogram(0)
    phase = gpx.phase("ZnO")
    pref = phase.getHAPvalues(hist)["Pref.Ori."]
    pref[0], pref[1], pref[2], pref[3] = "MD", 1.0, True, list(axis)
    var = f"{phase.id}:{hist.id}:MD"
    gpx.set_Controls("parmMin", 0.70, var)
    gpx.set_Controls("parmMax", 1.40, var)
    gpx.save(outpath)
    gpx.set_Frozen()
    gpx.do_refinements([{}])
    rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
    print(
        tag,
        "Rwp", hist.get_wR(),
        "GOF", rvals.get("GOF"),
        "MD", phase.getHAPvalues(hist)["Pref.Ori."][1],
        "size", phase.getHAPvalues(hist)["Size"][1][0],
        "converged", rvals.get("converged"),
        "max_shift_sigma", rvals.get("Max shft/sig"),
        "frozen", gpx.get_Frozen(),
        "fractions", hist.ComputeMassFracs(),
        flush=True,
    )
    gpx.save(outpath)


def main():
    G2sc.SetPrintLevel("warn")
    for axis in ([0, 0, 1], [1, 0, 0], [1, 1, 0]):
        trial(axis)


if __name__ == "__main__":
    main()
