#!/usr/bin/env python3
"""Rebuild the last stages from a checkpoint untouched by O-coordinate tests."""

import os

from GSASII import GSASIIscriptable as G2sc


SOURCE = "analysis/branches/main_microstrain_physical_wo3/001/fit.gpx"
OUTDIR = "analysis/checkpoints/clean_complete"
MAIN = os.path.join(OUTDIR, "main_converged.gpx")
TEXTURE = os.path.join(OUTDIR, "zno_001.gpx")


def show(gpx, label):
    hist = gpx.histogram(0)
    rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
    print(
        label,
        "Rwp", hist.get_wR(),
        "GOF", rvals.get("GOF"),
        "converged", rvals.get("converged"),
        "max_shift_sigma", rvals.get("Max shft/sig"),
        "frozen", gpx.get_Frozen(),
        "fractions", hist.ComputeMassFracs(),
        flush=True,
    )
    print(
        "WO3 atoms",
        [(a.label, a.refinement_flags, a.coordinates) for a in gpx.phase(2).atoms()],
        flush=True,
    )


def main():
    os.makedirs(OUTDIR, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    gpx = G2sc.G2Project(gpxfile=SOURCE)

    # Establish a unique autosave target before changing any project setting.
    gpx.save(MAIN)
    gpx.set_Controls("cycles", 50)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    gpx.set_Frozen()
    gpx.do_refinements([{}])
    gpx.save(MAIN)
    show(gpx, "clean main")

    # Start a separate checkpoint before adding the ZnO texture variable.
    gpx.save(TEXTURE)
    hist = gpx.histogram(0)
    zno = gpx.phase("ZnO")
    pref = zno.getHAPvalues(hist)["Pref.Ori."]
    pref[0], pref[1], pref[2], pref[3] = "MD", 1.0, True, [0, 0, 1]
    var = f"{zno.id}:{hist.id}:MD"
    gpx.set_Controls("parmMin", 0.70, var)
    gpx.set_Controls("parmMax", 1.40, var)
    gpx.set_Frozen()
    gpx.do_refinements([{}])
    gpx.save(TEXTURE)
    show(gpx, "clean ZnO [001]")
    print("ZnO PO", zno.getHAPvalues(hist)["Pref.Ori."], flush=True)


if __name__ == "__main__":
    main()
