#!/usr/bin/env python3
"""Converge the selected [110] gamma-WO3 texture branch."""

import os

from GSASII import GSASIIscriptable as G2sc


SOURCE = "analysis/branches/physical_wo3_texture/110/fit.gpx"
OUTDIR = "analysis/checkpoints/physical_wo3/texture_110"
OUT = os.path.join(OUTDIR, "fit.gpx")


def main():
    os.makedirs(OUTDIR, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    gpx = G2sc.G2Project(gpxfile=SOURCE)
    gpx.set_Controls("cycles", 50)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    gpx.save(OUT)
    gpx.set_Frozen()
    gpx.do_refinements([{}])
    hist = gpx.histogram(0)
    phase = gpx.phase("WO3_monoclinic_physical")
    rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
    print(
        "Rwp", hist.get_wR(),
        "GOF", rvals.get("GOF"),
        "MD", phase.getHAPvalues(hist)["Pref.Ori."][1],
        "converged", rvals.get("converged"),
        "max_shift_sigma", rvals.get("Max shft/sig"),
        "frozen", gpx.get_Frozen(),
        "fractions", hist.ComputeMassFracs(),
        flush=True,
    )
    gpx.save(OUT)


if __name__ == "__main__":
    main()
