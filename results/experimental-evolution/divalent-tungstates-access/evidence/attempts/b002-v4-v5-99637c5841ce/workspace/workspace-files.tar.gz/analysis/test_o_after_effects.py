#!/usr/bin/env python3
"""Test oxygen-coordinate subsets after intensity corrections are fixed."""

import argparse
import os

from GSASII import GSASIIscriptable as G2sc


ap = argparse.ArgumentParser()
ap.add_argument("subset", choices=("O1", "O2", "both"))
args = ap.parse_args()
outdir = f"analysis/branches/o_after_{args.subset}"
os.makedirs(outdir, exist_ok=True)
G2sc.SetPrintLevel("warn")
gpx = G2sc.G2Project(gpxfile="analysis/branches/uiso_0p009/fit.gpx")
gpx.set_Frozen()
gpx.set_Controls("cycles", 20)
gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
phase = gpx.phase(0)
targets = {"O1": "X"} if args.subset == "O1" else {"O2": "X"}
if args.subset == "both":
    targets = {"O1": "X", "O2": "X"}
phase.set_refinements({"Atoms": targets})
gpx.save(os.path.join(outdir, "fit.gpx"))
gpx.do_refinements([{}])
print(
    "subset", args.subset,
    "Rwp", gpx.histogram(0).get_wR(),
    "atoms", [(a.label, a.coordinates) for a in phase.atoms()],
    "converged", gpx.data["Covariance"]["data"].get("Rvals", {}).get("converged"),
)
gpx.save(os.path.join(outdir, "fit.gpx"))
phase.export_CIF(os.path.join(outdir, "fit.cif"))
