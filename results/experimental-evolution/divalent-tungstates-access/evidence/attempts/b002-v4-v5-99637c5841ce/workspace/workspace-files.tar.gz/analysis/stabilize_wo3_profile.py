#!/usr/bin/env python3
"""Resolve the correlated WO3 size/strain pair in the texture candidate."""

import os

from GSASII import GSASIIscriptable as G2sc


SOURCE = "analysis/checkpoints/inventory_refined/wo3_texture_111/refined.gpx"
ROOT = "analysis/checkpoints/inventory_refined/wo3_profile"


def trial(fixed_term):
    outdir = os.path.join(ROOT, "fixed_" + fixed_term.lower())
    os.makedirs(outdir, exist_ok=True)
    outpath = os.path.join(outdir, "fit.gpx")
    gpx = G2sc.G2Project(gpxfile=SOURCE)
    gpx.set_Controls("cycles", 30)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = gpx.histogram(0)
    phase = gpx.phase("WO3_monoclinic")
    if fixed_term == "Size":
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": False}}, [hist]
        )
    else:
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": False}}, [hist]
        )
    gpx.save(outpath)
    gpx.set_Frozen()
    gpx.do_refinements([{}])
    rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
    print(
        "fixed", fixed_term,
        "Rwp", hist.get_wR(),
        "GOF", rvals.get("GOF"),
        "converged", rvals.get("converged"),
        "max_shift_sigma", rvals.get("Max shft/sig"),
        "frozen", gpx.get_Frozen(),
        "profile", phase.getHAPvalues(hist)["Size"],
        phase.getHAPvalues(hist)["Mustrain"],
        "fractions", hist.ComputeMassFracs(),
        flush=True,
    )
    gpx.save(outpath)


def main():
    G2sc.SetPrintLevel("warn")
    for term in ("Size", "Mustrain"):
        trial(term)


if __name__ == "__main__":
    main()
