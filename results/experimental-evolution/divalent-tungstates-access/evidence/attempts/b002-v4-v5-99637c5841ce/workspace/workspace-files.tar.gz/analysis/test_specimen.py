#!/usr/bin/env python3
"""Test polarization and surface roughness on the accepted [111] PO model."""

import argparse
import os

from GSASII import GSASIIscriptable as G2sc


ap = argparse.ArgumentParser()
ap.add_argument("mode", choices=("pol", "surf", "both"))
args = ap.parse_args()
outdir = f"analysis/branches/specimen_{args.mode}"
os.makedirs(outdir, exist_ok=True)
G2sc.SetPrintLevel("warn")
gpx = G2sc.G2Project(gpxfile="analysis/branches/po_111/fit.gpx")
gpx.set_Frozen()
gpx.set_Controls("cycles", 18)
gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
hist = gpx.histogram(0)

if args.mode in ("pol", "both"):
    hist.InstrumentParameters["Polariz."][1] = 0.70
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    gpx.set_Controls("parmMin", 0.50, ":0:Polariz.")
    gpx.set_Controls("parmMax", 1.00, ":0:Polariz.")
if args.mode in ("surf", "both"):
    hist.SampleParameters["SurfRoughA"] = [0.20, True]
    hist.SampleParameters["SurfRoughB"] = [0.10, True]
    gpx.set_Controls("parmMin", 0.05, ":0:SurfRoughA")
    gpx.set_Controls("parmMax", 0.60, ":0:SurfRoughA")
    gpx.set_Controls("parmMin", 0.02, ":0:SurfRoughB")
    gpx.set_Controls("parmMax", 0.50, ":0:SurfRoughB")

gpx.save(os.path.join(outdir, "fit.gpx"))
gpx.do_refinements([{}])
frozen = gpx.get_Frozen()
recompute = False
for var, key, kind in (
    (":0:Polariz.", "Polariz.", "inst"),
    (":0:SurfRoughA", "SurfRoughA", "sample"),
    (":0:SurfRoughB", "SurfRoughB", "sample"),
):
    if var not in frozen:
        continue
    recompute = True
    if kind == "inst":
        hist.InstrumentParameters[key][2] = False
    else:
        hist.SampleParameters[key][1] = False
if recompute:
    gpx.set_Frozen()
    gpx.do_refinements([{}])

phase = gpx.phase(0)
print(
    "mode", args.mode,
    "Rwp", hist.get_wR(),
    "polarization", hist.InstrumentParameters["Polariz."],
    "surface", hist.SampleParameters["SurfRoughA"], hist.SampleParameters["SurfRoughB"],
    "MD", phase.getHAPvalues(hist)["Pref.Ori."],
    "frozen", gpx.get_Frozen(),
)
gpx.save(os.path.join(outdir, "fit.gpx"))
