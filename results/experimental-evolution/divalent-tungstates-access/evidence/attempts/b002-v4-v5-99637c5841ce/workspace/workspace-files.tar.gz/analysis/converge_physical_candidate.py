#!/usr/bin/env python3
"""Converge the selected physical three-phase candidate."""

import os

from GSASII import GSASIIscriptable as G2sc


SOURCE = "analysis/branches/main_microstrain_physical_wo3/001/fit.gpx"
OUTDIR = "analysis/checkpoints/physical_wo3/final_candidate"
OUT = os.path.join(OUTDIR, "fit.gpx")


def main():
    os.makedirs(OUTDIR, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    gpx = G2sc.G2Project(gpxfile=SOURCE)
    gpx.set_Controls("cycles", 50)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    gpx.save(OUT)
    gpx.set_Frozen()
    gpx.do_refinements([{}])
    hist = gpx.histogram(0)
    rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
    print(
        "Rwp", hist.get_wR(),
        "GOF", rvals.get("GOF"),
        "converged", rvals.get("converged"),
        "max_shift_sigma", rvals.get("Max shft/sig"),
        "frozen", gpx.get_Frozen(),
        "fractions", hist.ComputeMassFracs(),
        flush=True,
    )
    for phase in gpx.phases():
        print(
            phase.name,
            "cell", phase.data["General"]["Cell"][1:7],
            "profile", phase.getHAPvalues(hist)["Size"],
            phase.getHAPvalues(hist)["Mustrain"],
            "PO", phase.getHAPvalues(hist)["Pref.Ori."],
            flush=True,
        )
        phase.export_CIF(os.path.join(OUTDIR, phase.name + ".cif"))
    gpx.save(OUT)


if __name__ == "__main__":
    main()
