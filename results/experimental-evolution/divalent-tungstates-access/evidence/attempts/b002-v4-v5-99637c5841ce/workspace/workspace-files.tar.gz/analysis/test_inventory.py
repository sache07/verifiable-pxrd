#!/usr/bin/env python3
"""Compare WO3 topology branches in a common ZnWO4 + ZnO + WO3 state."""

import argparse
import os

from GSASII import GSASIIscriptable as G2sc


ZNO = "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c01/cif/9/00/41/9004178.cif"
BASE = "analysis/checkpoints/accepted_single_phase.gpx"


ap = argparse.ArgumentParser()
ap.add_argument("label")
ap.add_argument("cif")
args = ap.parse_args()
outdir = f"analysis/branches/inventory_{args.label}"
os.makedirs(outdir, exist_ok=True)
G2sc.SetPrintLevel("warn")
gpx = G2sc.G2Project(gpxfile=BASE)
gpx.save(os.path.join(outdir, "working.gpx"))
gpx.set_Frozen()
gpx.set_Controls("cycles", 22)
gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
hist = gpx.histogram(0)
zno = gpx.add_phase(ZNO, phasename="ZnO", histograms=[hist], fmthint="CIF")
wo3 = gpx.add_phase(args.cif, phasename=f"WO3_{args.label}", histograms=[hist], fmthint="CIF")
gpx.update_ids()

for phase, scale in ((zno, 5.0), (wo3, 10.0)):
    phase.data["General"]["Cell"][0] = True
    phase.getHAPvalues(hist)["Scale"] = [scale, True]
    for atom in phase.atoms():
        if atom.adp_flag == "I":
            atom.uiso = 0.009
        else:
            atom.ADP = [0.009, 0.009, 0.009, 0.0, 0.0, 0.0]
        atom.refinement_flags = ""
    phase.setSampleProfile(hist, "size", "isotropic", 0.12, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 500.0, LGmix=1.0)
    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
            "Scale": True,
        },
        [hist],
    )
    pfx = f"{phase.id}:{hist.id}:"
    for var, lo, hi in (
        (pfx + "Scale", 0.0, 1000.0),
        (pfx + "Size;i", 0.04, 1.50),
        (pfx + "Mustrain;i", 0.0, 8000.0),
    ):
        gpx.set_Controls("parmMin", lo, var)
        gpx.set_Controls("parmMax", hi, var)


def show(stage):
    print("stage", stage, "Rwp", hist.get_wR(), flush=True)
    for p in gpx.phases():
        hap = p.getHAPvalues(hist)
        print(
            p.name,
            "scale", hap["Scale"],
            "cell", p.data["General"]["Cell"][1:7],
            "size", hap["Size"],
            "strain", hap["Mustrain"],
            flush=True,
        )


gpx.save(os.path.join(outdir, "20_scale_cell_profile.gpx"))
gpx.do_refinements([{}])
show("20_scale_cell_profile")

# Refine only the heavy-atom coordinates in the WO3 candidate. This gives
# each topology comparable intensity flexibility without letting oxygen
# coordinates rescue an incorrect lattice.
for atom in wo3.atoms():
    if atom.element == "W":
        atom.refinement_flags = "X"
gpx.set_Frozen()
gpx.save(os.path.join(outdir, "21_W_coordinates.gpx"))
gpx.do_refinements([{}])
show("21_W_coordinates")
gpx.save(os.path.join(outdir, "final_branch.gpx"))
for p in gpx.phases():
    p.export_CIF(os.path.join(outdir, p.name + ".cif"))
