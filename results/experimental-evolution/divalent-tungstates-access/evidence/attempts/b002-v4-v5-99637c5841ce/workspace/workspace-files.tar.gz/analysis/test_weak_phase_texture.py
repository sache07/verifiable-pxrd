#!/usr/bin/env python3
"""Test one bounded March-Dollase term on each minor phase."""

import os

from GSASII import GSASIIscriptable as G2sc


SOURCE = "analysis/checkpoints/inventory_refined/stabilized/stabilized.gpx"
ROOT = "analysis/branches/weak_texture"


def trial(phase_name, axis):
    tag = phase_name.replace("_monoclinic", "") + "_" + "".join(map(str, axis))
    outdir = os.path.join(ROOT, tag)
    os.makedirs(outdir, exist_ok=True)
    outpath = os.path.join(outdir, "fit.gpx")

    gpx = G2sc.G2Project(gpxfile=SOURCE)
    gpx.set_Controls("cycles", 20)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-7
    hist = gpx.histogram(0)
    phase = gpx.phase(phase_name)
    pref = phase.getHAPvalues(hist)["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = list(axis)
    var = f"{phase.id}:{hist.id}:MD"
    gpx.set_Controls("parmMin", 0.70, var)
    gpx.set_Controls("parmMax", 1.40, var)

    gpx.save(outpath)
    gpx.set_Frozen()
    gpx.do_refinements([{}])
    rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
    print(
        tag,
        "Rwp", hist.get_wR(),
        "GOF", rvals.get("GOF"),
        "MD", phase.getHAPvalues(hist)["Pref.Ori."][1],
        "converged", rvals.get("converged"),
        "max_shift_sigma", rvals.get("Max shft/sig"),
        "frozen", gpx.get_Frozen(),
        "fractions", hist.ComputeMassFracs(),
        flush=True,
    )
    gpx.save(outpath)


def main():
    G2sc.SetPrintLevel("warn")
    os.makedirs(ROOT, exist_ok=True)
    for axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]):
        trial("WO3_monoclinic", axis)
    for axis in ([0, 0, 1], [1, 0, 0], [1, 1, 0]):
        trial("ZnO", axis)


if __name__ == "__main__":
    main()
