#!/usr/bin/env python3
"""Grid a common isotropic displacement parameter for all phase atoms."""

import argparse
import os

from GSASII import GSASIIscriptable as G2sc


ap = argparse.ArgumentParser()
ap.add_argument("uiso", type=float)
args = ap.parse_args()
tag = str(args.uiso).replace(".", "p")
outdir = f"analysis/branches/uiso_{tag}"
os.makedirs(outdir, exist_ok=True)
G2sc.SetPrintLevel("warn")
gpx = G2sc.G2Project(gpxfile="analysis/branches/specimen_pol/fit.gpx")
gpx.set_Frozen()
gpx.set_Controls("cycles", 16)
gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
phase = gpx.phase(0)
for atom in phase.atoms():
    atom.uiso = args.uiso
    atom.refinement_flags = atom.refinement_flags.replace("U", "")
gpx.save(os.path.join(outdir, "fit.gpx"))
gpx.do_refinements([{}])
print(
    "Uiso", args.uiso,
    "Rwp", gpx.histogram(0).get_wR(),
    "atoms", [(a.label, a.uiso, a.coordinates) for a in phase.atoms()],
)
gpx.save(os.path.join(outdir, "fit.gpx"))
