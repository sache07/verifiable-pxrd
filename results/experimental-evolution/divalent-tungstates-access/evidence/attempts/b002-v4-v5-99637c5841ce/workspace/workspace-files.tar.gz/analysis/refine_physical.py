#!/usr/bin/env python3
"""Refine the accepted wolframite model with physically bounded terms."""

import os

from GSASII import GSASIIscriptable as G2sc


SOURCE = "analysis/branches/wolframite/02_cell_shift.gpx"
OUTDIR = "analysis/checkpoints/physical"


def values(gpx, stage):
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    inst = hist.InstrumentParameters
    hap = phase.getHAPvalues(hist)
    cov = gpx.data["Covariance"]["data"]
    print(
        stage,
        "Rwp", hist.get_wR(),
        "cell", [round(x, 7) for x in phase.data["General"]["Cell"][1:7]],
        "shift", hist.SampleParameters["Shift"][0],
        "profile", {k: round(inst[k][1], 7) for k in ("U", "V", "W", "X", "SH/L")},
        "size", hap["Size"],
        "mustrain", hap["Mustrain"],
        "atoms", [(a.label, tuple(round(x, 7) for x in a.coordinates), round(a.uiso, 7)) for a in phase.atoms()],
        "frozen", gpx.get_Frozen(),
        "converged", cov.get("Rvals", {}).get("converged"),
        flush=True,
    )


def run(gpx, stage):
    gpx.set_Frozen()
    path = os.path.join(OUTDIR, stage + ".gpx")
    gpx.save(path)
    gpx.do_refinements([{}])
    values(gpx, stage)


def main():
    os.makedirs(OUTDIR, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    gpx = G2sc.G2Project(gpxfile=SOURCE)
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    gpx.set_Controls("cycles", 16)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6

    # Roll back the correlated/unphysical exploratory profile. Keep only the
    # specimen-height correction, which is identifiable enough with full-grid data.
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L"]})
    hist.InstrumentParameters["Zero"][1] = 0.0
    for key, val in {"U": 10.0, "V": 0.0, "W": 15.0, "X": 1.0, "SH/L": 0.02}.items():
        hist.InstrumentParameters[key][1] = val
    hist.SampleParameters["Shift"][1] = True
    phase.data["General"]["Cell"][0] = True

    # Instrument X and sample size, and instrument U and Gaussian strain, are
    # strongly correlated. Hold plausible instrument terms and refine the
    # phase-specific Lorentzian size/strain plus W and axial divergence.
    phase.setSampleProfile(hist, "size", "isotropic", 0.20, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 1500.0, LGmix=1.0)
    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        [hist],
    )
    hist.set_refinements({"Instrument Parameters": ["W", "SH/L"]})
    bounds = {
        ":0:W": (2.0, 40.0),
        ":0:SH/L": (0.005, 0.10),
        "0:0:Size;i": (0.04, 1.50),
        "0:0:Mustrain;i": (300.0, 8000.0),
        ":0:Shift": (-800.0, 800.0),
    }
    for var, (lo, hi) in bounds.items():
        gpx.set_Controls("parmMin", lo, var)
        gpx.set_Controls("parmMax", hi, var)
    run(gpx, "10_physical_profile")

    phase.set_refinements({"Atoms": {"W1": "X"}})
    run(gpx, "11_W_coordinate")

    phase.set_refinements({"Atoms": {"Zn1": "X"}})
    run(gpx, "12_Zn_coordinate")

    phase.set_refinements({"Atoms": {"O1": "X", "O2": "X"}})
    run(gpx, "13_O_coordinates")

    gpx.save(os.path.join(OUTDIR, "accepted_coordinates.gpx"))


if __name__ == "__main__":
    main()
