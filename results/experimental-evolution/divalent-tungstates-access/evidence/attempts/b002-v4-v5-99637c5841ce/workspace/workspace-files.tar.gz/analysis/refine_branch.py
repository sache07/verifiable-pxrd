#!/usr/bin/env python3
"""Comparable staged GSAS-II fit for a single candidate topology."""

import argparse
import os

from GSASII import GSASIIscriptable as G2sc


def report(stage, gpx, hist, phase):
    cell = phase.data["General"]["Cell"][1:7]
    inst = hist.InstrumentParameters
    samp = hist.SampleParameters
    hap = phase.getHAPvalues(hist)
    print(
        stage,
        "wR=", hist.get_wR(),
        "cell=", [round(float(v), 7) for v in cell],
        "Zero=", inst["Zero"][1],
        "Shift=", samp["Shift"][0],
        "scale=", hap["Scale"][0],
        "U,V,W,X,SHL=", [inst[k][1] for k in ("U", "V", "W", "X", "SH/L")],
        flush=True,
    )
    gpx.save()


def refine(gpx, stage, hist, phase, outdir):
    gpx.save(os.path.join(outdir, f"{stage}.gpx"))
    gpx.do_refinements([{}])
    report(stage, gpx, hist, phase)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cif")
    ap.add_argument("outdir")
    ap.add_argument("--name", required=True)
    args = ap.parse_args()
    os.makedirs(args.outdir, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    gpx = G2sc.G2Project(newgpx=os.path.join(args.outdir, "working.gpx"))
    hist = gpx.add_powder_histogram(
        "analysis/pattern.xy", "analysis/cu_ka.instprm", fmthint="xye"
    )
    phase = gpx.add_phase(
        args.cif, phasename=args.name, histograms=[hist], fmthint="CIF"
    )

    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-5
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-500.0, False]
    phase.getHAPvalues(hist)["Scale"] = [1.0, True]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
                "coeffs": [900.0, -250.0, 100.0, -50.0, 20.0, 0.0, 0.0, 0.0],
            }
        }
    )

    refine(gpx, "01_scale_background", hist, phase, args.outdir)

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(gpx, "02_cell_shift", hist, phase, args.outdir)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(gpx, "03_cell_shift_zero", hist, phase, args.outdir)

    hist.set_refinements(
        {"Instrument Parameters": ["U", "V", "W", "X", "SH/L"]}
    )
    refine(gpx, "04_profile", hist, phase, args.outdir)

    gpx.save(os.path.join(args.outdir, "final_branch.gpx"))
    report("final", gpx, hist, phase)


if __name__ == "__main__":
    main()
