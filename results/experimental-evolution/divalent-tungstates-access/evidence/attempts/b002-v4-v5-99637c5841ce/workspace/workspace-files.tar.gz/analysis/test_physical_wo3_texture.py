#!/usr/bin/env python3
"""Screen one March-Dollase axis for the physical gamma-WO3 parent."""

import os

from GSASII import GSASIIscriptable as G2sc


SOURCE = "analysis/checkpoints/physical_wo3/stabilized/fit.gpx"
ROOT = "analysis/branches/physical_wo3_texture"
PHASE = "WO3_monoclinic_physical"


def trial(axis):
    tag = "".join(map(str, axis))
    outdir = os.path.join(ROOT, tag)
    os.makedirs(outdir, exist_ok=True)
    outpath = os.path.join(outdir, "fit.gpx")
    gpx = G2sc.G2Project(gpxfile=SOURCE)
    gpx.set_Controls("cycles", 30)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = gpx.histogram(0)
    phase = gpx.phase(PHASE)
    pref = phase.getHAPvalues(hist)["Pref.Ori."]
    pref[0], pref[1], pref[2], pref[3] = "MD", 1.0, True, list(axis)
    var = f"{phase.id}:{hist.id}:MD"
    gpx.set_Controls("parmMin", 0.70, var)
    gpx.set_Controls("parmMax", 1.40, var)
    gpx.save(outpath)
    gpx.set_Frozen()
    gpx.do_refinements([{}])
    rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
    print(
        tag,
        "Rwp", hist.get_wR(),
        "GOF", rvals.get("GOF"),
        "MD", phase.getHAPvalues(hist)["Pref.Ori."][1],
        "converged", rvals.get("converged"),
        "max_shift_sigma", rvals.get("Max shft/sig"),
        "frozen", gpx.get_Frozen(),
        "fractions", hist.ComputeMassFracs(),
        flush=True,
    )
    gpx.save(outpath)


def main():
    G2sc.SetPrintLevel("warn")
    for axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]):
        trial(axis)


if __name__ == "__main__":
    main()
