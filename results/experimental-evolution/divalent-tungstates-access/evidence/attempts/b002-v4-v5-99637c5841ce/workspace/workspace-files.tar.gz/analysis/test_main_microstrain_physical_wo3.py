#!/usr/bin/env python3
"""Test ZnWO4 uniaxial microstrain after accepting physical gamma-WO3."""

import os

from GSASII import GSASIIscriptable as G2sc


SOURCE = "analysis/checkpoints/physical_wo3/texture_110/fit.gpx"
ROOT = "analysis/branches/main_microstrain_physical_wo3"


def trial(axis):
    tag = "".join(map(str, axis))
    outdir = os.path.join(ROOT, tag)
    os.makedirs(outdir, exist_ok=True)
    outpath = os.path.join(outdir, "fit.gpx")
    gpx = G2sc.G2Project(gpxfile=SOURCE)
    gpx.set_Controls("cycles", 35)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = gpx.histogram(0)
    phase = gpx.phase("ZnWO4_wolframite")
    value = phase.getHAPvalues(hist)["Mustrain"][1][0]
    phase.setSampleProfile(
        hist, "microstrain", "uniaxial", value, value, axis, LGmix=1.0
    )
    phase.set_HAP_refinements(
        {"Mustrain": {"type": "uniaxial", "refine": True}}, [hist]
    )
    for suffix in ("i", "a"):
        var = f"{phase.id}:{hist.id}:Mustrain;{suffix}"
        gpx.set_Controls("parmMin", 100.0, var)
        gpx.set_Controls("parmMax", 8000.0, var)
    gpx.save(outpath)
    gpx.set_Frozen()
    gpx.do_refinements([{}])
    rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
    print(
        tag,
        "Rwp", hist.get_wR(),
        "GOF", rvals.get("GOF"),
        "converged", rvals.get("converged"),
        "max_shift_sigma", rvals.get("Max shft/sig"),
        "frozen", gpx.get_Frozen(),
        "mustrain", phase.getHAPvalues(hist)["Mustrain"],
        "fractions", hist.ComputeMassFracs(),
        flush=True,
    )
    gpx.save(outpath)


def main():
    G2sc.SetPrintLevel("warn")
    for axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0]):
        trial(axis)


if __name__ == "__main__":
    main()
