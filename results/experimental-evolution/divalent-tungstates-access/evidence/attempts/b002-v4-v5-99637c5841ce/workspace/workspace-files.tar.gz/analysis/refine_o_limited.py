#!/usr/bin/env python3
"""Test a bounded light-atom refinement from the accepted heavy-atom checkpoint."""

import argparse
import os

from GSASII import GSASIIscriptable as G2sc


ap = argparse.ArgumentParser()
ap.add_argument("limit", type=float)
args = ap.parse_args()
lim = args.limit
tag = str(lim).replace(".", "p")
outdir = f"analysis/branches/o_limit_{tag}"
os.makedirs(outdir, exist_ok=True)
G2sc.SetPrintLevel("warn")
gpx = G2sc.G2Project(gpxfile="analysis/checkpoints/physical/12_Zn_coordinate.gpx")
gpx.set_Controls("cycles", 18)
gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
gpx.set_Frozen()
phase = gpx.phase(0)
phase.set_refinements({"Atoms": {"O1": "X", "O2": "X"}})
for atom in (2, 3):
    for axis in "xyz":
        var = f"0::dA{axis}:{atom}"
        gpx.set_Controls("parmMin", -lim, var)
        gpx.set_Controls("parmMax", lim, var)
gpx.save(os.path.join(outdir, "bounded_O.gpx"))
gpx.do_refinements([{}])
hist = gpx.histogram(0)
cov = gpx.data["Covariance"]["data"]
print(
    "limit", lim,
    "Rwp", hist.get_wR(),
    "atoms", [(a.label, a.coordinates) for a in phase.atoms()],
    "frozen", gpx.get_Frozen(),
    "converged", cov.get("Rvals", {}).get("converged"),
)
phase.export_CIF(os.path.join(outdir, "bounded_O.cif"))
