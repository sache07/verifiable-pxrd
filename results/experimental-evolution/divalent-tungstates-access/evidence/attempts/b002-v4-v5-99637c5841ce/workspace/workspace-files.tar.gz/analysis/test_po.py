#!/usr/bin/env python3
"""Compare the finite set of physically supported March-Dollase axes."""

import argparse
import os

from GSASII import GSASIIscriptable as G2sc


ap = argparse.ArgumentParser()
ap.add_argument("h", type=int)
ap.add_argument("k", type=int)
ap.add_argument("l", type=int)
args = ap.parse_args()
axis = [args.h, args.k, args.l]
tag = "".join(str(i) for i in axis)
outdir = f"analysis/branches/po_{tag}"
os.makedirs(outdir, exist_ok=True)
G2sc.SetPrintLevel("warn")
gpx = G2sc.G2Project(gpxfile="analysis/checkpoints/physical/12_Zn_coordinate.gpx")
gpx.set_Frozen()
gpx.set_Controls("cycles", 18)
gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
hist = gpx.histogram(0)
phase = gpx.phase(0)
po = phase.getHAPvalues(hist)["Pref.Ori."]
po[0] = "MD"
po[1] = 1.0
po[2] = True
po[3] = axis
gpx.set_Controls("parmMin", 0.70, "0:0:MD")
gpx.set_Controls("parmMax", 1.40, "0:0:MD")
gpx.save(os.path.join(outdir, "fit.gpx"))
gpx.do_refinements([{}])

# If a limit was hit, recompute once with the bounded value fixed so the
# stored profile and residual statistics correspond to the saved model.
if "0:0:MD" in gpx.get_Frozen():
    po[2] = False
    gpx.set_Frozen()
    gpx.do_refinements([{}])

print("axis", axis, "Rwp", hist.get_wR(), "MD", po[1], "frozen", gpx.get_Frozen())
gpx.save(os.path.join(outdir, "fit.gpx"))
