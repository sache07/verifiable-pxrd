#!/usr/bin/env python3
"""Put the physical COD 2311041 gamma-WO3 model in its Niggli setting."""

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


SOURCE = (
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif/2/31/10/2311041.cif"
)
OUTPUT = "analysis/wo3_monoclinic_physical_start.cif"


structure = Structure.from_file(SOURCE).get_reduced_structure("niggli")
CifWriter(structure, symprec=1.0e-3).write_file(OUTPUT)
print(structure.composition, structure.get_space_group_info())
print(structure.lattice)
