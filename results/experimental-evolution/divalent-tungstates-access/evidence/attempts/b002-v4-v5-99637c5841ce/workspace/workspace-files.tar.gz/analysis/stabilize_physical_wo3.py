#!/usr/bin/env python3
"""Stabilize the three-phase branch built from physical gamma-WO3."""

import os

from GSASII import GSASIIscriptable as G2sc


SOURCE = "analysis/branches/inventory_monoclinic_physical/final_branch.gpx"
OUTDIR = "analysis/checkpoints/physical_wo3/stabilized"
OUT = os.path.join(OUTDIR, "fit.gpx")


def main():
    os.makedirs(OUTDIR, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    gpx = G2sc.G2Project(gpxfile=SOURCE)
    gpx.set_Controls("cycles", 35)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = gpx.histogram(0)
    zno = gpx.phase("ZnO")
    zno.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": False}}, [hist]
    )
    zno.getHAPvalues(hist)["Mustrain"][1][0] = 0.0
    hist.InstrumentParameters["SH/L"][2] = False
    gpx.save(OUT)
    gpx.set_Frozen()
    gpx.do_refinements([{}])
    rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
    print(
        "Rwp", hist.get_wR(),
        "GOF", rvals.get("GOF"),
        "converged", rvals.get("converged"),
        "max_shift_sigma", rvals.get("Max shft/sig"),
        "frozen", gpx.get_Frozen(),
        "fractions", hist.ComputeMassFracs(),
        flush=True,
    )
    gpx.save(OUT)


if __name__ == "__main__":
    main()
