#!/usr/bin/env python3
"""Converge the only supported minor-phase texture branch."""

import os

from GSASII import GSASIIscriptable as G2sc


SOURCE = "analysis/branches/weak_texture/WO3_111/fit.gpx"
OUTDIR = "analysis/checkpoints/inventory_refined/wo3_texture_111"
OUT = os.path.join(OUTDIR, "refined.gpx")


def main():
    os.makedirs(OUTDIR, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    gpx = G2sc.G2Project(gpxfile=SOURCE)
    gpx.set_Controls("cycles", 50)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-7
    gpx.save(OUT)
    gpx.set_Frozen()
    gpx.do_refinements([{}])
    hist = gpx.histogram(0)
    rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
    print(
        "Rwp", hist.get_wR(),
        "GOF", rvals.get("GOF"),
        "converged", rvals.get("converged"),
        "max_shift_sigma", rvals.get("Max shft/sig"),
        "frozen", gpx.get_Frozen(),
        "fractions", hist.ComputeMassFracs(),
        flush=True,
    )
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        print(
            phase.name,
            "scale", hap["Scale"],
            "PO", hap["Pref.Ori."],
            "size", hap["Size"],
            "strain", hap["Mustrain"],
            "cell", phase.data["General"]["Cell"][1:7],
            "atoms", [(a.label, a.refinement_flags, a.coordinates) for a in phase.atoms()],
            flush=True,
        )
        phase.export_CIF(os.path.join(OUTDIR, phase.name + ".cif"))
    gpx.save(OUT)


if __name__ == "__main__":
    main()
