#!/usr/bin/env python3
"""Stabilize the accepted three-phase model and test bounded O coordinates.

Each trial starts from the same replayable physical checkpoint.  This avoids
letting an unsuccessful weak-phase refinement contaminate the accepted model.
"""

import os
from GSASII import GSASIIscriptable as G2sc


SOURCE = "analysis/branches/inventory_monoclinic/final_branch.gpx"
ROOT = "analysis/checkpoints/inventory_refined"


def configure(gpx):
    gpx.set_Controls("cycles", 25)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-7


def describe(gpx, label):
    hist = gpx.histogram(0)
    rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
    print(
        label,
        "Rwp", hist.get_wR(),
        "GOF", rvals.get("GOF"),
        "converged", rvals.get("converged"),
        "max_shift_sigma", rvals.get("Max shft/sig"),
        "frozen", gpx.get_Frozen(),
        flush=True,
    )
    print("fractions", hist.ComputeMassFracs(), flush=True)
    print(
        "instrument",
        {key: hist.InstrumentParameters[key][1:] for key in ("W", "SH/L")},
        "shift", hist.SampleParameters["Shift"],
        flush=True,
    )
    for phase in gpx.phases():
        print(
            phase.name,
            "cell", [round(v, 7) for v in phase.data["General"]["Cell"][1:7]],
            "scale", phase.getHAPvalues(hist)["Scale"],
            "atoms", [
                (atom.label, atom.refinement_flags,
                 tuple(round(float(x), 7) for x in atom.coordinates))
                for atom in phase.atoms()
            ],
            flush=True,
        )


def run(gpx, outpath, label):
    # Save before set_Frozen because that method can auto-save its source.
    gpx.save(outpath)
    gpx.set_Frozen()
    gpx.do_refinements([{}])
    describe(gpx, label)
    gpx.save(outpath)
    return gpx


def stabilize():
    outdir = os.path.join(ROOT, "stabilized")
    os.makedirs(outdir, exist_ok=True)
    gpx = G2sc.G2Project(gpxfile=SOURCE)
    configure(gpx)
    hist = gpx.histogram(0)

    # The ZnO microstrain refined to its exact lower bound.  Treat that as a
    # stable scale collapse and fix it at zero.  Also remove the 96.6%-
    # correlated SH/L variable, retaining its already refined plausible value.
    zno = gpx.phase("ZnO")
    zno.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": False}}, [hist]
    )
    zno.getHAPvalues(hist)["Mustrain"][1][0] = 0.0
    hist.InstrumentParameters["SH/L"][2] = False

    return run(gpx, os.path.join(outdir, "stabilized.gpx"), "stabilized")


def bounded_oxygen_trial(source, label, phase_name, atom_labels, bound):
    outdir = os.path.join(ROOT, label)
    os.makedirs(outdir, exist_ok=True)
    gpx = G2sc.G2Project(gpxfile=source)
    configure(gpx)
    phase = gpx.phase(phase_name)
    for atom_index, atom in enumerate(phase.atoms()):
        if atom.label in atom_labels:
            atom.refinement_flags = "X"
            for axis, coordinate in zip("xyz", atom.coordinates):
                var = f"{phase.id}::dA{axis}:{atom_index}"
                # Despite the historical dA name, GSAS-II limits these as
                # absolute fractional coordinates rather than shifts.
                gpx.set_Controls("parmMin", coordinate - bound, var)
                gpx.set_Controls("parmMax", coordinate + bound, var)
    outpath = os.path.join(outdir, label + ".gpx")
    gpx = run(gpx, outpath, label)
    for item in gpx.phases():
        item.export_CIF(os.path.join(outdir, item.name + ".cif"))
    return outpath


def main():
    os.makedirs(ROOT, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    stable = stabilize()
    stable_path = os.path.join(ROOT, "stabilized", "stabilized.gpx")
    stable.save(stable_path)

    bounded_oxygen_trial(
        stable_path, "zno_O", "ZnO", {"O"}, 0.03
    )
    bounded_oxygen_trial(
        stable_path,
        "wo3_O_all",
        "WO3_monoclinic",
        {"O1", "O2", "O3", "O4", "O5", "O6"},
        0.02,
    )


if __name__ == "__main__":
    main()
