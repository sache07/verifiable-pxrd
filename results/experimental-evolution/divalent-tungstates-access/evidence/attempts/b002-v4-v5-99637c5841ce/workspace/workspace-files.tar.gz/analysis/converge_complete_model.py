#!/usr/bin/env python3
"""Converge the complete accepted physical model before final export."""

import os

from GSASII import GSASIIscriptable as G2sc


SOURCE = "analysis/branches/zno_texture_final/001/fit.gpx"
OUTDIR = "analysis/checkpoints/physical_wo3/complete"
OUT = os.path.join(OUTDIR, "fit.gpx")


def main():
    os.makedirs(OUTDIR, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    gpx = G2sc.G2Project(gpxfile=SOURCE)
    gpx.set_Controls("cycles", 50)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    gpx.save(OUT)
    gpx.set_Frozen()
    gpx.do_refinements([{}])
    hist = gpx.histogram(0)
    rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
    print(
        "Rwp", hist.get_wR(),
        "GOF", rvals.get("GOF"),
        "converged", rvals.get("converged"),
        "max_shift_sigma", rvals.get("Max shft/sig"),
        "frozen", gpx.get_Frozen(),
        "fractions", hist.ComputeMassFracs(),
        flush=True,
    )
    for phase in gpx.phases():
        print(
            phase.name,
            "scale", phase.getHAPvalues(hist)["Scale"],
            "cell", phase.data["General"]["Cell"][1:7],
            "PO", phase.getHAPvalues(hist)["Pref.Ori."],
            "size", phase.getHAPvalues(hist)["Size"],
            "strain", phase.getHAPvalues(hist)["Mustrain"],
            flush=True,
        )
        phase.export_CIF(os.path.join(OUTDIR, phase.name + ".cif"))
    gpx.save(OUT)


if __name__ == "__main__":
    main()
