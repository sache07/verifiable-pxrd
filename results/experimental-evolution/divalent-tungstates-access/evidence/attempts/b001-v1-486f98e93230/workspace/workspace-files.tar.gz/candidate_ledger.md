# Candidate ledger

The filtered structure index contains no `O-W-Zn` records. Exact-composition
Zn-W-O structures are therefore unavailable for direct import; all ZnWO4
entries below are explicitly constructed analogue models.

| Branch | Model source / transformation | Initial status | Test outcome |
|---|---|---|---|
| ZnWO4 wolframite | FeWO4 COD 1567215 metric/topology screen, then repaired Co/Ni prototypes COD 5910316/5910277 with Co/Ni -> Zn; P2/c multiplicities retained | tested | **nominated**: stable common-nuisance topology Rwp 33.90%; Fe coordinates flagged unphysical, so final branch restarts from repaired Co/Ni coordinates |
| ZnWO4 triclinic | CuWO4, COD 4000806, Cu -> Zn; P-1 retained | tested | rejected as principal topology: common-nuisance Rwp 55.54% |
| ZnWO4 scheelite | CdWO4, COD 1549132, Cd -> Zn; I41/a retained | tested | rejected as principal topology: common-nuisance Rwp 54.99% |
| ZnWO4 fergusonite | CaWO4, COD 1546035, Ca -> Zn; I2/a setting retained | tested | rejected as principal topology: common-nuisance Rwp 53.36% |
| ZnWO4 raspite | PbWO4, COD 9007617, Pb -> Zn; P21/a setting retained | tested | rejected as principal topology: common-nuisance Rwp 54.00% |
| ZnWO4 HgWO4-type | HgWO4, COD 2012578, Hg -> Zn; C2/c retained | tested | rejected as principal topology: Rwp 51.65% and 17.5% analogue-cell contraction before GSAS test |
| Co/Ni wolframite parents | COD 5910316 / 5910277 | tested/repaired | raw files duplicate symmetry-related cations and omit three mates of the second O site; repaired to four unique P2/c sites (2 Zn, 2 W, 4 O1, 4 O2) before fitting |
| ZnO precursor | COD 9004178 (wurtzite), COD 1537875 (zincblende), COD 1534836 (rocksalt) | tested | **nominated wurtzite**: Rwp 5.642%, 4.54 wt% at the common inventory stage; zincblende gave 0.335 wt% and rocksalt 0.03 wt% with worse fits |
| WO3 precursor/polymorphs | all 11 available WO3 records | tested | **nominated COD 2311041, P21/c**: Rwp 7.461%, about 17.0 wt% at the common inventory stage; P-1 COD 2106293 was the same framework and slightly worse (7.482%); other valid candidates were worse or collapsed |
| WO3 COD 1010618 | triclinic WO3 | unknown | source had a 0.464 A contact and cell refinement failed; invalid trial was rolled back, not scored as a rejection |
| WO3 COD 1563541 | nominal WO3 | rejected | import assigned invalid atom types and produced nonsensical abundance; excluded as an invalid atomic model |
| Reduced tungsten oxides | available W18O49, W10O29, W17O47, W3O8 and WO2 records | unknown / not triggered | no independent coherent residual family remained after precursor closure, so these were not claimed or falsely rejected |
| Other Zn-W-O stoichiometries | analogue substitution into plausible A-W-O prototypes | unknown / not triggered | no independent coherent residual family survived the ZnWO4 + WO3 + ZnO inventory |

Statuses are changed to **tested/rejected** only after a stable, active-phase
comparison. Failed imports or divergent/invalid refinements remain **unknown**.

## Final refinement branch ledger

| Branch | Status | Evidence / decision |
|---|---|---|
| ZnWO4 March-Dollase [100] | retained | large stable improvement; final ratio 0.7482 |
| WO3 March-Dollase axes | tested | [010] retained (final ratio 0.9596); [100], [001], [110], and [111] were inferior under identical settings |
| ZnO March-Dollase axes | rejected | all five axes changed Rwp by only about 0.001% |
| WO3 uniaxial microstrain | retained | [001] reduced Rwp 3.750% to 3.615%; [100]/[010] were worse; final equatorial/axial values 2314/4370 ppm |
| ZnWO4 uniaxial microstrain | rejected | no meaningful improvement over isotropic broadening |
| Common phase Uiso | retained | physically required isotropic normalization; positive values and stable equality constraints for each phase |
| ZnWO4 oxygen coordinates | retained then frozen | converged, Rwp 3.615% to 3.311%, and preserved 1.820-2.136 A W-O and 2.029-2.181 A Zn-O shells |
| WO3 tungsten coordinates | retained then frozen | stable positive improvement and physically valid 1.729-2.180 A W-O shells; frozen before final nuisance convergence |
| WO3 oxygen coordinates | rejected | apparent gain required 0.17-0.49 A shifts and a 1.56 A W-O contact |
| Zero + specimen shift | unknown / rolled back | direct joint branch was singular/highly correlated; curvature scan favored zero shift, so final model uses only zero = 0.14802 degrees |
| Surface roughness | rejected | small gain required 96% correlation with the principal scale |
| Extra U/W/X/SH-L/polarization refinements | rejected | negligible gain, instability, or 96-97% correlations with size, zero, or Uiso |
