#!/usr/bin/env python3
"""Bounded whole-pattern optimization for physically valid profile terms.

GSAS-II's normal least-squares driver is excellent near a solution but does not
bound profile parameters. This helper optimizes only the instrument/specimen
broadening family with SciPy bounds, then writes those values back into a normal
GSAS-II project for subsequent Rietveld refinement.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIstrIO as IO
from GSASII import GSASIIstrMath as M

from explore_gsas import freeze


def calculation(project_path: Path):
    histograms, phases = IO.GetUsedHistogramsAndPhases(str(project_path))
    name = next(name for name in histograms if name.startswith("PWDR"))
    hist = histograms[name]
    x = np.asarray(hist["Data"][0], float)
    y = np.asarray(hist["Data"][1], float)
    hist["Limits"] = [[float(x[0]), float(x[-1])], [float(x[0]), float(x[-1])]]
    used = {name: hist}
    controls = dict(IO.GetControls(str(project_path)))
    controls.pop("PhasePartials", None)
    rigid = IO.GetRigidBodies(str(project_path))
    ids = rigid.get("RBIds", {"Vector": [], "Residue": []})
    _, rb = IO.GetRigidBodyModels(rigid, Print=False)
    natoms, atomidx, _, phase, pawley, ff, ef, orb, bl, mf, maxss = IO.GetPhaseData(
        phases, {}, ids, Print=False
    )
    controls.update(
        atomIndx=atomidx,
        Natoms=natoms,
        FFtables=ff,
        EFtables=ef,
        ORBtables=orb,
        BLtables=bl,
        MFtables=mf,
        maxSSwave=maxss,
    )
    _, hap, extra = IO.GetHistogramPhaseData(phases, used, Controls=controls, Print=False)
    controls.update(extra)
    _, hp, hist1, extra = IO.GetHistogramData(used, Print=False)
    controls.update(extra)
    parameters = {**rb, **phase, **hap, **hp}
    IO.GetFprime(controls, used)
    return name, hist, phases, controls, pawley, hist1, parameters, x, y


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--max-nfev", type=int, default=80)
    args = parser.parse_args()

    name, hist, phases, controls, pawley, hist1, parameters, x, y = calculation(args.source)
    phase_ids = sorted(int(key.split(":", 1)[0]) for key in parameters if key.endswith(":Size;i"))
    principal_id = phase_ids[0]
    keys = [":0:U", ":0:W", ":0:X", ":0:SH/L", ":0:Polariz."]
    keys += [f"{pid}:0:Size;i" for pid in phase_ids]
    keys += [f"{pid}:0:Mustrain;i" for pid in phase_ids]
    keys += [f"{principal_id}:0:MD"]
    lower = [0.0, 2.0, 0.1, 0.005, 0.5]
    upper = [40.0, 40.0, 6.0, 0.10, 1.0]
    lower += [0.04] * len(phase_ids) + [0.0] * len(phase_ids) + [0.70]
    upper += [1.50] * len(phase_ids) + [8000.0] * len(phase_ids) + [1.40]
    start = []
    for key, lo, hi in zip(keys, lower, upper):
        value = float(parameters[key])
        if key.endswith("Mustrain;i") and value <= 0:
            value = 300.0
        start.append(min(hi - 1e-7, max(lo + 1e-7, value)))
    start = np.asarray(start)
    sqrt_weight = 1.0 / np.sqrt(np.maximum(y, 1.0))
    evaluations = 0

    def residual(values):
        nonlocal evaluations
        evaluations += 1
        for key, value in zip(keys, values):
            parameters[key] = float(value)
        signal, background = M.getPowderProfile(
            parameters, hist1, x, [], hist, phases, controls, pawley, name
        )
        predicted = signal + background
        if not np.all(np.isfinite(predicted)):
            return np.full_like(y, 1e8)
        if evaluations % 20 == 0:
            rwp = 100 * np.sqrt(np.sum(((y - predicted) * sqrt_weight) ** 2) / np.sum(y))
            print("evaluation", evaluations, "Rwp", rwp, flush=True)
        return (predicted - y) * sqrt_weight

    result = least_squares(
        residual,
        start,
        bounds=(np.asarray(lower), np.asarray(upper)),
        x_scale="jac",
        max_nfev=args.max_nfev,
        ftol=2e-7,
        xtol=2e-7,
        gtol=2e-7,
        verbose=2,
    )
    print("optimized", dict(zip(keys, result.x)), "cost", result.cost, flush=True)

    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    freeze(project)
    out_hist = project.histogram(0)
    xx = out_hist.data["data"][1][0]
    out_hist.data["Limits"] = [[float(xx[0]), float(xx[-1])], [float(xx[0]), float(xx[-1])]]
    instrument = out_hist.data["Instrument Parameters"][0]
    for key, value in zip(keys[:5], result.x[:5]):
        instrument[key.split(":")[-1]][1] = float(value)
    offset = 5
    for index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][out_hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = float(result.x[offset + index])
        hap["Mustrain"][1][0] = float(result.x[offset + len(phase_ids) + index])
    project.phases()[0].data["Histograms"][out_hist.name]["Pref.Ori."][1] = float(result.x[-1])
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    freeze(project)
    project.save()


if __name__ == "__main__":
    main()
