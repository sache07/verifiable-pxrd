#!/usr/bin/env python3
"""Create the clean, replayable final project and submission artifacts."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from explore_gsas import freeze


SOURCE = Path("trials/candidate_v8_joint.gpx")
FINAL = Path("final.gpx")

PHASES = {
    "znwo4_ni": {
        "name": "ZnWO4 (wolframite)",
        "formula": "ZnWO4",
        "cif_path": "phase_ZnWO4.cif",
    },
    "wo3_P21c": {
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif_path": "phase_WO3.cif",
    },
    "zno": {
        "name": "ZnO (wurtzite)",
        "formula": "ZnO",
        "cif_path": "phase_ZnO.cif",
    },
}


def remove_comparison_phase(project: G2.G2Project, name: str) -> None:
    """Remove a zero-scale trial phase from all persisted project locations."""
    hist = project.histogram(0)
    del project.data["Phases"][name]
    for row in project.names:
        if row and row[0] == "Phases" and name in row:
            row.remove(name)
    hist.data["Reflection Lists"].pop(name, None)
    for scope in ("Hist", "HAP", "Phase", "Global"):
        project.data["Constraints"]["data"][scope] = []
    project.data["Covariance"]["data"] = {}
    project.update_ids()


def main() -> None:
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    freeze(project)
    remove_comparison_phase(project, "wo3")

    # Recompute every calculated array and reflection list from the atomic models.
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    freeze(project)
    project.data["Covariance"]["data"] = {}
    project.save()

    # Reloading here is an intentional serialization/replay check.
    project = G2.G2Project(str(FINAL))
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    freeze(project)
    project.data["Covariance"]["data"] = {}
    project.save()

    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    x = np.asarray(arrays[0], dtype=float)
    observed = np.asarray(arrays[1], dtype=float)
    weight = np.asarray(arrays[2], dtype=float)
    calculated = np.asarray(arrays[3], dtype=float)
    background = np.asarray(arrays[4], dtype=float)
    difference = observed - calculated

    public = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
    if not np.array_equal(x, public[:, 0]) or not np.array_equal(observed, public[:, 1]):
        raise RuntimeError("Final project does not contain the exact supplied observations")
    if not np.isfinite(calculated).all() or np.any(calculated < 0):
        raise RuntimeError("Final calculated profile is nonfinite or negative")
    if not np.isfinite(background).all() or np.any(background < 0):
        raise RuntimeError("Final background is nonfinite or negative")

    np.savetxt(
        "fit.csv",
        np.column_stack((x, observed, calculated, difference, background)),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f", "%.10f"],
    )

    phase_objects = {phase.name: phase for phase in project.phases()}
    if set(phase_objects) != set(PHASES):
        raise RuntimeError(f"Unexpected final phase set: {sorted(phase_objects)}")

    mass_scales = {
        name: phase.data["General"]["Mass"]
        * phase.data["Histograms"][hist.name]["Scale"][0]
        for name, phase in phase_objects.items()
    }
    total = sum(mass_scales.values())
    rows = []
    for internal_name in ("znwo4_ni", "wo3_P21c", "zno"):
        phase = phase_objects[internal_name]
        metadata = PHASES[internal_name]
        phase.export_CIF(metadata["cif_path"])
        rows.append(
            {
                **metadata,
                "weight_fraction": mass_scales[internal_name] / total,
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            }
        )

    chi_square = float(np.sum(weight * difference**2))
    denominator = float(np.sum(weight * observed**2))
    rwp = float(100 * np.sqrt(chi_square / denominator))
    rp = float(100 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
    result = {
        "phases": rows,
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "chi_square": chi_square,
            "reduced_chi_square": chi_square / max(len(x) - 1, 1),
            "n_points": int(len(x)),
        },
        "refinement_histogram": hist.name,
        "fraction_basis": "normalized over modeled crystalline phases",
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
