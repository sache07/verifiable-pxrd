#!/usr/bin/env python3
"""Staged refinement for a project that contains an inactive comparison phase."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from explore_gsas import freeze


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--active", default="znwo4_ni,wo3_P21c,zno")
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    hist = project.histogram(0)
    active = [project.phase(name) for name in args.active.split(",")]
    principal, tungsten_oxide, _ = active
    project.set_Controls("cycles", 20)

    def run(label, setup):
        freeze(project)
        setup()
        project.refine(makeBack=False)
        freeze(project)
        project.save()
        masses = [
            p.data["General"]["Mass"]
            * p.data["Histograms"][hist.name]["Scale"][0]
            for p in active
        ]
        print(label, "Rwp", hist.get_wR(), "fractions", [m / sum(masses) for m in masses])

    run(
        "scales_background",
        lambda: (
            hist.data["Background"][0].__setitem__(1, True),
            [p.data["Histograms"][hist.name]["Scale"].__setitem__(1, True) for p in active],
        ),
    )
    run(
        "cells_zero",
        lambda: (
            [p.set_refinements({"Cell": True}) for p in active],
            hist.data["Instrument Parameters"][0]["Zero"].__setitem__(2, True),
        ),
    )
    run("principal_coordinates", lambda: principal.set_refinements({"Atoms": {"all": "X"}}))
    run(
        "textures",
        lambda: [
            p.data["Histograms"][hist.name]["Pref.Ori."].__setitem__(2, True)
            for p in (principal, tungsten_oxide)
        ],
    )
    run(
        "joint",
        lambda: (
            hist.data["Background"][0].__setitem__(1, True),
            [p.data["Histograms"][hist.name]["Scale"].__setitem__(1, True) for p in active],
            principal.set_refinements({"Atoms": {"all": "X"}}),
            [
                p.data["Histograms"][hist.name]["Pref.Ori."].__setitem__(2, True)
                for p in (principal, tungsten_oxide)
            ],
        ),
    )


if __name__ == "__main__":
    main()
