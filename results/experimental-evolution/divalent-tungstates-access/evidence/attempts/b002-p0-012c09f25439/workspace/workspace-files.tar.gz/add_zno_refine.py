#!/usr/bin/env python3
"""Add the residual wurtzite ZnO phase to the selected two-phase project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from explore_gsas import freeze


ZNO = Path("starting_models/ZnO_wurtzite_start.cif").resolve()


def summary(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    mass_scales = {
        p.name: p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    }
    total = sum(mass_scales.values())
    return {
        "stage": stage,
        "rwp": hist.get_wR(),
        "fractions": {k: v / total for k, v in mass_scales.items()},
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "hap": {p.name: p.data["Histograms"][hist.name] for p in project.phases()},
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    hist = project.histogram(0)
    freeze(project)
    zno = project.add_phase(str(ZNO), phasename="zno", histograms=[hist], fmthint="CIF")
    hap = zno.data["Histograms"][hist.name]
    hap["Scale"] = [14.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.5
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 800.0
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    project.set_Controls("cycles", 14)
    rows = []

    def refine(stage: str, setup) -> None:
        freeze(project)
        setup()
        project.refine(makeBack=False)
        project.save()
        row = summary(project, stage)
        rows.append(row)
        print(stage, "Rwp", row["rwp"], "fractions", row["fractions"])

    refine(
        "zno_scale_cell",
        lambda: (
            zno.set_refinements({"Cell": True}),
            zno.data["Histograms"][hist.name]["Scale"].__setitem__(1, True),
        ),
    )
    refine(
        "all_scales_background",
        lambda: (
            hist.data["Background"][0].__setitem__(1, True),
            [p.data["Histograms"][hist.name]["Scale"].__setitem__(1, True) for p in project.phases()],
        ),
    )
    refine(
        "zno_broadening",
        lambda: (
            zno.data["Histograms"][hist.name]["Size"][2].__setitem__(0, True),
            zno.data["Histograms"][hist.name]["Mustrain"][2].__setitem__(0, True),
        ),
    )
    refine(
        "cells_zero_shift",
        lambda: (
            [p.set_refinements({"Cell": True}) for p in project.phases()],
            hist.data["Instrument Parameters"][0]["Zero"].__setitem__(2, True),
            hist.SampleParameters["Shift"].__setitem__(1, True),
        ),
    )
    refine(
        "joint_intensity",
        lambda: (
            hist.data["Background"][0].__setitem__(1, True),
            [p.data["Histograms"][hist.name]["Scale"].__setitem__(1, True) for p in project.phases()],
            [p.data["Histograms"][hist.name]["Pref.Ori."].__setitem__(2, True) for p in project.phases()[:2]],
            project.phase("znwo4").set_refinements({"Atoms": {"all": "X"}}),
        ),
    )
    freeze(project)
    project.save()
    args.output.with_suffix(".history.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")
    arrays = hist.data["data"][1]
    np.savetxt(
        args.output.with_suffix(".fit.csv"),
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[1] - arrays[3], arrays[4])),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
    )


if __name__ == "__main__":
    main()
