#!/usr/bin/env python3
"""Build chemically appropriate starting models for the ZnO--WO3 pattern."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)


def cod_path(cod_id: str) -> Path:
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    out = Path("starting_models")
    out.mkdir(exist_ok=True)

    # COD 9008131 is a sound wolframite-type (Mn,Fe)WO4 analogue. Replace the
    # divalent-cation orbit by Zn and use a literature-scale ZnWO4 cell. The
    # symmetry coordinates are retained as a physically close refinement start.
    wolframite = Structure.from_file(cod_path("9008131"), primitive=False)
    for i, site in enumerate(wolframite):
        symbols = {element.symbol for element in site.species.elements}
        if symbols & {"Mn", "Fe"}:
            wolframite.replace(i, "Zn")
    wolframite = Structure(
        Lattice.monoclinic(4.6920, 5.7210, 4.9280, 90.62),
        [site.species for site in wolframite],
        wolframite.frac_coords,
        site_properties=wolframite.site_properties,
    )
    CifWriter(wolframite, symprec=1e-3, refine_struct=False).write_file(
        out / "ZnWO4_start.cif"
    )

    # Independent wolframite setting reconstructed from the closer NiWO4
    # analogue (COD 5910277). This avoids inheriting the oxygen-origin choice
    # of the Mn analogue and is used as a structural multistart, not as a new
    # phase hypothesis.
    ni_based = Structure.from_spacegroup(
        "P2/c",
        Lattice.monoclinic(4.6920, 5.7210, 4.9280, 90.62),
        ["Zn", "W", "O", "O"],
        [
            [0.5, 0.6530, 0.25],
            [0.0, 0.1800, 0.25],
            [0.2200, 0.1100, 0.9600],
            [0.2600, 0.3800, 0.3900],
        ],
    )
    CifWriter(ni_based, symprec=1e-3, refine_struct=False).write_file(
        out / "ZnWO4_ni_start.cif"
    )

    # Exact-composition precursor/reference candidates available to the solver.
    exact = {
        "ZnO_wurtzite_start.cif": "9004178",
        "ZnO_rocksalt_start.cif": "1537875",
        "WO3_ortho_start.cif": "1010618",
        "WO3_mono_start.cif": "2106293",
    }
    for name, cod_id in exact.items():
        structure = Structure.from_file(cod_path(cod_id), primitive=False)
        CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(out / name)


if __name__ == "__main__":
    main()
