#!/usr/bin/env python3
"""Physically staged GSAS-II refinement after phase/texture selection."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from explore_gsas import freeze


def phase_fraction(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    masses = {
        phase.name: phase.data["General"]["Mass"]
        * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    }
    total = sum(masses.values())
    return {name: value / total for name, value in masses.items()}


def concise(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    instrument = hist.data["Instrument Parameters"][0]
    return {
        "stage": stage,
        "rwp": hist.get_wR(),
        "fractions": phase_fraction(project),
        "instrument": {
            key: instrument[key][1]
            for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample": {
            key: hist.SampleParameters[key][0]
            for key in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")
        },
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
                "size": phase.data["Histograms"][hist.name]["Size"][1],
                "strain": phase.data["Histograms"][hist.name]["Mustrain"][1],
                "texture": phase.data["Histograms"][hist.name]["Pref.Ori."][1:4],
                "atoms": [
                    [atom.label, list(atom.coordinates), atom.uiso]
                    for atom in phase.atoms()
                ],
            }
            for phase in project.phases()
        },
    }


def set_instrument_flags(hist, keys: list[str]) -> None:
    for key in keys:
        hist.data["Instrument Parameters"][0][key][2] = True


def set_hap_flag(phase, hist, kind: str, enabled: bool = True) -> None:
    hap = phase.data["Histograms"][hist.name]
    if kind == "Scale":
        hap["Scale"][1] = enabled
    elif kind == "Size":
        hap["Size"][2][0] = enabled
    elif kind == "Mustrain":
        hap["Mustrain"][2][0] = enabled
    elif kind == "Pref.Ori.":
        hap["Pref.Ori."][2] = enabled
    else:
        raise ValueError(kind)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    hist = project.histogram(0)
    principal = next(p for p in project.phases() if p.name.startswith("znwo4"))
    freeze(project)

    # Replace the earlier unconstrained profile result by a valid, moderate
    # starting point. Cells, scales, coordinates and selected texture axes are
    # retained from the phase-identification refinement.
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {
        "U": 10.0,
        "V": 0.0,
        "W": 8.0,
        "X": 2.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.044,
        "Polariz.": 0.90,
    }.items():
        inst[key][1] = value
    hist.set_refinements({"Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 16,
                "refine": False,
            }
        }
    )
    for phase in project.phases():
        for atom in phase.atoms():
            atom.uiso = 0.010
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Mustrain"][0] = "isotropic"
        if phase is principal:
            hap["Size"][1][0] = 0.60
            hap["Mustrain"][1][0] = 1600.0
        else:
            hap["Size"][1][0] = 0.50
            hap["Mustrain"][1][0] = 800.0

    project.set_Controls("cycles", 12)
    history = []

    def refine(stage: str, setup) -> None:
        freeze(project)
        setup()
        project.refine(makeBack=False)
        project.save()
        row = concise(project, stage)
        history.append(row)
        print(stage, "Rwp", row["rwp"], row["instrument"], row["fractions"])

    def scales_background() -> None:
        hist.data["Background"][0][1] = True
        for phase in project.phases():
            set_hap_flag(phase, hist, "Scale")

    refine("scales_background", scales_background)
    refine(
        "cells_zero",
        lambda: (
            [phase.set_refinements({"Cell": True}) for phase in project.phases()],
            set_instrument_flags(hist, ["Zero"]),
        ),
    )
    refine(
        "shift",
        lambda: hist.set_refinements({"Sample Parameters": ["Shift"]}),
    )
    refine(
        "textures",
        lambda: [set_hap_flag(phase, hist, "Pref.Ori.") for phase in project.phases()],
    )
    refine("profile_W", lambda: set_instrument_flags(hist, ["W"]))
    refine("profile_U", lambda: set_instrument_flags(hist, ["U"]))
    refine("profile_X", lambda: set_instrument_flags(hist, ["X"]))
    refine(
        "phase_sizes",
        lambda: [set_hap_flag(phase, hist, "Size") for phase in project.phases()],
    )
    refine(
        "phase_strains",
        lambda: [set_hap_flag(phase, hist, "Mustrain") for phase in project.phases()],
    )
    refine("axial_pol", lambda: set_instrument_flags(hist, ["SH/L", "Polariz."]))
    refine(
        "znwo4_coordinates",
        lambda: principal.set_refinements({"Atoms": {"all": "X"}}),
    )
    refine("joint_intensity", lambda: (
        scales_background(),
        [set_hap_flag(phase, hist, "Pref.Ori.") for phase in project.phases()],
        principal.set_refinements({"Atoms": {"all": "X"}}),
        set_instrument_flags(hist, ["Polariz."]),
    ))

    freeze(project)
    project.save()
    (args.output.with_suffix(".history.json")).write_text(
        json.dumps(history, indent=2, default=str) + "\n"
    )
    arrays = hist.data["data"][1]
    np.savetxt(
        args.output.with_suffix(".fit.csv"),
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[1] - arrays[3], arrays[4])),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
    )


if __name__ == "__main__":
    main()
