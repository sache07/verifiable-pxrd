#!/usr/bin/env python3
"""Focused GSAS-II model diagnostics used after phase identification."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def freeze(project: G2.G2Project) -> None:
    for hist in project.histograms():
        hist.data["Background"][0][1] = False
        for value in hist.data["Instrument Parameters"][0].values():
            if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
                value[2] = False
        for value in hist.data["Sample Parameters"].values():
            if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
                value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        for hap in phase.data["Histograms"].values():
            hap["Scale"][1] = False
            hap["Pref.Ori."][2] = False
            hap["Size"][2] = [False] * len(hap["Size"][2])
            hap["Size"][5] = [False] * len(hap["Size"][5])
            hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def stats(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    obs = np.asarray(hist.data["data"][1][1], float)
    calc = np.asarray(hist.data["data"][1][3], float)
    return {
        "rwp": hist.get_wR(),
        "chi_square_poisson": float(np.sum((obs - calc) ** 2 / np.maximum(obs, 1))),
        "parameters": {
            phase.name: {
                "cell": phase.get_cell(),
                "hap": phase.data["Histograms"][hist.name],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": atom.coordinates,
                        "uiso": atom.uiso,
                    }
                    for atom in phase.atoms()
                ],
            }
            for phase in project.phases()
        },
    }


def md_trials(source: Path, out: Path, phase_name: str) -> None:
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    for axis in AXES:
        destination = out / ("axis_" + "".join(map(str, axis)) + ".gpx")
        project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
        freeze(project)
        project.set_Controls("cycles", 12)
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][project.histogram(0).name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 0.9
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        project.refine(makeBack=False)
        project.save()
        row = stats(project)
        row.update(axis=axis, ratio=hap["Pref.Ori."][1], project=str(destination))
        rows.append(row)
        print(axis, "ratio", row["ratio"], "Rwp", row["rwp"])
    (out / "summary.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")


def atom_trial(source: Path, out: Path, phase_name: str, flags: str) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source), newgpx=str(out))
    freeze(project)
    project.set_Controls("cycles", 16)
    phase = project.phase(phase_name)
    phase.set_refinements({"Atoms": {"all": flags}})
    project.refine(makeBack=False)
    project.save()
    row = stats(project)
    out.with_suffix(".json").write_text(json.dumps(row, indent=2, default=str) + "\n")
    print(flags, "Rwp", row["rwp"])


def strain_trials(source: Path, out: Path, phase_name: str) -> None:
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    for axis in AXES[:3]:
        destination = out / ("axis_" + "".join(map(str, axis)) + ".gpx")
        project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
        freeze(project)
        hist = project.histogram(0)
        instrument = hist.data["Instrument Parameters"][0]
        # Clamp the prior unconstrained instrument result so an anisotropic
        # specimen term is tested against a physically valid common profile.
        instrument["U"][1] = max(0.1, instrument["U"][1])
        instrument["W"][1] = min(40.0, max(2.0, instrument["W"][1]))
        instrument["X"][1] = min(6.0, max(0.1, instrument["X"][1]))
        instrument["Polariz."][1] = min(1.0, max(0.5, instrument["Polariz."][1]))
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        value = max(100.0, abs(float(hap["Mustrain"][1][0])))
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = value
        hap["Mustrain"][1][1] = value * 1.5
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        hap["Mustrain"][3] = list(axis)
        project.set_Controls("cycles", 16)
        project.refine(makeBack=False)
        project.save()
        row = stats(project)
        row.update(
            axis=axis,
            strain=hap["Mustrain"][1][:2],
            project=str(destination),
        )
        rows.append(row)
        print(axis, "strain", row["strain"], "Rwp", row["rwp"])
    (out / "summary.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")


def roughness_trials(source: Path, out: Path) -> None:
    out.mkdir(parents=True, exist_ok=True)
    starts = ((0.08, 0.03), (0.20, 0.08), (0.45, 0.20))
    rows = []
    for index, (aval, bval) in enumerate(starts):
        destination = out / f"start_{index}.gpx"
        project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
        freeze(project)
        hist = project.histogram(0)
        hist.SampleParameters["SurfRoughA"] = [aval, True]
        hist.SampleParameters["SurfRoughB"] = [bval, True]
        project.set_Controls("cycles", 20)
        project.refine(makeBack=False)
        project.save()
        row = stats(project)
        row.update(
            start=[aval, bval],
            refined=[
                hist.SampleParameters["SurfRoughA"][0],
                hist.SampleParameters["SurfRoughB"][0],
            ],
            project=str(destination),
        )
        rows.append(row)
        print(row["start"], "roughness", row["refined"], "Rwp", row["rwp"])
    (out / "summary.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")


def coordinate_multistart(source: Path, out: Path, starts: int) -> None:
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    for seed in range(starts):
        destination = out / f"start_{seed:02d}.gpx"
        project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
        freeze(project)
        hist = project.histogram(0)
        phase = project.phase("znwo4")
        rng = np.random.default_rng(481516 + seed)
        sigma = 0.006 + 0.004 * (seed % 4)
        for atom in phase.atoms():
            xyz = np.asarray(atom.coordinates, float)
            if atom.element in {"Zn", "W"}:
                xyz[1] += rng.normal(0.0, sigma)
            else:
                xyz += rng.normal(0.0, sigma, 3)
            atom.coordinates = xyz % 1.0
            atom.refinement_flags = "X"
        hist.data["Background"][0][1] = True
        for item in project.phases():
            item.data["Histograms"][hist.name]["Scale"][1] = True
        for item in project.phases()[:2]:
            item.data["Histograms"][hist.name]["Pref.Ori."][2] = True
        project.set_Controls("cycles", 24)
        project.refine(makeBack=False)
        project.save()
        row = stats(project)
        row.update(seed=seed, sigma=sigma, project=str(destination))
        rows.append(row)
        print(seed, "sigma", sigma, "Rwp", row["rwp"])
    (out / "summary.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    md = sub.add_parser("md")
    md.add_argument("source", type=Path)
    md.add_argument("out", type=Path)
    md.add_argument("phase")
    atom = sub.add_parser("atoms")
    atom.add_argument("source", type=Path)
    atom.add_argument("out", type=Path)
    atom.add_argument("phase")
    atom.add_argument("flags")
    strain = sub.add_parser("strain")
    strain.add_argument("source", type=Path)
    strain.add_argument("out", type=Path)
    strain.add_argument("phase")
    roughness = sub.add_parser("roughness")
    roughness.add_argument("source", type=Path)
    roughness.add_argument("out", type=Path)
    multistart = sub.add_parser("multistart")
    multistart.add_argument("source", type=Path)
    multistart.add_argument("out", type=Path)
    multistart.add_argument("--starts", type=int, default=8)
    args = parser.parse_args()
    if args.command == "md":
        md_trials(args.source, args.out, args.phase)
    elif args.command == "atoms":
        atom_trial(args.source, args.out, args.phase, args.flags)
    elif args.command == "strain":
        strain_trials(args.source, args.out, args.phase)
    elif args.command == "roughness":
        roughness_trials(args.source, args.out)
    else:
        coordinate_multistart(args.source, args.out, args.starts)


if __name__ == "__main__":
    main()
