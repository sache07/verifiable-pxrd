#!/usr/bin/env python3
"""Create and run staged GSAS-II refinements for candidate phase inventories.

Run under the supplied GSAS-II Python interpreter. This script intentionally
keeps each trial project so model selection can be audited from the fit rather
than from chemistry alone.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


MODEL_FILES = {
    "znwo4": "starting_models/ZnWO4_start.cif",
    "znwo4_ni": "starting_models/ZnWO4_ni_start.cif",
    "zno": "starting_models/ZnO_wurtzite_start.cif",
    "zno_rs": "starting_models/ZnO_rocksalt_start.cif",
    "wo3": "starting_models/WO3_mono_start.cif",
    "wo3_o": (
        "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
        "resources/b002-c01/cif/1/01/06/1010618.cif"
    ),
}

INITIAL_FRACTIONS = {
    "znwo4": 0.80,
    "znwo4_ni": 0.80,
    "zno": 0.15,
    "zno_rs": 0.02,
    "wo3": 0.05,
    "wo3_o": 0.05,
}


def prepare_input(root: Path) -> tuple[Path, Path]:
    x, y = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1).T
    sigma = np.sqrt(np.maximum(y, 1.0))
    xye = root / "pattern.xye"
    np.savetxt(xye, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")
    inst = root / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.29;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return xye, inst


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phases = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(mass_scale)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "mass_scale": mass_scale,
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    total = sum(masses)
    for row, value in zip(phases, masses):
        row["weight_fraction"] = value / total if total > 0 else None
    return {
        "stage": label,
        "rwp": hist.get_wR(),
        "residuals": hist.residuals,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"],
        "phases": phases,
    }


def run_trial(names: list[str], outdir: Path) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    xye, inst = prepare_input(outdir)
    gpx = outdir / "trial.gpx"
    project = G2.G2Project(newgpx=str(gpx))
    phases = [
        project.add_phase(
            str(Path(MODEL_FILES[name]).resolve()),
            phasename=name,
            fmthint="CIF",
        )
        for name in names
    ]
    hist = project.add_powder_histogram(
        str(xye), str(inst), phases=phases, fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1000.0] + [0.0] * 11,
                "refine": True,
            },
        }
    )
    start_sum = sum(INITIAL_FRACTIONS[name] for name in names)
    for name, phase in zip(names, phases):
        hap = phase.data["Histograms"][hist.name]
        # Match the forward-calculation convention closely enough to provide a
        # stable initial intensity (the refined value remains unconstrained).
        hap["Scale"] = [
            10000.0
            * INITIAL_FRACTIONS[name]
            / start_sum
            / phase.data["General"]["Mass"],
            True,
        ]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 300.0
        hap["Mustrain"][1][1] = 300.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    project.set_Controls("cycles", 8)
    history = []

    def refine(label: str) -> None:
        project.refine(makeBack=False)
        project.save()
        history.append(snapshot(project, label))
        print(label, "Rwp", history[-1]["rwp"])

    # Stable ordering: intensity/background, peak positions, profile, then
    # phase-specific broadening. Atomic coordinates are deliberately deferred.
    refine("scale_background")
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine("zero")
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine("cell")
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine("shift")
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine("cell_zero")

    hist.set_refinements(
        {"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]}
    )
    refine("instrument_profile")

    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    refine("phase_broadening")

    (outdir / "history.json").write_text(json.dumps(history, indent=2, default=str) + "\n")
    arrays = hist.data["data"][1]
    np.savetxt(
        outdir / "fit.csv",
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[1] - arrays[3], arrays[4])),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phases", required=True, help="comma-separated model keys")
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    run_trial(args.phases.split(","), args.out)


if __name__ == "__main__":
    main()
