#!/usr/bin/env python3
"""Rietveld intensity/structure refinement around a fixed valid profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from explore_gsas import freeze


def summarize(project, stage):
    hist = project.histogram(0)
    masses = {
        p.name: p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    }
    total = sum(masses.values())
    return {
        "stage": stage,
        "rwp": hist.get_wR(),
        "fractions": {k: v / total for k, v in masses.items()},
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.SampleParameters,
        "background": hist.data["Background"],
        "phases": {
            p.name: {
                "cell": p.get_cell(),
                "hap": p.data["Histograms"][hist.name],
                "atoms": [[a.label, list(a.coordinates), a.uiso] for a in p.atoms()],
            }
            for p in project.phases()
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    hist = project.histogram(0)
    principal = project.phases()[0]
    project.set_Controls("cycles", 18)
    rows = []

    def refine(stage, setup):
        freeze(project)
        setup()
        project.refine(makeBack=False)
        project.save()
        row = summarize(project, stage)
        rows.append(row)
        print(stage, "Rwp", row["rwp"], row["fractions"])

    refine(
        "scales_background",
        lambda: (
            hist.data["Background"][0].__setitem__(1, True),
            [p.data["Histograms"][hist.name]["Scale"].__setitem__(1, True) for p in project.phases()],
        ),
    )
    refine(
        "cells_zero",
        lambda: (
            [p.set_refinements({"Cell": True}) for p in project.phases()],
            hist.data["Instrument Parameters"][0]["Zero"].__setitem__(2, True),
        ),
    )
    refine(
        "shift",
        lambda: hist.SampleParameters["Shift"].__setitem__(1, True),
    )
    refine(
        "principal_coordinates",
        lambda: principal.set_refinements({"Atoms": {"all": "X"}}),
    )
    refine(
        "principal_texture",
        lambda: principal.data["Histograms"][hist.name]["Pref.Ori."].__setitem__(2, True),
    )
    refine(
        "joint_intensity",
        lambda: (
            hist.data["Background"][0].__setitem__(1, True),
            [p.data["Histograms"][hist.name]["Scale"].__setitem__(1, True) for p in project.phases()],
            principal.data["Histograms"][hist.name]["Pref.Ori."].__setitem__(2, True),
            principal.set_refinements({"Atoms": {"all": "X"}}),
        ),
    )
    freeze(project)
    project.save()
    args.output.with_suffix(".history.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")
    arrays = hist.data["data"][1]
    np.savetxt(
        args.output.with_suffix(".fit.csv"),
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[1] - arrays[3], arrays[4])),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
    )


if __name__ == "__main__":
    main()
