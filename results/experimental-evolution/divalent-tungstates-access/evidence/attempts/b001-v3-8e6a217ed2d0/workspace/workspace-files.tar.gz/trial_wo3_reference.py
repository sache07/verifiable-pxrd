"""Compare fixed, physically clean WO3 coordinate references in one model."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


REFERENCES = {
    "1528915": {
        "W0": (0.033, 0.026, 0.285), "W1": (0.466, 0.533, 0.719),
        "O2": (0.025, 0.710, 0.735), "O3": (0.220, 0.025, 0.720),
        "O4": (0.220, 0.025, 0.220), "O5": (0.250, 0.540, 0.470),
        "O6": (0.310, 0.740, 0.530), "O7": (0.475, 0.710, 0.265),
    },
    "2311041": {
        "W0": (0.028, 0.537, 0.782), "W1": (0.466, 0.023, 0.216),
        "O2": (0.002, 0.238, 0.214), "O3": (0.206, 0.542, 0.711),
        "O4": (0.225, 0.526, 0.218), "O5": (0.284, 0.043, 0.992),
        "O6": (0.286, 0.013, 0.507), "O7": (0.481, 0.241, 0.770),
    },
}

parser = argparse.ArgumentParser()
parser.add_argument("reference", choices=REFERENCES)
parser.add_argument("output", type=Path)
parser.add_argument("--base", type=Path,
                    default=Path(".tmp/three_phase_stages/09_polarization.gpx"))
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.base.resolve()),
                       newgpx=str(args.output.resolve()))
for phase in project.phases():
    for atom in phase.atoms():
        atom.refinement_flags = ""
wo3 = project.phase("wo3_1528915")
for atom in wo3.atoms():
    atom.coordinates = REFERENCES[args.reference][atom.label]
    atom.uiso = 0.005
controls = project.data["Controls"]["data"]
controls["parmMinDict"] = {}
controls["parmMaxDict"] = {}
controls["parmFrozen"] = {}
project.set_Controls("cycles", 24)
history = []
for _ in range(5):
    project.refine()
    history.append(float(project.histogram(0).get_wR()))
project.save(str(args.output.resolve()))
result = {
    "reference": args.reference,
    "Rwp_history_percent": history,
    "short_distances": {phase.name: phase.ShortDistances()
                        for phase in project.phases()},
    "coordinates": {atom.label: list(atom.coordinates) for atom in wo3.atoms()},
}
args.output.with_suffix(".json").write_text(
    json.dumps(result, indent=2, default=float) + "\n"
)
print(json.dumps(result, indent=2, default=float))
