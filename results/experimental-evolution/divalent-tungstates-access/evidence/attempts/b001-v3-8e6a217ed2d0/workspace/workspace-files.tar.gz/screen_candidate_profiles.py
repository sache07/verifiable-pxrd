"""Rank candidate frameworks against the residual after MnWO4 + monoclinic WO3."""

from pathlib import Path
import json
import sys
import warnings

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Lattice, Structure
from scipy.ndimage import gaussian_filter1d


ROOT = Path(__file__).resolve().parent
CANDIDATES = ROOT / ".tmp" / "candidates"
SCALED = ROOT / ".tmp" / "scaled_candidates"
SCALED.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT / "learned" / "divalent-tungstates" / "runtime"))
from models import write_synthetic_model  # noqa: E402

with np.load(ROOT / ".tmp" / "twophase_arrays.npz") as z:
    x, y, ycalc, background = (z[k].copy() for k in ["x", "y", "yc", "b"])
residual = y - ycalc
weights = 1.0 / np.maximum(y, 1.0)
step = float(np.median(np.diff(x)))

# Common angular mapping from the current two-phase fit.
zero = -0.19149684664900832
shift_um = -984.8466954935609
radius_mm = 200.0


def observed_angle(two_theta: np.ndarray) -> np.ndarray:
    theta = np.deg2rad(two_theta / 2.0)
    displacement = -0.09 / (np.pi * radius_mm) * 4.0 * shift_um * np.cos(theta)
    return two_theta + zero + displacement


def make_patterns(structure: Structure):
    patterns = []
    for wavelength, ratio in [(1.540598, 1.0), (1.544426, 0.5)]:
        pat = XRDCalculator(wavelength=wavelength).get_pattern(
            structure, two_theta_range=(8.0, 105.0), scaled=False
        )
        patterns.append((np.asarray(pat.x, float), np.asarray(pat.y, float) * ratio))
    return patterns


def profile(patterns, lattice_scale: float, width_scale: float) -> np.ndarray:
    # Scaling all direct-lattice vectors changes d spacings while keeping the
    # prototype coordinates and reflection intensities fixed for this screen.
    result = np.zeros_like(x)
    for ref, intensity0 in patterns:
        arg = np.sin(np.deg2rad(ref / 2.0)) / lattice_scale
        keep = (arg > 0) & (arg < 1)
        pos = observed_angle(np.rad2deg(2.0 * np.arcsin(arg[keep])))
        intensity = intensity0[keep]
        for center, area in zip(pos, intensity):
            if not x[0] - 2 <= center <= x[-1] + 2:
                continue
            fwhm = width_scale * (0.13 + 0.00012 * (center - 10.0) ** 2)
            sigma = max(fwhm / 2.35482, step)
            lo = max(0, int(np.searchsorted(x, center - 4.5 * sigma)))
            hi = min(len(x), int(np.searchsorted(x, center + 4.5 * sigma)))
            if hi <= lo:
                continue
            g = np.exp(-0.5 * ((x[lo:hi] - center) / sigma) ** 2)
            result[lo:hi] += area * g / (sigma * np.sqrt(2.0 * np.pi))
    return result


rows = []
for path in sorted(CANDIDATES.glob("*.cif")):
    if path.name.startswith("wo3_"):
        continue
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        structure = Structure.from_file(path, primitive=False)
    patterns = make_patterns(structure)
    best = None
    for scale in np.linspace(0.82, 1.16, 137):
        for width_scale in [0.7, 1.0, 1.35, 1.8]:
            calc = profile(patterns, float(scale), width_scale)
            denominator = float(np.sum(weights * calc * calc))
            amplitude = max(0.0, float(np.sum(weights * calc * residual)) / max(denominator, 1e-30))
            improvement = float(
                np.sum(weights * residual * residual)
                - np.sum(weights * (residual - amplitude * calc) ** 2)
            )
            trial = (improvement, float(scale), float(width_scale), amplitude)
            if best is None or trial > best:
                best = trial
    improvement, scale, width_scale, amplitude = best
    scaled = Structure(
        Lattice(structure.lattice.matrix * scale),
        [site.species for site in structure],
        structure.frac_coords,
        site_properties=structure.site_properties,
    )
    out = SCALED / path.name
    write_synthetic_model(scaled, out)
    rows.append(
        {
            "candidate": path.stem,
            "formula": structure.composition.reduced_formula,
            "space_group": structure.get_space_group_info()[0],
            "best_uniform_lattice_scale": scale,
            "best_width_scale": width_scale,
            "linear_amplitude": amplitude,
            "weighted_chi_square_improvement": improvement,
            "scaled_cif": str(out.relative_to(ROOT)),
        }
    )

rows.sort(key=lambda row: row["weighted_chi_square_improvement"], reverse=True)
(ROOT / ".tmp" / "candidate_profile_screen.json").write_text(json.dumps(rows, indent=2) + "\n")
for row in rows:
    print(
        f"{row['candidate']:42s} {row['formula']:10s} {row['space_group']:8s} "
        f"scale={row['best_uniform_lattice_scale']:.4f} width={row['best_width_scale']:.2f} "
        f"dchi2={row['weighted_chi_square_improvement']:.1f}"
    )
