"""Reset WO3 to a physical parent and refine within local coordinate bounds."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "three_phase_stages" / "09_polarization.gpx"
OUT = ROOT / ".tmp" / "three_phase_physical_wo3.gpx"
CHECK = ROOT / ".tmp" / "physical_wo3_stages"
CHECK.mkdir(parents=True, exist_ok=True)

PARENT = {
    "W0": (0.033, 0.026, 0.285),
    "W1": (0.466, 0.533, 0.719),
    "O2": (0.025, 0.710, 0.735),
    "O3": (0.220, 0.025, 0.720),
    "O4": (0.220, 0.025, 0.220),
    "O5": (0.250, 0.540, 0.470),
    "O6": (0.310, 0.740, 0.530),
    "O7": (0.475, 0.710, 0.265),
}


def report(project, label):
    hist = project.histogram(0)
    rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        rows.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "short_distances": phase.ShortDistances(),
                "atoms": [
                    {
                        "label": a.label,
                        "element": a.element,
                        "xyz": list(a.coordinates),
                        "uiso": a.uiso,
                        "flags": a.refinement_flags,
                    }
                    for a in phase.atoms()
                ],
            }
        )
    data = {
        "stage": label,
        "Rwp_percent": hist.get_wR(),
        "frozen": project.get_Frozen(),
        "phases": rows,
    }
    print(f"{label}: Rwp={hist.get_wR():.6f}%, frozen={data['frozen']}")
    for row in rows:
        print(row["name"], "short", row["short_distances"])
    (CHECK / f"{label}.json").write_text(json.dumps(data, indent=2, default=float) + "\n")
    project.save()
    shutil.copy2(project.filename, CHECK / f"{label}.gpx")


def refine(project, label, cycles):
    project.set_Controls("cycles", cycles)
    project.refine()
    report(project, label)


G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUT))
wo3 = project.phase("wo3_1528915")
for phase in project.phases():
    for atom in phase.atoms():
        atom.refinement_flags = ""
for atom in wo3.atoms():
    atom.coordinates = PARENT[atom.label]
    atom.uiso = 0.005

controls = project.data["Controls"]["data"]
controls["parmMinDict"] = {}
controls["parmMaxDict"] = {}
controls["parmFrozen"] = {}

refine(project, "01_parent_fixed", 24)

# The synthetic reference mismatch is small. Bounds are deliberately wider
# than that expected perturbation but prevent a second unphysical local minimum.
phase_id = wo3.id
for index, atom in enumerate(wo3.atoms()):
    for axis, value in zip("xyz", PARENT[atom.label]):
        variable = f"{phase_id}::dA{axis}:{index}"
        project.set_Controls("parmMin", value - 0.018, variable=variable)
        project.set_Controls("parmMax", value + 0.018, variable=variable)

for atom in wo3.atoms():
    if atom.element == "W":
        atom.refinement_flags = "X"
refine(project, "02_heavy_bounded", 20)

project.set_Frozen()
for atom in wo3.atoms():
    atom.refinement_flags = "X"
refine(project, "03_all_bounded", 28)

project.save(str(OUT))
