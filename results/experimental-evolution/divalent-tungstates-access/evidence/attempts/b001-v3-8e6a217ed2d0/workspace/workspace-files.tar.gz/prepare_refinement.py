"""Prepare a standardized MnWO4 starting model and GSAS-II input files."""

from pathlib import Path
import sys
import warnings

import numpy as np
import pandas as pd
from pymatgen.io.cif import CifParser


WORK = Path(__file__).resolve().parent
RUNTIME = WORK / "learned" / "divalent-tungstates" / "runtime"
sys.path.insert(0, str(RUNTIME))
from models import write_synthetic_model  # noqa: E402

LIBRARY = Path(
    "<EVOLUTION_SOURCE>/runs/"
    "divalent-tungstates-access/resources/b001-c06/cif"
)
SOURCE = LIBRARY / "1" / "52" / "02" / "1520200.cif"


with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    structure = CifParser(
        SOURCE, occupancy_tolerance=1.0, site_tolerance=1e-5, frac_tolerance=0
    ).parse_structures(primitive=False, on_error="raise")[0]
structure.remove_oxidation_states()
write_synthetic_model(structure, WORK / "mnwo4_start.cif")

pattern = pd.read_csv(WORK / "inputs" / "pattern.csv")
x = pattern["two_theta_deg"].to_numpy(float)
y = pattern["intensity"].to_numpy(float)
sigma = np.sqrt(np.maximum(y, 1.0))
np.savetxt(
    WORK / "pattern.xye",
    np.column_stack((x, y, sigma)),
    fmt=("%.8f", "%.8f", "%.8f"),
)

(WORK / "instrument.instprm").write_text(
    "#GSAS-II instrument parameter file for Cu Kalpha Bragg-Brentano data\n"
    "Type:PXC;Bank:1\n"
    "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
    "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
    "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
)
