"""Standardize direct references and chemically substituted framework trials."""

from pathlib import Path
import sys
import warnings

from pymatgen.io.cif import CifParser


ROOT = Path(__file__).resolve().parent
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/"
    "divalent-tungstates-access/resources/b001-c06/cif"
)
OUT = ROOT / ".tmp" / "candidates"
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT / "learned" / "divalent-tungstates" / "runtime"))
from models import write_synthetic_model  # noqa: E402


def source(cod_id: str) -> Path:
    return LIB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def parse(cod_id: str):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return CifParser(
            source(cod_id), occupancy_tolerance=1.0, site_tolerance=1e-5, frac_tolerance=0
        ).parse_structures(primitive=False, on_error="raise")[0]


direct = {
    "wo3_1528915": "1528915",
    "wo3_2106293": "2106293",
    "wo3_2107312": "2107312",
    "wo3_1010618": "1010618",
    "wo3_1563541": "1563541",
    "wo3_2311041": "2311041",
    "mn3o4_9001963": "9001963",
    "mn2o3_1514230": "1514230",
}
for name, cod_id in direct.items():
    structure = parse(cod_id)
    structure.remove_oxidation_states()
    write_synthetic_model(structure, OUT / f"{name}.cif")

analogues = {
    "mn3wo6_from_ca3wo6_1563081": ("1563081", {"Ca": "Mn"}),
    "mn3wo6_from_ba3wo6_1534803": ("1534803", {"Ba": "Mn"}),
    "mn3wo6_from_cu3wo6_1527404": ("1527404", {"Cu": "Mn"}),
    "mn2wo6_from_fe2wo6_2310464": ("2310464", {"Fe": "Mn"}),
    "mn3wo6_from_mn3teo6_2211528": ("2211528", {"Te": "W"}),
    "mn2wo6_from_v2wo6_1008912": ("1008912", {"V": "Mn"}),
    "mn2wo6_from_cr2wo6_1530909": ("1530909", {"Cr": "Mn"}),
}
for name, (cod_id, substitutions) in analogues.items():
    structure = parse(cod_id)
    structure.remove_oxidation_states()
    structure.replace_species(substitutions)
    write_synthetic_model(structure, OUT / f"{name}.cif")

print(OUT)
