"""Test the clean COD 2311041 monoclinic WO3 coordinate start."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "three_phase_stages" / "09_polarization.gpx"
OUT = ROOT / ".tmp" / "three_phase_wo3_2311041.gpx"
CHECK = ROOT / ".tmp" / "wo3_2311041_stages"
CHECK.mkdir(parents=True, exist_ok=True)
PARENT = {
    "W0": (0.028, 0.537, 0.782),
    "W1": (0.466, 0.023, 0.216),
    "O2": (0.002, 0.238, 0.214),
    "O3": (0.206, 0.542, 0.711),
    "O4": (0.225, 0.526, 0.218),
    "O5": (0.284, 0.043, 0.992),
    "O6": (0.286, 0.013, 0.507),
    "O7": (0.481, 0.241, 0.770),
}


def save_stage(project, label):
    hist = project.histogram(0)
    data = {
        "stage": label,
        "Rwp_percent": hist.get_wR(),
        "frozen": project.get_Frozen(),
        "phases": [
            {
                "name": p.name,
                "cell": p.get_cell(),
                "short_distances": p.ShortDistances(),
                "atoms": [
                    {"label": a.label, "element": a.element, "xyz": list(a.coordinates)}
                    for a in p.atoms()
                ],
            }
            for p in project.phases()
        ],
    }
    print(label, "Rwp", hist.get_wR(), "short", data["phases"][1]["short_distances"])
    (CHECK / f"{label}.json").write_text(json.dumps(data, indent=2, default=float) + "\n")
    project.save()
    shutil.copy2(project.filename, CHECK / f"{label}.gpx")


def refine(project, label, cycles):
    project.set_Controls("cycles", cycles)
    project.refine()
    save_stage(project, label)


G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUT))
wo3 = project.phase("wo3_1528915")
for phase in project.phases():
    for atom in phase.atoms():
        atom.refinement_flags = ""
for atom in wo3.atoms():
    atom.coordinates = PARENT[atom.label]
    atom.uiso = 0.005
controls = project.data["Controls"]["data"]
controls["parmMinDict"] = {}
controls["parmMaxDict"] = {}
controls["parmFrozen"] = {}

refine(project, "01_parent_fixed", 24)

for index, atom in enumerate(wo3.atoms()):
    for axis, value in zip("xyz", PARENT[atom.label]):
        variable = f"{wo3.id}::dA{axis}:{index}"
        project.set_Controls("parmMin", value - 0.018, variable=variable)
        project.set_Controls("parmMax", value + 0.018, variable=variable)
for atom in wo3.atoms():
    atom.refinement_flags = "X" if atom.element == "W" else ""
refine(project, "02_heavy_bounded", 20)
project.set_Frozen()
for atom in wo3.atoms():
    atom.refinement_flags = "X"
refine(project, "03_all_bounded", 28)
project.save(str(OUT))
