"""Refine one phase around a clean reference with component-wise bounds."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


REFERENCES = {
    0: {
        "Mn0": (0.5, 0.3154, 0.75), "W1": (0.0, 0.18116, 0.25),
        "O2": (0.2124, 0.1000, 0.9432), "O3": (0.2498, 0.3780, 0.3937),
    },
    1: {
        "W0": (0.028, 0.537, 0.782), "W1": (0.466, 0.023, 0.216),
        "O2": (0.002, 0.238, 0.214), "O3": (0.206, 0.542, 0.711),
        "O4": (0.225, 0.526, 0.218), "O5": (0.284, 0.043, 0.992),
        "O6": (0.286, 0.013, 0.507), "O7": (0.481, 0.241, 0.770),
    },
    2: {
        "Mn0": (0.03839, 0.26425, 0.21297), "W1": (0.0, 0.0, 0.0),
        "W2": (0.0, 0.0, 0.5), "O3": (0.02657, 0.18277, 0.88947),
        "O4": (0.03069, 0.19625, 0.40283),
    },
}

parser = argparse.ArgumentParser()
parser.add_argument("base", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("phase", type=int)
parser.add_argument("width", type=float)
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.base.resolve()),
                       newgpx=str(args.output.resolve()))
for phase in project.phases():
    for atom in phase.atoms():
        atom.refinement_flags = ""
phase = project.phases()[args.phase]
reference = REFERENCES[args.phase]
controls = project.data["Controls"]["data"]
controls["parmMinDict"] = {}
controls["parmMaxDict"] = {}
controls["parmFrozen"] = {}
for atom_index, atom in enumerate(phase.atoms()):
    atom.coordinates = reference[atom.label]
    atom.refinement_flags = "X"
    for axis, value in zip("xyz", reference[atom.label]):
        variable = f"{phase.id}::dA{axis}:{atom_index}"
        project.set_Controls("parmMin", value - args.width, variable=variable)
        project.set_Controls("parmMax", value + args.width, variable=variable)

project.set_Controls("cycles", 30)
history = []
for _ in range(2):
    project.set_Frozen()
    project.refine()
    history.append(float(project.histogram(0).get_wR()))

for atom in phase.atoms():
    atom.refinement_flags = ""
controls["parmMinDict"] = {}
controls["parmMaxDict"] = {}
controls["parmFrozen"] = {}
for _ in range(3):
    project.refine()
    history.append(float(project.histogram(0).get_wR()))

project.save(str(args.output.resolve()))
result = {
    "phase": args.phase,
    "width_fractional": args.width,
    "Rwp_history_percent": history,
    "coordinates": {atom.label: list(atom.coordinates) for atom in phase.atoms()},
    "short_distances": {item.name: item.ShortDistances()
                        for item in project.phases()},
}
args.output.with_suffix(".json").write_text(
    json.dumps(result, indent=2, default=float) + "\n"
)
print(json.dumps(result, indent=2, default=float))
