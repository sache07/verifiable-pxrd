"""Controlled three-phase refinement after reflection-family closure."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "trials" / "mn3wo6_mn3te_from_two_phase.gpx"
OUT = ROOT / ".tmp" / "three_phase_refined.gpx"
CHECK = ROOT / ".tmp" / "three_phase_stages"
CHECK.mkdir(parents=True, exist_ok=True)


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def summary(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "mass": phase.data["General"]["Mass"],
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "short_distances": phase.ShortDistances(),
                "atoms": [
                    {
                        "label": a.label,
                        "element": a.element,
                        "xyz": list(a.coordinates),
                        "uiso": a.uiso,
                        "flags": a.refinement_flags,
                    }
                    for a in phase.atoms()
                ],
            }
        )
    result = {
        "stage": label,
        "Rwp_percent": hist.get_wR(),
        "instrument": {
            k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) >= 2
        },
        "sample": {
            k: (v[0] if isinstance(v, list) else v)
            for k, v in sample.items()
            if k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"]
        },
        "background": hist.data["Background"][0],
        "phases": phases,
    }
    (CHECK / f"{label}.json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    project.save()
    shutil.copy2(project.filename, CHECK / f"{label}.gpx")
    print(f"{label}: Rwp={hist.get_wR():.6f}%")
    for phase_row in phases:
        print(
            f"  {phase_row['name']}: scale={phase_row['scale']:.6g}, "
            f"short={phase_row['short_distances']}"
        )
    return result


def refine(project: G2.G2Project, label: str, cycles: int = 16) -> dict:
    project.set_Controls("cycles", cycles)
    project.refine()
    return summary(project, label)


G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUT))
clear_flags(project)
hist = project.histogram(0)
mnwo4, wo3, mn3wo6 = project.phases()

# Restore the wolframite atoms to the physically plausible registered parent;
# its earlier oxygen shifts were obtained before the other two phases were known.
mnwo4_parent = {
    "Mn0": (0.5, 0.3154, 0.75),
    "W1": (0.0, 0.18116, 0.25),
    "O2": (0.2124, 0.1, 0.9432),
    "O3": (0.2498, 0.378, 0.3937),
}
for atom in mnwo4.atoms():
    atom.coordinates = mnwo4_parent[atom.label]
    atom.uiso = 0.005

# Choose a physical specimen displacement and compensate the common zero so
# that the current peak alignment is retained before recalibration.
hist.data["Sample Parameters"]["Shift"] = [-700.0, False]
hist.data["Instrument Parameters"][0]["Zero"][1] = -0.030
hist.data["Instrument Parameters"][0]["U"][1] = 5.0

# Shared peak positions and scales; fixing Shift avoids its near-perfect
# correlation with Zero and the three lattice scales.
hist.set_refinements({"Instrument Parameters": ["Zero"]})
for phase in project.phases():
    phase.data["General"]["Cell"][0] = True
refine(project, "01_cells_zero_scales", 20)

# Common instrumental width/asymmetry plus phase-specific isotropic profiles.
hist.set_refinements({"Instrument Parameters": ["W", "SH/L"]})
for phase in project.phases():
    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }
    )
refine(project, "02_isotropic_profiles", 24)

# Refine coordinates one accepted phase at a time. Heavy scatterers precede O.
for phase in project.phases():
    for atom in phase.atoms():
        atom.refinement_flags = ""
for atom in mnwo4.atoms():
    if atom.element != "O":
        atom.refinement_flags = "X"
refine(project, "03_mnwo4_heavy", 16)
for atom in mnwo4.atoms():
    atom.refinement_flags = "X"
refine(project, "04_mnwo4_all_coordinates", 20)

for atom in mnwo4.atoms():
    atom.refinement_flags = ""
for atom in mn3wo6.atoms():
    atom.refinement_flags = "X" if atom.element != "O" else ""
refine(project, "05_mn3wo6_heavy", 16)
for atom in mn3wo6.atoms():
    atom.refinement_flags = "X"
refine(project, "06_mn3wo6_all_coordinates", 20)

for atom in mn3wo6.atoms():
    atom.refinement_flags = ""
for atom in wo3.atoms():
    atom.refinement_flags = "X" if atom.element != "O" else ""
refine(project, "07_wo3_heavy", 18)
for atom in wo3.atoms():
    atom.refinement_flags = "X"
refine(project, "08_wo3_all_coordinates", 24)

# Polarization is common to all phases and is best determined after their
# coordinates are stable.
for phase in project.phases():
    for atom in phase.atoms():
        atom.refinement_flags = ""
hist.set_refinements({"Instrument Parameters": ["Polariz."]})
refine(project, "09_polarization", 18)

project.save(str(OUT))
