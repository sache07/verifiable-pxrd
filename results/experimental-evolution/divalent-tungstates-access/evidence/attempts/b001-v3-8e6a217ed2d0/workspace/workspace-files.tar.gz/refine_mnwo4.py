"""Staged GSAS-II refinement for the candidate wolframite MnWO4 phase."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
CHECKPOINTS = ROOT / ".tmp" / "refinement_checkpoints"
CHECKPOINTS.mkdir(parents=True, exist_ok=True)


def snapshot(project: G2.G2Project, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, CHECKPOINTS / f"{label}.gpx")


def summarize(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    hap = phase.data["Histograms"][hist.name]
    result = {
        "stage": label,
        "Rwp_percent": hist.get_wR(),
        "cell": phase.get_cell(),
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) >= 2},
        "sample": {
            k: (v[0] if isinstance(v, list) else v)
            for k, v in hist.data["Sample Parameters"].items()
            if k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"]
        },
        "background": hist.data["Background"][0],
        "hap_scale": hap["Scale"][0],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "xyz": list(atom.coordinates),
                "uiso": atom.uiso,
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ],
    }
    print(json.dumps(result, indent=2, default=float))
    (CHECKPOINTS / f"{label}.json").write_text(json.dumps(result, indent=2, default=float) + "\n")


def refine(project: G2.G2Project, label: str, cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    summarize(project, label)
    snapshot(project, label)


G2.SetPrintLevel("warn")
project = G2.G2Project(newgpx=str(ROOT / "working.gpx"))
hist = project.add_powder_histogram(
    str(ROOT / "pattern.xye"), str(ROOT / "instrument.instprm"), fmthint="xye"
)
phase = project.add_phase(
    str(ROOT / "mnwo4_start.cif"),
    phasename="MnWO4_wolframite",
    histograms=[hist],
    fmthint="CIF",
)

# Use the phase scale as the sole intensity scale. Initialize specimen position
# from the diagnostic peak displacement so the first scale refinement is stable.
sample = hist.data["Sample Parameters"]
sample["Scale"] = [1.0, False]
sample["Type"] = "Bragg-Brentano"
sample["Gonio. radius"] = 200.0
sample["Shift"] = [-550.0, False]
sample["Transparency"] = [0.0, False]
sample["SurfRoughA"] = [0.0, False]
sample["SurfRoughB"] = [0.0, False]

hap = phase.data["Histograms"][hist.name]
hap["Scale"] = [1.0, True]
hap["Size"][0] = "isotropic"
hap["Size"][1][0] = 0.3
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][0] = 1000.0

hist.set_refinements(
    {
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 8,
            "coeffs": [1400.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            "refine": True,
        }
    }
)
snapshot(project, "00_initial")

refine(project, "01_scale_background", 10)

# Peak-position calibration, then lattice adjustment.
hist.set_refinements({"Instrument Parameters": ["Zero"]})
hist.set_refinements({"Sample Parameters": ["Shift"]})
refine(project, "02_zero_shift", 12)

phase.set_refinements({"Cell": True})
refine(project, "03_cell", 12)

# Match the symmetric instrumental profile and isotropic specimen broadening.
hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
phase.set_HAP_refinements(
    {
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    }
)
refine(project, "04_profile", 16)

# Refine the heavy-atom coordinates first, followed by oxygen coordinates and a
# common isotropic displacement model (the synthetic references use Uiso).
phase.set_refinements({"Atoms": {"Mn0": "X", "W1": "X"}})
refine(project, "05_heavy_coordinates", 12)

phase.set_refinements({"Atoms": {"O2": "X", "O3": "X"}})
refine(project, "06_oxygen_coordinates", 16)

phase.set_refinements({"Atoms": {"all": "XU"}})
hist.set_refinements({"Instrument Parameters": ["Polariz."]})
refine(project, "07_coordinates_uiso_polarization", 18)

project.save(str(ROOT / "working.gpx"))
