"""Add one candidate to the accepted MnWO4 project and refine it comparably."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_flags(project: G2.G2Project) -> None:
    for hist in project.histograms():
        hist.data["Background"][0][1] = True
        for value in hist.data["Instrument Parameters"][0].values():
            if isinstance(value, list) and len(value) >= 3:
                value[2] = False
        for value in hist.data["Sample Parameters"].values():
            if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
                value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
        for hap in phase.data.get("Histograms", {}).values():
            hap["Scale"][1] = True
            hap["Pref.Ori."][2] = False
            hap["Extinction"][1] = False
            hap["Size"][2] = [False for _ in hap["Size"][2]]
            hap["Size"][5] = [False for _ in hap["Size"][5]]
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
            hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]


def stage(project: G2.G2Project, cycles: int = 12) -> float:
    project.set_Controls("cycles", cycles)
    project.refine()
    return float(project.histogram(0).get_wR())


parser = argparse.ArgumentParser()
parser.add_argument("candidate", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--base", type=Path, default=Path(".tmp/refinement_checkpoints/06_oxygen_coordinates.gpx"))
args = parser.parse_args()
args.output.parent.mkdir(parents=True, exist_ok=True)

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.base.resolve()), newgpx=str(args.output.resolve()))
clear_flags(project)
hist = project.histogram(0)
candidate = project.add_phase(
    str(args.candidate.resolve()),
    phasename=args.candidate.stem,
    histograms=[hist],
    fmthint="CIF",
)
hap = candidate.data["Histograms"][hist.name]
hap["Scale"] = [25.0, True]
hap["Size"][0] = "isotropic"
hap["Size"][1][0] = 0.2
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][0] = 3000.0

result = {"candidate": str(args.candidate), "stages": []}
result["stages"].append({"name": "scale", "Rwp_percent": stage(project, 12)})

candidate.data["General"]["Cell"][0] = True
result["stages"].append({"name": "cell", "Rwp_percent": stage(project, 16)})

candidate.set_HAP_refinements(
    {
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    }
)
result["stages"].append({"name": "profile", "Rwp_percent": stage(project, 16)})

for atom in candidate.atoms():
    atom.refinement_flags = "X"
result["stages"].append({"name": "coordinates", "Rwp_percent": stage(project, 16)})

result.update(
    scale=float(hap["Scale"][0]),
    cell=candidate.get_cell(),
    size=hap["Size"],
    mustrain=hap["Mustrain"],
    atoms=[
        {"label": a.label, "element": a.element, "xyz": list(a.coordinates), "uiso": a.uiso}
        for a in candidate.atoms()
    ],
)
project.save(str(args.output.resolve()))
args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float) + "\n")
print(json.dumps(result, indent=2, default=float))
