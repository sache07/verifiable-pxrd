"""Export the saved atomic models from a GSAS-II project for diagnostics."""

from pathlib import Path
import argparse

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("project", type=Path)
parser.add_argument("output_dir", type=Path)
args = parser.parse_args()

args.output_dir.mkdir(parents=True, exist_ok=True)
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.project.resolve()))
# Avoid substituting stale covariance values for the full-precision saved atoms.
project.data["Covariance"]["data"] = {}
for index, phase in enumerate(project.phases(), start=1):
    phase.export_CIF(str((args.output_dir / f"phase_{index}.cif").resolve()))
