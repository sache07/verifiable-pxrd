from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter1d, percentile_filter
from scipy.signal import find_peaks, peak_widths


pattern = pd.read_csv("inputs/pattern.csv")
x = pattern["two_theta_deg"].to_numpy(float)
y = pattern["intensity"].to_numpy(float)
step = float(np.median(np.diff(x)))

# A broad lower-envelope estimate is used only for finding peaks, not fitting.
baseline = percentile_filter(y, percentile=20, size=401, mode="nearest")
signal = gaussian_filter1d(y - baseline, 1.2)
peaks, props = find_peaks(signal, prominence=80, distance=max(1, round(0.08 / step)))
width_samples = peak_widths(signal, peaks, rel_height=0.5)[0]
rows = []
for i, p in enumerate(peaks):
    rows.append(
        {
            "two_theta_deg": x[p],
            "height_above_baseline": signal[p],
            "prominence": props["prominences"][i],
            "fwhm_deg_approx": width_samples[i] * step,
        }
    )
peaks_df = pd.DataFrame(rows).sort_values("prominence", ascending=False)
print(peaks_df.head(100).to_string(index=False, formatters={
    "two_theta_deg": "{:.5f}".format,
    "height_above_baseline": "{:.1f}".format,
    "prominence": "{:.1f}".format,
    "fwhm_deg_approx": "{:.3f}".format,
}))

fig, ax = plt.subplots(figsize=(15, 6))
ax.plot(x, y, lw=0.55, color="black")
ax.plot(x, baseline, lw=0.8, color="tab:orange")
ax.set(xlabel=r"$2\theta$ (deg, Cu K$\alpha$)", ylabel="Counts", xlim=(x[0], x[-1]))
fig.tight_layout()
fig.savefig("pattern_overview.png", dpi=180)
