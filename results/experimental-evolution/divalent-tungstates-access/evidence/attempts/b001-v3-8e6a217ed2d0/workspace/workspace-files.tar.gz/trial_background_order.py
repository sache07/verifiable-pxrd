"""Test a smooth Chebyshev background order with stable profile replay."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("base", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("order", type=int)
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.base.resolve()),
                       newgpx=str(args.output.resolve()))
for phase in project.phases():
    for atom in phase.atoms():
        atom.refinement_flags = ""
hist = project.histogram(0)
hist.set_refinements({"Background": {
    "type": "chebyschev-1", "no. coeffs": args.order, "refine": True,
}})
controls = project.data["Controls"]["data"]
controls["parmMinDict"] = {}
controls["parmMaxDict"] = {}
controls["parmFrozen"] = {}
project.set_Controls("cycles", 24)
history = []
for _ in range(4):
    project.refine()
    history.append(float(hist.get_wR()))
project.save(str(args.output.resolve()))
background = hist.data["Background"][0]
result = {
    "order": args.order,
    "Rwp_history_percent": history,
    "background": background,
}
args.output.with_suffix(".json").write_text(
    json.dumps(result, indent=2, default=float) + "\n"
)
print(json.dumps(result, indent=2, default=float))
