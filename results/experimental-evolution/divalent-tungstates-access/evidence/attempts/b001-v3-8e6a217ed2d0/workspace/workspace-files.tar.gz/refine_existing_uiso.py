"""Re-refine existing per-phase equal-Uiso constraints after coordinate work."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("base", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.base.resolve()),
                       newgpx=str(args.output.resolve()))
controls = project.data["Controls"]["data"]
controls["parmMinDict"] = {}
controls["parmMaxDict"] = {}
controls["parmFrozen"] = {}
for phase in project.phases():
    for atom_index, atom in enumerate(phase.atoms()):
        atom.refinement_flags = "U"
        variable = f"{phase.id}::AUiso:{atom_index}"
        project.set_Controls("parmMin", 0.003, variable=variable)
        project.set_Controls("parmMax", 0.020, variable=variable)

project.set_Controls("cycles", 30)
history = []
for _ in range(3):
    project.set_Frozen()
    project.refine()
    history.append(float(project.histogram(0).get_wR()))

for phase in project.phases():
    for atom in phase.atoms():
        atom.refinement_flags = ""
controls["parmMinDict"] = {}
controls["parmMaxDict"] = {}
controls["parmFrozen"] = {}
for _ in range(3):
    project.refine()
    history.append(float(project.histogram(0).get_wR()))

project.save(str(args.output.resolve()))
result = {
    "Rwp_history_percent": history,
    "uiso_A2": {
        phase.name: {atom.label: float(atom.uiso) for atom in phase.atoms()}
        for phase in project.phases()
    },
    "short_distances": {phase.name: phase.ShortDistances()
                        for phase in project.phases()},
}
args.output.with_suffix(".json").write_text(
    json.dumps(result, indent=2, default=float) + "\n"
)
print(json.dumps(result, indent=2, default=float))
