"""Test one physically supported texture, strain anisotropy, or roughness term."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("kind", choices=["texture", "strain", "roughness"])
parser.add_argument("output", type=Path)
parser.add_argument("--phase", type=int, default=0)
parser.add_argument("--axis", default="0,0,1")
parser.add_argument("--base", type=Path, default=Path(".tmp/three_phase_wo3_2311041.gpx"))
parser.add_argument("--cycles", type=int, default=16)
args = parser.parse_args()
axis = [int(v) for v in args.axis.split(",")]

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.base.resolve()), newgpx=str(args.output.resolve()))
hist = project.histogram(0)
for phase in project.phases():
    for atom in phase.atoms():
        atom.refinement_flags = ""
    phase.data["Histograms"][hist.name]["Pref.Ori."][2] = False
controls = project.data["Controls"]["data"]
controls["parmMinDict"] = {}
controls["parmMaxDict"] = {}
controls["parmFrozen"] = {}

if args.kind == "texture":
    phase = project.phase(args.phase)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = axis
elif args.kind == "strain":
    phase = project.phase(args.phase)
    strain = phase.data["Histograms"][hist.name]["Mustrain"]
    value = float(strain[1][0])
    strain[0] = "uniaxial"
    strain[1][0] = value
    strain[1][1] = value
    strain[2][0] = True
    strain[2][1] = True
    strain[3] = axis
elif args.kind == "roughness":
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.2, True]
    sample["SurfRoughB"] = [0.1, True]

project.set_Controls("cycles", args.cycles)
project.refine()
rows = []
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    rows.append(
        {
            "name": phase.name,
            "scale": hap["Scale"][0],
            "texture": hap["Pref.Ori."],
            "mustrain": hap["Mustrain"],
            "size": hap["Size"],
        }
    )
result = {
    "kind": args.kind,
    "phase": args.phase,
    "axis": axis,
    "Rwp_percent": hist.get_wR(),
    "sample": hist.data["Sample Parameters"],
    "phases": rows,
}
project.save(str(args.output.resolve()))
args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float) + "\n")
print(json.dumps(result, indent=2, default=float))
