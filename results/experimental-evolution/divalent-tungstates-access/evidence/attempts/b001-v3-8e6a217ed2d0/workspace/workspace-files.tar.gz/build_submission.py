"""Build replay-consistent submission files from the final GSAS-II project."""

from pathlib import Path
import hashlib
import json
import shutil
import numpy as np


ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / ".tmp" / "final_replay"
PROJECT = ROOT / "final.gpx"
N_VARS = 37

replay = json.loads((REPLAY / "replay.json").read_text())
if replay.get("status") != "replayed":
    raise RuntimeError(f"Final project did not replay: {replay}")
project_hash = hashlib.sha256(PROJECT.read_bytes()).hexdigest()
if project_hash != replay["project_sha256"]:
    raise RuntimeError("Replay does not correspond to final.gpx")

phase_metadata = [
    {
        "name": "Wolframite MnWO4",
        "formula": "MnWO4",
        "space_group": "P2/c",
        "cif_path": "phase_1_MnWO4.cif",
        "identification": "Direct wolframite MnWO4 reference, structurally refined",
    },
    {
        "name": "Monoclinic WO3",
        "formula": "WO3",
        "space_group": "P2_1/c",
        "cif_path": "phase_2_WO3.cif",
        "identification": "Monoclinic WO3 model based on clean COD 2311041 coordinates",
    },
    {
        "name": "Rhombohedral Mn3WO6",
        "formula": "Mn3WO6",
        "space_group": "R-3",
        "cif_path": "phase_3_Mn3WO6.cif",
        "identification": "Mn3TeO6-topology transfer (Te to W), structurally refined",
    },
]

phases = []
for index, (model, replay_phase) in enumerate(zip(phase_metadata, replay["phases"])):
    shutil.copy2(REPLAY / replay_phase["cif"], ROOT / model["cif_path"])
    phases.append({
        **model,
        "weight_fraction": float(replay_phase["weight_fraction"]),
    })

profile = np.load(REPLAY / "prediction.npz")
x = np.asarray(profile["x"], dtype=float)
observed = np.asarray(profile["observed"], dtype=float)
calculated = np.asarray(profile["predicted"], dtype=float)
difference = observed - calculated
np.savetxt(
    ROOT / "fit.csv",
    np.column_stack((x, observed, calculated, difference)),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference_observed_minus_calculated",
    comments="",
    fmt=("%.8f", "%.8f", "%.8f", "%.8f"),
)

weights = 1.0 / np.maximum(observed, 1.0)
chi_square = float(np.sum(weights * difference**2))
rwp = float(100.0 * np.sqrt(chi_square / np.sum(weights * observed**2)))
rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
dof = int(len(observed) - N_VARS)
reduced_chi_square = chi_square / dof
goodness_of_fit = float(np.sqrt(reduced_chi_square))
rexp = rwp / goodness_of_fit

result = {
    "project_path": "final.gpx",
    "fit_profile_path": "fit.csv",
    "refinement_histogram": replay["histogram"],
    "weight_fraction_basis": "normalized over the modeled crystalline phases",
    "phases": phases,
    "unresolved_components": [],
    "fit_statistics": {
        "rwp_percent": rwp,
        "rp_percent": rp,
        "rexp_percent": rexp,
        "chi_square": chi_square,
        "reduced_chi_square": reduced_chi_square,
        "goodness_of_fit": goodness_of_fit,
        "data_points": int(len(observed)),
        "refined_variables": N_VARS,
        "weighting": "Poisson counting weights, w = 1/max(Iobs, 1)",
        "calculation": "independent native GSAS-II full-grid replay; zero parameters optimized",
    },
    "project_sha256": project_hash,
}
(ROOT / "result.json").write_text(
    json.dumps(result, indent=2, allow_nan=False) + "\n"
)
print(json.dumps(result, indent=2))
