"""Test a bounded physical coordinate relaxation around clean WO3 COD 2311041."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


PARENT = {
    "W0": (0.028, 0.537, 0.782), "W1": (0.466, 0.023, 0.216),
    "O2": (0.002, 0.238, 0.214), "O3": (0.206, 0.542, 0.711),
    "O4": (0.225, 0.526, 0.218), "O5": (0.284, 0.043, 0.992),
    "O6": (0.286, 0.013, 0.507), "O7": (0.481, 0.241, 0.770),
}
parser = argparse.ArgumentParser()
parser.add_argument("width", type=float)
parser.add_argument("output", type=Path)
args = parser.parse_args()
base = Path(".tmp/wo3_2311041_stages/01_parent_fixed.gpx").resolve()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(base), newgpx=str(args.output.resolve()))
wo3 = project.phase("wo3_1528915")
for phase in project.phases():
    for atom in phase.atoms():
        atom.refinement_flags = ""
controls = project.data["Controls"]["data"]
controls["parmMinDict"] = {}; controls["parmMaxDict"] = {}; controls["parmFrozen"] = {}
for index, atom in enumerate(wo3.atoms()):
    for axis, value in zip("xyz", PARENT[atom.label]):
        variable = f"{wo3.id}::dA{axis}:{index}"
        project.set_Controls("parmMin", value - args.width, variable=variable)
        project.set_Controls("parmMax", value + args.width, variable=variable)
    atom.refinement_flags = "X"

project.set_Controls("cycles", 28)
history = []
for _ in range(2):
    project.set_Frozen()
    project.refine()
    history.append(float(project.histogram(0).get_wR()))

# Freeze the accepted coordinates and perform a fresh full-grid replay/refit of
# only the remaining active profile parameters.
for atom in wo3.atoms(): atom.refinement_flags = ""
controls["parmMinDict"] = {}; controls["parmMaxDict"] = {}; controls["parmFrozen"] = {}
for _ in range(2):
    project.refine()
    history.append(float(project.histogram(0).get_wR()))

result = {
    "width_fractional": args.width,
    "Rwp_history_percent": history,
    "short_distances": {p.name: p.ShortDistances() for p in project.phases()},
    "coordinates": {p.name: {a.label: list(a.coordinates) for a in p.atoms()} for p in project.phases()},
}
project.save(str(args.output.resolve()))
args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float) + "\n")
print(json.dumps(result, indent=2, default=float))
