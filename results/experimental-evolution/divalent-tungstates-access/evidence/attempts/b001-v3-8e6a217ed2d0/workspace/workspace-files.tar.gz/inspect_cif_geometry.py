"""Report broad geometry diagnostics for one or more CIF files."""

from pathlib import Path
import argparse
import json
import numpy as np
from pymatgen.core import Structure


parser = argparse.ArgumentParser()
parser.add_argument("cifs", nargs="+", type=Path)
args = parser.parse_args()

for path in args.cifs:
    structure = Structure.from_file(path, primitive=False)
    matrix = np.asarray(structure.distance_matrix, dtype=float)
    np.fill_diagonal(matrix, np.inf)
    rows = []
    for i in range(len(structure)):
        for j in range(i + 1, len(structure)):
            rows.append((matrix[i, j], i, j, structure[i].species_string,
                         structure[j].species_string))
    rows.sort()
    by_pair = {}
    for distance, i, j, a, b in rows:
        key = "-".join(sorted((a, b)))
        by_pair.setdefault(key, []).append(distance)
    result = {
        "path": str(path),
        "formula": structure.composition.reduced_formula,
        "density_g_cm3": structure.density,
        "shortest_contacts": [
            {"distance_A": d, "sites": [i, j], "species": [a, b]}
            for d, i, j, a, b in rows[:20]
        ],
        "pair_ranges_below_3A": {
            pair: {
                "minimum_A": min(values),
                "maximum_below_3A": max(v for v in values if v < 3.0),
                "count_below_3A": sum(v < 3.0 for v in values),
            }
            for pair, values in by_pair.items() if min(values) < 3.0
        },
    }
    print(json.dumps(result, indent=2, default=float))
