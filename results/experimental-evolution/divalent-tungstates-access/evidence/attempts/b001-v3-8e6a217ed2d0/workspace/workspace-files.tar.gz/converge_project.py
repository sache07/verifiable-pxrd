"""Replay repeated GSAS-II cycles until a selected model is numerically stable."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("input", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--repeats", type=int, default=5)
parser.add_argument("--cycles", type=int, default=20)
parser.add_argument("--keep-atom-flags", action="store_true")
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
if not args.keep_atom_flags:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = ""
controls = project.data["Controls"]["data"]
controls["parmMinDict"] = {}
controls["parmMaxDict"] = {}
controls["parmFrozen"] = {}
project.set_Controls("cycles", args.cycles)
history = []
for index in range(args.repeats):
    project.refine()
    history.append(float(project.histogram(0).get_wR()))
    print(index + 1, history[-1])
project.save(str(args.output.resolve()))
result = {"Rwp_history_percent": history, "output": str(args.output)}
args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
