#!/usr/bin/env python3
"""Test the laboratory's permitted March-Dollase axes one phase at a time."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def clear_flags(project, hist) -> None:
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(project, hist) -> dict[str, float]:
    weighted = {
        phase.name: max(
            0.0,
            float(phase.data["General"]["Mass"])
            * float(phase.data["Histograms"][hist.name]["Scale"][0]),
        )
        for phase in project.phases()
    }
    total = sum(weighted.values())
    return {key: value / total for key, value in weighted.items()}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("phase")
    parser.add_argument("prefix")
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    source = Path(args.base).resolve()
    prefix = Path(args.prefix).resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    records = []

    baseline = G2.G2Project(gpxfile=str(source))
    records.append({"axis": None, "Rwp_percent": float(baseline.histogram(0).get_wR())})
    for axis in AXES:
        label = "".join(map(str, axis))
        output = prefix.with_name(f"{prefix.name}_{label}.gpx")
        project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
        hist = project.histogram(0)
        clear_flags(project, hist)
        hist.Background[0][1] = True
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = True
            phase.data["Histograms"][hist.name]["Scale"][1] = True
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        project.index_ids()
        pid = phase.data["pId"]
        hid = hist.data["data"][0]["hId"]
        project.set_Controls("parmMin", 0.7, variable=f"{pid}:{hid}:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{pid}:{hid}:MD")
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        cov = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        rec = {
            "axis": axis,
            "Rwp_percent": float(hist.get_wR()),
            "ratio": float(hap["Pref.Ori."][1]),
            "fractions": fractions(project, hist),
            "converged": bool(cov.get("converged", False)),
            "max_shift_esd": cov.get("Max shft/sig"),
            "frozen": [str(item) for item in project.get_Frozen()],
            "project": str(output),
        }
        records.append(rec)
        print(json.dumps(rec), flush=True)
    prefix.with_suffix(".json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
