#!/usr/bin/env python3
"""Build and refine candidate Mn-W-O Rietveld models with GSAS-II."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def clear_frozen(project: G2.G2Project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def mass_fractions(project: G2.G2Project, hist) -> dict[str, float]:
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted[phase.name] = max(
            0.0,
            float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]),
        )
    total = sum(weighted.values())
    return {key: value / total for key, value in weighted.items()} if total else weighted


def state(project: G2.G2Project, hist, label: str) -> dict:
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "stage": label,
        "Rwp_percent": float(hist.get_wR()),
        "GOF": float(cov.get("Rvals", {}).get("GOF", np.nan)),
        "converged": bool(cov.get("Rvals", {}).get("converged", False)),
        "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "fractions": mass_fractions(project, hist),
        "instrument": {
            key: float(value[1])
            for key, value in hist.InstrumentParameters.items()
            if isinstance(value, list) and len(value) > 1 and key in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."}
        },
        "sample": {
            key: float(value[0])
            for key, value in hist.SampleParameters.items()
            if isinstance(value, list) and value and key in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"}
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "profiles": {
            phase.name: {
                "scale": float(phase.data["Histograms"][hist.name]["Scale"][0]),
                "size": phase.data["Histograms"][hist.name]["Size"][:4],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"][:4],
                "preferred_orientation": phase.data["Histograms"][hist.name]["Pref.Ori."][:4],
            }
            for phase in project.phases()
        },
        "frozen": [str(item) for item in project.get_Frozen()],
    }


def refine(project, hist, records: list[dict], label: str, cycles: int = 8) -> None:
    clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    rec = state(project, hist, label)
    records.append(rec)
    stage_path = Path(project.filename).with_name(
        f"{Path(project.filename).stem}.{label}.gpx"
    )
    shutil.copy2(project.filename, stage_path)
    print(json.dumps(rec), flush=True)


def set_bounds(project, hist) -> None:
    project.index_ids()
    hid = hist.data["data"][0]["hId"]
    bounds = {
        f":{hid}:Zero": (-0.30, 0.30),
        f":{hid}:U": (0.0, 40.0),
        f":{hid}:W": (2.0, 40.0),
        f":{hid}:X": (0.1, 6.0),
        f":{hid}:SH/L": (0.005, 0.10),
        f":{hid}:Polariz.": (0.5, 1.0),
        f":{hid}:Shift": (-800.0, 800.0),
        f":{hid}:SurfRoughA": (0.0, 0.65),
        f":{hid}:SurfRoughB": (0.0, 0.55),
    }
    for variable, (lower, upper) in bounds.items():
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    for phase in project.phases():
        pid = phase.data["pId"]
        phase_bounds = {
            f"{pid}:{hid}:Scale": (0.0, 1000.0),
            f"{pid}:{hid}:Size;i": (0.04, 1.5),
            f"{pid}:{hid}:Mustrain;i": (0.0, 8000.0),
            f"{pid}:{hid}:MD": (0.7, 1.4),
        }
        for variable, (lower, upper) in phase_bounds.items():
            project.set_Controls("parmMin", lower, variable=variable)
            project.set_Controls("parmMax", upper, variable=variable)


def build(args) -> tuple[G2.G2Project, object]:
    out = Path(args.output).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(Path(args.pattern).resolve()),
        str(Path(args.instrument).resolve()),
        fmthint="comma/tab/semicolon separated",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": args.background_terms,
            "coeffs": [4000.0] + [0.0] * (args.background_terms - 1),
            "refine": False,
        }
    })
    for index, token in enumerate(args.phases):
        if "=" in token:
            name, source = token.split("=", 1)
        else:
            name, source = token, token
        path = cod_path(source) if source.isdigit() and len(source) == 7 else Path(source)
        if not path.is_file():
            raise FileNotFoundError(path)
        phase = project.add_phase(
            str(path.resolve()),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][1] = 500.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    project.save()
    set_bounds(project, hist)
    project.save()
    return project, hist


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output")
    parser.add_argument("phases", nargs="+", help="NAME=COD_ID or NAME=CIF")
    parser.add_argument("--pattern", default="inputs/pattern.csv")
    parser.add_argument("--instrument", default="instrument.instprm")
    parser.add_argument("--background-terms", type=int, default=12)
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--no-profile", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project, hist = build(args)
    records: list[dict] = []

    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    refine(project, hist, records, "background_scales", 12)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, hist, records, "zero_background_scales", 10)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, hist, records, "zero_shift_background_scales", 10)

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, hist, records, "cells", 12)

    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.clear_refinements({"Sample Parameters": ["Shift"]})

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, hist, records, "instrument_profile", 12)
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})

    if not args.no_profile:
        for phase in project.phases():
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True, "value": 0.5}})
        refine(project, hist, records, "isotropic_sizes", 12)
        for phase in project.phases():
            phase.clear_HAP_refinements({"Size": True})
        for phase in project.phases():
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        refine(project, hist, records, "isotropic_microstrain", 12)
        for phase in project.phases():
            phase.clear_HAP_refinements({"Mustrain": True})

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, hist, records, "polarization", 10)
    hist.clear_refinements({"Instrument Parameters": ["Polariz."]})

    if args.roughness:
        hist.SampleParameters["SurfRoughA"][0] = 0.2
        hist.SampleParameters["SurfRoughB"][0] = 0.05
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        refine(project, hist, records, "surface_roughness", 12)
        hist.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})

    project.save()
    Path(args.output).with_suffix(".summary.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
