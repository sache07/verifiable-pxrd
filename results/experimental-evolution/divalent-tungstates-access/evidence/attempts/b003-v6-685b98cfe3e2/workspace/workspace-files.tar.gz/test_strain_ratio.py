#!/usr/bin/env python3
"""Test bounded uniaxial microstrain ratios for one phase and axis."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


RATIOS = (0.25, 0.5, 1.0, 2.0, 4.0)


def clear_flags(project, hist) -> None:
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("phase")
    parser.add_argument("axis", help="comma-separated h,k,l")
    parser.add_argument("prefix")
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    source = Path(args.base).resolve()
    prefix = Path(args.prefix).resolve()
    axis = [int(item) for item in args.axis.split(",")]
    if len(axis) != 3 or not any(axis):
        raise ValueError("axis must be a nonzero h,k,l triple")
    records = []
    for ratio in RATIOS:
        label = str(ratio).replace(".", "p")
        output = prefix.with_name(f"{prefix.name}_r{label}.gpx")
        project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
        hist = project.histogram(0)
        clear_flags(project, hist)
        hist.Background[0][1] = True
        for item in project.phases():
            item.data["General"]["Cell"][0] = True
            item.data["Histograms"][hist.name]["Scale"][1] = True
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][hist.name]
        initial = float(hap["Mustrain"][1][0])
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = initial
        hap["Mustrain"][1][1] = ratio * initial
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        hap["Mustrain"][3] = list(axis)
        project.index_ids()
        pid = phase.data["pId"]
        hid = hist.data["data"][0]["hId"]
        vi = f"{pid}:{hid}:Mustrain;i"
        va = f"{pid}:{hid}:Mustrain;a"
        # Equivalence convention m_i*i = m_a*a; m_a=1/ratio gives a=ratio*i.
        project.add_EquivConstr((vi, va), (1.0, 1.0 / ratio), reloadIdx=False)
        project.set_Controls("parmMin", 0.0, variable=vi)
        project.set_Controls("parmMax", min(8000.0, 8000.0 / ratio), variable=vi)
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        cov = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        rec = {
            "axis": axis,
            "ratio": ratio,
            "Rwp_percent": float(hist.get_wR()),
            "equatorial_ppm": float(hap["Mustrain"][1][0]),
            "axial_ppm": float(hap["Mustrain"][1][1]),
            "converged": bool(cov.get("converged", False)),
            "max_shift_esd": cov.get("Max shft/sig"),
            "frozen": [str(item) for item in project.get_Frozen()],
            "project": str(output),
        }
        records.append(rec)
        print(json.dumps(rec), flush=True)
    prefix.with_suffix(".json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
