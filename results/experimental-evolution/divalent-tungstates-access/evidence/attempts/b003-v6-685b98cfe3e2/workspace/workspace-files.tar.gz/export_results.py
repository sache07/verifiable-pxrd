#!/usr/bin/env python3
"""Export the required submission artifacts from final.gpx."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


PHASE_INFO = {
    "MnWO4": {
        "formula": "MnWO4",
        "identification": "wolframite-type manganese(II) tungstate, P2/c",
        "source_reference": "COD 1520200 (registration-normalized)",
        "cif_path": "phase_MnWO4.cif",
    },
    "WO3": {
        "formula": "WO3",
        "identification": "monoclinic tungsten(VI) oxide, P21/c",
        "source_reference": "COD 2311041 (registration-normalized)",
        "cif_path": "phase_WO3.cif",
    },
    "Mn3WO6": {
        "formula": "Mn3WO6",
        "identification": "rhombohedral trimanganese tungstate, R-3",
        "source_reference": "COD 2002703 (registration-normalized)",
        "cif_path": "phase_Mn3WO6.cif",
    },
}


def mass_fractions(project, hist):
    try:
        formal = hist.ComputeMassFracs()
    except Exception:
        formal = {}
    weighted = {
        phase.name: max(
            0.0,
            float(phase.data["General"]["Mass"])
            * float(phase.data["Histograms"][hist.name]["Scale"][0]),
        )
        for phase in project.phases()
    }
    total = sum(weighted.values())
    values = {name: value / total for name, value in weighted.items()}
    esds = {
        name: (float(formal[name][1]) if name in formal else None)
        for name in values
    }
    return values, esds


def main() -> None:
    root = Path(__file__).resolve().parent
    project = G2.G2Project(gpxfile=str(root / "final.gpx"))
    histograms = project.histograms()
    if len(histograms) != 1:
        raise RuntimeError("expected exactly one refinement histogram")
    hist = histograms[0]
    x, observed, weights, calculated = [
        np.asarray(item, dtype=float) for item in hist.data["data"][1][:4]
    ]
    difference = observed - calculated
    if not np.all(np.isfinite(calculated)) or np.any(calculated < 0):
        raise RuntimeError("invalid calculated profile")
    np.savetxt(
        root / "fit.csv",
        np.column_stack([x, observed, calculated, difference]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f"],
    )

    fractions, esds = mass_fractions(project, hist)
    rows = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        phase.export_CIF(str(root / info["cif_path"]))
        rows.append({
            "name": phase.name,
            "formula": info["formula"],
            "identification": info["identification"],
            "cif_path": info["cif_path"],
            "weight_fraction": fractions[phase.name],
            "weight_fraction_formal_esd": esds[phase.name],
            "source_reference": info["source_reference"],
        })

    residuals = hist.residuals
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    chi_square = float(np.sum(weights * difference**2))
    n_parameters = len(covariance.get("varyList", []))
    dof = max(1, len(x) - n_parameters)
    fit = {
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": float(residuals.get("R", np.nan)),
        "R_expected_percent": float(residuals.get("wRmin", np.nan)),
        "chi_square": chi_square,
        "reduced_chi_square": chi_square / dof,
        "goodness_of_fit": float(np.sqrt(chi_square / dof)),
        "n_points": int(len(x)),
        "n_refined_parameters_last_cycle": int(n_parameters),
        "converged": bool(rvals.get("converged", False)),
        "maximum_shift_over_esd": (
            None if rvals.get("Max shft/sig") is None
            else float(rvals["Max shft/sig"])
        ),
    }
    result = {
        "phases": rows,
        "fit_statistics": fit,
        "refinement_histogram": hist.name,
        "fraction_basis": "normalized over the three modeled crystalline phases",
        "calibration": {
            "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
            "specimen_shift_um": float(hist.SampleParameters["Shift"][0]),
            "goniometer_radius_mm": float(hist.SampleParameters["Gonio. radius"]),
        },
        "project": "final.gpx",
        "profile": "fit.csv",
    }
    (root / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
