#!/usr/bin/env python3
"""Settle ordinary Rietveld/profile terms before the final coordinate polish."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


def clear_flags(project, hist) -> None:
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def enable_base(project, hist) -> None:
    clear_flags(project, hist)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def fractions(project, hist) -> dict[str, float]:
    weighted = {
        phase.name: max(
            0.0,
            float(phase.data["General"]["Mass"])
            * float(phase.data["Histograms"][hist.name]["Scale"][0]),
        )
        for phase in project.phases()
    }
    total = sum(weighted.values())
    return {key: value / total for key, value in weighted.items()}


def record(project, hist, stage: str) -> dict:
    cov = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "fractions": fractions(project, hist),
        "converged": bool(cov.get("converged", False)),
        "max_shift_esd": cov.get("Max shft/sig"),
        "frozen": [str(item) for item in project.get_Frozen()],
        "instrument": {
            key: float(value[1])
            for key, value in hist.InstrumentParameters.items()
            if key in {"Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}
            and isinstance(value, list) and len(value) > 1
        },
        "sample": {
            key: float(value[0])
            for key, value in hist.SampleParameters.items()
            if key in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"}
            and isinstance(value, list) and value
        },
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "microstrain_ppm": float(phase.data["Histograms"][hist.name]["Mustrain"][1][0]),
                "MD_ratio": float(phase.data["Histograms"][hist.name]["Pref.Ori."][1]),
                "MD_axis": list(phase.data["Histograms"][hist.name]["Pref.Ori."][3]),
                "Uiso_A2": [float(atom.uiso) for atom in phase.atoms()],
            }
            for phase in project.phases()
        },
    }


def run(project, hist, records, stage, cycles=10) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    rec = record(project, hist, stage)
    records.append(rec)
    stage_path = Path(project.filename).with_name(
        f"{Path(project.filename).stem}.{stage}.gpx"
    )
    shutil.copy2(project.filename, stage_path)
    print(json.dumps(rec), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--skip-uiso", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(Path(args.source).resolve()),
        newgpx=str(Path(args.output).resolve()),
    )
    hist = project.histogram(0)
    records = []

    for index in range(2):
        enable_base(project, hist)
        run(project, hist, records, f"settle_{index + 1}", 10)

    enable_base(project, hist)
    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    run(project, hist, records, "sizes", 10)

    enable_base(project, hist)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][2][0] = True
        if hap["Mustrain"][0] == "uniaxial":
            hap["Mustrain"][2][1] = True
    run(project, hist, records, "microstrain", 10)

    enable_base(project, hist)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run(project, hist, records, "instrument", 10)

    enable_base(project, hist)
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    run(project, hist, records, "polarization", 8)

    if not args.skip_uiso:
        # Registration and generation use one isotropic Uiso per phase. Refine
        # exactly that model, with all sites in each phase constrained equal.
        enable_base(project, hist)
        project.index_ids()
        for phase in project.phases():
            pid = phase.data["pId"]
            variables = []
            for index, atom in enumerate(phase.atoms()):
                if atom.adp_flag != "I":
                    raise RuntimeError(f"{phase.name} has a non-isotropic ADP")
                atom.refinement_flags = "U"
                variables.append(f"{pid}::AUiso:{index}")
            if len(variables) > 1:
                project.add_EquivConstr(variables, reloadIdx=False)
            project.set_Controls("parmMin", 0.001, variable=variables[0])
            project.set_Controls("parmMax", 0.03, variable=variables[0])
        run(project, hist, records, "phase_common_Uiso", 10)

    for index in range(2):
        enable_base(project, hist)
        run(project, hist, records, f"final_settle_{index + 1}", 10)

    clear_flags(project, hist)
    project.save()
    Path(args.output).with_suffix(".summary.json").write_text(
        json.dumps(records, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
