#!/usr/bin/env python3
"""Build, refine and inspect the GSAS-II project for this PXRD pattern."""

from __future__ import annotations

import json
import math
import sys
import copy
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PHASES = [
    ("Ba3W2O9", "1533878"),
    ("WO3", "2311041"),
    ("BaCO3", "9010928"),
]


def project_summary(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    result = {
        "residuals": hist.residuals,
        "instrument": {
            key: value[1] if isinstance(value, list) and len(value) > 1 else value
            for key, value in hist.InstrumentParameters.items()
        },
        "sample": {
            key: value[0] if isinstance(value, list) and len(value) > 1 else value
            for key, value in hist.SampleParameters.items()
        },
        "background": hist.Background[0],
        "phases": {},
    }
    try:
        fractions = hist.ComputeMassFracs()
    except Exception as exc:
        fractions = {"error": str(exc)}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "mass": phase.data["General"]["Mass"],
            "scale": hap["Scale"],
            "mass_fraction": fractions.get(phase.name),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": list(atom.coordinates),
                    "uiso": atom.uiso if atom.adp_flag == "I" else None,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    arrays = hist.data["data"][1]
    result["profile"] = {
        "points": len(arrays[0]),
        "yobs_range": [float(np.min(arrays[1])), float(np.max(arrays[1]))],
        "ycalc_range": [float(np.min(arrays[3])), float(np.max(arrays[3]))],
        "background_range": [float(np.min(arrays[4])), float(np.max(arrays[4]))],
    }
    return result


def initialize(output: Path) -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(output))
    phases = [
        project.add_phase(str(cod_path(cod_id)), phasename=name, fmthint="CIF")
        for name, cod_id in PHASES
    ]
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
        phases=phases,
        fmthint="xye",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1200.0] + [0.0] * 11,
                "refine": False,
            },
        }
    )
    # Scale convention is mass fraction / unit-cell mass times a common count factor.
    initial_fractions = [0.65, 0.25, 0.10]
    common_count_scale = 2.0e5
    for phase, fraction in zip(phases, initial_fractions):
        for atom in phase.atoms():
            if atom.adp_flag == "I":
                atom.uiso = 0.01
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [common_count_scale * fraction / phase.data["General"]["Mass"], False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][1][1] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
    project.set_Controls("cycles", 0)
    project.refine()
    project.save()
    print(json.dumps(project_summary(project), indent=2, default=float))


def inspect(project_path: Path) -> None:
    project = G2.G2Project(str(project_path))
    print(json.dumps(project_summary(project), indent=2, default=float))


def dump_profile(project_path: Path, output_path: Path) -> None:
    project = G2.G2Project(str(project_path))
    arrays = project.histogram(0).data["data"][1]
    np.savez_compressed(
        output_path,
        two_theta=np.asarray(arrays[0], float),
        observed=np.asarray(arrays[1], float),
        weight=np.asarray(arrays[2], float),
        calculated=np.asarray(arrays[3], float),
        background=np.asarray(arrays[4], float),
        difference=np.asarray(arrays[5], float),
    )


def run_refinement(input_path: Path, output_path: Path) -> None:
    """Run a conservative sequence from background/scales through peak shapes."""
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(input_path), newgpx=str(output_path))
    hist = project.histogram(0)
    phases = project.phases()
    project.set_Controls("cycles", 8)

    # Correct the deliberately generous initialization before varying scale factors.
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][0] /= 3.0

    records = []

    def step(name: str) -> None:
        project.refine()
        project.save()
        records.append(
            {
                "step": name,
                "residuals": dict(hist.residuals),
                "instrument": {
                    key: value[1]
                    for key, value in hist.InstrumentParameters.items()
                    if isinstance(value, list) and len(value) > 1
                },
                "sample": {
                    key: value[0]
                    for key, value in hist.SampleParameters.items()
                    if isinstance(value, list) and len(value) > 1
                },
                "cells": {phase.name: phase.get_cell() for phase in phases},
                "scales": {
                    phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
                    for phase in phases
                },
            }
        )
        print(json.dumps(records[-1], default=float), flush=True)

    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    step("background_and_phase_scales")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    step("zero_and_cells")

    # U is exactly confounded with common isotropic microstrain and X with
    # Lorentzian size broadening. Keep the nonnegative instrumental minima and
    # let phase-specific terms absorb those sums, which gives a stable profile.
    hist.set_refinements({"Instrument Parameters": ["W", "SH/L"]})
    step("instrument_profile")

    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    step("isotropic_phase_broadening")

    po = phases[0].data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = [1, 1, 0]
    step("Ba3W2O9_preferred_orientation_110")

    for phase, heavy_elements in zip(phases, [{"W"}, {"W"}, {"Ba"}]):
        for atom in phase.atoms():
            if atom.element in heavy_elements:
                atom.refinement_flags = "X"
    step("heavy_atom_coordinates")

    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    step("sample_shift")

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    step("polarization")

    (output_path.with_suffix(".stages.json")).write_text(
        json.dumps(records, indent=2, default=float) + "\n"
    )
    print(json.dumps(project_summary(project), indent=2, default=float))


def test_preferred_orientation(input_path: Path, output_dir: Path, phase_index: int) -> None:
    """Refine each generator-supported March-Dollase axis from one checkpoint."""
    G2.SetPrintLevel("warn")
    output_dir.mkdir(parents=True, exist_ok=True)
    axes = [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]
    trials = [("none", None)] + [("".join(map(str, axis)), axis) for axis in axes]
    results = []
    for label, axis in trials:
        output = output_dir / f"po-{phase_index}-{label}.gpx"
        project = G2.G2Project(str(input_path), newgpx=str(output))
        project.set_Controls("cycles", 12)
        phase = project.phase(phase_index)
        hist = project.histogram(0)
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[1] = 1.0
        po[2] = axis is not None
        if axis is not None:
            po[3] = axis
        project.refine()
        project.save()
        row = {
            "label": label,
            "axis": axis,
            "phase": phase.name,
            "ratio": po[1],
            "wR": hist.residuals.get("wR"),
            "wRb": hist.residuals.get("wRb"),
            "zero": hist.InstrumentParameters["Zero"][1],
            "shift": hist.SampleParameters["Shift"][0],
            "output": str(output),
        }
        results.append(row)
        print(json.dumps(row), flush=True)
    (output_dir / f"po-{phase_index}-results.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )


def refine_coordinates(
    input_path: Path,
    output_path: Path,
    phase_index: int,
    elements: set[str],
    max_fractional_shift: float | None = None,
) -> None:
    """Refine coordinates for selected elements in one phase."""
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(input_path), newgpx=str(output_path))
    phase = project.phase(phase_index)
    selected = []
    for atom_index, atom in enumerate(phase.atoms()):
        if atom.element in elements:
            atom.refinement_flags = "X"
            selected.append(atom.label)
            if max_fractional_shift is not None:
                for component, coordinate in zip("xyz", atom.coordinates):
                    variable = f"{phase_index}::dA{component}:{atom_index}"
                    project.set_Controls(
                        "parmMin", coordinate - max_fractional_shift, variable
                    )
                    project.set_Controls(
                        "parmMax", coordinate + max_fractional_shift, variable
                    )
    if not selected:
        raise ValueError(f"No atoms selected from {phase.name}: {sorted(elements)}")
    project.set_Controls("cycles", 16)
    project.refine()
    project.save()
    result = {
        "phase": phase.name,
        "elements": sorted(elements),
        "atoms": selected,
        "max_fractional_shift": max_fractional_shift,
        "wR": project.histogram(0).residuals.get("wR"),
        "wRb": project.histogram(0).residuals.get("wRb"),
        "coordinates": {
            atom.label: list(atom.coordinates)
            for atom in phase.atoms()
            if atom.label in selected
        },
        "output": str(output_path),
    }
    print(json.dumps(result, indent=2), flush=True)


def test_wo3_parent(input_path: Path, output_path: Path, cod_id: str) -> None:
    """Replace the active WO3 contribution with one COD candidate and refine it."""
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(input_path), newgpx=str(output_path))
    hist = project.histogram(0)
    old = project.phase("WO3")
    old_hap = old.data["Histograms"][hist.name]
    old_hap["Use"] = False
    old_hap["Scale"] = [0.0, False]
    old.set_refinements({"Cell": False})
    for atom in old.atoms():
        atom.refinement_flags = ""

    new = project.add_phase(
        str(cod_path(cod_id)),
        phasename=f"WO3_{cod_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    for atom in new.atoms():
        if atom.adp_flag == "I":
            atom.uiso = 0.01
        if atom.element == "W":
            atom.refinement_flags = "X"
    new_hap = new.data["Histograms"][hist.name]
    old_mass = old.data["General"]["Mass"]
    new_mass = new.data["General"]["Mass"]
    # Preserve the old contribution's approximate mass before rescaling.
    previous_scale = project.phase("Ba3W2O9").data["Histograms"][hist.name]["Scale"][0]
    old_fraction_proxy = 10.5 * old_mass
    new_hap["Scale"] = [old_fraction_proxy / new_mass, True]
    new_hap["Size"] = copy.deepcopy(old_hap["Size"])
    new_hap["Mustrain"] = copy.deepcopy(old_hap["Mustrain"])
    new_hap["Pref.Ori."][0] = "MD"
    new_hap["Pref.Ori."][1] = 1.0
    new_hap["Pref.Ori."][2] = False
    new.set_refinements({"Cell": True})
    new.set_HAP_refinements(
        {
            "Scale": True,
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        [hist],
    )
    project.set_Controls("cycles", 20)
    project.refine()
    project.save()
    dmat = []
    result = {
        "cod_id": cod_id,
        "phase": new.name,
        "space_group": new.data["General"]["SGData"]["SpGrp"],
        "wR": hist.residuals.get("wR"),
        "wRb": hist.residuals.get("wRb"),
        "cell": new.get_cell(),
        "scale": new_hap["Scale"][0],
        "size": new_hap["Size"][1],
        "mustrain": new_hap["Mustrain"][1],
        "W_coordinates": {
            atom.label: list(atom.coordinates)
            for atom in new.atoms()
            if atom.element == "W"
        },
        "output": str(output_path),
    }
    print(json.dumps(result, indent=2), flush=True)


def refine_common_uiso(input_path: Path, output_path: Path) -> None:
    """Refine one symmetry-independent isotropic U value per phase."""
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(input_path), newgpx=str(output_path))
    project.save()
    for phase_index, phase in enumerate(project.phases()):
        atoms = list(phase.atoms())
        variables = [f"{phase_index}::AUiso:{i}" for i in range(len(atoms))]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=(phase_index == 0))
        for atom in atoms:
            atom.refinement_flags = "XU" if "X" in atom.refinement_flags else "U"
    project.set_Controls("cycles", 16)
    project.refine()
    project.save()
    result = {
        "wR": project.histogram(0).residuals.get("wR"),
        "wRb": project.histogram(0).residuals.get("wRb"),
        "uiso": {
            phase.name: [atom.uiso for atom in phase.atoms()]
            for phase in project.phases()
        },
        "output": str(output_path),
    }
    print(json.dumps(result, indent=2), flush=True)


def _lattice_matrix(cell: dict) -> np.ndarray:
    a, b, c = (cell[f"length_{key}"] for key in "abc")
    alpha, beta, gamma = (
        math.radians(cell[f"angle_{key}"])
        for key in ("alpha", "beta", "gamma")
    )
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * math.cos(gamma), b * math.sin(gamma), 0.0])
    cx = c * math.cos(beta)
    cy = c * (math.cos(alpha) - math.cos(beta) * math.cos(gamma)) / math.sin(gamma)
    vc = np.array([cx, cy, math.sqrt(max(0.0, c * c - cx * cx - cy * cy))])
    return np.vstack([va, vb, vc])


def scale_coordinate_rms(
    base_path: Path,
    input_path: Path,
    output_path: Path,
    specifications: list[tuple[int, str, float]],
) -> None:
    """Scale refined displacement directions to physically supported element RMS values."""
    G2.SetPrintLevel("warn")
    base = G2.G2Project(str(base_path))
    project = G2.G2Project(str(input_path), newgpx=str(output_path))
    changes = []
    for phase_index, element, target_rms in specifications:
        parent_phase = base.phase(phase_index)
        phase = project.phase(phase_index)
        lattice = _lattice_matrix(parent_phase.get_cell())
        selected = []
        weighted_sq = 0.0
        weight = 0.0
        for parent_atom, atom in zip(parent_phase.atoms(), phase.atoms()):
            if atom.element != element:
                continue
            delta = np.asarray(atom.coordinates) - np.asarray(parent_atom.coordinates)
            delta -= np.rint(delta)
            distance = float(np.linalg.norm(delta @ lattice))
            weighted_sq += atom.mult * distance * distance
            weight += atom.mult
            selected.append((parent_atom, atom, delta))
        current_rms = math.sqrt(weighted_sq / weight)
        factor = target_rms / current_rms
        for parent_atom, atom, delta in selected:
            atom.coordinates = tuple(np.asarray(parent_atom.coordinates) + factor * delta)
            atom.refinement_flags = atom.refinement_flags.replace("X", "")
        changes.append(
            {
                "phase": phase.name,
                "element": element,
                "initial_rms_A": current_rms,
                "target_rms_A": target_rms,
                "scale_factor": factor,
            }
        )
    project.set_Controls("cycles", 16)
    project.refine()
    project.save()
    result = {
        "wR": project.histogram(0).residuals.get("wR"),
        "wRb": project.histogram(0).residuals.get("wRb"),
        "changes": changes,
        "output": str(output_path),
    }
    print(json.dumps(result, indent=2), flush=True)


def set_fixed_uiso(input_path: Path, output_path: Path, values: list[float]) -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(input_path), newgpx=str(output_path))
    if len(values) != len(project.phases()):
        raise ValueError("Need one Uiso value per phase")
    for phase, value in zip(project.phases(), values):
        for atom in phase.atoms():
            if atom.adp_flag == "I":
                atom.uiso = value
            atom.refinement_flags = atom.refinement_flags.replace("U", "")
    project.set_Controls("cycles", 16)
    project.refine()
    project.save()
    print(
        json.dumps(
            {
                "wR": project.histogram(0).residuals.get("wR"),
                "wRb": project.histogram(0).residuals.get("wRb"),
                "uiso": values,
                "output": str(output_path),
            },
            indent=2,
        ),
        flush=True,
    )


def refine_surface_roughness(
    input_path: Path, output_path: Path, initial_a: float, initial_b: float
) -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(input_path), newgpx=str(output_path))
    hist = project.histogram(0)
    hist.SampleParameters["SurfRoughA"] = [initial_a, True]
    hist.SampleParameters["SurfRoughB"] = [initial_b, True]
    project.set_Controls("cycles", 20)
    project.refine()
    project.save()
    print(
        json.dumps(
            {
                "wR": hist.residuals.get("wR"),
                "wRb": hist.residuals.get("wRb"),
                "SurfRoughA": hist.SampleParameters["SurfRoughA"][0],
                "SurfRoughB": hist.SampleParameters["SurfRoughB"][0],
                "output": str(output_path),
            },
            indent=2,
        ),
        flush=True,
    )


def test_uniaxial_strain(input_path: Path, output_dir: Path, phase_index: int) -> None:
    G2.SetPrintLevel("warn")
    output_dir.mkdir(parents=True, exist_ok=True)
    axes = [[0, 0, 1], [1, 0, 0], [0, 1, 0]]
    trials = [("none", None)] + [("".join(map(str, axis)), axis) for axis in axes]
    results = []
    for label, axis in trials:
        output = output_dir / f"strain-{phase_index}-{label}.gpx"
        project = G2.G2Project(str(input_path), newgpx=str(output))
        phase = project.phase(phase_index)
        hist = project.histogram(0)
        strain = phase.data["Histograms"][hist.name]["Mustrain"]
        if axis is not None:
            isotropic = strain[1][0]
            strain[0] = "uniaxial"
            strain[1][0] = isotropic
            strain[1][1] = isotropic
            strain[2][0] = True
            strain[2][1] = True
            strain[3] = axis
        project.set_Controls("cycles", 16)
        project.refine()
        project.save()
        row = {
            "label": label,
            "axis": axis,
            "phase": phase.name,
            "equatorial_ppm": strain[1][0],
            "axial_ppm": strain[1][1],
            "wR": hist.residuals.get("wR"),
            "wRb": hist.residuals.get("wRb"),
            "output": str(output),
        }
        results.append(row)
        print(json.dumps(row), flush=True)
    (output_dir / f"strain-{phase_index}-results.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )


def main() -> None:
    if len(sys.argv) < 3 or sys.argv[1] not in {
        "init", "inspect", "run", "profile", "test-po", "coords", "test-wo3",
        "uiso"
        , "scale-coords", "fix-uiso", "surface", "test-strain"
    }:
        raise SystemExit(
            "usage: refine_gsas.py {init|inspect} PROJECT.gpx | "
            "refine_gsas.py run INPUT.gpx OUTPUT.gpx"
        )
    project_path = Path(sys.argv[2]).resolve()
    if sys.argv[1] == "init":
        initialize(project_path)
    elif sys.argv[1] == "run":
        if len(sys.argv) != 4:
            raise SystemExit("usage: refine_gsas.py run INPUT.gpx OUTPUT.gpx")
        run_refinement(project_path, Path(sys.argv[3]).resolve())
    elif sys.argv[1] == "profile":
        if len(sys.argv) != 4:
            raise SystemExit("usage: refine_gsas.py profile PROJECT.gpx OUTPUT.npz")
        dump_profile(project_path, Path(sys.argv[3]).resolve())
    elif sys.argv[1] == "test-po":
        if len(sys.argv) != 5:
            raise SystemExit(
                "usage: refine_gsas.py test-po PROJECT.gpx OUTPUT_DIR PHASE_INDEX"
            )
        test_preferred_orientation(project_path, Path(sys.argv[3]).resolve(), int(sys.argv[4]))
    elif sys.argv[1] == "coords":
        if len(sys.argv) not in {6, 7}:
            raise SystemExit(
                "usage: refine_gsas.py coords INPUT.gpx OUTPUT.gpx PHASE_INDEX "
                "ELEMENTS [MAX_FRACTIONAL_SHIFT]"
            )
        refine_coordinates(
            project_path,
            Path(sys.argv[3]).resolve(),
            int(sys.argv[4]),
            set(sys.argv[5].split(",")),
            float(sys.argv[6]) if len(sys.argv) == 7 else None,
        )
    elif sys.argv[1] == "test-wo3":
        if len(sys.argv) != 5:
            raise SystemExit(
                "usage: refine_gsas.py test-wo3 INPUT.gpx OUTPUT.gpx COD_ID"
            )
        test_wo3_parent(project_path, Path(sys.argv[3]).resolve(), sys.argv[4])
    elif sys.argv[1] == "uiso":
        if len(sys.argv) != 4:
            raise SystemExit("usage: refine_gsas.py uiso INPUT.gpx OUTPUT.gpx")
        refine_common_uiso(project_path, Path(sys.argv[3]).resolve())
    elif sys.argv[1] == "scale-coords":
        if len(sys.argv) < 6:
            raise SystemExit(
                "usage: refine_gsas.py scale-coords BASE.gpx INPUT.gpx OUTPUT.gpx "
                "PHASE:ELEMENT:RMS [...]"
            )
        specs = []
        for raw in sys.argv[5:]:
            phase, element, rms = raw.split(":")
            specs.append((int(phase), element, float(rms)))
        scale_coordinate_rms(
            Path(sys.argv[2]).resolve(),
            Path(sys.argv[3]).resolve(),
            Path(sys.argv[4]).resolve(),
            specs,
        )
    elif sys.argv[1] == "fix-uiso":
        if len(sys.argv) != 5:
            raise SystemExit(
                "usage: refine_gsas.py fix-uiso INPUT.gpx OUTPUT.gpx U0,U1,U2"
            )
        set_fixed_uiso(
            Path(sys.argv[2]).resolve(),
            Path(sys.argv[3]).resolve(),
            [float(value) for value in sys.argv[4].split(",")],
        )
    elif sys.argv[1] == "surface":
        if len(sys.argv) != 6:
            raise SystemExit(
                "usage: refine_gsas.py surface INPUT.gpx OUTPUT.gpx A B"
            )
        refine_surface_roughness(
            Path(sys.argv[2]).resolve(),
            Path(sys.argv[3]).resolve(),
            float(sys.argv[4]),
            float(sys.argv[5]),
        )
    elif sys.argv[1] == "test-strain":
        if len(sys.argv) != 5:
            raise SystemExit(
                "usage: refine_gsas.py test-strain INPUT.gpx OUTPUT_DIR PHASE_INDEX"
            )
        test_uniaxial_strain(
            Path(sys.argv[2]).resolve(), Path(sys.argv[3]).resolve(), int(sys.argv[4])
        )
    else:
        inspect(project_path)


if __name__ == "__main__":
    main()
