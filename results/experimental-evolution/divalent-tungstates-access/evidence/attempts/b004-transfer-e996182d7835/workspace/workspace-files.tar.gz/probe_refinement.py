#!/usr/bin/env python3
"""Small, reproducible GSAS-II refinement probes used to select the final model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def set_bound(project: G2.G2Project, variable: str, lower: float, upper: float) -> None:
    project.set_Controls("parmMin", lower, variable)
    project.set_Controls("parmMax", upper, variable)


def summarize(project: G2.G2Project, output: Path) -> None:
    hist = project.histogram(0)
    rows = []
    fractions = hist.ComputeMassFracs()
    for index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        rows.append(
            {
                "index": index,
                "name": phase.name,
                "fraction": fractions.get(phase.name),
                "scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "uiso": [atom.uiso for atom in phase.atoms()],
            }
        )
    print(
        json.dumps(
            {
                "output": str(output),
                "wR": hist.residuals.get("wR"),
                "wRb": hist.residuals.get("wRb"),
                "limits": hist.data["Limits"],
                "zero": hist.InstrumentParameters["Zero"],
                "polarization": hist.InstrumentParameters["Polariz."],
                "W": hist.InstrumentParameters["W"],
                "SH/L": hist.InstrumentParameters["SH/L"],
                "shift": hist.SampleParameters["Shift"],
                "surface_A": hist.SampleParameters["SurfRoughA"],
                "surface_B": hist.SampleParameters["SurfRoughB"],
                "phases": rows,
                "vary_list": project.data.get("Covariance", {})
                .get("data", {})
                .get("varyList", []),
            },
            indent=2,
            default=float,
        ),
        flush=True,
    )


def load_copy(source: Path, output: Path) -> G2.G2Project:
    G2.SetPrintLevel("warn")
    return G2.G2Project(str(source), newgpx=str(output))


def common_bounds(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    set_bound(project, ":0:Zero", -0.25, 0.25)
    set_bound(project, ":0:Shift", -800.0, 800.0)
    set_bound(project, ":0:Polariz.", 0.5, 1.0)
    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:SH/L", 0.005, 0.1)
    for index, _phase in enumerate(project.phases()):
        set_bound(project, f"{index}:0:Scale", 1.0e-9, 1.0e6)
        set_bound(project, f"{index}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{index}:0:Mustrain;i", 0.0, 8000.0)
        set_bound(project, f"{index}:0:MD", 0.7, 1.4)


def refine_zero(
    source: Path, output: Path, full_range: bool, initial_shift: float | None
) -> None:
    project = load_copy(source, output)
    hist = project.histogram(0)
    common_bounds(project)
    if initial_shift is not None:
        hist.SampleParameters["Shift"][0] = initial_shift
    hist.SampleParameters["Shift"][1] = True
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    if full_range:
        x = hist.data["data"][1][0]
        hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    project.set_Controls("cycles", 24)
    project.refine()
    project.save()
    summarize(project, output)


def refine_fixed_shift(source: Path, output: Path, shift: float) -> None:
    """Refine the zero/cells with specimen displacement held at a trial value."""
    project = load_copy(source, output)
    hist = project.histogram(0)
    common_bounds(project)
    hist.SampleParameters["Shift"] = [shift, False]
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Controls("cycles", 16)
    project.refine()
    project.save()
    summarize(project, output)


def refine_full_range(source: Path, output: Path) -> None:
    """Extend the refinement to every measured bin without changing model flags."""
    project = load_copy(source, output)
    hist = project.histogram(0)
    common_bounds(project)
    x = hist.data["data"][1][0]
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    project.set_Controls("cycles", 20)
    project.refine()
    project.save()
    summarize(project, output)


def fixed_surface(source: Path, output: Path, a: float, b: float) -> None:
    project = load_copy(source, output)
    hist = project.histogram(0)
    common_bounds(project)
    hist.SampleParameters["SurfRoughA"] = [a, False]
    hist.SampleParameters["SurfRoughB"] = [b, False]
    project.set_Controls("cycles", 20)
    project.refine()
    project.save()
    summarize(project, output)


def fixed_uiso(source: Path, output: Path, values: list[float]) -> None:
    project = load_copy(source, output)
    if len(values) != len(project.phases()):
        raise ValueError("Need one Uiso value per phase")
    common_bounds(project)
    for phase, value in zip(project.phases(), values):
        for atom in phase.atoms():
            if atom.adp_flag == "I":
                atom.uiso = value
            atom.refinement_flags = atom.refinement_flags.replace("U", "")
    project.set_Controls("cycles", 20)
    project.refine()
    project.save()
    summarize(project, output)


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="mode", required=True)
    zero = sub.add_parser("zero")
    zero.add_argument("source", type=Path)
    zero.add_argument("output", type=Path)
    zero.add_argument("--full-range", action="store_true")
    zero.add_argument("--initial-shift", type=float)
    surface = sub.add_parser("surface")
    surface.add_argument("source", type=Path)
    surface.add_argument("output", type=Path)
    surface.add_argument("a", type=float)
    surface.add_argument("b", type=float)
    uiso = sub.add_parser("uiso")
    uiso.add_argument("source", type=Path)
    uiso.add_argument("output", type=Path)
    uiso.add_argument("values")
    shift = sub.add_parser("fixed-shift")
    shift.add_argument("source", type=Path)
    shift.add_argument("output", type=Path)
    shift.add_argument("value", type=float)
    full = sub.add_parser("full-range")
    full.add_argument("source", type=Path)
    full.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.mode == "zero":
        refine_zero(
            args.source.resolve(),
            args.output.resolve(),
            args.full_range,
            args.initial_shift,
        )
    elif args.mode == "surface":
        fixed_surface(args.source.resolve(), args.output.resolve(), args.a, args.b)
    elif args.mode == "uiso":
        fixed_uiso(
            args.source.resolve(),
            args.output.resolve(),
            [float(value) for value in args.values.split(",")],
        )
    elif args.mode == "fixed-shift":
        refine_fixed_shift(args.source.resolve(), args.output.resolve(), args.value)
    else:
        refine_full_range(args.source.resolve(), args.output.resolve())


if __name__ == "__main__":
    main()
