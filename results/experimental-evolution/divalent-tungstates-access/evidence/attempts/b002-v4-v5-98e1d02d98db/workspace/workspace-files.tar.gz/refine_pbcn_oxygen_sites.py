#!/usr/bin/env python3
"""Limited, geometry-screenable Pbcn oxygen-site refinements."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "branches/mn2wo6_serious/Pbcn/checkpoint_04_heavy.gpx"
OUT = ROOT / "branches/mn2wo6_serious/Pbcn_oxygen_sites"
OUT.mkdir(parents=True, exist_ok=True)


def set_bound(gpx, variable, low, high):
    gpx.set_Controls("parmMin", float(low), variable=variable)
    gpx.set_Controls("parmMax", float(high), variable=variable)


def run(label):
    branch = OUT / label
    branch.mkdir(exist_ok=True)
    path = branch / "model.gpx"
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(path))
    for phase in gpx.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    candidate = gpx.phase(2)
    atom = candidate.atom(label)
    atom.refinement_flags = "X"
    atoms = list(candidate.atoms())
    index = next(i for i, value in enumerate(atoms) if value.label == label)
    for axis, value in zip("xyz", atom.coordinates):
        set_bound(
            gpx,
            f"{candidate.id}::dA{axis}:{index}",
            float(value) - 0.015,
            float(value) + 0.015,
        )
    gpx.set_Controls("cycles", 20)
    previous = sum(len(v) for v in gpx.get_Controls("parmFrozen").values())
    for _ in range(5):
        gpx.refine()
        current = sum(len(v) for v in gpx.get_Controls("parmFrozen").values())
        if current == previous:
            break
        previous = current
    gpx.save()
    replay_path = branch / "replay.gpx"
    shutil.copy2(path, replay_path)
    replay = G2sc.G2Project(str(replay_path))
    replay.set_Controls("cycles", 0)
    replay.refine()
    delta = abs(gpx.histogram(0).get_wR() - replay.histogram(0).get_wR())
    if delta > 1.0e-3:
        raise RuntimeError(f"{label} does not replay ({delta}%)")
    cif = branch / "Mn2WO6_Pbcn.cif"
    candidate.export_CIF(str(cif))
    result = {
        "site": label,
        "wR_percent": float(gpx.histogram(0).get_wR()),
        "scale": float(candidate.data["Histograms"][gpx.histogram(0).name]["Scale"][0]),
        "cell": candidate.get_cell(),
        "cif": str(cif.relative_to(ROOT)),
        "gpx": str(path.relative_to(ROOT)),
    }
    (branch / "summary.json").write_text(json.dumps(result, indent=2))
    print(label, result)
    return result


G2sc.SetPrintLevel("error")
results = [run(label) for label in ("O1", "O2", "O3")]
(OUT / "comparison.json").write_text(json.dumps(results, indent=2))
