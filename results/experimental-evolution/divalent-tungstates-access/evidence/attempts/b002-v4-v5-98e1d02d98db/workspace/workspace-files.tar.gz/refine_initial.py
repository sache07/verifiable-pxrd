#!/usr/bin/env python3
"""Build and stage-refine the first physical MnWO4 GSAS-II checkpoint."""

from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
REF_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)
MNWO4 = REF_ROOT / "1/52/02/1520200.cif"
CHECKPOINTS = ROOT / "checkpoints"
CHECKPOINTS.mkdir(exist_ok=True)


def summarize(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    hap = phase.data["Histograms"][hist.name]
    out = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "cell": phase.get_cell(),
        "instrument": {
            key: inst[key][1]
            for key in (
                "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z",
                "SH/L", "I(L2)/I(L1)"
            )
            if key in inst
        },
        "sample": {
            key: sample[key][0]
            for key in ("Shift", "SurfRoughA", "SurfRoughB")
            if key in sample
        },
        "phase_scale": hap["Scale"][0],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "xyz": [float(v) for v in atom.coordinates],
                "occupancy": float(atom.occupancy),
                "adp_flag": atom.adp_flag,
                "adp": atom.ADP,
                "refinement_flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ],
    }
    print(json.dumps(out, indent=2, default=str))


def checkpoint(project, name):
    path = CHECKPOINTS / f"{name}.gpx"
    project.save(str(path))
    summarize(project, name)
    return path


G2sc.SetPrintLevel("warn")
gpx_path = CHECKPOINTS / "mnwo4_work.gpx"
gpx = G2sc.G2Project(newgpx=str(gpx_path))
hist = gpx.add_powder_histogram(
    str(ROOT / "inputs/pattern.csv"),
    str(ROOT / "instrument.instprm"),
    fmthint="comma",
)
# The histogram scale and phase scale are exactly correlated. Keep the former
# fixed and refine phase scale(s), which is also what quantitative phase
# analysis requires for a later multiphase model.
hist.SampleParameters["Scale"] = [1.0, False]
phase = gpx.add_phase(
    str(MNWO4), phasename="MnWO4_wolframite", histograms=[hist]
)
gpx.set_Controls("cycles", 12)
hist.set_refinements({"Limits": [10.0, 100.05]})

# A smooth background plus phase scale is enough to establish a complete,
# replayable physical checkpoint before testing optional residual branches.
hist.set_refinements(
    {
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 12,
        }
    }
)
phase.set_HAP_refinements({"Scale": True})
gpx.refine()
checkpoint(gpx, "01_scale_background")

# Refine phase cell and the two physically distinct position corrections.
phase.set_refinements({"Cell": True})
hist.set_refinements(
    {
        "Instrument Parameters": ["Zero"],
        "Sample Parameters": ["Shift"],
    }
)
gpx.refine()
checkpoint(gpx, "02_cell_zero_shift")

# Instrument broadening terms supported by the laboratory model. V and Y are
# retained at zero initially to limit parameter covariance.
hist.set_refinements(
    {"Instrument Parameters": ["U", "W", "X", "SH/L"]}
)
gpx.refine()
checkpoint(gpx, "03_instrument_profile")

# Phase-specific isotropic size and strain are the conservative first specimen
# model. Anisotropy is considered only after residual mapping.
phase.set_HAP_refinements(
    {
        "Size": {"type": "isotropic", "value": 1.0, "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    }
)
gpx.refine()
checkpoint(gpx, "04_physical_initial")

# Export arrays for objective residual/peak-family analysis.
arr = np.column_stack(
    [
        hist.getdata("X"),
        hist.getdata("Yobs"),
        hist.getdata("Ycalc"),
        hist.getdata("Background"),
        hist.getdata("Residual"),
        hist.getdata("Yweight"),
    ]
)
np.savetxt(
    CHECKPOINTS / "04_physical_initial_profile.csv",
    arr,
    delimiter=",",
    header="two_theta_deg,observed,calculated,background,difference,weight",
    comments="",
)
