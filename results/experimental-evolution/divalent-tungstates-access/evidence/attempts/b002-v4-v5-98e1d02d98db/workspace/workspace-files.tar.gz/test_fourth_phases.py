#!/usr/bin/env python3
"""Test exact Mn oxide references after the three-phase model is closed."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
REF = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)
SOURCE = ROOT / "branches/mn2wo6_serious/Pbcn_oxygen_sites/O3/model.gpx"
OUT = ROOT / "branches/fourth_phase_tests"
OUT.mkdir(parents=True, exist_ok=True)


def cif(cid):
    return REF / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


CANDIDATES = {
    "Mn3O4_hausmannite": cif("9001963"),
    "MnO_manganosite": cif("1514108"),
    "Mn2O3_bixbyite": cif("1514230"),
}


def bound(gpx, variable, low, high):
    gpx.set_Controls("parmMin", float(low), variable=variable)
    gpx.set_Controls("parmMax", float(high), variable=variable)


def refine_stable(gpx):
    prior_n = sum(len(v) for v in gpx.get_Controls("parmFrozen").values())
    prior_wr = None
    for _ in range(6):
        gpx.refine()
        n = sum(len(v) for v in gpx.get_Controls("parmFrozen").values())
        wr = float(gpx.histogram(0).get_wR())
        if n == prior_n and prior_wr is not None and abs(wr - prior_wr) < 1e-4:
            return
        prior_n, prior_wr = n, wr


def replay_check(path):
    target = path.with_name(path.stem + "_replay.gpx")
    shutil.copy2(path, target)
    p = G2sc.G2Project(str(target))
    before = float(p.histogram(0).get_wR())
    p.set_Controls("cycles", 0)
    p.refine()
    after = float(p.histogram(0).get_wR())
    return before, after, abs(after - before)


def run(label, phase_cif):
    branch = OUT / label
    branch.mkdir(exist_ok=True)
    path = branch / "model.gpx"
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(path))
    hist = gpx.histogram(0)
    # Keep the accepted reflection positions and widths fixed while testing a
    # fourth identity. Scales, smooth background, and displacement stay live.
    for phase in gpx.phases():
        phase.clear_refinements({"Cell": True})
        phase.data["Histograms"][hist.name]["Size"][2][0] = False
        phase.data["Histograms"][hist.name]["Mustrain"][2][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
    candidate = gpx.add_phase(str(phase_cif), phasename=label, histograms=[hist])
    candidate.data["Histograms"][hist.name]["Scale"] = [1.0, True]
    candidate.data["Histograms"][hist.name]["Size"] = [
        "isotropic", [0.05, 1.0, 1.0], [False, False, False], [0, 0, 1],
        [1.0, 1.0, 1.0, 0.0, 0.0, 0.0],
        [False, False, False, False, False, False],
    ]
    bound(gpx, f"{candidate.id}:0:Scale", 0.0, 1e5)
    gpx.set_Controls("cycles", 16)
    stages = {}
    refine_stable(gpx)
    stages["scale"] = float(hist.get_wR())

    scale = float(candidate.data["Histograms"][hist.name]["Scale"][0])
    if scale > 1e-8:
        candidate.set_refinements({"Cell": True})
        for i, value in enumerate(G2lat.cell2A(candidate.data["General"]["Cell"][1:7])):
            if abs(value) > 1e-10:
                bound(gpx, f"{candidate.id}::A{i}", value * 0.9, value * 1.1)
        refine_stable(gpx)
        stages["cell"] = float(hist.get_wR())
        candidate.clear_refinements({"Cell": True})
        candidate.data["Histograms"][hist.name]["Size"][2][0] = True
        bound(gpx, f"{candidate.id}:0:Size;i", 0.005, 10.0)
        refine_stable(gpx)
        stages["size"] = float(hist.get_wR())
    gpx.save()
    before, after, delta = replay_check(path)
    if delta > 1e-3:
        raise RuntimeError(f"{label} does not replay: {before} -> {after}")
    scales = {
        phase.name: float(phase.data["Histograms"][hist.name]["Scale"][0])
        for phase in gpx.phases()
    }
    terms = {
        phase.name: scales[phase.name] * float(phase.data["General"]["Mass"])
        for phase in gpx.phases()
    }
    total = sum(terms.values())
    result = {
        "candidate": label,
        "wR_percent": float(hist.get_wR()),
        "stages": stages,
        "scales": scales,
        "weight_fractions": {name: value / total for name, value in terms.items()},
        "candidate_cell": candidate.get_cell(),
        "candidate_size": candidate.data["Histograms"][hist.name]["Size"],
        "replay_delta_wR_percent": delta,
        "gpx": str(path.relative_to(ROOT)),
    }
    (branch / "summary.json").write_text(json.dumps(result, indent=2))
    print(label, result)
    return result


G2sc.SetPrintLevel("error")
results = [run(label, path) for label, path in CANDIDATES.items()]
(OUT / "comparison.json").write_text(json.dumps(results, indent=2))
