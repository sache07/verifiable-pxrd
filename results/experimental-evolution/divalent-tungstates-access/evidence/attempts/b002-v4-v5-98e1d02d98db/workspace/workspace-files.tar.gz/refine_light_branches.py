#!/usr/bin/env python3
"""Refine limited light-atom subsets from the accepted heavy-atom model."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "branches/two_phase_structure/heavy_coordinates/model.gpx"
OUT = ROOT / "branches/two_phase_structure/light_site_tests"
OUT.mkdir(parents=True, exist_ok=True)

TESTS = {
    "mnwo4_O1_O2": {"MnWO4_wolframite": ["O1", "O2"]},
    "wo3_O1": {"WO3_gamma_monoclinic": ["O1"]},
    "wo3_O2": {"WO3_gamma_monoclinic": ["O2"]},
    "wo3_O3": {"WO3_gamma_monoclinic": ["O3"]},
    "wo3_O4": {"WO3_gamma_monoclinic": ["O4"]},
    "wo3_O5": {"WO3_gamma_monoclinic": ["O5"]},
    "wo3_O6": {"WO3_gamma_monoclinic": ["O6"]},
}


def frozen_count(gpx):
    return sum(len(v) for v in gpx.get_Controls("parmFrozen").values())


def refine_stable(gpx, max_passes=4):
    before = frozen_count(gpx)
    for _ in range(max_passes):
        gpx.refine()
        after = frozen_count(gpx)
        if after == before:
            return
        before = after
    raise RuntimeError("parameter clipping did not stabilize")


def run(label, selection):
    branch = OUT / label
    branch.mkdir(exist_ok=True)
    path = branch / "model.gpx"
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(path))
    for phase in gpx.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    for phase_name, labels in selection.items():
        gpx.phase(phase_name).set_refinements(
            {"Atoms": {atom_label: "X" for atom_label in labels}}
        )
    gpx.set_Controls("cycles", 20)
    refine_stable(gpx)
    gpx.save()
    hist = gpx.histogram(0)
    stored_wR = float(hist.get_wR())

    replay_path = branch / "replay_check.gpx"
    shutil.copy2(path, replay_path)
    replay = G2sc.G2Project(str(replay_path))
    replay.set_Controls("cycles", 0)
    replay.refine()
    replay_wR = float(replay.histogram(0).get_wR())
    if abs(replay_wR - stored_wR) > 1.0e-3:
        raise RuntimeError(f"non-replaying branch: {stored_wR} -> {replay_wR}")

    cifs = {}
    for phase in gpx.phases():
        cif = branch / f"{phase.name}.cif"
        phase.export_CIF(str(cif))
        cifs[phase.name] = str(cif.relative_to(ROOT))
    result = {
        "label": label,
        "selection": selection,
        "wR_percent": stored_wR,
        "replay_wR_percent": replay_wR,
        "cifs": cifs,
        "atoms": {
            phase.name: [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": [float(v) for v in atom.coordinates],
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ]
            for phase in gpx.phases()
        },
        "gpx": str(path.relative_to(ROOT)),
    }
    (branch / "summary.json").write_text(json.dumps(result, indent=2))
    print(label, f"wR={stored_wR:.6f}")
    return result


G2sc.SetPrintLevel("error")
results = [run(label, selection) for label, selection in TESTS.items()]
(OUT / "comparison.json").write_text(json.dumps(results, indent=2))
