#!/usr/bin/env python3
"""Comparable serious refinements of the two Mn2WO6 topology transfers."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
SOURCE = (
    ROOT
    / "branches/two_phase_structure/light_site_tests/mnwo4_O1_O2/model.gpx"
)
MODEL_ROOT = ROOT / "branches/models"
OUT = ROOT / "branches/mn2wo6_serious"
OUT.mkdir(parents=True, exist_ok=True)

TOPOLOGIES = {
    "Pbcn": {
        "cif": MODEL_ROOT / "Mn2WO6_Fe2WO6_Pbcn.cif",
        "heavy": ["Mn0", "Mn1", "W1"],
        "oxygen": ["O1", "O2", "O3"],
    },
    "trirutile": {
        "cif": MODEL_ROOT / "Mn2WO6_Cr2WO6_trirutile.cif",
        "heavy": ["Mn0", "W1"],
        "oxygen": ["O1", "O2"],
    },
}


def set_bound(gpx, variable, low, high):
    gpx.set_Controls("parmMin", float(low), variable=variable)
    gpx.set_Controls("parmMax", float(high), variable=variable)


def frozen_count(gpx):
    return sum(len(v) for v in gpx.get_Controls("parmFrozen").values())


def refine_stable(gpx, max_passes=6):
    before = frozen_count(gpx)
    for _ in range(max_passes):
        gpx.refine()
        after = frozen_count(gpx)
        if after == before:
            return
        before = after
    raise RuntimeError("parameter clipping did not stabilize")


def replay_delta(path):
    replay_path = path.with_name(path.stem + "_replay.gpx")
    shutil.copy2(path, replay_path)
    replay = G2sc.G2Project(str(replay_path))
    before = float(replay.histogram(0).get_wR())
    replay.set_Controls("cycles", 0)
    replay.refine()
    after = float(replay.histogram(0).get_wR())
    return before, after, abs(after - before)


def add_cell_bounds(gpx, phase, fraction=0.20):
    cell = phase.data["General"]["Cell"][1:7]
    reciprocal = G2lat.cell2A(cell)
    for index, value in enumerate(reciprocal):
        if abs(value) < 1.0e-10:
            continue
        low, high = sorted((value * (1.0 - fraction), value * (1.0 + fraction)))
        set_bound(gpx, f"{phase.id}::A{index}", low, high)


def add_coordinate_bounds(gpx, phase, labels, half_width):
    atoms = list(phase.atoms())
    for label in labels:
        atom = phase.atom(label)
        index = next(i for i, item in enumerate(atoms) if item.label == label)
        for axis, value in zip("xyz", atom.coordinates):
            set_bound(
                gpx,
                f"{phase.id}::dA{axis}:{index}",
                float(value) - half_width,
                float(value) + half_width,
            )


def record(gpx, branch, stage, stages):
    gpx.save()
    project_copy = branch / f"checkpoint_{stage}.gpx"
    shutil.copy2(gpx.filename, project_copy)
    before, after, delta = replay_delta(project_copy)
    if delta > 1.0e-3:
        raise RuntimeError(f"{stage} does not replay: {before} -> {after}")
    hist = gpx.histogram(0)
    candidate = gpx.phase(2)
    cif_paths = {}
    for phase in gpx.phases():
        cif = branch / f"{stage}_{phase.name}.cif"
        phase.export_CIF(str(cif))
        cif_paths[phase.name] = str(cif.relative_to(ROOT))
    stages[stage] = {
        "wR_percent": float(hist.get_wR()),
        "replay_wR_percent": after,
        "candidate_scale": float(
            candidate.data["Histograms"][hist.name]["Scale"][0]
        ),
        "candidate_cell": candidate.get_cell(),
        "candidate_size": candidate.data["Histograms"][hist.name]["Size"],
        "candidate_atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "xyz": [float(v) for v in atom.coordinates],
                "flags": atom.refinement_flags,
            }
            for atom in candidate.atoms()
        ],
        "cifs": cif_paths,
        "frozen": [
            str(item)
            for values in gpx.get_Controls("parmFrozen").values()
            for item in values
        ],
    }
    print(branch.name, stage, f"wR={hist.get_wR():.6f}", f"scale={stages[stage]['candidate_scale']:.6g}")


def run(label, spec):
    branch = OUT / label
    branch.mkdir(exist_ok=True)
    path = branch / "work.gpx"
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(path))
    hist = gpx.histogram(0)
    for phase in gpx.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    candidate = gpx.add_phase(
        str(spec["cif"]), phasename=f"Mn2WO6_{label}", histograms=[hist]
    )
    # Start near a chemically material abundance. Keeping the scale initially
    # unconstrained lets a topology show whether its best coefficient is
    # genuinely positive before a physical non-negative checkpoint is made.
    candidate.data["Histograms"][hist.name]["Scale"] = [10.0, True]
    gpx.set_Controls("cycles", 16)
    stages = {}
    refine_stable(gpx)
    record(gpx, branch, "01_scale_background", stages)

    candidate.set_refinements({"Cell": True})
    add_cell_bounds(gpx, candidate, 0.20)
    refine_stable(gpx)
    record(gpx, branch, "02_cell", stages)

    candidate.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 0.06, "refine": True}}
    )
    set_bound(gpx, f"{candidate.id}:0:Size;i", 0.005, 10.0)
    refine_stable(gpx)
    record(gpx, branch, "03_size", stages)

    candidate.set_refinements(
        {"Atoms": {atom_label: "X" for atom_label in spec["heavy"]}}
    )
    add_coordinate_bounds(gpx, candidate, spec["heavy"], 0.04)
    refine_stable(gpx)
    record(gpx, branch, "04_heavy", stages)

    for atom in candidate.atoms():
        atom.refinement_flags = " "
    candidate.set_refinements(
        {"Atoms": {atom_label: "X" for atom_label in spec["oxygen"]}}
    )
    add_coordinate_bounds(gpx, candidate, spec["oxygen"], 0.03)
    refine_stable(gpx)
    record(gpx, branch, "05_oxygen", stages)

    # Enforce a physical non-negative scale and recalculate after clipping.
    set_bound(gpx, f"{candidate.id}:0:Scale", 0.0, 1.0e5)
    refine_stable(gpx)
    record(gpx, branch, "06_physical", stages)
    result = {
        "topology": label,
        "parent_model": str(spec["cif"].relative_to(ROOT)),
        "stages": stages,
        "gpx": str(path.relative_to(ROOT)),
    }
    (branch / "summary.json").write_text(json.dumps(result, indent=2))
    return result


G2sc.SetPrintLevel("error")
results = [run(label, spec) for label, spec in TOPOLOGIES.items()]
(OUT / "comparison.json").write_text(json.dumps(results, indent=2))
