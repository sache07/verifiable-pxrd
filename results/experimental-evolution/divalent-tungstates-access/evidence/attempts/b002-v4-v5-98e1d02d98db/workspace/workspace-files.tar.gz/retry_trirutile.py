#!/usr/bin/env python3
"""Complete the trirutile comparison from its last valid cell checkpoint."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BRANCH = ROOT / "branches/mn2wo6_serious/trirutile_retry"
BRANCH.mkdir(parents=True, exist_ok=True)
SOURCE = ROOT / "branches/mn2wo6_serious/trirutile/checkpoint_03_size.gpx"


def set_bound(gpx, variable, low, high):
    gpx.set_Controls("parmMin", float(low), variable=variable)
    gpx.set_Controls("parmMax", float(high), variable=variable)


def frozen_count(gpx):
    return sum(len(v) for v in gpx.get_Controls("parmFrozen").values())


def refine_stable(gpx):
    before = frozen_count(gpx)
    for _ in range(5):
        gpx.refine()
        after = frozen_count(gpx)
        if after == before:
            return
        before = after
    raise RuntimeError("clipping did not stabilize")


def coordinate_bounds(gpx, phase, labels, half_width):
    atoms = list(phase.atoms())
    for label in labels:
        atom = phase.atom(label)
        index = next(i for i, value in enumerate(atoms) if value.label == label)
        for axis, value in zip("xyz", atom.coordinates):
            set_bound(
                gpx,
                f"{phase.id}::dA{axis}:{index}",
                float(value) - half_width,
                float(value) + half_width,
            )


def record(gpx, stage, result):
    gpx.save()
    saved = BRANCH / f"checkpoint_{stage}.gpx"
    shutil.copy2(gpx.filename, saved)
    replay_file = BRANCH / f"replay_{stage}.gpx"
    shutil.copy2(saved, replay_file)
    replay = G2sc.G2Project(str(replay_file))
    before = float(replay.histogram(0).get_wR())
    replay.set_Controls("cycles", 0)
    replay.refine()
    after = float(replay.histogram(0).get_wR())
    if abs(after - before) > 1.0e-3:
        raise RuntimeError(f"{stage} does not replay: {before} -> {after}")
    hist = gpx.histogram(0)
    phase = gpx.phase(2)
    cif = BRANCH / f"{stage}_Mn2WO6_trirutile.cif"
    phase.export_CIF(str(cif))
    result[stage] = {
        "wR_percent": float(hist.get_wR()),
        "scale": float(phase.data["Histograms"][hist.name]["Scale"][0]),
        "cell": phase.get_cell(),
        "size": phase.data["Histograms"][hist.name]["Size"],
        "cif": str(cif.relative_to(ROOT)),
    }
    print(stage, result[stage])


G2sc.SetPrintLevel("error")
path = BRANCH / "work.gpx"
gpx = G2sc.G2Project(str(SOURCE), newgpx=str(path))
gpx.set_Controls("cycles", 16)
candidate = gpx.phase(2)
candidate.clear_refinements({"Cell": True})
for phase in gpx.phases():
    for atom in phase.atoms():
        atom.refinement_flags = " "
result = {}
refine_stable(gpx)
record(gpx, "03_size_replayed", result)

candidate.set_refinements({"Atoms": {"Mn0": "X", "W1": "X"}})
coordinate_bounds(gpx, candidate, ["Mn0", "W1"], 0.04)
refine_stable(gpx)
record(gpx, "04_heavy", result)

for atom in candidate.atoms():
    atom.refinement_flags = " "
candidate.set_refinements({"Atoms": {"O1": "X", "O2": "X"}})
coordinate_bounds(gpx, candidate, ["O1", "O2"], 0.03)
refine_stable(gpx)
record(gpx, "05_oxygen", result)

set_bound(gpx, f"{candidate.id}:0:Scale", 0.0, 1.0e5)
refine_stable(gpx)
record(gpx, "06_physical", result)
(BRANCH / "summary.json").write_text(json.dumps(result, indent=2))
