#!/usr/bin/env python3
"""Consolidate the accepted physical refinement and write deliverables."""

from __future__ import annotations

import csv
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "branches/wo3_texture/100/model.gpx"
OUT = ROOT / "branches/final_with_texture"
WORK = OUT / "work.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "MnWO4_wolframite": {
        "name": "MnWO4 (wolframite)",
        "formula": "MnWO4",
        "space_group": "P 2/c",
        "cif": "phase_1_MnWO4.cif",
        "model_origin": "COD 1520200, exact-composition wolframite reference",
    },
    "WO3_gamma_monoclinic": {
        "name": "gamma-WO3 (monoclinic)",
        "formula": "WO3",
        "space_group": "P 21/c",
        "cif": "phase_2_WO3.cif",
        "model_origin": "COD 2311041, exact-composition gamma-WO3 reference",
    },
    "Mn2WO6_Pbcn": {
        "name": "Mn2WO6 (Pbcn)",
        "formula": "Mn2WO6",
        "space_group": "P b c n",
        "cif": "phase_3_Mn2WO6.cif",
        "model_origin": (
            "Mn-substituted Fe2WO6 Pbcn parent (COD 2310464), then refined"
        ),
    },
    "Mn3O4_hausmannite": {
        "name": "Mn3O4 (hausmannite)",
        "formula": "Mn3O4",
        "space_group": "I 41/a m d",
        "cif": "phase_4_Mn3O4.cif",
        "model_origin": "COD 9001963, exact-composition hausmannite reference",
    },
}


def frozen_count(project: G2sc.G2Project) -> int:
    return sum(len(values) for values in project.get_Controls("parmFrozen").values())


def refine_to_stability(project: G2sc.G2Project, max_passes: int = 8) -> list[float]:
    """Repeat after any bound clipping and until Rwp itself is stable."""
    history: list[float] = []
    previous_frozen = frozen_count(project)
    for _ in range(max_passes):
        project.refine()
        current = float(project.histogram(0).get_wR())
        history.append(current)
        current_frozen = frozen_count(project)
        if (
            len(history) > 1
            and current_frozen == previous_frozen
            and abs(history[-1] - history[-2]) < 1.0e-5
        ):
            break
        previous_frozen = current_frozen
    return history


def molar_mn_to_w(fractions: dict[str, tuple[float, float]]) -> float:
    """Compute bulk Mn:W from normalized crystalline weight fractions."""
    atomic_mass = {"Mn": 54.938044, "W": 183.84, "O": 15.999}
    formula = {
        "MnWO4_wolframite": ({"Mn": 1, "W": 1, "O": 4}),
        "WO3_gamma_monoclinic": ({"W": 1, "O": 3}),
        "Mn2WO6_Pbcn": ({"Mn": 2, "W": 1, "O": 6}),
        "Mn3O4_hausmannite": ({"Mn": 3, "O": 4}),
    }
    totals = {"Mn": 0.0, "W": 0.0}
    for phase, composition in formula.items():
        molecular_mass = sum(atomic_mass[element] * number for element, number in composition.items())
        moles = fractions[phase][0] / molecular_mass
        for element in totals:
            totals[element] += moles * composition.get(element, 0)
    return totals["Mn"] / totals["W"]


def main() -> None:
    G2sc.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(SOURCE), newgpx=str(WORK))
    histogram = project.histogram(0)
    project.set_Controls("cycles", 20)

    # Include every supplied point, including the half-step edge bins outside
    # the nominal 10--100 degree acquisition interval.
    measured_limits = histogram.data["Limits"][0]
    histogram.data["Limits"][1] = [
        float(measured_limits[0]),
        float(measured_limits[1]),
    ]

    # The texture screen kept cells fixed so axes could be compared on equal
    # footing. Re-enable all cells for the final joint intensity/position fit.
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][2][0] = False
        hap["Mustrain"][2][0] = False
        if phase.name != "WO3_gamma_monoclinic":
            hap["Pref.Ori."][2] = False

    # Widths were determined in staged passes and are now fixed to avoid
    # instrument/specimen degeneracy. The one accepted WO3 texture parameter,
    # phase scales, background, displacement and all cells remain active.
    for key in ("U", "V", "W", "X", "SH/L", "Polariz."):
        histogram.InstrumentParameters[key][2] = False
    project.set_Controls("parmMin", 0.5, variable="1:0:MD")
    project.set_Controls("parmMax", 2.0, variable="1:0:MD")

    history = refine_to_stability(project)
    project.save(str(FINAL))
    shutil.copy2(FINAL, OUT / "accepted_checkpoint.gpx")

    # Verify that a clean zero-cycle calculation exactly regenerates the
    # stored full-grid profile. The replay is kept alongside the checkpoint.
    stored_rwp = float(histogram.get_wR())
    replay_path = OUT / "replay.gpx"
    shutil.copy2(FINAL, replay_path)
    replay = G2sc.G2Project(str(replay_path))
    replay.set_Controls("cycles", 0)
    replay.refine()
    replay_rwp = float(replay.histogram(0).get_wR())
    replay_delta = abs(stored_rwp - replay_rwp)
    if replay_delta > 1.0e-3:
        raise RuntimeError(
            f"final project is not replayable: Rwp {stored_rwp} -> {replay_rwp}"
        )

    raw_mass = histogram.ComputeMassFracs()
    fractions = {
        name: (float(values[0]), float(values[1]))
        for name, values in raw_mass.items()
    }

    # CIFs are exported from this exact final project and covariance matrix.
    phases_json = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        phase.export_CIF(str(ROOT / info["cif"]))
        cell = phase.get_cell()
        phases_json.append(
            {
                "name": info["name"],
                "formula": info["formula"],
                "space_group": info["space_group"],
                "cif_path": info["cif"],
                "weight_fraction": fractions[phase.name][0],
                "weight_fraction_esd": fractions[phase.name][1],
                "cell": {
                    "a_angstrom": float(cell["length_a"]),
                    "b_angstrom": float(cell["length_b"]),
                    "c_angstrom": float(cell["length_c"]),
                    "alpha_deg": float(cell["angle_alpha"]),
                    "beta_deg": float(cell["angle_beta"]),
                    "gamma_deg": float(cell["angle_gamma"]),
                    "volume_angstrom3": float(cell["volume"]),
                },
                "model_origin": info["model_origin"],
            }
        )

    x = histogram.getdata("X")
    observed = histogram.getdata("Yobs")
    calculated = histogram.getdata("Ycalc")
    # GSAS-II leaves its cached residual array at zero outside the active
    # refinement limits. Define the submitted full-grid difference directly,
    # including those edge bins, so the identity is exact for every row.
    difference = observed - calculated
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("two_theta_deg", "observed", "calculated", "difference"))
        writer.writerows(zip(x, observed, calculated, difference))

    residuals = histogram.residuals
    rvals = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "phases": phases_json,
        "fit_statistics": {
            "Rwp_percent": stored_rwp,
            "Rp_percent": float(residuals["R"]),
            "R_background_percent": float(residuals["Rb"]),
            "weighted_R_background_percent": float(residuals["wRb"]),
            "R_expected_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "observations": int(rvals["Nobs"]),
            "variables": int(rvals["Nvars"]),
        },
        "profile": {
            "path": "fit.csv",
            "histogram": histogram.name,
            "points": len(x),
            "difference_definition": "observed - calculated",
        },
        "project_path": "final.gpx",
        "project_replay": {
            "zero_cycle_Rwp_percent": replay_rwp,
            "absolute_Rwp_delta_percent": replay_delta,
        },
        "modeled_crystalline_Mn_to_W_molar_ratio": molar_mn_to_w(fractions),
        "notes": [
            "Weight fractions are normalized over the four modeled crystalline phases.",
            "Reported e.s.d. values are GSAS-II least-squares estimates and exclude model-selection and other systematic uncertainty.",
        ],
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    diagnostics = {
        "refinement_Rwp_history_percent": history,
        "stored_Rwp_percent": stored_rwp,
        "replay_Rwp_percent": replay_rwp,
        "frozen_variable_count": frozen_count(project),
        "texture": {
            "phase": "WO3_gamma_monoclinic",
            "model": "March-Dollase",
            "axis_hkl": [1, 0, 0],
            "coefficient": float(
                project.phase("WO3_gamma_monoclinic")
                .data["Histograms"][histogram.name]["Pref.Ori."][1]
            ),
        },
        "mass_fraction_sum": sum(value[0] for value in fractions.values()),
    }
    (OUT / "diagnostics.json").write_text(json.dumps(diagnostics, indent=2) + "\n")
    print(json.dumps({"result": result, "diagnostics": diagnostics}, indent=2))


if __name__ == "__main__":
    main()
