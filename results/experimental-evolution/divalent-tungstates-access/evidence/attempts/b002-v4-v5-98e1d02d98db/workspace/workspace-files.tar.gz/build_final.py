#!/usr/bin/env python3
"""Refine and export the accepted four-phase physical replay."""

from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "branches/fourth_phase_tests/Mn3O4_hausmannite/model.gpx"
OUT = ROOT / "branches/final_refinement"
OUT.mkdir(parents=True, exist_ok=True)
WORK = OUT / "work.gpx"


def bound(gpx, variable, low, high):
    gpx.set_Controls("parmMin", float(low), variable=variable)
    gpx.set_Controls("parmMax", float(high), variable=variable)


def n_frozen(gpx):
    return sum(len(v) for v in gpx.get_Controls("parmFrozen").values())


def refine_stable(gpx, stage, max_passes=8):
    prior_n = n_frozen(gpx)
    prior_wr = None
    history = []
    for _ in range(max_passes):
        gpx.refine()
        wr = float(gpx.histogram(0).get_wR())
        n = n_frozen(gpx)
        history.append(wr)
        if n == prior_n and prior_wr is not None and abs(wr - prior_wr) < 1e-4:
            break
        prior_n, prior_wr = n, wr
    gpx.save()
    checkpoint = OUT / f"checkpoint_{stage}.gpx"
    shutil.copy2(gpx.filename, checkpoint)
    print(stage, history, "frozen", n_frozen(gpx))
    return history


def set_size_flag(phase, hist, value):
    phase.data["Histograms"][hist.name]["Size"][2][0] = bool(value)


def set_strain_flag(phase, hist, value):
    phase.data["Histograms"][hist.name]["Mustrain"][2][0] = bool(value)


G2sc.SetPrintLevel("error")
gpx = G2sc.G2Project(str(SOURCE), newgpx=str(WORK))
hist = gpx.histogram(0)
phases = gpx.phases()
gpx.set_Controls("cycles", 20)

# Remove stale frozen-variable records from rejected coordinate/profile tests.
# All accepted values are already stored explicitly in the phase dictionaries.
gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}

# Start the final profile sequence from fixed cells, coordinates, sizes, and
# strains. Scales, the smooth background, and specimen displacement remain
# live throughout.
for phase in phases:
    phase.clear_refinements({"Cell": True})
    set_size_flag(phase, hist, False)
    set_strain_flag(phase, hist, False)
    for atom in phase.atoms():
        atom.refinement_flags = " "

for key in ("U", "V", "W", "X", "SH/L", "Polariz."):
    hist.InstrumentParameters[key][2] = False

stages = {}

# Effective polarization is not reported in metadata. Refine it once within
# its physical interval, then hold the bounded result.
hist.InstrumentParameters["Polariz."][1] = 0.8
hist.InstrumentParameters["Polariz."][2] = True
bound(gpx, ":0:Polariz.", 0.45, 1.0)
stages["01_polarization"] = refine_stable(gpx, "01_polarization")
hist.InstrumentParameters["Polariz."][2] = False

# The isolated Gaussian test placed U at zero. Keep that physical boundary
# fixed and refine V/W, which remain positive-definite over the measured grid.
hist.InstrumentParameters["U"][1] = 0.0
hist.InstrumentParameters["U"][2] = False
hist.InstrumentParameters["V"][1] = -15.0
hist.InstrumentParameters["W"][1] = 22.5
hist.InstrumentParameters["V"][2] = True
hist.InstrumentParameters["W"][2] = True
bound(gpx, ":0:V", -60.0, 60.0)
bound(gpx, ":0:W", 0.0, 60.0)
stages["02_instrument_VW"] = refine_stable(gpx, "02_instrument_VW")
hist.InstrumentParameters["V"][2] = False
hist.InstrumentParameters["W"][2] = False

# Re-estimate the Scherrer contribution one phase at a time with the
# instrument fixed, preventing exact instrument/size covariance.
for index, phase in enumerate(phases):
    set_size_flag(phase, hist, True)
    bound(gpx, f"{phase.id}:0:Size;i", 0.005, 10.0)
    label = f"03{index + 1}_size_{phase.name}"
    stages[label] = refine_stable(gpx, label)
    set_size_flag(phase, hist, False)

# Add only isotropic microstrain, again one phase at a time. No anisotropic
# strain or texture family is introduced without a later residual test.
for index, phase in enumerate(phases):
    set_strain_flag(phase, hist, True)
    bound(gpx, f"{phase.id}:0:Mustrain;i", 0.0, 20000.0)
    label = f"04{index + 1}_strain_{phase.name}"
    stages[label] = refine_stable(gpx, label)
    set_strain_flag(phase, hist, False)

# Return to position/intensity terms after the profile is established.
for phase in phases:
    phase.set_refinements({"Cell": True})
stages["05_cells_scales_background"] = refine_stable(
    gpx, "05_cells_scales_background"
)

# A final V/W pass with all specimen widths fixed, followed by a final
# cell/scale/background calculation, leaves a well-conditioned covariance
# matrix for phase-fraction uncertainties.
for phase in phases:
    phase.clear_refinements({"Cell": True})
hist.InstrumentParameters["V"][2] = True
hist.InstrumentParameters["W"][2] = True
stages["06_final_instrument_VW"] = refine_stable(gpx, "06_final_instrument_VW")
hist.InstrumentParameters["V"][2] = False
hist.InstrumentParameters["W"][2] = False
for phase in phases:
    phase.set_refinements({"Cell": True})
stages["07_final_positions_intensities"] = refine_stable(
    gpx, "07_final_positions_intensities"
)

# Save the active physical replay at the required root path. A separate
# zero-cycle copy verifies, without destroying this covariance matrix, that
# the stored profile is regenerated from exactly the stored parameters.
gpx.save(str(ROOT / "final.gpx"))
replay_path = OUT / "final_replay_check.gpx"
shutil.copy2(ROOT / "final.gpx", replay_path)
replay = G2sc.G2Project(str(replay_path))
stored_wR = float(gpx.histogram(0).get_wR())
replay.set_Controls("cycles", 0)
replay.refine()
replay_wR = float(replay.histogram(0).get_wR())
if abs(stored_wR - replay_wR) > 1e-3:
    raise RuntimeError(f"final project does not replay: {stored_wR} -> {replay_wR}")

mass = hist.ComputeMassFracs()
summary = {
    "wR_percent": stored_wR,
    "replay_wR_percent": replay_wR,
    "replay_delta_wR_percent": abs(stored_wR - replay_wR),
    "residuals": hist.residuals,
    "mass_fractions": {name: [float(v) for v in values] for name, values in mass.items()},
    "cells": {phase.name: phase.get_cell() for phase in phases},
    "instrument": {
        key: hist.InstrumentParameters[key]
        for key in ("U", "V", "W", "X", "SH/L", "Polariz.")
    },
    "sample": {
        key: hist.SampleParameters[key]
        for key in ("Shift", "SurfRoughA", "SurfRoughB")
    },
    "hap": {
        phase.name: {
            "scale": phase.data["Histograms"][hist.name]["Scale"],
            "size": phase.data["Histograms"][hist.name]["Size"],
            "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
        }
        for phase in phases
    },
    "stages": stages,
}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2))

profile = np.column_stack(
    [
        hist.getdata("X"), hist.getdata("Yobs"), hist.getdata("Ycalc"),
        hist.getdata("Residual"), hist.getdata("Background"),
    ]
)
np.savetxt(
    OUT / "profile.csv", profile, delimiter=",",
    header="two_theta_deg,observed,calculated,difference,background", comments="",
)
print(json.dumps(summary, indent=2))
