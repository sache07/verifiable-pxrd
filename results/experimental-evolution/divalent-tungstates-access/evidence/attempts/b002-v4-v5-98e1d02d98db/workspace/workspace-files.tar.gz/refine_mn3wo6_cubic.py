#!/usr/bin/env python3
"""Comparable serious refinement for the alternative cubic Mn3WO6 model."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "branches/two_phase_structure/light_site_tests/mnwo4_O1_O2/model.gpx"
CIF = ROOT / "branches/models/Mn3WO6_Cu3WO6_cubic.cif"
OUT = ROOT / "branches/mn3wo6_cubic_serious"
OUT.mkdir(parents=True, exist_ok=True)


def bound(gpx, variable, low, high):
    gpx.set_Controls("parmMin", float(low), variable=variable)
    gpx.set_Controls("parmMax", float(high), variable=variable)


def n_frozen(gpx):
    return sum(len(v) for v in gpx.get_Controls("parmFrozen").values())


def refine_stable(gpx):
    before = n_frozen(gpx)
    for _ in range(6):
        gpx.refine()
        after = n_frozen(gpx)
        if after == before:
            return
        before = after
    raise RuntimeError("clipping did not stabilize")


def coordinate_bounds(gpx, phase, labels, width):
    atoms = list(phase.atoms())
    for label in labels:
        atom = phase.atom(label)
        index = next(i for i, item in enumerate(atoms) if item.label == label)
        for axis, value in zip("xyz", atom.coordinates):
            bound(gpx, f"{phase.id}::dA{axis}:{index}", value - width, value + width)


def record(gpx, stage, stages):
    gpx.save()
    checkpoint = OUT / f"checkpoint_{stage}.gpx"
    shutil.copy2(gpx.filename, checkpoint)
    replay_file = OUT / f"replay_{stage}.gpx"
    shutil.copy2(checkpoint, replay_file)
    replay = G2sc.G2Project(str(replay_file))
    replay.set_Controls("cycles", 0)
    replay.refine()
    delta = abs(replay.histogram(0).get_wR() - gpx.histogram(0).get_wR())
    if delta > 1.0e-3:
        raise RuntimeError(f"{stage} does not replay ({delta}%)")
    phase = gpx.phase(2)
    hist = gpx.histogram(0)
    cif = OUT / f"{stage}_Mn3WO6_cubic.cif"
    phase.export_CIF(str(cif))
    stages[stage] = {
        "wR_percent": float(hist.get_wR()),
        "scale": float(phase.data["Histograms"][hist.name]["Scale"][0]),
        "cell": phase.get_cell(),
        "size": phase.data["Histograms"][hist.name]["Size"],
        "cif": str(cif.relative_to(ROOT)),
        "frozen": [
            str(x)
            for values in gpx.get_Controls("parmFrozen").values()
            for x in values
        ],
    }
    print(stage, f"wR={hist.get_wR():.6f}", f"scale={stages[stage]['scale']:.6g}")


G2sc.SetPrintLevel("error")
path = OUT / "work.gpx"
gpx = G2sc.G2Project(str(SOURCE), newgpx=str(path))
hist = gpx.histogram(0)
for phase in gpx.phases():
    for atom in phase.atoms():
        atom.refinement_flags = " "
candidate = gpx.add_phase(str(CIF), phasename="Mn3WO6_cubic", histograms=[hist])
candidate.data["Histograms"][hist.name]["Scale"] = [4.0, True]
gpx.set_Controls("cycles", 16)
stages = {}
refine_stable(gpx)
record(gpx, "01_scale", stages)

candidate.set_refinements({"Cell": True})
for i, value in enumerate(G2lat.cell2A(candidate.data["General"]["Cell"][1:7])):
    if abs(value) > 1.0e-10:
        bound(gpx, f"{candidate.id}::A{i}", value * 0.8, value * 1.2)
refine_stable(gpx)
record(gpx, "02_cell", stages)

candidate.set_HAP_refinements(
    {"Size": {"type": "isotropic", "value": 0.03, "refine": True}}
)
bound(gpx, f"{candidate.id}:0:Size;i", 0.005, 10.0)
refine_stable(gpx)
record(gpx, "03_size", stages)

candidate.set_refinements({"Atoms": {"Mn0": "X", "W1": "X"}})
coordinate_bounds(gpx, candidate, ["Mn0", "W1"], 0.04)
refine_stable(gpx)
record(gpx, "04_heavy", stages)

for atom in candidate.atoms():
    atom.refinement_flags = " "
candidate.set_refinements({"Atoms": {"O1": "X", "O2": "X"}})
coordinate_bounds(gpx, candidate, ["O1", "O2"], 0.03)
refine_stable(gpx)
record(gpx, "05_oxygen", stages)

bound(gpx, f"{candidate.id}:0:Scale", 0.0, 1.0e5)
refine_stable(gpx)
record(gpx, "06_physical", stages)
(OUT / "summary.json").write_text(json.dumps(stages, indent=2))
