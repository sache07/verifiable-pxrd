#!/usr/bin/env python3
"""Compare physically screened WO3 topologies in a common MnWO4+WO3 fit."""

from pathlib import Path
import argparse
import json
import shutil
import traceback

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
REF_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)
OUT = ROOT / "branches" / "wo3"
OUT.mkdir(parents=True, exist_ok=True)

MNWO4 = "1520200"
# One physically credible representative per distinct diffraction/topology
# family. The old 1010618 and 1528915 models are excluded because their
# occupied geometries contain O--O contacts of 0.46 and 1.57 A, respectively.
CANDIDATES = {
    "monoclinic_gamma_2311041": "2311041",
    "triclinic_2106293": "2106293",
    "orthorhombic_2107312": "2107312",
    "tetragonal_1521532": "1521532",
    "hexagonal_1004057": "1004057",
    "monoclinic_hp_1563541": "1563541",
}


def cif_path(cid):
    if cid == "1563541":
        return OUT / "repaired_1563541.cif"
    return REF_ROOT / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


def set_bound(gpx, var, low, high):
    gpx.set_Controls("parmMin", float(low), variable=var)
    gpx.set_Controls("parmMax", float(high), variable=var)


def set_common_bounds(gpx, nphase):
    for key, limits in {
        "Zero": (-0.25, 0.25),
        "Shift": (-800.0, 800.0),
        "U": (0.0, 40.0),
        "W": (2.0, 40.0),
        "X": (0.1, 6.0),
        "SH/L": (0.005, 0.10),
        "Polariz.": (0.5, 1.0),
    }.items():
        set_bound(gpx, f":0:{key}", *limits)
    for pid in range(nphase):
        set_bound(gpx, f"{pid}:0:Scale", 0.0, 1.0e5)
        set_bound(gpx, f"{pid}:0:Size;i", 0.04, 3.0)
        set_bound(gpx, f"{pid}:0:Mustrain;i", 100.0, 10000.0)


def refine_step(gpx, name):
    gpx.refine()
    # Keep final_branch.gpx as the active replay while preserving a complete
    # same-branch checkpoint after each genuine stage.
    gpx.save()
    shutil.copy2(gpx.filename, Path(gpx.filename).with_name(f"checkpoint_{name}.gpx"))


def run_branch(label, cid):
    branch = OUT / label
    branch.mkdir(exist_ok=True)
    gpx = G2sc.G2Project(newgpx=str(branch / "final_branch.gpx"))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    mn = gpx.add_phase(
        str(cif_path(MNWO4)), phasename="MnWO4_wolframite", histograms=[hist]
    )
    wo = gpx.add_phase(
        str(cif_path(cid)), phasename=f"WO3_{cid}", histograms=[hist]
    )
    gpx.set_Controls("cycles", 12)
    set_common_bounds(gpx, 2)
    hist.set_refinements({"Limits": [10.0, 100.05]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 16,
            }
        }
    )
    mn.set_HAP_refinements({"Scale": True})
    wo.set_HAP_refinements({"Scale": True})
    refine_step(gpx, "01_scales_background")

    # Refine the cells and zero first; add specimen displacement only after
    # that stable position model exists.
    mn.set_refinements({"Cell": True})
    wo.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_step(gpx, "02_cells_zero")
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine_step(gpx, "03_shift")

    # Width model in staged, bounded blocks. Instrument Lorentzian width is
    # refined before phase-specific size/strain and then held in the joint fit.
    hist.set_refinements({"Instrument Parameters": ["U", "W"]})
    refine_step(gpx, "04_gaussian_profile")
    hist.set_refinements({"Instrument Parameters": ["X", "SH/L"]})
    refine_step(gpx, "05_lorentz_axial")
    for phase in (mn, wo):
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 1.0, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    # Avoid exact X/size covariance in the comparison checkpoint.
    hist.clear_refinements({"Instrument Parameters": ["X"]})
    refine_step(gpx, "06_phase_broadening")
    gpx.save()

    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    result = {
        "candidate": cid,
        "label": label,
        "wR_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "cells": {p.name: p.get_cell() for p in (mn, wo)},
        "scales": {
            p.name: p.data["Histograms"][hist.name]["Scale"][0]
            for p in (mn, wo)
        },
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "Polariz.", "U", "V", "W", "X", "SH/L")
            if key in inst
        },
        "sample": {
            key: sample[key][0]
            for key in ("Shift", "SurfRoughA", "SurfRoughB")
            if key in sample
        },
        "hap": {
            p.name: {
                "size": p.data["Histograms"][hist.name]["Size"],
                "mustrain": p.data["Histograms"][hist.name]["Mustrain"],
            }
            for p in (mn, wo)
        },
        "gpx": str((branch / "final_branch.gpx").relative_to(ROOT)),
    }
    (branch / "summary.json").write_text(json.dumps(result, indent=2))
    arr = np.column_stack(
        [
            hist.getdata("X"), hist.getdata("Yobs"), hist.getdata("Ycalc"),
            hist.getdata("Background"), hist.getdata("Residual"),
            hist.getdata("Yweight"),
        ]
    )
    np.savetxt(
        branch / "profile.csv", arr, delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference,weight",
        comments="",
    )
    return result


parser = argparse.ArgumentParser()
parser.add_argument("labels", nargs="*", choices=tuple(CANDIDATES))
args = parser.parse_args()

G2sc.SetPrintLevel("error")
summaries = []
selected = args.labels or list(CANDIDATES)
for label in selected:
    cid = CANDIDATES[label]
    try:
        result = run_branch(label, cid)
        summaries.append(result)
        print(label, result["wR_percent"])
    except Exception as exc:
        print(label, "FAILED", repr(exc))
        traceback.print_exc()
        summaries.append({"label": label, "candidate": cid, "error": repr(exc)})

comparison_path = OUT / ("comparison.json" if not args.labels else "comparison_partial.json")
comparison_path.write_text(json.dumps(summaries, indent=2))
