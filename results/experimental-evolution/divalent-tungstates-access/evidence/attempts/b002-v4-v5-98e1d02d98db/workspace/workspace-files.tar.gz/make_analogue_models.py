#!/usr/bin/env python3
"""Create provenance-tracked Mn tungstate models by isovalent substitution."""

from pathlib import Path
import json

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
REF_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)
OUT = ROOT / "branches" / "models"
OUT.mkdir(parents=True, exist_ok=True)

MODELS = {
    "Mn2WO6_Fe2WO6_Pbcn": {
        "parent_id": "2310464",
        "substitution": {"Fe": "Mn"},
        # The first two coherent unassigned lines (19.86 and 20.40 deg) and
        # the line hidden under MnWO4 at 30.42 deg require d spacings about
        # 1.8% larger than the Fe(III) parent.  This is also chemically
        # sensible for the larger Mn(III) ion and gives cell refinement an
        # indexed, rather than arbitrary, starting point.
        "lattice_scale": 1.018,
        "basis": "Fe2WO6-type orthorhombic Pbcn; Fe(III) is the closest available ordered small-trivalent-cation parent.",
    },
    "Mn2WO6_Cr2WO6_trirutile": {
        "parent_id": "1530909",
        "substitution": {"Cr": "Mn"},
        "lattice_scale": 1.018,
        "basis": "Cr2WO6-type tetragonal P42/mnm trirutile; Cr(III) supplies the distinct nearest octahedral small-trivalent-cation topology.",
    },
    "Mn3WO6_Cu3WO6_cubic": {
        "parent_id": "1527404",
        "substitution": {"Cu": "Mn"},
        "basis": "Cu3WO6-type cubic Pa-3; Cu(II) is an available divalent parent for the alternative balance-closing Mn3WO6 formula.",
    },
    "Mn3WO6_Ca3WO6_monoclinic": {
        "parent_id": "1563081",
        "substitution": {"Ca": "Mn"},
        # Pymatgen's standardized rewrite of this nearly orthogonal P21/c
        # cell produces an operation setting that the GSAS-II CIF importer
        # does not recognize. Preserve the published setting and perform the
        # same full-occupancy type substitution textually.
        "preserve_source_setting": True,
        "basis": "Ca3WO6-type monoclinic P21/c; Ca(II) supplies a distinct divalent-cation topology for Mn3WO6.",
    },
}


def source_path(cid):
    return REF_ROOT / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


for name, info in MODELS.items():
    parent = source_path(info["parent_id"])
    structure = Structure.from_file(parent)
    structure.remove_oxidation_states()
    structure.replace_species(info["substitution"])
    lattice_scale = float(info.get("lattice_scale", 1.0))
    if lattice_scale != 1.0:
        structure.scale_lattice(structure.volume * lattice_scale**3)
    cif_path = OUT / f"{name}.cif"
    if info.get("preserve_source_setting"):
        source_text = parent.read_text()
        for old, new in info["substitution"].items():
            source_text = source_text.replace(old, new)
        # Informational only (GSAS-II recomputes mass from occupied sites), but
        # keep the formula-weight field internally consistent.
        source_text = source_text.replace("400.08", "444.65")
        cif_path.write_text(source_text)
    else:
        CifWriter(structure, symprec=0.01, refine_struct=False).write_file(cif_path)
    record = {
        "model": name,
        "model_basis": "analogue_derived",
        "parent_id": f"COD {info['parent_id']}",
        "parent_cif": str(parent),
        "transformation": (
            "Direct full-occupancy element substitution "
            f"{info['substitution']}; parent fractional coordinates, lattice, "
            "symmetry, occupancies, and displacement parameters otherwise retained. "
            f"For indexing, all lattice vectors were multiplied by {lattice_scale:.6g}. "
            "The lattice and supported coordinates are to be refined against the specimen."
        ),
        "rationale": info["basis"],
        "output_cif": str(cif_path.relative_to(ROOT)),
        "composition": structure.composition.reduced_formula,
    }
    (OUT / f"{name}.provenance.json").write_text(json.dumps(record, indent=2))
    print(name, structure.composition.reduced_formula, cif_path)
