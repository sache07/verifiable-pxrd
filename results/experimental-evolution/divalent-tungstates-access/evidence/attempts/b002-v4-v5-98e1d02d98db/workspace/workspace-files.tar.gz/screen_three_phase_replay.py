#!/usr/bin/env python3
"""Replay-safe, common-state screening of a third crystalline phase.

GSAS-II applies parameter limits after calculating a refinement profile.  A
profile saved on the first cycle in which a limit is crossed therefore does
not reproduce the clipped model.  ``refine_stable`` always performs another
refinement after clipping, and the final zero-cycle calculation independently
checks every branch before its score is recorded.
"""

from pathlib import Path
import argparse
import json
import shutil
import traceback

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
REF_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)
OUT = ROOT / "branches" / "three_phase_replay"
OUT.mkdir(parents=True, exist_ok=True)


def ref(cid):
    return REF_ROOT / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


CANDIDATES = {
    # Exact-composition precursor/decomposition checks come first.
    "Mn3O4_hausmannite": (ref("9001963"), "precursor"),
    "MnO_manganosite": (ref("1514108"), "precursor_or_decomposition"),
    "Mn2O3_bixbyite": (ref("1514230"), "oxidized_precursor"),
    # Balance-closing Mn2WO6: nearest physical parent from each small-M(III)
    # coordination/symmetry topology available in the frozen index.
    "Mn2WO6_Pbcn": (
        ROOT / "branches/models/Mn2WO6_Fe2WO6_Pbcn.cif",
        "balance_closing_analogue",
    ),
    "Mn2WO6_trirutile": (
        ROOT / "branches/models/Mn2WO6_Cr2WO6_trirutile.cif",
        "balance_closing_analogue",
    ),
    # Alternative Mn-rich formula capable of closing the nominal inventory.
    "Mn3WO6_cubic": (
        ROOT / "branches/models/Mn3WO6_Cu3WO6_cubic.cif",
        "alternative_balance_closing_analogue",
    ),
    "Mn3WO6_monoclinic": (
        ROOT / "branches/models/Mn3WO6_Ca3WO6_monoclinic.cif",
        "alternative_balance_closing_analogue",
    ),
}

MNWO4 = ref("1520200")
WO3 = ref("2311041")


def set_bound(gpx, var, low, high):
    gpx.set_Controls("parmMin", float(low), variable=var)
    gpx.set_Controls("parmMax", float(high), variable=var)


def frozen_count(gpx):
    frozen = gpx.get_Controls("parmFrozen")
    return sum(len(v) for v in frozen.values())


def refine_stable(gpx, branch, label, max_passes=5):
    """Refine until a complete pass adds no newly clipped variables."""
    previous = frozen_count(gpx)
    for _ in range(max_passes):
        gpx.refine()
        current = frozen_count(gpx)
        if current == previous:
            break
        previous = current
    else:
        raise RuntimeError(f"parameter clipping did not stabilize in {label}")
    gpx.save()
    shutil.copy2(gpx.filename, branch / f"checkpoint_{label}.gpx")
    return float(gpx.histogram(0).get_wR())


def run(label):
    candidate_path, kind = CANDIDATES[label]
    branch = OUT / label
    branch.mkdir(exist_ok=True)
    project_path = branch / "final_branch.gpx"
    gpx = G2sc.G2Project(newgpx=str(project_path))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    accepted = [
        gpx.add_phase(str(MNWO4), phasename="MnWO4_wolframite", histograms=[hist]),
        gpx.add_phase(str(WO3), phasename="WO3_gamma_monoclinic", histograms=[hist]),
    ]
    candidate = gpx.add_phase(
        str(candidate_path), phasename=label, histograms=[hist]
    )
    phases = accepted + [candidate]
    gpx.set_Controls("cycles", 10)
    hist.set_refinements({"Limits": [10.0, 100.05]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 14,
            }
        }
    )
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
        set_bound(gpx, f"{phase.id}:0:Scale", 0.0, 1.0e5)

    stages = {}
    stages["01_scales_background"] = refine_stable(
        gpx, branch, "01_scales_background"
    )

    # A candidate whose scale has collapsed is retained and replayed at zero.
    # During identity screening its physical reference/indexed cell is always
    # held fixed: allowing an absent phase to vary its cell lets it migrate to
    # unrelated peaks (or expand until it has no reflections in range).
    candidate_scale = candidate.data["Histograms"][hist.name]["Scale"][0]
    if candidate_scale > 1.0e-8:
        for phase in accepted:
            phase.set_refinements({"Cell": True})
        stages["02_accepted_cells"] = refine_stable(
            gpx, branch, "02_accepted_cells"
        )

        # The accepted-phase residuals show a common angle-dependent peak
        # offset. Use specimen displacement as the sole global correction;
        # instrumental zero stays fixed to avoid their near-exact covariance.
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        set_bound(gpx, ":0:Shift", -1000.0, 1000.0)
        stages["03_shift_accepted_cells"] = refine_stable(
            gpx, branch, "03_shift_accepted_cells"
        )

        # One physically interpretable phase-width family is enough for a fair
        # identity comparison. Instrument U/W/X remain common and fixed here.
        for phase in phases:
            start_size = 0.05 if phase is candidate else 0.5
            phase.set_HAP_refinements(
                {
                    "Size": {
                        "type": "isotropic",
                        "value": start_size,
                        "refine": True,
                    }
                }
            )
            set_bound(gpx, f"{phase.id}:0:Size;i", 0.005, 10.0)
        stages["04_isotropic_size"] = refine_stable(
            gpx, branch, "04_isotropic_size"
        )

    # A zero-cycle pass forces the saved profile to be generated from exactly
    # the parameters that will replay from disk. It also catches GSAS-II's
    # post-calculation clipping behavior independently of the loop above.
    w_before_replay = float(hist.get_wR())
    gpx.set_Controls("cycles", 0)
    gpx.refine()
    w_after_replay = float(hist.get_wR())
    replay_delta = abs(w_after_replay - w_before_replay)
    # Floating-point regeneration of the reflection list can change wR in the
    # fifth decimal place; only a material profile mismatch is a replay error.
    if replay_delta > 1.0e-3:
        raise RuntimeError(
            f"non-replaying branch: wR changed by {replay_delta:.6g}%"
        )
    gpx.set_Controls("cycles", 10)
    gpx.save()

    # A zero-cycle replay intentionally has no covariance matrix. The phase
    # values themselves are the Hill--Howard GSAS-II expression S_i M_i /
    # sum(S_j M_j); uncertainties are not needed for branch screening.
    mass_terms = {
        p.name: float(p.data["Histograms"][hist.name]["Scale"][0])
        * float(p.data["General"]["Mass"])
        for p in phases
    }
    mass_sum = sum(mass_terms.values())
    mass = {
        name: (value / mass_sum if mass_sum else float("nan"), float("nan"))
        for name, value in mass_terms.items()
    }
    summary = {
        "label": label,
        "kind": kind,
        "source": str(candidate_path),
        "wR_percent": w_after_replay,
        "replay_delta_wR_percent": replay_delta,
        "stages_wR_percent": stages,
        "residuals": hist.residuals,
        "mass_fractions": {k: [float(x) for x in v] for k, v in mass.items()},
        "cells": {p.name: p.get_cell() for p in phases},
        "scales": {
            p.name: float(p.data["Histograms"][hist.name]["Scale"][0])
            for p in phases
        },
        "sizes": {
            p.name: p.data["Histograms"][hist.name]["Size"] for p in phases
        },
        "sample_shift_micrometers": float(hist.SampleParameters["Shift"][0]),
        "frozen_parameters": [
            str(item)
            for values in gpx.get_Controls("parmFrozen").values()
            for item in values
        ],
        "composition": candidate.composition,
        "density_g_cm3": candidate.density,
        "gpx": str(project_path.relative_to(ROOT)),
    }
    (branch / "summary.json").write_text(json.dumps(summary, indent=2))
    arr = np.column_stack(
        [
            hist.getdata("X"),
            hist.getdata("Yobs"),
            hist.getdata("Ycalc"),
            hist.getdata("Background"),
            hist.getdata("Residual"),
            hist.getdata("Yweight"),
        ]
    )
    np.savetxt(
        branch / "profile.csv",
        arr,
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference,weight",
        comments="",
    )
    print(
        label,
        f"wR={w_after_replay:.5f}",
        f"candidate_scale={summary['scales'][label]:.6g}",
        f"replay_delta={replay_delta:.3g}",
    )
    return summary


parser = argparse.ArgumentParser()
parser.add_argument("labels", nargs="*", choices=tuple(CANDIDATES))
args = parser.parse_args()
selected = args.labels or list(CANDIDATES)

G2sc.SetPrintLevel("error")
results = []
for selected_label in selected:
    try:
        results.append(run(selected_label))
    except Exception as exc:
        traceback.print_exc()
        results.append({"label": selected_label, "error": repr(exc)})

comparison_path = OUT / (
    "comparison.json" if not args.labels else "comparison_partial.json"
)
comparison_path.write_text(json.dumps(results, indent=2))
