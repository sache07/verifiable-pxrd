#!/usr/bin/env python3
"""Replay-safe serious comparison branch for triclinic WO3."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
REF = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)
OUT = ROOT / "branches/wo3_triclinic_serious"
OUT.mkdir(parents=True, exist_ok=True)


def cif(cid):
    return REF / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


def bound(gpx, variable, low, high):
    gpx.set_Controls("parmMin", float(low), variable=variable)
    gpx.set_Controls("parmMax", float(high), variable=variable)


def n_frozen(gpx):
    return sum(len(v) for v in gpx.get_Controls("parmFrozen").values())


def refine_stable(gpx):
    prior_n = n_frozen(gpx)
    prior_wr = None
    for _ in range(7):
        gpx.refine()
        n = n_frozen(gpx)
        wr = float(gpx.histogram(0).get_wR())
        if n == prior_n and prior_wr is not None and abs(wr - prior_wr) < 1e-4:
            return
        prior_n, prior_wr = n, wr
    # A replay check below is authoritative even if parameter/esd convergence
    # is slower than the conservative loop threshold.


def coordinate_bounds(gpx, phase, labels, half_width):
    atoms = list(phase.atoms())
    for label in labels:
        atom = phase.atom(label)
        index = next(i for i, item in enumerate(atoms) if item.label == label)
        for axis, value in zip("xyz", atom.coordinates):
            bound(gpx, f"{phase.id}::dA{axis}:{index}", value - half_width, value + half_width)


def record(gpx, stage, results):
    gpx.save()
    checkpoint = OUT / f"checkpoint_{stage}.gpx"
    shutil.copy2(gpx.filename, checkpoint)
    replay_path = OUT / f"replay_{stage}.gpx"
    shutil.copy2(checkpoint, replay_path)
    replay = G2sc.G2Project(str(replay_path))
    replay.set_Controls("cycles", 0)
    replay.refine()
    wr = float(gpx.histogram(0).get_wR())
    replay_wr = float(replay.histogram(0).get_wR())
    if abs(wr - replay_wr) > 1e-3:
        raise RuntimeError(f"{stage} does not replay: {wr} -> {replay_wr}")
    cifs = {}
    for phase in gpx.phases():
        path = OUT / f"{stage}_{phase.name}.cif"
        phase.export_CIF(str(path))
        cifs[phase.name] = str(path.relative_to(ROOT))
    results[stage] = {
        "wR_percent": wr,
        "cifs": cifs,
        "cells": {phase.name: phase.get_cell() for phase in gpx.phases()},
    }
    print(stage, wr)


G2sc.SetPrintLevel("error")
project_path = OUT / "work.gpx"
gpx = G2sc.G2Project(newgpx=str(project_path))
hist = gpx.add_powder_histogram(
    str(ROOT / "inputs/pattern.csv"), str(ROOT / "instrument.instprm"), fmthint="comma"
)
hist.SampleParameters["Scale"] = [1.0, False]
mn = gpx.add_phase(str(cif("1520200")), phasename="MnWO4_wolframite", histograms=[hist])
wo = gpx.add_phase(str(cif("2106293")), phasename="WO3_triclinic", histograms=[hist])
gpx.set_Controls("cycles", 16)
hist.set_refinements({"Limits": [10.0, 100.05]})
hist.set_refinements(
    {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 14}}
)
for phase in (mn, wo):
    phase.set_HAP_refinements({"Scale": True})
    bound(gpx, f"{phase.id}:0:Scale", 0.0, 1e5)
results = {}
refine_stable(gpx)
record(gpx, "01_scale", results)
for phase in (mn, wo):
    phase.set_refinements({"Cell": True})
refine_stable(gpx)
record(gpx, "02_cell", results)
hist.set_refinements({"Sample Parameters": ["Shift"]})
bound(gpx, ":0:Shift", -1000.0, 1000.0)
refine_stable(gpx)
record(gpx, "03_shift", results)
for phase in (mn, wo):
    phase.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 0.5, "refine": True}}
    )
    bound(gpx, f"{phase.id}:0:Size;i", 0.005, 10.0)
refine_stable(gpx)
record(gpx, "04_size", results)

for phase in (mn, wo):
    for atom in phase.atoms():
        atom.refinement_flags = " "
mn.set_refinements({"Atoms": {"Mn1": "X", "W1": "X"}})
wo_w = [atom.label for atom in wo.atoms() if atom.element == "W"]
wo.set_refinements({"Atoms": {label: "X" for label in wo_w}})
coordinate_bounds(gpx, mn, ["Mn1", "W1"], 0.02)
coordinate_bounds(gpx, wo, wo_w, 0.02)
refine_stable(gpx)
record(gpx, "05_heavy", results)

for phase in (mn, wo):
    for atom in phase.atoms():
        atom.refinement_flags = " "
mn.set_refinements({"Atoms": {"O1": "X", "O2": "X"}})
coordinate_bounds(gpx, mn, ["O1", "O2"], 0.02)
refine_stable(gpx)
record(gpx, "06_mn_oxygen", results)
(OUT / "summary.json").write_text(json.dumps(results, indent=2))
