#!/usr/bin/env python3
"""Test precursor and balance-closing third phases in one common state."""

from pathlib import Path
import argparse
import json
import shutil
import traceback

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
REF_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)
BASE = ROOT / "branches/wo3/monoclinic_gamma_2311041/final_branch.gpx"
OUT = ROOT / "branches" / "third_phase"
OUT.mkdir(parents=True, exist_ok=True)

CANDIDATES = {
    "Mn3O4_hausmannite": {
        "path": REF_ROOT / "9/00/19/9001963.cif",
        "name": "Mn3O4_hausmannite",
        "kind": "precursor",
    },
    "MnO_manganosite": {
        "path": REF_ROOT / "1/51/41/1514108.cif",
        "name": "MnO_manganosite",
        "kind": "precursor_or_decomposition",
    },
    "Mn2O3_bixbyite": {
        "path": REF_ROOT / "1/51/42/1514230.cif",
        "name": "Mn2O3_bixbyite",
        "kind": "oxidized_precursor",
    },
    "Mn2WO6_Pbcn": {
        "path": ROOT / "branches/models/Mn2WO6_Fe2WO6_Pbcn.cif",
        "name": "Mn2WO6_Pbcn",
        "kind": "balance_closing_analogue",
    },
    "Mn2WO6_trirutile": {
        "path": ROOT / "branches/models/Mn2WO6_Cr2WO6_trirutile.cif",
        "name": "Mn2WO6_trirutile",
        "kind": "balance_closing_analogue",
    },
    "Mn3WO6_cubic": {
        "path": ROOT / "branches/models/Mn3WO6_Cu3WO6_cubic.cif",
        "name": "Mn3WO6_cubic",
        "kind": "alternative_balance_closing_analogue",
    },
    "Mn3WO6_monoclinic": {
        "path": ROOT / "branches/models/Mn3WO6_Ca3WO6_monoclinic.cif",
        "name": "Mn3WO6_monoclinic",
        "kind": "alternative_balance_closing_analogue",
    },
}


def set_bound(gpx, var, low, high):
    gpx.set_Controls("parmMin", float(low), variable=var)
    gpx.set_Controls("parmMax", float(high), variable=var)


def checkpoint(gpx, branch, name):
    gpx.save()
    shutil.copy2(gpx.filename, branch / f"checkpoint_{name}.gpx")


def run(label):
    spec = CANDIDATES[label]
    branch = OUT / label
    branch.mkdir(exist_ok=True)
    gpx = G2sc.G2Project(str(BASE), newgpx=str(branch / "final_branch.gpx"))
    hist = gpx.histogram(0)
    # Hold the accepted two-phase position/profile model fixed while a new
    # identity is tested. This prevents an absent candidate from destabilizing
    # calibrated cells and widths. Background and all phase scales remain live.
    hist.clear_refinements(
        {
            "Instrument Parameters": [
                "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z",
                "SH/L", "I(L2)/I(L1)",
            ],
            "Sample Parameters": [
                "Shift", "Transparency", "SurfRoughA", "SurfRoughB",
            ],
        }
    )
    for accepted in gpx.phases():
        accepted.clear_refinements({"Cell": True})
        accepted.clear_HAP_refinements({"Size": True, "Mustrain": True})
        accepted.set_HAP_refinements({"Scale": True})
    phase = gpx.add_phase(
        str(spec["path"]), phasename=spec["name"], histograms=[hist]
    )
    pid = phase.id
    gpx.set_Controls("cycles", 12)
    set_bound(gpx, f"{pid}:0:Scale", 0.0, 1.0e5)
    set_bound(gpx, f"{pid}:0:Size;i", 0.04, 3.0)
    set_bound(gpx, f"{pid}:0:Mustrain;i", 100.0, 10000.0)

    phase.set_HAP_refinements({"Scale": True})
    gpx.refine()
    checkpoint(gpx, branch, "01_scale")

    phase.set_refinements({"Cell": True})
    gpx.refine()
    checkpoint(gpx, branch, "02_cell")

    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": 0.5, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }
    )
    gpx.refine()
    checkpoint(gpx, branch, "03_profile")

    masses = hist.ComputeMassFracs()
    summary = {
        "label": label,
        "kind": spec["kind"],
        "source": str(spec["path"]),
        "wR_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "mass_fractions": {k: [float(x) for x in v] for k, v in masses.items()},
        "cells": {p.name: p.get_cell() for p in gpx.phases()},
        "scales": {
            p.name: p.data["Histograms"][hist.name]["Scale"][0]
            for p in gpx.phases()
        },
        "new_phase_hap": {
            "size": phase.data["Histograms"][hist.name]["Size"],
            "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
        },
        "composition": phase.composition,
        "density_g_cm3": phase.density,
        "gpx": str((branch / "final_branch.gpx").relative_to(ROOT)),
    }
    (branch / "summary.json").write_text(json.dumps(summary, indent=2))
    arr = np.column_stack(
        [
            hist.getdata("X"), hist.getdata("Yobs"), hist.getdata("Ycalc"),
            hist.getdata("Background"), hist.getdata("Residual"),
            hist.getdata("Yweight"),
        ]
    )
    np.savetxt(
        branch / "profile.csv", arr, delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference,weight",
        comments="",
    )
    print(label, hist.get_wR(), summary["mass_fractions"])
    return summary


parser = argparse.ArgumentParser()
parser.add_argument("labels", nargs="*", choices=tuple(CANDIDATES))
args = parser.parse_args()
selected = args.labels or list(CANDIDATES)

G2sc.SetPrintLevel("error")
results = []
for label in selected:
    try:
        results.append(run(label))
    except Exception as exc:
        traceback.print_exc()
        results.append({"label": label, "error": repr(exc)})

path = OUT / ("comparison.json" if not args.labels else "comparison_partial.json")
path.write_text(json.dumps(results, indent=2))
