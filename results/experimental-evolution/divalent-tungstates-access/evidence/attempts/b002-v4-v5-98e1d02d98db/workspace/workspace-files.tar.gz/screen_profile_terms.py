#!/usr/bin/env python3
"""Test one supported profile/specimen family at a time on the physical model."""

from pathlib import Path
import json
import shutil
import sys
import traceback

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "branches/mn2wo6_serious/Pbcn_oxygen_sites/O3/model.gpx"
OUT = ROOT / "branches/profile_terms"
OUT.mkdir(parents=True, exist_ok=True)

TESTS = ("instrument_UW", "instrument_UVW", "axial_SHL", "isotropic_mustrain", "polarization")


def set_bound(gpx, variable, low, high):
    gpx.set_Controls("parmMin", float(low), variable=variable)
    gpx.set_Controls("parmMax", float(high), variable=variable)


def run(label):
    branch = OUT / label
    branch.mkdir(exist_ok=True)
    path = branch / "model.gpx"
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(path))
    hist = gpx.histogram(0)
    for phase in gpx.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        # Isolate the new width/specimen family from the already established
        # cell and Scherrer-size model. Joint refinement caused exact width
        # covariances and drove unrelated phase cells/sizes to their bounds.
        phase.clear_refinements({"Cell": True})
        phase.data["Histograms"][hist.name]["Size"][2][0] = False
    if label == "instrument_UW":
        hist.set_refinements({"Instrument Parameters": ["U", "W"]})
        set_bound(gpx, ":0:U", 0.0, 60.0)
        set_bound(gpx, ":0:W", 0.0, 60.0)
    elif label == "instrument_UVW":
        hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
        set_bound(gpx, ":0:U", 0.0, 60.0)
        set_bound(gpx, ":0:V", -60.0, 60.0)
        set_bound(gpx, ":0:W", 0.0, 60.0)
    elif label == "axial_SHL":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        set_bound(gpx, ":0:SH/L", 0.001, 0.10)
    elif label == "isotropic_mustrain":
        for phase in gpx.phases():
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )
            set_bound(gpx, f"{phase.id}:0:Mustrain;i", 0.0, 20000.0)
    elif label == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        set_bound(gpx, ":0:Polariz.", 0.45, 1.0)
    else:
        raise ValueError(label)

    gpx.set_Controls("cycles", 20)
    previous_frozen = sum(len(v) for v in gpx.get_Controls("parmFrozen").values())
    previous_wR = None
    for _ in range(8):
        gpx.refine()
        current_frozen = sum(len(v) for v in gpx.get_Controls("parmFrozen").values())
        current_wR = float(hist.get_wR())
        if (
            current_frozen == previous_frozen
            and previous_wR is not None
            and abs(current_wR - previous_wR) < 1.0e-4
        ):
            break
        previous_frozen = current_frozen
        previous_wR = current_wR
    gpx.save()
    replay_path = branch / "replay.gpx"
    shutil.copy2(path, replay_path)
    replay = G2sc.G2Project(str(replay_path))
    replay.set_Controls("cycles", 0)
    replay.refine()
    delta = abs(float(hist.get_wR()) - float(replay.histogram(0).get_wR()))
    if delta > 1.0e-3:
        raise RuntimeError(f"{label} does not replay ({delta}%)")
    result = {
        "test": label,
        "wR_percent": float(hist.get_wR()),
        "replay_delta_wR_percent": delta,
        "instrument": {
            key: hist.InstrumentParameters[key]
            for key in ("U", "V", "W", "X", "SH/L", "Polariz.")
        },
        "hap": {
            phase.name: {
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in gpx.phases()
        },
        "gpx": str(path.relative_to(ROOT)),
        "frozen": [
            str(value)
            for values in gpx.get_Controls("parmFrozen").values()
            for value in values
        ],
    }
    (branch / "summary.json").write_text(json.dumps(result, indent=2))
    print(label, f"wR={result['wR_percent']:.6f}")
    return result


G2sc.SetPrintLevel("error")
selected = tuple(sys.argv[1:]) or TESTS
results = []
for selected_label in selected:
    try:
        results.append(run(selected_label))
    except Exception as exc:
        traceback.print_exc()
        results.append({"test": selected_label, "error": repr(exc)})
(OUT / "comparison.json").write_text(json.dumps(results, indent=2))
