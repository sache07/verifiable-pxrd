#!/usr/bin/env python3
"""Build a replay-safe MnWO4 + gamma-WO3 model and test coordinates."""

from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
REF_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)
OUT = ROOT / "branches" / "two_phase_structure"
OUT.mkdir(parents=True, exist_ok=True)


def ref(cid):
    return REF_ROOT / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


def set_bound(gpx, var, low, high):
    gpx.set_Controls("parmMin", float(low), variable=var)
    gpx.set_Controls("parmMax", float(high), variable=var)


def frozen_count(gpx):
    return sum(len(v) for v in gpx.get_Controls("parmFrozen").values())


def refine_stable(gpx, checkpoint_dir, label, max_passes=5):
    before = frozen_count(gpx)
    for _ in range(max_passes):
        gpx.refine()
        after = frozen_count(gpx)
        if after == before:
            break
        before = after
    else:
        raise RuntimeError(f"parameter clipping did not stabilize in {label}")
    gpx.save()
    shutil.copy2(gpx.filename, checkpoint_dir / f"checkpoint_{label}.gpx")
    return float(gpx.histogram(0).get_wR())


def replay_check(project_path):
    replay_path = project_path.with_name(project_path.stem + "_replay_check.gpx")
    shutil.copy2(project_path, replay_path)
    replay = G2sc.G2Project(str(replay_path))
    before = float(replay.histogram(0).get_wR())
    replay.set_Controls("cycles", 0)
    replay.refine()
    after = float(replay.histogram(0).get_wR())
    return before, after, abs(after - before)


def summarize(gpx, branch, stages):
    hist = gpx.histogram(0)
    mass = hist.ComputeMassFracs()
    project_path = Path(gpx.filename)
    replay_before, replay_after, replay_delta = replay_check(project_path)
    if replay_delta > 1.0e-3:
        raise RuntimeError(f"non-replaying branch {branch.name}: {replay_delta}%")
    cifs = {}
    for phase in gpx.phases():
        path = branch / f"{phase.name}.cif"
        phase.export_CIF(str(path))
        cifs[phase.name] = str(path.relative_to(ROOT))
    result = {
        "wR_percent": float(hist.get_wR()),
        "replay_wR_percent": replay_after,
        "replay_delta_wR_percent": replay_delta,
        "stages_wR_percent": stages,
        "residuals": hist.residuals,
        "mass_fractions": {k: [float(x) for x in v] for k, v in mass.items()},
        "cells": {p.name: p.get_cell() for p in gpx.phases()},
        "scales": {
            p.name: float(p.data["Histograms"][hist.name]["Scale"][0])
            for p in gpx.phases()
        },
        "sizes": {
            p.name: p.data["Histograms"][hist.name]["Size"] for p in gpx.phases()
        },
        "sample_shift_micrometers": float(hist.SampleParameters["Shift"][0]),
        "atoms": {
            p.name: [
                {
                    "label": a.label,
                    "element": a.element,
                    "xyz": [float(x) for x in a.coordinates],
                    "flags": a.refinement_flags,
                }
                for a in p.atoms()
            ]
            for p in gpx.phases()
        },
        "cifs": cifs,
        "gpx": str(project_path.relative_to(ROOT)),
    }
    (branch / "summary.json").write_text(json.dumps(result, indent=2))
    profile = np.column_stack(
        [
            hist.getdata("X"),
            hist.getdata("Yobs"),
            hist.getdata("Ycalc"),
            hist.getdata("Background"),
            hist.getdata("Residual"),
            hist.getdata("Yweight"),
        ]
    )
    np.savetxt(
        branch / "profile.csv",
        profile,
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference,weight",
        comments="",
    )
    print(branch.name, f"wR={result['wR_percent']:.6f}", result["mass_fractions"])
    return result


def build_base():
    branch = OUT / "base"
    branch.mkdir(exist_ok=True)
    path = branch / "model.gpx"
    gpx = G2sc.G2Project(newgpx=str(path))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    phases = [
        gpx.add_phase(
            str(ref("1520200")), phasename="MnWO4_wolframite", histograms=[hist]
        ),
        gpx.add_phase(
            str(ref("2311041")),
            phasename="WO3_gamma_monoclinic",
            histograms=[hist],
        ),
    ]
    gpx.set_Controls("cycles", 12)
    hist.set_refinements({"Limits": [10.0, 100.05]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 14,
            }
        }
    )
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
        set_bound(gpx, f"{phase.id}:0:Scale", 0.0, 1.0e5)
    stages = {"01_scales_background": refine_stable(gpx, branch, "01_scales_background")}
    for phase in phases:
        phase.set_refinements({"Cell": True})
    stages["02_cells"] = refine_stable(gpx, branch, "02_cells")
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    set_bound(gpx, ":0:Shift", -1000.0, 1000.0)
    stages["03_shift_cells"] = refine_stable(gpx, branch, "03_shift_cells")
    for phase in phases:
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 0.5, "refine": True}}
        )
        set_bound(gpx, f"{phase.id}:0:Size;i", 0.005, 10.0)
    stages["04_isotropic_size"] = refine_stable(
        gpx, branch, "04_isotropic_size"
    )
    summarize(gpx, branch, stages)
    return path


def coordinate_branch(source, name, atom_labels):
    branch = OUT / name
    branch.mkdir(exist_ok=True)
    path = branch / "model.gpx"
    gpx = G2sc.G2Project(str(source), newgpx=str(path))
    for phase in gpx.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    for phase_name, labels in atom_labels.items():
        phase = gpx.phase(phase_name)
        phase.set_refinements({"Atoms": {label: "X" for label in labels}})
    gpx.set_Controls("cycles", 20)
    stages = {"coordinates": refine_stable(gpx, branch, "coordinates")}
    summarize(gpx, branch, stages)
    return path


G2sc.SetPrintLevel("error")
base = build_base()
heavy = coordinate_branch(
    base,
    "heavy_coordinates",
    {
        "MnWO4_wolframite": ["Mn1", "W1"],
        "WO3_gamma_monoclinic": ["W1", "W2"],
    },
)
coordinate_branch(
    heavy,
    "oxygen_coordinates",
    {
        "MnWO4_wolframite": ["O1", "O2"],
        "WO3_gamma_monoclinic": ["O1", "O2", "O3", "O4"],
    },
)
