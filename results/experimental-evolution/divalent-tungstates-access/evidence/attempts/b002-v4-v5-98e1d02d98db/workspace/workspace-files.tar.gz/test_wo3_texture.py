#!/usr/bin/env python3
"""Test one March-Dollase WO3 texture axis at a time."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "final.gpx"
OUT = ROOT / "branches/wo3_texture"
OUT.mkdir(parents=True, exist_ok=True)
AXES = {"100": [1, 0, 0], "010": [0, 1, 0], "001": [0, 0, 1]}


def run(label, axis):
    branch = OUT / label
    branch.mkdir(exist_ok=True)
    path = branch / "model.gpx"
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(path))
    hist = gpx.histogram(0)
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    for phase in gpx.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    wo = gpx.phase("WO3_gamma_monoclinic")
    po = wo.data["Histograms"][hist.name]["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", 1.0, True, axis
    gpx.set_Controls("parmMin", 0.5, variable=f"{wo.id}:0:MD")
    gpx.set_Controls("parmMax", 2.0, variable=f"{wo.id}:0:MD")
    gpx.set_Controls("cycles", 20)
    prior = None
    prior_n = 0
    for _ in range(6):
        gpx.refine()
        wr = float(hist.get_wR())
        n = sum(len(v) for v in gpx.get_Controls("parmFrozen").values())
        if prior is not None and n == prior_n and abs(wr - prior) < 1e-4:
            break
        prior, prior_n = wr, n
    gpx.save()
    replay_path = branch / "replay.gpx"
    shutil.copy2(path, replay_path)
    replay = G2sc.G2Project(str(replay_path))
    replay.set_Controls("cycles", 0)
    replay.refine()
    replay_wr = float(replay.histogram(0).get_wR())
    if abs(replay_wr - hist.get_wR()) > 1e-3:
        raise RuntimeError(f"{label} does not replay")
    result = {
        "axis": axis,
        "wR_percent": float(hist.get_wR()),
        "MD": float(po[1]),
        "mass_fractions": {
            name: [float(v) for v in values]
            for name, values in hist.ComputeMassFracs().items()
        },
        "gpx": str(path.relative_to(ROOT)),
    }
    (branch / "summary.json").write_text(json.dumps(result, indent=2))
    print(label, result)
    return result


G2sc.SetPrintLevel("error")
results = [run(label, axis) for label, axis in AXES.items()]
(OUT / "comparison.json").write_text(json.dumps(results, indent=2))
