#!/usr/bin/env python3
"""Export each phase in a GSAS-II project as a CIF.

The project itself is not modified. Clearing the in-memory covariance avoids
mixing uncertainties from a staged refinement with parameters that were fixed
in the most recent stage.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import re

import GSASIIscriptable as G2


def safe_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", name).strip("_") or "phase"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.project.resolve()))
    project.data.get("Covariance", {}).setdefault("data", {}).clear()
    for phase in project.phases():
        destination = args.output_dir / f"{safe_name(phase.name)}.cif"
        phase.export_CIF(str(destination.resolve()))
        print(f"{phase.name}\t{destination}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
