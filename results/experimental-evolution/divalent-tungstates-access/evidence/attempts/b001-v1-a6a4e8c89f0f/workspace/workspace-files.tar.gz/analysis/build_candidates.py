#!/usr/bin/env python
"""Build and physically screen the candidate structures used in phase discovery."""

from __future__ import annotations

import json
import shutil
import warnings
from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = Path(__file__).resolve().parent / "candidates"


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


# Exact-composition structures are retained without rewriting. Analogue-derived
# models replace one element on the parent's crystallographic sites and retain
# its cell, coordinates, occupancies, and topology.
MODELS = [
    ("CuWO4_Pm1_cod4000806", "4000806", {}),
    ("CuWO4_P2c_cod4000807", "4000807", {}),
    ("CuWO4_from_ZnWO4_Pm1_2101690", "2101690", {"Zn": "Cu"}),
    ("CuWO4_from_ZnWO4_Pm1_2101679", "2101679", {"Zn": "Cu"}),
    ("CuWO4_from_CuMoO4_Pm1_1535336", "1535336", {"Mo": "W"}),
    ("CuWO4_from_FeWO4_P2c_9008124", "9008124", {"Fe": "Cu"}),
    ("CuWO4_from_MgWO4_P2c_9013902", "9013902", {"Mg": "Cu"}),
    ("CuWO4_from_ZnWO4_P2c_1520641", "1520641", {"Zn": "Cu"}),
    ("CuWO4_from_MnWO4_P2c_1520200", "1520200", {"Mn": "Cu"}),
    ("CuWO4_from_CdWO4_P2c_1520645", "1520645", {"Cd": "Cu"}),
    ("CuO_C2c_1011194", "1011194", {}),
    ("CuO_Cc_9016057", "9016057", {}),
    ("Cu2O_Pn3m_1010941", "1010941", {}),
    ("Cu4O3_I41amd_9000603", "9000603", {}),
    ("Cu3WO6_Pa3_1527404", "1527404", {}),
    ("Cu2WO4_P1_2002403", "2002403", {}),
    ("WO3_P6mmm_1004057", "1004057", {}),
    ("WO3_P21m_1010618", "1010618", {}),
    ("WO3_P4ncc_1521532", "1521532", {}),
    ("WO3_P4nmm_1521533", "1521533", {}),
    ("WO3_P21c_1528915", "1528915", {}),
    ("WO3_P21c_1563541", "1563541", {}),
    ("WO3_P21c_2311041", "2311041", {}),
    ("WO3_Pm1_2106293", "2106293", {}),
    ("WO3_Pnma_2107312", "2107312", {}),
]


def screen(structure: Structure) -> dict:
    occupancies = [float(sum(site.species.values())) for site in structure]
    dm = np.asarray(structure.distance_matrix, float)
    dm[dm < 1e-8] = np.inf
    symbols = [site.specie.symbol for site in structure]
    oo = [
        dm[i, j]
        for i in range(len(structure))
        for j in range(i + 1, len(structure))
        if symbols[i] == symbols[j] == "O"
    ]
    metal_o = [
        dm[i, j]
        for i in range(len(structure))
        for j in range(len(structure))
        if symbols[i] != "O" and symbols[j] == "O"
    ]
    return {
        "formula": structure.composition.reduced_formula,
        "full_composition": structure.composition.formula,
        "space_group": structure.get_space_group_info(symprec=1e-3)[0],
        "space_group_number": structure.get_space_group_info(symprec=1e-3)[1],
        "sites": len(structure),
        "cell": [float(v) for v in (*structure.lattice.abc, *structure.lattice.angles)],
        "volume_A3": float(structure.volume),
        "occupancy_min": min(occupancies),
        "occupancy_max": max(occupancies),
        "minimum_contact_A": float(np.min(dm)),
        "minimum_O_O_A": float(min(oo)) if oo else None,
        "minimum_cation_O_A": float(min(metal_o)) if metal_o else None,
        "passes_occupancy": min(occupancies) >= 0 and max(occupancies) <= 1.0001,
        "passes_hard_contact": float(np.min(dm)) >= 0.8,
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    records = []
    for name, cod_id, substitutions in MODELS:
        source = cod_path(cod_id)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            structure = Structure.from_file(source, primitive=False)
        if substitutions:
            structure.replace_species(substitutions)
            destination = OUT / f"{name}.cif"
            CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(destination)
            basis = "analogue_derived"
        elif cod_id == "2002403":
            # The published CIF's unquoted ``x,y,z`` symmetry operation is
            # accepted by pymatgen but not by the GSAS-II CIF importer. Rewrite
            # the parsed P1 structure without changing its cell or sites.
            destination = OUT / f"{name}.cif"
            CifWriter(structure, symprec=None, refine_struct=False).write_file(destination)
            basis = "repaired"
        else:
            destination = OUT / f"{name}.cif"
            shutil.copyfile(source, destination)
            basis = "published"
        check = screen(structure)
        records.append(
            {
                "name": name,
                "path": str(destination.relative_to(Path.cwd())),
                "cod_id": cod_id,
                "model_basis": basis,
                "substitutions": substitutions,
                "screen": check,
            }
        )
    (OUT / "inventory.json").write_text(json.dumps(records, indent=2) + "\n")
    for record in records:
        s = record["screen"]
        print(
            f"{record['name']:42s} {s['formula']:9s} {s['space_group']:9s} "
            f"occ={s['occupancy_min']:.3f}-{s['occupancy_max']:.3f} "
            f"dmin={s['minimum_contact_A']:.3f} O-O={s['minimum_O_O_A']:.3f}"
        )


if __name__ == "__main__":
    main()
