#!/usr/bin/env python
"""Run a staged, identity-addressed GSAS-II powder refinement trial.

This script is intentionally conservative for candidate screening: every phase
starts with a positive scale, profile and coordinates are fixed unless their
stages are explicitly requested, and a stage is classified unknown if the
refinement fails or creates an invalid cell/scale.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import shutil
import sys
import traceback
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter

from GSASII import GSASIIscriptable as G2


def parse_phase(text: str) -> tuple[str, Path]:
    if "=" not in text:
        raise argparse.ArgumentTypeError("phase must be NAME=PATH")
    name, path = text.split("=", 1)
    path = Path(path).resolve()
    if not name or not path.is_file():
        raise argparse.ArgumentTypeError(f"invalid phase specification: {text}")
    return name, path


def prepare_observation(csv_path: Path, xye_path: Path) -> tuple[np.ndarray, np.ndarray]:
    values = np.loadtxt(csv_path, delimiter=",", skiprows=1)
    x, y = values.T
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(xye_path, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")
    return x, y


def write_instrument(path: Path) -> None:
    path.write_text(
        "#GSAS-II instrument parameter file; Cu K-alpha Bragg-Brentano starting model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:20.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def initial_background(x: np.ndarray, y: np.ndarray, terms: int = 12) -> list[float]:
    # A broad lower-percentile envelope supplies a stable linear starting point;
    # all coefficients are subsequently refined by GSAS-II.
    baseline = percentile_filter(y, percentile=18, size=401, mode="nearest")
    baseline = gaussian_filter1d(baseline, 80)
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(t, baseline, terms - 1).tolist()


def rwp(hist) -> float:
    arrays = hist.data["data"][1]
    yobs = np.asarray(arrays[1], float)
    weights = np.asarray(arrays[2], float)
    ycalc = np.asarray(arrays[3], float)
    return 100.0 * math.sqrt(np.sum(weights * (yobs - ycalc) ** 2) / np.sum(weights * yobs**2))


def state(project: G2.G2Project, histogram_name: str) -> dict:
    hist = project.histogram(histogram_name)
    phases = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram_name]
        scale = float(hap["Scale"][0])
        mass = float(phase.data["General"]["Mass"])
        cell = phase.get_cell()
        volume = float(cell["volume"])
        phases.append(
            {
                "name": phase.name,
                "scale": scale,
                "cell_mass": mass,
                "mass_times_scale": mass * scale,
                "cell": {key: float(value) for key, value in cell.items()},
                "use": bool(hap.get("Use", True)),
                "size": hap.get("Size"),
                "mustrain": hap.get("Mustrain"),
                "preferred_orientation": hap.get("Pref.Ori."),
            }
        )
        masses.append(max(0.0, mass * scale))
    total = sum(masses)
    for phase, amount in zip(phases, masses):
        phase["weight_fraction"] = amount / total if total > 0 else None
    cov = project.data.get("Covariance", {}).get("data", {})
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    return {
        "rwp_percent_recomputed": rwp(hist),
        "rwp_percent_gsas": hist.get_wR(),
        "covariance_Rvals": cov.get("Rvals", {}),
        "vary_list": [str(v) for v in cov.get("varyList", [])],
        "instrument": {
            key: value
            for key, value in inst.items()
            if key in {"Lam", "Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}
        },
        "sample": {
            key: value
            for key, value in sample.items()
            if key in {"Scale", "Type", "Gonio. radius", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"}
        },
        "phases": phases,
    }


def validate(snapshot: dict) -> tuple[bool, str]:
    for phase in snapshot["phases"]:
        if not phase["use"]:
            return False, f"phase unexpectedly inactive: {phase['name']}"
        # A scale that refines to the imposed zero boundary is a valid tested
        # result (the candidate contribution collapsed and can be rejected).
        # Negative or nonfinite scales indicate an invalid trial.
        if not np.isfinite(phase["scale"]) or phase["scale"] < -1e-12:
            return False, f"negative or nonfinite scale: {phase['name']}={phase['scale']}"
        cell = phase["cell"]
        if (
            not all(np.isfinite(cell[key]) and cell[key] > 0 for key in ("length_a", "length_b", "length_c", "volume"))
            or not all(20.0 < cell[key] < 160.0 for key in ("angle_alpha", "angle_beta", "angle_gamma"))
        ):
            return False, f"invalid cell: {phase['name']} {cell}"
    return True, "ok"


def export_profile(hist, path: Path) -> None:
    arrays = hist.data["data"][1]
    x, yobs, weights, ycalc, background, difference = [np.asarray(v, float) for v in arrays[:6]]
    with path.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed", "calculated", "background", "difference", "weight"])
        writer.writerows(zip(x, yobs, ycalc, background, difference, weights))


def configure_limits(project: G2.G2Project, hist, phases) -> None:
    project.index_ids()
    h = hist.id
    # Broad physical limits prevent otherwise linear profile/scale steps from
    # crossing unphysical boundaries during candidate screening.
    for phase in phases:
        p = phase.id
        project.set_Controls("parmMin", 0.0, f"{p}:{h}:Scale")
    for key, low in (("U", 0.0), ("W", 0.0), ("X", 0.0), ("SH/L", 0.001)):
        project.set_Controls("parmMin", low, f":{h}:{key}")
    for key, high in (("U", 100.0), ("W", 100.0), ("X", 20.0), ("SH/L", 0.3)):
        project.set_Controls("parmMax", high, f":{h}:{key}")
    project.set_Controls("parmMin", -2.0, f":{h}:Zero")
    project.set_Controls("parmMax", 2.0, f":{h}:Zero")
    project.set_Controls("parmMin", -2000.0, f":{h}:Shift")
    project.set_Controls("parmMax", 2000.0, f":{h}:Shift")
    project.set_Controls("parmMin", 0.0, f":{h}:Polariz.")
    project.set_Controls("parmMax", 1.0, f":{h}:Polariz.")
    for phase in phases:
        p = phase.id
        project.set_Controls("parmMin", 0.02, f"{p}:{h}:Size;i")
        project.set_Controls("parmMax", 20.0, f"{p}:{h}:Size;i")
        project.set_Controls("parmMin", 0.0, f"{p}:{h}:Mustrain;i")
        project.set_Controls("parmMax", 20000.0, f"{p}:{h}:Mustrain;i")
        project.set_Controls("parmMin", 0.0, f"{p}:{h}:Mustrain;a")
        project.set_Controls("parmMax", 20000.0, f"{p}:{h}:Mustrain;a")
        project.set_Controls("parmMin", 0.0, f"{p}::AUiso:*")
        project.set_Controls("parmMax", 0.1, f"{p}::AUiso:*")
        project.set_Controls("parmMin", 0.2, f"{p}:{h}:MD")
        project.set_Controls("parmMax", 5.0, f"{p}:{h}:MD")


def clear_all_refinement_flags(hist, phases) -> None:
    """Retain values from a stable project while clearing every vary flag."""
    # G2PwdrData.clear_refinements returns immediately for a boolean
    # Background request, so clear histogram/sample flags first and background
    # in a separate call.
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"],
            "Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        }
    )
    hist.clear_refinements({"Background": True})
    for phase in phases:
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
                "Babinet": ["BabA", "BabU"],
            },
            [hist],
        )


def set_stage(
    project,
    hist,
    phases,
    stage: str,
    target_names: list[str] | None = None,
    coordinate_elements: list[str] | None = None,
    mustrain_axis: list[int] | None = None,
    texture_axis: list[int] | None = None,
) -> None:
    selected = phases
    if target_names:
        by_name = {phase.name: phase for phase in phases}
        missing = sorted(set(target_names) - set(by_name))
        if missing:
            raise ValueError(f"target phase identities not present: {missing}")
        selected = [by_name[name] for name in target_names]
    if stage == "scale_background":
        hist.set_refinements({"Background": True})
        for phase in phases:
            phase.set_HAP_refinements({"Scale": True}, [hist])
    elif stage == "shift":
        # The effective angular shift is established before cell terms. Sample
        # displacement is introduced only in a later, separately tested stage.
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    elif stage == "cell":
        for phase in selected:
            phase.set_refinements({"Cell": True})
    elif stage == "profile":
        hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "SH/L"]})
    elif stage == "profile_no_u":
        hist.set_refinements({"Instrument Parameters": ["V", "W", "X", "SH/L"]})
    elif stage == "profile_no_v":
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    elif stage == "profile_wx":
        hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    elif stage == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif stage in {"size", "mustrain", "microstructure"}:
        for phase in selected:
            refs = {}
            if stage in {"size", "microstructure"}:
                refs["Size"] = {"type": "isotropic", "refine": True}
            if stage in {"mustrain", "microstructure"}:
                refs["Mustrain"] = {"type": "isotropic", "refine": True}
            phase.set_HAP_refinements(
                refs,
                [hist],
            )
    elif stage == "mustrain_uniaxial":
        if not mustrain_axis or len(mustrain_axis) != 3 or not any(mustrain_axis):
            raise ValueError("mustrain_uniaxial requires a nonzero --mustrain-axis h k l")
        for phase in selected:
            hap = phase.data["Histograms"][hist.name]
            if hap["Mustrain"][0] != "uniaxial":
                hap["Mustrain"][1][1] = hap["Mustrain"][1][0]
            phase.set_HAP_refinements(
                {
                    "Mustrain": {
                        "type": "uniaxial",
                        "direction": mustrain_axis,
                        "refine": True,
                    }
                },
                [hist],
            )
    elif stage == "texture":
        if not texture_axis or len(texture_axis) != 3 or not any(texture_axis):
            raise ValueError("texture requires a nonzero --texture-axis h k l")
        for phase in selected:
            po = phase.data["Histograms"][hist.name]["Pref.Ori."]
            if po[0] != "MD" or list(po[3]) != list(texture_axis):
                po[1] = 1.0
            po[0] = "MD"
            po[2] = True
            po[3] = list(texture_axis)
    elif stage == "displacement":
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    elif stage == "coordinates":
        for phase in selected:
            for atom in phase.atoms():
                if not coordinate_elements or atom.element in coordinate_elements:
                    atom.refinement_flags = "X"
    elif stage in {"uiso_common", "uiso_existing"}:
        # The synthetic/reference model assigns one isotropic displacement
        # amplitude per phase. Use an equality constraint so scale and thermal
        # falloff are not traded against many independent atom ADPs.
        project.index_ids()
        for phase in selected:
            variables = []
            for index, atom in enumerate(phase.atoms()):
                atom.refinement_flags = "U"
                variables.append(f"{phase.id}::AUiso:{index}")
            if stage == "uiso_common" and len(variables) > 1:
                project.add_EquivConstr(variables, reloadIdx=False, override=True)
    else:
        raise ValueError(f"unknown stage: {stage}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--phase", action="append", type=parse_phase, default=[])
    parser.add_argument(
        "--stages",
        nargs="+",
        default=["scale_background", "shift", "cell", "scale_background"],
        choices=[
            "scale_background",
            "shift",
            "cell",
            "profile",
            "profile_no_u",
            "profile_no_v",
            "profile_wx",
            "polarization",
            "size",
            "mustrain",
            "microstructure",
            "mustrain_uniaxial",
            "texture",
            "displacement",
            "coordinates",
            "uiso_common",
            "uiso_existing",
        ],
    )
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument(
        "--target-phase",
        action="append",
        default=[],
        help="identity-addressed subset for cell, size/mustrain, or coordinate stages",
    )
    parser.add_argument(
        "--coordinate-element",
        action="append",
        default=[],
        help="element subset for the coordinates stage (default: all elements in target phases)",
    )
    parser.add_argument("--mustrain-axis", nargs=3, type=int, metavar=("H", "K", "L"))
    parser.add_argument("--texture-axis", nargs=3, type=int, metavar=("H", "K", "L"))
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument(
        "--base-project",
        type=Path,
        help="clone a stable project, retain its parameter values, and add the requested phases",
    )
    args = parser.parse_args()

    if not args.base_project and not args.phase:
        parser.error("at least one --phase is required when --base-project is not supplied")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    gpx = args.output_dir / "trial.gpx"
    G2.SetPrintLevel("warn")
    if args.base_project:
        project = G2.G2Project(gpxfile=str(args.base_project.resolve()), newgpx=str(gpx.resolve()))
        powder = project.histograms(typ="PWDR")
        if len(powder) != 1:
            raise RuntimeError("base project must contain exactly one powder histogram")
        hist = powder[0]
        x = np.asarray(hist.data["data"][1][0], float)
        y = np.asarray(hist.data["data"][1][1], float)
        phases = list(project.phases())
        expected_names = [phase.name for phase in phases]
        clear_all_refinement_flags(hist, phases)
    else:
        xye = args.output_dir / "pattern.xye"
        inst = args.output_dir / "instrument.instprm"
        x, y = prepare_observation(args.pattern.resolve(), xye)
        write_instrument(inst)
        project = G2.G2Project(newgpx=str(gpx.resolve()))
        hist = project.add_powder_histogram(str(xye.resolve()), str(inst.resolve()), fmthint="xye")
        hist.SampleParameters["Type"] = "Bragg-Brentano"
        hist.SampleParameters["Gonio. radius"] = 200.0
        hist.SampleParameters["Shift"] = [0.0, False]
        hist.SampleParameters["Scale"] = [1.0, False]
        coefficients = initial_background(x, y)
        hist.set_refinements(
            {
                "Limits": [float(x[0]), float(x[-1])],
                "Background": {
                    "type": "chebyschev-1",
                    "no. coeffs": len(coefficients),
                    "coeffs": coefficients,
                    "refine": False,
                },
            }
        )
        phases = []
        expected_names = []

    existing_amount = sum(
        float(phase.data["General"]["Mass"])
        * max(0.0, float(phase.data["Histograms"][hist.name]["Scale"][0]))
        for phase in phases
    )
    for name, path in args.phase:
        if name in expected_names:
            raise RuntimeError(f"phase identity already exists in base project: {name}")
        expected_names.append(name)
        phase = project.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
        if phase.name != name:
            raise RuntimeError(f"phase identity mismatch: requested {name}, imported {phase.name}")
        mass = float(phase.data["General"]["Mass"])
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        # New candidates enter a stable project with a small but finite 3 wt%
        # contribution. New projects use equal positive mass contributions.
        if existing_amount > 0:
            start_amount = existing_amount * 0.03 / 0.97
        else:
            start_amount = 100.0
        hap["Scale"] = [start_amount / mass, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.5
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        phases.append(phase)

    # Phase import may add default flags; clear all, while retaining the
    # deliberately positive initialized scales, before the requested recipe.
    clear_all_refinement_flags(hist, phases)
    project.data.get("Covariance", {}).setdefault("data", {}).clear()

    if [phase.name for phase in phases] != expected_names:
        raise RuntimeError("active phase list does not match the identity-addressed request")
    if any(phase.data["Histograms"][hist.name]["Scale"][0] <= 0 for phase in phases):
        raise RuntimeError("all intended candidates must begin with a positive scale")

    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    configure_limits(project, hist, phases)
    project.save()

    history = []
    initial = state(project, hist.name)
    history.append({"stage": "initial", "status": "ok", "state": initial})
    status = "tested"
    failure = None
    for index, stage in enumerate(args.stages, start=1):
        before = args.output_dir / f"stage_{index:02d}_{stage}_before.gpx"
        project.save(str(before.resolve()))
        # Continue saving/refining into the canonical trial path.
        project.filename = str(gpx.resolve())
        project.data["Controls"]["data"]["LastSavedAs"] = str(gpx.resolve())
        try:
            set_stage(
                project,
                hist,
                phases,
                stage,
                args.target_phase,
                args.coordinate_element,
                args.mustrain_axis,
                args.texture_axis,
            )
            project.refine(makeBack=False)
            snapshot = state(project, hist.name)
            ok, reason = validate(snapshot)
            history.append({"stage": stage, "status": "ok" if ok else "invalid", "reason": reason, "state": snapshot})
            if not ok:
                status = "unknown"
                failure = f"{stage}: {reason}"
                shutil.copyfile(before, gpx)
                project = G2.G2Project(gpxfile=str(gpx.resolve()))
                hist = project.histogram(hist.name)
                phases = [project.phase(name) for name in expected_names]
                break
        except Exception as exc:
            status = "unknown"
            failure = f"{stage}: {type(exc).__name__}: {exc}"
            history.append(
                {
                    "stage": stage,
                    "status": "exception",
                    "error": failure,
                    "traceback": traceback.format_exc(),
                }
            )
            shutil.copyfile(before, gpx)
            project = G2.G2Project(gpxfile=str(gpx.resolve()))
            hist = project.histogram(hist.name)
            phases = [project.phase(name) for name in expected_names]
            break

    project.save(str(gpx.resolve()))
    final_state = state(project, hist.name)
    export_profile(hist, args.output_dir / "profile.csv")
    summary = {
        "status": status,
        "failure": failure,
        "active_phase_identities": expected_names,
        "stages_requested": args.stages,
        "history": history,
        "final": final_state,
    }
    (args.output_dir / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps({"status": status, "failure": failure, "final": final_state}, indent=2, default=str))
    return 0 if status == "tested" else 2


if __name__ == "__main__":
    sys.exit(main())
