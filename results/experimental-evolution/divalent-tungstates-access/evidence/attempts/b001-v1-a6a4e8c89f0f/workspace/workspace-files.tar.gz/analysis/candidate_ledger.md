# Candidate ledger

Every quantitative branch started from a stable project with the same
instrument/background convention and a positive scale. A failed, interrupted,
or unimported branch is `unknown`, not rejected. Fractions below are normalized
over the active crystalline model in that trial.

| Candidate branch | Basis and common-setting result | Status |
|---|---|---|
| CuWO4, P-1 (COD 4000806) | Exact formula; single-phase Rwp 32.371%, versus 51.877--55.025% for the analogue/topology shortlist. It remains the dominant positive contribution in every closed inventory. | **selected** |
| CuWO4, P2/c (COD 4000807) | Exact formula wolframite alternative; single-phase Rwp 54.906%. As an extra phase in the four-phase model it contributed only 0.099 wt%. | rejected |
| CuWO4 from ZnWO4 P-1 (COD 2101690, 2101679) | Zn->Cu one-substitution models, physical after substitution; common single-phase Rwp 51.877% and 52.667%. | rejected |
| CuWO4 from CuMoO4 P-1 (COD 1535336) | Mo->W one-substitution topology; physical, common single-phase Rwp 54.261%. | rejected |
| CuWO4 from Fe/Mg/Zn/Mn/CdWO4 P2/c | One-cation-substitution wolframite relatives; physical, common single-phase Rwp 54.189--55.025%. | rejected |
| WO3, P21/c (COD 2311041) | Exact formula precursor; best same-formula two-phase branch, Rwp 19.968% with 23.87 wt% WO3 before inventory closure. Stable near 20 wt% in the final model. | **selected** |
| WO3, P-1 (COD 2106293) | Exact formula; two-phase Rwp 20.079%, but its scale collapsed when tested as an additional polymorph beside selected P21/c WO3. | rejected |
| WO3, P21/c (COD 1563541), Pnma, P4/ncc, P4/nmm | Exact-formula alternatives; common two-phase Rwp 27.477--31.556%, materially worse than COD 2311041. | rejected |
| WO3, P6/mmm (COD 1004057) | Trial produced no reflections in range and could not be evaluated stably. | unknown |
| WO3 source models COD 1010618 and 1528915 | Failed pre-fit geometry screen (sub-angstrom contact in 1010618; 1.575 A O--O in 1528915). | rejected as unphysical source models |
| Cu3WO6, Pa-3 (COD 1527404) | Exact formula; uniquely explains the sharp 15, 20, and 33--35 degree families. Two-phase Rwp 26.346%; order-independent three-phase fits both reached Rwp 10.336% with about 15.1 wt% Cu3WO6. Prototype-neighbour search found the exact entry as the sole surviving close framework. | **selected** |
| CuO, C2/c (COD 1011194) | Exact formula precursor; closes the 32.5, 35.6, 38.7, and higher-angle residual family. Four-phase common-setting Rwp 9.7714%, with 2.96 wt% CuO. | **selected** |
| CuO, Cc (COD 9016057) | Lower-symmetry exact-formula alternative; four-phase Rwp 9.7729%, slightly worse than C2/c and less economical. | rejected |
| Cu2O, Pn-3m (COD 1010941) | Exact formula oxide; the closure retest diverged/collapsed and produced no usable reflection trial. | unknown |
| Cu4O3, I41/amd (COD 9000603) | Exact formula oxide; scale collapsed to effectively zero in the closure retest. | rejected |
| Cu2WO4, P1 (COD 2002403) | Exact formula off-stoichiometric oxide; repaired serialization preserved the published P1 cell/sites. Stable trial gave only 0.143 wt% and required a strongly distorted cell. Prototype-neighbour search found no competing close framework beyond the exact entry. | rejected |

The closed four-phase model has no remaining one-sign coherent residual family.
The largest residual extrema are paired negative/positive lobes around strong
modeled reflections, so no fractional solid solution or additional substituted
prototype was promoted to a quantitative branch. Late post-cell profile trials
that became numerically stuck were rolled back and remain **unknown**.
