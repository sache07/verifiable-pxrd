#!/usr/bin/env python3
"""Perform basic physical-integrity checks on one or more CIFs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


def element(site) -> str:
    return max(site.species.items(), key=lambda item: item[1])[0].symbol


def screen(path: Path) -> dict:
    structure = Structure.from_file(path, primitive=False)
    elements = [element(site) for site in structure]
    distances = np.asarray(structure.distance_matrix, float)
    np.fill_diagonal(distances, np.inf)
    pair_minima: dict[str, float] = {}
    for i in range(len(structure)):
        for j in range(i + 1, len(structure)):
            key = "-".join(sorted((elements[i], elements[j])))
            value = float(distances[i, j])
            pair_minima[key] = min(pair_minima.get(key, np.inf), value)

    occupancies = [float(sum(site.species.values())) for site in structure]
    try:
        symmetry = SpacegroupAnalyzer(structure, symprec=1e-3).get_space_group_symbol()
    except Exception:
        symmetry = None
    return {
        "path": str(path),
        "formula": structure.composition.reduced_formula,
        "sites_in_conventional_cell": len(structure),
        "space_group_reidentified": symmetry,
        "cell": {
            "a": float(structure.lattice.a),
            "b": float(structure.lattice.b),
            "c": float(structure.lattice.c),
            "alpha": float(structure.lattice.alpha),
            "beta": float(structure.lattice.beta),
            "gamma": float(structure.lattice.gamma),
            "volume": float(structure.volume),
        },
        "occupancy_range": [min(occupancies), max(occupancies)],
        "minimum_contact_A": float(np.min(distances)),
        "pair_minima_A": dict(sorted(pair_minima.items())),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("cifs", nargs="+", type=Path)
    args = parser.parse_args()
    print(json.dumps([screen(path) for path in args.cifs], indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
