#!/usr/bin/env python3
"""Freshly replay a GSAS-II project and report observed-data Rwp."""

from pathlib import Path
import importlib.util
import json
import sys

import numpy as np


if len(sys.argv) not in (3, 4):
    raise SystemExit("usage: replay_check.py PROJECT.gpx OBSERVED.csv [HISTOGRAM]")
project = str(Path(sys.argv[1]).resolve())
observed = str(Path(sys.argv[2]).resolve())
histogram = sys.argv[3] if len(sys.argv) == 4 else None
worker_path = (Path(__file__).resolve().parent /
               "learned/divalent-tungstates/scorer/runtime/replay_worker.py")
spec = importlib.util.spec_from_file_location("local_replay_worker", worker_path)
worker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(worker)
request = {"project": project, "observed": observed}
if histogram:
    request["histogram"] = histogram
result = worker.replay(request)
archive = np.load("prediction.npz")
y = archive["observed"]
calculated = archive["predicted"]
weight = 1.0 / np.maximum(y, 1.0)
rwp = 100.0 * np.sqrt(np.sum(weight * (y-calculated)**2) /
                      np.sum(weight * y**2))
print(json.dumps({"status": result["status"],
                  "sha256": result["project_sha256"],
                  "histogram": result["histogram"],
                  "weight_fractions": {p["name"]: p["weight_fraction"]
                                       for p in result["phases"]},
                  "profile_review_flags": result["profile_review_flags"],
                  "replay_rwp_percent": float(rwp),
                  "calculated_min": float(calculated.min())}, indent=2))
