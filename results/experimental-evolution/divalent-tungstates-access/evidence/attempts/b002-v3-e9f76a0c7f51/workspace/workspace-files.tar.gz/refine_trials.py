#!/usr/bin/env python3
"""Run one conservative GSAS-II trial from an existing physical project."""

import json
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


def bound(project, variable, low, high):
    project.set_Controls("parmMin", float(low), variable)
    project.set_Controls("parmMax", float(high), variable)


def reset(project):
    """Clear every refinement flag and stale frozen/bound records."""
    h = project.histogram(0)
    h.Background[0][1] = False
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in h.SampleParameters.values():
        if (isinstance(value, list) and len(value) > 1
                and isinstance(value[1], (bool, np.bool_))):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        for value in hap.get("Babinet", {}).values():
            value[1] = False
    project.get_Constraints("Phase").clear()
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    # Refine and replay the complete measured grid.
    x = np.asarray(h.data["data"][1][0], float)
    h.data["Limits"][1] = [float(x[0]), float(x[-1])]
    return h


def coordinate_bounds(project, pidx, phase, atom_indices, frac_limit):
    atoms = list(phase.atoms())
    for i in atom_indices:
        atom = atoms[i]
        for axis, value in zip("xyz", atom.coordinates):
            bound(project, f"{pidx}::dA{axis}:{i}", value-frac_limit, value+frac_limit)


def main():
    if len(sys.argv) < 4:
        raise SystemExit("usage: refine_trials.py INPUT.gpx OUTPUT.gpx MODE [ARGS...]")
    source, destination, mode, *args = sys.argv[1:]
    G2.SetPrintLevel("error")
    project = G2.G2Project(source, filename=destination)
    h = reset(project)
    phases = project.phases()

    # Re-optimize only scale/background alongside each tested effect.
    h.Background[0][1] = True
    for phase in phases:
        phase.data["Histograms"][h.name]["Scale"][1] = True

    if mode == "cleanup":
        pass
    elif mode == "roughness":
        h.SampleParameters["SurfRoughA"] = [0.30, True]
        h.SampleParameters["SurfRoughB"] = [0.10, True]
        bound(project, ":0:SurfRoughA", 0.05, 0.60)
        bound(project, ":0:SurfRoughB", 0.02, 0.50)
    elif mode == "po":
        pidx = int(args[0])
        axis = [int(v) for v in args[1].split(",")]
        start = float(args[2])
        po = phases[pidx].data["Histograms"][h.name]["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", start, True, axis
        bound(project, f"{pidx}:0:MD", 0.70, 1.40)
    elif mode == "uiso":
        pidx = int(args[0])
        phase = phases[pidx]
        variables = []
        for i, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "U"
            variables.append(f"{pidx}::AUiso:{i}")
            bound(project, variables[-1], 0.003, 0.020)
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=True, override=True)
    elif mode == "coords":
        pidx, selection, limit = int(args[0]), args[1], float(args[2])
        phase = phases[pidx]
        if selection == "all":
            indices = list(range(len(phase.atoms())))
        elif selection == "heavy":
            indices = [i for i, atom in enumerate(phase.atoms()) if atom.element != "O"]
        elif selection == "oxygen":
            indices = [i for i, atom in enumerate(phase.atoms()) if atom.element == "O"]
        else:
            indices = [int(v) for v in selection.split(",")]
        coordinate_bounds(project, pidx, phase, indices, limit)
        atoms = list(phase.atoms())
        for i in indices:
            atoms[i].refinement_flags = "X"
    elif mode == "cells":
        for phase in phases:
            phase.set_refinements({"Cell": True})
    elif mode == "calibration":
        h.InstrumentParameters["Zero"][2] = True
        h.SampleParameters["Shift"][1] = True
        bound(project, ":0:Zero", -0.25, 0.25)
        bound(project, ":0:Shift", -800.0, 800.0)
    elif mode == "shift_cells":
        h.SampleParameters["Shift"] = [float(args[0]), False]
        h.InstrumentParameters["Zero"][2] = True
        bound(project, ":0:Zero", -0.25, 0.25)
        for phase in phases:
            phase.set_refinements({"Cell": True})
    elif mode == "polarization":
        h.InstrumentParameters["Polariz."][2] = True
        bound(project, ":0:Polariz.", 0.50, 1.00)
    elif mode == "size_iso":
        pidx = int(args[0])
        hap = phases[pidx].data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][2][0] = True
        bound(project, f"{pidx}:0:Size;i", 0.04, 1.50)
    elif mode == "strain_iso":
        pidx = int(args[0])
        hap = phases[pidx].data["Histograms"][h.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = float(args[1]) if len(args) > 1 else 500.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2][0] = True
        bound(project, f"{pidx}:0:Mustrain;i", 0.0, 8000.0)
    elif mode == "strain_uniaxial":
        pidx = int(args[0])
        axis = [int(v) for v in args[1].split(",")]
        start = float(args[2]) if len(args) > 2 else 500.0
        hap = phases[pidx].data["Histograms"][h.name]
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][:3] = [start, start, 1.0]
        hap["Mustrain"][2][:3] = [True, True, False]
        hap["Mustrain"][3] = axis
        bound(project, f"{pidx}:0:Mustrain;i", 0.0, 8000.0)
        bound(project, f"{pidx}:0:Mustrain;a", 0.0, 8000.0)
    elif mode == "instrument":
        key = args[0]
        limits = {"U": (0.0, 40.0), "W": (2.0, 40.0),
                  "SH/L": (0.005, 0.10)}
        if key not in limits:
            raise SystemExit("unsupported instrument parameter: " + key)
        h.InstrumentParameters[key][2] = True
        bound(project, f":0:{key}", *limits[key])
    elif mode == "instrument_uw":
        for key, limits in {"U": (0.0, 40.0), "W": (2.0, 40.0)}.items():
            h.InstrumentParameters[key][2] = True
            bound(project, f":0:{key}", *limits)
    else:
        raise SystemExit("unknown mode: " + mode)

    project.set_Controls("cycles", 10)
    project.save()
    project.refine(makeBack=False)
    project.save()
    cov = project.data.get("Covariance", {}).get("data", {})
    vary_list = [str(v) for v in cov.get("varyList", [])]
    variables = np.asarray(cov.get("variables", [])).tolist()
    rvals = cov.get("Rvals", {})
    output = {
        "mode": mode,
        "Rwp": h.residuals.get("wR"),
        "Rp": h.residuals.get("R"),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "message": rvals.get("msg", ""),
        "variables": dict(zip(vary_list, variables)),
        "fractions": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "sample": {k: h.SampleParameters[k] for k in
                   ["Shift", "SurfRoughA", "SurfRoughB"]},
        "instrument": {k: h.InstrumentParameters[k] for k in
                       ["Zero", "Polariz.", "U", "W", "X", "SH/L"]},
        "phases": {},
    }
    for phase in phases:
        hap = phase.data["Histograms"][h.name]
        output["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "po": hap["Pref.Ori."],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "atoms": [{"label": a.label, "xyz": list(a.coordinates),
                       "uiso": a.uiso, "flags": a.refinement_flags}
                      for a in phase.atoms()],
        }
    print(json.dumps(output, default=str))


if __name__ == "__main__":
    main()
