#!/usr/bin/env python3
"""Fresh-grid March-Dollase axis trials from one structural project."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def freeze_except_scales(project):
    h = project.histogram(0)
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for key in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]:
        if isinstance(h.SampleParameters.get(key), list):
            h.SampleParameters[key][1] = False
    h.Background[0][1] = True
    project.get_Constraints("Phase").clear()
    for p in project.phases():
        p.clear_refinements({"Cell": True})
        p.set_refinements({"LeBail": False})
        for a in p.atoms():
            a.refinement_flags = " "
        hap = p.data["Histograms"][h.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: trial_preferred_orientation.py INPUT.gpx OUTDIR")
    source = Path(sys.argv[1]).resolve()
    outdir = Path(sys.argv[2]).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    results = []
    for axis in AXES:
        tag = "".join(str(x) for x in axis)
        output = outdir / f"po_{tag}.gpx"
        project = G2.G2Project(str(source), filename=str(output))
        freeze_except_scales(project)
        h = project.histogram(0)
        hap = project.phase(0).data["Histograms"][h.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.05
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        project.set_Controls("cycles", 8)
        project.save()
        project.set_Controls("parmMin", 0.7, "0:0:MD")
        project.set_Controls("parmMax", 1.4, "0:0:MD")
        project.refine(makeBack=False)
        row = {"axis": axis, "ratio": hap["Pref.Ori."][1],
               "wR": h.residuals.get("wR"), "R": h.residuals.get("R"),
               "fractions": {k: list(v) for k, v in h.ComputeMassFracs().items()}}
        results.append(row)
        print(json.dumps(row), flush=True)
        project.save()
    (outdir / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
