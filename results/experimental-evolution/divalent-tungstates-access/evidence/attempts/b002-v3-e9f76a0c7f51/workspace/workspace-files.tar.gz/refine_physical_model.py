#!/usr/bin/env python3
"""Conservative, physically bounded ZnWO4 + WO3 (+ trial ZnO) refinement."""

from pathlib import Path
import json
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
LIB = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c01/cif")


def cod_path(code):
    return LIB / code[0] / code[1:3] / code[3:5] / f"{code}.cif"


def scalarize(phase, uiso=0.01):
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = float(uiso)
        atom.data[atom.cia + 2:atom.cia + 8] = [0.0] * 6
        atom.refinement_flags = " "


def fractions(hist):
    try:
        return {k: [float(x) for x in v] for k, v in hist.ComputeMassFracs().items()}
    except Exception as exc:
        return {"error": str(exc)}


def record(project, stage):
    h = project.histogram(0)
    return {
        "stage": stage, "residuals": h.residuals, "fractions": fractions(h),
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "instrument": {k: v[1] for k, v in h.InstrumentParameters.items()
                       if k in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"]},
        "sample": {k: h.SampleParameters[k][0] for k in
                   ["Shift", "SurfRoughA", "SurfRoughB"]},
        "phases": {p.name: {
            "scale": p.data["Histograms"][h.name]["Scale"][0],
            "size": p.data["Histograms"][h.name]["Size"],
            "mustrain": p.data["Histograms"][h.name]["Mustrain"],
            "po": p.data["Histograms"][h.name]["Pref.Ori."],
            "atoms": [{"label": a.label, "element": a.element,
                       "xyz": list(a.coordinates), "uiso": a.uiso,
                       "flags": a.refinement_flags} for a in p.atoms()],
        } for p in project.phases()},
    }


def refine(project, outdir, stage, log, cycles=6):
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    yc = np.asarray(project.histogram(0).data["data"][1][3], float)
    if not np.all(np.isfinite(yc)):
        raise RuntimeError(f"nonfinite profile at {stage}")
    project.save()
    shutil.copy2(project.filename, outdir / f"{stage}.gpx")
    row = record(project, stage)
    log.append(row)
    print(json.dumps({"stage": stage, "wR": row["residuals"].get("wR"),
                      "R": row["residuals"].get("R"),
                      "fractions": row["fractions"]}), flush=True)


def set_bound(project, var, lo, hi):
    project.set_Controls("parmMin", lo, var)
    project.set_Controls("parmMax", hi, var)


def coordinate_bounds(project, phase_index, phase, heavy=0.015, oxygen=0.02):
    for i, atom in enumerate(phase.atoms()):
        lim = oxygen if atom.element == "O" else heavy
        for axis, value in zip("xyz", atom.coordinates):
            # Despite the historical dA name, GSAS-II's refined coordinate
            # variable stores the absolute fractional coordinate.
            set_bound(project, f"{phase_index}::dA{axis}:{i}", value - lim, value + lim)


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: refine_physical_model.py ZNWO4_START.cif RUN_TAG")
    zn_path = Path(sys.argv[1]).resolve()
    tag = sys.argv[2]
    outdir = ROOT / "physical" / tag
    outdir.mkdir(parents=True, exist_ok=True)
    gpx = outdir / "working.gpx"
    if gpx.exists():
        gpx.unlink()

    G2.SetPrintLevel("error")
    project = G2.G2Project(newgpx=str(gpx))
    h = project.add_powder_histogram(str(ROOT / "pattern.xye"),
                                     str(ROOT / "instrument.instprm"), fmthint="xye")
    paths = [zn_path, ROOT / "candidates" / "wo3_2311041_reduced.cif",
             cod_path("9004178")]
    names = ["ZnWO4_wolframite", "WO3_monoclinic", "ZnO_wurtzite_trial"]
    phases = [project.add_phase(str(path), phasename=name, histograms=[h], fmthint="CIF")
              for path, name in zip(paths, names)]
    znwo4, wo3, zno = phases
    for p in phases:
        scalarize(p)

    h.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {"type": "chebyschev-1", "no. coeffs": 12,
                       "coeffs": [900.0] + [0.0] * 11, "refine": True},
    })
    h.SampleParameters["Type"] = "Bragg-Brentano"
    h.SampleParameters["Gonio. radius"] = 200.0
    h.SampleParameters["Scale"][1] = False
    h.SampleParameters["Shift"] = [-502.6, False]
    h.SampleParameters["Transparency"] = [0.0, False]
    h.SampleParameters["SurfRoughA"] = [0.0, False]
    h.SampleParameters["SurfRoughB"] = [0.0, False]
    inst = h.InstrumentParameters
    for key, val in {"Zero": 0.0077, "Polariz.": 0.8, "U": 20.0,
                     "V": 0.0, "W": 15.0, "X": 2.0, "Y": 0.0,
                     "SH/L": 0.03}.items():
        inst[key][1] = val
        inst[key][2] = key in ["U", "W", "SH/L"]

    for p, scale in zip(phases, [85.0, 4.0, 4.0]):
        hap = p.data["Histograms"][h.name]
        hap["Scale"] = [scale, True]
        p.setSampleProfile(h, "size", "isotropic", 0.15, LGmix=1.0)
        p.setSampleProfile(h, "microstrain", "isotropic", 500.0, LGmix=1.0)
        p.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 0.15, "refine": True,
                     "LGmix": {"value": 1.0, "refine": False}},
            "Mustrain": {"type": "isotropic", "refine": True,
                         "LGmix": {"value": 1.0, "refine": False}},
        }, [h])
        p.set_refinements({"Cell": True, "LeBail": True})

    project.save()
    for var, lo, hi in [(":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0),
                        (":0:SH/L", 0.005, 0.10), ("0:0:MD", 0.7, 1.4)]:
        set_bound(project, var, lo, hi)
    for i in range(3):
        set_bound(project, f"{i}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{i}:0:Mustrain;i", 0.0, 8000.0)
    log = []
    refine(project, outdir, "01_lebail", log, cycles=8)
    refine(project, outdir, "02_lebail_replay", log, cycles=8)

    # Structural model starts from untouched, physically screened parents.
    for key in ["U", "W", "X", "SH/L", "Polariz."]:
        inst[key][2] = False
    for p in phases:
        p.clear_refinements({"Cell": True})
        p.set_refinements({"LeBail": False})
        p.clear_HAP_refinements({"Size": True, "Mustrain": True}, [h])
    po = znwo4.data["Histograms"][h.name]["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", 0.76, True, [1, 1, 1]
    refine(project, outdir, "03_parent_structures", log, cycles=8)

    coordinate_bounds(project, 0, znwo4)
    for a in znwo4.atoms():
        if a.element in ["Zn", "W"]:
            a.refinement_flags = "X"
    refine(project, outdir, "04_znwo4_heavy", log, cycles=8)
    for a in znwo4.atoms():
        if a.element == "O":
            a.refinement_flags = "X"
    refine(project, outdir, "05_znwo4_oxygen", log, cycles=8)

    # Only W positions are released in the 11%-level WO3 phase. Its oxygen
    # substructure remains the physical parent because it is not independently
    # supported at this counting precision.
    coordinate_bounds(project, 1, wo3, heavy=0.008, oxygen=0.008)
    for a in wo3.atoms():
        if a.element == "W":
            a.refinement_flags = "X"
    refine(project, outdir, "06_wo3_tungsten", log, cycles=8)

    # Reopen cells and polarization only after coordinates are stable.
    for p in phases:
        p.set_refinements({"Cell": True})
    inst["Polariz."][2] = True
    set_bound(project, ":0:Polariz.", 0.5, 1.0)
    refine(project, outdir, "07_final_replay", log, cycles=8)
    project.save(str(outdir / "physical_final.gpx"))
    (outdir / "stages.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
