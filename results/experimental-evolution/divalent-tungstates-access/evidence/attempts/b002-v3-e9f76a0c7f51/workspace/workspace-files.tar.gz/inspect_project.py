#!/usr/bin/env python3
"""Emit a compact JSON summary of a saved GSAS-II project."""

import json
import sys

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("error")
project = G2.G2Project(sys.argv[1])
hist = project.histogram(0)
cov = project.data.get("Covariance", {}).get("data", {})
result = {
    "histogram": hist.name,
    "residuals": hist.residuals,
    "Rvals": cov.get("Rvals", {}),
    "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
    "instrument": {k: v for k, v in hist.InstrumentParameters.items()
                   if k in {"Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."}},
    "sample": hist.SampleParameters,
    "phases": {},
}
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    result["phases"][phase.name] = {
        "cell": phase.get_cell(),
        "scale": hap["Scale"],
        "po": hap["Pref.Ori."],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "atoms": [
            {"label": atom.label, "element": atom.element,
             "xyz": list(atom.coordinates), "uiso": atom.uiso}
            for atom in phase.atoms()
        ],
    }
print(json.dumps(result, default=str, allow_nan=False))
