#!/usr/bin/env python3
"""Refine a physical multiphase profile with structures held fixed."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


def bound(project, var, lo, hi):
    project.set_Controls("parmMin", lo, var)
    project.set_Controls("parmMax", hi, var)


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: refine_profile_stage.py INPUT.gpx OUTPUT.gpx")
    G2.SetPrintLevel("error")
    project = G2.G2Project(sys.argv[1], filename=sys.argv[2])
    h = project.histogram(0)
    project.get_Constraints("Phase").clear()
    h.SampleParameters["Scale"][1] = False
    h.SampleParameters["Shift"][1] = False
    h.Background[0][1] = True
    for key, value in h.InstrumentParameters.items():
        if isinstance(value, list) and len(value) > 2:
            value[2] = key in ["U", "W", "SH/L"]
    for p in project.phases():
        p.clear_refinements({"Cell": True})
        p.set_refinements({"LeBail": False})
        for atom in p.atoms():
            atom.refinement_flags = " "
        hap = p.data["Histograms"][h.name]
        hap["Scale"][1] = True
        p.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True,
                     "LGmix": {"value": 1.0, "refine": False}},
            "Mustrain": {"type": "isotropic", "refine": True,
                         "LGmix": {"value": 1.0, "refine": False}},
        }, [h])
    # Keep only the accepted dominant [111] texture active.
    project.phase(0).data["Histograms"][h.name]["Pref.Ori."][2] = True
    for i, p in enumerate(project.phases()[1:], start=1):
        p.data["Histograms"][h.name]["Pref.Ori."][2] = False

    project.save()
    for var, lo, hi in [(":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0),
                        (":0:SH/L", 0.005, 0.1), ("0:0:MD", 0.7, 1.4)]:
        bound(project, var, lo, hi)
    for i in range(len(project.phases())):
        bound(project, f"{i}:0:Size;i", 0.04, 1.5)
        bound(project, f"{i}:0:Mustrain;i", 0.0, 8000.0)
    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    project.save()
    row = {
        "residuals": h.residuals,
        "fractions": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "instrument": {k: v[1] for k, v in h.InstrumentParameters.items()
                       if k in ["U", "V", "W", "X", "Y", "SH/L"]},
        "profiles": {p.name: {
            "size": p.data["Histograms"][h.name]["Size"],
            "mustrain": p.data["Histograms"][h.name]["Mustrain"],
            "po": p.data["Histograms"][h.name]["Pref.Ori."],
        } for p in project.phases()},
    }
    print(json.dumps(row, default=str))


if __name__ == "__main__":
    main()
