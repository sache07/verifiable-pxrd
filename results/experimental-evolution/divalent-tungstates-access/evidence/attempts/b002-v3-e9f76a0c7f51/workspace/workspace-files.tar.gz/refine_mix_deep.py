#!/usr/bin/env python3
"""Deep, staged three-phase refinement from a screened WO3 reference."""

from pathlib import Path
import json
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def scalarize_adps(phase, value=0.01):
    """Use one isotropic starting ADP per site, preserving atom identities."""
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = float(value)
        atom.data[atom.cia + 2:atom.cia + 8] = [0.0] * 6
        atom.refinement_flags = " "


def mass_fracs(hist):
    try:
        return {k: [float(x) for x in v] for k, v in hist.ComputeMassFracs().items()}
    except Exception as exc:
        return {"error": str(exc)}


def state(project, stage):
    h = project.histogram(0)
    phases = project.phases()
    return {
        "stage": stage,
        "residuals": h.residuals,
        "mass_fractions": mass_fracs(h),
        "cells": {p.name: p.get_cell() for p in phases},
        "scales": {p.name: p.data["Histograms"][h.name]["Scale"][0] for p in phases},
        "instrument": {k: v[1] for k, v in h.InstrumentParameters.items()
                       if k in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"]},
        "sample": {k: h.SampleParameters[k][0] for k in
                   ["Shift", "SurfRoughA", "SurfRoughB"]},
        "profiles": {p.name: {
            "size": p.data["Histograms"][h.name]["Size"],
            "mustrain": p.data["Histograms"][h.name]["Mustrain"],
            "po": p.data["Histograms"][h.name]["Pref.Ori."],
        } for p in phases},
        "atoms": {p.name: [{"label": a.label, "element": a.element,
                             "xyz": list(a.coordinates), "uiso": a.uiso,
                             "flags": a.refinement_flags}
                            for a in p.atoms()] for p in phases},
    }


def run(project, outdir, stage, log, cycles=6):
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    h = project.histogram(0)
    yc = np.asarray(h.data["data"][1][3], float)
    if not np.all(np.isfinite(yc)):
        raise RuntimeError(f"nonfinite profile after {stage}")
    record = state(project, stage)
    log.append(record)
    project.save(str(outdir / f"{stage}.gpx"))
    print(json.dumps({"stage": stage, "wR": h.residuals.get("wR"),
                      "R": h.residuals.get("R"),
                      "fractions": record["mass_fractions"]}), flush=True)


def set_limits(project):
    for var, lo, hi in [
        (":*:Zero", -0.25, 0.25), (":*:Shift", -800.0, 800.0),
        (":*:Polariz.", 0.5, 1.0), (":*:U", 0.0, 40.0),
        (":*:W", 2.0, 40.0), (":*:X", 0.1, 12.0),
        (":*:SH/L", 0.005, 0.10), ("*::AUiso:*", 0.001, 0.03),
    ]:
        project.set_Controls("parmMin", lo, var)
        project.set_Controls("parmMax", hi, var)
    # GSAS-II does not retain a histogram wildcard when both phase and
    # histogram fields are wildcards, so set HAP bounds explicitly.
    for pidx in range(3):
        for name, lo, hi in [("Size;i", 0.04, 1.5),
                             ("Mustrain;i", 0.0, 8000.0)]:
            var = f"{pidx}:0:{name}"
            project.set_Controls("parmMin", lo, var)
            project.set_Controls("parmMax", hi, var)


def atoms_by_element(phase, element):
    return {a.label: "X" for a in phase.atoms() if a.element == element}


def main():
    if len(sys.argv) != 2:
        raise SystemExit("usage: refine_mix_deep.py WO3_COD_ID")
    code = sys.argv[1]
    source = ROOT / "screens" / code / "screen.gpx"
    outdir = ROOT / "deep" / code
    outdir.mkdir(parents=True, exist_ok=True)
    working = outdir / "working.gpx"
    shutil.copy2(source, working)

    G2.SetPrintLevel("error")
    project = G2.G2Project(str(working))
    h = project.histogram(0)
    phases = project.phases()
    znwo4, wo3, zno = phases

    # Preserve the well-determined calibration from the serial screen.
    h.InstrumentParameters["Zero"][2] = False
    h.SampleParameters["Shift"][1] = False
    h.SampleParameters["Scale"][1] = False
    h.Background[0][1] = True
    for p in phases:
        p.data["Histograms"][h.name]["Scale"][1] = True
        scalarize_adps(p, 0.01)

    # Reset the profile decomposition to a physical interior point. X is held
    # fixed because it is exactly collinear with a common size contribution;
    # phase-specific sizes carry that otherwise unidentifiable broadening.
    inst = h.InstrumentParameters
    for key, value in {"U": 15.0, "W": 15.0, "X": 2.0,
                       "SH/L": 0.03, "Polariz.": 0.8}.items():
        inst[key][1] = value
        inst[key][2] = key in ["U", "W", "SH/L"]
    for p in phases:
        p.setSampleProfile(h, "size", "isotropic", 0.30, LGmix=1.0)
        p.setSampleProfile(h, "microstrain", "isotropic", 1000.0, LGmix=1.0)
        p.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 0.30, "refine": True,
                     "LGmix": {"value": 1.0, "refine": False}},
            "Mustrain": {"type": "isotropic", "refine": True,
                         "LGmix": {"value": 1.0, "refine": False}},
        }, [h])
        p.set_refinements({"Cell": True, "LeBail": True})

    project.save()
    set_limits(project)
    log = []

    # Profile/cell calibration without imposing imperfect starting intensities.
    run(project, outdir, "01_lebail_profile", log, cycles=8)
    run(project, outdir, "02_lebail_replay", log, cycles=8)

    # Freeze nuisance quantities for structural adaptation.
    for key in ["U", "W", "X", "SH/L", "Polariz."]:
        inst[key][2] = False
    for p in phases:
        p.clear_refinements({"Cell": True})
        p.set_refinements({"LeBail": False})
        p.clear_HAP_refinements({"Size": True, "Mustrain": True}, [h])
    run(project, outdir, "03_structure_scales", log, cycles=8)

    # Dominant transferred framework: heavy coordinates first, then oxygen.
    znwo4.set_refinements({"Atoms": {
        **atoms_by_element(znwo4, "Zn"), **atoms_by_element(znwo4, "W")}})
    run(project, outdir, "04_znwo4_heavy", log, cycles=8)
    znwo4.set_refinements({"Atoms": atoms_by_element(znwo4, "O")})
    run(project, outdir, "05_znwo4_oxygen", log, cycles=8)

    # Minor phases are adapted independently at comparable depth.
    wo3.set_refinements({"Atoms": atoms_by_element(wo3, "W")})
    run(project, outdir, "06_wo3_tungsten", log, cycles=8)
    wo3.set_refinements({"Atoms": atoms_by_element(wo3, "O")})
    run(project, outdir, "07_wo3_oxygen", log, cycles=8)
    zno.set_refinements({"Atoms": {a.label: "X" for a in zno.atoms()}})
    run(project, outdir, "08_zno_coordinate", log, cycles=8)

    # One physically shared isotropic displacement parameter per phase.
    project.get_Constraints("Phase").clear()
    project.save()
    for pidx, p in enumerate(phases):
        for a in p.atoms():
            a.refinement_flags = a.refinement_flags.replace("U", "") + "U"
        variables = [f"{pidx}::AUiso:{i}" for i, _ in enumerate(p.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=(pidx == 0), override=True)
    run(project, outdir, "09_shared_uiso", log, cycles=8)

    # Final angular intensity and lattice replay after coordinates are stable.
    inst["Polariz."][2] = True
    for p in phases:
        p.set_refinements({"Cell": True})
    run(project, outdir, "10_cell_polarization", log, cycles=8)
    project.save(str(outdir / "deep_final.gpx"))
    (outdir / "stages.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
