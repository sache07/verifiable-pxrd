#!/usr/bin/env python3
"""Compare allowed March-Dollase axes at equal refinement depth."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2

from refine_trials import bound, reset


AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]
STARTS = (0.8, 1.2)


if len(sys.argv) != 4:
    raise SystemExit("usage: trial_po_grid_phases.py INPUT.gpx PHASE_INDEX OUTDIR")
source = Path(sys.argv[1]).resolve()
pidx = int(sys.argv[2])
outdir = Path(sys.argv[3]).resolve()
outdir.mkdir(parents=True, exist_ok=True)
G2.SetPrintLevel("error")
results = []
for axis in AXES:
    for start in STARTS:
        tag = "".join(str(v) for v in axis) + "_" + str(start).replace(".", "")
        output = outdir / f"po_p{pidx}_{tag}.gpx"
        project = G2.G2Project(str(source), filename=str(output))
        h = reset(project)
        h.Background[0][1] = True
        for phase in project.phases():
            phase.data["Histograms"][h.name]["Scale"][1] = True
        po = project.phase(pidx).data["Histograms"][h.name]["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", start, True, list(axis)
        bound(project, f"{pidx}:0:MD", 0.7, 1.4)
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        row = {"axis": axis, "start": start, "ratio": po[1],
               "Rwp": h.residuals.get("wR"), "Rp": h.residuals.get("R"),
               "converged": rvals.get("converged"),
               "message": rvals.get("msg", ""), "project": str(output)}
        results.append(row)
        print(json.dumps(row), flush=True)
(outdir / "results.json").write_text(json.dumps(results, indent=2) + "\n")
