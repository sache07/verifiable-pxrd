#!/usr/bin/env python3
"""Comparable ZnWO4 coordinate-start trials with the accepted [111] texture."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


STARTS = {
    "current": None,
    "old_cowo4": {
        "Zn1": (0.5, 0.6530, 0.25), "W1": (0.0, 0.1800, 0.25),
        "O1": (0.2200, 0.1100, 0.9600), "O2": (0.2600, 0.3800, 0.3900),
    },
    "mnreo4": {
        "Zn1": (0.5, 0.68110, 0.25), "W1": (0.0, 0.16966, 0.25),
        "O1": (0.2078, 0.1056, 0.9375), "O2": (0.2595, 0.3712, 0.3881),
    },
    "como4": {
        "Zn1": (0.5, 0.67338, 0.25), "W1": (0.0, 0.18500, 0.25),
        "O1": (0.2179, -0.1072, 0.0646), "O2": (0.2551, 0.3772, 0.1021),
    },
}


def prep(project):
    h = project.histogram(0)
    project.get_Constraints("Phase").clear()
    for val in h.InstrumentParameters.values():
        if isinstance(val, list) and len(val) > 2:
            val[2] = False
    for key in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]:
        if isinstance(h.SampleParameters.get(key), list):
            h.SampleParameters[key][1] = False
    h.Background[0][1] = True
    for p in project.phases():
        p.clear_refinements({"Cell": True})
        p.set_refinements({"LeBail": False})
        for atom in p.atoms():
            atom.refinement_flags = " "
        hap = p.data["Histograms"][h.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
    po = project.phase(0).data["Histograms"][h.name]["Pref.Ori."]
    po[0], po[2], po[3] = "MD", True, [1, 1, 1]
    if not 0.7 <= po[1] <= 1.4:
        po[1] = 0.8


def refine(project, cycles):
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: trial_znwo4_starts.py INPUT.gpx OUTDIR")
    source, outdir = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    results = []
    for name, coords in STARTS.items():
        output = outdir / f"{name}.gpx"
        p = G2.G2Project(str(source), filename=str(output))
        prep(p)
        phase = p.phase(0)
        if coords is not None:
            for atom in phase.atoms():
                atom.coordinates = coords[atom.label]
                atom.uiso = 0.01
        p.save()
        p.set_Controls("parmMin", 0.7, "0:0:MD")
        p.set_Controls("parmMax", 1.4, "0:0:MD")
        refine(p, 6)
        for a in phase.atoms():
            if a.element in ["Zn", "W"]:
                a.refinement_flags = "X"
        refine(p, 8)
        for a in phase.atoms():
            if a.element == "O":
                a.refinement_flags = "X"
        refine(p, 8)
        h = p.histogram(0)
        row = {"start": name, "wR": h.residuals.get("wR"),
               "R": h.residuals.get("R"),
               "po_ratio": phase.data["Histograms"][h.name]["Pref.Ori."][1],
               "fractions": {k: list(v) for k, v in h.ComputeMassFracs().items()},
               "coordinates": {a.label: list(a.coordinates) for a in phase.atoms()}}
        results.append(row)
        print(json.dumps(row), flush=True)
        p.save()
    (outdir / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
