#!/usr/bin/env python3
"""Comparable staged three-phase screening refinements for WO3 references."""

from pathlib import Path
import json
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
LIB = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c01/cif")


def cod_path(code):
    return LIB / code[0] / code[1:3] / code[3:5] / f"{code}.cif"


def set_flag(pair, flag):
    pair[1] = bool(flag)


def summary(project, stage, output):
    h = project.histogram(0)
    phases = project.phases()
    result = {
        "stage": stage,
        "residuals": h.residuals,
        "cells": {p.name: p.get_cell() for p in phases},
        "scales": {p.name: p.data["Histograms"][h.name]["Scale"][0] for p in phases},
        "instrument": {k: v[1] for k, v in h.InstrumentParameters.items()
                       if k in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"]},
        "sample": {k: h.SampleParameters[k][0] for k in
                   ["Shift", "SurfRoughA", "SurfRoughB"]},
    }
    output.append(result)
    print(json.dumps(result))


def run_refine(project, stage, output):
    project.save()
    project.refine(makeBack=False)
    h = project.histogram(0)
    if not np.all(np.isfinite(np.asarray(h.data["data"][1][3], float))):
        raise RuntimeError(f"nonfinite calculated profile at {stage}")
    summary(project, stage, output)


def set_limits(project):
    limits = {
        ":*:Zero": (-0.25, 0.25),
        ":*:Shift": (-800.0, 800.0),
        ":*:Polariz.": (0.5, 1.0),
        ":*:U": (0.0, 40.0),
        ":*:W": (2.0, 40.0),
        ":*:X": (0.1, 12.0),
        ":*:SH/L": (0.005, 0.10),
        "*:*:Size;i": (0.04, 10.0),
        "*:*:Mustrain;i": (0.0, 10000.0),
    }
    for var, (lo, hi) in limits.items():
        project.set_Controls("parmMin", lo, var)
        project.set_Controls("parmMax", hi, var)


def main():
    if len(sys.argv) != 2:
        raise SystemExit("usage: refine_mix_screen.py WO3_COD_ID")
    wo3_id = sys.argv[1]
    outdir = ROOT / "screens" / wo3_id
    outdir.mkdir(parents=True, exist_ok=True)
    gpx_path = outdir / "screen.gpx"
    if gpx_path.exists():
        gpx_path.unlink()

    G2.SetPrintLevel("error")
    project = G2.G2Project(newgpx=str(gpx_path))
    h = project.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "instrument.instprm"), fmthint="xye"
    )
    paths = [ROOT / "candidates" / "znwo4_wolframite_start.cif",
             cod_path(wo3_id), cod_path("9004178")]
    names = ["ZnWO4_wolframite", f"WO3_{wo3_id}", "ZnO_wurtzite_9004178"]
    phases = [project.add_phase(str(path), phasename=name, histograms=[h], fmthint="CIF")
              for path, name in zip(paths, names)]

    h.SampleParameters["Type"] = "Bragg-Brentano"
    h.SampleParameters["Gonio. radius"] = 200.0
    h.SampleParameters["Scale"][1] = False
    h.SampleParameters["Shift"] = [-500.0, False]
    h.SampleParameters["Transparency"] = [0.0, False]
    h.SampleParameters["SurfRoughA"] = [0.0, False]
    h.SampleParameters["SurfRoughB"] = [0.0, False]
    inst = h.InstrumentParameters
    for key, value in {"Zero": 0.0, "Polariz.": 0.8, "U": 20.0,
                       "V": 0.0, "W": 20.0, "X": 2.0, "Y": 0.0,
                       "SH/L": 0.03}.items():
        inst[key][1] = value
        inst[key][2] = False

    h.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {"type": "chebyschev-1", "no. coeffs": 12,
                       "coeffs": [900.0] + [0.0] * 11, "refine": True},
    })
    for p, scale in zip(phases, [80.0, 5.0, 20.0]):
        hap = p.data["Histograms"][h.name]
        hap["Scale"] = [scale, True]
        p.setSampleProfile(h, "size", "isotropic", 1.0, LGmix=1.0)
        p.setSampleProfile(h, "microstrain", "isotropic", 0.0, LGmix=1.0)
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]

    project.set_Controls("cycles", 4)
    project.save()
    set_limits(project)
    log = []

    # All candidates receive the same staged relaxation depth.
    run_refine(project, "01_scale_background", log)
    for p in phases:
        p.set_refinements({"Cell": True})
    run_refine(project, "02_cells", log)
    for p in phases:
        p.clear_refinements({"Cell": True})

    # Resolve calibration terms serially so their near-collinearity cannot
    # drive the lattice outside a physical local basin.
    h.InstrumentParameters["Zero"][2] = True
    run_refine(project, "03_zero", log)
    h.InstrumentParameters["Zero"][2] = False
    h.SampleParameters["Shift"][1] = True
    run_refine(project, "04_shift", log)
    h.SampleParameters["Shift"][1] = False
    for p in phases:
        p.set_refinements({"Cell": True})
    run_refine(project, "05_cells_replay", log)

    # Instrumental profile only for screening; phase-specific broadening is
    # deliberately deferred until after the WO3 topology is selected.
    for key in ["U", "W", "X", "SH/L", "Polariz."]:
        h.InstrumentParameters[key][2] = True
    run_refine(project, "06_profile", log)
    project.save()
    (outdir / "stages.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
