#!/usr/bin/env python3
"""Build and stage a one-phase ZnWO4 GSAS-II refinement."""

from pathlib import Path
import json
import math
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
GPX = ROOT / "single_znwo4.gpx"


def finite_state(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    values = []
    values.extend(phase.data["General"]["Cell"][1:8])
    values.extend(hist.data["data"][1][3])
    if not np.all(np.isfinite(np.asarray(values, dtype=float))):
        raise RuntimeError(f"nonfinite state after {label}")
    print(label, json.dumps({
        "residuals": hist.residuals,
        "cell": phase.get_cell(),
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items()
                       if isinstance(v, list) and len(v) > 1},
        "sample": hist.SampleParameters,
        "hap_scale": phase.data["Histograms"][hist.name]["Scale"],
        "size": phase.data["Histograms"][hist.name]["Size"],
        "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
        "po": phase.data["Histograms"][hist.name]["Pref.Ori."],
        "atoms": phase.data["Atoms"],
    }, default=str))


def refine(project, label):
    project.save()
    project.refine(makeBack=False)
    finite_state(project, label)


def main():
    G2.SetPrintLevel("warn")
    if GPX.exists():
        GPX.unlink()
    project = G2.G2Project(newgpx=str(GPX))
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "instrument.instprm"), fmthint="xye"
    )
    phase = project.add_phase(
        str(ROOT / "candidates" / "znwo4_wolframite_start.cif"),
        phasename="ZnWO4_wolframite", histograms=[hist], fmthint="CIF",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"][1] = False
    hist.SampleParameters["Shift"] = [-500.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {"type": "chebyschev-1", "no. coeffs": 10,
                       "coeffs": [900.0] + [0.0] * 9, "refine": True},
    })
    project.set_Controls("cycles", 10)

    # Stage 1: intensity scale and smooth background with a physically informed
    # displacement start. Peak positions are already close enough for this.
    phase.set_HAP_refinements({"Scale": True}, [hist])
    refine(project, "01_scale_background")

    # Stage 2: lattice and the two distinct angular corrections. Shift captures
    # the cos(theta) specimen-height term; Zero captures a constant offset.
    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"],
                          "Instrument Parameters": ["Zero"]})
    refine(project, "02_cell_shift_zero")

    # Stage 3: the calibrated instrumental family used by the measurement
    # generator. V and Y remain zero by construction.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    refine(project, "03_instrument_profile")

    # Stage 4: phase-specific isotropic size and microstrain. Starting values
    # are central in the allowed laboratory range.
    phase.setSampleProfile(hist, "size", "isotropic", 0.3, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=1.0)
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": 0.3, "refine": True,
                 "LGmix": {"value": 1.0, "refine": False}},
        "Mustrain": {"type": "isotropic", "refine": True,
                     "LGmix": {"value": 1.0, "refine": False}},
    }, [hist])
    refine(project, "04_size_strain")

    # Stage 5: symmetry-allowed coordinates. Heavy sites are relaxed first,
    # followed by oxygen, as their scattering leverage differs strongly.
    phase.set_refinements({"Atoms": {"Zn1": "X", "W1": "X"}})
    refine(project, "05_heavy_coordinates")
    phase.set_refinements({"Atoms": {"O1": "X", "O2": "X"}})
    refine(project, "06_oxygen_coordinates")

    # Re-equilibrate profile and lattice after coordinate changes.
    refine(project, "07_full_replay")
    project.save()


if __name__ == "__main__":
    main()
