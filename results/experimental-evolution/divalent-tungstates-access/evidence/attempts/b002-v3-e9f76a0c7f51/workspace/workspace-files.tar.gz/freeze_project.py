#!/usr/bin/env python3
"""Create the immutable, no-active-flags final GSAS-II project."""

import sys

from GSASII import GSASIIscriptable as G2

from refine_trials import reset


if len(sys.argv) != 3:
    raise SystemExit("usage: freeze_project.py INPUT.gpx OUTPUT.gpx")

G2.SetPrintLevel("error")
project = G2.G2Project(sys.argv[1], filename=sys.argv[2])
reset(project)
project.save()
print(sys.argv[2])
