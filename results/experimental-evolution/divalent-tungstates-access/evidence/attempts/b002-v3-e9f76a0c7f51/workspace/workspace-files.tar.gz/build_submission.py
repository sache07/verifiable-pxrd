#!/usr/bin/env python3
"""Build submission files from the frozen GPX and its independent replay."""

from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / "validation" / "final_replay"
PROJECT = ROOT / "final.gpx"

G2.SetPrintLevel("error")
project = G2.G2Project(str(PROJECT))
hist = project.histogram(0)
fractions = {name: float(value[0])
             for name, value in hist.ComputeMassFracs().items()}

records = [
    ("ZnWO4_wolframite", "ZnWO4 (wolframite)", "ZnWO4", "P 2/c",
     "phase_1_ZnWO4.cif"),
    ("WO3_monoclinic", "WO3 (monoclinic)", "WO3", "P 21/n",
     "phase_2_WO3.cif"),
    ("ZnO_wurtzite_trial", "ZnO (wurtzite)", "ZnO", "P 63 m c",
     "phase_3_ZnO.cif"),
]
for index, (_, _, _, _, destination) in enumerate(records):
    shutil.copyfile(REPLAY / f"phase_{index}.cif", ROOT / destination)

archive = np.load(REPLAY / "prediction.npz")
x = np.asarray(archive["x"], float)
observed = np.asarray(archive["observed"], float)
calculated = np.asarray(archive["predicted"], float)
difference = observed - calculated
profile = np.column_stack((x, observed, calculated, difference))
np.savetxt(
    ROOT / "fit.csv", profile, delimiter=",",
    header="two_theta,observed,calculated,difference", comments="",
    fmt="%.10f",
)

weight = 1.0 / np.maximum(observed, 1.0)
rwp = 100.0 * np.sqrt(
    np.sum(weight * difference**2) / np.sum(weight * observed**2)
)
covariance = project.data.get("Covariance", {}).get("data", {})
rvals = covariance.get("Rvals", {})
phases = []
for internal, name, formula, space_group, cif in records:
    phases.append({
        "name": name,
        "formula": formula,
        "space_group": space_group,
        "cif_path": cif,
        "weight_fraction": fractions[internal],
    })

result = {
    "phases": phases,
    "fraction_basis": "normalized over the modeled crystalline phases",
    "fit_statistics": {
        "rwp_percent": float(rwp),
        "rp_percent": float(hist.residuals["R"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "wrmin_percent": float(hist.residuals["wRmin"]),
        "n_observations": int(rvals["Nobs"]),
    },
    "calibration": {
        "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
        "specimen_displacement_um": float(hist.SampleParameters["Shift"][0]),
    },
    "refinement_histogram": hist.name,
    "profile_file": "fit.csv",
    "project_file": "final.gpx",
}
(ROOT / "result.json").write_text(
    json.dumps(result, indent=2, allow_nan=False) + "\n"
)
print(json.dumps(result, indent=2))
