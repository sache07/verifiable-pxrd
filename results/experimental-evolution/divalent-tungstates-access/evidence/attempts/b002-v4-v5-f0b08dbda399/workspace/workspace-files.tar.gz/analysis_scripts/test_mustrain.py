import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("axis", nargs=3, type=int)
    args = parser.parse_args()

    G2.SetPrintLevel("error")
    project = G2.G2Project(
        gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve())
    )
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    phase = project.phase(args.phase)
    phase.set_HAP_refinements(
        {
            "Mustrain": {
                "type": "uniaxial",
                "direction": args.axis,
                "refine": True,
            }
        }
    )
    project.save()
    for name in ["Mustrain;i", "Mustrain;a"]:
        variable = f"{phase.id}:{hist.id}:{name}"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 8000.0, variable=variable)
    project.set_Controls("cycles", 40)
    project.do_refinements([{}])
    print("Rwp", hist.get_wR())
    print("Rvals", project.data["Covariance"]["data"]["Rvals"])
    for item in project.phases():
        hap = item.data["Histograms"][hist.name]
        print(item.name, "Mustrain", hap["Mustrain"], "Size", hap["Size"])
    project.save()


if __name__ == "__main__":
    main()
