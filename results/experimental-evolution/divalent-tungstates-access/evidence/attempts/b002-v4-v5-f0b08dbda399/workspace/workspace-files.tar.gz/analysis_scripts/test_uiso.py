import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("uiso", type=float)
    args = parser.parse_args()

    G2.SetPrintLevel("error")
    project = G2.G2Project(
        gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve())
    )
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    phase = project.phase(args.phase)
    phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
    for atom in phase.atoms():
        atom.uiso = args.uiso
    project.set_Controls("cycles", 40)
    project.do_refinements([{}])
    hist = project.histogram(0)
    print("Rwp", hist.get_wR())
    print("Rvals", project.data["Covariance"]["data"]["Rvals"])
    print("Uiso", [(atom.label, atom.uiso) for atom in phase.atoms()])
    project.save()


if __name__ == "__main__":
    main()
