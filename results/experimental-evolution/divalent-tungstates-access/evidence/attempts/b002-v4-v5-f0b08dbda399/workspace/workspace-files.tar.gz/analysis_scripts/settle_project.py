import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--clear-atoms", action="store_true")
    parser.add_argument(
        "--fix-surface-a",
        action="store_true",
        help="Retain the current SurfRoughA value but remove it from refinement.",
    )
    args = parser.parse_args()

    G2.SetPrintLevel("error")
    project = G2.G2Project(
        gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve())
    )
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    if args.fix_surface_a:
        project.histogram(0).SampleParameters["SurfRoughA"][1] = False
    if args.clear_atoms:
        for phase in project.phases():
            phase.clear_refinements(
                {"Atoms": [atom.label for atom in phase.atoms()]}
            )
    project.set_Controls("cycles", 40)
    project.do_refinements([{}])
    hist = project.histogram(0)
    print("Rwp", hist.get_wR())
    print("residuals", hist.residuals)
    print("Rvals", project.data["Covariance"]["data"]["Rvals"])
    for phase in project.phases():
        print("phase", phase.name, phase.get_cell())
        print("HAP", phase.data["Histograms"][hist.name])
        for atom in phase.atoms():
            print(atom.label, atom.coordinates, atom.refinement_flags)
    project.save()


if __name__ == "__main__":
    main()
