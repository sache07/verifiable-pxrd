import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
MODEL_PATHS = {
    "ZnWO4": ROOT / "models" / "ZnWO4_start.cif",
    "WO3": ROOT / "models" / "WO3_start.cif",
    "WO3_triclinic": ROOT / "models" / "WO3_triclinic_start.cif",
    "WO3_modern_monoclinic": ROOT / "models" / "WO3_modern_monoclinic_start.cif",
    "WO3_small_monoclinic": ROOT / "models" / "WO3_small_monoclinic_start.cif",
    "WO3_p21m": ROOT / "models" / "WO3_p21m_start.cif",
    "WO3_tetragonal": ROOT / "models" / "WO3_tetragonal_start.cif",
    "ZnO": ROOT / "models" / "ZnO_start.cif",
}
START_SCALES = {
    "ZnWO4": 1.2,
    "WO3": 0.08,
    "WO3_triclinic": 0.08,
    "WO3_modern_monoclinic": 0.08,
    "WO3_small_monoclinic": 0.08,
    "WO3_p21m": 0.08,
    "WO3_tetragonal": 0.08,
    "ZnO": 0.25,
}


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def summarize(project, label):
    hist = project.histogram(0)
    masses = np.array(
        [
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][hist.name]["Scale"][0]
            for phase in project.phases()
        ],
        float,
    )
    fractions = masses / masses.sum() if masses.sum() > 0 else np.full_like(masses, np.nan)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": label,
        "residuals": plain(hist.residuals),
        "Rvals": plain(rvals),
        "instrument": {
            key: plain(hist.InstrumentParameters[key])
            for key in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]
        },
        "sample": {
            key: plain(hist.SampleParameters[key])
            for key in ["Shift", "SurfRoughA", "SurfRoughB"]
        },
        "phases": [
            {
                "name": phase.name,
                "scale": plain(phase.data["Histograms"][hist.name]["Scale"]),
                "weight_fraction": float(fraction),
                "cell": plain(phase.get_cell()),
                "size": plain(phase.data["Histograms"][hist.name]["Size"]),
                "mustrain": plain(phase.data["Histograms"][hist.name]["Mustrain"]),
            }
            for phase, fraction in zip(project.phases(), fractions)
        ],
    }


def checkpoint(project, output, label, records):
    project.save()
    checkpoint_path = output.with_name(f"{output.stem}_{label}.gpx")
    shutil.copy2(output, checkpoint_path)
    records.append(summarize(project, label))
    print(json.dumps(records[-1], indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phases", nargs="+")
    args = parser.parse_args()
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    unknown = sorted(set(args.phases) - set(MODEL_PATHS))
    if unknown:
        raise ValueError(f"Unknown model(s): {unknown}")

    G2.SetPrintLevel("error")
    project = G2.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
        fmthint="xye",
    )
    phases = []
    for name in args.phases:
        phase = project.add_phase(
            str(MODEL_PATHS[name]),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase.data["Histograms"][hist.name]["Scale"] = [START_SCALES[name], True]
        phases.append(phase)

    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [900.0, 300.0, 100.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": True,
            }
        }
    )
    project.set_Controls("cycles", 15)
    project.save()
    for phase in phases:
        project.set_Controls(
            "parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale"
        )

    records = []
    project.do_refinements([{}])
    checkpoint(project, output, "scales", records)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.set_Controls("parmMin", -0.5, variable=f":{hist.id}:Zero")
    project.set_Controls("parmMax", 0.5, variable=f":{hist.id}:Zero")
    project.set_Controls("cycles", 30)
    project.do_refinements([{}])
    checkpoint(project, output, "cells", records)

    for phase in phases:
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 0.15, "refine": True}}
        )
    project.set_Controls("cycles", 30)
    project.do_refinements([{}])
    checkpoint(project, output, "size", records)

    (output.with_suffix(".summary.json")).write_text(
        json.dumps(records, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
