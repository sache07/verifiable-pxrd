from pathlib import Path

import numpy as np
import pandas as pd
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parents[1]
COD = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_structure(cod_id: str, output: str, substitutions=None) -> None:
    structure = Structure.from_file(cod_path(cod_id))
    if substitutions:
        structure.replace_species(substitutions)
    CifWriter(structure, symprec=1e-4).write_file(ROOT / "models" / output)


def main() -> None:
    pattern = pd.read_csv(ROOT / "inputs" / "pattern.csv")
    x = pattern["two_theta_deg"].to_numpy(float)
    y = pattern["intensity"].to_numpy(float)
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(
        ROOT / "pattern.xye",
        np.column_stack([x, y, sigma]),
        fmt=["%.8f", "%.8f", "%.8f"],
        header="2theta intensity sigma",
    )

    # A deliberately middle-of-range starting profile. All uncertain profile
    # terms are refined later against the specimen scan.
    (ROOT / "instrument.instprm").write_text(
        "#GSAS-II Cu Kalpha Bragg-Brentano starting instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )

    # COD 7205001 is P2/c wolframite CoMoO4. Isovalent Co->Zn and Mo->W
    # substitution supplies the chemically supported ZnWO4 starting topology.
    write_structure(
        "7205001", "ZnWO4_start.cif", {"Co": "Zn", "Mo": "W"}
    )
    # Room-temperature gamma-WO3 and wurtzite ZnO precursor references.
    write_structure("1528915", "WO3_start.cif")
    write_structure("2106293", "WO3_triclinic_start.cif")
    write_structure("2311041", "WO3_modern_monoclinic_start.cif")
    write_structure("1563541", "WO3_small_monoclinic_start.cif")
    write_structure("1010618", "WO3_p21m_start.cif")
    write_structure("1521532", "WO3_tetragonal_start.cif")
    write_structure("9004178", "ZnO_start.cif")


if __name__ == "__main__":
    main()
