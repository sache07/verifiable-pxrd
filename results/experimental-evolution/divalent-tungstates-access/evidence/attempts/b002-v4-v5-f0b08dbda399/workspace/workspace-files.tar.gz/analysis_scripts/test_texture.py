import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("axis", nargs=3, type=int)
    args = parser.parse_args()

    G2.SetPrintLevel("error")
    project = G2.G2Project(
        gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve())
    )
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = args.axis
    project.save()
    project.set_Controls(
        "parmMin", 0.5, variable=f"{phase.id}:{hist.id}:MD"
    )
    project.set_Controls(
        "parmMax", 2.0, variable=f"{phase.id}:{hist.id}:MD"
    )
    project.set_Controls("cycles", 40)
    project.do_refinements([{}])
    print("Rwp", hist.get_wR())
    print("residuals", hist.residuals)
    print("Rvals", project.data["Covariance"]["data"]["Rvals"])
    for item in project.phases():
        item_hap = item.data["Histograms"][hist.name]
        print(item.name, "Pref.Ori.", item_hap["Pref.Ori."])
    project.save()


if __name__ == "__main__":
    main()
