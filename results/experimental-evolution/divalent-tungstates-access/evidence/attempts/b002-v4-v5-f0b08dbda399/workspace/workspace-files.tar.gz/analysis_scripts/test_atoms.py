import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("labels", nargs="+")
    parser.add_argument("--bound", type=float, default=0.01)
    args = parser.parse_args()

    G2.SetPrintLevel("error")
    project = G2.G2Project(
        gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve())
    )
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    atoms = list(phase.atoms())
    phase.clear_refinements({"Atoms": [atom.label for atom in atoms]})
    phase.set_refinements({"Atoms": {label: "X" for label in args.labels}})
    project.save()
    label_to_index = {atom.label: index for index, atom in enumerate(atoms)}
    for label in args.labels:
        index = label_to_index[label]
        for coordinate, start in zip("xyz", atoms[index].coordinates):
            variable = f"{phase.id}::dA{coordinate}:{index}"
            project.set_Controls("parmMin", start - args.bound, variable=variable)
            project.set_Controls("parmMax", start + args.bound, variable=variable)
    project.set_Controls("cycles", 40)
    project.do_refinements([{}])
    print("Rwp", hist.get_wR())
    print("Rvals", project.data["Covariance"]["data"]["Rvals"])
    for atom in phase.atoms():
        print(atom.label, atom.coordinates, atom.refinement_flags)
    project.save()


if __name__ == "__main__":
    main()
