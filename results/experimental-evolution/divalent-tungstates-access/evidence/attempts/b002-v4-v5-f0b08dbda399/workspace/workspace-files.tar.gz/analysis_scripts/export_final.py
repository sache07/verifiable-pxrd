"""Export the converged GSAS-II model and machine-readable deliverables."""

from __future__ import annotations

import json
import re
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "trials" / "final_physical_settled.gpx"
FINAL_GPX = ROOT / "final.gpx"

PHASE_INFO = {
    "ZnWO4": {
        "name": "ZnWO4",
        "formula": "ZnWO4",
        "cif": "phase_ZnWO4.cif",
    },
    "WO3_modern_monoclinic": {
        "name": "WO3",
        "formula": "WO3",
        "cif": "phase_WO3.cif",
    },
    "ZnO_test": {
        "name": "ZnO",
        "formula": "ZnO",
        "cif": "phase_ZnO.cif",
    },
}


def plain(value):
    if isinstance(value, dict):
        return {str(key): plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(item) for item in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def phase_fraction_esds(project, histogram, phases, masses, fractions):
    """Propagate the refined phase-scale covariance into normalized fractions."""
    covdata = project.data["Covariance"]["data"]
    vary = [str(item) for item in covdata["varyList"]]
    covariance = np.asarray(covdata["covMatrix"], dtype=float)
    total = masses.sum()
    esds = []
    for i, phase_i in enumerate(phases):
        gradient = np.zeros(len(vary), dtype=float)
        for j, phase_j in enumerate(phases):
            variable = f"{phase_j.id}:{histogram.id}:Scale"
            if variable not in vary:
                continue
            scale_mass = float(phase_j.data["General"]["Mass"])
            derivative = (
                (float(phase_i.data["General"]["Mass"]) if i == j else 0.0)
                / total
                - masses[i] * scale_mass / total**2
            )
            gradient[vary.index(variable)] = derivative
        variance = float(gradient @ covariance @ gradient)
        esds.append(float(np.sqrt(max(variance, 0.0))))
    return np.asarray(esds), fractions


def main():
    if not SOURCE.exists():
        raise FileNotFoundError(SOURCE)

    # Keep the submitted project byte-identical to the converged checkpoint.
    shutil.copy2(SOURCE, FINAL_GPX)
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(FINAL_GPX))
    histogram = project.histogram(0)
    phases = project.phases()

    if [phase.name for phase in phases] != list(PHASE_INFO):
        raise RuntimeError(f"Unexpected phase inventory: {[p.name for p in phases]}")

    # Export the exact structural parameters stored in final.gpx.
    for phase in phases:
        info = PHASE_INFO[phase.name]
        output = ROOT / info["cif"]
        phase.export_CIF(str(output))
        # Give the user-facing phase name in the CIF while preserving the GPX tree.
        contents = output.read_text()
        contents = re.sub(
            r"(?m)^_pd_phase_name\s+.*$",
            f"_pd_phase_name  {info['name']}",
            contents,
        )
        contents = contents.replace(
            f"# phase info for {phase.name} follows",
            f"# phase info for {info['name']} follows",
        )
        output.write_text(contents)

    arrays = [np.asarray(item, dtype=float) for item in histogram.data["data"][1]]
    two_theta, observed, weights, calculated, background, stored_difference = arrays
    difference = observed - calculated
    if not np.allclose(stored_difference, difference, rtol=0.0, atol=1e-8):
        raise RuntimeError("Stored GSAS-II difference profile is inconsistent")
    fit = np.column_stack((two_theta, observed, calculated, difference, background))
    np.savetxt(
        ROOT / "fit.csv",
        fit,
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
        fmt=["%.8f", "%.10g", "%.10g", "%.10g", "%.10g"],
    )

    scales = np.asarray(
        [phase.data["Histograms"][histogram.name]["Scale"][0] for phase in phases],
        dtype=float,
    )
    scale_masses = np.asarray(
        [phase.data["General"]["Mass"] for phase in phases], dtype=float
    )
    weighted_masses = scales * scale_masses
    fractions = weighted_masses / weighted_masses.sum()
    fraction_esds, _ = phase_fraction_esds(
        project, histogram, phases, weighted_masses, fractions
    )

    residuals = histogram.residuals
    rvals = project.data["Covariance"]["data"]["Rvals"]
    phase_rows = []
    for phase, fraction, fraction_esd in zip(phases, fractions, fraction_esds):
        info = PHASE_INFO[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        phase_rows.append(
            {
                "name": info["name"],
                "formula": info["formula"],
                "cif_path": info["cif"],
                "cif": info["cif"],
                "weight_fraction": float(fraction),
                "weight_fraction_esd": float(fraction_esd),
                "weight_percent": float(100.0 * fraction),
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cell": plain(cell),
                "cell_esd": plain(cell_esd),
                "bragg_R_percent": float(
                    residuals[f"{phase.id}:{histogram.id}:Rf"]
                ),
            }
        )

    result = {
        "phases": phase_rows,
        "weight_fraction_normalization": "modeled crystalline phases; sum = 1",
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "R_background_percent": float(residuals["Rb"]),
            "weighted_R_background_percent": float(residuals["wRb"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_variables": int(rvals["Nvars"]),
        },
        "profile_path": "fit.csv",
        "gsas_project_path": "final.gpx",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    audit = {
        "fraction_sum": float(fractions.sum()),
        "minimum_calculated_intensity": float(calculated.min()),
        "minimum_background": float(background.min()),
        "maximum_final_shift_over_esd": float(rvals["Max shft/sig"]),
        "converged": bool(rvals["converged"]),
        "frozen_parameters": [
            str(item)
            for item in project.data["Controls"]["data"]
            .get("parmFrozen", {})
            .get("FrozenList", [])
        ],
        "point_count": int(two_theta.size),
        "weights_finite_positive": bool(np.all(np.isfinite(weights) & (weights > 0))),
    }
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
