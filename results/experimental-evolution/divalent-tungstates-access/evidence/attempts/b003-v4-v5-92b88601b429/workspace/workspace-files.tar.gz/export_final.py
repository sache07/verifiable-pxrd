#!/usr/bin/env python3
"""Export the final GSAS-II replay, CIFs, fit profile and machine result."""

from __future__ import annotations

import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "final-physical" / "checkpoint.gpx"
FINAL = ROOT / "final.gpx"


def main():
    G2.SetPrintLevel("warn")
    shutil.copy2(SOURCE, FINAL)
    project = G2.G2Project(str(FINAL))
    hist = project.histogram(0)
    project.set_Controls("cycles", 0)
    project.refine(printFile=str(ROOT / ".tmp" / "final-replay.lst"))
    project.save()

    phases = project.phases()
    phase_specs = [
        ("MnWO4", "P 2/c", "mnwo4_wolframite.cif"),
        ("Mn3WO6", "R -3", "mn3wo6_corundum_related.cif"),
        ("WO3", "P 21/c", "wo3_monoclinic.cif"),
    ]
    raw = []
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        raw.append(float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]))
    raw = np.asarray(raw, dtype=float)
    fractions = raw / raw.sum()

    phase_results = []
    for phase, (formula, space_group, filename), fraction in zip(
        phases, phase_specs, fractions
    ):
        path = ROOT / filename
        phase.export_CIF(str(path))
        phase_results.append(
            {
                "name": phase.name,
                "formula": formula,
                "space_group": space_group,
                "cif_path": filename,
                "weight_fraction": float(fraction),
            }
        )

    x, observed, weight, calculated, background, difference = hist.data["data"][1]
    # GSAS-II stores yobs-ycalc as the sixth profile row. Recompute explicitly
    # to ensure the submitted CSV is internally exact.
    difference = np.asarray(observed) - np.asarray(calculated)
    profile = np.column_stack([x, observed, calculated, difference])
    if profile.shape[0] != 8301 or not np.all(np.isfinite(profile)):
        raise RuntimeError(f"Unexpected final profile shape/content: {profile.shape}")
    np.savetxt(
        ROOT / "fit.csv",
        profile,
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )

    residuals = hist.residuals
    rwp = float(residuals["wR"])
    rexp = float(residuals["wRmin"])
    gof = rwp / rexp
    result = {
        "phases": phase_results,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": rexp,
            "GOF": gof,
            "chi_square": gof * gof,
            "RBragg_percent": float(residuals["Rb"]),
            "weighted_RBragg_percent": float(residuals["wRb"]),
            "n_profile_points": int(len(x)),
        },
        "project_path": "final.gpx",
        "fit_path": "fit.csv",
        "weight_fraction_basis": "normalized over modeled crystalline phases",
    }
    if not math.isclose(
        sum(p["weight_fraction"] for p in phase_results), 1.0, abs_tol=1e-12
    ):
        raise RuntimeError("Exported phase fractions do not sum to one")
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
