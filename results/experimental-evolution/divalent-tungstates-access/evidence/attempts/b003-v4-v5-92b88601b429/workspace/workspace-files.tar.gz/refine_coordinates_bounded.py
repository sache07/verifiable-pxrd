#!/usr/bin/env python3
"""Refine atomic positions with explicit physical displacement bounds.

The synthetic-reference mismatch is small. Unrestrained oxygen refinement can
fit profile effects by creating impossible contacts, so this script projects
each element's total displacement back to a chemically modest RMS after every
short least-squares block.
"""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def lattice_matrix(cell):
    a, b, c = cell["length_a"], cell["length_b"], cell["length_c"]
    alpha, beta, gamma = map(
        math.radians,
        (cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]),
    )
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * math.cos(gamma), b * math.sin(gamma), 0.0])
    cx = c * math.cos(beta)
    cy = c * (math.cos(alpha) - math.cos(beta) * math.cos(gamma)) / math.sin(gamma)
    cz = math.sqrt(max(c * c - cx * cx - cy * cy, 0.0))
    return np.array([va, vb, [cx, cy, cz]])


def project_displacements(phases, parents, heavy_cap, oxygen_cap):
    report = {}
    for pidx, phase in enumerate(phases):
        matrix = lattice_matrix(phase.get_cell())
        atoms = phase.atoms()
        by_element = {}
        for atom in atoms:
            by_element.setdefault(atom.element, []).append(atom)
        report[phase.name] = {}
        for element, selected in by_element.items():
            cap = oxygen_cap if element == "O" else heavy_cap
            deltas = []
            lengths = []
            for atom in selected:
                delta = np.asarray(atom.coordinates) - parents[pidx][atom.label]
                delta -= np.rint(delta)
                length = float(np.linalg.norm(delta @ matrix))
                if length > 2.5 * cap:
                    delta *= (2.5 * cap) / length
                    length = 2.5 * cap
                deltas.append(delta)
                lengths.append(length)
            rms_before = float(np.sqrt(np.mean(np.square(lengths))))
            factor = min(1.0, cap / max(rms_before, 1e-15))
            for atom, delta in zip(selected, deltas):
                atom.coordinates = (parents[pidx][atom.label] + factor * delta) % 1.0
            report[phase.name][element] = {
                "rms_before_A": rms_before,
                "rms_after_A": rms_before * factor,
                "cap_A": cap,
            }
    return report


def fractions(project, hist):
    raw = {
        phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
        * phase.data["General"]["Mass"]
        for phase in project.phases()
    }
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def calculate(project, outdir, label):
    project.set_Controls("cycles", 0)
    project.refine(printFile=str(outdir / f"{label}-calc.lst"))


def checkpoint(project, hist, outdir, label, projection):
    project.save()
    target = outdir / f"{label}.gpx"
    shutil.copy2(project.filename, target)
    cov = project.data.get("Covariance", {}).get("data", {})
    payload = {
        "label": label,
        "residuals": hist.residuals,
        "fractions": fractions(project, hist),
        "projection": projection,
        "varyList": cov.get("varyList", []),
        "Rvals": cov.get("Rvals", {}),
        "atoms": {
            phase.name: [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": list(atom.coordinates),
                    "flags": atom.refinement_flags,
                    "ADP": atom.ADP,
                }
                for atom in phase.atoms()
            ]
            for phase in project.phases()
        },
    }
    (outdir / f"{label}.json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    print(label, "wR", hist.get_wR(), "fractions", fractions(project, hist), flush=True)


def refine_projected(
    project, hist, phases, parents, outdir, label, heavy_cap, oxygen_cap, blocks
):
    projection = None
    for block in range(blocks):
        project.set_Controls("cycles", 4)
        project.refine(printFile=str(outdir / f"{label}-fit-{block + 1}.lst"))
        projection = project_displacements(phases, parents, heavy_cap, oxygen_cap)
        calculate(project, outdir, f"{label}-{block + 1}")
        print(
            label,
            "block",
            block + 1,
            "wR",
            hist.get_wR(),
            "projection",
            projection,
            flush=True,
        )
    checkpoint(project, hist, outdir, label, projection)


def enable_positions(phase, elements):
    for atom in phase.atoms():
        if atom.element in elements:
            atom.refinement_flags = "X"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("outdir")
    parser.add_argument("--heavy-rms", type=float, default=0.04)
    parser.add_argument("--oxygen-rms", type=float, default=0.05)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    working = outdir / "working.gpx"
    project = G2.G2Project(args.input_gpx, newgpx=str(working))
    project.save()
    hist = project.histogram(0)
    phases = project.phases()
    parents = [
        {atom.label: np.asarray(atom.coordinates, dtype=float) for atom in phase.atoms()}
        for phase in phases
    ]

    hist.clear_refinements({"Instrument Parameters": ["U", "X", "SH/L"]})
    phases[1].clear_HAP_refinements({"Mustrain": True}, [hist])
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = ""

    for phase in phases:
        enable_positions(phase, {"Mn", "W"})
    refine_projected(
        project,
        hist,
        phases,
        parents,
        outdir,
        "stage6_heavy",
        args.heavy_rms,
        args.oxygen_rms,
        3,
    )

    enable_positions(phases[0], {"O"})
    refine_projected(
        project,
        hist,
        phases,
        parents,
        outdir,
        "stage7_mnwo4_oxygen",
        args.heavy_rms,
        args.oxygen_rms,
        3,
    )

    enable_positions(phases[1], {"O"})
    refine_projected(
        project,
        hist,
        phases,
        parents,
        outdir,
        "stage8_mn3wo6_oxygen",
        args.heavy_rms,
        args.oxygen_rms,
        3,
    )

    enable_positions(phases[2], {"O"})
    refine_projected(
        project,
        hist,
        phases,
        parents,
        outdir,
        "stage9_wo3_oxygen",
        args.heavy_rms,
        args.oxygen_rms,
        4,
    )

    # Freeze the accepted bounded structure and let only non-coordinate terms
    # settle. This makes the checkpoint replay the projected, physical model.
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = ""
    project.set_Controls("cycles", 6)
    project.refine(printFile=str(outdir / "stage10_settle.lst"))
    projection = project_displacements(
        phases, parents, args.heavy_rms, args.oxygen_rms
    )
    calculate(project, outdir, "stage10_settle")
    checkpoint(project, hist, outdir, "checkpoint_bounded", projection)


if __name__ == "__main__":
    main()
