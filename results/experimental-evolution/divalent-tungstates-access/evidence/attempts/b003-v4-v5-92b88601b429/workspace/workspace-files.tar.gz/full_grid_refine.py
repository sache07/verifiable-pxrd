#!/usr/bin/env python3
"""Settle the accepted physical model on the complete measured grid."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fractions(project, hist):
    raw = {
        p.name: p.data["Histograms"][hist.name]["Scale"][0]
        * p.data["General"]["Mass"]
        for p in project.phases()
    }
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("outdir")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(args.input_gpx, newgpx=str(outdir / "working.gpx"))
    project.save()
    controls = project.data["Controls"]["data"]
    controls.setdefault("parmFrozen", {})["FrozenList"] = []
    # Common Uiso values are already embedded in the model. Remove stale
    # equivalence objects so the final replay is warning-free.
    project.data["Constraints"]["data"]["Phase"] = []
    hist = project.histogram(0)
    phases = project.phases()
    x = hist.data["data"][1][0]
    hist.data["Limits"][1] = [float(x.min()), float(x.max())]

    # The calibration zero and sample height are nearly collinear. Clamp the
    # fixed zero to the physical bound and let cells/height resettle.
    hist.InstrumentParameters["Zero"][1] = -0.25
    hist.InstrumentParameters["Zero"][2] = False
    hist.clear_refinements(
        {"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz.", "Zero"]}
    )
    hist.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    for phase in phases:
        phase.clear_HAP_refinements(
            {"Pref.Ori.": True, "Size": True, "Mustrain": True}, [hist]
        )
        for atom in phase.atoms():
            atom.refinement_flags = ""

    history = []
    for rep in range(3):
        project.set_Controls("cycles", 8)
        project.refine(printFile=str(outdir / f"fit-{rep + 1}.lst"))
        history.append({"repeat": rep + 1, "wR": hist.get_wR()})
        print(history[-1], flush=True)
    project.set_Controls("cycles", 0)
    project.refine(printFile=str(outdir / "replay.lst"))
    project.save()
    shutil.copy2(project.filename, outdir / "checkpoint.gpx")
    payload = {
        "history": history,
        "limits": hist.data["Limits"],
        "residuals": hist.residuals,
        "fractions": fractions(project, hist),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
    }
    (outdir / "summary.json").write_text(
        json.dumps(payload, indent=2, default=str) + "\n"
    )
    print(json.dumps(payload, default=str), flush=True)


if __name__ == "__main__":
    main()
