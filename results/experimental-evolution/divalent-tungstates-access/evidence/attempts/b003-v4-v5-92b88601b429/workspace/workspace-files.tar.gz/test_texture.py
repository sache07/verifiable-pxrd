#!/usr/bin/env python3
"""Test one March-Dollase texture axis in an otherwise identical project."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fractions(project, hist):
    vals = {
        p.name: p.data["Histograms"][hist.name]["Scale"][0]
        * p.data["General"]["Mass"]
        for p in project.phases()
    }
    total = sum(vals.values())
    return {k: v / total for k, v in vals.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("outdir")
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--axis", required=True, help="comma-separated h,k,l")
    args = parser.parse_args()

    axis = [int(v) for v in args.axis.split(",")]
    if len(axis) != 3 or not any(axis):
        raise ValueError("axis must contain three integers and be nonzero")

    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(args.input_gpx, newgpx=str(outdir / "working.gpx"))
    project.save()
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.histogram(0)
    phases = project.phases()
    for phase in phases:
        phase.clear_HAP_refinements({"Pref.Ori.": True}, [hist])
    target = phases[args.phase]
    hap = target.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][3] = axis
    target.set_HAP_refinements({"Pref.Ori.": True}, [hist])
    project.set_Controls("parmMin", 0.5, variable=f"{args.phase}:0:MD")
    project.set_Controls("parmMax", 2.0, variable=f"{args.phase}:0:MD")

    for rep in range(3):
        project.set_Controls("cycles", 7)
        project.refine(printFile=str(outdir / f"fit-{rep + 1}.lst"))
        print(rep + 1, hist.get_wR(), hap["Pref.Ori."], flush=True)
    project.save()
    shutil.copy2(project.filename, outdir / "checkpoint.gpx")
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "phase_index": args.phase,
        "phase": target.name,
        "axis": axis,
        "preferred_orientation": hap["Pref.Ori."],
        "residuals": hist.residuals,
        "fractions": fractions(project, hist),
        "Rvals": cov.get("Rvals", {}),
    }
    (outdir / "summary.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps(result, default=str), flush=True)


if __name__ == "__main__":
    main()
