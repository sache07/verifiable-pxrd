#!/usr/bin/env python3
"""Refine one isotropic U per phase and the x-ray polarization factor."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fractions(project, hist):
    values = {
        p.name: p.data["Histograms"][hist.name]["Scale"][0]
        * p.data["General"]["Mass"]
        for p in project.phases()
    }
    total = sum(values.values())
    return {k: v / total for k, v in values.items()}


def checkpoint(project, hist, outdir, label):
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    cov = project.data.get("Covariance", {}).get("data", {})
    payload = {
        "label": label,
        "residuals": hist.residuals,
        "fractions": fractions(project, hist),
        "polarization": hist.InstrumentParameters["Polariz."],
        "uiso": {
            p.name: {a.label: a.ADP for a in p.atoms()} for p in project.phases()
        },
        "varyList": cov.get("varyList", []),
        "variables": [float(v) for v in cov.get("variables", [])],
        "sig": [float(v) for v in cov.get("sig", [])],
        "Rvals": cov.get("Rvals", {}),
    }
    (outdir / f"{label}.json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    print(label, hist.get_wR(), payload["fractions"], payload["uiso"], flush=True)


def refine(project, outdir, label, repeats=2):
    for rep in range(repeats):
        project.set_Controls("cycles", 8)
        project.refine(printFile=str(outdir / f"{label}-{rep + 1}.lst"))
        print(label, rep + 1, project.histogram(0).get_wR(), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("outdir")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(args.input_gpx, newgpx=str(outdir / "working.gpx"))
    project.save()
    hist = project.histogram(0)
    phases = project.phases()
    controls = project.data["Controls"]["data"]
    controls.setdefault("parmFrozen", {})["FrozenList"] = []

    for pidx, phase in enumerate(phases):
        variables = []
        for aidx, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "U"
            variables.append(f"{pidx}::AUiso:{aidx}")
            project.set_Controls("parmMin", 0.001, variable=variables[-1])
            project.set_Controls("parmMax", 0.03, variable=variables[-1])
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=(pidx == 0))

    refine(project, outdir, "stage11_common_uiso", repeats=3)
    checkpoint(project, hist, outdir, "stage11_common_uiso")

    project.set_Controls("parmMin", 0.6, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, outdir, "stage12_polarization", repeats=2)
    checkpoint(project, hist, outdir, "checkpoint_thermal_polarization")


if __name__ == "__main__":
    main()
