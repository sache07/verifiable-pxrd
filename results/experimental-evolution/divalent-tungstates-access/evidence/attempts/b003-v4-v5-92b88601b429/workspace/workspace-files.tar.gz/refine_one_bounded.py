#!/usr/bin/env python3
"""Test one physically bounded coordinate family from a saved checkpoint."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def lattice_matrix(cell):
    a, b, c = cell["length_a"], cell["length_b"], cell["length_c"]
    al, be, ga = map(
        math.radians,
        (cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]),
    )
    return np.array(
        [
            [a, 0.0, 0.0],
            [b * math.cos(ga), b * math.sin(ga), 0.0],
            [
                c * math.cos(be),
                c * (math.cos(al) - math.cos(be) * math.cos(ga)) / math.sin(ga),
                c
                * math.sqrt(
                    max(
                        1
                        - math.cos(be) ** 2
                        - (
                            (math.cos(al) - math.cos(be) * math.cos(ga))
                            / math.sin(ga)
                        )
                        ** 2,
                        0.0,
                    )
                ),
            ],
        ]
    )


def clamp(selected, parent, matrix, cap):
    deltas = []
    lengths = []
    for atom in selected:
        delta = np.asarray(atom.coordinates) - parent[atom.label]
        delta -= np.rint(delta)
        length = float(np.linalg.norm(delta @ matrix))
        if length > 2.5 * cap:
            delta *= 2.5 * cap / length
            length = 2.5 * cap
        deltas.append(delta)
        lengths.append(length)
    before = float(np.sqrt(np.mean(np.square(lengths))))
    factor = min(1.0, cap / max(before, 1e-15))
    for atom, delta in zip(selected, deltas):
        atom.coordinates = (parent[atom.label] + factor * delta) % 1.0
    return {"rms_before_A": before, "rms_after_A": before * factor, "cap_A": cap}


def fractions(project, hist):
    vals = {
        p.name: p.data["Histograms"][hist.name]["Scale"][0]
        * p.data["General"]["Mass"]
        for p in project.phases()
    }
    total = sum(vals.values())
    return {k: v / total for k, v in vals.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("outdir")
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--element", required=True)
    parser.add_argument("--rms", type=float, required=True)
    parser.add_argument("--blocks", type=int, default=3)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(args.input_gpx, newgpx=str(outdir / "working.gpx"))
    project.save()
    hist = project.histogram(0)
    phases = project.phases()
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = ""
    target = phases[args.phase]
    selected = [atom for atom in target.atoms() if atom.element == args.element]
    parent = {atom.label: np.asarray(atom.coordinates, dtype=float) for atom in selected}
    matrix = lattice_matrix(target.get_cell())
    for atom in selected:
        atom.refinement_flags = "X"

    history = []
    for block in range(args.blocks):
        project.set_Controls("cycles", 3)
        project.refine(printFile=str(outdir / f"fit-{block + 1}.lst"))
        projection = clamp(selected, parent, matrix, args.rms)
        project.set_Controls("cycles", 0)
        project.refine(printFile=str(outdir / f"calc-{block + 1}.lst"))
        history.append({"block": block + 1, "wR": hist.get_wR(), **projection})
        print(history[-1], flush=True)

    for atom in selected:
        atom.refinement_flags = ""
    project.set_Controls("cycles", 6)
    project.refine(printFile=str(outdir / "settle.lst"))
    project.save()
    shutil.copy2(project.filename, outdir / "checkpoint.gpx")
    payload = {
        "phase": target.name,
        "element": args.element,
        "history": history,
        "residuals": hist.residuals,
        "fractions": fractions(project, hist),
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": list(atom.coordinates),
                "ADP": atom.ADP,
            }
            for atom in target.atoms()
        ],
    }
    (outdir / "summary.json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    print("settled", hist.get_wR(), fractions(project, hist), flush=True)


if __name__ == "__main__":
    main()
