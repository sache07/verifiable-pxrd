#!/usr/bin/env python3
"""Project one coordinate family onto an absolute reference-RMS bound."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def lattice_matrix(cell):
    a, b, c = cell["length_a"], cell["length_b"], cell["length_c"]
    al, be, ga = map(
        math.radians,
        (cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]),
    )
    return np.array(
        [
            [a, 0.0, 0.0],
            [b * math.cos(ga), b * math.sin(ga), 0.0],
            [
                c * math.cos(be),
                c * (math.cos(al) - math.cos(be) * math.cos(ga)) / math.sin(ga),
                c
                * math.sqrt(
                    max(
                        1
                        - math.cos(be) ** 2
                        - (
                            (math.cos(al) - math.cos(be) * math.cos(ga))
                            / math.sin(ga)
                        )
                        ** 2,
                        0.0,
                    )
                ),
            ],
        ]
    )


def fractions(project, hist):
    raw = {
        p.name: p.data["Histograms"][hist.name]["Scale"][0]
        * p.data["General"]["Mass"]
        for p in project.phases()
    }
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("reference_cif")
    parser.add_argument("outdir")
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--element", required=True)
    parser.add_argument("--rms", type=float, required=True)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(args.input_gpx, newgpx=str(outdir / "working.gpx"))
    project.save()
    hist = project.histogram(0)
    phase = project.phases()[args.phase]

    reference_project = G2.G2Project(newgpx=str(outdir / "reference.gpx"))
    reference = reference_project.add_phase(
        str(Path(args.reference_cif).resolve()), phasename="reference", fmthint="CIF"
    )
    parent = {atom.label: np.asarray(atom.coordinates) for atom in reference.atoms()}
    matrix = lattice_matrix(phase.get_cell())
    selected = [atom for atom in phase.atoms() if atom.element == args.element]
    deltas, distances = [], []
    for atom in selected:
        delta = np.asarray(atom.coordinates) - parent[atom.label]
        delta -= np.rint(delta)
        deltas.append(delta)
        distances.append(float(np.linalg.norm(delta @ matrix)))
    rms_before = float(np.sqrt(np.mean(np.square(distances))))
    factor = min(1.0, args.rms / max(rms_before, 1e-15))
    for atom, delta in zip(selected, deltas):
        atom.coordinates = (parent[atom.label] + factor * delta) % 1.0
        atom.refinement_flags = ""

    for rep in range(2):
        project.set_Controls("cycles", 8)
        project.refine(printFile=str(outdir / f"settle-{rep + 1}.lst"))
        print(rep + 1, hist.get_wR(), flush=True)
    project.set_Controls("cycles", 0)
    project.refine(printFile=str(outdir / "replay.lst"))
    project.save()
    shutil.copy2(project.filename, outdir / "checkpoint.gpx")
    payload = {
        "phase": phase.name,
        "element": args.element,
        "rms_before_A": rms_before,
        "rms_after_A": rms_before * factor,
        "factor": factor,
        "residuals": hist.residuals,
        "fractions": fractions(project, hist),
    }
    (outdir / "summary.json").write_text(
        json.dumps(payload, indent=2, default=str) + "\n"
    )
    print(json.dumps(payload, default=str), flush=True)


if __name__ == "__main__":
    main()
