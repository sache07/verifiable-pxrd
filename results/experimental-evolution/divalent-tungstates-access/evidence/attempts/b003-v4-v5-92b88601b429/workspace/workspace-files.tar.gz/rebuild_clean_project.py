#!/usr/bin/env python3
"""Rebuild a clean three-phase project from an accepted replacement branch."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def fractions(project, hist):
    raw = {
        p.name: p.data["Histograms"][hist.name]["Scale"][0]
        * p.data["General"]["Mass"]
        for p in project.phases()
    }
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("outdir")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    source = G2.G2Project(args.input_gpx)
    source_hist = source.histogram(0)
    source_phases = source.phases()
    selected = [source_phases[0], source_phases[1], source_phases[3]]
    names = [
        "MnWO4_wolframite_P2c",
        "Mn3WO6_corundum_related_R-3",
        "WO3_monoclinic_P21c",
    ]

    phase_files = []
    for index, phase in enumerate(selected):
        path = outdir / f"source_phase_{index}.cif"
        phase.export_CIF(str(path))
        phase_files.append(path)

    x, y = source_hist.data["data"][1][:2]
    xye = outdir / "observed.xye"
    np.savetxt(
        xye,
        np.column_stack([x, y, np.sqrt(np.maximum(y, 1.0))]),
        fmt="%.8f %.8f %.8f",
    )
    inst = outdir / "instrument.instprm"
    inst.write_text(
        "#GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.20;Polariz.:0.75;Azimuth:0.0\n"
        "U:12.0;V:0.0;W:12.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )

    project = G2.G2Project(newgpx=str(outdir / "clean.gpx"))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.data["Limits"] = copy.deepcopy(source_hist.data["Limits"])
    hist.data["Background"] = copy.deepcopy(source_hist.data["Background"])
    hist.data["Instrument Parameters"] = copy.deepcopy(
        source_hist.data["Instrument Parameters"]
    )
    hist.data["Sample Parameters"] = copy.deepcopy(
        source_hist.data["Sample Parameters"]
    )

    for old, name, cif in zip(selected, names, phase_files):
        new = project.add_phase(
            str(cif), phasename=name, histograms=[hist], fmthint="CIF"
        )
        old_hap = old.data["Histograms"][source_hist.name]
        new_hap = copy.deepcopy(old_hap)
        new_hap["hId"] = hist.id
        new.data["Histograms"][hist.name] = new_hap
        new.data["General"]["Cell"][0] = bool(old.data["General"]["Cell"][0])
        for atom in new.atoms():
            atom.refinement_flags = ""

    # Re-establish the conservative physical parameter bounds under the new
    # contiguous phase numbering. No cross-phase constraints are copied.
    project.set_Controls("parmMin", -0.25, variable=":0:Zero")
    project.set_Controls("parmMax", 0.25, variable=":0:Zero")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    for name, low, high in [
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10),
        ("Polariz.", 0.6, 1.0),
    ]:
        project.set_Controls("parmMin", low, variable=f":0:{name}")
        project.set_Controls("parmMax", high, variable=f":0:{name}")
    for index in range(3):
        project.set_Controls("parmMin", 0.0, variable=f"{index}:0:Scale")
        project.set_Controls("parmMax", 1000.0, variable=f"{index}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{index}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{index}:0:Size;i")
        project.set_Controls("parmMin", 0.5, variable=f"{index}:0:MD")
        project.set_Controls("parmMax", 2.0, variable=f"{index}:0:MD")

    project.set_Controls("cycles", 0)
    project.refine(printFile=str(outdir / "replay.lst"))
    project.save()
    payload = {
        "residuals": hist.residuals,
        "fractions": fractions(project, hist),
        "phases": [p.name for p in project.phases()],
    }
    (outdir / "summary.json").write_text(
        json.dumps(payload, indent=2, default=str) + "\n"
    )
    print(json.dumps(payload, default=str), flush=True)


if __name__ == "__main__":
    main()
