#!/usr/bin/env python3
"""Compare one physical WO3 topology in the accepted three-phase state.

The questionable historical WO3 phase is retained at exactly zero scale only
to avoid unsafe surgery on the GSAS-II project tree. The candidate therefore
replaces, rather than supplements, its diffraction contribution.
"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fractions(project, hist):
    vals = {}
    for phase in project.phases():
        value = (
            phase.data["Histograms"][hist.name]["Scale"][0]
            * phase.data["General"]["Mass"]
        )
        if value > 0:
            vals[phase.name] = value
    total = sum(vals.values())
    return {key: value / total for key, value in vals.items()}


def refine(project, hist, outdir, label, repeats=2):
    for rep in range(repeats):
        project.set_Controls("cycles", 7)
        project.refine(printFile=str(outdir / f"{label}-{rep + 1}.lst"))
        print(label, rep + 1, hist.get_wR(), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("candidate_cif")
    parser.add_argument("outdir")
    parser.add_argument("--axis", required=True)
    parser.add_argument("--name", required=True)
    args = parser.parse_args()

    axis = [int(v) for v in args.axis.split(",")]
    if len(axis) != 3 or not any(axis):
        raise ValueError("axis must be a nonzero h,k,l triplet")

    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(args.input_gpx, newgpx=str(outdir / "working.gpx"))
    project.save()
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.histogram(0)
    phases = project.phases()

    # Remove the old WO3 contribution while preserving a valid project tree.
    old = phases[2]
    old_hap = old.data["Histograms"][hist.name]
    old_weight_scale = old_hap["Scale"][0] * old.data["General"]["Mass"]
    old_hap["Scale"] = [0.0, False]
    old.clear_refinements({"Cell": True})
    old.clear_HAP_refinements(
        {"Scale": True, "Pref.Ori.": True, "Size": True, "Mustrain": True},
        [hist],
    )
    for atom in old.atoms():
        atom.refinement_flags = ""

    candidate = project.add_phase(
        str(Path(args.candidate_cif).resolve()),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    phases = project.phases()
    index = len(phases) - 1
    hap = candidate.data["Histograms"][hist.name]
    hap["Scale"] = [old_weight_scale / candidate.data["General"]["Mass"], False]
    candidate.setSampleProfile(hist, "size", "isotropic", 0.128, LGmix=1.0)
    candidate.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    for atom in candidate.atoms():
        atom.uiso = 0.005
        atom.refinement_flags = ""

    project.set_Controls("parmMin", 0.0, variable=f"{index}:0:Scale")
    project.set_Controls("parmMax", 1000.0, variable=f"{index}:0:Scale")
    project.set_Controls("parmMin", 0.04, variable=f"{index}:0:Size;i")
    project.set_Controls("parmMax", 1.5, variable=f"{index}:0:Size;i")
    project.set_Controls("parmMin", 0.5, variable=f"{index}:0:MD")
    project.set_Controls("parmMax", 2.0, variable=f"{index}:0:MD")

    candidate.set_HAP_refinements({"Scale": True}, [hist])
    candidate.set_refinements({"Cell": True})
    refine(project, hist, outdir, "stage1_scale_cell", repeats=3)

    candidate.set_HAP_refinements(
        {"Size": {"type": "isotropic", "refine": True}}, [hist]
    )
    refine(project, hist, outdir, "stage2_size", repeats=2)

    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][3] = axis
    candidate.set_HAP_refinements({"Pref.Ori.": True}, [hist])
    refine(project, hist, outdir, "stage3_texture", repeats=3)

    project.save()
    shutil.copy2(project.filename, outdir / "checkpoint.gpx")
    payload = {
        "candidate": candidate.name,
        "axis": axis,
        "space_group": candidate.data["General"]["SGData"]["SpGrp"],
        "cell": candidate.get_cell(),
        "preferred_orientation": hap["Pref.Ori."],
        "size": hap["Size"],
        "residuals": hist.residuals,
        "fractions": fractions(project, hist),
    }
    (outdir / "summary.json").write_text(
        json.dumps(payload, indent=2, default=str) + "\n"
    )
    print(json.dumps(payload, default=str), flush=True)


if __name__ == "__main__":
    main()
