#!/usr/bin/env python3
"""Freeze accepted specimen/intensity terms before bounded coordinate tests."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fractions(project, hist):
    raw = {
        p.name: p.data["Histograms"][hist.name]["Scale"][0]
        * p.data["General"]["Mass"]
        for p in project.phases()
    }
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("outdir")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(args.input_gpx, newgpx=str(outdir / "working.gpx"))
    project.save()
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_HAP_refinements(
            {"Pref.Ori.": True, "Size": True, "Mustrain": True}, [hist]
        )
        for atom in phase.atoms():
            atom.refinement_flags = ""
    project.set_Controls("cycles", 0)
    project.refine(printFile=str(outdir / "calc.lst"))
    project.save()
    shutil.copy2(project.filename, outdir / "checkpoint.gpx")
    payload = {
        "residuals": hist.residuals,
        "fractions": fractions(project, hist),
        "polarization": hist.InstrumentParameters["Polariz."],
        "sample": hist.SampleParameters,
        "phases": {
            p.name: {
                "preferred_orientation": p.data["Histograms"][hist.name]["Pref.Ori."],
                "size": p.data["Histograms"][hist.name]["Size"],
                "microstrain": p.data["Histograms"][hist.name]["Mustrain"],
            }
            for p in project.phases()
        },
    }
    (outdir / "summary.json").write_text(
        json.dumps(payload, indent=2, default=str) + "\n"
    )
    print(json.dumps(payload, default=str), flush=True)


if __name__ == "__main__":
    main()
