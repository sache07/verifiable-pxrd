#!/usr/bin/env python3
"""Final bounded cleanup of supported Rietveld terms."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fractions(project, hist):
    raw = {
        p.name: p.data["Histograms"][hist.name]["Scale"][0]
        * p.data["General"]["Mass"]
        for p in project.phases()
    }
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def checkpoint(project, hist, outdir, label):
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    payload = {
        "label": label,
        "residuals": hist.residuals,
        "fractions": fractions(project, hist),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "phases": {
            p.name: p.data["Histograms"][hist.name] for p in project.phases()
        },
        "uiso": {
            p.name: {a.label: a.uiso for a in p.atoms()} for p in project.phases()
        },
    }
    (outdir / f"{label}.json").write_text(
        json.dumps(payload, indent=2, default=str) + "\n"
    )
    print(label, hist.get_wR(), payload["fractions"], flush=True)


def refine(project, hist, outdir, label, repeats=2):
    for rep in range(repeats):
        project.set_Controls("cycles", 8)
        project.refine(printFile=str(outdir / f"{label}-{rep + 1}.lst"))
        print(label, rep + 1, hist.get_wR(), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("outdir")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(args.input_gpx, newgpx=str(outdir / "working.gpx"))
    project.save()
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.histogram(0)
    phases = project.phases()

    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    for phase in phases:
        phase.clear_HAP_refinements(
            {"Pref.Ori.": True, "Size": True, "Mustrain": True}, [hist]
        )
        for atom in phase.atoms():
            atom.refinement_flags = ""

    # Crystallite sizes, one supported isotropic term per phase.
    for index, phase in enumerate(phases):
        project.set_Controls("parmMin", 0.04, variable=f"{index}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{index}:0:Size;i")
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
    refine(project, hist, outdir, "stage1_sizes", 2)
    checkpoint(project, hist, outdir, "stage1_sizes")
    for phase in phases:
        phase.clear_HAP_refinements({"Size": True}, [hist])

    # Refit only the three previously selected March-Dollase families.
    for index, phase in enumerate(phases):
        project.set_Controls("parmMin", 0.5, variable=f"{index}:0:MD")
        project.set_Controls("parmMax", 2.0, variable=f"{index}:0:MD")
        phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])
    refine(project, hist, outdir, "stage2_textures", 2)
    checkpoint(project, hist, outdir, "stage2_textures")
    for phase in phases:
        phase.clear_HAP_refinements({"Pref.Ori.": True}, [hist])

    # Surface roughness is highly correlated, so hold A and refine B only.
    hist.SampleParameters["SurfRoughA"][1] = False
    hist.SampleParameters["SurfRoughB"][1] = True
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.5, variable=":0:SurfRoughB")
    refine(project, hist, outdir, "stage3_surface_b", 2)
    checkpoint(project, hist, outdir, "stage3_surface_b")
    hist.SampleParameters["SurfRoughB"][1] = False

    # Common Uiso constraints were established in the thermal stage and are
    # retained in this project; reactivate them briefly, then freeze them.
    for pidx, phase in enumerate(phases):
        for aidx, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "U"
            project.set_Controls("parmMin", 0.001, variable=f"{pidx}::AUiso:{aidx}")
            project.set_Controls("parmMax", 0.03, variable=f"{pidx}::AUiso:{aidx}")
    refine(project, hist, outdir, "stage4_common_uiso", 2)
    checkpoint(project, hist, outdir, "stage4_common_uiso")
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = ""

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Controls("parmMin", 0.6, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    refine(project, hist, outdir, "stage5_polarization", 2)
    checkpoint(project, hist, outdir, "stage5_polarization")
    hist.clear_refinements({"Instrument Parameters": ["Polariz."]})

    # Test the physical instrument partition without changing the accepted
    # anisotropic specimen-strain model.
    for name, low, high in [("U", 0.0, 40.0), ("W", 2.0, 40.0), ("X", 0.1, 6.0)]:
        project.set_Controls("parmMin", low, variable=f":0:{name}")
        project.set_Controls("parmMax", high, variable=f":0:{name}")
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(project, hist, outdir, "stage6_instrument", 2)
    checkpoint(project, hist, outdir, "stage6_instrument")
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})

    project.set_Controls("cycles", 0)
    project.refine(printFile=str(outdir / "final-calc.lst"))
    checkpoint(project, hist, outdir, "checkpoint")


if __name__ == "__main__":
    main()
