#!/usr/bin/env python3
"""Repartition peak broadening into bounded instrument/specimen terms."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fractions(project, hist):
    vals = {
        p.name: p.data["Histograms"][hist.name]["Scale"][0]
        * p.data["General"]["Mass"]
        for p in project.phases()
    }
    total = sum(vals.values())
    return {k: v / total for k, v in vals.items()}


def summary(project, hist):
    return {
        "residuals": hist.residuals,
        "fractions": fractions(project, hist),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "phases": {
            p.name: p.data["Histograms"][hist.name] for p in project.phases()
        },
        "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    }


def checkpoint(project, hist, outdir, label):
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    (outdir / f"{label}.json").write_text(
        json.dumps(summary(project, hist), indent=2, default=str) + "\n"
    )
    print(label, hist.get_wR(), fractions(project, hist), flush=True)


def refine(project, hist, outdir, label, repeats=2):
    for rep in range(repeats):
        project.set_Controls("cycles", 8)
        project.refine(printFile=str(outdir / f"{label}-{rep + 1}.lst"))
        print(label, rep + 1, hist.get_wR(), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("outdir")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(args.input_gpx, newgpx=str(outdir / "working.gpx"))
    project.save()
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.histogram(0)
    phases = project.phases()

    # Hold intensity corrections fixed while peak-shape terms are separated.
    hist.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    hist.clear_refinements({"Instrument Parameters": ["Polariz."]})
    for phase in phases:
        phase.clear_HAP_refinements({"Pref.Ori.": True, "Size": True, "Mustrain": True}, [hist])
        for atom in phase.atoms():
            atom.refinement_flags = ""

    inst = hist.InstrumentParameters
    inst["U"][1] = 8.0
    inst["W"][1] = 13.0
    inst["X"][1] = 4.0
    inst["SH/L"][1] = 0.03
    for name, lo, hi in [
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10),
    ]:
        project.set_Controls("parmMin", lo, variable=f":0:{name}")
        project.set_Controls("parmMax", hi, variable=f":0:{name}")

    # Instrument profile against the already reasonable specimen widths.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(project, hist, outdir, "stage13_instrument", repeats=3)
    checkpoint(project, hist, outdir, "stage13_instrument")

    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
    for i, phase in enumerate(phases):
        project.set_Controls("parmMin", 0.04, variable=f"{i}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{i}:0:Size;i")
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
    refine(project, hist, outdir, "stage14_sizes", repeats=3)
    checkpoint(project, hist, outdir, "stage14_sizes")

    # The dominant MnWO4 strain was already stable and positive. Refit it with
    # the physical instrument partition, leaving zero-strain phases at zero.
    phases[0].set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
    )
    project.set_Controls("parmMin", 0.0, variable="0:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable="0:0:Mustrain;i")
    refine(project, hist, outdir, "stage15_mnwo4_strain", repeats=2)
    checkpoint(project, hist, outdir, "stage15_mnwo4_strain")

    # Joint cleanup, then the asymmetric axial-divergence term on its own.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(project, hist, outdir, "stage16_joint_profile", repeats=3)
    checkpoint(project, hist, outdir, "stage16_joint_profile")

    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    refine(project, hist, outdir, "stage17_axial_divergence", repeats=2)
    checkpoint(project, hist, outdir, "checkpoint_profile", )


if __name__ == "__main__":
    main()
