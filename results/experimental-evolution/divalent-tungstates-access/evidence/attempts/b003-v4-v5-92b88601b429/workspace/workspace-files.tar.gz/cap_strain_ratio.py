#!/usr/bin/env python3
"""Project a uniaxial microstrain model onto a fixed axial/equatorial ratio."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fractions(project, hist):
    vals = {
        p.name: p.data["Histograms"][hist.name]["Scale"][0]
        * p.data["General"]["Mass"]
        for p in project.phases()
    }
    total = sum(vals.values())
    return {k: v / total for k, v in vals.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("outdir")
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--ratio", type=float, required=True)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(args.input_gpx, newgpx=str(outdir / "working.gpx"))
    project.save()
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.histogram(0)
    target = project.phases()[args.phase]
    must = target.data["Histograms"][hist.name]["Mustrain"]
    for rep in range(4):
        must[1][1] = args.ratio * must[1][0]
        must[2] = [True, False, False]
        project.set_Controls("cycles", 6)
        project.refine(printFile=str(outdir / f"fit-{rep + 1}.lst"))
        print(rep + 1, hist.get_wR(), must, flush=True)
    must[1][1] = args.ratio * must[1][0]
    must[2] = [False, False, False]
    project.set_Controls("cycles", 0)
    project.refine(printFile=str(outdir / "calc.lst"))
    project.save()
    shutil.copy2(project.filename, outdir / "checkpoint.gpx")
    result = {
        "ratio": args.ratio,
        "microstrain": must,
        "residuals": hist.residuals,
        "fractions": fractions(project, hist),
    }
    (outdir / "summary.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print("final", hist.get_wR(), must, flush=True)


if __name__ == "__main__":
    main()
