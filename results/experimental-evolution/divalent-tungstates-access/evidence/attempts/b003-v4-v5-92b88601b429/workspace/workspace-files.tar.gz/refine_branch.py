#!/usr/bin/env python3
"""Build and comparably refine a three-phase GSAS-II branch.

Run this with the GSAS-II Python interpreter.  The script is deliberately
conservative: it refines only background, phase scales, calibration/cells and
isotropic profile terms.  Coordinate and texture tests are performed later on
the selected physical branch.
"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def source_path(cod_id: str, normalized: bool) -> Path:
    if not normalized:
        return cod_path(cod_id)
    names = {
        "1520200": "mnwo4_1520200.cif",
        "2002703": "mn3wo6_2002703.cif",
        "1528915": "wo3_1528915.cif",
    }
    if cod_id not in names:
        raise ValueError(f"No normalized local reference prepared for COD {cod_id}")
    return Path(__file__).resolve().parent / "reference_pool" / "models" / names[cod_id]


def write_inputs(pattern: Path, outdir: Path) -> tuple[Path, Path]:
    values = np.genfromtxt(pattern, delimiter=",", names=True)
    x = np.asarray(values[values.dtype.names[0]], dtype=float)
    y = np.asarray(values[values.dtype.names[1]], dtype=float)
    sigma = np.sqrt(np.maximum(y, 1.0))
    xye = outdir / "observed.xye"
    np.savetxt(xye, np.column_stack([x, y, sigma]), fmt="%.8f %.8f %.8f")

    inst = outdir / "instrument.instprm"
    inst.write_text(
        "#GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.20;Polariz.:0.75;Azimuth:0.0\n"
        "U:12.0;V:0.0;W:12.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def fractions(project: G2.G2Project, hist: G2.G2PwdrData) -> dict[str, float]:
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        raw[phase.name] = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
    total = sum(raw.values())
    return {key: value / total for key, value in raw.items()}


def snapshot(project: G2.G2Project, hist: G2.G2PwdrData, label: str, outdir: Path):
    project.save(outdir / f"{label}.gpx")
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "microstrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    record = {
        "label": label,
        "residuals": hist.residuals,
        "fractions": fractions(project, hist),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": phases,
        "covariance": project.data.get("Covariance", {}).get("data", {}),
    }
    # The covariance dict contains GSAS-II objects in a few versions. Keep the
    # human-readable subset if direct JSON serialization is not possible.
    try:
        text = json.dumps(record, indent=2, default=str)
    except Exception:
        record.pop("covariance", None)
        text = json.dumps(record, indent=2, default=str)
    (outdir / f"{label}.json").write_text(text + "\n")
    print(label, "wR", hist.get_wR(), "fractions", fractions(project, hist), flush=True)


def run(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    xye, inst = write_inputs(Path(args.pattern).resolve(), outdir)

    project = G2.G2Project(newgpx=str(outdir / "working.gpx"))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.data["Limits"][1] = [10.0, 100.0]
    sample = hist.SampleParameters
    # The histogram scale is redundant with all HAP scales. Keep it fixed so
    # refined phase scales (and hence weight fractions) are identifiable.
    sample["Scale"] = [1.0, False]
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    phase_specs = [
        ("MnWO4_wolframite", args.mnwo4),
        ("Mn3WO6_corundum_related", args.mn3wo6),
        (f"WO3_{args.wo3}", args.wo3),
    ]
    phases = []
    for name, cid in phase_specs:
        phase = project.add_phase(
            str(source_path(cid, args.normalized)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phases.append(phase)
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [0.1, False]
        phase.setSampleProfile(hist, "size", "isotropic", 0.3, LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=1.0)

    # Physical bounds prevent profile terms from crossing into nonphysical
    # values while branches are being compared.
    project.set_Controls("parmMin", -0.5, variable=":0:Zero")
    project.set_Controls("parmMax", 0.5, variable=":0:Zero")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    for name, low, high in [
        (":0:U", 0.0, 80.0),
        (":0:W", 0.0, 80.0),
        (":0:X", 0.0, 15.0),
        (":0:SH/L", 0.001, 0.20),
    ]:
        project.set_Controls("parmMin", low, variable=name)
        project.set_Controls("parmMax", high, variable=name)
    for index in range(len(phases)):
        for suffix, low, high in [
            ("Scale", 0.0, 1000.0),
            ("Size;i", 0.02, 5.0),
            ("Mustrain;i", 0.0, 12000.0),
        ]:
            project.set_Controls("parmMin", low, variable=f"{index}:0:{suffix}")
            project.set_Controls("parmMax", high, variable=f"{index}:0:{suffix}")

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [3500.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": True,
            }
        }
    )
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
    project.set_Controls("cycles", 6)
    project.refine(printFile=str(outdir / "stage1.lst"))
    snapshot(project, hist, "stage1_scale_background", outdir)

    # A common zero and independent cells capture the peak positions without
    # allowing the broadening or atomic model to mask topology mismatch.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.refine(printFile=str(outdir / "stage2.lst"))
    snapshot(project, hist, "stage2_cells_zero", outdir)

    # Separate constant zero from the Bragg-Brentano sample-height term.
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.refine(printFile=str(outdir / "stage3.lst"))
    snapshot(project, hist, "stage3_shift", outdir)

    # First refine a shared instrument profile, then specimen broadening by
    # phase. V is left fixed at zero to reduce Caglioti correlations initially.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    project.refine(printFile=str(outdir / "stage4.lst"))
    snapshot(project, hist, "stage4_instrument_profile", outdir)

    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            histograms=[hist],
        )
    project.refine(printFile=str(outdir / "stage5.lst"))
    snapshot(project, hist, "stage5_phase_profiles", outdir)

    # Save a replayable branch checkpoint with all current flags and values.
    project.save(outdir / "checkpoint.gpx")
    shutil.copy2(outdir / "stage5_phase_profiles.json", outdir / "summary.json")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", default="inputs/pattern.csv")
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--wo3", required=True)
    parser.add_argument("--mnwo4", default="1520200")
    parser.add_argument("--mn3wo6", default="2002703")
    parser.add_argument("--normalized", action="store_true")
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
