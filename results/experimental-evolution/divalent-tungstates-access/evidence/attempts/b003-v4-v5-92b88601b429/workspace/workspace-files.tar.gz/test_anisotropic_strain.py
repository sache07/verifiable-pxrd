#!/usr/bin/env python3
"""Test one bounded uniaxial microstrain family for a selected phase."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fractions(project, hist):
    vals = {
        p.name: p.data["Histograms"][hist.name]["Scale"][0]
        * p.data["General"]["Mass"]
        for p in project.phases()
    }
    total = sum(vals.values())
    return {k: v / total for k, v in vals.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("outdir")
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--axis", required=True)
    parser.add_argument("--equatorial", type=float, default=None)
    parser.add_argument("--axial", type=float, default=None)
    args = parser.parse_args()
    axis = [int(v) for v in args.axis.split(",")]

    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(args.input_gpx, newgpx=str(outdir / "working.gpx"))
    project.save()
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.histogram(0)
    phases = project.phases()
    hist.clear_refinements({"Instrument Parameters": ["SH/L", "U", "W", "X"]})
    for phase in phases:
        phase.clear_HAP_refinements({"Mustrain": True, "Size": True}, [hist])
    target = phases[args.phase]
    current = target.data["Histograms"][hist.name]["Mustrain"][1][0]
    equatorial = args.equatorial if args.equatorial is not None else max(current, 500.0)
    axial = args.axial if args.axial is not None else 1.5 * equatorial
    target.setSampleProfile(
        hist, "microstrain", "uniaxial", equatorial, axial, axis, LGmix=1.0
    )
    target.set_HAP_refinements(
        {
            "Mustrain": {
                "type": "uniaxial",
                "refine": True,
                "direction": axis,
            }
        },
        [hist],
    )
    for suffix in ["Mustrain;i", "Mustrain;a"]:
        project.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:{suffix}")
        project.set_Controls("parmMax", 8000.0, variable=f"{args.phase}:0:{suffix}")
    for rep in range(3):
        project.set_Controls("cycles", 8)
        project.refine(printFile=str(outdir / f"fit-{rep + 1}.lst"))
        print(
            rep + 1,
            hist.get_wR(),
            target.data["Histograms"][hist.name]["Mustrain"],
            flush=True,
        )
    project.save()
    shutil.copy2(project.filename, outdir / "checkpoint.gpx")
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "phase_index": args.phase,
        "phase": target.name,
        "axis": axis,
        "microstrain": target.data["Histograms"][hist.name]["Mustrain"],
        "residuals": hist.residuals,
        "fractions": fractions(project, hist),
        "Rvals": cov.get("Rvals", {}),
    }
    (outdir / "summary.json").write_text(json.dumps(result, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
