#!/usr/bin/env python3
"""Staged coordinate refinement for the accepted three-phase checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def phase_fractions(project, hist):
    raw = {
        phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
        * phase.data["General"]["Mass"]
        for phase in project.phases()
    }
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def state(project, hist, label):
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "label": label,
        "residuals": hist.residuals,
        "fractions": phase_fractions(project, hist),
        "varyList": cov.get("varyList", []),
        "variables": [float(v) for v in cov.get("variables", [])],
        "sig": [float(v) for v in cov.get("sig", [])],
        "Rvals": cov.get("Rvals", {}),
        "atoms": {
            phase.name: [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": list(atom.coordinates),
                    "occupancy": atom.occupancy,
                    "flags": atom.refinement_flags,
                    "ADP": atom.ADP,
                }
                for atom in phase.atoms()
            ]
            for phase in project.phases()
        },
    }


def run_stage(project, hist, outdir, label, repeats=2):
    for repeat in range(repeats):
        project.set_Controls("cycles", 8)
        project.refine(printFile=str(outdir / f"{label}-{repeat + 1}.lst"))
        print(label, repeat + 1, "wR", hist.get_wR(), flush=True)
    project.save(outdir / f"{label}.gpx")
    payload = state(project, hist, label)
    (outdir / f"{label}.json").write_text(json.dumps(payload, indent=2, default=str) + "\n")


def set_position_flags(phase, elements):
    for atom in phase.atoms():
        if atom.element in elements:
            atom.refinement_flags = "X"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("outdir")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(args.input_gpx, newgpx=str(outdir / "working.gpx"))
    hist = project.histogram(0)
    phases = project.phases()

    # Keep the already fitted scale/background/cell/profile terms active while
    # the structure relaxes, but remove parameters that had landed on a bound.
    hist.clear_refinements({"Instrument Parameters": ["U", "X", "SH/L"]})
    phases[1].clear_HAP_refinements({"Mustrain": True}, [hist])
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = ""

    set_position_flags(phases[0], {"Mn", "W"})
    set_position_flags(phases[1], {"Mn", "W"})
    set_position_flags(phases[2], {"W"})
    run_stage(project, hist, outdir, "stage6_heavy_coordinates", repeats=3)

    set_position_flags(phases[0], {"O"})
    run_stage(project, hist, outdir, "stage7_mnwo4_oxygen", repeats=2)

    set_position_flags(phases[1], {"O"})
    run_stage(project, hist, outdir, "stage8_mn3wo6_oxygen", repeats=2)

    set_position_flags(phases[2], {"O"})
    run_stage(project, hist, outdir, "stage9_wo3_oxygen", repeats=3)

    project.save(outdir / "checkpoint_coordinates.gpx")


if __name__ == "__main__":
    main()
