#!/usr/bin/env python3
"""Test the Bragg-Brentano Suortti surface-roughness correction."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fractions(project, hist):
    vals = {
        p.name: p.data["Histograms"][hist.name]["Scale"][0]
        * p.data["General"]["Mass"]
        for p in project.phases()
    }
    total = sum(vals.values())
    return {k: v / total for k, v in vals.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("outdir")
    parser.add_argument("--a", type=float, default=0.2)
    parser.add_argument("--b", type=float, default=0.1)
    parser.add_argument("--fix-a", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(args.input_gpx, newgpx=str(outdir / "working.gpx"))
    project.save()
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.histogram(0)
    hist.SampleParameters["SurfRoughA"] = [args.a, not args.fix_a]
    hist.SampleParameters["SurfRoughB"] = [args.b, True]
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.6, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.001, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.5, variable=":0:SurfRoughB")
    for rep in range(3):
        project.set_Controls("cycles", 8)
        project.refine(printFile=str(outdir / f"fit-{rep + 1}.lst"))
        print(rep + 1, hist.get_wR(), hist.SampleParameters, flush=True)
    project.save()
    shutil.copy2(project.filename, outdir / "checkpoint.gpx")
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "surface_roughness_A": hist.SampleParameters["SurfRoughA"],
        "surface_roughness_B": hist.SampleParameters["SurfRoughB"],
        "residuals": hist.residuals,
        "fractions": fractions(project, hist),
        "Rvals": cov.get("Rvals", {}),
    }
    (outdir / "summary.json").write_text(json.dumps(result, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
