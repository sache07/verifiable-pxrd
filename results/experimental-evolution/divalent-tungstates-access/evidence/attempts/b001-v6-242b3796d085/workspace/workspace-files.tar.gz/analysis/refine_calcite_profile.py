#!/usr/bin/env python3
"""Refine only the supported calcite width after phase acceptance."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2

from complete_checkpoint import clear_flags, enable_scales_background, mass_fractions, reset_bounds


def snapshot(project, stage):
    hist = project.histogram(0)
    r = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {"stage": stage, "rwp_percent": float(hist.get_wR()),
            "converged": bool(r.get("converged", False)), "max_shift_esd": r.get("Max shft/sig"),
            "frozen": [str(v) for v in project.get_Frozen()], "fractions": mass_fractions(project)}


def refine(source: Path, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = project.histogram(0)
    calcite = project.phase("CaCO3_calcite")
    clear_flags(project)
    reset_bounds(project)
    project.index_ids()
    hid = hist.id
    for phase in project.phases():
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hid}:Scale")
        project.set_Controls("parmMax", 100.0, variable=f"{phase.id}:{hid}:Scale")
    project.set_Controls("parmMin", 0.04, variable=f"{calcite.id}:{hid}:Size;i")
    project.set_Controls("parmMax", 2.0, variable=f"{calcite.id}:{hid}:Size;i")
    enable_scales_background(project)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    calcite.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    records = []
    for index, cycles in enumerate((10, 8), 1):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", cycles)
        project.save(); project.refine(makeBack=False); project.save()
        records.append(snapshot(project, f"size_settle_{index}"))
        shutil.copy2(project.filename, output.parent / f"checkpoint-{index:02d}-size_settle.gpx")
        print(json.dumps(records[-1]), flush=True)
    clear_flags(project)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 0)
    project.save(); project.refine(makeBack=False); project.save()
    records.append(snapshot(project, "calculation_only_replay"))
    print(json.dumps(records[-1]), flush=True)
    output.with_suffix(".json").write_text(json.dumps({
        "records": records,
        "calcite_size_um": calcite.data["Histograms"][hist.name]["Size"][1][0],
        "cells": {p.name: p.get_cell() for p in project.phases()},
    }, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    refine(args.source.resolve(), args.output.resolve())


if __name__ == "__main__":
    main()
