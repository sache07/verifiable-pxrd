#!/usr/bin/env python3
"""Test one common calcite Uiso without varying its light-atom coordinates."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from complete_checkpoint import clear_flags, enable_scales_background, mass_fractions, reset_bounds


def status(project, stage):
    hist = project.histogram(0)
    values = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {"stage": stage, "rwp_percent": float(hist.get_wR()),
            "converged": bool(values.get("converged", False)), "max_shift_esd": values.get("Max shft/sig"),
            "frozen": [str(v) for v in project.get_Frozen()], "fractions": mass_fractions(project)}


def refine(source: Path, output: Path):
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = project.histogram(0)
    calcite = project.phase("CaCO3_calcite")
    clear_flags(project)
    reset_bounds(project)
    project.save(); project.index_ids()
    variables = []
    for index, atom in enumerate(calcite.atoms()):
        atom.refinement_flags = "U"
        variables.append(f"{calcite.id}::AUiso:{index}")
        project.set_Controls("parmMin", 0.0, variable=variables[-1])
        project.set_Controls("parmMax", 0.05, variable=variables[-1])
    project.add_EquivConstr(variables, reloadIdx=False)
    hid = hist.id
    for phase in project.phases():
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hid}:Scale")
        project.set_Controls("parmMax", 100.0, variable=f"{phase.id}:{hid}:Scale")
    project.set_Controls("parmMin", 0.04, variable=f"{calcite.id}:{hid}:Size;i")
    project.set_Controls("parmMax", 2.0, variable=f"{calcite.id}:{hid}:Size;i")
    enable_scales_background(project)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    calcite.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    records=[]
    for n,cycles in enumerate((10,8),1):
        project.data["Controls"]["data"]["parmFrozen"]={"FrozenList":[]}
        project.set_Controls("cycles",cycles);project.save();project.refine(makeBack=False);project.save()
        records.append(status(project,f"uiso_settle_{n}"));print(json.dumps(records[-1]),flush=True)
    clear_flags(project);project.data["Controls"]["data"]["parmFrozen"]={"FrozenList":[]}
    project.set_Controls("cycles",0);project.save();project.refine(makeBack=False);project.save()
    records.append(status(project,"calculation_only_replay"));print(json.dumps(records[-1]),flush=True)
    output.with_suffix(".json").write_text(json.dumps({
        "records":records,
        "calcite_uiso_A2":[float(a.uiso) for a in calcite.atoms()],
        "calcite_size_um":calcite.data["Histograms"][hist.name]["Size"][1][0],
    },indent=2)+"\n")


def main():
    p=argparse.ArgumentParser();p.add_argument("source",type=Path);p.add_argument("output",type=Path);a=p.parse_args()
    G2.SetPrintLevel("warn");refine(a.source.resolve(),a.output.resolve())


if __name__=="__main__":main()
