#!/usr/bin/env python3
"""Complete the physical nuisance model before the one-shot coordinate polish."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][1] = False
        for value in hap["Babinet"].values():
            value[1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def enable_scales_background(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def reset_bounds(project: G2.G2Project) -> None:
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}


def install_bounds(project: G2.G2Project) -> None:
    project.index_ids()
    hist = project.histogram(0)
    hid = hist.id
    bounds = [
        (f":{hid}:Zero", -1.0, 1.0),
        (f":{hid}:Shift", -1500.0, 1500.0),
        (f":{hid}:U", 0.0, 100.0),
        (f":{hid}:W", 0.1, 100.0),
        (f":{hid}:X", 0.01, 20.0),
        (f":{hid}:SH/L", 0.002, 0.2),
        (f":{hid}:Polariz.", 0.4, 1.0),
    ]
    for phase in project.phases():
        pid = phase.id
        bounds.extend([
            (f"{pid}:{hid}:Scale", 0.0, 100.0),
            (f"{pid}:{hid}:Size;i", 0.02, 10.0),
            (f"{pid}:{hid}:Mustrain;i", 0.0, 20000.0),
        ])
        for index, _atom in enumerate(phase.atoms()):
            bounds.append((f"{pid}::AUiso:{index}", 0.0, 0.05))
    for variable, low, high in bounds:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)


def mass_fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    weighted = {
        phase.name: max(0.0, float(phase.data["General"]["Mass"]) * float(phase.data["Histograms"][hist.name]["Scale"][0]))
        for phase in project.phases()
    }
    total = sum(weighted.values())
    return {key: value / total for key, value in weighted.items()}


def state(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": stage,
        "rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "fractions": mass_fractions(project),
    }


def run(project: G2.G2Project, out_dir: Path, stage: str, records: list[dict], cycles: int = 12) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    records.append(state(project, stage))
    shutil.copy2(project.filename, out_dir / f"checkpoint-{len(records):02d}-{stage}.gpx")
    print(json.dumps(records[-1]), flush=True)


def constrain_phase_uiso(project: G2.G2Project) -> None:
    project.data["Constraints"]["data"]["Phase"] = []
    project.save()
    project.index_ids()
    for phase in project.phases():
        variables = []
        for index, atom in enumerate(phase.atoms()):
            atom.uiso = 0.005
            atom.refinement_flags = "U"
            variables.append(f"{phase.id}::AUiso:{index}")
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)


def complete(source: Path, output: Path, initial_zero: float, initial_shift: float, calibration_mode: str) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = project.histogram(0)
    hist.Limits("lower", float(hist.data["Limits"][0][0]))
    hist.Limits("upper", float(hist.data["Limits"][0][1]))
    clear_flags(project)
    reset_bounds(project)
    install_bounds(project)
    records: list[dict] = []

    # Frozen reference models are registered with Uiso=0.005 A^2. Let one
    # constrained isotropic value per phase absorb the specimen realization.
    constrain_phase_uiso(project)
    enable_scales_background(project)
    run(project, output.parent, "phase_uiso", records)

    # Separate constant angular zero from Bragg-Brentano specimen displacement.
    clear_flags(project)
    enable_scales_background(project)
    hist.InstrumentParameters["Zero"][1] = float(initial_zero)
    hist.SampleParameters["Shift"][0] = float(initial_shift)
    hist.InstrumentParameters["Zero"][2] = calibration_mode in {"zero-only", "both"}
    hist.SampleParameters["Shift"][1] = calibration_mode in {"shift-only", "both"}
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run(project, output.parent, "calibration_cells", records)
    run(project, output.parent, "calibration_cells_settle", records, cycles=8)

    # Settle the complete ordinary peak-shape model, retaining positive scales,
    # widths and the full dual-wavelength profile.
    clear_flags(project)
    enable_scales_background(project)
    instrument_parameters = ["U", "W", "X", "SH/L"]
    if calibration_mode in {"zero-only", "both"}:
        instrument_parameters.append("Zero")
    refs = {"Instrument Parameters": instrument_parameters}
    if calibration_mode in {"shift-only", "both"}:
        refs["Sample Parameters"] = ["Shift"]
    hist.set_refinements(refs)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    run(project, output.parent, "complete_profile", records)
    run(project, output.parent, "complete_profile_settle", records, cycles=8)

    # Polarization is an independent, bounded instrument intensity term.
    hist.InstrumentParameters["Polariz."][2] = True
    run(project, output.parent, "polarization", records, cycles=8)
    run(project, output.parent, "final_settle", records, cycles=8)

    summary = {
        "source": str(source),
        "output": str(output),
        "records": records,
        "instrument": {k: v[1] if isinstance(v, list) and len(v) > 1 else v for k, v in hist.InstrumentParameters.items()},
        "sample": hist.SampleParameters,
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "uiso": {phase.name: [float(atom.uiso) for atom in phase.atoms()] for phase in project.phases()},
        "hap": {phase.name: phase.data["Histograms"][hist.name] for phase in project.phases()},
        "background": hist.Background,
    }
    output.with_suffix(".complete.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--initial-zero", type=float, default=-0.10)
    parser.add_argument("--initial-shift", type=float, default=460.0)
    parser.add_argument("--calibration-mode", choices=["zero-only", "shift-only", "both"], default="shift-only")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    complete(args.source.resolve(), args.output.resolve(), args.initial_zero, args.initial_shift, args.calibration_mode)


if __name__ == "__main__":
    main()
