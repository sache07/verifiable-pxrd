#!/usr/bin/env python3
"""Settle a replay-consistent physical profile with insensitive terms fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2

from complete_checkpoint import clear_flags, enable_scales_background, mass_fractions, reset_bounds


def install_bounds(project: G2.G2Project) -> None:
    project.index_ids()
    hist = project.histogram(0)
    hid = hist.id
    bounds = [
        (f":{hid}:Shift", -1200.0, 1200.0),
        (f":{hid}:U", 0.0, 80.0),
        (f":{hid}:W", 0.1, 80.0),
        (f":{hid}:X", 0.01, 12.0),
        (f":{hid}:SH/L", 0.002, 0.15),
        (f":{hid}:Polariz.", 0.4, 1.0),
    ]
    for phase in project.phases():
        pid = phase.id
        bounds.append((f"{pid}:{hid}:Scale", 0.0, 100.0))
    # Only supported interior phase-width terms are varied below.
    bounds.extend([
        (f"0:{hid}:Size;i", 0.04, 2.0),
        (f"1:{hid}:Mustrain;i", 0.0, 10000.0),
    ])
    for variable, low, high in bounds:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)


def record(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": stage,
        "rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "fractions": mass_fractions(project),
    }


def run(project: G2.G2Project, out_dir: Path, stage: str, records: list[dict], cycles: int = 12) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    records.append(record(project, stage))
    shutil.copy2(project.filename, out_dir / f"checkpoint-{len(records):02d}-{stage}.gpx")
    print(json.dumps(records[-1]), flush=True)


def settle(source: Path, output: Path, wo_size: float, refine_wo_strain: bool) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = project.histogram(0)
    clear_flags(project)
    reset_bounds(project)
    install_bounds(project)
    records: list[dict] = []

    ca, wo = project.phases()
    ca_hap = ca.data["Histograms"][hist.name]
    wo_hap = wo.data["Histograms"][hist.name]
    ca_hap["Mustrain"][0] = "isotropic"
    ca_hap["Mustrain"][1][0] = 0.0
    wo_hap["Size"][0] = "isotropic"
    wo_hap["Size"][1][0] = float(wo_size)
    if not refine_wo_strain:
        wo_hap["Mustrain"][1][0] = 0.0

    enable_scales_background(project)
    hist.set_refinements({
        "Instrument Parameters": ["U", "W", "X", "SH/L"],
        "Sample Parameters": ["Shift"],
    })
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    ca.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    if refine_wo_strain:
        wo.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    run(project, output.parent, "profile", records)
    run(project, output.parent, "profile_settle", records, cycles=8)

    # Refine polarization only after widths are stable.
    hist.InstrumentParameters["Polariz."][2] = True
    run(project, output.parent, "polarization", records, cycles=8)

    # Freeze every parameter and force GSAS-II to recalculate the profile from
    # the serialized values. This is the replay-consistency check.
    clear_flags(project)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 0)
    project.save()
    project.refine(makeBack=False)
    project.save()
    records.append(record(project, "calculation_only_replay"))
    shutil.copy2(project.filename, output.parent / f"checkpoint-{len(records):02d}-calculation_only_replay.gpx")
    print(json.dumps(records[-1]), flush=True)

    summary = {
        "source": str(source),
        "output": str(output),
        "settings": {"wo_size_um_fixed": wo_size, "refine_wo_strain": refine_wo_strain},
        "records": records,
        "instrument": {k: v[1] if isinstance(v, list) and len(v) > 1 else v for k, v in hist.InstrumentParameters.items()},
        "sample": hist.SampleParameters,
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "uiso": {phase.name: [float(atom.uiso) for atom in phase.atoms()] for phase in project.phases()},
        "hap": {phase.name: phase.data["Histograms"][hist.name] for phase in project.phases()},
    }
    output.with_suffix(".physical.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--wo-size", type=float, default=3.0)
    parser.add_argument("--fix-wo-strain", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    settle(args.source.resolve(), args.output.resolve(), args.wo_size, not args.fix_wo_strain)


if __name__ == "__main__":
    main()
