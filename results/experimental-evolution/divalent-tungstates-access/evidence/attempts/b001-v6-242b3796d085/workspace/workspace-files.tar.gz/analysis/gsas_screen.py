#!/usr/bin/env python3
"""Build and conservatively refine a two-phase GSAS-II screening project.

This is an analysis helper for the current specimen. It uses the measured
Poisson counting uncertainty and keeps the same refinement sequence for each
candidate WO3 structure so candidate comparisons are meaningful.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
import shutil
import sys

import numpy as np

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
INPUT_CSV = ROOT / "inputs" / "pattern.csv"
COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_input(run_dir: Path) -> tuple[Path, Path]:
    run_dir.mkdir(parents=True, exist_ok=True)
    data = np.loadtxt(INPUT_CSV, delimiter=",", skiprows=1)
    xye = run_dir / "observed.xye"
    np.savetxt(xye, np.column_stack((data[:, 0], data[:, 1], np.sqrt(np.maximum(data[:, 1], 1.0)))), fmt="%.8f %.8f %.8f")
    inst = run_dir / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file; initial Cu Kalpha Bragg-Brentano profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.25;Polariz.:0.70;Azimuth:0.0\n"
        "U:5.0;V:0.0;W:5.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def clear_all(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements({
        "Background": {},
        "Instrument Parameters": list(hist.InstrumentParameters),
        "Sample Parameters": [k for k, v in hist.SampleParameters.items() if isinstance(v, list) and len(v) > 1],
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"Atoms": {"all": " "}})
        phase.clear_HAP_refinements({
            "Scale": True,
            "Size": True,
            "Mustrain": True,
            "Pref.Ori.": True,
            "HStrain": True,
            "Extinction": True,
            "Babinet": ["BabA", "BabU"],
        })


def set_reasonable_bounds(project: G2.G2Project) -> None:
    """Prevent screening branches from turning numerical failure into a false win."""
    project.index_ids()
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    hid = hist.id
    # Instrument and specimen ranges cover the lab settings but reject nonsense.
    for name, lo, hi in [
        ("Zero", -0.50, 0.30),
        ("U", 0.0, 60.0),
        ("W", 0.2, 60.0),
        ("X", 0.01, 8.0),
        ("SH/L", 0.002, 0.15),
        ("Polariz.", 0.45, 1.0),
    ]:
        project.set_Controls("parmMin", lo, variable=f":{hid}:{name}")
        project.set_Controls("parmMax", hi, variable=f":{hid}:{name}")
    project.set_Controls("parmMin", -800.0, variable=f":{hid}:Shift")
    project.set_Controls("parmMax", 800.0, variable=f":{hid}:Shift")
    for phase in project.phases():
        pid = phase.id
        hap = phase.data["Histograms"][hist.name]
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMax", 100.0, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMin", 0.03, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 3.0, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, variable=f"{pid}:{hid}:Mustrain;i")


def run_refinement(project: G2.G2Project, run_dir: Path, name: str, records: list[dict]) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.refine()
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    records.append({
        "step": name,
        "rwp_percent": float(hist.get_wR()),
        "gof": float(cov.get("Rvals", {}).get("GOF", math.nan)),
        "converged": bool(cov.get("Rvals", {}).get("converged", False)),
        "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
    })
    project.save()
    shutil.copy2(project.filename, run_dir / f"checkpoint-{len(records):02d}-{name}.gpx")


def mass_fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted[phase.name] = max(0.0, float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
    total = sum(weighted.values())
    return {k: v / total for k, v in weighted.items()}


def build_and_refine(label: str, wo3_id: str) -> Path:
    run_dir = ROOT / "analysis" / "screen" / label
    xye, inst = prepare_input(run_dir)
    project_path = run_dir / "screen.gpx"
    project = G2.G2Project(newgpx=str(project_path))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    ca = project.add_phase(str(cod_path("7219229")), phasename="CaWO4_scheelite", histograms=[hist], fmthint="CIF")
    wo = project.add_phase(str(cod_path(wo3_id)), phasename=f"WO3_{wo3_id}", histograms=[hist], fmthint="CIF")

    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 10, "coeffs": [1000.0] + [0.0] * 9, "refine": False}})

    # Starting scales and profiles are estimated from the two resolved families.
    for phase, scale, size, strain in [(ca, 4.5, 0.20, 2200.0), (wo, 0.65, 1.0, 100.0)]:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain

    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    clear_all(project)
    set_reasonable_bounds(project)
    records: list[dict] = []

    # Close the gross model first: phase scales and broad continuum.
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    run_refinement(project, run_dir, "scales_background", records)

    # Peak positions: first a common zero, then symmetry-preserving cells.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(project, run_dir, "zero", records)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run_refinement(project, run_dir, "cells", records)

    # Resolve common profile terms one at a time before phase broadening.
    for parameter in ["W", "U", "X", "SH/L"]:
        hist.set_refinements({"Instrument Parameters": [parameter]})
        run_refinement(project, run_dir, f"instrument_{parameter.replace('/', '_')}", records)
    for phase in [ca, wo]:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True, "value": phase.data["Histograms"][hist.name]["Size"][1][0]},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
        run_refinement(project, run_dir, f"profile_{phase.name}", records)
    run_refinement(project, run_dir, "repeat", records)

    result = {
        "label": label,
        "wo3_cod_id": wo3_id,
        "project": str(project_path.relative_to(ROOT)),
        "steps": records,
        "fractions": mass_fractions(project),
        "instrument": {k: v[1] if isinstance(v, list) and len(v) > 1 else v for k, v in hist.InstrumentParameters.items()},
        "sample": hist.SampleParameters,
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "hap": {p.name: p.data["Histograms"][hist.name] for p in project.phases()},
    }
    (run_dir / "screen.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    return run_dir / "screen.json"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("label")
    parser.add_argument("wo3_id")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    path = build_and_refine(args.label, args.wo3_id)
    print(path)


if __name__ == "__main__":
    main()
