#!/usr/bin/env python3
"""Export all submission artifacts from the accepted final.gpx."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "final.gpx"


def main() -> None:
    project = G2.G2Project(str(PROJECT))
    hist = project.histogram(0)
    phases = project.phases()
    if len(project.histograms()) != 1 or len(phases) != 3:
        raise RuntimeError("accepted project inventory changed")

    fractions = hist.ComputeMassFracs()
    residuals = hist.residuals
    rvals = project.data["Covariance"]["data"]["Rvals"]
    x = np.asarray(hist.getdata("X"), float)
    observed = np.asarray(hist.getdata("Yobs"), float)
    calculated = np.asarray(hist.getdata("Ycalc"), float)
    background = np.asarray(hist.getdata("Background"), float)
    difference = observed - calculated
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    if abs(rwp - float(hist.get_wR())) > 1e-8:
        raise RuntimeError("manual and GSAS-II Rwp disagree")
    if np.any(background < 0) or np.any(calculated < 0):
        raise RuntimeError("accepted model has a negative background or calculated profile")

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
        writer.writerows(zip(x, observed, calculated, difference))

    export_names = {
        "CaWO4_scheelite": "phase_CaWO4_scheelite.cif",
        "WO3_2311041": "phase_WO3_monoclinic.cif",
        "CaCO3_calcite": "phase_CaCO3_calcite.cif",
    }
    phase_metadata = {
        "CaWO4_scheelite": {
            "name": "CaWO4 scheelite",
            "formula": "CaWO4",
            "reference": "COD 7219229",
        },
        "WO3_2311041": {
            "name": "WO3 monoclinic",
            "formula": "WO3",
            "reference": "COD 2311041",
        },
        "CaCO3_calcite": {
            "name": "CaCO3 calcite",
            "formula": "CaCO3",
            "reference": "COD 1547347",
        },
    }

    # Export the saved full-precision atoms rather than stale covariance
    # parameter aliases. This mirrors the independent project replay.
    project.data["Covariance"]["data"] = {}
    rows = []
    for phase in phases:
        filename = export_names[phase.name]
        phase.export_CIF(str(ROOT / filename))
        fraction, esd = fractions[phase.name]
        rows.append({
            **phase_metadata[phase.name],
            "project_phase_name": phase.name,
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": filename,
            "weight_fraction": float(fraction),
            "weight_fraction_esd": float(esd),
            "bragg_r_factor_percent": float(residuals[f"{phase.id}:0:Rf"]),
        })

    result = {
        "phases": rows,
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "refinement_histogram": hist.name,
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": float(residuals["R"]),
            "weighted_background_r_percent": float(residuals["wRb"]),
            "rwp_min_percent": float(residuals["wRmin"]),
            "chi_square": chi_square,
            "reduced_chi_square": float(chi_square / (int(rvals["Nobs"]) - int(rvals["Nvars"]))),
            "goodness_of_fit": float(rvals["GOF"]),
            "n_points": int(rvals["Nobs"]),
            "n_refined_parameters_final_settle": int(rvals["Nvars"]),
        },
        "calibration": {
            "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
            "specimen_shift_um": float(hist.SampleParameters["Shift"][0]),
            "goniometer_radius_mm": float(hist.SampleParameters["Gonio. radius"]),
        },
        "profile": {
            "background_min_counts": float(np.min(background)),
            "calculated_min_counts": float(np.min(calculated)),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
