#!/usr/bin/env python3
"""Test and refine a residual calcite phase against the complete profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2

from complete_checkpoint import clear_flags, enable_scales_background, mass_fractions, reset_bounds


COD_CALCITE = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/54/73/1547347.cif")


def state(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": stage,
        "rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "fractions": mass_fractions(project),
    }


def run(project: G2.G2Project, out_dir: Path, stage: str, records: list[dict], cycles: int = 10) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    records.append(state(project, stage))
    shutil.copy2(project.filename, out_dir / f"checkpoint-{len(records):02d}-{stage}.gpx")
    print(json.dumps(records[-1]), flush=True)


def add_phase(source: Path, output: Path, calcite_size: float) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = project.histogram(0)
    calcite = project.add_phase(str(COD_CALCITE), phasename="CaCO3_calcite", histograms=[hist], fmthint="CIF")
    hap = calcite.data["Histograms"][hist.name]
    hap["Scale"] = [0.30, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = float(calcite_size)
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    for atom in calcite.atoms():
        if atom.adp_flag != "I":
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 2:atom.cia + 8] = [0.0] * 6
        atom.uiso = 0.005
        atom.refinement_flags = " "

    clear_flags(project)
    reset_bounds(project)
    project.index_ids()
    hid = hist.id
    for phase in project.phases():
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hid}:Scale")
        project.set_Controls("parmMax", 100.0, variable=f"{phase.id}:{hid}:Scale")

    records: list[dict] = []
    enable_scales_background(project)
    run(project, output.parent, "scale", records)

    calcite.set_refinements({"Cell": True})
    run(project, output.parent, "calcite_cell", records)

    # Settle every accepted lattice and the quantitative scales, but keep all
    # atomic coordinates and the insensitive calcite width fixed.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run(project, output.parent, "all_cells_settle", records, cycles=8)

    clear_flags(project)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 0)
    project.save()
    project.refine(makeBack=False)
    project.save()
    records.append(state(project, "calculation_only_replay"))
    print(json.dumps(records[-1]), flush=True)

    summary = {
        "source": str(source),
        "output": str(output),
        "calcite_size_um_fixed": calcite_size,
        "records": records,
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "hap": {phase.name: phase.data["Histograms"][hist.name] for phase in project.phases()},
    }
    output.with_suffix(".calcite.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--calcite-size", type=float, default=0.3)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    add_phase(args.source.resolve(), args.output.resolve(), args.calcite_size)


if __name__ == "__main__":
    main()
