from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "coordinates" / "accepted.gpx"
OUT = ROOT / ".tmp" / "profiles"


def clear_frozen(project):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def install_bounds(project):
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    for name, low, high in (
        ("U", 0.0, 40.0), ("W", 2.0, 40.0), ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10), ("Polariz.", 0.5, 1.0),
        ("Zero", -0.25, 0.25),
    ):
        project.set_Controls("parmMin", low, variable=f":0:{name}")
        project.set_Controls("parmMax", high, variable=f":0:{name}")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    hist = project.histogram(0)
    for phase in project.phases():
        pid = int(phase.data["pId"])
        hap = phase.data["Histograms"][hist.name]
        scale = float(hap["Scale"][0])
        project.set_Controls("parmMin", max(scale * 0.20, 0.0), variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", max(scale * 5.0, 1.0), variable=f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(reciprocal):
            value = float(value)
            span = max(0.01 * abs(value), 0.0003)
            project.set_Controls("parmMin", value - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", value + span, variable=f"{pid}::A{index}")


def set_common(project, active):
    hist = project.histogram(0)
    for name in ("U", "W", "X"):
        hist.InstrumentParameters[name][2] = bool(active)


def set_phase_profiles(project, active):
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Mustrain"][0] = "isotropic"
        hap["Size"][2] = [bool(active), False, False]
        hap["Mustrain"][2] = [bool(active), False, False]


def top_correlations(project):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(map(str, covariance.get("varyList", [])))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    rows = []
    if matrix.shape == (len(names), len(names)) and names:
        sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
        denom = np.outer(sigma, sigma)
        corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
        for left in range(len(names)):
            for right in range(left + 1, len(names)):
                value = float(corr[left, right])
                if abs(value) >= 0.85:
                    rows.append([names[left], names[right], value])
    rows.sort(key=lambda item: abs(item[2]), reverse=True)
    return rows[:20]


def state(project):
    hist = project.histogram(0)
    return {
        "instrument": {
            name: float(hist.InstrumentParameters[name][1])
            for name in ("U", "W", "X", "SH/L", "Polariz.", "Zero")
        },
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "phase_profiles": {
            phase.name: {
                "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "microstrain": float(phase.data["Histograms"][hist.name]["Mustrain"][1][0]),
            }
            for phase in project.phases()
        },
    }


def run(project, stage, records, cycles=15):
    clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    record = {
        "stage": stage,
        "Rwp_percent": float(project.histogram(0).get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(map(str, project.get_Frozen())),
        "state": state(project),
        "high_correlations": top_correlations(project),
    }
    records.append(record)
    print(json.dumps(record), flush=True)
    return record


def refine_until(project, stage, records):
    record = None
    for pass_index in range(3):
        record = run(project, f"{stage}_{pass_index + 1}", records)
        maximum = record["max_shift_esd"]
        if record["converged"] and maximum is not None and maximum <= 1.0 and not record["frozen"]:
            break
    return record


def run_branch(name, sequence):
    directory = OUT / name
    directory.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(directory / "profile.gpx"))
    install_bounds(project)
    records = []
    for index, profile_class in enumerate(sequence, start=1):
        if profile_class == "common":
            set_phase_profiles(project, False)
            set_common(project, True)
        else:
            set_common(project, False)
            set_phase_profiles(project, True)
        refine_until(project, f"step_{index}_{profile_class}", records)
    set_common(project, False)
    set_phase_profiles(project, False)
    project.save()
    summary = {
        "name": name,
        "sequence": sequence,
        "Rwp_percent": float(project.histogram(0).get_wR()),
        "state": state(project),
        "records": records,
    }
    (directory / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    return summary


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    summaries = [
        run_branch("common_first", ["common", "phase", "common", "phase"]),
        run_branch("phase_first", ["phase", "common", "phase", "common"]),
    ]
    (OUT / "summary.json").write_text(json.dumps(summaries, indent=2, default=str) + "\n")
    print(json.dumps([
        {"name": item["name"], "Rwp_percent": item["Rwp_percent"], **item["state"]}
        for item in summaries
    ], indent=2))


if __name__ == "__main__":
    main()
