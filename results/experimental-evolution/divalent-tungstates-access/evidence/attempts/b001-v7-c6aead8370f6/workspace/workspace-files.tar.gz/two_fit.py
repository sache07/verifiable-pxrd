from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
CIFS = [
    ('MnWO4_wolframite', Path('<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06/cif/1/52/02/1520200.cif')),
    ('WO3_gamma_monoclinic', Path('<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06/cif/1/52/89/1528915.cif')),
]


def phase_state(p, h):
    hap = p.data['Histograms'][h.name]
    return {
        'cell': p.get_cell(), 'mass': p.data['General']['Mass'],
        'scale': hap['Scale'][0], 'size': hap['Size'][:3],
        'mustrain': hap['Mustrain'][:3], 'PO': hap['Pref.Ori.'][:4],
    }


def report(gpx, stage):
    h = gpx.histogram(0)
    cov = gpx.data.get('Covariance', {}).get('data', {})
    masses = {p.name: p.data['General']['Mass'] * p.data['Histograms'][h.name]['Scale'][0]
              for p in gpx.phases()}
    total = sum(max(v, 0) for v in masses.values())
    row = {
        'stage': stage, 'Rwp': h.get_wR(),
        'instrument': {k: h.InstrumentParameters[k][1] for k in
                       ('Zero', 'U', 'V', 'W', 'X', 'Y', 'Z', 'SH/L', 'Polariz.')},
        'sample': {k: h.SampleParameters[k][0] for k in
                   ('Shift', 'SurfRoughA', 'SurfRoughB')},
        'fractions': {k: max(v, 0) / total for k, v in masses.items()},
        'phases': {p.name: phase_state(p, h) for p in gpx.phases()},
        'converged': cov.get('Rvals', {}).get('converged'),
        'max_shift_esd': cov.get('Rvals', {}).get('Max shft/sig'),
        'frozen': list(gpx.get_Frozen()),
    }
    print(json.dumps(row, default=lambda x: x.tolist() if hasattr(x, 'tolist') else str(x)), flush=True)


def run_stage(gpx, name, cycles=10, repeats=1):
    for i in range(repeats):
        gpx.data['Controls']['data']['parmFrozen'] = {'FrozenList': []}
        gpx.set_Controls('cycles', cycles)
        gpx.save()
        gpx.refine(makeBack=False)
        gpx.save()
        report(gpx, name + (f'_{i+1}' if repeats > 1 else ''))


def set_limits(gpx, h, phases):
    hid = h.id
    for name, lo, hi in [('U', 0.0, 40.0), ('W', 2.0, 40.0),
                         ('X', 0.1, 6.0), ('SH/L', 0.005, 0.10),
                         ('Polariz.', 0.5, 1.0), ('Zero', -0.25, 0.25)]:
        gpx.set_Controls('parmMin', lo, variable=f':{hid}:{name}')
        gpx.set_Controls('parmMax', hi, variable=f':{hid}:{name}')
    gpx.set_Controls('parmMin', -800.0, variable=f':{hid}:Shift')
    gpx.set_Controls('parmMax', 800.0, variable=f':{hid}:Shift')
    for p in phases:
        pid = p.id
        gpx.set_Controls('parmMin', 0.0, variable=f'{pid}:{hid}:Scale')
        gpx.set_Controls('parmMin', 0.04, variable=f'{pid}:{hid}:Size;i')
        gpx.set_Controls('parmMax', 1.5, variable=f'{pid}:{hid}:Size;i')
        gpx.set_Controls('parmMin', 0.0, variable=f'{pid}:{hid}:Mustrain;i')
        gpx.set_Controls('parmMax', 8000.0, variable=f'{pid}:{hid}:Mustrain;i')


def main():
    G2.SetPrintLevel('error')
    out = ROOT / '.tmp' / 'mnwo4_wo3.gpx'
    gpx = G2.G2Project(newgpx=str(out))
    h = gpx.add_powder_histogram(str(ROOT / '.tmp' / 'pattern.xye'),
                                 str(ROOT / 'instrument.instprm'), fmthint='xye')
    phases = [gpx.add_phase(str(cif), phasename=name, histograms=[h], fmthint='CIF')
              for name, cif in CIFS]
    h.SampleParameters['Scale'] = [1.0, False]
    h.SampleParameters['Gonio. radius'] = 200.0
    h.SampleParameters['Shift'] = [-520.0, False]
    h.InstrumentParameters['Zero'][0] = h.InstrumentParameters['Zero'][1] = 0.08
    h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 10,
                                      'coeffs': [1400.0] + [0.0] * 9,
                                      'refine': True}})
    for p, scale in zip(phases, (170.0, 35.0)):
        hap = p.data['Histograms'][h.name]
        hap['Scale'] = [scale, True]
        hap['Size'][0] = 'isotropic'
        hap['Size'][1][0] = 0.3
        hap['Size'][2] = [False, False, False]
        hap['Mustrain'][0] = 'isotropic'
        hap['Mustrain'][1][0] = 1500.0
        hap['Mustrain'][2] = [False, False, False]
    gpx.save()
    run_stage(gpx, 'background_scales', 10)

    h.SampleParameters['Shift'][1] = True
    for p in phases:
        p.set_refinements({'Cell': True})
    run_stage(gpx, 'shift_cells', 12, repeats=2)

    for p in phases:
        hap = p.data['Histograms'][h.name]
        hap['Size'][2][0] = True
        hap['Mustrain'][2][0] = True
    run_stage(gpx, 'phase_profiles', 12, repeats=3)

    x = np.asarray(h.getdata('x'))
    obs = np.asarray(h.getdata('yobs'))
    calc = np.asarray(h.getdata('ycalc'))
    bg = np.asarray(h.getdata('background'))
    np.savetxt(ROOT / '.tmp' / 'mnwo4_wo3_fit.csv',
               np.column_stack([x, obs, calc, obs-calc, bg]), delimiter=',',
               header='two_theta_deg,observed,calculated,difference,background', comments='')


if __name__ == '__main__':
    main()
