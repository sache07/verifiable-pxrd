from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "coordinates" / "stabilized.gpx"
REFERENCE = ROOT / ".tmp" / "calibration" / "shift_only" / "calibrated.gpx"
DESTINATION = ROOT / ".tmp" / "coordinates" / "accepted.gpx"


def clear_flags(project):
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def run(project, stage, cycles=15):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    result = {
        "stage": stage,
        "Rwp_percent": float(project.histogram(0).get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(map(str, project.get_Frozen())),
    }
    print(json.dumps(result), flush=True)
    return result


def main():
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(DESTINATION))
    reference = G2.G2Project(gpxfile=str(REFERENCE))
    # WO3 heavy coordinates are an oscillating, highly correlated pair. Restore
    # the complete reference topology so no unsupported partial adjustment is kept.
    for atom, source_atom in zip(project.phases()[1].atoms(), reference.phases()[1].atoms()):
        atom.coordinates = tuple(map(float, source_atom.coordinates))

    clear_flags(project)
    for phase_index in (0, 2):
        phase = project.phases()[phase_index]
        for atom_index, atom in enumerate(phase.atoms()):
            if phase_index == 2 and atom.element.strip().upper() in {"O", "O-2"}:
                continue
            atom.refinement_flags = "X"
    coordinate_record = run(project, "accepted_coordinate_replay", cycles=18)
    clear_flags(project)
    settle_record = run(project, "nuisance_settle", cycles=12)
    clear_flags(project)
    project.save()
    summary = {
        "coordinate_record": coordinate_record,
        "settle_record": settle_record,
        "short_contacts": {
            phase.name: [list(row) for row in phase.ShortDistances(useAll=False)]
            for phase in project.phases()
        },
    }
    (DESTINATION.parent / "accepted.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
