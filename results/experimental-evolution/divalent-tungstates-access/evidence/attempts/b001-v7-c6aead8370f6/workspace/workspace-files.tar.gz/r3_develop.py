from pathlib import Path
import argparse
import json
import re

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WINDOW_A = 0.10
COORD = re.compile(r'^(\d+)::dA[xyz]:(\d+)$')


def clear_frozen(gpx):
    gpx.data['Controls']['data']['parmFrozen'] = {'FrozenList': []}


def run(gpx, stage, cycles, records):
    clear_frozen(gpx)
    gpx.set_Controls('cycles', cycles)
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    h = gpx.histogram(0)
    cov = gpx.data.get('Covariance', {}).get('data', {})
    records.append({
        'stage': stage, 'Rwp_percent': float(h.get_wR()),
        'converged': bool(cov.get('Rvals', {}).get('converged', False)),
        'max_shift_esd': cov.get('Rvals', {}).get('Max shft/sig'),
        'frozen': list(gpx.get_Frozen()),
    })
    print(json.dumps(records[-1]), flush=True)
    return records[-1]


def frozen_atom_indices(record, pid):
    indices = set()
    for variable in record['frozen']:
        match = COORD.match(str(variable))
        if match and int(match.group(1)) == pid:
            indices.add(int(match.group(2)))
    return indices


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('candidate', choices=['r3_mn3teo6_2211528', 'r3_cd3teo6_2242674'])
    args = parser.parse_args()
    source = ROOT / '.tmp' / 'screens' / args.candidate / 'screen.gpx'
    work = ROOT / '.tmp' / 'developed' / args.candidate
    work.mkdir(parents=True, exist_ok=True)
    destination = work / 'developed.gpx'
    G2.SetPrintLevel('error')
    gpx = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
    candidate = gpx.phases()[2]
    gpx.index_ids()
    source_coordinates = [tuple(map(float, atom.coordinates))
                          for atom in candidate.atoms()]
    cell = candidate.get_cell()
    lengths = [cell['length_a'], cell['length_b'], cell['length_c']]
    for index, atom in enumerate(candidate.atoms()):
        for axis, value, length in zip('xyz', atom.coordinates, lengths):
            half = WINDOW_A / length
            variable = f'{candidate.id}::dA{axis}:{index}'
            gpx.set_Controls('parmMin', float(value) - half, variable=variable)
            gpx.set_Controls('parmMax', float(value) + half, variable=variable)
    records = []
    excluded = set()

    for atom in candidate.atoms():
        atom.refinement_flags = 'X' if atom.element.strip() != 'O' else ' '
    record = run(gpx, 'candidate_heavy_coordinates', 8, records)
    excluded.update(frozen_atom_indices(record, candidate.id))
    for index in excluded:
        candidate.atoms()[index].coordinates = source_coordinates[index]
    for atom in candidate.atoms():
        atom.refinement_flags = 'X' if atom.element.strip() == 'O' else ' '
    record = run(gpx, 'candidate_oxygen_coordinates', 8, records)
    excluded.update(frozen_atom_indices(record, candidate.id))
    for index in excluded:
        candidate.atoms()[index].coordinates = source_coordinates[index]
    for index, atom in enumerate(candidate.atoms()):
        atom.refinement_flags = ' ' if index in excluded else 'X'
    for pass_index in range(3):
        record = run(gpx, f'candidate_interior_joint_{pass_index + 1}', 8, records)
        newly_excluded = frozen_atom_indices(record, candidate.id)
        if newly_excluded:
            excluded.update(newly_excluded)
            for index in excluded:
                candidate.atoms()[index].coordinates = source_coordinates[index]
            for index, atom in enumerate(candidate.atoms()):
                atom.refinement_flags = ' ' if index in excluded else 'X'
        elif record['converged'] and record['max_shift_esd'] is not None and record['max_shift_esd'] <= 1.0:
            break
    for atom in candidate.atoms():
        atom.refinement_flags = ' '
    run(gpx, 'cell_scale_background_settle', 8, records)

    h = gpx.histogram(0)
    masses = {p.name: p.data['General']['Mass'] * p.data['Histograms'][h.name]['Scale'][0]
              for p in gpx.phases()}
    total = sum(max(v, 0.0) for v in masses.values())
    summary = {
        'candidate': args.candidate, 'stages': records,
        'excluded_bound_hit_atom_indices': sorted(excluded),
        'Rwp_percent': float(h.get_wR()),
        'fractions': {k: max(v, 0.0) / total for k, v in masses.items()},
        'cells': {p.name: p.get_cell() for p in gpx.phases()},
        'candidate_atoms': [
            {'label': atom.label, 'element': atom.element,
             'coordinates': list(map(float, atom.coordinates))}
            for atom in candidate.atoms()
        ],
        'short_contacts': [list(row) for row in candidate.ShortDistances(useAll=False)],
    }
    (work / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({'selected_checkpoint': summary['Rwp_percent'],
                      'fractions': summary['fractions'],
                      'short_contacts': summary['short_contacts']}))


if __name__ == '__main__':
    main()
