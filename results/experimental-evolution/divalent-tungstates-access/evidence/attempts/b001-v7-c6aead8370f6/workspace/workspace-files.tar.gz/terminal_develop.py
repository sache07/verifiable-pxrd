from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "selected" / "selected.gpx"
OUT = ROOT / ".tmp" / "terminal_base"
DESTINATION = OUT / "base.gpx"


def clear_flags(project):
    hist = project.histogram(0)
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "


def activate_profiles(project):
    hist = project.histogram(0)
    for index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][2] = [True, True, False] if index in (0, 1) else [True, False, False]


def activate_common(project):
    hist = project.histogram(0)
    for name in ("U", "W", "X"):
        hist.InstrumentParameters[name][2] = True


def activate_uiso(project):
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "U"


def state(project):
    hist = project.histogram(0)
    return {
        "instrument": {name: float(hist.InstrumentParameters[name][1]) for name in ("U", "W", "X", "SH/L", "Polariz.", "Zero")},
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "phases": {
            phase.name: {
                "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "strain_type": phase.data["Histograms"][hist.name]["Mustrain"][0],
                "strain_values": list(map(float, phase.data["Histograms"][hist.name]["Mustrain"][1][:2])),
                "strain_axis": list(phase.data["Histograms"][hist.name]["Mustrain"][3]),
                "MD_ratio": float(phase.data["Histograms"][hist.name]["Pref.Ori."][1]),
                "MD_axis": list(phase.data["Histograms"][hist.name]["Pref.Ori."][3]),
                "Uiso_A2": float(phase.atoms()[0].uiso),
            }
            for phase in project.phases()
        },
    }


def high_correlations(project):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(map(str, covariance.get("varyList", [])))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    rows = []
    if matrix.shape == (len(names), len(names)) and names:
        sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
        denominator = np.outer(sigma, sigma)
        corr = np.divide(matrix, denominator, out=np.zeros_like(matrix), where=denominator > 0)
        for left in range(len(names)):
            for right in range(left + 1, len(names)):
                value = float(corr[left, right])
                if abs(value) >= 0.90:
                    rows.append([names[left], names[right], value])
    rows.sort(key=lambda row: abs(row[2]), reverse=True)
    return rows[:20]


def run(project, stage, records, cycles=15):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    record = {
        "stage": stage,
        "Rwp_percent": float(project.histogram(0).get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(map(str, project.get_Frozen())),
        "high_correlations": high_correlations(project),
        "state": state(project),
    }
    records.append(record)
    print(json.dumps(record), flush=True)
    return record


def run_until(project, stage, records, passes=4):
    record = None
    for pass_index in range(passes):
        record = run(project, f"{stage}_{pass_index + 1}", records)
        maximum = record["max_shift_esd"]
        if record["converged"] and maximum is not None and maximum <= 1.0 and not record["frozen"]:
            break
    return record


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(DESTINATION))
    hist = project.histogram(0)
    clear_flags(project)
    # Supported strain basins from equal axis screens.
    strain0 = project.phases()[0].data["Histograms"][hist.name]["Mustrain"]
    strain0[0], strain0[1][0], strain0[1][1], strain0[3] = "uniaxial", 5677.572235410026, 5306.915629130102, [1, 0, 0]
    strain1 = project.phases()[1].data["Histograms"][hist.name]["Mustrain"]
    strain1[0], strain1[1][0], strain1[1][1], strain1[3] = "uniaxial", 1981.1121237123225, 4410.710753354001, [0, 1, 0]
    strain2 = project.phases()[2].data["Histograms"][hist.name]["Mustrain"]
    strain2[0], strain2[1][1] = "isotropic", strain2[1][0]
    for phase in project.phases():
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", 1.0, False, [0, 0, 1]

    records = []
    for alternation in range(2):
        clear_flags(project)
        activate_profiles(project)
        run_until(project, f"phase_profiles_{alternation + 1}", records)
        clear_flags(project)
        activate_common(project)
        run_until(project, f"common_profile_{alternation + 1}", records)
    clear_flags(project)
    activate_uiso(project)
    run_until(project, "phase_common_uiso", records)
    clear_flags(project)
    hist.InstrumentParameters["SH/L"][2] = True
    run_until(project, "axial_divergence", records)
    clear_flags(project)
    run_until(project, "base_settle", records)
    clear_flags(project)
    project.save()
    summary = {
        "Rwp_percent": float(hist.get_wR()), "state": state(project),
        "records": records,
        "short_contacts": {phase.name: [list(row) for row in phase.ShortDistances(useAll=False)] for phase in project.phases()},
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
