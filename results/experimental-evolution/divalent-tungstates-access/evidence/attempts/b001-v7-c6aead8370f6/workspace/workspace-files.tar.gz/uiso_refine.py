from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "profiles" / "common_first" / "profile.gpx"
OUT = ROOT / ".tmp" / "uiso"
DESTINATION = OUT / "uiso.gpx"


def run(project, stage, cycles=15):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    result = {
        "stage": stage,
        "Rwp_percent": float(project.histogram(0).get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(map(str, project.get_Frozen())),
    }
    print(json.dumps(result), flush=True)
    return result


def common_uiso_values(project):
    result = {}
    for phase in project.phases():
        values = [float(atom.uiso) for atom in phase.atoms()]
        result[phase.name] = {"min": min(values), "max": max(values), "values": values}
    return result


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(DESTINATION))
    project.index_ids()
    controls = project.data["Controls"]["data"]
    # Keep existing physical profile/calibration bounds, adding Uiso bounds.
    controls["parmFrozen"] = {"FrozenList": []}
    for phase in project.phases():
        pid = int(phase.data["pId"])
        variables = []
        for atom_index, atom in enumerate(phase.atoms()):
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = 0.005
            atom.data[atom.cia + 2:atom.cia + 8] = [0.0] * 6
            atom.refinement_flags = "U"
            variable = f"{pid}::AUiso:{atom_index}"
            variables.append(variable)
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
    records = []
    for pass_index in range(3):
        record = run(project, f"phase_common_uiso_{pass_index + 1}")
        records.append(record)
        maximum = record["max_shift_esd"]
        if record["converged"] and maximum is not None and maximum <= 1.0 and not record["frozen"]:
            break
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(map(str, covariance.get("varyList", [])))
    values = np.asarray(covariance.get("variables", []), dtype=float)
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    refined_parameters = []
    if len(names) == len(values) and matrix.shape == (len(names), len(names)):
        sigmas = np.sqrt(np.maximum(np.diag(matrix), 0.0))
        refined_parameters = [
            {"name": name, "value": float(value), "esd": float(sigma)}
            for name, value, sigma in zip(names, values, sigmas)
            if "Uiso" in name or "::constr" in name or "::nv-" in name
        ]
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    settle = run(project, "nuisance_settle", cycles=12)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.save()
    summary = {
        "Rwp_percent": float(project.histogram(0).get_wR()),
        "common_Uiso_A2": common_uiso_values(project),
        "Uiso_parameters": refined_parameters,
        "records": records,
        "settle": settle,
        "short_contacts": {
            phase.name: [list(row) for row in phase.ShortDistances(useAll=False)]
            for phase in project.phases()
        },
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
