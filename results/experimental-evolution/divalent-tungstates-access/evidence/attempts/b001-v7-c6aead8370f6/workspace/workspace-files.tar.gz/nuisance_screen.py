from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "combined" / "combined.gpx"
OUT = ROOT / ".tmp" / "nuisance_screen"


def clear_flags(project):
    hist = project.histogram(0)
    for parameter in hist.InstrumentParameters.values():
        if isinstance(parameter, list) and len(parameter) > 2:
            parameter[2] = False
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
    for name in ("SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[name][1] = False


def covariance_values(project, wanted):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(map(str, covariance.get("varyList", [])))
    values = np.asarray(covariance.get("variables", []), dtype=float)
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    result = {}
    for name in wanted:
        if name not in names or len(values) != len(names) or matrix.shape != (len(names), len(names)):
            continue
        index = names.index(name)
        result[name] = {
            "value": float(values[index]),
            "esd": float(np.sqrt(max(matrix[index, index], 0.0))),
        }
    correlations = []
    if matrix.shape == (len(names), len(names)):
        sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
        for i, left in enumerate(names):
            if left not in wanted:
                continue
            for j in range(i + 1, len(names)):
                right = names[j]
                if right not in wanted:
                    continue
                denominator = sigma[i] * sigma[j]
                if denominator:
                    correlations.append([left, right, float(matrix[i, j] / denominator)])
    return result, correlations


def state(project):
    hist = project.histogram(0)
    return {
        "SH_L": float(hist.InstrumentParameters["SH/L"][1]),
        "polarization": float(hist.InstrumentParameters["Polariz."][1]),
        "roughness_A": float(hist.SampleParameters["SurfRoughA"][0]),
        "roughness_B": float(hist.SampleParameters["SurfRoughB"][0]),
    }


def run_branch(name, active):
    directory = OUT / name
    directory.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(directory / "nuisance.gpx"))
    clear_flags(project)
    hist = project.histogram(0)
    wanted = []
    if "shl" in active:
        hist.InstrumentParameters["SH/L"][2] = True
        wanted.append(":0:SH/L")
    if "polarization" in active:
        hist.InstrumentParameters["Polariz."][2] = True
        wanted.append(":0:Polariz.")
    if "roughness" in active:
        hist.SampleParameters["SurfRoughA"] = [0.20, True]
        hist.SampleParameters["SurfRoughB"] = [0.10, True]
        wanted.extend((":0:SurfRoughA", ":0:SurfRoughB"))
    project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.10, variable=":0:SH/L")
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    records = []
    for pass_index in range(3):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 15)
        project.save()
        project.refine(makeBack=False)
        project.save()
        covariance = project.data.get("Covariance", {}).get("data", {})
        rvals = covariance.get("Rvals", {})
        parameters, correlations = covariance_values(project, wanted)
        record = {
            "pass": pass_index + 1,
            "Rwp_percent": float(hist.get_wR()),
            "state": state(project),
            "parameters": parameters,
            "correlations": correlations,
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": list(map(str, project.get_Frozen())),
        }
        records.append(record)
        print(json.dumps({"branch": name, **record}), flush=True)
        if record["converged"] and record["max_shift_esd"] is not None and record["max_shift_esd"] <= 1.0 and not record["frozen"]:
            break
    clear_flags(project)
    project.save()
    summary = {"name": name, "active": active, "Rwp_percent": float(hist.get_wR()), "state": state(project), "records": records}
    (directory / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    summaries = [
        run_branch("shl", ["shl"]),
        run_branch("polarization", ["polarization"]),
        run_branch("roughness", ["roughness"]),
        run_branch("shl_polarization", ["shl", "polarization"]),
        run_branch("all", ["shl", "polarization", "roughness"]),
    ]
    (OUT / "summary.json").write_text(json.dumps(summaries, indent=2) + "\n")
    print(json.dumps(summaries, indent=2))


if __name__ == "__main__":
    main()
