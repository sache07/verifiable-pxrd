from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "uiso" / "uiso.gpx"
OUT = ROOT / ".tmp" / "strain_screen"
AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def parameter_esd(project, name):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(map(str, covariance.get("varyList", [])))
    if name not in names:
        return None
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return None
    index = names.index(name)
    return float(np.sqrt(max(matrix[index, index], 0.0)))


def correlation(project, left_name, right_name):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(map(str, covariance.get("varyList", [])))
    if left_name not in names or right_name not in names:
        return None
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return None
    left, right = names.index(left_name), names.index(right_name)
    denom = np.sqrt(max(matrix[left, left], 0.0) * max(matrix[right, right], 0.0))
    return None if denom == 0 else float(matrix[left, right] / denom)


def run_candidate(phase_index, axis):
    axis_label = "".join(map(str, axis))
    directory = OUT / f"phase_{phase_index}_axis_{axis_label}"
    directory.mkdir(parents=True, exist_ok=True)
    destination = directory / "strain.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(destination))
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][1] = hap["Mustrain"][1][0]
        hap["Mustrain"][2] = [False, False, False]
    phase = project.phases()[phase_index]
    pid = int(phase.data["pId"])
    strain = phase.data["Histograms"][hist.name]["Mustrain"]
    strain[0] = "uniaxial"
    strain[1][1] = float(strain[1][0])
    strain[2] = [True, True, False]
    strain[3] = list(axis)
    equatorial = f"{pid}:0:Mustrain;i"
    axial = f"{pid}:0:Mustrain;a"
    project.set_Controls("parmMin", 0.0, variable=equatorial)
    project.set_Controls("parmMax", 8000.0, variable=equatorial)
    project.set_Controls("parmMin", 0.0, variable=axial)
    project.set_Controls("parmMax", 32000.0, variable=axial)
    records = []
    for pass_index in range(2):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 15)
        project.save()
        project.refine(makeBack=False)
        project.save()
        covariance = project.data.get("Covariance", {}).get("data", {})
        rvals = covariance.get("Rvals", {})
        record = {
            "pass": pass_index + 1,
            "Rwp_percent": float(hist.get_wR()),
            "equatorial_ppm": float(strain[1][0]),
            "axial_ppm": float(strain[1][1]),
            "equatorial_esd": parameter_esd(project, equatorial),
            "axial_esd": parameter_esd(project, axial),
            "correlation": correlation(project, equatorial, axial),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": list(map(str, project.get_Frozen())),
        }
        records.append(record)
        print(json.dumps({
            "phase_index": phase_index, "phase": phase.name,
            "axis": list(axis), **record,
        }), flush=True)
        if record["converged"] and record["max_shift_esd"] is not None and record["max_shift_esd"] <= 1.0 and not record["frozen"]:
            break
    strain[2] = [False, False, False]
    project.save()
    summary = {
        "phase_index": phase_index, "phase": phase.name, "axis": list(axis),
        "equatorial_ppm": float(strain[1][0]), "axial_ppm": float(strain[1][1]),
        "Rwp_percent": float(hist.get_wR()), "records": records,
    }
    (directory / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    summaries = []
    for phase_index in range(3):
        for axis in AXES:
            summaries.append(run_candidate(phase_index, axis))
    summaries.sort(key=lambda row: row["Rwp_percent"])
    (OUT / "summary.json").write_text(json.dumps(summaries, indent=2) + "\n")
    print(json.dumps(summaries, indent=2))


if __name__ == "__main__":
    main()
